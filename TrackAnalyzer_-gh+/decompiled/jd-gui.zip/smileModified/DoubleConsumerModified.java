package smileModified;

public interface DoubleConsumerModified {
  void accept(int paramInt1, int paramInt2, double paramDouble);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_-master/jar_expanded/!/smileModified/DoubleConsumerModified.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */