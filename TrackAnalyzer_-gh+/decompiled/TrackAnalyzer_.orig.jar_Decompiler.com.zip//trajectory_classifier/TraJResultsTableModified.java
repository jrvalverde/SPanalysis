package trajectory_classifier;

import ij.measure.ResultsTable;

public class TraJResultsTableModified extends ResultsTable {
   boolean isParentTable;

   public TraJResultsTableModified() {
      this.isParentTable = false;
   }

   public TraJResultsTableModified(boolean isParentTable) {
      this.isParentTable = isParentTable;
   }
}
