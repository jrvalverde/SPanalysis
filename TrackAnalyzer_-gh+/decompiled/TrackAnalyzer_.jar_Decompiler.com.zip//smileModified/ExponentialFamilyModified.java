package smileModified;

public interface ExponentialFamilyModified {
   MixtureModified.Component M(double[] var1, double[] var2);
}
