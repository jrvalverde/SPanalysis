package vecmath;

// $FF: synthetic class
interface package-info {
}
