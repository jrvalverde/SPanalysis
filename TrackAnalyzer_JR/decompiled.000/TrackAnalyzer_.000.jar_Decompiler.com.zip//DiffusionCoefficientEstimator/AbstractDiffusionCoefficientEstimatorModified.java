package DiffusionCoefficientEstimator;

import traJ.TrajectoryModified;

public interface AbstractDiffusionCoefficientEstimatorModified {
   double[] getDiffusionCoefficient(TrajectoryModified var1, double var2);
}
