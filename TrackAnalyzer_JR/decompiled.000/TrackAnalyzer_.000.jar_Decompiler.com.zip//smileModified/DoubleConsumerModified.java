package smileModified;

public interface DoubleConsumerModified {
   void accept(int var1, int var2, double var3);
}
