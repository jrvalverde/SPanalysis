package DiffusionCoefficientEstimator;

import traJ.TrajectoryModified;

public interface AbstractDiffusionCoefficientEstimatorModified {
  double[] getDiffusionCoefficient(TrajectoryModified paramTrajectoryModified, double paramDouble);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/DiffusionCoefficientEstimator/AbstractDiffusionCoefficientEstimatorModified.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */