package smileModified;

public interface ExponentialFamilyModified {
  MixtureModified.Component M(double[] paramArrayOfdouble1, double[] paramArrayOfdouble2);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/smileModified/ExponentialFamilyModified.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */