package vecmath;


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/vecmath/package-info.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */