/*
 * #%L
 * ImgLib2: a general-purpose, multidimensional image processing library.
 * %%
 * Copyright (C) 2009 - 2021 Tobias Pietzsch, Stephan Preibisch, Stephan Saalfeld,
 * John Bogovic, Albert Cardona, Barry DeZonia, Christian Dietz, Jan Funke,
 * Aivar Grislis, Jonathan Hale, Grant Harris, Stefan Helfrich, Mark Hiner,
 * Martin Horn, Steffen Jaensch, Lee Kamentsky, Larry Lindsey, Melissa Linkert,
 * Mark Longair, Brian Northan, Nick Perry, Curtis Rueden, Johannes Schindelin,
 * Jean-Yves Tinevez and Michael Zinsmaier.
 * %%
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 * #L%
 */
package net.imglib2.loops;

import java.util.Arrays;
import java.util.List;

import net.imglib2.Localizable;
import net.imglib2.Positionable;

/**
 * Helper for the implementation of {@link LoopBuilder}. Used to bind together a
 * list of {@link Positionable}s:
 * <p>
 * {@code
 * Positionable synced = SyncedPositionables.create(listOfPositionables);
 * }
 * </p>
 * <p>
 * A call of a method for relative movement of {@code synced} moves all the
 * {@link Positionable}s in the list ({@code listOfPositionable}) accordingly.
 * </p>
 * <p>
 * e.g.: A call to {@code synced.fwd(d)}, is functionally equivalent to
 * {@code for(Positionable p : listOfPostionables) { p.fwd(d); }}
 * </p>
 * <p>
 * Methods {@link Positionable#fwd}, {@link Positionable#bck} and
 * {@link Positionable#move} are supported. But calling
 * {@link Positionable#setPosition} or {@link Positionable#numDimensions} will
 * throw an {@link UnsupportedOperationException}.
 * </p>
 *
 * @author Matthias Arzt
 */
public final class SyncedPositionables
{

	private SyncedPositionables()
	{
		// prevent class from instantiation
	}

	private static final List< ClassCopyProvider< Positionable > > forwarderFactories = Arrays.asList(
			new ClassCopyProvider<>( Private.GeneralForwarder.class, Positionable.class ),
			new ClassCopyProvider<>( Private.Forwarder1.class, Positionable.class ),
			new ClassCopyProvider<>( Private.Forwarder2.class, Positionable.class ),
			new ClassCopyProvider<>( Private.Forwarder3.class, Positionable.class ),
			new ClassCopyProvider<>( Private.Forwarder4.class, Positionable.class ),
			new ClassCopyProvider<>( Private.Forwarder5.class, Positionable.class )
	);

	public static Positionable create( final List< ? extends Positionable > positionables )
	{
		List< Class< ? > > key = ListUtils.map( Object::getClass, positionables );
		int i = positionables.size();
		return forwarderFactories.get( i >= forwarderFactories.size() ? 0 : i ).newInstanceForKey( key, positionables );
	}

	public static Positionable create( final Positionable... positionables )
	{
		return create( Arrays.asList( positionables ) );
	}

	static class Private {

		public interface Forwarder extends Positionable
		{

			@Override
			default void bck( final int d )
			{
				move( -1, d );
			}

			@Override
			default void move( final int distance, final int d )
			{
				move( ( long ) distance, d );
			}

			@Override
			default void move( final Localizable localizable )
			{
				for ( int i = 0; i < localizable.numDimensions(); i++ )
					move( localizable.getLongPosition( i ), i );
			}

			@Override
			default void move( final int[] distance )
			{
				for ( int i = 0; i < distance.length; i++ )
					move( ( long ) distance[ i ], i );
			}

			@Override
			default void move( final long[] distance )
			{
				for ( int i = 0; i < distance.length; i++ )
					move( distance[ i ], i );
			}

			@Override
			default void setPosition( final Localizable localizable )
			{
				throw new UnsupportedOperationException();
			}

			@Override
			default void setPosition( final int[] position )
			{
				throw new UnsupportedOperationException();
			}

			@Override
			default void setPosition( final long[] position )
			{
				throw new UnsupportedOperationException();
			}

			@Override
			default void setPosition( final int position, final int d )
			{
				throw new UnsupportedOperationException();
			}

			@Override
			default void setPosition( final long position, final int d )
			{
				throw new UnsupportedOperationException();
			}

			@Override
			default int numDimensions()
			{
				throw new UnsupportedOperationException();
			}
		}

		public static class Forwarder1 implements Forwarder
		{

			private final Positionable a;

			public Forwarder1( final List< ? extends Positionable > values )
			{
				this.a = values.get( 0 );
			}

			@Override
			public void fwd( final int d )
			{
				a.fwd( d );
			}

			@Override
			public void move( final long offset, final int d )
			{
				a.move( offset, d );
			}
		}

		public static class Forwarder2 implements Forwarder
		{

			private final Positionable a, b;

			public Forwarder2( final List< ? extends Positionable > values )
			{
				this.a = values.get( 0 );
				this.b = values.get( 1 );
			}

			@Override
			public void fwd( final int d )
			{
				a.fwd( d );
				b.fwd( d );
			}

			@Override
			public void move( final long offset, final int d )
			{
				a.move( offset, d );
				b.move( offset, d );
			}
		}

		public static class Forwarder3 implements Forwarder
		{

			private final Positionable a, b, c;

			public Forwarder3( final List< ? extends Positionable > values )
			{
				this.a = values.get( 0 );
				this.b = values.get( 1 );
				this.c = values.get( 2 );
			}

			@Override
			public void fwd( final int d )
			{
				a.fwd( d );
				b.fwd( d );
				c.fwd( d );
			}

			@Override
			public void move( final long offset, final int d )
			{
				a.move( offset, d );
				b.move( offset, d );
				c.move( offset, d );
			}
		}

		public static class Forwarder4 implements Forwarder
		{

			private final Positionable a, b, c, d;

			public Forwarder4( final List< ? extends Positionable > values )
			{
				this.a = values.get( 0 );
				this.b = values.get( 1 );
				this.c = values.get( 2 );
				this.d = values.get( 3 );
			}

			@Override
			public void fwd( final int d )
			{
				this.a.fwd( d );
				this.b.fwd( d );
				this.c.fwd( d );
				this.d.fwd( d );
			}

			@Override
			public void move( final long offset, final int d )
			{
				this.a.move( offset, d );
				this.b.move( offset, d );
				this.c.move( offset, d );
				this.d.move( offset, d );
			}
		}

		public static class Forwarder5 implements Forwarder
		{

			private final Positionable a, b, c, d, e;

			public Forwarder5( final List< ? extends Positionable > values )
			{
				this.a = values.get( 0 );
				this.b = values.get( 1 );
				this.c = values.get( 2 );
				this.d = values.get( 3 );
				this.e = values.get( 4 );
			}

			@Override
			public void fwd( final int d )
			{
				this.a.fwd( d );
				this.b.fwd( d );
				this.c.fwd( d );
				this.d.fwd( d );
				this.e.fwd( d );
			}

			@Override
			public void move( final long offset, final int d )
			{
				this.a.move( offset, d );
				this.b.move( offset, d );
				this.c.move( offset, d );
				this.d.move( offset, d );
				this.e.move( offset, d );
			}
		}

		public static class GeneralForwarder implements Forwarder
		{

			private final Positionable[] values;

			public GeneralForwarder( final List< ? extends Positionable > values )
			{
				this.values = values.toArray( new Positionable[ values.size() ] );
			}

			@Override
			public void fwd( final int d )
			{
				for ( final Positionable positionable : values )
					positionable.fwd( d );
			}

			@Override
			public void move( final long offset, final int d )
			{
				for ( final Positionable positionable : values )
					positionable.move( offset, d );
			}
		}
	}

}
