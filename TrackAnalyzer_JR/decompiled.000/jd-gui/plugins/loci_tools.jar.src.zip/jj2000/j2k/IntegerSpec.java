/*     */ package jj2000.j2k;
/*     */ 
/*     */ import com.sun.media.imageioimpl.plugins.jpeg2000.J2KImageWriteParamJava;
/*     */ import java.util.StringTokenizer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IntegerSpec
/*     */   extends ModuleSpec
/*     */ {
/* 101 */   protected static int MAX_INT = Integer.MAX_VALUE;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IntegerSpec(int nt, int nc, byte type) {
/* 117 */     super(nt, nc, type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IntegerSpec(int nt, int nc, byte type, J2KImageWriteParamJava wp, String values, String defaultValue) {
/* 137 */     super(nt, nc, type);
/*     */     
/* 139 */     if (values == null) {
/*     */       try {
/* 141 */         setDefault(new Integer(defaultValue));
/*     */       }
/* 143 */       catch (NumberFormatException e) {
/* 144 */         throw new IllegalArgumentException("Non recognized value for option -: " + defaultValue);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 154 */     StringTokenizer stk = new StringTokenizer(values);
/*     */     
/* 156 */     byte curSpecType = 0;
/*     */     
/* 158 */     boolean[] tileSpec = null;
/* 159 */     boolean[] compSpec = null;
/*     */     
/* 161 */     while (stk.hasMoreTokens()) {
/* 162 */       Integer value; String word = stk.nextToken();
/*     */       
/* 164 */       switch (word.charAt(0)) {
/*     */         case 't':
/* 166 */           tileSpec = parseIdx(word, this.nTiles);
/* 167 */           if (curSpecType == 1) {
/* 168 */             curSpecType = 3; continue;
/*     */           } 
/* 170 */           curSpecType = 2;
/*     */           continue;
/*     */         case 'c':
/* 173 */           compSpec = parseIdx(word, this.nComp);
/* 174 */           if (curSpecType == 2) {
/* 175 */             curSpecType = 3; continue;
/*     */           } 
/* 177 */           curSpecType = 1;
/*     */           continue;
/*     */       } 
/*     */       try {
/* 181 */         value = new Integer(word);
/*     */       }
/* 183 */       catch (NumberFormatException e) {
/* 184 */         throw new IllegalArgumentException("Non recognized value for option -: " + word);
/*     */       } 
/*     */ 
/*     */       
/* 188 */       if (curSpecType == 0) {
/* 189 */         setDefault(value);
/*     */       }
/* 191 */       else if (curSpecType == 2) {
/* 192 */         for (int i = tileSpec.length - 1; i >= 0; i--) {
/* 193 */           if (tileSpec[i]) {
/* 194 */             setTileDef(i, value);
/*     */           }
/*     */         } 
/* 197 */       } else if (curSpecType == 1) {
/* 198 */         for (int i = compSpec.length - 1; i >= 0; i--) {
/* 199 */           if (compSpec[i]) {
/* 200 */             setCompDef(i, value);
/*     */           }
/*     */         } 
/*     */       } else {
/* 204 */         for (int i = tileSpec.length - 1; i >= 0; i--) {
/* 205 */           for (int j = compSpec.length - 1; j >= 0; j--) {
/* 206 */             if (tileSpec[i] && compSpec[j]) {
/* 207 */               setTileCompVal(i, j, value);
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 214 */       curSpecType = 0;
/* 215 */       tileSpec = null;
/* 216 */       compSpec = null;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 222 */     if (getDefault() == null) {
/* 223 */       int ndefspec = 0;
/* 224 */       for (int t = nt - 1; t >= 0; t--) {
/* 225 */         for (int c = nc - 1; c >= 0; c--) {
/* 226 */           if (this.specValType[t][c] == 0) {
/* 227 */             ndefspec++;
/*     */           }
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 234 */       if (ndefspec != 0) {
/*     */         try {
/* 236 */           setDefault(new Integer(defaultValue));
/*     */         }
/* 238 */         catch (NumberFormatException e) {
/* 239 */           throw new IllegalArgumentException("Non recognized value for option - : " + defaultValue);
/*     */         } 
/*     */       } else {
/*     */         int c, i;
/*     */ 
/*     */ 
/*     */         
/* 246 */         setDefault(getTileCompVal(0, 0));
/* 247 */         switch (this.specValType[0][0]) {
/*     */           case 2:
/* 249 */             for (c = nc - 1; c >= 0; c--) {
/* 250 */               if (this.specValType[0][c] == 2)
/* 251 */                 this.specValType[0][c] = 0; 
/*     */             } 
/* 253 */             this.tileDef[0] = null;
/*     */             break;
/*     */           case 1:
/* 256 */             for (i = nt - 1; i >= 0; i--) {
/* 257 */               if (this.specValType[i][0] == 1)
/* 258 */                 this.specValType[i][0] = 0; 
/*     */             } 
/* 260 */             this.compDef[0] = null;
/*     */             break;
/*     */           case 3:
/* 263 */             this.specValType[0][0] = 0;
/* 264 */             this.tileCompVal.put("t0c0", null);
/*     */             break;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMax() {
/* 278 */     int max = ((Integer)this.def).intValue();
/*     */ 
/*     */     
/* 281 */     for (int t = 0; t < this.nTiles; t++) {
/* 282 */       for (int c = 0; c < this.nComp; c++) {
/* 283 */         int tmp = ((Integer)getSpec(t, c)).intValue();
/* 284 */         if (max < tmp) {
/* 285 */           max = tmp;
/*     */         }
/*     */       } 
/*     */     } 
/* 289 */     return max;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMin() {
/* 299 */     int min = ((Integer)this.def).intValue();
/*     */ 
/*     */     
/* 302 */     for (int t = 0; t < this.nTiles; t++) {
/* 303 */       for (int c = 0; c < this.nComp; c++) {
/* 304 */         int tmp = ((Integer)getSpec(t, c)).intValue();
/* 305 */         if (min > tmp) {
/* 306 */           min = tmp;
/*     */         }
/*     */       } 
/*     */     } 
/* 310 */     return min;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaxInComp(int c) {
/* 322 */     int max = 0;
/*     */ 
/*     */     
/* 325 */     for (int t = 0; t < this.nTiles; t++) {
/* 326 */       int tmp = ((Integer)getSpec(t, c)).intValue();
/* 327 */       if (max < tmp) {
/* 328 */         max = tmp;
/*     */       }
/*     */     } 
/* 331 */     return max;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMinInComp(int c) {
/* 343 */     int min = MAX_INT;
/*     */ 
/*     */     
/* 346 */     for (int t = 0; t < this.nTiles; t++) {
/* 347 */       int tmp = ((Integer)getSpec(t, c)).intValue();
/* 348 */       if (min > tmp) {
/* 349 */         min = tmp;
/*     */       }
/*     */     } 
/* 352 */     return min;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaxInTile(int t) {
/* 364 */     int max = 0;
/*     */ 
/*     */     
/* 367 */     for (int c = 0; c < this.nComp; c++) {
/* 368 */       int tmp = ((Integer)getSpec(t, c)).intValue();
/* 369 */       if (max < tmp) {
/* 370 */         max = tmp;
/*     */       }
/*     */     } 
/* 373 */     return max;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMinInTile(int t) {
/* 385 */     int min = MAX_INT;
/*     */ 
/*     */     
/* 388 */     for (int c = 0; c < this.nComp; c++) {
/* 389 */       int tmp = ((Integer)getSpec(t, c)).intValue();
/* 390 */       if (min > tmp) {
/* 391 */         min = tmp;
/*     */       }
/*     */     } 
/* 394 */     return min;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/IntegerSpec.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */