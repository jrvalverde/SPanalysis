/*     */ package jj2000.j2k.roi.encoder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SubbandROIMask
/*     */ {
/*     */   protected SubbandROIMask ll;
/*     */   protected SubbandROIMask lh;
/*     */   protected SubbandROIMask hl;
/*     */   protected SubbandROIMask hh;
/*     */   protected boolean isNode;
/*     */   public int ulx;
/*     */   public int uly;
/*     */   public int w;
/*     */   public int h;
/*     */   
/*     */   public SubbandROIMask(int ulx, int uly, int w, int h) {
/* 137 */     this.ulx = ulx;
/* 138 */     this.uly = uly;
/* 139 */     this.w = w;
/* 140 */     this.h = h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SubbandROIMask getSubbandRectROIMask(int x, int y) {
/* 157 */     if (x < this.ulx || y < this.uly || x >= this.ulx + this.w || y >= this.uly + this.h) {
/* 158 */       throw new IllegalArgumentException();
/*     */     }
/*     */     
/* 161 */     SubbandROIMask cur = this;
/* 162 */     while (cur.isNode) {
/* 163 */       SubbandROIMask hhs = cur.hh;
/*     */       
/* 165 */       if (x < hhs.ulx) {
/*     */         
/* 167 */         if (y < hhs.uly) {
/*     */           
/* 169 */           cur = cur.ll;
/*     */           
/*     */           continue;
/*     */         } 
/* 173 */         cur = cur.lh;
/*     */         
/*     */         continue;
/*     */       } 
/*     */       
/* 178 */       if (y < hhs.uly) {
/*     */         
/* 180 */         cur = cur.hl;
/*     */         
/*     */         continue;
/*     */       } 
/* 184 */       cur = cur.hh;
/*     */     } 
/*     */ 
/*     */     
/* 188 */     return cur;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/roi/encoder/SubbandROIMask.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */