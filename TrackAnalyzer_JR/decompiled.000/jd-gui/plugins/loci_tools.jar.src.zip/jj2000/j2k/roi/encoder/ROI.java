/*     */ package jj2000.j2k.roi.encoder;
/*     */ 
/*     */ import jj2000.j2k.image.input.ImgReaderPGM;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ROI
/*     */ {
/* 100 */   public ImgReaderPGM maskPGM = null;
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean arbShape;
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean rect;
/*     */ 
/*     */ 
/*     */   
/*     */   public int comp;
/*     */ 
/*     */ 
/*     */   
/*     */   public int ulx;
/*     */ 
/*     */ 
/*     */   
/*     */   public int uly;
/*     */ 
/*     */ 
/*     */   
/*     */   public int w;
/*     */ 
/*     */   
/*     */   public int h;
/*     */ 
/*     */   
/*     */   public int x;
/*     */ 
/*     */   
/*     */   public int y;
/*     */ 
/*     */   
/*     */   public int r;
/*     */ 
/*     */ 
/*     */   
/*     */   public ROI(int comp, ImgReaderPGM maskPGM) {
/* 141 */     this.arbShape = true;
/* 142 */     this.rect = false;
/* 143 */     this.comp = comp;
/* 144 */     this.maskPGM = maskPGM;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ROI(int comp, int ulx, int uly, int w, int h) {
/* 161 */     this.arbShape = false;
/* 162 */     this.comp = comp;
/* 163 */     this.ulx = ulx;
/* 164 */     this.uly = uly;
/* 165 */     this.w = w;
/* 166 */     this.h = h;
/* 167 */     this.rect = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ROI(int comp, int x, int y, int rad) {
/* 182 */     this.arbShape = false;
/* 183 */     this.comp = comp;
/* 184 */     this.x = x;
/* 185 */     this.y = y;
/* 186 */     this.r = rad;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 193 */     if (this.arbShape) {
/* 194 */       return "ROI with arbitrary shape, PGM file= " + this.maskPGM;
/*     */     }
/* 196 */     if (this.rect) {
/* 197 */       return "Rectangular ROI, comp=" + this.comp + " ulx=" + this.ulx + " uly=" + this.uly + " w=" + this.w + " h=" + this.h;
/*     */     }
/*     */     
/* 200 */     return "Circular ROI,  comp=" + this.comp + " x=" + this.x + " y=" + this.y + " radius=" + this.r;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/roi/encoder/ROI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */