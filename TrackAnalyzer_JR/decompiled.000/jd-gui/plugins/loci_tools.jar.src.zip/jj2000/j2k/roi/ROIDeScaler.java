/*     */ package jj2000.j2k.roi;
/*     */ 
/*     */ import com.sun.media.imageioimpl.plugins.jpeg2000.J2KImageReadParamJava;
/*     */ import jj2000.j2k.decoder.DecoderSpecs;
/*     */ import jj2000.j2k.image.DataBlk;
/*     */ import jj2000.j2k.quantization.dequantizer.CBlkQuantDataSrcDec;
/*     */ import jj2000.j2k.wavelet.synthesis.MultiResImgData;
/*     */ import jj2000.j2k.wavelet.synthesis.MultiResImgDataAdapter;
/*     */ import jj2000.j2k.wavelet.synthesis.SubbandSyn;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ROIDeScaler
/*     */   extends MultiResImgDataAdapter
/*     */   implements CBlkQuantDataSrcDec
/*     */ {
/*     */   private MaxShiftSpec mss;
/*     */   public static final char OPT_PREFIX = 'R';
/* 124 */   private static final String[][] pinfo = new String[][] { { "Rno_roi", null, "This argument makes sure that the no ROI de-scaling is performed. Decompression is done like there is no ROI in the image", null } };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private CBlkQuantDataSrcDec src;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ROIDeScaler(CBlkQuantDataSrcDec src, MaxShiftSpec mss) {
/* 144 */     super((MultiResImgData)src);
/* 145 */     this.src = src;
/* 146 */     this.mss = mss;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SubbandSyn getSynSubbandTree(int t, int c) {
/* 164 */     return this.src.getSynSubbandTree(t, c);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getCbULX() {
/* 172 */     return this.src.getCbULX();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getCbULY() {
/* 180 */     return this.src.getCbULY();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[][] getParameterInfo() {
/* 197 */     return pinfo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DataBlk getCodeBlock(int c, int m, int n, SubbandSyn sb, DataBlk cblk) {
/* 245 */     return getInternCodeBlock(c, m, n, sb, cblk);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DataBlk getInternCodeBlock(int c, int m, int n, SubbandSyn sb, DataBlk cblk) {
/* 298 */     cblk = this.src.getInternCodeBlock(c, m, n, sb, cblk);
/*     */ 
/*     */     
/* 301 */     boolean noRoiInTile = false;
/* 302 */     if (this.mss == null || this.mss.getTileCompVal(getTileIdx(), c) == null) {
/* 303 */       noRoiInTile = true;
/*     */     }
/* 305 */     if (noRoiInTile || cblk == null) {
/* 306 */       return cblk;
/*     */     }
/* 308 */     int[] data = (int[])cblk.getData();
/* 309 */     int ulx = cblk.ulx;
/* 310 */     int uly = cblk.uly;
/* 311 */     int w = cblk.w;
/* 312 */     int h = cblk.h;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 317 */     int boost = ((Integer)this.mss.getTileCompVal(getTileIdx(), c)).intValue();
/* 318 */     int mask = (1 << sb.magbits) - 1 << 31 - sb.magbits;
/* 319 */     int mask2 = (mask ^ 0xFFFFFFFF) & Integer.MAX_VALUE;
/*     */     
/* 321 */     int wrap = cblk.scanw - w;
/* 322 */     int i = cblk.offset + cblk.scanw * (h - 1) + w - 1;
/* 323 */     for (int j = h; j > 0; j--) {
/* 324 */       for (int k = w; k > 0; k--, i--) {
/* 325 */         int tmp = data[i];
/* 326 */         if ((tmp & mask) == 0) {
/* 327 */           data[i] = tmp & Integer.MIN_VALUE | tmp << boost;
/*     */         
/*     */         }
/* 330 */         else if ((tmp & mask2) != 0) {
/*     */ 
/*     */ 
/*     */           
/* 334 */           data[i] = tmp & (mask2 ^ 0xFFFFFFFF) | 1 << 30 - sb.magbits;
/*     */         } 
/*     */       } 
/*     */       
/* 338 */       i -= wrap;
/*     */     } 
/* 340 */     return cblk;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ROIDeScaler createInstance(CBlkQuantDataSrcDec src, J2KImageReadParamJava j2krparam, DecoderSpecs decSpec) {
/* 361 */     boolean noRoi = j2krparam.getNoROIDescaling();
/* 362 */     if (noRoi || decSpec.rois == null)
/*     */     {
/* 364 */       return new ROIDeScaler(src, null);
/*     */     }
/*     */     
/* 367 */     return new ROIDeScaler(src, decSpec.rois);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/roi/ROIDeScaler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */