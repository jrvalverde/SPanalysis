/*     */ package jj2000.j2k.roi.encoder;
/*     */ 
/*     */ import jj2000.j2k.image.DataBlk;
/*     */ import jj2000.j2k.image.DataBlkInt;
/*     */ import jj2000.j2k.image.input.ImgReaderPGM;
/*     */ import jj2000.j2k.quantization.quantizer.Quantizer;
/*     */ import jj2000.j2k.wavelet.Subband;
/*     */ import jj2000.j2k.wavelet.WaveletFilter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ArbROIMaskGenerator
/*     */   extends ROIMaskGenerator
/*     */ {
/*     */   private Quantizer src;
/*     */   private int[][] roiMask;
/*     */   private int[] maskLineLow;
/*     */   private int[] maskLineHigh;
/*     */   private int[] paddedMaskLine;
/*     */   private boolean roiInTile;
/*     */   
/*     */   public ArbROIMaskGenerator(ROI[] rois, int nrc, Quantizer src) {
/* 136 */     super(rois, nrc);
/* 137 */     this.roiMask = new int[nrc][];
/* 138 */     this.src = src;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getROIMask(DataBlkInt db, Subband sb, int magbits, int c) {
/* 163 */     int x = db.ulx;
/* 164 */     int y = db.uly;
/* 165 */     int w = db.w;
/* 166 */     int h = db.h;
/* 167 */     int tilew = sb.w;
/* 168 */     int tileh = sb.h;
/* 169 */     int[] maskData = (int[])db.getData();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 174 */     if (!this.tileMaskMade[c]) {
/* 175 */       makeMask(sb, magbits, c);
/* 176 */       this.tileMaskMade[c] = true;
/*     */     } 
/* 178 */     if (!this.roiInTile) {
/* 179 */       return false;
/*     */     }
/* 181 */     int[] mask = this.roiMask[c];
/*     */ 
/*     */     
/* 184 */     int i = (y + h - 1) * tilew + x + w - 1;
/* 185 */     int bi = w * h - 1;
/* 186 */     int wrap = tilew - w;
/* 187 */     for (int j = h; j > 0; j--) {
/* 188 */       for (int k = w; k > 0; k--, i--, bi--) {
/* 189 */         maskData[bi] = mask[i];
/*     */       }
/* 191 */       i -= wrap;
/*     */     } 
/* 193 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 201 */     return "Fast rectangular ROI mask generator";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void makeMask(Subband sb, int magbits, int c) {
/*     */     int[] mask;
/* 218 */     ROI[] rois = this.rois;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 225 */     int tileulx = sb.ulcx;
/* 226 */     int tileuly = sb.ulcy;
/* 227 */     int tilew = sb.w;
/* 228 */     int tileh = sb.h;
/* 229 */     int lineLen = (tilew > tileh) ? tilew : tileh;
/*     */ 
/*     */     
/* 232 */     if (this.roiMask[c] == null || (this.roiMask[c]).length < tilew * tileh) {
/* 233 */       this.roiMask[c] = new int[tilew * tileh];
/* 234 */       mask = this.roiMask[c];
/*     */     } else {
/*     */       
/* 237 */       mask = this.roiMask[c];
/* 238 */       for (int i = tilew * tileh - 1; i >= 0; i--) {
/* 239 */         mask[i] = 0;
/*     */       }
/*     */     } 
/*     */     
/* 243 */     if (this.maskLineLow == null || this.maskLineLow.length < (lineLen + 1) / 2)
/* 244 */       this.maskLineLow = new int[(lineLen + 1) / 2]; 
/* 245 */     if (this.maskLineHigh == null || this.maskLineHigh.length < (lineLen + 1) / 2) {
/* 246 */       this.maskLineHigh = new int[(lineLen + 1) / 2];
/*     */     }
/* 248 */     this.roiInTile = false;
/*     */     
/* 250 */     for (int r = rois.length - 1; r >= 0; r--) {
/* 251 */       if ((rois[r]).comp == c) {
/* 252 */         int curScalVal = magbits;
/*     */         
/* 254 */         if ((rois[r]).arbShape) {
/* 255 */           ImgReaderPGM maskPGM = (rois[r]).maskPGM;
/*     */           
/* 257 */           if (this.src.getImgWidth() != maskPGM.getImgWidth() || this.src.getImgHeight() != maskPGM.getImgHeight())
/*     */           {
/* 259 */             throw new IllegalArgumentException("Input image and ROI mask must have the same size");
/*     */           }
/*     */ 
/*     */           
/* 263 */           int x = this.src.getImgULX();
/* 264 */           int y = this.src.getImgULY();
/* 265 */           int lrx = x + this.src.getImgWidth() - 1;
/* 266 */           int lry = y + this.src.getImgHeight() - 1;
/* 267 */           if (x <= tileulx + tilew && y <= tileuly + tileh && lrx >= tileulx && lry >= tileuly) {
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 272 */             x -= tileulx;
/* 273 */             lrx -= tileulx;
/* 274 */             y -= tileuly;
/* 275 */             lry -= tileuly;
/*     */             
/* 277 */             int offx = 0;
/* 278 */             int offy = 0;
/* 279 */             if (x < 0) {
/* 280 */               offx = -x;
/* 281 */               x = 0;
/*     */             } 
/* 283 */             if (y < 0) {
/* 284 */               offy = -y;
/* 285 */               y = 0;
/*     */             } 
/* 287 */             int w = (lrx > tilew - 1) ? (tilew - x) : (lrx + 1 - x);
/* 288 */             int h = (lry > tileh - 1) ? (tileh - y) : (lry + 1 - y);
/*     */ 
/*     */ 
/*     */             
/* 292 */             DataBlkInt srcblk = new DataBlkInt();
/* 293 */             int mDcOff = -ImgReaderPGM.DC_OFFSET;
/* 294 */             int nROIcoeff = 0;
/*     */             
/* 296 */             srcblk.ulx = offx;
/* 297 */             srcblk.w = w;
/* 298 */             srcblk.h = 1;
/*     */             
/* 300 */             int i = (y + h - 1) * tilew + x + w - 1;
/* 301 */             int maxj = w;
/* 302 */             int wrap = tilew - maxj;
/* 303 */             for (int k = h; k > 0; k--) {
/* 304 */               srcblk.uly = offy + k - 1;
/* 305 */               srcblk = (DataBlkInt)maskPGM.getInternCompData((DataBlk)srcblk, 0);
/*     */               
/* 307 */               int[] src_data = srcblk.getDataInt();
/*     */               
/* 309 */               for (int j = maxj; j > 0; j--, i--) {
/* 310 */                 if (src_data[j - 1] != mDcOff) {
/* 311 */                   mask[i] = curScalVal;
/* 312 */                   nROIcoeff++;
/*     */                 } 
/*     */               } 
/* 315 */               i -= wrap;
/*     */             } 
/*     */             
/* 318 */             if (nROIcoeff != 0) {
/* 319 */               this.roiInTile = true;
/*     */             }
/*     */           } 
/* 322 */         } else if ((rois[r]).rect) {
/* 323 */           int x = (rois[r]).ulx;
/* 324 */           int y = (rois[r]).uly;
/* 325 */           int lrx = (rois[r]).w + x - 1;
/* 326 */           int lry = (rois[r]).h + y - 1;
/*     */           
/* 328 */           if (x <= tileulx + tilew && y <= tileuly + tileh && lrx >= tileulx && lry >= tileuly) {
/*     */ 
/*     */ 
/*     */             
/* 332 */             this.roiInTile = true;
/*     */ 
/*     */             
/* 335 */             x -= tileulx;
/* 336 */             lrx -= tileulx;
/* 337 */             y -= tileuly;
/* 338 */             lry -= tileuly;
/*     */             
/* 340 */             x = (x < 0) ? 0 : x;
/* 341 */             y = (y < 0) ? 0 : y;
/* 342 */             int w = (lrx > tilew - 1) ? (tilew - x) : (lrx + 1 - x);
/* 343 */             int h = (lry > tileh - 1) ? (tileh - y) : (lry + 1 - y);
/*     */             
/* 345 */             int i = (y + h - 1) * tilew + x + w - 1;
/* 346 */             int maxj = w;
/* 347 */             int wrap = tilew - maxj;
/* 348 */             for (int k = h; k > 0; k--) {
/* 349 */               for (int j = maxj; j > 0; j--, i--) {
/* 350 */                 mask[i] = curScalVal;
/*     */               }
/* 352 */               i -= wrap;
/*     */             } 
/*     */           } 
/*     */         } else {
/* 356 */           int cx = (rois[r]).x - tileulx;
/* 357 */           int cy = (rois[r]).y - tileuly;
/* 358 */           int rad = (rois[r]).r;
/* 359 */           int i = tileh * tilew - 1;
/* 360 */           for (int k = tileh - 1; k >= 0; k--) {
/* 361 */             for (int j = tilew - 1; j >= 0; j--, i--) {
/* 362 */               if ((j - cx) * (j - cx) + (k - cy) * (k - cy) < rad * rad) {
/* 363 */                 mask[i] = curScalVal;
/* 364 */                 this.roiInTile = true;
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 373 */     if (sb.isNode) {
/*     */ 
/*     */       
/* 376 */       WaveletFilter vFilter = sb.getVerWFilter();
/* 377 */       WaveletFilter hFilter = sb.getHorWFilter();
/* 378 */       int lvsup = vFilter.getSynLowNegSupport() + vFilter.getSynLowPosSupport();
/*     */       
/* 380 */       int hvsup = vFilter.getSynHighNegSupport() + vFilter.getSynHighPosSupport();
/*     */       
/* 382 */       int lhsup = hFilter.getSynLowNegSupport() + hFilter.getSynLowPosSupport();
/*     */       
/* 384 */       int hhsup = hFilter.getSynHighNegSupport() + hFilter.getSynHighPosSupport();
/*     */       
/* 386 */       lvsup = (lvsup > hvsup) ? lvsup : hvsup;
/* 387 */       lhsup = (lhsup > hhsup) ? lhsup : hhsup;
/* 388 */       lvsup = (lvsup > lhsup) ? lvsup : lhsup;
/* 389 */       this.paddedMaskLine = new int[lineLen + lvsup];
/*     */       
/* 391 */       if (this.roiInTile) {
/* 392 */         decomp(sb, tilew, tileh, c);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void decomp(Subband sb, int tilew, int tileh, int c) {
/* 411 */     int hmax, lmax, ulx = sb.ulx;
/* 412 */     int uly = sb.uly;
/* 413 */     int w = sb.w;
/* 414 */     int h = sb.h;
/* 415 */     int maxVal = 0;
/* 416 */     int mi = 0;
/*     */ 
/*     */     
/* 419 */     int[] mask = this.roiMask[c];
/* 420 */     int[] low = this.maskLineLow;
/* 421 */     int[] high = this.maskLineHigh;
/* 422 */     int[] padLine = this.paddedMaskLine;
/* 423 */     int highFirst = 0;
/*     */ 
/*     */ 
/*     */     
/* 427 */     if (!sb.isNode) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 434 */     WaveletFilter filter = sb.getHorWFilter();
/* 435 */     int lnSup = filter.getSynLowNegSupport();
/* 436 */     int hnSup = filter.getSynHighNegSupport();
/* 437 */     int lpSup = filter.getSynLowPosSupport();
/* 438 */     int hpSup = filter.getSynHighPosSupport();
/* 439 */     int lsup = lnSup + lpSup + 1;
/* 440 */     int hsup = hnSup + hpSup + 1;
/*     */ 
/*     */     
/* 443 */     highFirst = sb.ulcx % 2;
/* 444 */     if (sb.w % 2 == 0) {
/* 445 */       lmax = w / 2 - 1;
/* 446 */       hmax = lmax;
/*     */     
/*     */     }
/* 449 */     else if (highFirst == 0) {
/* 450 */       lmax = (w + 1) / 2 - 1;
/* 451 */       hmax = w / 2 - 1;
/*     */     } else {
/*     */       
/* 454 */       hmax = (w + 1) / 2 - 1;
/* 455 */       lmax = w / 2 - 1;
/*     */     } 
/*     */ 
/*     */     
/* 459 */     int maxnSup = (lnSup > hnSup) ? lnSup : hnSup;
/* 460 */     int maxpSup = (lpSup > hpSup) ? lpSup : hpSup;
/*     */     
/*     */     int pin;
/*     */     
/* 464 */     for (pin = maxnSup - 1; pin >= 0; pin--)
/* 465 */       padLine[pin] = 0; 
/* 466 */     for (pin = maxnSup + w - 1 + maxpSup; pin >= w; pin--) {
/* 467 */       padLine[pin] = 0;
/*     */     }
/*     */     
/* 470 */     int lineoffs = (uly + h) * tilew + ulx + w - 1; int j;
/* 471 */     for (j = h - 1; j >= 0; j--) {
/* 472 */       lineoffs -= tilew;
/*     */       
/* 474 */       mi = lineoffs; int k;
/* 475 */       for (k = w, pin = w - 1 + maxnSup; k > 0; k--, mi--, pin--) {
/* 476 */         padLine[pin] = mask[mi];
/*     */       }
/*     */       
/* 479 */       int lastpin = maxnSup + highFirst + 2 * lmax + lpSup;
/* 480 */       for (k = lmax; k >= 0; k--, lastpin -= 2) {
/* 481 */         pin = lastpin;
/* 482 */         for (int s = lsup; s > 0; s--, pin--) {
/* 483 */           int scalVal = padLine[pin];
/* 484 */           if (scalVal > maxVal)
/* 485 */             maxVal = scalVal; 
/*     */         } 
/* 487 */         low[k] = maxVal;
/* 488 */         maxVal = 0;
/*     */       } 
/* 490 */       lastpin = maxnSup - highFirst + 2 * hmax + 1 + hpSup;
/* 491 */       for (k = hmax; k >= 0; k--, lastpin -= 2) {
/* 492 */         pin = lastpin;
/* 493 */         for (int s = hsup; s > 0; s--, pin--) {
/* 494 */           int scalVal = padLine[pin];
/* 495 */           if (scalVal > maxVal)
/* 496 */             maxVal = scalVal; 
/*     */         } 
/* 498 */         high[k] = maxVal;
/* 499 */         maxVal = 0;
/*     */       } 
/*     */       
/* 502 */       mi = lineoffs;
/* 503 */       for (k = hmax; k >= 0; k--, mi--) {
/* 504 */         mask[mi] = high[k];
/*     */       }
/* 506 */       for (k = lmax; k >= 0; k--, mi--) {
/* 507 */         mask[mi] = low[k];
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 515 */     filter = sb.getVerWFilter();
/* 516 */     lnSup = filter.getSynLowNegSupport();
/* 517 */     hnSup = filter.getSynHighNegSupport();
/* 518 */     lpSup = filter.getSynLowPosSupport();
/* 519 */     hpSup = filter.getSynHighPosSupport();
/* 520 */     lsup = lnSup + lpSup + 1;
/* 521 */     hsup = hnSup + hpSup + 1;
/*     */ 
/*     */     
/* 524 */     highFirst = sb.ulcy % 2;
/* 525 */     if (sb.h % 2 == 0) {
/* 526 */       lmax = h / 2 - 1;
/* 527 */       hmax = lmax;
/*     */     
/*     */     }
/* 530 */     else if (sb.ulcy % 2 == 0) {
/* 531 */       lmax = (h + 1) / 2 - 1;
/* 532 */       hmax = h / 2 - 1;
/*     */     } else {
/*     */       
/* 535 */       hmax = (h + 1) / 2 - 1;
/* 536 */       lmax = h / 2 - 1;
/*     */     } 
/*     */ 
/*     */     
/* 540 */     maxnSup = (lnSup > hnSup) ? lnSup : hnSup;
/* 541 */     maxpSup = (lpSup > hpSup) ? lpSup : hpSup;
/*     */ 
/*     */     
/* 544 */     for (pin = maxnSup - 1; pin >= 0; pin--)
/* 545 */       padLine[pin] = 0; 
/* 546 */     for (pin = maxnSup + h - 1 + maxpSup; pin >= h; pin--) {
/* 547 */       padLine[pin] = 0;
/*     */     }
/*     */     
/* 550 */     lineoffs = (uly + h - 1) * tilew + ulx + w;
/* 551 */     for (j = w - 1; j >= 0; j--) {
/*     */ 
/*     */       
/* 554 */       mi = --lineoffs; int k;
/* 555 */       for (k = h, pin = k - 1 + maxnSup; k > 0; k--, mi -= tilew, pin--) {
/* 556 */         padLine[pin] = mask[mi];
/*     */       }
/* 558 */       int lastpin = maxnSup + highFirst + 2 * lmax + lpSup;
/* 559 */       for (k = lmax; k >= 0; k--, lastpin -= 2) {
/* 560 */         pin = lastpin;
/* 561 */         for (int s = lsup; s > 0; s--, pin--) {
/* 562 */           int scalVal = padLine[pin];
/* 563 */           if (scalVal > maxVal)
/* 564 */             maxVal = scalVal; 
/*     */         } 
/* 566 */         low[k] = maxVal;
/* 567 */         maxVal = 0;
/*     */       } 
/* 569 */       lastpin = maxnSup - highFirst + 2 * hmax + 1 + hpSup;
/* 570 */       for (k = hmax; k >= 0; k--, lastpin -= 2) {
/* 571 */         pin = lastpin;
/* 572 */         for (int s = hsup; s > 0; s--, pin--) {
/* 573 */           int scalVal = padLine[pin];
/* 574 */           if (scalVal > maxVal)
/* 575 */             maxVal = scalVal; 
/*     */         } 
/* 577 */         high[k] = maxVal;
/* 578 */         maxVal = 0;
/*     */       } 
/*     */       
/* 581 */       mi = lineoffs;
/* 582 */       for (k = hmax; k >= 0; k--, mi -= tilew) {
/* 583 */         mask[mi] = high[k];
/*     */       }
/* 585 */       for (k = lmax; k >= 0; k--, mi -= tilew) {
/* 586 */         mask[mi] = low[k];
/*     */       }
/*     */     } 
/*     */     
/* 590 */     if (sb.isNode) {
/* 591 */       decomp(sb.getHH(), tilew, tileh, c);
/* 592 */       decomp(sb.getLH(), tilew, tileh, c);
/* 593 */       decomp(sb.getHL(), tilew, tileh, c);
/* 594 */       decomp(sb.getLL(), tilew, tileh, c);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/roi/encoder/ArbROIMaskGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */