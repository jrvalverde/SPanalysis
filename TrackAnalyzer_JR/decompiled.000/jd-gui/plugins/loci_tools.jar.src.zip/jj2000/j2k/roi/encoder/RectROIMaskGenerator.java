/*     */ package jj2000.j2k.roi.encoder;
/*     */ 
/*     */ import jj2000.j2k.image.DataBlkInt;
/*     */ import jj2000.j2k.wavelet.Subband;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RectROIMaskGenerator
/*     */   extends ROIMaskGenerator
/*     */ {
/*     */   private int[] ulxs;
/*     */   private int[] ulys;
/*     */   private int[] lrxs;
/*     */   private int[] lrys;
/*     */   private int[] nrROIs;
/*     */   private SubbandRectROIMask[] sMasks;
/*     */   
/*     */   public RectROIMaskGenerator(ROI[] ROIs, int nrc) {
/* 144 */     super(ROIs, nrc);
/* 145 */     int nr = ROIs.length;
/*     */     
/* 147 */     this.nrROIs = new int[nrc];
/* 148 */     this.sMasks = new SubbandRectROIMask[nrc];
/*     */ 
/*     */     
/* 151 */     for (int r = nr - 1; r >= 0; r--) {
/* 152 */       this.nrROIs[(ROIs[r]).comp] = this.nrROIs[(ROIs[r]).comp] + 1;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getROIMask(DataBlkInt db, Subband sb, int magbits, int c) {
/* 177 */     int x = db.ulx;
/* 178 */     int y = db.uly;
/* 179 */     int w = db.w;
/* 180 */     int h = db.h;
/* 181 */     int[] mask = db.getDataInt();
/*     */     
/* 183 */     int ulx = 0, uly = 0, lrx = 0, lry = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 194 */     if (!this.tileMaskMade[c]) {
/* 195 */       makeMask(sb, magbits, c);
/* 196 */       this.tileMaskMade[c] = true;
/*     */     } 
/*     */     
/* 199 */     if (!this.roiInTile) {
/* 200 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 204 */     SubbandRectROIMask srm = (SubbandRectROIMask)this.sMasks[c].getSubbandRectROIMask(x, y);
/* 205 */     int[] culxs = srm.ulxs;
/* 206 */     int[] culys = srm.ulys;
/* 207 */     int[] clrxs = srm.lrxs;
/* 208 */     int[] clrys = srm.lrys;
/* 209 */     int maxROI = culxs.length - 1;
/*     */ 
/*     */ 
/*     */     
/* 213 */     x -= srm.ulx;
/* 214 */     y -= srm.uly;
/* 215 */     for (int r = maxROI; r >= 0; r--) {
/* 216 */       ulx = culxs[r] - x;
/* 217 */       if (ulx < 0) {
/* 218 */         ulx = 0;
/* 219 */       } else if (ulx >= w) {
/* 220 */         ulx = w;
/*     */       } 
/*     */       
/* 223 */       uly = culys[r] - y;
/* 224 */       if (uly < 0) {
/* 225 */         uly = 0;
/* 226 */       } else if (uly >= h) {
/* 227 */         uly = h;
/*     */       } 
/*     */       
/* 230 */       lrx = clrxs[r] - x;
/* 231 */       if (lrx < 0) {
/* 232 */         lrx = -1;
/* 233 */       } else if (lrx >= w) {
/* 234 */         lrx = w - 1;
/*     */       } 
/*     */       
/* 237 */       lry = clrys[r] - y;
/* 238 */       if (lry < 0) {
/* 239 */         lry = -1;
/* 240 */       } else if (lry >= h) {
/* 241 */         lry = h - 1;
/*     */       } 
/*     */ 
/*     */       
/* 245 */       int i = w * lry + lrx;
/* 246 */       int maxj = lrx - ulx;
/* 247 */       int wrap = w - maxj - 1;
/* 248 */       int maxk = lry - uly;
/*     */       
/* 250 */       for (int k = maxk; k >= 0; k--) {
/* 251 */         for (int j = maxj; j >= 0; j--, i--)
/* 252 */           mask[i] = magbits; 
/* 253 */         i -= wrap;
/*     */       } 
/*     */     } 
/* 256 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 263 */     return "Fast rectangular ROI mask generator";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void makeMask(Subband sb, int magbits, int n) {
/* 276 */     int nr = this.nrROIs[n];
/*     */ 
/*     */     
/* 279 */     int tileulx = sb.ulcx;
/* 280 */     int tileuly = sb.ulcy;
/* 281 */     int tilew = sb.w;
/* 282 */     int tileh = sb.h;
/* 283 */     ROI[] ROIs = this.rois;
/*     */     
/* 285 */     this.ulxs = new int[nr];
/* 286 */     this.ulys = new int[nr];
/* 287 */     this.lrxs = new int[nr];
/* 288 */     this.lrys = new int[nr];
/*     */     
/* 290 */     nr = 0;
/*     */     
/* 292 */     for (int r = ROIs.length - 1; r >= 0; r--) {
/* 293 */       if ((ROIs[r]).comp == n) {
/* 294 */         int ulx = (ROIs[r]).ulx;
/* 295 */         int uly = (ROIs[r]).uly;
/* 296 */         int lrx = (ROIs[r]).w + ulx - 1;
/* 297 */         int lry = (ROIs[r]).h + uly - 1;
/*     */         
/* 299 */         if (ulx <= tileulx + tilew - 1 && uly <= tileuly + tileh - 1 && lrx >= tileulx && lry >= tileuly) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 305 */           ulx -= tileulx;
/* 306 */           lrx -= tileulx;
/* 307 */           uly -= tileuly;
/* 308 */           lry -= tileuly;
/*     */           
/* 310 */           ulx = (ulx < 0) ? 0 : ulx;
/* 311 */           uly = (uly < 0) ? 0 : uly;
/* 312 */           lrx = (lrx > tilew - 1) ? (tilew - 1) : lrx;
/* 313 */           lry = (lry > tileh - 1) ? (tileh - 1) : lry;
/*     */           
/* 315 */           this.ulxs[nr] = ulx;
/* 316 */           this.ulys[nr] = uly;
/* 317 */           this.lrxs[nr] = lrx;
/* 318 */           this.lrys[nr] = lry;
/* 319 */           nr++;
/*     */         } 
/*     */       } 
/* 322 */     }  if (nr == 0) {
/* 323 */       this.roiInTile = false;
/*     */     } else {
/*     */       
/* 326 */       this.roiInTile = true;
/*     */     } 
/* 328 */     this.sMasks[n] = new SubbandRectROIMask(sb, this.ulxs, this.ulys, this.lrxs, this.lrys, nr);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/roi/encoder/RectROIMaskGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */