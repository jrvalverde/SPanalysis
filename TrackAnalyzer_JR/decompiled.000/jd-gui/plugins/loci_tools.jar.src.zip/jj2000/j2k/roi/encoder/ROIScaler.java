/*     */ package jj2000.j2k.roi.encoder;
/*     */ 
/*     */ import com.sun.media.imageioimpl.plugins.jpeg2000.J2KImageWriteParamJava;
/*     */ import java.io.IOException;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.Vector;
/*     */ import jj2000.j2k.ModuleSpec;
/*     */ import jj2000.j2k.image.DataBlkInt;
/*     */ import jj2000.j2k.image.ImgData;
/*     */ import jj2000.j2k.image.ImgDataAdapter;
/*     */ import jj2000.j2k.image.input.ImgReaderPGM;
/*     */ import jj2000.j2k.quantization.quantizer.CBlkQuantDataSrcEnc;
/*     */ import jj2000.j2k.quantization.quantizer.Quantizer;
/*     */ import jj2000.j2k.roi.MaxShiftSpec;
/*     */ import jj2000.j2k.wavelet.Subband;
/*     */ import jj2000.j2k.wavelet.analysis.CBlkWTData;
/*     */ import jj2000.j2k.wavelet.analysis.SubbandAn;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ROIScaler
/*     */   extends ImgDataAdapter
/*     */   implements CBlkQuantDataSrcEnc
/*     */ {
/*     */   public static final char OPT_PREFIX = 'R';
/* 122 */   private static final String[][] pinfo = new String[][] { { "Rroi", "[<component idx>] R <left> <top> <width> <height> or [<component idx>] C <centre column> <centre row> <radius> or [<component idx>] A <filename>", "Specifies ROIs shape and location. The shape can be either rectangular 'R', or circular 'C' or arbitrary 'A'. Each new occurrence of an 'R', a 'C' or an 'A' is a new ROI. For circular and rectangular ROIs, all values are given as their pixel values relative to the canvas origin. Arbitrary shapes must be included in a PGM file where non 0 values correspond to ROI coefficients. The PGM file must have the size as the image. The component idx specifies which components contain the ROI. The component index is specified as described by points 3 and 4 in the general comment on tile-component idx. If this option is used, the codestream is layer progressive by default unless it is overridden by the 'Aptype' option.", null }, { "Ralign", "[true|false]", "By specifying this argument, the ROI mask will be limited to covering only entire code-blocks. The ROI coding can then be performed without any actual scaling of the coefficients but by instead scaling the distortion estimates.", "false" }, { "Rstart_level", "<level>", "This argument forces the lowest <level> resolution levels to belong to the ROI. By doing this, it is possible to avoid only getting information for the ROI at an early stage of transmission.<level> = 0 means the lowest resolution level belongs to the ROI, 1 means the two lowest etc. (-1 deactivates the option)", "-1" }, { "Rno_rect", "[true|false]", "This argument makes sure that the ROI mask generation is not done using the fast ROI mask generation for rectangular ROIs regardless of whether the specified ROIs are rectangular or not", "false" } };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int[][] maxMagBits;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean roi;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean blockAligned;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int useStartLevel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ROIMaskGenerator mg;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private DataBlkInt roiMask;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Quantizer src;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ROIScaler(Quantizer src, ROIMaskGenerator mg, boolean roi, int sLev, boolean uba, J2KImageWriteParamJava wp) {
/* 203 */     super((ImgData)src);
/* 204 */     this.src = src;
/* 205 */     this.roi = roi;
/* 206 */     this.useStartLevel = sLev;
/* 207 */     if (roi) {
/*     */       
/* 209 */       this.mg = mg;
/* 210 */       this.roiMask = new DataBlkInt();
/* 211 */       calcMaxMagBits(wp);
/* 212 */       this.blockAligned = uba;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isReversible(int t, int c) {
/* 227 */     return this.src.isReversible(t, c);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SubbandAn getAnSubbandTree(int t, int c) {
/* 245 */     return this.src.getAnSubbandTree(t, c);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getCbULX() {
/* 253 */     return this.src.getCbULX();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getCbULY() {
/* 261 */     return this.src.getCbULY();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ROIScaler createInstance(Quantizer src, J2KImageWriteParamJava wp) {
/* 283 */     Vector roiVector = new Vector();
/* 284 */     ROIMaskGenerator maskGen = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 292 */     String roiopt = wp.getROIs().getSpecified();
/* 293 */     if (roiopt == null)
/*     */     {
/* 295 */       return new ROIScaler(src, null, false, -1, false, wp);
/*     */     }
/*     */ 
/*     */     
/* 299 */     int sLev = wp.getStartLevelROI();
/*     */ 
/*     */     
/* 302 */     boolean useBlockAligned = wp.getAlignROI();
/*     */ 
/*     */     
/* 305 */     boolean onlyRect = false;
/*     */ 
/*     */     
/* 308 */     parseROIs(roiopt, src.getNumComps(), roiVector);
/* 309 */     ROI[] roiArray = new ROI[roiVector.size()];
/* 310 */     roiVector.copyInto((Object[])roiArray);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 315 */     if (onlyRect) {
/* 316 */       for (int i = roiArray.length - 1; i >= 0; i--) {
/* 317 */         if (!(roiArray[i]).rect) {
/* 318 */           onlyRect = false;
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     }
/* 323 */     if (onlyRect) {
/*     */ 
/*     */       
/* 326 */       maskGen = new RectROIMaskGenerator(roiArray, src.getNumComps());
/*     */     }
/*     */     else {
/*     */       
/* 330 */       maskGen = new ArbROIMaskGenerator(roiArray, src.getNumComps(), src);
/*     */     } 
/*     */     
/* 333 */     return new ROIScaler(src, maskGen, true, sLev, useBlockAligned, wp);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static Vector parseROIs(String roiopt, int nc, Vector<ROI> roiVector) {
/* 362 */     int nrOfROIs = 0;
/*     */ 
/*     */     
/* 365 */     boolean[] roiInComp = null;
/*     */     
/* 367 */     StringTokenizer stok = new StringTokenizer(roiopt);
/*     */ 
/*     */     
/* 370 */     while (stok.hasMoreTokens()) {
/* 371 */       int ulx, uly, w, h, x, y, rad, i; String filename; ImgReaderPGM maskPGM; int j; String word = stok.nextToken();
/*     */       
/* 373 */       switch (word.charAt(0)) {
/*     */         case 'c':
/* 375 */           roiInComp = ModuleSpec.parseIdx(word, nc);
/*     */           continue;
/*     */         case 'R':
/* 378 */           nrOfROIs++;
/*     */           try {
/* 380 */             word = stok.nextToken();
/* 381 */             ulx = (new Integer(word)).intValue();
/* 382 */             word = stok.nextToken();
/* 383 */             uly = (new Integer(word)).intValue();
/* 384 */             word = stok.nextToken();
/* 385 */             w = (new Integer(word)).intValue();
/* 386 */             word = stok.nextToken();
/* 387 */             h = (new Integer(word)).intValue();
/*     */           }
/* 389 */           catch (NumberFormatException e) {
/* 390 */             throw new IllegalArgumentException("Bad parameter for '-Rroi R' option : " + word);
/*     */ 
/*     */           
/*     */           }
/* 394 */           catch (NoSuchElementException f) {
/* 395 */             throw new IllegalArgumentException("Wrong number of parameters for  h'-Rroi R' option.");
/*     */           } 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 401 */           if (roiInComp != null) {
/* 402 */             for (int k = 0; k < nc; k++) {
/* 403 */               if (roiInComp[k]) {
/* 404 */                 ROI roi = new ROI(k, ulx, uly, w, h);
/* 405 */                 roiVector.addElement(roi);
/*     */               } 
/*     */             }  continue;
/*     */           } 
/* 409 */           for (i = 0; i < nc; i++) {
/* 410 */             ROI roi = new ROI(i, ulx, uly, w, h);
/* 411 */             roiVector.addElement(roi);
/*     */           } 
/*     */           continue;
/*     */         
/*     */         case 'C':
/* 416 */           nrOfROIs++;
/*     */           
/*     */           try {
/* 419 */             word = stok.nextToken();
/* 420 */             x = (new Integer(word)).intValue();
/* 421 */             word = stok.nextToken();
/* 422 */             y = (new Integer(word)).intValue();
/* 423 */             word = stok.nextToken();
/* 424 */             rad = (new Integer(word)).intValue();
/*     */           }
/* 426 */           catch (NumberFormatException e) {
/* 427 */             throw new IllegalArgumentException("Bad parameter for '-Rroi C' option : " + word);
/*     */ 
/*     */           
/*     */           }
/* 431 */           catch (NoSuchElementException f) {
/* 432 */             throw new IllegalArgumentException("Wrong number of parameters for '-Rroi C' option.");
/*     */           } 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 438 */           if (roiInComp != null) {
/* 439 */             for (i = 0; i < nc; i++) {
/* 440 */               if (roiInComp[i]) {
/* 441 */                 ROI roi = new ROI(i, x, y, rad);
/* 442 */                 roiVector.addElement(roi);
/*     */               } 
/*     */             }  continue;
/*     */           } 
/* 446 */           for (i = 0; i < nc; i++) {
/* 447 */             ROI roi = new ROI(i, x, y, rad);
/* 448 */             roiVector.addElement(roi);
/*     */           } 
/*     */           continue;
/*     */         
/*     */         case 'A':
/* 453 */           nrOfROIs++;
/*     */ 
/*     */           
/* 456 */           maskPGM = null;
/*     */           
/*     */           try {
/* 459 */             filename = stok.nextToken();
/*     */           }
/* 461 */           catch (NoSuchElementException e) {
/* 462 */             throw new IllegalArgumentException("Wrong number of parameters for '-Rroi A' option.");
/*     */           } 
/*     */ 
/*     */           
/*     */           try {
/* 467 */             maskPGM = new ImgReaderPGM(filename);
/*     */           }
/* 469 */           catch (IOException e) {
/* 470 */             throw new Error("Cannot read PGM file with ROI");
/*     */           } 
/*     */ 
/*     */           
/* 474 */           if (roiInComp != null) {
/* 475 */             for (int k = 0; k < nc; k++) {
/* 476 */               if (roiInComp[k]) {
/* 477 */                 ROI roi = new ROI(k, maskPGM);
/* 478 */                 roiVector.addElement(roi);
/*     */               } 
/*     */             }  continue;
/*     */           } 
/* 482 */           for (j = 0; j < nc; j++) {
/* 483 */             ROI roi = new ROI(j, maskPGM);
/* 484 */             roiVector.addElement(roi);
/*     */           } 
/*     */           continue;
/*     */       } 
/*     */       
/* 489 */       throw new Error("Bad parameters for ROI nr " + roiVector.size());
/*     */     } 
/*     */ 
/*     */     
/* 493 */     return roiVector;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CBlkWTData getNextCodeBlock(int n, CBlkWTData cblk) {
/* 522 */     return getNextInternCodeBlock(n, cblk);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CBlkWTData getNextInternCodeBlock(int c, CBlkWTData cblk) {
/* 548 */     DataBlkInt mask = this.roiMask;
/*     */ 
/*     */ 
/*     */     
/* 552 */     int bitMask = Integer.MAX_VALUE;
/*     */     
/* 554 */     int maxBits = 0;
/*     */ 
/*     */     
/* 557 */     int nROIcoeff = 0;
/*     */ 
/*     */     
/* 560 */     cblk = this.src.getNextCodeBlock(c, cblk);
/*     */ 
/*     */ 
/*     */     
/* 564 */     if (!this.roi || cblk == null) {
/* 565 */       return cblk;
/*     */     }
/*     */     
/* 568 */     int[] data = (int[])cblk.getData();
/* 569 */     SubbandAn sb = cblk.sb;
/* 570 */     int ulx = cblk.ulx;
/* 571 */     int uly = cblk.uly;
/* 572 */     int w = cblk.w;
/* 573 */     int h = cblk.h;
/* 574 */     boolean sbInMask = (sb.resLvl <= this.useStartLevel);
/*     */ 
/*     */     
/* 577 */     int[] maskData = mask.getDataInt();
/* 578 */     if (maskData == null || w * h > maskData.length) {
/* 579 */       maskData = new int[w * h];
/* 580 */       mask.setDataInt(maskData);
/*     */     } else {
/*     */       
/* 583 */       for (int k = w * h - 1; k >= 0; k--)
/* 584 */         maskData[k] = 0; 
/*     */     } 
/* 586 */     mask.ulx = ulx;
/* 587 */     mask.uly = uly;
/* 588 */     mask.w = w;
/* 589 */     mask.h = h;
/*     */ 
/*     */     
/* 592 */     SubbandAn root = this.src.getAnSubbandTree(this.tIdx, c);
/* 593 */     maxBits = this.maxMagBits[this.tIdx][c];
/* 594 */     boolean roiInTile = this.mg.getROIMask(mask, (Subband)root, maxBits, c);
/*     */ 
/*     */     
/* 597 */     if (!roiInTile && !sbInMask) {
/* 598 */       cblk.nROIbp = 0;
/* 599 */       return cblk;
/*     */     } 
/*     */ 
/*     */     
/* 603 */     cblk.nROIbp = cblk.magbits;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 608 */     if (sbInMask) {
/*     */ 
/*     */       
/* 611 */       cblk.wmseScaling *= (1 << maxBits << 1);
/* 612 */       cblk.nROIcoeff = w * h;
/* 613 */       return cblk;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 619 */     if (this.blockAligned) {
/* 620 */       int i1 = cblk.scanw - w;
/* 621 */       int k = h * w - 1;
/* 622 */       int m = cblk.offset + cblk.scanw * (h - 1) + w - 1;
/* 623 */       int nroicoeff = 0;
/* 624 */       for (int n = h; n > 0; n--) {
/* 625 */         for (int i2 = w - 1; i2 >= 0; i2--, m--, k--) {
/* 626 */           if (maskData[k] != 0) {
/* 627 */             nroicoeff++;
/*     */           }
/*     */         } 
/* 630 */         m -= i1;
/*     */       } 
/* 632 */       if (nroicoeff != 0) {
/* 633 */         cblk.wmseScaling *= (1 << maxBits << 1);
/* 634 */         cblk.nROIcoeff = w * h;
/*     */       } 
/* 636 */       return cblk;
/*     */     } 
/*     */ 
/*     */     
/* 640 */     bitMask = (1 << cblk.magbits) - 1 << 31 - cblk.magbits;
/* 641 */     int wrap = cblk.scanw - w;
/* 642 */     int mi = h * w - 1;
/* 643 */     int i = cblk.offset + cblk.scanw * (h - 1) + w - 1;
/* 644 */     for (int j = h; j > 0; j--) {
/* 645 */       for (int k = w; k > 0; k--, i--, mi--) {
/* 646 */         int tmp = data[i];
/* 647 */         if (maskData[mi] != 0) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 656 */           data[i] = Integer.MIN_VALUE & tmp | tmp & bitMask;
/* 657 */           nROIcoeff++;
/*     */         }
/*     */         else {
/*     */           
/* 661 */           data[i] = Integer.MIN_VALUE & tmp | (tmp & Integer.MAX_VALUE) >> maxBits;
/*     */         } 
/*     */       } 
/*     */       
/* 665 */       i -= wrap;
/*     */     } 
/*     */ 
/*     */     
/* 669 */     cblk.magbits += maxBits;
/*     */ 
/*     */     
/* 672 */     cblk.nROIcoeff = nROIcoeff;
/*     */     
/* 674 */     return cblk;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ROIMaskGenerator getROIMaskGenerator() {
/* 683 */     return this.mg;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getBlockAligned() {
/* 692 */     return this.blockAligned;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean useRoi() {
/* 701 */     return this.roi;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[][] getParameterInfo() {
/* 719 */     return pinfo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTile(int x, int y) {
/* 732 */     super.setTile(x, y);
/* 733 */     if (this.roi) {
/* 734 */       this.mg.tileChanged();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void nextTile() {
/* 743 */     super.nextTile();
/* 744 */     if (this.roi) {
/* 745 */       this.mg.tileChanged();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void calcMaxMagBits(J2KImageWriteParamJava wp) {
/* 757 */     MaxShiftSpec rois = wp.getROIs();
/*     */     
/* 759 */     int nt = this.src.getNumTiles();
/* 760 */     int nc = this.src.getNumComps();
/*     */     
/* 762 */     this.maxMagBits = new int[nt][nc];
/*     */     
/* 764 */     this.src.setTile(0, 0);
/* 765 */     for (int t = 0; t < nt; t++) {
/* 766 */       for (int c = nc - 1; c >= 0; c--) {
/* 767 */         int tmp = this.src.getMaxMagBits(c);
/* 768 */         this.maxMagBits[t][c] = tmp;
/* 769 */         rois.setTileCompVal(t, c, new Integer(tmp));
/*     */       } 
/* 771 */       if (t < nt - 1) this.src.nextTile();
/*     */     
/*     */     } 
/* 774 */     this.src.setTile(0, 0);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/roi/encoder/ROIScaler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */