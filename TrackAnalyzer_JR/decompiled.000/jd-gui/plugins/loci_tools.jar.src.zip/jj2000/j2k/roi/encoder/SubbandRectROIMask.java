/*     */ package jj2000.j2k.roi.encoder;
/*     */ 
/*     */ import jj2000.j2k.wavelet.Subband;
/*     */ import jj2000.j2k.wavelet.WaveletFilter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SubbandRectROIMask
/*     */   extends SubbandROIMask
/*     */ {
/*     */   public int[] ulxs;
/*     */   public int[] ulys;
/*     */   public int[] lrxs;
/*     */   public int[] lrys;
/*     */   
/*     */   public SubbandRectROIMask(Subband sb, int[] ulxs, int[] ulys, int[] lrxs, int[] lrys, int nr) {
/* 132 */     super(sb.ulx, sb.uly, sb.w, sb.h);
/* 133 */     this.ulxs = ulxs;
/* 134 */     this.ulys = ulys;
/* 135 */     this.lrxs = lrxs;
/* 136 */     this.lrys = lrys;
/*     */ 
/*     */     
/* 139 */     if (sb.isNode) {
/* 140 */       this.isNode = true;
/*     */       
/* 142 */       int horEvenLow = sb.ulcx % 2;
/* 143 */       int verEvenLow = sb.ulcy % 2;
/*     */ 
/*     */       
/* 146 */       WaveletFilter hFilter = sb.getHorWFilter();
/* 147 */       WaveletFilter vFilter = sb.getVerWFilter();
/* 148 */       int hlnSup = hFilter.getSynLowNegSupport();
/* 149 */       int hhnSup = hFilter.getSynHighNegSupport();
/* 150 */       int hlpSup = hFilter.getSynLowPosSupport();
/* 151 */       int hhpSup = hFilter.getSynHighPosSupport();
/* 152 */       int vlnSup = vFilter.getSynLowNegSupport();
/* 153 */       int vhnSup = vFilter.getSynHighNegSupport();
/* 154 */       int vlpSup = vFilter.getSynLowPosSupport();
/* 155 */       int vhpSup = vFilter.getSynHighPosSupport();
/*     */ 
/*     */ 
/*     */       
/* 159 */       int[] lulxs = new int[nr];
/* 160 */       int[] lulys = new int[nr];
/* 161 */       int[] llrxs = new int[nr];
/* 162 */       int[] llrys = new int[nr];
/* 163 */       int[] hulxs = new int[nr];
/* 164 */       int[] hulys = new int[nr];
/* 165 */       int[] hlrxs = new int[nr];
/* 166 */       int[] hlrys = new int[nr];
/* 167 */       for (int r = nr - 1; r >= 0; r--) {
/*     */         
/* 169 */         int x = ulxs[r];
/* 170 */         if (horEvenLow == 0) {
/* 171 */           lulxs[r] = (x + 1 - hlnSup) / 2;
/* 172 */           hulxs[r] = (x - hhnSup) / 2;
/*     */         } else {
/*     */           
/* 175 */           lulxs[r] = (x - hlnSup) / 2;
/* 176 */           hulxs[r] = (x + 1 - hhnSup) / 2;
/*     */         } 
/*     */         
/* 179 */         int y = ulys[r];
/* 180 */         if (verEvenLow == 0) {
/* 181 */           lulys[r] = (y + 1 - vlnSup) / 2;
/* 182 */           hulys[r] = (y - vhnSup) / 2;
/*     */         } else {
/*     */           
/* 185 */           lulys[r] = (y - vlnSup) / 2;
/* 186 */           hulys[r] = (y + 1 - vhnSup) / 2;
/*     */         } 
/*     */         
/* 189 */         x = lrxs[r];
/* 190 */         if (horEvenLow == 0) {
/* 191 */           llrxs[r] = (x + hlpSup) / 2;
/* 192 */           hlrxs[r] = (x - 1 + hhpSup) / 2;
/*     */         } else {
/*     */           
/* 195 */           llrxs[r] = (x - 1 + hlpSup) / 2;
/* 196 */           hlrxs[r] = (x + hhpSup) / 2;
/*     */         } 
/*     */         
/* 199 */         y = lrys[r];
/* 200 */         if (verEvenLow == 0) {
/* 201 */           llrys[r] = (y + vlpSup) / 2;
/* 202 */           hlrys[r] = (y - 1 + vhpSup) / 2;
/*     */         } else {
/*     */           
/* 205 */           llrys[r] = (y - 1 + vlpSup) / 2;
/* 206 */           hlrys[r] = (y + vhpSup) / 2;
/*     */         } 
/*     */       } 
/*     */       
/* 210 */       this.hh = new SubbandRectROIMask(sb.getHH(), hulxs, hulys, hlrxs, hlrys, nr);
/* 211 */       this.lh = new SubbandRectROIMask(sb.getLH(), lulxs, hulys, llrxs, hlrys, nr);
/* 212 */       this.hl = new SubbandRectROIMask(sb.getHL(), hulxs, lulys, hlrxs, llrys, nr);
/* 213 */       this.ll = new SubbandRectROIMask(sb.getLL(), lulxs, lulys, llrxs, llrys, nr);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/roi/encoder/SubbandRectROIMask.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */