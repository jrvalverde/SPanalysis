/*     */ package jj2000.j2k.codestream.reader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CBlkInfo
/*     */ {
/*     */   public int ulx;
/*     */   public int uly;
/*     */   public int w;
/*     */   public int h;
/*     */   public int msbSkipped;
/*     */   public int[] len;
/*     */   public int[] off;
/*     */   public int[] ntp;
/*     */   public int ctp;
/*     */   public int[][] segLen;
/*     */   public int[] pktIdx;
/*     */   
/*     */   public CBlkInfo(int ulx, int uly, int w, int h, int nl) {
/* 149 */     this.ulx = ulx;
/* 150 */     this.uly = uly;
/* 151 */     this.w = w;
/* 152 */     this.h = h;
/* 153 */     this.off = new int[nl];
/* 154 */     this.len = new int[nl];
/* 155 */     this.ntp = new int[nl];
/* 156 */     this.segLen = new int[nl][];
/* 157 */     this.pktIdx = new int[nl];
/* 158 */     for (int i = nl - 1; i >= 0; i--) {
/* 159 */       this.pktIdx[i] = -1;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addNTP(int l, int newtp) {
/* 171 */     this.ntp[l] = newtp;
/* 172 */     this.ctp = 0;
/* 173 */     for (int lIdx = 0; lIdx <= l; lIdx++) {
/* 174 */       this.ctp += this.ntp[lIdx];
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 185 */     String string = "(ulx,uly,w,h)= " + this.ulx + "," + this.uly + "," + this.w + "," + this.h;
/* 186 */     string = string + ", " + this.msbSkipped + " MSB bit(s) skipped\n";
/* 187 */     if (this.len != null)
/* 188 */       for (int i = 0; i < this.len.length; i++) {
/* 189 */         string = string + "\tl:" + i + ", start:" + this.off[i] + ", len:" + this.len[i] + ", ntp:" + this.ntp[i] + ", pktIdx=" + this.pktIdx[i];
/*     */ 
/*     */         
/* 192 */         if (this.segLen != null && this.segLen[i] != null) {
/* 193 */           string = string + " { ";
/* 194 */           for (int j = 0; j < (this.segLen[i]).length; j++)
/* 195 */             string = string + this.segLen[i][j] + " "; 
/* 196 */           string = string + "}";
/*     */         } 
/* 198 */         string = string + "\n";
/*     */       }  
/* 200 */     string = string + "\tctp=" + this.ctp;
/* 201 */     return string;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/codestream/reader/CBlkInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */