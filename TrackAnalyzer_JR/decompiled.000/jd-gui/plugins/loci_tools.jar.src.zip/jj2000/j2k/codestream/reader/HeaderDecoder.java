/*      */ package jj2000.j2k.codestream.reader;
/*      */ 
/*      */ import com.sun.media.imageioimpl.plugins.jpeg2000.J2KImageReadParamJava;
/*      */ import java.awt.Point;
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.DataInputStream;
/*      */ import java.io.IOException;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Vector;
/*      */ import jj2000.j2k.NotImplementedError;
/*      */ import jj2000.j2k.codestream.CorruptedCodestreamException;
/*      */ import jj2000.j2k.codestream.HeaderInfo;
/*      */ import jj2000.j2k.codestream.Markers;
/*      */ import jj2000.j2k.codestream.ProgressionType;
/*      */ import jj2000.j2k.decoder.DecoderSpecs;
/*      */ import jj2000.j2k.entropy.StdEntropyCoderOptions;
/*      */ import jj2000.j2k.entropy.decoder.CodedCBlkDataSrcDec;
/*      */ import jj2000.j2k.entropy.decoder.EntropyDecoder;
/*      */ import jj2000.j2k.entropy.decoder.StdEntropyDecoder;
/*      */ import jj2000.j2k.io.RandomAccessIO;
/*      */ import jj2000.j2k.quantization.dequantizer.CBlkQuantDataSrcDec;
/*      */ import jj2000.j2k.quantization.dequantizer.Dequantizer;
/*      */ import jj2000.j2k.quantization.dequantizer.StdDequantizer;
/*      */ import jj2000.j2k.quantization.dequantizer.StdDequantizerParams;
/*      */ import jj2000.j2k.roi.MaxShiftSpec;
/*      */ import jj2000.j2k.roi.ROIDeScaler;
/*      */ import jj2000.j2k.util.FacilityManager;
/*      */ import jj2000.j2k.wavelet.synthesis.SynWTFilter;
/*      */ import jj2000.j2k.wavelet.synthesis.SynWTFilterFloatLift9x7;
/*      */ import jj2000.j2k.wavelet.synthesis.SynWTFilterIntLift5x3;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class HeaderDecoder
/*      */   implements ProgressionType, Markers, StdEntropyCoderOptions
/*      */ {
/*      */   public static final char OPT_PREFIX = 'H';
/*  154 */   private static final String[][] pinfo = (String[][])null;
/*      */ 
/*      */ 
/*      */   
/*      */   private HeaderInfo hi;
/*      */ 
/*      */   
/*  161 */   private String hdStr = "";
/*      */ 
/*      */ 
/*      */   
/*      */   private J2KImageReadParamJava j2krparam;
/*      */ 
/*      */ 
/*      */   
/*      */   private int nTiles;
/*      */ 
/*      */   
/*      */   public int[] nTileParts;
/*      */ 
/*      */   
/*  175 */   private int nfMarkSeg = 0;
/*      */ 
/*      */   
/*  178 */   private int nCOCMarkSeg = 0;
/*      */ 
/*      */   
/*  181 */   private int nQCCMarkSeg = 0;
/*      */ 
/*      */   
/*  184 */   private int nCOMMarkSeg = 0;
/*      */ 
/*      */   
/*  187 */   private int nRGNMarkSeg = 0;
/*      */ 
/*      */   
/*  190 */   private int nPPMMarkSeg = 0;
/*      */ 
/*      */   
/*  193 */   private int[][] nPPTMarkSeg = (int[][])null;
/*      */ 
/*      */   
/*      */   private static final int SIZ_FOUND = 1;
/*      */ 
/*      */   
/*      */   private static final int COD_FOUND = 2;
/*      */ 
/*      */   
/*      */   private static final int COC_FOUND = 4;
/*      */ 
/*      */   
/*      */   private static final int QCD_FOUND = 8;
/*      */ 
/*      */   
/*      */   private static final int TLM_FOUND = 16;
/*      */ 
/*      */   
/*      */   private static final int PLM_FOUND = 32;
/*      */ 
/*      */   
/*      */   private static final int SOT_FOUND = 64;
/*      */ 
/*      */   
/*      */   private static final int PLT_FOUND = 128;
/*      */ 
/*      */   
/*      */   private static final int QCC_FOUND = 256;
/*      */ 
/*      */   
/*      */   private static final int RGN_FOUND = 512;
/*      */ 
/*      */   
/*      */   private static final int POC_FOUND = 1024;
/*      */ 
/*      */   
/*      */   private static final int COM_FOUND = 2048;
/*      */ 
/*      */   
/*      */   public static final int SOD_FOUND = 8192;
/*      */ 
/*      */   
/*      */   public static final int PPM_FOUND = 16384;
/*      */ 
/*      */   
/*      */   public static final int PPT_FOUND = 32768;
/*      */ 
/*      */   
/*      */   public static final int CRG_FOUND = 65536;
/*      */ 
/*      */   
/*      */   private static final int TILE_RESET = -546;
/*      */ 
/*      */   
/*  247 */   private Hashtable ht = null;
/*      */ 
/*      */   
/*      */   private int nComp;
/*      */ 
/*      */   
/*  253 */   private int cb0x = -1;
/*      */ 
/*      */   
/*  256 */   private int cb0y = -1;
/*      */ 
/*      */ 
/*      */   
/*      */   private DecoderSpecs decSpec;
/*      */ 
/*      */ 
/*      */   
/*      */   boolean precinctPartitionIsUsed;
/*      */ 
/*      */   
/*      */   public int mainHeadOff;
/*      */ 
/*      */   
/*      */   public Vector tileOfTileParts;
/*      */ 
/*      */   
/*      */   private byte[][] pPMMarkerData;
/*      */ 
/*      */   
/*      */   private byte[][][][] tilePartPkdPktHeaders;
/*      */ 
/*      */   
/*      */   private ByteArrayOutputStream[] pkdPktHeaders;
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMaxCompImgHeight() {
/*  284 */     return this.hi.siz.getMaxCompHeight();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMaxCompImgWidth() {
/*  291 */     return this.hi.siz.getMaxCompWidth();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getImgWidth() {
/*  298 */     return this.hi.siz.xsiz - this.hi.siz.x0siz;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getImgHeight() {
/*  305 */     return this.hi.siz.ysiz - this.hi.siz.y0siz;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getImgULX() {
/*  313 */     return this.hi.siz.x0siz;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getImgULY() {
/*  321 */     return this.hi.siz.y0siz;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getNomTileWidth() {
/*  328 */     return this.hi.siz.xtsiz;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getNomTileHeight() {
/*  335 */     return this.hi.siz.ytsiz;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Point getTilingOrigin(Point co) {
/*  350 */     if (co != null) {
/*  351 */       co.x = this.hi.siz.xt0siz;
/*  352 */       co.y = this.hi.siz.yt0siz;
/*  353 */       return co;
/*      */     } 
/*      */     
/*  356 */     return new Point(this.hi.siz.xt0siz, this.hi.siz.yt0siz);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isOriginalSigned(int c) {
/*  370 */     return this.hi.siz.isOrigSigned(c);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getOriginalBitDepth(int c) {
/*  381 */     return this.hi.siz.getOrigBitDepth(c);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getNumComps() {
/*  390 */     return this.nComp;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getCompSubsX(int c) {
/*  402 */     return this.hi.siz.xrsiz[c];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getCompSubsY(int c) {
/*  413 */     return this.hi.siz.yrsiz[c];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Dequantizer createDequantizer(CBlkQuantDataSrcDec src, int[] rb, DecoderSpecs decSpec2) {
/*  431 */     return (Dequantizer)new StdDequantizer(src, rb, decSpec2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getCbULX() {
/*  439 */     return this.cb0x;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getCbULY() {
/*  447 */     return this.cb0y;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getPPX(int t, int c, int rl) {
/*  464 */     return this.decSpec.pss.getPPX(t, c, rl);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getPPY(int t, int c, int rl) {
/*  481 */     return this.decSpec.pss.getPPY(t, c, rl);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean precinctPartitionUsed() {
/*  488 */     return this.precinctPartitionIsUsed;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private SynWTFilter readFilter(DataInputStream ehs, int[] filtIdx) throws IOException {
/*  504 */     int kid = filtIdx[0] = ehs.readUnsignedByte();
/*  505 */     if (kid >= 128) {
/*  506 */       throw new NotImplementedError("Custom filters not supported");
/*      */     }
/*      */     
/*  509 */     switch (kid) {
/*      */       case 0:
/*  511 */         return (SynWTFilter)new SynWTFilterFloatLift9x7();
/*      */       case 1:
/*  513 */         return (SynWTFilter)new SynWTFilterIntLift5x3();
/*      */     } 
/*  515 */     throw new CorruptedCodestreamException("Specified wavelet filter not JPEG 2000 part I compliant");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void checkMarkerLength(DataInputStream ehs, String str) throws IOException {
/*  533 */     if (ehs.available() != 0) {
/*  534 */       FacilityManager.getMsgLogger().printmsg(2, str + " length was short, attempting to resync.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void readSIZ(DataInputStream ehs) throws IOException {
/*  554 */     HeaderInfo.SIZ ms = this.hi.getNewSIZ();
/*  555 */     this.hi.siz = ms;
/*      */ 
/*      */     
/*  558 */     ms.lsiz = ehs.readUnsignedShort();
/*      */ 
/*      */     
/*  561 */     ms.rsiz = ehs.readUnsignedShort();
/*  562 */     if (ms.rsiz > 2) {
/*  563 */       throw new Error("Codestream capabiities not JPEG 2000 - Part I compliant");
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  568 */     ms.xsiz = ehs.readInt();
/*  569 */     ms.ysiz = ehs.readInt();
/*  570 */     if (ms.xsiz <= 0 || ms.ysiz <= 0) {
/*  571 */       throw new IOException("JJ2000 does not support images whose width and/or height not in the range: 1 -- (2^31)-1");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  577 */     ms.x0siz = ehs.readInt();
/*  578 */     ms.y0siz = ehs.readInt();
/*  579 */     if (ms.x0siz < 0 || ms.y0siz < 0) {
/*  580 */       throw new IOException("JJ2000 does not support images offset not in the range: 0 -- (2^31)-1");
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  585 */     ms.xtsiz = ehs.readInt();
/*  586 */     ms.ytsiz = ehs.readInt();
/*  587 */     if (ms.xtsiz <= 0 || ms.ytsiz <= 0) {
/*  588 */       throw new IOException("JJ2000 does not support tiles whose width and/or height are not in  the range: 1 -- (2^31)-1");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  594 */     ms.xt0siz = ehs.readInt();
/*  595 */     ms.yt0siz = ehs.readInt();
/*  596 */     if (ms.xt0siz < 0 || ms.yt0siz < 0) {
/*  597 */       throw new IOException("JJ2000 does not support tiles whose offset is not in  the range: 0 -- (2^31)-1");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  603 */     this.nComp = ms.csiz = ehs.readUnsignedShort();
/*  604 */     if (this.nComp < 1 || this.nComp > 16384) {
/*  605 */       throw new IllegalArgumentException("Number of component out of range 1--16384: " + this.nComp);
/*      */     }
/*      */ 
/*      */     
/*  609 */     ms.ssiz = new int[this.nComp];
/*  610 */     ms.xrsiz = new int[this.nComp];
/*  611 */     ms.yrsiz = new int[this.nComp];
/*      */ 
/*      */     
/*  614 */     for (int i = 0; i < this.nComp; i++) {
/*  615 */       ms.ssiz[i] = ehs.readUnsignedByte();
/*  616 */       ms.xrsiz[i] = ehs.readUnsignedByte();
/*  617 */       ms.yrsiz[i] = ehs.readUnsignedByte();
/*      */     } 
/*      */ 
/*      */     
/*  621 */     checkMarkerLength(ehs, "SIZ marker");
/*      */ 
/*      */     
/*  624 */     this.nTiles = ms.getNumTiles();
/*      */ 
/*      */     
/*  627 */     this.decSpec = new DecoderSpecs(this.nTiles, this.nComp);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void readCRG(DataInputStream ehs) throws IOException {
/*  638 */     HeaderInfo.CRG ms = this.hi.getNewCRG();
/*  639 */     this.hi.crg = ms;
/*      */     
/*  641 */     ms.lcrg = ehs.readUnsignedShort();
/*  642 */     ms.xcrg = new int[this.nComp];
/*  643 */     ms.ycrg = new int[this.nComp];
/*      */     
/*  645 */     FacilityManager.getMsgLogger().printmsg(2, "Information in CRG marker segment not taken into account. This may affect the display of the decoded image.");
/*      */ 
/*      */ 
/*      */     
/*  649 */     for (int c = 0; c < this.nComp; c++) {
/*  650 */       ms.xcrg[c] = ehs.readUnsignedShort();
/*  651 */       ms.ycrg[c] = ehs.readUnsignedShort();
/*      */     } 
/*      */ 
/*      */     
/*  655 */     checkMarkerLength(ehs, "CRG marker");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void readCOM(DataInputStream ehs, boolean mainh, int tileIdx, int comIdx) throws IOException {
/*      */     int i;
/*  680 */     HeaderInfo.COM ms = this.hi.getNewCOM();
/*      */ 
/*      */     
/*  683 */     ms.lcom = ehs.readUnsignedShort();
/*      */ 
/*      */     
/*  686 */     ms.rcom = ehs.readUnsignedShort();
/*  687 */     switch (ms.rcom) {
/*      */       case 1:
/*  689 */         ms.ccom = new byte[ms.lcom - 4];
/*  690 */         for (i = 0; i < ms.lcom - 4; i++) {
/*  691 */           ms.ccom[i] = ehs.readByte();
/*      */         }
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/*  697 */         FacilityManager.getMsgLogger().printmsg(2, "COM marker registered as 0x" + Integer.toHexString(ms.rcom) + " unknown, ignoring (this might crash the " + "decoder or decode a quality degraded or even " + "useless image)");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  704 */         ehs.skipBytes(ms.lcom - 4);
/*      */         break;
/*      */     } 
/*      */     
/*  708 */     if (mainh) {
/*  709 */       this.hi.com.put("main_" + comIdx, ms);
/*      */     } else {
/*  711 */       this.hi.com.put("t" + tileIdx + "_" + comIdx, ms);
/*      */     } 
/*      */ 
/*      */     
/*  715 */     checkMarkerLength(ehs, "COM marker");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void readQCD(DataInputStream ehs, boolean mainh, int tileIdx, int tpIdx) throws IOException {
/*  740 */     float[][] nStep = (float[][])null;
/*  741 */     HeaderInfo.QCD ms = this.hi.getNewQCD();
/*      */ 
/*      */     
/*  744 */     ms.lqcd = ehs.readUnsignedShort();
/*      */ 
/*      */     
/*  747 */     ms.sqcd = ehs.readUnsignedByte();
/*      */     
/*  749 */     int guardBits = ms.getNumGuardBits();
/*  750 */     int qType = ms.getQuantType();
/*      */     
/*  752 */     if (mainh) {
/*  753 */       this.hi.qcd.put("main", ms);
/*      */ 
/*      */       
/*  756 */       switch (qType) {
/*      */         case 0:
/*  758 */           this.decSpec.qts.setDefault("reversible");
/*      */           break;
/*      */         case 1:
/*  761 */           this.decSpec.qts.setDefault("derived");
/*      */           break;
/*      */         case 2:
/*  764 */           this.decSpec.qts.setDefault("expounded");
/*      */           break;
/*      */         default:
/*  767 */           throw new CorruptedCodestreamException("Unknown or unsupported quantization style in Sqcd field, QCD marker main header");
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     } else {
/*  774 */       this.hi.qcd.put("t" + tileIdx, ms);
/*      */ 
/*      */       
/*  777 */       switch (qType) {
/*      */         case 0:
/*  779 */           this.decSpec.qts.setTileDef(tileIdx, "reversible");
/*      */           break;
/*      */         case 1:
/*  782 */           this.decSpec.qts.setTileDef(tileIdx, "derived");
/*      */           break;
/*      */         case 2:
/*  785 */           this.decSpec.qts.setTileDef(tileIdx, "expounded");
/*      */           break;
/*      */         default:
/*  788 */           throw new CorruptedCodestreamException("Unknown or unsupported quantization style in Sqcd field, QCD marker, tile header");
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     } 
/*  796 */     StdDequantizerParams qParms = new StdDequantizerParams();
/*      */     
/*  798 */     if (qType == 0) {
/*  799 */       int maxrl = mainh ? ((Integer)this.decSpec.dls.getDefault()).intValue() : ((Integer)this.decSpec.dls.getTileDef(tileIdx)).intValue();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  807 */       int[][] exp = qParms.exp = new int[maxrl + 1][];
/*  808 */       ms.spqcd = new int[maxrl + 1][4];
/*      */       
/*  810 */       for (int rl = 0; rl <= maxrl; rl++) {
/*      */         int minb, maxb;
/*  812 */         if (rl == 0) {
/*  813 */           minb = 0;
/*  814 */           maxb = 1;
/*      */         } else {
/*      */           
/*  817 */           int hpd = 1;
/*      */ 
/*      */           
/*  820 */           if (hpd > maxrl - rl) {
/*  821 */             hpd -= maxrl - rl;
/*      */           } else {
/*      */             
/*  824 */             hpd = 1;
/*      */           } 
/*      */           
/*  827 */           minb = 1 << hpd - 1 << 1;
/*  828 */           maxb = 1 << hpd << 1;
/*      */         } 
/*      */         
/*  831 */         exp[rl] = new int[maxb];
/*      */         
/*  833 */         for (int j = minb; j < maxb; j++) {
/*  834 */           int tmp = ms.spqcd[rl][j] = ehs.readUnsignedByte();
/*  835 */           exp[rl][j] = tmp >> 3 & 0x1F;
/*      */         } 
/*      */       } 
/*      */     } else {
/*  839 */       int maxrl = (qType == 1) ? 0 : (mainh ? ((Integer)this.decSpec.dls.getDefault()).intValue() : ((Integer)this.decSpec.dls.getTileDef(tileIdx)).intValue());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  847 */       int[][] exp = qParms.exp = new int[maxrl + 1][];
/*  848 */       nStep = qParms.nStep = new float[maxrl + 1][];
/*  849 */       ms.spqcd = new int[maxrl + 1][4];
/*      */       
/*  851 */       for (int rl = 0; rl <= maxrl; rl++) {
/*      */         int minb, maxb;
/*  853 */         if (rl == 0) {
/*  854 */           minb = 0;
/*  855 */           maxb = 1;
/*      */         } else {
/*      */           
/*  858 */           int hpd = 1;
/*      */ 
/*      */           
/*  861 */           if (hpd > maxrl - rl) {
/*  862 */             hpd -= maxrl - rl;
/*      */           } else {
/*  864 */             hpd = 1;
/*      */           } 
/*      */           
/*  867 */           minb = 1 << hpd - 1 << 1;
/*  868 */           maxb = 1 << hpd << 1;
/*      */         } 
/*      */         
/*  871 */         exp[rl] = new int[maxb];
/*  872 */         nStep[rl] = new float[maxb];
/*      */         
/*  874 */         for (int j = minb; j < maxb; j++) {
/*  875 */           int tmp = ms.spqcd[rl][j] = ehs.readUnsignedShort();
/*  876 */           exp[rl][j] = tmp >> 11 & 0x1F;
/*      */ 
/*      */ 
/*      */           
/*  880 */           nStep[rl][j] = (-1.0F - (tmp & 0x7FF) / 2048.0F) / (-1 << exp[rl][j]);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  888 */     if (mainh) {
/*  889 */       this.decSpec.qsss.setDefault(qParms);
/*  890 */       this.decSpec.gbs.setDefault(new Integer(guardBits));
/*      */     } else {
/*      */       
/*  893 */       this.decSpec.qsss.setTileDef(tileIdx, qParms);
/*  894 */       this.decSpec.gbs.setTileDef(tileIdx, new Integer(guardBits));
/*      */     } 
/*      */ 
/*      */     
/*  898 */     checkMarkerLength(ehs, "QCD marker");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void readQCC(DataInputStream ehs, boolean mainh, int tileIdx, int tpIdx) throws IOException {
/*      */     int cComp;
/*  924 */     float[][] nStepC = (float[][])null;
/*  925 */     HeaderInfo.QCC ms = this.hi.getNewQCC();
/*      */ 
/*      */     
/*  928 */     ms.lqcc = ehs.readUnsignedShort();
/*      */ 
/*      */     
/*  931 */     if (this.nComp < 257) {
/*  932 */       cComp = ms.cqcc = ehs.readUnsignedByte();
/*      */     } else {
/*  934 */       cComp = ms.cqcc = ehs.readUnsignedShort();
/*      */     } 
/*  936 */     if (cComp >= this.nComp) {
/*  937 */       throw new CorruptedCodestreamException("Invalid component index in QCC marker");
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  942 */     ms.sqcc = ehs.readUnsignedByte();
/*  943 */     int guardBits = ms.getNumGuardBits();
/*  944 */     int qType = ms.getQuantType();
/*      */     
/*  946 */     if (mainh) {
/*  947 */       this.hi.qcc.put("main_c" + cComp, ms);
/*      */ 
/*      */       
/*  950 */       switch (qType) {
/*      */         case 0:
/*  952 */           this.decSpec.qts.setCompDef(cComp, "reversible");
/*      */           break;
/*      */         case 1:
/*  955 */           this.decSpec.qts.setCompDef(cComp, "derived");
/*      */           break;
/*      */         case 2:
/*  958 */           this.decSpec.qts.setCompDef(cComp, "expounded");
/*      */           break;
/*      */         default:
/*  961 */           throw new CorruptedCodestreamException("Unknown or unsupported quantization style in Sqcd field, QCD marker, main header");
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     } else {
/*  968 */       this.hi.qcc.put("t" + tileIdx + "_c" + cComp, ms);
/*      */ 
/*      */       
/*  971 */       switch (qType) {
/*      */         case 0:
/*  973 */           this.decSpec.qts.setTileCompVal(tileIdx, cComp, "reversible");
/*      */           break;
/*      */         case 1:
/*  976 */           this.decSpec.qts.setTileCompVal(tileIdx, cComp, "derived");
/*      */           break;
/*      */         case 2:
/*  979 */           this.decSpec.qts.setTileCompVal(tileIdx, cComp, "expounded");
/*      */           break;
/*      */         default:
/*  982 */           throw new CorruptedCodestreamException("Unknown or unsupported quantization style in Sqcd field, QCD marker, main header");
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     } 
/*  991 */     StdDequantizerParams qParms = new StdDequantizerParams();
/*      */     
/*  993 */     if (qType == 0) {
/*  994 */       int maxrl = mainh ? ((Integer)this.decSpec.dls.getCompDef(cComp)).intValue() : ((Integer)this.decSpec.dls.getTileCompVal(tileIdx, cComp)).intValue();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1001 */       int[][] expC = qParms.exp = new int[maxrl + 1][];
/* 1002 */       ms.spqcc = new int[maxrl + 1][4];
/*      */       
/* 1004 */       for (int rl = 0; rl <= maxrl; rl++) {
/*      */         int minb, maxb;
/* 1006 */         if (rl == 0) {
/* 1007 */           minb = 0;
/* 1008 */           maxb = 1;
/*      */         } else {
/*      */           
/* 1011 */           int hpd = 1;
/*      */ 
/*      */           
/* 1014 */           if (hpd > maxrl - rl) {
/* 1015 */             hpd -= maxrl - rl;
/*      */           } else {
/* 1017 */             hpd = 1;
/*      */           } 
/*      */           
/* 1020 */           minb = 1 << hpd - 1 << 1;
/* 1021 */           maxb = 1 << hpd << 1;
/*      */         } 
/*      */         
/* 1024 */         expC[rl] = new int[maxb];
/*      */         
/* 1026 */         for (int j = minb; j < maxb; j++) {
/* 1027 */           int tmp = ms.spqcc[rl][j] = ehs.readUnsignedByte();
/* 1028 */           expC[rl][j] = tmp >> 3 & 0x1F;
/*      */         } 
/*      */       } 
/*      */     } else {
/* 1032 */       int maxrl = (qType == 1) ? 0 : (mainh ? ((Integer)this.decSpec.dls.getCompDef(cComp)).intValue() : ((Integer)this.decSpec.dls.getTileCompVal(tileIdx, cComp)).intValue());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1040 */       nStepC = qParms.nStep = new float[maxrl + 1][];
/* 1041 */       int[][] expC = qParms.exp = new int[maxrl + 1][];
/* 1042 */       ms.spqcc = new int[maxrl + 1][4];
/*      */       
/* 1044 */       for (int rl = 0; rl <= maxrl; rl++) {
/*      */         int minb, maxb;
/* 1046 */         if (rl == 0) {
/* 1047 */           minb = 0;
/* 1048 */           maxb = 1;
/*      */         } else {
/*      */           
/* 1051 */           int hpd = 1;
/*      */ 
/*      */           
/* 1054 */           if (hpd > maxrl - rl) {
/* 1055 */             hpd -= maxrl - rl;
/*      */           } else {
/* 1057 */             hpd = 1;
/*      */           } 
/*      */           
/* 1060 */           minb = 1 << hpd - 1 << 1;
/* 1061 */           maxb = 1 << hpd << 1;
/*      */         } 
/*      */         
/* 1064 */         expC[rl] = new int[maxb];
/* 1065 */         nStepC[rl] = new float[maxb];
/*      */         
/* 1067 */         for (int j = minb; j < maxb; j++) {
/* 1068 */           int tmp = ms.spqcc[rl][j] = ehs.readUnsignedShort();
/* 1069 */           expC[rl][j] = tmp >> 11 & 0x1F;
/*      */ 
/*      */ 
/*      */           
/* 1073 */           nStepC[rl][j] = (-1.0F - (tmp & 0x7FF) / 2048.0F) / (-1 << expC[rl][j]);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1081 */     if (mainh) {
/* 1082 */       this.decSpec.qsss.setCompDef(cComp, qParms);
/* 1083 */       this.decSpec.gbs.setCompDef(cComp, new Integer(guardBits));
/*      */     } else {
/*      */       
/* 1086 */       this.decSpec.qsss.setTileCompVal(tileIdx, cComp, qParms);
/* 1087 */       this.decSpec.gbs.setTileCompVal(tileIdx, cComp, new Integer(guardBits));
/*      */     } 
/*      */ 
/*      */     
/* 1091 */     checkMarkerLength(ehs, "QCC marker");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void readCOD(DataInputStream ehs, boolean mainh, int tileIdx, int tpIdx) throws IOException {
/* 1117 */     boolean sopUsed = false;
/* 1118 */     boolean ephUsed = false;
/* 1119 */     HeaderInfo.COD ms = this.hi.getNewCOD();
/*      */ 
/*      */     
/* 1122 */     ms.lcod = ehs.readUnsignedShort();
/*      */ 
/*      */ 
/*      */     
/* 1126 */     int cstyle = ms.scod = ehs.readUnsignedByte();
/*      */     
/* 1128 */     if ((cstyle & 0x1) != 0) {
/* 1129 */       this.precinctPartitionIsUsed = true;
/*      */       
/* 1131 */       cstyle &= 0xFFFFFFFE;
/*      */     } else {
/* 1133 */       this.precinctPartitionIsUsed = false;
/*      */     } 
/*      */ 
/*      */     
/* 1137 */     if (mainh) {
/* 1138 */       this.hi.cod.put("main", ms);
/*      */       
/* 1140 */       if ((cstyle & 0x2) != 0) {
/*      */         
/* 1142 */         this.decSpec.sops.setDefault(new Boolean("true"));
/* 1143 */         sopUsed = true;
/*      */         
/* 1145 */         cstyle &= 0xFFFFFFFD;
/*      */       } else {
/*      */         
/* 1148 */         this.decSpec.sops.setDefault(new Boolean("false"));
/*      */       } 
/*      */     } else {
/* 1151 */       this.hi.cod.put("t" + tileIdx, ms);
/*      */       
/* 1153 */       if ((cstyle & 0x2) != 0) {
/*      */         
/* 1155 */         this.decSpec.sops.setTileDef(tileIdx, new Boolean("true"));
/* 1156 */         sopUsed = true;
/*      */         
/* 1158 */         cstyle &= 0xFFFFFFFD;
/*      */       }
/*      */       else {
/*      */         
/* 1162 */         this.decSpec.sops.setTileDef(tileIdx, new Boolean("false"));
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1167 */     if (mainh) {
/* 1168 */       if ((cstyle & 0x4) != 0) {
/*      */         
/* 1170 */         this.decSpec.ephs.setDefault(new Boolean("true"));
/* 1171 */         ephUsed = true;
/*      */         
/* 1173 */         cstyle &= 0xFFFFFFFB;
/*      */       } else {
/*      */         
/* 1176 */         this.decSpec.ephs.setDefault(new Boolean("false"));
/*      */       }
/*      */     
/* 1179 */     } else if ((cstyle & 0x4) != 0) {
/*      */       
/* 1181 */       this.decSpec.ephs.setTileDef(tileIdx, new Boolean("true"));
/* 1182 */       ephUsed = true;
/*      */       
/* 1184 */       cstyle &= 0xFFFFFFFB;
/*      */     } else {
/*      */       
/* 1187 */       this.decSpec.ephs.setTileDef(tileIdx, new Boolean("false"));
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1192 */     if ((cstyle & 0x18) != 0) {
/* 1193 */       FacilityManager.getMsgLogger().printmsg(2, "Code-block partition origin different from (0,0). This is defined in JPEG 2000 part 2 and may not be supported by all JPEG 2000 decoders.");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1199 */     if ((cstyle & 0x8) != 0) {
/* 1200 */       if (this.cb0x != -1 && this.cb0x == 0) {
/* 1201 */         throw new IllegalArgumentException("Code-block partition origin redefined in new COD marker segment. Not supported by JJ2000");
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 1206 */       this.cb0x = 1;
/* 1207 */       cstyle &= 0xFFFFFFF7;
/*      */     } else {
/* 1209 */       if (this.cb0x != -1 && this.cb0x == 1) {
/* 1210 */         throw new IllegalArgumentException("Code-block partition origin redefined in new COD marker segment. Not supported by JJ2000");
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 1215 */       this.cb0x = 0;
/*      */     } 
/* 1217 */     if ((cstyle & 0x10) != 0) {
/* 1218 */       if (this.cb0y != -1 && this.cb0y == 0) {
/* 1219 */         throw new IllegalArgumentException("Code-block partition origin redefined in new COD marker segment. Not supported by JJ2000");
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 1224 */       this.cb0y = 1;
/* 1225 */       cstyle &= 0xFFFFFFEF;
/*      */     } else {
/* 1227 */       if (this.cb0y != -1 && this.cb0y == 1) {
/* 1228 */         throw new IllegalArgumentException("Code-block partition origin redefined in new COD marker segment. Not supported by JJ2000");
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 1233 */       this.cb0y = 0;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1238 */     ms.sgcod_po = ehs.readUnsignedByte();
/*      */ 
/*      */     
/* 1241 */     ms.sgcod_nl = ehs.readUnsignedShort();
/* 1242 */     if (ms.sgcod_nl <= 0 || ms.sgcod_nl > 65535) {
/* 1243 */       throw new CorruptedCodestreamException("Number of layers out of range: 1--65535");
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1248 */     ms.sgcod_mct = ehs.readUnsignedByte();
/*      */ 
/*      */ 
/*      */     
/* 1252 */     int mrl = ms.spcod_ndl = ehs.readUnsignedByte();
/* 1253 */     if (mrl > 32) {
/* 1254 */       throw new CorruptedCodestreamException("Number of decomposition levels out of range: 0--32");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1260 */     Integer[] cblk = new Integer[2];
/* 1261 */     ms.spcod_cw = ehs.readUnsignedByte();
/* 1262 */     cblk[0] = new Integer(1 << ms.spcod_cw + 2);
/* 1263 */     if (cblk[0].intValue() < 4 || cblk[0].intValue() > 1024) {
/*      */       
/* 1265 */       String errMsg = "Non-valid code-block width in SPcod field, COD marker";
/*      */       
/* 1267 */       throw new CorruptedCodestreamException(errMsg);
/*      */     } 
/* 1269 */     ms.spcod_ch = ehs.readUnsignedByte();
/* 1270 */     cblk[1] = new Integer(1 << ms.spcod_ch + 2);
/* 1271 */     if (cblk[1].intValue() < 4 || cblk[1].intValue() > 1024) {
/*      */       
/* 1273 */       String errMsg = "Non-valid code-block height in SPcod field, COD marker";
/*      */       
/* 1275 */       throw new CorruptedCodestreamException(errMsg);
/*      */     } 
/* 1277 */     if (cblk[0].intValue() * cblk[1].intValue() > 4096) {
/*      */       
/* 1279 */       String errMsg = "Non-valid code-block area in SPcod field, COD marker";
/*      */       
/* 1281 */       throw new CorruptedCodestreamException(errMsg);
/*      */     } 
/* 1283 */     if (mainh) {
/* 1284 */       this.decSpec.cblks.setDefault(cblk);
/*      */     } else {
/*      */       
/* 1287 */       this.decSpec.cblks.setTileDef(tileIdx, cblk);
/*      */     } 
/*      */ 
/*      */     
/* 1291 */     int ecOptions = ms.spcod_cs = ehs.readUnsignedByte();
/* 1292 */     if ((ecOptions & 0xFFFFFFC0) != 0)
/*      */     {
/*      */       
/* 1295 */       throw new CorruptedCodestreamException("Unknown \"code-block style\" in SPcod field, COD marker: 0x" + Integer.toHexString(ecOptions));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1304 */     SynWTFilter[] hfilters = new SynWTFilter[1];
/* 1305 */     SynWTFilter[] vfilters = new SynWTFilter[1];
/* 1306 */     hfilters[0] = readFilter(ehs, ms.spcod_t);
/* 1307 */     vfilters[0] = hfilters[0];
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1312 */     SynWTFilter[][] hvfilters = new SynWTFilter[2][];
/* 1313 */     hvfilters[0] = hfilters;
/* 1314 */     hvfilters[1] = vfilters;
/*      */ 
/*      */     
/* 1317 */     Vector[] v = new Vector[2];
/* 1318 */     v[0] = new Vector();
/* 1319 */     v[1] = new Vector();
/* 1320 */     int val = 65535;
/* 1321 */     if (!this.precinctPartitionIsUsed) {
/*      */       
/* 1323 */       Integer w = new Integer(1 << (val & 0xF));
/* 1324 */       v[0].addElement(w);
/* 1325 */       Integer h = new Integer(1 << (val & 0xF0) >> 4);
/* 1326 */       v[1].addElement(h);
/*      */     } else {
/* 1328 */       ms.spcod_ps = new int[mrl + 1];
/* 1329 */       for (int rl = mrl; rl >= 0; rl--) {
/*      */         
/* 1331 */         val = ms.spcod_ps[mrl - rl] = ehs.readUnsignedByte();
/* 1332 */         Integer w = new Integer(1 << (val & 0xF));
/* 1333 */         v[0].insertElementAt(w, 0);
/* 1334 */         Integer h = new Integer(1 << (val & 0xF0) >> 4);
/* 1335 */         v[1].insertElementAt(h, 0);
/*      */       } 
/*      */     } 
/* 1338 */     if (mainh) {
/* 1339 */       this.decSpec.pss.setDefault(v);
/*      */     } else {
/* 1341 */       this.decSpec.pss.setTileDef(tileIdx, v);
/*      */     } 
/* 1343 */     this.precinctPartitionIsUsed = true;
/*      */ 
/*      */     
/* 1346 */     checkMarkerLength(ehs, "COD marker");
/*      */ 
/*      */     
/* 1349 */     if (mainh) {
/* 1350 */       this.decSpec.wfs.setDefault(hvfilters);
/* 1351 */       this.decSpec.dls.setDefault(new Integer(mrl));
/* 1352 */       this.decSpec.ecopts.setDefault(new Integer(ecOptions));
/* 1353 */       this.decSpec.cts.setDefault(new Integer(ms.sgcod_mct));
/* 1354 */       this.decSpec.nls.setDefault(new Integer(ms.sgcod_nl));
/* 1355 */       this.decSpec.pos.setDefault(new Integer(ms.sgcod_po));
/*      */     } else {
/*      */       
/* 1358 */       this.decSpec.wfs.setTileDef(tileIdx, hvfilters);
/* 1359 */       this.decSpec.dls.setTileDef(tileIdx, new Integer(mrl));
/* 1360 */       this.decSpec.ecopts.setTileDef(tileIdx, new Integer(ecOptions));
/* 1361 */       this.decSpec.cts.setTileDef(tileIdx, new Integer(ms.sgcod_mct));
/* 1362 */       this.decSpec.nls.setTileDef(tileIdx, new Integer(ms.sgcod_nl));
/* 1363 */       this.decSpec.pos.setTileDef(tileIdx, new Integer(ms.sgcod_po));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void readCOC(DataInputStream ehs, boolean mainh, int tileIdx, int tpIdx) throws IOException {
/*      */     int cComp;
/* 1391 */     HeaderInfo.COC ms = this.hi.getNewCOC();
/*      */ 
/*      */     
/* 1394 */     ms.lcoc = ehs.readUnsignedShort();
/*      */ 
/*      */     
/* 1397 */     if (this.nComp < 257) {
/* 1398 */       cComp = ms.ccoc = ehs.readUnsignedByte();
/*      */     } else {
/* 1400 */       cComp = ms.ccoc = ehs.readUnsignedShort();
/*      */     } 
/* 1402 */     if (cComp >= this.nComp) {
/* 1403 */       throw new CorruptedCodestreamException("Invalid component index in QCC marker");
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1408 */     int cstyle = ms.scoc = ehs.readUnsignedByte();
/* 1409 */     if ((cstyle & 0x1) != 0) {
/* 1410 */       this.precinctPartitionIsUsed = true;
/*      */       
/* 1412 */       cstyle &= 0xFFFFFFFE;
/*      */     } else {
/* 1414 */       this.precinctPartitionIsUsed = false;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1420 */     int mrl = ms.spcoc_ndl = ehs.readUnsignedByte();
/*      */ 
/*      */     
/* 1423 */     Integer[] cblk = new Integer[2];
/* 1424 */     ms.spcoc_cw = ehs.readUnsignedByte();
/* 1425 */     cblk[0] = new Integer(1 << ms.spcoc_cw + 2);
/* 1426 */     if (cblk[0].intValue() < 4 || cblk[0].intValue() > 1024) {
/*      */       
/* 1428 */       String errMsg = "Non-valid code-block width in SPcod field, COC marker";
/*      */       
/* 1430 */       throw new CorruptedCodestreamException(errMsg);
/*      */     } 
/* 1432 */     ms.spcoc_ch = ehs.readUnsignedByte();
/* 1433 */     cblk[1] = new Integer(1 << ms.spcoc_ch + 2);
/* 1434 */     if (cblk[1].intValue() < 4 || cblk[1].intValue() > 1024) {
/*      */       
/* 1436 */       String errMsg = "Non-valid code-block height in SPcod field, COC marker";
/*      */       
/* 1438 */       throw new CorruptedCodestreamException(errMsg);
/*      */     } 
/* 1440 */     if (cblk[0].intValue() * cblk[1].intValue() > 4096) {
/*      */       
/* 1442 */       String errMsg = "Non-valid code-block area in SPcod field, COC marker";
/*      */       
/* 1444 */       throw new CorruptedCodestreamException(errMsg);
/*      */     } 
/* 1446 */     if (mainh) {
/* 1447 */       this.decSpec.cblks.setCompDef(cComp, cblk);
/*      */     } else {
/* 1449 */       this.decSpec.cblks.setTileCompVal(tileIdx, cComp, cblk);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1454 */     int ecOptions = ms.spcoc_cs = ehs.readUnsignedByte();
/* 1455 */     if ((ecOptions & 0xFFFFFFC0) != 0)
/*      */     {
/*      */       
/* 1458 */       throw new CorruptedCodestreamException("Unknown \"code-block context\" in SPcoc field, COC marker: 0x" + Integer.toHexString(ecOptions));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1467 */     SynWTFilter[] hfilters = new SynWTFilter[1];
/* 1468 */     SynWTFilter[] vfilters = new SynWTFilter[1];
/* 1469 */     hfilters[0] = readFilter(ehs, ms.spcoc_t);
/* 1470 */     vfilters[0] = hfilters[0];
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1475 */     SynWTFilter[][] hvfilters = new SynWTFilter[2][];
/* 1476 */     hvfilters[0] = hfilters;
/* 1477 */     hvfilters[1] = vfilters;
/*      */ 
/*      */     
/* 1480 */     Vector[] v = new Vector[2];
/* 1481 */     v[0] = new Vector();
/* 1482 */     v[1] = new Vector();
/* 1483 */     int val = 65535;
/* 1484 */     if (!this.precinctPartitionIsUsed) {
/*      */       
/* 1486 */       Integer w = new Integer(1 << (val & 0xF));
/* 1487 */       v[0].addElement(w);
/* 1488 */       Integer h = new Integer(1 << (val & 0xF0) >> 4);
/* 1489 */       v[1].addElement(h);
/*      */     } else {
/* 1491 */       ms.spcoc_ps = new int[mrl + 1];
/* 1492 */       for (int rl = mrl; rl >= 0; rl--) {
/*      */         
/* 1494 */         val = ms.spcoc_ps[rl] = ehs.readUnsignedByte();
/* 1495 */         Integer w = new Integer(1 << (val & 0xF));
/* 1496 */         v[0].insertElementAt(w, 0);
/* 1497 */         Integer h = new Integer(1 << (val & 0xF0) >> 4);
/* 1498 */         v[1].insertElementAt(h, 0);
/*      */       } 
/*      */     } 
/* 1501 */     if (mainh) {
/* 1502 */       this.decSpec.pss.setCompDef(cComp, v);
/*      */     } else {
/* 1504 */       this.decSpec.pss.setTileCompVal(tileIdx, cComp, v);
/*      */     } 
/* 1506 */     this.precinctPartitionIsUsed = true;
/*      */ 
/*      */     
/* 1509 */     checkMarkerLength(ehs, "COD marker");
/*      */     
/* 1511 */     if (mainh) {
/* 1512 */       this.hi.coc.put("main_c" + cComp, ms);
/* 1513 */       this.decSpec.wfs.setCompDef(cComp, hvfilters);
/* 1514 */       this.decSpec.dls.setCompDef(cComp, new Integer(mrl));
/* 1515 */       this.decSpec.ecopts.setCompDef(cComp, new Integer(ecOptions));
/*      */     } else {
/* 1517 */       this.hi.coc.put("t" + tileIdx + "_c" + cComp, ms);
/* 1518 */       this.decSpec.wfs.setTileCompVal(tileIdx, cComp, hvfilters);
/* 1519 */       this.decSpec.dls.setTileCompVal(tileIdx, cComp, new Integer(mrl));
/* 1520 */       this.decSpec.ecopts.setTileCompVal(tileIdx, cComp, new Integer(ecOptions));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void readPOC(DataInputStream ehs, boolean mainh, int t, int tpIdx) throws IOException {
/*      */     HeaderInfo.POC ms;
/*      */     int[][] change;
/* 1544 */     boolean useShort = (this.nComp >= 256);
/*      */     
/* 1546 */     int nOldChg = 0;
/*      */     
/* 1548 */     if (mainh || this.hi.poc.get("t" + t) == null) {
/* 1549 */       ms = this.hi.getNewPOC();
/*      */     } else {
/* 1551 */       ms = (HeaderInfo.POC)this.hi.poc.get("t" + t);
/* 1552 */       nOldChg = ms.rspoc.length;
/*      */     } 
/*      */ 
/*      */     
/* 1556 */     ms.lpoc = ehs.readUnsignedShort();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1561 */     int newChg = (ms.lpoc - 2) / (5 + (useShort ? 4 : 2));
/* 1562 */     int ntotChg = nOldChg + newChg;
/*      */ 
/*      */     
/* 1565 */     if (nOldChg != 0) {
/*      */       
/* 1567 */       change = new int[ntotChg][6];
/* 1568 */       int[] tmprspoc = new int[ntotChg];
/* 1569 */       int[] tmpcspoc = new int[ntotChg];
/* 1570 */       int[] tmplyepoc = new int[ntotChg];
/* 1571 */       int[] tmprepoc = new int[ntotChg];
/* 1572 */       int[] tmpcepoc = new int[ntotChg];
/* 1573 */       int[] tmpppoc = new int[ntotChg];
/*      */ 
/*      */       
/* 1576 */       int[][] prevChg = (int[][])this.decSpec.pcs.getTileDef(t);
/* 1577 */       for (int i = 0; i < nOldChg; i++) {
/* 1578 */         change[i] = prevChg[i];
/* 1579 */         tmprspoc[i] = ms.rspoc[i];
/* 1580 */         tmpcspoc[i] = ms.cspoc[i];
/* 1581 */         tmplyepoc[i] = ms.lyepoc[i];
/* 1582 */         tmprepoc[i] = ms.repoc[i];
/* 1583 */         tmpcepoc[i] = ms.cepoc[i];
/* 1584 */         tmpppoc[i] = ms.ppoc[i];
/*      */       } 
/* 1586 */       ms.rspoc = tmprspoc;
/* 1587 */       ms.cspoc = tmpcspoc;
/* 1588 */       ms.lyepoc = tmplyepoc;
/* 1589 */       ms.repoc = tmprepoc;
/* 1590 */       ms.cepoc = tmpcepoc;
/* 1591 */       ms.ppoc = tmpppoc;
/*      */     } else {
/* 1593 */       change = new int[newChg][6];
/* 1594 */       ms.rspoc = new int[newChg];
/* 1595 */       ms.cspoc = new int[newChg];
/* 1596 */       ms.lyepoc = new int[newChg];
/* 1597 */       ms.repoc = new int[newChg];
/* 1598 */       ms.cepoc = new int[newChg];
/* 1599 */       ms.ppoc = new int[newChg];
/*      */     } 
/*      */     
/* 1602 */     for (int chg = nOldChg; chg < ntotChg; chg++) {
/*      */       
/* 1604 */       ms.rspoc[chg] = ehs.readUnsignedByte(); change[chg][0] = ehs.readUnsignedByte();
/*      */ 
/*      */       
/* 1607 */       if (useShort) {
/* 1608 */         ms.cspoc[chg] = ehs.readUnsignedShort(); change[chg][1] = ehs.readUnsignedShort();
/*      */       } else {
/* 1610 */         ms.cspoc[chg] = ehs.readUnsignedByte(); change[chg][1] = ehs.readUnsignedByte();
/*      */       } 
/*      */ 
/*      */       
/* 1614 */       ms.lyepoc[chg] = ehs.readUnsignedShort(); change[chg][2] = ehs.readUnsignedShort();
/* 1615 */       if (change[chg][2] < 1) {
/* 1616 */         throw new CorruptedCodestreamException("LYEpoc value must be greater than 1 in POC marker segment of tile " + t + ", tile-part " + tpIdx);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1622 */       ms.repoc[chg] = ehs.readUnsignedByte(); change[chg][3] = ehs.readUnsignedByte();
/* 1623 */       if (change[chg][3] <= change[chg][0]) {
/* 1624 */         throw new CorruptedCodestreamException("REpoc value must be greater than RSpoc in POC marker segment of tile " + t + ", tile-part " + tpIdx);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1630 */       if (useShort) {
/* 1631 */         ms.cepoc[chg] = ehs.readUnsignedShort(); change[chg][4] = ehs.readUnsignedShort();
/*      */       } else {
/* 1633 */         int tmp = ms.cepoc[chg] = ehs.readUnsignedByte();
/* 1634 */         if (tmp == 0) {
/* 1635 */           change[chg][4] = 0;
/*      */         } else {
/* 1637 */           change[chg][4] = tmp;
/*      */         } 
/*      */       } 
/* 1640 */       if (change[chg][4] <= change[chg][1]) {
/* 1641 */         throw new CorruptedCodestreamException("CEpoc value must be greater than CSpoc in POC marker segment of tile " + t + ", tile-part " + tpIdx);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1647 */       ms.ppoc[chg] = ehs.readUnsignedByte(); change[chg][5] = ehs.readUnsignedByte();
/*      */     } 
/*      */ 
/*      */     
/* 1651 */     checkMarkerLength(ehs, "POC marker");
/*      */ 
/*      */     
/* 1654 */     if (mainh) {
/* 1655 */       this.hi.poc.put("main", ms);
/* 1656 */       this.decSpec.pcs.setDefault(change);
/*      */     } else {
/* 1658 */       this.hi.poc.put("t" + t, ms);
/* 1659 */       this.decSpec.pcs.setTileDef(t, change);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void readTLM(DataInputStream ehs) throws IOException {
/* 1676 */     int length = ehs.readUnsignedShort();
/*      */     
/* 1678 */     ehs.skipBytes(length - 2);
/*      */     
/* 1680 */     FacilityManager.getMsgLogger().printmsg(1, "Skipping unsupported TLM marker");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void readPLM(DataInputStream ehs) throws IOException {
/* 1697 */     int length = ehs.readUnsignedShort();
/*      */     
/* 1699 */     ehs.skipBytes(length - 2);
/*      */     
/* 1701 */     FacilityManager.getMsgLogger().printmsg(1, "Skipping unsupported PLM marker");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void readPLTFields(DataInputStream ehs) throws IOException {
/* 1718 */     int length = ehs.readUnsignedShort();
/*      */     
/* 1720 */     ehs.skipBytes(length - 2);
/*      */     
/* 1722 */     FacilityManager.getMsgLogger().printmsg(1, "Skipping unsupported PLT marker");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void readRGN(DataInputStream ehs, boolean mainh, int tileIdx, int tpIdx) throws IOException {
/* 1750 */     HeaderInfo.RGN ms = this.hi.getNewRGN();
/*      */ 
/*      */     
/* 1753 */     ms.lrgn = ehs.readUnsignedShort();
/*      */ 
/*      */     
/* 1756 */     int comp = (this.nComp < 257) ? ehs.readUnsignedByte() : ehs.readUnsignedShort();
/*      */     
/* 1758 */     if (comp >= this.nComp) {
/* 1759 */       throw new CorruptedCodestreamException("Invalid component index in RGN marker" + comp);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1765 */     ms.srgn = ehs.readUnsignedByte();
/*      */ 
/*      */     
/* 1768 */     if (ms.srgn != 0) {
/* 1769 */       throw new CorruptedCodestreamException("Unknown or unsupported Srgn parameter in ROI marker");
/*      */     }
/*      */ 
/*      */     
/* 1773 */     if (this.decSpec.rois == null)
/*      */     {
/* 1775 */       this.decSpec.rois = new MaxShiftSpec(this.nTiles, this.nComp, (byte)2, "null");
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1780 */     ms.sprgn = ehs.readUnsignedByte();
/*      */     
/* 1782 */     if (mainh) {
/* 1783 */       this.hi.rgn.put("main_c" + comp, ms);
/* 1784 */       this.decSpec.rois.setCompDef(comp, new Integer(ms.sprgn));
/*      */     } else {
/* 1786 */       this.hi.rgn.put("t" + tileIdx + "_c" + comp, ms);
/* 1787 */       this.decSpec.rois.setTileCompVal(tileIdx, comp, new Integer(ms.sprgn));
/*      */     } 
/*      */ 
/*      */     
/* 1791 */     checkMarkerLength(ehs, "RGN marker");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void readPPM(DataInputStream ehs) throws IOException {
/* 1810 */     if (this.pPMMarkerData == null) {
/* 1811 */       this.pPMMarkerData = new byte[this.nPPMMarkSeg][];
/* 1812 */       this.tileOfTileParts = new Vector();
/* 1813 */       this.decSpec.pphs.setDefault(new Boolean(true));
/*      */     } 
/*      */ 
/*      */     
/* 1817 */     int curMarkSegLen = ehs.readUnsignedShort();
/* 1818 */     int remSegLen = curMarkSegLen - 3;
/*      */ 
/*      */     
/* 1821 */     int indx = ehs.readUnsignedByte();
/*      */ 
/*      */     
/* 1824 */     this.pPMMarkerData[indx] = new byte[remSegLen];
/* 1825 */     ehs.read(this.pPMMarkerData[indx], 0, remSegLen);
/*      */ 
/*      */     
/* 1828 */     checkMarkerLength(ehs, "PPM marker");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void readPPT(DataInputStream ehs, int tile, int tpIdx) throws IOException {
/* 1846 */     int len = 0;
/*      */ 
/*      */     
/* 1849 */     if (this.tilePartPkdPktHeaders == null) {
/* 1850 */       this.tilePartPkdPktHeaders = new byte[this.nTiles][][][];
/*      */     }
/*      */     
/* 1853 */     if (this.tilePartPkdPktHeaders[tile] == null) {
/* 1854 */       this.tilePartPkdPktHeaders[tile] = new byte[this.nTileParts[tile]][][];
/*      */     }
/*      */     
/* 1857 */     if (this.tilePartPkdPktHeaders[tile][tpIdx] == null) {
/* 1858 */       this.tilePartPkdPktHeaders[tile][tpIdx] = new byte[this.nPPTMarkSeg[tile][tpIdx]][];
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1863 */     int curMarkSegLen = ehs.readUnsignedShort();
/*      */ 
/*      */     
/* 1866 */     int indx = ehs.readUnsignedByte();
/*      */ 
/*      */     
/* 1869 */     byte[] temp = new byte[curMarkSegLen - 3];
/* 1870 */     ehs.read(temp);
/* 1871 */     this.tilePartPkdPktHeaders[tile][tpIdx][indx] = temp;
/*      */ 
/*      */     
/* 1874 */     checkMarkerLength(ehs, "PPT marker");
/*      */     
/* 1876 */     this.decSpec.pphs.setTileDef(tile, new Boolean(true));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void extractMainMarkSeg(short marker, RandomAccessIO ehs) throws IOException {
/* 1896 */     if (this.nfMarkSeg == 0)
/*      */     {
/* 1898 */       if (marker != -175) {
/* 1899 */         throw new CorruptedCodestreamException("First marker after SOC must be SIZ " + Integer.toHexString(marker));
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1907 */     String htKey = "";
/* 1908 */     if (this.ht == null) {
/* 1909 */       this.ht = new Hashtable<Object, Object>();
/*      */     }
/*      */     
/* 1912 */     switch (marker) {
/*      */       case -175:
/* 1914 */         if ((this.nfMarkSeg & 0x1) != 0) {
/* 1915 */           throw new CorruptedCodestreamException("More than one SIZ marker segment found in main header");
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 1920 */         this.nfMarkSeg |= 0x1;
/* 1921 */         htKey = "SIZ";
/*      */         break;
/*      */       case -109:
/* 1924 */         throw new CorruptedCodestreamException("SOD found in main header");
/*      */       case -39:
/* 1926 */         throw new CorruptedCodestreamException("EOC found in main header");
/*      */       case -112:
/* 1928 */         if ((this.nfMarkSeg & 0x40) != 0) {
/* 1929 */           throw new CorruptedCodestreamException("More than one SOT marker found right after main or tile header");
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1935 */         this.nfMarkSeg |= 0x40;
/*      */         return;
/*      */       case -174:
/* 1938 */         if ((this.nfMarkSeg & 0x2) != 0) {
/* 1939 */           throw new CorruptedCodestreamException("More than one COD marker found in main header");
/*      */         }
/*      */ 
/*      */         
/* 1943 */         this.nfMarkSeg |= 0x2;
/* 1944 */         htKey = "COD";
/*      */         break;
/*      */       case -173:
/* 1947 */         this.nfMarkSeg |= 0x4;
/* 1948 */         htKey = "COC" + this.nCOCMarkSeg++;
/*      */         break;
/*      */       case -164:
/* 1951 */         if ((this.nfMarkSeg & 0x8) != 0) {
/* 1952 */           throw new CorruptedCodestreamException("More than one QCD marker found in main header");
/*      */         }
/*      */ 
/*      */         
/* 1956 */         this.nfMarkSeg |= 0x8;
/* 1957 */         htKey = "QCD";
/*      */         break;
/*      */       case -163:
/* 1960 */         this.nfMarkSeg |= 0x100;
/* 1961 */         htKey = "QCC" + this.nQCCMarkSeg++;
/*      */         break;
/*      */       case -162:
/* 1964 */         this.nfMarkSeg |= 0x200;
/* 1965 */         htKey = "RGN" + this.nRGNMarkSeg++;
/*      */         break;
/*      */       case -156:
/* 1968 */         this.nfMarkSeg |= 0x800;
/* 1969 */         htKey = "COM" + this.nCOMMarkSeg++;
/*      */         break;
/*      */       case -157:
/* 1972 */         if ((this.nfMarkSeg & 0x10000) != 0) {
/* 1973 */           throw new CorruptedCodestreamException("More than one CRG marker found in main header");
/*      */         }
/*      */ 
/*      */         
/* 1977 */         this.nfMarkSeg |= 0x10000;
/* 1978 */         htKey = "CRG";
/*      */         break;
/*      */       case -160:
/* 1981 */         this.nfMarkSeg |= 0x4000;
/* 1982 */         htKey = "PPM" + this.nPPMMarkSeg++;
/*      */         break;
/*      */       case -171:
/* 1985 */         if ((this.nfMarkSeg & 0x10) != 0) {
/* 1986 */           FacilityManager.getMsgLogger().printmsg(1, "More than one TLM marker found in main header");
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1997 */         this.nfMarkSeg |= 0x10;
/*      */         break;
/*      */       case -169:
/* 2000 */         if ((this.nfMarkSeg & 0x20) != 0) {
/* 2001 */           throw new CorruptedCodestreamException("More than one PLM marker found in main header");
/*      */         }
/*      */ 
/*      */         
/* 2005 */         FacilityManager.getMsgLogger().printmsg(2, "PLM marker segment found but not used by by JJ2000 decoder.");
/*      */ 
/*      */         
/* 2008 */         this.nfMarkSeg |= 0x20;
/* 2009 */         htKey = "PLM";
/*      */         break;
/*      */       case -161:
/* 2012 */         if ((this.nfMarkSeg & 0x400) != 0) {
/* 2013 */           throw new CorruptedCodestreamException("More than one POC marker segment found in main header");
/*      */         }
/*      */ 
/*      */         
/* 2017 */         this.nfMarkSeg |= 0x400;
/* 2018 */         htKey = "POC";
/*      */         break;
/*      */       case -168:
/* 2021 */         throw new CorruptedCodestreamException("PLT found in main header");
/*      */       case -159:
/* 2023 */         throw new CorruptedCodestreamException("PPT found in main header");
/*      */       default:
/* 2025 */         htKey = "UNKNOWN";
/* 2026 */         FacilityManager.getMsgLogger().printmsg(2, "Non recognized marker segment (0x" + Integer.toHexString(marker) + ") in main header!");
/*      */         break;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 2032 */     if (marker < -208 || marker > -193) {
/*      */       
/* 2034 */       int markSegLen = ehs.readUnsignedShort();
/* 2035 */       byte[] buf = new byte[markSegLen];
/*      */ 
/*      */       
/* 2038 */       buf[0] = (byte)(markSegLen >> 8 & 0xFF);
/* 2039 */       buf[1] = (byte)(markSegLen & 0xFF);
/* 2040 */       ehs.readFully(buf, 2, markSegLen - 2);
/*      */       
/* 2042 */       if (!htKey.equals("UNKNOWN"))
/*      */       {
/* 2044 */         this.ht.put(htKey, buf);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void extractTilePartMarkSeg(short marker, RandomAccessIO ehs, int tileIdx, int tilePartIdx) throws IOException {
/* 2069 */     String htKey = "";
/* 2070 */     if (this.ht == null) {
/* 2071 */       this.ht = new Hashtable<Object, Object>();
/*      */     }
/*      */     
/* 2074 */     switch (marker) {
/*      */       case -112:
/* 2076 */         throw new CorruptedCodestreamException("Second SOT marker segment found in tile-part header");
/*      */ 
/*      */       
/*      */       case -175:
/* 2080 */         throw new CorruptedCodestreamException("SIZ found in tile-part header");
/*      */       
/*      */       case -39:
/* 2083 */         throw new CorruptedCodestreamException("EOC found in tile-part header");
/*      */       
/*      */       case -171:
/* 2086 */         throw new CorruptedCodestreamException("TLM found in tile-part header");
/*      */       
/*      */       case -160:
/* 2089 */         throw new CorruptedCodestreamException("PPM found in tile-part header");
/*      */       
/*      */       case -174:
/* 2092 */         if ((this.nfMarkSeg & 0x2) != 0) {
/* 2093 */           throw new CorruptedCodestreamException("More than one COD marker found in tile-part header");
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 2098 */         this.nfMarkSeg |= 0x2;
/* 2099 */         htKey = "COD";
/*      */         break;
/*      */       case -173:
/* 2102 */         this.nfMarkSeg |= 0x4;
/* 2103 */         htKey = "COC" + this.nCOCMarkSeg++;
/*      */         break;
/*      */       case -164:
/* 2106 */         if ((this.nfMarkSeg & 0x8) != 0) {
/* 2107 */           throw new CorruptedCodestreamException("More than one QCD marker found in tile-part header");
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 2112 */         this.nfMarkSeg |= 0x8;
/* 2113 */         htKey = "QCD";
/*      */         break;
/*      */       case -163:
/* 2116 */         this.nfMarkSeg |= 0x100;
/* 2117 */         htKey = "QCC" + this.nQCCMarkSeg++;
/*      */         break;
/*      */       case -162:
/* 2120 */         this.nfMarkSeg |= 0x200;
/* 2121 */         htKey = "RGN" + this.nRGNMarkSeg++;
/*      */         break;
/*      */       case -156:
/* 2124 */         this.nfMarkSeg |= 0x800;
/* 2125 */         htKey = "COM" + this.nCOMMarkSeg++;
/*      */         break;
/*      */       case -157:
/* 2128 */         throw new CorruptedCodestreamException("CRG marker found in tile-part header");
/*      */       
/*      */       case -159:
/* 2131 */         this.nfMarkSeg |= 0x8000;
/* 2132 */         if (this.nPPTMarkSeg == null) {
/* 2133 */           this.nPPTMarkSeg = new int[this.nTiles][];
/*      */         }
/* 2135 */         if (this.nPPTMarkSeg[tileIdx] == null) {
/* 2136 */           this.nPPTMarkSeg[tileIdx] = new int[this.nTileParts[tileIdx]];
/*      */         }
/* 2138 */         this.nPPTMarkSeg[tileIdx][tilePartIdx] = this.nPPTMarkSeg[tileIdx][tilePartIdx] + 1; htKey = "PPT" + this.nPPTMarkSeg[tileIdx][tilePartIdx];
/*      */         break;
/*      */       case -109:
/* 2141 */         this.nfMarkSeg |= 0x2000;
/*      */         return;
/*      */       case -161:
/* 2144 */         if ((this.nfMarkSeg & 0x400) != 0) {
/* 2145 */           throw new CorruptedCodestreamException("More than one POC marker segment found in tile-part header");
/*      */         }
/*      */ 
/*      */         
/* 2149 */         this.nfMarkSeg |= 0x400;
/* 2150 */         htKey = "POC";
/*      */         break;
/*      */       case -168:
/* 2153 */         if ((this.nfMarkSeg & 0x20) != 0) {
/* 2154 */           throw new CorruptedCodestreamException("PLT marker found eventhough PLM marker found in main header");
/*      */         }
/*      */ 
/*      */         
/* 2158 */         FacilityManager.getMsgLogger().printmsg(2, "PLT marker segment found but not used by JJ2000 decoder.");
/*      */ 
/*      */         
/* 2161 */         htKey = "UNKNOWN";
/*      */         break;
/*      */       default:
/* 2164 */         htKey = "UNKNOWN";
/* 2165 */         FacilityManager.getMsgLogger().printmsg(2, "Non recognized marker segment (0x" + Integer.toHexString(marker) + ") in tile-part header" + " of tile " + tileIdx + " !");
/*      */         break;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2173 */     int markSegLen = ehs.readUnsignedShort();
/* 2174 */     byte[] buf = new byte[markSegLen];
/*      */ 
/*      */     
/* 2177 */     buf[0] = (byte)(markSegLen >> 8 & 0xFF);
/* 2178 */     buf[1] = (byte)(markSegLen & 0xFF);
/* 2179 */     ehs.readFully(buf, 2, markSegLen - 2);
/*      */     
/* 2181 */     if (!htKey.equals("UNKNOWN"))
/*      */     {
/* 2183 */       this.ht.put(htKey, buf);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void readFoundMainMarkSeg() throws IOException {
/* 2198 */     if ((this.nfMarkSeg & 0x1) != 0) {
/* 2199 */       ByteArrayInputStream bais = new ByteArrayInputStream((byte[])this.ht.get("SIZ"));
/* 2200 */       readSIZ(new DataInputStream(bais));
/*      */     } 
/*      */ 
/*      */     
/* 2204 */     if ((this.nfMarkSeg & 0x800) != 0) {
/* 2205 */       for (int i = 0; i < this.nCOMMarkSeg; i++) {
/* 2206 */         ByteArrayInputStream bais = new ByteArrayInputStream((byte[])this.ht.get("COM" + i));
/* 2207 */         readCOM(new DataInputStream(bais), true, 0, i);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/* 2212 */     if ((this.nfMarkSeg & 0x10000) != 0) {
/* 2213 */       ByteArrayInputStream bais = new ByteArrayInputStream((byte[])this.ht.get("CRG"));
/* 2214 */       readCRG(new DataInputStream(bais));
/*      */     } 
/*      */ 
/*      */     
/* 2218 */     if ((this.nfMarkSeg & 0x2) != 0) {
/* 2219 */       ByteArrayInputStream bais = new ByteArrayInputStream((byte[])this.ht.get("COD"));
/* 2220 */       readCOD(new DataInputStream(bais), true, 0, 0);
/*      */     } 
/*      */ 
/*      */     
/* 2224 */     if ((this.nfMarkSeg & 0x4) != 0) {
/* 2225 */       for (int i = 0; i < this.nCOCMarkSeg; i++) {
/* 2226 */         ByteArrayInputStream bais = new ByteArrayInputStream((byte[])this.ht.get("COC" + i));
/* 2227 */         readCOC(new DataInputStream(bais), true, 0, 0);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/* 2232 */     if ((this.nfMarkSeg & 0x200) != 0) {
/* 2233 */       for (int i = 0; i < this.nRGNMarkSeg; i++) {
/* 2234 */         ByteArrayInputStream bais = new ByteArrayInputStream((byte[])this.ht.get("RGN" + i));
/* 2235 */         readRGN(new DataInputStream(bais), true, 0, 0);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/* 2240 */     if ((this.nfMarkSeg & 0x8) != 0) {
/* 2241 */       ByteArrayInputStream bais = new ByteArrayInputStream((byte[])this.ht.get("QCD"));
/* 2242 */       readQCD(new DataInputStream(bais), true, 0, 0);
/*      */     } 
/*      */ 
/*      */     
/* 2246 */     if ((this.nfMarkSeg & 0x100) != 0) {
/* 2247 */       for (int i = 0; i < this.nQCCMarkSeg; i++) {
/* 2248 */         ByteArrayInputStream bais = new ByteArrayInputStream((byte[])this.ht.get("QCC" + i));
/* 2249 */         readQCC(new DataInputStream(bais), true, 0, 0);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/* 2254 */     if ((this.nfMarkSeg & 0x400) != 0) {
/* 2255 */       ByteArrayInputStream bais = new ByteArrayInputStream((byte[])this.ht.get("POC"));
/* 2256 */       readPOC(new DataInputStream(bais), true, 0, 0);
/*      */     } 
/*      */ 
/*      */     
/* 2260 */     if ((this.nfMarkSeg & 0x4000) != 0) {
/* 2261 */       for (int i = 0; i < this.nPPMMarkSeg; i++) {
/* 2262 */         ByteArrayInputStream bais = new ByteArrayInputStream((byte[])this.ht.get("PPM" + i));
/* 2263 */         readPPM(new DataInputStream(bais));
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/* 2268 */     this.ht = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void readFoundTilePartMarkSeg(int tileIdx, int tpIdx) throws IOException {
/* 2289 */     if ((this.nfMarkSeg & 0x2) != 0) {
/* 2290 */       ByteArrayInputStream bais = new ByteArrayInputStream((byte[])this.ht.get("COD"));
/* 2291 */       readCOD(new DataInputStream(bais), false, tileIdx, tpIdx);
/*      */     } 
/*      */ 
/*      */     
/* 2295 */     if ((this.nfMarkSeg & 0x4) != 0) {
/* 2296 */       for (int i = 0; i < this.nCOCMarkSeg; i++) {
/* 2297 */         ByteArrayInputStream bais = new ByteArrayInputStream((byte[])this.ht.get("COC" + i));
/* 2298 */         readCOC(new DataInputStream(bais), false, tileIdx, tpIdx);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/* 2303 */     if ((this.nfMarkSeg & 0x200) != 0) {
/* 2304 */       for (int i = 0; i < this.nRGNMarkSeg; i++) {
/* 2305 */         ByteArrayInputStream bais = new ByteArrayInputStream((byte[])this.ht.get("RGN" + i));
/* 2306 */         readRGN(new DataInputStream(bais), false, tileIdx, tpIdx);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/* 2311 */     if ((this.nfMarkSeg & 0x8) != 0) {
/* 2312 */       ByteArrayInputStream bais = new ByteArrayInputStream((byte[])this.ht.get("QCD"));
/* 2313 */       readQCD(new DataInputStream(bais), false, tileIdx, tpIdx);
/*      */     } 
/*      */ 
/*      */     
/* 2317 */     if ((this.nfMarkSeg & 0x100) != 0) {
/* 2318 */       for (int i = 0; i < this.nQCCMarkSeg; i++) {
/* 2319 */         ByteArrayInputStream bais = new ByteArrayInputStream((byte[])this.ht.get("QCC" + i));
/* 2320 */         readQCC(new DataInputStream(bais), false, tileIdx, tpIdx);
/*      */       } 
/*      */     }
/*      */     
/* 2324 */     if ((this.nfMarkSeg & 0x400) != 0) {
/* 2325 */       ByteArrayInputStream bais = new ByteArrayInputStream((byte[])this.ht.get("POC"));
/* 2326 */       readPOC(new DataInputStream(bais), false, tileIdx, tpIdx);
/*      */     } 
/*      */ 
/*      */     
/* 2330 */     if ((this.nfMarkSeg & 0x800) != 0) {
/* 2331 */       for (int i = 0; i < this.nCOMMarkSeg; i++) {
/* 2332 */         ByteArrayInputStream bais = new ByteArrayInputStream((byte[])this.ht.get("COM" + i));
/* 2333 */         readCOM(new DataInputStream(bais), false, tileIdx, i);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/* 2338 */     if ((this.nfMarkSeg & 0x8000) != 0) {
/* 2339 */       for (int i = 0; i < this.nPPTMarkSeg[tileIdx][tpIdx]; i++) {
/* 2340 */         ByteArrayInputStream bais = new ByteArrayInputStream((byte[])this.ht.get("PPT" + i));
/* 2341 */         readPPT(new DataInputStream(bais), tileIdx, tpIdx);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/* 2346 */     this.ht = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DecoderSpecs getDecoderSpecs() {
/* 2356 */     return this.decSpec;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HeaderDecoder(RandomAccessIO ehs, J2KImageReadParamJava j2krparam, HeaderInfo hi) throws IOException {
/* 2385 */     this.hi = hi;
/* 2386 */     this.j2krparam = j2krparam;
/* 2387 */     this.mainHeadOff = ehs.getPos();
/* 2388 */     if (ehs.readShort() != -177) {
/* 2389 */       throw new CorruptedCodestreamException("SOC marker segment not  found at the beginning of the codestream.");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2397 */     this.nfMarkSeg = 0;
/*      */     while (true) {
/* 2399 */       extractMainMarkSeg(ehs.readShort(), ehs);
/* 2400 */       if ((this.nfMarkSeg & 0x40) != 0) {
/* 2401 */         ehs.seek(ehs.getPos() - 2);
/*      */ 
/*      */         
/* 2404 */         readFoundMainMarkSeg();
/*      */         return;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public EntropyDecoder createEntropyDecoder(CodedCBlkDataSrcDec src, J2KImageReadParamJava j2krparam) {
/* 2424 */     boolean doer = true;
/*      */ 
/*      */     
/* 2427 */     boolean verber = false;
/*      */ 
/*      */ 
/*      */     
/* 2431 */     int mMax = -1;
/* 2432 */     return (EntropyDecoder)new StdEntropyDecoder(src, this.decSpec, doer, verber, mMax);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ROIDeScaler createROIDeScaler(CBlkQuantDataSrcDec src, J2KImageReadParamJava j2krparam, DecoderSpecs decSpec2) {
/* 2531 */     return ROIDeScaler.createInstance(src, j2krparam, decSpec2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void resetHeaderMarkers() {
/* 2541 */     this.nfMarkSeg &= 0x4020;
/* 2542 */     this.nCOCMarkSeg = 0;
/* 2543 */     this.nQCCMarkSeg = 0;
/* 2544 */     this.nCOMMarkSeg = 0;
/* 2545 */     this.nRGNMarkSeg = 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/* 2555 */     return this.hdStr;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[][] getParameterInfo() {
/* 2570 */     return pinfo;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getNumTiles() {
/* 2579 */     return this.nTiles;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ByteArrayInputStream getPackedPktHead(int tile) throws IOException {
/* 2594 */     if (this.pkdPktHeaders == null) {
/*      */       
/* 2596 */       this.pkdPktHeaders = new ByteArrayOutputStream[this.nTiles]; int i;
/* 2597 */       for (i = this.nTiles - 1; i >= 0; i--) {
/* 2598 */         this.pkdPktHeaders[i] = new ByteArrayOutputStream();
/*      */       }
/* 2600 */       if (this.nPPMMarkSeg != 0) {
/*      */ 
/*      */ 
/*      */         
/* 2604 */         int nTileParts = this.tileOfTileParts.size();
/*      */ 
/*      */         
/* 2607 */         ByteArrayOutputStream allNppmIppm = new ByteArrayOutputStream();
/*      */ 
/*      */ 
/*      */         
/* 2611 */         for (i = 0; i < this.nPPMMarkSeg; i++) {
/* 2612 */           allNppmIppm.write(this.pPMMarkerData[i]);
/*      */         }
/* 2614 */         ByteArrayInputStream pph = new ByteArrayInputStream(allNppmIppm.toByteArray());
/*      */ 
/*      */ 
/*      */         
/* 2618 */         for (i = 0; i < nTileParts; i++) {
/* 2619 */           int t = ((Integer)this.tileOfTileParts.elementAt(i)).intValue();
/*      */           
/* 2621 */           int nppm = pph.read() << 24 | pph.read() << 16 | pph.read() << 8 | pph.read();
/*      */ 
/*      */           
/* 2624 */           byte[] temp = new byte[nppm];
/*      */           
/* 2626 */           pph.read(temp);
/* 2627 */           this.pkdPktHeaders[t].write(temp);
/*      */         }
/*      */       
/*      */       } else {
/*      */         
/* 2632 */         for (int t = this.nTiles - 1; t >= 0; t--) {
/* 2633 */           for (int tp = 0; tp < this.nTileParts[t]; tp++) {
/* 2634 */             for (i = 0; i < this.nPPTMarkSeg[t][tp]; i++) {
/* 2635 */               this.pkdPktHeaders[t].write(this.tilePartPkdPktHeaders[t][tp][i]);
/*      */             }
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 2643 */     return new ByteArrayInputStream(this.pkdPktHeaders[tile].toByteArray());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTileOfTileParts(int tile) {
/* 2654 */     if (this.nPPMMarkSeg != 0) {
/* 2655 */       this.tileOfTileParts.addElement(new Integer(tile));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getNumFoundMarkSeg() {
/* 2665 */     return this.nfMarkSeg;
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/codestream/reader/HeaderDecoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */