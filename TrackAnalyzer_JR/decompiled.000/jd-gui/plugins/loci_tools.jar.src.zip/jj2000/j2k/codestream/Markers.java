package jj2000.j2k.codestream;

public interface Markers {
  public static final short SOC = -177;
  
  public static final short SOT = -112;
  
  public static final short SOD = -109;
  
  public static final short EOC = -39;
  
  public static final short SIZ = -175;
  
  public static final int RSIZ_BASELINE = 0;
  
  public static final int RSIZ_ER_FLAG = 1;
  
  public static final int RSIZ_ROI = 2;
  
  public static final int SSIZ_DEPTH_BITS = 7;
  
  public static final int MAX_COMP_BITDEPTH = 38;
  
  public static final short COD = -174;
  
  public static final short COC = -173;
  
  public static final int SCOX_PRECINCT_PARTITION = 1;
  
  public static final int SCOX_USE_SOP = 2;
  
  public static final int SCOX_USE_EPH = 4;
  
  public static final int SCOX_HOR_CB_PART = 8;
  
  public static final int SCOX_VER_CB_PART = 16;
  
  public static final int PRECINCT_PARTITION_DEF_SIZE = 65535;
  
  public static final short RGN = -162;
  
  public static final int SRGN_IMPLICIT = 0;
  
  public static final short QCD = -164;
  
  public static final short QCC = -163;
  
  public static final int SQCX_GB_SHIFT = 5;
  
  public static final int SQCX_GB_MSK = 7;
  
  public static final int SQCX_NO_QUANTIZATION = 0;
  
  public static final int SQCX_SCALAR_DERIVED = 1;
  
  public static final int SQCX_SCALAR_EXPOUNDED = 2;
  
  public static final int SQCX_EXP_SHIFT = 3;
  
  public static final int SQCX_EXP_MASK = 31;
  
  public static final int ERS_SOP = 1;
  
  public static final int ERS_SEG_SYMBOLS = 2;
  
  public static final short POC = -161;
  
  public static final short TLM = -171;
  
  public static final short PLM = -169;
  
  public static final short PLT = -168;
  
  public static final short PPM = -160;
  
  public static final short PPT = -159;
  
  public static final int MAX_LPPT = 65535;
  
  public static final int MAX_LPPM = 65535;
  
  public static final short SOP = -111;
  
  public static final short SOP_LENGTH = 6;
  
  public static final short EPH = -110;
  
  public static final short EPH_LENGTH = 2;
  
  public static final short CRG = -157;
  
  public static final short COM = -156;
  
  public static final short RCOM_GEN_USE = 1;
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/codestream/Markers.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */