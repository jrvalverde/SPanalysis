/*      */ package jj2000.j2k.codestream.reader;
/*      */ 
/*      */ import com.sun.media.imageioimpl.plugins.jpeg2000.J2KImageReadParamJava;
/*      */ import java.awt.Point;
/*      */ import java.io.IOException;
/*      */ import jj2000.j2k.codestream.HeaderInfo;
/*      */ import jj2000.j2k.decoder.DecoderSpecs;
/*      */ import jj2000.j2k.entropy.decoder.CodedCBlkDataSrcDec;
/*      */ import jj2000.j2k.io.RandomAccessIO;
/*      */ import jj2000.j2k.quantization.dequantizer.StdDequantizerParams;
/*      */ import jj2000.j2k.util.MathUtil;
/*      */ import jj2000.j2k.wavelet.synthesis.SubbandSyn;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class BitstreamReaderAgent
/*      */   implements CodedCBlkDataSrcDec
/*      */ {
/*      */   protected DecoderSpecs decSpec;
/*  129 */   protected boolean[] derived = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  137 */   protected int[] gb = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  146 */   protected StdDequantizerParams[] params = null;
/*      */ 
/*      */ 
/*      */   
/*      */   public static final char OPT_PREFIX = 'B';
/*      */ 
/*      */   
/*  153 */   private static final String[][] pinfo = (String[][])null;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int[] mdl;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final int nc;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int targetRes;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected SubbandSyn[] subbTrees;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final int imgW;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final int imgH;
/*      */ 
/*      */ 
/*      */   
/*      */   protected final int ax;
/*      */ 
/*      */ 
/*      */   
/*      */   protected final int ay;
/*      */ 
/*      */ 
/*      */   
/*      */   protected final int px;
/*      */ 
/*      */ 
/*      */   
/*      */   protected final int py;
/*      */ 
/*      */ 
/*      */   
/*      */   protected final int[] offX;
/*      */ 
/*      */ 
/*      */   
/*      */   protected final int[] offY;
/*      */ 
/*      */ 
/*      */   
/*      */   protected final int[] culx;
/*      */ 
/*      */ 
/*      */   
/*      */   protected final int[] culy;
/*      */ 
/*      */ 
/*      */   
/*      */   protected final int ntW;
/*      */ 
/*      */ 
/*      */   
/*      */   protected final int ntH;
/*      */ 
/*      */ 
/*      */   
/*      */   protected final int ntX;
/*      */ 
/*      */ 
/*      */   
/*      */   protected final int ntY;
/*      */ 
/*      */ 
/*      */   
/*      */   protected final int nt;
/*      */ 
/*      */ 
/*      */   
/*      */   protected int ctX;
/*      */ 
/*      */ 
/*      */   
/*      */   protected int ctY;
/*      */ 
/*      */ 
/*      */   
/*      */   protected final HeaderDecoder hd;
/*      */ 
/*      */ 
/*      */   
/*      */   protected int tnbytes;
/*      */ 
/*      */ 
/*      */   
/*      */   protected int anbytes;
/*      */ 
/*      */ 
/*      */   
/*      */   protected float trate;
/*      */ 
/*      */ 
/*      */   
/*      */   protected float arate;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected BitstreamReaderAgent(HeaderDecoder hd, DecoderSpecs decSpec) {
/*  269 */     this.decSpec = decSpec;
/*  270 */     this.hd = hd;
/*      */ 
/*      */     
/*  273 */     this.nc = hd.getNumComps();
/*  274 */     this.offX = new int[this.nc];
/*  275 */     this.offY = new int[this.nc];
/*  276 */     this.culx = new int[this.nc];
/*  277 */     this.culy = new int[this.nc];
/*      */ 
/*      */     
/*  280 */     this.imgW = hd.getImgWidth();
/*  281 */     this.imgH = hd.getImgHeight();
/*  282 */     this.ax = hd.getImgULX();
/*  283 */     this.ay = hd.getImgULY();
/*      */ 
/*      */     
/*  286 */     Point co = hd.getTilingOrigin(null);
/*  287 */     this.px = co.x;
/*  288 */     this.py = co.y;
/*  289 */     this.ntW = hd.getNomTileWidth();
/*  290 */     this.ntH = hd.getNomTileHeight();
/*  291 */     this.ntX = (this.ax + this.imgW - this.px + this.ntW - 1) / this.ntW;
/*  292 */     this.ntY = (this.ay + this.imgH - this.py + this.ntH - 1) / this.ntH;
/*  293 */     this.nt = this.ntX * this.ntY;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getCbULX() {
/*  301 */     return this.hd.getCbULX();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getCbULY() {
/*  309 */     return this.hd.getCbULY();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getNumComps() {
/*  318 */     return this.nc;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getCompSubsX(int c) {
/*  334 */     return this.hd.getCompSubsX(c);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getCompSubsY(int c) {
/*  350 */     return this.hd.getCompSubsY(c);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getTileWidth(int rl) {
/*  376 */     int mindl = this.decSpec.dls.getMinInTile(getTileIdx());
/*  377 */     if (rl > mindl) {
/*  378 */       throw new IllegalArgumentException("Requested resolution level is not available for, at least, one component in tile: " + this.ctX + "x" + this.ctY);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  384 */     int dl = mindl - rl;
/*      */ 
/*      */ 
/*      */     
/*  388 */     int ctulx = (this.ctX == 0) ? this.ax : (this.px + this.ctX * this.ntW);
/*      */     
/*  390 */     int ntulx = (this.ctX < this.ntX - 1) ? (this.px + (this.ctX + 1) * this.ntW) : (this.ax + this.imgW);
/*  391 */     dl = 1 << dl;
/*      */     
/*  393 */     return (ntulx + dl - 1) / dl - (ctulx + dl - 1) / dl;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getTileHeight(int rl) {
/*  419 */     int mindl = this.decSpec.dls.getMinInTile(getTileIdx());
/*  420 */     if (rl > mindl) {
/*  421 */       throw new IllegalArgumentException("Requested resolution level is not available for, at least, one component in tile: " + this.ctX + "x" + this.ctY);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  428 */     int dl = mindl - rl;
/*      */ 
/*      */ 
/*      */     
/*  432 */     int ctuly = (this.ctY == 0) ? this.ay : (this.py + this.ctY * this.ntH);
/*      */     
/*  434 */     int ntuly = (this.ctY < this.ntY - 1) ? (this.py + (this.ctY + 1) * this.ntH) : (this.ay + this.imgH);
/*  435 */     dl = 1 << dl;
/*      */     
/*  437 */     return (ntuly + dl - 1) / dl - (ctuly + dl - 1) / dl;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getImgWidth(int rl) {
/*  462 */     int mindl = this.decSpec.dls.getMin();
/*  463 */     if (rl > mindl) {
/*  464 */       throw new IllegalArgumentException("Requested resolution level is not available for, at least, one tile-component");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  470 */     int dl = 1 << mindl - rl;
/*  471 */     return (this.ax + this.imgW + dl - 1) / dl - (this.ax + dl - 1) / dl;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getImgHeight(int rl) {
/*  494 */     int mindl = this.decSpec.dls.getMin();
/*  495 */     if (rl > mindl) {
/*  496 */       throw new IllegalArgumentException("Requested resolution level is not available for, at least, one tile-component");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  502 */     int dl = 1 << mindl - rl;
/*  503 */     return (this.ay + this.imgH + dl - 1) / dl - (this.ay + dl - 1) / dl;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getImgULX(int rl) {
/*  527 */     int mindl = this.decSpec.dls.getMin();
/*  528 */     if (rl > mindl) {
/*  529 */       throw new IllegalArgumentException("Requested resolution level is not available for, at least, one tile-component");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  535 */     int dl = 1 << mindl - rl;
/*  536 */     return (this.ax + dl - 1) / dl;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getImgULY(int rl) {
/*  560 */     int mindl = this.decSpec.dls.getMin();
/*  561 */     if (rl > mindl) {
/*  562 */       throw new IllegalArgumentException("Requested resolution level is not available for, at least, one tile-component");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  568 */     int dl = 1 << mindl - rl;
/*  569 */     return (this.ay + dl - 1) / dl;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getTileCompWidth(int t, int c, int rl) {
/*  586 */     int tIdx = getTileIdx();
/*  587 */     if (t != tIdx) {
/*  588 */       throw new Error("Asking the tile-component width of a tile different  from the current one.");
/*      */     }
/*      */ 
/*      */     
/*  592 */     int ntulx = (this.ctX < this.ntX - 1) ? (this.px + (this.ctX + 1) * this.ntW) : (this.ax + this.imgW);
/*      */     
/*  594 */     ntulx = (ntulx + this.hd.getCompSubsX(c) - 1) / this.hd.getCompSubsX(c);
/*  595 */     int dl = 1 << this.mdl[c] - rl;
/*      */ 
/*      */     
/*  598 */     return (ntulx + dl - 1) / dl - (this.culx[c] + dl - 1) / dl;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getTileCompHeight(int t, int c, int rl) {
/*  615 */     int tIdx = getTileIdx();
/*  616 */     if (t != tIdx) {
/*  617 */       throw new Error("Asking the tile-component width of a tile different  from the current one.");
/*      */     }
/*      */ 
/*      */     
/*  621 */     int ntuly = (this.ctY < this.ntY - 1) ? (this.py + (this.ctY + 1) * this.ntH) : (this.ay + this.imgH);
/*      */     
/*  623 */     ntuly = (ntuly + this.hd.getCompSubsY(c) - 1) / this.hd.getCompSubsY(c);
/*  624 */     int dl = 1 << this.mdl[c] - rl;
/*      */ 
/*      */     
/*  627 */     return (ntuly + dl - 1) / dl - (this.culy[c] + dl - 1) / dl;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getCompImgWidth(int c, int rl) {
/*  656 */     int sx = (this.ax + this.hd.getCompSubsX(c) - 1) / this.hd.getCompSubsX(c);
/*      */     
/*  658 */     int ex = (this.ax + this.imgW + this.hd.getCompSubsX(c) - 1) / this.hd.getCompSubsX(c);
/*  659 */     int dl = 1 << this.decSpec.dls.getMinInComp(c) - rl;
/*      */     
/*  661 */     return (ex + dl - 1) / dl - (sx + dl - 1) / dl;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getCompImgHeight(int c, int rl) {
/*  689 */     int sy = (this.ay + this.hd.getCompSubsY(c) - 1) / this.hd.getCompSubsY(c);
/*      */     
/*  691 */     int ey = (this.ay + this.imgH + this.hd.getCompSubsY(c) - 1) / this.hd.getCompSubsY(c);
/*  692 */     int dl = 1 << this.decSpec.dls.getMinInComp(c) - rl;
/*      */     
/*  694 */     return (ey + dl - 1) / dl - (sy + dl - 1) / dl;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void setTile(int paramInt1, int paramInt2);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void nextTile();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Point getTile(Point co) {
/*  725 */     if (co != null) {
/*  726 */       co.x = this.ctX;
/*  727 */       co.y = this.ctY;
/*  728 */       return co;
/*      */     } 
/*      */     
/*  731 */     return new Point(this.ctX, this.ctY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getTileIdx() {
/*  742 */     return this.ctY * this.ntX + this.ctX;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getResULX(int c, int rl) {
/*  754 */     int dl = this.mdl[c] - rl;
/*  755 */     if (dl < 0) {
/*  756 */       throw new IllegalArgumentException("Requested resolution level is not available for, at least, one component in tile: " + this.ctX + "x" + this.ctY);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  761 */     int tx0 = Math.max(this.px + this.ctX * this.ntW, this.ax);
/*  762 */     int tcx0 = (int)Math.ceil(tx0 / getCompSubsX(c));
/*  763 */     return (int)Math.ceil(tcx0 / (1 << dl));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getResULY(int c, int rl) {
/*  775 */     int dl = this.mdl[c] - rl;
/*  776 */     if (dl < 0) {
/*  777 */       throw new IllegalArgumentException("Requested resolution level is not available for, at least, one component in tile: " + this.ctX + "x" + this.ctY);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  782 */     int ty0 = Math.max(this.py + this.ctY * this.ntH, this.ay);
/*  783 */     int tcy0 = (int)Math.ceil(ty0 / getCompSubsY(c));
/*  784 */     return (int)Math.ceil(tcy0 / (1 << dl));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Point getNumTiles(Point co) {
/*  797 */     if (co != null) {
/*  798 */       co.x = this.ntX;
/*  799 */       co.y = this.ntY;
/*  800 */       return co;
/*      */     } 
/*      */     
/*  803 */     return new Point(this.ntX, this.ntY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getNumTiles() {
/*  813 */     return this.ntX * this.ntY;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final SubbandSyn getSynSubbandTree(int t, int c) {
/*  834 */     if (t != getTileIdx()) {
/*  835 */       throw new IllegalArgumentException("Can not request subband tree of a different tile than the current one");
/*      */     }
/*      */ 
/*      */     
/*  839 */     if (c < 0 || c >= this.nc) {
/*  840 */       throw new IllegalArgumentException("Component index out of range");
/*      */     }
/*  842 */     return this.subbTrees[c];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BitstreamReaderAgent createInstance(RandomAccessIO in, HeaderDecoder hd, J2KImageReadParamJava j2krparam, DecoderSpecs decSpec, boolean cdstrInfo, HeaderInfo hi) throws IOException {
/*  883 */     return new FileBitstreamReaderAgent(hd, in, decSpec, j2krparam, cdstrInfo, hi);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[][] getParameterInfo() {
/*  901 */     return pinfo;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getPPX(int t, int c, int rl) {
/*  918 */     return this.decSpec.pss.getPPX(t, c, rl);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getPPY(int t, int c, int rl) {
/*  935 */     return this.decSpec.pss.getPPY(t, c, rl);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initSubbandsFields(int c, SubbandSyn sb) {
/*  950 */     int t = getTileIdx();
/*  951 */     int rl = sb.resLvl;
/*      */ 
/*      */     
/*  954 */     int cbw = this.decSpec.cblks.getCBlkWidth((byte)3, t, c);
/*  955 */     int cbh = this.decSpec.cblks.getCBlkHeight((byte)3, t, c);
/*      */     
/*  957 */     if (!sb.isNode) {
/*  958 */       if (this.hd.precinctPartitionUsed()) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  963 */         int ppxExp = MathUtil.log2(getPPX(t, c, rl));
/*  964 */         int ppyExp = MathUtil.log2(getPPY(t, c, rl));
/*  965 */         int cbwExp = MathUtil.log2(cbw);
/*  966 */         int cbhExp = MathUtil.log2(cbh);
/*      */         
/*  968 */         switch (sb.resLvl) {
/*      */           case 0:
/*  970 */             sb.nomCBlkW = (cbwExp < ppxExp) ? (1 << cbwExp) : (1 << ppxExp);
/*      */             
/*  972 */             sb.nomCBlkH = (cbhExp < ppyExp) ? (1 << cbhExp) : (1 << ppyExp);
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/*  977 */             sb.nomCBlkW = (cbwExp < ppxExp - 1) ? (1 << cbwExp) : (1 << ppxExp - 1);
/*      */             
/*  979 */             sb.nomCBlkH = (cbhExp < ppyExp - 1) ? (1 << cbhExp) : (1 << ppyExp - 1);
/*      */             break;
/*      */         } 
/*      */ 
/*      */       
/*      */       } else {
/*  985 */         sb.nomCBlkW = cbw;
/*  986 */         sb.nomCBlkH = cbh;
/*      */       } 
/*      */ 
/*      */       
/*  990 */       if (sb.numCb == null) sb.numCb = new Point(); 
/*  991 */       if (sb.w == 0 || sb.h == 0) {
/*  992 */         sb.numCb.x = 0;
/*  993 */         sb.numCb.y = 0;
/*      */       } else {
/*  995 */         int cb0x = getCbULX();
/*  996 */         int cb0y = getCbULY();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1004 */         int acb0x = cb0x;
/* 1005 */         int acb0y = cb0y;
/*      */         
/* 1007 */         switch (sb.sbandIdx) {
/*      */           case 0:
/*      */             break;
/*      */           
/*      */           case 1:
/* 1012 */             acb0x = 0;
/*      */             break;
/*      */           case 2:
/* 1015 */             acb0y = 0;
/*      */             break;
/*      */           case 3:
/* 1018 */             acb0x = 0;
/* 1019 */             acb0y = 0;
/*      */             break;
/*      */           default:
/* 1022 */             throw new Error("Internal JJ2000 error");
/*      */         } 
/* 1024 */         if (sb.ulcx - acb0x < 0 || sb.ulcy - acb0y < 0) {
/* 1025 */           throw new IllegalArgumentException("Invalid code-blocks partition origin or image offset in the reference grid.");
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1036 */         int tmp = sb.ulcx - acb0x + sb.nomCBlkW;
/* 1037 */         sb.numCb.x = (tmp + sb.w - 1) / sb.nomCBlkW - tmp / sb.nomCBlkW - 1;
/*      */         
/* 1039 */         tmp = sb.ulcy - acb0y + sb.nomCBlkH;
/* 1040 */         sb.numCb.y = (tmp + sb.h - 1) / sb.nomCBlkH - tmp / sb.nomCBlkH - 1;
/*      */       } 
/*      */       
/* 1043 */       if (this.derived[c]) {
/* 1044 */         sb.magbits = this.gb[c] + (this.params[c]).exp[0][0] - this.mdl[c] - sb.level - 1;
/*      */       } else {
/*      */         
/* 1047 */         sb.magbits = this.gb[c] + (this.params[c]).exp[sb.resLvl][sb.sbandIdx] - 1;
/*      */       } 
/*      */     } else {
/*      */       
/* 1051 */       initSubbandsFields(c, (SubbandSyn)sb.getLL());
/* 1052 */       initSubbandsFields(c, (SubbandSyn)sb.getHL());
/* 1053 */       initSubbandsFields(c, (SubbandSyn)sb.getLH());
/* 1054 */       initSubbandsFields(c, (SubbandSyn)sb.getHH());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getImgRes() {
/* 1066 */     return this.targetRes;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getTargetRate() {
/* 1075 */     return this.trate;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getActualRate() {
/* 1084 */     this.arate = this.anbytes * 8.0F / this.hd.getMaxCompImgWidth() / this.hd.getMaxCompImgHeight();
/* 1085 */     return this.arate;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getTargetNbytes() {
/* 1094 */     return this.tnbytes;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getActualNbytes() {
/* 1103 */     return this.anbytes;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getTilePartULX() {
/* 1108 */     return (this.hd.getTilingOrigin(null)).x;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getTilePartULY() {
/* 1113 */     return (this.hd.getTilingOrigin(null)).y;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getNomTileWidth() {
/* 1118 */     return this.hd.getNomTileWidth();
/*      */   }
/*      */ 
/*      */   
/*      */   public int getNomTileHeight() {
/* 1123 */     return this.hd.getNomTileHeight();
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/codestream/reader/BitstreamReaderAgent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */