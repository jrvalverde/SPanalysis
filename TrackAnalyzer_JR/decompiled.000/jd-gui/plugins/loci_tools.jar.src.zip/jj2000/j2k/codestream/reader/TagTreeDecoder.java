/*     */ package jj2000.j2k.codestream.reader;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import jj2000.j2k.util.ArrayUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TagTreeDecoder
/*     */ {
/*     */   protected int w;
/*     */   protected int h;
/*     */   protected int lvls;
/*     */   protected int[][] treeV;
/*     */   protected int[][] treeS;
/*     */   
/*     */   public TagTreeDecoder(int h, int w) {
/* 149 */     if (w < 0 || h < 0) {
/* 150 */       throw new IllegalArgumentException();
/*     */     }
/*     */     
/* 153 */     this.w = w;
/* 154 */     this.h = h;
/*     */     
/* 156 */     if (w == 0 || h == 0) {
/* 157 */       this.lvls = 0;
/*     */     } else {
/*     */       
/* 160 */       this.lvls = 1;
/* 161 */       while (h != 1 || w != 1) {
/* 162 */         w = w + 1 >> 1;
/* 163 */         h = h + 1 >> 1;
/* 164 */         this.lvls++;
/*     */       } 
/*     */     } 
/*     */     
/* 168 */     this.treeV = new int[this.lvls][];
/* 169 */     this.treeS = new int[this.lvls][];
/* 170 */     w = this.w;
/* 171 */     h = this.h;
/* 172 */     for (int i = 0; i < this.lvls; i++) {
/* 173 */       this.treeV[i] = new int[h * w];
/*     */       
/* 175 */       ArrayUtil.intArraySet(this.treeV[i], 2147483647);
/*     */ 
/*     */       
/* 178 */       this.treeS[i] = new int[h * w];
/* 179 */       w = w + 1 >> 1;
/* 180 */       h = h + 1 >> 1;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getWidth() {
/* 192 */     return this.w;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getHeight() {
/* 203 */     return this.h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int update(int m, int n, int t, PktHeaderBitReader in) throws IOException {
/*     */     int tv;
/* 237 */     if (m >= this.h || n >= this.w || t < 0) {
/* 238 */       throw new IllegalArgumentException();
/*     */     }
/*     */ 
/*     */     
/* 242 */     int k = this.lvls - 1;
/* 243 */     int tmin = this.treeS[k][0];
/*     */ 
/*     */     
/* 246 */     int idx = (m >> k) * (this.w + (1 << k) - 1 >> k) + (n >> k);
/*     */     
/*     */     while (true) {
/* 249 */       int ts = this.treeS[k][idx];
/* 250 */       tv = this.treeV[k][idx];
/* 251 */       if (ts < tmin) {
/* 252 */         ts = tmin;
/*     */       }
/* 254 */       while (t > ts) {
/* 255 */         if (tv >= ts) {
/* 256 */           if (in.readBit() == 0) {
/*     */             
/* 258 */             ts++;
/*     */             
/*     */             continue;
/*     */           } 
/* 262 */           tv = ts++;
/*     */           
/*     */           continue;
/*     */         } 
/*     */         
/* 267 */         ts = t;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 272 */       this.treeS[k][idx] = ts;
/* 273 */       this.treeV[k][idx] = tv;
/*     */       
/* 275 */       if (k > 0) {
/* 276 */         tmin = (ts < tv) ? ts : tv;
/* 277 */         k--;
/*     */         
/* 279 */         idx = (m >> k) * (this.w + (1 << k) - 1 >> k) + (n >> k); continue;
/*     */       } 
/*     */       break;
/*     */     } 
/* 283 */     return tv;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getValue(int m, int n) {
/* 304 */     if (m >= this.h || n >= this.w) {
/* 305 */       throw new IllegalArgumentException();
/*     */     }
/*     */     
/* 308 */     return this.treeV[0][m * this.w + n];
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/codestream/reader/TagTreeDecoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */