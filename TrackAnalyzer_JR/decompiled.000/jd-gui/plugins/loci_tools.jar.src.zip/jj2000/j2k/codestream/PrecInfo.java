/*     */ package jj2000.j2k.codestream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PrecInfo
/*     */ {
/*     */   public int rgulx;
/*     */   public int rguly;
/*     */   public int rgw;
/*     */   public int rgh;
/*     */   public int ulx;
/*     */   public int uly;
/*     */   public int w;
/*     */   public int h;
/*     */   public int r;
/*     */   public CBlkCoordInfo[][][] cblk;
/*     */   public int[] nblk;
/*     */   
/*     */   public PrecInfo(int r, int ulx, int uly, int w, int h, int rgulx, int rguly, int rgw, int rgh) {
/* 137 */     this.r = r;
/* 138 */     this.ulx = ulx;
/* 139 */     this.uly = uly;
/* 140 */     this.w = w;
/* 141 */     this.h = h;
/* 142 */     this.rgulx = rgulx;
/* 143 */     this.rguly = rguly;
/* 144 */     this.rgw = rgw;
/* 145 */     this.rgh = rgh;
/*     */     
/* 147 */     if (r == 0) {
/* 148 */       this.cblk = new CBlkCoordInfo[1][][];
/* 149 */       this.nblk = new int[1];
/*     */     } else {
/* 151 */       this.cblk = new CBlkCoordInfo[4][][];
/* 152 */       this.nblk = new int[4];
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 162 */     return "ulx=" + this.ulx + ",uly=" + this.uly + ",w=" + this.w + ",h=" + this.h + ",rgulx=" + this.rgulx + ",rguly=" + this.rguly + ",rgw=" + this.rgw + ",rgh=" + this.rgh;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/codestream/PrecInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */