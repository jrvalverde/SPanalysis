/*     */ package jj2000.j2k.codestream;
/*     */ 
/*     */ import java.util.Hashtable;
/*     */ import jj2000.j2k.wavelet.FilterTypes;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HeaderInfo
/*     */   implements Markers, ProgressionType, FilterTypes, Cloneable
/*     */ {
/*     */   public SIZ siz;
/*     */   
/*     */   public class SIZ
/*     */     implements Cloneable
/*     */   {
/*     */     public int lsiz;
/*     */     public int rsiz;
/*     */     public int xsiz;
/*     */     public int ysiz;
/*     */     public int x0siz;
/*     */     public int y0siz;
/*     */     public int xtsiz;
/*     */     public int ytsiz;
/*     */     public int xt0siz;
/*     */     public int yt0siz;
/*     */     public int csiz;
/*     */     public int[] ssiz;
/*     */     public int[] xrsiz;
/*     */     public int[] yrsiz;
/* 113 */     private int[] compWidth = null;
/*     */     
/* 115 */     private int maxCompWidth = -1;
/*     */     
/* 117 */     private int[] compHeight = null;
/*     */     
/* 119 */     private int maxCompHeight = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getCompImgWidth(int c) {
/* 128 */       if (this.compWidth == null) {
/* 129 */         this.compWidth = new int[this.csiz];
/* 130 */         for (int cc = 0; cc < this.csiz; cc++) {
/* 131 */           this.compWidth[cc] = (int)(Math.ceil(this.xsiz / this.xrsiz[cc]) - Math.ceil(this.x0siz / this.xrsiz[cc]));
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 136 */       return this.compWidth[c];
/*     */     }
/*     */     public int getMaxCompWidth() {
/* 139 */       if (this.compWidth == null) {
/* 140 */         this.compWidth = new int[this.csiz];
/* 141 */         for (int cc = 0; cc < this.csiz; cc++) {
/* 142 */           this.compWidth[cc] = (int)(Math.ceil(this.xsiz / this.xrsiz[cc]) - Math.ceil(this.x0siz / this.xrsiz[cc]));
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 147 */       if (this.maxCompWidth == -1) {
/* 148 */         for (int c = 0; c < this.csiz; c++) {
/* 149 */           if (this.compWidth[c] > this.maxCompWidth) {
/* 150 */             this.maxCompWidth = this.compWidth[c];
/*     */           }
/*     */         } 
/*     */       }
/* 154 */       return this.maxCompWidth;
/*     */     }
/*     */     public int getCompImgHeight(int c) {
/* 157 */       if (this.compHeight == null) {
/* 158 */         this.compHeight = new int[this.csiz];
/* 159 */         for (int cc = 0; cc < this.csiz; cc++) {
/* 160 */           this.compHeight[cc] = (int)(Math.ceil(this.ysiz / this.yrsiz[cc]) - Math.ceil(this.y0siz / this.yrsiz[cc]));
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 165 */       return this.compHeight[c];
/*     */     }
/*     */     public int getMaxCompHeight() {
/* 168 */       if (this.compHeight == null) {
/* 169 */         this.compHeight = new int[this.csiz];
/* 170 */         for (int cc = 0; cc < this.csiz; cc++) {
/* 171 */           this.compHeight[cc] = (int)(Math.ceil(this.ysiz / this.yrsiz[cc]) - Math.ceil(this.y0siz / this.yrsiz[cc]));
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 176 */       if (this.maxCompHeight == -1) {
/* 177 */         for (int c = 0; c < this.csiz; c++) {
/* 178 */           if (this.compHeight[c] != this.maxCompHeight) {
/* 179 */             this.maxCompHeight = this.compHeight[c];
/*     */           }
/*     */         } 
/*     */       }
/* 183 */       return this.maxCompHeight;
/*     */     }
/* 185 */     private int numTiles = -1;
/*     */     public int getNumTiles() {
/* 187 */       if (this.numTiles == -1) {
/* 188 */         this.numTiles = (this.xsiz - this.xt0siz + this.xtsiz - 1) / this.xtsiz * (this.ysiz - this.yt0siz + this.ytsiz - 1) / this.ytsiz;
/*     */       }
/*     */       
/* 191 */       return this.numTiles;
/*     */     }
/* 193 */     private boolean[] origSigned = null;
/*     */     public boolean isOrigSigned(int c) {
/* 195 */       if (this.origSigned == null) {
/* 196 */         this.origSigned = new boolean[this.csiz];
/* 197 */         for (int cc = 0; cc < this.csiz; cc++) {
/* 198 */           this.origSigned[cc] = (this.ssiz[cc] >>> 7 == 1);
/*     */         }
/*     */       } 
/* 201 */       return this.origSigned[c];
/*     */     }
/* 203 */     private int[] origBitDepth = null;
/*     */     public int getOrigBitDepth(int c) {
/* 205 */       if (this.origBitDepth == null) {
/* 206 */         this.origBitDepth = new int[this.csiz];
/* 207 */         for (int cc = 0; cc < this.csiz; cc++) {
/* 208 */           this.origBitDepth[cc] = (this.ssiz[cc] & 0x7F) + 1;
/*     */         }
/*     */       } 
/* 211 */       return this.origBitDepth[c];
/*     */     }
/*     */     public SIZ getCopy() {
/* 214 */       SIZ ms = null;
/*     */       try {
/* 216 */         ms = (SIZ)clone();
/* 217 */       } catch (CloneNotSupportedException e) {
/* 218 */         throw new Error("Cannot clone SIZ marker segment");
/*     */       } 
/* 220 */       return ms;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 225 */       String str = "\n --- SIZ (" + this.lsiz + " bytes) ---\n";
/* 226 */       str = str + " Capabilities : " + this.rsiz + "\n";
/* 227 */       str = str + " Image dim.   : " + (this.xsiz - this.x0siz) + "x" + (this.ysiz - this.y0siz) + ", (off=" + this.x0siz + "," + this.y0siz + ")\n";
/*     */       
/* 229 */       str = str + " Tile dim.    : " + this.xtsiz + "x" + this.ytsiz + ", (off=" + this.xt0siz + "," + this.yt0siz + ")\n";
/*     */       
/* 231 */       str = str + " Component(s) : " + this.csiz + "\n";
/* 232 */       str = str + " Orig. depth  : "; int i;
/* 233 */       for (i = 0; i < this.csiz; ) { str = str + getOrigBitDepth(i) + " "; i++; }
/* 234 */        str = str + "\n";
/* 235 */       str = str + " Orig. signed : ";
/* 236 */       for (i = 0; i < this.csiz; ) { str = str + isOrigSigned(i) + " "; i++; }
/* 237 */        str = str + "\n";
/* 238 */       str = str + " Subs. factor : ";
/* 239 */       for (i = 0; i < this.csiz; ) { str = str + this.xrsiz[i] + "," + this.yrsiz[i] + " "; i++; }
/* 240 */        str = str + "\n";
/* 241 */       return str;
/*     */     } }
/*     */   
/*     */   public SIZ getNewSIZ() {
/* 245 */     return new SIZ();
/*     */   }
/*     */   
/*     */   public class SOT
/*     */   {
/*     */     public int lsot;
/*     */     public int isot;
/*     */     public int psot;
/*     */     public int tpsot;
/*     */     public int tnsot;
/*     */     
/*     */     public String toString() {
/* 257 */       String str = "\n --- SOT (" + this.lsot + " bytes) ---\n";
/* 258 */       str = str + "Tile index         : " + this.isot + "\n";
/* 259 */       str = str + "Tile-part length   : " + this.psot + " bytes\n";
/* 260 */       str = str + "Tile-part index    : " + this.tpsot + "\n";
/* 261 */       str = str + "Num. of tile-parts : " + this.tnsot + "\n";
/* 262 */       str = str + "\n";
/* 263 */       return str;
/*     */     } }
/*     */   
/*     */   public SOT getNewSOT() {
/* 267 */     return new SOT();
/*     */   }
/*     */   
/*     */   public class COD implements Cloneable {
/*     */     public int lcod;
/*     */     public int scod;
/*     */     public int sgcod_po;
/*     */     public int sgcod_nl;
/*     */     public int sgcod_mct;
/*     */     public int spcod_ndl;
/*     */     public int spcod_cw;
/*     */     public int spcod_ch;
/*     */     public int spcod_cs;
/* 280 */     public int[] spcod_t = new int[1];
/*     */     public int[] spcod_ps;
/*     */     
/*     */     public COD getCopy() {
/* 284 */       COD ms = null;
/*     */       try {
/* 286 */         ms = (COD)clone();
/* 287 */       } catch (CloneNotSupportedException e) {
/* 288 */         throw new Error("Cannot clone SIZ marker segment");
/*     */       } 
/* 290 */       return ms;
/*     */     }
/*     */     
/*     */     public String toString() {
/* 294 */       String str = "\n --- COD (" + this.lcod + " bytes) ---\n";
/* 295 */       str = str + " Coding style   : ";
/* 296 */       if (this.scod == 0) {
/* 297 */         str = str + "Default";
/*     */       } else {
/* 299 */         if ((this.scod & 0x1) != 0) str = str + "Precints "; 
/* 300 */         if ((this.scod & 0x2) != 0) str = str + "SOP "; 
/* 301 */         if ((this.scod & 0x4) != 0) str = str + "EPH "; 
/* 302 */         int cb0x = ((this.scod & 0x8) != 0) ? 1 : 0;
/* 303 */         int cb0y = ((this.scod & 0x10) != 0) ? 1 : 0;
/* 304 */         if (cb0x != 0 || cb0y != 0) {
/* 305 */           str = str + "Code-blocks offset";
/* 306 */           str = str + "\n Cblk partition : " + cb0x + "," + cb0y;
/*     */         } 
/*     */       } 
/* 309 */       str = str + "\n";
/* 310 */       str = str + " Cblk style     : ";
/* 311 */       if (this.spcod_cs == 0) {
/* 312 */         str = str + "Default";
/*     */       } else {
/* 314 */         if ((this.spcod_cs & 0x1) != 0) str = str + "Bypass "; 
/* 315 */         if ((this.spcod_cs & 0x2) != 0) str = str + "Reset "; 
/* 316 */         if ((this.spcod_cs & 0x4) != 0) str = str + "Terminate "; 
/* 317 */         if ((this.spcod_cs & 0x8) != 0) str = str + "Vert_causal "; 
/* 318 */         if ((this.spcod_cs & 0x10) != 0) str = str + "Predict "; 
/* 319 */         if ((this.spcod_cs & 0x20) != 0) str = str + "Seg_symb "; 
/*     */       } 
/* 321 */       str = str + "\n";
/* 322 */       str = str + " Num. of levels : " + this.spcod_ndl + "\n";
/* 323 */       switch (this.sgcod_po) {
/*     */         case 0:
/* 325 */           str = str + " Progress. type : LY_RES_COMP_POS_PROG\n";
/*     */           break;
/*     */         case 1:
/* 328 */           str = str + " Progress. type : RES_LY_COMP_POS_PROG\n";
/*     */           break;
/*     */         case 2:
/* 331 */           str = str + " Progress. type : RES_POS_COMP_LY_PROG\n";
/*     */           break;
/*     */         case 3:
/* 334 */           str = str + " Progress. type : POS_COMP_RES_LY_PROG\n";
/*     */           break;
/*     */         case 4:
/* 337 */           str = str + " Progress. type : COMP_POS_RES_LY_PROG\n";
/*     */           break;
/*     */       } 
/* 340 */       str = str + " Num. of layers : " + this.sgcod_nl + "\n";
/* 341 */       str = str + " Cblk dimension : " + (1 << this.spcod_cw + 2) + "x" + (1 << this.spcod_ch + 2) + "\n";
/*     */       
/* 343 */       switch (this.spcod_t[0]) {
/*     */         case 0:
/* 345 */           str = str + " Filter         : 9-7 irreversible\n";
/*     */           break;
/*     */         case 1:
/* 348 */           str = str + " Filter         : 5-3 reversible\n";
/*     */           break;
/*     */       } 
/* 351 */       str = str + " Multi comp tr. : " + ((this.sgcod_mct == 1) ? 1 : 0) + "\n";
/* 352 */       if (this.spcod_ps != null) {
/* 353 */         str = str + " Precincts      : ";
/* 354 */         for (int i = 0; i < this.spcod_ps.length; i++) {
/* 355 */           str = str + (1 << (this.spcod_ps[i] & 0xF)) + "x" + (1 << (this.spcod_ps[i] & 0xF0) >> 4) + " ";
/*     */         }
/*     */       } 
/*     */       
/* 359 */       str = str + "\n";
/* 360 */       return str;
/*     */     } }
/*     */   
/*     */   public COD getNewCOD() {
/* 364 */     return new COD();
/*     */   }
/*     */   
/*     */   public class COC {
/*     */     public int lcoc;
/*     */     public int ccoc;
/*     */     public int scoc;
/*     */     public int spcoc_ndl;
/*     */     public int spcoc_cw;
/*     */     public int spcoc_ch;
/*     */     public int spcoc_cs;
/* 375 */     public int[] spcoc_t = new int[1];
/*     */     public int[] spcoc_ps;
/*     */     
/*     */     public String toString() {
/* 379 */       String str = "\n --- COC (" + this.lcoc + " bytes) ---\n";
/* 380 */       str = str + " Component      : " + this.ccoc + "\n";
/* 381 */       str = str + " Coding style   : ";
/* 382 */       if (this.scoc == 0) {
/* 383 */         str = str + "Default";
/*     */       } else {
/* 385 */         if ((this.scoc & 0x1) != 0) str = str + "Precints "; 
/* 386 */         if ((this.scoc & 0x2) != 0) str = str + "SOP "; 
/* 387 */         if ((this.scoc & 0x4) != 0) str = str + "EPH "; 
/*     */       } 
/* 389 */       str = str + "\n";
/* 390 */       str = str + " Cblk style     : ";
/* 391 */       if (this.spcoc_cs == 0) {
/* 392 */         str = str + "Default";
/*     */       } else {
/* 394 */         if ((this.spcoc_cs & 0x1) != 0) str = str + "Bypass "; 
/* 395 */         if ((this.spcoc_cs & 0x2) != 0) str = str + "Reset "; 
/* 396 */         if ((this.spcoc_cs & 0x4) != 0) str = str + "Terminate "; 
/* 397 */         if ((this.spcoc_cs & 0x8) != 0) str = str + "Vert_causal "; 
/* 398 */         if ((this.spcoc_cs & 0x10) != 0) str = str + "Predict "; 
/* 399 */         if ((this.spcoc_cs & 0x20) != 0) str = str + "Seg_symb "; 
/*     */       } 
/* 401 */       str = str + "\n";
/* 402 */       str = str + " Num. of levels : " + this.spcoc_ndl + "\n";
/* 403 */       str = str + " Cblk dimension : " + (1 << this.spcoc_cw + 2) + "x" + (1 << this.spcoc_ch + 2) + "\n";
/*     */       
/* 405 */       switch (this.spcoc_t[0]) {
/*     */         case 0:
/* 407 */           str = str + " Filter         : 9-7 irreversible\n";
/*     */           break;
/*     */         case 1:
/* 410 */           str = str + " Filter         : 5-3 reversible\n";
/*     */           break;
/*     */       } 
/* 413 */       if (this.spcoc_ps != null) {
/* 414 */         str = str + " Precincts      : ";
/* 415 */         for (int i = 0; i < this.spcoc_ps.length; i++) {
/* 416 */           str = str + (1 << (this.spcoc_ps[i] & 0xF)) + "x" + (1 << (this.spcoc_ps[i] & 0xF0) >> 4) + " ";
/*     */         }
/*     */       } 
/*     */       
/* 420 */       str = str + "\n";
/* 421 */       return str;
/*     */     } }
/*     */   
/*     */   public COC getNewCOC() {
/* 425 */     return new COC();
/*     */   }
/*     */   
/*     */   public class RGN {
/*     */     public int lrgn;
/*     */     public int crgn;
/*     */     public int srgn;
/*     */     public int sprgn;
/*     */     
/*     */     public String toString() {
/* 435 */       String str = "\n --- RGN (" + this.lrgn + " bytes) ---\n";
/* 436 */       str = str + " Component : " + this.crgn + "\n";
/* 437 */       if (this.srgn == 0) {
/* 438 */         str = str + " ROI style : Implicit\n";
/*     */       } else {
/* 440 */         str = str + " ROI style : Unsupported\n";
/*     */       } 
/* 442 */       str = str + " ROI shift : " + this.sprgn + "\n";
/* 443 */       str = str + "\n";
/* 444 */       return str;
/*     */     } }
/*     */   
/*     */   public RGN getNewRGN() {
/* 448 */     return new RGN();
/*     */   }
/*     */   
/*     */   public class QCD
/*     */   {
/*     */     public int lqcd;
/*     */     public int sqcd;
/*     */     public int[][] spqcd;
/* 456 */     private int qType = -1;
/*     */     public int getQuantType() {
/* 458 */       if (this.qType == -1) {
/* 459 */         this.qType = this.sqcd & 0xFFFFFF1F;
/*     */       }
/* 461 */       return this.qType;
/*     */     }
/* 463 */     private int gb = -1;
/*     */     public int getNumGuardBits() {
/* 465 */       if (this.gb == -1) {
/* 466 */         this.gb = this.sqcd >> 5 & 0x7;
/*     */       }
/* 468 */       return this.gb;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 473 */       String str = "\n --- QCD (" + this.lqcd + " bytes) ---\n";
/* 474 */       str = str + " Quant. type    : ";
/* 475 */       int qt = getQuantType();
/* 476 */       if (qt == 0) { str = str + "No quantization \n"; }
/* 477 */       else if (qt == 1) { str = str + "Scalar derived\n"; }
/* 478 */       else if (qt == 2) { str = str + "Scalar expounded\n"; }
/* 479 */        str = str + " Guard bits     : " + getNumGuardBits() + "\n";
/* 480 */       if (qt == 0) {
/* 481 */         str = str + " Exponents   :\n";
/*     */         
/* 483 */         for (int i = 0; i < this.spqcd.length; i++) {
/* 484 */           for (int j = 0; j < (this.spqcd[i]).length; j++) {
/* 485 */             if (i == 0 && j == 0) {
/* 486 */               int exp = this.spqcd[0][0] >> 3 & 0x1F;
/* 487 */               str = str + "\tr=0 : " + exp + "\n";
/* 488 */             } else if (i != 0 && j > 0) {
/* 489 */               int exp = this.spqcd[i][j] >> 3 & 0x1F;
/* 490 */               str = str + "\tr=" + i + ",s=" + j + " : " + exp + "\n";
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } else {
/* 495 */         str = str + " Exp / Mantissa : \n";
/*     */ 
/*     */         
/* 498 */         for (int i = 0; i < this.spqcd.length; i++) {
/* 499 */           for (int j = 0; j < (this.spqcd[i]).length; j++) {
/* 500 */             if (i == 0 && j == 0) {
/* 501 */               int exp = this.spqcd[0][0] >> 11 & 0x1F;
/* 502 */               double mantissa = ((-1.0F - (this.spqcd[0][0] & 0x7FF) / 2048.0F) / (-1 << exp));
/*     */               
/* 504 */               str = str + "\tr=0 : " + exp + " / " + mantissa + "\n";
/* 505 */             } else if (i != 0 && j > 0) {
/* 506 */               int exp = this.spqcd[i][j] >> 11 & 0x1F;
/* 507 */               double mantissa = ((-1.0F - (this.spqcd[i][j] & 0x7FF) / 2048.0F) / (-1 << exp));
/*     */               
/* 509 */               str = str + "\tr=" + i + ",s=" + j + " : " + exp + " / " + mantissa + "\n";
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/* 515 */       str = str + "\n";
/* 516 */       return str;
/*     */     } }
/*     */   
/*     */   public QCD getNewQCD() {
/* 520 */     return new QCD();
/*     */   }
/*     */   
/*     */   public class QCC
/*     */   {
/*     */     public int lqcc;
/*     */     public int cqcc;
/*     */     public int sqcc;
/*     */     public int[][] spqcc;
/* 529 */     private int qType = -1;
/*     */     public int getQuantType() {
/* 531 */       if (this.qType == -1) {
/* 532 */         this.qType = this.sqcc & 0xFFFFFF1F;
/*     */       }
/* 534 */       return this.qType;
/*     */     }
/* 536 */     private int gb = -1;
/*     */     public int getNumGuardBits() {
/* 538 */       if (this.gb == -1) {
/* 539 */         this.gb = this.sqcc >> 5 & 0x7;
/*     */       }
/* 541 */       return this.gb;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 546 */       String str = "\n --- QCC (" + this.lqcc + " bytes) ---\n";
/* 547 */       str = str + " Component      : " + this.cqcc + "\n";
/* 548 */       str = str + " Quant. type    : ";
/* 549 */       int qt = getQuantType();
/* 550 */       if (qt == 0) { str = str + "No quantization \n"; }
/* 551 */       else if (qt == 1) { str = str + "Scalar derived\n"; }
/* 552 */       else if (qt == 2) { str = str + "Scalar expounded\n"; }
/* 553 */        str = str + " Guard bits     : " + getNumGuardBits() + "\n";
/* 554 */       if (qt == 0) {
/* 555 */         str = str + " Exponents   :\n";
/*     */         
/* 557 */         for (int i = 0; i < this.spqcc.length; i++) {
/* 558 */           for (int j = 0; j < (this.spqcc[i]).length; j++) {
/* 559 */             if (i == 0 && j == 0) {
/* 560 */               int exp = this.spqcc[0][0] >> 3 & 0x1F;
/* 561 */               str = str + "\tr=0 : " + exp + "\n";
/* 562 */             } else if (i != 0 && j > 0) {
/* 563 */               int exp = this.spqcc[i][j] >> 3 & 0x1F;
/* 564 */               str = str + "\tr=" + i + ",s=" + j + " : " + exp + "\n";
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } else {
/* 569 */         str = str + " Exp / Mantissa : \n";
/*     */ 
/*     */         
/* 572 */         for (int i = 0; i < this.spqcc.length; i++) {
/* 573 */           for (int j = 0; j < (this.spqcc[i]).length; j++) {
/* 574 */             if (i == 0 && j == 0) {
/* 575 */               int exp = this.spqcc[0][0] >> 11 & 0x1F;
/* 576 */               double mantissa = ((-1.0F - (this.spqcc[0][0] & 0x7FF) / 2048.0F) / (-1 << exp));
/*     */               
/* 578 */               str = str + "\tr=0 : " + exp + " / " + mantissa + "\n";
/* 579 */             } else if (i != 0 && j > 0) {
/* 580 */               int exp = this.spqcc[i][j] >> 11 & 0x1F;
/* 581 */               double mantissa = ((-1.0F - (this.spqcc[i][j] & 0x7FF) / 2048.0F) / (-1 << exp));
/*     */               
/* 583 */               str = str + "\tr=" + i + ",s=" + j + " : " + exp + " / " + mantissa + "\n";
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/* 589 */       str = str + "\n";
/* 590 */       return str;
/*     */     } }
/*     */   
/*     */   public QCC getNewQCC() {
/* 594 */     return new QCC();
/*     */   }
/*     */   
/*     */   public class POC {
/*     */     public int lpoc;
/*     */     public int[] rspoc;
/*     */     public int[] cspoc;
/*     */     public int[] lyepoc;
/*     */     public int[] repoc;
/*     */     public int[] cepoc;
/*     */     public int[] ppoc;
/*     */     
/*     */     public String toString() {
/* 607 */       String str = "\n --- POC (" + this.lpoc + " bytes) ---\n";
/* 608 */       str = str + " Chg_idx RSpoc CSpoc LYEpoc REpoc CEpoc Ppoc\n";
/* 609 */       for (int chg = 0; chg < this.rspoc.length; chg++) {
/* 610 */         str = str + "   " + chg + "      " + this.rspoc[chg] + "     " + this.cspoc[chg] + "     " + this.lyepoc[chg] + "      " + this.repoc[chg] + "     " + this.cepoc[chg];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 616 */         switch (this.ppoc[chg]) {
/*     */           case 0:
/* 618 */             str = str + "  LY_RES_COMP_POS_PROG\n";
/*     */             break;
/*     */           case 1:
/* 621 */             str = str + "  RES_LY_COMP_POS_PROG\n";
/*     */             break;
/*     */           case 2:
/* 624 */             str = str + "  RES_POS_COMP_LY_PROG\n";
/*     */             break;
/*     */           case 3:
/* 627 */             str = str + "  POS_COMP_RES_LY_PROG\n";
/*     */             break;
/*     */           case 4:
/* 630 */             str = str + "  COMP_POS_RES_LY_PROG\n";
/*     */             break;
/*     */         } 
/*     */       } 
/* 634 */       str = str + "\n";
/* 635 */       return str;
/*     */     } }
/*     */   
/*     */   public POC getNewPOC() {
/* 639 */     return new POC();
/*     */   }
/*     */   
/*     */   public class CRG {
/*     */     public int lcrg;
/*     */     public int[] xcrg;
/*     */     public int[] ycrg;
/*     */     
/*     */     public String toString() {
/* 648 */       String str = "\n --- CRG (" + this.lcrg + " bytes) ---\n";
/* 649 */       for (int c = 0; c < this.xcrg.length; c++) {
/* 650 */         str = str + " Component " + c + " offset : " + this.xcrg[c] + "," + this.ycrg[c] + "\n";
/*     */       }
/* 652 */       str = str + "\n";
/* 653 */       return str;
/*     */     } }
/*     */   
/*     */   public CRG getNewCRG() {
/* 657 */     return new CRG();
/*     */   }
/*     */   
/*     */   public class COM {
/*     */     public int lcom;
/*     */     public int rcom;
/*     */     public byte[] ccom;
/*     */     
/*     */     public String toString() {
/* 666 */       String str = "\n --- COM (" + this.lcom + " bytes) ---\n";
/* 667 */       if (this.rcom == 0) {
/* 668 */         str = str + " Registration : General use (binary values)\n";
/* 669 */       } else if (this.rcom == 1) {
/* 670 */         str = str + " Registration : General use (IS 8859-15:1999 (Latin) values)\n";
/*     */         
/* 672 */         str = str + " Text         : " + new String(this.ccom) + "\n";
/*     */       } else {
/* 674 */         str = str + " Registration : Unknown\n";
/*     */       } 
/* 676 */       str = str + "\n";
/* 677 */       return str;
/*     */     } }
/*     */   
/*     */   public COM getNewCOM() {
/* 681 */     this.ncom++; return new COM();
/*     */   }
/*     */   public int getNumCOM() {
/* 684 */     return this.ncom;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 691 */   public Hashtable sot = new Hashtable<Object, Object>();
/*     */ 
/*     */ 
/*     */   
/* 695 */   public Hashtable cod = new Hashtable<Object, Object>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 700 */   public Hashtable coc = new Hashtable<Object, Object>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 705 */   public Hashtable rgn = new Hashtable<Object, Object>();
/*     */ 
/*     */ 
/*     */   
/* 709 */   public Hashtable qcd = new Hashtable<Object, Object>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 714 */   public Hashtable qcc = new Hashtable<Object, Object>();
/*     */ 
/*     */ 
/*     */   
/* 718 */   public Hashtable poc = new Hashtable<Object, Object>();
/*     */ 
/*     */ 
/*     */   
/*     */   public CRG crg;
/*     */ 
/*     */   
/* 725 */   public Hashtable com = new Hashtable<Object, Object>();
/*     */ 
/*     */   
/* 728 */   private int ncom = 0;
/*     */ 
/*     */ 
/*     */   
/*     */   public String toStringMainHeader() {
/* 733 */     int nc = this.siz.csiz;
/*     */     
/* 735 */     String str = "" + this.siz;
/*     */     
/* 737 */     if (this.cod.get("main") != null) {
/* 738 */       str = str + "" + (COD)this.cod.get("main");
/*     */     }
/*     */     int c;
/* 741 */     for (c = 0; c < nc; c++) {
/* 742 */       if (this.coc.get("main_c" + c) != null) {
/* 743 */         str = str + "" + (COC)this.coc.get("main_c" + c);
/*     */       }
/*     */     } 
/*     */     
/* 747 */     if (this.qcd.get("main") != null) {
/* 748 */       str = str + "" + (QCD)this.qcd.get("main");
/*     */     }
/*     */     
/* 751 */     for (c = 0; c < nc; c++) {
/* 752 */       if (this.qcc.get("main_c" + c) != null) {
/* 753 */         str = str + "" + (QCC)this.qcc.get("main_c" + c);
/*     */       }
/*     */     } 
/*     */     
/* 757 */     for (c = 0; c < nc; c++) {
/* 758 */       if (this.rgn.get("main_c" + c) != null) {
/* 759 */         str = str + "" + (RGN)this.rgn.get("main_c" + c);
/*     */       }
/*     */     } 
/*     */     
/* 763 */     if (this.poc.get("main") != null) {
/* 764 */       str = str + "" + (POC)this.poc.get("main");
/*     */     }
/*     */     
/* 767 */     if (this.crg != null) {
/* 768 */       str = str + "" + this.crg;
/*     */     }
/*     */     
/* 771 */     for (int i = 0; i < this.ncom; i++) {
/* 772 */       if (this.com.get("main_" + i) != null) {
/* 773 */         str = str + "" + (COM)this.com.get("main_" + i);
/*     */       }
/*     */     } 
/* 776 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toStringTileHeader(int t, int ntp) {
/* 787 */     int nc = this.siz.csiz;
/* 788 */     String str = "";
/*     */     
/* 790 */     for (int i = 0; i < ntp; i++) {
/* 791 */       str = str + "Tile-part " + i + ", tile " + t + ":\n";
/* 792 */       str = str + "" + (SOT)this.sot.get("t" + t + "_tp" + i);
/*     */     } 
/*     */     
/* 795 */     if (this.cod.get("t" + t) != null) {
/* 796 */       str = str + "" + (COD)this.cod.get("t" + t);
/*     */     }
/*     */     int c;
/* 799 */     for (c = 0; c < nc; c++) {
/* 800 */       if (this.coc.get("t" + t + "_c" + c) != null) {
/* 801 */         str = str + "" + (COC)this.coc.get("t" + t + "_c" + c);
/*     */       }
/*     */     } 
/*     */     
/* 805 */     if (this.qcd.get("t" + t) != null) {
/* 806 */       str = str + "" + (QCD)this.qcd.get("t" + t);
/*     */     }
/*     */     
/* 809 */     for (c = 0; c < nc; c++) {
/* 810 */       if (this.qcc.get("t" + t + "_c" + c) != null) {
/* 811 */         str = str + "" + (QCC)this.qcc.get("t" + t + "_c" + c);
/*     */       }
/*     */     } 
/*     */     
/* 815 */     for (c = 0; c < nc; c++) {
/* 816 */       if (this.rgn.get("t" + t + "_c" + c) != null) {
/* 817 */         str = str + "" + (RGN)this.rgn.get("t" + t + "_c" + c);
/*     */       }
/*     */     } 
/*     */     
/* 821 */     if (this.poc.get("t" + t) != null) {
/* 822 */       str = str + "" + (POC)this.poc.get("t" + t);
/*     */     }
/* 824 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toStringThNoSOT(int t, int ntp) {
/* 836 */     int nc = this.siz.csiz;
/* 837 */     String str = "";
/*     */     
/* 839 */     if (this.cod.get("t" + t) != null) {
/* 840 */       str = str + "" + (COD)this.cod.get("t" + t);
/*     */     }
/*     */     int c;
/* 843 */     for (c = 0; c < nc; c++) {
/* 844 */       if (this.coc.get("t" + t + "_c" + c) != null) {
/* 845 */         str = str + "" + (COC)this.coc.get("t" + t + "_c" + c);
/*     */       }
/*     */     } 
/*     */     
/* 849 */     if (this.qcd.get("t" + t) != null) {
/* 850 */       str = str + "" + (QCD)this.qcd.get("t" + t);
/*     */     }
/*     */     
/* 853 */     for (c = 0; c < nc; c++) {
/* 854 */       if (this.qcc.get("t" + t + "_c" + c) != null) {
/* 855 */         str = str + "" + (QCC)this.qcc.get("t" + t + "_c" + c);
/*     */       }
/*     */     } 
/*     */     
/* 859 */     for (c = 0; c < nc; c++) {
/* 860 */       if (this.rgn.get("t" + t + "_c" + c) != null) {
/* 861 */         str = str + "" + (RGN)this.rgn.get("t" + t + "_c" + c);
/*     */       }
/*     */     } 
/*     */     
/* 865 */     if (this.poc.get("t" + t) != null) {
/* 866 */       str = str + "" + (POC)this.poc.get("t" + t);
/*     */     }
/* 868 */     return str;
/*     */   }
/*     */ 
/*     */   
/*     */   public HeaderInfo getCopy(int nt) {
/* 873 */     HeaderInfo nhi = null;
/*     */     
/*     */     try {
/* 876 */       nhi = (HeaderInfo)clone();
/* 877 */     } catch (CloneNotSupportedException e) {
/* 878 */       throw new Error("Cannot clone HeaderInfo instance");
/*     */     } 
/* 880 */     nhi.siz = this.siz.getCopy();
/*     */     
/* 882 */     if (this.cod.get("main") != null) {
/* 883 */       COD ms = (COD)this.cod.get("main");
/* 884 */       nhi.cod.put("main", ms.getCopy());
/*     */     } 
/* 886 */     for (int t = 0; t < nt; t++) {
/* 887 */       if (this.cod.get("t" + t) != null) {
/* 888 */         COD ms = (COD)this.cod.get("t" + t);
/* 889 */         nhi.cod.put("t" + t, ms.getCopy());
/*     */       } 
/*     */     } 
/* 892 */     return nhi;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/codestream/HeaderInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */