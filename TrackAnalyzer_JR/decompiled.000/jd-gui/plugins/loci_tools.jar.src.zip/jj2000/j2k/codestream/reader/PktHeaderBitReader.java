/*     */ package jj2000.j2k.codestream.reader;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import jj2000.j2k.io.RandomAccessIO;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class PktHeaderBitReader
/*     */ {
/*     */   RandomAccessIO in;
/*     */   ByteArrayInputStream bais;
/*     */   boolean usebais;
/*     */   int bbuf;
/*     */   int bpos;
/*     */   int nextbbuf;
/*     */   
/*     */   PktHeaderBitReader(RandomAccessIO in) {
/* 126 */     this.in = in;
/* 127 */     this.usebais = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   PktHeaderBitReader(ByteArrayInputStream bais) {
/* 138 */     this.bais = bais;
/* 139 */     this.usebais = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final int readBit() throws IOException {
/* 153 */     if (this.bpos == 0) {
/* 154 */       if (this.bbuf != 255) {
/* 155 */         if (this.usebais) {
/* 156 */           this.bbuf = this.bais.read();
/*     */         } else {
/* 158 */           this.bbuf = this.in.read();
/* 159 */         }  this.bpos = 8;
/* 160 */         if (this.bbuf == 255) {
/* 161 */           if (this.usebais) {
/* 162 */             this.nextbbuf = this.bais.read();
/*     */           } else {
/* 164 */             this.nextbbuf = this.in.read();
/*     */           } 
/*     */         }
/*     */       } else {
/* 168 */         this.bbuf = this.nextbbuf;
/* 169 */         this.bpos = 7;
/*     */       } 
/*     */     }
/* 172 */     return this.bbuf >> --this.bpos & 0x1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final int readBits(int n) throws IOException {
/* 192 */     if (n <= this.bpos) {
/* 193 */       return this.bbuf >> (this.bpos -= n) & (1 << n) - 1;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 199 */     int bits = 0;
/*     */     
/*     */     do {
/* 202 */       bits <<= this.bpos;
/* 203 */       n -= this.bpos;
/* 204 */       bits |= readBits(this.bpos);
/*     */       
/* 206 */       if (this.bbuf != 255) {
/* 207 */         if (this.usebais) {
/* 208 */           this.bbuf = this.bais.read();
/*     */         } else {
/* 210 */           this.bbuf = this.in.read();
/*     */         } 
/* 212 */         this.bpos = 8;
/* 213 */         if (this.bbuf == 255) {
/* 214 */           if (this.usebais) {
/* 215 */             this.nextbbuf = this.bais.read();
/*     */           } else {
/* 217 */             this.nextbbuf = this.in.read();
/*     */           } 
/*     */         }
/*     */       } else {
/* 221 */         this.bbuf = this.nextbbuf;
/* 222 */         this.bpos = 7;
/*     */       } 
/* 224 */     } while (n > this.bpos);
/*     */     
/* 226 */     bits <<= n;
/* 227 */     bits |= this.bbuf >> (this.bpos -= n) & (1 << n) - 1;
/*     */     
/* 229 */     return bits;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void sync() {
/* 244 */     this.bbuf = 0;
/* 245 */     this.bpos = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setInput(RandomAccessIO in) {
/* 260 */     this.in = in;
/* 261 */     this.bbuf = 0;
/* 262 */     this.bpos = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setInput(ByteArrayInputStream bais) {
/* 277 */     this.bais = bais;
/* 278 */     this.bbuf = 0;
/* 279 */     this.bpos = 0;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/codestream/reader/PktHeaderBitReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */