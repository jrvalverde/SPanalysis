/*     */ package jj2000.j2k.codestream.writer;
/*     */ 
/*     */ import jj2000.j2k.util.ArrayUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TagTreeEncoder
/*     */ {
/*     */   protected int w;
/*     */   protected int h;
/*     */   protected int lvls;
/*     */   protected int[][] treeV;
/*     */   protected int[][] treeS;
/*     */   protected int[][] treeVbak;
/*     */   protected int[][] treeSbak;
/*     */   protected boolean saved;
/*     */   
/*     */   public TagTreeEncoder(int h, int w) {
/* 173 */     if (w < 0 || h < 0) {
/* 174 */       throw new IllegalArgumentException();
/*     */     }
/*     */     
/* 177 */     init(w, h);
/*     */     
/* 179 */     for (int k = this.treeV.length - 1; k >= 0; k--) {
/* 180 */       ArrayUtil.intArraySet(this.treeV[k], 2147483647);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TagTreeEncoder(int h, int w, int[] val) {
/* 206 */     if (w < 0 || h < 0 || val.length < w * h) {
/* 207 */       throw new IllegalArgumentException();
/*     */     }
/*     */     
/* 210 */     init(w, h);
/*     */     
/* 212 */     for (int k = w * h - 1; k >= 0; k--) {
/* 213 */       this.treeV[0][k] = val[k];
/*     */     }
/*     */     
/* 216 */     recalcTreeV();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getWidth() {
/* 227 */     return this.w;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getHeight() {
/* 238 */     return this.h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void init(int w, int h) {
/* 256 */     this.w = w;
/* 257 */     this.h = h;
/*     */     
/* 259 */     if (w == 0 || h == 0) {
/* 260 */       this.lvls = 0;
/*     */     } else {
/*     */       
/* 263 */       this.lvls = 1;
/* 264 */       while (h != 1 || w != 1) {
/* 265 */         w = w + 1 >> 1;
/* 266 */         h = h + 1 >> 1;
/* 267 */         this.lvls++;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 272 */     this.treeV = new int[this.lvls][];
/* 273 */     this.treeS = new int[this.lvls][];
/* 274 */     w = this.w;
/* 275 */     h = this.h;
/* 276 */     for (int i = 0; i < this.lvls; i++) {
/* 277 */       this.treeV[i] = new int[h * w];
/* 278 */       this.treeS[i] = new int[h * w];
/* 279 */       w = w + 1 >> 1;
/* 280 */       h = h + 1 >> 1;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void recalcTreeV() {
/* 293 */     for (int k = 0; k < this.lvls - 1; k++) {
/*     */       
/* 295 */       int lw = this.w + (1 << k) - 1 >> k;
/* 296 */       int lh = this.h + (1 << k) - 1 >> k; int m;
/* 297 */       for (m = (lh >> 1 << 1) - 2; m >= 0; m -= 2) {
/* 298 */         int n; for (n = (lw >> 1 << 1) - 2; n >= 0; n -= 2) {
/*     */ 
/*     */           
/* 301 */           int bi = m * lw + n;
/* 302 */           int tm1 = (this.treeV[k][bi] < this.treeV[k][bi + 1]) ? this.treeV[k][bi] : this.treeV[k][bi + 1];
/*     */           
/* 304 */           int tm2 = (this.treeV[k][bi + lw] < this.treeV[k][bi + lw + 1]) ? this.treeV[k][bi + lw] : this.treeV[k][bi + lw + 1];
/*     */           
/* 306 */           this.treeV[k + 1][(m >> 1) * (lw + 1 >> 1) + (n >> 1)] = (tm1 < tm2) ? tm1 : tm2;
/*     */         } 
/*     */ 
/*     */         
/* 310 */         if (lw % 2 != 0) {
/* 311 */           n = lw >> 1 << 1;
/*     */ 
/*     */           
/* 314 */           int bi = m * lw + n;
/* 315 */           this.treeV[k + 1][(m >> 1) * (lw + 1 >> 1) + (n >> 1)] = (this.treeV[k][bi] < this.treeV[k][bi + lw]) ? this.treeV[k][bi] : this.treeV[k][bi + lw];
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 321 */       if (lh % 2 != 0) {
/* 322 */         m = lh >> 1 << 1; int n;
/* 323 */         for (n = (lw >> 1 << 1) - 2; n >= 0; n -= 2) {
/*     */ 
/*     */           
/* 326 */           int bi = m * lw + n;
/* 327 */           this.treeV[k + 1][(m >> 1) * (lw + 1 >> 1) + (n >> 1)] = (this.treeV[k][bi] < this.treeV[k][bi + 1]) ? this.treeV[k][bi] : this.treeV[k][bi + 1];
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 332 */         if (lw % 2 != 0) {
/*     */           
/* 334 */           n = lw >> 1 << 1;
/* 335 */           this.treeV[k + 1][(m >> 1) * (lw + 1 >> 1) + (n >> 1)] = this.treeV[k][m * lw + n];
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(int m, int n, int v) {
/* 358 */     if (this.lvls == 0 || n < 0 || n >= this.w || v < this.treeS[this.lvls - 1][0] || this.treeV[0][m * this.w + n] < this.treeS[this.lvls - 1][0])
/*     */     {
/* 360 */       throw new IllegalArgumentException();
/*     */     }
/*     */     
/* 363 */     this.treeV[0][m * this.w + n] = v;
/*     */     
/* 365 */     for (int k = 1; k < this.lvls; ) {
/* 366 */       int idx = (m >> k) * (this.w + (1 << k) - 1 >> k) + (n >> k);
/* 367 */       if (v < this.treeV[k][idx]) {
/*     */ 
/*     */         
/* 370 */         this.treeV[k][idx] = v;
/*     */         k++;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValues(int[] val) {
/* 402 */     if (this.lvls == 0) {
/* 403 */       throw new IllegalArgumentException();
/*     */     }
/*     */     
/* 406 */     int maxt = this.treeS[this.lvls - 1][0];
/* 407 */     for (int i = this.w * this.h - 1; i >= 0; i--) {
/* 408 */       if ((this.treeV[0][i] < maxt || val[i] < maxt) && this.treeV[0][i] != val[i])
/*     */       {
/* 410 */         throw new IllegalArgumentException();
/*     */       }
/*     */       
/* 413 */       this.treeV[0][i] = val[i];
/*     */     } 
/*     */     
/* 416 */     recalcTreeV();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void encode(int m, int n, int t, BitOutputBuffer out) {
/* 439 */     if (m >= this.h || n >= this.w || t < 0) {
/* 440 */       throw new IllegalArgumentException();
/*     */     }
/*     */ 
/*     */     
/* 444 */     int k = this.lvls - 1;
/* 445 */     int tmin = this.treeS[k][0];
/*     */ 
/*     */ 
/*     */     
/*     */     while (true) {
/* 450 */       int idx = (m >> k) * (this.w + (1 << k) - 1 >> k) + (n >> k);
/*     */       
/* 452 */       int ts = this.treeS[k][idx];
/* 453 */       if (ts < tmin) {
/* 454 */         ts = tmin;
/*     */       }
/* 456 */       while (t > ts) {
/* 457 */         if (this.treeV[k][idx] > ts) {
/* 458 */           out.writeBit(0);
/*     */         }
/* 460 */         else if (this.treeV[k][idx] == ts) {
/* 461 */           out.writeBit(1);
/*     */         } else {
/*     */           
/* 464 */           ts = t;
/*     */           
/*     */           break;
/*     */         } 
/* 468 */         ts++;
/*     */       } 
/*     */       
/* 471 */       this.treeS[k][idx] = ts;
/*     */       
/* 473 */       if (k > 0) {
/* 474 */         tmin = (ts < this.treeV[k][idx]) ? ts : this.treeV[k][idx];
/* 475 */         k--;
/*     */         continue;
/*     */       } 
/*     */       break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void save() {
/* 495 */     if (this.treeVbak == null) {
/*     */ 
/*     */       
/* 498 */       this.treeVbak = new int[this.lvls][];
/* 499 */       this.treeSbak = new int[this.lvls][];
/* 500 */       for (int i = this.lvls - 1; i >= 0; i--) {
/* 501 */         this.treeVbak[i] = new int[(this.treeV[i]).length];
/* 502 */         this.treeSbak[i] = new int[(this.treeV[i]).length];
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 507 */     for (int k = this.treeV.length - 1; k >= 0; k--) {
/* 508 */       System.arraycopy(this.treeV[k], 0, this.treeVbak[k], 0, (this.treeV[k]).length);
/* 509 */       System.arraycopy(this.treeS[k], 0, this.treeSbak[k], 0, (this.treeS[k]).length);
/*     */     } 
/*     */ 
/*     */     
/* 513 */     this.saved = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void restore() {
/* 528 */     if (!this.saved) {
/* 529 */       throw new IllegalArgumentException();
/*     */     }
/*     */ 
/*     */     
/* 533 */     for (int k = this.lvls - 1; k >= 0; k--) {
/* 534 */       System.arraycopy(this.treeVbak[k], 0, this.treeV[k], 0, (this.treeV[k]).length);
/* 535 */       System.arraycopy(this.treeSbak[k], 0, this.treeS[k], 0, (this.treeS[k]).length);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset() {
/* 550 */     for (int k = this.lvls - 1; k >= 0; k--) {
/* 551 */       ArrayUtil.intArraySet(this.treeV[k], 2147483647);
/* 552 */       ArrayUtil.intArraySet(this.treeS[k], 0);
/*     */     } 
/*     */     
/* 555 */     this.saved = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset(int[] val) {
/*     */     int k;
/* 569 */     for (k = this.w * this.h - 1; k >= 0; k--) {
/* 570 */       this.treeV[0][k] = val[k];
/*     */     }
/*     */     
/* 573 */     recalcTreeV();
/*     */     
/* 575 */     for (k = this.lvls - 1; k >= 0; k--) {
/* 576 */       ArrayUtil.intArraySet(this.treeS[k], 0);
/*     */     }
/*     */     
/* 579 */     this.saved = false;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/codestream/writer/TagTreeEncoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */