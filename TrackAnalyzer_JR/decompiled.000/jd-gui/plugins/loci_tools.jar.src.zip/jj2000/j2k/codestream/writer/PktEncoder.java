/*      */ package jj2000.j2k.codestream.writer;
/*      */ 
/*      */ import com.sun.media.imageioimpl.plugins.jpeg2000.J2KImageWriteParamJava;
/*      */ import java.awt.Point;
/*      */ import java.util.Vector;
/*      */ import jj2000.j2k.codestream.CBlkCoordInfo;
/*      */ import jj2000.j2k.codestream.PrecInfo;
/*      */ import jj2000.j2k.entropy.encoder.CBlkRateDistStats;
/*      */ import jj2000.j2k.entropy.encoder.CodedCBlkDataSrcEnc;
/*      */ import jj2000.j2k.util.ArrayUtil;
/*      */ import jj2000.j2k.util.MathUtil;
/*      */ import jj2000.j2k.wavelet.analysis.SubbandAn;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class PktEncoder
/*      */ {
/*      */   public static final char OPT_PREFIX = 'P';
/*  110 */   private static final String[][] pinfo = new String[][] { { "Psop", "[<tile idx>] true|false[ [<tile idx>] true|false ...]", "Specifies whether start of packet (SOP) markers should be used. 'true' enables, 'false' disables it.", "false" }, { "Peph", "[<tile idx>] true|false[ [<tile  idx>] true|false ...]", "Specifies whether end of packet header (EPH) markers should be  used. 'true' enables, 'false' disables it.", "false" } };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int INIT_LBLOCK = 3;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private CodedCBlkDataSrcEnc infoSrc;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   J2KImageWriteParamJava wp;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private TagTreeEncoder[][][][][] ttIncl;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private TagTreeEncoder[][][][][] ttMaxBP;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int[][][][][] lblock;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int[][][][][] prevtIdxs;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int[][][][][] bak_lblock;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int[][][][][] bak_prevtIdxs;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private byte[] lbbuf;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int lblen;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean saved;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean roiInPkt = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  253 */   private int roiLen = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private PrecInfo[][][][] ppinfo;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean packetWritable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PktEncoder(CodedCBlkDataSrcEnc infoSrc, J2KImageWriteParamJava wp, Point[][][] numPrec) {
/*  293 */     this.infoSrc = infoSrc;
/*  294 */     this.wp = wp;
/*      */ 
/*      */ 
/*      */     
/*  298 */     int nc = infoSrc.getNumComps();
/*  299 */     int nt = infoSrc.getNumTiles();
/*      */ 
/*      */     
/*  302 */     this.ttIncl = new TagTreeEncoder[nt][nc][][][];
/*  303 */     this.ttMaxBP = new TagTreeEncoder[nt][nc][][][];
/*  304 */     this.lblock = new int[nt][nc][][][];
/*  305 */     this.prevtIdxs = new int[nt][nc][][][];
/*  306 */     this.ppinfo = new PrecInfo[nt][nc][][];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  312 */     Point tmpCoord = null;
/*      */     
/*  314 */     Vector cblks = null;
/*  315 */     infoSrc.setTile(0, 0);
/*  316 */     for (int t = 0; t < nt; t++) {
/*  317 */       for (int c = 0; c < nc; c++) {
/*      */         
/*  319 */         SubbandAn root = infoSrc.getAnSubbandTree(t, c);
/*  320 */         int mrl = root.resLvl;
/*      */         
/*  322 */         this.lblock[t][c] = new int[mrl + 1][][];
/*  323 */         this.ttIncl[t][c] = new TagTreeEncoder[mrl + 1][][];
/*  324 */         this.ttMaxBP[t][c] = new TagTreeEncoder[mrl + 1][][];
/*  325 */         this.prevtIdxs[t][c] = new int[mrl + 1][][];
/*  326 */         this.ppinfo[t][c] = new PrecInfo[mrl + 1][];
/*      */         
/*  328 */         for (int r = 0; r <= mrl; r++) {
/*  329 */           int mins = (r == 0) ? 0 : 1;
/*  330 */           int maxs = (r == 0) ? 1 : 4;
/*      */           
/*  332 */           int maxPrec = (numPrec[t][c][r]).x * (numPrec[t][c][r]).y;
/*      */           
/*  334 */           this.ttIncl[t][c][r] = new TagTreeEncoder[maxPrec][maxs];
/*  335 */           this.ttMaxBP[t][c][r] = new TagTreeEncoder[maxPrec][maxs];
/*  336 */           this.prevtIdxs[t][c][r] = new int[maxs][];
/*  337 */           this.lblock[t][c][r] = new int[maxs][];
/*      */ 
/*      */           
/*  340 */           this.ppinfo[t][c][r] = new PrecInfo[maxPrec];
/*  341 */           fillPrecInfo(t, c, r);
/*      */           
/*  343 */           for (int s = mins; s < maxs; s++) {
/*      */             
/*  345 */             SubbandAn sb = (SubbandAn)root.getSubbandByIdx(r, s);
/*  346 */             int numcb = sb.numCb.x * sb.numCb.y;
/*      */             
/*  348 */             this.lblock[t][c][r][s] = new int[numcb];
/*  349 */             ArrayUtil.intArraySet(this.lblock[t][c][r][s], 3);
/*      */             
/*  351 */             this.prevtIdxs[t][c][r][s] = new int[numcb];
/*  352 */             ArrayUtil.intArraySet(this.prevtIdxs[t][c][r][s], -1);
/*      */           } 
/*      */         } 
/*      */       } 
/*  356 */       if (t != nt - 1) infoSrc.nextTile();
/*      */     
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void fillPrecInfo(int t, int c, int r) {
/*  373 */     if ((this.ppinfo[t][c][r]).length == 0) {
/*      */       return;
/*      */     }
/*  376 */     Point tileI = this.infoSrc.getTile(null);
/*  377 */     Point nTiles = this.infoSrc.getNumTiles(null);
/*      */     
/*  379 */     int x0siz = this.infoSrc.getImgULX();
/*  380 */     int y0siz = this.infoSrc.getImgULY();
/*  381 */     int xsiz = x0siz + this.infoSrc.getImgWidth();
/*  382 */     int ysiz = y0siz + this.infoSrc.getImgHeight();
/*  383 */     int xt0siz = this.infoSrc.getTilePartULX();
/*  384 */     int yt0siz = this.infoSrc.getTilePartULY();
/*  385 */     int xtsiz = this.infoSrc.getNomTileWidth();
/*  386 */     int ytsiz = this.infoSrc.getNomTileHeight();
/*      */     
/*  388 */     int tx0 = (tileI.x == 0) ? x0siz : (xt0siz + tileI.x * xtsiz);
/*  389 */     int ty0 = (tileI.y == 0) ? y0siz : (yt0siz + tileI.y * ytsiz);
/*  390 */     int tx1 = (tileI.x != nTiles.x - 1) ? (xt0siz + (tileI.x + 1) * xtsiz) : xsiz;
/*  391 */     int ty1 = (tileI.y != nTiles.y - 1) ? (yt0siz + (tileI.y + 1) * ytsiz) : ysiz;
/*      */     
/*  393 */     int xrsiz = this.infoSrc.getCompSubsX(c);
/*  394 */     int yrsiz = this.infoSrc.getCompSubsY(c);
/*      */     
/*  396 */     int tcx0 = (int)Math.ceil(tx0 / xrsiz);
/*  397 */     int tcy0 = (int)Math.ceil(ty0 / yrsiz);
/*  398 */     int tcx1 = (int)Math.ceil(tx1 / xrsiz);
/*  399 */     int tcy1 = (int)Math.ceil(ty1 / yrsiz);
/*      */     
/*  401 */     int ndl = (this.infoSrc.getAnSubbandTree(t, c)).resLvl - r;
/*  402 */     int trx0 = (int)Math.ceil(tcx0 / (1 << ndl));
/*  403 */     int try0 = (int)Math.ceil(tcy0 / (1 << ndl));
/*  404 */     int trx1 = (int)Math.ceil(tcx1 / (1 << ndl));
/*  405 */     int try1 = (int)Math.ceil(tcy1 / (1 << ndl));
/*      */     
/*  407 */     int cb0x = this.infoSrc.getCbULX();
/*  408 */     int cb0y = this.infoSrc.getCbULY();
/*      */     
/*  410 */     double twoppx = this.wp.getPrecinctPartition().getPPX(t, c, r);
/*  411 */     double twoppy = this.wp.getPrecinctPartition().getPPY(t, c, r);
/*  412 */     int twoppx2 = (int)(twoppx / 2.0D);
/*  413 */     int twoppy2 = (int)(twoppy / 2.0D);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  418 */     int maxPrec = (this.ppinfo[t][c][r]).length;
/*  419 */     int nPrec = 0;
/*      */     
/*  421 */     int istart = (int)Math.floor((try0 - cb0y) / twoppy);
/*  422 */     int iend = (int)Math.floor((try1 - 1 - cb0y) / twoppy);
/*  423 */     int jstart = (int)Math.floor((trx0 - cb0x) / twoppx);
/*  424 */     int jend = (int)Math.floor((trx1 - 1 - cb0x) / twoppx);
/*      */ 
/*      */ 
/*      */     
/*  428 */     SubbandAn root = this.infoSrc.getAnSubbandTree(t, c);
/*  429 */     SubbandAn sb = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  436 */     int prg_w = (int)twoppx << ndl;
/*  437 */     int prg_h = (int)twoppy << ndl;
/*      */ 
/*      */ 
/*      */     
/*  441 */     for (int i = istart; i <= iend; i++) {
/*  442 */       for (int j = jstart; j <= jend; j++, nPrec++) {
/*  443 */         int prg_ulx, prg_uly; if (j == jstart && (trx0 - cb0x) % xrsiz * (int)twoppx != 0) {
/*  444 */           prg_ulx = tx0;
/*      */         } else {
/*  446 */           prg_ulx = cb0x + j * xrsiz * ((int)twoppx << ndl);
/*      */         } 
/*  448 */         if (i == istart && (try0 - cb0y) % yrsiz * (int)twoppy != 0) {
/*  449 */           prg_uly = ty0;
/*      */         } else {
/*  451 */           prg_uly = cb0y + i * yrsiz * ((int)twoppy << ndl);
/*      */         } 
/*      */         
/*  454 */         this.ppinfo[t][c][r][nPrec] = new PrecInfo(r, (int)(cb0x + j * twoppx), (int)(cb0y + i * twoppy), (int)twoppx, (int)twoppy, prg_ulx, prg_uly, prg_w, prg_h);
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  459 */         if (r == 0) {
/*  460 */           int acb0x = cb0x;
/*  461 */           int acb0y = cb0y;
/*      */           
/*  463 */           int p0x = acb0x + j * (int)twoppx;
/*  464 */           int p1x = p0x + (int)twoppx;
/*  465 */           int p0y = acb0y + i * (int)twoppy;
/*  466 */           int p1y = p0y + (int)twoppy;
/*      */           
/*  468 */           sb = (SubbandAn)root.getSubbandByIdx(0, 0);
/*  469 */           int s0x = (p0x < sb.ulcx) ? sb.ulcx : p0x;
/*  470 */           int s1x = (p1x > sb.ulcx + sb.w) ? (sb.ulcx + sb.w) : p1x;
/*  471 */           int s0y = (p0y < sb.ulcy) ? sb.ulcy : p0y;
/*  472 */           int s1y = (p1y > sb.ulcy + sb.h) ? (sb.ulcy + sb.h) : p1y;
/*      */ 
/*      */           
/*  475 */           int cw = sb.nomCBlkW;
/*  476 */           int ch = sb.nomCBlkH;
/*  477 */           int k0 = (int)Math.floor((sb.ulcy - acb0y) / ch);
/*  478 */           int kstart = (int)Math.floor((s0y - acb0y) / ch);
/*  479 */           int kend = (int)Math.floor((s1y - 1 - acb0y) / ch);
/*  480 */           int l0 = (int)Math.floor((sb.ulcx - acb0x) / cw);
/*  481 */           int lstart = (int)Math.floor((s0x - acb0x) / cw);
/*  482 */           int lend = (int)Math.floor((s1x - 1 - acb0x) / cw);
/*      */           
/*  484 */           if (s1x - s0x <= 0 || s1y - s0y <= 0) {
/*  485 */             (this.ppinfo[t][c][r][nPrec]).nblk[0] = 0;
/*  486 */             this.ttIncl[t][c][r][nPrec][0] = new TagTreeEncoder(0, 0);
/*  487 */             this.ttMaxBP[t][c][r][nPrec][0] = new TagTreeEncoder(0, 0);
/*      */           } else {
/*  489 */             this.ttIncl[t][c][r][nPrec][0] = new TagTreeEncoder(kend - kstart + 1, lend - lstart + 1);
/*      */             
/*  491 */             this.ttMaxBP[t][c][r][nPrec][0] = new TagTreeEncoder(kend - kstart + 1, lend - lstart + 1);
/*      */             
/*  493 */             (this.ppinfo[t][c][r][nPrec]).cblk[0] = new CBlkCoordInfo[kend - kstart + 1][lend - lstart + 1];
/*      */             
/*  495 */             (this.ppinfo[t][c][r][nPrec]).nblk[0] = (kend - kstart + 1) * (lend - lstart + 1);
/*      */ 
/*      */             
/*  498 */             for (int k = kstart; k <= kend; k++) {
/*  499 */               for (int l = lstart; l <= lend; l++)
/*      */               {
/*  501 */                 CBlkCoordInfo cb = new CBlkCoordInfo(k - k0, l - l0);
/*  502 */                 (this.ppinfo[t][c][r][nPrec]).cblk[0][k - kstart][l - lstart] = cb;
/*      */               }
/*      */             
/*      */             } 
/*      */           } 
/*      */         } else {
/*      */           
/*  509 */           int acb0x = 0;
/*  510 */           int acb0y = cb0y;
/*      */           
/*  512 */           int p0x = acb0x + j * twoppx2;
/*  513 */           int p1x = p0x + twoppx2;
/*  514 */           int p0y = acb0y + i * twoppy2;
/*  515 */           int p1y = p0y + twoppy2;
/*      */           
/*  517 */           sb = (SubbandAn)root.getSubbandByIdx(r, 1);
/*  518 */           int s0x = (p0x < sb.ulcx) ? sb.ulcx : p0x;
/*  519 */           int s1x = (p1x > sb.ulcx + sb.w) ? (sb.ulcx + sb.w) : p1x;
/*  520 */           int s0y = (p0y < sb.ulcy) ? sb.ulcy : p0y;
/*  521 */           int s1y = (p1y > sb.ulcy + sb.h) ? (sb.ulcy + sb.h) : p1y;
/*      */ 
/*      */           
/*  524 */           int cw = sb.nomCBlkW;
/*  525 */           int ch = sb.nomCBlkH;
/*  526 */           int k0 = (int)Math.floor((sb.ulcy - acb0y) / ch);
/*  527 */           int kstart = (int)Math.floor((s0y - acb0y) / ch);
/*  528 */           int kend = (int)Math.floor((s1y - 1 - acb0y) / ch);
/*  529 */           int l0 = (int)Math.floor((sb.ulcx - acb0x) / cw);
/*  530 */           int lstart = (int)Math.floor((s0x - acb0x) / cw);
/*  531 */           int lend = (int)Math.floor((s1x - 1 - acb0x) / cw);
/*      */           
/*  533 */           if (s1x - s0x <= 0 || s1y - s0y <= 0) {
/*  534 */             (this.ppinfo[t][c][r][nPrec]).nblk[1] = 0;
/*  535 */             this.ttIncl[t][c][r][nPrec][1] = new TagTreeEncoder(0, 0);
/*  536 */             this.ttMaxBP[t][c][r][nPrec][1] = new TagTreeEncoder(0, 0);
/*      */           } else {
/*  538 */             this.ttIncl[t][c][r][nPrec][1] = new TagTreeEncoder(kend - kstart + 1, lend - lstart + 1);
/*      */             
/*  540 */             this.ttMaxBP[t][c][r][nPrec][1] = new TagTreeEncoder(kend - kstart + 1, lend - lstart + 1);
/*      */             
/*  542 */             (this.ppinfo[t][c][r][nPrec]).cblk[1] = new CBlkCoordInfo[kend - kstart + 1][lend - lstart + 1];
/*      */             
/*  544 */             (this.ppinfo[t][c][r][nPrec]).nblk[1] = (kend - kstart + 1) * (lend - lstart + 1);
/*      */ 
/*      */             
/*  547 */             for (int k = kstart; k <= kend; k++) {
/*  548 */               for (int l = lstart; l <= lend; l++) {
/*  549 */                 CBlkCoordInfo cb = new CBlkCoordInfo(k - k0, l - l0);
/*  550 */                 (this.ppinfo[t][c][r][nPrec]).cblk[1][k - kstart][l - lstart] = cb;
/*      */               } 
/*      */             } 
/*      */           } 
/*      */ 
/*      */ 
/*      */           
/*  557 */           acb0x = cb0x;
/*  558 */           acb0y = 0;
/*      */           
/*  560 */           p0x = acb0x + j * twoppx2;
/*  561 */           p1x = p0x + twoppx2;
/*  562 */           p0y = acb0y + i * twoppy2;
/*  563 */           p1y = p0y + twoppy2;
/*      */           
/*  565 */           sb = (SubbandAn)root.getSubbandByIdx(r, 2);
/*  566 */           s0x = (p0x < sb.ulcx) ? sb.ulcx : p0x;
/*  567 */           s1x = (p1x > sb.ulcx + sb.w) ? (sb.ulcx + sb.w) : p1x;
/*  568 */           s0y = (p0y < sb.ulcy) ? sb.ulcy : p0y;
/*  569 */           s1y = (p1y > sb.ulcy + sb.h) ? (sb.ulcy + sb.h) : p1y;
/*      */ 
/*      */           
/*  572 */           cw = sb.nomCBlkW;
/*  573 */           ch = sb.nomCBlkH;
/*  574 */           k0 = (int)Math.floor((sb.ulcy - acb0y) / ch);
/*  575 */           kstart = (int)Math.floor((s0y - acb0y) / ch);
/*  576 */           kend = (int)Math.floor((s1y - 1 - acb0y) / ch);
/*  577 */           l0 = (int)Math.floor((sb.ulcx - acb0x) / cw);
/*  578 */           lstart = (int)Math.floor((s0x - acb0x) / cw);
/*  579 */           lend = (int)Math.floor((s1x - 1 - acb0x) / cw);
/*      */           
/*  581 */           if (s1x - s0x <= 0 || s1y - s0y <= 0) {
/*  582 */             (this.ppinfo[t][c][r][nPrec]).nblk[2] = 0;
/*  583 */             this.ttIncl[t][c][r][nPrec][2] = new TagTreeEncoder(0, 0);
/*  584 */             this.ttMaxBP[t][c][r][nPrec][2] = new TagTreeEncoder(0, 0);
/*      */           } else {
/*  586 */             this.ttIncl[t][c][r][nPrec][2] = new TagTreeEncoder(kend - kstart + 1, lend - lstart + 1);
/*      */             
/*  588 */             this.ttMaxBP[t][c][r][nPrec][2] = new TagTreeEncoder(kend - kstart + 1, lend - lstart + 1);
/*      */             
/*  590 */             (this.ppinfo[t][c][r][nPrec]).cblk[2] = new CBlkCoordInfo[kend - kstart + 1][lend - lstart + 1];
/*      */             
/*  592 */             (this.ppinfo[t][c][r][nPrec]).nblk[2] = (kend - kstart + 1) * (lend - lstart + 1);
/*      */ 
/*      */             
/*  595 */             for (int k = kstart; k <= kend; k++) {
/*  596 */               for (int l = lstart; l <= lend; l++) {
/*  597 */                 CBlkCoordInfo cb = new CBlkCoordInfo(k - k0, l - l0);
/*  598 */                 (this.ppinfo[t][c][r][nPrec]).cblk[2][k - kstart][l - lstart] = cb;
/*      */               } 
/*      */             } 
/*      */           } 
/*      */ 
/*      */ 
/*      */           
/*  605 */           acb0x = 0;
/*  606 */           acb0y = 0;
/*      */           
/*  608 */           p0x = acb0x + j * twoppx2;
/*  609 */           p1x = p0x + twoppx2;
/*  610 */           p0y = acb0y + i * twoppy2;
/*  611 */           p1y = p0y + twoppy2;
/*      */           
/*  613 */           sb = (SubbandAn)root.getSubbandByIdx(r, 3);
/*  614 */           s0x = (p0x < sb.ulcx) ? sb.ulcx : p0x;
/*  615 */           s1x = (p1x > sb.ulcx + sb.w) ? (sb.ulcx + sb.w) : p1x;
/*  616 */           s0y = (p0y < sb.ulcy) ? sb.ulcy : p0y;
/*  617 */           s1y = (p1y > sb.ulcy + sb.h) ? (sb.ulcy + sb.h) : p1y;
/*      */ 
/*      */           
/*  620 */           cw = sb.nomCBlkW;
/*  621 */           ch = sb.nomCBlkH;
/*  622 */           k0 = (int)Math.floor((sb.ulcy - acb0y) / ch);
/*  623 */           kstart = (int)Math.floor((s0y - acb0y) / ch);
/*  624 */           kend = (int)Math.floor((s1y - 1 - acb0y) / ch);
/*  625 */           l0 = (int)Math.floor((sb.ulcx - acb0x) / cw);
/*  626 */           lstart = (int)Math.floor((s0x - acb0x) / cw);
/*  627 */           lend = (int)Math.floor((s1x - 1 - acb0x) / cw);
/*      */           
/*  629 */           if (s1x - s0x <= 0 || s1y - s0y <= 0) {
/*  630 */             (this.ppinfo[t][c][r][nPrec]).nblk[3] = 0;
/*  631 */             this.ttIncl[t][c][r][nPrec][3] = new TagTreeEncoder(0, 0);
/*  632 */             this.ttMaxBP[t][c][r][nPrec][3] = new TagTreeEncoder(0, 0);
/*      */           } else {
/*  634 */             this.ttIncl[t][c][r][nPrec][3] = new TagTreeEncoder(kend - kstart + 1, lend - lstart + 1);
/*      */             
/*  636 */             this.ttMaxBP[t][c][r][nPrec][3] = new TagTreeEncoder(kend - kstart + 1, lend - lstart + 1);
/*      */             
/*  638 */             (this.ppinfo[t][c][r][nPrec]).cblk[3] = new CBlkCoordInfo[kend - kstart + 1][lend - lstart + 1];
/*      */             
/*  640 */             (this.ppinfo[t][c][r][nPrec]).nblk[3] = (kend - kstart + 1) * (lend - lstart + 1);
/*      */ 
/*      */             
/*  643 */             for (int k = kstart; k <= kend; k++) {
/*  644 */               for (int l = lstart; l <= lend; l++) {
/*  645 */                 CBlkCoordInfo cb = new CBlkCoordInfo(k - k0, l - l0);
/*  646 */                 (this.ppinfo[t][c][r][nPrec]).cblk[3][k - kstart][l - lstart] = cb;
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BitOutputBuffer encodePacket(int ly, int c, int r, int t, CBlkRateDistStats[][] cbs, int[][] tIndx, BitOutputBuffer hbuf, byte[] bbuf, int pIdx) {
/*  719 */     int minsb = (r == 0) ? 0 : 1;
/*  720 */     int maxsb = (r == 0) ? 1 : 4;
/*  721 */     Point cbCoord = null;
/*  722 */     SubbandAn root = this.infoSrc.getAnSubbandTree(t, c);
/*      */     
/*  724 */     this.roiInPkt = false;
/*  725 */     this.roiLen = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  730 */     if (pIdx >= (this.ppinfo[t][c][r]).length) {
/*  731 */       this.packetWritable = false;
/*  732 */       return hbuf;
/*      */     } 
/*  734 */     PrecInfo prec = this.ppinfo[t][c][r][pIdx];
/*      */ 
/*      */ 
/*      */     
/*  738 */     boolean isPrecVoid = true;
/*      */     int s;
/*  740 */     for (s = minsb; s < maxsb; ) {
/*  741 */       if (prec.nblk[s] == 0) {
/*      */         s++;
/*      */         
/*      */         continue;
/*      */       } 
/*      */       
/*  747 */       isPrecVoid = false;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  752 */     if (isPrecVoid) {
/*  753 */       this.packetWritable = true;
/*      */       
/*  755 */       if (hbuf == null) {
/*  756 */         hbuf = new BitOutputBuffer();
/*      */       } else {
/*  758 */         hbuf.reset();
/*      */       } 
/*  760 */       if (bbuf == null) {
/*  761 */         this.lbbuf = bbuf = new byte[1];
/*      */       }
/*  763 */       hbuf.writeBit(0);
/*  764 */       this.lblen = 0;
/*      */       
/*  766 */       return hbuf;
/*      */     } 
/*      */     
/*  769 */     if (hbuf == null) {
/*  770 */       hbuf = new BitOutputBuffer();
/*      */     } else {
/*  772 */       hbuf.reset();
/*      */     } 
/*      */ 
/*      */     
/*  776 */     this.lbbuf = null;
/*  777 */     this.lblen = 0;
/*      */ 
/*      */     
/*  780 */     hbuf.writeBit(1);
/*      */     
/*  782 */     for (s = minsb; s < maxsb; s++) {
/*  783 */       SubbandAn sb = (SubbandAn)root.getSubbandByIdx(r, s);
/*      */ 
/*      */ 
/*      */       
/*  787 */       if (prec.nblk[s] != 0) {
/*      */ 
/*      */ 
/*      */         
/*  791 */         TagTreeEncoder cur_ttIncl = this.ttIncl[t][c][r][pIdx][s];
/*  792 */         TagTreeEncoder cur_ttMaxBP = this.ttMaxBP[t][c][r][pIdx][s];
/*  793 */         int[] cur_prevtIdxs = this.prevtIdxs[t][c][r][s];
/*  794 */         CBlkRateDistStats[] cur_cbs = cbs[s];
/*  795 */         int[] cur_tIndx = tIndx[s];
/*      */ 
/*      */         
/*  798 */         int mend = (prec.cblk[s] == null) ? 0 : (prec.cblk[s]).length; int m;
/*  799 */         for (m = 0; m < mend; m++) {
/*  800 */           int nend = (prec.cblk[s][m] == null) ? 0 : (prec.cblk[s][m]).length;
/*  801 */           for (int n = 0; n < nend; n++) {
/*  802 */             cbCoord = (prec.cblk[s][m][n]).idx;
/*  803 */             int b = cbCoord.x + cbCoord.y * sb.numCb.x;
/*      */             
/*  805 */             if (cur_tIndx[b] > cur_prevtIdxs[b] && cur_prevtIdxs[b] < 0)
/*      */             {
/*  807 */               cur_ttIncl.setValue(m, n, ly - 1);
/*      */             }
/*  809 */             if (ly == 1) {
/*  810 */               cur_ttMaxBP.setValue(m, n, (cur_cbs[b]).skipMSBP);
/*      */             }
/*      */           } 
/*      */         } 
/*      */ 
/*      */         
/*  816 */         for (m = 0; m < (prec.cblk[s]).length; m++) {
/*  817 */           int n = 0; while (true) { if (n < (prec.cblk[s][m]).length) {
/*  818 */               cbCoord = (prec.cblk[s][m][n]).idx;
/*  819 */               int b = cbCoord.x + cbCoord.y * sb.numCb.x;
/*      */ 
/*      */               
/*  822 */               if (cur_tIndx[b] > cur_prevtIdxs[b]) {
/*      */                 int k;
/*  824 */                 if (cur_prevtIdxs[b] < 0) {
/*      */                   
/*  826 */                   cur_ttIncl.encode(m, n, ly, hbuf);
/*      */ 
/*      */                   
/*  829 */                   int thmax = (cur_cbs[b]).skipMSBP + 1;
/*  830 */                   for (int i1 = 1; i1 <= thmax; i1++) {
/*  831 */                     cur_ttMaxBP.encode(m, n, i1, hbuf);
/*      */                   }
/*      */ 
/*      */                   
/*  835 */                   this.lblen += (cur_cbs[b]).truncRates[(cur_cbs[b]).truncIdxs[cur_tIndx[b]]];
/*      */                 }
/*      */                 else {
/*      */                   
/*  839 */                   hbuf.writeBit(1);
/*      */                   
/*  841 */                   this.lblen += (cur_cbs[b]).truncRates[(cur_cbs[b]).truncIdxs[cur_tIndx[b]]] - (cur_cbs[b]).truncRates[(cur_cbs[b]).truncIdxs[cur_prevtIdxs[b]]];
/*      */                 } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*  851 */                 if (cur_prevtIdxs[b] < 0) {
/*  852 */                   k = (cur_cbs[b]).truncIdxs[cur_tIndx[b]];
/*      */                 } else {
/*  854 */                   k = (cur_cbs[b]).truncIdxs[cur_tIndx[b]] - (cur_cbs[b]).truncIdxs[cur_prevtIdxs[b]] - 1;
/*      */                 } 
/*      */ 
/*      */ 
/*      */                 
/*  859 */                 switch (k) {
/*      */                   case 0:
/*  861 */                     hbuf.writeBit(0);
/*      */                     break;
/*      */                   case 1:
/*  864 */                     hbuf.writeBits(2, 2);
/*      */                     break;
/*      */ 
/*      */                   
/*      */                   case 2:
/*      */                   case 3:
/*      */                   case 4:
/*  871 */                     hbuf.writeBits(0xC | k - 2, 4);
/*      */                     break;
/*      */                   default:
/*  874 */                     if (k <= 35) {
/*      */ 
/*      */                       
/*  877 */                       hbuf.writeBits(0x1E0 | k - 5, 9); break;
/*  878 */                     }  if (k <= 163) {
/*      */ 
/*      */                       
/*  881 */                       hbuf.writeBits(0xFF80 | k - 36, 16); break;
/*      */                     } 
/*  883 */                     throw new ArithmeticException("Maximum number of truncation points exceeded");
/*      */                 } 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               } else {
/*  890 */                 if (cur_prevtIdxs[b] >= 0) {
/*      */                   
/*  892 */                   hbuf.writeBit(0);
/*      */                 } else {
/*  894 */                   cur_ttIncl.encode(m, n, ly, hbuf);
/*      */                 } 
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*      */                 n++;
/*      */               } 
/*      */ 
/*      */ 
/*      */               
/*  905 */               int newtp = 1;
/*  906 */               int maxi = (cur_cbs[b]).truncIdxs[cur_tIndx[b]];
/*  907 */               int cblen = (cur_prevtIdxs[b] < 0) ? 0 : (cur_cbs[b]).truncRates[(cur_cbs[b]).truncIdxs[cur_prevtIdxs[b]]];
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*  912 */               int i = (cur_prevtIdxs[b] < 0) ? 0 : ((cur_cbs[b]).truncIdxs[cur_prevtIdxs[b]] + 1);
/*      */               
/*  914 */               int minbits = 0;
/*  915 */               for (; i < maxi; i++, newtp++) {
/*      */                 
/*  917 */                 if ((cur_cbs[b]).isTermPass != null && (cur_cbs[b]).isTermPass[i]) {
/*      */ 
/*      */ 
/*      */                   
/*  921 */                   cblen = (cur_cbs[b]).truncRates[i] - cblen;
/*      */ 
/*      */                   
/*  924 */                   int k = this.lblock[t][c][r][s][b] + MathUtil.log2(newtp);
/*      */                   
/*  926 */                   minbits = ((cblen > 0) ? MathUtil.log2(cblen) : 0) + 1;
/*      */ 
/*      */                   
/*  929 */                   for (int i1 = k; i1 < minbits; i1++) {
/*  930 */                     this.lblock[t][c][r][s][b] = this.lblock[t][c][r][s][b] + 1;
/*  931 */                     hbuf.writeBit(1);
/*      */                   } 
/*      */                   
/*  934 */                   newtp = 0;
/*  935 */                   cblen = (cur_cbs[b]).truncRates[i];
/*      */                 } 
/*      */               } 
/*      */ 
/*      */ 
/*      */               
/*  941 */               cblen = (cur_cbs[b]).truncRates[i] - cblen;
/*      */ 
/*      */               
/*  944 */               int prednbits = this.lblock[t][c][r][s][b] + MathUtil.log2(newtp);
/*  945 */               minbits = ((cblen > 0) ? MathUtil.log2(cblen) : 0) + 1;
/*      */               
/*  947 */               for (int j = prednbits; j < minbits; j++) {
/*  948 */                 this.lblock[t][c][r][s][b] = this.lblock[t][c][r][s][b] + 1;
/*  949 */                 hbuf.writeBit(1);
/*      */               } 
/*      */ 
/*      */               
/*  953 */               hbuf.writeBit(0);
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*  958 */               newtp = 1;
/*  959 */               maxi = (cur_cbs[b]).truncIdxs[cur_tIndx[b]];
/*  960 */               cblen = (cur_prevtIdxs[b] < 0) ? 0 : (cur_cbs[b]).truncRates[(cur_cbs[b]).truncIdxs[cur_prevtIdxs[b]]];
/*      */ 
/*      */ 
/*      */               
/*  964 */               i = (cur_prevtIdxs[b] < 0) ? 0 : ((cur_cbs[b]).truncIdxs[cur_prevtIdxs[b]] + 1);
/*      */               
/*  966 */               for (; i < maxi; i++, newtp++) {
/*      */                 
/*  968 */                 if ((cur_cbs[b]).isTermPass != null && (cur_cbs[b]).isTermPass[i]) {
/*      */ 
/*      */                   
/*  971 */                   cblen = (cur_cbs[b]).truncRates[i] - cblen;
/*  972 */                   int k = MathUtil.log2(newtp) + this.lblock[t][c][r][s][b];
/*  973 */                   hbuf.writeBits(cblen, k);
/*      */ 
/*      */                   
/*  976 */                   newtp = 0;
/*  977 */                   cblen = (cur_cbs[b]).truncRates[i];
/*      */                 } 
/*      */               } 
/*      */ 
/*      */ 
/*      */               
/*  983 */               cblen = (cur_cbs[b]).truncRates[i] - cblen;
/*  984 */               int nbits = MathUtil.log2(newtp) + this.lblock[t][c][r][s][b];
/*  985 */               hbuf.writeBits(cblen, nbits);
/*      */             } else {
/*      */               break;
/*      */             } 
/*      */             n++; }
/*      */         
/*      */         } 
/*      */       } 
/*      */     } 
/*  994 */     if (bbuf == null || bbuf.length < this.lblen) {
/*  995 */       bbuf = new byte[this.lblen];
/*      */     }
/*  997 */     this.lbbuf = bbuf;
/*  998 */     this.lblen = 0;
/*      */     
/* 1000 */     for (s = minsb; s < maxsb; s++) {
/* 1001 */       SubbandAn sb = (SubbandAn)root.getSubbandByIdx(r, s);
/*      */       
/* 1003 */       int[] cur_prevtIdxs = this.prevtIdxs[t][c][r][s];
/* 1004 */       CBlkRateDistStats[] cur_cbs = cbs[s];
/* 1005 */       int[] cur_tIndx = tIndx[s];
/* 1006 */       int ncb = cur_prevtIdxs.length;
/*      */       
/* 1008 */       int mend = (prec.cblk[s] == null) ? 0 : (prec.cblk[s]).length;
/* 1009 */       for (int m = 0; m < mend; m++) {
/* 1010 */         int nend = (prec.cblk[s][m] == null) ? 0 : (prec.cblk[s][m]).length;
/* 1011 */         for (int n = 0; n < nend; n++) {
/* 1012 */           cbCoord = (prec.cblk[s][m][n]).idx;
/* 1013 */           int b = cbCoord.x + cbCoord.y * sb.numCb.x;
/*      */           
/* 1015 */           if (cur_tIndx[b] > cur_prevtIdxs[b]) {
/*      */             int cblen;
/*      */ 
/*      */             
/* 1019 */             if (cur_prevtIdxs[b] < 0) {
/* 1020 */               cblen = (cur_cbs[b]).truncRates[(cur_cbs[b]).truncIdxs[cur_tIndx[b]]];
/*      */               
/* 1022 */               System.arraycopy((cur_cbs[b]).data, 0, this.lbbuf, this.lblen, cblen);
/*      */             } else {
/*      */               
/* 1025 */               cblen = (cur_cbs[b]).truncRates[(cur_cbs[b]).truncIdxs[cur_tIndx[b]]] - (cur_cbs[b]).truncRates[(cur_cbs[b]).truncIdxs[cur_prevtIdxs[b]]];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 1031 */               System.arraycopy((cur_cbs[b]).data, (cur_cbs[b]).truncRates[(cur_cbs[b]).truncIdxs[cur_prevtIdxs[b]]], this.lbbuf, this.lblen, cblen);
/*      */             } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1039 */             this.lblen += cblen;
/*      */ 
/*      */ 
/*      */             
/* 1043 */             if ((cur_cbs[b]).nROIcoeff != 0 && (cur_prevtIdxs[b] == -1 || (cur_cbs[b]).truncIdxs[cur_prevtIdxs[b]] <= (cur_cbs[b]).nROIcp - 1)) {
/*      */ 
/*      */ 
/*      */               
/* 1047 */               this.roiInPkt = true;
/* 1048 */               this.roiLen = this.lblen;
/*      */             } 
/*      */ 
/*      */             
/* 1052 */             cur_prevtIdxs[b] = cur_tIndx[b];
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 1058 */     this.packetWritable = true;
/*      */ 
/*      */     
/* 1061 */     if (hbuf.getLength() == 0) {
/* 1062 */       throw new Error("You have found a bug in PktEncoder, method: encodePacket");
/*      */     }
/*      */ 
/*      */     
/* 1066 */     return hbuf;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] getLastBodyBuf() {
/* 1083 */     if (this.lbbuf == null) {
/* 1084 */       throw new IllegalArgumentException();
/*      */     }
/* 1086 */     return this.lbbuf;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getLastBodyLen() {
/* 1099 */     return this.lblen;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void save() {
/* 1112 */     if (this.bak_lblock == null) {
/*      */       
/* 1114 */       this.bak_lblock = new int[this.ttIncl.length][][][][];
/* 1115 */       this.bak_prevtIdxs = new int[this.ttIncl.length][][][][];
/* 1116 */       for (int i = this.ttIncl.length - 1; i >= 0; i--) {
/* 1117 */         this.bak_lblock[i] = new int[(this.ttIncl[i]).length][][][];
/* 1118 */         this.bak_prevtIdxs[i] = new int[(this.ttIncl[i]).length][][][];
/* 1119 */         for (int c = (this.ttIncl[i]).length - 1; c >= 0; c--) {
/* 1120 */           this.bak_lblock[i][c] = new int[(this.lblock[i][c]).length][][];
/* 1121 */           this.bak_prevtIdxs[i][c] = new int[(this.ttIncl[i][c]).length][][];
/* 1122 */           for (int r = (this.lblock[i][c]).length - 1; r >= 0; r--) {
/* 1123 */             this.bak_lblock[i][c][r] = new int[(this.lblock[i][c][r]).length][];
/*      */             
/* 1125 */             this.bak_prevtIdxs[i][c][r] = new int[(this.prevtIdxs[i][c][r]).length][];
/*      */             
/* 1127 */             int minsbi = (r == 0) ? 0 : 1;
/* 1128 */             int maxsbi = (r == 0) ? 1 : 4;
/* 1129 */             for (int s = minsbi; s < maxsbi; s++) {
/* 1130 */               this.bak_lblock[i][c][r][s] = new int[(this.lblock[i][c][r][s]).length];
/*      */               
/* 1132 */               this.bak_prevtIdxs[i][c][r][s] = new int[(this.prevtIdxs[i][c][r][s]).length];
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1155 */     for (int t = this.ttIncl.length - 1; t >= 0; t--) {
/*      */       
/* 1157 */       for (int c = (this.ttIncl[t]).length - 1; c >= 0; c--) {
/*      */         
/* 1159 */         int[][][] lblock_t_c = this.lblock[t][c];
/* 1160 */         int[][][] bak_lblock_t_c = this.bak_lblock[t][c];
/* 1161 */         TagTreeEncoder[][][] ttIncl_t_c = this.ttIncl[t][c];
/* 1162 */         TagTreeEncoder[][][] ttMaxBP_t_c = this.ttMaxBP[t][c];
/*      */         
/* 1164 */         for (int r = lblock_t_c.length - 1; r >= 0; r--) {
/*      */           
/* 1166 */           TagTreeEncoder[][] ttIncl_t_c_r = ttIncl_t_c[r];
/* 1167 */           TagTreeEncoder[][] ttMaxBP_t_c_r = ttMaxBP_t_c[r];
/* 1168 */           int[][] prevtIdxs_t_c_r = this.prevtIdxs[t][c][r];
/* 1169 */           int[][] bak_prevtIdxs_t_c_r = this.bak_prevtIdxs[t][c][r];
/*      */ 
/*      */           
/* 1172 */           int minsbi = (r == 0) ? 0 : 1;
/* 1173 */           int maxsbi = (r == 0) ? 1 : 4;
/* 1174 */           for (int s = minsbi; s < maxsbi; s++) {
/*      */             
/* 1176 */             System.arraycopy(lblock_t_c[r][s], 0, bak_lblock_t_c[r][s], 0, (lblock_t_c[r][s]).length);
/*      */ 
/*      */ 
/*      */             
/* 1180 */             System.arraycopy(prevtIdxs_t_c_r[s], 0, bak_prevtIdxs_t_c_r[s], 0, (prevtIdxs_t_c_r[s]).length);
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1186 */           for (int p = (this.ppinfo[t][c][r]).length - 1; p >= 0; p--) {
/* 1187 */             if (p < ttIncl_t_c_r.length)
/*      */             {
/* 1189 */               for (int i = minsbi; i < maxsbi; i++) {
/* 1190 */                 ttIncl_t_c_r[p][i].save();
/* 1191 */                 ttMaxBP_t_c_r[p][i].save();
/*      */               } 
/*      */             }
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1200 */     this.saved = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void restore() {
/* 1213 */     if (!this.saved) {
/* 1214 */       throw new IllegalArgumentException();
/*      */     }
/*      */ 
/*      */     
/* 1218 */     this.lbbuf = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1229 */     for (int t = this.ttIncl.length - 1; t >= 0; t--) {
/*      */       
/* 1231 */       for (int c = (this.ttIncl[t]).length - 1; c >= 0; c--) {
/*      */         
/* 1233 */         int[][][] lblock_t_c = this.lblock[t][c];
/* 1234 */         int[][][] bak_lblock_t_c = this.bak_lblock[t][c];
/* 1235 */         TagTreeEncoder[][][] ttIncl_t_c = this.ttIncl[t][c];
/* 1236 */         TagTreeEncoder[][][] ttMaxBP_t_c = this.ttMaxBP[t][c];
/*      */         
/* 1238 */         for (int r = lblock_t_c.length - 1; r >= 0; r--) {
/*      */           
/* 1240 */           TagTreeEncoder[][] ttIncl_t_c_r = ttIncl_t_c[r];
/* 1241 */           TagTreeEncoder[][] ttMaxBP_t_c_r = ttMaxBP_t_c[r];
/* 1242 */           int[][] prevtIdxs_t_c_r = this.prevtIdxs[t][c][r];
/* 1243 */           int[][] bak_prevtIdxs_t_c_r = this.bak_prevtIdxs[t][c][r];
/*      */ 
/*      */           
/* 1246 */           int minsbi = (r == 0) ? 0 : 1;
/* 1247 */           int maxsbi = (r == 0) ? 1 : 4;
/* 1248 */           for (int s = minsbi; s < maxsbi; s++) {
/*      */             
/* 1250 */             System.arraycopy(bak_lblock_t_c[r][s], 0, lblock_t_c[r][s], 0, (lblock_t_c[r][s]).length);
/*      */ 
/*      */ 
/*      */             
/* 1254 */             System.arraycopy(bak_prevtIdxs_t_c_r[s], 0, prevtIdxs_t_c_r[s], 0, (prevtIdxs_t_c_r[s]).length);
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1260 */           for (int p = (this.ppinfo[t][c][r]).length - 1; p >= 0; p--) {
/* 1261 */             if (p < ttIncl_t_c_r.length)
/*      */             {
/* 1263 */               for (int i = minsbi; i < maxsbi; i++) {
/* 1264 */                 ttIncl_t_c_r[p][i].restore();
/* 1265 */                 ttMaxBP_t_c_r[p][i].restore();
/*      */               } 
/*      */             }
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void reset() {
/* 1282 */     this.saved = false;
/*      */     
/* 1284 */     this.lbbuf = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1294 */     for (int t = this.ttIncl.length - 1; t >= 0; t--) {
/*      */       
/* 1296 */       for (int c = (this.ttIncl[t]).length - 1; c >= 0; c--) {
/*      */         
/* 1298 */         int[][][] lblock_t_c = this.lblock[t][c];
/* 1299 */         TagTreeEncoder[][][] ttIncl_t_c = this.ttIncl[t][c];
/* 1300 */         TagTreeEncoder[][][] ttMaxBP_t_c = this.ttMaxBP[t][c];
/*      */         
/* 1302 */         for (int r = lblock_t_c.length - 1; r >= 0; r--) {
/*      */           
/* 1304 */           TagTreeEncoder[][] ttIncl_t_c_r = ttIncl_t_c[r];
/* 1305 */           TagTreeEncoder[][] ttMaxBP_t_c_r = ttMaxBP_t_c[r];
/* 1306 */           int[][] prevtIdxs_t_c_r = this.prevtIdxs[t][c][r];
/*      */ 
/*      */           
/* 1309 */           int minsbi = (r == 0) ? 0 : 1;
/* 1310 */           int maxsbi = (r == 0) ? 1 : 4;
/* 1311 */           for (int s = minsbi; s < maxsbi; s++) {
/*      */             
/* 1313 */             ArrayUtil.intArraySet(prevtIdxs_t_c_r[s], -1);
/*      */             
/* 1315 */             ArrayUtil.intArraySet(lblock_t_c[r][s], 3);
/*      */           } 
/*      */ 
/*      */           
/* 1319 */           for (int p = (this.ppinfo[t][c][r]).length - 1; p >= 0; p--) {
/* 1320 */             if (p < ttIncl_t_c_r.length)
/*      */             {
/* 1322 */               for (int i = minsbi; i < maxsbi; i++) {
/* 1323 */                 ttIncl_t_c_r[p][i].reset();
/* 1324 */                 ttMaxBP_t_c_r[p][i].reset();
/*      */               } 
/*      */             }
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isPacketWritable() {
/* 1338 */     return this.packetWritable;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isROIinPkt() {
/* 1345 */     return this.roiInPkt;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getROILen() {
/* 1351 */     return this.roiLen;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[][] getParameterInfo() {
/* 1368 */     return pinfo;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PrecInfo getPrecInfo(int t, int c, int r, int p) {
/* 1383 */     return this.ppinfo[t][c][r][p];
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/codestream/writer/PktEncoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */