/*     */ package jj2000.j2k.codestream.writer;
/*     */ 
/*     */ import jj2000.j2k.util.ArrayUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BitOutputBuffer
/*     */ {
/*     */   byte[] buf;
/*     */   int curbyte;
/* 104 */   int avbits = 8;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int SZ_INCR = 16;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int SZ_INIT = 32;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BitOutputBuffer() {
/* 120 */     this.buf = new byte[32];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset() {
/* 132 */     this.curbyte = 0;
/* 133 */     this.avbits = 8;
/* 134 */     ArrayUtil.byteArraySet(this.buf, (byte)0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void writeBit(int bit) {
/* 148 */     this.buf[this.curbyte] = (byte)(this.buf[this.curbyte] | bit << --this.avbits);
/* 149 */     if (this.avbits > 0) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 154 */     if (this.buf[this.curbyte] != -1) {
/* 155 */       this.avbits = 8;
/*     */     } else {
/*     */       
/* 158 */       this.avbits = 7;
/*     */     } 
/* 160 */     this.curbyte++;
/* 161 */     if (this.curbyte == this.buf.length) {
/*     */       
/* 163 */       byte[] oldbuf = this.buf;
/* 164 */       this.buf = new byte[oldbuf.length + 16];
/* 165 */       System.arraycopy(oldbuf, 0, this.buf, 0, oldbuf.length);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void writeBits(int bits, int n) {
/* 187 */     if ((this.buf.length - this.curbyte << 3) - 8 + this.avbits <= n + 2) {
/*     */       
/* 189 */       byte[] oldbuf = this.buf;
/* 190 */       this.buf = new byte[oldbuf.length + 16];
/* 191 */       System.arraycopy(oldbuf, 0, this.buf, 0, oldbuf.length);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 196 */     if (n >= this.avbits) {
/*     */       
/* 198 */       n -= this.avbits;
/* 199 */       this.buf[this.curbyte] = (byte)(this.buf[this.curbyte] | bits >> n);
/* 200 */       if (this.buf[this.curbyte] != -1) {
/* 201 */         this.avbits = 8;
/*     */       } else {
/*     */         
/* 204 */         this.avbits = 7;
/*     */       } 
/* 206 */       this.curbyte++;
/*     */       
/* 208 */       while (n >= this.avbits) {
/* 209 */         n -= this.avbits;
/* 210 */         this.buf[this.curbyte] = (byte)(this.buf[this.curbyte] | bits >> n & (1 << this.avbits ^ 0xFFFFFFFF));
/* 211 */         if (this.buf[this.curbyte] != -1) {
/*     */           
/* 213 */           this.avbits = 8;
/*     */         } else {
/*     */           
/* 216 */           this.avbits = 7;
/*     */         } 
/* 218 */         this.curbyte++;
/*     */       } 
/*     */     } 
/*     */     
/* 222 */     if (n > 0) {
/* 223 */       this.avbits -= n;
/* 224 */       this.buf[this.curbyte] = (byte)(this.buf[this.curbyte] | (bits & (1 << n) - 1) << this.avbits);
/*     */     } 
/* 226 */     if (this.avbits == 0) {
/* 227 */       if (this.buf[this.curbyte] != -1) {
/* 228 */         this.avbits = 8;
/*     */       } else {
/*     */         
/* 231 */         this.avbits = 7;
/*     */       } 
/* 233 */       this.curbyte++;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getLength() {
/* 245 */     if (this.avbits == 8) {
/* 246 */       return this.curbyte;
/*     */     }
/*     */     
/* 249 */     return this.curbyte + 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final byte[] getBuffer() {
/* 263 */     return this.buf;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] toByteArray(byte[] data) {
/* 279 */     if (data == null) {
/* 280 */       data = new byte[(this.avbits == 8) ? this.curbyte : (this.curbyte + 1)];
/*     */     }
/* 282 */     System.arraycopy(this.buf, 0, data, 0, (this.avbits == 8) ? this.curbyte : (this.curbyte + 1));
/* 283 */     return data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 292 */     return "bits written = " + (this.curbyte * 8 + 8 - this.avbits) + ", curbyte = " + this.curbyte + ", avbits = " + this.avbits;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/codestream/writer/BitOutputBuffer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */