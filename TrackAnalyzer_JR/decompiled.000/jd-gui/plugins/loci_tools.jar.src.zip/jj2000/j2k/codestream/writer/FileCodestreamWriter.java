/*     */ package jj2000.j2k.codestream.writer;
/*     */ 
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import jj2000.j2k.codestream.Markers;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FileCodestreamWriter
/*     */   extends CodestreamWriter
/*     */   implements Markers
/*     */ {
/*     */   private static final int SOP_MARKER_LIMIT = 65535;
/* 109 */   private int tileIdx = 0;
/*     */ 
/*     */ 
/*     */   
/*     */   private OutputStream out;
/*     */ 
/*     */   
/* 116 */   int ndata = 0;
/*     */ 
/*     */   
/* 119 */   public static int DEF_BUF_LEN = 1024;
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] sopMarker;
/*     */ 
/*     */   
/*     */   byte[] ephMarker;
/*     */ 
/*     */   
/* 129 */   int packetIdx = 0;
/*     */ 
/*     */   
/* 132 */   private int offLastROIPkt = 0;
/*     */ 
/*     */   
/* 135 */   private int lenLastNoROI = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FileCodestreamWriter(File file, int mb) throws IOException {
/* 155 */     super(mb);
/* 156 */     this.out = new BufferedOutputStream(new FileOutputStream(file), DEF_BUF_LEN);
/* 157 */     initSOP_EPHArrays();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FileCodestreamWriter(String fname, int mb) throws IOException {
/* 180 */     super(mb);
/* 181 */     this.out = new BufferedOutputStream(new FileOutputStream(fname), DEF_BUF_LEN);
/*     */     
/* 183 */     initSOP_EPHArrays();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FileCodestreamWriter(OutputStream os, int mb) throws IOException {
/* 204 */     super(mb);
/* 205 */     this.out = os;
/* 206 */     initSOP_EPHArrays();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getMaxAvailableBytes() {
/* 219 */     return this.maxBytes - this.ndata;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLength() {
/* 228 */     if (getMaxAvailableBytes() >= 0) {
/* 229 */       return this.ndata;
/*     */     }
/*     */     
/* 232 */     return this.maxBytes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int writePacketHead(byte[] head, int hlen, boolean sim, boolean sop, boolean eph) throws IOException {
/* 277 */     int len = hlen + (sop ? 6 : 0) + (eph ? 2 : 0);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 282 */     if (!sim) {
/*     */       
/* 284 */       if (getMaxAvailableBytes() < len) {
/* 285 */         len = getMaxAvailableBytes();
/*     */       }
/*     */       
/* 288 */       if (len > 0) {
/*     */         
/* 290 */         if (sop) {
/*     */ 
/*     */           
/* 293 */           this.sopMarker[4] = (byte)(this.packetIdx >> 8);
/* 294 */           this.sopMarker[5] = (byte)this.packetIdx;
/* 295 */           this.out.write(this.sopMarker, 0, 6);
/* 296 */           this.packetIdx++;
/* 297 */           if (this.packetIdx > 65535)
/*     */           {
/* 299 */             this.packetIdx = 0;
/*     */           }
/*     */         } 
/* 302 */         this.out.write(head, 0, hlen);
/*     */         
/* 304 */         this.ndata += len;
/*     */ 
/*     */         
/* 307 */         if (eph) {
/* 308 */           this.out.write(this.ephMarker, 0, 2);
/*     */         }
/*     */ 
/*     */         
/* 312 */         this.lenLastNoROI += len;
/*     */       } 
/*     */     } 
/* 315 */     return len;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int writePacketBody(byte[] body, int blen, boolean sim, boolean roiInPkt, int roiLen) throws IOException {
/* 354 */     int len = blen;
/*     */ 
/*     */     
/* 357 */     if (!sim) {
/*     */       
/* 359 */       len = blen;
/* 360 */       if (getMaxAvailableBytes() < len) {
/* 361 */         len = getMaxAvailableBytes();
/*     */       }
/* 363 */       if (blen > 0) {
/* 364 */         this.out.write(body, 0, len);
/*     */       }
/*     */       
/* 367 */       this.ndata += len;
/*     */ 
/*     */       
/* 370 */       if (roiInPkt) {
/* 371 */         this.offLastROIPkt += this.lenLastNoROI + roiLen;
/* 372 */         this.lenLastNoROI = len - roiLen;
/*     */       } else {
/* 374 */         this.lenLastNoROI += len;
/*     */       } 
/*     */     } 
/* 377 */     return len;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 389 */     this.out.write(-1);
/* 390 */     this.out.write(-39);
/*     */     
/* 392 */     this.ndata += 2;
/*     */     
/* 394 */     this.out.close();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getOffLastROIPkt() {
/* 403 */     return this.offLastROIPkt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void commitBitstreamHeader(HeaderEncoder he) throws IOException {
/* 417 */     this.ndata += he.getLength();
/* 418 */     he.writeTo(this.out);
/*     */     
/* 420 */     this.packetIdx = 0;
/*     */ 
/*     */     
/* 423 */     this.lenLastNoROI += he.getLength();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initSOP_EPHArrays() {
/* 434 */     this.sopMarker = new byte[6];
/* 435 */     this.sopMarker[0] = -1;
/* 436 */     this.sopMarker[1] = -111;
/* 437 */     this.sopMarker[2] = 0;
/* 438 */     this.sopMarker[3] = 4;
/*     */ 
/*     */ 
/*     */     
/* 442 */     this.ephMarker = new byte[2];
/* 443 */     this.ephMarker[0] = -1;
/* 444 */     this.ephMarker[1] = -110;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/codestream/writer/FileCodestreamWriter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */