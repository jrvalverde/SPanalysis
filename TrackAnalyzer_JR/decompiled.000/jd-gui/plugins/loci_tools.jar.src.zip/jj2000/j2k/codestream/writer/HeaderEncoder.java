/*      */ package jj2000.j2k.codestream.writer;
/*      */ 
/*      */ import com.sun.media.imageioimpl.plugins.jpeg2000.J2KImageWriteParamJava;
/*      */ import java.awt.Point;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.DataOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.OutputStream;
/*      */ import java.util.StringTokenizer;
/*      */ import java.util.Vector;
/*      */ import jj2000.j2k.codestream.Markers;
/*      */ import jj2000.j2k.entropy.Progression;
/*      */ import jj2000.j2k.entropy.StdEntropyCoderOptions;
/*      */ import jj2000.j2k.entropy.encoder.PostCompRateAllocator;
/*      */ import jj2000.j2k.image.ImgData;
/*      */ import jj2000.j2k.image.Tiler;
/*      */ import jj2000.j2k.io.BinaryDataOutput;
/*      */ import jj2000.j2k.quantization.quantizer.StdQuantizer;
/*      */ import jj2000.j2k.roi.encoder.ROIScaler;
/*      */ import jj2000.j2k.util.MathUtil;
/*      */ import jj2000.j2k.wavelet.analysis.AnWTFilter;
/*      */ import jj2000.j2k.wavelet.analysis.ForwardWT;
/*      */ import jj2000.j2k.wavelet.analysis.SubbandAn;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class HeaderEncoder
/*      */   implements Markers, StdEntropyCoderOptions
/*      */ {
/*      */   private int defimgn;
/*      */   private int deftilenr;
/*      */   protected int nComp;
/*      */   private boolean enJJ2KMarkSeg = true;
/*  140 */   private String otherCOMMarkSeg = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ByteArrayOutputStream baos;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected DataOutputStream hbuf;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ImgData origSrc;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean[] isOrigSig;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected PostCompRateAllocator ralloc;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ForwardWT dwt;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Tiler tiler;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ROIScaler roiSc;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected J2KImageWriteParamJava wp;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HeaderEncoder(ImgData origsrc, boolean[] isorigsig, ForwardWT dwt, Tiler tiler, J2KImageWriteParamJava wp, ROIScaler roiSc, PostCompRateAllocator ralloc) {
/*  202 */     if (origsrc.getNumComps() != isorigsig.length) {
/*  203 */       throw new IllegalArgumentException();
/*      */     }
/*  205 */     this.origSrc = origsrc;
/*  206 */     this.isOrigSig = isorigsig;
/*  207 */     this.dwt = dwt;
/*  208 */     this.tiler = tiler;
/*  209 */     this.wp = wp;
/*  210 */     this.roiSc = roiSc;
/*  211 */     this.ralloc = ralloc;
/*      */     
/*  213 */     this.baos = new ByteArrayOutputStream();
/*  214 */     this.hbuf = new DataOutputStream(this.baos);
/*  215 */     this.nComp = origsrc.getNumComps();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void reset() {
/*  226 */     this.baos.reset();
/*  227 */     this.hbuf = new DataOutputStream(this.baos);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected byte[] getBuffer() {
/*  236 */     return this.baos.toByteArray();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getLength() {
/*  245 */     return this.hbuf.size();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeTo(BinaryDataOutput out) throws IOException {
/*  257 */     byte[] buf = getBuffer();
/*  258 */     int len = getLength();
/*      */     
/*  260 */     for (int i = 0; i < len; i++) {
/*  261 */       out.writeByte(buf[i]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int getBufferLength() {
/*  273 */     return this.baos.size();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeTo(OutputStream out) throws IOException {
/*  282 */     out.write(getBuffer(), 0, getBufferLength());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void writeSOC() throws IOException {
/*  290 */     this.hbuf.writeShort(-177);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void writeSIZ() throws IOException {
/*  303 */     this.hbuf.writeShort(-175);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  310 */     int markSegLen = 38 + 3 * this.nComp;
/*  311 */     this.hbuf.writeShort(markSegLen);
/*      */ 
/*      */     
/*  314 */     this.hbuf.writeShort(0);
/*      */ 
/*      */     
/*  317 */     this.hbuf.writeInt(this.tiler.getImgWidth() + this.tiler.getImgULX());
/*      */ 
/*      */     
/*  320 */     this.hbuf.writeInt(this.tiler.getImgHeight() + this.tiler.getImgULY());
/*      */ 
/*      */ 
/*      */     
/*  324 */     this.hbuf.writeInt(this.tiler.getImgULX());
/*      */ 
/*      */ 
/*      */     
/*  328 */     this.hbuf.writeInt(this.tiler.getImgULY());
/*      */ 
/*      */     
/*  331 */     this.hbuf.writeInt(this.tiler.getNomTileWidth());
/*      */ 
/*      */     
/*  334 */     this.hbuf.writeInt(this.tiler.getNomTileHeight());
/*      */     
/*  336 */     Point torig = this.tiler.getTilingOrigin(null);
/*      */ 
/*      */     
/*  339 */     this.hbuf.writeInt(torig.x);
/*      */ 
/*      */ 
/*      */     
/*  343 */     this.hbuf.writeInt(torig.y);
/*      */ 
/*      */     
/*  346 */     this.hbuf.writeShort(this.nComp);
/*      */ 
/*      */     
/*  349 */     for (int c = 0; c < this.nComp; c++) {
/*      */ 
/*      */       
/*  352 */       int tmp = this.origSrc.getNomRangeBits(c) - 1;
/*      */       
/*  354 */       tmp |= (this.isOrigSig[c] ? 1 : 0) << 7;
/*  355 */       this.hbuf.write(tmp);
/*      */ 
/*      */       
/*  358 */       this.hbuf.write(this.tiler.getCompSubsX(c));
/*      */ 
/*      */       
/*  361 */       this.hbuf.write(this.tiler.getCompSubsY(c));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void writeCOD(boolean mh, int tileIdx) throws IOException {
/*      */     boolean precinctPartitionUsed;
/*      */     Progression[] prog;
/*  387 */     int mrl = 0, a = 0;
/*  388 */     int ppx = 0, ppy = 0;
/*      */ 
/*      */     
/*  391 */     if (mh) {
/*  392 */       mrl = ((Integer)this.wp.getDecompositionLevel().getDefault()).intValue();
/*      */       
/*  394 */       ppx = this.wp.getPrecinctPartition().getPPX(-1, -1, mrl);
/*  395 */       ppy = this.wp.getPrecinctPartition().getPPY(-1, -1, mrl);
/*  396 */       prog = (Progression[])this.wp.getProgressionType().getDefault();
/*      */     } else {
/*      */       
/*  399 */       mrl = ((Integer)this.wp.getDecompositionLevel().getTileDef(tileIdx)).intValue();
/*      */       
/*  401 */       ppx = this.wp.getPrecinctPartition().getPPX(tileIdx, -1, mrl);
/*  402 */       ppy = this.wp.getPrecinctPartition().getPPY(tileIdx, -1, mrl);
/*  403 */       prog = (Progression[])this.wp.getProgressionType().getTileDef(tileIdx);
/*      */     } 
/*      */     
/*  406 */     if (ppx != 65535 || ppy != 65535) {
/*      */       
/*  408 */       precinctPartitionUsed = true;
/*      */     } else {
/*      */       
/*  411 */       precinctPartitionUsed = false;
/*      */     } 
/*      */     
/*  414 */     if (precinctPartitionUsed)
/*      */     {
/*      */       
/*  417 */       a = mrl + 1;
/*      */     }
/*      */ 
/*      */     
/*  421 */     this.hbuf.writeShort(-174);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  427 */     int markSegLen = 12 + a;
/*  428 */     this.hbuf.writeShort(markSegLen);
/*      */ 
/*      */     
/*  431 */     int tmp = 0;
/*  432 */     if (precinctPartitionUsed) {
/*  433 */       tmp = 1;
/*      */     }
/*      */     
/*  436 */     if (mh) {
/*  437 */       if (this.wp.getSOP().getDefault().toString().equalsIgnoreCase("true"))
/*      */       {
/*  439 */         tmp |= 0x2;
/*      */       
/*      */       }
/*      */     }
/*  443 */     else if (this.wp.getSOP().getTileDef(tileIdx).toString().equalsIgnoreCase("true")) {
/*      */       
/*  445 */       tmp |= 0x2;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  450 */     if (mh) {
/*  451 */       if (this.wp.getEPH().getDefault().toString().equalsIgnoreCase("true"))
/*      */       {
/*  453 */         tmp |= 0x4;
/*      */       
/*      */       }
/*      */     }
/*  457 */     else if (this.wp.getEPH().getTileDef(tileIdx).toString().equalsIgnoreCase("true")) {
/*      */       
/*  459 */       tmp |= 0x4;
/*      */     } 
/*      */     
/*  462 */     if (this.dwt.getCbULX() != 0) tmp |= 0x8; 
/*  463 */     if (this.dwt.getCbULY() != 0) tmp |= 0x10; 
/*  464 */     this.hbuf.write(tmp);
/*      */ 
/*      */ 
/*      */     
/*  468 */     this.hbuf.write((prog[0]).type);
/*      */ 
/*      */     
/*  471 */     this.hbuf.writeShort(this.ralloc.getNumLayers());
/*      */ 
/*      */ 
/*      */     
/*  475 */     String str = null;
/*  476 */     if (mh) {
/*  477 */       str = (String)this.wp.getComponentTransformation().getDefault();
/*      */     } else {
/*  479 */       str = (String)this.wp.getComponentTransformation().getTileDef(tileIdx);
/*      */     } 
/*  481 */     if (str.equals("none")) {
/*  482 */       this.hbuf.write(0);
/*      */     } else {
/*  484 */       this.hbuf.write(1);
/*      */     } 
/*      */ 
/*      */     
/*  488 */     this.hbuf.write(mrl);
/*      */ 
/*      */     
/*  491 */     if (mh) {
/*      */       
/*  493 */       tmp = this.wp.getCodeBlockSize().getCBlkWidth((byte)0, -1, -1);
/*      */       
/*  495 */       this.hbuf.write(MathUtil.log2(tmp) - 2);
/*  496 */       tmp = this.wp.getCodeBlockSize().getCBlkHeight((byte)0, -1, -1);
/*      */       
/*  498 */       this.hbuf.write(MathUtil.log2(tmp) - 2);
/*      */     }
/*      */     else {
/*      */       
/*  502 */       tmp = this.wp.getCodeBlockSize().getCBlkWidth((byte)2, tileIdx, -1);
/*      */       
/*  504 */       this.hbuf.write(MathUtil.log2(tmp) - 2);
/*  505 */       tmp = this.wp.getCodeBlockSize().getCBlkHeight((byte)2, tileIdx, -1);
/*      */       
/*  507 */       this.hbuf.write(MathUtil.log2(tmp) - 2);
/*      */     } 
/*      */ 
/*      */     
/*  511 */     tmp = 0;
/*  512 */     if (mh) {
/*      */       
/*  514 */       if (((String)this.wp.getBypass().getDefault()).equals("true")) {
/*  515 */         tmp |= 0x1;
/*      */       }
/*      */       
/*  518 */       if (((String)this.wp.getResetMQ().getDefault()).equals("true")) {
/*  519 */         tmp |= 0x2;
/*      */       }
/*      */       
/*  522 */       if (((String)this.wp.getTerminateOnByte().getDefault()).equals("true")) {
/*  523 */         tmp |= 0x4;
/*      */       }
/*      */       
/*  526 */       if (((String)this.wp.getCausalCXInfo().getDefault()).equals("true")) {
/*  527 */         tmp |= 0x8;
/*      */       }
/*      */       
/*  530 */       if (((String)this.wp.getMethodForMQTermination().getDefault()).equals("predict")) {
/*  531 */         tmp |= 0x10;
/*      */       }
/*      */       
/*  534 */       if (((String)this.wp.getCodeSegSymbol().getDefault()).equals("true")) {
/*  535 */         tmp |= 0x20;
/*      */       
/*      */       }
/*      */     }
/*      */     else {
/*      */       
/*  541 */       if (((String)this.wp.getBypass().getTileDef(tileIdx)).equals("true")) {
/*  542 */         tmp |= 0x1;
/*      */       }
/*      */       
/*  545 */       if (((String)this.wp.getResetMQ().getTileDef(tileIdx)).equals("true")) {
/*  546 */         tmp |= 0x2;
/*      */       }
/*      */       
/*  549 */       if (((String)this.wp.getTerminateOnByte().getTileDef(tileIdx)).equals("true")) {
/*  550 */         tmp |= 0x4;
/*      */       }
/*      */       
/*  553 */       if (((String)this.wp.getCausalCXInfo().getTileDef(tileIdx)).equals("true")) {
/*  554 */         tmp |= 0x8;
/*      */       }
/*      */       
/*  557 */       if (((String)this.wp.getMethodForMQTermination().getTileDef(tileIdx)).equals("predict")) {
/*  558 */         tmp |= 0x10;
/*      */       }
/*      */       
/*  561 */       if (((String)this.wp.getCodeSegSymbol().getTileDef(tileIdx)).equals("true")) {
/*  562 */         tmp |= 0x20;
/*      */       }
/*      */     } 
/*  565 */     this.hbuf.write(tmp);
/*      */ 
/*      */ 
/*      */     
/*  569 */     if (mh) {
/*  570 */       AnWTFilter[][] filt = (AnWTFilter[][])this.wp.getFilters().getDefault();
/*  571 */       this.hbuf.write(filt[0][0].getFilterType());
/*      */     } else {
/*  573 */       AnWTFilter[][] filt = (AnWTFilter[][])this.wp.getFilters().getTileDef(tileIdx);
/*  574 */       this.hbuf.write(filt[0][0].getFilterType());
/*      */     } 
/*      */ 
/*      */     
/*  578 */     if (precinctPartitionUsed) {
/*      */ 
/*      */       
/*  581 */       Vector[] v = null;
/*  582 */       if (mh) {
/*  583 */         v = (Vector[])this.wp.getPrecinctPartition().getDefault();
/*      */       } else {
/*      */         
/*  586 */         v = (Vector[])this.wp.getPrecinctPartition().getTileDef(tileIdx);
/*      */       } 
/*  588 */       for (int r = mrl; r >= 0; r--) {
/*  589 */         if (r >= v[1].size()) {
/*  590 */           tmp = ((Integer)v[1].elementAt(v[1].size() - 1)).intValue();
/*      */         }
/*      */         else {
/*      */           
/*  594 */           tmp = ((Integer)v[1].elementAt(r)).intValue();
/*      */         } 
/*  596 */         int yExp = MathUtil.log2(tmp) << 4 & 0xF0;
/*      */         
/*  598 */         if (r >= v[0].size()) {
/*  599 */           tmp = ((Integer)v[0].elementAt(v[0].size() - 1)).intValue();
/*      */         }
/*      */         else {
/*      */           
/*  603 */           tmp = ((Integer)v[0].elementAt(r)).intValue();
/*      */         } 
/*  605 */         int xExp = MathUtil.log2(tmp) & 0xF;
/*  606 */         this.hbuf.write(yExp | xExp);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void writeCOC(boolean mh, int tileIdx, int compIdx) throws IOException {
/*      */     boolean precinctPartitionUsed;
/*  632 */     int mrl = 0, a = 0;
/*  633 */     int ppx = 0, ppy = 0;
/*      */ 
/*      */     
/*  636 */     if (mh) {
/*  637 */       mrl = ((Integer)this.wp.getDecompositionLevel().getCompDef(compIdx)).intValue();
/*      */       
/*  639 */       ppx = this.wp.getPrecinctPartition().getPPX(-1, compIdx, mrl);
/*  640 */       ppy = this.wp.getPrecinctPartition().getPPY(-1, compIdx, mrl);
/*  641 */       Progression[] prog = (Progression[])this.wp.getProgressionType().getCompDef(compIdx);
/*      */     } else {
/*      */       
/*  644 */       mrl = ((Integer)this.wp.getDecompositionLevel().getTileCompVal(tileIdx, compIdx)).intValue();
/*      */ 
/*      */       
/*  647 */       ppx = this.wp.getPrecinctPartition().getPPX(tileIdx, compIdx, mrl);
/*  648 */       ppy = this.wp.getPrecinctPartition().getPPY(tileIdx, compIdx, mrl);
/*  649 */       Progression[] prog = (Progression[])this.wp.getProgressionType().getTileCompVal(tileIdx, compIdx);
/*      */     } 
/*      */     
/*  652 */     if (ppx != 65535 || ppy != 65535) {
/*      */       
/*  654 */       precinctPartitionUsed = true;
/*      */     } else {
/*      */       
/*  657 */       precinctPartitionUsed = false;
/*      */     } 
/*  659 */     if (precinctPartitionUsed)
/*      */     {
/*      */       
/*  662 */       a = mrl + 1;
/*      */     }
/*      */ 
/*      */     
/*  666 */     this.hbuf.writeShort(-173);
/*      */ 
/*      */ 
/*      */     
/*  670 */     int markSegLen = 8 + ((this.nComp < 257) ? 1 : 2) + a;
/*      */ 
/*      */     
/*  673 */     this.hbuf.writeShort(markSegLen);
/*      */ 
/*      */     
/*  676 */     if (this.nComp < 257) {
/*  677 */       this.hbuf.write(compIdx);
/*      */     } else {
/*      */       
/*  680 */       this.hbuf.writeShort(compIdx);
/*      */     } 
/*      */ 
/*      */     
/*  684 */     int tmp = 0;
/*  685 */     if (precinctPartitionUsed) {
/*  686 */       tmp = 1;
/*      */     }
/*  688 */     this.hbuf.write(tmp);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  694 */     this.hbuf.write(mrl);
/*      */ 
/*      */     
/*  697 */     if (mh) {
/*      */       
/*  699 */       tmp = this.wp.getCodeBlockSize().getCBlkWidth((byte)1, -1, compIdx);
/*      */       
/*  701 */       this.hbuf.write(MathUtil.log2(tmp) - 2);
/*  702 */       tmp = this.wp.getCodeBlockSize().getCBlkHeight((byte)1, -1, compIdx);
/*      */       
/*  704 */       this.hbuf.write(MathUtil.log2(tmp) - 2);
/*      */     }
/*      */     else {
/*      */       
/*  708 */       tmp = this.wp.getCodeBlockSize().getCBlkWidth((byte)3, tileIdx, compIdx);
/*      */       
/*  710 */       this.hbuf.write(MathUtil.log2(tmp) - 2);
/*  711 */       tmp = this.wp.getCodeBlockSize().getCBlkHeight((byte)3, tileIdx, compIdx);
/*      */       
/*  713 */       this.hbuf.write(MathUtil.log2(tmp) - 2);
/*      */     } 
/*      */ 
/*      */     
/*  717 */     tmp = 0;
/*  718 */     if (mh) {
/*      */       
/*  720 */       if (((String)this.wp.getBypass().getCompDef(compIdx)).equals("true")) {
/*  721 */         tmp |= 0x1;
/*      */       }
/*      */       
/*  724 */       if (((String)this.wp.getResetMQ().getCompDef(compIdx)).equalsIgnoreCase("true"))
/*      */       {
/*  726 */         tmp |= 0x2;
/*      */       }
/*      */       
/*  729 */       if (((String)this.wp.getTerminateOnByte().getCompDef(compIdx)).equals("true")) {
/*  730 */         tmp |= 0x4;
/*      */       }
/*      */       
/*  733 */       if (((String)this.wp.getCausalCXInfo().getCompDef(compIdx)).equals("true")) {
/*  734 */         tmp |= 0x8;
/*      */       }
/*      */       
/*  737 */       if (((String)this.wp.getMethodForMQTermination().getCompDef(compIdx)).equals("predict")) {
/*  738 */         tmp |= 0x10;
/*      */       }
/*      */       
/*  741 */       if (((String)this.wp.getCodeSegSymbol().getCompDef(compIdx)).equals("true")) {
/*  742 */         tmp |= 0x20;
/*      */       }
/*      */     } else {
/*      */       
/*  746 */       if (((String)this.wp.getBypass().getTileCompVal(tileIdx, compIdx)).equals("true"))
/*      */       {
/*  748 */         tmp |= 0x1;
/*      */       }
/*      */       
/*  751 */       if (((String)this.wp.getResetMQ().getTileCompVal(tileIdx, compIdx)).equals("true"))
/*      */       {
/*  753 */         tmp |= 0x2;
/*      */       }
/*      */       
/*  756 */       if (((String)this.wp.getTerminateOnByte().getTileCompVal(tileIdx, compIdx)).equals("true"))
/*      */       {
/*  758 */         tmp |= 0x4;
/*      */       }
/*      */       
/*  761 */       if (((String)this.wp.getCausalCXInfo().getTileCompVal(tileIdx, compIdx)).equals("true"))
/*      */       {
/*  763 */         tmp |= 0x8;
/*      */       }
/*      */       
/*  766 */       if (((String)this.wp.getMethodForMQTermination().getTileCompVal(tileIdx, compIdx)).equals("predict"))
/*      */       {
/*  768 */         tmp |= 0x10;
/*      */       }
/*      */       
/*  771 */       if (((String)this.wp.getCodeSegSymbol().getTileCompVal(tileIdx, compIdx)).equals("true"))
/*      */       {
/*  773 */         tmp |= 0x20;
/*      */       }
/*      */     } 
/*  776 */     this.hbuf.write(tmp);
/*      */ 
/*      */ 
/*      */     
/*  780 */     if (mh) {
/*  781 */       AnWTFilter[][] filt = (AnWTFilter[][])this.wp.getFilters().getCompDef(compIdx);
/*  782 */       this.hbuf.write(filt[0][0].getFilterType());
/*      */     } else {
/*  784 */       AnWTFilter[][] filt = (AnWTFilter[][])this.wp.getFilters().getTileCompVal(tileIdx, compIdx);
/*  785 */       this.hbuf.write(filt[0][0].getFilterType());
/*      */     } 
/*      */ 
/*      */     
/*  789 */     if (precinctPartitionUsed) {
/*      */ 
/*      */       
/*  792 */       Vector[] v = null;
/*  793 */       if (mh) {
/*  794 */         v = (Vector[])this.wp.getPrecinctPartition().getCompDef(compIdx);
/*      */       } else {
/*      */         
/*  797 */         v = (Vector[])this.wp.getPrecinctPartition().getTileCompVal(tileIdx, compIdx);
/*      */       } 
/*  799 */       for (int r = mrl; r >= 0; r--) {
/*  800 */         if (r >= v[1].size()) {
/*  801 */           tmp = ((Integer)v[1].elementAt(v[1].size() - 1)).intValue();
/*      */         }
/*      */         else {
/*      */           
/*  805 */           tmp = ((Integer)v[1].elementAt(r)).intValue();
/*      */         } 
/*  807 */         int yExp = MathUtil.log2(tmp) << 4 & 0xF0;
/*      */         
/*  809 */         if (r >= v[0].size()) {
/*  810 */           tmp = ((Integer)v[0].elementAt(v[0].size() - 1)).intValue();
/*      */         }
/*      */         else {
/*      */           
/*  814 */           tmp = ((Integer)v[0].elementAt(r)).intValue();
/*      */         } 
/*  816 */         int xExp = MathUtil.log2(tmp) & 0xF;
/*  817 */         this.hbuf.write(yExp | xExp);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void writeMainQCD() throws IOException {
/*      */     float step;
/*      */     SubbandAn sb;
/*      */     int nqcd, j, i;
/*  833 */     String qType = (String)this.wp.getQuantizationType().getDefault();
/*  834 */     float baseStep = ((Float)this.wp.getQuantizationStep().getDefault()).floatValue();
/*  835 */     int gb = ((Integer)this.wp.getGuardBits().getDefault()).intValue();
/*      */     
/*  837 */     boolean isDerived = qType.equals("derived");
/*  838 */     boolean isReversible = qType.equals("reversible");
/*  839 */     int mrl = ((Integer)this.wp.getDecompositionLevel().getDefault()).intValue();
/*      */     
/*  841 */     int nt = this.dwt.getNumTiles();
/*  842 */     int nc = this.dwt.getNumComps();
/*      */     
/*  844 */     int[] tcIdx = new int[2];
/*      */     
/*  846 */     boolean notFound = true;
/*  847 */     for (int t = 0; t < nt && notFound; t++) {
/*  848 */       for (int c = 0; c < nc && notFound; c++) {
/*  849 */         int tmpI = ((Integer)this.wp.getDecompositionLevel().getTileCompVal(t, c)).intValue();
/*  850 */         String tmpStr = (String)this.wp.getQuantizationType().getTileCompVal(t, c);
/*  851 */         if (tmpI == mrl && tmpStr.equals(qType)) {
/*  852 */           tcIdx[0] = t; tcIdx[1] = c;
/*  853 */           notFound = false;
/*      */         } 
/*      */       } 
/*      */     } 
/*  857 */     if (notFound) {
/*  858 */       throw new Error("Default representative for quantization type  and number of decomposition levels not found  in main QCD marker segment. You have found a JJ2000 bug.");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  864 */     SubbandAn sbRoot = this.dwt.getAnSubbandTree(tcIdx[0], tcIdx[1]);
/*  865 */     this.defimgn = this.dwt.getNomRangeBits(tcIdx[1]);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  870 */     int qstyle = isReversible ? 0 : (isDerived ? 1 : 2);
/*      */ 
/*      */ 
/*      */     
/*  874 */     this.hbuf.writeShort(-164);
/*      */ 
/*      */ 
/*      */     
/*  878 */     switch (qstyle) {
/*      */       case 1:
/*  880 */         nqcd = 1;
/*      */         break;
/*      */       
/*      */       case 0:
/*      */       case 2:
/*  885 */         nqcd = 0;
/*      */         
/*  887 */         sb = sbRoot;
/*      */ 
/*      */         
/*  890 */         sb = (SubbandAn)sb.getSubbandByIdx(0, 0);
/*      */ 
/*      */         
/*  893 */         for (j = 0; j <= mrl; j++) {
/*  894 */           SubbandAn csb = sb;
/*  895 */           while (csb != null) {
/*  896 */             nqcd++;
/*  897 */             csb = (SubbandAn)csb.nextSubband();
/*      */           } 
/*      */           
/*  900 */           sb = (SubbandAn)sb.getNextResLevel();
/*      */         } 
/*      */         break;
/*      */       default:
/*  904 */         throw new Error("Internal JJ2000 error");
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  909 */     int markSegLen = 3 + (isReversible ? nqcd : (2 * nqcd));
/*      */ 
/*      */     
/*  912 */     this.hbuf.writeShort(markSegLen);
/*      */ 
/*      */     
/*  915 */     this.hbuf.write(qstyle + (gb << 5));
/*      */ 
/*      */     
/*  918 */     switch (qstyle) {
/*      */       case 0:
/*  920 */         sb = sbRoot;
/*  921 */         sb = (SubbandAn)sb.getSubbandByIdx(0, 0);
/*      */ 
/*      */         
/*  924 */         for (i = 0; i <= mrl; i++) {
/*  925 */           SubbandAn csb = sb;
/*  926 */           while (csb != null) {
/*  927 */             int tmp = this.defimgn + csb.anGainExp;
/*  928 */             this.hbuf.write(tmp << 3);
/*      */             
/*  930 */             csb = (SubbandAn)csb.nextSubband();
/*      */           } 
/*      */           
/*  933 */           sb = (SubbandAn)sb.getNextResLevel();
/*      */         } 
/*      */         return;
/*      */       case 1:
/*  937 */         sb = sbRoot;
/*  938 */         sb = (SubbandAn)sb.getSubbandByIdx(0, 0);
/*      */ 
/*      */ 
/*      */         
/*  942 */         step = baseStep / (1 << sb.level);
/*      */ 
/*      */         
/*  945 */         this.hbuf.writeShort(StdQuantizer.convertToExpMantissa(step));
/*      */         return;
/*      */       
/*      */       case 2:
/*  949 */         sb = sbRoot;
/*  950 */         sb = (SubbandAn)sb.getSubbandByIdx(0, 0);
/*      */ 
/*      */         
/*  953 */         for (i = 0; i <= mrl; i++) {
/*  954 */           SubbandAn csb = sb;
/*  955 */           while (csb != null) {
/*      */ 
/*      */             
/*  958 */             step = baseStep / csb.l2Norm * (1 << csb.anGainExp);
/*      */ 
/*      */             
/*  961 */             this.hbuf.writeShort(StdQuantizer.convertToExpMantissa(step));
/*      */ 
/*      */             
/*  964 */             csb = (SubbandAn)csb.nextSubband();
/*      */           } 
/*      */           
/*  967 */           sb = (SubbandAn)sb.getNextResLevel();
/*      */         } 
/*      */         return;
/*      */     } 
/*  971 */     throw new Error("Internal JJ2000 error");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void writeMainQCC(int compIdx) throws IOException {
/*      */     int qstyle;
/*      */     float step;
/*      */     SubbandAn sb;
/*  990 */     int nqcc, j, i, tIdx = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  996 */     int imgnr = this.dwt.getNomRangeBits(compIdx);
/*  997 */     String qType = (String)this.wp.getQuantizationType().getCompDef(compIdx);
/*  998 */     float baseStep = ((Float)this.wp.getQuantizationStep().getCompDef(compIdx)).floatValue();
/*  999 */     int gb = ((Integer)this.wp.getGuardBits().getCompDef(compIdx)).intValue();
/*      */     
/* 1001 */     boolean isReversible = qType.equals("reversible");
/* 1002 */     boolean isDerived = qType.equals("derived");
/*      */     
/* 1004 */     int mrl = ((Integer)this.wp.getDecompositionLevel().getCompDef(compIdx)).intValue();
/*      */     
/* 1006 */     int nt = this.dwt.getNumTiles();
/* 1007 */     int nc = this.dwt.getNumComps();
/*      */ 
/*      */     
/* 1010 */     boolean notFound = true;
/* 1011 */     for (int t = 0; t < nt && notFound; t++) {
/* 1012 */       for (int c = 0; c < nc && notFound; c++) {
/* 1013 */         int tmpI = ((Integer)this.wp.getDecompositionLevel().getTileCompVal(t, c)).intValue();
/* 1014 */         String tmpStr = (String)this.wp.getQuantizationType().getTileCompVal(t, c);
/* 1015 */         if (tmpI == mrl && tmpStr.equals(qType)) {
/* 1016 */           tIdx = t;
/* 1017 */           notFound = false;
/*      */         } 
/*      */       } 
/*      */     } 
/* 1021 */     if (notFound) {
/* 1022 */       throw new Error("Default representative for quantization type  and number of decomposition levels not found  in main QCC (c=" + compIdx + ") marker segment. " + "You have found a JJ2000 bug.");
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1027 */     SubbandAn sbRoot = this.dwt.getAnSubbandTree(tIdx, compIdx);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1032 */     if (isReversible) {
/* 1033 */       qstyle = 0;
/*      */     }
/* 1035 */     else if (isDerived) {
/* 1036 */       qstyle = 1;
/*      */     } else {
/*      */       
/* 1039 */       qstyle = 2;
/*      */     } 
/*      */ 
/*      */     
/* 1043 */     this.hbuf.writeShort(-163);
/*      */ 
/*      */     
/* 1046 */     switch (qstyle) {
/*      */       case 1:
/* 1048 */         nqcc = 1;
/*      */         break;
/*      */       
/*      */       case 0:
/*      */       case 2:
/* 1053 */         nqcc = 0;
/*      */         
/* 1055 */         sb = sbRoot;
/* 1056 */         mrl = sb.resLvl;
/*      */ 
/*      */         
/* 1059 */         sb = (SubbandAn)sb.getSubbandByIdx(0, 0);
/*      */ 
/*      */         
/* 1062 */         while (sb.resLvl != 0) {
/* 1063 */           sb = sb.subb_LL;
/*      */         }
/*      */ 
/*      */         
/* 1067 */         for (j = 0; j <= mrl; j++) {
/* 1068 */           SubbandAn sb2 = sb;
/* 1069 */           while (sb2 != null) {
/* 1070 */             nqcc++;
/* 1071 */             sb2 = (SubbandAn)sb2.nextSubband();
/*      */           } 
/*      */           
/* 1074 */           sb = (SubbandAn)sb.getNextResLevel();
/*      */         } 
/*      */         break;
/*      */       default:
/* 1078 */         throw new Error("Internal JJ2000 error");
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1083 */     int markSegLen = 3 + ((this.nComp < 257) ? 1 : 2) + (isReversible ? nqcc : (2 * nqcc));
/*      */     
/* 1085 */     this.hbuf.writeShort(markSegLen);
/*      */ 
/*      */     
/* 1088 */     if (this.nComp < 257) {
/* 1089 */       this.hbuf.write(compIdx);
/*      */     } else {
/*      */       
/* 1092 */       this.hbuf.writeShort(compIdx);
/*      */     } 
/*      */ 
/*      */     
/* 1096 */     this.hbuf.write(qstyle + (gb << 5));
/*      */ 
/*      */     
/* 1099 */     switch (qstyle) {
/*      */       
/*      */       case 0:
/* 1102 */         sb = sbRoot;
/* 1103 */         sb = (SubbandAn)sb.getSubbandByIdx(0, 0);
/*      */ 
/*      */         
/* 1106 */         for (i = 0; i <= mrl; i++) {
/* 1107 */           SubbandAn sb2 = sb;
/* 1108 */           while (sb2 != null) {
/* 1109 */             int tmp = imgnr + sb2.anGainExp;
/* 1110 */             this.hbuf.write(tmp << 3);
/*      */             
/* 1112 */             sb2 = (SubbandAn)sb2.nextSubband();
/*      */           } 
/*      */           
/* 1115 */           sb = (SubbandAn)sb.getNextResLevel();
/*      */         } 
/*      */         return;
/*      */       
/*      */       case 1:
/* 1120 */         sb = sbRoot;
/* 1121 */         sb = (SubbandAn)sb.getSubbandByIdx(0, 0);
/*      */ 
/*      */ 
/*      */         
/* 1125 */         step = baseStep / (1 << sb.level);
/*      */ 
/*      */         
/* 1128 */         this.hbuf.writeShort(StdQuantizer.convertToExpMantissa(step));
/*      */         return;
/*      */ 
/*      */       
/*      */       case 2:
/* 1133 */         sb = sbRoot;
/* 1134 */         mrl = sb.resLvl;
/*      */         
/* 1136 */         sb = (SubbandAn)sb.getSubbandByIdx(0, 0);
/*      */         
/* 1138 */         for (i = 0; i <= mrl; i++) {
/* 1139 */           SubbandAn sb2 = sb;
/* 1140 */           while (sb2 != null) {
/*      */ 
/*      */             
/* 1143 */             step = baseStep / sb2.l2Norm * (1 << sb2.anGainExp);
/*      */ 
/*      */             
/* 1146 */             this.hbuf.writeShort(StdQuantizer.convertToExpMantissa(step));
/*      */             
/* 1148 */             sb2 = (SubbandAn)sb2.nextSubband();
/*      */           } 
/*      */           
/* 1151 */           sb = (SubbandAn)sb.getNextResLevel();
/*      */         } 
/*      */         return;
/*      */     } 
/* 1155 */     throw new Error("Internal JJ2000 error");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void writeTileQCD(int tIdx) throws IOException {
/*      */     float step;
/*      */     SubbandAn sb;
/*      */     int nqcd, j, i;
/* 1175 */     String qType = (String)this.wp.getQuantizationType().getTileDef(tIdx);
/* 1176 */     float baseStep = ((Float)this.wp.getQuantizationStep().getTileDef(tIdx)).floatValue();
/* 1177 */     int mrl = ((Integer)this.wp.getDecompositionLevel().getTileDef(tIdx)).intValue();
/*      */     
/* 1179 */     int nc = this.dwt.getNumComps();
/*      */ 
/*      */     
/* 1182 */     boolean notFound = true;
/* 1183 */     int compIdx = 0;
/* 1184 */     for (int c = 0; c < nc && notFound; c++) {
/* 1185 */       int tmpI = ((Integer)this.wp.getDecompositionLevel().getTileCompVal(tIdx, c)).intValue();
/* 1186 */       String tmpStr = (String)this.wp.getQuantizationStep().getTileCompVal(tIdx, c);
/* 1187 */       if (tmpI == mrl && tmpStr.equals(qType)) {
/* 1188 */         compIdx = c;
/* 1189 */         notFound = false;
/*      */       } 
/*      */     } 
/* 1192 */     if (notFound) {
/* 1193 */       throw new Error("Default representative for quantization type  and number of decomposition levels not found  in tile QCD (t=" + tIdx + ") marker segment. " + "You have found a JJ2000 bug.");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1199 */     SubbandAn sbRoot = this.dwt.getAnSubbandTree(tIdx, compIdx);
/* 1200 */     this.deftilenr = this.dwt.getNomRangeBits(compIdx);
/* 1201 */     int gb = ((Integer)this.wp.getGuardBits().getTileDef(tIdx)).intValue();
/*      */     
/* 1203 */     boolean isDerived = qType.equals("derived");
/* 1204 */     boolean isReversible = qType.equals("reversible");
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1209 */     int qstyle = isReversible ? 0 : (isDerived ? 1 : 2);
/*      */ 
/*      */ 
/*      */     
/* 1213 */     this.hbuf.writeShort(-164);
/*      */ 
/*      */     
/* 1216 */     switch (qstyle) {
/*      */       case 1:
/* 1218 */         nqcd = 1;
/*      */         break;
/*      */       
/*      */       case 0:
/*      */       case 2:
/* 1223 */         nqcd = 0;
/*      */         
/* 1225 */         sb = sbRoot;
/*      */ 
/*      */         
/* 1228 */         sb = (SubbandAn)sb.getSubbandByIdx(0, 0);
/*      */ 
/*      */         
/* 1231 */         for (j = 0; j <= mrl; j++) {
/* 1232 */           SubbandAn csb = sb;
/* 1233 */           while (csb != null) {
/* 1234 */             nqcd++;
/* 1235 */             csb = (SubbandAn)csb.nextSubband();
/*      */           } 
/*      */           
/* 1238 */           sb = (SubbandAn)sb.getNextResLevel();
/*      */         } 
/*      */         break;
/*      */       default:
/* 1242 */         throw new Error("Internal JJ2000 error");
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1247 */     int markSegLen = 3 + (isReversible ? nqcd : (2 * nqcd));
/*      */ 
/*      */     
/* 1250 */     this.hbuf.writeShort(markSegLen);
/*      */ 
/*      */     
/* 1253 */     this.hbuf.write(qstyle + (gb << 5));
/*      */ 
/*      */     
/* 1256 */     switch (qstyle) {
/*      */       case 0:
/* 1258 */         sb = sbRoot;
/* 1259 */         sb = (SubbandAn)sb.getSubbandByIdx(0, 0);
/*      */ 
/*      */         
/* 1262 */         for (i = 0; i <= mrl; i++) {
/* 1263 */           SubbandAn csb = sb;
/* 1264 */           while (csb != null) {
/* 1265 */             int tmp = this.deftilenr + csb.anGainExp;
/* 1266 */             this.hbuf.write(tmp << 3);
/*      */             
/* 1268 */             csb = (SubbandAn)csb.nextSubband();
/*      */           } 
/*      */           
/* 1271 */           sb = (SubbandAn)sb.getNextResLevel();
/*      */         } 
/*      */         return;
/*      */       case 1:
/* 1275 */         sb = sbRoot;
/* 1276 */         sb = (SubbandAn)sb.getSubbandByIdx(0, 0);
/*      */ 
/*      */ 
/*      */         
/* 1280 */         step = baseStep / (1 << sb.level);
/*      */ 
/*      */         
/* 1283 */         this.hbuf.writeShort(StdQuantizer.convertToExpMantissa(step));
/*      */         return;
/*      */       
/*      */       case 2:
/* 1287 */         sb = sbRoot;
/* 1288 */         sb = (SubbandAn)sb.getSubbandByIdx(0, 0);
/*      */ 
/*      */         
/* 1291 */         for (i = 0; i <= mrl; i++) {
/* 1292 */           SubbandAn csb = sb;
/* 1293 */           while (csb != null) {
/*      */ 
/*      */             
/* 1296 */             step = baseStep / csb.l2Norm * (1 << csb.anGainExp);
/*      */ 
/*      */             
/* 1299 */             this.hbuf.writeShort(StdQuantizer.convertToExpMantissa(step));
/*      */ 
/*      */             
/* 1302 */             csb = (SubbandAn)csb.nextSubband();
/*      */           } 
/*      */           
/* 1305 */           sb = (SubbandAn)sb.getNextResLevel();
/*      */         } 
/*      */         return;
/*      */     } 
/* 1309 */     throw new Error("Internal JJ2000 error");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void writeTileQCC(int t, int compIdx) throws IOException {
/*      */     int qstyle;
/*      */     float step;
/*      */     SubbandAn sb;
/*      */     int nqcc, j, i;
/* 1335 */     SubbandAn sbRoot = this.dwt.getAnSubbandTree(t, compIdx);
/* 1336 */     int imgnr = this.dwt.getNomRangeBits(compIdx);
/* 1337 */     String qType = (String)this.wp.getQuantizationType().getTileCompVal(t, compIdx);
/* 1338 */     float baseStep = ((Float)this.wp.getQuantizationStep().getTileCompVal(t, compIdx)).floatValue();
/*      */     
/* 1340 */     int gb = ((Integer)this.wp.getGuardBits().getTileCompVal(t, compIdx)).intValue();
/*      */     
/* 1342 */     boolean isReversible = qType.equals("reversible");
/* 1343 */     boolean isDerived = qType.equals("derived");
/*      */     
/* 1345 */     int mrl = ((Integer)this.wp.getDecompositionLevel().getTileCompVal(t, compIdx)).intValue();
/*      */ 
/*      */     
/* 1348 */     if (isReversible) {
/* 1349 */       qstyle = 0;
/*      */     }
/* 1351 */     else if (isDerived) {
/* 1352 */       qstyle = 1;
/*      */     } else {
/*      */       
/* 1355 */       qstyle = 2;
/*      */     } 
/*      */ 
/*      */     
/* 1359 */     this.hbuf.writeShort(-163);
/*      */ 
/*      */     
/* 1362 */     switch (qstyle) {
/*      */       case 1:
/* 1364 */         nqcc = 1;
/*      */         break;
/*      */       
/*      */       case 0:
/*      */       case 2:
/* 1369 */         nqcc = 0;
/*      */         
/* 1371 */         sb = sbRoot;
/* 1372 */         mrl = sb.resLvl;
/*      */ 
/*      */         
/* 1375 */         sb = (SubbandAn)sb.getSubbandByIdx(0, 0);
/*      */ 
/*      */         
/* 1378 */         while (sb.resLvl != 0) {
/* 1379 */           sb = sb.subb_LL;
/*      */         }
/*      */ 
/*      */         
/* 1383 */         for (j = 0; j <= mrl; j++) {
/* 1384 */           SubbandAn sb2 = sb;
/* 1385 */           while (sb2 != null) {
/* 1386 */             nqcc++;
/* 1387 */             sb2 = (SubbandAn)sb2.nextSubband();
/*      */           } 
/*      */           
/* 1390 */           sb = (SubbandAn)sb.getNextResLevel();
/*      */         } 
/*      */         break;
/*      */       default:
/* 1394 */         throw new Error("Internal JJ2000 error");
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1399 */     int markSegLen = 3 + ((this.nComp < 257) ? 1 : 2) + (isReversible ? nqcc : (2 * nqcc));
/*      */     
/* 1401 */     this.hbuf.writeShort(markSegLen);
/*      */ 
/*      */     
/* 1404 */     if (this.nComp < 257) {
/* 1405 */       this.hbuf.write(compIdx);
/*      */     } else {
/*      */       
/* 1408 */       this.hbuf.writeShort(compIdx);
/*      */     } 
/*      */ 
/*      */     
/* 1412 */     this.hbuf.write(qstyle + (gb << 5));
/*      */ 
/*      */     
/* 1415 */     switch (qstyle) {
/*      */       
/*      */       case 0:
/* 1418 */         sb = sbRoot;
/* 1419 */         sb = (SubbandAn)sb.getSubbandByIdx(0, 0);
/*      */ 
/*      */         
/* 1422 */         for (i = 0; i <= mrl; i++) {
/* 1423 */           SubbandAn sb2 = sb;
/* 1424 */           while (sb2 != null) {
/* 1425 */             int tmp = imgnr + sb2.anGainExp;
/* 1426 */             this.hbuf.write(tmp << 3);
/*      */             
/* 1428 */             sb2 = (SubbandAn)sb2.nextSubband();
/*      */           } 
/*      */           
/* 1431 */           sb = (SubbandAn)sb.getNextResLevel();
/*      */         } 
/*      */         return;
/*      */       
/*      */       case 1:
/* 1436 */         sb = sbRoot;
/* 1437 */         sb = (SubbandAn)sb.getSubbandByIdx(0, 0);
/*      */ 
/*      */ 
/*      */         
/* 1441 */         step = baseStep / (1 << sb.level);
/*      */ 
/*      */         
/* 1444 */         this.hbuf.writeShort(StdQuantizer.convertToExpMantissa(step));
/*      */         return;
/*      */ 
/*      */       
/*      */       case 2:
/* 1449 */         sb = sbRoot;
/* 1450 */         mrl = sb.resLvl;
/*      */         
/* 1452 */         sb = (SubbandAn)sb.getSubbandByIdx(0, 0);
/*      */         
/* 1454 */         for (i = 0; i <= mrl; i++) {
/* 1455 */           SubbandAn sb2 = sb;
/* 1456 */           while (sb2 != null) {
/*      */ 
/*      */             
/* 1459 */             step = baseStep / sb2.l2Norm * (1 << sb2.anGainExp);
/*      */ 
/*      */             
/* 1462 */             this.hbuf.writeShort(StdQuantizer.convertToExpMantissa(step));
/*      */             
/* 1464 */             sb2 = (SubbandAn)sb2.nextSubband();
/*      */           } 
/*      */           
/* 1467 */           sb = (SubbandAn)sb.getNextResLevel();
/*      */         } 
/*      */         return;
/*      */     } 
/* 1471 */     throw new Error("Internal JJ2000 error");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void writePOC(boolean mh, int tileIdx) throws IOException {
/* 1485 */     int markSegLen = 0;
/*      */ 
/*      */ 
/*      */     
/* 1489 */     Progression[] prog = null;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1494 */     if (mh) {
/* 1495 */       prog = (Progression[])this.wp.getProgressionType().getDefault();
/*      */     } else {
/*      */       
/* 1498 */       prog = (Progression[])this.wp.getProgressionType().getTileDef(tileIdx);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1503 */     int lenCompField = (this.nComp < 257) ? 1 : 2;
/*      */ 
/*      */     
/* 1506 */     this.hbuf.writeShort(-161);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1511 */     int npoc = prog.length;
/* 1512 */     markSegLen = 2 + npoc * (1 + lenCompField + 2 + 1 + lenCompField + 1);
/* 1513 */     this.hbuf.writeShort(markSegLen);
/*      */ 
/*      */     
/* 1516 */     for (int i = 0; i < npoc; i++) {
/*      */       
/* 1518 */       this.hbuf.write((prog[i]).rs);
/*      */       
/* 1520 */       if (lenCompField == 2) {
/* 1521 */         this.hbuf.writeShort((prog[i]).cs);
/*      */       } else {
/*      */         
/* 1524 */         this.hbuf.write((prog[i]).cs);
/*      */       } 
/*      */       
/* 1527 */       this.hbuf.writeShort((prog[i]).lye);
/*      */       
/* 1529 */       this.hbuf.write((prog[i]).re);
/*      */       
/* 1531 */       if (lenCompField == 2) {
/* 1532 */         this.hbuf.writeShort((prog[i]).ce);
/*      */       } else {
/*      */         
/* 1535 */         this.hbuf.write((prog[i]).ce);
/*      */       } 
/*      */       
/* 1538 */       this.hbuf.write((prog[i]).type);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void encodeMainHeader() throws IOException {
/* 1557 */     writeSOC();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1562 */     writeSIZ();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1567 */     boolean isEresUsed = ((String)this.wp.getTerminateOnByte().getDefault()).equals("predict");
/*      */     
/* 1569 */     writeCOD(true, 0);
/*      */ 
/*      */     
/*      */     int i;
/*      */     
/* 1574 */     for (i = 0; i < this.nComp; i++) {
/* 1575 */       boolean isEresUsedinComp = ((String)this.wp.getTerminateOnByte().getCompDef(i)).equals("predict");
/*      */       
/* 1577 */       if (this.wp.getFilters().isCompSpecified(i) || this.wp.getDecompositionLevel().isCompSpecified(i) || this.wp.getBypass().isCompSpecified(i) || this.wp.getResetMQ().isCompSpecified(i) || this.wp.getMethodForMQTermination().isCompSpecified(i) || this.wp.getCodeSegSymbol().isCompSpecified(i) || this.wp.getCausalCXInfo().isCompSpecified(i) || this.wp.getPrecinctPartition().isCompSpecified(i) || this.wp.getCodeBlockSize().isCompSpecified(i) || isEresUsed != isEresUsedinComp)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1588 */         writeCOC(true, 0, i);
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1594 */     writeMainQCD();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1600 */     for (i = 0; i < this.nComp; i++) {
/* 1601 */       if (this.dwt.getNomRangeBits(i) != this.defimgn || this.wp.getQuantizationType().isCompSpecified(i) || this.wp.getQuantizationStep().isCompSpecified(i) || this.wp.getDecompositionLevel().isCompSpecified(i) || this.wp.getGuardBits().isCompSpecified(i))
/*      */       {
/*      */ 
/*      */ 
/*      */         
/* 1606 */         writeMainQCC(i);
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1613 */     Progression[] prog = (Progression[])this.wp.getProgressionType().getDefault();
/* 1614 */     if (prog.length > 1) {
/* 1615 */       writePOC(true, 0);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1620 */     writeCOM();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void writeCOM() throws IOException {
/* 1631 */     if (this.enJJ2KMarkSeg) {
/* 1632 */       String str = "Created by: JJ2000 version 4.1";
/*      */ 
/*      */ 
/*      */       
/* 1636 */       this.hbuf.writeShort(-156);
/*      */ 
/*      */       
/* 1639 */       int markSegLen = 4 + str.length();
/* 1640 */       this.hbuf.writeShort(markSegLen);
/*      */ 
/*      */       
/* 1643 */       this.hbuf.writeShort(1);
/*      */       
/* 1645 */       byte[] chars = str.getBytes();
/* 1646 */       for (int i = 0; i < chars.length; i++) {
/* 1647 */         this.hbuf.writeByte(chars[i]);
/*      */       }
/*      */     } 
/*      */     
/* 1651 */     if (this.otherCOMMarkSeg != null) {
/* 1652 */       StringTokenizer stk = new StringTokenizer(this.otherCOMMarkSeg, "#");
/* 1653 */       while (stk.hasMoreTokens()) {
/* 1654 */         String str = stk.nextToken();
/*      */ 
/*      */ 
/*      */         
/* 1658 */         this.hbuf.writeShort(-156);
/*      */ 
/*      */         
/* 1661 */         int markSegLen = 4 + str.length();
/* 1662 */         this.hbuf.writeShort(markSegLen);
/*      */ 
/*      */         
/* 1665 */         this.hbuf.writeShort(1);
/*      */ 
/*      */         
/* 1668 */         byte[] chars = str.getBytes();
/* 1669 */         for (int i = 0; i < chars.length; i++) {
/* 1670 */           this.hbuf.writeByte(chars[i]);
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void writeRGN(int tIdx) throws IOException {
/* 1694 */     for (int i = 0; i < this.nComp; i++) {
/*      */       
/* 1696 */       this.hbuf.writeShort(-162);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1701 */       int markSegLen = 4 + ((this.nComp < 257) ? 1 : 2);
/* 1702 */       this.hbuf.writeShort(markSegLen);
/*      */ 
/*      */       
/* 1705 */       if (this.nComp < 257) {
/* 1706 */         this.hbuf.writeByte(i);
/*      */       } else {
/* 1708 */         this.hbuf.writeShort(i);
/*      */       } 
/*      */       
/* 1711 */       this.hbuf.writeByte(0);
/*      */ 
/*      */       
/* 1714 */       this.hbuf.writeByte(((Integer)this.wp.getROIs().getTileCompVal(tIdx, i)).intValue());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void encodeTilePartHeader(int tileLength, int tileIdx) throws IOException {
/* 1733 */     Point numTiles = this.ralloc.getNumTiles(null);
/* 1734 */     this.ralloc.setTile(tileIdx % numTiles.x, tileIdx / numTiles.x);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1740 */     this.hbuf.writeByte(-1);
/* 1741 */     this.hbuf.writeByte(-112);
/*      */ 
/*      */     
/* 1744 */     this.hbuf.writeByte(0);
/* 1745 */     this.hbuf.writeByte(10);
/*      */ 
/*      */     
/* 1748 */     if (tileIdx > 65534) {
/* 1749 */       throw new IllegalArgumentException("Trying to write a tile-part header whose tile index is too high");
/*      */     }
/*      */ 
/*      */     
/* 1753 */     this.hbuf.writeByte(tileIdx >> 8);
/* 1754 */     this.hbuf.writeByte(tileIdx);
/*      */ 
/*      */     
/* 1757 */     int tmp = tileLength;
/* 1758 */     this.hbuf.writeByte(tmp >> 24);
/* 1759 */     this.hbuf.writeByte(tmp >> 16);
/* 1760 */     this.hbuf.writeByte(tmp >> 8);
/* 1761 */     this.hbuf.writeByte(tmp);
/*      */ 
/*      */     
/* 1764 */     this.hbuf.writeByte(0);
/*      */ 
/*      */     
/* 1767 */     this.hbuf.writeByte(1);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1772 */     boolean isEresUsed = ((String)this.wp.getMethodForMQTermination().getDefault()).equals("predict");
/*      */     
/* 1774 */     boolean isEresUsedInTile = ((String)this.wp.getMethodForMQTermination().getTileDef(tileIdx)).equals("predict");
/*      */     
/* 1776 */     boolean tileCODwritten = false;
/* 1777 */     if (this.wp.getFilters().isTileSpecified(tileIdx) || this.wp.getComponentTransformation().isTileSpecified(tileIdx) || this.wp.getDecompositionLevel().isTileSpecified(tileIdx) || this.wp.getBypass().isTileSpecified(tileIdx) || this.wp.getResetMQ().isTileSpecified(tileIdx) || this.wp.getTerminateOnByte().isTileSpecified(tileIdx) || this.wp.getCausalCXInfo().isTileSpecified(tileIdx) || this.wp.getPrecinctPartition().isTileSpecified(tileIdx) || this.wp.getSOP().isTileSpecified(tileIdx) || this.wp.getCodeSegSymbol().isTileSpecified(tileIdx) || this.wp.getProgressionType().isTileSpecified(tileIdx) || this.wp.getEPH().isTileSpecified(tileIdx) || this.wp.getCodeBlockSize().isTileSpecified(tileIdx) || isEresUsed != isEresUsedInTile) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1791 */       writeCOD(false, tileIdx);
/* 1792 */       tileCODwritten = true;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1798 */     for (int c = 0; c < this.nComp; c++) {
/* 1799 */       boolean isEresUsedInTileComp = ((String)this.wp.getMethodForMQTermination().getTileCompVal(tileIdx, c)).equals("predict");
/*      */ 
/*      */ 
/*      */       
/* 1803 */       if (this.wp.getFilters().isTileCompSpecified(tileIdx, c) || this.wp.getDecompositionLevel().isTileCompSpecified(tileIdx, c) || this.wp.getBypass().isTileCompSpecified(tileIdx, c) || this.wp.getResetMQ().isTileCompSpecified(tileIdx, c) || this.wp.getTerminateOnByte().isTileCompSpecified(tileIdx, c) || this.wp.getCausalCXInfo().isTileCompSpecified(tileIdx, c) || this.wp.getPrecinctPartition().isTileCompSpecified(tileIdx, c) || this.wp.getCodeSegSymbol().isTileCompSpecified(tileIdx, c) || this.wp.getCodeBlockSize().isTileCompSpecified(tileIdx, c) || isEresUsedInTileComp != isEresUsed) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1813 */         writeCOC(false, tileIdx, c);
/*      */       }
/* 1815 */       else if (tileCODwritten && (
/* 1816 */         this.wp.getFilters().isCompSpecified(c) || this.wp.getDecompositionLevel().isCompSpecified(c) || this.wp.getBypass().isCompSpecified(c) || this.wp.getResetMQ().isCompSpecified(c) || this.wp.getTerminateOnByte().isCompSpecified(c) || this.wp.getCodeSegSymbol().isCompSpecified(c) || this.wp.getCausalCXInfo().isCompSpecified(c) || this.wp.getPrecinctPartition().isCompSpecified(c) || this.wp.getCodeBlockSize().isCompSpecified(c) || (this.wp.getMethodForMQTermination().isCompSpecified(c) && ((String)this.wp.getMethodForMQTermination().getCompDef(c)).equals("predict")))) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1827 */         writeCOC(false, tileIdx, c);
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1835 */     boolean tileQCDwritten = false;
/* 1836 */     if (this.wp.getQuantizationType().isTileSpecified(tileIdx) || this.wp.getQuantizationStep().isTileSpecified(tileIdx) || this.wp.getDecompositionLevel().isTileSpecified(tileIdx) || this.wp.getGuardBits().isTileSpecified(tileIdx)) {
/*      */ 
/*      */ 
/*      */       
/* 1840 */       writeTileQCD(tileIdx);
/* 1841 */       tileQCDwritten = true;
/*      */     } else {
/* 1843 */       this.deftilenr = this.defimgn;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1849 */     for (int i = 0; i < this.nComp; i++) {
/* 1850 */       if (this.dwt.getNomRangeBits(i) != this.deftilenr || this.wp.getQuantizationType().isTileCompSpecified(tileIdx, i) || this.wp.getQuantizationStep().isTileCompSpecified(tileIdx, i) || this.wp.getDecompositionLevel().isTileCompSpecified(tileIdx, i) || this.wp.getGuardBits().isTileCompSpecified(tileIdx, i)) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1855 */         writeTileQCC(tileIdx, i);
/*      */       }
/* 1857 */       else if (tileQCDwritten && (
/* 1858 */         this.wp.getQuantizationType().isCompSpecified(i) || this.wp.getQuantizationStep().isCompSpecified(i) || this.wp.getDecompositionLevel().isCompSpecified(i) || this.wp.getGuardBits().isCompSpecified(i))) {
/*      */ 
/*      */ 
/*      */         
/* 1862 */         writeTileQCC(tileIdx, i);
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1870 */     if (this.roiSc.useRoi() && !this.roiSc.getBlockAligned()) {
/* 1871 */       writeRGN(tileIdx);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1877 */     if (this.wp.getProgressionType().isTileSpecified(tileIdx)) {
/* 1878 */       Progression[] prog = (Progression[])this.wp.getProgressionType().getTileDef(tileIdx);
/* 1879 */       if (prog.length > 1) {
/* 1880 */         writePOC(false, tileIdx);
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1886 */     this.hbuf.writeByte(-1);
/* 1887 */     this.hbuf.writeByte(-109);
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/codestream/writer/HeaderEncoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */