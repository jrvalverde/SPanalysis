/*      */ package jj2000.j2k.codestream.reader;
/*      */ 
/*      */ import java.awt.Point;
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.EOFException;
/*      */ import java.io.IOException;
/*      */ import java.util.Vector;
/*      */ import jj2000.j2k.codestream.CBlkCoordInfo;
/*      */ import jj2000.j2k.codestream.PrecInfo;
/*      */ import jj2000.j2k.decoder.DecoderSpecs;
/*      */ import jj2000.j2k.entropy.StdEntropyCoderOptions;
/*      */ import jj2000.j2k.io.RandomAccessIO;
/*      */ import jj2000.j2k.util.ArrayUtil;
/*      */ import jj2000.j2k.util.MathUtil;
/*      */ import jj2000.j2k.wavelet.synthesis.SubbandSyn;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class PktDecoder
/*      */   implements StdEntropyCoderOptions
/*      */ {
/*      */   private BitstreamReaderAgent src;
/*      */   private boolean pph = false;
/*      */   private ByteArrayInputStream pphbais;
/*      */   private DecoderSpecs decSpec;
/*      */   private HeaderDecoder hd;
/*  120 */   private final int INIT_LBLOCK = 3;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private PktHeaderBitReader bin;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private RandomAccessIO ehs;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Point[][] numPrec;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int tIdx;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private PrecInfo[][][] ppinfo;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int[][][][][] lblock;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private TagTreeDecoder[][][][] ttIncl;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private TagTreeDecoder[][][][] ttMaxBP;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  189 */   private int nl = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int nc;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean sopUsed = false;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean ephUsed = false;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int pktIdx;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Vector[] cblks;
/*      */ 
/*      */ 
/*      */   
/*      */   private int ncb;
/*      */ 
/*      */ 
/*      */   
/*      */   private int maxCB;
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean ncbQuit;
/*      */ 
/*      */ 
/*      */   
/*      */   private int tQuit;
/*      */ 
/*      */ 
/*      */   
/*      */   private int cQuit;
/*      */ 
/*      */ 
/*      */   
/*      */   private int sQuit;
/*      */ 
/*      */ 
/*      */   
/*      */   private int rQuit;
/*      */ 
/*      */ 
/*      */   
/*      */   private int xQuit;
/*      */ 
/*      */ 
/*      */   
/*      */   private int yQuit;
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isTruncMode;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PktDecoder(DecoderSpecs decSpec, HeaderDecoder hd, RandomAccessIO ehs, BitstreamReaderAgent src, boolean isTruncMode, int maxCB) {
/*  260 */     this.decSpec = decSpec;
/*  261 */     this.hd = hd;
/*  262 */     this.ehs = ehs;
/*  263 */     this.isTruncMode = isTruncMode;
/*  264 */     this.bin = new PktHeaderBitReader(ehs);
/*  265 */     this.src = src;
/*  266 */     this.ncb = 0;
/*  267 */     this.ncbQuit = false;
/*  268 */     this.maxCB = maxCB;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CBlkInfo[][][][][] restart(int nc, int[] mdl, int nl, CBlkInfo[][][][][] cbI, boolean pph, ByteArrayInputStream pphbais) {
/*  290 */     this.nc = nc;
/*  291 */     this.nl = nl;
/*  292 */     this.tIdx = this.src.getTileIdx();
/*  293 */     this.pph = pph;
/*  294 */     this.pphbais = pphbais;
/*      */     
/*  296 */     this.sopUsed = ((Boolean)this.decSpec.sops.getTileDef(this.tIdx)).booleanValue();
/*  297 */     this.pktIdx = 0;
/*  298 */     this.ephUsed = ((Boolean)this.decSpec.ephs.getTileDef(this.tIdx)).booleanValue();
/*      */     
/*  300 */     cbI = new CBlkInfo[nc][][][][];
/*  301 */     this.lblock = new int[nc][][][][];
/*  302 */     this.ttIncl = new TagTreeDecoder[nc][][][];
/*  303 */     this.ttMaxBP = new TagTreeDecoder[nc][][][];
/*  304 */     this.numPrec = new Point[nc][];
/*  305 */     this.ppinfo = new PrecInfo[nc][][];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  317 */     Point nBlk = null;
/*  318 */     int cb0x = this.src.getCbULX();
/*  319 */     int cb0y = this.src.getCbULY();
/*      */     
/*  321 */     for (int c = 0; c < nc; c++) {
/*  322 */       cbI[c] = new CBlkInfo[mdl[c] + 1][][][];
/*  323 */       this.lblock[c] = new int[mdl[c] + 1][][][];
/*  324 */       this.ttIncl[c] = new TagTreeDecoder[mdl[c] + 1][][];
/*  325 */       this.ttMaxBP[c] = new TagTreeDecoder[mdl[c] + 1][][];
/*  326 */       this.numPrec[c] = new Point[mdl[c] + 1];
/*  327 */       this.ppinfo[c] = new PrecInfo[mdl[c] + 1][];
/*      */ 
/*      */       
/*  330 */       int tcx0 = this.src.getResULX(c, mdl[c]);
/*  331 */       int tcy0 = this.src.getResULY(c, mdl[c]);
/*  332 */       int tcx1 = tcx0 + this.src.getTileCompWidth(this.tIdx, c, mdl[c]);
/*  333 */       int tcy1 = tcy0 + this.src.getTileCompHeight(this.tIdx, c, mdl[c]);
/*      */       
/*  335 */       for (int r = 0; r <= mdl[c]; r++) {
/*      */ 
/*      */         
/*  338 */         int trx0 = (int)Math.ceil(tcx0 / (1 << mdl[c] - r));
/*  339 */         int try0 = (int)Math.ceil(tcy0 / (1 << mdl[c] - r));
/*  340 */         int trx1 = (int)Math.ceil(tcx1 / (1 << mdl[c] - r));
/*  341 */         int try1 = (int)Math.ceil(tcy1 / (1 << mdl[c] - r));
/*      */ 
/*      */ 
/*      */         
/*  345 */         double twoppx = getPPX(this.tIdx, c, r);
/*  346 */         double twoppy = getPPY(this.tIdx, c, r);
/*  347 */         this.numPrec[c][r] = new Point();
/*  348 */         if (trx1 > trx0) {
/*  349 */           (this.numPrec[c][r]).x = (int)Math.ceil((trx1 - cb0x) / twoppx) - (int)Math.floor((trx0 - cb0x) / twoppx);
/*      */         } else {
/*      */           
/*  352 */           (this.numPrec[c][r]).x = 0;
/*      */         } 
/*  354 */         if (try1 > try0) {
/*  355 */           (this.numPrec[c][r]).y = (int)Math.ceil((try1 - cb0y) / twoppy) - (int)Math.floor((try0 - cb0y) / twoppy);
/*      */         } else {
/*      */           
/*  358 */           (this.numPrec[c][r]).y = 0;
/*      */         } 
/*      */ 
/*      */         
/*  362 */         int mins = (r == 0) ? 0 : 1;
/*  363 */         int maxs = (r == 0) ? 1 : 4;
/*      */         
/*  365 */         int maxPrec = (this.numPrec[c][r]).x * (this.numPrec[c][r]).y;
/*      */         
/*  367 */         this.ttIncl[c][r] = new TagTreeDecoder[maxPrec][maxs + 1];
/*  368 */         this.ttMaxBP[c][r] = new TagTreeDecoder[maxPrec][maxs + 1];
/*  369 */         cbI[c][r] = new CBlkInfo[maxs + 1][][];
/*  370 */         this.lblock[c][r] = new int[maxs + 1][][];
/*      */         
/*  372 */         this.ppinfo[c][r] = new PrecInfo[maxPrec];
/*  373 */         fillPrecInfo(c, r, mdl[c]);
/*      */         
/*  375 */         SubbandSyn root = this.src.getSynSubbandTree(this.tIdx, c);
/*  376 */         for (int s = mins; s < maxs; s++) {
/*  377 */           SubbandSyn sb = (SubbandSyn)root.getSubbandByIdx(r, s);
/*  378 */           nBlk = sb.numCb;
/*      */           
/*  380 */           cbI[c][r][s] = new CBlkInfo[nBlk.y][nBlk.x];
/*  381 */           this.lblock[c][r][s] = new int[nBlk.y][nBlk.x];
/*      */           
/*  383 */           for (int i = nBlk.y - 1; i >= 0; i--) {
/*  384 */             ArrayUtil.intArraySet(this.lblock[c][r][s][i], 3);
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  390 */     return cbI;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void fillPrecInfo(int c, int r, int mdl) {
/*  404 */     if ((this.ppinfo[c][r]).length == 0) {
/*      */       return;
/*      */     }
/*  407 */     Point tileI = this.src.getTile(null);
/*  408 */     Point nTiles = this.src.getNumTiles(null);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  414 */     int xt0siz = this.src.getTilePartULX();
/*  415 */     int yt0siz = this.src.getTilePartULY();
/*  416 */     int xtsiz = this.src.getNomTileWidth();
/*  417 */     int ytsiz = this.src.getNomTileHeight();
/*  418 */     int x0siz = this.hd.getImgULX();
/*  419 */     int y0siz = this.hd.getImgULY();
/*  420 */     int xsiz = this.hd.getImgWidth();
/*  421 */     int ysiz = this.hd.getImgHeight();
/*      */     
/*  423 */     int tx0 = (tileI.x == 0) ? x0siz : (xt0siz + tileI.x * xtsiz);
/*  424 */     int ty0 = (tileI.y == 0) ? y0siz : (yt0siz + tileI.y * ytsiz);
/*  425 */     int tx1 = (tileI.x != nTiles.x - 1) ? (xt0siz + (tileI.x + 1) * xtsiz) : xsiz;
/*  426 */     int ty1 = (tileI.y != nTiles.y - 1) ? (yt0siz + (tileI.y + 1) * ytsiz) : ysiz;
/*      */     
/*  428 */     int xrsiz = this.hd.getCompSubsX(c);
/*  429 */     int yrsiz = this.hd.getCompSubsY(c);
/*      */     
/*  431 */     int tcx0 = this.src.getResULX(c, mdl);
/*  432 */     int tcy0 = this.src.getResULY(c, mdl);
/*  433 */     int tcx1 = tcx0 + this.src.getTileCompWidth(this.tIdx, c, mdl);
/*  434 */     int tcy1 = tcy0 + this.src.getTileCompHeight(this.tIdx, c, mdl);
/*      */     
/*  436 */     int ndl = mdl - r;
/*  437 */     int trx0 = (int)Math.ceil(tcx0 / (1 << ndl));
/*  438 */     int try0 = (int)Math.ceil(tcy0 / (1 << ndl));
/*  439 */     int trx1 = (int)Math.ceil(tcx1 / (1 << ndl));
/*  440 */     int try1 = (int)Math.ceil(tcy1 / (1 << ndl));
/*      */     
/*  442 */     int cb0x = this.src.getCbULX();
/*  443 */     int cb0y = this.src.getCbULY();
/*      */     
/*  445 */     double twoppx = getPPX(this.tIdx, c, r);
/*  446 */     double twoppy = getPPY(this.tIdx, c, r);
/*  447 */     int twoppx2 = (int)(twoppx / 2.0D);
/*  448 */     int twoppy2 = (int)(twoppy / 2.0D);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  453 */     int maxPrec = (this.ppinfo[c][r]).length;
/*  454 */     int nPrec = 0;
/*      */     
/*  456 */     int istart = (int)Math.floor((try0 - cb0y) / twoppy);
/*  457 */     int iend = (int)Math.floor((try1 - 1 - cb0y) / twoppy);
/*  458 */     int jstart = (int)Math.floor((trx0 - cb0x) / twoppx);
/*  459 */     int jend = (int)Math.floor((trx1 - 1 - cb0x) / twoppx);
/*      */ 
/*      */ 
/*      */     
/*  463 */     SubbandSyn root = this.src.getSynSubbandTree(this.tIdx, c);
/*  464 */     SubbandSyn sb = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  471 */     int prg_w = (int)twoppx << ndl;
/*  472 */     int prg_h = (int)twoppy << ndl;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  477 */     for (int i = istart; i <= iend; i++) {
/*  478 */       for (int j = jstart; j <= jend; j++, nPrec++) {
/*  479 */         int prg_ulx, prg_uly; if (j == jstart && (trx0 - cb0x) % xrsiz * (int)twoppx != 0) {
/*  480 */           prg_ulx = tx0;
/*      */         } else {
/*  482 */           prg_ulx = cb0x + j * xrsiz * ((int)twoppx << ndl);
/*      */         } 
/*  484 */         if (i == istart && (try0 - cb0y) % yrsiz * (int)twoppy != 0) {
/*  485 */           prg_uly = ty0;
/*      */         } else {
/*  487 */           prg_uly = cb0y + i * yrsiz * ((int)twoppy << ndl);
/*      */         } 
/*      */         
/*  490 */         this.ppinfo[c][r][nPrec] = new PrecInfo(r, (int)(cb0x + j * twoppx), (int)(cb0y + i * twoppy), (int)twoppx, (int)twoppy, prg_ulx, prg_uly, prg_w, prg_h);
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  495 */         if (r == 0) {
/*  496 */           int acb0x = cb0x;
/*  497 */           int acb0y = cb0y;
/*      */           
/*  499 */           int p0x = acb0x + j * (int)twoppx;
/*  500 */           int p1x = p0x + (int)twoppx;
/*  501 */           int p0y = acb0y + i * (int)twoppy;
/*  502 */           int p1y = p0y + (int)twoppy;
/*      */           
/*  504 */           sb = (SubbandSyn)root.getSubbandByIdx(0, 0);
/*  505 */           int s0x = (p0x < sb.ulcx) ? sb.ulcx : p0x;
/*  506 */           int s1x = (p1x > sb.ulcx + sb.w) ? (sb.ulcx + sb.w) : p1x;
/*  507 */           int s0y = (p0y < sb.ulcy) ? sb.ulcy : p0y;
/*  508 */           int s1y = (p1y > sb.ulcy + sb.h) ? (sb.ulcy + sb.h) : p1y;
/*      */ 
/*      */           
/*  511 */           int cw = sb.nomCBlkW;
/*  512 */           int ch = sb.nomCBlkH;
/*  513 */           int k0 = (int)Math.floor((sb.ulcy - acb0y) / ch);
/*  514 */           int kstart = (int)Math.floor((s0y - acb0y) / ch);
/*  515 */           int kend = (int)Math.floor((s1y - 1 - acb0y) / ch);
/*  516 */           int l0 = (int)Math.floor((sb.ulcx - acb0x) / cw);
/*  517 */           int lstart = (int)Math.floor((s0x - acb0x) / cw);
/*  518 */           int lend = (int)Math.floor((s1x - 1 - acb0x) / cw);
/*      */           
/*  520 */           if (s1x - s0x <= 0 || s1y - s0y <= 0) {
/*  521 */             (this.ppinfo[c][r][nPrec]).nblk[0] = 0;
/*  522 */             this.ttIncl[c][r][nPrec][0] = new TagTreeDecoder(0, 0);
/*  523 */             this.ttMaxBP[c][r][nPrec][0] = new TagTreeDecoder(0, 0);
/*      */           } else {
/*  525 */             this.ttIncl[c][r][nPrec][0] = new TagTreeDecoder(kend - kstart + 1, lend - lstart + 1);
/*      */             
/*  527 */             this.ttMaxBP[c][r][nPrec][0] = new TagTreeDecoder(kend - kstart + 1, lend - lstart + 1);
/*      */             
/*  529 */             (this.ppinfo[c][r][nPrec]).cblk[0] = new CBlkCoordInfo[kend - kstart + 1][lend - lstart + 1];
/*      */             
/*  531 */             (this.ppinfo[c][r][nPrec]).nblk[0] = (kend - kstart + 1) * (lend - lstart + 1);
/*      */ 
/*      */             
/*  534 */             for (int k = kstart; k <= kend; k++) {
/*  535 */               for (int l = lstart; l <= lend; l++) {
/*  536 */                 CBlkCoordInfo cb = new CBlkCoordInfo(k - k0, l - l0);
/*  537 */                 if (l == l0) {
/*  538 */                   cb.ulx = sb.ulx;
/*      */                 } else {
/*  540 */                   cb.ulx = sb.ulx + l * cw - sb.ulcx - acb0x;
/*      */                 } 
/*  542 */                 if (k == k0) {
/*  543 */                   cb.uly = sb.uly;
/*      */                 } else {
/*  545 */                   cb.uly = sb.uly + k * ch - sb.ulcy - acb0y;
/*      */                 } 
/*  547 */                 int tmp1 = acb0x + l * cw;
/*  548 */                 tmp1 = (tmp1 > sb.ulcx) ? tmp1 : sb.ulcx;
/*  549 */                 int tmp2 = acb0x + (l + 1) * cw;
/*  550 */                 tmp2 = (tmp2 > sb.ulcx + sb.w) ? (sb.ulcx + sb.w) : tmp2;
/*      */                 
/*  552 */                 cb.w = tmp2 - tmp1;
/*  553 */                 tmp1 = acb0y + k * ch;
/*  554 */                 tmp1 = (tmp1 > sb.ulcy) ? tmp1 : sb.ulcy;
/*  555 */                 tmp2 = acb0y + (k + 1) * ch;
/*  556 */                 tmp2 = (tmp2 > sb.ulcy + sb.h) ? (sb.ulcy + sb.h) : tmp2;
/*      */                 
/*  558 */                 cb.h = tmp2 - tmp1;
/*  559 */                 (this.ppinfo[c][r][nPrec]).cblk[0][k - kstart][l - lstart] = cb;
/*      */               }
/*      */             
/*      */             } 
/*      */           } 
/*      */         } else {
/*      */           
/*  566 */           int acb0x = 0;
/*  567 */           int acb0y = cb0y;
/*      */           
/*  569 */           int p0x = acb0x + j * twoppx2;
/*  570 */           int p1x = p0x + twoppx2;
/*  571 */           int p0y = acb0y + i * twoppy2;
/*  572 */           int p1y = p0y + twoppy2;
/*      */           
/*  574 */           sb = (SubbandSyn)root.getSubbandByIdx(r, 1);
/*  575 */           int s0x = (p0x < sb.ulcx) ? sb.ulcx : p0x;
/*  576 */           int s1x = (p1x > sb.ulcx + sb.w) ? (sb.ulcx + sb.w) : p1x;
/*  577 */           int s0y = (p0y < sb.ulcy) ? sb.ulcy : p0y;
/*  578 */           int s1y = (p1y > sb.ulcy + sb.h) ? (sb.ulcy + sb.h) : p1y;
/*      */ 
/*      */           
/*  581 */           int cw = sb.nomCBlkW;
/*  582 */           int ch = sb.nomCBlkH;
/*  583 */           int k0 = (int)Math.floor((sb.ulcy - acb0y) / ch);
/*  584 */           int kstart = (int)Math.floor((s0y - acb0y) / ch);
/*  585 */           int kend = (int)Math.floor((s1y - 1 - acb0y) / ch);
/*  586 */           int l0 = (int)Math.floor((sb.ulcx - acb0x) / cw);
/*  587 */           int lstart = (int)Math.floor((s0x - acb0x) / cw);
/*  588 */           int lend = (int)Math.floor((s1x - 1 - acb0x) / cw);
/*      */           
/*  590 */           if (s1x - s0x <= 0 || s1y - s0y <= 0) {
/*  591 */             (this.ppinfo[c][r][nPrec]).nblk[1] = 0;
/*  592 */             this.ttIncl[c][r][nPrec][1] = new TagTreeDecoder(0, 0);
/*  593 */             this.ttMaxBP[c][r][nPrec][1] = new TagTreeDecoder(0, 0);
/*      */           } else {
/*  595 */             this.ttIncl[c][r][nPrec][1] = new TagTreeDecoder(kend - kstart + 1, lend - lstart + 1);
/*      */             
/*  597 */             this.ttMaxBP[c][r][nPrec][1] = new TagTreeDecoder(kend - kstart + 1, lend - lstart + 1);
/*      */             
/*  599 */             (this.ppinfo[c][r][nPrec]).cblk[1] = new CBlkCoordInfo[kend - kstart + 1][lend - lstart + 1];
/*      */             
/*  601 */             (this.ppinfo[c][r][nPrec]).nblk[1] = (kend - kstart + 1) * (lend - lstart + 1);
/*      */ 
/*      */             
/*  604 */             for (int k = kstart; k <= kend; k++) {
/*  605 */               for (int l = lstart; l <= lend; l++) {
/*  606 */                 CBlkCoordInfo cb = new CBlkCoordInfo(k - k0, l - l0);
/*  607 */                 if (l == l0) {
/*  608 */                   cb.ulx = sb.ulx;
/*      */                 } else {
/*  610 */                   cb.ulx = sb.ulx + l * cw - sb.ulcx - acb0x;
/*      */                 } 
/*  612 */                 if (k == k0) {
/*  613 */                   cb.uly = sb.uly;
/*      */                 } else {
/*  615 */                   cb.uly = sb.uly + k * ch - sb.ulcy - acb0y;
/*      */                 } 
/*  617 */                 int tmp1 = acb0x + l * cw;
/*  618 */                 tmp1 = (tmp1 > sb.ulcx) ? tmp1 : sb.ulcx;
/*  619 */                 int tmp2 = acb0x + (l + 1) * cw;
/*  620 */                 tmp2 = (tmp2 > sb.ulcx + sb.w) ? (sb.ulcx + sb.w) : tmp2;
/*      */                 
/*  622 */                 cb.w = tmp2 - tmp1;
/*  623 */                 tmp1 = acb0y + k * ch;
/*  624 */                 tmp1 = (tmp1 > sb.ulcy) ? tmp1 : sb.ulcy;
/*  625 */                 tmp2 = acb0y + (k + 1) * ch;
/*  626 */                 tmp2 = (tmp2 > sb.ulcy + sb.h) ? (sb.ulcy + sb.h) : tmp2;
/*      */                 
/*  628 */                 cb.h = tmp2 - tmp1;
/*  629 */                 (this.ppinfo[c][r][nPrec]).cblk[1][k - kstart][l - lstart] = cb;
/*      */               } 
/*      */             } 
/*      */           } 
/*      */ 
/*      */ 
/*      */           
/*  636 */           acb0x = cb0x;
/*  637 */           acb0y = 0;
/*      */           
/*  639 */           p0x = acb0x + j * twoppx2;
/*  640 */           p1x = p0x + twoppx2;
/*  641 */           p0y = acb0y + i * twoppy2;
/*  642 */           p1y = p0y + twoppy2;
/*      */           
/*  644 */           sb = (SubbandSyn)root.getSubbandByIdx(r, 2);
/*  645 */           s0x = (p0x < sb.ulcx) ? sb.ulcx : p0x;
/*  646 */           s1x = (p1x > sb.ulcx + sb.w) ? (sb.ulcx + sb.w) : p1x;
/*  647 */           s0y = (p0y < sb.ulcy) ? sb.ulcy : p0y;
/*  648 */           s1y = (p1y > sb.ulcy + sb.h) ? (sb.ulcy + sb.h) : p1y;
/*      */ 
/*      */           
/*  651 */           cw = sb.nomCBlkW;
/*  652 */           ch = sb.nomCBlkH;
/*  653 */           k0 = (int)Math.floor((sb.ulcy - acb0y) / ch);
/*  654 */           kstart = (int)Math.floor((s0y - acb0y) / ch);
/*  655 */           kend = (int)Math.floor((s1y - 1 - acb0y) / ch);
/*  656 */           l0 = (int)Math.floor((sb.ulcx - acb0x) / cw);
/*  657 */           lstart = (int)Math.floor((s0x - acb0x) / cw);
/*  658 */           lend = (int)Math.floor((s1x - 1 - acb0x) / cw);
/*      */           
/*  660 */           if (s1x - s0x <= 0 || s1y - s0y <= 0) {
/*  661 */             (this.ppinfo[c][r][nPrec]).nblk[2] = 0;
/*  662 */             this.ttIncl[c][r][nPrec][2] = new TagTreeDecoder(0, 0);
/*  663 */             this.ttMaxBP[c][r][nPrec][2] = new TagTreeDecoder(0, 0);
/*      */           } else {
/*  665 */             this.ttIncl[c][r][nPrec][2] = new TagTreeDecoder(kend - kstart + 1, lend - lstart + 1);
/*      */             
/*  667 */             this.ttMaxBP[c][r][nPrec][2] = new TagTreeDecoder(kend - kstart + 1, lend - lstart + 1);
/*      */             
/*  669 */             (this.ppinfo[c][r][nPrec]).cblk[2] = new CBlkCoordInfo[kend - kstart + 1][lend - lstart + 1];
/*      */             
/*  671 */             (this.ppinfo[c][r][nPrec]).nblk[2] = (kend - kstart + 1) * (lend - lstart + 1);
/*      */ 
/*      */             
/*  674 */             for (int k = kstart; k <= kend; k++) {
/*  675 */               for (int l = lstart; l <= lend; l++) {
/*  676 */                 CBlkCoordInfo cb = new CBlkCoordInfo(k - k0, l - l0);
/*  677 */                 if (l == l0) {
/*  678 */                   cb.ulx = sb.ulx;
/*      */                 } else {
/*  680 */                   cb.ulx = sb.ulx + l * cw - sb.ulcx - acb0x;
/*      */                 } 
/*  682 */                 if (k == k0) {
/*  683 */                   cb.uly = sb.uly;
/*      */                 } else {
/*  685 */                   cb.uly = sb.uly + k * ch - sb.ulcy - acb0y;
/*      */                 } 
/*  687 */                 int tmp1 = acb0x + l * cw;
/*  688 */                 tmp1 = (tmp1 > sb.ulcx) ? tmp1 : sb.ulcx;
/*  689 */                 int tmp2 = acb0x + (l + 1) * cw;
/*  690 */                 tmp2 = (tmp2 > sb.ulcx + sb.w) ? (sb.ulcx + sb.w) : tmp2;
/*      */                 
/*  692 */                 cb.w = tmp2 - tmp1;
/*  693 */                 tmp1 = acb0y + k * ch;
/*  694 */                 tmp1 = (tmp1 > sb.ulcy) ? tmp1 : sb.ulcy;
/*  695 */                 tmp2 = acb0y + (k + 1) * ch;
/*  696 */                 tmp2 = (tmp2 > sb.ulcy + sb.h) ? (sb.ulcy + sb.h) : tmp2;
/*      */                 
/*  698 */                 cb.h = tmp2 - tmp1;
/*  699 */                 (this.ppinfo[c][r][nPrec]).cblk[2][k - kstart][l - lstart] = cb;
/*      */               } 
/*      */             } 
/*      */           } 
/*      */ 
/*      */ 
/*      */           
/*  706 */           acb0x = 0;
/*  707 */           acb0y = 0;
/*      */           
/*  709 */           p0x = acb0x + j * twoppx2;
/*  710 */           p1x = p0x + twoppx2;
/*  711 */           p0y = acb0y + i * twoppy2;
/*  712 */           p1y = p0y + twoppy2;
/*      */           
/*  714 */           sb = (SubbandSyn)root.getSubbandByIdx(r, 3);
/*  715 */           s0x = (p0x < sb.ulcx) ? sb.ulcx : p0x;
/*  716 */           s1x = (p1x > sb.ulcx + sb.w) ? (sb.ulcx + sb.w) : p1x;
/*  717 */           s0y = (p0y < sb.ulcy) ? sb.ulcy : p0y;
/*  718 */           s1y = (p1y > sb.ulcy + sb.h) ? (sb.ulcy + sb.h) : p1y;
/*      */ 
/*      */           
/*  721 */           cw = sb.nomCBlkW;
/*  722 */           ch = sb.nomCBlkH;
/*  723 */           k0 = (int)Math.floor((sb.ulcy - acb0y) / ch);
/*  724 */           kstart = (int)Math.floor((s0y - acb0y) / ch);
/*  725 */           kend = (int)Math.floor((s1y - 1 - acb0y) / ch);
/*  726 */           l0 = (int)Math.floor((sb.ulcx - acb0x) / cw);
/*  727 */           lstart = (int)Math.floor((s0x - acb0x) / cw);
/*  728 */           lend = (int)Math.floor((s1x - 1 - acb0x) / cw);
/*      */           
/*  730 */           if (s1x - s0x <= 0 || s1y - s0y <= 0) {
/*  731 */             (this.ppinfo[c][r][nPrec]).nblk[3] = 0;
/*  732 */             this.ttIncl[c][r][nPrec][3] = new TagTreeDecoder(0, 0);
/*  733 */             this.ttMaxBP[c][r][nPrec][3] = new TagTreeDecoder(0, 0);
/*      */           } else {
/*  735 */             this.ttIncl[c][r][nPrec][3] = new TagTreeDecoder(kend - kstart + 1, lend - lstart + 1);
/*      */             
/*  737 */             this.ttMaxBP[c][r][nPrec][3] = new TagTreeDecoder(kend - kstart + 1, lend - lstart + 1);
/*      */             
/*  739 */             (this.ppinfo[c][r][nPrec]).cblk[3] = new CBlkCoordInfo[kend - kstart + 1][lend - lstart + 1];
/*      */             
/*  741 */             (this.ppinfo[c][r][nPrec]).nblk[3] = (kend - kstart + 1) * (lend - lstart + 1);
/*      */ 
/*      */             
/*  744 */             for (int k = kstart; k <= kend; k++) {
/*  745 */               for (int l = lstart; l <= lend; l++) {
/*  746 */                 CBlkCoordInfo cb = new CBlkCoordInfo(k - k0, l - l0);
/*  747 */                 if (l == l0) {
/*  748 */                   cb.ulx = sb.ulx;
/*      */                 } else {
/*  750 */                   cb.ulx = sb.ulx + l * cw - sb.ulcx - acb0x;
/*      */                 } 
/*  752 */                 if (k == k0) {
/*  753 */                   cb.uly = sb.uly;
/*      */                 } else {
/*  755 */                   cb.uly = sb.uly + k * ch - sb.ulcy - acb0y;
/*      */                 } 
/*  757 */                 int tmp1 = acb0x + l * cw;
/*  758 */                 tmp1 = (tmp1 > sb.ulcx) ? tmp1 : sb.ulcx;
/*  759 */                 int tmp2 = acb0x + (l + 1) * cw;
/*  760 */                 tmp2 = (tmp2 > sb.ulcx + sb.w) ? (sb.ulcx + sb.w) : tmp2;
/*      */                 
/*  762 */                 cb.w = tmp2 - tmp1;
/*  763 */                 tmp1 = acb0y + k * ch;
/*  764 */                 tmp1 = (tmp1 > sb.ulcy) ? tmp1 : sb.ulcy;
/*  765 */                 tmp2 = acb0y + (k + 1) * ch;
/*  766 */                 tmp2 = (tmp2 > sb.ulcy + sb.h) ? (sb.ulcy + sb.h) : tmp2;
/*      */                 
/*  768 */                 cb.h = tmp2 - tmp1;
/*  769 */                 (this.ppinfo[c][r][nPrec]).cblk[3][k - kstart][l - lstart] = cb;
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getNumPrecinct(int c, int r) {
/*  788 */     return (this.numPrec[c][r]).x * (this.numPrec[c][r]).y;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean readPktHead(int l, int r, int c, int p, CBlkInfo[][][] cbI, int[] nb) throws IOException {
/*      */     PktHeaderBitReader bin;
/*  821 */     int sumtotnewtp = 0;
/*      */     
/*  823 */     int startPktHead = this.ehs.getPos();
/*  824 */     if (startPktHead >= this.ehs.length())
/*      */     {
/*  826 */       return true;
/*      */     }
/*  828 */     int tIdx = this.src.getTileIdx();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  833 */     SubbandSyn root = this.src.getSynSubbandTree(tIdx, c);
/*      */ 
/*      */ 
/*      */     
/*  837 */     if (this.pph) {
/*  838 */       bin = new PktHeaderBitReader(this.pphbais);
/*      */     } else {
/*  840 */       bin = this.bin;
/*      */     } 
/*      */     
/*  843 */     int mins = (r == 0) ? 0 : 1;
/*  844 */     int maxs = (r == 0) ? 1 : 4;
/*      */     
/*  846 */     boolean precFound = false;
/*  847 */     for (int s = mins; s < maxs; s++) {
/*  848 */       if (p < (this.ppinfo[c][r]).length) {
/*  849 */         precFound = true;
/*      */       }
/*      */     } 
/*  852 */     if (!precFound) {
/*  853 */       return false;
/*      */     }
/*      */     
/*  856 */     PrecInfo prec = this.ppinfo[c][r][p];
/*      */ 
/*      */     
/*  859 */     bin.sync();
/*      */ 
/*      */     
/*  862 */     if (bin.readBit() == 0) {
/*      */       
/*  864 */       this.cblks = new Vector[maxs + 1];
/*  865 */       for (int j = mins; j < maxs; j++) {
/*  866 */         this.cblks[j] = new Vector();
/*      */       }
/*  868 */       this.pktIdx++;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  873 */       if (this.isTruncMode && this.maxCB == -1) {
/*  874 */         int tmp = this.ehs.getPos() - startPktHead;
/*  875 */         if (tmp > nb[tIdx]) {
/*  876 */           nb[tIdx] = 0;
/*  877 */           return true;
/*      */         } 
/*  879 */         nb[tIdx] = nb[tIdx] - tmp;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  884 */       if (this.ephUsed) {
/*  885 */         readEPHMarker(bin);
/*      */       }
/*  887 */       return false;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  892 */     if (this.cblks == null || this.cblks.length < maxs + 1) {
/*  893 */       this.cblks = new Vector[maxs + 1];
/*      */     }
/*      */     
/*  896 */     for (int i = mins; i < maxs; i++) {
/*  897 */       if (this.cblks[i] == null) {
/*  898 */         this.cblks[i] = new Vector();
/*      */       } else {
/*  900 */         this.cblks[i].removeAllElements();
/*      */       } 
/*  902 */       SubbandSyn sb = (SubbandSyn)root.getSubbandByIdx(r, i);
/*      */       
/*  904 */       if (prec.nblk[i] != 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  909 */         TagTreeDecoder tdIncl = this.ttIncl[c][r][p][i];
/*  910 */         TagTreeDecoder tdBD = this.ttMaxBP[c][r][p][i];
/*      */         
/*  912 */         int mend = (prec.cblk[i] == null) ? 0 : (prec.cblk[i]).length;
/*  913 */         for (int m = 0; m < mend; m++) {
/*  914 */           int nend = (prec.cblk[i][m] == null) ? 0 : (prec.cblk[i][m]).length;
/*  915 */           for (int n = 0; n < nend; n++) {
/*  916 */             Point cbc = (prec.cblk[i][m][n]).idx;
/*  917 */             int b = cbc.x + cbc.y * sb.numCb.x;
/*      */             
/*  919 */             CBlkInfo ccb = cbI[i][cbc.y][cbc.x];
/*      */             
/*      */             try {
/*      */               int nSeg, cbLen, totnewtp;
/*  923 */               if (ccb == null || ccb.ctp == 0) {
/*  924 */                 if (ccb == null) {
/*  925 */                   ccb = cbI[i][cbc.y][cbc.x] = new CBlkInfo((prec.cblk[i][m][n]).ulx, (prec.cblk[i][m][n]).uly, (prec.cblk[i][m][n]).w, (prec.cblk[i][m][n]).h, this.nl);
/*      */                 }
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*  931 */                 ccb.pktIdx[l] = this.pktIdx;
/*      */ 
/*      */                 
/*  934 */                 int tmp = tdIncl.update(m, n, l + 1, bin);
/*  935 */                 if (tmp > l) {
/*      */                   continue;
/*      */                 }
/*      */ 
/*      */                 
/*  940 */                 tmp = 1; int tmp2;
/*  941 */                 for (tmp2 = 1; tmp >= tmp2; tmp2++) {
/*  942 */                   tmp = tdBD.update(m, n, tmp2, bin);
/*      */                 }
/*  944 */                 ccb.msbSkipped = tmp2 - 2;
/*      */ 
/*      */                 
/*  947 */                 totnewtp = 1;
/*  948 */                 ccb.addNTP(l, 0);
/*      */ 
/*      */                 
/*  951 */                 this.ncb++;
/*  952 */                 if (this.maxCB != -1 && !this.ncbQuit && this.ncb == this.maxCB)
/*      */                 {
/*  954 */                   this.ncbQuit = true;
/*  955 */                   this.tQuit = tIdx;
/*  956 */                   this.cQuit = c;
/*  957 */                   this.sQuit = i;
/*  958 */                   this.rQuit = r;
/*  959 */                   this.xQuit = cbc.x;
/*  960 */                   this.yQuit = cbc.y;
/*      */                 }
/*      */               
/*      */               }
/*      */               else {
/*      */                 
/*  966 */                 ccb.pktIdx[l] = this.pktIdx;
/*      */ 
/*      */                 
/*  969 */                 if (bin.readBit() != 1) {
/*      */                   continue;
/*      */                 }
/*      */ 
/*      */ 
/*      */                 
/*  975 */                 totnewtp = 1;
/*      */               } 
/*      */ 
/*      */               
/*  979 */               if (bin.readBit() == 1) {
/*  980 */                 totnewtp++;
/*      */ 
/*      */                 
/*  983 */                 if (bin.readBit() == 1) {
/*  984 */                   totnewtp++;
/*      */                   
/*  986 */                   int tmp = bin.readBits(2);
/*  987 */                   totnewtp += tmp;
/*      */                   
/*  989 */                   if (tmp == 3) {
/*  990 */                     tmp = bin.readBits(5);
/*  991 */                     totnewtp += tmp;
/*      */ 
/*      */                     
/*  994 */                     if (tmp == 31) {
/*  995 */                       totnewtp += bin.readBits(7);
/*      */                     }
/*      */                   } 
/*      */                 } 
/*      */               } 
/* 1000 */               ccb.addNTP(l, totnewtp);
/* 1001 */               sumtotnewtp += totnewtp;
/* 1002 */               this.cblks[i].addElement(prec.cblk[i][m][n]);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 1020 */               int options = ((Integer)this.decSpec.ecopts.getTileCompVal(tIdx, c)).intValue();
/*      */ 
/*      */ 
/*      */               
/* 1024 */               if ((options & 0x4) != 0) {
/*      */ 
/*      */                 
/* 1027 */                 nSeg = totnewtp;
/* 1028 */               } else if ((options & 0x1) != 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/* 1036 */                 if (ccb.ctp <= 10) {
/* 1037 */                   nSeg = 1;
/*      */                 } else {
/* 1039 */                   nSeg = 1;
/*      */                   
/* 1041 */                   int tpidx = ccb.ctp - totnewtp;
/* 1042 */                   for (; tpidx < ccb.ctp - 1; tpidx++) {
/* 1043 */                     if (tpidx >= 9) {
/* 1044 */                       int passtype = (tpidx + 2) % 3;
/*      */ 
/*      */                       
/* 1047 */                       if (passtype == 1 || passtype == 2)
/*      */                       {
/*      */ 
/*      */                         
/* 1051 */                         nSeg++;
/*      */                       }
/*      */                     } 
/*      */                   } 
/*      */                 } 
/*      */               } else {
/*      */                 
/* 1058 */                 nSeg = 1;
/*      */               } 
/*      */ 
/*      */               
/* 1062 */               while (bin.readBit() != 0) {
/* 1063 */                 this.lblock[c][r][i][cbc.y][cbc.x] = this.lblock[c][r][i][cbc.y][cbc.x] + 1;
/*      */               }
/*      */               
/* 1066 */               if (nSeg == 1) {
/* 1067 */                 cbLen = bin.readBits(this.lblock[c][r][i][cbc.y][cbc.x] + MathUtil.log2(totnewtp));
/*      */               }
/*      */               else {
/*      */                 
/* 1071 */                 ccb.segLen[l] = new int[nSeg];
/* 1072 */                 cbLen = 0;
/*      */                 
/* 1074 */                 if ((options & 0x4) != 0) {
/*      */                   
/* 1076 */                   int tpidx = ccb.ctp - totnewtp, j = 0;
/* 1077 */                   for (; tpidx < ccb.ctp; tpidx++, j++)
/*      */                   {
/* 1079 */                     int lblockCur = this.lblock[c][r][i][cbc.y][cbc.x];
/*      */                     
/* 1081 */                     int tmp = bin.readBits(lblockCur);
/* 1082 */                     ccb.segLen[l][j] = tmp;
/* 1083 */                     cbLen += tmp;
/*      */                   }
/*      */                 
/*      */                 } else {
/*      */                   
/* 1088 */                   int ltp = ccb.ctp - totnewtp - 1;
/* 1089 */                   int tpidx = ccb.ctp - totnewtp, j = 0;
/* 1090 */                   for (; tpidx < ccb.ctp - 1; tpidx++) {
/* 1091 */                     if (tpidx >= 9) {
/* 1092 */                       int passtype = (tpidx + 2) % 3;
/*      */ 
/*      */                       
/* 1095 */                       if (passtype != 0) {
/*      */                         
/* 1097 */                         int i1 = this.lblock[c][r][i][cbc.y][cbc.x];
/*      */                         
/* 1099 */                         int k = bin.readBits(i1 + MathUtil.log2(tpidx - ltp));
/*      */ 
/*      */ 
/*      */                         
/* 1103 */                         ccb.segLen[l][j] = k;
/* 1104 */                         cbLen += k;
/* 1105 */                         ltp = tpidx;
/* 1106 */                         j++;
/*      */                       } 
/*      */                     } 
/*      */                   } 
/* 1110 */                   int lblockCur = this.lblock[c][r][i][cbc.y][cbc.x];
/* 1111 */                   int tmp = bin.readBits(lblockCur + MathUtil.log2(tpidx - ltp));
/*      */                   
/* 1113 */                   cbLen += tmp;
/* 1114 */                   ccb.segLen[l][j] = tmp;
/*      */                 } 
/*      */               } 
/* 1117 */               ccb.len[l] = cbLen;
/*      */ 
/*      */ 
/*      */               
/* 1121 */               if (this.isTruncMode && this.maxCB == -1) {
/* 1122 */                 int tmp = this.ehs.getPos() - startPktHead;
/* 1123 */                 if (tmp > nb[tIdx]) {
/* 1124 */                   nb[tIdx] = 0;
/*      */                   
/* 1126 */                   if (l == 0) {
/* 1127 */                     cbI[i][cbc.y][cbc.x] = null;
/*      */                   } else {
/* 1129 */                     ccb.len[l] = 0; ccb.off[l] = 0;
/* 1130 */                     ccb.ctp -= ccb.ntp[l];
/* 1131 */                     ccb.ntp[l] = 0;
/* 1132 */                     ccb.pktIdx[l] = -1;
/*      */                   } 
/* 1134 */                   return true;
/*      */                 }
/*      */               
/*      */               } 
/* 1138 */             } catch (EOFException e) {
/*      */               
/* 1140 */               if (l == 0) {
/* 1141 */                 cbI[i][cbc.y][cbc.x] = null;
/*      */               } else {
/* 1143 */                 ccb.len[l] = 0; ccb.off[l] = 0;
/* 1144 */                 ccb.ctp -= ccb.ntp[l];
/* 1145 */                 ccb.ntp[l] = 0;
/* 1146 */                 ccb.pktIdx[l] = -1;
/*      */               } 
/*      */               
/* 1149 */               return true;
/*      */             } 
/*      */             continue;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/* 1156 */     if (this.ephUsed) {
/* 1157 */       readEPHMarker(bin);
/*      */     }
/*      */     
/* 1160 */     this.pktIdx++;
/*      */ 
/*      */     
/* 1163 */     if (this.isTruncMode && this.maxCB == -1) {
/* 1164 */       int tmp = this.ehs.getPos() - startPktHead;
/* 1165 */       if (tmp > nb[tIdx]) {
/* 1166 */         nb[tIdx] = 0;
/* 1167 */         return true;
/*      */       } 
/* 1169 */       nb[tIdx] = nb[tIdx] - tmp;
/*      */     } 
/*      */     
/* 1172 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean readPktBody(int l, int r, int c, int p, CBlkInfo[][][] cbI, int[] nb) throws IOException {
/* 1198 */     int curOff = this.ehs.getPos();
/*      */ 
/*      */     
/* 1201 */     boolean stopRead = false;
/* 1202 */     int tIdx = this.src.getTileIdx();
/*      */ 
/*      */     
/* 1205 */     boolean precFound = false;
/* 1206 */     int mins = (r == 0) ? 0 : 1;
/* 1207 */     int maxs = (r == 0) ? 1 : 4; int s;
/* 1208 */     for (s = mins; s < maxs; s++) {
/* 1209 */       if (p < (this.ppinfo[c][r]).length) {
/* 1210 */         precFound = true;
/*      */       }
/*      */     } 
/* 1213 */     if (!precFound) {
/* 1214 */       return false;
/*      */     }
/*      */     
/* 1217 */     for (s = mins; s < maxs; s++) {
/* 1218 */       for (int numCB = 0; numCB < this.cblks[s].size(); numCB++) {
/* 1219 */         Point cbc = ((CBlkCoordInfo)this.cblks[s].elementAt(numCB)).idx;
/* 1220 */         CBlkInfo ccb = cbI[s][cbc.y][cbc.x];
/* 1221 */         ccb.off[l] = curOff;
/* 1222 */         curOff += ccb.len[l];
/*      */         try {
/* 1224 */           this.ehs.seek(curOff);
/* 1225 */         } catch (EOFException e) {
/* 1226 */           if (l == 0) {
/* 1227 */             cbI[s][cbc.y][cbc.x] = null;
/*      */           } else {
/* 1229 */             ccb.len[l] = 0; ccb.off[l] = 0;
/* 1230 */             ccb.ctp -= ccb.ntp[l];
/* 1231 */             ccb.ntp[l] = 0;
/* 1232 */             ccb.pktIdx[l] = -1;
/*      */           } 
/* 1234 */           throw new EOFException();
/*      */         } 
/*      */ 
/*      */         
/* 1238 */         if (this.isTruncMode) {
/* 1239 */           if (stopRead || ccb.len[l] > nb[tIdx]) {
/*      */             
/* 1241 */             if (l == 0) {
/* 1242 */               cbI[s][cbc.y][cbc.x] = null;
/*      */             } else {
/* 1244 */               ccb.len[l] = 0; ccb.off[l] = 0;
/* 1245 */               ccb.ctp -= ccb.ntp[l];
/* 1246 */               ccb.ntp[l] = 0;
/* 1247 */               ccb.pktIdx[l] = -1;
/*      */             } 
/* 1249 */             stopRead = true;
/*      */           } 
/* 1251 */           if (!stopRead) {
/* 1252 */             nb[tIdx] = nb[tIdx] - ccb.len[l];
/*      */           }
/*      */         } 
/*      */         
/* 1256 */         if (this.ncbQuit && r == this.rQuit && s == this.sQuit && cbc.x == this.xQuit && cbc.y == this.yQuit && tIdx == this.tQuit && c == this.cQuit) {
/*      */           
/* 1258 */           cbI[s][cbc.y][cbc.x] = null;
/* 1259 */           stopRead = true;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1265 */     this.ehs.seek(curOff);
/*      */     
/* 1267 */     if (stopRead) {
/* 1268 */       return true;
/*      */     }
/* 1270 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getPPX(int t, int c, int r) {
/* 1288 */     return this.decSpec.pss.getPPX(t, c, r);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getPPY(int t, int c, int rl) {
/* 1305 */     return this.decSpec.pss.getPPY(t, c, rl);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean readSOPMarker(int[] nBytes, int p, int c, int r) throws IOException {
/* 1323 */     byte[] sopArray = new byte[6];
/* 1324 */     int tIdx = this.src.getTileIdx();
/* 1325 */     int mins = (r == 0) ? 0 : 1;
/* 1326 */     int maxs = (r == 0) ? 1 : 4;
/* 1327 */     boolean precFound = false;
/* 1328 */     for (int s = mins; s < maxs; s++) {
/* 1329 */       if (p < (this.ppinfo[c][r]).length) {
/* 1330 */         precFound = true;
/*      */       }
/*      */     } 
/* 1333 */     if (!precFound) {
/* 1334 */       return false;
/*      */     }
/*      */ 
/*      */     
/* 1338 */     if (!this.sopUsed) {
/* 1339 */       return false;
/*      */     }
/*      */ 
/*      */     
/* 1343 */     int pos = this.ehs.getPos();
/* 1344 */     if ((short)(this.ehs.read() << 8 | this.ehs.read()) != -111) {
/* 1345 */       this.ehs.seek(pos);
/* 1346 */       return false;
/*      */     } 
/* 1348 */     this.ehs.seek(pos);
/*      */ 
/*      */ 
/*      */     
/* 1352 */     if (nBytes[tIdx] < 6) {
/* 1353 */       return true;
/*      */     }
/* 1355 */     nBytes[tIdx] = nBytes[tIdx] - 6;
/*      */ 
/*      */     
/* 1358 */     this.ehs.readFully(sopArray, 0, 6);
/*      */ 
/*      */     
/* 1361 */     int val = sopArray[0];
/* 1362 */     val <<= 8;
/* 1363 */     val |= sopArray[1];
/* 1364 */     if (val != -111) {
/* 1365 */       throw new Error("Corrupted Bitstream: Could not parse SOP marker !");
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1370 */     val = sopArray[2] & 0xFF;
/* 1371 */     val <<= 8;
/* 1372 */     val |= sopArray[3] & 0xFF;
/* 1373 */     if (val != 4) {
/* 1374 */       throw new Error("Corrupted Bitstream: Corrupted SOP marker !");
/*      */     }
/*      */ 
/*      */     
/* 1378 */     val = sopArray[4] & 0xFF;
/* 1379 */     val <<= 8;
/* 1380 */     val |= sopArray[5] & 0xFF;
/*      */     
/* 1382 */     if (!this.pph && val != this.pktIdx) {
/* 1383 */       throw new Error("Corrupted Bitstream: SOP marker out of sequence !");
/*      */     }
/*      */     
/* 1386 */     if (this.pph && val != this.pktIdx - 1)
/*      */     {
/*      */       
/* 1389 */       throw new Error("Corrupted Bitstream: SOP marker out of sequence !");
/*      */     }
/*      */     
/* 1392 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void readEPHMarker(PktHeaderBitReader bin) throws IOException {
/* 1403 */     byte[] ephArray = new byte[2];
/*      */     
/* 1405 */     if (bin.usebais) {
/* 1406 */       bin.bais.read(ephArray, 0, 2);
/*      */     } else {
/* 1408 */       bin.in.readFully(ephArray, 0, 2);
/*      */     } 
/*      */ 
/*      */     
/* 1412 */     int val = ephArray[0];
/* 1413 */     val <<= 8;
/* 1414 */     val |= ephArray[1];
/* 1415 */     if (val != -110) {
/* 1416 */       throw new Error("Corrupted Bitstream: Could not parse EPH marker ! ");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PrecInfo getPrecInfo(int c, int r, int p) {
/* 1432 */     return this.ppinfo[c][r][p];
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/codestream/reader/PktDecoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */