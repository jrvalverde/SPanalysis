/*      */ package jj2000.j2k.codestream.reader;
/*      */ 
/*      */ import com.sun.media.imageioimpl.plugins.jpeg2000.J2KImageReadParamJava;
/*      */ import java.awt.Point;
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.EOFException;
/*      */ import java.io.IOException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Vector;
/*      */ import javax.imageio.stream.ImageInputStream;
/*      */ import javax.imageio.stream.MemoryCacheImageInputStream;
/*      */ import jj2000.j2k.JJ2KExceptionHandler;
/*      */ import jj2000.j2k.NoNextElementException;
/*      */ import jj2000.j2k.NotImplementedError;
/*      */ import jj2000.j2k.codestream.CorruptedCodestreamException;
/*      */ import jj2000.j2k.codestream.HeaderInfo;
/*      */ import jj2000.j2k.codestream.Markers;
/*      */ import jj2000.j2k.codestream.PrecInfo;
/*      */ import jj2000.j2k.codestream.ProgressionType;
/*      */ import jj2000.j2k.decoder.DecoderSpecs;
/*      */ import jj2000.j2k.entropy.StdEntropyCoderOptions;
/*      */ import jj2000.j2k.entropy.decoder.DecLyrdCBlk;
/*      */ import jj2000.j2k.io.RandomAccessIO;
/*      */ import jj2000.j2k.quantization.dequantizer.StdDequantizerParams;
/*      */ import jj2000.j2k.util.ArrayUtil;
/*      */ import jj2000.j2k.util.FacilityManager;
/*      */ import jj2000.j2k.util.MathUtil;
/*      */ import jj2000.j2k.wavelet.WaveletFilter;
/*      */ import jj2000.j2k.wavelet.synthesis.SubbandSyn;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class FileBitstreamReaderAgent
/*      */   extends BitstreamReaderAgent
/*      */   implements Markers, ProgressionType, StdEntropyCoderOptions
/*      */ {
/*      */   private boolean isPsotEqualsZero = true;
/*      */   public PktDecoder pktDec;
/*      */   private J2KImageReadParamJava j2krparam;
/*      */   private RandomAccessIO in;
/*      */   private int nt;
/*      */   private int[][] firstPackOff;
/*      */   private int[] nBytes;
/*      */   
/*      */   public int getNumTileParts(int t) {
/*  146 */     if (this.firstPackOff == null || this.firstPackOff[t] == null) {
/*  147 */       throw new Error("Tile " + t + " not found in input codestream.");
/*      */     }
/*  149 */     return (this.firstPackOff[t]).length;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean printInfo = false;
/*      */ 
/*      */ 
/*      */   
/*      */   private int[] baknBytes;
/*      */ 
/*      */ 
/*      */   
/*      */   private int[][] tilePartLen;
/*      */ 
/*      */ 
/*      */   
/*      */   private int[] totTileLen;
/*      */ 
/*      */ 
/*      */   
/*      */   private int[] totTileHeadLen;
/*      */ 
/*      */ 
/*      */   
/*      */   private int firstTilePartHeadLen;
/*      */ 
/*      */ 
/*      */   
/*      */   private double totAllTileLen;
/*      */ 
/*      */ 
/*      */   
/*      */   private int mainHeadLen;
/*      */ 
/*      */ 
/*      */   
/*  187 */   private int headLen = 0;
/*      */ 
/*      */   
/*      */   private int[][] tilePartHeadLen;
/*      */ 
/*      */   
/*      */   private Vector pktHL;
/*      */ 
/*      */   
/*      */   private boolean isTruncMode;
/*      */ 
/*      */   
/*      */   private int remainingTileParts;
/*      */ 
/*      */   
/*      */   private int[] tilePartsRead;
/*      */ 
/*      */   
/*  205 */   private int totTilePartsRead = 0;
/*      */ 
/*      */ 
/*      */   
/*      */   private int[] tileParts;
/*      */ 
/*      */ 
/*      */   
/*      */   private int[] totTileParts;
/*      */ 
/*      */   
/*      */   private int curTilePart;
/*      */ 
/*      */   
/*      */   private int[][] tilePartNum;
/*      */ 
/*      */   
/*      */   private boolean isEOCFound = false;
/*      */ 
/*      */   
/*      */   private HeaderInfo hi;
/*      */ 
/*      */   
/*      */   private CBlkInfo[][][][][] cbI;
/*      */ 
/*      */   
/*      */   private int lQuit;
/*      */ 
/*      */ 
/*      */   
/*      */   public CBlkInfo[][][][][] getCBlkInfo() {
/*  236 */     return this.cbI;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean usePOCQuit = false;
/*      */   
/*      */   long[][] tilePartPositions;
/*      */   
/*      */   int cdstreamStart;
/*      */   
/*      */   int t;
/*      */   
/*      */   int pos;
/*      */   
/*      */   int tp;
/*      */   
/*      */   int tptot;
/*      */   
/*      */   int tilePartStart;
/*      */   
/*      */   boolean rateReached;
/*      */   
/*      */   int numtp;
/*      */   
/*      */   int maxTP;
/*      */   
/*      */   int lastPos;
/*      */   
/*      */   int maxPos;
/*      */   
/*      */   public FileBitstreamReaderAgent(HeaderDecoder hd, RandomAccessIO ehs, DecoderSpecs decSpec, J2KImageReadParamJava j2krparam, boolean cdstrInfo, HeaderInfo hi) throws IOException
/*      */   {
/*  268 */     super(hd, decSpec);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  380 */     this.tilePartPositions = (long[][])null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  519 */     this.cdstreamStart = 0;
/*  520 */     this.t = 0; this.pos = -1; this.tp = 0; this.tptot = 0;
/*  521 */     this.tilePartStart = 0;
/*  522 */     this.rateReached = false;
/*  523 */     this.numtp = 0;
/*  524 */     this.maxTP = this.nt;
/*  525 */     this.lastPos = 0; this.maxPos = 0; this.j2krparam = j2krparam; this.printInfo = cdstrInfo; this.hi = hi; String strInfo = this.printInfo ? "Codestream elements information in bytes (offset, total length, header length):\n\n" : null; if (j2krparam.getDecodingRate() == Double.MAX_VALUE) { this.tnbytes = Integer.MAX_VALUE; }
/*      */     else { this.tnbytes = (int)(j2krparam.getDecodingRate() * hd.getMaxCompImgWidth() * hd.getMaxCompImgHeight()) / 8; }
/*      */      this.isTruncMode = true; int ncbQuit = -1; if (ncbQuit != -1 && !this.isTruncMode)
/*      */       throw new Error("Cannot use -parsing and -ncb_quit condition at the same time.");  this.lQuit = -1; this.nt = this.ntX * this.ntY; this.in = ehs; this.pktDec = new PktDecoder(decSpec, hd, ehs, this, this.isTruncMode, ncbQuit); this.tileParts = new int[this.nt]; this.totTileParts = new int[this.nt]; this.totTileLen = new int[this.nt]; this.tilePartLen = new int[this.nt][]; this.tilePartNum = new int[this.nt][]; this.firstPackOff = new int[this.nt][]; this.tilePartsRead = new int[this.nt]; this.totTileHeadLen = new int[this.nt]; this.tilePartHeadLen = new int[this.nt][]; this.nBytes = new int[this.nt]; this.baknBytes = new int[this.nt]; hd.nTileParts = new int[this.nt]; this.isTruncMode = this.isTruncMode; this.cdstreamStart = hd.mainHeadOff; this.mainHeadLen = this.in.getPos() - this.cdstreamStart; this.headLen = this.mainHeadLen; if (ncbQuit == -1) { this.anbytes = this.mainHeadLen; }
/*      */     else { this.anbytes = 0; }
/*      */      if (this.printInfo)
/*      */       strInfo = strInfo + "Main header length    : " + this.cdstreamStart + ", " + this.mainHeadLen + ", " + this.mainHeadLen + "\n";  if (this.anbytes > this.tnbytes)
/*      */       throw new Error("Requested bitrate is too small.");  this.totAllTileLen = 0.0D; this.remainingTileParts = this.nt; this.maxPos = this.lastPos = this.in.getPos(); if (j2krparam.getResolution() == -1) { this.targetRes = decSpec.dls.getMin(); }
/*      */     else { this.targetRes = j2krparam.getResolution(); if (this.targetRes < 0)
/*      */         throw new IllegalArgumentException("Specified negative resolution level index: " + this.targetRes);  }
/*      */      int mdl = decSpec.dls.getMin(); if (this.targetRes > mdl) { FacilityManager.getMsgLogger().printmsg(2, "Specified resolution level (" + this.targetRes + ") is larger" + " than the maximum possible. Setting it to " + mdl + " (maximum possible)"); this.targetRes = mdl; }
/*  536 */      initTLM(); } private void initTile(int tileNum) throws IOException { if (this.tilePartPositions == null) this.in.seek(this.lastPos); 
/*  537 */     String strInfo = "";
/*  538 */     int ncbQuit = -1;
/*  539 */     boolean isTilePartRead = false;
/*  540 */     boolean isEOFEncountered = false;
/*      */     try {
/*  542 */       int tpNum = 0;
/*  543 */       while (this.remainingTileParts != 0 && (this.totTileParts[tileNum] == 0 || this.tilePartsRead[tileNum] < this.totTileParts[tileNum])) {
/*      */ 
/*      */         
/*  546 */         isTilePartRead = true;
/*      */         
/*  548 */         if (this.tilePartPositions != null) {
/*  549 */           this.in.seek((int)this.tilePartPositions[tileNum][tpNum++]);
/*      */         }
/*  551 */         this.tilePartStart = this.in.getPos();
/*      */ 
/*      */         
/*      */         try {
/*  555 */           this.t = readTilePartHeader();
/*  556 */           if (this.isEOCFound) {
/*      */             break;
/*      */           }
/*      */           
/*  560 */           this.tp = this.tilePartsRead[this.t];
/*  561 */           if (this.isPsotEqualsZero)
/*      */           {
/*      */             
/*  564 */             this.tilePartLen[this.t][this.tp] = this.in.length() - 2 - this.tilePartStart;
/*      */           }
/*  566 */         } catch (EOFException e) {
/*  567 */           this.firstPackOff[this.t][this.tp] = this.in.length();
/*  568 */           throw e;
/*      */         } 
/*      */         
/*  571 */         this.pos = this.in.getPos();
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  576 */         if (this.isTruncMode && ncbQuit == -1 && 
/*  577 */           this.pos - this.cdstreamStart > this.tnbytes) {
/*  578 */           this.firstPackOff[this.t][this.tp] = this.in.length();
/*  579 */           this.rateReached = true;
/*      */ 
/*      */           
/*      */           break;
/*      */         } 
/*      */         
/*  585 */         this.firstPackOff[this.t][this.tp] = this.pos;
/*  586 */         this.tilePartHeadLen[this.t][this.tp] = this.pos - this.tilePartStart;
/*      */         
/*  588 */         if (this.printInfo) {
/*  589 */           strInfo = strInfo + "Tile-part " + this.tp + " of tile " + this.t + " : " + this.tilePartStart + ", " + this.tilePartLen[this.t][this.tp] + ", " + this.tilePartHeadLen[this.t][this.tp] + "\n";
/*      */         }
/*      */ 
/*      */         
/*  593 */         this.totTileLen[this.t] = this.totTileLen[this.t] + this.tilePartLen[this.t][this.tp];
/*  594 */         this.totTileHeadLen[this.t] = this.totTileHeadLen[this.t] + this.tilePartHeadLen[this.t][this.tp];
/*  595 */         this.totAllTileLen += this.tilePartLen[this.t][this.tp];
/*  596 */         if (this.isTruncMode) {
/*  597 */           if (this.anbytes + this.tilePartLen[this.t][this.tp] > this.tnbytes) {
/*  598 */             this.anbytes += this.tilePartHeadLen[this.t][this.tp];
/*  599 */             this.headLen += this.tilePartHeadLen[this.t][this.tp];
/*  600 */             this.rateReached = true;
/*  601 */             this.nBytes[this.t] = this.nBytes[this.t] + this.tnbytes - this.anbytes;
/*      */             break;
/*      */           } 
/*  604 */           this.anbytes += this.tilePartHeadLen[this.t][this.tp];
/*  605 */           this.headLen += this.tilePartHeadLen[this.t][this.tp];
/*  606 */           this.nBytes[this.t] = this.nBytes[this.t] + this.tilePartLen[this.t][this.tp] - this.tilePartHeadLen[this.t][this.tp];
/*      */         }
/*      */         else {
/*      */           
/*  610 */           if (this.anbytes + this.tilePartHeadLen[this.t][this.tp] > this.tnbytes) {
/*      */             break;
/*      */           }
/*  613 */           this.anbytes += this.tilePartHeadLen[this.t][this.tp];
/*  614 */           this.headLen += this.tilePartHeadLen[this.t][this.tp];
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/*  619 */         if (this.tptot == 0) {
/*  620 */           this.firstTilePartHeadLen = this.tilePartHeadLen[this.t][this.tp];
/*      */         }
/*      */         
/*  623 */         this.tilePartsRead[this.t] = this.tilePartsRead[this.t] + 1;
/*  624 */         int nextMarkerPos = this.tilePartStart + this.tilePartLen[this.t][this.tp];
/*  625 */         if (this.tilePartPositions == null) {
/*  626 */           this.in.seek(nextMarkerPos);
/*      */         }
/*  628 */         if (nextMarkerPos > this.maxPos) {
/*  629 */           this.maxPos = nextMarkerPos;
/*      */         }
/*  631 */         this.remainingTileParts--;
/*  632 */         this.maxTP--;
/*  633 */         this.tptot++;
/*      */ 
/*      */         
/*  636 */         if (this.isPsotEqualsZero) {
/*  637 */           if (this.remainingTileParts != 0) {
/*  638 */             FacilityManager.getMsgLogger().printmsg(2, "Some tile-parts have not been found. The codestream may be corrupted.");
/*      */           }
/*      */ 
/*      */           
/*      */           break;
/*      */         } 
/*      */       } 
/*  645 */     } catch (EOFException e) {
/*  646 */       isEOFEncountered = true;
/*      */       
/*  648 */       if (this.printInfo) {
/*  649 */         FacilityManager.getMsgLogger().printmsg(1, strInfo);
/*      */       }
/*      */       
/*  652 */       FacilityManager.getMsgLogger().printmsg(2, "Codestream truncated in tile " + this.t);
/*      */ 
/*      */ 
/*      */       
/*  656 */       int fileLen = this.in.length();
/*  657 */       if (fileLen < this.tnbytes) {
/*  658 */         this.tnbytes = fileLen;
/*  659 */         this.trate = this.tnbytes * 8.0F / this.hd.getMaxCompImgWidth() / this.hd.getMaxCompImgHeight();
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  665 */     if (!isTilePartRead) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  699 */     if (!isEOFEncountered) {
/*  700 */       if (this.printInfo) {
/*  701 */         FacilityManager.getMsgLogger().printmsg(1, strInfo);
/*      */       }
/*      */       
/*  704 */       if (this.remainingTileParts == 0)
/*      */       {
/*      */         
/*  707 */         if (!this.isEOCFound && !this.isPsotEqualsZero && !this.rateReached) {
/*      */           try {
/*  709 */             int savePos = this.in.getPos();
/*  710 */             this.in.seek(this.maxPos);
/*  711 */             if (this.in.readShort() != -39) {
/*  712 */               FacilityManager.getMsgLogger().printmsg(2, "EOC marker not found. Codestream is corrupted.");
/*      */             }
/*      */ 
/*      */             
/*  716 */             this.in.seek(savePos);
/*  717 */           } catch (EOFException e) {
/*  718 */             FacilityManager.getMsgLogger().printmsg(2, "EOC marker is missing");
/*      */           } 
/*      */         }
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  726 */     if (!this.isTruncMode) {
/*  727 */       allocateRate();
/*  728 */     } else if (this.remainingTileParts == 0 && !isEOFEncountered) {
/*      */       
/*  730 */       if (this.in.getPos() >= this.tnbytes) {
/*  731 */         this.anbytes += 2;
/*      */       }
/*      */     } 
/*  734 */     if (this.tilePartPositions == null) this.lastPos = this.in.getPos();
/*      */ 
/*      */     
/*  737 */     for (int tIdx = 0; tIdx < this.nt; tIdx++) {
/*  738 */       this.baknBytes[tIdx] = this.nBytes[tIdx];
/*  739 */       if (this.printInfo) {
/*  740 */         FacilityManager.getMsgLogger().println("" + this.hi.toStringTileHeader(tIdx, (this.tilePartLen[tIdx]).length), 2, 2);
/*      */       }
/*      */     }  }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void allocateRate() throws IOException {
/*  753 */     int stopOff = this.tnbytes;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  759 */     if (this.remainingTileParts == 0) this.anbytes += 2;
/*      */ 
/*      */ 
/*      */     
/*  763 */     if (this.anbytes > stopOff) {
/*  764 */       throw new Error("Requested bitrate is too small for parsing");
/*      */     }
/*      */ 
/*      */     
/*  768 */     int rem = stopOff - this.anbytes;
/*  769 */     int totnByte = rem;
/*  770 */     for (int t = this.nt - 1; t > 0; t--) {
/*  771 */       this.nBytes[t] = (int)(totnByte * this.totTileLen[t] / this.totAllTileLen); rem -= (int)(totnByte * this.totTileLen[t] / this.totAllTileLen);
/*      */     } 
/*  773 */     this.nBytes[0] = rem;
/*      */   } private void initTLM() throws IOException { int savePos = this.in.getPos(); byte[][] tlmSegments = (byte[][])null; int numTLM = 0; try { this.in.seek(this.cdstreamStart + 2); short marker; while ((marker = this.in.readShort()) != -112) { int markerLength = this.in.readUnsignedShort(); if (marker == -171) { numTLM++; if (tlmSegments == null)
/*      */             tlmSegments = new byte[256][];  int Ztlm = this.in.read(); tlmSegments[Ztlm] = new byte[markerLength - 3]; this.in.readFully(tlmSegments[Ztlm], 0, markerLength - 3); continue; }  this.in.skipBytes(markerLength - 2); }  } catch (IOException e) { tlmSegments = (byte[][])null; }  if (tlmSegments != null) { ArrayList[] tlmOffsets = null; long tilePos = (this.cdstreamStart + this.mainHeadLen); int tileCounter = 0; for (int itlm = 0; itlm < numTLM; itlm++) { if (tlmSegments[itlm] == null) { tlmOffsets = null; break; }  if (tlmOffsets == null)
/*      */           tlmOffsets = new ArrayList[this.nt];  ByteArrayInputStream bais = new ByteArrayInputStream(tlmSegments[itlm]); ImageInputStream iis = new MemoryCacheImageInputStream(bais); try { int Stlm = iis.read(); int ST = Stlm >> 4 & 0x3; int SP = Stlm >> 6 & 0x1; int tlmLength = (tlmSegments[itlm]).length; while (iis.getStreamPosition() < tlmLength) { int tileIndex = tileCounter; switch (ST) { case 1: tileIndex = iis.read(); break;
/*      */               case 2:
/*      */                 tileIndex = iis.readUnsignedShort(); break; }  if (tlmOffsets[tileIndex] == null)
/*      */               tlmOffsets[tileIndex] = new ArrayList();  tlmOffsets[tileIndex].add(new Long(tilePos)); long tileLength = 0L; switch (SP) { case 0:
/*      */                 tileLength = iis.readUnsignedShort(); break;
/*      */               case 1:
/*      */                 tileLength = iis.readUnsignedInt(); break; }  tilePos += tileLength; if (ST == 0)
/*      */               tileCounter++;  }  } catch (IOException e) {} }  if (tlmOffsets != null) { this.tilePartPositions = new long[this.nt][]; for (int i = 0; i < this.nt; i++) { if (tlmOffsets[i] == null) { this.tilePartPositions = (long[][])null; break; }  ArrayList list = tlmOffsets[i]; int count = list.size(); this.tilePartPositions[i] = new long[count]; long[] tpPos = this.tilePartPositions[i]; for (int j = 0; j < count; j++)
/*  784 */             tpPos[j] = ((Long)list.get(j)).longValue();  }  }  }  this.in.seek(savePos); } private int readTilePartHeader() throws IOException { HeaderInfo.SOT ms = this.hi.getNewSOT();
/*      */ 
/*      */     
/*  787 */     short marker = this.in.readShort();
/*  788 */     if (marker != -112) {
/*  789 */       if (marker == -39) {
/*  790 */         this.isEOCFound = true;
/*  791 */         return -1;
/*      */       } 
/*  793 */       throw new CorruptedCodestreamException("SOT tag not found in tile-part start");
/*      */     } 
/*      */ 
/*      */     
/*  797 */     this.isEOCFound = false;
/*      */ 
/*      */     
/*  800 */     int lsot = this.in.readUnsignedShort();
/*  801 */     ms.lsot = lsot;
/*  802 */     if (lsot != 10) {
/*  803 */       throw new CorruptedCodestreamException("Wrong length for SOT marker segment: " + lsot);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  808 */     int tile = this.in.readUnsignedShort();
/*  809 */     ms.isot = tile;
/*  810 */     if (tile > 65534) {
/*  811 */       throw new CorruptedCodestreamException("Tile index too high in tile-part.");
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  816 */     int psot = this.in.readInt();
/*  817 */     ms.psot = psot;
/*  818 */     this.isPsotEqualsZero = !(psot != 0);
/*  819 */     if (psot < 0) {
/*  820 */       throw new NotImplementedError("Tile length larger than maximum supported");
/*      */     }
/*      */ 
/*      */     
/*  824 */     int tilePart = this.in.read();
/*  825 */     ms.tpsot = tilePart;
/*  826 */     if (tilePart != this.tilePartsRead[tile] || tilePart < 0 || tilePart > 254) {
/*  827 */       throw new CorruptedCodestreamException("Out of order tile-part");
/*      */     }
/*      */     
/*  830 */     int nrOfTileParts = this.in.read();
/*  831 */     ms.tnsot = nrOfTileParts;
/*  832 */     this.hi.sot.put("t" + tile + "_tp" + tilePart, ms);
/*  833 */     if (nrOfTileParts == 0) {
/*      */       int nExtraTp;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  839 */       if (this.tileParts[tile] == 0 || this.tileParts[tile] == this.tilePartLen.length) {
/*      */ 
/*      */         
/*  842 */         nExtraTp = 2;
/*  843 */         this.remainingTileParts++;
/*      */       }
/*      */       else {
/*      */         
/*  847 */         nExtraTp = 1;
/*      */       } 
/*      */       
/*  850 */       this.tileParts[tile] = this.tileParts[tile] + nExtraTp;
/*  851 */       nrOfTileParts = this.tileParts[tile];
/*  852 */       FacilityManager.getMsgLogger().printmsg(2, "Header of tile-part " + tilePart + " of tile " + tile + ", does not indicate the total" + " number of tile-parts. Assuming that there are " + nrOfTileParts + " tile-parts for this tile.");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  859 */       int[] tmpA = this.tilePartLen[tile];
/*  860 */       this.tilePartLen[tile] = new int[nrOfTileParts]; int i;
/*  861 */       for (i = 0; i < nrOfTileParts - nExtraTp; i++) {
/*  862 */         this.tilePartLen[tile][i] = tmpA[i];
/*      */       }
/*      */       
/*  865 */       tmpA = this.tilePartNum[tile];
/*  866 */       this.tilePartNum[tile] = new int[nrOfTileParts];
/*  867 */       for (i = 0; i < nrOfTileParts - nExtraTp; i++) {
/*  868 */         this.tilePartNum[tile][i] = tmpA[i];
/*      */       }
/*      */ 
/*      */       
/*  872 */       tmpA = this.firstPackOff[tile];
/*  873 */       this.firstPackOff[tile] = new int[nrOfTileParts];
/*  874 */       for (i = 0; i < nrOfTileParts - nExtraTp; i++) {
/*  875 */         this.firstPackOff[tile][i] = tmpA[i];
/*      */       }
/*      */ 
/*      */       
/*  879 */       tmpA = this.tilePartHeadLen[tile];
/*  880 */       this.tilePartHeadLen[tile] = new int[nrOfTileParts];
/*  881 */       for (i = 0; i < nrOfTileParts - nExtraTp; i++) {
/*  882 */         this.tilePartHeadLen[tile][i] = tmpA[i];
/*      */       }
/*      */     } else {
/*      */       
/*  886 */       this.totTileParts[tile] = nrOfTileParts;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  891 */       if (this.tileParts[tile] == 0)
/*  892 */       { this.remainingTileParts += nrOfTileParts - 1;
/*  893 */         this.tileParts[tile] = nrOfTileParts;
/*  894 */         this.tilePartLen[tile] = new int[nrOfTileParts];
/*  895 */         this.tilePartNum[tile] = new int[nrOfTileParts];
/*  896 */         this.firstPackOff[tile] = new int[nrOfTileParts];
/*  897 */         this.tilePartHeadLen[tile] = new int[nrOfTileParts]; }
/*  898 */       else { if (this.tileParts[tile] > nrOfTileParts)
/*      */         {
/*  900 */           throw new CorruptedCodestreamException("Invalid number of tile-parts in tile " + tile + ": " + nrOfTileParts);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  906 */         this.remainingTileParts += nrOfTileParts - this.tileParts[tile];
/*      */         
/*  908 */         if (this.tileParts[tile] != nrOfTileParts) {
/*      */ 
/*      */           
/*  911 */           int[] tmpA = this.tilePartLen[tile];
/*  912 */           this.tilePartLen[tile] = new int[nrOfTileParts]; int i;
/*  913 */           for (i = 0; i < this.tileParts[tile] - 1; i++) {
/*  914 */             this.tilePartLen[tile][i] = tmpA[i];
/*      */           }
/*      */ 
/*      */           
/*  918 */           tmpA = this.tilePartNum[tile];
/*  919 */           this.tilePartNum[tile] = new int[nrOfTileParts];
/*  920 */           for (i = 0; i < this.tileParts[tile] - 1; i++) {
/*  921 */             this.tilePartNum[tile][i] = tmpA[i];
/*      */           }
/*      */ 
/*      */           
/*  925 */           tmpA = this.firstPackOff[tile];
/*  926 */           this.firstPackOff[tile] = new int[nrOfTileParts];
/*  927 */           for (i = 0; i < this.tileParts[tile] - 1; i++) {
/*  928 */             this.firstPackOff[tile][i] = tmpA[i];
/*      */           }
/*      */ 
/*      */           
/*  932 */           tmpA = this.tilePartHeadLen[tile];
/*  933 */           this.tilePartHeadLen[tile] = new int[nrOfTileParts];
/*  934 */           for (i = 0; i < this.tileParts[tile] - 1; i++) {
/*  935 */             this.tilePartHeadLen[tile][i] = tmpA[i];
/*      */           }
/*      */         }  }
/*      */     
/*      */     } 
/*      */ 
/*      */     
/*  942 */     this.hd.resetHeaderMarkers();
/*  943 */     this.hd.nTileParts[tile] = nrOfTileParts;
/*      */ 
/*      */     
/*      */     do {
/*  947 */       this.hd.extractTilePartMarkSeg(this.in.readShort(), this.in, tile, tilePart);
/*  948 */     } while ((this.hd.getNumFoundMarkSeg() & 0x2000) == 0);
/*      */ 
/*      */     
/*  951 */     this.hd.readFoundTilePartMarkSeg(tile, tilePart);
/*      */     
/*  953 */     this.tilePartLen[tile][tilePart] = psot;
/*      */     
/*  955 */     this.tilePartNum[tile][tilePart] = this.totTilePartsRead;
/*  956 */     this.totTilePartsRead++;
/*      */ 
/*      */ 
/*      */     
/*  960 */     this.hd.setTileOfTileParts(tile);
/*      */     
/*  962 */     return tile; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean readLyResCompPos(int[][] lys, int lye, int ress, int rese, int comps, int compe) throws IOException {
/*  988 */     int minlys = 10000;
/*  989 */     for (int c = comps; c < compe; c++) {
/*      */       
/*  991 */       if (c < this.mdl.length)
/*      */       {
/*  993 */         for (int r = ress; r < rese; r++) {
/*  994 */           if (lys[c] != null && r < (lys[c]).length && lys[c][r] < minlys) {
/*  995 */             minlys = lys[c][r];
/*      */           }
/*      */         } 
/*      */       }
/*      */     } 
/* 1000 */     int t = getTileIdx();
/*      */     
/* 1002 */     boolean status = false;
/* 1003 */     int lastByte = this.firstPackOff[t][this.curTilePart] + this.tilePartLen[t][this.curTilePart] - 1 - this.tilePartHeadLen[t][this.curTilePart];
/*      */ 
/*      */     
/* 1006 */     int numLayers = ((Integer)this.decSpec.nls.getTileDef(t)).intValue();
/* 1007 */     int nPrec = 1;
/*      */     
/* 1009 */     String strInfo = this.printInfo ? ("Tile " + getTileIdx() + " (tile-part:" + this.curTilePart + "): offset, length, header length\n") : null;
/*      */ 
/*      */     
/* 1012 */     boolean pph = false;
/* 1013 */     if (((Boolean)this.decSpec.pphs.getTileDef(t)).booleanValue()) {
/* 1014 */       pph = true;
/*      */     }
/* 1016 */     for (int l = minlys; l < lye; l++) {
/* 1017 */       for (int r = ress; r < rese; r++) {
/* 1018 */         for (int i = comps; i < compe; i++) {
/*      */           
/* 1020 */           if (i < this.mdl.length)
/*      */           {
/* 1022 */             if (r < (lys[i]).length && 
/* 1023 */               r <= this.mdl[i])
/*      */             {
/* 1025 */               if (l >= lys[i][r] && l < numLayers) {
/*      */                 
/* 1027 */                 nPrec = this.pktDec.getNumPrecinct(i, r);
/* 1028 */                 for (int p = 0; p < nPrec; p++) {
/* 1029 */                   int start = this.in.getPos();
/*      */ 
/*      */ 
/*      */                   
/* 1033 */                   if (pph) {
/* 1034 */                     this.pktDec.readPktHead(l, r, i, p, this.cbI[i][r], this.nBytes);
/*      */                   }
/*      */ 
/*      */ 
/*      */                   
/* 1039 */                   if (start > lastByte && this.curTilePart < (this.firstPackOff[t]).length - 1) {
/*      */                     
/* 1041 */                     this.curTilePart++;
/* 1042 */                     this.in.seek(this.firstPackOff[t][this.curTilePart]);
/* 1043 */                     lastByte = this.in.getPos() + this.tilePartLen[t][this.curTilePart] - 1 - this.tilePartHeadLen[t][this.curTilePart];
/*      */                   } 
/*      */ 
/*      */ 
/*      */ 
/*      */                   
/* 1049 */                   status = this.pktDec.readSOPMarker(this.nBytes, p, i, r);
/*      */                   
/* 1051 */                   if (status) {
/* 1052 */                     if (this.printInfo) {
/* 1053 */                       FacilityManager.getMsgLogger().printmsg(1, strInfo);
/*      */                     }
/*      */                     
/* 1056 */                     return true;
/*      */                   } 
/*      */                   
/* 1059 */                   if (!pph) {
/* 1060 */                     status = this.pktDec.readPktHead(l, r, i, p, this.cbI[i][r], this.nBytes);
/*      */                   }
/*      */ 
/*      */                   
/* 1064 */                   if (status) {
/* 1065 */                     if (this.printInfo) {
/* 1066 */                       FacilityManager.getMsgLogger().printmsg(1, strInfo);
/*      */                     }
/*      */                     
/* 1069 */                     return true;
/*      */                   } 
/*      */ 
/*      */                   
/* 1073 */                   int hlen = this.in.getPos() - start;
/* 1074 */                   this.pktHL.addElement(new Integer(hlen));
/*      */ 
/*      */                   
/* 1077 */                   status = this.pktDec.readPktBody(l, r, i, p, this.cbI[i][r], this.nBytes);
/* 1078 */                   int plen = this.in.getPos() - start;
/* 1079 */                   if (this.printInfo) {
/* 1080 */                     strInfo = strInfo + " Pkt l=" + l + ",r=" + r + ",c=" + i + ",p=" + p + ": " + start + ", " + plen + ", " + hlen + "\n";
/*      */                   }
/*      */                   
/* 1083 */                   if (status) {
/* 1084 */                     if (this.printInfo) {
/* 1085 */                       FacilityManager.getMsgLogger().printmsg(1, strInfo);
/*      */                     }
/*      */                     
/* 1088 */                     return true;
/*      */                   } 
/*      */                 } 
/*      */               }  } 
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/* 1096 */     if (this.printInfo) {
/* 1097 */       FacilityManager.getMsgLogger().printmsg(1, strInfo);
/*      */     }
/* 1099 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean readResLyCompPos(int[][] lys, int lye, int ress, int rese, int comps, int compe) throws IOException {
/* 1124 */     int t = getTileIdx();
/* 1125 */     boolean status = false;
/* 1126 */     int lastByte = this.firstPackOff[t][this.curTilePart] + this.tilePartLen[t][this.curTilePart] - 1 - this.tilePartHeadLen[t][this.curTilePart];
/*      */ 
/*      */     
/* 1129 */     int minlys = 10000;
/* 1130 */     for (int c = comps; c < compe; c++) {
/*      */       
/* 1132 */       if (c < this.mdl.length)
/*      */       {
/* 1134 */         for (int i = ress; i < rese; i++) {
/* 1135 */           if (i <= this.mdl[c] && 
/* 1136 */             lys[c] != null && i < (lys[c]).length && lys[c][i] < minlys) {
/* 1137 */             minlys = lys[c][i];
/*      */           }
/*      */         } 
/*      */       }
/*      */     } 
/* 1142 */     String strInfo = this.printInfo ? ("Tile " + getTileIdx() + " (tile-part:" + this.curTilePart + "): offset, length, header length\n") : null;
/*      */ 
/*      */     
/* 1145 */     int numLayers = ((Integer)this.decSpec.nls.getTileDef(t)).intValue();
/* 1146 */     boolean pph = false;
/* 1147 */     if (((Boolean)this.decSpec.pphs.getTileDef(t)).booleanValue()) {
/* 1148 */       pph = true;
/*      */     }
/* 1150 */     int nPrec = 1;
/*      */ 
/*      */     
/* 1153 */     for (int r = ress; r < rese; r++) {
/* 1154 */       for (int l = minlys; l < lye; l++) {
/* 1155 */         for (int i = comps; i < compe; i++) {
/*      */           
/* 1157 */           if (i < this.mdl.length)
/*      */           {
/* 1159 */             if (r <= this.mdl[i] && 
/* 1160 */               r < (lys[i]).length)
/*      */             {
/* 1162 */               if (l >= lys[i][r] && l < numLayers) {
/*      */                 
/* 1164 */                 nPrec = this.pktDec.getNumPrecinct(i, r);
/*      */                 
/* 1166 */                 for (int p = 0; p < nPrec; p++) {
/* 1167 */                   int start = this.in.getPos();
/*      */ 
/*      */ 
/*      */                   
/* 1171 */                   if (pph) {
/* 1172 */                     this.pktDec.readPktHead(l, r, i, p, this.cbI[i][r], this.nBytes);
/*      */                   }
/*      */ 
/*      */ 
/*      */                   
/* 1177 */                   if (start > lastByte && this.curTilePart < (this.firstPackOff[t]).length - 1) {
/*      */                     
/* 1179 */                     this.curTilePart++;
/* 1180 */                     this.in.seek(this.firstPackOff[t][this.curTilePart]);
/* 1181 */                     lastByte = this.in.getPos() + this.tilePartLen[t][this.curTilePart] - 1 - this.tilePartHeadLen[t][this.curTilePart];
/*      */                   } 
/*      */ 
/*      */ 
/*      */ 
/*      */                   
/* 1187 */                   status = this.pktDec.readSOPMarker(this.nBytes, p, i, r);
/*      */                   
/* 1189 */                   if (status) {
/* 1190 */                     if (this.printInfo) {
/* 1191 */                       FacilityManager.getMsgLogger().printmsg(1, strInfo);
/*      */                     }
/*      */                     
/* 1194 */                     return true;
/*      */                   } 
/*      */                   
/* 1197 */                   if (!pph) {
/* 1198 */                     status = this.pktDec.readPktHead(l, r, i, p, this.cbI[i][r], this.nBytes);
/*      */                   }
/*      */ 
/*      */                   
/* 1202 */                   if (status) {
/* 1203 */                     if (this.printInfo) {
/* 1204 */                       FacilityManager.getMsgLogger().printmsg(1, strInfo);
/*      */                     }
/*      */ 
/*      */                     
/* 1208 */                     return true;
/*      */                   } 
/*      */ 
/*      */                   
/* 1212 */                   int hlen = this.in.getPos() - start;
/* 1213 */                   this.pktHL.addElement(new Integer(hlen));
/*      */ 
/*      */                   
/* 1216 */                   status = this.pktDec.readPktBody(l, r, i, p, this.cbI[i][r], this.nBytes);
/* 1217 */                   int plen = this.in.getPos() - start;
/* 1218 */                   if (this.printInfo) {
/* 1219 */                     strInfo = strInfo + " Pkt l=" + l + ",r=" + r + ",c=" + i + ",p=" + p + ": " + start + ", " + plen + ", " + hlen + "\n";
/*      */                   }
/*      */                   
/* 1222 */                   if (status) {
/* 1223 */                     if (this.printInfo) {
/* 1224 */                       FacilityManager.getMsgLogger().printmsg(1, strInfo);
/*      */                     }
/*      */ 
/*      */                     
/* 1228 */                     return true;
/*      */                   } 
/*      */                 } 
/*      */               }  } 
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/* 1236 */     if (this.printInfo) {
/* 1237 */       FacilityManager.getMsgLogger().printmsg(1, strInfo);
/*      */     }
/* 1239 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean readResPosCompLy(int[][] lys, int lye, int ress, int rese, int comps, int compe) throws IOException {
/* 1266 */     Point nTiles = getNumTiles(null);
/* 1267 */     Point tileI = getTile(null);
/* 1268 */     int x0siz = this.hd.getImgULX();
/* 1269 */     int y0siz = this.hd.getImgULY();
/* 1270 */     int xsiz = x0siz + this.hd.getImgWidth();
/* 1271 */     int ysiz = y0siz + this.hd.getImgHeight();
/* 1272 */     int xt0siz = getTilePartULX();
/* 1273 */     int yt0siz = getTilePartULY();
/* 1274 */     int xtsiz = getNomTileWidth();
/* 1275 */     int ytsiz = getNomTileHeight();
/* 1276 */     int tx0 = (tileI.x == 0) ? x0siz : (xt0siz + tileI.x * xtsiz);
/* 1277 */     int ty0 = (tileI.y == 0) ? y0siz : (yt0siz + tileI.y * ytsiz);
/* 1278 */     int tx1 = (tileI.x != nTiles.x - 1) ? (xt0siz + (tileI.x + 1) * xtsiz) : xsiz;
/* 1279 */     int ty1 = (tileI.y != nTiles.y - 1) ? (yt0siz + (tileI.y + 1) * ytsiz) : ysiz;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1284 */     int t = getTileIdx();
/*      */ 
/*      */     
/* 1287 */     int gcd_x = 0;
/* 1288 */     int gcd_y = 0;
/* 1289 */     int nPrec = 0;
/* 1290 */     int[][] nextPrec = new int[compe][];
/*      */     
/* 1292 */     int minlys = 100000;
/* 1293 */     int minx = tx1;
/*      */     
/* 1295 */     int miny = ty1;
/*      */     
/* 1297 */     int maxx = tx0;
/* 1298 */     int maxy = ty0;
/*      */     
/* 1300 */     for (int c = comps; c < compe; c++) {
/* 1301 */       for (int i = ress; i < rese; i++) {
/* 1302 */         if (c < this.mdl.length && 
/* 1303 */           i <= this.mdl[c]) {
/* 1304 */           nextPrec[c] = new int[this.mdl[c] + 1];
/* 1305 */           if (lys[c] != null && i < (lys[c]).length && lys[c][i] < minlys) {
/* 1306 */             minlys = lys[c][i];
/*      */           }
/* 1308 */           int p = this.pktDec.getNumPrecinct(c, i) - 1;
/* 1309 */           for (; p >= 0; p--) {
/* 1310 */             PrecInfo prec = this.pktDec.getPrecInfo(c, i, p);
/* 1311 */             if (prec.rgulx != tx0) {
/* 1312 */               if (prec.rgulx < minx) minx = prec.rgulx; 
/* 1313 */               if (prec.rgulx > maxx) maxx = prec.rgulx; 
/*      */             } 
/* 1315 */             if (prec.rguly != ty0) {
/* 1316 */               if (prec.rguly < miny) miny = prec.rguly; 
/* 1317 */               if (prec.rguly > maxy) maxy = prec.rguly;
/*      */             
/*      */             } 
/* 1320 */             if (nPrec == 0) {
/* 1321 */               gcd_x = prec.rgw;
/* 1322 */               gcd_y = prec.rgh;
/*      */             } else {
/* 1324 */               gcd_x = MathUtil.gcd(gcd_x, prec.rgw);
/* 1325 */               gcd_y = MathUtil.gcd(gcd_y, prec.rgh);
/*      */             } 
/* 1327 */             nPrec++;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/* 1332 */     if (nPrec == 0) {
/* 1333 */       throw new Error("Image cannot have no precinct");
/*      */     }
/*      */     
/* 1336 */     int pyend = (maxy - miny) / gcd_y + 1;
/* 1337 */     int pxend = (maxx - minx) / gcd_x + 1;
/*      */ 
/*      */ 
/*      */     
/* 1341 */     boolean status = false;
/* 1342 */     int lastByte = this.firstPackOff[t][this.curTilePart] + this.tilePartLen[t][this.curTilePart] - 1 - this.tilePartHeadLen[t][this.curTilePart];
/*      */ 
/*      */     
/* 1345 */     int numLayers = ((Integer)this.decSpec.nls.getTileDef(t)).intValue();
/* 1346 */     String strInfo = this.printInfo ? ("Tile " + getTileIdx() + " (tile-part:" + this.curTilePart + "): offset, length, header length\n") : null;
/*      */ 
/*      */     
/* 1349 */     boolean pph = false;
/* 1350 */     if (((Boolean)this.decSpec.pphs.getTileDef(t)).booleanValue()) {
/* 1351 */       pph = true;
/*      */     }
/* 1353 */     for (int r = ress; r < rese; r++) {
/* 1354 */       int y = ty0;
/* 1355 */       int x = tx0;
/* 1356 */       for (int py = 0; py <= pyend; py++) {
/* 1357 */         for (int px = 0; px <= pxend; px++) {
/* 1358 */           for (int i = comps; i < compe; i++) {
/* 1359 */             if (i < this.mdl.length && 
/* 1360 */               r <= this.mdl[i] && 
/* 1361 */               nextPrec[i][r] < this.pktDec.getNumPrecinct(i, r)) {
/*      */ 
/*      */               
/* 1364 */               PrecInfo prec = this.pktDec.getPrecInfo(i, r, nextPrec[i][r]);
/* 1365 */               if (prec.rgulx == x && prec.rguly == y)
/*      */               
/*      */               { 
/* 1368 */                 for (int l = minlys; l < lye; l++) {
/* 1369 */                   if (r < (lys[i]).length && 
/* 1370 */                     l >= lys[i][r] && l < numLayers) {
/*      */                     
/* 1372 */                     int start = this.in.getPos();
/*      */ 
/*      */ 
/*      */ 
/*      */                     
/* 1377 */                     if (pph) {
/* 1378 */                       this.pktDec.readPktHead(l, r, i, nextPrec[i][r], this.cbI[i][r], this.nBytes);
/*      */                     }
/*      */ 
/*      */ 
/*      */                     
/* 1383 */                     if (start > lastByte && this.curTilePart < (this.firstPackOff[t]).length - 1) {
/*      */                       
/* 1385 */                       this.curTilePart++;
/* 1386 */                       this.in.seek(this.firstPackOff[t][this.curTilePart]);
/* 1387 */                       lastByte = this.in.getPos() + this.tilePartLen[t][this.curTilePart] - 1 - this.tilePartHeadLen[t][this.curTilePart];
/*      */                     } 
/*      */ 
/*      */ 
/*      */ 
/*      */                     
/* 1393 */                     status = this.pktDec.readSOPMarker(this.nBytes, nextPrec[i][r], i, r);
/*      */ 
/*      */                     
/* 1396 */                     if (status) {
/* 1397 */                       if (this.printInfo) {
/* 1398 */                         FacilityManager.getMsgLogger().printmsg(1, strInfo);
/*      */                       }
/*      */                       
/* 1401 */                       return true;
/*      */                     } 
/*      */                     
/* 1404 */                     if (!pph) {
/* 1405 */                       status = this.pktDec.readPktHead(l, r, i, nextPrec[i][r], this.cbI[i][r], this.nBytes);
/*      */                     }
/*      */ 
/*      */ 
/*      */ 
/*      */                     
/* 1411 */                     if (status) {
/* 1412 */                       if (this.printInfo) {
/* 1413 */                         FacilityManager.getMsgLogger().printmsg(1, strInfo);
/*      */                       }
/*      */                       
/* 1416 */                       return true;
/*      */                     } 
/*      */ 
/*      */                     
/* 1420 */                     int hlen = this.in.getPos() - start;
/* 1421 */                     this.pktHL.addElement(new Integer(hlen));
/*      */ 
/*      */ 
/*      */                     
/* 1425 */                     status = this.pktDec.readPktBody(l, r, i, nextPrec[i][r], this.cbI[i][r], this.nBytes);
/*      */                     
/* 1427 */                     int plen = this.in.getPos() - start;
/* 1428 */                     if (this.printInfo) {
/* 1429 */                       strInfo = strInfo + " Pkt l=" + l + ",r=" + r + ",c=" + i + ",p=" + nextPrec[i][r] + ": " + start + ", " + plen + ", " + hlen + "\n";
/*      */                     }
/*      */ 
/*      */                     
/* 1433 */                     if (status) {
/* 1434 */                       if (this.printInfo) {
/* 1435 */                         FacilityManager.getMsgLogger().printmsg(1, strInfo);
/*      */                       }
/*      */                       
/* 1438 */                       return true;
/*      */                     } 
/*      */                   } 
/* 1441 */                 }  nextPrec[i][r] = nextPrec[i][r] + 1; } 
/*      */             } 
/* 1443 */           }  if (px != pxend) {
/* 1444 */             x = minx + px * gcd_x;
/*      */           } else {
/* 1446 */             x = tx0;
/*      */           } 
/*      */         } 
/* 1449 */         if (py != pyend) {
/* 1450 */           y = miny + py * gcd_y;
/*      */         } else {
/* 1452 */           y = ty0;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 1457 */     if (this.printInfo) {
/* 1458 */       FacilityManager.getMsgLogger().printmsg(1, strInfo);
/*      */     }
/* 1460 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean readPosCompResLy(int[][] lys, int lye, int ress, int rese, int comps, int compe) throws IOException {
/* 1484 */     Point nTiles = getNumTiles(null);
/* 1485 */     Point tileI = getTile(null);
/* 1486 */     int x0siz = this.hd.getImgULX();
/* 1487 */     int y0siz = this.hd.getImgULY();
/* 1488 */     int xsiz = x0siz + this.hd.getImgWidth();
/* 1489 */     int ysiz = y0siz + this.hd.getImgHeight();
/* 1490 */     int xt0siz = getTilePartULX();
/* 1491 */     int yt0siz = getTilePartULY();
/* 1492 */     int xtsiz = getNomTileWidth();
/* 1493 */     int ytsiz = getNomTileHeight();
/* 1494 */     int tx0 = (tileI.x == 0) ? x0siz : (xt0siz + tileI.x * xtsiz);
/* 1495 */     int ty0 = (tileI.y == 0) ? y0siz : (yt0siz + tileI.y * ytsiz);
/* 1496 */     int tx1 = (tileI.x != nTiles.x - 1) ? (xt0siz + (tileI.x + 1) * xtsiz) : xsiz;
/* 1497 */     int ty1 = (tileI.y != nTiles.y - 1) ? (yt0siz + (tileI.y + 1) * ytsiz) : ysiz;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1502 */     int t = getTileIdx();
/*      */ 
/*      */     
/* 1505 */     int gcd_x = 0;
/* 1506 */     int gcd_y = 0;
/* 1507 */     int nPrec = 0;
/* 1508 */     int[][] nextPrec = new int[compe][];
/*      */     
/* 1510 */     int minlys = 100000;
/* 1511 */     int minx = tx1;
/*      */     
/* 1513 */     int miny = ty1;
/*      */     
/* 1515 */     int maxx = tx0;
/* 1516 */     int maxy = ty0;
/*      */     
/* 1518 */     for (int c = comps; c < compe; c++) {
/* 1519 */       for (int r = ress; r < rese; r++) {
/* 1520 */         if (c < this.mdl.length && 
/* 1521 */           r <= this.mdl[c]) {
/* 1522 */           nextPrec[c] = new int[this.mdl[c] + 1];
/* 1523 */           if (lys[c] != null && r < (lys[c]).length && lys[c][r] < minlys) {
/* 1524 */             minlys = lys[c][r];
/*      */           }
/* 1526 */           int p = this.pktDec.getNumPrecinct(c, r) - 1;
/* 1527 */           for (; p >= 0; p--) {
/* 1528 */             PrecInfo prec = this.pktDec.getPrecInfo(c, r, p);
/* 1529 */             if (prec.rgulx != tx0) {
/* 1530 */               if (prec.rgulx < minx) minx = prec.rgulx; 
/* 1531 */               if (prec.rgulx > maxx) maxx = prec.rgulx; 
/*      */             } 
/* 1533 */             if (prec.rguly != ty0) {
/* 1534 */               if (prec.rguly < miny) miny = prec.rguly; 
/* 1535 */               if (prec.rguly > maxy) maxy = prec.rguly;
/*      */             
/*      */             } 
/* 1538 */             if (nPrec == 0) {
/* 1539 */               gcd_x = prec.rgw;
/* 1540 */               gcd_y = prec.rgh;
/*      */             } else {
/* 1542 */               gcd_x = MathUtil.gcd(gcd_x, prec.rgw);
/* 1543 */               gcd_y = MathUtil.gcd(gcd_y, prec.rgh);
/*      */             } 
/* 1545 */             nPrec++;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/* 1550 */     if (nPrec == 0) {
/* 1551 */       throw new Error("Image cannot have no precinct");
/*      */     }
/*      */     
/* 1554 */     int pyend = (maxy - miny) / gcd_y + 1;
/* 1555 */     int pxend = (maxx - minx) / gcd_x + 1;
/*      */ 
/*      */     
/* 1558 */     boolean status = false;
/* 1559 */     int lastByte = this.firstPackOff[t][this.curTilePart] + this.tilePartLen[t][this.curTilePart] - 1 - this.tilePartHeadLen[t][this.curTilePart];
/*      */ 
/*      */     
/* 1562 */     int numLayers = ((Integer)this.decSpec.nls.getTileDef(t)).intValue();
/* 1563 */     String strInfo = this.printInfo ? ("Tile " + getTileIdx() + " (tile-part:" + this.curTilePart + "): offset, length, header length\n") : null;
/*      */ 
/*      */     
/* 1566 */     boolean pph = false;
/* 1567 */     if (((Boolean)this.decSpec.pphs.getTileDef(t)).booleanValue()) {
/* 1568 */       pph = true;
/*      */     }
/*      */     
/* 1571 */     int y = ty0;
/* 1572 */     int x = tx0;
/* 1573 */     for (int py = 0; py <= pyend; py++) {
/* 1574 */       for (int px = 0; px <= pxend; px++) {
/* 1575 */         for (int i = comps; i < compe; i++) {
/* 1576 */           if (i < this.mdl.length)
/* 1577 */             for (int r = ress; r < rese; r++) {
/* 1578 */               if (r <= this.mdl[i] && 
/* 1579 */                 nextPrec[i][r] < this.pktDec.getNumPrecinct(i, r)) {
/*      */ 
/*      */                 
/* 1582 */                 PrecInfo prec = this.pktDec.getPrecInfo(i, r, nextPrec[i][r]);
/* 1583 */                 if (prec.rgulx == x && prec.rguly == y)
/*      */                 
/*      */                 { 
/* 1586 */                   for (int l = minlys; l < lye; l++) {
/* 1587 */                     if (r < (lys[i]).length && 
/* 1588 */                       l >= lys[i][r] && l < numLayers) {
/*      */                       
/* 1590 */                       int start = this.in.getPos();
/*      */ 
/*      */ 
/*      */ 
/*      */                       
/* 1595 */                       if (pph) {
/* 1596 */                         this.pktDec.readPktHead(l, r, i, nextPrec[i][r], this.cbI[i][r], this.nBytes);
/*      */                       }
/*      */ 
/*      */                       
/* 1600 */                       status = this.pktDec.readSOPMarker(this.nBytes, nextPrec[i][r], i, r);
/*      */ 
/*      */                       
/* 1603 */                       if (status) {
/* 1604 */                         if (this.printInfo) {
/* 1605 */                           FacilityManager.getMsgLogger().printmsg(1, strInfo);
/*      */                         }
/*      */                         
/* 1608 */                         return true;
/*      */                       } 
/*      */                       
/* 1611 */                       if (!pph) {
/* 1612 */                         status = this.pktDec.readPktHead(l, r, i, nextPrec[i][r], this.cbI[i][r], this.nBytes);
/*      */                       }
/*      */ 
/*      */ 
/*      */ 
/*      */                       
/* 1618 */                       if (status) {
/* 1619 */                         if (this.printInfo) {
/* 1620 */                           FacilityManager.getMsgLogger().printmsg(1, strInfo);
/*      */                         }
/*      */                         
/* 1623 */                         return true;
/*      */                       } 
/*      */ 
/*      */                       
/* 1627 */                       int hlen = this.in.getPos() - start;
/* 1628 */                       this.pktHL.addElement(new Integer(hlen));
/*      */ 
/*      */                       
/* 1631 */                       status = this.pktDec.readPktBody(l, r, i, nextPrec[i][r], this.cbI[i][r], this.nBytes);
/*      */                       
/* 1633 */                       int plen = this.in.getPos() - start;
/* 1634 */                       if (this.printInfo) {
/* 1635 */                         strInfo = strInfo + " Pkt l=" + l + ",r=" + r + ",c=" + i + ",p=" + nextPrec[i][r] + ": " + start + ", " + plen + ", " + hlen + "\n";
/*      */                       }
/*      */ 
/*      */                       
/* 1639 */                       if (status) {
/* 1640 */                         if (this.printInfo) {
/* 1641 */                           FacilityManager.getMsgLogger().printmsg(1, strInfo);
/*      */                         }
/*      */                         
/* 1644 */                         return true;
/*      */                       } 
/*      */                     } 
/*      */                   } 
/* 1648 */                   nextPrec[i][r] = nextPrec[i][r] + 1; } 
/*      */               } 
/*      */             }  
/* 1651 */         }  if (px != pxend) {
/* 1652 */           x = minx + px * gcd_x;
/*      */         } else {
/* 1654 */           x = tx0;
/*      */         } 
/*      */       } 
/* 1657 */       if (py != pyend) {
/* 1658 */         y = miny + py * gcd_y;
/*      */       } else {
/* 1660 */         y = ty0;
/*      */       } 
/*      */     } 
/*      */     
/* 1664 */     if (this.printInfo) {
/* 1665 */       FacilityManager.getMsgLogger().printmsg(1, strInfo);
/*      */     }
/* 1667 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean readCompPosResLy(int[][] lys, int lye, int ress, int rese, int comps, int compe) throws IOException {
/* 1691 */     Point nTiles = getNumTiles(null);
/* 1692 */     Point tileI = getTile(null);
/* 1693 */     int x0siz = this.hd.getImgULX();
/* 1694 */     int y0siz = this.hd.getImgULY();
/* 1695 */     int xsiz = x0siz + this.hd.getImgWidth();
/* 1696 */     int ysiz = y0siz + this.hd.getImgHeight();
/* 1697 */     int xt0siz = getTilePartULX();
/* 1698 */     int yt0siz = getTilePartULY();
/* 1699 */     int xtsiz = getNomTileWidth();
/* 1700 */     int ytsiz = getNomTileHeight();
/* 1701 */     int tx0 = (tileI.x == 0) ? x0siz : (xt0siz + tileI.x * xtsiz);
/* 1702 */     int ty0 = (tileI.y == 0) ? y0siz : (yt0siz + tileI.y * ytsiz);
/* 1703 */     int tx1 = (tileI.x != nTiles.x - 1) ? (xt0siz + (tileI.x + 1) * xtsiz) : xsiz;
/* 1704 */     int ty1 = (tileI.y != nTiles.y - 1) ? (yt0siz + (tileI.y + 1) * ytsiz) : ysiz;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1709 */     int t = getTileIdx();
/*      */ 
/*      */     
/* 1712 */     int gcd_x = 0;
/* 1713 */     int gcd_y = 0;
/* 1714 */     int nPrec = 0;
/* 1715 */     int[][] nextPrec = new int[compe][];
/*      */     
/* 1717 */     int minlys = 100000;
/* 1718 */     int minx = tx1;
/*      */     
/* 1720 */     int miny = ty1;
/*      */     
/* 1722 */     int maxx = tx0;
/* 1723 */     int maxy = ty0;
/*      */     
/* 1725 */     for (int c = comps; c < compe; c++) {
/* 1726 */       for (int r = ress; r < rese; r++) {
/* 1727 */         if (c < this.mdl.length && 
/* 1728 */           r <= this.mdl[c]) {
/* 1729 */           nextPrec[c] = new int[this.mdl[c] + 1];
/* 1730 */           if (lys[c] != null && r < (lys[c]).length && lys[c][r] < minlys) {
/* 1731 */             minlys = lys[c][r];
/*      */           }
/* 1733 */           int p = this.pktDec.getNumPrecinct(c, r) - 1;
/* 1734 */           for (; p >= 0; p--) {
/* 1735 */             PrecInfo prec = this.pktDec.getPrecInfo(c, r, p);
/* 1736 */             if (prec.rgulx != tx0) {
/* 1737 */               if (prec.rgulx < minx) minx = prec.rgulx; 
/* 1738 */               if (prec.rgulx > maxx) maxx = prec.rgulx; 
/*      */             } 
/* 1740 */             if (prec.rguly != ty0) {
/* 1741 */               if (prec.rguly < miny) miny = prec.rguly; 
/* 1742 */               if (prec.rguly > maxy) maxy = prec.rguly;
/*      */             
/*      */             } 
/* 1745 */             if (nPrec == 0) {
/* 1746 */               gcd_x = prec.rgw;
/* 1747 */               gcd_y = prec.rgh;
/*      */             } else {
/* 1749 */               gcd_x = MathUtil.gcd(gcd_x, prec.rgw);
/* 1750 */               gcd_y = MathUtil.gcd(gcd_y, prec.rgh);
/*      */             } 
/* 1752 */             nPrec++;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/* 1757 */     if (nPrec == 0) {
/* 1758 */       throw new Error("Image cannot have no precinct");
/*      */     }
/*      */     
/* 1761 */     int pyend = (maxy - miny) / gcd_y + 1;
/* 1762 */     int pxend = (maxx - minx) / gcd_x + 1;
/*      */ 
/*      */     
/* 1765 */     boolean status = false;
/* 1766 */     int lastByte = this.firstPackOff[t][this.curTilePart] + this.tilePartLen[t][this.curTilePart] - 1 - this.tilePartHeadLen[t][this.curTilePart];
/*      */ 
/*      */     
/* 1769 */     int numLayers = ((Integer)this.decSpec.nls.getTileDef(t)).intValue();
/* 1770 */     String strInfo = this.printInfo ? ("Tile " + getTileIdx() + " (tile-part:" + this.curTilePart + "): offset, length, header length\n") : null;
/*      */ 
/*      */     
/* 1773 */     boolean pph = false;
/* 1774 */     if (((Boolean)this.decSpec.pphs.getTileDef(t)).booleanValue()) {
/* 1775 */       pph = true;
/*      */     }
/*      */ 
/*      */     
/* 1779 */     for (int i = comps; i < compe; i++) {
/* 1780 */       if (i < this.mdl.length) {
/* 1781 */         int y = ty0;
/* 1782 */         int x = tx0;
/* 1783 */         for (int py = 0; py <= pyend; py++) {
/* 1784 */           for (int px = 0; px <= pxend; px++) {
/* 1785 */             for (int r = ress; r < rese; r++) {
/* 1786 */               if (r <= this.mdl[i] && 
/* 1787 */                 nextPrec[i][r] < this.pktDec.getNumPrecinct(i, r)) {
/*      */ 
/*      */                 
/* 1790 */                 PrecInfo prec = this.pktDec.getPrecInfo(i, r, nextPrec[i][r]);
/* 1791 */                 if (prec.rgulx == x && prec.rguly == y)
/*      */                 
/*      */                 { 
/*      */                   
/* 1795 */                   for (int l = minlys; l < lye; l++) {
/* 1796 */                     if (r < (lys[i]).length && 
/* 1797 */                       l >= lys[i][r]) {
/*      */                       
/* 1799 */                       int start = this.in.getPos();
/*      */ 
/*      */ 
/*      */ 
/*      */                       
/* 1804 */                       if (pph) {
/* 1805 */                         this.pktDec.readPktHead(l, r, i, nextPrec[i][r], this.cbI[i][r], this.nBytes);
/*      */                       }
/*      */ 
/*      */ 
/*      */                       
/* 1810 */                       if (start > lastByte && this.curTilePart < (this.firstPackOff[t]).length - 1) {
/*      */                         
/* 1812 */                         this.curTilePart++;
/* 1813 */                         this.in.seek(this.firstPackOff[t][this.curTilePart]);
/* 1814 */                         lastByte = this.in.getPos() + this.tilePartLen[t][this.curTilePart] - 1 - this.tilePartHeadLen[t][this.curTilePart];
/*      */                       } 
/*      */ 
/*      */ 
/*      */ 
/*      */                       
/* 1820 */                       status = this.pktDec.readSOPMarker(this.nBytes, nextPrec[i][r], i, r);
/*      */ 
/*      */                       
/* 1823 */                       if (status) {
/* 1824 */                         if (this.printInfo) {
/* 1825 */                           FacilityManager.getMsgLogger().printmsg(1, strInfo);
/*      */                         }
/*      */                         
/* 1828 */                         return true;
/*      */                       } 
/*      */                       
/* 1831 */                       if (!pph) {
/* 1832 */                         status = this.pktDec.readPktHead(l, r, i, nextPrec[i][r], this.cbI[i][r], this.nBytes);
/*      */                       }
/*      */ 
/*      */ 
/*      */ 
/*      */                       
/* 1838 */                       if (status) {
/* 1839 */                         if (this.printInfo) {
/* 1840 */                           FacilityManager.getMsgLogger().printmsg(1, strInfo);
/*      */                         }
/*      */                         
/* 1843 */                         return true;
/*      */                       } 
/*      */ 
/*      */                       
/* 1847 */                       int hlen = this.in.getPos() - start;
/* 1848 */                       this.pktHL.addElement(new Integer(hlen));
/*      */ 
/*      */                       
/* 1851 */                       status = this.pktDec.readPktBody(l, r, i, nextPrec[i][r], this.cbI[i][r], this.nBytes);
/*      */                       
/* 1853 */                       int plen = this.in.getPos() - start;
/* 1854 */                       if (this.printInfo) {
/* 1855 */                         strInfo = strInfo + " Pkt l=" + l + ",r=" + r + ",c=" + i + ",p=" + nextPrec[i][r] + ": " + start + ", " + plen + ", " + hlen + "\n";
/*      */                       }
/*      */ 
/*      */                       
/* 1859 */                       if (status) {
/* 1860 */                         if (this.printInfo) {
/* 1861 */                           FacilityManager.getMsgLogger().printmsg(1, strInfo);
/*      */                         }
/*      */                         
/* 1864 */                         return true;
/*      */                       } 
/*      */                     } 
/*      */                   } 
/* 1868 */                   nextPrec[i][r] = nextPrec[i][r] + 1; } 
/*      */               } 
/* 1870 */             }  if (px != pxend) {
/* 1871 */               x = minx + px * gcd_x;
/*      */             } else {
/* 1873 */               x = tx0;
/*      */             } 
/*      */           } 
/* 1876 */           if (py != pyend) {
/* 1877 */             y = miny + py * gcd_y;
/*      */           } else {
/* 1879 */             y = ty0;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/* 1884 */     if (this.printInfo) {
/* 1885 */       FacilityManager.getMsgLogger().printmsg(1, strInfo);
/*      */     }
/* 1887 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void readTilePkts(int t) throws IOException {
/* 1905 */     this.pktHL = new Vector();
/*      */     
/* 1907 */     int oldNBytes = this.nBytes[t];
/*      */ 
/*      */     
/* 1910 */     int nl = ((Integer)this.decSpec.nls.getTileDef(t)).intValue();
/*      */ 
/*      */ 
/*      */     
/* 1914 */     if (((Boolean)this.decSpec.pphs.getTileDef(t)).booleanValue()) {
/*      */       
/* 1916 */       ByteArrayInputStream pphbais = this.hd.getPackedPktHead(t);
/*      */ 
/*      */       
/* 1919 */       this.cbI = this.pktDec.restart(this.nc, this.mdl, nl, this.cbI, true, pphbais);
/*      */     } else {
/*      */       
/* 1922 */       this.cbI = this.pktDec.restart(this.nc, this.mdl, nl, this.cbI, false, null);
/*      */     } 
/*      */ 
/*      */     
/* 1926 */     int[][] pocSpec = (int[][])this.decSpec.pcs.getTileDef(t);
/* 1927 */     int nChg = (pocSpec == null) ? 1 : pocSpec.length;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1933 */     int[][] change = new int[nChg][6];
/* 1934 */     int idx = 0;
/*      */     
/* 1936 */     change[0][1] = 0;
/*      */     
/* 1938 */     if (pocSpec == null) {
/* 1939 */       change[idx][0] = ((Integer)this.decSpec.pos.getTileDef(t)).intValue();
/*      */       
/* 1941 */       change[idx][1] = nl;
/* 1942 */       change[idx][2] = 0;
/* 1943 */       change[idx][3] = this.decSpec.dls.getMaxInTile(t) + 1;
/* 1944 */       change[idx][4] = 0;
/* 1945 */       change[idx][5] = this.nc;
/*      */     } else {
/* 1947 */       for (idx = 0; idx < nChg; idx++) {
/* 1948 */         change[idx][0] = pocSpec[idx][5];
/* 1949 */         change[idx][1] = pocSpec[idx][2];
/* 1950 */         change[idx][2] = pocSpec[idx][0];
/* 1951 */         change[idx][3] = pocSpec[idx][3];
/* 1952 */         change[idx][4] = pocSpec[idx][1];
/* 1953 */         change[idx][5] = pocSpec[idx][4];
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 1962 */       if ((this.isTruncMode && this.firstPackOff == null) || this.firstPackOff[t] == null) {
/*      */         return;
/*      */       }
/* 1965 */       this.in.seek(this.firstPackOff[t][0]);
/* 1966 */     } catch (EOFException e) {
/* 1967 */       FacilityManager.getMsgLogger().printmsg(2, "Codestream truncated in tile " + t);
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 1972 */     this.curTilePart = 0;
/*      */ 
/*      */ 
/*      */     
/* 1976 */     boolean status = false;
/* 1977 */     int nb = this.nBytes[t];
/* 1978 */     int[][] lys = new int[this.nc][];
/* 1979 */     for (int c = 0; c < this.nc; c++) {
/* 1980 */       lys[c] = new int[((Integer)this.decSpec.dls.getTileCompVal(t, c)).intValue() + 1];
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 1986 */       for (int chg = 0; chg < nChg; chg++) {
/*      */         
/* 1988 */         int lye = change[chg][1];
/* 1989 */         int ress = change[chg][2];
/* 1990 */         int rese = change[chg][3];
/* 1991 */         int comps = change[chg][4];
/* 1992 */         int compe = change[chg][5];
/*      */         
/* 1994 */         switch (change[chg][0]) {
/*      */           case 0:
/* 1996 */             status = readLyResCompPos(lys, lye, ress, rese, comps, compe);
/*      */             break;
/*      */           case 1:
/* 1999 */             status = readResLyCompPos(lys, lye, ress, rese, comps, compe);
/*      */             break;
/*      */           case 2:
/* 2002 */             status = readResPosCompLy(lys, lye, ress, rese, comps, compe);
/*      */             break;
/*      */           case 3:
/* 2005 */             status = readPosCompResLy(lys, lye, ress, rese, comps, compe);
/*      */             break;
/*      */           case 4:
/* 2008 */             status = readCompPosResLy(lys, lye, ress, rese, comps, compe);
/*      */             break;
/*      */           default:
/* 2011 */             throw new IllegalArgumentException("Not recognized progression type");
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 2016 */         for (int i = comps; i < compe; i++) {
/* 2017 */           if (i < lys.length)
/* 2018 */             for (int r = ress; r < rese; r++) {
/* 2019 */               if (r < (lys[i]).length) {
/* 2020 */                 lys[i][r] = lye;
/*      */               }
/*      */             }  
/*      */         } 
/* 2024 */         if (status || this.usePOCQuit) {
/*      */           break;
/*      */         }
/*      */       } 
/* 2028 */     } catch (EOFException e) {
/*      */ 
/*      */       
/* 2031 */       throw e;
/*      */     } 
/*      */ 
/*      */     
/* 2035 */     if (this.isTruncMode) {
/* 2036 */       this.anbytes += nb - this.nBytes[t];
/*      */ 
/*      */       
/* 2039 */       if (status) {
/* 2040 */         this.nBytes[t] = 0;
/*      */       }
/* 2042 */     } else if (this.nBytes[t] < this.totTileLen[t] - this.totTileHeadLen[t]) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2053 */       boolean stopCount = false;
/*      */       
/* 2055 */       int[] pktHeadLen = new int[this.pktHL.size()];
/* 2056 */       for (int i = this.pktHL.size() - 1; i >= 0; i--) {
/* 2057 */         pktHeadLen[i] = ((Integer)this.pktHL.elementAt(i)).intValue();
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 2062 */       boolean reject = false;
/* 2063 */       for (int l = 0; l < nl; l++) {
/* 2064 */         if (this.cbI != null) {
/* 2065 */           int nc = this.cbI.length;
/*      */           
/* 2067 */           int mres = 0;
/* 2068 */           for (int j = 0; j < nc; j++) {
/* 2069 */             if (this.cbI[j] != null && (this.cbI[j]).length > mres)
/* 2070 */               mres = (this.cbI[j]).length; 
/*      */           } 
/* 2072 */           for (int r = 0; r < mres; r++) {
/*      */ 
/*      */             
/* 2075 */             int msub = 0;
/* 2076 */             for (int k = 0; k < nc; k++) {
/* 2077 */               if (this.cbI[k] != null && this.cbI[k][r] != null && (this.cbI[k][r]).length > msub)
/*      */               {
/* 2079 */                 msub = (this.cbI[k][r]).length; } 
/*      */             } 
/* 2081 */             for (int s = 0; s < msub; s++) {
/*      */               
/* 2083 */               if (r != 0 || s == 0)
/*      */               {
/* 2085 */                 if (r == 0 || s != 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */                   
/* 2090 */                   int mnby = 0;
/* 2091 */                   for (int n = 0; n < nc; n++) {
/* 2092 */                     if (this.cbI[n] != null && this.cbI[n][r] != null && this.cbI[n][r][s] != null && (this.cbI[n][r][s]).length > mnby)
/*      */                     {
/*      */                       
/* 2095 */                       mnby = (this.cbI[n][r][s]).length; } 
/*      */                   } 
/* 2097 */                   for (int m = 0; m < mnby; m++) {
/*      */                     
/* 2099 */                     int mnbx = 0;
/* 2100 */                     for (int i2 = 0; i2 < nc; i2++) {
/* 2101 */                       if (this.cbI[i2] != null && this.cbI[i2][r] != null && this.cbI[i2][r][s] != null && this.cbI[i2][r][s][m] != null && (this.cbI[i2][r][s][m]).length > mnbx)
/*      */                       {
/*      */                         
/* 2104 */                         mnbx = (this.cbI[i2][r][s][m]).length; } 
/*      */                     } 
/* 2106 */                     for (int i1 = 0; i1 < mnbx; i1++) {
/*      */                       
/* 2108 */                       for (int i3 = 0; i3 < nc; i3++) {
/*      */                         
/* 2110 */                         if (this.cbI[i3] != null && this.cbI[i3][r] != null && this.cbI[i3][r][s] != null && this.cbI[i3][r][s][m] != null && this.cbI[i3][r][s][m][i1] != null) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                           
/* 2116 */                           CBlkInfo cb = this.cbI[i3][r][s][m][i1];
/*      */ 
/*      */ 
/*      */                           
/* 2120 */                           if (!reject)
/*      */                           {
/*      */                             
/* 2123 */                             if (this.nBytes[t] < pktHeadLen[cb.pktIdx[l]]) {
/*      */                               
/* 2125 */                               stopCount = true;
/*      */ 
/*      */                               
/* 2128 */                               reject = true;
/*      */ 
/*      */                             
/*      */                             }
/* 2132 */                             else if (!stopCount) {
/*      */ 
/*      */ 
/*      */                               
/* 2136 */                               this.nBytes[t] = this.nBytes[t] - pktHeadLen[cb.pktIdx[l]];
/*      */                               
/* 2138 */                               this.anbytes += pktHeadLen[cb.pktIdx[l]];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                               
/* 2144 */                               pktHeadLen[cb.pktIdx[l]] = 0;
/*      */                             } 
/*      */                           }
/*      */ 
/*      */                           
/* 2149 */                           if (cb.len[l] != 0)
/*      */                           {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                             
/* 2157 */                             if (cb.len[l] < this.nBytes[t] && !reject) {
/*      */                               
/* 2159 */                               this.nBytes[t] = this.nBytes[t] - cb.len[l];
/* 2160 */                               this.anbytes += cb.len[l];
/*      */                             }
/*      */                             else {
/*      */                               
/* 2164 */                               cb.ntp[l] = 0; cb.off[l] = 0; cb.len[l] = 0;
/*      */ 
/*      */                               
/* 2167 */                               reject = true;
/*      */                             }  } 
/*      */                         } 
/*      */                       } 
/*      */                     } 
/*      */                   } 
/*      */                 }  } 
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } else {
/* 2179 */       this.anbytes += this.totTileLen[t] - this.totTileHeadLen[t];
/* 2180 */       if (t < getNumTiles() - 1) {
/* 2181 */         this.nBytes[t + 1] = this.nBytes[t + 1] + this.nBytes[t] - this.totTileLen[t] - this.totTileHeadLen[t];
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2188 */     this.nBytes[t] = oldNBytes;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTile(int x, int y) {
/* 2204 */     if (x < 0 || y < 0 || x >= this.ntX || y >= this.ntY) {
/* 2205 */       throw new IllegalArgumentException();
/*      */     }
/* 2207 */     int t = y * this.ntX + x;
/*      */     try {
/* 2209 */       initTile(t);
/* 2210 */     } catch (IOException ioe) {}
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2215 */     if (t == 0) {
/* 2216 */       this.anbytes = this.headLen;
/* 2217 */       if (!this.isTruncMode) {
/* 2218 */         this.anbytes += 2;
/*      */       }
/*      */       
/* 2221 */       for (int tIdx = 0; tIdx < this.nt; tIdx++) {
/* 2222 */         this.nBytes[tIdx] = this.baknBytes[tIdx];
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 2227 */     this.ctX = x;
/* 2228 */     this.ctY = y;
/*      */     
/* 2230 */     int ctox = (x == 0) ? this.ax : (this.px + x * this.ntW);
/* 2231 */     int ctoy = (y == 0) ? this.ay : (this.py + y * this.ntH);
/* 2232 */     for (int i = this.nc - 1; i >= 0; i--) {
/* 2233 */       this.culx[i] = (ctox + this.hd.getCompSubsX(i) - 1) / this.hd.getCompSubsX(i);
/* 2234 */       this.culy[i] = (ctoy + this.hd.getCompSubsY(i) - 1) / this.hd.getCompSubsY(i);
/* 2235 */       this.offX[i] = (this.px + x * this.ntW + this.hd.getCompSubsX(i) - 1) / this.hd.getCompSubsX(i);
/* 2236 */       this.offY[i] = (this.py + y * this.ntH + this.hd.getCompSubsY(i) - 1) / this.hd.getCompSubsY(i);
/*      */     } 
/*      */ 
/*      */     
/* 2240 */     this.subbTrees = new SubbandSyn[this.nc];
/* 2241 */     this.mdl = new int[this.nc];
/* 2242 */     this.derived = new boolean[this.nc];
/* 2243 */     this.params = new StdDequantizerParams[this.nc];
/* 2244 */     this.gb = new int[this.nc];
/*      */     
/* 2246 */     for (int c = 0; c < this.nc; c++) {
/* 2247 */       this.derived[c] = this.decSpec.qts.isDerived(t, c);
/* 2248 */       this.params[c] = (StdDequantizerParams)this.decSpec.qsss.getTileCompVal(t, c);
/*      */       
/* 2250 */       this.gb[c] = ((Integer)this.decSpec.gbs.getTileCompVal(t, c)).intValue();
/* 2251 */       this.mdl[c] = ((Integer)this.decSpec.dls.getTileCompVal(t, c)).intValue();
/*      */       
/* 2253 */       this.subbTrees[c] = new SubbandSyn(getTileCompWidth(t, c, this.mdl[c]), getTileCompHeight(t, c, this.mdl[c]), getResULX(c, this.mdl[c]), getResULY(c, this.mdl[c]), this.mdl[c], (WaveletFilter[])this.decSpec.wfs.getHFilters(t, c), (WaveletFilter[])this.decSpec.wfs.getVFilters(t, c));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2259 */       initSubbandsFields(c, this.subbTrees[c]);
/*      */     } 
/*      */ 
/*      */     
/*      */     try {
/* 2264 */       readTilePkts(t);
/* 2265 */     } catch (IOException e) {
/* 2266 */       e.printStackTrace();
/* 2267 */       throw new Error("IO Error when reading tile " + x + " x " + y);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void nextTile() {
/* 2278 */     if (this.ctX == this.ntX - 1 && this.ctY == this.ntY - 1) {
/* 2279 */       throw new NoNextElementException();
/*      */     }
/* 2281 */     if (this.ctX < this.ntX - 1) {
/* 2282 */       setTile(this.ctX + 1, this.ctY);
/*      */     } else {
/*      */       
/* 2285 */       setTile(0, this.ctY + 1);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DecLyrdCBlk getCodeBlock(int c, int m, int n, SubbandSyn sb, int fl, int nl, DecLyrdCBlk ccb) {
/*      */     CBlkInfo rcb;
/* 2341 */     int nts, t = getTileIdx();
/*      */     
/* 2343 */     int r = sb.resLvl;
/* 2344 */     int s = sb.sbandIdx;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2349 */     int numLayers = ((Integer)this.decSpec.nls.getTileDef(t)).intValue();
/* 2350 */     int options = ((Integer)this.decSpec.ecopts.getTileCompVal(t, c)).intValue();
/* 2351 */     if (nl < 0) {
/* 2352 */       nl = numLayers - fl + 1;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 2357 */     if (this.lQuit != -1 && fl + nl > this.lQuit) {
/* 2358 */       nl = this.lQuit - fl;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 2363 */     int maxdl = (getSynSubbandTree(t, c)).resLvl;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 2373 */       rcb = this.cbI[c][r][s][m][n];
/*      */       
/* 2375 */       if (fl < 1 || fl > numLayers || fl + nl - 1 > numLayers) {
/* 2376 */         throw new IllegalArgumentException();
/*      */       }
/* 2378 */     } catch (ArrayIndexOutOfBoundsException e) {
/* 2379 */       throw new IllegalArgumentException("Code-block (t:" + t + ", c:" + c + ", r:" + r + ", s:" + s + ", " + m + "x" + n + ") not found in codestream");
/*      */     
/*      */     }
/* 2382 */     catch (NullPointerException e) {
/* 2383 */       throw new IllegalArgumentException("Code-block (t:" + t + ", c:" + c + ", r:" + r + ", s:" + s + ", " + m + "x" + n + ") not found in bit stream");
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2389 */     if (ccb == null) {
/* 2390 */       ccb = new DecLyrdCBlk();
/*      */     }
/* 2392 */     ccb.m = m;
/* 2393 */     ccb.n = n;
/* 2394 */     ccb.nl = 0;
/* 2395 */     ccb.dl = 0;
/* 2396 */     ccb.nTrunc = 0;
/*      */     
/* 2398 */     if (rcb == null) {
/*      */       
/* 2400 */       ccb.skipMSBP = 0;
/* 2401 */       ccb.prog = false;
/* 2402 */       ccb.w = ccb.h = ccb.ulx = ccb.uly = 0;
/* 2403 */       return ccb;
/*      */     } 
/*      */ 
/*      */     
/* 2407 */     ccb.skipMSBP = rcb.msbSkipped;
/* 2408 */     ccb.ulx = rcb.ulx;
/* 2409 */     ccb.uly = rcb.uly;
/* 2410 */     ccb.w = rcb.w;
/* 2411 */     ccb.h = rcb.h;
/* 2412 */     ccb.ftpIdx = 0;
/*      */ 
/*      */ 
/*      */     
/* 2416 */     int l = 0;
/* 2417 */     while (l < rcb.len.length && rcb.len[l] == 0) {
/* 2418 */       ccb.ftpIdx += rcb.ntp[l];
/* 2419 */       l++;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 2424 */     for (l = fl - 1; l < fl + nl - 1; l++) {
/* 2425 */       ccb.nl++;
/* 2426 */       ccb.dl += rcb.len[l];
/* 2427 */       ccb.nTrunc += rcb.ntp[l];
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 2432 */     if ((options & 0x4) != 0) {
/*      */ 
/*      */       
/* 2435 */       nts = ccb.nTrunc - ccb.ftpIdx;
/* 2436 */     } else if ((options & 0x1) != 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2443 */       if (ccb.nTrunc <= 10) {
/* 2444 */         nts = 1;
/*      */       } else {
/* 2446 */         nts = 1;
/*      */         
/* 2448 */         for (int i = ccb.ftpIdx; i < ccb.nTrunc; i++) {
/* 2449 */           if (i >= 9) {
/* 2450 */             int passtype = (i + 2) % 3;
/*      */             
/* 2452 */             if (passtype == 1 || passtype == 2)
/*      */             {
/*      */               
/* 2455 */               nts++;
/*      */             }
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } else {
/*      */       
/* 2462 */       nts = 1;
/*      */     } 
/*      */ 
/*      */     
/* 2466 */     if (ccb.data == null || ccb.data.length < ccb.dl) {
/* 2467 */       ccb.data = new byte[ccb.dl];
/*      */     }
/*      */ 
/*      */     
/* 2471 */     if (nts > 1 && (ccb.tsLengths == null || ccb.tsLengths.length < nts)) {
/* 2472 */       ccb.tsLengths = new int[nts];
/* 2473 */     } else if (nts > 1 && (options & 0x5) == 1) {
/*      */       
/* 2475 */       ArrayUtil.intArraySet(ccb.tsLengths, 0);
/*      */     } 
/*      */ 
/*      */     
/* 2479 */     int dataIdx = -1;
/* 2480 */     int tpidx = ccb.ftpIdx;
/* 2481 */     int ctp = ccb.ftpIdx;
/*      */     
/* 2483 */     int tsidx = 0;
/*      */ 
/*      */     
/* 2486 */     for (l = fl - 1; l < fl + nl - 1; l++) {
/* 2487 */       ctp += rcb.ntp[l];
/*      */       
/* 2489 */       if (rcb.len[l] != 0) {
/*      */ 
/*      */         
/*      */         try {
/*      */ 
/*      */           
/* 2495 */           this.in.seek(rcb.off[l]);
/* 2496 */           this.in.readFully(ccb.data, dataIdx + 1, rcb.len[l]);
/* 2497 */           dataIdx += rcb.len[l];
/* 2498 */         } catch (IOException e) {
/* 2499 */           JJ2KExceptionHandler.handleException(e);
/*      */         } 
/*      */ 
/*      */         
/* 2503 */         if (nts != 1)
/* 2504 */           if ((options & 0x4) != 0) {
/*      */             
/* 2506 */             for (int j = 0; tpidx < ctp; j++, tpidx++) {
/* 2507 */               if (rcb.segLen[l] != null) {
/* 2508 */                 ccb.tsLengths[tsidx++] = rcb.segLen[l][j];
/*      */               } else {
/* 2510 */                 ccb.tsLengths[tsidx++] = rcb.len[l];
/*      */               } 
/*      */             } 
/*      */           } else {
/*      */             int j;
/* 2515 */             for (j = 0; tpidx < ctp; tpidx++) {
/* 2516 */               if (tpidx >= 9) {
/* 2517 */                 int passtype = (tpidx + 2) % 3;
/*      */                 
/* 2519 */                 if (passtype != 0)
/*      */                 {
/*      */ 
/*      */                   
/* 2523 */                   if (rcb.segLen[l] != null) {
/* 2524 */                     ccb.tsLengths[tsidx++] = ccb.tsLengths[tsidx++] + rcb.segLen[l][j++];
/* 2525 */                     rcb.len[l] = rcb.len[l] - rcb.segLen[l][j - 1];
/*      */                   } else {
/* 2527 */                     ccb.tsLengths[tsidx++] = ccb.tsLengths[tsidx++] + rcb.len[l];
/* 2528 */                     rcb.len[l] = 0;
/*      */                   } 
/*      */                 }
/*      */               } 
/*      */             } 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 2537 */             if (rcb.segLen[l] != null && j < (rcb.segLen[l]).length) {
/* 2538 */               ccb.tsLengths[tsidx] = ccb.tsLengths[tsidx] + rcb.segLen[l][j];
/* 2539 */               rcb.len[l] = rcb.len[l] - rcb.segLen[l][j];
/*      */             }
/* 2541 */             else if (tsidx < nts) {
/* 2542 */               ccb.tsLengths[tsidx] = ccb.tsLengths[tsidx] + rcb.len[l];
/* 2543 */               rcb.len[l] = 0;
/*      */             } 
/*      */           }  
/*      */       } 
/*      */     } 
/* 2548 */     if (nts == 1 && ccb.tsLengths != null) {
/* 2549 */       ccb.tsLengths[0] = ccb.dl;
/*      */     }
/*      */ 
/*      */     
/* 2553 */     int lastlayer = fl + nl - 1;
/* 2554 */     if (lastlayer < numLayers - 1) {
/* 2555 */       for (l = lastlayer + 1; l < numLayers; l++) {
/*      */         
/* 2557 */         if (rcb.len[l] != 0) {
/* 2558 */           ccb.prog = true;
/*      */         }
/*      */       } 
/*      */     }
/*      */     
/* 2563 */     return ccb;
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/codestream/reader/FileBitstreamReaderAgent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */