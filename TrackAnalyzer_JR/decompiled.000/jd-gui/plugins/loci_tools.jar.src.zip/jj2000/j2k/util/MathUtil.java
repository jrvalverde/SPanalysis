/*     */ package jj2000.j2k.util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MathUtil
/*     */ {
/*     */   public static int log2(int x) {
/* 102 */     if (x <= 0) {
/* 103 */       throw new IllegalArgumentException("" + x + " <= 0");
/*     */     }
/*     */     
/* 106 */     int v = x;
/* 107 */     int y = -1;
/* 108 */     while (v > 0) {
/* 109 */       v >>= 1;
/* 110 */       y++;
/*     */     } 
/* 112 */     return y;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int lcm(int x1, int x2) {
/*     */     int max;
/*     */     int min;
/* 124 */     if (x1 <= 0 || x2 <= 0) {
/* 125 */       throw new IllegalArgumentException("Cannot compute the least common multiple of two numbers if one, at least,is negative.");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 131 */     if (x1 > x2) {
/* 132 */       max = x1;
/* 133 */       min = x2;
/*     */     } else {
/* 135 */       max = x2;
/* 136 */       min = x1;
/*     */     } 
/* 138 */     for (int i = 1; i <= min; i++) {
/* 139 */       if (max * i % min == 0) {
/* 140 */         return i * max;
/*     */       }
/*     */     } 
/* 143 */     throw new Error("Cannot find the least common multiple of numbers " + x1 + " and " + x2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int lcm(int[] x) {
/* 154 */     if (x.length < 2) {
/* 155 */       throw new Error("Do not use this method if there are less than two numbers.");
/*     */     }
/*     */     
/* 158 */     int tmp = lcm(x[x.length - 1], x[x.length - 2]);
/* 159 */     for (int i = x.length - 3; i >= 0; i--) {
/* 160 */       if (x[i] <= 0) {
/* 161 */         throw new IllegalArgumentException("Cannot compute the least common multiple of several numbers where one, at least,is negative.");
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 167 */       tmp = lcm(tmp, x[i]);
/*     */     } 
/* 169 */     return tmp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int gcd(int x1, int x2) {
/*     */     int a, b;
/* 177 */     if (x1 < 0 || x2 < 0) {
/* 178 */       throw new IllegalArgumentException("Cannot compute the GCD if one integer is negative.");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 183 */     if (x1 > x2) {
/* 184 */       a = x1;
/* 185 */       b = x2;
/*     */     } else {
/* 187 */       a = x2;
/* 188 */       b = x1;
/*     */     } 
/*     */     
/* 191 */     if (b == 0) return 0;
/*     */     
/* 193 */     int g = b;
/* 194 */     while (g != 0) {
/* 195 */       int z = a % g;
/* 196 */       a = g;
/* 197 */       g = z;
/*     */     } 
/* 199 */     return a;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int gcd(int[] x) {
/* 209 */     if (x.length < 2) {
/* 210 */       throw new Error("Do not use this method if there are less than two numbers.");
/*     */     }
/*     */     
/* 213 */     int tmp = gcd(x[x.length - 1], x[x.length - 2]);
/* 214 */     for (int i = x.length - 3; i >= 0; i--) {
/* 215 */       if (x[i] < 0) {
/* 216 */         throw new IllegalArgumentException("Cannot compute the least common multiple of several numbers where one, at least,is negative.");
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 222 */       tmp = gcd(tmp, x[i]);
/*     */     } 
/* 224 */     return tmp;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/util/MathUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */