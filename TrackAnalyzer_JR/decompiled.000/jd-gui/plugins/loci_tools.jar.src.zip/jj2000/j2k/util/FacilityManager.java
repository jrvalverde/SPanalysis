/*     */ package jj2000.j2k.util;
/*     */ 
/*     */ import java.util.Hashtable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FacilityManager
/*     */ {
/* 115 */   private static final Hashtable loggerList = new Hashtable<Object, Object>();
/*     */ 
/*     */   
/* 118 */   private static MsgLogger defMsgLogger = new StreamMsgLogger(System.out, System.err, 78);
/*     */ 
/*     */ 
/*     */   
/* 122 */   private static final Hashtable watchProgList = new Hashtable<Object, Object>();
/*     */ 
/*     */ 
/*     */   
/* 126 */   private static ProgressWatch defWatchProg = null;
/*     */ 
/*     */   
/*     */   public static void registerProgressWatch(Thread t, ProgressWatch pw) {
/* 130 */     if (pw == null) {
/* 131 */       throw new NullPointerException();
/*     */     }
/* 133 */     if (t == null) {
/* 134 */       defWatchProg = pw;
/*     */     } else {
/*     */       
/* 137 */       watchProgList.put(t, pw);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ProgressWatch getProgressWatch() {
/* 147 */     ProgressWatch pw = (ProgressWatch)watchProgList.get(Thread.currentThread());
/*     */     
/* 149 */     return (pw == null) ? defWatchProg : pw;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void registerMsgLogger(Thread t, MsgLogger ml) {
/* 164 */     if (ml == null) {
/* 165 */       throw new NullPointerException();
/*     */     }
/* 167 */     if (t == null) {
/* 168 */       defMsgLogger = ml;
/*     */     } else {
/*     */       
/* 171 */       loggerList.put(t, ml);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MsgLogger getMsgLogger() {
/* 186 */     MsgLogger ml = (MsgLogger)loggerList.get(Thread.currentThread());
/*     */     
/* 188 */     return (ml == null) ? defMsgLogger : ml;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MsgLogger getMsgLogger(Thread t) {
/* 204 */     MsgLogger ml = (MsgLogger)loggerList.get(t);
/*     */     
/* 206 */     return (ml == null) ? defMsgLogger : ml;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/util/FacilityManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */