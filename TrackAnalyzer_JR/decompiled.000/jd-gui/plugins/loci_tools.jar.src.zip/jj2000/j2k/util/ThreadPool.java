/*     */ package jj2000.j2k.util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ThreadPool
/*     */ {
/*     */   public static final String CONCURRENCY_PROP_NAME = "jj2000.j2k.util.ThreadPool.concurrency";
/*     */   private ThreadPoolThread[] idle;
/*     */   private int nidle;
/*     */   private String poolName;
/*     */   private int poolPriority;
/*     */   private volatile Error targetE;
/*     */   private volatile RuntimeException targetRE;
/*     */   
/*     */   class ThreadPoolThread
/*     */     extends Thread
/*     */   {
/*     */     private Runnable target;
/*     */     private Object lock;
/*     */     private boolean doNotifyAll;
/*     */     
/*     */     public ThreadPoolThread(int idx, String name) {
/* 208 */       super(name);
/* 209 */       setDaemon(true);
/* 210 */       setPriority(ThreadPool.this.poolPriority);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void run() {
/* 235 */       ThreadPool.this.putInIdleList(this);
/*     */ 
/*     */ 
/*     */       
/* 239 */       synchronized (this) {
/*     */         
/*     */         while (true) {
/* 242 */           while (this.target == null) {
/*     */             try {
/* 244 */               wait();
/* 245 */             } catch (InterruptedException e) {}
/*     */           } 
/*     */ 
/*     */           
/*     */           try {
/* 250 */             this.target.run();
/* 251 */           } catch (ThreadDeath td) {
/*     */ 
/*     */ 
/*     */             
/* 255 */             FacilityManager.getMsgLogger().printmsg(2, "Thread.stop() called on a ThreadPool thread or ThreadDeath thrown. This is deprecated. Lock-up might occur.");
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 260 */             throw td;
/* 261 */           } catch (Error e) {
/* 262 */             ThreadPool.this.targetE = e;
/* 263 */           } catch (RuntimeException re) {
/* 264 */             ThreadPool.this.targetRE = re;
/* 265 */           } catch (Throwable ue) {
/*     */ 
/*     */ 
/*     */             
/* 269 */             ThreadPool.this.targetRE = new RuntimeException("Unchecked exception thrown by target's run() method in pool " + ThreadPool.this.poolName + ".");
/*     */           } 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 275 */           ThreadPool.this.putInIdleList(this);
/*     */           
/* 277 */           this.target = null;
/* 278 */           if (this.lock != null) {
/* 279 */             synchronized (this.lock) {
/* 280 */               if (this.doNotifyAll) {
/* 281 */                 this.lock.notifyAll();
/*     */               } else {
/*     */                 
/* 284 */                 this.lock.notify();
/*     */               } 
/*     */             } 
/*     */           }
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     synchronized void setTarget(Runnable target, Object lock, boolean notifyAll) {
/* 311 */       this.target = target;
/* 312 */       this.lock = lock;
/* 313 */       this.doNotifyAll = notifyAll;
/*     */       
/* 315 */       notify();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ThreadPool(int size, int priority, String name) {
/* 350 */     if (size <= 0) {
/* 351 */       throw new IllegalArgumentException("Pool must be of positive size");
/*     */     }
/* 353 */     if (priority < 1) {
/* 354 */       this.poolPriority = Thread.currentThread().getPriority();
/*     */     } else {
/*     */       
/* 357 */       this.poolPriority = (priority < 10) ? priority : 10;
/*     */     } 
/*     */     
/* 360 */     if (name == null) {
/* 361 */       this.poolName = "Anonymous ThreadPool";
/*     */     } else {
/*     */       
/* 364 */       this.poolName = name;
/*     */     } 
/*     */ 
/*     */     
/* 368 */     String prop = null;
/*     */     try {
/* 370 */       prop = System.getProperty("jj2000.j2k.util.ThreadPool.concurrency");
/* 371 */     } catch (SecurityException se) {}
/*     */ 
/*     */     
/* 374 */     if (prop != null) {
/*     */       int clevel;
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 380 */         clevel = Integer.parseInt(prop);
/* 381 */         if (clevel < 0) throw new NumberFormatException(); 
/* 382 */       } catch (NumberFormatException e) {
/* 383 */         throw new IllegalArgumentException("Invalid concurrency level in property jj2000.j2k.util.ThreadPool.concurrency");
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 388 */       if (NativeServices.loadLibrary()) {
/*     */         
/* 390 */         FacilityManager.getMsgLogger().printmsg(1, "Changing thread concurrency level from " + NativeServices.getThreadConcurrency() + " to " + clevel + ".");
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 395 */         NativeServices.setThreadConcurrency(clevel);
/*     */       }
/*     */       else {
/*     */         
/* 399 */         FacilityManager.getMsgLogger().printmsg(2, "Native library to set thread concurrency level as specified by the jj2000.j2k.util.ThreadPool.concurrency property not found. Thread concurrency unchanged.");
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 408 */     this.idle = new ThreadPoolThread[size];
/* 409 */     this.nidle = 0;
/*     */ 
/*     */     
/* 412 */     for (int i = 0; i < size; i++) {
/* 413 */       ThreadPoolThread t = new ThreadPoolThread(i, this.poolName + "-" + i);
/* 414 */       t.start();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSize() {
/* 426 */     return this.idle.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean runTarget(Runnable t, Object l) {
/* 451 */     return runTarget(t, l, false, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean runTarget(Runnable t, Object l, boolean async) {
/* 480 */     return runTarget(t, l, async, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean runTarget(Runnable t, Object l, boolean async, boolean notifyAll) {
/* 515 */     ThreadPoolThread runner = getIdle(async);
/*     */     
/* 517 */     if (runner == null) return false;
/*     */     
/* 519 */     runner.setTarget(t, l, notifyAll);
/* 520 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void checkTargetErrors() {
/* 536 */     if (this.targetE != null) throw this.targetE;
/*     */     
/* 538 */     if (this.targetRE != null) throw this.targetRE;
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clearTargetErrors() {
/* 556 */     this.targetE = null;
/* 557 */     this.targetRE = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void putInIdleList(ThreadPoolThread t) {
/* 578 */     synchronized (this.idle) {
/* 579 */       this.idle[this.nidle] = t;
/* 580 */       this.nidle++;
/*     */       
/* 582 */       if (this.nidle == 1) this.idle.notify();
/*     */     
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ThreadPoolThread getIdle(boolean async) {
/* 605 */     synchronized (this.idle) {
/* 606 */       if (async) {
/*     */         
/* 608 */         if (this.nidle == 0) return null;
/*     */       
/*     */       } else {
/*     */         
/* 612 */         while (this.nidle == 0) {
/*     */           try {
/* 614 */             this.idle.wait();
/* 615 */           } catch (InterruptedException e) {
/*     */             
/* 617 */             return null;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/* 622 */       this.nidle--;
/* 623 */       return this.idle[this.nidle];
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/util/ThreadPool.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */