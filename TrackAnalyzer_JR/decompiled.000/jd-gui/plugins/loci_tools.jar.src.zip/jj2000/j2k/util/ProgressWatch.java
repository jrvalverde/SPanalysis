package jj2000.j2k.util;

public interface ProgressWatch {
  void initProgressWatch(int paramInt1, int paramInt2, String paramString);
  
  void updateProgressWatch(int paramInt, String paramString);
  
  void terminateProgressWatch();
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/util/ProgressWatch.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */