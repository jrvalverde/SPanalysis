/*     */ package jj2000.j2k.util;
/*     */ 
/*     */ import java.io.OutputStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.Writer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StreamMsgLogger
/*     */   implements MsgLogger
/*     */ {
/*     */   private PrintWriter out;
/*     */   private PrintWriter err;
/*     */   private MsgPrinter mp;
/*     */   
/*     */   public StreamMsgLogger(OutputStream outstr, OutputStream errstr, int lw) {
/* 123 */     this.out = new PrintWriter(outstr, true);
/* 124 */     this.err = new PrintWriter(errstr, true);
/* 125 */     this.mp = new MsgPrinter(lw);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StreamMsgLogger(Writer outstr, Writer errstr, int lw) {
/* 142 */     this.out = new PrintWriter(outstr, true);
/* 143 */     this.err = new PrintWriter(errstr, true);
/* 144 */     this.mp = new MsgPrinter(lw);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StreamMsgLogger(PrintWriter outstr, PrintWriter errstr, int lw) {
/* 161 */     this.out = outstr;
/* 162 */     this.err = errstr;
/* 163 */     this.mp = new MsgPrinter(lw);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void printmsg(int sev, String msg) {
/*     */     PrintWriter lout;
/*     */     String prefix;
/* 182 */     switch (sev) {
/*     */       case 0:
/* 184 */         prefix = "[LOG]: ";
/* 185 */         lout = this.out;
/*     */         break;
/*     */       case 1:
/* 188 */         prefix = "[INFO]: ";
/* 189 */         lout = this.out;
/*     */         break;
/*     */       case 2:
/* 192 */         prefix = "[WARNING]: ";
/* 193 */         lout = this.err;
/*     */         break;
/*     */       case 3:
/* 196 */         prefix = "[ERROR]: ";
/* 197 */         lout = this.err;
/*     */         break;
/*     */       default:
/* 200 */         throw new IllegalArgumentException("Severity " + sev + " not valid.");
/*     */     } 
/*     */     
/* 203 */     this.mp.print(lout, 0, prefix.length(), prefix + msg);
/* 204 */     lout.flush();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void println(String str, int flind, int ind) {
/* 227 */     this.mp.print(this.out, flind, ind, str);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void flush() {
/* 237 */     this.out.flush();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/util/StreamMsgLogger.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */