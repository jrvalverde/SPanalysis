/*     */ package jj2000.j2k.util;
/*     */ 
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import jj2000.j2k.io.RandomAccessIO;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ISRandomAccessIO
/*     */   implements RandomAccessIO
/*     */ {
/*     */   private InputStream is;
/*     */   private int maxsize;
/*     */   private int inc;
/*     */   private byte[] buf;
/*     */   private int len;
/*     */   private int pos;
/*     */   private boolean complete;
/*     */   
/*     */   public ISRandomAccessIO(InputStream is, int size, int inc, int maxsize) {
/* 160 */     if (size < 0 || inc <= 0 || maxsize <= 0 || is == null) {
/* 161 */       throw new IllegalArgumentException();
/*     */     }
/* 163 */     this.is = is;
/*     */     
/* 165 */     if (size < Integer.MAX_VALUE) size++; 
/* 166 */     this.buf = new byte[size];
/* 167 */     this.inc = inc;
/*     */     
/* 169 */     if (maxsize < Integer.MAX_VALUE) maxsize++; 
/* 170 */     this.maxsize = maxsize;
/* 171 */     this.pos = 0;
/* 172 */     this.len = 0;
/* 173 */     this.complete = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ISRandomAccessIO(InputStream is) {
/* 185 */     this(is, 262144, 262144, 2147483647);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void growBuffer() throws IOException {
/*     */     byte[] newbuf;
/* 200 */     int effinc = this.inc;
/* 201 */     if (this.buf.length + effinc > this.maxsize) effinc = this.maxsize - this.buf.length; 
/* 202 */     if (effinc <= 0) {
/* 203 */       throw new IOException("Reached maximum cache size (" + this.maxsize + ")");
/*     */     }
/*     */     try {
/* 206 */       newbuf = new byte[this.buf.length + this.inc];
/* 207 */     } catch (OutOfMemoryError e) {
/* 208 */       throw new IOException("Out of memory to cache input data");
/*     */     } 
/* 210 */     System.arraycopy(this.buf, 0, newbuf, 0, this.len);
/* 211 */     this.buf = newbuf;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readInput() throws IOException {
/*     */     int k;
/* 229 */     if (this.complete) {
/* 230 */       throw new IllegalArgumentException("Already reached EOF");
/*     */     }
/*     */ 
/*     */     
/* 234 */     int n = 0;
/* 235 */     if (n == 0) n = 1; 
/* 236 */     while (this.len + n > this.buf.length) {
/* 237 */       growBuffer();
/*     */     }
/*     */     
/*     */     do {
/* 241 */       k = this.is.read(this.buf, this.len, n);
/* 242 */       if (k <= 0)
/* 243 */         continue;  this.len += k;
/* 244 */       n -= k;
/*     */     }
/* 246 */     while (n > 0 && k > 0);
/* 247 */     if (k <= 0) {
/* 248 */       this.complete = true;
/* 249 */       this.is = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 260 */     this.buf = null;
/* 261 */     if (!this.complete) {
/* 262 */       this.is.close();
/* 263 */       this.is = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPos() throws IOException {
/* 275 */     return this.pos;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void seek(int off) throws IOException {
/* 295 */     if (this.complete && 
/* 296 */       off > this.len) {
/* 297 */       throw new EOFException();
/*     */     }
/*     */     
/* 300 */     this.pos = off;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int length() throws IOException {
/* 313 */     if (Integer.MAX_VALUE != this.maxsize)
/* 314 */       return this.maxsize - 1; 
/* 315 */     while (!this.complete) {
/* 316 */       readInput();
/*     */     }
/* 318 */     return this.len;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read() throws IOException {
/* 332 */     if (this.pos < this.len) {
/* 333 */       return 0xFF & this.buf[this.pos++];
/*     */     }
/*     */     
/* 336 */     while (!this.complete && this.pos >= this.len) {
/* 337 */       readInput();
/*     */     }
/* 339 */     if (this.pos == this.len)
/* 340 */       throw new EOFException(); 
/* 341 */     if (this.pos > this.len) {
/* 342 */       throw new IOException("Position beyond EOF");
/*     */     }
/* 344 */     return 0xFF & this.buf[this.pos++];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readFully(byte[] b, int off, int n) throws IOException {
/* 367 */     if (this.pos + n <= this.len) {
/* 368 */       System.arraycopy(this.buf, this.pos, b, off, n);
/* 369 */       this.pos += n;
/*     */       
/*     */       return;
/*     */     } 
/* 373 */     while (!this.complete && this.pos + n > this.len) {
/* 374 */       readInput();
/*     */     }
/* 376 */     if (this.pos + n > this.len) {
/* 377 */       throw new EOFException();
/*     */     }
/* 379 */     System.arraycopy(this.buf, this.pos, b, off, n);
/* 380 */     this.pos += n;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getByteOrdering() {
/* 394 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte readByte() throws IOException {
/* 409 */     if (this.pos < this.len) {
/* 410 */       return this.buf[this.pos++];
/*     */     }
/*     */     
/* 413 */     return (byte)read();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int readUnsignedByte() throws IOException {
/* 428 */     if (this.pos < this.len) {
/* 429 */       return 0xFF & this.buf[this.pos++];
/*     */     }
/*     */     
/* 432 */     return read();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public short readShort() throws IOException {
/* 447 */     if (this.pos + 1 < this.len) {
/* 448 */       return (short)(this.buf[this.pos++] << 8 | 0xFF & this.buf[this.pos++]);
/*     */     }
/*     */     
/* 451 */     return (short)(read() << 8 | read());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int readUnsignedShort() throws IOException {
/* 466 */     if (this.pos + 1 < this.len) {
/* 467 */       return (0xFF & this.buf[this.pos++]) << 8 | 0xFF & this.buf[this.pos++];
/*     */     }
/*     */     
/* 470 */     return read() << 8 | read();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int readInt() throws IOException {
/* 485 */     if (this.pos + 3 < this.len) {
/* 486 */       return this.buf[this.pos++] << 24 | (0xFF & this.buf[this.pos++]) << 16 | (0xFF & this.buf[this.pos++]) << 8 | 0xFF & this.buf[this.pos++];
/*     */     }
/*     */ 
/*     */     
/* 490 */     return read() << 24 | read() << 16 | read() << 8 | read();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long readUnsignedInt() throws IOException {
/* 505 */     if (this.pos + 3 < this.len) {
/* 506 */       return 0xFFFFFFFFL & (this.buf[this.pos++] << 24 | (0xFF & this.buf[this.pos++]) << 16 | (0xFF & this.buf[this.pos++]) << 8 | 0xFF & this.buf[this.pos++]);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 511 */     return 0xFFFFFFFFL & (read() << 24 | read() << 16 | read() << 8 | read());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long readLong() throws IOException {
/* 527 */     if (this.pos + 7 < this.len) {
/* 528 */       return this.buf[this.pos++] << 56L | (0xFF & this.buf[this.pos++]) << 48L | (0xFF & this.buf[this.pos++]) << 40L | (0xFF & this.buf[this.pos++]) << 32L | (0xFF & this.buf[this.pos++]) << 24L | (0xFF & this.buf[this.pos++]) << 16L | (0xFF & this.buf[this.pos++]) << 8L | (0xFF & this.buf[this.pos++]);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 538 */     return read() << 56L | read() << 48L | read() << 40L | read() << 32L | read() << 24L | read() << 16L | read() << 8L | read();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float readFloat() throws IOException {
/* 560 */     if (this.pos + 3 < this.len) {
/* 561 */       return Float.intBitsToFloat(this.buf[this.pos++] << 24 | (0xFF & this.buf[this.pos++]) << 16 | (0xFF & this.buf[this.pos++]) << 8 | 0xFF & this.buf[this.pos++]);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 567 */     return Float.intBitsToFloat(read() << 24 | read() << 16 | read() << 8 | read());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double readDouble() throws IOException {
/* 583 */     if (this.pos + 7 < this.len) {
/* 584 */       return Double.longBitsToDouble(this.buf[this.pos++] << 56L | (0xFF & this.buf[this.pos++]) << 48L | (0xFF & this.buf[this.pos++]) << 40L | (0xFF & this.buf[this.pos++]) << 32L | (0xFF & this.buf[this.pos++]) << 24L | (0xFF & this.buf[this.pos++]) << 16L | (0xFF & this.buf[this.pos++]) << 8L | (0xFF & this.buf[this.pos++]));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 594 */     return Double.longBitsToDouble(read() << 56L | read() << 48L | read() << 40L | read() << 32L | read() << 24L | read() << 16L | read() << 8L | read());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int skipBytes(int n) throws IOException {
/* 617 */     if (this.complete && 
/* 618 */       this.pos + n > this.len) {
/* 619 */       throw new EOFException();
/*     */     }
/*     */     
/* 622 */     this.pos += n;
/* 623 */     return n;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void flush() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(int b) throws IOException {
/* 636 */     throw new IOException("read-only");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeByte(int v) throws IOException {
/* 643 */     throw new IOException("read-only");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeShort(int v) throws IOException {
/* 650 */     throw new IOException("read-only");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeInt(int v) throws IOException {
/* 657 */     throw new IOException("read-only");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeLong(long v) throws IOException {
/* 664 */     throw new IOException("read-only");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeFloat(float v) throws IOException {
/* 671 */     throw new IOException("read-only");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeDouble(double v) throws IOException {
/* 678 */     throw new IOException("read-only");
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/util/ISRandomAccessIO.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */