package jj2000.j2k.util;

public interface MsgLogger {
  public static final int LOG = 0;
  
  public static final int INFO = 1;
  
  public static final int WARNING = 2;
  
  public static final int ERROR = 3;
  
  void printmsg(int paramInt, String paramString);
  
  void println(String paramString, int paramInt1, int paramInt2);
  
  void flush();
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/util/MsgLogger.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */