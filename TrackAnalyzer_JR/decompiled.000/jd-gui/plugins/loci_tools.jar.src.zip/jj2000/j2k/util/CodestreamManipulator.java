/*     */ package jj2000.j2k.util;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.Vector;
/*     */ import jj2000.j2k.io.BEBufferedRandomAccessFile;
/*     */ import jj2000.j2k.io.BufferedRandomAccessFile;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CodestreamManipulator
/*     */ {
/*     */   private boolean ppmUsed;
/*     */   private boolean pptUsed;
/*     */   private boolean tempSop;
/*     */   private boolean tempEph;
/*     */   private int nt;
/*     */   private int pptp;
/*     */   private File file;
/* 120 */   private static int TP_HEAD_LEN = 14;
/*     */ 
/*     */   
/* 123 */   private static int MAX_TPSOT = 16;
/*     */ 
/*     */   
/*     */   private int maxtp;
/*     */ 
/*     */   
/* 129 */   private int[] ppt = new int[this.nt];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Integer[] positions;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] mainHeader;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[][][] tileParts;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[][] tileHeaders;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[][][] packetHeaders;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[][][] packetData;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[][][] sopMarkSeg;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CodestreamManipulator(File file, int nt, int pptp, boolean ppm, boolean ppt, boolean tempSop, boolean tempEph) {
/* 173 */     this.file = file;
/* 174 */     this.nt = nt;
/* 175 */     this.pptp = pptp;
/* 176 */     this.ppmUsed = ppm;
/* 177 */     this.pptUsed = ppt;
/* 178 */     this.tempSop = tempSop;
/* 179 */     this.tempEph = tempEph;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int doCodestreamManipulation() throws IOException {
/* 191 */     int addedHeaderBytes = 0;
/* 192 */     this.ppt = new int[this.nt];
/* 193 */     this.tileParts = new byte[this.nt][][];
/* 194 */     this.tileHeaders = new byte[this.nt][];
/* 195 */     this.packetHeaders = new byte[this.nt][][];
/* 196 */     this.packetData = new byte[this.nt][][];
/* 197 */     this.sopMarkSeg = new byte[this.nt][][];
/*     */ 
/*     */     
/* 200 */     if (!this.ppmUsed && !this.pptUsed && this.pptp == 0) {
/* 201 */       return 0;
/*     */     }
/*     */     
/* 204 */     BEBufferedRandomAccessFile fi = new BEBufferedRandomAccessFile(this.file, "rw+");
/*     */     
/* 206 */     addedHeaderBytes -= fi.length();
/*     */ 
/*     */     
/* 209 */     parseAndFind((BufferedRandomAccessFile)fi);
/*     */ 
/*     */     
/* 212 */     readAndBuffer((BufferedRandomAccessFile)fi);
/*     */ 
/*     */     
/* 215 */     fi.close();
/* 216 */     fi = new BEBufferedRandomAccessFile(this.file, "rw");
/*     */ 
/*     */     
/* 219 */     createTileParts();
/*     */ 
/*     */     
/* 222 */     writeNewCodestream((BufferedRandomAccessFile)fi);
/*     */ 
/*     */     
/* 225 */     fi.flush();
/* 226 */     addedHeaderBytes += fi.length();
/* 227 */     fi.close();
/*     */     
/* 229 */     return addedHeaderBytes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void parseAndFind(BufferedRandomAccessFile fi) throws IOException {
/* 242 */     int sop = 0, eph = 0;
/*     */ 
/*     */ 
/*     */     
/* 246 */     Vector<Integer> markPos = new Vector();
/*     */ 
/*     */     
/* 249 */     short marker = (short)fi.readUnsignedShort();
/* 250 */     marker = (short)fi.readUnsignedShort();
/* 251 */     while (marker != -112) {
/* 252 */       int i = fi.getPos();
/* 253 */       int length = fi.readUnsignedShort();
/*     */ 
/*     */ 
/*     */       
/* 257 */       if (marker == -174) {
/* 258 */         int scod = fi.readUnsignedByte();
/* 259 */         if (this.tempSop)
/* 260 */           scod &= 0xFD; 
/* 261 */         if (this.tempEph)
/* 262 */           scod &= 0xFB; 
/* 263 */         fi.seek(i + 2);
/* 264 */         fi.write(scod);
/*     */       } 
/*     */       
/* 267 */       fi.seek(i + length);
/* 268 */       marker = (short)fi.readUnsignedShort();
/*     */     } 
/* 270 */     int pos = fi.getPos();
/* 271 */     fi.seek(pos - 2);
/*     */ 
/*     */     
/* 274 */     for (int t = 0; t < this.nt; t++) {
/*     */       
/* 276 */       fi.readUnsignedShort();
/* 277 */       pos = fi.getPos();
/* 278 */       markPos.addElement(new Integer(fi.getPos()));
/* 279 */       fi.readInt();
/* 280 */       int length = fi.readInt();
/* 281 */       fi.readUnsignedShort();
/* 282 */       int tileEnd = pos + length - 2;
/*     */ 
/*     */       
/* 285 */       marker = (short)fi.readUnsignedShort();
/* 286 */       while (marker != -109) {
/* 287 */         pos = fi.getPos();
/* 288 */         length = fi.readUnsignedShort();
/*     */ 
/*     */ 
/*     */         
/* 292 */         if (marker == -174) {
/* 293 */           int scod = fi.readUnsignedByte();
/* 294 */           if (this.tempSop)
/* 295 */             scod &= 0xFD; 
/* 296 */           if (this.tempEph)
/* 297 */             scod &= 0xFB; 
/* 298 */           fi.seek(pos + 2);
/* 299 */           fi.write(scod);
/*     */         } 
/* 301 */         fi.seek(pos + length);
/* 302 */         marker = (short)fi.readUnsignedShort();
/*     */       } 
/*     */ 
/*     */       
/* 306 */       sop = 0;
/* 307 */       eph = 0;
/*     */       
/* 309 */       int i = fi.getPos();
/* 310 */       while (i < tileEnd) {
/* 311 */         int halfMarker = (short)fi.readUnsignedByte();
/* 312 */         if (halfMarker == 255) {
/* 313 */           marker = (short)((halfMarker << 8) + fi.readUnsignedByte());
/*     */           
/* 315 */           i++;
/* 316 */           if (marker == -111) {
/* 317 */             markPos.addElement(new Integer(fi.getPos()));
/* 318 */             this.ppt[t] = this.ppt[t] + 1;
/* 319 */             sop++;
/* 320 */             fi.skipBytes(4);
/* 321 */             i += 4;
/*     */           } 
/*     */           
/* 324 */           if (marker == -110) {
/* 325 */             markPos.addElement(new Integer(fi.getPos()));
/* 326 */             eph++;
/*     */           } 
/*     */         } 
/* 329 */         i++;
/*     */       } 
/*     */     } 
/* 332 */     markPos.addElement(new Integer(fi.getPos() + 2));
/* 333 */     this.positions = new Integer[markPos.size()];
/* 334 */     markPos.copyInto((Object[])this.positions);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readAndBuffer(BufferedRandomAccessFile fi) throws IOException {
/* 349 */     fi.seek(0);
/* 350 */     int length = this.positions[0].intValue() - 2;
/* 351 */     this.mainHeader = new byte[length];
/* 352 */     fi.readFully(this.mainHeader, 0, length);
/* 353 */     int markIndex = 0;
/*     */     
/* 355 */     for (int t = 0; t < this.nt; t++) {
/* 356 */       int prem = this.ppt[t];
/*     */       
/* 358 */       this.packetHeaders[t] = new byte[prem][];
/* 359 */       this.packetData[t] = new byte[prem][];
/* 360 */       this.sopMarkSeg[t] = new byte[prem][];
/*     */ 
/*     */       
/* 363 */       length = this.positions[markIndex + 1].intValue() - this.positions[markIndex].intValue();
/*     */       
/* 365 */       this.tileHeaders[t] = new byte[length];
/* 366 */       fi.readFully(this.tileHeaders[t], 0, length);
/* 367 */       markIndex++;
/*     */       
/* 369 */       for (int p = 0; p < prem; p++) {
/*     */         
/* 371 */         length = this.positions[markIndex + 1].intValue() - this.positions[markIndex].intValue();
/*     */ 
/*     */         
/* 374 */         if (this.tempSop) {
/* 375 */           length -= 6;
/* 376 */           fi.skipBytes(6);
/*     */         } else {
/*     */           
/* 379 */           length -= 6;
/* 380 */           this.sopMarkSeg[t][p] = new byte[6];
/* 381 */           fi.readFully(this.sopMarkSeg[t][p], 0, 6);
/*     */         } 
/*     */         
/* 384 */         if (!this.tempEph) {
/* 385 */           length += 2;
/*     */         }
/*     */         
/* 388 */         this.packetHeaders[t][p] = new byte[length];
/* 389 */         fi.readFully(this.packetHeaders[t][p], 0, length);
/* 390 */         markIndex++;
/*     */ 
/*     */         
/* 393 */         length = this.positions[markIndex + 1].intValue() - this.positions[markIndex].intValue();
/*     */ 
/*     */         
/* 396 */         length -= 2;
/* 397 */         if (this.tempEph) {
/* 398 */           fi.skipBytes(2);
/*     */         }
/*     */         
/* 401 */         this.packetData[t][p] = new byte[length];
/* 402 */         fi.readFully(this.packetData[t][p], 0, length);
/* 403 */         markIndex++;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void createTileParts() throws IOException {
/* 422 */     ByteArrayOutputStream temp = new ByteArrayOutputStream();
/*     */ 
/*     */ 
/*     */     
/* 426 */     this.tileParts = new byte[this.nt][][];
/* 427 */     this.maxtp = 0;
/*     */     
/* 429 */     for (int t = 0; t < this.nt; t++) {
/*     */ 
/*     */       
/* 432 */       if (this.pptp == 0)
/* 433 */         this.pptp = this.ppt[t]; 
/* 434 */       int prem = this.ppt[t];
/* 435 */       int numTileParts = (int)Math.ceil(prem / this.pptp);
/* 436 */       int numPackets = (this.packetHeaders[t]).length;
/* 437 */       this.maxtp = (numTileParts > this.maxtp) ? numTileParts : this.maxtp;
/* 438 */       this.tileParts[t] = new byte[numTileParts][];
/*     */ 
/*     */       
/* 441 */       int tppStart = 0;
/* 442 */       int pIndex = 0;
/* 443 */       int p = 0;
/* 444 */       int phIndex = 0;
/* 445 */       for (int tilePart = 0; tilePart < numTileParts; tilePart++) {
/*     */ 
/*     */         
/* 448 */         int nomnp = (this.pptp > prem) ? prem : this.pptp;
/* 449 */         int np = nomnp;
/*     */ 
/*     */         
/* 452 */         if (tilePart == 0) {
/*     */           
/* 454 */           temp.write(this.tileHeaders[t], 0, (this.tileHeaders[t]).length - 2);
/*     */         }
/*     */         else {
/*     */           
/* 458 */           temp.write(new byte[TP_HEAD_LEN - 2], 0, TP_HEAD_LEN - 2);
/*     */         } 
/*     */ 
/*     */         
/* 462 */         if (this.pptUsed) {
/* 463 */           int pptLength = 3;
/* 464 */           int pptIndex = 0;
/*     */ 
/*     */           
/* 467 */           p = pIndex;
/* 468 */           while (np > 0) {
/* 469 */             int phLength = (this.packetHeaders[t][p]).length;
/*     */ 
/*     */ 
/*     */             
/* 473 */             if (pptLength + phLength > 65535) {
/* 474 */               temp.write(16777215);
/* 475 */               temp.write(-159);
/* 476 */               temp.write(pptLength >>> 8);
/* 477 */               temp.write(pptLength);
/* 478 */               temp.write(pptIndex++);
/* 479 */               for (int j = pIndex; j < p; j++) {
/* 480 */                 temp.write(this.packetHeaders[t][j], 0, (this.packetHeaders[t][j]).length);
/*     */               }
/*     */               
/* 483 */               pptLength = 3;
/* 484 */               pIndex = p;
/*     */             } 
/* 486 */             pptLength += phLength;
/* 487 */             p++;
/* 488 */             np--;
/*     */           } 
/*     */           
/* 491 */           temp.write(16777215);
/* 492 */           temp.write(-159);
/* 493 */           temp.write(pptLength >>> 8);
/* 494 */           temp.write(pptLength);
/* 495 */           temp.write(pptIndex);
/* 496 */           for (int i = pIndex; i < p; i++)
/*     */           {
/* 498 */             temp.write(this.packetHeaders[t][i], 0, (this.packetHeaders[t][i]).length);
/*     */           }
/*     */         } 
/*     */         
/* 502 */         pIndex = p;
/* 503 */         np = nomnp;
/*     */ 
/*     */         
/* 506 */         temp.write(16777215);
/* 507 */         temp.write(-109);
/*     */ 
/*     */         
/* 510 */         for (p = tppStart; p < tppStart + np; p++) {
/* 511 */           if (!this.tempSop) {
/* 512 */             temp.write(this.sopMarkSeg[t][p], 0, 6);
/*     */           }
/*     */           
/* 515 */           if (!this.ppmUsed && !this.pptUsed) {
/* 516 */             temp.write(this.packetHeaders[t][p], 0, (this.packetHeaders[t][p]).length);
/*     */           }
/*     */ 
/*     */           
/* 520 */           temp.write(this.packetData[t][p], 0, (this.packetData[t][p]).length);
/*     */         } 
/* 522 */         tppStart += np;
/*     */ 
/*     */         
/* 525 */         byte[] tempByteArr = temp.toByteArray();
/* 526 */         this.tileParts[t][tilePart] = tempByteArr;
/* 527 */         int length = temp.size();
/*     */         
/* 529 */         if (tilePart == 0) {
/*     */           
/* 531 */           tempByteArr[6] = (byte)(length >>> 24);
/* 532 */           tempByteArr[7] = (byte)(length >>> 16);
/* 533 */           tempByteArr[8] = (byte)(length >>> 8);
/* 534 */           tempByteArr[9] = (byte)length;
/* 535 */           tempByteArr[10] = 0;
/* 536 */           tempByteArr[11] = (byte)numTileParts;
/*     */         } else {
/*     */           
/* 539 */           tempByteArr[0] = -1;
/* 540 */           tempByteArr[1] = -112;
/* 541 */           tempByteArr[2] = 0;
/* 542 */           tempByteArr[3] = 10;
/* 543 */           tempByteArr[4] = (byte)(t >> 8);
/* 544 */           tempByteArr[5] = (byte)t;
/* 545 */           tempByteArr[6] = (byte)(length >>> 24);
/* 546 */           tempByteArr[7] = (byte)(length >>> 16);
/* 547 */           tempByteArr[8] = (byte)(length >>> 8);
/* 548 */           tempByteArr[9] = (byte)length;
/* 549 */           tempByteArr[10] = (byte)tilePart;
/* 550 */           tempByteArr[11] = (byte)numTileParts;
/*     */         } 
/* 552 */         temp.reset();
/* 553 */         prem -= np;
/*     */       } 
/*     */     } 
/* 556 */     temp.close();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeNewCodestream(BufferedRandomAccessFile fi) throws IOException {
/* 569 */     int numTiles = this.tileParts.length;
/* 570 */     int[][] packetHeaderLengths = new int[numTiles][this.maxtp];
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 575 */     fi.write(this.mainHeader, 0, this.mainHeader.length);
/*     */ 
/*     */     
/* 578 */     if (this.ppmUsed) {
/* 579 */       ByteArrayOutputStream ppmMarkerSegment = new ByteArrayOutputStream();
/*     */ 
/*     */ 
/*     */       
/* 583 */       int ppmIndex = 0;
/*     */ 
/*     */       
/* 586 */       int[] prem = new int[numTiles];
/*     */       
/*     */       int t;
/* 589 */       for (t = 0; t < numTiles; t++) {
/* 590 */         prem[t] = (this.packetHeaders[t]).length;
/*     */       }
/*     */       int i;
/* 593 */       for (i = 0; i < this.maxtp; i++) {
/* 594 */         for (t = 0; t < numTiles; t++) {
/*     */           
/* 596 */           if ((this.tileParts[t]).length > i) {
/* 597 */             int totNumPackets = (this.packetHeaders[t]).length;
/*     */             
/* 599 */             int numPackets = (i == (this.tileParts[t]).length - 1) ? prem[t] : this.pptp;
/*     */ 
/*     */ 
/*     */             
/* 603 */             int pStart = totNumPackets - prem[t];
/* 604 */             int pStop = pStart + numPackets;
/*     */ 
/*     */ 
/*     */             
/* 608 */             for (int p = pStart; p < pStop; p++) {
/* 609 */               packetHeaderLengths[t][i] = packetHeaderLengths[t][i] + (this.packetHeaders[t][p]).length;
/*     */             }
/*     */             
/* 612 */             prem[t] = prem[t] - numPackets;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 618 */       ppmMarkerSegment.write(16777215);
/* 619 */       ppmMarkerSegment.write(-160);
/* 620 */       ppmMarkerSegment.write(0);
/* 621 */       ppmMarkerSegment.write(0);
/* 622 */       ppmMarkerSegment.write(0);
/* 623 */       int ppmLength = 3;
/* 624 */       ppmIndex++;
/*     */ 
/*     */       
/* 627 */       for (t = 0; t < numTiles; t++) {
/* 628 */         prem[t] = (this.packetHeaders[t]).length;
/*     */       }
/*     */       
/* 631 */       for (i = 0; i < this.maxtp; i++) {
/* 632 */         for (t = 0; t < numTiles; t++) {
/*     */           
/* 634 */           if ((this.tileParts[t]).length > i) {
/* 635 */             int totNumPackets = (this.packetHeaders[t]).length;
/*     */ 
/*     */             
/* 638 */             int numPackets = (i == (this.tileParts[t]).length - 1) ? prem[t] : this.pptp;
/*     */ 
/*     */             
/* 641 */             int pStart = totNumPackets - prem[t];
/* 642 */             int pStop = pStart + numPackets;
/*     */ 
/*     */ 
/*     */             
/* 646 */             if (ppmLength + 4 > 65535) {
/*     */               
/* 648 */               byte[] arrayOfByte = ppmMarkerSegment.toByteArray();
/* 649 */               int k = arrayOfByte.length - 2;
/* 650 */               arrayOfByte[2] = (byte)(k >>> 8);
/* 651 */               arrayOfByte[3] = (byte)k;
/* 652 */               fi.write(arrayOfByte, 0, k + 2);
/*     */ 
/*     */               
/* 655 */               ppmMarkerSegment.reset();
/* 656 */               ppmMarkerSegment.write(16777215);
/* 657 */               ppmMarkerSegment.write(-160);
/* 658 */               ppmMarkerSegment.write(0);
/* 659 */               ppmMarkerSegment.write(0);
/* 660 */               ppmMarkerSegment.write(ppmIndex++);
/* 661 */               ppmLength = 3;
/*     */             } 
/*     */ 
/*     */             
/* 665 */             int j = packetHeaderLengths[t][i];
/* 666 */             ppmMarkerSegment.write(j >>> 24);
/* 667 */             ppmMarkerSegment.write(j >>> 16);
/* 668 */             ppmMarkerSegment.write(j >>> 8);
/* 669 */             ppmMarkerSegment.write(j);
/* 670 */             ppmLength += 4;
/*     */ 
/*     */             
/* 673 */             for (int p = pStart; p < pStop; p++) {
/* 674 */               j = (this.packetHeaders[t][p]).length;
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 679 */               if (ppmLength + j > 65535) {
/*     */                 
/* 681 */                 byte[] arrayOfByte = ppmMarkerSegment.toByteArray();
/* 682 */                 j = arrayOfByte.length - 2;
/* 683 */                 arrayOfByte[2] = (byte)(j >>> 8);
/* 684 */                 arrayOfByte[3] = (byte)j;
/* 685 */                 fi.write(arrayOfByte, 0, j + 2);
/*     */ 
/*     */                 
/* 688 */                 ppmMarkerSegment.reset();
/* 689 */                 ppmMarkerSegment.write(16777215);
/* 690 */                 ppmMarkerSegment.write(-160);
/* 691 */                 ppmMarkerSegment.write(0);
/* 692 */                 ppmMarkerSegment.write(0);
/* 693 */                 ppmMarkerSegment.write(ppmIndex++);
/* 694 */                 ppmLength = 3;
/*     */               } 
/*     */ 
/*     */               
/* 698 */               ppmMarkerSegment.write(this.packetHeaders[t][p], 0, (this.packetHeaders[t][p]).length);
/*     */               
/* 700 */               ppmLength += (this.packetHeaders[t][p]).length;
/*     */             } 
/* 702 */             prem[t] = prem[t] - numPackets;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/* 707 */       byte[] temp = ppmMarkerSegment.toByteArray();
/* 708 */       int length = temp.length - 2;
/* 709 */       temp[2] = (byte)(length >>> 8);
/* 710 */       temp[3] = (byte)length;
/* 711 */       fi.write(temp, 0, length + 2);
/*     */     } 
/*     */ 
/*     */     
/* 715 */     for (int tp = 0; tp < this.maxtp; tp++) {
/* 716 */       for (int t = 0; t < this.nt; t++) {
/* 717 */         if ((this.tileParts[t]).length >= tp) {
/* 718 */           byte[] temp = this.tileParts[t][tp];
/* 719 */           int length = temp.length;
/* 720 */           fi.write(temp, 0, length);
/*     */         } 
/*     */       } 
/* 723 */     }  fi.writeShort(-39);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/util/CodestreamManipulator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */