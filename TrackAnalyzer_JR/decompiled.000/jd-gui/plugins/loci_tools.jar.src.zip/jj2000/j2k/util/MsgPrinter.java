/*     */ package jj2000.j2k.util;
/*     */ 
/*     */ import java.io.PrintWriter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MsgPrinter
/*     */ {
/*     */   public int lw;
/*     */   private static final int IS_NEWLINE = -2;
/*     */   private static final int IS_EOS = -1;
/*     */   
/*     */   public MsgPrinter(int linewidth) {
/* 116 */     this.lw = linewidth;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLineWidth() {
/* 127 */     return this.lw;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLineWidth(int linewidth) {
/* 139 */     if (linewidth < 1) {
/* 140 */       throw new IllegalArgumentException();
/*     */     }
/* 142 */     this.lw = linewidth;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void print(PrintWriter out, int flind, int ind, String msg) {
/* 167 */     int start = 0;
/* 168 */     int end = 0;
/* 169 */     int pend = 0;
/* 170 */     int efflw = this.lw - flind;
/* 171 */     int lind = flind;
/* 172 */     while ((end = nextLineEnd(msg, pend)) != -1) {
/* 173 */       if (end == -2) {
/* 174 */         for (int i = 0; i < lind; i++) {
/* 175 */           out.print(" ");
/*     */         }
/* 177 */         out.println(msg.substring(start, pend));
/* 178 */         if (nextWord(msg, pend) == msg.length()) {
/*     */           
/* 180 */           out.println("");
/* 181 */           start = pend;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } else {
/* 186 */         if (efflw > end - pend) {
/* 187 */           efflw -= end - pend;
/* 188 */           pend = end;
/*     */           
/*     */           continue;
/*     */         } 
/* 192 */         for (int i = 0; i < lind; i++) {
/* 193 */           out.print(" ");
/*     */         }
/* 195 */         if (start == pend) {
/*     */           
/* 197 */           out.println(msg.substring(start, end));
/* 198 */           pend = end;
/*     */         } else {
/*     */           
/* 201 */           out.println(msg.substring(start, pend));
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 206 */       lind = ind;
/* 207 */       efflw = this.lw - ind;
/* 208 */       start = nextWord(msg, pend);
/* 209 */       pend = start;
/* 210 */       if (start == -1) {
/*     */         break;
/*     */       }
/*     */     } 
/* 214 */     if (pend != start) {
/* 215 */       for (int i = 0; i < lind; i++) {
/* 216 */         out.print(" ");
/*     */       }
/* 218 */       out.println(msg.substring(start, pend));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int nextLineEnd(String str, int from) {
/* 247 */     int len = str.length();
/* 248 */     char c = Character.MIN_VALUE;
/*     */     
/* 250 */     while (from < len && (c = str.charAt(from)) != '\n' && Character.isWhitespace(c))
/*     */     {
/* 252 */       from++;
/*     */     }
/* 254 */     if (c == '\n') {
/* 255 */       return -2;
/*     */     }
/* 257 */     if (from >= len) {
/* 258 */       return -1;
/*     */     }
/*     */     
/* 261 */     while (from < len && !Character.isWhitespace(str.charAt(from))) {
/* 262 */       from++;
/*     */     }
/* 264 */     return from;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int nextWord(String str, int from) {
/* 289 */     int len = str.length();
/* 290 */     char c = Character.MIN_VALUE;
/*     */     
/* 292 */     while (from < len && (c = str.charAt(from)) != '\n' && Character.isWhitespace(c))
/*     */     {
/* 294 */       from++;
/*     */     }
/* 296 */     if (from >= len) {
/* 297 */       return -1;
/*     */     }
/* 299 */     if (c == '\n') {
/* 300 */       return from + 1;
/*     */     }
/*     */     
/* 303 */     return from;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/util/MsgPrinter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */