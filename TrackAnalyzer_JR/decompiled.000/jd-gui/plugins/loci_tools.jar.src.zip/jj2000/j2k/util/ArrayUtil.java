/*     */ package jj2000.j2k.util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ArrayUtil
/*     */ {
/*     */   public static final int MAX_EL_COPYING = 8;
/*     */   public static final int INIT_EL_COPYING = 4;
/*     */   
/*     */   public static void intArraySet(int[] arr, int val) {
/* 115 */     int len = arr.length;
/*     */     
/* 117 */     if (len < 8) {
/*     */       
/* 119 */       for (int i = len - 1; i >= 0; i--) {
/* 120 */         arr[i] = val;
/*     */       }
/*     */     } else {
/*     */       
/* 124 */       int len2 = len >> 1; int i;
/* 125 */       for (i = 0; i < 4; i++) {
/* 126 */         arr[i] = val;
/*     */       }
/* 128 */       for (; i <= len2; i <<= 1)
/*     */       {
/* 130 */         System.arraycopy(arr, 0, arr, i, i);
/*     */       }
/* 132 */       if (i < len) {
/* 133 */         System.arraycopy(arr, 0, arr, i, len - i);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void byteArraySet(byte[] arr, byte val) {
/* 154 */     int len = arr.length;
/*     */     
/* 156 */     if (len < 8) {
/*     */       
/* 158 */       for (int i = len - 1; i >= 0; i--) {
/* 159 */         arr[i] = val;
/*     */       }
/*     */     } else {
/*     */       
/* 163 */       int len2 = len >> 1; int i;
/* 164 */       for (i = 0; i < 4; i++) {
/* 165 */         arr[i] = val;
/*     */       }
/* 167 */       for (; i <= len2; i <<= 1)
/*     */       {
/* 169 */         System.arraycopy(arr, 0, arr, i, i);
/*     */       }
/* 171 */       if (i < len)
/* 172 */         System.arraycopy(arr, 0, arr, i, len - i); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/util/ArrayUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */