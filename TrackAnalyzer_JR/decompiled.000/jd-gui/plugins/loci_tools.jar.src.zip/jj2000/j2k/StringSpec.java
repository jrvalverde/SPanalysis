/*     */ package jj2000.j2k;
/*     */ 
/*     */ import com.sun.media.imageioimpl.plugins.jpeg2000.J2KImageWriteParamJava;
/*     */ import java.util.StringTokenizer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StringSpec
/*     */   extends ModuleSpec
/*     */ {
/*     */   private String specified;
/*     */   
/*     */   public StringSpec(int nt, int nc, byte type) {
/* 110 */     super(nt, nc, type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StringSpec(int nt, int nc, byte type, String defaultValue, String[] list, J2KImageWriteParamJava wp, String values) {
/* 138 */     super(nt, nc, type);
/* 139 */     this.specified = values;
/*     */     
/* 141 */     boolean recognized = false;
/*     */     
/* 143 */     String param = values;
/*     */     
/* 145 */     if (values == null) {
/* 146 */       for (int i = list.length - 1; i >= 0; i--) {
/* 147 */         if (defaultValue.equalsIgnoreCase(list[i]))
/* 148 */           recognized = true; 
/* 149 */       }  if (!recognized) {
/* 150 */         throw new IllegalArgumentException("Default parameter of option - not recognized: " + defaultValue);
/*     */       }
/*     */       
/* 153 */       setDefault(defaultValue);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 158 */     StringTokenizer stk = new StringTokenizer(this.specified);
/*     */     
/* 160 */     byte curSpecType = 0;
/*     */     
/* 162 */     boolean[] tileSpec = null;
/*     */     
/* 164 */     boolean[] compSpec = null;
/*     */ 
/*     */     
/* 167 */     while (stk.hasMoreTokens()) {
/* 168 */       String word = stk.nextToken();
/*     */       
/* 170 */       if (word.matches("t[0-9]*")) {
/* 171 */         tileSpec = parseIdx(word, this.nTiles);
/* 172 */         if (curSpecType == 1) {
/* 173 */           curSpecType = 3;
/*     */           continue;
/*     */         } 
/* 176 */         curSpecType = 2; continue;
/*     */       } 
/* 178 */       if (word.matches("c[0-9]*")) {
/* 179 */         compSpec = parseIdx(word, this.nComp);
/* 180 */         if (curSpecType == 2) {
/* 181 */           curSpecType = 3;
/*     */           continue;
/*     */         } 
/* 184 */         curSpecType = 1; continue;
/*     */       } 
/* 186 */       recognized = false;
/*     */       int i;
/* 188 */       for (i = list.length - 1; i >= 0; i--) {
/* 189 */         if (word.equalsIgnoreCase(list[i]))
/* 190 */           recognized = true; 
/* 191 */       }  if (!recognized) {
/* 192 */         throw new IllegalArgumentException("Default parameter of option not recognized: " + word);
/*     */       }
/*     */ 
/*     */       
/* 196 */       if (curSpecType == 0) {
/* 197 */         setDefault(word);
/*     */       }
/* 199 */       else if (curSpecType == 2) {
/* 200 */         for (i = tileSpec.length - 1; i >= 0; i--) {
/* 201 */           if (tileSpec[i]) {
/* 202 */             setTileDef(i, word);
/*     */           }
/*     */         } 
/* 205 */       } else if (curSpecType == 1) {
/* 206 */         for (i = compSpec.length - 1; i >= 0; i--) {
/* 207 */           if (compSpec[i]) {
/* 208 */             setCompDef(i, word);
/*     */           }
/*     */         } 
/*     */       } else {
/* 212 */         for (i = tileSpec.length - 1; i >= 0; i--) {
/* 213 */           for (int j = compSpec.length - 1; j >= 0; j--) {
/* 214 */             if (tileSpec[i] && compSpec[j]) {
/* 215 */               setTileCompVal(i, j, word);
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 222 */       curSpecType = 0;
/* 223 */       tileSpec = null;
/* 224 */       compSpec = null;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 229 */     if (getDefault() == null) {
/* 230 */       int ndefspec = 0;
/* 231 */       for (int t = nt - 1; t >= 0; t--) {
/* 232 */         for (int c = nc - 1; c >= 0; c--) {
/* 233 */           if (this.specValType[t][c] == 0) {
/* 234 */             ndefspec++;
/*     */           }
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 241 */       if (ndefspec != 0) {
/* 242 */         param = defaultValue;
/* 243 */         for (int i = list.length - 1; i >= 0; i--) {
/* 244 */           if (param.equalsIgnoreCase(list[i]))
/* 245 */             recognized = true; 
/* 246 */         }  if (!recognized) {
/* 247 */           throw new IllegalArgumentException("Default parameter of option not recognized: " + this.specified);
/*     */         }
/*     */         
/* 250 */         setDefault(param);
/*     */       } else {
/*     */         int c, i;
/*     */ 
/*     */         
/* 255 */         setDefault(getSpec(0, 0));
/* 256 */         switch (this.specValType[0][0]) {
/*     */           case 2:
/* 258 */             for (c = nc - 1; c >= 0; c--) {
/* 259 */               if (this.specValType[0][c] == 2)
/* 260 */                 this.specValType[0][c] = 0; 
/*     */             } 
/* 262 */             this.tileDef[0] = null;
/*     */             break;
/*     */           case 1:
/* 265 */             for (i = nt - 1; i >= 0; i--) {
/* 266 */               if (this.specValType[i][0] == 1)
/* 267 */                 this.specValType[i][0] = 0; 
/*     */             } 
/* 269 */             this.compDef[0] = null;
/*     */             break;
/*     */           case 3:
/* 272 */             this.specValType[0][0] = 0;
/* 273 */             this.tileCompVal.put("t0c0", null);
/*     */             break;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public String getSpecified() {
/* 281 */     return this.specified;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/StringSpec.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */