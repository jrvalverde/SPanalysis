/*     */ package jj2000.j2k;
/*     */ 
/*     */ import java.awt.Point;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModuleSpec
/*     */   implements Cloneable
/*     */ {
/*     */   public static final byte SPEC_TYPE_COMP = 0;
/*     */   public static final byte SPEC_TYPE_TILE = 1;
/*     */   public static final byte SPEC_TYPE_TILE_COMP = 2;
/*     */   public static final byte SPEC_DEF = 0;
/*     */   public static final byte SPEC_COMP_DEF = 1;
/*     */   public static final byte SPEC_TILE_DEF = 2;
/*     */   public static final byte SPEC_TILE_COMP = 3;
/*     */   protected int specType;
/* 133 */   protected int nTiles = 0;
/*     */ 
/*     */   
/* 136 */   protected int nComp = 0;
/*     */ 
/*     */ 
/*     */   
/*     */   protected byte[][] specValType;
/*     */ 
/*     */ 
/*     */   
/* 144 */   protected Object def = null;
/*     */ 
/*     */ 
/*     */   
/* 148 */   protected Object[] compDef = null;
/*     */ 
/*     */ 
/*     */   
/* 152 */   protected Object[] tileDef = null;
/*     */ 
/*     */   
/*     */   protected Hashtable tileCompVal;
/*     */ 
/*     */   
/*     */   protected String specified;
/*     */ 
/*     */ 
/*     */   
/*     */   public ModuleSpec getCopy() {
/* 163 */     return (ModuleSpec)clone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ModuleSpec(int nt, int nc, byte type) {
/* 180 */     this.nTiles = nt;
/* 181 */     this.nComp = nc;
/* 182 */     this.specValType = new byte[nt][nc];
/* 183 */     switch (type) {
/*     */       case 1:
/* 185 */         this.specType = 1;
/*     */         break;
/*     */       case 0:
/* 188 */         this.specType = 0;
/*     */         break;
/*     */       case 2:
/* 191 */         this.specType = 2;
/*     */         break;
/*     */     } 
/*     */   }
/*     */   
/*     */   protected Object clone() {
/*     */     ModuleSpec ms;
/*     */     try {
/* 199 */       ms = (ModuleSpec)super.clone();
/* 200 */     } catch (CloneNotSupportedException e) {
/* 201 */       throw new Error("Error when cloning ModuleSpec instance");
/*     */     } 
/*     */     
/* 204 */     ms.specValType = new byte[this.nTiles][this.nComp]; int t;
/* 205 */     for (t = 0; t < this.nTiles; t++) {
/* 206 */       for (int c = 0; c < this.nComp; c++) {
/* 207 */         ms.specValType[t][c] = this.specValType[t][c];
/*     */       }
/*     */     } 
/*     */     
/* 211 */     if (this.tileDef != null) {
/* 212 */       ms.tileDef = new Object[this.nTiles];
/* 213 */       for (t = 0; t < this.nTiles; t++) {
/* 214 */         ms.tileDef[t] = this.tileDef[t];
/*     */       }
/*     */     } 
/*     */     
/* 218 */     if (this.tileCompVal != null) {
/* 219 */       ms.tileCompVal = new Hashtable<Object, Object>();
/*     */ 
/*     */       
/* 222 */       for (Enumeration<String> e = this.tileCompVal.keys(); e.hasMoreElements(); ) {
/* 223 */         String tmpKey = e.nextElement();
/* 224 */         Object tmpVal = this.tileCompVal.get(tmpKey);
/* 225 */         ms.tileCompVal.put(tmpKey, tmpVal);
/*     */       } 
/*     */     } 
/* 228 */     return ms;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void rotate90(Point anT) {
/* 240 */     byte[][] tmpsvt = new byte[this.nTiles][];
/*     */     
/* 242 */     Point bnT = new Point(anT.y, anT.x);
/* 243 */     for (int by = 0; by < bnT.y; by++) {
/* 244 */       for (int bx = 0; bx < bnT.x; bx++) {
/* 245 */         int ay = bx;
/* 246 */         int ax = bnT.y - by - 1;
/* 247 */         tmpsvt[ay * anT.x + ax] = this.specValType[by * bnT.x + bx];
/*     */       } 
/*     */     } 
/* 250 */     this.specValType = tmpsvt;
/*     */ 
/*     */     
/* 253 */     if (this.tileDef != null) {
/* 254 */       Object[] tmptd = new Object[this.nTiles];
/* 255 */       for (int i = 0; i < bnT.y; i++) {
/* 256 */         for (int bx = 0; bx < bnT.x; bx++) {
/* 257 */           int ay = bx;
/* 258 */           int ax = bnT.y - i - 1;
/* 259 */           tmptd[ay * anT.x + ax] = this.tileDef[i * bnT.x + bx];
/*     */         } 
/*     */       } 
/* 262 */       this.tileDef = tmptd;
/*     */     } 
/*     */ 
/*     */     
/* 266 */     if (this.tileCompVal != null && this.tileCompVal.size() > 0) {
/* 267 */       Hashtable<Object, Object> tmptcv = new Hashtable<Object, Object>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 273 */       for (Enumeration<String> e = this.tileCompVal.keys(); e.hasMoreElements(); ) {
/* 274 */         String tmpKey = e.nextElement();
/* 275 */         Object tmpVal = this.tileCompVal.get(tmpKey);
/* 276 */         int i1 = tmpKey.indexOf('t');
/* 277 */         int i2 = tmpKey.indexOf('c');
/* 278 */         int btIdx = (new Integer(tmpKey.substring(i1 + 1, i2))).intValue();
/* 279 */         int bx = btIdx % bnT.x;
/* 280 */         int i = btIdx / bnT.x;
/* 281 */         int ay = bx;
/* 282 */         int ax = bnT.y - i - 1;
/* 283 */         int atIdx = ax + ay * anT.x;
/* 284 */         tmptcv.put("t" + atIdx + tmpKey.substring(i2), tmpVal);
/*     */       } 
/* 286 */       this.tileCompVal = tmptcv;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefault(Object value) {
/* 294 */     this.def = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getDefault() {
/* 303 */     return this.def;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCompDef(int c, Object value) {
/* 313 */     if (this.specType == 1) {
/* 314 */       String errMsg = "Option whose value is '" + value + "' cannot be " + "specified for components as it is a 'tile only' specific " + "option";
/*     */ 
/*     */       
/* 317 */       throw new Error(errMsg);
/*     */     } 
/* 319 */     if (this.compDef == null)
/* 320 */       this.compDef = new Object[this.nComp]; 
/* 321 */     for (int i = 0; i < this.nTiles; i++) {
/* 322 */       if (this.specValType[i][c] < 1) {
/* 323 */         this.specValType[i][c] = 1;
/*     */       }
/*     */     } 
/* 326 */     this.compDef[c] = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getCompDef(int c) {
/* 341 */     if (this.specType == 1) {
/* 342 */       throw new Error("Illegal use of ModuleSpec class");
/*     */     }
/* 344 */     if (this.compDef == null || this.compDef[c] == null) {
/* 345 */       return getDefault();
/*     */     }
/*     */     
/* 348 */     return this.compDef[c];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTileDef(int t, Object value) {
/* 358 */     if (this.specType == 0) {
/* 359 */       String errMsg = "Option whose value is '" + value + "' cannot be " + "specified for tiles as it is a 'component only' specific " + "option";
/*     */ 
/*     */       
/* 362 */       throw new Error(errMsg);
/*     */     } 
/* 364 */     if (this.tileDef == null)
/* 365 */       this.tileDef = new Object[this.nTiles]; 
/* 366 */     for (int i = 0; i < this.nComp; i++) {
/* 367 */       if (this.specValType[t][i] < 2) {
/* 368 */         this.specValType[t][i] = 2;
/*     */       }
/*     */     } 
/* 371 */     this.tileDef[t] = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getTileDef(int t) {
/* 385 */     if (this.specType == 0) {
/* 386 */       throw new Error("Illegal use of ModuleSpec class");
/*     */     }
/* 388 */     if (this.tileDef == null || this.tileDef[t] == null) {
/* 389 */       return getDefault();
/*     */     }
/*     */     
/* 392 */     return this.tileDef[t];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTileCompVal(int t, int c, Object value) {
/* 403 */     if (this.specType != 2) {
/* 404 */       String errMsg = "Option whose value is '" + value + "' cannot be " + "specified for ";
/*     */       
/* 406 */       switch (this.specType) {
/*     */         case 1:
/* 408 */           errMsg = errMsg + "components as it is a 'tile only' specific option";
/*     */           break;
/*     */         case 0:
/* 411 */           errMsg = errMsg + "tiles as it is a 'component only' specific option";
/*     */           break;
/*     */       } 
/* 414 */       throw new Error(errMsg);
/*     */     } 
/* 416 */     if (this.tileCompVal == null)
/* 417 */       this.tileCompVal = new Hashtable<Object, Object>(); 
/* 418 */     this.specValType[t][c] = 3;
/* 419 */     this.tileCompVal.put("t" + t + "c" + c, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getTileCompVal(int t, int c) {
/* 437 */     if (this.specType != 2) {
/* 438 */       throw new Error("Illegal use of ModuleSpec class");
/*     */     }
/* 440 */     return getSpec(t, c);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object getSpec(int t, int c) {
/* 458 */     switch (this.specValType[t][c]) {
/*     */       case 0:
/* 460 */         return getDefault();
/*     */       case 1:
/* 462 */         return getCompDef(c);
/*     */       case 2:
/* 464 */         return getTileDef(t);
/*     */       case 3:
/* 466 */         return this.tileCompVal.get("t" + t + "c" + c);
/*     */     } 
/* 468 */     throw new IllegalArgumentException("Not recognized spec type");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte getSpecValType(int t, int c) {
/* 480 */     return this.specValType[t][c];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCompSpecified(int c) {
/* 492 */     if (this.compDef == null || this.compDef[c] == null) {
/* 493 */       return false;
/*     */     }
/* 495 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isTileSpecified(int t) {
/* 507 */     if (this.tileDef == null || this.tileDef[t] == null) {
/* 508 */       return false;
/*     */     }
/* 510 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isTileCompSpecified(int t, int c) {
/* 523 */     if (this.tileCompVal == null || this.tileCompVal.get("t" + t + "c" + c) == null) {
/* 524 */       return false;
/*     */     }
/* 526 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final boolean[] parseIdx(String word, int maxIdx) {
/* 552 */     int nChar = word.length();
/* 553 */     char c = word.charAt(0);
/* 554 */     int idx = -1;
/* 555 */     int lastIdx = -1;
/* 556 */     boolean isDash = false;
/*     */     
/* 558 */     boolean[] idxSet = new boolean[maxIdx];
/* 559 */     int i = 1;
/*     */     
/* 561 */     while (i < nChar) {
/* 562 */       c = word.charAt(i);
/* 563 */       if (Character.isDigit(c)) {
/* 564 */         if (idx == -1)
/* 565 */           idx = 0; 
/* 566 */         idx = idx * 10 + c - 48;
/*     */       } else {
/*     */         
/* 569 */         if (idx == -1 || (c != ',' && c != '-')) {
/* 570 */           throw new IllegalArgumentException("Bad construction for parameter: " + word);
/*     */         }
/*     */         
/* 573 */         if (idx < 0 || idx >= maxIdx) {
/* 574 */           throw new IllegalArgumentException("Out of range index in parameter `" + word + "' : " + idx);
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 580 */         if (c == ',') {
/* 581 */           if (isDash) {
/* 582 */             for (int j = lastIdx + 1; j < idx; j++) {
/* 583 */               idxSet[j] = true;
/*     */             }
/*     */           }
/* 586 */           isDash = false;
/*     */         } else {
/*     */           
/* 589 */           isDash = true;
/*     */         } 
/*     */         
/* 592 */         idxSet[idx] = true;
/* 593 */         lastIdx = idx;
/* 594 */         idx = -1;
/*     */       } 
/* 596 */       i++;
/*     */     } 
/*     */ 
/*     */     
/* 600 */     if (idx < 0 || idx >= maxIdx) {
/* 601 */       throw new IllegalArgumentException("Out of range index in parameter `" + word + "' : " + idx);
/*     */     }
/*     */     
/* 604 */     if (isDash)
/* 605 */       for (int j = lastIdx + 1; j < idx; j++) {
/* 606 */         idxSet[j] = true;
/*     */       } 
/* 608 */     idxSet[idx] = true;
/*     */     
/* 610 */     return idxSet;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/ModuleSpec.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */