/*     */ package jj2000.j2k.wavelet.synthesis;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SynWTFilterIntLift5x3
/*     */   extends SynWTFilterInt
/*     */ {
/*     */   public void synthetize_lpf(int[] lowSig, int lowOff, int lowLen, int lowStep, int[] highSig, int highOff, int highLen, int highStep, int[] outSig, int outOff, int outStep) {
/* 152 */     int outLen = lowLen + highLen;
/* 153 */     int iStep = 2 * outStep;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 163 */     int lk = lowOff;
/* 164 */     int hk = highOff;
/* 165 */     int ik = outOff;
/*     */ 
/*     */     
/* 168 */     if (outLen > 1) {
/* 169 */       outSig[ik] = lowSig[lk] - (highSig[hk] + 1 >> 1);
/*     */     } else {
/*     */       
/* 172 */       outSig[ik] = lowSig[lk];
/*     */     } 
/*     */     
/* 175 */     lk += lowStep;
/* 176 */     hk += highStep;
/* 177 */     ik += iStep;
/*     */     
/*     */     int i;
/* 180 */     for (i = 2; i < outLen - 1; i += 2) {
/* 181 */       outSig[ik] = lowSig[lk] - (highSig[hk - highStep] + highSig[hk] + 2 >> 2);
/*     */ 
/*     */       
/* 184 */       lk += lowStep;
/* 185 */       hk += highStep;
/* 186 */       ik += iStep;
/*     */     } 
/*     */ 
/*     */     
/* 190 */     if (outLen % 2 == 1 && outLen > 2) {
/* 191 */       outSig[ik] = lowSig[lk] - (2 * highSig[hk - highStep] + 2 >> 2);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 199 */     hk = highOff;
/* 200 */     ik = outOff + outStep;
/*     */ 
/*     */     
/* 203 */     for (i = 1; i < outLen - 1; i += 2) {
/*     */ 
/*     */       
/* 206 */       outSig[ik] = highSig[hk] + (outSig[ik - outStep] + outSig[ik + outStep] >> 1);
/*     */ 
/*     */       
/* 209 */       hk += highStep;
/* 210 */       ik += iStep;
/*     */     } 
/*     */ 
/*     */     
/* 214 */     if (outLen % 2 == 0 && outLen > 1) {
/* 215 */       outSig[ik] = highSig[hk] + outSig[ik - outStep];
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void synthetize_hpf(int[] lowSig, int lowOff, int lowLen, int lowStep, int[] highSig, int highOff, int highLen, int highStep, int[] outSig, int outOff, int outStep) {
/* 270 */     int outLen = lowLen + highLen;
/* 271 */     int iStep = 2 * outStep;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 281 */     int lk = lowOff;
/* 282 */     int hk = highOff;
/* 283 */     int ik = outOff + outStep;
/*     */     
/*     */     int i;
/* 286 */     for (i = 1; i < outLen - 1; i += 2) {
/* 287 */       outSig[ik] = lowSig[lk] - (highSig[hk] + highSig[hk + highStep] + 2 >> 2);
/*     */ 
/*     */       
/* 290 */       lk += lowStep;
/* 291 */       hk += highStep;
/* 292 */       ik += iStep;
/*     */     } 
/*     */     
/* 295 */     if (outLen > 1 && outLen % 2 == 0)
/*     */     {
/* 297 */       outSig[ik] = lowSig[lk] - (2 * highSig[hk] + 2 >> 2);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 304 */     hk = highOff;
/* 305 */     ik = outOff;
/*     */     
/* 307 */     if (outLen > 1) {
/* 308 */       outSig[ik] = highSig[hk] + outSig[ik + outStep];
/*     */     }
/*     */     else {
/*     */       
/* 312 */       outSig[ik] = highSig[hk] >> 1;
/*     */     } 
/*     */     
/* 315 */     hk += highStep;
/* 316 */     ik += iStep;
/*     */ 
/*     */     
/* 319 */     for (i = 2; i < outLen - 1; i += 2) {
/*     */ 
/*     */       
/* 322 */       outSig[ik] = highSig[hk] + (outSig[ik - outStep] + outSig[ik + outStep] >> 1);
/*     */       
/* 324 */       hk += highStep;
/* 325 */       ik += iStep;
/*     */     } 
/*     */ 
/*     */     
/* 329 */     if (outLen % 2 == 1 && outLen > 1) {
/* 330 */       outSig[ik] = highSig[hk] + outSig[ik - outStep];
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getAnLowNegSupport() {
/* 341 */     return 2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getAnLowPosSupport() {
/* 352 */     return 2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getAnHighNegSupport() {
/* 363 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getAnHighPosSupport() {
/* 374 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSynLowNegSupport() {
/* 387 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSynLowPosSupport() {
/* 400 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSynHighNegSupport() {
/* 413 */     return 2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSynHighPosSupport() {
/* 426 */     return 2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getImplType() {
/* 437 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isReversible() {
/* 448 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSameAsFullWT(int tailOvrlp, int headOvrlp, int inLen) {
/* 480 */     if (inLen % 2 == 0) {
/* 481 */       if (tailOvrlp >= 2 && headOvrlp >= 1) return true; 
/* 482 */       return false;
/*     */     } 
/*     */ 
/*     */     
/* 486 */     if (tailOvrlp >= 2 && headOvrlp >= 2) return true; 
/* 487 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 497 */     return "w5x3 (lifting)";
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/wavelet/synthesis/SynWTFilterIntLift5x3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */