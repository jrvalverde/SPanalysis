/*     */ package jj2000.j2k.wavelet.synthesis;
/*     */ 
/*     */ import jj2000.j2k.ModuleSpec;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SynWTFilterSpec
/*     */   extends ModuleSpec
/*     */ {
/*     */   public SynWTFilterSpec(int nt, int nc, byte type) {
/* 112 */     super(nt, nc, type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getWTDataType(int t, int c) {
/* 129 */     SynWTFilter[][] an = (SynWTFilter[][])getSpec(t, c);
/* 130 */     return an[0][0].getDataType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SynWTFilter[] getHFilters(int t, int c) {
/* 154 */     SynWTFilter[][] an = (SynWTFilter[][])getSpec(t, c);
/* 155 */     return an[0];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SynWTFilter[] getVFilters(int t, int c) {
/* 179 */     SynWTFilter[][] an = (SynWTFilter[][])getSpec(t, c);
/* 180 */     return an[1];
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 185 */     String str = "";
/*     */ 
/*     */     
/* 188 */     str = str + "nTiles=" + this.nTiles + "\nnComp=" + this.nComp + "\n\n";
/*     */     
/* 190 */     for (int t = 0; t < this.nTiles; t++) {
/* 191 */       for (int c = 0; c < this.nComp; c++) {
/* 192 */         SynWTFilter[][] an = (SynWTFilter[][])getSpec(t, c);
/*     */         
/* 194 */         str = str + "(t:" + t + ",c:" + c + ")\n";
/*     */ 
/*     */         
/* 197 */         str = str + "\tH:"; int i;
/* 198 */         for (i = 0; i < (an[0]).length; i++) {
/* 199 */           str = str + " " + an[0][i];
/*     */         }
/* 201 */         str = str + "\n\tV:";
/* 202 */         for (i = 0; i < (an[1]).length; i++)
/* 203 */           str = str + " " + an[1][i]; 
/* 204 */         str = str + "\n";
/*     */       } 
/*     */     } 
/*     */     
/* 208 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isReversible(int t, int c) {
/* 224 */     SynWTFilter[] hfilter = getHFilters(t, c);
/* 225 */     SynWTFilter[] vfilter = getVFilters(t, c);
/*     */ 
/*     */     
/* 228 */     for (int i = hfilter.length - 1; i >= 0; i--) {
/* 229 */       if (!hfilter[i].isReversible() || !vfilter[i].isReversible())
/* 230 */         return false; 
/* 231 */     }  return true;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/wavelet/synthesis/SynWTFilterSpec.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */