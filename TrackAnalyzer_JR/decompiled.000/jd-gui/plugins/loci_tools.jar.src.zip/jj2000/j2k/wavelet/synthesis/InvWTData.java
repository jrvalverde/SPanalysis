package jj2000.j2k.wavelet.synthesis;

public interface InvWTData extends MultiResImgData {
  SubbandSyn getSynSubbandTree(int paramInt1, int paramInt2);
  
  int getCbULX();
  
  int getCbULY();
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/wavelet/synthesis/InvWTData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */