/*     */ package jj2000.j2k.wavelet;
/*     */ 
/*     */ import jj2000.j2k.NotImplementedError;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WTDecompSpec
/*     */ {
/*     */   public static final int WT_DECOMP_DYADIC = 0;
/*     */   public static final int WT_DECOMP_SPACL = 2;
/*     */   public static final int WT_DECOMP_PACKET = 1;
/*     */   public static final byte DEC_SPEC_MAIN_DEF = 0;
/*     */   public static final byte DEC_SPEC_COMP_DEF = 1;
/*     */   public static final byte DEC_SPEC_TILE_DEF = 2;
/*     */   public static final byte DEC_SPEC_TILE_COMP = 3;
/*     */   private byte[] specValType;
/*     */   private int mainDefDecompType;
/*     */   private int mainDefLevels;
/*     */   private int[] compMainDefDecompType;
/*     */   private int[] compMainDefLevels;
/*     */   
/*     */   public WTDecompSpec(int nc, int dec, int lev) {
/* 173 */     this.mainDefDecompType = dec;
/* 174 */     this.mainDefLevels = lev;
/* 175 */     this.specValType = new byte[nc];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMainCompDefDecompType(int n, int dec, int lev) {
/* 194 */     if (dec < 0 && lev < 0) {
/* 195 */       throw new IllegalArgumentException();
/*     */     }
/*     */     
/* 198 */     this.specValType[n] = 1;
/* 199 */     if (this.compMainDefDecompType == null) {
/* 200 */       this.compMainDefDecompType = new int[this.specValType.length];
/* 201 */       this.compMainDefLevels = new int[this.specValType.length];
/*     */     } 
/* 203 */     this.compMainDefDecompType[n] = (dec >= 0) ? dec : this.mainDefDecompType;
/* 204 */     this.compMainDefLevels[n] = (lev >= 0) ? lev : this.mainDefLevels;
/*     */ 
/*     */     
/* 207 */     throw new NotImplementedError("Currently, in JJ2000, all components and tiles must have the same decomposition type and number of levels");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte getDecSpecType(int n) {
/* 230 */     return this.specValType[n];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMainDefDecompType() {
/* 241 */     return this.mainDefDecompType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMainDefLevels() {
/* 252 */     return this.mainDefLevels;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getDecompType(int n) {
/* 270 */     switch (this.specValType[n]) {
/*     */       case 0:
/* 272 */         return this.mainDefDecompType;
/*     */       case 1:
/* 274 */         return this.compMainDefDecompType[n];
/*     */       case 2:
/* 276 */         throw new NotImplementedError();
/*     */       case 3:
/* 278 */         throw new NotImplementedError();
/*     */     } 
/* 280 */     throw new Error("Internal JJ2000 error");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLevels(int n) {
/* 299 */     switch (this.specValType[n]) {
/*     */       case 0:
/* 301 */         return this.mainDefLevels;
/*     */       case 1:
/* 303 */         return this.compMainDefLevels[n];
/*     */       case 2:
/* 305 */         throw new NotImplementedError();
/*     */       case 3:
/* 307 */         throw new NotImplementedError();
/*     */     } 
/* 309 */     throw new Error("Internal JJ2000 error");
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/wavelet/WTDecompSpec.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */