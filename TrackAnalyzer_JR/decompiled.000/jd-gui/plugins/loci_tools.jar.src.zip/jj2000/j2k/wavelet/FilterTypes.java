package jj2000.j2k.wavelet;

public interface FilterTypes {
  public static final int W9X7 = 0;
  
  public static final int W5X3 = 1;
  
  public static final int CUSTOM = -1;
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/wavelet/FilterTypes.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */