/*     */ package jj2000.j2k.wavelet.synthesis;
/*     */ 
/*     */ import java.awt.Point;
/*     */ import jj2000.j2k.decoder.DecoderSpecs;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class InvWTAdapter
/*     */   implements InvWT
/*     */ {
/*     */   protected DecoderSpecs decSpec;
/*     */   protected MultiResImgData mressrc;
/*     */   protected int reslvl;
/*     */   protected int maxImgRes;
/*     */   
/*     */   protected InvWTAdapter(MultiResImgData src, DecoderSpecs decSpec) {
/* 135 */     this.mressrc = src;
/* 136 */     this.decSpec = decSpec;
/* 137 */     this.maxImgRes = decSpec.dls.getMin();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setImgResLevel(int rl) {
/* 161 */     if (rl < 0) {
/* 162 */       throw new IllegalArgumentException("Resolution level index cannot be negative.");
/*     */     }
/*     */     
/* 165 */     this.reslvl = rl;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTileWidth() {
/* 181 */     int tIdx = getTileIdx();
/* 182 */     int rl = 10000;
/*     */     
/* 184 */     int nc = this.mressrc.getNumComps();
/* 185 */     for (int c = 0; c < nc; c++) {
/* 186 */       int mrl = (this.mressrc.getSynSubbandTree(tIdx, c)).resLvl;
/* 187 */       if (mrl < rl) rl = mrl; 
/*     */     } 
/* 189 */     return this.mressrc.getTileWidth(rl);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTileHeight() {
/* 206 */     int tIdx = getTileIdx();
/* 207 */     int rl = 10000;
/*     */     
/* 209 */     int nc = this.mressrc.getNumComps();
/* 210 */     for (int c = 0; c < nc; c++) {
/* 211 */       int mrl = (this.mressrc.getSynSubbandTree(tIdx, c)).resLvl;
/* 212 */       if (mrl < rl) rl = mrl; 
/*     */     } 
/* 214 */     return this.mressrc.getTileHeight(rl);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getNomTileWidth() {
/* 219 */     return this.mressrc.getNomTileWidth();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getNomTileHeight() {
/* 224 */     return this.mressrc.getNomTileHeight();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getImgWidth() {
/* 235 */     return this.mressrc.getImgWidth(this.reslvl);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getImgHeight() {
/* 246 */     return this.mressrc.getImgHeight(this.reslvl);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNumComps() {
/* 255 */     return this.mressrc.getNumComps();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getCompSubsX(int c) {
/* 272 */     return this.mressrc.getCompSubsX(c);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getCompSubsY(int c) {
/* 289 */     return this.mressrc.getCompSubsY(c);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTileCompWidth(int t, int c) {
/* 304 */     int rl = (this.mressrc.getSynSubbandTree(t, c)).resLvl;
/* 305 */     return this.mressrc.getTileCompWidth(t, c, rl);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTileCompHeight(int t, int c) {
/* 324 */     int rl = (this.mressrc.getSynSubbandTree(t, c)).resLvl;
/* 325 */     return this.mressrc.getTileCompHeight(t, c, rl);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getCompImgWidth(int c) {
/* 340 */     int rl = this.decSpec.dls.getMinInComp(c);
/* 341 */     return this.mressrc.getCompImgWidth(c, rl);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getCompImgHeight(int c) {
/* 359 */     int rl = this.decSpec.dls.getMinInComp(c);
/* 360 */     return this.mressrc.getCompImgHeight(c, rl);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTile(int x, int y) {
/* 375 */     this.mressrc.setTile(x, y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void nextTile() {
/* 386 */     this.mressrc.nextTile();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point getTile(Point co) {
/* 401 */     return this.mressrc.getTile(co);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTileIdx() {
/* 413 */     return this.mressrc.getTileIdx();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getCompULX(int c) {
/* 425 */     int tIdx = getTileIdx();
/* 426 */     int rl = (this.mressrc.getSynSubbandTree(tIdx, c)).resLvl;
/* 427 */     return this.mressrc.getResULX(c, rl);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getCompULY(int c) {
/* 439 */     int tIdx = getTileIdx();
/* 440 */     int rl = (this.mressrc.getSynSubbandTree(tIdx, c)).resLvl;
/* 441 */     return this.mressrc.getResULY(c, rl);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getImgULX() {
/* 455 */     return this.mressrc.getImgULX(this.reslvl);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getImgULY() {
/* 469 */     return this.mressrc.getImgULY(this.reslvl);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getTilePartULX() {
/* 474 */     return this.mressrc.getTilePartULX();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getTilePartULY() {
/* 479 */     return this.mressrc.getTilePartULY();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point getNumTiles(Point co) {
/* 494 */     return this.mressrc.getNumTiles(co);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNumTiles() {
/* 505 */     return this.mressrc.getNumTiles();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SubbandSyn getSynSubbandTree(int t, int c) {
/* 516 */     return this.mressrc.getSynSubbandTree(t, c);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/wavelet/synthesis/InvWTAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */