package jj2000.j2k.wavelet;

import jj2000.j2k.image.ImgData;

public interface WaveletTransform extends ImgData {
  public static final int WT_IMPL_LINE = 0;
  
  public static final int WT_IMPL_FULL = 2;
  
  boolean isReversible(int paramInt1, int paramInt2);
  
  int getImplementationType(int paramInt);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/wavelet/WaveletTransform.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */