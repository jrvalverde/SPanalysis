/*     */ package jj2000.j2k.wavelet;
/*     */ 
/*     */ import java.awt.Point;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Subband
/*     */ {
/*     */   public static final int WT_ORIENT_LL = 0;
/*     */   public static final int WT_ORIENT_HL = 1;
/*     */   public static final int WT_ORIENT_LH = 2;
/*     */   public static final int WT_ORIENT_HH = 3;
/*     */   public boolean isNode;
/*     */   public int orientation;
/*     */   public int level;
/*     */   public int resLvl;
/* 147 */   public Point numCb = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int anGainExp;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 178 */   public int sbandIdx = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int ulcx;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int ulcy;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int ulx;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int uly;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int w;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int h;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int nomCBlkW;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int nomCBlkH;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract Subband getParent();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract Subband getLL();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract Subband getHL();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract Subband getLH();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract Subband getHH();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract Subband split(WaveletFilter paramWaveletFilter1, WaveletFilter paramWaveletFilter2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initChilds() {
/* 280 */     Subband subb_LL = getLL();
/* 281 */     Subband subb_HL = getHL();
/* 282 */     Subband subb_LH = getLH();
/* 283 */     Subband subb_HH = getHH();
/*     */ 
/*     */     
/* 286 */     this.level++;
/* 287 */     subb_LL.ulcx = this.ulcx + 1 >> 1;
/* 288 */     subb_LL.ulcy = this.ulcy + 1 >> 1;
/* 289 */     subb_LL.ulx = this.ulx;
/* 290 */     subb_LL.uly = this.uly;
/* 291 */     subb_LL.w = (this.ulcx + this.w + 1 >> 1) - subb_LL.ulcx;
/* 292 */     subb_LL.h = (this.ulcy + this.h + 1 >> 1) - subb_LL.ulcy;
/*     */ 
/*     */     
/* 295 */     subb_LL.resLvl = (this.orientation == 0) ? (this.resLvl - 1) : this.resLvl;
/* 296 */     subb_LL.anGainExp = this.anGainExp;
/* 297 */     this.sbandIdx <<= 2;
/*     */     
/* 299 */     subb_HL.orientation = 1;
/* 300 */     subb_HL.level = subb_LL.level;
/* 301 */     this.ulcx >>= 1;
/* 302 */     subb_HL.ulcy = subb_LL.ulcy;
/* 303 */     this.ulx += subb_LL.w;
/* 304 */     subb_HL.uly = this.uly;
/* 305 */     subb_HL.w = (this.ulcx + this.w >> 1) - subb_HL.ulcx;
/* 306 */     subb_HL.h = subb_LL.h;
/* 307 */     subb_HL.resLvl = this.resLvl;
/* 308 */     this.anGainExp++;
/* 309 */     subb_HL.sbandIdx = (this.sbandIdx << 2) + 1;
/*     */     
/* 311 */     subb_LH.orientation = 2;
/* 312 */     subb_LH.level = subb_LL.level;
/* 313 */     subb_LH.ulcx = subb_LL.ulcx;
/* 314 */     this.ulcy >>= 1;
/* 315 */     subb_LH.ulx = this.ulx;
/* 316 */     this.uly += subb_LL.h;
/* 317 */     subb_LH.w = subb_LL.w;
/* 318 */     subb_LH.h = (this.ulcy + this.h >> 1) - subb_LH.ulcy;
/* 319 */     subb_LH.resLvl = this.resLvl;
/* 320 */     this.anGainExp++;
/* 321 */     subb_LH.sbandIdx = (this.sbandIdx << 2) + 2;
/*     */     
/* 323 */     subb_HH.orientation = 3;
/* 324 */     subb_HH.level = subb_LL.level;
/* 325 */     subb_HH.ulcx = subb_HL.ulcx;
/* 326 */     subb_HH.ulcy = subb_LH.ulcy;
/* 327 */     subb_HH.ulx = subb_HL.ulx;
/* 328 */     subb_HH.uly = subb_LH.uly;
/* 329 */     subb_HH.w = subb_HL.w;
/* 330 */     subb_HH.h = subb_LH.h;
/* 331 */     subb_HH.resLvl = this.resLvl;
/* 332 */     this.anGainExp += 2;
/* 333 */     subb_HH.sbandIdx = (this.sbandIdx << 2) + 3;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Subband() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Subband(int w, int h, int ulcx, int ulcy, int lvls, WaveletFilter[] hfilters, WaveletFilter[] vfilters) {
/* 387 */     this.w = w;
/* 388 */     this.h = h;
/* 389 */     this.ulcx = ulcx;
/* 390 */     this.ulcy = ulcy;
/* 391 */     this.resLvl = lvls;
/*     */     
/* 393 */     Subband cur = this;
/* 394 */     for (int i = 0; i < lvls; i++) {
/* 395 */       int hi = (cur.resLvl <= hfilters.length) ? (cur.resLvl - 1) : (hfilters.length - 1);
/*     */       
/* 397 */       int vi = (cur.resLvl <= vfilters.length) ? (cur.resLvl - 1) : (vfilters.length - 1);
/*     */       
/* 399 */       cur = cur.split(hfilters[hi], vfilters[vi]);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Subband nextSubband() {
/*     */     Subband sb;
/* 415 */     if (this.isNode) {
/* 416 */       throw new IllegalArgumentException();
/*     */     }
/*     */     
/* 419 */     switch (this.orientation) {
/*     */       case 0:
/* 421 */         sb = getParent();
/* 422 */         if (sb == null || sb.resLvl != this.resLvl)
/*     */         {
/* 424 */           return null;
/*     */         }
/*     */         
/* 427 */         return sb.getHL();
/*     */       
/*     */       case 1:
/* 430 */         return getParent().getLH();
/*     */       case 2:
/* 432 */         return getParent().getHH();
/*     */       
/*     */       case 3:
/* 435 */         sb = this;
/* 436 */         while (sb.orientation == 3) {
/* 437 */           sb = sb.getParent();
/*     */         }
/* 439 */         switch (sb.orientation) {
/*     */           case 0:
/* 441 */             sb = sb.getParent();
/* 442 */             if (sb == null || sb.resLvl != this.resLvl)
/*     */             {
/* 444 */               return null;
/*     */             }
/*     */             
/* 447 */             sb = sb.getHL();
/*     */             break;
/*     */           
/*     */           case 1:
/* 451 */             sb = sb.getParent().getLH();
/*     */             break;
/*     */           case 2:
/* 454 */             sb = sb.getParent().getHH();
/*     */             break;
/*     */           default:
/* 457 */             throw new Error("You have found a bug in JJ2000");
/*     */         } 
/* 459 */         while (sb.isNode) {
/* 460 */           sb = sb.getLL();
/*     */         }
/* 462 */         return sb;
/*     */     } 
/* 464 */     throw new Error("You have found a bug in JJ2000");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Subband getNextResLevel() {
/* 478 */     if (this.level == 0) {
/* 479 */       return null;
/*     */     }
/*     */     
/* 482 */     Subband sb = this;
/*     */     do {
/* 484 */       sb = sb.getParent();
/* 485 */       if (sb == null) {
/* 486 */         return null;
/*     */       }
/* 488 */     } while (sb.resLvl == this.resLvl);
/*     */     
/* 490 */     sb = sb.getHL();
/*     */     
/* 492 */     while (sb.isNode) {
/* 493 */       sb = sb.getLL();
/*     */     }
/* 495 */     return sb;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Subband getSubbandByIdx(int rl, int sbi) {
/* 507 */     Subband sb = this;
/*     */ 
/*     */     
/* 510 */     if (rl > sb.resLvl || rl < 0) {
/* 511 */       throw new IllegalArgumentException("Resolution level index out of range");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 516 */     if (rl == sb.resLvl && sbi == sb.sbandIdx) return sb;
/*     */     
/* 518 */     if (sb.sbandIdx != 0) sb = sb.getParent();
/*     */     
/* 520 */     for (; sb.resLvl > rl; sb = sb.getLL());
/* 521 */     for (; sb.resLvl < rl; sb = sb.getParent());
/*     */     
/* 523 */     switch (sbi)
/*     */     
/*     */     { default:
/* 526 */         return sb;
/*     */       case 1:
/* 528 */         return sb.getHL();
/*     */       case 2:
/* 530 */         return sb.getLH();
/*     */       case 3:
/* 532 */         break; }  return sb.getHH();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Subband getSubband(int x, int y) {
/* 550 */     if (x < this.ulx || y < this.uly || x >= this.ulx + this.w || y >= this.uly + this.h) {
/* 551 */       throw new IllegalArgumentException();
/*     */     }
/*     */     
/* 554 */     Subband cur = this;
/* 555 */     while (cur.isNode) {
/* 556 */       Subband hhs = cur.getHH();
/*     */       
/* 558 */       if (x < hhs.ulx) {
/*     */         
/* 560 */         if (y < hhs.uly) {
/*     */           
/* 562 */           cur = cur.getLL();
/*     */           continue;
/*     */         } 
/* 565 */         cur = cur.getLH();
/*     */         
/*     */         continue;
/*     */       } 
/* 569 */       if (y < hhs.uly) {
/*     */         
/* 571 */         cur = cur.getHL();
/*     */         continue;
/*     */       } 
/* 574 */       cur = cur.getHH();
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 579 */     return cur;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 589 */     String string = "w=" + this.w + ", h=" + this.h + ", ulx=" + this.ulx + ", uly=" + this.uly + ", ulcx= " + this.ulcx + ", ulcy=" + this.ulcy + ", idx=" + this.sbandIdx + "\norient=" + this.orientation + ", node=" + this.isNode + ", level=" + this.level + ", resLvl=" + this.resLvl + ", nomCBlkW=" + this.nomCBlkW + ", nomCBlkH=" + this.nomCBlkH;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 596 */     return string;
/*     */   }
/*     */   
/*     */   public abstract WaveletFilter getHorWFilter();
/*     */   
/*     */   public abstract WaveletFilter getVerWFilter();
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/wavelet/Subband.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */