/*     */ package jj2000.j2k.wavelet.analysis;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnWTFilterFloatLift9x7
/*     */   extends AnWTFilterFloat
/*     */ {
/* 104 */   private static final float[] LPSynthesisFilter = new float[] { -0.091272F, -0.057544F, 0.591272F, 1.115087F, 0.591272F, -0.057544F, -0.091272F };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 109 */   private static final float[] HPSynthesisFilter = new float[] { 0.026749F, 0.016864F, -0.078223F, -0.266864F, 0.602949F, -0.266864F, -0.078223F, 0.016864F, 0.026749F };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final float ALPHA = -1.5861343F;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final float BETA = -0.052980117F;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final float GAMMA = 0.8829111F;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final float DELTA = 0.44356853F;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final float KL = 0.8128931F;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final float KH = 1.2301741F;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void analyze_lpf(float[] inSig, int inOff, int inLen, int inStep, float[] lowSig, int lowOff, int lowStep, float[] highSig, int highOff, int highStep) {
/* 184 */     int iStep = 2 * inStep;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 192 */     int ik = inOff + inStep;
/* 193 */     int lk = lowOff;
/* 194 */     int hk = highOff;
/*     */     
/*     */     int i, maxi;
/* 197 */     for (i = 1, maxi = inLen - 1; i < maxi; i += 2) {
/* 198 */       highSig[hk] = inSig[ik] + -1.5861343F * (inSig[ik - inStep] + inSig[ik + inStep]);
/*     */ 
/*     */       
/* 201 */       ik += iStep;
/* 202 */       hk += highStep;
/*     */     } 
/*     */ 
/*     */     
/* 206 */     if (inLen % 2 == 0) {
/* 207 */       highSig[hk] = inSig[ik] + -3.1722686F * inSig[ik - inStep];
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 213 */     ik = inOff;
/* 214 */     lk = lowOff;
/* 215 */     hk = highOff;
/*     */     
/* 217 */     if (inLen > 1) {
/* 218 */       lowSig[lk] = inSig[ik] + -0.105960235F * highSig[hk];
/*     */     } else {
/*     */       
/* 221 */       lowSig[lk] = inSig[ik];
/*     */     } 
/*     */     
/* 224 */     ik += iStep;
/* 225 */     lk += lowStep;
/* 226 */     hk += highStep;
/*     */ 
/*     */     
/* 229 */     for (i = 2, maxi = inLen - 1; i < maxi; i += 2) {
/* 230 */       lowSig[lk] = inSig[ik] + -0.052980117F * (highSig[hk - highStep] + highSig[hk]);
/*     */ 
/*     */       
/* 233 */       ik += iStep;
/* 234 */       lk += lowStep;
/* 235 */       hk += highStep;
/*     */     } 
/*     */ 
/*     */     
/* 239 */     if (inLen % 2 == 1 && inLen > 2) {
/* 240 */       lowSig[lk] = inSig[ik] + -0.105960235F * highSig[hk - highStep];
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 246 */     lk = lowOff;
/* 247 */     hk = highOff;
/*     */ 
/*     */     
/* 250 */     for (i = 1, maxi = inLen - 1; i < maxi; i += 2) {
/* 251 */       highSig[hk] = highSig[hk] + 0.8829111F * (lowSig[lk] + lowSig[lk + lowStep]);
/*     */       
/* 253 */       lk += lowStep;
/* 254 */       hk += highStep;
/*     */     } 
/*     */ 
/*     */     
/* 258 */     if (inLen % 2 == 0) {
/* 259 */       highSig[hk] = highSig[hk] + 1.7658222F * lowSig[lk];
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 265 */     lk = lowOff;
/* 266 */     hk = highOff;
/*     */ 
/*     */ 
/*     */     
/* 270 */     if (inLen > 1) {
/* 271 */       lowSig[lk] = lowSig[lk] + 0.88713706F * highSig[hk];
/*     */     }
/*     */     
/* 274 */     lk += lowStep;
/* 275 */     hk += highStep;
/*     */ 
/*     */     
/* 278 */     for (i = 2, maxi = inLen - 1; i < maxi; i += 2) {
/* 279 */       lowSig[lk] = lowSig[lk] + 0.44356853F * (highSig[hk - highStep] + highSig[hk]);
/*     */ 
/*     */       
/* 282 */       lk += lowStep;
/* 283 */       hk += highStep;
/*     */     } 
/*     */ 
/*     */     
/* 287 */     if (inLen % 2 == 1 && inLen > 2) {
/* 288 */       lowSig[lk] = lowSig[lk] + 0.88713706F * highSig[hk - highStep];
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 294 */     lk = lowOff;
/* 295 */     hk = highOff;
/*     */ 
/*     */     
/* 298 */     for (i = 0; i < inLen >> 1; i++) {
/* 299 */       lowSig[lk] = lowSig[lk] * 0.8128931F;
/* 300 */       highSig[hk] = highSig[hk] * 1.2301741F;
/* 301 */       lk += lowStep;
/* 302 */       hk += highStep;
/*     */     } 
/*     */ 
/*     */     
/* 306 */     if (inLen % 2 == 1 && inLen != 1) {
/* 307 */       lowSig[lk] = lowSig[lk] * 0.8128931F;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void analyze_hpf(float[] inSig, int inOff, int inLen, int inStep, float[] lowSig, int lowOff, int lowStep, float[] highSig, int highOff, int highStep) {
/* 365 */     int iStep = 2 * inStep;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 373 */     int ik = inOff;
/* 374 */     int lk = lowOff;
/* 375 */     int hk = highOff;
/*     */     
/* 377 */     if (inLen > 1) {
/*     */       
/* 379 */       highSig[hk] = inSig[ik] + -3.1722686F * inSig[ik + inStep];
/*     */     }
/*     */     else {
/*     */       
/* 383 */       highSig[hk] = inSig[ik] * 2.0F;
/*     */     } 
/*     */     
/* 386 */     ik += iStep;
/* 387 */     hk += highStep;
/*     */     
/*     */     int i;
/* 390 */     for (i = 2; i < inLen - 1; i += 2) {
/* 391 */       highSig[hk] = inSig[ik] + -1.5861343F * (inSig[ik - inStep] + inSig[ik + inStep]);
/*     */       
/* 393 */       ik += iStep;
/* 394 */       hk += highStep;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 399 */     if (inLen % 2 == 1 && inLen > 1) {
/* 400 */       highSig[hk] = inSig[ik] + -3.1722686F * inSig[ik - inStep];
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 407 */     ik = inOff + inStep;
/* 408 */     lk = lowOff;
/* 409 */     hk = highOff;
/*     */ 
/*     */ 
/*     */     
/* 413 */     for (i = 1; i < inLen - 1; i += 2) {
/* 414 */       lowSig[lk] = inSig[ik] + -0.052980117F * (highSig[hk] + highSig[hk + highStep]);
/*     */ 
/*     */       
/* 417 */       ik += iStep;
/* 418 */       lk += lowStep;
/* 419 */       hk += highStep;
/*     */     } 
/* 421 */     if (inLen > 1 && inLen % 2 == 0)
/*     */     {
/* 423 */       lowSig[lk] = inSig[ik] + -0.105960235F * highSig[hk];
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 429 */     lk = lowOff;
/* 430 */     hk = highOff;
/*     */     
/* 432 */     if (inLen > 1)
/*     */     {
/* 434 */       highSig[hk] = highSig[hk] + 1.7658222F * lowSig[lk];
/*     */     }
/*     */     
/* 437 */     hk += highStep;
/*     */ 
/*     */     
/* 440 */     for (i = 2; i < inLen - 1; i += 2) {
/* 441 */       highSig[hk] = highSig[hk] + 0.8829111F * (lowSig[lk] + lowSig[lk + lowStep]);
/* 442 */       lk += lowStep;
/* 443 */       hk += highStep;
/*     */     } 
/*     */ 
/*     */     
/* 447 */     if (inLen > 1 && inLen % 2 == 1)
/*     */     {
/* 449 */       highSig[hk] = highSig[hk] + 1.7658222F * lowSig[lk];
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 455 */     lk = lowOff;
/* 456 */     hk = highOff;
/*     */ 
/*     */     
/* 459 */     for (i = 1; i < inLen - 1; i += 2) {
/* 460 */       lowSig[lk] = lowSig[lk] + 0.44356853F * (highSig[hk] + highSig[hk + highStep]);
/* 461 */       lk += lowStep;
/* 462 */       hk += highStep;
/*     */     } 
/*     */     
/* 465 */     if (inLen > 1 && inLen % 2 == 0) {
/* 466 */       lowSig[lk] = lowSig[lk] + 0.88713706F * highSig[hk];
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 472 */     lk = lowOff;
/* 473 */     hk = highOff;
/*     */ 
/*     */     
/* 476 */     for (i = 0; i < inLen >> 1; i++) {
/* 477 */       lowSig[lk] = lowSig[lk] * 0.8128931F;
/* 478 */       highSig[hk] = highSig[hk] * 1.2301741F;
/* 479 */       lk += lowStep;
/* 480 */       hk += highStep;
/*     */     } 
/*     */ 
/*     */     
/* 484 */     if (inLen % 2 == 1 && inLen != 1) {
/* 485 */       highSig[hk] = highSig[hk] * 1.2301741F;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getAnLowNegSupport() {
/* 497 */     return 4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getAnLowPosSupport() {
/* 509 */     return 4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getAnHighNegSupport() {
/* 521 */     return 3;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getAnHighPosSupport() {
/* 533 */     return 3;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSynLowNegSupport() {
/* 547 */     return 3;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSynLowPosSupport() {
/* 561 */     return 3;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSynHighNegSupport() {
/* 575 */     return 4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSynHighPosSupport() {
/* 589 */     return 4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float[] getLPSynthesisFilter() {
/* 607 */     return LPSynthesisFilter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float[] getHPSynthesisFilter() {
/* 626 */     return HPSynthesisFilter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getImplType() {
/* 637 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isReversible() {
/* 648 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSameAsFullWT(int tailOvrlp, int headOvrlp, int inLen) {
/* 683 */     if (inLen % 2 == 0) {
/* 684 */       if (tailOvrlp >= 4 && headOvrlp >= 3) return true; 
/* 685 */       return false;
/*     */     } 
/*     */ 
/*     */     
/* 689 */     if (tailOvrlp >= 4 && headOvrlp >= 4) return true; 
/* 690 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 706 */     return (obj == this || obj instanceof AnWTFilterFloatLift9x7);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFilterType() {
/* 719 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 724 */     return "w9x7";
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/wavelet/analysis/AnWTFilterFloatLift9x7.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */