/*     */ package jj2000.j2k.wavelet.synthesis;
/*     */ 
/*     */ import java.awt.Point;
/*     */ import jj2000.j2k.decoder.DecoderSpecs;
/*     */ import jj2000.j2k.image.DataBlk;
/*     */ import jj2000.j2k.image.DataBlkFloat;
/*     */ import jj2000.j2k.image.DataBlkInt;
/*     */ import jj2000.j2k.util.FacilityManager;
/*     */ import jj2000.j2k.util.ProgressWatch;
/*     */ import jj2000.j2k.wavelet.Subband;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InvWTFull
/*     */   extends InverseWT
/*     */ {
/* 119 */   private ProgressWatch pw = null;
/*     */ 
/*     */   
/* 122 */   private int cblkToDecode = 0;
/*     */ 
/*     */   
/* 125 */   private int nDecCblk = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private CBlkWTDataSrcDec src;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int dtype;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private DataBlk[] reconstructedComps;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int[] ndl;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean[][] reversible;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InvWTFull(CBlkWTDataSrcDec src, DecoderSpecs decSpec) {
/* 160 */     super(src, decSpec);
/* 161 */     this.src = src;
/*     */     
/* 163 */     int nc = src.getNumComps();
/* 164 */     this.reconstructedComps = new DataBlk[nc];
/* 165 */     this.ndl = new int[nc];
/* 166 */     this.pw = FacilityManager.getProgressWatch();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isSubbandReversible(Subband subband) {
/* 181 */     if (subband.isNode)
/*     */     {
/*     */       
/* 184 */       return (isSubbandReversible(subband.getLL()) && isSubbandReversible(subband.getHL()) && isSubbandReversible(subband.getLH()) && isSubbandReversible(subband.getHH()) && ((SubbandSyn)subband).hFilter.isReversible() && ((SubbandSyn)subband).vFilter.isReversible());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 194 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isReversible(int t, int c) {
/* 211 */     if (this.reversible[t] == null) {
/*     */       
/* 213 */       this.reversible[t] = new boolean[getNumComps()];
/* 214 */       for (int i = this.reversible.length - 1; i >= 0; i--) {
/* 215 */         this.reversible[t][i] = isSubbandReversible(this.src.getSynSubbandTree(t, i));
/*     */       }
/*     */     } 
/*     */     
/* 219 */     return this.reversible[t][c];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNomRangeBits(int c) {
/* 243 */     return this.src.getNomRangeBits(c);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFixedPoint(int c) {
/* 265 */     return this.src.getFixedPoint(c);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final DataBlk getInternCompData(DataBlk blk, int c) {
/*     */     DataBlkFloat dataBlkFloat;
/* 295 */     int tIdx = getTileIdx();
/* 296 */     if (this.src.getSynSubbandTree(tIdx, c).getHorWFilter() == null) {
/* 297 */       this.dtype = 3;
/*     */     } else {
/* 299 */       this.dtype = this.src.getSynSubbandTree(tIdx, c).getHorWFilter().getDataType();
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 304 */     if (this.reconstructedComps[c] == null) {
/*     */       
/* 306 */       switch (this.dtype) {
/*     */         case 4:
/* 308 */           this.reconstructedComps[c] = (DataBlk)new DataBlkFloat(0, 0, getTileCompWidth(tIdx, c), getTileCompHeight(tIdx, c));
/*     */           break;
/*     */ 
/*     */         
/*     */         case 3:
/* 313 */           this.reconstructedComps[c] = (DataBlk)new DataBlkInt(0, 0, getTileCompWidth(tIdx, c), getTileCompHeight(tIdx, c));
/*     */           break;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 319 */       waveletTreeReconstruction(this.reconstructedComps[c], this.src.getSynSubbandTree(tIdx, c), c);
/*     */       
/* 321 */       if (this.pw != null && c == this.src.getNumComps() - 1) {
/* 322 */         this.pw.terminateProgressWatch();
/*     */       }
/*     */     } 
/*     */     
/* 326 */     if (blk.getDataType() != this.dtype) {
/* 327 */       DataBlkInt dataBlkInt; if (this.dtype == 3) {
/* 328 */         dataBlkInt = new DataBlkInt(blk.ulx, blk.uly, blk.w, blk.h);
/*     */       } else {
/* 330 */         dataBlkFloat = new DataBlkFloat(((DataBlk)dataBlkInt).ulx, ((DataBlk)dataBlkInt).uly, ((DataBlk)dataBlkInt).w, ((DataBlk)dataBlkInt).h);
/*     */       } 
/*     */     } 
/*     */     
/* 334 */     dataBlkFloat.setData(this.reconstructedComps[c].getData());
/* 335 */     ((DataBlk)dataBlkFloat).offset = (this.reconstructedComps[c]).w * ((DataBlk)dataBlkFloat).uly + ((DataBlk)dataBlkFloat).ulx;
/* 336 */     ((DataBlk)dataBlkFloat).scanw = (this.reconstructedComps[c]).w;
/* 337 */     ((DataBlk)dataBlkFloat).progressive = false;
/* 338 */     return (DataBlk)dataBlkFloat;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DataBlk getCompData(DataBlk blk, int c) {
/*     */     int[] dst_data_int;
/*     */     float[] dst_data_float;
/* 381 */     Object dst_data = null;
/*     */ 
/*     */     
/* 384 */     switch (blk.getDataType()) {
/*     */       case 3:
/* 386 */         dst_data_int = (int[])blk.getData();
/* 387 */         if (dst_data_int == null || dst_data_int.length < blk.w * blk.h) {
/* 388 */           dst_data_int = new int[blk.w * blk.h];
/*     */         }
/* 390 */         dst_data = dst_data_int;
/*     */         break;
/*     */       case 4:
/* 393 */         dst_data_float = (float[])blk.getData();
/* 394 */         if (dst_data_float == null || dst_data_float.length < blk.w * blk.h) {
/* 395 */           dst_data_float = new float[blk.w * blk.h];
/*     */         }
/* 397 */         dst_data = dst_data_float;
/*     */         break;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 403 */     blk = getInternCompData(blk, c);
/*     */ 
/*     */     
/* 406 */     blk.setData(dst_data);
/* 407 */     blk.offset = 0;
/* 408 */     blk.scanw = blk.w;
/* 409 */     return blk;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void wavelet2DReconstruction(DataBlk db, SubbandSyn sb, int c) {
/*     */     int j, data_int[], buf_int[];
/*     */     float[] data_float, buf_float;
/* 431 */     if (sb.w == 0 || sb.h == 0) {
/*     */       return;
/*     */     }
/*     */     
/* 435 */     Object data = db.getData();
/*     */     
/* 437 */     int ulx = sb.ulx;
/* 438 */     int uly = sb.uly;
/* 439 */     int w = sb.w;
/* 440 */     int h = sb.h;
/*     */     
/* 442 */     Object buf = null;
/*     */     
/* 444 */     switch (sb.getHorWFilter().getDataType()) {
/*     */       case 3:
/* 446 */         buf = new int[(w >= h) ? w : h];
/*     */         break;
/*     */       case 4:
/* 449 */         buf = new float[(w >= h) ? w : h];
/*     */         break;
/*     */     } 
/*     */ 
/*     */     
/* 454 */     int offset = (uly - db.uly) * db.w + ulx - db.ulx;
/* 455 */     if (sb.ulcx % 2 == 0) {
/* 456 */       for (int i = 0; i < h; i++, offset += db.w) {
/* 457 */         System.arraycopy(data, offset, buf, 0, w);
/* 458 */         sb.hFilter.synthetize_lpf(buf, 0, (w + 1) / 2, 1, buf, (w + 1) / 2, w / 2, 1, data, offset, 1);
/*     */       } 
/*     */     } else {
/*     */       
/* 462 */       for (int i = 0; i < h; i++, offset += db.w) {
/* 463 */         System.arraycopy(data, offset, buf, 0, w);
/* 464 */         sb.hFilter.synthetize_hpf(buf, 0, w / 2, 1, buf, w / 2, (w + 1) / 2, 1, data, offset, 1);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 470 */     offset = (uly - db.uly) * db.w + ulx - db.ulx;
/* 471 */     switch (sb.getVerWFilter().getDataType()) {
/*     */       
/*     */       case 3:
/* 474 */         data_int = (int[])data;
/* 475 */         buf_int = (int[])buf;
/* 476 */         if (sb.ulcy % 2 == 0) {
/* 477 */           for (int i = 0; i < w; i++, offset++) {
/* 478 */             int k; for (int m = h - 1; m >= 0; m--, k -= db.w)
/* 479 */               buf_int[m] = data_int[k]; 
/* 480 */             sb.vFilter.synthetize_lpf(buf, 0, (h + 1) / 2, 1, buf, (h + 1) / 2, h / 2, 1, data, offset, db.w);
/*     */           } 
/*     */           break;
/*     */         } 
/* 484 */         for (j = 0; j < w; j++, offset++) {
/* 485 */           int k; for (int i = h - 1; i >= 0; i--, k -= db.w)
/* 486 */             buf_int[i] = data_int[k]; 
/* 487 */           sb.vFilter.synthetize_hpf(buf, 0, h / 2, 1, buf, h / 2, (h + 1) / 2, 1, data, offset, db.w);
/*     */         } 
/*     */         break;
/*     */ 
/*     */ 
/*     */       
/*     */       case 4:
/* 494 */         data_float = (float[])data;
/* 495 */         buf_float = (float[])buf;
/* 496 */         if (sb.ulcy % 2 == 0) {
/* 497 */           for (j = 0; j < w; j++, offset++) {
/* 498 */             int k; for (int i = h - 1; i >= 0; i--, k -= db.w)
/* 499 */               buf_float[i] = data_float[k]; 
/* 500 */             sb.vFilter.synthetize_lpf(buf, 0, (h + 1) / 2, 1, buf, (h + 1) / 2, h / 2, 1, data, offset, db.w);
/*     */           } 
/*     */           break;
/*     */         } 
/* 504 */         for (j = 0; j < w; j++, offset++) {
/* 505 */           int k; for (int i = h - 1; i >= 0; i--, k -= db.w)
/* 506 */             buf_float[i] = data_float[k]; 
/* 507 */           sb.vFilter.synthetize_hpf(buf, 0, h / 2, 1, buf, h / 2, (h + 1) / 2, 1, data, offset, db.w);
/*     */         } 
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void waveletTreeReconstruction(DataBlk img, SubbandSyn sb, int c) {
/* 533 */     if (!sb.isNode) {
/*     */       DataBlkFloat dataBlkFloat;
/*     */ 
/*     */ 
/*     */       
/* 538 */       if (sb.w == 0 || sb.h == 0) {
/*     */         return;
/*     */       }
/*     */ 
/*     */       
/* 543 */       if (this.dtype == 3) {
/* 544 */         DataBlkInt dataBlkInt = new DataBlkInt();
/*     */       } else {
/* 546 */         dataBlkFloat = new DataBlkFloat();
/*     */       } 
/* 548 */       Point ncblks = sb.numCb;
/* 549 */       Object dst_data = img.getData();
/* 550 */       for (int m = 0; m < ncblks.y; m++) {
/* 551 */         for (int n = 0; n < ncblks.x; n++) {
/* 552 */           DataBlk dataBlk = this.src.getInternCodeBlock(c, m, n, sb, (DataBlk)dataBlkFloat);
/* 553 */           Object src_data = dataBlk.getData();
/* 554 */           if (this.pw != null) {
/* 555 */             this.nDecCblk++;
/* 556 */             this.pw.updateProgressWatch(this.nDecCblk, null);
/*     */           } 
/*     */           
/* 559 */           for (int i = dataBlk.h - 1; i >= 0; i--) {
/* 560 */             System.arraycopy(src_data, dataBlk.offset + i * dataBlk.scanw, dst_data, (dataBlk.uly + i) * img.w + dataBlk.ulx, dataBlk.w);
/*     */           
/*     */           }
/*     */         }
/*     */       
/*     */       }
/*     */     
/*     */     }
/* 568 */     else if (sb.isNode) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 573 */       waveletTreeReconstruction(img, (SubbandSyn)sb.getLL(), c);
/*     */       
/* 575 */       if (sb.resLvl <= this.reslvl - this.maxImgRes + this.ndl[c]) {
/*     */         
/* 577 */         waveletTreeReconstruction(img, (SubbandSyn)sb.getHL(), c);
/* 578 */         waveletTreeReconstruction(img, (SubbandSyn)sb.getLH(), c);
/* 579 */         waveletTreeReconstruction(img, (SubbandSyn)sb.getHH(), c);
/*     */ 
/*     */         
/* 582 */         wavelet2DReconstruction(img, sb, c);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getImplementationType(int c) {
/* 598 */     return 2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTile(int x, int y) {
/* 614 */     super.setTile(x, y);
/*     */     
/* 616 */     int nc = this.src.getNumComps();
/* 617 */     int tIdx = this.src.getTileIdx();
/* 618 */     for (int c = 0; c < nc; c++) {
/* 619 */       this.ndl[c] = (this.src.getSynSubbandTree(tIdx, c)).resLvl;
/*     */     }
/*     */ 
/*     */     
/* 623 */     if (this.reconstructedComps != null) {
/* 624 */       for (int j = this.reconstructedComps.length - 1; j >= 0; j--) {
/* 625 */         this.reconstructedComps[j] = null;
/*     */       }
/*     */     }
/*     */     
/* 629 */     this.cblkToDecode = 0;
/*     */     
/* 631 */     for (int i = 0; i < nc; i++) {
/* 632 */       SubbandSyn root = this.src.getSynSubbandTree(tIdx, i);
/* 633 */       for (int r = 0; r <= this.reslvl - this.maxImgRes + root.resLvl; r++) {
/* 634 */         if (r == 0) {
/* 635 */           SubbandSyn sb = (SubbandSyn)root.getSubbandByIdx(0, 0);
/* 636 */           if (sb != null) this.cblkToDecode += sb.numCb.x * sb.numCb.y; 
/*     */         } else {
/* 638 */           SubbandSyn sb = (SubbandSyn)root.getSubbandByIdx(r, 1);
/* 639 */           if (sb != null) this.cblkToDecode += sb.numCb.x * sb.numCb.y; 
/* 640 */           sb = (SubbandSyn)root.getSubbandByIdx(r, 2);
/* 641 */           if (sb != null) this.cblkToDecode += sb.numCb.x * sb.numCb.y; 
/* 642 */           sb = (SubbandSyn)root.getSubbandByIdx(r, 3);
/* 643 */           if (sb != null) this.cblkToDecode += sb.numCb.x * sb.numCb.y; 
/*     */         } 
/*     */       } 
/*     */     } 
/* 647 */     this.nDecCblk = 0;
/*     */     
/* 649 */     if (this.pw != null) {
/* 650 */       this.pw.initProgressWatch(0, this.cblkToDecode, "Decoding tile " + tIdx + "...");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void nextTile() {
/* 663 */     super.nextTile();
/*     */     
/* 665 */     int nc = this.src.getNumComps();
/* 666 */     int tIdx = this.src.getTileIdx();
/* 667 */     for (int c = 0; c < nc; c++) {
/* 668 */       this.ndl[c] = (this.src.getSynSubbandTree(tIdx, c)).resLvl;
/*     */     }
/*     */ 
/*     */     
/* 672 */     if (this.reconstructedComps != null)
/* 673 */       for (int i = this.reconstructedComps.length - 1; i >= 0; i--)
/* 674 */         this.reconstructedComps[i] = null;  
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/wavelet/synthesis/InvWTFull.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */