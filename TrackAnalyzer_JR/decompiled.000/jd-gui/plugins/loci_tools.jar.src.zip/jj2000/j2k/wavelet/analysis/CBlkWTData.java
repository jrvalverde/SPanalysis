/*     */ package jj2000.j2k.wavelet.analysis;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class CBlkWTData
/*     */ {
/*     */   public int ulx;
/*     */   public int uly;
/*     */   public int n;
/*     */   public int m;
/*     */   public SubbandAn sb;
/*     */   public int w;
/*     */   public int h;
/*     */   public int offset;
/*     */   public int scanw;
/*     */   public int magbits;
/* 154 */   public float wmseScaling = 1.0F;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 160 */   public double convertFactor = 1.0D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 166 */   public double stepSize = 1.0D;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 171 */   public int nROIcoeff = 0;
/*     */ 
/*     */   
/* 174 */   public int nROIbp = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract int getDataType();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract Object getData();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void setData(Object paramObject);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 229 */     String typeString = "";
/* 230 */     switch (getDataType()) {
/*     */       case 0:
/* 232 */         typeString = "Unsigned Byte";
/*     */         break;
/*     */       case 1:
/* 235 */         typeString = "Short";
/*     */         break;
/*     */       case 3:
/* 238 */         typeString = "Integer";
/*     */         break;
/*     */       case 4:
/* 241 */         typeString = "Float";
/*     */         break;
/*     */     } 
/*     */     
/* 245 */     return "CBlkWTData: ulx= " + this.ulx + ", uly= " + this.uly + ", code-block(" + this.m + "," + this.n + "), width= " + this.w + ", height= " + this.h + ", offset= " + this.offset + ", scan-width=" + this.scanw + ", type= " + typeString + ", sb= " + this.sb + ", num. ROI coeff=" + this.nROIcoeff + ", num. ROI bit-planes=" + this.nROIbp;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/wavelet/analysis/CBlkWTData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */