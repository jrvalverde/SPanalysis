package jj2000.j2k.wavelet.synthesis;

import java.awt.Point;

public interface MultiResImgData {
  int getTileWidth(int paramInt);
  
  int getTileHeight(int paramInt);
  
  int getNomTileWidth();
  
  int getNomTileHeight();
  
  int getImgWidth(int paramInt);
  
  int getImgHeight(int paramInt);
  
  int getNumComps();
  
  int getCompSubsX(int paramInt);
  
  int getCompSubsY(int paramInt);
  
  int getTileCompWidth(int paramInt1, int paramInt2, int paramInt3);
  
  int getTileCompHeight(int paramInt1, int paramInt2, int paramInt3);
  
  int getCompImgWidth(int paramInt1, int paramInt2);
  
  int getCompImgHeight(int paramInt1, int paramInt2);
  
  void setTile(int paramInt1, int paramInt2);
  
  void nextTile();
  
  Point getTile(Point paramPoint);
  
  int getTileIdx();
  
  int getResULX(int paramInt1, int paramInt2);
  
  int getResULY(int paramInt1, int paramInt2);
  
  int getImgULX(int paramInt);
  
  int getImgULY(int paramInt);
  
  int getTilePartULX();
  
  int getTilePartULY();
  
  Point getNumTiles(Point paramPoint);
  
  int getNumTiles();
  
  SubbandSyn getSynSubbandTree(int paramInt1, int paramInt2);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/wavelet/synthesis/MultiResImgData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */