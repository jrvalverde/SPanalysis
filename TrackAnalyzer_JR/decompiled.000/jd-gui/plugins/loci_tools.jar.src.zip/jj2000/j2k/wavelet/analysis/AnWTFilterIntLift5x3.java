/*     */ package jj2000.j2k.wavelet.analysis;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnWTFilterIntLift5x3
/*     */   extends AnWTFilterInt
/*     */ {
/* 103 */   private static final float[] LPSynthesisFilter = new float[] { 0.5F, 1.0F, 0.5F };
/*     */ 
/*     */ 
/*     */   
/* 107 */   private static final float[] HPSynthesisFilter = new float[] { -0.125F, -0.25F, 0.75F, -0.25F, -0.125F };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void analyze_lpf(int[] inSig, int inOff, int inLen, int inStep, int[] lowSig, int lowOff, int lowStep, int[] highSig, int highOff, int highStep) {
/* 155 */     int iStep = 2 * inStep;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 165 */     int ik = inOff + inStep;
/* 166 */     int hk = highOff;
/*     */     
/*     */     int i;
/* 169 */     for (i = 1; i < inLen - 1; i += 2) {
/* 170 */       highSig[hk] = inSig[ik] - (inSig[ik - inStep] + inSig[ik + inStep] >> 1);
/*     */ 
/*     */       
/* 173 */       ik += iStep;
/* 174 */       hk += highStep;
/*     */     } 
/*     */ 
/*     */     
/* 178 */     if (inLen % 2 == 0) {
/* 179 */       highSig[hk] = inSig[ik] - (2 * inSig[ik - inStep] >> 1);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 187 */     ik = inOff;
/* 188 */     int lk = lowOff;
/* 189 */     hk = highOff;
/*     */     
/* 191 */     if (inLen > 1) {
/* 192 */       lowSig[lk] = inSig[ik] + (highSig[hk] + 1 >> 1);
/*     */     } else {
/*     */       
/* 195 */       lowSig[lk] = inSig[ik];
/*     */     } 
/*     */     
/* 198 */     ik += iStep;
/* 199 */     lk += lowStep;
/* 200 */     hk += highStep;
/*     */ 
/*     */     
/* 203 */     for (i = 2; i < inLen - 1; i += 2) {
/* 204 */       lowSig[lk] = inSig[ik] + (highSig[hk - highStep] + highSig[hk] + 2 >> 2);
/*     */ 
/*     */       
/* 207 */       ik += iStep;
/* 208 */       lk += lowStep;
/* 209 */       hk += highStep;
/*     */     } 
/*     */ 
/*     */     
/* 213 */     if (inLen % 2 == 1 && 
/* 214 */       inLen > 2) {
/* 215 */       lowSig[lk] = inSig[ik] + (2 * highSig[hk - highStep] + 2 >> 2);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void analyze_hpf(int[] inSig, int inOff, int inLen, int inStep, int[] lowSig, int lowOff, int lowStep, int[] highSig, int highOff, int highStep) {
/* 267 */     int iStep = 2 * inStep;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 277 */     int ik = inOff;
/* 278 */     int hk = highOff;
/*     */     
/* 280 */     if (inLen > 1) {
/*     */       
/* 282 */       highSig[hk] = inSig[ik] - inSig[ik + inStep];
/*     */     }
/*     */     else {
/*     */       
/* 286 */       highSig[hk] = inSig[ik] << 1;
/*     */     } 
/*     */     
/* 289 */     ik += iStep;
/* 290 */     hk += highStep;
/*     */ 
/*     */     
/* 293 */     if (inLen > 3) {
/* 294 */       for (int j = 2; j < inLen - 1; j += 2) {
/* 295 */         highSig[hk] = inSig[ik] - (inSig[ik - inStep] + inSig[ik + inStep] >> 1);
/*     */         
/* 297 */         ik += iStep;
/* 298 */         hk += highStep;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 304 */     if (inLen % 2 == 1 && inLen > 1) {
/* 305 */       highSig[hk] = inSig[ik] - inSig[ik - inStep];
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 313 */     ik = inOff + inStep;
/* 314 */     int lk = lowOff;
/* 315 */     hk = highOff;
/*     */     
/* 317 */     for (int i = 1; i < inLen - 1; i += 2) {
/*     */       
/* 319 */       lowSig[lk] = inSig[ik] + (highSig[hk] + highSig[hk + highStep] + 2 >> 2);
/*     */ 
/*     */       
/* 322 */       ik += iStep;
/* 323 */       lk += lowStep;
/* 324 */       hk += highStep;
/*     */     } 
/*     */     
/* 327 */     if (inLen > 1 && inLen % 2 == 0)
/*     */     {
/* 329 */       lowSig[lk] = inSig[ik] + (2 * highSig[hk] + 2 >> 2);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getAnLowNegSupport() {
/* 340 */     return 2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getAnLowPosSupport() {
/* 351 */     return 2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getAnHighNegSupport() {
/* 362 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getAnHighPosSupport() {
/* 373 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSynLowNegSupport() {
/* 386 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSynLowPosSupport() {
/* 399 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSynHighNegSupport() {
/* 412 */     return 2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSynHighPosSupport() {
/* 425 */     return 2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float[] getLPSynthesisFilter() {
/* 441 */     return LPSynthesisFilter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float[] getHPSynthesisFilter() {
/* 457 */     return HPSynthesisFilter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getImplType() {
/* 469 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isReversible() {
/* 480 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSameAsFullWT(int tailOvrlp, int headOvrlp, int inLen) {
/* 512 */     if (inLen % 2 == 0) {
/* 513 */       if (tailOvrlp >= 2 && headOvrlp >= 1) return true; 
/* 514 */       return false;
/*     */     } 
/*     */ 
/*     */     
/* 518 */     if (tailOvrlp >= 2 && headOvrlp >= 2) return true; 
/* 519 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 535 */     return (obj == this || obj instanceof AnWTFilterIntLift5x3);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFilterType() {
/* 548 */     return 1;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 553 */     return "w5x3";
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/wavelet/analysis/AnWTFilterIntLift5x3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */