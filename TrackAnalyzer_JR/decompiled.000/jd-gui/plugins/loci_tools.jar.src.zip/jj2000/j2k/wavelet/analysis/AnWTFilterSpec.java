/*     */ package jj2000.j2k.wavelet.analysis;
/*     */ 
/*     */ import com.sun.media.imageioimpl.plugins.jpeg2000.J2KImageWriteParamJava;
/*     */ import java.util.StringTokenizer;
/*     */ import jj2000.j2k.ModuleSpec;
/*     */ import jj2000.j2k.quantization.QuantTypeSpec;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnWTFilterSpec
/*     */   extends ModuleSpec
/*     */ {
/*     */   private static final String REV_FILTER_STR = "w5x3";
/*     */   private static final String NON_REV_FILTER_STR = "w9x7";
/*     */   
/*     */   public AnWTFilterSpec(int nt, int nc, byte type, QuantTypeSpec qts, J2KImageWriteParamJava wp, String values) {
/* 119 */     super(nt, nc, type);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 125 */     this.specified = values;
/* 126 */     String param = this.specified;
/* 127 */     boolean isFilterSpecified = true;
/*     */ 
/*     */     
/* 130 */     if (values == null) {
/* 131 */       isFilterSpecified = false;
/*     */       
/* 133 */       if (wp.getLossless()) {
/* 134 */         setDefault(parseFilters("w5x3"));
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */ 
/*     */       
/* 141 */       for (int i = nt - 1; i >= 0; i--) {
/* 142 */         for (int c = nc - 1; c >= 0; c--) {
/* 143 */           switch (qts.getSpecValType(i, c)) {
/*     */             case 0:
/* 145 */               if (getDefault() == null) {
/* 146 */                 if (wp.getLossless())
/* 147 */                   setDefault(parseFilters("w5x3")); 
/* 148 */                 if (((String)qts.getDefault()).equals("reversible")) {
/*     */                   
/* 150 */                   setDefault(parseFilters("w5x3"));
/*     */                 } else {
/*     */                   
/* 153 */                   setDefault(parseFilters("w9x7"));
/*     */                 } 
/*     */               } 
/* 156 */               this.specValType[i][c] = 0;
/*     */               break;
/*     */             case 1:
/* 159 */               if (!isCompSpecified(c)) {
/* 160 */                 if (((String)qts.getCompDef(c)).equals("reversible")) {
/*     */                   
/* 162 */                   setCompDef(c, parseFilters("w5x3"));
/*     */                 } else {
/*     */                   
/* 165 */                   setCompDef(c, parseFilters("w9x7"));
/*     */                 } 
/*     */               }
/* 168 */               this.specValType[i][c] = 1;
/*     */               break;
/*     */             case 2:
/* 171 */               if (!isTileSpecified(i)) {
/* 172 */                 if (((String)qts.getTileDef(i)).equals("reversible")) {
/*     */                   
/* 174 */                   setTileDef(i, parseFilters("w5x3"));
/*     */                 } else {
/*     */                   
/* 177 */                   setTileDef(i, parseFilters("w9x7"));
/*     */                 } 
/*     */               }
/* 180 */               this.specValType[i][c] = 2;
/*     */               break;
/*     */             case 3:
/* 183 */               if (!isTileCompSpecified(i, c)) {
/* 184 */                 if (((String)qts.getTileCompVal(i, c)).equals("reversible")) {
/*     */                   
/* 186 */                   setTileCompVal(i, c, parseFilters("w5x3"));
/*     */                 } else {
/*     */                   
/* 189 */                   setTileCompVal(i, c, parseFilters("w9x7"));
/*     */                 } 
/*     */               }
/*     */               
/* 193 */               this.specValType[i][c] = 3;
/*     */               break;
/*     */             default:
/* 196 */               throw new IllegalArgumentException("Unsupported specification type");
/*     */           } 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         } 
/*     */       } 
/*     */       return;
/*     */     } 
/* 206 */     StringTokenizer stk = new StringTokenizer(param);
/*     */     
/* 208 */     byte curSpecType = 0;
/*     */     
/* 210 */     boolean[] tileSpec = null;
/* 211 */     boolean[] compSpec = null;
/*     */ 
/*     */     
/* 214 */     while (stk.hasMoreTokens()) {
/* 215 */       AnWTFilter[][] filter; String word = stk.nextToken();
/*     */       
/* 217 */       switch (word.charAt(0)) {
/*     */         case 'T':
/*     */         case 't':
/* 220 */           tileSpec = parseIdx(word, this.nTiles);
/* 221 */           if (curSpecType == 1) {
/* 222 */             curSpecType = 3; continue;
/*     */           } 
/* 224 */           curSpecType = 2;
/*     */           continue;
/*     */         case 'C':
/*     */         case 'c':
/* 228 */           compSpec = parseIdx(word, this.nComp);
/* 229 */           if (curSpecType == 2) {
/* 230 */             curSpecType = 3; continue;
/*     */           } 
/* 232 */           curSpecType = 1;
/*     */           continue;
/*     */         case 'W':
/*     */         case 'w':
/* 236 */           if (wp.getLossless() && word.equalsIgnoreCase("w9x7"))
/*     */           {
/* 238 */             throw new IllegalArgumentException("Cannot use non reversible wavelet transform with '-lossless' option");
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 245 */           filter = parseFilters(word);
/* 246 */           if (curSpecType == 0) {
/* 247 */             setDefault(filter);
/*     */           }
/* 249 */           else if (curSpecType == 2) {
/* 250 */             for (int i = tileSpec.length - 1; i >= 0; i--) {
/* 251 */               if (tileSpec[i]) {
/* 252 */                 setTileDef(i, filter);
/*     */               }
/*     */             } 
/* 255 */           } else if (curSpecType == 1) {
/* 256 */             for (int i = compSpec.length - 1; i >= 0; i--) {
/* 257 */               if (compSpec[i]) {
/* 258 */                 setCompDef(i, filter);
/*     */               }
/*     */             } 
/*     */           } else {
/* 262 */             for (int i = tileSpec.length - 1; i >= 0; i--) {
/* 263 */               for (int j = compSpec.length - 1; j >= 0; j--) {
/* 264 */                 if (tileSpec[i] && compSpec[j]) {
/* 265 */                   setTileCompVal(i, j, filter);
/*     */                 }
/*     */               } 
/*     */             } 
/*     */           } 
/*     */ 
/*     */           
/* 272 */           curSpecType = 0;
/* 273 */           tileSpec = null;
/* 274 */           compSpec = null;
/*     */           continue;
/*     */       } 
/*     */       
/* 278 */       throw new IllegalArgumentException("Bad construction for parameter: " + word);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 284 */     if (getDefault() == null) {
/* 285 */       int ndefspec = 0;
/* 286 */       for (int i = nt - 1; i >= 0; i--) {
/* 287 */         for (int c = nc - 1; c >= 0; c--) {
/* 288 */           if (this.specValType[i][c] == 0) {
/* 289 */             ndefspec++;
/*     */           }
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 296 */       if (ndefspec != 0) {
/* 297 */         if (((String)qts.getDefault()).equals("reversible")) {
/* 298 */           setDefault(parseFilters("w5x3"));
/*     */         } else {
/* 300 */           setDefault(parseFilters("w9x7"));
/*     */         } 
/*     */       } else {
/*     */         int c, j;
/*     */         
/* 305 */         setDefault(getTileCompVal(0, 0));
/* 306 */         switch (this.specValType[0][0]) {
/*     */           case 2:
/* 308 */             for (c = nc - 1; c >= 0; c--) {
/* 309 */               if (this.specValType[0][c] == 2)
/* 310 */                 this.specValType[0][c] = 0; 
/*     */             } 
/* 312 */             this.tileDef[0] = null;
/*     */             break;
/*     */           case 1:
/* 315 */             for (j = nt - 1; j >= 0; j--) {
/* 316 */               if (this.specValType[j][0] == 1)
/* 317 */                 this.specValType[j][0] = 0; 
/*     */             } 
/* 319 */             this.compDef[0] = null;
/*     */             break;
/*     */           case 3:
/* 322 */             this.specValType[0][0] = 0;
/* 323 */             this.tileCompVal.put("t0c0", null);
/*     */             break;
/*     */         } 
/*     */ 
/*     */ 
/*     */       
/*     */       } 
/*     */     } 
/* 331 */     for (int t = nt - 1; t >= 0; t--) {
/* 332 */       for (int c = nc - 1; c >= 0; c--) {
/*     */         
/* 334 */         if (((String)qts.getTileCompVal(t, c)).equals("reversible")) {
/*     */           
/* 336 */           if (!isReversible(t, c))
/*     */           {
/*     */             
/* 339 */             if (!isFilterSpecified) {
/* 340 */               setTileCompVal(t, c, parseFilters("w5x3"));
/*     */             }
/*     */             else {
/*     */               
/* 344 */               throw new IllegalArgumentException("Filter of tile-component (" + t + "," + c + ") does" + " not allow " + "reversible " + "quantization. " + "Specify '-Qtype " + "expounded' or " + "'-Qtype derived'" + "in " + "the command line.");
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*     */             }
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           }
/*     */ 
/*     */ 
/*     */         
/*     */         }
/* 359 */         else if (isReversible(t, c)) {
/*     */ 
/*     */ 
/*     */           
/* 363 */           if (!isFilterSpecified) {
/* 364 */             setTileCompVal(t, c, parseFilters("w9x7"));
/*     */           }
/*     */           else {
/*     */             
/* 368 */             throw new IllegalArgumentException("Filter of tile-component (" + t + "," + c + ") does" + " not allow " + "non-reversible " + "quantization. " + "Specify '-Qtype " + "reversible' in " + "the command line");
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private AnWTFilter[][] parseFilters(String word) {
/* 392 */     AnWTFilter[][] filt = new AnWTFilter[2][1];
/* 393 */     if (word.equalsIgnoreCase("w5x3")) {
/* 394 */       filt[0][0] = new AnWTFilterIntLift5x3();
/* 395 */       filt[1][0] = new AnWTFilterIntLift5x3();
/* 396 */       return filt;
/*     */     } 
/* 398 */     if (word.equalsIgnoreCase("w9x7")) {
/* 399 */       filt[0][0] = new AnWTFilterFloatLift9x7();
/* 400 */       filt[1][0] = new AnWTFilterFloatLift9x7();
/* 401 */       return filt;
/*     */     } 
/*     */     
/* 404 */     throw new IllegalArgumentException("Non JPEG 2000 part I filter: " + word);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getWTDataType(int t, int c) {
/* 423 */     AnWTFilter[][] an = (AnWTFilter[][])getSpec(t, c);
/* 424 */     return an[0][0].getDataType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnWTFilter[] getHFilters(int t, int c) {
/* 446 */     AnWTFilter[][] an = (AnWTFilter[][])getSpec(t, c);
/* 447 */     return an[0];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnWTFilter[] getVFilters(int t, int c) {
/* 469 */     AnWTFilter[][] an = (AnWTFilter[][])getSpec(t, c);
/* 470 */     return an[1];
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 475 */     String str = "";
/*     */ 
/*     */     
/* 478 */     str = str + "nTiles=" + this.nTiles + "\nnComp=" + this.nComp + "\n\n";
/*     */     
/* 480 */     for (int t = 0; t < this.nTiles; t++) {
/* 481 */       for (int c = 0; c < this.nComp; c++) {
/* 482 */         AnWTFilter[][] an = (AnWTFilter[][])getSpec(t, c);
/*     */         
/* 484 */         str = str + "(t:" + t + ",c:" + c + ")\n";
/*     */ 
/*     */         
/* 487 */         str = str + "\tH:"; int i;
/* 488 */         for (i = 0; i < (an[0]).length; i++) {
/* 489 */           str = str + " " + an[0][i];
/*     */         }
/* 491 */         str = str + "\n\tV:";
/* 492 */         for (i = 0; i < (an[1]).length; i++)
/* 493 */           str = str + " " + an[1][i]; 
/* 494 */         str = str + "\n";
/*     */       } 
/*     */     } 
/*     */     
/* 498 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isReversible(int t, int c) {
/* 513 */     AnWTFilter[] hfilter = getHFilters(t, c);
/* 514 */     AnWTFilter[] vfilter = getVFilters(t, c);
/*     */ 
/*     */     
/* 517 */     for (int i = hfilter.length - 1; i >= 0; i--) {
/* 518 */       if (!hfilter[i].isReversible() || !vfilter[i].isReversible())
/* 519 */         return false; 
/* 520 */     }  return true;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/wavelet/analysis/AnWTFilterSpec.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */