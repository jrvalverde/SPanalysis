/*     */ package jj2000.j2k.wavelet.synthesis;
/*     */ 
/*     */ import jj2000.j2k.wavelet.Subband;
/*     */ import jj2000.j2k.wavelet.WaveletFilter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SubbandSyn
/*     */   extends Subband
/*     */ {
/*     */   public SubbandSyn parent;
/*     */   public SubbandSyn subb_LL;
/*     */   public SubbandSyn subb_HL;
/*     */   public SubbandSyn subb_LH;
/*     */   public SubbandSyn subb_HH;
/*     */   public SynWTFilter hFilter;
/*     */   public SynWTFilter vFilter;
/* 145 */   public int magbits = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SubbandSyn() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SubbandSyn(int w, int h, int ulcx, int ulcy, int lvls, WaveletFilter[] hfilters, WaveletFilter[] vfilters) {
/* 190 */     super(w, h, ulcx, ulcy, lvls, hfilters, vfilters);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Subband getParent() {
/* 203 */     return this.parent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Subband getLL() {
/* 214 */     return this.subb_LL;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Subband getHL() {
/* 226 */     return this.subb_HL;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Subband getLH() {
/* 238 */     return this.subb_LH;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Subband getHH() {
/* 249 */     return this.subb_HH;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Subband split(WaveletFilter hfilter, WaveletFilter vfilter) {
/* 275 */     if (this.isNode) {
/* 276 */       throw new IllegalArgumentException();
/*     */     }
/*     */ 
/*     */     
/* 280 */     this.isNode = true;
/* 281 */     this.hFilter = (SynWTFilter)hfilter;
/* 282 */     this.vFilter = (SynWTFilter)vfilter;
/*     */ 
/*     */     
/* 285 */     this.subb_LL = new SubbandSyn();
/* 286 */     this.subb_LH = new SubbandSyn();
/* 287 */     this.subb_HL = new SubbandSyn();
/* 288 */     this.subb_HH = new SubbandSyn();
/*     */ 
/*     */     
/* 291 */     this.subb_LL.parent = this;
/* 292 */     this.subb_HL.parent = this;
/* 293 */     this.subb_LH.parent = this;
/* 294 */     this.subb_HH.parent = this;
/*     */ 
/*     */     
/* 297 */     initChilds();
/*     */ 
/*     */     
/* 300 */     return this.subb_LL;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WaveletFilter getHorWFilter() {
/* 311 */     return this.hFilter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WaveletFilter getVerWFilter() {
/* 323 */     return this.hFilter;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/wavelet/synthesis/SubbandSyn.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */