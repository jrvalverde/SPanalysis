/*     */ package jj2000.j2k.wavelet.analysis;
/*     */ 
/*     */ import jj2000.j2k.wavelet.Subband;
/*     */ import jj2000.j2k.wavelet.WaveletFilter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SubbandAn
/*     */   extends Subband
/*     */ {
/* 109 */   public SubbandAn parent = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SubbandAn subb_LL;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SubbandAn subb_HL;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SubbandAn subb_LH;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SubbandAn subb_HH;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnWTFilter hFilter;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnWTFilter vFilter;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 149 */   public float l2Norm = -1.0F;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float stepWMSE;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SubbandAn() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SubbandAn(int w, int h, int ulcx, int ulcy, int lvls, WaveletFilter[] hfilters, WaveletFilter[] vfilters) {
/* 212 */     super(w, h, ulcx, ulcy, lvls, hfilters, vfilters);
/*     */     
/* 214 */     calcL2Norms();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Subband getParent() {
/* 227 */     return this.parent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Subband getLL() {
/* 238 */     return this.subb_LL;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Subband getHL() {
/* 250 */     return this.subb_HL;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Subband getLH() {
/* 262 */     return this.subb_LH;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Subband getHH() {
/* 273 */     return this.subb_HH;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Subband split(WaveletFilter hfilter, WaveletFilter vfilter) {
/* 299 */     if (this.isNode) {
/* 300 */       throw new IllegalArgumentException();
/*     */     }
/*     */ 
/*     */     
/* 304 */     this.isNode = true;
/* 305 */     this.hFilter = (AnWTFilter)hfilter;
/* 306 */     this.vFilter = (AnWTFilter)vfilter;
/*     */ 
/*     */     
/* 309 */     this.subb_LL = new SubbandAn();
/* 310 */     this.subb_LH = new SubbandAn();
/* 311 */     this.subb_HL = new SubbandAn();
/* 312 */     this.subb_HH = new SubbandAn();
/*     */ 
/*     */     
/* 315 */     this.subb_LL.parent = this;
/* 316 */     this.subb_HL.parent = this;
/* 317 */     this.subb_LH.parent = this;
/* 318 */     this.subb_HH.parent = this;
/*     */ 
/*     */     
/* 321 */     initChilds();
/*     */ 
/*     */     
/* 324 */     return this.subb_LL;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void calcBasisWaveForms(float[][] wfs) {
/* 349 */     if (this.l2Norm < 0.0F) {
/*     */       
/* 351 */       if (this.isNode)
/*     */       {
/* 353 */         if (this.subb_LL.l2Norm < 0.0F) {
/* 354 */           this.subb_LL.calcBasisWaveForms(wfs);
/* 355 */           wfs[0] = this.hFilter.getLPSynWaveForm(wfs[0], null);
/*     */           
/* 357 */           wfs[1] = this.vFilter.getLPSynWaveForm(wfs[1], null);
/*     */         
/*     */         }
/* 360 */         else if (this.subb_HL.l2Norm < 0.0F) {
/* 361 */           this.subb_HL.calcBasisWaveForms(wfs);
/* 362 */           wfs[0] = this.hFilter.getHPSynWaveForm(wfs[0], null);
/*     */           
/* 364 */           wfs[1] = this.vFilter.getLPSynWaveForm(wfs[1], null);
/*     */         
/*     */         }
/* 367 */         else if (this.subb_LH.l2Norm < 0.0F) {
/* 368 */           this.subb_LH.calcBasisWaveForms(wfs);
/* 369 */           wfs[0] = this.hFilter.getLPSynWaveForm(wfs[0], null);
/*     */           
/* 371 */           wfs[1] = this.vFilter.getHPSynWaveForm(wfs[1], null);
/*     */         
/*     */         }
/* 374 */         else if (this.subb_HH.l2Norm < 0.0F) {
/* 375 */           this.subb_HH.calcBasisWaveForms(wfs);
/* 376 */           wfs[0] = this.hFilter.getHPSynWaveForm(wfs[0], null);
/*     */           
/* 378 */           wfs[1] = this.vFilter.getHPSynWaveForm(wfs[1], null);
/*     */ 
/*     */         
/*     */         }
/*     */         else {
/*     */ 
/*     */           
/* 385 */           throw new Error("You have found a bug in JJ2000!");
/*     */         }
/*     */       
/*     */       }
/*     */       else
/*     */       {
/* 391 */         wfs[0] = new float[1];
/* 392 */         wfs[0][0] = 1.0F;
/* 393 */         wfs[1] = new float[1];
/* 394 */         wfs[1][0] = 1.0F;
/*     */       
/*     */       }
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 401 */       throw new Error("You have found a bug in JJ2000!");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void assignL2Norm(float l2n) {
/* 421 */     if (this.l2Norm < 0.0F) {
/*     */       
/* 423 */       if (this.isNode) {
/*     */         
/* 425 */         if (this.subb_LL.l2Norm < 0.0F) {
/* 426 */           this.subb_LL.assignL2Norm(l2n);
/*     */         }
/* 428 */         else if (this.subb_HL.l2Norm < 0.0F) {
/* 429 */           this.subb_HL.assignL2Norm(l2n);
/*     */         }
/* 431 */         else if (this.subb_LH.l2Norm < 0.0F) {
/* 432 */           this.subb_LH.assignL2Norm(l2n);
/*     */         }
/* 434 */         else if (this.subb_HH.l2Norm < 0.0F) {
/* 435 */           this.subb_HH.assignL2Norm(l2n);
/*     */           
/* 437 */           if (this.subb_HH.l2Norm >= 0.0F) {
/* 438 */             this.l2Norm = 0.0F;
/*     */           
/*     */           }
/*     */         
/*     */         }
/*     */         else {
/*     */           
/* 445 */           throw new Error("You have found a bug in JJ2000!");
/*     */         }
/*     */       
/*     */       } else {
/*     */         
/* 450 */         this.l2Norm = l2n;
/*     */       
/*     */       }
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 457 */       throw new Error("You have found a bug in JJ2000!");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void calcL2Norms() {
/* 471 */     float[][] wfs = new float[2][];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 477 */     while (this.l2Norm < 0.0F) {
/* 478 */       calcBasisWaveForms(wfs);
/*     */ 
/*     */       
/* 481 */       double acc = 0.0D; int i;
/* 482 */       for (i = (wfs[0]).length - 1; i >= 0; i--) {
/* 483 */         acc += (wfs[0][i] * wfs[0][i]);
/*     */       }
/* 485 */       float l2n = (float)Math.sqrt(acc);
/*     */       
/* 487 */       acc = 0.0D;
/* 488 */       for (i = (wfs[1]).length - 1; i >= 0; i--) {
/* 489 */         acc += (wfs[1][i] * wfs[1][i]);
/*     */       }
/* 491 */       l2n *= (float)Math.sqrt(acc);
/*     */       
/* 493 */       wfs[0] = null;
/* 494 */       wfs[1] = null;
/*     */       
/* 496 */       assignL2Norm(l2n);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WaveletFilter getHorWFilter() {
/* 509 */     return this.hFilter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WaveletFilter getVerWFilter() {
/* 521 */     return this.hFilter;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/wavelet/analysis/SubbandAn.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */