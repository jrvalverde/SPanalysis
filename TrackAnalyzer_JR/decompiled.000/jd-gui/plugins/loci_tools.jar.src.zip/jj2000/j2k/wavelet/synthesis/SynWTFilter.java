package jj2000.j2k.wavelet.synthesis;

import jj2000.j2k.codestream.Markers;
import jj2000.j2k.wavelet.WaveletFilter;

public abstract class SynWTFilter implements WaveletFilter, Markers {
  public abstract void synthetize_lpf(Object paramObject1, int paramInt1, int paramInt2, int paramInt3, Object paramObject2, int paramInt4, int paramInt5, int paramInt6, Object paramObject3, int paramInt7, int paramInt8);
  
  public abstract void synthetize_hpf(Object paramObject1, int paramInt1, int paramInt2, int paramInt3, Object paramObject2, int paramInt4, int paramInt5, int paramInt6, Object paramObject3, int paramInt7, int paramInt8);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/wavelet/synthesis/SynWTFilter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */