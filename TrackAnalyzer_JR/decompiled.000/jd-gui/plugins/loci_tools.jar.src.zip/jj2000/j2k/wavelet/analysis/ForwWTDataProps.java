package jj2000.j2k.wavelet.analysis;

import jj2000.j2k.image.ImgData;

public interface ForwWTDataProps extends ImgData {
  boolean isReversible(int paramInt1, int paramInt2);
  
  SubbandAn getAnSubbandTree(int paramInt1, int paramInt2);
  
  int getCbULX();
  
  int getCbULY();
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/wavelet/analysis/ForwWTDataProps.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */