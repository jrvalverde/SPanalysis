package jj2000.j2k.wavelet;

public interface WaveletFilter {
  public static final int WT_FILTER_INT_LIFT = 0;
  
  public static final int WT_FILTER_FLOAT_LIFT = 1;
  
  public static final int WT_FILTER_FLOAT_CONVOL = 2;
  
  int getAnLowNegSupport();
  
  int getAnLowPosSupport();
  
  int getAnHighNegSupport();
  
  int getAnHighPosSupport();
  
  int getSynLowNegSupport();
  
  int getSynLowPosSupport();
  
  int getSynHighNegSupport();
  
  int getSynHighPosSupport();
  
  int getImplType();
  
  int getDataType();
  
  boolean isReversible();
  
  boolean isSameAsFullWT(int paramInt1, int paramInt2, int paramInt3);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/wavelet/WaveletFilter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */