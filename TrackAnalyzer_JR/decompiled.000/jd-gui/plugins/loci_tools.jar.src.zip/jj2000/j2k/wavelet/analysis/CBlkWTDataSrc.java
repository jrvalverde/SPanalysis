package jj2000.j2k.wavelet.analysis;

public interface CBlkWTDataSrc extends ForwWTDataProps {
  int getFixedPoint(int paramInt);
  
  int getDataType(int paramInt1, int paramInt2);
  
  CBlkWTData getNextCodeBlock(int paramInt, CBlkWTData paramCBlkWTData);
  
  CBlkWTData getNextInternCodeBlock(int paramInt, CBlkWTData paramCBlkWTData);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/wavelet/analysis/CBlkWTDataSrc.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */