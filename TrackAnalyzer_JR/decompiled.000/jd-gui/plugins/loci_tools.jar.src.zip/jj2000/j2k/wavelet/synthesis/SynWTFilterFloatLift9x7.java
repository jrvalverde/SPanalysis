/*     */ package jj2000.j2k.wavelet.synthesis;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SynWTFilterFloatLift9x7
/*     */   extends SynWTFilterFloat
/*     */ {
/*     */   public static final float ALPHA = -1.5861343F;
/*     */   public static final float BETA = -0.052980117F;
/*     */   public static final float GAMMA = 0.8829111F;
/*     */   public static final float DELTA = 0.44350687F;
/*     */   public static final float KL = 0.8128931F;
/*     */   public static final float KH = 1.2301741F;
/*     */   
/*     */   public void synthetize_lpf(float[] lowSig, int lowOff, int lowLen, int lowStep, float[] highSig, int highOff, int highLen, int highStep, float[] outSig, int outOff, int outStep) {
/* 179 */     int outLen = lowLen + highLen;
/* 180 */     int iStep = 2 * outStep;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 186 */     float sample = 0.0F;
/*     */ 
/*     */     
/* 189 */     int lk = lowOff;
/* 190 */     int hk = highOff;
/* 191 */     int ik = outOff;
/*     */ 
/*     */     
/* 194 */     if (outLen > 1) {
/* 195 */       outSig[ik] = lowSig[lk] / 0.8128931F - 0.88701373F * highSig[hk] / 1.2301741F;
/*     */     } else {
/*     */       
/* 198 */       outSig[ik] = lowSig[lk];
/*     */     } 
/*     */     
/* 201 */     lk += lowStep;
/* 202 */     hk += highStep;
/* 203 */     ik += iStep;
/*     */     
/*     */     int i;
/* 206 */     for (i = 2; i < outLen - 1; i += 2, ik += iStep, lk += lowStep, hk += highStep) {
/* 207 */       outSig[ik] = lowSig[lk] / 0.8128931F - 0.44350687F * (highSig[hk - highStep] + highSig[hk]) / 1.2301741F;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 212 */     if (outLen % 2 == 1 && 
/* 213 */       outLen > 2) {
/* 214 */       outSig[ik] = lowSig[lk] / 0.8128931F - 0.88701373F * highSig[hk - highStep] / 1.2301741F;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 222 */     lk = lowOff;
/* 223 */     hk = highOff;
/* 224 */     ik = outOff + outStep;
/*     */ 
/*     */     
/* 227 */     for (i = 1; i < outLen - 1; i += 2, ik += iStep, hk += highStep, lk += lowStep) {
/* 228 */       outSig[ik] = highSig[hk] / 1.2301741F - 0.8829111F * (outSig[ik - outStep] + outSig[ik + outStep]);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 233 */     if (outLen % 2 == 0) {
/* 234 */       outSig[ik] = highSig[hk] / 1.2301741F - 1.7658222F * outSig[ik - outStep];
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 240 */     ik = outOff;
/*     */ 
/*     */ 
/*     */     
/* 244 */     if (outLen > 1) {
/* 245 */       outSig[ik] = outSig[ik] - -0.105960235F * outSig[ik + outStep];
/*     */     }
/* 247 */     ik += iStep;
/*     */ 
/*     */     
/* 250 */     for (i = 2; i < outLen - 1; i += 2, ik += iStep) {
/* 251 */       outSig[ik] = outSig[ik] - -0.052980117F * (outSig[ik - outStep] + outSig[ik + outStep]);
/*     */     }
/*     */ 
/*     */     
/* 255 */     if (outLen % 2 == 1 && outLen > 2) {
/* 256 */       outSig[ik] = outSig[ik] - -0.105960235F * outSig[ik - outStep];
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 262 */     ik = outOff + outStep;
/*     */ 
/*     */     
/* 265 */     for (i = 1; i < outLen - 1; i += 2, ik += iStep) {
/* 266 */       outSig[ik] = outSig[ik] - -1.5861343F * (outSig[ik - outStep] + outSig[ik + outStep]);
/*     */     }
/*     */ 
/*     */     
/* 270 */     if (outLen % 2 == 0) {
/* 271 */       outSig[ik] = outSig[ik] - -3.1722686F * outSig[ik - outStep];
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void synthetize_hpf(float[] lowSig, int lowOff, int lowLen, int lowStep, float[] highSig, int highOff, int highLen, int highStep, float[] outSig, int outOff, int outStep) {
/* 334 */     int outLen = lowLen + highLen;
/* 335 */     int iStep = 2 * outStep;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 341 */     int lk = lowOff;
/* 342 */     int hk = highOff;
/*     */     
/* 344 */     if (outLen != 1) {
/* 345 */       int outLen2 = outLen >> 1;
/*     */       
/* 347 */       for (int j = 0; j < outLen2; j++) {
/* 348 */         lowSig[lk] = lowSig[lk] / 0.8128931F;
/* 349 */         highSig[hk] = highSig[hk] / 1.2301741F;
/* 350 */         lk += lowStep;
/* 351 */         hk += highStep;
/*     */       } 
/*     */       
/* 354 */       if (outLen % 2 == 1) {
/* 355 */         highSig[hk] = highSig[hk] / 1.2301741F;
/*     */       }
/*     */     } else {
/*     */       
/* 359 */       highSig[highOff] = highSig[highOff] / 2.0F;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 365 */     lk = lowOff;
/* 366 */     hk = highOff;
/* 367 */     int ik = outOff + outStep;
/*     */     
/*     */     int i;
/* 370 */     for (i = 1; i < outLen - 1; i += 2) {
/* 371 */       outSig[ik] = lowSig[lk] - 0.44350687F * (highSig[hk] + highSig[hk + highStep]);
/*     */       
/* 373 */       ik += iStep;
/* 374 */       lk += lowStep;
/* 375 */       hk += highStep;
/*     */     } 
/*     */     
/* 378 */     if (outLen % 2 == 0 && outLen > 1)
/*     */     {
/* 380 */       outSig[ik] = lowSig[lk] - 0.88701373F * highSig[hk];
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 386 */     hk = highOff;
/* 387 */     ik = outOff;
/*     */     
/* 389 */     if (outLen > 1) {
/* 390 */       outSig[ik] = highSig[hk] - 1.7658222F * outSig[ik + outStep];
/*     */     } else {
/* 392 */       outSig[ik] = highSig[hk];
/*     */     } 
/*     */     
/* 395 */     ik += iStep;
/* 396 */     hk += highStep;
/*     */ 
/*     */     
/* 399 */     for (i = 2; i < outLen - 1; i += 2) {
/* 400 */       outSig[ik] = highSig[hk] - 0.8829111F * (outSig[ik - outStep] + outSig[ik + outStep]);
/*     */       
/* 402 */       ik += iStep;
/* 403 */       hk += highStep;
/*     */     } 
/*     */ 
/*     */     
/* 407 */     if (outLen % 2 == 1 && outLen > 1)
/*     */     {
/* 409 */       outSig[ik] = highSig[hk] - 1.7658222F * outSig[ik - outStep];
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 415 */     ik = outOff + outStep;
/*     */ 
/*     */     
/* 418 */     for (i = 1; i < outLen - 1; i += 2) {
/* 419 */       outSig[ik] = outSig[ik] - -0.052980117F * (outSig[ik - outStep] + outSig[ik + outStep]);
/* 420 */       ik += iStep;
/*     */     } 
/*     */     
/* 423 */     if (outLen % 2 == 0 && outLen > 1)
/*     */     {
/* 425 */       outSig[ik] = outSig[ik] - -0.105960235F * outSig[ik - outStep];
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 431 */     ik = outOff;
/*     */     
/* 433 */     if (outLen > 1)
/*     */     {
/* 435 */       outSig[ik] = outSig[ik] - -3.1722686F * outSig[ik + outStep];
/*     */     }
/* 437 */     ik += iStep;
/*     */ 
/*     */     
/* 440 */     for (i = 2; i < outLen - 1; i += 2) {
/* 441 */       outSig[ik] = outSig[ik] - -1.5861343F * (outSig[ik - outStep] + outSig[ik + outStep]);
/* 442 */       ik += iStep;
/*     */     } 
/*     */ 
/*     */     
/* 446 */     if (outLen % 2 == 1 && outLen > 1)
/*     */     {
/* 448 */       outSig[ik] = outSig[ik] - -3.1722686F * outSig[ik - outStep];
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getAnLowNegSupport() {
/* 459 */     return 4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getAnLowPosSupport() {
/* 470 */     return 4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getAnHighNegSupport() {
/* 481 */     return 3;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getAnHighPosSupport() {
/* 492 */     return 3;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSynLowNegSupport() {
/* 505 */     return 3;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSynLowPosSupport() {
/* 518 */     return 3;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSynHighNegSupport() {
/* 531 */     return 4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSynHighPosSupport() {
/* 544 */     return 4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getImplType() {
/* 555 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isReversible() {
/* 566 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSameAsFullWT(int tailOvrlp, int headOvrlp, int inLen) {
/* 604 */     if (inLen % 2 == 0) {
/* 605 */       if (tailOvrlp >= 2 && headOvrlp >= 1) return true; 
/* 606 */       return false;
/*     */     } 
/*     */ 
/*     */     
/* 610 */     if (tailOvrlp >= 2 && headOvrlp >= 2) return true; 
/* 611 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 623 */     return "w9x7 (lifting)";
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/wavelet/synthesis/SynWTFilterFloatLift9x7.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */