/*      */ package jj2000.j2k.wavelet.analysis;
/*      */ 
/*      */ import com.sun.media.imageioimpl.plugins.jpeg2000.J2KImageWriteParamJava;
/*      */ import java.awt.Point;
/*      */ import jj2000.j2k.IntegerSpec;
/*      */ import jj2000.j2k.entropy.CBlkSizeSpec;
/*      */ import jj2000.j2k.entropy.PrecinctSizeSpec;
/*      */ import jj2000.j2k.image.BlkImgDataSrc;
/*      */ import jj2000.j2k.image.DataBlk;
/*      */ import jj2000.j2k.image.DataBlkFloat;
/*      */ import jj2000.j2k.image.DataBlkInt;
/*      */ import jj2000.j2k.image.ImgData;
/*      */ import jj2000.j2k.util.MathUtil;
/*      */ import jj2000.j2k.wavelet.Subband;
/*      */ import jj2000.j2k.wavelet.WaveletFilter;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ForwWTFull
/*      */   extends ForwardWT
/*      */ {
/*      */   private boolean intData;
/*      */   private SubbandAn[][] subbTrees;
/*      */   private BlkImgDataSrc src;
/*      */   private int cb0x;
/*      */   private int cb0y;
/*      */   private IntegerSpec dls;
/*      */   private AnWTFilterSpec filters;
/*      */   private CBlkSizeSpec cblks;
/*      */   private PrecinctSizeSpec pss;
/*      */   private DataBlk[] decomposedComps;
/*      */   private int[] lastn;
/*      */   private int[] lastm;
/*      */   SubbandAn[] currentSubband;
/*      */   Point ncblks;
/*      */   
/*      */   public ForwWTFull(BlkImgDataSrc src, J2KImageWriteParamJava wp, int pox, int poy) {
/*  180 */     super((ImgData)src);
/*  181 */     this.src = src;
/*      */     
/*  183 */     this.cb0x = this.cb0x;
/*  184 */     this.cb0y = this.cb0y;
/*  185 */     this.dls = wp.getDecompositionLevel();
/*  186 */     this.filters = wp.getFilters();
/*  187 */     this.cblks = wp.getCodeBlockSize();
/*  188 */     this.pss = wp.getPrecinctPartition();
/*      */     
/*  190 */     int ncomp = src.getNumComps();
/*  191 */     int ntiles = src.getNumTiles();
/*      */     
/*  193 */     this.currentSubband = new SubbandAn[ncomp];
/*  194 */     this.decomposedComps = new DataBlk[ncomp];
/*  195 */     this.subbTrees = new SubbandAn[ntiles][ncomp];
/*  196 */     this.lastn = new int[ncomp];
/*  197 */     this.lastm = new int[ncomp];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getImplementationType(int c) {
/*  209 */     return 2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getDecompLevels(int t, int c) {
/*  225 */     return ((Integer)this.dls.getTileCompVal(t, c)).intValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getDecomp(int t, int c) {
/*  239 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnWTFilter[] getHorAnWaveletFilters(int t, int c) {
/*  264 */     return this.filters.getHFilters(t, c);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnWTFilter[] getVertAnWaveletFilters(int t, int c) {
/*  289 */     return this.filters.getVFilters(t, c);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isReversible(int t, int c) {
/*  304 */     return this.filters.isReversible(t, c);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getCbULX() {
/*  312 */     return this.cb0x;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getCbULY() {
/*  320 */     return this.cb0y;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getFixedPoint(int c) {
/*  338 */     return this.src.getFixedPoint(c);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CBlkWTData getNextInternCodeBlock(int c, CBlkWTData cblk) {
/*  379 */     this.intData = (this.filters.getWTDataType(this.tIdx, c) == 3);
/*      */ 
/*      */     
/*  382 */     if (this.decomposedComps[c] == null) {
/*      */       DataBlkFloat dataBlkFloat;
/*      */ 
/*      */ 
/*      */       
/*  387 */       int w = getTileCompWidth(this.tIdx, c);
/*  388 */       int h = getTileCompHeight(this.tIdx, c);
/*      */ 
/*      */       
/*  391 */       if (this.intData) {
/*  392 */         this.decomposedComps[c] = (DataBlk)new DataBlkInt(0, 0, w, h);
/*  393 */         DataBlkInt dataBlkInt = new DataBlkInt();
/*      */       } else {
/*  395 */         this.decomposedComps[c] = (DataBlk)new DataBlkFloat(0, 0, w, h);
/*  396 */         dataBlkFloat = new DataBlkFloat();
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  401 */       Object dst_data = this.decomposedComps[c].getData();
/*  402 */       int lstart = getCompULX(c);
/*  403 */       ((DataBlk)dataBlkFloat).ulx = lstart;
/*  404 */       ((DataBlk)dataBlkFloat).w = w;
/*  405 */       ((DataBlk)dataBlkFloat).h = 1;
/*  406 */       int kk = getCompULY(c);
/*  407 */       for (int k = 0; k < h; k++, kk++) {
/*  408 */         ((DataBlk)dataBlkFloat).uly = kk;
/*  409 */         ((DataBlk)dataBlkFloat).ulx = lstart;
/*  410 */         DataBlk dataBlk = this.src.getInternCompData((DataBlk)dataBlkFloat, c);
/*  411 */         System.arraycopy(dataBlk.getData(), dataBlk.offset, dst_data, k * w, w);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  416 */       waveletTreeDecomposition(this.decomposedComps[c], getAnSubbandTree(this.tIdx, c), c);
/*      */ 
/*      */ 
/*      */       
/*  420 */       this.currentSubband[c] = getNextSubband(c);
/*      */       
/*  422 */       this.lastn[c] = -1;
/*  423 */       this.lastm[c] = 0;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/*  429 */       this.ncblks = (this.currentSubband[c]).numCb;
/*      */       
/*  431 */       this.lastn[c] = this.lastn[c] + 1;
/*  432 */       if (this.lastn[c] == this.ncblks.x) {
/*      */         
/*  434 */         this.lastn[c] = 0;
/*  435 */         this.lastm[c] = this.lastm[c] + 1;
/*      */       } 
/*  437 */       if (this.lastm[c] < this.ncblks.y) {
/*      */         break;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  444 */       this.currentSubband[c] = getNextSubband(c);
/*  445 */       this.lastn[c] = -1;
/*  446 */       this.lastm[c] = 0;
/*  447 */       if (this.currentSubband[c] == null) {
/*      */         
/*  449 */         this.decomposedComps[c] = null;
/*      */ 
/*      */ 
/*      */         
/*  453 */         return null;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  463 */     int acb0x = this.cb0x;
/*  464 */     int acb0y = this.cb0y;
/*  465 */     switch ((this.currentSubband[c]).sbandIdx) {
/*      */       case 0:
/*      */         break;
/*      */       
/*      */       case 1:
/*  470 */         acb0x = 0;
/*      */         break;
/*      */       case 2:
/*  473 */         acb0y = 0;
/*      */         break;
/*      */       case 3:
/*  476 */         acb0x = 0;
/*  477 */         acb0y = 0;
/*      */         break;
/*      */       default:
/*  480 */         throw new Error("Internal JJ2000 error");
/*      */     } 
/*      */     
/*  483 */     if (cblk == null) {
/*  484 */       if (this.intData) {
/*  485 */         cblk = new CBlkWTDataInt();
/*      */       } else {
/*  487 */         cblk = new CBlkWTDataFloat();
/*      */       } 
/*      */     }
/*  490 */     int cbn = this.lastn[c];
/*  491 */     int cbm = this.lastm[c];
/*  492 */     SubbandAn sb = this.currentSubband[c];
/*  493 */     cblk.n = cbn;
/*  494 */     cblk.m = cbm;
/*  495 */     cblk.sb = sb;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  502 */     int cn = (sb.ulcx - acb0x + sb.nomCBlkW) / sb.nomCBlkW - 1;
/*  503 */     int cm = (sb.ulcy - acb0y + sb.nomCBlkH) / sb.nomCBlkH - 1;
/*  504 */     if (cbn == 0) {
/*  505 */       cblk.ulx = sb.ulx;
/*      */     } else {
/*      */       
/*  508 */       cblk.ulx = (cn + cbn) * sb.nomCBlkW - sb.ulcx - acb0x + sb.ulx;
/*      */     } 
/*  510 */     if (cbm == 0) {
/*  511 */       cblk.uly = sb.uly;
/*      */     } else {
/*  513 */       cblk.uly = (cm + cbm) * sb.nomCBlkH - sb.ulcy - acb0y + sb.uly;
/*      */     } 
/*  515 */     if (cbn < this.ncblks.x - 1) {
/*      */       
/*  517 */       cblk.w = (cn + cbn + 1) * sb.nomCBlkW - sb.ulcx - acb0x + sb.ulx - cblk.ulx;
/*      */     } else {
/*      */       
/*  520 */       cblk.w = sb.ulx + sb.w - cblk.ulx;
/*      */     } 
/*  522 */     if (cbm < this.ncblks.y - 1) {
/*      */       
/*  524 */       cblk.h = (cm + cbm + 1) * sb.nomCBlkH - sb.ulcy - acb0y + sb.uly - cblk.uly;
/*      */     } else {
/*      */       
/*  527 */       cblk.h = sb.uly + sb.h - cblk.uly;
/*      */     } 
/*  529 */     cblk.wmseScaling = 1.0F;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  534 */     cblk.offset = cblk.uly * (this.decomposedComps[c]).w + cblk.ulx;
/*  535 */     cblk.scanw = (this.decomposedComps[c]).w;
/*      */ 
/*      */     
/*  538 */     cblk.setData(this.decomposedComps[c].getData());
/*      */     
/*  540 */     return cblk;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CBlkWTData getNextCodeBlock(int c, CBlkWTData cblk) {
/*  590 */     this.intData = (this.filters.getWTDataType(this.tIdx, c) == 3);
/*      */     
/*  592 */     Object dst_data = null;
/*      */ 
/*      */     
/*  595 */     if (cblk != null) {
/*  596 */       dst_data = cblk.getData();
/*      */     }
/*      */ 
/*      */     
/*  600 */     cblk = getNextInternCodeBlock(c, cblk);
/*      */     
/*  602 */     if (cblk == null) {
/*  603 */       return null;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  608 */     if (this.intData) {
/*  609 */       int[] dst_data_int = (int[])dst_data;
/*  610 */       if (dst_data_int == null || dst_data_int.length < cblk.w * cblk.h) {
/*  611 */         dst_data = new int[cblk.w * cblk.h];
/*      */       }
/*      */     } else {
/*      */       
/*  615 */       float[] dst_data_float = (float[])dst_data;
/*  616 */       if (dst_data_float == null || dst_data_float.length < cblk.w * cblk.h)
/*      */       {
/*  618 */         dst_data = new float[cblk.w * cblk.h];
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  623 */     Object src_data = cblk.getData();
/*  624 */     int w = cblk.w;
/*  625 */     int j = w * (cblk.h - 1), k = cblk.offset + (cblk.h - 1) * cblk.scanw;
/*  626 */     for (; j >= 0; j -= w, k -= cblk.scanw) {
/*  627 */       System.arraycopy(src_data, k, dst_data, j, w);
/*      */     }
/*  629 */     cblk.setData(dst_data);
/*  630 */     cblk.offset = 0;
/*  631 */     cblk.scanw = w;
/*      */     
/*  633 */     return cblk;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getDataType(int t, int c) {
/*  648 */     return this.filters.getWTDataType(t, c);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private SubbandAn getNextSubband(int c) {
/*  661 */     int down = 1;
/*  662 */     int up = 0;
/*  663 */     int direction = down;
/*      */ 
/*      */     
/*  666 */     SubbandAn nextsb = this.currentSubband[c];
/*      */     
/*  668 */     if (nextsb == null) {
/*  669 */       nextsb = getAnSubbandTree(this.tIdx, c);
/*      */       
/*  671 */       if (!nextsb.isNode) {
/*  672 */         return nextsb;
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  679 */     while (nextsb != null)
/*      */     
/*      */     { 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  686 */       if (!nextsb.isNode) {
/*  687 */         switch (nextsb.orientation) {
/*      */           case 3:
/*  689 */             nextsb = (SubbandAn)nextsb.getParent().getLH();
/*  690 */             direction = down;
/*      */             break;
/*      */           case 2:
/*  693 */             nextsb = (SubbandAn)nextsb.getParent().getHL();
/*  694 */             direction = down;
/*      */             break;
/*      */           case 1:
/*  697 */             nextsb = (SubbandAn)nextsb.getParent().getLL();
/*  698 */             direction = down;
/*      */             break;
/*      */           case 0:
/*  701 */             nextsb = (SubbandAn)nextsb.getParent();
/*  702 */             direction = up;
/*      */             break;
/*      */         } 
/*      */ 
/*      */ 
/*      */       
/*  708 */       } else if (nextsb.isNode) {
/*      */ 
/*      */         
/*  711 */         if (direction == down) {
/*  712 */           nextsb = (SubbandAn)nextsb.getHH();
/*      */ 
/*      */ 
/*      */         
/*      */         }
/*  717 */         else if (direction == up) {
/*  718 */           switch (nextsb.orientation) {
/*      */             case 3:
/*  720 */               nextsb = (SubbandAn)nextsb.getParent().getLH();
/*  721 */               direction = down;
/*      */               break;
/*      */             case 2:
/*  724 */               nextsb = (SubbandAn)nextsb.getParent().getHL();
/*  725 */               direction = down;
/*      */               break;
/*      */             case 1:
/*  728 */               nextsb = (SubbandAn)nextsb.getParent().getLL();
/*  729 */               direction = down;
/*      */               break;
/*      */             case 0:
/*  732 */               nextsb = (SubbandAn)nextsb.getParent();
/*  733 */               direction = up;
/*      */               break;
/*      */           } 
/*      */         
/*      */         } 
/*      */       } 
/*  739 */       if (nextsb == null) {
/*      */         break;
/*      */       }
/*  742 */       if (!nextsb.isNode)
/*  743 */         break;  }  return nextsb;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void waveletTreeDecomposition(DataBlk band, SubbandAn subband, int c) {
/*  762 */     if (!subband.isNode) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*  767 */     wavelet2DDecomposition(band, subband, c);
/*      */ 
/*      */     
/*  770 */     waveletTreeDecomposition(band, (SubbandAn)subband.getHH(), c);
/*  771 */     waveletTreeDecomposition(band, (SubbandAn)subband.getLH(), c);
/*  772 */     waveletTreeDecomposition(band, (SubbandAn)subband.getHL(), c);
/*  773 */     waveletTreeDecomposition(band, (SubbandAn)subband.getLL(), c);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void wavelet2DDecomposition(DataBlk band, SubbandAn subband, int c) {
/*  797 */     if (subband.w == 0 || subband.h == 0) {
/*      */       return;
/*      */     }
/*      */     
/*  801 */     int ulx = subband.ulx;
/*  802 */     int uly = subband.uly;
/*  803 */     int w = subband.w;
/*  804 */     int h = subband.h;
/*  805 */     int band_w = getTileCompWidth(this.tIdx, c);
/*  806 */     int band_h = getTileCompHeight(this.tIdx, c);
/*      */     
/*  808 */     if (this.intData) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  813 */       int[] tmpVector = new int[Math.max(w, h)];
/*      */       
/*  815 */       int[] data = ((DataBlkInt)band).getDataInt();
/*      */ 
/*      */       
/*  818 */       if (subband.ulcy % 2 == 0) {
/*  819 */         for (int j = 0; j < w; j++) {
/*  820 */           int offset = uly * band_w + ulx + j;
/*  821 */           for (int i = 0; i < h; i++)
/*  822 */             tmpVector[i] = data[offset + i * band_w]; 
/*  823 */           subband.vFilter.analyze_lpf(tmpVector, 0, h, 1, data, offset, band_w, data, offset + (h + 1) / 2 * band_w, band_w);
/*      */         
/*      */         }
/*      */       
/*      */       }
/*      */       else {
/*      */         
/*  830 */         for (int j = 0; j < w; j++) {
/*  831 */           int offset = uly * band_w + ulx + j;
/*  832 */           for (int i = 0; i < h; i++)
/*  833 */             tmpVector[i] = data[offset + i * band_w]; 
/*  834 */           subband.vFilter.analyze_hpf(tmpVector, 0, h, 1, data, offset, band_w, data, offset + h / 2 * band_w, band_w);
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  842 */       if (subband.ulcx % 2 == 0) {
/*  843 */         for (int i = 0; i < h; i++) {
/*  844 */           int offset = (uly + i) * band_w + ulx;
/*  845 */           for (byte b = 0; b < w; b++)
/*  846 */             tmpVector[b] = data[offset + b]; 
/*  847 */           subband.hFilter.analyze_lpf(tmpVector, 0, w, 1, data, offset, 1, data, offset + (w + 1) / 2, 1);
/*      */         }
/*      */       
/*      */       }
/*      */       else {
/*      */         
/*  853 */         for (int i = 0; i < h; i++) {
/*  854 */           int offset = (uly + i) * band_w + ulx;
/*  855 */           for (byte b = 0; b < w; b++)
/*  856 */             tmpVector[b] = data[offset + b]; 
/*  857 */           subband.hFilter.analyze_hpf(tmpVector, 0, w, 1, data, offset, 1, data, offset + w / 2, 1);
/*      */         
/*      */         }
/*      */ 
/*      */       
/*      */       }
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */       
/*  868 */       float[] tmpVector = new float[Math.max(w, h)];
/*  869 */       float[] data = ((DataBlkFloat)band).getDataFloat();
/*      */ 
/*      */       
/*  872 */       if (subband.ulcy % 2 == 0) {
/*  873 */         for (int j = 0; j < w; j++) {
/*  874 */           int offset = uly * band_w + ulx + j;
/*  875 */           for (int i = 0; i < h; i++)
/*  876 */             tmpVector[i] = data[offset + i * band_w]; 
/*  877 */           subband.vFilter.analyze_lpf(tmpVector, 0, h, 1, data, offset, band_w, data, offset + (h + 1) / 2 * band_w, band_w);
/*      */         
/*      */         }
/*      */       
/*      */       }
/*      */       else {
/*      */         
/*  884 */         for (int j = 0; j < w; j++) {
/*  885 */           int offset = uly * band_w + ulx + j;
/*  886 */           for (int i = 0; i < h; i++)
/*  887 */             tmpVector[i] = data[offset + i * band_w]; 
/*  888 */           subband.vFilter.analyze_hpf(tmpVector, 0, h, 1, data, offset, band_w, data, offset + h / 2 * band_w, band_w);
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  895 */       if (subband.ulcx % 2 == 0) {
/*  896 */         for (int i = 0; i < h; i++) {
/*  897 */           int offset = (uly + i) * band_w + ulx;
/*  898 */           for (byte b = 0; b < w; b++)
/*  899 */             tmpVector[b] = data[offset + b]; 
/*  900 */           subband.hFilter.analyze_lpf(tmpVector, 0, w, 1, data, offset, 1, data, offset + (w + 1) / 2, 1);
/*      */         }
/*      */       
/*      */       }
/*      */       else {
/*      */         
/*  906 */         for (int i = 0; i < h; i++) {
/*  907 */           int offset = (uly + i) * band_w + ulx;
/*  908 */           for (byte b = 0; b < w; b++)
/*  909 */             tmpVector[b] = data[offset + b]; 
/*  910 */           subband.hFilter.analyze_hpf(tmpVector, 0, w, 1, data, offset, 1, data, offset + w / 2, 1);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTile(int x, int y) {
/*  933 */     super.setTile(x, y);
/*      */ 
/*      */     
/*  936 */     if (this.decomposedComps != null) {
/*  937 */       for (int i = this.decomposedComps.length - 1; i >= 0; i--) {
/*  938 */         this.decomposedComps[i] = null;
/*  939 */         this.currentSubband[i] = null;
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void nextTile() {
/*  958 */     super.nextTile();
/*      */     
/*  960 */     if (this.decomposedComps != null) {
/*  961 */       for (int i = this.decomposedComps.length - 1; i >= 0; i--) {
/*  962 */         this.decomposedComps[i] = null;
/*  963 */         this.currentSubband[i] = null;
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SubbandAn getAnSubbandTree(int t, int c) {
/*  983 */     if (this.subbTrees[t][c] == null) {
/*  984 */       this.subbTrees[t][c] = new SubbandAn(getTileCompWidth(this.tIdx, c), getTileCompHeight(this.tIdx, c), getCompULX(c), getCompULY(c), getDecompLevels(t, c), (WaveletFilter[])getHorAnWaveletFilters(t, c), (WaveletFilter[])getVertAnWaveletFilters(t, c));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  990 */       initSubbandsFields(t, c, this.subbTrees[t][c]);
/*      */     } 
/*  992 */     return this.subbTrees[t][c];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void initSubbandsFields(int t, int c, Subband sb) {
/* 1007 */     int cbw = this.cblks.getCBlkWidth((byte)3, t, c);
/* 1008 */     int cbh = this.cblks.getCBlkHeight((byte)3, t, c);
/*      */     
/* 1010 */     if (!sb.isNode) {
/*      */ 
/*      */ 
/*      */       
/* 1014 */       int ppx = this.pss.getPPX(t, c, sb.resLvl);
/* 1015 */       int ppy = this.pss.getPPY(t, c, sb.resLvl);
/*      */       
/* 1017 */       if (ppx != 65535 || ppy != 65535) {
/*      */ 
/*      */         
/* 1020 */         int ppxExp = MathUtil.log2(ppx);
/* 1021 */         int ppyExp = MathUtil.log2(ppy);
/* 1022 */         int cbwExp = MathUtil.log2(cbw);
/* 1023 */         int cbhExp = MathUtil.log2(cbh);
/*      */ 
/*      */         
/* 1026 */         switch (sb.resLvl) {
/*      */           case 0:
/* 1028 */             sb.nomCBlkW = (cbwExp < ppxExp) ? (1 << cbwExp) : (1 << ppxExp);
/*      */             
/* 1030 */             sb.nomCBlkH = (cbhExp < ppyExp) ? (1 << cbhExp) : (1 << ppyExp);
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/* 1035 */             sb.nomCBlkW = (cbwExp < ppxExp - 1) ? (1 << cbwExp) : (1 << ppxExp - 1);
/*      */             
/* 1037 */             sb.nomCBlkH = (cbhExp < ppyExp - 1) ? (1 << cbhExp) : (1 << ppyExp - 1);
/*      */             break;
/*      */         } 
/*      */       
/*      */       } else {
/* 1042 */         sb.nomCBlkW = cbw;
/* 1043 */         sb.nomCBlkH = cbh;
/*      */       } 
/*      */ 
/*      */       
/* 1047 */       if (sb.numCb == null) sb.numCb = new Point(); 
/* 1048 */       if (sb.w != 0 && sb.h != 0) {
/* 1049 */         int acb0x = this.cb0x;
/* 1050 */         int acb0y = this.cb0y;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1058 */         switch (sb.sbandIdx) {
/*      */           case 0:
/*      */             break;
/*      */           
/*      */           case 1:
/* 1063 */             acb0x = 0;
/*      */             break;
/*      */           case 2:
/* 1066 */             acb0y = 0;
/*      */             break;
/*      */           case 3:
/* 1069 */             acb0x = 0;
/* 1070 */             acb0y = 0;
/*      */             break;
/*      */           default:
/* 1073 */             throw new Error("Internal JJ2000 error");
/*      */         } 
/* 1075 */         if (sb.ulcx - acb0x < 0 || sb.ulcy - acb0y < 0) {
/* 1076 */           throw new IllegalArgumentException("Invalid code-blocks partition origin or image offset in the reference grid.");
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1085 */         int tmp = sb.ulcx - acb0x + sb.nomCBlkW;
/* 1086 */         sb.numCb.x = (tmp + sb.w - 1) / sb.nomCBlkW - tmp / sb.nomCBlkW - 1;
/* 1087 */         tmp = sb.ulcy - acb0y + sb.nomCBlkH;
/* 1088 */         sb.numCb.y = (tmp + sb.h - 1) / sb.nomCBlkH - tmp / sb.nomCBlkH - 1;
/*      */       } else {
/* 1090 */         sb.numCb.x = sb.numCb.y = 0;
/*      */       } 
/*      */     } else {
/* 1093 */       initSubbandsFields(t, c, sb.getLL());
/* 1094 */       initSubbandsFields(t, c, sb.getHL());
/* 1095 */       initSubbandsFields(t, c, sb.getLH());
/* 1096 */       initSubbandsFields(t, c, sb.getHH());
/*      */     } 
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/wavelet/analysis/ForwWTFull.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */