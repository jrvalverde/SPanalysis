package jj2000.j2k.wavelet.synthesis;

import jj2000.j2k.image.DataBlk;

public interface CBlkWTDataSrcDec extends InvWTData {
  int getNomRangeBits(int paramInt);
  
  int getFixedPoint(int paramInt);
  
  DataBlk getCodeBlock(int paramInt1, int paramInt2, int paramInt3, SubbandSyn paramSubbandSyn, DataBlk paramDataBlk);
  
  DataBlk getInternCodeBlock(int paramInt1, int paramInt2, int paramInt3, SubbandSyn paramSubbandSyn, DataBlk paramDataBlk);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/wavelet/synthesis/CBlkWTDataSrcDec.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */