/*     */ package jj2000.j2k.decoder;
/*     */ 
/*     */ import jj2000.j2k.IntegerSpec;
/*     */ import jj2000.j2k.ModuleSpec;
/*     */ import jj2000.j2k.entropy.CBlkSizeSpec;
/*     */ import jj2000.j2k.entropy.PrecinctSizeSpec;
/*     */ import jj2000.j2k.image.CompTransfSpec;
/*     */ import jj2000.j2k.quantization.GuardBitsSpec;
/*     */ import jj2000.j2k.quantization.QuantStepSizeSpec;
/*     */ import jj2000.j2k.quantization.QuantTypeSpec;
/*     */ import jj2000.j2k.roi.MaxShiftSpec;
/*     */ import jj2000.j2k.wavelet.synthesis.SynWTFilterSpec;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DecoderSpecs
/*     */   implements Cloneable
/*     */ {
/*     */   public ModuleSpec iccs;
/*     */   public MaxShiftSpec rois;
/*     */   public QuantTypeSpec qts;
/*     */   public QuantStepSizeSpec qsss;
/*     */   public GuardBitsSpec gbs;
/*     */   public SynWTFilterSpec wfs;
/*     */   public IntegerSpec dls;
/*     */   public IntegerSpec nls;
/*     */   public IntegerSpec pos;
/*     */   public ModuleSpec ecopts;
/*     */   public CompTransfSpec cts;
/*     */   public ModuleSpec pcs;
/*     */   public ModuleSpec ers;
/*     */   public PrecinctSizeSpec pss;
/*     */   public ModuleSpec sops;
/*     */   public ModuleSpec ephs;
/*     */   public CBlkSizeSpec cblks;
/*     */   public ModuleSpec pphs;
/*     */   
/*     */   public DecoderSpecs getCopy() {
/*     */     DecoderSpecs decSpec2;
/*     */     try {
/* 163 */       decSpec2 = (DecoderSpecs)clone();
/* 164 */     } catch (CloneNotSupportedException e) {
/* 165 */       throw new Error("Cannot clone the DecoderSpecs instance");
/*     */     } 
/*     */     
/* 168 */     decSpec2.qts = (QuantTypeSpec)this.qts.getCopy();
/* 169 */     decSpec2.qsss = (QuantStepSizeSpec)this.qsss.getCopy();
/* 170 */     decSpec2.gbs = (GuardBitsSpec)this.gbs.getCopy();
/*     */     
/* 172 */     decSpec2.wfs = (SynWTFilterSpec)this.wfs.getCopy();
/* 173 */     decSpec2.dls = (IntegerSpec)this.dls.getCopy();
/*     */     
/* 175 */     decSpec2.cts = (CompTransfSpec)this.cts.getCopy();
/*     */     
/* 177 */     if (this.rois != null) {
/* 178 */       decSpec2.rois = (MaxShiftSpec)this.rois.getCopy();
/*     */     }
/* 180 */     return decSpec2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DecoderSpecs(int nt, int nc) {
/* 193 */     this.qts = new QuantTypeSpec(nt, nc, (byte)2);
/* 194 */     this.qsss = new QuantStepSizeSpec(nt, nc, (byte)2);
/* 195 */     this.gbs = new GuardBitsSpec(nt, nc, (byte)2);
/*     */ 
/*     */     
/* 198 */     this.wfs = new SynWTFilterSpec(nt, nc, (byte)2);
/* 199 */     this.dls = new IntegerSpec(nt, nc, (byte)2);
/*     */ 
/*     */     
/* 202 */     this.cts = new CompTransfSpec(nt, nc, (byte)2);
/*     */ 
/*     */     
/* 205 */     this.ecopts = new ModuleSpec(nt, nc, (byte)2);
/* 206 */     this.ers = new ModuleSpec(nt, nc, (byte)2);
/* 207 */     this.cblks = new CBlkSizeSpec(nt, nc, (byte)2);
/*     */ 
/*     */     
/* 210 */     this.pss = new PrecinctSizeSpec(nt, nc, (byte)2, this.dls);
/*     */ 
/*     */     
/* 213 */     this.nls = new IntegerSpec(nt, nc, (byte)1);
/* 214 */     this.pos = new IntegerSpec(nt, nc, (byte)1);
/* 215 */     this.pcs = new ModuleSpec(nt, nc, (byte)1);
/* 216 */     this.sops = new ModuleSpec(nt, nc, (byte)1);
/* 217 */     this.ephs = new ModuleSpec(nt, nc, (byte)1);
/* 218 */     this.pphs = new ModuleSpec(nt, nc, (byte)1);
/* 219 */     this.iccs = new ModuleSpec(nt, nc, (byte)1);
/* 220 */     this.pphs.setDefault(new Boolean(false));
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/decoder/DecoderSpecs.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */