package jj2000.j2k.io;

import java.io.EOFException;
import java.io.IOException;

public interface BinaryDataInput {
  byte readByte() throws EOFException, IOException;
  
  int readUnsignedByte() throws EOFException, IOException;
  
  short readShort() throws EOFException, IOException;
  
  int readUnsignedShort() throws EOFException, IOException;
  
  int readInt() throws EOFException, IOException;
  
  long readUnsignedInt() throws EOFException, IOException;
  
  long readLong() throws EOFException, IOException;
  
  float readFloat() throws EOFException, IOException;
  
  double readDouble() throws EOFException, IOException;
  
  int getByteOrdering();
  
  int skipBytes(int paramInt) throws EOFException, IOException;
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/io/BinaryDataInput.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */