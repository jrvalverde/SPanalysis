/*     */ package jj2000.j2k.io;
/*     */ 
/*     */ import java.io.EOFException;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BEBufferedRandomAccessFile
/*     */   extends BufferedRandomAccessFile
/*     */   implements RandomAccessIO, EndianType
/*     */ {
/*     */   public BEBufferedRandomAccessFile(File file, String mode, int bufferSize) throws IOException {
/* 114 */     super(file, mode, bufferSize);
/* 115 */     this.byteOrdering = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BEBufferedRandomAccessFile(File file, String mode) throws IOException {
/* 133 */     super(file, mode);
/* 134 */     this.byteOrdering = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BEBufferedRandomAccessFile(String name, String mode, int bufferSize) throws IOException {
/* 154 */     super(name, mode, bufferSize);
/* 155 */     this.byteOrdering = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BEBufferedRandomAccessFile(String name, String mode) throws IOException {
/* 173 */     super(name, mode);
/* 174 */     this.byteOrdering = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void writeShort(int v) throws IOException {
/* 192 */     write(v >>> 8);
/* 193 */     write(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void writeInt(int v) throws IOException {
/* 206 */     write(v >>> 24);
/* 207 */     write(v >>> 16);
/* 208 */     write(v >>> 8);
/* 209 */     write(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void writeLong(long v) throws IOException {
/* 222 */     write((int)(v >>> 56L));
/* 223 */     write((int)(v >>> 48L));
/* 224 */     write((int)(v >>> 40L));
/* 225 */     write((int)(v >>> 32L));
/* 226 */     write((int)(v >>> 24L));
/* 227 */     write((int)(v >>> 16L));
/* 228 */     write((int)(v >>> 8L));
/* 229 */     write((int)v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void writeFloat(float v) throws IOException {
/* 242 */     int intV = Float.floatToIntBits(v);
/*     */     
/* 244 */     write(intV >>> 24);
/* 245 */     write(intV >>> 16);
/* 246 */     write(intV >>> 8);
/* 247 */     write(intV);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void writeDouble(double v) throws IOException {
/* 260 */     long longV = Double.doubleToLongBits(v);
/*     */     
/* 262 */     write((int)(longV >>> 56L));
/* 263 */     write((int)(longV >>> 48L));
/* 264 */     write((int)(longV >>> 40L));
/* 265 */     write((int)(longV >>> 32L));
/* 266 */     write((int)(longV >>> 24L));
/* 267 */     write((int)(longV >>> 16L));
/* 268 */     write((int)(longV >>> 8L));
/* 269 */     write((int)longV);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final short readShort() throws IOException, EOFException {
/* 285 */     return (short)(read() << 8 | read());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int readUnsignedShort() throws IOException, EOFException {
/* 306 */     return read() << 8 | read();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int readInt() throws IOException, EOFException {
/* 325 */     return read() << 24 | read() << 16 | read() << 8 | read();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final long readUnsignedInt() throws IOException, EOFException {
/* 347 */     return (read() << 24 | read() << 16 | read() << 8 | read());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final long readLong() throws IOException, EOFException {
/* 368 */     return read() << 56L | read() << 48L | read() << 40L | read() << 32L | read() << 24L | read() << 16L | read() << 8L | read();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final float readFloat() throws EOFException, IOException {
/* 394 */     return Float.intBitsToFloat(read() << 24 | read() << 16 | read() << 8 | read());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final double readDouble() throws IOException, EOFException {
/* 416 */     return Double.longBitsToDouble(read() << 56L | read() << 48L | read() << 40L | read() << 32L | read() << 24L | read() << 16L | read() << 8L | read());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 432 */     return super.toString() + "\nBig-Endian ordering";
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/io/BEBufferedRandomAccessFile.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */