/*     */ package jj2000.j2k.io;
/*     */ 
/*     */ import java.io.EOFException;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.RandomAccessFile;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BufferedRandomAccessFile
/*     */   implements RandomAccessIO, EndianType
/*     */ {
/*     */   private String fileName;
/*     */   private boolean isReadOnly = true;
/*     */   private RandomAccessFile theFile;
/*     */   protected byte[] byteBuffer;
/*     */   protected boolean byteBufferChanged;
/*     */   protected int offset;
/*     */   protected int pos;
/*     */   protected int maxByte;
/*     */   protected boolean isEOFInBuffer;
/*     */   protected int byteOrdering;
/*     */   
/*     */   protected BufferedRandomAccessFile(File file, String mode, int bufferSize) throws IOException {
/* 178 */     this.fileName = file.getName();
/* 179 */     if (mode.equals("rw") || mode.equals("rw+")) {
/* 180 */       this.isReadOnly = false;
/* 181 */       if (mode.equals("rw") && 
/* 182 */         file.exists()) {
/* 183 */         file.delete();
/*     */       }
/* 185 */       mode = "rw";
/*     */     } 
/* 187 */     this.theFile = new RandomAccessFile(file, mode);
/* 188 */     this.byteBuffer = new byte[bufferSize];
/* 189 */     readNewBuffer(0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BufferedRandomAccessFile(File file, String mode) throws IOException {
/* 208 */     this(file, mode, 512);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BufferedRandomAccessFile(String name, String mode, int bufferSize) throws IOException {
/* 228 */     this(new File(name), mode, bufferSize);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BufferedRandomAccessFile(String name, String mode) throws IOException {
/* 247 */     this(name, mode, 512);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void readNewBuffer(int off) throws IOException {
/* 264 */     if (this.byteBufferChanged) {
/* 265 */       flush();
/*     */     }
/*     */     
/* 268 */     if (this.isReadOnly && off >= this.theFile.length()) {
/* 269 */       throw new EOFException();
/*     */     }
/*     */     
/* 272 */     this.offset = off;
/*     */     
/* 274 */     this.theFile.seek(this.offset);
/*     */     
/* 276 */     this.maxByte = this.theFile.read(this.byteBuffer, 0, this.byteBuffer.length);
/* 277 */     this.pos = 0;
/*     */     
/* 279 */     if (this.maxByte < this.byteBuffer.length) {
/* 280 */       this.isEOFInBuffer = true;
/* 281 */       if (this.maxByte == -1) {
/* 282 */         this.maxByte++;
/*     */       }
/*     */     } else {
/* 285 */       this.isEOFInBuffer = false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 298 */     flush();
/* 299 */     this.byteBuffer = null;
/* 300 */     this.theFile.close();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPos() {
/* 307 */     return this.offset + this.pos;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int length() throws IOException {
/* 321 */     int len = (int)this.theFile.length();
/*     */ 
/*     */ 
/*     */     
/* 325 */     if (this.offset + this.maxByte <= len) {
/* 326 */       return len;
/*     */     }
/*     */     
/* 329 */     return this.offset + this.maxByte;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void seek(int off) throws IOException {
/* 347 */     if (off >= this.offset && off < this.offset + this.byteBuffer.length) {
/* 348 */       if (this.isReadOnly && this.isEOFInBuffer && off > this.offset + this.maxByte)
/*     */       {
/* 350 */         throw new EOFException();
/*     */       }
/* 352 */       this.pos = off - this.offset;
/*     */     } else {
/*     */       
/* 355 */       readNewBuffer(off);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int read() throws IOException, EOFException {
/* 370 */     if (this.pos < this.maxByte)
/*     */     {
/* 372 */       return this.byteBuffer[this.pos++] & 0xFF;
/*     */     }
/* 374 */     if (this.isEOFInBuffer) {
/* 375 */       this.pos = this.maxByte + 1;
/* 376 */       throw new EOFException();
/*     */     } 
/*     */     
/* 379 */     readNewBuffer(this.offset + this.pos);
/* 380 */     return read();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void readFully(byte[] b, int off, int len) throws IOException {
/* 405 */     while (len > 0) {
/*     */       
/* 407 */       if (this.pos < this.maxByte) {
/* 408 */         int clen = this.maxByte - this.pos;
/* 409 */         if (clen > len) clen = len; 
/* 410 */         System.arraycopy(this.byteBuffer, this.pos, b, off, clen);
/* 411 */         this.pos += clen;
/* 412 */         off += clen;
/* 413 */         len -= clen; continue;
/*     */       } 
/* 415 */       if (this.isEOFInBuffer) {
/* 416 */         this.pos = this.maxByte + 1;
/* 417 */         throw new EOFException();
/*     */       } 
/*     */       
/* 420 */       readNewBuffer(this.offset + this.pos);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void write(int b) throws IOException {
/* 438 */     if (this.pos < this.byteBuffer.length) {
/* 439 */       if (this.isReadOnly)
/* 440 */         throw new IOException("File is read only"); 
/* 441 */       this.byteBuffer[this.pos] = (byte)b;
/* 442 */       if (this.pos >= this.maxByte) {
/* 443 */         this.maxByte = this.pos + 1;
/*     */       }
/* 445 */       this.pos++;
/* 446 */       this.byteBufferChanged = true;
/*     */     } else {
/*     */       
/* 449 */       readNewBuffer(this.offset + this.pos);
/* 450 */       write(b);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void write(byte b) throws IOException {
/* 466 */     if (this.pos < this.byteBuffer.length) {
/* 467 */       if (this.isReadOnly)
/* 468 */         throw new IOException("File is read only"); 
/* 469 */       this.byteBuffer[this.pos] = b;
/* 470 */       if (this.pos >= this.maxByte) {
/* 471 */         this.maxByte = this.pos + 1;
/*     */       }
/* 473 */       this.pos++;
/* 474 */       this.byteBufferChanged = true;
/*     */     } else {
/*     */       
/* 477 */       readNewBuffer(this.offset + this.pos);
/* 478 */       write(b);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void write(byte[] b, int offset, int length) throws IOException {
/* 497 */     int stop = offset + length;
/* 498 */     if (stop > b.length)
/* 499 */       throw new ArrayIndexOutOfBoundsException(b.length); 
/* 500 */     for (int i = offset; i < stop; i++) {
/* 501 */       write(b[i]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void writeByte(int v) throws IOException {
/* 521 */     write(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void flush() throws IOException {
/* 532 */     if (this.byteBufferChanged) {
/* 533 */       this.theFile.seek(this.offset);
/* 534 */       this.theFile.write(this.byteBuffer, 0, this.maxByte);
/* 535 */       this.byteBufferChanged = false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final byte readByte() throws EOFException, IOException {
/* 552 */     if (this.pos < this.maxByte)
/*     */     {
/* 554 */       return this.byteBuffer[this.pos++];
/*     */     }
/* 556 */     if (this.isEOFInBuffer) {
/* 557 */       this.pos = this.maxByte + 1;
/* 558 */       throw new EOFException();
/*     */     } 
/*     */     
/* 561 */     readNewBuffer(this.offset + this.pos);
/* 562 */     return readByte();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int readUnsignedByte() throws EOFException, IOException {
/* 581 */     return read();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getByteOrdering() {
/* 596 */     return this.byteOrdering;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int skipBytes(int n) throws EOFException, IOException {
/* 611 */     if (n < 0) {
/* 612 */       throw new IllegalArgumentException("Can not skip negative number of bytes");
/*     */     }
/* 614 */     if (n <= this.maxByte - this.pos) {
/* 615 */       this.pos += n;
/* 616 */       return n;
/*     */     } 
/*     */     
/* 619 */     seek(this.offset + this.pos + n);
/* 620 */     return n;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 628 */     return "BufferedRandomAccessFile: " + this.fileName + " (" + (this.isReadOnly ? "read only" : "read/write") + ")";
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/io/BufferedRandomAccessFile.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */