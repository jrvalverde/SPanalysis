package jj2000.j2k.io;

public interface EndianType {
  public static final int BIG_ENDIAN = 0;
  
  public static final int LITTLE_ENDIAN = 1;
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/io/EndianType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */