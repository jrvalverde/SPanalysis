package jj2000.j2k.io;

import java.io.EOFException;
import java.io.IOException;

public interface RandomAccessIO extends BinaryDataInput, BinaryDataOutput {
  void close() throws IOException;
  
  int getPos() throws IOException;
  
  int length() throws IOException;
  
  void seek(int paramInt) throws IOException;
  
  int read() throws EOFException, IOException;
  
  void readFully(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException;
  
  void write(int paramInt) throws IOException;
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/io/RandomAccessIO.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */