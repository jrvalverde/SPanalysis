/*     */ package jj2000.j2k.quantization;
/*     */ 
/*     */ import com.sun.media.imageioimpl.plugins.jpeg2000.J2KImageWriteParamJava;
/*     */ import java.util.StringTokenizer;
/*     */ import jj2000.j2k.ModuleSpec;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GuardBitsSpec
/*     */   extends ModuleSpec
/*     */ {
/*  97 */   private String defaultValue = "2";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GuardBitsSpec(int nt, int nc, byte type) {
/* 111 */     super(nt, nc, type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GuardBitsSpec(int nt, int nc, byte type, J2KImageWriteParamJava wp, String values) {
/* 126 */     super(nt, nc, type);
/*     */ 
/*     */     
/* 129 */     if (values == null) {
/* 130 */       setDefault(new Integer(this.defaultValue));
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 136 */     String param = values;
/*     */     
/* 138 */     StringTokenizer stk = new StringTokenizer(param);
/*     */     
/* 140 */     byte curSpecType = 0;
/*     */     
/* 142 */     boolean[] tileSpec = null;
/* 143 */     boolean[] compSpec = null;
/*     */ 
/*     */     
/* 146 */     while (stk.hasMoreTokens()) {
/* 147 */       Integer value; String word = stk.nextToken().toLowerCase();
/*     */       
/* 149 */       switch (word.charAt(0)) {
/*     */         case 't':
/* 151 */           tileSpec = parseIdx(word, this.nTiles);
/* 152 */           if (curSpecType == 1) {
/* 153 */             curSpecType = 3; continue;
/*     */           } 
/* 155 */           curSpecType = 2;
/*     */           continue;
/*     */         case 'c':
/* 158 */           compSpec = parseIdx(word, this.nComp);
/* 159 */           if (curSpecType == 2) {
/* 160 */             curSpecType = 3; continue;
/*     */           } 
/* 162 */           curSpecType = 1;
/*     */           continue;
/*     */       } 
/*     */       try {
/* 166 */         value = new Integer(word);
/*     */       }
/* 168 */       catch (NumberFormatException e) {
/* 169 */         throw new IllegalArgumentException("Bad parameter for -Qguard_bits option : " + word);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 174 */       if (value.floatValue() <= 0.0F) {
/* 175 */         throw new IllegalArgumentException("Guard bits value must be positive : " + value);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 181 */       if (curSpecType == 0) {
/* 182 */         setDefault(value);
/*     */       }
/* 184 */       else if (curSpecType == 2) {
/* 185 */         for (int i = tileSpec.length - 1; i >= 0; i--) {
/* 186 */           if (tileSpec[i]) {
/* 187 */             setTileDef(i, value);
/*     */           }
/*     */         } 
/* 190 */       } else if (curSpecType == 1) {
/* 191 */         for (int i = compSpec.length - 1; i >= 0; i--) {
/* 192 */           if (compSpec[i]) {
/* 193 */             setCompDef(i, value);
/*     */           }
/*     */         } 
/*     */       } else {
/* 197 */         for (int i = tileSpec.length - 1; i >= 0; i--) {
/* 198 */           for (int j = compSpec.length - 1; j >= 0; j--) {
/* 199 */             if (tileSpec[i] && compSpec[j]) {
/* 200 */               setTileCompVal(i, j, value);
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 207 */       curSpecType = 0;
/* 208 */       tileSpec = null;
/* 209 */       compSpec = null;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 215 */     if (getDefault() == null) {
/* 216 */       int ndefspec = 0;
/* 217 */       for (int t = nt - 1; t >= 0; t--) {
/* 218 */         for (int c = nc - 1; c >= 0; c--) {
/* 219 */           if (this.specValType[t][c] == 0) {
/* 220 */             ndefspec++;
/*     */           }
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 227 */       if (ndefspec != 0) {
/* 228 */         setDefault(new Integer(this.defaultValue));
/*     */       } else {
/*     */         int c, i;
/*     */ 
/*     */         
/* 233 */         setDefault(getTileCompVal(0, 0));
/* 234 */         switch (this.specValType[0][0]) {
/*     */           case 2:
/* 236 */             for (c = nc - 1; c >= 0; c--) {
/* 237 */               if (this.specValType[0][c] == 2)
/* 238 */                 this.specValType[0][c] = 0; 
/*     */             } 
/* 240 */             this.tileDef[0] = null;
/*     */             break;
/*     */           case 1:
/* 243 */             for (i = nt - 1; i >= 0; i--) {
/* 244 */               if (this.specValType[i][0] == 1)
/* 245 */                 this.specValType[i][0] = 0; 
/*     */             } 
/* 247 */             this.compDef[0] = null;
/*     */             break;
/*     */           case 3:
/* 250 */             this.specValType[0][0] = 0;
/* 251 */             this.tileCompVal.put("t0c0", null);
/*     */             break;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/quantization/GuardBitsSpec.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */