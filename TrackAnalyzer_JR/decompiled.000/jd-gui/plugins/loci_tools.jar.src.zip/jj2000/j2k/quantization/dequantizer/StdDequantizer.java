/*     */ package jj2000.j2k.quantization.dequantizer;
/*     */ 
/*     */ import jj2000.j2k.decoder.DecoderSpecs;
/*     */ import jj2000.j2k.image.DataBlk;
/*     */ import jj2000.j2k.image.DataBlkFloat;
/*     */ import jj2000.j2k.image.DataBlkInt;
/*     */ import jj2000.j2k.quantization.GuardBitsSpec;
/*     */ import jj2000.j2k.quantization.QuantStepSizeSpec;
/*     */ import jj2000.j2k.quantization.QuantTypeSpec;
/*     */ import jj2000.j2k.wavelet.synthesis.SubbandSyn;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StdDequantizer
/*     */   extends Dequantizer
/*     */ {
/*     */   private QuantTypeSpec qts;
/*     */   private QuantStepSizeSpec qsss;
/*     */   private GuardBitsSpec gbs;
/*     */   private StdDequantizerParams params;
/*     */   private DataBlkInt inblk;
/*     */   private int outdtype;
/*     */   
/*     */   public StdDequantizer(CBlkQuantDataSrcDec src, int[] utrb, DecoderSpecs decSpec) {
/* 168 */     super(src, utrb, decSpec);
/*     */     
/* 170 */     if (utrb.length != src.getNumComps()) {
/* 171 */       throw new IllegalArgumentException("Invalid rb argument");
/*     */     }
/* 173 */     this.qsss = decSpec.qsss;
/* 174 */     this.qts = decSpec.qts;
/* 175 */     this.gbs = decSpec.gbs;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFixedPoint(int c) {
/* 197 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final DataBlk getCodeBlock(int c, int m, int n, SubbandSyn sb, DataBlk cblk) {
/* 241 */     return getInternCodeBlock(c, m, n, sb, cblk);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final DataBlk getInternCodeBlock(int c, int m, int n, SubbandSyn sb, DataBlk cblk) {
/*     */     DataBlkFloat dataBlkFloat;
/* 295 */     boolean reversible = this.qts.isReversible(this.tIdx, c);
/* 296 */     boolean derived = this.qts.isDerived(this.tIdx, c);
/*     */     
/* 298 */     StdDequantizerParams params = (StdDequantizerParams)this.qsss.getTileCompVal(this.tIdx, c);
/* 299 */     int G = ((Integer)this.gbs.getTileCompVal(this.tIdx, c)).intValue();
/*     */     
/* 301 */     this.outdtype = cblk.getDataType();
/*     */     
/* 303 */     if (reversible && this.outdtype != 3) {
/* 304 */       throw new IllegalArgumentException("Reversible quantizations must use int data");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 309 */     int[] outiarr = null;
/* 310 */     float[] outfarr = null;
/* 311 */     int[] inarr = null;
/*     */ 
/*     */     
/* 314 */     switch (this.outdtype) {
/*     */ 
/*     */ 
/*     */       
/*     */       case 3:
/* 319 */         cblk = this.src.getCodeBlock(c, m, n, sb, cblk);
/*     */         
/* 321 */         outiarr = (int[])cblk.getData();
/*     */         break;
/*     */ 
/*     */       
/*     */       case 4:
/* 326 */         this.inblk = (DataBlkInt)this.src.getInternCodeBlock(c, m, n, sb, (DataBlk)this.inblk);
/* 327 */         inarr = this.inblk.getDataInt();
/* 328 */         if (cblk == null) {
/* 329 */           dataBlkFloat = new DataBlkFloat();
/*     */         }
/*     */         
/* 332 */         ((DataBlk)dataBlkFloat).ulx = this.inblk.ulx;
/* 333 */         ((DataBlk)dataBlkFloat).uly = this.inblk.uly;
/* 334 */         ((DataBlk)dataBlkFloat).w = this.inblk.w;
/* 335 */         ((DataBlk)dataBlkFloat).h = this.inblk.h;
/* 336 */         ((DataBlk)dataBlkFloat).offset = 0;
/* 337 */         ((DataBlk)dataBlkFloat).scanw = ((DataBlk)dataBlkFloat).w;
/* 338 */         ((DataBlk)dataBlkFloat).progressive = this.inblk.progressive;
/*     */         
/* 340 */         outfarr = (float[])dataBlkFloat.getData();
/* 341 */         if (outfarr == null || outfarr.length < ((DataBlk)dataBlkFloat).w * ((DataBlk)dataBlkFloat).h) {
/* 342 */           outfarr = new float[((DataBlk)dataBlkFloat).w * ((DataBlk)dataBlkFloat).h];
/* 343 */           dataBlkFloat.setData(outfarr);
/*     */         } 
/*     */         break;
/*     */     } 
/*     */     
/* 348 */     int magBits = sb.magbits;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 353 */     if (reversible) {
/* 354 */       int shiftBits = 31 - magBits;
/*     */ 
/*     */ 
/*     */       
/* 358 */       for (int j = outiarr.length - 1; j >= 0; j--) {
/* 359 */         int temp = outiarr[j];
/* 360 */         outiarr[j] = (temp >= 0) ? (temp >> shiftBits) : -((temp & Integer.MAX_VALUE) >> shiftBits);
/*     */       } 
/*     */     } else {
/*     */       int j, jmin, k; float step;
/*     */       int w, h;
/* 365 */       if (derived) {
/*     */         
/* 367 */         int mrl = (this.src.getSynSubbandTree(getTileIdx(), c)).resLvl;
/* 368 */         step = params.nStep[0][0] * (float)(1L << this.rb[c] + sb.anGainExp + mrl - sb.level);
/*     */       }
/*     */       else {
/*     */         
/* 372 */         step = params.nStep[sb.resLvl][sb.sbandIdx] * (float)(1L << this.rb[c] + sb.anGainExp);
/*     */       } 
/*     */       
/* 375 */       int shiftBits = 31 - magBits;
/*     */ 
/*     */       
/* 378 */       step /= (1 << shiftBits);
/*     */       
/* 380 */       switch (this.outdtype) {
/*     */ 
/*     */ 
/*     */         
/*     */         case 3:
/* 385 */           for (j = outiarr.length - 1; j >= 0; j--) {
/* 386 */             int temp = outiarr[j];
/* 387 */             outiarr[j] = (int)(((temp >= 0) ? temp : -(temp & Integer.MAX_VALUE)) * step);
/*     */           } 
/*     */           break;
/*     */ 
/*     */ 
/*     */         
/*     */         case 4:
/* 394 */           w = ((DataBlk)dataBlkFloat).w;
/* 395 */           h = ((DataBlk)dataBlkFloat).h;
/* 396 */           j = w * h - 1; k = this.inblk.offset + (h - 1) * this.inblk.scanw + w - 1;
/* 397 */           for (jmin = w * (h - 1); j >= 0; jmin -= w) {
/* 398 */             for (; j >= jmin; k--, j--) {
/* 399 */               int i = inarr[k];
/* 400 */               outfarr[j] = ((i >= 0) ? i : -(i & Integer.MAX_VALUE)) * step;
/*     */             } 
/*     */ 
/*     */             
/* 404 */             k -= this.inblk.scanw - w;
/*     */           } 
/*     */           break;
/*     */       } 
/*     */     
/*     */     } 
/* 410 */     return (DataBlk)dataBlkFloat;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/quantization/dequantizer/StdDequantizer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */