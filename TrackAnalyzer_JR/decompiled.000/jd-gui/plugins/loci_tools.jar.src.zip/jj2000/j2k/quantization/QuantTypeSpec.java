/*     */ package jj2000.j2k.quantization;
/*     */ 
/*     */ import com.sun.media.imageioimpl.plugins.jpeg2000.J2KImageWriteParamJava;
/*     */ import java.util.StringTokenizer;
/*     */ import jj2000.j2k.ModuleSpec;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class QuantTypeSpec
/*     */   extends ModuleSpec
/*     */ {
/*     */   public QuantTypeSpec(int nt, int nc, byte type) {
/* 118 */     super(nt, nc, type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QuantTypeSpec(int nt, int nc, byte type, J2KImageWriteParamJava wp, String values) {
/* 135 */     super(nt, nc, type);
/*     */     
/* 137 */     if (values == null) {
/* 138 */       if (wp.getLossless()) {
/* 139 */         setDefault("reversible");
/*     */       } else {
/* 141 */         setDefault("expounded");
/*     */       } 
/*     */       
/*     */       return;
/*     */     } 
/* 146 */     this.specified = values;
/* 147 */     String param = values;
/*     */     
/* 149 */     StringTokenizer stk = new StringTokenizer(param);
/*     */     
/* 151 */     byte curSpecValType = 0;
/*     */     
/* 153 */     boolean[] tileSpec = null;
/* 154 */     boolean[] compSpec = null;
/*     */     
/* 156 */     while (stk.hasMoreTokens()) {
/* 157 */       String word = stk.nextToken().toLowerCase();
/*     */       
/* 159 */       switch (word.charAt(0)) {
/*     */         case 't':
/* 161 */           tileSpec = parseIdx(word, this.nTiles);
/* 162 */           if (curSpecValType == 1) {
/* 163 */             curSpecValType = 3;
/*     */             continue;
/*     */           } 
/* 166 */           curSpecValType = 2;
/*     */           continue;
/*     */         
/*     */         case 'c':
/* 170 */           compSpec = parseIdx(word, this.nComp);
/* 171 */           if (curSpecValType == 2) {
/* 172 */             curSpecValType = 3;
/*     */             continue;
/*     */           } 
/* 175 */           curSpecValType = 1;
/*     */           continue;
/*     */         case 'd':
/*     */         case 'e':
/*     */         case 'r':
/* 180 */           if (!word.equalsIgnoreCase("reversible") && !word.equalsIgnoreCase("derived") && !word.equalsIgnoreCase("expounded"))
/*     */           {
/*     */             
/* 183 */             throw new IllegalArgumentException("Unknown parameter for '-Qtype' option: " + word);
/*     */           }
/*     */ 
/*     */ 
/*     */           
/* 188 */           if (wp.getLossless() && (word.equalsIgnoreCase("derived") || word.equalsIgnoreCase("expounded")))
/*     */           {
/*     */             
/* 191 */             throw new IllegalArgumentException("Cannot use non reversible quantization with '-lossless' option");
/*     */           }
/*     */ 
/*     */ 
/*     */           
/* 196 */           if (curSpecValType == 0) {
/* 197 */             setDefault(word);
/*     */           }
/* 199 */           else if (curSpecValType == 2) {
/* 200 */             for (int i = tileSpec.length - 1; i >= 0; i--) {
/* 201 */               if (tileSpec[i]) {
/* 202 */                 setTileDef(i, word);
/*     */               }
/*     */             } 
/* 205 */           } else if (curSpecValType == 1) {
/* 206 */             for (int i = compSpec.length - 1; i >= 0; i--) {
/* 207 */               if (compSpec[i]) {
/* 208 */                 setCompDef(i, word);
/*     */               }
/*     */             } 
/*     */           } else {
/* 212 */             for (int i = tileSpec.length - 1; i >= 0; i--) {
/* 213 */               for (int j = compSpec.length - 1; j >= 0; j--) {
/* 214 */                 if (tileSpec[i] && compSpec[j]) {
/* 215 */                   setTileCompVal(i, j, word);
/*     */                 }
/*     */               } 
/*     */             } 
/*     */           } 
/*     */ 
/*     */           
/* 222 */           curSpecValType = 0;
/* 223 */           tileSpec = null;
/* 224 */           compSpec = null;
/*     */           continue;
/*     */       } 
/*     */       
/* 228 */       throw new IllegalArgumentException("Unknown parameter for '-Qtype' option: " + word);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 234 */     if (getDefault() == null) {
/* 235 */       int ndefspec = 0;
/* 236 */       for (int t = nt - 1; t >= 0; t--) {
/* 237 */         for (int c = nc - 1; c >= 0; c--) {
/* 238 */           if (this.specValType[t][c] == 0) {
/* 239 */             ndefspec++;
/*     */           }
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 246 */       if (ndefspec != 0) {
/* 247 */         if (wp.getLossless()) {
/* 248 */           setDefault("reversible");
/*     */         } else {
/* 250 */           setDefault("expounded");
/*     */         } 
/*     */       } else {
/*     */         int c, i;
/*     */         
/* 255 */         setDefault(getTileCompVal(0, 0));
/* 256 */         switch (this.specValType[0][0]) {
/*     */           case 2:
/* 258 */             for (c = nc - 1; c >= 0; c--) {
/* 259 */               if (this.specValType[0][c] == 2)
/* 260 */                 this.specValType[0][c] = 0; 
/*     */             } 
/* 262 */             this.tileDef[0] = null;
/*     */             break;
/*     */           case 1:
/* 265 */             for (i = nt - 1; i >= 0; i--) {
/* 266 */               if (this.specValType[i][0] == 1)
/* 267 */                 this.specValType[i][0] = 0; 
/*     */             } 
/* 269 */             this.compDef[0] = null;
/*     */             break;
/*     */           case 3:
/* 272 */             this.specValType[0][0] = 0;
/* 273 */             this.tileCompVal.put("t0c0", null);
/*     */             break;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDerived(int t, int c) {
/* 291 */     if (((String)getTileCompVal(t, c)).equals("derived")) {
/* 292 */       return true;
/*     */     }
/* 294 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isReversible(int t, int c) {
/* 307 */     if (((String)getTileCompVal(t, c)).equals("reversible")) {
/* 308 */       return true;
/*     */     }
/* 310 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isFullyReversible() {
/* 322 */     if (((String)getDefault()).equals("reversible")) {
/* 323 */       for (int t = this.nTiles - 1; t >= 0; t--) {
/* 324 */         for (int c = this.nComp - 1; c >= 0; c--)
/* 325 */         { if (this.specValType[t][c] != 0)
/* 326 */             return false;  } 
/* 327 */       }  return true;
/*     */     } 
/*     */     
/* 330 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isFullyNonReversible() {
/* 340 */     for (int t = this.nTiles - 1; t >= 0; t--) {
/* 341 */       for (int c = this.nComp - 1; c >= 0; c--)
/* 342 */       { if (((String)getSpec(t, c)).equals("reversible"))
/* 343 */           return false;  } 
/* 344 */     }  return true;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/quantization/QuantTypeSpec.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */