package jj2000.j2k.quantization;

public interface QuantizationType {
  public static final int Q_TYPE_SCALAR_DZ = 0;
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/quantization/QuantizationType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */