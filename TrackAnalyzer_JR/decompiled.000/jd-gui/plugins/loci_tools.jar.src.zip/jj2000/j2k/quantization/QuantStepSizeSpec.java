/*     */ package jj2000.j2k.quantization;
/*     */ 
/*     */ import com.sun.media.imageioimpl.plugins.jpeg2000.J2KImageWriteParamJava;
/*     */ import java.util.StringTokenizer;
/*     */ import jj2000.j2k.ModuleSpec;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class QuantStepSizeSpec
/*     */   extends ModuleSpec
/*     */ {
/* 100 */   private String defaultValue = "0.0078125";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QuantStepSizeSpec(int nt, int nc, byte type) {
/* 114 */     super(nt, nc, type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QuantStepSizeSpec(int nt, int nc, byte type, J2KImageWriteParamJava wp, String values) {
/* 129 */     super(nt, nc, type);
/*     */     
/* 131 */     if (values == null)
/*     */     {
/* 133 */       setDefault(new Float(this.defaultValue));
/*     */     }
/*     */     
/* 136 */     this.specified = values;
/*     */ 
/*     */     
/* 139 */     String param = this.specified;
/* 140 */     if (param == null) {
/* 141 */       param = this.defaultValue;
/*     */     }
/*     */     
/* 144 */     StringTokenizer stk = new StringTokenizer(param);
/*     */     
/* 146 */     byte curSpecType = 0;
/*     */     
/* 148 */     boolean[] tileSpec = null;
/* 149 */     boolean[] compSpec = null;
/*     */ 
/*     */     
/* 152 */     while (stk.hasMoreTokens()) {
/* 153 */       Float value; String word = stk.nextToken().toLowerCase();
/*     */       
/* 155 */       switch (word.charAt(0)) {
/*     */         case 't':
/* 157 */           tileSpec = parseIdx(word, this.nTiles);
/* 158 */           if (curSpecType == 1) {
/* 159 */             curSpecType = 3; continue;
/*     */           } 
/* 161 */           curSpecType = 2;
/*     */           continue;
/*     */         case 'c':
/* 164 */           compSpec = parseIdx(word, this.nComp);
/* 165 */           if (curSpecType == 2) {
/* 166 */             curSpecType = 3; continue;
/*     */           } 
/* 168 */           curSpecType = 1;
/*     */           continue;
/*     */       } 
/*     */       try {
/* 172 */         value = new Float(word);
/*     */       }
/* 174 */       catch (NumberFormatException e) {
/* 175 */         throw new IllegalArgumentException("Bad parameter for -Qstep option : " + word);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 180 */       if (value.floatValue() <= 0.0F) {
/* 181 */         throw new IllegalArgumentException("Normalized base step must be positive : " + value);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 187 */       if (curSpecType == 0) {
/* 188 */         setDefault(value);
/*     */       }
/* 190 */       else if (curSpecType == 2) {
/* 191 */         for (int i = tileSpec.length - 1; i >= 0; i--) {
/* 192 */           if (tileSpec[i]) {
/* 193 */             setTileDef(i, value);
/*     */           }
/*     */         } 
/* 196 */       } else if (curSpecType == 1) {
/* 197 */         for (int i = compSpec.length - 1; i >= 0; i--) {
/* 198 */           if (compSpec[i]) {
/* 199 */             setCompDef(i, value);
/*     */           }
/*     */         } 
/*     */       } else {
/* 203 */         for (int i = tileSpec.length - 1; i >= 0; i--) {
/* 204 */           for (int j = compSpec.length - 1; j >= 0; j--) {
/* 205 */             if (tileSpec[i] && compSpec[j]) {
/* 206 */               setTileCompVal(i, j, value);
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 213 */       curSpecType = 0;
/* 214 */       tileSpec = null;
/* 215 */       compSpec = null;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 221 */     if (getDefault() == null) {
/* 222 */       int ndefspec = 0;
/* 223 */       for (int t = nt - 1; t >= 0; t--) {
/* 224 */         for (int c = nc - 1; c >= 0; c--) {
/* 225 */           if (this.specValType[t][c] == 0) {
/* 226 */             ndefspec++;
/*     */           }
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 233 */       if (ndefspec != 0) {
/* 234 */         setDefault(new Float(this.defaultValue));
/*     */       } else {
/*     */         int c, i;
/*     */ 
/*     */         
/* 239 */         setDefault(getTileCompVal(0, 0));
/* 240 */         switch (this.specValType[0][0]) {
/*     */           case 2:
/* 242 */             for (c = nc - 1; c >= 0; c--) {
/* 243 */               if (this.specValType[0][c] == 2)
/* 244 */                 this.specValType[0][c] = 0; 
/*     */             } 
/* 246 */             this.tileDef[0] = null;
/*     */             break;
/*     */           case 1:
/* 249 */             for (i = nt - 1; i >= 0; i--) {
/* 250 */               if (this.specValType[i][0] == 1)
/* 251 */                 this.specValType[i][0] = 0; 
/*     */             } 
/* 253 */             this.compDef[0] = null;
/*     */             break;
/*     */           case 3:
/* 256 */             this.specValType[0][0] = 0;
/* 257 */             this.tileCompVal.put("t0c0", null);
/*     */             break;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/quantization/QuantStepSizeSpec.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */