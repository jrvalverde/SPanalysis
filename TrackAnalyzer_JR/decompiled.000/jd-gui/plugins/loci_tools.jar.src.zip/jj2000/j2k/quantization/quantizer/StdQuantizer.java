/*     */ package jj2000.j2k.quantization.quantizer;
/*     */ 
/*     */ import com.sun.media.imageioimpl.plugins.jpeg2000.J2KImageWriteParamJava;
/*     */ import jj2000.j2k.quantization.GuardBitsSpec;
/*     */ import jj2000.j2k.quantization.QuantStepSizeSpec;
/*     */ import jj2000.j2k.quantization.QuantTypeSpec;
/*     */ import jj2000.j2k.wavelet.Subband;
/*     */ import jj2000.j2k.wavelet.analysis.CBlkWTData;
/*     */ import jj2000.j2k.wavelet.analysis.CBlkWTDataFloat;
/*     */ import jj2000.j2k.wavelet.analysis.CBlkWTDataInt;
/*     */ import jj2000.j2k.wavelet.analysis.CBlkWTDataSrc;
/*     */ import jj2000.j2k.wavelet.analysis.SubbandAn;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StdQuantizer
/*     */   extends Quantizer
/*     */ {
/*     */   public static final int QSTEP_MANTISSA_BITS = 11;
/*     */   public static final int QSTEP_EXPONENT_BITS = 5;
/*     */   public static final int QSTEP_MAX_MANTISSA = 2047;
/*     */   public static final int QSTEP_MAX_EXPONENT = 31;
/* 143 */   private static double log2 = Math.log(2.0D);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private QuantTypeSpec qts;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private QuantStepSizeSpec qsss;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private GuardBitsSpec gbs;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private CBlkWTDataFloat infblk;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StdQuantizer(CBlkWTDataSrc src, J2KImageWriteParamJava wp) {
/* 176 */     super(src);
/* 177 */     this.qts = wp.getQuantizationType();
/* 178 */     this.qsss = wp.getQuantizationStep();
/* 179 */     this.gbs = wp.getGuardBits();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QuantTypeSpec getQuantTypeSpec() {
/* 188 */     return this.qts;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNumGuardBits(int t, int c) {
/* 202 */     return ((Integer)this.gbs.getTileCompVal(t, c)).intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isReversible(int t, int c) {
/* 217 */     return this.qts.isReversible(t, c);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDerived(int t, int c) {
/* 232 */     return this.qts.isDerived(t, c);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CBlkWTData getNextCodeBlock(int c, CBlkWTData cblk) {
/* 270 */     return getNextInternCodeBlock(c, cblk);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final CBlkWTData getNextInternCodeBlock(int c, CBlkWTData cblk) {
/*     */     CBlkWTDataInt cBlkWTDataInt;
/*     */     CBlkWTData cBlkWTData;
/*     */     int[] outarr;
/* 314 */     float[] infarr = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 321 */     int g = ((Integer)this.gbs.getTileCompVal(this.tIdx, c)).intValue();
/*     */ 
/*     */     
/* 324 */     boolean intq = (this.src.getDataType(this.tIdx, c) == 3);
/*     */ 
/*     */     
/* 327 */     if (cblk == null) {
/* 328 */       cBlkWTDataInt = new CBlkWTDataInt();
/*     */     }
/*     */ 
/*     */     
/* 332 */     CBlkWTDataFloat infblk = this.infblk;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 339 */     if (intq) {
/* 340 */       cBlkWTData = this.src.getNextCodeBlock(c, (CBlkWTData)cBlkWTDataInt);
/* 341 */       if (cBlkWTData == null) {
/* 342 */         return null;
/*     */       }
/*     */       
/* 345 */       outarr = (int[])cBlkWTData.getData();
/*     */     }
/*     */     else {
/*     */       
/* 349 */       infblk = (CBlkWTDataFloat)this.src.getNextInternCodeBlock(c, (CBlkWTData)infblk);
/* 350 */       if (infblk == null) {
/*     */ 
/*     */ 
/*     */         
/* 354 */         this.infblk.setData(null);
/* 355 */         return null;
/*     */       } 
/* 357 */       this.infblk = infblk;
/* 358 */       infarr = (float[])infblk.getData();
/*     */ 
/*     */       
/* 361 */       outarr = (int[])cBlkWTData.getData();
/* 362 */       if (outarr == null || outarr.length < infblk.w * infblk.h) {
/* 363 */         outarr = new int[infblk.w * infblk.h];
/* 364 */         cBlkWTData.setData(outarr);
/*     */       } 
/* 366 */       cBlkWTData.m = infblk.m;
/* 367 */       cBlkWTData.n = infblk.n;
/* 368 */       cBlkWTData.sb = infblk.sb;
/* 369 */       cBlkWTData.ulx = infblk.ulx;
/* 370 */       cBlkWTData.uly = infblk.uly;
/* 371 */       cBlkWTData.w = infblk.w;
/* 372 */       cBlkWTData.h = infblk.h;
/* 373 */       cBlkWTData.wmseScaling = infblk.wmseScaling;
/* 374 */       cBlkWTData.offset = 0;
/* 375 */       cBlkWTData.scanw = cBlkWTData.w;
/*     */     } 
/*     */ 
/*     */     
/* 379 */     int w = cBlkWTData.w;
/* 380 */     int h = cBlkWTData.h;
/* 381 */     SubbandAn sb = cBlkWTData.sb;
/*     */     
/* 383 */     if (isReversible(this.tIdx, c)) {
/* 384 */       cBlkWTData.magbits = g - 1 + this.src.getNomRangeBits(c) + sb.anGainExp;
/* 385 */       int shiftBits = 31 - cBlkWTData.magbits;
/*     */ 
/*     */       
/* 388 */       cBlkWTData.convertFactor = (1 << shiftBits);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 393 */       for (int j = w * h - 1; j >= 0; j--) {
/* 394 */         int tmp = outarr[j] << shiftBits;
/* 395 */         outarr[j] = (tmp < 0) ? (Integer.MIN_VALUE | -tmp) : tmp;
/*     */       } 
/*     */     } else {
/*     */       
/* 399 */       float baseStep = ((Float)this.qsss.getTileCompVal(this.tIdx, c)).floatValue();
/*     */ 
/*     */ 
/*     */       
/* 403 */       if (isDerived(this.tIdx, c)) {
/* 404 */         cBlkWTData.magbits = g - 1 + sb.level - (int)Math.floor(Math.log(baseStep) / log2);
/*     */         
/* 406 */         stepUDR = baseStep / (1 << sb.level);
/*     */       } else {
/*     */         
/* 409 */         cBlkWTData.magbits = g - 1 - (int)Math.floor(Math.log((baseStep / sb.l2Norm * (1 << sb.anGainExp))) / log2);
/*     */ 
/*     */         
/* 412 */         stepUDR = baseStep / sb.l2Norm * (1 << sb.anGainExp);
/*     */       } 
/* 414 */       int shiftBits = 31 - cBlkWTData.magbits;
/*     */       
/* 416 */       float stepUDR = convertFromExpMantissa(convertToExpMantissa(stepUDR));
/*     */       
/* 418 */       float invstep = 1.0F / (float)(1L << this.src.getNomRangeBits(c) + sb.anGainExp) * stepUDR;
/*     */ 
/*     */       
/* 421 */       invstep *= (1 << shiftBits - this.src.getFixedPoint(c));
/*     */ 
/*     */       
/* 424 */       cBlkWTData.convertFactor = invstep;
/* 425 */       cBlkWTData.stepSize = ((float)(1L << this.src.getNomRangeBits(c) + sb.anGainExp) * stepUDR);
/*     */ 
/*     */       
/* 428 */       if (intq) {
/*     */ 
/*     */ 
/*     */         
/* 432 */         for (int j = w * h - 1; j >= 0; j--) {
/* 433 */           int tmp = (int)(outarr[j] * invstep);
/* 434 */           outarr[j] = (tmp < 0) ? (Integer.MIN_VALUE | -tmp) : tmp;
/*     */         } 
/*     */       } else {
/*     */         
/* 438 */         int j = w * h - 1, k = infblk.offset + (h - 1) * infblk.scanw + w - 1; int jmin;
/* 439 */         for (jmin = w * (h - 1); j >= 0; jmin -= w) {
/* 440 */           for (; j >= jmin; k--, j--) {
/* 441 */             int tmp = (int)(infarr[k] * invstep);
/* 442 */             outarr[j] = (tmp < 0) ? (Integer.MIN_VALUE | -tmp) : tmp;
/*     */           } 
/*     */           
/* 445 */           k -= infblk.scanw - w;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 450 */     return cBlkWTData;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void calcSbParams(SubbandAn sb, int c) {
/* 468 */     if (sb.stepWMSE > 0.0F)
/*     */       return; 
/* 470 */     if (!sb.isNode) {
/* 471 */       if (isReversible(this.tIdx, c)) {
/* 472 */         sb.stepWMSE = (float)Math.pow(2.0D, -(this.src.getNomRangeBits(c) << 1)) * sb.l2Norm * sb.l2Norm;
/*     */       }
/*     */       else {
/*     */         
/* 476 */         float baseStep = ((Float)this.qsss.getTileCompVal(this.tIdx, c)).floatValue();
/* 477 */         if (isDerived(this.tIdx, c)) {
/* 478 */           sb.stepWMSE = baseStep * baseStep * (float)Math.pow(2.0D, (sb.anGainExp - sb.level << 1)) * sb.l2Norm * sb.l2Norm;
/*     */         
/*     */         }
/*     */         else {
/*     */           
/* 483 */           sb.stepWMSE = baseStep * baseStep;
/*     */         } 
/*     */       } 
/*     */     } else {
/*     */       
/* 488 */       calcSbParams((SubbandAn)sb.getLL(), c);
/* 489 */       calcSbParams((SubbandAn)sb.getHL(), c);
/* 490 */       calcSbParams((SubbandAn)sb.getLH(), c);
/* 491 */       calcSbParams((SubbandAn)sb.getHH(), c);
/* 492 */       sb.stepWMSE = 1.0F;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int convertToExpMantissa(float step) {
/* 508 */     int exp = (int)Math.ceil(-Math.log(step) / log2);
/* 509 */     if (exp > 31)
/*     */     {
/*     */       
/* 512 */       return 63488;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 517 */     return exp << 11 | (int)((-step * (-1 << exp) - 1.0F) * 2048.0F + 0.5F);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static float convertFromExpMantissa(int ems) {
/* 535 */     return (-1.0F - (ems & 0x7FF) / 2048.0F) / (-1 << (ems >> 11 & 0x1F));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaxMagBits(int c) {
/* 550 */     SubbandAn subbandAn = getAnSubbandTree(this.tIdx, c);
/* 551 */     if (isReversible(this.tIdx, c)) {
/* 552 */       return getMaxMagBitsRev((Subband)subbandAn, c);
/*     */     }
/*     */     
/* 555 */     if (isDerived(this.tIdx, c)) {
/* 556 */       return getMaxMagBitsDerived((Subband)subbandAn, this.tIdx, c);
/*     */     }
/*     */     
/* 559 */     return getMaxMagBitsExpounded((Subband)subbandAn, this.tIdx, c);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int getMaxMagBitsRev(Subband sb, int c) {
/* 576 */     int max = 0;
/* 577 */     int g = ((Integer)this.gbs.getTileCompVal(this.tIdx, c)).intValue();
/*     */     
/* 579 */     if (!sb.isNode) {
/* 580 */       return g - 1 + this.src.getNomRangeBits(c) + sb.anGainExp;
/*     */     }
/* 582 */     max = getMaxMagBitsRev(sb.getLL(), c);
/* 583 */     int tmp = getMaxMagBitsRev(sb.getLH(), c);
/* 584 */     if (tmp > max)
/* 585 */       max = tmp; 
/* 586 */     tmp = getMaxMagBitsRev(sb.getHL(), c);
/* 587 */     if (tmp > max)
/* 588 */       max = tmp; 
/* 589 */     tmp = getMaxMagBitsRev(sb.getHH(), c);
/* 590 */     if (tmp > max) {
/* 591 */       max = tmp;
/*     */     }
/* 593 */     return max;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int getMaxMagBitsDerived(Subband sb, int t, int c) {
/* 609 */     int max = 0;
/* 610 */     int g = ((Integer)this.gbs.getTileCompVal(t, c)).intValue();
/*     */     
/* 612 */     if (!sb.isNode) {
/* 613 */       float baseStep = ((Float)this.qsss.getTileCompVal(t, c)).floatValue();
/* 614 */       return g - 1 + sb.level - (int)Math.floor(Math.log(baseStep) / log2);
/*     */     } 
/*     */     
/* 617 */     max = getMaxMagBitsDerived(sb.getLL(), t, c);
/* 618 */     int tmp = getMaxMagBitsDerived(sb.getLH(), t, c);
/* 619 */     if (tmp > max)
/* 620 */       max = tmp; 
/* 621 */     tmp = getMaxMagBitsDerived(sb.getHL(), t, c);
/* 622 */     if (tmp > max)
/* 623 */       max = tmp; 
/* 624 */     tmp = getMaxMagBitsDerived(sb.getHH(), t, c);
/* 625 */     if (tmp > max) {
/* 626 */       max = tmp;
/*     */     }
/* 628 */     return max;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int getMaxMagBitsExpounded(Subband sb, int t, int c) {
/* 645 */     int max = 0;
/* 646 */     int g = ((Integer)this.gbs.getTileCompVal(t, c)).intValue();
/*     */     
/* 648 */     if (!sb.isNode) {
/* 649 */       float baseStep = ((Float)this.qsss.getTileCompVal(t, c)).floatValue();
/* 650 */       return g - 1 - (int)Math.floor(Math.log((baseStep / ((SubbandAn)sb).l2Norm * (1 << sb.anGainExp))) / log2);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 656 */     max = getMaxMagBitsExpounded(sb.getLL(), t, c);
/* 657 */     int tmp = getMaxMagBitsExpounded(sb.getLH(), t, c);
/* 658 */     if (tmp > max)
/* 659 */       max = tmp; 
/* 660 */     tmp = getMaxMagBitsExpounded(sb.getHL(), t, c);
/* 661 */     if (tmp > max)
/* 662 */       max = tmp; 
/* 663 */     tmp = getMaxMagBitsExpounded(sb.getHH(), t, c);
/* 664 */     if (tmp > max) {
/* 665 */       max = tmp;
/*     */     }
/* 667 */     return max;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/quantization/quantizer/StdQuantizer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */