package jj2000.j2k.quantization.quantizer;

import jj2000.j2k.wavelet.analysis.CBlkWTData;
import jj2000.j2k.wavelet.analysis.ForwWTDataProps;

public interface CBlkQuantDataSrcEnc extends ForwWTDataProps {
  CBlkWTData getNextCodeBlock(int paramInt, CBlkWTData paramCBlkWTData);
  
  CBlkWTData getNextInternCodeBlock(int paramInt, CBlkWTData paramCBlkWTData);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/quantization/quantizer/CBlkQuantDataSrcEnc.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */