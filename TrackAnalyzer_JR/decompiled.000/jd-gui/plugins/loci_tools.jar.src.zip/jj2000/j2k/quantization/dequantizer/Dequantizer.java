/*     */ package jj2000.j2k.quantization.dequantizer;
/*     */ 
/*     */ import jj2000.j2k.decoder.DecoderSpecs;
/*     */ import jj2000.j2k.image.CompTransfSpec;
/*     */ import jj2000.j2k.image.invcomptransf.InvCompTransf;
/*     */ import jj2000.j2k.wavelet.synthesis.CBlkWTDataSrcDec;
/*     */ import jj2000.j2k.wavelet.synthesis.MultiResImgData;
/*     */ import jj2000.j2k.wavelet.synthesis.MultiResImgDataAdapter;
/*     */ import jj2000.j2k.wavelet.synthesis.SubbandSyn;
/*     */ import jj2000.j2k.wavelet.synthesis.SynWTFilterSpec;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Dequantizer
/*     */   extends MultiResImgDataAdapter
/*     */   implements CBlkWTDataSrcDec
/*     */ {
/*     */   public static final char OPT_PREFIX = 'Q';
/* 126 */   private static final String[][] pinfo = (String[][])null;
/*     */ 
/*     */ 
/*     */   
/*     */   protected CBlkQuantDataSrcDec src;
/*     */ 
/*     */   
/* 133 */   protected int[] rb = null;
/*     */ 
/*     */   
/* 136 */   protected int[] utrb = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private CompTransfSpec cts;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private SynWTFilterSpec wfs;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Dequantizer(CBlkQuantDataSrcDec src, int[] utrb, DecoderSpecs decSpec) {
/* 157 */     super((MultiResImgData)src);
/* 158 */     if (utrb.length != src.getNumComps()) {
/* 159 */       throw new IllegalArgumentException();
/*     */     }
/* 161 */     this.src = src;
/* 162 */     this.utrb = utrb;
/* 163 */     this.cts = decSpec.cts;
/* 164 */     this.wfs = decSpec.wfs;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNomRangeBits(int c) {
/* 192 */     return this.rb[c];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SubbandSyn getSynSubbandTree(int t, int c) {
/* 212 */     return this.src.getSynSubbandTree(t, c);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getCbULX() {
/* 220 */     return this.src.getCbULX();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getCbULY() {
/* 228 */     return this.src.getCbULY();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[][] getParameterInfo() {
/* 246 */     return pinfo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTile(int x, int y) {
/* 262 */     this.src.setTile(x, y);
/* 263 */     this.tIdx = getTileIdx();
/*     */ 
/*     */     
/* 266 */     int cttype = 0;
/* 267 */     if (((Integer)this.cts.getTileDef(this.tIdx)).intValue() == 0) {
/* 268 */       cttype = 0;
/*     */     } else {
/* 270 */       int nc = (this.src.getNumComps() > 3) ? 3 : this.src.getNumComps();
/* 271 */       int rev = 0;
/* 272 */       for (int c = 0; c < nc; c++)
/* 273 */         rev += this.wfs.isReversible(this.tIdx, c) ? 1 : 0; 
/* 274 */       if (rev == 3) {
/*     */         
/* 276 */         cttype = 1;
/*     */       }
/* 278 */       else if (rev == 0) {
/*     */         
/* 280 */         cttype = 2;
/*     */       }
/*     */       else {
/*     */         
/* 284 */         throw new IllegalArgumentException("Wavelet transformation and component transformation not coherent in tile" + this.tIdx);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 292 */     switch (cttype) {
/*     */       case 0:
/* 294 */         this.rb = this.utrb;
/*     */         return;
/*     */       case 1:
/* 297 */         this.rb = InvCompTransf.calcMixedBitDepths(this.utrb, 1, null);
/*     */         return;
/*     */       
/*     */       case 2:
/* 301 */         this.rb = InvCompTransf.calcMixedBitDepths(this.utrb, 2, null);
/*     */         return;
/*     */     } 
/*     */     
/* 305 */     throw new IllegalArgumentException("Non JPEG 2000 part I component transformation for tile: " + this.tIdx);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void nextTile() {
/* 321 */     this.src.nextTile();
/* 322 */     this.tIdx = getTileIdx();
/*     */ 
/*     */     
/* 325 */     int cttype = ((Integer)this.cts.getTileDef(this.tIdx)).intValue();
/* 326 */     switch (cttype) {
/*     */       case 0:
/* 328 */         this.rb = this.utrb;
/*     */         return;
/*     */       case 1:
/* 331 */         this.rb = InvCompTransf.calcMixedBitDepths(this.utrb, 1, null);
/*     */         return;
/*     */       
/*     */       case 2:
/* 335 */         this.rb = InvCompTransf.calcMixedBitDepths(this.utrb, 2, null);
/*     */         return;
/*     */     } 
/*     */     
/* 339 */     throw new IllegalArgumentException("Non JPEG 2000 part I component transformation for tile: " + this.tIdx);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/quantization/dequantizer/Dequantizer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */