package jj2000.j2k.quantization.dequantizer;

public abstract class DequantizerParams {
  public abstract int getDequantizerType();
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/quantization/dequantizer/DequantizerParams.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */