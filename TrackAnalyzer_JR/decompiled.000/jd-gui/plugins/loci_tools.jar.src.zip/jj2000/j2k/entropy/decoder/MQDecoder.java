/*     */ package jj2000.j2k.entropy.decoder;
/*     */ 
/*     */ import jj2000.j2k.util.ArrayUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MQDecoder
/*     */ {
/* 111 */   static final int[] qe = new int[] { 22017, 13313, 6145, 2753, 1313, 545, 22017, 21505, 18433, 14337, 12289, 9217, 7169, 5633, 22017, 21505, 20737, 18433, 14337, 13313, 12289, 10241, 9217, 8705, 7169, 6145, 5633, 5121, 4609, 4353, 2753, 2497, 2209, 1313, 1089, 673, 545, 321, 273, 133, 73, 37, 21, 9, 5, 1, 22017 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 121 */   static final int[] nMPS = new int[] { 1, 2, 3, 4, 5, 38, 7, 8, 9, 10, 11, 12, 13, 29, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 45, 46 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 127 */   static final int[] nLPS = new int[] { 1, 6, 9, 12, 29, 33, 6, 14, 14, 14, 17, 18, 20, 21, 14, 14, 15, 16, 17, 18, 19, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 46 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 133 */   static final int[] switchLM = new int[] { 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ByteInputBuffer in;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int[] mPS;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int[] I;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int c;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int cT;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int a;
/*     */ 
/*     */ 
/*     */   
/*     */   int b;
/*     */ 
/*     */ 
/*     */   
/*     */   boolean markerFound;
/*     */ 
/*     */ 
/*     */   
/*     */   final int[] initStates;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MQDecoder(ByteInputBuffer iStream, int nrOfContexts, int[] initStates) {
/* 181 */     this.in = iStream;
/*     */ 
/*     */ 
/*     */     
/* 185 */     this.I = new int[nrOfContexts];
/* 186 */     this.mPS = new int[nrOfContexts];
/*     */     
/* 188 */     this.initStates = initStates;
/*     */ 
/*     */     
/* 191 */     init();
/*     */ 
/*     */     
/* 194 */     resetCtxts();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean fastDecodeSymbols(int[] bits, int ctxt, int n) {
/* 233 */     int idx = this.I[ctxt];
/* 234 */     int q = qe[idx];
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 239 */     if (q < 16384 && n <= (this.a - (this.c >>> 16) - 1) / q && n <= (this.a - 32768) / q + 1) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 244 */       this.a -= n * q;
/* 245 */       if (this.a >= 32768) {
/* 246 */         bits[0] = this.mPS[ctxt];
/* 247 */         return true;
/*     */       } 
/*     */       
/* 250 */       this.I[ctxt] = nMPS[idx];
/*     */       
/* 252 */       if (this.cT == 0)
/* 253 */         byteIn(); 
/* 254 */       this.a <<= 1;
/* 255 */       this.c <<= 1;
/* 256 */       this.cT--;
/*     */       
/* 258 */       bits[0] = this.mPS[ctxt];
/* 259 */       return true;
/*     */     } 
/*     */ 
/*     */     
/* 263 */     int la = this.a;
/* 264 */     for (int i = 0; i < n; i++) {
/* 265 */       la -= q;
/* 266 */       if (this.c >>> 16 < la) {
/* 267 */         if (la >= 32768) {
/* 268 */           bits[i] = this.mPS[ctxt];
/*     */ 
/*     */         
/*     */         }
/* 272 */         else if (la >= q) {
/* 273 */           bits[i] = this.mPS[ctxt];
/* 274 */           idx = nMPS[idx];
/* 275 */           q = qe[idx];
/*     */ 
/*     */           
/* 278 */           if (this.cT == 0)
/* 279 */             byteIn(); 
/* 280 */           la <<= 1;
/* 281 */           this.c <<= 1;
/* 282 */           this.cT--;
/*     */         }
/*     */         else {
/*     */           
/* 286 */           bits[i] = 1 - this.mPS[ctxt];
/* 287 */           if (switchLM[idx] == 1)
/* 288 */             this.mPS[ctxt] = 1 - this.mPS[ctxt]; 
/* 289 */           idx = nLPS[idx];
/* 290 */           q = qe[idx];
/*     */ 
/*     */           
/*     */           do {
/* 294 */             if (this.cT == 0)
/* 295 */               byteIn(); 
/* 296 */             la <<= 1;
/* 297 */             this.c <<= 1;
/* 298 */             this.cT--;
/* 299 */           } while (la < 32768);
/*     */         
/*     */         }
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 306 */         this.c -= la << 16;
/*     */         
/* 308 */         if (la < q) {
/* 309 */           la = q;
/* 310 */           bits[i] = this.mPS[ctxt];
/* 311 */           idx = nMPS[idx];
/* 312 */           q = qe[idx];
/*     */ 
/*     */           
/* 315 */           if (this.cT == 0)
/* 316 */             byteIn(); 
/* 317 */           la <<= 1;
/* 318 */           this.c <<= 1;
/* 319 */           this.cT--;
/*     */         }
/*     */         else {
/*     */           
/* 323 */           la = q;
/* 324 */           bits[i] = 1 - this.mPS[ctxt];
/* 325 */           if (switchLM[idx] == 1)
/* 326 */             this.mPS[ctxt] = 1 - this.mPS[ctxt]; 
/* 327 */           idx = nLPS[idx];
/* 328 */           q = qe[idx];
/*     */ 
/*     */           
/*     */           do {
/* 332 */             if (this.cT == 0)
/* 333 */               byteIn(); 
/* 334 */             la <<= 1;
/* 335 */             this.c <<= 1;
/* 336 */             this.cT--;
/* 337 */           } while (la < 32768);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 343 */     this.a = la;
/* 344 */     this.I[ctxt] = idx;
/* 345 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void decodeSymbols(int[] bits, int[] cX, int n) {
/* 382 */     for (int i = 0; i < n; i++) {
/* 383 */       int ctxt = cX[i];
/*     */       
/* 385 */       int index = this.I[ctxt];
/* 386 */       int q = qe[index];
/*     */       
/* 388 */       this.a -= q;
/* 389 */       if (this.c >>> 16 < this.a) {
/* 390 */         if (this.a >= 32768) {
/* 391 */           bits[i] = this.mPS[ctxt];
/*     */         } else {
/*     */           
/* 394 */           int la = this.a;
/*     */           
/* 396 */           if (la >= q) {
/* 397 */             bits[i] = this.mPS[ctxt];
/* 398 */             this.I[ctxt] = nMPS[index];
/*     */             
/* 400 */             if (this.cT == 0)
/* 401 */               byteIn(); 
/* 402 */             la <<= 1;
/* 403 */             this.c <<= 1;
/* 404 */             this.cT--;
/*     */           }
/*     */           else {
/*     */             
/* 408 */             bits[i] = 1 - this.mPS[ctxt];
/* 409 */             if (switchLM[index] == 1)
/* 410 */               this.mPS[ctxt] = 1 - this.mPS[ctxt]; 
/* 411 */             this.I[ctxt] = nLPS[index];
/*     */             
/*     */             do {
/* 414 */               if (this.cT == 0)
/* 415 */                 byteIn(); 
/* 416 */               la <<= 1;
/* 417 */               this.c <<= 1;
/* 418 */               this.cT--;
/* 419 */             } while (la < 32768);
/*     */           } 
/*     */ 
/*     */           
/* 423 */           this.a = la;
/*     */         } 
/*     */       } else {
/*     */         
/* 427 */         int la = this.a;
/* 428 */         this.c -= la << 16;
/*     */         
/* 430 */         if (la < q) {
/* 431 */           la = q;
/* 432 */           bits[i] = this.mPS[ctxt];
/* 433 */           this.I[ctxt] = nMPS[index];
/*     */           
/* 435 */           if (this.cT == 0)
/* 436 */             byteIn(); 
/* 437 */           la <<= 1;
/* 438 */           this.c <<= 1;
/* 439 */           this.cT--;
/*     */         }
/*     */         else {
/*     */           
/* 443 */           la = q;
/* 444 */           bits[i] = 1 - this.mPS[ctxt];
/* 445 */           if (switchLM[index] == 1)
/* 446 */             this.mPS[ctxt] = 1 - this.mPS[ctxt]; 
/* 447 */           this.I[ctxt] = nLPS[index];
/*     */           
/*     */           do {
/* 450 */             if (this.cT == 0)
/* 451 */               byteIn(); 
/* 452 */             la <<= 1;
/* 453 */             this.c <<= 1;
/* 454 */             this.cT--;
/* 455 */           } while (la < 32768);
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 460 */         this.a = la;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int decodeSymbol(int context) {
/* 486 */     int decision, index = this.I[context];
/* 487 */     int q = qe[index];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 497 */     this.a -= q;
/* 498 */     if (this.c >>> 16 < this.a) {
/* 499 */       if (this.a >= 32768) {
/* 500 */         decision = this.mPS[context];
/*     */       } else {
/*     */         
/* 503 */         int la = this.a;
/*     */         
/* 505 */         if (la >= q) {
/* 506 */           decision = this.mPS[context];
/* 507 */           this.I[context] = nMPS[index];
/*     */           
/* 509 */           if (this.cT == 0)
/* 510 */             byteIn(); 
/* 511 */           la <<= 1;
/* 512 */           this.c <<= 1;
/* 513 */           this.cT--;
/*     */         }
/*     */         else {
/*     */           
/* 517 */           decision = 1 - this.mPS[context];
/* 518 */           if (switchLM[index] == 1)
/* 519 */             this.mPS[context] = 1 - this.mPS[context]; 
/* 520 */           this.I[context] = nLPS[index];
/*     */           
/*     */           do {
/* 523 */             if (this.cT == 0)
/* 524 */               byteIn(); 
/* 525 */             la <<= 1;
/* 526 */             this.c <<= 1;
/* 527 */             this.cT--;
/* 528 */           } while (la < 32768);
/*     */         } 
/*     */ 
/*     */         
/* 532 */         this.a = la;
/*     */       } 
/*     */     } else {
/*     */       
/* 536 */       int la = this.a;
/* 537 */       this.c -= la << 16;
/*     */       
/* 539 */       if (la < q) {
/* 540 */         la = q;
/* 541 */         decision = this.mPS[context];
/* 542 */         this.I[context] = nMPS[index];
/*     */         
/* 544 */         if (this.cT == 0)
/* 545 */           byteIn(); 
/* 546 */         la <<= 1;
/* 547 */         this.c <<= 1;
/* 548 */         this.cT--;
/*     */       }
/*     */       else {
/*     */         
/* 552 */         la = q;
/* 553 */         decision = 1 - this.mPS[context];
/* 554 */         if (switchLM[index] == 1)
/* 555 */           this.mPS[context] = 1 - this.mPS[context]; 
/* 556 */         this.I[context] = nLPS[index];
/*     */         
/*     */         do {
/* 559 */           if (this.cT == 0)
/* 560 */             byteIn(); 
/* 561 */           la <<= 1;
/* 562 */           this.c <<= 1;
/* 563 */           this.cT--;
/* 564 */         } while (la < 32768);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 569 */       this.a = la;
/*     */     } 
/* 571 */     return decision;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean checkPredTerm() {
/* 591 */     if (this.b != 255 && !this.markerFound) return true;
/*     */ 
/*     */ 
/*     */     
/* 595 */     if (this.cT != 0 && !this.markerFound) return true;
/*     */ 
/*     */ 
/*     */     
/* 599 */     if (this.cT == 1) return false;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 604 */     if (this.cT == 0) {
/* 605 */       if (!this.markerFound) {
/*     */         
/* 607 */         this.b = this.in.read() & 0xFF;
/* 608 */         if (this.b <= 143) return true;
/*     */       
/*     */       } 
/* 611 */       this.cT = 8;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 617 */     int k = this.cT - 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 626 */     int q = 32768 >> k;
/*     */ 
/*     */     
/* 629 */     this.a -= q;
/* 630 */     if (this.c >>> 16 < this.a)
/*     */     {
/* 632 */       return true;
/*     */     }
/*     */     
/* 635 */     this.c -= this.a << 16;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 640 */     this.a = q;
/*     */     
/*     */     do {
/* 643 */       if (this.cT == 0) byteIn(); 
/* 644 */       this.a <<= 1;
/* 645 */       this.c <<= 1;
/* 646 */       this.cT--;
/* 647 */     } while (this.a < 32768);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 654 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void byteIn() {
/* 666 */     if (!this.markerFound) {
/* 667 */       if (this.b == 255) {
/* 668 */         this.b = this.in.read() & 0xFF;
/*     */         
/* 670 */         if (this.b > 143) {
/* 671 */           this.markerFound = true;
/*     */           
/* 673 */           this.cT = 8;
/*     */         } else {
/* 675 */           this.c += 65024 - (this.b << 9);
/* 676 */           this.cT = 7;
/*     */         } 
/*     */       } else {
/* 679 */         this.b = this.in.read() & 0xFF;
/* 680 */         this.c += 65280 - (this.b << 8);
/* 681 */         this.cT = 8;
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 686 */       this.cT = 8;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getNumCtxts() {
/* 698 */     return this.I.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void resetCtxt(int c) {
/* 710 */     this.I[c] = this.initStates[c];
/* 711 */     this.mPS[c] = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void resetCtxts() {
/* 725 */     System.arraycopy(this.initStates, 0, this.I, 0, this.I.length);
/* 726 */     ArrayUtil.intArraySet(this.mPS, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void nextSegment(byte[] buf, int off, int len) {
/* 747 */     this.in.setByteArray(buf, off, len);
/*     */     
/* 749 */     init();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ByteInputBuffer getByteInputBuffer() {
/* 760 */     return this.in;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void init() {
/* 775 */     this.markerFound = false;
/*     */ 
/*     */     
/* 778 */     this.b = this.in.read() & 0xFF;
/*     */ 
/*     */     
/* 781 */     this.c = (this.b ^ 0xFF) << 16;
/* 782 */     byteIn();
/* 783 */     this.c <<= 7;
/* 784 */     this.cT -= 7;
/* 785 */     this.a = 32768;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/entropy/decoder/MQDecoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */