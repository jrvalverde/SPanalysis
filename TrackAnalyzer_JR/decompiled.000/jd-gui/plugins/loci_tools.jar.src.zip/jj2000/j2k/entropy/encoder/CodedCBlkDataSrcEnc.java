package jj2000.j2k.entropy.encoder;

import jj2000.j2k.wavelet.analysis.ForwWTDataProps;

public interface CodedCBlkDataSrcEnc extends ForwWTDataProps {
  CBlkRateDistStats getNextCodeBlock(int paramInt, CBlkRateDistStats paramCBlkRateDistStats);
  
  int getPPX(int paramInt1, int paramInt2, int paramInt3);
  
  int getPPY(int paramInt1, int paramInt2, int paramInt3);
  
  boolean precinctPartitionUsed(int paramInt1, int paramInt2);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/entropy/encoder/CodedCBlkDataSrcEnc.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */