/*     */ package jj2000.j2k.entropy.encoder;
/*     */ 
/*     */ import jj2000.j2k.entropy.CodedCBlk;
/*     */ import jj2000.j2k.wavelet.analysis.SubbandAn;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CBlkRateDistStats
/*     */   extends CodedCBlk
/*     */ {
/*     */   public SubbandAn sb;
/*     */   public int nTotTrunc;
/*     */   public int nVldTrunc;
/*     */   public int[] truncRates;
/*     */   public double[] truncDists;
/*     */   public float[] truncSlopes;
/*     */   public int[] truncIdxs;
/*     */   public boolean[] isTermPass;
/* 156 */   public int nROIcoeff = 0;
/*     */ 
/*     */   
/* 159 */   public int nROIcp = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CBlkRateDistStats() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CBlkRateDistStats(int m, int n, int skipMSBP, byte[] data, int[] rates, double[] dists, boolean[] termp, int np, boolean inclast) {
/* 215 */     super(m, n, skipMSBP, data);
/* 216 */     selectConvexHull(rates, dists, termp, np, inclast);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void selectConvexHull(int[] rates, double[] dists, boolean[] termp, int n, boolean inclast) {
/* 266 */     int first_pnt = 0;
/* 267 */     while (first_pnt < n && rates[first_pnt] <= 0) {
/* 268 */       first_pnt++;
/*     */     }
/*     */ 
/*     */     
/* 272 */     int npnt = n - first_pnt;
/* 273 */     float p_slope = 0.0F;
/*     */     
/*     */     label56: while (true) {
/* 276 */       int p = -1;
/* 277 */       for (int m = first_pnt; m < n; m++) {
/* 278 */         if (rates[m] >= 0) {
/*     */           int delta_rate;
/*     */           
/*     */           double delta_dist;
/* 282 */           if (p >= 0) {
/* 283 */             delta_rate = rates[m] - rates[p];
/* 284 */             delta_dist = dists[m] - dists[p];
/*     */           } else {
/*     */             
/* 287 */             delta_rate = rates[m];
/* 288 */             delta_dist = dists[m];
/*     */           } 
/*     */ 
/*     */ 
/*     */           
/* 293 */           if (delta_dist < 0.0D || (delta_dist == 0.0D && delta_rate > 0)) {
/*     */             
/* 295 */             rates[m] = -rates[m];
/* 296 */             npnt--;
/*     */           } else {
/*     */             
/* 299 */             float k_slope = (float)(delta_dist / delta_rate);
/*     */ 
/*     */ 
/*     */             
/* 303 */             if (p >= 0 && (delta_rate <= 0 || k_slope >= p_slope)) {
/*     */ 
/*     */               
/* 306 */               rates[p] = -rates[p];
/* 307 */               npnt--;
/*     */               
/*     */               continue label56;
/*     */             } 
/* 311 */             p_slope = k_slope;
/* 312 */             p = m;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/*     */       break;
/*     */     } 
/*     */     
/* 321 */     if (inclast && n > 0 && rates[n - 1] < 0) {
/* 322 */       rates[n - 1] = -rates[n - 1];
/*     */ 
/*     */ 
/*     */       
/* 326 */       npnt++;
/*     */     } 
/*     */ 
/*     */     
/* 330 */     this.nTotTrunc = n;
/* 331 */     this.nVldTrunc = npnt;
/* 332 */     this.truncRates = new int[n];
/* 333 */     this.truncDists = new double[n];
/* 334 */     this.truncSlopes = new float[npnt];
/* 335 */     this.truncIdxs = new int[npnt];
/* 336 */     if (termp != null) {
/* 337 */       this.isTermPass = new boolean[n];
/* 338 */       System.arraycopy(termp, 0, this.isTermPass, 0, n);
/*     */     } else {
/*     */       
/* 341 */       this.isTermPass = null;
/*     */     } 
/* 343 */     System.arraycopy(rates, 0, this.truncRates, 0, n);
/* 344 */     for (int k = first_pnt, j = -1, i = 0; k < n; k++) {
/* 345 */       if (rates[k] > 0) {
/* 346 */         this.truncDists[k] = dists[k];
/* 347 */         if (j < 0) {
/* 348 */           this.truncSlopes[i] = (float)(dists[k] / rates[k]);
/*     */         } else {
/*     */           
/* 351 */           this.truncSlopes[i] = (float)((dists[k] - dists[j]) / (rates[k] - rates[j]));
/*     */         } 
/*     */         
/* 354 */         this.truncIdxs[i] = k;
/* 355 */         i++;
/* 356 */         j = k;
/*     */       } else {
/*     */         
/* 359 */         this.truncDists[k] = -1.0D;
/* 360 */         this.truncRates[k] = -this.truncRates[k];
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 372 */     return super.toString() + "\n nVldTrunc = " + this.nVldTrunc + ", nTotTrunc=" + this.nTotTrunc + ", num. ROI" + " coeff=" + this.nROIcoeff + ", num. ROI coding passes=" + this.nROIcp;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/entropy/encoder/CBlkRateDistStats.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */