package jj2000.j2k.entropy.decoder;

import jj2000.j2k.wavelet.synthesis.InvWTData;
import jj2000.j2k.wavelet.synthesis.SubbandSyn;

public interface CodedCBlkDataSrcDec extends InvWTData {
  DecLyrdCBlk getCodeBlock(int paramInt1, int paramInt2, int paramInt3, SubbandSyn paramSubbandSyn, int paramInt4, int paramInt5, DecLyrdCBlk paramDecLyrdCBlk);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/entropy/decoder/CodedCBlkDataSrcDec.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */