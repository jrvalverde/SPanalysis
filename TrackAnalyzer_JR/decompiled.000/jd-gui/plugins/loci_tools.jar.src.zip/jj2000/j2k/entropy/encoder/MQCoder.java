/*      */ package jj2000.j2k.entropy.encoder;
/*      */ 
/*      */ import jj2000.j2k.util.ArrayUtil;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class MQCoder
/*      */ {
/*      */   public static final int LENGTH_LAZY = 0;
/*      */   public static final int LENGTH_LAZY_GOOD = 1;
/*      */   public static final int LENGTH_NEAR_OPT = 2;
/*      */   public static final int TERM_FULL = 0;
/*      */   public static final int TERM_NEAR_OPT = 1;
/*      */   public static final int TERM_EASY = 2;
/*      */   public static final int TERM_PRED_ER = 3;
/*  218 */   static final int[] qe = new int[] { 22017, 13313, 6145, 2753, 1313, 545, 22017, 21505, 18433, 14337, 12289, 9217, 7169, 5633, 22017, 21505, 20737, 18433, 14337, 13313, 12289, 10241, 9217, 8705, 7169, 6145, 5633, 5121, 4609, 4353, 2753, 2497, 2209, 1313, 1089, 673, 545, 321, 273, 133, 73, 37, 21, 9, 5, 1, 22017 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  228 */   static final int[] nMPS = new int[] { 1, 2, 3, 4, 5, 38, 7, 8, 9, 10, 11, 12, 13, 29, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 45, 46 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  234 */   static final int[] nLPS = new int[] { 1, 6, 9, 12, 29, 33, 6, 14, 14, 14, 17, 18, 20, 21, 14, 14, 15, 16, 17, 18, 19, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 46 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  240 */   static final int[] switchLM = new int[] { 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
/*      */ 
/*      */ 
/*      */   
/*      */   ByteOutputBuffer out;
/*      */ 
/*      */ 
/*      */   
/*      */   int[] mPS;
/*      */ 
/*      */ 
/*      */   
/*      */   int[] I;
/*      */ 
/*      */ 
/*      */   
/*      */   int c;
/*      */ 
/*      */ 
/*      */   
/*      */   int cT;
/*      */ 
/*      */   
/*      */   int a;
/*      */ 
/*      */   
/*      */   int b;
/*      */ 
/*      */   
/*      */   boolean delFF;
/*      */ 
/*      */   
/*  272 */   int nrOfWrittenBytes = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int[] initStates;
/*      */ 
/*      */ 
/*      */   
/*      */   int ttype;
/*      */ 
/*      */ 
/*      */   
/*      */   int ltype;
/*      */ 
/*      */ 
/*      */   
/*      */   int[] savedC;
/*      */ 
/*      */ 
/*      */   
/*      */   int[] savedCT;
/*      */ 
/*      */ 
/*      */   
/*      */   int[] savedA;
/*      */ 
/*      */ 
/*      */   
/*      */   int[] savedB;
/*      */ 
/*      */ 
/*      */   
/*      */   boolean[] savedDelFF;
/*      */ 
/*      */ 
/*      */   
/*      */   int nSaved;
/*      */ 
/*      */ 
/*      */   
/*      */   static final int SAVED_LEN = 96;
/*      */ 
/*      */ 
/*      */   
/*      */   static final int SAVED_INC = 12;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLenCalcType(int ltype) {
/*  323 */     if (ltype != 0 && ltype != 1 && ltype != 2)
/*      */     {
/*  325 */       throw new IllegalArgumentException("Unrecognized length calculation type code: " + ltype);
/*      */     }
/*      */ 
/*      */     
/*  329 */     if (ltype == 2) {
/*  330 */       if (this.savedC == null)
/*  331 */         this.savedC = new int[96]; 
/*  332 */       if (this.savedCT == null)
/*  333 */         this.savedCT = new int[96]; 
/*  334 */       if (this.savedA == null)
/*  335 */         this.savedA = new int[96]; 
/*  336 */       if (this.savedB == null)
/*  337 */         this.savedB = new int[96]; 
/*  338 */       if (this.savedDelFF == null) {
/*  339 */         this.savedDelFF = new boolean[96];
/*      */       }
/*      */     } 
/*  342 */     this.ltype = ltype;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTermType(int ttype) {
/*  352 */     if (ttype != 0 && ttype != 1 && ttype != 2 && ttype != 3)
/*      */     {
/*  354 */       throw new IllegalArgumentException("Unrecognized termination type code: " + ttype);
/*      */     }
/*      */ 
/*      */     
/*  358 */     this.ttype = ttype;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MQCoder(ByteOutputBuffer oStream, int nrOfContexts, int[] init) {
/*  375 */     this.out = oStream;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  381 */     this.I = new int[nrOfContexts];
/*  382 */     this.mPS = new int[nrOfContexts];
/*  383 */     this.initStates = init;
/*      */     
/*  385 */     this.a = 32768;
/*  386 */     this.c = 0;
/*  387 */     if (this.b == 255) {
/*  388 */       this.cT = 13;
/*      */     } else {
/*  390 */       this.cT = 12;
/*      */     } 
/*  392 */     resetCtxts();
/*      */ 
/*      */ 
/*      */     
/*  396 */     this.b = 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void fastCodeSymbols(int bit, int ctxt, int n) {
/*  429 */     int li = this.I[ctxt];
/*  430 */     int q = qe[li];
/*      */     int ns;
/*  432 */     if (q <= 16384 && bit == this.mPS[ctxt] && (ns = (this.a - 32768) / q + 1) > 1) {
/*      */       
/*      */       do
/*      */       {
/*      */         
/*  437 */         if (n <= ns) {
/*      */           
/*  439 */           int i = n * q;
/*  440 */           this.a -= i;
/*  441 */           this.c += i;
/*  442 */           if (this.a >= 32768) {
/*  443 */             this.I[ctxt] = li;
/*      */             return;
/*      */           } 
/*  446 */           this.I[ctxt] = nMPS[li];
/*      */           
/*  448 */           this.a <<= 1;
/*  449 */           this.c <<= 1;
/*  450 */           this.cT--;
/*  451 */           if (this.cT == 0) {
/*  452 */             byteOut();
/*      */           }
/*      */ 
/*      */           
/*      */           return;
/*      */         } 
/*      */         
/*  459 */         int la = ns * q;
/*  460 */         this.c += la;
/*  461 */         this.a -= la;
/*      */         
/*  463 */         li = nMPS[li];
/*  464 */         q = qe[li];
/*      */ 
/*      */ 
/*      */         
/*  468 */         this.a <<= 1;
/*  469 */         this.c <<= 1;
/*  470 */         this.cT--;
/*  471 */         if (this.cT == 0) {
/*  472 */           byteOut();
/*      */         }
/*      */         
/*  475 */         n -= ns;
/*  476 */         ns = (this.a - 32768) / q + 1;
/*      */       
/*      */       }
/*  479 */       while (n > 0);
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */       
/*  485 */       int la = this.a;
/*      */       while (true) {
/*  487 */         if (bit == this.mPS[ctxt]) {
/*  488 */           la -= q;
/*  489 */           if (la >= 32768) {
/*  490 */             this.c += q;
/*      */           } else {
/*      */             
/*  493 */             if (la < q) {
/*  494 */               la = q;
/*      */             } else {
/*  496 */               this.c += q;
/*      */             } 
/*  498 */             li = nMPS[li];
/*  499 */             q = qe[li];
/*      */ 
/*      */             
/*  502 */             la <<= 1;
/*  503 */             this.c <<= 1;
/*  504 */             this.cT--;
/*  505 */             if (this.cT == 0) {
/*  506 */               byteOut();
/*      */             }
/*      */           }
/*      */         
/*      */         } else {
/*      */           
/*  512 */           la -= q;
/*  513 */           if (la < q) {
/*  514 */             this.c += q;
/*      */           } else {
/*  516 */             la = q;
/*  517 */           }  if (switchLM[li] != 0) {
/*  518 */             this.mPS[ctxt] = 1 - this.mPS[ctxt];
/*      */           }
/*      */           
/*  521 */           li = nLPS[li];
/*  522 */           q = qe[li];
/*      */ 
/*      */ 
/*      */           
/*  526 */           int nc = 0;
/*      */           while (true) {
/*  528 */             la <<= 1;
/*  529 */             nc++;
/*  530 */             if (la >= 32768) {
/*  531 */               if (this.cT > nc) {
/*  532 */                 this.c <<= nc;
/*  533 */                 this.cT -= nc;
/*      */                 break;
/*      */               } 
/*      */               while (true) {
/*  537 */                 this.c <<= this.cT;
/*  538 */                 nc -= this.cT;
/*      */                 
/*  540 */                 byteOut();
/*  541 */                 if (this.cT > nc)
/*  542 */                 { this.c <<= nc;
/*  543 */                   this.cT -= nc; break; } 
/*      */               }  break;
/*      */             } 
/*      */           } 
/*  547 */         }  n--;
/*  548 */         if (n <= 0) {
/*  549 */           this.I[ctxt] = li;
/*  550 */           this.a = la;
/*      */           return;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void codeSymbols(int[] bits, int[] cX, int n) {
/*  584 */     int la = this.a;
/*  585 */     for (int i = 0; i < n; i++) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  594 */       int ctxt = cX[i];
/*  595 */       int li = this.I[ctxt];
/*  596 */       int q = qe[li];
/*      */       
/*  598 */       if (bits[i] == this.mPS[ctxt]) {
/*      */         
/*  600 */         la -= q;
/*      */         
/*  602 */         if (la >= 32768) {
/*  603 */           this.c += q;
/*      */         } else {
/*      */           
/*  606 */           if (la < q) {
/*  607 */             la = q;
/*      */           } else {
/*  609 */             this.c += q;
/*      */           } 
/*  611 */           this.I[ctxt] = nMPS[li];
/*      */ 
/*      */           
/*  614 */           la <<= 1;
/*  615 */           this.c <<= 1;
/*  616 */           this.cT--;
/*  617 */           if (this.cT == 0) {
/*  618 */             byteOut();
/*      */           }
/*      */         }
/*      */       
/*      */       } else {
/*      */         
/*  624 */         la -= q;
/*      */         
/*  626 */         if (la < q) {
/*  627 */           this.c += q;
/*      */         } else {
/*  629 */           la = q;
/*  630 */         }  if (switchLM[li] != 0) {
/*  631 */           this.mPS[ctxt] = 1 - this.mPS[ctxt];
/*      */         }
/*  633 */         this.I[ctxt] = nLPS[li];
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  638 */         int nc = 0;
/*      */         while (true) {
/*  640 */           la <<= 1;
/*  641 */           nc++;
/*  642 */           if (la >= 32768) {
/*  643 */             if (this.cT > nc) {
/*  644 */               this.c <<= nc;
/*  645 */               this.cT -= nc;
/*      */               break;
/*      */             } 
/*      */             while (true) {
/*  649 */               this.c <<= this.cT;
/*  650 */               nc -= this.cT;
/*      */               
/*  652 */               byteOut();
/*  653 */               if (this.cT > nc) {
/*  654 */                 this.c <<= nc;
/*  655 */                 this.cT -= nc; break;
/*      */               } 
/*      */             }  break;
/*      */           } 
/*      */         } 
/*      */       } 
/*  661 */     }  this.a = la;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void codeSymbol(int bit, int context) {
/*  692 */     int li = this.I[context];
/*  693 */     int q = qe[li];
/*      */     
/*  695 */     if (bit == this.mPS[context]) {
/*      */       
/*  697 */       this.a -= q;
/*      */       
/*  699 */       if (this.a >= 32768) {
/*  700 */         this.c += q;
/*      */       } else {
/*      */         
/*  703 */         if (this.a < q) {
/*  704 */           this.a = q;
/*      */         } else {
/*  706 */           this.c += q;
/*      */         } 
/*  708 */         this.I[context] = nMPS[li];
/*      */ 
/*      */         
/*  711 */         this.a <<= 1;
/*  712 */         this.c <<= 1;
/*  713 */         this.cT--;
/*  714 */         if (this.cT == 0) {
/*  715 */           byteOut();
/*      */         }
/*      */       }
/*      */     
/*      */     }
/*      */     else {
/*      */       
/*  722 */       int la = this.a;
/*  723 */       la -= q;
/*      */       
/*  725 */       if (la < q) {
/*  726 */         this.c += q;
/*      */       } else {
/*  728 */         la = q;
/*  729 */       }  if (switchLM[li] != 0) {
/*  730 */         this.mPS[context] = 1 - this.mPS[context];
/*      */       }
/*  732 */       this.I[context] = nLPS[li];
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  737 */       int n = 0;
/*      */       while (true) {
/*  739 */         la <<= 1;
/*  740 */         n++;
/*  741 */         if (la >= 32768) {
/*  742 */           if (this.cT > n) {
/*  743 */             this.c <<= n;
/*  744 */             this.cT -= n;
/*      */             continue;
/*      */           } 
/*      */           while (true) {
/*  748 */             this.c <<= this.cT;
/*  749 */             n -= this.cT;
/*      */             
/*  751 */             byteOut();
/*  752 */             if (this.cT > n) {
/*  753 */               this.c <<= n;
/*  754 */               this.cT -= n;
/*      */ 
/*      */ 
/*      */               
/*  758 */               this.a = la;
/*      */               return;
/*      */             } 
/*      */           } 
/*      */           break;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void byteOut() {
/*  770 */     if (this.nrOfWrittenBytes >= 0) {
/*  771 */       if (this.b == 255) {
/*      */         
/*  773 */         this.delFF = true;
/*  774 */         this.b = this.c >>> 20;
/*  775 */         this.c &= 0xFFFFF;
/*  776 */         this.cT = 7;
/*      */       }
/*  778 */       else if (this.c < 134217728) {
/*      */         
/*  780 */         if (this.delFF) {
/*  781 */           this.out.write(255);
/*  782 */           this.delFF = false;
/*  783 */           this.nrOfWrittenBytes++;
/*      */         } 
/*  785 */         this.out.write(this.b);
/*  786 */         this.nrOfWrittenBytes++;
/*  787 */         this.b = this.c >>> 19;
/*  788 */         this.c &= 0x7FFFF;
/*  789 */         this.cT = 8;
/*      */       } else {
/*      */         
/*  792 */         this.b++;
/*  793 */         if (this.b == 255)
/*      */         {
/*  795 */           this.delFF = true;
/*  796 */           this.c &= 0x7FFFFFF;
/*  797 */           this.b = this.c >>> 20;
/*  798 */           this.c &= 0xFFFFF;
/*  799 */           this.cT = 7;
/*      */         }
/*      */         else
/*      */         {
/*  803 */           if (this.delFF) {
/*  804 */             this.out.write(255);
/*  805 */             this.delFF = false;
/*  806 */             this.nrOfWrittenBytes++;
/*      */           } 
/*  808 */           this.out.write(this.b);
/*  809 */           this.nrOfWrittenBytes++;
/*  810 */           this.b = this.c >>> 19 & 0xFF;
/*  811 */           this.c &= 0x7FFFF;
/*  812 */           this.cT = 8;
/*      */         }
/*      */       
/*      */       } 
/*      */     } else {
/*      */       
/*  818 */       this.b = this.c >>> 19;
/*  819 */       this.c &= 0x7FFFF;
/*  820 */       this.cT = 8;
/*  821 */       this.nrOfWrittenBytes++;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int terminate() {
/*      */     int tempc;
/*      */     int len;
/*      */     int remainingBits;
/*      */     int k;
/*      */     int cLow;
/*      */     int cUp;
/*      */     int bLow;
/*      */     int bUp;
/*  842 */     switch (this.ttype) {
/*      */       
/*      */       case 0:
/*  845 */         tempc = this.c + this.a;
/*  846 */         this.c |= 0xFFFF;
/*  847 */         if (this.c >= tempc) {
/*  848 */           this.c -= 32768;
/*      */         }
/*  850 */         remainingBits = 27 - this.cT;
/*      */ 
/*      */         
/*      */         do {
/*  854 */           this.c <<= this.cT;
/*  855 */           if (this.b != 255) {
/*  856 */             remainingBits -= 8;
/*      */           } else {
/*  858 */             remainingBits -= 7;
/*  859 */           }  byteOut();
/*      */         }
/*  861 */         while (remainingBits > 0);
/*      */         
/*  863 */         this.b |= (1 << -remainingBits) - 1;
/*  864 */         if (this.b == 255) {
/*  865 */           this.delFF = true;
/*      */         }
/*      */         else {
/*      */           
/*  869 */           if (this.delFF) {
/*  870 */             this.out.write(255);
/*  871 */             this.delFF = false;
/*  872 */             this.nrOfWrittenBytes++;
/*      */           } 
/*  874 */           this.out.write(this.b);
/*  875 */           this.nrOfWrittenBytes++;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1052 */         len = this.nrOfWrittenBytes;
/* 1053 */         this.a = 32768;
/* 1054 */         this.c = 0;
/* 1055 */         this.b = 0;
/* 1056 */         this.cT = 12;
/* 1057 */         this.delFF = false;
/* 1058 */         this.nrOfWrittenBytes = -1;
/*      */ 
/*      */         
/* 1061 */         return len;case 2: case 3: k = 11 - this.cT + 1; this.c <<= this.cT; for (; k > 0; k -= this.cT, this.c <<= this.cT) byteOut();  if (k < 0 && this.ttype == 2) this.b |= (1 << -k) - 1;  byteOut(); len = this.nrOfWrittenBytes; this.a = 32768; this.c = 0; this.b = 0; this.cT = 12; this.delFF = false; this.nrOfWrittenBytes = -1; return len;case 1: cLow = this.c; cUp = this.c + this.a; bLow = bUp = this.b; cLow <<= this.cT; cUp <<= this.cT; if ((cLow & 0x8000000) != 0) if (bLow == 255) { this.delFF = true; bLow = cLow >>> 20; bUp = cUp >>> 20; cLow &= 0xFFFFF; cUp &= 0xFFFFF; cLow <<= 7; cUp <<= 7; } else { bLow++; cLow &= 0xF7FFFFFF; }   if ((cUp & 0x8000000) != 0) { bUp++; cUp &= 0xF7FFFFFF; }  while (true) { if (this.delFF) { if (bLow <= 127 && bUp > 127) break;  this.out.write(255); this.nrOfWrittenBytes++; this.delFF = false; } else if (bLow <= 255 && bUp > 255) { break; }  if (bLow < 255) { if (this.nrOfWrittenBytes >= 0) this.out.write(bLow);  this.nrOfWrittenBytes++; bUp -= bLow; bUp <<= 8; bUp |= cUp >>> 19 & 0xFF; bLow = cLow >>> 19 & 0xFF; cLow &= 0x7FFFF; cUp &= 0x7FFFF; cLow <<= 8; cUp <<= 8; continue; }  this.delFF = true; bUp -= bLow; bUp <<= 7; bUp |= cUp >> 20 & 0x7F; bLow = cLow >> 20 & 0x7F; cLow &= 0xFFFFF; cUp &= 0xFFFFF; cLow <<= 7; cUp <<= 7; }  len = this.nrOfWrittenBytes; this.a = 32768; this.c = 0; this.b = 0; this.cT = 12; this.delFF = false; this.nrOfWrittenBytes = -1; return len;
/*      */     } 
/*      */     throw new Error("Illegal termination type code");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getNumCtxts() {
/* 1070 */     return this.I.length;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void resetCtxt(int c) {
/* 1080 */     this.I[c] = this.initStates[c];
/* 1081 */     this.mPS[c] = 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void resetCtxts() {
/* 1089 */     System.arraycopy(this.initStates, 0, this.I, 0, this.I.length);
/* 1090 */     ArrayUtil.intArraySet(this.mPS, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getNumCodedBytes() {
/*      */     int bitsInN3Bytes;
/* 1120 */     switch (this.ltype) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 1:
/* 1126 */         if (this.b >= 254) {
/*      */ 
/*      */           
/* 1129 */           bitsInN3Bytes = 22;
/*      */         
/*      */         }
/*      */         else {
/*      */           
/* 1134 */           bitsInN3Bytes = 23;
/*      */         } 
/* 1136 */         if (11 - this.cT + 16 <= bitsInN3Bytes) {
/* 1137 */           return this.nrOfWrittenBytes + (this.delFF ? 1 : 0) + 1 + 3;
/*      */         }
/*      */         
/* 1140 */         return this.nrOfWrittenBytes + (this.delFF ? 1 : 0) + 1 + 4;
/*      */ 
/*      */       
/*      */       case 0:
/* 1144 */         if (27 - this.cT <= 22) {
/* 1145 */           return this.nrOfWrittenBytes + (this.delFF ? 1 : 0) + 1 + 3;
/*      */         }
/*      */         
/* 1148 */         return this.nrOfWrittenBytes + (this.delFF ? 1 : 0) + 1 + 4;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 2:
/* 1157 */         saveState();
/*      */ 
/*      */         
/* 1160 */         return this.nrOfWrittenBytes;
/*      */     } 
/* 1162 */     throw new Error("Illegal length calculation type code");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void reset() {
/* 1176 */     this.out.reset();
/*      */     
/* 1178 */     this.a = 32768;
/* 1179 */     this.c = 0;
/* 1180 */     this.b = 0;
/* 1181 */     if (this.b == 255) {
/* 1182 */       this.cT = 13;
/*      */     } else {
/* 1184 */       this.cT = 12;
/* 1185 */     }  resetCtxts();
/* 1186 */     this.nrOfWrittenBytes = -1;
/* 1187 */     this.delFF = false;
/*      */     
/* 1189 */     this.nSaved = 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void saveState() {
/* 1199 */     if (this.nSaved == this.savedC.length) {
/*      */       
/* 1201 */       Object tmp = this.savedC;
/* 1202 */       this.savedC = new int[this.nSaved + 12];
/* 1203 */       System.arraycopy(tmp, 0, this.savedC, 0, this.nSaved);
/* 1204 */       tmp = this.savedCT;
/* 1205 */       this.savedCT = new int[this.nSaved + 12];
/* 1206 */       System.arraycopy(tmp, 0, this.savedCT, 0, this.nSaved);
/* 1207 */       tmp = this.savedA;
/* 1208 */       this.savedA = new int[this.nSaved + 12];
/* 1209 */       System.arraycopy(tmp, 0, this.savedA, 0, this.nSaved);
/* 1210 */       tmp = this.savedB;
/* 1211 */       this.savedB = new int[this.nSaved + 12];
/* 1212 */       System.arraycopy(tmp, 0, this.savedB, 0, this.nSaved);
/* 1213 */       tmp = this.savedDelFF;
/* 1214 */       this.savedDelFF = new boolean[this.nSaved + 12];
/* 1215 */       System.arraycopy(tmp, 0, this.savedDelFF, 0, this.nSaved);
/*      */     } 
/*      */     
/* 1218 */     this.savedC[this.nSaved] = this.c;
/* 1219 */     this.savedCT[this.nSaved] = this.cT;
/* 1220 */     this.savedA[this.nSaved] = this.a;
/* 1221 */     this.savedB[this.nSaved] = this.b;
/* 1222 */     this.savedDelFF[this.nSaved] = this.delFF;
/* 1223 */     this.nSaved++;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void finishLengthCalculation(int[] rates, int n) {
/* 1241 */     if (this.ltype != 2) {
/*      */ 
/*      */ 
/*      */       
/* 1245 */       if (n > 0 && rates[n - 1] > rates[n])
/*      */       {
/* 1247 */         int tl = rates[n];
/* 1248 */         n--;
/*      */         do {
/* 1250 */           rates[n--] = tl;
/* 1251 */         } while (n >= 0 && rates[n] > tl);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1290 */       int ridx = n - this.nSaved;
/*      */       
/* 1292 */       int minlen = (ridx - 1 >= 0) ? rates[ridx - 1] : 0;
/*      */       
/* 1294 */       int maxlen = rates[n];
/* 1295 */       for (int sidx = 0; ridx < n; ridx++, sidx++) {
/*      */         
/* 1297 */         int cLow = this.savedC[sidx];
/* 1298 */         int cUp = this.savedC[sidx] + this.savedA[sidx];
/* 1299 */         int bLow = this.savedB[sidx];
/* 1300 */         int bUp = this.savedB[sidx];
/*      */         
/* 1302 */         cLow <<= this.savedCT[sidx];
/* 1303 */         if ((cLow & 0x8000000) != 0) {
/* 1304 */           bLow++;
/* 1305 */           cLow &= 0x7FFFFFF;
/*      */         } 
/* 1307 */         cUp <<= this.savedCT[sidx];
/* 1308 */         if ((cUp & 0x8000000) != 0) {
/* 1309 */           bUp++;
/* 1310 */           cUp &= 0x7FFFFFF;
/*      */         } 
/*      */         
/* 1313 */         boolean cdFF = this.savedDelFF[sidx];
/*      */ 
/*      */ 
/*      */         
/* 1317 */         int clen = rates[ridx] + (cdFF ? 1 : 0);
/*      */         
/*      */         while (true) {
/* 1320 */           if (clen >= maxlen) {
/* 1321 */             clen = maxlen;
/*      */             
/*      */             break;
/*      */           } 
/* 1325 */           if (cdFF) {
/* 1326 */             if (bLow < 128 && bUp >= 128) {
/*      */               
/* 1328 */               clen--;
/*      */ 
/*      */               
/*      */               break;
/*      */             } 
/* 1333 */           } else if (bLow < 256 && bUp >= 256) {
/*      */             break;
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1340 */           int nb = (clen >= minlen) ? this.out.getByte(clen) : 0;
/* 1341 */           bLow -= nb;
/* 1342 */           bUp -= nb;
/* 1343 */           clen++;
/* 1344 */           if (nb == 255) {
/* 1345 */             bLow <<= 7;
/* 1346 */             bLow |= cLow >> 20 & 0x7F;
/* 1347 */             cLow &= 0xFFFFF;
/* 1348 */             cLow <<= 7;
/* 1349 */             bUp <<= 7;
/* 1350 */             bUp |= cUp >> 20 & 0x7F;
/* 1351 */             cUp &= 0xFFFFF;
/* 1352 */             cUp <<= 7;
/* 1353 */             cdFF = true;
/*      */             continue;
/*      */           } 
/* 1356 */           bLow <<= 8;
/* 1357 */           bLow |= cLow >> 19 & 0xFF;
/* 1358 */           cLow &= 0x7FFFF;
/* 1359 */           cLow <<= 8;
/* 1360 */           bUp <<= 8;
/* 1361 */           bUp |= cUp >> 19 & 0xFF;
/* 1362 */           cUp &= 0x7FFFF;
/* 1363 */           cUp <<= 8;
/* 1364 */           cdFF = false;
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 1369 */         rates[ridx] = (clen >= minlen) ? clen : minlen;
/*      */       } 
/*      */       
/* 1372 */       this.nSaved = 0;
/*      */     } 
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/entropy/encoder/MQCoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */