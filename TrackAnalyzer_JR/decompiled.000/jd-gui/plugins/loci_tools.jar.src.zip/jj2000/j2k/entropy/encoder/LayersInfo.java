/*     */ package jj2000.j2k.entropy.encoder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LayersInfo
/*     */ {
/*     */   private static final int SZ_INIT = 10;
/*     */   private static final int SZ_INCR = 5;
/* 123 */   int totlyrs = 1;
/*     */ 
/*     */ 
/*     */   
/*     */   float totbrate;
/*     */ 
/*     */   
/*     */   int nopt;
/*     */ 
/*     */   
/* 133 */   float[] optbrate = new float[10];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 140 */   int[] extralyrs = new int[10];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LayersInfo(float brate) {
/* 153 */     if (brate <= 0.0F) {
/* 154 */       throw new IllegalArgumentException("Overall target bitrate must be a positive number");
/*     */     }
/*     */     
/* 157 */     this.totbrate = brate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getTotBitrate() {
/* 168 */     return this.totbrate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTotNumLayers() {
/* 180 */     return this.totlyrs;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNOptPoints() {
/* 193 */     return this.nopt + 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getTargetBitrate(int n) {
/* 207 */     return (n < this.nopt) ? this.optbrate[n] : this.totbrate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getExtraLayers(int n) {
/* 224 */     return (n < this.nopt) ? this.extralyrs[n] : 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addOptPoint(float brate, int elyrs) {
/* 242 */     if (brate <= 0.0F) {
/* 243 */       throw new IllegalArgumentException("Target bitrate must be positive");
/*     */     }
/*     */     
/* 246 */     if (elyrs < 0) {
/* 247 */       throw new IllegalArgumentException("The number of extra layers must be 0 or more");
/*     */     }
/*     */     
/* 250 */     if (this.nopt > 0 && this.optbrate[this.nopt - 1] >= brate) {
/* 251 */       throw new IllegalArgumentException("New optimization point must have a target bitrate higher than the preceding one");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 257 */     if (this.optbrate.length == this.nopt) {
/* 258 */       float[] tbr = this.optbrate;
/* 259 */       int[] tel = this.extralyrs;
/*     */       
/* 261 */       this.optbrate = new float[this.optbrate.length + 5];
/* 262 */       this.extralyrs = new int[this.extralyrs.length + 5];
/* 263 */       System.arraycopy(tbr, 0, this.optbrate, 0, this.nopt);
/* 264 */       System.arraycopy(tel, 0, this.extralyrs, 0, this.nopt);
/*     */     } 
/*     */     
/* 267 */     this.optbrate[this.nopt] = brate;
/* 268 */     this.extralyrs[this.nopt] = elyrs;
/* 269 */     this.nopt++;
/*     */     
/* 271 */     this.totlyrs += 1 + elyrs;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/entropy/encoder/LayersInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */