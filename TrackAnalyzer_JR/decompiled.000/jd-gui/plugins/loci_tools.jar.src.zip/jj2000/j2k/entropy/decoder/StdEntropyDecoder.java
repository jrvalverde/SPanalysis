/*      */ package jj2000.j2k.entropy.decoder;
/*      */ 
/*      */ import jj2000.j2k.decoder.DecoderSpecs;
/*      */ import jj2000.j2k.entropy.StdEntropyCoderOptions;
/*      */ import jj2000.j2k.image.DataBlk;
/*      */ import jj2000.j2k.image.DataBlkInt;
/*      */ import jj2000.j2k.util.ArrayUtil;
/*      */ import jj2000.j2k.util.FacilityManager;
/*      */ import jj2000.j2k.wavelet.synthesis.SubbandSyn;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class StdEntropyDecoder
/*      */   extends EntropyDecoder
/*      */   implements StdEntropyCoderOptions
/*      */ {
/*      */   private static final boolean DO_TIMING = false;
/*      */   private long[] time;
/*      */   private ByteToBitInput bin;
/*      */   private MQDecoder mq;
/*      */   private DecoderSpecs decSpec;
/*      */   private int options;
/*      */   private final boolean doer;
/*      */   private final boolean verber;
/*      */   private static final int ZC_LUT_BITS = 8;
/*  158 */   private static final int[] ZC_LUT_LH = new int[256];
/*      */ 
/*      */   
/*  161 */   private static final int[] ZC_LUT_HL = new int[256];
/*      */ 
/*      */   
/*  164 */   private static final int[] ZC_LUT_HH = new int[256];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int SC_LUT_BITS = 9;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  178 */   private static final int[] SC_LUT = new int[512];
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int SC_LUT_MASK = 15;
/*      */ 
/*      */   
/*      */   private static final int SC_SPRED_SHIFT = 31;
/*      */ 
/*      */   
/*      */   private static final int INT_SIGN_BIT = -2147483648;
/*      */ 
/*      */   
/*      */   private static final int MR_LUT_BITS = 9;
/*      */ 
/*      */   
/*  194 */   private static final int[] MR_LUT = new int[512];
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int NUM_CTXTS = 19;
/*      */ 
/*      */   
/*      */   private static final int RLC_CTXT = 1;
/*      */ 
/*      */   
/*      */   private static final int UNIF_CTXT = 0;
/*      */ 
/*      */   
/*  207 */   private static final int[] MQ_INIT = new int[] { 46, 3, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int SEG_SYMBOL = 10;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int[] state;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int STATE_SEP = 16;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int STATE_SIG_R1 = 32768;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int STATE_VISITED_R1 = 16384;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int STATE_NZ_CTXT_R1 = 8192;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int STATE_H_L_SIGN_R1 = 4096;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int STATE_H_R_SIGN_R1 = 2048;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int STATE_V_U_SIGN_R1 = 1024;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int STATE_V_D_SIGN_R1 = 512;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int STATE_PREV_MR_R1 = 256;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int STATE_H_L_R1 = 128;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int STATE_H_R_R1 = 64;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int STATE_V_U_R1 = 32;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int STATE_V_D_R1 = 16;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int STATE_D_UL_R1 = 8;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int STATE_D_UR_R1 = 4;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int STATE_D_DL_R1 = 2;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int STATE_D_DR_R1 = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int STATE_SIG_R2 = -2147483648;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int STATE_VISITED_R2 = 1073741824;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int STATE_NZ_CTXT_R2 = 536870912;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int STATE_H_L_SIGN_R2 = 268435456;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int STATE_H_R_SIGN_R2 = 134217728;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int STATE_V_U_SIGN_R2 = 67108864;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int STATE_V_D_SIGN_R2 = 33554432;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int STATE_PREV_MR_R2 = 16777216;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int STATE_H_L_R2 = 8388608;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int STATE_H_R_R2 = 4194304;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int STATE_V_U_R2 = 2097152;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int STATE_V_D_R2 = 1048576;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int STATE_D_UL_R2 = 524288;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int STATE_D_UR_R2 = 262144;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int STATE_D_DL_R2 = 131072;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int STATE_D_DR_R2 = 65536;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int SIG_MASK_R1R2 = -2147450880;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int VSTD_MASK_R1R2 = 1073758208;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int RLC_MASK_R1R2 = -536813568;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int ZC_MASK = 255;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int SC_SHIFT_R1 = 4;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int SC_SHIFT_R2 = 20;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int SC_MASK = 511;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int MR_MASK = 511;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private DecLyrdCBlk srcblk;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int mQuit;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static {
/*  438 */     ZC_LUT_LH[0] = 2;
/*      */     int i;
/*  440 */     for (i = 1; i < 16; i++) {
/*  441 */       ZC_LUT_LH[i] = 4;
/*      */     }
/*  443 */     for (i = 0; i < 4; i++) {
/*  444 */       ZC_LUT_LH[1 << i] = 3;
/*      */     }
/*      */     
/*  447 */     for (i = 0; i < 16; i++) {
/*      */       
/*  449 */       ZC_LUT_LH[0x20 | i] = 5;
/*  450 */       ZC_LUT_LH[0x10 | i] = 5;
/*      */       
/*  452 */       ZC_LUT_LH[0x30 | i] = 6;
/*      */     } 
/*      */     
/*  455 */     ZC_LUT_LH[128] = 7;
/*  456 */     ZC_LUT_LH[64] = 7;
/*      */ 
/*      */     
/*  459 */     for (i = 1; i < 16; i++) {
/*  460 */       ZC_LUT_LH[0x80 | i] = 8;
/*  461 */       ZC_LUT_LH[0x40 | i] = 8;
/*      */     } 
/*      */ 
/*      */     
/*  465 */     for (i = 1; i < 4; i++) {
/*  466 */       for (int k = 0; k < 16; k++) {
/*  467 */         ZC_LUT_LH[0x80 | i << 4 | k] = 9;
/*  468 */         ZC_LUT_LH[0x40 | i << 4 | k] = 9;
/*      */       } 
/*      */     } 
/*      */     
/*  472 */     for (i = 0; i < 64; i++) {
/*  473 */       ZC_LUT_LH[0xC0 | i] = 10;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  479 */     ZC_LUT_HL[0] = 2;
/*      */     
/*  481 */     for (i = 1; i < 16; i++) {
/*  482 */       ZC_LUT_HL[i] = 4;
/*      */     }
/*  484 */     for (i = 0; i < 4; i++) {
/*  485 */       ZC_LUT_HL[1 << i] = 3;
/*      */     }
/*      */     
/*  488 */     for (i = 0; i < 16; i++) {
/*      */       
/*  490 */       ZC_LUT_HL[0x80 | i] = 5;
/*  491 */       ZC_LUT_HL[0x40 | i] = 5;
/*      */       
/*  493 */       ZC_LUT_HL[0xC0 | i] = 6;
/*      */     } 
/*      */     
/*  496 */     ZC_LUT_HL[32] = 7;
/*  497 */     ZC_LUT_HL[16] = 7;
/*      */ 
/*      */     
/*  500 */     for (i = 1; i < 16; i++) {
/*  501 */       ZC_LUT_HL[0x20 | i] = 8;
/*  502 */       ZC_LUT_HL[0x10 | i] = 8;
/*      */     } 
/*      */ 
/*      */     
/*  506 */     for (i = 1; i < 4; i++) {
/*  507 */       for (int k = 0; k < 16; k++) {
/*  508 */         ZC_LUT_HL[i << 6 | 0x20 | k] = 9;
/*  509 */         ZC_LUT_HL[i << 6 | 0x10 | k] = 9;
/*      */       } 
/*      */     } 
/*      */     
/*  513 */     for (i = 0; i < 4; i++) {
/*  514 */       for (int k = 0; k < 16; k++) {
/*  515 */         ZC_LUT_HL[i << 6 | 0x20 | 0x10 | k] = 10;
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  520 */     int[] twoBits = { 3, 5, 6, 9, 10, 12 };
/*      */ 
/*      */     
/*  523 */     int[] oneBit = { 1, 2, 4, 8 };
/*      */ 
/*      */     
/*  526 */     int[] twoLeast = { 3, 5, 6, 7, 9, 10, 11, 12, 13, 14, 15 };
/*      */ 
/*      */ 
/*      */     
/*  530 */     int[] threeLeast = { 7, 11, 13, 14, 15 };
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  535 */     ZC_LUT_HH[0] = 2;
/*      */ 
/*      */     
/*  538 */     for (i = 0; i < oneBit.length; i++) {
/*  539 */       ZC_LUT_HH[oneBit[i] << 4] = 3;
/*      */     }
/*      */     
/*  542 */     for (i = 0; i < twoLeast.length; i++) {
/*  543 */       ZC_LUT_HH[twoLeast[i] << 4] = 4;
/*      */     }
/*      */     
/*  546 */     for (i = 0; i < oneBit.length; i++) {
/*  547 */       ZC_LUT_HH[oneBit[i]] = 5;
/*      */     }
/*      */     
/*  550 */     for (i = 0; i < oneBit.length; i++) {
/*  551 */       for (int k = 0; k < oneBit.length; k++) {
/*  552 */         ZC_LUT_HH[oneBit[i] << 4 | oneBit[k]] = 6;
/*      */       }
/*      */     } 
/*  555 */     for (i = 0; i < twoLeast.length; i++) {
/*  556 */       for (int k = 0; k < oneBit.length; k++) {
/*  557 */         ZC_LUT_HH[twoLeast[i] << 4 | oneBit[k]] = 7;
/*      */       }
/*      */     } 
/*  560 */     for (i = 0; i < twoBits.length; i++) {
/*  561 */       ZC_LUT_HH[twoBits[i]] = 8;
/*      */     }
/*      */     int j;
/*  564 */     for (j = 0; j < twoBits.length; j++) {
/*  565 */       for (i = 1; i < 16; i++) {
/*  566 */         ZC_LUT_HH[i << 4 | twoBits[j]] = 9;
/*      */       }
/*      */     } 
/*  569 */     for (i = 0; i < 16; i++) {
/*  570 */       for (j = 0; j < threeLeast.length; j++) {
/*  571 */         ZC_LUT_HH[i << 4 | threeLeast[j]] = 10;
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  580 */     int[] inter_sc_lut = new int[36];
/*  581 */     inter_sc_lut[18] = 15;
/*  582 */     inter_sc_lut[17] = 14;
/*  583 */     inter_sc_lut[16] = 13;
/*  584 */     inter_sc_lut[10] = 12;
/*  585 */     inter_sc_lut[9] = 11;
/*  586 */     inter_sc_lut[8] = -2147483636;
/*  587 */     inter_sc_lut[2] = -2147483635;
/*  588 */     inter_sc_lut[1] = -2147483634;
/*  589 */     inter_sc_lut[0] = -2147483633;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  598 */     for (i = 0; i < 511; i++) {
/*  599 */       int ds = i & 0x1;
/*  600 */       int us = i >> 1 & 0x1;
/*  601 */       int rs = i >> 2 & 0x1;
/*  602 */       int ls = i >> 3 & 0x1;
/*  603 */       int dsgn = i >> 5 & 0x1;
/*  604 */       int usgn = i >> 6 & 0x1;
/*  605 */       int rsgn = i >> 7 & 0x1;
/*  606 */       int lsgn = i >> 8 & 0x1;
/*      */       
/*  608 */       int h = ls * (1 - 2 * lsgn) + rs * (1 - 2 * rsgn);
/*  609 */       h = (h >= -1) ? h : -1;
/*  610 */       h = (h <= 1) ? h : 1;
/*  611 */       int v = us * (1 - 2 * usgn) + ds * (1 - 2 * dsgn);
/*  612 */       v = (v >= -1) ? v : -1;
/*  613 */       v = (v <= 1) ? v : 1;
/*      */       
/*  615 */       SC_LUT[i] = inter_sc_lut[h + 1 << 3 | v + 1];
/*      */     } 
/*  617 */     inter_sc_lut = null;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  622 */     MR_LUT[0] = 16;
/*      */     
/*  624 */     for (i = 1; i < 256; i++) {
/*  625 */       MR_LUT[i] = 17;
/*      */     }
/*      */     
/*  628 */     for (; i < 512; i++) {
/*  629 */       MR_LUT[i] = 18;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StdEntropyDecoder(CodedCBlkDataSrcDec src, DecoderSpecs decSpec, boolean doer, boolean verber, int mQuit) {
/*  651 */     super(src);
/*      */     
/*  653 */     this.decSpec = decSpec;
/*  654 */     this.doer = doer;
/*  655 */     this.verber = verber;
/*  656 */     this.mQuit = mQuit;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  666 */     this.state = new int[(decSpec.cblks.getMaxCBlkWidth() + 2) * ((decSpec.cblks.getMaxCBlkHeight() + 1) / 2 + 2)];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void finalize() throws Throwable {
/*  691 */     super.finalize();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DataBlk getCodeBlock(int c, int m, int n, SubbandSyn sb, DataBlk cblk) {
/*      */     DataBlkInt dataBlkInt;
/*      */     int[] zc_lut;
/*  739 */     long stime = 0L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  747 */     ByteInputBuffer in = null;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  752 */     this.srcblk = this.src.getCodeBlock(c, m, n, sb, 1, -1, this.srcblk);
/*      */ 
/*      */ 
/*      */     
/*  756 */     this.options = ((Integer)this.decSpec.ecopts.getTileCompVal(this.tIdx, c)).intValue();
/*      */ 
/*      */ 
/*      */     
/*  760 */     ArrayUtil.intArraySet(this.state, 0);
/*      */ 
/*      */     
/*  763 */     if (cblk == null) {
/*  764 */       dataBlkInt = new DataBlkInt();
/*      */     }
/*  766 */     ((DataBlk)dataBlkInt).progressive = this.srcblk.prog;
/*  767 */     ((DataBlk)dataBlkInt).ulx = this.srcblk.ulx;
/*  768 */     ((DataBlk)dataBlkInt).uly = this.srcblk.uly;
/*  769 */     ((DataBlk)dataBlkInt).w = this.srcblk.w;
/*  770 */     ((DataBlk)dataBlkInt).h = this.srcblk.h;
/*  771 */     ((DataBlk)dataBlkInt).offset = 0;
/*  772 */     ((DataBlk)dataBlkInt).scanw = ((DataBlk)dataBlkInt).w;
/*  773 */     int[] out_data = (int[])dataBlkInt.getData();
/*      */     
/*  775 */     if (out_data == null || out_data.length < this.srcblk.w * this.srcblk.h) {
/*  776 */       out_data = new int[this.srcblk.w * this.srcblk.h];
/*  777 */       dataBlkInt.setData(out_data);
/*      */     } else {
/*      */       
/*  780 */       ArrayUtil.intArraySet(out_data, 0);
/*      */     } 
/*      */     
/*  783 */     if (this.srcblk.nl <= 0 || this.srcblk.nTrunc <= 0)
/*      */     {
/*  785 */       return (DataBlk)dataBlkInt;
/*      */     }
/*      */ 
/*      */     
/*  789 */     int tslen = (this.srcblk.tsLengths == null) ? this.srcblk.dl : this.srcblk.tsLengths[0];
/*  790 */     int tsidx = 0;
/*      */     
/*  792 */     int npasses = this.srcblk.nTrunc;
/*  793 */     if (this.mq == null) {
/*  794 */       in = new ByteInputBuffer(this.srcblk.data, 0, tslen);
/*  795 */       this.mq = new MQDecoder(in, 19, MQ_INIT);
/*      */     }
/*      */     else {
/*      */       
/*  799 */       this.mq.nextSegment(this.srcblk.data, 0, tslen);
/*  800 */       this.mq.resetCtxts();
/*      */     } 
/*  802 */     boolean error = false;
/*      */     
/*  804 */     if ((this.options & 0x1) != 0 && 
/*  805 */       this.bin == null) {
/*  806 */       if (in == null) in = this.mq.getByteInputBuffer(); 
/*  807 */       this.bin = new ByteToBitInput(in);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  812 */     switch (sb.orientation) {
/*      */       case 1:
/*  814 */         zc_lut = ZC_LUT_HL;
/*      */         break;
/*      */       case 0:
/*      */       case 2:
/*  818 */         zc_lut = ZC_LUT_LH;
/*      */         break;
/*      */       case 3:
/*  821 */         zc_lut = ZC_LUT_HH;
/*      */         break;
/*      */       default:
/*  824 */         throw new Error("JJ2000 internal error");
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  838 */     int curbp = 30 - this.srcblk.skipMSBP;
/*      */ 
/*      */     
/*  841 */     if (this.mQuit != -1 && this.mQuit * 3 - 2 < npasses) {
/*  842 */       npasses = this.mQuit * 3 - 2;
/*      */     }
/*      */ 
/*      */     
/*  846 */     if (curbp >= 0 && npasses > 0) {
/*  847 */       boolean isterm = ((this.options & 0x4) != 0 || ((this.options & 0x1) != 0 && 27 - this.srcblk.skipMSBP >= curbp));
/*      */ 
/*      */       
/*  850 */       error = cleanuppass((DataBlk)dataBlkInt, this.mq, curbp, this.state, zc_lut, isterm);
/*  851 */       npasses--;
/*  852 */       if (!error || !this.doer) curbp--;
/*      */     
/*      */     } 
/*      */     
/*  856 */     if (!error || !this.doer) {
/*  857 */       while (curbp >= 0 && npasses > 0) {
/*      */         
/*  859 */         if ((this.options & 0x1) != 0 && curbp < 27 - this.srcblk.skipMSBP) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  865 */           this.bin.setByteArray(null, -1, this.srcblk.tsLengths[++tsidx]);
/*  866 */           boolean isterm = ((this.options & 0x4) != 0);
/*  867 */           error = rawSigProgPass((DataBlk)dataBlkInt, this.bin, curbp, this.state, isterm);
/*  868 */           npasses--;
/*  869 */           if (npasses <= 0 || (error && this.doer))
/*      */             break; 
/*  871 */           if ((this.options & 0x4) != 0)
/*      */           {
/*  873 */             this.bin.setByteArray(null, -1, this.srcblk.tsLengths[++tsidx]);
/*      */           }
/*  875 */           isterm = ((this.options & 0x4) != 0 || ((this.options & 0x1) != 0 && 27 - this.srcblk.skipMSBP > curbp));
/*      */ 
/*      */           
/*  878 */           error = rawMagRefPass((DataBlk)dataBlkInt, this.bin, curbp, this.state, isterm);
/*      */         } else {
/*      */           
/*  881 */           if ((this.options & 0x4) != 0)
/*      */           {
/*  883 */             this.mq.nextSegment(null, -1, this.srcblk.tsLengths[++tsidx]);
/*      */           }
/*  885 */           boolean isterm = ((this.options & 0x4) != 0);
/*  886 */           error = sigProgPass((DataBlk)dataBlkInt, this.mq, curbp, this.state, zc_lut, isterm);
/*  887 */           npasses--;
/*  888 */           if (npasses <= 0 || (error && this.doer))
/*      */             break; 
/*  890 */           if ((this.options & 0x4) != 0)
/*      */           {
/*  892 */             this.mq.nextSegment(null, -1, this.srcblk.tsLengths[++tsidx]);
/*      */           }
/*  894 */           isterm = ((this.options & 0x4) != 0 || ((this.options & 0x1) != 0 && 27 - this.srcblk.skipMSBP > curbp));
/*      */ 
/*      */           
/*  897 */           error = magRefPass((DataBlk)dataBlkInt, this.mq, curbp, this.state, isterm);
/*      */         } 
/*      */         
/*  900 */         npasses--;
/*  901 */         if (npasses <= 0 || (error && this.doer))
/*      */           break; 
/*  903 */         if ((this.options & 0x4) != 0 || ((this.options & 0x1) != 0 && curbp < 27 - this.srcblk.skipMSBP))
/*      */         {
/*      */ 
/*      */           
/*  907 */           this.mq.nextSegment(null, -1, this.srcblk.tsLengths[++tsidx]);
/*      */         }
/*  909 */         boolean bool = ((this.options & 0x4) != 0 || ((this.options & 0x1) != 0 && 27 - this.srcblk.skipMSBP >= curbp)) ? true : false;
/*      */ 
/*      */         
/*  912 */         error = cleanuppass((DataBlk)dataBlkInt, this.mq, curbp, this.state, zc_lut, bool);
/*  913 */         npasses--;
/*  914 */         if (error)
/*      */           break; 
/*  916 */         curbp--;
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*  921 */     if (error && this.doer) {
/*  922 */       if (this.verber) {
/*  923 */         FacilityManager.getMsgLogger().printmsg(2, "Error detected at bit-plane " + curbp + " in code-block (" + m + "," + n + "), sb_idx " + sb.sbandIdx + ", res. level " + sb.resLvl + ". Concealing...");
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  931 */       conceal((DataBlk)dataBlkInt, curbp);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  937 */     return (DataBlk)dataBlkInt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DataBlk getInternCodeBlock(int c, int m, int n, SubbandSyn sb, DataBlk cblk) {
/*  984 */     return getCodeBlock(c, m, n, sb, cblk);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean sigProgPass(DataBlk cblk, MQDecoder mq, int bp, int[] state, int[] zc_lut, boolean isterm) {
/*      */     // Byte code:
/*      */     //   0: aload_1
/*      */     //   1: getfield scanw : I
/*      */     //   4: istore #11
/*      */     //   6: aload_1
/*      */     //   7: getfield w : I
/*      */     //   10: iconst_2
/*      */     //   11: iadd
/*      */     //   12: istore #12
/*      */     //   14: iload #12
/*      */     //   16: iconst_4
/*      */     //   17: imul
/*      */     //   18: iconst_2
/*      */     //   19: idiv
/*      */     //   20: aload_1
/*      */     //   21: getfield w : I
/*      */     //   24: isub
/*      */     //   25: istore #13
/*      */     //   27: iload #11
/*      */     //   29: iconst_4
/*      */     //   30: imul
/*      */     //   31: aload_1
/*      */     //   32: getfield w : I
/*      */     //   35: isub
/*      */     //   36: istore #14
/*      */     //   38: iconst_3
/*      */     //   39: iload_3
/*      */     //   40: ishl
/*      */     //   41: iconst_1
/*      */     //   42: ishr
/*      */     //   43: istore #17
/*      */     //   45: aload_1
/*      */     //   46: invokevirtual getData : ()Ljava/lang/Object;
/*      */     //   49: checkcast [I
/*      */     //   52: checkcast [I
/*      */     //   55: astore #20
/*      */     //   57: aload_1
/*      */     //   58: getfield h : I
/*      */     //   61: iconst_4
/*      */     //   62: iadd
/*      */     //   63: iconst_1
/*      */     //   64: isub
/*      */     //   65: iconst_4
/*      */     //   66: idiv
/*      */     //   67: istore #23
/*      */     //   69: aload_0
/*      */     //   70: getfield options : I
/*      */     //   73: bipush #8
/*      */     //   75: iand
/*      */     //   76: ifeq -> 83
/*      */     //   79: iconst_1
/*      */     //   80: goto -> 84
/*      */     //   83: iconst_0
/*      */     //   84: istore #22
/*      */     //   86: iload #12
/*      */     //   88: ineg
/*      */     //   89: iconst_1
/*      */     //   90: isub
/*      */     //   91: istore #25
/*      */     //   93: iload #12
/*      */     //   95: ineg
/*      */     //   96: iconst_1
/*      */     //   97: iadd
/*      */     //   98: istore #26
/*      */     //   100: iload #12
/*      */     //   102: iconst_1
/*      */     //   103: iadd
/*      */     //   104: istore #27
/*      */     //   106: iload #12
/*      */     //   108: iconst_1
/*      */     //   109: isub
/*      */     //   110: istore #28
/*      */     //   112: aload_1
/*      */     //   113: getfield offset : I
/*      */     //   116: istore #10
/*      */     //   118: iload #12
/*      */     //   120: iconst_1
/*      */     //   121: iadd
/*      */     //   122: istore #8
/*      */     //   124: iload #23
/*      */     //   126: iconst_1
/*      */     //   127: isub
/*      */     //   128: istore #21
/*      */     //   130: iload #21
/*      */     //   132: iflt -> 1182
/*      */     //   135: iload #21
/*      */     //   137: ifeq -> 144
/*      */     //   140: iconst_4
/*      */     //   141: goto -> 155
/*      */     //   144: aload_1
/*      */     //   145: getfield h : I
/*      */     //   148: iload #23
/*      */     //   150: iconst_1
/*      */     //   151: isub
/*      */     //   152: iconst_4
/*      */     //   153: imul
/*      */     //   154: isub
/*      */     //   155: istore #24
/*      */     //   157: iload #10
/*      */     //   159: aload_1
/*      */     //   160: getfield w : I
/*      */     //   163: iadd
/*      */     //   164: istore #15
/*      */     //   166: iload #10
/*      */     //   168: iload #15
/*      */     //   170: if_icmpge -> 1162
/*      */     //   173: iload #8
/*      */     //   175: istore #7
/*      */     //   177: aload #4
/*      */     //   179: iload #7
/*      */     //   181: iaload
/*      */     //   182: istore #16
/*      */     //   184: iload #16
/*      */     //   186: iconst_m1
/*      */     //   187: ixor
/*      */     //   188: iload #16
/*      */     //   190: iconst_2
/*      */     //   191: ishl
/*      */     //   192: iand
/*      */     //   193: ldc -2147450880
/*      */     //   195: iand
/*      */     //   196: ifeq -> 662
/*      */     //   199: iload #10
/*      */     //   201: istore #9
/*      */     //   203: iload #16
/*      */     //   205: ldc 40960
/*      */     //   207: iand
/*      */     //   208: sipush #8192
/*      */     //   211: if_icmpne -> 422
/*      */     //   214: aload_2
/*      */     //   215: aload #5
/*      */     //   217: iload #16
/*      */     //   219: sipush #255
/*      */     //   222: iand
/*      */     //   223: iaload
/*      */     //   224: invokevirtual decodeSymbol : (I)I
/*      */     //   227: ifeq -> 414
/*      */     //   230: getstatic jj2000/j2k/entropy/decoder/StdEntropyDecoder.SC_LUT : [I
/*      */     //   233: iload #16
/*      */     //   235: iconst_4
/*      */     //   236: iushr
/*      */     //   237: sipush #511
/*      */     //   240: iand
/*      */     //   241: iaload
/*      */     //   242: istore #19
/*      */     //   244: aload_2
/*      */     //   245: iload #19
/*      */     //   247: bipush #15
/*      */     //   249: iand
/*      */     //   250: invokevirtual decodeSymbol : (I)I
/*      */     //   253: iload #19
/*      */     //   255: bipush #31
/*      */     //   257: iushr
/*      */     //   258: ixor
/*      */     //   259: istore #18
/*      */     //   261: aload #20
/*      */     //   263: iload #9
/*      */     //   265: iload #18
/*      */     //   267: bipush #31
/*      */     //   269: ishl
/*      */     //   270: iload #17
/*      */     //   272: ior
/*      */     //   273: iastore
/*      */     //   274: iload #22
/*      */     //   276: ifne -> 305
/*      */     //   279: aload #4
/*      */     //   281: iload #7
/*      */     //   283: iload #25
/*      */     //   285: iadd
/*      */     //   286: dup2
/*      */     //   287: iaload
/*      */     //   288: ldc 536936448
/*      */     //   290: ior
/*      */     //   291: iastore
/*      */     //   292: aload #4
/*      */     //   294: iload #7
/*      */     //   296: iload #26
/*      */     //   298: iadd
/*      */     //   299: dup2
/*      */     //   300: iaload
/*      */     //   301: ldc 537001984
/*      */     //   303: ior
/*      */     //   304: iastore
/*      */     //   305: iload #18
/*      */     //   307: ifeq -> 362
/*      */     //   310: iload #16
/*      */     //   312: ldc 606126080
/*      */     //   314: ior
/*      */     //   315: istore #16
/*      */     //   317: iload #22
/*      */     //   319: ifne -> 335
/*      */     //   322: aload #4
/*      */     //   324: iload #7
/*      */     //   326: iload #12
/*      */     //   328: isub
/*      */     //   329: dup2
/*      */     //   330: iaload
/*      */     //   331: ldc 571473920
/*      */     //   333: ior
/*      */     //   334: iastore
/*      */     //   335: aload #4
/*      */     //   337: iload #7
/*      */     //   339: iconst_1
/*      */     //   340: iadd
/*      */     //   341: dup2
/*      */     //   342: iaload
/*      */     //   343: ldc 537407616
/*      */     //   345: ior
/*      */     //   346: iastore
/*      */     //   347: aload #4
/*      */     //   349: iload #7
/*      */     //   351: iconst_1
/*      */     //   352: isub
/*      */     //   353: dup2
/*      */     //   354: iaload
/*      */     //   355: ldc 537143360
/*      */     //   357: ior
/*      */     //   358: iastore
/*      */     //   359: goto -> 422
/*      */     //   362: iload #16
/*      */     //   364: ldc 539017216
/*      */     //   366: ior
/*      */     //   367: istore #16
/*      */     //   369: iload #22
/*      */     //   371: ifne -> 387
/*      */     //   374: aload #4
/*      */     //   376: iload #7
/*      */     //   378: iload #12
/*      */     //   380: isub
/*      */     //   381: dup2
/*      */     //   382: iaload
/*      */     //   383: ldc 537919488
/*      */     //   385: ior
/*      */     //   386: iastore
/*      */     //   387: aload #4
/*      */     //   389: iload #7
/*      */     //   391: iconst_1
/*      */     //   392: iadd
/*      */     //   393: dup2
/*      */     //   394: iaload
/*      */     //   395: ldc 537403520
/*      */     //   397: ior
/*      */     //   398: iastore
/*      */     //   399: aload #4
/*      */     //   401: iload #7
/*      */     //   403: iconst_1
/*      */     //   404: isub
/*      */     //   405: dup2
/*      */     //   406: iaload
/*      */     //   407: ldc 537141312
/*      */     //   409: ior
/*      */     //   410: iastore
/*      */     //   411: goto -> 422
/*      */     //   414: iload #16
/*      */     //   416: sipush #16384
/*      */     //   419: ior
/*      */     //   420: istore #16
/*      */     //   422: iload #24
/*      */     //   424: iconst_2
/*      */     //   425: if_icmpge -> 438
/*      */     //   428: aload #4
/*      */     //   430: iload #7
/*      */     //   432: iload #16
/*      */     //   434: iastore
/*      */     //   435: goto -> 1153
/*      */     //   438: iload #16
/*      */     //   440: ldc -1610612736
/*      */     //   442: iand
/*      */     //   443: ldc 536870912
/*      */     //   445: if_icmpne -> 655
/*      */     //   448: iload #9
/*      */     //   450: iload #11
/*      */     //   452: iadd
/*      */     //   453: istore #9
/*      */     //   455: aload_2
/*      */     //   456: aload #5
/*      */     //   458: iload #16
/*      */     //   460: bipush #16
/*      */     //   462: iushr
/*      */     //   463: sipush #255
/*      */     //   466: iand
/*      */     //   467: iaload
/*      */     //   468: invokevirtual decodeSymbol : (I)I
/*      */     //   471: ifeq -> 648
/*      */     //   474: getstatic jj2000/j2k/entropy/decoder/StdEntropyDecoder.SC_LUT : [I
/*      */     //   477: iload #16
/*      */     //   479: bipush #20
/*      */     //   481: iushr
/*      */     //   482: sipush #511
/*      */     //   485: iand
/*      */     //   486: iaload
/*      */     //   487: istore #19
/*      */     //   489: aload_2
/*      */     //   490: iload #19
/*      */     //   492: bipush #15
/*      */     //   494: iand
/*      */     //   495: invokevirtual decodeSymbol : (I)I
/*      */     //   498: iload #19
/*      */     //   500: bipush #31
/*      */     //   502: iushr
/*      */     //   503: ixor
/*      */     //   504: istore #18
/*      */     //   506: aload #20
/*      */     //   508: iload #9
/*      */     //   510: iload #18
/*      */     //   512: bipush #31
/*      */     //   514: ishl
/*      */     //   515: iload #17
/*      */     //   517: ior
/*      */     //   518: iastore
/*      */     //   519: aload #4
/*      */     //   521: iload #7
/*      */     //   523: iload #28
/*      */     //   525: iadd
/*      */     //   526: dup2
/*      */     //   527: iaload
/*      */     //   528: sipush #8196
/*      */     //   531: ior
/*      */     //   532: iastore
/*      */     //   533: aload #4
/*      */     //   535: iload #7
/*      */     //   537: iload #27
/*      */     //   539: iadd
/*      */     //   540: dup2
/*      */     //   541: iaload
/*      */     //   542: sipush #8200
/*      */     //   545: ior
/*      */     //   546: iastore
/*      */     //   547: iload #18
/*      */     //   549: ifeq -> 600
/*      */     //   552: iload #16
/*      */     //   554: ldc -1073733104
/*      */     //   556: ior
/*      */     //   557: istore #16
/*      */     //   559: aload #4
/*      */     //   561: iload #7
/*      */     //   563: iload #12
/*      */     //   565: iadd
/*      */     //   566: dup2
/*      */     //   567: iaload
/*      */     //   568: sipush #9248
/*      */     //   571: ior
/*      */     //   572: iastore
/*      */     //   573: aload #4
/*      */     //   575: iload #7
/*      */     //   577: iconst_1
/*      */     //   578: iadd
/*      */     //   579: dup2
/*      */     //   580: iaload
/*      */     //   581: ldc 813703170
/*      */     //   583: ior
/*      */     //   584: iastore
/*      */     //   585: aload #4
/*      */     //   587: iload #7
/*      */     //   589: iconst_1
/*      */     //   590: isub
/*      */     //   591: dup2
/*      */     //   592: iaload
/*      */     //   593: ldc 675291137
/*      */     //   595: ior
/*      */     //   596: iastore
/*      */     //   597: goto -> 655
/*      */     //   600: iload #16
/*      */     //   602: ldc -1073733616
/*      */     //   604: ior
/*      */     //   605: istore #16
/*      */     //   607: aload #4
/*      */     //   609: iload #7
/*      */     //   611: iload #12
/*      */     //   613: iadd
/*      */     //   614: dup2
/*      */     //   615: iaload
/*      */     //   616: sipush #8224
/*      */     //   619: ior
/*      */     //   620: iastore
/*      */     //   621: aload #4
/*      */     //   623: iload #7
/*      */     //   625: iconst_1
/*      */     //   626: iadd
/*      */     //   627: dup2
/*      */     //   628: iaload
/*      */     //   629: ldc 545267714
/*      */     //   631: ior
/*      */     //   632: iastore
/*      */     //   633: aload #4
/*      */     //   635: iload #7
/*      */     //   637: iconst_1
/*      */     //   638: isub
/*      */     //   639: dup2
/*      */     //   640: iaload
/*      */     //   641: ldc 541073409
/*      */     //   643: ior
/*      */     //   644: iastore
/*      */     //   645: goto -> 655
/*      */     //   648: iload #16
/*      */     //   650: ldc 1073741824
/*      */     //   652: ior
/*      */     //   653: istore #16
/*      */     //   655: aload #4
/*      */     //   657: iload #7
/*      */     //   659: iload #16
/*      */     //   661: iastore
/*      */     //   662: iload #24
/*      */     //   664: iconst_3
/*      */     //   665: if_icmpge -> 671
/*      */     //   668: goto -> 1153
/*      */     //   671: iload #7
/*      */     //   673: iload #12
/*      */     //   675: iadd
/*      */     //   676: istore #7
/*      */     //   678: aload #4
/*      */     //   680: iload #7
/*      */     //   682: iaload
/*      */     //   683: istore #16
/*      */     //   685: iload #16
/*      */     //   687: iconst_m1
/*      */     //   688: ixor
/*      */     //   689: iload #16
/*      */     //   691: iconst_2
/*      */     //   692: ishl
/*      */     //   693: iand
/*      */     //   694: ldc -2147450880
/*      */     //   696: iand
/*      */     //   697: ifeq -> 1153
/*      */     //   700: iload #10
/*      */     //   702: iload #11
/*      */     //   704: iconst_1
/*      */     //   705: ishl
/*      */     //   706: iadd
/*      */     //   707: istore #9
/*      */     //   709: iload #16
/*      */     //   711: ldc 40960
/*      */     //   713: iand
/*      */     //   714: sipush #8192
/*      */     //   717: if_icmpne -> 913
/*      */     //   720: aload_2
/*      */     //   721: aload #5
/*      */     //   723: iload #16
/*      */     //   725: sipush #255
/*      */     //   728: iand
/*      */     //   729: iaload
/*      */     //   730: invokevirtual decodeSymbol : (I)I
/*      */     //   733: ifeq -> 905
/*      */     //   736: getstatic jj2000/j2k/entropy/decoder/StdEntropyDecoder.SC_LUT : [I
/*      */     //   739: iload #16
/*      */     //   741: iconst_4
/*      */     //   742: iushr
/*      */     //   743: sipush #511
/*      */     //   746: iand
/*      */     //   747: iaload
/*      */     //   748: istore #19
/*      */     //   750: aload_2
/*      */     //   751: iload #19
/*      */     //   753: bipush #15
/*      */     //   755: iand
/*      */     //   756: invokevirtual decodeSymbol : (I)I
/*      */     //   759: iload #19
/*      */     //   761: bipush #31
/*      */     //   763: iushr
/*      */     //   764: ixor
/*      */     //   765: istore #18
/*      */     //   767: aload #20
/*      */     //   769: iload #9
/*      */     //   771: iload #18
/*      */     //   773: bipush #31
/*      */     //   775: ishl
/*      */     //   776: iload #17
/*      */     //   778: ior
/*      */     //   779: iastore
/*      */     //   780: aload #4
/*      */     //   782: iload #7
/*      */     //   784: iload #25
/*      */     //   786: iadd
/*      */     //   787: dup2
/*      */     //   788: iaload
/*      */     //   789: ldc 536936448
/*      */     //   791: ior
/*      */     //   792: iastore
/*      */     //   793: aload #4
/*      */     //   795: iload #7
/*      */     //   797: iload #26
/*      */     //   799: iadd
/*      */     //   800: dup2
/*      */     //   801: iaload
/*      */     //   802: ldc 537001984
/*      */     //   804: ior
/*      */     //   805: iastore
/*      */     //   806: iload #18
/*      */     //   808: ifeq -> 858
/*      */     //   811: iload #16
/*      */     //   813: ldc 606126080
/*      */     //   815: ior
/*      */     //   816: istore #16
/*      */     //   818: aload #4
/*      */     //   820: iload #7
/*      */     //   822: iload #12
/*      */     //   824: isub
/*      */     //   825: dup2
/*      */     //   826: iaload
/*      */     //   827: ldc 571473920
/*      */     //   829: ior
/*      */     //   830: iastore
/*      */     //   831: aload #4
/*      */     //   833: iload #7
/*      */     //   835: iconst_1
/*      */     //   836: iadd
/*      */     //   837: dup2
/*      */     //   838: iaload
/*      */     //   839: ldc 537407616
/*      */     //   841: ior
/*      */     //   842: iastore
/*      */     //   843: aload #4
/*      */     //   845: iload #7
/*      */     //   847: iconst_1
/*      */     //   848: isub
/*      */     //   849: dup2
/*      */     //   850: iaload
/*      */     //   851: ldc 537143360
/*      */     //   853: ior
/*      */     //   854: iastore
/*      */     //   855: goto -> 913
/*      */     //   858: iload #16
/*      */     //   860: ldc 539017216
/*      */     //   862: ior
/*      */     //   863: istore #16
/*      */     //   865: aload #4
/*      */     //   867: iload #7
/*      */     //   869: iload #12
/*      */     //   871: isub
/*      */     //   872: dup2
/*      */     //   873: iaload
/*      */     //   874: ldc 537919488
/*      */     //   876: ior
/*      */     //   877: iastore
/*      */     //   878: aload #4
/*      */     //   880: iload #7
/*      */     //   882: iconst_1
/*      */     //   883: iadd
/*      */     //   884: dup2
/*      */     //   885: iaload
/*      */     //   886: ldc 537403520
/*      */     //   888: ior
/*      */     //   889: iastore
/*      */     //   890: aload #4
/*      */     //   892: iload #7
/*      */     //   894: iconst_1
/*      */     //   895: isub
/*      */     //   896: dup2
/*      */     //   897: iaload
/*      */     //   898: ldc 537141312
/*      */     //   900: ior
/*      */     //   901: iastore
/*      */     //   902: goto -> 913
/*      */     //   905: iload #16
/*      */     //   907: sipush #16384
/*      */     //   910: ior
/*      */     //   911: istore #16
/*      */     //   913: iload #24
/*      */     //   915: iconst_4
/*      */     //   916: if_icmpge -> 929
/*      */     //   919: aload #4
/*      */     //   921: iload #7
/*      */     //   923: iload #16
/*      */     //   925: iastore
/*      */     //   926: goto -> 1153
/*      */     //   929: iload #16
/*      */     //   931: ldc -1610612736
/*      */     //   933: iand
/*      */     //   934: ldc 536870912
/*      */     //   936: if_icmpne -> 1146
/*      */     //   939: iload #9
/*      */     //   941: iload #11
/*      */     //   943: iadd
/*      */     //   944: istore #9
/*      */     //   946: aload_2
/*      */     //   947: aload #5
/*      */     //   949: iload #16
/*      */     //   951: bipush #16
/*      */     //   953: iushr
/*      */     //   954: sipush #255
/*      */     //   957: iand
/*      */     //   958: iaload
/*      */     //   959: invokevirtual decodeSymbol : (I)I
/*      */     //   962: ifeq -> 1139
/*      */     //   965: getstatic jj2000/j2k/entropy/decoder/StdEntropyDecoder.SC_LUT : [I
/*      */     //   968: iload #16
/*      */     //   970: bipush #20
/*      */     //   972: iushr
/*      */     //   973: sipush #511
/*      */     //   976: iand
/*      */     //   977: iaload
/*      */     //   978: istore #19
/*      */     //   980: aload_2
/*      */     //   981: iload #19
/*      */     //   983: bipush #15
/*      */     //   985: iand
/*      */     //   986: invokevirtual decodeSymbol : (I)I
/*      */     //   989: iload #19
/*      */     //   991: bipush #31
/*      */     //   993: iushr
/*      */     //   994: ixor
/*      */     //   995: istore #18
/*      */     //   997: aload #20
/*      */     //   999: iload #9
/*      */     //   1001: iload #18
/*      */     //   1003: bipush #31
/*      */     //   1005: ishl
/*      */     //   1006: iload #17
/*      */     //   1008: ior
/*      */     //   1009: iastore
/*      */     //   1010: aload #4
/*      */     //   1012: iload #7
/*      */     //   1014: iload #28
/*      */     //   1016: iadd
/*      */     //   1017: dup2
/*      */     //   1018: iaload
/*      */     //   1019: sipush #8196
/*      */     //   1022: ior
/*      */     //   1023: iastore
/*      */     //   1024: aload #4
/*      */     //   1026: iload #7
/*      */     //   1028: iload #27
/*      */     //   1030: iadd
/*      */     //   1031: dup2
/*      */     //   1032: iaload
/*      */     //   1033: sipush #8200
/*      */     //   1036: ior
/*      */     //   1037: iastore
/*      */     //   1038: iload #18
/*      */     //   1040: ifeq -> 1091
/*      */     //   1043: iload #16
/*      */     //   1045: ldc -1073733104
/*      */     //   1047: ior
/*      */     //   1048: istore #16
/*      */     //   1050: aload #4
/*      */     //   1052: iload #7
/*      */     //   1054: iload #12
/*      */     //   1056: iadd
/*      */     //   1057: dup2
/*      */     //   1058: iaload
/*      */     //   1059: sipush #9248
/*      */     //   1062: ior
/*      */     //   1063: iastore
/*      */     //   1064: aload #4
/*      */     //   1066: iload #7
/*      */     //   1068: iconst_1
/*      */     //   1069: iadd
/*      */     //   1070: dup2
/*      */     //   1071: iaload
/*      */     //   1072: ldc 813703170
/*      */     //   1074: ior
/*      */     //   1075: iastore
/*      */     //   1076: aload #4
/*      */     //   1078: iload #7
/*      */     //   1080: iconst_1
/*      */     //   1081: isub
/*      */     //   1082: dup2
/*      */     //   1083: iaload
/*      */     //   1084: ldc 675291137
/*      */     //   1086: ior
/*      */     //   1087: iastore
/*      */     //   1088: goto -> 1146
/*      */     //   1091: iload #16
/*      */     //   1093: ldc -1073733616
/*      */     //   1095: ior
/*      */     //   1096: istore #16
/*      */     //   1098: aload #4
/*      */     //   1100: iload #7
/*      */     //   1102: iload #12
/*      */     //   1104: iadd
/*      */     //   1105: dup2
/*      */     //   1106: iaload
/*      */     //   1107: sipush #8224
/*      */     //   1110: ior
/*      */     //   1111: iastore
/*      */     //   1112: aload #4
/*      */     //   1114: iload #7
/*      */     //   1116: iconst_1
/*      */     //   1117: iadd
/*      */     //   1118: dup2
/*      */     //   1119: iaload
/*      */     //   1120: ldc 545267714
/*      */     //   1122: ior
/*      */     //   1123: iastore
/*      */     //   1124: aload #4
/*      */     //   1126: iload #7
/*      */     //   1128: iconst_1
/*      */     //   1129: isub
/*      */     //   1130: dup2
/*      */     //   1131: iaload
/*      */     //   1132: ldc 541073409
/*      */     //   1134: ior
/*      */     //   1135: iastore
/*      */     //   1136: goto -> 1146
/*      */     //   1139: iload #16
/*      */     //   1141: ldc 1073741824
/*      */     //   1143: ior
/*      */     //   1144: istore #16
/*      */     //   1146: aload #4
/*      */     //   1148: iload #7
/*      */     //   1150: iload #16
/*      */     //   1152: iastore
/*      */     //   1153: iinc #10, 1
/*      */     //   1156: iinc #8, 1
/*      */     //   1159: goto -> 166
/*      */     //   1162: iinc #21, -1
/*      */     //   1165: iload #10
/*      */     //   1167: iload #14
/*      */     //   1169: iadd
/*      */     //   1170: istore #10
/*      */     //   1172: iload #8
/*      */     //   1174: iload #13
/*      */     //   1176: iadd
/*      */     //   1177: istore #8
/*      */     //   1179: goto -> 130
/*      */     //   1182: iconst_0
/*      */     //   1183: istore #29
/*      */     //   1185: iload #6
/*      */     //   1187: ifeq -> 1206
/*      */     //   1190: aload_0
/*      */     //   1191: getfield options : I
/*      */     //   1194: bipush #16
/*      */     //   1196: iand
/*      */     //   1197: ifeq -> 1206
/*      */     //   1200: aload_2
/*      */     //   1201: invokevirtual checkPredTerm : ()Z
/*      */     //   1204: istore #29
/*      */     //   1206: aload_0
/*      */     //   1207: getfield options : I
/*      */     //   1210: iconst_2
/*      */     //   1211: iand
/*      */     //   1212: ifeq -> 1219
/*      */     //   1215: aload_2
/*      */     //   1216: invokevirtual resetCtxts : ()V
/*      */     //   1219: iload #29
/*      */     //   1221: ireturn
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #1041	-> 0
/*      */     //   #1042	-> 6
/*      */     //   #1043	-> 14
/*      */     //   #1044	-> 27
/*      */     //   #1045	-> 38
/*      */     //   #1046	-> 45
/*      */     //   #1047	-> 57
/*      */     //   #1048	-> 69
/*      */     //   #1051	-> 86
/*      */     //   #1052	-> 93
/*      */     //   #1053	-> 100
/*      */     //   #1054	-> 106
/*      */     //   #1057	-> 112
/*      */     //   #1058	-> 118
/*      */     //   #1059	-> 124
/*      */     //   #1060	-> 135
/*      */     //   #1062	-> 157
/*      */     //   #1064	-> 166
/*      */     //   #1066	-> 173
/*      */     //   #1067	-> 177
/*      */     //   #1071	-> 184
/*      */     //   #1072	-> 199
/*      */     //   #1074	-> 203
/*      */     //   #1077	-> 214
/*      */     //   #1080	-> 230
/*      */     //   #1081	-> 244
/*      */     //   #1084	-> 261
/*      */     //   #1089	-> 274
/*      */     //   #1092	-> 279
/*      */     //   #1094	-> 292
/*      */     //   #1098	-> 305
/*      */     //   #1099	-> 310
/*      */     //   #1102	-> 317
/*      */     //   #1105	-> 322
/*      */     //   #1108	-> 335
/*      */     //   #1112	-> 347
/*      */     //   #1118	-> 362
/*      */     //   #1120	-> 369
/*      */     //   #1123	-> 374
/*      */     //   #1126	-> 387
/*      */     //   #1129	-> 399
/*      */     //   #1135	-> 414
/*      */     //   #1138	-> 422
/*      */     //   #1139	-> 428
/*      */     //   #1140	-> 435
/*      */     //   #1143	-> 438
/*      */     //   #1145	-> 448
/*      */     //   #1147	-> 455
/*      */     //   #1151	-> 474
/*      */     //   #1152	-> 489
/*      */     //   #1155	-> 506
/*      */     //   #1160	-> 519
/*      */     //   #1161	-> 533
/*      */     //   #1163	-> 547
/*      */     //   #1164	-> 552
/*      */     //   #1167	-> 559
/*      */     //   #1169	-> 573
/*      */     //   #1173	-> 585
/*      */     //   #1179	-> 600
/*      */     //   #1181	-> 607
/*      */     //   #1183	-> 621
/*      */     //   #1186	-> 633
/*      */     //   #1192	-> 648
/*      */     //   #1195	-> 655
/*      */     //   #1198	-> 662
/*      */     //   #1199	-> 671
/*      */     //   #1200	-> 678
/*      */     //   #1204	-> 685
/*      */     //   #1205	-> 700
/*      */     //   #1207	-> 709
/*      */     //   #1210	-> 720
/*      */     //   #1213	-> 736
/*      */     //   #1214	-> 750
/*      */     //   #1217	-> 767
/*      */     //   #1222	-> 780
/*      */     //   #1224	-> 793
/*      */     //   #1227	-> 806
/*      */     //   #1228	-> 811
/*      */     //   #1231	-> 818
/*      */     //   #1233	-> 831
/*      */     //   #1237	-> 843
/*      */     //   #1243	-> 858
/*      */     //   #1245	-> 865
/*      */     //   #1247	-> 878
/*      */     //   #1250	-> 890
/*      */     //   #1256	-> 905
/*      */     //   #1259	-> 913
/*      */     //   #1260	-> 919
/*      */     //   #1261	-> 926
/*      */     //   #1264	-> 929
/*      */     //   #1266	-> 939
/*      */     //   #1268	-> 946
/*      */     //   #1272	-> 965
/*      */     //   #1273	-> 980
/*      */     //   #1276	-> 997
/*      */     //   #1281	-> 1010
/*      */     //   #1282	-> 1024
/*      */     //   #1284	-> 1038
/*      */     //   #1285	-> 1043
/*      */     //   #1288	-> 1050
/*      */     //   #1290	-> 1064
/*      */     //   #1294	-> 1076
/*      */     //   #1300	-> 1091
/*      */     //   #1302	-> 1098
/*      */     //   #1304	-> 1112
/*      */     //   #1307	-> 1124
/*      */     //   #1313	-> 1139
/*      */     //   #1316	-> 1146
/*      */     //   #1064	-> 1153
/*      */     //   #1059	-> 1162
/*      */     //   #1321	-> 1182
/*      */     //   #1324	-> 1185
/*      */     //   #1325	-> 1200
/*      */     //   #1329	-> 1206
/*      */     //   #1330	-> 1215
/*      */     //   #1334	-> 1219
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   261	153	18	sym	I
/*      */     //   244	170	19	ctxt	I
/*      */     //   506	142	18	sym	I
/*      */     //   489	159	19	ctxt	I
/*      */     //   203	459	9	k	I
/*      */     //   767	138	18	sym	I
/*      */     //   750	155	19	ctxt	I
/*      */     //   997	142	18	sym	I
/*      */     //   980	159	19	ctxt	I
/*      */     //   709	444	9	k	I
/*      */     //   177	985	7	j	I
/*      */     //   184	978	16	csj	I
/*      */     //   166	1016	15	stopsk	I
/*      */     //   157	1025	24	sheight	I
/*      */     //   0	1222	0	this	Ljj2000/j2k/entropy/decoder/StdEntropyDecoder;
/*      */     //   0	1222	1	cblk	Ljj2000/j2k/image/DataBlk;
/*      */     //   0	1222	2	mq	Ljj2000/j2k/entropy/decoder/MQDecoder;
/*      */     //   0	1222	3	bp	I
/*      */     //   0	1222	4	state	[I
/*      */     //   0	1222	5	zc_lut	[I
/*      */     //   0	1222	6	isterm	Z
/*      */     //   124	1098	8	sj	I
/*      */     //   118	1104	10	sk	I
/*      */     //   6	1216	11	dscanw	I
/*      */     //   14	1208	12	sscanw	I
/*      */     //   27	1195	13	jstep	I
/*      */     //   38	1184	14	kstep	I
/*      */     //   45	1177	17	setmask	I
/*      */     //   57	1165	20	data	[I
/*      */     //   130	1092	21	s	I
/*      */     //   86	1136	22	causal	Z
/*      */     //   69	1153	23	nstripes	I
/*      */     //   93	1129	25	off_ul	I
/*      */     //   100	1122	26	off_ur	I
/*      */     //   106	1116	27	off_dr	I
/*      */     //   112	1110	28	off_dl	I
/*      */     //   1185	37	29	error	Z
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean rawSigProgPass(DataBlk cblk, ByteToBitInput bin, int bp, int[] state, boolean isterm) {
/*      */     // Byte code:
/*      */     //   0: aload_1
/*      */     //   1: getfield scanw : I
/*      */     //   4: istore #10
/*      */     //   6: aload_1
/*      */     //   7: getfield w : I
/*      */     //   10: iconst_2
/*      */     //   11: iadd
/*      */     //   12: istore #11
/*      */     //   14: iload #11
/*      */     //   16: iconst_4
/*      */     //   17: imul
/*      */     //   18: iconst_2
/*      */     //   19: idiv
/*      */     //   20: aload_1
/*      */     //   21: getfield w : I
/*      */     //   24: isub
/*      */     //   25: istore #12
/*      */     //   27: iload #10
/*      */     //   29: iconst_4
/*      */     //   30: imul
/*      */     //   31: aload_1
/*      */     //   32: getfield w : I
/*      */     //   35: isub
/*      */     //   36: istore #13
/*      */     //   38: iconst_3
/*      */     //   39: iload_3
/*      */     //   40: ishl
/*      */     //   41: iconst_1
/*      */     //   42: ishr
/*      */     //   43: istore #16
/*      */     //   45: aload_1
/*      */     //   46: invokevirtual getData : ()Ljava/lang/Object;
/*      */     //   49: checkcast [I
/*      */     //   52: checkcast [I
/*      */     //   55: astore #18
/*      */     //   57: aload_1
/*      */     //   58: getfield h : I
/*      */     //   61: iconst_4
/*      */     //   62: iadd
/*      */     //   63: iconst_1
/*      */     //   64: isub
/*      */     //   65: iconst_4
/*      */     //   66: idiv
/*      */     //   67: istore #21
/*      */     //   69: aload_0
/*      */     //   70: getfield options : I
/*      */     //   73: bipush #8
/*      */     //   75: iand
/*      */     //   76: ifeq -> 83
/*      */     //   79: iconst_1
/*      */     //   80: goto -> 84
/*      */     //   83: iconst_0
/*      */     //   84: istore #20
/*      */     //   86: iload #11
/*      */     //   88: ineg
/*      */     //   89: iconst_1
/*      */     //   90: isub
/*      */     //   91: istore #23
/*      */     //   93: iload #11
/*      */     //   95: ineg
/*      */     //   96: iconst_1
/*      */     //   97: iadd
/*      */     //   98: istore #24
/*      */     //   100: iload #11
/*      */     //   102: iconst_1
/*      */     //   103: iadd
/*      */     //   104: istore #25
/*      */     //   106: iload #11
/*      */     //   108: iconst_1
/*      */     //   109: isub
/*      */     //   110: istore #26
/*      */     //   112: aload_1
/*      */     //   113: getfield offset : I
/*      */     //   116: istore #9
/*      */     //   118: iload #11
/*      */     //   120: iconst_1
/*      */     //   121: iadd
/*      */     //   122: istore #7
/*      */     //   124: iload #21
/*      */     //   126: iconst_1
/*      */     //   127: isub
/*      */     //   128: istore #19
/*      */     //   130: iload #19
/*      */     //   132: iflt -> 1038
/*      */     //   135: iload #19
/*      */     //   137: ifeq -> 144
/*      */     //   140: iconst_4
/*      */     //   141: goto -> 155
/*      */     //   144: aload_1
/*      */     //   145: getfield h : I
/*      */     //   148: iload #21
/*      */     //   150: iconst_1
/*      */     //   151: isub
/*      */     //   152: iconst_4
/*      */     //   153: imul
/*      */     //   154: isub
/*      */     //   155: istore #22
/*      */     //   157: iload #9
/*      */     //   159: aload_1
/*      */     //   160: getfield w : I
/*      */     //   163: iadd
/*      */     //   164: istore #14
/*      */     //   166: iload #9
/*      */     //   168: iload #14
/*      */     //   170: if_icmpge -> 1018
/*      */     //   173: iload #7
/*      */     //   175: istore #6
/*      */     //   177: aload #4
/*      */     //   179: iload #6
/*      */     //   181: iaload
/*      */     //   182: istore #15
/*      */     //   184: iload #15
/*      */     //   186: iconst_m1
/*      */     //   187: ixor
/*      */     //   188: iload #15
/*      */     //   190: iconst_2
/*      */     //   191: ishl
/*      */     //   192: iand
/*      */     //   193: ldc -2147450880
/*      */     //   195: iand
/*      */     //   196: ifeq -> 590
/*      */     //   199: iload #9
/*      */     //   201: istore #8
/*      */     //   203: iload #15
/*      */     //   205: ldc 40960
/*      */     //   207: iand
/*      */     //   208: sipush #8192
/*      */     //   211: if_icmpne -> 388
/*      */     //   214: aload_2
/*      */     //   215: invokevirtual readBit : ()I
/*      */     //   218: ifeq -> 380
/*      */     //   221: aload_2
/*      */     //   222: invokevirtual readBit : ()I
/*      */     //   225: istore #17
/*      */     //   227: aload #18
/*      */     //   229: iload #8
/*      */     //   231: iload #17
/*      */     //   233: bipush #31
/*      */     //   235: ishl
/*      */     //   236: iload #16
/*      */     //   238: ior
/*      */     //   239: iastore
/*      */     //   240: iload #20
/*      */     //   242: ifne -> 271
/*      */     //   245: aload #4
/*      */     //   247: iload #6
/*      */     //   249: iload #23
/*      */     //   251: iadd
/*      */     //   252: dup2
/*      */     //   253: iaload
/*      */     //   254: ldc 536936448
/*      */     //   256: ior
/*      */     //   257: iastore
/*      */     //   258: aload #4
/*      */     //   260: iload #6
/*      */     //   262: iload #24
/*      */     //   264: iadd
/*      */     //   265: dup2
/*      */     //   266: iaload
/*      */     //   267: ldc 537001984
/*      */     //   269: ior
/*      */     //   270: iastore
/*      */     //   271: iload #17
/*      */     //   273: ifeq -> 328
/*      */     //   276: iload #15
/*      */     //   278: ldc 606126080
/*      */     //   280: ior
/*      */     //   281: istore #15
/*      */     //   283: iload #20
/*      */     //   285: ifne -> 301
/*      */     //   288: aload #4
/*      */     //   290: iload #6
/*      */     //   292: iload #11
/*      */     //   294: isub
/*      */     //   295: dup2
/*      */     //   296: iaload
/*      */     //   297: ldc 571473920
/*      */     //   299: ior
/*      */     //   300: iastore
/*      */     //   301: aload #4
/*      */     //   303: iload #6
/*      */     //   305: iconst_1
/*      */     //   306: iadd
/*      */     //   307: dup2
/*      */     //   308: iaload
/*      */     //   309: ldc 537407616
/*      */     //   311: ior
/*      */     //   312: iastore
/*      */     //   313: aload #4
/*      */     //   315: iload #6
/*      */     //   317: iconst_1
/*      */     //   318: isub
/*      */     //   319: dup2
/*      */     //   320: iaload
/*      */     //   321: ldc 537143360
/*      */     //   323: ior
/*      */     //   324: iastore
/*      */     //   325: goto -> 388
/*      */     //   328: iload #15
/*      */     //   330: ldc 539017216
/*      */     //   332: ior
/*      */     //   333: istore #15
/*      */     //   335: iload #20
/*      */     //   337: ifne -> 353
/*      */     //   340: aload #4
/*      */     //   342: iload #6
/*      */     //   344: iload #11
/*      */     //   346: isub
/*      */     //   347: dup2
/*      */     //   348: iaload
/*      */     //   349: ldc 537919488
/*      */     //   351: ior
/*      */     //   352: iastore
/*      */     //   353: aload #4
/*      */     //   355: iload #6
/*      */     //   357: iconst_1
/*      */     //   358: iadd
/*      */     //   359: dup2
/*      */     //   360: iaload
/*      */     //   361: ldc 537403520
/*      */     //   363: ior
/*      */     //   364: iastore
/*      */     //   365: aload #4
/*      */     //   367: iload #6
/*      */     //   369: iconst_1
/*      */     //   370: isub
/*      */     //   371: dup2
/*      */     //   372: iaload
/*      */     //   373: ldc 537141312
/*      */     //   375: ior
/*      */     //   376: iastore
/*      */     //   377: goto -> 388
/*      */     //   380: iload #15
/*      */     //   382: sipush #16384
/*      */     //   385: ior
/*      */     //   386: istore #15
/*      */     //   388: iload #22
/*      */     //   390: iconst_2
/*      */     //   391: if_icmpge -> 404
/*      */     //   394: aload #4
/*      */     //   396: iload #6
/*      */     //   398: iload #15
/*      */     //   400: iastore
/*      */     //   401: goto -> 1009
/*      */     //   404: iload #15
/*      */     //   406: ldc -1610612736
/*      */     //   408: iand
/*      */     //   409: ldc 536870912
/*      */     //   411: if_icmpne -> 583
/*      */     //   414: iload #8
/*      */     //   416: iload #10
/*      */     //   418: iadd
/*      */     //   419: istore #8
/*      */     //   421: aload_2
/*      */     //   422: invokevirtual readBit : ()I
/*      */     //   425: ifeq -> 576
/*      */     //   428: aload_2
/*      */     //   429: invokevirtual readBit : ()I
/*      */     //   432: istore #17
/*      */     //   434: aload #18
/*      */     //   436: iload #8
/*      */     //   438: iload #17
/*      */     //   440: bipush #31
/*      */     //   442: ishl
/*      */     //   443: iload #16
/*      */     //   445: ior
/*      */     //   446: iastore
/*      */     //   447: aload #4
/*      */     //   449: iload #6
/*      */     //   451: iload #26
/*      */     //   453: iadd
/*      */     //   454: dup2
/*      */     //   455: iaload
/*      */     //   456: sipush #8196
/*      */     //   459: ior
/*      */     //   460: iastore
/*      */     //   461: aload #4
/*      */     //   463: iload #6
/*      */     //   465: iload #25
/*      */     //   467: iadd
/*      */     //   468: dup2
/*      */     //   469: iaload
/*      */     //   470: sipush #8200
/*      */     //   473: ior
/*      */     //   474: iastore
/*      */     //   475: iload #17
/*      */     //   477: ifeq -> 528
/*      */     //   480: iload #15
/*      */     //   482: ldc -1073733104
/*      */     //   484: ior
/*      */     //   485: istore #15
/*      */     //   487: aload #4
/*      */     //   489: iload #6
/*      */     //   491: iload #11
/*      */     //   493: iadd
/*      */     //   494: dup2
/*      */     //   495: iaload
/*      */     //   496: sipush #9248
/*      */     //   499: ior
/*      */     //   500: iastore
/*      */     //   501: aload #4
/*      */     //   503: iload #6
/*      */     //   505: iconst_1
/*      */     //   506: iadd
/*      */     //   507: dup2
/*      */     //   508: iaload
/*      */     //   509: ldc 813703170
/*      */     //   511: ior
/*      */     //   512: iastore
/*      */     //   513: aload #4
/*      */     //   515: iload #6
/*      */     //   517: iconst_1
/*      */     //   518: isub
/*      */     //   519: dup2
/*      */     //   520: iaload
/*      */     //   521: ldc 675291137
/*      */     //   523: ior
/*      */     //   524: iastore
/*      */     //   525: goto -> 583
/*      */     //   528: iload #15
/*      */     //   530: ldc -1073733616
/*      */     //   532: ior
/*      */     //   533: istore #15
/*      */     //   535: aload #4
/*      */     //   537: iload #6
/*      */     //   539: iload #11
/*      */     //   541: iadd
/*      */     //   542: dup2
/*      */     //   543: iaload
/*      */     //   544: sipush #8224
/*      */     //   547: ior
/*      */     //   548: iastore
/*      */     //   549: aload #4
/*      */     //   551: iload #6
/*      */     //   553: iconst_1
/*      */     //   554: iadd
/*      */     //   555: dup2
/*      */     //   556: iaload
/*      */     //   557: ldc 545267714
/*      */     //   559: ior
/*      */     //   560: iastore
/*      */     //   561: aload #4
/*      */     //   563: iload #6
/*      */     //   565: iconst_1
/*      */     //   566: isub
/*      */     //   567: dup2
/*      */     //   568: iaload
/*      */     //   569: ldc 541073409
/*      */     //   571: ior
/*      */     //   572: iastore
/*      */     //   573: goto -> 583
/*      */     //   576: iload #15
/*      */     //   578: ldc 1073741824
/*      */     //   580: ior
/*      */     //   581: istore #15
/*      */     //   583: aload #4
/*      */     //   585: iload #6
/*      */     //   587: iload #15
/*      */     //   589: iastore
/*      */     //   590: iload #22
/*      */     //   592: iconst_3
/*      */     //   593: if_icmpge -> 599
/*      */     //   596: goto -> 1009
/*      */     //   599: iload #6
/*      */     //   601: iload #11
/*      */     //   603: iadd
/*      */     //   604: istore #6
/*      */     //   606: aload #4
/*      */     //   608: iload #6
/*      */     //   610: iaload
/*      */     //   611: istore #15
/*      */     //   613: iload #15
/*      */     //   615: iconst_m1
/*      */     //   616: ixor
/*      */     //   617: iload #15
/*      */     //   619: iconst_2
/*      */     //   620: ishl
/*      */     //   621: iand
/*      */     //   622: ldc -2147450880
/*      */     //   624: iand
/*      */     //   625: ifeq -> 1009
/*      */     //   628: iload #9
/*      */     //   630: iload #10
/*      */     //   632: iconst_1
/*      */     //   633: ishl
/*      */     //   634: iadd
/*      */     //   635: istore #8
/*      */     //   637: iload #15
/*      */     //   639: ldc 40960
/*      */     //   641: iand
/*      */     //   642: sipush #8192
/*      */     //   645: if_icmpne -> 807
/*      */     //   648: aload_2
/*      */     //   649: invokevirtual readBit : ()I
/*      */     //   652: ifeq -> 799
/*      */     //   655: aload_2
/*      */     //   656: invokevirtual readBit : ()I
/*      */     //   659: istore #17
/*      */     //   661: aload #18
/*      */     //   663: iload #8
/*      */     //   665: iload #17
/*      */     //   667: bipush #31
/*      */     //   669: ishl
/*      */     //   670: iload #16
/*      */     //   672: ior
/*      */     //   673: iastore
/*      */     //   674: aload #4
/*      */     //   676: iload #6
/*      */     //   678: iload #23
/*      */     //   680: iadd
/*      */     //   681: dup2
/*      */     //   682: iaload
/*      */     //   683: ldc 536936448
/*      */     //   685: ior
/*      */     //   686: iastore
/*      */     //   687: aload #4
/*      */     //   689: iload #6
/*      */     //   691: iload #24
/*      */     //   693: iadd
/*      */     //   694: dup2
/*      */     //   695: iaload
/*      */     //   696: ldc 537001984
/*      */     //   698: ior
/*      */     //   699: iastore
/*      */     //   700: iload #17
/*      */     //   702: ifeq -> 752
/*      */     //   705: iload #15
/*      */     //   707: ldc 606126080
/*      */     //   709: ior
/*      */     //   710: istore #15
/*      */     //   712: aload #4
/*      */     //   714: iload #6
/*      */     //   716: iload #11
/*      */     //   718: isub
/*      */     //   719: dup2
/*      */     //   720: iaload
/*      */     //   721: ldc 571473920
/*      */     //   723: ior
/*      */     //   724: iastore
/*      */     //   725: aload #4
/*      */     //   727: iload #6
/*      */     //   729: iconst_1
/*      */     //   730: iadd
/*      */     //   731: dup2
/*      */     //   732: iaload
/*      */     //   733: ldc 537407616
/*      */     //   735: ior
/*      */     //   736: iastore
/*      */     //   737: aload #4
/*      */     //   739: iload #6
/*      */     //   741: iconst_1
/*      */     //   742: isub
/*      */     //   743: dup2
/*      */     //   744: iaload
/*      */     //   745: ldc 537143360
/*      */     //   747: ior
/*      */     //   748: iastore
/*      */     //   749: goto -> 807
/*      */     //   752: iload #15
/*      */     //   754: ldc 539017216
/*      */     //   756: ior
/*      */     //   757: istore #15
/*      */     //   759: aload #4
/*      */     //   761: iload #6
/*      */     //   763: iload #11
/*      */     //   765: isub
/*      */     //   766: dup2
/*      */     //   767: iaload
/*      */     //   768: ldc 537919488
/*      */     //   770: ior
/*      */     //   771: iastore
/*      */     //   772: aload #4
/*      */     //   774: iload #6
/*      */     //   776: iconst_1
/*      */     //   777: iadd
/*      */     //   778: dup2
/*      */     //   779: iaload
/*      */     //   780: ldc 537403520
/*      */     //   782: ior
/*      */     //   783: iastore
/*      */     //   784: aload #4
/*      */     //   786: iload #6
/*      */     //   788: iconst_1
/*      */     //   789: isub
/*      */     //   790: dup2
/*      */     //   791: iaload
/*      */     //   792: ldc 537141312
/*      */     //   794: ior
/*      */     //   795: iastore
/*      */     //   796: goto -> 807
/*      */     //   799: iload #15
/*      */     //   801: sipush #16384
/*      */     //   804: ior
/*      */     //   805: istore #15
/*      */     //   807: iload #22
/*      */     //   809: iconst_4
/*      */     //   810: if_icmpge -> 823
/*      */     //   813: aload #4
/*      */     //   815: iload #6
/*      */     //   817: iload #15
/*      */     //   819: iastore
/*      */     //   820: goto -> 1009
/*      */     //   823: iload #15
/*      */     //   825: ldc -1610612736
/*      */     //   827: iand
/*      */     //   828: ldc 536870912
/*      */     //   830: if_icmpne -> 1002
/*      */     //   833: iload #8
/*      */     //   835: iload #10
/*      */     //   837: iadd
/*      */     //   838: istore #8
/*      */     //   840: aload_2
/*      */     //   841: invokevirtual readBit : ()I
/*      */     //   844: ifeq -> 995
/*      */     //   847: aload_2
/*      */     //   848: invokevirtual readBit : ()I
/*      */     //   851: istore #17
/*      */     //   853: aload #18
/*      */     //   855: iload #8
/*      */     //   857: iload #17
/*      */     //   859: bipush #31
/*      */     //   861: ishl
/*      */     //   862: iload #16
/*      */     //   864: ior
/*      */     //   865: iastore
/*      */     //   866: aload #4
/*      */     //   868: iload #6
/*      */     //   870: iload #26
/*      */     //   872: iadd
/*      */     //   873: dup2
/*      */     //   874: iaload
/*      */     //   875: sipush #8196
/*      */     //   878: ior
/*      */     //   879: iastore
/*      */     //   880: aload #4
/*      */     //   882: iload #6
/*      */     //   884: iload #25
/*      */     //   886: iadd
/*      */     //   887: dup2
/*      */     //   888: iaload
/*      */     //   889: sipush #8200
/*      */     //   892: ior
/*      */     //   893: iastore
/*      */     //   894: iload #17
/*      */     //   896: ifeq -> 947
/*      */     //   899: iload #15
/*      */     //   901: ldc -1073733104
/*      */     //   903: ior
/*      */     //   904: istore #15
/*      */     //   906: aload #4
/*      */     //   908: iload #6
/*      */     //   910: iload #11
/*      */     //   912: iadd
/*      */     //   913: dup2
/*      */     //   914: iaload
/*      */     //   915: sipush #9248
/*      */     //   918: ior
/*      */     //   919: iastore
/*      */     //   920: aload #4
/*      */     //   922: iload #6
/*      */     //   924: iconst_1
/*      */     //   925: iadd
/*      */     //   926: dup2
/*      */     //   927: iaload
/*      */     //   928: ldc 813703170
/*      */     //   930: ior
/*      */     //   931: iastore
/*      */     //   932: aload #4
/*      */     //   934: iload #6
/*      */     //   936: iconst_1
/*      */     //   937: isub
/*      */     //   938: dup2
/*      */     //   939: iaload
/*      */     //   940: ldc 675291137
/*      */     //   942: ior
/*      */     //   943: iastore
/*      */     //   944: goto -> 1002
/*      */     //   947: iload #15
/*      */     //   949: ldc -1073733616
/*      */     //   951: ior
/*      */     //   952: istore #15
/*      */     //   954: aload #4
/*      */     //   956: iload #6
/*      */     //   958: iload #11
/*      */     //   960: iadd
/*      */     //   961: dup2
/*      */     //   962: iaload
/*      */     //   963: sipush #8224
/*      */     //   966: ior
/*      */     //   967: iastore
/*      */     //   968: aload #4
/*      */     //   970: iload #6
/*      */     //   972: iconst_1
/*      */     //   973: iadd
/*      */     //   974: dup2
/*      */     //   975: iaload
/*      */     //   976: ldc 545267714
/*      */     //   978: ior
/*      */     //   979: iastore
/*      */     //   980: aload #4
/*      */     //   982: iload #6
/*      */     //   984: iconst_1
/*      */     //   985: isub
/*      */     //   986: dup2
/*      */     //   987: iaload
/*      */     //   988: ldc 541073409
/*      */     //   990: ior
/*      */     //   991: iastore
/*      */     //   992: goto -> 1002
/*      */     //   995: iload #15
/*      */     //   997: ldc 1073741824
/*      */     //   999: ior
/*      */     //   1000: istore #15
/*      */     //   1002: aload #4
/*      */     //   1004: iload #6
/*      */     //   1006: iload #15
/*      */     //   1008: iastore
/*      */     //   1009: iinc #9, 1
/*      */     //   1012: iinc #7, 1
/*      */     //   1015: goto -> 166
/*      */     //   1018: iinc #19, -1
/*      */     //   1021: iload #9
/*      */     //   1023: iload #13
/*      */     //   1025: iadd
/*      */     //   1026: istore #9
/*      */     //   1028: iload #7
/*      */     //   1030: iload #12
/*      */     //   1032: iadd
/*      */     //   1033: istore #7
/*      */     //   1035: goto -> 130
/*      */     //   1038: iconst_0
/*      */     //   1039: istore #27
/*      */     //   1041: iload #5
/*      */     //   1043: ifeq -> 1052
/*      */     //   1046: aload_2
/*      */     //   1047: invokevirtual checkBytePadding : ()Z
/*      */     //   1050: istore #27
/*      */     //   1052: iload #27
/*      */     //   1054: ireturn
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #1391	-> 0
/*      */     //   #1392	-> 6
/*      */     //   #1393	-> 14
/*      */     //   #1394	-> 27
/*      */     //   #1395	-> 38
/*      */     //   #1396	-> 45
/*      */     //   #1397	-> 57
/*      */     //   #1398	-> 69
/*      */     //   #1401	-> 86
/*      */     //   #1402	-> 93
/*      */     //   #1403	-> 100
/*      */     //   #1404	-> 106
/*      */     //   #1407	-> 112
/*      */     //   #1408	-> 118
/*      */     //   #1409	-> 124
/*      */     //   #1410	-> 135
/*      */     //   #1412	-> 157
/*      */     //   #1414	-> 166
/*      */     //   #1416	-> 173
/*      */     //   #1417	-> 177
/*      */     //   #1421	-> 184
/*      */     //   #1422	-> 199
/*      */     //   #1424	-> 203
/*      */     //   #1427	-> 214
/*      */     //   #1430	-> 221
/*      */     //   #1432	-> 227
/*      */     //   #1437	-> 240
/*      */     //   #1440	-> 245
/*      */     //   #1442	-> 258
/*      */     //   #1446	-> 271
/*      */     //   #1447	-> 276
/*      */     //   #1450	-> 283
/*      */     //   #1453	-> 288
/*      */     //   #1456	-> 301
/*      */     //   #1460	-> 313
/*      */     //   #1466	-> 328
/*      */     //   #1468	-> 335
/*      */     //   #1471	-> 340
/*      */     //   #1474	-> 353
/*      */     //   #1477	-> 365
/*      */     //   #1483	-> 380
/*      */     //   #1486	-> 388
/*      */     //   #1487	-> 394
/*      */     //   #1488	-> 401
/*      */     //   #1490	-> 404
/*      */     //   #1492	-> 414
/*      */     //   #1494	-> 421
/*      */     //   #1497	-> 428
/*      */     //   #1499	-> 434
/*      */     //   #1504	-> 447
/*      */     //   #1505	-> 461
/*      */     //   #1507	-> 475
/*      */     //   #1508	-> 480
/*      */     //   #1511	-> 487
/*      */     //   #1513	-> 501
/*      */     //   #1517	-> 513
/*      */     //   #1523	-> 528
/*      */     //   #1525	-> 535
/*      */     //   #1527	-> 549
/*      */     //   #1530	-> 561
/*      */     //   #1536	-> 576
/*      */     //   #1539	-> 583
/*      */     //   #1542	-> 590
/*      */     //   #1543	-> 599
/*      */     //   #1544	-> 606
/*      */     //   #1548	-> 613
/*      */     //   #1549	-> 628
/*      */     //   #1551	-> 637
/*      */     //   #1554	-> 648
/*      */     //   #1557	-> 655
/*      */     //   #1559	-> 661
/*      */     //   #1564	-> 674
/*      */     //   #1566	-> 687
/*      */     //   #1569	-> 700
/*      */     //   #1570	-> 705
/*      */     //   #1573	-> 712
/*      */     //   #1575	-> 725
/*      */     //   #1579	-> 737
/*      */     //   #1585	-> 752
/*      */     //   #1587	-> 759
/*      */     //   #1589	-> 772
/*      */     //   #1592	-> 784
/*      */     //   #1598	-> 799
/*      */     //   #1601	-> 807
/*      */     //   #1602	-> 813
/*      */     //   #1603	-> 820
/*      */     //   #1606	-> 823
/*      */     //   #1608	-> 833
/*      */     //   #1610	-> 840
/*      */     //   #1613	-> 847
/*      */     //   #1615	-> 853
/*      */     //   #1620	-> 866
/*      */     //   #1621	-> 880
/*      */     //   #1623	-> 894
/*      */     //   #1624	-> 899
/*      */     //   #1627	-> 906
/*      */     //   #1629	-> 920
/*      */     //   #1633	-> 932
/*      */     //   #1639	-> 947
/*      */     //   #1641	-> 954
/*      */     //   #1643	-> 968
/*      */     //   #1646	-> 980
/*      */     //   #1652	-> 995
/*      */     //   #1655	-> 1002
/*      */     //   #1414	-> 1009
/*      */     //   #1409	-> 1018
/*      */     //   #1660	-> 1038
/*      */     //   #1663	-> 1041
/*      */     //   #1664	-> 1046
/*      */     //   #1668	-> 1052
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   227	153	17	sym	I
/*      */     //   434	142	17	sym	I
/*      */     //   203	387	8	k	I
/*      */     //   661	138	17	sym	I
/*      */     //   853	142	17	sym	I
/*      */     //   637	372	8	k	I
/*      */     //   177	841	6	j	I
/*      */     //   184	834	15	csj	I
/*      */     //   166	872	14	stopsk	I
/*      */     //   157	881	22	sheight	I
/*      */     //   0	1055	0	this	Ljj2000/j2k/entropy/decoder/StdEntropyDecoder;
/*      */     //   0	1055	1	cblk	Ljj2000/j2k/image/DataBlk;
/*      */     //   0	1055	2	bin	Ljj2000/j2k/entropy/decoder/ByteToBitInput;
/*      */     //   0	1055	3	bp	I
/*      */     //   0	1055	4	state	[I
/*      */     //   0	1055	5	isterm	Z
/*      */     //   124	931	7	sj	I
/*      */     //   118	937	9	sk	I
/*      */     //   6	1049	10	dscanw	I
/*      */     //   14	1041	11	sscanw	I
/*      */     //   27	1028	12	jstep	I
/*      */     //   38	1017	13	kstep	I
/*      */     //   45	1010	16	setmask	I
/*      */     //   57	998	18	data	[I
/*      */     //   130	925	19	s	I
/*      */     //   86	969	20	causal	Z
/*      */     //   69	986	21	nstripes	I
/*      */     //   93	962	23	off_ul	I
/*      */     //   100	955	24	off_ur	I
/*      */     //   106	949	25	off_dr	I
/*      */     //   112	943	26	off_dl	I
/*      */     //   1041	14	27	error	Z
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean magRefPass(DataBlk cblk, MQDecoder mq, int bp, int[] state, boolean isterm) {
/*      */     // Byte code:
/*      */     //   0: aload_1
/*      */     //   1: getfield scanw : I
/*      */     //   4: istore #10
/*      */     //   6: aload_1
/*      */     //   7: getfield w : I
/*      */     //   10: iconst_2
/*      */     //   11: iadd
/*      */     //   12: istore #11
/*      */     //   14: iload #11
/*      */     //   16: iconst_4
/*      */     //   17: imul
/*      */     //   18: iconst_2
/*      */     //   19: idiv
/*      */     //   20: aload_1
/*      */     //   21: getfield w : I
/*      */     //   24: isub
/*      */     //   25: istore #12
/*      */     //   27: iload #10
/*      */     //   29: iconst_4
/*      */     //   30: imul
/*      */     //   31: aload_1
/*      */     //   32: getfield w : I
/*      */     //   35: isub
/*      */     //   36: istore #13
/*      */     //   38: iconst_1
/*      */     //   39: iload_3
/*      */     //   40: ishl
/*      */     //   41: iconst_1
/*      */     //   42: ishr
/*      */     //   43: istore #16
/*      */     //   45: iconst_m1
/*      */     //   46: iload_3
/*      */     //   47: iconst_1
/*      */     //   48: iadd
/*      */     //   49: ishl
/*      */     //   50: istore #17
/*      */     //   52: aload_1
/*      */     //   53: invokevirtual getData : ()Ljava/lang/Object;
/*      */     //   56: checkcast [I
/*      */     //   59: checkcast [I
/*      */     //   62: astore #19
/*      */     //   64: aload_1
/*      */     //   65: getfield h : I
/*      */     //   68: iconst_4
/*      */     //   69: iadd
/*      */     //   70: iconst_1
/*      */     //   71: isub
/*      */     //   72: iconst_4
/*      */     //   73: idiv
/*      */     //   74: istore #21
/*      */     //   76: aload_1
/*      */     //   77: getfield offset : I
/*      */     //   80: istore #9
/*      */     //   82: iload #11
/*      */     //   84: iconst_1
/*      */     //   85: iadd
/*      */     //   86: istore #7
/*      */     //   88: iload #21
/*      */     //   90: iconst_1
/*      */     //   91: isub
/*      */     //   92: istore #20
/*      */     //   94: iload #20
/*      */     //   96: iflt -> 546
/*      */     //   99: iload #20
/*      */     //   101: ifeq -> 108
/*      */     //   104: iconst_4
/*      */     //   105: goto -> 119
/*      */     //   108: aload_1
/*      */     //   109: getfield h : I
/*      */     //   112: iload #21
/*      */     //   114: iconst_1
/*      */     //   115: isub
/*      */     //   116: iconst_4
/*      */     //   117: imul
/*      */     //   118: isub
/*      */     //   119: istore #22
/*      */     //   121: iload #9
/*      */     //   123: aload_1
/*      */     //   124: getfield w : I
/*      */     //   127: iadd
/*      */     //   128: istore #14
/*      */     //   130: iload #9
/*      */     //   132: iload #14
/*      */     //   134: if_icmpge -> 526
/*      */     //   137: iload #7
/*      */     //   139: istore #6
/*      */     //   141: aload #4
/*      */     //   143: iload #6
/*      */     //   145: iaload
/*      */     //   146: istore #15
/*      */     //   148: iload #15
/*      */     //   150: iconst_1
/*      */     //   151: iushr
/*      */     //   152: iload #15
/*      */     //   154: iconst_m1
/*      */     //   155: ixor
/*      */     //   156: iand
/*      */     //   157: ldc 1073758208
/*      */     //   159: iand
/*      */     //   160: ifeq -> 317
/*      */     //   163: iload #9
/*      */     //   165: istore #8
/*      */     //   167: iload #15
/*      */     //   169: ldc 49152
/*      */     //   171: iand
/*      */     //   172: ldc 32768
/*      */     //   174: if_icmpne -> 226
/*      */     //   177: aload_2
/*      */     //   178: getstatic jj2000/j2k/entropy/decoder/StdEntropyDecoder.MR_LUT : [I
/*      */     //   181: iload #15
/*      */     //   183: sipush #511
/*      */     //   186: iand
/*      */     //   187: iaload
/*      */     //   188: invokevirtual decodeSymbol : (I)I
/*      */     //   191: istore #18
/*      */     //   193: aload #19
/*      */     //   195: iload #8
/*      */     //   197: dup2
/*      */     //   198: iaload
/*      */     //   199: iload #17
/*      */     //   201: iand
/*      */     //   202: iastore
/*      */     //   203: aload #19
/*      */     //   205: iload #8
/*      */     //   207: dup2
/*      */     //   208: iaload
/*      */     //   209: iload #18
/*      */     //   211: iload_3
/*      */     //   212: ishl
/*      */     //   213: iload #16
/*      */     //   215: ior
/*      */     //   216: ior
/*      */     //   217: iastore
/*      */     //   218: iload #15
/*      */     //   220: sipush #256
/*      */     //   223: ior
/*      */     //   224: istore #15
/*      */     //   226: iload #22
/*      */     //   228: iconst_2
/*      */     //   229: if_icmpge -> 242
/*      */     //   232: aload #4
/*      */     //   234: iload #6
/*      */     //   236: iload #15
/*      */     //   238: iastore
/*      */     //   239: goto -> 517
/*      */     //   242: iload #15
/*      */     //   244: ldc -1073741824
/*      */     //   246: iand
/*      */     //   247: ldc -2147483648
/*      */     //   249: if_icmpne -> 310
/*      */     //   252: iload #8
/*      */     //   254: iload #10
/*      */     //   256: iadd
/*      */     //   257: istore #8
/*      */     //   259: aload_2
/*      */     //   260: getstatic jj2000/j2k/entropy/decoder/StdEntropyDecoder.MR_LUT : [I
/*      */     //   263: iload #15
/*      */     //   265: bipush #16
/*      */     //   267: iushr
/*      */     //   268: sipush #511
/*      */     //   271: iand
/*      */     //   272: iaload
/*      */     //   273: invokevirtual decodeSymbol : (I)I
/*      */     //   276: istore #18
/*      */     //   278: aload #19
/*      */     //   280: iload #8
/*      */     //   282: dup2
/*      */     //   283: iaload
/*      */     //   284: iload #17
/*      */     //   286: iand
/*      */     //   287: iastore
/*      */     //   288: aload #19
/*      */     //   290: iload #8
/*      */     //   292: dup2
/*      */     //   293: iaload
/*      */     //   294: iload #18
/*      */     //   296: iload_3
/*      */     //   297: ishl
/*      */     //   298: iload #16
/*      */     //   300: ior
/*      */     //   301: ior
/*      */     //   302: iastore
/*      */     //   303: iload #15
/*      */     //   305: ldc 16777216
/*      */     //   307: ior
/*      */     //   308: istore #15
/*      */     //   310: aload #4
/*      */     //   312: iload #6
/*      */     //   314: iload #15
/*      */     //   316: iastore
/*      */     //   317: iload #22
/*      */     //   319: iconst_3
/*      */     //   320: if_icmpge -> 326
/*      */     //   323: goto -> 517
/*      */     //   326: iload #6
/*      */     //   328: iload #11
/*      */     //   330: iadd
/*      */     //   331: istore #6
/*      */     //   333: aload #4
/*      */     //   335: iload #6
/*      */     //   337: iaload
/*      */     //   338: istore #15
/*      */     //   340: iload #15
/*      */     //   342: iconst_1
/*      */     //   343: iushr
/*      */     //   344: iload #15
/*      */     //   346: iconst_m1
/*      */     //   347: ixor
/*      */     //   348: iand
/*      */     //   349: ldc 1073758208
/*      */     //   351: iand
/*      */     //   352: ifeq -> 517
/*      */     //   355: iload #9
/*      */     //   357: iload #10
/*      */     //   359: iconst_1
/*      */     //   360: ishl
/*      */     //   361: iadd
/*      */     //   362: istore #8
/*      */     //   364: iload #15
/*      */     //   366: ldc 49152
/*      */     //   368: iand
/*      */     //   369: ldc 32768
/*      */     //   371: if_icmpne -> 423
/*      */     //   374: aload_2
/*      */     //   375: getstatic jj2000/j2k/entropy/decoder/StdEntropyDecoder.MR_LUT : [I
/*      */     //   378: iload #15
/*      */     //   380: sipush #511
/*      */     //   383: iand
/*      */     //   384: iaload
/*      */     //   385: invokevirtual decodeSymbol : (I)I
/*      */     //   388: istore #18
/*      */     //   390: aload #19
/*      */     //   392: iload #8
/*      */     //   394: dup2
/*      */     //   395: iaload
/*      */     //   396: iload #17
/*      */     //   398: iand
/*      */     //   399: iastore
/*      */     //   400: aload #19
/*      */     //   402: iload #8
/*      */     //   404: dup2
/*      */     //   405: iaload
/*      */     //   406: iload #18
/*      */     //   408: iload_3
/*      */     //   409: ishl
/*      */     //   410: iload #16
/*      */     //   412: ior
/*      */     //   413: ior
/*      */     //   414: iastore
/*      */     //   415: iload #15
/*      */     //   417: sipush #256
/*      */     //   420: ior
/*      */     //   421: istore #15
/*      */     //   423: iload #22
/*      */     //   425: iconst_4
/*      */     //   426: if_icmpge -> 439
/*      */     //   429: aload #4
/*      */     //   431: iload #6
/*      */     //   433: iload #15
/*      */     //   435: iastore
/*      */     //   436: goto -> 517
/*      */     //   439: aload #4
/*      */     //   441: iload #6
/*      */     //   443: iaload
/*      */     //   444: ldc -1073741824
/*      */     //   446: iand
/*      */     //   447: ldc -2147483648
/*      */     //   449: if_icmpne -> 510
/*      */     //   452: iload #8
/*      */     //   454: iload #10
/*      */     //   456: iadd
/*      */     //   457: istore #8
/*      */     //   459: aload_2
/*      */     //   460: getstatic jj2000/j2k/entropy/decoder/StdEntropyDecoder.MR_LUT : [I
/*      */     //   463: iload #15
/*      */     //   465: bipush #16
/*      */     //   467: iushr
/*      */     //   468: sipush #511
/*      */     //   471: iand
/*      */     //   472: iaload
/*      */     //   473: invokevirtual decodeSymbol : (I)I
/*      */     //   476: istore #18
/*      */     //   478: aload #19
/*      */     //   480: iload #8
/*      */     //   482: dup2
/*      */     //   483: iaload
/*      */     //   484: iload #17
/*      */     //   486: iand
/*      */     //   487: iastore
/*      */     //   488: aload #19
/*      */     //   490: iload #8
/*      */     //   492: dup2
/*      */     //   493: iaload
/*      */     //   494: iload #18
/*      */     //   496: iload_3
/*      */     //   497: ishl
/*      */     //   498: iload #16
/*      */     //   500: ior
/*      */     //   501: ior
/*      */     //   502: iastore
/*      */     //   503: iload #15
/*      */     //   505: ldc 16777216
/*      */     //   507: ior
/*      */     //   508: istore #15
/*      */     //   510: aload #4
/*      */     //   512: iload #6
/*      */     //   514: iload #15
/*      */     //   516: iastore
/*      */     //   517: iinc #9, 1
/*      */     //   520: iinc #7, 1
/*      */     //   523: goto -> 130
/*      */     //   526: iinc #20, -1
/*      */     //   529: iload #9
/*      */     //   531: iload #13
/*      */     //   533: iadd
/*      */     //   534: istore #9
/*      */     //   536: iload #7
/*      */     //   538: iload #12
/*      */     //   540: iadd
/*      */     //   541: istore #7
/*      */     //   543: goto -> 94
/*      */     //   546: iconst_0
/*      */     //   547: istore #23
/*      */     //   549: iload #5
/*      */     //   551: ifeq -> 570
/*      */     //   554: aload_0
/*      */     //   555: getfield options : I
/*      */     //   558: bipush #16
/*      */     //   560: iand
/*      */     //   561: ifeq -> 570
/*      */     //   564: aload_2
/*      */     //   565: invokevirtual checkPredTerm : ()Z
/*      */     //   568: istore #23
/*      */     //   570: aload_0
/*      */     //   571: getfield options : I
/*      */     //   574: iconst_2
/*      */     //   575: iand
/*      */     //   576: ifeq -> 583
/*      */     //   579: aload_2
/*      */     //   580: invokevirtual resetCtxts : ()V
/*      */     //   583: iload #23
/*      */     //   585: ireturn
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #1718	-> 0
/*      */     //   #1719	-> 6
/*      */     //   #1720	-> 14
/*      */     //   #1721	-> 27
/*      */     //   #1722	-> 38
/*      */     //   #1723	-> 45
/*      */     //   #1724	-> 52
/*      */     //   #1725	-> 64
/*      */     //   #1728	-> 76
/*      */     //   #1729	-> 82
/*      */     //   #1730	-> 88
/*      */     //   #1731	-> 99
/*      */     //   #1733	-> 121
/*      */     //   #1735	-> 130
/*      */     //   #1737	-> 137
/*      */     //   #1738	-> 141
/*      */     //   #1741	-> 148
/*      */     //   #1742	-> 163
/*      */     //   #1744	-> 167
/*      */     //   #1747	-> 177
/*      */     //   #1749	-> 193
/*      */     //   #1750	-> 203
/*      */     //   #1752	-> 218
/*      */     //   #1754	-> 226
/*      */     //   #1755	-> 232
/*      */     //   #1756	-> 239
/*      */     //   #1759	-> 242
/*      */     //   #1761	-> 252
/*      */     //   #1763	-> 259
/*      */     //   #1766	-> 278
/*      */     //   #1767	-> 288
/*      */     //   #1769	-> 303
/*      */     //   #1771	-> 310
/*      */     //   #1774	-> 317
/*      */     //   #1775	-> 326
/*      */     //   #1776	-> 333
/*      */     //   #1779	-> 340
/*      */     //   #1780	-> 355
/*      */     //   #1782	-> 364
/*      */     //   #1785	-> 374
/*      */     //   #1787	-> 390
/*      */     //   #1788	-> 400
/*      */     //   #1790	-> 415
/*      */     //   #1792	-> 423
/*      */     //   #1793	-> 429
/*      */     //   #1794	-> 436
/*      */     //   #1797	-> 439
/*      */     //   #1799	-> 452
/*      */     //   #1801	-> 459
/*      */     //   #1804	-> 478
/*      */     //   #1805	-> 488
/*      */     //   #1807	-> 503
/*      */     //   #1809	-> 510
/*      */     //   #1735	-> 517
/*      */     //   #1730	-> 526
/*      */     //   #1814	-> 546
/*      */     //   #1817	-> 549
/*      */     //   #1818	-> 564
/*      */     //   #1822	-> 570
/*      */     //   #1823	-> 579
/*      */     //   #1827	-> 583
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   193	33	18	sym	I
/*      */     //   278	32	18	sym	I
/*      */     //   167	150	8	k	I
/*      */     //   390	33	18	sym	I
/*      */     //   478	32	18	sym	I
/*      */     //   364	153	8	k	I
/*      */     //   141	385	6	j	I
/*      */     //   148	378	15	csj	I
/*      */     //   130	416	14	stopsk	I
/*      */     //   121	425	22	sheight	I
/*      */     //   0	586	0	this	Ljj2000/j2k/entropy/decoder/StdEntropyDecoder;
/*      */     //   0	586	1	cblk	Ljj2000/j2k/image/DataBlk;
/*      */     //   0	586	2	mq	Ljj2000/j2k/entropy/decoder/MQDecoder;
/*      */     //   0	586	3	bp	I
/*      */     //   0	586	4	state	[I
/*      */     //   0	586	5	isterm	Z
/*      */     //   88	498	7	sj	I
/*      */     //   82	504	9	sk	I
/*      */     //   6	580	10	dscanw	I
/*      */     //   14	572	11	sscanw	I
/*      */     //   27	559	12	jstep	I
/*      */     //   38	548	13	kstep	I
/*      */     //   45	541	16	setmask	I
/*      */     //   52	534	17	resetmask	I
/*      */     //   64	522	19	data	[I
/*      */     //   94	492	20	s	I
/*      */     //   76	510	21	nstripes	I
/*      */     //   549	37	23	error	Z
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean rawMagRefPass(DataBlk cblk, ByteToBitInput bin, int bp, int[] state, boolean isterm) {
/* 1880 */     int dscanw = cblk.scanw;
/* 1881 */     int sscanw = cblk.w + 2;
/* 1882 */     int jstep = sscanw * 4 / 2 - cblk.w;
/* 1883 */     int kstep = dscanw * 4 - cblk.w;
/* 1884 */     int setmask = 1 << bp >> 1;
/* 1885 */     int resetmask = -1 << bp + 1;
/* 1886 */     int[] data = (int[])cblk.getData();
/* 1887 */     int nstripes = (cblk.h + 4 - 1) / 4;
/*      */ 
/*      */     
/* 1890 */     int sk = cblk.offset;
/* 1891 */     int sj = sscanw + 1;
/* 1892 */     for (int s = nstripes - 1; s >= 0; s--, sk += kstep, sj += jstep) {
/* 1893 */       int sheight = (s != 0) ? 4 : (cblk.h - (nstripes - 1) * 4);
/*      */       
/* 1895 */       int stopsk = sk + cblk.w;
/*      */       
/* 1897 */       for (; sk < stopsk; sk++, sj++) {
/*      */         
/* 1899 */         int j = sj;
/* 1900 */         int csj = state[j];
/*      */ 
/*      */         
/* 1903 */         if ((csj >>> 1 & (csj ^ 0xFFFFFFFF) & 0x40004000) != 0) {
/* 1904 */           int k = sk;
/*      */           
/* 1906 */           if ((csj & 0xC000) == 32768) {
/*      */ 
/*      */             
/* 1909 */             int sym = bin.readBit();
/*      */             
/* 1911 */             data[k] = data[k] & resetmask;
/* 1912 */             data[k] = data[k] | sym << bp | setmask;
/*      */           } 
/*      */ 
/*      */           
/* 1916 */           if (sheight < 2)
/*      */             continue; 
/* 1918 */           if ((csj & 0xC0000000) == Integer.MIN_VALUE) {
/*      */             
/* 1920 */             k += dscanw;
/*      */             
/* 1922 */             int sym = bin.readBit();
/*      */             
/* 1924 */             data[k] = data[k] & resetmask;
/* 1925 */             data[k] = data[k] | sym << bp | setmask;
/*      */           } 
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 1931 */         if (sheight >= 3) {
/* 1932 */           j += sscanw;
/* 1933 */           csj = state[j];
/*      */ 
/*      */           
/* 1936 */           if ((csj >>> 1 & (csj ^ 0xFFFFFFFF) & 0x40004000) != 0) {
/* 1937 */             int k = sk + (dscanw << 1);
/*      */             
/* 1939 */             if ((csj & 0xC000) == 32768) {
/*      */ 
/*      */               
/* 1942 */               int sym = bin.readBit();
/*      */               
/* 1944 */               data[k] = data[k] & resetmask;
/* 1945 */               data[k] = data[k] | sym << bp | setmask;
/*      */             } 
/*      */ 
/*      */             
/* 1949 */             if (sheight >= 4)
/*      */             {
/* 1951 */               if ((state[j] & 0xC0000000) == Integer.MIN_VALUE) {
/*      */                 
/* 1953 */                 k += dscanw;
/*      */                 
/* 1955 */                 int sym = bin.readBit();
/*      */                 
/* 1957 */                 data[k] = data[k] & resetmask;
/* 1958 */                 data[k] = data[k] | sym << bp | setmask;
/*      */               } 
/*      */             }
/*      */           } 
/*      */         } 
/*      */         continue;
/*      */       } 
/*      */     } 
/* 1966 */     boolean error = false;
/*      */ 
/*      */     
/* 1969 */     if (isterm && (this.options & 0x10) != 0) {
/* 1970 */       error = bin.checkBytePadding();
/*      */     }
/*      */ 
/*      */     
/* 1974 */     return error;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean cleanuppass(DataBlk cblk, MQDecoder mq, int bp, int[] state, int[] zc_lut, boolean isterm) {
/*      */     boolean bool1;
/* 2033 */     int dscanw = cblk.scanw;
/* 2034 */     int sscanw = cblk.w + 2;
/* 2035 */     int jstep = sscanw * 4 / 2 - cblk.w;
/* 2036 */     int kstep = dscanw * 4 - cblk.w;
/* 2037 */     int setmask = 3 << bp >> 1;
/* 2038 */     int[] data = (int[])cblk.getData();
/* 2039 */     int nstripes = (cblk.h + 4 - 1) / 4;
/* 2040 */     boolean causal = ((this.options & 0x8) != 0);
/*      */ 
/*      */     
/* 2043 */     int off_ul = -sscanw - 1;
/* 2044 */     int off_ur = -sscanw + 1;
/* 2045 */     int off_dr = sscanw + 1;
/* 2046 */     int off_dl = sscanw - 1;
/*      */ 
/*      */     
/* 2049 */     int sk = cblk.offset;
/* 2050 */     int sj = sscanw + 1;
/* 2051 */     for (int s = nstripes - 1; s >= 0; s--, sk += kstep, sj += jstep) {
/* 2052 */       int sheight = (s != 0) ? 4 : (cblk.h - (nstripes - 1) * 4);
/*      */       
/* 2054 */       int stopsk = sk + cblk.w;
/*      */       while (true) {
/* 2056 */         sk++; sj++;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       continue;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2455 */     if ((this.options & 0x20) != 0) {
/* 2456 */       int sym = mq.decodeSymbol(0) << 3;
/* 2457 */       sym |= mq.decodeSymbol(0) << 2;
/* 2458 */       sym |= mq.decodeSymbol(0) << 1;
/* 2459 */       sym |= mq.decodeSymbol(0);
/*      */       
/* 2461 */       bool1 = (sym != 10);
/*      */     } else {
/*      */       
/* 2464 */       bool1 = false;
/*      */     } 
/*      */ 
/*      */     
/* 2468 */     if (isterm && (this.options & 0x10) != 0) {
/* 2469 */       bool1 = mq.checkPredTerm();
/*      */     }
/*      */ 
/*      */     
/* 2473 */     if ((this.options & 0x2) != 0) {
/* 2474 */       mq.resetCtxts();
/*      */     }
/*      */ 
/*      */     
/* 2478 */     return bool1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void conceal(DataBlk cblk, int bp) {
/* 2504 */     int setmask = 1 << bp;
/* 2505 */     int resetmask = -1 << bp;
/*      */ 
/*      */     
/* 2508 */     int[] data = (int[])cblk.getData();
/*      */ 
/*      */ 
/*      */     
/* 2512 */     for (int l = cblk.h - 1, k = cblk.offset; l >= 0; l--) {
/* 2513 */       for (int kmax = k + cblk.w; k < kmax; k++) {
/* 2514 */         int dk = data[k];
/* 2515 */         if ((dk & resetmask & Integer.MAX_VALUE) != 0) {
/*      */ 
/*      */           
/* 2518 */           data[k] = dk & resetmask | setmask;
/*      */         }
/*      */         else {
/*      */           
/* 2522 */           data[k] = 0;
/*      */         } 
/*      */       } 
/* 2525 */       k += cblk.scanw - cblk.w;
/*      */     } 
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/entropy/decoder/StdEntropyDecoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */