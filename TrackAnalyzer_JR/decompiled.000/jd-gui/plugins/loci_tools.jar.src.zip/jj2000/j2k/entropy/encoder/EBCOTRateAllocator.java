/*      */ package jj2000.j2k.entropy.encoder;
/*      */ 
/*      */ import com.sun.media.imageioimpl.plugins.jpeg2000.J2KImageWriteParamJava;
/*      */ import java.awt.Point;
/*      */ import java.io.IOException;
/*      */ import jj2000.j2k.codestream.PrecInfo;
/*      */ import jj2000.j2k.codestream.writer.BitOutputBuffer;
/*      */ import jj2000.j2k.codestream.writer.CodestreamWriter;
/*      */ import jj2000.j2k.codestream.writer.PktEncoder;
/*      */ import jj2000.j2k.entropy.Progression;
/*      */ import jj2000.j2k.util.FacilityManager;
/*      */ import jj2000.j2k.util.MathUtil;
/*      */ import jj2000.j2k.util.ProgressWatch;
/*      */ import jj2000.j2k.wavelet.analysis.SubbandAn;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class EBCOTRateAllocator
/*      */   extends PostCompRateAllocator
/*      */ {
/*      */   private static final boolean DO_TIMING = false;
/*      */   private long initTime;
/*      */   private long buildTime;
/*      */   private long writeTime;
/*      */   private CBlkRateDistStats[][][][][] cblks;
/*      */   private int[][][][][][] truncIdxs;
/*      */   private Point[][][] numPrec;
/*      */   private EBCOTLayer[] layers;
/*  180 */   private static final double LOG2 = Math.log(2.0D);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int RD_SUMMARY_OFF = 24;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int RD_SUMMARY_SIZE = 64;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final float FLOAT_REL_PRECISION = 1.0E-4F;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final float FLOAT_ABS_PRECISION = 1.0E-10F;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int MIN_AVG_PACKET_SZ = 32;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int[] RDSlopesRates;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private PktEncoder pktEnc;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private LayersInfo lyrSpec;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private float maxSlope;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private float minSlope;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public EBCOTRateAllocator(CodedCBlkDataSrcEnc src, LayersInfo lyrs, CodestreamWriter writer, J2KImageWriteParamJava wp) {
/*  249 */     super(src, lyrs.getTotNumLayers(), writer, wp);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  254 */     Point ncblks = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  270 */     this.lyrSpec = lyrs;
/*      */ 
/*      */     
/*  273 */     this.RDSlopesRates = new int[64];
/*      */ 
/*      */     
/*  276 */     int nt = src.getNumTiles();
/*  277 */     int nc = getNumComps();
/*      */ 
/*      */     
/*  280 */     this.cblks = new CBlkRateDistStats[nt][nc][][][];
/*  281 */     this.truncIdxs = new int[nt][this.numLayers][nc][][][];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  296 */     Point tileI = null;
/*  297 */     Point nTiles = null;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  302 */     int cb0x = src.getCbULX();
/*  303 */     int cb0y = src.getCbULY();
/*      */     
/*  305 */     src.setTile(0, 0);
/*  306 */     for (int t = 0; t < nt; t++) {
/*  307 */       nTiles = src.getNumTiles(nTiles);
/*  308 */       tileI = src.getTile(tileI);
/*  309 */       int x0siz = getImgULX();
/*  310 */       int y0siz = getImgULY();
/*  311 */       int xsiz = x0siz + getImgWidth();
/*  312 */       int ysiz = y0siz + getImgHeight();
/*  313 */       int xt0siz = src.getTilePartULX();
/*  314 */       int yt0siz = src.getTilePartULY();
/*  315 */       int xtsiz = src.getNomTileWidth();
/*  316 */       int ytsiz = src.getNomTileHeight();
/*      */ 
/*      */       
/*  319 */       int tx0 = (tileI.x == 0) ? x0siz : (xt0siz + tileI.x * xtsiz);
/*  320 */       int ty0 = (tileI.y == 0) ? y0siz : (yt0siz + tileI.y * ytsiz);
/*  321 */       int tx1 = (tileI.x != nTiles.x - 1) ? (xt0siz + (tileI.x + 1) * xtsiz) : xsiz;
/*  322 */       int ty1 = (tileI.y != nTiles.y - 1) ? (yt0siz + (tileI.y + 1) * ytsiz) : ysiz;
/*      */       
/*  324 */       for (int c = 0; c < nc; c++) {
/*      */ 
/*      */         
/*  327 */         SubbandAn sb = src.getAnSubbandTree(t, c);
/*  328 */         int mrl = sb.resLvl + 1;
/*      */ 
/*      */         
/*  331 */         if (this.numPrec == null) this.numPrec = new Point[nt][nc][]; 
/*  332 */         if (this.numPrec[t][c] == null) {
/*  333 */           this.numPrec[t][c] = new Point[mrl];
/*      */         }
/*      */ 
/*      */         
/*  337 */         int xrsiz = src.getCompSubsX(c);
/*  338 */         int yrsiz = src.getCompSubsY(c);
/*      */ 
/*      */         
/*  341 */         int tcx0 = (int)Math.ceil(tx0 / xrsiz);
/*  342 */         int tcy0 = (int)Math.ceil(ty0 / yrsiz);
/*  343 */         int tcx1 = (int)Math.ceil(tx1 / xrsiz);
/*  344 */         int tcy1 = (int)Math.ceil(ty1 / yrsiz);
/*      */         
/*  346 */         this.cblks[t][c] = new CBlkRateDistStats[mrl][][];
/*      */         int l;
/*  348 */         for (l = 0; l < this.numLayers; l++) {
/*  349 */           this.truncIdxs[t][l][c] = new int[mrl][][];
/*      */         }
/*      */         
/*  352 */         for (int r = 0; r < mrl; r++) {
/*      */ 
/*      */ 
/*      */           
/*  356 */           int trx0 = (int)Math.ceil(tcx0 / (1 << mrl - 1 - r));
/*  357 */           int try0 = (int)Math.ceil(tcy0 / (1 << mrl - 1 - r));
/*  358 */           int trx1 = (int)Math.ceil(tcx1 / (1 << mrl - 1 - r));
/*  359 */           int try1 = (int)Math.ceil(tcy1 / (1 << mrl - 1 - r));
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  364 */           double twoppx = wp.getPrecinctPartition().getPPX(t, c, r);
/*  365 */           double twoppy = wp.getPrecinctPartition().getPPY(t, c, r);
/*  366 */           this.numPrec[t][c][r] = new Point();
/*  367 */           if (trx1 > trx0) {
/*  368 */             (this.numPrec[t][c][r]).x = (int)Math.ceil((trx1 - cb0x) / twoppx) - (int)Math.floor((trx0 - cb0x) / twoppx);
/*      */           } else {
/*      */             
/*  371 */             (this.numPrec[t][c][r]).x = 0;
/*      */           } 
/*  373 */           if (try1 > try0) {
/*  374 */             (this.numPrec[t][c][r]).y = (int)Math.ceil((try1 - cb0y) / twoppy) - (int)Math.floor((try0 - cb0y) / twoppy);
/*      */           } else {
/*      */             
/*  377 */             (this.numPrec[t][c][r]).y = 0;
/*      */           } 
/*      */           
/*  380 */           int minsbi = (r == 0) ? 0 : 1;
/*  381 */           int maxsbi = (r == 0) ? 1 : 4;
/*      */           
/*  383 */           this.cblks[t][c][r] = new CBlkRateDistStats[maxsbi][];
/*  384 */           for (l = 0; l < this.numLayers; l++) {
/*  385 */             this.truncIdxs[t][l][c][r] = new int[maxsbi][];
/*      */           }
/*      */           
/*  388 */           for (int s = minsbi; s < maxsbi; s++) {
/*      */             
/*  390 */             SubbandAn sb2 = (SubbandAn)sb.getSubbandByIdx(r, s);
/*  391 */             ncblks = sb2.numCb;
/*  392 */             int cblkPerSubband = ncblks.x * ncblks.y;
/*  393 */             this.cblks[t][c][r][s] = new CBlkRateDistStats[cblkPerSubband];
/*      */ 
/*      */             
/*  396 */             for (l = 0; l < this.numLayers; l++) {
/*  397 */               this.truncIdxs[t][l][c][r][s] = new int[cblkPerSubband];
/*  398 */               for (int i = 0; i < cblkPerSubband; i++) {
/*  399 */                 this.truncIdxs[t][l][c][r][s][i] = -1;
/*      */               }
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*  405 */       if (t != nt - 1) {
/*  406 */         src.nextTile();
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  411 */     this.pktEnc = new PktEncoder(src, wp, this.numPrec);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void finalize() throws Throwable {
/*  438 */     super.finalize();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void runAndWrite() throws IOException {
/*  447 */     buildAndWriteLayers();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void initialize() throws IOException {
/*  467 */     int numTiles = this.src.getNumTiles();
/*  468 */     int numComps = this.src.getNumComps();
/*      */ 
/*      */ 
/*      */     
/*  472 */     long stime = 0L;
/*      */ 
/*      */ 
/*      */     
/*  476 */     getAllCodeBlocks();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  481 */     int totenclength = this.RDSlopesRates[0];
/*      */     
/*      */     int t;
/*      */     
/*  485 */     for (t = 0; t < numTiles; t++) {
/*  486 */       int avgPktLen = 2;
/*      */       
/*  488 */       if (((String)this.wp.getSOP().getTileDef(t)).equalsIgnoreCase("true")) {
/*  489 */         avgPktLen += 6;
/*      */       }
/*      */       
/*  492 */       if (((String)this.wp.getEPH().getTileDef(t)).equalsIgnoreCase("true")) {
/*  493 */         avgPktLen += 2;
/*      */       }
/*      */       
/*  496 */       for (int c = 0; c < numComps; c++) {
/*  497 */         int numLvls = (this.src.getAnSubbandTree(t, c)).resLvl + 1;
/*  498 */         if (!this.src.precinctPartitionUsed(c, t)) {
/*      */ 
/*      */           
/*  501 */           totenclength += this.numLayers * avgPktLen * numLvls;
/*      */         
/*      */         }
/*      */         else {
/*      */ 
/*      */           
/*  507 */           for (int rl = 0; rl < numLvls; rl++) {
/*  508 */             int maxpkt = (this.numPrec[t][c][rl]).x * (this.numPrec[t][c][rl]).y;
/*  509 */             totenclength += this.numLayers * avgPktLen * maxpkt;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  523 */     int ho = this.headEnc.getLength();
/*  524 */     float np = (this.src.getImgWidth() * this.src.getImgHeight()) / 8.0F;
/*      */ 
/*      */     
/*  527 */     for (t = 0; t < numTiles; t++) {
/*  528 */       this.headEnc.reset();
/*  529 */       this.headEnc.encodeTilePartHeader(0, t);
/*  530 */       ho += this.headEnc.getLength();
/*      */     } 
/*      */     
/*  533 */     this.layers = new EBCOTLayer[this.numLayers]; int n;
/*  534 */     for (n = this.numLayers - 1; n >= 0; n--) {
/*  535 */       this.layers[n] = new EBCOTLayer();
/*      */     }
/*      */     
/*  538 */     int minlsz = 0;
/*  539 */     for (t = 0; t < numTiles; t++) {
/*  540 */       for (int c = 0; c < numComps; c++) {
/*  541 */         int numLvls = (this.src.getAnSubbandTree(t, c)).resLvl + 1;
/*      */         
/*  543 */         if (!this.src.precinctPartitionUsed(c, t)) {
/*      */           
/*  545 */           minlsz += 32 * numLvls;
/*      */         }
/*      */         else {
/*      */           
/*  549 */           for (int rl = 0; rl < numLvls; rl++) {
/*  550 */             int maxpkt = (this.numPrec[t][c][rl]).x * (this.numPrec[t][c][rl]).y;
/*  551 */             minlsz += 32 * maxpkt;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  558 */     n = 0;
/*  559 */     int i = 0;
/*  560 */     int lastbytes = 0;
/*      */     
/*  562 */     while (n < this.numLayers - 1) {
/*      */       int k;
/*  564 */       double basebytes = Math.floor((this.lyrSpec.getTargetBitrate(i) * np));
/*  565 */       if (i < this.lyrSpec.getNOptPoints() - 1) {
/*  566 */         k = (int)(this.lyrSpec.getTargetBitrate(i + 1) * np);
/*      */         
/*  568 */         if (k > totenclength) {
/*  569 */           k = totenclength;
/*      */         }
/*      */       } else {
/*  572 */         k = 1;
/*      */       } 
/*  574 */       int loopnlyrs = this.lyrSpec.getExtraLayers(i) + 1;
/*  575 */       double ls = Math.exp(Math.log(k / basebytes) / loopnlyrs);
/*  576 */       (this.layers[n]).optimize = true;
/*  577 */       for (int l = 0; l < loopnlyrs; l++) {
/*  578 */         int m = (int)basebytes - lastbytes - ho;
/*  579 */         if (m < minlsz) {
/*  580 */           basebytes *= ls;
/*  581 */           this.numLayers--;
/*      */         } else {
/*      */           
/*  584 */           lastbytes = (int)basebytes - ho;
/*  585 */           (this.layers[n]).maxBytes = lastbytes;
/*  586 */           basebytes *= ls;
/*  587 */           n++;
/*      */         } 
/*  589 */       }  i++;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  594 */     n = this.numLayers - 2;
/*  595 */     int nextbytes = (int)(this.lyrSpec.getTotBitrate() * np) - ho;
/*  596 */     int newbytes = nextbytes - ((n >= 0) ? (this.layers[n]).maxBytes : 0);
/*  597 */     while (newbytes < minlsz) {
/*  598 */       if (this.numLayers == 1) {
/*  599 */         if (newbytes <= 0) {
/*  600 */           throw new IllegalArgumentException("Overall target bitrate too low, given the current bit stream header overhead");
/*      */         }
/*      */ 
/*      */         
/*      */         break;
/*      */       } 
/*      */ 
/*      */       
/*  608 */       this.numLayers--;
/*  609 */       n--;
/*  610 */       newbytes = nextbytes - ((n >= 0) ? (this.layers[n]).maxBytes : 0);
/*      */     } 
/*      */     
/*  613 */     n++;
/*  614 */     (this.layers[n]).maxBytes = nextbytes;
/*  615 */     (this.layers[n]).optimize = true;
/*      */ 
/*      */ 
/*      */     
/*  619 */     Progression[] prog1 = (Progression[])this.wp.getProgressionType().getDefault();
/*  620 */     int nValidProg = prog1.length;
/*  621 */     for (int prg = 0; prg < prog1.length; prg++) {
/*  622 */       if ((prog1[prg]).lye > this.numLayers) {
/*  623 */         (prog1[prg]).lye = this.numLayers;
/*      */       }
/*      */     } 
/*  626 */     if (nValidProg == 0) {
/*  627 */       throw new Error("Unable to initialize rate allocator: No default progression type has been defined.");
/*      */     }
/*      */ 
/*      */     
/*  631 */     for (int j = 0; j < numTiles; j++) {
/*  632 */       if (this.wp.getProgressionType().isTileSpecified(j)) {
/*  633 */         prog1 = (Progression[])this.wp.getProgressionType().getTileDef(j);
/*  634 */         nValidProg = prog1.length;
/*  635 */         for (int k = 0; k < prog1.length; k++) {
/*  636 */           if ((prog1[k]).lye > this.numLayers) {
/*  637 */             (prog1[k]).lye = this.numLayers;
/*      */           }
/*      */         } 
/*  640 */         if (nValidProg == 0) {
/*  641 */           throw new Error("Unable to initialize rate allocator: No default progression type has been defined.");
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void getAllCodeBlocks() {
/*  664 */     CBlkRateDistStats ccb = null;
/*  665 */     Point ncblks = null;
/*      */ 
/*      */ 
/*      */     
/*  669 */     long stime = 0L;
/*      */     
/*  671 */     this.maxSlope = 0.0F;
/*  672 */     this.minSlope = Float.MAX_VALUE;
/*      */ 
/*      */     
/*  675 */     int numComps = this.src.getNumComps();
/*  676 */     int numTiles = this.src.getNumTiles();
/*      */ 
/*      */     
/*  679 */     int cblkToEncode = 0;
/*  680 */     int nEncCblk = 0;
/*  681 */     ProgressWatch pw = FacilityManager.getProgressWatch();
/*      */ 
/*      */     
/*  684 */     this.src.setTile(0, 0);
/*  685 */     for (int t = 0; t < numTiles; t++) {
/*  686 */       nEncCblk = 0;
/*  687 */       cblkToEncode = 0; int c;
/*  688 */       for (c = 0; c < numComps; c++) {
/*  689 */         SubbandAn root = this.src.getAnSubbandTree(t, c);
/*  690 */         for (int r = 0; r <= root.resLvl; r++) {
/*  691 */           if (r == 0) {
/*  692 */             SubbandAn sb = (SubbandAn)root.getSubbandByIdx(0, 0);
/*  693 */             if (sb != null) cblkToEncode += sb.numCb.x * sb.numCb.y; 
/*      */           } else {
/*  695 */             SubbandAn sb = (SubbandAn)root.getSubbandByIdx(r, 1);
/*  696 */             if (sb != null) cblkToEncode += sb.numCb.x * sb.numCb.y; 
/*  697 */             sb = (SubbandAn)root.getSubbandByIdx(r, 2);
/*  698 */             if (sb != null) cblkToEncode += sb.numCb.x * sb.numCb.y; 
/*  699 */             sb = (SubbandAn)root.getSubbandByIdx(r, 3);
/*  700 */             if (sb != null) cblkToEncode += sb.numCb.x * sb.numCb.y; 
/*      */           } 
/*      */         } 
/*      */       } 
/*  704 */       if (pw != null) {
/*  705 */         pw.initProgressWatch(0, cblkToEncode, "Encoding tile " + t + "...");
/*      */       }
/*      */       
/*  708 */       for (c = 0; c < numComps; c++) {
/*      */ 
/*      */         
/*  711 */         while ((ccb = this.src.getNextCodeBlock(c, ccb)) != null) {
/*      */ 
/*      */           
/*  714 */           if (pw != null) {
/*  715 */             nEncCblk++;
/*  716 */             pw.updateProgressWatch(nEncCblk, null);
/*      */           } 
/*      */           
/*  719 */           SubbandAn subb = ccb.sb;
/*      */ 
/*      */           
/*  722 */           int r = subb.resLvl;
/*      */ 
/*      */           
/*  725 */           int s = subb.sbandIdx;
/*      */ 
/*      */           
/*  728 */           ncblks = subb.numCb;
/*      */ 
/*      */ 
/*      */           
/*  732 */           int last_sidx = -1;
/*  733 */           for (int k = ccb.nVldTrunc - 1; k >= 0; k--) {
/*  734 */             float fslope = ccb.truncSlopes[k];
/*  735 */             if (fslope > this.maxSlope) this.maxSlope = fslope; 
/*  736 */             if (fslope < this.minSlope) this.minSlope = fslope; 
/*  737 */             int sidx = getLimitedSIndexFromSlope(fslope);
/*  738 */             for (; sidx > last_sidx; sidx--) {
/*  739 */               this.RDSlopesRates[sidx] = this.RDSlopesRates[sidx] + ccb.truncRates[ccb.truncIdxs[k]];
/*      */             }
/*      */             
/*  742 */             last_sidx = getLimitedSIndexFromSlope(fslope);
/*      */           } 
/*      */ 
/*      */           
/*  746 */           this.cblks[t][c][r][s][ccb.m * ncblks.x + ccb.n] = ccb;
/*  747 */           ccb = null;
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  753 */       if (pw != null) {
/*  754 */         pw.terminateProgressWatch();
/*      */       }
/*      */ 
/*      */       
/*  758 */       if (t < numTiles - 1) {
/*  759 */         this.src.nextTile();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void buildAndWriteLayers() throws IOException {
/*  770 */     int nPrec = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  775 */     BitOutputBuffer hBuff = null;
/*  776 */     byte[] bBuff = null;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  781 */     int nc = this.src.getNumComps();
/*  782 */     int nt = this.src.getNumTiles();
/*      */ 
/*      */     
/*  785 */     long stime = 0L;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  790 */     float rdThreshold = this.maxSlope;
/*      */     
/*  792 */     int[] tileLengths = new int[nt];
/*  793 */     int actualBytes = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  799 */     for (int l = 0; l < this.numLayers; l++) {
/*      */       
/*  801 */       int maxBytes = (this.layers[l]).maxBytes;
/*  802 */       if ((this.layers[l]).optimize) {
/*  803 */         rdThreshold = optimizeBitstreamLayer(l, rdThreshold, maxBytes, actualBytes);
/*      */       } else {
/*      */         
/*  806 */         if (l <= 0 || l >= this.numLayers - 1) {
/*  807 */           throw new IllegalArgumentException("The first and the last layer thresholds must be optimized");
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*  812 */         rdThreshold = estimateLayerThreshold(maxBytes, this.layers[l - 1]);
/*      */       } 
/*      */       
/*  815 */       for (int i = 0; i < nt; i++) {
/*  816 */         if (l == 0) {
/*      */           
/*  818 */           this.headEnc.reset();
/*  819 */           this.headEnc.encodeTilePartHeader(0, i);
/*  820 */           tileLengths[i] = tileLengths[i] + this.headEnc.getLength();
/*      */         } 
/*      */         
/*  823 */         for (int c = 0; c < nc; c++) {
/*      */ 
/*      */           
/*  826 */           boolean sopUsed = ((String)this.wp.getSOP().getTileDef(i)).equalsIgnoreCase("true");
/*      */ 
/*      */           
/*  829 */           boolean ephUsed = ((String)this.wp.getEPH().getTileDef(i)).equalsIgnoreCase("true");
/*      */ 
/*      */ 
/*      */           
/*  833 */           SubbandAn sb = this.src.getAnSubbandTree(i, c);
/*  834 */           int mrl = sb.resLvl + 1;
/*      */           
/*  836 */           while (sb.subb_LL != null) {
/*  837 */             sb = sb.subb_LL;
/*      */           }
/*      */           
/*  840 */           for (int r = 0; r < mrl; r++) {
/*      */             
/*  842 */             nPrec = (this.numPrec[i][c][r]).x * (this.numPrec[i][c][r]).y;
/*  843 */             for (int p = 0; p < nPrec; p++) {
/*      */               
/*  845 */               findTruncIndices(l, c, r, i, sb, rdThreshold, p);
/*      */               
/*  847 */               hBuff = this.pktEnc.encodePacket(l + 1, c, r, i, this.cblks[i][c][r], this.truncIdxs[i][l][c][r], hBuff, bBuff, p);
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*  852 */               if (this.pktEnc.isPacketWritable()) {
/*  853 */                 int tmp = this.bsWriter.writePacketHead(hBuff.getBuffer(), hBuff.getLength(), true, sopUsed, ephUsed);
/*      */ 
/*      */ 
/*      */                 
/*  857 */                 tmp += this.bsWriter.writePacketBody(this.pktEnc.getLastBodyBuf(), this.pktEnc.getLastBodyLen(), true, this.pktEnc.isROIinPkt(), this.pktEnc.getROILen());
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*  862 */                 actualBytes += tmp;
/*  863 */                 tileLengths[i] = tileLengths[i] + tmp;
/*      */               } 
/*      */             } 
/*  866 */             sb = sb.parent;
/*      */           } 
/*      */         } 
/*      */       } 
/*  870 */       (this.layers[l]).rdThreshold = rdThreshold;
/*  871 */       (this.layers[l]).actualBytes = actualBytes;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  884 */     this.pktEnc.reset();
/*      */ 
/*      */ 
/*      */     
/*  888 */     int[] mrlc = new int[nc];
/*  889 */     for (int t = 0; t < nt; t++) {
/*      */ 
/*      */       
/*  892 */       int[][] lys = new int[nc][];
/*  893 */       for (int c = 0; c < nc; c++) {
/*  894 */         mrlc[c] = (this.src.getAnSubbandTree(t, c)).resLvl;
/*  895 */         lys[c] = new int[mrlc[c] + 1];
/*      */       } 
/*      */ 
/*      */       
/*  899 */       this.headEnc.reset();
/*  900 */       this.headEnc.encodeTilePartHeader(tileLengths[t], t);
/*  901 */       this.bsWriter.commitBitstreamHeader(this.headEnc);
/*  902 */       Progression[] prog = (Progression[])this.wp.getProgressionType().getTileDef(t);
/*      */       
/*  904 */       for (int prg = 0; prg < prog.length; prg++) {
/*  905 */         int lye = (prog[prg]).lye;
/*  906 */         int cs = (prog[prg]).cs;
/*  907 */         int ce = (prog[prg]).ce;
/*  908 */         int rs = (prog[prg]).rs;
/*  909 */         int re = (prog[prg]).re;
/*      */         
/*  911 */         switch ((prog[prg]).type) {
/*      */           case 1:
/*  913 */             writeResLyCompPos(t, rs, re, cs, ce, lys, lye);
/*      */             break;
/*      */           case 0:
/*  916 */             writeLyResCompPos(t, rs, re, cs, ce, lys, lye);
/*      */             break;
/*      */           case 3:
/*  919 */             writePosCompResLy(t, rs, re, cs, ce, lys, lye);
/*      */             break;
/*      */           case 4:
/*  922 */             writeCompPosResLy(t, rs, re, cs, ce, lys, lye);
/*      */             break;
/*      */           case 2:
/*  925 */             writeResPosCompLy(t, rs, re, cs, ce, lys, lye);
/*      */             break;
/*      */           default:
/*  928 */             throw new Error("Unsupported bit stream progression type");
/*      */         } 
/*      */ 
/*      */         
/*  932 */         for (int i = cs; i < ce; i++) {
/*  933 */           for (int r = rs; r < re; r++) {
/*  934 */             if (r <= mrlc[i]) {
/*  935 */               lys[i][r] = lye;
/*      */             }
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeResLyCompPos(int t, int rs, int re, int cs, int ce, int[][] lys, int lye) throws IOException {
/*  966 */     int nc = this.src.getNumComps();
/*  967 */     int[] mrl = new int[nc];
/*      */ 
/*      */     
/*  970 */     BitOutputBuffer hBuff = null;
/*  971 */     byte[] bBuff = null;
/*  972 */     int nPrec = 0;
/*      */ 
/*      */     
/*  975 */     int maxResLvl = 0;
/*  976 */     for (int c = 0; c < nc; c++) {
/*  977 */       mrl[c] = (this.src.getAnSubbandTree(t, c)).resLvl;
/*  978 */       if (mrl[c] > maxResLvl) maxResLvl = mrl[c];
/*      */     
/*      */     } 
/*      */ 
/*      */     
/*  983 */     for (int r = rs; r < re; r++) {
/*  984 */       if (r <= maxResLvl) {
/*      */         
/*  986 */         int minlys = 100000;
/*  987 */         for (int i = cs; i < ce; i++) {
/*  988 */           if (r < (lys[i]).length && lys[i][r] < minlys) {
/*  989 */             minlys = lys[i][r];
/*      */           }
/*      */         } 
/*      */         
/*  993 */         for (int l = minlys; l < lye; l++) {
/*  994 */           for (int j = cs; j < ce; j++) {
/*  995 */             if (r < (lys[j]).length && 
/*  996 */               l >= lys[j][r])
/*      */             {
/*      */               
/*  999 */               if (r <= mrl[j]) {
/*      */                 
/* 1001 */                 nPrec = (this.numPrec[t][j][r]).x * (this.numPrec[t][j][r]).y;
/* 1002 */                 for (int p = 0; p < nPrec; p++) {
/*      */ 
/*      */                   
/* 1005 */                   boolean sopUsed = ((String)this.wp.getSOP().getTileDef(t)).equals("true");
/*      */                   
/* 1007 */                   boolean ephUsed = ((String)this.wp.getEPH().getTileDef(t)).equals("true");
/*      */                   
/* 1009 */                   SubbandAn sb = this.src.getAnSubbandTree(t, j);
/* 1010 */                   for (int k = mrl[j]; k > r; k--) {
/* 1011 */                     sb = sb.subb_LL;
/*      */                   }
/*      */                   
/* 1014 */                   float threshold = (this.layers[l]).rdThreshold;
/* 1015 */                   findTruncIndices(l, j, r, t, sb, threshold, p);
/*      */                   
/* 1017 */                   hBuff = this.pktEnc.encodePacket(l + 1, j, r, t, this.cblks[t][j][r], this.truncIdxs[t][l][j][r], hBuff, bBuff, p);
/*      */ 
/*      */ 
/*      */                   
/* 1021 */                   if (this.pktEnc.isPacketWritable()) {
/* 1022 */                     this.bsWriter.writePacketHead(hBuff.getBuffer(), hBuff.getLength(), false, sopUsed, ephUsed);
/*      */ 
/*      */                     
/* 1025 */                     this.bsWriter.writePacketBody(this.pktEnc.getLastBodyBuf(), this.pktEnc.getLastBodyLen(), false, this.pktEnc.isROIinPkt(), this.pktEnc.getROILen());
/*      */                   } 
/*      */                 } 
/*      */               } 
/*      */             }
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeLyResCompPos(int t, int rs, int re, int cs, int ce, int[][] lys, int lye) throws IOException {
/* 1060 */     int nc = this.src.getNumComps();
/*      */ 
/*      */ 
/*      */     
/* 1064 */     BitOutputBuffer hBuff = null;
/* 1065 */     byte[] bBuff = null;
/* 1066 */     int nPrec = 0;
/*      */     
/* 1068 */     int minlys = 100000;
/* 1069 */     for (int c = cs; c < ce; c++) {
/* 1070 */       for (int r = 0; r < lys.length; r++) {
/* 1071 */         if (lys[c] != null && r < (lys[c]).length && lys[c][r] < minlys) {
/* 1072 */           minlys = lys[c][r];
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/* 1077 */     for (int l = minlys; l < lye; l++) {
/* 1078 */       for (int r = rs; r < re; r++) {
/* 1079 */         for (int i = cs; i < ce; i++) {
/* 1080 */           int mrl = (this.src.getAnSubbandTree(t, i)).resLvl;
/* 1081 */           if (r <= mrl && 
/* 1082 */             r < (lys[i]).length && 
/* 1083 */             l >= lys[i][r]) {
/* 1084 */             nPrec = (this.numPrec[t][i][r]).x * (this.numPrec[t][i][r]).y;
/* 1085 */             for (int p = 0; p < nPrec; p++) {
/*      */ 
/*      */               
/* 1088 */               boolean sopUsed = ((String)this.wp.getSOP().getTileDef(t)).equals("true");
/*      */               
/* 1090 */               boolean ephUsed = ((String)this.wp.getEPH().getTileDef(t)).equals("true");
/*      */               
/* 1092 */               SubbandAn sb = this.src.getAnSubbandTree(t, i);
/* 1093 */               for (int j = mrl; j > r; j--) {
/* 1094 */                 sb = sb.subb_LL;
/*      */               }
/*      */               
/* 1097 */               float threshold = (this.layers[l]).rdThreshold;
/* 1098 */               findTruncIndices(l, i, r, t, sb, threshold, p);
/*      */               
/* 1100 */               hBuff = this.pktEnc.encodePacket(l + 1, i, r, t, this.cblks[t][i][r], this.truncIdxs[t][l][i][r], hBuff, bBuff, p);
/*      */ 
/*      */ 
/*      */               
/* 1104 */               if (this.pktEnc.isPacketWritable()) {
/* 1105 */                 this.bsWriter.writePacketHead(hBuff.getBuffer(), hBuff.getLength(), false, sopUsed, ephUsed);
/*      */ 
/*      */                 
/* 1108 */                 this.bsWriter.writePacketBody(this.pktEnc.getLastBodyBuf(), this.pktEnc.getLastBodyLen(), false, this.pktEnc.isROIinPkt(), this.pktEnc.getROILen());
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writePosCompResLy(int t, int rs, int re, int cs, int ce, int[][] lys, int lye) throws IOException {
/* 1142 */     int nc = this.src.getNumComps();
/*      */ 
/*      */ 
/*      */     
/* 1146 */     BitOutputBuffer hBuff = null;
/* 1147 */     byte[] bBuff = null;
/*      */ 
/*      */     
/* 1150 */     Point nTiles = this.src.getNumTiles(null);
/* 1151 */     Point tileI = this.src.getTile(null);
/* 1152 */     int x0siz = this.src.getImgULX();
/* 1153 */     int y0siz = this.src.getImgULY();
/* 1154 */     int xsiz = x0siz + this.src.getImgWidth();
/* 1155 */     int ysiz = y0siz + this.src.getImgHeight();
/* 1156 */     int xt0siz = this.src.getTilePartULX();
/* 1157 */     int yt0siz = this.src.getTilePartULY();
/* 1158 */     int xtsiz = this.src.getNomTileWidth();
/* 1159 */     int ytsiz = this.src.getNomTileHeight();
/* 1160 */     int tx0 = (tileI.x == 0) ? x0siz : (xt0siz + tileI.x * xtsiz);
/* 1161 */     int ty0 = (tileI.y == 0) ? y0siz : (yt0siz + tileI.y * ytsiz);
/* 1162 */     int tx1 = (tileI.x != nTiles.x - 1) ? (xt0siz + (tileI.x + 1) * xtsiz) : xsiz;
/* 1163 */     int ty1 = (tileI.y != nTiles.y - 1) ? (yt0siz + (tileI.y + 1) * ytsiz) : ysiz;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1170 */     int gcd_x = 0;
/* 1171 */     int gcd_y = 0;
/* 1172 */     int nPrec = 0;
/* 1173 */     int[][] nextPrec = new int[ce][];
/*      */     
/* 1175 */     int minlys = 100000;
/* 1176 */     int minx = tx1;
/*      */     
/* 1178 */     int miny = ty1;
/*      */     
/* 1180 */     int maxx = tx0;
/* 1181 */     int maxy = ty0;
/* 1182 */     for (int c = cs; c < ce; c++) {
/* 1183 */       int mrl = (this.src.getAnSubbandTree(t, c)).resLvl;
/* 1184 */       nextPrec[c] = new int[mrl + 1];
/* 1185 */       for (int r = rs; r < re; r++) {
/* 1186 */         if (r <= mrl) {
/* 1187 */           if (r < (lys[c]).length && lys[c][r] < minlys) {
/* 1188 */             minlys = lys[c][r];
/*      */           }
/* 1190 */           int p = (this.numPrec[t][c][r]).y * (this.numPrec[t][c][r]).x - 1;
/* 1191 */           for (; p >= 0; p--) {
/* 1192 */             PrecInfo prec = this.pktEnc.getPrecInfo(t, c, r, p);
/* 1193 */             if (prec.rgulx != tx0) {
/* 1194 */               if (prec.rgulx < minx) minx = prec.rgulx; 
/* 1195 */               if (prec.rgulx > maxx) maxx = prec.rgulx; 
/*      */             } 
/* 1197 */             if (prec.rguly != ty0) {
/* 1198 */               if (prec.rguly < miny) miny = prec.rguly; 
/* 1199 */               if (prec.rguly > maxy) maxy = prec.rguly;
/*      */             
/*      */             } 
/* 1202 */             if (nPrec == 0) {
/* 1203 */               gcd_x = prec.rgw;
/* 1204 */               gcd_y = prec.rgh;
/*      */             } else {
/* 1206 */               gcd_x = MathUtil.gcd(gcd_x, prec.rgw);
/* 1207 */               gcd_y = MathUtil.gcd(gcd_y, prec.rgh);
/*      */             } 
/* 1209 */             nPrec++;
/*      */           } 
/*      */         } 
/*      */       } 
/* 1213 */     }  if (nPrec == 0) {
/* 1214 */       throw new Error("Image cannot have no precinct");
/*      */     }
/*      */     
/* 1217 */     int pyend = (maxy - miny) / gcd_y + 1;
/* 1218 */     int pxend = (maxx - minx) / gcd_x + 1;
/* 1219 */     int y = ty0;
/* 1220 */     int x = tx0;
/* 1221 */     for (int py = 0; py <= pyend; py++) {
/* 1222 */       for (int px = 0; px <= pxend; px++) {
/* 1223 */         for (int j = cs; j < ce; j++) {
/* 1224 */           int mrl = (this.src.getAnSubbandTree(t, j)).resLvl;
/* 1225 */           for (int r = rs; r < re; r++) {
/* 1226 */             if (r <= mrl && 
/* 1227 */               nextPrec[j][r] < (this.numPrec[t][j][r]).x * (this.numPrec[t][j][r]).y) {
/*      */ 
/*      */ 
/*      */               
/* 1231 */               PrecInfo prec = this.pktEnc.getPrecInfo(t, j, r, nextPrec[j][r]);
/* 1232 */               if (prec.rgulx == x && prec.rguly == y)
/*      */               
/*      */               { 
/* 1235 */                 for (int l = minlys; l < lye; l++) {
/* 1236 */                   if (r < (lys[j]).length && 
/* 1237 */                     l >= lys[j][r]) {
/*      */ 
/*      */                     
/* 1240 */                     boolean sopUsed = ((String)this.wp.getSOP().getTileDef(t)).equals("true");
/*      */                     
/* 1242 */                     boolean ephUsed = ((String)this.wp.getEPH().getTileDef(t)).equals("true");
/*      */                     
/* 1244 */                     SubbandAn sb = this.src.getAnSubbandTree(t, j);
/* 1245 */                     for (int k = mrl; k > r; k--) {
/* 1246 */                       sb = sb.subb_LL;
/*      */                     }
/*      */                     
/* 1249 */                     float threshold = (this.layers[l]).rdThreshold;
/* 1250 */                     findTruncIndices(l, j, r, t, sb, threshold, nextPrec[j][r]);
/*      */ 
/*      */ 
/*      */                     
/* 1254 */                     hBuff = this.pktEnc.encodePacket(l + 1, j, r, t, this.cblks[t][j][r], this.truncIdxs[t][l][j][r], hBuff, bBuff, nextPrec[j][r]);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                     
/* 1260 */                     if (this.pktEnc.isPacketWritable()) {
/* 1261 */                       this.bsWriter.writePacketHead(hBuff.getBuffer(), hBuff.getLength(), false, sopUsed, ephUsed);
/*      */ 
/*      */ 
/*      */                       
/* 1265 */                       this.bsWriter.writePacketBody(this.pktEnc.getLastBodyBuf(), this.pktEnc.getLastBodyLen(), false, this.pktEnc.isROIinPkt(), this.pktEnc.getROILen());
/*      */                     } 
/*      */                   } 
/*      */                 } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/* 1274 */                 nextPrec[j][r] = nextPrec[j][r] + 1; } 
/*      */             } 
/*      */           } 
/* 1277 */         }  if (px != pxend) {
/* 1278 */           x = minx + px * gcd_x;
/*      */         } else {
/* 1280 */           x = tx0;
/*      */         } 
/*      */       } 
/* 1283 */       if (py != pyend) {
/* 1284 */         y = miny + py * gcd_y;
/*      */       } else {
/* 1286 */         y = ty0;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1291 */     for (int i = cs; i < ce; i++) {
/* 1292 */       int mrl = (this.src.getAnSubbandTree(t, i)).resLvl;
/* 1293 */       for (int r = rs; r < re; r++) {
/* 1294 */         if (r <= mrl && 
/* 1295 */           nextPrec[i][r] < (this.numPrec[t][i][r]).x * (this.numPrec[t][i][r]).y - 1) {
/* 1296 */           throw new Error("JJ2000 bug: One precinct at least has not been written for resolution level " + r + " of component " + i + " in tile " + t + ".");
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeCompPosResLy(int t, int rs, int re, int cs, int ce, int[][] lys, int lye) throws IOException {
/* 1327 */     int nc = this.src.getNumComps();
/*      */ 
/*      */ 
/*      */     
/* 1331 */     BitOutputBuffer hBuff = null;
/* 1332 */     byte[] bBuff = null;
/*      */ 
/*      */     
/* 1335 */     Point nTiles = this.src.getNumTiles(null);
/* 1336 */     Point tileI = this.src.getTile(null);
/* 1337 */     int x0siz = this.src.getImgULX();
/* 1338 */     int y0siz = this.src.getImgULY();
/* 1339 */     int xsiz = x0siz + this.src.getImgWidth();
/* 1340 */     int ysiz = y0siz + this.src.getImgHeight();
/* 1341 */     int xt0siz = this.src.getTilePartULX();
/* 1342 */     int yt0siz = this.src.getTilePartULY();
/* 1343 */     int xtsiz = this.src.getNomTileWidth();
/* 1344 */     int ytsiz = this.src.getNomTileHeight();
/* 1345 */     int tx0 = (tileI.x == 0) ? x0siz : (xt0siz + tileI.x * xtsiz);
/* 1346 */     int ty0 = (tileI.y == 0) ? y0siz : (yt0siz + tileI.y * ytsiz);
/* 1347 */     int tx1 = (tileI.x != nTiles.x - 1) ? (xt0siz + (tileI.x + 1) * xtsiz) : xsiz;
/* 1348 */     int ty1 = (tileI.y != nTiles.y - 1) ? (yt0siz + (tileI.y + 1) * ytsiz) : ysiz;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1355 */     int gcd_x = 0;
/* 1356 */     int gcd_y = 0;
/* 1357 */     int nPrec = 0;
/* 1358 */     int[][] nextPrec = new int[ce][];
/*      */     
/* 1360 */     int minlys = 100000;
/* 1361 */     int minx = tx1;
/*      */     
/* 1363 */     int miny = ty1;
/*      */     
/* 1365 */     int maxx = tx0;
/* 1366 */     int maxy = ty0;
/* 1367 */     for (int c = cs; c < ce; c++) {
/* 1368 */       int mrl = (this.src.getAnSubbandTree(t, c)).resLvl;
/* 1369 */       for (int r = rs; r < re; r++) {
/* 1370 */         if (r <= mrl) {
/* 1371 */           nextPrec[c] = new int[mrl + 1];
/* 1372 */           if (r < (lys[c]).length && lys[c][r] < minlys) {
/* 1373 */             minlys = lys[c][r];
/*      */           }
/* 1375 */           int p = (this.numPrec[t][c][r]).y * (this.numPrec[t][c][r]).x - 1;
/* 1376 */           for (; p >= 0; p--) {
/* 1377 */             PrecInfo prec = this.pktEnc.getPrecInfo(t, c, r, p);
/* 1378 */             if (prec.rgulx != tx0) {
/* 1379 */               if (prec.rgulx < minx) minx = prec.rgulx; 
/* 1380 */               if (prec.rgulx > maxx) maxx = prec.rgulx; 
/*      */             } 
/* 1382 */             if (prec.rguly != ty0) {
/* 1383 */               if (prec.rguly < miny) miny = prec.rguly; 
/* 1384 */               if (prec.rguly > maxy) maxy = prec.rguly;
/*      */             
/*      */             } 
/* 1387 */             if (nPrec == 0) {
/* 1388 */               gcd_x = prec.rgw;
/* 1389 */               gcd_y = prec.rgh;
/*      */             } else {
/* 1391 */               gcd_x = MathUtil.gcd(gcd_x, prec.rgw);
/* 1392 */               gcd_y = MathUtil.gcd(gcd_y, prec.rgh);
/*      */             } 
/* 1394 */             nPrec++;
/*      */           } 
/*      */         } 
/*      */       } 
/* 1398 */     }  if (nPrec == 0) {
/* 1399 */       throw new Error("Image cannot have no precinct");
/*      */     }
/*      */     
/* 1402 */     int pyend = (maxy - miny) / gcd_y + 1;
/* 1403 */     int pxend = (maxx - minx) / gcd_x + 1;
/*      */     
/*      */     int i;
/* 1406 */     for (i = cs; i < ce; i++) {
/* 1407 */       int y = ty0;
/* 1408 */       int x = tx0;
/* 1409 */       int mrl = (this.src.getAnSubbandTree(t, i)).resLvl;
/* 1410 */       for (int py = 0; py <= pyend; py++) {
/* 1411 */         for (int px = 0; px <= pxend; px++) {
/* 1412 */           for (int r = rs; r < re; r++) {
/* 1413 */             if (r <= mrl && 
/* 1414 */               nextPrec[i][r] < (this.numPrec[t][i][r]).x * (this.numPrec[t][i][r]).y) {
/*      */ 
/*      */ 
/*      */               
/* 1418 */               PrecInfo prec = this.pktEnc.getPrecInfo(t, i, r, nextPrec[i][r]);
/* 1419 */               if (prec.rgulx == x && prec.rguly == y)
/*      */               
/*      */               { 
/*      */                 
/* 1423 */                 for (int l = minlys; l < lye; l++) {
/* 1424 */                   if (r < (lys[i]).length && 
/* 1425 */                     l >= lys[i][r]) {
/*      */ 
/*      */                     
/* 1428 */                     boolean sopUsed = ((String)this.wp.getSOP().getTileDef(t)).equals("true");
/*      */                     
/* 1430 */                     boolean ephUsed = ((String)this.wp.getEPH().getTileDef(t)).equals("true");
/*      */                     
/* 1432 */                     SubbandAn sb = this.src.getAnSubbandTree(t, i);
/* 1433 */                     for (int j = mrl; j > r; j--) {
/* 1434 */                       sb = sb.subb_LL;
/*      */                     }
/*      */                     
/* 1437 */                     float threshold = (this.layers[l]).rdThreshold;
/* 1438 */                     findTruncIndices(l, i, r, t, sb, threshold, nextPrec[i][r]);
/*      */ 
/*      */                     
/* 1441 */                     hBuff = this.pktEnc.encodePacket(l + 1, i, r, t, this.cblks[t][i][r], this.truncIdxs[t][l][i][r], hBuff, bBuff, nextPrec[i][r]);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                     
/* 1447 */                     if (this.pktEnc.isPacketWritable()) {
/* 1448 */                       this.bsWriter.writePacketHead(hBuff.getBuffer(), hBuff.getLength(), false, sopUsed, ephUsed);
/*      */ 
/*      */ 
/*      */                       
/* 1452 */                       this.bsWriter.writePacketBody(this.pktEnc.getLastBodyBuf(), this.pktEnc.getLastBodyLen(), false, this.pktEnc.isROIinPkt(), this.pktEnc.getROILen());
/*      */                     } 
/*      */                   } 
/*      */                 } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/* 1462 */                 nextPrec[i][r] = nextPrec[i][r] + 1; } 
/*      */             } 
/* 1464 */           }  if (px != pxend) {
/* 1465 */             x = minx + px * gcd_x;
/*      */           } else {
/* 1467 */             x = tx0;
/*      */           } 
/*      */         } 
/* 1470 */         if (py != pyend) {
/* 1471 */           y = miny + py * gcd_y;
/*      */         } else {
/* 1473 */           y = ty0;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1479 */     for (i = cs; i < ce; i++) {
/* 1480 */       int mrl = (this.src.getAnSubbandTree(t, i)).resLvl;
/* 1481 */       for (int r = rs; r < re; r++) {
/* 1482 */         if (r <= mrl && 
/* 1483 */           nextPrec[i][r] < (this.numPrec[t][i][r]).x * (this.numPrec[t][i][r]).y - 1) {
/* 1484 */           throw new Error("JJ2000 bug: One precinct at least has not been written for resolution level " + r + " of component " + i + " in tile " + t + ".");
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeResPosCompLy(int t, int rs, int re, int cs, int ce, int[][] lys, int lye) throws IOException {
/* 1515 */     int nc = this.src.getNumComps();
/*      */ 
/*      */ 
/*      */     
/* 1519 */     BitOutputBuffer hBuff = null;
/* 1520 */     byte[] bBuff = null;
/*      */ 
/*      */     
/* 1523 */     Point nTiles = this.src.getNumTiles(null);
/* 1524 */     Point tileI = this.src.getTile(null);
/* 1525 */     int x0siz = this.src.getImgULX();
/* 1526 */     int y0siz = this.src.getImgULY();
/* 1527 */     int xsiz = x0siz + this.src.getImgWidth();
/* 1528 */     int ysiz = y0siz + this.src.getImgHeight();
/* 1529 */     int xt0siz = this.src.getTilePartULX();
/* 1530 */     int yt0siz = this.src.getTilePartULY();
/* 1531 */     int xtsiz = this.src.getNomTileWidth();
/* 1532 */     int ytsiz = this.src.getNomTileHeight();
/* 1533 */     int tx0 = (tileI.x == 0) ? x0siz : (xt0siz + tileI.x * xtsiz);
/* 1534 */     int ty0 = (tileI.y == 0) ? y0siz : (yt0siz + tileI.y * ytsiz);
/* 1535 */     int tx1 = (tileI.x != nTiles.x - 1) ? (xt0siz + (tileI.x + 1) * xtsiz) : xsiz;
/* 1536 */     int ty1 = (tileI.y != nTiles.y - 1) ? (yt0siz + (tileI.y + 1) * ytsiz) : ysiz;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1543 */     int gcd_x = 0;
/* 1544 */     int gcd_y = 0;
/* 1545 */     int nPrec = 0;
/* 1546 */     int[][] nextPrec = new int[ce][];
/*      */     
/* 1548 */     int minlys = 100000;
/* 1549 */     int minx = tx1;
/*      */     
/* 1551 */     int miny = ty1;
/*      */     
/* 1553 */     int maxx = tx0;
/* 1554 */     int maxy = ty0;
/* 1555 */     for (int c = cs; c < ce; c++) {
/* 1556 */       int mrl = (this.src.getAnSubbandTree(t, c)).resLvl;
/* 1557 */       nextPrec[c] = new int[mrl + 1];
/* 1558 */       for (int j = rs; j < re; j++) {
/* 1559 */         if (j <= mrl) {
/* 1560 */           if (j < (lys[c]).length && lys[c][j] < minlys) {
/* 1561 */             minlys = lys[c][j];
/*      */           }
/* 1563 */           int p = (this.numPrec[t][c][j]).y * (this.numPrec[t][c][j]).x - 1;
/* 1564 */           for (; p >= 0; p--) {
/* 1565 */             PrecInfo prec = this.pktEnc.getPrecInfo(t, c, j, p);
/* 1566 */             if (prec.rgulx != tx0) {
/* 1567 */               if (prec.rgulx < minx) minx = prec.rgulx; 
/* 1568 */               if (prec.rgulx > maxx) maxx = prec.rgulx; 
/*      */             } 
/* 1570 */             if (prec.rguly != ty0) {
/* 1571 */               if (prec.rguly < miny) miny = prec.rguly; 
/* 1572 */               if (prec.rguly > maxy) maxy = prec.rguly;
/*      */             
/*      */             } 
/* 1575 */             if (nPrec == 0) {
/* 1576 */               gcd_x = prec.rgw;
/* 1577 */               gcd_y = prec.rgh;
/*      */             } else {
/* 1579 */               gcd_x = MathUtil.gcd(gcd_x, prec.rgw);
/* 1580 */               gcd_y = MathUtil.gcd(gcd_y, prec.rgh);
/*      */             } 
/* 1582 */             nPrec++;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/* 1587 */     if (nPrec == 0) {
/* 1588 */       throw new Error("Image cannot have no precinct");
/*      */     }
/*      */     
/* 1591 */     int pyend = (maxy - miny) / gcd_y + 1;
/* 1592 */     int pxend = (maxx - minx) / gcd_x + 1;
/*      */     
/* 1594 */     for (int r = rs; r < re; r++) {
/* 1595 */       int y = ty0;
/* 1596 */       int x = tx0;
/* 1597 */       for (int py = 0; py <= pyend; py++) {
/* 1598 */         for (int px = 0; px <= pxend; px++) {
/* 1599 */           for (int j = cs; j < ce; j++) {
/* 1600 */             int mrl = (this.src.getAnSubbandTree(t, j)).resLvl;
/* 1601 */             if (r <= mrl && 
/* 1602 */               nextPrec[j][r] < (this.numPrec[t][j][r]).x * (this.numPrec[t][j][r]).y) {
/*      */ 
/*      */ 
/*      */               
/* 1606 */               PrecInfo prec = this.pktEnc.getPrecInfo(t, j, r, nextPrec[j][r]);
/* 1607 */               if (prec.rgulx == x && prec.rguly == y)
/*      */               
/*      */               { 
/* 1610 */                 for (int l = minlys; l < lye; l++) {
/* 1611 */                   if (r < (lys[j]).length && 
/* 1612 */                     l >= lys[j][r]) {
/*      */ 
/*      */                     
/* 1615 */                     boolean sopUsed = ((String)this.wp.getSOP().getTileDef(t)).equals("true");
/*      */                     
/* 1617 */                     boolean ephUsed = ((String)this.wp.getEPH().getTileDef(t)).equals("true");
/*      */                     
/* 1619 */                     SubbandAn sb = this.src.getAnSubbandTree(t, j);
/* 1620 */                     for (int k = mrl; k > r; k--) {
/* 1621 */                       sb = sb.subb_LL;
/*      */                     }
/*      */                     
/* 1624 */                     float threshold = (this.layers[l]).rdThreshold;
/* 1625 */                     findTruncIndices(l, j, r, t, sb, threshold, nextPrec[j][r]);
/*      */ 
/*      */                     
/* 1628 */                     hBuff = this.pktEnc.encodePacket(l + 1, j, r, t, this.cblks[t][j][r], this.truncIdxs[t][l][j][r], hBuff, bBuff, nextPrec[j][r]);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                     
/* 1634 */                     if (this.pktEnc.isPacketWritable()) {
/* 1635 */                       this.bsWriter.writePacketHead(hBuff.getBuffer(), hBuff.getLength(), false, sopUsed, ephUsed);
/*      */ 
/*      */ 
/*      */                       
/* 1639 */                       this.bsWriter.writePacketBody(this.pktEnc.getLastBodyBuf(), this.pktEnc.getLastBodyLen(), false, this.pktEnc.isROIinPkt(), this.pktEnc.getROILen());
/*      */                     } 
/*      */                   } 
/*      */                 } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/* 1649 */                 nextPrec[j][r] = nextPrec[j][r] + 1; } 
/*      */             } 
/* 1651 */           }  if (px != pxend) {
/* 1652 */             x = minx + px * gcd_x;
/*      */           } else {
/* 1654 */             x = tx0;
/*      */           } 
/*      */         } 
/* 1657 */         if (py != pyend) {
/* 1658 */           y = miny + py * gcd_y;
/*      */         } else {
/* 1660 */           y = ty0;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1666 */     for (int i = cs; i < ce; i++) {
/* 1667 */       int mrl = (this.src.getAnSubbandTree(t, i)).resLvl;
/* 1668 */       for (int j = rs; j < re; j++) {
/* 1669 */         if (j <= mrl && 
/* 1670 */           nextPrec[i][j] < (this.numPrec[t][i][j]).x * (this.numPrec[t][i][j]).y - 1) {
/* 1671 */           throw new Error("JJ2000 bug: One precinct at least has not been written for resolution level " + j + " of component " + i + " in tile " + t + ".");
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private float optimizeBitstreamLayer(int layerIdx, float fmaxt, int maxBytes, int prevBytes) throws IOException {
/* 1721 */     this.pktEnc.save();
/*      */     
/* 1723 */     int nt = this.src.getNumTiles();
/* 1724 */     int nc = this.src.getNumComps();
/* 1725 */     BitOutputBuffer hBuff = null;
/* 1726 */     byte[] bBuff = null;
/*      */ 
/*      */ 
/*      */     
/*      */     int sidx;
/*      */ 
/*      */ 
/*      */     
/* 1734 */     for (sidx = 63; sidx > 0 && 
/* 1735 */       this.RDSlopesRates[sidx] < maxBytes; sidx--);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1740 */     float fmint = getSlopeFromSIndex(sidx);
/*      */     
/* 1742 */     if (fmint >= fmaxt) {
/* 1743 */       sidx--;
/* 1744 */       fmint = getSlopeFromSIndex(sidx);
/*      */     } 
/*      */ 
/*      */     
/* 1748 */     if (sidx <= 0) fmint = 0.0F;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1764 */     float ft = (fmaxt + fmint) / 2.0F;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1769 */     if (ft <= fmint) ft = fmaxt;
/*      */ 
/*      */ 
/*      */     
/*      */     do {
/* 1774 */       int actualBytes = prevBytes;
/* 1775 */       this.src.setTile(0, 0);
/*      */       
/* 1777 */       for (int t = 0; t < nt; t++) {
/* 1778 */         for (int c = 0; c < nc; c++) {
/*      */           
/* 1780 */           boolean sopUsed = ((String)this.wp.getSOP().getTileDef(t)).equalsIgnoreCase("true");
/*      */           
/* 1782 */           boolean ephUsed = ((String)this.wp.getEPH().getTileDef(t)).equalsIgnoreCase("true");
/*      */ 
/*      */           
/* 1785 */           SubbandAn sb = this.src.getAnSubbandTree(t, c);
/* 1786 */           int numLvls = sb.resLvl + 1;
/* 1787 */           sb = (SubbandAn)sb.getSubbandByIdx(0, 0);
/*      */           
/* 1789 */           for (int r = 0; r < numLvls; r++) {
/*      */             
/* 1791 */             int nPrec = (this.numPrec[t][c][r]).x * (this.numPrec[t][c][r]).y;
/* 1792 */             for (int p = 0; p < nPrec; p++) {
/*      */               
/* 1794 */               findTruncIndices(layerIdx, c, r, t, sb, ft, p);
/* 1795 */               hBuff = this.pktEnc.encodePacket(layerIdx + 1, c, r, t, this.cblks[t][c][r], this.truncIdxs[t][layerIdx][c][r], hBuff, bBuff, p);
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 1800 */               if (this.pktEnc.isPacketWritable()) {
/* 1801 */                 bBuff = this.pktEnc.getLastBodyBuf();
/* 1802 */                 actualBytes += this.bsWriter.writePacketHead(hBuff.getBuffer(), hBuff.getLength(), true, sopUsed, ephUsed);
/*      */ 
/*      */ 
/*      */                 
/* 1806 */                 actualBytes += this.bsWriter.writePacketBody(bBuff, this.pktEnc.getLastBodyLen(), true, this.pktEnc.isROIinPkt(), this.pktEnc.getROILen());
/*      */               } 
/*      */             } 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1813 */             sb = sb.parent;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/* 1819 */       if (actualBytes > maxBytes) {
/*      */ 
/*      */         
/* 1822 */         fmint = ft;
/*      */       }
/*      */       else {
/*      */         
/* 1826 */         fmaxt = ft;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1831 */       ft = (fmaxt + fmint) / 2.0F;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1836 */       if (ft <= fmint) ft = fmaxt;
/*      */ 
/*      */       
/* 1839 */       this.pktEnc.restore();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/* 1845 */     while (ft < fmaxt * 0.9999F && ft < fmaxt - 1.0E-10F);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1852 */     if (ft <= 1.0E-10F) {
/* 1853 */       ft = 0.0F;
/*      */     }
/*      */     else {
/*      */       
/* 1857 */       ft = fmaxt;
/*      */     } 
/* 1859 */     return ft;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private float estimateLayerThreshold(int targetBytes, EBCOTLayer lastLayer) {
/* 1907 */     float log_len1, log_len2, log_ab, lthresh = lastLayer.rdThreshold;
/* 1908 */     if (lthresh > this.maxSlope) lthresh = this.maxSlope;
/*      */ 
/*      */     
/* 1911 */     if (lthresh < 1.0E-10F) return 0.0F; 
/* 1912 */     int sidx = getLimitedSIndexFromSlope(lthresh);
/*      */ 
/*      */     
/* 1915 */     if (sidx >= 63) sidx = 62;
/*      */ 
/*      */ 
/*      */     
/* 1919 */     if (this.RDSlopesRates[sidx + 1] == 0) {
/*      */ 
/*      */ 
/*      */       
/* 1923 */       log_len1 = (float)Math.log(((this.RDSlopesRates[sidx] << 1) + 1));
/* 1924 */       log_len2 = (float)Math.log((this.RDSlopesRates[sidx] + 1));
/* 1925 */       log_ab = (float)Math.log((lastLayer.actualBytes + this.RDSlopesRates[sidx] + 1));
/*      */     }
/*      */     else {
/*      */       
/* 1929 */       log_len1 = (float)Math.log(this.RDSlopesRates[sidx]);
/* 1930 */       log_len2 = (float)Math.log(this.RDSlopesRates[sidx + 1]);
/* 1931 */       log_ab = (float)Math.log(lastLayer.actualBytes);
/*      */     } 
/*      */     
/* 1934 */     float log_sl1 = (float)Math.log(getSlopeFromSIndex(sidx));
/* 1935 */     float log_sl2 = (float)Math.log(getSlopeFromSIndex(sidx + 1));
/*      */     
/* 1937 */     float log_isl = (float)Math.log(lthresh);
/*      */     
/* 1939 */     float log_ilen = log_len1 + (log_isl - log_sl1) * (log_len1 - log_len2) / (log_sl1 - log_sl2);
/*      */ 
/*      */     
/* 1942 */     float log_off = log_ab - log_ilen;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1947 */     if (log_off < 0.0F) log_off = 0.0F;
/*      */ 
/*      */ 
/*      */     
/* 1951 */     int tlen = (int)(targetBytes / (float)Math.exp(log_off));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1958 */     for (sidx = 63; sidx >= 0 && 
/* 1959 */       this.RDSlopesRates[sidx] < tlen; sidx--);
/*      */     
/* 1961 */     sidx++;
/*      */     
/* 1963 */     if (sidx >= 64) sidx = 63; 
/* 1964 */     if (sidx <= 0) sidx = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1969 */     if (this.RDSlopesRates[sidx] == 0) {
/*      */ 
/*      */ 
/*      */       
/* 1973 */       log_len1 = (float)Math.log((this.RDSlopesRates[sidx - 1] + 1));
/* 1974 */       log_len2 = (float)Math.log(((this.RDSlopesRates[sidx - 1] << 1) + 1));
/* 1975 */       log_ilen = (float)Math.log((tlen + this.RDSlopesRates[sidx - 1] + 1));
/*      */     }
/*      */     else {
/*      */       
/* 1979 */       log_len1 = (float)Math.log(this.RDSlopesRates[sidx]);
/* 1980 */       log_len2 = (float)Math.log(this.RDSlopesRates[sidx - 1]);
/* 1981 */       log_ilen = (float)Math.log(tlen);
/*      */     } 
/*      */     
/* 1984 */     log_sl1 = (float)Math.log(getSlopeFromSIndex(sidx));
/* 1985 */     log_sl2 = (float)Math.log(getSlopeFromSIndex(sidx - 1));
/*      */ 
/*      */ 
/*      */     
/* 1989 */     log_isl = log_sl1 + (log_ilen - log_len1) * (log_sl1 - log_sl2) / (log_len1 - log_len2);
/*      */ 
/*      */     
/* 1992 */     float eth = (float)Math.exp(log_isl);
/*      */ 
/*      */     
/* 1995 */     if (eth > lthresh) eth = lthresh; 
/* 1996 */     if (eth < 1.0E-10F) eth = 0.0F;
/*      */ 
/*      */     
/* 1999 */     return eth;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void findTruncIndices(int layerIdx, int compIdx, int lvlIdx, int tileIdx, SubbandAn subb, float fthresh, int precinctIdx) {
/* 2026 */     Point ncblks = null;
/*      */ 
/*      */     
/* 2029 */     PrecInfo prec = this.pktEnc.getPrecInfo(tileIdx, compIdx, lvlIdx, precinctIdx);
/*      */ 
/*      */     
/* 2032 */     SubbandAn sb = subb;
/* 2033 */     while (sb.subb_HH != null) {
/* 2034 */       sb = sb.subb_HH;
/*      */     }
/* 2036 */     int minsbi = (lvlIdx == 0) ? 0 : 1;
/* 2037 */     int maxsbi = (lvlIdx == 0) ? 1 : 4;
/*      */ 
/*      */ 
/*      */     
/* 2041 */     sb = (SubbandAn)subb.getSubbandByIdx(lvlIdx, minsbi);
/* 2042 */     for (int s = minsbi; s < maxsbi; s++) {
/* 2043 */       int yend = (prec.cblk[s] != null) ? (prec.cblk[s]).length : 0;
/* 2044 */       for (int y = 0; y < yend; y++) {
/* 2045 */         int xend = (prec.cblk[s][y] != null) ? (prec.cblk[s][y]).length : 0;
/* 2046 */         for (int x = 0; x < xend; x++) {
/* 2047 */           Point cbCoord = (prec.cblk[s][y][x]).idx;
/* 2048 */           int b = cbCoord.x + cbCoord.y * sb.numCb.x;
/*      */           
/* 2050 */           CBlkRateDistStats cur_cblk = this.cblks[tileIdx][compIdx][lvlIdx][s][b]; int n;
/* 2051 */           for (n = 0; n < cur_cblk.nVldTrunc && 
/* 2052 */             cur_cblk.truncSlopes[n] >= fthresh; n++);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2060 */           this.truncIdxs[tileIdx][layerIdx][compIdx][lvlIdx][s][b] = n - 1;
/*      */         } 
/*      */       } 
/*      */       
/* 2064 */       sb = (SubbandAn)sb.nextSubband();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int getLimitedSIndexFromSlope(float slope) {
/* 2085 */     int idx = (int)Math.floor(Math.log(slope) / LOG2) + 24;
/*      */     
/* 2087 */     if (idx < 0) {
/* 2088 */       return 0;
/*      */     }
/* 2090 */     if (idx >= 64) {
/* 2091 */       return 63;
/*      */     }
/*      */     
/* 2094 */     return idx;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static float getSlopeFromSIndex(int index) {
/* 2107 */     return (float)Math.pow(2.0D, (index - 24));
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/entropy/encoder/EBCOTRateAllocator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */