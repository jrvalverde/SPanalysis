/*     */ package jj2000.j2k.entropy.encoder;
/*     */ 
/*     */ import com.sun.media.imageioimpl.plugins.jpeg2000.J2KImageWriteParamJava;
/*     */ import jj2000.j2k.StringSpec;
/*     */ import jj2000.j2k.entropy.CBlkSizeSpec;
/*     */ import jj2000.j2k.entropy.PrecinctSizeSpec;
/*     */ import jj2000.j2k.entropy.StdEntropyCoderOptions;
/*     */ import jj2000.j2k.image.ImgData;
/*     */ import jj2000.j2k.image.ImgDataAdapter;
/*     */ import jj2000.j2k.quantization.quantizer.CBlkQuantDataSrcEnc;
/*     */ import jj2000.j2k.wavelet.analysis.SubbandAn;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class EntropyCoder
/*     */   extends ImgDataAdapter
/*     */   implements CodedCBlkDataSrcEnc, StdEntropyCoderOptions
/*     */ {
/*     */   public static final char OPT_PREFIX = 'C';
/* 125 */   private static final String[][] pinfo = new String[][] { { "Cblksiz", "[<tile-component idx>] <width> <height> [[<tile-component idx>] <width> <height>]", "Specifies the maximum code-block size to use for tile-component. The maximum width and height is 1024, however the surface area (i.e. width x height) must not exceed 4096. The minimum width and height is 4.", "64 64" }, { "Cbypass", "[<tile-component idx>] true|false[ [<tile-component idx>] true|false ...]", "Uses the lazy coding mode with the entropy coder. This will bypass the MQ coder for some of the coding passes, where the distribution is often close to uniform. Since the MQ codeword will be terminated at least once per lazy pass, it is important to use an efficient termination algorithm, see the 'Cterm' option.'true' enables, 'false' disables it.", "false" }, { "CresetMQ", "[<tile-component idx>] true|false[ [<tile-component idx>] true|false ...]", "If this is enabled the probability estimates of the MQ coder are reset after each arithmetically coded (i.e. non-lazy) coding pass. 'true' enables, 'false' disables it.", "false" }, { "Creg_term", "[<tile-component idx>] true|false[ [<tile-component idx>] true|false ...]", "If this is enabled the codeword (raw or MQ) is terminated on a byte boundary after each coding pass. In this case it is important to use an efficient termination algorithm, see the 'Cterm' option. 'true' enables, 'false' disables it.", "false" }, { "Ccausal", "[<tile-component idx>] true|false[ [<tile-component idx>] true|false ...]", "Uses vertically stripe causal context formation. If this is enabled the context formation process in one stripe is independant of the next stripe (i.e. the one below it). 'true' enables, 'false' disables it.", "false" }, { "Cseg_symbol", "[<tile-component idx>] true|false[ [<tile-component idx>] true|false ...]", "Inserts an error resilience segmentation symbol in the MQ codeword at the end of each bit-plane (cleanup pass). Decoders can use this information to detect and conceal errors.'true' enables, 'false' disables it.", "false" }, { "Cterm", "[<tile-component idx>] near_opt|easy|predict|full[ [<tile-component idx>] near_opt|easy|predict|full ...]", "Specifies the algorithm used to terminate the MQ codeword. The most efficient one is 'near_opt', which delivers a codeword which in almost all cases is the shortest possible. The 'easy' is a simpler algorithm that delivers a codeword length that is close to the previous one (in average 1 bit longer). The 'predict' is almost the same as the 'easy' but it leaves error resilient information on the spare least significant bits (in average 3.5 bits), which can be used by a decoder to detect errors. The 'full' algorithm performs a full flush of the MQ coder and is highly inefficient.\nIt is important to use a good termination policy since the MQ codeword can be terminated quite often, specially if the 'Cbypass' or 'Creg_term' options are enabled (in the normal case it would be terminated once per code-block, while if 'Creg_term' is specified it will be done almost 3 times per bit-plane in each code-block).", "near_opt" }, { "Clen_calc", "[<tile-component idx>] near_opt|lazy_good|lazy[ [<tile-component idx>] ...]", "Specifies the algorithm to use in calculating the necessary MQ length for each decoding pass. The best one is 'near_opt', which performs a rather sophisticated calculation and provides the best results. The 'lazy_good' and 'lazy' are very simple algorithms that provide rather conservative results, 'lazy_good' one being slightly better. Do not change this option unless you want to experiment the effect of different length calculation algorithms.", "near_opt" }, { "Cpp", "[<tile-component idx>] <dim> <dim> [<dim> <dim>] [ [<tile-component idx>] ...]", "Specifies precinct partition dimensions for tile-component. The first two values apply to the highest resolution and the following ones (if any) apply to the remaining resolutions in decreasing order. If less values than the number of decomposition levels are specified, then the last two values are used for the remaining resolutions.", null } };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected CBlkQuantDataSrcEnc src;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EntropyCoder(CBlkQuantDataSrcEnc src) {
/* 220 */     super((ImgData)src);
/* 221 */     this.src = src;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract int getCBlkWidth(int paramInt1, int paramInt2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract int getCBlkHeight(int paramInt1, int paramInt2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isReversible(int t, int c) {
/* 264 */     return this.src.isReversible(t, c);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SubbandAn getAnSubbandTree(int t, int c) {
/* 282 */     return this.src.getAnSubbandTree(t, c);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getCbULX() {
/* 290 */     return this.src.getCbULX();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getCbULY() {
/* 298 */     return this.src.getCbULY();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[][] getParameterInfo() {
/* 316 */     return pinfo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static EntropyCoder createInstance(CBlkQuantDataSrcEnc src, J2KImageWriteParamJava wp, CBlkSizeSpec cblks, PrecinctSizeSpec pss, StringSpec bms, StringSpec mqrs, StringSpec rts, StringSpec css, StringSpec sss, StringSpec lcs, StringSpec tts) {
/* 359 */     return new StdEntropyCoder(src, cblks, pss, bms, mqrs, rts, css, sss, lcs, tts);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/entropy/encoder/EntropyCoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */