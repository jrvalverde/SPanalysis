/*     */ package jj2000.j2k.entropy;
/*     */ 
/*     */ import com.sun.media.imageioimpl.plugins.jpeg2000.J2KImageWriteParamJava;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.StringTokenizer;
/*     */ import jj2000.j2k.ModuleSpec;
/*     */ import jj2000.j2k.util.MathUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CBlkSizeSpec
/*     */   extends ModuleSpec
/*     */ {
/*  98 */   private String defaultValue = "64 64";
/*     */ 
/*     */   
/*     */   private static final String optName = "Cblksiz";
/*     */ 
/*     */   
/* 104 */   private int maxCBlkWidth = 0;
/*     */ 
/*     */   
/* 107 */   private int maxCBlkHeight = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CBlkSizeSpec(int nt, int nc, byte type) {
/* 121 */     super(nt, nc, type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CBlkSizeSpec(int nt, int nc, byte type, J2KImageWriteParamJava wp, String values) {
/* 140 */     super(nt, nc, type);
/*     */     
/* 142 */     boolean firstVal = true;
/* 143 */     this.specified = values;
/*     */     
/* 145 */     String param = values;
/* 146 */     if (param == null) {
/* 147 */       param = this.defaultValue;
/*     */     }
/*     */ 
/*     */     
/* 151 */     StringTokenizer stk = new StringTokenizer(param);
/* 152 */     byte curSpecType = 0;
/*     */     
/* 154 */     boolean[] tileSpec = null;
/* 155 */     boolean[] compSpec = null;
/*     */     
/* 157 */     String word = null;
/* 158 */     String errMsg = null;
/*     */     
/* 160 */     while (stk.hasMoreTokens()) {
/* 161 */       int ci; word = stk.nextToken();
/*     */       
/* 163 */       switch (word.charAt(0)) {
/*     */         
/*     */         case 't':
/* 166 */           tileSpec = parseIdx(word, this.nTiles);
/* 167 */           if (curSpecType == 1) {
/* 168 */             curSpecType = 3;
/*     */             continue;
/*     */           } 
/* 171 */           curSpecType = 2;
/*     */           continue;
/*     */ 
/*     */         
/*     */         case 'c':
/* 176 */           compSpec = parseIdx(word, this.nComp);
/* 177 */           if (curSpecType == 2) {
/* 178 */             curSpecType = 3;
/*     */             continue;
/*     */           } 
/* 181 */           curSpecType = 1;
/*     */           continue;
/*     */       } 
/*     */ 
/*     */       
/* 186 */       if (!Character.isDigit(word.charAt(0))) {
/* 187 */         errMsg = "Bad construction for parameter: " + word;
/* 188 */         throw new IllegalArgumentException(errMsg);
/*     */       } 
/* 190 */       Integer[] dim = new Integer[2];
/*     */       
/*     */       try {
/* 193 */         dim[0] = new Integer(word);
/*     */ 
/*     */         
/* 196 */         if (dim[0].intValue() > 1024) {
/* 197 */           errMsg = "'Cblksiz' option : the code-block's width cannot be greater than 1024";
/*     */ 
/*     */           
/* 200 */           throw new IllegalArgumentException(errMsg);
/*     */         } 
/*     */ 
/*     */         
/* 204 */         if (dim[0].intValue() < 4) {
/* 205 */           errMsg = "'Cblksiz' option : the code-block's width cannot be less than 4";
/*     */ 
/*     */           
/* 208 */           throw new IllegalArgumentException(errMsg);
/*     */         } 
/*     */         
/* 211 */         if (dim[0].intValue() != 1 << MathUtil.log2(dim[0].intValue()))
/*     */         {
/* 213 */           errMsg = "'Cblksiz' option : the code-block's width must be a power of 2";
/*     */           
/* 215 */           throw new IllegalArgumentException(errMsg);
/*     */         }
/*     */       
/* 218 */       } catch (NumberFormatException e) {
/* 219 */         errMsg = "'Cblksiz' option : the code-block's width could not be parsed.";
/*     */         
/* 221 */         throw new IllegalArgumentException(errMsg);
/*     */       } 
/*     */       
/*     */       try {
/* 225 */         word = stk.nextToken();
/*     */       }
/* 227 */       catch (NoSuchElementException e) {
/* 228 */         errMsg = "'Cblksiz' option : could not parse the code-block's height";
/*     */         
/* 230 */         throw new IllegalArgumentException(errMsg);
/*     */       } 
/*     */ 
/*     */       
/*     */       try {
/* 235 */         dim[1] = new Integer(word);
/*     */ 
/*     */         
/* 238 */         if (dim[1].intValue() > 1024) {
/* 239 */           errMsg = "'Cblksiz' option : the code-block's height cannot be greater than 1024";
/*     */ 
/*     */           
/* 242 */           throw new IllegalArgumentException(errMsg);
/*     */         } 
/*     */ 
/*     */         
/* 246 */         if (dim[1].intValue() < 4) {
/* 247 */           errMsg = "'Cblksiz' option : the code-block's height cannot be less than 4";
/*     */ 
/*     */           
/* 250 */           throw new IllegalArgumentException(errMsg);
/*     */         } 
/*     */         
/* 253 */         if (dim[1].intValue() != 1 << MathUtil.log2(dim[1].intValue())) {
/*     */           
/* 255 */           errMsg = "'Cblksiz' option : the code-block's height must be a power of 2";
/*     */           
/* 257 */           throw new IllegalArgumentException(errMsg);
/*     */         } 
/*     */ 
/*     */         
/* 261 */         if (dim[0].intValue() * dim[1].intValue() > 4096)
/*     */         {
/*     */           
/* 264 */           errMsg = "'Cblksiz' option : The code-block's area (i.e. width*height) cannot be greater than 4096";
/*     */ 
/*     */ 
/*     */           
/* 268 */           throw new IllegalArgumentException(errMsg);
/*     */         }
/*     */       
/* 271 */       } catch (NumberFormatException e) {
/* 272 */         errMsg = "'Cblksiz' option : the code-block's height could not be parsed.";
/*     */         
/* 274 */         throw new IllegalArgumentException(errMsg);
/*     */       } 
/*     */ 
/*     */       
/* 278 */       if (dim[0].intValue() > this.maxCBlkWidth) {
/* 279 */         this.maxCBlkWidth = dim[0].intValue();
/*     */       }
/*     */       
/* 282 */       if (dim[1].intValue() > this.maxCBlkHeight) {
/* 283 */         this.maxCBlkHeight = dim[1].intValue();
/*     */       }
/*     */       
/* 286 */       if (firstVal) {
/*     */ 
/*     */         
/* 289 */         setDefault(dim);
/* 290 */         firstVal = false;
/*     */       } 
/*     */       
/* 293 */       switch (curSpecType) {
/*     */         case 0:
/* 295 */           setDefault(dim);
/*     */           continue;
/*     */         case 2:
/* 298 */           for (ti = tileSpec.length - 1; ti >= 0; ti--) {
/* 299 */             if (tileSpec[ti]) {
/* 300 */               setTileDef(ti, dim);
/*     */             }
/*     */           } 
/*     */           continue;
/*     */         case 1:
/* 305 */           for (ci = compSpec.length - 1; ci >= 0; ci--) {
/* 306 */             if (compSpec[ci]) {
/* 307 */               setCompDef(ci, dim);
/*     */             }
/*     */           } 
/*     */           continue;
/*     */       } 
/* 312 */       for (int ti = tileSpec.length - 1; ti >= 0; ti--) {
/* 313 */         for (ci = compSpec.length - 1; ci >= 0; ci--) {
/* 314 */           if (tileSpec[ti] && compSpec[ci]) {
/* 315 */             setTileCompVal(ti, ci, dim);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaxCBlkWidth() {
/* 330 */     return this.maxCBlkWidth;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaxCBlkHeight() {
/* 338 */     return this.maxCBlkHeight;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getCBlkWidth(byte type, int t, int c) {
/* 373 */     Integer[] dim = null;
/* 374 */     switch (type) {
/*     */       case 0:
/* 376 */         dim = (Integer[])getDefault();
/*     */         break;
/*     */       case 1:
/* 379 */         dim = (Integer[])getCompDef(c);
/*     */         break;
/*     */       case 2:
/* 382 */         dim = (Integer[])getTileDef(t);
/*     */         break;
/*     */       case 3:
/* 385 */         dim = (Integer[])getTileCompVal(t, c); break;
/*     */     } 
/* 387 */     return dim[0].intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getCBlkHeight(byte type, int t, int c) {
/* 422 */     Integer[] dim = null;
/* 423 */     switch (type) {
/*     */       case 0:
/* 425 */         dim = (Integer[])getDefault();
/*     */         break;
/*     */       case 1:
/* 428 */         dim = (Integer[])getCompDef(c);
/*     */         break;
/*     */       case 2:
/* 431 */         dim = (Integer[])getTileDef(t);
/*     */         break;
/*     */       case 3:
/* 434 */         dim = (Integer[])getTileCompVal(t, c); break;
/*     */     } 
/* 436 */     return dim[1].intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefault(Object value) {
/* 445 */     super.setDefault(value);
/*     */ 
/*     */     
/* 448 */     storeHighestDims((Integer[])value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTileDef(int t, Object value) {
/* 460 */     super.setTileDef(t, value);
/*     */ 
/*     */     
/* 463 */     storeHighestDims((Integer[])value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCompDef(int c, Object value) {
/* 475 */     super.setCompDef(c, value);
/*     */ 
/*     */     
/* 478 */     storeHighestDims((Integer[])value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTileCompVal(int t, int c, Object value) {
/* 491 */     super.setTileCompVal(t, c, value);
/*     */ 
/*     */     
/* 494 */     storeHighestDims((Integer[])value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void storeHighestDims(Integer[] dim) {
/* 505 */     if (dim[0].intValue() > this.maxCBlkWidth) {
/* 506 */       this.maxCBlkWidth = dim[0].intValue();
/*     */     }
/* 508 */     if (dim[1].intValue() > this.maxCBlkHeight)
/* 509 */       this.maxCBlkHeight = dim[1].intValue(); 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/entropy/CBlkSizeSpec.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */