/*     */ package jj2000.j2k.entropy.encoder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BitToByteOutput
/*     */ {
/*     */   private boolean isPredTerm = false;
/*     */   static final int PAD_SEQ = 42;
/*     */   boolean delFF = false;
/*     */   ByteOutputBuffer out;
/*     */   int bbuf;
/* 114 */   int bpos = 7;
/*     */ 
/*     */   
/* 117 */   int nb = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   BitToByteOutput(ByteOutputBuffer out) {
/* 126 */     this.out = out;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void writeBits(int[] symbuf, int nsym) {
/* 141 */     int bbuf = this.bbuf;
/* 142 */     int bpos = this.bpos;
/*     */     
/* 144 */     for (int i = 0; i < nsym; i++) {
/* 145 */       bbuf |= (symbuf[i] & 0x1) << bpos--;
/* 146 */       if (bpos < 0) {
/* 147 */         if (bbuf != 255) {
/* 148 */           if (this.delFF) {
/* 149 */             this.out.write(255);
/* 150 */             this.delFF = false;
/* 151 */             this.nb++;
/*     */           } 
/* 153 */           this.out.write(bbuf);
/* 154 */           this.nb++;
/* 155 */           bpos = 7;
/*     */         } else {
/*     */           
/* 158 */           this.delFF = true;
/* 159 */           bpos = 6;
/*     */         } 
/* 161 */         bbuf = 0;
/*     */       } 
/*     */     } 
/* 164 */     this.bbuf = bbuf;
/* 165 */     this.bpos = bpos;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void writeBit(int bit) {
/* 175 */     this.bbuf |= (bit & 0x1) << this.bpos--;
/* 176 */     if (this.bpos < 0) {
/* 177 */       if (this.bbuf != 255) {
/* 178 */         if (this.delFF) {
/* 179 */           this.out.write(255);
/* 180 */           this.delFF = false;
/* 181 */           this.nb++;
/*     */         } 
/*     */         
/* 184 */         this.out.write(this.bbuf);
/* 185 */         this.nb++;
/* 186 */         this.bpos = 7;
/*     */       } else {
/*     */         
/* 189 */         this.delFF = true;
/* 190 */         this.bpos = 6;
/*     */       } 
/* 192 */       this.bbuf = 0;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void flush() {
/* 201 */     if (this.delFF) {
/* 202 */       if (this.bpos != 6) {
/*     */         
/* 204 */         this.out.write(255);
/* 205 */         this.delFF = false;
/* 206 */         this.nb++;
/*     */ 
/*     */         
/* 209 */         this.bbuf |= 42 >>> 6 - this.bpos;
/*     */         
/* 211 */         this.out.write(this.bbuf);
/* 212 */         this.nb++;
/* 213 */         this.bpos = 7;
/* 214 */         this.bbuf = 0;
/* 215 */       } else if (this.isPredTerm) {
/* 216 */         this.out.write(255);
/* 217 */         this.nb++;
/* 218 */         this.out.write(42);
/* 219 */         this.nb++;
/* 220 */         this.bpos = 7;
/* 221 */         this.bbuf = 0;
/* 222 */         this.delFF = false;
/*     */       }
/*     */     
/*     */     }
/* 226 */     else if (this.bpos != 7) {
/*     */ 
/*     */       
/* 229 */       this.bbuf |= 42 >>> 6 - this.bpos;
/*     */       
/* 231 */       this.out.write(this.bbuf);
/* 232 */       this.nb++;
/* 233 */       this.bpos = 7;
/* 234 */       this.bbuf = 0;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int terminate() {
/* 243 */     flush();
/* 244 */     int savedNb = this.nb;
/* 245 */     reset();
/* 246 */     return savedNb;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void reset() {
/* 255 */     this.delFF = false;
/* 256 */     this.bpos = 7;
/* 257 */     this.bbuf = 0;
/* 258 */     this.nb = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int length() {
/* 269 */     if (this.delFF)
/*     */     {
/*     */       
/* 272 */       return this.nb + 2;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 277 */     return this.nb + ((this.bpos == 7) ? 0 : 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setPredTerm(boolean isPredTerm) {
/* 288 */     this.isPredTerm = isPredTerm;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/entropy/encoder/BitToByteOutput.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */