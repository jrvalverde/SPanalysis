/*      */ package jj2000.j2k.entropy.encoder;
/*      */ 
/*      */ import java.awt.Point;
/*      */ import java.util.Stack;
/*      */ import jj2000.j2k.StringSpec;
/*      */ import jj2000.j2k.entropy.CBlkSizeSpec;
/*      */ import jj2000.j2k.entropy.PrecinctSizeSpec;
/*      */ import jj2000.j2k.entropy.StdEntropyCoderOptions;
/*      */ import jj2000.j2k.quantization.quantizer.CBlkQuantDataSrcEnc;
/*      */ import jj2000.j2k.util.ArrayUtil;
/*      */ import jj2000.j2k.util.FacilityManager;
/*      */ import jj2000.j2k.util.ThreadPool;
/*      */ import jj2000.j2k.wavelet.analysis.CBlkWTData;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class StdEntropyCoder
/*      */   extends EntropyCoder
/*      */   implements StdEntropyCoderOptions
/*      */ {
/*      */   private static final boolean DO_TIMING = false;
/*      */   private long[] time;
/*      */   public static final String THREADS_PROP_NAME = "jj2000.j2k.entropy.encoder.StdEntropyCoder.nthreads";
/*      */   public static final String DEF_THREADS_NUM = "0";
/*      */   public static final int THREADS_PRIORITY_INC = 0;
/*      */   private ThreadPool tPool;
/*      */   private Stack idleComps;
/*      */   private Stack[] completedComps;
/*      */   private int[] nBusyComps;
/*      */   private boolean[] finishedTileComponent;
/*      */   private MQCoder[] mqT;
/*      */   private BitToByteOutput[] boutT;
/*      */   private ByteOutputBuffer[] outT;
/*      */   private CBlkSizeSpec cblks;
/*      */   private PrecinctSizeSpec pss;
/*      */   public StringSpec bms;
/*      */   public StringSpec mqrs;
/*      */   public StringSpec rts;
/*      */   public StringSpec css;
/*      */   public StringSpec sss;
/*      */   public StringSpec lcs;
/*      */   public StringSpec tts;
/*      */   private int[][] opts;
/*      */   private int[][] lenCalc;
/*      */   private int[][] tType;
/*      */   private static final int ZC_LUT_BITS = 8;
/*  254 */   private static final int[] ZC_LUT_LH = new int[256];
/*      */ 
/*      */   
/*  257 */   private static final int[] ZC_LUT_HL = new int[256];
/*      */ 
/*      */   
/*  260 */   private static final int[] ZC_LUT_HH = new int[256];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int SC_LUT_BITS = 9;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  274 */   private static final int[] SC_LUT = new int[512];
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int SC_LUT_MASK = 15;
/*      */ 
/*      */   
/*      */   private static final int SC_SPRED_SHIFT = 31;
/*      */ 
/*      */   
/*      */   private static final int INT_SIGN_BIT = -2147483648;
/*      */ 
/*      */   
/*      */   private static final int MR_LUT_BITS = 9;
/*      */ 
/*      */   
/*  290 */   private static final int[] MR_LUT = new int[512];
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int NUM_CTXTS = 19;
/*      */ 
/*      */   
/*      */   private static final int RLC_CTXT = 1;
/*      */ 
/*      */   
/*      */   private static final int UNIF_CTXT = 0;
/*      */ 
/*      */   
/*  303 */   private static final int[] MQ_INIT = new int[] { 46, 3, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
/*      */ 
/*      */ 
/*      */   
/*  307 */   private static final int[] SEG_SYMBOLS = new int[] { 1, 0, 1, 0 };
/*      */ 
/*      */ 
/*      */   
/*  311 */   private static final int[] SEG_SYMB_CTXTS = new int[] { 0, 0, 0, 0 };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int[][] stateT;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int STATE_SEP = 16;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int STATE_SIG_R1 = 32768;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int STATE_VISITED_R1 = 16384;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int STATE_NZ_CTXT_R1 = 8192;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int STATE_H_L_SIGN_R1 = 4096;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int STATE_H_R_SIGN_R1 = 2048;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int STATE_V_U_SIGN_R1 = 1024;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int STATE_V_D_SIGN_R1 = 512;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int STATE_PREV_MR_R1 = 256;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int STATE_H_L_R1 = 128;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int STATE_H_R_R1 = 64;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int STATE_V_U_R1 = 32;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int STATE_V_D_R1 = 16;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int STATE_D_UL_R1 = 8;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int STATE_D_UR_R1 = 4;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int STATE_D_DL_R1 = 2;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int STATE_D_DR_R1 = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int STATE_SIG_R2 = -2147483648;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int STATE_VISITED_R2 = 1073741824;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int STATE_NZ_CTXT_R2 = 536870912;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int STATE_H_L_SIGN_R2 = 268435456;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int STATE_H_R_SIGN_R2 = 134217728;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int STATE_V_U_SIGN_R2 = 67108864;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int STATE_V_D_SIGN_R2 = 33554432;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int STATE_PREV_MR_R2 = 16777216;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int STATE_H_L_R2 = 8388608;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int STATE_H_R_R2 = 4194304;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int STATE_V_U_R2 = 2097152;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int STATE_V_D_R2 = 1048576;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int STATE_D_UL_R2 = 524288;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int STATE_D_UR_R2 = 262144;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int STATE_D_DL_R2 = 131072;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int STATE_D_DR_R2 = 65536;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int SIG_MASK_R1R2 = -2147450880;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int VSTD_MASK_R1R2 = 1073758208;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int RLC_MASK_R1R2 = -536813568;
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int ZC_MASK = 255;
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int SC_SHIFT_R1 = 4;
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int SC_SHIFT_R2 = 20;
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int SC_MASK = 511;
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int MR_MASK = 511;
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int MSE_LKP_BITS = 7;
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int MSE_LKP_FRAC_BITS = 13;
/*      */ 
/*      */ 
/*      */   
/*  528 */   private static final int[] FS_LOSSY = new int[64];
/*      */ 
/*      */ 
/*      */   
/*  532 */   private static final int[] FM_LOSSY = new int[128];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  538 */   private static final int[] FS_LOSSLESS = new int[64];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  545 */   private static final int[] FM_LOSSLESS = new int[128];
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private double[][] distbufT;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int[][] ratebufT;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean[][] istermbufT;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private CBlkWTData[] srcblkT;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int[][] symbufT;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int[][] ctxtbufT;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean[][] precinctPartition;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private class Compressor
/*      */     implements Runnable
/*      */   {
/*      */     private final int idx;
/*      */ 
/*      */ 
/*      */     
/*      */     CBlkRateDistStats ccb;
/*      */ 
/*      */ 
/*      */     
/*      */     int c;
/*      */ 
/*      */ 
/*      */     
/*      */     int options;
/*      */ 
/*      */ 
/*      */     
/*      */     boolean rev;
/*      */ 
/*      */ 
/*      */     
/*      */     int lcType;
/*      */ 
/*      */ 
/*      */     
/*      */     int tType;
/*      */ 
/*      */ 
/*      */     
/*      */     private long[] time;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     Compressor(int idx) {
/*  622 */       this.idx = idx;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void run() {
/*      */       try {
/*  636 */         long stime = 0L;
/*      */         
/*  638 */         StdEntropyCoder.compressCodeBlock(this.c, this.ccb, StdEntropyCoder.this.srcblkT[this.idx], StdEntropyCoder.this.mqT[this.idx], StdEntropyCoder.this.boutT[this.idx], StdEntropyCoder.this.outT[this.idx], StdEntropyCoder.this.stateT[this.idx], StdEntropyCoder.this.distbufT[this.idx], StdEntropyCoder.this.ratebufT[this.idx], StdEntropyCoder.this.istermbufT[this.idx], StdEntropyCoder.this.symbufT[this.idx], StdEntropyCoder.this.ctxtbufT[this.idx], this.options, this.rev, this.lcType, this.tType);
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*      */       finally {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  648 */         StdEntropyCoder.this.completedComps[this.c].push(this);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     synchronized long getTiming(int c) {
/*  667 */       return 0L;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int getIdx() {
/*  677 */       return this.idx;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static {
/*  695 */     ZC_LUT_LH[0] = 2;
/*      */     
/*      */     int i;
/*  698 */     for (i = 1; i < 16; i++) {
/*  699 */       ZC_LUT_LH[i] = 4;
/*      */     }
/*  701 */     for (i = 0; i < 4; i++) {
/*  702 */       ZC_LUT_LH[1 << i] = 3;
/*      */     }
/*      */     
/*  705 */     for (i = 0; i < 16; i++) {
/*      */       
/*  707 */       ZC_LUT_LH[0x20 | i] = 5;
/*  708 */       ZC_LUT_LH[0x10 | i] = 5;
/*      */       
/*  710 */       ZC_LUT_LH[0x30 | i] = 6;
/*      */     } 
/*      */     
/*  713 */     ZC_LUT_LH[128] = 7;
/*  714 */     ZC_LUT_LH[64] = 7;
/*      */ 
/*      */     
/*  717 */     for (i = 1; i < 16; i++) {
/*  718 */       ZC_LUT_LH[0x80 | i] = 8;
/*  719 */       ZC_LUT_LH[0x40 | i] = 8;
/*      */     } 
/*      */ 
/*      */     
/*  723 */     for (i = 1; i < 4; i++) {
/*  724 */       for (int k = 0; k < 16; k++) {
/*  725 */         ZC_LUT_LH[0x80 | i << 4 | k] = 9;
/*  726 */         ZC_LUT_LH[0x40 | i << 4 | k] = 9;
/*      */       } 
/*      */     } 
/*      */     
/*  730 */     for (i = 0; i < 64; i++) {
/*  731 */       ZC_LUT_LH[0xC0 | i] = 10;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  737 */     ZC_LUT_HL[0] = 2;
/*      */     
/*  739 */     for (i = 1; i < 16; i++) {
/*  740 */       ZC_LUT_HL[i] = 4;
/*      */     }
/*  742 */     for (i = 0; i < 4; i++) {
/*  743 */       ZC_LUT_HL[1 << i] = 3;
/*      */     }
/*      */     
/*  746 */     for (i = 0; i < 16; i++) {
/*      */       
/*  748 */       ZC_LUT_HL[0x80 | i] = 5;
/*  749 */       ZC_LUT_HL[0x40 | i] = 5;
/*      */       
/*  751 */       ZC_LUT_HL[0xC0 | i] = 6;
/*      */     } 
/*      */     
/*  754 */     ZC_LUT_HL[32] = 7;
/*  755 */     ZC_LUT_HL[16] = 7;
/*      */ 
/*      */     
/*  758 */     for (i = 1; i < 16; i++) {
/*  759 */       ZC_LUT_HL[0x20 | i] = 8;
/*  760 */       ZC_LUT_HL[0x10 | i] = 8;
/*      */     } 
/*      */ 
/*      */     
/*  764 */     for (i = 1; i < 4; i++) {
/*  765 */       for (int k = 0; k < 16; k++) {
/*  766 */         ZC_LUT_HL[i << 6 | 0x20 | k] = 9;
/*  767 */         ZC_LUT_HL[i << 6 | 0x10 | k] = 9;
/*      */       } 
/*      */     } 
/*      */     
/*  771 */     for (i = 0; i < 4; i++) {
/*  772 */       for (int k = 0; k < 16; k++) {
/*  773 */         ZC_LUT_HL[i << 6 | 0x20 | 0x10 | k] = 10;
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  778 */     int[] twoBits = { 3, 5, 6, 9, 10, 12 };
/*      */ 
/*      */     
/*  781 */     int[] oneBit = { 1, 2, 4, 8 };
/*      */ 
/*      */     
/*  784 */     int[] twoLeast = { 3, 5, 6, 7, 9, 10, 11, 12, 13, 14, 15 };
/*      */ 
/*      */ 
/*      */     
/*  788 */     int[] threeLeast = { 7, 11, 13, 14, 15 };
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  793 */     ZC_LUT_HH[0] = 2;
/*      */ 
/*      */     
/*  796 */     for (i = 0; i < oneBit.length; i++) {
/*  797 */       ZC_LUT_HH[oneBit[i] << 4] = 3;
/*      */     }
/*      */     
/*  800 */     for (i = 0; i < twoLeast.length; i++) {
/*  801 */       ZC_LUT_HH[twoLeast[i] << 4] = 4;
/*      */     }
/*      */     
/*  804 */     for (i = 0; i < oneBit.length; i++) {
/*  805 */       ZC_LUT_HH[oneBit[i]] = 5;
/*      */     }
/*      */     
/*  808 */     for (i = 0; i < oneBit.length; i++) {
/*  809 */       for (int k = 0; k < oneBit.length; k++) {
/*  810 */         ZC_LUT_HH[oneBit[i] << 4 | oneBit[k]] = 6;
/*      */       }
/*      */     } 
/*  813 */     for (i = 0; i < twoLeast.length; i++) {
/*  814 */       for (int k = 0; k < oneBit.length; k++) {
/*  815 */         ZC_LUT_HH[twoLeast[i] << 4 | oneBit[k]] = 7;
/*      */       }
/*      */     } 
/*  818 */     for (i = 0; i < twoBits.length; i++) {
/*  819 */       ZC_LUT_HH[twoBits[i]] = 8;
/*      */     }
/*      */     int j;
/*  822 */     for (j = 0; j < twoBits.length; j++) {
/*  823 */       for (i = 1; i < 16; i++) {
/*  824 */         ZC_LUT_HH[i << 4 | twoBits[j]] = 9;
/*      */       }
/*      */     } 
/*  827 */     for (i = 0; i < 16; i++) {
/*  828 */       for (j = 0; j < threeLeast.length; j++) {
/*  829 */         ZC_LUT_HH[i << 4 | threeLeast[j]] = 10;
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  837 */     int[] inter_sc_lut = new int[36];
/*  838 */     inter_sc_lut[18] = 15;
/*  839 */     inter_sc_lut[17] = 14;
/*  840 */     inter_sc_lut[16] = 13;
/*  841 */     inter_sc_lut[10] = 12;
/*  842 */     inter_sc_lut[9] = 11;
/*  843 */     inter_sc_lut[8] = -2147483636;
/*  844 */     inter_sc_lut[2] = -2147483635;
/*  845 */     inter_sc_lut[1] = -2147483634;
/*  846 */     inter_sc_lut[0] = -2147483633;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  855 */     for (i = 0; i < 511; i++) {
/*  856 */       int ds = i & 0x1;
/*  857 */       int us = i >> 1 & 0x1;
/*  858 */       int rs = i >> 2 & 0x1;
/*  859 */       int ls = i >> 3 & 0x1;
/*  860 */       int dsgn = i >> 5 & 0x1;
/*  861 */       int usgn = i >> 6 & 0x1;
/*  862 */       int rsgn = i >> 7 & 0x1;
/*  863 */       int lsgn = i >> 8 & 0x1;
/*      */       
/*  865 */       int h = ls * (1 - 2 * lsgn) + rs * (1 - 2 * rsgn);
/*  866 */       h = (h >= -1) ? h : -1;
/*  867 */       h = (h <= 1) ? h : 1;
/*  868 */       int v = us * (1 - 2 * usgn) + ds * (1 - 2 * dsgn);
/*  869 */       v = (v >= -1) ? v : -1;
/*  870 */       v = (v <= 1) ? v : 1;
/*      */       
/*  872 */       SC_LUT[i] = inter_sc_lut[h + 1 << 3 | v + 1];
/*      */     } 
/*  874 */     inter_sc_lut = null;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  879 */     MR_LUT[0] = 16;
/*      */     
/*  881 */     for (i = 1; i < 256; i++) {
/*  882 */       MR_LUT[i] = 17;
/*      */     }
/*      */     
/*  885 */     for (; i < 512; i++) {
/*  886 */       MR_LUT[i] = 18;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  892 */     for (i = 0; i < 64; i++) {
/*      */       
/*  894 */       double val = i / 64.0D + 1.0D;
/*  895 */       double deltaMSE = val * val;
/*  896 */       FS_LOSSLESS[i] = (int)Math.floor(deltaMSE * 8192.0D + 0.5D);
/*      */ 
/*      */       
/*  899 */       val -= 1.5D;
/*  900 */       deltaMSE -= val * val;
/*  901 */       FS_LOSSY[i] = (int)Math.floor(deltaMSE * 8192.0D + 0.5D);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  907 */     for (i = 0; i < 128; i++) {
/*  908 */       double val = i / 64.0D;
/*  909 */       double deltaMSE = (val - 1.0D) * (val - 1.0D);
/*  910 */       FM_LOSSLESS[i] = (int)Math.floor(deltaMSE * 8192.0D + 0.5D);
/*      */ 
/*      */       
/*  913 */       val -= (i < 64) ? 0.5D : 1.5D;
/*  914 */       deltaMSE -= val * val;
/*  915 */       FM_LOSSY[i] = (int)Math.floor(deltaMSE * 8192.0D + 0.5D);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StdEntropyCoder(CBlkQuantDataSrcEnc src, CBlkSizeSpec cblks, PrecinctSizeSpec pss, StringSpec bms, StringSpec mqrs, StringSpec rts, StringSpec css, StringSpec sss, StringSpec lcs, StringSpec tts) {
/*  955 */     super(src); int j, tsl; this.opts = (int[][])null; this.lenCalc = (int[][])null; this.tType = (int[][])null;
/*  956 */     this.cblks = cblks;
/*  957 */     this.pss = pss;
/*  958 */     this.bms = bms;
/*  959 */     this.mqrs = mqrs;
/*  960 */     this.rts = rts;
/*  961 */     this.css = css;
/*  962 */     this.sss = sss;
/*  963 */     this.lcs = lcs;
/*  964 */     this.tts = tts;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  971 */     int maxCBlkWidth = cblks.getMaxCBlkWidth();
/*  972 */     int maxCBlkHeight = cblks.getMaxCBlkHeight();
/*      */ 
/*      */     
/*      */     try {
/*      */       try {
/*  977 */         j = Integer.parseInt(System.getProperty("jj2000.j2k.entropy.encoder.StdEntropyCoder.nthreads", "0"));
/*      */       }
/*  979 */       catch (SecurityException se) {
/*      */         
/*  981 */         j = Integer.parseInt("0");
/*      */       } 
/*  983 */       if (j < 0) throw new NumberFormatException(); 
/*  984 */     } catch (NumberFormatException e) {
/*  985 */       throw new IllegalArgumentException("Invalid number of threads for entropy coding in property jj2000.j2k.entropy.encoder.StdEntropyCoder.nthreads");
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  999 */     if (j > 0) {
/* 1000 */       FacilityManager.getMsgLogger().printmsg(1, "Using multithreaded entropy coder with " + j + " compressor threads.");
/*      */ 
/*      */ 
/*      */       
/* 1004 */       tsl = j;
/* 1005 */       this.tPool = new ThreadPool(j, Thread.currentThread().getPriority() + 0, "StdEntropyCoder");
/*      */       
/* 1007 */       this.idleComps = new Stack();
/* 1008 */       this.completedComps = new Stack[src.getNumComps()];
/* 1009 */       this.nBusyComps = new int[src.getNumComps()];
/* 1010 */       this.finishedTileComponent = new boolean[src.getNumComps()]; int k;
/* 1011 */       for (k = src.getNumComps() - 1; k >= 0; k--) {
/* 1012 */         this.completedComps[k] = new Stack();
/*      */       }
/* 1014 */       for (k = 0; k < j; k++) {
/* 1015 */         this.idleComps.push(new Compressor(k));
/*      */       }
/*      */     } else {
/*      */       
/* 1019 */       tsl = 1;
/* 1020 */       this.tPool = null;
/* 1021 */       this.idleComps = null;
/* 1022 */       this.completedComps = null;
/* 1023 */       this.nBusyComps = null;
/* 1024 */       this.finishedTileComponent = null;
/*      */     } 
/*      */ 
/*      */     
/* 1028 */     this.outT = new ByteOutputBuffer[tsl];
/* 1029 */     this.mqT = new MQCoder[tsl];
/* 1030 */     this.boutT = new BitToByteOutput[tsl];
/* 1031 */     this.stateT = new int[tsl][(maxCBlkWidth + 2) * ((maxCBlkHeight + 1) / 2 + 2)];
/* 1032 */     this.symbufT = new int[tsl][maxCBlkWidth * 10];
/* 1033 */     this.ctxtbufT = new int[tsl][maxCBlkWidth * 10];
/* 1034 */     this.distbufT = new double[tsl][96];
/* 1035 */     this.ratebufT = new int[tsl][96];
/* 1036 */     this.istermbufT = new boolean[tsl][96];
/* 1037 */     this.srcblkT = new CBlkWTData[tsl];
/* 1038 */     for (int i = 0; i < tsl; i++) {
/* 1039 */       this.outT[i] = new ByteOutputBuffer();
/* 1040 */       this.mqT[i] = new MQCoder(this.outT[i], 19, MQ_INIT);
/*      */     } 
/* 1042 */     this.precinctPartition = new boolean[src.getNumComps()][src.getNumTiles()];
/*      */ 
/*      */     
/* 1045 */     Point numTiles = src.getNumTiles(null);
/*      */     
/* 1047 */     int nc = getNumComps();
/* 1048 */     initTileComp(getNumTiles(), nc);
/*      */     
/* 1050 */     for (int c = 0; c < nc; c++) {
/* 1051 */       for (int tY = 0; tY < numTiles.y; tY++) {
/* 1052 */         for (int tX = 0; tX < numTiles.x; tX++) {
/* 1053 */           this.precinctPartition[c][this.tIdx] = false;
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void finalize() throws Throwable {
/* 1113 */     super.finalize();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getCBlkWidth(int t, int c) {
/* 1126 */     return this.cblks.getCBlkWidth((byte)3, t, c);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getCBlkHeight(int t, int c) {
/* 1139 */     return this.cblks.getCBlkHeight((byte)3, t, c);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CBlkRateDistStats getNextCodeBlock(int c, CBlkRateDistStats ccb) {
/* 1173 */     long stime = 0L;
/* 1174 */     if (this.tPool == null) {
/*      */       
/* 1176 */       this.srcblkT[0] = this.src.getNextInternCodeBlock(c, this.srcblkT[0]);
/*      */ 
/*      */       
/* 1179 */       if (this.srcblkT[0] == null) {
/* 1180 */         return null;
/*      */       }
/*      */       
/* 1183 */       if ((this.opts[this.tIdx][c] & 0x1) != 0 && this.boutT[0] == null) {
/* 1184 */         this.boutT[0] = new BitToByteOutput(this.outT[0]);
/*      */       }
/*      */       
/* 1187 */       if (ccb == null) {
/* 1188 */         ccb = new CBlkRateDistStats();
/*      */       }
/*      */       
/* 1191 */       compressCodeBlock(c, ccb, this.srcblkT[0], this.mqT[0], this.boutT[0], this.outT[0], this.stateT[0], this.distbufT[0], this.ratebufT[0], this.istermbufT[0], this.symbufT[0], this.ctxtbufT[0], this.opts[this.tIdx][c], isReversible(this.tIdx, c), this.lenCalc[this.tIdx][c], this.tType[this.tIdx][c]);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1198 */       return ccb;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1206 */     while (!this.finishedTileComponent[c] && !this.idleComps.empty()) {
/*      */       
/* 1208 */       Compressor compr = this.idleComps.pop();
/* 1209 */       int cIdx = compr.getIdx();
/*      */ 
/*      */       
/* 1212 */       this.srcblkT[cIdx] = this.src.getNextInternCodeBlock(c, this.srcblkT[cIdx]);
/*      */       
/* 1214 */       if (this.srcblkT[cIdx] != null) {
/*      */         
/* 1216 */         if ((this.opts[this.tIdx][c] & 0x1) != 0 && this.boutT[cIdx] == null) {
/* 1217 */           this.boutT[cIdx] = new BitToByteOutput(this.outT[cIdx]);
/*      */         }
/*      */         
/* 1220 */         if (ccb == null) ccb = new CBlkRateDistStats(); 
/* 1221 */         compr.ccb = ccb;
/* 1222 */         compr.c = c;
/* 1223 */         compr.options = this.opts[this.tIdx][c];
/* 1224 */         compr.rev = isReversible(this.tIdx, c);
/* 1225 */         compr.lcType = this.lenCalc[this.tIdx][c];
/* 1226 */         compr.tType = this.tType[this.tIdx][c];
/* 1227 */         this.nBusyComps[c] = this.nBusyComps[c] + 1;
/* 1228 */         ccb = null;
/*      */         
/* 1230 */         this.tPool.runTarget(compr, this.completedComps[c]);
/*      */         
/*      */         continue;
/*      */       } 
/*      */       
/* 1235 */       this.idleComps.push(compr);
/* 1236 */       this.finishedTileComponent[c] = true;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1241 */     if (this.nBusyComps[c] > 0) {
/* 1242 */       synchronized (this.completedComps[c]) {
/*      */         
/* 1244 */         if (this.completedComps[c].empty()) {
/*      */           
/*      */           try {
/*      */ 
/*      */             
/* 1249 */             this.completedComps[c].wait();
/*      */ 
/*      */           
/*      */           }
/* 1253 */           catch (InterruptedException e) {}
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 1258 */         Compressor compr = this.completedComps[c].pop();
/* 1259 */         int cIdx = compr.getIdx();
/* 1260 */         this.nBusyComps[c] = this.nBusyComps[c] - 1;
/* 1261 */         this.idleComps.push(compr);
/*      */         
/* 1263 */         this.tPool.checkTargetErrors();
/*      */ 
/*      */         
/* 1266 */         return compr.ccb;
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/* 1271 */     this.tPool.checkTargetErrors();
/*      */ 
/*      */ 
/*      */     
/* 1275 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTile(int x, int y) {
/* 1293 */     super.setTile(x, y);
/*      */     
/* 1295 */     if (this.finishedTileComponent != null) {
/* 1296 */       for (int c = this.src.getNumComps() - 1; c >= 0; c--) {
/* 1297 */         this.finishedTileComponent[c] = false;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void nextTile() {
/* 1312 */     if (this.finishedTileComponent != null) {
/* 1313 */       for (int c = this.src.getNumComps() - 1; c >= 0; c--) {
/* 1314 */         this.finishedTileComponent[c] = false;
/*      */       }
/*      */     }
/* 1317 */     super.nextTile();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void compressCodeBlock(int c, CBlkRateDistStats ccb, CBlkWTData srcblk, MQCoder mq, BitToByteOutput bout, ByteOutputBuffer out, int[] state, double[] distbuf, int[] ratebuf, boolean[] istermbuf, int[] symbuf, int[] ctxtbuf, int options, boolean rev, int lcType, int tType) {
/*      */     int[] zc_lut;
/* 1394 */     if ((options & 0x10) != 0 && tType != 3) {
/* 1395 */       throw new IllegalArgumentException("Embedded error-resilient info in MQ termination option specified but incorrect MQ termination policy specified");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1403 */     mq.setLenCalcType(lcType);
/* 1404 */     mq.setTermType(tType);
/*      */     
/* 1406 */     int lmb = 30 - srcblk.magbits + 1;
/*      */ 
/*      */     
/* 1409 */     lmb = (lmb < 0) ? 0 : lmb;
/*      */ 
/*      */     
/* 1412 */     ArrayUtil.intArraySet(state, 0);
/*      */ 
/*      */     
/* 1415 */     int skipbp = calcSkipMSBP(srcblk, lmb);
/*      */ 
/*      */     
/* 1418 */     ccb.m = srcblk.m;
/* 1419 */     ccb.n = srcblk.n;
/* 1420 */     ccb.sb = srcblk.sb;
/* 1421 */     ccb.nROIcoeff = srcblk.nROIcoeff;
/* 1422 */     ccb.skipMSBP = skipbp;
/* 1423 */     if (ccb.nROIcoeff != 0) {
/* 1424 */       ccb.nROIcp = 3 * (srcblk.nROIbp - skipbp - 1) + 1;
/*      */     } else {
/* 1426 */       ccb.nROIcp = 0;
/*      */     } 
/*      */ 
/*      */     
/* 1430 */     switch (srcblk.sb.orientation) {
/*      */       case 1:
/* 1432 */         zc_lut = ZC_LUT_HL;
/*      */         break;
/*      */       case 0:
/*      */       case 2:
/* 1436 */         zc_lut = ZC_LUT_LH;
/*      */         break;
/*      */       case 3:
/* 1439 */         zc_lut = ZC_LUT_HH;
/*      */         break;
/*      */       default:
/* 1442 */         throw new Error("JJ2000 internal error");
/*      */     } 
/*      */ 
/*      */     
/* 1446 */     int curbp = 30 - skipbp;
/* 1447 */     int[] fs = FS_LOSSLESS;
/* 1448 */     int[] fm = FM_LOSSLESS;
/* 1449 */     double msew = Math.pow(2.0D, ((curbp - lmb << 1) - 13)) * srcblk.sb.stepWMSE * srcblk.wmseScaling;
/*      */     
/* 1451 */     double totdist = 0.0D;
/* 1452 */     int npass = 0;
/* 1453 */     int ltpidx = -1;
/*      */     
/* 1455 */     if (curbp >= lmb) {
/*      */       
/* 1457 */       if (rev && curbp == lmb) {
/* 1458 */         fs = FM_LOSSLESS;
/*      */       }
/*      */ 
/*      */       
/* 1462 */       istermbuf[npass] = ((options & 0x4) != 0 || curbp == lmb || ((options & 0x1) != 0 && 27 - skipbp >= curbp));
/*      */ 
/*      */       
/* 1465 */       totdist += cleanuppass(srcblk, mq, istermbuf[npass], curbp, state, fs, zc_lut, symbuf, ctxtbuf, ratebuf, npass, ltpidx, options) * msew;
/*      */ 
/*      */       
/* 1468 */       distbuf[npass] = totdist;
/* 1469 */       if (istermbuf[npass]) ltpidx = npass; 
/* 1470 */       npass++;
/* 1471 */       msew *= 0.25D;
/* 1472 */       curbp--;
/*      */     } 
/*      */     
/* 1475 */     while (curbp >= lmb) {
/*      */       
/* 1477 */       if (rev && curbp == lmb) {
/* 1478 */         fs = FS_LOSSLESS;
/* 1479 */         fm = FM_LOSSLESS;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1484 */       istermbuf[npass] = ((options & 0x4) != 0);
/* 1485 */       if ((options & 0x1) == 0 || 27 - skipbp <= curbp) {
/*      */         
/* 1487 */         totdist += sigProgPass(srcblk, mq, istermbuf[npass], curbp, state, fs, zc_lut, symbuf, ctxtbuf, ratebuf, npass, ltpidx, options) * msew;
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */         
/* 1493 */         bout.setPredTerm(((options & 0x10) != 0));
/* 1494 */         totdist += rawSigProgPass(srcblk, bout, istermbuf[npass], curbp, state, fs, ratebuf, npass, ltpidx, options) * msew;
/*      */       } 
/*      */ 
/*      */       
/* 1498 */       distbuf[npass] = totdist;
/* 1499 */       if (istermbuf[npass]) ltpidx = npass; 
/* 1500 */       npass++;
/*      */ 
/*      */ 
/*      */       
/* 1504 */       istermbuf[npass] = ((options & 0x4) != 0 || ((options & 0x1) != 0 && 27 - skipbp > curbp));
/*      */ 
/*      */       
/* 1507 */       if ((options & 0x1) == 0 || 27 - skipbp <= curbp) {
/*      */         
/* 1509 */         totdist += magRefPass(srcblk, mq, istermbuf[npass], curbp, state, fm, symbuf, ctxtbuf, ratebuf, npass, ltpidx, options) * msew;
/*      */       
/*      */       }
/*      */       else {
/*      */         
/* 1514 */         bout.setPredTerm(((options & 0x10) != 0));
/* 1515 */         totdist += rawMagRefPass(srcblk, bout, istermbuf[npass], curbp, state, fm, ratebuf, npass, ltpidx, options) * msew;
/*      */       } 
/*      */ 
/*      */       
/* 1519 */       distbuf[npass] = totdist;
/* 1520 */       if (istermbuf[npass]) ltpidx = npass; 
/* 1521 */       npass++;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1526 */       istermbuf[npass] = ((options & 0x4) != 0 || curbp == lmb || ((options & 0x1) != 0 && 27 - skipbp >= curbp));
/*      */ 
/*      */       
/* 1529 */       totdist += cleanuppass(srcblk, mq, istermbuf[npass], curbp, state, fs, zc_lut, symbuf, ctxtbuf, ratebuf, npass, ltpidx, options) * msew;
/*      */ 
/*      */       
/* 1532 */       distbuf[npass] = totdist;
/* 1533 */       if (istermbuf[npass]) ltpidx = npass; 
/* 1534 */       npass++;
/*      */ 
/*      */       
/* 1537 */       msew *= 0.25D;
/* 1538 */       curbp--;
/*      */     } 
/*      */ 
/*      */     
/* 1542 */     ccb.data = new byte[out.size()];
/* 1543 */     out.toByteArray(0, out.size(), ccb.data, 0);
/* 1544 */     checkEndOfPassFF(ccb.data, ratebuf, istermbuf, npass);
/* 1545 */     ccb.selectConvexHull(ratebuf, distbuf, ((options & 0x5) != 0) ? istermbuf : null, npass, rev);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1550 */     mq.reset();
/* 1551 */     if (bout != null) bout.reset();
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int calcSkipMSBP(CBlkWTData cblk, int lmb) {
/* 1577 */     int[] data = (int[])cblk.getData();
/* 1578 */     int w = cblk.w;
/* 1579 */     int h = cblk.h;
/*      */ 
/*      */     
/* 1582 */     int maxmag = 0;
/*      */     
/* 1584 */     int mask = Integer.MAX_VALUE & ((1 << lmb) - 1 ^ 0xFFFFFFFF);
/* 1585 */     for (int l = h - 1, k = cblk.offset; l >= 0; l--) {
/* 1586 */       for (int kmax = k + w; k < kmax; k++) {
/* 1587 */         int mag = data[k] & mask;
/* 1588 */         if (mag > maxmag) maxmag = mag; 
/*      */       } 
/* 1590 */       k += cblk.scanw - w;
/*      */     } 
/*      */ 
/*      */     
/* 1594 */     int msbp = 30;
/*      */     
/*      */     do {
/* 1597 */       msbp--;
/* 1598 */     } while ((1 << msbp & maxmag) == 0 && msbp >= lmb);
/*      */ 
/*      */     
/* 1601 */     return 30 - msbp;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int sigProgPass(CBlkWTData srcblk, MQCoder mq, boolean doterm, int bp, int[] state, int[] fs, int[] zc_lut, int[] symbuf, int[] ctxtbuf, int[] ratebuf, int pidx, int ltpidx, int options) {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield scanw : I
/*      */     //   4: istore #18
/*      */     //   6: aload_0
/*      */     //   7: getfield w : I
/*      */     //   10: iconst_2
/*      */     //   11: iadd
/*      */     //   12: istore #19
/*      */     //   14: iload #19
/*      */     //   16: iconst_4
/*      */     //   17: imul
/*      */     //   18: iconst_2
/*      */     //   19: idiv
/*      */     //   20: aload_0
/*      */     //   21: getfield w : I
/*      */     //   24: isub
/*      */     //   25: istore #20
/*      */     //   27: iload #18
/*      */     //   29: iconst_4
/*      */     //   30: imul
/*      */     //   31: aload_0
/*      */     //   32: getfield w : I
/*      */     //   35: isub
/*      */     //   36: istore #21
/*      */     //   38: iconst_1
/*      */     //   39: iload_3
/*      */     //   40: ishl
/*      */     //   41: istore #24
/*      */     //   43: aload_0
/*      */     //   44: invokevirtual getData : ()Ljava/lang/Object;
/*      */     //   47: checkcast [I
/*      */     //   50: checkcast [I
/*      */     //   53: astore #27
/*      */     //   55: aload_0
/*      */     //   56: getfield h : I
/*      */     //   59: iconst_4
/*      */     //   60: iadd
/*      */     //   61: iconst_1
/*      */     //   62: isub
/*      */     //   63: iconst_4
/*      */     //   64: idiv
/*      */     //   65: istore #35
/*      */     //   67: iconst_0
/*      */     //   68: istore #28
/*      */     //   70: iload_3
/*      */     //   71: bipush #6
/*      */     //   73: isub
/*      */     //   74: istore #29
/*      */     //   76: iload #29
/*      */     //   78: iflt -> 85
/*      */     //   81: iconst_0
/*      */     //   82: goto -> 88
/*      */     //   85: iload #29
/*      */     //   87: ineg
/*      */     //   88: istore #30
/*      */     //   90: iload #29
/*      */     //   92: ifgt -> 99
/*      */     //   95: iconst_0
/*      */     //   96: goto -> 101
/*      */     //   99: iload #29
/*      */     //   101: istore #31
/*      */     //   103: iload #12
/*      */     //   105: bipush #8
/*      */     //   107: iand
/*      */     //   108: ifeq -> 115
/*      */     //   111: iconst_1
/*      */     //   112: goto -> 116
/*      */     //   115: iconst_0
/*      */     //   116: istore #34
/*      */     //   118: iload #19
/*      */     //   120: ineg
/*      */     //   121: iconst_1
/*      */     //   122: isub
/*      */     //   123: istore #37
/*      */     //   125: iload #19
/*      */     //   127: ineg
/*      */     //   128: iconst_1
/*      */     //   129: iadd
/*      */     //   130: istore #38
/*      */     //   132: iload #19
/*      */     //   134: iconst_1
/*      */     //   135: iadd
/*      */     //   136: istore #39
/*      */     //   138: iload #19
/*      */     //   140: iconst_1
/*      */     //   141: isub
/*      */     //   142: istore #40
/*      */     //   144: aload_0
/*      */     //   145: getfield offset : I
/*      */     //   148: istore #16
/*      */     //   150: iload #19
/*      */     //   152: iconst_1
/*      */     //   153: iadd
/*      */     //   154: istore #14
/*      */     //   156: iload #35
/*      */     //   158: iconst_1
/*      */     //   159: isub
/*      */     //   160: istore #33
/*      */     //   162: iload #33
/*      */     //   164: iflt -> 1435
/*      */     //   167: iload #33
/*      */     //   169: ifeq -> 176
/*      */     //   172: iconst_4
/*      */     //   173: goto -> 187
/*      */     //   176: aload_0
/*      */     //   177: getfield h : I
/*      */     //   180: iload #35
/*      */     //   182: iconst_1
/*      */     //   183: isub
/*      */     //   184: iconst_4
/*      */     //   185: imul
/*      */     //   186: isub
/*      */     //   187: istore #36
/*      */     //   189: iload #16
/*      */     //   191: aload_0
/*      */     //   192: getfield w : I
/*      */     //   195: iadd
/*      */     //   196: istore #22
/*      */     //   198: iconst_0
/*      */     //   199: istore #17
/*      */     //   201: iload #16
/*      */     //   203: iload #22
/*      */     //   205: if_icmpge -> 1405
/*      */     //   208: iload #14
/*      */     //   210: istore #13
/*      */     //   212: aload #4
/*      */     //   214: iload #13
/*      */     //   216: iaload
/*      */     //   217: istore #23
/*      */     //   219: iload #23
/*      */     //   221: iconst_m1
/*      */     //   222: ixor
/*      */     //   223: iload #23
/*      */     //   225: iconst_2
/*      */     //   226: ishl
/*      */     //   227: iand
/*      */     //   228: ldc -2147450880
/*      */     //   230: iand
/*      */     //   231: ifeq -> 801
/*      */     //   234: iload #16
/*      */     //   236: istore #15
/*      */     //   238: iload #23
/*      */     //   240: ldc 40960
/*      */     //   242: iand
/*      */     //   243: sipush #8192
/*      */     //   246: if_icmpne -> 509
/*      */     //   249: aload #8
/*      */     //   251: iload #17
/*      */     //   253: aload #6
/*      */     //   255: iload #23
/*      */     //   257: sipush #255
/*      */     //   260: iand
/*      */     //   261: iaload
/*      */     //   262: iastore
/*      */     //   263: aload #7
/*      */     //   265: iload #17
/*      */     //   267: iinc #17, 1
/*      */     //   270: aload #27
/*      */     //   272: iload #15
/*      */     //   274: iaload
/*      */     //   275: iload #24
/*      */     //   277: iand
/*      */     //   278: iload_3
/*      */     //   279: iushr
/*      */     //   280: dup_x2
/*      */     //   281: iastore
/*      */     //   282: ifeq -> 501
/*      */     //   285: aload #27
/*      */     //   287: iload #15
/*      */     //   289: iaload
/*      */     //   290: bipush #31
/*      */     //   292: iushr
/*      */     //   293: istore #25
/*      */     //   295: getstatic jj2000/j2k/entropy/encoder/StdEntropyCoder.SC_LUT : [I
/*      */     //   298: iload #23
/*      */     //   300: iconst_4
/*      */     //   301: iushr
/*      */     //   302: sipush #511
/*      */     //   305: iand
/*      */     //   306: iaload
/*      */     //   307: istore #26
/*      */     //   309: aload #7
/*      */     //   311: iload #17
/*      */     //   313: iload #25
/*      */     //   315: iload #26
/*      */     //   317: bipush #31
/*      */     //   319: iushr
/*      */     //   320: ixor
/*      */     //   321: iastore
/*      */     //   322: aload #8
/*      */     //   324: iload #17
/*      */     //   326: iinc #17, 1
/*      */     //   329: iload #26
/*      */     //   331: bipush #15
/*      */     //   333: iand
/*      */     //   334: iastore
/*      */     //   335: iload #34
/*      */     //   337: ifne -> 366
/*      */     //   340: aload #4
/*      */     //   342: iload #13
/*      */     //   344: iload #37
/*      */     //   346: iadd
/*      */     //   347: dup2
/*      */     //   348: iaload
/*      */     //   349: ldc 536936448
/*      */     //   351: ior
/*      */     //   352: iastore
/*      */     //   353: aload #4
/*      */     //   355: iload #13
/*      */     //   357: iload #38
/*      */     //   359: iadd
/*      */     //   360: dup2
/*      */     //   361: iaload
/*      */     //   362: ldc 537001984
/*      */     //   364: ior
/*      */     //   365: iastore
/*      */     //   366: iload #25
/*      */     //   368: ifeq -> 423
/*      */     //   371: iload #23
/*      */     //   373: ldc 606126080
/*      */     //   375: ior
/*      */     //   376: istore #23
/*      */     //   378: iload #34
/*      */     //   380: ifne -> 396
/*      */     //   383: aload #4
/*      */     //   385: iload #13
/*      */     //   387: iload #19
/*      */     //   389: isub
/*      */     //   390: dup2
/*      */     //   391: iaload
/*      */     //   392: ldc 571473920
/*      */     //   394: ior
/*      */     //   395: iastore
/*      */     //   396: aload #4
/*      */     //   398: iload #13
/*      */     //   400: iconst_1
/*      */     //   401: iadd
/*      */     //   402: dup2
/*      */     //   403: iaload
/*      */     //   404: ldc 537407616
/*      */     //   406: ior
/*      */     //   407: iastore
/*      */     //   408: aload #4
/*      */     //   410: iload #13
/*      */     //   412: iconst_1
/*      */     //   413: isub
/*      */     //   414: dup2
/*      */     //   415: iaload
/*      */     //   416: ldc 537143360
/*      */     //   418: ior
/*      */     //   419: iastore
/*      */     //   420: goto -> 472
/*      */     //   423: iload #23
/*      */     //   425: ldc 539017216
/*      */     //   427: ior
/*      */     //   428: istore #23
/*      */     //   430: iload #34
/*      */     //   432: ifne -> 448
/*      */     //   435: aload #4
/*      */     //   437: iload #13
/*      */     //   439: iload #19
/*      */     //   441: isub
/*      */     //   442: dup2
/*      */     //   443: iaload
/*      */     //   444: ldc 537919488
/*      */     //   446: ior
/*      */     //   447: iastore
/*      */     //   448: aload #4
/*      */     //   450: iload #13
/*      */     //   452: iconst_1
/*      */     //   453: iadd
/*      */     //   454: dup2
/*      */     //   455: iaload
/*      */     //   456: ldc 537403520
/*      */     //   458: ior
/*      */     //   459: iastore
/*      */     //   460: aload #4
/*      */     //   462: iload #13
/*      */     //   464: iconst_1
/*      */     //   465: isub
/*      */     //   466: dup2
/*      */     //   467: iaload
/*      */     //   468: ldc 537141312
/*      */     //   470: ior
/*      */     //   471: iastore
/*      */     //   472: aload #27
/*      */     //   474: iload #15
/*      */     //   476: iaload
/*      */     //   477: iload #31
/*      */     //   479: ishr
/*      */     //   480: iload #30
/*      */     //   482: ishl
/*      */     //   483: istore #32
/*      */     //   485: iload #28
/*      */     //   487: aload #5
/*      */     //   489: iload #32
/*      */     //   491: bipush #63
/*      */     //   493: iand
/*      */     //   494: iaload
/*      */     //   495: iadd
/*      */     //   496: istore #28
/*      */     //   498: goto -> 509
/*      */     //   501: iload #23
/*      */     //   503: sipush #16384
/*      */     //   506: ior
/*      */     //   507: istore #23
/*      */     //   509: iload #36
/*      */     //   511: iconst_2
/*      */     //   512: if_icmpge -> 525
/*      */     //   515: aload #4
/*      */     //   517: iload #13
/*      */     //   519: iload #23
/*      */     //   521: iastore
/*      */     //   522: goto -> 1396
/*      */     //   525: iload #23
/*      */     //   527: ldc -1610612736
/*      */     //   529: iand
/*      */     //   530: ldc 536870912
/*      */     //   532: if_icmpne -> 794
/*      */     //   535: iload #15
/*      */     //   537: iload #18
/*      */     //   539: iadd
/*      */     //   540: istore #15
/*      */     //   542: aload #8
/*      */     //   544: iload #17
/*      */     //   546: aload #6
/*      */     //   548: iload #23
/*      */     //   550: bipush #16
/*      */     //   552: iushr
/*      */     //   553: sipush #255
/*      */     //   556: iand
/*      */     //   557: iaload
/*      */     //   558: iastore
/*      */     //   559: aload #7
/*      */     //   561: iload #17
/*      */     //   563: iinc #17, 1
/*      */     //   566: aload #27
/*      */     //   568: iload #15
/*      */     //   570: iaload
/*      */     //   571: iload #24
/*      */     //   573: iand
/*      */     //   574: iload_3
/*      */     //   575: iushr
/*      */     //   576: dup_x2
/*      */     //   577: iastore
/*      */     //   578: ifeq -> 787
/*      */     //   581: aload #27
/*      */     //   583: iload #15
/*      */     //   585: iaload
/*      */     //   586: bipush #31
/*      */     //   588: iushr
/*      */     //   589: istore #25
/*      */     //   591: getstatic jj2000/j2k/entropy/encoder/StdEntropyCoder.SC_LUT : [I
/*      */     //   594: iload #23
/*      */     //   596: bipush #20
/*      */     //   598: iushr
/*      */     //   599: sipush #511
/*      */     //   602: iand
/*      */     //   603: iaload
/*      */     //   604: istore #26
/*      */     //   606: aload #7
/*      */     //   608: iload #17
/*      */     //   610: iload #25
/*      */     //   612: iload #26
/*      */     //   614: bipush #31
/*      */     //   616: iushr
/*      */     //   617: ixor
/*      */     //   618: iastore
/*      */     //   619: aload #8
/*      */     //   621: iload #17
/*      */     //   623: iinc #17, 1
/*      */     //   626: iload #26
/*      */     //   628: bipush #15
/*      */     //   630: iand
/*      */     //   631: iastore
/*      */     //   632: aload #4
/*      */     //   634: iload #13
/*      */     //   636: iload #40
/*      */     //   638: iadd
/*      */     //   639: dup2
/*      */     //   640: iaload
/*      */     //   641: sipush #8196
/*      */     //   644: ior
/*      */     //   645: iastore
/*      */     //   646: aload #4
/*      */     //   648: iload #13
/*      */     //   650: iload #39
/*      */     //   652: iadd
/*      */     //   653: dup2
/*      */     //   654: iaload
/*      */     //   655: sipush #8200
/*      */     //   658: ior
/*      */     //   659: iastore
/*      */     //   660: iload #25
/*      */     //   662: ifeq -> 713
/*      */     //   665: iload #23
/*      */     //   667: ldc -1073733104
/*      */     //   669: ior
/*      */     //   670: istore #23
/*      */     //   672: aload #4
/*      */     //   674: iload #13
/*      */     //   676: iload #19
/*      */     //   678: iadd
/*      */     //   679: dup2
/*      */     //   680: iaload
/*      */     //   681: sipush #9248
/*      */     //   684: ior
/*      */     //   685: iastore
/*      */     //   686: aload #4
/*      */     //   688: iload #13
/*      */     //   690: iconst_1
/*      */     //   691: iadd
/*      */     //   692: dup2
/*      */     //   693: iaload
/*      */     //   694: ldc 813703170
/*      */     //   696: ior
/*      */     //   697: iastore
/*      */     //   698: aload #4
/*      */     //   700: iload #13
/*      */     //   702: iconst_1
/*      */     //   703: isub
/*      */     //   704: dup2
/*      */     //   705: iaload
/*      */     //   706: ldc 675291137
/*      */     //   708: ior
/*      */     //   709: iastore
/*      */     //   710: goto -> 758
/*      */     //   713: iload #23
/*      */     //   715: ldc -1073733616
/*      */     //   717: ior
/*      */     //   718: istore #23
/*      */     //   720: aload #4
/*      */     //   722: iload #13
/*      */     //   724: iload #19
/*      */     //   726: iadd
/*      */     //   727: dup2
/*      */     //   728: iaload
/*      */     //   729: sipush #8224
/*      */     //   732: ior
/*      */     //   733: iastore
/*      */     //   734: aload #4
/*      */     //   736: iload #13
/*      */     //   738: iconst_1
/*      */     //   739: iadd
/*      */     //   740: dup2
/*      */     //   741: iaload
/*      */     //   742: ldc 545267714
/*      */     //   744: ior
/*      */     //   745: iastore
/*      */     //   746: aload #4
/*      */     //   748: iload #13
/*      */     //   750: iconst_1
/*      */     //   751: isub
/*      */     //   752: dup2
/*      */     //   753: iaload
/*      */     //   754: ldc 541073409
/*      */     //   756: ior
/*      */     //   757: iastore
/*      */     //   758: aload #27
/*      */     //   760: iload #15
/*      */     //   762: iaload
/*      */     //   763: iload #31
/*      */     //   765: ishr
/*      */     //   766: iload #30
/*      */     //   768: ishl
/*      */     //   769: istore #32
/*      */     //   771: iload #28
/*      */     //   773: aload #5
/*      */     //   775: iload #32
/*      */     //   777: bipush #63
/*      */     //   779: iand
/*      */     //   780: iaload
/*      */     //   781: iadd
/*      */     //   782: istore #28
/*      */     //   784: goto -> 794
/*      */     //   787: iload #23
/*      */     //   789: ldc 1073741824
/*      */     //   791: ior
/*      */     //   792: istore #23
/*      */     //   794: aload #4
/*      */     //   796: iload #13
/*      */     //   798: iload #23
/*      */     //   800: iastore
/*      */     //   801: iload #36
/*      */     //   803: iconst_3
/*      */     //   804: if_icmpge -> 810
/*      */     //   807: goto -> 1396
/*      */     //   810: iload #13
/*      */     //   812: iload #19
/*      */     //   814: iadd
/*      */     //   815: istore #13
/*      */     //   817: aload #4
/*      */     //   819: iload #13
/*      */     //   821: iaload
/*      */     //   822: istore #23
/*      */     //   824: iload #23
/*      */     //   826: iconst_m1
/*      */     //   827: ixor
/*      */     //   828: iload #23
/*      */     //   830: iconst_2
/*      */     //   831: ishl
/*      */     //   832: iand
/*      */     //   833: ldc -2147450880
/*      */     //   835: iand
/*      */     //   836: ifeq -> 1396
/*      */     //   839: iload #16
/*      */     //   841: iload #18
/*      */     //   843: iconst_1
/*      */     //   844: ishl
/*      */     //   845: iadd
/*      */     //   846: istore #15
/*      */     //   848: iload #23
/*      */     //   850: ldc 40960
/*      */     //   852: iand
/*      */     //   853: sipush #8192
/*      */     //   856: if_icmpne -> 1104
/*      */     //   859: aload #8
/*      */     //   861: iload #17
/*      */     //   863: aload #6
/*      */     //   865: iload #23
/*      */     //   867: sipush #255
/*      */     //   870: iand
/*      */     //   871: iaload
/*      */     //   872: iastore
/*      */     //   873: aload #7
/*      */     //   875: iload #17
/*      */     //   877: iinc #17, 1
/*      */     //   880: aload #27
/*      */     //   882: iload #15
/*      */     //   884: iaload
/*      */     //   885: iload #24
/*      */     //   887: iand
/*      */     //   888: iload_3
/*      */     //   889: iushr
/*      */     //   890: dup_x2
/*      */     //   891: iastore
/*      */     //   892: ifeq -> 1096
/*      */     //   895: aload #27
/*      */     //   897: iload #15
/*      */     //   899: iaload
/*      */     //   900: bipush #31
/*      */     //   902: iushr
/*      */     //   903: istore #25
/*      */     //   905: getstatic jj2000/j2k/entropy/encoder/StdEntropyCoder.SC_LUT : [I
/*      */     //   908: iload #23
/*      */     //   910: iconst_4
/*      */     //   911: iushr
/*      */     //   912: sipush #511
/*      */     //   915: iand
/*      */     //   916: iaload
/*      */     //   917: istore #26
/*      */     //   919: aload #7
/*      */     //   921: iload #17
/*      */     //   923: iload #25
/*      */     //   925: iload #26
/*      */     //   927: bipush #31
/*      */     //   929: iushr
/*      */     //   930: ixor
/*      */     //   931: iastore
/*      */     //   932: aload #8
/*      */     //   934: iload #17
/*      */     //   936: iinc #17, 1
/*      */     //   939: iload #26
/*      */     //   941: bipush #15
/*      */     //   943: iand
/*      */     //   944: iastore
/*      */     //   945: aload #4
/*      */     //   947: iload #13
/*      */     //   949: iload #37
/*      */     //   951: iadd
/*      */     //   952: dup2
/*      */     //   953: iaload
/*      */     //   954: ldc 536936448
/*      */     //   956: ior
/*      */     //   957: iastore
/*      */     //   958: aload #4
/*      */     //   960: iload #13
/*      */     //   962: iload #38
/*      */     //   964: iadd
/*      */     //   965: dup2
/*      */     //   966: iaload
/*      */     //   967: ldc 537001984
/*      */     //   969: ior
/*      */     //   970: iastore
/*      */     //   971: iload #25
/*      */     //   973: ifeq -> 1023
/*      */     //   976: iload #23
/*      */     //   978: ldc 606126080
/*      */     //   980: ior
/*      */     //   981: istore #23
/*      */     //   983: aload #4
/*      */     //   985: iload #13
/*      */     //   987: iload #19
/*      */     //   989: isub
/*      */     //   990: dup2
/*      */     //   991: iaload
/*      */     //   992: ldc 571473920
/*      */     //   994: ior
/*      */     //   995: iastore
/*      */     //   996: aload #4
/*      */     //   998: iload #13
/*      */     //   1000: iconst_1
/*      */     //   1001: iadd
/*      */     //   1002: dup2
/*      */     //   1003: iaload
/*      */     //   1004: ldc 537407616
/*      */     //   1006: ior
/*      */     //   1007: iastore
/*      */     //   1008: aload #4
/*      */     //   1010: iload #13
/*      */     //   1012: iconst_1
/*      */     //   1013: isub
/*      */     //   1014: dup2
/*      */     //   1015: iaload
/*      */     //   1016: ldc 537143360
/*      */     //   1018: ior
/*      */     //   1019: iastore
/*      */     //   1020: goto -> 1067
/*      */     //   1023: iload #23
/*      */     //   1025: ldc 539017216
/*      */     //   1027: ior
/*      */     //   1028: istore #23
/*      */     //   1030: aload #4
/*      */     //   1032: iload #13
/*      */     //   1034: iload #19
/*      */     //   1036: isub
/*      */     //   1037: dup2
/*      */     //   1038: iaload
/*      */     //   1039: ldc 537919488
/*      */     //   1041: ior
/*      */     //   1042: iastore
/*      */     //   1043: aload #4
/*      */     //   1045: iload #13
/*      */     //   1047: iconst_1
/*      */     //   1048: iadd
/*      */     //   1049: dup2
/*      */     //   1050: iaload
/*      */     //   1051: ldc 537403520
/*      */     //   1053: ior
/*      */     //   1054: iastore
/*      */     //   1055: aload #4
/*      */     //   1057: iload #13
/*      */     //   1059: iconst_1
/*      */     //   1060: isub
/*      */     //   1061: dup2
/*      */     //   1062: iaload
/*      */     //   1063: ldc 537141312
/*      */     //   1065: ior
/*      */     //   1066: iastore
/*      */     //   1067: aload #27
/*      */     //   1069: iload #15
/*      */     //   1071: iaload
/*      */     //   1072: iload #31
/*      */     //   1074: ishr
/*      */     //   1075: iload #30
/*      */     //   1077: ishl
/*      */     //   1078: istore #32
/*      */     //   1080: iload #28
/*      */     //   1082: aload #5
/*      */     //   1084: iload #32
/*      */     //   1086: bipush #63
/*      */     //   1088: iand
/*      */     //   1089: iaload
/*      */     //   1090: iadd
/*      */     //   1091: istore #28
/*      */     //   1093: goto -> 1104
/*      */     //   1096: iload #23
/*      */     //   1098: sipush #16384
/*      */     //   1101: ior
/*      */     //   1102: istore #23
/*      */     //   1104: iload #36
/*      */     //   1106: iconst_4
/*      */     //   1107: if_icmpge -> 1120
/*      */     //   1110: aload #4
/*      */     //   1112: iload #13
/*      */     //   1114: iload #23
/*      */     //   1116: iastore
/*      */     //   1117: goto -> 1396
/*      */     //   1120: iload #23
/*      */     //   1122: ldc -1610612736
/*      */     //   1124: iand
/*      */     //   1125: ldc 536870912
/*      */     //   1127: if_icmpne -> 1389
/*      */     //   1130: iload #15
/*      */     //   1132: iload #18
/*      */     //   1134: iadd
/*      */     //   1135: istore #15
/*      */     //   1137: aload #8
/*      */     //   1139: iload #17
/*      */     //   1141: aload #6
/*      */     //   1143: iload #23
/*      */     //   1145: bipush #16
/*      */     //   1147: iushr
/*      */     //   1148: sipush #255
/*      */     //   1151: iand
/*      */     //   1152: iaload
/*      */     //   1153: iastore
/*      */     //   1154: aload #7
/*      */     //   1156: iload #17
/*      */     //   1158: iinc #17, 1
/*      */     //   1161: aload #27
/*      */     //   1163: iload #15
/*      */     //   1165: iaload
/*      */     //   1166: iload #24
/*      */     //   1168: iand
/*      */     //   1169: iload_3
/*      */     //   1170: iushr
/*      */     //   1171: dup_x2
/*      */     //   1172: iastore
/*      */     //   1173: ifeq -> 1382
/*      */     //   1176: aload #27
/*      */     //   1178: iload #15
/*      */     //   1180: iaload
/*      */     //   1181: bipush #31
/*      */     //   1183: iushr
/*      */     //   1184: istore #25
/*      */     //   1186: getstatic jj2000/j2k/entropy/encoder/StdEntropyCoder.SC_LUT : [I
/*      */     //   1189: iload #23
/*      */     //   1191: bipush #20
/*      */     //   1193: iushr
/*      */     //   1194: sipush #511
/*      */     //   1197: iand
/*      */     //   1198: iaload
/*      */     //   1199: istore #26
/*      */     //   1201: aload #7
/*      */     //   1203: iload #17
/*      */     //   1205: iload #25
/*      */     //   1207: iload #26
/*      */     //   1209: bipush #31
/*      */     //   1211: iushr
/*      */     //   1212: ixor
/*      */     //   1213: iastore
/*      */     //   1214: aload #8
/*      */     //   1216: iload #17
/*      */     //   1218: iinc #17, 1
/*      */     //   1221: iload #26
/*      */     //   1223: bipush #15
/*      */     //   1225: iand
/*      */     //   1226: iastore
/*      */     //   1227: aload #4
/*      */     //   1229: iload #13
/*      */     //   1231: iload #40
/*      */     //   1233: iadd
/*      */     //   1234: dup2
/*      */     //   1235: iaload
/*      */     //   1236: sipush #8196
/*      */     //   1239: ior
/*      */     //   1240: iastore
/*      */     //   1241: aload #4
/*      */     //   1243: iload #13
/*      */     //   1245: iload #39
/*      */     //   1247: iadd
/*      */     //   1248: dup2
/*      */     //   1249: iaload
/*      */     //   1250: sipush #8200
/*      */     //   1253: ior
/*      */     //   1254: iastore
/*      */     //   1255: iload #25
/*      */     //   1257: ifeq -> 1308
/*      */     //   1260: iload #23
/*      */     //   1262: ldc -1073733104
/*      */     //   1264: ior
/*      */     //   1265: istore #23
/*      */     //   1267: aload #4
/*      */     //   1269: iload #13
/*      */     //   1271: iload #19
/*      */     //   1273: iadd
/*      */     //   1274: dup2
/*      */     //   1275: iaload
/*      */     //   1276: sipush #9248
/*      */     //   1279: ior
/*      */     //   1280: iastore
/*      */     //   1281: aload #4
/*      */     //   1283: iload #13
/*      */     //   1285: iconst_1
/*      */     //   1286: iadd
/*      */     //   1287: dup2
/*      */     //   1288: iaload
/*      */     //   1289: ldc 813703170
/*      */     //   1291: ior
/*      */     //   1292: iastore
/*      */     //   1293: aload #4
/*      */     //   1295: iload #13
/*      */     //   1297: iconst_1
/*      */     //   1298: isub
/*      */     //   1299: dup2
/*      */     //   1300: iaload
/*      */     //   1301: ldc 675291137
/*      */     //   1303: ior
/*      */     //   1304: iastore
/*      */     //   1305: goto -> 1353
/*      */     //   1308: iload #23
/*      */     //   1310: ldc -1073733616
/*      */     //   1312: ior
/*      */     //   1313: istore #23
/*      */     //   1315: aload #4
/*      */     //   1317: iload #13
/*      */     //   1319: iload #19
/*      */     //   1321: iadd
/*      */     //   1322: dup2
/*      */     //   1323: iaload
/*      */     //   1324: sipush #8224
/*      */     //   1327: ior
/*      */     //   1328: iastore
/*      */     //   1329: aload #4
/*      */     //   1331: iload #13
/*      */     //   1333: iconst_1
/*      */     //   1334: iadd
/*      */     //   1335: dup2
/*      */     //   1336: iaload
/*      */     //   1337: ldc 545267714
/*      */     //   1339: ior
/*      */     //   1340: iastore
/*      */     //   1341: aload #4
/*      */     //   1343: iload #13
/*      */     //   1345: iconst_1
/*      */     //   1346: isub
/*      */     //   1347: dup2
/*      */     //   1348: iaload
/*      */     //   1349: ldc 541073409
/*      */     //   1351: ior
/*      */     //   1352: iastore
/*      */     //   1353: aload #27
/*      */     //   1355: iload #15
/*      */     //   1357: iaload
/*      */     //   1358: iload #31
/*      */     //   1360: ishr
/*      */     //   1361: iload #30
/*      */     //   1363: ishl
/*      */     //   1364: istore #32
/*      */     //   1366: iload #28
/*      */     //   1368: aload #5
/*      */     //   1370: iload #32
/*      */     //   1372: bipush #63
/*      */     //   1374: iand
/*      */     //   1375: iaload
/*      */     //   1376: iadd
/*      */     //   1377: istore #28
/*      */     //   1379: goto -> 1389
/*      */     //   1382: iload #23
/*      */     //   1384: ldc 1073741824
/*      */     //   1386: ior
/*      */     //   1387: istore #23
/*      */     //   1389: aload #4
/*      */     //   1391: iload #13
/*      */     //   1393: iload #23
/*      */     //   1395: iastore
/*      */     //   1396: iinc #16, 1
/*      */     //   1399: iinc #14, 1
/*      */     //   1402: goto -> 201
/*      */     //   1405: aload_1
/*      */     //   1406: aload #7
/*      */     //   1408: aload #8
/*      */     //   1410: iload #17
/*      */     //   1412: invokevirtual codeSymbols : ([I[II)V
/*      */     //   1415: iinc #33, -1
/*      */     //   1418: iload #16
/*      */     //   1420: iload #21
/*      */     //   1422: iadd
/*      */     //   1423: istore #16
/*      */     //   1425: iload #14
/*      */     //   1427: iload #20
/*      */     //   1429: iadd
/*      */     //   1430: istore #14
/*      */     //   1432: goto -> 162
/*      */     //   1435: iload #12
/*      */     //   1437: iconst_2
/*      */     //   1438: iand
/*      */     //   1439: ifeq -> 1446
/*      */     //   1442: aload_1
/*      */     //   1443: invokevirtual resetCtxts : ()V
/*      */     //   1446: iload_2
/*      */     //   1447: ifeq -> 1462
/*      */     //   1450: aload #9
/*      */     //   1452: iload #10
/*      */     //   1454: aload_1
/*      */     //   1455: invokevirtual terminate : ()I
/*      */     //   1458: iastore
/*      */     //   1459: goto -> 1471
/*      */     //   1462: aload #9
/*      */     //   1464: iload #10
/*      */     //   1466: aload_1
/*      */     //   1467: invokevirtual getNumCodedBytes : ()I
/*      */     //   1470: iastore
/*      */     //   1471: iload #11
/*      */     //   1473: iflt -> 1489
/*      */     //   1476: aload #9
/*      */     //   1478: iload #10
/*      */     //   1480: dup2
/*      */     //   1481: iaload
/*      */     //   1482: aload #9
/*      */     //   1484: iload #11
/*      */     //   1486: iaload
/*      */     //   1487: iadd
/*      */     //   1488: iastore
/*      */     //   1489: iload_2
/*      */     //   1490: ifeq -> 1501
/*      */     //   1493: aload_1
/*      */     //   1494: aload #9
/*      */     //   1496: iload #10
/*      */     //   1498: invokevirtual finishLengthCalculation : ([II)V
/*      */     //   1501: iload #28
/*      */     //   1503: ireturn
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #1678	-> 0
/*      */     //   #1679	-> 6
/*      */     //   #1680	-> 14
/*      */     //   #1681	-> 27
/*      */     //   #1682	-> 38
/*      */     //   #1683	-> 43
/*      */     //   #1684	-> 55
/*      */     //   #1685	-> 67
/*      */     //   #1688	-> 70
/*      */     //   #1689	-> 76
/*      */     //   #1690	-> 90
/*      */     //   #1691	-> 103
/*      */     //   #1694	-> 118
/*      */     //   #1695	-> 125
/*      */     //   #1696	-> 132
/*      */     //   #1697	-> 138
/*      */     //   #1700	-> 144
/*      */     //   #1701	-> 150
/*      */     //   #1702	-> 156
/*      */     //   #1703	-> 167
/*      */     //   #1705	-> 189
/*      */     //   #1707	-> 198
/*      */     //   #1709	-> 208
/*      */     //   #1710	-> 212
/*      */     //   #1714	-> 219
/*      */     //   #1715	-> 234
/*      */     //   #1717	-> 238
/*      */     //   #1720	-> 249
/*      */     //   #1721	-> 263
/*      */     //   #1724	-> 285
/*      */     //   #1725	-> 295
/*      */     //   #1726	-> 309
/*      */     //   #1727	-> 322
/*      */     //   #1732	-> 335
/*      */     //   #1735	-> 340
/*      */     //   #1737	-> 353
/*      */     //   #1741	-> 366
/*      */     //   #1742	-> 371
/*      */     //   #1745	-> 378
/*      */     //   #1748	-> 383
/*      */     //   #1751	-> 396
/*      */     //   #1755	-> 408
/*      */     //   #1761	-> 423
/*      */     //   #1763	-> 430
/*      */     //   #1766	-> 435
/*      */     //   #1769	-> 448
/*      */     //   #1772	-> 460
/*      */     //   #1777	-> 472
/*      */     //   #1778	-> 485
/*      */     //   #1781	-> 501
/*      */     //   #1784	-> 509
/*      */     //   #1785	-> 515
/*      */     //   #1786	-> 522
/*      */     //   #1789	-> 525
/*      */     //   #1791	-> 535
/*      */     //   #1793	-> 542
/*      */     //   #1794	-> 559
/*      */     //   #1797	-> 581
/*      */     //   #1798	-> 591
/*      */     //   #1799	-> 606
/*      */     //   #1800	-> 619
/*      */     //   #1805	-> 632
/*      */     //   #1806	-> 646
/*      */     //   #1808	-> 660
/*      */     //   #1809	-> 665
/*      */     //   #1812	-> 672
/*      */     //   #1814	-> 686
/*      */     //   #1818	-> 698
/*      */     //   #1824	-> 713
/*      */     //   #1826	-> 720
/*      */     //   #1828	-> 734
/*      */     //   #1831	-> 746
/*      */     //   #1836	-> 758
/*      */     //   #1837	-> 771
/*      */     //   #1840	-> 787
/*      */     //   #1843	-> 794
/*      */     //   #1846	-> 801
/*      */     //   #1847	-> 810
/*      */     //   #1848	-> 817
/*      */     //   #1852	-> 824
/*      */     //   #1853	-> 839
/*      */     //   #1855	-> 848
/*      */     //   #1858	-> 859
/*      */     //   #1859	-> 873
/*      */     //   #1862	-> 895
/*      */     //   #1863	-> 905
/*      */     //   #1864	-> 919
/*      */     //   #1865	-> 932
/*      */     //   #1870	-> 945
/*      */     //   #1871	-> 958
/*      */     //   #1873	-> 971
/*      */     //   #1874	-> 976
/*      */     //   #1877	-> 983
/*      */     //   #1879	-> 996
/*      */     //   #1883	-> 1008
/*      */     //   #1889	-> 1023
/*      */     //   #1891	-> 1030
/*      */     //   #1893	-> 1043
/*      */     //   #1896	-> 1055
/*      */     //   #1901	-> 1067
/*      */     //   #1902	-> 1080
/*      */     //   #1905	-> 1096
/*      */     //   #1908	-> 1104
/*      */     //   #1909	-> 1110
/*      */     //   #1910	-> 1117
/*      */     //   #1913	-> 1120
/*      */     //   #1915	-> 1130
/*      */     //   #1917	-> 1137
/*      */     //   #1918	-> 1154
/*      */     //   #1921	-> 1176
/*      */     //   #1922	-> 1186
/*      */     //   #1923	-> 1201
/*      */     //   #1924	-> 1214
/*      */     //   #1929	-> 1227
/*      */     //   #1930	-> 1241
/*      */     //   #1932	-> 1255
/*      */     //   #1933	-> 1260
/*      */     //   #1936	-> 1267
/*      */     //   #1938	-> 1281
/*      */     //   #1942	-> 1293
/*      */     //   #1948	-> 1308
/*      */     //   #1950	-> 1315
/*      */     //   #1952	-> 1329
/*      */     //   #1955	-> 1341
/*      */     //   #1960	-> 1353
/*      */     //   #1961	-> 1366
/*      */     //   #1964	-> 1382
/*      */     //   #1967	-> 1389
/*      */     //   #1707	-> 1396
/*      */     //   #1971	-> 1405
/*      */     //   #1702	-> 1415
/*      */     //   #1975	-> 1435
/*      */     //   #1976	-> 1442
/*      */     //   #1980	-> 1446
/*      */     //   #1981	-> 1450
/*      */     //   #1984	-> 1462
/*      */     //   #1987	-> 1471
/*      */     //   #1988	-> 1476
/*      */     //   #1991	-> 1489
/*      */     //   #1992	-> 1493
/*      */     //   #1996	-> 1501
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   295	206	25	sym	I
/*      */     //   309	192	26	ctxt	I
/*      */     //   485	16	32	normval	I
/*      */     //   591	196	25	sym	I
/*      */     //   606	181	26	ctxt	I
/*      */     //   771	16	32	normval	I
/*      */     //   238	563	15	k	I
/*      */     //   905	191	25	sym	I
/*      */     //   919	177	26	ctxt	I
/*      */     //   1080	16	32	normval	I
/*      */     //   1186	196	25	sym	I
/*      */     //   1201	181	26	ctxt	I
/*      */     //   1366	16	32	normval	I
/*      */     //   848	548	15	k	I
/*      */     //   212	1193	13	j	I
/*      */     //   219	1186	23	csj	I
/*      */     //   201	1234	17	nsym	I
/*      */     //   198	1237	22	stopsk	I
/*      */     //   189	1246	36	sheight	I
/*      */     //   0	1504	0	srcblk	Ljj2000/j2k/wavelet/analysis/CBlkWTData;
/*      */     //   0	1504	1	mq	Ljj2000/j2k/entropy/encoder/MQCoder;
/*      */     //   0	1504	2	doterm	Z
/*      */     //   0	1504	3	bp	I
/*      */     //   0	1504	4	state	[I
/*      */     //   0	1504	5	fs	[I
/*      */     //   0	1504	6	zc_lut	[I
/*      */     //   0	1504	7	symbuf	[I
/*      */     //   0	1504	8	ctxtbuf	[I
/*      */     //   0	1504	9	ratebuf	[I
/*      */     //   0	1504	10	pidx	I
/*      */     //   0	1504	11	ltpidx	I
/*      */     //   0	1504	12	options	I
/*      */     //   156	1348	14	sj	I
/*      */     //   150	1354	16	sk	I
/*      */     //   6	1498	18	dscanw	I
/*      */     //   14	1490	19	sscanw	I
/*      */     //   27	1477	20	jstep	I
/*      */     //   38	1466	21	kstep	I
/*      */     //   43	1461	24	mask	I
/*      */     //   55	1449	27	data	[I
/*      */     //   70	1434	28	dist	I
/*      */     //   76	1428	29	shift	I
/*      */     //   90	1414	30	upshift	I
/*      */     //   103	1401	31	downshift	I
/*      */     //   162	1342	33	s	I
/*      */     //   118	1386	34	causal	Z
/*      */     //   67	1437	35	nstripes	I
/*      */     //   125	1379	37	off_ul	I
/*      */     //   132	1372	38	off_ur	I
/*      */     //   138	1366	39	off_dr	I
/*      */     //   144	1360	40	off_dl	I
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int rawSigProgPass(CBlkWTData srcblk, BitToByteOutput bout, boolean doterm, int bp, int[] state, int[] fs, int[] ratebuf, int pidx, int ltpidx, int options) {
/*      */     // Byte code:
/*      */     //   0: iconst_0
/*      */     //   1: istore #21
/*      */     //   3: aload_0
/*      */     //   4: getfield scanw : I
/*      */     //   7: istore #14
/*      */     //   9: aload_0
/*      */     //   10: getfield w : I
/*      */     //   13: iconst_2
/*      */     //   14: iadd
/*      */     //   15: istore #15
/*      */     //   17: iload #15
/*      */     //   19: iconst_4
/*      */     //   20: imul
/*      */     //   21: iconst_2
/*      */     //   22: idiv
/*      */     //   23: aload_0
/*      */     //   24: getfield w : I
/*      */     //   27: isub
/*      */     //   28: istore #16
/*      */     //   30: iload #14
/*      */     //   32: iconst_4
/*      */     //   33: imul
/*      */     //   34: aload_0
/*      */     //   35: getfield w : I
/*      */     //   38: isub
/*      */     //   39: istore #17
/*      */     //   41: iconst_1
/*      */     //   42: iload_3
/*      */     //   43: ishl
/*      */     //   44: istore #20
/*      */     //   46: aload_0
/*      */     //   47: invokevirtual getData : ()Ljava/lang/Object;
/*      */     //   50: checkcast [I
/*      */     //   53: checkcast [I
/*      */     //   56: astore #23
/*      */     //   58: aload_0
/*      */     //   59: getfield h : I
/*      */     //   62: iconst_4
/*      */     //   63: iadd
/*      */     //   64: iconst_1
/*      */     //   65: isub
/*      */     //   66: iconst_4
/*      */     //   67: idiv
/*      */     //   68: istore #31
/*      */     //   70: iconst_0
/*      */     //   71: istore #24
/*      */     //   73: iload_3
/*      */     //   74: bipush #6
/*      */     //   76: isub
/*      */     //   77: istore #25
/*      */     //   79: iload #25
/*      */     //   81: iflt -> 88
/*      */     //   84: iconst_0
/*      */     //   85: goto -> 91
/*      */     //   88: iload #25
/*      */     //   90: ineg
/*      */     //   91: istore #26
/*      */     //   93: iload #25
/*      */     //   95: ifgt -> 102
/*      */     //   98: iconst_0
/*      */     //   99: goto -> 104
/*      */     //   102: iload #25
/*      */     //   104: istore #27
/*      */     //   106: iload #9
/*      */     //   108: bipush #8
/*      */     //   110: iand
/*      */     //   111: ifeq -> 118
/*      */     //   114: iconst_1
/*      */     //   115: goto -> 119
/*      */     //   118: iconst_0
/*      */     //   119: istore #30
/*      */     //   121: iload #15
/*      */     //   123: ineg
/*      */     //   124: iconst_1
/*      */     //   125: isub
/*      */     //   126: istore #33
/*      */     //   128: iload #15
/*      */     //   130: ineg
/*      */     //   131: iconst_1
/*      */     //   132: iadd
/*      */     //   133: istore #34
/*      */     //   135: iload #15
/*      */     //   137: iconst_1
/*      */     //   138: iadd
/*      */     //   139: istore #35
/*      */     //   141: iload #15
/*      */     //   143: iconst_1
/*      */     //   144: isub
/*      */     //   145: istore #36
/*      */     //   147: aload_0
/*      */     //   148: getfield offset : I
/*      */     //   151: istore #13
/*      */     //   153: iload #15
/*      */     //   155: iconst_1
/*      */     //   156: iadd
/*      */     //   157: istore #11
/*      */     //   159: iload #31
/*      */     //   161: iconst_1
/*      */     //   162: isub
/*      */     //   163: istore #29
/*      */     //   165: iload #29
/*      */     //   167: iflt -> 1253
/*      */     //   170: iload #29
/*      */     //   172: ifeq -> 179
/*      */     //   175: iconst_4
/*      */     //   176: goto -> 190
/*      */     //   179: aload_0
/*      */     //   180: getfield h : I
/*      */     //   183: iload #31
/*      */     //   185: iconst_1
/*      */     //   186: isub
/*      */     //   187: iconst_4
/*      */     //   188: imul
/*      */     //   189: isub
/*      */     //   190: istore #32
/*      */     //   192: iload #13
/*      */     //   194: aload_0
/*      */     //   195: getfield w : I
/*      */     //   198: iadd
/*      */     //   199: istore #18
/*      */     //   201: iload #13
/*      */     //   203: iload #18
/*      */     //   205: if_icmpge -> 1233
/*      */     //   208: iload #11
/*      */     //   210: istore #10
/*      */     //   212: aload #4
/*      */     //   214: iload #10
/*      */     //   216: iaload
/*      */     //   217: istore #19
/*      */     //   219: iload #19
/*      */     //   221: iconst_m1
/*      */     //   222: ixor
/*      */     //   223: iload #19
/*      */     //   225: iconst_2
/*      */     //   226: ishl
/*      */     //   227: iand
/*      */     //   228: ldc -2147450880
/*      */     //   230: iand
/*      */     //   231: ifeq -> 715
/*      */     //   234: iload #13
/*      */     //   236: istore #12
/*      */     //   238: iload #19
/*      */     //   240: ldc 40960
/*      */     //   242: iand
/*      */     //   243: sipush #8192
/*      */     //   246: if_icmpne -> 468
/*      */     //   249: aload #23
/*      */     //   251: iload #12
/*      */     //   253: iaload
/*      */     //   254: iload #20
/*      */     //   256: iand
/*      */     //   257: iload_3
/*      */     //   258: iushr
/*      */     //   259: istore #22
/*      */     //   261: aload_1
/*      */     //   262: iload #22
/*      */     //   264: invokevirtual writeBit : (I)V
/*      */     //   267: iinc #21, 1
/*      */     //   270: iload #22
/*      */     //   272: ifeq -> 460
/*      */     //   275: aload #23
/*      */     //   277: iload #12
/*      */     //   279: iaload
/*      */     //   280: bipush #31
/*      */     //   282: iushr
/*      */     //   283: istore #22
/*      */     //   285: aload_1
/*      */     //   286: iload #22
/*      */     //   288: invokevirtual writeBit : (I)V
/*      */     //   291: iinc #21, 1
/*      */     //   294: iload #30
/*      */     //   296: ifne -> 325
/*      */     //   299: aload #4
/*      */     //   301: iload #10
/*      */     //   303: iload #33
/*      */     //   305: iadd
/*      */     //   306: dup2
/*      */     //   307: iaload
/*      */     //   308: ldc 536936448
/*      */     //   310: ior
/*      */     //   311: iastore
/*      */     //   312: aload #4
/*      */     //   314: iload #10
/*      */     //   316: iload #34
/*      */     //   318: iadd
/*      */     //   319: dup2
/*      */     //   320: iaload
/*      */     //   321: ldc 537001984
/*      */     //   323: ior
/*      */     //   324: iastore
/*      */     //   325: iload #22
/*      */     //   327: ifeq -> 382
/*      */     //   330: iload #19
/*      */     //   332: ldc 606126080
/*      */     //   334: ior
/*      */     //   335: istore #19
/*      */     //   337: iload #30
/*      */     //   339: ifne -> 355
/*      */     //   342: aload #4
/*      */     //   344: iload #10
/*      */     //   346: iload #15
/*      */     //   348: isub
/*      */     //   349: dup2
/*      */     //   350: iaload
/*      */     //   351: ldc 571473920
/*      */     //   353: ior
/*      */     //   354: iastore
/*      */     //   355: aload #4
/*      */     //   357: iload #10
/*      */     //   359: iconst_1
/*      */     //   360: iadd
/*      */     //   361: dup2
/*      */     //   362: iaload
/*      */     //   363: ldc 537407616
/*      */     //   365: ior
/*      */     //   366: iastore
/*      */     //   367: aload #4
/*      */     //   369: iload #10
/*      */     //   371: iconst_1
/*      */     //   372: isub
/*      */     //   373: dup2
/*      */     //   374: iaload
/*      */     //   375: ldc 537143360
/*      */     //   377: ior
/*      */     //   378: iastore
/*      */     //   379: goto -> 431
/*      */     //   382: iload #19
/*      */     //   384: ldc 539017216
/*      */     //   386: ior
/*      */     //   387: istore #19
/*      */     //   389: iload #30
/*      */     //   391: ifne -> 407
/*      */     //   394: aload #4
/*      */     //   396: iload #10
/*      */     //   398: iload #15
/*      */     //   400: isub
/*      */     //   401: dup2
/*      */     //   402: iaload
/*      */     //   403: ldc 537919488
/*      */     //   405: ior
/*      */     //   406: iastore
/*      */     //   407: aload #4
/*      */     //   409: iload #10
/*      */     //   411: iconst_1
/*      */     //   412: iadd
/*      */     //   413: dup2
/*      */     //   414: iaload
/*      */     //   415: ldc 537403520
/*      */     //   417: ior
/*      */     //   418: iastore
/*      */     //   419: aload #4
/*      */     //   421: iload #10
/*      */     //   423: iconst_1
/*      */     //   424: isub
/*      */     //   425: dup2
/*      */     //   426: iaload
/*      */     //   427: ldc 537141312
/*      */     //   429: ior
/*      */     //   430: iastore
/*      */     //   431: aload #23
/*      */     //   433: iload #12
/*      */     //   435: iaload
/*      */     //   436: iload #27
/*      */     //   438: ishr
/*      */     //   439: iload #26
/*      */     //   441: ishl
/*      */     //   442: istore #28
/*      */     //   444: iload #24
/*      */     //   446: aload #5
/*      */     //   448: iload #28
/*      */     //   450: bipush #63
/*      */     //   452: iand
/*      */     //   453: iaload
/*      */     //   454: iadd
/*      */     //   455: istore #24
/*      */     //   457: goto -> 468
/*      */     //   460: iload #19
/*      */     //   462: sipush #16384
/*      */     //   465: ior
/*      */     //   466: istore #19
/*      */     //   468: iload #32
/*      */     //   470: iconst_2
/*      */     //   471: if_icmpge -> 484
/*      */     //   474: aload #4
/*      */     //   476: iload #10
/*      */     //   478: iload #19
/*      */     //   480: iastore
/*      */     //   481: goto -> 1224
/*      */     //   484: iload #19
/*      */     //   486: ldc -1610612736
/*      */     //   488: iand
/*      */     //   489: ldc 536870912
/*      */     //   491: if_icmpne -> 708
/*      */     //   494: iload #12
/*      */     //   496: iload #14
/*      */     //   498: iadd
/*      */     //   499: istore #12
/*      */     //   501: aload #23
/*      */     //   503: iload #12
/*      */     //   505: iaload
/*      */     //   506: iload #20
/*      */     //   508: iand
/*      */     //   509: iload_3
/*      */     //   510: iushr
/*      */     //   511: istore #22
/*      */     //   513: aload_1
/*      */     //   514: iload #22
/*      */     //   516: invokevirtual writeBit : (I)V
/*      */     //   519: iinc #21, 1
/*      */     //   522: iload #22
/*      */     //   524: ifeq -> 701
/*      */     //   527: aload #23
/*      */     //   529: iload #12
/*      */     //   531: iaload
/*      */     //   532: bipush #31
/*      */     //   534: iushr
/*      */     //   535: istore #22
/*      */     //   537: aload_1
/*      */     //   538: iload #22
/*      */     //   540: invokevirtual writeBit : (I)V
/*      */     //   543: iinc #21, 1
/*      */     //   546: aload #4
/*      */     //   548: iload #10
/*      */     //   550: iload #36
/*      */     //   552: iadd
/*      */     //   553: dup2
/*      */     //   554: iaload
/*      */     //   555: sipush #8196
/*      */     //   558: ior
/*      */     //   559: iastore
/*      */     //   560: aload #4
/*      */     //   562: iload #10
/*      */     //   564: iload #35
/*      */     //   566: iadd
/*      */     //   567: dup2
/*      */     //   568: iaload
/*      */     //   569: sipush #8200
/*      */     //   572: ior
/*      */     //   573: iastore
/*      */     //   574: iload #22
/*      */     //   576: ifeq -> 627
/*      */     //   579: iload #19
/*      */     //   581: ldc -1073733104
/*      */     //   583: ior
/*      */     //   584: istore #19
/*      */     //   586: aload #4
/*      */     //   588: iload #10
/*      */     //   590: iload #15
/*      */     //   592: iadd
/*      */     //   593: dup2
/*      */     //   594: iaload
/*      */     //   595: sipush #9248
/*      */     //   598: ior
/*      */     //   599: iastore
/*      */     //   600: aload #4
/*      */     //   602: iload #10
/*      */     //   604: iconst_1
/*      */     //   605: iadd
/*      */     //   606: dup2
/*      */     //   607: iaload
/*      */     //   608: ldc 813703170
/*      */     //   610: ior
/*      */     //   611: iastore
/*      */     //   612: aload #4
/*      */     //   614: iload #10
/*      */     //   616: iconst_1
/*      */     //   617: isub
/*      */     //   618: dup2
/*      */     //   619: iaload
/*      */     //   620: ldc 675291137
/*      */     //   622: ior
/*      */     //   623: iastore
/*      */     //   624: goto -> 672
/*      */     //   627: iload #19
/*      */     //   629: ldc -1073733616
/*      */     //   631: ior
/*      */     //   632: istore #19
/*      */     //   634: aload #4
/*      */     //   636: iload #10
/*      */     //   638: iload #15
/*      */     //   640: iadd
/*      */     //   641: dup2
/*      */     //   642: iaload
/*      */     //   643: sipush #8224
/*      */     //   646: ior
/*      */     //   647: iastore
/*      */     //   648: aload #4
/*      */     //   650: iload #10
/*      */     //   652: iconst_1
/*      */     //   653: iadd
/*      */     //   654: dup2
/*      */     //   655: iaload
/*      */     //   656: ldc 545267714
/*      */     //   658: ior
/*      */     //   659: iastore
/*      */     //   660: aload #4
/*      */     //   662: iload #10
/*      */     //   664: iconst_1
/*      */     //   665: isub
/*      */     //   666: dup2
/*      */     //   667: iaload
/*      */     //   668: ldc 541073409
/*      */     //   670: ior
/*      */     //   671: iastore
/*      */     //   672: aload #23
/*      */     //   674: iload #12
/*      */     //   676: iaload
/*      */     //   677: iload #27
/*      */     //   679: ishr
/*      */     //   680: iload #26
/*      */     //   682: ishl
/*      */     //   683: istore #28
/*      */     //   685: iload #24
/*      */     //   687: aload #5
/*      */     //   689: iload #28
/*      */     //   691: bipush #63
/*      */     //   693: iand
/*      */     //   694: iaload
/*      */     //   695: iadd
/*      */     //   696: istore #24
/*      */     //   698: goto -> 708
/*      */     //   701: iload #19
/*      */     //   703: ldc 1073741824
/*      */     //   705: ior
/*      */     //   706: istore #19
/*      */     //   708: aload #4
/*      */     //   710: iload #10
/*      */     //   712: iload #19
/*      */     //   714: iastore
/*      */     //   715: iload #32
/*      */     //   717: iconst_3
/*      */     //   718: if_icmpge -> 724
/*      */     //   721: goto -> 1224
/*      */     //   724: iload #10
/*      */     //   726: iload #15
/*      */     //   728: iadd
/*      */     //   729: istore #10
/*      */     //   731: aload #4
/*      */     //   733: iload #10
/*      */     //   735: iaload
/*      */     //   736: istore #19
/*      */     //   738: iload #19
/*      */     //   740: iconst_m1
/*      */     //   741: ixor
/*      */     //   742: iload #19
/*      */     //   744: iconst_2
/*      */     //   745: ishl
/*      */     //   746: iand
/*      */     //   747: ldc -2147450880
/*      */     //   749: iand
/*      */     //   750: ifeq -> 1224
/*      */     //   753: iload #13
/*      */     //   755: iload #14
/*      */     //   757: iconst_1
/*      */     //   758: ishl
/*      */     //   759: iadd
/*      */     //   760: istore #12
/*      */     //   762: iload #19
/*      */     //   764: ldc 40960
/*      */     //   766: iand
/*      */     //   767: sipush #8192
/*      */     //   770: if_icmpne -> 977
/*      */     //   773: aload #23
/*      */     //   775: iload #12
/*      */     //   777: iaload
/*      */     //   778: iload #20
/*      */     //   780: iand
/*      */     //   781: iload_3
/*      */     //   782: iushr
/*      */     //   783: istore #22
/*      */     //   785: aload_1
/*      */     //   786: iload #22
/*      */     //   788: invokevirtual writeBit : (I)V
/*      */     //   791: iinc #21, 1
/*      */     //   794: iload #22
/*      */     //   796: ifeq -> 969
/*      */     //   799: aload #23
/*      */     //   801: iload #12
/*      */     //   803: iaload
/*      */     //   804: bipush #31
/*      */     //   806: iushr
/*      */     //   807: istore #22
/*      */     //   809: aload_1
/*      */     //   810: iload #22
/*      */     //   812: invokevirtual writeBit : (I)V
/*      */     //   815: iinc #21, 1
/*      */     //   818: aload #4
/*      */     //   820: iload #10
/*      */     //   822: iload #33
/*      */     //   824: iadd
/*      */     //   825: dup2
/*      */     //   826: iaload
/*      */     //   827: ldc 536936448
/*      */     //   829: ior
/*      */     //   830: iastore
/*      */     //   831: aload #4
/*      */     //   833: iload #10
/*      */     //   835: iload #34
/*      */     //   837: iadd
/*      */     //   838: dup2
/*      */     //   839: iaload
/*      */     //   840: ldc 537001984
/*      */     //   842: ior
/*      */     //   843: iastore
/*      */     //   844: iload #22
/*      */     //   846: ifeq -> 896
/*      */     //   849: iload #19
/*      */     //   851: ldc 606126080
/*      */     //   853: ior
/*      */     //   854: istore #19
/*      */     //   856: aload #4
/*      */     //   858: iload #10
/*      */     //   860: iload #15
/*      */     //   862: isub
/*      */     //   863: dup2
/*      */     //   864: iaload
/*      */     //   865: ldc 571473920
/*      */     //   867: ior
/*      */     //   868: iastore
/*      */     //   869: aload #4
/*      */     //   871: iload #10
/*      */     //   873: iconst_1
/*      */     //   874: iadd
/*      */     //   875: dup2
/*      */     //   876: iaload
/*      */     //   877: ldc 537407616
/*      */     //   879: ior
/*      */     //   880: iastore
/*      */     //   881: aload #4
/*      */     //   883: iload #10
/*      */     //   885: iconst_1
/*      */     //   886: isub
/*      */     //   887: dup2
/*      */     //   888: iaload
/*      */     //   889: ldc 537143360
/*      */     //   891: ior
/*      */     //   892: iastore
/*      */     //   893: goto -> 940
/*      */     //   896: iload #19
/*      */     //   898: ldc 539017216
/*      */     //   900: ior
/*      */     //   901: istore #19
/*      */     //   903: aload #4
/*      */     //   905: iload #10
/*      */     //   907: iload #15
/*      */     //   909: isub
/*      */     //   910: dup2
/*      */     //   911: iaload
/*      */     //   912: ldc 537919488
/*      */     //   914: ior
/*      */     //   915: iastore
/*      */     //   916: aload #4
/*      */     //   918: iload #10
/*      */     //   920: iconst_1
/*      */     //   921: iadd
/*      */     //   922: dup2
/*      */     //   923: iaload
/*      */     //   924: ldc 537403520
/*      */     //   926: ior
/*      */     //   927: iastore
/*      */     //   928: aload #4
/*      */     //   930: iload #10
/*      */     //   932: iconst_1
/*      */     //   933: isub
/*      */     //   934: dup2
/*      */     //   935: iaload
/*      */     //   936: ldc 537141312
/*      */     //   938: ior
/*      */     //   939: iastore
/*      */     //   940: aload #23
/*      */     //   942: iload #12
/*      */     //   944: iaload
/*      */     //   945: iload #27
/*      */     //   947: ishr
/*      */     //   948: iload #26
/*      */     //   950: ishl
/*      */     //   951: istore #28
/*      */     //   953: iload #24
/*      */     //   955: aload #5
/*      */     //   957: iload #28
/*      */     //   959: bipush #63
/*      */     //   961: iand
/*      */     //   962: iaload
/*      */     //   963: iadd
/*      */     //   964: istore #24
/*      */     //   966: goto -> 977
/*      */     //   969: iload #19
/*      */     //   971: sipush #16384
/*      */     //   974: ior
/*      */     //   975: istore #19
/*      */     //   977: iload #32
/*      */     //   979: iconst_4
/*      */     //   980: if_icmpge -> 993
/*      */     //   983: aload #4
/*      */     //   985: iload #10
/*      */     //   987: iload #19
/*      */     //   989: iastore
/*      */     //   990: goto -> 1224
/*      */     //   993: iload #19
/*      */     //   995: ldc -1610612736
/*      */     //   997: iand
/*      */     //   998: ldc 536870912
/*      */     //   1000: if_icmpne -> 1217
/*      */     //   1003: iload #12
/*      */     //   1005: iload #14
/*      */     //   1007: iadd
/*      */     //   1008: istore #12
/*      */     //   1010: aload #23
/*      */     //   1012: iload #12
/*      */     //   1014: iaload
/*      */     //   1015: iload #20
/*      */     //   1017: iand
/*      */     //   1018: iload_3
/*      */     //   1019: iushr
/*      */     //   1020: istore #22
/*      */     //   1022: aload_1
/*      */     //   1023: iload #22
/*      */     //   1025: invokevirtual writeBit : (I)V
/*      */     //   1028: iinc #21, 1
/*      */     //   1031: iload #22
/*      */     //   1033: ifeq -> 1210
/*      */     //   1036: aload #23
/*      */     //   1038: iload #12
/*      */     //   1040: iaload
/*      */     //   1041: bipush #31
/*      */     //   1043: iushr
/*      */     //   1044: istore #22
/*      */     //   1046: aload_1
/*      */     //   1047: iload #22
/*      */     //   1049: invokevirtual writeBit : (I)V
/*      */     //   1052: iinc #21, 1
/*      */     //   1055: aload #4
/*      */     //   1057: iload #10
/*      */     //   1059: iload #36
/*      */     //   1061: iadd
/*      */     //   1062: dup2
/*      */     //   1063: iaload
/*      */     //   1064: sipush #8196
/*      */     //   1067: ior
/*      */     //   1068: iastore
/*      */     //   1069: aload #4
/*      */     //   1071: iload #10
/*      */     //   1073: iload #35
/*      */     //   1075: iadd
/*      */     //   1076: dup2
/*      */     //   1077: iaload
/*      */     //   1078: sipush #8200
/*      */     //   1081: ior
/*      */     //   1082: iastore
/*      */     //   1083: iload #22
/*      */     //   1085: ifeq -> 1136
/*      */     //   1088: iload #19
/*      */     //   1090: ldc -1073733104
/*      */     //   1092: ior
/*      */     //   1093: istore #19
/*      */     //   1095: aload #4
/*      */     //   1097: iload #10
/*      */     //   1099: iload #15
/*      */     //   1101: iadd
/*      */     //   1102: dup2
/*      */     //   1103: iaload
/*      */     //   1104: sipush #9248
/*      */     //   1107: ior
/*      */     //   1108: iastore
/*      */     //   1109: aload #4
/*      */     //   1111: iload #10
/*      */     //   1113: iconst_1
/*      */     //   1114: iadd
/*      */     //   1115: dup2
/*      */     //   1116: iaload
/*      */     //   1117: ldc 813703170
/*      */     //   1119: ior
/*      */     //   1120: iastore
/*      */     //   1121: aload #4
/*      */     //   1123: iload #10
/*      */     //   1125: iconst_1
/*      */     //   1126: isub
/*      */     //   1127: dup2
/*      */     //   1128: iaload
/*      */     //   1129: ldc 675291137
/*      */     //   1131: ior
/*      */     //   1132: iastore
/*      */     //   1133: goto -> 1181
/*      */     //   1136: iload #19
/*      */     //   1138: ldc -1073733616
/*      */     //   1140: ior
/*      */     //   1141: istore #19
/*      */     //   1143: aload #4
/*      */     //   1145: iload #10
/*      */     //   1147: iload #15
/*      */     //   1149: iadd
/*      */     //   1150: dup2
/*      */     //   1151: iaload
/*      */     //   1152: sipush #8224
/*      */     //   1155: ior
/*      */     //   1156: iastore
/*      */     //   1157: aload #4
/*      */     //   1159: iload #10
/*      */     //   1161: iconst_1
/*      */     //   1162: iadd
/*      */     //   1163: dup2
/*      */     //   1164: iaload
/*      */     //   1165: ldc 545267714
/*      */     //   1167: ior
/*      */     //   1168: iastore
/*      */     //   1169: aload #4
/*      */     //   1171: iload #10
/*      */     //   1173: iconst_1
/*      */     //   1174: isub
/*      */     //   1175: dup2
/*      */     //   1176: iaload
/*      */     //   1177: ldc 541073409
/*      */     //   1179: ior
/*      */     //   1180: iastore
/*      */     //   1181: aload #23
/*      */     //   1183: iload #12
/*      */     //   1185: iaload
/*      */     //   1186: iload #27
/*      */     //   1188: ishr
/*      */     //   1189: iload #26
/*      */     //   1191: ishl
/*      */     //   1192: istore #28
/*      */     //   1194: iload #24
/*      */     //   1196: aload #5
/*      */     //   1198: iload #28
/*      */     //   1200: bipush #63
/*      */     //   1202: iand
/*      */     //   1203: iaload
/*      */     //   1204: iadd
/*      */     //   1205: istore #24
/*      */     //   1207: goto -> 1217
/*      */     //   1210: iload #19
/*      */     //   1212: ldc 1073741824
/*      */     //   1214: ior
/*      */     //   1215: istore #19
/*      */     //   1217: aload #4
/*      */     //   1219: iload #10
/*      */     //   1221: iload #19
/*      */     //   1223: iastore
/*      */     //   1224: iinc #13, 1
/*      */     //   1227: iinc #11, 1
/*      */     //   1230: goto -> 201
/*      */     //   1233: iinc #29, -1
/*      */     //   1236: iload #13
/*      */     //   1238: iload #17
/*      */     //   1240: iadd
/*      */     //   1241: istore #13
/*      */     //   1243: iload #11
/*      */     //   1245: iload #16
/*      */     //   1247: iadd
/*      */     //   1248: istore #11
/*      */     //   1250: goto -> 165
/*      */     //   1253: iload_2
/*      */     //   1254: ifeq -> 1269
/*      */     //   1257: aload #6
/*      */     //   1259: iload #7
/*      */     //   1261: aload_1
/*      */     //   1262: invokevirtual terminate : ()I
/*      */     //   1265: iastore
/*      */     //   1266: goto -> 1278
/*      */     //   1269: aload #6
/*      */     //   1271: iload #7
/*      */     //   1273: aload_1
/*      */     //   1274: invokevirtual length : ()I
/*      */     //   1277: iastore
/*      */     //   1278: iload #8
/*      */     //   1280: iflt -> 1296
/*      */     //   1283: aload #6
/*      */     //   1285: iload #7
/*      */     //   1287: dup2
/*      */     //   1288: iaload
/*      */     //   1289: aload #6
/*      */     //   1291: iload #8
/*      */     //   1293: iaload
/*      */     //   1294: iadd
/*      */     //   1295: iastore
/*      */     //   1296: iload #24
/*      */     //   1298: ireturn
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #2052	-> 0
/*      */     //   #2068	-> 3
/*      */     //   #2069	-> 9
/*      */     //   #2070	-> 17
/*      */     //   #2071	-> 30
/*      */     //   #2072	-> 41
/*      */     //   #2073	-> 46
/*      */     //   #2074	-> 58
/*      */     //   #2075	-> 70
/*      */     //   #2078	-> 73
/*      */     //   #2079	-> 79
/*      */     //   #2080	-> 93
/*      */     //   #2081	-> 106
/*      */     //   #2084	-> 121
/*      */     //   #2085	-> 128
/*      */     //   #2086	-> 135
/*      */     //   #2087	-> 141
/*      */     //   #2090	-> 147
/*      */     //   #2091	-> 153
/*      */     //   #2092	-> 159
/*      */     //   #2093	-> 170
/*      */     //   #2095	-> 192
/*      */     //   #2097	-> 201
/*      */     //   #2099	-> 208
/*      */     //   #2100	-> 212
/*      */     //   #2104	-> 219
/*      */     //   #2105	-> 234
/*      */     //   #2107	-> 238
/*      */     //   #2110	-> 249
/*      */     //   #2111	-> 261
/*      */     //   #2112	-> 267
/*      */     //   #2114	-> 270
/*      */     //   #2117	-> 275
/*      */     //   #2118	-> 285
/*      */     //   #2119	-> 291
/*      */     //   #2125	-> 294
/*      */     //   #2128	-> 299
/*      */     //   #2130	-> 312
/*      */     //   #2134	-> 325
/*      */     //   #2135	-> 330
/*      */     //   #2138	-> 337
/*      */     //   #2141	-> 342
/*      */     //   #2144	-> 355
/*      */     //   #2148	-> 367
/*      */     //   #2154	-> 382
/*      */     //   #2156	-> 389
/*      */     //   #2159	-> 394
/*      */     //   #2162	-> 407
/*      */     //   #2165	-> 419
/*      */     //   #2170	-> 431
/*      */     //   #2171	-> 444
/*      */     //   #2174	-> 460
/*      */     //   #2177	-> 468
/*      */     //   #2178	-> 474
/*      */     //   #2179	-> 481
/*      */     //   #2182	-> 484
/*      */     //   #2184	-> 494
/*      */     //   #2186	-> 501
/*      */     //   #2187	-> 513
/*      */     //   #2188	-> 519
/*      */     //   #2189	-> 522
/*      */     //   #2192	-> 527
/*      */     //   #2193	-> 537
/*      */     //   #2194	-> 543
/*      */     //   #2199	-> 546
/*      */     //   #2200	-> 560
/*      */     //   #2202	-> 574
/*      */     //   #2203	-> 579
/*      */     //   #2206	-> 586
/*      */     //   #2208	-> 600
/*      */     //   #2212	-> 612
/*      */     //   #2218	-> 627
/*      */     //   #2220	-> 634
/*      */     //   #2222	-> 648
/*      */     //   #2225	-> 660
/*      */     //   #2230	-> 672
/*      */     //   #2231	-> 685
/*      */     //   #2234	-> 701
/*      */     //   #2237	-> 708
/*      */     //   #2240	-> 715
/*      */     //   #2241	-> 724
/*      */     //   #2242	-> 731
/*      */     //   #2246	-> 738
/*      */     //   #2247	-> 753
/*      */     //   #2249	-> 762
/*      */     //   #2251	-> 773
/*      */     //   #2252	-> 785
/*      */     //   #2253	-> 791
/*      */     //   #2254	-> 794
/*      */     //   #2257	-> 799
/*      */     //   #2258	-> 809
/*      */     //   #2259	-> 815
/*      */     //   #2264	-> 818
/*      */     //   #2265	-> 831
/*      */     //   #2267	-> 844
/*      */     //   #2268	-> 849
/*      */     //   #2271	-> 856
/*      */     //   #2273	-> 869
/*      */     //   #2277	-> 881
/*      */     //   #2283	-> 896
/*      */     //   #2285	-> 903
/*      */     //   #2287	-> 916
/*      */     //   #2290	-> 928
/*      */     //   #2295	-> 940
/*      */     //   #2296	-> 953
/*      */     //   #2299	-> 969
/*      */     //   #2302	-> 977
/*      */     //   #2303	-> 983
/*      */     //   #2304	-> 990
/*      */     //   #2306	-> 993
/*      */     //   #2308	-> 1003
/*      */     //   #2310	-> 1010
/*      */     //   #2311	-> 1022
/*      */     //   #2312	-> 1028
/*      */     //   #2313	-> 1031
/*      */     //   #2316	-> 1036
/*      */     //   #2317	-> 1046
/*      */     //   #2318	-> 1052
/*      */     //   #2323	-> 1055
/*      */     //   #2324	-> 1069
/*      */     //   #2326	-> 1083
/*      */     //   #2327	-> 1088
/*      */     //   #2330	-> 1095
/*      */     //   #2332	-> 1109
/*      */     //   #2336	-> 1121
/*      */     //   #2342	-> 1136
/*      */     //   #2344	-> 1143
/*      */     //   #2346	-> 1157
/*      */     //   #2349	-> 1169
/*      */     //   #2354	-> 1181
/*      */     //   #2355	-> 1194
/*      */     //   #2358	-> 1210
/*      */     //   #2361	-> 1217
/*      */     //   #2097	-> 1224
/*      */     //   #2092	-> 1233
/*      */     //   #2367	-> 1253
/*      */     //   #2368	-> 1257
/*      */     //   #2370	-> 1269
/*      */     //   #2373	-> 1278
/*      */     //   #2374	-> 1283
/*      */     //   #2378	-> 1296
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   444	16	28	normval	I
/*      */     //   261	207	22	sym	I
/*      */     //   685	16	28	normval	I
/*      */     //   513	195	22	sym	I
/*      */     //   238	477	12	k	I
/*      */     //   953	16	28	normval	I
/*      */     //   785	192	22	sym	I
/*      */     //   1194	16	28	normval	I
/*      */     //   1022	195	22	sym	I
/*      */     //   762	462	12	k	I
/*      */     //   212	1021	10	j	I
/*      */     //   219	1014	19	csj	I
/*      */     //   201	1052	18	stopsk	I
/*      */     //   192	1061	32	sheight	I
/*      */     //   0	1299	0	srcblk	Ljj2000/j2k/wavelet/analysis/CBlkWTData;
/*      */     //   0	1299	1	bout	Ljj2000/j2k/entropy/encoder/BitToByteOutput;
/*      */     //   0	1299	2	doterm	Z
/*      */     //   0	1299	3	bp	I
/*      */     //   0	1299	4	state	[I
/*      */     //   0	1299	5	fs	[I
/*      */     //   0	1299	6	ratebuf	[I
/*      */     //   0	1299	7	pidx	I
/*      */     //   0	1299	8	ltpidx	I
/*      */     //   0	1299	9	options	I
/*      */     //   159	1140	11	sj	I
/*      */     //   153	1146	13	sk	I
/*      */     //   9	1290	14	dscanw	I
/*      */     //   17	1282	15	sscanw	I
/*      */     //   30	1269	16	jstep	I
/*      */     //   41	1258	17	kstep	I
/*      */     //   46	1253	20	mask	I
/*      */     //   3	1296	21	nsym	I
/*      */     //   58	1241	23	data	[I
/*      */     //   73	1226	24	dist	I
/*      */     //   79	1220	25	shift	I
/*      */     //   93	1206	26	upshift	I
/*      */     //   106	1193	27	downshift	I
/*      */     //   165	1134	29	s	I
/*      */     //   121	1178	30	causal	Z
/*      */     //   70	1229	31	nstripes	I
/*      */     //   128	1171	33	off_ul	I
/*      */     //   135	1164	34	off_ur	I
/*      */     //   141	1158	35	off_dr	I
/*      */     //   147	1152	36	off_dl	I
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int magRefPass(CBlkWTData srcblk, MQCoder mq, boolean doterm, int bp, int[] state, int[] fm, int[] symbuf, int[] ctxtbuf, int[] ratebuf, int pidx, int ltpidx, int options) {
/*      */     // Byte code:
/*      */     //   0: iconst_0
/*      */     //   1: istore #16
/*      */     //   3: aload_0
/*      */     //   4: getfield scanw : I
/*      */     //   7: istore #17
/*      */     //   9: aload_0
/*      */     //   10: getfield w : I
/*      */     //   13: iconst_2
/*      */     //   14: iadd
/*      */     //   15: istore #18
/*      */     //   17: iload #18
/*      */     //   19: iconst_4
/*      */     //   20: imul
/*      */     //   21: iconst_2
/*      */     //   22: idiv
/*      */     //   23: aload_0
/*      */     //   24: getfield w : I
/*      */     //   27: isub
/*      */     //   28: istore #19
/*      */     //   30: iload #17
/*      */     //   32: iconst_4
/*      */     //   33: imul
/*      */     //   34: aload_0
/*      */     //   35: getfield w : I
/*      */     //   38: isub
/*      */     //   39: istore #20
/*      */     //   41: iconst_1
/*      */     //   42: iload_3
/*      */     //   43: ishl
/*      */     //   44: istore #23
/*      */     //   46: aload_0
/*      */     //   47: invokevirtual getData : ()Ljava/lang/Object;
/*      */     //   50: checkcast [I
/*      */     //   53: checkcast [I
/*      */     //   56: astore #24
/*      */     //   58: aload_0
/*      */     //   59: getfield h : I
/*      */     //   62: iconst_4
/*      */     //   63: iadd
/*      */     //   64: iconst_1
/*      */     //   65: isub
/*      */     //   66: iconst_4
/*      */     //   67: idiv
/*      */     //   68: istore #31
/*      */     //   70: iconst_0
/*      */     //   71: istore #25
/*      */     //   73: iload_3
/*      */     //   74: bipush #6
/*      */     //   76: isub
/*      */     //   77: istore #26
/*      */     //   79: iload #26
/*      */     //   81: iflt -> 88
/*      */     //   84: iconst_0
/*      */     //   85: goto -> 91
/*      */     //   88: iload #26
/*      */     //   90: ineg
/*      */     //   91: istore #27
/*      */     //   93: iload #26
/*      */     //   95: ifgt -> 102
/*      */     //   98: iconst_0
/*      */     //   99: goto -> 104
/*      */     //   102: iload #26
/*      */     //   104: istore #28
/*      */     //   106: aload_0
/*      */     //   107: getfield offset : I
/*      */     //   110: istore #15
/*      */     //   112: iload #18
/*      */     //   114: iconst_1
/*      */     //   115: iadd
/*      */     //   116: istore #13
/*      */     //   118: iload #31
/*      */     //   120: iconst_1
/*      */     //   121: isub
/*      */     //   122: istore #30
/*      */     //   124: iload #30
/*      */     //   126: iflt -> 666
/*      */     //   129: iload #30
/*      */     //   131: ifeq -> 138
/*      */     //   134: iconst_4
/*      */     //   135: goto -> 149
/*      */     //   138: aload_0
/*      */     //   139: getfield h : I
/*      */     //   142: iload #31
/*      */     //   144: iconst_1
/*      */     //   145: isub
/*      */     //   146: iconst_4
/*      */     //   147: imul
/*      */     //   148: isub
/*      */     //   149: istore #32
/*      */     //   151: iload #15
/*      */     //   153: aload_0
/*      */     //   154: getfield w : I
/*      */     //   157: iadd
/*      */     //   158: istore #21
/*      */     //   160: iconst_0
/*      */     //   161: istore #16
/*      */     //   163: iload #15
/*      */     //   165: iload #21
/*      */     //   167: if_icmpge -> 631
/*      */     //   170: iload #13
/*      */     //   172: istore #12
/*      */     //   174: aload #4
/*      */     //   176: iload #12
/*      */     //   178: iaload
/*      */     //   179: istore #22
/*      */     //   181: iload #22
/*      */     //   183: iconst_1
/*      */     //   184: iushr
/*      */     //   185: iload #22
/*      */     //   187: iconst_m1
/*      */     //   188: ixor
/*      */     //   189: iand
/*      */     //   190: ldc 1073758208
/*      */     //   192: iand
/*      */     //   193: ifeq -> 386
/*      */     //   196: iload #15
/*      */     //   198: istore #14
/*      */     //   200: iload #22
/*      */     //   202: ldc 49152
/*      */     //   204: iand
/*      */     //   205: ldc 32768
/*      */     //   207: if_icmpne -> 277
/*      */     //   210: aload #6
/*      */     //   212: iload #16
/*      */     //   214: aload #24
/*      */     //   216: iload #14
/*      */     //   218: iaload
/*      */     //   219: iload #23
/*      */     //   221: iand
/*      */     //   222: iload_3
/*      */     //   223: iushr
/*      */     //   224: iastore
/*      */     //   225: aload #7
/*      */     //   227: iload #16
/*      */     //   229: iinc #16, 1
/*      */     //   232: getstatic jj2000/j2k/entropy/encoder/StdEntropyCoder.MR_LUT : [I
/*      */     //   235: iload #22
/*      */     //   237: sipush #511
/*      */     //   240: iand
/*      */     //   241: iaload
/*      */     //   242: iastore
/*      */     //   243: iload #22
/*      */     //   245: sipush #256
/*      */     //   248: ior
/*      */     //   249: istore #22
/*      */     //   251: aload #24
/*      */     //   253: iload #14
/*      */     //   255: iaload
/*      */     //   256: iload #28
/*      */     //   258: ishr
/*      */     //   259: iload #27
/*      */     //   261: ishl
/*      */     //   262: istore #29
/*      */     //   264: iload #25
/*      */     //   266: aload #5
/*      */     //   268: iload #29
/*      */     //   270: bipush #127
/*      */     //   272: iand
/*      */     //   273: iaload
/*      */     //   274: iadd
/*      */     //   275: istore #25
/*      */     //   277: iload #32
/*      */     //   279: iconst_2
/*      */     //   280: if_icmpge -> 293
/*      */     //   283: aload #4
/*      */     //   285: iload #12
/*      */     //   287: iload #22
/*      */     //   289: iastore
/*      */     //   290: goto -> 622
/*      */     //   293: iload #22
/*      */     //   295: ldc -1073741824
/*      */     //   297: iand
/*      */     //   298: ldc -2147483648
/*      */     //   300: if_icmpne -> 379
/*      */     //   303: iload #14
/*      */     //   305: iload #17
/*      */     //   307: iadd
/*      */     //   308: istore #14
/*      */     //   310: aload #6
/*      */     //   312: iload #16
/*      */     //   314: aload #24
/*      */     //   316: iload #14
/*      */     //   318: iaload
/*      */     //   319: iload #23
/*      */     //   321: iand
/*      */     //   322: iload_3
/*      */     //   323: iushr
/*      */     //   324: iastore
/*      */     //   325: aload #7
/*      */     //   327: iload #16
/*      */     //   329: iinc #16, 1
/*      */     //   332: getstatic jj2000/j2k/entropy/encoder/StdEntropyCoder.MR_LUT : [I
/*      */     //   335: iload #22
/*      */     //   337: bipush #16
/*      */     //   339: iushr
/*      */     //   340: sipush #511
/*      */     //   343: iand
/*      */     //   344: iaload
/*      */     //   345: iastore
/*      */     //   346: iload #22
/*      */     //   348: ldc 16777216
/*      */     //   350: ior
/*      */     //   351: istore #22
/*      */     //   353: aload #24
/*      */     //   355: iload #14
/*      */     //   357: iaload
/*      */     //   358: iload #28
/*      */     //   360: ishr
/*      */     //   361: iload #27
/*      */     //   363: ishl
/*      */     //   364: istore #29
/*      */     //   366: iload #25
/*      */     //   368: aload #5
/*      */     //   370: iload #29
/*      */     //   372: bipush #127
/*      */     //   374: iand
/*      */     //   375: iaload
/*      */     //   376: iadd
/*      */     //   377: istore #25
/*      */     //   379: aload #4
/*      */     //   381: iload #12
/*      */     //   383: iload #22
/*      */     //   385: iastore
/*      */     //   386: iload #32
/*      */     //   388: iconst_3
/*      */     //   389: if_icmpge -> 395
/*      */     //   392: goto -> 622
/*      */     //   395: iload #12
/*      */     //   397: iload #18
/*      */     //   399: iadd
/*      */     //   400: istore #12
/*      */     //   402: aload #4
/*      */     //   404: iload #12
/*      */     //   406: iaload
/*      */     //   407: istore #22
/*      */     //   409: iload #22
/*      */     //   411: iconst_1
/*      */     //   412: iushr
/*      */     //   413: iload #22
/*      */     //   415: iconst_m1
/*      */     //   416: ixor
/*      */     //   417: iand
/*      */     //   418: ldc 1073758208
/*      */     //   420: iand
/*      */     //   421: ifeq -> 622
/*      */     //   424: iload #15
/*      */     //   426: iload #17
/*      */     //   428: iconst_1
/*      */     //   429: ishl
/*      */     //   430: iadd
/*      */     //   431: istore #14
/*      */     //   433: iload #22
/*      */     //   435: ldc 49152
/*      */     //   437: iand
/*      */     //   438: ldc 32768
/*      */     //   440: if_icmpne -> 510
/*      */     //   443: aload #6
/*      */     //   445: iload #16
/*      */     //   447: aload #24
/*      */     //   449: iload #14
/*      */     //   451: iaload
/*      */     //   452: iload #23
/*      */     //   454: iand
/*      */     //   455: iload_3
/*      */     //   456: iushr
/*      */     //   457: iastore
/*      */     //   458: aload #7
/*      */     //   460: iload #16
/*      */     //   462: iinc #16, 1
/*      */     //   465: getstatic jj2000/j2k/entropy/encoder/StdEntropyCoder.MR_LUT : [I
/*      */     //   468: iload #22
/*      */     //   470: sipush #511
/*      */     //   473: iand
/*      */     //   474: iaload
/*      */     //   475: iastore
/*      */     //   476: iload #22
/*      */     //   478: sipush #256
/*      */     //   481: ior
/*      */     //   482: istore #22
/*      */     //   484: aload #24
/*      */     //   486: iload #14
/*      */     //   488: iaload
/*      */     //   489: iload #28
/*      */     //   491: ishr
/*      */     //   492: iload #27
/*      */     //   494: ishl
/*      */     //   495: istore #29
/*      */     //   497: iload #25
/*      */     //   499: aload #5
/*      */     //   501: iload #29
/*      */     //   503: bipush #127
/*      */     //   505: iand
/*      */     //   506: iaload
/*      */     //   507: iadd
/*      */     //   508: istore #25
/*      */     //   510: iload #32
/*      */     //   512: iconst_4
/*      */     //   513: if_icmpge -> 526
/*      */     //   516: aload #4
/*      */     //   518: iload #12
/*      */     //   520: iload #22
/*      */     //   522: iastore
/*      */     //   523: goto -> 622
/*      */     //   526: aload #4
/*      */     //   528: iload #12
/*      */     //   530: iaload
/*      */     //   531: ldc -1073741824
/*      */     //   533: iand
/*      */     //   534: ldc -2147483648
/*      */     //   536: if_icmpne -> 615
/*      */     //   539: iload #14
/*      */     //   541: iload #17
/*      */     //   543: iadd
/*      */     //   544: istore #14
/*      */     //   546: aload #6
/*      */     //   548: iload #16
/*      */     //   550: aload #24
/*      */     //   552: iload #14
/*      */     //   554: iaload
/*      */     //   555: iload #23
/*      */     //   557: iand
/*      */     //   558: iload_3
/*      */     //   559: iushr
/*      */     //   560: iastore
/*      */     //   561: aload #7
/*      */     //   563: iload #16
/*      */     //   565: iinc #16, 1
/*      */     //   568: getstatic jj2000/j2k/entropy/encoder/StdEntropyCoder.MR_LUT : [I
/*      */     //   571: iload #22
/*      */     //   573: bipush #16
/*      */     //   575: iushr
/*      */     //   576: sipush #511
/*      */     //   579: iand
/*      */     //   580: iaload
/*      */     //   581: iastore
/*      */     //   582: iload #22
/*      */     //   584: ldc 16777216
/*      */     //   586: ior
/*      */     //   587: istore #22
/*      */     //   589: aload #24
/*      */     //   591: iload #14
/*      */     //   593: iaload
/*      */     //   594: iload #28
/*      */     //   596: ishr
/*      */     //   597: iload #27
/*      */     //   599: ishl
/*      */     //   600: istore #29
/*      */     //   602: iload #25
/*      */     //   604: aload #5
/*      */     //   606: iload #29
/*      */     //   608: bipush #127
/*      */     //   610: iand
/*      */     //   611: iaload
/*      */     //   612: iadd
/*      */     //   613: istore #25
/*      */     //   615: aload #4
/*      */     //   617: iload #12
/*      */     //   619: iload #22
/*      */     //   621: iastore
/*      */     //   622: iinc #15, 1
/*      */     //   625: iinc #13, 1
/*      */     //   628: goto -> 163
/*      */     //   631: iload #16
/*      */     //   633: ifle -> 646
/*      */     //   636: aload_1
/*      */     //   637: aload #6
/*      */     //   639: aload #7
/*      */     //   641: iload #16
/*      */     //   643: invokevirtual codeSymbols : ([I[II)V
/*      */     //   646: iinc #30, -1
/*      */     //   649: iload #15
/*      */     //   651: iload #20
/*      */     //   653: iadd
/*      */     //   654: istore #15
/*      */     //   656: iload #13
/*      */     //   658: iload #19
/*      */     //   660: iadd
/*      */     //   661: istore #13
/*      */     //   663: goto -> 124
/*      */     //   666: iload #11
/*      */     //   668: iconst_2
/*      */     //   669: iand
/*      */     //   670: ifeq -> 677
/*      */     //   673: aload_1
/*      */     //   674: invokevirtual resetCtxts : ()V
/*      */     //   677: iload_2
/*      */     //   678: ifeq -> 693
/*      */     //   681: aload #8
/*      */     //   683: iload #9
/*      */     //   685: aload_1
/*      */     //   686: invokevirtual terminate : ()I
/*      */     //   689: iastore
/*      */     //   690: goto -> 702
/*      */     //   693: aload #8
/*      */     //   695: iload #9
/*      */     //   697: aload_1
/*      */     //   698: invokevirtual getNumCodedBytes : ()I
/*      */     //   701: iastore
/*      */     //   702: iload #10
/*      */     //   704: iflt -> 720
/*      */     //   707: aload #8
/*      */     //   709: iload #9
/*      */     //   711: dup2
/*      */     //   712: iaload
/*      */     //   713: aload #8
/*      */     //   715: iload #10
/*      */     //   717: iaload
/*      */     //   718: iadd
/*      */     //   719: iastore
/*      */     //   720: iload_2
/*      */     //   721: ifeq -> 732
/*      */     //   724: aload_1
/*      */     //   725: aload #8
/*      */     //   727: iload #9
/*      */     //   729: invokevirtual finishLengthCalculation : ([II)V
/*      */     //   732: iload #25
/*      */     //   734: ireturn
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #2426	-> 0
/*      */     //   #2445	-> 3
/*      */     //   #2446	-> 9
/*      */     //   #2447	-> 17
/*      */     //   #2448	-> 30
/*      */     //   #2449	-> 41
/*      */     //   #2450	-> 46
/*      */     //   #2451	-> 58
/*      */     //   #2452	-> 70
/*      */     //   #2455	-> 73
/*      */     //   #2456	-> 79
/*      */     //   #2457	-> 93
/*      */     //   #2460	-> 106
/*      */     //   #2461	-> 112
/*      */     //   #2462	-> 118
/*      */     //   #2463	-> 129
/*      */     //   #2465	-> 151
/*      */     //   #2467	-> 160
/*      */     //   #2469	-> 170
/*      */     //   #2470	-> 174
/*      */     //   #2473	-> 181
/*      */     //   #2474	-> 196
/*      */     //   #2476	-> 200
/*      */     //   #2479	-> 210
/*      */     //   #2480	-> 225
/*      */     //   #2482	-> 243
/*      */     //   #2484	-> 251
/*      */     //   #2485	-> 264
/*      */     //   #2487	-> 277
/*      */     //   #2488	-> 283
/*      */     //   #2489	-> 290
/*      */     //   #2492	-> 293
/*      */     //   #2494	-> 303
/*      */     //   #2496	-> 310
/*      */     //   #2497	-> 325
/*      */     //   #2499	-> 346
/*      */     //   #2501	-> 353
/*      */     //   #2502	-> 366
/*      */     //   #2504	-> 379
/*      */     //   #2507	-> 386
/*      */     //   #2508	-> 395
/*      */     //   #2509	-> 402
/*      */     //   #2512	-> 409
/*      */     //   #2513	-> 424
/*      */     //   #2515	-> 433
/*      */     //   #2518	-> 443
/*      */     //   #2519	-> 458
/*      */     //   #2521	-> 476
/*      */     //   #2523	-> 484
/*      */     //   #2524	-> 497
/*      */     //   #2526	-> 510
/*      */     //   #2527	-> 516
/*      */     //   #2528	-> 523
/*      */     //   #2531	-> 526
/*      */     //   #2533	-> 539
/*      */     //   #2535	-> 546
/*      */     //   #2536	-> 561
/*      */     //   #2538	-> 582
/*      */     //   #2540	-> 589
/*      */     //   #2541	-> 602
/*      */     //   #2543	-> 615
/*      */     //   #2467	-> 622
/*      */     //   #2547	-> 631
/*      */     //   #2462	-> 646
/*      */     //   #2551	-> 666
/*      */     //   #2552	-> 673
/*      */     //   #2556	-> 677
/*      */     //   #2557	-> 681
/*      */     //   #2560	-> 693
/*      */     //   #2563	-> 702
/*      */     //   #2564	-> 707
/*      */     //   #2567	-> 720
/*      */     //   #2568	-> 724
/*      */     //   #2572	-> 732
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   264	13	29	normval	I
/*      */     //   366	13	29	normval	I
/*      */     //   200	186	14	k	I
/*      */     //   497	13	29	normval	I
/*      */     //   602	13	29	normval	I
/*      */     //   433	189	14	k	I
/*      */     //   174	457	12	j	I
/*      */     //   181	450	22	csj	I
/*      */     //   160	506	21	stopsk	I
/*      */     //   151	515	32	sheight	I
/*      */     //   0	735	0	srcblk	Ljj2000/j2k/wavelet/analysis/CBlkWTData;
/*      */     //   0	735	1	mq	Ljj2000/j2k/entropy/encoder/MQCoder;
/*      */     //   0	735	2	doterm	Z
/*      */     //   0	735	3	bp	I
/*      */     //   0	735	4	state	[I
/*      */     //   0	735	5	fm	[I
/*      */     //   0	735	6	symbuf	[I
/*      */     //   0	735	7	ctxtbuf	[I
/*      */     //   0	735	8	ratebuf	[I
/*      */     //   0	735	9	pidx	I
/*      */     //   0	735	10	ltpidx	I
/*      */     //   0	735	11	options	I
/*      */     //   118	617	13	sj	I
/*      */     //   112	623	15	sk	I
/*      */     //   3	732	16	nsym	I
/*      */     //   9	726	17	dscanw	I
/*      */     //   17	718	18	sscanw	I
/*      */     //   30	705	19	jstep	I
/*      */     //   41	694	20	kstep	I
/*      */     //   46	689	23	mask	I
/*      */     //   58	677	24	data	[I
/*      */     //   73	662	25	dist	I
/*      */     //   79	656	26	shift	I
/*      */     //   93	642	27	upshift	I
/*      */     //   106	629	28	downshift	I
/*      */     //   124	611	30	s	I
/*      */     //   70	665	31	nstripes	I
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int rawMagRefPass(CBlkWTData srcblk, BitToByteOutput bout, boolean doterm, int bp, int[] state, int[] fm, int[] ratebuf, int pidx, int ltpidx, int options) {
/* 2639 */     int nsym = 0;
/*      */ 
/*      */     
/* 2642 */     int dscanw = srcblk.scanw;
/* 2643 */     int sscanw = srcblk.w + 2;
/* 2644 */     int jstep = sscanw * 4 / 2 - srcblk.w;
/* 2645 */     int kstep = dscanw * 4 - srcblk.w;
/* 2646 */     int mask = 1 << bp;
/* 2647 */     int[] data = (int[])srcblk.getData();
/* 2648 */     int nstripes = (srcblk.h + 4 - 1) / 4;
/* 2649 */     int dist = 0;
/*      */ 
/*      */     
/* 2652 */     int shift = bp - 6;
/* 2653 */     int upshift = (shift >= 0) ? 0 : -shift;
/* 2654 */     int downshift = (shift <= 0) ? 0 : shift;
/*      */ 
/*      */     
/* 2657 */     int sk = srcblk.offset;
/* 2658 */     int sj = sscanw + 1;
/* 2659 */     for (int s = nstripes - 1; s >= 0; s--, sk += kstep, sj += jstep) {
/* 2660 */       int sheight = (s != 0) ? 4 : (srcblk.h - (nstripes - 1) * 4);
/*      */       
/* 2662 */       int stopsk = sk + srcblk.w;
/*      */       
/* 2664 */       for (; sk < stopsk; sk++, sj++) {
/*      */         
/* 2666 */         int j = sj;
/* 2667 */         int csj = state[j];
/*      */ 
/*      */         
/* 2670 */         if ((csj >>> 1 & (csj ^ 0xFFFFFFFF) & 0x40004000) != 0) {
/* 2671 */           int k = sk;
/*      */           
/* 2673 */           if ((csj & 0xC000) == 32768) {
/*      */ 
/*      */             
/* 2676 */             bout.writeBit((data[k] & mask) >>> bp);
/* 2677 */             nsym++;
/*      */ 
/*      */ 
/*      */             
/* 2681 */             int normval = data[k] >> downshift << upshift;
/* 2682 */             dist += fm[normval & 0x7F];
/*      */           } 
/* 2684 */           if (sheight < 2)
/*      */             continue; 
/* 2686 */           if ((csj & 0xC0000000) == Integer.MIN_VALUE) {
/*      */             
/* 2688 */             k += dscanw;
/*      */             
/* 2690 */             bout.writeBit((data[k] & mask) >>> bp);
/* 2691 */             nsym++;
/*      */ 
/*      */ 
/*      */             
/* 2695 */             int normval = data[k] >> downshift << upshift;
/* 2696 */             dist += fm[normval & 0x7F];
/*      */           } 
/*      */         } 
/*      */         
/* 2700 */         if (sheight >= 3) {
/* 2701 */           j += sscanw;
/* 2702 */           csj = state[j];
/*      */ 
/*      */           
/* 2705 */           if ((csj >>> 1 & (csj ^ 0xFFFFFFFF) & 0x40004000) != 0) {
/* 2706 */             int k = sk + (dscanw << 1);
/*      */             
/* 2708 */             if ((csj & 0xC000) == 32768) {
/*      */ 
/*      */               
/* 2711 */               bout.writeBit((data[k] & mask) >>> bp);
/* 2712 */               nsym++;
/*      */ 
/*      */ 
/*      */               
/* 2716 */               int normval = data[k] >> downshift << upshift;
/* 2717 */               dist += fm[normval & 0x7F];
/*      */             } 
/* 2719 */             if (sheight >= 4)
/*      */             {
/* 2721 */               if ((state[j] & 0xC0000000) == Integer.MIN_VALUE) {
/*      */                 
/* 2723 */                 k += dscanw;
/*      */                 
/* 2725 */                 bout.writeBit((data[k] & mask) >>> bp);
/* 2726 */                 nsym++;
/*      */ 
/*      */ 
/*      */                 
/* 2730 */                 int normval = data[k] >> downshift << upshift;
/* 2731 */                 dist += fm[normval & 0x7F];
/*      */               }  } 
/*      */           } 
/*      */         } 
/*      */         continue;
/*      */       } 
/*      */     } 
/* 2738 */     if (doterm) {
/* 2739 */       ratebuf[pidx] = bout.terminate();
/*      */     } else {
/* 2741 */       ratebuf[pidx] = bout.length();
/*      */     } 
/*      */ 
/*      */     
/* 2745 */     if (ltpidx >= 0) {
/* 2746 */       ratebuf[pidx] = ratebuf[pidx] + ratebuf[ltpidx];
/*      */     }
/*      */ 
/*      */     
/* 2750 */     return dist;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int cleanuppass(CBlkWTData srcblk, MQCoder mq, boolean doterm, int bp, int[] state, int[] fs, int[] zc_lut, int[] symbuf, int[] ctxtbuf, int[] ratebuf, int pidx, int ltpidx, int options) {
/* 2806 */     int nsym = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2831 */     int dscanw = srcblk.scanw;
/* 2832 */     int sscanw = srcblk.w + 2;
/* 2833 */     int jstep = sscanw * 4 / 2 - srcblk.w;
/* 2834 */     int kstep = dscanw * 4 - srcblk.w;
/* 2835 */     int mask = 1 << bp;
/* 2836 */     int[] data = (int[])srcblk.getData();
/* 2837 */     int nstripes = (srcblk.h + 4 - 1) / 4;
/* 2838 */     int dist = 0;
/*      */ 
/*      */     
/* 2841 */     int shift = bp - 6;
/* 2842 */     int upshift = (shift >= 0) ? 0 : -shift;
/* 2843 */     int downshift = (shift <= 0) ? 0 : shift;
/* 2844 */     boolean causal = ((options & 0x8) != 0);
/*      */ 
/*      */     
/* 2847 */     int off_ul = -sscanw - 1;
/* 2848 */     int off_ur = -sscanw + 1;
/* 2849 */     int off_dr = sscanw + 1;
/* 2850 */     int off_dl = sscanw - 1;
/*      */ 
/*      */     
/* 2853 */     int sk = srcblk.offset;
/* 2854 */     int sj = sscanw + 1;
/* 2855 */     for (int s = nstripes - 1; s >= 0; s--, sk += kstep, sj += jstep) {
/* 2856 */       int sheight = (s != 0) ? 4 : (srcblk.h - (nstripes - 1) * 4);
/*      */       
/* 2858 */       int stopsk = sk + srcblk.w;
/*      */       
/* 2860 */       nsym = 0; while (true) { sk++; sj++; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3283 */       if (nsym > 0) mq.codeSymbols(symbuf, ctxtbuf, nsym);
/*      */       
/*      */       continue;
/*      */     } 
/* 3287 */     if ((options & 0x20) != 0) {
/* 3288 */       mq.codeSymbols(SEG_SYMBOLS, SEG_SYMB_CTXTS, SEG_SYMBOLS.length);
/*      */     }
/*      */ 
/*      */     
/* 3292 */     if ((options & 0x2) != 0) {
/* 3293 */       mq.resetCtxts();
/*      */     }
/*      */ 
/*      */     
/* 3297 */     if (doterm) {
/* 3298 */       ratebuf[pidx] = mq.terminate();
/*      */     } else {
/*      */       
/* 3301 */       ratebuf[pidx] = mq.getNumCodedBytes();
/*      */     } 
/*      */     
/* 3304 */     if (ltpidx >= 0) {
/* 3305 */       ratebuf[pidx] = ratebuf[pidx] + ratebuf[ltpidx];
/*      */     }
/*      */     
/* 3308 */     if (doterm) {
/* 3309 */       mq.finishLengthCalculation(ratebuf, pidx);
/*      */     }
/*      */ 
/*      */     
/* 3313 */     return dist;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void checkEndOfPassFF(byte[] data, int[] rates, boolean[] isterm, int n) {
/* 3357 */     if (isterm == null) {
/* 3358 */       for (; --n >= 0; n--) {
/* 3359 */         int dp = rates[n] - 1;
/* 3360 */         if (dp >= 0 && data[dp] == -1) {
/* 3361 */           rates[n] = rates[n] - 1;
/*      */         }
/*      */       } 
/*      */     } else {
/*      */       
/* 3366 */       for (; --n >= 0; n--) {
/* 3367 */         if (!isterm[n]) {
/* 3368 */           int dp = rates[n] - 1;
/* 3369 */           if (dp >= 0 && data[dp] == -1) {
/* 3370 */             rates[n] = rates[n] - 1;
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void initTileComp(int nt, int nc) {
/* 3387 */     this.opts = new int[nt][nc];
/* 3388 */     this.lenCalc = new int[nt][nc];
/* 3389 */     this.tType = new int[nt][nc];
/*      */     
/* 3391 */     for (int t = 0; t < nt; t++) {
/* 3392 */       for (int c = 0; c < nc; c++) {
/* 3393 */         this.opts[t][c] = 0;
/*      */ 
/*      */         
/* 3396 */         if (((String)this.bms.getTileCompVal(t, c)).equalsIgnoreCase("true"))
/*      */         {
/* 3398 */           this.opts[t][c] = this.opts[t][c] | 0x1;
/*      */         }
/*      */         
/* 3401 */         if (((String)this.mqrs.getTileCompVal(t, c)).equalsIgnoreCase("true"))
/*      */         {
/* 3403 */           this.opts[t][c] = this.opts[t][c] | 0x2;
/*      */         }
/*      */         
/* 3406 */         if (((String)this.rts.getTileCompVal(t, c)).equalsIgnoreCase("true"))
/*      */         {
/* 3408 */           this.opts[t][c] = this.opts[t][c] | 0x4;
/*      */         }
/*      */         
/* 3411 */         if (((String)this.css.getTileCompVal(t, c)).equalsIgnoreCase("true"))
/*      */         {
/* 3413 */           this.opts[t][c] = this.opts[t][c] | 0x8;
/*      */         }
/*      */         
/* 3416 */         if (((String)this.sss.getTileCompVal(t, c)).equalsIgnoreCase("true"))
/*      */         {
/* 3418 */           this.opts[t][c] = this.opts[t][c] | 0x20;
/*      */         }
/*      */ 
/*      */         
/* 3422 */         String lCalcType = (String)this.lcs.getTileCompVal(t, c);
/* 3423 */         if (lCalcType.equals("near_opt")) {
/* 3424 */           this.lenCalc[t][c] = 2;
/*      */         }
/* 3426 */         else if (lCalcType.equals("lazy_good")) {
/* 3427 */           this.lenCalc[t][c] = 1;
/*      */         }
/* 3429 */         else if (lCalcType.equals("lazy")) {
/* 3430 */           this.lenCalc[t][c] = 0;
/*      */         } else {
/*      */           
/* 3433 */           throw new IllegalArgumentException("Unrecognized or unsupported MQ length calculation.");
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3439 */         String termType = (String)this.tts.getTileCompVal(t, c);
/* 3440 */         if (termType.equalsIgnoreCase("easy")) {
/* 3441 */           this.tType[t][c] = 2;
/*      */         }
/* 3443 */         else if (termType.equalsIgnoreCase("full")) {
/* 3444 */           this.tType[t][c] = 0;
/*      */         }
/* 3446 */         else if (termType.equalsIgnoreCase("near_opt")) {
/* 3447 */           this.tType[t][c] = 1;
/*      */         }
/* 3449 */         else if (termType.equalsIgnoreCase("predict")) {
/* 3450 */           this.tType[t][c] = 3;
/* 3451 */           this.opts[t][c] = this.opts[t][c] | 0x10;
/* 3452 */           if ((this.opts[t][c] & 0x5) == 0) {
/* 3453 */             FacilityManager.getMsgLogger().printmsg(1, "Using error resilient MQ termination, but terminating only at the end of code-blocks. The error protection offered by this option will be very weak. Specify the 'Creg_term' and/or 'Cbypass' option for increased error resilience.");
/*      */ 
/*      */           
/*      */           }
/*      */ 
/*      */         
/*      */         }
/*      */         else {
/*      */ 
/*      */ 
/*      */           
/* 3464 */           throw new IllegalArgumentException("Unrecognized or unsupported MQ coder termination.");
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getPPX(int t, int c, int rl) {
/* 3487 */     return this.pss.getPPX(t, c, rl);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getPPY(int t, int c, int rl) {
/* 3504 */     return this.pss.getPPY(t, c, rl);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean precinctPartitionUsed(int c, int t) {
/* 3519 */     return this.precinctPartition[c][t];
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/entropy/encoder/StdEntropyCoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */