/*     */ package jj2000.j2k.entropy.encoder;
/*     */ 
/*     */ import com.sun.media.imageioimpl.plugins.jpeg2000.J2KImageWriteParamJava;
/*     */ import java.io.IOException;
/*     */ import java.io.StreamTokenizer;
/*     */ import java.io.StringReader;
/*     */ import jj2000.j2k.codestream.writer.CodestreamWriter;
/*     */ import jj2000.j2k.codestream.writer.HeaderEncoder;
/*     */ import jj2000.j2k.image.ImgData;
/*     */ import jj2000.j2k.image.ImgDataAdapter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class PostCompRateAllocator
/*     */   extends ImgDataAdapter
/*     */ {
/*     */   public static final char OPT_PREFIX = 'A';
/* 117 */   private static final String[][] pinfo = new String[][] { { "Aptype", "[<tile idx>] res|layer|res-pos|pos-comp|comp-pos [res_start comp_start layer_end res_end comp_end prog] [[res_start comp_start ly_end res_end comp_end prog] ...] [[<tile-component idx>] ...]", "Specifies which type of progression should be used when generating the codestream. The 'res' value generates a resolution progressive codestream with the number of layers specified by 'Alayers' option. The 'layer' value generates a layer progressive codestream with multiple layers. In any case the rate-allocation algorithm optimizes for best quality in each layer. The quality measure is mean squared error (MSE) or a weighted version of it (WMSE). If no progression type is specified or imposed by other modules, the default value is 'layer'.\nIt is also possible to describe progression order changes. In this case, 'res_start' is the index (from 0) of the first resolution level, 'comp_start' is the index (from 0) of the first component, 'ly_end' is the index (from 0) of the first layer not included, 'res_end' is the index (from 0) of the first resolution level not included, 'comp_end' is index (from 0) of the first component not included and 'prog' is the progression type to be used for the rest of the tile/image. Several progression order changes can be specified, one after the other.", null }, { "Alayers", "<rate> [+<layers>] [<rate [+<layers>] [...]]", "Explicitly specifies the codestream layer formation parameters. The <rate> parameter specifies the bitrate to which the first layer should be optimized. The <layers> parameter, if present, specifies the number of extra layers that should be added for scalability. These extra layers are not optimized. Any extra <rate> and <layers> parameters add more layers, in the same way. An additional layer is always added at the end, which is optimized to the overall target bitrate of the bit stream. Any layers (optimized or not) whose target bitrate is higher that the overall target bitrate are silently ignored. The bitrates of the extra layers that are added through the <layers> parameter are approximately log-spaced between the other target bitrates. If several <rate> [+<layers>] constructs appear the <rate> parameters must appear in increasing order. The rate allocation algorithm ensures that all coded layers have a minimal reasonable size, if not these layers are silently ignored.", "0.015 +20 2.0 +10" } };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected CodedCBlkDataSrcEnc src;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected J2KImageWriteParamJava wp;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int numLayers;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   CodestreamWriter bsWriter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   HeaderEncoder headEnc;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PostCompRateAllocator(CodedCBlkDataSrcEnc src, int nl, CodestreamWriter bw, J2KImageWriteParamJava wp) {
/* 195 */     super((ImgData)src);
/* 196 */     this.src = src;
/* 197 */     this.wp = wp;
/* 198 */     this.numLayers = nl;
/* 199 */     this.bsWriter = bw;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHeaderEncoder(HeaderEncoder headEnc) {
/* 208 */     this.headEnc = headEnc;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void initialize() throws IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void runAndWrite() throws IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNumLayers() {
/* 238 */     return this.numLayers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[][] getParameterInfo() {
/* 255 */     return pinfo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PostCompRateAllocator createInstance(CodedCBlkDataSrcEnc src, float rate, CodestreamWriter bw, J2KImageWriteParamJava wp) {
/* 277 */     String lyropt = wp.getLayers();
/* 278 */     if (lyropt == null) {
/* 279 */       if (wp.getROIs().getSpecified() == null) {
/* 280 */         lyropt = "res";
/*     */       } else {
/*     */         
/* 283 */         lyropt = "layer";
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 288 */     LayersInfo lyrs = parseAlayers(lyropt, rate);
/*     */     
/* 290 */     int nTiles = wp.getNumTiles();
/* 291 */     int nComp = wp.getNumComponents();
/* 292 */     int numLayers = lyrs.getTotNumLayers();
/*     */ 
/*     */     
/* 295 */     wp.setProgressionType(lyrs, wp.getProgressionName());
/*     */     
/* 297 */     return new EBCOTRateAllocator(src, lyrs, bw, wp);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static LayersInfo parseAlayers(String params, float rate) {
/* 315 */     LayersInfo lyrs = new LayersInfo(rate);
/* 316 */     StreamTokenizer stok = new StreamTokenizer(new StringReader(params));
/* 317 */     stok.eolIsSignificant(false);
/*     */     
/*     */     try {
/* 320 */       stok.nextToken();
/*     */     }
/* 322 */     catch (IOException e) {
/* 323 */       throw new Error("An IOException has ocurred where it should never occur");
/*     */     } 
/*     */     
/* 326 */     boolean ratepending = false;
/* 327 */     boolean islayer = false;
/* 328 */     float r = 0.0F;
/* 329 */     while (stok.ttype != -1) {
/* 330 */       switch (stok.ttype) {
/*     */         case -2:
/* 332 */           if (islayer) {
/*     */             try {
/* 334 */               lyrs.addOptPoint(r, (int)stok.nval);
/*     */             }
/* 336 */             catch (IllegalArgumentException e) {
/* 337 */               throw new IllegalArgumentException("Error in 'Alayers' option: " + e.getMessage());
/*     */             } 
/*     */ 
/*     */             
/* 341 */             ratepending = false;
/* 342 */             islayer = false;
/*     */             break;
/*     */           } 
/* 345 */           if (ratepending) {
/*     */             try {
/* 347 */               lyrs.addOptPoint(r, 0);
/*     */             }
/* 349 */             catch (IllegalArgumentException e) {
/* 350 */               throw new IllegalArgumentException("Error in 'Alayers' option: " + e.getMessage());
/*     */             } 
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 357 */           r = (float)stok.nval;
/* 358 */           ratepending = true;
/*     */           break;
/*     */         
/*     */         case 43:
/* 362 */           if (!ratepending || islayer) {
/* 363 */             throw new IllegalArgumentException("Layer parameter without previous rate parameter in 'Alayers' option");
/*     */           }
/*     */ 
/*     */ 
/*     */           
/* 368 */           islayer = true;
/*     */           break;
/*     */         case -3:
/*     */           try {
/* 372 */             stok.nextToken();
/* 373 */           } catch (IOException e) {
/* 374 */             throw new Error("An IOException has ocurred where it should never occur");
/*     */           } 
/*     */           
/* 377 */           if (stok.ttype != -1) {
/* 378 */             throw new IllegalArgumentException("'sl' argument of '-Alayers' option must be used alone.");
/*     */           }
/*     */           break;
/*     */ 
/*     */ 
/*     */         
/*     */         default:
/* 385 */           throw new IllegalArgumentException("Error parsing 'Alayers' option");
/*     */       } 
/*     */       
/*     */       try {
/* 389 */         stok.nextToken();
/*     */       }
/* 391 */       catch (IOException e) {
/* 392 */         throw new Error("An IOException has ocurred where it should never occur");
/*     */       } 
/*     */     } 
/*     */     
/* 396 */     if (islayer) {
/* 397 */       throw new IllegalArgumentException("Error parsing 'Alayers' option");
/*     */     }
/*     */     
/* 400 */     if (ratepending) {
/*     */       try {
/* 402 */         lyrs.addOptPoint(r, 0);
/*     */       }
/* 404 */       catch (IllegalArgumentException e) {
/* 405 */         throw new IllegalArgumentException("Error in 'Alayers' option: " + e.getMessage());
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 411 */     return lyrs;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/entropy/encoder/PostCompRateAllocator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */