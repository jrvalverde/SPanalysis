/*     */ package jj2000.j2k.entropy.decoder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ByteToBitInput
/*     */ {
/*     */   ByteInputBuffer in;
/*     */   int bbuf;
/* 101 */   int bpos = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ByteToBitInput(ByteInputBuffer in) {
/* 109 */     this.in = in;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final int readBit() {
/* 120 */     if (this.bpos < 0) {
/* 121 */       if ((this.bbuf & 0xFF) != 255) {
/* 122 */         this.bbuf = this.in.read();
/* 123 */         this.bpos = 7;
/*     */       } else {
/*     */         
/* 126 */         this.bbuf = this.in.read();
/* 127 */         this.bpos = 6;
/*     */       } 
/*     */     }
/* 130 */     return this.bbuf >> this.bpos-- & 0x1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean checkBytePadding() {
/* 148 */     if (this.bpos < 0 && (this.bbuf & 0xFF) == 255) {
/* 149 */       this.bbuf = this.in.read();
/* 150 */       this.bpos = 6;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 155 */     if (this.bpos >= 0) {
/* 156 */       int seq = this.bbuf & (1 << this.bpos + 1) - 1;
/* 157 */       if (seq != 85 >> 7 - this.bpos) return true;
/*     */     
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 163 */     if (this.bbuf != -1) {
/* 164 */       if (this.bbuf == 255 && this.bpos == 0)
/* 165 */       { if ((this.in.read() & 0xFF) >= 128) return true;
/*     */          }
/*     */       
/* 168 */       else if (this.in.read() != -1) { return true; }
/*     */     
/*     */     }
/*     */ 
/*     */     
/* 173 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void flush() {
/* 182 */     this.bbuf = 0;
/* 183 */     this.bpos = -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void setByteArray(byte[] buf, int off, int len) {
/* 201 */     this.in.setByteArray(buf, off, len);
/* 202 */     this.bbuf = 0;
/* 203 */     this.bpos = -1;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/entropy/decoder/ByteToBitInput.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */