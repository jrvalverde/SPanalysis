/*     */ package jj2000.j2k.entropy.decoder;
/*     */ 
/*     */ import jj2000.j2k.entropy.CodedCBlk;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DecLyrdCBlk
/*     */   extends CodedCBlk
/*     */ {
/*     */   public int ulx;
/*     */   public int uly;
/*     */   public int w;
/*     */   public int h;
/*     */   public int dl;
/*     */   public boolean prog;
/*     */   public int nl;
/*     */   public int ftpIdx;
/*     */   public int nTrunc;
/*     */   public int[] tsLengths;
/*     */   
/*     */   public String toString() {
/* 154 */     String str = "Coded code-block (" + this.m + "," + this.n + "): " + this.skipMSBP + " MSB skipped, " + this.dl + " bytes, " + this.nTrunc + " truncation points, " + this.nl + " layers, " + "progressive= " + this.prog + ", ulx= " + this.ulx + ", uly= " + this.uly + ", w= " + this.w + ", h= " + this.h + ", ftpIdx=" + this.ftpIdx;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 159 */     if (this.tsLengths != null) {
/* 160 */       str = str + " {";
/* 161 */       for (int i = 0; i < this.tsLengths.length; i++)
/* 162 */         str = str + " " + this.tsLengths[i]; 
/* 163 */       str = str + " }";
/*     */     } 
/* 165 */     return str;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/entropy/decoder/DecLyrdCBlk.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */