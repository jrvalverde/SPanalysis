/*     */ package jj2000.j2k.entropy;
/*     */ 
/*     */ import com.sun.media.imageioimpl.plugins.jpeg2000.J2KImageWriteParamJava;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.Vector;
/*     */ import jj2000.j2k.IntegerSpec;
/*     */ import jj2000.j2k.ModuleSpec;
/*     */ import jj2000.j2k.image.BlkImgDataSrc;
/*     */ import jj2000.j2k.util.MathUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PrecinctSizeSpec
/*     */   extends ModuleSpec
/*     */ {
/*     */   private static final String optName = "Cpp";
/*     */   private IntegerSpec dls;
/*     */   
/*     */   public PrecinctSizeSpec(int nt, int nc, byte type, IntegerSpec dls) {
/* 124 */     super(nt, nc, type);
/* 125 */     this.dls = dls;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PrecinctSizeSpec(int nt, int nc, byte type, BlkImgDataSrc imgsrc, IntegerSpec dls, J2KImageWriteParamJava wp, String values) {
/* 145 */     super(nt, nc, type);
/*     */     
/* 147 */     this.dls = dls;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 163 */     boolean wasReadingPrecinctSize = false;
/*     */     
/* 165 */     String param = values;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 172 */     Vector[] tmpv = new Vector[2];
/* 173 */     tmpv[0] = new Vector();
/* 174 */     tmpv[0].addElement(new Integer(65535));
/* 175 */     tmpv[1] = new Vector();
/* 176 */     tmpv[1].addElement(new Integer(65535));
/* 177 */     setDefault(tmpv);
/*     */     
/* 179 */     if (param == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 186 */     StringTokenizer stk = new StringTokenizer(param);
/* 187 */     byte curSpecType = 0;
/*     */     
/* 189 */     boolean[] tileSpec = null;
/* 190 */     boolean[] compSpec = null;
/*     */ 
/*     */     
/* 193 */     boolean endOfParamList = false;
/* 194 */     String word = null;
/*     */     
/* 196 */     String errMsg = null;
/*     */     
/* 198 */     while ((stk.hasMoreTokens() || wasReadingPrecinctSize) && !endOfParamList) {
/*     */ 
/*     */       
/* 201 */       Vector[] v = new Vector[2];
/*     */ 
/*     */ 
/*     */       
/* 205 */       if (!wasReadingPrecinctSize) {
/* 206 */         word = stk.nextToken();
/*     */       }
/*     */       
/* 209 */       wasReadingPrecinctSize = false;
/*     */       
/* 211 */       switch (word.charAt(0)) {
/*     */         
/*     */         case 't':
/* 214 */           tileSpec = parseIdx(word, this.nTiles);
/* 215 */           if (curSpecType == 1) {
/* 216 */             curSpecType = 3;
/*     */             continue;
/*     */           } 
/* 219 */           curSpecType = 2;
/*     */           continue;
/*     */ 
/*     */         
/*     */         case 'c':
/* 224 */           compSpec = parseIdx(word, this.nComp);
/* 225 */           if (curSpecType == 2) {
/* 226 */             curSpecType = 3;
/*     */             continue;
/*     */           } 
/* 229 */           curSpecType = 1;
/*     */           continue;
/*     */       } 
/*     */ 
/*     */       
/* 234 */       if (!Character.isDigit(word.charAt(0))) {
/* 235 */         errMsg = "Bad construction for parameter: " + word;
/* 236 */         throw new IllegalArgumentException(errMsg);
/*     */       } 
/*     */ 
/*     */       
/* 240 */       v[0] = new Vector();
/* 241 */       v[1] = new Vector();
/*     */ 
/*     */       
/*     */       while (true) {
/*     */         Integer w, h;
/*     */         
/*     */         try {
/* 248 */           w = new Integer(word);
/*     */ 
/*     */           
/*     */           try {
/* 252 */             word = stk.nextToken();
/*     */           }
/* 254 */           catch (NoSuchElementException e) {
/* 255 */             errMsg = "'Cpp' option : could not parse the precinct's width";
/*     */             
/* 257 */             throw new IllegalArgumentException(errMsg);
/*     */           } 
/*     */ 
/*     */           
/* 261 */           h = new Integer(word);
/* 262 */           if (w.intValue() != 1 << MathUtil.log2(w.intValue()) || h.intValue() != 1 << MathUtil.log2(h.intValue()))
/*     */           {
/*     */             
/* 265 */             errMsg = "Precinct dimensions must be powers of 2";
/* 266 */             throw new IllegalArgumentException(errMsg);
/*     */           }
/*     */         
/* 269 */         } catch (NumberFormatException e) {
/* 270 */           errMsg = "'Cpp' option : the argument '" + word + "' could not be parsed.";
/*     */           
/* 272 */           throw new IllegalArgumentException(errMsg);
/*     */         } 
/*     */         
/* 275 */         v[0].addElement(w);
/* 276 */         v[1].addElement(h);
/*     */ 
/*     */         
/* 279 */         if (stk.hasMoreTokens()) {
/* 280 */           word = stk.nextToken();
/* 281 */           if (!Character.isDigit(word.charAt(0))) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 287 */             wasReadingPrecinctSize = true;
/*     */             
/* 289 */             if (curSpecType == 0) {
/* 290 */               setDefault(v); continue;
/*     */             } 
/* 292 */             if (curSpecType == 2) {
/* 293 */               for (int ti = tileSpec.length - 1; ti >= 0; ti--) {
/* 294 */                 if (tileSpec[ti]) {
/* 295 */                   setTileDef(ti, v);
/*     */                 }
/*     */               }
/*     */             
/* 299 */             } else if (curSpecType == 1) {
/* 300 */               for (int ci = compSpec.length - 1; ci >= 0; ci--) {
/* 301 */                 if (compSpec[ci]) {
/* 302 */                   setCompDef(ci, v);
/*     */                 }
/*     */               } 
/*     */             } else {
/*     */               
/* 307 */               for (int ti = tileSpec.length - 1; ti >= 0; ti--) {
/* 308 */                 for (int ci = compSpec.length - 1; ci >= 0; ci--) {
/* 309 */                   if (tileSpec[ti] && compSpec[ci]) {
/* 310 */                     setTileCompVal(ti, ci, v);
/*     */                   }
/*     */                 } 
/*     */               } 
/*     */             } 
/*     */             
/* 316 */             curSpecType = 0;
/* 317 */             tileSpec = null;
/* 318 */             compSpec = null;
/*     */           } 
/*     */ 
/*     */           
/*     */           continue;
/*     */         } 
/*     */ 
/*     */         
/*     */         break;
/*     */       } 
/*     */ 
/*     */       
/* 330 */       if (curSpecType == 0) {
/* 331 */         setDefault(v);
/*     */       }
/* 333 */       else if (curSpecType == 2) {
/* 334 */         for (int ti = tileSpec.length - 1; ti >= 0; ti--) {
/* 335 */           if (tileSpec[ti]) {
/* 336 */             setTileDef(ti, v);
/*     */           }
/*     */         }
/*     */       
/* 340 */       } else if (curSpecType == 1) {
/* 341 */         for (int ci = compSpec.length - 1; ci >= 0; ci--) {
/* 342 */           if (compSpec[ci]) {
/* 343 */             setCompDef(ci, v);
/*     */           }
/*     */         } 
/*     */       } else {
/*     */         
/* 348 */         for (int ti = tileSpec.length - 1; ti >= 0; ti--) {
/* 349 */           for (int ci = compSpec.length - 1; ci >= 0; ci--) {
/* 350 */             if (tileSpec[ti] && compSpec[ci]) {
/* 351 */               setTileCompVal(ti, ci, v);
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/* 356 */       endOfParamList = true;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPPX(int t, int c, int rl) {
/*     */     int mrl;
/* 384 */     Vector[] v = null;
/* 385 */     boolean tileSpecified = (t != -1);
/* 386 */     boolean compSpecified = (c != -1);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 391 */     if (tileSpecified && compSpecified) {
/* 392 */       mrl = ((Integer)this.dls.getTileCompVal(t, c)).intValue();
/* 393 */       v = (Vector[])getTileCompVal(t, c);
/*     */     }
/* 395 */     else if (tileSpecified && !compSpecified) {
/* 396 */       mrl = ((Integer)this.dls.getTileDef(t)).intValue();
/* 397 */       v = (Vector[])getTileDef(t);
/*     */     }
/* 399 */     else if (!tileSpecified && compSpecified) {
/* 400 */       mrl = ((Integer)this.dls.getCompDef(c)).intValue();
/* 401 */       v = (Vector[])getCompDef(c);
/*     */     } else {
/*     */       
/* 404 */       mrl = ((Integer)this.dls.getDefault()).intValue();
/* 405 */       v = (Vector[])getDefault();
/*     */     } 
/* 407 */     int idx = mrl - rl;
/* 408 */     if (v[0].size() > idx) {
/* 409 */       return ((Integer)v[0].elementAt(idx)).intValue();
/*     */     }
/*     */     
/* 412 */     return ((Integer)v[0].elementAt(v[0].size() - 1)).intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPPY(int t, int c, int rl) {
/*     */     int mrl;
/* 435 */     Vector[] v = null;
/* 436 */     boolean tileSpecified = (t != -1);
/* 437 */     boolean compSpecified = (c != -1);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 442 */     if (tileSpecified && compSpecified) {
/* 443 */       mrl = ((Integer)this.dls.getTileCompVal(t, c)).intValue();
/* 444 */       v = (Vector[])getTileCompVal(t, c);
/*     */     }
/* 446 */     else if (tileSpecified && !compSpecified) {
/* 447 */       mrl = ((Integer)this.dls.getTileDef(t)).intValue();
/* 448 */       v = (Vector[])getTileDef(t);
/*     */     }
/* 450 */     else if (!tileSpecified && compSpecified) {
/* 451 */       mrl = ((Integer)this.dls.getCompDef(c)).intValue();
/* 452 */       v = (Vector[])getCompDef(c);
/*     */     } else {
/*     */       
/* 455 */       mrl = ((Integer)this.dls.getDefault()).intValue();
/* 456 */       v = (Vector[])getDefault();
/*     */     } 
/* 458 */     int idx = mrl - rl;
/* 459 */     if (v[1].size() > idx) {
/* 460 */       return ((Integer)v[1].elementAt(idx)).intValue();
/*     */     }
/*     */     
/* 463 */     return ((Integer)v[1].elementAt(v[1].size() - 1)).intValue();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/entropy/PrecinctSizeSpec.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */