/*     */ package jj2000.j2k.entropy.decoder;
/*     */ 
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ByteInputBuffer
/*     */ {
/*     */   private byte[] buf;
/*     */   private int count;
/*     */   private int pos;
/*     */   
/*     */   public ByteInputBuffer(byte[] buf) {
/* 126 */     this.buf = buf;
/* 127 */     this.count = buf.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ByteInputBuffer(byte[] buf, int offset, int length) {
/* 146 */     this.buf = buf;
/* 147 */     this.pos = offset;
/* 148 */     this.count = offset + length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setByteArray(byte[] buf, int offset, int length) {
/* 170 */     if (buf == null) {
/* 171 */       if (length < 0 || this.count + length > this.buf.length) {
/* 172 */         throw new IllegalArgumentException();
/*     */       }
/* 174 */       if (offset < 0) {
/* 175 */         this.pos = this.count;
/* 176 */         this.count += length;
/*     */       } else {
/* 178 */         this.count = offset + length;
/* 179 */         this.pos = offset;
/*     */       } 
/*     */     } else {
/* 182 */       if (offset < 0 || length < 0 || offset + length > buf.length) {
/* 183 */         throw new IllegalArgumentException();
/*     */       }
/* 185 */       this.buf = buf;
/* 186 */       this.count = offset + length;
/* 187 */       this.pos = offset;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void addByteArray(byte[] data, int off, int len) {
/* 207 */     if (len < 0 || off < 0 || len + off > this.buf.length) {
/* 208 */       throw new IllegalArgumentException();
/*     */     }
/*     */     
/* 211 */     if (this.count + len <= this.buf.length) {
/* 212 */       System.arraycopy(data, off, this.buf, this.count, len);
/* 213 */       this.count += len;
/*     */     } else {
/* 215 */       if (this.count - this.pos + len <= this.buf.length) {
/*     */ 
/*     */         
/* 218 */         System.arraycopy(this.buf, this.pos, this.buf, 0, this.count - this.pos);
/*     */       } else {
/* 220 */         byte[] oldbuf = this.buf;
/* 221 */         this.buf = new byte[this.count - this.pos + len];
/*     */         
/* 223 */         System.arraycopy(oldbuf, this.count, this.buf, 0, this.count - this.pos);
/*     */       } 
/* 225 */       this.count -= this.pos;
/* 226 */       this.pos = 0;
/*     */       
/* 228 */       System.arraycopy(data, off, this.buf, this.count, len);
/* 229 */       this.count += len;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int readChecked() throws IOException {
/* 248 */     if (this.pos < this.count) {
/* 249 */       return this.buf[this.pos++] & 0xFF;
/*     */     }
/* 251 */     throw new EOFException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read() {
/* 268 */     if (this.pos < this.count) {
/* 269 */       return this.buf[this.pos++] & 0xFF;
/*     */     }
/* 271 */     return -1;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/entropy/decoder/ByteInputBuffer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */