/*     */ package jj2000.j2k.entropy;
/*     */ 
/*     */ import com.sun.media.imageioimpl.plugins.jpeg2000.J2KImageWriteParamJava;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.Vector;
/*     */ import jj2000.j2k.IntegerSpec;
/*     */ import jj2000.j2k.ModuleSpec;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProgressionSpec
/*     */   extends ModuleSpec
/*     */ {
/*     */   public ProgressionSpec(int nt, int nc, byte type) {
/* 114 */     super(nt, nc, type);
/* 115 */     if (type != 1) {
/* 116 */       throw new Error("Illegal use of class ProgressionSpec !");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ProgressionSpec(int nt, int nc, int nl, IntegerSpec dls, byte type, J2KImageWriteParamJava wp, String values) {
/* 139 */     super(nt, nc, type);
/*     */     
/* 141 */     this.specified = values;
/*     */     
/* 143 */     String param = values;
/*     */     
/* 145 */     int mode = -1;
/*     */     
/* 147 */     if (values == null) {
/* 148 */       if (wp.getROIs() == null) {
/* 149 */         mode = checkProgMode("res");
/*     */       } else {
/*     */         
/* 152 */         mode = checkProgMode("layer");
/*     */       } 
/*     */       
/* 155 */       if (mode == -1) {
/* 156 */         String str = "Unknown progression type : '" + param + "'";
/* 157 */         throw new IllegalArgumentException(str);
/*     */       } 
/* 159 */       Progression[] arrayOfProgression = new Progression[1];
/* 160 */       arrayOfProgression[0] = new Progression(mode, 0, nc, 0, dls.getMax() + 1, nl);
/* 161 */       setDefault(arrayOfProgression);
/*     */       
/*     */       return;
/*     */     } 
/* 165 */     StringTokenizer stk = new StringTokenizer(param);
/* 166 */     byte curSpecType = 0;
/*     */     
/* 168 */     boolean[] tileSpec = null;
/* 169 */     String word = null;
/* 170 */     String errMsg = null;
/* 171 */     boolean needInteger = false;
/* 172 */     int intType = 0;
/*     */ 
/*     */ 
/*     */     
/* 176 */     Vector<Progression> progression = new Vector();
/* 177 */     int tmp = 0;
/* 178 */     Progression curProg = null;
/*     */     
/* 180 */     while (stk.hasMoreTokens()) {
/* 181 */       word = stk.nextToken();
/*     */       
/* 183 */       switch (word.charAt(0)) {
/*     */         
/*     */         case 't':
/* 186 */           if (progression.size() > 0) {
/*     */             
/* 188 */             curProg.ce = nc;
/* 189 */             curProg.lye = nl;
/* 190 */             curProg.re = dls.getMax() + 1;
/* 191 */             Progression[] arrayOfProgression = new Progression[progression.size()];
/* 192 */             progression.copyInto((Object[])arrayOfProgression);
/* 193 */             if (curSpecType == 0) {
/* 194 */               setDefault(arrayOfProgression);
/*     */             }
/* 196 */             else if (curSpecType == 2) {
/* 197 */               for (int i = tileSpec.length - 1; i >= 0; i--) {
/* 198 */                 if (tileSpec[i])
/* 199 */                   setTileDef(i, arrayOfProgression); 
/*     */               } 
/*     */             } 
/*     */           } 
/* 203 */           progression.removeAllElements();
/* 204 */           intType = -1;
/* 205 */           needInteger = false;
/*     */ 
/*     */           
/* 208 */           tileSpec = parseIdx(word, this.nTiles);
/* 209 */           curSpecType = 2;
/*     */           continue;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 215 */       if (needInteger) {
/*     */         try {
/* 217 */           tmp = (new Integer(word)).intValue();
/*     */         }
/* 219 */         catch (NumberFormatException e) {
/*     */           
/* 221 */           throw new IllegalArgumentException("Progression order specification has missing parameters: " + param);
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 229 */         switch (intType) {
/*     */           case 0:
/* 231 */             if (tmp < 0 || tmp > dls.getMax() + 1) {
/* 232 */               throw new IllegalArgumentException("Invalid comp_start in '-Aptype' option");
/*     */             }
/*     */             
/* 235 */             curProg.cs = tmp; break;
/*     */           case 1:
/* 237 */             if (tmp < 0 || tmp > nc) {
/* 238 */               throw new IllegalArgumentException("Invalid res_start in '-Aptype' option");
/*     */             }
/*     */ 
/*     */             
/* 242 */             curProg.rs = tmp; break;
/*     */           case 2:
/* 244 */             if (tmp < 0) {
/* 245 */               throw new IllegalArgumentException("Invalid layer_end in '-Aptype' option");
/*     */             }
/*     */             
/* 248 */             if (tmp > nl) {
/* 249 */               tmp = nl;
/*     */             }
/* 251 */             curProg.lye = tmp; break;
/*     */           case 3:
/* 253 */             if (tmp < 0) {
/* 254 */               throw new IllegalArgumentException("Invalid comp_end in '-Aptype' option");
/*     */             }
/*     */             
/* 257 */             if (tmp > dls.getMax() + 1) {
/* 258 */               tmp = dls.getMax() + 1;
/*     */             }
/* 260 */             curProg.ce = tmp; break;
/*     */           case 4:
/* 262 */             if (tmp < 0) {
/* 263 */               throw new IllegalArgumentException("Invalid res_end in '-Aptype' option");
/*     */             }
/*     */             
/* 266 */             if (tmp > nc) {
/* 267 */               tmp = nc;
/*     */             }
/* 269 */             curProg.re = tmp;
/*     */             break;
/*     */         } 
/* 272 */         if (intType < 4) {
/* 273 */           intType++;
/* 274 */           needInteger = true;
/*     */           continue;
/*     */         } 
/* 277 */         if (intType == 4) {
/* 278 */           intType = 0;
/* 279 */           needInteger = false;
/*     */           
/*     */           continue;
/*     */         } 
/* 283 */         throw new Error("Error in usage of 'Aptype' option: " + param);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 288 */       if (!needInteger) {
/* 289 */         mode = checkProgMode(word);
/* 290 */         if (mode == -1) {
/* 291 */           errMsg = "Unknown progression type : '" + word + "'";
/* 292 */           throw new IllegalArgumentException(errMsg);
/*     */         } 
/* 294 */         needInteger = true;
/* 295 */         intType = 0;
/* 296 */         if (progression.size() == 0) {
/* 297 */           curProg = new Progression(mode, 0, nc, 0, dls.getMax() + 1, nl);
/*     */         } else {
/*     */           
/* 300 */           curProg = new Progression(mode, 0, nc, 0, dls.getMax() + 1, nl);
/*     */         } 
/*     */         
/* 303 */         progression.addElement(curProg);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 308 */     if (progression.size() == 0) {
/*     */       
/* 310 */       if (wp.getROIs() == null) {
/* 311 */         mode = checkProgMode("res");
/*     */       } else {
/*     */         
/* 314 */         mode = checkProgMode("layer");
/*     */       } 
/*     */       
/* 317 */       if (mode == -1) {
/* 318 */         errMsg = "Unknown progression type : '" + param + "'";
/* 319 */         throw new IllegalArgumentException(errMsg);
/*     */       } 
/* 321 */       Progression[] arrayOfProgression = new Progression[1];
/* 322 */       arrayOfProgression[0] = new Progression(mode, 0, nc, 0, dls.getMax() + 1, nl);
/* 323 */       setDefault(arrayOfProgression);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 328 */     curProg.ce = nc;
/* 329 */     curProg.lye = nl;
/* 330 */     curProg.re = dls.getMax() + 1;
/*     */ 
/*     */     
/* 333 */     Progression[] prog = new Progression[progression.size()];
/* 334 */     progression.copyInto((Object[])prog);
/*     */     
/* 336 */     if (curSpecType == 0) {
/* 337 */       setDefault(prog);
/*     */     }
/* 339 */     else if (curSpecType == 2) {
/* 340 */       for (int i = tileSpec.length - 1; i >= 0; i--) {
/* 341 */         if (tileSpec[i]) {
/* 342 */           setTileDef(i, prog);
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 347 */     if (getDefault() == null) {
/* 348 */       int ndefspec = 0;
/* 349 */       for (int t = nt - 1; t >= 0; t--) {
/* 350 */         for (int c = nc - 1; c >= 0; c--) {
/* 351 */           if (this.specValType[t][c] == 0) {
/* 352 */             ndefspec++;
/*     */           }
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 359 */       if (ndefspec != 0) {
/* 360 */         if (wp.getROIs() == null) {
/* 361 */           mode = checkProgMode("res");
/*     */         } else {
/* 363 */           mode = checkProgMode("layer");
/*     */         } 
/* 365 */         if (mode == -1) {
/* 366 */           errMsg = "Unknown progression type : '" + param + "'";
/* 367 */           throw new IllegalArgumentException(errMsg);
/*     */         } 
/* 369 */         prog = new Progression[1];
/* 370 */         prog[0] = new Progression(mode, 0, nc, 0, dls.getMax() + 1, nl);
/* 371 */         setDefault(prog);
/*     */       } else {
/*     */         int c, i;
/*     */ 
/*     */         
/* 376 */         setDefault(getTileCompVal(0, 0));
/* 377 */         switch (this.specValType[0][0]) {
/*     */           case 2:
/* 379 */             for (c = nc - 1; c >= 0; c--) {
/* 380 */               if (this.specValType[0][c] == 2)
/* 381 */                 this.specValType[0][c] = 0; 
/*     */             } 
/* 383 */             this.tileDef[0] = null;
/*     */             break;
/*     */           case 1:
/* 386 */             for (i = nt - 1; i >= 0; i--) {
/* 387 */               if (this.specValType[i][0] == 1)
/* 388 */                 this.specValType[i][0] = 0; 
/*     */             } 
/* 390 */             this.compDef[0] = null;
/*     */             break;
/*     */           case 3:
/* 393 */             this.specValType[0][0] = 0;
/* 394 */             this.tileCompVal.put("t0c0", null);
/*     */             break;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int checkProgMode(String mode) {
/* 413 */     if (mode.equals("res")) {
/* 414 */       return 1;
/*     */     }
/* 416 */     if (mode.equals("layer")) {
/* 417 */       return 0;
/*     */     }
/* 419 */     if (mode.equals("pos-comp")) {
/* 420 */       return 3;
/*     */     }
/* 422 */     if (mode.equals("comp-pos")) {
/* 423 */       return 4;
/*     */     }
/* 425 */     if (mode.equals("res-pos")) {
/* 426 */       return 2;
/*     */     }
/*     */ 
/*     */     
/* 430 */     return -1;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/entropy/ProgressionSpec.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */