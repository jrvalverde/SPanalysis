/*     */ package jj2000.j2k.entropy;
/*     */ 
/*     */ import jj2000.j2k.codestream.ProgressionType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Progression
/*     */   implements ProgressionType
/*     */ {
/*     */   public int type;
/*     */   public int cs;
/*     */   public int ce;
/*     */   public int rs;
/*     */   public int re;
/*     */   public int lye;
/*     */   
/*     */   public Progression(int type, int cs, int ce, int rs, int re, int lye) {
/* 139 */     this.type = type;
/* 140 */     this.cs = cs;
/* 141 */     this.ce = ce;
/* 142 */     this.rs = rs;
/* 143 */     this.re = re;
/* 144 */     this.lye = lye;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 148 */     String str = "type= ";
/* 149 */     switch (this.type) {
/*     */       case 0:
/* 151 */         str = str + "layer, ";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 168 */         str = str + "comp.: " + this.cs + "-" + this.ce + ", ";
/* 169 */         str = str + "res.: " + this.rs + "-" + this.re + ", ";
/* 170 */         str = str + "layer: up to " + this.lye;
/* 171 */         return str;case 1: str = str + "res, "; str = str + "comp.: " + this.cs + "-" + this.ce + ", "; str = str + "res.: " + this.rs + "-" + this.re + ", "; str = str + "layer: up to " + this.lye; return str;case 2: str = str + "res-pos, "; str = str + "comp.: " + this.cs + "-" + this.ce + ", "; str = str + "res.: " + this.rs + "-" + this.re + ", "; str = str + "layer: up to " + this.lye; return str;case 3: str = str + "pos-comp, "; str = str + "comp.: " + this.cs + "-" + this.ce + ", "; str = str + "res.: " + this.rs + "-" + this.re + ", "; str = str + "layer: up to " + this.lye; return str;case 4: str = str + "pos-comp, "; str = str + "comp.: " + this.cs + "-" + this.ce + ", "; str = str + "res.: " + this.rs + "-" + this.re + ", "; str = str + "layer: up to " + this.lye; return str;
/*     */     } 
/*     */     throw new Error("Unknown progression type");
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/entropy/Progression.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */