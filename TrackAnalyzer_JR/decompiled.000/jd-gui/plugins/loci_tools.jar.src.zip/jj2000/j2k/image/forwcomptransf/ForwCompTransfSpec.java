/*     */ package jj2000.j2k.image.forwcomptransf;
/*     */ 
/*     */ import com.sun.media.imageioimpl.plugins.jpeg2000.J2KImageWriteParamJava;
/*     */ import java.util.StringTokenizer;
/*     */ import jj2000.j2k.image.CompTransfSpec;
/*     */ import jj2000.j2k.wavelet.FilterTypes;
/*     */ import jj2000.j2k.wavelet.analysis.AnWTFilter;
/*     */ import jj2000.j2k.wavelet.analysis.AnWTFilterSpec;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ForwCompTransfSpec
/*     */   extends CompTransfSpec
/*     */   implements FilterTypes
/*     */ {
/*  98 */   private String defaultValue = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ForwCompTransfSpec(int nt, int nc, byte type, AnWTFilterSpec wfs, J2KImageWriteParamJava wp, String values) {
/* 123 */     super(nt, nc, type);
/*     */     
/* 125 */     String param = values;
/* 126 */     this.specified = values;
/* 127 */     if (values == null) {
/*     */ 
/*     */       
/* 130 */       if (nc < 3) {
/* 131 */         setDefault("none");
/*     */         
/*     */         return;
/*     */       } 
/* 135 */       if (wp.getLossless()) {
/* 136 */         setDefault("rct");
/*     */         
/*     */         return;
/*     */       } 
/* 140 */       int[] filtType = new int[this.nComp];
/* 141 */       for (int c = 0; c < 3; c++) {
/* 142 */         AnWTFilter[][] anfilt = (AnWTFilter[][])wfs.getCompDef(c);
/* 143 */         filtType[c] = anfilt[0][0].getFilterType();
/*     */       } 
/*     */ 
/*     */       
/* 147 */       boolean reject = false; int j;
/* 148 */       for (j = 1; j < 3; j++) {
/* 149 */         if (filtType[j] != filtType[0]) reject = true;
/*     */       
/*     */       } 
/* 152 */       if (reject) {
/* 153 */         setDefault("none");
/*     */       } else {
/* 155 */         AnWTFilter[][] anfilt = (AnWTFilter[][])wfs.getCompDef(0);
/* 156 */         if (anfilt[0][0].getFilterType() == 0) {
/* 157 */           setDefault("ict");
/*     */         } else {
/* 159 */           setDefault("rct");
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 167 */       for (int i = 0; i < nt; i++) {
/*     */         
/* 169 */         int[] arrayOfInt = new int[this.nComp];
/* 170 */         for (j = 0; j < 3; j++) {
/* 171 */           AnWTFilter[][] anfilt = (AnWTFilter[][])wfs.getTileCompVal(i, j);
/* 172 */           arrayOfInt[j] = anfilt[0][0].getFilterType();
/*     */         } 
/*     */ 
/*     */         
/* 176 */         boolean bool = false;
/* 177 */         for (int k = 1; k < this.nComp; k++) {
/* 178 */           if (arrayOfInt[k] != arrayOfInt[0]) {
/* 179 */             bool = true;
/*     */           }
/*     */         } 
/* 182 */         if (bool) {
/* 183 */           setTileDef(i, "none");
/*     */         } else {
/* 185 */           AnWTFilter[][] anfilt = (AnWTFilter[][])wfs.getTileCompVal(i, 0);
/* 186 */           if (anfilt[0][0].getFilterType() == 0) {
/* 187 */             setTileDef(i, "ict");
/*     */           } else {
/* 189 */             setTileDef(i, "rct");
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/*     */       return;
/*     */     } 
/* 196 */     if (param.equalsIgnoreCase("true")) {
/* 197 */       param = "on";
/*     */     }
/* 199 */     StringTokenizer stk = new StringTokenizer(param);
/*     */     
/* 201 */     byte curSpecType = 0;
/*     */     
/* 203 */     boolean[] tileSpec = null;
/*     */ 
/*     */ 
/*     */     
/* 207 */     while (stk.hasMoreTokens()) {
/* 208 */       String word = stk.nextToken();
/*     */       
/* 210 */       switch (word.charAt(0)) {
/*     */         case 't':
/* 212 */           tileSpec = parseIdx(word, this.nTiles);
/* 213 */           if (curSpecType == 1) {
/* 214 */             curSpecType = 3; continue;
/*     */           } 
/* 216 */           curSpecType = 2;
/*     */           continue;
/*     */         
/*     */         case 'c':
/* 220 */           throw new IllegalArgumentException("Component specific  parameters not allowed with '-Mct' option");
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 225 */       if (word.equals("off")) {
/* 226 */         if (curSpecType == 0) {
/* 227 */           setDefault("none");
/* 228 */         } else if (curSpecType == 2) {
/* 229 */           for (int i = tileSpec.length - 1; i >= 0; i--) {
/* 230 */             if (tileSpec[i])
/* 231 */               setTileDef(i, "none"); 
/*     */           } 
/*     */         } 
/* 234 */       } else if (word.equals("on")) {
/* 235 */         if (nc < 3) {
/* 236 */           setDefault("none");
/*     */           
/*     */           continue;
/*     */         } 
/* 240 */         if (curSpecType == 0) {
/*     */ 
/*     */           
/* 243 */           setDefault("rct");
/* 244 */         } else if (curSpecType == 2) {
/* 245 */           for (int i = tileSpec.length - 1; i >= 0; i--) {
/* 246 */             if (tileSpec[i]) {
/* 247 */               if (getFilterType(i, wfs) == 1) {
/* 248 */                 setTileDef(i, "rct");
/*     */               } else {
/* 250 */                 setTileDef(i, "ict");
/*     */               } 
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } else {
/* 256 */         throw new IllegalArgumentException("Default parameter of option Mct not recognized: " + param);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 262 */       curSpecType = 0;
/* 263 */       tileSpec = null;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 269 */     if (getDefault() == null) {
/*     */ 
/*     */ 
/*     */       
/* 273 */       setDefault("none");
/*     */       
/* 275 */       for (int i = 0; i < nt; i++) {
/* 276 */         if (!isTileSpecified(i)) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 281 */           int[] filtType = new int[this.nComp];
/* 282 */           for (int c = 0; c < 3; c++) {
/* 283 */             AnWTFilter[][] anfilt = (AnWTFilter[][])wfs.getTileCompVal(i, c);
/* 284 */             filtType[c] = anfilt[0][0].getFilterType();
/*     */           } 
/*     */ 
/*     */           
/* 288 */           boolean reject = false;
/* 289 */           for (int j = 1; j < this.nComp; j++) {
/* 290 */             if (filtType[j] != filtType[0]) {
/* 291 */               reject = true;
/*     */             }
/*     */           } 
/* 294 */           if (reject) {
/* 295 */             setTileDef(i, "none");
/*     */           } else {
/* 297 */             AnWTFilter[][] anfilt = (AnWTFilter[][])wfs.getTileCompVal(i, 0);
/* 298 */             if (anfilt[0][0].getFilterType() == 0) {
/* 299 */               setTileDef(i, "ict");
/*     */             } else {
/* 301 */               setTileDef(i, "rct");
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 309 */     for (int t = nt - 1; t >= 0; t--) {
/*     */       
/* 311 */       if (!((String)getTileDef(t)).equals("none"))
/*     */       {
/*     */ 
/*     */         
/* 315 */         if (((String)getTileDef(t)).equals("rct")) {
/*     */           
/* 317 */           int filterType = getFilterType(t, wfs);
/* 318 */           switch (filterType) {
/*     */             case 1:
/*     */               break;
/*     */             case 0:
/* 322 */               if (isTileSpecified(t))
/*     */               {
/* 324 */                 throw new IllegalArgumentException("Cannot use RCT with 9x7 filter in tile " + t);
/*     */               }
/*     */ 
/*     */ 
/*     */               
/* 329 */               setTileDef(t, "ict");
/*     */               break;
/*     */             
/*     */             default:
/* 333 */               throw new IllegalArgumentException("Default filter is not JPEG 2000 part I compliant");
/*     */           } 
/*     */ 
/*     */         
/*     */         } else {
/* 338 */           int filterType = getFilterType(t, wfs);
/* 339 */           switch (filterType) {
/*     */             case 1:
/* 341 */               if (isTileSpecified(t))
/*     */               {
/* 343 */                 throw new IllegalArgumentException("Cannot use ICT with filter 5x3 in tile " + t);
/*     */               }
/*     */ 
/*     */ 
/*     */               
/* 348 */               setTileDef(t, "rct");
/*     */               break;
/*     */             
/*     */             case 0:
/*     */               break;
/*     */             default:
/* 354 */               throw new IllegalArgumentException("Default filter is not JPEG 2000 part I compliant");
/*     */           } 
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int getFilterType(int t, AnWTFilterSpec wfs) {
/* 376 */     int[] filtType = new int[this.nComp];
/* 377 */     for (int c = 0; c < this.nComp; c++) {
/* 378 */       AnWTFilter[][] anfilt; if (t == -1) {
/* 379 */         anfilt = (AnWTFilter[][])wfs.getCompDef(c);
/*     */       } else {
/* 381 */         anfilt = (AnWTFilter[][])wfs.getTileCompVal(t, c);
/* 382 */       }  filtType[c] = anfilt[0][0].getFilterType();
/*     */     } 
/*     */ 
/*     */     
/* 386 */     boolean reject = false;
/* 387 */     for (int i = 1; i < this.nComp; i++) {
/* 388 */       if (filtType[i] != filtType[0])
/* 389 */         reject = true; 
/*     */     } 
/* 391 */     if (reject) {
/* 392 */       throw new IllegalArgumentException("Can not use component transformation when components do not use the same filters");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 397 */     return filtType[0];
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/image/forwcomptransf/ForwCompTransfSpec.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */