/*     */ package jj2000.j2k.image;
/*     */ 
/*     */ import java.awt.Point;
/*     */ import jj2000.j2k.NoNextElementException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ImgDataJoiner
/*     */   implements BlkImgDataSrc
/*     */ {
/*     */   private int w;
/*     */   private int h;
/*     */   private int nc;
/*     */   private BlkImgDataSrc[] imageData;
/*     */   private int[] compIdx;
/*     */   private int[] subsX;
/*     */   private int[] subsY;
/*     */   
/*     */   public ImgDataJoiner(BlkImgDataSrc[] imD, int[] cIdx) {
/* 157 */     this.imageData = imD;
/* 158 */     this.compIdx = cIdx;
/* 159 */     if (this.imageData.length != this.compIdx.length) {
/* 160 */       throw new IllegalArgumentException("imD and cIdx must have the same length");
/*     */     }
/*     */     
/* 163 */     this.nc = imD.length;
/*     */     
/* 165 */     this.subsX = new int[this.nc];
/* 166 */     this.subsY = new int[this.nc];
/*     */     
/*     */     int i;
/*     */     
/* 170 */     for (i = 0; i < this.nc; i++) {
/* 171 */       if (imD[i].getNumTiles() != 1 || imD[i].getCompULX(cIdx[i]) != 0 || imD[i].getCompULY(cIdx[i]) != 0)
/*     */       {
/*     */         
/* 174 */         throw new IllegalArgumentException("All input components must, not use tiles and must have the origin at the canvas origin");
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 194 */     int maxW = 0;
/* 195 */     int maxH = 0;
/* 196 */     for (i = 0; i < this.nc; i++) {
/* 197 */       if (imD[i].getCompImgWidth(cIdx[i]) > maxW)
/* 198 */         maxW = imD[i].getCompImgWidth(cIdx[i]); 
/* 199 */       if (imD[i].getCompImgHeight(cIdx[i]) > maxH) {
/* 200 */         maxH = imD[i].getCompImgHeight(cIdx[i]);
/*     */       }
/*     */     } 
/* 203 */     this.w = maxW;
/* 204 */     this.h = maxH;
/*     */ 
/*     */ 
/*     */     
/* 208 */     for (i = 0; i < this.nc; i++) {
/*     */ 
/*     */       
/* 211 */       this.subsX[i] = (maxW + imD[i].getCompImgWidth(cIdx[i]) - 1) / imD[i].getCompImgWidth(cIdx[i]);
/*     */       
/* 213 */       this.subsY[i] = (maxH + imD[i].getCompImgHeight(cIdx[i]) - 1) / imD[i].getCompImgHeight(cIdx[i]);
/*     */       
/* 215 */       if ((maxW + this.subsX[i] - 1) / this.subsX[i] != imD[i].getCompImgWidth(cIdx[i]) || (maxH + this.subsY[i] - 1) / this.subsY[i] != imD[i].getCompImgHeight(cIdx[i]))
/*     */       {
/*     */ 
/*     */         
/* 219 */         throw new Error("Can not compute component subsampling factors: strange subsampling.");
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTileWidth() {
/* 232 */     return this.w;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTileHeight() {
/* 242 */     return this.h;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getNomTileWidth() {
/* 247 */     return this.w;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getNomTileHeight() {
/* 252 */     return this.h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getImgWidth() {
/* 262 */     return this.w;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getImgHeight() {
/* 272 */     return this.h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNumComps() {
/* 281 */     return this.nc;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getCompSubsX(int c) {
/* 297 */     return this.subsX[c];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getCompSubsY(int c) {
/* 313 */     return this.subsY[c];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTileCompWidth(int t, int c) {
/* 327 */     return this.imageData[c].getTileCompWidth(t, this.compIdx[c]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTileCompHeight(int t, int c) {
/* 341 */     return this.imageData[c].getTileCompHeight(t, this.compIdx[c]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getCompImgWidth(int c) {
/* 354 */     return this.imageData[c].getCompImgWidth(this.compIdx[c]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getCompImgHeight(int n) {
/* 369 */     return this.imageData[n].getCompImgHeight(this.compIdx[n]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNomRangeBits(int c) {
/* 387 */     return this.imageData[c].getNomRangeBits(this.compIdx[c]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFixedPoint(int c) {
/* 405 */     return this.imageData[c].getFixedPoint(this.compIdx[c]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DataBlk getInternCompData(DataBlk blk, int c) {
/* 446 */     return this.imageData[c].getInternCompData(blk, this.compIdx[c]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DataBlk getCompData(DataBlk blk, int c) {
/* 487 */     return this.imageData[c].getCompData(blk, this.compIdx[c]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTile(int x, int y) {
/* 500 */     if (x != 0 || y != 0) {
/* 501 */       throw new IllegalArgumentException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void nextTile() {
/* 512 */     throw new NoNextElementException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point getTile(Point co) {
/* 525 */     if (co != null) {
/* 526 */       co.x = 0;
/* 527 */       co.y = 0;
/* 528 */       return co;
/*     */     } 
/*     */     
/* 531 */     return new Point(0, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTileIdx() {
/* 543 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getCompULX(int c) {
/* 553 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getCompULY(int c) {
/* 563 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getTilePartULX() {
/* 568 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getTilePartULY() {
/* 573 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getImgULX() {
/* 584 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getImgULY() {
/* 595 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point getNumTiles(Point co) {
/* 610 */     if (co != null) {
/* 611 */       co.x = 1;
/* 612 */       co.y = 1;
/* 613 */       return co;
/*     */     } 
/*     */     
/* 616 */     return new Point(1, 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNumTiles() {
/* 627 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 638 */     String string = "ImgDataJoiner: WxH = " + this.w + "x" + this.h;
/* 639 */     for (int i = 0; i < this.nc; i++) {
/* 640 */       string = string + "\n- Component " + i + " " + this.imageData[i];
/*     */     }
/* 642 */     return string;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/image/ImgDataJoiner.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */