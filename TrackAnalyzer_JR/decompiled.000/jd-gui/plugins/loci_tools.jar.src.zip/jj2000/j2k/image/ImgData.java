package jj2000.j2k.image;

import java.awt.Point;

public interface ImgData {
  int getTileWidth();
  
  int getTileHeight();
  
  int getNomTileWidth();
  
  int getNomTileHeight();
  
  int getImgWidth();
  
  int getImgHeight();
  
  int getNumComps();
  
  int getCompSubsX(int paramInt);
  
  int getCompSubsY(int paramInt);
  
  int getTileCompWidth(int paramInt1, int paramInt2);
  
  int getTileCompHeight(int paramInt1, int paramInt2);
  
  int getCompImgWidth(int paramInt);
  
  int getCompImgHeight(int paramInt);
  
  int getNomRangeBits(int paramInt);
  
  void setTile(int paramInt1, int paramInt2);
  
  void nextTile();
  
  Point getTile(Point paramPoint);
  
  int getTileIdx();
  
  int getTilePartULX();
  
  int getTilePartULY();
  
  int getCompULX(int paramInt);
  
  int getCompULY(int paramInt);
  
  int getImgULX();
  
  int getImgULY();
  
  Point getNumTiles(Point paramPoint);
  
  int getNumTiles();
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/image/ImgData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */