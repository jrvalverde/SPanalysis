/*     */ package jj2000.j2k.image.input;
/*     */ 
/*     */ import java.io.EOFException;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.RandomAccessFile;
/*     */ import jj2000.j2k.JJ2KExceptionHandler;
/*     */ import jj2000.j2k.image.DataBlk;
/*     */ import jj2000.j2k.image.DataBlkInt;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ImgReaderPGM
/*     */   extends ImgReader
/*     */ {
/* 103 */   public static int DC_OFFSET = 128;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private RandomAccessFile in;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int offset;
/*     */ 
/*     */ 
/*     */   
/*     */   private int rb;
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] buf;
/*     */ 
/*     */ 
/*     */   
/*     */   private DataBlkInt intBlk;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImgReaderPGM(File file) throws IOException {
/* 131 */     this(new RandomAccessFile(file, "r"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImgReaderPGM(String fname) throws IOException {
/* 142 */     this(new RandomAccessFile(fname, "r"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImgReaderPGM(RandomAccessFile in) throws EOFException, IOException {
/* 155 */     this.in = in;
/*     */     
/* 157 */     confirmFileType();
/* 158 */     skipCommentAndWhiteSpace();
/* 159 */     this.w = readHeaderInt();
/* 160 */     skipCommentAndWhiteSpace();
/* 161 */     this.h = readHeaderInt();
/* 162 */     skipCommentAndWhiteSpace();
/*     */     
/* 164 */     readHeaderInt();
/* 165 */     this.nc = 1;
/* 166 */     this.rb = 8;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 177 */     this.in.close();
/* 178 */     this.in = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNomRangeBits(int c) {
/* 199 */     if (c != 0) {
/* 200 */       throw new IllegalArgumentException();
/*     */     }
/* 202 */     return this.rb;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFixedPoint(int c) {
/* 218 */     if (c != 0)
/* 219 */       throw new IllegalArgumentException(); 
/* 220 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final DataBlk getInternCompData(DataBlk blk, int c) {
/*     */     DataBlkInt dataBlkInt;
/* 271 */     if (c != 0) {
/* 272 */       throw new IllegalArgumentException();
/*     */     }
/*     */     
/* 275 */     if (blk.getDataType() != 3) {
/* 276 */       if (this.intBlk == null) {
/* 277 */         this.intBlk = new DataBlkInt(blk.ulx, blk.uly, blk.w, blk.h);
/*     */       } else {
/* 279 */         this.intBlk.ulx = blk.ulx;
/* 280 */         this.intBlk.uly = blk.uly;
/* 281 */         this.intBlk.w = blk.w;
/* 282 */         this.intBlk.h = blk.h;
/*     */       } 
/* 284 */       dataBlkInt = this.intBlk;
/*     */     } 
/*     */ 
/*     */     
/* 288 */     int[] barr = (int[])dataBlkInt.getData();
/* 289 */     if (barr == null || barr.length < ((DataBlk)dataBlkInt).w * ((DataBlk)dataBlkInt).h) {
/* 290 */       barr = new int[((DataBlk)dataBlkInt).w * ((DataBlk)dataBlkInt).h];
/* 291 */       dataBlkInt.setData(barr);
/*     */     } 
/*     */ 
/*     */     
/* 295 */     if (this.buf == null || this.buf.length < ((DataBlk)dataBlkInt).w) {
/* 296 */       this.buf = new byte[((DataBlk)dataBlkInt).w];
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 301 */       int mi = ((DataBlk)dataBlkInt).uly + ((DataBlk)dataBlkInt).h;
/* 302 */       for (int i = ((DataBlk)dataBlkInt).uly; i < mi; i++)
/*     */       {
/* 304 */         this.in.seek((this.offset + i * this.w + ((DataBlk)dataBlkInt).ulx));
/* 305 */         this.in.read(this.buf, 0, ((DataBlk)dataBlkInt).w);
/* 306 */         int k = (i - ((DataBlk)dataBlkInt).uly) * ((DataBlk)dataBlkInt).w + ((DataBlk)dataBlkInt).w - 1, j = ((DataBlk)dataBlkInt).w - 1;
/* 307 */         for (; j >= 0; j--, k--) {
/* 308 */           barr[k] = (this.buf[j] & 0xFF) - DC_OFFSET;
/*     */         }
/*     */       }
/*     */     
/* 312 */     } catch (IOException e) {
/* 313 */       JJ2KExceptionHandler.handleException(e);
/*     */     } 
/*     */ 
/*     */     
/* 317 */     ((DataBlk)dataBlkInt).progressive = false;
/*     */     
/* 319 */     ((DataBlk)dataBlkInt).offset = 0;
/* 320 */     ((DataBlk)dataBlkInt).scanw = ((DataBlk)dataBlkInt).w;
/* 321 */     return (DataBlk)dataBlkInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DataBlk getCompData(DataBlk blk, int c) {
/* 369 */     return getInternCompData(blk, c);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte countedByteRead() throws IOException, EOFException {
/* 384 */     this.offset++;
/* 385 */     return this.in.readByte();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void confirmFileType() throws IOException, EOFException {
/* 395 */     byte[] type = { 80, 53 };
/*     */ 
/*     */ 
/*     */     
/* 399 */     for (int i = 0; i < 2; i++) {
/* 400 */       byte b = countedByteRead();
/* 401 */       if (b != type[i]) {
/* 402 */         if (i == 1 && b == 50) {
/* 403 */           throw new IllegalArgumentException("JJ2000 does not support ascii-PGM files. Use  raw-PGM file instead. ");
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 408 */         throw new IllegalArgumentException("Not a raw-PGM file");
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void skipCommentAndWhiteSpace() throws IOException, EOFException {
/* 423 */     boolean done = false;
/*     */ 
/*     */     
/* 426 */     while (!done) {
/* 427 */       byte b = countedByteRead();
/* 428 */       if (b == 35) {
/* 429 */         while (b != 10 && b != 13)
/* 430 */           b = countedByteRead();  continue;
/*     */       } 
/* 432 */       if (b != 9 && b != 10 && b != 13 && b != 32) {
/* 433 */         done = true;
/*     */       }
/*     */     } 
/*     */     
/* 437 */     this.offset--;
/* 438 */     this.in.seek(this.offset);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int readHeaderInt() throws IOException, EOFException {
/* 451 */     int res = 0;
/* 452 */     byte b = 0;
/*     */     
/* 454 */     b = countedByteRead();
/* 455 */     while (b != 32 && b != 10 && b != 9 && b != 13) {
/* 456 */       res = res * 10 + b - 48;
/* 457 */       b = countedByteRead();
/*     */     } 
/* 459 */     return res;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isOrigSigned(int c) {
/* 473 */     if (c != 0)
/* 474 */       throw new IllegalArgumentException(); 
/* 475 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 486 */     return "ImgReaderPGM: WxH = " + this.w + "x" + this.h + ", Component = 0" + "\nUnderlying RandomAccessIO:\n" + this.in.toString();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/image/input/ImgReaderPGM.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */