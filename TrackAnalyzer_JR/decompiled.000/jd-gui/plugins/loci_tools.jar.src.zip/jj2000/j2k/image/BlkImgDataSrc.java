package jj2000.j2k.image;

public interface BlkImgDataSrc extends ImgData {
  int getFixedPoint(int paramInt);
  
  DataBlk getInternCompData(DataBlk paramDataBlk, int paramInt);
  
  DataBlk getCompData(DataBlk paramDataBlk, int paramInt);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/image/BlkImgDataSrc.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */