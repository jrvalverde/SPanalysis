/*     */ package jj2000.j2k.image.invcomptransf;
/*     */ 
/*     */ import jj2000.j2k.decoder.DecoderSpecs;
/*     */ import jj2000.j2k.image.BlkImgDataSrc;
/*     */ import jj2000.j2k.image.CompTransfSpec;
/*     */ import jj2000.j2k.image.DataBlk;
/*     */ import jj2000.j2k.image.DataBlkFloat;
/*     */ import jj2000.j2k.image.DataBlkInt;
/*     */ import jj2000.j2k.image.ImgData;
/*     */ import jj2000.j2k.image.ImgDataAdapter;
/*     */ import jj2000.j2k.util.MathUtil;
/*     */ import jj2000.j2k.wavelet.synthesis.SynWTFilterSpec;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InvCompTransf
/*     */   extends ImgDataAdapter
/*     */   implements BlkImgDataSrc
/*     */ {
/*     */   public static final int NONE = 0;
/*     */   public static final char OPT_PREFIX = 'M';
/* 109 */   private static final String[][] pinfo = (String[][])null;
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int INV_RCT = 1;
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int INV_ICT = 2;
/*     */ 
/*     */ 
/*     */   
/*     */   private BlkImgDataSrc src;
/*     */ 
/*     */   
/*     */   private CompTransfSpec cts;
/*     */ 
/*     */   
/*     */   private SynWTFilterSpec wfs;
/*     */ 
/*     */   
/* 130 */   private int transfType = 0;
/*     */ 
/*     */   
/* 133 */   private int[][] outdata = new int[3][];
/*     */ 
/*     */ 
/*     */   
/*     */   private DataBlk block0;
/*     */ 
/*     */   
/*     */   private DataBlk block1;
/*     */ 
/*     */   
/*     */   private DataBlk block2;
/*     */ 
/*     */   
/* 146 */   private DataBlkInt dbi = new DataBlkInt();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int[] utdepth;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean noCompTransf = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InvCompTransf(BlkImgDataSrc imgSrc, DecoderSpecs decSpec, int[] utdepth) {
/* 168 */     super((ImgData)imgSrc);
/* 169 */     this.cts = decSpec.cts;
/* 170 */     this.wfs = decSpec.wfs;
/* 171 */     this.src = imgSrc;
/* 172 */     this.utdepth = utdepth;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[][] getParameterInfo() {
/* 189 */     return pinfo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 200 */     switch (this.transfType) {
/*     */       case 1:
/* 202 */         return "Inverse RCT";
/*     */       case 2:
/* 204 */         return "Inverse ICT";
/*     */       case 0:
/* 206 */         return "No component transformation";
/*     */     } 
/* 208 */     throw new IllegalArgumentException("Non JPEG 2000 part I component transformation");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isReversible() {
/* 223 */     switch (this.transfType) {
/*     */       case 0:
/*     */       case 1:
/* 226 */         return true;
/*     */       case 2:
/* 228 */         return false;
/*     */     } 
/* 230 */     throw new IllegalArgumentException("Non JPEG 2000 part I component transformation");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFixedPoint(int c) {
/* 253 */     return this.src.getFixedPoint(c);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int[] calcMixedBitDepths(int[] utdepth, int ttype, int[] tdepth) {
/* 273 */     if (utdepth.length < 3 && ttype != 0) {
/* 274 */       throw new IllegalArgumentException();
/*     */     }
/*     */     
/* 277 */     if (tdepth == null) {
/* 278 */       tdepth = new int[utdepth.length];
/*     */     }
/*     */     
/* 281 */     switch (ttype) {
/*     */       case 0:
/* 283 */         System.arraycopy(utdepth, 0, tdepth, 0, utdepth.length);
/*     */         break;
/*     */       case 1:
/* 286 */         if (utdepth.length > 3) {
/* 287 */           System.arraycopy(utdepth, 3, tdepth, 3, utdepth.length - 3);
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 297 */         tdepth[0] = MathUtil.log2((1 << utdepth[0]) + (2 << utdepth[1]) + (1 << utdepth[2]) - 1) - 2 + 1;
/*     */         
/* 299 */         tdepth[1] = MathUtil.log2((1 << utdepth[2]) + (1 << utdepth[1]) - 1) + 1;
/* 300 */         tdepth[2] = MathUtil.log2((1 << utdepth[0]) + (1 << utdepth[1]) - 1) + 1;
/*     */         break;
/*     */       case 2:
/* 303 */         if (utdepth.length > 3) {
/* 304 */           System.arraycopy(utdepth, 3, tdepth, 3, utdepth.length - 3);
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 309 */         tdepth[0] = MathUtil.log2((int)Math.floor((1 << utdepth[0]) * 0.299072D + (1 << utdepth[1]) * 0.586914D + (1 << utdepth[2]) * 0.114014D) - 1) + 1;
/*     */ 
/*     */ 
/*     */         
/* 313 */         tdepth[1] = MathUtil.log2((int)Math.floor((1 << utdepth[0]) * 0.168701D + (1 << utdepth[1]) * 0.331299D + (1 << utdepth[2]) * 0.5D) - 1) + 1;
/*     */ 
/*     */ 
/*     */         
/* 317 */         tdepth[2] = MathUtil.log2((int)Math.floor((1 << utdepth[0]) * 0.5D + (1 << utdepth[1]) * 0.418701D + (1 << utdepth[2]) * 0.081299D) - 1) + 1;
/*     */         break;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 324 */     return tdepth;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNomRangeBits(int c) {
/* 339 */     return this.utdepth[c];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DataBlk getCompData(DataBlk blk, int c) {
/* 364 */     if (c >= 3 || this.transfType == 0) {
/* 365 */       return this.src.getCompData(blk, c);
/*     */     }
/*     */     
/* 368 */     return getInternCompData(blk, c);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DataBlk getInternCompData(DataBlk blk, int c) {
/* 391 */     if (this.noCompTransf) {
/* 392 */       return this.src.getInternCompData(blk, c);
/*     */     }
/* 394 */     switch (this.transfType) {
/*     */       case 0:
/* 396 */         return this.src.getInternCompData(blk, c);
/*     */       case 1:
/* 398 */         return invRCT(blk, c);
/*     */       case 2:
/* 400 */         return invICT(blk, c);
/*     */     } 
/* 402 */     throw new IllegalArgumentException("Non JPEG 2000 part I component transformation");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private DataBlk invRCT(DataBlk blk, int c) {
/* 420 */     if (c >= 3 && c < getNumComps())
/*     */     {
/* 422 */       return this.src.getInternCompData(blk, c);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 427 */     if (this.outdata[c] == null || this.dbi.ulx > blk.ulx || this.dbi.uly > blk.uly || this.dbi.ulx + this.dbi.w < blk.ulx + blk.w || this.dbi.uly + this.dbi.h < blk.uly + blk.h) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 432 */       int w = blk.w;
/* 433 */       int h = blk.h;
/*     */ 
/*     */       
/* 436 */       this.outdata[c] = (int[])blk.getData();
/*     */ 
/*     */       
/* 439 */       if (this.outdata[c] == null || (this.outdata[c]).length != h * w) {
/* 440 */         this.outdata[c] = new int[h * w];
/* 441 */         blk.setData(this.outdata[c]);
/*     */       } 
/*     */       
/* 444 */       this.outdata[(c + 1) % 3] = new int[(this.outdata[c]).length];
/* 445 */       this.outdata[(c + 2) % 3] = new int[(this.outdata[c]).length];
/*     */       
/* 447 */       if (this.block0 == null || this.block0.getDataType() != 3)
/* 448 */         this.block0 = (DataBlk)new DataBlkInt(); 
/* 449 */       if (this.block1 == null || this.block1.getDataType() != 3)
/* 450 */         this.block1 = (DataBlk)new DataBlkInt(); 
/* 451 */       if (this.block2 == null || this.block2.getDataType() != 3)
/* 452 */         this.block2 = (DataBlk)new DataBlkInt(); 
/* 453 */       this.block2.w = blk.w;
/* 454 */       this.block2.h = blk.h;
/* 455 */       this.block2.ulx = blk.ulx;
/* 456 */       this.block2.uly = blk.uly;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 462 */       this.block0 = this.src.getInternCompData(this.block0, 0);
/* 463 */       int[] data0 = (int[])this.block0.getData();
/* 464 */       this.block1 = this.src.getInternCompData(this.block1, 1);
/* 465 */       int[] data1 = (int[])this.block1.getData();
/* 466 */       this.block2 = this.src.getInternCompData(this.block2, 2);
/* 467 */       int[] data2 = (int[])this.block2.getData();
/*     */ 
/*     */       
/* 470 */       blk.progressive = (this.block0.progressive || this.block1.progressive || this.block2.progressive);
/*     */       
/* 472 */       blk.offset = 0;
/* 473 */       blk.scanw = w;
/*     */ 
/*     */       
/* 476 */       this.dbi.progressive = blk.progressive;
/* 477 */       this.dbi.ulx = blk.ulx;
/* 478 */       this.dbi.uly = blk.uly;
/* 479 */       this.dbi.w = blk.w;
/* 480 */       this.dbi.h = blk.h;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 485 */       int k = w * h - 1;
/* 486 */       int k0 = this.block0.offset + (h - 1) * this.block0.scanw + w - 1;
/* 487 */       int k1 = this.block1.offset + (h - 1) * this.block1.scanw + w - 1;
/* 488 */       int k2 = this.block2.offset + (h - 1) * this.block2.scanw + w - 1;
/*     */       
/* 490 */       for (int i = h - 1; i >= 0; i--) {
/* 491 */         for (int mink = k - w; k > mink; k--, k0--, k1--, k2--) {
/* 492 */           this.outdata[1][k] = data0[k0] - (data1[k1] + data2[k2] >> 2);
/* 493 */           this.outdata[0][k] = data2[k2] + this.outdata[1][k];
/* 494 */           this.outdata[2][k] = data1[k1] + this.outdata[1][k];
/*     */         } 
/*     */         
/* 497 */         k0 -= this.block0.scanw - w;
/* 498 */         k1 -= this.block1.scanw - w;
/* 499 */         k2 -= this.block2.scanw - w;
/*     */       } 
/* 501 */       this.outdata[c] = null;
/*     */     }
/* 503 */     else if (c >= 0 && c <= 3) {
/* 504 */       blk.setData(this.outdata[c]);
/* 505 */       blk.progressive = this.dbi.progressive;
/* 506 */       blk.offset = (blk.uly - this.dbi.uly) * this.dbi.w + blk.ulx - this.dbi.ulx;
/* 507 */       blk.scanw = this.dbi.w;
/* 508 */       this.outdata[c] = null;
/*     */     }
/*     */     else {
/*     */       
/* 512 */       throw new IllegalArgumentException();
/*     */     } 
/* 514 */     return blk;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private DataBlk invICT(DataBlk blk, int c) {
/* 529 */     if (c >= 3 && c < getNumComps()) {
/*     */ 
/*     */       
/* 532 */       int w = blk.w;
/* 533 */       int h = blk.h;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 538 */       int[] outdata = (int[])blk.getData();
/*     */ 
/*     */       
/* 541 */       if (outdata == null) {
/* 542 */         outdata = new int[h * w];
/* 543 */         blk.setData(outdata);
/*     */       } 
/*     */ 
/*     */       
/* 547 */       DataBlkFloat indb = new DataBlkFloat(blk.ulx, blk.uly, w, h);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 552 */       this.src.getInternCompData((DataBlk)indb, c);
/* 553 */       float[] indata = (float[])indb.getData();
/*     */ 
/*     */       
/* 556 */       int k = w * h - 1;
/* 557 */       int k0 = indb.offset + (h - 1) * indb.scanw + w - 1;
/* 558 */       for (int i = h - 1; i >= 0; i--) {
/* 559 */         for (int mink = k - w; k > mink; k--, k0--) {
/* 560 */           outdata[k] = (int)indata[k0];
/*     */         }
/*     */         
/* 563 */         k0 -= indb.scanw - w;
/*     */       } 
/*     */ 
/*     */       
/* 567 */       blk.progressive = indb.progressive;
/* 568 */       blk.offset = 0;
/* 569 */       blk.scanw = w;
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 574 */     else if (this.outdata[c] == null || this.dbi.ulx > blk.ulx || this.dbi.uly > blk.uly || this.dbi.ulx + this.dbi.w < blk.ulx + blk.w || this.dbi.uly + this.dbi.h < blk.uly + blk.h) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 579 */       int w = blk.w;
/* 580 */       int h = blk.h;
/*     */ 
/*     */       
/* 583 */       this.outdata[c] = (int[])blk.getData();
/*     */ 
/*     */       
/* 586 */       if (this.outdata[c] == null || (this.outdata[c]).length != w * h) {
/* 587 */         this.outdata[c] = new int[h * w];
/* 588 */         blk.setData(this.outdata[c]);
/*     */       } 
/*     */       
/* 591 */       this.outdata[(c + 1) % 3] = new int[(this.outdata[c]).length];
/* 592 */       this.outdata[(c + 2) % 3] = new int[(this.outdata[c]).length];
/*     */       
/* 594 */       if (this.block0 == null || this.block0.getDataType() != 4)
/* 595 */         this.block0 = (DataBlk)new DataBlkFloat(); 
/* 596 */       if (this.block2 == null || this.block2.getDataType() != 4)
/* 597 */         this.block2 = (DataBlk)new DataBlkFloat(); 
/* 598 */       if (this.block1 == null || this.block1.getDataType() != 4)
/* 599 */         this.block1 = (DataBlk)new DataBlkFloat(); 
/* 600 */       this.block1.w = blk.w;
/* 601 */       this.block1.h = blk.h;
/* 602 */       this.block1.ulx = blk.ulx;
/* 603 */       this.block1.uly = blk.uly;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 609 */       this.block0 = this.src.getInternCompData(this.block0, 0);
/* 610 */       float[] data0 = (float[])this.block0.getData();
/* 611 */       this.block2 = this.src.getInternCompData(this.block2, 1);
/* 612 */       float[] data2 = (float[])this.block2.getData();
/* 613 */       this.block1 = this.src.getInternCompData(this.block1, 2);
/* 614 */       float[] data1 = (float[])this.block1.getData();
/*     */ 
/*     */       
/* 617 */       blk.progressive = (this.block0.progressive || this.block1.progressive || this.block2.progressive);
/*     */       
/* 619 */       blk.offset = 0;
/* 620 */       blk.scanw = w;
/*     */ 
/*     */       
/* 623 */       this.dbi.progressive = blk.progressive;
/* 624 */       this.dbi.ulx = blk.ulx;
/* 625 */       this.dbi.uly = blk.uly;
/* 626 */       this.dbi.w = blk.w;
/* 627 */       this.dbi.h = blk.h;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 632 */       int k = w * h - 1;
/* 633 */       int k0 = this.block0.offset + (h - 1) * this.block0.scanw + w - 1;
/* 634 */       int k2 = this.block2.offset + (h - 1) * this.block2.scanw + w - 1;
/* 635 */       int k1 = this.block1.offset + (h - 1) * this.block1.scanw + w - 1;
/*     */       
/* 637 */       for (int i = h - 1; i >= 0; i--) {
/* 638 */         for (int mink = k - w; k > mink; k--, k0--, k2--, k1--) {
/* 639 */           this.outdata[0][k] = (int)(data0[k0] + 1.402F * data1[k1] + 0.5F);
/* 640 */           this.outdata[1][k] = (int)(data0[k0] - 0.34413F * data2[k2] - 0.71414F * data1[k1] + 0.5F);
/*     */ 
/*     */           
/* 643 */           this.outdata[2][k] = (int)(data0[k0] + 1.772F * data2[k2] + 0.5F);
/*     */         } 
/*     */         
/* 646 */         k0 -= this.block0.scanw - w;
/* 647 */         k2 -= this.block2.scanw - w;
/* 648 */         k1 -= this.block1.scanw - w;
/*     */       } 
/* 650 */       this.outdata[c] = null;
/*     */     }
/* 652 */     else if (c >= 0 && c <= 3) {
/* 653 */       blk.setData(this.outdata[c]);
/* 654 */       blk.progressive = this.dbi.progressive;
/* 655 */       blk.offset = (blk.uly - this.dbi.uly) * this.dbi.w + blk.ulx - this.dbi.ulx;
/* 656 */       blk.scanw = this.dbi.w;
/* 657 */       this.outdata[c] = null;
/*     */     } else {
/*     */       
/* 660 */       throw new IllegalArgumentException();
/*     */     } 
/* 662 */     return blk;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTile(int x, int y) {
/* 679 */     this.src.setTile(x, y);
/* 680 */     this.tIdx = getTileIdx();
/*     */ 
/*     */     
/* 683 */     if (((Integer)this.cts.getTileDef(this.tIdx)).intValue() == 0) {
/* 684 */       this.transfType = 0;
/*     */     } else {
/* 686 */       int nc = (this.src.getNumComps() > 3) ? 3 : this.src.getNumComps();
/* 687 */       int rev = 0;
/* 688 */       for (int c = 0; c < nc; c++)
/* 689 */         rev += this.wfs.isReversible(this.tIdx, c) ? 1 : 0; 
/* 690 */       if (rev == 3) {
/*     */         
/* 692 */         this.transfType = 1;
/*     */       }
/* 694 */       else if (rev == 0) {
/*     */         
/* 696 */         this.transfType = 2;
/*     */       }
/*     */       else {
/*     */         
/* 700 */         throw new IllegalArgumentException("Wavelet transformation and component transformation not coherent in tile" + this.tIdx);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void nextTile() {
/* 718 */     this.src.nextTile();
/* 719 */     this.tIdx = getTileIdx();
/*     */ 
/*     */     
/* 722 */     if (((Integer)this.cts.getTileDef(this.tIdx)).intValue() == 0) {
/* 723 */       this.transfType = 0;
/*     */     } else {
/* 725 */       int nc = (this.src.getNumComps() > 3) ? 3 : this.src.getNumComps();
/* 726 */       int rev = 0;
/* 727 */       for (int c = 0; c < nc; c++)
/* 728 */         rev += this.wfs.isReversible(this.tIdx, c) ? 1 : 0; 
/* 729 */       if (rev == 3) {
/*     */         
/* 731 */         this.transfType = 1;
/*     */       }
/* 733 */       else if (rev == 0) {
/*     */         
/* 735 */         this.transfType = 2;
/*     */       }
/*     */       else {
/*     */         
/* 739 */         throw new IllegalArgumentException("Wavelet transformation and component transformation not coherent in tile" + this.tIdx);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/image/invcomptransf/InvCompTransf.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */