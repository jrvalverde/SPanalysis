/*     */ package jj2000.j2k.image;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ImgDataConverter
/*     */   extends ImgDataAdapter
/*     */   implements BlkImgDataSrc
/*     */ {
/* 102 */   private DataBlk srcBlk = new DataBlkInt();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private BlkImgDataSrc src;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int fp;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImgDataConverter(BlkImgDataSrc imgSrc, int fp) {
/* 121 */     super(imgSrc);
/* 122 */     this.src = imgSrc;
/* 123 */     this.fp = fp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImgDataConverter(BlkImgDataSrc imgSrc) {
/* 135 */     super(imgSrc);
/* 136 */     this.src = imgSrc;
/* 137 */     this.fp = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFixedPoint(int c) {
/* 155 */     return this.fp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DataBlk getCompData(DataBlk blk, int c) {
/* 195 */     return getData(blk, c, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final DataBlk getInternCompData(DataBlk blk, int c) {
/* 241 */     return getData(blk, c, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private DataBlk getData(DataBlk blk, int c, boolean intern) {
/*     */     DataBlk reqBlk;
/*     */     float[] farr;
/*     */     int[] srcIArr, iarr;
/*     */     float[] srcFArr;
/* 266 */     int otype = blk.getDataType();
/*     */     
/* 268 */     if (otype == this.srcBlk.getDataType()) {
/*     */       
/* 270 */       reqBlk = blk;
/*     */     }
/*     */     else {
/*     */       
/* 274 */       reqBlk = this.srcBlk;
/*     */       
/* 276 */       reqBlk.ulx = blk.ulx;
/* 277 */       reqBlk.uly = blk.uly;
/* 278 */       reqBlk.w = blk.w;
/* 279 */       reqBlk.h = blk.h;
/*     */     } 
/*     */ 
/*     */     
/* 283 */     if (intern) {
/*     */       
/* 285 */       this.srcBlk = this.src.getInternCompData(reqBlk, c);
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 292 */       this.srcBlk = this.src.getCompData(reqBlk, c);
/*     */     } 
/*     */ 
/*     */     
/* 296 */     if (this.srcBlk.getDataType() == otype) {
/* 297 */       return this.srcBlk;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 303 */     int w = this.srcBlk.w;
/* 304 */     int h = this.srcBlk.h;
/*     */     
/* 306 */     switch (otype) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 4:
/* 313 */         farr = (float[])blk.getData();
/* 314 */         if (farr == null || farr.length < w * h) {
/* 315 */           farr = new float[w * h];
/* 316 */           blk.setData(farr);
/*     */         } 
/*     */         
/* 319 */         blk.scanw = this.srcBlk.w;
/* 320 */         blk.offset = 0;
/* 321 */         blk.progressive = this.srcBlk.progressive;
/* 322 */         srcIArr = (int[])this.srcBlk.getData();
/*     */ 
/*     */         
/* 325 */         this.fp = this.src.getFixedPoint(c);
/* 326 */         if (this.fp != 0) {
/* 327 */           float mult = 1.0F / (1 << this.fp);
/* 328 */           int i = h - 1, k = w * h - 1, kSrc = this.srcBlk.offset + (h - 1) * this.srcBlk.scanw + w - 1;
/* 329 */           for (; i >= 0; i--) {
/* 330 */             for (int kmin = k - w; k > kmin; k--, kSrc--) {
/* 331 */               farr[k] = srcIArr[kSrc] * mult;
/*     */             }
/*     */             
/* 334 */             kSrc -= this.srcBlk.scanw - w;
/*     */           } 
/*     */         } else {
/*     */           
/* 338 */           int i = h - 1, k = w * h - 1, kSrc = this.srcBlk.offset + (h - 1) * this.srcBlk.scanw + w - 1;
/* 339 */           for (; i >= 0; i--) {
/* 340 */             for (int kmin = k - w; k > kmin; k--, kSrc--) {
/* 341 */               farr[k] = srcIArr[kSrc];
/*     */             }
/*     */             
/* 344 */             kSrc -= this.srcBlk.scanw - w;
/*     */           } 
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 403 */         return blk;case 3: iarr = (int[])blk.getData(); if (iarr == null || iarr.length < w * h) { iarr = new int[w * h]; blk.setData(iarr); }  blk.scanw = this.srcBlk.w; blk.offset = 0; blk.progressive = this.srcBlk.progressive; srcFArr = (float[])this.srcBlk.getData(); if (this.fp != 0) { float mult = (1 << this.fp); int i = h - 1, j = w * h - 1, k = this.srcBlk.offset + (h - 1) * this.srcBlk.scanw + w - 1; for (; i >= 0; i--) { for (int m = j - w; j > m; j--, k--) { if (srcFArr[k] > 0.0F) { iarr[j] = (int)(srcFArr[k] * mult + 0.5F); } else { iarr[j] = (int)(srcFArr[k] * mult - 0.5F); }  }  k -= this.srcBlk.scanw - w; }  } else { int i = h - 1, k = w * h - 1, kSrc = this.srcBlk.offset + (h - 1) * this.srcBlk.scanw + w - 1; for (; i >= 0; i--) { for (int kmin = k - w; k > kmin; k--, kSrc--) { if (srcFArr[kSrc] > 0.0F) { iarr[k] = (int)(srcFArr[kSrc] + 0.5F); } else { iarr[k] = (int)(srcFArr[kSrc] - 0.5F); }  }  kSrc -= this.srcBlk.scanw - w; }  }  return blk;
/*     */     } 
/*     */     throw new IllegalArgumentException("Only integer and float data are supported by JJ2000");
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/image/ImgDataConverter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */