/*     */ package jj2000.j2k.image;
/*     */ 
/*     */ import java.awt.Point;
/*     */ import jj2000.j2k.NoNextElementException;
/*     */ import jj2000.j2k.util.FacilityManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Tiler
/*     */   extends ImgDataAdapter
/*     */   implements BlkImgDataSrc
/*     */ {
/* 111 */   private BlkImgDataSrc src = null;
/*     */ 
/*     */ 
/*     */   
/*     */   private int x0siz;
/*     */ 
/*     */ 
/*     */   
/*     */   private int y0siz;
/*     */ 
/*     */ 
/*     */   
/*     */   private int xt0siz;
/*     */ 
/*     */ 
/*     */   
/*     */   private int yt0siz;
/*     */ 
/*     */   
/*     */   private int xtsiz;
/*     */ 
/*     */   
/*     */   private int ytsiz;
/*     */ 
/*     */   
/*     */   private int ntX;
/*     */ 
/*     */   
/*     */   private int ntY;
/*     */ 
/*     */   
/* 142 */   private int[] compW = null;
/*     */ 
/*     */   
/* 145 */   private int[] compH = null;
/*     */ 
/*     */ 
/*     */   
/* 149 */   private int[] tcx0 = null;
/*     */ 
/*     */ 
/*     */   
/* 153 */   private int[] tcy0 = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int tx;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int ty;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int tileW;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int tileH;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Tiler(BlkImgDataSrc src, int ax, int ay, int px, int py, int nw, int nh) {
/* 199 */     super(src);
/*     */ 
/*     */     
/* 202 */     this.src = src;
/* 203 */     this.x0siz = ax;
/* 204 */     this.y0siz = ay;
/* 205 */     this.xt0siz = px;
/* 206 */     this.yt0siz = py;
/* 207 */     this.xtsiz = nw;
/* 208 */     this.ytsiz = nh;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 223 */     if (this.x0siz < 0 || this.y0siz < 0 || this.xt0siz < 0 || this.yt0siz < 0 || this.xtsiz < 0 || this.ytsiz < 0 || this.xt0siz > this.x0siz || this.yt0siz > this.y0siz)
/*     */     {
/* 225 */       throw new IllegalArgumentException("Invalid image origin, tiling origin or nominal tile size");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 232 */     if (this.xtsiz == 0) this.xtsiz = this.x0siz + src.getImgWidth() - this.xt0siz; 
/* 233 */     if (this.ytsiz == 0) this.ytsiz = this.y0siz + src.getImgHeight() - this.yt0siz;
/*     */ 
/*     */ 
/*     */     
/* 237 */     if (this.x0siz - this.xt0siz >= this.xtsiz) {
/* 238 */       this.xt0siz += (this.x0siz - this.xt0siz) / this.xtsiz * this.xtsiz;
/*     */     }
/* 240 */     if (this.y0siz - this.yt0siz >= this.ytsiz) {
/* 241 */       this.yt0siz += (this.y0siz - this.yt0siz) / this.ytsiz * this.ytsiz;
/*     */     }
/* 243 */     if (this.x0siz - this.xt0siz >= this.xtsiz || this.y0siz - this.yt0siz >= this.ytsiz) {
/* 244 */       FacilityManager.getMsgLogger().printmsg(1, "Automatically adjusted tiling origin to equivalent one (" + this.xt0siz + "," + this.yt0siz + ") so that " + "first tile overlaps the image");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 252 */     this.ntX = (int)Math.ceil((this.x0siz + src.getImgWidth() - this.xt0siz) / this.xtsiz);
/* 253 */     this.ntY = (int)Math.ceil((this.y0siz + src.getImgHeight() - this.yt0siz) / this.ytsiz);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getTileWidth() {
/* 263 */     return this.tileW;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getTileHeight() {
/* 273 */     return this.tileH;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getTileCompWidth(int t, int c) {
/* 286 */     if (t != getTileIdx()) {
/* 287 */       throw new Error("Asking the width of a tile-component which is not in the current tile (call setTile() or nextTile() methods before).");
/*     */     }
/*     */ 
/*     */     
/* 291 */     return this.compW[c];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getTileCompHeight(int t, int c) {
/* 304 */     if (t != getTileIdx()) {
/* 305 */       throw new Error("Asking the width of a tile-component which is not in the current tile (call setTile() or nextTile() methods before).");
/*     */     }
/*     */ 
/*     */     
/* 309 */     return this.compH[c];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFixedPoint(int c) {
/* 327 */     return this.src.getFixedPoint(c);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final DataBlk getInternCompData(DataBlk blk, int c) {
/* 371 */     if (blk.ulx < 0 || blk.uly < 0 || blk.w > this.compW[c] || blk.h > this.compH[c]) {
/* 372 */       throw new IllegalArgumentException("Block is outside the tile");
/*     */     }
/*     */     
/* 375 */     int incx = (int)Math.ceil(this.x0siz / this.src.getCompSubsX(c));
/* 376 */     int incy = (int)Math.ceil(this.y0siz / this.src.getCompSubsY(c));
/* 377 */     blk.ulx -= incx;
/* 378 */     blk.uly -= incy;
/* 379 */     blk = this.src.getInternCompData(blk, c);
/*     */     
/* 381 */     blk.ulx += incx;
/* 382 */     blk.uly += incy;
/* 383 */     return blk;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final DataBlk getCompData(DataBlk blk, int c) {
/* 426 */     if (blk.ulx < 0 || blk.uly < 0 || blk.w > this.compW[c] || blk.h > this.compH[c]) {
/* 427 */       throw new IllegalArgumentException("Block is outside the tile");
/*     */     }
/*     */     
/* 430 */     int incx = (int)Math.ceil(this.x0siz / this.src.getCompSubsX(c));
/* 431 */     int incy = (int)Math.ceil(this.y0siz / this.src.getCompSubsY(c));
/* 432 */     blk.ulx -= incx;
/* 433 */     blk.uly -= incy;
/* 434 */     blk = this.src.getCompData(blk, c);
/*     */     
/* 436 */     blk.ulx += incx;
/* 437 */     blk.uly += incy;
/* 438 */     return blk;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setTile(int x, int y) {
/* 451 */     this.src.setTile(x, y);
/*     */ 
/*     */     
/* 454 */     if (x < 0 || y < 0 || x >= this.ntX || y >= this.ntY) {
/* 455 */       throw new IllegalArgumentException("Tile's indexes out of bounds");
/*     */     }
/*     */ 
/*     */     
/* 459 */     this.tx = x;
/* 460 */     this.ty = y;
/*     */     
/* 462 */     int tx0 = (x != 0) ? (this.xt0siz + x * this.xtsiz) : this.x0siz;
/* 463 */     int ty0 = (y != 0) ? (this.yt0siz + y * this.ytsiz) : this.y0siz;
/* 464 */     int tx1 = (x != this.ntX - 1) ? (this.xt0siz + (x + 1) * this.xtsiz) : (this.x0siz + this.src.getImgWidth());
/*     */     
/* 466 */     int ty1 = (y != this.ntY - 1) ? (this.yt0siz + (y + 1) * this.ytsiz) : (this.y0siz + this.src.getImgHeight());
/*     */ 
/*     */     
/* 469 */     this.tileW = tx1 - tx0;
/* 470 */     this.tileH = ty1 - ty0;
/*     */     
/* 472 */     int nc = this.src.getNumComps();
/* 473 */     if (this.compW == null) this.compW = new int[nc]; 
/* 474 */     if (this.compH == null) this.compH = new int[nc]; 
/* 475 */     if (this.tcx0 == null) this.tcx0 = new int[nc]; 
/* 476 */     if (this.tcy0 == null) this.tcy0 = new int[nc]; 
/* 477 */     for (int i = 0; i < nc; i++) {
/* 478 */       this.tcx0[i] = (int)Math.ceil(tx0 / this.src.getCompSubsX(i));
/* 479 */       this.tcy0[i] = (int)Math.ceil(ty0 / this.src.getCompSubsY(i));
/* 480 */       this.compW[i] = (int)Math.ceil(tx1 / this.src.getCompSubsX(i)) - this.tcx0[i];
/*     */       
/* 482 */       this.compH[i] = (int)Math.ceil(ty1 / this.src.getCompSubsY(i)) - this.tcy0[i];
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void nextTile() {
/* 493 */     if (this.tx == this.ntX - 1 && this.ty == this.ntY - 1)
/* 494 */       throw new NoNextElementException(); 
/* 495 */     if (this.tx < this.ntX - 1) {
/* 496 */       setTile(this.tx + 1, this.ty);
/*     */     } else {
/* 498 */       setTile(0, this.ty + 1);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Point getTile(Point co) {
/* 511 */     if (co != null) {
/* 512 */       co.x = this.tx;
/* 513 */       co.y = this.ty;
/* 514 */       return co;
/*     */     } 
/* 516 */     return new Point(this.tx, this.ty);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getTileIdx() {
/* 527 */     return this.ty * this.ntX + this.tx;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getCompULX(int c) {
/* 537 */     return this.tcx0[c];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getCompULY(int c) {
/* 547 */     return this.tcy0[c];
/*     */   }
/*     */ 
/*     */   
/*     */   public int getTilePartULX() {
/* 552 */     return this.xt0siz;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getTilePartULY() {
/* 557 */     return this.yt0siz;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getImgULX() {
/* 568 */     return this.x0siz;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getImgULY() {
/* 579 */     return this.y0siz;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Point getNumTiles(Point co) {
/* 592 */     if (co != null) {
/* 593 */       co.x = this.ntX;
/* 594 */       co.y = this.ntY;
/* 595 */       return co;
/*     */     } 
/* 597 */     return new Point(this.ntX, this.ntY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getNumTiles() {
/* 607 */     return this.ntX * this.ntY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getNomTileWidth() {
/* 616 */     return this.xtsiz;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getNomTileHeight() {
/* 625 */     return this.ytsiz;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Point getTilingOrigin(Point co) {
/* 641 */     if (co != null) {
/* 642 */       co.x = this.xt0siz;
/* 643 */       co.y = this.yt0siz;
/* 644 */       return co;
/*     */     } 
/* 646 */     return new Point(this.xt0siz, this.yt0siz);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 656 */     return "Tiler: source= " + this.src + "\n" + getNumTiles() + " tile(s), nominal width=" + this.xtsiz + ", nominal height=" + this.ytsiz;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/image/Tiler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */