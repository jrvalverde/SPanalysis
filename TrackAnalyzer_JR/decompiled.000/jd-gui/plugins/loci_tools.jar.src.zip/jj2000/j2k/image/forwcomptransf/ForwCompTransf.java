/*     */ package jj2000.j2k.image.forwcomptransf;
/*     */ 
/*     */ import com.sun.media.imageioimpl.plugins.jpeg2000.J2KImageWriteParamJava;
/*     */ import jj2000.j2k.image.BlkImgDataSrc;
/*     */ import jj2000.j2k.image.CompTransfSpec;
/*     */ import jj2000.j2k.image.DataBlk;
/*     */ import jj2000.j2k.image.DataBlkFloat;
/*     */ import jj2000.j2k.image.DataBlkInt;
/*     */ import jj2000.j2k.image.ImgData;
/*     */ import jj2000.j2k.image.ImgDataAdapter;
/*     */ import jj2000.j2k.util.MathUtil;
/*     */ import jj2000.j2k.wavelet.analysis.AnWTFilterSpec;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ForwCompTransf
/*     */   extends ImgDataAdapter
/*     */   implements BlkImgDataSrc
/*     */ {
/*     */   public static final int NONE = 0;
/*     */   public static final int FORW_RCT = 1;
/*     */   public static final int FORW_ICT = 2;
/*     */   private BlkImgDataSrc src;
/*     */   private CompTransfSpec cts;
/*     */   private AnWTFilterSpec wfs;
/* 125 */   private int transfType = 0;
/*     */ 
/*     */ 
/*     */   
/*     */   private int[] tdepth;
/*     */ 
/*     */ 
/*     */   
/*     */   private DataBlk outBlk;
/*     */ 
/*     */ 
/*     */   
/*     */   private DataBlkInt block0;
/*     */ 
/*     */ 
/*     */   
/*     */   private DataBlkInt block1;
/*     */ 
/*     */ 
/*     */   
/*     */   private DataBlkInt block2;
/*     */ 
/*     */ 
/*     */   
/*     */   public static final char OPT_PREFIX = 'M';
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ForwCompTransf(BlkImgDataSrc imgSrc, J2KImageWriteParamJava wp) {
/* 155 */     super((ImgData)imgSrc);
/* 156 */     this.cts = wp.getComponentTransformation();
/* 157 */     this.wfs = wp.getFilters();
/* 158 */     this.src = imgSrc;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 166 */   private static final String[][] pinfo = new String[][] { { "Mct", "[<tile index>] [true|false] ...", "Specifies to use component transformation with some tiles.  If the wavelet transform is reversible (w5x3 filter), the Reversible Component Transformation (RCT) is applied. If not (w9x7 filter), the Irreversible Component Transformation (ICT) is used.", null } };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFixedPoint(int c) {
/* 193 */     return this.src.getFixedPoint(c);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[][] getParameterInfo() {
/* 210 */     return pinfo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int[] calcMixedBitDepths(int[] ntdepth, int ttype, int[] tdepth) {
/* 230 */     if (ntdepth.length < 3 && ttype != 0) {
/* 231 */       throw new IllegalArgumentException();
/*     */     }
/*     */     
/* 234 */     if (tdepth == null) {
/* 235 */       tdepth = new int[ntdepth.length];
/*     */     }
/*     */     
/* 238 */     switch (ttype) {
/*     */       case 0:
/* 240 */         System.arraycopy(ntdepth, 0, tdepth, 0, ntdepth.length);
/*     */         break;
/*     */       case 1:
/* 243 */         if (ntdepth.length > 3) {
/* 244 */           System.arraycopy(ntdepth, 3, tdepth, 3, ntdepth.length - 3);
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 254 */         tdepth[0] = MathUtil.log2((1 << ntdepth[0]) + (2 << ntdepth[1]) + (1 << ntdepth[2]) - 1) - 2 + 1;
/*     */         
/* 256 */         tdepth[1] = MathUtil.log2((1 << ntdepth[2]) + (1 << ntdepth[1]) - 1) + 1;
/* 257 */         tdepth[2] = MathUtil.log2((1 << ntdepth[0]) + (1 << ntdepth[1]) - 1) + 1;
/*     */         break;
/*     */       case 2:
/* 260 */         if (ntdepth.length > 3) {
/* 261 */           System.arraycopy(ntdepth, 3, tdepth, 3, ntdepth.length - 3);
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 266 */         tdepth[0] = MathUtil.log2((int)Math.floor((1 << ntdepth[0]) * 0.299072D + (1 << ntdepth[1]) * 0.586914D + (1 << ntdepth[2]) * 0.114014D) - 1) + 1;
/*     */ 
/*     */ 
/*     */         
/* 270 */         tdepth[1] = MathUtil.log2((int)Math.floor((1 << ntdepth[0]) * 0.168701D + (1 << ntdepth[1]) * 0.331299D + (1 << ntdepth[2]) * 0.5D) - 1) + 1;
/*     */ 
/*     */ 
/*     */         
/* 274 */         tdepth[2] = MathUtil.log2((int)Math.floor((1 << ntdepth[0]) * 0.5D + (1 << ntdepth[1]) * 0.418701D + (1 << ntdepth[2]) * 0.081299D) - 1) + 1;
/*     */         break;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 281 */     return tdepth;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initForwRCT() {
/* 290 */     int tIdx = getTileIdx();
/*     */     
/* 292 */     if (this.src.getNumComps() < 3) {
/* 293 */       throw new IllegalArgumentException();
/*     */     }
/*     */     
/* 296 */     if (this.src.getTileCompWidth(tIdx, 0) != this.src.getTileCompWidth(tIdx, 1) || this.src.getTileCompWidth(tIdx, 0) != this.src.getTileCompWidth(tIdx, 2) || this.src.getTileCompHeight(tIdx, 0) != this.src.getTileCompHeight(tIdx, 1) || this.src.getTileCompHeight(tIdx, 0) != this.src.getTileCompHeight(tIdx, 2))
/*     */     {
/*     */ 
/*     */       
/* 300 */       throw new IllegalArgumentException("Can not use RCT on components with different dimensions");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 306 */     int[] utd = new int[this.src.getNumComps()];
/* 307 */     for (int i = utd.length - 1; i >= 0; i--) {
/* 308 */       utd[i] = this.src.getNomRangeBits(i);
/*     */     }
/* 310 */     this.tdepth = calcMixedBitDepths(utd, 1, (int[])null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initForwICT() {
/* 319 */     int tIdx = getTileIdx();
/*     */     
/* 321 */     if (this.src.getNumComps() < 3) {
/* 322 */       throw new IllegalArgumentException();
/*     */     }
/*     */     
/* 325 */     if (this.src.getTileCompWidth(tIdx, 0) != this.src.getTileCompWidth(tIdx, 1) || this.src.getTileCompWidth(tIdx, 0) != this.src.getTileCompWidth(tIdx, 2) || this.src.getTileCompHeight(tIdx, 0) != this.src.getTileCompHeight(tIdx, 1) || this.src.getTileCompHeight(tIdx, 0) != this.src.getTileCompHeight(tIdx, 2))
/*     */     {
/*     */ 
/*     */       
/* 329 */       throw new IllegalArgumentException("Can not use ICT on components with different dimensions");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 335 */     int[] utd = new int[this.src.getNumComps()];
/* 336 */     for (int i = utd.length - 1; i >= 0; i--) {
/* 337 */       utd[i] = this.src.getNomRangeBits(i);
/*     */     }
/* 339 */     this.tdepth = calcMixedBitDepths(utd, 2, (int[])null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 350 */     switch (this.transfType) {
/*     */       case 1:
/* 352 */         return "Forward RCT";
/*     */       case 2:
/* 354 */         return "Forward ICT";
/*     */       case 0:
/* 356 */         return "No component transformation";
/*     */     } 
/* 358 */     throw new IllegalArgumentException("Non JPEG 2000 part I component transformation");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNomRangeBits(int c) {
/* 376 */     switch (this.transfType) {
/*     */       case 1:
/*     */       case 2:
/* 379 */         return this.tdepth[c];
/*     */       case 0:
/* 381 */         return this.src.getNomRangeBits(c);
/*     */     } 
/* 383 */     throw new IllegalArgumentException("Non JPEG 2000 part I component transformation");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isReversible() {
/* 397 */     switch (this.transfType) {
/*     */       case 0:
/*     */       case 1:
/* 400 */         return true;
/*     */       case 2:
/* 402 */         return false;
/*     */     } 
/* 404 */     throw new IllegalArgumentException("Non JPEG 2000 part I component transformation");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DataBlk getCompData(DataBlk blk, int c) {
/* 431 */     if (c >= 3 || this.transfType == 0) {
/* 432 */       return this.src.getCompData(blk, c);
/*     */     }
/*     */     
/* 435 */     return getInternCompData(blk, c);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DataBlk getInternCompData(DataBlk blk, int c) {
/* 455 */     switch (this.transfType) {
/*     */       case 0:
/* 457 */         return this.src.getInternCompData(blk, c);
/*     */       case 1:
/* 459 */         return forwRCT(blk, c);
/*     */       case 2:
/* 461 */         return forwICT(blk, c);
/*     */     } 
/* 463 */     throw new IllegalArgumentException("Non JPEG 2000 part I component transformation for tile: " + this.tIdx);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private DataBlk forwRCT(DataBlk blk, int c) {
/* 482 */     int w = blk.w;
/* 483 */     int h = blk.h;
/*     */ 
/*     */ 
/*     */     
/* 487 */     if (c >= 0 && c <= 2) {
/*     */       int i;
/* 489 */       if (blk.getDataType() != 3) {
/* 490 */         if (this.outBlk == null || this.outBlk.getDataType() != 3) {
/* 491 */           this.outBlk = (DataBlk)new DataBlkInt();
/*     */         }
/* 493 */         this.outBlk.w = w;
/* 494 */         this.outBlk.h = h;
/* 495 */         this.outBlk.ulx = blk.ulx;
/* 496 */         this.outBlk.uly = blk.uly;
/* 497 */         blk = this.outBlk;
/*     */       } 
/*     */ 
/*     */       
/* 501 */       int[] outdata = (int[])blk.getData();
/*     */ 
/*     */       
/* 504 */       if (outdata == null || outdata.length < h * w) {
/* 505 */         outdata = new int[h * w];
/* 506 */         blk.setData(outdata);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 512 */       if (this.block0 == null)
/* 513 */         this.block0 = new DataBlkInt(); 
/* 514 */       if (this.block1 == null)
/* 515 */         this.block1 = new DataBlkInt(); 
/* 516 */       if (this.block2 == null)
/* 517 */         this.block2 = new DataBlkInt(); 
/* 518 */       this.block2.w = blk.w;
/* 519 */       this.block2.h = blk.h;
/* 520 */       this.block2.ulx = blk.ulx;
/* 521 */       this.block2.uly = blk.uly;
/*     */ 
/*     */ 
/*     */       
/* 525 */       this.block0 = (DataBlkInt)this.src.getInternCompData((DataBlk)this.block0, 0);
/* 526 */       int[] data0 = (int[])this.block0.getData();
/* 527 */       this.block1 = (DataBlkInt)this.src.getInternCompData((DataBlk)this.block1, 1);
/* 528 */       int[] data1 = (int[])this.block1.getData();
/* 529 */       this.block2 = (DataBlkInt)this.src.getInternCompData((DataBlk)this.block2, 2);
/* 530 */       int[] bdata = (int[])this.block2.getData();
/*     */ 
/*     */       
/* 533 */       blk.progressive = (this.block0.progressive || this.block1.progressive || this.block2.progressive);
/*     */       
/* 535 */       blk.offset = 0;
/* 536 */       blk.scanw = w;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 541 */       int k = w * h - 1;
/* 542 */       int k0 = this.block0.offset + (h - 1) * this.block0.scanw + w - 1;
/* 543 */       int k1 = this.block1.offset + (h - 1) * this.block1.scanw + w - 1;
/* 544 */       int k2 = this.block2.offset + (h - 1) * this.block2.scanw + w - 1;
/*     */       
/* 546 */       switch (c) {
/*     */         case 0:
/* 548 */           for (i = h - 1; i >= 0; i--) {
/* 549 */             for (int mink = k - w; k > mink; k--, k0--, k1--, k2--)
/*     */             {
/*     */               
/* 552 */               outdata[k] = data0[k] + 2 * data1[k] + bdata[k] >> 2;
/*     */             }
/*     */ 
/*     */ 
/*     */             
/* 557 */             k0 -= this.block0.scanw - w;
/* 558 */             k1 -= this.block1.scanw - w;
/* 559 */             k2 -= this.block2.scanw - w;
/*     */           } 
/*     */           break;
/*     */         
/*     */         case 1:
/* 564 */           for (i = h - 1; i >= 0; i--) {
/* 565 */             for (int j = k - w; k > j; k--, k1--, k2--)
/*     */             {
/*     */               
/* 568 */               outdata[k] = bdata[k2] - data1[k1];
/*     */             }
/*     */             
/* 571 */             k1 -= this.block1.scanw - w;
/* 572 */             k2 -= this.block2.scanw - w;
/*     */           } 
/*     */           break;
/*     */         
/*     */         case 2:
/* 577 */           for (i = h - 1; i >= 0; i--) {
/* 578 */             for (int j = k - w; k > j; k--, k0--, k1--)
/*     */             {
/*     */               
/* 581 */               outdata[k] = data0[k0] - data1[k1];
/*     */             }
/*     */             
/* 584 */             k0 -= this.block0.scanw - w;
/* 585 */             k1 -= this.block1.scanw - w;
/*     */           } 
/*     */           break;
/*     */       } 
/*     */     
/*     */     } else {
/* 591 */       if (c >= 3)
/*     */       {
/*     */         
/* 594 */         return this.src.getInternCompData(blk, c);
/*     */       }
/*     */ 
/*     */       
/* 598 */       throw new IllegalArgumentException();
/*     */     } 
/* 600 */     return blk;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private DataBlk forwICT(DataBlk blk, int c) {
/* 617 */     int w = blk.w;
/* 618 */     int h = blk.h;
/*     */ 
/*     */     
/* 621 */     if (blk.getDataType() != 4) {
/* 622 */       if (this.outBlk == null || this.outBlk.getDataType() != 4) {
/* 623 */         this.outBlk = (DataBlk)new DataBlkFloat();
/*     */       }
/* 625 */       this.outBlk.w = w;
/* 626 */       this.outBlk.h = h;
/* 627 */       this.outBlk.ulx = blk.ulx;
/* 628 */       this.outBlk.uly = blk.uly;
/* 629 */       blk = this.outBlk;
/*     */     } 
/*     */ 
/*     */     
/* 633 */     float[] outdata = (float[])blk.getData();
/*     */ 
/*     */     
/* 636 */     if (outdata == null || outdata.length < w * h) {
/* 637 */       outdata = new float[h * w];
/* 638 */       blk.setData(outdata);
/*     */     } 
/*     */ 
/*     */     
/* 642 */     if (c >= 0 && c <= 2) {
/*     */       int i;
/*     */ 
/*     */       
/* 646 */       if (this.block0 == null)
/* 647 */         this.block0 = new DataBlkInt(); 
/* 648 */       if (this.block1 == null)
/* 649 */         this.block1 = new DataBlkInt(); 
/* 650 */       if (this.block2 == null)
/* 651 */         this.block2 = new DataBlkInt(); 
/* 652 */       this.block2.w = blk.w;
/* 653 */       this.block2.h = blk.h;
/* 654 */       this.block2.ulx = blk.ulx;
/* 655 */       this.block2.uly = blk.uly;
/*     */ 
/*     */       
/* 658 */       this.block0 = (DataBlkInt)this.src.getInternCompData((DataBlk)this.block0, 0);
/* 659 */       int[] data0 = (int[])this.block0.getData();
/* 660 */       this.block1 = (DataBlkInt)this.src.getInternCompData((DataBlk)this.block1, 1);
/* 661 */       int[] data1 = (int[])this.block1.getData();
/* 662 */       this.block2 = (DataBlkInt)this.src.getInternCompData((DataBlk)this.block2, 2);
/* 663 */       int[] data2 = (int[])this.block2.getData();
/*     */ 
/*     */       
/* 666 */       blk.progressive = (this.block0.progressive || this.block1.progressive || this.block2.progressive);
/*     */       
/* 668 */       blk.offset = 0;
/* 669 */       blk.scanw = w;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 674 */       int k = w * h - 1;
/* 675 */       int k0 = this.block0.offset + (h - 1) * this.block0.scanw + w - 1;
/* 676 */       int k1 = this.block1.offset + (h - 1) * this.block1.scanw + w - 1;
/* 677 */       int k2 = this.block2.offset + (h - 1) * this.block2.scanw + w - 1;
/*     */       
/* 679 */       switch (c) {
/*     */         
/*     */         case 0:
/* 682 */           for (i = h - 1; i >= 0; i--) {
/* 683 */             for (int mink = k - w; k > mink; k--, k0--, k1--, k2--) {
/* 684 */               outdata[k] = 0.299F * data0[k0] + 0.587F * data1[k1] + 0.114F * data2[k2];
/*     */             }
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 690 */             k0 -= this.block0.scanw - w;
/* 691 */             k1 -= this.block1.scanw - w;
/* 692 */             k2 -= this.block2.scanw - w;
/*     */           } 
/*     */           break;
/*     */ 
/*     */         
/*     */         case 1:
/* 698 */           for (i = h - 1; i >= 0; i--) {
/* 699 */             for (int j = k - w; k > j; k--, k0--, k1--, k2--) {
/* 700 */               outdata[k] = -0.16875F * data0[k0] - 0.33126F * data1[k1] + 0.5F * data2[k2];
/*     */             }
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 706 */             k0 -= this.block0.scanw - w;
/* 707 */             k1 -= this.block1.scanw - w;
/* 708 */             k2 -= this.block2.scanw - w;
/*     */           } 
/*     */           break;
/*     */ 
/*     */         
/*     */         case 2:
/* 714 */           for (i = h - 1; i >= 0; i--) {
/* 715 */             for (int j = k - w; k > j; k--, k0--, k1--, k2--) {
/* 716 */               outdata[k] = 0.5F * data0[k0] - 0.41869F * data1[k1] - 0.08131F * data2[k2];
/*     */             }
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 722 */             k0 -= this.block0.scanw - w;
/* 723 */             k1 -= this.block1.scanw - w;
/* 724 */             k2 -= this.block2.scanw - w;
/*     */           } 
/*     */           break;
/*     */       } 
/*     */     } else {
/* 729 */       if (c >= 3) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 734 */         DataBlkInt indb = new DataBlkInt(blk.ulx, blk.uly, w, h);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 739 */         this.src.getInternCompData((DataBlk)indb, c);
/* 740 */         int[] indata = (int[])indb.getData();
/*     */ 
/*     */         
/* 743 */         int k = w * h - 1;
/* 744 */         int k0 = indb.offset + (h - 1) * indb.scanw + w - 1;
/* 745 */         for (int i = h - 1; i >= 0; i--) {
/* 746 */           for (int mink = k - w; k > mink; k--, k0--) {
/* 747 */             outdata[k] = indata[k0];
/*     */           }
/*     */           
/* 750 */           k0 += indb.w - w;
/*     */         } 
/*     */ 
/*     */         
/* 754 */         blk.progressive = indb.progressive;
/* 755 */         blk.offset = 0;
/* 756 */         blk.scanw = w;
/* 757 */         return blk;
/*     */       } 
/*     */ 
/*     */       
/* 761 */       throw new IllegalArgumentException();
/*     */     } 
/* 763 */     return blk;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTile(int x, int y) {
/* 780 */     this.src.setTile(x, y);
/* 781 */     this.tIdx = getTileIdx();
/*     */ 
/*     */     
/* 784 */     String str = (String)this.cts.getTileDef(this.tIdx);
/* 785 */     if (str.equals("none")) {
/* 786 */       this.transfType = 0;
/*     */     }
/* 788 */     else if (str.equals("rct")) {
/* 789 */       this.transfType = 1;
/* 790 */       initForwRCT();
/*     */     }
/* 792 */     else if (str.equals("ict")) {
/* 793 */       this.transfType = 2;
/* 794 */       initForwICT();
/*     */     } else {
/*     */       
/* 797 */       throw new IllegalArgumentException("Component transformation not recognized");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void nextTile() {
/* 811 */     this.src.nextTile();
/* 812 */     this.tIdx = getTileIdx();
/*     */ 
/*     */     
/* 815 */     String str = (String)this.cts.getTileDef(this.tIdx);
/* 816 */     if (str.equals("none")) {
/* 817 */       this.transfType = 0;
/*     */     }
/* 819 */     else if (str.equals("rct")) {
/* 820 */       this.transfType = 1;
/* 821 */       initForwRCT();
/*     */     }
/* 823 */     else if (str.equals("ict")) {
/* 824 */       this.transfType = 2;
/* 825 */       initForwICT();
/*     */     } else {
/*     */       
/* 828 */       throw new IllegalArgumentException("Component transformation not recognized");
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/image/forwcomptransf/ForwCompTransf.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */