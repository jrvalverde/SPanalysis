/*     */ package jj2000.j2k.fileformat.writer;
/*     */ 
/*     */ import com.sun.media.imageioimpl.plugins.jpeg2000.Box;
/*     */ import com.sun.media.imageioimpl.plugins.jpeg2000.J2KMetadata;
/*     */ import com.sun.media.imageioimpl.plugins.jpeg2000.J2KMetadataFormat;
/*     */ import java.awt.image.ColorModel;
/*     */ import java.awt.image.SampleModel;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import javax.imageio.metadata.IIOMetadataNode;
/*     */ import javax.imageio.stream.ImageOutputStream;
/*     */ import jj2000.j2k.fileformat.FileFormatBoxes;
/*     */ import jj2000.j2k.io.BEBufferedRandomAccessFile;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FileFormatWriter
/*     */   implements FileFormatBoxes
/*     */ {
/*     */   private File file;
/*     */   private ImageOutputStream stream;
/*     */   private int height;
/*     */   private int width;
/*     */   private int nc;
/*     */   private int[] bpc;
/*     */   private boolean bpcVaries;
/*     */   private int clength;
/*     */   private static final int CSB_LENGTH = 15;
/*     */   private static final int FTB_LENGTH = 20;
/*     */   private static final int IHB_LENGTH = 22;
/*     */   private static final int BPC_LENGTH = 8;
/*     */   private ColorModel colorModel;
/*     */   private SampleModel sampleModel;
/*     */   private J2KMetadata metadata;
/*     */   private boolean isIndexed = false;
/*     */   private int otherLength;
/*     */   J2KMetadataFormat format;
/*     */   
/*     */   public FileFormatWriter(File file, ImageOutputStream stream, int height, int width, int nc, int[] bpc, int clength, ColorModel colorModel, SampleModel sampleModel, J2KMetadata metadata) {
/* 188 */     this.height = height;
/* 189 */     this.width = width;
/* 190 */     this.nc = nc;
/* 191 */     this.bpc = bpc;
/* 192 */     this.file = file;
/* 193 */     this.stream = stream;
/* 194 */     this.clength = clength;
/* 195 */     this.colorModel = colorModel;
/* 196 */     this.sampleModel = sampleModel;
/* 197 */     this.metadata = metadata;
/*     */     
/* 199 */     if (colorModel instanceof java.awt.image.IndexColorModel) {
/* 200 */       this.isIndexed = true;
/*     */     }
/* 202 */     this.bpcVaries = false;
/* 203 */     int fixbpc = bpc[0];
/* 204 */     for (int i = nc - 1; i > 0; i--) {
/* 205 */       if (bpc[i] != fixbpc) {
/* 206 */         this.bpcVaries = true;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int writeFileFormat() throws IOException {
/* 221 */     writeMetadata(this.metadata);
/*     */ 
/*     */     
/* 224 */     writeContiguousCodeStreamBox();
/*     */     
/* 226 */     return 15 + this.otherLength;
/*     */   }
/*     */   
/*     */   private void writeMetadata(J2KMetadata metadata) throws IOException {
/* 230 */     if (metadata == null) {
/*     */       return;
/*     */     }
/* 233 */     IIOMetadataNode root = (IIOMetadataNode)metadata.getAsTree("com_sun_media_imageio_plugins_jpeg2000_image_1.0");
/*     */     
/* 235 */     if (root == null)
/*     */       return; 
/* 237 */     this.format = (J2KMetadataFormat)metadata.getMetadataFormat("com_sun_media_imageio_plugins_jpeg2000_image_1.0");
/* 238 */     writeSuperBox(root);
/*     */   }
/*     */   
/*     */   private void writeSuperBox(IIOMetadataNode node) throws IOException {
/* 242 */     NodeList list = node.getChildNodes();
/*     */     
/* 244 */     String name = node.getNodeName();
/* 245 */     if (name.startsWith("JPEG2000")) {
/* 246 */       this.stream.writeInt(computeLength(node));
/* 247 */       this.stream.writeInt(Box.getTypeInt(Box.getTypeByName(name)));
/* 248 */       this.otherLength += 8;
/*     */     } 
/*     */     
/* 251 */     for (int i = 0; i < list.getLength(); i++) {
/* 252 */       IIOMetadataNode child = (IIOMetadataNode)list.item(i);
/*     */       
/* 254 */       name = child.getNodeName();
/* 255 */       if (name.startsWith("JPEG2000") && this.format.isLeaf(name)) {
/* 256 */         writeBox(child);
/*     */       } else {
/* 258 */         writeSuperBox(child);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   private void writeBox(IIOMetadataNode node) throws IOException {
/* 263 */     int type = Box.getTypeInt((String)Box.getAttribute(node, "Type"));
/* 264 */     int length = (new Integer((String)Box.getAttribute(node, "Length"))).intValue();
/* 265 */     Box box = Box.createBox(type, node);
/* 266 */     this.otherLength += length;
/* 267 */     this.stream.writeInt(length);
/* 268 */     this.stream.writeInt(type);
/* 269 */     byte[] data = box.getContent();
/* 270 */     this.stream.write(data, 0, data.length);
/*     */   }
/*     */   
/*     */   private int computeLength(IIOMetadataNode root) {
/* 274 */     NodeList list = root.getChildNodes();
/* 275 */     int length = 0;
/* 276 */     for (int i = 0; i < list.getLength(); i++) {
/* 277 */       IIOMetadataNode node = (IIOMetadataNode)list.item(i);
/* 278 */       String name = node.getNodeName();
/*     */       
/* 280 */       if (this.format.isLeaf(name)) {
/* 281 */         length += (new Integer((String)Box.getAttribute(node, "Length"))).intValue();
/*     */       } else {
/* 283 */         length += computeLength(node);
/*     */       } 
/*     */     } 
/*     */     
/* 287 */     return length + (root.getNodeName().startsWith("JPEG2000") ? 8 : 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeContiguousCodeStreamBox() throws IOException {
/* 300 */     if (this.metadata != null) {
/*     */ 
/*     */ 
/*     */       
/* 304 */       this.stream.writeInt(this.clength + 8);
/*     */ 
/*     */       
/* 307 */       this.stream.writeInt(1785737827);
/*     */     } 
/*     */     
/* 310 */     BEBufferedRandomAccessFile fi = new BEBufferedRandomAccessFile(this.file, "rw+");
/*     */     
/* 312 */     int remainder = this.clength;
/* 313 */     byte[] codestream = new byte[1024];
/*     */     
/* 315 */     while (remainder > 0) {
/* 316 */       int len = (remainder > 1024) ? 1024 : remainder;
/* 317 */       fi.readFully(codestream, 0, len);
/*     */ 
/*     */       
/* 320 */       this.stream.write(codestream, 0, len);
/* 321 */       remainder -= len;
/*     */     } 
/*     */ 
/*     */     
/* 325 */     fi.close();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/fileformat/writer/FileFormatWriter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */