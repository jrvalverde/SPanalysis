/*     */ package jj2000.j2k.fileformat.reader;
/*     */ 
/*     */ import com.sun.media.imageioimpl.plugins.jpeg2000.BitsPerComponentBox;
/*     */ import com.sun.media.imageioimpl.plugins.jpeg2000.Box;
/*     */ import com.sun.media.imageioimpl.plugins.jpeg2000.ChannelDefinitionBox;
/*     */ import com.sun.media.imageioimpl.plugins.jpeg2000.ColorSpecificationBox;
/*     */ import com.sun.media.imageioimpl.plugins.jpeg2000.ComponentMappingBox;
/*     */ import com.sun.media.imageioimpl.plugins.jpeg2000.DataEntryURLBox;
/*     */ import com.sun.media.imageioimpl.plugins.jpeg2000.FileTypeBox;
/*     */ import com.sun.media.imageioimpl.plugins.jpeg2000.HeaderBox;
/*     */ import com.sun.media.imageioimpl.plugins.jpeg2000.J2KMetadata;
/*     */ import com.sun.media.imageioimpl.plugins.jpeg2000.PaletteBox;
/*     */ import com.sun.media.imageioimpl.plugins.jpeg2000.ResolutionBox;
/*     */ import com.sun.media.imageioimpl.plugins.jpeg2000.SignatureBox;
/*     */ import com.sun.media.imageioimpl.plugins.jpeg2000.UUIDBox;
/*     */ import com.sun.media.imageioimpl.plugins.jpeg2000.UUIDListBox;
/*     */ import com.sun.media.imageioimpl.plugins.jpeg2000.XMLBox;
/*     */ import java.awt.color.ColorSpace;
/*     */ import java.awt.color.ICC_ColorSpace;
/*     */ import java.awt.color.ICC_Profile;
/*     */ import java.awt.image.ColorModel;
/*     */ import java.awt.image.ComponentColorModel;
/*     */ import java.awt.image.IndexColorModel;
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.util.Vector;
/*     */ import jj2000.j2k.fileformat.FileFormatBoxes;
/*     */ import jj2000.j2k.io.RandomAccessIO;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FileFormatReader
/*     */   implements FileFormatBoxes
/*     */ {
/*     */   private RandomAccessIO in;
/*     */   private Vector codeStreamPos;
/*     */   private Vector codeStreamLength;
/* 131 */   private ColorModel colorModel = null;
/*     */ 
/*     */   
/*     */   private J2KMetadata metadata;
/*     */   
/*     */   private int width;
/*     */   
/*     */   private int height;
/*     */   
/*     */   private int numComp;
/*     */   
/*     */   private int bitDepth;
/*     */   
/*     */   private int compressionType;
/*     */   
/*     */   private int unknownColor;
/*     */   
/*     */   private int intelProp;
/*     */   
/*     */   private byte[] bitDepths;
/*     */   
/*     */   private byte[][] lut;
/*     */   
/*     */   private byte[] compSize;
/*     */   
/*     */   private short[] comps;
/*     */   
/*     */   private byte[] type;
/*     */   
/*     */   private byte[] maps;
/*     */   
/*     */   private short[] channels;
/*     */   
/*     */   private short[] cType;
/*     */   
/*     */   private short[] associations;
/*     */   
/*     */   private int colorSpaceType;
/*     */   
/*     */   private ICC_Profile profile;
/*     */ 
/*     */   
/*     */   public FileFormatReader(RandomAccessIO in, J2KMetadata metadata) {
/* 174 */     this.in = in;
/* 175 */     this.metadata = metadata;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readFileFormat() throws IOException, EOFException {
/* 192 */     int foundCodeStreamBoxes = 0;
/*     */ 
/*     */     
/* 195 */     long longLength = 0L;
/*     */ 
/*     */     
/* 198 */     boolean jp2HeaderBoxFound = false;
/* 199 */     boolean lastBoxFound = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 207 */       int pos = this.in.getPos();
/*     */ 
/*     */ 
/*     */       
/* 211 */       if (this.in.readInt() != 12 || this.in.readInt() != 1783636000 || this.in.readInt() != 218793738) {
/*     */ 
/*     */         
/* 214 */         this.in.seek(pos);
/*     */         
/* 216 */         short marker = this.in.readShort();
/* 217 */         if (marker != -177) {
/* 218 */           throw new Error("File is neither valid JP2 file nor valid JPEG 2000 codestream");
/*     */         }
/* 220 */         this.in.seek(pos);
/* 221 */         if (this.codeStreamPos == null)
/* 222 */           this.codeStreamPos = new Vector(); 
/* 223 */         this.codeStreamPos.addElement(new Integer(pos));
/*     */         
/*     */         return;
/*     */       } 
/* 227 */       if (this.metadata != null) {
/* 228 */         this.metadata.addNode((Box)new SignatureBox());
/*     */       }
/*     */       
/* 231 */       while (!lastBoxFound) {
/* 232 */         pos = this.in.getPos();
/* 233 */         int length = this.in.readInt();
/* 234 */         if (pos + length == this.in.length()) {
/* 235 */           lastBoxFound = true;
/*     */         }
/* 237 */         int box = this.in.readInt();
/* 238 */         if (length == 0)
/* 239 */         { lastBoxFound = true;
/* 240 */           length = this.in.length() - this.in.getPos(); }
/* 241 */         else { if (length == 1) {
/* 242 */             longLength = this.in.readLong();
/* 243 */             throw new IOException("File too long.");
/* 244 */           }  longLength = 0L; }
/*     */         
/* 246 */         pos = this.in.getPos();
/* 247 */         length -= 8;
/*     */         
/* 249 */         switch (box) {
/*     */           case 1718909296:
/* 251 */             readFileTypeBox(length + 8, longLength);
/*     */             break;
/*     */           case 1785737827:
/* 254 */             if (!jp2HeaderBoxFound) {
/* 255 */               throw new Error("Invalid JP2 file: JP2Header box not found before Contiguous codestream box ");
/*     */             }
/*     */             
/* 258 */             readContiguousCodeStreamBox(length + 8, longLength);
/*     */             break;
/*     */           case 1785737832:
/* 261 */             if (jp2HeaderBoxFound) {
/* 262 */               throw new Error("Invalid JP2 file: Multiple JP2Header boxes found");
/*     */             }
/* 264 */             readJP2HeaderBox(length + 8);
/* 265 */             jp2HeaderBoxFound = true;
/* 266 */             length = 0;
/*     */             break;
/*     */           case 1768449138:
/* 269 */             readImageHeaderBox(length);
/*     */             break;
/*     */           case 1685074537:
/* 272 */             readIntPropertyBox(length);
/*     */             break;
/*     */           case 2020437024:
/* 275 */             readXMLBox(length);
/*     */             break;
/*     */           case 1969843814:
/* 278 */             length = 0;
/*     */             break;
/*     */           case 1970628964:
/* 281 */             readUUIDBox(length);
/*     */             break;
/*     */           case 1969451892:
/* 284 */             readUUIDListBox(length);
/*     */             break;
/*     */           case 1970433056:
/* 287 */             readURLBox(length);
/*     */             break;
/*     */           case 1885564018:
/* 290 */             readPaletteBox(length + 8);
/*     */             break;
/*     */           case 1651532643:
/* 293 */             readBitsPerComponentBox(length);
/*     */             break;
/*     */           case 1668112752:
/* 296 */             readComponentMappingBox(length);
/*     */             break;
/*     */           case 1668246642:
/* 299 */             readColourSpecificationBox(length);
/*     */             break;
/*     */           case 1667523942:
/* 302 */             readChannelDefinitionBox(length);
/*     */             break;
/*     */           case 1919251232:
/* 305 */             length = 0;
/*     */             break;
/*     */           case 1919251299:
/*     */           case 1919251300:
/* 309 */             readResolutionBox(box, length);
/*     */             break;
/*     */           default:
/* 312 */             if (this.metadata != null) {
/* 313 */               byte[] data = new byte[length];
/* 314 */               this.in.readFully(data, 0, length);
/* 315 */               this.metadata.addNode(new Box(length + 8, box, longLength, data));
/*     */             } 
/*     */             break;
/*     */         } 
/*     */ 
/*     */         
/* 321 */         if (!lastBoxFound)
/* 322 */           this.in.seek(pos + length); 
/*     */       } 
/* 324 */     } catch (EOFException e) {
/* 325 */       throw new Error("EOF reached before finding Contiguous Codestream Box");
/*     */     } 
/*     */ 
/*     */     
/* 329 */     if (this.codeStreamPos.size() == 0)
/*     */     {
/* 331 */       throw new Error("Invalid JP2 file: Contiguous codestream box missing");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean readFileTypeBox(int length, long longLength) throws IOException, EOFException {
/* 350 */     boolean foundComp = false;
/*     */ 
/*     */     
/* 353 */     if (length == 1) {
/* 354 */       longLength = this.in.readLong();
/* 355 */       throw new IOException("File too long.");
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 360 */     if (this.in.readInt() != 1785737760) {
/* 361 */       return false;
/*     */     }
/*     */     
/* 364 */     int minorVersion = this.in.readInt();
/*     */ 
/*     */ 
/*     */     
/* 368 */     int nComp = (length - 16) / 4;
/* 369 */     int[] comp = new int[nComp];
/* 370 */     for (int i = 0; i < nComp; i++) {
/* 371 */       comp[i] = this.in.readInt(); if (this.in.readInt() == 1785737760)
/* 372 */         foundComp = true; 
/*     */     } 
/* 374 */     if (!foundComp) {
/* 375 */       return false;
/*     */     }
/* 377 */     if (this.metadata != null) {
/* 378 */       this.metadata.addNode((Box)new FileTypeBox(1785737760, minorVersion, comp));
/*     */     }
/* 380 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean readJP2HeaderBox(int length) throws IOException, EOFException {
/* 402 */     if (length == 0) {
/* 403 */       throw new Error("Zero-length of JP2Header Box");
/*     */     }
/*     */     
/* 406 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean readImageHeaderBox(int length) throws IOException, EOFException {
/* 422 */     if (length == 0) {
/* 423 */       throw new Error("Zero-length of JP2Header Box");
/*     */     }
/*     */ 
/*     */     
/* 427 */     this.height = this.in.readInt();
/* 428 */     this.width = this.in.readInt();
/* 429 */     this.numComp = this.in.readShort();
/* 430 */     this.bitDepth = this.in.readByte();
/*     */     
/* 432 */     this.compressionType = this.in.readByte();
/* 433 */     this.unknownColor = this.in.readByte();
/* 434 */     this.intelProp = this.in.readByte();
/*     */     
/* 436 */     if (this.metadata != null)
/*     */     {
/* 438 */       this.metadata.addNode((Box)new HeaderBox(this.height, this.width, this.numComp, this.bitDepth, this.compressionType, this.unknownColor, this.intelProp));
/*     */     }
/*     */ 
/*     */     
/* 442 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean readContiguousCodeStreamBox(int length, long longLength) throws IOException, EOFException {
/* 467 */     int ccpos = this.in.getPos();
/*     */     
/* 469 */     if (this.codeStreamPos == null)
/* 470 */       this.codeStreamPos = new Vector(); 
/* 471 */     this.codeStreamPos.addElement(new Integer(ccpos));
/*     */ 
/*     */     
/* 474 */     if (this.codeStreamLength == null)
/* 475 */       this.codeStreamLength = new Vector(); 
/* 476 */     this.codeStreamLength.addElement(new Integer(length));
/*     */     
/* 478 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readIntPropertyBox(int length) throws IOException {
/* 485 */     if (this.metadata != null) {
/* 486 */       byte[] data = new byte[length];
/* 487 */       this.in.readFully(data, 0, length);
/* 488 */       this.metadata.addNode(new Box(length + 8, 1785737833, data));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readXMLBox(int length) throws IOException {
/* 496 */     if (this.metadata != null) {
/* 497 */       byte[] data = new byte[length];
/* 498 */       this.in.readFully(data, 0, length);
/* 499 */       this.metadata.addNode((Box)new XMLBox(data));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readURLBox(int length) throws IOException {
/* 507 */     if (this.metadata != null) {
/* 508 */       byte[] data = new byte[length];
/* 509 */       this.in.readFully(data, 0, length);
/* 510 */       this.metadata.addNode((Box)new DataEntryURLBox(data));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readUUIDBox(int length) throws IOException {
/* 518 */     if (this.metadata != null) {
/* 519 */       byte[] data = new byte[length];
/* 520 */       this.in.readFully(data, 0, length);
/* 521 */       this.metadata.addNode((Box)new UUIDBox(data));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readUUIDListBox(int length) throws IOException {
/* 529 */     if (this.metadata != null) {
/* 530 */       byte[] data = new byte[length];
/* 531 */       this.in.readFully(data, 0, length);
/* 532 */       this.metadata.addNode((Box)new UUIDListBox(data));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void readPaletteBox(int length) throws IOException {
/* 539 */     int pos = this.in.getPos();
/*     */     
/* 541 */     int lutSize = this.in.readShort();
/* 542 */     int numComp = this.in.readByte();
/* 543 */     this.compSize = new byte[numComp];
/*     */     
/* 545 */     for (int i = 0; i < numComp; i++) {
/* 546 */       this.compSize[i] = this.in.readByte();
/*     */     }
/*     */     
/* 549 */     this.lut = new byte[numComp][lutSize];
/*     */     
/* 551 */     for (int n = 0; n < lutSize; n++) {
/* 552 */       for (int c = 0; c < numComp; c++) {
/* 553 */         int depth = 1 + (this.compSize[c] & Byte.MAX_VALUE);
/* 554 */         if (depth > 32)
/* 555 */           depth = 32; 
/* 556 */         int numBytes = depth + 7 >> 3;
/* 557 */         int mask = (1 << depth) - 1;
/* 558 */         byte[] buf = new byte[numBytes];
/* 559 */         this.in.readFully(buf, 0, numBytes);
/*     */         
/* 561 */         int val = 0;
/*     */         
/* 563 */         for (int k = 0; k < numBytes; k++) {
/* 564 */           val = buf[k] + (val << 8);
/*     */         }
/* 566 */         this.lut[c][n] = (byte)val;
/*     */       } 
/*     */     } 
/* 569 */     if (this.metadata != null) {
/* 570 */       this.metadata.addNode((Box)new PaletteBox(length, this.compSize, this.lut));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void readComponentMappingBox(int length) throws IOException {
/* 577 */     int num = length / 4;
/*     */     
/* 579 */     this.comps = new short[num];
/* 580 */     this.type = new byte[num];
/* 581 */     this.maps = new byte[num];
/*     */     
/* 583 */     for (int i = 0; i < num; i++) {
/* 584 */       this.comps[i] = this.in.readShort();
/* 585 */       this.type[i] = this.in.readByte();
/* 586 */       this.maps[i] = this.in.readByte();
/*     */     } 
/*     */     
/* 589 */     if (this.metadata != null) {
/* 590 */       this.metadata.addNode((Box)new ComponentMappingBox(this.comps, this.type, this.maps));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readChannelDefinitionBox(int length) throws IOException {
/* 601 */     int num = this.in.readShort();
/* 602 */     this.channels = new short[num];
/* 603 */     this.cType = new short[num];
/* 604 */     this.associations = new short[num];
/*     */     
/* 606 */     for (int i = 0; i < num; i++) {
/* 607 */       this.channels[i] = this.in.readShort();
/* 608 */       this.cType[i] = this.in.readShort();
/* 609 */       this.associations[i] = this.in.readShort();
/*     */     } 
/* 611 */     if (this.metadata != null) {
/* 612 */       this.metadata.addNode((Box)new ChannelDefinitionBox(this.channels, this.cType, this.associations));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void readBitsPerComponentBox(int length) throws IOException {
/* 619 */     this.bitDepths = new byte[length];
/* 620 */     this.in.readFully(this.bitDepths, 0, length);
/*     */     
/* 622 */     if (this.metadata != null) {
/* 623 */       this.metadata.addNode((Box)new BitsPerComponentBox(this.bitDepths));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readColourSpecificationBox(int length) throws IOException {
/* 631 */     byte method = this.in.readByte();
/*     */ 
/*     */     
/* 634 */     byte prec = this.in.readByte();
/*     */ 
/*     */     
/* 637 */     byte approx = this.in.readByte();
/*     */     
/* 639 */     if (method == 2) {
/* 640 */       byte[] data = new byte[length - 3];
/* 641 */       this.in.readFully(data, 0, data.length);
/* 642 */       this.profile = ICC_Profile.getInstance(data);
/*     */     } else {
/* 644 */       this.colorSpaceType = this.in.readInt();
/*     */     } 
/* 646 */     if (this.metadata != null) {
/* 647 */       this.metadata.addNode((Box)new ColorSpecificationBox(method, prec, approx, this.colorSpaceType, this.profile));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readResolutionBox(int type, int length) throws IOException {
/* 656 */     byte[] data = new byte[length];
/* 657 */     this.in.readFully(data, 0, length);
/* 658 */     if (this.metadata != null) {
/* 659 */       this.metadata.addNode((Box)new ResolutionBox(type, data));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long[] getCodeStreamPos() {
/* 670 */     int size = this.codeStreamPos.size();
/* 671 */     long[] pos = new long[size];
/* 672 */     for (int i = 0; i < size; i++)
/* 673 */       pos[i] = ((Integer)this.codeStreamPos.elementAt(i)).longValue(); 
/* 674 */     return pos;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFirstCodeStreamPos() {
/* 684 */     return ((Integer)this.codeStreamPos.elementAt(0)).intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFirstCodeStreamLength() {
/* 694 */     return ((Integer)this.codeStreamLength.elementAt(0)).intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ColorModel getColorModel() {
/* 704 */     if (this.lut != null && this.numComp == 1) {
/* 705 */       int numComp = this.lut.length;
/*     */       
/* 707 */       int maxDepth = 1 + (this.bitDepth & 0x7F);
/*     */       
/* 709 */       if (this.maps == null) {
/* 710 */         this.maps = new byte[numComp];
/* 711 */         for (int i = 0; i < numComp; i++)
/* 712 */           this.maps[i] = (byte)i; 
/*     */       } 
/* 714 */       if (numComp == 3) {
/* 715 */         this.colorModel = new IndexColorModel(maxDepth, (this.lut[0]).length, this.lut[this.maps[0]], this.lut[this.maps[1]], this.lut[this.maps[2]]);
/*     */ 
/*     */       
/*     */       }
/* 719 */       else if (numComp == 4) {
/* 720 */         this.colorModel = new IndexColorModel(maxDepth, (this.lut[0]).length, this.lut[this.maps[0]], this.lut[this.maps[1]], this.lut[this.maps[2]], this.lut[this.maps[3]]);
/*     */       
/*     */       }
/*     */     
/*     */     }
/* 725 */     else if (this.channels != null) {
/* 726 */       boolean hasAlpha = false;
/* 727 */       int alphaChannel = this.numComp - 1;
/*     */       
/* 729 */       for (int i = 0; i < this.channels.length; i++) {
/* 730 */         if (this.cType[i] == 1 && this.channels[i] == alphaChannel) {
/* 731 */           hasAlpha = true;
/*     */         }
/*     */       } 
/* 734 */       boolean[] isPremultiplied = { false };
/*     */       
/* 736 */       if (hasAlpha) {
/* 737 */         isPremultiplied = new boolean[alphaChannel];
/*     */         int k;
/* 739 */         for (k = 0; k < alphaChannel; k++) {
/* 740 */           isPremultiplied[k] = false;
/*     */         }
/* 742 */         for (k = 0; k < this.channels.length; k++) {
/* 743 */           if (this.cType[k] == 2) {
/* 744 */             isPremultiplied[this.associations[k] - 1] = true;
/*     */           }
/*     */         } 
/* 747 */         for (k = 1; k < alphaChannel; k++) {
/* 748 */           isPremultiplied[0] = isPremultiplied[0] & isPremultiplied[k];
/*     */         }
/*     */       } 
/* 751 */       ColorSpace cs = null;
/* 752 */       if (this.profile != null) {
/* 753 */         cs = new ICC_ColorSpace(this.profile);
/* 754 */       } else if (this.colorSpaceType == 16) {
/* 755 */         cs = ColorSpace.getInstance(1000);
/* 756 */       } else if (this.colorSpaceType == 17) {
/* 757 */         cs = ColorSpace.getInstance(1003);
/* 758 */       } else if (this.colorSpaceType == 18) {
/* 759 */         cs = ColorSpace.getInstance(1002);
/*     */       } 
/* 761 */       int[] bits = new int[this.numComp];
/* 762 */       for (int j = 0; j < this.numComp; j++) {
/* 763 */         if (this.bitDepths != null) {
/* 764 */           bits[j] = (this.bitDepths[j] & Byte.MAX_VALUE) + 1;
/*     */         } else {
/* 766 */           bits[j] = (this.bitDepth & 0x7F) + 1;
/*     */         } 
/* 768 */       }  int maxBitDepth = 1 + (this.bitDepth & 0x7F);
/* 769 */       boolean isSigned = ((this.bitDepth & 0x80) == 128);
/* 770 */       if (this.bitDepths != null) {
/* 771 */         isSigned = ((this.bitDepths[0] & 0x80) == 128);
/*     */       }
/* 773 */       if (this.bitDepths != null)
/* 774 */         for (int k = 0; k < this.numComp; k++) {
/* 775 */           if (bits[k] > maxBitDepth)
/* 776 */             maxBitDepth = bits[k]; 
/*     */         }  
/* 778 */       int type = -1;
/*     */       
/* 780 */       if (maxBitDepth <= 8) {
/* 781 */         type = 0;
/* 782 */       } else if (maxBitDepth <= 16) {
/* 783 */         type = isSigned ? 2 : 1;
/* 784 */       } else if (maxBitDepth <= 32) {
/* 785 */         type = 3;
/*     */       } 
/* 787 */       if (type == -1) {
/* 788 */         return null;
/*     */       }
/* 790 */       if (cs != null) {
/* 791 */         this.colorModel = new ComponentColorModel(cs, bits, hasAlpha, isPremultiplied[0], hasAlpha ? 3 : 1, type);
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 799 */     return this.colorModel;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/jj2000/j2k/fileformat/reader/FileFormatReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */