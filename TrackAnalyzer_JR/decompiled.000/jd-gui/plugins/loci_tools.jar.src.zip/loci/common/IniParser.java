/*     */ package loci.common;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IniParser
/*     */ {
/*  60 */   private static final Logger LOGGER = LoggerFactory.getLogger(IniParser.class);
/*     */   
/*  62 */   private String commentDelimiter = "#";
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean slashContinues = true;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCommentDelimiter(String delimiter) {
/*  72 */     this.commentDelimiter = delimiter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBackslashContinuesLine(boolean slashContinues) {
/*  82 */     this.slashContinues = slashContinues;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IniList parseINI(String path) throws IOException {
/*  89 */     return parseINI(openTextResource(path));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IniList parseINI(String path, Class<?> c) throws IOException {
/*  99 */     return parseINI(openTextResource(path, c));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IniList parseINI(BufferedReader in) throws IOException {
/* 106 */     IniList list = new IniList();
/* 107 */     IniTable attrs = null;
/* 108 */     String chapter = null;
/* 109 */     int no = 1;
/* 110 */     StringBuffer sb = new StringBuffer();
/*     */     while (true) {
/* 112 */       int num = readLine(in, sb);
/* 113 */       if (num == 0)
/* 114 */         break;  String line = sb.toString();
/* 115 */       LOGGER.debug("Line {}: {}", Integer.valueOf(no), line);
/*     */ 
/*     */       
/* 118 */       if (line.equals("")) {
/* 119 */         no += num;
/*     */         
/*     */         continue;
/*     */       } 
/*     */       
/* 124 */       if (line.startsWith("{")) {
/*     */         
/* 126 */         int end = line.length();
/* 127 */         if (line.endsWith("}")) end--; 
/* 128 */         chapter = line.substring(1, end);
/*     */         
/*     */         continue;
/*     */       } 
/*     */       
/* 133 */       if (line.startsWith("[")) {
/* 134 */         attrs = new IniTable();
/* 135 */         list.add(attrs);
/*     */ 
/*     */         
/* 138 */         int end = line.length();
/* 139 */         if (line.endsWith("]")) end--; 
/* 140 */         String header = line.substring(1, end);
/* 141 */         if (chapter != null) header = chapter + ": " + header;
/*     */         
/* 143 */         attrs.put("header", header);
/* 144 */         no += num;
/*     */         
/*     */         continue;
/*     */       } 
/*     */       
/* 149 */       int equals = line.indexOf("=");
/* 150 */       if (equals < 0) throw new IOException(no + ": bad line"); 
/* 151 */       String key = line.substring(0, equals).trim();
/* 152 */       String value = line.substring(equals + 1).trim();
/* 153 */       attrs.put(key, value);
/* 154 */       no += num;
/*     */     } 
/* 156 */     return list;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BufferedReader openTextResource(String path) {
/* 163 */     return openTextResource(path, IniParser.class);
/*     */   }
/*     */ 
/*     */   
/*     */   public static BufferedReader openTextResource(String path, Class<?> c) {
/*     */     try {
/* 169 */       return new BufferedReader(new InputStreamReader(c.getResourceAsStream(path), "UTF-8"));
/*     */     
/*     */     }
/* 172 */     catch (IOException e) {
/* 173 */       LOGGER.error("Could not open BufferedReader", e);
/*     */       
/* 175 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int readLine(BufferedReader in, StringBuffer sb) throws IOException {
/*     */     boolean slash;
/* 187 */     int no = 0;
/* 188 */     sb.setLength(0);
/* 189 */     boolean blockText = false;
/*     */     do {
/* 191 */       String line = in.readLine();
/* 192 */       if (line == null)
/* 193 */         break;  no++;
/*     */ 
/*     */       
/* 196 */       if (this.commentDelimiter != null) {
/* 197 */         int comment = line.indexOf(this.commentDelimiter);
/* 198 */         if (comment >= 0) line = line.substring(0, comment);
/*     */       
/*     */       } 
/*     */       
/* 202 */       if (!blockText) {
/* 203 */         line = line.trim();
/*     */       }
/*     */ 
/*     */       
/* 207 */       slash = (this.slashContinues && line.trim().endsWith("\\"));
/* 208 */       blockText = (this.slashContinues && line.trim().endsWith("\\n"));
/*     */       
/* 210 */       if (blockText) {
/* 211 */         line = line.substring(0, line.length() - 2) + "\n";
/*     */       }
/* 213 */       else if (slash) {
/* 214 */         line = line.substring(0, line.length() - 1).trim() + " ";
/*     */       } 
/* 216 */       sb.append(line);
/* 217 */     } while (slash || blockText);
/*     */     
/* 219 */     return no;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/common/IniParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */