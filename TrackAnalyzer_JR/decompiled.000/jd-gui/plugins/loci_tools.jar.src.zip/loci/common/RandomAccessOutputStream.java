/*     */ package loci.common;
/*     */ 
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.ByteOrder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RandomAccessOutputStream
/*     */   extends OutputStream
/*     */   implements DataOutput
/*     */ {
/*     */   private IRandomAccess outputFile;
/*     */   
/*     */   public RandomAccessOutputStream(String file) throws IOException {
/*  67 */     this.outputFile = Location.getHandle(file, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RandomAccessOutputStream(IRandomAccess handle) {
/*  75 */     this.outputFile = handle;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void seek(long pos) throws IOException {
/*  82 */     this.outputFile.seek(pos);
/*     */   }
/*     */ 
/*     */   
/*     */   public long getFilePointer() throws IOException {
/*  87 */     return this.outputFile.getFilePointer();
/*     */   }
/*     */ 
/*     */   
/*     */   public long length() throws IOException {
/*  92 */     return this.outputFile.length();
/*     */   }
/*     */ 
/*     */   
/*     */   public void skipBytes(int skip) throws IOException {
/*  97 */     this.outputFile.seek(this.outputFile.getFilePointer() + skip);
/*     */   }
/*     */ 
/*     */   
/*     */   public void order(boolean little) {
/* 102 */     this.outputFile.setOrder(little ? ByteOrder.LITTLE_ENDIAN : ByteOrder.BIG_ENDIAN);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isLittleEndian() {
/* 108 */     return (this.outputFile.getOrder() == ByteOrder.LITTLE_ENDIAN);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeLine(String s) throws IOException {
/* 113 */     writeBytes(s);
/* 114 */     writeBytes("\n");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(byte[] b) throws IOException {
/* 121 */     this.outputFile.write(b);
/*     */   }
/*     */ 
/*     */   
/*     */   public void write(byte[] b, int off, int len) throws IOException {
/* 126 */     this.outputFile.write(b, off, len);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(ByteBuffer b) throws IOException {
/* 135 */     this.outputFile.write(b);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(ByteBuffer b, int off, int len) throws IOException {
/* 145 */     this.outputFile.write(b, off, len);
/*     */   }
/*     */ 
/*     */   
/*     */   public void write(int b) throws IOException {
/* 150 */     this.outputFile.write(b);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeBoolean(boolean v) throws IOException {
/* 155 */     this.outputFile.writeBoolean(v);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeByte(int v) throws IOException {
/* 160 */     this.outputFile.writeByte(v);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeBytes(String s) throws IOException {
/* 165 */     this.outputFile.writeBytes(s);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeChar(int v) throws IOException {
/* 170 */     this.outputFile.writeChar(v);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeChars(String s) throws IOException {
/* 175 */     this.outputFile.writeChars(s);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeDouble(double v) throws IOException {
/* 180 */     this.outputFile.writeDouble(v);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeFloat(float v) throws IOException {
/* 185 */     this.outputFile.writeFloat(v);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeInt(int v) throws IOException {
/* 190 */     this.outputFile.writeInt(v);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeLong(long v) throws IOException {
/* 195 */     this.outputFile.writeLong(v);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeShort(int v) throws IOException {
/* 200 */     this.outputFile.writeShort(v);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeUTF(String str) throws IOException {
/* 205 */     this.outputFile.writeUTF(str);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 212 */     this.outputFile.close();
/*     */   }
/*     */   
/*     */   public void flush() throws IOException {}
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/common/RandomAccessOutputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */