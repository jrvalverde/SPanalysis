/*     */ package loci.common;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.zip.GZIPInputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GZipHandle
/*     */   extends StreamHandle
/*     */ {
/*     */   public GZipHandle(String file) throws IOException {
/*  68 */     this.file = file;
/*  69 */     if (!isGZipFile(file)) {
/*  70 */       throw new HandleException(file + " is not a gzip file.");
/*     */     }
/*     */     
/*  73 */     resetStream();
/*     */     
/*  75 */     this.length = 0L;
/*     */     while (true) {
/*  77 */       int skip = this.stream.skipBytes(1024);
/*  78 */       if (skip <= 0)
/*  79 */         break;  this.length += skip;
/*     */     } 
/*     */     
/*  82 */     resetStream();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isGZipFile(String file) throws IOException {
/*  89 */     if (!file.toLowerCase().endsWith(".gz")) return false;
/*     */     
/*  91 */     FileInputStream s = new FileInputStream(file);
/*  92 */     byte[] b = new byte[2];
/*  93 */     s.read(b);
/*  94 */     s.close();
/*  95 */     return (DataTools.bytesToInt(b, true) == 35615);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void resetStream() throws IOException {
/* 102 */     if (this.stream != null) this.stream.close(); 
/* 103 */     BufferedInputStream bis = new BufferedInputStream(new FileInputStream(this.file), 1048576);
/*     */     
/* 105 */     this.stream = new DataInputStream(new GZIPInputStream(bis));
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/common/GZipHandle.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */