/*     */ package loci.common;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Region
/*     */ {
/*     */   public int x;
/*     */   public int y;
/*     */   public int width;
/*     */   public int height;
/*     */   
/*     */   public Region() {}
/*     */   
/*     */   public Region(int x, int y, int width, int height) {
/*  62 */     this.x = x;
/*  63 */     this.y = y;
/*  64 */     this.width = width;
/*  65 */     this.height = height;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean intersects(Region r) {
/*  72 */     int tw = this.width;
/*  73 */     int th = this.height;
/*  74 */     int rw = r.width;
/*  75 */     int rh = r.height;
/*  76 */     if (rw <= 0 || rh <= 0 || tw <= 0 || th <= 0) {
/*  77 */       return false;
/*     */     }
/*  79 */     int tx = this.x;
/*  80 */     int ty = this.y;
/*  81 */     int rx = r.x;
/*  82 */     int ry = r.y;
/*  83 */     rw += rx;
/*  84 */     rh += ry;
/*  85 */     tw += tx;
/*  86 */     th += ty;
/*  87 */     boolean rtn = ((rw < rx || rw > tx) && (rh < ry || rh > ty) && (tw < tx || tw > rx) && (th < ty || th > ry));
/*     */     
/*  89 */     return rtn;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Region intersection(Region r) {
/*  98 */     int x = Math.max(this.x, r.x);
/*  99 */     int y = Math.max(this.y, r.y);
/* 100 */     int w = Math.min(this.x + this.width, r.x + r.width) - x;
/* 101 */     int h = Math.min(this.y + this.height, r.y + r.height) - y;
/*     */     
/* 103 */     if (w < 0) w = 0; 
/* 104 */     if (h < 0) h = 0;
/*     */     
/* 106 */     return new Region(x, y, w, h);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsPoint(int xc, int yc) {
/* 114 */     return intersects(new Region(xc, yc, 1, 1));
/*     */   }
/*     */   
/*     */   public String toString() {
/* 118 */     return "x=" + this.x + ", y=" + this.y + ", w=" + this.width + ", h=" + this.height;
/*     */   }
/*     */   
/*     */   public boolean equals(Object o) {
/* 122 */     if (!(o instanceof Region)) return false;
/*     */     
/* 124 */     Region that = (Region)o;
/* 125 */     return (this.x == that.x && this.y == that.y && this.width == that.width && this.height == that.height);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 130 */     return toString().hashCode();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/common/Region.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */