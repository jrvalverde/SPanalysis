/*     */ package loci.common;
/*     */ 
/*     */ import java.io.EOFException;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.RandomAccessFile;
/*     */ import java.nio.BufferUnderflowException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.ByteOrder;
/*     */ import java.nio.channels.FileChannel;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NIOFileHandle
/*     */   extends AbstractNIOHandle
/*     */ {
/*  68 */   private static final Logger LOGGER = LoggerFactory.getLogger(RandomAccessInputStream.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  74 */   protected static int defaultBufferSize = 1048576;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  79 */   protected static int defaultRWBufferSize = 8192;
/*     */ 
/*     */ 
/*     */   
/*     */   protected RandomAccessFile raf;
/*     */ 
/*     */ 
/*     */   
/*     */   protected FileChannel channel;
/*     */ 
/*     */   
/*  90 */   protected long position = 0L;
/*     */ 
/*     */   
/*  93 */   protected long bufferStartPosition = 0L;
/*     */ 
/*     */   
/*     */   protected int bufferSize;
/*     */ 
/*     */   
/*     */   protected ByteBuffer buffer;
/*     */ 
/*     */   
/*     */   protected boolean isReadWrite = false;
/*     */ 
/*     */   
/* 105 */   protected FileChannel.MapMode mapMode = FileChannel.MapMode.READ_ONLY;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ByteOrder order;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected NIOByteBufferProvider byteBufferProvider;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NIOFileHandle(File file, String mode, int bufferSize) throws IOException {
/* 121 */     this.bufferSize = bufferSize;
/* 122 */     validateMode(mode);
/* 123 */     if (mode.equals("rw")) {
/* 124 */       this.isReadWrite = true;
/* 125 */       this.mapMode = FileChannel.MapMode.READ_WRITE;
/*     */     } 
/* 127 */     this.raf = new RandomAccessFile(file, mode);
/* 128 */     this.channel = this.raf.getChannel();
/* 129 */     this.byteBufferProvider = new NIOByteBufferProvider(this.channel, this.mapMode);
/* 130 */     buffer(this.position, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NIOFileHandle(File file, String mode) throws IOException {
/* 138 */     this(file, mode, mode.equals("rw") ? defaultRWBufferSize : defaultBufferSize);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NIOFileHandle(String name, String mode) throws IOException {
/* 147 */     this(new File(name), mode);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setDefaultBufferSize(int size) {
/* 159 */     defaultBufferSize = size;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setDefaultReadWriteBufferSize(int size) {
/* 169 */     defaultRWBufferSize = size;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public RandomAccessFile getRandomAccessFile() {
/* 175 */     return this.raf;
/*     */   }
/*     */   public FileChannel getFileChannel() {
/* 178 */     return this.channel;
/*     */   }
/*     */   public int getBufferSize() {
/* 181 */     return this.bufferSize;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLength(long length) throws IOException {
/* 187 */     this.raf.seek(length - 1L);
/* 188 */     this.raf.write(0);
/* 189 */     this.buffer = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 196 */     this.raf.close();
/*     */   }
/*     */ 
/*     */   
/*     */   public long getFilePointer() {
/* 201 */     return this.position;
/*     */   }
/*     */ 
/*     */   
/*     */   public long length() throws IOException {
/* 206 */     return this.raf.length();
/*     */   }
/*     */ 
/*     */   
/*     */   public ByteOrder getOrder() {
/* 211 */     return (this.buffer == null) ? this.order : this.buffer.order();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setOrder(ByteOrder order) {
/* 216 */     this.order = order;
/* 217 */     if (this.buffer != null) {
/* 218 */       this.buffer.order(order);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public int read(byte[] b) throws IOException {
/* 224 */     return read(ByteBuffer.wrap(b));
/*     */   }
/*     */ 
/*     */   
/*     */   public int read(byte[] b, int off, int len) throws IOException {
/* 229 */     return read(ByteBuffer.wrap(b), off, len);
/*     */   }
/*     */ 
/*     */   
/*     */   public int read(ByteBuffer buf) throws IOException {
/* 234 */     return read(buf, 0, buf.capacity());
/*     */   }
/*     */ 
/*     */   
/*     */   public int read(ByteBuffer buf, int off, int len) throws IOException {
/* 239 */     buf.position(off);
/* 240 */     buf.limit(off + len);
/* 241 */     this.channel.position(this.position);
/* 242 */     int readLength = this.channel.read(buf);
/* 243 */     buffer(this.position + readLength, 0);
/*     */ 
/*     */     
/* 246 */     return (readLength == -1) ? 0 : readLength;
/*     */   }
/*     */ 
/*     */   
/*     */   public void seek(long pos) throws IOException {
/* 251 */     if (this.mapMode == FileChannel.MapMode.READ_WRITE && pos > length()) {
/* 252 */       setLength(pos);
/*     */     }
/* 254 */     buffer(pos, 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean readBoolean() throws IOException {
/* 259 */     return (readByte() == 1);
/*     */   }
/*     */ 
/*     */   
/*     */   public byte readByte() throws IOException {
/* 264 */     buffer(this.position, 1);
/* 265 */     this.position++;
/*     */     try {
/* 267 */       return this.buffer.get();
/* 268 */     } catch (BufferUnderflowException e) {
/* 269 */       EOFException eof = new EOFException("Attempting to read beyond end of file.");
/* 270 */       eof.initCause(e);
/* 271 */       throw eof;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public char readChar() throws IOException {
/* 277 */     buffer(this.position, 2);
/* 278 */     this.position += 2L;
/*     */     try {
/* 280 */       return this.buffer.getChar();
/* 281 */     } catch (BufferUnderflowException e) {
/* 282 */       EOFException eof = new EOFException("Attempting to read beyond end of file.");
/* 283 */       eof.initCause(e);
/* 284 */       throw eof;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public double readDouble() throws IOException {
/* 290 */     buffer(this.position, 8);
/* 291 */     this.position += 8L;
/*     */     try {
/* 293 */       return this.buffer.getDouble();
/* 294 */     } catch (BufferUnderflowException e) {
/* 295 */       EOFException eof = new EOFException("Attempting to read beyond end of file.");
/* 296 */       eof.initCause(e);
/* 297 */       throw eof;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public float readFloat() throws IOException {
/* 303 */     buffer(this.position, 4);
/* 304 */     this.position += 4L;
/*     */     try {
/* 306 */       return this.buffer.getFloat();
/* 307 */     } catch (BufferUnderflowException e) {
/* 308 */       EOFException eof = new EOFException("Attempting to read beyond end of file.");
/* 309 */       eof.initCause(e);
/* 310 */       throw eof;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void readFully(byte[] b) throws IOException {
/* 316 */     read(b);
/*     */   }
/*     */ 
/*     */   
/*     */   public void readFully(byte[] b, int off, int len) throws IOException {
/* 321 */     read(b, off, len);
/*     */   }
/*     */ 
/*     */   
/*     */   public int readInt() throws IOException {
/* 326 */     buffer(this.position, 4);
/* 327 */     this.position += 4L;
/*     */     try {
/* 329 */       return this.buffer.getInt();
/* 330 */     } catch (BufferUnderflowException e) {
/* 331 */       EOFException eof = new EOFException("Attempting to read beyond end of file.");
/* 332 */       eof.initCause(e);
/* 333 */       throw eof;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String readLine() throws IOException {
/* 339 */     this.raf.seek(this.position);
/* 340 */     String line = this.raf.readLine();
/* 341 */     buffer(this.raf.getFilePointer(), 0);
/* 342 */     return line;
/*     */   }
/*     */ 
/*     */   
/*     */   public long readLong() throws IOException {
/* 347 */     buffer(this.position, 8);
/* 348 */     this.position += 8L;
/*     */     try {
/* 350 */       return this.buffer.getLong();
/* 351 */     } catch (BufferUnderflowException e) {
/* 352 */       EOFException eof = new EOFException("Attempting to read beyond end of file.");
/* 353 */       eof.initCause(e);
/* 354 */       throw eof;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public short readShort() throws IOException {
/* 360 */     buffer(this.position, 2);
/* 361 */     this.position += 2L;
/*     */     try {
/* 363 */       return this.buffer.getShort();
/* 364 */     } catch (BufferUnderflowException e) {
/* 365 */       EOFException eof = new EOFException("Attempting to read beyond end of file.");
/* 366 */       eof.initCause(e);
/* 367 */       throw eof;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int readUnsignedByte() throws IOException {
/* 373 */     return readByte() & 0xFF;
/*     */   }
/*     */ 
/*     */   
/*     */   public int readUnsignedShort() throws IOException {
/* 378 */     return readShort() & 0xFFFF;
/*     */   }
/*     */ 
/*     */   
/*     */   public String readUTF() throws IOException {
/* 383 */     this.raf.seek(this.position);
/* 384 */     String utf8 = this.raf.readUTF();
/* 385 */     buffer(this.raf.getFilePointer(), 0);
/* 386 */     return utf8;
/*     */   }
/*     */ 
/*     */   
/*     */   public int skipBytes(int n) throws IOException {
/* 391 */     if (n < 1) {
/* 392 */       return 0;
/*     */     }
/* 394 */     long oldPosition = this.position;
/* 395 */     long newPosition = oldPosition + Math.min(n, length());
/*     */     
/* 397 */     buffer(newPosition, 0);
/* 398 */     return (int)(this.position - oldPosition);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(byte[] b) throws IOException {
/* 405 */     write(ByteBuffer.wrap(b));
/*     */   }
/*     */ 
/*     */   
/*     */   public void write(byte[] b, int off, int len) throws IOException {
/* 410 */     write(ByteBuffer.wrap(b), off, len);
/*     */   }
/*     */ 
/*     */   
/*     */   public void write(ByteBuffer buf) throws IOException {
/* 415 */     write(buf, 0, buf.capacity());
/*     */   }
/*     */ 
/*     */   
/*     */   public void write(ByteBuffer buf, int off, int len) throws IOException {
/* 420 */     writeSetup(len);
/* 421 */     buf.limit(off + len);
/* 422 */     buf.position(off);
/* 423 */     this.position += this.channel.write(buf, this.position);
/* 424 */     this.buffer = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void write(int b) throws IOException {
/* 429 */     writeByte(b);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeBoolean(boolean v) throws IOException {
/* 434 */     writeByte(v ? 1 : 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeByte(int v) throws IOException {
/* 439 */     writeSetup(1);
/* 440 */     this.buffer.put((byte)v);
/* 441 */     doWrite(1);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeBytes(String s) throws IOException {
/* 446 */     write(s.getBytes("UTF-8"));
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeChar(int v) throws IOException {
/* 451 */     writeSetup(2);
/* 452 */     this.buffer.putChar((char)v);
/* 453 */     doWrite(2);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeChars(String s) throws IOException {
/* 458 */     write(s.getBytes("UTF-16BE"));
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeDouble(double v) throws IOException {
/* 463 */     writeSetup(8);
/* 464 */     this.buffer.putDouble(v);
/* 465 */     doWrite(8);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeFloat(float v) throws IOException {
/* 470 */     writeSetup(4);
/* 471 */     this.buffer.putFloat(v);
/* 472 */     doWrite(4);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeInt(int v) throws IOException {
/* 477 */     writeSetup(4);
/* 478 */     this.buffer.putInt(v);
/* 479 */     doWrite(4);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeLong(long v) throws IOException {
/* 484 */     writeSetup(8);
/* 485 */     this.buffer.putLong(v);
/* 486 */     doWrite(8);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeShort(int v) throws IOException {
/* 491 */     writeSetup(2);
/* 492 */     this.buffer.putShort((short)v);
/* 493 */     doWrite(2);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeUTF(String str) throws IOException {
/* 499 */     int strlen = (str.getBytes("UTF-8")).length + 2;
/* 500 */     writeSetup(strlen);
/* 501 */     this.raf.seek(this.position);
/* 502 */     this.raf.writeUTF(str);
/* 503 */     this.position += strlen;
/* 504 */     this.buffer = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void buffer(long offset, int size) throws IOException {
/* 516 */     this.position = offset;
/* 517 */     long newPosition = offset + size;
/* 518 */     if (newPosition < this.bufferStartPosition || newPosition > this.bufferStartPosition + this.bufferSize || this.buffer == null) {
/*     */ 
/*     */       
/* 521 */       this.bufferStartPosition = offset;
/* 522 */       if (length() > 0L && length() - 1L < this.bufferStartPosition) {
/* 523 */         this.bufferStartPosition = length() - 1L;
/*     */       }
/* 525 */       long newSize = Math.min(length() - this.bufferStartPosition, this.bufferSize);
/* 526 */       if (newSize < size && newSize == this.bufferSize) newSize = size; 
/* 527 */       if (newSize + this.bufferStartPosition > length()) {
/* 528 */         newSize = length() - this.bufferStartPosition;
/*     */       }
/* 530 */       offset = this.bufferStartPosition;
/* 531 */       ByteOrder byteOrder = (this.buffer == null) ? this.order : getOrder();
/* 532 */       this.buffer = this.byteBufferProvider.allocate(this.bufferStartPosition, (int)newSize);
/* 533 */       if (byteOrder != null) setOrder(byteOrder); 
/*     */     } 
/* 535 */     this.buffer.position((int)(offset - this.bufferStartPosition));
/* 536 */     if (this.buffer.position() + size > this.buffer.limit() && this.mapMode == FileChannel.MapMode.READ_WRITE)
/*     */     {
/*     */       
/* 539 */       this.buffer.limit(this.buffer.position() + size);
/*     */     }
/*     */   }
/*     */   
/*     */   private void writeSetup(int length) throws IOException {
/* 544 */     validateLength(length);
/* 545 */     buffer(this.position, length);
/*     */   }
/*     */   
/*     */   private void doWrite(int length) throws IOException {
/* 549 */     this.buffer.position(this.buffer.position() - length);
/* 550 */     this.channel.write(this.buffer, this.position);
/* 551 */     this.position += length;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/common/NIOFileHandle.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */