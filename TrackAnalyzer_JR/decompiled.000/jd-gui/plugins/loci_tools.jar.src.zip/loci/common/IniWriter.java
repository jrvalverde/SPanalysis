/*    */ package loci.common;
/*    */ 
/*    */ import java.io.BufferedWriter;
/*    */ import java.io.FileOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStreamWriter;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IniWriter
/*    */ {
/* 59 */   private static final Logger LOGGER = LoggerFactory.getLogger(IniWriter.class);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void saveINI(IniList ini, String path) throws IOException {
/* 68 */     saveINI(ini, path, true);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void saveINI(IniList ini, String path, boolean append) throws IOException {
/* 75 */     BufferedWriter out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(path, append), "UTF-8"));
/*    */ 
/*    */     
/* 78 */     for (IniTable table : ini) {
/* 79 */       String header = table.get("header");
/* 80 */       out.write("[" + header + "]\n");
/* 81 */       for (String key : table.keySet()) {
/* 82 */         out.write(key + " = " + table.get(key) + "\n");
/*    */       }
/* 84 */       out.write("\n");
/*    */     } 
/*    */     
/* 87 */     out.close();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/common/IniWriter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */