/*     */ package loci.common;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.channels.FileChannel;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NIOByteBufferProvider
/*     */ {
/*     */   public static final int MINIMUM_JAVA_VERSION = 6;
/*  71 */   private static final Logger LOGGER = LoggerFactory.getLogger(NIOByteBufferProvider.class);
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean useMappedByteBuffer = false;
/*     */ 
/*     */   
/*     */   private FileChannel channel;
/*     */ 
/*     */   
/*     */   private FileChannel.MapMode mapMode;
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  86 */     String mapping = System.getProperty("mappedBuffers");
/*  87 */     useMappedByteBuffer = Boolean.parseBoolean(mapping);
/*  88 */     LOGGER.debug("Using mapped byte buffer? {}", Boolean.valueOf(useMappedByteBuffer));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NIOByteBufferProvider(FileChannel channel, FileChannel.MapMode mapMode) {
/* 100 */     this.channel = channel;
/* 101 */     this.mapMode = mapMode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ByteBuffer allocate(long bufferStartPosition, int newSize) throws IOException {
/* 115 */     if (useMappedByteBuffer) {
/* 116 */       return allocateMappedByteBuffer(bufferStartPosition, newSize);
/*     */     }
/* 118 */     return allocateDirect(bufferStartPosition, newSize);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ByteBuffer allocateDirect(long bufferStartPosition, int newSize) throws IOException {
/* 132 */     ByteBuffer buffer = ByteBuffer.allocate(newSize);
/* 133 */     this.channel.read(buffer, bufferStartPosition);
/* 134 */     return buffer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ByteBuffer allocateMappedByteBuffer(long bufferStartPosition, int newSize) throws IOException {
/* 148 */     return this.channel.map(this.mapMode, bufferStartPosition, newSize);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/common/NIOByteBufferProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */