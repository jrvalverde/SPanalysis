package loci.common;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public interface IRandomAccess extends DataInput, DataOutput {
  void close() throws IOException;
  
  long getFilePointer() throws IOException;
  
  long length() throws IOException;
  
  ByteOrder getOrder();
  
  void setOrder(ByteOrder paramByteOrder);
  
  int read(byte[] paramArrayOfbyte) throws IOException;
  
  int read(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException;
  
  int read(ByteBuffer paramByteBuffer) throws IOException;
  
  int read(ByteBuffer paramByteBuffer, int paramInt1, int paramInt2) throws IOException;
  
  void seek(long paramLong) throws IOException;
  
  void write(ByteBuffer paramByteBuffer) throws IOException;
  
  void write(ByteBuffer paramByteBuffer, int paramInt1, int paramInt2) throws IOException;
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/common/IRandomAccess.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */