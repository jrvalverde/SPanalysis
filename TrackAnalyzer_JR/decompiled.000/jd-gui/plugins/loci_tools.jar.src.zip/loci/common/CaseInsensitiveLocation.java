/*     */ package loci.common;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.HashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CaseInsensitiveLocation
/*     */   extends Location
/*     */ {
/*  58 */   private static final Cache cache = new Cache();
/*     */ 
/*     */ 
/*     */   
/*     */   public CaseInsensitiveLocation(String pathname) throws IOException {
/*  63 */     super(findCaseInsensitive(new File(pathname)));
/*     */   }
/*     */   
/*     */   public CaseInsensitiveLocation(File file) throws IOException {
/*  67 */     super(findCaseInsensitive(file));
/*     */   }
/*     */   
/*     */   public CaseInsensitiveLocation(String parent, String child) throws IOException {
/*  71 */     super(findCaseInsensitive(new File(parent + File.separator + child)));
/*     */   }
/*     */   
/*     */   public CaseInsensitiveLocation(CaseInsensitiveLocation parent, String child) throws IOException {
/*  75 */     super(findCaseInsensitive(new File(parent.getAbsolutePath(), child)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void invalidateCache() {
/*  85 */     cache.invalidate();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void invalidateCache(File dir) {
/*  93 */     cache.invalidate(dir);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static File findCaseInsensitive(File name) throws IOException {
/* 100 */     return cache.lookup(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class Cache
/*     */   {
/* 122 */     private HashMap<String, HashMap<String, String>> cache = new HashMap<String, HashMap<String, String>>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private HashMap<String, String> fill(File dir) throws IOException {
/* 139 */       String dirname = dir.getAbsolutePath();
/* 140 */       HashMap<String, String> s = this.cache.get(dirname);
/* 141 */       if (s == null && dir.exists()) {
/* 142 */         s = new HashMap<String, String>();
/* 143 */         this.cache.put(dirname, s);
/*     */         
/* 145 */         String[] files = dir.list();
/* 146 */         for (String name : files) {
/* 147 */           String lower = name.toLowerCase();
/* 148 */           if (s.containsKey(lower))
/* 149 */             throw new IOException("Multiple files found for case-insensitive path"); 
/* 150 */           s.put(lower, name);
/*     */         } 
/*     */       } 
/* 153 */       return s;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void invalidate(File dir) {
/* 161 */       String dirname = dir.getAbsolutePath();
/* 162 */       this.cache.remove(dirname);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void invalidate() {
/* 169 */       this.cache.clear();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public File lookup(File name) throws IOException {
/* 180 */       File parent = name.getParentFile();
/* 181 */       if (parent != null) {
/* 182 */         HashMap<String, String> s = fill(parent);
/*     */         
/* 184 */         if (s != null) {
/* 185 */           String realname = name.getName();
/* 186 */           String lower = realname.toLowerCase();
/* 187 */           String f = s.get(lower);
/* 188 */           if (f != null)
/* 189 */             return new File(parent, f); 
/*     */         } 
/*     */       } 
/* 192 */       return name;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/common/CaseInsensitiveLocation.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */