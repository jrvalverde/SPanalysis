/*     */ package loci.common.services;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DependencyException
/*     */   extends Exception
/*     */ {
/*     */   private static final long serialVersionUID = -7836244849086491562L;
/*     */   private Class<? extends Service> failureClass;
/*     */   
/*     */   public DependencyException(String message) {
/*  63 */     super(message);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DependencyException(String message, Class<? extends Service> klass) {
/*  73 */     super(message);
/*  74 */     this.failureClass = klass;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DependencyException(String message, Class<? extends Service> klass, Throwable cause) {
/*  86 */     super(message, cause);
/*  87 */     this.failureClass = klass;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DependencyException(Throwable cause) {
/*  96 */     super(cause);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<? extends Service> getFailureClass() {
/* 105 */     return this.failureClass;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 111 */     if (this.failureClass == null)
/*     */     {
/* 113 */       return getMessage();
/*     */     }
/* 115 */     return getMessage() + " for " + this.failureClass;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/common/services/DependencyException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */