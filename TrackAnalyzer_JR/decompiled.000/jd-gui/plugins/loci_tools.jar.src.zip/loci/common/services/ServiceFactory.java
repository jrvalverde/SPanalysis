/*     */ package loci.common.services;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServiceFactory
/*     */ {
/*  61 */   private static final Logger LOGGER = LoggerFactory.getLogger(ServiceFactory.class);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String DEFAULT_PROPERTIES_FILE = "services.properties";
/*     */ 
/*     */ 
/*     */   
/*  69 */   private static Map<Class<? extends Service>, Constructor<? extends Service>> constructorCache = new HashMap<Class<? extends Service>, Constructor<? extends Service>>();
/*     */ 
/*     */ 
/*     */   
/*  73 */   private Map<Class<? extends Service>, Class<? extends Service>> services = new HashMap<Class<? extends Service>, Class<? extends Service>>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static ServiceFactory defaultFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServiceFactory() throws DependencyException {
/*  86 */     if (defaultFactory == null) {
/*  87 */       defaultFactory = new ServiceFactory("services.properties");
/*     */     }
/*  89 */     synchronized (defaultFactory) {
/*  90 */       this.services.putAll(defaultFactory.services);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServiceFactory(String path) throws DependencyException {
/* 101 */     InputStream stream = getClass().getResourceAsStream(path);
/* 102 */     Properties properties = new Properties();
/* 103 */     if (stream == null) {
/* 104 */       throw new DependencyException(path + " not found on CLASSPATH");
/*     */     }
/*     */     try {
/* 107 */       properties.load(stream);
/* 108 */       LOGGER.debug("Loaded properties from: {}", path);
/* 109 */     } catch (Throwable t) {
/* 110 */       throw new DependencyException(t);
/*     */     } finally {
/*     */       
/*     */       try {
/* 114 */         stream.close();
/*     */       }
/* 116 */       catch (IOException e) {
/* 117 */         LOGGER.warn("Error closing properties file stream.", e);
/*     */       } 
/*     */     } 
/* 120 */     Set<Map.Entry<Object, Object>> entries = properties.entrySet();
/* 121 */     for (Map.Entry<Object, Object> entry : entries) {
/* 122 */       String interfaceName = (String)entry.getKey();
/* 123 */       String implementationName = (String)entry.getValue();
/* 124 */       Class<? extends Service> interfaceClass = null;
/* 125 */       Class<? extends Service> implementationClass = null;
/* 126 */       ClassLoader loader = getClass().getClassLoader();
/*     */       try {
/* 128 */         interfaceClass = (Class)Class.forName(interfaceName, false, loader);
/*     */       
/*     */       }
/* 131 */       catch (Throwable t) {
/* 132 */         LOGGER.debug("CLASSPATH missing interface: {}", interfaceName, t);
/*     */         continue;
/*     */       } 
/*     */       try {
/* 136 */         implementationClass = (Class)Class.forName(implementationName, false, loader);
/*     */       
/*     */       }
/* 139 */       catch (Throwable t) {
/* 140 */         LOGGER.debug("CLASSPATH missing implementation or implementation dependency: {}", implementationName, t);
/*     */       } 
/*     */ 
/*     */       
/* 144 */       this.services.put(interfaceClass, implementationClass);
/* 145 */       LOGGER.debug("Added interface {} and implementation {}", interfaceClass, implementationClass);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T extends Service> T getInstance(Class<T> type) throws DependencyException {
/* 160 */     Class<T> impl = (Class<T>)this.services.get(type);
/* 161 */     if (impl == null && this.services.containsKey(type)) {
/* 162 */       throw new DependencyException("Unable to instantiate service. Missing implementation or implementation dependency", type);
/*     */     }
/*     */ 
/*     */     
/* 166 */     if (impl == null) {
/* 167 */       throw new DependencyException("Unknown service type: " + type);
/*     */     }
/* 169 */     Constructor<T> constructor = getConstructor(impl);
/*     */     try {
/* 171 */       return constructor.newInstance(new Object[0]);
/* 172 */     } catch (Throwable t) {
/* 173 */       throw new DependencyException("Unable to instantiate service", type, t);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private <T extends Service> Constructor<T> getConstructor(Class<T> klass) throws DependencyException {
/* 188 */     synchronized (constructorCache) {
/* 189 */       Constructor<? extends Service> constructor = constructorCache.get(klass);
/*     */       
/* 191 */       if (constructor == null) {
/*     */         try {
/* 193 */           Class<T> concreteClass = (Class)Class.forName(klass.getName());
/* 194 */           constructor = concreteClass.getDeclaredConstructor(new Class[0]);
/* 195 */           constructorCache.put(klass, constructor);
/*     */         }
/* 197 */         catch (Throwable t) {
/* 198 */           throw new DependencyException("Unable to retrieve constructor", klass, t);
/*     */         } 
/*     */       }
/*     */       
/* 202 */       return (Constructor)constructor;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/common/services/ServiceFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */