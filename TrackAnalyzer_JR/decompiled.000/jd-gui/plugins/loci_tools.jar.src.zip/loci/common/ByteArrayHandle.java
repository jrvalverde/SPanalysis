/*     */ package loci.common;
/*     */ 
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.nio.BufferUnderflowException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.ByteOrder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ByteArrayHandle
/*     */   extends AbstractNIOHandle
/*     */ {
/*     */   protected static final int INITIAL_LENGTH = 1000000;
/*     */   protected ByteBuffer buffer;
/*     */   
/*     */   public ByteArrayHandle(byte[] bytes) {
/*  76 */     this.buffer = ByteBuffer.wrap(bytes);
/*     */   }
/*     */   
/*     */   public ByteArrayHandle(ByteBuffer bytes) {
/*  80 */     this.buffer = bytes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ByteArrayHandle(int capacity) {
/*  88 */     this.buffer = ByteBuffer.allocate(capacity);
/*  89 */     this.buffer.limit(capacity);
/*     */   }
/*     */ 
/*     */   
/*     */   public ByteArrayHandle() {
/*  94 */     this.buffer = ByteBuffer.allocate(1000000);
/*  95 */     this.buffer.limit(0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getBytes() {
/* 102 */     return this.buffer.array();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ByteBuffer getByteBuffer() {
/* 112 */     return this.buffer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLength(long length) throws IOException {
/* 119 */     if (length > this.buffer.capacity()) {
/* 120 */       long fp = getFilePointer();
/* 121 */       ByteBuffer tmp = ByteBuffer.allocate((int)(length * 2L));
/* 122 */       ByteOrder order = (this.buffer == null) ? null : getOrder();
/* 123 */       seek(0L);
/* 124 */       this.buffer = tmp.put(this.buffer);
/* 125 */       if (order != null) setOrder(order); 
/* 126 */       seek(fp);
/*     */     } 
/* 128 */     this.buffer.limit((int)length);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public long getFilePointer() {
/* 138 */     return this.buffer.position();
/*     */   }
/*     */ 
/*     */   
/*     */   public long length() {
/* 143 */     return this.buffer.limit();
/*     */   }
/*     */ 
/*     */   
/*     */   public int read(byte[] b) throws IOException {
/* 148 */     return read(b, 0, b.length);
/*     */   }
/*     */ 
/*     */   
/*     */   public int read(byte[] b, int off, int len) throws IOException {
/* 153 */     if (getFilePointer() + len > length()) {
/* 154 */       len = (int)(length() - getFilePointer());
/*     */     }
/* 156 */     this.buffer.get(b, off, len);
/* 157 */     return len;
/*     */   }
/*     */ 
/*     */   
/*     */   public int read(ByteBuffer buf) throws IOException {
/* 162 */     return read(buf, 0, buf.capacity());
/*     */   }
/*     */ 
/*     */   
/*     */   public int read(ByteBuffer buf, int off, int len) throws IOException {
/* 167 */     if (buf.hasArray()) {
/* 168 */       this.buffer.get(buf.array(), off, len);
/* 169 */       return len;
/*     */     } 
/*     */     
/* 172 */     byte[] b = new byte[len];
/* 173 */     read(b);
/* 174 */     buf.put(b, 0, len);
/* 175 */     return len;
/*     */   }
/*     */ 
/*     */   
/*     */   public void seek(long pos) throws IOException {
/* 180 */     if (pos > length()) setLength(pos); 
/* 181 */     this.buffer.position((int)pos);
/*     */   }
/*     */ 
/*     */   
/*     */   public ByteOrder getOrder() {
/* 186 */     return this.buffer.order();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setOrder(ByteOrder order) {
/* 191 */     this.buffer.order(order);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean readBoolean() throws IOException {
/* 198 */     return (readByte() != 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public byte readByte() throws IOException {
/* 203 */     if (getFilePointer() + 1L > length()) {
/* 204 */       throw new EOFException("Attempting to read beyond end of file.");
/*     */     }
/*     */     try {
/* 207 */       return this.buffer.get();
/*     */     }
/* 209 */     catch (BufferUnderflowException e) {
/* 210 */       EOFException eof = new EOFException();
/* 211 */       eof.initCause(e);
/* 212 */       throw eof;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public char readChar() throws IOException {
/* 218 */     if (getFilePointer() + 2L > length()) {
/* 219 */       throw new EOFException("Attempting to read beyond end of file.");
/*     */     }
/*     */     try {
/* 222 */       return this.buffer.getChar();
/*     */     }
/* 224 */     catch (BufferUnderflowException e) {
/* 225 */       EOFException eof = new EOFException();
/* 226 */       eof.initCause(e);
/* 227 */       throw eof;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public double readDouble() throws IOException {
/* 233 */     if (getFilePointer() + 8L > length()) {
/* 234 */       throw new EOFException("Attempting to read beyond end of file.");
/*     */     }
/*     */     try {
/* 237 */       return this.buffer.getDouble();
/*     */     }
/* 239 */     catch (BufferUnderflowException e) {
/* 240 */       EOFException eof = new EOFException();
/* 241 */       eof.initCause(e);
/* 242 */       throw eof;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public float readFloat() throws IOException {
/* 248 */     if (getFilePointer() + 4L > length()) {
/* 249 */       throw new EOFException("Attempting to read beyond end of file.");
/*     */     }
/*     */     try {
/* 252 */       return this.buffer.getFloat();
/*     */     }
/* 254 */     catch (BufferUnderflowException e) {
/* 255 */       EOFException eof = new EOFException();
/* 256 */       eof.initCause(e);
/* 257 */       throw eof;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void readFully(byte[] b) throws IOException {
/* 263 */     readFully(b, 0, b.length);
/*     */   }
/*     */ 
/*     */   
/*     */   public void readFully(byte[] b, int off, int len) throws IOException {
/* 268 */     if (getFilePointer() + len > length()) {
/* 269 */       throw new EOFException("Attempting to read beyond end of file.");
/*     */     }
/*     */     try {
/* 272 */       this.buffer.get(b, off, len);
/*     */     }
/* 274 */     catch (BufferUnderflowException e) {
/* 275 */       EOFException eof = new EOFException();
/* 276 */       eof.initCause(e);
/* 277 */       throw eof;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int readInt() throws IOException {
/* 283 */     if (getFilePointer() + 4L > length()) {
/* 284 */       throw new EOFException("Attempting to read beyond end of file.");
/*     */     }
/*     */     try {
/* 287 */       return this.buffer.getInt();
/*     */     }
/* 289 */     catch (BufferUnderflowException e) {
/* 290 */       EOFException eof = new EOFException();
/* 291 */       eof.initCause(e);
/* 292 */       throw eof;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String readLine() throws IOException {
/* 298 */     throw new IOException("Unimplemented");
/*     */   }
/*     */ 
/*     */   
/*     */   public long readLong() throws IOException {
/* 303 */     if (getFilePointer() + 8L > length()) {
/* 304 */       throw new EOFException("Attempting to read beyond end of file.");
/*     */     }
/*     */     try {
/* 307 */       return this.buffer.getLong();
/*     */     }
/* 309 */     catch (BufferUnderflowException e) {
/* 310 */       EOFException eof = new EOFException();
/* 311 */       eof.initCause(e);
/* 312 */       throw eof;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public short readShort() throws IOException {
/* 318 */     if (getFilePointer() + 2L > length()) {
/* 319 */       throw new EOFException("Attempting to read beyond end of file.");
/*     */     }
/*     */     try {
/* 322 */       return this.buffer.getShort();
/*     */     }
/* 324 */     catch (BufferUnderflowException e) {
/* 325 */       EOFException eof = new EOFException();
/* 326 */       eof.initCause(e);
/* 327 */       throw eof;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int readUnsignedByte() throws IOException {
/* 333 */     return readByte() & 0xFF;
/*     */   }
/*     */ 
/*     */   
/*     */   public int readUnsignedShort() throws IOException {
/* 338 */     return readShort() & 0xFFFF;
/*     */   }
/*     */ 
/*     */   
/*     */   public String readUTF() throws IOException {
/* 343 */     int length = readUnsignedShort();
/* 344 */     byte[] b = new byte[length];
/* 345 */     read(b);
/* 346 */     return new String(b, "UTF-8");
/*     */   }
/*     */ 
/*     */   
/*     */   public int skipBytes(int n) throws IOException {
/* 351 */     int skipped = (int)Math.min(n, length() - getFilePointer());
/* 352 */     if (skipped < 0) return 0; 
/* 353 */     seek(getFilePointer() + skipped);
/* 354 */     return skipped;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(byte[] b) throws IOException {
/* 361 */     write(b, 0, b.length);
/*     */   }
/*     */ 
/*     */   
/*     */   public void write(byte[] b, int off, int len) throws IOException {
/* 366 */     validateLength(len);
/* 367 */     this.buffer.put(b, off, len);
/*     */   }
/*     */ 
/*     */   
/*     */   public void write(ByteBuffer buf) throws IOException {
/* 372 */     write(buf, 0, buf.capacity());
/*     */   }
/*     */ 
/*     */   
/*     */   public void write(ByteBuffer buf, int off, int len) throws IOException {
/* 377 */     validateLength(len);
/* 378 */     buf.position(off);
/* 379 */     buf.limit(off + len);
/* 380 */     this.buffer.put(buf);
/*     */   }
/*     */ 
/*     */   
/*     */   public void write(int b) throws IOException {
/* 385 */     validateLength(1);
/* 386 */     this.buffer.put((byte)b);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeBoolean(boolean v) throws IOException {
/* 391 */     write(v ? 1 : 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeByte(int v) throws IOException {
/* 396 */     write(v);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeBytes(String s) throws IOException {
/* 401 */     write(s.getBytes("UTF-8"));
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeChar(int v) throws IOException {
/* 406 */     validateLength(2);
/* 407 */     this.buffer.putChar((char)v);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeChars(String s) throws IOException {
/* 412 */     int len = 2 * s.length();
/* 413 */     validateLength(len);
/* 414 */     char[] c = s.toCharArray();
/* 415 */     for (int i = 0; i < c.length; i++) {
/* 416 */       writeChar(c[i]);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeDouble(double v) throws IOException {
/* 422 */     validateLength(8);
/* 423 */     this.buffer.putDouble(v);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeFloat(float v) throws IOException {
/* 428 */     validateLength(4);
/* 429 */     this.buffer.putFloat(v);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeInt(int v) throws IOException {
/* 434 */     validateLength(4);
/* 435 */     this.buffer.putInt(v);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeLong(long v) throws IOException {
/* 440 */     validateLength(8);
/* 441 */     this.buffer.putLong(v);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeShort(int v) throws IOException {
/* 446 */     validateLength(2);
/* 447 */     this.buffer.putShort((short)v);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeUTF(String str) throws IOException {
/* 452 */     byte[] b = str.getBytes("UTF-8");
/* 453 */     writeShort(b.length);
/* 454 */     write(b);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/common/ByteArrayHandle.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */