/*     */ package loci.common;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Enumeration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DebugTools
/*     */ {
/*     */   public static String getStackTrace(Throwable t) {
/*     */     try {
/*  66 */       ByteArrayOutputStream out = new ByteArrayOutputStream();
/*  67 */       t.printStackTrace(new PrintStream(out, false, "UTF-8"));
/*  68 */       return new String(out.toByteArray(), "UTF-8");
/*     */     }
/*  70 */     catch (IOException e) {
/*  71 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized boolean enableLogging(String level) {
/*  83 */     ReflectedUniverse r = new ReflectedUniverse();
/*     */     try {
/*  85 */       r.exec("import org.apache.log4j.Level");
/*  86 */       r.exec("import org.apache.log4j.Logger");
/*  87 */       r.exec("root = Logger.getRootLogger()");
/*  88 */       r.exec("root.setLevel(Level." + level + ")");
/*  89 */       Enumeration en = (Enumeration)r.exec("root.getAllAppenders()");
/*  90 */       if (!en.hasMoreElements())
/*     */       {
/*  92 */         r.exec("import org.apache.log4j.ConsoleAppender");
/*  93 */         r.exec("import org.apache.log4j.PatternLayout");
/*  94 */         r.setVar("pattern", "%m%n");
/*  95 */         r.exec("layout = new PatternLayout(pattern)");
/*  96 */         r.exec("appender = new ConsoleAppender(layout)");
/*  97 */         r.exec("root.addAppender(appender)");
/*     */       }
/*     */     
/* 100 */     } catch (ReflectException exc) {
/* 101 */       return false;
/*     */     } 
/* 103 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getFieldName(Class<?> c, int value) {
/* 111 */     Field[] fields = c.getDeclaredFields();
/* 112 */     for (int i = 0; i < fields.length; i++) {
/* 113 */       if (Modifier.isStatic(fields[i].getModifiers())) {
/* 114 */         fields[i].setAccessible(true);
/*     */         
/* 116 */         try { if (fields[i].getInt(null) == value) return fields[i].getName();
/*     */            }
/* 118 */         catch (IllegalAccessException exc) {  }
/* 119 */         catch (IllegalArgumentException exc) {}
/*     */       } 
/* 121 */     }  return "" + value;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/common/DebugTools.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */