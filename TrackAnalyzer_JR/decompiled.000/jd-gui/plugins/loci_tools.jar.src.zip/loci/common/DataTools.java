/*      */ package loci.common;
/*      */ 
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.text.DecimalFormatSymbols;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class DataTools
/*      */ {
/*      */   public static String readFile(String id) throws IOException {
/*   69 */     RandomAccessInputStream in = new RandomAccessInputStream(id);
/*   70 */     long idLen = in.length();
/*   71 */     if (idLen > 2147483647L) {
/*   72 */       throw new IOException("File too large");
/*      */     }
/*   74 */     int len = (int)idLen;
/*   75 */     String data = in.readString(len);
/*   76 */     in.close();
/*   77 */     return data;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static short bytesToShort(byte[] bytes, int off, int len, boolean little) {
/*   90 */     if (bytes.length - off < len) len = bytes.length - off; 
/*   91 */     short total = 0;
/*   92 */     for (int i = 0, ndx = off; i < len; i++, ndx++) {
/*   93 */       total = (short)(total | ((bytes[ndx] < 0) ? (256 + bytes[ndx]) : bytes[ndx]) << (little ? i : (len - i - 1)) * 8);
/*      */     }
/*      */     
/*   96 */     return total;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static short bytesToShort(byte[] bytes, int off, boolean little) {
/*  105 */     return bytesToShort(bytes, off, 2, little);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static short bytesToShort(byte[] bytes, boolean little) {
/*  114 */     return bytesToShort(bytes, 0, 2, little);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static short bytesToShort(short[] bytes, int off, int len, boolean little) {
/*  125 */     if (bytes.length - off < len) len = bytes.length - off; 
/*  126 */     short total = 0;
/*  127 */     for (int i = 0, ndx = off; i < len; i++, ndx++) {
/*  128 */       total = (short)(total | bytes[ndx] << (little ? i : (len - i - 1)) * 8);
/*      */     }
/*  130 */     return total;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static short bytesToShort(short[] bytes, int off, boolean little) {
/*  139 */     return bytesToShort(bytes, off, 2, little);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static short bytesToShort(short[] bytes, boolean little) {
/*  148 */     return bytesToShort(bytes, 0, 2, little);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int bytesToInt(byte[] bytes, int off, int len, boolean little) {
/*  159 */     if (bytes.length - off < len) len = bytes.length - off; 
/*  160 */     int total = 0;
/*  161 */     for (int i = 0, ndx = off; i < len; i++, ndx++) {
/*  162 */       total |= ((bytes[ndx] < 0) ? (256 + bytes[ndx]) : bytes[ndx]) << (little ? i : (len - i - 1)) * 8;
/*      */     }
/*      */     
/*  165 */     return total;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int bytesToInt(byte[] bytes, int off, boolean little) {
/*  174 */     return bytesToInt(bytes, off, 4, little);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int bytesToInt(byte[] bytes, boolean little) {
/*  183 */     return bytesToInt(bytes, 0, 4, little);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int bytesToInt(short[] bytes, int off, int len, boolean little) {
/*  194 */     if (bytes.length - off < len) len = bytes.length - off; 
/*  195 */     int total = 0;
/*  196 */     for (int i = 0, ndx = off; i < len; i++, ndx++) {
/*  197 */       total |= bytes[ndx] << (little ? i : (len - i - 1)) * 8;
/*      */     }
/*  199 */     return total;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int bytesToInt(short[] bytes, int off, boolean little) {
/*  208 */     return bytesToInt(bytes, off, 4, little);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int bytesToInt(short[] bytes, boolean little) {
/*  217 */     return bytesToInt(bytes, 0, 4, little);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static float bytesToFloat(byte[] bytes, int off, int len, boolean little) {
/*  228 */     return Float.intBitsToFloat(bytesToInt(bytes, off, len, little));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static float bytesToFloat(byte[] bytes, int off, boolean little) {
/*  237 */     return bytesToFloat(bytes, off, 4, little);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static float bytesToFloat(byte[] bytes, boolean little) {
/*  246 */     return bytesToFloat(bytes, 0, 4, little);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static float bytesToFloat(short[] bytes, int off, int len, boolean little) {
/*  257 */     return Float.intBitsToFloat(bytesToInt(bytes, off, len, little));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static float bytesToFloat(short[] bytes, int off, boolean little) {
/*  266 */     return bytesToInt(bytes, off, 4, little);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static float bytesToFloat(short[] bytes, boolean little) {
/*  275 */     return bytesToInt(bytes, 0, 4, little);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long bytesToLong(byte[] bytes, int off, int len, boolean little) {
/*  286 */     if (bytes.length - off < len) len = bytes.length - off; 
/*  287 */     long total = 0L;
/*  288 */     for (int i = 0, ndx = off; i < len; i++, ndx++) {
/*  289 */       total |= ((bytes[ndx] < 0) ? (256L + bytes[ndx]) : bytes[ndx]) << (little ? i : (len - i - 1)) * 8;
/*      */     }
/*      */     
/*  292 */     return total;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long bytesToLong(byte[] bytes, int off, boolean little) {
/*  301 */     return bytesToLong(bytes, off, 8, little);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long bytesToLong(byte[] bytes, boolean little) {
/*  310 */     return bytesToLong(bytes, 0, 8, little);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long bytesToLong(short[] bytes, int off, int len, boolean little) {
/*  321 */     if (bytes.length - off < len) len = bytes.length - off; 
/*  322 */     long total = 0L;
/*  323 */     for (int i = 0, ndx = off; i < len; i++, ndx++) {
/*  324 */       total |= bytes[ndx] << (little ? i : (len - i - 1)) * 8;
/*      */     }
/*  326 */     return total;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long bytesToLong(short[] bytes, int off, boolean little) {
/*  335 */     return bytesToLong(bytes, off, 8, little);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long bytesToLong(short[] bytes, boolean little) {
/*  344 */     return bytesToLong(bytes, 0, 8, little);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double bytesToDouble(byte[] bytes, int off, int len, boolean little) {
/*  355 */     return Double.longBitsToDouble(bytesToLong(bytes, off, len, little));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double bytesToDouble(byte[] bytes, int off, boolean little) {
/*  366 */     return bytesToDouble(bytes, off, 8, little);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double bytesToDouble(byte[] bytes, boolean little) {
/*  375 */     return bytesToDouble(bytes, 0, 8, little);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double bytesToDouble(short[] bytes, int off, int len, boolean little) {
/*  386 */     return Double.longBitsToDouble(bytesToLong(bytes, off, len, little));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double bytesToDouble(short[] bytes, int off, boolean little) {
/*  397 */     return bytesToDouble(bytes, off, 8, little);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double bytesToDouble(short[] bytes, boolean little) {
/*  406 */     return bytesToDouble(bytes, 0, 8, little);
/*      */   }
/*      */ 
/*      */   
/*      */   public static String bytesToHex(byte[] b) {
/*  411 */     StringBuffer sb = new StringBuffer();
/*  412 */     for (int i = 0; i < b.length; i++) {
/*  413 */       String a = Integer.toHexString(b[i] & 0xFF);
/*  414 */       if (a.length() == 1) sb.append("0"); 
/*  415 */       sb.append(a);
/*      */     } 
/*  417 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   
/*      */   public static String sanitizeDouble(String value) {
/*  422 */     value = value.replaceAll("[^0-9,\\.]", "");
/*  423 */     char separator = (new DecimalFormatSymbols()).getDecimalSeparator();
/*  424 */     char usedSeparator = (separator == '.') ? ',' : '.';
/*  425 */     value = value.replace(usedSeparator, separator);
/*      */     try {
/*  427 */       Double.parseDouble(value);
/*      */     }
/*  429 */     catch (Exception e) {
/*  430 */       value = value.replace(separator, usedSeparator);
/*      */     } 
/*  432 */     return value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] shortToBytes(short value, boolean little) {
/*  439 */     byte[] v = new byte[2];
/*  440 */     unpackBytes(value, v, 0, 2, little);
/*  441 */     return v;
/*      */   }
/*      */ 
/*      */   
/*      */   public static byte[] intToBytes(int value, boolean little) {
/*  446 */     byte[] v = new byte[4];
/*  447 */     unpackBytes(value, v, 0, 4, little);
/*  448 */     return v;
/*      */   }
/*      */ 
/*      */   
/*      */   public static byte[] floatToBytes(float value, boolean little) {
/*  453 */     byte[] v = new byte[4];
/*  454 */     unpackBytes(Float.floatToIntBits(value), v, 0, 4, little);
/*  455 */     return v;
/*      */   }
/*      */ 
/*      */   
/*      */   public static byte[] longToBytes(long value, boolean little) {
/*  460 */     byte[] v = new byte[8];
/*  461 */     unpackBytes(value, v, 0, 8, little);
/*  462 */     return v;
/*      */   }
/*      */ 
/*      */   
/*      */   public static byte[] doubleToBytes(double value, boolean little) {
/*  467 */     byte[] v = new byte[8];
/*  468 */     unpackBytes(Double.doubleToLongBits(value), v, 0, 8, little);
/*  469 */     return v;
/*      */   }
/*      */ 
/*      */   
/*      */   public static byte[] shortsToBytes(short[] values, boolean little) {
/*  474 */     byte[] v = new byte[values.length * 2];
/*  475 */     for (int i = 0; i < values.length; i++) {
/*  476 */       unpackBytes(values[i], v, i * 2, 2, little);
/*      */     }
/*  478 */     return v;
/*      */   }
/*      */ 
/*      */   
/*      */   public static byte[] intsToBytes(int[] values, boolean little) {
/*  483 */     byte[] v = new byte[values.length * 4];
/*  484 */     for (int i = 0; i < values.length; i++) {
/*  485 */       unpackBytes(values[i], v, i * 4, 4, little);
/*      */     }
/*  487 */     return v;
/*      */   }
/*      */ 
/*      */   
/*      */   public static byte[] floatsToBytes(float[] values, boolean little) {
/*  492 */     byte[] v = new byte[values.length * 4];
/*  493 */     for (int i = 0; i < values.length; i++) {
/*  494 */       unpackBytes(Float.floatToIntBits(values[i]), v, i * 4, 4, little);
/*      */     }
/*  496 */     return v;
/*      */   }
/*      */ 
/*      */   
/*      */   public static byte[] longsToBytes(long[] values, boolean little) {
/*  501 */     byte[] v = new byte[values.length * 8];
/*  502 */     for (int i = 0; i < values.length; i++) {
/*  503 */       unpackBytes(values[i], v, i * 8, 8, little);
/*      */     }
/*  505 */     return v;
/*      */   }
/*      */ 
/*      */   
/*      */   public static byte[] doublesToBytes(double[] values, boolean little) {
/*  510 */     byte[] v = new byte[values.length * 8];
/*  511 */     for (int i = 0; i < values.length; i++) {
/*  512 */       unpackBytes(Double.doubleToLongBits(values[i]), v, i * 8, 8, little);
/*      */     }
/*  514 */     return v;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static void unpackShort(short value, byte[] buf, int ndx, boolean little) {
/*  522 */     unpackBytes(value, buf, ndx, 2, little);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void unpackBytes(long value, byte[] buf, int ndx, int nBytes, boolean little) {
/*  535 */     if (buf.length < ndx + nBytes) {
/*  536 */       throw new IllegalArgumentException("Invalid indices: buf.length=" + buf.length + ", ndx=" + ndx + ", nBytes=" + nBytes);
/*      */     }
/*      */     
/*  539 */     if (little) {
/*  540 */       for (int i = 0; i < nBytes; i++) {
/*  541 */         buf[ndx + i] = (byte)(int)(value >> 8 * i & 0xFFL);
/*      */       }
/*      */     } else {
/*      */       
/*  545 */       for (int i = 0; i < nBytes; i++) {
/*  546 */         buf[ndx + i] = (byte)(int)(value >> 8 * (nBytes - i - 1) & 0xFFL);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object makeDataArray(byte[] b, int bpp, boolean fp, boolean little) {
/*  563 */     if (bpp == 1) {
/*  564 */       return b;
/*      */     }
/*  566 */     if (bpp == 2) {
/*  567 */       short[] s = new short[b.length / 2];
/*  568 */       for (int i = 0; i < s.length; i++) {
/*  569 */         s[i] = bytesToShort(b, i * 2, 2, little);
/*      */       }
/*  571 */       return s;
/*      */     } 
/*  573 */     if (bpp == 4 && fp) {
/*  574 */       float[] f = new float[b.length / 4];
/*  575 */       for (int i = 0; i < f.length; i++) {
/*  576 */         f[i] = bytesToFloat(b, i * 4, 4, little);
/*      */       }
/*  578 */       return f;
/*      */     } 
/*  580 */     if (bpp == 4) {
/*  581 */       int[] i = new int[b.length / 4];
/*  582 */       for (int j = 0; j < i.length; j++) {
/*  583 */         i[j] = bytesToInt(b, j * 4, 4, little);
/*      */       }
/*  585 */       return i;
/*      */     } 
/*  587 */     if (bpp == 8 && fp) {
/*  588 */       double[] d = new double[b.length / 8];
/*  589 */       for (int i = 0; i < d.length; i++) {
/*  590 */         d[i] = bytesToDouble(b, i * 8, 8, little);
/*      */       }
/*  592 */       return d;
/*      */     } 
/*  594 */     if (bpp == 8) {
/*  595 */       long[] l = new long[b.length / 8];
/*  596 */       for (int i = 0; i < l.length; i++) {
/*  597 */         l[i] = bytesToLong(b, i * 8, 8, little);
/*      */       }
/*  599 */       return l;
/*      */     } 
/*  601 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static Object makeDataArray(byte[] b, int bpp, boolean fp, boolean little, boolean signed) {
/*  613 */     return makeDataArray(b, bpp, fp, little);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object makeDataArray2D(byte[] b, int bpp, boolean fp, boolean little, int height) {
/*  635 */     if (b.length % bpp * height != 0) {
/*  636 */       throw new IllegalArgumentException("Array length mismatch: b.length=" + b.length + "; bpp=" + bpp + "; height=" + height);
/*      */     }
/*      */     
/*  639 */     int width = b.length / bpp * height;
/*  640 */     if (bpp == 1) {
/*  641 */       byte[][] b2 = new byte[height][width];
/*  642 */       for (int y = 0; y < height; y++) {
/*  643 */         int index = width * y;
/*  644 */         System.arraycopy(b, index, b2[y], 0, width);
/*      */       } 
/*  646 */       return b2;
/*      */     } 
/*  648 */     if (bpp == 2) {
/*  649 */       short[][] s = new short[height][width];
/*  650 */       for (int y = 0; y < height; y++) {
/*  651 */         for (int x = 0; x < width; x++) {
/*  652 */           int index = 2 * (width * y + x);
/*  653 */           s[y][x] = bytesToShort(b, index, 2, little);
/*      */         } 
/*      */       } 
/*  656 */       return s;
/*      */     } 
/*  658 */     if (bpp == 4 && fp) {
/*  659 */       float[][] f = new float[height][width];
/*  660 */       for (int y = 0; y < height; y++) {
/*  661 */         for (int x = 0; x < width; x++) {
/*  662 */           int index = 4 * (width * y + x);
/*  663 */           f[y][x] = bytesToFloat(b, index, 4, little);
/*      */         } 
/*      */       } 
/*  666 */       return f;
/*      */     } 
/*  668 */     if (bpp == 4) {
/*  669 */       int[][] i = new int[height][width];
/*  670 */       for (int y = 0; y < height; y++) {
/*  671 */         for (int x = 0; x < width; x++) {
/*  672 */           int index = 4 * (width * y + x);
/*  673 */           i[y][x] = bytesToInt(b, index, 4, little);
/*      */         } 
/*      */       } 
/*  676 */       return i;
/*      */     } 
/*  678 */     if (bpp == 8 && fp) {
/*  679 */       double[][] d = new double[height][width];
/*  680 */       for (int y = 0; y < height; y++) {
/*  681 */         for (int x = 0; x < width; x++) {
/*  682 */           int index = 8 * (width * y + x);
/*  683 */           d[y][x] = bytesToDouble(b, index, 8, little);
/*      */         } 
/*      */       } 
/*  686 */       return d;
/*      */     } 
/*  688 */     if (bpp == 8) {
/*  689 */       long[][] l = new long[height][width];
/*  690 */       for (int y = 0; y < height; y++) {
/*  691 */         for (int x = 0; x < width; x++) {
/*  692 */           int index = 8 * (width * y + x);
/*  693 */           l[y][x] = bytesToLong(b, index, 8, little);
/*      */         } 
/*      */       } 
/*  696 */       return l;
/*      */     } 
/*  698 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static short swap(short x) {
/*  704 */     return (short)(x << 8 | x >> 8 & 0xFF);
/*      */   }
/*      */   
/*      */   public static char swap(char x) {
/*  708 */     return (char)(x << 8 | x >> 8 & 0xFF);
/*      */   }
/*      */   
/*      */   public static int swap(int x) {
/*  712 */     return swap((short)x) << 16 | swap((short)(x >> 16)) & 0xFFFF;
/*      */   }
/*      */   
/*      */   public static long swap(long x) {
/*  716 */     return swap((int)x) << 32L | swap((int)(x >> 32L)) & 0xFFFFFFFFL;
/*      */   }
/*      */   
/*      */   public static float swap(float x) {
/*  720 */     return Float.intBitsToFloat(swap(Float.floatToIntBits(x)));
/*      */   }
/*      */   
/*      */   public static double swap(double x) {
/*  724 */     return Double.longBitsToDouble(swap(Double.doubleToLongBits(x)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static String getHexString(byte[] b) {
/*  735 */     return bytesToHex(b);
/*      */   }
/*      */ 
/*      */   
/*      */   public static String stripString(String toStrip) {
/*  740 */     StringBuffer s = new StringBuffer();
/*  741 */     for (int i = 0; i < toStrip.length(); i++) {
/*  742 */       if (toStrip.charAt(i) != '\000') {
/*  743 */         s.append(toStrip.charAt(i));
/*      */       }
/*      */     } 
/*  746 */     return s.toString().trim();
/*      */   }
/*      */ 
/*      */   
/*      */   public static boolean samePrefix(String s1, String s2) {
/*  751 */     if (s1 == null || s2 == null) return false; 
/*  752 */     int n1 = s1.indexOf(".");
/*  753 */     int n2 = s2.indexOf(".");
/*  754 */     if (n1 == -1 || n2 == -1) return false;
/*      */     
/*  756 */     int slash1 = s1.lastIndexOf(File.pathSeparator);
/*  757 */     int slash2 = s2.lastIndexOf(File.pathSeparator);
/*      */     
/*  759 */     String sub1 = s1.substring(slash1 + 1, n1);
/*  760 */     String sub2 = s2.substring(slash2 + 1, n2);
/*  761 */     return (sub1.equals(sub2) || sub1.startsWith(sub2) || sub2.startsWith(sub1));
/*      */   }
/*      */ 
/*      */   
/*      */   public static String sanitize(String s) {
/*  766 */     if (s == null) return null; 
/*  767 */     StringBuffer buf = new StringBuffer(s);
/*  768 */     for (int i = 0; i < buf.length(); i++) {
/*  769 */       char c = buf.charAt(i);
/*  770 */       if (c != '\t' && c != '\n' && Character.isISOControl(c)) {
/*  771 */         buf = buf.deleteCharAt(i--);
/*      */       }
/*      */     } 
/*  774 */     return buf.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static float[] normalizeFloats(float[] data) {
/*  784 */     float[] rtn = new float[data.length];
/*      */ 
/*      */     
/*  787 */     float min = Float.MAX_VALUE;
/*  788 */     float max = Float.MIN_VALUE; int i;
/*  789 */     for (i = 0; i < data.length; i++) {
/*  790 */       if (data[i] != Float.POSITIVE_INFINITY && data[i] != Float.NEGATIVE_INFINITY) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  795 */         if (data[i] < min) min = data[i]; 
/*  796 */         if (data[i] > max) max = data[i];
/*      */       
/*      */       } 
/*      */     } 
/*  800 */     for (i = 0; i < data.length; i++) {
/*  801 */       if (data[i] == Float.POSITIVE_INFINITY) { data[i] = max; }
/*  802 */       else if (data[i] == Float.NEGATIVE_INFINITY) { data[i] = min; }
/*      */     
/*      */     } 
/*      */     
/*  806 */     float range = max - min;
/*  807 */     for (int j = 0; j < rtn.length; j++) {
/*  808 */       rtn[j] = (data[j] - min) / range;
/*      */     }
/*  810 */     return rtn;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double[] normalizeDoubles(double[] data) {
/*  818 */     double[] rtn = new double[data.length];
/*      */ 
/*      */     
/*  821 */     double min = Double.MAX_VALUE;
/*  822 */     double max = Double.MIN_VALUE; int i;
/*  823 */     for (i = 0; i < data.length; i++) {
/*  824 */       if (data[i] != Double.POSITIVE_INFINITY && data[i] != Double.NEGATIVE_INFINITY) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  829 */         if (data[i] < min) min = data[i]; 
/*  830 */         if (data[i] > max) max = data[i];
/*      */       
/*      */       } 
/*      */     } 
/*  834 */     for (i = 0; i < data.length; i++) {
/*  835 */       if (data[i] == Double.POSITIVE_INFINITY) { data[i] = max; }
/*  836 */       else if (data[i] == Double.NEGATIVE_INFINITY) { data[i] = min; }
/*      */     
/*      */     } 
/*      */     
/*  840 */     double range = max - min;
/*  841 */     for (int j = 0; j < rtn.length; j++) {
/*  842 */       rtn[j] = (data[j] - min) / range;
/*      */     }
/*  844 */     return rtn;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] allocate(int... sizes) throws IllegalArgumentException {
/*  860 */     if (sizes == null) return null; 
/*  861 */     if (sizes.length == 0) return new byte[0]; 
/*  862 */     int total = safeMultiply32(sizes);
/*  863 */     return new byte[total];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int safeMultiply32(int... sizes) throws IllegalArgumentException {
/*  879 */     if (sizes.length == 0) return 0; 
/*  880 */     long total = 1L;
/*  881 */     for (int size : sizes) {
/*  882 */       if (size < 1) {
/*  883 */         throw new IllegalArgumentException("Invalid array size: " + sizeAsProduct(sizes));
/*      */       }
/*      */       
/*  886 */       total *= size;
/*  887 */       if (total > 2147483647L) {
/*  888 */         throw new IllegalArgumentException("Array size too large: " + sizeAsProduct(sizes));
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  893 */     return (int)total;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long safeMultiply64(long... sizes) throws IllegalArgumentException {
/*  909 */     if (sizes.length == 0) return 0L; 
/*  910 */     long total = 1L;
/*  911 */     for (long size : sizes) {
/*  912 */       if (size < 1L) {
/*  913 */         throw new IllegalArgumentException("Invalid array size: " + sizeAsProduct(sizes));
/*      */       }
/*      */       
/*  916 */       if (willOverflow(total, size)) {
/*  917 */         throw new IllegalArgumentException("Array size too large: " + sizeAsProduct(sizes));
/*      */       }
/*      */       
/*  920 */       total *= size;
/*      */     } 
/*  922 */     return total;
/*      */   }
/*      */ 
/*      */   
/*      */   public static boolean containsValue(int[] array, int value) {
/*  927 */     return (indexOf(array, value) != -1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOf(int[] array, int value) {
/*  935 */     for (int i = 0; i < array.length; i++) {
/*  936 */       if (array[i] == value) return i; 
/*      */     } 
/*  938 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOf(Object[] array, Object value) {
/*  946 */     for (int i = 0; i < array.length; i++) {
/*  947 */       if (value == null)
/*  948 */       { if (array[i] == null) return i;
/*      */          }
/*  950 */       else if (value.equals(array[i])) { return i; }
/*      */     
/*  952 */     }  return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] makeSigned(byte[] b) {
/*  958 */     for (int i = 0; i < b.length; i++) {
/*  959 */       b[i] = (byte)(b[i] + 128);
/*      */     }
/*  961 */     return b;
/*      */   }
/*      */   
/*      */   public static short[] makeSigned(short[] s) {
/*  965 */     for (int i = 0; i < s.length; i++) {
/*  966 */       s[i] = (short)(s[i] + 32768);
/*      */     }
/*  968 */     return s;
/*      */   }
/*      */   
/*      */   public static int[] makeSigned(int[] i) {
/*  972 */     for (int j = 0; j < i.length; j++) {
/*  973 */       i[j] = (int)(i[j] + 2147483648L);
/*      */     }
/*  975 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static String sizeAsProduct(int... sizes) {
/*  981 */     StringBuilder sb = new StringBuilder();
/*  982 */     boolean first = true;
/*  983 */     for (int size : sizes) {
/*  984 */       if (first) { first = false; }
/*  985 */       else { sb.append(" x "); }
/*  986 */        sb.append(size);
/*      */     } 
/*  988 */     return sb.toString();
/*      */   }
/*      */   
/*      */   private static String sizeAsProduct(long... sizes) {
/*  992 */     StringBuilder sb = new StringBuilder();
/*  993 */     boolean first = true;
/*  994 */     for (long size : sizes) {
/*  995 */       if (first) { first = false; }
/*  996 */       else { sb.append(" x "); }
/*  997 */        sb.append(size);
/*      */     } 
/*  999 */     return sb.toString();
/*      */   }
/*      */   
/*      */   private static boolean willOverflow(long v1, long v2) {
/* 1003 */     return (Long.MAX_VALUE / v1 < v2);
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/common/DataTools.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */