/*     */ package loci.common;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.zip.ZipEntry;
/*     */ import java.util.zip.ZipInputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ZipHandle
/*     */   extends StreamHandle
/*     */ {
/*     */   private RandomAccessInputStream in;
/*     */   private ZipInputStream zip;
/*     */   private String entryName;
/*     */   private int entryCount;
/*     */   
/*     */   public ZipHandle(String file) throws IOException {
/*  71 */     this.file = file;
/*     */     
/*  73 */     this.in = openStream(file);
/*  74 */     this.zip = new ZipInputStream(this.in);
/*  75 */     this.entryName = null;
/*  76 */     this.entryCount = 0;
/*     */ 
/*     */     
/*  79 */     String innerFile = file.substring(0, file.length() - 4);
/*  80 */     int slash = innerFile.lastIndexOf(File.separator);
/*  81 */     if (slash < 0) slash = innerFile.lastIndexOf("/"); 
/*  82 */     if (slash >= 0) innerFile = innerFile.substring(slash + 1);
/*     */ 
/*     */     
/*  85 */     boolean matchFound = false;
/*     */     while (true) {
/*  87 */       ZipEntry ze = this.zip.getNextEntry();
/*  88 */       if (ze == null)
/*  89 */         break;  if (this.entryName == null) this.entryName = ze.getName(); 
/*  90 */       if (!matchFound && ze.getName().startsWith(innerFile)) {
/*     */         
/*  92 */         this.entryName = ze.getName();
/*  93 */         matchFound = true;
/*     */       } 
/*  95 */       this.entryCount++;
/*     */     } 
/*  97 */     resetStream();
/*     */     
/*  99 */     populateLength();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ZipHandle(String file, ZipEntry entry) throws IOException {
/* 110 */     this.file = file;
/*     */     
/* 112 */     this.in = openStream(file);
/* 113 */     this.zip = new ZipInputStream(this.in);
/* 114 */     this.entryName = entry.getName();
/* 115 */     this.entryCount = 1;
/*     */     
/* 117 */     seekToEntry();
/* 118 */     resetStream();
/* 119 */     populateLength();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isZipFile(String file) throws IOException {
/* 126 */     if (!file.toLowerCase().endsWith(".zip")) return false;
/*     */     
/* 128 */     IRandomAccess handle = getHandle(file);
/* 129 */     byte[] b = new byte[2];
/* 130 */     if (handle.length() >= 2L) {
/* 131 */       handle.read(b);
/*     */     }
/* 133 */     handle.close();
/* 134 */     return (new String(b, "UTF-8")).equals("PK");
/*     */   }
/*     */ 
/*     */   
/*     */   public String getEntryName() {
/* 139 */     return this.entryName;
/*     */   }
/*     */ 
/*     */   
/*     */   public DataInputStream getInputStream() {
/* 144 */     return this.stream;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getEntryCount() {
/* 149 */     return this.entryCount;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 156 */     if (!Location.getIdMap().containsValue(this)) {
/* 157 */       super.close();
/* 158 */       this.zip = null;
/* 159 */       this.entryName = null;
/* 160 */       if (this.in != null) this.in.close(); 
/* 161 */       this.in = null;
/* 162 */       this.entryCount = 0;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void resetStream() throws IOException {
/* 170 */     if (this.stream != null) this.stream.close(); 
/* 171 */     if (this.in != null) {
/* 172 */       this.in.close();
/* 173 */       this.in = openStream(this.file);
/*     */     } 
/* 175 */     if (this.zip != null) this.zip.close(); 
/* 176 */     this.zip = new ZipInputStream(this.in);
/* 177 */     if (this.entryName != null) seekToEntry(); 
/* 178 */     this.stream = new DataInputStream(new BufferedInputStream(this.zip, 1048576));
/*     */     
/* 180 */     this.stream.mark(1048576);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void seekToEntry() throws IOException {
/* 186 */     while (!this.entryName.equals(this.zip.getNextEntry().getName()));
/*     */   }
/*     */   
/*     */   private void populateLength() throws IOException {
/* 190 */     this.length = -1L;
/* 191 */     while (this.stream.available() > 0) {
/* 192 */       this.stream.skip(1L);
/* 193 */       this.length++;
/*     */     } 
/* 195 */     resetStream();
/*     */   }
/*     */   
/*     */   private static IRandomAccess getHandle(String file) throws IOException {
/* 199 */     return Location.getHandle(file, false, false);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static RandomAccessInputStream openStream(String file) throws IOException {
/* 205 */     return new RandomAccessInputStream(getHandle(file), file);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/common/ZipHandle.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */