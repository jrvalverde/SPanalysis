/*     */ package loci.common;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StatusEvent
/*     */ {
/*     */   protected int progress;
/*     */   protected int maximum;
/*     */   protected String status;
/*     */   protected boolean warning;
/*     */   
/*     */   public StatusEvent(String message) {
/*  66 */     this(-1, -1, message);
/*     */   }
/*     */ 
/*     */   
/*     */   public StatusEvent(String message, boolean warn) {
/*  71 */     this(-1, -1, message, warn);
/*     */   }
/*     */ 
/*     */   
/*     */   public StatusEvent(int progress, int maximum, String message) {
/*  76 */     this(progress, maximum, message, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public StatusEvent(int progress, int maximum, String message, boolean warn) {
/*  81 */     this.progress = progress;
/*  82 */     this.maximum = maximum;
/*  83 */     this.status = message;
/*  84 */     this.warning = warn;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getProgressValue() {
/*  90 */     return this.progress;
/*     */   }
/*     */   public int getProgressMaximum() {
/*  93 */     return this.maximum;
/*     */   }
/*     */   public String getStatusMessage() {
/*  96 */     return this.status;
/*     */   }
/*     */   public boolean isWarning() {
/*  99 */     return this.warning;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 105 */     StringBuilder sb = new StringBuilder();
/* 106 */     sb.append("Status");
/* 107 */     sb.append(": progress=" + this.progress);
/* 108 */     sb.append(", maximum=" + this.maximum);
/* 109 */     sb.append(", warning=" + this.warning);
/* 110 */     sb.append(", status='" + this.status + "'");
/* 111 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/common/StatusEvent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */