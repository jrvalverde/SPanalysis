/*     */ package loci.common;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.IOException;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class URLHandle
/*     */   extends StreamHandle
/*     */ {
/*     */   private String url;
/*     */   private URLConnection conn;
/*     */   
/*     */   public URLHandle(String url) throws IOException {
/*  75 */     if (!url.startsWith("http") && !url.startsWith("file:")) {
/*  76 */       url = "http://" + url;
/*     */     }
/*  78 */     this.url = url;
/*  79 */     resetStream();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void seek(long pos) throws IOException {
/*  86 */     if (pos < this.fp && pos >= this.mark) {
/*  87 */       this.stream.reset();
/*  88 */       this.fp = this.mark;
/*  89 */       skip(pos - this.fp);
/*     */     } else {
/*  91 */       super.seek(pos);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void resetStream() throws IOException {
/*  98 */     this.conn = (new URL(this.url)).openConnection();
/*  99 */     this.stream = new DataInputStream(new BufferedInputStream(this.conn.getInputStream(), 1048576));
/*     */     
/* 101 */     this.fp = 0L;
/* 102 */     this.mark = 0L;
/* 103 */     this.length = this.conn.getContentLength();
/* 104 */     if (this.stream != null) this.stream.mark(1048576);
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void skip(long bytes) throws IOException {
/* 111 */     while (bytes >= 2147483647L) {
/* 112 */       bytes -= skipBytes(2147483647);
/*     */     }
/* 114 */     int skipped = skipBytes((int)bytes);
/* 115 */     while (skipped < bytes) {
/* 116 */       int n = skipBytes((int)(bytes - skipped));
/* 117 */       if (n == 0)
/* 118 */         break;  skipped += n;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/common/URLHandle.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */