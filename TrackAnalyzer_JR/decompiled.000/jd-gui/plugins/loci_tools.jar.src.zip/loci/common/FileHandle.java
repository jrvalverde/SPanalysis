/*     */ package loci.common;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.RandomAccessFile;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.ByteOrder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FileHandle
/*     */   implements IRandomAccess
/*     */ {
/*     */   protected RandomAccessFile raf;
/*     */   
/*     */   public FileHandle(File file, String mode) throws FileNotFoundException {
/*  72 */     this.raf = new RandomAccessFile(file, mode);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FileHandle(String name, String mode) throws FileNotFoundException {
/*  80 */     this.raf = new RandomAccessFile(name, mode);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public RandomAccessFile getRandomAccessFile() {
/*  86 */     return this.raf;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/*  92 */     this.raf.close();
/*     */   }
/*     */ 
/*     */   
/*     */   public long getFilePointer() throws IOException {
/*  97 */     return this.raf.getFilePointer();
/*     */   }
/*     */ 
/*     */   
/*     */   public long length() throws IOException {
/* 102 */     return this.raf.length();
/*     */   }
/*     */ 
/*     */   
/*     */   public int read(byte[] b) throws IOException {
/* 107 */     return this.raf.read(b);
/*     */   }
/*     */ 
/*     */   
/*     */   public int read(byte[] b, int off, int len) throws IOException {
/* 112 */     return this.raf.read(b, off, len);
/*     */   }
/*     */ 
/*     */   
/*     */   public int read(ByteBuffer buffer) throws IOException {
/* 117 */     return read(buffer, 0, buffer.capacity());
/*     */   }
/*     */ 
/*     */   
/*     */   public int read(ByteBuffer buffer, int off, int len) throws IOException {
/* 122 */     byte[] b = new byte[len];
/* 123 */     int n = read(b);
/* 124 */     buffer.put(b, off, len);
/* 125 */     return n;
/*     */   }
/*     */ 
/*     */   
/*     */   public void seek(long pos) throws IOException {
/* 130 */     this.raf.seek(pos);
/*     */   }
/*     */ 
/*     */   
/*     */   public void write(ByteBuffer buf) throws IOException {
/* 135 */     write(buf, 0, buf.capacity());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(ByteBuffer buf, int off, int len) throws IOException {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean readBoolean() throws IOException {
/* 147 */     return this.raf.readBoolean();
/*     */   }
/*     */ 
/*     */   
/*     */   public byte readByte() throws IOException {
/* 152 */     return this.raf.readByte();
/*     */   }
/*     */ 
/*     */   
/*     */   public char readChar() throws IOException {
/* 157 */     return this.raf.readChar();
/*     */   }
/*     */ 
/*     */   
/*     */   public double readDouble() throws IOException {
/* 162 */     return this.raf.readDouble();
/*     */   }
/*     */ 
/*     */   
/*     */   public float readFloat() throws IOException {
/* 167 */     return this.raf.readFloat();
/*     */   }
/*     */ 
/*     */   
/*     */   public void readFully(byte[] b) throws IOException {
/* 172 */     this.raf.readFully(b);
/*     */   }
/*     */ 
/*     */   
/*     */   public void readFully(byte[] b, int off, int len) throws IOException {
/* 177 */     this.raf.readFully(b, off, len);
/*     */   }
/*     */ 
/*     */   
/*     */   public int readInt() throws IOException {
/* 182 */     return this.raf.readInt();
/*     */   }
/*     */ 
/*     */   
/*     */   public String readLine() throws IOException {
/* 187 */     return this.raf.readLine();
/*     */   }
/*     */ 
/*     */   
/*     */   public long readLong() throws IOException {
/* 192 */     return this.raf.readLong();
/*     */   }
/*     */ 
/*     */   
/*     */   public short readShort() throws IOException {
/* 197 */     return this.raf.readShort();
/*     */   }
/*     */ 
/*     */   
/*     */   public int readUnsignedByte() throws IOException {
/* 202 */     return this.raf.readUnsignedByte();
/*     */   }
/*     */ 
/*     */   
/*     */   public int readUnsignedShort() throws IOException {
/* 207 */     return this.raf.readUnsignedShort();
/*     */   }
/*     */ 
/*     */   
/*     */   public String readUTF() throws IOException {
/* 212 */     return this.raf.readUTF();
/*     */   }
/*     */ 
/*     */   
/*     */   public int skipBytes(int n) throws IOException {
/* 217 */     return this.raf.skipBytes(n);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(byte[] b) throws IOException {
/* 224 */     this.raf.write(b);
/*     */   }
/*     */ 
/*     */   
/*     */   public void write(byte[] b, int off, int len) throws IOException {
/* 229 */     this.raf.write(b, off, len);
/*     */   }
/*     */ 
/*     */   
/*     */   public void write(int b) throws IOException {
/* 234 */     this.raf.write(b);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeBoolean(boolean v) throws IOException {
/* 239 */     this.raf.writeBoolean(v);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeByte(int v) throws IOException {
/* 244 */     this.raf.writeByte(v);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeBytes(String s) throws IOException {
/* 249 */     this.raf.writeBytes(s);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeChar(int v) throws IOException {
/* 254 */     this.raf.writeChar(v);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeChars(String s) throws IOException {
/* 259 */     this.raf.writeChars(s);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeDouble(double v) throws IOException {
/* 264 */     this.raf.writeDouble(v);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeFloat(float v) throws IOException {
/* 269 */     this.raf.writeFloat(v);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeInt(int v) throws IOException {
/* 274 */     this.raf.writeInt(v);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeLong(long v) throws IOException {
/* 279 */     this.raf.writeLong(v);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeShort(int v) throws IOException {
/* 284 */     this.raf.writeShort(v);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeUTF(String str) throws IOException {
/* 289 */     this.raf.writeUTF(str);
/*     */   }
/*     */ 
/*     */   
/*     */   public ByteOrder getOrder() {
/* 294 */     return null;
/*     */   }
/*     */   
/*     */   public void setOrder(ByteOrder order) {}
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/common/FileHandle.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */