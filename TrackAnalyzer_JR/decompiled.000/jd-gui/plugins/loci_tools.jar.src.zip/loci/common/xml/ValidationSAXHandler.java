/*    */ package loci.common.xml;
/*    */ 
/*    */ import java.util.StringTokenizer;
/*    */ import org.xml.sax.Attributes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ValidationSAXHandler
/*    */   extends BaseHandler
/*    */ {
/*    */   private String schemaPath;
/*    */   private boolean first;
/*    */   
/*    */   public String getSchemaPath() {
/* 59 */     return this.schemaPath;
/*    */   } public void startDocument() {
/* 61 */     this.schemaPath = null;
/* 62 */     this.first = true;
/*    */   }
/*    */ 
/*    */   
/*    */   public void startElement(String uri, String localName, String qName, Attributes attributes) {
/* 67 */     if (!this.first)
/* 68 */       return;  this.first = false;
/*    */     
/* 70 */     int len = attributes.getLength();
/* 71 */     String xmlns = null, xsiSchemaLocation = null;
/* 72 */     for (int i = 0; i < len; i++) {
/* 73 */       String name = attributes.getQName(i);
/* 74 */       if (name.equals("xmlns")) { xmlns = attributes.getValue(i); }
/* 75 */       else if (name.equals("schemaLocation") || name.endsWith(":schemaLocation"))
/*    */       
/*    */       { 
/* 78 */         xsiSchemaLocation = attributes.getValue(i); }
/*    */     
/*    */     } 
/* 81 */     if (xmlns == null || xsiSchemaLocation == null)
/*    */       return; 
/* 83 */     StringTokenizer st = new StringTokenizer(xsiSchemaLocation);
/* 84 */     while (st.hasMoreTokens()) {
/* 85 */       String token = st.nextToken();
/* 86 */       if (xmlns.equals(token)) {
/*    */         
/* 88 */         if (st.hasMoreTokens()) this.schemaPath = st.nextToken(); 
/*    */         break;
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/common/xml/ValidationSAXHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */