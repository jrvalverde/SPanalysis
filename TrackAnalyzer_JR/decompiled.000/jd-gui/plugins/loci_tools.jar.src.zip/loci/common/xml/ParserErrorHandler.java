/*    */ package loci.common.xml;
/*    */ 
/*    */ import org.xml.sax.ErrorHandler;
/*    */ import org.xml.sax.SAXParseException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ParserErrorHandler
/*    */   implements ErrorHandler
/*    */ {
/*    */   public void error(SAXParseException e) {
/* 54 */     XMLTools.LOGGER.debug(e.getMessage());
/*    */   }
/*    */   
/*    */   public void fatalError(SAXParseException e) {
/* 58 */     XMLTools.LOGGER.debug(e.getMessage());
/*    */   }
/*    */   
/*    */   public void warning(SAXParseException e) {
/* 62 */     XMLTools.LOGGER.debug(e.getMessage());
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/common/xml/ParserErrorHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */