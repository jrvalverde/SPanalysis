/*    */ package loci.common.xml;
/*    */ 
/*    */ import org.xml.sax.ErrorHandler;
/*    */ import org.xml.sax.SAXParseException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ValidationErrorHandler
/*    */   implements ErrorHandler
/*    */ {
/* 55 */   private int errors = 0;
/*    */   public boolean ok() {
/* 57 */     return (this.errors == 0);
/*    */   } public int getErrorCount() {
/* 59 */     return this.errors;
/*    */   }
/*    */   public void error(SAXParseException e) {
/* 62 */     XMLTools.LOGGER.error(e.getMessage());
/* 63 */     this.errors++;
/*    */   }
/*    */   
/*    */   public void fatalError(SAXParseException e) {
/* 67 */     XMLTools.LOGGER.error(e.getMessage());
/* 68 */     this.errors++;
/*    */   }
/*    */   
/*    */   public void warning(SAXParseException e) {
/* 72 */     XMLTools.LOGGER.warn(e.getMessage());
/* 73 */     this.errors++;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/common/xml/ValidationErrorHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */