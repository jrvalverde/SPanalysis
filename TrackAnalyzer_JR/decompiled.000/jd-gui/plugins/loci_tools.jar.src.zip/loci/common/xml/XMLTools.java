/*     */ package loci.common.xml;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.StringReader;
/*     */ import java.io.StringWriter;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Set;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import javax.xml.parsers.SAXParser;
/*     */ import javax.xml.parsers.SAXParserFactory;
/*     */ import javax.xml.transform.ErrorListener;
/*     */ import javax.xml.transform.Result;
/*     */ import javax.xml.transform.Source;
/*     */ import javax.xml.transform.Templates;
/*     */ import javax.xml.transform.Transformer;
/*     */ import javax.xml.transform.TransformerConfigurationException;
/*     */ import javax.xml.transform.TransformerException;
/*     */ import javax.xml.transform.TransformerFactory;
/*     */ import javax.xml.transform.dom.DOMSource;
/*     */ import javax.xml.transform.sax.SAXSource;
/*     */ import javax.xml.transform.stream.StreamResult;
/*     */ import javax.xml.transform.stream.StreamSource;
/*     */ import javax.xml.validation.Schema;
/*     */ import javax.xml.validation.SchemaFactory;
/*     */ import javax.xml.validation.Validator;
/*     */ import loci.common.RandomAccessInputStream;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.w3c.dom.Document;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.helpers.DefaultHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class XMLTools
/*     */ {
/* 104 */   static final Logger LOGGER = LoggerFactory.getLogger(XMLTools.class);
/*     */ 
/*     */   
/*     */   private static final String XML_SCHEMA_PATH = "http://www.w3.org/2001/XMLSchema";
/*     */   
/* 109 */   private static final SchemaFactory FACTORY = SchemaFactory.newInstance("http://www.w3.org/2001/XMLSchema");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 114 */   private static ThreadLocal<HashMap<URI, Schema>> schemas = new ThreadLocal<HashMap<URI, Schema>>()
/*     */     {
/*     */       protected HashMap<URI, Schema> initialValue()
/*     */       {
/* 118 */         return new HashMap<URI, Schema>();
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Document parseDOM(File file) throws ParserConfigurationException, SAXException, IOException {
/* 132 */     InputStream is = new FileInputStream(file);
/*     */     try {
/* 134 */       Document doc = parseDOM(is);
/* 135 */       return doc;
/*     */     } finally {
/* 137 */       is.close();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Document parseDOM(String xml) throws ParserConfigurationException, SAXException, IOException {
/* 145 */     byte[] bytes = xml.getBytes("UTF-8");
/* 146 */     InputStream is = new ByteArrayInputStream(bytes);
/*     */     try {
/* 148 */       Document doc = parseDOM(is);
/* 149 */       return doc;
/*     */     } finally {
/* 151 */       is.close();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Document parseDOM(InputStream is) throws ParserConfigurationException, SAXException, IOException {
/* 159 */     InputStream in = is.markSupported() ? is : new BufferedInputStream(is);
/*     */     
/* 161 */     checkUTF8(in);
/*     */ 
/*     */     
/* 164 */     DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
/* 165 */     DocumentBuilder db = factory.newDocumentBuilder();
/* 166 */     db.setErrorHandler(new ParserErrorHandler());
/* 167 */     return db.parse(in);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getXML(Document doc) throws TransformerConfigurationException, TransformerException {
/* 174 */     Source source = new DOMSource(doc);
/* 175 */     StringWriter stringWriter = new StringWriter();
/* 176 */     Result result = new StreamResult(stringWriter);
/*     */     
/* 178 */     TransformerFactory factory = TransformerFactory.newInstance();
/* 179 */     factory.setErrorListener(new XMLListener());
/* 180 */     Transformer transformer = factory.newTransformer();
/* 181 */     transformer.transform(source, result);
/* 182 */     return stringWriter.getBuffer().toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String sanitizeXML(String s) {
/* 189 */     char[] c = s.toCharArray();
/* 190 */     for (int i = 0; i < s.length(); i++) {
/* 191 */       if ((Character.isISOControl(c[i]) && c[i] != '\n') || !Character.isDefined(c[i]))
/*     */       {
/*     */         
/* 194 */         c[i] = ' ';
/*     */       }
/*     */       
/* 197 */       if (i > 0 && c[i - 1] == '&' && c[i] == '#') c[i - 1] = ' '; 
/*     */     } 
/* 199 */     return new String(c);
/*     */   }
/*     */ 
/*     */   
/*     */   public static String escapeXML(String s) {
/* 204 */     StringBuffer sb = new StringBuffer();
/*     */     
/* 206 */     for (int i = 0; i < s.length(); i++) {
/* 207 */       char c = s.charAt(i);
/*     */       
/* 209 */       if (c == '<') {
/* 210 */         sb.append("&lt;");
/*     */       }
/* 212 */       else if (c == '>') {
/* 213 */         sb.append("&gt;");
/*     */       }
/* 215 */       else if (c == '&') {
/* 216 */         sb.append("&amp;");
/*     */       }
/* 218 */       else if (c == '"') {
/* 219 */         sb.append("&quot;");
/*     */       }
/* 221 */       else if (c == '\'') {
/* 222 */         sb.append("&apos;");
/*     */       } else {
/*     */         
/* 225 */         sb.append(c);
/*     */       } 
/*     */     } 
/*     */     
/* 229 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public static String indentXML(String xml) {
/* 234 */     return indentXML(xml, 3, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public static String indentXML(String xml, int spacing) {
/* 239 */     return indentXML(xml, spacing, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String indentXML(String xml, boolean preserveCData) {
/* 247 */     return indentXML(xml, 3, preserveCData);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String indentXML(String xml, int spacing, boolean preserveCData) {
/* 257 */     if (xml == null) return null; 
/* 258 */     StringBuffer sb = new StringBuffer();
/* 259 */     StringTokenizer st = new StringTokenizer(xml, "<>", true);
/* 260 */     int indent = 0, noSpace = 0;
/* 261 */     boolean first = true, element = false;
/* 262 */     while (st.hasMoreTokens()) {
/* 263 */       String token = st.nextToken().trim();
/* 264 */       if (token.equals(""))
/* 265 */         continue;  if (token.equals("<")) {
/* 266 */         element = true;
/*     */         continue;
/*     */       } 
/* 269 */       if (element && token.equals(">")) {
/* 270 */         element = false;
/*     */         
/*     */         continue;
/*     */       } 
/* 274 */       if (!element && preserveCData) noSpace = 2;
/*     */       
/* 276 */       if (noSpace == 0)
/*     */       {
/* 278 */         if (first) { first = false; }
/* 279 */         else { sb.append("\n"); }
/*     */       
/*     */       }
/*     */       
/* 283 */       if (element && token.startsWith("/")) indent -= spacing;
/*     */       
/* 285 */       if (noSpace == 0)
/*     */       {
/* 287 */         for (int j = 0; j < indent; ) { sb.append(" "); j++; }
/*     */       
/*     */       }
/*     */       
/* 291 */       if (element) sb.append("<"); 
/* 292 */       sb.append(token);
/* 293 */       if (element) sb.append(">");
/*     */       
/* 295 */       if (noSpace == 0)
/*     */       {
/* 297 */         if (element && !token.startsWith("?") && !token.startsWith("/") && !token.endsWith("/") && !token.startsWith("!"))
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 303 */           indent += spacing;
/*     */         }
/*     */       }
/*     */       
/* 307 */       if (noSpace > 0) noSpace--; 
/*     */     } 
/* 309 */     sb.append("\n");
/* 310 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Hashtable<String, String> parseXML(String xml) throws IOException {
/* 319 */     MetadataHandler handler = new MetadataHandler();
/* 320 */     parseXML(xml, handler);
/* 321 */     return handler.getMetadata();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void parseXML(String xml, DefaultHandler handler) throws IOException {
/* 330 */     parseXML(xml.getBytes("UTF-8"), handler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void parseXML(RandomAccessInputStream stream, DefaultHandler handler) throws IOException {
/* 341 */     parseXML((InputStream)stream, handler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void parseXML(byte[] xml, DefaultHandler handler) throws IOException {
/* 351 */     parseXML(new ByteArrayInputStream(xml), handler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void parseXML(InputStream xml, DefaultHandler handler) throws IOException {
/*     */     try {
/* 363 */       SAXParserFactory factory = SAXParserFactory.newInstance();
/* 364 */       SAXParser parser = factory.newSAXParser();
/* 365 */       parser.parse(xml, handler);
/*     */     }
/* 367 */     catch (ParserConfigurationException exc) {
/* 368 */       IOException e = new IOException();
/* 369 */       e.initCause(exc);
/* 370 */       throw e;
/*     */     }
/* 372 */     catch (SAXException exc) {
/* 373 */       IOException e = new IOException();
/* 374 */       e.initCause(exc);
/* 375 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Templates getStylesheet(String resourcePath, Class<?> sourceClass) {
/*     */     InputStream inputStream;
/* 386 */     if (sourceClass == null) {
/*     */       try {
/* 388 */         inputStream = new FileInputStream(resourcePath);
/*     */       }
/* 390 */       catch (IOException exc) {
/* 391 */         LOGGER.debug("Could not open file", exc);
/* 392 */         return null;
/*     */       } 
/*     */     } else {
/*     */       
/* 396 */       inputStream = sourceClass.getResourceAsStream(resourcePath);
/*     */     } 
/*     */     
/*     */     try {
/* 400 */       StreamSource xsltSource = new StreamSource(inputStream);
/*     */       
/* 402 */       TransformerFactory transformerFactory = TransformerFactory.newInstance();
/* 403 */       transformerFactory.setErrorListener(new XMLListener());
/* 404 */       return transformerFactory.newTemplates(xsltSource);
/*     */     }
/* 406 */     catch (TransformerConfigurationException exc) {
/* 407 */       LOGGER.debug("Could not construct template", exc);
/*     */     } finally {
/*     */       
/*     */       try {
/* 411 */         if (inputStream != null) inputStream.close();
/*     */       
/* 413 */       } catch (IOException e) {
/* 414 */         LOGGER.debug("Could not close file", e);
/*     */       } 
/*     */     } 
/* 417 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public static String avoidUndeclaredNamespaces(String xml) {
/* 422 */     int gt = xml.indexOf('>');
/* 423 */     if (gt > 0 && xml.startsWith("<?xml "))
/* 424 */       gt = xml.indexOf('>', gt + 1); 
/* 425 */     if (gt > 0) {
/* 426 */       String firstTag = xml.substring(0, gt + 1).toLowerCase();
/*     */ 
/*     */       
/* 429 */       while (firstTag.endsWith("-->")) {
/* 430 */         gt = xml.indexOf('>', gt + 1);
/* 431 */         firstTag = xml.substring(0, gt + 1).toLowerCase();
/*     */       } 
/*     */       
/* 434 */       Set<String> namespaces = new HashSet();
/* 435 */       Pattern pattern = Pattern.compile(" xmlns:(\\w+)");
/* 436 */       Matcher matcher = pattern.matcher(firstTag);
/* 437 */       while (matcher.find()) {
/* 438 */         namespaces.add(matcher.group(1));
/*     */       }
/*     */       
/* 441 */       pattern = Pattern.compile("</?(\\w+):");
/* 442 */       matcher = pattern.matcher(xml);
/* 443 */       while (matcher.find()) {
/* 444 */         String namespace = matcher.group(1);
/* 445 */         if (!namespace.equalsIgnoreCase("OME") && !namespace.startsWith("ns") && !namespaces.contains(namespace.toLowerCase())) {
/*     */ 
/*     */           
/* 448 */           int end = matcher.end();
/* 449 */           xml = xml.substring(0, end - 1) + "_" + xml.substring(end);
/*     */         } 
/*     */       } 
/*     */       
/* 453 */       Pattern emptyNamespaces = Pattern.compile(" xmlns:(\\w+)=\"\"");
/* 454 */       matcher = emptyNamespaces.matcher(firstTag);
/* 455 */       while (matcher.find()) {
/* 456 */         int start = matcher.start();
/* 457 */         int end = matcher.end();
/* 458 */         xml = xml.substring(0, start + 1) + xml.substring(end);
/*     */       } 
/*     */     } 
/* 461 */     return xml;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String transformXML(String xml, Templates xslt) throws IOException {
/* 468 */     xml = avoidUndeclaredNamespaces(xml);
/* 469 */     return transformXML(new StreamSource(new StringReader(xml)), xslt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String transformXML(Source xmlSource, Templates xslt) throws IOException {
/*     */     Transformer trans;
/*     */     try {
/* 478 */       trans = xslt.newTransformer();
/* 479 */       trans.setErrorListener(new XMLListener());
/*     */     }
/* 481 */     catch (TransformerConfigurationException exc) {
/* 482 */       IOException e = new IOException();
/* 483 */       e.initCause(exc);
/* 484 */       throw e;
/*     */     } 
/* 486 */     StringWriter xmlWriter = new StringWriter();
/* 487 */     StreamResult xmlResult = new StreamResult(xmlWriter);
/*     */     try {
/* 489 */       trans.transform(xmlSource, xmlResult);
/*     */     }
/* 491 */     catch (TransformerException exc) {
/* 492 */       IOException e = new IOException();
/* 493 */       e.initCause(exc);
/* 494 */       throw e;
/*     */     } 
/* 496 */     return xmlWriter.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean validateXML(String xml) {
/* 508 */     return validateXML(xml, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean validateXML(String xml, String label) {
/* 519 */     if (label == null) label = "XML"; 
/* 520 */     Exception exception = null;
/*     */ 
/*     */     
/* 523 */     LOGGER.info("Parsing schema path");
/* 524 */     ValidationSAXHandler saxHandler = new ValidationSAXHandler();
/*     */ 
/*     */     
/* 527 */     try { SAXParserFactory factory = SAXParserFactory.newInstance();
/* 528 */       SAXParser saxParser = factory.newSAXParser();
/* 529 */       InputStream inputStream = new ByteArrayInputStream(xml.getBytes("UTF-8"));
/*     */       
/* 531 */       saxParser.parse(inputStream, saxHandler); }
/*     */     catch (ParserConfigurationException exc)
/* 533 */     { exception = exc = null; }
/* 534 */     catch (SAXException exc) { exception = exc = null; }
/* 535 */     catch (IOException exc) { exception = exc = null; }
/* 536 */      if (exception != null) {
/* 537 */       LOGGER.warn("Error parsing schema path from {}", label, exception);
/* 538 */       return false;
/*     */     } 
/* 540 */     String schemaPath = saxHandler.getSchemaPath();
/* 541 */     if (schemaPath == null) {
/* 542 */       LOGGER.error("No schema path found. Validation cannot continue.");
/* 543 */       return false;
/*     */     } 
/* 545 */     LOGGER.info(schemaPath);
/*     */     
/* 547 */     LOGGER.info("Validating {}", label);
/*     */ 
/*     */     
/* 550 */     URI schemaLocation = null;
/*     */     try {
/* 552 */       schemaLocation = new URI(schemaPath);
/*     */     }
/* 554 */     catch (URISyntaxException exc) {
/* 555 */       LOGGER.info("Error accessing schema at {}", schemaPath, exc);
/* 556 */       return false;
/*     */     } 
/* 558 */     Schema schema = (Schema)((HashMap)schemas.get()).get(schemaLocation);
/* 559 */     if (schema == null) {
/*     */       try {
/* 561 */         schema = FACTORY.newSchema(schemaLocation.toURL());
/* 562 */         ((HashMap<URI, Schema>)schemas.get()).put(schemaLocation, schema);
/*     */       }
/* 564 */       catch (MalformedURLException exc) {
/* 565 */         LOGGER.info("Error parsing schema at {}", schemaPath, exc);
/* 566 */         return false;
/*     */       }
/* 568 */       catch (SAXException exc) {
/* 569 */         LOGGER.info("Error parsing schema at {}", schemaPath, exc);
/* 570 */         return false;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 575 */     Validator validator = schema.newValidator();
/*     */ 
/*     */     
/* 578 */     StringReader reader = new StringReader(xml);
/* 579 */     InputSource is = new InputSource(reader);
/* 580 */     SAXSource source = new SAXSource(is);
/*     */ 
/*     */     
/* 583 */     ValidationErrorHandler errorHandler = new ValidationErrorHandler();
/* 584 */     validator.setErrorHandler(errorHandler);
/*     */     
/* 586 */     try { validator.validate(source); }
/*     */     catch (IOException exc)
/* 588 */     { exception = exc = null; }
/* 589 */     catch (SAXException exc) { exception = exc = null; }
/* 590 */      int errors = errorHandler.getErrorCount();
/* 591 */     if (errors > 0) {
/* 592 */       LOGGER.info("Error validating document: {} errors found", Integer.valueOf(errors));
/* 593 */       return false;
/*     */     } 
/* 595 */     LOGGER.info("No validation errors found.");
/* 596 */     return errorHandler.ok();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void checkUTF8(InputStream is) throws IOException {
/* 612 */     is.mark(3);
/* 613 */     if (is.read() != 239 || is.read() != 187 || is.read() != 191)
/*     */     {
/* 615 */       is.reset();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static class XMLListener
/*     */     implements ErrorListener
/*     */   {
/*     */     public void error(TransformerException e) {
/* 624 */       XMLTools.LOGGER.debug("", e);
/*     */     }
/*     */     
/*     */     public void fatalError(TransformerException e) {
/* 628 */       XMLTools.LOGGER.debug("", e);
/*     */     }
/*     */     
/*     */     public void warning(TransformerException e) {
/* 632 */       XMLTools.LOGGER.debug("", e);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/common/xml/XMLTools.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */