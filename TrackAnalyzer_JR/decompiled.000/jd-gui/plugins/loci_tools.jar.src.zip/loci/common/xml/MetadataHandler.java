/*    */ package loci.common.xml;
/*    */ 
/*    */ import java.util.Hashtable;
/*    */ import org.xml.sax.Attributes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class MetadataHandler
/*    */   extends BaseHandler
/*    */ {
/*    */   private String currentQName;
/* 56 */   private Hashtable<String, String> metadata = new Hashtable<String, String>();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Hashtable<String, String> getMetadata() {
/* 62 */     return this.metadata;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void characters(char[] data, int start, int len) {
/* 68 */     this.metadata.put(this.currentQName, new String(data, start, len));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void startElement(String uri, String localName, String qName, Attributes attributes) {
/* 74 */     if (attributes.getLength() == 0) { this.currentQName += " - " + qName; }
/* 75 */     else { this.currentQName = qName; }
/* 76 */      for (int i = 0; i < attributes.getLength(); i++)
/* 77 */       this.metadata.put(qName + " - " + attributes.getQName(i), attributes.getValue(i)); 
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/common/xml/MetadataHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */