/*     */ package loci.common;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.nio.channels.Channel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NIOInputStream
/*     */   extends InputStream
/*     */   implements DataInput
/*     */ {
/*     */   protected static final int DEFAULT_BLOCK_SIZE = 262144;
/*     */   protected static final int MAX_SEARCH_SIZE = 536870912;
/*     */   protected IRandomAccess raf;
/*     */   protected String filename;
/*     */   protected File file;
/*     */   protected Channel channel;
/*     */   protected boolean isLittleEndian;
/*     */   
/*     */   public NIOInputStream(String filename) throws IOException {
/*  89 */     this.filename = filename;
/*  90 */     this.file = new File(filename);
/*  91 */     this.raf = new FileHandle(this.file, "r");
/*     */   }
/*     */ 
/*     */   
/*     */   public NIOInputStream(IRandomAccess handle) {
/*  96 */     this.raf = handle;
/*     */   }
/*     */ 
/*     */   
/*     */   public NIOInputStream(byte[] array) {
/* 101 */     this(new ByteArrayHandle(array));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DataInputStream getInputStream() {
/* 109 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExtend(int extend) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void seek(long pos) throws IOException {
/* 122 */     this.raf.seek(pos);
/*     */   }
/*     */ 
/*     */   
/*     */   public int read() throws IOException {
/* 127 */     return this.raf.readUnsignedByte();
/*     */   }
/*     */ 
/*     */   
/*     */   public long length() throws IOException {
/* 132 */     return this.raf.length();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long getFilePointer() {
/*     */     try {
/* 139 */       return this.raf.getFilePointer();
/* 140 */     } catch (IOException e) {
/* 141 */       throw new RuntimeException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void order(boolean isLittleEndian) {
/* 152 */     this.isLittleEndian = isLittleEndian;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isLittleEndian() {
/* 157 */     return this.isLittleEndian;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String readString(String lastChars) throws IOException {
/* 166 */     if (lastChars.length() == 1) return findString(new String[] { lastChars });
/*     */     
/* 168 */     String[] terminators = new String[lastChars.length()];
/* 169 */     for (int i = 0; i < terminators.length; i++) {
/* 170 */       terminators[i] = lastChars.substring(i, i + 1);
/*     */     }
/* 172 */     return findString(terminators);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String findString(String... terminators) throws IOException {
/* 185 */     return findString(true, 262144, terminators);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String findString(boolean saveString, String... terminators) throws IOException {
/* 206 */     return findString(saveString, 262144, terminators);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String findString(int blockSize, String... terminators) throws IOException {
/* 223 */     return findString(true, blockSize, terminators);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String findString(boolean saveString, int blockSize, String... terminators) throws IOException {
/* 245 */     StringBuilder out = new StringBuilder();
/* 246 */     long startPos = getFilePointer();
/* 247 */     long bytesDropped = 0L;
/* 248 */     long inputLen = length();
/* 249 */     long maxLen = inputLen - startPos;
/* 250 */     boolean tooLong = (saveString && maxLen > 536870912L);
/* 251 */     if (tooLong) maxLen = 536870912L; 
/* 252 */     boolean match = false;
/* 253 */     int maxTermLen = 0;
/* 254 */     for (String term : terminators) {
/* 255 */       int len = term.length();
/* 256 */       if (len > maxTermLen) maxTermLen = len;
/*     */     
/*     */     } 
/* 259 */     InputStreamReader in = new InputStreamReader(this, "UTF-8");
/* 260 */     char[] buf = new char[blockSize];
/* 261 */     long loc = 0L;
/* 262 */     while (loc < maxLen) {
/* 263 */       long pos = startPos + loc;
/*     */ 
/*     */       
/* 266 */       if (!saveString) {
/* 267 */         int outLen = out.length();
/* 268 */         if (outLen >= maxTermLen) {
/* 269 */           int dropIndex = outLen - maxTermLen + 1;
/* 270 */           String last = out.substring(dropIndex, outLen);
/* 271 */           out.setLength(0);
/* 272 */           out.append(last);
/* 273 */           bytesDropped += dropIndex;
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 278 */       int num = blockSize;
/* 279 */       if (pos + blockSize > inputLen) num = (int)(inputLen - pos); 
/* 280 */       int r = in.read(buf, 0, num);
/* 281 */       if (r <= 0) throw new IOException("Cannot read from stream: " + r);
/*     */ 
/*     */       
/* 284 */       out.append(buf, 0, r);
/*     */ 
/*     */       
/* 287 */       int min = Integer.MAX_VALUE, tagLen = 0;
/* 288 */       for (int t = 0; t < terminators.length; t++) {
/* 289 */         int len = terminators[t].length();
/* 290 */         int start = (int)(loc - bytesDropped - len);
/* 291 */         int value = out.indexOf(terminators[t], (start < 0) ? 0 : start);
/* 292 */         if (value >= 0 && value < min) {
/* 293 */           match = true;
/* 294 */           min = value;
/* 295 */           tagLen = len;
/*     */         } 
/*     */       } 
/*     */       
/* 299 */       if (match) {
/*     */         
/* 301 */         seek(startPos + bytesDropped + min + tagLen);
/*     */ 
/*     */         
/* 304 */         if (saveString) {
/* 305 */           out.setLength(min + tagLen);
/* 306 */           return out.toString();
/*     */         } 
/* 308 */         return null;
/*     */       } 
/*     */       
/* 311 */       loc += r;
/*     */     } 
/*     */ 
/*     */     
/* 315 */     if (tooLong) throw new IOException("Maximum search length reached."); 
/* 316 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean readBoolean() throws IOException {
/* 323 */     return this.raf.readBoolean();
/*     */   }
/*     */ 
/*     */   
/*     */   public byte readByte() throws IOException {
/* 328 */     return this.raf.readByte();
/*     */   }
/*     */ 
/*     */   
/*     */   public char readChar() throws IOException {
/* 333 */     return this.raf.readChar();
/*     */   }
/*     */ 
/*     */   
/*     */   public double readDouble() throws IOException {
/* 338 */     return this.raf.readDouble();
/*     */   }
/*     */ 
/*     */   
/*     */   public float readFloat() throws IOException {
/* 343 */     return this.raf.readFloat();
/*     */   }
/*     */ 
/*     */   
/*     */   public int readInt() throws IOException {
/* 348 */     return this.raf.readInt();
/*     */   }
/*     */ 
/*     */   
/*     */   public String readLine() throws IOException {
/* 353 */     return findString(new String[] { "\n" });
/*     */   }
/*     */ 
/*     */   
/*     */   public String readCString() throws IOException {
/* 358 */     return findString(new String[] { "\000" });
/*     */   }
/*     */ 
/*     */   
/*     */   public String readString(int n) throws IOException {
/* 363 */     byte[] b = new byte[n];
/* 364 */     readFully(b);
/* 365 */     return new String(b, "UTF-8");
/*     */   }
/*     */ 
/*     */   
/*     */   public long readLong() throws IOException {
/* 370 */     return this.raf.readLong();
/*     */   }
/*     */ 
/*     */   
/*     */   public short readShort() throws IOException {
/* 375 */     return this.raf.readShort();
/*     */   }
/*     */ 
/*     */   
/*     */   public int readUnsignedByte() throws IOException {
/* 380 */     return this.raf.readUnsignedByte();
/*     */   }
/*     */ 
/*     */   
/*     */   public int readUnsignedShort() throws IOException {
/* 385 */     return this.raf.readUnsignedShort();
/*     */   }
/*     */ 
/*     */   
/*     */   public String readUTF() throws IOException {
/* 390 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public int skipBytes(int n) throws IOException {
/* 395 */     return this.raf.skipBytes(n);
/*     */   }
/*     */ 
/*     */   
/*     */   public int read(byte[] array) throws IOException {
/* 400 */     return read(array, 0, array.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read(byte[] array, int offset, int n) throws IOException {
/* 407 */     return this.raf.read(array, offset, n);
/*     */   }
/*     */ 
/*     */   
/*     */   public void readFully(byte[] array) throws IOException {
/* 412 */     readFully(array, 0, array.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readFully(byte[] array, int offset, int n) throws IOException {
/* 419 */     this.raf.readFully(array, offset, n);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int available() throws IOException {
/* 426 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public void mark(int readLimit) {}
/*     */ 
/*     */   
/*     */   public boolean markSupported() {
/* 434 */     return false;
/*     */   }
/*     */   
/*     */   public void reset() throws IOException {
/* 438 */     this.raf.seek(0L);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/common/NIOInputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */