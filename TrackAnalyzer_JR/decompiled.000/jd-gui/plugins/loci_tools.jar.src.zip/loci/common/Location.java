/*     */ package loci.common;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Location
/*     */ {
/*  67 */   private static final Logger LOGGER = LoggerFactory.getLogger(Location.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  72 */   private static ThreadLocal<HashMap<String, Object>> idMap = new ThreadLocal<HashMap<String, Object>>()
/*     */     {
/*     */       protected HashMap<String, Object> initialValue() {
/*  75 */         return new HashMap<String, Object>();
/*     */       }
/*     */     };
/*     */ 
/*     */   
/*     */   private static volatile boolean cacheListings = false;
/*     */   
/*  82 */   private static volatile long cacheNanos = 3600000000000L;
/*     */   
/*     */   protected class ListingsResult {
/*     */     public final String[] listing;
/*     */     
/*     */     ListingsResult(String[] listing, long time) {
/*  88 */       this.listing = listing;
/*  89 */       this.time = time;
/*     */     }
/*     */     public final long time; }
/*  92 */   private static ConcurrentHashMap<String, ListingsResult> fileListings = new ConcurrentHashMap<String, ListingsResult>();
/*     */ 
/*     */   
/*     */   private boolean isURL = true;
/*     */ 
/*     */   
/*     */   private URL url;
/*     */   
/*     */   private File file;
/*     */ 
/*     */   
/*     */   public Location(String pathname) {
/* 104 */     LOGGER.trace("Location({})", pathname);
/* 105 */     if (pathname.contains("://")) {
/*     */       
/*     */       try {
/* 108 */         this.url = new URL(getMappedId(pathname));
/*     */       }
/* 110 */       catch (MalformedURLException e) {
/* 111 */         LOGGER.trace("Location is not a URL", e);
/* 112 */         this.isURL = false;
/*     */       } 
/*     */     } else {
/* 115 */       LOGGER.trace("Location is not a URL");
/* 116 */       this.isURL = false;
/*     */     } 
/* 118 */     if (!this.isURL) this.file = new File(getMappedId(pathname)); 
/*     */   }
/*     */   
/*     */   public Location(File file) {
/* 122 */     LOGGER.trace("Location({})", file);
/* 123 */     this.isURL = false;
/* 124 */     this.file = file;
/*     */   }
/*     */   
/*     */   public Location(String parent, String child) {
/* 128 */     this(parent + File.separator + child);
/*     */   }
/*     */   
/*     */   public Location(Location parent, String child) {
/* 132 */     this(parent.getAbsolutePath(), child);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void reset() {
/* 142 */     cacheListings = false;
/* 143 */     cacheNanos = 3600000000000L;
/* 144 */     fileListings.clear();
/* 145 */     getIdMap().clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void cacheDirectoryListings(boolean cache) {
/* 165 */     cacheListings = cache;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setCacheDirectoryTimeout(double sec) {
/* 175 */     cacheNanos = (long)(sec * 1000.0D * 1000.0D * 1000.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void clearDirectoryListingsCache() {
/* 184 */     fileListings = new ConcurrentHashMap<String, ListingsResult>();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void cleanStaleCacheEntries() {
/* 191 */     long t = System.nanoTime() - cacheNanos;
/* 192 */     ArrayList<String> staleKeys = new ArrayList<String>();
/* 193 */     for (String key : fileListings.keySet()) {
/* 194 */       if (((ListingsResult)fileListings.get(key)).time < t) {
/* 195 */         staleKeys.add(key);
/*     */       }
/*     */     } 
/* 198 */     for (String key : staleKeys) {
/* 199 */       fileListings.remove(key);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void mapId(String id, String filename) {
/* 214 */     if (id == null)
/* 215 */       return;  if (filename == null) { getIdMap().remove(id); }
/* 216 */     else { getIdMap().put(id, filename); }
/* 217 */      LOGGER.debug("Location.mapId: {} -> {}", id, filename);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void mapFile(String id, IRandomAccess ira) {
/* 222 */     if (id == null)
/* 223 */       return;  if (ira == null) { getIdMap().remove(id); }
/* 224 */     else { getIdMap().put(id, ira); }
/* 225 */      LOGGER.debug("Location.mapFile: {} -> {}", id, ira);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getMappedId(String id) {
/* 238 */     if (getIdMap() == null) return id; 
/* 239 */     String filename = null;
/* 240 */     if (id != null && getIdMap().get(id) instanceof String) {
/* 241 */       filename = (String)getIdMap().get(id);
/*     */     }
/* 243 */     return (filename == null) ? id : filename;
/*     */   }
/*     */ 
/*     */   
/*     */   public static IRandomAccess getMappedFile(String id) {
/* 248 */     if (getIdMap() == null) return null; 
/* 249 */     IRandomAccess ira = null;
/* 250 */     if (id != null && getIdMap().get(id) instanceof IRandomAccess) {
/* 251 */       ira = (IRandomAccess)getIdMap().get(id);
/*     */     }
/* 253 */     return ira;
/*     */   }
/*     */   
/*     */   public static HashMap<String, Object> getIdMap() {
/* 257 */     return idMap.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setIdMap(HashMap<String, Object> map) {
/* 265 */     if (map == null) throw new IllegalArgumentException("map cannot be null"); 
/* 266 */     idMap.set(map);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IRandomAccess getHandle(String id) throws IOException {
/* 274 */     return getHandle(id, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IRandomAccess getHandle(String id, boolean writable) throws IOException {
/* 284 */     return getHandle(id, writable, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IRandomAccess getHandle(String id, boolean writable, boolean allowArchiveHandles) throws IOException {
/* 294 */     LOGGER.trace("getHandle(id = {}, writable = {})", id, Boolean.valueOf(writable));
/* 295 */     IRandomAccess handle = getMappedFile(id);
/* 296 */     if (handle == null) {
/* 297 */       LOGGER.trace("no handle was mapped for this ID");
/* 298 */       String mapId = getMappedId(id);
/*     */       
/* 300 */       if (id.startsWith("http://")) {
/* 301 */         handle = new URLHandle(mapId);
/*     */       }
/* 303 */       else if (allowArchiveHandles && ZipHandle.isZipFile(id)) {
/* 304 */         handle = new ZipHandle(mapId);
/*     */       }
/* 306 */       else if (allowArchiveHandles && GZipHandle.isGZipFile(id)) {
/* 307 */         handle = new GZipHandle(mapId);
/*     */       }
/* 309 */       else if (allowArchiveHandles && BZip2Handle.isBZip2File(id)) {
/* 310 */         handle = new BZip2Handle(mapId);
/*     */       } else {
/*     */         
/* 313 */         handle = new NIOFileHandle(mapId, writable ? "rw" : "r");
/*     */       } 
/*     */     } 
/* 316 */     LOGGER.trace("Location.getHandle: {} -> {}", id, handle);
/* 317 */     return handle;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] list(boolean noHiddenFiles) {
/* 327 */     String key = getAbsolutePath() + Boolean.toString(noHiddenFiles);
/* 328 */     String[] result = null;
/* 329 */     if (cacheListings) {
/* 330 */       cleanStaleCacheEntries();
/* 331 */       ListingsResult listingsResult = fileListings.get(key);
/* 332 */       if (listingsResult != null) {
/* 333 */         return listingsResult.listing;
/*     */       }
/*     */     } 
/* 336 */     ArrayList<String> files = new ArrayList<String>();
/* 337 */     if (this.isURL) {
/*     */       try {
/* 339 */         URLConnection c = this.url.openConnection();
/* 340 */         InputStream is = c.getInputStream();
/* 341 */         boolean foundEnd = false;
/*     */         
/* 343 */         while (!foundEnd) {
/* 344 */           byte[] b = new byte[is.available()];
/* 345 */           is.read(b);
/* 346 */           String s = new String(b, "UTF-8");
/* 347 */           if (s.toLowerCase().indexOf("</html>") != -1) foundEnd = true;
/*     */           
/* 349 */           while (s.indexOf("a href") != -1) {
/* 350 */             int ndx = s.indexOf("a href") + 8;
/* 351 */             int idx = s.indexOf("\"", ndx);
/* 352 */             if (idx < 0)
/* 353 */               break;  String f = s.substring(ndx, idx);
/* 354 */             if (files.size() > 0 && f.startsWith("/")) {
/* 355 */               return null;
/*     */             }
/* 357 */             s = s.substring(idx + 1);
/* 358 */             if (f.startsWith("?"))
/* 359 */               continue;  Location check = new Location(getAbsolutePath(), f);
/* 360 */             if (check.exists() && (!noHiddenFiles || !check.isHidden())) {
/* 361 */               files.add(check.getName());
/*     */             }
/*     */           }
/*     */         
/*     */         } 
/* 366 */       } catch (IOException e) {
/* 367 */         LOGGER.trace("Could not retrieve directory listing", e);
/* 368 */         return null;
/*     */       } 
/*     */     } else {
/*     */       
/* 372 */       if (this.file == null) return null; 
/* 373 */       String[] f = this.file.list();
/* 374 */       if (f == null) return null; 
/* 375 */       for (String name : f) {
/* 376 */         if (!noHiddenFiles || (!name.startsWith(".") && !(new Location(this.file.getAbsolutePath(), name)).isHidden()))
/*     */         {
/*     */           
/* 379 */           files.add(name);
/*     */         }
/*     */       } 
/*     */     } 
/* 383 */     result = files.<String>toArray(new String[files.size()]);
/* 384 */     if (cacheListings) {
/* 385 */       fileListings.put(key, new ListingsResult(result, System.nanoTime()));
/*     */     }
/* 387 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canRead() {
/* 400 */     return this.isURL ? ((isDirectory() || isFile())) : this.file.canRead();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canWrite() {
/* 410 */     return this.isURL ? false : this.file.canWrite();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean createNewFile() throws IOException {
/* 425 */     if (this.isURL) throw new IOException("Unimplemented"); 
/* 426 */     return this.file.createNewFile();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean delete() {
/* 437 */     return this.isURL ? false : this.file.delete();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void deleteOnExit() {
/* 447 */     if (!this.isURL) this.file.deleteOnExit();
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 455 */     String absPath = getAbsolutePath();
/* 456 */     String thatPath = null;
/*     */     
/* 458 */     if (obj instanceof Location) {
/* 459 */       thatPath = ((Location)obj).getAbsolutePath();
/*     */     } else {
/*     */       
/* 462 */       thatPath = obj.toString();
/*     */     } 
/*     */     
/* 465 */     return absPath.equals(thatPath);
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 469 */     return getAbsolutePath().hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean exists() {
/* 480 */     if (this.isURL) {
/*     */       try {
/* 482 */         this.url.getContent();
/* 483 */         return true;
/*     */       }
/* 485 */       catch (IOException e) {
/* 486 */         LOGGER.trace("Failed to retrieve content from URL", e);
/* 487 */         return false;
/*     */       } 
/*     */     }
/* 490 */     if (this.file.exists()) return true; 
/* 491 */     if (getMappedFile(this.file.getPath()) != null) return true;
/*     */     
/* 493 */     String mappedId = getMappedId(this.file.getPath());
/* 494 */     return (mappedId != null && (new File(mappedId)).exists());
/*     */   }
/*     */ 
/*     */   
/*     */   public Location getAbsoluteFile() {
/* 499 */     return new Location(getAbsolutePath());
/*     */   }
/*     */ 
/*     */   
/*     */   public String getAbsolutePath() {
/* 504 */     return this.isURL ? this.url.toExternalForm() : this.file.getAbsolutePath();
/*     */   }
/*     */ 
/*     */   
/*     */   public Location getCanonicalFile() throws IOException {
/* 509 */     return this.isURL ? getAbsoluteFile() : new Location(this.file.getCanonicalFile());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCanonicalPath() throws IOException {
/* 519 */     return this.isURL ? getAbsolutePath() : this.file.getCanonicalPath();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 529 */     if (this.isURL) {
/* 530 */       String name = this.url.getFile();
/* 531 */       name = name.substring(name.lastIndexOf("/") + 1);
/* 532 */       return name;
/*     */     } 
/* 534 */     return this.file.getName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getParent() {
/* 545 */     if (this.isURL) {
/* 546 */       String absPath = getAbsolutePath();
/* 547 */       absPath = absPath.substring(0, absPath.lastIndexOf("/"));
/* 548 */       return absPath;
/*     */     } 
/* 550 */     return this.file.getParent();
/*     */   }
/*     */ 
/*     */   
/*     */   public Location getParentFile() {
/* 555 */     return new Location(getParent());
/*     */   }
/*     */ 
/*     */   
/*     */   public String getPath() {
/* 560 */     return this.isURL ? (this.url.getHost() + this.url.getPath()) : this.file.getPath();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAbsolute() {
/* 570 */     return this.isURL ? true : this.file.isAbsolute();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDirectory() {
/* 579 */     if (this.isURL) {
/* 580 */       String[] list = list();
/* 581 */       return (list != null);
/*     */     } 
/* 583 */     return this.file.isDirectory();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isFile() {
/* 592 */     return this.isURL ? ((!isDirectory() && exists())) : this.file.isFile();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isHidden() {
/* 602 */     return this.isURL ? false : this.file.isHidden();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long lastModified() {
/* 614 */     if (this.isURL) {
/*     */       try {
/* 616 */         return this.url.openConnection().getLastModified();
/*     */       }
/* 618 */       catch (IOException e) {
/* 619 */         LOGGER.trace("Could not determine URL's last modification time", e);
/* 620 */         return 0L;
/*     */       } 
/*     */     }
/* 623 */     return this.file.lastModified();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long length() {
/* 631 */     if (this.isURL) {
/*     */       try {
/* 633 */         return this.url.openConnection().getContentLength();
/*     */       }
/* 635 */       catch (IOException e) {
/* 636 */         LOGGER.trace("Could not determine URL's content length", e);
/* 637 */         return 0L;
/*     */       } 
/*     */     }
/* 640 */     return this.file.length();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] list() {
/* 649 */     return list(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Location[] listFiles() {
/* 658 */     String[] s = list();
/* 659 */     if (s == null) return null; 
/* 660 */     Location[] f = new Location[s.length];
/* 661 */     for (int i = 0; i < f.length; i++) {
/* 662 */       f[i] = new Location(getAbsolutePath(), s[i]);
/* 663 */       f[i] = f[i].getAbsoluteFile();
/*     */     } 
/* 665 */     return f;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public URL toURL() throws MalformedURLException {
/* 674 */     return this.isURL ? this.url : this.file.toURI().toURL();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 682 */     return this.isURL ? this.url.toString() : this.file.toString();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/common/Location.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */