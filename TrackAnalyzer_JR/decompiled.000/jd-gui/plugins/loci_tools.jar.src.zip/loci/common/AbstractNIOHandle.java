/*    */ package loci.common;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractNIOHandle
/*    */   implements IRandomAccess
/*    */ {
/*    */   protected static final String EOF_ERROR_MSG = "Attempting to read beyond end of file.";
/*    */   
/*    */   protected void validateMode(String mode) {
/* 73 */     if (!mode.equals("r") && !mode.equals("rw")) {
/* 74 */       throw new IllegalArgumentException(String.format("%s mode not in supported modes ('r', 'rw')", new Object[] { mode }));
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected boolean validateLength(int writeLength) throws IOException {
/* 88 */     if (getFilePointer() + writeLength > length()) {
/* 89 */       setLength(getFilePointer() + writeLength);
/* 90 */       return false;
/*    */     } 
/* 92 */     return true;
/*    */   }
/*    */   
/*    */   protected abstract void setLength(long paramLong) throws IOException;
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/common/AbstractNIOHandle.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */