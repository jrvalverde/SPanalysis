/*     */ package loci.common;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.ByteOrder;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RandomAccessInputStream
/*     */   extends InputStream
/*     */   implements DataInput
/*     */ {
/*     */   protected static final int MAX_OVERHEAD = 1048576;
/*  66 */   private static final Logger LOGGER = LoggerFactory.getLogger(RandomAccessInputStream.class);
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final int DEFAULT_BLOCK_SIZE = 262144;
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final int MAX_SEARCH_SIZE = 536870912;
/*     */ 
/*     */ 
/*     */   
/*     */   protected IRandomAccess raf;
/*     */ 
/*     */   
/*     */   protected final String file;
/*     */ 
/*     */   
/*  84 */   protected long length = -1L;
/*     */   
/*  86 */   protected long markedPos = -1L;
/*     */   
/*  88 */   protected String encoding = "UTF-8";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RandomAccessInputStream(String file) throws IOException {
/*  97 */     this(Location.getHandle(file), file);
/*     */   }
/*     */ 
/*     */   
/*     */   public RandomAccessInputStream(IRandomAccess handle) throws IOException {
/* 102 */     this(handle, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RandomAccessInputStream(IRandomAccess handle, String file) throws IOException {
/* 112 */     if (LOGGER.isTraceEnabled()) {
/* 113 */       LOGGER.trace("RandomAccessInputStream {} OPEN", Integer.valueOf(hashCode()));
/*     */     }
/* 115 */     this.raf = handle;
/* 116 */     this.raf.setOrder(ByteOrder.BIG_ENDIAN);
/* 117 */     this.file = file;
/* 118 */     seek(0L);
/* 119 */     this.length = -1L;
/*     */   }
/*     */ 
/*     */   
/*     */   public RandomAccessInputStream(byte[] array) throws IOException {
/* 124 */     this(new ByteArrayHandle(array));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEncoding(String encoding) {
/* 135 */     this.encoding = encoding;
/*     */   }
/*     */ 
/*     */   
/*     */   public void seek(long pos) throws IOException {
/* 140 */     this.raf.seek(pos);
/*     */   }
/*     */ 
/*     */   
/*     */   public long length() throws IOException {
/* 145 */     return (this.length < 0L) ? this.raf.length() : this.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLength(long newLength) throws IOException {
/* 157 */     if (newLength < length()) {
/* 158 */       this.length = newLength;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public long getFilePointer() throws IOException {
/* 164 */     return this.raf.getFilePointer();
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 169 */     if (LOGGER.isTraceEnabled()) {
/* 170 */       LOGGER.trace("RandomAccessInputStream {} CLOSE", Integer.valueOf(hashCode()));
/*     */     }
/* 172 */     if (Location.getMappedFile(this.file) != null)
/* 173 */       return;  if (this.raf != null) this.raf.close(); 
/* 174 */     this.raf = null;
/* 175 */     this.markedPos = -1L;
/*     */   }
/*     */ 
/*     */   
/*     */   public void order(boolean little) {
/* 180 */     if (this.raf != null) {
/* 181 */       this.raf.setOrder(little ? ByteOrder.LITTLE_ENDIAN : ByteOrder.BIG_ENDIAN);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isLittleEndian() {
/* 187 */     return (this.raf.getOrder() == ByteOrder.LITTLE_ENDIAN);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String readString(String lastChars) throws IOException {
/* 196 */     if (lastChars.length() == 1) return findString(new String[] { lastChars }); 
/* 197 */     String[] terminators = new String[lastChars.length()];
/* 198 */     for (int i = 0; i < terminators.length; i++) {
/* 199 */       terminators[i] = lastChars.substring(i, i + 1);
/*     */     }
/* 201 */     return findString(terminators);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String findString(String... terminators) throws IOException {
/* 214 */     return findString(true, 262144, terminators);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String findString(boolean saveString, String... terminators) throws IOException {
/* 235 */     return findString(saveString, 262144, terminators);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String findString(int blockSize, String... terminators) throws IOException {
/* 252 */     return findString(true, blockSize, terminators);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String findString(boolean saveString, int blockSize, String... terminators) throws IOException {
/* 274 */     StringBuilder out = new StringBuilder();
/* 275 */     long startPos = getFilePointer();
/* 276 */     long bytesDropped = 0L;
/* 277 */     long inputLen = length();
/* 278 */     long maxLen = inputLen - startPos;
/* 279 */     boolean tooLong = (saveString && maxLen > 536870912L);
/* 280 */     if (tooLong) maxLen = 536870912L; 
/* 281 */     boolean match = false;
/* 282 */     int maxTermLen = 0;
/* 283 */     for (String term : terminators) {
/* 284 */       int len = term.length();
/* 285 */       if (len > maxTermLen) maxTermLen = len;
/*     */     
/*     */     } 
/* 288 */     InputStreamReader in = new InputStreamReader(this, this.encoding);
/* 289 */     char[] buf = new char[blockSize];
/* 290 */     long loc = 0L;
/* 291 */     while (loc < maxLen && getFilePointer() < length() - 1L) {
/*     */       
/* 293 */       if (!saveString) {
/* 294 */         int outLen = out.length();
/* 295 */         if (outLen >= maxTermLen) {
/* 296 */           int dropIndex = outLen - maxTermLen + 1;
/* 297 */           String last = out.substring(dropIndex, outLen);
/* 298 */           out.setLength(0);
/* 299 */           out.append(last);
/* 300 */           bytesDropped += dropIndex;
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 305 */       int r = in.read(buf, 0, blockSize);
/* 306 */       if (r <= 0) throw new IOException("Cannot read from stream: " + r);
/*     */ 
/*     */       
/* 309 */       out.append(buf, 0, r);
/*     */ 
/*     */       
/* 312 */       int min = Integer.MAX_VALUE, tagLen = 0;
/* 313 */       for (String t : terminators) {
/* 314 */         int len = t.length();
/* 315 */         int start = (int)(loc - bytesDropped - len);
/* 316 */         int value = out.indexOf(t, (start < 0) ? 0 : start);
/* 317 */         if (value >= 0 && value < min) {
/* 318 */           match = true;
/* 319 */           min = value;
/* 320 */           tagLen = len;
/*     */         } 
/*     */       } 
/*     */       
/* 324 */       if (match) {
/*     */         
/* 326 */         seek(startPos + bytesDropped + min + tagLen);
/*     */ 
/*     */         
/* 329 */         if (saveString) {
/* 330 */           out.setLength(min + tagLen);
/* 331 */           return out.toString();
/*     */         } 
/* 333 */         return null;
/*     */       } 
/*     */       
/* 336 */       loc += r;
/*     */     } 
/*     */ 
/*     */     
/* 340 */     if (tooLong) throw new IOException("Maximum search length reached."); 
/* 341 */     return saveString ? out.toString() : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean readBoolean() throws IOException {
/* 348 */     return this.raf.readBoolean();
/*     */   }
/*     */ 
/*     */   
/*     */   public byte readByte() throws IOException {
/* 353 */     return this.raf.readByte();
/*     */   }
/*     */ 
/*     */   
/*     */   public char readChar() throws IOException {
/* 358 */     return this.raf.readChar();
/*     */   }
/*     */ 
/*     */   
/*     */   public double readDouble() throws IOException {
/* 363 */     return this.raf.readDouble();
/*     */   }
/*     */ 
/*     */   
/*     */   public float readFloat() throws IOException {
/* 368 */     return this.raf.readFloat();
/*     */   }
/*     */ 
/*     */   
/*     */   public int readInt() throws IOException {
/* 373 */     return this.raf.readInt();
/*     */   }
/*     */ 
/*     */   
/*     */   public String readLine() throws IOException {
/* 378 */     String line = findString(new String[] { "\n" });
/* 379 */     return (line.length() == 0) ? null : line;
/*     */   }
/*     */ 
/*     */   
/*     */   public String readCString() throws IOException {
/* 384 */     String line = findString(new String[] { "\000" });
/* 385 */     return (line.length() == 0) ? null : line;
/*     */   }
/*     */ 
/*     */   
/*     */   public String readString(int n) throws IOException {
/* 390 */     int avail = available();
/* 391 */     if (n > avail) n = avail; 
/* 392 */     byte[] b = new byte[n];
/* 393 */     readFully(b);
/* 394 */     return new String(b, this.encoding);
/*     */   }
/*     */ 
/*     */   
/*     */   public long readLong() throws IOException {
/* 399 */     return this.raf.readLong();
/*     */   }
/*     */ 
/*     */   
/*     */   public short readShort() throws IOException {
/* 404 */     return this.raf.readShort();
/*     */   }
/*     */ 
/*     */   
/*     */   public int readUnsignedByte() throws IOException {
/* 409 */     return this.raf.readUnsignedByte();
/*     */   }
/*     */ 
/*     */   
/*     */   public int readUnsignedShort() throws IOException {
/* 414 */     return this.raf.readUnsignedShort();
/*     */   }
/*     */ 
/*     */   
/*     */   public String readUTF() throws IOException {
/* 419 */     return this.raf.readUTF();
/*     */   }
/*     */ 
/*     */   
/*     */   public int skipBytes(int n) throws IOException {
/* 424 */     return this.raf.skipBytes(n);
/*     */   }
/*     */ 
/*     */   
/*     */   public int read(byte[] array) throws IOException {
/* 429 */     int rtn = this.raf.read(array);
/* 430 */     if (rtn == 0 && this.raf.getFilePointer() >= this.raf.length() - 1L) rtn = -1; 
/* 431 */     return rtn;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read(byte[] array, int offset, int n) throws IOException {
/* 438 */     int rtn = this.raf.read(array, offset, n);
/* 439 */     if (rtn == 0 && this.raf.getFilePointer() >= this.raf.length() - 1L) rtn = -1; 
/* 440 */     return rtn;
/*     */   }
/*     */ 
/*     */   
/*     */   public int read(ByteBuffer buf) throws IOException {
/* 445 */     return this.raf.read(buf);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read(ByteBuffer buf, int offset, int n) throws IOException {
/* 452 */     return this.raf.read(buf, offset, n);
/*     */   }
/*     */ 
/*     */   
/*     */   public void readFully(byte[] array) throws IOException {
/* 457 */     this.raf.readFully(array);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readFully(byte[] array, int offset, int n) throws IOException {
/* 464 */     this.raf.readFully(array, offset, n);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int read() throws IOException {
/* 470 */     int b = readByte();
/* 471 */     if (b == -1 && getFilePointer() >= length()) return 0; 
/* 472 */     return b;
/*     */   }
/*     */   
/*     */   public int available() throws IOException {
/* 476 */     long remain = length() - getFilePointer();
/* 477 */     if (remain > 2147483647L) remain = 2147483647L; 
/* 478 */     return (int)remain;
/*     */   }
/*     */   
/*     */   public void mark(int readLimit) {
/*     */     try {
/* 483 */       this.markedPos = getFilePointer();
/*     */     }
/* 485 */     catch (IOException exc) {
/* 486 */       LOGGER.warn("Cannot set mark", exc);
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean markSupported() {
/* 491 */     return true;
/*     */   }
/*     */   
/*     */   public void reset() throws IOException {
/* 495 */     if (this.markedPos < 0L) throw new IOException("No mark set"); 
/* 496 */     seek(this.markedPos);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/common/RandomAccessInputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */