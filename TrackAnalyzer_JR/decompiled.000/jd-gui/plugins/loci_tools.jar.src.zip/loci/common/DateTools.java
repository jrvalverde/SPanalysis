/*     */ package loci.common;
/*     */ 
/*     */ import java.text.FieldPosition;
/*     */ import java.text.ParsePosition;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.TimeZone;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DateTools
/*     */ {
/*     */   public static final int UNIX = 0;
/*     */   public static final int COBOL = 1;
/*     */   public static final int MICROSOFT = 2;
/*     */   public static final int ZVI = 3;
/*     */   public static final int ALT_ZVI = 4;
/*     */   public static final long UNIX_EPOCH = 0L;
/*     */   public static final long COBOL_EPOCH = 11644473600000L;
/*     */   public static final long MICROSOFT_EPOCH = 2209143600000L;
/*     */   public static final long ZVI_EPOCH = 2921084975759000L;
/*     */   public static final long ALT_ZVI_EPOCH = 2921084284761000L;
/*     */   public static final String ISO8601_FORMAT = "yyyy-MM-dd'T'HH:mm:ss";
/*     */   
/*     */   public static long getMillisFromTicks(long hi, long lo) {
/*  88 */     long ticks = hi << 32L | lo;
/*  89 */     return ticks / 10000L;
/*     */   }
/*     */ 
/*     */   
/*     */   public static String convertDate(long stamp, int format) {
/*  94 */     return convertDate(stamp, format, "yyyy-MM-dd'T'HH:mm:ss");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static String convertDate(long stamp, int format, String outputFormat) {
/* 100 */     return convertDate(stamp, format, outputFormat, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String convertDate(long stamp, int format, String outputFormat, boolean correctTimeZoneForGMT) {
/* 115 */     long ms = stamp;
/*     */     
/* 117 */     switch (format) {
/*     */       case 0:
/* 119 */         ms -= 0L;
/*     */         break;
/*     */       case 1:
/* 122 */         ms -= 11644473600000L;
/*     */         break;
/*     */       case 2:
/* 125 */         ms -= 2209143600000L;
/*     */         break;
/*     */       case 3:
/* 128 */         ms -= 2921084975759000L;
/*     */         break;
/*     */       case 4:
/* 131 */         ms -= 2921084284761000L;
/*     */         break;
/*     */     } 
/*     */     
/* 135 */     SimpleDateFormat fmt = new SimpleDateFormat(outputFormat);
/* 136 */     if (correctTimeZoneForGMT) {
/* 137 */       TimeZone tz = TimeZone.getDefault();
/* 138 */       ms -= tz.getOffset(ms);
/*     */     } 
/* 140 */     StringBuffer sb = new StringBuffer();
/*     */     
/* 142 */     Date d = new Date(ms);
/*     */     
/* 144 */     fmt.format(d, sb, new FieldPosition(0));
/* 145 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String formatDate(String date, String format) {
/* 157 */     return formatDate(date, format, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String formatDate(String date, String format, boolean lenient) {
/* 168 */     if (date == null) return null; 
/* 169 */     SimpleDateFormat sdf = new SimpleDateFormat(format);
/* 170 */     sdf.setLenient(lenient);
/* 171 */     Date d = sdf.parse(date, new ParsePosition(0));
/* 172 */     if (d == null) return null; 
/* 173 */     sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
/* 174 */     return sdf.format(d);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String formatDate(String date, String[] formats) {
/* 186 */     return formatDate(date, formats, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String formatDate(String date, String[] formats, boolean lenient) {
/* 199 */     for (int i = 0; i < formats.length; i++) {
/* 200 */       String result = formatDate(date, formats[i], lenient);
/* 201 */       if (result != null) return result; 
/*     */     } 
/* 203 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long getTime(String date, String format) {
/* 211 */     SimpleDateFormat f = new SimpleDateFormat(format);
/* 212 */     Date d = f.parse(date, new ParsePosition(0));
/* 213 */     if (d == null) return -1L; 
/* 214 */     return d.getTime();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/common/DateTools.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */