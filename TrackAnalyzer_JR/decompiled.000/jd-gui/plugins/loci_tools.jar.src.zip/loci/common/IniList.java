/*    */ package loci.common;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.HashMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IniList
/*    */   extends ArrayList<IniTable>
/*    */ {
/*    */   public IniTable getTable(String tableName) {
/* 57 */     for (IniTable table : this) {
/* 58 */       String header = table.get("header");
/* 59 */       if (tableName.equals(header)) return table; 
/*    */     } 
/* 61 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public HashMap<String, String> flattenIntoHashMap() {
/* 69 */     HashMap<String, String> h = new HashMap<String, String>();
/* 70 */     for (IniTable table : this) {
/* 71 */       String tableName = table.get("header");
/* 72 */       for (String key : table.keySet()) {
/* 73 */         if (!key.equals("header")) {
/* 74 */           h.put("[" + tableName + "] " + key, table.get(key));
/*    */         }
/*    */       } 
/*    */     } 
/* 78 */     return h;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/common/IniList.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */