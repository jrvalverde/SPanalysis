package loci.common;

public interface StatusReporter {
  void addStatusListener(StatusListener paramStatusListener);
  
  void removeStatusListener(StatusListener paramStatusListener);
  
  void notifyListeners(StatusEvent paramStatusEvent);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/common/StatusReporter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */