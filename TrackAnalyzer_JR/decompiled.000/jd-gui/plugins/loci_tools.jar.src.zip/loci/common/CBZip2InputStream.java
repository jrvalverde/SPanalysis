/*      */ package loci.common;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import org.slf4j.Logger;
/*      */ import org.slf4j.LoggerFactory;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class CBZip2InputStream
/*      */   extends InputStream
/*      */ {
/*      */   private static final int BASE_BLOCK_SIZE = 100000;
/*      */   private static final int MAX_ALPHA_SIZE = 258;
/*      */   private static final int MAX_CODE_LEN = 23;
/*      */   private static final int RUNA = 0;
/*      */   private static final int RUNB = 1;
/*      */   private static final int N_GROUPS = 6;
/*      */   private static final int G_SIZE = 50;
/*      */   private static final int MAX_SELECTORS = 18002;
/*  102 */   private static final int[] R_NUMS = new int[] { 619, 720, 127, 481, 931, 816, 813, 233, 566, 247, 985, 724, 205, 454, 863, 491, 741, 242, 949, 214, 733, 859, 335, 708, 621, 574, 73, 654, 730, 472, 419, 436, 278, 496, 867, 210, 399, 680, 480, 51, 878, 465, 811, 169, 869, 675, 611, 697, 867, 561, 862, 687, 507, 283, 482, 129, 807, 591, 733, 623, 150, 238, 59, 379, 684, 877, 625, 169, 643, 105, 170, 607, 520, 932, 727, 476, 693, 425, 174, 647, 73, 122, 335, 530, 442, 853, 695, 249, 445, 515, 909, 545, 703, 919, 874, 474, 882, 500, 594, 612, 641, 801, 220, 162, 819, 984, 589, 513, 495, 799, 161, 604, 958, 533, 221, 400, 386, 867, 600, 782, 382, 596, 414, 171, 516, 375, 682, 485, 911, 276, 98, 553, 163, 354, 666, 933, 424, 341, 533, 870, 227, 730, 475, 186, 263, 647, 537, 686, 600, 224, 469, 68, 770, 919, 190, 373, 294, 822, 808, 206, 184, 943, 795, 384, 383, 461, 404, 758, 839, 887, 715, 67, 618, 276, 204, 918, 873, 777, 604, 560, 951, 160, 578, 722, 79, 804, 96, 409, 713, 940, 652, 934, 970, 447, 318, 353, 859, 672, 112, 785, 645, 863, 803, 350, 139, 93, 354, 99, 820, 908, 609, 772, 154, 274, 580, 184, 79, 626, 630, 742, 653, 282, 762, 623, 680, 81, 927, 626, 789, 125, 411, 521, 938, 300, 821, 78, 343, 175, 128, 250, 170, 774, 972, 275, 999, 639, 495, 78, 352, 126, 857, 956, 358, 619, 580, 124, 737, 594, 701, 612, 669, 112, 134, 694, 363, 992, 809, 743, 168, 974, 944, 375, 748, 52, 600, 747, 642, 182, 862, 81, 344, 805, 988, 739, 511, 655, 814, 334, 249, 515, 897, 955, 664, 981, 649, 113, 974, 459, 893, 228, 433, 837, 553, 268, 926, 240, 102, 654, 459, 51, 686, 754, 806, 760, 493, 403, 415, 394, 687, 700, 946, 670, 656, 610, 738, 392, 760, 799, 887, 653, 978, 321, 576, 617, 626, 502, 894, 679, 243, 440, 680, 879, 194, 572, 640, 724, 926, 56, 204, 700, 707, 151, 457, 449, 797, 195, 791, 558, 945, 679, 297, 59, 87, 824, 713, 663, 412, 693, 342, 606, 134, 108, 571, 364, 631, 212, 174, 643, 304, 329, 343, 97, 430, 751, 497, 314, 983, 374, 822, 928, 140, 206, 73, 263, 980, 736, 876, 478, 430, 305, 170, 514, 364, 692, 829, 82, 855, 953, 676, 246, 369, 970, 294, 750, 807, 827, 150, 790, 288, 923, 804, 378, 215, 828, 592, 281, 565, 555, 710, 82, 896, 831, 547, 261, 524, 462, 293, 465, 502, 56, 661, 821, 976, 991, 658, 869, 905, 758, 745, 193, 768, 550, 608, 933, 378, 286, 215, 979, 792, 961, 61, 688, 793, 644, 986, 403, 106, 366, 905, 644, 372, 567, 466, 434, 645, 210, 389, 550, 919, 135, 780, 773, 635, 389, 707, 100, 626, 958, 165, 504, 920, 176, 193, 713, 857, 265, 203, 50, 668, 108, 645, 990, 626, 197, 510, 357, 358, 850, 858, 364, 936, 638 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  157 */   private static final Logger LOGGER = LoggerFactory.getLogger(CBZip2InputStream.class); private int last;
/*      */   private int origPtr;
/*      */   private int blockSize100k;
/*      */   private boolean blockRandomised;
/*      */   private int bsBuff;
/*      */   private int bsLive;
/*      */   
/*      */   private static void reportCRCError() {
/*  165 */     LOGGER.error("BZip2 CRC error");
/*      */   }
/*      */   
/*      */   private void makeMaps() {
/*  169 */     boolean[] inUse = this.data.inUse;
/*  170 */     byte[] seqToUnseq = this.data.seqToUnseq;
/*      */     
/*  172 */     int nInUseShadow = 0;
/*      */     
/*  174 */     for (int i = 0; i < 256; i++) {
/*  175 */       if (inUse[i]) seqToUnseq[nInUseShadow++] = (byte)i;
/*      */     
/*      */     } 
/*  178 */     this.nInUse = nInUseShadow;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  201 */   private final CRC crc = new CRC();
/*      */   
/*      */   private int nInUse;
/*      */   
/*      */   private InputStream in;
/*      */   
/*  207 */   private int currentChar = -1;
/*      */   
/*      */   private static final int EOF = 0;
/*      */   
/*      */   private static final int START_BLOCK_STATE = 1;
/*      */   private static final int RAND_PART_A_STATE = 2;
/*      */   private static final int RAND_PART_B_STATE = 3;
/*      */   private static final int RAND_PART_C_STATE = 4;
/*      */   private static final int NO_RAND_PART_A_STATE = 5;
/*      */   private static final int NO_RAND_PART_B_STATE = 6;
/*      */   private static final int NO_RAND_PART_C_STATE = 7;
/*  218 */   private int currentState = 1;
/*      */ 
/*      */   
/*      */   private int storedBlockCRC;
/*      */ 
/*      */   
/*      */   private int storedCombinedCRC;
/*      */ 
/*      */   
/*      */   private int computedBlockCRC;
/*      */ 
/*      */   
/*      */   private int computedCombinedCRC;
/*      */ 
/*      */   
/*      */   private int suCount;
/*      */ 
/*      */   
/*      */   private int suCh2;
/*      */ 
/*      */   
/*      */   private int suChPrev;
/*      */ 
/*      */   
/*      */   private int suI2;
/*      */ 
/*      */   
/*      */   private int suJ2;
/*      */   
/*      */   private int suRNToGo;
/*      */   
/*      */   private int suRTPos;
/*      */   
/*      */   private int suTPos;
/*      */   
/*      */   private char suZ;
/*      */   
/*      */   private Data data;
/*      */ 
/*      */   
/*      */   public CBZip2InputStream(InputStream in) throws IOException {
/*  259 */     this.in = in;
/*  260 */     init();
/*      */   }
/*      */   
/*      */   public int read() throws IOException {
/*  264 */     if (this.in != null) return read0(); 
/*  265 */     throw new IOException("stream closed");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int read(byte[] dest, int offs, int len) throws IOException {
/*  271 */     if (offs < 0) {
/*  272 */       throw new IndexOutOfBoundsException("offs(" + offs + ") < 0.");
/*      */     }
/*  274 */     if (len < 0) {
/*  275 */       throw new IndexOutOfBoundsException("len(" + len + ") < 0.");
/*      */     }
/*  277 */     if (offs + len > dest.length) {
/*  278 */       throw new IndexOutOfBoundsException("offs(" + offs + ") + len(" + len + ") > dest.length(" + dest.length + ").");
/*      */     }
/*      */     
/*  281 */     if (this.in == null) throw new IOException("stream closed");
/*      */     
/*  283 */     int hi = offs + len;
/*  284 */     int destOffs = offs; int b;
/*  285 */     while (destOffs < hi && (b = read0()) >= 0) {
/*  286 */       dest[destOffs++] = (byte)b;
/*      */     }
/*      */     
/*  289 */     return (destOffs == offs) ? -1 : (destOffs - offs);
/*      */   }
/*      */   
/*      */   private int read0() throws IOException {
/*  293 */     int retChar = this.currentChar;
/*      */     
/*  295 */     switch (this.currentState) {
/*      */       case 0:
/*  297 */         return -1;
/*      */       
/*      */       case 1:
/*  300 */         throw new IllegalStateException();
/*      */       
/*      */       case 2:
/*  303 */         throw new IllegalStateException();
/*      */       
/*      */       case 3:
/*  306 */         setupRandPartB();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  328 */         return retChar;case 4: setupRandPartC(); return retChar;case 5: throw new IllegalStateException();case 6: setupNoRandPartB(); return retChar;case 7: setupNoRandPartC(); return retChar;
/*      */     } 
/*      */     throw new IllegalStateException();
/*      */   } private void init() throws IOException {
/*  332 */     int magic2 = this.in.read();
/*  333 */     if (magic2 != 104) {
/*  334 */       throw new IOException("Stream is not BZip2 formatted: expected 'h' as first byte but got '" + (char)magic2 + "'");
/*      */     }
/*      */ 
/*      */     
/*  338 */     int blockSize = this.in.read();
/*  339 */     if (blockSize < 49 || blockSize > 57) {
/*  340 */       throw new IOException("Stream is not BZip2 formatted: illegal blocksize " + (char)blockSize);
/*      */     }
/*      */ 
/*      */     
/*  344 */     this.blockSize100k = blockSize - 48;
/*      */     
/*  346 */     initBlock();
/*  347 */     setupBlock();
/*      */   }
/*      */   
/*      */   private void initBlock() throws IOException {
/*  351 */     char magic0 = bsGetUByte();
/*  352 */     char magic1 = bsGetUByte();
/*  353 */     char magic2 = bsGetUByte();
/*  354 */     char magic3 = bsGetUByte();
/*  355 */     char magic4 = bsGetUByte();
/*  356 */     char magic5 = bsGetUByte();
/*      */     
/*  358 */     if (magic0 == '\027' && magic1 == 'r' && magic2 == 'E' && magic3 == '8' && magic4 == 'P' && magic5 == '') {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  365 */       complete();
/*      */     } else {
/*  367 */       if (magic0 != '1' || magic1 != 'A' || magic2 != 'Y' || magic3 != '&' || magic4 != 'S' || magic5 != 'Y') {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  374 */         this.currentState = 0;
/*  375 */         throw new IOException("bad block header");
/*      */       } 
/*      */       
/*  378 */       this.storedBlockCRC = bsGetInt();
/*  379 */       this.blockRandomised = (bsR(1) == 1);
/*      */ 
/*      */ 
/*      */       
/*  383 */       if (this.data == null) {
/*  384 */         this.data = new Data(this.blockSize100k);
/*      */       }
/*      */ 
/*      */       
/*  388 */       getAndMoveToFrontDecode();
/*      */       
/*  390 */       this.crc.initialiseCRC();
/*  391 */       this.currentState = 1;
/*      */     } 
/*      */   }
/*      */   
/*      */   private void endBlock() {
/*  396 */     this.computedBlockCRC = this.crc.getFinalCRC();
/*      */ 
/*      */     
/*  399 */     if (this.storedBlockCRC != this.computedBlockCRC) {
/*      */ 
/*      */       
/*  402 */       this.computedCombinedCRC = this.storedCombinedCRC << 1 | this.storedCombinedCRC >>> 31;
/*      */       
/*  404 */       this.computedCombinedCRC ^= this.storedBlockCRC;
/*      */       
/*  406 */       reportCRCError();
/*      */     } 
/*      */     
/*  409 */     this.computedCombinedCRC = this.computedCombinedCRC << 1 | this.computedCombinedCRC >>> 31;
/*      */     
/*  411 */     this.computedCombinedCRC ^= this.computedBlockCRC;
/*      */   }
/*      */   
/*      */   private void complete() throws IOException {
/*  415 */     this.storedCombinedCRC = bsGetInt();
/*  416 */     this.currentState = 0;
/*  417 */     this.data = null;
/*      */     
/*  419 */     if (this.storedCombinedCRC != this.computedCombinedCRC) {
/*  420 */       reportCRCError();
/*      */     }
/*      */   }
/*      */   
/*      */   public void close() throws IOException {
/*  425 */     InputStream inShadow = this.in;
/*  426 */     if (inShadow != null) {
/*      */       try {
/*  428 */         if (inShadow != System.in) inShadow.close();
/*      */       
/*      */       } finally {
/*  431 */         this.data = null;
/*  432 */         this.in = null;
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   private int bsR(int n) throws IOException {
/*  438 */     int bsLiveShadow = this.bsLive;
/*  439 */     int bsBuffShadow = this.bsBuff;
/*      */     
/*  441 */     if (bsLiveShadow < n) {
/*  442 */       InputStream inShadow = this.in;
/*      */       do {
/*  444 */         int thech = inShadow.read();
/*      */         
/*  446 */         if (thech < 0) throw new IOException("unexpected end of stream");
/*      */         
/*  448 */         bsBuffShadow = bsBuffShadow << 8 | thech;
/*  449 */         bsLiveShadow += 8;
/*      */       }
/*  451 */       while (bsLiveShadow < n);
/*      */       
/*  453 */       this.bsBuff = bsBuffShadow;
/*      */     } 
/*      */     
/*  456 */     this.bsLive = bsLiveShadow - n;
/*  457 */     return bsBuffShadow >> bsLiveShadow - n & (1 << n) - 1;
/*      */   }
/*      */   
/*      */   private boolean bsGetBit() throws IOException {
/*  461 */     return (bsR(1) != 0);
/*      */   }
/*      */   
/*      */   private char bsGetUByte() throws IOException {
/*  465 */     return (char)bsR(8);
/*      */   }
/*      */   
/*      */   private int bsGetInt() throws IOException {
/*  469 */     return ((bsR(8) << 8 | bsR(8)) << 8 | bsR(8)) << 8 | bsR(8);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static void hbCreateDecodeTables(int[] limit, int[] base, int[] perm, char[] length, int minLen, int maxLen, int alphaSize) {
/*      */     int i;
/*      */     int pp;
/*  477 */     for (i = minLen, pp = 0; i <= maxLen; i++) {
/*  478 */       for (int k = 0; k < alphaSize; k++) {
/*  479 */         if (length[k] == i) perm[pp++] = k;
/*      */       
/*      */       } 
/*      */     } 
/*  483 */     for (i = 23; --i > 0; ) {
/*  484 */       base[i] = 0;
/*  485 */       limit[i] = 0;
/*      */     } 
/*      */     
/*  488 */     for (i = 0; i < alphaSize; i++) {
/*  489 */       base[length[i] + 1] = base[length[i] + 1] + 1;
/*      */     }
/*      */     int b;
/*  492 */     for (i = 1, b = base[0]; i < 23; i++) {
/*  493 */       b += base[i];
/*  494 */       base[i] = b;
/*      */     }  int vec;
/*      */     int j;
/*  497 */     for (i = minLen, vec = 0, j = base[i]; i <= maxLen; i++) {
/*  498 */       int nb = base[i + 1];
/*  499 */       vec += nb - j;
/*  500 */       j = nb;
/*  501 */       limit[i] = vec - 1;
/*  502 */       vec <<= 1;
/*      */     } 
/*      */     
/*  505 */     for (i = minLen + 1; i <= maxLen; i++) {
/*  506 */       base[i] = (limit[i - 1] + 1 << 1) - base[i];
/*      */     }
/*      */   }
/*      */   
/*      */   private void recvDecodingTables() throws IOException {
/*  511 */     Data dataShadow = this.data;
/*  512 */     boolean[] inUse = dataShadow.inUse;
/*  513 */     byte[] pos = dataShadow.recvDecodingTablesPos;
/*  514 */     byte[] selector = dataShadow.selector;
/*  515 */     byte[] selectorMtf = dataShadow.selectorMtf;
/*      */     
/*  517 */     int inUse16 = 0;
/*      */     
/*      */     int i;
/*  520 */     for (i = 0; i < 16; i++) {
/*  521 */       if (bsGetBit()) {
/*  522 */         inUse16 |= 1 << i;
/*      */       }
/*      */     } 
/*      */     
/*  526 */     for (i = 256; --i >= 0; inUse[i] = false);
/*      */     
/*  528 */     for (i = 0; i < 16; i++) {
/*  529 */       if ((inUse16 & 1 << i) != 0) {
/*  530 */         int i16 = i << 4;
/*  531 */         for (int m = 0; m < 16; m++) {
/*  532 */           if (bsGetBit()) inUse[i16 + m] = true;
/*      */         
/*      */         } 
/*      */       } 
/*      */     } 
/*  537 */     makeMaps();
/*  538 */     int alphaSize = this.nInUse + 2;
/*      */ 
/*      */     
/*  541 */     int nGroups = bsR(3);
/*  542 */     int nSelectors = bsR(15);
/*      */     
/*  544 */     for (int k = 0; k < nSelectors; k++) {
/*  545 */       int m = 0;
/*  546 */       for (; bsGetBit(); m++);
/*  547 */       selectorMtf[k] = (byte)m;
/*      */     } 
/*      */ 
/*      */     
/*  551 */     for (int v = nGroups; --v >= 0; pos[v] = (byte)v);
/*      */     
/*  553 */     for (int j = 0; j < nSelectors; j++) {
/*  554 */       int m = selectorMtf[j] & 0xFF;
/*  555 */       byte tmp = pos[m];
/*  556 */       while (m > 0) {
/*      */         
/*  558 */         pos[m] = pos[m - 1];
/*  559 */         m--;
/*      */       } 
/*  561 */       pos[0] = tmp;
/*  562 */       selector[j] = tmp;
/*      */     } 
/*      */     
/*  565 */     char[][] len = dataShadow.tempCharArray2d;
/*      */ 
/*      */     
/*  568 */     for (int t = 0; t < nGroups; t++) {
/*  569 */       int curr = bsR(5);
/*  570 */       char[] tLen = len[t];
/*  571 */       for (int m = 0; m < alphaSize; m++) {
/*  572 */         for (; bsGetBit(); curr += bsGetBit() ? -1 : 1);
/*  573 */         tLen[m] = (char)curr;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  578 */     createHuffmanDecodingTables(alphaSize, nGroups);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void createHuffmanDecodingTables(int alphaSize, int nGroups) {
/*  585 */     Data dataShadow = this.data;
/*  586 */     char[][] len = dataShadow.tempCharArray2d;
/*  587 */     int[] minLens = dataShadow.minLens;
/*  588 */     int[][] limit = dataShadow.limit;
/*  589 */     int[][] base = dataShadow.base;
/*  590 */     int[][] perm = dataShadow.perm;
/*      */     
/*  592 */     for (int t = 0; t < nGroups; t++) {
/*  593 */       int minLen = 32;
/*  594 */       int maxLen = 0;
/*  595 */       char[] tLen = len[t];
/*  596 */       for (int i = alphaSize; --i >= 0; ) {
/*  597 */         char lent = tLen[i];
/*  598 */         if (lent > maxLen) maxLen = lent; 
/*  599 */         if (lent < minLen) minLen = lent; 
/*      */       } 
/*  601 */       hbCreateDecodeTables(limit[t], base[t], perm[t], len[t], minLen, maxLen, alphaSize);
/*      */       
/*  603 */       minLens[t] = minLen;
/*      */     } 
/*      */   }
/*      */   
/*      */   private void getAndMoveToFrontDecode() throws IOException {
/*  608 */     this.origPtr = bsR(24);
/*  609 */     recvDecodingTables();
/*      */     
/*  611 */     InputStream inShadow = this.in;
/*  612 */     Data dataShadow = this.data;
/*  613 */     byte[] ll8 = dataShadow.ll8;
/*  614 */     int[] unzftab = dataShadow.unzftab;
/*  615 */     byte[] selector = dataShadow.selector;
/*  616 */     byte[] seqToUnseq = dataShadow.seqToUnseq;
/*  617 */     char[] yy = dataShadow.getAndMoveToFrontDecodeYY;
/*  618 */     int[] minLens = dataShadow.minLens;
/*  619 */     int[][] limit = dataShadow.limit;
/*  620 */     int[][] base = dataShadow.base;
/*  621 */     int[][] perm = dataShadow.perm;
/*  622 */     int limitLast = this.blockSize100k * 100000;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  628 */     for (int i = 256; --i >= 0; ) {
/*  629 */       yy[i] = (char)i;
/*  630 */       unzftab[i] = 0;
/*      */     } 
/*      */     
/*  633 */     int groupNo = 0;
/*  634 */     int groupPos = 49;
/*  635 */     int eob = this.nInUse + 1;
/*  636 */     int nextSym = getAndMoveToFrontDecode0(0);
/*  637 */     int bsBuffShadow = this.bsBuff;
/*  638 */     int bsLiveShadow = this.bsLive;
/*  639 */     int lastShadow = -1;
/*  640 */     int zt = selector[groupNo] & 0xFF;
/*  641 */     int[] baseZT = base[zt];
/*  642 */     int[] limitZT = limit[zt];
/*  643 */     int[] permZT = perm[zt];
/*  644 */     int minLensZT = minLens[zt];
/*      */     
/*  646 */     while (nextSym != eob) {
/*  647 */       if (nextSym == 0 || nextSym == 1) {
/*  648 */         int s = -1;
/*      */         int n;
/*  650 */         for (n = 1;; n <<= 1) {
/*  651 */           if (nextSym == 0) { s += n; }
/*  652 */           else if (nextSym == 1) { s += n << 1; }
/*      */           else
/*      */           { break; }
/*  655 */            if (groupPos == 0) {
/*  656 */             groupPos = 49;
/*  657 */             zt = selector[++groupNo] & 0xFF;
/*  658 */             baseZT = base[zt];
/*  659 */             limitZT = limit[zt];
/*  660 */             permZT = perm[zt];
/*  661 */             minLensZT = minLens[zt];
/*      */           } else {
/*  663 */             groupPos--;
/*      */           } 
/*  665 */           int j = minLensZT;
/*      */ 
/*      */ 
/*      */           
/*  669 */           while (bsLiveShadow < j) {
/*  670 */             int thech = inShadow.read();
/*  671 */             if (thech >= 0) {
/*  672 */               bsBuffShadow = bsBuffShadow << 8 | thech;
/*  673 */               bsLiveShadow += 8;
/*      */               continue;
/*      */             } 
/*  676 */             throw new IOException("unexpected end of stream");
/*      */           } 
/*  678 */           int k = bsBuffShadow >> bsLiveShadow - j & (1 << j) - 1;
/*  679 */           bsLiveShadow -= j;
/*      */           
/*  681 */           while (k > limitZT[j]) {
/*  682 */             j++;
/*  683 */             while (bsLiveShadow < 1) {
/*  684 */               int thech = inShadow.read();
/*  685 */               if (thech >= 0) {
/*  686 */                 bsBuffShadow = bsBuffShadow << 8 | thech;
/*  687 */                 bsLiveShadow += 8;
/*      */                 continue;
/*      */               } 
/*  690 */               throw new IOException("unexpected end of stream");
/*      */             } 
/*  692 */             bsLiveShadow--;
/*  693 */             k = k << 1 | bsBuffShadow >> bsLiveShadow & 0x1;
/*      */           } 
/*  695 */           nextSym = permZT[k - baseZT[j]];
/*      */         } 
/*      */         
/*  698 */         byte ch = seqToUnseq[yy[0]];
/*  699 */         unzftab[ch & 0xFF] = unzftab[ch & 0xFF] + s + 1;
/*      */         
/*  701 */         for (; s-- >= 0; ll8[++lastShadow] = ch);
/*      */         
/*  703 */         if (lastShadow >= limitLast) throw new IOException("block overrun"); 
/*      */         continue;
/*      */       } 
/*  706 */       if (++lastShadow >= limitLast) {
/*  707 */         throw new IOException("block overrun");
/*      */       }
/*      */       
/*  710 */       char tmp = yy[nextSym - 1];
/*  711 */       unzftab[seqToUnseq[tmp] & 0xFF] = unzftab[seqToUnseq[tmp] & 0xFF] + 1;
/*  712 */       ll8[lastShadow] = seqToUnseq[tmp];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  719 */       if (nextSym <= 16) {
/*  720 */         for (int j = nextSym - 1; j > 0; yy[j] = yy[--j]);
/*      */       } else {
/*  722 */         System.arraycopy(yy, 0, yy, 1, nextSym - 1);
/*      */       } 
/*  724 */       yy[0] = tmp;
/*      */       
/*  726 */       if (groupPos == 0) {
/*  727 */         groupPos = 49;
/*  728 */         zt = selector[++groupNo] & 0xFF;
/*  729 */         baseZT = base[zt];
/*  730 */         limitZT = limit[zt];
/*  731 */         permZT = perm[zt];
/*  732 */         minLensZT = minLens[zt];
/*      */       } else {
/*  734 */         groupPos--;
/*      */       } 
/*  736 */       int zn = minLensZT;
/*      */ 
/*      */ 
/*      */       
/*  740 */       while (bsLiveShadow < zn) {
/*  741 */         int thech = inShadow.read();
/*  742 */         if (thech >= 0) {
/*  743 */           bsBuffShadow = bsBuffShadow << 8 | thech;
/*  744 */           bsLiveShadow += 8;
/*      */           continue;
/*      */         } 
/*  747 */         throw new IOException("unexpected end of stream");
/*      */       } 
/*  749 */       int zvec = bsBuffShadow >> bsLiveShadow - zn & (1 << zn) - 1;
/*  750 */       bsLiveShadow -= zn;
/*      */       
/*  752 */       while (zvec > limitZT[zn]) {
/*  753 */         zn++;
/*  754 */         while (bsLiveShadow < 1) {
/*  755 */           int thech = inShadow.read();
/*  756 */           if (thech >= 0) {
/*  757 */             bsBuffShadow = bsBuffShadow << 8 | thech;
/*  758 */             bsLiveShadow += 8;
/*      */             continue;
/*      */           } 
/*  761 */           throw new IOException("unexpected end of stream");
/*      */         } 
/*  763 */         bsLiveShadow--;
/*  764 */         zvec = zvec << 1 | bsBuffShadow >> bsLiveShadow & 0x1;
/*      */       } 
/*  766 */       nextSym = permZT[zvec - baseZT[zn]];
/*      */     } 
/*      */ 
/*      */     
/*  770 */     this.last = lastShadow;
/*  771 */     this.bsLive = bsLiveShadow;
/*  772 */     this.bsBuff = bsBuffShadow;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private int getAndMoveToFrontDecode0(int groupNo) throws IOException {
/*  778 */     InputStream inShadow = this.in;
/*  779 */     Data dataShadow = this.data;
/*  780 */     int zt = dataShadow.selector[groupNo] & 0xFF;
/*  781 */     int[] limitZT = dataShadow.limit[zt];
/*  782 */     int zn = dataShadow.minLens[zt];
/*  783 */     int zvec = bsR(zn);
/*  784 */     int bsLiveShadow = this.bsLive;
/*  785 */     int bsBuffShadow = this.bsBuff;
/*      */     
/*  787 */     while (zvec > limitZT[zn]) {
/*  788 */       zn++;
/*  789 */       while (bsLiveShadow < 1) {
/*  790 */         int thech = inShadow.read();
/*      */         
/*  792 */         if (thech >= 0) {
/*  793 */           bsBuffShadow = bsBuffShadow << 8 | thech;
/*  794 */           bsLiveShadow += 8;
/*      */           continue;
/*      */         } 
/*  797 */         throw new IOException("unexpected end of stream");
/*      */       } 
/*  799 */       bsLiveShadow--;
/*  800 */       zvec = zvec << 1 | bsBuffShadow >> bsLiveShadow & 0x1;
/*      */     } 
/*      */     
/*  803 */     this.bsLive = bsLiveShadow;
/*  804 */     this.bsBuff = bsBuffShadow;
/*      */     
/*  806 */     return dataShadow.perm[zt][zvec - dataShadow.base[zt][zn]];
/*      */   }
/*      */   
/*      */   private void setupBlock() throws IOException {
/*  810 */     if (this.data == null)
/*      */       return; 
/*  812 */     int[] cftab = this.data.cftab;
/*  813 */     int[] tt = this.data.initTT(this.last + 1);
/*  814 */     byte[] ll8 = this.data.ll8;
/*  815 */     cftab[0] = 0;
/*  816 */     System.arraycopy(this.data.unzftab, 0, cftab, 1, 256);
/*      */     int i, c;
/*  818 */     for (i = 1, c = cftab[0]; i <= 256; i++) {
/*  819 */       c += cftab[i];
/*  820 */       cftab[i] = c;
/*      */     } 
/*      */     int lastShadow;
/*  823 */     for (i = 0, lastShadow = this.last; i <= lastShadow; i++) {
/*  824 */       cftab[ll8[i] & 0xFF] = cftab[ll8[i] & 0xFF] + 1; tt[cftab[ll8[i] & 0xFF]] = i;
/*      */     } 
/*      */     
/*  827 */     if (this.origPtr < 0 || this.origPtr >= tt.length) {
/*  828 */       throw new IOException("stream corrupted");
/*      */     }
/*      */     
/*  831 */     this.suTPos = tt[this.origPtr];
/*  832 */     this.suCount = 0;
/*  833 */     this.suI2 = 0;
/*  834 */     this.suCh2 = 256;
/*      */     
/*  836 */     if (this.blockRandomised) {
/*  837 */       this.suRNToGo = 0;
/*  838 */       this.suRTPos = 0;
/*  839 */       setupRandPartA();
/*      */     } else {
/*  841 */       setupNoRandPartA();
/*      */     } 
/*      */   }
/*      */   private void setupRandPartA() throws IOException {
/*  845 */     if (this.suI2 <= this.last) {
/*  846 */       this.suChPrev = this.suCh2;
/*  847 */       int suCh2Shadow = this.data.ll8[this.suTPos] & 0xFF;
/*  848 */       this.suTPos = this.data.tt[this.suTPos];
/*  849 */       if (this.suRNToGo == 0) {
/*  850 */         this.suRNToGo = R_NUMS[this.suRTPos] - 1;
/*  851 */         if (++this.suRTPos == 512) this.suRTPos = 0; 
/*      */       } else {
/*  853 */         this.suRNToGo--;
/*  854 */       }  this.suCh2 = suCh2Shadow ^= (this.suRNToGo == 1) ? 1 : 0;
/*  855 */       this.suI2++;
/*  856 */       this.currentChar = suCh2Shadow;
/*  857 */       this.currentState = 3;
/*  858 */       this.crc.updateCRC(suCh2Shadow);
/*      */     } else {
/*      */       
/*  861 */       endBlock();
/*  862 */       initBlock();
/*  863 */       setupBlock();
/*      */     } 
/*      */   }
/*      */   
/*      */   private void setupNoRandPartA() throws IOException {
/*  868 */     if (this.suI2 <= this.last) {
/*  869 */       this.suChPrev = this.suCh2;
/*  870 */       int suCh2Shadow = this.data.ll8[this.suTPos] & 0xFF;
/*  871 */       this.suCh2 = suCh2Shadow;
/*  872 */       this.suTPos = this.data.tt[this.suTPos];
/*  873 */       this.suI2++;
/*  874 */       this.currentChar = suCh2Shadow;
/*  875 */       this.currentState = 6;
/*  876 */       this.crc.updateCRC(suCh2Shadow);
/*      */     } else {
/*      */       
/*  879 */       this.currentState = 5;
/*  880 */       endBlock();
/*  881 */       initBlock();
/*  882 */       setupBlock();
/*      */     } 
/*      */   }
/*      */   
/*      */   private void setupRandPartB() throws IOException {
/*  887 */     if (this.suCh2 != this.suChPrev) {
/*  888 */       this.currentState = 2;
/*  889 */       this.suCount = 1;
/*  890 */       setupRandPartA();
/*      */     }
/*  892 */     else if (++this.suCount >= 4) {
/*  893 */       this.suZ = (char)(this.data.ll8[this.suTPos] & 0xFF);
/*  894 */       this.suTPos = this.data.tt[this.suTPos];
/*  895 */       if (this.suRNToGo == 0) {
/*  896 */         this.suRNToGo = R_NUMS[this.suRTPos] - 1;
/*  897 */         if (++this.suRTPos == 512) {
/*  898 */           this.suRTPos = 0;
/*      */         }
/*      */       } else {
/*  901 */         this.suRNToGo--;
/*  902 */       }  this.suJ2 = 0;
/*  903 */       this.currentState = 4;
/*  904 */       if (this.suRNToGo == 1) this.suZ = (char)(this.suZ ^ 0x1); 
/*  905 */       setupRandPartC();
/*      */     } else {
/*      */       
/*  908 */       this.currentState = 2;
/*  909 */       setupRandPartA();
/*      */     } 
/*      */   }
/*      */   
/*      */   private void setupRandPartC() throws IOException {
/*  914 */     if (this.suJ2 < this.suZ) {
/*  915 */       this.currentChar = this.suCh2;
/*  916 */       this.crc.updateCRC(this.suCh2);
/*  917 */       this.suJ2++;
/*      */     } else {
/*      */       
/*  920 */       this.currentState = 2;
/*  921 */       this.suI2++;
/*  922 */       this.suCount = 0;
/*  923 */       setupRandPartA();
/*      */     } 
/*      */   }
/*      */   
/*      */   private void setupNoRandPartB() throws IOException {
/*  928 */     if (this.suCh2 != this.suChPrev) {
/*  929 */       this.suCount = 1;
/*  930 */       setupNoRandPartA();
/*      */     }
/*  932 */     else if (++this.suCount >= 4) {
/*  933 */       this.suZ = (char)(this.data.ll8[this.suTPos] & 0xFF);
/*  934 */       this.suTPos = this.data.tt[this.suTPos];
/*  935 */       this.suJ2 = 0;
/*  936 */       setupNoRandPartC();
/*      */     } else {
/*  938 */       setupNoRandPartA();
/*      */     } 
/*      */   }
/*      */   private void setupNoRandPartC() throws IOException {
/*  942 */     if (this.suJ2 < this.suZ) {
/*  943 */       int suCh2Shadow = this.suCh2;
/*  944 */       this.currentChar = suCh2Shadow;
/*  945 */       this.crc.updateCRC(suCh2Shadow);
/*  946 */       this.suJ2++;
/*  947 */       this.currentState = 7;
/*      */     } else {
/*      */       
/*  950 */       this.suI2++;
/*  951 */       this.suCount = 0;
/*  952 */       setupNoRandPartA();
/*      */     } 
/*      */   }
/*      */   
/*      */   private static final class Data
/*      */   {
/*  958 */     final boolean[] inUse = new boolean[256];
/*      */     
/*  960 */     final byte[] seqToUnseq = new byte[256];
/*  961 */     final byte[] selector = new byte[18002];
/*  962 */     final byte[] selectorMtf = new byte[18002];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  968 */     final int[] unzftab = new int[256];
/*      */     
/*  970 */     final int[][] limit = new int[6][258];
/*  971 */     final int[][] base = new int[6][258];
/*  972 */     final int[][] perm = new int[6][258];
/*  973 */     final int[] minLens = new int[6];
/*      */     
/*  975 */     final int[] cftab = new int[257];
/*  976 */     final char[] getAndMoveToFrontDecodeYY = new char[256];
/*      */ 
/*      */     
/*  979 */     final char[][] tempCharArray2d = new char[6][258];
/*      */     
/*  981 */     final byte[] recvDecodingTablesPos = new byte[6];
/*      */ 
/*      */ 
/*      */     
/*      */     int[] tt;
/*      */ 
/*      */ 
/*      */     
/*      */     byte[] ll8;
/*      */ 
/*      */ 
/*      */     
/*      */     Data(int blockSize100k) {
/*  994 */       this.ll8 = new byte[blockSize100k * 100000];
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     int[] initTT(int length) {
/* 1006 */       int[] ttShadow = this.tt;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1012 */       if (ttShadow == null || ttShadow.length < length) {
/* 1013 */         this.tt = ttShadow = new int[length];
/*      */       }
/*      */       
/* 1016 */       return ttShadow;
/*      */     }
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/common/CBZip2InputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */