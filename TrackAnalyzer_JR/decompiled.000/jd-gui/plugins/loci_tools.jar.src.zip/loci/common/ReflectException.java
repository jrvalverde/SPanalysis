/*    */ package loci.common;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReflectException
/*    */   extends Exception
/*    */ {
/*    */   public ReflectException() {}
/*    */   
/*    */   public ReflectException(String s) {
/* 50 */     super(s);
/* 51 */   } public ReflectException(String s, Throwable cause) { super(s, cause); } public ReflectException(Throwable cause) {
/* 52 */     super(cause);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/common/ReflectException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */