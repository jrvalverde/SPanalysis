package loci.common;

public final class Constants {
  public static final String ENCODING = "UTF-8";
  
  public static final double EPSILON = 1.0E-6D;
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/common/Constants.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */