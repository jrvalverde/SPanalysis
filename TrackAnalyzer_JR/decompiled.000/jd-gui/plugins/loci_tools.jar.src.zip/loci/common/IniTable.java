package loci.common;

import java.util.HashMap;

public class IniTable extends HashMap<String, String> {
  public static final String HEADER_KEY = "header";
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/common/IniTable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */