/*     */ package loci.common;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.URL;
/*     */ import java.net.URLClassLoader;
/*     */ import java.util.HashMap;
/*     */ import java.util.StringTokenizer;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReflectedUniverse
/*     */ {
/*  65 */   private static final Logger LOGGER = LoggerFactory.getLogger(ReflectedUniverse.class);
/*     */ 
/*     */ 
/*     */   
/*     */   protected HashMap<String, Object> variables;
/*     */ 
/*     */ 
/*     */   
/*     */   protected ClassLoader loader;
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean force;
/*     */ 
/*     */ 
/*     */   
/*     */   public ReflectedUniverse() {
/*  82 */     this((ClassLoader)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReflectedUniverse(URL[] urls) {
/*  90 */     this((urls == null) ? null : new URLClassLoader(urls));
/*     */   }
/*     */ 
/*     */   
/*     */   public ReflectedUniverse(ClassLoader loader) {
/*  95 */     this.variables = new HashMap<String, Object>();
/*  96 */     this.loader = (loader == null) ? getClass().getClassLoader() : loader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isInstance(Class<?> c, Object o) {
/* 106 */     return (o == null || c.isInstance(o) || (c == byte.class && o instanceof Byte) || (c == short.class && o instanceof Short) || (c == int.class && o instanceof Integer) || (c == long.class && o instanceof Long) || (c == float.class && o instanceof Float) || (c == double.class && o instanceof Double) || (c == boolean.class && o instanceof Boolean) || (c == char.class && o instanceof Character));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object exec(String command) throws ReflectException {
/* 150 */     command = command.trim();
/* 151 */     if (command.startsWith("import ")) {
/*     */       Class<?> c;
/* 153 */       command = command.substring(7).trim();
/* 154 */       int dot = command.lastIndexOf(".");
/* 155 */       String varName = (dot < 0) ? command : command.substring(dot + 1);
/*     */       
/*     */       try {
/* 158 */         c = Class.forName(command, true, this.loader);
/*     */       }
/* 160 */       catch (NoClassDefFoundError err) {
/* 161 */         LOGGER.debug("No such class: {}", command, err);
/* 162 */         throw new ReflectException("No such class: " + command, err);
/*     */       }
/* 164 */       catch (ClassNotFoundException exc) {
/* 165 */         LOGGER.debug("No such class: {}", command, exc);
/* 166 */         throw new ReflectException("No such class: " + command, exc);
/*     */       }
/* 168 */       catch (RuntimeException exc) {
/*     */         
/* 170 */         String msg = exc.getMessage();
/* 171 */         if (msg != null && msg.indexOf("ClassNotFound") < 0) throw exc; 
/* 172 */         LOGGER.debug("No such class: {}", command, exc);
/* 173 */         throw new ReflectException("No such class: " + command, exc);
/*     */       } 
/* 175 */       setVar(varName, c);
/* 176 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 180 */     int eqIndex = command.indexOf("=");
/* 181 */     String target = null;
/* 182 */     if (eqIndex >= 0) {
/* 183 */       target = command.substring(0, eqIndex).trim();
/* 184 */       command = command.substring(eqIndex + 1).trim();
/*     */     } 
/*     */     
/* 187 */     Object result = null;
/*     */ 
/*     */     
/* 190 */     int leftParen = command.indexOf("(");
/* 191 */     if (leftParen < 0) {
/*     */       
/* 193 */       result = getVar(command);
/* 194 */       if (target != null) setVar(target, result); 
/* 195 */       return result;
/*     */     } 
/* 197 */     if (leftParen != command.lastIndexOf("(") || command.indexOf(")") != command.length() - 1)
/*     */     {
/*     */       
/* 200 */       throw new ReflectException("Invalid parentheses");
/*     */     }
/*     */ 
/*     */     
/* 204 */     String arglist = command.substring(leftParen + 1);
/* 205 */     StringTokenizer st = new StringTokenizer(arglist, "(,)");
/* 206 */     int len = st.countTokens();
/* 207 */     Object[] args = new Object[len];
/* 208 */     for (int i = 0; i < len; i++) {
/* 209 */       String arg = st.nextToken().trim();
/* 210 */       args[i] = getVar(arg);
/*     */     } 
/* 212 */     command = command.substring(0, leftParen);
/*     */     
/* 214 */     if (command.startsWith("new ")) {
/*     */       
/* 216 */       String className = command.substring(4).trim();
/* 217 */       Object var = getVar(className);
/* 218 */       if (var == null) {
/* 219 */         throw new ReflectException("Class not found: " + className);
/*     */       }
/* 221 */       if (!(var instanceof Class)) {
/* 222 */         throw new ReflectException("Not a class: " + className);
/*     */       }
/* 224 */       Class<?> cl = (Class)var;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 231 */       Constructor<?> constructor = null;
/* 232 */       Constructor[] arrayOfConstructor = (Constructor[])cl.getConstructors();
/* 233 */       for (int j = 0; j < arrayOfConstructor.length; j++) {
/* 234 */         if (this.force) arrayOfConstructor[j].setAccessible(true); 
/* 235 */         Class<?>[] params = arrayOfConstructor[j].getParameterTypes();
/* 236 */         if (params.length == args.length) {
/* 237 */           boolean match = true;
/* 238 */           for (int k = 0; k < params.length; k++) {
/* 239 */             if (!isInstance(params[k], args[k])) {
/* 240 */               match = false;
/*     */               break;
/*     */             } 
/*     */           } 
/* 244 */           if (match) {
/* 245 */             constructor = arrayOfConstructor[j];
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       } 
/* 250 */       if (constructor == null) {
/* 251 */         StringBuffer sb = new StringBuffer(command);
/* 252 */         for (int k = 0; k < args.length; k++) {
/* 253 */           sb.append((k == 0) ? "(" : ", ");
/* 254 */           sb.append(args[k].getClass().getName());
/*     */         } 
/* 256 */         sb.append(")");
/* 257 */         throw new ReflectException("No such constructor: " + sb.toString());
/*     */       } 
/*     */ 
/*     */       
/* 261 */       Exception exc = null; 
/* 262 */       try { result = constructor.newInstance(args); }
/* 263 */       catch (InstantiationException e) { exc = e = null; }
/* 264 */       catch (IllegalAccessException e) { exc = e = null; }
/* 265 */       catch (InvocationTargetException e) { exc = e = null; }
/* 266 */        if (exc != null) {
/* 267 */         LOGGER.debug("Cannot instantiate object", exc);
/* 268 */         throw new ReflectException("Cannot instantiate object", exc);
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 273 */       int dot = command.indexOf(".");
/* 274 */       if (dot < 0) throw new ReflectException("Syntax error"); 
/* 275 */       String varName = command.substring(0, dot).trim();
/* 276 */       String methodName = command.substring(dot + 1).trim();
/* 277 */       Object var = getVar(varName);
/* 278 */       if (var == null) {
/* 279 */         throw new ReflectException("No such variable: " + varName);
/*     */       }
/* 281 */       Class<?> varClass = (var instanceof Class) ? (Class)var : var.getClass();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 289 */       Method method = null;
/* 290 */       Method[] m = varClass.getMethods();
/* 291 */       for (int j = 0; j < m.length; j++) {
/* 292 */         if (this.force) m[j].setAccessible(true); 
/* 293 */         if (methodName.equals(m[j].getName())) {
/* 294 */           Class<?>[] params = m[j].getParameterTypes();
/* 295 */           if (params.length == args.length) {
/* 296 */             boolean match = true;
/* 297 */             for (int k = 0; k < params.length; k++) {
/* 298 */               if (!isInstance(params[k], args[k])) {
/* 299 */                 match = false;
/*     */                 break;
/*     */               } 
/*     */             } 
/* 303 */             if (match) {
/* 304 */               method = m[j];
/*     */               break;
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/* 310 */       if (method == null) {
/* 311 */         throw new ReflectException("No such method: " + methodName);
/*     */       }
/*     */ 
/*     */       
/* 315 */       Exception exc = null; 
/* 316 */       try { result = method.invoke(var, args); }
/* 317 */       catch (IllegalAccessException e) { exc = e = null; }
/* 318 */       catch (InvocationTargetException e) { exc = e = null; }
/* 319 */        if (exc != null) {
/* 320 */         LOGGER.debug("Cannot execute method: {}", methodName, exc);
/* 321 */         throw new ReflectException("Cannot execute method: " + methodName, exc);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 326 */     if (target != null) setVar(target, result); 
/* 327 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setVar(String varName, Object obj) {
/* 332 */     if (obj == null) { this.variables.remove(varName); }
/* 333 */     else { this.variables.put(varName, obj); }
/*     */   
/*     */   }
/*     */   
/*     */   public void setVar(String varName, boolean b) {
/* 338 */     setVar(varName, new Boolean(b));
/*     */   }
/*     */ 
/*     */   
/*     */   public void setVar(String varName, byte b) {
/* 343 */     setVar(varName, new Byte(b));
/*     */   }
/*     */ 
/*     */   
/*     */   public void setVar(String varName, char c) {
/* 348 */     setVar(varName, Character.valueOf(c));
/*     */   }
/*     */ 
/*     */   
/*     */   public void setVar(String varName, double d) {
/* 353 */     setVar(varName, new Double(d));
/*     */   }
/*     */ 
/*     */   
/*     */   public void setVar(String varName, float f) {
/* 358 */     setVar(varName, new Float(f));
/*     */   }
/*     */ 
/*     */   
/*     */   public void setVar(String varName, int i) {
/* 363 */     setVar(varName, Integer.valueOf(i));
/*     */   }
/*     */ 
/*     */   
/*     */   public void setVar(String varName, long l) {
/* 368 */     setVar(varName, Long.valueOf(l));
/*     */   }
/*     */ 
/*     */   
/*     */   public void setVar(String varName, short s) {
/* 373 */     setVar(varName, Short.valueOf(s));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getVar(String varName) throws ReflectException {
/* 381 */     if (varName.equals("null"))
/*     */     {
/* 383 */       return null;
/*     */     }
/* 385 */     if (varName.equals("true"))
/*     */     {
/* 387 */       return Boolean.TRUE;
/*     */     }
/* 389 */     if (varName.equals("false"))
/*     */     {
/* 391 */       return Boolean.FALSE;
/*     */     }
/* 393 */     if (varName.startsWith("\"") && varName.endsWith("\""))
/*     */     {
/* 395 */       return varName.substring(1, varName.length() - 1);
/*     */     }
/*     */     try {
/* 398 */       if (varName.matches("-?\\d+"))
/*     */       {
/* 400 */         return new Integer(varName);
/*     */       }
/* 402 */       if (varName.matches("-?\\d+L"))
/*     */       {
/* 404 */         return new Long(varName);
/*     */       }
/* 406 */       if (varName.matches("-?\\d*\\.\\d*"))
/*     */       {
/* 408 */         return new Double(varName);
/*     */       }
/*     */     }
/* 411 */     catch (NumberFormatException exc) {
/* 412 */       throw new ReflectException("Invalid literal: " + varName, exc);
/*     */     } 
/* 414 */     int dot = varName.indexOf(".");
/* 415 */     if (dot >= 0) {
/*     */       Field field; Object fieldVal;
/* 417 */       String className = varName.substring(0, dot).trim();
/* 418 */       Object object1 = this.variables.get(className);
/* 419 */       if (object1 == null) {
/* 420 */         throw new ReflectException("No such class: " + className);
/*     */       }
/* 422 */       Class<?> varClass = (object1 instanceof Class) ? (Class)object1 : object1.getClass();
/*     */       
/* 424 */       String fieldName = varName.substring(dot + 1).trim();
/*     */       
/*     */       try {
/* 427 */         field = varClass.getField(fieldName);
/* 428 */         if (this.force) field.setAccessible(true);
/*     */       
/* 430 */       } catch (NoSuchFieldException exc) {
/* 431 */         LOGGER.debug("No such field: {}", varName, exc);
/* 432 */         throw new ReflectException("No such field: " + varName, exc);
/*     */       } 
/*     */       try {
/* 435 */         fieldVal = field.get(object1);
/* 436 */       } catch (IllegalAccessException exc) {
/* 437 */         LOGGER.debug("Cannot get field value: {}", varName, exc);
/* 438 */         throw new ReflectException("Cannot get field value: " + varName, exc);
/*     */       } 
/* 440 */       return fieldVal;
/*     */     } 
/*     */     
/* 443 */     Object var = this.variables.get(varName);
/* 444 */     return var;
/*     */   }
/*     */   
/*     */   public void setAccessibilityIgnored(boolean ignore) {
/* 448 */     this.force = ignore;
/*     */   }
/*     */   public boolean isAccessibilityIgnored() {
/* 451 */     return this.force;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] args) throws IOException {
/* 459 */     ReflectedUniverse r = new ReflectedUniverse();
/* 460 */     System.out.println("Reflected universe test environment. Type commands, or press ^D to quit.");
/*     */     
/* 462 */     if (args.length > 0) {
/* 463 */       r.setAccessibilityIgnored(true);
/* 464 */       System.out.println("Ignoring accessibility modifiers.");
/*     */     } 
/* 466 */     BufferedReader in = new BufferedReader(new InputStreamReader(System.in, "UTF-8"));
/*     */     
/*     */     while (true) {
/* 469 */       System.out.print("> ");
/* 470 */       String line = in.readLine();
/* 471 */       if (line == null)
/* 472 */         break;  try { r.exec(line); }
/* 473 */       catch (ReflectException exc)
/* 474 */       { LOGGER.debug("Could not execute '{}'", line, exc); }
/*     */     
/*     */     } 
/* 477 */     System.out.println();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/common/ReflectedUniverse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */