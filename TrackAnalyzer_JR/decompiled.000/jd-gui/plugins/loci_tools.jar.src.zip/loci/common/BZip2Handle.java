/*     */ package loci.common;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BZip2Handle
/*     */   extends StreamHandle
/*     */ {
/*     */   public BZip2Handle(String file) throws IOException {
/*  67 */     this.file = file;
/*  68 */     if (!isBZip2File(file)) {
/*  69 */       throw new HandleException(file + " is not a BZip2 file.");
/*     */     }
/*     */     
/*  72 */     resetStream();
/*     */     
/*  74 */     this.length = 0L;
/*     */     while (true) {
/*  76 */       int skip = this.stream.skipBytes(1024);
/*  77 */       if (skip <= 0)
/*  78 */         break;  this.length += skip;
/*     */     } 
/*     */     
/*  81 */     resetStream();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isBZip2File(String file) throws IOException {
/*  88 */     if (!file.toLowerCase().endsWith(".bz2")) return false;
/*     */     
/*  90 */     FileInputStream s = new FileInputStream(file);
/*  91 */     byte[] b = new byte[2];
/*  92 */     s.read(b);
/*  93 */     s.close();
/*  94 */     return (new String(b, "UTF-8")).equals("BZ");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void resetStream() throws IOException {
/* 101 */     BufferedInputStream bis = new BufferedInputStream(new FileInputStream(this.file), 1048576);
/*     */     
/* 103 */     int skipped = 0;
/* 104 */     while (skipped < 2) {
/* 105 */       skipped = (int)(skipped + bis.skip((2 - skipped)));
/*     */     }
/* 107 */     this.stream = new DataInputStream(new CBZip2InputStream(bis));
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/common/BZip2Handle.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */