/*    */ package loci.common;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HandleException
/*    */   extends IOException
/*    */ {
/*    */   public HandleException() {}
/*    */   
/*    */   public HandleException(String s) {
/* 52 */     super(s);
/*    */   } public HandleException(String s, Throwable cause) {
/* 54 */     super(s);
/* 55 */     initCause(cause);
/*    */   }
/*    */   
/*    */   public HandleException(Throwable cause) {
/* 59 */     initCause(cause);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/common/HandleException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */