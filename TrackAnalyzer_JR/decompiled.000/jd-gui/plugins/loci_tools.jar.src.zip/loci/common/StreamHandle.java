/*     */ package loci.common;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.ByteOrder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class StreamHandle
/*     */   implements IRandomAccess
/*     */ {
/*     */   protected String file;
/*     */   protected DataInputStream stream;
/*     */   protected DataOutputStream outStream;
/*     */   protected long length;
/*  91 */   protected long fp = 0L;
/*  92 */   protected ByteOrder order = ByteOrder.BIG_ENDIAN;
/*     */ 
/*     */   
/*     */   protected long mark;
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/*  99 */     this.length = this.fp = this.mark = 0L;
/* 100 */     if (this.stream != null) this.stream.close(); 
/* 101 */     if (this.outStream != null) this.outStream.close(); 
/* 102 */     this.stream = null;
/* 103 */     this.outStream = null;
/* 104 */     this.file = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public long getFilePointer() throws IOException {
/* 109 */     return this.fp;
/*     */   }
/*     */ 
/*     */   
/*     */   public long length() throws IOException {
/* 114 */     return this.length;
/*     */   }
/*     */ 
/*     */   
/*     */   public int read(byte[] b) throws IOException {
/* 119 */     return read(b, 0, b.length);
/*     */   }
/*     */ 
/*     */   
/*     */   public int read(byte[] b, int off, int len) throws IOException {
/* 124 */     int n = this.stream.read(b, off, len);
/* 125 */     if (n >= 0) { this.fp += n; }
/* 126 */     else { n = 0; }
/* 127 */      markManager();
/* 128 */     while (n < len && this.fp < length()) {
/* 129 */       int s = this.stream.read(b, off + n, len - n);
/* 130 */       this.fp += s;
/* 131 */       n += s;
/*     */     } 
/* 133 */     return (n == -1) ? 0 : n;
/*     */   }
/*     */ 
/*     */   
/*     */   public int read(ByteBuffer buffer) throws IOException {
/* 138 */     return read(buffer, 0, buffer.capacity());
/*     */   }
/*     */ 
/*     */   
/*     */   public int read(ByteBuffer buffer, int off, int len) throws IOException {
/* 143 */     if (buffer.hasArray()) {
/* 144 */       return read(buffer.array(), off, len);
/*     */     }
/*     */     
/* 147 */     byte[] b = new byte[len];
/* 148 */     int n = read(b);
/* 149 */     buffer.put(b, off, len);
/* 150 */     return n;
/*     */   }
/*     */ 
/*     */   
/*     */   public void seek(long pos) throws IOException {
/* 155 */     long diff = pos - this.fp;
/* 156 */     this.fp = pos;
/*     */     
/* 158 */     if (diff < 0L) {
/* 159 */       resetStream();
/* 160 */       diff = this.fp;
/*     */     } 
/* 162 */     int skipped = this.stream.skipBytes((int)diff);
/* 163 */     while (skipped < diff) {
/* 164 */       int n = this.stream.skipBytes((int)(diff - skipped));
/* 165 */       if (n == 0)
/* 166 */         break;  skipped += n;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void write(ByteBuffer buf) throws IOException {
/* 172 */     write(buf, 0, buf.capacity());
/*     */   }
/*     */ 
/*     */   
/*     */   public void write(ByteBuffer buf, int off, int len) throws IOException {
/* 177 */     buf.position(off);
/* 178 */     if (buf.hasArray()) {
/* 179 */       write(buf.array(), off, len);
/*     */     } else {
/*     */       
/* 182 */       byte[] b = new byte[len];
/* 183 */       buf.get(b);
/* 184 */       write(b);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public ByteOrder getOrder() {
/* 190 */     return this.order;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setOrder(ByteOrder order) {
/* 195 */     this.order = order;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean readBoolean() throws IOException {
/* 202 */     this.fp++;
/* 203 */     return this.stream.readBoolean();
/*     */   }
/*     */ 
/*     */   
/*     */   public byte readByte() throws IOException {
/* 208 */     this.fp++;
/* 209 */     return this.stream.readByte();
/*     */   }
/*     */ 
/*     */   
/*     */   public char readChar() throws IOException {
/* 214 */     this.fp++;
/* 215 */     return this.stream.readChar();
/*     */   }
/*     */ 
/*     */   
/*     */   public double readDouble() throws IOException {
/* 220 */     this.fp += 8L;
/* 221 */     double v = this.stream.readDouble();
/* 222 */     return this.order.equals(ByteOrder.LITTLE_ENDIAN) ? DataTools.swap(v) : v;
/*     */   }
/*     */ 
/*     */   
/*     */   public float readFloat() throws IOException {
/* 227 */     this.fp += 4L;
/* 228 */     float v = this.stream.readFloat();
/* 229 */     return this.order.equals(ByteOrder.LITTLE_ENDIAN) ? DataTools.swap(v) : v;
/*     */   }
/*     */ 
/*     */   
/*     */   public void readFully(byte[] b) throws IOException {
/* 234 */     this.stream.readFully(b);
/* 235 */     this.fp += b.length;
/*     */   }
/*     */ 
/*     */   
/*     */   public void readFully(byte[] b, int off, int len) throws IOException {
/* 240 */     this.stream.readFully(b, off, len);
/* 241 */     this.fp += len;
/*     */   }
/*     */ 
/*     */   
/*     */   public int readInt() throws IOException {
/* 246 */     this.fp += 4L;
/* 247 */     int v = this.stream.readInt();
/* 248 */     return this.order.equals(ByteOrder.LITTLE_ENDIAN) ? DataTools.swap(v) : v;
/*     */   }
/*     */ 
/*     */   
/*     */   public String readLine() throws IOException {
/* 253 */     throw new IOException("Unimplemented");
/*     */   }
/*     */ 
/*     */   
/*     */   public long readLong() throws IOException {
/* 258 */     this.fp += 8L;
/* 259 */     long v = this.stream.readLong();
/* 260 */     return this.order.equals(ByteOrder.LITTLE_ENDIAN) ? DataTools.swap(v) : v;
/*     */   }
/*     */ 
/*     */   
/*     */   public short readShort() throws IOException {
/* 265 */     this.fp += 2L;
/* 266 */     short v = this.stream.readShort();
/* 267 */     return this.order.equals(ByteOrder.LITTLE_ENDIAN) ? DataTools.swap(v) : v;
/*     */   }
/*     */ 
/*     */   
/*     */   public int readUnsignedByte() throws IOException {
/* 272 */     this.fp++;
/* 273 */     return this.stream.readUnsignedByte();
/*     */   }
/*     */ 
/*     */   
/*     */   public int readUnsignedShort() throws IOException {
/* 278 */     return readShort() & 0xFFFF;
/*     */   }
/*     */ 
/*     */   
/*     */   public String readUTF() throws IOException {
/* 283 */     String s = this.stream.readUTF();
/* 284 */     this.fp += s.length();
/* 285 */     return s;
/*     */   }
/*     */ 
/*     */   
/*     */   public int skipBytes(int n) throws IOException {
/* 290 */     int skipped = 0;
/*     */     try {
/* 292 */       for (int i = 0; i < n; i++) {
/* 293 */         if (readUnsignedByte() != -1) skipped++; 
/* 294 */         markManager();
/*     */       }
/*     */     
/* 297 */     } catch (EOFException e) {}
/* 298 */     return skipped;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(byte[] b) throws IOException {
/* 305 */     if (this.outStream == null) {
/* 306 */       throw new HandleException("This stream is read-only.");
/*     */     }
/* 308 */     this.outStream.write(b);
/*     */   }
/*     */ 
/*     */   
/*     */   public void write(byte[] b, int off, int len) throws IOException {
/* 313 */     if (this.outStream == null) {
/* 314 */       throw new HandleException("This stream is read-only.");
/*     */     }
/* 316 */     this.outStream.write(b, off, len);
/*     */   }
/*     */ 
/*     */   
/*     */   public void write(int b) throws IOException {
/* 321 */     if (this.outStream == null) {
/* 322 */       throw new HandleException("This stream is read-only.");
/*     */     }
/* 324 */     if (this.order.equals(ByteOrder.LITTLE_ENDIAN)) b = DataTools.swap(b); 
/* 325 */     this.outStream.write(b);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeBoolean(boolean v) throws IOException {
/* 330 */     if (this.outStream == null) {
/* 331 */       throw new HandleException("This stream is read-only.");
/*     */     }
/* 333 */     this.outStream.writeBoolean(v);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeByte(int v) throws IOException {
/* 338 */     if (this.outStream == null) {
/* 339 */       throw new HandleException("This stream is read-only.");
/*     */     }
/* 341 */     if (this.order.equals(ByteOrder.LITTLE_ENDIAN)) v = DataTools.swap(v); 
/* 342 */     this.outStream.writeByte(v);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeBytes(String s) throws IOException {
/* 347 */     if (this.outStream == null) {
/* 348 */       throw new HandleException("This stream is read-only.");
/*     */     }
/* 350 */     this.outStream.writeBytes(s);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeChar(int v) throws IOException {
/* 355 */     if (this.outStream == null) {
/* 356 */       throw new HandleException("This stream is read-only.");
/*     */     }
/* 358 */     if (this.order.equals(ByteOrder.LITTLE_ENDIAN)) v = DataTools.swap(v); 
/* 359 */     this.outStream.writeChar(v);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeChars(String s) throws IOException {
/* 364 */     if (this.outStream == null) {
/* 365 */       throw new HandleException("This stream is read-only.");
/*     */     }
/* 367 */     this.outStream.writeChars(s);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeDouble(double v) throws IOException {
/* 372 */     if (this.outStream == null) {
/* 373 */       throw new HandleException("This stream is read-only.");
/*     */     }
/* 375 */     if (this.order.equals(ByteOrder.LITTLE_ENDIAN)) v = DataTools.swap(v); 
/* 376 */     this.outStream.writeDouble(v);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeFloat(float v) throws IOException {
/* 381 */     if (this.outStream == null) {
/* 382 */       throw new HandleException("This stream is read-only.");
/*     */     }
/* 384 */     if (this.order.equals(ByteOrder.LITTLE_ENDIAN)) v = DataTools.swap(v); 
/* 385 */     this.outStream.writeFloat(v);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeInt(int v) throws IOException {
/* 390 */     if (this.outStream == null) {
/* 391 */       throw new HandleException("This stream is read-only.");
/*     */     }
/* 393 */     if (this.order.equals(ByteOrder.LITTLE_ENDIAN)) v = DataTools.swap(v); 
/* 394 */     this.outStream.writeInt(v);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeLong(long v) throws IOException {
/* 399 */     if (this.outStream == null) {
/* 400 */       throw new HandleException("This stream is read-only.");
/*     */     }
/* 402 */     if (this.order.equals(ByteOrder.LITTLE_ENDIAN)) v = DataTools.swap(v); 
/* 403 */     this.outStream.writeLong(v);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeShort(int v) throws IOException {
/* 408 */     if (this.outStream == null) {
/* 409 */       throw new HandleException("This stream is read-only.");
/*     */     }
/* 411 */     if (this.order.equals(ByteOrder.LITTLE_ENDIAN)) v = DataTools.swap(v); 
/* 412 */     this.outStream.writeShort(v);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeUTF(String str) throws IOException {
/* 417 */     if (this.outStream == null) {
/* 418 */       throw new HandleException("This stream is read-only.");
/*     */     }
/* 420 */     this.outStream.writeUTF(str);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void resetStream() throws IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void markManager() {
/* 434 */     if (this.fp >= this.mark + 1048576L - 1L) {
/* 435 */       this.mark = this.fp;
/* 436 */       this.stream.mark(1048576);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/common/StreamHandle.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */