/*    */ package loci.common.enumeration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EnumException
/*    */   extends RuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = -4969429871517178079L;
/*    */   
/*    */   public EnumException() {}
/*    */   
/*    */   public EnumException(String s) {
/* 51 */     super(s);
/* 52 */   } public EnumException(String s, Throwable cause) { super(s, cause); } public EnumException(Throwable cause) {
/* 53 */     super(cause);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/common/enumeration/EnumException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */