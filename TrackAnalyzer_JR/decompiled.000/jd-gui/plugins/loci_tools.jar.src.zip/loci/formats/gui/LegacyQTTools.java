/*     */ package loci.formats.gui;
/*     */ 
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Image;
/*     */ import java.awt.Toolkit;
/*     */ import java.awt.image.DirectColorModel;
/*     */ import java.awt.image.MemoryImageSource;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.net.URLClassLoader;
/*     */ import java.util.StringTokenizer;
/*     */ import loci.common.Location;
/*     */ import loci.common.ReflectException;
/*     */ import loci.common.ReflectedUniverse;
/*     */ import loci.formats.FormatException;
/*     */ import loci.formats.MissingLibraryException;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LegacyQTTools
/*     */ {
/*  69 */   private static final Logger LOGGER = LoggerFactory.getLogger(LegacyQTTools.class);
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String NO_QT_MSG = "QuickTime for Java is required to read some QuickTime files. Please install QuickTime for Java from http://www.apple.com/quicktime/";
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String JVM_64BIT_MSG = "QuickTime for Java is not supported with a 64-bit JVM. Please invoke the 32-bit JVM (-d32) to utilize QTJava functionality.";
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String EXPIRED_QT_MSG = "Your version of QuickTime for Java has expired. Please reinstall QuickTime for Java from http://www.apple.com/quicktime/";
/*     */ 
/*     */   
/*  84 */   protected static final String[] SUFFIXES = new String[] { "mov", "qt" };
/*     */   
/*  86 */   protected static final boolean MAC_OS_X = System.getProperty("os.name").equals("Mac OS X");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  98 */   protected static final ClassLoader LOADER = constructLoader();
/*     */ 
/*     */   
/*     */   protected static ClassLoader constructLoader() {
/* 102 */     URL[] paths = null;
/*     */     
/* 104 */     if (MAC_OS_X) {
/*     */       try {
/* 106 */         paths = new URL[] { new URL("file:/System/Library/Java/Extensions/QTJava.zip") };
/*     */       }
/*     */       catch (MalformedURLException exc) {
/*     */         
/* 110 */         LOGGER.info("", exc);
/* 111 */       }  return (paths == null) ? null : new URLClassLoader(paths);
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 116 */       String windir = System.getProperty("java.library.path");
/* 117 */       StringTokenizer st = new StringTokenizer(windir, ";");
/*     */       
/* 119 */       while (st.hasMoreTokens()) {
/* 120 */         Location f = new Location(st.nextToken(), "QTJava.zip");
/* 121 */         if (f.exists()) {
/*     */           try {
/* 123 */             paths = new URL[] { f.toURL() };
/*     */           } catch (MalformedURLException exc) {
/* 125 */             LOGGER.info("", exc);
/* 126 */           }  return (paths == null) ? null : new URLClassLoader(paths);
/*     */         }
/*     */       
/*     */       } 
/* 130 */     } catch (SecurityException e) {
/*     */       
/* 132 */       LOGGER.warn("Cannot read value of 'java.library.path'", e);
/*     */     } 
/*     */     
/* 135 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean initialized = false;
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean noQT = false;
/*     */ 
/*     */   
/*     */   protected boolean jvm64Bit = false;
/*     */ 
/*     */   
/*     */   protected boolean expiredQT = false;
/*     */ 
/*     */   
/*     */   protected ReflectedUniverse r;
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initClass() {
/* 159 */     if (this.initialized)
/*     */       return; 
/* 161 */     String arch = System.getProperty("os.arch");
/* 162 */     if (arch != null && arch.indexOf("64") >= 0) {
/*     */       
/* 164 */       this.noQT = true;
/* 165 */       this.jvm64Bit = true;
/* 166 */       this.initialized = true;
/*     */       
/*     */       return;
/*     */     } 
/* 170 */     boolean needClose = false;
/* 171 */     this.r = new ReflectedUniverse(LOADER);
/*     */     try {
/* 173 */       this.r.exec("import quicktime.QTSession");
/* 174 */       this.r.exec("QTSession.open()");
/* 175 */       needClose = true;
/*     */ 
/*     */       
/* 178 */       this.r.exec("import quicktime.io.QTFile");
/* 179 */       this.r.exec("import quicktime.std.movies.Movie");
/*     */ 
/*     */       
/* 182 */       this.r.exec("import quicktime.app.view.MoviePlayer");
/* 183 */       this.r.exec("import quicktime.app.view.QTImageProducer");
/* 184 */       this.r.exec("import quicktime.io.OpenMovieFile");
/* 185 */       this.r.exec("import quicktime.qd.QDDimension");
/* 186 */       this.r.exec("import quicktime.std.StdQTConstants");
/* 187 */       this.r.exec("import quicktime.std.movies.TimeInfo");
/* 188 */       this.r.exec("import quicktime.std.movies.Track");
/*     */ 
/*     */       
/* 191 */       this.r.exec("import quicktime.qd.QDGraphics");
/* 192 */       this.r.exec("import quicktime.qd.QDRect");
/* 193 */       this.r.exec("import quicktime.std.image.CSequence");
/* 194 */       this.r.exec("import quicktime.std.image.CodecComponent");
/* 195 */       this.r.exec("import quicktime.std.image.ImageDescription");
/* 196 */       this.r.exec("import quicktime.std.movies.media.VideoMedia");
/* 197 */       this.r.exec("import quicktime.util.QTHandle");
/* 198 */       this.r.exec("import quicktime.util.RawEncodedImage");
/* 199 */       this.r.exec("import quicktime.util.EndianOrder");
/*     */     }
/* 201 */     catch (ExceptionInInitializerError err) {
/* 202 */       this.noQT = true;
/* 203 */       Throwable t = err.getException();
/* 204 */       if (t instanceof SecurityException) {
/* 205 */         SecurityException exc = (SecurityException)t;
/* 206 */         if (exc.getMessage().indexOf("expired") >= 0) this.expiredQT = true;
/*     */       
/*     */       } 
/* 209 */     } catch (Throwable t) {
/* 210 */       this.noQT = true;
/* 211 */       LOGGER.debug("Could not find QuickTime for Java", t);
/*     */     } finally {
/*     */       
/* 214 */       if (needClose) {
/* 215 */         try { this.r.exec("QTSession.close()"); }
/* 216 */         catch (Throwable t)
/* 217 */         { LOGGER.debug("Could not close QuickTime session", t); }
/*     */       
/*     */       }
/* 220 */       this.initialized = true;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canDoQT() {
/* 226 */     if (!this.initialized) initClass(); 
/* 227 */     return !this.noQT;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isJVM64Bit() {
/* 232 */     if (!this.initialized) initClass(); 
/* 233 */     return this.jvm64Bit;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isQTExpired() {
/* 238 */     if (!this.initialized) initClass(); 
/* 239 */     return this.expiredQT;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getQTVersion() {
/* 244 */     if (isJVM64Bit()) return "Not available"; 
/* 245 */     if (isQTExpired()) return "Expired"; 
/* 246 */     if (!canDoQT()) return "Missing";
/*     */     
/*     */     try {
/* 249 */       String qtMajor = this.r.exec("QTSession.getMajorVersion()").toString();
/* 250 */       String qtMinor = this.r.exec("QTSession.getMinorVersion()").toString();
/* 251 */       return qtMajor + "." + qtMinor;
/*     */     }
/* 253 */     catch (Throwable t) {
/* 254 */       LOGGER.debug("Could not retrieve QuickTime for Java version", t);
/* 255 */       return "Error";
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ReflectedUniverse getUniverse() {
/* 262 */     if (!this.initialized) initClass(); 
/* 263 */     return this.r;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Dimension getPictDimensions(byte[] bytes) throws FormatException, ReflectException {
/* 270 */     checkQTLibrary();
/*     */     try {
/* 272 */       this.r.exec("QTSession.open()");
/* 273 */       this.r.setVar("bytes", bytes);
/* 274 */       this.r.exec("pict = new Pict(bytes)");
/* 275 */       this.r.exec("box = pict.getPictFrame()");
/* 276 */       int width = ((Integer)this.r.exec("box.getWidth()")).intValue();
/* 277 */       int height = ((Integer)this.r.exec("box.getHeight()")).intValue();
/* 278 */       this.r.exec("QTSession.close()");
/* 279 */       return new Dimension(width, height);
/*     */     }
/* 281 */     catch (ReflectException e) {
/* 282 */       this.r.exec("QTSession.close()");
/* 283 */       throw new FormatException("PICT height determination failed", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized Image pictToImage(byte[] bytes) throws FormatException {
/* 291 */     checkQTLibrary();
/*     */     
/* 293 */     try { this.r.exec("QTSession.open()");
/*     */ 
/*     */ 
/*     */       
/* 297 */       this.r.setVar("bytes", bytes);
/* 298 */       this.r.exec("pict = new Pict(bytes)");
/* 299 */       this.r.exec("box = pict.getPictFrame()");
/* 300 */       int width = ((Integer)this.r.exec("box.getWidth()")).intValue();
/* 301 */       int height = ((Integer)this.r.exec("box.getHeight()")).intValue();
/*     */ 
/*     */       
/* 304 */       this.r.exec("g = new QDGraphics(box)");
/* 305 */       this.r.exec("pict.draw(g, box)");
/*     */       
/* 307 */       this.r.exec("pixMap = g.getPixMap()");
/* 308 */       this.r.exec("rei = pixMap.getPixelData()");
/*     */ 
/*     */       
/* 311 */       int rowBytes = ((Integer)this.r.exec("pixMap.getRowBytes()")).intValue();
/* 312 */       int intsPerRow = rowBytes / 4;
/* 313 */       int pixLen = intsPerRow * height;
/* 314 */       this.r.setVar("pixLen", pixLen);
/* 315 */       int[] pixels = new int[pixLen];
/* 316 */       this.r.setVar("pixels", pixels);
/* 317 */       this.r.setVar("zero", new Integer(0));
/* 318 */       this.r.exec("rei.copyToArray(zero, pixels, zero, pixLen)");
/*     */ 
/*     */       
/* 321 */       int bitsPerSample = 32;
/* 322 */       int redMask = 16711680;
/* 323 */       int greenMask = 65280;
/* 324 */       int blueMask = 255;
/* 325 */       int alphaMask = 0;
/* 326 */       DirectColorModel colorModel = new DirectColorModel(bitsPerSample, redMask, greenMask, blueMask, alphaMask);
/*     */ 
/*     */       
/* 329 */       this.r.exec("QTSession.close()");
/* 330 */       return Toolkit.getDefaultToolkit().createImage(new MemoryImageSource(width, height, colorModel, pixels, 0, intsPerRow));
/*     */        }
/*     */     
/* 333 */     catch (ReflectException e) { try {
/* 334 */         this.r.exec("QTSession.close()");
/* 335 */       } catch (ReflectException exc) {
/* 336 */         LOGGER.info("Could not close QuickTime session", (Throwable)exc);
/*     */       } 
/* 338 */       throw new FormatException("PICT extraction failed", e); }
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   public void checkQTLibrary() throws MissingLibraryException {
/* 344 */     if (isJVM64Bit()) throw new MissingLibraryException("QuickTime for Java is not supported with a 64-bit JVM. Please invoke the 32-bit JVM (-d32) to utilize QTJava functionality."); 
/* 345 */     if (isQTExpired()) throw new MissingLibraryException("Your version of QuickTime for Java has expired. Please reinstall QuickTime for Java from http://www.apple.com/quicktime/"); 
/* 346 */     if (!canDoQT()) throw new MissingLibraryException("QuickTime for Java is required to read some QuickTime files. Please install QuickTime for Java from http://www.apple.com/quicktime/"); 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/gui/LegacyQTTools.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */