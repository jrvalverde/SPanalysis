/*     */ package loci.formats.gui;
/*     */ 
/*     */ import java.awt.image.ColorModel;
/*     */ import java.awt.image.Raster;
/*     */ import java.awt.image.WritableRaster;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Index16ColorModel
/*     */   extends ColorModel
/*     */ {
/*     */   private short[] redShort;
/*     */   private short[] greenShort;
/*     */   private short[] blueShort;
/*     */   private short[] alphaShort;
/*     */   private int pixelBits;
/*     */   
/*     */   public Index16ColorModel(int bits, int size, short[][] table, boolean littleEndian) throws IOException {
/*  68 */     super(bits);
/*     */     
/*  70 */     if (table == null) throw new IOException("LUT cannot be null"); 
/*  71 */     for (int i = 0; i < table.length; i++) {
/*  72 */       if ((table[i]).length < size) {
/*  73 */         throw new IOException("LUT " + i + " too small");
/*     */       }
/*     */     } 
/*     */     
/*  77 */     if (table.length > 0) this.redShort = table[0]; 
/*  78 */     if (table.length > 1) this.greenShort = table[1]; 
/*  79 */     if (table.length > 2) this.blueShort = table[2]; 
/*  80 */     if (table.length > 3) this.alphaShort = table[3]; 
/*  81 */     this.pixelBits = bits;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public short[] getReds() {
/*  88 */     return this.redShort;
/*     */   }
/*     */ 
/*     */   
/*     */   public short[] getGreens() {
/*  93 */     return this.greenShort;
/*     */   }
/*     */ 
/*     */   
/*     */   public short[] getBlues() {
/*  98 */     return this.blueShort;
/*     */   }
/*     */ 
/*     */   
/*     */   public short[] getAlphas() {
/* 103 */     return this.alphaShort;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized Object getDataElements(int rgb, Object pixel) {
/* 110 */     int red = rgb >> 16 & 0xFF;
/* 111 */     int green = rgb >> 8 & 0xFF;
/* 112 */     int blue = rgb & 0xFF;
/*     */ 
/*     */     
/* 115 */     short[] p = (pixel == null) ? new short[3] : (short[])pixel;
/* 116 */     p[0] = (short)red;
/* 117 */     p[1] = (short)green;
/* 118 */     p[2] = (short)blue;
/* 119 */     return p;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isCompatibleRaster(Raster raster) {
/* 124 */     return (raster.getNumBands() == 1);
/*     */   }
/*     */ 
/*     */   
/*     */   public WritableRaster createCompatibleWritableRaster(int w, int h) {
/* 129 */     return Raster.createInterleavedRaster(1, w, h, 1, null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getAlpha(int pixel) {
/* 135 */     if (this.alphaShort != null) {
/* 136 */       return (int)((this.alphaShort[pixel] & 0xFFFF) / 65535.0D * 255.0D);
/*     */     }
/* 138 */     return 255;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getBlue(int pixel) {
/* 143 */     if (this.blueShort == null) return 0; 
/* 144 */     int blue = this.blueShort[pixel] & 0xFFFF;
/* 145 */     return (int)(blue / 65535.0D * 255.0D);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getGreen(int pixel) {
/* 150 */     if (this.greenShort == null) return 0; 
/* 151 */     int green = this.greenShort[pixel] & 0xFFFF;
/* 152 */     return (int)(green / 65535.0D * 255.0D);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getRed(int pixel) {
/* 157 */     if (this.redShort == null) return 0; 
/* 158 */     int red = this.redShort[pixel] & 0xFFFF;
/* 159 */     return (int)(red / 65535.0D * 255.0D);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/gui/Index16ColorModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */