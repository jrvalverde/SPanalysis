/*     */ package loci.formats.gui;
/*     */ 
/*     */ import java.awt.image.DataBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UnsignedIntBuffer
/*     */   extends DataBuffer
/*     */ {
/*     */   private int[][] bankData;
/*     */   
/*     */   public UnsignedIntBuffer(int[] dataArray, int size) {
/*  56 */     super(3, size);
/*  57 */     this.bankData = new int[1][];
/*  58 */     this.bankData[0] = dataArray;
/*     */   }
/*     */ 
/*     */   
/*     */   public UnsignedIntBuffer(int[][] dataArray, int size) {
/*  63 */     super(3, size);
/*  64 */     this.bankData = dataArray;
/*     */   }
/*     */ 
/*     */   
/*     */   public int[] getData() {
/*  69 */     return this.bankData[0];
/*     */   }
/*     */ 
/*     */   
/*     */   public int[] getData(int bank) {
/*  74 */     return this.bankData[bank];
/*     */   }
/*     */ 
/*     */   
/*     */   public int getElem(int i) {
/*  79 */     return getElem(0, i);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getElem(int bank, int i) {
/*  84 */     int value = this.bankData[bank][i + getOffsets()[bank]];
/*  85 */     return (int)(value & 0xFFFFFFFFL);
/*     */   }
/*     */ 
/*     */   
/*     */   public float getElemFloat(int i) {
/*  90 */     return getElemFloat(0, i);
/*     */   }
/*     */ 
/*     */   
/*     */   public float getElemFloat(int bank, int i) {
/*  95 */     return (float)(getElem(bank, i) & 0xFFFFFFFFL);
/*     */   }
/*     */ 
/*     */   
/*     */   public double getElemDouble(int i) {
/* 100 */     return getElemDouble(0, i);
/*     */   }
/*     */ 
/*     */   
/*     */   public double getElemDouble(int bank, int i) {
/* 105 */     return (getElem(bank, i) & 0xFFFFFFFFL);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setElem(int i, int val) {
/* 110 */     setElem(0, i, val);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setElem(int bank, int i, int val) {
/* 115 */     this.bankData[bank][i + getOffsets()[bank]] = val;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setElemFloat(int i, float val) {
/* 120 */     setElemFloat(0, i, val);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setElemFloat(int bank, int i, float val) {
/* 125 */     this.bankData[bank][i + getOffsets()[bank]] = (int)val;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setElemDouble(int i, double val) {
/* 130 */     setElemDouble(0, i, val);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setElemDouble(int bank, int i, double val) {
/* 135 */     this.bankData[bank][i + getOffsets()[bank]] = (int)val;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/gui/UnsignedIntBuffer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */