/*     */ package loci.formats.gui;
/*     */ 
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.geom.Rectangle2D;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.beans.PropertyChangeEvent;
/*     */ import java.beans.PropertyChangeListener;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import javax.swing.Box;
/*     */ import javax.swing.BoxLayout;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JFileChooser;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.SwingUtilities;
/*     */ import javax.swing.border.EmptyBorder;
/*     */ import loci.formats.FormatException;
/*     */ import loci.formats.FormatTools;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PreviewPane
/*     */   extends JPanel
/*     */   implements PropertyChangeListener, Runnable
/*     */ {
/*  78 */   private static final Logger LOGGER = LoggerFactory.getLogger(PreviewPane.class);
/*     */   
/*     */   protected BufferedImageReader reader;
/*     */   
/*     */   protected String loadId;
/*     */   
/*     */   protected String lastId;
/*     */   
/*     */   protected Thread loader;
/*     */   
/*     */   protected boolean loaderAlive;
/*     */   
/*     */   protected Runnable refresher;
/*     */   
/*     */   protected JLabel iconLabel;
/*     */   
/*     */   protected JLabel formatLabel;
/*     */   
/*     */   protected JLabel resLabel;
/*     */   
/*     */   protected JLabel zctLabel;
/*     */   
/*     */   protected JLabel typeLabel;
/*     */   
/*     */   protected ImageIcon icon;
/*     */   
/*     */   protected String iconText;
/*     */   
/*     */   protected String formatText;
/*     */   
/*     */   protected String resText;
/*     */   protected String zctText;
/*     */   protected String typeText;
/*     */   protected String iconTip;
/*     */   protected String formatTip;
/*     */   protected String resTip;
/*     */   protected String zctTip;
/*     */   protected String typeTip;
/*     */   
/*     */   public PreviewPane(JFileChooser jc) {
/* 118 */     this.reader = new BufferedImageReader();
/* 119 */     this.reader.setNormalized(true);
/*     */ 
/*     */     
/* 122 */     setBorder(new EmptyBorder(0, 10, 0, 10));
/* 123 */     setLayout(new BoxLayout(this, 1));
/* 124 */     this.iconLabel = new JLabel();
/* 125 */     this.iconLabel.setMinimumSize(new Dimension(128, -1));
/* 126 */     this.iconLabel.setAlignmentX(0.5F);
/* 127 */     add(this.iconLabel);
/* 128 */     add(Box.createVerticalStrut(7));
/* 129 */     this.formatLabel = new JLabel();
/* 130 */     this.formatLabel.setAlignmentX(0.5F);
/* 131 */     add(this.formatLabel);
/* 132 */     add(Box.createVerticalStrut(5));
/* 133 */     this.resLabel = new JLabel();
/* 134 */     this.resLabel.setAlignmentX(0.5F);
/* 135 */     add(this.resLabel);
/* 136 */     this.zctLabel = new JLabel();
/* 137 */     this.zctLabel.setAlignmentX(0.5F);
/* 138 */     add(this.zctLabel);
/* 139 */     this.typeLabel = new JLabel();
/* 140 */     this.typeLabel.setAlignmentX(0.5F);
/* 141 */     add(this.typeLabel);
/*     */ 
/*     */     
/* 144 */     Font font = this.formatLabel.getFont();
/* 145 */     font = font.deriveFont(font.getSize2D() - 3.0F);
/* 146 */     this.formatLabel.setFont(font);
/* 147 */     this.resLabel.setFont(font);
/* 148 */     this.zctLabel.setFont(font);
/* 149 */     this.typeLabel.setFont(font);
/*     */ 
/*     */     
/* 152 */     this.icon = null;
/* 153 */     this.iconText = this.formatText = this.resText = this.zctText = this.typeText = "";
/* 154 */     this.iconTip = this.formatTip = this.resTip = this.zctTip = this.typeTip = null;
/*     */     
/* 156 */     if (jc != null) {
/* 157 */       jc.setAccessory(this);
/* 158 */       jc.addPropertyChangeListener(this);
/*     */       
/* 160 */       this.refresher = new Runnable() {
/*     */           public void run() {
/* 162 */             PreviewPane.this.iconLabel.setIcon(PreviewPane.this.icon);
/* 163 */             PreviewPane.this.iconLabel.setText(PreviewPane.this.iconText);
/* 164 */             PreviewPane.this.iconLabel.setToolTipText(PreviewPane.this.iconTip);
/* 165 */             PreviewPane.this.formatLabel.setText(PreviewPane.this.formatText);
/* 166 */             PreviewPane.this.formatLabel.setToolTipText(PreviewPane.this.formatTip);
/* 167 */             PreviewPane.this.resLabel.setText(PreviewPane.this.resText);
/* 168 */             PreviewPane.this.resLabel.setToolTipText(PreviewPane.this.resTip);
/* 169 */             PreviewPane.this.zctLabel.setText(PreviewPane.this.zctText);
/* 170 */             PreviewPane.this.zctLabel.setToolTipText(PreviewPane.this.zctTip);
/* 171 */             PreviewPane.this.typeLabel.setText(PreviewPane.this.typeText);
/* 172 */             PreviewPane.this.typeLabel.setToolTipText(PreviewPane.this.typeTip);
/*     */           }
/*     */         };
/*     */ 
/*     */       
/* 177 */       this.loaderAlive = true;
/* 178 */       this.loader = new Thread(this, "Preview");
/* 179 */       this.loader.start();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Dimension getPreferredSize() {
/* 187 */     Dimension prefSize = super.getPreferredSize();
/* 188 */     return new Dimension(148, prefSize.height);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void propertyChange(PropertyChangeEvent e) {
/* 198 */     String prop = e.getPropertyName();
/* 199 */     if (prop.equals("JFileChooserDialogIsClosingProperty"))
/*     */     {
/* 201 */       this.loaderAlive = false;
/*     */     }
/*     */     
/* 204 */     if (!prop.equals("SelectedFileChangedProperty"))
/*     */       return; 
/* 206 */     File f = (File)e.getNewValue();
/* 207 */     if (f != null && (f.isDirectory() || !f.exists())) f = null;
/*     */     
/* 209 */     this.loadId = (f == null) ? null : f.getAbsolutePath();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run() {
/* 216 */     while (this.loaderAlive) { 
/* 217 */       try { Thread.sleep(100L); }
/* 218 */       catch (InterruptedException exc) { LOGGER.info("", exc); }
/*     */       
/*     */       try {
/* 221 */         String id = this.loadId;
/* 222 */         if (id == this.lastId)
/* 223 */           continue;  if (id != null && this.lastId != null) {
/* 224 */           String[] files = this.reader.getUsedFiles();
/* 225 */           boolean found = false;
/* 226 */           for (int i = 0; i < files.length; i++) {
/* 227 */             if (id.equals(files[i])) {
/* 228 */               found = true;
/* 229 */               this.lastId = id;
/*     */               break;
/*     */             } 
/*     */           } 
/* 233 */           if (found)
/*     */             continue; 
/* 235 */         }  this.lastId = id;
/*     */         
/* 237 */         this.icon = null;
/* 238 */         this.iconText = (id == null) ? "" : "Reading...";
/* 239 */         this.formatText = this.resText = this.zctText = this.typeText = "";
/* 240 */         this.iconTip = id;
/* 241 */         this.formatTip = this.resTip = this.zctTip = this.typeTip = "";
/*     */         
/* 243 */         if (id == null) {
/* 244 */           SwingUtilities.invokeLater(this.refresher);
/*     */           continue;
/*     */         } 
/*     */         try {
/* 248 */           this.reader.setId(id);
/* 249 */         } catch (FormatException exc) {
/* 250 */           LOGGER.debug("Failed to initialize {}", id, exc);
/* 251 */           boolean badFormat = exc.getMessage().startsWith("Unknown file format");
/*     */           
/* 253 */           this.iconText = "Unsupported " + (badFormat ? "format" : "file");
/* 254 */           this.formatText = this.resText = "";
/* 255 */           SwingUtilities.invokeLater(this.refresher);
/* 256 */           this.lastId = null;
/*     */           
/*     */           continue;
/* 259 */         } catch (IOException exc) {
/* 260 */           LOGGER.debug("Failed to initialize {}", id, exc);
/* 261 */           this.iconText = "Unsupported file";
/* 262 */           this.formatText = this.resText = "";
/* 263 */           SwingUtilities.invokeLater(this.refresher);
/* 264 */           this.lastId = null;
/*     */           continue;
/*     */         } 
/* 267 */         if (id != this.loadId) {
/* 268 */           SwingUtilities.invokeLater(this.refresher);
/*     */           
/*     */           continue;
/*     */         } 
/* 272 */         this.icon = new ImageIcon(makeImage("Loading..."));
/* 273 */         this.iconText = "";
/* 274 */         String format = this.reader.getFormat();
/* 275 */         this.formatText = format;
/* 276 */         this.formatTip = format;
/* 277 */         this.resText = this.reader.getSizeX() + " x " + this.reader.getSizeY();
/* 278 */         this.zctText = this.reader.getSizeZ() + "Z x " + this.reader.getSizeT() + "T x " + this.reader.getSizeC() + "C";
/*     */         
/* 280 */         this.typeText = this.reader.getRGBChannelCount() + " x " + FormatTools.getPixelTypeString(this.reader.getPixelType());
/*     */         
/* 282 */         SwingUtilities.invokeLater(this.refresher);
/*     */ 
/*     */         
/* 285 */         int z = this.reader.getSizeZ() / 2;
/* 286 */         int t = this.reader.getSizeT() / 2;
/* 287 */         int ndx = this.reader.getIndex(z, 0, t);
/* 288 */         BufferedImage thumb = null; try {
/* 289 */           thumb = this.reader.openThumbImage(ndx);
/* 290 */         } catch (FormatException exc) {
/* 291 */           LOGGER.debug("Failed to read thumbnail #{} from {}", new Object[] { Integer.valueOf(ndx), id }, exc);
/*     */         
/*     */         }
/* 294 */         catch (IOException exc) {
/* 295 */           LOGGER.debug("Failed to read thumbnail #{} from {}", new Object[] { Integer.valueOf(ndx), id }, exc);
/*     */         } 
/*     */         
/* 298 */         this.icon = new ImageIcon((thumb == null) ? makeImage("Failed") : thumb);
/* 299 */         this.iconText = "";
/*     */         
/* 301 */         SwingUtilities.invokeLater(this.refresher);
/*     */       }
/* 303 */       catch (Exception exc) {
/* 304 */         LOGGER.info("", exc);
/* 305 */         this.icon = null;
/* 306 */         this.iconText = "Thumbnail failure";
/* 307 */         this.formatText = this.resText = this.zctText = this.typeText = "";
/* 308 */         this.iconTip = this.loadId;
/* 309 */         this.formatTip = this.resTip = this.zctTip = this.typeTip = "";
/* 310 */         SwingUtilities.invokeLater(this.refresher);
/*     */       }  }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 319 */     if (this.reader != null) {
/* 320 */       this.reader.close();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private BufferedImage makeImage(String message) {
/* 332 */     int w = this.reader.getThumbSizeX(), h = this.reader.getThumbSizeY();
/* 333 */     if (w < 128) w = 128; 
/* 334 */     if (h < 32) h = 32; 
/* 335 */     BufferedImage image = new BufferedImage(w, h, 1);
/* 336 */     Graphics2D g = image.createGraphics();
/* 337 */     Rectangle2D.Float r = (Rectangle2D.Float)g.getFont().getStringBounds(message, g.getFontRenderContext());
/*     */     
/* 339 */     g.drawString(message, (w - r.width) / 2.0F, (h - r.height) / 2.0F + r.height);
/* 340 */     g.dispose();
/* 341 */     return image;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/gui/PreviewPane.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */