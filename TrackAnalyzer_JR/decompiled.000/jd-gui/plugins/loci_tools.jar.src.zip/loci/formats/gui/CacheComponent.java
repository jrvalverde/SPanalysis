/*     */ package loci.formats.gui;
/*     */ 
/*     */ import com.jgoodies.forms.layout.CellConstraints;
/*     */ import com.jgoodies.forms.layout.FormLayout;
/*     */ import java.awt.LayoutManager;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import javax.swing.Box;
/*     */ import javax.swing.BoxLayout;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JSpinner;
/*     */ import javax.swing.SpinnerNumberModel;
/*     */ import javax.swing.event.ChangeEvent;
/*     */ import javax.swing.event.ChangeListener;
/*     */ import loci.formats.cache.ByteArraySource;
/*     */ import loci.formats.cache.Cache;
/*     */ import loci.formats.cache.CacheEvent;
/*     */ import loci.formats.cache.CacheException;
/*     */ import loci.formats.cache.CacheListener;
/*     */ import loci.formats.cache.CrosshairStrategy;
/*     */ import loci.formats.cache.ICacheSource;
/*     */ import loci.formats.cache.ICacheStrategy;
/*     */ import loci.formats.cache.RectangleStrategy;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CacheComponent
/*     */   extends JPanel
/*     */   implements ActionListener, CacheListener, ChangeListener
/*     */ {
/*  83 */   private static final Logger LOGGER = LoggerFactory.getLogger(CacheComponent.class);
/*     */ 
/*     */   
/*  86 */   protected static final String[] SOURCES = new String[] { "Byte arrays", "BufferedImages" };
/*  87 */   protected static final Class[] SOURCE_VALUES = new Class[] { ByteArraySource.class, BufferedImageSource.class };
/*     */ 
/*     */ 
/*     */   
/*  91 */   protected static final Class[] SOURCE_PARAMS = new Class[] { String.class };
/*  92 */   protected static final String[] STRATEGIES = new String[] { "Crosshair", "Rectangle" };
/*  93 */   protected static final Class[] STRATEGY_VALUES = new Class[] { CrosshairStrategy.class, RectangleStrategy.class };
/*     */ 
/*     */ 
/*     */   
/*  97 */   protected static final Class[] STRATEGY_PARAMS = new Class[] { int[].class };
/*     */   
/*  99 */   protected static final String[] PRIORITIES = new String[] { "Maximum", "High", "Normal", "Low", "Minimum" };
/*     */   
/* 101 */   protected static final int[] PRIORITY_VALUES = new int[] { 10, 5, 0, -5, -10 };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 106 */   protected static final String[] ORDERS = new String[] { "Centered", "Forward", "Backward" };
/* 107 */   protected static final int[] ORDER_VALUES = new int[] { 0, 1, -1 };
/*     */ 
/*     */ 
/*     */   
/*     */   private Cache cache;
/*     */ 
/*     */ 
/*     */   
/*     */   private JComboBox sourceChooser;
/*     */ 
/*     */ 
/*     */   
/*     */   private JComboBox strategyChooser;
/*     */ 
/*     */ 
/*     */   
/*     */   private JSpinner[] range;
/*     */ 
/*     */ 
/*     */   
/*     */   private JComboBox[] priority;
/*     */ 
/*     */ 
/*     */   
/*     */   private JComboBox[] order;
/*     */ 
/*     */ 
/*     */   
/*     */   private String id;
/*     */ 
/*     */   
/*     */   private int[] lengths;
/*     */ 
/*     */ 
/*     */   
/*     */   public CacheComponent(Cache cache, String[] axisLabels) {
/* 143 */     this(cache, axisLabels, (String)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CacheComponent(Cache cache, String[] axisLabels, String id) {
/* 152 */     this.cache = cache;
/* 153 */     this.id = id;
/* 154 */     this.lengths = cache.getStrategy().getLengths();
/*     */     
/* 156 */     setLayout(new BoxLayout(this, 1));
/*     */     
/* 158 */     CellConstraints cc = new CellConstraints();
/*     */     
/* 160 */     JPanel top = new JPanel();
/* 161 */     FormLayout layout = new FormLayout("pref,3dlu,pref:grow", (id == null) ? "pref:grow" : "pref:grow,3dlu,pref:grow");
/*     */     
/* 163 */     top.setLayout((LayoutManager)layout);
/*     */     
/* 165 */     int col = 1, row = 1;
/*     */ 
/*     */     
/* 168 */     if (id != null) {
/* 169 */       JLabel jLabel = new JLabel("Objects to cache: ");
/* 170 */       this.sourceChooser = new JComboBox<String>(SOURCES);
/* 171 */       this.sourceChooser.setSelectedIndex(sourceIndex(cache.getSource()));
/* 172 */       this.sourceChooser.setActionCommand("source");
/* 173 */       this.sourceChooser.addActionListener(this);
/*     */       
/* 175 */       col = 1;
/* 176 */       top.add(jLabel, cc.xy(col, row));
/* 177 */       col += 2;
/* 178 */       top.add(this.sourceChooser, cc.xy(col, row));
/* 179 */       row += 2;
/*     */     } 
/*     */     
/* 182 */     ICacheStrategy strategy = cache.getStrategy();
/*     */ 
/*     */     
/* 185 */     JLabel label = new JLabel("Caching strategy: ");
/* 186 */     this.strategyChooser = new JComboBox<String>(STRATEGIES);
/* 187 */     this.strategyChooser.setSelectedIndex(strategyIndex(strategy));
/* 188 */     this.strategyChooser.setActionCommand("strategy");
/* 189 */     this.strategyChooser.addActionListener(this);
/*     */     
/* 191 */     col = 1;
/* 192 */     top.add(label, cc.xy(col, row));
/* 193 */     col += 2;
/* 194 */     top.add(this.strategyChooser, cc.xy(col, row));
/* 195 */     row += 2;
/*     */     
/* 197 */     JPanel bottom = new JPanel();
/* 198 */     StringBuffer rows = new StringBuffer();
/* 199 */     rows.append("pref:grow");
/* 200 */     for (int i = 0; i < axisLabels.length; ) { rows.append(",3dlu,pref:grow"); i++; }
/* 201 */      layout = new FormLayout("pref:grow,3dlu,pref:grow,3dlu,pref:grow,3dlu,pref:grow", rows.toString());
/*     */ 
/*     */     
/* 204 */     bottom.setLayout((LayoutManager)layout);
/*     */ 
/*     */     
/* 207 */     col = row = 1;
/* 208 */     bottom.add(new JLabel("Axis"), cc.xy(col, row));
/* 209 */     col += 2;
/* 210 */     bottom.add(new JLabel("Range"), cc.xy(col, row));
/* 211 */     col += 2;
/* 212 */     bottom.add(new JLabel("Priority"), cc.xy(col, row));
/* 213 */     col += 2;
/* 214 */     bottom.add(new JLabel("Order"), cc.xy(col, row));
/* 215 */     row += 2;
/*     */     
/* 217 */     this.range = new JSpinner[this.lengths.length];
/* 218 */     this.priority = new JComboBox[this.lengths.length];
/* 219 */     this.order = new JComboBox[this.lengths.length];
/*     */     
/* 221 */     int[] rng = strategy.getRange();
/* 222 */     int[] prio = strategy.getPriorities();
/* 223 */     int[] ord = strategy.getOrder();
/* 224 */     for (int j = 0; j < axisLabels.length; j++) {
/* 225 */       JLabel l = new JLabel(axisLabels[j]);
/* 226 */       this.range[j] = new JSpinner(new SpinnerNumberModel(rng[j], 0, this.lengths[j], 1));
/* 227 */       this.priority[j] = new JComboBox<String>(PRIORITIES);
/* 228 */       this.priority[j].setSelectedIndex(priorityIndex(prio[j]));
/* 229 */       this.order[j] = new JComboBox<String>(ORDERS);
/* 230 */       this.order[j].setSelectedIndex(orderIndex(ord[j]));
/*     */       
/* 232 */       col = 1;
/* 233 */       bottom.add(l, cc.xy(col, row));
/* 234 */       col += 2;
/* 235 */       bottom.add(this.range[j], cc.xy(col, row));
/* 236 */       col += 2;
/* 237 */       bottom.add(this.priority[j], cc.xy(col, row));
/* 238 */       col += 2;
/* 239 */       bottom.add(this.order[j], cc.xy(col, row));
/* 240 */       row += 2;
/*     */       
/* 242 */       this.range[j].addChangeListener(this);
/* 243 */       this.priority[j].addActionListener(this);
/* 244 */       this.order[j].addActionListener(this);
/*     */     } 
/*     */     
/* 247 */     add(top);
/* 248 */     add(Box.createVerticalStrut(9));
/* 249 */     add(bottom);
/*     */     
/* 251 */     cache.addCacheListener(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public Cache getCache() {
/* 256 */     return this.cache;
/*     */   }
/*     */   public void dispose() {
/* 259 */     this.cache.removeCacheListener(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void actionPerformed(ActionEvent e) {
/* 266 */     String cmd = e.getActionCommand();
/* 267 */     if ("source".equals(cmd)) { updateSource(); }
/* 268 */     else if ("strategy".equals(cmd)) { updateStrategy(); }
/*     */     else
/* 270 */     { Object src = e.getSource(); int i;
/* 271 */       for (i = 0; i < this.priority.length; i++) {
/* 272 */         if (src == this.priority[i]) {
/* 273 */           updatePriority(i);
/*     */           return;
/*     */         } 
/*     */       } 
/* 277 */       for (i = 0; i < this.order.length; i++) {
/* 278 */         if (src == this.order[i]) {
/* 279 */           updateOrder(i);
/*     */           return;
/*     */         } 
/*     */       }  }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void cacheUpdated(CacheEvent e) {
/* 290 */     int prio[], i, ord[], j, rng[], k, type = e.getType();
/* 291 */     ICacheStrategy strategy = this.cache.getStrategy();
/* 292 */     switch (type) {
/*     */       case 1:
/* 294 */         this.sourceChooser.removeActionListener(this);
/* 295 */         this.sourceChooser.setSelectedIndex(sourceIndex(this.cache.getSource()));
/* 296 */         this.sourceChooser.addActionListener(this);
/*     */         break;
/*     */       case 2:
/* 299 */         this.strategyChooser.removeActionListener(this);
/* 300 */         this.strategyChooser.setSelectedIndex(strategyIndex(strategy));
/* 301 */         this.strategyChooser.addActionListener(this);
/*     */         break;
/*     */       case 4:
/* 304 */         prio = strategy.getPriorities();
/* 305 */         for (i = 0; i < prio.length; i++) {
/* 306 */           this.priority[i].removeActionListener(this);
/* 307 */           this.priority[i].setSelectedIndex(priorityIndex(prio[i]));
/* 308 */           this.priority[i].addActionListener(this);
/*     */         } 
/*     */         break;
/*     */       case 5:
/* 312 */         ord = strategy.getOrder();
/* 313 */         for (j = 0; j < ord.length; j++) {
/* 314 */           this.order[j].removeActionListener(this);
/* 315 */           this.order[j].setSelectedIndex(orderIndex(ord[j]));
/* 316 */           this.order[j].addActionListener(this);
/*     */         } 
/*     */         break;
/*     */       case 6:
/* 320 */         rng = strategy.getRange();
/* 321 */         for (k = 0; k < rng.length; k++) {
/* 322 */           this.range[k].removeChangeListener(this);
/* 323 */           this.range[k].setValue(new Integer(rng[k]));
/* 324 */           this.range[k].addChangeListener(this);
/*     */         } 
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void stateChanged(ChangeEvent e) {
/* 334 */     Object src = e.getSource();
/* 335 */     for (int i = 0; i < this.range.length; i++) {
/* 336 */       if (src == this.range[i]) {
/* 337 */         updateRange(i);
/*     */         return;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateSource() {
/*     */     try {
/* 348 */       ICacheSource source = sourceValue(this.sourceChooser.getSelectedIndex());
/* 349 */       if (source != null) this.cache.setSource(source); 
/*     */     } catch (CacheException exc) {
/* 351 */       LOGGER.info("", (Throwable)exc);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void updateStrategy() {
/*     */     try {
/* 357 */       ICacheStrategy strategy = strategyValue(this.strategyChooser.getSelectedIndex());
/*     */       
/* 359 */       if (strategy != null) this.cache.setStrategy(strategy); 
/*     */     } catch (CacheException exc) {
/* 361 */       LOGGER.info("", (Throwable)exc);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void updateRange(int index) {
/* 366 */     int rng = ((Integer)this.range[index].getValue()).intValue();
/*     */     
/* 368 */     ICacheStrategy strategy = this.cache.getStrategy();
/* 369 */     int[] ranges = strategy.getRange();
/* 370 */     if (rng != ranges[index]) strategy.setRange(rng, index);
/*     */   
/*     */   }
/*     */   
/*     */   private void updatePriority(int index) {
/* 375 */     int prio = priorityValue(this.priority[index].getSelectedIndex());
/* 376 */     ICacheStrategy strategy = this.cache.getStrategy();
/* 377 */     int[] priorities = strategy.getPriorities();
/* 378 */     if (prio != priorities[index]) strategy.setPriority(prio, index);
/*     */   
/*     */   }
/*     */   
/*     */   private void updateOrder(int index) {
/* 383 */     int ord = orderValue(this.order[index].getSelectedIndex());
/* 384 */     ICacheStrategy strategy = this.cache.getStrategy();
/* 385 */     int[] orders = strategy.getOrder();
/* 386 */     if (ord != orders[index]) strategy.setOrder(ord, index);
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private int sourceIndex(ICacheSource s) {
/* 393 */     Class<?> c = s.getClass();
/* 394 */     for (int i = 0; i < SOURCE_VALUES.length; i++) {
/* 395 */       if (SOURCE_VALUES[i] == c) return i; 
/*     */     } 
/* 397 */     return -1;
/*     */   }
/*     */ 
/*     */   
/*     */   private ICacheSource sourceValue(int index) {
/* 402 */     Class<?> c = SOURCE_VALUES[index];
/* 403 */     if (c == this.cache.getSource().getClass()) return null; 
/*     */     
/* 405 */     try { Constructor<?> con = c.getConstructor(SOURCE_PARAMS);
/* 406 */       return (ICacheSource)con.newInstance(new Object[] { this.id }); }
/*     */     catch (NoSuchMethodException exc)
/* 408 */     { LOGGER.info("", exc); }
/* 409 */     catch (InstantiationException exc) { LOGGER.info("", exc); }
/* 410 */     catch (IllegalAccessException exc) { LOGGER.info("", exc); }
/* 411 */     catch (IllegalArgumentException exc) { LOGGER.info("", exc); }
/* 412 */     catch (InvocationTargetException exc) { LOGGER.info("", exc); }
/* 413 */      return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private int strategyIndex(ICacheStrategy s) {
/* 418 */     Class<?> c = s.getClass();
/* 419 */     for (int i = 0; i < STRATEGY_VALUES.length; i++) {
/* 420 */       if (STRATEGY_VALUES[i] == c) return i; 
/*     */     } 
/* 422 */     return -1;
/*     */   }
/*     */ 
/*     */   
/*     */   private ICacheStrategy strategyValue(int index) {
/* 427 */     Class<?> c = STRATEGY_VALUES[index];
/* 428 */     if (c == this.cache.getStrategy().getClass()) return null; 
/*     */     
/* 430 */     try { Constructor<?> con = c.getConstructor(STRATEGY_PARAMS);
/* 431 */       return (ICacheStrategy)con.newInstance(new Object[] { this.lengths }); }
/*     */     catch (NoSuchMethodException exc)
/* 433 */     { LOGGER.info("", exc); }
/* 434 */     catch (InstantiationException exc) { LOGGER.info("", exc); }
/* 435 */     catch (IllegalAccessException exc) { LOGGER.info("", exc); }
/* 436 */     catch (IllegalArgumentException exc) { LOGGER.info("", exc); }
/* 437 */     catch (InvocationTargetException exc) { LOGGER.info("", exc); }
/* 438 */      return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private int priorityIndex(int prio) {
/* 443 */     for (int i = 0; i < PRIORITY_VALUES.length; i++) {
/* 444 */       if (PRIORITY_VALUES[i] == prio) return i; 
/*     */     } 
/* 446 */     return -1;
/*     */   }
/*     */   
/*     */   private int priorityValue(int index) {
/* 450 */     return PRIORITY_VALUES[index];
/*     */   }
/*     */   
/*     */   private int orderIndex(int ord) {
/* 454 */     for (int i = 0; i < ORDER_VALUES.length; i++) {
/* 455 */       if (ORDER_VALUES[i] == ord) return i; 
/*     */     } 
/* 457 */     return -1;
/*     */   }
/*     */   
/*     */   private int orderValue(int index) {
/* 461 */     return ORDER_VALUES[index];
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/gui/CacheComponent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */