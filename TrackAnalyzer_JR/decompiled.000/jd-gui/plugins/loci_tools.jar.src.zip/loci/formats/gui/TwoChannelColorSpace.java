/*     */ package loci.formats.gui;
/*     */ 
/*     */ import java.awt.color.ColorSpace;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TwoChannelColorSpace
/*     */   extends ColorSpace
/*     */ {
/*     */   public static final int CS_2C = -1;
/*     */   private static final int NUM_COMPONENTS = 2;
/*     */   
/*     */   protected TwoChannelColorSpace(int type, int components) {
/*  61 */     super(type, components);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public float[] fromCIEXYZ(float[] color) {
/*  67 */     ColorSpace rgb = ColorSpace.getInstance(1000);
/*  68 */     return rgb.fromCIEXYZ(toRGB(color));
/*     */   }
/*     */   
/*     */   public float[] fromRGB(float[] rgb) {
/*  72 */     return new float[] { rgb[0], rgb[1] };
/*     */   }
/*     */   
/*     */   public static ColorSpace getInstance(int colorSpace) {
/*  76 */     if (colorSpace == -1) {
/*  77 */       return new TwoChannelColorSpace(12, 2);
/*     */     }
/*  79 */     return ColorSpace.getInstance(colorSpace);
/*     */   }
/*     */   
/*     */   public String getName(int idx) {
/*  83 */     return (idx == 0) ? "Red" : "Green";
/*     */   }
/*     */   
/*     */   public int getNumComponents() {
/*  87 */     return 2;
/*     */   }
/*     */   
/*     */   public int getType() {
/*  91 */     return 12;
/*     */   }
/*     */   public boolean isCS_sRGB() {
/*  94 */     return false;
/*     */   }
/*     */   public float[] toCIEXYZ(float[] color) {
/*  97 */     ColorSpace rgb = ColorSpace.getInstance(1000);
/*  98 */     return rgb.toCIEXYZ(toRGB(color));
/*     */   }
/*     */   
/*     */   public float[] toRGB(float[] color) {
/* 102 */     return new float[] { color[0], color[1], 0.0F };
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/gui/TwoChannelColorSpace.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */