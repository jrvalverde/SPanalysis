/*     */ package loci.formats.gui;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.util.Vector;
/*     */ import javax.swing.JFileChooser;
/*     */ import javax.swing.SwingUtilities;
/*     */ import javax.swing.filechooser.FileFilter;
/*     */ import loci.formats.FileStitcher;
/*     */ import loci.formats.IFormatHandler;
/*     */ import loci.formats.IFormatReader;
/*     */ import loci.formats.IFormatWriter;
/*     */ import loci.formats.ImageReader;
/*     */ import loci.formats.ImageWriter;
/*     */ import loci.formats.ReaderWrapper;
/*     */ import loci.formats.WriterWrapper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class GUITools
/*     */ {
/*     */   private static final String ALL_TYPES = "All supported file types";
/*     */   
/*     */   public static FileFilter[] buildFileFilters(IFormatHandler handler) {
/*     */     IFormatWriter iFormatWriter;
/*  79 */     FileFilter[] filters = null;
/*     */     
/*     */     while (true) {
/*     */       IFormatReader iFormatReader;
/*  83 */       while (handler instanceof ReaderWrapper) {
/*  84 */         iFormatReader = ((ReaderWrapper)handler).getReader();
/*     */       }
/*  86 */       if (iFormatReader instanceof FileStitcher) {
/*  87 */         iFormatReader = ((FileStitcher)iFormatReader).getReader(); continue;
/*     */       } 
/*  89 */       if (iFormatReader instanceof WriterWrapper) {
/*  90 */         iFormatWriter = ((WriterWrapper)iFormatReader).getWriter();
/*     */         
/*     */         continue;
/*     */       } 
/*     */       break;
/*     */     } 
/*  96 */     if (iFormatWriter instanceof ImageReader) {
/*  97 */       ImageReader imageReader = (ImageReader)iFormatWriter;
/*  98 */       IFormatReader[] readers = imageReader.getReaders();
/*  99 */       Vector<FormatFileFilter> filterList = new Vector();
/* 100 */       Vector<ExtensionFileFilter> comboList = new Vector();
/* 101 */       for (int i = 0; i < readers.length; i++) {
/* 102 */         filterList.add(new FormatFileFilter(readers[i]));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 110 */         String[] suffixes = readers[i].getSuffixes();
/* 111 */         String format = readers[i].getFormat();
/* 112 */         comboList.add(new ExtensionFileFilter(suffixes, format));
/*     */       } 
/* 114 */       comboList.add(new NoExtensionFileFilter());
/* 115 */       FileFilter combo = makeComboFilter(sortFilters(comboList));
/* 116 */       if (combo != null) filterList.add(combo);
/*     */       
/* 118 */       filters = sortFilters(filterList);
/*     */     }
/* 120 */     else if (iFormatWriter instanceof ImageWriter) {
/* 121 */       IFormatWriter[] writers = ((ImageWriter)iFormatWriter).getWriters();
/* 122 */       Vector<ExtensionFileFilter> filterList = new Vector();
/* 123 */       for (int i = 0; i < writers.length; i++) {
/* 124 */         String[] suffixes = writers[i].getSuffixes();
/* 125 */         String format = writers[i].getFormat();
/* 126 */         filterList.add(new ExtensionFileFilter(suffixes, format));
/*     */       } 
/* 128 */       filters = sortFilters(filterList);
/*     */ 
/*     */     
/*     */     }
/* 132 */     else if (iFormatWriter instanceof IFormatReader) {
/* 133 */       IFormatReader reader = (IFormatReader)iFormatWriter;
/* 134 */       filters = new FileFilter[] { new FormatFileFilter(reader) };
/*     */     } else {
/*     */       
/* 137 */       String[] suffixes = iFormatWriter.getSuffixes();
/* 138 */       String format = iFormatWriter.getFormat();
/* 139 */       filters = new FileFilter[] { new ExtensionFileFilter(suffixes, format) };
/*     */     } 
/* 141 */     return filters;
/*     */   }
/*     */ 
/*     */   
/*     */   public static JFileChooser buildFileChooser(IFormatHandler handler) {
/* 146 */     return buildFileChooser(handler, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JFileChooser buildFileChooser(IFormatHandler handler, boolean preview) {
/* 157 */     return buildFileChooser(buildFileFilters(handler), preview);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JFileChooser buildFileChooser(FileFilter[] filters) {
/* 165 */     return buildFileChooser(filters, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JFileChooser buildFileChooser(final FileFilter[] filters, final boolean preview) {
/* 178 */     final JFileChooser[] jfc = new JFileChooser[1];
/* 179 */     Runnable r = new Runnable() {
/*     */         public void run() {
/* 181 */           JFileChooser fc = new JFileChooser(System.getProperty("user.dir"));
/* 182 */           FileFilter[] ff = GUITools.sortFilters(filters);
/*     */           
/* 184 */           FileFilter combo = null;
/* 185 */           if (ff.length > 0 && ff[0] instanceof ComboFileFilter) {
/*     */             
/* 187 */             ComboFileFilter cff = (ComboFileFilter)ff[0];
/* 188 */             if ("All supported file types".equals(cff.getDescription())) combo = cff;
/*     */           
/*     */           } 
/* 191 */           if (combo == null) {
/* 192 */             combo = GUITools.makeComboFilter(ff);
/* 193 */             if (combo != null) fc.addChoosableFileFilter(combo); 
/*     */           } 
/* 195 */           for (int i = 0; i < ff.length; ) { fc.addChoosableFileFilter(ff[i]); i++; }
/* 196 */            if (combo != null) fc.setFileFilter(combo); 
/* 197 */           if (preview) new PreviewPane(fc); 
/* 198 */           jfc[0] = fc;
/*     */         }
/*     */       };
/* 201 */     if (Thread.currentThread().getName().startsWith("AWT-EventQueue")) {
/*     */       
/* 203 */       r.run();
/*     */     } else {
/*     */ 
/*     */ 
/*     */       
/* 208 */       try { SwingUtilities.invokeAndWait(r); }
/*     */       catch (InterruptedException exc)
/* 210 */       { return null; }
/* 211 */       catch (InvocationTargetException exc) { return null; }
/*     */     
/* 213 */     }  return jfc[0];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static FileFilter makeComboFilter(FileFilter[] filters) {
/* 223 */     return (filters.length > 1) ? new ComboFileFilter(filters, "All supported file types") : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static FileFilter[] sortFilters(FileFilter[] filters) {
/* 231 */     filters = ComboFileFilter.sortFilters(filters);
/* 232 */     shuffleAllTypesToFront(filters);
/* 233 */     return filters;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static FileFilter[] sortFilters(Vector filterList) {
/* 241 */     FileFilter[] filters = ComboFileFilter.sortFilters(filterList);
/* 242 */     shuffleAllTypesToFront(filters);
/* 243 */     return filters;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void shuffleAllTypesToFront(FileFilter[] filters) {
/* 251 */     for (int i = 0; i < filters.length; i++) {
/* 252 */       if (filters[i] instanceof ComboFileFilter && 
/* 253 */         "All supported file types".equals(filters[i].getDescription())) {
/* 254 */         FileFilter f = filters[i];
/* 255 */         for (int j = i; j >= 1; ) { filters[j] = filters[j - 1]; j--; }
/* 256 */          filters[0] = f;
/*     */         break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/gui/GUITools.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */