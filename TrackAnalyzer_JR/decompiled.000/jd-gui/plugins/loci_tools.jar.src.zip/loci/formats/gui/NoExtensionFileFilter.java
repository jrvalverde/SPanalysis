/*    */ package loci.formats.gui;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.FileFilter;
/*    */ import javax.swing.filechooser.FileFilter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NoExtensionFileFilter
/*    */   extends FileFilter
/*    */   implements FileFilter, Comparable
/*    */ {
/*    */   public boolean accept(File f) {
/* 59 */     if (f.isDirectory()) return true; 
/* 60 */     return (f.getName().lastIndexOf('.') < 0);
/*    */   }
/*    */   
/*    */   public String getDescription() {
/* 64 */     return "Files with no extension";
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 69 */     return "NoExtensionFileFilter";
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int compareTo(Object o) {
/* 75 */     FileFilter filter = (FileFilter)o;
/* 76 */     return getDescription().compareToIgnoreCase(filter.getDescription());
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/gui/NoExtensionFileFilter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */