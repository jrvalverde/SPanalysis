/*     */ package loci.formats.gui;
/*     */ 
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Cursor;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.KeyEvent;
/*     */ import java.awt.event.KeyListener;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.MouseMotionListener;
/*     */ import java.awt.event.WindowEvent;
/*     */ import java.awt.event.WindowListener;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.Raster;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import javax.swing.Box;
/*     */ import javax.swing.BoxLayout;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JFileChooser;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JMenu;
/*     */ import javax.swing.JMenuBar;
/*     */ import javax.swing.JMenuItem;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JSlider;
/*     */ import javax.swing.ProgressMonitor;
/*     */ import javax.swing.border.BevelBorder;
/*     */ import javax.swing.border.EmptyBorder;
/*     */ import javax.swing.event.ChangeEvent;
/*     */ import javax.swing.event.ChangeListener;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import loci.common.services.DependencyException;
/*     */ import loci.common.services.ServiceException;
/*     */ import loci.common.services.ServiceFactory;
/*     */ import loci.formats.ChannelMerger;
/*     */ import loci.formats.FileStitcher;
/*     */ import loci.formats.FormatException;
/*     */ import loci.formats.FormatTools;
/*     */ import loci.formats.IFormatHandler;
/*     */ import loci.formats.IFormatReader;
/*     */ import loci.formats.IFormatWriter;
/*     */ import loci.formats.ImageWriter;
/*     */ import loci.formats.MetadataTools;
/*     */ import loci.formats.meta.IMetadata;
/*     */ import loci.formats.meta.MetadataRetrieve;
/*     */ import loci.formats.meta.MetadataStore;
/*     */ import loci.formats.ome.OMEXMLMetadata;
/*     */ import loci.formats.services.OMEXMLService;
/*     */ import ome.xml.model.enums.DimensionOrder;
/*     */ import ome.xml.model.enums.EnumerationException;
/*     */ import ome.xml.model.enums.PixelType;
/*     */ import ome.xml.model.enums.handlers.DimensionOrderEnumHandler;
/*     */ import ome.xml.model.enums.handlers.PixelTypeEnumHandler;
/*     */ import ome.xml.model.primitives.PositiveInteger;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ImageViewer
/*     */   extends JFrame
/*     */   implements ActionListener, ChangeListener, KeyListener, MouseMotionListener, Runnable, WindowListener
/*     */ {
/* 120 */   private static final Logger LOGGER = LoggerFactory.getLogger(ImageViewer.class);
/*     */   
/*     */   protected static final String TITLE = "Bio-Formats Viewer";
/*     */   
/*     */   protected static final char ANIMATION_KEY = ' ';
/*     */   
/*     */   protected JPanel pane;
/*     */   
/*     */   protected ImageIcon icon;
/*     */   
/*     */   protected JLabel iconLabel;
/*     */   
/*     */   protected JPanel sliderPanel;
/*     */   
/*     */   protected JSlider nSlider;
/*     */   
/*     */   protected JSlider zSlider;
/*     */   
/*     */   protected JSlider tSlider;
/*     */   
/*     */   protected JSlider cSlider;
/*     */   
/*     */   protected JLabel probeLabel;
/*     */   protected JMenuItem fileView;
/*     */   protected JMenuItem fileSave;
/*     */   protected MetadataStore omeMeta;
/*     */   protected BufferedImageReader myReader;
/*     */   protected BufferedImageWriter myWriter;
/*     */   protected IFormatReader fileReader;
/*     */   protected IFormatWriter fileWriter;
/*     */   protected String filename;
/*     */   protected IFormatReader in;
/*     */   protected BufferedImage[] images;
/*     */   protected int sizeZ;
/*     */   protected int sizeT;
/*     */   protected int sizeC;
/*     */   protected boolean anim = false;
/* 157 */   protected int fps = 10; protected boolean canCloseReader = true; protected OMEXMLService omexmlService; protected StringBuffer sb; public ImageViewer(boolean canCloseReader) { this(); this.canCloseReader = canCloseReader; }
/*     */   public void open(String id) { wait(true); try { OMEXMLMetadata oMEXMLMetadata; IMetadata meta = null; if (this.omexmlService != null) try { oMEXMLMetadata = this.omexmlService.createOMEXMLMetadata(); this.myReader.setMetadataStore((MetadataStore)oMEXMLMetadata); } catch (ServiceException exc) { LOGGER.debug("Could not create OME-XML metadata", (Throwable)exc); }   if (oMEXMLMetadata == null) LOGGER.info("OME metadata unavailable");  this.myReader.setId(id); int num = this.myReader.getImageCount(); ProgressMonitor progress = new ProgressMonitor(this, "Reading " + id, null, 0, num + 1); this.sizeZ = this.myReader.getSizeZ(); this.sizeT = this.myReader.getSizeT(); this.sizeC = this.myReader.getEffectiveSizeC(); progress.setProgress(1); BufferedImage[] img = new BufferedImage[num]; for (int i = 0; i < num && !progress.isCanceled(); i++) { img[i] = this.myReader.openImage(i); if (i == 0) setImages((IFormatReader)this.myReader, img);  progress.setProgress(i + 2); }  this.myReader.close(true); } catch (FormatException exc) { LOGGER.info("", (Throwable)exc); wait(false); return; } catch (IOException exc) { LOGGER.info("", exc); wait(false); return; }  wait(false); }
/*     */   public void save(String id) { if (this.images == null)
/*     */       return;  wait(true); try { if (this.omeMeta == null) { this.omeMeta = (MetadataStore)this.omexmlService.createOMEXMLMetadata(); this.omeMeta.setImageID(MetadataTools.createLSID("Image", new int[] { 0 }), 0); this.omeMeta.setPixelsID(MetadataTools.createLSID("Pixels", new int[] { 0 }), 0); this.omeMeta.setPixelsBinDataBigEndian(Boolean.valueOf(false), 0, 0); String order = "XYCZT"; if (this.in != null)
/*     */           order = this.in.getDimensionOrder();  this.omeMeta.setPixelsDimensionOrder((DimensionOrder)(new DimensionOrderEnumHandler()).getEnumeration(order), 0); int type = AWTImageTools.getPixelType(this.images[0]); String pixelType = FormatTools.getPixelTypeString(type); this.omeMeta.setPixelsType((PixelType)(new PixelTypeEnumHandler()).getEnumeration(pixelType), 0); int rgbChannelCount = this.images[0].getRaster().getNumBands(); int realChannelCount = this.sizeC / rgbChannelCount; for (int i = 0; i < realChannelCount; i++) { this.omeMeta.setChannelID(MetadataTools.createLSID("Channel", new int[] { i, 0 }), 0, i); this.omeMeta.setChannelSamplesPerPixel(new PositiveInteger(Integer.valueOf(rgbChannelCount)), 0, i); }  this.omeMeta.setPixelsSizeX(new PositiveInteger(Integer.valueOf(this.images[0].getWidth())), 0); this.omeMeta.setPixelsSizeY(new PositiveInteger(Integer.valueOf(this.images[0].getHeight())), 0); this.omeMeta.setPixelsSizeC(new PositiveInteger(Integer.valueOf(this.sizeC)), 0); this.omeMeta.setPixelsSizeZ(new PositiveInteger(Integer.valueOf(this.sizeZ)), 0); this.omeMeta.setPixelsSizeT(new PositiveInteger(Integer.valueOf(this.sizeT)), 0); }  this.myWriter.setMetadataRetrieve(this.omexmlService.asRetrieve(this.omeMeta)); this.myWriter.setId(id); boolean stack = this.myWriter.canDoStacks(); ProgressMonitor progress = new ProgressMonitor(this, "Saving " + id, null, 0, stack ? this.images.length : 1); if (stack) { for (int i = 0; i < this.images.length; i++) { progress.setProgress(i); boolean canceled = progress.isCanceled(); this.myWriter.saveImage(i, this.images[i]); if (canceled)
/*     */             break;  }  progress.setProgress(this.images.length); } else { this.myWriter.savePlane(0, getImage()); progress.setProgress(1); }  this.myWriter.close(); } catch (FormatException exc) { LOGGER.info("", (Throwable)exc); } catch (IOException exc) { LOGGER.info("", exc); } catch (ServiceException exc) { LOGGER.info("", (Throwable)exc); } catch (EnumerationException exc) { LOGGER.info("", (Throwable)exc); }  wait(false); }
/*     */   public void setImages(BufferedImage[] img) { setImages((IFormatReader)null, img); }
/*     */   public void setImages(IFormatReader reader, BufferedImage[] img) { this.filename = (reader == null) ? null : reader.getCurrentFile(); this.in = reader; this.images = img; if (reader == null) { this.sizeZ = this.sizeC = this.sizeT = 1; } else { this.sizeZ = reader.getSizeZ(); this.sizeT = reader.getSizeT(); this.sizeC = reader.getEffectiveSizeC(); this.omeMeta = reader.getMetadataStore(); if (this.omexmlService == null || !this.omexmlService.isOMEXMLMetadata(this.omeMeta))
/*     */         this.omeMeta = null;  }  this.fileView.setEnabled((this.omeMeta != null)); this.fileSave.setEnabled(true); this.nSlider.removeChangeListener(this); this.zSlider.removeChangeListener(this); this.tSlider.removeChangeListener(this); this.cSlider.removeChangeListener(this); this.nSlider.setValue(1); this.nSlider.setMaximum(this.images.length); this.nSlider.setEnabled((this.images.length > 1)); this.zSlider.setValue(1); this.zSlider.setMaximum(this.sizeZ); this.zSlider.setEnabled((this.sizeZ > 1)); this.tSlider.setValue(1); this.tSlider.setMaximum(this.sizeT); this.tSlider.setEnabled((this.sizeT > 1)); this.cSlider.setValue(1); this.cSlider.setMaximum(this.sizeC); this.cSlider.setEnabled((this.sizeC > 1)); this.nSlider.addChangeListener(this); this.zSlider.addChangeListener(this); this.tSlider.addChangeListener(this); this.cSlider.addChangeListener(this); this.sliderPanel.setVisible((this.images.length > 1)); updateLabel(-1, -1); this.sb.setLength(0); if (this.filename != null) { this.sb.append(reader.getCurrentFile()); this.sb.append(" "); }  String format = (reader == null) ? null : reader.getFormat(); if (format != null) { this.sb.append("("); this.sb.append(format); this.sb.append(")"); this.sb.append(" "); }  if (this.filename != null || format != null)
/*     */       this.sb.append("- ");  this.sb.append("Bio-Formats Viewer"); setTitle(this.sb.toString()); if (this.images != null)
/*     */       this.icon.setImage(this.images[0]);  pack(); }
/*     */   public BufferedImage getImage() { int ndx = getImageIndex(); return (this.images == null || ndx >= this.images.length) ? null : this.images[ndx]; }
/*     */   public int getImageIndex() { return this.nSlider.getValue() - 1; }
/* 170 */   public ImageViewer() { super("Bio-Formats Viewer");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 731 */     this.sb = new StringBuffer(); setDefaultCloseOperation(2); addWindowListener(this); this.fileReader = (IFormatReader)new ChannelMerger((IFormatReader)new FileStitcher()); this.myReader = new BufferedImageReader(this.fileReader); this.fileWriter = (IFormatWriter)new ImageWriter(); this.myWriter = new BufferedImageWriter(this.fileWriter); try { ServiceFactory factory = new ServiceFactory(); this.omexmlService = (OMEXMLService)factory.getInstance(OMEXMLService.class); } catch (DependencyException exc) { LOGGER.debug("OME-XML service unavailable", (Throwable)exc); }  this.pane = new JPanel(); this.pane.setLayout(new BorderLayout()); setContentPane(this.pane); setSize(350, 350); this.sliderPanel = new JPanel(); this.sliderPanel.setVisible(false); this.sliderPanel.setBorder(new EmptyBorder(5, 3, 5, 3)); this.sliderPanel.setLayout(new BoxLayout(this.sliderPanel, 1)); this.pane.add("South", this.sliderPanel); JPanel nPanel = new JPanel(); nPanel.setLayout(new BoxLayout(nPanel, 0)); this.sliderPanel.add(nPanel); this.sliderPanel.add(Box.createVerticalStrut(2)); this.nSlider = new JSlider(1, 1); this.nSlider.setEnabled(false); this.nSlider.addChangeListener(this); nPanel.add(new JLabel("N")); nPanel.add(Box.createHorizontalStrut(3)); nPanel.add(this.nSlider); JPanel ztcPanel = new JPanel(); ztcPanel.setLayout(new BoxLayout(ztcPanel, 0)); this.sliderPanel.add(ztcPanel); this.zSlider = new JSlider(1, 1); Dimension dim = this.zSlider.getPreferredSize(); dim.width = 50; this.zSlider.setPreferredSize(dim); this.zSlider.setEnabled(false); this.zSlider.addChangeListener(this); ztcPanel.add(new JLabel("Z")); ztcPanel.add(Box.createHorizontalStrut(3)); ztcPanel.add(this.zSlider); ztcPanel.add(Box.createHorizontalStrut(7)); this.tSlider = new JSlider(1, 1); this.tSlider.setPreferredSize(dim); this.tSlider.setEnabled(false); this.tSlider.addChangeListener(this); ztcPanel.add(new JLabel("T")); ztcPanel.add(Box.createHorizontalStrut(3)); ztcPanel.add(this.tSlider); ztcPanel.add(Box.createHorizontalStrut(7)); this.cSlider = new JSlider(1, 1); this.cSlider.setPreferredSize(dim); this.cSlider.setEnabled(false); this.cSlider.addChangeListener(this); ztcPanel.add(new JLabel("C")); ztcPanel.add(Box.createHorizontalStrut(3)); ztcPanel.add(this.cSlider); ztcPanel.add(Box.createHorizontalStrut(7)); BufferedImage dummy = AWTImageTools.makeImage(new byte[1][1], 1, 1, false); this.icon = new ImageIcon(dummy); this.iconLabel = new JLabel(this.icon, 2); this.iconLabel.setVerticalAlignment(1); this.pane.add(new JScrollPane(this.iconLabel)); this.probeLabel = new JLabel(" "); this.probeLabel.setHorizontalAlignment(0); this.probeLabel.setBorder(new BevelBorder(0)); this.pane.add("North", this.probeLabel); this.iconLabel.addMouseMotionListener(this); JMenuBar menubar = new JMenuBar(); setJMenuBar(menubar); JMenu file = new JMenu("File"); file.setMnemonic('f'); menubar.add(file); JMenuItem fileOpen = new JMenuItem("Open..."); fileOpen.setMnemonic('o'); fileOpen.setActionCommand("open"); fileOpen.addActionListener(this); file.add(fileOpen); this.fileSave = new JMenuItem("Save..."); this.fileSave.setMnemonic('s'); this.fileSave.setEnabled(false); this.fileSave.setActionCommand("save"); this.fileSave.addActionListener(this); file.add(this.fileSave); if (this.omexmlService != null) { this.fileView = new JMenuItem("View Metadata..."); this.fileView.setMnemonic('m'); this.fileView.setEnabled(true); this.fileView.setActionCommand("view"); this.fileView.addActionListener(this); file.add(this.fileView); }
/*     */      JMenuItem fileExit = new JMenuItem("Exit"); fileExit.setMnemonic('x'); fileExit.setActionCommand("exit"); fileExit.addActionListener(this); file.add(fileExit); JMenu options = new JMenu("Options"); options.setMnemonic('p'); menubar.add(options); JMenuItem optionsFPS = new JMenuItem("Frames per Second..."); optionsFPS.setMnemonic('f'); optionsFPS.setActionCommand("fps"); optionsFPS.addActionListener(this); options.add(optionsFPS); JMenu help = new JMenu("Help"); help.setMnemonic('h'); menubar.add(help); JMenuItem helpAbout = new JMenuItem("About..."); helpAbout.setMnemonic('a'); helpAbout.setActionCommand("about"); helpAbout.addActionListener(this); help.add(helpAbout); this.nSlider.addKeyListener(this); this.zSlider.addKeyListener(this); this.tSlider.addKeyListener(this); this.cSlider.addKeyListener(this); }
/*     */   public int getZ() { return this.zSlider.getValue() - 1; }
/*     */   public int getT() { return this.tSlider.getValue() - 1; }
/* 735 */   public int getC() { return this.cSlider.getValue() - 1; } protected void updateLabel(int x, int y) { if (this.images == null)
/* 736 */       return;  int ndx = getImageIndex();
/* 737 */     this.sb.setLength(0);
/* 738 */     if (this.images.length > 1) {
/* 739 */       this.sb.append("N=");
/* 740 */       this.sb.append(ndx + 1);
/* 741 */       this.sb.append("/");
/* 742 */       this.sb.append(this.images.length);
/*     */     } 
/* 744 */     if (this.sizeZ > 1) {
/* 745 */       this.sb.append("; Z=");
/* 746 */       this.sb.append(getZ() + 1);
/* 747 */       this.sb.append("/");
/* 748 */       this.sb.append(this.sizeZ);
/*     */     } 
/* 750 */     if (this.sizeT > 1) {
/* 751 */       this.sb.append("; T=");
/* 752 */       this.sb.append(getT() + 1);
/* 753 */       this.sb.append("/");
/* 754 */       this.sb.append(this.sizeT);
/*     */     } 
/* 756 */     if (this.sizeC > 1) {
/* 757 */       this.sb.append("; C=");
/* 758 */       this.sb.append(getC() + 1);
/* 759 */       this.sb.append("/");
/* 760 */       this.sb.append(this.sizeC);
/*     */     } 
/* 762 */     BufferedImage image = this.images[ndx];
/* 763 */     int w = (image == null) ? -1 : image.getWidth();
/* 764 */     int h = (image == null) ? -1 : image.getHeight();
/* 765 */     if (x >= w) x = w - 1; 
/* 766 */     if (y >= h) y = h - 1; 
/* 767 */     if (x >= 0 && y >= 0) {
/* 768 */       if (this.images.length > 1) this.sb.append("; "); 
/* 769 */       this.sb.append("X=");
/* 770 */       this.sb.append(x);
/* 771 */       if (w > 0) {
/* 772 */         this.sb.append("/");
/* 773 */         this.sb.append(w);
/*     */       } 
/* 775 */       this.sb.append("; Y=");
/* 776 */       this.sb.append(y);
/* 777 */       if (h > 0) {
/* 778 */         this.sb.append("/");
/* 779 */         this.sb.append(h);
/*     */       } 
/* 781 */       if (image != null) {
/* 782 */         Raster r = image.getRaster();
/* 783 */         double[] pix = r.getPixel(x, y, (double[])null);
/* 784 */         this.sb.append("; value");
/* 785 */         this.sb.append((pix.length > 1) ? "s=(" : "=");
/* 786 */         for (int i = 0; i < pix.length; i++) {
/* 787 */           if (i > 0) this.sb.append(", "); 
/* 788 */           this.sb.append(pix[i]);
/*     */         } 
/* 790 */         if (pix.length > 1) this.sb.append(")"); 
/* 791 */         this.sb.append("; type=");
/* 792 */         int pixelType = AWTImageTools.getPixelType(image);
/* 793 */         this.sb.append(FormatTools.getPixelTypeString(pixelType));
/*     */       } 
/*     */     } 
/* 796 */     this.sb.append(" ");
/* 797 */     this.probeLabel.setText(this.sb.toString()); }
/*     */   public void setVisible(boolean visible) { super.setVisible(visible); (new Thread(this)).start(); }
/*     */   public void actionPerformed(ActionEvent e) { String cmd = e.getActionCommand(); if ("open".equals(cmd)) { wait(true); JFileChooser chooser = GUITools.buildFileChooser((IFormatHandler)this.myReader); wait(false); int rval = chooser.showOpenDialog(this); if (rval == 0) { File file = chooser.getSelectedFile(); if (file != null) open(file.getAbsolutePath(), this.fileReader);  }  } else if ("save".equals(cmd)) { wait(true); JFileChooser chooser = GUITools.buildFileChooser((IFormatHandler)this.myWriter); wait(false); int rval = chooser.showSaveDialog(this); if (rval == 0) { File file = chooser.getSelectedFile(); if (file != null) save(file.getAbsolutePath(), this.fileWriter);  }  } else if ("view".equals(cmd)) { if (this.omeMeta != null) { XMLWindow metaWindow = new XMLWindow("OME Metadata - " + getTitle()); metaWindow.setDefaultCloseOperation(2); Exception exception = null; try { MetadataRetrieve retrieve = this.omexmlService.asRetrieve(this.omeMeta); metaWindow.setXML(this.omexmlService.getOMEXML(retrieve)); metaWindow.setVisible(true); } catch (ServiceException exc) { ServiceException serviceException1 = exc = null; } catch (ParserConfigurationException exc) { exception = exc = null; } catch (SAXException exc) { exception = exc = null; } catch (IOException exc) { exception = exc = null; }  if (exception != null) LOGGER.info("Cannot display OME metadata", exception);  }  } else if ("exit".equals(cmd)) { dispose(); } else if ("fps".equals(cmd)) { setDefaultCloseOperation(3); String result = JOptionPane.showInputDialog(this, "Animate using space bar. How many frames per second?", "" + this.fps); try { this.fps = Integer.parseInt(result); } catch (NumberFormatException exc) { LOGGER.debug("Could not parse fps '{}'", Integer.valueOf(this.fps), exc); }  } else if ("about".equals(cmd)) { setDefaultCloseOperation(3); String msg = "<html>OME Bio-Formats package for reading and converting biological file formats.<br>Copyright (C) 2005 - " + FormatTools.YEAR + " Open Microscopy Environment:" + "<ul>" + "<li>Board of Regents of the University of Wisconsin-Madison</li>" + "<li>Glencoe Software, Inc.</li>" + "<li>University of Dundee</li>" + "</ul>" + "<i>" + "http://www.openmicroscopy.org/site/products/bio-formats" + "</i>" + "<br>Revision " + FormatTools.VCS_REVISION + ", built " + FormatTools.DATE + "<br><br>See <a href=\"" + "http://www.openmicroscopy.org/site/support/bio-formats/users/index.html\">" + "http://www.openmicroscopy.org/site/support/bio-formats/users/index.html</a>" + "<br>for help with using Bio-Formats."; ImageIcon bioFormatsLogo = new ImageIcon(IFormatHandler.class.getResource("bio-formats-logo.png")); JOptionPane.showMessageDialog(null, msg, "Bio-Formats", 1, bioFormatsLogo); }  }
/*     */   public void stateChanged(ChangeEvent e) { Object src = e.getSource(); boolean outOfBounds = false; if (src == this.nSlider) { int ndx = getImageIndex(); (new int[3])[0] = -1; (new int[3])[1] = -1; (new int[3])[2] = -1; int[] zct = (this.in == null) ? new int[3] : this.in.getZCTCoords(ndx); if (zct[0] >= 0) { this.zSlider.removeChangeListener(this); this.zSlider.setValue(zct[0] + 1); this.zSlider.addChangeListener(this); }  if (zct[1] >= 0) { this.cSlider.removeChangeListener(this); this.cSlider.setValue(zct[1] + 1); this.cSlider.addChangeListener(this); }  if (zct[2] >= 0) { this.tSlider.removeChangeListener(this); this.tSlider.setValue(zct[2] + 1); this.tSlider.addChangeListener(this); }  } else { int ndx = (this.in == null) ? -1 : this.in.getIndex(getZ(), getC(), getT()); if (ndx >= 0) { this.nSlider.removeChangeListener(this); outOfBounds = (ndx >= this.nSlider.getMaximum()); this.nSlider.setValue(ndx + 1); this.nSlider.addChangeListener(this); }  }  updateLabel(-1, -1); BufferedImage image = outOfBounds ? null : getImage(); if (image == null) { this.iconLabel.setIcon((Icon)null); this.iconLabel.setText("No image plane"); } else { this.icon.setImage(image); this.iconLabel.setIcon(this.icon); this.iconLabel.setText((String)null); }  }
/*     */   public void keyPressed(KeyEvent e) { if (e.getKeyChar() == ' ') this.anim = !this.anim;  }
/* 802 */   public void keyReleased(KeyEvent e) {} public void keyTyped(KeyEvent e) {} public void mouseDragged(MouseEvent e) { updateLabel(e.getX(), e.getY()); } public void mouseMoved(MouseEvent e) { updateLabel(e.getX(), e.getY()); } public void run() { while (isVisible()) { if (this.anim) { int t = this.tSlider.getValue(); t = t % this.tSlider.getMaximum() + 1; this.tSlider.setValue(t); }  try { Thread.sleep((1000 / this.fps)); } catch (InterruptedException exc) { LOGGER.debug("", exc); }  }  } public void windowClosing(WindowEvent e) {} public void windowActivated(WindowEvent e) {} public void windowDeactivated(WindowEvent e) {} public void windowOpened(WindowEvent e) {} public void windowIconified(WindowEvent e) {} public void windowDeiconified(WindowEvent e) {} public void windowClosed(WindowEvent e) { try { this.myReader.close(); this.myWriter.close(); if (this.canCloseReader) this.in.close();  } catch (IOException io) {} } protected void wait(boolean wait) { setCursor(wait ? Cursor.getPredefinedCursor(3) : null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void open(final String id, final IFormatReader r) {
/* 810 */     (new Thread("ImageViewer-Opener") {
/*     */         public void run() {
/*     */           try {
/* 813 */             ImageViewer.this.myReader.close();
/*     */           } catch (IOException exc) {
/* 815 */             ImageViewer.LOGGER.info("", exc);
/* 816 */           }  ImageViewer.this.myReader = new BufferedImageReader(r);
/* 817 */           ImageViewer.this.open(id);
/*     */         }
/*     */       }).start();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void save(final String id, final IFormatWriter w) {
/* 827 */     (new Thread("ImageViewer-Saver") {
/*     */         public void run() {
/*     */           try {
/* 830 */             ImageViewer.this.myWriter.close();
/*     */           } catch (IOException exc) {
/* 832 */             ImageViewer.LOGGER.info("", exc);
/* 833 */           }  ImageViewer.this.myWriter = BufferedImageWriter.makeBufferedImageWriter(w);
/* 834 */           ImageViewer.this.save(id);
/*     */         }
/*     */       }).start();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {
/* 842 */     ImageViewer viewer = new ImageViewer();
/* 843 */     viewer.setVisible(true);
/* 844 */     if (args.length > 0) viewer.open(args[0]); 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/gui/ImageViewer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */