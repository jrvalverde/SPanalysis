/*     */ package loci.formats.gui;
/*     */ 
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Toolkit;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTree;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import org.w3c.dom.Document;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XMLWindow
/*     */   extends JFrame
/*     */ {
/*     */   private Document doc;
/*     */   
/*     */   public XMLWindow() {}
/*     */   
/*     */   public XMLWindow(String title) {
/*  81 */     super(title);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setXML(String xml) throws ParserConfigurationException, SAXException, IOException {
/*  90 */     setDocument((Document)null);
/*     */ 
/*     */     
/*  93 */     DocumentBuilderFactory docFact = DocumentBuilderFactory.newInstance();
/*  94 */     DocumentBuilder db = docFact.newDocumentBuilder();
/*  95 */     ByteArrayInputStream is = new ByteArrayInputStream(xml.getBytes("UTF-8"));
/*     */     
/*  97 */     Document doc = db.parse(is);
/*  98 */     is.close();
/*     */     
/* 100 */     setDocument(doc);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setXML(File file) throws ParserConfigurationException, SAXException, IOException {
/* 107 */     setDocument((Document)null);
/*     */ 
/*     */     
/* 110 */     DocumentBuilderFactory docFact = DocumentBuilderFactory.newInstance();
/* 111 */     DocumentBuilder db = docFact.newDocumentBuilder();
/* 112 */     Document doc = db.parse(file);
/*     */     
/* 114 */     setDocument(doc);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setDocument(Document doc) {
/* 119 */     this.doc = doc;
/* 120 */     getContentPane().removeAll();
/* 121 */     if (doc == null) { setVisible(false); }
/*     */     else
/*     */     
/* 124 */     { JTree tree = XMLCellRenderer.makeJTree(doc);
/* 125 */       for (int i = 0; i < tree.getRowCount(); ) { tree.expandRow(i); i++; }
/* 126 */        getContentPane().add(new JScrollPane(tree));
/* 127 */       pack();
/* 128 */       Dimension dim = getSize();
/* 129 */       int pad = 20;
/* 130 */       dim.width += 20;
/* 131 */       dim.height += 20;
/* 132 */       Dimension ss = Toolkit.getDefaultToolkit().getScreenSize();
/* 133 */       int maxWidth = 3 * ss.width / 4;
/* 134 */       int maxHeight = 3 * ss.height / 4;
/* 135 */       if (dim.width > maxWidth) dim.width = maxWidth; 
/* 136 */       if (dim.height > maxHeight) dim.height = maxHeight; 
/* 137 */       setSize(dim); }
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   public Document getDocument() {
/* 143 */     return this.doc;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] args) throws Exception {
/* 149 */     XMLWindow xmlWindow = new XMLWindow();
/* 150 */     xmlWindow.setDefaultCloseOperation(3);
/* 151 */     if (args.length > 0) {
/* 152 */       String filename = args[0];
/* 153 */       xmlWindow.setXML(new File(filename));
/* 154 */       xmlWindow.setTitle("XML Window - " + filename);
/*     */     } else {
/*     */       
/* 157 */       BufferedReader in = new BufferedReader(new InputStreamReader(System.in, "UTF-8"));
/*     */       
/* 159 */       StringBuffer sb = new StringBuffer();
/*     */       while (true) {
/* 161 */         String line = in.readLine();
/* 162 */         if (line == null)
/* 163 */           break;  sb.append(line);
/* 164 */         sb.append("\n");
/*     */       } 
/* 166 */       xmlWindow.setXML(sb.toString());
/* 167 */       xmlWindow.setTitle("XML Window - <stdin>");
/*     */     } 
/* 169 */     xmlWindow.setLocation(200, 200);
/* 170 */     xmlWindow.setVisible(true);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/gui/XMLWindow.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */