/*     */ package loci.formats.gui;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileFilter;
/*     */ import javax.swing.filechooser.FileFilter;
/*     */ import loci.formats.IFormatReader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FormatFileFilter
/*     */   extends FileFilter
/*     */   implements FileFilter, Comparable
/*     */ {
/*     */   private IFormatReader reader;
/*     */   private boolean allowOpen;
/*     */   private String desc;
/*     */   
/*     */   public FormatFileFilter(IFormatReader reader) {
/*  71 */     this(reader, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FormatFileFilter(IFormatReader reader, boolean allowOpen) {
/*  81 */     this.reader = reader;
/*  82 */     this.allowOpen = allowOpen;
/*  83 */     StringBuffer sb = new StringBuffer(reader.getFormat());
/*  84 */     String[] exts = reader.getSuffixes();
/*  85 */     boolean first = true;
/*  86 */     for (int i = 0; i < exts.length; i++) {
/*  87 */       if (exts[i] != null && !exts[i].equals("")) {
/*  88 */         if (first) {
/*  89 */           sb.append(" (");
/*  90 */           first = false;
/*     */         } else {
/*  92 */           sb.append(", ");
/*  93 */         }  sb.append("*.");
/*  94 */         sb.append(exts[i]);
/*     */       } 
/*  96 */     }  sb.append(")");
/*  97 */     this.desc = sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean accept(File f) {
/* 104 */     if (f.isDirectory()) return true; 
/* 105 */     return this.reader.isThisType(f.getPath(), this.allowOpen);
/*     */   }
/*     */   
/*     */   public IFormatReader getReader() {
/* 109 */     return this.reader;
/*     */   }
/*     */   public String getDescription() {
/* 112 */     return this.desc;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 117 */     return "FormatFileFilter: " + this.desc;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int compareTo(Object o) {
/* 123 */     return this.desc.compareTo(((FileFilter)o).getDescription());
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/gui/FormatFileFilter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */