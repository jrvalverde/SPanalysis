/*     */ package loci.formats.gui;
/*     */ 
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.io.IOException;
/*     */ import loci.formats.FormatException;
/*     */ import loci.formats.IFormatReader;
/*     */ import loci.formats.ReaderWrapper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BufferedImageReader
/*     */   extends ReaderWrapper
/*     */ {
/*     */   public static BufferedImageReader makeBufferedImageReader(IFormatReader r) {
/*  61 */     if (r instanceof BufferedImageReader) return (BufferedImageReader)r; 
/*  62 */     return new BufferedImageReader(r);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public BufferedImageReader() {}
/*     */ 
/*     */   
/*     */   public BufferedImageReader(IFormatReader r) {
/*  71 */     super(r);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public BufferedImage openImage(int no) throws FormatException, IOException {
/*  77 */     return openImage(no, 0, 0, getSizeX(), getSizeY());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BufferedImage openImage(int no, int x, int y, int w, int h) throws FormatException, IOException {
/*  87 */     Class<?> dataType = getNativeDataType();
/*  88 */     if (BufferedImage.class.isAssignableFrom(dataType))
/*     */     {
/*  90 */       return (BufferedImage)openPlane(no, x, y, w, h);
/*     */     }
/*     */ 
/*     */     
/*  94 */     return AWTImageTools.openImage(openBytes(no, x, y, w, h), (IFormatReader)this, w, h);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BufferedImage openThumbImage(int no) throws FormatException, IOException {
/* 102 */     Class<?> dataType = getNativeDataType();
/* 103 */     if (BufferedImage.class.isAssignableFrom(dataType)) {
/* 104 */       BufferedImage img = AWTImageTools.makeUnsigned(openImage(no));
/* 105 */       return AWTImageTools.scale(img, getThumbSizeX(), getThumbSizeY(), false);
/*     */     } 
/*     */     
/* 108 */     byte[] thumbBytes = openThumbBytes(no);
/* 109 */     return AWTImageTools.openImage(thumbBytes, (IFormatReader)this, getThumbSizeX(), getThumbSizeY());
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/gui/BufferedImageReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */