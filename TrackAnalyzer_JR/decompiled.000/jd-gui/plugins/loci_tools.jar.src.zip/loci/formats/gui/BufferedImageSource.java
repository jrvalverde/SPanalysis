/*    */ package loci.formats.gui;
/*    */ 
/*    */ import java.awt.image.BufferedImage;
/*    */ import java.io.IOException;
/*    */ import loci.formats.FormatException;
/*    */ import loci.formats.IFormatReader;
/*    */ import loci.formats.cache.CacheException;
/*    */ import loci.formats.cache.ICacheSource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BufferedImageSource
/*    */   implements ICacheSource
/*    */ {
/*    */   protected BufferedImageReader reader;
/*    */   
/*    */   public BufferedImageSource(IFormatReader reader) throws CacheException {
/* 65 */     if (reader instanceof BufferedImageReader) {
/* 66 */       this.reader = (BufferedImageReader)reader;
/*    */     } else {
/*    */       
/* 69 */       this.reader = new BufferedImageReader(reader);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int getObjectCount() {
/* 76 */     return this.reader.getImageCount();
/*    */   }
/*    */   
/*    */   public Object getObject(int index) throws CacheException {
/* 80 */     BufferedImage bi = null;
/*    */     try {
/* 82 */       bi = this.reader.openImage(index);
/*    */     }
/* 84 */     catch (FormatException exc) {
/* 85 */       throw new CacheException(exc);
/*    */     }
/* 87 */     catch (IOException exc) {
/* 88 */       throw new CacheException(exc);
/*    */     } 
/* 90 */     return bi;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/gui/BufferedImageSource.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */