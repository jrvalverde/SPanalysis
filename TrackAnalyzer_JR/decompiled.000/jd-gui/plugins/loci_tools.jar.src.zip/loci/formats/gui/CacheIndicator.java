/*     */ package loci.formats.gui;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.SwingUtilities;
/*     */ import loci.formats.cache.Cache;
/*     */ import loci.formats.cache.CacheEvent;
/*     */ import loci.formats.cache.CacheException;
/*     */ import loci.formats.cache.CacheListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CacheIndicator
/*     */   extends JComponent
/*     */   implements CacheListener
/*     */ {
/*     */   private static final int COMPONENT_WIDTH = 5;
/*     */   private static final int COMPONENT_HEIGHT = 5;
/*     */   private Cache cache;
/*     */   private int axis;
/*     */   private Component comp;
/*     */   private int lPad;
/*     */   private int rPad;
/*     */   
/*     */   public CacheIndicator(Cache cache, int axis) {
/*  78 */     this(cache, axis, (Component)null, 0, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CacheIndicator(Cache cache, int axis, Component comp, int lPad, int rPad) {
/*  89 */     this.cache = cache;
/*  90 */     this.axis = axis;
/*  91 */     this.comp = comp;
/*  92 */     this.lPad = lPad;
/*  93 */     this.rPad = rPad;
/*  94 */     cache.addCacheListener(this);
/*  95 */     setBackground(Color.WHITE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void paintComponent(Graphics g) {
/* 103 */     g.setColor(Color.BLACK);
/* 104 */     int xStart = this.lPad, width = getWidth() - this.lPad - this.rPad;
/* 105 */     g.drawRect(xStart, 0, width - 1, 4);
/*     */     
/* 107 */     int[] lengths = this.cache.getStrategy().getLengths();
/* 108 */     int cacheLength = (this.axis >= 0 && this.axis < lengths.length) ? lengths[this.axis] : 0;
/*     */     
/* 110 */     if (cacheLength == 0)
/*     */       return; 
/* 112 */     int pixelsPerIndex = (width - 2) / cacheLength;
/* 113 */     int remainder = width - 2 - pixelsPerIndex * cacheLength;
/*     */     
/*     */     try {
/* 116 */       int[] currentPos = null;
/* 117 */       int[][] loadList = (int[][])null;
/*     */       
/* 119 */       currentPos = this.cache.getCurrentPos();
/* 120 */       loadList = this.cache.getStrategy().getLoadList(currentPos);
/*     */       
/* 122 */       int[] pos = new int[currentPos.length];
/* 123 */       System.arraycopy(currentPos, 0, pos, 0, pos.length);
/*     */       
/* 125 */       int start = xStart + 1;
/* 126 */       for (int i = 0; i < cacheLength; i++) {
/* 127 */         pos[this.axis] = i;
/*     */         
/* 129 */         boolean inLoadList = false;
/* 130 */         for (int j = 0; j < loadList.length; j++) {
/* 131 */           boolean equal = true;
/* 132 */           for (int k = 0; k < (loadList[j]).length; k++) {
/* 133 */             if (loadList[j][k] != pos[k]) {
/* 134 */               equal = false;
/*     */               break;
/*     */             } 
/*     */           } 
/* 138 */           if (equal) {
/* 139 */             inLoadList = true;
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/* 144 */         boolean inCache = false;
/*     */         
/* 146 */         inCache = this.cache.isInCache(pos);
/*     */         
/* 148 */         if (inCache) { g.setColor(Color.BLUE); }
/* 149 */         else if (inLoadList) { g.setColor(Color.RED); }
/* 150 */         else { g.setColor(Color.WHITE); }
/* 151 */          int len = pixelsPerIndex;
/* 152 */         if (i < remainder) len++; 
/* 153 */         g.fillRect(start, 1, len, getHeight() - 2);
/* 154 */         start += len;
/*     */       } 
/*     */     } catch (CacheException e) {
/* 157 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Dimension getPreferredSize() {
/* 163 */     int w = (this.comp == null) ? 5 : (this.comp.getPreferredSize()).width;
/* 164 */     return new Dimension(w, 5);
/*     */   }
/*     */   
/*     */   public Dimension getMinimumSize() {
/* 168 */     int w = (this.comp == null) ? 5 : (this.comp.getMinimumSize()).width;
/* 169 */     return new Dimension(w, 5);
/*     */   }
/*     */   
/*     */   public Dimension getMaximumSize() {
/* 173 */     int w = (this.comp == null) ? Integer.MAX_VALUE : (this.comp.getMaximumSize()).width;
/* 174 */     return new Dimension(w, 5);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void cacheUpdated(CacheEvent e) {
/* 180 */     if (e.getSource() instanceof Cache) this.cache = (Cache)e.getSource(); 
/* 181 */     int type = e.getType();
/* 182 */     if (type == 7 || type == 8 || !(e.getSource() instanceof Cache))
/*     */     {
/*     */ 
/*     */       
/* 186 */       SwingUtilities.invokeLater(new Runnable() {
/*     */             public void run() {
/* 188 */               CacheIndicator.this.repaint();
/*     */             }
/*     */           });
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/gui/CacheIndicator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */