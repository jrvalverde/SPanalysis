/*     */ package loci.formats.gui;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileFilter;
/*     */ import javax.swing.filechooser.FileFilter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExtensionFileFilter
/*     */   extends FileFilter
/*     */   implements FileFilter, Comparable
/*     */ {
/*     */   private String[] exts;
/*     */   private String desc;
/*     */   
/*     */   public ExtensionFileFilter(String extension, String description) {
/*  66 */     this(new String[] { extension }, description);
/*     */   }
/*     */ 
/*     */   
/*     */   public ExtensionFileFilter(String[] extensions, String description) {
/*  71 */     this.exts = new String[extensions.length];
/*  72 */     System.arraycopy(extensions, 0, this.exts, 0, extensions.length);
/*  73 */     StringBuffer sb = new StringBuffer(description);
/*  74 */     boolean first = true;
/*  75 */     for (int i = 0; i < this.exts.length; i++) {
/*  76 */       if (this.exts[i] == null) this.exts[i] = ""; 
/*  77 */       if (!this.exts[i].equals("")) {
/*  78 */         if (first) {
/*  79 */           sb.append(" (");
/*  80 */           first = false;
/*     */         } else {
/*  82 */           sb.append(", ");
/*  83 */         }  sb.append("*.");
/*  84 */         sb.append(this.exts[i]);
/*     */       } 
/*  86 */     }  if (!first) {
/*  87 */       sb.append(")");
/*     */     }
/*  89 */     this.desc = sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getExtension() {
/*  95 */     return this.exts[0];
/*     */   }
/*     */   public String[] getExtensions() {
/*  98 */     return this.exts;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean accept(File f) {
/* 104 */     if (f.isDirectory()) return true;
/*     */     
/* 106 */     String name = f.getName().toLowerCase();
/*     */     
/* 108 */     for (int i = 0; i < this.exts.length; i++) {
/* 109 */       if (name.endsWith(this.exts[i].toLowerCase())) return true;
/*     */     
/*     */     } 
/* 112 */     return false;
/*     */   }
/*     */   
/*     */   public String getDescription() {
/* 116 */     return this.desc;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 121 */     return "ExtensionFileFilter: " + this.desc;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int compareTo(Object o) {
/* 127 */     return this.desc.compareToIgnoreCase(((FileFilter)o).getDescription());
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/gui/ExtensionFileFilter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */