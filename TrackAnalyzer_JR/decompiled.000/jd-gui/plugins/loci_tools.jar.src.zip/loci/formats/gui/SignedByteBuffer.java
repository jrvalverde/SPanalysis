/*    */ package loci.formats.gui;
/*    */ 
/*    */ import java.awt.image.DataBuffer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SignedByteBuffer
/*    */   extends DataBuffer
/*    */ {
/*    */   private byte[][] bankData;
/*    */   
/*    */   public SignedByteBuffer(byte[] dataArray, int size) {
/* 56 */     super(0, size);
/* 57 */     this.bankData = new byte[1][];
/* 58 */     this.bankData[0] = dataArray;
/*    */   }
/*    */ 
/*    */   
/*    */   public SignedByteBuffer(byte[][] dataArray, int size) {
/* 63 */     super(0, size);
/* 64 */     this.bankData = dataArray;
/*    */   }
/*    */ 
/*    */   
/*    */   public byte[] getData() {
/* 69 */     return this.bankData[0];
/*    */   }
/*    */ 
/*    */   
/*    */   public byte[] getData(int bank) {
/* 74 */     return this.bankData[bank];
/*    */   }
/*    */ 
/*    */   
/*    */   public int getElem(int i) {
/* 79 */     return getElem(0, i);
/*    */   }
/*    */ 
/*    */   
/*    */   public int getElem(int bank, int i) {
/* 84 */     return this.bankData[bank][i + getOffsets()[bank]];
/*    */   }
/*    */ 
/*    */   
/*    */   public void setElem(int i, int val) {
/* 89 */     setElem(0, i, val);
/*    */   }
/*    */ 
/*    */   
/*    */   public void setElem(int bank, int i, int val) {
/* 94 */     this.bankData[bank][i + getOffsets()[bank]] = (byte)val;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/gui/SignedByteBuffer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */