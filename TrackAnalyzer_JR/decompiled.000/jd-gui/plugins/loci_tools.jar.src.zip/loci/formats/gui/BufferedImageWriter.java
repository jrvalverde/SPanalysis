/*     */ package loci.formats.gui;
/*     */ 
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.io.IOException;
/*     */ import loci.formats.FormatException;
/*     */ import loci.formats.FormatTools;
/*     */ import loci.formats.IFormatWriter;
/*     */ import loci.formats.WriterWrapper;
/*     */ import loci.formats.meta.MetadataRetrieve;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BufferedImageWriter
/*     */   extends WriterWrapper
/*     */ {
/*  62 */   private int numWritten = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BufferedImageWriter makeBufferedImageWriter(IFormatWriter w) {
/*  70 */     if (w instanceof BufferedImageWriter) return (BufferedImageWriter)w; 
/*  71 */     return new BufferedImageWriter(w);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public BufferedImageWriter() {}
/*     */ 
/*     */   
/*     */   public BufferedImageWriter(IFormatWriter r) {
/*  80 */     super(r);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void saveImage(int no, BufferedImage image) throws FormatException, IOException {
/*  93 */     saveImage(no, image, 0, 0, image.getWidth(), image.getHeight());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void saveImage(int no, BufferedImage image, int x, int y, int w, int h) throws FormatException, IOException {
/* 110 */     Class<?> dataType = getNativeDataType();
/* 111 */     if (BufferedImage.class.isAssignableFrom(dataType)) {
/*     */       
/* 113 */       savePlane(no, image, x, y, w, h);
/*     */     }
/*     */     else {
/*     */       
/* 117 */       byte[] buf = toBytes(image, (IFormatWriter)this);
/*     */       
/* 119 */       saveBytes(no, buf, x, y, w, h);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 127 */     super.close();
/* 128 */     this.numWritten = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void saveImage(BufferedImage image, boolean last) throws FormatException, IOException {
/* 143 */     saveImage(image, 0, last, last);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void saveImage(BufferedImage image, int series, boolean lastInSeries, boolean last) throws FormatException, IOException {
/* 158 */     setSeries(series);
/* 159 */     saveImage(this.numWritten++, image);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] toBytes(BufferedImage image, IFormatWriter writer) {
/* 165 */     boolean littleEndian = false;
/* 166 */     int bpp = FormatTools.getBytesPerPixel(AWTImageTools.getPixelType(image));
/*     */     
/* 168 */     MetadataRetrieve r = writer.getMetadataRetrieve();
/* 169 */     if (r != null) {
/* 170 */       Boolean bigEndian = r.getPixelsBinDataBigEndian(writer.getSeries(), 0);
/* 171 */       if (bigEndian != null) littleEndian = !bigEndian.booleanValue();
/*     */     
/*     */     } 
/* 174 */     byte[][] pixelBytes = AWTImageTools.getPixelBytes(image, littleEndian);
/* 175 */     byte[] buf = new byte[pixelBytes.length * (pixelBytes[0]).length];
/* 176 */     if (writer.isInterleaved()) {
/* 177 */       int i; for (i = 0; i < (pixelBytes[0]).length; i += bpp) {
/* 178 */         for (int j = 0; j < pixelBytes.length; j++) {
/* 179 */           System.arraycopy(pixelBytes[j], i, buf, i * pixelBytes.length + j * bpp, bpp);
/*     */         }
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 185 */       for (int i = 0; i < pixelBytes.length; i++) {
/* 186 */         System.arraycopy(pixelBytes[i], 0, buf, i * (pixelBytes[0]).length, (pixelBytes[i]).length);
/*     */       }
/*     */     } 
/*     */     
/* 190 */     pixelBytes = (byte[][])null;
/* 191 */     return buf;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/gui/BufferedImageWriter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */