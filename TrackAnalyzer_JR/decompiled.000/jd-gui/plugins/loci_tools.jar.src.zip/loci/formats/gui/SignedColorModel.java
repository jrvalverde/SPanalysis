/*     */ package loci.formats.gui;
/*     */ 
/*     */ import java.awt.image.ColorModel;
/*     */ import java.awt.image.ComponentColorModel;
/*     */ import java.awt.image.ComponentSampleModel;
/*     */ import java.awt.image.DataBuffer;
/*     */ import java.awt.image.DataBufferShort;
/*     */ import java.awt.image.Raster;
/*     */ import java.awt.image.SampleModel;
/*     */ import java.awt.image.WritableRaster;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SignedColorModel
/*     */   extends ColorModel
/*     */ {
/*     */   private int pixelBits;
/*     */   private int nChannels;
/*     */   private ComponentColorModel helper;
/*     */   private int max;
/*     */   
/*     */   public SignedColorModel(int pixelBits, int dataType, int nChannels) throws IOException {
/*  71 */     super(pixelBits, makeBitArray(nChannels, pixelBits), AWTImageTools.makeColorSpace(nChannels), (nChannels == 4), false, 3, dataType);
/*     */ 
/*     */ 
/*     */     
/*  75 */     int type = dataType;
/*  76 */     if (type == 2) {
/*  77 */       type = 1;
/*     */     }
/*     */     
/*  80 */     this.helper = new ComponentColorModel(AWTImageTools.makeColorSpace(nChannels), (nChannels == 4), false, 3, type);
/*     */ 
/*     */     
/*  83 */     this.pixelBits = pixelBits;
/*  84 */     this.nChannels = nChannels;
/*     */     
/*  86 */     this.max = (int)Math.pow(2.0D, pixelBits) - 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized Object getDataElements(int rgb, Object pixel) {
/*  93 */     return this.helper.getDataElements(rgb, pixel);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isCompatibleRaster(Raster raster) {
/*  98 */     if (this.pixelBits == 16) {
/*  99 */       return (raster.getTransferType() == 2);
/*     */     }
/* 101 */     return this.helper.isCompatibleRaster(raster);
/*     */   }
/*     */ 
/*     */   
/*     */   public WritableRaster createCompatibleWritableRaster(int w, int h) {
/* 106 */     if (this.pixelBits == 16) {
/* 107 */       int[] bandOffsets = new int[this.nChannels];
/* 108 */       for (int i = 0; i < this.nChannels; ) { bandOffsets[i] = i; i++; }
/*     */       
/* 110 */       SampleModel m = new ComponentSampleModel(2, w, h, this.nChannels, w * this.nChannels, bandOffsets);
/*     */       
/* 112 */       DataBuffer db = new DataBufferShort(w * h, this.nChannels);
/* 113 */       return Raster.createWritableRaster(m, db, null);
/*     */     } 
/* 115 */     return this.helper.createCompatibleWritableRaster(w, h);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getAlpha(int pixel) {
/* 120 */     if (this.nChannels < 4) return 255; 
/* 121 */     return rescale(pixel, this.max);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getBlue(int pixel) {
/* 126 */     if (this.nChannels == 1) return getRed(pixel); 
/* 127 */     return rescale(pixel, this.max);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getGreen(int pixel) {
/* 132 */     if (this.nChannels == 1) return getRed(pixel); 
/* 133 */     return rescale(pixel, this.max);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getRed(int pixel) {
/* 138 */     return rescale(pixel, this.max);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getAlpha(Object data) {
/* 143 */     if (data instanceof byte[]) {
/* 144 */       byte[] b = (byte[])data;
/* 145 */       if (b.length == 1) return getAlpha(b[0]); 
/* 146 */       return rescale((b.length == 4) ? b[0] : this.max, this.max);
/*     */     } 
/* 148 */     if (data instanceof short[]) {
/* 149 */       short[] s = (short[])data;
/* 150 */       if (s.length == 1) return getAlpha(s[0]); 
/* 151 */       return rescale((s.length == 4) ? s[0] : this.max, this.max);
/*     */     } 
/* 153 */     if (data instanceof int[]) {
/* 154 */       int[] i = (int[])data;
/* 155 */       if (i.length == 1) return getAlpha(i[0]); 
/* 156 */       return rescale((i.length == 4) ? i[0] : this.max, this.max);
/*     */     } 
/* 158 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getRed(Object data) {
/* 163 */     if (data instanceof byte[]) {
/* 164 */       byte[] b = (byte[])data;
/* 165 */       if (b.length == 1) return getRed(b[0]); 
/* 166 */       return rescale((b.length != 4) ? b[0] : b[1]);
/*     */     } 
/* 168 */     if (data instanceof short[]) {
/* 169 */       short[] s = (short[])data;
/* 170 */       if (s.length == 1) return getRed(s[0]); 
/* 171 */       return rescale((s.length != 4) ? s[0] : s[1], this.max);
/*     */     } 
/* 173 */     if (data instanceof int[]) {
/* 174 */       int[] i = (int[])data;
/* 175 */       if (i.length == 1) return getRed(i[0]); 
/* 176 */       return rescale((i.length != 4) ? i[0] : i[1], this.max);
/*     */     } 
/* 178 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getGreen(Object data) {
/* 183 */     if (data instanceof byte[]) {
/* 184 */       byte[] b = (byte[])data;
/* 185 */       if (b.length == 1) return getGreen(b[0]); 
/* 186 */       return rescale((b.length != 4) ? b[1] : b[2]);
/*     */     } 
/* 188 */     if (data instanceof short[]) {
/* 189 */       short[] s = (short[])data;
/* 190 */       if (s.length == 1) return getGreen(s[0]); 
/* 191 */       return rescale((s.length != 4) ? s[1] : s[2], this.max);
/*     */     } 
/* 193 */     if (data instanceof int[]) {
/* 194 */       int[] i = (int[])data;
/* 195 */       if (i.length == 1) return getGreen(i[0]); 
/* 196 */       return rescale((i.length != 4) ? i[1] : i[2], this.max);
/*     */     } 
/* 198 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getBlue(Object data) {
/* 203 */     if (data instanceof byte[]) {
/* 204 */       byte[] b = (byte[])data;
/* 205 */       if (b.length == 1) return getBlue(b[0]); 
/* 206 */       return rescale((b.length > 2) ? b[b.length - 1] : 0);
/*     */     } 
/* 208 */     if (data instanceof short[]) {
/* 209 */       short[] s = (short[])data;
/* 210 */       if (s.length == 1) return getBlue(s[0]); 
/* 211 */       return rescale((s.length > 2) ? s[s.length - 1] : 0, this.max);
/*     */     } 
/* 213 */     if (data instanceof int[]) {
/* 214 */       int[] i = (int[])data;
/* 215 */       if (i.length == 1) return getBlue(i[0]); 
/* 216 */       return rescale((i.length > 2) ? i[i.length - 1] : 0, this.max);
/*     */     } 
/* 218 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private int rescale(int value, int max) {
/* 224 */     float v = value / max;
/* 225 */     v *= 255.0F;
/* 226 */     return rescale((int)v);
/*     */   }
/*     */   
/*     */   private int rescale(int value) {
/* 230 */     if (value < 128) {
/* 231 */       value += 128;
/*     */     } else {
/*     */       
/* 234 */       value -= 128;
/*     */     } 
/* 236 */     return value;
/*     */   }
/*     */   
/*     */   private static int[] makeBitArray(int nChannels, int nBits) {
/* 240 */     int[] bits = new int[nChannels];
/* 241 */     for (int i = 0; i < bits.length; i++) {
/* 242 */       bits[i] = nBits;
/*     */     }
/* 244 */     return bits;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/gui/SignedColorModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */