/*     */ package loci.formats.gui;
/*     */ 
/*     */ import java.awt.Dimension;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import javax.swing.Box;
/*     */ import javax.swing.BoxLayout;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JFileChooser;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JProgressBar;
/*     */ import javax.swing.JSpinner;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.SpinnerNumberModel;
/*     */ import javax.swing.border.EmptyBorder;
/*     */ import javax.swing.event.ChangeEvent;
/*     */ import javax.swing.event.ChangeListener;
/*     */ import loci.formats.DimensionSwapper;
/*     */ import loci.formats.FilePattern;
/*     */ import loci.formats.FileStitcher;
/*     */ import loci.formats.FormatException;
/*     */ import loci.formats.FormatTools;
/*     */ import loci.formats.IFormatHandler;
/*     */ import loci.formats.IFormatReader;
/*     */ import loci.formats.IFormatWriter;
/*     */ import loci.formats.ImageWriter;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataConverter
/*     */   extends JFrame
/*     */   implements ActionListener, ChangeListener, Runnable
/*     */ {
/*  91 */   private static final Logger LOGGER = LoggerFactory.getLogger(DataConverter.class);
/*     */ 
/*     */   
/*     */   private static final String TITLE = "Data Converter";
/*     */ 
/*     */   
/*     */   private static final int COLUMNS = 24;
/*     */ 
/*     */   
/* 100 */   private FileStitcher reader = new FileStitcher(true);
/* 101 */   private DimensionSwapper swap = new DimensionSwapper((IFormatReader)this.reader);
/* 102 */   private BufferedImageReader biReader = new BufferedImageReader((IFormatReader)this.swap);
/* 103 */   private ImageWriter writer = new ImageWriter();
/* 104 */   private BufferedImageWriter biWriter = new BufferedImageWriter((IFormatWriter)this.writer);
/*     */   
/*     */   private JFileChooser rc;
/*     */   
/*     */   private JFileChooser wc;
/*     */   private boolean shutdown;
/*     */   private boolean force = true;
/*     */   private JTextField input;
/*     */   private JTextField output;
/*     */   private JCheckBox qtJava;
/*     */   private JCheckBox forceType;
/*     */   private JCheckBox includeZ;
/*     */   private JCheckBox includeT;
/*     */   private JCheckBox includeC;
/*     */   
/*     */   public DataConverter() {
/* 120 */     super("Data Converter");
/*     */ 
/*     */     
/* 123 */     this.rc = GUITools.buildFileChooser((IFormatHandler)this.swap);
/* 124 */     this.wc = GUITools.buildFileChooser((IFormatHandler)this.writer);
/*     */     
/* 126 */     JPanel pane = new JPanel();
/* 127 */     pane.setBorder(new EmptyBorder(5, 5, 5, 5));
/* 128 */     pane.setLayout(new BoxLayout(pane, 1));
/* 129 */     setContentPane(pane);
/*     */ 
/*     */ 
/*     */     
/* 133 */     JPanel row1 = new RowPanel();
/* 134 */     row1.setLayout(new BoxLayout(row1, 0));
/* 135 */     pane.add(row1);
/*     */     
/* 137 */     pane.add(Box.createVerticalStrut(4));
/*     */     
/* 139 */     JLabel inputLabel = new JLabel("Input");
/* 140 */     row1.add(inputLabel);
/*     */     
/* 142 */     row1.add(Box.createHorizontalStrut(4));
/*     */     
/* 144 */     this.input = new JTextField(24);
/* 145 */     this.input.setEditable(false);
/* 146 */     row1.add(this.input);
/* 147 */     limitHeight(this.input);
/*     */     
/* 149 */     row1.add(Box.createHorizontalStrut(4));
/*     */     
/* 151 */     JButton chooseInput = new JButton("Choose");
/* 152 */     row1.add(chooseInput);
/* 153 */     chooseInput.setActionCommand("input");
/* 154 */     chooseInput.addActionListener(this);
/*     */     
/* 156 */     row1.add(Box.createHorizontalStrut(4));
/*     */ 
/*     */ 
/*     */     
/* 160 */     JPanel row2 = new RowPanel();
/* 161 */     row2.setLayout(new BoxLayout(row2, 0));
/* 162 */     pane.add(row2);
/*     */     
/* 164 */     pane.add(Box.createVerticalStrut(9));
/*     */     
/* 166 */     JLabel outputLabel = new JLabel("Output");
/* 167 */     row2.add(outputLabel);
/* 168 */     inputLabel.setPreferredSize(outputLabel.getPreferredSize());
/*     */     
/* 170 */     row2.add(Box.createHorizontalStrut(4));
/*     */     
/* 172 */     this.output = new JTextField(24);
/* 173 */     this.output.setEditable(false);
/* 174 */     row2.add(this.output);
/* 175 */     limitHeight(this.output);
/*     */     
/* 177 */     row2.add(Box.createHorizontalStrut(4));
/*     */     
/* 179 */     JButton chooseOutput = new JButton("Choose");
/* 180 */     row2.add(chooseOutput);
/* 181 */     chooseOutput.setActionCommand("output");
/* 182 */     chooseOutput.addActionListener(this);
/*     */     
/* 184 */     row2.add(Box.createHorizontalStrut(4));
/*     */ 
/*     */     
/* 187 */     this.seriesRow = new RowPanel();
/* 188 */     this.seriesRow.setLayout(new BoxLayout(this.seriesRow, 0));
/* 189 */     pane.add(this.seriesRow);
/*     */ 
/*     */ 
/*     */     
/* 193 */     JPanel row3 = new RowPanel();
/* 194 */     row3.setLayout(new BoxLayout(row3, 0));
/* 195 */     pane.add(row3);
/*     */     
/* 197 */     pane.add(Box.createVerticalStrut(9));
/*     */     
/* 199 */     String[] axisNames = { "Time", "Slice", "Channel" };
/*     */     
/* 201 */     this.zLabel = new JLabel(" 1) Slice       <0-0>");
/* 202 */     this.tLabel = new JLabel(" 2) Time      <0-0>");
/* 203 */     this.cLabel = new JLabel(" 3) Channel <0-0>");
/*     */     
/* 205 */     this.zChoice = new JComboBox<String>(axisNames);
/* 206 */     this.zChoice.setSelectedIndex(1);
/* 207 */     this.zChoice.setPreferredSize(new Dimension(5, 9));
/* 208 */     this.zChoice.setActionCommand("zChoice");
/* 209 */     this.zChoice.addActionListener(this);
/*     */     
/* 211 */     this.tChoice = new JComboBox<String>(axisNames);
/* 212 */     this.tChoice.setSelectedIndex(0);
/* 213 */     this.tChoice.setPreferredSize(new Dimension(5, 9));
/* 214 */     this.tChoice.setActionCommand("tChoice");
/* 215 */     this.tChoice.addActionListener(this);
/*     */     
/* 217 */     this.cChoice = new JComboBox<String>(axisNames);
/* 218 */     this.cChoice.setSelectedIndex(2);
/* 219 */     this.cChoice.setPreferredSize(new Dimension(5, 9));
/* 220 */     this.cChoice.setActionCommand("cChoice");
/* 221 */     this.cChoice.addActionListener(this);
/*     */     
/* 223 */     this.includeZ = new JCheckBox("Include in file");
/* 224 */     this.includeZ.setEnabled(false);
/* 225 */     this.includeT = new JCheckBox("Include in file");
/* 226 */     this.includeT.setEnabled(false);
/* 227 */     this.includeC = new JCheckBox("Include in file");
/* 228 */     this.includeC.setEnabled(false);
/*     */     
/* 230 */     row3.add(this.zLabel);
/* 231 */     row3.add(this.zChoice);
/* 232 */     row3.add(this.includeZ);
/* 233 */     row3.add(Box.createHorizontalStrut(4));
/*     */     
/* 235 */     row3 = new RowPanel();
/* 236 */     row3.setLayout(new BoxLayout(row3, 0));
/* 237 */     pane.add(row3);
/* 238 */     pane.add(Box.createVerticalStrut(9));
/*     */     
/* 240 */     row3.add(this.tLabel);
/* 241 */     row3.add(this.tChoice);
/* 242 */     row3.add(this.includeT);
/* 243 */     row3.add(Box.createHorizontalStrut(4));
/*     */     
/* 245 */     row3 = new RowPanel();
/* 246 */     row3.setLayout(new BoxLayout(row3, 0));
/* 247 */     pane.add(row3);
/* 248 */     pane.add(Box.createVerticalStrut(9));
/*     */     
/* 250 */     row3.add(this.cLabel);
/* 251 */     row3.add(this.cChoice);
/* 252 */     row3.add(this.includeC);
/*     */     
/* 254 */     row3.add(Box.createHorizontalStrut(4));
/*     */ 
/*     */ 
/*     */     
/* 258 */     JPanel row4 = new RowPanel();
/* 259 */     row4.setLayout(new BoxLayout(row4, 0));
/* 260 */     pane.add(row4);
/*     */     
/* 262 */     pane.add(Box.createVerticalStrut(9));
/*     */     
/* 264 */     JLabel fpsLabel = new JLabel("Frames per second: ");
/* 265 */     row4.add(fpsLabel);
/* 266 */     this.fps = new JSpinner(new SpinnerNumberModel(10, 1, 100, 1));
/* 267 */     row4.add(this.fps);
/* 268 */     row4.add(Box.createHorizontalStrut(3));
/*     */     
/* 270 */     JLabel codecLabel = new JLabel("Output compression type: ");
/* 271 */     row4.add(codecLabel);
/* 272 */     this.codec = new JComboBox<String>(new String[0]);
/* 273 */     row4.add(this.codec);
/*     */ 
/*     */ 
/*     */     
/* 277 */     JPanel row5 = new RowPanel();
/* 278 */     row5.setLayout(new BoxLayout(row5, 0));
/* 279 */     pane.add(row5);
/*     */     
/* 281 */     pane.add(Box.createVerticalStrut(9));
/*     */     
/* 283 */     boolean canDoQT = (new LegacyQTTools()).canDoQT();
/* 284 */     this.qtJava = new JCheckBox("Use QTJava", canDoQT);
/* 285 */     this.qtJava.setEnabled(canDoQT);
/* 286 */     row5.add(this.qtJava);
/*     */     
/* 288 */     row5.add(Box.createHorizontalStrut(3));
/*     */     
/* 290 */     this.forceType = new JCheckBox("Force", true);
/* 291 */     this.forceType.setActionCommand("force");
/* 292 */     this.forceType.addActionListener(this);
/* 293 */     row5.add(this.forceType);
/*     */     
/* 295 */     row5.add(Box.createHorizontalStrut(3));
/* 296 */     row5.add(Box.createHorizontalGlue());
/*     */     
/* 298 */     this.convert = new JButton("Convert");
/* 299 */     row5.add(this.convert);
/* 300 */     this.convert.setActionCommand("convert");
/* 301 */     this.convert.addActionListener(this);
/*     */     
/* 303 */     row5.add(Box.createHorizontalStrut(4));
/*     */     
/* 305 */     JButton quit = new JButton("Quit");
/* 306 */     row5.add(quit);
/* 307 */     quit.setActionCommand("quit");
/* 308 */     quit.addActionListener(this);
/*     */ 
/*     */ 
/*     */     
/* 312 */     JPanel row6 = new RowPanel();
/* 313 */     row6.setLayout(new BoxLayout(row6, 0));
/* 314 */     pane.add(row6);
/*     */     
/* 316 */     this.progress = new JProgressBar();
/* 317 */     this.progress.setString("");
/* 318 */     this.progress.setStringPainted(true);
/* 319 */     row6.add(this.progress);
/*     */     
/* 321 */     row6.add(Box.createHorizontalStrut(8));
/*     */     
/* 323 */     JLabel version = new JLabel("Built on " + FormatTools.DATE);
/* 324 */     version.setFont(version.getFont().deriveFont(2));
/* 325 */     row6.add(version);
/*     */     
/* 327 */     setDefaultCloseOperation(2);
/* 328 */     setLocation(100, 100);
/* 329 */     pack();
/*     */   }
/*     */   private JLabel zLabel; private JLabel tLabel; private JLabel cLabel; private JComboBox zChoice; private JComboBox tChoice; private JComboBox cChoice; private JComboBox codec; private JSpinner fps; private JSpinner series; private JPanel seriesRow; private JProgressBar progress;
/*     */   private JButton convert;
/*     */   
/*     */   public void actionPerformed(ActionEvent e) {
/* 335 */     String cmd = e.getActionCommand();
/* 336 */     if ("input".equals(cmd))
/* 337 */     { int rval = this.rc.showOpenDialog(this);
/* 338 */       if (rval != 0)
/* 339 */         return;  File file = this.rc.getSelectedFile();
/* 340 */       if (file != null) this.wc.setCurrentDirectory(file); 
/* 341 */       String pattern = FilePattern.findPattern(file);
/* 342 */       this.input.setText(pattern);
/*     */ 
/*     */       
/* 345 */       try { this.swap.setId(pattern);
/*     */         
/* 347 */         if (this.swap.getSeriesCount() > 1 && this.series == null) {
/* 348 */           JLabel seriesLabel = new JLabel("Series: ");
/* 349 */           this.series = new JSpinner(new SpinnerNumberModel(1, 1, this.swap.getSeriesCount(), 1));
/*     */           
/* 351 */           this.series.addChangeListener(this);
/* 352 */           this.seriesRow.add(seriesLabel);
/* 353 */           this.seriesRow.add(this.series);
/* 354 */           pack();
/*     */         }
/* 356 */         else if (this.series != null) {
/* 357 */           ((SpinnerNumberModel)this.series.getModel()).setMaximum(new Integer(this.swap.getSeriesCount()));
/*     */           
/* 359 */           pack();
/*     */         }
/* 361 */         else if (this.swap.getSeriesCount() == 1 && this.series != null) {
/* 362 */           this.seriesRow.remove(this.series);
/* 363 */           this.series = null;
/* 364 */           pack();
/*     */         }  }
/*     */       catch (FormatException exc)
/* 367 */       { LOGGER.info("", (Throwable)exc); }
/* 368 */       catch (IOException exc) { LOGGER.info("", exc); }
/*     */       
/* 370 */       updateLabels(pattern); }
/*     */     
/* 372 */     else if ("output".equals(cmd))
/* 373 */     { int rval = this.wc.showSaveDialog(this);
/* 374 */       if (rval != 0)
/* 375 */         return;  File file = this.wc.getSelectedFile();
/* 376 */       if (file != null) this.rc.setCurrentDirectory(file); 
/* 377 */       String s = file.getPath();
/* 378 */       this.output.setText(s);
/*     */       
/* 380 */       try { this.writer.setId(s);
/* 381 */         if (!this.writer.canDoStacks()) {
/* 382 */           this.includeZ.setEnabled(false);
/* 383 */           this.includeT.setEnabled(false);
/* 384 */           this.includeC.setEnabled(false);
/*     */         } 
/* 386 */         this.codec.removeAllItems();
/* 387 */         String[] codecs = this.writer.getWriter().getCompressionTypes();
/* 388 */         if (codecs == null) codecs = new String[] { "Uncompressed" }; 
/* 389 */         for (int i = 0; i < codecs.length; i++) {
/* 390 */           this.codec.addItem(codecs[i]);
/*     */         } }
/*     */       catch (FormatException exc)
/* 393 */       { LOGGER.info("", (Throwable)exc); }
/* 394 */       catch (IOException exc) { LOGGER.info("", exc); }
/*     */        }
/* 396 */     else if ("zChoice".equals(cmd))
/* 397 */     { String newName = (String)this.zChoice.getSelectedItem();
/* 398 */       String label = this.zLabel.getText();
/* 399 */       String oldName = label.substring(4, label.indexOf(" ", 4));
/* 400 */       label = label.replaceAll(oldName, newName);
/* 401 */       this.zLabel.setText(label); }
/*     */     
/* 403 */     else if ("tChoice".equals(cmd))
/* 404 */     { String newName = (String)this.tChoice.getSelectedItem();
/* 405 */       String label = this.tLabel.getText();
/* 406 */       String oldName = label.substring(4, label.indexOf(" ", 4));
/* 407 */       label = label.replaceAll(oldName, newName);
/* 408 */       this.tLabel.setText(label); }
/*     */     
/* 410 */     else if ("cChoice".equals(cmd))
/* 411 */     { String newName = (String)this.cChoice.getSelectedItem();
/* 412 */       String label = this.cLabel.getText();
/* 413 */       String oldName = label.substring(4, label.indexOf(" ", 4));
/* 414 */       label = label.replaceAll(oldName, newName);
/* 415 */       this.cLabel.setText(label); }
/*     */     
/* 417 */     else if ("convert".equals(cmd)) { (new Thread(this, "Converter")).start(); }
/* 418 */     else if ("force".equals(cmd))
/* 419 */     { this.force = this.forceType.isSelected(); }
/*     */     
/* 421 */     else if ("quit".equals(cmd))
/* 422 */     { this.shutdown = true;
/* 423 */       (new Thread("Quitter") { public void run() {
/* 424 */             DataConverter.this.dispose();
/*     */           } }
/*     */         ).start(); }
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   public void stateChanged(ChangeEvent e) {
/* 432 */     if (e.getSource() == this.series) {
/* 433 */       this.swap.setSeries(((Integer)this.series.getValue()).intValue() - 1);
/* 434 */       updateLabels(this.input.getText());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void run() {
/* 441 */     this.convert.setEnabled(false);
/* 442 */     this.includeZ.setEnabled(false);
/* 443 */     this.includeT.setEnabled(false);
/* 444 */     this.includeC.setEnabled(false);
/* 445 */     this.zChoice.setEnabled(false);
/* 446 */     this.tChoice.setEnabled(false);
/* 447 */     this.cChoice.setEnabled(false);
/* 448 */     this.input.setEditable(false);
/* 449 */     this.fps.setEnabled(false);
/* 450 */     if (this.series != null) this.series.setEnabled(false); 
/* 451 */     this.forceType.setEnabled(false);
/* 452 */     this.codec.setEnabled(false);
/*     */     
/* 454 */     this.progress.setString("Getting ready");
/*     */     try {
/* 456 */       String in = this.input.getText();
/* 457 */       String out = this.output.getText();
/* 458 */       if (in.trim().equals("")) {
/* 459 */         msg("Please specify input files.");
/* 460 */         this.convert.setEnabled(true);
/* 461 */         this.progress.setString("");
/*     */         return;
/*     */       } 
/* 464 */       if (out.trim().equals("")) {
/* 465 */         File f = new File(in);
/* 466 */         String name = (new FilePattern(in)).getPrefix();
/* 467 */         String stitchDir = name + "-stitched";
/* 468 */         (new File(f.getParent() + File.separator + stitchDir)).mkdir();
/* 469 */         out = f.getParent() + File.separator + stitchDir + File.separator + name + ".tif";
/*     */         
/* 471 */         out = out.replaceAll(File.separator + File.separator, File.separator);
/* 472 */         this.output.setText(out);
/*     */       } 
/* 474 */       this.output.setEditable(false);
/*     */       
/* 476 */       this.swap.setId(in);
/* 477 */       if (this.series != null) {
/* 478 */         this.swap.setSeries(((Integer)this.series.getValue()).intValue() - 1);
/*     */       }
/*     */       
/* 481 */       this.writer.setFramesPerSecond(((Integer)this.fps.getValue()).intValue());
/*     */       try {
/* 483 */         this.writer.getWriter(out).setCompression((String)this.codec.getSelectedItem());
/*     */       }
/* 485 */       catch (NullPointerException npe) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 493 */       String order = this.swap.getDimensionOrder();
/*     */       
/* 495 */       if (this.zLabel.getText().indexOf("Time") != -1) {
/* 496 */         order = order.replace('Z', 'T');
/*     */       }
/* 498 */       else if (this.zLabel.getText().indexOf("Channel") != -1) {
/* 499 */         order = order.replace('Z', 'C');
/*     */       } 
/*     */       
/* 502 */       if (this.tLabel.getText().indexOf("Slice") != -1) {
/* 503 */         order = order.replace('T', 'Z');
/*     */       }
/* 505 */       else if (this.tLabel.getText().indexOf("Channel") != -1) {
/* 506 */         order = order.replace('T', 'C');
/*     */       } 
/*     */       
/* 509 */       if (this.cLabel.getText().indexOf("Time") != -1) {
/* 510 */         order = order.replace('C', 'T');
/*     */       }
/* 512 */       else if (this.cLabel.getText().indexOf("Slice") != -1) {
/* 513 */         order = order.replace('C', 'Z');
/*     */       } 
/*     */       
/* 516 */       this.swap.swapDimensions(order);
/*     */ 
/*     */ 
/*     */       
/* 520 */       int internalZ = this.includeZ.isSelected() ? this.swap.getSizeZ() : 1;
/* 521 */       int internalT = this.includeT.isSelected() ? this.swap.getSizeT() : 1;
/* 522 */       int internalC = this.includeC.isSelected() ? this.swap.getEffectiveSizeC() : 1;
/*     */       
/* 524 */       int externalZ = this.includeZ.isSelected() ? 1 : this.swap.getSizeZ();
/* 525 */       int externalT = this.includeT.isSelected() ? 1 : this.swap.getSizeT();
/* 526 */       int externalC = this.includeC.isSelected() ? 1 : this.swap.getEffectiveSizeC();
/*     */       
/* 528 */       int zDigits = ("" + externalZ).length();
/* 529 */       int tDigits = ("" + externalT).length();
/* 530 */       int cDigits = ("" + externalC).length();
/*     */       
/* 532 */       this.progress.setMaximum(2 * this.swap.getImageCount());
/*     */       
/* 534 */       int star = out.lastIndexOf(".");
/* 535 */       if (star < 0) star = out.length(); 
/* 536 */       String pre = out.substring(0, star);
/* 537 */       String post = out.substring(star);
/*     */ 
/*     */ 
/*     */       
/* 541 */       int type = this.swap.getPixelType();
/* 542 */       this.writer.setId(out);
/* 543 */       if (this.force && !this.writer.isSupportedType(type)) {
/* 544 */         int[] types = this.writer.getPixelTypes();
/* 545 */         for (int j = 0; j < types.length; j++) {
/* 546 */           if (types[j] > type) {
/* 547 */             if (j == 0) {
/* 548 */               type = types[j];
/*     */               
/*     */               break;
/*     */             } 
/* 552 */             type = types[j - 1];
/*     */             
/*     */             break;
/*     */           } 
/* 556 */           if (j == types.length - 1) type = types[j];
/*     */         
/*     */         } 
/* 559 */       } else if (!this.force && !this.writer.isSupportedType(type)) {
/* 560 */         throw new FormatException("Unsupported pixel type: " + FormatTools.getPixelTypeString(type) + "\nTo write to this format, the \"force\" box must be checked.\n" + "This may result in a loss of precision; for best results, " + "convert to TIFF instead.");
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 567 */       long start = System.currentTimeMillis();
/* 568 */       int plane = 0;
/*     */       
/* 570 */       for (int i = 0; i < externalZ; i++) {
/* 571 */         for (int j = 0; j < externalT; j++) {
/* 572 */           for (int k = 0; k < externalC; k++) {
/*     */             
/* 574 */             String zBlock = "";
/* 575 */             String tBlock = "";
/* 576 */             String cBlock = "";
/*     */             
/* 578 */             if (externalZ > 1) {
/* 579 */               String num = "" + i;
/* 580 */               for (; num.length() < zDigits; num = "0" + num);
/* 581 */               zBlock = "Z" + num + "_";
/*     */             } 
/* 583 */             if (externalT > 1) {
/* 584 */               String num = "" + j;
/* 585 */               for (; num.length() < tDigits; num = "0" + num);
/* 586 */               tBlock = "T" + num + "_";
/*     */             } 
/* 588 */             if (externalC > 1) {
/* 589 */               String num = "" + k;
/* 590 */               for (; num.length() < cDigits; num = "0" + num);
/* 591 */               cBlock = "C" + num;
/*     */             } 
/*     */             
/* 594 */             String outFile = pre;
/* 595 */             if (zBlock.length() > 1) outFile = outFile + zBlock; 
/* 596 */             if (tBlock.length() > 1) outFile = outFile + tBlock; 
/* 597 */             if (cBlock.length() > 1) outFile = outFile + cBlock; 
/* 598 */             if (outFile.endsWith("_")) {
/* 599 */               outFile = outFile.substring(0, outFile.length() - 1);
/*     */             }
/* 601 */             outFile = outFile + post;
/*     */             
/* 603 */             String outName = (new File(outFile)).getName();
/*     */             
/* 605 */             int planesPerFile = internalZ * internalT * internalC;
/* 606 */             int filePlane = 0;
/*     */             
/* 608 */             for (int z = 0; z < internalZ; z++) {
/* 609 */               for (int t = 0; t < internalT; t++) {
/* 610 */                 for (int c = 0; c < internalC; c++) {
/* 611 */                   int zPos = z * externalZ + i;
/* 612 */                   int tPos = t * externalT + j;
/* 613 */                   int cPos = c * externalC + k;
/*     */                   
/* 615 */                   this.progress.setString(outName + " " + (filePlane + 1) + "/" + planesPerFile);
/*     */                   
/* 617 */                   filePlane++;
/* 618 */                   this.progress.setValue(2 * (plane + 1));
/* 619 */                   plane++;
/* 620 */                   int ndx = this.swap.getIndex(zPos, cPos, tPos);
/*     */                   
/* 622 */                   BufferedImage img = this.biReader.openImage(ndx);
/* 623 */                   this.writer.setId(out);
/* 624 */                   if (this.force && !this.writer.isSupportedType(this.swap.getPixelType())) {
/* 625 */                     int pixelType = 0;
/* 626 */                     switch (type) {
/*     */                       case 0:
/*     */                       case 1:
/* 629 */                         pixelType = 0;
/*     */                         break;
/*     */                       case 2:
/* 632 */                         pixelType = 1;
/*     */                         break;
/*     */                       case 3:
/* 635 */                         pixelType = 2;
/*     */                         break;
/*     */                       case 4:
/*     */                       case 5:
/* 639 */                         pixelType = 3;
/*     */                         break;
/*     */                       case 6:
/* 642 */                         pixelType = 4;
/*     */                         break;
/*     */                       case 7:
/* 645 */                         pixelType = 5;
/*     */                         break;
/*     */                     } 
/*     */ 
/*     */ 
/*     */                   
/*     */                   } 
/* 652 */                   this.writer.setId(outFile);
/* 653 */                   this.biWriter.savePlane(filePlane, img);
/* 654 */                   if (this.shutdown)
/*     */                     break; 
/*     */                 } 
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/* 662 */       this.progress.setValue(2 * this.swap.getImageCount());
/* 663 */       this.progress.setString("Finishing");
/* 664 */       if (this.writer != null) this.writer.close();
/*     */       
/* 666 */       long end = System.currentTimeMillis();
/* 667 */       double time = (end - start) / 1000.0D;
/* 668 */       long avg = (end - start) / this.swap.getImageCount();
/* 669 */       this.progress.setString(time + " s elapsed (" + avg + " ms/plane)");
/* 670 */       this.progress.setValue(0);
/* 671 */       if (this.swap != null) this.swap.close();
/*     */     
/* 673 */     } catch (FormatException exc) {
/* 674 */       LOGGER.info("", (Throwable)exc);
/* 675 */       String err = exc.getMessage();
/* 676 */       if (err == null) err = exc.getClass().getName(); 
/* 677 */       msg("Sorry, an error occurred: " + err);
/* 678 */       this.progress.setString("");
/* 679 */       this.progress.setValue(0);
/*     */     }
/* 681 */     catch (IOException exc) {
/* 682 */       LOGGER.info("", exc);
/* 683 */       String err = exc.getMessage();
/* 684 */       if (err == null) err = exc.getClass().getName(); 
/* 685 */       msg("Sorry, an error occurred: " + err);
/* 686 */       this.progress.setString("");
/* 687 */       this.progress.setValue(0);
/*     */     } 
/* 689 */     this.convert.setEnabled(true);
/* 690 */     this.includeZ.setEnabled(true);
/* 691 */     this.includeT.setEnabled(true);
/* 692 */     this.includeC.setEnabled(true);
/* 693 */     this.zChoice.setEnabled(true);
/* 694 */     this.tChoice.setEnabled(true);
/* 695 */     this.cChoice.setEnabled(true);
/* 696 */     this.input.setEditable(true);
/* 697 */     this.output.setEditable(true);
/* 698 */     this.fps.setEnabled(true);
/* 699 */     if (this.series != null) this.series.setEnabled(true); 
/* 700 */     this.forceType.setEnabled(true);
/* 701 */     this.codec.setEnabled(true);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void limitHeight(JComponent jc) {
/* 707 */     int w = (jc.getMaximumSize()).width;
/* 708 */     int h = (jc.getPreferredSize()).height;
/* 709 */     jc.setMaximumSize(new Dimension(w, h));
/*     */   }
/*     */   
/*     */   private void msg(String msg) {
/* 713 */     JOptionPane.showMessageDialog(this, msg, "Data Converter", 0);
/*     */   }
/*     */   
/*     */   private void updateLabels(String pattern) {
/*     */     
/* 718 */     try { this.swap.setId(pattern);
/*     */       
/* 720 */       String z = this.zLabel.getText();
/* 721 */       z = z.substring(0, z.indexOf("<"));
/* 722 */       z = z + "<1-" + this.swap.getSizeZ() + ">";
/* 723 */       this.zLabel.setText(z);
/*     */       
/* 725 */       String t = this.tLabel.getText();
/* 726 */       t = t.substring(0, t.indexOf("<"));
/* 727 */       t = t + "<1-" + this.swap.getSizeT() + ">";
/* 728 */       this.tLabel.setText(t);
/*     */       
/* 730 */       String c = this.cLabel.getText();
/* 731 */       c = c.substring(0, c.indexOf("<"));
/* 732 */       c = c + "<1-" + this.swap.getEffectiveSizeC() + ">";
/* 733 */       this.cLabel.setText(c);
/*     */       
/* 735 */       this.includeZ.setEnabled(true);
/* 736 */       this.includeT.setEnabled(true);
/* 737 */       this.includeC.setEnabled(true); }
/*     */     catch (FormatException exc)
/* 739 */     { LOGGER.info("", (Throwable)exc); }
/* 740 */     catch (IOException exc) { LOGGER.info("", exc); }
/*     */   
/*     */   }
/*     */   
/*     */   private class RowPanel extends JPanel { private RowPanel() {}
/*     */     
/*     */     public Dimension getMaximumSize() {
/* 747 */       int w = (super.getMaximumSize()).width;
/* 748 */       int h = (getPreferredSize()).height;
/* 749 */       return new Dimension(w, h);
/*     */     } }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {
/* 756 */     (new DataConverter()).setVisible(true);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/gui/DataConverter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */