/*     */ package loci.formats.gui;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileFilter;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Vector;
/*     */ import javax.swing.filechooser.FileFilter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ComboFileFilter
/*     */   extends FileFilter
/*     */   implements FileFilter, Comparable
/*     */ {
/*     */   private FileFilter[] filts;
/*     */   private String desc;
/*     */   
/*     */   public ComboFileFilter(FileFilter[] filters, String description) {
/*  69 */     this.filts = new FileFilter[filters.length];
/*  70 */     System.arraycopy(filters, 0, this.filts, 0, filters.length);
/*  71 */     this.desc = description;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FileFilter[] getFilters() {
/*  78 */     FileFilter[] ff = new FileFilter[this.filts.length];
/*  79 */     System.arraycopy(this.filts, 0, ff, 0, this.filts.length);
/*  80 */     return ff;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static FileFilter[] sortFilters(FileFilter[] filters) {
/*  91 */     return sortFilters(new Vector(Arrays.asList((Object[])filters)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static FileFilter[] sortFilters(Vector<Comparable> filters) {
/* 101 */     Collections.sort(filters);
/*     */ 
/*     */     
/* 104 */     int len = filters.size();
/* 105 */     Vector<ComboFileFilter> v = new Vector(len);
/* 106 */     for (int i = 0; i < len; i++) {
/* 107 */       FileFilter ffi = (FileFilter)filters.elementAt(i);
/* 108 */       int ndx = i + 1;
/* 109 */       while (ndx < len) {
/* 110 */         FileFilter ff = (FileFilter)filters.elementAt(ndx);
/* 111 */         if (!ffi.getDescription().equals(ff.getDescription()))
/* 112 */           break;  ndx++;
/*     */       } 
/* 114 */       if (ndx > i + 1) {
/*     */         
/* 116 */         FileFilter[] temp = new FileFilter[ndx - i];
/* 117 */         for (int j = 0; j < temp.length; j++) {
/* 118 */           temp[j] = (FileFilter)filters.elementAt(i + j);
/*     */         }
/* 120 */         v.add(new ComboFileFilter(temp, temp[0].getDescription()));
/* 121 */         i += temp.length - 1;
/*     */       } else {
/* 123 */         v.add(ffi);
/*     */       } 
/* 125 */     }  FileFilter[] result = new FileFilter[v.size()];
/* 126 */     v.copyInto((Object[])result);
/* 127 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean accept(File f) {
/* 134 */     for (int i = 0; i < this.filts.length; i++) {
/* 135 */       if (this.filts[i].accept(f)) return true; 
/*     */     } 
/* 137 */     return false;
/*     */   }
/*     */   
/*     */   public String getDescription() {
/* 141 */     return this.desc;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 147 */     StringBuffer sb = new StringBuffer("ComboFileFilter: ");
/* 148 */     sb.append(this.desc);
/* 149 */     for (int i = 0; i < this.filts.length; i++) {
/* 150 */       sb.append("\n\t");
/* 151 */       sb.append(this.filts[i].toString());
/*     */     } 
/* 153 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int compareTo(Object o) {
/* 160 */     return this.desc.compareToIgnoreCase(((FileFilter)o).getDescription());
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/gui/ComboFileFilter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */