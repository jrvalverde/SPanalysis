/*     */ package loci.formats.gui;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JTree;
/*     */ import javax.swing.tree.DefaultMutableTreeNode;
/*     */ import javax.swing.tree.DefaultTreeCellRenderer;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XMLCellRenderer
/*     */   extends DefaultTreeCellRenderer
/*     */ {
/*     */   private static final String ELEMENT_STYLE_START = "<font color=\"#7f007f\"><b>";
/*     */   private static final String ELEMENT_STYLE_END = "</b></font>";
/*     */   private static final String ATTR_NAME_STYLE_START = "<b>";
/*     */   private static final String ATTR_NAME_STYLE_END = "</b>";
/*     */   private static final String ATTR_VALUE_STYLE_START = "<font color=\"blue\">";
/*     */   private static final String ATTR_VALUE_STYLE_END = "</font>";
/*     */   private static final String COMMENT_STYLE_START = "<font color=\"green\"><i>";
/*     */   private static final String COMMENT_STYLE_END = "</i></font>";
/*     */   
/*     */   public static JTree makeJTree(Document doc) {
/*  79 */     Element rootNode = doc.getDocumentElement();
/*  80 */     DefaultMutableTreeNode rootTreeNode = makeTreeNode(rootNode);
/*  81 */     JTree tree = new JTree(rootTreeNode);
/*  82 */     tree.setCellRenderer(new XMLCellRenderer());
/*  83 */     tree.setRowHeight(0);
/*  84 */     return tree;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Component getTreeCellRendererComponent(JTree tree, Object value, boolean selected, boolean expanded, boolean leaf, int row, boolean hasFocus) {
/*  97 */     Component c = super.getTreeCellRendererComponent(tree, value, selected, expanded, leaf, row, hasFocus);
/*     */ 
/*     */ 
/*     */     
/* 101 */     DefaultMutableTreeNode treeNode = (DefaultMutableTreeNode)value;
/* 102 */     XMLItem item = (XMLItem)treeNode.getUserObject();
/* 103 */     JLabel l = (JLabel)c;
/* 104 */     l.setText(item.toString(true));
/* 105 */     return c;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static DefaultMutableTreeNode makeTreeNode(Node node) {
/* 112 */     DefaultMutableTreeNode treeNode = new DefaultMutableTreeNode(new XMLItem(node));
/*     */     
/* 114 */     NodeList nodeList = node.getChildNodes();
/* 115 */     for (int i = 0; i < nodeList.getLength(); i++) {
/* 116 */       Node n = nodeList.item(i);
/* 117 */       if (!(n instanceof org.w3c.dom.Text)) treeNode.add(makeTreeNode(n)); 
/*     */     } 
/* 119 */     return treeNode;
/*     */   }
/*     */ 
/*     */   
/*     */   private static class XMLItem
/*     */   {
/*     */     private Node node;
/*     */     
/*     */     public XMLItem(Node node) {
/* 128 */       this.node = node;
/*     */     }
/*     */     public String toString(boolean html) {
/* 131 */       StringBuffer sb = new StringBuffer();
/* 132 */       if (this.node instanceof Element) {
/* 133 */         if (html) sb.append("<html>"); 
/* 134 */         sb.append(html ? "&lt;" : "<");
/* 135 */         if (html) sb.append("<font color=\"#7f007f\"><b>"); 
/* 136 */         sb.append(this.node.getNodeName());
/* 137 */         if (html) sb.append("</b></font>");
/*     */         
/* 139 */         NamedNodeMap attr = this.node.getAttributes();
/* 140 */         for (int i = 0; i < attr.getLength(); i++) {
/* 141 */           Node attrNode = attr.item(i);
/* 142 */           sb.append(" ");
/* 143 */           if (html) sb.append("<b>"); 
/* 144 */           sb.append(attrNode.getNodeName());
/* 145 */           sb.append("=");
/* 146 */           if (html) sb.append("</b>"); 
/* 147 */           if (html) sb.append("<font color=\"blue\">"); 
/* 148 */           sb.append(html ? "&quot;" : "\"");
/* 149 */           sb.append(attrNode.getNodeValue());
/* 150 */           sb.append(html ? "&quot;" : "\"");
/* 151 */           if (html) sb.append("</font>"); 
/*     */         } 
/* 153 */         int numChildren = this.node.getChildNodes().getLength();
/* 154 */         if (numChildren == 0) sb.append("/"); 
/* 155 */         sb.append(html ? "&gt;" : ">");
/*     */         
/* 157 */         if (numChildren == 1) {
/* 158 */           Node n = this.node.getFirstChild();
/* 159 */           if (n instanceof org.w3c.dom.Text) {
/* 160 */             sb.append(sanitize(n.getNodeValue(), html));
/* 161 */             sb.append(html ? "&lt;" : "<");
/* 162 */             sb.append("/");
/* 163 */             if (html) sb.append("<font color=\"#7f007f\"><b>"); 
/* 164 */             sb.append(this.node.getNodeName());
/* 165 */             if (html) sb.append("</b></font>"); 
/* 166 */             sb.append(html ? "&gt;" : ">");
/*     */           }
/*     */         
/*     */         } 
/* 170 */       } else if (this.node instanceof org.w3c.dom.Comment) {
/* 171 */         if (html) sb.append("<html>"); 
/* 172 */         if (html) sb.append("<font color=\"green\"><i>"); 
/* 173 */         sb.append(html ? "&lt;" : "<");
/* 174 */         sb.append("!--");
/* 175 */         sb.append(html ? "<br>" : "\n");
/* 176 */         sb.append(sanitize(this.node.getNodeValue(), html));
/* 177 */         sb.append(html ? "<br>" : "\n");
/* 178 */         sb.append("--");
/* 179 */         sb.append(html ? "&gt;" : ">");
/* 180 */         if (html) sb.append("</i></font>"); 
/*     */       } else {
/* 182 */         sb.append(this.node.getNodeValue());
/* 183 */       }  return sb.toString();
/*     */     }
/*     */     
/*     */     public String toString() {
/* 187 */       return toString(false);
/*     */     }
/*     */     
/*     */     private String sanitize(String s, boolean html) {
/* 191 */       if (!html) return s; 
/* 192 */       s = s.replaceAll("&", "&amp;");
/* 193 */       s = s.replaceAll("\"", "&quot;");
/* 194 */       s = s.replaceAll("<", "&lt;");
/* 195 */       s = s.replaceAll(">", "&gt;");
/* 196 */       s = s.replaceAll("[\n\r]", "<br>");
/* 197 */       return s;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/gui/XMLCellRenderer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */