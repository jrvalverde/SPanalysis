/*     */ package loci.formats.gui;
/*     */ 
/*     */ import java.awt.image.ColorModel;
/*     */ import java.awt.image.ComponentColorModel;
/*     */ import java.awt.image.ComponentSampleModel;
/*     */ import java.awt.image.DataBuffer;
/*     */ import java.awt.image.DataBufferInt;
/*     */ import java.awt.image.Raster;
/*     */ import java.awt.image.SampleModel;
/*     */ import java.awt.image.WritableRaster;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UnsignedIntColorModel
/*     */   extends ColorModel
/*     */ {
/*     */   private int pixelBits;
/*     */   private int nChannels;
/*     */   private ComponentColorModel helper;
/*     */   
/*     */   public UnsignedIntColorModel(int pixelBits, int dataType, int nChannels) throws IOException {
/*  69 */     super(pixelBits, makeBitArray(nChannels, pixelBits), AWTImageTools.makeColorSpace(nChannels), (nChannels == 4), false, 3, dataType);
/*     */ 
/*     */ 
/*     */     
/*  73 */     this.helper = new ComponentColorModel(AWTImageTools.makeColorSpace(nChannels), (nChannels == 4), false, 3, dataType);
/*     */ 
/*     */     
/*  76 */     this.pixelBits = pixelBits;
/*  77 */     this.nChannels = nChannels;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized Object getDataElements(int rgb, Object pixel) {
/*  84 */     return this.helper.getDataElements(rgb, pixel);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isCompatibleRaster(Raster raster) {
/*  89 */     return (raster.getNumBands() == getNumComponents() && raster.getTransferType() == getTransferType());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public WritableRaster createCompatibleWritableRaster(int w, int h) {
/*  95 */     int[] bandOffsets = new int[this.nChannels];
/*  96 */     for (int i = 0; i < this.nChannels; ) { bandOffsets[i] = i; i++; }
/*     */     
/*  98 */     SampleModel m = new ComponentSampleModel(3, w, h, this.nChannels, w * this.nChannels, bandOffsets);
/*     */     
/* 100 */     DataBuffer db = new DataBufferInt(w * h, this.nChannels);
/* 101 */     return Raster.createWritableRaster(m, db, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getAlpha(int pixel) {
/* 106 */     return (int)(Math.pow(2.0D, 32.0D) - 1.0D);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getBlue(int pixel) {
/* 111 */     return getComponent(pixel, 3);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getGreen(int pixel) {
/* 116 */     return getComponent(pixel, 2);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getRed(int pixel) {
/* 121 */     return getComponent(pixel, 1);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getAlpha(Object data) {
/* 126 */     int max = (int)Math.pow(2.0D, 32.0D) - 1;
/* 127 */     if (data instanceof int[]) {
/* 128 */       int[] i = (int[])data;
/* 129 */       if (i.length == 1) return getAlpha(i[0]); 
/* 130 */       return getAlpha((i.length == 4) ? i[0] : max);
/*     */     } 
/* 132 */     return max;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getRed(Object data) {
/* 137 */     int max = (int)Math.pow(2.0D, 32.0D) - 1;
/* 138 */     if (data instanceof int[]) {
/* 139 */       int[] i = (int[])data;
/* 140 */       if (i.length == 1) return getRed(i[0]); 
/* 141 */       return getRed((i.length != 4) ? i[0] : i[1]);
/*     */     } 
/* 143 */     return max;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getGreen(Object data) {
/* 148 */     int max = (int)Math.pow(2.0D, 32.0D) - 1;
/* 149 */     if (data instanceof int[]) {
/* 150 */       int[] i = (int[])data;
/* 151 */       if (i.length == 1) return getGreen(i[0]); 
/* 152 */       return getGreen((i.length != 4) ? i[1] : i[2]);
/*     */     } 
/* 154 */     return max;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getBlue(Object data) {
/* 159 */     int max = (int)Math.pow(2.0D, 32.0D) - 1;
/* 160 */     if (data instanceof int[]) {
/* 161 */       int[] i = (int[])data;
/* 162 */       if (i.length == 1) return getBlue(i[0]); 
/* 163 */       return getBlue(i[i.length - 1]);
/*     */     } 
/* 165 */     return max;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private int getComponent(int pixel, int index) {
/* 171 */     long v = pixel & 0xFFFFFFFFL;
/* 172 */     double f = v / (Math.pow(2.0D, 32.0D) - 1.0D);
/* 173 */     f *= 255.0D;
/* 174 */     return (int)f;
/*     */   }
/*     */   
/*     */   private static int[] makeBitArray(int nChannels, int nBits) {
/* 178 */     int[] bits = new int[nChannels];
/* 179 */     for (int i = 0; i < bits.length; i++) {
/* 180 */       bits[i] = nBits;
/*     */     }
/* 182 */     return bits;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/gui/UnsignedIntColorModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */