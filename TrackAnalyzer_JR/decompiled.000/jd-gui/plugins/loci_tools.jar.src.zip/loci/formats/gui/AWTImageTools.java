/*      */ package loci.formats.gui;
/*      */ 
/*      */ import java.awt.Component;
/*      */ import java.awt.Container;
/*      */ import java.awt.Dimension;
/*      */ import java.awt.Graphics;
/*      */ import java.awt.Graphics2D;
/*      */ import java.awt.GraphicsConfiguration;
/*      */ import java.awt.GraphicsDevice;
/*      */ import java.awt.GraphicsEnvironment;
/*      */ import java.awt.Image;
/*      */ import java.awt.MediaTracker;
/*      */ import java.awt.RenderingHints;
/*      */ import java.awt.color.ColorSpace;
/*      */ import java.awt.geom.AffineTransform;
/*      */ import java.awt.image.BandedSampleModel;
/*      */ import java.awt.image.BufferedImage;
/*      */ import java.awt.image.ColorModel;
/*      */ import java.awt.image.ComponentColorModel;
/*      */ import java.awt.image.ComponentSampleModel;
/*      */ import java.awt.image.DataBuffer;
/*      */ import java.awt.image.DataBufferByte;
/*      */ import java.awt.image.DataBufferDouble;
/*      */ import java.awt.image.DataBufferFloat;
/*      */ import java.awt.image.DataBufferInt;
/*      */ import java.awt.image.DataBufferUShort;
/*      */ import java.awt.image.IndexColorModel;
/*      */ import java.awt.image.PixelInterleavedSampleModel;
/*      */ import java.awt.image.Raster;
/*      */ import java.awt.image.RenderedImage;
/*      */ import java.awt.image.SampleModel;
/*      */ import java.awt.image.SinglePixelPackedSampleModel;
/*      */ import java.awt.image.WritableRaster;
/*      */ import java.io.IOException;
/*      */ import java.util.Hashtable;
/*      */ import loci.common.DataTools;
/*      */ import loci.formats.FormatException;
/*      */ import loci.formats.FormatTools;
/*      */ import loci.formats.IFormatReader;
/*      */ import loci.formats.ImageTools;
/*      */ import loci.formats.MetadataTools;
/*      */ import loci.formats.meta.MetadataRetrieve;
/*      */ import ome.xml.model.primitives.PositiveInteger;
/*      */ import org.slf4j.Logger;
/*      */ import org.slf4j.LoggerFactory;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class AWTImageTools
/*      */ {
/*  110 */   protected static final Component OBS = new Container();
/*      */   
/*  112 */   private static final Logger LOGGER = LoggerFactory.getLogger(AWTImageTools.class);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedImage makeImage(byte[] data, int w, int h, boolean signed) {
/*  133 */     return makeImage(new byte[][] { data }, w, h, signed);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedImage makeImage(short[] data, int w, int h, boolean signed) {
/*  148 */     return makeImage(new short[][] { data }, w, h, signed);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedImage makeImage(int[] data, int w, int h, boolean signed) {
/*  163 */     return makeImage(new int[][] { data }, w, h, signed);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedImage makeImage(float[] data, int w, int h) {
/*  174 */     return makeImage(new float[][] { data }, w, h);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedImage makeImage(double[] data, int w, int h) {
/*  185 */     return makeImage(new double[][] { data }, w, h);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedImage makeImage(byte[] data, int w, int h, int c, boolean interleaved, boolean signed) {
/*      */     DataBuffer buffer;
/*  207 */     if (c == 1) return makeImage(data, w, h, signed); 
/*  208 */     if (c > 2) return makeRGBImage(data, c, w, h, interleaved);
/*      */ 
/*      */     
/*  211 */     int dataType = 0;
/*  212 */     if (signed) {
/*  213 */       buffer = new SignedByteBuffer(data, c * w * h);
/*      */     } else {
/*      */       
/*  216 */       buffer = new DataBufferByte(data, c * w * h);
/*      */     } 
/*  218 */     return constructImage(c, dataType, w, h, interleaved, false, buffer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedImage makeImage(short[] data, int w, int h, int c, boolean interleaved, boolean signed) {
/*      */     int dataType;
/*      */     DataBuffer buffer;
/*  238 */     if (c == 1) return makeImage(data, w, h, signed);
/*      */ 
/*      */     
/*  241 */     if (signed) {
/*  242 */       dataType = 2;
/*  243 */       buffer = new SignedShortBuffer(data, c * w * h);
/*      */     } else {
/*      */       
/*  246 */       dataType = 1;
/*  247 */       buffer = new DataBufferUShort(data, c * w * h);
/*      */     } 
/*  249 */     return constructImage(c, dataType, w, h, interleaved, false, buffer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedImage makeImage(int[] data, int w, int h, int c, boolean interleaved, boolean signed) {
/*      */     DataBuffer buffer;
/*  269 */     if (c == 1) return makeImage(data, w, h, signed); 
/*  270 */     int dataType = 3;
/*      */     
/*  272 */     if (signed) {
/*  273 */       buffer = new DataBufferInt(data, c * w * h);
/*      */     } else {
/*      */       
/*  276 */       buffer = new UnsignedIntBuffer(data, c * w * h);
/*      */     } 
/*  278 */     return constructImage(c, dataType, w, h, interleaved, false, buffer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedImage makeImage(float[] data, int w, int h, int c, boolean interleaved) {
/*  296 */     if (c == 1) return makeImage(data, w, h); 
/*  297 */     int dataType = 4;
/*  298 */     DataBuffer buffer = new DataBufferFloat(data, c * w * h);
/*  299 */     return constructImage(c, dataType, w, h, interleaved, false, buffer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedImage makeImage(double[] data, int w, int h, int c, boolean interleaved) {
/*  317 */     if (c == 1) return makeImage(data, w, h); 
/*  318 */     int dataType = 5;
/*  319 */     DataBuffer buffer = new DataBufferDouble(data, c * w * h);
/*  320 */     return constructImage(c, dataType, w, h, interleaved, false, buffer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedImage makeImage(byte[][] data, int w, int h, boolean signed) {
/*      */     DataBuffer buffer;
/*  339 */     if (data.length > 2) return makeRGBImage(data, w, h);
/*      */ 
/*      */     
/*  342 */     int dataType = 0;
/*  343 */     if (signed) {
/*  344 */       buffer = new SignedByteBuffer(data, (data[0]).length);
/*      */     } else {
/*      */       
/*  347 */       buffer = new DataBufferByte(data, (data[0]).length);
/*      */     } 
/*  349 */     return constructImage(data.length, dataType, w, h, false, true, buffer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedImage makeImage(short[][] data, int w, int h, boolean signed) {
/*      */     int dataType;
/*      */     DataBuffer buffer;
/*  368 */     if (signed) {
/*  369 */       dataType = 2;
/*  370 */       buffer = new SignedShortBuffer(data, (data[0]).length);
/*      */     } else {
/*      */       
/*  373 */       dataType = 1;
/*  374 */       buffer = new DataBufferUShort(data, (data[0]).length);
/*      */     } 
/*  376 */     return constructImage(data.length, dataType, w, h, false, true, buffer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedImage makeImage(int[][] data, int w, int h, boolean signed) {
/*      */     DataBuffer buffer;
/*  393 */     int dataType = 3;
/*      */     
/*  395 */     if (signed) {
/*  396 */       buffer = new DataBufferInt(data, (data[0]).length);
/*      */     } else {
/*      */       
/*  399 */       buffer = new UnsignedIntBuffer(data, (data[0]).length);
/*      */     } 
/*  401 */     return constructImage(data.length, dataType, w, h, false, true, buffer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedImage makeImage(float[][] data, int w, int h) {
/*  414 */     int dataType = 4;
/*  415 */     DataBuffer buffer = new DataBufferFloat(data, (data[0]).length);
/*  416 */     return constructImage(data.length, dataType, w, h, false, true, buffer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedImage makeImage(double[][] data, int w, int h) {
/*  429 */     int dataType = 5;
/*  430 */     DataBuffer buffer = new DataBufferDouble(data, (data[0]).length);
/*  431 */     return constructImage(data.length, dataType, w, h, false, true, buffer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedImage makeImage(byte[] data, boolean interleaved, MetadataRetrieve meta, int series) throws FormatException {
/*  451 */     MetadataTools.verifyMinimumPopulated(meta, series);
/*  452 */     int width = ((Integer)meta.getPixelsSizeX(series).getValue()).intValue();
/*  453 */     int height = ((Integer)meta.getPixelsSizeY(series).getValue()).intValue();
/*  454 */     String pixelType = meta.getPixelsType(series).toString();
/*  455 */     int type = FormatTools.pixelTypeFromString(pixelType);
/*  456 */     PositiveInteger nChannels = meta.getChannelSamplesPerPixel(series, 0);
/*  457 */     if (nChannels == null) {
/*  458 */       LOGGER.warn("SamplesPerPixel is null; it is assumed to be 1.");
/*      */     }
/*  460 */     int channels = (nChannels == null) ? 1 : ((Integer)nChannels.getValue()).intValue();
/*  461 */     boolean littleEndian = !meta.getPixelsBinDataBigEndian(series, 0).booleanValue();
/*      */     
/*  463 */     return makeImage(data, width, height, channels, interleaved, FormatTools.getBytesPerPixel(type), FormatTools.isFloatingPoint(type), littleEndian, FormatTools.isSigned(type));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedImage makeImage(byte[] data, int w, int h, int c, boolean interleaved, int bpp, boolean fp, boolean little, boolean signed) {
/*  491 */     Object pixels = DataTools.makeDataArray(data, (bpp % 3 == 0) ? (bpp / 3) : bpp, fp, little);
/*      */ 
/*      */     
/*  494 */     if (pixels instanceof byte[]) {
/*  495 */       return makeImage((byte[])pixels, w, h, c, interleaved, signed);
/*      */     }
/*  497 */     if (pixels instanceof short[]) {
/*  498 */       return makeImage((short[])pixels, w, h, c, interleaved, signed);
/*      */     }
/*  500 */     if (pixels instanceof int[]) {
/*  501 */       return makeImage((int[])pixels, w, h, c, interleaved, signed);
/*      */     }
/*  503 */     if (pixels instanceof float[]) {
/*  504 */       return makeImage((float[])pixels, w, h, c, interleaved);
/*      */     }
/*  506 */     if (pixels instanceof double[]) {
/*  507 */       return makeImage((double[])pixels, w, h, c, interleaved);
/*      */     }
/*  509 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedImage makeImage(byte[][] data, int w, int h, int bpp, boolean fp, boolean little, boolean signed) {
/*  529 */     int c = data.length;
/*  530 */     Object v = null;
/*  531 */     for (int i = 0; i < c; i++) {
/*  532 */       Object pixels = DataTools.makeDataArray(data[i], (bpp % 3 == 0) ? (bpp / 3) : bpp, fp, little);
/*      */       
/*  534 */       if (pixels instanceof byte[]) {
/*  535 */         if (v == null) v = new byte[c][]; 
/*  536 */         ((byte[][])v)[i] = (byte[])pixels;
/*      */       }
/*  538 */       else if (pixels instanceof short[]) {
/*  539 */         if (v == null) v = new short[c][]; 
/*  540 */         ((short[][])v)[i] = (short[])pixels;
/*      */       }
/*  542 */       else if (pixels instanceof int[]) {
/*  543 */         if (v == null) v = new int[c][]; 
/*  544 */         ((int[][])v)[i] = (int[])pixels;
/*      */       }
/*  546 */       else if (pixels instanceof float[]) {
/*  547 */         if (v == null) v = new float[c][]; 
/*  548 */         ((float[][])v)[i] = (float[])pixels;
/*      */       }
/*  550 */       else if (pixels instanceof double[]) {
/*  551 */         if (v == null) v = new double[c][]; 
/*  552 */         ((double[][])v)[i] = (double[])pixels;
/*      */       } 
/*      */     } 
/*  555 */     if (v instanceof byte[][]) {
/*  556 */       return makeImage((byte[][])v, w, h, signed);
/*      */     }
/*  558 */     if (v instanceof short[][]) {
/*  559 */       return makeImage((short[][])v, w, h, signed);
/*      */     }
/*  561 */     if (v instanceof int[][]) {
/*  562 */       return makeImage((int[][])v, w, h, signed);
/*      */     }
/*  564 */     if (v instanceof float[][]) {
/*  565 */       return makeImage((float[][])v, w, h);
/*      */     }
/*  567 */     if (v instanceof double[][]) {
/*  568 */       return makeImage((double[][])v, w, h);
/*      */     }
/*  570 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedImage makeRGBImage(byte[] data, int c, int w, int h, boolean interleaved) {
/*  576 */     int cc = Math.min(c, 4);
/*  577 */     int[] buf = new int[data.length / c];
/*  578 */     int nBits = (cc - 1) * 8;
/*      */     
/*  580 */     for (int i = 0; i < buf.length; i++) {
/*  581 */       for (int q = 0; q < cc; q++) {
/*  582 */         if (interleaved) {
/*  583 */           buf[i] = buf[i] | (data[i * c + q] & 0xFF) << nBits - q * 8;
/*      */         } else {
/*      */           
/*  586 */           buf[i] = buf[i] | (data[q * buf.length + i] & 0xFF) << nBits - q * 8;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  591 */     DataBuffer buffer = new DataBufferInt(buf, buf.length);
/*  592 */     return constructImage(cc, 3, w, h, false, false, buffer);
/*      */   }
/*      */   
/*      */   public static BufferedImage makeRGBImage(byte[][] data, int w, int h) {
/*  596 */     int[] buf = new int[(data[0]).length];
/*  597 */     int nBits = (data.length - 1) * 8;
/*      */     
/*  599 */     for (int i = 0; i < buf.length; i++) {
/*  600 */       for (int q = 0; q < data.length; q++) {
/*  601 */         buf[i] = buf[i] | (data[q][i] & 0xFF) << nBits - q * 8;
/*      */       }
/*      */     } 
/*      */     
/*  605 */     DataBuffer buffer = new DataBufferInt(buf, buf.length);
/*  606 */     return constructImage(data.length, 3, w, h, false, false, buffer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedImage blankImage(int w, int h, int c, int type) {
/*  629 */     switch (type) {
/*      */       case 0:
/*  631 */         return makeImage(new byte[c][w * h], w, h, true);
/*      */       case 1:
/*  633 */         return makeImage(new byte[c][w * h], w, h, false);
/*      */       case 2:
/*  635 */         return makeImage(new short[c][w * h], w, h, true);
/*      */       case 3:
/*  637 */         return makeImage(new short[c][w * h], w, h, false);
/*      */       case 4:
/*  639 */         return makeImage(new int[c][w * h], w, h, true);
/*      */       case 5:
/*  641 */         return makeImage(new int[c][w * h], w, h, false);
/*      */       case 6:
/*  643 */         return makeImage(new float[c][w * h], w, h);
/*      */       case 7:
/*  645 */         return makeImage(new double[c][w * h], w, h);
/*      */     } 
/*  647 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedImage constructImage(int c, int type, int w, int h, boolean interleaved, boolean banded, DataBuffer buffer) {
/*  654 */     return constructImage(c, type, w, h, interleaved, banded, buffer, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedImage constructImage(int c, int type, int w, int h, boolean interleaved, boolean banded, DataBuffer buffer, ColorModel colorModel) {
/*      */     SampleModel model;
/*  662 */     if (c > 4) {
/*  663 */       throw new IllegalArgumentException("Cannot construct image with " + c + " channels");
/*      */     }
/*      */     
/*  666 */     if (colorModel == null || colorModel instanceof java.awt.image.DirectColorModel) {
/*  667 */       colorModel = makeColorModel(c, type);
/*  668 */       if (colorModel == null) return null; 
/*  669 */       if (buffer instanceof UnsignedIntBuffer) {
/*      */         try {
/*  671 */           colorModel = new UnsignedIntColorModel(32, type, c);
/*      */         }
/*  673 */         catch (IOException e) {
/*  674 */           return null;
/*      */         } 
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  680 */     if (c > 2 && type == 3 && buffer.getNumBanks() == 1 && !(buffer instanceof UnsignedIntBuffer))
/*      */     
/*      */     { 
/*  683 */       int[] bitMasks = new int[c];
/*  684 */       for (int i = 0; i < c; i++) {
/*  685 */         bitMasks[i] = 255 << (c - i - 1) * 8;
/*      */       }
/*  687 */       model = new SinglePixelPackedSampleModel(3, w, h, bitMasks);
/*      */        }
/*      */     
/*  690 */     else if (banded) { model = new BandedSampleModel(type, w, h, c); }
/*  691 */     else if (interleaved)
/*  692 */     { int[] bandOffsets = new int[c];
/*  693 */       for (int i = 0; i < c; ) { bandOffsets[i] = i; i++; }
/*  694 */        model = new PixelInterleavedSampleModel(type, w, h, c, c * w, bandOffsets); }
/*      */     
/*      */     else
/*      */     
/*  698 */     { int[] bandOffsets = new int[c];
/*  699 */       for (int i = 0; i < c; ) { bandOffsets[i] = i * w * h; i++; }
/*  700 */        model = new ComponentSampleModel(type, w, h, 1, w, bandOffsets); }
/*      */ 
/*      */     
/*  703 */     WritableRaster raster = Raster.createWritableRaster(model, buffer, null);
/*      */     
/*  705 */     BufferedImage b = null;
/*      */     
/*  707 */     if (c == 1 && type == 0 && !(buffer instanceof SignedByteBuffer)) {
/*      */ 
/*      */       
/*  710 */       if (colorModel instanceof IndexColorModel) {
/*  711 */         b = new BufferedImage(w, h, 13);
/*      */       } else {
/*      */         
/*  714 */         b = new BufferedImage(w, h, 10);
/*      */       } 
/*  716 */       b.setData(raster);
/*      */     }
/*  718 */     else if (c == 1 && type == 1) {
/*  719 */       if (!(colorModel instanceof IndexColorModel)) {
/*  720 */         b = new BufferedImage(w, h, 11);
/*  721 */         b.setData(raster);
/*      */       }
/*      */     
/*  724 */     } else if (c > 2 && type == 3 && buffer.getNumBanks() == 1 && !(buffer instanceof UnsignedIntBuffer)) {
/*      */ 
/*      */       
/*  727 */       if (c == 3) {
/*  728 */         b = new BufferedImage(w, h, 1);
/*      */       }
/*  730 */       else if (c == 4) {
/*  731 */         b = new BufferedImage(w, h, 2);
/*      */       } 
/*      */       
/*  734 */       if (b != null) b.setData(raster);
/*      */     
/*      */     } 
/*  737 */     if (b == null) b = new BufferedImage(colorModel, raster, false, null);
/*      */     
/*  739 */     return b;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedImage openImage(byte[] buf, IFormatReader r, int w, int h) throws FormatException, IOException {
/*  749 */     int pixelType = r.getPixelType();
/*  750 */     boolean little = r.isLittleEndian();
/*  751 */     boolean normal = r.isNormalized();
/*  752 */     int rgbChanCount = r.getRGBChannelCount();
/*  753 */     boolean interleaved = r.isInterleaved();
/*  754 */     boolean indexed = r.isIndexed();
/*      */     
/*  756 */     if (pixelType == 6) {
/*  757 */       float[] f = (float[])DataTools.makeDataArray(buf, 4, true, little);
/*  758 */       if (normal) f = DataTools.normalizeFloats(f); 
/*  759 */       return makeImage(f, w, h, rgbChanCount, interleaved);
/*      */     } 
/*  761 */     if (pixelType == 7) {
/*  762 */       double[] d = (double[])DataTools.makeDataArray(buf, 8, true, little);
/*  763 */       if (normal) d = DataTools.normalizeDoubles(d); 
/*  764 */       return makeImage(d, w, h, rgbChanCount, interleaved);
/*      */     } 
/*      */     
/*  767 */     boolean signed = FormatTools.isSigned(pixelType);
/*  768 */     ColorModel model = null;
/*      */     
/*  770 */     if (signed) {
/*  771 */       if (pixelType == 0) {
/*  772 */         model = new SignedColorModel(8, 0, rgbChanCount);
/*      */       }
/*  774 */       else if (pixelType == 2) {
/*  775 */         model = new SignedColorModel(16, 2, rgbChanCount);
/*      */       }
/*  777 */       else if (pixelType == 4) {
/*  778 */         model = new SignedColorModel(32, 3, rgbChanCount);
/*      */       } 
/*      */     }
/*      */     
/*  782 */     int bpp = FormatTools.getBytesPerPixel(pixelType);
/*  783 */     BufferedImage b = makeImage(buf, w, h, rgbChanCount, interleaved, bpp, false, little, signed);
/*      */     
/*  785 */     if (b == null) {
/*  786 */       throw new FormatException("Could not construct BufferedImage");
/*      */     }
/*      */     
/*  789 */     if (indexed && rgbChanCount == 1) {
/*  790 */       if (pixelType == 1 || pixelType == 0) {
/*  791 */         byte[][] table = r.get8BitLookupTable();
/*  792 */         if (table != null && table.length > 0 && table[0] != null) {
/*  793 */           int len = (table[0]).length;
/*  794 */           byte[] dummy = (table.length < 3) ? new byte[len] : null;
/*  795 */           byte[] red = (table.length >= 1) ? table[0] : dummy;
/*  796 */           byte[] green = (table.length >= 2) ? table[1] : dummy;
/*  797 */           byte[] blue = (table.length >= 3) ? table[2] : dummy;
/*  798 */           model = new IndexColorModel(8, len, red, green, blue);
/*      */         }
/*      */       
/*  801 */       } else if (pixelType == 3 || pixelType == 2) {
/*      */ 
/*      */         
/*  804 */         short[][] table = r.get16BitLookupTable();
/*  805 */         if (table != null && table.length > 0 && table[0] != null) {
/*  806 */           model = new Index16ColorModel(16, (table[0]).length, table, r.isLittleEndian());
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*  812 */     if (model != null) {
/*  813 */       WritableRaster raster = Raster.createWritableRaster(b.getSampleModel(), b.getRaster().getDataBuffer(), null);
/*      */       
/*  815 */       b = new BufferedImage(model, raster, false, null);
/*      */     } 
/*      */     
/*  818 */     return b;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object getPixels(BufferedImage image) {
/*  829 */     return getPixels(image, 0, 0, image.getWidth(), image.getHeight());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object getPixels(BufferedImage image, int x, int y, int w, int h) {
/*  841 */     WritableRaster raster = image.getRaster();
/*  842 */     return getPixels(raster, x, y, w, h);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object getPixels(WritableRaster raster) {
/*  851 */     return getPixels(raster, 0, 0, raster.getWidth(), raster.getHeight());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object getPixels(WritableRaster raster, int x, int y, int w, int h) {
/*  862 */     int tt = raster.getTransferType();
/*  863 */     if (tt == 0) return getBytes(raster, x, y, w, h); 
/*  864 */     if (tt == 1 || tt == 2) {
/*  865 */       return getShorts(raster, x, y, w, h);
/*      */     }
/*  867 */     if (tt == 3) return getInts(raster, x, y, w, h); 
/*  868 */     if (tt == 4) return getFloats(raster, x, y, w, h); 
/*  869 */     if (tt == 5) {
/*  870 */       return getDoubles(raster, x, y, w, h);
/*      */     }
/*  872 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public static byte[][] getBytes(BufferedImage image) {
/*  877 */     WritableRaster r = image.getRaster();
/*  878 */     return getBytes(r);
/*      */   }
/*      */ 
/*      */   
/*      */   public static byte[][] getBytes(WritableRaster r) {
/*  883 */     return getBytes(r, 0, 0, r.getWidth(), r.getHeight());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[][] getBytes(WritableRaster r, int x, int y, int w, int h) {
/*  889 */     if (canUseBankDataDirectly(r, 0, (Class)DataBufferByte.class) && x == 0 && y == 0 && w == r.getWidth() && h == r.getHeight())
/*      */     {
/*      */       
/*  892 */       return ((DataBufferByte)r.getDataBuffer()).getBankData();
/*      */     }
/*  894 */     int c = r.getNumBands();
/*  895 */     byte[][] samples = new byte[c][w * h];
/*  896 */     int[] buf = new int[w * h];
/*  897 */     for (int i = 0; i < c; i++) {
/*  898 */       r.getSamples(x, y, w, h, i, buf);
/*  899 */       for (int j = 0; j < buf.length; ) { samples[i][j] = (byte)buf[j]; j++; }
/*      */     
/*  901 */     }  return samples;
/*      */   }
/*      */ 
/*      */   
/*      */   public static short[][] getShorts(BufferedImage image) {
/*  906 */     WritableRaster r = image.getRaster();
/*  907 */     return getShorts(r);
/*      */   }
/*      */ 
/*      */   
/*      */   public static short[][] getShorts(WritableRaster r) {
/*  912 */     return getShorts(r, 0, 0, r.getWidth(), r.getHeight());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static short[][] getShorts(WritableRaster r, int x, int y, int w, int h) {
/*  919 */     if (canUseBankDataDirectly(r, 1, (Class)DataBufferUShort.class) && x == 0 && y == 0 && w == r.getWidth() && h == r.getHeight())
/*      */     {
/*      */ 
/*      */       
/*  923 */       return ((DataBufferUShort)r.getDataBuffer()).getBankData();
/*      */     }
/*  925 */     int c = r.getNumBands();
/*  926 */     short[][] samples = new short[c][w * h];
/*  927 */     int[] buf = new int[w * h];
/*  928 */     for (int i = 0; i < c; i++) {
/*  929 */       r.getSamples(x, y, w, h, i, buf);
/*  930 */       for (int j = 0; j < buf.length; ) { samples[i][j] = (short)buf[j]; j++; }
/*      */     
/*  932 */     }  return samples;
/*      */   }
/*      */ 
/*      */   
/*      */   public static int[][] getInts(BufferedImage image) {
/*  937 */     WritableRaster r = image.getRaster();
/*  938 */     return getInts(r);
/*      */   }
/*      */ 
/*      */   
/*      */   public static int[][] getInts(WritableRaster r) {
/*  943 */     return getInts(r, 0, 0, r.getWidth(), r.getHeight());
/*      */   }
/*      */ 
/*      */   
/*      */   public static int[][] getInts(WritableRaster r, int x, int y, int w, int h) {
/*  948 */     if (canUseBankDataDirectly(r, 3, (Class)DataBufferInt.class) && x == 0 && y == 0 && w == r.getWidth() && h == r.getHeight())
/*      */     {
/*      */       
/*  951 */       return ((DataBufferInt)r.getDataBuffer()).getBankData();
/*      */     }
/*      */     
/*  954 */     int c = r.getNumBands();
/*  955 */     int[][] samples = new int[c][w * h];
/*  956 */     for (int i = 0; i < c; ) { r.getSamples(x, y, w, h, i, samples[i]); i++; }
/*  957 */      return samples;
/*      */   }
/*      */ 
/*      */   
/*      */   public static float[][] getFloats(BufferedImage image) {
/*  962 */     WritableRaster r = image.getRaster();
/*  963 */     return getFloats(r);
/*      */   }
/*      */ 
/*      */   
/*      */   public static float[][] getFloats(WritableRaster r) {
/*  968 */     return getFloats(r, 0, 0, r.getWidth(), r.getHeight());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static float[][] getFloats(WritableRaster r, int x, int y, int w, int h) {
/*  975 */     if (canUseBankDataDirectly(r, 4, (Class)DataBufferFloat.class) && x == 0 && y == 0 && w == r.getWidth() && h == r.getHeight())
/*      */     {
/*      */ 
/*      */       
/*  979 */       return ((DataBufferFloat)r.getDataBuffer()).getBankData();
/*      */     }
/*      */     
/*  982 */     int c = r.getNumBands();
/*  983 */     float[][] samples = new float[c][w * h];
/*  984 */     for (int i = 0; i < c; ) { r.getSamples(x, y, w, h, i, samples[i]); i++; }
/*  985 */      return samples;
/*      */   }
/*      */ 
/*      */   
/*      */   public static double[][] getDoubles(BufferedImage image) {
/*  990 */     WritableRaster r = image.getRaster();
/*  991 */     return getDoubles(r);
/*      */   }
/*      */ 
/*      */   
/*      */   public static double[][] getDoubles(WritableRaster r) {
/*  996 */     return getDoubles(r, 0, 0, r.getWidth(), r.getHeight());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double[][] getDoubles(WritableRaster r, int x, int y, int w, int h) {
/* 1003 */     if (canUseBankDataDirectly(r, 5, (Class)DataBufferDouble.class) && x == 0 && y == 0 && w == r.getWidth() && h == r.getHeight())
/*      */     {
/*      */ 
/*      */       
/* 1007 */       return ((DataBufferDouble)r.getDataBuffer()).getBankData();
/*      */     }
/*      */     
/* 1010 */     int c = r.getNumBands();
/* 1011 */     double[][] samples = new double[c][w * h];
/* 1012 */     for (int i = 0; i < c; ) { r.getSamples(x, y, w, h, i, samples[i]); i++; }
/* 1013 */      return samples;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean canUseBankDataDirectly(WritableRaster r, int transferType, Class<? extends DataBuffer> dataBufferClass) {
/* 1023 */     int tt = r.getTransferType();
/* 1024 */     if (tt != transferType) return false; 
/* 1025 */     DataBuffer buffer = r.getDataBuffer();
/* 1026 */     if (!dataBufferClass.isInstance(buffer)) return false; 
/* 1027 */     SampleModel model = r.getSampleModel();
/* 1028 */     if (!(model instanceof ComponentSampleModel)) return false; 
/* 1029 */     ComponentSampleModel csm = (ComponentSampleModel)model;
/* 1030 */     int pixelStride = csm.getPixelStride();
/* 1031 */     if (pixelStride != 1) return false; 
/* 1032 */     int w = r.getWidth();
/* 1033 */     int scanlineStride = csm.getScanlineStride();
/* 1034 */     if (scanlineStride != w) return false; 
/* 1035 */     int c = r.getNumBands();
/* 1036 */     int[] bandOffsets = csm.getBandOffsets();
/* 1037 */     if (bandOffsets.length != c) return false;  int i;
/* 1038 */     for (i = 0; i < bandOffsets.length; i++) {
/* 1039 */       if (bandOffsets[i] != 0) return false; 
/*      */     } 
/* 1041 */     for (i = 0; i < bandOffsets.length; i++) {
/* 1042 */       if (bandOffsets[i] != i) return false; 
/*      */     } 
/* 1044 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[][] getPixelBytes(BufferedImage img, boolean little) {
/* 1055 */     return getPixelBytes(img, little, 0, 0, img.getWidth(), img.getHeight());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[][] getPixelBytes(WritableRaster r, boolean little) {
/* 1066 */     return getPixelBytes(r, little, 0, 0, r.getWidth(), r.getHeight());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[][] getPixelBytes(BufferedImage img, boolean little, int x, int y, int w, int h) {
/* 1079 */     Object pixels = getPixels(img, x, y, w, h);
/* 1080 */     int imageType = img.getType();
/* 1081 */     byte[][] pixelBytes = (byte[][])null;
/*      */     
/* 1083 */     if (pixels instanceof byte[][]) {
/* 1084 */       pixelBytes = (byte[][])pixels;
/*      */     }
/* 1086 */     else if (pixels instanceof short[][]) {
/* 1087 */       short[][] s = (short[][])pixels;
/* 1088 */       pixelBytes = new byte[s.length][(s[0]).length * 2];
/* 1089 */       for (int i = 0; i < pixelBytes.length; i++) {
/* 1090 */         for (int j = 0; j < (s[0]).length; j++) {
/* 1091 */           DataTools.unpackBytes(s[i][j], pixelBytes[i], j * 2, 2, little);
/*      */         }
/*      */       }
/*      */     
/* 1095 */     } else if (pixels instanceof int[][]) {
/* 1096 */       int[][] in = (int[][])pixels;
/*      */       
/* 1098 */       if (imageType == 1 || imageType == 4 || imageType == 2) {
/*      */ 
/*      */ 
/*      */         
/* 1102 */         pixelBytes = new byte[in.length][(in[0]).length];
/* 1103 */         for (int c = 0; c < in.length; c++) {
/* 1104 */           for (int i = 0; i < (in[0]).length; i++) {
/* 1105 */             if (imageType != 4) {
/* 1106 */               pixelBytes[c][i] = (byte)(in[c][i] & 0xFF);
/*      */             } else {
/*      */               
/* 1109 */               pixelBytes[in.length - c - 1][i] = (byte)(in[c][i] & 0xFF);
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } else {
/*      */         
/* 1115 */         pixelBytes = new byte[in.length][(in[0]).length * 4];
/* 1116 */         for (int i = 0; i < pixelBytes.length; i++) {
/* 1117 */           for (int j = 0; j < (in[0]).length; j++) {
/* 1118 */             DataTools.unpackBytes(in[i][j], pixelBytes[i], j * 4, 4, little);
/*      */           }
/*      */         }
/*      */       
/*      */       } 
/* 1123 */     } else if (pixels instanceof float[][]) {
/* 1124 */       float[][] in = (float[][])pixels;
/* 1125 */       pixelBytes = new byte[in.length][(in[0]).length * 4];
/* 1126 */       for (int i = 0; i < pixelBytes.length; i++) {
/* 1127 */         for (int j = 0; j < (in[0]).length; j++) {
/* 1128 */           int v = Float.floatToIntBits(in[i][j]);
/* 1129 */           DataTools.unpackBytes(v, pixelBytes[i], j * 4, 4, little);
/*      */         }
/*      */       
/*      */       } 
/* 1133 */     } else if (pixels instanceof double[][]) {
/* 1134 */       double[][] in = (double[][])pixels;
/* 1135 */       pixelBytes = new byte[in.length][(in[0]).length * 8];
/* 1136 */       for (int i = 0; i < pixelBytes.length; i++) {
/* 1137 */         for (int j = 0; j < (in[0]).length; j++) {
/* 1138 */           long v = Double.doubleToLongBits(in[i][j]);
/* 1139 */           DataTools.unpackBytes(v, pixelBytes[i], j * 8, 8, little);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 1144 */     return pixelBytes;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[][] getPixelBytes(WritableRaster r, boolean little, int x, int y, int w, int h) {
/* 1157 */     Object pixels = getPixels(r);
/* 1158 */     byte[][] pixelBytes = (byte[][])null;
/* 1159 */     int bpp = 0;
/*      */     
/* 1161 */     if (pixels instanceof byte[][]) {
/* 1162 */       pixelBytes = (byte[][])pixels;
/* 1163 */       bpp = 1;
/*      */     }
/* 1165 */     else if (pixels instanceof short[][]) {
/* 1166 */       bpp = 2;
/* 1167 */       short[][] s = (short[][])pixels;
/* 1168 */       pixelBytes = new byte[s.length][(s[0]).length * bpp];
/* 1169 */       for (int i = 0; i < pixelBytes.length; i++) {
/* 1170 */         for (int j = 0; j < (s[0]).length; j++) {
/* 1171 */           DataTools.unpackBytes(s[i][j], pixelBytes[i], j * bpp, bpp, little);
/*      */         }
/*      */       }
/*      */     
/* 1175 */     } else if (pixels instanceof int[][]) {
/* 1176 */       bpp = 4;
/* 1177 */       int[][] in = (int[][])pixels;
/*      */       
/* 1179 */       pixelBytes = new byte[in.length][(in[0]).length * bpp];
/* 1180 */       for (int i = 0; i < pixelBytes.length; i++) {
/* 1181 */         for (int j = 0; j < (in[0]).length; j++) {
/* 1182 */           DataTools.unpackBytes(in[i][j], pixelBytes[i], j * bpp, bpp, little);
/*      */         }
/*      */       }
/*      */     
/* 1186 */     } else if (pixels instanceof float[][]) {
/* 1187 */       bpp = 4;
/* 1188 */       float[][] in = (float[][])pixels;
/* 1189 */       pixelBytes = new byte[in.length][(in[0]).length * bpp];
/* 1190 */       for (int i = 0; i < pixelBytes.length; i++) {
/* 1191 */         for (int j = 0; j < (in[0]).length; j++) {
/* 1192 */           int v = Float.floatToIntBits(in[i][j]);
/* 1193 */           DataTools.unpackBytes(v, pixelBytes[i], j * bpp, bpp, little);
/*      */         }
/*      */       
/*      */       } 
/* 1197 */     } else if (pixels instanceof double[][]) {
/* 1198 */       bpp = 8;
/* 1199 */       double[][] in = (double[][])pixels;
/* 1200 */       pixelBytes = new byte[in.length][(in[0]).length * bpp];
/* 1201 */       for (int i = 0; i < pixelBytes.length; i++) {
/* 1202 */         for (int j = 0; j < (in[0]).length; j++) {
/* 1203 */           long v = Double.doubleToLongBits(in[i][j]);
/* 1204 */           DataTools.unpackBytes(v, pixelBytes[i], j * bpp, bpp, little);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 1209 */     if (x == 0 && y == 0 && w == r.getWidth() && h == r.getHeight()) {
/* 1210 */       return pixelBytes;
/*      */     }
/*      */     
/* 1213 */     byte[][] croppedBytes = new byte[pixelBytes.length][w * h * bpp];
/* 1214 */     for (int c = 0; c < croppedBytes.length; c++) {
/* 1215 */       for (int row = 0; row < h; row++) {
/* 1216 */         int src = (row + y) * r.getWidth() * bpp + x * bpp;
/* 1217 */         int dest = row * w * bpp;
/* 1218 */         System.arraycopy(pixelBytes[c], src, croppedBytes[c], dest, w * bpp);
/*      */       } 
/*      */     } 
/* 1221 */     return croppedBytes;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int getPixelType(BufferedImage image) {
/* 1240 */     Raster raster = image.getRaster();
/* 1241 */     if (raster == null) return -1; 
/* 1242 */     DataBuffer buffer = raster.getDataBuffer();
/* 1243 */     if (buffer == null) return -1;
/*      */     
/* 1245 */     if (buffer instanceof SignedByteBuffer) {
/* 1246 */       return 0;
/*      */     }
/* 1248 */     if (buffer instanceof SignedShortBuffer) {
/* 1249 */       return 2;
/*      */     }
/* 1251 */     if (buffer instanceof UnsignedIntBuffer) {
/* 1252 */       return 5;
/*      */     }
/*      */     
/* 1255 */     int type = buffer.getDataType();
/* 1256 */     int imageType = image.getType();
/* 1257 */     switch (type) {
/*      */       case 0:
/* 1259 */         return 1;
/*      */       case 5:
/* 1261 */         return 7;
/*      */       case 4:
/* 1263 */         return 6;
/*      */       case 3:
/* 1265 */         if (imageType == 1 || imageType == 4 || imageType == 2)
/*      */         {
/*      */ 
/*      */           
/* 1269 */           return 1;
/*      */         }
/* 1271 */         if (buffer instanceof UnsignedIntBuffer) {
/* 1272 */           return 5;
/*      */         }
/* 1274 */         return 4;
/*      */       case 2:
/* 1276 */         return 2;
/*      */       case 1:
/* 1278 */         if (imageType == 9 || imageType == 8)
/*      */         {
/*      */           
/* 1281 */           return 1;
/*      */         }
/* 1283 */         return 3;
/*      */     } 
/* 1285 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedImage convertRenderedImage(RenderedImage img) {
/* 1331 */     if (img instanceof BufferedImage) return (BufferedImage)img; 
/* 1332 */     ColorModel cm = img.getColorModel();
/* 1333 */     int width = img.getWidth();
/* 1334 */     int height = img.getHeight();
/* 1335 */     WritableRaster raster = cm.createCompatibleWritableRaster(width, height);
/* 1336 */     boolean isAlphaPremultiplied = cm.isAlphaPremultiplied();
/* 1337 */     Hashtable<String, Object> properties = new Hashtable<String, Object>();
/* 1338 */     String[] keys = img.getPropertyNames();
/* 1339 */     if (keys != null) {
/* 1340 */       for (int i = 0; i < keys.length; i++) {
/* 1341 */         properties.put(keys[i], img.getProperty(keys[i]));
/*      */       }
/*      */     }
/* 1344 */     BufferedImage result = new BufferedImage(cm, raster, isAlphaPremultiplied, properties);
/*      */     
/* 1346 */     img.copyData(raster);
/* 1347 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   public static byte[] getBytes(BufferedImage img, boolean separated) {
/* 1352 */     byte[][] p = getBytes(img);
/* 1353 */     if (separated || p.length == 1) return p[0];
/*      */     
/* 1355 */     byte[] rtn = new byte[p.length * (p[0]).length];
/* 1356 */     for (int i = 0; i < p.length; i++) {
/* 1357 */       System.arraycopy(p[i], 0, rtn, i * (p[0]).length, (p[i]).length);
/*      */     }
/* 1359 */     return rtn;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedImage makeUnsigned(BufferedImage img) {
/* 1366 */     if (img == null) return null; 
/* 1367 */     int pixelType = getPixelType(img);
/* 1368 */     boolean signed = FormatTools.isSigned(pixelType);
/* 1369 */     boolean fp = FormatTools.isFloatingPoint(pixelType);
/* 1370 */     if (!signed || fp) return img;
/*      */     
/* 1372 */     int bpp = FormatTools.getBytesPerPixel(pixelType);
/*      */     
/* 1374 */     byte[][] pix = getPixelBytes(img, false);
/* 1375 */     return makeImage(pix, img.getWidth(), img.getHeight(), bpp, fp, false, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedImage getSubimage(BufferedImage image, boolean littleEndian, int x, int y, int w, int h) {
/* 1385 */     int pixelType = getPixelType(image);
/* 1386 */     byte[][] pix = getPixelBytes(image, littleEndian, x, y, w, h);
/* 1387 */     return makeImage(pix, w, h, FormatTools.getBytesPerPixel(pixelType), FormatTools.isFloatingPoint(pixelType), littleEndian, FormatTools.isSigned(pixelType));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedImage[] splitChannels(BufferedImage image) {
/* 1394 */     int w = image.getWidth(), h = image.getHeight();
/* 1395 */     int c = image.getRaster().getNumBands();
/* 1396 */     if (c == 1) return new BufferedImage[] { image }; 
/* 1397 */     BufferedImage[] results = new BufferedImage[c];
/*      */     
/* 1399 */     Object o = getPixels(image);
/*      */     
/* 1401 */     int pixelType = getPixelType(image);
/* 1402 */     boolean signed = FormatTools.isSigned(pixelType);
/* 1403 */     if (o instanceof byte[][]) {
/* 1404 */       byte[][] pix = (byte[][])o;
/* 1405 */       for (int i = 0; i < c; ) { results[i] = makeImage(pix[i], w, h, signed); i++; }
/*      */     
/* 1407 */     } else if (o instanceof short[][]) {
/* 1408 */       short[][] pix = (short[][])o;
/* 1409 */       for (int i = 0; i < c; ) { results[i] = makeImage(pix[i], w, h, signed); i++; }
/*      */     
/* 1411 */     } else if (o instanceof int[][]) {
/* 1412 */       int[][] pix = (int[][])o;
/* 1413 */       for (int i = 0; i < c; ) { results[i] = makeImage(pix[i], w, h, signed); i++; }
/*      */     
/* 1415 */     } else if (o instanceof float[][]) {
/* 1416 */       float[][] pix = (float[][])o;
/* 1417 */       for (int i = 0; i < c; ) { results[i] = makeImage(pix[i], w, h); i++; }
/*      */     
/* 1419 */     } else if (o instanceof double[][]) {
/* 1420 */       double[][] pix = (double[][])o;
/* 1421 */       for (int i = 0; i < c; ) { results[i] = makeImage(pix[i], w, h); i++; }
/*      */     
/*      */     } 
/* 1424 */     return results;
/*      */   }
/*      */ 
/*      */   
/*      */   public static BufferedImage mergeChannels(BufferedImage[] images) {
/* 1429 */     if (images == null || images.length == 0) return null;
/*      */ 
/*      */     
/* 1432 */     Object[] list = new Object[images.length];
/* 1433 */     int c = 0, type = 0;
/* 1434 */     for (int i = 0; i < images.length; i++) {
/* 1435 */       Object o = getPixels(images[i]);
/* 1436 */       if (o instanceof byte[][]) {
/* 1437 */         if (i == 0) { type = 0; }
/* 1438 */         else if (type != 0) { return null; }
/* 1439 */          c += ((byte[][])o).length;
/*      */       }
/* 1441 */       else if (o instanceof short[][]) {
/* 1442 */         if (i == 0) { type = 1; }
/* 1443 */         else if (type != 1) { return null; }
/* 1444 */          c += ((short[][])o).length;
/*      */       }
/* 1446 */       else if (o instanceof int[][]) {
/* 1447 */         if (i == 0) { type = 3; }
/* 1448 */         else if (type != 3) { return null; }
/* 1449 */          c += ((int[][])o).length;
/*      */       }
/* 1451 */       else if (o instanceof float[][]) {
/* 1452 */         if (i == 0) { type = 4; }
/* 1453 */         else if (type != 4) { return null; }
/* 1454 */          c += ((float[][])o).length;
/*      */       }
/* 1456 */       else if (o instanceof double[][]) {
/* 1457 */         if (i == 0) { type = 5; }
/* 1458 */         else if (type != 5) { return null; }
/* 1459 */          c += ((double[][])o).length;
/*      */       } 
/* 1461 */       if (c > 4) return null; 
/* 1462 */       list[i] = o;
/*      */     } 
/* 1464 */     if (c < 1 || c > 4) return null;
/*      */ 
/*      */     
/* 1467 */     int w = images[0].getWidth(), h = images[0].getHeight();
/* 1468 */     int pixelType = getPixelType(images[0]);
/* 1469 */     boolean signed = FormatTools.isSigned(pixelType);
/* 1470 */     if (type == 0) {
/* 1471 */       byte[][] pix = new byte[c][];
/* 1472 */       int ndx = 0;
/* 1473 */       for (int j = 0; j < list.length; j++) {
/* 1474 */         byte[][] b = (byte[][])list[j];
/* 1475 */         for (int k = 0; k < b.length; ) { pix[ndx++] = b[k]; k++; }
/*      */       
/* 1477 */       }  for (; ndx < pix.length; pix[ndx++] = new byte[w * h]);
/* 1478 */       return makeImage(pix, w, h, signed);
/*      */     } 
/* 1480 */     if (type == 1 || type == 2) {
/* 1481 */       short[][] pix = new short[c][];
/* 1482 */       int ndx = 0;
/* 1483 */       for (int j = 0; j < list.length; j++) {
/* 1484 */         short[][] b = (short[][])list[j];
/* 1485 */         for (int k = 0; k < b.length; ) { pix[ndx++] = b[k]; k++; }
/*      */       
/* 1487 */       }  for (; ndx < pix.length; pix[ndx++] = new short[w * h]);
/* 1488 */       return makeImage(pix, w, h, signed);
/*      */     } 
/* 1490 */     if (type == 3) {
/* 1491 */       int[][] pix = new int[c][];
/* 1492 */       int ndx = 0;
/* 1493 */       for (int j = 0; j < list.length; j++) {
/* 1494 */         int[][] b = (int[][])list[j];
/* 1495 */         for (int k = 0; k < b.length; ) { pix[ndx++] = b[k]; k++; }
/*      */       
/* 1497 */       }  for (; ndx < pix.length; pix[ndx++] = new int[w * h]);
/* 1498 */       return makeImage(pix, w, h, signed);
/*      */     } 
/* 1500 */     if (type == 4) {
/* 1501 */       float[][] pix = new float[c][];
/* 1502 */       int ndx = 0;
/* 1503 */       for (int j = 0; j < list.length; j++) {
/* 1504 */         float[][] b = (float[][])list[j];
/* 1505 */         for (int k = 0; k < b.length; ) { pix[ndx++] = b[k]; k++; }
/*      */       
/* 1507 */       }  for (; ndx < pix.length; pix[ndx++] = new float[w * h]);
/* 1508 */       return makeImage(pix, w, h);
/*      */     } 
/* 1510 */     if (type == 5) {
/* 1511 */       double[][] pix = new double[c][];
/* 1512 */       int ndx = 0;
/* 1513 */       for (int j = 0; j < list.length; j++) {
/* 1514 */         double[][] b = (double[][])list[j];
/* 1515 */         for (int k = 0; k < b.length; ) { pix[ndx++] = b[k]; k++; }
/*      */       
/* 1517 */       }  for (; ndx < pix.length; pix[ndx++] = new double[w * h]);
/* 1518 */       return makeImage(pix, w, h);
/*      */     } 
/*      */     
/* 1521 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedImage padImage(BufferedImage img, int width, int height) {
/* 1530 */     if (img == null) {
/* 1531 */       byte[][] data = new byte[1][width * height];
/* 1532 */       return makeImage(data, width, height, false);
/*      */     } 
/*      */     
/* 1535 */     boolean needsPadding = (img.getWidth() != width || img.getHeight() != height);
/*      */     
/* 1537 */     if (needsPadding) {
/* 1538 */       Object pixels = getPixels(img);
/* 1539 */       int pixelType = getPixelType(img);
/* 1540 */       boolean signed = FormatTools.isSigned(pixelType);
/*      */       
/* 1542 */       if (pixels instanceof byte[][]) {
/* 1543 */         byte[][] b = (byte[][])pixels;
/* 1544 */         byte[][] newBytes = new byte[b.length][width * height];
/* 1545 */         for (int i = 0; i < b.length; i++) {
/* 1546 */           newBytes[i] = ImageTools.padImage(b[i], false, 1, img.getWidth(), width, height);
/*      */         }
/*      */         
/* 1549 */         return makeImage(newBytes, width, height, signed);
/*      */       } 
/* 1551 */       if (pixels instanceof short[][]) {
/* 1552 */         short[][] b = (short[][])pixels;
/* 1553 */         short[][] newShorts = new short[b.length][width * height];
/* 1554 */         for (int i = 0; i < b.length; i++) {
/* 1555 */           newShorts[i] = ImageTools.padImage(b[i], false, 1, img.getWidth(), width, height);
/*      */         }
/*      */         
/* 1558 */         return makeImage(newShorts, width, height, signed);
/*      */       } 
/* 1560 */       if (pixels instanceof int[][]) {
/* 1561 */         int[][] b = (int[][])pixels;
/* 1562 */         int[][] newInts = new int[b.length][width * height];
/* 1563 */         for (int i = 0; i < b.length; i++) {
/* 1564 */           newInts[i] = ImageTools.padImage(b[i], false, 1, img.getWidth(), width, height);
/*      */         }
/*      */         
/* 1567 */         return makeImage(newInts, width, height, signed);
/*      */       } 
/* 1569 */       if (pixels instanceof float[][]) {
/* 1570 */         float[][] b = (float[][])pixels;
/* 1571 */         float[][] newFloats = new float[b.length][width * height];
/* 1572 */         for (int i = 0; i < b.length; i++) {
/* 1573 */           newFloats[i] = ImageTools.padImage(b[i], false, 1, img.getWidth(), width, height);
/*      */         }
/*      */         
/* 1576 */         return makeImage(newFloats, width, height);
/*      */       } 
/* 1578 */       if (pixels instanceof double[][]) {
/* 1579 */         double[][] b = (double[][])pixels;
/* 1580 */         double[][] newDoubles = new double[b.length][width * height];
/* 1581 */         for (int i = 0; i < b.length; i++) {
/* 1582 */           newDoubles[i] = ImageTools.padImage(b[i], false, 1, img.getWidth(), width, height);
/*      */         }
/*      */         
/* 1585 */         return makeImage(newDoubles, width, height);
/*      */       } 
/* 1587 */       return null;
/*      */     } 
/* 1589 */     return img;
/*      */   }
/*      */ 
/*      */   
/*      */   public static BufferedImage autoscale(BufferedImage img) {
/* 1594 */     byte[][] pixels = getPixelBytes(img, true);
/* 1595 */     double min = Double.MAX_VALUE;
/* 1596 */     double max = 0.0D;
/* 1597 */     int bits = (pixels[0]).length / img.getWidth() * img.getHeight() * 8;
/* 1598 */     for (int i = 0; i < pixels.length; i++) {
/* 1599 */       Double[] mm = ImageTools.scanData(pixels[0], bits, true);
/* 1600 */       double tmin = mm[0].doubleValue();
/* 1601 */       double tmax = mm[1].doubleValue();
/* 1602 */       if (tmin < min) min = tmin; 
/* 1603 */       if (tmax > max) max = tmax;
/*      */     
/*      */     } 
/* 1606 */     return autoscale(img, (int)min, (int)max);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedImage autoscale(BufferedImage img, int min, int max) {
/* 1615 */     Object pixels = getPixels(img);
/* 1616 */     int pixelType = getPixelType(img);
/* 1617 */     boolean signed = FormatTools.isSigned(pixelType);
/*      */     
/* 1619 */     if (pixels instanceof byte[][]) return img; 
/* 1620 */     if (pixels instanceof short[][]) {
/* 1621 */       short[][] shorts = (short[][])pixels;
/* 1622 */       byte[][] out = new byte[shorts.length][(shorts[0]).length];
/*      */       
/* 1624 */       for (int i = 0; i < out.length; i++) {
/* 1625 */         for (int j = 0; j < (out[i]).length; j++) {
/* 1626 */           if (shorts[i][j] < 0) shorts[i][j] = (short)(shorts[i][j] + 32767);
/*      */           
/* 1628 */           int diff = max - min;
/* 1629 */           float dist = (shorts[i][j] - min) / diff;
/*      */           
/* 1631 */           if (shorts[i][j] >= max) { out[i][j] = -1; }
/* 1632 */           else if (shorts[i][j] <= min) { out[i][j] = 0; }
/* 1633 */           else { out[i][j] = (byte)(int)(dist * 256.0F); }
/*      */         
/*      */         } 
/*      */       } 
/* 1637 */       return makeImage(out, img.getWidth(), img.getHeight(), signed);
/*      */     } 
/* 1639 */     if (pixels instanceof int[][]) {
/* 1640 */       int[][] ints = (int[][])pixels;
/* 1641 */       byte[][] out = new byte[ints.length][(ints[0]).length];
/*      */       
/* 1643 */       for (int i = 0; i < out.length; i++) {
/* 1644 */         for (int j = 0; j < (out[i]).length; j++) {
/* 1645 */           if (ints[i][j] >= max) { out[i][j] = -1; }
/* 1646 */           else if (ints[i][j] <= min) { out[i][j] = 0; }
/*      */           else
/* 1648 */           { int diff = max - min;
/* 1649 */             float dist = ((ints[i][j] - min) / diff);
/* 1650 */             out[i][j] = (byte)(int)(dist * 256.0F); }
/*      */         
/*      */         } 
/*      */       } 
/*      */       
/* 1655 */       return makeImage(out, img.getWidth(), img.getHeight(), signed);
/*      */     } 
/* 1657 */     if (pixels instanceof float[][]) {
/* 1658 */       float[][] floats = (float[][])pixels;
/* 1659 */       byte[][] out = new byte[floats.length][(floats[0]).length];
/*      */       
/* 1661 */       for (int i = 0; i < out.length; i++) {
/* 1662 */         for (int j = 0; j < (out[i]).length; j++) {
/* 1663 */           if (floats[i][j] >= max) { out[i][j] = -1; }
/* 1664 */           else if (floats[i][j] <= min) { out[i][j] = 0; }
/*      */           else
/* 1666 */           { int diff = max - min;
/* 1667 */             float dist = (floats[i][j] - min) / diff;
/* 1668 */             out[i][j] = (byte)(int)(dist * 256.0F); }
/*      */         
/*      */         } 
/*      */       } 
/*      */       
/* 1673 */       return makeImage(out, img.getWidth(), img.getHeight(), signed);
/*      */     } 
/* 1675 */     if (pixels instanceof double[][]) {
/* 1676 */       double[][] doubles = (double[][])pixels;
/* 1677 */       byte[][] out = new byte[doubles.length][(doubles[0]).length];
/*      */       
/* 1679 */       for (int i = 0; i < out.length; i++) {
/* 1680 */         for (int j = 0; j < (out[i]).length; j++) {
/* 1681 */           if (doubles[i][j] >= max) { out[i][j] = -1; }
/* 1682 */           else if (doubles[i][j] <= min) { out[i][j] = 0; }
/*      */           else
/* 1684 */           { int diff = max - min;
/* 1685 */             float dist = (float)(doubles[i][j] - min) / diff;
/* 1686 */             out[i][j] = (byte)(int)(dist * 256.0F); }
/*      */         
/*      */         } 
/*      */       } 
/*      */       
/* 1691 */       return makeImage(out, img.getWidth(), img.getHeight(), signed);
/*      */     } 
/* 1693 */     return img;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedImage copyScaled(BufferedImage source, BufferedImage target, Object hint) {
/* 1702 */     if (hint == null) hint = RenderingHints.VALUE_INTERPOLATION_BICUBIC; 
/* 1703 */     Graphics2D g2 = target.createGraphics();
/* 1704 */     g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, hint);
/* 1705 */     double scalex = target.getWidth() / source.getWidth();
/* 1706 */     double scaley = target.getHeight() / source.getHeight();
/* 1707 */     AffineTransform xform = AffineTransform.getScaleInstance(scalex, scaley);
/* 1708 */     g2.drawRenderedImage(source, xform);
/* 1709 */     g2.dispose();
/* 1710 */     return target;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedImage scale2D(BufferedImage image, int width, int height, Object hint, GraphicsConfiguration gc) {
/* 1720 */     if (gc == null) gc = getDefaultConfiguration(); 
/* 1721 */     int trans = image.getColorModel().getTransparency();
/* 1722 */     return copyScaled(image, gc.createCompatibleImage(width, height, trans), hint);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedImage scale2D(BufferedImage image, int width, int height, Object hint, ColorModel cm) {
/* 1733 */     WritableRaster raster = cm.createCompatibleWritableRaster(width, height);
/* 1734 */     boolean isRasterPremultiplied = cm.isAlphaPremultiplied();
/* 1735 */     return copyScaled(image, new BufferedImage(cm, raster, isRasterPremultiplied, null), hint);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Image scaleAWT(BufferedImage source, int width, int height, int hint) {
/* 1743 */     return source.getScaledInstance(width, height, hint);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedImage scale(BufferedImage source, int width, int height, boolean pad) {
/* 1753 */     int w = source.getWidth();
/* 1754 */     int h = source.getHeight();
/* 1755 */     if (w == width && h == height) return source;
/*      */     
/* 1757 */     int finalWidth = width, finalHeight = height;
/*      */     
/* 1759 */     if (pad) {
/*      */       
/* 1761 */       double r = w / h;
/* 1762 */       double ratio = width / height;
/* 1763 */       if (r > ratio) {
/*      */         
/* 1765 */         height = h * width / w;
/*      */       }
/*      */       else {
/*      */         
/* 1769 */         width = w * height / h;
/*      */       } 
/*      */     } 
/*      */     
/* 1773 */     int pixelType = getPixelType(source);
/*      */     
/* 1775 */     BufferedImage result = null;
/* 1776 */     ColorModel sourceModel = source.getColorModel();
/* 1777 */     if (sourceModel instanceof Index16ColorModel || sourceModel instanceof IndexColorModel || sourceModel instanceof SignedColorModel) {
/*      */ 
/*      */ 
/*      */       
/* 1781 */       DataBuffer buffer = source.getData().getDataBuffer();
/* 1782 */       WritableRaster raster = Raster.createWritableRaster(source.getSampleModel(), buffer, null);
/*      */ 
/*      */       
/* 1785 */       ColorModel model = makeColorModel(1, buffer.getDataType());
/* 1786 */       if (sourceModel instanceof SignedColorModel) {
/* 1787 */         model = sourceModel;
/*      */       }
/* 1789 */       source = new BufferedImage(model, raster, false, null);
/*      */       
/* 1791 */       Image scaled = scaleAWT(source, width, height, 16);
/*      */       
/* 1793 */       result = makeBuffered(scaled, sourceModel);
/*      */       
/* 1795 */       raster = Raster.createWritableRaster(result.getSampleModel(), result.getData().getDataBuffer(), null);
/*      */       
/* 1797 */       result = new BufferedImage(sourceModel, raster, false, null);
/*      */     } else {
/*      */       
/* 1800 */       if (FormatTools.isSigned(pixelType)) {
/* 1801 */         source = makeUnsigned(source);
/* 1802 */         sourceModel = null;
/*      */       } 
/* 1804 */       Image scaled = scaleAWT(source, width, height, 16);
/*      */       
/* 1806 */       result = makeBuffered(scaled, sourceModel);
/*      */     } 
/* 1808 */     return padImage(result, finalWidth, finalHeight);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedImage makeBuffered(Image image) {
/* 1818 */     if (image instanceof BufferedImage) return (BufferedImage)image;
/*      */ 
/*      */     
/* 1821 */     loadImage(image);
/* 1822 */     BufferedImage img = new BufferedImage(image.getWidth(OBS), image.getHeight(OBS), 1);
/*      */     
/* 1824 */     Graphics g = img.getGraphics();
/* 1825 */     g.drawImage(image, 0, 0, OBS);
/* 1826 */     g.dispose();
/* 1827 */     return img;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedImage makeBuffered(Image image, ColorModel cm) {
/* 1836 */     if (cm == null) return makeBuffered(image);
/*      */     
/* 1838 */     if (image instanceof BufferedImage) {
/* 1839 */       BufferedImage bi = (BufferedImage)image;
/* 1840 */       if (cm.equals(bi.getColorModel())) return bi; 
/*      */     } 
/* 1842 */     loadImage(image);
/* 1843 */     int w = image.getWidth(OBS), h = image.getHeight(OBS);
/* 1844 */     boolean alphaPremultiplied = cm.isAlphaPremultiplied();
/* 1845 */     WritableRaster raster = cm.createCompatibleWritableRaster(w, h);
/* 1846 */     BufferedImage result = new BufferedImage(cm, raster, alphaPremultiplied, null);
/*      */     
/* 1848 */     Graphics2D g = result.createGraphics();
/* 1849 */     g.drawImage(image, 0, 0, OBS);
/* 1850 */     g.dispose();
/* 1851 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   public static boolean loadImage(Image image) {
/* 1856 */     if (image instanceof BufferedImage) return true; 
/* 1857 */     MediaTracker tracker = new MediaTracker(OBS);
/* 1858 */     tracker.addImage(image, 0); 
/* 1859 */     try { tracker.waitForID(0); }
/* 1860 */     catch (InterruptedException exc) { return false; }
/* 1861 */      if (8 != tracker.statusID(0, false)) return false; 
/* 1862 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Dimension getSize(Image image) {
/* 1870 */     if (image == null) return new Dimension(0, 0); 
/* 1871 */     if (image instanceof BufferedImage) {
/* 1872 */       BufferedImage bi = (BufferedImage)image;
/* 1873 */       return new Dimension(bi.getWidth(), bi.getHeight());
/*      */     } 
/* 1875 */     loadImage(image);
/* 1876 */     return new Dimension(image.getWidth(OBS), image.getHeight(OBS));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedImage makeCompatible(BufferedImage image, GraphicsConfiguration gc) {
/* 1889 */     if (gc == null) gc = getDefaultConfiguration(); 
/* 1890 */     int w = image.getWidth(), h = image.getHeight();
/* 1891 */     int trans = image.getColorModel().getTransparency();
/* 1892 */     BufferedImage result = gc.createCompatibleImage(w, h, trans);
/* 1893 */     Graphics2D g2 = result.createGraphics();
/* 1894 */     g2.drawRenderedImage(image, (AffineTransform)null);
/* 1895 */     g2.dispose();
/* 1896 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   public static GraphicsConfiguration getDefaultConfiguration() {
/* 1901 */     GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
/* 1902 */     GraphicsDevice gd = ge.getDefaultScreenDevice();
/* 1903 */     return gd.getDefaultConfiguration();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ColorSpace makeColorSpace(int c) {
/*      */     int type;
/* 1911 */     switch (c) {
/*      */       case 1:
/* 1913 */         type = 1003;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1927 */         return TwoChannelColorSpace.getInstance(type);case 2: type = -1; return TwoChannelColorSpace.getInstance(type);case 3: type = 1000; return TwoChannelColorSpace.getInstance(type);case 4: type = 1000; return TwoChannelColorSpace.getInstance(type);
/*      */     } 
/*      */     return null;
/*      */   }
/*      */   public static ColorModel makeColorModel(int c, int dataType) {
/* 1932 */     ColorSpace cs = makeColorSpace(c);
/* 1933 */     return (cs == null) ? null : new ComponentColorModel(cs, (c == 4), false, 3, dataType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedImage indexedToRGB(BufferedImage img, boolean le) {
/* 1941 */     byte[][] indices = getPixelBytes(img, le);
/* 1942 */     if (indices.length > 1) return img;
/*      */     
/* 1944 */     int pixelType = getPixelType(img);
/* 1945 */     boolean signed = FormatTools.isSigned(pixelType);
/* 1946 */     if (pixelType == 1) {
/* 1947 */       IndexColorModel model = (IndexColorModel)img.getColorModel();
/* 1948 */       byte[][] b = new byte[3][(indices[0]).length];
/* 1949 */       for (int i = 0; i < (indices[0]).length; i++) {
/* 1950 */         b[0][i] = (byte)(model.getRed(indices[0][i] & 0xFF) & 0xFF);
/* 1951 */         b[1][i] = (byte)(model.getGreen(indices[0][i] & 0xFF) & 0xFF);
/* 1952 */         b[2][i] = (byte)(model.getBlue(indices[0][i] & 0xFF) & 0xFF);
/*      */       } 
/* 1954 */       return makeImage(b, img.getWidth(), img.getHeight(), signed);
/*      */     } 
/* 1956 */     if (pixelType == 3) {
/* 1957 */       Index16ColorModel model = (Index16ColorModel)img.getColorModel();
/* 1958 */       short[][] s = new short[3][(indices[0]).length / 2];
/* 1959 */       for (int i = 0; i < (s[0]).length; i++) {
/* 1960 */         int ndx = DataTools.bytesToInt(indices[0], i * 2, 2, le) & 0xFFFF;
/* 1961 */         s[0][i] = (short)(model.getRed(ndx) & 0xFFFF);
/* 1962 */         s[1][i] = (short)(model.getRed(ndx) & 0xFFFF);
/* 1963 */         s[2][i] = (short)(model.getRed(ndx) & 0xFFFF);
/*      */       } 
/* 1965 */       return makeImage(s, img.getWidth(), img.getHeight(), signed);
/*      */     } 
/* 1967 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public static byte[][] get8BitLookupTable(ColorModel model) {
/* 1972 */     if (!(model instanceof IndexColorModel)) return (byte[][])null; 
/* 1973 */     IndexColorModel m = (IndexColorModel)model;
/* 1974 */     byte[][] lut = new byte[3][m.getMapSize()];
/* 1975 */     m.getReds(lut[0]);
/* 1976 */     m.getGreens(lut[1]);
/* 1977 */     m.getBlues(lut[2]);
/* 1978 */     return lut;
/*      */   }
/*      */ 
/*      */   
/*      */   public static short[][] getLookupTable(ColorModel model) {
/* 1983 */     if (!(model instanceof Index16ColorModel)) return (short[][])null; 
/* 1984 */     Index16ColorModel m = (Index16ColorModel)model;
/* 1985 */     short[][] lut = new short[3][];
/* 1986 */     lut[0] = m.getReds();
/* 1987 */     lut[1] = m.getGreens();
/* 1988 */     lut[2] = m.getBlues();
/* 1989 */     return lut;
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/gui/AWTImageTools.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */