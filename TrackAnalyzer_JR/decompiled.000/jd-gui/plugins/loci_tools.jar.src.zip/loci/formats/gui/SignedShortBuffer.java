/*     */ package loci.formats.gui;
/*     */ 
/*     */ import java.awt.image.DataBuffer;
/*     */ import java.awt.image.DataBufferShort;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SignedShortBuffer
/*     */   extends DataBuffer
/*     */ {
/*     */   private DataBufferShort helper;
/*     */   
/*     */   public SignedShortBuffer(int size) {
/*  62 */     super(1, size);
/*  63 */     this.helper = new DataBufferShort(size);
/*     */   }
/*     */   
/*     */   public SignedShortBuffer(int size, int numbanks) {
/*  67 */     super(1, size, numbanks);
/*  68 */     this.helper = new DataBufferShort(size, numbanks);
/*     */   }
/*     */   
/*     */   public SignedShortBuffer(short[] data, int size) {
/*  72 */     super(1, size);
/*  73 */     this.helper = new DataBufferShort(data, size);
/*     */   }
/*     */   
/*     */   public SignedShortBuffer(short[] data, int size, int offset) {
/*  77 */     super(1, size, 1, offset);
/*  78 */     this.helper = new DataBufferShort(data, size, offset);
/*     */   }
/*     */   
/*     */   public SignedShortBuffer(short[][] data, int size) {
/*  82 */     super(1, size, data.length);
/*  83 */     this.helper = new DataBufferShort(data, size);
/*     */   }
/*     */   
/*     */   public SignedShortBuffer(short[][] data, int size, int[] offsets) {
/*  87 */     super(1, size, data.length, offsets);
/*  88 */     this.helper = new DataBufferShort(data, size, offsets);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public short[] getData() {
/*  95 */     return this.helper.getData();
/*     */   }
/*     */ 
/*     */   
/*     */   public short[] getData(int bank) {
/* 100 */     return this.helper.getData(bank);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getElem(int bank, int i) {
/* 105 */     return this.helper.getElem(bank, i);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setElem(int bank, int i, int val) {
/* 110 */     this.helper.setElem(bank, i, val);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/gui/SignedShortBuffer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */