/*     */ package loci.formats.in;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.Vector;
/*     */ import java.util.zip.InflaterInputStream;
/*     */ import loci.common.RandomAccessInputStream;
/*     */ import loci.formats.FormatException;
/*     */ import loci.formats.FormatReader;
/*     */ import loci.formats.FormatTools;
/*     */ import loci.formats.IFormatReader;
/*     */ import loci.formats.MetadataTools;
/*     */ import loci.formats.UnsupportedCompressionException;
/*     */ import loci.formats.codec.BitBuffer;
/*     */ import loci.formats.meta.MetadataStore;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class APNGReader
/*     */   extends FormatReader
/*     */ {
/*     */   private static final int GRAYSCALE = 0;
/*     */   private static final int TRUE_COLOR = 2;
/*     */   private static final int INDEXED = 3;
/*     */   private static final int GRAY_ALPHA = 4;
/*     */   private static final int TRUE_ALPHA = 6;
/*     */   private static final int NONE = 0;
/*     */   private static final int SUB = 1;
/*     */   private static final int UP = 2;
/*     */   private static final int AVERAGE = 3;
/*     */   private static final int PAETH = 4;
/*  83 */   private static final int[] PASS_WIDTHS = new int[] { 1, 1, 2, 2, 4, 4, 8 };
/*  84 */   private static final int[] PASS_HEIGHTS = new int[] { 1, 1, 1, 2, 2, 4, 4 };
/*     */   
/*     */   private Vector<PNGBlock> blocks;
/*     */   
/*     */   private Vector<int[]> frameCoordinates;
/*     */   
/*     */   private byte[][] lut;
/*     */   
/*     */   private byte[] lastImage;
/*     */   
/*  94 */   private int lastImageIndex = -1;
/*     */   
/*     */   private int compression;
/*     */   private int interlace;
/*  98 */   private int idatCount = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public APNGReader() {
/* 104 */     super("Animated PNG", "png");
/* 105 */     this.domains = new String[] { "Graphics" };
/* 106 */     this.suffixNecessary = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isThisType(RandomAccessInputStream stream) throws IOException {
/* 113 */     int blockLen = 8;
/* 114 */     if (!FormatTools.validStream(stream, 8, false)) return false;
/*     */     
/* 116 */     byte[] signature = new byte[8];
/* 117 */     stream.read(signature);
/*     */     
/* 119 */     if (signature[0] != -119 || signature[1] != 80 || signature[2] != 78 || signature[3] != 71 || signature[4] != 13 || signature[5] != 10 || signature[6] != 26 || signature[7] != 10)
/*     */     {
/*     */ 
/*     */       
/* 123 */       return false;
/*     */     }
/* 125 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[][] get8BitLookupTable() {
/* 130 */     FormatTools.assertId(this.currentId, true, 1);
/* 131 */     return this.lut;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] openBytes(int no, byte[] buf, int x, int y, int w, int h) throws FormatException, IOException {
/* 140 */     FormatTools.checkPlaneParameters((IFormatReader)this, no, buf.length, x, y, w, h);
/*     */     
/* 142 */     if (no == this.lastImageIndex && this.lastImage != null) {
/* 143 */       RandomAccessInputStream randomAccessInputStream = new RandomAccessInputStream(this.lastImage);
/* 144 */       readPlane(randomAccessInputStream, x, y, w, h, buf);
/* 145 */       randomAccessInputStream.close();
/* 146 */       return buf;
/*     */     } 
/*     */     
/* 149 */     if (no == 0) {
/* 150 */       ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
/* 151 */       int i = 0;
/*     */       
/* 153 */       for (PNGBlock block : this.blocks) {
/* 154 */         if (block.type.equals("IDAT")) {
/* 155 */           this.in.seek(block.offset);
/* 156 */           byte[] tmp = new byte[block.length];
/* 157 */           this.in.read(tmp);
/* 158 */           byteArrayOutputStream.write(tmp);
/* 159 */           tmp = null;
/*     */           
/* 161 */           i++;
/*     */         } 
/* 163 */         if (i == this.idatCount) {
/*     */           break;
/*     */         }
/*     */       } 
/*     */       
/* 168 */       byteArrayOutputStream.close();
/*     */       
/* 170 */       this.lastImage = decode(byteArrayOutputStream.toByteArray());
/* 171 */       this.lastImageIndex = 0;
/*     */       
/* 173 */       RandomAccessInputStream randomAccessInputStream = new RandomAccessInputStream(this.lastImage);
/* 174 */       readPlane(randomAccessInputStream, x, y, w, h, buf);
/* 175 */       randomAccessInputStream.close();
/* 176 */       return buf;
/*     */     } 
/*     */     
/* 179 */     ByteArrayOutputStream s = new ByteArrayOutputStream();
/* 180 */     int readIDATs = 0;
/*     */     
/* 182 */     for (PNGBlock block : this.blocks) {
/* 183 */       if (block.type.equals("IDAT")) {
/* 184 */         this.in.seek(block.offset);
/* 185 */         byte[] tmp = new byte[block.length];
/* 186 */         this.in.read(tmp);
/* 187 */         s.write(tmp);
/* 188 */         tmp = null;
/*     */         
/* 190 */         readIDATs++;
/*     */       } 
/* 192 */       if (readIDATs == this.idatCount) {
/*     */         break;
/*     */       }
/*     */     } 
/*     */     
/* 197 */     boolean fdatValid = false;
/* 198 */     int fctlCount = 0;
/* 199 */     int[] coords = this.frameCoordinates.get(no);
/*     */     
/* 201 */     s = new ByteArrayOutputStream();
/*     */     
/* 203 */     for (PNGBlock block : this.blocks) {
/* 204 */       if (block.type.equals("fcTL")) {
/* 205 */         fdatValid = (fctlCount == no);
/* 206 */         fctlCount++; continue;
/*     */       } 
/* 208 */       if (block.type.equals("fdAT")) {
/* 209 */         this.in.seek(block.offset + 4L);
/* 210 */         if (fdatValid) {
/* 211 */           byte[] tmp = new byte[block.length - 4];
/* 212 */           this.in.read(tmp);
/* 213 */           s.write(tmp);
/* 214 */           tmp = null;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 219 */     s.close();
/* 220 */     this.lastImage = openBytes(0);
/* 221 */     byte[] newImage = decode(s.toByteArray(), coords[2], coords[3]);
/*     */ 
/*     */ 
/*     */     
/* 225 */     int bpp = FormatTools.getBytesPerPixel(getPixelType());
/* 226 */     int len = coords[2] * bpp;
/* 227 */     int plane = getSizeX() * getSizeY() * bpp;
/* 228 */     int newPlane = len * coords[3];
/* 229 */     for (int c = 0; c < getRGBChannelCount(); c++) {
/* 230 */       for (int row = 0; row < coords[3]; row++) {
/* 231 */         System.arraycopy(newImage, c * newPlane + row * len, this.lastImage, c * plane + (coords[1] + row) * getSizeX() * bpp + coords[0] * bpp, len);
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 237 */     this.lastImageIndex = no;
/*     */     
/* 239 */     RandomAccessInputStream pix = new RandomAccessInputStream(this.lastImage);
/* 240 */     readPlane(pix, x, y, w, h, buf);
/* 241 */     pix.close();
/* 242 */     return buf;
/*     */   }
/*     */ 
/*     */   
/*     */   public void close(boolean fileOnly) throws IOException {
/* 247 */     super.close(fileOnly);
/* 248 */     if (!fileOnly) {
/* 249 */       this.lut = (byte[][])null;
/* 250 */       this.frameCoordinates = null;
/* 251 */       this.blocks = null;
/* 252 */       this.lastImage = null;
/* 253 */       this.lastImageIndex = -1;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initFile(String id) throws FormatException, IOException {
/* 261 */     super.initFile(id);
/* 262 */     this.in = new RandomAccessInputStream(id);
/*     */ 
/*     */     
/* 265 */     byte[] signature = new byte[8];
/* 266 */     this.in.read(signature);
/*     */     
/* 268 */     if (signature[0] != -119 || signature[1] != 80 || signature[2] != 78 || signature[3] != 71 || signature[4] != 13 || signature[5] != 10 || signature[6] != 26 || signature[7] != 10)
/*     */     {
/*     */ 
/*     */       
/* 272 */       throw new FormatException("Invalid PNG signature.");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 281 */     this.blocks = new Vector<PNGBlock>();
/* 282 */     this.frameCoordinates = (Vector)new Vector<int>();
/*     */     
/* 284 */     while (this.in.getFilePointer() < this.in.length()) {
/* 285 */       int length = this.in.readInt();
/* 286 */       String type = this.in.readString(4);
/*     */       
/* 288 */       PNGBlock block = new PNGBlock();
/* 289 */       block.length = length;
/* 290 */       block.type = type;
/* 291 */       block.offset = this.in.getFilePointer();
/* 292 */       this.blocks.add(block);
/*     */       
/* 294 */       if (type.equals("acTL")) {
/*     */         
/* 296 */         (this.core[0]).imageCount = this.in.readInt();
/* 297 */         int loop = this.in.readInt();
/* 298 */         addGlobalMeta("Loop count", loop);
/*     */       }
/* 300 */       else if (type.equals("fcTL")) {
/* 301 */         this.in.skipBytes(4);
/* 302 */         int w = this.in.readInt();
/* 303 */         int h = this.in.readInt();
/* 304 */         int x = this.in.readInt();
/* 305 */         int y = this.in.readInt();
/* 306 */         this.frameCoordinates.add(new int[] { x, y, w, h });
/* 307 */         this.in.skipBytes(length - 20);
/*     */       }
/* 309 */       else if (type.equals("IDAT")) {
/* 310 */         this.idatCount++;
/*     */       }
/* 312 */       else if (type.equals("PLTE")) {
/*     */ 
/*     */         
/* 315 */         (this.core[0]).indexed = true;
/* 316 */         this.lut = new byte[3][256];
/*     */         
/* 318 */         for (int i = 0; i < length / 3; i++) {
/* 319 */           for (int c = 0; c < 3; c++) {
/* 320 */             this.lut[c][i] = this.in.readByte();
/*     */           }
/*     */         }
/*     */       
/* 324 */       } else if (type.equals("IHDR")) {
/* 325 */         (this.core[0]).sizeX = this.in.readInt();
/* 326 */         (this.core[0]).sizeY = this.in.readInt();
/* 327 */         (this.core[0]).bitsPerPixel = this.in.read();
/* 328 */         int colorType = this.in.read();
/* 329 */         this.compression = this.in.read();
/* 330 */         int filter = this.in.read();
/* 331 */         this.interlace = this.in.read();
/*     */         
/* 333 */         if (filter != 0) {
/* 334 */           throw new FormatException("Invalid filter mode: " + filter);
/*     */         }
/*     */         
/* 337 */         switch (colorType) {
/*     */           case 0:
/*     */           case 3:
/* 340 */             (this.core[0]).sizeC = 1;
/*     */             break;
/*     */           case 4:
/* 343 */             (this.core[0]).sizeC = 2;
/*     */             break;
/*     */           case 2:
/* 346 */             (this.core[0]).sizeC = 3;
/*     */             break;
/*     */           case 6:
/* 349 */             (this.core[0]).sizeC = 4;
/*     */             break;
/*     */         } 
/*     */         
/* 353 */         (this.core[0]).pixelType = (getBitsPerPixel() <= 8) ? 1 : 3;
/*     */         
/* 355 */         (this.core[0]).rgb = (getSizeC() > 1);
/*     */       }
/* 357 */       else if (type.equals("IEND")) {
/*     */         break;
/*     */       } 
/* 360 */       this.in.seek(block.offset + length);
/*     */       
/* 362 */       if (this.in.getFilePointer() < this.in.length() - 4L) {
/* 363 */         this.in.skipBytes(4);
/*     */       }
/*     */     } 
/*     */     
/* 367 */     if ((this.core[0]).imageCount == 0) (this.core[0]).imageCount = 1; 
/* 368 */     (this.core[0]).sizeZ = 1;
/* 369 */     (this.core[0]).sizeT = getImageCount();
/*     */     
/* 371 */     (this.core[0]).dimensionOrder = "XYCTZ";
/* 372 */     (this.core[0]).interleaved = false;
/* 373 */     (this.core[0]).falseColor = false;
/*     */     
/* 375 */     MetadataStore store = makeFilterMetadata();
/* 376 */     MetadataTools.populatePixels(store, (IFormatReader)this);
/*     */   }
/*     */   
/*     */   private byte[] decode(byte[] bytes) throws FormatException, IOException {
/* 380 */     return decode(bytes, getSizeX(), getSizeY());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] decode(byte[] bytes, int width, int height) throws FormatException, IOException {
/* 386 */     int bpp = FormatTools.getBytesPerPixel(getPixelType());
/* 387 */     int rowLen = width * getRGBChannelCount() * bpp;
/*     */     
/* 389 */     if (getBitsPerPixel() < bpp * 8) {
/* 390 */       rowLen /= bpp * 8 / getBitsPerPixel();
/*     */     }
/*     */     
/* 393 */     byte[] image = null;
/*     */     
/* 395 */     if (this.compression == 0 && this.interlace == 0) {
/*     */       
/* 397 */       byte[] filters = new byte[height];
/* 398 */       image = new byte[rowLen * height];
/*     */       
/* 400 */       InflaterInputStream decompressor = new InflaterInputStream(new ByteArrayInputStream(bytes));
/*     */       
/*     */       try {
/* 403 */         for (int row = 0; row < height; row++) {
/* 404 */           int n = 0;
/* 405 */           while (n < 1) {
/* 406 */             n = decompressor.read(filters, row, 1);
/*     */           }
/* 408 */           n = 0;
/* 409 */           while (n < rowLen) {
/* 410 */             n += decompressor.read(image, row * rowLen + n, rowLen - n);
/*     */           }
/*     */         } 
/*     */       } finally {
/*     */         
/* 415 */         decompressor.close();
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 420 */       unfilter(filters, image, width, height);
/*     */     }
/* 422 */     else if (this.compression == 0) {
/*     */       
/* 424 */       int byteCount = 0;
/*     */       
/* 426 */       byte[][] passImages = new byte[7][];
/*     */       
/* 428 */       int nRowBlocks = height / 8;
/* 429 */       int nColBlocks = width / 8;
/*     */       
/* 431 */       image = new byte[FormatTools.getPlaneSize((IFormatReader)this)];
/*     */       
/* 433 */       InflaterInputStream decompressor = new InflaterInputStream(new ByteArrayInputStream(bytes));
/*     */       
/*     */       try {
/* 436 */         for (int i = 0; i < passImages.length; i++) {
/* 437 */           int passWidth = PASS_WIDTHS[i] * nColBlocks;
/* 438 */           int passHeight = PASS_HEIGHTS[i] * nRowBlocks;
/*     */           
/* 440 */           int rowSize = passWidth * bpp * getRGBChannelCount();
/*     */           
/* 442 */           byte[] filters = new byte[passHeight];
/* 443 */           passImages[i] = new byte[rowSize * passHeight];
/*     */           
/* 445 */           for (int j = 0; j < passHeight; j++) {
/* 446 */             int n = 0;
/* 447 */             while (n < 1) {
/* 448 */               n = decompressor.read(filters, j, 1);
/*     */             }
/* 450 */             n = 0;
/* 451 */             while (n < rowSize) {
/* 452 */               n += decompressor.read(passImages[i], j * rowSize + n, rowSize - n);
/*     */             }
/*     */           } 
/*     */ 
/*     */           
/* 457 */           unfilter(filters, passImages[i], passWidth, passHeight);
/*     */         } 
/*     */       } finally {
/*     */         
/* 461 */         decompressor.close();
/*     */       } 
/*     */       
/* 464 */       int chunk = bpp * getRGBChannelCount();
/* 465 */       int[] passOffset = new int[7];
/*     */       
/* 467 */       for (int row = 0; row < height; row++) {
/* 468 */         int rowOffset = row * width * chunk;
/* 469 */         for (int col = 0; col < width; col++) {
/* 470 */           int blockRow = row % 8;
/* 471 */           int blockCol = col % 8;
/*     */           
/* 473 */           int pass = -1;
/*     */           
/* 475 */           if (blockRow % 2 == 1) {
/* 476 */             pass = 6;
/*     */           }
/* 478 */           else if (blockRow == 0 || blockRow == 4) {
/* 479 */             if (blockCol % 2 == 1) {
/* 480 */               pass = 5;
/*     */             }
/* 482 */             else if (blockCol == 0) {
/* 483 */               pass = (blockRow == 0) ? 0 : 2;
/*     */             }
/* 485 */             else if (blockCol == 4) {
/* 486 */               pass = (blockRow == 0) ? 1 : 2;
/*     */             } else {
/*     */               
/* 489 */               pass = 3;
/*     */             } 
/*     */           } else {
/*     */             
/* 493 */             pass = 4 + blockCol % 2;
/*     */           } 
/*     */           
/* 496 */           int colOffset = col * chunk;
/* 497 */           for (int i = 0; i < chunk; i++) {
/* 498 */             passOffset[pass] = passOffset[pass] + 1; image[rowOffset + colOffset + i] = passImages[pass][passOffset[pass]];
/*     */           }
/*     */         
/*     */         } 
/*     */       } 
/*     */     } else {
/*     */       
/* 505 */       throw new UnsupportedCompressionException("Compression type " + this.compression + " not supported");
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 511 */     if (getBitsPerPixel() < 8) {
/* 512 */       byte[] expandedImage = new byte[FormatTools.getPlaneSize((IFormatReader)this)];
/* 513 */       BitBuffer bits = new BitBuffer(image);
/*     */       
/* 515 */       for (int i = 0; i < expandedImage.length; i++) {
/* 516 */         expandedImage[i] = (byte)(bits.getBits(getBitsPerPixel()) & 0xFF);
/*     */       }
/*     */       
/* 519 */       image = expandedImage;
/*     */     } 
/*     */     
/* 522 */     byte[] deinterleave = new byte[image.length];
/*     */     
/* 524 */     for (int c = 0; c < getRGBChannelCount(); c++) {
/* 525 */       int plane = c * width * height * bpp;
/* 526 */       for (int row = 0; row < height; row++) {
/* 527 */         int srcRow = row * width * getRGBChannelCount() * bpp;
/* 528 */         int destRow = row * width * bpp;
/*     */         
/* 530 */         for (int col = 0; col < width; col++) {
/* 531 */           int srcCol = col * getRGBChannelCount() * bpp;
/* 532 */           int destCol = col * bpp;
/*     */           
/* 534 */           for (int b = 0; b < bpp; b++) {
/* 535 */             deinterleave[plane + destRow + destCol + b] = image[srcRow + srcCol + c * bpp + b];
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 542 */     return deinterleave;
/*     */   }
/*     */ 
/*     */   
/*     */   private void unfilter(byte[] filters, byte[] image, int width, int height) {
/* 547 */     int bpp = getRGBChannelCount() * FormatTools.getBytesPerPixel(getPixelType());
/*     */     
/* 549 */     int rowLen = width * bpp;
/* 550 */     for (int row = 0; row < height; row++) {
/* 551 */       int filter = filters[row];
/*     */       
/* 553 */       if (filter != 0)
/*     */       {
/*     */ 
/*     */         
/* 557 */         for (int col = 0; col < rowLen; col++) {
/* 558 */           int p, pa, pb, pc, q = row * rowLen + col;
/*     */           
/* 560 */           int xx = image[q] & 0xFF;
/* 561 */           int a = (col >= bpp) ? (image[q - bpp] & 0xFF) : 0;
/* 562 */           int b = (row > 0) ? (image[q - bpp * width] & 0xFF) : 0;
/* 563 */           int c = (row > 0 && col >= bpp) ? (image[q - bpp * (width + 1)] & 0xFF) : 0;
/*     */ 
/*     */           
/* 566 */           switch (filter) {
/*     */             case 1:
/* 568 */               image[q] = (byte)(xx + a & 0xFF);
/*     */               break;
/*     */             case 2:
/* 571 */               image[q] = (byte)(xx + b & 0xFF);
/*     */               break;
/*     */             case 3:
/* 574 */               image[q] = (byte)(xx + (int)Math.floor((a + b)) / 2 & 0xFF);
/*     */               break;
/*     */             case 4:
/* 577 */               p = a + b - c;
/* 578 */               pa = Math.abs(p - a);
/* 579 */               pb = Math.abs(p - b);
/* 580 */               pc = Math.abs(p - c);
/*     */               
/* 582 */               if (pa <= pb && pa <= pc) {
/* 583 */                 image[q] = (byte)(xx + a & 0xFF); break;
/*     */               } 
/* 585 */               if (pb <= pc) {
/* 586 */                 image[q] = (byte)(xx + b & 0xFF);
/*     */                 break;
/*     */               } 
/* 589 */               image[q] = (byte)(xx + c & 0xFF);
/*     */               break;
/*     */           } 
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   class PNGBlock {
/*     */     public long offset;
/*     */     public int length;
/*     */     public String type;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/in/APNGReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */