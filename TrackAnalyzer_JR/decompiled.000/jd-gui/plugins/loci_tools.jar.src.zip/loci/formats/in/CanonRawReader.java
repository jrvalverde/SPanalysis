/*     */ package loci.formats.in;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import loci.common.RandomAccessInputStream;
/*     */ import loci.formats.FormatException;
/*     */ import loci.formats.FormatReader;
/*     */ import loci.formats.FormatTools;
/*     */ import loci.formats.IFormatReader;
/*     */ import loci.formats.ImageTools;
/*     */ import loci.formats.MetadataTools;
/*     */ import loci.formats.codec.BitBuffer;
/*     */ import loci.formats.meta.MetadataStore;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CanonRawReader
/*     */   extends FormatReader
/*     */ {
/*     */   private static final int FILE_LENGTH = 18653760;
/*  52 */   private static final int[] COLOR_MAP = new int[] { 1, 0, 2, 1 };
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] plane;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CanonRawReader() {
/*  62 */     super("Canon RAW", new String[] { "cr2", "crw", "jpg", "thm", "wav" });
/*  63 */     this.domains = new String[] { "Graphics" };
/*  64 */     this.suffixNecessary = false;
/*  65 */     this.suffixSufficient = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isThisType(RandomAccessInputStream stream) throws IOException {
/*  72 */     return (stream.length() == 18653760L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] openBytes(int no, byte[] buf, int x, int y, int w, int h) throws FormatException, IOException {
/*  81 */     FormatTools.checkPlaneParameters((IFormatReader)this, no, buf.length, x, y, w, h);
/*     */     
/*  83 */     RandomAccessInputStream s = new RandomAccessInputStream(this.plane);
/*  84 */     readPlane(s, x, y, w, h, buf);
/*  85 */     s.close();
/*     */     
/*  87 */     return buf;
/*     */   }
/*     */ 
/*     */   
/*     */   public void close(boolean fileOnly) throws IOException {
/*  92 */     super.close(fileOnly);
/*  93 */     if (!fileOnly) {
/*  94 */       this.plane = null;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initFile(String id) throws FormatException, IOException {
/* 102 */     super.initFile(id);
/* 103 */     this.in = new RandomAccessInputStream(id);
/*     */     
/* 105 */     byte[] pixBuffer = new byte[18653760];
/* 106 */     this.in.read(pixBuffer);
/*     */ 
/*     */ 
/*     */     
/* 110 */     for (int i = 0; i < pixBuffer.length; i += 2) {
/* 111 */       byte v = pixBuffer[i];
/* 112 */       pixBuffer[i] = pixBuffer[i + 1];
/* 113 */       pixBuffer[i + 1] = v;
/*     */     } 
/*     */     
/* 116 */     (this.core[0]).sizeX = 4080;
/* 117 */     (this.core[0]).sizeY = 3048;
/* 118 */     (this.core[0]).sizeC = 3;
/* 119 */     (this.core[0]).sizeZ = 1;
/* 120 */     (this.core[0]).sizeT = 1;
/* 121 */     (this.core[0]).imageCount = getSizeZ() * getSizeT();
/* 122 */     (this.core[0]).indexed = false;
/* 123 */     (this.core[0]).littleEndian = true;
/* 124 */     (this.core[0]).dimensionOrder = "XYCZT";
/* 125 */     (this.core[0]).pixelType = 3;
/* 126 */     (this.core[0]).bitsPerPixel = 12;
/* 127 */     (this.core[0]).rgb = true;
/* 128 */     (this.core[0]).interleaved = true;
/*     */     
/* 130 */     BitBuffer bb = new BitBuffer(pixBuffer);
/* 131 */     this.plane = new byte[FormatTools.getPlaneSize((IFormatReader)this)];
/* 132 */     short[] pix = new short[getSizeX() * getSizeY() * 3];
/*     */     
/* 134 */     for (int row = 0; row < getSizeY(); row++) {
/* 135 */       for (int col = 0; col < getSizeX(); col++) {
/* 136 */         short val = (short)(bb.getBits(12) & 0xFFFF);
/* 137 */         int mapIndex = row % 2 * 2 + col % 2;
/*     */         
/* 139 */         int redOffset = row * getSizeX() + col;
/* 140 */         int greenOffset = (getSizeY() + row) * getSizeX() + col;
/* 141 */         int blueOffset = (2 * getSizeY() + row) * getSizeX() + col;
/*     */         
/* 143 */         switch (COLOR_MAP[mapIndex]) {
/*     */           case 0:
/* 145 */             pix[redOffset] = val;
/*     */             break;
/*     */           case 1:
/* 148 */             pix[greenOffset] = val;
/*     */             break;
/*     */           case 2:
/* 151 */             pix[blueOffset] = val;
/*     */             break;
/*     */         } 
/*     */       
/*     */       } 
/*     */     } 
/* 157 */     ImageTools.interpolate(pix, this.plane, COLOR_MAP, getSizeX(), getSizeY(), isLittleEndian());
/*     */ 
/*     */     
/* 160 */     MetadataStore store = makeFilterMetadata();
/* 161 */     MetadataTools.populatePixels(store, (IFormatReader)this);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/in/CanonRawReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */