/*      */ package loci.formats.in;
/*      */ 
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.util.Arrays;
/*      */ import java.util.Hashtable;
/*      */ import java.util.StringTokenizer;
/*      */ import java.util.Vector;
/*      */ import loci.common.Location;
/*      */ import loci.common.RandomAccessInputStream;
/*      */ import loci.common.xml.BaseHandler;
/*      */ import loci.common.xml.XMLTools;
/*      */ import loci.formats.CoreMetadata;
/*      */ import loci.formats.FilePattern;
/*      */ import loci.formats.FormatException;
/*      */ import loci.formats.FormatReader;
/*      */ import loci.formats.FormatTools;
/*      */ import loci.formats.IFormatReader;
/*      */ import loci.formats.MetadataTools;
/*      */ import loci.formats.meta.IMinMaxStore;
/*      */ import loci.formats.meta.MetadataStore;
/*      */ import ome.xml.model.primitives.PositiveFloat;
/*      */ import ome.xml.model.primitives.PositiveInteger;
/*      */ import ome.xml.model.primitives.Timestamp;
/*      */ import org.xml.sax.Attributes;
/*      */ import org.xml.sax.helpers.DefaultHandler;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class BioRadReader
/*      */   extends FormatReader
/*      */ {
/*      */   private static final int PIC_FILE_ID = 12345;
/*      */   private static final boolean LITTLE_ENDIAN = true;
/*   75 */   private static final String[] MERGE_NAMES = new String[] { "MERGE_OFF", "MERGE_16", "MERGE_ALTERNATE", "MERGE_COLUMN", "MERGE_ROW", "MERGE_MAXIMUM", "MERGE_OPT12", "MERGE_OPT12_V2" };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   81 */   public static final String[] NOTE_NAMES = new String[] { "0", "LIVE", "FILE1", "NUMBER", "USER", "LINE", "COLLECT", "FILE2", "SCALEBAR", "MERGE", "THRUVIEW", "ARROW", "12", "13", "14", "15", "16", "17", "18", "19", "VARIABLE", "STRUCTURE", "4D SERIES" };
/*      */   
/*      */   public static final int NOTE_TYPE_LIVE = 1;
/*      */   
/*      */   public static final int NOTE_TYPE_FILE1 = 2;
/*      */   
/*      */   public static final int NOTE_TYPE_NUMBER = 3;
/*      */   
/*      */   public static final int NOTE_TYPE_USER = 4;
/*      */   
/*      */   public static final int NOTE_TYPE_LINE = 5;
/*      */   
/*      */   public static final int NOTE_TYPE_COLLECT = 6;
/*      */   
/*      */   public static final int NOTE_TYPE_FILE2 = 7;
/*      */   public static final int NOTE_TYPE_SCALEBAR = 8;
/*      */   public static final int NOTE_TYPE_MERGE = 9;
/*      */   public static final int NOTE_TYPE_THRUVIEW = 10;
/*      */   public static final int NOTE_TYPE_ARROW = 11;
/*      */   public static final int NOTE_TYPE_VARIABLE = 20;
/*      */   public static final int NOTE_TYPE_STRUCTURE = 21;
/*      */   public static final int NOTE_TYPE_4D_SERIES = 22;
/*  103 */   public static final String[] STRUCTURE_LABELS_1 = new String[] { "Scan Channel", "Both mode", "Speed", "Filter", "Factor", "Number of scans", "Photon counting mode (channel 1)", "Photon counting detector (channel 1)", "Photon counting mode (channel 2)", "Photon counting detector (channel 2)", "Photon mode", "Objective magnification", "Zoom factor", "Motor on", "Z Step Size" };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  111 */   public static final String[] STRUCTURE_LABELS_2 = new String[] { "Z Start", "Z Stop", "Scan area X coordinate", "Scan area Y coordinate", "Scan area width", "Scan area height" };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  116 */   public static final String[] STRUCTURE_LABELS_3 = new String[] { "Iris for PMT", "Gain for PMT", "Black level for PMT", "Emission filter for PMT", "Multiplier for channel" };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  121 */   public static final String[] STRUCTURE_LABELS_4 = new String[] { "enhanced", "PMT 1 percentage", "PMT 2 percentage", "Transmission 1 percentage", "Transmission 2 percentage", "Transmission 3 percentage" };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  127 */   public static final String[] STRUCTURE_LABELS_5 = new String[] { "laser ", "excitation filter for laser ", "ND filter for laser ", "emission filter for laser " };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  132 */   public static final String[] STRUCTURE_LABELS_6 = new String[] { "Part number for laser 3", "Part number for excitation filter for laser 3", "Part number for ND filter for laser 3", "Part number for emission filter for laser 3", "Part number for filter block 1", "Part number for filter block 2" };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  139 */   public static final String[] PIC_SUFFIX = new String[] { "pic" };
/*      */ 
/*      */   
/*      */   public static final int LUT_LENGTH = 256;
/*      */   
/*      */   private Vector<String> used;
/*      */   
/*      */   private String[] picFiles;
/*      */   
/*      */   private byte[][][] lut;
/*      */   
/*  150 */   private int lastChannel = 0;
/*      */   
/*      */   private boolean brokenNotes = false;
/*      */   
/*      */   private Vector<Note> noteStrings;
/*      */   
/*      */   private Vector<Double> offset;
/*      */   
/*      */   private Vector<Double> gain;
/*      */   
/*      */   public BioRadReader() {
/*  161 */     super("Bio-Rad PIC", new String[] { "pic", "xml", "raw" });
/*  162 */     this.domains = new String[] { "Light Microscopy" };
/*  163 */     this.hasCompanionFiles = true;
/*  164 */     this.datasetDescription = "One or more .pic files and an optional lse.xml file";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getOptimalTileHeight() {
/*  171 */     FormatTools.assertId(this.currentId, true, 1);
/*  172 */     return getSizeY();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isSingleFile(String id) throws FormatException, IOException {
/*  177 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isThisType(String name, boolean open) {
/*  182 */     if (checkSuffix(name, PIC_SUFFIX)) return true; 
/*  183 */     String fname = (new File(name.toLowerCase())).getName();
/*  184 */     return (fname.equals("lse.xml") || fname.equals("data.raw"));
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isThisType(RandomAccessInputStream stream) throws IOException {
/*  189 */     int blockLen = 56;
/*  190 */     if (!FormatTools.validStream(stream, 56, true)) {
/*  191 */       return false;
/*      */     }
/*  193 */     String c = stream.readString(56);
/*  194 */     stream.seek(54L);
/*  195 */     return (stream.readShort() == 12345 || c.startsWith("[Input Sources]"));
/*      */   }
/*      */ 
/*      */   
/*      */   public int fileGroupOption(String id) throws FormatException, IOException {
/*  200 */     Location thisFile = (new Location(id)).getAbsoluteFile();
/*  201 */     Location parent = thisFile.getParentFile();
/*  202 */     String[] list = parent.list(true);
/*  203 */     for (String f : list) {
/*  204 */       if (checkSuffix(f, "raw") || checkSuffix(f, "xml")) {
/*  205 */         return 0;
/*      */       }
/*      */     } 
/*  208 */     return 1;
/*      */   }
/*      */ 
/*      */   
/*      */   public byte[][] get8BitLookupTable() {
/*  213 */     FormatTools.assertId(this.currentId, true, 1);
/*  214 */     return (this.lut == null) ? (byte[][])null : this.lut[this.lastChannel];
/*      */   }
/*      */ 
/*      */   
/*      */   public String[] getSeriesUsedFiles(boolean noPixels) {
/*  219 */     FormatTools.assertId(this.currentId, true, 1);
/*  220 */     if (noPixels) {
/*  221 */       Vector<String> files = new Vector<String>();
/*  222 */       for (String f : this.used) {
/*  223 */         if (!checkSuffix(f, PIC_SUFFIX)) files.add(f); 
/*      */       } 
/*  225 */       return files.<String>toArray(new String[files.size()]);
/*      */     } 
/*  227 */     return this.used.<String>toArray(new String[this.used.size()]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] openBytes(int no, byte[] buf, int x, int y, int w, int h) throws FormatException, IOException {
/*  236 */     FormatTools.checkPlaneParameters((IFormatReader)this, no, buf.length, x, y, w, h);
/*      */     
/*  238 */     this.lastChannel = getZCTCoords(no)[1];
/*      */     
/*  240 */     if (this.picFiles != null) {
/*  241 */       int file = no % this.picFiles.length;
/*  242 */       RandomAccessInputStream ras = new RandomAccessInputStream(this.picFiles[file]);
/*  243 */       long offset = (no / this.picFiles.length * FormatTools.getPlaneSize((IFormatReader)this));
/*  244 */       ras.seek(offset + 76L);
/*      */       
/*  246 */       readPlane(ras, x, y, w, h, buf);
/*  247 */       ras.close();
/*      */     } else {
/*      */       
/*  250 */       this.in.seek((no * FormatTools.getPlaneSize((IFormatReader)this) + 76));
/*  251 */       readPlane(this.in, x, y, w, h, buf);
/*      */     } 
/*  253 */     return buf;
/*      */   }
/*      */ 
/*      */   
/*      */   public void close(boolean fileOnly) throws IOException {
/*  258 */     super.close(fileOnly);
/*  259 */     if (!fileOnly) {
/*  260 */       this.used = null;
/*  261 */       this.picFiles = null;
/*  262 */       this.lut = (byte[][][])null;
/*  263 */       this.lastChannel = 0;
/*  264 */       this.noteStrings = null;
/*  265 */       this.offset = this.gain = null;
/*  266 */       this.brokenNotes = false;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initFile(String id) throws FormatException, IOException {
/*  275 */     if (!checkSuffix(id, PIC_SUFFIX)) {
/*  276 */       Location dir = (new Location(id)).getAbsoluteFile().getParentFile();
/*      */       
/*  278 */       String[] list = dir.list(true);
/*  279 */       for (int j = 0; j < list.length; j++) {
/*  280 */         if (checkSuffix(list[j], PIC_SUFFIX)) {
/*  281 */           id = (new Location(dir.getAbsolutePath(), list[j])).getAbsolutePath();
/*      */         }
/*      */       } 
/*  284 */       if (!checkSuffix(id, PIC_SUFFIX)) {
/*  285 */         throw new FormatException("No .pic files found - invalid dataset.");
/*      */       }
/*      */     } 
/*      */     
/*  289 */     super.initFile(id);
/*  290 */     this.in = new RandomAccessInputStream(id);
/*  291 */     this.in.order(true);
/*      */     
/*  293 */     this.offset = new Vector<Double>();
/*  294 */     this.gain = new Vector<Double>();
/*      */     
/*  296 */     this.used = new Vector<String>();
/*  297 */     this.used.add(this.currentId);
/*      */     
/*  299 */     LOGGER.info("Reading image dimensions");
/*      */     
/*  301 */     this.noteStrings = new Vector<Note>();
/*      */ 
/*      */ 
/*      */     
/*  305 */     (this.core[0]).sizeX = this.in.readShort();
/*  306 */     (this.core[0]).sizeY = this.in.readShort();
/*  307 */     int npic = this.in.readShort();
/*  308 */     (this.core[0]).imageCount = npic;
/*      */     
/*  310 */     int ramp1min = this.in.readShort();
/*  311 */     int ramp1max = this.in.readShort();
/*  312 */     boolean notes = (this.in.readInt() != 0);
/*  313 */     (this.core[0]).pixelType = (this.in.readShort() == 0) ? 3 : 1;
/*      */     
/*  315 */     int imageNumber = this.in.readShort();
/*  316 */     String name = this.in.readString(32);
/*  317 */     for (int i = 0; i < name.length(); i++) {
/*  318 */       if (name.charAt(i) == '\000') {
/*  319 */         name = name.substring(0, i);
/*      */         
/*      */         break;
/*      */       } 
/*      */     } 
/*  324 */     float magFactor = 1.0F;
/*  325 */     int lens = 0;
/*      */     
/*  327 */     if (getMetadataOptions().getMetadataLevel() != MetadataLevel.MINIMUM) {
/*  328 */       int merged = this.in.readShort();
/*  329 */       int color1 = this.in.readShort();
/*  330 */       int fileId = this.in.readShort();
/*  331 */       int ramp2min = this.in.readShort();
/*  332 */       int ramp2max = this.in.readShort();
/*  333 */       int color2 = this.in.readShort();
/*  334 */       int edited = this.in.readShort();
/*  335 */       lens = this.in.readShort();
/*  336 */       magFactor = this.in.readFloat();
/*      */ 
/*      */       
/*  339 */       if (fileId != 12345) {
/*  340 */         throw new FormatException("Invalid file header : " + fileId);
/*      */       }
/*      */ 
/*      */       
/*  344 */       addGlobalMeta("nx", getSizeX());
/*  345 */       addGlobalMeta("ny", getSizeY());
/*  346 */       addGlobalMeta("npic", getImageCount());
/*  347 */       addGlobalMeta("ramp1_min", ramp1min);
/*  348 */       addGlobalMeta("ramp1_max", ramp1max);
/*  349 */       addGlobalMeta("notes", notes);
/*  350 */       addGlobalMeta("image_number", imageNumber);
/*  351 */       addGlobalMeta("name", name);
/*  352 */       addGlobalMeta("merged", MERGE_NAMES[merged]);
/*  353 */       addGlobalMeta("color1", color1);
/*  354 */       addGlobalMeta("file_id", fileId);
/*  355 */       addGlobalMeta("ramp2_min", ramp2min);
/*  356 */       addGlobalMeta("ramp2_max", ramp2max);
/*  357 */       addGlobalMeta("color2", color2);
/*  358 */       addGlobalMeta("edited", edited);
/*  359 */       addGlobalMeta("lens", lens);
/*  360 */       addGlobalMeta("mag_factor", magFactor);
/*      */     } else {
/*  362 */       this.in.skipBytes(20);
/*      */     } 
/*      */     
/*  365 */     int imageLen = getSizeX() * getSizeY();
/*  366 */     int bpp = FormatTools.getBytesPerPixel(getPixelType());
/*  367 */     this.in.skipBytes(bpp * getImageCount() * imageLen + 6);
/*      */     
/*  369 */     (this.core[0]).sizeZ = getImageCount();
/*  370 */     (this.core[0]).sizeC = 1;
/*  371 */     (this.core[0]).sizeT = 1;
/*      */     
/*  373 */     (this.core[0]).orderCertain = false;
/*  374 */     (this.core[0]).rgb = false;
/*  375 */     (this.core[0]).interleaved = false;
/*  376 */     (this.core[0]).littleEndian = true;
/*  377 */     (this.core[0]).metadataComplete = true;
/*  378 */     (this.core[0]).falseColor = true;
/*      */     
/*  380 */     LOGGER.info("Reading notes");
/*      */     
/*  382 */     String zoom = null, zstart = null, zstop = null, mag = null;
/*  383 */     String gain1 = null, gain2 = null, gain3 = null;
/*  384 */     String offset1 = null;
/*  385 */     String ex1 = null, ex2 = null, ex3 = null;
/*  386 */     String em1 = null, em2 = null, em3 = null;
/*      */     
/*  388 */     MetadataStore store = makeFilterMetadata();
/*      */ 
/*      */ 
/*      */     
/*  392 */     readNotes(this.in, true);
/*      */     
/*  394 */     LOGGER.info("Populating metadata");
/*      */ 
/*      */ 
/*      */     
/*  398 */     Vector<String> pics = new Vector<String>();
/*      */     
/*  400 */     if (isGroupFiles()) {
/*  401 */       Location parent = (new Location(this.currentId)).getAbsoluteFile().getParentFile();
/*      */       
/*  403 */       String parentPath = parent.getAbsolutePath();
/*  404 */       String[] list = parent.list(true);
/*  405 */       Arrays.sort((Object[])list);
/*      */       
/*  407 */       for (int j = 0; j < list.length; j++) {
/*  408 */         if (list[j].endsWith("lse.xml")) {
/*  409 */           String path = (new Location(parentPath, list[j])).getAbsolutePath();
/*  410 */           this.used.add(path);
/*      */           
/*  412 */           BioRadHandler bioRadHandler = new BioRadHandler();
/*  413 */           RandomAccessInputStream xml = new RandomAccessInputStream(path);
/*  414 */           XMLTools.parseXML(xml, (DefaultHandler)bioRadHandler);
/*  415 */           xml.close();
/*      */           
/*  417 */           this.used.remove(this.currentId);
/*  418 */           for (int q = 0; q < list.length; q++) {
/*  419 */             if (checkSuffix(list[q], PIC_SUFFIX)) {
/*  420 */               path = (new Location(parentPath, list[q])).getAbsolutePath();
/*  421 */               pics.add(path);
/*  422 */               if (!this.used.contains(path)) this.used.add(path);
/*      */             
/*      */             } 
/*      */           } 
/*  426 */         } else if (list[j].endsWith("data.raw")) {
/*  427 */           this.used.add((new Location(parentPath, list[j])).getAbsolutePath());
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  434 */     (this.core[0]).dimensionOrder = "XYCTZ";
/*      */     
/*  436 */     boolean multipleFiles = parseNotes(store);
/*      */     
/*  438 */     if (multipleFiles && isGroupFiles() && pics.size() == 0) {
/*      */       
/*  440 */       this.used.remove(this.currentId);
/*  441 */       long length = (new Location(this.currentId)).length();
/*  442 */       FilePattern pattern = new FilePattern((new Location(id)).getAbsoluteFile());
/*  443 */       String[] patternFiles = pattern.getFiles();
/*  444 */       for (String file : patternFiles) {
/*  445 */         Location f = new Location(file);
/*  446 */         if (f.length() == length) {
/*  447 */           pics.add(file);
/*  448 */           this.used.add(file);
/*      */         } 
/*      */       } 
/*  451 */       if (pics.size() == 1) (this.core[0]).sizeC = 1;
/*      */     
/*      */     } 
/*  454 */     this.picFiles = pics.<String>toArray(new String[pics.size()]);
/*  455 */     Arrays.sort((Object[])this.picFiles);
/*  456 */     if (this.picFiles.length > 0)
/*  457 */     { if (getSizeC() == 0) (this.core[0]).sizeC = 1; 
/*  458 */       (this.core[0]).imageCount = npic * this.picFiles.length;
/*  459 */       if (multipleFiles) {
/*  460 */         (this.core[0]).sizeT = getImageCount() / getSizeZ() * getSizeC();
/*      */       } else {
/*  462 */         (this.core[0]).sizeC = getImageCount() / getSizeZ() * getSizeT();
/*      */       }  }
/*  464 */     else { this.picFiles = null; }
/*      */     
/*  466 */     if (getEffectiveSizeC() != getSizeC() && !isRGB()) {
/*  467 */       (this.core[0]).sizeC = 1;
/*      */     }
/*      */     
/*  470 */     LOGGER.info("Reading lookup tables");
/*      */     
/*  472 */     this.lut = new byte[getEffectiveSizeC()][][];
/*  473 */     for (int channel = 0; channel < this.lut.length; channel++) {
/*  474 */       int plane = getIndex(0, channel, 0);
/*  475 */       String file = (this.picFiles == null) ? this.currentId : this.picFiles[plane % this.picFiles.length];
/*      */       
/*  477 */       LOGGER.trace("reading table for C = {} from {}", Integer.valueOf(channel), file);
/*  478 */       RandomAccessInputStream s = new RandomAccessInputStream(file);
/*  479 */       s.order(true);
/*  480 */       readLookupTables(s);
/*  481 */       s.close();
/*  482 */       if (this.lut == null)
/*      */         break; 
/*  484 */     }  (this.core[0]).indexed = (this.lut != null);
/*      */     
/*  486 */     MetadataTools.populatePixels(store, (IFormatReader)this);
/*  487 */     store.setImageName(name, 0);
/*      */     
/*  489 */     if (getMetadataOptions().getMetadataLevel() != MetadataLevel.MINIMUM) {
/*      */       
/*  491 */       String instrumentID = MetadataTools.createLSID("Instrument", new int[] { 0 });
/*  492 */       store.setInstrumentID(instrumentID, 0);
/*  493 */       store.setImageInstrumentRef(instrumentID, 0);
/*      */ 
/*      */       
/*  496 */       String objectiveID = MetadataTools.createLSID("Objective", new int[] { 0, 0 });
/*  497 */       store.setObjectiveID(objectiveID, 0, 0);
/*  498 */       store.setObjectiveSettingsID(objectiveID, 0);
/*      */       
/*  500 */       store.setObjectiveLensNA(new Double(lens), 0, 0);
/*  501 */       if ((int)magFactor > 0) {
/*  502 */         store.setObjectiveNominalMagnification(new PositiveInteger(Integer.valueOf((int)magFactor)), 0, 0);
/*      */       }
/*      */       else {
/*      */         
/*  506 */         LOGGER.warn("Expected positive value for NominalMagnification; got {}", Float.valueOf(magFactor));
/*      */       } 
/*      */       
/*  509 */       store.setObjectiveCorrection(getCorrection("Other"), 0, 0);
/*  510 */       store.setObjectiveImmersion(getImmersion("Other"), 0, 0);
/*      */ 
/*      */       
/*  513 */       for (int j = 0; j < getEffectiveSizeC(); j++) {
/*  514 */         Double detectorOffset = (j < this.offset.size()) ? this.offset.get(j) : null;
/*  515 */         Double detectorGain = (j < this.gain.size()) ? this.gain.get(j) : null;
/*      */         
/*  517 */         if (detectorOffset != null || detectorGain != null) {
/*  518 */           String detectorID = MetadataTools.createLSID("Detector", new int[] { 0, j });
/*  519 */           store.setDetectorSettingsID(detectorID, 0, j);
/*  520 */           store.setDetectorID(detectorID, 0, j);
/*  521 */           store.setDetectorType(getDetectorType("Other"), 0, j);
/*      */         } 
/*  523 */         if (detectorOffset != null) {
/*  524 */           store.setDetectorSettingsOffset(detectorOffset, 0, j);
/*      */         }
/*  526 */         if (detectorGain != null) {
/*  527 */           store.setDetectorSettingsGain(detectorGain, 0, j);
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void readNotes(RandomAccessInputStream s, boolean add) throws IOException {
/*  542 */     s.seek(70L);
/*  543 */     int imageLen = getSizeX() * getSizeY();
/*  544 */     if (this.picFiles == null) { imageLen *= getImageCount(); }
/*      */     else
/*  546 */     { imageLen *= getImageCount() / this.picFiles.length; }
/*      */     
/*  548 */     int bpp = FormatTools.getBytesPerPixel(getPixelType());
/*  549 */     s.skipBytes(bpp * imageLen + 6);
/*      */     
/*  551 */     boolean notes = true;
/*  552 */     while (notes) {
/*      */ 
/*      */       
/*  555 */       if (s.getFilePointer() >= s.length()) {
/*  556 */         this.brokenNotes = true;
/*      */         
/*      */         break;
/*      */       } 
/*  560 */       Note n = new Note();
/*  561 */       n.level = s.readShort();
/*  562 */       notes = (s.readInt() != 0);
/*  563 */       n.num = s.readShort();
/*  564 */       n.status = s.readShort();
/*  565 */       n.type = s.readShort();
/*  566 */       n.x = s.readShort();
/*  567 */       n.y = s.readShort();
/*  568 */       n.p = s.readString(80);
/*      */       
/*  570 */       if (n.type < 0 || n.type >= NOTE_NAMES.length) {
/*  571 */         notes = false;
/*  572 */         this.brokenNotes = true;
/*      */         
/*      */         break;
/*      */       } 
/*  576 */       if (!add) {
/*      */         continue;
/*      */       }
/*  579 */       int ndx = n.p.length();
/*  580 */       for (int i = 0; i < n.p.length(); i++) {
/*  581 */         if (n.p.charAt(i) == '\000') {
/*  582 */           ndx = i;
/*      */           
/*      */           break;
/*      */         } 
/*      */       } 
/*  587 */       n.p = n.p.substring(0, ndx).trim();
/*      */       
/*  589 */       String value = n.p.replaceAll("=", "");
/*  590 */       Vector<String> v = new Vector<String>();
/*  591 */       StringTokenizer t = new StringTokenizer(value, " ");
/*  592 */       while (t.hasMoreTokens()) {
/*  593 */         String token = t.nextToken().trim();
/*  594 */         if (token.length() > 0) v.add(token); 
/*      */       } 
/*  596 */       String[] tokens = v.<String>toArray(new String[v.size()]);
/*      */       try {
/*  598 */         if (tokens.length > 1) {
/*  599 */           int noteType = Integer.parseInt(tokens[1]);
/*      */           
/*  601 */           if (noteType == 2 && value.indexOf("AXIS_4") != -1) {
/*  602 */             (this.core[0]).sizeZ = 1;
/*  603 */             (this.core[0]).sizeT = getImageCount();
/*  604 */             (this.core[0]).orderCertain = true;
/*      */           }
/*      */         
/*      */         } 
/*  608 */       } catch (NumberFormatException e) {}
/*      */ 
/*      */       
/*  611 */       this.noteStrings.add(n);
/*      */     } 
/*      */   }
/*      */   
/*      */   private boolean parseNotes(MetadataStore store) throws FormatException {
/*  616 */     boolean multipleFiles = false;
/*  617 */     int nextDetector = 0, nLasers = 0;
/*  618 */     for (int noteIndex = 0; noteIndex < this.noteStrings.size(); noteIndex++) {
/*  619 */       Note n = this.noteStrings.get(noteIndex);
/*  620 */       if (getMetadataOptions().getMetadataLevel() != MetadataLevel.MINIMUM) {
/*  621 */         int structureType; int version; String[] values; switch (n.type) {
/*      */           
/*      */           case 4:
/*  624 */             addGlobalMeta("Note #" + noteIndex, n.toString());
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 8:
/*  632 */             addGlobalMeta("Note #" + noteIndex, n.toString());
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 11:
/*  641 */             addGlobalMeta("Note #" + noteIndex, n.toString());
/*      */             break;
/*      */           case 20:
/*  644 */             if (n.p.indexOf("=") >= 0) {
/*  645 */               String key = n.p.substring(0, n.p.indexOf("=")).trim();
/*  646 */               String value = n.p.substring(n.p.indexOf("=") + 1).trim();
/*  647 */               addGlobalMeta(key, value);
/*      */               
/*  649 */               if (key.equals("INFO_OBJECTIVE_NAME")) {
/*  650 */                 store.setObjectiveModel(value, 0, 0); break;
/*      */               } 
/*  652 */               if (key.equals("INFO_OBJECTIVE_MAGNIFICATION")) {
/*  653 */                 int mag = (int)Float.parseFloat(value);
/*  654 */                 if (mag > 0) {
/*  655 */                   store.setObjectiveNominalMagnification(new PositiveInteger(Integer.valueOf(mag)), 0, 0);
/*      */                   
/*      */                   break;
/*      */                 } 
/*  659 */                 LOGGER.warn("Expected positive value for NominalMagnification; got {}", Integer.valueOf(mag));
/*      */                 
/*      */                 break;
/*      */               } 
/*      */               
/*  664 */               if (key.equals("LENS_MAGNIFICATION")) {
/*  665 */                 int magnification = (int)Float.parseFloat(value);
/*  666 */                 if (magnification > 0) {
/*  667 */                   store.setObjectiveNominalMagnification(new PositiveInteger(Integer.valueOf(magnification)), 0, 0);
/*      */                   
/*      */                   break;
/*      */                 } 
/*  671 */                 LOGGER.warn("Expected positive value for NominalMagnification; got {}", Integer.valueOf(magnification));
/*      */                 
/*      */                 break;
/*      */               } 
/*      */               
/*  676 */               if (key.startsWith("SETTING")) {
/*  677 */                 if (key.indexOf("_DET_") != -1) {
/*  678 */                   int index = key.indexOf("_DET_") + 5;
/*  679 */                   if (key.lastIndexOf("_") > index) {
/*  680 */                     String detectorID = MetadataTools.createLSID("Detector", new int[] { 0, nextDetector });
/*      */                     
/*  682 */                     store.setDetectorID(detectorID, 0, nextDetector);
/*  683 */                     store.setDetectorType(getDetectorType("Other"), 0, nextDetector);
/*      */ 
/*      */                     
/*  686 */                     if (key.endsWith("OFFSET")) {
/*  687 */                       if (nextDetector < this.offset.size()) {
/*  688 */                         this.offset.setElementAt(new Double(value), nextDetector);
/*      */                       } else {
/*      */                         
/*  691 */                         while (nextDetector > this.offset.size()) {
/*  692 */                           this.offset.add(null);
/*      */                         }
/*  694 */                         this.offset.add(new Double(value));
/*      */                       }
/*      */                     
/*  697 */                     } else if (key.endsWith("GAIN")) {
/*  698 */                       if (nextDetector < this.gain.size()) {
/*  699 */                         this.gain.setElementAt(new Double(value), nextDetector);
/*      */                       } else {
/*      */                         
/*  702 */                         while (nextDetector > this.gain.size()) {
/*  703 */                           this.gain.add(null);
/*      */                         }
/*  705 */                         this.gain.add(new Double(value));
/*      */                       } 
/*      */                     } 
/*  708 */                     nextDetector++;
/*      */                   } 
/*      */                 } 
/*      */                 break;
/*      */               } 
/*  713 */               String[] arrayOfString = value.split(" ");
/*  714 */               if (arrayOfString.length > 1) {
/*      */                 try {
/*  716 */                   int type = Integer.parseInt(arrayOfString[0]);
/*  717 */                   if (type == 257 && arrayOfString.length >= 3) {
/*      */                     
/*  719 */                     Double pixelSize = new Double(arrayOfString[2]);
/*  720 */                     if (key.equals("AXIS_2")) {
/*  721 */                       PositiveFloat size = FormatTools.getPhysicalSizeX(pixelSize);
/*      */                       
/*  723 */                       if (size != null)
/*  724 */                         store.setPixelsPhysicalSizeX(size, 0); 
/*      */                       break;
/*      */                     } 
/*  727 */                     if (key.equals("AXIS_3")) {
/*  728 */                       PositiveFloat size = FormatTools.getPhysicalSizeY(pixelSize);
/*      */ 
/*      */                       
/*  731 */                       if (size != null) {
/*  732 */                         store.setPixelsPhysicalSizeY(size, 0);
/*      */                       }
/*      */                     }
/*      */                   
/*      */                   } 
/*  737 */                 } catch (NumberFormatException e) {}
/*      */               }
/*      */               break;
/*      */             } 
/*  741 */             if (n.p.startsWith("AXIS_2")) {
/*  742 */               String[] arrayOfString = n.p.split(" ");
/*  743 */               Double pixelSize = new Double(arrayOfString[3]);
/*  744 */               PositiveFloat size = FormatTools.getPhysicalSizeX(pixelSize);
/*  745 */               if (size != null)
/*  746 */                 store.setPixelsPhysicalSizeX(size, 0); 
/*      */               break;
/*      */             } 
/*  749 */             if (n.p.startsWith("AXIS_3")) {
/*  750 */               String[] arrayOfString = n.p.split(" ");
/*  751 */               Double pixelSize = new Double(arrayOfString[3]);
/*  752 */               PositiveFloat size = FormatTools.getPhysicalSizeY(pixelSize);
/*  753 */               if (size != null) {
/*  754 */                 store.setPixelsPhysicalSizeY(size, 0);
/*      */               }
/*      */               break;
/*      */             } 
/*  758 */             addGlobalMeta("Note #" + noteIndex, n.toString());
/*      */             break;
/*      */           
/*      */           case 21:
/*  762 */             structureType = (n.x & 0xFF00) >> 8;
/*  763 */             version = n.x & 0xFF;
/*  764 */             values = n.p.split(" ");
/*  765 */             if (structureType == 1) {
/*  766 */               int i; int mag; Double sizeZ; PositiveFloat size; int j; double x1; double x2; double width; double y1; double y2; double height; PositiveFloat sizeX; PositiveFloat sizeY; int k; String prefix; int m; int year; int i1; String date; int i2; String experimentID; int i3; switch (n.y) {
/*      */                 case 1:
/*  768 */                   for (i = 0; i < STRUCTURE_LABELS_1.length; i++) {
/*  769 */                     addGlobalMeta(STRUCTURE_LABELS_1[i], values[i]);
/*      */                   }
/*      */                   
/*  772 */                   mag = (int)Float.parseFloat(values[11]);
/*  773 */                   if (mag > 0) {
/*  774 */                     store.setObjectiveNominalMagnification(new PositiveInteger(Integer.valueOf(mag)), 0, 0);
/*      */                   }
/*      */                   else {
/*      */                     
/*  778 */                     LOGGER.warn("Expected positive value for NominalMagnification; got {}", Integer.valueOf(mag));
/*      */                   } 
/*      */ 
/*      */                   
/*  782 */                   sizeZ = new Double(values[14]);
/*  783 */                   size = FormatTools.getPhysicalSizeZ(sizeZ);
/*  784 */                   if (size != null) {
/*  785 */                     store.setPixelsPhysicalSizeZ(size, 0);
/*      */                   }
/*      */                   break;
/*      */                 case 2:
/*  789 */                   for (j = 0; j < STRUCTURE_LABELS_2.length; j++) {
/*  790 */                     addGlobalMeta(STRUCTURE_LABELS_2[j], values[j]);
/*      */                   }
/*      */                   
/*  793 */                   x1 = Double.parseDouble(values[2]);
/*  794 */                   x2 = Double.parseDouble(values[4]);
/*  795 */                   width = x2 - x1;
/*  796 */                   width /= getSizeX();
/*      */                   
/*  798 */                   y1 = Double.parseDouble(values[3]);
/*  799 */                   y2 = Double.parseDouble(values[5]);
/*  800 */                   height = y2 - y1;
/*  801 */                   height /= getSizeY();
/*      */                   
/*  803 */                   sizeX = FormatTools.getPhysicalSizeX(Double.valueOf(width));
/*  804 */                   sizeY = FormatTools.getPhysicalSizeY(Double.valueOf(height));
/*  805 */                   if (sizeX != null) {
/*  806 */                     store.setPixelsPhysicalSizeX(sizeX, 0);
/*      */                   }
/*  808 */                   if (sizeY != null) {
/*  809 */                     store.setPixelsPhysicalSizeY(sizeY, 0);
/*      */                   }
/*      */                   break;
/*      */                 
/*      */                 case 3:
/*  814 */                   for (k = 0; k < 3; k++) {
/*  815 */                     for (int i4 = 0; i4 < STRUCTURE_LABELS_3.length; i4++) {
/*  816 */                       String v = (i4 == STRUCTURE_LABELS_3.length - 1) ? values[12 + k] : values[k * 4 + i4];
/*      */                       
/*  818 */                       addGlobalMeta(STRUCTURE_LABELS_3[i4] + " " + (k + 1), v);
/*      */                     } 
/*      */                   } 
/*      */                   break;
/*      */                 case 4:
/*  823 */                   nLasers = Integer.parseInt(values[0]);
/*  824 */                   addGlobalMeta("Number of lasers", values[0]);
/*  825 */                   addGlobalMeta("Number of transmission detectors", values[1]);
/*  826 */                   addGlobalMeta("Number of PMTs", values[2]);
/*  827 */                   for (k = 1; k <= 3; k++) {
/*  828 */                     int idx = (k + 1) * 3;
/*  829 */                     addGlobalMeta("Shutter present for laser " + k, values[k + 2]);
/*      */                     
/*  831 */                     addGlobalMeta("Neutral density filter for laser " + k, values[idx]);
/*      */                     
/*  833 */                     addGlobalMeta("Excitation filter for laser " + k, values[idx + 1]);
/*      */                     
/*  835 */                     addGlobalMeta("Use laser " + k, values[idx + 2]);
/*      */                   } 
/*  837 */                   for (k = 0; k < nLasers; k++) {
/*  838 */                     addGlobalMeta("Neutral density filter name - laser " + (k + 1), values[15 + k]);
/*      */                   }
/*      */                   break;
/*      */                 
/*      */                 case 5:
/*  843 */                   prefix = "Excitation filter name - laser ";
/*  844 */                   for (m = 0; m < nLasers; m++) {
/*  845 */                     addGlobalMeta(prefix + (m + 1), values[m]);
/*      */                   }
/*      */                   break;
/*      */                 case 6:
/*  849 */                   prefix = "Emission filter name - laser ";
/*  850 */                   for (m = 0; m < nLasers; m++) {
/*  851 */                     addGlobalMeta(prefix + (m + 1), values[m]);
/*      */                   }
/*      */                   break;
/*      */                 case 7:
/*  855 */                   for (m = 0; m < 2; m++) {
/*  856 */                     prefix = "Mixer " + m + " - ";
/*  857 */                     for (int i4 = 0; i4 < STRUCTURE_LABELS_4.length; i4++) {
/*  858 */                       addGlobalMeta(prefix + STRUCTURE_LABELS_4[i4], values[m * 7 + i4]);
/*      */                     }
/*      */                   } 
/*      */                   
/*  862 */                   addGlobalMeta("Mixer 0 - low signal on", values[14]);
/*  863 */                   addGlobalMeta("Mixer 1 - low signal on", values[15]);
/*      */                   break;
/*      */                 case 8:
/*      */                 case 9:
/*      */                 case 10:
/*  868 */                   addGlobalMeta("Laser name - laser " + (n.y - 7), values[0]);
/*      */                   break;
/*      */                 case 11:
/*  871 */                   for (m = 0; m < 3; m++) {
/*  872 */                     prefix = "Transmission detector " + (m + 1) + " - ";
/*  873 */                     addGlobalMeta(prefix + "offset", values[m * 3]);
/*  874 */                     addGlobalMeta(prefix + "gain", values[m * 3 + 1]);
/*  875 */                     addGlobalMeta(prefix + "black level", values[m * 3 + 2]);
/*      */                     
/*  877 */                     String detectorID = MetadataTools.createLSID("Detector", new int[] { 0, m });
/*      */                     
/*  879 */                     store.setDetectorID(detectorID, 0, m);
/*  880 */                     store.setDetectorOffset(new Double(values[m * 3]), 0, m);
/*  881 */                     store.setDetectorGain(new Double(values[m * 3 + 1]), 0, m);
/*  882 */                     store.setDetectorType(getDetectorType("Other"), 0, m);
/*      */                   } 
/*      */                   break;
/*      */                 case 12:
/*  886 */                   for (m = 0; m < 2; m++) {
/*  887 */                     prefix = "Part number for ";
/*  888 */                     for (int i4 = 0; i4 < STRUCTURE_LABELS_5.length; i4++) {
/*  889 */                       addGlobalMeta(prefix + STRUCTURE_LABELS_5[i4] + (m + 1), values[m * 4 + i4]);
/*      */                     }
/*      */                   } 
/*      */                   break;
/*      */                 
/*      */                 case 13:
/*  895 */                   for (m = 0; m < STRUCTURE_LABELS_6.length; m++) {
/*  896 */                     addGlobalMeta(STRUCTURE_LABELS_6[m], values[m]);
/*      */                   }
/*      */                   break;
/*      */                 case 14:
/*  900 */                   prefix = "Filter Block Name - filter block ";
/*  901 */                   addGlobalMeta(prefix + "1", values[0]);
/*  902 */                   addGlobalMeta(prefix + "2", values[1]);
/*      */                   break;
/*      */                 case 15:
/*  905 */                   for (m = 0; m < 5; m++) {
/*  906 */                     addGlobalMeta("Image bands status - band " + (m + 1), values[m * 3]);
/*      */                     
/*  908 */                     addGlobalMeta("Image bands min - band " + (m + 1), values[m * 3 + 1]);
/*      */                     
/*  910 */                     addGlobalMeta("Image bands max - band " + (m + 1), values[m * 3 + 2]);
/*      */                     
/*  912 */                     if (store instanceof IMinMaxStore) {
/*  913 */                       ((IMinMaxStore)store).setChannelGlobalMinMax(m, Double.parseDouble(values[m * 3 + 1]), Double.parseDouble(values[m * 3 + 2]), 0);
/*      */                     }
/*      */                   } 
/*      */                   break;
/*      */ 
/*      */                 
/*      */                 case 17:
/*  920 */                   year = Integer.parseInt(values[5]) + 1900;
/*  921 */                   for (i1 = 0; i1 < 5; i1++) {
/*  922 */                     if (values[i1].length() == 1) values[i1] = "0" + values[i1];
/*      */                   
/*      */                   } 
/*      */                   
/*  926 */                   date = year + "-" + values[4] + "-" + values[3] + "T" + values[2] + ":" + values[1] + ":" + values[0];
/*      */                   
/*  928 */                   addGlobalMeta("Acquisition date", date);
/*      */                   try {
/*  930 */                     store.setImageAcquisitionDate(new Timestamp(date), 0);
/*      */                   }
/*  932 */                   catch (Exception e) {
/*  933 */                     LOGGER.debug("Failed to parse acquisition date", e);
/*      */                   } 
/*      */                   break;
/*      */                 case 18:
/*  937 */                   addGlobalMeta("Mixer 3 - enhanced", values[0]);
/*  938 */                   for (i2 = 1; i2 <= 3; i2++) {
/*  939 */                     addGlobalMeta("Mixer 3 - PMT " + i2 + " percentage", values[i2]);
/*      */                     
/*  941 */                     addGlobalMeta("Mixer 3 - Transmission " + i2 + " percentage", values[i2 + 3]);
/*      */                     
/*  943 */                     addGlobalMeta("Mixer 3 - photon counting " + i2, values[i2 + 7]);
/*      */                   } 
/*      */                   
/*  946 */                   addGlobalMeta("Mixer 3 - low signal on", values[7]);
/*  947 */                   addGlobalMeta("Mixer 3 - mode", values[11]);
/*      */                   break;
/*      */                 case 19:
/*  950 */                   for (i2 = 1; i2 <= 2; i2++) {
/*  951 */                     prefix = "Mixer " + i2 + " - ";
/*  952 */                     String photon = prefix + "photon counting ";
/*  953 */                     addGlobalMeta(photon + "1", values[i2 * 4 - 4]);
/*  954 */                     addGlobalMeta(photon + "2", values[i2 * 4 - 3]);
/*  955 */                     addGlobalMeta(photon + "3", values[i2 * 4 - 2]);
/*  956 */                     addGlobalMeta(prefix + "mode", values[i2 * 4 - 1]);
/*      */                   } 
/*      */                   break;
/*      */                 case 20:
/*  960 */                   addGlobalMeta("Display mode", values[0]);
/*  961 */                   addGlobalMeta("Course", values[1]);
/*  962 */                   addGlobalMeta("Time Course - experiment type", values[2]);
/*  963 */                   addGlobalMeta("Time Course - kd factor", values[3]);
/*  964 */                   experimentID = MetadataTools.createLSID("Experiment", new int[] { 0 });
/*      */                   
/*  966 */                   store.setExperimentID(experimentID, 0);
/*  967 */                   store.setExperimentType(getExperimentType(values[2]), 0);
/*      */                   break;
/*      */                 case 21:
/*  970 */                   addGlobalMeta("Time Course - ion name", values[0]);
/*      */                   break;
/*      */                 case 22:
/*  973 */                   addGlobalMeta("PIC file generated on Isoscan (lite)", values[0]);
/*      */                   
/*  975 */                   for (i3 = 1; i3 <= 3; i3++) {
/*  976 */                     addGlobalMeta("Photon counting used (PMT " + i3 + ")", values[i3]);
/*      */                     
/*  978 */                     addGlobalMeta("Hot spot filter used (PMT " + i3 + ")", values[i3 + 3]);
/*      */                     
/*  980 */                     addGlobalMeta("Tx Selector used (TX " + i3 + ")", values[i3 + 6]);
/*      */                   } 
/*      */                   break;
/*      */               } 
/*      */             
/*      */             } 
/*      */             break;
/*      */           
/*      */           default:
/*  989 */             addGlobalMeta("Note #" + noteIndex, n.toString());
/*      */             break;
/*      */         } 
/*      */ 
/*      */ 
/*      */       
/*      */       } 
/*  996 */       if (n.p.indexOf("AXIS") != -1) {
/*  997 */         n.p = n.p.replaceAll("=", "");
/*  998 */         Vector<String> v = new Vector<String>();
/*  999 */         StringTokenizer tokens = new StringTokenizer(n.p, " ");
/* 1000 */         while (tokens.hasMoreTokens()) {
/* 1001 */           String token = tokens.nextToken().trim();
/* 1002 */           if (token.length() > 0) v.add(token); 
/*      */         } 
/* 1004 */         String[] values = v.<String>toArray(new String[v.size()]);
/* 1005 */         String key = values[0];
/* 1006 */         String noteType = values[1];
/*      */         
/* 1008 */         int axisType = Integer.parseInt(noteType);
/*      */         
/* 1010 */         if (axisType == 11 && values.length > 2) {
/* 1011 */           addGlobalMeta(key + " RGB type (X)", values[2]);
/* 1012 */           addGlobalMeta(key + " RGB type (Y)", values[3]);
/*      */           
/* 1014 */           if (key.equals("AXIS_4")) {
/*      */             
/* 1016 */             (this.core[0]).sizeC = getImageCount();
/* 1017 */             (this.core[0]).sizeZ = 1;
/* 1018 */             (this.core[0]).sizeT = 1;
/*      */           }
/* 1020 */           else if (key.equals("AXIS_9")) {
/* 1021 */             multipleFiles = true;
/* 1022 */             (this.core[0]).sizeC = (int)Double.parseDouble(values[3]);
/*      */           } 
/*      */         } 
/*      */         
/* 1026 */         if (getMetadataOptions().getMetadataLevel() != MetadataLevel.MINIMUM && values.length > 2) {
/*      */           String prefix;
/*      */           
/* 1029 */           switch (axisType) {
/*      */             case 1:
/* 1031 */               addGlobalMeta(key + " distance (X) in microns", values[2]);
/* 1032 */               addGlobalMeta(key + " distance (Y) in microns", values[3]);
/*      */               break;
/*      */             case 3:
/* 1035 */               addGlobalMeta(key + " angle (X) in degrees", values[2]);
/* 1036 */               addGlobalMeta(key + " angle (Y) in degrees", values[3]);
/*      */               break;
/*      */             case 4:
/* 1039 */               addGlobalMeta(key + " intensity (X)", values[2]);
/* 1040 */               addGlobalMeta(key + " intensity (Y)", values[3]);
/*      */               break;
/*      */             case 6:
/* 1043 */               addGlobalMeta(key + " ratio (X)", values[2]);
/* 1044 */               addGlobalMeta(key + " ratio (Y)", values[3]);
/*      */               break;
/*      */             case 7:
/* 1047 */               addGlobalMeta(key + " log ratio (X)", values[2]);
/* 1048 */               addGlobalMeta(key + " log ratio (Y)", values[3]);
/*      */               break;
/*      */             case 9:
/* 1051 */               addGlobalMeta(key + " noncalibrated intensity min", values[2]);
/* 1052 */               addGlobalMeta(key + " noncalibrated intensity max", values[3]);
/* 1053 */               addGlobalMeta(key + " calibrated intensity min", values[4]);
/* 1054 */               addGlobalMeta(key + " calibrated intensity max", values[5]);
/*      */               break;
/*      */             case 14:
/* 1057 */               addGlobalMeta(key + " time course type (X)", values[2]);
/* 1058 */               addGlobalMeta(key + " time course type (Y)", values[3]);
/*      */               break;
/*      */             case 15:
/* 1061 */               prefix = " inverse sigmoid calibrated intensity ";
/* 1062 */               addGlobalMeta(key + prefix + "(min)", values[2]);
/* 1063 */               addGlobalMeta(key + prefix + "(max)", values[3]);
/* 1064 */               addGlobalMeta(key + prefix + "(beta)", values[4]);
/* 1065 */               addGlobalMeta(key + prefix + "(Kd)", values[5]);
/*      */               break;
/*      */             case 16:
/* 1068 */               prefix = " log inverse sigmoid calibrated intensity ";
/* 1069 */               addGlobalMeta(key + prefix + "(min)", values[2]);
/* 1070 */               addGlobalMeta(key + prefix + "(max)", values[3]);
/* 1071 */               addGlobalMeta(key + prefix + "(beta)", values[4]);
/* 1072 */               addGlobalMeta(key + prefix + "(Kd)", values[5]);
/*      */               break;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/* 1078 */     return multipleFiles;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void readLookupTables(RandomAccessInputStream s) throws IOException {
/* 1085 */     int channel = 0;
/* 1086 */     for (; channel < this.lut.length && this.lut[channel] != null; channel++);
/* 1087 */     if (channel >= this.lut.length)
/*      */       return; 
/* 1089 */     readNotes(s, false);
/*      */ 
/*      */     
/* 1092 */     boolean eof = false;
/* 1093 */     int next = 0;
/* 1094 */     while (!eof && channel < this.lut.length && !this.brokenNotes) {
/* 1095 */       if (s.getFilePointer() + 256L <= s.length()) {
/* 1096 */         if (this.lut[channel] == null) {
/* 1097 */           this.lut[channel] = new byte[3][256];
/*      */         }
/*      */         
/* 1100 */         s.read(this.lut[channel][next++]);
/* 1101 */         if (next == 3) {
/* 1102 */           next = 0;
/* 1103 */           channel++;
/*      */         } 
/*      */       } else {
/* 1106 */         eof = true;
/* 1107 */       }  if (eof && channel == 0) {
/* 1108 */         this.lut = (byte[][][])null;
/*      */       }
/*      */     } 
/* 1111 */     if (this.brokenNotes) this.lut = (byte[][][])null;
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   class BioRadHandler
/*      */     extends BaseHandler
/*      */   {
/*      */     public void startElement(String uri, String localName, String qName, Attributes attributes) {
/* 1121 */       if (qName.equals("Pixels")) {
/* 1122 */         String sizeZ = attributes.getValue("SizeZ");
/* 1123 */         String sizeC = attributes.getValue("SizeC");
/* 1124 */         String sizeT = attributes.getValue("SizeT");
/* 1125 */         int z = (sizeZ == null) ? 1 : Integer.parseInt(sizeZ);
/* 1126 */         int c = (sizeC == null) ? 1 : Integer.parseInt(sizeC);
/* 1127 */         int t = (sizeT == null) ? 1 : Integer.parseInt(sizeT);
/* 1128 */         int count = BioRadReader.this.getSizeZ() * BioRadReader.this.getSizeC() * BioRadReader.this.getSizeT();
/* 1129 */         (BioRadReader.this.core[0]).sizeZ = z;
/* 1130 */         (BioRadReader.this.core[0]).sizeC = c;
/* 1131 */         (BioRadReader.this.core[0]).sizeT = t;
/* 1132 */         if (count >= BioRadReader.this.getImageCount()) { (BioRadReader.this.core[0]).imageCount = count; }
/* 1133 */         else { (BioRadReader.this.core[0]).sizeC = BioRadReader.this.getImageCount() / count; }
/*      */       
/* 1135 */       } else if (qName.equals("Z") || qName.equals("C") || qName.equals("T")) {
/* 1136 */         String stamp = attributes.getValue("TimeCompleted");
/* 1137 */         int count = 0;
/* 1138 */         for (; BioRadReader.this.metadata.containsKey("Timestamp " + count); count++);
/* 1139 */         BioRadReader.this.addGlobalMeta("Timestamp " + count, stamp);
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   class Note {
/*      */     public int num;
/*      */     public int level;
/*      */     public int status;
/*      */     public int type;
/*      */     public int x;
/*      */     public int y;
/*      */     public String p;
/*      */     
/*      */     public String toString() {
/* 1154 */       StringBuffer sb = new StringBuffer(100);
/* 1155 */       sb.append("level=");
/* 1156 */       sb.append(this.level);
/* 1157 */       sb.append("; num=");
/* 1158 */       sb.append(this.num);
/* 1159 */       sb.append("; status=");
/* 1160 */       sb.append(this.status);
/* 1161 */       sb.append("; type=");
/* 1162 */       sb.append(BioRadReader.NOTE_NAMES[this.type]);
/* 1163 */       sb.append("; x=");
/* 1164 */       sb.append(this.x);
/* 1165 */       sb.append("; y=");
/* 1166 */       sb.append(this.y);
/* 1167 */       sb.append("; text=");
/* 1168 */       sb.append((this.p == null) ? "null" : this.p.trim());
/* 1169 */       return sb.toString();
/*      */     }
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/in/BioRadReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */