/*     */ package loci.formats.in;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import loci.common.ByteArrayHandle;
/*     */ import loci.common.IRandomAccess;
/*     */ import loci.common.Location;
/*     */ import loci.common.RandomAccessInputStream;
/*     */ import loci.common.Region;
/*     */ import loci.formats.CoreMetadata;
/*     */ import loci.formats.FormatException;
/*     */ import loci.formats.FormatReader;
/*     */ import loci.formats.FormatTools;
/*     */ import loci.formats.IFormatReader;
/*     */ import loci.formats.MetadataTools;
/*     */ import loci.formats.codec.CodecOptions;
/*     */ import loci.formats.codec.JPEG2000Codec;
/*     */ import loci.formats.codec.JPEGCodec;
/*     */ import loci.formats.meta.MetadataStore;
/*     */ import loci.formats.tiff.IFD;
/*     */ import loci.formats.tiff.IFDList;
/*     */ import loci.formats.tiff.PhotoInterp;
/*     */ import loci.formats.tiff.TiffParser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CellSensReader
/*     */   extends FormatReader
/*     */ {
/*     */   private static final int RAW = 0;
/*     */   private static final int JPEG = 2;
/*     */   private static final int JPEG_2000 = 3;
/*     */   private static final int PNG = 8;
/*     */   private static final int BMP = 9;
/*     */   private static final int CHAR = 1;
/*     */   private static final int UCHAR = 2;
/*     */   private static final int SHORT = 3;
/*     */   private static final int USHORT = 4;
/*     */   private static final int INT = 5;
/*     */   private static final int UINT = 6;
/*     */   private static final int LONG = 7;
/*     */   private static final int ULONG = 8;
/*     */   private static final int FLOAT = 9;
/*     */   private static final int DOUBLE = 10;
/*     */   private static final int COMPLEX = 11;
/*     */   private static final int BOOLEAN = 12;
/*     */   private static final int TCHAR = 13;
/*     */   private static final int DWORD = 14;
/*     */   private static final int TIMESTAMP = 17;
/*     */   private static final int DATE = 18;
/*     */   private static final int INT_2 = 256;
/*     */   private static final int INT_3 = 257;
/*     */   private static final int INT_4 = 258;
/*     */   private static final int INT_RECT = 259;
/*     */   private static final int DOUBLE_2 = 260;
/*     */   private static final int DOUBLE_3 = 261;
/*     */   private static final int DOUBLE_4 = 262;
/*     */   private static final int DOUBLE_RECT = 263;
/*     */   private static final int DOUBLE_2_2 = 264;
/*     */   private static final int DOUBLE_3_3 = 265;
/*     */   private static final int DOUBLE_4_4 = 266;
/*     */   private static final int INT_INTERVAL = 267;
/*     */   private static final int DOUBLE_INTERVAL = 268;
/*     */   private static final int RGB = 269;
/*     */   private static final int BGR = 270;
/*     */   private static final int FIELD_TYPE = 271;
/*     */   private static final int MEM_MODEL = 272;
/*     */   private static final int COLOR_SPACE = 273;
/*     */   private static final int INT_ARRAY_2 = 274;
/*     */   private static final int INT_ARRAY_3 = 275;
/*     */   private static final int INT_ARRAY_4 = 276;
/*     */   private static final int INT_ARRAY_5 = 277;
/*     */   private static final int DOUBLE_ARRAY_2 = 279;
/*     */   private static final int DOUBLE_ARRAY_3 = 280;
/*     */   private static final int UNICODE_TCHAR = 8192;
/*     */   private static final int DIM_INDEX_1 = 8195;
/*     */   private static final int DIM_INDEX_2 = 8199;
/*     */   private static final int VOLUME_INDEX = 8200;
/*     */   private static final int PIXEL_INFO_TYPE = 8470;
/*     */   private static final int NEW_VOLUME_HEADER = 0;
/*     */   private static final int PROPERTY_SET_VOLUME = 1;
/*     */   private static final int NEW_MDIM_VOLUME_HEADER = 2;
/*     */   private static final int TIFF_IFD = 10;
/*     */   private static final int VECTOR_DATA = 11;
/*     */   private String[] usedFiles;
/*     */   private TiffParser parser;
/*     */   private IFDList ifds;
/*     */   private Long[][] tileOffsets;
/*     */   private boolean jpeg = false;
/*     */   private int[] rows;
/*     */   private int[] cols;
/*     */   private int[] compressionType;
/*     */   private int[] tileX;
/*     */   private int[] tileY;
/*     */   private HashMap<TileCoordinate, Integer>[] tileMap;
/*     */   private int[] nDimensions;
/*     */   private boolean inDimensionProperties = false;
/*     */   private boolean foundChannelTag = false;
/*     */   private int dimensionTag;
/* 147 */   private HashMap<String, Integer> dimensionOrdering = new HashMap<String, Integer>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CellSensReader() {
/* 154 */     super("CellSens VSI", new String[] { "vsi", "ets" });
/* 155 */     this.domains = new String[] { "Histology" };
/* 156 */     this.suffixSufficient = true;
/* 157 */     this.datasetDescription = "One .vsi file and an optional directory with a similar name that contains at least one subdirectory with .ets files";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int fileGroupOption(String id) throws FormatException, IOException {
/* 165 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSingleFile(String id) throws FormatException, IOException {
/* 170 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getSeriesUsedFiles(boolean noPixels) {
/* 175 */     FormatTools.assertId(this.currentId, true, 1);
/*     */     
/* 177 */     return this.usedFiles;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOptimalTileWidth() {
/* 182 */     FormatTools.assertId(this.currentId, true, 1);
/* 183 */     if (getCoreIndex() < this.core.length - this.ifds.size()) {
/* 184 */       return this.tileX[getCoreIndex()];
/*     */     }
/* 186 */     int ifdIndex = getCoreIndex() - this.usedFiles.length - 1;
/*     */     try {
/* 188 */       return (int)((IFD)this.ifds.get(ifdIndex)).getTileWidth();
/*     */     }
/* 190 */     catch (FormatException e) {
/* 191 */       LOGGER.debug("Could not retrieve tile width", (Throwable)e);
/*     */       
/* 193 */       return super.getOptimalTileWidth();
/*     */     } 
/*     */   }
/*     */   
/*     */   public int getOptimalTileHeight() {
/* 198 */     FormatTools.assertId(this.currentId, true, 1);
/* 199 */     if (getCoreIndex() < this.core.length - this.ifds.size()) {
/* 200 */       return this.tileY[getCoreIndex()];
/*     */     }
/* 202 */     int ifdIndex = getCoreIndex() - this.usedFiles.length - 1;
/*     */     try {
/* 204 */       return (int)((IFD)this.ifds.get(ifdIndex)).getTileLength();
/*     */     }
/* 206 */     catch (FormatException e) {
/* 207 */       LOGGER.debug("Could not retrieve tile height", (Throwable)e);
/*     */       
/* 209 */       return super.getOptimalTileHeight();
/*     */     } 
/*     */   }
/*     */   
/*     */   public byte[] openThumbBytes(int no) throws FormatException, IOException {
/* 214 */     FormatTools.assertId(this.currentId, true, 1);
/*     */     
/* 216 */     int currentSeries = getSeries();
/* 217 */     int thumbSize = getThumbSizeX() * getThumbSizeY() * FormatTools.getBytesPerPixel(getPixelType()) * getRGBChannelCount();
/*     */ 
/*     */     
/* 220 */     if (getCoreIndex() >= this.usedFiles.length - 1 || this.usedFiles.length >= this.core.length)
/*     */     {
/*     */       
/* 223 */       return super.openThumbBytes(no);
/*     */     }
/*     */     
/* 226 */     setSeries(this.usedFiles.length);
/* 227 */     byte[] thumb = FormatTools.openThumbBytes((IFormatReader)this, 0);
/* 228 */     setSeries(currentSeries);
/* 229 */     if (thumb.length == thumbSize) {
/* 230 */       return thumb;
/*     */     }
/* 232 */     return super.openThumbBytes(no);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] openBytes(int no, byte[] buf, int x, int y, int w, int h) throws FormatException, IOException {
/* 241 */     FormatTools.checkPlaneParameters((IFormatReader)this, no, buf.length, x, y, w, h);
/*     */     
/* 243 */     if (getCoreIndex() < this.core.length - this.ifds.size()) {
/* 244 */       int tileRows = this.rows[getCoreIndex()];
/* 245 */       int tileCols = this.cols[getCoreIndex()];
/*     */       
/* 247 */       Region image = new Region(x, y, w, h);
/* 248 */       int outputRow = 0, outputCol = 0;
/* 249 */       Region intersection = null;
/*     */       
/* 251 */       byte[] tileBuf = null;
/* 252 */       int pixel = getRGBChannelCount() * FormatTools.getBytesPerPixel(getPixelType());
/*     */       
/* 254 */       int outputRowLen = w * pixel;
/*     */       
/* 256 */       for (int row = 0; row < tileRows; row++) {
/* 257 */         for (int col = 0; col < tileCols; col++) {
/* 258 */           int width = this.tileX[getCoreIndex()];
/* 259 */           int height = this.tileY[getCoreIndex()];
/* 260 */           Region tile = new Region(col * width, row * height, width, height);
/* 261 */           if (tile.intersects(image)) {
/*     */ 
/*     */ 
/*     */             
/* 265 */             intersection = tile.intersection(image);
/* 266 */             int intersectionX = 0;
/*     */             
/* 268 */             if (tile.x < image.x) {
/* 269 */               intersectionX = image.x - tile.x;
/*     */             }
/*     */             
/* 272 */             tileBuf = decodeTile(no, row, col);
/*     */             
/* 274 */             int rowLen = pixel * Math.min(intersection.width, width);
/*     */             
/* 276 */             int outputOffset = outputRow * outputRowLen + outputCol;
/* 277 */             for (int trow = 0; trow < intersection.height; trow++) {
/* 278 */               int realRow = trow + intersection.y - tile.y;
/* 279 */               int inputOffset = pixel * (realRow * width + intersectionX);
/* 280 */               System.arraycopy(tileBuf, inputOffset, buf, outputOffset, rowLen);
/* 281 */               outputOffset += outputRowLen;
/*     */             } 
/*     */             
/* 284 */             outputCol += rowLen;
/*     */           } 
/*     */         } 
/* 287 */         if (intersection != null) {
/* 288 */           outputRow += intersection.height;
/* 289 */           outputCol = 0;
/*     */         } 
/*     */       } 
/*     */       
/* 293 */       return buf;
/*     */     } 
/*     */     
/* 296 */     int ifdIndex = getCoreIndex() - this.usedFiles.length - 1;
/* 297 */     return this.parser.getSamples((IFD)this.ifds.get(ifdIndex), buf, x, y, w, h);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void close(boolean fileOnly) throws IOException {
/* 303 */     super.close(fileOnly);
/* 304 */     if (!fileOnly) {
/* 305 */       if (this.parser != null && this.parser.getStream() != null) {
/* 306 */         this.parser.getStream().close();
/*     */       }
/* 308 */       this.parser = null;
/* 309 */       this.ifds = null;
/* 310 */       this.usedFiles = null;
/* 311 */       this.tileOffsets = (Long[][])null;
/* 312 */       this.jpeg = false;
/* 313 */       this.rows = null;
/* 314 */       this.cols = null;
/* 315 */       this.compressionType = null;
/* 316 */       this.tileX = null;
/* 317 */       this.tileY = null;
/* 318 */       this.tileMap = null;
/* 319 */       this.nDimensions = null;
/* 320 */       this.inDimensionProperties = false;
/* 321 */       this.foundChannelTag = false;
/* 322 */       this.dimensionTag = 0;
/* 323 */       this.dimensionOrdering.clear();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initFile(String id) throws FormatException, IOException {
/* 331 */     super.initFile(id);
/*     */     
/* 333 */     if (!checkSuffix(id, "vsi")) {
/* 334 */       Location current = (new Location(id)).getAbsoluteFile();
/* 335 */       Location parent = current.getParentFile();
/* 336 */       parent = parent.getParentFile();
/* 337 */       Location grandparent = parent.getParentFile();
/* 338 */       String str = parent.getName();
/* 339 */       str = str.substring(1, str.length() - 1) + ".vsi";
/*     */       
/* 341 */       Location vsiFile = new Location(grandparent, str);
/* 342 */       if (!vsiFile.exists()) {
/* 343 */         throw new FormatException("Could not find .vsi file.");
/*     */       }
/*     */       
/* 346 */       id = vsiFile.getAbsolutePath();
/*     */     } 
/*     */ 
/*     */     
/* 350 */     this.parser = new TiffParser(id);
/* 351 */     this.ifds = this.parser.getIFDs();
/*     */     
/* 353 */     RandomAccessInputStream vsi = new RandomAccessInputStream(id);
/* 354 */     vsi.order(this.parser.getStream().isLittleEndian());
/* 355 */     vsi.seek(8L);
/* 356 */     readTags(vsi);
/* 357 */     vsi.seek(this.parser.getStream().getFilePointer());
/*     */     
/* 359 */     vsi.skipBytes(273);
/*     */     
/* 361 */     ArrayList<String> files = new ArrayList<String>();
/* 362 */     Location file = (new Location(id)).getAbsoluteFile();
/*     */     
/* 364 */     Location dir = file.getParentFile();
/*     */     
/* 366 */     String name = file.getName();
/* 367 */     name = name.substring(0, name.lastIndexOf("."));
/*     */     
/* 369 */     Location pixelsDir = new Location(dir, "_" + name + "_");
/* 370 */     String[] stackDirs = pixelsDir.list(true);
/* 371 */     if (stackDirs != null) {
/* 372 */       Arrays.sort((Object[])stackDirs);
/* 373 */       for (String f : stackDirs) {
/* 374 */         Location stackDir = new Location(pixelsDir, f);
/* 375 */         String[] pixelsFiles = stackDir.list(true);
/* 376 */         if (pixelsFiles != null) {
/* 377 */           Arrays.sort((Object[])pixelsFiles);
/* 378 */           for (String pixelsFile : pixelsFiles) {
/* 379 */             if (checkSuffix(pixelsFile, "ets")) {
/* 380 */               files.add((new Location(stackDir, pixelsFile)).getAbsolutePath());
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 386 */     files.add(file.getAbsolutePath());
/* 387 */     this.usedFiles = files.<String>toArray(new String[files.size()]);
/*     */     
/* 389 */     this.core = new CoreMetadata[files.size() - 1 + this.ifds.size()];
/*     */     
/* 391 */     this.tileOffsets = new Long[files.size() - 1][];
/* 392 */     this.rows = new int[files.size() - 1];
/* 393 */     this.cols = new int[files.size() - 1];
/* 394 */     this.nDimensions = new int[this.core.length];
/*     */     
/* 396 */     IFDList exifs = this.parser.getExifIFDs();
/*     */     
/* 398 */     this.compressionType = new int[this.core.length];
/* 399 */     this.tileX = new int[this.core.length];
/* 400 */     this.tileY = new int[this.core.length];
/* 401 */     this.tileMap = (HashMap<TileCoordinate, Integer>[])new HashMap[this.core.length];
/*     */     int s;
/* 403 */     for (s = 0; s < this.core.length; s++) {
/* 404 */       this.core[s] = new CoreMetadata();
/*     */     }
/*     */     
/* 407 */     for (s = 0; s < this.core.length; s++) {
/* 408 */       this.tileMap[s] = new HashMap<TileCoordinate, Integer>();
/*     */       
/* 410 */       if (s == 0) {
/* 411 */         (this.core[s]).resolutionCount = this.ifds.size() + ((files.size() == 1) ? 0 : 1);
/*     */       }
/*     */       
/* 414 */       if (s < files.size() - 1) {
/* 415 */         setSeries(s);
/* 416 */         parseETSFile(files.get(s), s);
/*     */         
/* 418 */         (this.core[s]).littleEndian = (this.compressionType[s] == 0);
/* 419 */         (this.core[s]).interleaved = (this.core[s]).rgb;
/*     */         
/* 421 */         if (s == 0 && exifs.size() > 0) {
/* 422 */           IFD exif = (IFD)exifs.get(0);
/*     */           
/* 424 */           int newX = exif.getIFDIntValue(40962);
/* 425 */           int newY = exif.getIFDIntValue(40963);
/*     */           
/* 427 */           if (getSizeX() > newX || getSizeY() > newY) {
/* 428 */             (this.core[s]).sizeX = newX;
/* 429 */             (this.core[s]).sizeY = newY;
/*     */           } 
/*     */         } 
/*     */         
/* 433 */         setSeries(0);
/*     */       } else {
/*     */         
/* 436 */         IFD ifd = (IFD)this.ifds.get(s - files.size() + 1);
/* 437 */         PhotoInterp p = ifd.getPhotometricInterpretation();
/* 438 */         int samples = ifd.getSamplesPerPixel();
/* 439 */         (this.core[s]).rgb = (samples > 1 || p == PhotoInterp.RGB);
/* 440 */         (this.core[s]).sizeX = (int)ifd.getImageWidth();
/* 441 */         (this.core[s]).sizeY = (int)ifd.getImageLength();
/* 442 */         (this.core[s]).sizeZ = 1;
/* 443 */         (this.core[s]).sizeT = 1;
/* 444 */         (this.core[s]).sizeC = (this.core[s]).rgb ? samples : 1;
/* 445 */         (this.core[s]).littleEndian = ifd.isLittleEndian();
/* 446 */         (this.core[s]).indexed = (p == PhotoInterp.RGB_PALETTE && (get8BitLookupTable() != null || get16BitLookupTable() != null));
/*     */         
/* 448 */         (this.core[s]).imageCount = 1;
/* 449 */         (this.core[s]).pixelType = ifd.getPixelType();
/* 450 */         (this.core[s]).interleaved = false;
/* 451 */         (this.core[s]).falseColor = false;
/* 452 */         (this.core[s]).thumbnail = (s != 0);
/*     */       } 
/* 454 */       (this.core[s]).metadataComplete = true;
/* 455 */       (this.core[s]).dimensionOrder = "XYCZT";
/*     */     } 
/* 457 */     vsi.close();
/*     */     
/* 459 */     MetadataStore store = makeFilterMetadata();
/* 460 */     MetadataTools.populatePixels(store, (IFormatReader)this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private int getTileSize() {
/* 466 */     int channels = getRGBChannelCount();
/* 467 */     int bpp = FormatTools.getBytesPerPixel(getPixelType());
/* 468 */     return bpp * channels * this.tileX[getCoreIndex()] * this.tileY[getCoreIndex()]; } private byte[] decodeTile(int no, int row, int col) throws FormatException, IOException {
/*     */     APNGReader aPNGReader;
/*     */     BMPReader bMPReader;
/*     */     JPEGCodec jPEGCodec;
/*     */     JPEG2000Codec jPEG2000Codec;
/*     */     byte[] b;
/* 474 */     if (this.tileMap[getCoreIndex()] == null) {
/* 475 */       return new byte[getTileSize()];
/*     */     }
/*     */     
/* 478 */     int[] zct = getZCTCoords(no);
/* 479 */     TileCoordinate t = new TileCoordinate(this.nDimensions[getCoreIndex()]);
/* 480 */     t.coordinate[0] = col;
/* 481 */     t.coordinate[1] = row;
/*     */     
/* 483 */     for (String dim : this.dimensionOrdering.keySet()) {
/* 484 */       int i = ((Integer)this.dimensionOrdering.get(dim)).intValue() + 2;
/*     */       
/* 486 */       if (dim.equals("Z")) {
/* 487 */         t.coordinate[i] = zct[0]; continue;
/*     */       } 
/* 489 */       if (dim.equals("C")) {
/* 490 */         t.coordinate[i] = zct[1]; continue;
/*     */       } 
/* 492 */       if (dim.equals("T")) {
/* 493 */         t.coordinate[i] = zct[2];
/*     */       }
/*     */     } 
/*     */     
/* 497 */     Integer index = this.tileMap[getCoreIndex()].get(t);
/* 498 */     if (index == null) {
/* 499 */       return new byte[getTileSize()];
/*     */     }
/*     */     
/* 502 */     Long offset = this.tileOffsets[getCoreIndex()][index.intValue()];
/* 503 */     RandomAccessInputStream ets = new RandomAccessInputStream(this.usedFiles[getCoreIndex()]);
/*     */     
/* 505 */     ets.seek(offset.longValue());
/*     */     
/* 507 */     CodecOptions options = new CodecOptions();
/* 508 */     options.interleaved = isInterleaved();
/* 509 */     options.littleEndian = isLittleEndian();
/* 510 */     int tileSize = getTileSize();
/* 511 */     if (tileSize == 0) {
/* 512 */       tileSize = this.tileX[getCoreIndex()] * this.tileY[getCoreIndex()] * 10;
/*     */     }
/* 514 */     options.maxBytes = (int)(offset.longValue() + tileSize);
/*     */     
/* 516 */     byte[] buf = null;
/* 517 */     long end = (index.intValue() < (this.tileOffsets[getCoreIndex()]).length - 1) ? this.tileOffsets[getCoreIndex()][index.intValue() + 1].longValue() : ets.length();
/*     */ 
/*     */     
/* 520 */     IFormatReader reader = null;
/* 521 */     String file = null;
/*     */     
/* 523 */     switch (this.compressionType[getCoreIndex()]) {
/*     */       case 0:
/* 525 */         buf = new byte[tileSize];
/* 526 */         ets.read(buf);
/*     */         break;
/*     */       case 2:
/* 529 */         jPEGCodec = new JPEGCodec();
/* 530 */         buf = jPEGCodec.decompress(ets, options);
/*     */         break;
/*     */       case 3:
/* 533 */         jPEG2000Codec = new JPEG2000Codec();
/* 534 */         buf = jPEG2000Codec.decompress(ets, options);
/*     */         break;
/*     */       case 8:
/* 537 */         file = "tile.png";
/* 538 */         aPNGReader = new APNGReader();
/*     */       case 9:
/* 540 */         if (aPNGReader == null) {
/* 541 */           file = "tile.bmp";
/* 542 */           bMPReader = new BMPReader();
/*     */         } 
/*     */         
/* 545 */         b = new byte[(int)(end - offset.longValue())];
/* 546 */         ets.read(b);
/* 547 */         Location.mapFile(file, (IRandomAccess)new ByteArrayHandle(b));
/* 548 */         bMPReader.setId(file);
/* 549 */         buf = bMPReader.openBytes(0);
/* 550 */         Location.mapFile(file, null);
/*     */         break;
/*     */     } 
/*     */     
/* 554 */     if (bMPReader != null) {
/* 555 */       bMPReader.close();
/*     */     }
/*     */     
/* 558 */     ets.close();
/* 559 */     return buf;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void parseETSFile(String file, int s) throws FormatException, IOException {
/* 565 */     RandomAccessInputStream etsFile = new RandomAccessInputStream(file);
/* 566 */     etsFile.order(true);
/*     */ 
/*     */     
/* 569 */     String magic = etsFile.readString(4).trim();
/* 570 */     if (!magic.equals("SIS")) {
/* 571 */       throw new FormatException("Unknown magic bytes: " + magic);
/*     */     }
/*     */     
/* 574 */     int headerSize = etsFile.readInt();
/* 575 */     int version = etsFile.readInt();
/* 576 */     this.nDimensions[s] = etsFile.readInt();
/* 577 */     long additionalHeaderOffset = etsFile.readLong();
/* 578 */     int additionalHeaderSize = etsFile.readInt();
/* 579 */     etsFile.skipBytes(4);
/* 580 */     long usedChunkOffset = etsFile.readLong();
/* 581 */     int nUsedChunks = etsFile.readInt();
/* 582 */     etsFile.skipBytes(4);
/*     */ 
/*     */     
/* 585 */     etsFile.seek(additionalHeaderOffset);
/*     */     
/* 587 */     String moreMagic = etsFile.readString(4).trim();
/* 588 */     if (!moreMagic.equals("ETS")) {
/* 589 */       throw new FormatException("Unknown magic bytes: " + moreMagic);
/*     */     }
/*     */     
/* 592 */     etsFile.skipBytes(4);
/*     */     
/* 594 */     int pixelType = etsFile.readInt();
/* 595 */     (this.core[s]).sizeC = etsFile.readInt();
/* 596 */     int colorspace = etsFile.readInt();
/* 597 */     this.compressionType[s] = etsFile.readInt();
/* 598 */     int compressionQuality = etsFile.readInt();
/* 599 */     this.tileX[s] = etsFile.readInt();
/* 600 */     this.tileY[s] = etsFile.readInt();
/* 601 */     int tileZ = etsFile.readInt();
/*     */     
/* 603 */     (this.core[s]).rgb = ((this.core[s]).sizeC > 1);
/*     */ 
/*     */ 
/*     */     
/* 607 */     etsFile.seek(usedChunkOffset);
/*     */     
/* 609 */     this.tileOffsets[s] = new Long[nUsedChunks];
/*     */     
/* 611 */     ArrayList<TileCoordinate> tmpTiles = new ArrayList<TileCoordinate>();
/*     */     
/* 613 */     for (int chunk = 0; chunk < nUsedChunks; chunk++) {
/* 614 */       etsFile.skipBytes(4);
/* 615 */       TileCoordinate t = new TileCoordinate(this.nDimensions[s]);
/* 616 */       for (int j = 0; j < this.nDimensions[s]; j++) {
/* 617 */         t.coordinate[j] = etsFile.readInt();
/*     */       }
/* 619 */       this.tileOffsets[s][chunk] = Long.valueOf(etsFile.readLong());
/* 620 */       int nBytes = etsFile.readInt();
/* 621 */       etsFile.skipBytes(4);
/*     */       
/* 623 */       tmpTiles.add(t);
/*     */     } 
/*     */     
/* 626 */     int maxX = 0;
/* 627 */     int maxY = 0;
/* 628 */     int maxZ = 0;
/* 629 */     int maxC = 0;
/* 630 */     int maxT = 0;
/*     */     
/* 632 */     for (TileCoordinate t : tmpTiles) {
/* 633 */       Integer tv = this.dimensionOrdering.get("T");
/* 634 */       Integer zv = this.dimensionOrdering.get("Z");
/* 635 */       Integer cv = this.dimensionOrdering.get("C");
/*     */       
/* 637 */       int tIndex = (tv == null) ? -1 : (tv.intValue() + 2);
/* 638 */       int zIndex = (zv == null) ? -1 : (zv.intValue() + 2);
/* 639 */       int cIndex = (cv == null) ? -1 : (cv.intValue() + 2);
/*     */       
/* 641 */       if (tv == null && zv == null) {
/* 642 */         if (t.coordinate.length > 4 && cv == null) {
/* 643 */           cIndex = 2;
/* 644 */           this.dimensionOrdering.put("C", Integer.valueOf(cIndex - 2));
/*     */         } 
/*     */         
/* 647 */         if (t.coordinate.length > 4) {
/* 648 */           if (cv == null) {
/* 649 */             tIndex = 3;
/*     */           } else {
/*     */             
/* 652 */             tIndex = cIndex + 2;
/*     */           } 
/* 654 */           if (tIndex < t.coordinate.length) {
/* 655 */             this.dimensionOrdering.put("T", Integer.valueOf(tIndex - 2));
/*     */           } else {
/*     */             
/* 658 */             tIndex = -1;
/*     */           } 
/*     */         } 
/*     */         
/* 662 */         if (t.coordinate.length > 5) {
/* 663 */           if (cv == null) {
/* 664 */             zIndex = 4;
/*     */           } else {
/*     */             
/* 667 */             zIndex = cIndex + 1;
/*     */           } 
/* 669 */           if (zIndex < t.coordinate.length) {
/* 670 */             this.dimensionOrdering.put("Z", Integer.valueOf(zIndex - 2));
/*     */           } else {
/*     */             
/* 673 */             zIndex = -1;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/* 678 */       if (t.coordinate[0] > maxX) {
/* 679 */         maxX = t.coordinate[0];
/*     */       }
/* 681 */       if (t.coordinate[1] > maxY) {
/* 682 */         maxY = t.coordinate[1];
/*     */       }
/*     */       
/* 685 */       if (tIndex >= 0 && t.coordinate[tIndex] > maxT) {
/* 686 */         maxT = t.coordinate[tIndex];
/*     */       }
/* 688 */       if (zIndex >= 0 && t.coordinate[zIndex] > maxZ) {
/* 689 */         maxZ = t.coordinate[zIndex];
/*     */       }
/* 691 */       if (cIndex >= 0 && t.coordinate[cIndex] > maxC) {
/* 692 */         maxC = t.coordinate[cIndex];
/*     */       }
/*     */     } 
/*     */     
/* 696 */     if (maxX > 1) {
/* 697 */       (this.core[s]).sizeX = this.tileX[s] * (maxX + 1);
/*     */     } else {
/*     */       
/* 700 */       (this.core[s]).sizeX = this.tileX[s];
/*     */     } 
/* 702 */     if (maxY > 1) {
/* 703 */       (this.core[s]).sizeY = this.tileY[s] * (maxY + 1);
/*     */     } else {
/*     */       
/* 706 */       (this.core[s]).sizeY = this.tileY[s];
/*     */     } 
/* 708 */     (this.core[s]).sizeZ = maxZ + 1;
/* 709 */     if (maxC > 0) {
/* 710 */       (this.core[s]).sizeC *= maxC + 1;
/*     */     }
/* 712 */     (this.core[s]).sizeT = maxT + 1;
/* 713 */     if ((this.core[s]).sizeZ == 0) {
/* 714 */       (this.core[s]).sizeZ = 1;
/*     */     }
/* 716 */     (this.core[s]).imageCount = (this.core[s]).sizeZ * (this.core[s]).sizeT;
/* 717 */     if (maxC > 0) {
/* 718 */       (this.core[s]).imageCount *= maxC + 1;
/*     */     }
/*     */     
/* 721 */     if (maxY > 1) {
/* 722 */       this.rows[s] = maxY + 1;
/*     */     } else {
/*     */       
/* 725 */       this.rows[s] = 1;
/*     */     } 
/* 727 */     if (maxX > 1) {
/* 728 */       this.cols[s] = maxX + 1;
/*     */     } else {
/*     */       
/* 731 */       this.cols[s] = 1;
/*     */     } 
/*     */     
/* 734 */     for (int i = 0; i < tmpTiles.size(); i++) {
/* 735 */       this.tileMap[s].put(tmpTiles.get(i), Integer.valueOf(i));
/*     */     }
/*     */     
/* 738 */     (this.core[s]).pixelType = convertPixelType(pixelType);
/* 739 */     etsFile.close();
/*     */   }
/*     */   
/*     */   private int convertPixelType(int pixelType) throws FormatException {
/* 743 */     switch (pixelType) {
/*     */       case 1:
/* 745 */         return 0;
/*     */       case 2:
/* 747 */         return 1;
/*     */       case 3:
/* 749 */         return 2;
/*     */       case 4:
/* 751 */         return 3;
/*     */       case 5:
/* 753 */         return 4;
/*     */       case 6:
/* 755 */         return 5;
/*     */       case 7:
/* 757 */         throw new FormatException("Unsupported pixel type: long");
/*     */       case 8:
/* 759 */         throw new FormatException("Unsupported pixel type: unsigned long");
/*     */       case 9:
/* 761 */         return 6;
/*     */       case 10:
/* 763 */         return 7;
/*     */     } 
/* 765 */     throw new FormatException("Unsupported pixel type: " + pixelType);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void readTags(RandomAccessInputStream vsi) {
/*     */     try {
/* 772 */       long fp = vsi.getFilePointer();
/* 773 */       if (fp + 24L >= vsi.length()) {
/*     */         return;
/*     */       }
/* 776 */       int headerSize = vsi.readShort();
/* 777 */       int version = vsi.readShort();
/* 778 */       int volumeVersion = vsi.readInt();
/* 779 */       long dataFieldOffset = vsi.readLong();
/* 780 */       int flags = vsi.readInt();
/* 781 */       vsi.skipBytes(4);
/*     */       
/* 783 */       int tagCount = flags & 0xFFFFFFF;
/*     */       
/* 785 */       if (fp + dataFieldOffset < 0L) {
/*     */         return;
/*     */       }
/*     */       
/* 789 */       vsi.seek(fp + dataFieldOffset);
/* 790 */       if (vsi.getFilePointer() >= vsi.length()) {
/*     */         return;
/*     */       }
/*     */       
/* 794 */       for (int i = 0; i < tagCount && 
/* 795 */         vsi.getFilePointer() + 16L < vsi.length(); ) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 801 */         int fieldType = vsi.readInt();
/* 802 */         int tag = vsi.readInt();
/* 803 */         long nextField = vsi.readInt() & 0xFFFFFFFFL;
/* 804 */         int dataSize = vsi.readInt();
/*     */         
/* 806 */         boolean extraTag = ((fieldType & 0x8000000) >> 27 == 1);
/* 807 */         boolean extendedField = ((fieldType & 0x10000000) >> 28 == 1);
/* 808 */         boolean inlineData = ((fieldType & 0x40000000) >> 30 == 1);
/* 809 */         boolean array = (!inlineData && !extendedField && (fieldType & 0x20000000) >> 29 == 1);
/*     */         
/* 811 */         boolean newVolume = ((fieldType & Integer.MIN_VALUE) >> 31 == 1);
/*     */         
/* 813 */         int realType = fieldType & 0xFFFFFF;
/* 814 */         int secondTag = -1;
/*     */         
/* 816 */         if (extraTag) {
/* 817 */           secondTag = vsi.readInt();
/*     */         }
/*     */         
/* 820 */         if (extendedField && realType == 0) {
/* 821 */           if (tag == 2007) {
/* 822 */             this.dimensionTag = secondTag;
/* 823 */             this.inDimensionProperties = true;
/*     */           } 
/* 825 */           long endPointer = vsi.getFilePointer() + dataSize;
/* 826 */           while (vsi.getFilePointer() < endPointer && vsi.getFilePointer() < vsi.length()) {
/*     */ 
/*     */             
/* 829 */             long start = vsi.getFilePointer();
/* 830 */             readTags(vsi);
/* 831 */             long end = vsi.getFilePointer();
/* 832 */             if (start == end) {
/*     */               break;
/*     */             }
/*     */           } 
/* 836 */           if (tag == 2007) {
/* 837 */             this.inDimensionProperties = false;
/* 838 */             this.foundChannelTag = false;
/*     */           } 
/*     */         } 
/*     */         
/* 842 */         if (this.inDimensionProperties) {
/* 843 */           if (tag == 2012 && !this.dimensionOrdering.containsValue(Integer.valueOf(this.dimensionTag))) {
/* 844 */             this.dimensionOrdering.put("Z", Integer.valueOf(this.dimensionTag));
/*     */           }
/* 846 */           else if ((tag == 2100 || tag == 2027) && !this.dimensionOrdering.containsValue(Integer.valueOf(this.dimensionTag))) {
/*     */ 
/*     */             
/* 849 */             this.dimensionOrdering.put("T", Integer.valueOf(this.dimensionTag));
/*     */           }
/* 851 */           else if (tag == 2039 && !this.dimensionOrdering.containsValue(Integer.valueOf(this.dimensionTag))) {
/*     */             
/* 853 */             this.dimensionOrdering.put("L", Integer.valueOf(this.dimensionTag));
/*     */           }
/* 855 */           else if (tag == 2008 && this.foundChannelTag && !this.dimensionOrdering.containsValue(Integer.valueOf(this.dimensionTag))) {
/*     */ 
/*     */             
/* 858 */             this.dimensionOrdering.put("C", Integer.valueOf(this.dimensionTag));
/*     */           }
/* 860 */           else if (tag == 2008) {
/* 861 */             this.foundChannelTag = true;
/*     */           } 
/*     */         }
/*     */         
/* 865 */         if (nextField == 0L) {
/*     */           return;
/*     */         }
/*     */         
/* 869 */         if (fp + nextField < vsi.length() && fp + nextField >= 0L) {
/* 870 */           vsi.seek(fp + nextField);
/*     */           i++;
/*     */         } 
/*     */         break;
/*     */       } 
/* 875 */     } catch (Exception e) {
/* 876 */       LOGGER.debug("Failed to read all tags", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   class TileCoordinate
/*     */   {
/*     */     public int[] coordinate;
/*     */     
/*     */     public TileCoordinate(int nDimensions) {
/* 886 */       this.coordinate = new int[nDimensions];
/*     */     }
/*     */     
/*     */     public boolean equals(Object o) {
/* 890 */       if (!(o instanceof TileCoordinate)) {
/* 891 */         return false;
/*     */       }
/*     */       
/* 894 */       TileCoordinate t = (TileCoordinate)o;
/* 895 */       if (this.coordinate.length != t.coordinate.length) {
/* 896 */         return false;
/*     */       }
/*     */       
/* 899 */       for (int i = 0; i < this.coordinate.length; i++) {
/* 900 */         if (this.coordinate[i] != t.coordinate[i]) {
/* 901 */           return false;
/*     */         }
/*     */       } 
/* 904 */       return true;
/*     */     }
/*     */     
/*     */     public int hashCode() {
/* 908 */       int[] lengths = new int[this.coordinate.length];
/* 909 */       lengths[0] = CellSensReader.this.rows[CellSensReader.this.getSeries()];
/* 910 */       lengths[1] = CellSensReader.this.cols[CellSensReader.this.getSeries()];
/*     */       
/* 912 */       for (String dim : CellSensReader.this.dimensionOrdering.keySet()) {
/* 913 */         int index = ((Integer)CellSensReader.this.dimensionOrdering.get(dim)).intValue() + 2;
/*     */         
/* 915 */         if (dim.equals("Z")) {
/* 916 */           lengths[index] = CellSensReader.this.getSizeZ(); continue;
/*     */         } 
/* 918 */         if (dim.equals("C")) {
/* 919 */           lengths[index] = CellSensReader.this.getEffectiveSizeC(); continue;
/*     */         } 
/* 921 */         if (dim.equals("T")) {
/* 922 */           lengths[index] = CellSensReader.this.getSizeT();
/*     */         }
/*     */       } 
/*     */       
/* 926 */       for (int i = 0; i < lengths.length; i++) {
/* 927 */         if (lengths[i] == 0) {
/* 928 */           lengths[i] = 1;
/*     */         }
/*     */       } 
/*     */       
/* 932 */       return FormatTools.positionToRaster(lengths, this.coordinate);
/*     */     }
/*     */     
/*     */     public String toString() {
/* 936 */       StringBuffer b = new StringBuffer("{");
/* 937 */       for (int p : this.coordinate) {
/* 938 */         b.append(p);
/* 939 */         b.append(", ");
/*     */       } 
/* 941 */       b.append("}");
/* 942 */       return b.toString();
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/in/CellSensReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */