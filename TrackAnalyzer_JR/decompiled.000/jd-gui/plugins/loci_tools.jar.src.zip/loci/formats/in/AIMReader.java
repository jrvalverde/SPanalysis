/*     */ package loci.formats.in;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import loci.common.DateTools;
/*     */ import loci.common.RandomAccessInputStream;
/*     */ import loci.formats.FormatException;
/*     */ import loci.formats.FormatReader;
/*     */ import loci.formats.FormatTools;
/*     */ import loci.formats.IFormatReader;
/*     */ import loci.formats.MetadataTools;
/*     */ import loci.formats.meta.MetadataStore;
/*     */ import ome.xml.model.primitives.PositiveFloat;
/*     */ import ome.xml.model.primitives.Timestamp;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AIMReader
/*     */   extends FormatReader
/*     */ {
/*     */   private long pixelOffset;
/*     */   
/*     */   public AIMReader() {
/*  57 */     super("AIM", "aim");
/*  58 */     this.domains = new String[] { "Unknown" };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] openBytes(int no, byte[] buf, int x, int y, int w, int h) throws FormatException, IOException {
/*  69 */     FormatTools.checkPlaneParameters((IFormatReader)this, no, buf.length, x, y, w, h);
/*     */     
/*  71 */     this.in.seek(this.pixelOffset + (FormatTools.getPlaneSize((IFormatReader)this) * no));
/*  72 */     readPlane(this.in, x, y, w, h, buf);
/*  73 */     return buf;
/*     */   }
/*     */ 
/*     */   
/*     */   public void close(boolean fileOnly) throws IOException {
/*  78 */     super.close(fileOnly);
/*  79 */     if (!fileOnly) {
/*  80 */       this.pixelOffset = 0L;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initFile(String id) throws FormatException, IOException {
/*  88 */     super.initFile(id);
/*  89 */     this.in = new RandomAccessInputStream(id);
/*  90 */     (this.core[0]).littleEndian = true;
/*  91 */     this.in.order(isLittleEndian());
/*     */     
/*  93 */     this.in.seek(56L);
/*     */     
/*  95 */     (this.core[0]).sizeX = this.in.readInt();
/*  96 */     (this.core[0]).sizeY = this.in.readInt();
/*  97 */     (this.core[0]).sizeZ = this.in.readInt();
/*  98 */     (this.core[0]).sizeC = 1;
/*  99 */     (this.core[0]).sizeT = 1;
/* 100 */     (this.core[0]).imageCount = getSizeZ();
/* 101 */     (this.core[0]).pixelType = 2;
/* 102 */     (this.core[0]).dimensionOrder = "XYZCT";
/*     */     
/* 104 */     this.in.seek(160L);
/*     */     
/* 106 */     String processingLog = this.in.readCString();
/* 107 */     this.pixelOffset = this.in.getFilePointer();
/*     */     
/* 109 */     String date = null;
/* 110 */     Double xSize = null, xLength = null;
/* 111 */     Double ySize = null, yLength = null;
/* 112 */     Double zSize = null, zLength = null;
/*     */     
/* 114 */     String[] lines = processingLog.split("\n");
/* 115 */     for (String line : lines) {
/* 116 */       line = line.trim();
/* 117 */       int split = line.indexOf("  ");
/* 118 */       if (split > 0) {
/* 119 */         String key = line.substring(0, split).trim();
/* 120 */         String value = line.substring(split).trim();
/*     */         
/* 122 */         addGlobalMeta(key, value);
/*     */         
/* 124 */         if (key.equals("Original Creation-Date")) {
/* 125 */           date = DateTools.formatDate(value, "dd-MMM-yyyy HH:mm:ss.SS");
/*     */         }
/* 127 */         else if (key.equals("Orig-ISQ-Dim-p")) {
/* 128 */           String[] tokens = value.split(" ");
/* 129 */           for (String token : tokens) {
/* 130 */             token = token.trim();
/* 131 */             if (token.length() > 0) {
/* 132 */               if (xSize == null) {
/* 133 */                 xSize = new Double(token);
/*     */               }
/* 135 */               else if (ySize == null) {
/* 136 */                 ySize = new Double(token);
/*     */               }
/* 138 */               else if (zSize == null) {
/* 139 */                 zSize = new Double(token);
/*     */               }
/*     */             
/*     */             }
/*     */           } 
/* 144 */         } else if (key.equals("Orig-ISQ-Dim-um")) {
/* 145 */           String[] tokens = value.split(" ");
/* 146 */           for (String token : tokens) {
/* 147 */             token = token.trim();
/* 148 */             if (token.length() > 0) {
/* 149 */               if (xLength == null) {
/* 150 */                 xLength = new Double(token);
/*     */               }
/* 152 */               else if (yLength == null) {
/* 153 */                 yLength = new Double(token);
/*     */               }
/* 155 */               else if (zLength == null) {
/* 156 */                 zLength = new Double(token);
/*     */               } 
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 164 */     MetadataStore store = makeFilterMetadata();
/* 165 */     MetadataTools.populatePixels(store, (IFormatReader)this);
/*     */     
/* 167 */     if (date != null) {
/* 168 */       store.setImageAcquisitionDate(new Timestamp(date), 0);
/*     */     }
/*     */     
/* 171 */     if (getMetadataOptions().getMetadataLevel() != MetadataLevel.MINIMUM) {
/* 172 */       if (xSize != null && xLength != null) {
/* 173 */         Double size = Double.valueOf(xLength.doubleValue() / xSize.doubleValue());
/* 174 */         PositiveFloat physicalSize = FormatTools.getPhysicalSizeX(size);
/* 175 */         if (physicalSize != null) {
/* 176 */           store.setPixelsPhysicalSizeX(physicalSize, 0);
/*     */         }
/*     */       } 
/* 179 */       if (ySize != null && yLength != null) {
/* 180 */         Double size = Double.valueOf(yLength.doubleValue() / ySize.doubleValue());
/* 181 */         PositiveFloat physicalSize = FormatTools.getPhysicalSizeY(size);
/* 182 */         if (physicalSize != null) {
/* 183 */           store.setPixelsPhysicalSizeY(physicalSize, 0);
/*     */         }
/*     */       } 
/* 186 */       if (zSize != null && zLength != null) {
/* 187 */         Double size = Double.valueOf(zLength.doubleValue() / zSize.doubleValue());
/* 188 */         PositiveFloat physicalSize = FormatTools.getPhysicalSizeZ(size);
/* 189 */         if (physicalSize != null)
/* 190 */           store.setPixelsPhysicalSizeZ(physicalSize, 0); 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/in/AIMReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */