/*     */ package loci.formats.in;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import loci.common.DateTools;
/*     */ import loci.common.RandomAccessInputStream;
/*     */ import loci.formats.FormatException;
/*     */ import loci.formats.FormatReader;
/*     */ import loci.formats.FormatTools;
/*     */ import loci.formats.IFormatReader;
/*     */ import loci.formats.MetadataTools;
/*     */ import loci.formats.meta.MetadataStore;
/*     */ import ome.xml.model.primitives.PositiveFloat;
/*     */ import ome.xml.model.primitives.Timestamp;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BioRadGelReader
/*     */   extends FormatReader
/*     */ {
/*     */   private static final int MAGIC_BYTES = 44975;
/*     */   private static final long PIXEL_OFFSET = 59654L;
/*     */   private static final long START_OFFSET = 160L;
/*     */   private static final long BASE_OFFSET = 352L;
/*     */   private long offset;
/*     */   private long diff;
/*     */   
/*     */   public BioRadGelReader() {
/*  66 */     super("Bio-Rad GEL", "1sc");
/*  67 */     this.domains = new String[] { "Gel/Blot Imaging" };
/*  68 */     this.suffixNecessary = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isThisType(RandomAccessInputStream stream) throws IOException {
/*  75 */     int blockLen = 2;
/*  76 */     if (!FormatTools.validStream(stream, 2, false)) return false; 
/*  77 */     return ((stream.readShort() & 0xFFFF) == 44975);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] openBytes(int no, byte[] buf, int x, int y, int w, int h) throws FormatException, IOException {
/*  86 */     FormatTools.checkPlaneParameters((IFormatReader)this, no, buf.length, x, y, w, h);
/*     */     
/*  88 */     int planeSize = FormatTools.getPlaneSize((IFormatReader)this);
/*     */     
/*  90 */     if (59654L + planeSize < this.in.length())
/*     */     
/*  92 */     { if (this.diff < 0L) {
/*  93 */         this.in.seek(227793L);
/*     */       }
/*  95 */       else if (this.diff == 0L) {
/*  96 */         this.in.seek(59654L);
/*     */       }
/*  98 */       else if (this.in.length() - planeSize > 61000L) {
/*  99 */         this.in.seek(59458L);
/*     */         
/* 101 */         while (!this.in.readString(3).equals("scn")) {
/* 102 */           this.in.seek(this.in.getFilePointer() - 2L);
/*     */         }
/*     */         
/* 105 */         this.in.skipBytes(91);
/* 106 */         int len = this.in.readShort();
/* 107 */         this.in.skipBytes(len);
/* 108 */         this.in.skipBytes(32);
/*     */       } else {
/* 110 */         this.in.seek(this.in.length() - planeSize);
/*     */       }  }
/* 112 */     else { this.in.seek(this.in.length() - planeSize); }
/*     */     
/* 114 */     int bpp = FormatTools.getBytesPerPixel(getPixelType());
/* 115 */     int pixel = bpp * getSizeC();
/*     */     
/* 117 */     this.in.skipBytes(pixel * getSizeX() * (getSizeY() - h - y));
/*     */     
/* 119 */     for (int row = h - 1; row >= 0; row--) {
/* 120 */       this.in.skipBytes(x * pixel);
/* 121 */       this.in.read(buf, row * w * pixel, w * pixel);
/* 122 */       this.in.skipBytes(pixel * (getSizeX() - w - x));
/*     */     } 
/*     */     
/* 125 */     return buf;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initFile(String id) throws FormatException, IOException {
/* 132 */     super.initFile(id);
/* 133 */     this.in = new RandomAccessInputStream(id);
/*     */     
/* 135 */     String check = this.in.readString(48);
/* 136 */     if (check.indexOf("Intel Format") != -1) {
/* 137 */       this.in.order(true);
/*     */     }
/*     */     
/* 140 */     this.in.seek(160L);
/*     */     
/* 142 */     boolean codeFound = false;
/* 143 */     int skip = 0;
/*     */     
/* 145 */     while (!codeFound) {
/* 146 */       short code = this.in.readShort();
/* 147 */       if (code == 129) codeFound = true; 
/* 148 */       short length = this.in.readShort();
/*     */       
/* 150 */       this.in.skipBytes(2 + 2 * length);
/* 151 */       if (codeFound) {
/* 152 */         skip = (this.in.readShort() & 0xFFFF) - 32;
/*     */         continue;
/*     */       } 
/* 155 */       if (length == 1) { this.in.skipBytes(12); continue; }
/* 156 */        if (length == 2) this.in.skipBytes(10);
/*     */     
/*     */     } 
/*     */     
/* 160 */     long baseFP = this.in.getFilePointer();
/* 161 */     this.diff = 352L - baseFP;
/* 162 */     skip = (int)(skip + this.diff);
/*     */     
/* 164 */     double physicalWidth = 0.0D, physicalHeight = 0.0D;
/* 165 */     if (getMetadataOptions().getMetadataLevel() != MetadataLevel.MINIMUM && 
/* 166 */       baseFP + skip - 8187L > 0L) {
/* 167 */       this.in.seek(baseFP + skip - 8187L);
/* 168 */       String str1 = this.in.readCString();
/* 169 */       this.in.skipBytes(8);
/* 170 */       this.in.readCString();
/* 171 */       this.in.skipBytes(8);
/* 172 */       String imageArea = this.in.readCString();
/*     */       
/* 174 */       imageArea = imageArea.substring(imageArea.indexOf(":") + 1).trim();
/* 175 */       int xIndex = imageArea.indexOf("x");
/* 176 */       if (xIndex > 0) {
/* 177 */         int space = imageArea.indexOf(" ");
/* 178 */         if (space >= 0) {
/* 179 */           String width = imageArea.substring(1, space);
/* 180 */           int nextSpace = imageArea.indexOf(" ", xIndex + 2);
/* 181 */           if (nextSpace > xIndex) {
/* 182 */             String height = imageArea.substring(xIndex + 1, nextSpace);
/* 183 */             physicalWidth = Double.parseDouble(width.trim()) * 1000.0D;
/* 184 */             physicalHeight = Double.parseDouble(height.trim()) * 1000.0D;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 191 */     this.in.seek(baseFP + skip - 298L);
/* 192 */     String date = this.in.readString(17);
/* 193 */     date = DateTools.formatDate(date, "dd-MMM-yyyy HH:mm");
/* 194 */     this.in.skipBytes(73);
/* 195 */     String scannerName = this.in.readCString();
/* 196 */     addGlobalMeta("Scanner name", scannerName);
/*     */     
/* 198 */     this.in.seek(baseFP + skip);
/*     */     
/* 200 */     (this.core[0]).sizeX = this.in.readShort() & 0xFFFF;
/* 201 */     (this.core[0]).sizeY = this.in.readShort() & 0xFFFF;
/* 202 */     if ((getSizeX() * getSizeY()) > this.in.length()) {
/* 203 */       this.in.order(true);
/* 204 */       this.in.seek(this.in.getFilePointer() - 4L);
/* 205 */       (this.core[0]).sizeX = this.in.readShort();
/* 206 */       (this.core[0]).sizeY = this.in.readShort();
/*     */     } 
/* 208 */     this.in.skipBytes(2);
/*     */     
/* 210 */     int bpp = this.in.readShort();
/* 211 */     (this.core[0]).pixelType = FormatTools.pixelTypeFromBytes(bpp, false, false);
/*     */     
/* 213 */     this.offset = this.in.getFilePointer();
/*     */     
/* 215 */     (this.core[0]).sizeZ = 1;
/* 216 */     (this.core[0]).sizeC = 1;
/* 217 */     (this.core[0]).sizeT = 1;
/* 218 */     (this.core[0]).imageCount = 1;
/* 219 */     (this.core[0]).dimensionOrder = "XYCZT";
/* 220 */     (this.core[0]).rgb = false;
/* 221 */     (this.core[0]).interleaved = false;
/* 222 */     (this.core[0]).indexed = false;
/* 223 */     (this.core[0]).littleEndian = this.in.isLittleEndian();
/*     */     
/* 225 */     MetadataStore store = makeFilterMetadata();
/* 226 */     MetadataTools.populatePixels(store, (IFormatReader)this);
/*     */     
/* 228 */     if (date != null) {
/* 229 */       store.setImageAcquisitionDate(new Timestamp(date), 0);
/*     */     }
/* 231 */     if (getMetadataOptions().getMetadataLevel() != MetadataLevel.MINIMUM) {
/* 232 */       PositiveFloat sizeX = FormatTools.getPhysicalSizeX(Double.valueOf(physicalWidth / getSizeX()));
/*     */       
/* 234 */       PositiveFloat sizeY = FormatTools.getPhysicalSizeY(Double.valueOf(physicalHeight / getSizeY()));
/*     */ 
/*     */       
/* 237 */       if (sizeX != null) {
/* 238 */         store.setPixelsPhysicalSizeX(sizeX, 0);
/*     */       }
/* 240 */       if (sizeY != null)
/* 241 */         store.setPixelsPhysicalSizeY(sizeY, 0); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/in/BioRadGelReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */