/*     */ package loci.formats.in;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import loci.common.RandomAccessInputStream;
/*     */ import loci.formats.FormatException;
/*     */ import loci.formats.FormatReader;
/*     */ import loci.formats.FormatTools;
/*     */ import loci.formats.IFormatReader;
/*     */ import loci.formats.MetadataTools;
/*     */ import loci.formats.meta.MetadataStore;
/*     */ import ome.xml.model.primitives.PositiveFloat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AliconaReader
/*     */   extends FormatReader
/*     */ {
/*     */   public static final String AL3D_MAGIC_STRING = "Alicona";
/*     */   private int textureOffset;
/*     */   private int numBytes;
/*     */   
/*     */   public AliconaReader() {
/*  64 */     super("Alicona AL3D", "al3d");
/*  65 */     this.domains = new String[] { "Scanning Electron Microscopy (SEM)" };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isThisType(RandomAccessInputStream stream) throws IOException {
/*  72 */     int blockLen = 16;
/*  73 */     if (!FormatTools.validStream(stream, 16, false)) return false; 
/*  74 */     return (stream.readString(16).indexOf("Alicona") >= 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] openBytes(int no, byte[] buf, int x, int y, int w, int h) throws FormatException, IOException {
/*  83 */     FormatTools.checkPlaneParameters((IFormatReader)this, no, buf.length, x, y, w, h);
/*     */     
/*  85 */     int pad = (8 - getSizeX() % 8) % 8;
/*     */     
/*  87 */     int planeSize = (getSizeX() + pad) * getSizeY();
/*     */     
/*  89 */     if (getPixelType() == 6) {
/*  90 */       this.in.seek(this.textureOffset);
/*  91 */       readPlane(this.in, x, y, w, h, buf);
/*  92 */       return buf;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  98 */     for (int i = 0; i < this.numBytes; i++) {
/*  99 */       this.in.seek((this.textureOffset + no * planeSize * (i + 1)));
/* 100 */       this.in.skipBytes(y * (getSizeX() + pad));
/* 101 */       if (getSizeX() == w) {
/* 102 */         this.in.read(buf, i * w * h, w * h);
/*     */       } else {
/*     */         
/* 105 */         for (int row = 0; row < h; row++) {
/* 106 */           this.in.skipBytes(x);
/* 107 */           this.in.read(buf, i * w * h + row * w, w);
/* 108 */           this.in.skipBytes(getSizeX() + pad - x - w);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 113 */     if (this.numBytes > 1) {
/* 114 */       byte[] tmp = new byte[buf.length];
/* 115 */       for (int j = 0; j < planeSize; j++) {
/* 116 */         for (int k = 0; k < this.numBytes; k++) {
/* 117 */           tmp[j * this.numBytes + k] = buf[planeSize * k + j];
/*     */         }
/*     */       } 
/* 120 */       System.arraycopy(tmp, 0, buf, 0, tmp.length);
/* 121 */       tmp = null;
/*     */     } 
/*     */     
/* 124 */     return buf;
/*     */   }
/*     */ 
/*     */   
/*     */   public void close(boolean fileOnly) throws IOException {
/* 129 */     super.close(fileOnly);
/* 130 */     if (!fileOnly) {
/* 131 */       this.textureOffset = this.numBytes = 0;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initFile(String id) throws FormatException, IOException {
/* 139 */     super.initFile(id);
/* 140 */     this.in = new RandomAccessInputStream(id);
/*     */ 
/*     */     
/* 143 */     LOGGER.info("Verifying Alicona format");
/* 144 */     String magicString = this.in.readString(17);
/* 145 */     if (!magicString.trim().equals("AliconaImaging")) {
/* 146 */       throw new FormatException("Invalid magic string : expected 'AliconaImaging', got " + magicString);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 153 */     LOGGER.info("Reading tags");
/*     */     
/* 155 */     int count = 2;
/*     */     
/* 157 */     boolean hasC = false;
/* 158 */     String voltage = null, magnification = null, workingDistance = null;
/* 159 */     String pntX = null, pntY = null;
/* 160 */     int depthOffset = 0;
/*     */     
/* 162 */     for (int i = 0; i < count; i++) {
/* 163 */       String key = this.in.readString(20).trim();
/* 164 */       String value = this.in.readString(30).trim();
/*     */       
/* 166 */       addGlobalMeta(key, value);
/* 167 */       this.in.skipBytes(2);
/*     */       
/* 169 */       if (key.equals("TagCount")) { count += Integer.parseInt(value); }
/* 170 */       else if (key.equals("Rows")) { (this.core[0]).sizeY = Integer.parseInt(value); }
/* 171 */       else if (key.equals("Cols")) { (this.core[0]).sizeX = Integer.parseInt(value); }
/* 172 */       else if (key.equals("NumberOfPlanes"))
/* 173 */       { (this.core[0]).imageCount = Integer.parseInt(value); }
/*     */       
/* 175 */       else if (key.equals("TextureImageOffset"))
/* 176 */       { this.textureOffset = Integer.parseInt(value); }
/*     */       
/* 178 */       else if (key.equals("TexturePtr") && !value.equals("7")) { hasC = true; }
/* 179 */       else if (key.equals("Voltage")) { voltage = value; }
/* 180 */       else if (key.equals("Magnification")) { magnification = value; }
/* 181 */       else if (key.equals("PixelSizeXMeter")) { pntX = value; }
/* 182 */       else if (key.equals("PixelSizeYMeter")) { pntY = value; }
/* 183 */       else if (key.equals("WorkingDistance")) { workingDistance = value; }
/* 184 */       else if (key.equals("DepthImageOffset"))
/* 185 */       { depthOffset = Integer.parseInt(value); }
/*     */     
/*     */     } 
/*     */     
/* 189 */     LOGGER.info("Populating metadata");
/*     */     
/* 191 */     if (this.textureOffset != 0) {
/* 192 */       this.numBytes = (int)(this.in.length() - this.textureOffset) / getSizeX() * getSizeY() * getImageCount();
/*     */ 
/*     */       
/* 195 */       (this.core[0]).sizeC = hasC ? 3 : 1;
/* 196 */       (this.core[0]).sizeZ = 1;
/* 197 */       (this.core[0]).sizeT = getImageCount() / getSizeC();
/*     */       
/* 199 */       (this.core[0]).pixelType = FormatTools.pixelTypeFromBytes(this.numBytes, false, false);
/*     */     }
/*     */     else {
/*     */       
/* 203 */       this.textureOffset = depthOffset;
/* 204 */       (this.core[0]).pixelType = 6;
/* 205 */       (this.core[0]).sizeC = 1;
/* 206 */       (this.core[0]).sizeZ = 1;
/* 207 */       (this.core[0]).sizeT = 1;
/* 208 */       (this.core[0]).imageCount = 1;
/*     */     } 
/*     */     
/* 211 */     (this.core[0]).rgb = false;
/* 212 */     (this.core[0]).interleaved = false;
/* 213 */     (this.core[0]).littleEndian = true;
/* 214 */     (this.core[0]).dimensionOrder = "XYCTZ";
/* 215 */     (this.core[0]).metadataComplete = true;
/* 216 */     (this.core[0]).indexed = false;
/* 217 */     (this.core[0]).falseColor = false;
/*     */     
/* 219 */     MetadataStore store = makeFilterMetadata();
/* 220 */     MetadataTools.populatePixels(store, (IFormatReader)this);
/*     */ 
/*     */ 
/*     */     
/* 224 */     if (getMetadataOptions().getMetadataLevel() != MetadataLevel.MINIMUM) {
/*     */       
/* 226 */       String instrumentID = MetadataTools.createLSID("Instrument", new int[] { 0 });
/* 227 */       store.setInstrumentID(instrumentID, 0);
/* 228 */       store.setImageInstrumentRef(instrumentID, 0);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 234 */       if (voltage != null) {
/* 235 */         store.setDetectorSettingsVoltage(new Double(voltage), 0, 0);
/*     */ 
/*     */         
/* 238 */         String detectorID = MetadataTools.createLSID("Detector", new int[] { 0, 0 });
/* 239 */         store.setDetectorID(detectorID, 0, 0);
/* 240 */         store.setDetectorSettingsID(detectorID, 0, 0);
/*     */ 
/*     */         
/* 243 */         store.setDetectorType(getDetectorType("Other"), 0, 0);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 248 */       if (magnification != null) {
/* 249 */         store.setObjectiveCalibratedMagnification(new Double(magnification), 0, 0);
/*     */       }
/*     */ 
/*     */       
/* 253 */       if (workingDistance != null) {
/* 254 */         store.setObjectiveWorkingDistance(new Double(workingDistance), 0, 0);
/*     */       }
/*     */       
/* 257 */       store.setObjectiveCorrection(getCorrection("Other"), 0, 0);
/* 258 */       store.setObjectiveImmersion(getImmersion("Other"), 0, 0);
/*     */ 
/*     */       
/* 261 */       String objectiveID = MetadataTools.createLSID("Objective", new int[] { 0, 0 });
/* 262 */       store.setObjectiveID(objectiveID, 0, 0);
/* 263 */       store.setObjectiveSettingsID(objectiveID, 0);
/*     */ 
/*     */ 
/*     */       
/* 267 */       if (pntX != null && pntY != null) {
/* 268 */         double pixelSizeX = Double.parseDouble(pntX) * 1000000.0D;
/* 269 */         double pixelSizeY = Double.parseDouble(pntY) * 1000000.0D;
/*     */         
/* 271 */         PositiveFloat sizeX = FormatTools.getPhysicalSizeX(Double.valueOf(pixelSizeX));
/* 272 */         PositiveFloat sizeY = FormatTools.getPhysicalSizeY(Double.valueOf(pixelSizeY));
/*     */         
/* 274 */         if (sizeX != null) {
/* 275 */           store.setPixelsPhysicalSizeX(sizeX, 0);
/*     */         }
/* 277 */         if (sizeY != null)
/* 278 */           store.setPixelsPhysicalSizeY(sizeY, 0); 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/in/AliconaReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */