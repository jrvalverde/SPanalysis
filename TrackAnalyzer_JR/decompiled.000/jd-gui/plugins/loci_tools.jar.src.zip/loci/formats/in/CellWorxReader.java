/*     */ package loci.formats.in;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Vector;
/*     */ import loci.common.DataTools;
/*     */ import loci.common.DateTools;
/*     */ import loci.common.Location;
/*     */ import loci.formats.CoreMetadata;
/*     */ import loci.formats.FormatException;
/*     */ import loci.formats.FormatReader;
/*     */ import loci.formats.FormatTools;
/*     */ import loci.formats.IFormatReader;
/*     */ import loci.formats.MetadataTools;
/*     */ import loci.formats.meta.IMetadata;
/*     */ import loci.formats.meta.MetadataConverter;
/*     */ import loci.formats.meta.MetadataRetrieve;
/*     */ import loci.formats.meta.MetadataStore;
/*     */ import loci.formats.ome.OMEXMLMetadata;
/*     */ import ome.xml.model.Image;
/*     */ import ome.xml.model.Instrument;
/*     */ import ome.xml.model.OME;
/*     */ import ome.xml.model.primitives.NonNegativeInteger;
/*     */ import ome.xml.model.primitives.PositiveFloat;
/*     */ import ome.xml.model.primitives.PositiveInteger;
/*     */ import ome.xml.model.primitives.Timestamp;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CellWorxReader
/*     */   extends FormatReader
/*     */ {
/*     */   private static final String DATE_FORMAT = "EEE MMM dd HH:mm:ss yyyy";
/*     */   private boolean[][] fieldMap;
/*     */   private String[][][] wellFiles;
/*     */   private String[][] logFiles;
/*  75 */   private int fieldCount = 0;
/*     */   
/*     */   private boolean doChannels = false;
/*     */   
/*     */   private String plateLogFile;
/*     */   
/*     */   private String zMapFile;
/*     */   private String lastFile;
/*     */   private IFormatReader lastReader;
/*  84 */   private HashMap<Integer, Timestamp> timestamps = new HashMap<Integer, Timestamp>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CellWorxReader() {
/*  91 */     super("CellWorx", new String[] { "pnl", "htd", "log" });
/*  92 */     this.domains = new String[] { "High-Content Screening (HCS)" };
/*  93 */     this.hasCompanionFiles = true;
/*  94 */     this.datasetDescription = "One .htd file plus one or more .pnl or .tif files and optionally one or more .log files";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isThisType(String name, boolean open) {
/* 102 */     if (checkSuffix(name, "pnl") || checkSuffix(name, "htd")) {
/* 103 */       return super.isThisType(name, open);
/*     */     }
/* 105 */     if (!open) return false;
/*     */     
/* 107 */     boolean foundHTD = false;
/*     */     
/* 109 */     Location current = (new Location(name)).getAbsoluteFile();
/* 110 */     Location parent = current.getParentFile();
/*     */     
/* 112 */     String htdName = current.getName();
/* 113 */     while (htdName.indexOf("_") > 0) {
/* 114 */       htdName = htdName.substring(0, htdName.lastIndexOf("_"));
/* 115 */       if ((new Location(parent, htdName + ".htd")).exists() || (new Location(parent, htdName + ".HTD")).exists())
/*     */       {
/*     */         
/* 118 */         return (checkSuffix(name, "log") || isGroupFiles());
/*     */       }
/*     */     } 
/* 121 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getSeriesUsedFiles(boolean noPixels) {
/* 126 */     FormatTools.assertId(this.currentId, true, 1);
/* 127 */     Vector<String> files = new Vector<String>();
/* 128 */     files.add(this.currentId);
/* 129 */     if (this.plateLogFile != null && (new Location(this.plateLogFile)).exists()) {
/* 130 */       files.add(this.plateLogFile);
/*     */     }
/* 132 */     if (this.zMapFile != null) files.add(this.zMapFile);
/*     */     
/* 134 */     int row = getWellRow(getSeries());
/* 135 */     int col = getWellColumn(getSeries());
/*     */     
/* 137 */     if ((new Location(this.logFiles[row][col])).exists()) {
/* 138 */       files.add(this.logFiles[row][col]);
/*     */     }
/* 140 */     if (!noPixels) {
/* 141 */       if (checkSuffix(this.wellFiles[row][col][0], "pnl")) {
/* 142 */         if ((new Location(this.wellFiles[row][col][0])).exists()) {
/* 143 */           files.add(this.wellFiles[row][col][0]);
/*     */         }
/*     */       } else {
/*     */         
/* 147 */         for (String f : this.wellFiles[row][col]) {
/* 148 */           if ((new Location(f)).exists()) {
/* 149 */             files.add(f);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     }
/* 154 */     return files.<String>toArray(new String[files.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] openBytes(int no, byte[] buf, int x, int y, int w, int h) throws FormatException, IOException {
/* 163 */     FormatTools.checkPlaneParameters((IFormatReader)this, no, buf.length, x, y, w, h);
/* 164 */     int fieldIndex = getSeries() % this.fieldCount;
/*     */     
/* 166 */     String file = getFile(getSeries(), no);
/* 167 */     if (file == null) {
/* 168 */       Arrays.fill(buf, (byte)0);
/* 169 */       return buf;
/*     */     } 
/*     */     
/* 172 */     if (this.lastFile == null || this.lastReader == null || !file.equals(this.lastFile) || this.lastReader.getCurrentFile() == null) {
/*     */ 
/*     */       
/* 175 */       if (this.lastReader != null) {
/* 176 */         this.lastReader.close();
/*     */       }
/*     */       try {
/* 179 */         this.lastReader = getReader(file);
/*     */       }
/* 181 */       catch (IOException e) {
/*     */         
/* 183 */         LOGGER.debug("", e);
/* 184 */         return buf;
/*     */       } 
/* 186 */       this.lastFile = file;
/*     */     } 
/*     */     
/* 189 */     int planeIndex = no;
/* 190 */     if (this.lastReader.getSeriesCount() == this.fieldCount) {
/* 191 */       this.lastReader.setSeries(fieldIndex);
/*     */     } else {
/*     */       
/* 194 */       int[] zct = getZCTCoords(no);
/* 195 */       planeIndex = zct[0];
/*     */     } 
/* 197 */     this.lastReader.openBytes(planeIndex, buf, x, y, w, h);
/* 198 */     return buf;
/*     */   }
/*     */ 
/*     */   
/*     */   public void close(boolean fileOnly) throws IOException {
/* 203 */     super.close(fileOnly);
/* 204 */     if (!fileOnly) {
/* 205 */       this.fieldMap = (boolean[][])null;
/* 206 */       this.wellFiles = (String[][][])null;
/* 207 */       this.logFiles = (String[][])null;
/* 208 */       this.fieldCount = 0;
/* 209 */       this.plateLogFile = null;
/* 210 */       this.zMapFile = null;
/* 211 */       this.lastFile = null;
/* 212 */       if (this.lastReader != null) {
/* 213 */         this.lastReader.close();
/*     */       }
/* 215 */       this.lastReader = null;
/* 216 */       this.doChannels = false;
/* 217 */       this.timestamps.clear();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initFile(String id) throws FormatException, IOException {
/* 228 */     LOGGER.info("Searching for .htd file");
/* 229 */     String base = (new Location(id)).getAbsolutePath();
/* 230 */     base = base.substring(0, base.lastIndexOf("_"));
/* 231 */     id = base + ".HTD";
/*     */     
/* 233 */     if (!checkSuffix(id, "htd") && !(new Location(id)).exists()) {
/* 234 */       Location parent = (new Location(id)).getAbsoluteFile().getParentFile();
/* 235 */       String[] list = parent.list(true);
/* 236 */       for (String f : list) {
/* 237 */         if (checkSuffix(f, "htd")) {
/* 238 */           id = (new Location(parent, f)).getAbsolutePath();
/* 239 */           LOGGER.info("Found .htd file {}", f);
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 246 */     super.initFile(id);
/*     */     
/* 248 */     String plateData = DataTools.readFile(id);
/* 249 */     String[] lines = plateData.split("\n");
/* 250 */     int xWells = 0, yWells = 0;
/* 251 */     int xFields = 0, yFields = 0;
/* 252 */     String[] wavelengths = null;
/* 253 */     int nTimepoints = 1;
/*     */ 
/*     */     
/* 256 */     for (String line : lines) {
/* 257 */       int split = line.indexOf("\",");
/* 258 */       if (split >= 1) {
/* 259 */         String key = line.substring(1, split).trim();
/* 260 */         String value = line.substring(split + 2).trim();
/*     */         
/* 262 */         if (key.equals("XWells")) {
/* 263 */           xWells = Integer.parseInt(value);
/*     */         }
/* 265 */         else if (key.equals("YWells")) {
/* 266 */           yWells = Integer.parseInt(value);
/* 267 */           this.wellFiles = new String[yWells][xWells][];
/* 268 */           this.logFiles = new String[yWells][xWells];
/*     */         }
/* 270 */         else if (key.startsWith("WellsSelection")) {
/* 271 */           int i1 = Integer.parseInt(key.substring(14)) - 1;
/* 272 */           String[] mapping = value.split(",");
/* 273 */           for (int col = 0; col < xWells; col++) {
/* 274 */             if ((new Boolean(mapping[col].trim())).booleanValue()) {
/* 275 */               this.wellFiles[i1][col] = new String[1];
/*     */             }
/*     */           }
/*     */         
/* 279 */         } else if (key.equals("XSites")) {
/* 280 */           xFields = Integer.parseInt(value);
/*     */         }
/* 282 */         else if (key.equals("YSites")) {
/* 283 */           yFields = Integer.parseInt(value);
/* 284 */           this.fieldMap = new boolean[yFields][xFields];
/*     */         }
/* 286 */         else if (key.equals("TimePoints")) {
/* 287 */           nTimepoints = Integer.parseInt(value);
/*     */         }
/* 289 */         else if (key.startsWith("SiteSelection")) {
/* 290 */           int i1 = Integer.parseInt(key.substring(13)) - 1;
/* 291 */           String[] mapping = value.split(",");
/* 292 */           for (int col = 0; col < xFields; col++) {
/* 293 */             this.fieldMap[i1][col] = (new Boolean(mapping[col].trim())).booleanValue();
/*     */           }
/*     */         }
/* 296 */         else if (key.equals("Waves")) {
/* 297 */           this.doChannels = (new Boolean(value.toLowerCase())).booleanValue();
/*     */         }
/* 299 */         else if (key.equals("NWavelengths")) {
/* 300 */           wavelengths = new String[Integer.parseInt(value)];
/*     */         }
/* 302 */         else if (key.startsWith("WaveName")) {
/* 303 */           int index = Integer.parseInt(key.substring(8)) - 1;
/* 304 */           wavelengths[index] = value.replaceAll("\"", "");
/*     */         } 
/*     */       } 
/*     */     } 
/* 308 */     for (int row = 0; row < this.fieldMap.length; row++) {
/* 309 */       for (int col = 0; col < (this.fieldMap[row]).length; col++) {
/* 310 */         if (this.fieldMap[row][col]) this.fieldCount++;
/*     */       
/*     */       } 
/*     */     } 
/*     */     
/* 315 */     String plateName = (new Location(id)).getAbsolutePath();
/* 316 */     plateName = plateName.substring(0, plateName.lastIndexOf(".")) + "_";
/* 317 */     int wellCount = 0;
/* 318 */     for (int j = 0; j < this.wellFiles.length; j++) {
/* 319 */       for (int col = 0; col < (this.wellFiles[j]).length; col++) {
/*     */         
/* 321 */         wellCount++;
/* 322 */         char rowLetter = (char)(j + 65);
/* 323 */         String str = plateName + rowLetter + String.format("%02d", new Object[] { Integer.valueOf(col + 1) });
/* 324 */         this.wellFiles[j][col][0] = str + ".pnl";
/* 325 */         this.logFiles[j][col] = str + "_scan.log";
/*     */         
/* 327 */         if (this.wellFiles[j][col] != null && !(new Location(this.wellFiles[j][col][0])).exists())
/*     */         {
/*     */           
/* 330 */           this.wellFiles[j][col] = getTiffFiles(plateName, rowLetter, col, wavelengths.length, nTimepoints);
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 337 */     this.plateLogFile = plateName + "scan.log";
/*     */     
/* 339 */     String serialNumber = null;
/*     */     
/* 341 */     if ((new Location(this.plateLogFile)).exists()) {
/* 342 */       String[] f = DataTools.readFile(this.plateLogFile).split("\n");
/* 343 */       for (String line : f) {
/* 344 */         if (line.trim().startsWith("Z Map File")) {
/* 345 */           String str1 = line.substring(line.indexOf(":") + 1);
/* 346 */           str1 = str1.substring(str1.lastIndexOf("/") + 1).trim();
/* 347 */           String parent = (new Location(id)).getAbsoluteFile().getParent();
/* 348 */           this.zMapFile = (new Location(parent, str1)).getAbsolutePath();
/*     */         }
/* 350 */         else if (line.trim().startsWith("Scanner SN")) {
/* 351 */           serialNumber = line.substring(line.indexOf(":") + 1).trim();
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 356 */     this.core = new CoreMetadata[this.fieldCount * wellCount];
/*     */     
/* 358 */     int planeIndex = 0;
/* 359 */     int seriesIndex = 0;
/* 360 */     String file = getFile(seriesIndex, planeIndex);
/* 361 */     while (!(new Location(file)).exists()) {
/* 362 */       if (planeIndex < nTimepoints * wavelengths.length) {
/* 363 */         planeIndex++;
/*     */       }
/* 365 */       else if (seriesIndex < this.core.length) {
/* 366 */         planeIndex = 0;
/* 367 */         seriesIndex++;
/*     */       } else {
/*     */         break;
/*     */       } 
/*     */       
/* 372 */       file = getFile(seriesIndex, planeIndex);
/*     */     } 
/* 374 */     IFormatReader pnl = getReader(file);
/*     */     
/* 376 */     for (int i = 0; i < this.core.length; i++) {
/* 377 */       setSeries(i);
/* 378 */       this.core[i] = new CoreMetadata();
/* 379 */       (this.core[i]).littleEndian = pnl.isLittleEndian();
/* 380 */       (this.core[i]).sizeX = pnl.getSizeX();
/* 381 */       (this.core[i]).sizeY = pnl.getSizeY();
/* 382 */       (this.core[i]).pixelType = pnl.getPixelType();
/* 383 */       (this.core[i]).sizeZ = 1;
/* 384 */       (this.core[i]).sizeT = nTimepoints;
/* 385 */       (this.core[i]).sizeC = wavelengths.length;
/* 386 */       (this.core[i]).imageCount = getSizeZ() * getSizeC() * getSizeT();
/* 387 */       (this.core[i]).dimensionOrder = "XYCZT";
/* 388 */       (this.core[i]).rgb = false;
/* 389 */       (this.core[i]).interleaved = pnl.isInterleaved();
/*     */     } 
/*     */     
/* 392 */     OMEXMLMetadata readerMetadata = (OMEXMLMetadata)pnl.getMetadataStore();
/* 393 */     OME root = (OME)readerMetadata.getRoot();
/* 394 */     Instrument instrument = root.getInstrument(0);
/* 395 */     List<Image> images = root.copyImageList();
/*     */     
/* 397 */     OME convertRoot = new OME();
/* 398 */     convertRoot.addInstrument(instrument);
/* 399 */     for (int k = 0; k < this.core.length / images.size(); k++) {
/* 400 */       for (Image img : images) {
/* 401 */         convertRoot.addImage(img);
/*     */       }
/*     */     } 
/* 404 */     IMetadata convertMetadata = MetadataTools.createOMEXMLMetadata();
/* 405 */     convertMetadata.setRoot(convertRoot);
/*     */     
/* 407 */     pnl.close();
/*     */     
/* 409 */     MetadataStore store = makeFilterMetadata();
/* 410 */     MetadataConverter.convertMetadata((MetadataRetrieve)convertMetadata, store);
/* 411 */     MetadataTools.populatePixels(store, (IFormatReader)this);
/*     */     
/* 413 */     String plateID = MetadataTools.createLSID("Plate", new int[] { 0 });
/*     */     
/* 415 */     Location plate = (new Location(id)).getAbsoluteFile().getParentFile();
/*     */     
/* 417 */     store.setPlateID(plateID, 0);
/* 418 */     store.setPlateName(plate.getName(), 0);
/* 419 */     for (int m = 0; m < this.core.length; m++) {
/* 420 */       store.setImageID(MetadataTools.createLSID("Image", new int[] { m }), m);
/*     */     } 
/*     */     
/* 423 */     String plateAcqID = MetadataTools.createLSID("PlateAcquisition", new int[] { 0, 0 });
/* 424 */     store.setPlateAcquisitionID(plateAcqID, 0, 0);
/*     */     
/* 426 */     PositiveInteger fieldCount = FormatTools.getMaxFieldCount(Integer.valueOf(this.fieldMap.length * (this.fieldMap[0]).length));
/*     */ 
/*     */     
/* 429 */     if (fieldCount != null) {
/* 430 */       store.setPlateAcquisitionMaximumFieldCount(fieldCount, 0, 0);
/*     */     }
/*     */     
/* 433 */     int nextImage = 0;
/* 434 */     for (int n = 0; n < this.wellFiles.length; n++) {
/* 435 */       for (int col = 0; col < (this.wellFiles[n]).length; col++) {
/* 436 */         int wellIndex = n * (this.wellFiles[n]).length + col;
/* 437 */         String wellID = MetadataTools.createLSID("Well", new int[] { 0, wellIndex });
/* 438 */         store.setWellID(wellID, 0, wellIndex);
/* 439 */         store.setWellColumn(new NonNegativeInteger(Integer.valueOf(col)), 0, wellIndex);
/* 440 */         store.setWellRow(new NonNegativeInteger(Integer.valueOf(n)), 0, wellIndex);
/*     */         
/* 442 */         int fieldIndex = 0;
/* 443 */         for (int fieldRow = 0; fieldRow < this.fieldMap.length; fieldRow++) {
/* 444 */           for (int fieldCol = 0; fieldCol < (this.fieldMap[fieldRow]).length; fieldCol++) {
/* 445 */             if (this.fieldMap[fieldRow][fieldCol] && this.wellFiles[n][col] != null) {
/* 446 */               String wellSampleID = MetadataTools.createLSID("WellSample", new int[] { 0, wellIndex, fieldIndex });
/*     */               
/* 448 */               store.setWellSampleID(wellSampleID, 0, wellIndex, fieldIndex);
/* 449 */               String imageID = MetadataTools.createLSID("Image", new int[] { nextImage });
/* 450 */               store.setWellSampleImageRef(imageID, 0, wellIndex, fieldIndex);
/* 451 */               store.setWellSampleIndex(new NonNegativeInteger(Integer.valueOf(nextImage)), 0, wellIndex, fieldIndex);
/*     */ 
/*     */               
/* 454 */               store.setPlateAcquisitionWellSampleRef(wellSampleID, 0, 0, nextImage);
/*     */ 
/*     */               
/* 457 */               String well = (char)(n + 65) + String.format("%02d", new Object[] { Integer.valueOf(col + 1) });
/* 458 */               store.setImageName("Well " + well + " Field #" + (fieldIndex + 1), nextImage);
/*     */               
/* 460 */               nextImage++;
/* 461 */               fieldIndex++;
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 468 */     if (getMetadataOptions().getMetadataLevel() != MetadataLevel.MINIMUM) {
/* 469 */       if (serialNumber != null) {
/* 470 */         store.setMicroscopeSerialNumber(serialNumber, 0);
/*     */       }
/*     */       
/* 473 */       for (int well = 0; well < wellCount; well++) {
/* 474 */         parseWellLogFile(well, store);
/*     */       }
/* 476 */       if (this.timestamps.size() > 0) {
/* 477 */         store.setPlateAcquisitionStartTime(this.timestamps.get(Integer.valueOf(0)), 0, 0);
/* 478 */         store.setPlateAcquisitionEndTime(this.timestamps.get(Integer.valueOf(this.timestamps.size() - 1)), 0, 0);
/*     */       } 
/*     */       
/* 481 */       for (int i1 = 0; i1 < this.core.length; i1++) {
/* 482 */         for (int c = 0; c < getSizeC(); c++) {
/* 483 */           if (c < wavelengths.length && wavelengths[c] != null) {
/* 484 */             store.setChannelName(wavelengths[c], i1, c);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int getWell(int seriesIndex) {
/* 495 */     int wellIndex = seriesIndex / this.fieldCount;
/* 496 */     int counter = -1;
/* 497 */     for (int row = 0; row < this.wellFiles.length; row++) {
/* 498 */       for (int col = 0; col < (this.wellFiles[row]).length; col++) {
/* 499 */         if (this.wellFiles[row][col] != null) counter++; 
/* 500 */         if (counter == wellIndex) return row * (this.wellFiles[row]).length + col; 
/*     */       } 
/*     */     } 
/* 503 */     return -1;
/*     */   }
/*     */ 
/*     */   
/*     */   private int getWellRow(int seriesIndex) {
/* 508 */     int well = getWell(seriesIndex);
/* 509 */     return well / (this.wellFiles[0]).length;
/*     */   }
/*     */ 
/*     */   
/*     */   private int getWellColumn(int seriesIndex) {
/* 514 */     int well = getWell(seriesIndex);
/* 515 */     return well % (this.wellFiles[0]).length;
/*     */   }
/*     */ 
/*     */   
/*     */   private String getFile(int seriesIndex, int no) {
/* 520 */     int row = getWellRow(seriesIndex);
/* 521 */     int col = getWellColumn(seriesIndex);
/* 522 */     int field = seriesIndex % this.fieldCount;
/* 523 */     if ((this.wellFiles[row][col]).length == 0) {
/* 524 */       return this.wellFiles[row][col][0];
/*     */     }
/*     */     
/* 527 */     int imageCount = (this.wellFiles[row][col]).length / this.fieldCount;
/* 528 */     if (field * imageCount + no < (this.wellFiles[row][col]).length) {
/* 529 */       return this.wellFiles[row][col][field * imageCount + no];
/*     */     }
/* 531 */     if (field < (this.wellFiles[row][col]).length) {
/* 532 */       return this.wellFiles[row][col][field];
/*     */     }
/* 534 */     if (imageCount == 0 && (this.wellFiles[row][col]).length == 1) {
/* 535 */       return this.wellFiles[row][col][0];
/*     */     }
/* 537 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void parseWellLogFile(int wellIndex, MetadataStore store) throws IOException {
/* 544 */     int seriesIndex = wellIndex * this.fieldCount;
/* 545 */     int row = getWellRow(seriesIndex);
/* 546 */     int col = getWellColumn(seriesIndex);
/* 547 */     int well = row * (this.wellFiles[0]).length + col;
/* 548 */     String logFile = this.logFiles[row][col];
/* 549 */     if (!(new Location(logFile)).exists()) {
/*     */       return;
/*     */     }
/* 552 */     LOGGER.debug("Parsing log file for well {}{}", Character.valueOf((char)(row + 65)), Integer.valueOf(col + 1));
/*     */     
/* 554 */     int oldSeries = getSeries();
/* 555 */     setSeries(seriesIndex);
/*     */     
/* 557 */     String data = DataTools.readFile(logFile);
/* 558 */     String[] lines = data.split("\n");
/* 559 */     for (String line : lines) {
/* 560 */       line = line.trim();
/* 561 */       int separator = line.indexOf(":");
/* 562 */       if (separator >= 0) {
/* 563 */         String key = line.substring(0, separator).trim();
/* 564 */         String value = line.substring(separator + 1).trim();
/*     */         
/* 566 */         addSeriesMeta(key, value);
/*     */         
/* 568 */         if (key.equals("Date")) {
/* 569 */           String date = DateTools.formatDate(value, "EEE MMM dd HH:mm:ss yyyy");
/* 570 */           for (int field = 0; field < this.fieldCount; field++) {
/* 571 */             if (date != null) {
/* 572 */               int imageIndex = seriesIndex + field;
/* 573 */               this.timestamps.put(Integer.valueOf(imageIndex), new Timestamp(date));
/* 574 */               store.setImageAcquisitionDate(this.timestamps.get(Integer.valueOf(imageIndex)), imageIndex);
/*     */             }
/*     */           
/*     */           }
/*     */         
/* 579 */         } else if (key.equals("Scan Origin")) {
/* 580 */           String[] axes = value.split(",");
/* 581 */           for (int fieldRow = 0; fieldRow < this.fieldMap.length; fieldRow++) {
/* 582 */             for (int fieldCol = 0; fieldCol < (this.fieldMap[fieldRow]).length; fieldCol++) {
/* 583 */               if (this.fieldMap[fieldRow][fieldCol] && this.wellFiles[row][col] != null) {
/* 584 */                 int field = fieldRow * (this.fieldMap[fieldRow]).length + fieldCol;
/* 585 */                 store.setWellSamplePositionX(new Double(axes[0]), 0, well, field);
/* 586 */                 store.setWellSamplePositionY(new Double(axes[1]), 0, well, field);
/*     */                 
/* 588 */                 addGlobalMeta("X position for position #" + (field + 1), axes[0]);
/* 589 */                 addGlobalMeta("Y position for position #" + (field + 1), axes[1]);
/*     */               }
/*     */             
/*     */             } 
/*     */           } 
/* 594 */         } else if (key.equals("Scan Area")) {
/* 595 */           int s = value.indexOf("x");
/* 596 */           if (s > 0) {
/* 597 */             int end = value.indexOf(" ", s + 2);
/* 598 */             Double xSize = new Double(value.substring(0, s).trim());
/* 599 */             Double ySize = new Double(value.substring(s + 1, end).trim());
/* 600 */             for (int field = 0; field < this.fieldCount; field++) {
/* 601 */               int index = seriesIndex + field;
/* 602 */               if (xSize.doubleValue() > 0.0D) {
/* 603 */                 store.setPixelsPhysicalSizeX(new PositiveFloat(Double.valueOf(xSize.doubleValue() / getSizeX())), index);
/*     */               }
/*     */               else {
/*     */                 
/* 607 */                 LOGGER.warn("Expected positive value for PhysicalSizeX; got {}", Double.valueOf(xSize.doubleValue() / getSizeX()));
/*     */               } 
/*     */               
/* 610 */               if (ySize.doubleValue() > 0.0D) {
/* 611 */                 store.setPixelsPhysicalSizeY(new PositiveFloat(Double.valueOf(ySize.doubleValue() / getSizeY())), index);
/*     */               }
/*     */               else {
/*     */                 
/* 615 */                 LOGGER.warn("Expected positive value for PhysicalSizeY; got {}", Double.valueOf(ySize.doubleValue() / getSizeY()));
/*     */               }
/*     */             
/*     */             }
/*     */           
/*     */           } 
/* 621 */         } else if (key.startsWith("Channel")) {
/* 622 */           int start = key.indexOf(" ") + 1;
/* 623 */           int end = key.indexOf(" ", start);
/* 624 */           if (end < 0) end = key.length(); 
/* 625 */           int index = Integer.parseInt(key.substring(start, end)) - 1;
/*     */           
/* 627 */           String[] tokens = value.split(",");
/* 628 */           for (String token : tokens) {
/* 629 */             token = token.trim();
/* 630 */             if (token.startsWith("gain")) {
/* 631 */               String instrumentID = MetadataTools.createLSID("Instrument", new int[] { 0 });
/* 632 */               Double gain = new Double(token.replaceAll("gain ", ""));
/* 633 */               String detectorID = MetadataTools.createLSID("Detector", new int[] { 0, 0 });
/*     */               
/* 635 */               store.setInstrumentID(instrumentID, 0);
/* 636 */               store.setDetectorID(detectorID, 0, 0);
/*     */               
/* 638 */               for (int field = 0; field < this.fieldCount; field++) {
/* 639 */                 store.setImageInstrumentRef(instrumentID, seriesIndex + field);
/* 640 */                 store.setDetectorSettingsGain(gain, seriesIndex + field, index);
/* 641 */                 store.setDetectorSettingsID(detectorID, seriesIndex + field, index);
/*     */               }
/*     */             
/*     */             }
/* 645 */             else if (token.startsWith("EX")) {
/* 646 */               int slash = token.indexOf("/");
/* 647 */               if (slash > 0) {
/* 648 */                 String ex = token.substring(0, slash).trim();
/* 649 */                 String em = token.substring(slash + 1).trim();
/*     */                 
/* 651 */                 if (ex.indexOf(" ") > 0) ex = ex.substring(ex.indexOf(" ") + 1); 
/* 652 */                 if (em.indexOf(" ") > 0) {
/* 653 */                   em = em.substring(em.indexOf(" ") + 1);
/* 654 */                   if (em.indexOf(" ") > 0) {
/* 655 */                     em = em.substring(0, em.indexOf(" "));
/*     */                   }
/*     */                 } 
/*     */                 
/* 659 */                 Integer emission = new Integer(em);
/* 660 */                 Integer excitation = new Integer(ex);
/*     */                 
/* 662 */                 for (int field = 0; field < this.fieldCount; field++) {
/* 663 */                   if (excitation.intValue() > 0) {
/* 664 */                     store.setChannelExcitationWavelength(new PositiveInteger(excitation), seriesIndex + field, index);
/*     */                   }
/*     */                   else {
/*     */                     
/* 668 */                     LOGGER.warn("Expected positive value for ExcitationWavelength; got {}", excitation);
/*     */                   } 
/*     */ 
/*     */                   
/* 672 */                   if (emission.intValue() > 0) {
/* 673 */                     store.setChannelEmissionWavelength(new PositiveInteger(emission), seriesIndex + field, index);
/*     */                   }
/*     */                   else {
/*     */                     
/* 677 */                     LOGGER.warn("Expected positive value for EmissionWavelength; got {}", emission);
/*     */                   } 
/*     */                 } 
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 688 */     setSeries(oldSeries);
/*     */   }
/*     */ 
/*     */   
/*     */   private IFormatReader getReader(String file) throws FormatException, IOException {
/*     */     MetamorphReader metamorphReader;
/* 694 */     DeltavisionReader deltavisionReader = new DeltavisionReader();
/* 695 */     if (checkSuffix(file, "tif")) {
/* 696 */       metamorphReader = new MetamorphReader();
/*     */     }
/* 698 */     IMetadata metadata = MetadataTools.createOMEXMLMetadata();
/* 699 */     metamorphReader.setMetadataStore((MetadataStore)metadata);
/* 700 */     metamorphReader.setId(file);
/* 701 */     return (IFormatReader)metamorphReader;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private String[] getTiffFiles(String plateName, char rowLetter, int col, int channels, int nTimepoints) {
/* 707 */     String base = plateName + rowLetter + String.format("%02d", new Object[] { Integer.valueOf(col + 1) });
/*     */     
/* 709 */     String[] files = new String[this.fieldCount * channels * nTimepoints];
/*     */     
/* 711 */     int nextFile = 0;
/* 712 */     for (int field = 0; field < this.fieldCount; field++) {
/* 713 */       for (int channel = 0; channel < channels; channel++) {
/* 714 */         for (int t = 0; t < nTimepoints; t++, nextFile++) {
/* 715 */           String file = base;
/* 716 */           if (this.fieldCount > 1) {
/* 717 */             file = file + "_s" + (field + 1);
/*     */           }
/* 719 */           if (this.doChannels || channels > 1) {
/* 720 */             file = file + "_w" + (channel + 1);
/*     */           }
/* 722 */           if (nTimepoints > 1) {
/* 723 */             file = file + "_t" + nTimepoints;
/*     */           }
/* 725 */           files[nextFile] = file + ".tif";
/*     */           
/* 727 */           if (!(new Location(files[nextFile])).exists()) {
/* 728 */             files[nextFile] = file + ".TIF";
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 734 */     boolean noneExist = true;
/* 735 */     for (String file : files) {
/* 736 */       if ((new Location(file)).exists()) {
/* 737 */         noneExist = false;
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/* 742 */     if (noneExist) {
/* 743 */       nextFile = 0;
/* 744 */       Location parent = (new Location(this.currentId)).getAbsoluteFile().getParentFile();
/*     */       
/* 746 */       String[] list = parent.list(true);
/* 747 */       Arrays.sort((Object[])list);
/* 748 */       for (String f : list) {
/* 749 */         if (checkSuffix(f, new String[] { "tif", "tiff", "pnl" })) {
/* 750 */           String path = (new Location(parent, f)).getAbsolutePath();
/* 751 */           if (path.startsWith(base) && path.indexOf("_thumb_") < 0) {
/* 752 */             files[nextFile++] = path;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 758 */     return files;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/in/CellWorxReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */