/*     */ package loci.formats.in;
/*     */ 
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.io.IOException;
/*     */ import loci.common.DataTools;
/*     */ import loci.formats.FormatException;
/*     */ import loci.formats.FormatReader;
/*     */ import loci.formats.FormatTools;
/*     */ import loci.formats.IFormatReader;
/*     */ import loci.formats.gui.AWTImageTools;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BIFormatReader
/*     */   extends FormatReader
/*     */ {
/*     */   public BIFormatReader(String name, String suffix) {
/*  64 */     super(name, suffix);
/*     */   }
/*     */ 
/*     */   
/*     */   public BIFormatReader(String name, String[] suffixes) {
/*  69 */     super(name, suffixes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] openBytes(int no, byte[] buf, int x, int y, int w, int h) throws FormatException, IOException {
/*     */     byte[] t;
/*     */     short[][] ts;
/*     */     int c;
/*  80 */     FormatTools.checkPlaneParameters((IFormatReader)this, no, buf.length, x, y, w, h);
/*     */     
/*  82 */     BufferedImage data = (BufferedImage)openPlane(no, x, y, w, h);
/*  83 */     switch (data.getColorModel().getComponentSize(0)) {
/*     */       case 8:
/*  85 */         t = AWTImageTools.getBytes(data, false);
/*  86 */         System.arraycopy(t, 0, buf, 0, Math.min(t.length, buf.length));
/*     */         break;
/*     */       case 16:
/*  89 */         ts = AWTImageTools.getShorts(data);
/*  90 */         for (c = 0; c < ts.length; c++) {
/*  91 */           int offset = c * (ts[c]).length * 2;
/*  92 */           for (int i = 0; i < (ts[c]).length && offset < buf.length; i++) {
/*  93 */             DataTools.unpackBytes(ts[c][i], buf, offset, 2, isLittleEndian());
/*  94 */             offset += 2;
/*     */           } 
/*     */         } 
/*     */         break;
/*     */     } 
/*  99 */     return buf;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> getNativeDataType() {
/* 106 */     return BufferedImage.class;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/in/BIFormatReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */