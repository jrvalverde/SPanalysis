/*     */ package loci.formats.in;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Vector;
/*     */ import loci.common.RandomAccessInputStream;
/*     */ import loci.formats.FormatException;
/*     */ import loci.formats.FormatReader;
/*     */ import loci.formats.FormatTools;
/*     */ import loci.formats.IFormatReader;
/*     */ import loci.formats.ImageTools;
/*     */ import loci.formats.MetadataTools;
/*     */ import loci.formats.UnsupportedCompressionException;
/*     */ import loci.formats.codec.BitBuffer;
/*     */ import loci.formats.codec.CodecOptions;
/*     */ import loci.formats.codec.JPEGCodec;
/*     */ import loci.formats.codec.MSRLECodec;
/*     */ import loci.formats.codec.MSVideoCodec;
/*     */ import loci.formats.meta.MetadataStore;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AVIReader
/*     */   extends FormatReader
/*     */ {
/*     */   public static final String AVI_MAGIC_STRING = "RIFF";
/*     */   private static final int MSRLE = 1;
/*     */   private static final int MS_VIDEO = 1296126531;
/*     */   private static final int JPEG = 1196444237;
/*     */   private static final int Y8 = 538982489;
/*  81 */   private static final byte[] MJPEG_HUFFMAN_TABLE = new byte[] { -1, -60, 1, -94, 0, 0, 1, 5, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 1, 0, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 16, 0, 2, 1, 3, 3, 2, 4, 3, 5, 5, 4, 4, 0, 0, 1, 125, 1, 2, 3, 0, 4, 17, 5, 18, 33, 49, 65, 6, 19, 81, 97, 7, 34, 113, 20, 50, -127, -111, -95, 8, 35, 66, -79, -63, 21, 82, -47, -16, 36, 51, 98, 114, -126, 9, 10, 22, 23, 24, 25, 26, 37, 38, 39, 40, 41, 42, 52, 53, 54, 55, 56, 57, 58, 67, 68, 69, 70, 71, 72, 73, 74, 83, 84, 85, 86, 87, 88, 89, 90, 99, 100, 101, 102, 103, 104, 105, 106, 115, 116, 117, 118, 119, 120, 121, 122, -125, -124, -123, -122, -121, -120, -119, -118, -110, -109, -108, -107, -106, -105, -104, -103, -102, -94, -93, -92, -91, -90, -89, -88, -87, -86, -78, -77, -76, -75, -74, -73, -72, -71, -70, -62, -61, -60, -59, -58, -57, -56, -55, -54, -46, -45, -44, -43, -42, -41, -40, -39, -38, -31, -30, -29, -28, -27, -26, -25, -24, -23, -22, -15, -14, -13, -12, -11, -10, -9, -8, -7, -6, 17, 0, 2, 1, 2, 4, 4, 3, 4, 7, 5, 4, 4, 0, 1, 2, 119, 0, 1, 2, 3, 17, 4, 5, 33, 49, 6, 18, 65, 81, 7, 97, 113, 19, 34, 50, -127, 8, 20, 66, -111, -95, -79, -63, 9, 35, 51, 82, -16, 21, 98, 114, -47, 10, 22, 36, 52, -31, 37, -15, 23, 24, 25, 26, 38, 39, 40, 41, 42, 53, 54, 55, 56, 57, 58, 67, 68, 69, 70, 71, 72, 73, 74, 83, 84, 85, 86, 87, 88, 89, 90, 99, 100, 101, 102, 103, 104, 105, 106, 115, 116, 117, 118, 119, 120, 121, 122, -126, -125, -124, -123, -122, -121, -120, -119, -118, -110, -109, -108, -107, -106, -105, -104, -103, -102, -94, -93, -92, -91, -90, -89, -88, -87, -86, -78, -77, -76, -75, -74, -73, -72, -71, -70, -62, -61, -60, -59, -58, -57, -56, -55, -54, -46, -45, -44, -43, -42, -41, -40, -39, -38, -30, -29, -28, -27, -26, -25, -24, -23, -22, -14, -13, -12, -11, -10, -9, -8, -7, -6 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Vector<Long> offsets;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Vector<Long> lengths;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String listString;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 143 */   private String type = "error";
/* 144 */   private String fcc = "error";
/* 145 */   private int size = -1;
/*     */   
/*     */   private long pos;
/*     */   private int bytesPerPlane;
/*     */   private int bmpColorsUsed;
/*     */   private int bmpWidth;
/*     */   private int bmpCompression;
/*     */   private int bmpScanLineSize;
/*     */   private short bmpBitsPerPixel;
/* 154 */   private byte[][] lut = (byte[][])null;
/*     */ 
/*     */   
/*     */   private byte[] lastImage;
/*     */   
/*     */   private int lastImageNo;
/*     */ 
/*     */   
/*     */   public AVIReader() {
/* 163 */     super("Audio Video Interleave", "avi");
/* 164 */     this.suffixNecessary = false;
/* 165 */     this.domains = new String[] { "Graphics" };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isThisType(RandomAccessInputStream stream) throws IOException {
/* 172 */     int blockLen = 12;
/* 173 */     if (!FormatTools.validStream(stream, 12, false)) return false; 
/* 174 */     String type = stream.readString(4);
/* 175 */     stream.skipBytes(4);
/* 176 */     String format = stream.readString(4);
/* 177 */     return (type.equals("RIFF") && format.equals("AVI "));
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[][] get8BitLookupTable() {
/* 182 */     FormatTools.assertId(this.currentId, true, 1);
/* 183 */     return isRGB() ? (byte[][])null : this.lut;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] openBytes(int no, byte[] buf, int x, int y, int w, int h) throws FormatException, IOException {
/* 192 */     FormatTools.checkPlaneParameters((IFormatReader)this, no, buf.length, x, y, w, h);
/*     */     
/* 194 */     int bytes = FormatTools.getBytesPerPixel(getPixelType());
/* 195 */     double p = this.bmpScanLineSize / this.bmpBitsPerPixel;
/* 196 */     int effectiveWidth = (int)(this.bmpScanLineSize / p);
/* 197 */     if (effectiveWidth == 0 || effectiveWidth < getSizeX()) {
/* 198 */       effectiveWidth = getSizeX();
/*     */     }
/*     */     
/* 201 */     long fileOff = ((Long)this.offsets.get(no)).longValue();
/* 202 */     long end = (no < this.offsets.size() - 1) ? ((Long)this.offsets.get(no + 1)).longValue() : this.in.length();
/* 203 */     long maxBytes = end - fileOff;
/* 204 */     this.in.seek(fileOff);
/*     */     
/* 206 */     if (this.bmpCompression != 0 && this.bmpCompression != 538982489) {
/* 207 */       byte[] b = uncompress(no, buf);
/* 208 */       int rowLen = FormatTools.getPlaneSize((IFormatReader)this, w, 1);
/* 209 */       int inputRowLen = FormatTools.getPlaneSize((IFormatReader)this, getSizeX(), 1);
/* 210 */       for (int row = 0; row < h; row++) {
/* 211 */         System.arraycopy(b, (row + y) * inputRowLen + x * bytes, buf, row * rowLen, rowLen);
/*     */       }
/*     */       
/* 214 */       b = null;
/* 215 */       return buf;
/*     */     } 
/*     */     
/* 218 */     if (this.bmpBitsPerPixel < 8) {
/* 219 */       int rawSize = FormatTools.getPlaneSize((IFormatReader)this, effectiveWidth, getSizeY());
/* 220 */       rawSize /= 8 / this.bmpBitsPerPixel;
/*     */       
/* 222 */       byte[] b = new byte[rawSize];
/*     */       
/* 224 */       int len = rawSize / getSizeY();
/* 225 */       this.in.read(b);
/*     */       
/* 227 */       BitBuffer bb = new BitBuffer(b);
/* 228 */       bb.skipBits((this.bmpBitsPerPixel * len * (getSizeY() - h - y)));
/*     */       
/* 230 */       for (int row = h; row >= y; row--) {
/* 231 */         bb.skipBits((this.bmpBitsPerPixel * x));
/* 232 */         for (int col = 0; col < len; col++) {
/* 233 */           buf[(row - y) * len + col] = (byte)bb.getBits(this.bmpBitsPerPixel);
/*     */         }
/* 235 */         bb.skipBits((this.bmpBitsPerPixel * (getSizeX() - w - x)));
/*     */       } 
/*     */       
/* 238 */       return buf;
/*     */     } 
/*     */     
/* 241 */     int pad = this.bmpScanLineSize / getRGBChannelCount() - getSizeX() * bytes;
/* 242 */     int scanline = w * bytes * (isInterleaved() ? getRGBChannelCount() : 1);
/*     */     
/* 244 */     this.in.skipBytes((getSizeX() + pad) * this.bmpBitsPerPixel / 8 * (getSizeY() - h - y));
/*     */     
/* 246 */     if (getSizeX() == w && pad == 0) {
/* 247 */       for (int row = 0; row < h; row++) {
/* 248 */         int outputRow = (this.bmpCompression == 538982489) ? row : (h - row - 1);
/* 249 */         this.in.read(buf, outputRow * scanline, scanline);
/*     */       } 
/*     */ 
/*     */       
/* 253 */       if (this.bmpBitsPerPixel == 24 || this.bmpBitsPerPixel == 32) {
/* 254 */         for (int i = 0; i < buf.length / getRGBChannelCount(); i++) {
/* 255 */           byte r = buf[i * getRGBChannelCount() + 2];
/* 256 */           buf[i * getRGBChannelCount() + 2] = buf[i * getRGBChannelCount()];
/* 257 */           buf[i * getRGBChannelCount()] = r;
/*     */         } 
/*     */       }
/*     */     } else {
/*     */       
/* 262 */       int skip = FormatTools.getPlaneSize((IFormatReader)this, getSizeX() - w - x + pad, 1);
/* 263 */       if (((getSizeX() + pad) * getSizeY() * getRGBChannelCount()) > maxBytes) {
/* 264 */         skip /= getRGBChannelCount();
/*     */       }
/* 266 */       for (int i = h - 1; i >= 0; i--) {
/* 267 */         this.in.skipBytes(x * this.bmpBitsPerPixel / 8);
/* 268 */         this.in.read(buf, i * scanline, scanline);
/* 269 */         if (this.bmpBitsPerPixel == 24) {
/* 270 */           for (int j = 0; j < w; j++) {
/* 271 */             byte r = buf[i * scanline + j * 3 + 2];
/* 272 */             buf[i * scanline + j * 3 + 2] = buf[i * scanline + j * 3];
/* 273 */             buf[i * scanline + j * 3] = r;
/*     */           } 
/*     */         }
/* 276 */         if (i > 0) this.in.skipBytes(skip);
/*     */       
/*     */       } 
/*     */     } 
/* 280 */     if (this.bmpBitsPerPixel == 16 && isRGB())
/*     */     {
/* 282 */       ImageTools.bgrToRgb(buf, isInterleaved(), 2, getRGBChannelCount());
/*     */     }
/*     */     
/* 285 */     return buf;
/*     */   }
/*     */ 
/*     */   
/*     */   public void close(boolean fileOnly) throws IOException {
/* 290 */     super.close(fileOnly);
/* 291 */     if (!fileOnly) {
/* 292 */       this.listString = null;
/* 293 */       this.offsets = null;
/* 294 */       this.lengths = null;
/* 295 */       this.type = null;
/* 296 */       this.fcc = null;
/* 297 */       this.size = -1;
/* 298 */       this.pos = 0L;
/* 299 */       this.bytesPerPlane = 0;
/* 300 */       this.bmpColorsUsed = this.bmpWidth = this.bmpCompression = this.bmpScanLineSize = 0;
/* 301 */       this.bmpBitsPerPixel = 0;
/* 302 */       this.lut = (byte[][])null;
/* 303 */       this.lastImage = null;
/* 304 */       this.lastImageNo = -1;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initFile(String id) throws FormatException, IOException {
/* 312 */     super.initFile(id);
/* 313 */     this.in = new RandomAccessInputStream(id);
/* 314 */     this.in.order(true);
/*     */     
/* 316 */     LOGGER.info("Verifying AVI format");
/*     */     
/* 318 */     this.offsets = new Vector<Long>();
/* 319 */     this.lengths = new Vector<Long>();
/* 320 */     this.lastImageNo = -1;
/*     */     
/* 322 */     while (this.in.getFilePointer() < this.in.length() - 8L) {
/* 323 */       readChunk();
/*     */     }
/* 325 */     LOGGER.info("Populating metadata");
/*     */     
/* 327 */     (this.core[0]).imageCount = this.offsets.size();
/* 328 */     (this.core[0]).sizeZ = 1;
/* 329 */     (this.core[0]).sizeT = getImageCount();
/* 330 */     (this.core[0]).littleEndian = true;
/* 331 */     (this.core[0]).interleaved = (this.bmpBitsPerPixel != 16);
/*     */     
/* 333 */     addGlobalMeta("Compression", getCodecName(this.bmpCompression));
/*     */     
/* 335 */     if (this.bmpCompression == 1196444237) {
/* 336 */       long fileOff = ((Long)this.offsets.get(0)).longValue();
/* 337 */       this.in.seek(fileOff);
/* 338 */       int nBytes = (uncompress(0, (byte[])null)).length / getSizeX() * getSizeY();
/*     */       
/* 340 */       if (this.bmpBitsPerPixel == 16) {
/* 341 */         nBytes /= 2;
/*     */       }
/* 343 */       (this.core[0]).sizeC = nBytes;
/* 344 */       (this.core[0]).rgb = (getSizeC() > 1);
/*     */     }
/* 346 */     else if (this.bmpBitsPerPixel == 32) {
/* 347 */       (this.core[0]).sizeC = 4;
/* 348 */       (this.core[0]).rgb = true;
/*     */     }
/* 350 */     else if (this.bytesPerPlane == 0 || this.bmpBitsPerPixel == 24) {
/* 351 */       (this.core[0]).rgb = (this.bmpBitsPerPixel > 8 || (this.bmpCompression != 0 && this.lut == null));
/* 352 */       (this.core[0]).sizeC = isRGB() ? 3 : 1;
/*     */     }
/* 354 */     else if (this.bmpCompression == 1296126531) {
/* 355 */       (this.core[0]).sizeC = 3;
/* 356 */       (this.core[0]).rgb = true;
/*     */     } else {
/*     */       
/* 359 */       (this.core[0]).sizeC = this.bytesPerPlane / getSizeX() * getSizeY() * this.bmpBitsPerPixel / 8;
/*     */       
/* 361 */       (this.core[0]).rgb = (getSizeC() > 1);
/*     */     } 
/* 363 */     (this.core[0]).dimensionOrder = isRGB() ? "XYCTZ" : "XYTCZ";
/* 364 */     (this.core[0]).falseColor = false;
/* 365 */     (this.core[0]).metadataComplete = true;
/* 366 */     (this.core[0]).indexed = (this.lut != null && !isRGB());
/*     */     
/* 368 */     if (this.bmpBitsPerPixel <= 8)
/* 369 */     { (this.core[0]).pixelType = 1;
/* 370 */       (this.core[0]).bitsPerPixel = this.bmpBitsPerPixel; }
/*     */     
/* 372 */     else if (this.bmpBitsPerPixel == 16) { (this.core[0]).pixelType = 3; }
/* 373 */     else if (this.bmpBitsPerPixel == 24 || this.bmpBitsPerPixel == 32)
/* 374 */     { (this.core[0]).pixelType = 1; }
/*     */     else
/*     */     
/* 377 */     { throw new FormatException("Unknown matching for pixel bit width of: " + this.bmpBitsPerPixel); }
/*     */ 
/*     */ 
/*     */     
/* 381 */     if (this.bmpCompression != 0) (this.core[0]).pixelType = 1;
/*     */     
/* 383 */     int effectiveWidth = this.bmpScanLineSize / this.bmpBitsPerPixel / 8;
/* 384 */     if (effectiveWidth == 0) {
/* 385 */       effectiveWidth = getSizeX();
/*     */     }
/* 387 */     if (effectiveWidth < getSizeX()) {
/* 388 */       (this.core[0]).sizeX = effectiveWidth;
/*     */     }
/*     */     
/* 391 */     MetadataStore store = makeFilterMetadata();
/* 392 */     MetadataTools.populatePixels(store, (IFormatReader)this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] uncompress(int no, byte[] buf) throws FormatException, IOException {
/* 400 */     if (this.lastImageNo == no) {
/* 401 */       buf = this.lastImage;
/* 402 */       return buf;
/*     */     } 
/* 404 */     CodecOptions options = new CodecOptions();
/* 405 */     options.width = getSizeX();
/* 406 */     options.height = getSizeY();
/* 407 */     options.previousImage = (this.lastImageNo == no - 1) ? this.lastImage : null;
/*     */     
/* 409 */     if (options.previousImage == null && this.bmpCompression != 1196444237) {
/* 410 */       while (this.lastImageNo < no - 1) {
/* 411 */         openBytes(this.lastImageNo + 1, buf);
/*     */       }
/* 413 */       options.previousImage = this.lastImage;
/*     */     } 
/*     */     
/* 416 */     long fileOff = ((Long)this.offsets.get(no)).longValue();
/* 417 */     this.in.seek(fileOff);
/*     */     
/* 419 */     options.bitsPerSample = this.bmpBitsPerPixel;
/* 420 */     options.interleaved = isInterleaved();
/* 421 */     options.littleEndian = isLittleEndian();
/*     */     
/* 423 */     if (this.bmpCompression == 1) {
/* 424 */       byte[] b = new byte[(int)((Long)this.lengths.get(no)).longValue()];
/* 425 */       this.in.read(b);
/* 426 */       MSRLECodec codec = new MSRLECodec();
/* 427 */       buf = codec.decompress(b, options);
/* 428 */       this.lastImage = buf;
/* 429 */       this.lastImageNo = no;
/*     */     }
/* 431 */     else if (this.bmpCompression == 1296126531) {
/* 432 */       MSVideoCodec codec = new MSVideoCodec();
/* 433 */       buf = codec.decompress(this.in, options);
/* 434 */       this.lastImage = buf;
/* 435 */       this.lastImageNo = no;
/*     */     }
/* 437 */     else if (this.bmpCompression == 1196444237) {
/* 438 */       JPEGCodec codec = new JPEGCodec();
/*     */       
/* 440 */       byte[] plane = new byte[(int)((Long)this.lengths.get(no)).longValue()];
/* 441 */       this.in.read(plane);
/*     */       
/* 443 */       boolean motionJPEG = (new String(plane, 6, 4, "UTF-8")).equals("AVI1");
/*     */ 
/*     */       
/* 446 */       if (motionJPEG) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 451 */         byte[] fixedPlane = new byte[plane.length + MJPEG_HUFFMAN_TABLE.length];
/* 452 */         System.arraycopy(plane, 0, fixedPlane, 0, 20);
/* 453 */         System.arraycopy(MJPEG_HUFFMAN_TABLE, 0, fixedPlane, 20, MJPEG_HUFFMAN_TABLE.length);
/*     */         
/* 455 */         System.arraycopy(plane, 20, fixedPlane, 20 + MJPEG_HUFFMAN_TABLE.length, plane.length - 20);
/*     */ 
/*     */         
/* 458 */         plane = fixedPlane;
/*     */       } 
/*     */       
/* 461 */       buf = codec.decompress(plane, options);
/*     */       
/* 463 */       if (motionJPEG)
/*     */       {
/*     */ 
/*     */         
/* 467 */         for (int i = 0; i < buf.length; i += 3) {
/* 468 */           int y = buf[i] & 0xFF;
/* 469 */           int cb = (buf[i + 1] & 0xFF) - 128;
/* 470 */           int cr = (buf[i + 2] & 0xFF) - 128;
/*     */           
/* 472 */           int red = (int)(y + 1.402D * cr);
/* 473 */           int green = (int)(y - 0.34414D * cb - 0.71414D * cr);
/* 474 */           int blue = (int)(y + 1.772D * cb);
/*     */           
/* 476 */           if (red < 0) {
/* 477 */             red = 0;
/*     */           }
/* 479 */           else if (red > 255) {
/* 480 */             red = 255;
/*     */           } 
/* 482 */           if (green < 0) {
/* 483 */             green = 0;
/*     */           }
/* 485 */           else if (green > 255) {
/* 486 */             green = 255;
/*     */           } 
/* 488 */           if (blue < 0) {
/* 489 */             blue = 0;
/*     */           }
/* 491 */           else if (blue > 255) {
/* 492 */             blue = 255;
/*     */           } 
/*     */           
/* 495 */           buf[i] = (byte)(red & 0xFF);
/* 496 */           buf[i + 1] = (byte)(green & 0xFF);
/* 497 */           buf[i + 2] = (byte)(blue & 0xFF);
/*     */ 
/*     */ 
/*     */         
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       }
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */ 
/*     */       
/* 515 */       throw new UnsupportedCompressionException(this.bmpCompression + " not supported");
/*     */     } 
/*     */     
/* 518 */     return buf;
/*     */   }
/*     */   
/*     */   private void readChunkHeader() throws IOException {
/* 522 */     readTypeAndSize();
/* 523 */     this.fcc = this.in.readString(4);
/*     */   }
/*     */   
/*     */   private void readTypeAndSize() throws IOException {
/* 527 */     this.type = this.in.readString(4);
/* 528 */     this.size = this.in.readInt();
/*     */   }
/*     */   
/*     */   private void readChunk() throws FormatException, IOException {
/* 532 */     readChunkHeader();
/*     */     
/* 534 */     if (this.type.equals("RIFF")) {
/* 535 */       if (!this.fcc.startsWith("AVI")) {
/* 536 */         throw new FormatException("Sorry, AVI RIFF format not found.");
/*     */       }
/*     */     } else {
/* 539 */       if (this.in.getFilePointer() == 12L) {
/* 540 */         throw new FormatException("Not an AVI file");
/*     */       }
/*     */       
/* 543 */       if (this.in.getFilePointer() + this.size - 4L <= this.in.length()) {
/* 544 */         this.in.skipBytes(this.size - 4);
/*     */       }
/*     */       
/*     */       return;
/*     */     } 
/* 549 */     this.pos = this.in.getFilePointer();
/* 550 */     long spos = this.pos;
/*     */     
/* 552 */     LOGGER.info("Searching for image data");
/*     */     
/* 554 */     while (this.in.length() - this.in.getFilePointer() > 4L) {
/* 555 */       this.listString = this.in.readString(4);
/* 556 */       if (this.listString.equals("RIFF")) {
/* 557 */         this.in.seek(this.in.getFilePointer() - 4L);
/*     */         return;
/*     */       } 
/* 560 */       this.in.seek(this.pos);
/* 561 */       if (this.listString.equals(" JUN")) {
/* 562 */         this.in.skipBytes(1);
/* 563 */         this.pos++;
/*     */       } 
/*     */       
/* 566 */       if (this.listString.equals("JUNK")) {
/* 567 */         readTypeAndSize();
/*     */         
/* 569 */         if (this.type.equals("JUNK")) {
/* 570 */           this.in.skipBytes(this.size);
/*     */         }
/*     */       }
/* 573 */       else if (this.listString.equals("LIST")) {
/* 574 */         spos = this.in.getFilePointer();
/* 575 */         readChunkHeader();
/*     */         
/* 577 */         this.in.seek(spos);
/* 578 */         if (this.fcc.equals("hdrl")) {
/* 579 */           readChunkHeader();
/*     */           
/* 581 */           if (this.type.equals("LIST") && 
/* 582 */             this.fcc.equals("hdrl")) {
/* 583 */             readTypeAndSize();
/* 584 */             if (this.type.equals("avih")) {
/* 585 */               spos = this.in.getFilePointer();
/*     */               
/* 587 */               addGlobalMeta("Microseconds per frame", this.in.readInt());
/* 588 */               addGlobalMeta("Max. bytes per second", this.in.readInt());
/*     */               
/* 590 */               this.in.skipBytes(8);
/*     */               
/* 592 */               addGlobalMeta("Total frames", this.in.readInt());
/* 593 */               addGlobalMeta("Initial frames", this.in.readInt());
/*     */               
/* 595 */               this.in.skipBytes(8);
/* 596 */               (this.core[0]).sizeX = this.in.readInt();
/*     */               
/* 598 */               addGlobalMeta("Frame height", this.in.readInt());
/* 599 */               addGlobalMeta("Scale factor", this.in.readInt());
/* 600 */               addGlobalMeta("Frame rate", this.in.readInt());
/* 601 */               addGlobalMeta("Start time", this.in.readInt());
/* 602 */               addGlobalMeta("Length", this.in.readInt());
/*     */               
/* 604 */               addGlobalMeta("Frame width", getSizeX());
/*     */               
/* 606 */               if (spos + this.size <= this.in.length()) {
/* 607 */                 this.in.seek(spos + this.size);
/*     */               }
/*     */             }
/*     */           
/*     */           }
/*     */         
/* 613 */         } else if (this.fcc.equals("strl")) {
/* 614 */           long startPos = this.in.getFilePointer();
/* 615 */           long streamSize = this.size;
/*     */           
/* 617 */           readChunkHeader();
/*     */           
/* 619 */           if (this.type.equals("LIST")) {
/* 620 */             if (this.fcc.equals("strl")) {
/* 621 */               readTypeAndSize();
/*     */               
/* 623 */               if (this.type.equals("strh")) {
/* 624 */                 spos = this.in.getFilePointer();
/* 625 */                 this.in.skipBytes(40);
/*     */                 
/* 627 */                 addGlobalMeta("Stream quality", this.in.readInt());
/* 628 */                 this.bytesPerPlane = this.in.readInt();
/* 629 */                 addGlobalMeta("Stream sample size", this.bytesPerPlane);
/*     */                 
/* 631 */                 if (spos + this.size <= this.in.length()) {
/* 632 */                   this.in.seek(spos + this.size);
/*     */                 }
/*     */               } 
/*     */               
/* 636 */               readTypeAndSize();
/* 637 */               if (this.type.equals("strf")) {
/* 638 */                 spos = this.in.getFilePointer();
/*     */                 
/* 640 */                 if (getSizeY() != 0) {
/* 641 */                   this.in.skipBytes(this.size);
/* 642 */                   readTypeAndSize();
/* 643 */                   while (this.type.equals("indx")) {
/* 644 */                     this.in.skipBytes(this.size);
/* 645 */                     readTypeAndSize();
/*     */                   } 
/* 647 */                   this.pos = this.in.getFilePointer() - 4L;
/* 648 */                   this.in.seek(this.pos - 4L);
/*     */                   
/*     */                   continue;
/*     */                 } 
/* 652 */                 this.in.skipBytes(4);
/* 653 */                 this.bmpWidth = this.in.readInt();
/* 654 */                 (this.core[0]).sizeY = this.in.readInt();
/* 655 */                 this.in.skipBytes(2);
/* 656 */                 this.bmpBitsPerPixel = this.in.readShort();
/* 657 */                 this.bmpCompression = this.in.readInt();
/* 658 */                 this.in.skipBytes(4);
/*     */                 
/* 660 */                 addGlobalMeta("Horizontal resolution", this.in.readInt());
/* 661 */                 addGlobalMeta("Vertical resolution", this.in.readInt());
/*     */                 
/* 663 */                 this.bmpColorsUsed = this.in.readInt();
/* 664 */                 this.in.skipBytes(4);
/*     */                 
/* 666 */                 addGlobalMeta("Bitmap compression value", this.bmpCompression);
/* 667 */                 addGlobalMeta("Number of colors used", this.bmpColorsUsed);
/* 668 */                 addGlobalMeta("Bits per pixel", this.bmpBitsPerPixel);
/*     */ 
/*     */                 
/* 671 */                 int npad = this.bmpWidth % 4;
/* 672 */                 if (npad > 0) npad = 4 - npad;
/*     */                 
/* 674 */                 this.bmpScanLineSize = (this.bmpWidth + npad) * this.bmpBitsPerPixel / 8;
/*     */                 
/* 676 */                 int bmpActualColorsUsed = 0;
/* 677 */                 if (this.bmpColorsUsed != 0) {
/* 678 */                   bmpActualColorsUsed = this.bmpColorsUsed;
/*     */                 }
/* 680 */                 else if (this.bmpBitsPerPixel < 16) {
/*     */ 
/*     */                   
/* 683 */                   bmpActualColorsUsed = 1 << this.bmpBitsPerPixel;
/* 684 */                   this.bmpColorsUsed = bmpActualColorsUsed;
/*     */                 } 
/*     */                 
/* 687 */                 if (this.bmpCompression != 1 && this.bmpCompression != 0 && this.bmpCompression != 1296126531 && this.bmpCompression != 1196444237 && this.bmpCompression != 538982489)
/*     */                 {
/*     */ 
/*     */                   
/* 691 */                   throw new UnsupportedCompressionException(this.bmpCompression + " not supported");
/*     */                 }
/*     */ 
/*     */                 
/* 695 */                 if (this.bmpBitsPerPixel != 4 && this.bmpBitsPerPixel != 8 && this.bmpBitsPerPixel != 24 && this.bmpBitsPerPixel != 16 && this.bmpBitsPerPixel != 32)
/*     */                 {
/*     */ 
/*     */                   
/* 699 */                   throw new FormatException(this.bmpBitsPerPixel + " bits per pixel not supported");
/*     */                 }
/*     */ 
/*     */                 
/* 703 */                 if (bmpActualColorsUsed != 0) {
/*     */                   
/* 705 */                   this.lut = new byte[3][this.bmpColorsUsed];
/*     */                   
/* 707 */                   for (int i = 0; i < this.bmpColorsUsed; i++) {
/* 708 */                     if (this.bmpCompression != 538982489) {
/* 709 */                       this.lut[2][i] = this.in.readByte();
/* 710 */                       this.lut[1][i] = this.in.readByte();
/* 711 */                       this.lut[0][i] = this.in.readByte();
/* 712 */                       this.in.skipBytes(1);
/*     */                     } else {
/*     */                       
/* 715 */                       this.lut[0][i] = (byte)i;
/* 716 */                       this.lut[1][i] = (byte)i;
/* 717 */                       this.lut[2][i] = (byte)i;
/*     */                     } 
/*     */                   } 
/*     */                 } 
/*     */                 
/* 722 */                 this.in.seek(spos + this.size);
/*     */               } 
/*     */             } 
/*     */             
/* 726 */             spos = this.in.getFilePointer();
/* 727 */             readTypeAndSize();
/* 728 */             if (this.type.equals("strd")) {
/* 729 */               this.in.skipBytes(this.size);
/*     */             } else {
/*     */               
/* 732 */               this.in.seek(spos);
/*     */             } 
/*     */             
/* 735 */             spos = this.in.getFilePointer();
/* 736 */             readTypeAndSize();
/* 737 */             if (this.type.equals("strn") || this.type.equals("indx")) {
/* 738 */               this.in.skipBytes(this.size);
/*     */             } else {
/*     */               
/* 741 */               this.in.seek(spos);
/*     */             } 
/*     */           } 
/*     */           
/* 745 */           if (startPos + streamSize + 8L <= this.in.length()) {
/* 746 */             this.in.seek(startPos + 8L + streamSize);
/*     */           }
/*     */         }
/* 749 */         else if (this.fcc.equals("movi")) {
/* 750 */           readChunkHeader();
/*     */           
/* 752 */           if (this.type.equals("LIST") && 
/* 753 */             this.fcc.equals("movi")) {
/* 754 */             spos = this.in.getFilePointer();
/* 755 */             if (spos >= this.in.length() - 12L)
/* 756 */               break;  readChunkHeader();
/* 757 */             if (!this.type.equals("LIST") || (!this.fcc.equals("rec ") && !this.fcc.equals("movi")))
/*     */             {
/*     */               
/* 760 */               this.in.seek(spos);
/*     */             }
/*     */             
/* 763 */             spos = this.in.getFilePointer();
/* 764 */             boolean end = false;
/* 765 */             while (!end) {
/* 766 */               readTypeAndSize();
/* 767 */               String oldType = this.type;
/* 768 */               while (this.type.startsWith("ix") || this.type.endsWith("tx") || this.type.equals("JUNK")) {
/*     */ 
/*     */                 
/* 771 */                 this.in.skipBytes(this.size);
/* 772 */                 readTypeAndSize();
/*     */               } 
/*     */               
/* 775 */               String check = this.type.substring(2);
/* 776 */               boolean foundPixels = false;
/* 777 */               while (check.equals("db") || check.equals("dc") || check.equals("wb")) {
/*     */ 
/*     */                 
/* 780 */                 foundPixels = true;
/* 781 */                 if (check.startsWith("d") && (
/* 782 */                   this.size > 0 || this.bmpCompression != 0)) {
/* 783 */                   this.offsets.add(new Long(this.in.getFilePointer()));
/* 784 */                   this.lengths.add(new Long(this.size));
/* 785 */                   this.in.skipBytes(this.size);
/*     */                 } 
/*     */ 
/*     */                 
/* 789 */                 spos = this.in.getFilePointer();
/* 790 */                 if (spos + 8L >= this.in.length())
/*     */                   return; 
/* 792 */                 readTypeAndSize();
/* 793 */                 if (this.type.equals("JUNK")) {
/* 794 */                   this.in.skipBytes(this.size);
/* 795 */                   spos = this.in.getFilePointer();
/* 796 */                   if (spos + 8L >= this.in.length())
/* 797 */                     return;  readTypeAndSize();
/*     */                 } 
/* 799 */                 check = this.type.substring(2);
/* 800 */                 if (check.equals("0d")) {
/* 801 */                   this.in.seek(spos + 1L);
/* 802 */                   readTypeAndSize();
/* 803 */                   check = this.type.substring(2);
/*     */                 } 
/*     */               } 
/* 806 */               this.in.seek(spos);
/* 807 */               if (!oldType.startsWith("ix") && !foundPixels) {
/* 808 */                 end = true;
/*     */               }
/*     */             }
/*     */           
/*     */           } 
/*     */         } else {
/*     */           
/* 815 */           int oldSize = this.size;
/* 816 */           this.size = this.in.readInt() - 8;
/* 817 */           if (this.size > oldSize) {
/* 818 */             this.size = oldSize;
/* 819 */             this.in.seek(this.in.getFilePointer() - 4L);
/*     */           } 
/*     */           
/* 822 */           if (this.size + 8 >= 0) this.in.skipBytes(8 + this.size);
/*     */         
/*     */         } 
/* 825 */       } else if (this.in.getFilePointer() + 8L < this.in.length()) {
/*     */         
/* 827 */         readTypeAndSize();
/* 828 */         if (this.in.getFilePointer() + 8L < this.in.length() && !this.type.equals("idx1"))
/* 829 */         { readTypeAndSize(); }
/*     */         
/* 831 */         else if (!this.type.equals("idx1")) { break; }
/* 832 */          if (this.in.getFilePointer() + this.size + 4L <= this.in.length()) {
/* 833 */           this.in.skipBytes(this.size);
/*     */         }
/* 835 */         if (this.type.equals("idx1"))
/*     */           break; 
/*     */       } else {
/*     */         break;
/*     */       } 
/* 840 */       this.pos = this.in.getFilePointer();
/*     */     } 
/*     */   }
/*     */   
/*     */   private String getCodecName(int bmpCompression) {
/* 845 */     switch (bmpCompression) {
/*     */       case 0:
/* 847 */         return "Raw (uncompressed)";
/*     */       case 1:
/* 849 */         return "Microsoft Run-Length Encoding (MSRLE)";
/*     */       case 1296126531:
/* 851 */         return "Microsoft Video (MSV1)";
/*     */       case 1196444237:
/* 853 */         return "JPEG";
/*     */     } 
/*     */ 
/*     */     
/* 857 */     return "Unknown";
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/in/AVIReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */