/*      */ package loci.formats.in;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.EnumSet;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.Vector;
/*      */ import loci.common.DateTools;
/*      */ import loci.formats.CoreMetadata;
/*      */ import loci.formats.FormatException;
/*      */ import loci.formats.FormatReader;
/*      */ import loci.formats.FormatTools;
/*      */ import loci.formats.IFormatReader;
/*      */ import loci.formats.MetadataTools;
/*      */ import loci.formats.meta.MetadataStore;
/*      */ import ome.xml.model.primitives.PositiveFloat;
/*      */ import ome.xml.model.primitives.PositiveInteger;
/*      */ import ome.xml.model.primitives.Timestamp;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class BaseZeissReader
/*      */   extends FormatReader
/*      */ {
/*      */   protected int bpp;
/*      */   protected String[] imageFiles;
/*      */   protected int[] offsets;
/*      */   protected int[][] coordinates;
/*      */   protected Hashtable<Integer, String> timestamps;
/*      */   protected Hashtable<Integer, String> exposureTime;
/*   71 */   protected int cIndex = -1;
/*      */   
/*      */   protected boolean isJPEG;
/*      */   protected boolean isZlib;
/*      */   protected int realWidth;
/*      */   protected int realHeight;
/*      */   protected Vector<String> tagsToParse;
/*   78 */   protected int nextEmWave = 0; protected int nextExWave = 0; protected int nextChName = 0;
/*   79 */   protected Hashtable<Integer, Double> stageX = new Hashtable<Integer, Double>();
/*   80 */   protected Hashtable<Integer, Double> stageY = new Hashtable<Integer, Double>();
/*   81 */   protected int timepoint = 0;
/*      */   
/*      */   protected int[] channelColors;
/*   84 */   protected int lastPlane = 0;
/*   85 */   protected Hashtable<Integer, Integer> tiles = new Hashtable<Integer, Integer>();
/*      */   
/*   87 */   protected Hashtable<Integer, Double> detectorGain = new Hashtable<Integer, Double>();
/*      */   
/*   89 */   protected Hashtable<Integer, Double> detectorOffset = new Hashtable<Integer, Double>();
/*      */   
/*   91 */   protected Hashtable<Integer, PositiveInteger> emWavelength = new Hashtable<Integer, PositiveInteger>();
/*      */   
/*   93 */   protected Hashtable<Integer, PositiveInteger> exWavelength = new Hashtable<Integer, PositiveInteger>();
/*      */   
/*   95 */   protected Hashtable<Integer, String> channelName = new Hashtable<Integer, String>(); protected Double physicalSizeX; protected Double physicalSizeY;
/*      */   protected Double physicalSizeZ;
/*      */   protected int rowCount;
/*      */   protected int colCount;
/*      */   protected int rawCount;
/*      */   protected String imageDescription;
/*  101 */   protected Set<Integer> channelIndices = new HashSet<Integer>();
/*  102 */   protected Set<Integer> zIndices = new HashSet<Integer>();
/*  103 */   protected Set<Integer> timepointIndices = new HashSet<Integer>();
/*  104 */   protected Set<Integer> tileIndices = new HashSet<Integer>();
/*      */   
/*  106 */   protected Vector<String> roiIDs = new Vector<String>();
/*      */ 
/*      */   
/*  109 */   public ArrayList<Layer> layers = new ArrayList<Layer>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BaseZeissReader(String name, String suffix) {
/*  116 */     super(name, suffix);
/*      */   }
/*      */ 
/*      */   
/*      */   public BaseZeissReader(String name, String[] suffixes) {
/*  121 */     super(name, suffixes);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initFileMain(String id) throws FormatException, IOException {
/*  128 */     MetadataStore store = makeFilterMetadata();
/*  129 */     initVars(id);
/*  130 */     fillMetadataPass1(store);
/*  131 */     fillMetadataPass2(store);
/*  132 */     fillMetadataPass3(store);
/*  133 */     fillMetadataPass4(store);
/*  134 */     fillMetadataPass5(store);
/*  135 */     fillMetadataPass6(store);
/*  136 */     MetadataTools.populatePixels(store, (IFormatReader)this, true);
/*  137 */     storeROIs(store);
/*  138 */     fillMetadataPass7(store);
/*      */   }
/*      */   
/*      */   protected void initVars(String id) throws FormatException, IOException {
/*  142 */     this.timestamps = new Hashtable<Integer, String>();
/*  143 */     this.exposureTime = new Hashtable<Integer, String>();
/*  144 */     this.tagsToParse = new Vector<String>();
/*      */   }
/*      */   
/*      */   protected void countImages() {
/*  148 */     if (getImageCount() == 0)
/*  149 */       (this.core[0]).imageCount = 1; 
/*  150 */     this.offsets = new int[getImageCount()];
/*  151 */     this.coordinates = new int[getImageCount()][3];
/*  152 */     this.imageFiles = new String[getImageCount()];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void fillMetadataPass1(MetadataStore store) throws FormatException, IOException {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void fillMetadataPass2(MetadataStore store) throws FormatException, IOException {
/*  171 */     LOGGER.info("Populating metadata");
/*  172 */     this.stageX.clear();
/*  173 */     this.stageY.clear();
/*      */     
/*  175 */     (this.core[0]).sizeZ = this.zIndices.size();
/*  176 */     (this.core[0]).sizeT = this.timepointIndices.size();
/*  177 */     (this.core[0]).sizeC = this.channelIndices.size();
/*      */     
/*  179 */     (this.core[0]).littleEndian = true;
/*  180 */     (this.core[0]).interleaved = true;
/*  181 */     (this.core[0]).falseColor = true;
/*  182 */     (this.core[0]).metadataComplete = true;
/*      */     
/*  184 */     (this.core[0]).imageCount = getSizeZ() * getSizeT() * getSizeC();
/*      */     
/*  186 */     if (getImageCount() == 0 || getImageCount() == 1) {
/*  187 */       (this.core[0]).imageCount = 1;
/*  188 */       (this.core[0]).sizeZ = 1;
/*  189 */       (this.core[0]).sizeC = 1;
/*  190 */       (this.core[0]).sizeT = 1;
/*      */     } 
/*  192 */     (this.core[0]).rgb = (this.bpp % 3 == 0);
/*  193 */     if (isRGB()) (this.core[0]).sizeC *= 3;
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void fillMetadataPass3(MetadataStore store) throws FormatException, IOException {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void fillMetadataPass4(MetadataStore store) throws FormatException, IOException {
/*  213 */     int totalTiles = this.offsets.length / getImageCount();
/*      */     
/*  215 */     if (totalTiles <= 1) {
/*  216 */       totalTiles = 1;
/*      */     }
/*      */ 
/*      */     
/*  220 */     if (totalTiles > 1) {
/*  221 */       CoreMetadata originalCore = this.core[0];
/*  222 */       this.core = new CoreMetadata[totalTiles];
/*  223 */       this.core[0] = originalCore;
/*      */     } 
/*      */     
/*  226 */     (this.core[0]).dimensionOrder = "XY";
/*  227 */     if (isRGB()) (this.core[0]).dimensionOrder += "C"; 
/*  228 */     for (int i = 0; i < this.coordinates.length - 1; i++) {
/*  229 */       int[] zct1 = this.coordinates[i];
/*  230 */       int[] zct2 = this.coordinates[i + 1];
/*  231 */       int deltaZ = zct2[0] - zct1[0];
/*  232 */       int deltaC = zct2[1] - zct1[1];
/*  233 */       int deltaT = zct2[2] - zct1[2];
/*  234 */       if (deltaZ > 0 && getDimensionOrder().indexOf("Z") == -1) {
/*  235 */         (this.core[0]).dimensionOrder += "Z";
/*      */       }
/*  237 */       if (deltaC > 0 && getDimensionOrder().indexOf("C") == -1) {
/*  238 */         (this.core[0]).dimensionOrder += "C";
/*      */       }
/*  240 */       if (deltaT > 0 && getDimensionOrder().indexOf("T") == -1) {
/*  241 */         (this.core[0]).dimensionOrder += "T";
/*      */       }
/*      */     } 
/*  244 */     (this.core[0]).dimensionOrder = MetadataTools.makeSaneDimensionOrder(getDimensionOrder());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void fillMetadataPass5(MetadataStore store) throws FormatException, IOException {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void fillMetadataPass6(MetadataStore store) throws FormatException, IOException {
/*  264 */     if (getSizeX() == 0) {
/*  265 */       (this.core[0]).sizeX = 1;
/*      */     }
/*  267 */     if (getSizeY() == 0) {
/*  268 */       (this.core[0]).sizeY = 1;
/*      */     }
/*      */     
/*  271 */     if (this.bpp == 1 || this.bpp == 3) { (this.core[0]).pixelType = 1; }
/*  272 */     else if (this.bpp == 2 || this.bpp == 6) { (this.core[0]).pixelType = 3; }
/*  273 */      if (this.isJPEG) (this.core[0]).pixelType = 1;
/*      */     
/*  275 */     (this.core[0]).indexed = (!isRGB() && this.channelColors != null);
/*      */     
/*  277 */     for (int i = 1; i < this.core.length; i++) {
/*  278 */       this.core[i] = new CoreMetadata((IFormatReader)this, 0);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void fillMetadataPass7(MetadataStore store) throws FormatException, IOException {
/*  289 */     for (int i = 0; i < getSeriesCount(); i++) {
/*  290 */       long firstStamp = 0L;
/*  291 */       if (this.timestamps.size() > 0) {
/*  292 */         String timestamp = this.timestamps.get(new Integer(0));
/*  293 */         firstStamp = parseTimestamp(timestamp);
/*  294 */         firstStamp /= 1600L;
/*  295 */         int epoch = (this.timestamps.size() == 1) ? 4 : 3;
/*  296 */         String date = DateTools.convertDate(firstStamp, epoch);
/*  297 */         if (date != null) {
/*  298 */           store.setImageAcquisitionDate(new Timestamp(date), i);
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/*  303 */     if (getMetadataOptions().getMetadataLevel() != MetadataLevel.MINIMUM) {
/*      */       
/*  305 */       String instrumentID = MetadataTools.createLSID("Instrument", new int[] { 0 });
/*  306 */       store.setInstrumentID(instrumentID, 0);
/*      */       
/*  308 */       String objectiveID = MetadataTools.createLSID("Objective", new int[] { 0, 0 });
/*  309 */       store.setObjectiveID(objectiveID, 0, 0);
/*  310 */       store.setObjectiveCorrection(getCorrection("Other"), 0, 0);
/*  311 */       store.setObjectiveImmersion(getImmersion("Other"), 0, 0);
/*      */       
/*  313 */       Integer[] channelKeys = (Integer[])this.channelName.keySet().toArray((Object[])new Integer[0]);
/*  314 */       Arrays.sort((Object[])channelKeys);
/*      */       
/*      */       int j;
/*  317 */       for (j = 0; j < getEffectiveSizeC(); j++) {
/*  318 */         String detectorID = MetadataTools.createLSID("Detector", new int[] { 0, j });
/*  319 */         store.setDetectorID(detectorID, 0, j);
/*  320 */         store.setDetectorType(getDetectorType("Other"), 0, j);
/*      */         
/*  322 */         for (int s = 0; s < getSeriesCount(); s++) {
/*  323 */           int c = j;
/*  324 */           if (j < channelKeys.length) {
/*  325 */             c = channelKeys[j].intValue();
/*      */           }
/*      */           
/*  328 */           store.setDetectorSettingsID(detectorID, s, j);
/*  329 */           store.setDetectorSettingsGain(this.detectorGain.get(Integer.valueOf(c)), s, j);
/*  330 */           store.setDetectorSettingsOffset(this.detectorOffset.get(Integer.valueOf(c)), s, j);
/*      */           
/*  332 */           store.setChannelName(this.channelName.get(Integer.valueOf(c)), s, j);
/*  333 */           store.setChannelEmissionWavelength(this.emWavelength.get(Integer.valueOf(c)), s, j);
/*  334 */           store.setChannelExcitationWavelength(this.exWavelength.get(Integer.valueOf(c)), s, j);
/*      */         } 
/*      */       } 
/*      */       
/*  338 */       for (j = 0; j < getSeriesCount(); j++) {
/*  339 */         store.setImageInstrumentRef(instrumentID, j);
/*  340 */         store.setObjectiveSettingsID(objectiveID, j);
/*      */         
/*  342 */         if (this.imageDescription != null) {
/*  343 */           store.setImageDescription(this.imageDescription, j);
/*      */         }
/*  345 */         if (getSeriesCount() > 1) {
/*  346 */           store.setImageName("Tile #" + (j + 1), j);
/*      */         }
/*      */         
/*  349 */         PositiveFloat sizeX = FormatTools.getPhysicalSizeX(this.physicalSizeX);
/*  350 */         PositiveFloat sizeY = FormatTools.getPhysicalSizeY(this.physicalSizeY);
/*  351 */         PositiveFloat sizeZ = FormatTools.getPhysicalSizeZ(this.physicalSizeZ);
/*      */         
/*  353 */         if (sizeX != null) {
/*  354 */           store.setPixelsPhysicalSizeX(sizeX, j);
/*      */         }
/*  356 */         if (sizeY != null) {
/*  357 */           store.setPixelsPhysicalSizeY(sizeY, j);
/*      */         }
/*  359 */         if (sizeZ != null) {
/*  360 */           store.setPixelsPhysicalSizeZ(sizeZ, j);
/*      */         }
/*      */         
/*  363 */         long firstStamp = parseTimestamp(this.timestamps.get(new Integer(0)));
/*      */         
/*  365 */         for (int plane = 0; plane < getImageCount(); plane++) {
/*  366 */           int[] zct = getZCTCoords(plane);
/*  367 */           int expIndex = zct[1];
/*  368 */           if (channelKeys.length > 0) {
/*  369 */             expIndex += channelKeys[0].intValue();
/*      */           }
/*  371 */           String exposure = this.exposureTime.get(Integer.valueOf(expIndex));
/*  372 */           if (exposure == null && this.exposureTime.size() == 1) {
/*  373 */             exposure = this.exposureTime.get(this.exposureTime.keys().nextElement());
/*      */           }
/*  375 */           Double exp = new Double(0.0D); 
/*  376 */           try { exp = new Double(exposure); }
/*  377 */           catch (NumberFormatException e) {  }
/*  378 */           catch (NullPointerException e) {}
/*  379 */           store.setPlaneExposureTime(exp, j, plane);
/*      */           
/*  381 */           int posIndex = j * getImageCount() + plane;
/*      */           
/*  383 */           if (posIndex < this.timestamps.size()) {
/*  384 */             String timestamp = this.timestamps.get(new Integer(posIndex));
/*  385 */             long stamp = parseTimestamp(timestamp);
/*  386 */             stamp -= firstStamp;
/*  387 */             store.setPlaneDeltaT(new Double((stamp / 1600000L)), j, plane);
/*      */           } 
/*      */           
/*  390 */           if (this.stageX.get(Integer.valueOf(posIndex)) != null) {
/*  391 */             store.setPlanePositionX(this.stageX.get(Integer.valueOf(posIndex)), j, plane);
/*      */           }
/*  393 */           if (this.stageY.get(Integer.valueOf(posIndex)) != null) {
/*  394 */             store.setPlanePositionY(this.stageY.get(Integer.valueOf(posIndex)), j, plane);
/*      */           }
/*      */         } 
/*      */       } 
/*      */       
/*  399 */       for (j = 0; j < getSeriesCount(); j++) {
/*  400 */         for (int roi = 0; roi < this.roiIDs.size(); roi++) {
/*  401 */           store.setImageROIRef(this.roiIDs.get(roi), j, roi);
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public int getOptimalTileHeight() {
/*  409 */     FormatTools.assertId(this.currentId, true, 1);
/*  410 */     return getSizeY();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void storeROIs(MetadataStore store) throws FormatException, IOException {
/*  420 */     int roiIndex = 0;
/*  421 */     int shapeIndex = 0;
/*      */ 
/*      */ 
/*      */     
/*  425 */     for (Layer layer : this.layers) {
/*  426 */       for (Shape shape : layer.shapes) {
/*  427 */         String shapeID; StringBuffer points; int i, caliperPoints, j; double xdiff, ydiff, radius; int p; boolean closed; int m, k; shapeIndex = 0;
/*  428 */         if (shape.type == FeatureType.UNKNOWN || shape.type == FeatureType.LUT) {
/*      */           continue;
/*      */         }
/*  431 */         String roiID = MetadataTools.createLSID("ROI", new int[] { roiIndex });
/*      */         
/*  433 */         this.roiIDs.add(roiID);
/*  434 */         store.setROIID(roiID, roiIndex);
/*  435 */         if (shape.name != null)
/*  436 */           store.setROIName(shape.name, roiIndex); 
/*  437 */         if (shape.text != null && shape.text.length() == 0) {
/*  438 */           shape.text = null;
/*      */         }
/*  440 */         switch (shape.type) {
/*      */           case MAIN:
/*      */           case SCALING:
/*      */           case PLANE:
/*      */           case null:
/*  445 */             for (i = 0; i < shape.points.length / 2; i++) {
/*  446 */               String str = MetadataTools.createLSID("Shape", new int[] { roiIndex, shapeIndex });
/*  447 */               store.setPointID(str, roiIndex, shapeIndex);
/*  448 */               store.setPointX(Double.valueOf(shape.points[i * 2]), roiIndex, shapeIndex);
/*  449 */               store.setPointY(Double.valueOf(shape.points[i * 2 + 1]), roiIndex, shapeIndex);
/*  450 */               if (shape.text != null && i == 0)
/*  451 */                 store.setPointText(shape.text, roiIndex, shapeIndex); 
/*  452 */               shapeIndex++;
/*      */             } 
/*      */             break;
/*      */           case null:
/*      */           case null:
/*      */           case null:
/*  458 */             shapeID = MetadataTools.createLSID("Shape", new int[] { roiIndex, shapeIndex });
/*  459 */             store.setLineID(shapeID, roiIndex, shapeIndex);
/*  460 */             store.setLineX1(Double.valueOf(shape.points[0]), roiIndex, shapeIndex);
/*  461 */             store.setLineY1(Double.valueOf(shape.points[1]), roiIndex, shapeIndex);
/*  462 */             store.setLineX2(Double.valueOf(shape.points[2]), roiIndex, shapeIndex);
/*  463 */             store.setLineY2(Double.valueOf(shape.points[3]), roiIndex, shapeIndex);
/*  464 */             if (shape.text != null)
/*  465 */               store.setLineText(shape.text, roiIndex, shapeIndex); 
/*  466 */             shapeIndex++;
/*      */             break;
/*      */ 
/*      */ 
/*      */           
/*      */           case null:
/*      */           case null:
/*      */           case null:
/*      */           case null:
/*      */           case null:
/*      */           case null:
/*      */           case null:
/*      */           case null:
/*  479 */             caliperPoints = shape.points.length / 2;
/*  480 */             if (shape.type == FeatureType.CALIPER || shape.type == FeatureType.MEAS_CALIPER) {
/*  481 */               caliperPoints -= 2;
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  487 */             for (j = 0; j < caliperPoints; j++) {
/*  488 */               shapeID = MetadataTools.createLSID("Shape", new int[] { roiIndex, shapeIndex });
/*  489 */               store.setLineID(shapeID, roiIndex, shapeIndex);
/*  490 */               store.setLineX1(Double.valueOf(shape.points[j * 2 + 0]), roiIndex, shapeIndex);
/*  491 */               store.setLineY1(Double.valueOf(shape.points[j * 2 + 1]), roiIndex, shapeIndex);
/*  492 */               store.setLineX2(Double.valueOf(shape.points[j * 2 + 2]), roiIndex, shapeIndex);
/*  493 */               store.setLineY2(Double.valueOf(shape.points[j * 2 + 3]), roiIndex, shapeIndex);
/*  494 */               if (shape.text != null && j == caliperPoints - 2)
/*  495 */                 store.setLineText(shape.text, roiIndex, shapeIndex); 
/*  496 */               shapeIndex++;
/*      */             } 
/*      */             break;
/*      */           
/*      */           case null:
/*      */           case null:
/*      */           case null:
/*      */           case null:
/*  504 */             for (j = 0; j < 4; j += 2) {
/*  505 */               shapeID = MetadataTools.createLSID("Shape", new int[] { roiIndex, shapeIndex });
/*  506 */               store.setLineID(shapeID, roiIndex, shapeIndex);
/*  507 */               store.setLineX1(Double.valueOf(shape.points[j * 2 + 0]), roiIndex, shapeIndex);
/*  508 */               store.setLineY1(Double.valueOf(shape.points[j * 2 + 1]), roiIndex, shapeIndex);
/*  509 */               store.setLineX2(Double.valueOf(shape.points[j * 2 + 2]), roiIndex, shapeIndex);
/*  510 */               store.setLineY2(Double.valueOf(shape.points[j * 2 + 3]), roiIndex, shapeIndex);
/*  511 */               if (shape.text != null && j == 0)
/*  512 */                 store.setLineText(shape.text, roiIndex, shapeIndex); 
/*  513 */               shapeIndex++;
/*      */             } 
/*      */             break;
/*      */           
/*      */           case null:
/*      */           case null:
/*  519 */             xdiff = Math.abs(shape.points[0] - shape.points[2]);
/*  520 */             ydiff = Math.abs(shape.points[1] - shape.points[3]);
/*  521 */             radius = Math.sqrt(Math.pow(xdiff, 2.0D) + Math.pow(ydiff, 2.0D));
/*  522 */             shapeID = MetadataTools.createLSID("Shape", new int[] { roiIndex, shapeIndex });
/*  523 */             store.setEllipseID(shapeID, roiIndex, shapeIndex);
/*  524 */             store.setEllipseX(Double.valueOf(shape.points[0]), roiIndex, shapeIndex);
/*  525 */             store.setEllipseY(Double.valueOf(shape.points[1]), roiIndex, shapeIndex);
/*  526 */             store.setEllipseRadiusX(Double.valueOf(radius), roiIndex, shapeIndex);
/*  527 */             store.setEllipseRadiusY(Double.valueOf(radius), roiIndex, shapeIndex);
/*  528 */             if (shape.text != null)
/*  529 */               store.setEllipseText(shape.text, roiIndex, shapeIndex); 
/*  530 */             shapeIndex++;
/*  531 */             shapeID = MetadataTools.createLSID("Shape", new int[] { roiIndex, shapeIndex });
/*  532 */             store.setLineID(shapeID, roiIndex, shapeIndex);
/*  533 */             store.setLineX1(Double.valueOf(shape.points[0]), roiIndex, shapeIndex);
/*  534 */             store.setLineY1(Double.valueOf(shape.points[1]), roiIndex, shapeIndex);
/*  535 */             store.setLineX2(Double.valueOf(shape.points[2]), roiIndex, shapeIndex);
/*  536 */             store.setLineY2(Double.valueOf(shape.points[3]), roiIndex, shapeIndex);
/*  537 */             shapeIndex++;
/*      */             break;
/*      */           
/*      */           case null:
/*  541 */             shapeID = MetadataTools.createLSID("Shape", new int[] { roiIndex, shapeIndex });
/*  542 */             store.setLineID(shapeID, roiIndex, shapeIndex);
/*  543 */             store.setLineX1(Double.valueOf(shape.points[0]), roiIndex, shapeIndex);
/*  544 */             store.setLineY1(Double.valueOf(shape.points[1]), roiIndex, shapeIndex);
/*  545 */             store.setLineX2(Double.valueOf(shape.points[2]), roiIndex, shapeIndex);
/*  546 */             store.setLineY2(Double.valueOf(shape.points[3]), roiIndex, shapeIndex);
/*  547 */             store.setLineText(shape.text, roiIndex, shapeIndex);
/*  548 */             shapeIndex++;
/*  549 */             shapeID = MetadataTools.createLSID("Shape", new int[] { roiIndex, shapeIndex });
/*  550 */             store.setLabelID(shapeID, roiIndex, shapeIndex);
/*  551 */             store.setLabelX(Double.valueOf(shape.points[0]), roiIndex, shapeIndex);
/*  552 */             store.setLabelY(Double.valueOf(shape.points[1]), roiIndex, shapeIndex);
/*  553 */             if (shape.text != null)
/*  554 */               store.setLabelText(shape.text, roiIndex, shapeIndex); 
/*  555 */             shapeIndex++;
/*      */             
/*  557 */             shapeID = MetadataTools.createLSID("Shape", new int[] { roiIndex, shapeIndex });
/*  558 */             store.setRectangleID(shapeID, roiIndex, shapeIndex);
/*  559 */             store.setRectangleX(Double.valueOf(shape.points[0]), roiIndex, shapeIndex);
/*  560 */             store.setRectangleY(Double.valueOf(shape.points[1]), roiIndex, shapeIndex);
/*  561 */             store.setRectangleWidth(Double.valueOf(shape.points[2] - shape.points[0]), roiIndex, shapeIndex);
/*  562 */             store.setRectangleHeight(Double.valueOf(shape.points[3] - shape.points[1]), roiIndex, shapeIndex);
/*  563 */             if (shape.text != null)
/*  564 */               store.setRectangleText(shape.text, roiIndex, shapeIndex); 
/*  565 */             shapeIndex++;
/*      */             break;
/*      */           
/*      */           case null:
/*      */           case null:
/*      */           case null:
/*      */           case null:
/*      */           case null:
/*      */           case null:
/*      */           case null:
/*      */           case null:
/*  576 */             points = new StringBuffer();
/*  577 */             for (p = 0; p < shape.points.length; p += 2) {
/*  578 */               points.append(shape.points[p + 0]);
/*  579 */               points.append(",");
/*  580 */               points.append(shape.points[p + 1]);
/*  581 */               if (p < shape.points.length - 2)
/*  582 */                 points.append(" "); 
/*      */             } 
/*  584 */             shapeID = MetadataTools.createLSID("Shape", new int[] { roiIndex, shapeIndex });
/*  585 */             closed = (shape.type == FeatureType.POLYLINE_CLOSED || shape.type == FeatureType.SPLINE_CLOSED || shape.type == FeatureType.MEAS_POLYLINE_CLOSED || shape.type == FeatureType.MEAS_SPLINE_CLOSED);
/*      */             
/*  587 */             if (closed) {
/*  588 */               store.setPolygonID(shapeID, roiIndex, shapeIndex);
/*  589 */               store.setPolygonPoints(points.toString(), roiIndex, shapeIndex);
/*  590 */               if (shape.text != null)
/*  591 */                 store.setPolygonText(shape.text, roiIndex, shapeIndex); 
/*      */             } else {
/*  593 */               store.setPolylineID(shapeID, roiIndex, shapeIndex);
/*  594 */               store.setPolylinePoints(points.toString(), roiIndex, shapeIndex);
/*  595 */               if (shape.text != null)
/*  596 */                 store.setPolylineText(shape.text, roiIndex, shapeIndex); 
/*      */             } 
/*  598 */             shapeIndex++;
/*      */             break;
/*      */ 
/*      */           
/*      */           case null:
/*      */           case null:
/*      */           case null:
/*  605 */             shapeID = MetadataTools.createLSID("Shape", new int[] { roiIndex, shapeIndex });
/*  606 */             store.setLabelID(shapeID, roiIndex, shapeIndex);
/*  607 */             store.setLabelX(Double.valueOf(shape.points[0]), roiIndex, shapeIndex);
/*  608 */             store.setLabelY(Double.valueOf(shape.points[1]), roiIndex, shapeIndex);
/*  609 */             if (shape.text != null)
/*  610 */               store.setLabelText(shape.text, roiIndex, shapeIndex); 
/*  611 */             shapeIndex++;
/*  612 */             shapeID = MetadataTools.createLSID("Shape", new int[] { roiIndex, shapeIndex });
/*  613 */             store.setRectangleID(shapeID, roiIndex, shapeIndex);
/*  614 */             store.setRectangleX(Double.valueOf(shape.points[0]), roiIndex, shapeIndex);
/*  615 */             store.setRectangleY(Double.valueOf(shape.points[1]), roiIndex, shapeIndex);
/*  616 */             store.setRectangleWidth(Double.valueOf(shape.points[4] - shape.points[0]), roiIndex, shapeIndex);
/*  617 */             store.setRectangleHeight(Double.valueOf(shape.points[5] - shape.points[1]), roiIndex, shapeIndex);
/*  618 */             if (shape.text != null)
/*  619 */               store.setRectangleText(shape.text, roiIndex, shapeIndex); 
/*  620 */             shapeIndex++;
/*      */             break;
/*      */           case null:
/*      */           case null:
/*  624 */             points = new StringBuffer();
/*  625 */             for (m = 0; m < 8; m += 2) {
/*  626 */               points.append(shape.points[m + 0]);
/*  627 */               points.append(",");
/*  628 */               points.append(shape.points[m + 1]);
/*  629 */               if (m < 3) points.append(" "); 
/*      */             } 
/*  631 */             shapeID = MetadataTools.createLSID("Shape", new int[] { roiIndex, shapeIndex });
/*  632 */             store.setPolygonID(shapeID, roiIndex, shapeIndex);
/*  633 */             store.setPolygonPoints(points.toString(), roiIndex, shapeIndex);
/*  634 */             if (shape.text != null)
/*  635 */               store.setPolygonText(shape.text, roiIndex, shapeIndex); 
/*  636 */             shapeIndex++;
/*      */             break;
/*      */           case null:
/*      */           case null:
/*  640 */             shapeID = MetadataTools.createLSID("Shape", new int[] { roiIndex, shapeIndex });
/*  641 */             store.setEllipseID(shapeID, roiIndex, shapeIndex);
/*  642 */             store.setEllipseX(Double.valueOf((shape.points[0] + shape.points[4]) / 2.0D), roiIndex, shapeIndex);
/*  643 */             store.setEllipseY(Double.valueOf((shape.points[1] + shape.points[5]) / 2.0D), roiIndex, shapeIndex);
/*  644 */             store.setEllipseRadiusX(Double.valueOf((shape.points[4] - shape.points[0]) / 2.0D), roiIndex, shapeIndex);
/*  645 */             store.setEllipseRadiusY(Double.valueOf((shape.points[5] - shape.points[1]) / 2.0D), roiIndex, shapeIndex);
/*  646 */             if (shape.text != null)
/*  647 */               store.setEllipseText(shape.text, roiIndex, shapeIndex); 
/*  648 */             shapeIndex++;
/*      */             break;
/*      */           
/*      */           case null:
/*      */           case null:
/*  653 */             for (k = 0; k < 6; k += 2) {
/*  654 */               shapeID = MetadataTools.createLSID("Shape", new int[] { roiIndex, shapeIndex });
/*  655 */               store.setLineID(shapeID, roiIndex, shapeIndex);
/*  656 */               store.setLineX1(Double.valueOf(shape.points[k * 2 + 0]), roiIndex, shapeIndex);
/*  657 */               store.setLineY1(Double.valueOf(shape.points[k * 2 + 1]), roiIndex, shapeIndex);
/*  658 */               store.setLineX2(Double.valueOf(shape.points[k * 2 + 2]), roiIndex, shapeIndex);
/*  659 */               store.setLineY2(Double.valueOf(shape.points[k * 2 + 3]), roiIndex, shapeIndex);
/*  660 */               if (shape.text != null && k == 0)
/*  661 */                 store.setLineText(shape.text, roiIndex, shapeIndex); 
/*  662 */               shapeIndex++;
/*      */             } 
/*      */             break;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  670 */         roiIndex++;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public byte[][] get8BitLookupTable() throws FormatException, IOException {
/*  677 */     int pixelType = getPixelType();
/*  678 */     if ((pixelType != 0 && pixelType != 1) || !isIndexed())
/*      */     {
/*      */       
/*  681 */       return (byte[][])null;
/*      */     }
/*  683 */     byte[][] lut = new byte[3][256];
/*  684 */     int channel = getZCTCoords(this.lastPlane)[1];
/*  685 */     if (channel >= this.channelColors.length) return (byte[][])null; 
/*  686 */     int color = this.channelColors[channel];
/*      */     
/*  688 */     float red = (color & 0xFF) / 255.0F;
/*  689 */     float green = ((color & 0xFF00) >> 8) / 255.0F;
/*  690 */     float blue = ((color & 0xFF0000) >> 16) / 255.0F;
/*      */     
/*  692 */     for (int i = 0; i < (lut[0]).length; i++) {
/*  693 */       lut[0][i] = (byte)(int)(red * i);
/*  694 */       lut[1][i] = (byte)(int)(green * i);
/*  695 */       lut[2][i] = (byte)(int)(blue * i);
/*      */     } 
/*      */     
/*  698 */     return lut;
/*      */   }
/*      */ 
/*      */   
/*      */   public short[][] get16BitLookupTable() throws FormatException, IOException {
/*  703 */     int pixelType = getPixelType();
/*  704 */     if ((pixelType != 2 && pixelType != 3) || !isIndexed())
/*      */     {
/*      */       
/*  707 */       return (short[][])null;
/*      */     }
/*  709 */     short[][] lut = new short[3][65536];
/*  710 */     int channel = getZCTCoords(this.lastPlane)[1];
/*  711 */     if (channel >= this.channelColors.length) return (short[][])null; 
/*  712 */     int color = this.channelColors[channel];
/*      */     
/*  714 */     float red = (color & 0xFF) / 255.0F;
/*  715 */     float green = ((color & 0xFF00) >> 8) / 255.0F;
/*  716 */     float blue = ((color & 0xFF0000) >> 16) / 255.0F;
/*      */     
/*  718 */     for (int i = 0; i < (lut[0]).length; i++) {
/*  719 */       lut[0][i] = (short)(int)(red * i);
/*  720 */       lut[1][i] = (short)(int)(green * i);
/*  721 */       lut[2][i] = (short)(int)(blue * i);
/*      */     } 
/*  723 */     return lut;
/*      */   }
/*      */ 
/*      */   
/*      */   public void close(boolean fileOnly) throws IOException {
/*  728 */     super.close(fileOnly);
/*  729 */     if (!fileOnly) {
/*  730 */       this.timestamps = this.exposureTime = null;
/*  731 */       this.offsets = null;
/*  732 */       this.coordinates = (int[][])null;
/*  733 */       this.imageFiles = null;
/*  734 */       this.cIndex = -1;
/*  735 */       this.bpp = 0;
/*  736 */       this.isJPEG = this.isZlib = false;
/*      */       
/*  738 */       this.tagsToParse = null;
/*  739 */       this.nextEmWave = this.nextExWave = this.nextChName = 0;
/*  740 */       this.realWidth = this.realHeight = 0;
/*  741 */       this.stageX.clear();
/*  742 */       this.stageY.clear();
/*  743 */       this.channelColors = null;
/*  744 */       this.lastPlane = 0;
/*  745 */       this.tiles.clear();
/*  746 */       this.detectorGain.clear();
/*  747 */       this.detectorOffset.clear();
/*  748 */       this.emWavelength.clear();
/*  749 */       this.exWavelength.clear();
/*  750 */       this.channelName.clear();
/*  751 */       this.physicalSizeX = this.physicalSizeY = this.physicalSizeZ = null;
/*  752 */       this.rowCount = this.colCount = this.rawCount = 0;
/*  753 */       this.imageDescription = null;
/*  754 */       this.channelIndices.clear();
/*  755 */       this.zIndices.clear();
/*  756 */       this.timepointIndices.clear();
/*  757 */       this.tileIndices.clear();
/*  758 */       this.timepoint = 0;
/*  759 */       this.roiIDs.clear();
/*  760 */       this.layers.clear();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void parseMainTags(int image, MetadataStore store, ArrayList<Tag> tags) throws FormatException, IOException {
/*  769 */     int effectiveSizeC = 0;
/*      */     try {
/*  771 */       effectiveSizeC = getEffectiveSizeC();
/*      */     }
/*  773 */     catch (ArithmeticException e) {}
/*      */     
/*  775 */     for (Tag t : tags) {
/*      */       
/*  777 */       String key = t.getKey();
/*  778 */       String value = t.getValue();
/*      */       
/*      */       try {
/*  781 */         if (key.equals("Image Channel Index")) {
/*  782 */           this.cIndex = Integer.parseInt(value);
/*  783 */           int v = 0;
/*  784 */           for (; getGlobalMeta(key + " " + v) != null; v++);
/*  785 */           if (!getGlobalMetadata().containsValue(Integer.valueOf(this.cIndex))) {
/*  786 */             addGlobalMeta(key + " " + v, this.cIndex);
/*      */           }
/*      */           continue;
/*      */         } 
/*  790 */         if (key.equals("ImageWidth")) {
/*  791 */           int v = Integer.parseInt(value);
/*  792 */           if (getSizeX() == 0 || v < getSizeX()) {
/*  793 */             (this.core[0]).sizeX = v;
/*      */           }
/*  795 */           if (this.realWidth == 0 && v > this.realWidth) this.realWidth = v;
/*      */         
/*  797 */         } else if (key.equals("ImageHeight")) {
/*  798 */           int v = Integer.parseInt(value);
/*  799 */           if (getSizeY() == 0 || v < getSizeY()) (this.core[0]).sizeY = v; 
/*  800 */           if (this.realHeight == 0 || v > this.realHeight) this.realHeight = v;
/*      */         
/*      */         } 
/*  803 */         if (this.cIndex != -1) key = key + " " + this.cIndex; 
/*  804 */         addGlobalMeta(key, value);
/*      */         
/*  806 */         if (key.startsWith("ImageTile") && !(store instanceof loci.formats.meta.DummyMetadata)) {
/*  807 */           if (!this.tiles.containsKey(new Integer(value))) {
/*  808 */             this.tiles.put(new Integer(value), new Integer(1));
/*      */           } else {
/*      */             
/*  811 */             int v = ((Integer)this.tiles.get(new Integer(value))).intValue() + 1;
/*  812 */             this.tiles.put(new Integer(value), new Integer(v));
/*      */           } 
/*      */         }
/*      */         
/*  816 */         if (key.startsWith("MultiChannel Color")) {
/*  817 */           if (this.cIndex >= 0 && this.cIndex < effectiveSizeC) {
/*  818 */             if (this.channelColors == null || effectiveSizeC > this.channelColors.length)
/*      */             {
/*      */               
/*  821 */               this.channelColors = new int[effectiveSizeC];
/*      */             }
/*  823 */             if (this.channelColors[this.cIndex] == 0)
/*  824 */               this.channelColors[this.cIndex] = Integer.parseInt(value); 
/*      */             continue;
/*      */           } 
/*  827 */           if (this.cIndex == effectiveSizeC && this.channelColors != null && this.channelColors[0] == 0) {
/*      */ 
/*      */             
/*  830 */             System.arraycopy(this.channelColors, 1, this.channelColors, 0, this.channelColors.length - 1);
/*      */             
/*  832 */             this.channelColors[this.cIndex - 1] = Integer.parseInt(value);
/*      */           }  continue;
/*  834 */         }  if (key.startsWith("Scale Factor for X") && this.physicalSizeX == null) {
/*      */           
/*  836 */           this.physicalSizeX = Double.valueOf(Double.parseDouble(value)); continue;
/*      */         } 
/*  838 */         if (key.startsWith("Scale Factor for Y") && this.physicalSizeY == null) {
/*      */           
/*  840 */           this.physicalSizeY = Double.valueOf(Double.parseDouble(value)); continue;
/*      */         } 
/*  842 */         if (key.startsWith("Scale Factor for Z") && this.physicalSizeZ == null) {
/*      */           
/*  844 */           this.physicalSizeZ = Double.valueOf(Double.parseDouble(value)); continue;
/*      */         } 
/*  846 */         if (key.startsWith("Number Rows") && this.rowCount == 0) {
/*      */           
/*  848 */           this.rowCount = parseInt(value); continue;
/*      */         } 
/*  850 */         if (key.startsWith("Number Columns") && this.colCount == 0) {
/*      */           
/*  852 */           this.colCount = parseInt(value); continue;
/*      */         } 
/*  854 */         if (key.startsWith("NumberOfRawImages") && this.rawCount == 0) {
/*      */           
/*  856 */           this.rawCount = parseInt(value); continue;
/*      */         } 
/*  858 */         if (key.startsWith("Emission Wavelength")) {
/*  859 */           if (this.cIndex != -1) {
/*  860 */             Integer wave = new Integer(value);
/*  861 */             PositiveInteger emission = FormatTools.getEmissionWavelength(wave);
/*  862 */             if (emission != null)
/*  863 */               this.emWavelength.put(Integer.valueOf(this.cIndex), emission); 
/*      */           } 
/*      */           continue;
/*      */         } 
/*  867 */         if (key.startsWith("Excitation Wavelength")) {
/*  868 */           if (this.cIndex != -1) {
/*  869 */             Integer wave = new Integer((int)Double.parseDouble(value));
/*  870 */             PositiveInteger excitation = FormatTools.getExcitationWavelength(wave);
/*      */             
/*  872 */             if (excitation != null)
/*  873 */               this.exWavelength.put(Integer.valueOf(this.cIndex), excitation); 
/*      */           } 
/*      */           continue;
/*      */         } 
/*  877 */         if (key.startsWith("Channel Name")) {
/*  878 */           if (this.cIndex != -1)
/*  879 */             this.channelName.put(Integer.valueOf(this.cIndex), value); 
/*      */           continue;
/*      */         } 
/*  882 */         if (key.startsWith("Exposure Time [ms]")) {
/*  883 */           if (this.exposureTime.get(new Integer(this.cIndex)) == null) {
/*  884 */             double exp = Double.parseDouble(value) / 1000.0D;
/*  885 */             this.exposureTime.put(new Integer(this.cIndex), String.valueOf(exp));
/*      */           }  continue;
/*      */         } 
/*  888 */         if (key.startsWith("User Name")) {
/*  889 */           String[] username = value.split(" ");
/*  890 */           if (username.length >= 2) {
/*  891 */             String id = MetadataTools.createLSID("Experimenter", new int[] { 0 });
/*  892 */             store.setExperimenterID(id, 0);
/*  893 */             store.setExperimenterFirstName(username[0], 0);
/*  894 */             store.setExperimenterLastName(username[username.length - 1], 0);
/*      */           }  continue;
/*      */         } 
/*  897 */         if (key.equals("User company")) {
/*  898 */           String id = MetadataTools.createLSID("Experimenter", new int[] { 0 });
/*  899 */           store.setExperimenterID(id, 0);
/*  900 */           store.setExperimenterInstitution(value, 0); continue;
/*      */         } 
/*  902 */         if (key.startsWith("Objective Magnification")) {
/*  903 */           int magnification = (int)Double.parseDouble(value);
/*  904 */           if (magnification > 0) {
/*  905 */             store.setObjectiveNominalMagnification(new PositiveInteger(Integer.valueOf(magnification)), 0, 0);
/*      */             
/*      */             continue;
/*      */           } 
/*  909 */           LOGGER.warn("Expected positive value for NominalMagnification; got {}", Integer.valueOf(magnification));
/*      */           
/*      */           continue;
/*      */         } 
/*      */         
/*  914 */         if (key.startsWith("Objective ID")) {
/*  915 */           store.setObjectiveID("Objective:" + value, 0, 0);
/*  916 */           store.setObjectiveCorrection(getCorrection("Other"), 0, 0);
/*  917 */           store.setObjectiveImmersion(getImmersion("Other"), 0, 0); continue;
/*      */         } 
/*  919 */         if (key.startsWith("Objective N.A.")) {
/*  920 */           store.setObjectiveLensNA(new Double(value), 0, 0); continue;
/*      */         } 
/*  922 */         if (key.startsWith("Objective Name")) {
/*  923 */           String[] tokens = value.split(" ");
/*  924 */           for (int q = 0; q < tokens.length; q++) {
/*  925 */             int slash = tokens[q].indexOf("/");
/*  926 */             if (slash != -1 && slash - q > 0) {
/*  927 */               int mag = (int)Double.parseDouble(tokens[q].substring(0, slash - q));
/*      */               
/*  929 */               String na = tokens[q].substring(slash + 1);
/*  930 */               if (mag > 0) {
/*  931 */                 store.setObjectiveNominalMagnification(new PositiveInteger(Integer.valueOf(mag)), 0, 0);
/*      */               }
/*      */               else {
/*      */                 
/*  935 */                 LOGGER.warn("Expected positive value for NominalMagnification; got {}", Integer.valueOf(mag));
/*      */               } 
/*      */ 
/*      */               
/*  939 */               store.setObjectiveLensNA(new Double(na), 0, 0);
/*  940 */               store.setObjectiveCorrection(getCorrection(tokens[q - 1]), 0, 0); break;
/*      */             } 
/*      */           } 
/*      */           continue;
/*      */         } 
/*  945 */         if (key.startsWith("Objective Working Distance")) {
/*  946 */           store.setObjectiveWorkingDistance(new Double(value), 0, 0); continue;
/*      */         } 
/*  948 */         if (key.startsWith("Objective Immersion Type")) {
/*  949 */           String immersion = "Other";
/*  950 */           switch (Integer.parseInt(value)) {
/*      */             
/*      */             case 2:
/*  953 */               immersion = "Oil";
/*      */               break;
/*      */             case 3:
/*  956 */               immersion = "Water";
/*      */               break;
/*      */           } 
/*  959 */           store.setObjectiveImmersion(getImmersion(immersion), 0, 0); continue;
/*      */         } 
/*  961 */         if (key.startsWith("Stage Position X")) {
/*  962 */           this.stageX.put(Integer.valueOf(image), new Double(value));
/*  963 */           addGlobalMeta("X position for position #" + this.stageX.size(), value); continue;
/*      */         } 
/*  965 */         if (key.startsWith("Stage Position Y")) {
/*  966 */           this.stageY.put(Integer.valueOf(image), new Double(value));
/*  967 */           addGlobalMeta("Y position for position #" + this.stageY.size(), value); continue;
/*      */         } 
/*  969 */         if (key.startsWith("Orca Analog Gain")) {
/*  970 */           this.detectorGain.put(Integer.valueOf(this.cIndex), new Double(value)); continue;
/*      */         } 
/*  972 */         if (key.startsWith("Orca Analog Offset")) {
/*  973 */           this.detectorOffset.put(Integer.valueOf(this.cIndex), new Double(value)); continue;
/*      */         } 
/*  975 */         if (key.startsWith("Comments")) {
/*  976 */           this.imageDescription = value; continue;
/*      */         } 
/*  978 */         if (key.startsWith("Acquisition Date")) {
/*  979 */           if (this.timepoint > 0) {
/*  980 */             this.timestamps.put(new Integer(this.timepoint - 1), value);
/*  981 */             addGlobalMeta("Timestamp " + this.timepoint, value);
/*      */           } else {
/*      */             
/*  984 */             this.timestamps.put(new Integer(this.timepoint), value);
/*      */           } 
/*  986 */           this.timepoint++;
/*      */         }
/*      */       
/*  989 */       } catch (NumberFormatException e) {}
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static int parseInt(String number) {
/* 1001 */     return parseInt(number, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static int parseInt(String number, int defaultnum) {
/* 1011 */     if (number != null && number.trim().length() > 0) {
/* 1012 */       return Integer.parseInt(number);
/*      */     }
/* 1014 */     return defaultnum;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private long parseTimestamp(String s) {
/* 1024 */     long stamp = 0L;
/*      */     try {
/* 1026 */       stamp = Long.parseLong(s);
/*      */     }
/* 1028 */     catch (NumberFormatException exc) {
/*      */       try {
/* 1030 */         stamp = Double.doubleToLongBits(Double.parseDouble(s));
/*      */       }
/* 1032 */       catch (Exception e) {
/* 1033 */         if (s != null) {
/* 1034 */           stamp = DateTools.getTime(s, "M/d/y h:mm:ss aa");
/* 1035 */           if (stamp < 0L) {
/* 1036 */             stamp = DateTools.getTime(s, "d/M/y H:mm:ss");
/*      */           }
/* 1038 */           stamp += 2921084975759000L;
/* 1039 */           stamp *= 1600L;
/*      */         } 
/*      */       } 
/*      */     } 
/* 1043 */     return stamp;
/*      */   }
/*      */   
/* 1046 */   public enum Context { MAIN, SCALING, PLANE; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public class Tag
/*      */   {
/*      */     private int index;
/*      */ 
/*      */     
/*      */     private int keyid;
/*      */ 
/*      */     
/*      */     private String value;
/*      */ 
/*      */     
/*      */     private int category;
/*      */ 
/*      */     
/*      */     private BaseZeissReader.Context context;
/*      */ 
/*      */ 
/*      */     
/*      */     public Tag(int index, BaseZeissReader.Context context) {
/* 1071 */       this.index = index;
/* 1072 */       this.keyid = -1;
/* 1073 */       this.value = null;
/* 1074 */       this.category = -1;
/* 1075 */       this.context = context;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Tag(int keyid, String value, BaseZeissReader.Context context) {
/* 1085 */       this.index = 0;
/* 1086 */       this.keyid = keyid;
/* 1087 */       this.value = value;
/* 1088 */       this.category = 0;
/* 1089 */       this.context = context;
/*      */     }
/*      */ 
/*      */     
/*      */     public void setKey(int keyid) {
/* 1094 */       this.keyid = keyid;
/*      */     }
/*      */ 
/*      */     
/*      */     public String getKey() {
/* 1099 */       return getKey(this.keyid);
/*      */     }
/*      */ 
/*      */     
/*      */     public void setValue(String value) {
/* 1104 */       this.value = value;
/*      */     }
/*      */ 
/*      */     
/*      */     public String getValue() {
/* 1109 */       return this.value;
/*      */     }
/*      */ 
/*      */     
/*      */     public void setIndex(int index) {
/* 1114 */       this.index = index;
/*      */     }
/*      */ 
/*      */     
/*      */     public int getIndex() {
/* 1119 */       return this.index;
/*      */     }
/*      */ 
/*      */     
/*      */     public void setCategory(int category) {
/* 1124 */       this.category = category;
/*      */     }
/*      */ 
/*      */     
/*      */     public int getCategory() {
/* 1129 */       return this.category;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean valid() {
/* 1137 */       return (this.keyid != -1 && this.value != null && this.category != -1);
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/* 1142 */       String s = new String();
/* 1143 */       s = s + this.keyid + " (" + getKey() + ") = " + getValue();
/* 1144 */       switch (this.context)
/*      */       
/*      */       { case MAIN:
/* 1147 */           s = s + " [main]";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1155 */           return s;case SCALING: s = s + " [scaling]"; return s;case PLANE: s = s + " [plane]"; return s; }  s = s + " [unknown]"; return s;
/*      */     }
/*      */ 
/*      */     
/*      */     protected String getKey(int tagID) {
/* 1160 */       switch (tagID) { case -1:
/* 1161 */           return "INVALID";
/* 1162 */         case 222: return "Compression";
/* 1163 */         case 257: return "DateMappingTable";
/* 1164 */         case 258: return "BlackValue";
/* 1165 */         case 259: return "WhiteValue";
/* 1166 */         case 260: return "ImageDataMappingAutoRange";
/* 1167 */         case 261: return "Thumbnail";
/* 1168 */         case 262: return "GammaValue";
/* 1169 */         case 264: return "ImageOverExposure";
/* 1170 */         case 265: return "ImageRelativeTime1";
/* 1171 */         case 266: return "ImageRelativeTime2";
/* 1172 */         case 267: return "ImageRelativeTime3";
/* 1173 */         case 268: return "ImageRelativeTime4";
/* 1174 */         case 300: return "ImageRelativeTime";
/* 1175 */         case 301: return "ImageBaseTime1";
/* 1176 */         case 302: return "ImageBaseTime2";
/* 1177 */         case 303: return "ImageBaseTime3";
/* 1178 */         case 305: return "ImageBaseTime4";
/* 1179 */         case 333: return "RelFocusPosition1";
/* 1180 */         case 334: return "RelFocusPosition2";
/* 1181 */         case 513: return "ObjectType";
/* 1182 */         case 515: return "ImageWidth";
/* 1183 */         case 516: return "ImageHeight";
/* 1184 */         case 517: return "Number Raw Count";
/* 1185 */         case 518: return "PixelType";
/* 1186 */         case 519: return "NumberOfRawImages";
/* 1187 */         case 520: return "ImageSize";
/* 1188 */         case 521: return "CompressionFactorForSave";
/* 1189 */         case 522: return "DocumentSaveFlags";
/* 1190 */         case 523: return "Acquisition pause annotation";
/* 1191 */         case 530: return "Document Subtype";
/* 1192 */         case 531: return "Acquisition Bit Depth";
/* 1193 */         case 532: return "Image Memory Usage (RAM)";
/* 1194 */         case 534: return "Z-Stack single representative";
/* 1195 */         case 769: return "Scale Factor for X";
/* 1196 */         case 770: return "Scale Unit for X";
/* 1197 */         case 771: return "Scale Width";
/* 1198 */         case 772: return "Scale Factor for Y";
/* 1199 */         case 773: return "Scale Unit for Y";
/* 1200 */         case 774: return "Scale Height";
/* 1201 */         case 775: return "Scale Factor for Z";
/* 1202 */         case 776: return "Scale Unit for Z";
/* 1203 */         case 777: return "Scale Depth";
/* 1204 */         case 778: return "Scaling Parent";
/* 1205 */         case 1001: return "Date";
/* 1206 */         case 1002: return "Code";
/* 1207 */         case 1003: return "Source";
/* 1208 */         case 1004: return "Message";
/* 1209 */         case 1025: return "Acquisition Date";
/* 1210 */         case 1026: return "8-bit Acquisition";
/* 1211 */         case 1027: return "Camera Bit Depth";
/* 1212 */         case 1029: return "MonoReferenceLow";
/* 1213 */         case 1030: return "MonoReferenceHigh";
/* 1214 */         case 1031: return "RedReferenceLow";
/* 1215 */         case 1032: return "RedReferenceHigh";
/* 1216 */         case 1033: return "GreenReferenceLow";
/* 1217 */         case 1034: return "GreenReferenceHigh";
/* 1218 */         case 1035: return "BlueReferenceLow";
/* 1219 */         case 1036: return "BlueReferenceHigh";
/* 1220 */         case 1041: return "FrameGrabber Name";
/* 1221 */         case 1042: return "Camera";
/* 1222 */         case 1044: return "CameraTriggerSignalType";
/* 1223 */         case 1045: return "CameraTriggerEnable";
/* 1224 */         case 1046: return "GrabberTimeout";
/* 1225 */         case 1047: return "tag_ID_1047";
/* 1226 */         case 1281: return "MultiChannelEnabled";
/* 1227 */         case 1282: return "MultiChannel Color";
/* 1228 */         case 1283: return "MultiChannel Weight";
/* 1229 */         case 1284: return "Channel Name";
/* 1230 */         case 1536: return "DocumentInformationGroup";
/* 1231 */         case 1537: if (this.context == BaseZeissReader.Context.SCALING) {
/* 1232 */             return "Scale Unit for Z";
/*      */           }
/* 1234 */           return "Title";
/* 1235 */         case 1538: return "Author";
/* 1236 */         case 1539: return "Keywords";
/* 1237 */         case 1540: return "Comments";
/* 1238 */         case 1541: return "SampleID";
/* 1239 */         case 1542: return "Subject";
/* 1240 */         case 1543: return "RevisionNumber";
/* 1241 */         case 1544: return "Save Folder";
/* 1242 */         case 1545: return "FileLink";
/* 1243 */         case 1546: return "Document Type";
/* 1244 */         case 1547: return "Storage Media";
/* 1245 */         case 1548: return "File ID";
/* 1246 */         case 1549: return "Reference";
/* 1247 */         case 1550: return "File Date";
/* 1248 */         case 1551: return "File Size";
/* 1249 */         case 1553: return "Filename";
/* 1250 */         case 1792: return "ProjectGroup";
/* 1251 */         case 1793: return "Acquisition Date";
/* 1252 */         case 1794: return "Last modified by";
/* 1253 */         case 1795: return "User Company";
/* 1254 */         case 1796: return "User Company Logo";
/* 1255 */         case 1797: return "Image";
/* 1256 */         case 1800: return "User ID";
/* 1257 */         case 1801: return "User Name";
/* 1258 */         case 1802: return "User City";
/* 1259 */         case 1803: return "User Address";
/* 1260 */         case 1804: return "User Country";
/* 1261 */         case 1805: return "User Phone";
/* 1262 */         case 1806: return "User Fax";
/* 1263 */         case 2049: return "Objective Name";
/* 1264 */         case 2050: return "Optovar";
/* 1265 */         case 2051: return "Reflector";
/* 1266 */         case 2052: return "Condenser Contrast";
/* 1267 */         case 2053: return "Transmitted Light Filter 1";
/* 1268 */         case 2054: return "Transmitted Light Filter 2";
/* 1269 */         case 2055: return "Reflected Light Shutter";
/* 1270 */         case 2056: return "Condenser Front Lens";
/* 1271 */         case 2057: return "Excitation Filter Name";
/* 1272 */         case 2060: return "Transmitted Light Fieldstop Aperture";
/* 1273 */         case 2061: return "Reflected Light Aperture";
/* 1274 */         case 2062: return "Condenser N.A.";
/* 1275 */         case 2063: return "Light Path";
/* 1276 */         case 2064: return "HalogenLampOn";
/* 1277 */         case 2065: return "Halogen Lamp Mode";
/* 1278 */         case 2066: return "Halogen Lamp Voltage";
/* 1279 */         case 2068: return "Fluorescence Lamp Level";
/* 1280 */         case 2069: return "Fluorescence Lamp Intensity";
/* 1281 */         case 2070: return "LightManagerEnabled";
/* 1282 */         case 2071: return "tag_ID_2071";
/* 1283 */         case 2072: return "Focus Position";
/* 1284 */         case 2073: return "Stage Position X";
/* 1285 */         case 2074: return "Stage Position Y";
/* 1286 */         case 2075: return "Microscope Name";
/* 1287 */         case 2076: return "Objective Magnification";
/* 1288 */         case 2077: return "Objective N.A.";
/* 1289 */         case 2078: return "MicroscopeIllumination";
/* 1290 */         case 2079: return "External Shutter 1";
/* 1291 */         case 2080: return "External Shutter 2";
/* 1292 */         case 2081: return "External Shutter 3";
/* 1293 */         case 2082: return "External Filter Wheel 1 Name";
/* 1294 */         case 2083: return "External Filter Wheel 2 Name";
/* 1295 */         case 2084: return "Parfocal Correction";
/* 1296 */         case 2086: return "External Shutter 4";
/* 1297 */         case 2087: return "External Shutter 5";
/* 1298 */         case 2088: return "External Shutter 6";
/* 1299 */         case 2089: return "External Filter Wheel 3 Name";
/* 1300 */         case 2090: return "External Filter Wheel 4 Name";
/* 1301 */         case 2103: return "Objective Turret Position";
/* 1302 */         case 2104: return "Objective Contrast Method";
/* 1303 */         case 2105: return "Objective Immersion Type";
/* 1304 */         case 2107: return "Reflector Position";
/* 1305 */         case 2109: return "Transmitted Light Filter 1 Position";
/* 1306 */         case 2110: return "Transmitted Light Filter 2 Position";
/* 1307 */         case 2112: return "Excitation Filter Position";
/* 1308 */         case 2113: return "Lamp Mirror Position";
/* 1309 */         case 2114: return "External Filter Wheel 1 Position";
/* 1310 */         case 2115: return "External Filter Wheel 2 Position";
/* 1311 */         case 2116: return "External Filter Wheel 3 Position";
/* 1312 */         case 2117: return "External Filter Wheel 4 Position";
/* 1313 */         case 2118: return "Lightmanager Mode";
/* 1314 */         case 2119: return "Halogen Lamp Calibration";
/* 1315 */         case 2120: return "CondenserNAGoSpeed";
/* 1316 */         case 2121: return "TransmittedLightFieldstopGoSpeed";
/* 1317 */         case 2122: return "OptovarGoSpeed";
/* 1318 */         case 2123: return "Focus calibrated";
/* 1319 */         case 2124: return "FocusBasicPosition";
/* 1320 */         case 2125: return "FocusPower";
/* 1321 */         case 2126: return "FocusBacklash";
/* 1322 */         case 2127: return "FocusMeasurementOrigin";
/* 1323 */         case 2128: return "FocusMeasurementDistance";
/* 1324 */         case 2129: return "FocusSpeed";
/* 1325 */         case 2130: return "FocusGoSpeed";
/* 1326 */         case 2131: return "FocusDistance";
/* 1327 */         case 2132: return "FocusInitPosition";
/* 1328 */         case 2133: return "Stage calibrated";
/* 1329 */         case 2134: return "StagePower";
/* 1330 */         case 2135: return "StageXBacklash";
/* 1331 */         case 2136: return "StageYBacklash";
/* 1332 */         case 2137: return "StageSpeedX";
/* 1333 */         case 2138: return "StageSpeedY";
/* 1334 */         case 2139: return "StageSpeed";
/* 1335 */         case 2140: return "StageGoSpeedX";
/* 1336 */         case 2141: return "StageGoSpeedY";
/* 1337 */         case 2142: return "StageStepDistanceX";
/* 1338 */         case 2143: return "StageStepDistanceY";
/* 1339 */         case 2144: return "StageInitialisationPositionX";
/* 1340 */         case 2145: return "StageInitialisationPositionY";
/* 1341 */         case 2146: return "MicroscopeMagnification";
/* 1342 */         case 2147: return "ReflectorMagnification";
/* 1343 */         case 2148: return "LampMirrorPosition";
/* 1344 */         case 2149: return "FocusDepth";
/* 1345 */         case 2150: return "MicroscopeType";
/* 1346 */         case 2151: return "Objective Working Distance";
/* 1347 */         case 2152: return "ReflectedLightApertureGoSpeed";
/* 1348 */         case 2153: return "External Shutter";
/* 1349 */         case 2154: return "ObjectiveImmersionStop";
/* 1350 */         case 2155: return "Focus Start Speed";
/* 1351 */         case 2156: return "Focus Acceleration";
/* 1352 */         case 2157: return "ReflectedLightFieldstop";
/* 1353 */         case 2158: return "ReflectedLightFieldstopGoSpeed";
/* 1354 */         case 2159: return "ReflectedLightFilter 1";
/* 1355 */         case 2160: return "ReflectedLightFilter 2";
/* 1356 */         case 2161: return "ReflectedLightFilter1Position";
/* 1357 */         case 2162: return "ReflectedLightFilter2Position";
/* 1358 */         case 2163: return "TransmittedLightAttenuator";
/* 1359 */         case 2164: return "ReflectedLightAttenuator";
/* 1360 */         case 2165: return "Transmitted Light Shutter";
/* 1361 */         case 2166: return "TransmittedLightAttenuatorGoSpeed";
/* 1362 */         case 2167: return "ReflectedLightAttenuatorGoSpeed";
/* 1363 */         case 2176: return "TransmittedLightVirtualFilterPosition";
/* 1364 */         case 2177: return "TransmittedLightVirtualFilter";
/* 1365 */         case 2178: return "ReflectedLightVirtualFilterPosition";
/* 1366 */         case 2179: return "ReflectedLightVirtualFilter";
/* 1367 */         case 2180: return "ReflectedLightHalogenLampMode";
/* 1368 */         case 2181: return "ReflectedLightHalogenLampVoltage";
/* 1369 */         case 2182: return "ReflectedLightHalogenLampColorTemperature";
/* 1370 */         case 2183: return "ContrastManagerMode";
/* 1371 */         case 2184: return "Dazzle Protection Active";
/* 1372 */         case 2195: return "Zoom";
/* 1373 */         case 2196: return "ZoomGoSpeed";
/* 1374 */         case 2197: return "LightZoom";
/* 1375 */         case 2198: return "LightZoomGoSpeed";
/* 1376 */         case 2199: return "LightZoomCoupled";
/* 1377 */         case 2200: return "TransmittedLightHalogenLampMode";
/* 1378 */         case 2201: return "TransmittedLightHalogenLampVoltage";
/* 1379 */         case 2202: return "TransmittedLightHalogenLampColorTemperature";
/* 1380 */         case 2203: return "Reflected Coldlight Mode";
/* 1381 */         case 2204: return "Reflected Coldlight Intensity";
/* 1382 */         case 2205: return "Reflected Coldlight Color Temperature";
/* 1383 */         case 2206: return "Transmitted Coldlight Mode";
/* 1384 */         case 2207: return "Transmitted Coldlight Intensity";
/* 1385 */         case 2208: return "Transmitted Coldlight Color Temperature";
/* 1386 */         case 2209: return "Infinityspace Portchanger Position";
/* 1387 */         case 2210: return "Beamsplitter Infinity Space";
/* 1388 */         case 2211: return "TwoTv VisCamChanger Position";
/* 1389 */         case 2212: return "Beamsplitter Ocular";
/* 1390 */         case 2213: return "TwoTv CamerasChanger Position";
/* 1391 */         case 2214: return "Beamsplitter Cameras";
/* 1392 */         case 2215: return "Ocular Shutter";
/* 1393 */         case 2216: return "TwoTv CamerasChangerCube";
/* 1394 */         case 2217: return "LightWaveLength";
/* 1395 */         case 2218: return "Ocular Magnification";
/* 1396 */         case 2219: return "Camera Adapter Magnification";
/* 1397 */         case 2220: return "Microscope Port";
/* 1398 */         case 2221: return "Ocular Total Magnification";
/* 1399 */         case 2222: return "Field of View";
/* 1400 */         case 2223: return "Ocular";
/* 1401 */         case 2224: return "CameraAdapter";
/* 1402 */         case 2225: return "StageJoystickEnabled";
/* 1403 */         case 2226: return "ContrastManager Contrast Method";
/* 1404 */         case 2229: return "CamerasChanger Beamsplitter Type";
/* 1405 */         case 2235: return "Rearport Slider Position";
/* 1406 */         case 2236: return "Rearport Source";
/* 1407 */         case 2237: return "Beamsplitter Type Infinity Space";
/* 1408 */         case 2238: return "Fluorescence Attenuator";
/* 1409 */         case 2239: return "Fluorescence Attenuator Position";
/* 1410 */         case 2247: return "tag_ID_2247";
/* 1411 */         case 2252: return "tag_ID_2252";
/* 1412 */         case 2253: return "tag_ID_2253";
/* 1413 */         case 2254: return "tag_ID_2254";
/* 1414 */         case 2255: return "tag_ID_2255";
/* 1415 */         case 2256: return "tag_ID_2256";
/* 1416 */         case 2257: return "tag_ID_2257";
/* 1417 */         case 2258: return "tag_ID_2258";
/* 1418 */         case 2259: return "tag_ID_2259";
/* 1419 */         case 2260: return "tag_ID_2260";
/* 1420 */         case 2261: return "Objective ID";
/* 1421 */         case 2262: return "Reflector ID";
/* 1422 */         case 2307: return "Camera Framestart Left";
/* 1423 */         case 2308: return "Camera Framestart Top";
/* 1424 */         case 2309: return "Camera Frame Width";
/* 1425 */         case 2310: return "Camera Frame Height";
/* 1426 */         case 2311: return "Camera Binning";
/* 1427 */         case 2312: return "CameraFrameFull";
/* 1428 */         case 2313: return "CameraFramePixelDistance";
/* 1429 */         case 2318: return "DataFormatUseScaling";
/* 1430 */         case 2319: return "CameraFrameImageOrientation";
/* 1431 */         case 2320: return "VideoMonochromeSignalType";
/* 1432 */         case 2321: return "VideoColorSignalType";
/* 1433 */         case 2322: return "MeteorChannelInput";
/* 1434 */         case 2323: return "MeteorChannelSync";
/* 1435 */         case 2324: return "WhiteBalanceEnabled";
/* 1436 */         case 2325: return "CameraWhiteBalanceRed";
/* 1437 */         case 2326: return "CameraWhiteBalanceGreen";
/* 1438 */         case 2327: return "CameraWhiteBalanceBlue";
/* 1439 */         case 2331: return "CameraFrameScalingFactor";
/* 1440 */         case 2562: return "Meteor Camera Type";
/* 1441 */         case 2564: return "Exposure Time [ms]";
/* 1442 */         case 2568: return "CameraExposureTimeAutoCalculate";
/* 1443 */         case 2569: return "Meteor Gain Value";
/* 1444 */         case 2571: return "Meteor Gain Automatic";
/* 1445 */         case 2572: return "MeteorAdjustHue";
/* 1446 */         case 2573: return "MeteorAdjustSaturation";
/* 1447 */         case 2574: return "MeteorAdjustRedLow";
/* 1448 */         case 2575: return "MeteorAdjustGreenLow";
/* 1449 */         case 2576: return "Meteor Blue Low";
/* 1450 */         case 2577: return "MeteorAdjustRedHigh";
/* 1451 */         case 2578: return "MeteorAdjustGreenHigh";
/* 1452 */         case 2579: return "MeteorBlue High";
/* 1453 */         case 2582: return "CameraExposureTimeCalculationControl";
/* 1454 */         case 2585: return "AxioCamFadingCorrectionEnable";
/* 1455 */         case 2587: return "CameraLiveImage";
/* 1456 */         case 2588: return "CameraLiveEnabled";
/* 1457 */         case 2589: return "LiveImageSyncObjectName";
/* 1458 */         case 2590: return "CameraLiveSpeed";
/* 1459 */         case 2591: return "CameraImage";
/* 1460 */         case 2592: return "CameraImageWidth";
/* 1461 */         case 2593: return "CameraImageHeight";
/* 1462 */         case 2594: return "CameraImagePixelType";
/* 1463 */         case 2595: return "CameraImageShMemoryName";
/* 1464 */         case 2596: return "CameraLiveImageWidth";
/* 1465 */         case 2597: return "CameraLiveImageHeight";
/* 1466 */         case 2598: return "CameraLiveImagePixelType";
/* 1467 */         case 2599: return "CameraLiveImageShMemoryName";
/* 1468 */         case 2600: return "CameraLiveMaximumSpeed";
/* 1469 */         case 2601: return "CameraLiveBinning";
/* 1470 */         case 2602: return "CameraLiveGainValue";
/* 1471 */         case 2603: return "CameraLiveExposureTimeValue";
/* 1472 */         case 2604: return "CameraLiveScalingFactor";
/* 1473 */         case 2817: return "Image Index U";
/* 1474 */         case 2818: return "Image Index V";
/* 1475 */         case 2819: return "Image Index Z";
/* 1476 */         case 2820: return "Image Channel Index";
/* 1477 */         case 2821: return "Image Index T";
/* 1478 */         case 2822: return "ImageTile Index";
/* 1479 */         case 2823: return "Image acquisition Index";
/* 1480 */         case 2824: return "ImageCount Tiles";
/* 1481 */         case 2825: return "ImageCount A";
/* 1482 */         case 2827: return "Image Index S";
/* 1483 */         case 2828: return "Image Index Raw";
/* 1484 */         case 2832: return "Image Count Z";
/* 1485 */         case 2833: return "Image Count C";
/* 1486 */         case 2834: return "Image Count T";
/* 1487 */         case 2838: return "Number Rows";
/* 1488 */         case 2839: return "Number Columns";
/* 1489 */         case 2840: return "Image Count S";
/* 1490 */         case 2841: return "Original Stage Position X";
/* 1491 */         case 2842: return "Original Stage Position Y";
/* 1492 */         case 3088: return "LayerDrawFlags";
/* 1493 */         case 3334: return "RemainingTime";
/* 1494 */         case 3585: return "User Field 1";
/* 1495 */         case 3586: return "User Field 2";
/* 1496 */         case 3587: return "User Field 3";
/* 1497 */         case 3588: return "User Field 4";
/* 1498 */         case 3589: return "User Field 5";
/* 1499 */         case 3590: return "User Field 6";
/* 1500 */         case 3591: return "User Field 7";
/* 1501 */         case 3592: return "User Field 8";
/* 1502 */         case 3593: return "User Field 9";
/* 1503 */         case 3594: return "User Field 10";
/* 1504 */         case 3840: return "ID";
/* 1505 */         case 3841: return "Name";
/* 1506 */         case 3842: return "Value";
/* 1507 */         case 5501: return "PvCamClockingMode";
/* 1508 */         case 8193: return "Autofocus Status Report";
/* 1509 */         case 8194: return "Autofocus Position";
/* 1510 */         case 8195: return "Autofocus Position Offset";
/* 1511 */         case 8196: return "Autofocus Empty Field Threshold";
/* 1512 */         case 8197: return "Autofocus Calibration Name";
/* 1513 */         case 8198: return "Autofocus Current Calibration Item";
/* 1514 */         case 20478: return "tag_ID_20478";
/* 1515 */         case 65537: return "CameraFrameFullWidth";
/* 1516 */         case 65538: return "CameraFrameFullHeight";
/* 1517 */         case 65541: return "AxioCam Shutter Signal";
/* 1518 */         case 65542: return "AxioCam Delay Time";
/* 1519 */         case 65543: return "AxioCam Shutter Control";
/* 1520 */         case 65544: return "AxioCam BlackRefIsCalculated";
/* 1521 */         case 65545: return "AxioCam Black Reference";
/* 1522 */         case 65547: return "Camera Shading Correction";
/* 1523 */         case 65550: return "AxioCam Enhance Color";
/* 1524 */         case 65551: return "AxioCam NIR Mode";
/* 1525 */         case 65552: return "CameraShutterCloseDelay";
/* 1526 */         case 65553: return "CameraWhiteBalanceAutoCalculate";
/* 1527 */         case 65556: return "AxioCam NIR Mode Available";
/* 1528 */         case 65557: return "AxioCam Fading Correction Available";
/* 1529 */         case 65559: return "AxioCam Enhance Color Available";
/* 1530 */         case 65565: return "MeteorVideoNorm";
/* 1531 */         case 65566: return "MeteorAdjustWhiteReference";
/* 1532 */         case 65567: return "MeteorBlackReference";
/* 1533 */         case 65568: return "MeteorChannelInputCountMono";
/* 1534 */         case 65570: return "MeteorChannelInputCountRGB";
/* 1535 */         case 65571: return "MeteorEnableVCR";
/* 1536 */         case 65572: return "Meteor Brightness";
/* 1537 */         case 65573: return "Meteor Contrast";
/* 1538 */         case 65575: return "AxioCam Selector";
/* 1539 */         case 65576: return "AxioCam Type";
/* 1540 */         case 65577: return "AxioCam Info";
/* 1541 */         case 65580: return "AxioCam Resolution";
/* 1542 */         case 65581: return "AxioCam Color Model";
/* 1543 */         case 65582: return "AxioCam MicroScanning";
/* 1544 */         case 65585: return "Amplification Index";
/* 1545 */         case 65586: return "Device Command";
/* 1546 */         case 65587: return "BeamLocation";
/* 1547 */         case 65588: return "ComponentType";
/* 1548 */         case 65589: return "ControllerType";
/* 1549 */         case 65590: return "CameraWhiteBalanceCalculationRedPaint";
/* 1550 */         case 65591: return "CameraWhiteBalanceCalculationBluePaint";
/* 1551 */         case 65592: return "CameraWhiteBalanceSetRed";
/* 1552 */         case 65593: return "CameraWhiteBalanceSetGreen";
/* 1553 */         case 65594: return "CameraWhiteBalanceSetBlue";
/* 1554 */         case 65595: return "CameraWhiteBalanceSetTargetRed";
/* 1555 */         case 65596: return "CameraWhiteBalanceSetTargetGreen";
/* 1556 */         case 65597: return "CameraWhiteBalanceSetTargetBlue";
/* 1557 */         case 65598: return "ApotomeCamCalibrationMode";
/* 1558 */         case 65599: return "ApoTome Grid Position";
/* 1559 */         case 65600: return "ApotomeCamScannerPosition";
/* 1560 */         case 65601: return "ApoTome Full Phase Shift";
/* 1561 */         case 65602: return "ApoTome Grid Name";
/* 1562 */         case 65603: return "ApoTome Staining";
/* 1563 */         case 65604: return "ApoTome Processing Mode";
/* 1564 */         case 65605: return "ApotomeCamLiveCombineMode";
/* 1565 */         case 65606: return "ApoTome Filter Name";
/* 1566 */         case 65607: return "Apotome Filter Strength";
/* 1567 */         case 65608: return "ApotomeCamFilterHarmonics";
/* 1568 */         case 65609: return "ApoTome Grating Period";
/* 1569 */         case 65610: return "ApoTome Auto Shutter Used";
/* 1570 */         case 65611: return "Apotome Cam Status";
/* 1571 */         case 65612: return "ApotomeCamNormalize";
/* 1572 */         case 65613: return "ApotomeCamSettingsManager";
/* 1573 */         case 65614: return "DeepviewCamSupervisorMode";
/* 1574 */         case 65615: return "DeepView Processing";
/* 1575 */         case 65616: return "DeepviewCamFilterName";
/* 1576 */         case 65617: return "DeepviewCamStatus";
/* 1577 */         case 65618: return "DeepviewCamSettingsManager";
/* 1578 */         case 65619: return "DeviceScalingName";
/* 1579 */         case 65620: return "CameraShadingIsCalculated";
/* 1580 */         case 65621: return "CameraShadingCalculationName";
/* 1581 */         case 65622: return "CameraShadingAutoCalculate";
/* 1582 */         case 65623: return "CameraTriggerAvailable";
/* 1583 */         case 65626: return "CameraShutterAvailable";
/* 1584 */         case 65627: return "AxioCam ShutterMicroScanningEnable";
/* 1585 */         case 65628: return "ApotomeCamLiveFocus";
/* 1586 */         case 65629: return "DeviceInitStatus";
/* 1587 */         case 65630: return "DeviceErrorStatus";
/* 1588 */         case 65631: return "ApotomeCamSliderInGridPosition";
/* 1589 */         case 65632: return "Orca NIR Mode Used";
/* 1590 */         case 65633: return "Orca Analog Gain";
/* 1591 */         case 65634: return "Orca Analog Offset";
/* 1592 */         case 65635: return "Orca Binning";
/* 1593 */         case 65636: return "Orca Bit Depth";
/* 1594 */         case 65637: return "ApoTome Averaging Count";
/* 1595 */         case 65638: return "DeepView DoF";
/* 1596 */         case 65639: return "DeepView EDoF";
/* 1597 */         case 65643: return "DeepView Slider Name";
/* 1598 */         case 65651: return "tag_ID_65651";
/* 1599 */         case 65652: return "tag_ID_65652";
/* 1600 */         case 65655: return "DeepView Slider Name";
/* 1601 */         case 65657: return "tag_ID_65657";
/* 1602 */         case 65658: return "tag_ID_65658";
/* 1603 */         case 65661: return "tag_ID_65661";
/* 1604 */         case 65662: return "tag_ID_65662";
/*      */         case 5439491:
/* 1606 */           return "Acquisition Software";
/* 1607 */         case 16777488: return "Excitation Wavelength";
/* 1608 */         case 16777489: return "Emission Wavelength";
/* 1609 */         case 101515267: return "File Name";
/*      */         case 101253123:
/*      */         case 101777411:
/* 1612 */           return "Image Name"; }
/* 1613 */        return "tag_ID_" + tagID;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   enum FeatureType
/*      */   {
/* 1628 */     UNKNOWN(-1, 0),
/* 1629 */     POINT(0, 1),
/* 1630 */     POINTS(1, 0),
/* 1631 */     LINE(2, 2),
/* 1632 */     CALIPER(3, 6),
/* 1633 */     DISTANCE(4, 6),
/* 1634 */     MULTIPLE_CALIPER(5, -4),
/* 1635 */     MULTIPLE_DISTANCE(5, -4),
/* 1636 */     ANGLE3(7, 4),
/* 1637 */     ANGLE4(8, 4),
/* 1638 */     CIRCLE(9, 2),
/* 1639 */     SCALE_BAR(10, 2),
/* 1640 */     POLYLINE_OPEN(12, -2),
/* 1641 */     ALIGNED_RECTANGLE(13, 5),
/* 1642 */     RECTANGLE(14, 5),
/* 1643 */     ELLIPSE(15, 5),
/* 1644 */     POLYLINE_CLOSED(16, -2),
/* 1645 */     TEXT(17, 5),
/* 1646 */     LENGTH(18, 6),
/* 1647 */     SPLINE_OPEN(19, -3),
/* 1648 */     SPLINE_CLOSED(20, -3),
/* 1649 */     LUT(21, 5),
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1654 */     MEAS_PROFILE(28, 2),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1661 */     MEAS_POINT(32, 1),
/* 1662 */     MEAS_POINTS(33, 0),
/* 1663 */     MEAS_LINE(34, 2),
/* 1664 */     MEAS_CALIPER(35, 6),
/* 1665 */     MEAS_DISTANCE(36, 6),
/* 1666 */     MEAS_MULTIPLE_CALIPER(37, -4),
/* 1667 */     MEAS_MULTIPLE_DISTANCE(38, -4),
/* 1668 */     MEAS_ANGLE3(39, 4),
/* 1669 */     MEAS_ANGLE4(40, 4),
/* 1670 */     MEAS_CIRCLE(41, 2),
/* 1671 */     MEAS_POLYLINE_OPEN(42, -2),
/* 1672 */     MEAS_ALIGNED_RECTANGLE(43, 5),
/* 1673 */     MEAS_RECTANGLE(44, 5),
/* 1674 */     MEAS_ELLIPSE(45, 5),
/* 1675 */     MEAS_POLYLINE_CLOSED(46, -2),
/* 1676 */     MEAS_LENGTH(48, 6),
/* 1677 */     MEAS_SPLINE_OPEN(49, -3),
/* 1678 */     MEAS_SPLINE_CLOSED(50, -3);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1687 */     private static final Map<Integer, FeatureType> lookup = new HashMap<Integer, FeatureType>(); private int value; private int points;
/*      */     
/*      */     static {
/* 1690 */       for (FeatureType d : EnumSet.<FeatureType>allOf(FeatureType.class)) {
/* 1691 */         lookup.put(Integer.valueOf(d.getValue()), d);
/*      */       }
/* 1693 */       lookup.put(Integer.valueOf(284), MEAS_PROFILE);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     FeatureType(int value, int points) {
/* 1700 */       this.value = value;
/* 1701 */       this.points = points;
/*      */     }
/*      */     public int getValue() {
/* 1704 */       return this.value;
/*      */     } public int getPoints() {
/* 1706 */       return this.points;
/*      */     }
/*      */     boolean checkPoints(int points) {
/* 1709 */       boolean status = false;
/* 1710 */       if (this.points == 0) {
/* 1711 */         status = true;
/* 1712 */       } else if (this.points > 0 && points == this.points) {
/* 1713 */         status = true;
/* 1714 */       } else if (this.points < 0 && points >= -this.points) {
/* 1715 */         status = true;
/* 1716 */       }  return status;
/*      */     }
/*      */     
/*      */     public static FeatureType get(int value) {
/* 1720 */       FeatureType ret = lookup.get(Integer.valueOf(value));
/* 1721 */       if (ret == null)
/* 1722 */         ret = UNKNOWN; 
/* 1723 */       return ret;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   enum DrawStyle
/*      */   {
/* 1732 */     NO_LINE(0),
/* 1733 */     SOLID(1),
/* 1734 */     DOT(3),
/* 1735 */     DASH(2),
/* 1736 */     DASH_DOT(4),
/* 1737 */     DASH_DOT_DOT(5);
/*      */     
/* 1739 */     private static final Map<Integer, DrawStyle> lookup = new HashMap<Integer, DrawStyle>(); private int value;
/*      */     
/*      */     static {
/* 1742 */       for (DrawStyle d : EnumSet.<DrawStyle>allOf(DrawStyle.class)) {
/* 1743 */         lookup.put(Integer.valueOf(d.getValue()), d);
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*      */     DrawStyle(int value) {
/* 1749 */       this.value = value;
/*      */     }
/*      */     public int getValue() {
/* 1752 */       return this.value;
/*      */     }
/*      */     public static DrawStyle get(int value) {
/* 1755 */       DrawStyle ret = lookup.get(Integer.valueOf(value));
/* 1756 */       if (ret == null)
/* 1757 */         ret = SOLID; 
/* 1758 */       return ret;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   enum FillStyle
/*      */   {
/* 1766 */     NONE(1),
/* 1767 */     SOLID(0),
/* 1768 */     HORIZONTAL_LINE(2),
/* 1769 */     VERTICAL_LINE(3),
/* 1770 */     DOWNWARDS_DIAGONAL(4),
/* 1771 */     UPWARDS_DIAGONAL(5),
/* 1772 */     CROSS(6),
/* 1773 */     DIAGONAL_CROSS(7);
/*      */     
/* 1775 */     private static final Map<Integer, FillStyle> lookup = new HashMap<Integer, FillStyle>(); private int value;
/*      */     
/*      */     static {
/* 1778 */       for (FillStyle f : EnumSet.<FillStyle>allOf(FillStyle.class)) {
/* 1779 */         lookup.put(Integer.valueOf(f.getValue()), f);
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*      */     FillStyle(int value) {
/* 1785 */       this.value = value;
/*      */     }
/*      */     public int getValue() {
/* 1788 */       return this.value;
/*      */     }
/*      */     public static FillStyle get(int value) {
/* 1791 */       FillStyle ret = lookup.get(Integer.valueOf(value));
/* 1792 */       if (ret == null)
/* 1793 */         ret = SOLID; 
/* 1794 */       return ret;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   enum LineEndStyle
/*      */   {
/* 1802 */     NONE(1),
/* 1803 */     ARROWS(5),
/* 1804 */     END_TICKS(2),
/* 1805 */     FILLED_ARROWS(3);
/*      */     
/* 1807 */     private static final Map<Integer, LineEndStyle> lookup = new HashMap<Integer, LineEndStyle>(); private int value;
/*      */     
/*      */     static {
/* 1810 */       for (LineEndStyle f : EnumSet.<LineEndStyle>allOf(LineEndStyle.class)) {
/* 1811 */         lookup.put(Integer.valueOf(f.getValue()), f);
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*      */     LineEndStyle(int value) {
/* 1817 */       this.value = value;
/*      */     }
/*      */     public int getValue() {
/* 1820 */       return this.value;
/*      */     }
/*      */     public static LineEndStyle get(int value) {
/* 1823 */       LineEndStyle ret = lookup.get(Integer.valueOf(value));
/* 1824 */       if (ret == null)
/* 1825 */         ret = ARROWS; 
/* 1826 */       return ret;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   enum PointStyle
/*      */   {
/* 1835 */     NONE(0),
/* 1836 */     PLUS(2),
/* 1837 */     CROSS(7),
/* 1838 */     SQUARE(1),
/* 1839 */     DIAMOND(3),
/* 1840 */     ASTERISK(4),
/* 1841 */     ARROW(5),
/* 1842 */     BAR(6),
/* 1843 */     FILLED_ARROW(8),
/* 1844 */     CROSSHAIR(9);
/*      */ 
/*      */     
/* 1847 */     private static final Map<Integer, PointStyle> lookup = new HashMap<Integer, PointStyle>(); private int value;
/*      */     
/*      */     static {
/* 1850 */       for (PointStyle f : EnumSet.<PointStyle>allOf(PointStyle.class)) {
/* 1851 */         lookup.put(Integer.valueOf(f.getValue()), f);
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*      */     PointStyle(int value) {
/* 1857 */       this.value = value;
/*      */     }
/*      */     public int getValue() {
/* 1860 */       return this.value;
/*      */     }
/*      */     public static PointStyle get(int value) {
/* 1863 */       PointStyle ret = lookup.get(Integer.valueOf(value));
/* 1864 */       if (ret == null)
/* 1865 */         ret = CROSS; 
/* 1866 */       return ret;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   enum LineEndPositions
/*      */   {
/* 1875 */     NONE(0),
/* 1876 */     LEFT(1),
/* 1877 */     RIGHT(2),
/* 1878 */     BOTH(3);
/*      */     
/* 1880 */     private static final Map<Integer, LineEndPositions> lookup = new HashMap<Integer, LineEndPositions>(); private int value;
/*      */     
/*      */     static {
/* 1883 */       for (LineEndPositions f : EnumSet.<LineEndPositions>allOf(LineEndPositions.class)) {
/* 1884 */         lookup.put(Integer.valueOf(f.getValue()), f);
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*      */     LineEndPositions(int value) {
/* 1890 */       this.value = value;
/*      */     }
/*      */     public int getValue() {
/* 1893 */       return this.value;
/*      */     }
/*      */     public static LineEndPositions get(int value) {
/* 1896 */       LineEndPositions ret = lookup.get(Integer.valueOf(value));
/* 1897 */       if (ret == null)
/* 1898 */         ret = NONE; 
/* 1899 */       return ret;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   enum TextAlignment
/*      */   {
/* 1910 */     LEFT(0),
/* 1911 */     CENTER(1),
/* 1912 */     RIGHT(2),
/* 1913 */     NONE(3);
/*      */     
/* 1915 */     private static final Map<Integer, TextAlignment> lookup = new HashMap<Integer, TextAlignment>(); private int value;
/*      */     
/*      */     static {
/* 1918 */       for (TextAlignment f : EnumSet.<TextAlignment>allOf(TextAlignment.class)) {
/* 1919 */         lookup.put(Integer.valueOf(f.getValue()), f);
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*      */     TextAlignment(int value) {
/* 1925 */       this.value = value;
/*      */     }
/*      */     public int getValue() {
/* 1928 */       return this.value;
/*      */     }
/*      */     public static TextAlignment get(int value) {
/* 1931 */       TextAlignment ret = lookup.get(Integer.valueOf(value));
/* 1932 */       if (ret == null)
/* 1933 */         ret = LEFT; 
/* 1934 */       return ret;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   enum Charset
/*      */   {
/* 1944 */     ANSI(0, "windows-1252"),
/* 1945 */     MAC_CHARSET(77, "MacRoman"),
/* 1946 */     SHIFTJIS_CHARSET(128, "x-MS932_0213"),
/* 1947 */     HANGUL_CHARSET(129, "x-windows-949"),
/* 1948 */     GB2313_CHARSET(134, "x-mswin-936"),
/* 1949 */     CHINESEBIG5_CHARSET(136, "x-windows-950"),
/* 1950 */     GREEK_CHARSET(161, "windows-1253"),
/* 1951 */     TURKISH_CHARSET(162, "windows-1254"),
/* 1952 */     VIETNAMESE_CHARSET(163, "CP-1258"),
/* 1953 */     HEBREW_CHARSET(177, "windows-1255"),
/* 1954 */     ARABIC_CHARSET(178, "windows-1256"),
/* 1955 */     BALTIC_CHARSET(186, "windows-1257"),
/* 1956 */     RUSSIAN_CHARSET(204, "windows-1251"),
/* 1957 */     THAI_CHARSET(222, "x-windows-874"),
/* 1958 */     EASTEUROPE_CHARSET(238, "windows-1250");
/*      */     
/* 1960 */     private static final Map<Integer, Charset> lookup = new HashMap<Integer, Charset>(); private int value; String name;
/*      */     
/*      */     static {
/* 1963 */       for (Charset f : EnumSet.<Charset>allOf(Charset.class)) {
/* 1964 */         lookup.put(Integer.valueOf(f.getValue()), f);
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     Charset(int value, String name) {
/* 1971 */       this.value = value;
/* 1972 */       this.name = name;
/*      */     }
/*      */     public int getValue() {
/* 1975 */       return this.value;
/*      */     } public String getName() {
/* 1977 */       return this.name;
/*      */     }
/*      */     public static Charset get(int value) {
/* 1980 */       Charset ret = lookup.get(Integer.valueOf(value));
/* 1981 */       if (ret == null)
/* 1982 */         ret = ANSI; 
/* 1983 */       return ret;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   class Shape
/*      */   {
/* 2015 */     int id = 0;
/* 2016 */     BaseZeissReader.FeatureType type = BaseZeissReader.FeatureType.UNKNOWN; int unknown1;
/*      */     int unknown2;
/*      */     int unknown3;
/* 2019 */     int x1 = 0; int y1 = 0; int x2 = 0; int y2 = 0; int width = 0; int height = 0; int unknown4;
/*      */     int unknown5;
/*      */     int unknown6;
/*      */     int unknown7;
/* 2023 */     byte fb = -1;
/* 2024 */     int fillColour = BaseZeissReader.parseColor(this.fb, this.fb, this.fb);
/* 2025 */     int textColour = BaseZeissReader.parseColor(this.fb, this.fb, this.fb);
/* 2026 */     int drawColour = BaseZeissReader.parseColor(this.fb, this.fb, this.fb);
/* 2027 */     int lineWidth = 1;
/* 2028 */     BaseZeissReader.DrawStyle drawStyle = BaseZeissReader.DrawStyle.NO_LINE;
/* 2029 */     BaseZeissReader.FillStyle fillStyle = BaseZeissReader.FillStyle.NONE; int unknown8; int unknown10; int unknown11; int unknown12; int unknown13; int unknown14;
/*      */     int unknown15;
/*      */     int unknown16;
/*      */     int unknown17;
/*      */     int unknown18;
/*      */     int unknown19;
/* 2035 */     BaseZeissReader.LineEndStyle lineEndStyle = BaseZeissReader.LineEndStyle.NONE;
/* 2036 */     BaseZeissReader.PointStyle pointStyle = BaseZeissReader.PointStyle.CROSS;
/* 2037 */     int lineEndSize = 10;
/* 2038 */     BaseZeissReader.LineEndPositions lineEndPositions = BaseZeissReader.LineEndPositions.NONE;
/*      */     
/*      */     String fontName;
/* 2041 */     int fontSize = 10;
/* 2042 */     int fontWeight = 300;
/*      */     boolean bold = false;
/*      */     boolean italic = false;
/*      */     boolean underline = false;
/*      */     boolean strikeout = false;
/* 2047 */     BaseZeissReader.Charset charset = BaseZeissReader.Charset.ANSI;
/* 2048 */     BaseZeissReader.TextAlignment textAlignment = BaseZeissReader.TextAlignment.LEFT;
/*      */     
/*      */     String name;
/*      */     
/*      */     String text;
/*      */     
/*      */     BaseZeissReader.Tag tagID;
/*      */     
/*      */     boolean displayTag;
/*      */     int handleSize;
/* 2058 */     int pointCount = 0;
/*      */     double[] points;
/*      */     
/*      */     public String toString() {
/* 2062 */       String s = new String();
/* 2063 */       s = s + "  SHAPE: " + this.id;
/* 2064 */       s = s + "    Type=" + this.type;
/* 2065 */       s = s + "    Unknown1=" + Long.toHexString(this.unknown1 & 0xFFFFFFFFL) + " Unknown2=" + Long.toHexString(this.unknown2 & 0xFFFFFFFFL) + " Unknown3=" + Long.toHexString(this.unknown3 & 0xFFFFFFFFL) + "\n";
/* 2066 */       s = s + "    Bbox=" + this.x1 + "," + this.y1 + "  " + this.x2 + "," + this.y2 + "\n";
/* 2067 */       s = s + "    Unknown4=" + Long.toHexString(this.unknown4 & 0xFFFFFFFFL) + " Unknown5=" + Long.toHexString(this.unknown5 & 0xFFFFFFFFL) + " Unknown6=" + Long.toHexString(this.unknown6 & 0xFFFFFFFFL) + " Unknown7=" + Long.toHexString(this.unknown7 & 0xFFFFFFFFL) + "\n";
/* 2068 */       s = s + "    Unknown8=" + Long.toHexString(this.unknown8 & 0xFFFFFFFFL) + "\n";
/* 2069 */       s = s + "    Unknown10=" + Long.toHexString(this.unknown10 & 0xFFFFFFFFL) + " Unknown11=" + Long.toHexString(this.unknown11 & 0xFFFFFFFFL) + " Unknown12=" + Long.toHexString(this.unknown12 & 0xFFFFFFFFL) + "\n";
/* 2070 */       s = s + "    Unknown13=" + Long.toHexString(this.unknown13 & 0xFFFFFFFFL) + " Unknown14=" + Long.toHexString(this.unknown14 & 0xFFFFFFFFL) + " Unknown15=" + Long.toHexString(this.unknown15 & 0xFFFFFFFFL) + " Unknown16=" + Long.toHexString(this.unknown16 & 0xFFFFFFFFL) + "\n";
/* 2071 */       s = s + "    Unknown17=" + Long.toHexString(this.unknown17 & 0xFFFFFFFFL) + " Unknown18=" + Long.toHexString(this.unknown18 & 0xFFFFFFFFL) + " Unknown19=" + Long.toHexString(this.unknown19 & 0xFFFFFFFFL) + "\n";
/* 2072 */       s = s + "    fillColour=" + Long.toHexString(this.fillColour & 0xFFFFFFFFL) + " textColour=" + Long.toHexString(this.textColour & 0xFFFFFFFFL) + " drawColour=" + Long.toHexString(this.drawColour & 0xFFFFFFFFL) + "\n";
/*      */ 
/*      */       
/* 2075 */       s = s + "    drawStyle=" + this.drawStyle + " fillStyle=" + this.fillStyle + " lineEndStyle=" + this.lineEndStyle + " lineEndSize=" + this.lineEndSize + " lineEndPositions=" + this.lineEndPositions + "\n";
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2080 */       s = s + "displayTag=" + this.displayTag + "\n";
/* 2081 */       s = s + "  fontName=" + this.fontName + " size=" + this.fontSize + " weight=" + this.fontWeight + " bold=" + this.bold + " italic=" + this.italic + " underline=" + this.underline + " strikeout=" + this.strikeout + " alignment=" + this.textAlignment + " charset=" + this.charset + "\n";
/* 2082 */       s = s + "  name: " + this.name + "\n";
/* 2083 */       s = s + "  text: " + this.text + "\n";
/*      */       
/* 2085 */       s = s + "  tagID: " + this.tagID.getKey() + "\n";
/* 2086 */       s = s + "  handleSize:" + this.handleSize + "\n";
/* 2087 */       s = s + "  pointCount:" + this.pointCount + "\n    ";
/* 2088 */       for (double point : this.points)
/* 2089 */         s = s + point + ", "; 
/* 2090 */       s = s + "\n";
/* 2091 */       return s;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   class Layer
/*      */   {
/*      */     int key;
/*      */     
/*      */     String flags;
/*      */     
/*      */     public String name;
/*      */     
/* 2104 */     public ArrayList<BaseZeissReader.Shape> shapes = new ArrayList<BaseZeissReader.Shape>();
/*      */     
/*      */     public String toString() {
/* 2107 */       String s = new String();
/* 2108 */       s = s + "LAYER: " + this.key;
/* 2109 */       if (this.name != null)
/* 2110 */         s = s + " (" + this.name + ")"; 
/* 2111 */       s = s + "\n";
/* 2112 */       for (BaseZeissReader.Shape shape : this.shapes) {
/* 2113 */         s = s + shape;
/*      */       }
/* 2115 */       return s;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   protected static int parseColor(byte r, byte g, byte b) {
/* 2121 */     return (r & 0xFF) << 24 | (g & 0xFF) << 16 | (b & 0xFF) << 8;
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/in/BaseZeissReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */