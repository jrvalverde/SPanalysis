/*     */ package loci.formats.in;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import loci.common.DateTools;
/*     */ import loci.formats.FormatException;
/*     */ import loci.formats.FormatTools;
/*     */ import loci.formats.IFormatReader;
/*     */ import loci.formats.MetadataTools;
/*     */ import loci.formats.meta.MetadataStore;
/*     */ import loci.formats.tiff.IFD;
/*     */ import loci.formats.tiff.IFDList;
/*     */ import loci.formats.tiff.PhotoInterp;
/*     */ import loci.formats.tiff.TiffCompression;
/*     */ import loci.formats.tiff.TiffRational;
/*     */ import ome.xml.model.primitives.PositiveFloat;
/*     */ import ome.xml.model.primitives.Timestamp;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BaseTiffReader
/*     */   extends MinimalTiffReader
/*     */ {
/*  74 */   protected static final Logger LOGGER = LoggerFactory.getLogger(BaseTiffReader.class);
/*     */ 
/*     */   
/*  77 */   public static final String[] DATE_FORMATS = new String[] { "yyyy:MM:dd HH:mm:ss", "dd/MM/yyyy HH:mm:ss.SS", "MM/dd/yyyy hh:mm:ss.SSS aa", "yyyyMMdd HH:mm:ss.SSS", "yyyy/MM/dd HH:mm:ss" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BaseTiffReader(String name, String suffix) {
/*  88 */     super(name, suffix);
/*     */   }
/*     */   
/*     */   public BaseTiffReader(String name, String[] suffixes) {
/*  92 */     super(name, suffixes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initMetadata() throws FormatException, IOException {
/*  99 */     initStandardMetadata();
/* 100 */     initMetadataStore();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initStandardMetadata() throws FormatException, IOException {
/* 111 */     if (getMetadataOptions().getMetadataLevel() == MetadataLevel.MINIMUM) {
/*     */       return;
/*     */     }
/*     */     
/* 115 */     for (int i = 0; i < this.ifds.size(); i++) {
/* 116 */       put("PageName #" + i, (IFD)this.ifds.get(i), 285);
/*     */     }
/*     */     
/* 119 */     IFD firstIFD = (IFD)this.ifds.get(0);
/* 120 */     put("ImageWidth", firstIFD, 256);
/* 121 */     put("ImageLength", firstIFD, 257);
/* 122 */     put("BitsPerSample", firstIFD, 258);
/*     */ 
/*     */ 
/*     */     
/* 126 */     if (((IFD)this.ifds.get(0)).containsKey(Integer.valueOf(34665))) {
/* 127 */       IFDList exifIFDs = this.tiffParser.getExifIFDs();
/* 128 */       if (exifIFDs.size() > 0) {
/* 129 */         IFD exif = (IFD)exifIFDs.get(0);
/* 130 */         this.tiffParser.fillInIFD(exif);
/* 131 */         for (Integer key : exif.keySet()) {
/* 132 */           int k = key.intValue();
/* 133 */           addGlobalMeta(getExifTagName(k), exif.get(key));
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 138 */     TiffCompression comp = firstIFD.getCompression();
/* 139 */     put("Compression", comp.getCodecName());
/*     */     
/* 141 */     PhotoInterp photo = firstIFD.getPhotometricInterpretation();
/* 142 */     String photoInterp = photo.getName();
/* 143 */     String metaDataPhotoInterp = photo.getMetadataType();
/* 144 */     put("PhotometricInterpretation", photoInterp);
/* 145 */     put("MetaDataPhotometricInterpretation", metaDataPhotoInterp);
/*     */     
/* 147 */     putInt("CellWidth", firstIFD, 264);
/* 148 */     putInt("CellLength", firstIFD, 265);
/*     */     
/* 150 */     int or = firstIFD.getIFDIntValue(274);
/*     */ 
/*     */     
/* 153 */     if (or == 8) {
/* 154 */       put("ImageWidth", firstIFD, 257);
/* 155 */       put("ImageLength", firstIFD, 256);
/*     */     } 
/*     */     
/* 158 */     String orientation = null;
/*     */     
/* 160 */     switch (or) {
/*     */       case 1:
/* 162 */         orientation = "1st row -> top; 1st column -> left";
/*     */         break;
/*     */       case 2:
/* 165 */         orientation = "1st row -> top; 1st column -> right";
/*     */         break;
/*     */       case 3:
/* 168 */         orientation = "1st row -> bottom; 1st column -> right";
/*     */         break;
/*     */       case 4:
/* 171 */         orientation = "1st row -> bottom; 1st column -> left";
/*     */         break;
/*     */       case 5:
/* 174 */         orientation = "1st row -> left; 1st column -> top";
/*     */         break;
/*     */       case 6:
/* 177 */         orientation = "1st row -> right; 1st column -> top";
/*     */         break;
/*     */       case 7:
/* 180 */         orientation = "1st row -> right; 1st column -> bottom";
/*     */         break;
/*     */       case 8:
/* 183 */         orientation = "1st row -> left; 1st column -> bottom";
/*     */         break;
/*     */     } 
/* 186 */     put("Orientation", orientation);
/* 187 */     putInt("SamplesPerPixel", firstIFD, 277);
/*     */     
/* 189 */     put("Software", firstIFD, 305);
/* 190 */     put("Instrument Make", firstIFD, 271);
/* 191 */     put("Instrument Model", firstIFD, 272);
/* 192 */     put("Document Name", firstIFD, 269);
/* 193 */     put("DateTime", firstIFD, 306);
/* 194 */     put("Artist", firstIFD, 315);
/*     */     
/* 196 */     put("HostComputer", firstIFD, 316);
/* 197 */     put("Copyright", firstIFD, 33432);
/*     */     
/* 199 */     put("NewSubfileType", firstIFD, 254);
/*     */     
/* 201 */     int thresh = firstIFD.getIFDIntValue(263);
/* 202 */     String threshholding = null;
/* 203 */     switch (thresh) {
/*     */       case 1:
/* 205 */         threshholding = "No dithering or halftoning";
/*     */         break;
/*     */       case 2:
/* 208 */         threshholding = "Ordered dithering or halftoning";
/*     */         break;
/*     */       case 3:
/* 211 */         threshholding = "Randomized error diffusion";
/*     */         break;
/*     */     } 
/* 214 */     put("Threshholding", threshholding);
/*     */     
/* 216 */     int fill = firstIFD.getIFDIntValue(266);
/* 217 */     String fillOrder = null;
/* 218 */     switch (fill) {
/*     */       case 1:
/* 220 */         fillOrder = "Pixels with lower column values are stored in the higher order bits of a byte";
/*     */         break;
/*     */       
/*     */       case 2:
/* 224 */         fillOrder = "Pixels with lower column values are stored in the lower order bits of a byte";
/*     */         break;
/*     */     } 
/*     */     
/* 228 */     put("FillOrder", fillOrder);
/*     */     
/* 230 */     putInt("Make", firstIFD, 271);
/* 231 */     putInt("Model", firstIFD, 272);
/* 232 */     putInt("MinSampleValue", firstIFD, 280);
/* 233 */     putInt("MaxSampleValue", firstIFD, 281);
/* 234 */     putInt("XResolution", firstIFD, 282);
/* 235 */     putInt("YResolution", firstIFD, 283);
/*     */     
/* 237 */     int planar = firstIFD.getIFDIntValue(284);
/* 238 */     String planarConfig = null;
/* 239 */     switch (planar) {
/*     */       case 1:
/* 241 */         planarConfig = "Chunky";
/*     */         break;
/*     */       case 2:
/* 244 */         planarConfig = "Planar";
/*     */         break;
/*     */     } 
/* 247 */     put("PlanarConfiguration", planarConfig);
/*     */     
/* 249 */     putInt("XPosition", firstIFD, 286);
/* 250 */     putInt("YPosition", firstIFD, 287);
/* 251 */     putInt("FreeOffsets", firstIFD, 288);
/* 252 */     putInt("FreeByteCounts", firstIFD, 289);
/* 253 */     putInt("GrayResponseUnit", firstIFD, 290);
/* 254 */     putInt("GrayResponseCurve", firstIFD, 291);
/* 255 */     putInt("T4Options", firstIFD, 292);
/* 256 */     putInt("T6Options", firstIFD, 293);
/*     */     
/* 258 */     int res = firstIFD.getIFDIntValue(296);
/* 259 */     String resUnit = null;
/* 260 */     switch (res) {
/*     */       case 1:
/* 262 */         resUnit = "None";
/*     */         break;
/*     */       case 2:
/* 265 */         resUnit = "Inch";
/*     */         break;
/*     */       case 3:
/* 268 */         resUnit = "Centimeter";
/*     */         break;
/*     */     } 
/* 271 */     put("ResolutionUnit", resUnit);
/*     */     
/* 273 */     putInt("PageNumber", firstIFD, 297);
/* 274 */     putInt("TransferFunction", firstIFD, 301);
/*     */     
/* 276 */     int predict = firstIFD.getIFDIntValue(317);
/* 277 */     String predictor = null;
/* 278 */     switch (predict) {
/*     */       case 1:
/* 280 */         predictor = "No prediction scheme";
/*     */         break;
/*     */       case 2:
/* 283 */         predictor = "Horizontal differencing";
/*     */         break;
/*     */     } 
/* 286 */     put("Predictor", predictor);
/*     */     
/* 288 */     putInt("WhitePoint", firstIFD, 318);
/* 289 */     putInt("PrimaryChromacities", firstIFD, 319);
/*     */     
/* 291 */     putInt("HalftoneHints", firstIFD, 321);
/* 292 */     putInt("TileWidth", firstIFD, 322);
/* 293 */     putInt("TileLength", firstIFD, 323);
/* 294 */     putInt("TileOffsets", firstIFD, 324);
/* 295 */     putInt("TileByteCounts", firstIFD, 325);
/*     */     
/* 297 */     int ink = firstIFD.getIFDIntValue(332);
/* 298 */     String inkSet = null;
/* 299 */     switch (ink) {
/*     */       case 1:
/* 301 */         inkSet = "CMYK";
/*     */         break;
/*     */       case 2:
/* 304 */         inkSet = "Other";
/*     */         break;
/*     */     } 
/* 307 */     put("InkSet", inkSet);
/*     */     
/* 309 */     putInt("InkNames", firstIFD, 333);
/* 310 */     putInt("NumberOfInks", firstIFD, 334);
/* 311 */     putInt("DotRange", firstIFD, 336);
/* 312 */     put("TargetPrinter", firstIFD, 337);
/* 313 */     putInt("ExtraSamples", firstIFD, 338);
/*     */     
/* 315 */     int fmt = firstIFD.getIFDIntValue(339);
/* 316 */     String sampleFormat = null;
/* 317 */     switch (fmt) {
/*     */       case 1:
/* 319 */         sampleFormat = "unsigned integer";
/*     */         break;
/*     */       case 2:
/* 322 */         sampleFormat = "two's complement signed integer";
/*     */         break;
/*     */       case 3:
/* 325 */         sampleFormat = "IEEE floating point";
/*     */         break;
/*     */       case 4:
/* 328 */         sampleFormat = "undefined";
/*     */         break;
/*     */     } 
/* 331 */     put("SampleFormat", sampleFormat);
/*     */     
/* 333 */     putInt("SMinSampleValue", firstIFD, 340);
/* 334 */     putInt("SMaxSampleValue", firstIFD, 341);
/* 335 */     putInt("TransferRange", firstIFD, 342);
/*     */     
/* 337 */     int jpeg = firstIFD.getIFDIntValue(512);
/* 338 */     String jpegProc = null;
/* 339 */     switch (jpeg) {
/*     */       case 1:
/* 341 */         jpegProc = "baseline sequential process";
/*     */         break;
/*     */       case 14:
/* 344 */         jpegProc = "lossless process with Huffman coding";
/*     */         break;
/*     */     } 
/* 347 */     put("JPEGProc", jpegProc);
/*     */     
/* 349 */     putInt("JPEGInterchangeFormat", firstIFD, 513);
/* 350 */     putInt("JPEGRestartInterval", firstIFD, 515);
/*     */     
/* 352 */     putInt("JPEGLosslessPredictors", firstIFD, 517);
/* 353 */     putInt("JPEGPointTransforms", firstIFD, 518);
/* 354 */     putInt("JPEGQTables", firstIFD, 519);
/* 355 */     putInt("JPEGDCTables", firstIFD, 520);
/* 356 */     putInt("JPEGACTables", firstIFD, 521);
/* 357 */     putInt("YCbCrCoefficients", firstIFD, 529);
/*     */     
/* 359 */     int ycbcr = firstIFD.getIFDIntValue(530);
/* 360 */     String subSampling = null;
/* 361 */     switch (ycbcr) {
/*     */       case 1:
/* 363 */         subSampling = "chroma image dimensions = luma image dimensions";
/*     */         break;
/*     */       case 2:
/* 366 */         subSampling = "chroma image dimensions are half the luma image dimensions";
/*     */         break;
/*     */       
/*     */       case 4:
/* 370 */         subSampling = "chroma image dimensions are 1/4 the luma image dimensions";
/*     */         break;
/*     */     } 
/*     */     
/* 374 */     put("YCbCrSubSampling", subSampling);
/*     */     
/* 376 */     putInt("YCbCrPositioning", firstIFD, 531);
/* 377 */     putInt("ReferenceBlackWhite", firstIFD, 532);
/*     */ 
/*     */     
/* 380 */     int[] q = firstIFD.getBitsPerSample();
/* 381 */     int bps = q[0];
/* 382 */     int numC = q.length;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 387 */     if (photo == PhotoInterp.RGB_PALETTE || photo == PhotoInterp.CFA_ARRAY) {
/* 388 */       numC = 3;
/*     */     }
/*     */     
/* 391 */     put("BitsPerSample", bps);
/* 392 */     put("NumberOfChannels", numC);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initMetadataStore() throws FormatException {
/* 405 */     LOGGER.info("Populating OME metadata");
/*     */ 
/*     */     
/* 408 */     MetadataStore store = makeFilterMetadata();
/*     */     
/* 410 */     IFD firstIFD = (IFD)this.ifds.get(0);
/* 411 */     IFD exif = null;
/*     */     
/* 413 */     if (((IFD)this.ifds.get(0)).containsKey(Integer.valueOf(34665))) {
/*     */       try {
/* 415 */         IFDList exifIFDs = this.tiffParser.getExifIFDs();
/* 416 */         if (exifIFDs.size() > 0) {
/* 417 */           exif = (IFD)exifIFDs.get(0);
/*     */         }
/* 419 */         this.tiffParser.fillInIFD(exif);
/*     */       }
/* 421 */       catch (IOException e) {
/* 422 */         LOGGER.debug("Could not read EXIF IFDs", e);
/*     */       } 
/*     */     }
/*     */     
/* 426 */     MetadataTools.populatePixels(store, (IFormatReader)this, (exif != null));
/*     */ 
/*     */ 
/*     */     
/* 430 */     String creationDate = getImageCreationDate();
/* 431 */     String date = DateTools.formatDate(creationDate, DATE_FORMATS);
/* 432 */     if (creationDate != null && date == null) {
/* 433 */       LOGGER.warn("unknown creation date format: {}", creationDate);
/*     */     }
/* 435 */     creationDate = date;
/*     */ 
/*     */ 
/*     */     
/* 439 */     if (creationDate != null) {
/* 440 */       store.setImageAcquisitionDate(new Timestamp(creationDate), 0);
/*     */     }
/*     */     
/* 443 */     if (getMetadataOptions().getMetadataLevel() != MetadataLevel.MINIMUM) {
/*     */       
/* 445 */       String artist = firstIFD.getIFDTextValue(315);
/*     */       
/* 447 */       if (artist != null) {
/* 448 */         String firstName = null, lastName = null;
/* 449 */         int ndx = artist.indexOf(" ");
/* 450 */         if (ndx < 0) { lastName = artist; }
/*     */         else
/* 452 */         { firstName = artist.substring(0, ndx);
/* 453 */           lastName = artist.substring(ndx + 1); }
/*     */         
/* 455 */         String email = firstIFD.getIFDStringValue(316);
/* 456 */         store.setExperimenterFirstName(firstName, 0);
/* 457 */         store.setExperimenterLastName(lastName, 0);
/* 458 */         store.setExperimenterEmail(email, 0);
/* 459 */         store.setExperimenterID(MetadataTools.createLSID("Experimenter", new int[] { 0 }), 0);
/*     */       } 
/*     */       
/* 462 */       store.setImageDescription(firstIFD.getComment(), 0);
/*     */ 
/*     */ 
/*     */       
/* 466 */       double pixX = firstIFD.getXResolution();
/* 467 */       double pixY = firstIFD.getYResolution();
/*     */       
/* 469 */       PositiveFloat sizeX = FormatTools.getPhysicalSizeX(Double.valueOf(pixX));
/* 470 */       PositiveFloat sizeY = FormatTools.getPhysicalSizeY(Double.valueOf(pixY));
/*     */       
/* 472 */       if (sizeX != null) {
/* 473 */         store.setPixelsPhysicalSizeX(sizeX, 0);
/*     */       }
/* 475 */       if (sizeY != null) {
/* 476 */         store.setPixelsPhysicalSizeY(sizeY, 0);
/*     */       }
/* 478 */       store.setPixelsPhysicalSizeZ(null, 0);
/*     */       
/* 480 */       if (exif != null && 
/* 481 */         exif.containsKey(Integer.valueOf(33434))) {
/* 482 */         Object exp = exif.get(Integer.valueOf(33434));
/* 483 */         if (exp instanceof TiffRational) {
/* 484 */           Double exposure = Double.valueOf(((TiffRational)exp).doubleValue());
/* 485 */           for (int i = 0; i < getImageCount(); i++) {
/* 486 */             store.setPlaneExposureTime(exposure, 0, i);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getImageCreationDate() {
/* 499 */     Object o = ((IFD)this.ifds.get(0)).getIFDValue(306);
/* 500 */     if (o instanceof String) return (String)o; 
/* 501 */     if (o instanceof String[]) return ((String[])o)[0]; 
/* 502 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void put(String key, Object value) {
/* 512 */     if (value == null)
/* 513 */       return;  if (value instanceof String) value = ((String)value).trim(); 
/* 514 */     addGlobalMeta(key, value);
/*     */   }
/*     */   
/*     */   protected void put(String key, int value) {
/* 518 */     if (value == -1)
/* 519 */       return;  addGlobalMeta(key, value);
/*     */   }
/*     */   
/*     */   protected void put(String key, boolean value) {
/* 523 */     put(key, new Boolean(value));
/*     */   }
/* 525 */   protected void put(String key, byte value) { put(key, new Byte(value)); }
/* 526 */   protected void put(String key, char value) { put(key, new Character(value)); }
/* 527 */   protected void put(String key, double value) { put(key, new Double(value)); }
/* 528 */   protected void put(String key, float value) { put(key, new Float(value)); }
/* 529 */   protected void put(String key, long value) { put(key, new Long(value)); } protected void put(String key, short value) {
/* 530 */     put(key, new Short(value));
/*     */   }
/*     */   protected void put(String key, IFD ifd, int tag) {
/* 533 */     put(key, ifd.getIFDValue(tag));
/*     */   }
/*     */   
/*     */   protected void putInt(String key, IFD ifd, int tag) {
/* 537 */     put(key, ifd.getIFDIntValue(tag));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initFile(String id) throws FormatException, IOException {
/* 544 */     super.initFile(id);
/* 545 */     initMetadata();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getExifTagName(int tag) {
/* 551 */     return IFD.getIFDTagName(tag);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/in/BaseTiffReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */