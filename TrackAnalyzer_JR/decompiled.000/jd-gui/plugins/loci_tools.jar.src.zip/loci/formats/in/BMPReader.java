/*     */ package loci.formats.in;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import loci.common.RandomAccessInputStream;
/*     */ import loci.formats.FormatException;
/*     */ import loci.formats.FormatReader;
/*     */ import loci.formats.FormatTools;
/*     */ import loci.formats.IFormatReader;
/*     */ import loci.formats.ImageTools;
/*     */ import loci.formats.MetadataTools;
/*     */ import loci.formats.UnsupportedCompressionException;
/*     */ import loci.formats.codec.BitBuffer;
/*     */ import loci.formats.meta.MetadataStore;
/*     */ import ome.xml.model.primitives.PositiveFloat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BMPReader
/*     */   extends FormatReader
/*     */ {
/*     */   public static final String BMP_MAGIC_STRING = "BM";
/*     */   private static final int RAW = 0;
/*     */   private static final int RLE_8 = 1;
/*     */   private static final int RLE_4 = 2;
/*     */   private static final int RGB_MASK = 3;
/*     */   private int bpp;
/*     */   private byte[][] palette;
/*     */   private int compression;
/*     */   private long global;
/*     */   private boolean invertY = false;
/*     */   
/*     */   public BMPReader() {
/*  96 */     super("Windows Bitmap", "bmp");
/*  97 */     this.domains = new String[] { "Graphics" };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isThisType(RandomAccessInputStream stream) throws IOException {
/* 104 */     int blockLen = 2;
/* 105 */     if (!FormatTools.validStream(stream, 2, false)) return false; 
/* 106 */     return stream.readString(2).startsWith("BM");
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[][] get8BitLookupTable() throws FormatException, IOException {
/* 111 */     FormatTools.assertId(this.currentId, true, 1);
/* 112 */     return this.palette;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] openBytes(int no, byte[] buf, int x, int y, int w, int h) throws FormatException, IOException {
/* 121 */     FormatTools.checkPlaneParameters((IFormatReader)this, no, buf.length, x, y, w, h);
/*     */     
/* 123 */     if (this.compression != 0 && this.in.length() < FormatTools.getPlaneSize((IFormatReader)this)) {
/* 124 */       throw new UnsupportedCompressionException(this.compression + " not supported");
/*     */     }
/*     */     
/* 127 */     int rowsToSkip = this.invertY ? y : (getSizeY() - h + y);
/* 128 */     int rowLength = getSizeX() * (isIndexed() ? 1 : getSizeC());
/* 129 */     this.in.seek(this.global + (rowsToSkip * rowLength));
/*     */     
/* 131 */     int pad = rowLength * this.bpp / 8 % 2;
/* 132 */     if (pad == 0) { pad = rowLength * this.bpp / 8 % 4; }
/* 133 */     else { pad *= getSizeC(); }
/* 134 */      int planeSize = getSizeX() * getSizeC() * h;
/* 135 */     if (this.bpp >= 8) { planeSize *= this.bpp / 8; }
/* 136 */     else { planeSize /= 8 / this.bpp; }
/* 137 */      planeSize += pad * h;
/* 138 */     if (planeSize + this.in.getFilePointer() > this.in.length()) {
/* 139 */       planeSize -= pad * h;
/*     */ 
/*     */       
/* 142 */       if ((planeSize + getSizeY()) + this.in.getFilePointer() <= this.in.length()) {
/* 143 */         pad = 1;
/* 144 */         planeSize += h;
/*     */       } else {
/*     */         
/* 147 */         pad = 0;
/*     */       } 
/*     */     } 
/*     */     
/* 151 */     this.in.skipBytes(rowsToSkip * pad);
/*     */     
/* 153 */     byte[] rawPlane = new byte[planeSize];
/* 154 */     this.in.read(rawPlane);
/*     */     
/* 156 */     BitBuffer bb = new BitBuffer(rawPlane);
/*     */     
/* 158 */     int effectiveC = (this.palette != null && (this.palette[0]).length > 0) ? 1 : getSizeC();
/* 159 */     for (int row = h - 1; row >= 0; row--) {
/* 160 */       int rowIndex = this.invertY ? (h - 1 - row) : row;
/* 161 */       bb.skipBits((x * this.bpp * effectiveC));
/* 162 */       for (int i = 0; i < w * effectiveC; i++) {
/* 163 */         if (this.bpp <= 8) {
/* 164 */           buf[rowIndex * w * effectiveC + i] = (byte)(bb.getBits(this.bpp) & 0xFF);
/*     */         } else {
/*     */           
/* 167 */           for (int b = 0; b < this.bpp / 8; b++) {
/* 168 */             buf[this.bpp / 8 * (rowIndex * w * effectiveC + i) + b] = (byte)(bb.getBits(8) & 0xFF);
/*     */           }
/*     */         } 
/*     */       } 
/*     */       
/* 173 */       if (row > 0) {
/* 174 */         bb.skipBits(((getSizeX() - w - x) * this.bpp * effectiveC + pad * 8));
/*     */       }
/*     */     } 
/*     */     
/* 178 */     if (getRGBChannelCount() > 1) {
/* 179 */       ImageTools.bgrToRgb(buf, isInterleaved(), 1, getRGBChannelCount());
/*     */     }
/* 181 */     return buf;
/*     */   }
/*     */ 
/*     */   
/*     */   public void close(boolean fileOnly) throws IOException {
/* 186 */     super.close(fileOnly);
/* 187 */     if (!fileOnly) {
/* 188 */       this.bpp = this.compression = 0;
/* 189 */       this.global = 0L;
/* 190 */       this.palette = (byte[][])null;
/* 191 */       this.invertY = false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initFile(String id) throws FormatException, IOException {
/* 199 */     super.initFile(id);
/* 200 */     this.in = new RandomAccessInputStream(id);
/*     */     
/* 202 */     LOGGER.info("Reading bitmap header");
/*     */     
/* 204 */     this.in.order(true);
/*     */ 
/*     */ 
/*     */     
/* 208 */     addGlobalMeta("Magic identifier", this.in.readString(2));
/*     */     
/* 210 */     addGlobalMeta("File size (in bytes)", this.in.readInt());
/* 211 */     this.in.skipBytes(4);
/* 212 */     this.global = this.in.readInt();
/*     */ 
/*     */ 
/*     */     
/* 216 */     this.in.skipBytes(4);
/*     */ 
/*     */ 
/*     */     
/* 220 */     (this.core[0]).sizeX = this.in.readInt();
/* 221 */     (this.core[0]).sizeY = this.in.readInt();
/*     */     
/* 223 */     if (getSizeX() < 1) {
/* 224 */       LOGGER.trace("Invalid width: {}; using the absolute value", Integer.valueOf(getSizeX()));
/* 225 */       (this.core[0]).sizeX = Math.abs(getSizeX());
/*     */     } 
/* 227 */     if (getSizeY() < 1) {
/* 228 */       LOGGER.trace("Invalid height: {}; using the absolute value", Integer.valueOf(getSizeY()));
/* 229 */       (this.core[0]).sizeY = Math.abs(getSizeY());
/* 230 */       this.invertY = true;
/*     */     } 
/*     */     
/* 233 */     addGlobalMeta("Color planes", this.in.readShort());
/* 234 */     this.bpp = this.in.readShort();
/*     */     
/* 236 */     this.compression = this.in.readInt();
/*     */     
/* 238 */     this.in.skipBytes(4);
/* 239 */     int pixelSizeX = this.in.readInt();
/* 240 */     int pixelSizeY = this.in.readInt();
/* 241 */     int nColors = this.in.readInt();
/* 242 */     if (nColors == 0 && this.bpp != 32 && this.bpp != 24) {
/* 243 */       nColors = (this.bpp < 8) ? (1 << this.bpp) : 256;
/*     */     }
/* 245 */     this.in.skipBytes(4);
/*     */ 
/*     */ 
/*     */     
/* 249 */     if (nColors != 0 && this.bpp == 8)
/* 250 */     { this.palette = new byte[3][256];
/*     */       
/* 252 */       for (int i = 0; i < nColors; i++) {
/* 253 */         for (int j = this.palette.length - 1; j >= 0; j--) {
/* 254 */           this.palette[j][i] = this.in.readByte();
/*     */         }
/* 256 */         this.in.skipBytes(1);
/*     */       }
/*     */        }
/* 259 */     else if (nColors != 0) { this.in.skipBytes(nColors * 4); }
/*     */     
/* 261 */     LOGGER.info("Populating metadata");
/*     */     
/* 263 */     (this.core[0]).sizeC = (this.bpp != 24) ? 1 : 3;
/* 264 */     if (this.bpp == 32) (this.core[0]).sizeC = 4; 
/* 265 */     if (this.bpp > 8) this.bpp /= getSizeC();
/*     */     
/* 267 */     switch (this.bpp) {
/*     */       case 16:
/* 269 */         (this.core[0]).pixelType = 3;
/*     */         break;
/*     */       case 32:
/* 272 */         (this.core[0]).pixelType = 5;
/*     */         break;
/*     */       default:
/* 275 */         (this.core[0]).pixelType = 1;
/*     */         break;
/*     */     } 
/* 278 */     (this.core[0]).rgb = (getSizeC() > 1);
/* 279 */     (this.core[0]).littleEndian = true;
/* 280 */     (this.core[0]).interleaved = true;
/* 281 */     (this.core[0]).imageCount = 1;
/* 282 */     (this.core[0]).sizeZ = 1;
/* 283 */     (this.core[0]).sizeT = 1;
/* 284 */     (this.core[0]).dimensionOrder = "XYCTZ";
/* 285 */     (this.core[0]).metadataComplete = true;
/* 286 */     (this.core[0]).indexed = (this.palette != null);
/* 287 */     if (isIndexed()) {
/* 288 */       (this.core[0]).sizeC = 1;
/* 289 */       (this.core[0]).rgb = false;
/*     */     } 
/* 291 */     (this.core[0]).falseColor = false;
/*     */     
/* 293 */     if (getMetadataOptions().getMetadataLevel() != MetadataLevel.MINIMUM) {
/* 294 */       addGlobalMeta("Indexed color", (this.palette != null));
/* 295 */       addGlobalMeta("Image width", getSizeX());
/* 296 */       addGlobalMeta("Image height", getSizeY());
/* 297 */       addGlobalMeta("Bits per pixel", this.bpp);
/* 298 */       String comp = "invalid";
/*     */       
/* 300 */       switch (this.compression) {
/*     */         case 0:
/* 302 */           comp = "None";
/*     */           break;
/*     */         case 1:
/* 305 */           comp = "8 bit run length encoding";
/*     */           break;
/*     */         case 2:
/* 308 */           comp = "4 bit run length encoding";
/*     */           break;
/*     */         case 3:
/* 311 */           comp = "RGB bitmap with mask";
/*     */           break;
/*     */       } 
/*     */       
/* 315 */       addGlobalMeta("Compression type", comp);
/* 316 */       addGlobalMeta("X resolution", pixelSizeX);
/* 317 */       addGlobalMeta("Y resolution", pixelSizeY);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 322 */     MetadataStore store = makeFilterMetadata();
/* 323 */     MetadataTools.populatePixels(store, (IFormatReader)this);
/*     */     
/* 325 */     if (getMetadataOptions().getMetadataLevel() != MetadataLevel.MINIMUM) {
/*     */ 
/*     */ 
/*     */       
/* 329 */       double correctedX = (pixelSizeX == 0) ? 0.0D : (1000000.0D / pixelSizeX);
/* 330 */       double correctedY = (pixelSizeY == 0) ? 0.0D : (1000000.0D / pixelSizeY);
/*     */       
/* 332 */       PositiveFloat sizeX = FormatTools.getPhysicalSizeX(Double.valueOf(correctedX));
/* 333 */       PositiveFloat sizeY = FormatTools.getPhysicalSizeY(Double.valueOf(correctedY));
/* 334 */       if (sizeX != null) {
/* 335 */         store.setPixelsPhysicalSizeX(sizeX, 0);
/*     */       }
/* 337 */       if (sizeY != null)
/* 338 */         store.setPixelsPhysicalSizeY(sizeY, 0); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/in/BMPReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */