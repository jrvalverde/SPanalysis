/*     */ package loci.formats.in;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import loci.common.Location;
/*     */ import loci.common.RandomAccessInputStream;
/*     */ import loci.formats.FormatException;
/*     */ import loci.formats.FormatReader;
/*     */ import loci.formats.FormatTools;
/*     */ import loci.formats.IFormatReader;
/*     */ import loci.formats.MetadataTools;
/*     */ import loci.formats.meta.MetadataStore;
/*     */ import ome.xml.model.primitives.PositiveFloat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnalyzeReader
/*     */   extends FormatReader
/*     */ {
/*     */   private static final int MAGIC = 348;
/*     */   private int pixelOffset;
/*     */   private RandomAccessInputStream pixelFile;
/*     */   private String pixelsFilename;
/*     */   
/*     */   public AnalyzeReader() {
/*  69 */     super("Analyze 7.5", new String[] { "img", "hdr" });
/*  70 */     this.domains = new String[] { "Medical Imaging" };
/*  71 */     this.hasCompanionFiles = true;
/*  72 */     this.datasetDescription = "One .img file and one similarly-named .hdr file";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isThisType(String name, boolean open) {
/*  79 */     if (!super.isThisType(name, open)) return false; 
/*  80 */     if (!open) return false;
/*     */     
/*  82 */     String headerFile = checkSuffix(name, "hdr") ? name : null;
/*  83 */     String extension = name.substring(name.lastIndexOf(".") + 1);
/*  84 */     name = name.substring(0, name.lastIndexOf("."));
/*  85 */     if (extension.equals("img")) { extension = "hdr"; }
/*  86 */     else if (extension.equals("IMG")) { extension = "HDR"; }
/*  87 */     else if (extension.equals("hdr")) { extension = "img"; }
/*  88 */     else if (extension.equals("HDR")) { extension = "IMG"; }
/*  89 */      if (extension.equalsIgnoreCase("hdr")) {
/*  90 */       headerFile = name + "." + extension;
/*     */     }
/*     */     
/*  93 */     boolean validHeader = false;
/*     */     try {
/*  95 */       RandomAccessInputStream headerStream = new RandomAccessInputStream(headerFile);
/*     */       
/*  97 */       validHeader = isThisType(headerStream);
/*  98 */       headerStream.close();
/*     */     }
/* 100 */     catch (IOException e) {}
/*     */     
/* 102 */     return ((new Location(name + "." + extension)).exists() && validHeader);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isThisType(RandomAccessInputStream stream) throws IOException {
/* 107 */     int blockLen = 4;
/* 108 */     if (!FormatTools.validStream(stream, 4, false)) return false; 
/* 109 */     stream.order(true);
/* 110 */     int checkLittleEndian = stream.readInt();
/* 111 */     stream.seek(stream.getFilePointer() - 4L);
/* 112 */     stream.order(false);
/* 113 */     int checkBigEndian = stream.readInt();
/* 114 */     return (checkLittleEndian == 348 || checkBigEndian == 348);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSingleFile(String id) throws FormatException, IOException {
/* 119 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] openBytes(int no, byte[] buf, int x, int y, int w, int h) throws FormatException, IOException {
/* 128 */     FormatTools.checkPlaneParameters((IFormatReader)this, no, buf.length, x, y, w, h);
/*     */     
/* 130 */     int planeSize = FormatTools.getPlaneSize((IFormatReader)this);
/* 131 */     this.pixelFile.seek((this.pixelOffset + no * planeSize));
/* 132 */     readPlane(this.pixelFile, x, y, w, h, buf);
/*     */     
/* 134 */     return buf;
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getSeriesUsedFiles(boolean noPixels) {
/* 139 */     FormatTools.assertId(this.currentId, true, 1);
/* 140 */     (new String[1])[0] = this.currentId; (new String[2])[0] = this.currentId; (new String[2])[1] = this.pixelsFilename; return noPixels ? new String[1] : new String[2];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int fileGroupOption(String id) throws FormatException, IOException {
/* 146 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public void close(boolean fileOnly) throws IOException {
/* 151 */     super.close(fileOnly);
/* 152 */     if (this.pixelFile != null) this.pixelFile.close(); 
/* 153 */     if (!fileOnly) {
/* 154 */       this.pixelOffset = 0;
/* 155 */       this.pixelFile = null;
/* 156 */       this.pixelsFilename = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initFile(String id) throws FormatException, IOException {
/* 165 */     if (id.endsWith(".img")) {
/* 166 */       LOGGER.info("Looking for header file");
/* 167 */       String header = id.substring(0, id.lastIndexOf(".")) + ".hdr";
/* 168 */       if ((new Location(header)).exists()) {
/* 169 */         setId(header);
/*     */         return;
/*     */       } 
/* 172 */       throw new FormatException("Header file not found.");
/*     */     } 
/*     */     
/* 175 */     super.initFile(id);
/* 176 */     this.in = new RandomAccessInputStream(id);
/* 177 */     this.pixelsFilename = id.substring(0, id.lastIndexOf(".")) + ".img";
/* 178 */     this.pixelFile = new RandomAccessInputStream(this.pixelsFilename);
/*     */     
/* 180 */     LOGGER.info("Reading header");
/*     */     
/* 182 */     int fileSize = this.in.readInt();
/* 183 */     boolean little = (fileSize != this.in.length());
/* 184 */     this.in.order(little);
/* 185 */     this.pixelFile.order(little);
/*     */     
/* 187 */     this.in.skipBytes(10);
/*     */     
/* 189 */     String imageName = this.in.readString(18);
/* 190 */     this.in.skipBytes(8);
/*     */     
/* 192 */     int ndims = this.in.readShort();
/*     */     
/* 194 */     int x = this.in.readShort();
/* 195 */     int y = this.in.readShort();
/* 196 */     int z = this.in.readShort();
/* 197 */     int t = this.in.readShort();
/*     */     
/* 199 */     this.in.skipBytes(20);
/*     */     
/* 201 */     int dataType = this.in.readShort();
/* 202 */     int nBitsPerPixel = this.in.readShort();
/*     */     
/* 204 */     String description = null;
/* 205 */     double voxelWidth = 0.0D, voxelHeight = 0.0D, sliceThickness = 0.0D, deltaT = 0.0D;
/*     */     
/* 207 */     if (getMetadataOptions().getMetadataLevel() != MetadataLevel.MINIMUM) {
/* 208 */       this.in.skipBytes(6);
/*     */       
/* 210 */       voxelWidth = this.in.readFloat();
/* 211 */       voxelHeight = this.in.readFloat();
/* 212 */       sliceThickness = this.in.readFloat();
/* 213 */       deltaT = this.in.readFloat();
/*     */       
/* 215 */       this.in.skipBytes(12);
/*     */       
/* 217 */       this.pixelOffset = (int)this.in.readFloat();
/* 218 */       this.in.skipBytes(12);
/*     */       
/* 220 */       float calibratedMax = this.in.readFloat();
/* 221 */       float calibratedMin = this.in.readFloat();
/* 222 */       float compressed = this.in.readFloat();
/* 223 */       float verified = this.in.readFloat();
/* 224 */       float pixelMax = this.in.readFloat();
/* 225 */       float pixelMin = this.in.readFloat();
/*     */       
/* 227 */       description = this.in.readString(80);
/* 228 */       String auxFile = this.in.readString(24);
/* 229 */       char orient = (char)this.in.readByte();
/* 230 */       String originator = this.in.readString(10);
/* 231 */       String generated = this.in.readString(10);
/* 232 */       String scannum = this.in.readString(10);
/* 233 */       String patientID = this.in.readString(10);
/* 234 */       String expDate = this.in.readString(10);
/* 235 */       String expTime = this.in.readString(10);
/*     */       
/* 237 */       this.in.skipBytes(3);
/*     */       
/* 239 */       int views = this.in.readInt();
/* 240 */       int volsAdded = this.in.readInt();
/* 241 */       int startField = this.in.readInt();
/* 242 */       int fieldSkip = this.in.readInt();
/* 243 */       int omax = this.in.readInt();
/* 244 */       int omin = this.in.readInt();
/* 245 */       int smax = this.in.readInt();
/* 246 */       int smin = this.in.readInt();
/*     */       
/* 248 */       addGlobalMeta("Database name", imageName);
/* 249 */       addGlobalMeta("Number of dimensions", ndims);
/* 250 */       addGlobalMeta("Data type", dataType);
/* 251 */       addGlobalMeta("Number of bits per pixel", nBitsPerPixel);
/* 252 */       addGlobalMeta("Voxel width", voxelWidth);
/* 253 */       addGlobalMeta("Voxel height", voxelHeight);
/* 254 */       addGlobalMeta("Slice thickness", sliceThickness);
/* 255 */       addGlobalMeta("Exposure time", deltaT);
/* 256 */       addGlobalMeta("Pixel offset", this.pixelOffset);
/* 257 */       addGlobalMeta("Calibrated maximum", calibratedMax);
/* 258 */       addGlobalMeta("Calibrated minimum", calibratedMin);
/* 259 */       addGlobalMeta("Compressed", compressed);
/* 260 */       addGlobalMeta("Verified", verified);
/* 261 */       addGlobalMeta("Pixel maximum", pixelMax);
/* 262 */       addGlobalMeta("Pixel minimum", pixelMin);
/* 263 */       addGlobalMeta("Description", description);
/* 264 */       addGlobalMeta("Auxiliary file", auxFile);
/* 265 */       addGlobalMeta("Orientation", orient);
/* 266 */       addGlobalMeta("Originator", originator);
/* 267 */       addGlobalMeta("Generated", generated);
/* 268 */       addGlobalMeta("Scan Number", scannum);
/* 269 */       addGlobalMeta("Patient ID", patientID);
/* 270 */       addGlobalMeta("Acquisition Date", expDate);
/* 271 */       addGlobalMeta("Acquisition Time", expTime);
/*     */     } else {
/*     */       
/* 274 */       this.in.skipBytes(34);
/* 275 */       this.pixelOffset = (int)this.in.readFloat();
/*     */     } 
/*     */     
/* 278 */     LOGGER.info("Populating core metadata");
/*     */     
/* 280 */     (this.core[0]).sizeX = x;
/* 281 */     (this.core[0]).sizeY = y;
/* 282 */     (this.core[0]).sizeZ = z;
/* 283 */     (this.core[0]).sizeT = t;
/* 284 */     (this.core[0]).sizeC = 1;
/* 285 */     if (getSizeZ() == 0) (this.core[0]).sizeZ = 1; 
/* 286 */     if (getSizeT() == 0) (this.core[0]).sizeT = 1;
/*     */     
/* 288 */     (this.core[0]).imageCount = getSizeZ() * getSizeT();
/* 289 */     (this.core[0]).rgb = false;
/* 290 */     (this.core[0]).interleaved = false;
/* 291 */     (this.core[0]).indexed = false;
/* 292 */     (this.core[0]).dimensionOrder = "XYZTC";
/*     */     
/* 294 */     switch (dataType) {
/*     */       case 1:
/*     */       case 2:
/* 297 */         (this.core[0]).pixelType = 1;
/*     */         break;
/*     */       case 4:
/* 300 */         (this.core[0]).pixelType = 2;
/*     */         break;
/*     */       case 8:
/* 303 */         (this.core[0]).pixelType = 4;
/*     */         break;
/*     */       case 16:
/* 306 */         (this.core[0]).pixelType = 6;
/*     */         break;
/*     */       case 64:
/* 309 */         (this.core[0]).pixelType = 7;
/*     */         break;
/*     */       case 128:
/* 312 */         (this.core[0]).pixelType = 1;
/* 313 */         (this.core[0]).sizeC = 3;
/* 314 */         (this.core[0]).rgb = true;
/* 315 */         (this.core[0]).interleaved = true;
/* 316 */         (this.core[0]).dimensionOrder = "XYCZT";
/*     */       default:
/* 318 */         throw new FormatException("Unsupported data type: " + dataType);
/*     */     } 
/*     */     
/* 321 */     LOGGER.info("Populating MetadataStore");
/*     */     
/* 323 */     MetadataStore store = makeFilterMetadata();
/* 324 */     MetadataTools.populatePixels(store, (IFormatReader)this);
/*     */     
/* 326 */     store.setImageName(imageName, 0);
/*     */     
/* 328 */     if (getMetadataOptions().getMetadataLevel() != MetadataLevel.MINIMUM) {
/* 329 */       store.setImageDescription(description, 0);
/*     */       
/* 331 */       PositiveFloat sizeX = FormatTools.getPhysicalSizeX(Double.valueOf(voxelWidth * 0.001D));
/* 332 */       PositiveFloat sizeY = FormatTools.getPhysicalSizeY(Double.valueOf(voxelHeight * 0.001D));
/* 333 */       PositiveFloat sizeZ = FormatTools.getPhysicalSizeZ(Double.valueOf(sliceThickness * 0.001D));
/*     */ 
/*     */       
/* 336 */       if (sizeX != null) {
/* 337 */         store.setPixelsPhysicalSizeX(sizeX, 0);
/*     */       }
/* 339 */       if (sizeY != null) {
/* 340 */         store.setPixelsPhysicalSizeY(sizeY, 0);
/*     */       }
/* 342 */       if (sizeZ != null) {
/* 343 */         store.setPixelsPhysicalSizeZ(sizeZ, 0);
/*     */       }
/*     */       
/* 346 */       store.setPixelsTimeIncrement(new Double(deltaT * 1000.0D), 0);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/in/AnalyzeReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */