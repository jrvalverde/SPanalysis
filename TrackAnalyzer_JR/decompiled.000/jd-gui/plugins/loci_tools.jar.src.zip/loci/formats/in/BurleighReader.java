/*     */ package loci.formats.in;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import loci.common.RandomAccessInputStream;
/*     */ import loci.formats.FormatException;
/*     */ import loci.formats.FormatReader;
/*     */ import loci.formats.FormatTools;
/*     */ import loci.formats.IFormatReader;
/*     */ import loci.formats.MetadataTools;
/*     */ import loci.formats.meta.MetadataStore;
/*     */ import ome.xml.model.primitives.PositiveFloat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BurleighReader
/*     */   extends FormatReader
/*     */ {
/*     */   private int pixelsOffset;
/*     */   
/*     */   public BurleighReader() {
/*  56 */     super("Burleigh", "img");
/*  57 */     this.domains = new String[] { "Scanning Electron Microscopy (SEM)" };
/*  58 */     this.suffixSufficient = false;
/*  59 */     this.suffixNecessary = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isThisType(RandomAccessInputStream stream) throws IOException {
/*  66 */     int blockLen = 4;
/*  67 */     if (!FormatTools.validStream(stream, 4, false)) return false; 
/*  68 */     byte[] magic = new byte[4];
/*  69 */     stream.read(magic);
/*  70 */     return (magic[0] == 102 && magic[1] == 102 && magic[3] == 64 && (magic[2] == 70 || magic[2] == 6));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] openBytes(int no, byte[] buf, int x, int y, int w, int h) throws FormatException, IOException {
/*  80 */     FormatTools.checkPlaneParameters((IFormatReader)this, no, buf.length, x, y, w, h);
/*     */     
/*  82 */     this.in.seek(this.pixelsOffset);
/*  83 */     readPlane(this.in, x, y, w, h, buf);
/*  84 */     return buf;
/*     */   }
/*     */ 
/*     */   
/*     */   public void close(boolean fileOnly) throws IOException {
/*  89 */     super.close(fileOnly);
/*  90 */     if (!fileOnly) {
/*  91 */       this.pixelsOffset = 0;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initFile(String id) throws FormatException, IOException {
/*  99 */     super.initFile(id);
/* 100 */     this.in = new RandomAccessInputStream(id);
/*     */     
/* 102 */     (this.core[0]).littleEndian = true;
/* 103 */     this.in.order(isLittleEndian());
/*     */     
/* 105 */     int version = (int)this.in.readFloat() - 1;
/*     */     
/* 107 */     (this.core[0]).sizeX = this.in.readShort();
/* 108 */     (this.core[0]).sizeY = this.in.readShort();
/*     */     
/* 110 */     double xSize = 0.0D, ySize = 0.0D, zSize = 0.0D;
/*     */     
/* 112 */     this.pixelsOffset = (version == 1) ? 8 : 260;
/*     */     
/* 114 */     if (getMetadataOptions().getMetadataLevel() != MetadataLevel.MINIMUM) {
/* 115 */       double timePerPixel = 0.0D;
/* 116 */       int mode = 0, gain = 0, mag = 0;
/* 117 */       double sampleVolts = 0.0D, tunnelCurrent = 0.0D;
/* 118 */       if (version == 1) {
/* 119 */         this.in.seek(this.in.length() - 40L);
/* 120 */         this.in.skipBytes(12);
/* 121 */         xSize = this.in.readInt();
/* 122 */         ySize = this.in.readInt();
/* 123 */         zSize = this.in.readInt();
/* 124 */         timePerPixel = (this.in.readShort() * 50);
/* 125 */         mag = this.in.readShort();
/*     */         
/* 127 */         switch (mag) {
/*     */           case 3:
/* 129 */             mag = 10;
/*     */             break;
/*     */           case 4:
/* 132 */             mag = 50;
/*     */             break;
/*     */           case 5:
/* 135 */             mag = 250;
/*     */             break;
/*     */         } 
/* 138 */         xSize /= mag;
/* 139 */         ySize /= mag;
/* 140 */         zSize /= mag;
/*     */         
/* 142 */         mode = this.in.readShort();
/* 143 */         gain = this.in.readShort();
/* 144 */         sampleVolts = (this.in.readFloat() / 1000.0F);
/* 145 */         tunnelCurrent = this.in.readFloat();
/*     */       }
/* 147 */       else if (version == 2) {
/* 148 */         this.in.skipBytes(14);
/* 149 */         xSize = this.in.readInt();
/* 150 */         ySize = this.in.readInt();
/* 151 */         zSize = this.in.readInt();
/* 152 */         mode = this.in.readShort();
/* 153 */         this.in.skipBytes(4);
/* 154 */         gain = this.in.readShort();
/* 155 */         timePerPixel = (this.in.readShort() * 50);
/* 156 */         this.in.skipBytes(12);
/* 157 */         sampleVolts = this.in.readFloat();
/* 158 */         tunnelCurrent = this.in.readFloat();
/* 159 */         addGlobalMeta("Force", this.in.readFloat());
/*     */       } 
/*     */       
/* 162 */       addGlobalMeta("Version", version);
/* 163 */       addGlobalMeta("Image mode", mode);
/* 164 */       addGlobalMeta("Z gain", gain);
/* 165 */       addGlobalMeta("Time per pixel (s)", timePerPixel);
/* 166 */       addGlobalMeta("Sample volts", sampleVolts);
/* 167 */       addGlobalMeta("Tunnel current", tunnelCurrent);
/* 168 */       addGlobalMeta("Magnification", mag);
/*     */     } 
/*     */     
/* 171 */     (this.core[0]).pixelType = 3;
/* 172 */     (this.core[0]).sizeZ = 1;
/* 173 */     (this.core[0]).sizeC = 1;
/* 174 */     (this.core[0]).sizeT = 1;
/* 175 */     (this.core[0]).imageCount = 1;
/* 176 */     (this.core[0]).dimensionOrder = "XYZCT";
/*     */     
/* 178 */     MetadataStore store = makeFilterMetadata();
/* 179 */     MetadataTools.populatePixels(store, (IFormatReader)this);
/*     */     
/* 181 */     if (getMetadataOptions().getMetadataLevel() != MetadataLevel.MINIMUM) {
/* 182 */       PositiveFloat sizeX = FormatTools.getPhysicalSizeX(Double.valueOf(xSize / getSizeX()));
/* 183 */       PositiveFloat sizeY = FormatTools.getPhysicalSizeY(Double.valueOf(ySize / getSizeY()));
/* 184 */       PositiveFloat sizeZ = FormatTools.getPhysicalSizeZ(Double.valueOf(zSize / getSizeZ()));
/* 185 */       if (sizeX != null) {
/* 186 */         store.setPixelsPhysicalSizeX(sizeX, 0);
/*     */       }
/* 188 */       if (sizeY != null) {
/* 189 */         store.setPixelsPhysicalSizeY(sizeY, 0);
/*     */       }
/* 191 */       if (sizeZ != null)
/* 192 */         store.setPixelsPhysicalSizeZ(sizeZ, 0); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/in/BurleighReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */