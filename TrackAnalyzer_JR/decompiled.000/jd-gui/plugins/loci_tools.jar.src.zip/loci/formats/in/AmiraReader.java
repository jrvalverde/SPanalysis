/*     */ package loci.formats.in;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Map;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import java.util.zip.InflaterInputStream;
/*     */ import loci.common.DataTools;
/*     */ import loci.common.RandomAccessInputStream;
/*     */ import loci.formats.FormatException;
/*     */ import loci.formats.FormatReader;
/*     */ import loci.formats.FormatTools;
/*     */ import loci.formats.IFormatReader;
/*     */ import loci.formats.MetadataTools;
/*     */ import loci.formats.meta.MetadataStore;
/*     */ import loci.formats.tools.AmiraParameters;
/*     */ import ome.xml.model.primitives.PositiveFloat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AmiraReader
/*     */   extends FormatReader
/*     */ {
/*     */   AmiraParameters parameters;
/*     */   long offsetOfFirstStream;
/*     */   PlaneReader planeReader;
/*     */   byte[][] lut;
/*     */   
/*     */   public AmiraReader() {
/*  74 */     super("Amira", new String[] { "am", "amiramesh", "grey", "hx", "labels" });
/*  75 */     this.domains = new String[] { "Unknown" };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getOptimalTileHeight() {
/*  82 */     FormatTools.assertId(this.currentId, true, 1);
/*  83 */     return getSizeY();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] openBytes(int no, byte[] buf, int x, int y, int w, int h) throws FormatException, IOException {
/*  92 */     FormatTools.checkPlaneParameters((IFormatReader)this, no, buf.length, x, y, w, h);
/*     */     
/*  94 */     int planeSize = FormatTools.getPlaneSize((IFormatReader)this);
/*  95 */     if (this.planeReader != null) {
/*     */       
/*  97 */       int bytesPerPixel = FormatTools.getBytesPerPixel(getPixelType());
/*  98 */       byte[] planeBuf = new byte[planeSize];
/*  99 */       this.planeReader.read(no, planeBuf);
/* 100 */       int srcWidth = this.parameters.width * bytesPerPixel;
/* 101 */       int destWidth = w * bytesPerPixel;
/* 102 */       for (int j = y; j < y + h; j++) {
/* 103 */         int src = j * srcWidth + x * bytesPerPixel;
/* 104 */         int dest = (j - y) * destWidth;
/* 105 */         System.arraycopy(planeBuf, src, buf, dest, destWidth);
/*     */       } 
/*     */     } else {
/*     */       
/* 109 */       this.in.seek(this.offsetOfFirstStream + no * planeSize);
/* 110 */       readPlane(this.in, x, y, w, h, buf);
/*     */     } 
/*     */     
/* 113 */     return buf;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initFile(String id) throws FormatException, IOException {
/* 120 */     super.initFile(id);
/* 121 */     this.in = new RandomAccessInputStream(id);
/*     */     
/* 123 */     this.parameters = new AmiraParameters(this.in);
/* 124 */     this.offsetOfFirstStream = this.in.getFilePointer();
/*     */     
/* 126 */     LOGGER.info("Populating metadata hashtable");
/*     */     
/* 128 */     addGlobalMeta("Image width", this.parameters.width);
/* 129 */     addGlobalMeta("Image height", this.parameters.height);
/* 130 */     addGlobalMeta("Number of planes", this.parameters.depth);
/* 131 */     addGlobalMeta("Bits per pixel", 8);
/*     */     
/* 133 */     LOGGER.info("Populating core metadata");
/*     */     
/* 135 */     int channelIndex = 1;
/* 136 */     while (this.parameters.getStreams().get("@" + channelIndex) != null) {
/* 137 */       channelIndex++;
/*     */     }
/*     */     
/* 140 */     (this.core[0]).sizeX = this.parameters.width;
/* 141 */     (this.core[0]).sizeY = this.parameters.height;
/* 142 */     (this.core[0]).sizeZ = this.parameters.depth;
/* 143 */     (this.core[0]).sizeT = 1;
/* 144 */     (this.core[0]).sizeC = channelIndex - 1;
/* 145 */     (this.core[0]).imageCount = getSizeZ() * getSizeC();
/* 146 */     (this.core[0]).littleEndian = this.parameters.littleEndian;
/* 147 */     (this.core[0]).dimensionOrder = "XYZCT";
/*     */     
/* 149 */     String streamType = this.parameters.streamTypes[0].toLowerCase();
/* 150 */     if (streamType.equals("byte")) {
/* 151 */       (this.core[0]).pixelType = 1;
/*     */     }
/* 153 */     else if (streamType.equals("short")) {
/* 154 */       (this.core[0]).pixelType = 2;
/* 155 */       addGlobalMeta("Bits per pixel", 16);
/*     */     }
/* 157 */     else if (streamType.equals("ushort")) {
/* 158 */       (this.core[0]).pixelType = 3;
/* 159 */       addGlobalMeta("Bits per pixel", 16);
/*     */     }
/* 161 */     else if (streamType.equals("int")) {
/* 162 */       (this.core[0]).pixelType = 4;
/* 163 */       addGlobalMeta("Bits per pixel", 32);
/*     */     }
/* 165 */     else if (streamType.equals("float")) {
/* 166 */       (this.core[0]).pixelType = 6;
/* 167 */       addGlobalMeta("Bits per pixel", 32);
/*     */     } else {
/*     */       
/* 170 */       LOGGER.warn("Assuming data type is byte");
/* 171 */       (this.core[0]).pixelType = 1;
/*     */     } 
/* 173 */     LOGGER.info("Populating metadata store");
/*     */     
/* 175 */     MetadataStore store = makeFilterMetadata();
/* 176 */     MetadataTools.populatePixels(store, (IFormatReader)this);
/*     */ 
/*     */ 
/*     */     
/* 180 */     if (getMetadataOptions().getMetadataLevel() != MetadataLevel.MINIMUM) {
/* 181 */       double pixelWidth = (this.parameters.x1 - this.parameters.x0) / (this.parameters.width - 1);
/*     */       
/* 183 */       double pixelHeight = (this.parameters.y1 - this.parameters.y0) / (this.parameters.height - 1);
/*     */ 
/*     */       
/* 186 */       double pixelDepth = (this.parameters.z1 - this.parameters.z0) / (this.parameters.depth - 1);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 191 */       addGlobalMeta("Pixels per meter (X)", 1000000.0D / pixelWidth);
/* 192 */       addGlobalMeta("Pixels per meter (Y)", 1000000.0D / pixelHeight);
/* 193 */       addGlobalMeta("Pixels per meter (Z)", 1000000.0D / pixelDepth);
/*     */       
/* 195 */       PositiveFloat sizeX = FormatTools.getPhysicalSizeX(Double.valueOf(pixelWidth));
/* 196 */       PositiveFloat sizeY = FormatTools.getPhysicalSizeY(Double.valueOf(pixelHeight));
/* 197 */       PositiveFloat sizeZ = FormatTools.getPhysicalSizeZ(Double.valueOf(pixelDepth));
/*     */       
/* 199 */       if (sizeX != null) {
/* 200 */         store.setPixelsPhysicalSizeX(sizeX, 0);
/*     */       }
/* 202 */       if (sizeY != null) {
/* 203 */         store.setPixelsPhysicalSizeY(sizeY, 0);
/*     */       }
/* 205 */       if (sizeZ != null) {
/* 206 */         store.setPixelsPhysicalSizeZ(sizeZ, 0);
/*     */       }
/*     */     } 
/*     */     
/* 210 */     if (this.parameters.ascii) {
/* 211 */       this.planeReader = new ASCII((this.core[0]).pixelType, this.parameters.width * this.parameters.height);
/*     */     }
/*     */ 
/*     */     
/* 215 */     int compressionType = 0;
/* 216 */     ArrayList<String> streamData = (ArrayList)this.parameters.getStreams().get("@1");
/* 217 */     if (streamData.size() > 2) {
/* 218 */       String compression = streamData.get(2);
/* 219 */       if (compression.startsWith("HxZip,")) {
/* 220 */         compressionType = 1;
/* 221 */         long size = Long.parseLong(compression.substring("HxZip,".length()));
/* 222 */         this.planeReader = new HxZip(size);
/*     */       }
/* 224 */       else if (compression.startsWith("HxByteRLE,")) {
/* 225 */         compressionType = 2;
/* 226 */         long size = Long.parseLong(compression.substring("HxByteRLE,".length()));
/*     */         
/* 228 */         this.planeReader = new HxRLE(this.parameters.depth, size);
/*     */       } 
/*     */     } 
/*     */     
/* 232 */     addGlobalMeta("Compression", compressionType);
/*     */     
/* 234 */     Map params = (Map)this.parameters.getMap().get("Parameters");
/* 235 */     if (params != null) {
/* 236 */       Map materials = (Map)params.get("Materials");
/* 237 */       if (materials != null) {
/* 238 */         this.lut = getLookupTable(materials);
/* 239 */         (this.core[0]).indexed = true;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isThisType(RandomAccessInputStream stream) throws IOException {
/* 246 */     if (!FormatTools.validStream(stream, 50, false)) return false; 
/* 247 */     String c = stream.readLine();
/*     */     
/* 249 */     Matcher amiraMeshDef = Pattern.compile("#\\s+AmiraMesh.*?(BINARY|ASCII)(-LITTLE-ENDIAN)*").matcher(c);
/*     */     
/* 251 */     return amiraMeshDef.find();
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[][] get8BitLookupTable() {
/* 256 */     FormatTools.assertId(this.currentId, true, 1);
/* 257 */     return this.lut;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   byte[][] getLookupTable(Map materials) throws FormatException {
/* 263 */     byte[][] result = new byte[3][256];
/* 264 */     int i = -1;
/* 265 */     for (Object label : materials.keySet()) {
/* 266 */       i++;
/* 267 */       Object object = materials.get(label);
/* 268 */       if (!(object instanceof Map)) {
/* 269 */         throw new FormatException("Invalid material: " + label);
/*     */       }
/* 271 */       Map material = (Map)object;
/* 272 */       object = material.get("Color");
/* 273 */       if (object == null)
/* 274 */         continue;  if (!(object instanceof Number[])) {
/* 275 */         throw new FormatException("Invalid material: " + label);
/*     */       }
/* 277 */       Number[] color = (Number[])object;
/* 278 */       if (color.length != 3) {
/* 279 */         throw new FormatException("Invalid color: " + color.length + " channels");
/*     */       }
/*     */       
/* 282 */       for (int j = 0; j < 3; j++) {
/* 283 */         result[j][i] = (byte)(int)(255.0F * color[j].floatValue());
/*     */       }
/*     */     } 
/* 286 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   static interface PlaneReader
/*     */   {
/*     */     byte[] read(int param1Int, byte[] param1ArrayOfbyte) throws FormatException, IOException;
/*     */   }
/*     */ 
/*     */   
/*     */   class ASCII
/*     */     implements PlaneReader
/*     */   {
/*     */     int pixelType;
/*     */     
/*     */     int bytesPerPixel;
/*     */     
/*     */     int pixelsPerPlane;
/*     */     
/*     */     long[] offsets;
/* 306 */     byte[] numberBuffer = new byte[32];
/*     */     
/*     */     ASCII(int pixelType, int pixelsPerPlane) {
/* 309 */       this.pixelType = pixelType;
/* 310 */       this.pixelsPerPlane = pixelsPerPlane;
/* 311 */       this.bytesPerPixel = FormatTools.getBytesPerPixel(pixelType);
/* 312 */       this.offsets = new long[AmiraReader.this.parameters.depth + 1];
/* 313 */       this.offsets[0] = AmiraReader.this.offsetOfFirstStream;
/*     */     }
/*     */     
/*     */     public byte[] read(int no, byte[] buf) throws FormatException, IOException {
/* 317 */       if (this.offsets[no] == 0L) {
/* 318 */         int i = no - 1;
/* 319 */         while (this.offsets[i] == 0L) {
/* 320 */           i--;
/*     */         }
/* 322 */         AmiraReader.this.in.seek(this.offsets[i]);
/* 323 */         while (i < no) {
/* 324 */           for (int k = 0; k < this.pixelsPerPlane; k++) {
/* 325 */             readNumberString();
/*     */           }
/* 327 */           this.offsets[++i] = AmiraReader.this.in.getFilePointer();
/*     */         } 
/*     */       } else {
/*     */         
/* 331 */         AmiraReader.this.in.seek(this.offsets[no]);
/*     */       } 
/* 333 */       for (int j = 0; j < this.pixelsPerPlane; j++) {
/* 334 */         int offset = j * this.bytesPerPixel;
/* 335 */         double number = readNumberString();
/* 336 */         long value = (this.pixelType == 7) ? Double.doubleToLongBits(number) : ((this.pixelType == 6) ? Float.floatToIntBits((float)number) : (long)number);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 341 */         DataTools.unpackBytes(value, buf, offset, this.bytesPerPixel, false);
/*     */       } 
/* 343 */       this.offsets[no + 1] = AmiraReader.this.in.getFilePointer();
/* 344 */       return buf;
/*     */     }
/*     */     
/*     */     double readNumberString() throws IOException {
/* 348 */       this.numberBuffer[0] = skipWhiteSpace();
/* 349 */       for (int i = 1;; i++) {
/* 350 */         byte c = AmiraReader.this.in.readByte();
/* 351 */         if ((c < 48 || c > 57) && c != 46) {
/* 352 */           return Double.parseDouble(new String(this.numberBuffer, 0, i, "UTF-8"));
/*     */         }
/*     */         
/* 355 */         this.numberBuffer[i] = c;
/*     */       } 
/*     */     }
/*     */     
/*     */     byte skipWhiteSpace() throws IOException {
/*     */       while (true) {
/* 361 */         byte c = AmiraReader.this.in.readByte();
/* 362 */         if (c != 32 && c != 9 && c != 10) {
/* 363 */           return c;
/*     */         }
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   class HxZip
/*     */     implements PlaneReader
/*     */   {
/*     */     long offsetOfStream;
/*     */     
/*     */     long compressedSize;
/*     */     
/*     */     int currentNo;
/*     */     int planeSize;
/*     */     InflaterInputStream decompressor;
/*     */     
/*     */     HxZip(long compressedSize) {
/* 382 */       this.compressedSize = compressedSize;
/* 383 */       this.planeSize = FormatTools.getPlaneSize((IFormatReader)AmiraReader.this);
/* 384 */       this.offsetOfStream = AmiraReader.this.offsetOfFirstStream;
/* 385 */       this.currentNo = Integer.MAX_VALUE;
/*     */     }
/*     */     
/*     */     void initDecompressor() throws IOException {
/* 389 */       this.currentNo = 0;
/* 390 */       AmiraReader.this.in.seek(this.offsetOfStream);
/* 391 */       this.decompressor = new InflaterInputStream((InputStream)AmiraReader.this.in);
/*     */     }
/*     */     
/*     */     public byte[] read(int no, byte[] buf) throws FormatException, IOException {
/* 395 */       if (no < this.currentNo) {
/* 396 */         initDecompressor();
/*     */       }
/* 398 */       for (; this.currentNo <= no; this.currentNo++) {
/* 399 */         int offset = 0, len = this.planeSize;
/* 400 */         while (len > 0) {
/* 401 */           int count = this.decompressor.read(buf, offset, len);
/* 402 */           if (count <= 0) return null; 
/* 403 */           offset += count;
/* 404 */           len -= count;
/*     */         } 
/*     */       } 
/* 407 */       return buf;
/*     */     }
/*     */   }
/*     */   
/*     */   class HxRLE
/*     */     implements PlaneReader {
/*     */     long compressedSize;
/*     */     long[] offsets;
/*     */     int[] internalOffsets;
/*     */     int currentNo;
/*     */     int maxOffsetIndex;
/*     */     int planeSize;
/* 419 */     long lastCodeOffset = 0L;
/*     */     
/*     */     HxRLE(int sliceCount, long compressedSize) {
/* 422 */       this.compressedSize = compressedSize;
/* 423 */       this.offsets = new long[sliceCount + 1];
/* 424 */       this.internalOffsets = new int[sliceCount + 1];
/* 425 */       this.offsets[0] = AmiraReader.this.offsetOfFirstStream;
/* 426 */       this.internalOffsets[0] = 0;
/* 427 */       this.planeSize = FormatTools.getPlaneSize((IFormatReader)AmiraReader.this);
/* 428 */       this.maxOffsetIndex = this.currentNo = 0;
/*     */     }
/*     */     
/*     */     void read(byte[] buf, int len) throws FormatException, IOException {
/* 432 */       int off = 0;
/* 433 */       while (len > 0 && AmiraReader.this.in.getFilePointer() < AmiraReader.this.in.length()) {
/* 434 */         this.lastCodeOffset = AmiraReader.this.in.getFilePointer();
/* 435 */         int insn = AmiraReader.this.in.readByte();
/* 436 */         if (insn < 0) {
/* 437 */           insn &= 0x7F;
/* 438 */           if (insn > len) {
/* 439 */             throw new FormatException("Slice " + this.currentNo + " is unaligned!");
/*     */           }
/* 441 */           while (insn > 0) {
/* 442 */             int count = AmiraReader.this.in.read(buf, off, insn);
/* 443 */             if (count < 0) throw new IOException("End of file!"); 
/* 444 */             insn -= count;
/* 445 */             len -= count;
/* 446 */             off += count;
/*     */           } 
/*     */           continue;
/*     */         } 
/* 450 */         if (insn > len)
/* 451 */         { this.internalOffsets[this.currentNo] = len;
/* 452 */           insn = len; }
/*     */         
/* 454 */         else if (insn == len) { this.lastCodeOffset += 2L; }
/* 455 */          if (off == 0 && this.currentNo > 0 && this.internalOffsets[this.currentNo - 1] > 0) {
/* 456 */           insn -= this.internalOffsets[this.currentNo - 1];
/*     */         }
/* 458 */         Arrays.fill(buf, off, off + insn, AmiraReader.this.in.readByte());
/* 459 */         len -= insn;
/* 460 */         off += insn;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public byte[] read(int no, byte[] buf) throws FormatException, IOException {
/* 466 */       if (this.maxOffsetIndex < no) {
/* 467 */         AmiraReader.this.in.seek(this.offsets[this.maxOffsetIndex]);
/* 468 */         while (this.maxOffsetIndex <= no) {
/* 469 */           Arrays.fill(buf, (byte)0);
/* 470 */           read(this.currentNo, buf);
/* 471 */           this.currentNo++;
/*     */         } 
/*     */       } else {
/*     */         
/* 475 */         AmiraReader.this.in.seek(this.offsets[no]);
/* 476 */         this.currentNo = no;
/* 477 */         Arrays.fill(buf, (byte)0);
/* 478 */         read(buf, this.planeSize);
/* 479 */         if (this.maxOffsetIndex == no) {
/* 480 */           this.offsets[++this.maxOffsetIndex] = this.lastCodeOffset;
/*     */         }
/*     */       } 
/* 483 */       return buf;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/in/AmiraReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */