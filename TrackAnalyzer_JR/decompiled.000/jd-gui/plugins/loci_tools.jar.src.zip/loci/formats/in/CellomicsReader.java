/*     */ package loci.formats.in;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import loci.common.Location;
/*     */ import loci.common.RandomAccessInputStream;
/*     */ import loci.formats.CoreMetadata;
/*     */ import loci.formats.FormatException;
/*     */ import loci.formats.FormatReader;
/*     */ import loci.formats.FormatTools;
/*     */ import loci.formats.IFormatReader;
/*     */ import loci.formats.MetadataTools;
/*     */ import loci.formats.UnsupportedCompressionException;
/*     */ import loci.formats.codec.ZlibCodec;
/*     */ import loci.formats.meta.MetadataStore;
/*     */ import ome.xml.model.enums.NamingConvention;
/*     */ import ome.xml.model.primitives.NonNegativeInteger;
/*     */ import ome.xml.model.primitives.PositiveFloat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CellomicsReader
/*     */   extends FormatReader
/*     */ {
/*     */   public static final int C01_MAGIC_BYTES = 16;
/*     */   private String[] files;
/*     */   private String channelCharacter;
/*     */   
/*     */   public CellomicsReader() {
/*  70 */     super("Cellomics C01", new String[] { "c01", "dib" });
/*  71 */     this.domains = new String[] { "Light Microscopy", "High-Content Screening (HCS)" };
/*  72 */     this.datasetDescription = "One or more .c01 files";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isThisType(RandomAccessInputStream stream) throws IOException {
/*  79 */     int blockLen = 4;
/*  80 */     if (!FormatTools.validStream(stream, 4, false)) return false; 
/*  81 */     return (stream.readInt() == 16);
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getDomains() {
/*  86 */     FormatTools.assertId(this.currentId, true, 1);
/*  87 */     return new String[] { "High-Content Screening (HCS)" };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] openBytes(int no, byte[] buf, int x, int y, int w, int h) throws FormatException, IOException {
/*  96 */     FormatTools.checkPlaneParameters((IFormatReader)this, no, buf.length, x, y, w, h);
/*     */     
/*  98 */     int[] zct = getZCTCoords(no);
/*     */     
/* 100 */     String file = this.files[getSeries() * getSizeC() + zct[1]];
/* 101 */     RandomAccessInputStream s = getDecompressedStream(file);
/*     */     
/* 103 */     int planeSize = FormatTools.getPlaneSize((IFormatReader)this);
/* 104 */     s.seek((52 + zct[0] * planeSize));
/* 105 */     readPlane(s, x, y, w, h, buf);
/* 106 */     s.close();
/*     */     
/* 108 */     return buf;
/*     */   }
/*     */ 
/*     */   
/*     */   public void close(boolean fileOnly) throws IOException {
/* 113 */     super.close(fileOnly);
/* 114 */     if (!fileOnly) {
/* 115 */       this.files = null;
/* 116 */       this.channelCharacter = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getSeriesUsedFiles(boolean noPixels) {
/* 122 */     FormatTools.assertId(this.currentId, true, 1);
/* 123 */     return this.files;
/*     */   }
/*     */ 
/*     */   
/*     */   public int fileGroupOption(String id) throws FormatException, IOException {
/* 128 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initFile(String id) throws FormatException, IOException {
/* 135 */     super.initFile(id);
/*     */ 
/*     */     
/* 138 */     Location baseFile = (new Location(id)).getAbsoluteFile();
/* 139 */     Location parent = baseFile.getParentFile();
/* 140 */     ArrayList<String> pixelFiles = new ArrayList<String>();
/*     */     
/* 142 */     String plateName = getPlateName(baseFile.getName());
/*     */     
/* 144 */     this.channelCharacter = "d";
/* 145 */     if (getChannel(id) < 0) {
/* 146 */       this.channelCharacter = "o";
/*     */     }
/*     */     
/* 149 */     if (plateName != null && isGroupFiles()) {
/* 150 */       String[] list = parent.list();
/* 151 */       for (String f : list) {
/* 152 */         if (plateName.equals(getPlateName(f)) && (checkSuffix(f, "c01") || checkSuffix(f, "dib"))) {
/*     */ 
/*     */           
/* 155 */           Location loc = new Location(parent, f);
/* 156 */           if ((!f.startsWith(".") || !loc.isHidden()) && getChannel(f) >= 0) {
/* 157 */             pixelFiles.add(loc.getAbsolutePath());
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } else {
/* 162 */       pixelFiles.add(id);
/*     */     } 
/* 164 */     this.files = pixelFiles.<String>toArray(new String[pixelFiles.size()]);
/* 165 */     Arrays.sort((Object[])this.files);
/*     */     
/* 167 */     int wellRows = 0;
/* 168 */     int wellColumns = 0;
/* 169 */     int fields = 0;
/*     */     
/* 171 */     ArrayList<String> uniqueRows = new ArrayList<String>();
/* 172 */     ArrayList<String> uniqueCols = new ArrayList<String>();
/* 173 */     ArrayList<String> uniqueFields = new ArrayList<String>();
/* 174 */     ArrayList<Integer> uniqueChannels = new ArrayList<Integer>();
/* 175 */     for (String f : this.files) {
/* 176 */       String wellRow = getWellRow(f);
/* 177 */       String wellCol = getWellColumn(f);
/* 178 */       String field = getField(f);
/* 179 */       int channel = getChannel(f);
/*     */       
/* 181 */       if (!uniqueRows.contains(wellRow)) uniqueRows.add(wellRow); 
/* 182 */       if (!uniqueCols.contains(wellCol)) uniqueCols.add(wellCol); 
/* 183 */       if (!uniqueFields.contains(field)) uniqueFields.add(field); 
/* 184 */       if (!uniqueChannels.contains(Integer.valueOf(channel))) uniqueChannels.add(Integer.valueOf(channel));
/*     */     
/*     */     } 
/* 187 */     fields = uniqueFields.size();
/* 188 */     wellRows = uniqueRows.size();
/* 189 */     wellColumns = uniqueCols.size();
/*     */     
/* 191 */     if (fields * wellRows * wellColumns > this.files.length) {
/* 192 */       this.files = new String[] { id };
/*     */     }
/*     */     
/* 195 */     this.core = new CoreMetadata[this.files.length / uniqueChannels.size()];
/*     */     
/* 197 */     for (int i = 0; i < this.core.length; i++) {
/* 198 */       this.core[i] = new CoreMetadata();
/*     */     }
/*     */     
/* 201 */     this.in = getDecompressedStream(id);
/*     */     
/* 203 */     LOGGER.info("Reading header data");
/*     */     
/* 205 */     this.in.order(true);
/* 206 */     this.in.skipBytes(4);
/*     */     
/* 208 */     int x = this.in.readInt();
/* 209 */     int y = this.in.readInt();
/* 210 */     int nPlanes = this.in.readShort();
/* 211 */     int nBits = this.in.readShort();
/*     */     
/* 213 */     int compression = this.in.readInt();
/*     */     
/* 215 */     if ((x * y * nPlanes * nBits / 8 + 52) > this.in.length()) {
/* 216 */       throw new UnsupportedCompressionException("Compressed pixel data is not yet supported.");
/*     */     }
/*     */ 
/*     */     
/* 220 */     this.in.skipBytes(4);
/* 221 */     int pixelWidth = 0, pixelHeight = 0;
/*     */     
/* 223 */     if (getMetadataOptions().getMetadataLevel() != MetadataLevel.MINIMUM) {
/* 224 */       pixelWidth = this.in.readInt();
/* 225 */       pixelHeight = this.in.readInt();
/* 226 */       int colorUsed = this.in.readInt();
/* 227 */       int colorImportant = this.in.readInt();
/*     */       
/* 229 */       LOGGER.info("Populating metadata hashtable");
/*     */       
/* 231 */       addGlobalMeta("Image width", x);
/* 232 */       addGlobalMeta("Image height", y);
/* 233 */       addGlobalMeta("Number of planes", nPlanes);
/* 234 */       addGlobalMeta("Bits per pixel", nBits);
/* 235 */       addGlobalMeta("Compression", compression);
/* 236 */       addGlobalMeta("Pixels per meter (X)", pixelWidth);
/* 237 */       addGlobalMeta("Pixels per meter (Y)", pixelHeight);
/* 238 */       addGlobalMeta("Color used", colorUsed);
/* 239 */       addGlobalMeta("Color important", colorImportant);
/*     */     } 
/*     */     
/* 242 */     LOGGER.info("Populating core metadata");
/*     */     
/* 244 */     for (int j = 0; j < getSeriesCount(); j++) {
/* 245 */       (this.core[j]).sizeX = x;
/* 246 */       (this.core[j]).sizeY = y;
/* 247 */       (this.core[j]).sizeZ = nPlanes;
/* 248 */       (this.core[j]).sizeT = 1;
/* 249 */       (this.core[j]).sizeC = uniqueChannels.size();
/* 250 */       (this.core[j]).imageCount = getSizeZ() * getSizeT() * getSizeC();
/* 251 */       (this.core[j]).littleEndian = true;
/* 252 */       (this.core[j]).dimensionOrder = "XYCZT";
/* 253 */       (this.core[j]).pixelType = FormatTools.pixelTypeFromBytes(nBits / 8, false, false);
/*     */     } 
/*     */ 
/*     */     
/* 257 */     LOGGER.info("Populating metadata store");
/*     */     
/* 259 */     MetadataStore store = makeFilterMetadata();
/* 260 */     MetadataTools.populatePixels(store, (IFormatReader)this);
/*     */     
/* 262 */     store.setPlateID(MetadataTools.createLSID("Plate", new int[] { 0 }), 0);
/* 263 */     store.setPlateName(plateName, 0);
/* 264 */     store.setPlateRowNamingConvention(NamingConvention.LETTER, 0);
/* 265 */     store.setPlateColumnNamingConvention(NamingConvention.NUMBER, 0);
/*     */     
/* 267 */     int realRows = wellRows;
/* 268 */     int realCols = wellColumns;
/*     */     
/* 270 */     if (this.files.length == 1) {
/* 271 */       realRows = 1;
/* 272 */       realCols = 1;
/*     */     }
/* 274 */     else if (realRows <= 8 && realCols <= 12) {
/* 275 */       realRows = 8;
/* 276 */       realCols = 12;
/*     */     } else {
/*     */       
/* 279 */       realRows = 16;
/* 280 */       realCols = 24;
/*     */     } 
/*     */     
/* 283 */     for (int row = 0; row < realRows; row++) {
/* 284 */       for (int col = 0; col < realCols; col++) {
/* 285 */         int well = row * realCols + col;
/*     */         
/* 287 */         if (this.files.length == 1) {
/* 288 */           String wellRow = getWellRow(this.files[0]);
/* 289 */           String wellColumn = getWellColumn(this.files[0]);
/* 290 */           row = wellRow.toUpperCase().charAt(0) - 65;
/* 291 */           col = Integer.parseInt(wellColumn) - 1;
/*     */         } 
/*     */         
/* 294 */         store.setWellID(MetadataTools.createLSID("Well", new int[] { 0, well }), 0, well);
/* 295 */         store.setWellRow(new NonNegativeInteger(Integer.valueOf(row)), 0, well);
/* 296 */         store.setWellColumn(new NonNegativeInteger(Integer.valueOf(col)), 0, well);
/*     */       } 
/*     */     } 
/*     */     
/* 300 */     for (int k = 0; k < getSeriesCount(); k++) {
/* 301 */       String file = this.files[k * getSizeC()];
/*     */       
/* 303 */       String field = getField(file);
/* 304 */       String wellRow = getWellRow(file);
/* 305 */       String wellColumn = getWellColumn(file);
/*     */       
/* 307 */       int m = wellRow.toUpperCase().charAt(0) - 65;
/* 308 */       int col = Integer.parseInt(wellColumn) - 1;
/*     */       
/* 310 */       if (this.files.length == 1) {
/* 311 */         m = 0;
/* 312 */         col = 0;
/*     */       } 
/*     */       
/* 315 */       String imageID = MetadataTools.createLSID("Image", new int[] { k });
/* 316 */       store.setImageID(imageID, k);
/* 317 */       if (m < realRows && col < realCols) {
/*     */         
/* 319 */         int wellIndex = m * realCols + col;
/* 320 */         int fieldIndex = Integer.parseInt(field);
/*     */         
/* 322 */         if (this.files.length == 1) {
/* 323 */           fieldIndex = 0;
/*     */         }
/*     */         
/* 326 */         String wellSampleID = MetadataTools.createLSID("WellSample", new int[] { 0, wellIndex, fieldIndex });
/*     */         
/* 328 */         store.setWellSampleID(wellSampleID, 0, wellIndex, fieldIndex);
/* 329 */         store.setWellSampleIndex(new NonNegativeInteger(Integer.valueOf(k)), 0, wellIndex, fieldIndex);
/*     */ 
/*     */         
/* 332 */         store.setWellSampleImageRef(imageID, 0, wellIndex, fieldIndex);
/*     */       } 
/* 334 */       store.setImageName("Well " + wellRow + wellColumn + ", Field #" + field, k);
/*     */     } 
/*     */ 
/*     */     
/* 338 */     if (getMetadataOptions().getMetadataLevel() != MetadataLevel.MINIMUM) {
/*     */ 
/*     */       
/* 341 */       double width = (pixelWidth == 0) ? 0.0D : (1000000.0D / pixelWidth);
/* 342 */       double height = (pixelHeight == 0) ? 0.0D : (1000000.0D / pixelHeight);
/*     */       
/* 344 */       PositiveFloat sizeX = FormatTools.getPhysicalSizeX(Double.valueOf(width));
/* 345 */       PositiveFloat sizeY = FormatTools.getPhysicalSizeY(Double.valueOf(height));
/* 346 */       for (int m = 0; m < getSeriesCount(); m++) {
/* 347 */         if (sizeX != null) {
/* 348 */           store.setPixelsPhysicalSizeX(sizeX, 0);
/*     */         }
/* 350 */         if (sizeY != null) {
/* 351 */           store.setPixelsPhysicalSizeY(sizeY, 0);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private String getPlateName(String filename) {
/* 360 */     int underscore = filename.lastIndexOf("_");
/* 361 */     if (underscore < 0) return null; 
/* 362 */     return filename.substring(0, underscore);
/*     */   }
/*     */   
/*     */   private String getWellName(String filename) {
/* 366 */     String wellName = filename.substring(filename.lastIndexOf("_") + 1);
/* 367 */     while (!Character.isLetter(wellName.charAt(0)) || !Character.isDigit(wellName.charAt(1)))
/*     */     {
/*     */       
/* 370 */       wellName = wellName.substring(1, wellName.length());
/*     */     }
/* 372 */     return wellName;
/*     */   }
/*     */   
/*     */   private String getWellRow(String filename) {
/* 376 */     return getWellName(filename).substring(0, 1);
/*     */   }
/*     */   
/*     */   private String getWellColumn(String filename) {
/* 380 */     return getWellName(filename).substring(1, 3);
/*     */   }
/*     */   
/*     */   private String getField(String filename) {
/* 384 */     String well = getWellName(filename);
/* 385 */     int start = well.indexOf("f") + 1;
/* 386 */     int end = start + 2;
/* 387 */     return well.substring(start, end);
/*     */   }
/*     */   
/*     */   private int getChannel(String filename) {
/* 391 */     String well = getWellName(filename);
/* 392 */     int start = well.indexOf(this.channelCharacter) + 1;
/* 393 */     int end = start + 1;
/* 394 */     if (start > 0) {
/* 395 */       return Integer.parseInt(well.substring(start, end));
/*     */     }
/* 397 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private RandomAccessInputStream getDecompressedStream(String filename) throws FormatException, IOException {
/* 403 */     RandomAccessInputStream s = new RandomAccessInputStream(filename);
/* 404 */     if (checkSuffix(filename, "c01")) {
/* 405 */       LOGGER.info("Decompressing file");
/*     */       
/* 407 */       s.seek(4L);
/* 408 */       ZlibCodec codec = new ZlibCodec();
/* 409 */       byte[] file = codec.decompress(s, null);
/* 410 */       s.close();
/*     */       
/* 412 */       return new RandomAccessInputStream(file);
/*     */     } 
/* 414 */     return s;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/in/CellomicsReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */