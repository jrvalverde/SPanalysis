/*     */ package loci.formats.in;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Comparator;
/*     */ import loci.common.DataTools;
/*     */ import loci.common.DateTools;
/*     */ import loci.common.Location;
/*     */ import loci.common.RandomAccessInputStream;
/*     */ import loci.formats.CoreMetadata;
/*     */ import loci.formats.FormatException;
/*     */ import loci.formats.FormatReader;
/*     */ import loci.formats.FormatTools;
/*     */ import loci.formats.IFormatReader;
/*     */ import loci.formats.MetadataTools;
/*     */ import loci.formats.meta.MetadataStore;
/*     */ import ome.xml.model.primitives.Timestamp;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BrukerReader
/*     */   extends FormatReader
/*     */ {
/*     */   private static final String DATE_FORMAT = "HH:mm:ss  d MMM yyyy";
/*  64 */   private ArrayList<String> pixelsFiles = new ArrayList<String>();
/*  65 */   private ArrayList<String> allFiles = new ArrayList<String>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BrukerReader() {
/*  71 */     super("Bruker", "");
/*  72 */     this.suffixSufficient = false;
/*  73 */     this.domains = new String[] { "Medical Imaging" };
/*  74 */     this.hasCompanionFiles = true;
/*  75 */     this.datasetDescription = "One 'fid' and one 'acqp' plus several other metadata files and a 'pdata' directory";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSingleFile(String id) throws FormatException, IOException {
/*  83 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isThisType(String name, boolean open) {
/*  88 */     Location file = (new Location(name)).getAbsoluteFile();
/*  89 */     return (file.getName().equals("fid") || file.getName().equals("acqp"));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isThisType(RandomAccessInputStream stream) throws IOException {
/*  94 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] openBytes(int no, byte[] buf, int x, int y, int w, int h) throws FormatException, IOException {
/* 103 */     FormatTools.checkPlaneParameters((IFormatReader)this, no, buf.length, x, y, w, h);
/*     */     
/* 105 */     RandomAccessInputStream s = new RandomAccessInputStream(this.pixelsFiles.get(getSeries()));
/*     */     
/* 107 */     s.seek((no * FormatTools.getPlaneSize((IFormatReader)this)));
/* 108 */     readPlane(s, x, y, w, h, buf);
/* 109 */     s.close();
/* 110 */     return buf;
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getSeriesUsedFiles(boolean noPixels) {
/* 115 */     FormatTools.assertId(this.currentId, true, 1);
/*     */     
/* 117 */     String dir = this.pixelsFiles.get(getSeries());
/* 118 */     Location realDir = (new Location(dir)).getParentFile();
/* 119 */     realDir = realDir.getParentFile();
/* 120 */     realDir = realDir.getParentFile();
/* 121 */     dir = realDir.getAbsolutePath();
/* 122 */     ArrayList<String> files = new ArrayList<String>();
/*     */     
/* 124 */     for (String f : this.allFiles) {
/* 125 */       if (f.startsWith(dir) && (!f.endsWith("2dseq") || !noPixels)) {
/* 126 */         files.add(f);
/*     */       }
/*     */     } 
/*     */     
/* 130 */     return files.<String>toArray(new String[files.size()]);
/*     */   }
/*     */ 
/*     */   
/*     */   public int fileGroupOption(String id) throws FormatException, IOException {
/* 135 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public void close(boolean fileOnly) throws IOException {
/* 140 */     super.close(fileOnly);
/* 141 */     if (!fileOnly) {
/* 142 */       this.pixelsFiles.clear();
/* 143 */       this.allFiles.clear();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initFile(String id) throws FormatException, IOException {
/* 151 */     super.initFile(id);
/*     */     
/* 153 */     Location originalFile = (new Location(id)).getAbsoluteFile();
/* 154 */     Location parent = originalFile.getParentFile().getParentFile();
/*     */     
/* 156 */     String[] acquisitionDirs = parent.list(true);
/*     */     
/* 158 */     Comparator<String> comparator = new Comparator<String>() {
/*     */         public int compare(String s1, String s2) {
/* 160 */           Integer i1 = Integer.valueOf(0);
/*     */           try {
/* 162 */             i1 = new Integer(s1);
/*     */           }
/* 164 */           catch (NumberFormatException e) {}
/* 165 */           Integer i2 = Integer.valueOf(0);
/*     */           try {
/* 167 */             i2 = new Integer(s2);
/*     */           }
/* 169 */           catch (NumberFormatException e) {}
/*     */           
/* 171 */           return i1.compareTo(i2);
/*     */         }
/*     */       };
/*     */     
/* 175 */     Arrays.sort(acquisitionDirs, comparator);
/*     */     
/* 177 */     ArrayList<String> acqpFiles = new ArrayList<String>();
/* 178 */     ArrayList<String> recoFiles = new ArrayList<String>();
/*     */     
/* 180 */     for (String f : acquisitionDirs) {
/* 181 */       Location dir = new Location(parent, f);
/* 182 */       if (dir.isDirectory()) {
/* 183 */         String[] files = dir.list(true);
/* 184 */         for (String file : files) {
/* 185 */           Location child = new Location(dir, file);
/* 186 */           if (!child.isDirectory()) {
/* 187 */             this.allFiles.add(child.getAbsolutePath());
/* 188 */             if (file.equals("acqp")) {
/* 189 */               acqpFiles.add(child.getAbsolutePath());
/*     */             }
/*     */           } else {
/*     */             
/* 193 */             Location grandchild = new Location(child, "1");
/* 194 */             if (grandchild.exists()) {
/* 195 */               String[] moreFiles = grandchild.list(true);
/* 196 */               for (String m : moreFiles) {
/* 197 */                 Location ggc = new Location(grandchild, m);
/* 198 */                 if (!ggc.isDirectory()) {
/* 199 */                   this.allFiles.add(ggc.getAbsolutePath());
/* 200 */                   if (m.equals("2dseq")) {
/* 201 */                     this.pixelsFiles.add(ggc.getAbsolutePath());
/*     */                   }
/* 203 */                   else if (m.equals("reco")) {
/* 204 */                     recoFiles.add(ggc.getAbsolutePath());
/*     */                   } 
/*     */                 } 
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */         
/* 212 */         if (acqpFiles.size() > this.pixelsFiles.size()) {
/* 213 */           acqpFiles.remove(acqpFiles.size() - 1);
/*     */         }
/* 215 */         if (recoFiles.size() > this.pixelsFiles.size()) {
/* 216 */           recoFiles.remove(recoFiles.size() - 1);
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 221 */     this.core = new CoreMetadata[this.pixelsFiles.size()];
/*     */     
/* 223 */     String[] imageNames = new String[this.pixelsFiles.size()];
/* 224 */     String[] timestamps = new String[this.pixelsFiles.size()];
/* 225 */     String[] institutions = new String[this.pixelsFiles.size()];
/* 226 */     String[] users = new String[this.pixelsFiles.size()];
/*     */     
/* 228 */     for (int series = 0; series < this.pixelsFiles.size(); series++) {
/* 229 */       setSeries(series);
/*     */       
/* 231 */       this.core[series] = new CoreMetadata();
/*     */       
/* 233 */       String acqData = DataTools.readFile(acqpFiles.get(series));
/* 234 */       String[] lines = acqData.split("\n");
/*     */       
/* 236 */       String[] sizes = null;
/* 237 */       String[] ordering = null;
/* 238 */       int ni = 0, nr = 0, ns = 0;
/* 239 */       int bits = 0;
/* 240 */       boolean signed = false;
/* 241 */       boolean isFloat = false;
/*     */       
/* 243 */       for (int j = 0; j < lines.length; j++) {
/* 244 */         String line = lines[j];
/* 245 */         int index = line.indexOf("=");
/* 246 */         if (index >= 0) {
/* 247 */           String key = line.substring(0, index);
/* 248 */           String value = line.substring(index + 1);
/*     */           
/* 250 */           if (value.startsWith("(")) {
/* 251 */             value = lines[j + 1].trim();
/* 252 */             if (value.startsWith("<")) {
/* 253 */               value = value.substring(1, value.length() - 1);
/*     */             }
/*     */           } 
/* 256 */           if (key.length() >= 4) {
/*     */ 
/*     */ 
/*     */             
/* 260 */             addSeriesMeta(key.substring(3), value);
/*     */             
/* 262 */             if (key.equals("##$NI")) {
/* 263 */               ni = Integer.parseInt(value);
/*     */             }
/* 265 */             else if (key.equals("##$NR")) {
/* 266 */               nr = Integer.parseInt(value);
/*     */             }
/* 268 */             else if (key.equals("##$ACQ_word_size")) {
/* 269 */               bits = Integer.parseInt(value.substring(1, value.lastIndexOf("_")));
/*     */             }
/* 271 */             else if (key.equals("##$BYTORDA")) {
/* 272 */               (this.core[series]).littleEndian = value.toLowerCase().equals("little");
/*     */             }
/* 274 */             else if (key.equals("##$ACQ_size")) {
/* 275 */               sizes = value.split(" ");
/*     */             }
/* 277 */             else if (key.equals("##$ACQ_obj_order")) {
/* 278 */               ordering = value.split(" ");
/*     */             }
/* 280 */             else if (key.equals("##$ACQ_time")) {
/* 281 */               timestamps[series] = value;
/*     */             }
/* 283 */             else if (key.equals("##$ACQ_institution")) {
/* 284 */               institutions[series] = value;
/*     */             }
/* 286 */             else if (key.equals("##$ACQ_operator")) {
/* 287 */               users[series] = value;
/*     */             }
/* 289 */             else if (key.equals("##$ACQ_scan_name")) {
/* 290 */               imageNames[series] = value;
/*     */             }
/* 292 */             else if (key.equals("##$ACQ_ns_list_size")) {
/* 293 */               ns = Integer.parseInt(value);
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/* 298 */       String recoData = DataTools.readFile(recoFiles.get(series));
/* 299 */       lines = recoData.split("\n");
/*     */       
/* 301 */       for (int k = 0; k < lines.length; k++) {
/* 302 */         String line = lines[k];
/* 303 */         int index = line.indexOf("=");
/* 304 */         if (index >= 0) {
/* 305 */           String key = line.substring(0, index);
/* 306 */           String value = line.substring(index + 1);
/*     */           
/* 308 */           if (value.startsWith("(")) {
/* 309 */             value = lines[k + 1].trim();
/* 310 */             if (value.startsWith("<")) {
/* 311 */               value = value.substring(1, value.length() - 1);
/*     */             }
/*     */           } 
/* 314 */           if (key.length() >= 4) {
/*     */ 
/*     */ 
/*     */             
/* 318 */             addSeriesMeta(key.substring(3), value);
/*     */             
/* 320 */             if (key.equals("##$RECO_size")) {
/* 321 */               sizes = value.split(" ");
/*     */             }
/* 323 */             else if (key.equals("##$RECO_wordtype")) {
/* 324 */               bits = Integer.parseInt(value.substring(1, value.indexOf("BIT")));
/* 325 */               signed = (value.indexOf("_SGN_") >= 0);
/* 326 */               isFloat = !value.endsWith("_INT");
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/* 331 */       int td = Integer.parseInt(sizes[0]);
/* 332 */       int ys = (sizes.length > 1) ? Integer.parseInt(sizes[1]) : 0;
/* 333 */       int zs = (sizes.length > 2) ? Integer.parseInt(sizes[2]) : 0;
/*     */       
/* 335 */       if (sizes.length == 2) {
/* 336 */         if (ni == 1) {
/* 337 */           (this.core[series]).sizeY = ys;
/* 338 */           (this.core[series]).sizeZ = nr;
/*     */         } else {
/*     */           
/* 341 */           (this.core[series]).sizeY = ys;
/* 342 */           (this.core[series]).sizeZ = ni;
/*     */         }
/*     */       
/* 345 */       } else if (sizes.length == 3) {
/* 346 */         (this.core[series]).sizeY = ni * ys;
/* 347 */         (this.core[series]).sizeZ = nr * zs;
/*     */       } 
/*     */       
/* 350 */       (this.core[series]).sizeX = td;
/*     */       
/* 352 */       (this.core[series]).sizeZ /= ns;
/* 353 */       (this.core[series]).sizeT = ns * nr;
/* 354 */       (this.core[series]).sizeC = 1;
/* 355 */       (this.core[series]).imageCount = getSizeZ() * getSizeC() * getSizeT();
/* 356 */       (this.core[series]).dimensionOrder = "XYCTZ";
/* 357 */       (this.core[series]).rgb = false;
/* 358 */       (this.core[series]).interleaved = false;
/* 359 */       (this.core[series]).pixelType = FormatTools.pixelTypeFromBytes(bits / 8, signed, isFloat);
/*     */     } 
/*     */ 
/*     */     
/* 363 */     MetadataStore store = makeFilterMetadata();
/* 364 */     MetadataTools.populatePixels(store, (IFormatReader)this);
/*     */     
/* 366 */     for (int i = 0; i < getSeriesCount(); i++) {
/* 367 */       store.setImageName(imageNames[i] + " #" + (i + 1), i);
/* 368 */       String date = DateTools.formatDate(timestamps[i], "HH:mm:ss  d MMM yyyy");
/* 369 */       if (date != null) {
/* 370 */         store.setImageAcquisitionDate(new Timestamp(date), i);
/*     */       }
/*     */       
/* 373 */       String expID = MetadataTools.createLSID("Experimenter", new int[] { i });
/* 374 */       store.setExperimenterID(expID, i);
/* 375 */       store.setExperimenterLastName(users[i], i);
/* 376 */       store.setExperimenterInstitution(institutions[i], i);
/*     */       
/* 378 */       store.setImageExperimenterRef(expID, i);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/in/BrukerReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */