/*     */ package loci.formats.in;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.Vector;
/*     */ import loci.common.DataTools;
/*     */ import loci.common.Location;
/*     */ import loci.common.services.DependencyException;
/*     */ import loci.common.services.ServiceFactory;
/*     */ import loci.formats.CoreMetadata;
/*     */ import loci.formats.FormatException;
/*     */ import loci.formats.FormatReader;
/*     */ import loci.formats.FormatTools;
/*     */ import loci.formats.IFormatReader;
/*     */ import loci.formats.MetadataTools;
/*     */ import loci.formats.meta.MetadataStore;
/*     */ import loci.formats.services.MDBService;
/*     */ import loci.formats.tiff.IFD;
/*     */ import loci.formats.tiff.IFDList;
/*     */ import loci.formats.tiff.PhotoInterp;
/*     */ import loci.formats.tiff.TiffParser;
/*     */ import ome.xml.model.primitives.PositiveFloat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class APLReader
/*     */   extends FormatReader
/*     */ {
/*  62 */   private static final String[] METADATA_SUFFIXES = new String[] { "apl", "tnb", "mtb" };
/*     */ 
/*     */   
/*     */   private String[] tiffFiles;
/*     */   
/*     */   private String[] xmlFiles;
/*     */   
/*     */   private TiffParser[] parser;
/*     */   
/*     */   private IFDList[] ifds;
/*     */   
/*     */   private Vector<String> used;
/*     */ 
/*     */   
/*     */   public APLReader() {
/*  77 */     super("Olympus APL", new String[] { "apl", "tnb", "mtb", "tif" });
/*  78 */     this.domains = new String[] { "Light Microscopy" };
/*  79 */     this.hasCompanionFiles = true;
/*  80 */     this.suffixSufficient = false;
/*  81 */     this.datasetDescription = "One .apl file, one .mtb file, one .tnb file, and a directory containing one or more .tif files";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isThisType(String name, boolean open) {
/*  89 */     if (checkSuffix(name, METADATA_SUFFIXES)) return true; 
/*  90 */     if (checkSuffix(name, "tif") && open) {
/*  91 */       Location file = (new Location(name)).getAbsoluteFile();
/*  92 */       Location parent = file.getParentFile();
/*  93 */       if (parent != null) {
/*     */         try {
/*  95 */           parent = parent.getParentFile();
/*  96 */           parent = parent.getParentFile();
/*     */         }
/*  98 */         catch (NullPointerException e) {
/*  99 */           return false;
/*     */         } 
/* 101 */         Location aplFile = new Location(parent, parent.getName() + ".apl");
/* 102 */         return aplFile.exists();
/*     */       } 
/*     */     } 
/* 105 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSingleFile(String id) throws FormatException, IOException {
/* 110 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getSeriesUsedFiles(boolean noPixels) {
/* 115 */     FormatTools.assertId(this.currentId, true, 1);
/* 116 */     Vector<String> files = new Vector<String>();
/* 117 */     files.addAll(this.used);
/*     */     
/* 119 */     if (getSeries() < this.xmlFiles.length) {
/* 120 */       Location xmlFile = new Location(this.xmlFiles[getSeries()]);
/* 121 */       if (xmlFile.exists() && !xmlFile.isDirectory()) {
/* 122 */         files.add(this.xmlFiles[getSeries()]);
/*     */       }
/*     */     } 
/* 125 */     if (!noPixels && getSeries() < this.tiffFiles.length && (new Location(this.tiffFiles[getSeries()])).exists())
/*     */     {
/*     */       
/* 128 */       files.add(this.tiffFiles[getSeries()]);
/*     */     }
/* 130 */     return files.<String>toArray(new String[files.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] openBytes(int no, byte[] buf, int x, int y, int w, int h) throws FormatException, IOException {
/* 139 */     FormatTools.checkPlaneParameters((IFormatReader)this, no, buf.length, x, y, w, h);
/*     */     
/* 141 */     IFD ifd = (IFD)this.ifds[getSeries()].get(no);
/* 142 */     return this.parser[getSeries()].getSamples(ifd, buf, x, y, w, h);
/*     */   }
/*     */ 
/*     */   
/*     */   public void close(boolean fileOnly) throws IOException {
/* 147 */     super.close(fileOnly);
/* 148 */     if (!fileOnly) {
/* 149 */       this.tiffFiles = null;
/* 150 */       this.xmlFiles = null;
/* 151 */       this.used = null;
/* 152 */       this.ifds = null;
/* 153 */       if (this.parser != null) {
/* 154 */         for (TiffParser p : this.parser) {
/* 155 */           if (p != null) {
/* 156 */             p.getStream().close();
/*     */           }
/*     */         } 
/*     */       }
/* 160 */       this.parser = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int fileGroupOption(String id) throws FormatException, IOException {
/* 166 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOptimalTileWidth() {
/* 171 */     FormatTools.assertId(this.currentId, true, 1);
/*     */     try {
/* 173 */       return (int)((IFD)this.ifds[getSeries()].get(0)).getTileWidth();
/*     */     }
/* 175 */     catch (FormatException e) {
/* 176 */       LOGGER.debug("Could not retrieve tile width", (Throwable)e);
/*     */       
/* 178 */       return super.getOptimalTileWidth();
/*     */     } 
/*     */   }
/*     */   
/*     */   public int getOptimalTileHeight() {
/* 183 */     FormatTools.assertId(this.currentId, true, 1);
/*     */     try {
/* 185 */       return (int)((IFD)this.ifds[getSeries()].get(0)).getTileLength();
/*     */     }
/* 187 */     catch (FormatException e) {
/* 188 */       LOGGER.debug("Could not retrieve tile height", (Throwable)e);
/*     */       
/* 190 */       return super.getOptimalTileHeight();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initFile(String id) throws FormatException, IOException {
/* 197 */     super.initFile(id);
/*     */     
/* 199 */     LOGGER.debug("Initializing {}", id);
/*     */ 
/*     */     
/* 202 */     if (!checkSuffix(id, "mtb")) {
/* 203 */       if (checkSuffix(id, METADATA_SUFFIXES)) {
/* 204 */         int separator = id.lastIndexOf(File.separator);
/* 205 */         if (separator < 0) separator = 0; 
/* 206 */         int underscore = id.lastIndexOf("_");
/* 207 */         if (underscore < separator || checkSuffix(id, "apl")) {
/* 208 */           underscore = id.lastIndexOf(".");
/*     */         }
/* 210 */         String mtbFile = id.substring(0, underscore) + "_d.mtb";
/* 211 */         if (!(new Location(mtbFile)).exists()) {
/* 212 */           throw new FormatException(".mtb file not found");
/*     */         }
/* 214 */         this.currentId = (new Location(mtbFile)).getAbsolutePath();
/*     */       } else {
/*     */         
/* 217 */         Location parent = (new Location(id)).getAbsoluteFile().getParentFile();
/* 218 */         parent = parent.getParentFile();
/* 219 */         String[] arrayOfString = parent.list(true);
/* 220 */         for (String f : arrayOfString) {
/* 221 */           if (checkSuffix(f, "mtb")) {
/* 222 */             this.currentId = (new Location(parent, f)).getAbsolutePath();
/*     */             break;
/*     */           } 
/*     */         } 
/* 226 */         if (!checkSuffix(this.currentId, "mtb")) {
/* 227 */           throw new FormatException(".mtb file not found");
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/* 232 */     String mtb = (new Location(this.currentId)).getAbsolutePath();
/* 233 */     LOGGER.debug("Reading .mtb file '{}'", mtb);
/*     */     
/* 235 */     MDBService mdb = null;
/*     */     try {
/* 237 */       ServiceFactory factory = new ServiceFactory();
/* 238 */       mdb = (MDBService)factory.getInstance(MDBService.class);
/*     */     }
/* 240 */     catch (DependencyException de) {
/* 241 */       throw new FormatException("MDB Tools Java library not found", de);
/*     */     } 
/*     */     
/* 244 */     String[] columnNames = null;
/* 245 */     Vector<String[]> rows = null;
/*     */     try {
/* 247 */       mdb.initialize(mtb);
/* 248 */       rows = mdb.parseDatabase().get(0);
/*     */       
/* 250 */       columnNames = rows.get(0);
/* 251 */       String[] tmpNames = columnNames;
/* 252 */       columnNames = new String[tmpNames.length - 1];
/* 253 */       System.arraycopy(tmpNames, 1, columnNames, 0, columnNames.length);
/*     */     } finally {
/*     */       
/* 256 */       mdb.close();
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 261 */     if (getMetadataOptions().getMetadataLevel() != MetadataLevel.MINIMUM) {
/* 262 */       for (int m = 1; m < rows.size(); m++) {
/* 263 */         String[] row = rows.get(m);
/* 264 */         for (int q = 0; q < row.length; q++) {
/* 265 */           addGlobalMeta(columnNames[q] + " " + m, row[q]);
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/* 270 */     this.used = new Vector<String>();
/* 271 */     this.used.add(mtb);
/* 272 */     String tnb = mtb.substring(0, mtb.lastIndexOf("."));
/* 273 */     if (tnb.lastIndexOf("_") > tnb.lastIndexOf(File.separator)) {
/* 274 */       tnb = tnb.substring(0, tnb.lastIndexOf("_"));
/*     */     }
/* 276 */     this.used.add(tnb + "_1.tnb");
/* 277 */     this.used.add(tnb + ".apl");
/* 278 */     String idPath = (new Location(id)).getAbsolutePath();
/* 279 */     if (!this.used.contains(idPath) && checkSuffix(idPath, METADATA_SUFFIXES)) {
/* 280 */       this.used.add(idPath);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 285 */     int calibrationUnit = DataTools.indexOf((Object[])columnNames, "Calibration Unit");
/* 286 */     int colorChannels = DataTools.indexOf((Object[])columnNames, "Color Channels");
/* 287 */     int frames = DataTools.indexOf((Object[])columnNames, "Frames");
/* 288 */     int calibratedHeight = DataTools.indexOf((Object[])columnNames, "Height");
/* 289 */     int calibratedWidth = DataTools.indexOf((Object[])columnNames, "Width");
/* 290 */     int path = DataTools.indexOf((Object[])columnNames, "Image Path");
/* 291 */     int filename = DataTools.indexOf((Object[])columnNames, "File Name");
/* 292 */     int magnification = DataTools.indexOf((Object[])columnNames, "Magnification");
/* 293 */     int width = DataTools.indexOf((Object[])columnNames, "X-Resolution");
/* 294 */     int height = DataTools.indexOf((Object[])columnNames, "Y-Resolution");
/* 295 */     int imageName = DataTools.indexOf((Object[])columnNames, "Image Name");
/* 296 */     int zLayers = DataTools.indexOf((Object[])columnNames, "Z-Layers");
/*     */     
/* 298 */     String parentDirectory = mtb.substring(0, mtb.lastIndexOf(File.separator));
/*     */ 
/*     */ 
/*     */     
/* 302 */     LOGGER.debug("Searching {} for a directory with TIFFs", parentDirectory);
/*     */     
/* 304 */     Location dir = new Location(parentDirectory);
/* 305 */     String[] list = dir.list();
/* 306 */     String topDirectory = null;
/* 307 */     for (String f : list) {
/* 308 */       LOGGER.debug("  '{}'", f);
/* 309 */       Location file = new Location(dir, f);
/* 310 */       if (file.isDirectory() && f.indexOf("_DocumentFiles") > 0) {
/* 311 */         topDirectory = file.getAbsolutePath();
/* 312 */         LOGGER.debug("Found {}", topDirectory);
/*     */         break;
/*     */       } 
/*     */     } 
/* 316 */     if (topDirectory == null) {
/* 317 */       throw new FormatException("Could not find a directory with TIFF files.");
/*     */     }
/*     */     
/* 320 */     Vector<Integer> seriesIndexes = new Vector<Integer>();
/*     */     
/* 322 */     for (int i = 1; i < rows.size(); i++) {
/* 323 */       String file = ((String[])rows.get(i))[filename].trim();
/*     */       
/* 325 */       file = topDirectory + File.separator + file;
/* 326 */       if (!file.equals("") && (new Location(file)).exists() && checkSuffix(file, "tif")) {
/* 327 */         seriesIndexes.add(Integer.valueOf(i));
/*     */       }
/*     */     } 
/* 330 */     int seriesCount = seriesIndexes.size();
/*     */     
/* 332 */     this.core = new CoreMetadata[seriesCount]; int j;
/* 333 */     for (j = 0; j < seriesCount; j++) {
/* 334 */       this.core[j] = new CoreMetadata();
/*     */     }
/* 336 */     this.tiffFiles = new String[seriesCount];
/* 337 */     this.xmlFiles = new String[seriesCount];
/* 338 */     this.parser = new TiffParser[seriesCount];
/* 339 */     this.ifds = new IFDList[seriesCount];
/*     */     
/* 341 */     for (j = 0; j < seriesCount; j++) {
/* 342 */       int secondRow = ((Integer)seriesIndexes.get(j)).intValue();
/* 343 */       int firstRow = secondRow - 1;
/* 344 */       String[] row2 = rows.get(firstRow);
/* 345 */       String[] row3 = rows.get(secondRow);
/*     */       
/* 347 */       (this.core[j]).sizeT = parseDimension(row3[frames]);
/* 348 */       (this.core[j]).sizeZ = parseDimension(row3[zLayers]);
/* 349 */       (this.core[j]).sizeC = parseDimension(row3[colorChannels]);
/* 350 */       (this.core[j]).dimensionOrder = "XYCZT";
/*     */       
/* 352 */       if ((this.core[j]).sizeZ == 0) (this.core[j]).sizeZ = 1; 
/* 353 */       if ((this.core[j]).sizeC == 0) (this.core[j]).sizeC = 1; 
/* 354 */       if ((this.core[j]).sizeT == 0) (this.core[j]).sizeT = 1;
/*     */       
/* 356 */       this.xmlFiles[j] = topDirectory + File.separator + row2[filename];
/* 357 */       this.tiffFiles[j] = topDirectory + File.separator + row3[filename];
/*     */       
/* 359 */       this.parser[j] = new TiffParser(this.tiffFiles[j]);
/* 360 */       this.parser[j].setDoCaching(false);
/* 361 */       this.ifds[j] = this.parser[j].getIFDs();
/* 362 */       for (IFD iFD : this.ifds[j]) {
/* 363 */         this.parser[j].fillInIFD(iFD);
/*     */       }
/*     */       
/* 366 */       for (IFD iFD : this.ifds[j]) {
/* 367 */         this.parser[j].fillInIFD(iFD);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 372 */       IFD ifd = (IFD)this.ifds[j].get(0);
/* 373 */       PhotoInterp photo = ifd.getPhotometricInterpretation();
/* 374 */       int samples = ifd.getSamplesPerPixel();
/*     */       
/* 376 */       (this.core[j]).sizeX = (int)ifd.getImageWidth();
/* 377 */       (this.core[j]).sizeY = (int)ifd.getImageLength();
/* 378 */       (this.core[j]).rgb = (samples > 1 || photo == PhotoInterp.RGB);
/* 379 */       (this.core[j]).pixelType = ifd.getPixelType();
/* 380 */       (this.core[j]).littleEndian = ifd.isLittleEndian();
/* 381 */       (this.core[j]).indexed = (photo == PhotoInterp.RGB_PALETTE && ifd.containsKey(Integer.valueOf(320)));
/*     */       
/* 383 */       (this.core[j]).imageCount = this.ifds[j].size();
/* 384 */       if ((this.core[j]).sizeZ * (this.core[j]).sizeT * ((this.core[j]).rgb ? 1 : (this.core[j]).sizeC) != (this.core[j]).imageCount) {
/*     */ 
/*     */         
/* 387 */         (this.core[j]).sizeT = (this.core[j]).imageCount / ((this.core[j]).rgb ? 1 : (this.core[j]).sizeC);
/* 388 */         (this.core[j]).sizeZ = 1;
/*     */       } 
/*     */     } 
/*     */     
/* 392 */     MetadataStore store = makeFilterMetadata();
/* 393 */     MetadataTools.populatePixels(store, (IFormatReader)this);
/*     */     
/* 395 */     for (int k = 0; k < seriesCount; k++) {
/* 396 */       String[] row = rows.get(((Integer)seriesIndexes.get(k)).intValue());
/*     */ 
/*     */       
/* 399 */       MetadataTools.setDefaultCreationDate(store, mtb, k);
/* 400 */       store.setImageName(row[imageName].trim(), k);
/*     */       
/* 402 */       if (getMetadataOptions().getMetadataLevel() != MetadataLevel.MINIMUM) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 407 */         double realWidth = Double.parseDouble(row[calibratedWidth]);
/* 408 */         double realHeight = Double.parseDouble(row[calibratedHeight]);
/*     */         
/* 410 */         String units = row[calibrationUnit];
/*     */         
/* 412 */         double px = realWidth / (this.core[k]).sizeX;
/* 413 */         double py = realHeight / (this.core[k]).sizeY;
/*     */         
/* 415 */         if (units.equals("mm")) {
/* 416 */           px *= 1000.0D;
/* 417 */           py *= 1000.0D;
/*     */         } 
/*     */ 
/*     */         
/* 421 */         PositiveFloat physicalSizeX = FormatTools.getPhysicalSizeX(Double.valueOf(px));
/* 422 */         PositiveFloat physicalSizeY = FormatTools.getPhysicalSizeY(Double.valueOf(py));
/*     */         
/* 424 */         if (physicalSizeX != null) {
/* 425 */           store.setPixelsPhysicalSizeX(physicalSizeX, k);
/*     */         }
/* 427 */         if (physicalSizeY != null) {
/* 428 */           store.setPixelsPhysicalSizeY(physicalSizeY, k);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int parseDimension(String dim) {
/*     */     try {
/* 443 */       return Integer.parseInt(dim);
/*     */     }
/* 445 */     catch (NumberFormatException e) {
/* 446 */       return 1;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/in/APLReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */