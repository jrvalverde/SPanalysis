/*     */ package loci.formats.in;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import loci.common.RandomAccessInputStream;
/*     */ import loci.formats.FormatException;
/*     */ import loci.formats.FormatReader;
/*     */ import loci.formats.FormatTools;
/*     */ import loci.formats.IFormatReader;
/*     */ import loci.formats.MetadataTools;
/*     */ import loci.formats.meta.MetadataStore;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ARFReader
/*     */   extends FormatReader
/*     */ {
/*     */   private static final long PIXELS_OFFSET = 524L;
/*     */   
/*     */   public ARFReader() {
/*  59 */     super("ARF", "arf");
/*  60 */     this.domains = new String[] { "Unknown" };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isThisType(RandomAccessInputStream stream) throws IOException {
/*  67 */     int blockLen = 4;
/*  68 */     if (!FormatTools.validStream(stream, 4, false)) return false; 
/*  69 */     byte endian1 = stream.readByte();
/*  70 */     byte endian2 = stream.readByte();
/*  71 */     return (((endian1 == 1 && endian2 == 0) || (endian1 == 0 && endian2 == 1)) && stream.readString(2).equals("AR"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] openBytes(int no, byte[] buf, int x, int y, int w, int h) throws FormatException, IOException {
/*  81 */     FormatTools.checkPlaneParameters((IFormatReader)this, no, buf.length, x, y, w, h);
/*     */     
/*  83 */     this.in.seek(524L + (no * FormatTools.getPlaneSize((IFormatReader)this)));
/*  84 */     readPlane(this.in, x, y, w, h, buf);
/*     */     
/*  86 */     return buf;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initFile(String id) throws FormatException, IOException {
/*     */     boolean little;
/*  93 */     super.initFile(id);
/*  94 */     this.in = new RandomAccessInputStream(id);
/*     */ 
/*     */ 
/*     */     
/*  98 */     LOGGER.info("Reading file header");
/*     */     
/* 100 */     byte endian1 = this.in.readByte();
/* 101 */     byte endian2 = this.in.readByte();
/*     */     
/* 103 */     if (endian1 == 1 && endian2 == 0) { little = true; }
/* 104 */     else if (endian1 == 0 && endian2 == 1) { little = false; }
/* 105 */     else { throw new FormatException("Undefined endianness"); }
/* 106 */      this.in.order(little);
/*     */     
/* 108 */     this.in.skipBytes(2);
/* 109 */     int version = this.in.readUnsignedShort();
/* 110 */     int width = this.in.readUnsignedShort();
/* 111 */     int height = this.in.readUnsignedShort();
/* 112 */     int bitsPerPixel = this.in.readUnsignedShort();
/* 113 */     int numImages = (version == 2) ? this.in.readUnsignedShort() : 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 119 */     (this.core[0]).sizeX = width;
/* 120 */     (this.core[0]).sizeY = height;
/* 121 */     (this.core[0]).sizeZ = 1;
/* 122 */     (this.core[0]).sizeC = 1;
/* 123 */     (this.core[0]).sizeT = numImages;
/*     */     
/* 125 */     int bpp = bitsPerPixel / 8;
/* 126 */     if (bitsPerPixel % 8 != 0) bpp++; 
/* 127 */     (this.core[0]).pixelType = FormatTools.pixelTypeFromBytes(bpp, false, false);
/*     */     
/* 129 */     (this.core[0]).bitsPerPixel = bitsPerPixel;
/* 130 */     (this.core[0]).imageCount = numImages;
/* 131 */     (this.core[0]).dimensionOrder = "XYCZT";
/* 132 */     (this.core[0]).orderCertain = true;
/* 133 */     (this.core[0]).littleEndian = little;
/* 134 */     (this.core[0]).rgb = false;
/* 135 */     (this.core[0]).interleaved = false;
/* 136 */     (this.core[0]).indexed = false;
/* 137 */     (this.core[0]).metadataComplete = true;
/*     */     
/* 139 */     if (getMetadataOptions().getMetadataLevel() != MetadataLevel.MINIMUM) {
/*     */ 
/*     */       
/* 142 */       addGlobalMeta("Endianness", little ? "little" : "big");
/* 143 */       addGlobalMeta("Version", version);
/* 144 */       addGlobalMeta("Width", width);
/* 145 */       addGlobalMeta("Height", height);
/* 146 */       addGlobalMeta("Bits per pixel", bitsPerPixel);
/* 147 */       addGlobalMeta("Image count", numImages);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 152 */     MetadataStore store = makeFilterMetadata();
/* 153 */     MetadataTools.populatePixels(store, (IFormatReader)this);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/in/ARFReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */