/*     */ package loci.formats.in;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.StringReader;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.Vector;
/*     */ import loci.common.DataTools;
/*     */ import loci.common.DateTools;
/*     */ import loci.common.IniList;
/*     */ import loci.common.IniParser;
/*     */ import loci.common.IniTable;
/*     */ import loci.common.Location;
/*     */ import loci.common.RandomAccessInputStream;
/*     */ import loci.formats.CoreMetadata;
/*     */ import loci.formats.FormatException;
/*     */ import loci.formats.FormatReader;
/*     */ import loci.formats.FormatTools;
/*     */ import loci.formats.IFormatReader;
/*     */ import loci.formats.MetadataTools;
/*     */ import loci.formats.meta.MetadataStore;
/*     */ import loci.formats.tiff.IFD;
/*     */ import loci.formats.tiff.TiffIFDEntry;
/*     */ import loci.formats.tiff.TiffParser;
/*     */ import ome.xml.model.primitives.NonNegativeInteger;
/*     */ import ome.xml.model.primitives.PositiveInteger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BDReader
/*     */   extends FormatReader
/*     */ {
/*     */   private static final String EXPERIMENT_FILE = "Experiment.exp";
/*  73 */   private static final String[] META_EXT = new String[] { "drt", "dye", "exp", "plt", "txt", "geo", "ltp", "ffc", "afc", "mon", "xyz", "mac", "bmp", "roi", "adf" };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  78 */   private Vector<String> metadataFiles = new Vector<String>();
/*  79 */   private Vector<String> channelNames = new Vector<String>();
/*  80 */   private Vector<String> wellLabels = new Vector<String>(); private String plateName;
/*     */   private String plateDescription;
/*     */   private String[][] tiffs;
/*     */   private MinimalTiffReader reader;
/*     */   private String roiFile;
/*     */   private int[] emWave;
/*     */   private int[] exWave;
/*     */   private double[] gain;
/*     */   private double[] offset;
/*     */   private double[] exposure;
/*     */   private String binning;
/*     */   private String objective;
/*     */   private int wellRows;
/*     */   private int wellCols;
/*     */   private int fieldRows;
/*     */   private int fieldCols;
/*     */   
/*     */   public BDReader() {
/*  98 */     super("BD Pathway", new String[] { "exp", "tif" });
/*  99 */     this.domains = new String[] { "High-Content Screening (HCS)" };
/* 100 */     this.hasCompanionFiles = true;
/* 101 */     this.suffixSufficient = false;
/* 102 */     this.suffixNecessary = false;
/* 103 */     this.datasetDescription = "Multiple files (.exp, .dye, .ltp, …) plus one or more directories containing .tif and .bmp files";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isThisType(String name, boolean open) {
/* 111 */     if (name.endsWith("Experiment.exp")) return true; 
/* 112 */     if (!open) return false;
/*     */     
/* 114 */     String id = (new Location(name)).getAbsolutePath();
/*     */     try {
/* 116 */       id = locateExperimentFile(id);
/*     */     }
/* 118 */     catch (FormatException f) {
/* 119 */       return false;
/*     */     }
/* 121 */     catch (IOException f) {
/* 122 */       return false;
/*     */     }
/* 124 */     catch (NullPointerException e) {
/* 125 */       return false;
/*     */     } 
/*     */     
/* 128 */     if (id.endsWith("Experiment.exp")) return true;
/*     */     
/* 130 */     return super.isThisType(name, open);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isThisType(RandomAccessInputStream stream) throws IOException {
/* 135 */     TiffParser p = new TiffParser(stream);
/* 136 */     IFD ifd = p.getFirstIFD();
/* 137 */     if (ifd == null) return false;
/*     */     
/* 139 */     String software = ifd.getIFDTextValue(305);
/* 140 */     if (software == null) return false;
/*     */     
/* 142 */     return software.trim().startsWith("MATROX Imaging Library");
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getSeriesUsedFiles(boolean noPixels) {
/* 147 */     FormatTools.assertId(this.currentId, true, 1);
/*     */     
/* 149 */     Vector<String> files = new Vector<String>();
/* 150 */     for (String file : this.metadataFiles) {
/* 151 */       if (file != null) files.add(file);
/*     */     
/*     */     } 
/* 154 */     if (!noPixels && this.tiffs != null) {
/* 155 */       int well = getSeries() / this.fieldRows * this.fieldCols;
/* 156 */       for (int i = 0; i < (this.tiffs[well]).length; i++) {
/* 157 */         files.add(this.tiffs[well][i]);
/*     */       }
/*     */     } 
/*     */     
/* 161 */     return files.<String>toArray(new String[files.size()]);
/*     */   }
/*     */ 
/*     */   
/*     */   public void close(boolean fileOnly) throws IOException {
/* 166 */     super.close(fileOnly);
/* 167 */     if (!fileOnly) {
/* 168 */       if (this.reader != null) this.reader.close(); 
/* 169 */       this.reader = null;
/* 170 */       this.tiffs = (String[][])null;
/* 171 */       this.plateName = null;
/* 172 */       this.plateDescription = null;
/* 173 */       this.channelNames.clear();
/* 174 */       this.metadataFiles.clear();
/* 175 */       this.wellLabels.clear();
/* 176 */       this.wellRows = 0;
/* 177 */       this.wellCols = 0;
/* 178 */       this.fieldRows = 0;
/* 179 */       this.fieldCols = 0;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int fileGroupOption(String id) throws FormatException, IOException {
/* 185 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSingleFile(String id) throws FormatException, IOException {
/* 190 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] openBytes(int no, byte[] buf, int x, int y, int w, int h) throws FormatException, IOException {
/* 199 */     FormatTools.checkPlaneParameters((IFormatReader)this, no, buf.length, x, y, w, h);
/*     */     
/* 201 */     String file = getFilename(getSeries(), no);
/* 202 */     int field = getSeries() % this.fieldRows * this.fieldCols;
/* 203 */     int fieldRow = field / this.fieldCols;
/* 204 */     int fieldCol = field % this.fieldCols;
/*     */     
/* 206 */     if (file != null) {
/*     */       try {
/* 208 */         this.reader.setId(file);
/* 209 */         if (this.fieldRows * this.fieldCols == 1) {
/* 210 */           this.reader.openBytes(0, buf, x, y, w, h);
/*     */         
/*     */         }
/*     */         else {
/*     */           
/* 215 */           int fx = x + fieldCol * getSizeX();
/* 216 */           int fy = y + fieldRow * getSizeY();
/* 217 */           this.reader.openBytes(0, buf, fx, fy, w, h);
/*     */         }
/*     */       
/* 220 */       } catch (FormatException e) {
/* 221 */         LOGGER.debug("Could not read file " + file, (Throwable)e);
/* 222 */         return buf;
/*     */       }
/* 224 */       catch (IOException e) {
/* 225 */         LOGGER.debug("Could not read file " + file, e);
/* 226 */         return buf;
/*     */       } 
/*     */     }
/*     */     
/* 230 */     return buf;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOptimalTileWidth() {
/* 235 */     FormatTools.assertId(this.currentId, true, 1);
/* 236 */     return this.reader.getOptimalTileWidth();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOptimalTileHeight() {
/* 241 */     FormatTools.assertId(this.currentId, true, 1);
/* 242 */     return this.reader.getOptimalTileHeight();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initFile(String id) throws FormatException, IOException {
/* 250 */     id = locateExperimentFile(id);
/* 251 */     super.initFile(id);
/* 252 */     Location dir = (new Location(id)).getAbsoluteFile().getParentFile();
/*     */     
/* 254 */     for (String file : dir.list(true)) {
/* 255 */       Location f = new Location(dir, file);
/* 256 */       if (!f.isDirectory()) {
/* 257 */         if (checkSuffix(file, META_EXT)) {
/* 258 */           this.metadataFiles.add(f.getAbsolutePath());
/*     */         }
/*     */       } else {
/*     */         
/* 262 */         for (String well : f.list(true)) {
/* 263 */           Location wellFile = new Location(f, well);
/* 264 */           if (!wellFile.isDirectory() && 
/* 265 */             checkSuffix(well, META_EXT)) {
/* 266 */             this.metadataFiles.add(wellFile.getAbsolutePath());
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 274 */     IniList experiment = readMetaData(id);
/*     */     
/* 276 */     if (getMetadataOptions().getMetadataLevel() != MetadataLevel.MINIMUM) {
/* 277 */       this.objective = (String)experiment.getTable("Geometry").get("Name");
/* 278 */       IniTable camera = experiment.getTable("Camera");
/* 279 */       this.binning = (String)camera.get("BinX") + "x" + (String)camera.get("BinY");
/*     */       
/* 281 */       parseChannelData(dir);
/*     */       
/* 283 */       addGlobalMeta("Objective", this.objective);
/* 284 */       addGlobalMeta("Camera binning", this.binning);
/*     */     } 
/*     */     
/* 287 */     Vector<String> uniqueRows = new Vector<String>();
/* 288 */     Vector<String> uniqueColumns = new Vector<String>();
/*     */     
/* 290 */     for (String well : this.wellLabels) {
/* 291 */       String str1 = well.substring(0, 1).trim();
/* 292 */       String column = well.substring(1).trim();
/*     */       
/* 294 */       if (!uniqueRows.contains(str1) && str1.length() > 0) uniqueRows.add(str1); 
/* 295 */       if (!uniqueColumns.contains(column) && column.length() > 0) {
/* 296 */         uniqueColumns.add(column);
/*     */       }
/*     */     } 
/*     */     
/* 300 */     int nSlices = (getSizeZ() == 0) ? 1 : getSizeZ();
/* 301 */     int nTimepoints = getSizeT();
/* 302 */     int nWells = this.wellLabels.size();
/* 303 */     int nChannels = (getSizeC() == 0) ? this.channelNames.size() : getSizeC();
/* 304 */     if (nChannels == 0) nChannels = 1;
/*     */     
/* 306 */     this.tiffs = getTiffs(dir.getAbsolutePath());
/*     */     
/* 308 */     this.reader = new MinimalTiffReader();
/* 309 */     this.reader.setId(this.tiffs[0][0]);
/*     */     
/* 311 */     int sizeX = this.reader.getSizeX();
/* 312 */     int sizeY = this.reader.getSizeY();
/* 313 */     int pixelType = this.reader.getPixelType();
/* 314 */     boolean rgb = this.reader.isRGB();
/* 315 */     boolean interleaved = this.reader.isInterleaved();
/* 316 */     boolean indexed = this.reader.isIndexed();
/* 317 */     boolean littleEndian = this.reader.isLittleEndian();
/*     */     
/* 319 */     if (getMetadataOptions().getMetadataLevel() != MetadataLevel.MINIMUM) {
/* 320 */       IniParser parser = new IniParser();
/* 321 */       for (String metadataFile : this.metadataFiles) {
/* 322 */         String filename = (new Location(metadataFile)).getName();
/* 323 */         if (!checkSuffix(metadataFile, new String[] { "txt", "bmp", "adf", "roi" })) {
/*     */ 
/*     */           
/* 326 */           String data = DataTools.readFile(metadataFile);
/* 327 */           IniList ini = parser.parseINI(new BufferedReader(new StringReader(data)));
/*     */           
/* 329 */           HashMap<String, String> h = ini.flattenIntoHashMap();
/* 330 */           for (String key : h.keySet()) {
/* 331 */             addGlobalMeta(filename + " " + key, h.get(key));
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 337 */     for (int i = 0; i < getSeriesCount(); i++) {
/* 338 */       this.core[i] = new CoreMetadata();
/* 339 */       (this.core[i]).sizeC = nChannels;
/* 340 */       (this.core[i]).sizeZ = nSlices;
/* 341 */       (this.core[i]).sizeT = nTimepoints;
/* 342 */       (this.core[i]).sizeX = sizeX / this.fieldCols;
/* 343 */       (this.core[i]).sizeY = sizeY / this.fieldRows;
/* 344 */       (this.core[i]).pixelType = pixelType;
/* 345 */       (this.core[i]).rgb = rgb;
/* 346 */       (this.core[i]).interleaved = interleaved;
/* 347 */       (this.core[i]).indexed = indexed;
/* 348 */       (this.core[i]).littleEndian = littleEndian;
/* 349 */       (this.core[i]).dimensionOrder = "XYZTC";
/* 350 */       (this.core[i]).imageCount = nSlices * nTimepoints * nChannels;
/*     */     } 
/*     */     
/* 353 */     MetadataStore store = makeFilterMetadata();
/* 354 */     boolean populatePlanes = (getMetadataOptions().getMetadataLevel() != MetadataLevel.MINIMUM);
/*     */     
/* 356 */     MetadataTools.populatePixels(store, (IFormatReader)this, populatePlanes);
/*     */     
/* 358 */     String plateAcqID = MetadataTools.createLSID("PlateAcquisition", new int[] { 0, 0 });
/* 359 */     store.setPlateAcquisitionID(plateAcqID, 0, 0);
/*     */     
/* 361 */     PositiveInteger fieldCount = FormatTools.getMaxFieldCount(Integer.valueOf(this.fieldRows * this.fieldCols));
/*     */     
/* 363 */     if (fieldCount != null) {
/* 364 */       store.setPlateAcquisitionMaximumFieldCount(fieldCount, 0, 0);
/*     */     }
/*     */     
/* 367 */     for (int row = 0; row < this.wellRows; row++) {
/* 368 */       for (int col = 0; col < this.wellCols; col++) {
/* 369 */         int index = row * this.wellCols + col;
/*     */         
/* 371 */         store.setWellID(MetadataTools.createLSID("Well", new int[] { 0, index }), 0, index);
/* 372 */         store.setWellRow(new NonNegativeInteger(Integer.valueOf(row)), 0, index);
/* 373 */         store.setWellColumn(new NonNegativeInteger(Integer.valueOf(col)), 0, index);
/*     */       } 
/*     */     } 
/*     */     
/* 377 */     for (int j = 0; j < getSeriesCount(); j++) {
/* 378 */       int well = j / this.fieldRows * this.fieldCols;
/* 379 */       int field = j % this.fieldRows * this.fieldCols;
/*     */       
/* 381 */       MetadataTools.setDefaultCreationDate(store, this.tiffs[well][0], j);
/*     */       
/* 383 */       String name = this.wellLabels.get(well);
/* 384 */       String str1 = name.substring(0, 1);
/* 385 */       Integer col = Integer.valueOf(Integer.parseInt(name.substring(1)));
/*     */       
/* 387 */       int index = (str1.charAt(0) - 65) * this.wellCols + col.intValue() - 1;
/*     */       
/* 389 */       String wellSampleID = MetadataTools.createLSID("WellSample", new int[] { 0, index, field });
/*     */       
/* 391 */       store.setWellSampleID(wellSampleID, 0, index, field);
/* 392 */       store.setWellSampleIndex(new NonNegativeInteger(Integer.valueOf(j)), 0, index, field);
/*     */       
/* 394 */       String imageID = MetadataTools.createLSID("Image", new int[] { j });
/* 395 */       store.setWellSampleImageRef(imageID, 0, index, field);
/* 396 */       store.setImageID(imageID, j);
/* 397 */       store.setImageName(name + " Field #" + (field + 1), j);
/*     */       
/* 399 */       store.setPlateAcquisitionWellSampleRef(wellSampleID, 0, 0, j);
/*     */     } 
/*     */     
/* 402 */     MetadataLevel level = getMetadataOptions().getMetadataLevel();
/* 403 */     if (level != MetadataLevel.MINIMUM) {
/* 404 */       String instrumentID = MetadataTools.createLSID("Instrument", new int[] { 0 });
/* 405 */       store.setInstrumentID(instrumentID, 0);
/*     */       
/* 407 */       String objectiveID = MetadataTools.createLSID("Objective", new int[] { 0, 0 });
/* 408 */       store.setObjectiveID(objectiveID, 0, 0);
/* 409 */       if (this.objective != null) {
/* 410 */         String[] tokens = this.objective.split(" ");
/* 411 */         String mag = tokens[0].replaceAll("[xX]", "");
/* 412 */         String na = null;
/* 413 */         int naIndex = 0;
/* 414 */         for (int m = 0; m < tokens.length; m++) {
/* 415 */           if (tokens[m].equals("NA")) {
/* 416 */             naIndex = m + 1;
/* 417 */             na = tokens[naIndex];
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/* 422 */         Integer magnification = new Integer(mag);
/* 423 */         if (magnification.intValue() > 0) {
/* 424 */           store.setObjectiveNominalMagnification(new PositiveInteger(magnification), 0, 0);
/*     */         }
/*     */         else {
/*     */           
/* 428 */           LOGGER.warn("Expected positive value for NominalMagnification; got {}", magnification);
/*     */         } 
/*     */ 
/*     */         
/* 432 */         if (na != null) {
/* 433 */           na = na.substring(0, 1) + "." + na.substring(1);
/* 434 */           store.setObjectiveLensNA(new Double(na), 0, 0);
/*     */         } 
/* 436 */         if (naIndex + 1 < tokens.length) {
/* 437 */           store.setObjectiveManufacturer(tokens[naIndex + 1], 0, 0);
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 442 */       for (int k = 0; k < getSeriesCount(); k++) {
/* 443 */         store.setImageInstrumentRef(instrumentID, k);
/* 444 */         store.setObjectiveSettingsID(objectiveID, k);
/*     */         
/* 446 */         for (int c = 0; c < getSizeC(); c++) {
/* 447 */           store.setChannelName(this.channelNames.get(c), k, c);
/*     */           
/* 449 */           PositiveInteger emission = FormatTools.getEmissionWavelength(Integer.valueOf(this.emWave[c]));
/*     */           
/* 451 */           PositiveInteger excitation = FormatTools.getExcitationWavelength(Integer.valueOf(this.exWave[c]));
/*     */ 
/*     */           
/* 454 */           if (emission != null) {
/* 455 */             store.setChannelEmissionWavelength(emission, k, c);
/*     */           }
/* 457 */           if (excitation != null) {
/* 458 */             store.setChannelExcitationWavelength(excitation, k, c);
/*     */           }
/*     */           
/* 461 */           String detectorID = MetadataTools.createLSID("Detector", new int[] { 0, c });
/* 462 */           store.setDetectorID(detectorID, 0, c);
/* 463 */           store.setDetectorSettingsID(detectorID, k, c);
/* 464 */           store.setDetectorSettingsGain(Double.valueOf(this.gain[c]), k, c);
/* 465 */           store.setDetectorSettingsOffset(Double.valueOf(this.offset[c]), k, c);
/* 466 */           store.setDetectorSettingsBinning(getBinning(this.binning), k, c);
/*     */         } 
/*     */         
/* 469 */         long firstPlane = 0L;
/* 470 */         for (int p = 0; p < getImageCount(); p++) {
/* 471 */           int[] zct = getZCTCoords(p);
/* 472 */           store.setPlaneExposureTime(Double.valueOf(this.exposure[zct[1]]), k, p);
/* 473 */           String file = getFilename(k, p);
/* 474 */           if (file != null) {
/* 475 */             long plane = getTimestamp(file);
/* 476 */             if (p == 0) {
/* 477 */               firstPlane = plane;
/*     */             }
/* 479 */             double timestamp = (plane - firstPlane) / 1000.0D;
/* 480 */             store.setPlaneDeltaT(Double.valueOf(timestamp), k, p);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/* 485 */       store.setPlateID(MetadataTools.createLSID("Plate", new int[] { 0 }), 0);
/* 486 */       store.setPlateRowNamingConvention(getNamingConvention("Letter"), 0);
/* 487 */       store.setPlateColumnNamingConvention(getNamingConvention("Number"), 0);
/* 488 */       store.setPlateName(this.plateName, 0);
/* 489 */       store.setPlateDescription(this.plateDescription, 0);
/*     */       
/* 491 */       if (level != MetadataLevel.NO_OVERLAYS) {
/* 492 */         parseROIs(store);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String locateExperimentFile(String id) throws FormatException, IOException {
/* 503 */     if (!checkSuffix(id, "exp")) {
/* 504 */       Location parent = (new Location(id)).getAbsoluteFile().getParentFile();
/* 505 */       if (checkSuffix(id, "tif")) parent = parent.getParentFile(); 
/* 506 */       Location expFile = new Location(parent, "Experiment.exp");
/* 507 */       if (expFile.exists()) {
/* 508 */         return expFile.getAbsolutePath();
/*     */       }
/* 510 */       throw new FormatException("Could not find Experiment.exp in " + parent.getAbsolutePath());
/*     */     } 
/*     */     
/* 513 */     return id;
/*     */   }
/*     */   
/*     */   private IniList readMetaData(String id) throws IOException {
/* 517 */     IniParser parser = new IniParser();
/* 518 */     FileInputStream idStream = new FileInputStream(id);
/* 519 */     IniList exp = parser.parseINI(new BufferedReader(new InputStreamReader(idStream, "UTF-8")));
/*     */     
/* 521 */     IniList plate = null;
/* 522 */     IniList xyz = null;
/*     */ 
/*     */     
/* 525 */     for (String filename : this.metadataFiles) {
/* 526 */       if (checkSuffix(filename, "plt")) {
/* 527 */         FileInputStream stream = new FileInputStream(filename);
/* 528 */         plate = parser.parseINI(new BufferedReader(new InputStreamReader(stream, "UTF-8")));
/*     */         
/* 530 */         stream.close(); continue;
/*     */       } 
/* 532 */       if (checkSuffix(filename, "xyz")) {
/* 533 */         FileInputStream stream = new FileInputStream(filename);
/* 534 */         xyz = parser.parseINI(new BufferedReader(new InputStreamReader(stream, "UTF-8")));
/*     */         
/* 536 */         stream.close(); continue;
/*     */       } 
/* 538 */       if (filename.endsWith("RoiSummary.txt")) {
/* 539 */         this.roiFile = filename;
/* 540 */         if (getMetadataOptions().getMetadataLevel() != MetadataLevel.MINIMUM) {
/* 541 */           RandomAccessInputStream s = new RandomAccessInputStream(filename);
/* 542 */           String line = s.readLine().trim();
/* 543 */           while (!line.endsWith(".adf\"")) {
/* 544 */             line = s.readLine().trim();
/*     */           }
/* 546 */           this.plateName = line.substring(line.indexOf(":")).trim();
/* 547 */           this.plateName = this.plateName.replace('/', File.separatorChar);
/* 548 */           this.plateName = this.plateName.replace('\\', File.separatorChar);
/* 549 */           for (int j = 0; j < 3; j++) {
/* 550 */             this.plateName = this.plateName.substring(0, this.plateName.lastIndexOf(File.separator));
/*     */           }
/*     */           
/* 553 */           this.plateName = this.plateName.substring(this.plateName.lastIndexOf(File.separator) + 1);
/*     */ 
/*     */           
/* 556 */           s.close();
/*     */         } 
/*     */       } 
/*     */     } 
/* 560 */     if (plate == null) throw new IOException("No Plate File");
/*     */     
/* 562 */     IniTable plateType = plate.getTable("PlateType");
/*     */     
/* 564 */     if (this.plateName == null) {
/* 565 */       this.plateName = (String)plateType.get("Brand");
/*     */     }
/* 567 */     this.plateDescription = (String)plateType.get("Brand") + " " + (String)plateType.get("Description");
/*     */ 
/*     */     
/* 570 */     int nWells = Integer.parseInt((String)plateType.get("Wells"));
/* 571 */     if (nWells == 96) {
/* 572 */       this.wellRows = 8;
/* 573 */       this.wellCols = 12;
/*     */     }
/* 575 */     else if (nWells == 384) {
/* 576 */       this.wellRows = 16;
/* 577 */       this.wellCols = 24;
/*     */     } 
/*     */     
/* 580 */     Location dir = (new Location(id)).getAbsoluteFile().getParentFile();
/* 581 */     String[] wellList = dir.list();
/* 582 */     Arrays.sort((Object[])wellList);
/* 583 */     for (String filename : wellList) {
/* 584 */       if (filename.startsWith("Well ")) {
/* 585 */         this.wellLabels.add(filename.split("\\s|\\.")[1]);
/*     */       }
/*     */     } 
/*     */     
/* 589 */     IniTable imageTable = exp.getTable("Image");
/* 590 */     boolean montage = ((String)imageTable.get("Montaged")).equals("1");
/* 591 */     if (montage) {
/* 592 */       this.fieldRows = Integer.parseInt((String)imageTable.get("TilesY"));
/* 593 */       this.fieldCols = Integer.parseInt((String)imageTable.get("TilesX"));
/*     */     } else {
/*     */       
/* 596 */       this.fieldRows = 1;
/* 597 */       this.fieldCols = 1;
/*     */     } 
/*     */     
/* 600 */     this.core = new CoreMetadata[this.wellLabels.size() * this.fieldRows * this.fieldCols];
/*     */     
/* 602 */     this.core[0] = new CoreMetadata();
/*     */     
/* 604 */     (this.core[0]).sizeC = Integer.parseInt((String)exp.getTable("General").get("Dyes"));
/* 605 */     (this.core[0]).bitsPerPixel = Integer.parseInt((String)exp.getTable("Camera").get("BitdepthUsed"));
/*     */ 
/*     */     
/* 608 */     IniTable dyeTable = exp.getTable("Dyes");
/* 609 */     for (int i = 1; i <= getSizeC(); i++) {
/* 610 */       this.channelNames.add(dyeTable.get(Integer.toString(i)));
/*     */     }
/*     */     
/* 613 */     if (xyz != null) {
/* 614 */       IniTable zTable = xyz.getTable("Z1Axis");
/* 615 */       boolean zEnabled = ("1".equals(zTable.get("Z1AxisEnabled")) && "1".equals(zTable.get("Z1AxisMode")));
/*     */       
/* 617 */       if (zEnabled) {
/* 618 */         (this.core[0]).sizeZ = (int)Double.parseDouble((String)zTable.get("Z1AxisValue")) + 1;
/*     */       } else {
/*     */         
/* 621 */         (this.core[0]).sizeZ = 1;
/*     */       } 
/*     */     } else {
/*     */       
/* 625 */       (this.core[0]).sizeZ = 1;
/*     */     } 
/*     */ 
/*     */     
/* 629 */     (this.core[0]).sizeT = 0;
/*     */     
/* 631 */     Location well = new Location(dir.getAbsolutePath(), "Well " + (String)this.wellLabels.get(1));
/*     */     
/* 633 */     for (String channelName : this.channelNames) {
/* 634 */       int images = 0;
/* 635 */       for (String filename : well.list()) {
/* 636 */         if (filename.startsWith(channelName) && filename.endsWith(".tif")) {
/* 637 */           images++;
/*     */         }
/*     */       } 
/*     */       
/* 641 */       if (images > getImageCount()) {
/* 642 */         (this.core[0]).sizeT = images / getSizeZ();
/* 643 */         (this.core[0]).imageCount = getSizeZ() * getSizeT() * this.channelNames.size();
/*     */       } 
/*     */     } 
/*     */     
/* 647 */     idStream.close();
/*     */     
/* 649 */     return exp;
/*     */   }
/*     */   
/*     */   private void parseChannelData(Location dir) throws IOException {
/* 653 */     this.emWave = new int[this.channelNames.size()];
/* 654 */     this.exWave = new int[this.channelNames.size()];
/* 655 */     this.exposure = new double[this.channelNames.size()];
/* 656 */     this.gain = new double[this.channelNames.size()];
/* 657 */     this.offset = new double[this.channelNames.size()];
/*     */     
/* 659 */     for (int c = 0; c < this.channelNames.size(); c++) {
/* 660 */       Location dyeFile = new Location(dir, (String)this.channelNames.get(c) + ".dye");
/* 661 */       FileInputStream stream = new FileInputStream(dyeFile.getAbsolutePath());
/* 662 */       IniList dye = (new IniParser()).parseINI(new BufferedReader(new InputStreamReader(stream, "UTF-8")));
/*     */ 
/*     */       
/* 665 */       IniTable numerator = dye.getTable("Numerator");
/* 666 */       String em = (String)numerator.get("Emission");
/* 667 */       em = em.substring(0, em.indexOf(" "));
/* 668 */       this.emWave[c] = Integer.parseInt(em);
/*     */       
/* 670 */       String ex = (String)numerator.get("Excitation");
/* 671 */       ex = ex.substring(0, ex.lastIndexOf(" "));
/* 672 */       if (ex.indexOf(" ") != -1) {
/* 673 */         ex = ex.substring(ex.lastIndexOf(" ") + 1);
/*     */       }
/* 675 */       this.exWave[c] = Integer.parseInt(ex);
/*     */       
/* 677 */       this.exposure[c] = Double.parseDouble((String)numerator.get("Exposure"));
/* 678 */       this.gain[c] = Double.parseDouble((String)numerator.get("Gain"));
/* 679 */       this.offset[c] = Double.parseDouble((String)numerator.get("Offset"));
/*     */       
/* 681 */       stream.close();
/*     */     } 
/*     */   }
/*     */   
/*     */   private String[][] getTiffs(String dir) {
/* 686 */     Location f = new Location(dir);
/* 687 */     Vector<Vector<String>> files = new Vector<Vector<String>>();
/*     */     
/* 689 */     String[] wells = f.list(true);
/* 690 */     Arrays.sort((Object[])wells);
/*     */     
/* 692 */     for (String filename : wells) {
/* 693 */       Location file = (new Location(f, filename)).getAbsoluteFile();
/* 694 */       if (file.isDirectory() && filename.startsWith("Well ")) {
/* 695 */         String[] list = file.list(true);
/* 696 */         Vector<String> tiffList = new Vector<String>();
/* 697 */         Arrays.sort((Object[])list);
/* 698 */         for (String tiff : list) {
/* 699 */           if (tiff.matches(".* - n\\d\\d\\d\\d\\d\\d\\.tif")) {
/* 700 */             tiffList.add((new Location(file, tiff)).getAbsolutePath());
/*     */           }
/*     */         } 
/* 703 */         files.add(tiffList);
/*     */       } 
/*     */     } 
/*     */     
/* 707 */     String[][] tiffFiles = new String[files.size()][];
/* 708 */     for (int i = 0; i < tiffFiles.length; i++) {
/* 709 */       tiffFiles[i] = (String[])((Vector)files.get(i)).toArray((Object[])new String[0]);
/*     */     }
/* 711 */     return tiffFiles;
/*     */   }
/*     */   
/*     */   private void parseROIs(MetadataStore store) throws IOException {
/* 715 */     if (this.roiFile == null)
/* 716 */       return;  String roiData = DataTools.readFile(this.roiFile);
/* 717 */     String[] lines = roiData.split("\r\n");
/*     */     
/* 719 */     int firstRow = 0;
/* 720 */     while (firstRow < lines.length && !lines[firstRow].startsWith("ROI")) {
/* 721 */       firstRow++;
/*     */     }
/* 723 */     firstRow += 2;
/* 724 */     if (firstRow >= lines.length)
/*     */       return; 
/* 726 */     for (int i = firstRow; i < lines.length; i++) {
/* 727 */       String[] cols = lines[i].split("\t");
/* 728 */       if (cols.length < 6)
/*     */         break; 
/* 730 */       if (cols[2].trim().length() > 0) {
/* 731 */         String rectangleID = MetadataTools.createLSID("Shape", new int[] { i - firstRow, 0 });
/* 732 */         store.setRectangleID(rectangleID, i - firstRow, 0);
/* 733 */         store.setRectangleX(new Double(cols[2]), i - firstRow, 0);
/* 734 */         store.setRectangleY(new Double(cols[3]), i - firstRow, 0);
/* 735 */         store.setRectangleWidth(new Double(cols[4]), i - firstRow, 0);
/* 736 */         store.setRectangleHeight(new Double(cols[5]), i - firstRow, 0);
/* 737 */         String roiID = MetadataTools.createLSID("ROI", new int[] { i - firstRow });
/* 738 */         store.setROIID(roiID, i - firstRow);
/* 739 */         for (int s = 0; s < getSeriesCount(); s++) {
/* 740 */           store.setImageROIRef(roiID, s, i - firstRow);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private String getFilename(int series, int no) {
/* 747 */     int[] zct = getZCTCoords(no);
/* 748 */     String channel = this.channelNames.get(zct[1]);
/*     */     
/* 750 */     int well = series / this.fieldRows * this.fieldCols;
/*     */     
/* 752 */     for (int i = 0; i < (this.tiffs[well]).length; i++) {
/* 753 */       String name = this.tiffs[well][i];
/* 754 */       name = name.substring(name.lastIndexOf(File.separator) + 1);
/* 755 */       name = name.substring(0, name.lastIndexOf("."));
/*     */       
/* 757 */       String index = name.substring(name.lastIndexOf("n") + 1);
/*     */       
/* 759 */       int realIndex = getIndex(zct[0], 0, zct[2]);
/*     */       
/* 761 */       if (name.startsWith(channel) && Integer.parseInt(index) == realIndex) {
/* 762 */         return this.tiffs[well][i];
/*     */       }
/*     */     } 
/* 765 */     return null;
/*     */   }
/*     */   
/*     */   private long getTimestamp(String file) throws FormatException, IOException {
/* 769 */     RandomAccessInputStream s = new RandomAccessInputStream(file);
/* 770 */     TiffParser parser = new TiffParser(s);
/* 771 */     parser.setDoCaching(false);
/* 772 */     IFD firstIFD = parser.getFirstIFD();
/* 773 */     if (firstIFD != null) {
/* 774 */       TiffIFDEntry timestamp = (TiffIFDEntry)firstIFD.get(Integer.valueOf(306));
/* 775 */       if (timestamp != null) {
/* 776 */         String stamp = parser.getIFDValue(timestamp).toString();
/* 777 */         s.close();
/* 778 */         stamp = DateTools.formatDate(stamp, BaseTiffReader.DATE_FORMATS);
/* 779 */         return DateTools.getTime(stamp, "yyyy-MM-dd'T'HH:mm:ss");
/*     */       } 
/*     */     } 
/* 782 */     s.close();
/* 783 */     return (new Location(file)).lastModified();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/in/BDReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */