/*    */ package loci.formats.cache;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CrosshairStrategy
/*    */   extends CacheStrategy
/*    */ {
/*    */   public CrosshairStrategy(int[] lengths) {
/* 75 */     super(lengths);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected int[][] getPossiblePositions() {
/* 82 */     int len = 1;
/* 83 */     for (int i = 0; i < this.lengths.length; ) { len += this.lengths[i] - 1; i++; }
/* 84 */      int[][] p = new int[len][this.lengths.length];
/* 85 */     for (int j = 0, c = 0; j < this.lengths.length; j++) {
/* 86 */       for (int k = 1; k < this.lengths[j]; ) { p[++c][j] = k; k++; }
/*    */     
/* 88 */     }  return p;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/cache/CrosshairStrategy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */