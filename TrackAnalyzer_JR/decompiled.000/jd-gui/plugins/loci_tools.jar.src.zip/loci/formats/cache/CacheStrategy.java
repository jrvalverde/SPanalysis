/*     */ package loci.formats.cache;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Comparator;
/*     */ import java.util.Vector;
/*     */ import loci.formats.FormatTools;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class CacheStrategy
/*     */   implements CacheReporter, Comparator, ICacheStrategy
/*     */ {
/*     */   public static final int DEFAULT_RANGE = 0;
/*     */   protected int[] lengths;
/*     */   protected int[] order;
/*     */   protected int[] range;
/*     */   protected int[] priorities;
/*     */   private int[][] positions;
/*     */   private boolean dirty;
/*     */   protected Vector listeners;
/*     */   
/*     */   public CacheStrategy(int[] lengths) {
/*  94 */     this.lengths = lengths;
/*  95 */     this.order = new int[lengths.length];
/*  96 */     Arrays.fill(this.order, 0);
/*  97 */     this.range = new int[lengths.length];
/*  98 */     Arrays.fill(this.range, 0);
/*  99 */     this.priorities = new int[lengths.length];
/* 100 */     Arrays.fill(this.priorities, 0);
/* 101 */     this.positions = getPossiblePositions();
/* 102 */     this.dirty = true;
/* 103 */     this.listeners = new Vector();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract int[][] getPossiblePositions();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int distance(int axis, int value) {
/*     */     int vb;
/* 121 */     switch (this.order[axis]) {
/*     */       case 0:
/* 123 */         if (value == 0) return 0; 
/* 124 */         vb = this.lengths[axis] - value;
/* 125 */         return (value <= vb) ? value : vb;
/*     */       case 1:
/* 127 */         return value;
/*     */       case -1:
/* 129 */         if (value == 0) return 0; 
/* 130 */         return this.lengths[axis] - value;
/*     */     } 
/* 132 */     throw new IllegalStateException("unknown order: " + this.order[axis]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int raster(int[] pos) {
/* 140 */     return FormatTools.positionToRaster(this.lengths, pos);
/*     */   }
/*     */ 
/*     */   
/*     */   protected int[] pos(int raster) {
/* 145 */     return FormatTools.rasterToPosition(this.lengths, raster);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int[] pos(int raster, int[] pos) {
/* 153 */     return FormatTools.rasterToPosition(this.lengths, raster, pos);
/*     */   }
/*     */   
/*     */   protected int length() {
/* 157 */     return FormatTools.getRasterLength(this.lengths);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void addCacheListener(CacheListener l) {
/* 163 */     synchronized (this.listeners) { this.listeners.add(l); }
/*     */   
/*     */   }
/*     */   
/*     */   public void removeCacheListener(CacheListener l) {
/* 168 */     synchronized (this.listeners) { this.listeners.remove(l); }
/*     */   
/*     */   }
/*     */   
/*     */   public CacheListener[] getCacheListeners() {
/*     */     CacheListener[] l;
/* 174 */     synchronized (this.listeners) {
/* 175 */       l = new CacheListener[this.listeners.size()];
/* 176 */       this.listeners.copyInto((Object[])l);
/*     */     } 
/* 178 */     return l;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int compare(Object o1, Object o2) {
/* 188 */     int[] p1 = (int[])o1;
/* 189 */     int[] p2 = (int[])o2;
/*     */     
/*     */     int p;
/* 192 */     for (p = 10; p >= -10; p--) {
/* 193 */       int dist1 = 0, dist2 = 0;
/* 194 */       for (int i = 0; i < p1.length; i++) {
/* 195 */         if (this.priorities[i] == p) {
/* 196 */           dist1 += distance(i, p1[i]);
/* 197 */           dist2 += distance(i, p2[i]);
/*     */         } 
/*     */       } 
/* 200 */       int diff = dist1 - dist2;
/* 201 */       if (diff != 0) return diff;
/*     */     
/*     */     } 
/*     */     
/* 205 */     for (p = 10; p >= -10; p--) {
/* 206 */       int div1 = 0, div2 = 0;
/* 207 */       for (int i = 0; i < p1.length; i++) {
/* 208 */         if (this.priorities[i] == p) {
/* 209 */           if (p1[i] != 0) div1++; 
/* 210 */           if (p2[i] != 0) div2++; 
/*     */         } 
/*     */       } 
/* 213 */       int diff = div1 - div2;
/* 214 */       if (diff != 0) return diff;
/*     */     
/*     */     } 
/* 217 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[][] getLoadList(int[] pos) throws CacheException {
/* 224 */     int[][] loadList = (int[][])null;
/* 225 */     synchronized (this.positions) {
/* 226 */       if (this.dirty) {
/*     */         
/* 228 */         Arrays.sort(this.positions, this);
/* 229 */         this.dirty = false;
/*     */       } 
/*     */ 
/*     */       
/* 233 */       int c = 0; int i;
/* 234 */       for (i = 0; i < this.positions.length; i++) {
/* 235 */         int[] ipos = this.positions[i];
/*     */ 
/*     */         
/* 238 */         boolean ok = true;
/* 239 */         for (int j = 0; j < ipos.length; j++) {
/* 240 */           if (distance(j, ipos[j]) > this.range[j]) {
/* 241 */             ok = false;
/*     */             break;
/*     */           } 
/*     */         } 
/* 245 */         if (ok) c++;
/*     */       
/*     */       } 
/* 248 */       loadList = new int[c][this.lengths.length];
/* 249 */       c = 0;
/*     */ 
/*     */       
/* 252 */       for (i = 0; i < this.positions.length; i++) {
/* 253 */         int[] ipos = this.positions[i];
/*     */ 
/*     */         
/* 256 */         boolean ok = true;
/* 257 */         for (int j = 0; j < ipos.length && c < loadList.length; j++) {
/* 258 */           if (distance(j, ipos[j]) > this.range[j]) {
/* 259 */             ok = false;
/*     */             break;
/*     */           } 
/* 262 */           int value = (pos[j] + ipos[j]) % this.lengths[j];
/* 263 */           loadList[c][j] = value;
/*     */         } 
/* 265 */         if (ok) c++; 
/*     */       } 
/*     */     } 
/* 268 */     return loadList;
/*     */   }
/*     */   
/*     */   public int[] getPriorities() {
/* 272 */     return this.priorities;
/*     */   }
/*     */   
/*     */   public void setPriority(int priority, int axis) {
/* 276 */     if (priority < -10 || priority > 10) {
/* 277 */       throw new IllegalArgumentException("Invalid priority for axis #" + axis + ": " + priority);
/*     */     }
/*     */     
/* 280 */     synchronized (this.positions) {
/* 281 */       this.priorities[axis] = priority;
/* 282 */       this.dirty = true;
/*     */     } 
/* 284 */     notifyListeners(new CacheEvent(this, 4));
/*     */   }
/*     */   
/*     */   public int[] getOrder() {
/* 288 */     return this.order;
/*     */   }
/*     */   
/*     */   public void setOrder(int order, int axis) {
/* 292 */     if (order != 0 && order != 1 && order != -1)
/*     */     {
/*     */       
/* 295 */       throw new IllegalArgumentException("Invalid order for axis #" + axis + ": " + order);
/*     */     }
/*     */     
/* 298 */     synchronized (this.positions) {
/* 299 */       this.order[axis] = order;
/* 300 */       this.dirty = true;
/*     */     } 
/* 302 */     notifyListeners(new CacheEvent(this, 5));
/*     */   }
/*     */   
/*     */   public int[] getRange() {
/* 306 */     return this.range;
/*     */   }
/*     */   
/*     */   public void setRange(int num, int axis) {
/* 310 */     if (num < 0) {
/* 311 */       throw new IllegalArgumentException("Invalid range for axis #" + axis + ": " + num);
/*     */     }
/*     */     
/* 314 */     this.range[axis] = num;
/* 315 */     notifyListeners(new CacheEvent(this, 6));
/*     */   }
/*     */   
/*     */   public int[] getLengths() {
/* 319 */     return this.lengths;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void notifyListeners(CacheEvent e) {
/* 325 */     synchronized (this.listeners) {
/* 326 */       for (int i = 0; i < this.listeners.size(); i++) {
/* 327 */         CacheListener l = this.listeners.elementAt(i);
/* 328 */         l.cacheUpdated(e);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/cache/CacheStrategy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */