/*    */ package loci.formats.cache;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RectangleStrategy
/*    */   extends CacheStrategy
/*    */ {
/*    */   public RectangleStrategy(int[] lengths) {
/* 76 */     super(lengths);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected int[][] getPossiblePositions() {
/* 83 */     int[][] p = new int[length()][this.lengths.length];
/* 84 */     for (int i = 0; i < p.length; ) { pos(i, p[i]); i++; }
/* 85 */      return p;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/cache/RectangleStrategy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */