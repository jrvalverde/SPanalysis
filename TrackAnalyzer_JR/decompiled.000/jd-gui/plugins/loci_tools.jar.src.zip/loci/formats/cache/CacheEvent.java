/*     */ package loci.formats.cache;
/*     */ 
/*     */ import java.lang.reflect.Field;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CacheEvent
/*     */ {
/*     */   public static final int SOURCE_CHANGED = 1;
/*     */   public static final int STRATEGY_CHANGED = 2;
/*     */   public static final int POSITION_CHANGED = 3;
/*     */   public static final int PRIORITIES_CHANGED = 4;
/*     */   public static final int ORDER_CHANGED = 5;
/*     */   public static final int RANGE_CHANGED = 6;
/*     */   public static final int OBJECT_LOADED = 7;
/*     */   public static final int OBJECT_DROPPED = 8;
/*     */   protected Object source;
/*     */   protected int type;
/*     */   protected int index;
/*     */   
/*     */   public CacheEvent(Object source, int type) {
/*  90 */     this(source, type, -1);
/*     */   }
/*     */   
/*     */   public CacheEvent(Object source, int type, int index) {
/*  94 */     this.source = source;
/*  95 */     this.type = type;
/*  96 */     this.index = index;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getSource() {
/* 102 */     return this.source;
/*     */   }
/*     */   public int getType() {
/* 105 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getIndex() {
/* 112 */     return this.index;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 118 */     String sType = "unknown";
/* 119 */     Field[] fields = getClass().getFields();
/* 120 */     for (int i = 0; i < fields.length; i++) {
/*     */       
/* 122 */       try { if (fields[i].getInt(null) == this.type) sType = fields[i].getName();
/*     */          }
/* 124 */       catch (IllegalAccessException exc) {  }
/* 125 */       catch (IllegalArgumentException exc) {}
/*     */     } 
/* 127 */     return super.toString() + ": source=[" + this.source + "] type=" + sType + " index=" + this.index;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/cache/CacheEvent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */