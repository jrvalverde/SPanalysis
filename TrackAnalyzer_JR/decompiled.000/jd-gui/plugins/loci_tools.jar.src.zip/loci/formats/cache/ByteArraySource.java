/*    */ package loci.formats.cache;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import loci.formats.FormatException;
/*    */ import loci.formats.IFormatReader;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ByteArraySource
/*    */   extends CacheSource
/*    */ {
/*    */   public ByteArraySource(IFormatReader r) {
/* 57 */     super(r);
/*    */   }
/*    */   public ByteArraySource(String id) throws CacheException {
/* 60 */     super(id);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object getObject(int index) throws CacheException {
/*    */     
/* 66 */     try { return this.reader.openBytes(index); }
/* 67 */     catch (FormatException exc) { throw new CacheException(exc); }
/* 68 */     catch (IOException exc) { throw new CacheException(exc); }
/*    */   
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/cache/ByteArraySource.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */