/*    */ package loci.formats.cache;
/*    */ 
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CacheUpdater
/*    */   extends Thread
/*    */ {
/* 54 */   private static final Logger LOGGER = LoggerFactory.getLogger(CacheUpdater.class);
/*    */ 
/*    */   
/*    */   private Cache cache;
/*    */ 
/*    */   
/*    */   private boolean quit;
/*    */ 
/*    */ 
/*    */   
/*    */   public CacheUpdater(Cache cache) {
/* 65 */     super("Bio-Formats-Cache-Updater");
/* 66 */     setPriority(1);
/* 67 */     this.cache = cache;
/* 68 */     this.quit = false;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void quit() {
/* 74 */     this.quit = true;
/*    */ 
/*    */ 
/*    */     
/*    */     try {
/* 79 */       join();
/*    */     }
/* 81 */     catch (InterruptedException exc) {
/* 82 */       LOGGER.info("Thread interrupted", exc);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void run() {
/* 89 */     int length = 0;
/*    */     try {
/* 91 */       length = (this.cache.getStrategy().getLoadList(this.cache.getCurrentPos())).length;
/* 92 */       for (int i = 0; i < length && 
/* 93 */         !this.quit; i++) {
/* 94 */         this.cache.recache(i);
/*    */       }
/*    */     }
/* 97 */     catch (CacheException e) {
/* 98 */       LOGGER.info("", (Throwable)e);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/cache/CacheUpdater.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */