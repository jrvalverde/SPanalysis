/*    */ package loci.formats.cache;
/*    */ 
/*    */ import loci.formats.FormatException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CacheException
/*    */   extends FormatException
/*    */ {
/*    */   public CacheException() {}
/*    */   
/*    */   public CacheException(String s) {
/* 52 */     super(s);
/* 53 */   } public CacheException(String s, Throwable cause) { super(s, cause); } public CacheException(Throwable cause) {
/* 54 */     super(cause);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/cache/CacheException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */