/*    */ package loci.formats.cache;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import loci.formats.FileStitcher;
/*    */ import loci.formats.FormatException;
/*    */ import loci.formats.IFormatReader;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class CacheSource
/*    */   implements ICacheSource
/*    */ {
/*    */   protected IFormatReader reader;
/*    */   
/*    */   public CacheSource(IFormatReader r) {
/* 63 */     this.reader = r;
/*    */   }
/*    */   
/*    */   public CacheSource(String id) throws CacheException {
/* 67 */     this((IFormatReader)new FileStitcher()); 
/* 68 */     try { this.reader.setId(id); }
/* 69 */     catch (FormatException exc) { throw new CacheException(exc); }
/* 70 */     catch (IOException exc) { throw new CacheException(exc); }
/*    */   
/*    */   }
/*    */ 
/*    */   
/*    */   public int getObjectCount() {
/* 76 */     return this.reader.getImageCount();
/*    */   }
/*    */   
/*    */   public abstract Object getObject(int paramInt) throws CacheException;
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/cache/CacheSource.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */