package loci.formats.cache;

public interface ICacheStrategy extends CacheReporter {
  public static final int MIN_PRIORITY = -10;
  
  public static final int LOW_PRIORITY = -5;
  
  public static final int NORMAL_PRIORITY = 0;
  
  public static final int HIGH_PRIORITY = 5;
  
  public static final int MAX_PRIORITY = 10;
  
  public static final int CENTERED_ORDER = 0;
  
  public static final int FORWARD_ORDER = 1;
  
  public static final int BACKWARD_ORDER = -1;
  
  int[][] getLoadList(int[] paramArrayOfint) throws CacheException;
  
  int[] getPriorities();
  
  void setPriority(int paramInt1, int paramInt2);
  
  int[] getOrder();
  
  void setOrder(int paramInt1, int paramInt2);
  
  int[] getRange();
  
  void setRange(int paramInt1, int paramInt2);
  
  int[] getLengths();
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/cache/ICacheStrategy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */