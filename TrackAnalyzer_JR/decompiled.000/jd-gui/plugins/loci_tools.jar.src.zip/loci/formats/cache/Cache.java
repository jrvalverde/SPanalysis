/*     */ package loci.formats.cache;
/*     */ 
/*     */ import java.util.Vector;
/*     */ import loci.formats.FormatTools;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Cache
/*     */   implements CacheReporter
/*     */ {
/*     */   protected ICacheStrategy strategy;
/*     */   protected ICacheSource source;
/*     */   protected int[] currentPos;
/*     */   protected Object[] cache;
/*     */   protected boolean[] inCache;
/*     */   protected Vector<CacheListener> listeners;
/*     */   protected boolean autoUpdate;
/*     */   
/*     */   public Cache(ICacheStrategy strategy, ICacheSource source, boolean autoUpdate) throws CacheException {
/*  89 */     if (strategy == null) throw new CacheException("strategy is null"); 
/*  90 */     if (source == null) throw new CacheException("source is null"); 
/*  91 */     this.strategy = strategy;
/*  92 */     this.source = source;
/*  93 */     this.autoUpdate = autoUpdate;
/*  94 */     this.listeners = new Vector<CacheListener>();
/*  95 */     reset();
/*  96 */     if (autoUpdate) recache();
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getObject(int[] pos) throws CacheException {
/* 103 */     if (pos.length != (this.strategy.getLengths()).length) {
/* 104 */       throw new CacheException("Invalid number of axes; got " + pos.length + "; expected " + (this.strategy.getLengths()).length);
/*     */     }
/*     */ 
/*     */     
/* 108 */     int ndx = FormatTools.positionToRaster(this.strategy.getLengths(), pos);
/* 109 */     return this.cache[ndx];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isInCache(int[] pos) throws CacheException {
/* 117 */     return isInCache(FormatTools.positionToRaster(this.strategy.getLengths(), pos));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isInCache(int pos) throws CacheException {
/* 122 */     return this.inCache[pos];
/*     */   }
/*     */ 
/*     */   
/*     */   public void reset() throws CacheException {
/* 127 */     this.currentPos = new int[(this.strategy.getLengths()).length];
/* 128 */     this.cache = new Object[this.source.getObjectCount()];
/* 129 */     this.inCache = new boolean[this.source.getObjectCount()];
/*     */   }
/*     */   
/*     */   public ICacheStrategy getStrategy() {
/* 133 */     return this.strategy;
/*     */   }
/*     */   public ICacheSource getSource() {
/* 136 */     return this.source;
/*     */   }
/*     */   public int[] getCurrentPos() {
/* 139 */     return this.currentPos;
/*     */   }
/*     */   
/*     */   public void setStrategy(ICacheStrategy strategy) throws CacheException {
/* 143 */     if (strategy == null) throw new CacheException("strategy is null"); 
/* 144 */     synchronized (this.listeners) {
/* 145 */       for (int i = 0; i < this.listeners.size(); i++) {
/* 146 */         CacheListener l = this.listeners.elementAt(i);
/* 147 */         this.strategy.removeCacheListener(l);
/* 148 */         strategy.addCacheListener(l);
/*     */       } 
/*     */     } 
/* 151 */     this.strategy = strategy;
/* 152 */     notifyListeners(new CacheEvent(this, 2));
/* 153 */     reset();
/* 154 */     if (this.autoUpdate) recache();
/*     */   
/*     */   }
/*     */   
/*     */   public void setSource(ICacheSource source) throws CacheException {
/* 159 */     if (source == null) throw new CacheException("source is null"); 
/* 160 */     this.source = source;
/* 161 */     notifyListeners(new CacheEvent(this, 1));
/* 162 */     reset();
/* 163 */     if (this.autoUpdate) recache();
/*     */   
/*     */   }
/*     */   
/*     */   public void setCurrentPos(int[] pos) throws CacheException {
/* 168 */     if (pos == null) throw new CacheException("pos is null"); 
/* 169 */     if (pos.length != this.currentPos.length) {
/* 170 */       throw new CacheException("pos length mismatch (is " + pos.length + ", expected " + this.currentPos.length + ")");
/*     */     }
/*     */     
/* 173 */     int[] len = this.strategy.getLengths();
/* 174 */     for (int i = 0; i < pos.length; i++) {
/* 175 */       if (pos[i] < 0 || pos[i] >= len[i]) {
/* 176 */         throw new CacheException("invalid pos[" + i + "] (is " + pos[i] + ", expected [0, " + (len[i] - 1) + "])");
/*     */       }
/*     */     } 
/*     */     
/* 180 */     System.arraycopy(pos, 0, this.currentPos, 0, pos.length);
/* 181 */     int ndx = FormatTools.positionToRaster(len, pos);
/* 182 */     notifyListeners(new CacheEvent(this, 3, ndx));
/* 183 */     if (this.autoUpdate) recache();
/*     */   
/*     */   }
/*     */   
/*     */   public void recache(int n) throws CacheException {
/* 188 */     int[][] indices = this.strategy.getLoadList(this.currentPos);
/* 189 */     int[] len = this.strategy.getLengths();
/*     */     
/* 191 */     for (int i = 0; i < this.inCache.length; i++) {
/* 192 */       boolean found = false;
/* 193 */       for (int j = 0; j < indices.length; j++) {
/* 194 */         if (i == FormatTools.positionToRaster(len, indices[j])) {
/* 195 */           found = true;
/*     */           break;
/*     */         } 
/*     */       } 
/* 199 */       if (!found) {
/* 200 */         this.inCache[i] = false;
/* 201 */         if (this.cache[i] != null) {
/* 202 */           this.cache[i] = null;
/* 203 */           notifyListeners(new CacheEvent(this, 8, i));
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 208 */     int ndx = FormatTools.positionToRaster(len, indices[n]);
/* 209 */     if (ndx >= 0) this.inCache[ndx] = true;
/*     */     
/* 211 */     if (this.cache[ndx] == null) {
/* 212 */       this.cache[ndx] = this.source.getObject(ndx);
/* 213 */       notifyListeners(new CacheEvent(this, 7, ndx));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void recache() throws CacheException {
/* 231 */     for (int i = 0; i < (this.strategy.getLoadList(this.currentPos)).length; i++) {
/* 232 */       recache(i);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addCacheListener(CacheListener l) {
/* 240 */     synchronized (this.listeners) {
/* 241 */       this.listeners.add(l);
/* 242 */       this.strategy.addCacheListener(l);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeCacheListener(CacheListener l) {
/* 248 */     synchronized (this.listeners) {
/* 249 */       this.listeners.remove(l);
/* 250 */       this.strategy.removeCacheListener(l);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public CacheListener[] getCacheListeners() {
/*     */     CacheListener[] l;
/* 257 */     synchronized (this.listeners) {
/* 258 */       l = new CacheListener[this.listeners.size()];
/* 259 */       this.listeners.copyInto((Object[])l);
/*     */     } 
/* 261 */     return l;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void notifyListeners(CacheEvent e) {
/* 268 */     synchronized (this.listeners) {
/* 269 */       for (int i = 0; i < this.listeners.size(); i++) {
/* 270 */         CacheListener l = this.listeners.elementAt(i);
/* 271 */         l.cacheUpdated(e);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/cache/Cache.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */