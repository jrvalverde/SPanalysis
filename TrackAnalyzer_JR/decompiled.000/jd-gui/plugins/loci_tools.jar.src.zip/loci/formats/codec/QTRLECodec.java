/*     */ package loci.formats.codec;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import loci.common.ByteArrayHandle;
/*     */ import loci.common.RandomAccessInputStream;
/*     */ import loci.formats.FormatException;
/*     */ import loci.formats.UnsupportedCompressionException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class QTRLECodec
/*     */   extends BaseCodec
/*     */ {
/*     */   public byte[] compress(byte[] data, CodecOptions options) throws FormatException {
/*  59 */     throw new UnsupportedCompressionException("QTRLE compression not supported.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] decompress(RandomAccessInputStream in, CodecOptions options) throws FormatException, IOException {
/*  67 */     if (in == null)
/*  68 */       throw new IllegalArgumentException("No data to decompress."); 
/*  69 */     byte[] b = new byte[(int)(in.length() - in.getFilePointer())];
/*  70 */     in.read(b);
/*  71 */     return decompress(b, options);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] decompress(byte[] data, CodecOptions options) throws FormatException {
/*  86 */     if (options == null) options = CodecOptions.getDefaultOptions(); 
/*  87 */     if (data == null || data.length == 0)
/*  88 */       throw new IllegalArgumentException("No data to decompress."); 
/*  89 */     int numLines = options.height;
/*     */     
/*  91 */     if (data.length < 8) return options.previousImage;
/*     */     
/*  93 */     int bpp = options.bitsPerSample / 8;
/*  94 */     int line = options.width * bpp;
/*     */     
/*     */     try {
/*  97 */       ByteArrayHandle s = new ByteArrayHandle(data);
/*  98 */       s.skipBytes(4);
/*     */       
/* 100 */       int header = s.readShort();
/* 101 */       int off = 0;
/* 102 */       int start = 0;
/*     */       
/* 104 */       byte[] output = new byte[options.height * line];
/*     */       
/* 106 */       if ((header & 0x8) == 8) {
/* 107 */         start = s.readShort();
/* 108 */         s.skipBytes(2);
/* 109 */         numLines = s.readShort();
/* 110 */         s.skipBytes(2);
/*     */         
/* 112 */         if (options.previousImage != null) {
/* 113 */           for (int j = 0; j < start; j++) {
/* 114 */             System.arraycopy(options.previousImage, off, output, off, line);
/* 115 */             off += line;
/*     */           } 
/*     */         }
/*     */         
/* 119 */         if (options.previousImage != null) {
/* 120 */           off = line * (start + numLines);
/* 121 */           for (int j = start + numLines; j < options.height; j++) {
/* 122 */             System.arraycopy(options.previousImage, off, output, off, line);
/* 123 */             off += line;
/*     */           } 
/*     */         } 
/*     */       } else {
/* 127 */         throw new FormatException("Unsupported header : " + header);
/*     */       } 
/*     */ 
/*     */       
/* 131 */       int skip = 0;
/* 132 */       byte rle = 0;
/*     */       
/* 134 */       int rowPointer = start * line;
/*     */       
/* 136 */       for (int i = 0; i < numLines; i++) {
/* 137 */         skip = s.readUnsignedByte();
/* 138 */         if (skip < 0) skip += 256;
/*     */         
/* 140 */         if (options.previousImage != null) {
/*     */           try {
/* 142 */             System.arraycopy(options.previousImage, rowPointer, output, rowPointer, (skip - 1) * bpp);
/*     */           
/*     */           }
/* 145 */           catch (ArrayIndexOutOfBoundsException e) {}
/*     */         }
/*     */         
/* 148 */         off = rowPointer + (skip - 1) * bpp;
/*     */         while (true) {
/* 150 */           rle = (byte)(s.readUnsignedByte() & 0xFF);
/*     */           
/* 152 */           if (rle == 0) {
/* 153 */             skip = s.readUnsignedByte();
/*     */             
/* 155 */             if (options.previousImage != null) {
/*     */               try {
/* 157 */                 System.arraycopy(options.previousImage, off, output, off, (skip - 1) * bpp);
/*     */               
/*     */               }
/* 160 */               catch (ArrayIndexOutOfBoundsException e) {}
/*     */             }
/*     */             
/* 163 */             off += (skip - 1) * bpp;
/*     */           } else {
/* 165 */             if (rle == -1) {
/* 166 */               if (off < rowPointer + line && options.previousImage != null) {
/* 167 */                 System.arraycopy(options.previousImage, off, output, off, rowPointer + line - off);
/*     */               }
/*     */               
/*     */               break;
/*     */             } 
/* 172 */             if (rle < -1) {
/*     */               
/* 174 */               for (int j = 0; j < -1 * rle && 
/* 175 */                 off < output.length; j++) {
/* 176 */                 System.arraycopy(data, (int)s.getFilePointer(), output, off, bpp);
/*     */                 
/* 178 */                 off += bpp;
/*     */               } 
/*     */ 
/*     */               
/* 182 */               s.skipBytes(bpp);
/*     */             }
/*     */             else {
/*     */               
/* 186 */               int len = rle * bpp;
/* 187 */               if (output.length - off < len) len = output.length - off; 
/* 188 */               if (s.length() - s.getFilePointer() < len) {
/* 189 */                 len = (int)(s.length() - s.getFilePointer());
/*     */               }
/* 191 */               if (len < 0) len = 0; 
/* 192 */               if (off > output.length) off = output.length; 
/* 193 */               s.read(output, off, len);
/* 194 */               off += len;
/*     */             } 
/* 196 */           }  if (s.getFilePointer() >= s.length()) return output; 
/*     */         } 
/* 198 */         rowPointer += line;
/*     */       } 
/* 200 */       return output;
/*     */     }
/* 202 */     catch (IOException e) {
/* 203 */       throw new FormatException(e);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/codec/QTRLECodec.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */