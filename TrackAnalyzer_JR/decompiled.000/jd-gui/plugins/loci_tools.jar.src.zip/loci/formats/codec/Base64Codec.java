/*     */ package loci.formats.codec;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import loci.common.RandomAccessInputStream;
/*     */ import loci.formats.FormatException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Base64Codec
/*     */   extends BaseCodec
/*     */ {
/*     */   private static final byte PAD = 61;
/*  61 */   private static byte[] base64Alphabet = new byte[255];
/*  62 */   private static byte[] lookupBase64Alphabet = new byte[255];
/*     */   static {
/*     */     int i;
/*  65 */     for (i = 0; i < 255; i++) {
/*  66 */       base64Alphabet[i] = -1;
/*     */     }
/*  68 */     for (i = 90; i >= 65; i--) {
/*  69 */       base64Alphabet[i] = (byte)(i - 65);
/*  70 */       lookupBase64Alphabet[i - 65] = (byte)i;
/*     */     } 
/*  72 */     for (i = 122; i >= 97; i--) {
/*  73 */       base64Alphabet[i] = (byte)(i - 97 + 26);
/*  74 */       lookupBase64Alphabet[i - 97 + 26] = (byte)i;
/*     */     } 
/*  76 */     for (i = 57; i >= 48; i--) {
/*  77 */       base64Alphabet[i] = (byte)(i - 48 + 52);
/*  78 */       lookupBase64Alphabet[i - 48 + 52] = (byte)i;
/*     */     } 
/*     */     
/*  81 */     base64Alphabet[43] = 62;
/*  82 */     base64Alphabet[47] = 63;
/*     */     
/*  84 */     lookupBase64Alphabet[62] = 43;
/*  85 */     lookupBase64Alphabet[63] = 47;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] compress(byte[] input, CodecOptions options) throws FormatException {
/*  92 */     if (input == null || input.length == 0) return null; 
/*  93 */     int dataBits = input.length * 8;
/*  94 */     int fewerThan24 = dataBits % 24;
/*  95 */     int numTriples = dataBits / 24;
/*  96 */     ByteVector encoded = new ByteVector();
/*     */ 
/*     */ 
/*     */     
/* 100 */     int dataIndex = 0;
/*     */     
/* 102 */     for (int i = 0; i < numTriples; i++) {
/* 103 */       dataIndex = i * 3;
/* 104 */       byte b1 = input[dataIndex];
/* 105 */       byte b2 = input[dataIndex + 1];
/* 106 */       byte b3 = input[dataIndex + 2];
/*     */       
/* 108 */       byte l = (byte)(b2 & 0xF);
/* 109 */       byte k = (byte)(b1 & 0x3);
/*     */       
/* 111 */       byte v1 = ((b1 & Byte.MIN_VALUE) == 0) ? (byte)(b1 >> 2) : (byte)(b1 >> 2 ^ 0xC0);
/*     */       
/* 113 */       byte v2 = ((b2 & Byte.MIN_VALUE) == 0) ? (byte)(b2 >> 4) : (byte)(b2 >> 4 ^ 0xF0);
/*     */       
/* 115 */       byte v3 = ((b3 & Byte.MIN_VALUE) == 0) ? (byte)(b3 >> 6) : (byte)(b3 >> 6 ^ 0xFC);
/*     */ 
/*     */       
/* 118 */       encoded.add(lookupBase64Alphabet[v1]);
/* 119 */       encoded.add(lookupBase64Alphabet[v2 | k << 4]);
/* 120 */       encoded.add(lookupBase64Alphabet[l << 2 | v3]);
/* 121 */       encoded.add(lookupBase64Alphabet[b3 & 0x3F]);
/*     */     } 
/*     */     
/* 124 */     dataIndex = numTriples * 3;
/*     */     
/* 126 */     if (fewerThan24 == 8) {
/* 127 */       byte b1 = input[dataIndex];
/* 128 */       byte k = (byte)(b1 & 0x3);
/* 129 */       byte v = ((b1 & Byte.MIN_VALUE) == 0) ? (byte)(b1 >> 2) : (byte)(b1 >> 2 ^ 0xC0);
/*     */       
/* 131 */       encoded.add(lookupBase64Alphabet[v]);
/* 132 */       encoded.add(lookupBase64Alphabet[k << 4]);
/* 133 */       encoded.add((byte)61);
/* 134 */       encoded.add((byte)61);
/*     */     }
/* 136 */     else if (fewerThan24 == 16) {
/* 137 */       byte b1 = input[dataIndex];
/* 138 */       byte b2 = input[dataIndex + 1];
/* 139 */       byte l = (byte)(b2 & 0xF);
/* 140 */       byte k = (byte)(b1 & 0x3);
/*     */       
/* 142 */       byte v1 = ((b1 & Byte.MIN_VALUE) == 0) ? (byte)(b1 >> 2) : (byte)(b1 >> 2 ^ 0xC0);
/*     */       
/* 144 */       byte v2 = ((b2 & Byte.MIN_VALUE) == 0) ? (byte)(b2 >> 4) : (byte)(b2 >> 4 ^ 0xF0);
/*     */ 
/*     */       
/* 147 */       encoded.add(lookupBase64Alphabet[v1]);
/* 148 */       encoded.add(lookupBase64Alphabet[v2 | k << 4]);
/* 149 */       encoded.add(lookupBase64Alphabet[l << 2]);
/* 150 */       encoded.add((byte)61);
/*     */     } 
/*     */     
/* 153 */     return encoded.toByteArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] decompress(RandomAccessInputStream in, CodecOptions options) throws FormatException, IOException {
/* 160 */     if (in == null)
/* 161 */       throw new IllegalArgumentException("No data to decompress."); 
/* 162 */     if (in.length() == 0L) return new byte[0];
/*     */     
/* 164 */     byte b3 = 0, b4 = 0, marker0 = 0, marker1 = 0;
/*     */     
/* 166 */     ByteVector decodedData = new ByteVector();
/*     */     
/* 168 */     byte[] block = new byte[8192];
/* 169 */     int nRead = in.read(block);
/* 170 */     int p = 0;
/* 171 */     byte b1 = base64Alphabet[block[p++]];
/* 172 */     byte b2 = base64Alphabet[block[p++]];
/*     */     
/* 174 */     while (b1 != -1 && b2 != -1 && in.getFilePointer() - nRead + p < in.length()) {
/*     */ 
/*     */       
/* 177 */       marker0 = block[p++];
/* 178 */       marker1 = block[p++];
/*     */       
/* 180 */       if (p == block.length) {
/* 181 */         nRead = in.read(block);
/* 182 */         p = 0;
/*     */       } 
/*     */       
/* 185 */       decodedData.add((byte)(b1 << 2 | b2 >> 4));
/* 186 */       if (p >= nRead && in.getFilePointer() >= in.length())
/* 187 */         break;  if (marker0 != 61 && marker1 != 61) {
/* 188 */         b3 = base64Alphabet[marker0];
/* 189 */         b4 = base64Alphabet[marker1];
/*     */         
/* 191 */         decodedData.add((byte)((b2 & 0xF) << 4 | b3 >> 2 & 0xF));
/* 192 */         decodedData.add((byte)(b3 << 6 | b4));
/*     */       }
/* 194 */       else if (marker0 == 61) {
/* 195 */         decodedData.add((byte)0);
/* 196 */         decodedData.add((byte)0);
/*     */       }
/* 198 */       else if (marker1 == 61) {
/* 199 */         b3 = base64Alphabet[marker0];
/*     */         
/* 201 */         decodedData.add((byte)((b2 & 0xF) << 4 | b3 >> 2 & 0xF));
/* 202 */         decodedData.add((byte)0);
/*     */       } 
/* 204 */       b1 = base64Alphabet[block[p++]];
/* 205 */       b2 = base64Alphabet[block[p++]];
/*     */     } 
/* 207 */     return decodedData.toByteArray();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/codec/Base64Codec.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */