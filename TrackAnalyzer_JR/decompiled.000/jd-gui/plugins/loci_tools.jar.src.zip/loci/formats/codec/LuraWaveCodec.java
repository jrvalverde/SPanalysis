/*     */ package loci.formats.codec;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import loci.common.DataTools;
/*     */ import loci.common.RandomAccessInputStream;
/*     */ import loci.common.services.DependencyException;
/*     */ import loci.common.services.ServiceException;
/*     */ import loci.common.services.ServiceFactory;
/*     */ import loci.formats.FormatException;
/*     */ import loci.formats.MissingLibraryException;
/*     */ import loci.formats.UnsupportedCompressionException;
/*     */ import loci.formats.services.LuraWaveService;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LuraWaveCodec
/*     */   extends BaseCodec
/*     */ {
/*     */   private LuraWaveService service;
/*     */   
/*     */   public byte[] compress(byte[] data, CodecOptions options) throws FormatException {
/*  78 */     throw new UnsupportedCompressionException("LuraWave compression not supported");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] decompress(RandomAccessInputStream in, CodecOptions options) throws FormatException, IOException {
/*  86 */     byte[] buf = new byte[(int)in.length()];
/*  87 */     in.read(buf);
/*  88 */     return decompress(buf, options);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] decompress(byte[] buf, CodecOptions options) throws FormatException {
/* 100 */     initialize();
/*     */     
/* 102 */     BufferedInputStream stream = new BufferedInputStream(new ByteArrayInputStream(buf), 4096);
/*     */     
/*     */     try {
/* 105 */       this.service.initialize(stream);
/*     */     }
/* 107 */     catch (DependencyException e) {
/* 108 */       throw new FormatException("No LuraWave license code was specified.\r\nPlease set one in the lurawave.license system property (e.g., with -Dlurawave.license=XXXX from the command line).", e);
/*     */     }
/* 110 */     catch (ServiceException e) {
/* 111 */       throw new FormatException("Invalid license code: ", e);
/*     */     }
/* 113 */     catch (IOException e) {
/* 114 */       throw new FormatException(e);
/*     */     } 
/*     */     
/* 117 */     int w = this.service.getWidth();
/* 118 */     int h = this.service.getHeight();
/*     */     
/* 120 */     int nbits = 8 * options.maxBytes / w * h;
/*     */     
/* 122 */     if (nbits == 8) {
/* 123 */       byte[] image8 = new byte[w * h];
/*     */       try {
/* 125 */         this.service.decodeToMemoryGray8(image8, -1, 1024, 0);
/*     */       }
/* 127 */       catch (ServiceException e) {
/* 128 */         throw new FormatException("Invalid license code: ", e);
/*     */       } 
/* 130 */       return image8;
/*     */     } 
/* 132 */     if (nbits == 16) {
/* 133 */       short[] image16 = new short[w * h];
/*     */       try {
/* 135 */         this.service.decodeToMemoryGray16(image16, 0, -1, 1024, 0, 1, w, 0, 0, w, h);
/*     */       }
/* 137 */       catch (ServiceException e) {
/* 138 */         throw new FormatException("Invalid license code: ", e);
/*     */       } 
/*     */       
/* 141 */       byte[] output = new byte[w * h * 2];
/* 142 */       for (int i = 0; i < image16.length; i++) {
/* 143 */         DataTools.unpackBytes(image16[i], output, i * 2, 2, true);
/*     */       }
/* 145 */       return output;
/*     */     } 
/*     */     
/* 148 */     throw new FormatException("Unsupported bits per pixel: " + nbits);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initialize() throws FormatException {
/* 162 */     if (this.service != null)
/*     */       return;  try {
/* 164 */       ServiceFactory factory = new ServiceFactory();
/* 165 */       this.service = (LuraWaveService)factory.getInstance(LuraWaveService.class);
/*     */     }
/* 167 */     catch (DependencyException e) {
/* 168 */       throw new MissingLibraryException("The LuraWave decoding library, lwf_jsdk2.6.jar, is required to decode this file.\r\nPlease make sure it is present in your classpath.", e);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/codec/LuraWaveCodec.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */