/*     */ package loci.formats.codec;
/*     */ 
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.DataBuffer;
/*     */ import java.awt.image.DataBufferByte;
/*     */ import java.awt.image.DataBufferUShort;
/*     */ import java.awt.image.WritableRaster;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import loci.common.DataTools;
/*     */ import loci.common.RandomAccessInputStream;
/*     */ import loci.common.services.DependencyException;
/*     */ import loci.common.services.ServiceException;
/*     */ import loci.common.services.ServiceFactory;
/*     */ import loci.formats.FormatException;
/*     */ import loci.formats.MissingLibraryException;
/*     */ import loci.formats.gui.AWTImageTools;
/*     */ import loci.formats.gui.UnsignedIntBuffer;
/*     */ import loci.formats.services.JAIIIOService;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JPEG2000Codec
/*     */   extends BaseCodec
/*     */ {
/*     */   private JAIIIOService service;
/*     */   
/*     */   public byte[] compress(byte[] data, CodecOptions options) throws FormatException {
/*     */     JPEG2000CodecOptions j2kOptions;
/*  92 */     if (data == null || data.length == 0) return data; 
/*  93 */     initialize();
/*     */ 
/*     */     
/*  96 */     if (options instanceof JPEG2000CodecOptions) {
/*  97 */       j2kOptions = (JPEG2000CodecOptions)options;
/*     */     } else {
/*     */       
/* 100 */       j2kOptions = JPEG2000CodecOptions.getDefaultOptions(options);
/*     */     } 
/*     */ 
/*     */     
/* 104 */     ByteArrayOutputStream out = new ByteArrayOutputStream();
/* 105 */     BufferedImage img = null;
/*     */     
/* 107 */     int next = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 116 */     int plane = j2kOptions.width * j2kOptions.height;
/*     */     
/* 118 */     if (j2kOptions.bitsPerSample == 8) {
/* 119 */       byte[][] b = new byte[j2kOptions.channels][plane];
/* 120 */       if (j2kOptions.interleaved) {
/* 121 */         for (int q = 0; q < plane; q++) {
/* 122 */           for (int c = 0; c < j2kOptions.channels; c++) {
/* 123 */             b[c][q] = data[next++];
/*     */           }
/*     */         } 
/*     */       } else {
/*     */         
/* 128 */         for (int c = 0; c < j2kOptions.channels; c++) {
/* 129 */           System.arraycopy(data, c * plane, b[c], 0, plane);
/*     */         }
/*     */       } 
/* 132 */       DataBuffer buffer = new DataBufferByte(b, plane);
/* 133 */       img = AWTImageTools.constructImage(b.length, 0, j2kOptions.width, j2kOptions.height, false, true, buffer, j2kOptions.colorModel);
/*     */ 
/*     */     
/*     */     }
/* 137 */     else if (j2kOptions.bitsPerSample == 16) {
/* 138 */       short[][] s = new short[j2kOptions.channels][plane];
/* 139 */       if (j2kOptions.interleaved) {
/* 140 */         for (int q = 0; q < plane; q++) {
/* 141 */           for (int c = 0; c < j2kOptions.channels; c++) {
/* 142 */             s[c][q] = DataTools.bytesToShort(data, next, 2, j2kOptions.littleEndian);
/*     */             
/* 144 */             next += 2;
/*     */           } 
/*     */         } 
/*     */       } else {
/*     */         
/* 149 */         for (int c = 0; c < j2kOptions.channels; c++) {
/* 150 */           for (int q = 0; q < plane; q++) {
/* 151 */             s[c][q] = DataTools.bytesToShort(data, next, 2, j2kOptions.littleEndian);
/*     */             
/* 153 */             next += 2;
/*     */           } 
/*     */         } 
/*     */       } 
/* 157 */       DataBuffer buffer = new DataBufferUShort(s, plane);
/* 158 */       img = AWTImageTools.constructImage(s.length, 1, j2kOptions.width, j2kOptions.height, false, true, buffer, j2kOptions.colorModel);
/*     */ 
/*     */     
/*     */     }
/* 162 */     else if (j2kOptions.bitsPerSample == 32) {
/* 163 */       int[][] s = new int[j2kOptions.channels][plane];
/* 164 */       if (j2kOptions.interleaved) {
/* 165 */         for (int q = 0; q < plane; q++) {
/* 166 */           for (int c = 0; c < j2kOptions.channels; c++) {
/* 167 */             s[c][q] = DataTools.bytesToInt(data, next, 4, j2kOptions.littleEndian);
/*     */             
/* 169 */             next += 4;
/*     */           } 
/*     */         } 
/*     */       } else {
/*     */         
/* 174 */         for (int c = 0; c < j2kOptions.channels; c++) {
/* 175 */           for (int q = 0; q < plane; q++) {
/* 176 */             s[c][q] = DataTools.bytesToInt(data, next, 4, j2kOptions.littleEndian);
/*     */             
/* 178 */             next += 4;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/* 183 */       UnsignedIntBuffer unsignedIntBuffer = new UnsignedIntBuffer(s, plane);
/* 184 */       img = AWTImageTools.constructImage(s.length, 3, j2kOptions.width, j2kOptions.height, false, true, (DataBuffer)unsignedIntBuffer, j2kOptions.colorModel);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 190 */       this.service.writeImage(out, img, j2kOptions);
/*     */     }
/* 192 */     catch (IOException e) {
/* 193 */       throw new FormatException("Could not compress JPEG-2000 data.", e);
/*     */     }
/* 195 */     catch (ServiceException e) {
/* 196 */       throw new FormatException("Could not compress JPEG-2000 data.", e);
/*     */     } 
/*     */     
/* 199 */     return out.toByteArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] decompress(RandomAccessInputStream in, CodecOptions options) throws FormatException, IOException {
/* 212 */     if (in == null) {
/* 213 */       throw new IllegalArgumentException("No data to decompress.");
/*     */     }
/* 215 */     if (options == null || !(options instanceof JPEG2000CodecOptions)) {
/* 216 */       options = JPEG2000CodecOptions.getDefaultOptions(options);
/*     */     }
/*     */     
/* 219 */     byte[] buf = null;
/* 220 */     long fp = in.getFilePointer();
/* 221 */     if (options.maxBytes == 0) {
/* 222 */       buf = new byte[(int)(in.length() - fp)];
/*     */     } else {
/*     */       
/* 225 */       buf = new byte[(int)(options.maxBytes - fp)];
/*     */     } 
/* 227 */     in.read(buf);
/* 228 */     return decompress(buf, options);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] decompress(byte[] buf, CodecOptions options) throws FormatException {
/* 241 */     initialize();
/*     */     
/* 243 */     if (options == null || !(options instanceof JPEG2000CodecOptions)) {
/* 244 */       options = JPEG2000CodecOptions.getDefaultOptions(options);
/*     */     } else {
/*     */       
/* 247 */       options = new JPEG2000CodecOptions(options);
/*     */     } 
/*     */     
/* 250 */     byte[][] single = (byte[][])null;
/* 251 */     WritableRaster b = null;
/* 252 */     int bpp = options.bitsPerSample / 8;
/*     */     
/*     */     try {
/* 255 */       ByteArrayInputStream bis = new ByteArrayInputStream(buf);
/* 256 */       b = (WritableRaster)this.service.readRaster(bis, (JPEG2000CodecOptions)options);
/*     */       
/* 258 */       single = AWTImageTools.getPixelBytes(b, options.littleEndian);
/* 259 */       bpp = (single[0]).length / b.getWidth() * b.getHeight();
/*     */       
/* 261 */       bis.close();
/* 262 */       b = null;
/*     */     }
/* 264 */     catch (IOException e) {
/* 265 */       throw new FormatException("Could not decompress JPEG2000 image. Please make sure that jai_imageio.jar is installed.", e);
/*     */     
/*     */     }
/* 268 */     catch (ServiceException e) {
/* 269 */       throw new FormatException("Could not decompress JPEG2000 image. Please make sure that jai_imageio.jar is installed.", e);
/*     */     } 
/*     */ 
/*     */     
/* 273 */     if (single.length == 1) return single[0]; 
/* 274 */     byte[] rtn = new byte[single.length * (single[0]).length];
/* 275 */     if (options.interleaved) {
/* 276 */       int next = 0;
/* 277 */       for (int i = 0; i < (single[0]).length / bpp; i++) {
/* 278 */         for (int j = 0; j < single.length; j++) {
/* 279 */           for (int bb = 0; bb < bpp; bb++) {
/* 280 */             rtn[next++] = single[j][i * bpp + bb];
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } else {
/*     */       
/* 286 */       for (int i = 0; i < single.length; i++) {
/* 287 */         System.arraycopy(single[i], 0, rtn, i * (single[0]).length, (single[i]).length);
/*     */       }
/*     */     } 
/*     */     
/* 291 */     single = (byte[][])null;
/*     */     
/* 293 */     return rtn;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initialize() throws FormatException {
/* 308 */     if (this.service != null)
/*     */       return;  try {
/* 310 */       ServiceFactory factory = new ServiceFactory();
/* 311 */       this.service = (JAIIIOService)factory.getInstance(JAIIIOService.class);
/*     */     }
/* 313 */     catch (DependencyException de) {
/* 314 */       throw new MissingLibraryException("The JAI Image I/O Tools are required to read JPEG-2000 files. Please obtain jai_imageio.jar from http://www.openmicroscopy.org/site/support/bio-formats/developers/java-library.html", de);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/codec/JPEG2000Codec.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */