/*     */ package loci.formats.codec;
/*     */ 
/*     */ import java.util.EnumSet;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import loci.common.enumeration.CodedEnum;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum JPEG2000SegmentMarker
/*     */   implements CodedEnum
/*     */ {
/*  54 */   RESERVED_DELIMITER_MARKER_MIN(65328, "Reserved delimiter marker minimum"),
/*  55 */   RESERVED_DELIMITER_MARKER_MAX(65343, "Reserved delimiter marker maximum"),
/*  56 */   SOC(65359, "Start of codestream"),
/*  57 */   SOC_WRONG_ENDIANNESS(20479, "Start of codestream (Wrong endianness)"),
/*  58 */   SOT(65424, "Start of tile"),
/*  59 */   SOD(65427, "Start of data"),
/*  60 */   EOC(65497, "End of codestream"),
/*  61 */   SIZ(65361, "Size"),
/*  62 */   COD(65362, "Coding style default"),
/*  63 */   COC(65363, "Coding style component"),
/*  64 */   RGN(65374, "Region of interest"),
/*  65 */   QCD(65372, "Quantization default"),
/*  66 */   QCC(65373, "Quantization component"),
/*  67 */   POC(65375, "Progression order change"),
/*  68 */   TLM(65365, "Tile lengths"),
/*  69 */   PLM(65367, "Packet length main"),
/*  70 */   PLT(65368, "Packet length tile"),
/*  71 */   PPM(65376, "Packed packet main"),
/*  72 */   PPT(65377, "Packed packet tile"),
/*  73 */   SOP(65425, "Start of packet"),
/*  74 */   EPH(65426, "End of packet header"),
/*  75 */   CRG(65379, "Component registration"),
/*  76 */   COM(65380, "Comment");
/*     */   
/*     */   private int code;
/*     */   
/*     */   private String name;
/*     */   
/*     */   private static final Map<Integer, JPEG2000SegmentMarker> lookup;
/*     */   
/*     */   static {
/*  85 */     lookup = new HashMap<Integer, JPEG2000SegmentMarker>();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  90 */     for (JPEG2000SegmentMarker v : EnumSet.<JPEG2000SegmentMarker>allOf(JPEG2000SegmentMarker.class)) {
/*  91 */       lookup.put(Integer.valueOf(v.getCode()), v);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JPEG2000SegmentMarker get(int code) {
/* 102 */     return lookup.get(Integer.valueOf(code));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   JPEG2000SegmentMarker(int code, String name) {
/* 111 */     this.code = code;
/* 112 */     this.name = name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getCode() {
/* 120 */     return this.code;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 128 */     return this.name;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/codec/JPEG2000SegmentMarker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */