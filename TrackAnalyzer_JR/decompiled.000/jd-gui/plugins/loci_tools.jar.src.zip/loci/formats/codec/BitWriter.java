/*     */ package loci.formats.codec;
/*     */ 
/*     */ import java.util.Random;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BitWriter
/*     */ {
/*  56 */   private static final Logger LOGGER = LoggerFactory.getLogger(BitWriter.class);
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] buf;
/*     */ 
/*     */ 
/*     */   
/*     */   private int index;
/*     */ 
/*     */   
/*     */   private int bit;
/*     */ 
/*     */ 
/*     */   
/*     */   public BitWriter() {
/*  72 */     this(10);
/*     */   }
/*     */   public BitWriter(int size) {
/*  75 */     this.buf = new byte[size];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(int value, int numBits) {
/*  81 */     if (numBits <= 0)
/*  82 */       return;  byte[] bits = new byte[numBits]; int i;
/*  83 */     for (i = 0; i < numBits; i++) {
/*  84 */       bits[i] = (byte)(value & 0x1);
/*  85 */       value >>= 1;
/*     */     } 
/*  87 */     for (i = numBits - 1; i >= 0; i--) {
/*  88 */       int b = bits[i] << 7 - this.bit;
/*  89 */       this.buf[this.index] = (byte)(this.buf[this.index] | b);
/*  90 */       this.bit++;
/*  91 */       if (this.bit > 7) {
/*  92 */         this.bit = 0;
/*  93 */         this.index++;
/*  94 */         if (this.index >= this.buf.length) {
/*     */           
/*  96 */           byte[] newBuf = new byte[this.buf.length * 2];
/*  97 */           System.arraycopy(this.buf, 0, newBuf, 0, this.buf.length);
/*  98 */           this.buf = newBuf;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(String bitString) {
/* 111 */     if (bitString == null)
/* 112 */       throw new IllegalArgumentException("The string cannot be null."); 
/* 113 */     for (int i = 0; i < bitString.length(); i++) {
/* 114 */       if ('1' == bitString.charAt(i)) {
/* 115 */         int b = 1 << 7 - this.bit;
/* 116 */         this.buf[this.index] = (byte)(this.buf[this.index] | b);
/*     */       }
/* 118 */       else if ('0' != bitString.charAt(i)) {
/* 119 */         throw new IllegalArgumentException(bitString.charAt(i) + "found at character " + i + "; 0 or 1 expected. Write only partially completed.");
/*     */       } 
/*     */ 
/*     */       
/* 123 */       this.bit++;
/* 124 */       if (this.bit > 7) {
/* 125 */         this.bit = 0;
/* 126 */         this.index++;
/* 127 */         if (this.index >= this.buf.length) {
/*     */           
/* 129 */           byte[] newBuf = new byte[this.buf.length * 2];
/* 130 */           System.arraycopy(this.buf, 0, newBuf, 0, this.buf.length);
/* 131 */           this.buf = newBuf;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] toByteArray() {
/* 139 */     int size = this.index;
/* 140 */     if (this.bit > 0) size++; 
/* 141 */     byte[] b = new byte[size];
/* 142 */     System.arraycopy(this.buf, 0, b, 0, size);
/* 143 */     return b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {
/* 150 */     int max = 50000;
/*     */     
/* 152 */     LOGGER.info("Generating random list of {} values", Integer.valueOf(max));
/* 153 */     int[] values = new int[max];
/* 154 */     int[] bits = new int[max];
/* 155 */     double log2 = Math.log(2.0D);
/* 156 */     for (int i = 0; i < values.length; i++) {
/* 157 */       values[i] = (int)(50000.0D * Math.random()) + 1;
/* 158 */       int minBits = (int)Math.ceil(Math.log((values[i] + 1)) / log2);
/* 159 */       bits[i] = (int)(10.0D * Math.random()) + minBits;
/*     */     } 
/*     */ 
/*     */     
/* 163 */     LOGGER.info("Writing values to byte array");
/* 164 */     BitWriter out = new BitWriter();
/* 165 */     for (int j = 0; j < values.length; ) { out.write(values[j], bits[j]); j++; }
/*     */ 
/*     */     
/* 168 */     LOGGER.info("Reading values from byte array");
/* 169 */     BitBuffer bb = new BitBuffer(out.toByteArray());
/* 170 */     for (int k = 0; k < values.length; k++) {
/* 171 */       int value = bb.getBits(bits[k]);
/* 172 */       if (value != values[k]) {
/* 173 */         LOGGER.info("Value #{} does not match (got {}; expected {}; {} bits)", new Object[] { Integer.valueOf(k), Integer.valueOf(value), Integer.valueOf(values[k]), Integer.valueOf(bits[k]) });
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 179 */     Random r = new Random();
/* 180 */     LOGGER.info("Generating 5000 random bits for String test");
/* 181 */     StringBuffer sb = new StringBuffer(5000); int m;
/* 182 */     for (m = 0; m < 5000; m++) {
/* 183 */       sb.append(r.nextInt(2));
/*     */     }
/* 185 */     out = new BitWriter();
/* 186 */     LOGGER.info("Writing values to byte array");
/* 187 */     out.write(sb.toString());
/* 188 */     LOGGER.info("Reading values from byte array");
/* 189 */     bb = new BitBuffer(out.toByteArray());
/* 190 */     for (m = 0; m < 5000; m++) {
/* 191 */       int value = bb.getBits(1);
/* 192 */       int expected = (sb.charAt(m) == '1') ? 1 : 0;
/* 193 */       if (value != expected)
/* 194 */         LOGGER.info("Bit #{} does not match (got {}; expected {}.", new Object[] { Integer.valueOf(m), Integer.valueOf(value), Integer.valueOf(expected) }); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/codec/BitWriter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */