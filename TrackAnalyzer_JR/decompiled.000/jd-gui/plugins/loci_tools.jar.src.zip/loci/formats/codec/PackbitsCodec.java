/*     */ package loci.formats.codec;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import loci.common.RandomAccessInputStream;
/*     */ import loci.formats.FormatException;
/*     */ import loci.formats.UnsupportedCompressionException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PackbitsCodec
/*     */   extends BaseCodec
/*     */ {
/*     */   public byte[] compress(byte[] data, CodecOptions options) throws FormatException {
/*  64 */     throw new UnsupportedCompressionException("Packbits Compression not currently supported");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] decompress(RandomAccessInputStream in, CodecOptions options) throws FormatException, IOException {
/*  77 */     if (options == null) options = CodecOptions.getDefaultOptions(); 
/*  78 */     if (in == null)
/*  79 */       throw new IllegalArgumentException("No data to decompress."); 
/*  80 */     long fp = in.getFilePointer();
/*     */     
/*  82 */     ByteArrayOutputStream output = new ByteArrayOutputStream(1024);
/*  83 */     int nread = 0;
/*  84 */     BufferedInputStream s = new BufferedInputStream((InputStream)in, 262144);
/*  85 */     while (output.size() < options.maxBytes) {
/*  86 */       byte n = (byte)(s.read() & 0xFF);
/*  87 */       nread++;
/*  88 */       if (n >= 0) {
/*  89 */         byte[] b = new byte[n + 1];
/*  90 */         s.read(b);
/*  91 */         nread += n + 1;
/*  92 */         output.write(b);
/*  93 */         b = null; continue;
/*     */       } 
/*  95 */       if (n != Byte.MIN_VALUE) {
/*  96 */         int len = -n + 1;
/*  97 */         byte inp = (byte)(s.read() & 0xFF);
/*  98 */         nread++;
/*  99 */         for (int i = 0; i < len; ) { output.write(inp); i++; }
/*     */       
/*     */       } 
/* 102 */     }  if (fp + nread < in.length()) in.seek(fp + nread); 
/* 103 */     return output.toByteArray();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/codec/PackbitsCodec.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */