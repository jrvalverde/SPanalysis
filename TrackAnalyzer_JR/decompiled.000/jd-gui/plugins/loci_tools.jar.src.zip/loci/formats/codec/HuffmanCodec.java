/*     */ package loci.formats.codec;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.HashMap;
/*     */ import loci.common.RandomAccessInputStream;
/*     */ import loci.formats.FormatException;
/*     */ import loci.formats.UnsupportedCompressionException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HuffmanCodec
/*     */   extends BaseCodec
/*     */ {
/*     */   private static final int LEAVES_OFFSET = 16;
/*     */   private int leafCounter;
/*  65 */   private HashMap<short[], Decoder> cachedDecoders = (HashMap)new HashMap<short, Decoder>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] compress(byte[] data, CodecOptions options) throws FormatException {
/*  74 */     throw new UnsupportedCompressionException("Huffman encoding not currently supported");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] decompress(RandomAccessInputStream in, CodecOptions options) throws FormatException, IOException {
/*  90 */     if (in == null)
/*  91 */       throw new IllegalArgumentException("No data to decompress."); 
/*  92 */     if (options == null || !(options instanceof HuffmanCodecOptions)) {
/*  93 */       throw new FormatException("Options must be an instance of loci.formats.codec.HuffmanCodecOptions.");
/*     */     }
/*     */ 
/*     */     
/*  97 */     HuffmanCodecOptions huffman = (HuffmanCodecOptions)options;
/*  98 */     byte[] pix = new byte[huffman.maxBytes];
/*  99 */     in.read(pix);
/*     */     
/* 101 */     BitBuffer bb = new BitBuffer(pix);
/*     */     
/* 103 */     int nSamples = huffman.maxBytes * 8 / huffman.bitsPerSample;
/* 104 */     int bytesPerSample = huffman.bitsPerSample / 8;
/* 105 */     if (huffman.bitsPerSample % 8 != 0) bytesPerSample++;
/*     */     
/* 107 */     BitWriter out = new BitWriter();
/*     */     
/* 109 */     for (int i = 0; i < nSamples; i++) {
/* 110 */       int sample = getSample(bb, options);
/* 111 */       out.write(sample, bytesPerSample * 8);
/*     */     } 
/*     */     
/* 114 */     return out.toByteArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSample(BitBuffer bb, CodecOptions options) throws FormatException {
/* 122 */     if (bb == null) {
/* 123 */       throw new IllegalArgumentException("No data to handle.");
/*     */     }
/* 125 */     if (options == null || !(options instanceof HuffmanCodecOptions)) {
/* 126 */       throw new FormatException("Options must be an instance of loci.formats.codec.HuffmanCodecOptions.");
/*     */     }
/*     */ 
/*     */     
/* 130 */     HuffmanCodecOptions huffman = (HuffmanCodecOptions)options;
/* 131 */     Decoder decoder = this.cachedDecoders.get(huffman.table);
/* 132 */     if (decoder == null) {
/* 133 */       decoder = new Decoder(huffman.table);
/* 134 */       this.cachedDecoders.put(huffman.table, decoder);
/*     */     } 
/*     */     
/* 137 */     int bitCount = decoder.decode(bb);
/* 138 */     if (bitCount == 16) {
/* 139 */       return 32768;
/*     */     }
/* 141 */     if (bitCount < 0) bitCount = 0; 
/* 142 */     int v = bb.getBits(bitCount) & (int)Math.pow(2.0D, bitCount) - 1;
/* 143 */     if ((v & 1 << bitCount - 1) == 0) {
/* 144 */       v -= (1 << bitCount) - 1;
/*     */     }
/*     */     
/* 147 */     return v;
/*     */   }
/*     */ 
/*     */   
/*     */   class Decoder
/*     */   {
/* 153 */     public Decoder[] branch = new Decoder[2];
/* 154 */     private int leafValue = -1;
/*     */     
/*     */     public Decoder() {}
/*     */     
/*     */     public Decoder(short[] source) {
/* 159 */       HuffmanCodec.this.leafCounter = 0;
/* 160 */       createDecoder(this, source, 0, 0);
/*     */     }
/*     */     
/*     */     private Decoder createDecoder(short[] source, int start, int level) {
/* 164 */       Decoder dest = new Decoder();
/* 165 */       createDecoder(dest, source, start, level);
/* 166 */       return dest;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private void createDecoder(Decoder dest, short[] source, int start, int level) {
/* 172 */       int next = 0;
/* 173 */       int i = 0;
/* 174 */       while (i <= HuffmanCodec.this.leafCounter && next < 16) {
/* 175 */         i += source[start + next++] & 0xFF;
/*     */       }
/*     */       
/* 178 */       if (level < next && next < 16) {
/* 179 */         dest.branch[0] = createDecoder(source, start, level + 1);
/* 180 */         dest.branch[1] = createDecoder(source, start, level + 1);
/*     */       } else {
/*     */         
/* 183 */         i = start + 16 + HuffmanCodec.this.leafCounter++;
/* 184 */         if (i < source.length) {
/* 185 */           dest.leafValue = source[i] & 0xFF;
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*     */     public int decode(BitBuffer bb) {
/* 191 */       Decoder d = this;
/* 192 */       while (d.branch[0] != null) {
/* 193 */         int v = bb.getBits(1);
/* 194 */         if (v < 0)
/* 195 */           break;  d = d.branch[v];
/*     */       } 
/* 197 */       return d.leafValue;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/codec/HuffmanCodec.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */