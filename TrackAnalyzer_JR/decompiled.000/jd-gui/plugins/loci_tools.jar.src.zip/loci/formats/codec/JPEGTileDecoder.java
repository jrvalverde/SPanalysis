/*     */ package loci.formats.codec;
/*     */ 
/*     */ import java.awt.Image;
/*     */ import java.awt.Toolkit;
/*     */ import java.awt.image.ColorModel;
/*     */ import java.awt.image.ImageConsumer;
/*     */ import java.awt.image.ImageProducer;
/*     */ import java.io.IOException;
/*     */ import java.util.Hashtable;
/*     */ import loci.common.RandomAccessInputStream;
/*     */ import loci.common.Region;
/*     */ import loci.formats.FormatException;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JPEGTileDecoder
/*     */ {
/*  66 */   protected static final Logger LOGGER = LoggerFactory.getLogger(JPEGTileDecoder.class);
/*     */ 
/*     */   
/*     */   private TileConsumer consumer;
/*     */ 
/*     */   
/*     */   private TileCache tiles;
/*     */   
/*     */   private RandomAccessInputStream in;
/*     */ 
/*     */   
/*     */   public void initialize(String id, int imageWidth) {
/*     */     try {
/*  79 */       initialize(new RandomAccessInputStream(id), imageWidth);
/*     */     }
/*  81 */     catch (IOException e) {
/*  82 */       LOGGER.debug("", e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void initialize(RandomAccessInputStream in, int imageWidth) {
/*  87 */     initialize(in, 0, 0, imageWidth);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void initialize(RandomAccessInputStream in, int y, int h, int imageWidth) {
/*  93 */     this.in = in;
/*  94 */     this.tiles = new TileCache(y, h);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 100 */       long fp = in.getFilePointer();
/* 101 */       boolean littleEndian = in.isLittleEndian();
/* 102 */       in.order(false);
/*     */       
/* 104 */       while (in.getFilePointer() < in.length() - 1L) {
/* 105 */         int code = in.readShort() & 0xFFFF;
/* 106 */         int length = in.readShort() & 0xFFFF;
/* 107 */         long pointer = in.getFilePointer();
/* 108 */         if (length > 65280 || code < 65280) {
/* 109 */           in.seek(pointer - 3L);
/*     */           continue;
/*     */         } 
/* 112 */         if (code == 65472) {
/* 113 */           in.skipBytes(1);
/* 114 */           int height = in.readShort() & 0xFFFF;
/* 115 */           int width = in.readShort() & 0xFFFF;
/* 116 */           if (height == 0 || width == 0) {
/* 117 */             throw new RuntimeException("Width or height > 65500 is not supported.");
/*     */           }
/*     */           
/*     */           break;
/*     */         } 
/* 122 */         if (pointer + length - 2L < in.length()) {
/* 123 */           in.seek(pointer + length - 2L);
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 130 */       in.seek(fp);
/* 131 */       in.order(littleEndian);
/*     */     }
/* 133 */     catch (IOException e) {}
/*     */     
/*     */     try {
/* 136 */       Toolkit toolkit = Toolkit.getDefaultToolkit();
/* 137 */       byte[] data = new byte[this.in.available()];
/* 138 */       this.in.readFully(data);
/* 139 */       Image image = toolkit.createImage(data);
/* 140 */       ImageProducer producer = image.getSource();
/*     */       
/* 142 */       this.consumer = new TileConsumer(producer, y, h);
/* 143 */       producer.startProduction(this.consumer);
/* 144 */       while (producer.isConsumer(this.consumer));
/*     */     }
/* 146 */     catch (IOException e) {}
/*     */   }
/*     */   
/*     */   public byte[] getScanline(int y) {
/*     */     try {
/* 151 */       return this.tiles.get(0, y, this.consumer.getWidth(), 1);
/*     */     }
/* 153 */     catch (FormatException e) {
/* 154 */       LOGGER.debug("", (Throwable)e);
/*     */     }
/* 156 */     catch (IOException e) {
/* 157 */       LOGGER.debug("", e);
/*     */     } 
/* 159 */     return null;
/*     */   }
/*     */   
/*     */   public int getWidth() {
/* 163 */     return this.consumer.getWidth();
/*     */   }
/*     */   
/*     */   public int getHeight() {
/* 167 */     return this.consumer.getHeight();
/*     */   }
/*     */   
/*     */   public void close() {
/*     */     try {
/* 172 */       if (this.in != null) {
/* 173 */         this.in.close();
/*     */       }
/*     */     }
/* 176 */     catch (IOException e) {
/* 177 */       LOGGER.debug("", e);
/*     */     } 
/* 179 */     this.tiles = null;
/* 180 */     this.consumer = null;
/*     */   }
/*     */ 
/*     */   
/*     */   class TileConsumer
/*     */     implements ImageConsumer
/*     */   {
/*     */     private int width;
/* 188 */     private int yy = 0; private int height; private ImageProducer producer; private int hh = 0;
/*     */     
/*     */     public TileConsumer(ImageProducer producer) {
/* 191 */       this.producer = producer;
/*     */     }
/*     */     
/*     */     public TileConsumer(ImageProducer producer, int y, int h) {
/* 195 */       this(producer);
/* 196 */       this.yy = y;
/* 197 */       this.hh = h;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int getWidth() {
/* 203 */       return this.width;
/*     */     }
/*     */     
/*     */     public int getHeight() {
/* 207 */       return this.height;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void imageComplete(int status) {
/* 213 */       this.producer.removeConsumer(this);
/*     */     }
/*     */     
/*     */     public void setDimensions(int width, int height) {
/* 217 */       this.width = width;
/* 218 */       this.height = height;
/* 219 */       if (this.hh <= 0) this.hh = height;
/*     */     
/*     */     }
/*     */ 
/*     */     
/*     */     public void setPixels(int x, int y, int w, int h, ColorModel model, byte[] pixels, int off, int scanSize) {
/* 225 */       JPEGTileDecoder.LOGGER.debug("Storing row {} of {} ({}%)", new Object[] { Integer.valueOf(y), Integer.valueOf(this.height), Double.valueOf(y / this.height * 100.0D) });
/*     */       
/* 227 */       if (y >= this.yy + this.hh) {
/* 228 */         imageComplete(0);
/*     */         return;
/*     */       } 
/* 231 */       if (y < this.yy)
/*     */         return;  try {
/* 233 */         JPEGTileDecoder.this.tiles.add(pixels, x, y, w, h);
/*     */       }
/* 235 */       catch (FormatException e) {
/* 236 */         JPEGTileDecoder.LOGGER.debug("", (Throwable)e);
/*     */       }
/* 238 */       catch (IOException e) {
/* 239 */         JPEGTileDecoder.LOGGER.debug("", e);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void setPixels(int x, int y, int w, int h, ColorModel model, int[] pixels, int off, int scanSize) {
/* 246 */       JPEGTileDecoder.LOGGER.debug("Storing row {} of {} ({}%)", new Object[] { Integer.valueOf(y), Integer.valueOf(this.yy + this.hh), Double.valueOf(y / (this.yy + this.hh) * 100.0D) });
/*     */       
/* 248 */       if (y >= this.yy + this.hh) {
/* 249 */         imageComplete(0);
/*     */         return;
/*     */       } 
/* 252 */       if (y < this.yy)
/*     */         return;  try {
/* 254 */         JPEGTileDecoder.this.tiles.add(pixels, x, y, w, h);
/*     */       }
/* 256 */       catch (FormatException e) {
/* 257 */         JPEGTileDecoder.LOGGER.debug("", (Throwable)e);
/*     */       }
/* 259 */       catch (IOException e) {
/* 260 */         JPEGTileDecoder.LOGGER.debug("", e);
/*     */       } 
/*     */     }
/*     */     
/*     */     public void setProperties(Hashtable props) {}
/*     */     
/*     */     public void setColorModel(ColorModel model) {}
/*     */     
/*     */     public void setHints(int hintFlags) {} }
/*     */   
/*     */   class TileCache {
/*     */     private static final int ROW_COUNT = 128;
/* 272 */     private Hashtable<Region, byte[]> compressedTiles = (Hashtable)new Hashtable<Region, byte>();
/*     */     
/* 274 */     private JPEGCodec codec = new JPEGCodec();
/* 275 */     private CodecOptions options = new CodecOptions();
/*     */     
/* 277 */     private ByteVector toCompress = new ByteVector();
/* 278 */     private int row = 0;
/*     */     
/* 280 */     private Region lastRegion = null;
/* 281 */     private byte[] lastTile = null;
/*     */     
/* 283 */     private int yy = 0; private int hh = 0;
/*     */     
/*     */     public TileCache(int yy, int hh) {
/* 286 */       this.options.interleaved = true;
/* 287 */       this.options.littleEndian = false;
/* 288 */       this.yy = yy;
/* 289 */       this.hh = hh;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void add(byte[] pixels, int x, int y, int w, int h) throws FormatException, IOException {
/* 295 */       this.toCompress.add(pixels);
/* 296 */       this.row++;
/*     */       
/* 298 */       if (y % 128 == 127 || y == JPEGTileDecoder.this.getHeight() - 1 || y == this.yy + this.hh - 1) {
/*     */ 
/*     */         
/* 301 */         Region r = new Region(x, y - this.row + 1, w, this.row);
/* 302 */         this.options.width = w;
/* 303 */         this.options.height = this.row;
/* 304 */         this.options.channels = 1;
/* 305 */         this.options.bitsPerSample = 8;
/* 306 */         this.options.signed = false;
/*     */         
/* 308 */         byte[] compressed = this.codec.compress(this.toCompress.toByteArray(), this.options);
/* 309 */         this.compressedTiles.put(r, compressed);
/* 310 */         this.toCompress.clear();
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void add(int[] pixels, int x, int y, int w, int h) throws FormatException, IOException {
/* 317 */       byte[] buf = new byte[pixels.length * 3];
/* 318 */       for (int i = 0; i < pixels.length; i++) {
/* 319 */         buf[i * 3] = (byte)((pixels[i] & 0xFF0000) >> 16);
/* 320 */         buf[i * 3 + 1] = (byte)((pixels[i] & 0xFF00) >> 8);
/* 321 */         buf[i * 3 + 2] = (byte)(pixels[i] & 0xFF);
/*     */       } 
/*     */       
/* 324 */       this.toCompress.add(buf);
/* 325 */       this.row++;
/*     */       
/* 327 */       if (y % 128 == 127 || y == JPEGTileDecoder.this.getHeight() - 1 || y == this.yy + this.hh - 1) {
/*     */ 
/*     */         
/* 330 */         Region r = new Region(x, y - this.row + 1, w, this.row);
/* 331 */         this.options.width = w;
/* 332 */         this.options.height = this.row;
/* 333 */         this.options.channels = 3;
/* 334 */         this.options.bitsPerSample = 8;
/* 335 */         this.options.signed = false;
/*     */         
/* 337 */         byte[] compressed = this.codec.compress(this.toCompress.toByteArray(), this.options);
/* 338 */         this.compressedTiles.put(r, compressed);
/* 339 */         this.toCompress.clear();
/* 340 */         this.row = 0;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public byte[] get(int x, int y, int w, int h) throws FormatException, IOException {
/* 347 */       Region[] keys = (Region[])this.compressedTiles.keySet().toArray((Object[])new Region[0]);
/* 348 */       Region r = new Region(x, y, w, h);
/* 349 */       for (Region key : keys) {
/* 350 */         if (key.intersects(r)) {
/* 351 */           r = key;
/*     */         }
/*     */       } 
/* 354 */       if (!r.equals(this.lastRegion)) {
/* 355 */         this.lastRegion = r;
/* 356 */         byte[] compressed = null;
/* 357 */         compressed = this.compressedTiles.get(r);
/* 358 */         if (compressed == null) return null; 
/* 359 */         this.lastTile = this.codec.decompress(compressed, this.options);
/*     */       } 
/*     */       
/* 362 */       int pixel = this.options.channels * this.options.bitsPerSample / 8;
/* 363 */       byte[] buf = new byte[w * h * pixel];
/*     */       
/* 365 */       for (int i = 0; i < h; i++) {
/* 366 */         System.arraycopy(this.lastTile, r.width * pixel * (i + y - r.y) + x - r.x, buf, i * w * pixel, pixel * w);
/*     */       }
/*     */ 
/*     */       
/* 370 */       return buf;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/codec/JPEGTileDecoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */