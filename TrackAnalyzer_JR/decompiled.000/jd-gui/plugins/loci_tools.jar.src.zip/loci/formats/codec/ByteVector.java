/*     */ package loci.formats.codec;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ByteVector
/*     */ {
/*     */   private byte[] data;
/*     */   private int size;
/*     */   
/*     */   public ByteVector() {
/*  52 */     this.data = new byte[10];
/*  53 */     this.size = 0;
/*     */   }
/*     */   
/*     */   public ByteVector(int initialSize) {
/*  57 */     this.data = new byte[initialSize];
/*  58 */     this.size = 0;
/*     */   }
/*     */   
/*     */   public ByteVector(byte[] byteBuffer) {
/*  62 */     this.data = byteBuffer;
/*  63 */     this.size = 0;
/*     */   }
/*     */   
/*     */   public void add(byte x) {
/*  67 */     for (; this.size >= this.data.length; doubleCapacity());
/*  68 */     this.data[this.size++] = x;
/*     */   }
/*     */   
/*     */   public int size() {
/*  72 */     return this.size;
/*     */   }
/*     */   
/*     */   public byte get(int index) {
/*  76 */     return this.data[index];
/*     */   }
/*     */   public void add(byte[] array) {
/*  79 */     add(array, 0, array.length);
/*     */   }
/*     */   public void add(byte[] array, int off, int len) {
/*  82 */     for (; this.data.length < this.size + len; doubleCapacity());
/*  83 */     if (len == 1) { this.data[this.size] = array[off]; }
/*  84 */     else if (len < 35)
/*     */     
/*  86 */     { for (int i = 0; i < len; ) { this.data[this.size + i] = array[off + i]; i++; }
/*     */        }
/*  88 */     else { System.arraycopy(array, off, this.data, this.size, len); }
/*  89 */      this.size += len;
/*     */   }
/*     */   
/*     */   void doubleCapacity() {
/*  93 */     byte[] tmp = new byte[this.data.length * 2 + 1];
/*  94 */     System.arraycopy(this.data, 0, tmp, 0, this.data.length);
/*  95 */     this.data = tmp;
/*     */   }
/*     */   
/*     */   public void clear() {
/*  99 */     this.size = 0;
/*     */   }
/*     */   
/*     */   public byte[] toByteArray() {
/* 103 */     byte[] bytes = new byte[this.size];
/* 104 */     System.arraycopy(this.data, 0, bytes, 0, this.size);
/* 105 */     return bytes;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/codec/ByteVector.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */