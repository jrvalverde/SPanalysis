/*     */ package loci.formats.codec;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JPEG2000CodecOptions
/*     */   extends CodecOptions
/*     */ {
/*     */   public int[] codeBlockSize;
/*     */   public Integer numDecompositionLevels;
/*     */   public Integer resolution;
/*     */   
/*     */   public JPEG2000CodecOptions() {}
/*     */   
/*     */   public JPEG2000CodecOptions(CodecOptions options) {
/*  88 */     super(options);
/*  89 */     if (options instanceof JPEG2000CodecOptions) {
/*  90 */       JPEG2000CodecOptions j2kOptions = (JPEG2000CodecOptions)options;
/*  91 */       if (j2kOptions.codeBlockSize != null) {
/*  92 */         this.codeBlockSize = j2kOptions.codeBlockSize;
/*     */       }
/*  94 */       this.numDecompositionLevels = j2kOptions.numDecompositionLevels;
/*  95 */       this.resolution = j2kOptions.resolution;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JPEG2000CodecOptions getDefaultOptions() {
/* 103 */     CodecOptions options = CodecOptions.getDefaultOptions();
/* 104 */     return getDefaultOptions(options);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JPEG2000CodecOptions getDefaultOptions(CodecOptions options) {
/* 112 */     JPEG2000CodecOptions j2kOptions = new JPEG2000CodecOptions(options);
/*     */     
/* 114 */     j2kOptions.quality = j2kOptions.lossless ? Double.MAX_VALUE : 10.0D;
/* 115 */     j2kOptions.codeBlockSize = new int[] { 64, 64 };
/*     */     
/* 117 */     return j2kOptions;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/codec/JPEG2000CodecOptions.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */