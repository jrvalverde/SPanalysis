/*     */ package loci.formats.codec;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Random;
/*     */ import loci.common.RandomAccessInputStream;
/*     */ import loci.formats.FormatException;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BaseCodec
/*     */   implements Codec
/*     */ {
/*  66 */   protected static final Logger LOGGER = LoggerFactory.getLogger(BaseCodec.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void test() throws FormatException {
/*  81 */     byte[] testdata = new byte[50000];
/*  82 */     Random r = new Random();
/*  83 */     LOGGER.info("Testing {}", getClass().getName());
/*  84 */     LOGGER.info("Generating random data");
/*  85 */     r.nextBytes(testdata);
/*  86 */     LOGGER.info("Compressing data");
/*  87 */     byte[] compressed = compress(testdata, null);
/*  88 */     LOGGER.info("Compressed size: {}", Integer.valueOf(compressed.length));
/*  89 */     LOGGER.info("Decompressing data");
/*  90 */     byte[] decompressed = decompress(compressed);
/*  91 */     LOGGER.info("Comparing data...");
/*  92 */     if (testdata.length != decompressed.length) {
/*  93 */       LOGGER.info("Test data differs in length from uncompressed data");
/*  94 */       LOGGER.info("Exiting...");
/*  95 */       System.exit(-1);
/*     */     } else {
/*     */       
/*  98 */       boolean bool = true;
/*  99 */       for (int k = 0; k < testdata.length; k++) {
/* 100 */         if (testdata[k] != decompressed[k]) {
/* 101 */           LOGGER.info("Test data and uncompressed data differ at byte {}", Integer.valueOf(k));
/* 102 */           bool = false;
/*     */         } 
/*     */       } 
/* 105 */       if (!bool) {
/* 106 */         LOGGER.info("Comparison failed. Exiting...");
/* 107 */         System.exit(-1);
/*     */       } 
/*     */     } 
/* 110 */     LOGGER.info("Success.");
/* 111 */     LOGGER.info("Generating 2D byte array test");
/* 112 */     byte[][] twoDtest = new byte[100][500];
/* 113 */     for (int i = 0; i < 100; i++) {
/* 114 */       System.arraycopy(testdata, 500 * i, twoDtest[i], 0, 500);
/*     */     }
/* 116 */     byte[] twoDcompressed = compress(twoDtest, null);
/* 117 */     LOGGER.info("Comparing compressed data...");
/* 118 */     if (twoDcompressed.length != compressed.length) {
/* 119 */       LOGGER.info("1D and 2D compressed data not same length");
/* 120 */       LOGGER.info("Exiting...");
/* 121 */       System.exit(-1);
/*     */     } 
/* 123 */     boolean equalsFlag = true;
/* 124 */     for (int j = 0; j < twoDcompressed.length; j++) {
/* 125 */       if (twoDcompressed[j] != compressed[j]) {
/* 126 */         LOGGER.info("1D data and 2D compressed data differs at byte {}", Integer.valueOf(j));
/* 127 */         equalsFlag = false;
/*     */       } 
/* 129 */       if (!equalsFlag) {
/* 130 */         LOGGER.info("Comparison failed. Exiting...");
/* 131 */         System.exit(-1);
/*     */       } 
/*     */     } 
/* 134 */     LOGGER.info("Success.");
/* 135 */     LOGGER.info("Test complete.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] compress(byte[][] data, CodecOptions options) throws FormatException {
/* 154 */     int len = 0;
/* 155 */     for (int i = 0; i < data.length; i++) {
/* 156 */       len += (data[i]).length;
/*     */     }
/* 158 */     byte[] toCompress = new byte[len];
/* 159 */     int curPos = 0;
/* 160 */     for (int j = 0; j < data.length; j++) {
/* 161 */       System.arraycopy(data[j], 0, toCompress, curPos, (data[j]).length);
/* 162 */       curPos += (data[j]).length;
/*     */     } 
/* 164 */     return compress(toCompress, options);
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] decompress(byte[] data) throws FormatException {
/* 169 */     return decompress(data, (CodecOptions)null);
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] decompress(byte[][] data) throws FormatException {
/* 174 */     return decompress(data, (CodecOptions)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] decompress(byte[] data, CodecOptions options) throws FormatException {
/*     */     try {
/* 182 */       RandomAccessInputStream r = new RandomAccessInputStream(data);
/* 183 */       byte[] t = decompress(r, options);
/* 184 */       r.close();
/* 185 */       return t;
/*     */     }
/* 187 */     catch (IOException e) {
/* 188 */       throw new FormatException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract byte[] decompress(RandomAccessInputStream paramRandomAccessInputStream, CodecOptions paramCodecOptions) throws FormatException, IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] decompress(byte[][] data, CodecOptions options) throws FormatException {
/* 209 */     if (data == null)
/* 210 */       throw new IllegalArgumentException("No data to decompress."); 
/* 211 */     int len = 0;
/* 212 */     for (int i = 0; i < data.length; i++) {
/* 213 */       len += (data[i]).length;
/*     */     }
/* 215 */     byte[] toDecompress = new byte[len];
/* 216 */     int curPos = 0;
/* 217 */     for (int j = 0; j < data.length; j++) {
/* 218 */       System.arraycopy(data[j], 0, toDecompress, curPos, (data[j]).length);
/* 219 */       curPos += (data[j]).length;
/*     */     } 
/* 221 */     return decompress(toDecompress, options);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/codec/BaseCodec.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */