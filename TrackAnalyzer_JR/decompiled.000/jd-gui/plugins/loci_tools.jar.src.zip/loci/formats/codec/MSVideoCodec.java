/*     */ package loci.formats.codec;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import loci.common.RandomAccessInputStream;
/*     */ import loci.formats.FormatException;
/*     */ import loci.formats.UnsupportedCompressionException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MSVideoCodec
/*     */   extends BaseCodec
/*     */ {
/*     */   public byte[] compress(byte[] data, CodecOptions options) throws FormatException {
/*  61 */     throw new UnsupportedCompressionException("MS Video 1 compression not supported.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] decompress(RandomAccessInputStream in, CodecOptions options) throws FormatException, IOException {
/*  77 */     if (in == null)
/*  78 */       throw new IllegalArgumentException("No data to decompress."); 
/*  79 */     if (options == null) options = CodecOptions.getDefaultOptions();
/*     */     
/*  81 */     in.order(true);
/*     */     
/*  83 */     int row = 0;
/*  84 */     int column = 0;
/*     */     
/*  86 */     int plane = options.width * options.height;
/*     */     
/*  88 */     byte[] bytes = new byte[plane];
/*  89 */     short[] shorts = new short[plane];
/*     */ 
/*     */     
/*  92 */     while (in.getFilePointer() < in.length() && row < options.width && column < options.height) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  97 */       short a = (short)(in.read() & 0xFF);
/*  98 */       short s1 = (short)(in.read() & 0xFF);
/*  99 */       if (a == 0 && s1 == 0 && in.getFilePointer() >= in.length())
/* 100 */         break;  if (s1 >= 132 && s1 < 136) {
/*     */ 
/*     */         
/* 103 */         int skip = (s1 - 132) * 256 + a;
/* 104 */         for (int j = 0; j < skip; j++) {
/* 105 */           if (options.previousImage != null) {
/* 106 */             for (int k = 0; k < 4; k++) {
/* 107 */               for (int x = 0; x < 4 && 
/* 108 */                 row + x < options.width && 
/* 109 */                 column + k < options.height; x++) {
/* 110 */                 int ndx = options.width * (column + k) + row + x;
/* 111 */                 int oldNdx = options.width * (options.height - 1 - k - column) + row + x;
/*     */                 
/* 113 */                 if (options.bitsPerSample == 8) {
/* 114 */                   bytes[ndx] = options.previousImage[oldNdx];
/*     */                 } else {
/*     */                   
/* 117 */                   byte red = options.previousImage[oldNdx];
/* 118 */                   byte green = options.previousImage[oldNdx + plane];
/* 119 */                   byte blue = options.previousImage[oldNdx + 2 * plane];
/* 120 */                   shorts[ndx] = (short)((blue & 0x1F) << 10 | (green & 0x1F) << 5 | red & 0x1F);
/*     */                 } 
/*     */               } 
/*     */             } 
/*     */           }
/*     */ 
/*     */           
/* 127 */           row += 4;
/* 128 */           if (row >= options.width) {
/* 129 */             row = 0;
/* 130 */             column += 4;
/*     */           } 
/*     */         }  continue;
/*     */       } 
/* 134 */       if (s1 >= 0 && s1 < 128) {
/* 135 */         if (options.bitsPerSample == 8) {
/* 136 */           byte colorA = in.readByte();
/* 137 */           byte colorB = in.readByte();
/*     */           
/* 139 */           for (int j = 0; j < 4; j++) {
/* 140 */             for (int x = 3; x >= 0; x--) {
/* 141 */               int ndx = options.width * (column + 3 - j) + row + x;
/* 142 */               short flag = (j < 2) ? s1 : a;
/* 143 */               int shift = 4 - 4 * j % 2 + x;
/* 144 */               int cmp = 1 << shift;
/* 145 */               if ((flag & cmp) == cmp) { bytes[ndx] = colorA; }
/* 146 */               else { bytes[ndx] = colorB; }
/*     */             
/*     */             } 
/*     */           } 
/*     */         } else {
/* 151 */           short check1 = in.readShort();
/* 152 */           short check2 = in.readShort();
/*     */           
/* 154 */           if ((check1 & 0x8000) == 32768) {
/*     */             
/* 156 */             short q1a = check1;
/* 157 */             short q1b = check2;
/* 158 */             short q2a = in.readShort();
/* 159 */             short q2b = in.readShort();
/* 160 */             short q3a = in.readShort();
/* 161 */             short q3b = in.readShort();
/* 162 */             short q4a = in.readShort();
/* 163 */             short q4b = in.readShort();
/*     */             
/* 165 */             for (int j = 0; j < 4; j++) {
/* 166 */               for (int x = 3; x >= 0; x--) {
/* 167 */                 int ndx = options.width * (column + 3 - j) + row + x;
/*     */                 
/* 169 */                 short colorA = (x < 2) ? ((j < 2) ? q3a : q1a) : ((j < 2) ? q4a : q2a);
/*     */                 
/* 171 */                 short colorB = (x < 2) ? ((j < 2) ? q3b : q1b) : ((j < 2) ? q4b : q2b);
/*     */ 
/*     */                 
/* 174 */                 short flag = (j < 2) ? s1 : a;
/* 175 */                 int shift = 4 - 4 * j % 2 + x;
/* 176 */                 int cmp = 1 << shift;
/* 177 */                 if (ndx < shorts.length) {
/* 178 */                   if ((flag & cmp) == cmp) { shorts[ndx] = colorA; }
/* 179 */                   else { shorts[ndx] = colorB; }
/*     */ 
/*     */                 
/*     */                 }
/*     */               } 
/*     */             } 
/*     */           } else {
/*     */             
/* 187 */             short colorA = check1;
/* 188 */             short colorB = check2;
/*     */             
/* 190 */             for (int j = 0; j < 4; j++) {
/* 191 */               for (int x = 3; x >= 0; x--) {
/* 192 */                 int ndx = options.width * (column + 3 - j) + row + x;
/* 193 */                 if (ndx >= shorts.length)
/* 194 */                   break;  short flag = (j < 2) ? s1 : a;
/* 195 */                 int shift = 4 - 4 * j % 2 + x;
/* 196 */                 int cmp = 1 << shift;
/* 197 */                 if ((flag & cmp) == cmp) { shorts[ndx] = colorA; }
/* 198 */                 else { shorts[ndx] = colorB; }
/*     */               
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/* 204 */         row += 4;
/* 205 */         if (row >= options.width) {
/* 206 */           row = 0;
/* 207 */           column += 4;
/*     */         }  continue;
/*     */       } 
/* 210 */       if (options.bitsPerSample == 8 && 144 < s1) {
/* 211 */         byte[] colors = new byte[8];
/* 212 */         in.read(colors);
/*     */         
/* 214 */         for (int j = 0; j < 4; j++) {
/* 215 */           for (int x = 3; x >= 0; x--) {
/* 216 */             int ndx = options.width * (column + 3 - j) + row + x;
/* 217 */             byte colorA = (j < 2) ? ((x < 2) ? colors[4] : colors[6]) : ((x < 2) ? colors[0] : colors[2]);
/*     */             
/* 219 */             byte colorB = (j < 2) ? ((x < 2) ? colors[5] : colors[7]) : ((x < 2) ? colors[1] : colors[3]);
/*     */ 
/*     */             
/* 222 */             short flag = (j < 2) ? s1 : a;
/* 223 */             int shift = 4 - 4 * j % 2 + x;
/* 224 */             int cmp = 1 << shift;
/* 225 */             if ((flag & cmp) == cmp) { bytes[ndx] = colorA; }
/* 226 */             else { bytes[ndx] = colorB; }
/*     */           
/*     */           } 
/*     */         } 
/* 230 */         row += 4;
/* 231 */         if (row >= options.width) {
/* 232 */           row = 0;
/* 233 */           column += 4;
/*     */         } 
/*     */         continue;
/*     */       } 
/* 237 */       for (int i = 0; i < 4; i++) {
/* 238 */         for (int x = 0; x < 4; x++) {
/* 239 */           int ndx = options.width * (column + 3 - i) + row + x;
/* 240 */           if (options.bitsPerSample == 8) {
/* 241 */             if (ndx < bytes.length) {
/* 242 */               bytes[ndx] = (byte)(a & 0xFF);
/*     */             
/*     */             }
/*     */           }
/* 246 */           else if (ndx < shorts.length) {
/* 247 */             shorts[ndx] = (short)((s1 << 8 | a) & 0xFFFF);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/* 252 */       row += 4;
/* 253 */       if (row >= options.width) {
/* 254 */         row = 0;
/* 255 */         column += 4;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 260 */     if (options.bitsPerSample == 8) {
/* 261 */       byte[] tmp = bytes;
/* 262 */       bytes = new byte[tmp.length];
/* 263 */       for (int i = 0; i < options.height; i++) {
/* 264 */         System.arraycopy(tmp, i * options.width, bytes, (options.height - i - 1) * options.width, options.width);
/*     */       }
/*     */       
/* 267 */       return bytes;
/*     */     } 
/*     */     
/* 270 */     byte[] b = new byte[plane * 3];
/*     */ 
/*     */     
/* 273 */     for (int y = 0; y < options.height; y++) {
/* 274 */       for (int x = 0; x < options.width; x++) {
/* 275 */         int off = y * options.width + x;
/* 276 */         int dest = (options.height - y - 1) * options.width + x;
/* 277 */         b[dest + 2 * plane] = (byte)((shorts[off] & 0x7C00) >> 10);
/* 278 */         b[dest + plane] = (byte)((shorts[off] & 0x3E0) >> 5);
/* 279 */         b[dest] = (byte)(shorts[off] & 0x1F);
/*     */       } 
/*     */     } 
/*     */     
/* 283 */     return b;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/codec/MSVideoCodec.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */