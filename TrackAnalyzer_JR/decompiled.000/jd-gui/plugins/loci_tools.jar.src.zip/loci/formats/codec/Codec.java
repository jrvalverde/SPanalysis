package loci.formats.codec;

import java.io.IOException;
import loci.common.RandomAccessInputStream;
import loci.formats.FormatException;

public interface Codec {
  byte[] compress(byte[] paramArrayOfbyte, CodecOptions paramCodecOptions) throws FormatException;
  
  byte[] compress(byte[][] paramArrayOfbyte, CodecOptions paramCodecOptions) throws FormatException;
  
  byte[] decompress(byte[] paramArrayOfbyte, CodecOptions paramCodecOptions) throws FormatException;
  
  byte[] decompress(byte[][] paramArrayOfbyte, CodecOptions paramCodecOptions) throws FormatException;
  
  byte[] decompress(byte[] paramArrayOfbyte) throws FormatException;
  
  byte[] decompress(byte[][] paramArrayOfbyte) throws FormatException;
  
  byte[] decompress(RandomAccessInputStream paramRandomAccessInputStream, CodecOptions paramCodecOptions) throws FormatException, IOException;
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/codec/Codec.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */