/*     */ package loci.formats.codec;
/*     */ 
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.util.Arrays;
/*     */ import loci.common.RandomAccessInputStream;
/*     */ import loci.formats.FormatException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LZWCodec
/*     */   extends BaseCodec
/*     */ {
/*     */   private static final int HASH_SIZE = 7349;
/*     */   private static final int HASH_STEP = 257;
/*     */   private static final int CLEAR_CODE = 256;
/*     */   private static final int EOI_CODE = 257;
/*     */   private static final int FIRST_CODE = 258;
/* 104 */   private static final int[] COMPR_MASKS = new int[] { 255, 127, 63, 31, 15, 7, 3, 1 };
/*     */ 
/*     */ 
/*     */   
/* 108 */   private static final int[] DECOMPR_MASKS = new int[] { 0, 1, 3, 7, 15, 31, 63, 127 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] compress(byte[] input, CodecOptions options) throws FormatException {
/* 115 */     if (input == null || input.length == 0) return input;
/*     */ 
/*     */     
/* 118 */     long bufferSize = input.length * 141L / 100L + 3L;
/* 119 */     if (bufferSize > 2147483647L) {
/* 120 */       throw new FormatException("Output buffer is greater than 2 GB");
/*     */     }
/* 122 */     byte[] output = new byte[(int)bufferSize];
/*     */ 
/*     */     
/* 125 */     int outSize = 0;
/*     */     
/* 127 */     output[outSize++] = Byte.MIN_VALUE;
/*     */ 
/*     */     
/* 130 */     int currOutByte = 0;
/*     */     
/* 132 */     int freeBits = 7;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 138 */     int[] htKeys = new int[7349];
/* 139 */     int[] htValues = new int[7349];
/*     */     
/* 141 */     Arrays.fill(htKeys, -1);
/*     */ 
/*     */     
/* 144 */     int nextCode = 258;
/*     */     
/* 146 */     int currCodeLength = 9;
/*     */ 
/*     */ 
/*     */     
/* 150 */     int tiffK = input[0] & 0xFF;
/* 151 */     int tiffOmega = tiffK;
/*     */ 
/*     */     
/* 154 */     for (int currInPos = 1; currInPos < input.length; currInPos++) {
/* 155 */       int i; tiffK = input[currInPos] & 0xFF;
/* 156 */       int hashKey = tiffOmega << 8 | tiffK;
/* 157 */       int hashCode = hashKey % 7349;
/*     */       while (true) {
/* 159 */         if (htKeys[hashCode] == hashKey) {
/*     */           
/* 161 */           tiffOmega = htValues[hashCode];
/*     */           break;
/*     */         } 
/* 164 */         if (htKeys[hashCode] < 0) {
/*     */ 
/*     */           
/* 167 */           htKeys[hashCode] = hashKey;
/* 168 */           htValues[hashCode] = nextCode++;
/*     */           
/* 170 */           int j = currCodeLength - freeBits;
/* 171 */           output[outSize++] = (byte)(currOutByte << freeBits | tiffOmega >> j);
/*     */           
/* 173 */           if (j > 8) {
/* 174 */             output[outSize++] = (byte)(tiffOmega >> j - 8);
/* 175 */             j -= 8;
/*     */           } 
/* 177 */           freeBits = 8 - j;
/* 178 */           currOutByte = tiffOmega & COMPR_MASKS[freeBits];
/*     */           
/* 180 */           tiffOmega = tiffK;
/*     */           
/*     */           break;
/*     */         } 
/*     */         
/* 185 */         hashCode = (hashCode + 257) % 7349;
/*     */       } 
/*     */ 
/*     */       
/* 189 */       switch (nextCode) {
/*     */         case 512:
/* 191 */           currCodeLength = 10;
/*     */           break;
/*     */         case 1024:
/* 194 */           currCodeLength = 11;
/*     */           break;
/*     */         case 2048:
/* 197 */           currCodeLength = 12;
/*     */           break;
/*     */         case 4096:
/* 200 */           i = currCodeLength - freeBits;
/* 201 */           output[outSize++] = (byte)(currOutByte << freeBits | 256 >> i);
/*     */           
/* 203 */           if (i > 8) {
/* 204 */             output[outSize++] = (byte)(256 >> i - 8);
/* 205 */             i -= 8;
/*     */           } 
/* 207 */           freeBits = 8 - i;
/* 208 */           currOutByte = 0x100 & COMPR_MASKS[freeBits];
/* 209 */           Arrays.fill(htKeys, -1);
/* 210 */           nextCode = 258;
/* 211 */           currCodeLength = 9;
/*     */           break;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     } 
/* 219 */     int shift = currCodeLength - freeBits;
/* 220 */     output[outSize++] = (byte)(currOutByte << freeBits | tiffOmega >> shift);
/*     */     
/* 222 */     if (shift > 8) {
/* 223 */       output[outSize++] = (byte)(tiffOmega >> shift - 8);
/* 224 */       shift -= 8;
/*     */     } 
/* 226 */     freeBits = 8 - shift;
/* 227 */     currOutByte = tiffOmega & COMPR_MASKS[freeBits];
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 232 */     switch (nextCode) {
/*     */       case 511:
/* 234 */         currCodeLength = 10;
/*     */         break;
/*     */       case 1023:
/* 237 */         currCodeLength = 11;
/*     */         break;
/*     */       case 2047:
/* 240 */         currCodeLength = 12;
/*     */         break;
/*     */     } 
/*     */ 
/*     */     
/* 245 */     shift = currCodeLength - freeBits;
/* 246 */     output[outSize++] = (byte)(currOutByte << freeBits | 257 >> shift);
/*     */     
/* 248 */     if (shift > 8) {
/* 249 */       output[outSize++] = (byte)(257 >> shift - 8);
/* 250 */       shift -= 8;
/*     */     } 
/* 252 */     freeBits = 8 - shift;
/* 253 */     currOutByte = 0x101 & COMPR_MASKS[freeBits];
/* 254 */     output[outSize++] = (byte)(currOutByte << freeBits);
/*     */ 
/*     */     
/* 257 */     byte[] result = new byte[outSize];
/* 258 */     System.arraycopy(output, 0, result, 0, outSize);
/* 259 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] decompress(RandomAccessInputStream in, CodecOptions options) throws FormatException, IOException {
/* 271 */     if (in == null || in.length() == 0L) return null; 
/* 272 */     if (options == null) options = CodecOptions.getDefaultOptions();
/*     */ 
/*     */     
/* 275 */     byte[] output = new byte[options.maxBytes];
/*     */     
/* 277 */     int currOutPos = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 285 */     int[] anotherCodes = new int[4096];
/* 286 */     byte[] newBytes = new byte[4096];
/* 287 */     int[] lengths = new int[4096];
/*     */     
/* 289 */     for (int i = 0; i < 256; i++) {
/* 290 */       newBytes[i] = (byte)i;
/* 291 */       lengths[i] = 1;
/*     */     } 
/*     */ 
/*     */     
/* 295 */     int currCodeLength = 9;
/*     */     
/* 297 */     int nextCode = 258;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 302 */     int currRead = 0;
/*     */     
/* 304 */     int bitsRead = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 309 */     int oldCode = 0;
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*     */       do {
/* 315 */         int bitsLeft = currCodeLength - bitsRead;
/* 316 */         if (bitsLeft > 8) {
/* 317 */           currRead = currRead << 8 | in.read() & 0xFF;
/* 318 */           bitsLeft -= 8;
/*     */         } 
/* 320 */         bitsRead = 8 - bitsLeft;
/* 321 */         int nextByte = in.read() & 0xFF;
/* 322 */         int currCode = currRead << bitsLeft | nextByte >> bitsRead;
/* 323 */         currRead = nextByte & DECOMPR_MASKS[bitsRead];
/*     */ 
/*     */         
/* 326 */         if (currCode == 257)
/*     */           break; 
/* 328 */         if (currCode == 256) {
/*     */           
/* 330 */           nextCode = 258;
/* 331 */           currCodeLength = 9;
/*     */ 
/*     */           
/* 334 */           bitsLeft = currCodeLength - bitsRead;
/* 335 */           if (bitsLeft > 8) {
/* 336 */             currRead = currRead << 8 | in.read() & 0xFF;
/* 337 */             bitsLeft -= 8;
/*     */           } 
/* 339 */           bitsRead = 8 - bitsLeft;
/*     */           
/* 341 */           nextByte = in.read() & 0xFF;
/* 342 */           currCode = currRead << bitsLeft | nextByte >> bitsRead;
/* 343 */           currRead = nextByte & DECOMPR_MASKS[bitsRead];
/*     */           
/* 345 */           if (currCode == 257) {
/*     */             break;
/*     */           }
/* 348 */           if (currOutPos >= output.length - 1)
/* 349 */             break;  output[currOutPos++] = newBytes[currCode];
/* 350 */           oldCode = currCode;
/*     */         }
/* 352 */         else if (currCode < nextCode) {
/*     */ 
/*     */           
/* 355 */           int outLength = lengths[currCode];
/* 356 */           int j = currOutPos + outLength;
/* 357 */           int tablePos = currCode;
/* 358 */           if (j > output.length)
/* 359 */             break;  while (j > currOutPos) {
/* 360 */             output[--j] = newBytes[tablePos];
/* 361 */             tablePos = anotherCodes[tablePos];
/*     */           } 
/* 363 */           currOutPos += outLength;
/*     */           
/* 365 */           if (nextCode >= anotherCodes.length)
/* 366 */             break;  anotherCodes[nextCode] = oldCode;
/* 367 */           newBytes[nextCode] = output[j];
/* 368 */           lengths[nextCode] = lengths[oldCode] + 1;
/* 369 */           oldCode = currCode;
/* 370 */           nextCode++;
/*     */         
/*     */         }
/*     */         else {
/*     */           
/* 375 */           int outLength = lengths[oldCode];
/* 376 */           int j = currOutPos + outLength;
/* 377 */           int tablePos = oldCode;
/* 378 */           if (j > output.length)
/* 379 */             break;  while (j > currOutPos) {
/* 380 */             output[--j] = newBytes[tablePos];
/* 381 */             tablePos = anotherCodes[tablePos];
/*     */           } 
/* 383 */           currOutPos += outLength;
/*     */           
/* 385 */           if (currOutPos >= output.length - 1)
/* 386 */             break;  output[currOutPos++] = output[j];
/*     */           
/* 388 */           anotherCodes[nextCode] = oldCode;
/* 389 */           newBytes[nextCode] = output[j];
/* 390 */           lengths[nextCode] = outLength + 1;
/* 391 */           oldCode = currCode;
/* 392 */           nextCode++;
/*     */         } 
/*     */         
/* 395 */         switch (nextCode) {
/*     */           case 511:
/* 397 */             currCodeLength = 10;
/*     */             break;
/*     */           case 1023:
/* 400 */             currCodeLength = 11;
/*     */             break;
/*     */           case 2047:
/* 403 */             currCodeLength = 12;
/*     */             break;
/*     */         } 
/* 406 */       } while (currOutPos < output.length && in.getFilePointer() < in.length());
/*     */     }
/* 408 */     catch (ArrayIndexOutOfBoundsException e) {
/* 409 */       throw new FormatException("Invalid LZW data", e);
/*     */     }
/* 411 */     catch (EOFException e) {}
/* 412 */     return output;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/codec/LZWCodec.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */