/*    */ package loci.formats.codec;
/*    */ 
/*    */ import java.io.EOFException;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.util.zip.Deflater;
/*    */ import java.util.zip.InflaterInputStream;
/*    */ import loci.common.RandomAccessInputStream;
/*    */ import loci.formats.FormatException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ZlibCodec
/*    */   extends BaseCodec
/*    */ {
/*    */   public byte[] compress(byte[] data, CodecOptions options) throws FormatException {
/* 62 */     if (data == null || data.length == 0)
/* 63 */       throw new IllegalArgumentException("No data to compress"); 
/* 64 */     Deflater deflater = new Deflater();
/* 65 */     deflater.setInput(data);
/* 66 */     deflater.finish();
/* 67 */     byte[] buf = new byte[8192];
/* 68 */     ByteVector bytes = new ByteVector();
/* 69 */     int r = 0;
/*    */     
/* 71 */     while ((r = deflater.deflate(buf, 0, buf.length)) > 0) {
/* 72 */       bytes.add(buf, 0, r);
/*    */     }
/* 74 */     return bytes.toByteArray();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public byte[] decompress(RandomAccessInputStream in, CodecOptions options) throws FormatException, IOException {
/* 81 */     InflaterInputStream i = new InflaterInputStream((InputStream)in);
/* 82 */     ByteVector bytes = new ByteVector();
/* 83 */     byte[] buf = new byte[8192];
/* 84 */     int r = 0;
/*    */     
/*    */     try {
/* 87 */       for (; (r = i.read(buf, 0, buf.length)) > 0; bytes.add(buf, 0, r));
/*    */     }
/* 89 */     catch (EOFException e) {}
/* 90 */     return bytes.toByteArray();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/codec/ZlibCodec.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */