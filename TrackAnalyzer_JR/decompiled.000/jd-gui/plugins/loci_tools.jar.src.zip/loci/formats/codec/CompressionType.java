/*     */ package loci.formats.codec;
/*     */ 
/*     */ import java.util.EnumSet;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import loci.common.enumeration.CodedEnum;
/*     */ import loci.common.enumeration.EnumException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum CompressionType
/*     */   implements CodedEnum
/*     */ {
/*  55 */   UNCOMPRESSED(1, "Uncompressed"),
/*  56 */   ZLIB(2, "zlib"),
/*  57 */   CINEPAK(3, "Cinepak"),
/*  58 */   ANIMATION(4, "Animation"),
/*  59 */   H_263(5, "H.263"),
/*  60 */   SORENSON(6, "Sorenson"),
/*  61 */   SORENSON_3(7, "Sorenson 3"),
/*  62 */   MPEG_4(8, "MPEG 4"),
/*  63 */   LZW(9, "LZW"),
/*  64 */   J2K(10, "JPEG-2000"),
/*  65 */   J2K_LOSSY(11, "JPEG-2000 Lossy"),
/*  66 */   JPEG(12, "JPEG");
/*     */   
/*     */   private int code;
/*     */   
/*     */   private String compression;
/*     */   
/*     */   private static final Map<Integer, CompressionType> lookup;
/*     */   
/*     */   static {
/*  75 */     lookup = new HashMap<Integer, CompressionType>();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  80 */     for (CompressionType v : EnumSet.<CompressionType>allOf(CompressionType.class)) {
/*  81 */       lookup.put(Integer.valueOf(v.getCode()), v);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CompressionType get(int code) {
/*  92 */     CompressionType toReturn = lookup.get(Integer.valueOf(code));
/*  93 */     if (toReturn == null) {
/*  94 */       throw new EnumException("Unable to find CompressionType with code: " + code);
/*     */     }
/*     */     
/*  97 */     return toReturn;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   CompressionType(int code, String compression) {
/* 106 */     this.code = code;
/* 107 */     this.compression = compression;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getCode() {
/* 115 */     return this.code;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCompression() {
/* 123 */     return this.compression;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/codec/CompressionType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */