/*     */ package loci.formats.codec;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import loci.common.RandomAccessInputStream;
/*     */ import loci.formats.FormatException;
/*     */ import loci.formats.UnsupportedCompressionException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RPZACodec
/*     */   extends BaseCodec
/*     */ {
/*     */   private int totalBlocks;
/*     */   private int pixelPtr;
/*     */   private int rowPtr;
/*     */   private int stride;
/*     */   
/*     */   public byte[] compress(byte[] input, CodecOptions options) throws FormatException {
/*  63 */     throw new UnsupportedCompressionException("RPZA compression not supported.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] decompress(RandomAccessInputStream in, CodecOptions options) throws FormatException, IOException {
/*  76 */     if (in == null)
/*  77 */       throw new IllegalArgumentException("No data to decompress."); 
/*  78 */     if (options == null) options = CodecOptions.getDefaultOptions();
/*     */     
/*  80 */     in.skipBytes(8);
/*     */     
/*  82 */     int plane = options.width * options.height;
/*     */     
/*  84 */     this.stride = options.width;
/*  85 */     int rowInc = this.stride - 4;
/*     */ 
/*     */     
/*  88 */     int colorA = 0;
/*  89 */     int[] color4 = new int[4];
/*     */ 
/*     */     
/*  92 */     int blockPtr = 0;
/*  93 */     this.rowPtr = this.pixelPtr = 0;
/*     */ 
/*     */     
/*  96 */     int[] pixels = new int[plane];
/*  97 */     byte[] rtn = new byte[plane * 3];
/*     */     
/*  99 */     while (in.read() != -31);
/* 100 */     in.skipBytes(3);
/*     */     
/* 102 */     this.totalBlocks = (options.width + 3) / 4 * (options.height + 3) / 4;
/*     */     
/* 104 */     while (in.getFilePointer() + 2L < in.length()) {
/* 105 */       int colorB, ta, tb; byte b; short opcode = (short)in.readByte();
/* 106 */       int nBlocks = (opcode & 0x1F) + 1;
/*     */       
/* 108 */       if ((opcode & 0x80) == 0) {
/* 109 */         if (in.getFilePointer() >= in.length())
/* 110 */           break;  colorA = opcode << 8 | in.read();
/* 111 */         opcode = 0;
/* 112 */         if (in.getFilePointer() >= in.length())
/* 113 */           break;  if ((in.read() & 0x80) != 0) {
/* 114 */           opcode = 32;
/* 115 */           nBlocks = 1;
/*     */         } 
/* 117 */         in.seek(in.getFilePointer() - 1L);
/*     */       } 
/*     */       
/* 120 */       switch (opcode & 0xE0) {
/*     */         case 128:
/* 122 */           while (nBlocks-- > 0) {
/* 123 */             updateBlock(options.width);
/*     */           }
/*     */         
/*     */         case 160:
/* 127 */           if (in.getFilePointer() + 2L >= in.length())
/* 128 */             continue;  colorA = in.readShort();
/* 129 */           while (nBlocks-- > 0) {
/* 130 */             blockPtr = this.rowPtr + this.pixelPtr;
/* 131 */             for (int pixelY = 0; pixelY < 4; pixelY++) {
/* 132 */               for (int pixelX = 0; pixelX < 4 && 
/* 133 */                 blockPtr < pixels.length; pixelX++) {
/* 134 */                 pixels[blockPtr] = colorA;
/*     */                 
/* 136 */                 short s = (short)(pixels[blockPtr] & 0x7FFF);
/* 137 */                 unpack(s, rtn, blockPtr, pixels.length);
/* 138 */                 blockPtr++;
/*     */               } 
/* 140 */               blockPtr += rowInc;
/*     */             } 
/* 142 */             updateBlock(options.width);
/*     */           } 
/*     */         
/*     */         case 32:
/*     */         case 192:
/* 147 */           if (in.getFilePointer() + 2L >= in.length())
/* 148 */             continue;  if ((opcode & 0xE0) == 192) {
/* 149 */             colorA = in.readShort();
/*     */           }
/*     */           
/* 152 */           colorB = in.readShort();
/*     */           
/* 154 */           color4[0] = colorB;
/* 155 */           color4[1] = 0;
/* 156 */           color4[2] = 0;
/* 157 */           color4[3] = colorA;
/*     */           
/* 159 */           ta = colorA >> 10 & 0x1F;
/* 160 */           tb = colorB >> 10 & 0x1F;
/* 161 */           color4[1] = color4[1] | 11 * ta + 21 * tb >> 5 << 10;
/* 162 */           color4[2] = color4[2] | 21 * ta + 11 * tb >> 5 << 10;
/*     */           
/* 164 */           ta = colorA >> 5 & 0x1F;
/* 165 */           tb = colorB >> 5 & 0x1F;
/* 166 */           color4[1] = color4[1] | 11 * ta + 21 * tb >> 5 << 5;
/* 167 */           color4[2] = color4[2] | 21 * ta + 11 * tb >> 5 << 5;
/*     */           
/* 169 */           ta = colorA & 0x1F;
/* 170 */           tb = colorB & 0x1F;
/* 171 */           color4[1] = color4[1] | 11 * ta + 21 * tb >> 5;
/* 172 */           color4[2] = color4[2] | 21 * ta + 11 * tb >> 5;
/*     */           
/* 174 */           while (nBlocks-- > 0) {
/* 175 */             blockPtr = this.rowPtr + this.pixelPtr;
/* 176 */             for (byte b1 = 0; b1 < 4 && 
/* 177 */               in.getFilePointer() < in.length(); b1++) {
/* 178 */               int index = in.read();
/* 179 */               for (int pixelX = 0; pixelX < 4; pixelX++) {
/* 180 */                 int idx = index >> 2 * (3 - pixelX) & 0x3;
/* 181 */                 if (blockPtr >= pixels.length)
/* 182 */                   break;  pixels[blockPtr] = color4[idx];
/*     */                 
/* 184 */                 short s = (short)(pixels[blockPtr] & 0x7FFF);
/* 185 */                 unpack(s, rtn, blockPtr, pixels.length);
/* 186 */                 blockPtr++;
/*     */               } 
/* 188 */               blockPtr += rowInc;
/*     */             } 
/* 190 */             updateBlock(options.width);
/*     */           } 
/*     */         
/*     */         case 0:
/* 194 */           blockPtr = this.rowPtr + this.pixelPtr;
/* 195 */           for (b = 0; b < 4; b++) {
/* 196 */             for (int pixelX = 0; pixelX < 4; pixelX++) {
/* 197 */               if (b != 0 || pixelX != 0) {
/* 198 */                 if (in.getFilePointer() + 2L >= in.length())
/* 199 */                   break;  colorA = in.readShort();
/*     */               } 
/* 201 */               if (blockPtr >= pixels.length)
/* 202 */                 break;  pixels[blockPtr] = colorA;
/*     */               
/* 204 */               short s = (short)(pixels[blockPtr] & 0x7FFF);
/* 205 */               unpack(s, rtn, blockPtr, pixels.length);
/* 206 */               blockPtr++;
/*     */             } 
/* 208 */             blockPtr += rowInc;
/*     */           } 
/* 210 */           updateBlock(options.width);
/*     */       } 
/*     */     
/*     */     } 
/* 214 */     return rtn;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void unpack(short s, byte[] array, int offset, int len) {
/* 220 */     array[offset] = (byte)(255 - ((s & 0x7C00) >> 10));
/* 221 */     array[offset + len] = (byte)(255 - ((s & 0x3E0) >> 5));
/* 222 */     array[offset + 2 * len] = (byte)(255 - (s & 0x1F));
/*     */   }
/*     */   
/*     */   private void updateBlock(int width) {
/* 226 */     this.pixelPtr += 4;
/* 227 */     if (this.pixelPtr >= width) {
/* 228 */       this.pixelPtr = 0;
/* 229 */       this.rowPtr += this.stride * 4;
/*     */     } 
/* 231 */     this.totalBlocks--;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/codec/RPZACodec.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */