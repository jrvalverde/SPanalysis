/*     */ package loci.formats.codec;
/*     */ 
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import javax.imageio.ImageIO;
/*     */ import loci.common.DataTools;
/*     */ import loci.common.RandomAccessInputStream;
/*     */ import loci.formats.FormatException;
/*     */ import loci.formats.gui.AWTImageTools;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JPEGCodec
/*     */   extends BaseCodec
/*     */ {
/*     */   public byte[] compress(byte[] data, CodecOptions options) throws FormatException {
/*  77 */     if (data == null || data.length == 0) return data; 
/*  78 */     if (options == null) options = CodecOptions.getDefaultOptions();
/*     */     
/*  80 */     if (options.bitsPerSample > 8) {
/*  81 */       throw new FormatException("> 8 bit data cannot be compressed with JPEG.");
/*     */     }
/*     */     
/*  84 */     ByteArrayOutputStream out = new ByteArrayOutputStream();
/*  85 */     BufferedImage img = AWTImageTools.makeImage(data, options.width, options.height, options.channels, options.interleaved, options.bitsPerSample / 8, false, options.littleEndian, options.signed);
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*  90 */       ImageIO.write(img, "jpeg", out);
/*     */     }
/*  92 */     catch (IOException e) {
/*  93 */       throw new FormatException("Could not write JPEG data", e);
/*     */     } 
/*  95 */     return out.toByteArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] decompress(RandomAccessInputStream in, CodecOptions options) throws FormatException, IOException {
/*     */     BufferedImage b;
/* 109 */     long fp = in.getFilePointer(); try { while (true) { try {
/*     */           do {
/*     */           
/* 112 */           } while (in.read() != -1); if (in.read() != -40)
/* 113 */             continue;  in.seek(in.getFilePointer() - 2L);
/*     */         }
/* 115 */         catch (EOFException e) {
/* 116 */           in.seek(fp);
/*     */         }  break; }
/*     */       
/* 119 */       b = ImageIO.read(new BufferedInputStream(new DataInputStream((InputStream)in), 8192)); }
/*     */     
/* 121 */     catch (IOException exc)
/*     */     
/* 123 */     { in.seek(fp);
/* 124 */       return (new LosslessJPEGCodec()).decompress(in, options); }
/*     */ 
/*     */     
/* 127 */     if (options == null) options = CodecOptions.getDefaultOptions();
/*     */     
/* 129 */     byte[][] buf = AWTImageTools.getPixelBytes(b, options.littleEndian);
/*     */ 
/*     */     
/* 132 */     if (options.ycbcr && buf.length == 3) {
/* 133 */       int nBytes = (buf[0]).length / b.getWidth() * b.getHeight();
/* 134 */       int mask = (int)(Math.pow(2.0D, (nBytes * 8)) - 1.0D); int i;
/* 135 */       for (i = 0; i < (buf[0]).length; i += nBytes) {
/* 136 */         int y = DataTools.bytesToInt(buf[0], i, nBytes, options.littleEndian);
/* 137 */         int cb = DataTools.bytesToInt(buf[1], i, nBytes, options.littleEndian);
/* 138 */         int cr = DataTools.bytesToInt(buf[2], i, nBytes, options.littleEndian);
/*     */         
/* 140 */         cb = Math.max(0, cb - 128);
/* 141 */         cr = Math.max(0, cr - 128);
/*     */         
/* 143 */         int red = (int)(y + 1.402D * cr) & mask;
/* 144 */         int green = (int)(y - 0.34414D * cb - 0.71414D * cr) & mask;
/* 145 */         int blue = (int)(y + 1.772D * cb) & mask;
/*     */         
/* 147 */         DataTools.unpackBytes(red, buf[0], i, nBytes, options.littleEndian);
/* 148 */         DataTools.unpackBytes(green, buf[1], i, nBytes, options.littleEndian);
/* 149 */         DataTools.unpackBytes(blue, buf[2], i, nBytes, options.littleEndian);
/*     */       } 
/*     */     } 
/*     */     
/* 153 */     byte[] rtn = new byte[buf.length * (buf[0]).length];
/* 154 */     if (buf.length == 1) { rtn = buf[0]; }
/*     */     
/* 156 */     else if (options.interleaved)
/* 157 */     { int next = 0;
/* 158 */       for (int i = 0; i < (buf[0]).length; i++) {
/* 159 */         for (int j = 0; j < buf.length; j++) {
/* 160 */           rtn[next++] = buf[j][i];
/*     */         }
/*     */       }  }
/*     */     else
/*     */     
/* 165 */     { for (int i = 0; i < buf.length; i++) {
/* 166 */         System.arraycopy(buf[i], 0, rtn, i * (buf[0]).length, (buf[i]).length);
/*     */       } }
/*     */ 
/*     */     
/* 170 */     return rtn;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/codec/JPEGCodec.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */