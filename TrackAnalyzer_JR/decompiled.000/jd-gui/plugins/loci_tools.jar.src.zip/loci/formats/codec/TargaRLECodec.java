/*     */ package loci.formats.codec;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import loci.common.RandomAccessInputStream;
/*     */ import loci.formats.FormatException;
/*     */ import loci.formats.UnsupportedCompressionException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TargaRLECodec
/*     */   extends BaseCodec
/*     */ {
/*     */   public byte[] compress(byte[] data, CodecOptions options) throws FormatException {
/*  64 */     throw new UnsupportedCompressionException("Targa RLE compression not currently supported");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] decompress(RandomAccessInputStream in, CodecOptions options) throws FormatException, IOException {
/*  78 */     if (in == null)
/*  79 */       throw new IllegalArgumentException("No data to decompress."); 
/*  80 */     if (options == null) options = CodecOptions.getDefaultOptions(); 
/*  81 */     long fp = in.getFilePointer();
/*  82 */     ByteArrayOutputStream output = new ByteArrayOutputStream(options.maxBytes);
/*  83 */     int nread = 0;
/*  84 */     BufferedInputStream s = new BufferedInputStream((InputStream)in, 262144);
/*  85 */     int bpp = options.bitsPerSample / 8;
/*  86 */     while (output.size() < options.maxBytes) {
/*  87 */       byte n = (byte)(s.read() & 0xFF);
/*  88 */       nread++;
/*  89 */       if (n >= 0) {
/*  90 */         byte[] b = new byte[bpp * (n + 1)];
/*  91 */         s.read(b);
/*  92 */         nread += bpp * n + 1;
/*  93 */         output.write(b);
/*  94 */         b = null; continue;
/*     */       } 
/*  96 */       if (n != Byte.MIN_VALUE) {
/*  97 */         int len = (n & Byte.MAX_VALUE) + 1;
/*  98 */         byte[] inp = new byte[bpp];
/*  99 */         s.read(inp);
/* 100 */         nread += bpp;
/* 101 */         for (int i = 0; i < len; ) { output.write(inp); i++; }
/*     */       
/*     */       } 
/* 104 */     }  in.seek(fp + nread);
/* 105 */     return output.toByteArray();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/codec/TargaRLECodec.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */