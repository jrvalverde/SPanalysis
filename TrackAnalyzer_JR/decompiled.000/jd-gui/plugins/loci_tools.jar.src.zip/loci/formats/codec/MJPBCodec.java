/*     */ package loci.formats.codec;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import loci.common.RandomAccessInputStream;
/*     */ import loci.formats.FormatException;
/*     */ import loci.formats.UnsupportedCompressionException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MJPBCodec
/*     */   extends BaseCodec
/*     */ {
/*  56 */   private static final byte[] HEADER = new byte[] { -1, -40, 0, 16, 74, 70, 73, 70, 0, 1, 1, 0, 72, 72, 0, 0 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] compress(byte[] data, CodecOptions options) throws FormatException {
/*  67 */     throw new UnsupportedCompressionException("Motion JPEG-B compression not supported.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] decompress(RandomAccessInputStream in, CodecOptions options) throws FormatException, IOException {
/*  86 */     if (options == null) options = CodecOptions.getDefaultOptions(); 
/*  87 */     if (!(options instanceof MJPBCodecOptions)) {
/*  88 */       throw new FormatException("Options must be an instance of loci.formats.codec.MJPBCodecOptions");
/*     */     }
/*     */ 
/*     */     
/*  92 */     byte[] raw = null;
/*  93 */     byte[] raw2 = null;
/*     */     
/*  95 */     long fp = in.getFilePointer();
/*     */     
/*     */     try {
/*  98 */       in.skipBytes(4);
/*     */       
/* 100 */       byte[] lumDcBits = null, lumAcBits = null, lumDc = null, lumAc = null;
/* 101 */       byte[] quant = null;
/*     */       
/* 103 */       String s1 = in.readString(4);
/* 104 */       in.skipBytes(12);
/* 105 */       String s2 = in.readString(4);
/* 106 */       in.seek(in.getFilePointer() - 4L);
/* 107 */       if (s1.equals("mjpg") || s2.equals("mjpg")) {
/* 108 */         int extra = 16;
/* 109 */         if (s1.startsWith("m")) {
/* 110 */           extra = 0;
/* 111 */           in.seek(fp + 4L);
/*     */         } 
/* 113 */         in.skipBytes(12);
/*     */         
/* 115 */         int offset = in.readInt() + extra;
/* 116 */         int quantOffset = in.readInt() + extra;
/* 117 */         int huffmanOffset = in.readInt() + extra;
/* 118 */         int sof = in.readInt() + extra;
/* 119 */         int sos = in.readInt() + extra;
/* 120 */         int sod = in.readInt() + extra;
/*     */         
/* 122 */         if (quantOffset != 0 && quantOffset + fp < in.length()) {
/* 123 */           in.seek(fp + quantOffset);
/* 124 */           in.skipBytes(3);
/* 125 */           quant = new byte[64];
/* 126 */           in.read(quant);
/*     */         } else {
/*     */           
/* 129 */           quant = new byte[] { 7, 5, 5, 6, 5, 5, 7, 6, 6, 6, 8, 7, 7, 8, 10, 17, 11, 10, 9, 9, 10, 20, 15, 15, 12, 17, 24, 21, 25, 25, 23, 21, 23, 23, 26, 29, 37, 32, 26, 28, 35, 28, 23, 23, 33, 44, 33, 35, 39, 40, 42, 42, 42, 25, 31, 46, 49, 45, 41, 49, 37, 41, 42, 40 };
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 137 */         if (huffmanOffset != 0 && huffmanOffset + fp < in.length()) {
/* 138 */           in.seek(fp + huffmanOffset);
/* 139 */           in.skipBytes(3);
/* 140 */           lumDcBits = new byte[16];
/* 141 */           in.read(lumDcBits);
/* 142 */           lumDc = new byte[12];
/* 143 */           in.read(lumDc);
/* 144 */           in.skipBytes(1);
/* 145 */           lumAcBits = new byte[16];
/* 146 */           in.read(lumAcBits);
/*     */           
/* 148 */           int sum = 0;
/*     */           
/* 150 */           for (int n = 0; n < lumAcBits.length; n++) {
/* 151 */             sum += lumAcBits[n] & 0xFF;
/*     */           }
/*     */           
/* 154 */           lumAc = new byte[sum];
/* 155 */           in.read(lumAc);
/*     */         } 
/*     */         
/* 158 */         in.seek(fp + sof + 7L);
/*     */         
/* 160 */         int channels = in.read() & 0xFF;
/*     */         
/* 162 */         int[] sampling = new int[channels];
/* 163 */         for (int k = 0; k < channels; k++) {
/* 164 */           in.skipBytes(1);
/* 165 */           sampling[k] = in.read();
/* 166 */           in.skipBytes(1);
/*     */         } 
/*     */         
/* 169 */         in.seek(fp + sos + 3L);
/* 170 */         int[] tables = new int[channels];
/* 171 */         for (int m = 0; m < channels; m++) {
/* 172 */           in.skipBytes(1);
/* 173 */           tables[m] = in.read();
/*     */         } 
/*     */         
/* 176 */         in.seek(fp + sod);
/* 177 */         int numBytes = (int)(offset - in.getFilePointer());
/* 178 */         if (offset == 0) numBytes = (int)(in.length() - in.getFilePointer()); 
/* 179 */         raw = new byte[numBytes];
/* 180 */         in.read(raw);
/*     */         
/* 182 */         if (offset != 0) {
/* 183 */           in.seek(fp + offset + 36L);
/* 184 */           int n = in.readInt();
/* 185 */           in.skipBytes(n);
/* 186 */           in.seek(in.getFilePointer() - 40L);
/*     */           
/* 188 */           numBytes = (int)(in.length() - in.getFilePointer());
/* 189 */           raw2 = new byte[numBytes];
/* 190 */           in.read(raw2);
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 195 */       ByteVector b = new ByteVector();
/* 196 */       for (int i = 0; i < raw.length; i++) {
/* 197 */         b.add(raw[i]);
/* 198 */         if (raw[i] == -1) {
/* 199 */           b.add((byte)0);
/*     */         }
/*     */       } 
/*     */       
/* 203 */       if (raw2 == null) raw2 = new byte[0]; 
/* 204 */       ByteVector b2 = new ByteVector();
/* 205 */       for (int j = 0; j < raw2.length; j++) {
/* 206 */         b2.add(raw2[j]);
/* 207 */         if (raw2[j] == -1) {
/* 208 */           b2.add((byte)0);
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 214 */       ByteVector v = new ByteVector(1000);
/* 215 */       v.add(HEADER);
/*     */       
/* 217 */       v.add(new byte[] { -1, -37 });
/*     */       
/* 219 */       int length = 4 + quant.length * 2;
/* 220 */       v.add((byte)(length >>> 8 & 0xFF));
/* 221 */       v.add((byte)(length & 0xFF));
/* 222 */       v.add((byte)0);
/* 223 */       v.add(quant);
/*     */       
/* 225 */       v.add((byte)1);
/* 226 */       v.add(quant);
/*     */       
/* 228 */       v.add(new byte[] { -1, -60 });
/* 229 */       length = (lumDcBits.length + lumDc.length + lumAcBits.length + lumAc.length) * 2 + 6;
/*     */       
/* 231 */       v.add((byte)(length >>> 8 & 0xFF));
/* 232 */       v.add((byte)(length & 0xFF));
/*     */       
/* 234 */       v.add((byte)0);
/* 235 */       v.add(lumDcBits);
/* 236 */       v.add(lumDc);
/* 237 */       v.add((byte)1);
/* 238 */       v.add(lumDcBits);
/* 239 */       v.add(lumDc);
/* 240 */       v.add((byte)16);
/* 241 */       v.add(lumAcBits);
/* 242 */       v.add(lumAc);
/* 243 */       v.add((byte)17);
/* 244 */       v.add(lumAcBits);
/* 245 */       v.add(lumAc);
/*     */       
/* 247 */       v.add((byte)-1);
/* 248 */       v.add((byte)-64);
/*     */       
/* 250 */       length = (options.bitsPerSample >= 40) ? 11 : 17;
/* 251 */       v.add((byte)(length >>> 8 & 0xFF));
/* 252 */       v.add((byte)(length & 0xFF));
/*     */       
/* 254 */       int fieldHeight = options.height;
/* 255 */       if (((MJPBCodecOptions)options).interlaced) fieldHeight /= 2; 
/* 256 */       if (options.height % 2 == 1) fieldHeight++;
/*     */       
/* 258 */       int c = (options.bitsPerSample == 24) ? 3 : ((options.bitsPerSample == 32) ? 4 : 1);
/*     */ 
/*     */       
/* 261 */       v.add((options.bitsPerSample >= 40) ? (byte)(options.bitsPerSample - 32) : (byte)(options.bitsPerSample / c));
/*     */       
/* 263 */       v.add((byte)(fieldHeight >>> 8 & 0xFF));
/* 264 */       v.add((byte)(fieldHeight & 0xFF));
/* 265 */       v.add((byte)(options.width >>> 8 & 0xFF));
/* 266 */       v.add((byte)(options.width & 0xFF));
/* 267 */       v.add((options.bitsPerSample >= 40) ? 1 : 3);
/*     */       
/* 269 */       v.add((byte)1);
/* 270 */       v.add((byte)33);
/* 271 */       v.add((byte)0);
/*     */       
/* 273 */       if (options.bitsPerSample < 40) {
/* 274 */         v.add((byte)2);
/* 275 */         v.add((byte)17);
/* 276 */         v.add((byte)1);
/* 277 */         v.add((byte)3);
/* 278 */         v.add((byte)17);
/* 279 */         v.add((byte)1);
/*     */       } 
/*     */       
/* 282 */       v.add((byte)-1);
/* 283 */       v.add((byte)-38);
/*     */       
/* 285 */       length = (options.bitsPerSample >= 40) ? 8 : 12;
/* 286 */       v.add((byte)(length >>> 8 & 0xFF));
/* 287 */       v.add((byte)(length & 0xFF));
/*     */       
/* 289 */       v.add((options.bitsPerSample >= 40) ? 1 : 3);
/* 290 */       v.add((byte)1);
/* 291 */       v.add((byte)0);
/*     */       
/* 293 */       if (options.bitsPerSample < 40) {
/* 294 */         v.add((byte)2);
/* 295 */         v.add((byte)1);
/* 296 */         v.add((byte)3);
/* 297 */         v.add((byte)1);
/*     */       } 
/*     */       
/* 300 */       v.add((byte)0);
/* 301 */       v.add((byte)63);
/* 302 */       v.add((byte)0);
/*     */       
/* 304 */       if (((MJPBCodecOptions)options).interlaced) {
/* 305 */         ByteVector v2 = new ByteVector(v.size());
/* 306 */         v2.add(v.toByteArray());
/*     */         
/* 308 */         v.add(b.toByteArray());
/* 309 */         v.add((byte)-1);
/* 310 */         v.add((byte)-39);
/* 311 */         v2.add(b2.toByteArray());
/* 312 */         v2.add((byte)-1);
/* 313 */         v2.add((byte)-39);
/*     */         
/* 315 */         JPEGCodec jpeg = new JPEGCodec();
/* 316 */         byte[] top = jpeg.decompress(v.toByteArray(), options);
/* 317 */         byte[] bottom = jpeg.decompress(v2.toByteArray(), options);
/*     */         
/* 319 */         int bpp = (options.bitsPerSample < 40) ? (options.bitsPerSample / 8) : ((options.bitsPerSample - 32) / 8);
/*     */         
/* 321 */         int ch = (options.bitsPerSample < 40) ? 3 : 1;
/* 322 */         byte[] result = new byte[options.width * options.height * bpp * ch];
/*     */         
/* 324 */         int topNdx = 0;
/* 325 */         int bottomNdx = 0;
/*     */         
/* 327 */         int row = options.width * bpp;
/*     */         
/* 329 */         for (int yy = 0; yy < options.height; yy++) {
/* 330 */           if (yy % 2 == 0 && (topNdx + 1) * row <= top.length) {
/* 331 */             System.arraycopy(top, topNdx * row, result, yy * row, row);
/* 332 */             topNdx++;
/*     */           } else {
/*     */             
/* 335 */             if ((bottomNdx + 1) * row <= bottom.length) {
/* 336 */               System.arraycopy(bottom, bottomNdx * row, result, yy * row, row);
/*     */             }
/* 338 */             bottomNdx++;
/*     */           } 
/*     */         } 
/* 341 */         return result;
/*     */       } 
/*     */       
/* 344 */       v.add(b.toByteArray());
/* 345 */       v.add((byte)-1);
/* 346 */       v.add((byte)-39);
/* 347 */       return (new JPEGCodec()).decompress(v.toByteArray(), options);
/*     */     
/*     */     }
/* 350 */     catch (IOException e) {
/* 351 */       throw new FormatException(e);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/codec/MJPBCodec.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */