/*     */ package loci.formats.codec;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import loci.common.RandomAccessInputStream;
/*     */ import loci.formats.FormatException;
/*     */ import loci.formats.UnsupportedCompressionException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LZOCodec
/*     */   extends BaseCodec
/*     */ {
/*     */   private static final int LZO_OVERRUN = -6;
/*     */   
/*     */   public byte[] compress(byte[] data, CodecOptions options) throws FormatException {
/*  65 */     throw new UnsupportedCompressionException("LZO Compression not currently supported");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] decompress(RandomAccessInputStream in, CodecOptions options) throws FormatException, IOException {
/*  73 */     if (in == null) {
/*  74 */       throw new IllegalArgumentException("No data to decompress.");
/*     */     }
/*     */     
/*  77 */     ByteVector dst = new ByteVector();
/*  78 */     int t = in.read() & 0xFF;
/*     */ 
/*     */     
/*  81 */     if (t > 17) {
/*  82 */       t -= 17;
/*     */       
/*  84 */       byte[] b = new byte[t];
/*  85 */       in.read(b);
/*  86 */       dst.add(b);
/*  87 */       t = in.read() & 0xFF;
/*     */       
/*  89 */       if (t < 16) {
/*  90 */         return dst.toByteArray();
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*     */     label77: while (true) {
/*  96 */       if (t < 16) {
/*  97 */         if (t == 0) {
/*  98 */           byte f = in.readByte();
/*  99 */           while (f == 0) {
/* 100 */             t += 255;
/* 101 */             f = in.readByte();
/*     */           } 
/* 103 */           t += 15 + (f & 0xFF);
/*     */         } 
/* 105 */         t += 3;
/*     */         
/* 107 */         byte[] b = new byte[t];
/* 108 */         in.read(b);
/* 109 */         dst.add(b);
/* 110 */         t = in.read() & 0xFF;
/* 111 */         if (t < 16) {
/* 112 */           int mPos = dst.size() - 2049 - (t >> 2) - ((in.read() & 0xFF) << 2);
/* 113 */           if (mPos < 0) {
/* 114 */             t = -6;
/*     */             break;
/*     */           } 
/* 117 */           t = 3;
/*     */           do {
/* 119 */             dst.add(dst.get(mPos++));
/* 120 */           } while (--t > 0);
/*     */           
/* 122 */           in.seek(in.getFilePointer() - 2L);
/* 123 */           t = in.read() & 0x3;
/* 124 */           in.skipBytes(1);
/* 125 */           if (t == 0) {
/*     */             t = in.read() & 0xFF; continue;
/* 127 */           }  b = new byte[t];
/* 128 */           in.read(b);
/* 129 */           dst.add(b);
/* 130 */           t = in.read() & 0xFF;
/*     */         } 
/*     */       }  while (true) {
/*     */         int mPos;
/* 134 */         if (t >= 64) {
/* 135 */           mPos = dst.size() - 1 - (t >> 2 & 0x7) - ((in.read() & 0xFF) << 3);
/* 136 */           t = (t >> 5) - 1;
/*     */         }
/* 138 */         else if (t >= 32) {
/* 139 */           t &= 0x1F;
/* 140 */           if (t == 0) {
/* 141 */             byte f = in.readByte();
/* 142 */             while (f == 0) {
/* 143 */               t += 255;
/* 144 */               f = in.readByte();
/*     */             } 
/* 146 */             t += 31 + (f & 0xFF);
/*     */           } 
/* 148 */           mPos = dst.size() - 1 - ((in.read() & 0xFF) >> 2);
/* 149 */           mPos -= (in.read() & 0xFF) << 6;
/*     */         }
/* 151 */         else if (t >= 16) {
/* 152 */           mPos = dst.size() - ((t & 0x8) << 11);
/* 153 */           t &= 0x7;
/* 154 */           if (t == 0) {
/* 155 */             byte f = in.readByte();
/* 156 */             while (f == 0) {
/* 157 */               t += 255;
/* 158 */               f = in.readByte();
/*     */             } 
/* 160 */             t += 7 + (f & 0xFF);
/*     */           } 
/* 162 */           mPos -= (in.read() & 0xFF) >> 2;
/* 163 */           mPos -= (in.read() & 0xFF) << 6;
/* 164 */           if (mPos == dst.size())
/* 165 */             break;  mPos -= 16384;
/*     */         } else {
/*     */           
/* 168 */           mPos = dst.size() - 1 - (t >> 2) - ((in.read() & 0xFF) << 2);
/* 169 */           t = 0;
/*     */         } 
/*     */         
/* 172 */         if (mPos < 0) {
/* 173 */           t = -6;
/*     */           
/*     */           break;
/*     */         } 
/* 177 */         t += 2;
/*     */         
/*     */         while (true) {
/* 180 */           dst.add(dst.get(mPos++));
/* 181 */           if (--t <= 0)
/* 182 */           { in.seek(in.getFilePointer() - 2L);
/* 183 */             t = in.read() & 0x3;
/* 184 */             in.skipBytes(1);
/* 185 */             if (t == 0)
/*     */               break; 
/* 187 */             byte[] b = new byte[t];
/* 188 */             in.read(b);
/* 189 */             dst.add(b);
/* 190 */             t = 0; t = in.read() & 0xFF; } 
/*     */         }  continue label77;
/*     */       }  break;
/* 193 */     }  return dst.toByteArray();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/codec/LZOCodec.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */