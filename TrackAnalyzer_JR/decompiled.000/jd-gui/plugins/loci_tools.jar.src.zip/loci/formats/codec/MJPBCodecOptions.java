package loci.formats.codec;

public class MJPBCodecOptions extends CodecOptions {
  public boolean interlaced;
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/codec/MJPBCodecOptions.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */