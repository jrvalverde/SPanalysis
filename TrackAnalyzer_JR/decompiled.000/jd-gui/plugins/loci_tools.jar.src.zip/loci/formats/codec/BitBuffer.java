/*     */ package loci.formats.codec;
/*     */ 
/*     */ import java.util.Random;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BitBuffer
/*     */ {
/*  56 */   private static final Logger LOGGER = LoggerFactory.getLogger(BitBuffer.class);
/*     */ 
/*     */   
/*  59 */   private static final int[] BACK_MASK = new int[] { 0, 1, 3, 7, 15, 31, 63, 127 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  71 */   private static final int[] FRONT_MASK = new int[] { 0, 128, 192, 224, 240, 248, 252, 254 };
/*     */ 
/*     */   
/*     */   private byte[] byteBuffer;
/*     */ 
/*     */   
/*     */   private int currentByte;
/*     */ 
/*     */   
/*     */   private int currentBit;
/*     */ 
/*     */   
/*     */   private int eofByte;
/*     */ 
/*     */   
/*     */   private boolean eofFlag;
/*     */ 
/*     */   
/*     */   public BitBuffer(byte[] byteBuffer) {
/*  90 */     this.byteBuffer = byteBuffer;
/*  91 */     this.currentByte = 0;
/*  92 */     this.currentBit = 0;
/*  93 */     this.eofByte = byteBuffer.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void skipBits(long bits) {
/* 102 */     if (bits < 0L) {
/* 103 */       throw new IllegalArgumentException("Bits to skip may not be negative");
/*     */     }
/*     */ 
/*     */     
/* 107 */     if (this.eofByte * 8L < this.currentByte * 8L + this.currentBit + bits) {
/* 108 */       this.eofFlag = true;
/* 109 */       this.currentByte = this.eofByte;
/* 110 */       this.currentBit = 0;
/*     */       
/*     */       return;
/*     */     } 
/* 114 */     int skipBytes = (int)(bits / 8L);
/* 115 */     int skipBits = (int)(bits % 8L);
/* 116 */     this.currentByte += skipBytes;
/* 117 */     this.currentBit += skipBits;
/* 118 */     while (this.currentBit >= 8) {
/* 119 */       this.currentByte++;
/* 120 */       this.currentBit -= 8;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getBits(int bitsToRead) {
/* 142 */     if (bitsToRead < 0) {
/* 143 */       throw new IllegalArgumentException("Bits to read may not be negative");
/*     */     }
/* 145 */     if (bitsToRead == 0) return 0; 
/* 146 */     if (this.eofFlag) return -1; 
/* 147 */     int toStore = 0;
/* 148 */     while (bitsToRead != 0 && !this.eofFlag) {
/* 149 */       if (this.currentBit < 0 || this.currentBit > 7) {
/* 150 */         throw new IllegalStateException("byte=" + this.currentByte + ", bit = " + this.currentBit);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 155 */       int bitsLeft = 8 - this.currentBit;
/* 156 */       if (bitsToRead >= bitsLeft) {
/* 157 */         toStore <<= bitsLeft;
/* 158 */         bitsToRead -= bitsLeft;
/* 159 */         int cb = this.byteBuffer[this.currentByte];
/* 160 */         if (this.currentBit == 0) {
/*     */           
/* 162 */           toStore += cb & 0xFF;
/*     */         
/*     */         }
/*     */         else {
/*     */ 
/*     */           
/* 168 */           toStore += cb & BACK_MASK[bitsLeft];
/* 169 */           this.currentBit = 0;
/*     */         } 
/* 171 */         this.currentByte++;
/*     */       
/*     */       }
/*     */       else {
/*     */ 
/*     */         
/* 177 */         toStore <<= bitsToRead;
/* 178 */         int cb = this.byteBuffer[this.currentByte] & 0xFF;
/* 179 */         toStore += (cb & 255 - FRONT_MASK[this.currentBit]) >> bitsLeft - bitsToRead;
/*     */         
/* 181 */         this.currentBit += bitsToRead;
/* 182 */         bitsToRead = 0;
/*     */       } 
/*     */       
/* 185 */       if (this.currentByte == this.eofByte) {
/* 186 */         this.eofFlag = true;
/* 187 */         return toStore;
/*     */       } 
/*     */     } 
/* 190 */     return toStore;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {
/* 198 */     int trials = 50000;
/* 199 */     int[] nums = new int[trials];
/* 200 */     int[] len = new int[trials];
/* 201 */     BitWriter bw = new BitWriter();
/* 202 */     int totallen = 0;
/*     */     
/* 204 */     Random r = new Random();
/* 205 */     LOGGER.info("Generating {} trials.", Integer.valueOf(trials));
/* 206 */     LOGGER.info("Writing to byte array");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 213 */     for (int i = 0; i < trials; i++) {
/* 214 */       if (31 == i % 32) {
/* 215 */         nums[i] = r.nextInt();
/*     */       } else {
/*     */         
/* 218 */         nums[i] = r.nextInt(1 << i % 32);
/*     */       } 
/*     */       
/* 221 */       len[i] = Integer.toBinaryString(nums[i]).length();
/* 222 */       totallen += len[i];
/* 223 */       bw.write(nums[i], len[i]);
/*     */     } 
/* 225 */     BitBuffer bb = new BitBuffer(bw.toByteArray());
/*     */     
/* 227 */     LOGGER.info("Reading from BitBuffer");
/*     */     
/* 229 */     for (int j = 0; j < trials; j++) {
/* 230 */       int c = r.nextInt(100);
/* 231 */       if (c > 50) {
/* 232 */         int readint = bb.getBits(len[j]);
/* 233 */         if (readint != nums[j]) {
/* 234 */           LOGGER.info("Error at #{}: {} received, {} expected.", new Object[] { Integer.valueOf(j), Integer.valueOf(readint), Integer.valueOf(nums[j]) });
/*     */         }
/*     */       }
/*     */       else {
/*     */         
/* 239 */         bb.skipBits(len[j]);
/*     */       } 
/*     */     } 
/*     */     
/* 243 */     LOGGER.info("Testing end of buffer");
/* 244 */     bb = new BitBuffer(bw.toByteArray());
/*     */     
/* 246 */     bb.skipBits((totallen + 8));
/* 247 */     int read = bb.getBits(1);
/* 248 */     if (-1 != read)
/* 249 */       LOGGER.info("-1 expected at end of buffer, {} received.", Integer.valueOf(read)); 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/codec/BitBuffer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */