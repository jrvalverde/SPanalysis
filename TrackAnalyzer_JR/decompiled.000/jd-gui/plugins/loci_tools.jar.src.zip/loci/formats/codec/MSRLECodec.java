/*     */ package loci.formats.codec;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import loci.common.RandomAccessInputStream;
/*     */ import loci.formats.FormatException;
/*     */ import loci.formats.UnsupportedCompressionException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MSRLECodec
/*     */   extends BaseCodec
/*     */ {
/*     */   public byte[] compress(byte[] data, CodecOptions options) throws FormatException {
/*  58 */     throw new UnsupportedCompressionException("MSRLE compression not supported.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] decompress(RandomAccessInputStream in, CodecOptions options) throws FormatException, IOException {
/*  73 */     if (in == null)
/*  74 */       throw new IllegalArgumentException("No data to decompress."); 
/*  75 */     if (options == null) options = CodecOptions.getDefaultOptions();
/*     */     
/*  77 */     int code = 0;
/*  78 */     short extra = 0;
/*  79 */     int stream = 0;
/*     */     
/*  81 */     int pixelPt = 0;
/*  82 */     int rowPt = (options.height - 1) * options.width;
/*  83 */     int frameSize = options.height * options.width;
/*     */     
/*  85 */     if (options.previousImage == null) {
/*  86 */       options.previousImage = new byte[frameSize];
/*     */     }
/*     */     
/*  89 */     while (rowPt >= 0 && in.getFilePointer() < in.length() && pixelPt < options.previousImage.length) {
/*     */ 
/*     */       
/*  92 */       stream = in.read() & 0xFF;
/*  93 */       code = stream;
/*     */       
/*  95 */       if (code == 0) {
/*  96 */         stream = in.read() & 0xFF;
/*  97 */         if (stream == 0) {
/*  98 */           rowPt -= options.width;
/*  99 */           pixelPt = 0; continue;
/*     */         } 
/* 101 */         if (stream == 1) return options.previousImage; 
/* 102 */         if (stream == 2) {
/* 103 */           stream = in.read() & 0xFF;
/* 104 */           pixelPt += stream;
/* 105 */           stream = in.read() & 0xFF;
/* 106 */           rowPt -= stream * options.width;
/*     */           continue;
/*     */         } 
/* 109 */         if (rowPt + pixelPt + stream > frameSize || rowPt < 0) {
/* 110 */           return options.previousImage;
/*     */         }
/*     */         
/* 113 */         code = stream;
/* 114 */         extra = (short)(stream & 0x1);
/* 115 */         if ((stream + code + extra) > in.length()) return options.previousImage;
/*     */         
/* 117 */         while (code-- > 0) {
/* 118 */           stream = in.read();
/* 119 */           options.previousImage[rowPt + pixelPt] = (byte)stream;
/* 120 */           pixelPt++;
/*     */         } 
/* 122 */         if (extra != 0) in.skipBytes(1);
/*     */         
/*     */         continue;
/*     */       } 
/* 126 */       if (rowPt + pixelPt + stream > frameSize || rowPt < 0) {
/* 127 */         return options.previousImage;
/*     */       }
/*     */       
/* 130 */       stream = in.read();
/*     */       
/* 132 */       while (code-- > 0) {
/* 133 */         options.previousImage[rowPt + pixelPt] = (byte)stream;
/* 134 */         pixelPt++;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 139 */     return options.previousImage;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/codec/MSRLECodec.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */