/*     */ package loci.formats.codec;
/*     */ 
/*     */ import java.util.EnumSet;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import loci.common.enumeration.CodedEnum;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum JPEG2000BoxType
/*     */   implements CodedEnum
/*     */ {
/*  54 */   SIGNATURE(1783636000, "Signature"),
/*  55 */   SIGNATURE_WRONG_ENDIANNESS(538988650, "Signature (Wrong endianness)"),
/*  56 */   FILE(1718909296, "File"),
/*  57 */   HEADER(1785737832, "Header"),
/*  58 */   IMAGE_HEADER(1768449138, "Image header"),
/*  59 */   BITS_PER_COMPONENT(1651532643, "Bits per component"),
/*  60 */   COLOUR_SPECIFICATION(1668246642, "Colour specification"),
/*  61 */   PALETTE(1885564018, "Palette"),
/*  62 */   COMPONENT_MAPPING(1668112752, "Component mapping"),
/*  63 */   CHANNEL_DEFINITION(1667523942, "Channel definition"),
/*  64 */   RESOLUTION(1919251232, "Resolution"),
/*  65 */   CAPTURE_RESOLUTION(1919251299, "Capture resolution"),
/*  66 */   DEFAULT_DISPLAY_RESOLUTION(1919251300, "Default display resolution"),
/*  67 */   CONTIGUOUS_CODESTREAM(1785737827, "Contiguous codestream"),
/*  68 */   INTELLECTUAL_PROPERTY(1785737833, "Intellectual property"),
/*  69 */   XML(2020437024, "XML"),
/*  70 */   UUID(1970628964, "UUID"),
/*  71 */   UUID_INFO(1969843814, "UUID info"),
/*  72 */   UUID_LIST(1970041716, "UUID list"),
/*  73 */   URL(1970433056, "URL"),
/*  74 */   ASSOCIATION(1634955107, "Association"),
/*  75 */   LABEL(1818389536, "Label"),
/*  76 */   PLACEHOLDER(1885891684, "Placeholder");
/*     */   
/*     */   private int code;
/*     */   
/*     */   private String name;
/*     */   
/*     */   private static final Map<Integer, JPEG2000BoxType> lookup;
/*     */   
/*     */   static {
/*  85 */     lookup = new HashMap<Integer, JPEG2000BoxType>();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  90 */     for (JPEG2000BoxType v : EnumSet.<JPEG2000BoxType>allOf(JPEG2000BoxType.class)) {
/*  91 */       lookup.put(Integer.valueOf(v.getCode()), v);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JPEG2000BoxType get(int code) {
/* 102 */     return lookup.get(Integer.valueOf(code));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   JPEG2000BoxType(int code, String name) {
/* 111 */     this.code = code;
/* 112 */     this.name = name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getCode() {
/* 120 */     return this.code;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 128 */     return this.name;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/codec/JPEG2000BoxType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */