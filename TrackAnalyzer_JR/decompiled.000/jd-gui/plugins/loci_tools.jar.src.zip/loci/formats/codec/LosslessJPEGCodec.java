/*     */ package loci.formats.codec;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Vector;
/*     */ import loci.common.DataTools;
/*     */ import loci.common.RandomAccessInputStream;
/*     */ import loci.formats.FormatException;
/*     */ import loci.formats.UnsupportedCompressionException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LosslessJPEGCodec
/*     */   extends BaseCodec
/*     */ {
/*     */   private static final int SOF0 = 65472;
/*     */   private static final int SOF1 = 65473;
/*     */   private static final int SOF2 = 65474;
/*     */   private static final int SOF3 = 65475;
/*     */   private static final int SOF5 = 65477;
/*     */   private static final int SOF6 = 65478;
/*     */   private static final int SOF7 = 65479;
/*     */   private static final int JPG = 65480;
/*     */   private static final int SOF9 = 65481;
/*     */   private static final int SOF10 = 65482;
/*     */   private static final int SOF11 = 65483;
/*     */   private static final int SOF13 = 65485;
/*     */   private static final int SOF14 = 65486;
/*     */   private static final int SOF15 = 65487;
/*     */   private static final int DHT = 65476;
/*     */   private static final int DAC = 65484;
/*     */   private static final int RST_0 = 65488;
/*     */   private static final int RST_1 = 65489;
/*     */   private static final int RST_2 = 65490;
/*     */   private static final int RST_3 = 65491;
/*     */   private static final int RST_4 = 65492;
/*     */   private static final int RST_5 = 65493;
/*     */   private static final int RST_6 = 65494;
/*     */   private static final int RST_7 = 65495;
/*     */   private static final int SOI = 65496;
/*     */   private static final int EOI = 65497;
/*     */   private static final int SOS = 65498;
/*     */   private static final int DQT = 65499;
/*     */   private static final int DNL = 65500;
/*     */   private static final int DRI = 65501;
/*     */   private static final int DHP = 65502;
/*     */   private static final int EXP = 65503;
/*     */   private static final int COM = 65534;
/*     */   
/*     */   public byte[] compress(byte[] data, CodecOptions options) throws FormatException {
/* 111 */     throw new UnsupportedCompressionException("Lossless JPEG compression not supported");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] decompress(RandomAccessInputStream in, CodecOptions options) throws FormatException, IOException {
/* 125 */     if (in == null)
/* 126 */       throw new IllegalArgumentException("No data to decompress."); 
/* 127 */     if (options == null) options = CodecOptions.getDefaultOptions(); 
/* 128 */     byte[] buf = new byte[0];
/*     */     
/* 130 */     int width = 0, height = 0;
/* 131 */     int bitsPerSample = 0, nComponents = 0, bytesPerSample = 0;
/* 132 */     int[] horizontalSampling = null, verticalSampling = null;
/* 133 */     int[] quantizationTable = null;
/* 134 */     short[][] huffmanTables = (short[][])null;
/*     */     
/* 136 */     int startPredictor = 0, endPredictor = 0;
/* 137 */     int pointTransform = 0;
/*     */     
/* 139 */     int[] dcTable = null, acTable = null;
/*     */     
/* 141 */     while (in.getFilePointer() < in.length() - 1L) {
/* 142 */       int code = in.readShort() & 0xFFFF;
/* 143 */       int length = in.readShort() & 0xFFFF;
/* 144 */       long fp = in.getFilePointer();
/* 145 */       if (length > 65280) {
/* 146 */         length = 0;
/* 147 */         in.seek(fp - 2L); continue;
/*     */       } 
/* 149 */       if (code == 65498) {
/* 150 */         nComponents = in.read();
/* 151 */         dcTable = new int[nComponents];
/* 152 */         acTable = new int[nComponents];
/* 153 */         for (int i = 0; i < nComponents; i++) {
/* 154 */           int componentSelector = in.read();
/* 155 */           int tableSelector = in.read();
/* 156 */           dcTable[i] = (tableSelector & 0xF0) >> 4;
/* 157 */           acTable[i] = tableSelector & 0xF;
/*     */         } 
/* 159 */         startPredictor = in.read();
/* 160 */         endPredictor = in.read();
/* 161 */         pointTransform = in.read() & 0xF;
/*     */ 
/*     */ 
/*     */         
/* 165 */         byte[] toDecode = new byte[(int)(in.length() - in.getFilePointer())];
/* 166 */         in.read(toDecode);
/*     */ 
/*     */ 
/*     */         
/* 170 */         ByteVector b = new ByteVector();
/* 171 */         for (int j = 0; j < toDecode.length; j++) {
/* 172 */           b.add(toDecode[j]);
/* 173 */           if (toDecode[j] == -1 && toDecode[j + 1] == 0) j++; 
/*     */         } 
/* 175 */         toDecode = b.toByteArray();
/*     */         
/* 177 */         BitBuffer bb = new BitBuffer(toDecode);
/* 178 */         HuffmanCodec huffman = new HuffmanCodec();
/* 179 */         HuffmanCodecOptions huffmanOptions = new HuffmanCodecOptions();
/* 180 */         huffmanOptions.bitsPerSample = bitsPerSample;
/* 181 */         huffmanOptions.maxBytes = buf.length / nComponents;
/*     */         
/* 183 */         int nextSample = 0;
/* 184 */         while (nextSample < buf.length / nComponents) {
/* 185 */           for (int k = 0; k < nComponents; k++) {
/* 186 */             huffmanOptions.table = huffmanTables[dcTable[k]];
/* 187 */             int v = 0;
/*     */             
/* 189 */             if (huffmanTables != null) {
/* 190 */               v = huffman.getSample(bb, huffmanOptions);
/* 191 */               if (nextSample == 0) {
/* 192 */                 v += (int)Math.pow(2.0D, (bitsPerSample - 1));
/*     */               }
/*     */             } else {
/*     */               
/* 196 */               throw new UnsupportedCompressionException("Arithmetic coding not supported");
/*     */             } 
/*     */ 
/*     */ 
/*     */             
/* 201 */             int predictor = startPredictor;
/* 202 */             if (nextSample < width * bytesPerSample) { predictor = 1; }
/* 203 */             else if (nextSample % width * bytesPerSample == 0)
/* 204 */             { predictor = 2; }
/*     */ 
/*     */             
/* 207 */             int componentOffset = k * buf.length / nComponents;
/*     */             
/* 209 */             int indexA = nextSample - bytesPerSample + componentOffset;
/* 210 */             int indexB = nextSample - width * bytesPerSample + componentOffset;
/* 211 */             int indexC = nextSample - (width + 1) * bytesPerSample + componentOffset;
/*     */ 
/*     */             
/* 214 */             int sampleA = (indexA < 0) ? 0 : DataTools.bytesToInt(buf, indexA, bytesPerSample, false);
/*     */             
/* 216 */             int sampleB = (indexB < 0) ? 0 : DataTools.bytesToInt(buf, indexB, bytesPerSample, false);
/*     */             
/* 218 */             int sampleC = (indexC < 0) ? 0 : DataTools.bytesToInt(buf, indexC, bytesPerSample, false);
/*     */ 
/*     */             
/* 221 */             if (nextSample > 0) {
/* 222 */               int pred = 0;
/* 223 */               switch (predictor) {
/*     */                 case 1:
/* 225 */                   pred = sampleA;
/*     */                   break;
/*     */                 case 2:
/* 228 */                   pred = sampleB;
/*     */                   break;
/*     */                 case 3:
/* 231 */                   pred = sampleC;
/*     */                   break;
/*     */                 case 4:
/* 234 */                   pred = sampleA + sampleB + sampleC;
/*     */                   break;
/*     */                 case 5:
/* 237 */                   pred = sampleA + (sampleB - sampleC) / 2;
/*     */                   break;
/*     */                 case 6:
/* 240 */                   pred = sampleB + (sampleA - sampleC) / 2;
/*     */                   break;
/*     */                 case 7:
/* 243 */                   pred = (sampleA + sampleB) / 2;
/*     */                   break;
/*     */               } 
/* 246 */               v += pred;
/*     */             } 
/*     */             
/* 249 */             int offset = componentOffset + nextSample;
/*     */             
/* 251 */             DataTools.unpackBytes(v, buf, offset, bytesPerSample, false);
/*     */           } 
/* 253 */           nextSample += bytesPerSample;
/*     */         } 
/*     */         continue;
/*     */       } 
/* 257 */       length -= 2;
/* 258 */       if (length == 0)
/*     */         continue; 
/* 260 */       if (code != 65497)
/* 261 */         if (code == 65475) {
/*     */           
/* 263 */           bitsPerSample = in.read();
/* 264 */           height = in.readShort();
/* 265 */           width = in.readShort();
/* 266 */           nComponents = in.read();
/* 267 */           horizontalSampling = new int[nComponents];
/* 268 */           verticalSampling = new int[nComponents];
/* 269 */           quantizationTable = new int[nComponents];
/* 270 */           for (int i = 0; i < nComponents; i++) {
/* 271 */             in.skipBytes(1);
/* 272 */             int s = in.read();
/* 273 */             horizontalSampling[i] = (s & 0xF0) >> 4;
/* 274 */             verticalSampling[i] = s & 0xF;
/* 275 */             quantizationTable[i] = in.read();
/*     */           } 
/*     */           
/* 278 */           bytesPerSample = bitsPerSample / 8;
/* 279 */           if (bitsPerSample % 8 != 0) bytesPerSample++;
/*     */           
/* 281 */           buf = new byte[width * height * nComponents * bytesPerSample];
/*     */         } else {
/* 283 */           if (code == 65483) {
/* 284 */             throw new UnsupportedCompressionException("Arithmetic coding is not yet supported");
/*     */           }
/*     */           
/* 287 */           if (code == 65476) {
/* 288 */             if (huffmanTables == null) {
/* 289 */               huffmanTables = new short[4][];
/*     */             }
/* 291 */             int s = in.read();
/* 292 */             byte tableClass = (byte)((s & 0xF0) >> 4);
/* 293 */             byte destination = (byte)(s & 0xF);
/* 294 */             int[] nCodes = new int[16];
/* 295 */             Vector<Short> table = new Vector(); int i;
/* 296 */             for (i = 0; i < nCodes.length; i++) {
/* 297 */               nCodes[i] = in.read();
/* 298 */               table.add(new Short((short)nCodes[i]));
/*     */             } 
/*     */             
/* 301 */             for (i = 0; i < nCodes.length; i++) {
/* 302 */               for (int j = 0; j < nCodes[i]; j++) {
/* 303 */                 table.add(new Short((short)(in.read() & 0xFF)));
/*     */               }
/*     */             } 
/* 306 */             huffmanTables[destination] = new short[table.size()];
/* 307 */             for (i = 0; i < (huffmanTables[destination]).length; i++)
/* 308 */               huffmanTables[destination][i] = ((Short)table.get(i)).shortValue(); 
/*     */           } 
/*     */         }  
/* 311 */       in.seek(fp + length);
/*     */     } 
/*     */ 
/*     */     
/* 315 */     if (options.interleaved && nComponents > 1) {
/*     */       
/* 317 */       byte[] newBuf = new byte[buf.length]; int i;
/* 318 */       for (i = 0; i < buf.length; i += nComponents * bytesPerSample) {
/* 319 */         for (int c = 0; c < nComponents; c++) {
/* 320 */           int src = c * buf.length / nComponents + i / nComponents;
/* 321 */           int dst = i + c * bytesPerSample;
/* 322 */           System.arraycopy(buf, src, newBuf, dst, bytesPerSample);
/*     */         } 
/*     */       } 
/* 325 */       buf = newBuf;
/*     */     } 
/*     */     
/* 328 */     if (options.littleEndian && bytesPerSample > 1) {
/*     */ 
/*     */       
/* 331 */       byte[] newBuf = new byte[buf.length]; int i;
/* 332 */       for (i = 0; i < buf.length; i += bytesPerSample) {
/* 333 */         for (int q = 0; q < bytesPerSample; q++) {
/* 334 */           newBuf[i + bytesPerSample - q - 1] = buf[i + q];
/*     */         }
/*     */       } 
/* 337 */       buf = newBuf;
/*     */     } 
/*     */     
/* 340 */     return buf;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/codec/LosslessJPEGCodec.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */