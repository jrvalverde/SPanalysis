/*     */ package loci.formats.codec;
/*     */ 
/*     */ import java.awt.image.ColorModel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CodecOptions
/*     */ {
/*     */   public int width;
/*     */   public int height;
/*     */   public int channels;
/*     */   public int bitsPerSample;
/*     */   public boolean littleEndian;
/*     */   public boolean interleaved;
/*     */   public boolean signed;
/*     */   public int tileWidth;
/*     */   public int tileHeight;
/*     */   public int tileGridXOffset;
/*     */   public int tileGridYOffset;
/*     */   public int maxBytes;
/*     */   public byte[] previousImage;
/*     */   public boolean lossless;
/*     */   public ColorModel colorModel;
/*     */   public double quality;
/*     */   public boolean ycbcr;
/*     */   
/*     */   public CodecOptions() {}
/*     */   
/*     */   public CodecOptions(CodecOptions options) {
/* 135 */     if (options != null) {
/* 136 */       this.width = options.width;
/* 137 */       this.height = options.height;
/* 138 */       this.channels = options.channels;
/* 139 */       this.bitsPerSample = options.bitsPerSample;
/* 140 */       this.littleEndian = options.littleEndian;
/* 141 */       this.interleaved = options.interleaved;
/* 142 */       this.signed = options.signed;
/* 143 */       this.maxBytes = options.maxBytes;
/* 144 */       this.previousImage = options.previousImage;
/* 145 */       this.lossless = options.lossless;
/* 146 */       this.colorModel = options.colorModel;
/* 147 */       this.quality = options.quality;
/* 148 */       this.tileWidth = options.tileWidth;
/* 149 */       this.tileHeight = options.tileHeight;
/* 150 */       this.tileGridXOffset = options.tileGridXOffset;
/* 151 */       this.tileGridYOffset = options.tileGridYOffset;
/* 152 */       this.ycbcr = options.ycbcr;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CodecOptions getDefaultOptions() {
/* 160 */     CodecOptions options = new CodecOptions();
/* 161 */     options.littleEndian = false;
/* 162 */     options.interleaved = false;
/* 163 */     options.lossless = true;
/* 164 */     options.ycbcr = false;
/* 165 */     return options;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/loci/formats/codec/CodecOptions.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */