/*     */ package com.sun.media.imageio.stream;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.ByteOrder;
/*     */ import java.nio.CharBuffer;
/*     */ import java.nio.DoubleBuffer;
/*     */ import java.nio.FloatBuffer;
/*     */ import java.nio.IntBuffer;
/*     */ import java.nio.LongBuffer;
/*     */ import java.nio.ShortBuffer;
/*     */ import java.nio.channels.FileChannel;
/*     */ import javax.imageio.stream.ImageInputStream;
/*     */ import javax.imageio.stream.ImageOutputStreamImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FileChannelImageOutputStream
/*     */   extends ImageOutputStreamImpl
/*     */ {
/*     */   private static final int DEFAULT_WRITE_BUFFER_SIZE = 1048576;
/*     */   private FileChannel channel;
/*     */   private ByteBuffer byteBuffer;
/* 128 */   private ImageInputStream readStream = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FileChannelImageOutputStream(FileChannel channel) throws IOException {
/* 228 */     if (channel == null)
/* 229 */       throw new IllegalArgumentException("channel == null"); 
/* 230 */     if (!channel.isOpen()) {
/* 231 */       throw new IllegalArgumentException("channel.isOpen() == false");
/*     */     }
/*     */ 
/*     */     
/* 235 */     this.channel = channel;
/*     */ 
/*     */     
/* 238 */     this.streamPos = this.flushedPos = channel.position();
/*     */ 
/*     */     
/* 241 */     this.byteBuffer = ByteBuffer.allocateDirect(1048576);
/*     */ 
/*     */     
/* 244 */     this.readStream = new FileChannelImageInputStream(channel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImageInputStream getImageInputStream() throws IOException {
/* 254 */     flushBuffer();
/*     */ 
/*     */     
/* 257 */     this.readStream.setByteOrder(this.byteOrder);
/* 258 */     this.readStream.seek(this.streamPos);
/* 259 */     this.readStream.flushBefore(this.flushedPos);
/* 260 */     this.readStream.setBitOffset(this.bitOffset);
/*     */     
/* 262 */     return this.readStream;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void flushBuffer() throws IOException {
/* 270 */     if (this.byteBuffer.position() != 0) {
/*     */       
/* 272 */       this.byteBuffer.limit(this.byteBuffer.position());
/*     */ 
/*     */       
/* 275 */       this.byteBuffer.position(0);
/*     */ 
/*     */       
/* 278 */       this.channel.write(this.byteBuffer);
/*     */ 
/*     */       
/* 281 */       this.byteBuffer.clear();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int read() throws IOException {
/* 288 */     checkClosed();
/* 289 */     this.bitOffset = 0;
/*     */     
/* 291 */     ImageInputStream inputStream = getImageInputStream();
/*     */     
/* 293 */     this.streamPos++;
/*     */     
/* 295 */     return inputStream.read();
/*     */   }
/*     */ 
/*     */   
/*     */   public int read(byte[] b, int off, int len) throws IOException {
/* 300 */     if (off < 0 || len < 0 || off + len > b.length) {
/* 301 */       throw new IndexOutOfBoundsException("off < 0 || len < 0 || off + len > b.length");
/*     */     }
/* 303 */     if (len == 0) {
/* 304 */       return 0;
/*     */     }
/*     */     
/* 307 */     checkClosed();
/* 308 */     this.bitOffset = 0;
/*     */     
/* 310 */     ImageInputStream inputStream = getImageInputStream();
/*     */     
/* 312 */     int numBytesRead = inputStream.read(b, off, len);
/*     */     
/* 314 */     this.streamPos += numBytesRead;
/*     */     
/* 316 */     return numBytesRead;
/*     */   }
/*     */   
/*     */   public void write(int b) throws IOException {
/* 320 */     write(new byte[] { (byte)(b & 0xFF) }, 0, 1);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(byte[] b, int off, int len) throws IOException {
/* 326 */     if (off < 0 || len < 0 || off + len > b.length)
/*     */     {
/* 328 */       throw new IndexOutOfBoundsException("off < 0 || len < 0 || off + len > b.length");
/*     */     }
/* 330 */     if (len == 0) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 335 */     flushBits();
/*     */ 
/*     */     
/* 338 */     int numPut = 0;
/*     */ 
/*     */ 
/*     */     
/*     */     do {
/* 343 */       int numToPut = Math.min(len - numPut, this.byteBuffer.remaining());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 349 */       if (numToPut == 0)
/* 350 */       { flushBuffer();
/*     */          }
/*     */       
/*     */       else
/*     */       
/* 355 */       { this.byteBuffer.put(b, off + numPut, numToPut);
/*     */ 
/*     */         
/* 358 */         numPut += numToPut; } 
/* 359 */     } while (numPut < len);
/*     */ 
/*     */     
/* 362 */     this.streamPos += len;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readFully(char[] c, int off, int len) throws IOException {
/* 370 */     getImageInputStream().readFully(c, off, len);
/* 371 */     this.streamPos += (2 * len);
/*     */   }
/*     */   
/*     */   public void readFully(short[] s, int off, int len) throws IOException {
/* 375 */     getImageInputStream().readFully(s, off, len);
/* 376 */     this.streamPos += (2 * len);
/*     */   }
/*     */   
/*     */   public void readFully(int[] i, int off, int len) throws IOException {
/* 380 */     getImageInputStream().readFully(i, off, len);
/* 381 */     this.streamPos += (4 * len);
/*     */   }
/*     */   
/*     */   public void readFully(long[] l, int off, int len) throws IOException {
/* 385 */     getImageInputStream().readFully(l, off, len);
/* 386 */     this.streamPos += (8 * len);
/*     */   }
/*     */   
/*     */   public void readFully(float[] f, int off, int len) throws IOException {
/* 390 */     getImageInputStream().readFully(f, off, len);
/* 391 */     this.streamPos += (4 * len);
/*     */   }
/*     */   
/*     */   public void readFully(double[] d, int off, int len) throws IOException {
/* 395 */     getImageInputStream().readFully(d, off, len);
/* 396 */     this.streamPos += (8 * len);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeChars(char[] c, int off, int len) throws IOException {
/* 404 */     if (off < 0 || len < 0 || off + len > c.length)
/*     */     {
/* 406 */       throw new IndexOutOfBoundsException("off < 0 || len < 0 || off + len > c.length");
/*     */     }
/* 408 */     if (len == 0) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 413 */     flushBits();
/*     */ 
/*     */     
/* 416 */     int numPut = 0;
/*     */ 
/*     */     
/* 419 */     CharBuffer viewBuffer = this.byteBuffer.asCharBuffer();
/*     */ 
/*     */ 
/*     */     
/*     */     do {
/* 424 */       int numToPut = Math.min(len - numPut, viewBuffer.remaining());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 430 */       if (numToPut == 0)
/* 431 */       { flushBuffer();
/*     */          }
/*     */       
/*     */       else
/*     */       
/* 436 */       { viewBuffer.put(c, off + numPut, numToPut);
/*     */ 
/*     */         
/* 439 */         this.byteBuffer.position(this.byteBuffer.position() + 2 * numToPut);
/*     */ 
/*     */         
/* 442 */         numPut += numToPut; } 
/* 443 */     } while (numPut < len);
/*     */ 
/*     */     
/* 446 */     this.streamPos += (2 * len);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeShorts(short[] s, int off, int len) throws IOException {
/* 452 */     if (off < 0 || len < 0 || off + len > s.length)
/*     */     {
/* 454 */       throw new IndexOutOfBoundsException("off < 0 || len < 0 || off + len > c.length");
/*     */     }
/* 456 */     if (len == 0) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 461 */     flushBits();
/*     */ 
/*     */     
/* 464 */     int numPut = 0;
/*     */ 
/*     */     
/* 467 */     ShortBuffer viewBuffer = this.byteBuffer.asShortBuffer();
/*     */ 
/*     */ 
/*     */     
/*     */     do {
/* 472 */       int numToPut = Math.min(len - numPut, viewBuffer.remaining());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 478 */       if (numToPut == 0)
/* 479 */       { flushBuffer();
/*     */          }
/*     */       
/*     */       else
/*     */       
/* 484 */       { viewBuffer.put(s, off + numPut, numToPut);
/*     */ 
/*     */         
/* 487 */         this.byteBuffer.position(this.byteBuffer.position() + 2 * numToPut);
/*     */ 
/*     */         
/* 490 */         numPut += numToPut; } 
/* 491 */     } while (numPut < len);
/*     */ 
/*     */     
/* 494 */     this.streamPos += (2 * len);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeInts(int[] i, int off, int len) throws IOException {
/* 500 */     if (off < 0 || len < 0 || off + len > i.length)
/*     */     {
/* 502 */       throw new IndexOutOfBoundsException("off < 0 || len < 0 || off + len > c.length");
/*     */     }
/* 504 */     if (len == 0) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 509 */     flushBits();
/*     */ 
/*     */     
/* 512 */     int numPut = 0;
/*     */ 
/*     */     
/* 515 */     IntBuffer viewBuffer = this.byteBuffer.asIntBuffer();
/*     */ 
/*     */ 
/*     */     
/*     */     do {
/* 520 */       int numToPut = Math.min(len - numPut, viewBuffer.remaining());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 526 */       if (numToPut == 0)
/* 527 */       { flushBuffer();
/*     */          }
/*     */       
/*     */       else
/*     */       
/* 532 */       { viewBuffer.put(i, off + numPut, numToPut);
/*     */ 
/*     */         
/* 535 */         this.byteBuffer.position(this.byteBuffer.position() + 4 * numToPut);
/*     */ 
/*     */         
/* 538 */         numPut += numToPut; } 
/* 539 */     } while (numPut < len);
/*     */ 
/*     */     
/* 542 */     this.streamPos += (4 * len);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeLongs(long[] l, int off, int len) throws IOException {
/* 548 */     if (off < 0 || len < 0 || off + len > l.length)
/*     */     {
/* 550 */       throw new IndexOutOfBoundsException("off < 0 || len < 0 || off + len > c.length");
/*     */     }
/* 552 */     if (len == 0) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 557 */     flushBits();
/*     */ 
/*     */     
/* 560 */     int numPut = 0;
/*     */ 
/*     */     
/* 563 */     LongBuffer viewBuffer = this.byteBuffer.asLongBuffer();
/*     */ 
/*     */ 
/*     */     
/*     */     do {
/* 568 */       int numToPut = Math.min(len - numPut, viewBuffer.remaining());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 574 */       if (numToPut == 0)
/* 575 */       { flushBuffer();
/*     */          }
/*     */       
/*     */       else
/*     */       
/* 580 */       { viewBuffer.put(l, off + numPut, numToPut);
/*     */ 
/*     */         
/* 583 */         this.byteBuffer.position(this.byteBuffer.position() + 8 * numToPut);
/*     */ 
/*     */         
/* 586 */         numPut += numToPut; } 
/* 587 */     } while (numPut < len);
/*     */ 
/*     */     
/* 590 */     this.streamPos += (8 * len);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeFloats(float[] f, int off, int len) throws IOException {
/* 596 */     if (off < 0 || len < 0 || off + len > f.length)
/*     */     {
/* 598 */       throw new IndexOutOfBoundsException("off < 0 || len < 0 || off + len > f.length");
/*     */     }
/* 600 */     if (len == 0) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 605 */     flushBits();
/*     */ 
/*     */     
/* 608 */     int numPut = 0;
/*     */ 
/*     */     
/* 611 */     FloatBuffer viewBuffer = this.byteBuffer.asFloatBuffer();
/*     */ 
/*     */ 
/*     */     
/*     */     do {
/* 616 */       int numToPut = Math.min(len - numPut, viewBuffer.remaining());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 622 */       if (numToPut == 0)
/* 623 */       { flushBuffer();
/*     */          }
/*     */       
/*     */       else
/*     */       
/* 628 */       { viewBuffer.put(f, off + numPut, numToPut);
/*     */ 
/*     */         
/* 631 */         this.byteBuffer.position(this.byteBuffer.position() + 4 * numToPut);
/*     */ 
/*     */         
/* 634 */         numPut += numToPut; } 
/* 635 */     } while (numPut < len);
/*     */ 
/*     */     
/* 638 */     this.streamPos += (4 * len);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeDoubles(double[] d, int off, int len) throws IOException {
/* 644 */     if (off < 0 || len < 0 || off + len > d.length)
/*     */     {
/* 646 */       throw new IndexOutOfBoundsException("off < 0 || len < 0 || off + len > d.length");
/*     */     }
/* 648 */     if (len == 0) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 653 */     flushBits();
/*     */ 
/*     */     
/* 656 */     int numPut = 0;
/*     */ 
/*     */     
/* 659 */     DoubleBuffer viewBuffer = this.byteBuffer.asDoubleBuffer();
/*     */ 
/*     */ 
/*     */     
/*     */     do {
/* 664 */       int numToPut = Math.min(len - numPut, viewBuffer.remaining());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 670 */       if (numToPut == 0)
/* 671 */       { flushBuffer();
/*     */          }
/*     */       
/*     */       else
/*     */       
/* 676 */       { viewBuffer.put(d, off + numPut, numToPut);
/*     */ 
/*     */         
/* 679 */         this.byteBuffer.position(this.byteBuffer.position() + 8 * numToPut);
/*     */ 
/*     */         
/* 682 */         numPut += numToPut; } 
/* 683 */     } while (numPut < len);
/*     */ 
/*     */     
/* 686 */     this.streamPos += (8 * len);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 703 */     flushBuffer();
/*     */ 
/*     */     
/* 706 */     this.readStream.close();
/* 707 */     this.readStream = null;
/*     */ 
/*     */     
/* 710 */     this.channel = null;
/*     */ 
/*     */     
/* 713 */     this.byteBuffer = null;
/*     */ 
/*     */     
/* 716 */     super.close();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long length() {
/* 729 */     long length = -1L;
/*     */ 
/*     */     
/*     */     try {
/* 733 */       length = this.channel.size();
/* 734 */     } catch (IOException e) {}
/*     */ 
/*     */ 
/*     */     
/* 738 */     return length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void seek(long pos) throws IOException {
/* 746 */     super.seek(pos);
/*     */ 
/*     */     
/* 749 */     flushBuffer();
/*     */ 
/*     */     
/* 752 */     this.channel.position(pos);
/*     */   }
/*     */   
/*     */   public void setByteOrder(ByteOrder networkByteOrder) {
/* 756 */     super.setByteOrder(networkByteOrder);
/* 757 */     this.byteBuffer.order(networkByteOrder);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageio/stream/FileChannelImageOutputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */