/*     */ package com.sun.media.imageioimpl.plugins.jpeg2000;
/*     */ 
/*     */ import com.sun.media.imageio.plugins.jpeg2000.J2KImageReadParam;
/*     */ import javax.imageio.ImageReadParam;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class J2KImageReadParamJava
/*     */   extends J2KImageReadParam
/*     */ {
/*     */   private boolean noROIDescaling;
/*     */   private boolean parsingEnabled;
/*     */   
/*     */   public J2KImageReadParamJava() {
/* 138 */     this.noROIDescaling = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 146 */     this.parsingEnabled = true; } public J2KImageReadParamJava(ImageReadParam param) { J2KImageReadParam j2kParam; this.noROIDescaling = true; this.parsingEnabled = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 157 */     if (param.hasController()) {
/* 158 */       setController(param.getController());
/*     */     }
/* 160 */     setSourceRegion(param.getSourceRegion());
/* 161 */     setSourceBands(param.getSourceBands());
/* 162 */     setDestinationBands(param.getDestinationBands());
/* 163 */     setDestination(param.getDestination());
/*     */     
/* 165 */     setDestinationOffset(param.getDestinationOffset());
/* 166 */     setSourceSubsampling(param.getSourceXSubsampling(), param.getSourceYSubsampling(), param.getSubsamplingXOffset(), param.getSubsamplingYOffset());
/*     */ 
/*     */ 
/*     */     
/* 170 */     setDestinationType(param.getDestinationType());
/*     */ 
/*     */ 
/*     */     
/* 174 */     if (param instanceof J2KImageReadParam) {
/* 175 */       j2kParam = (J2KImageReadParam)param;
/*     */     } else {
/* 177 */       j2kParam = new J2KImageReadParam();
/*     */     } 
/* 179 */     setDecodingRate(j2kParam.getDecodingRate());
/* 180 */     setResolution(j2kParam.getResolution()); }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNoROIDescaling(boolean value) {
/* 185 */     this.noROIDescaling = value;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getNoROIDescaling() {
/* 190 */     return this.noROIDescaling;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setParsingEnabled(boolean value) {
/* 195 */     this.parsingEnabled = value;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getParsingEnabled() {
/* 200 */     return this.parsingEnabled;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/jpeg2000/J2KImageReadParamJava.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */