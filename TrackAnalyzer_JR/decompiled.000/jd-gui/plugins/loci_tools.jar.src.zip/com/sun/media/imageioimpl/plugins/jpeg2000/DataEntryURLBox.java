/*     */ package com.sun.media.imageioimpl.plugins.jpeg2000;
/*     */ 
/*     */ import javax.imageio.metadata.IIOInvalidTreeException;
/*     */ import javax.imageio.metadata.IIOMetadataNode;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataEntryURLBox
/*     */   extends Box
/*     */ {
/*  95 */   private static String[] elementNames = new String[] { "Version", "Flags", "URL" };
/*     */   private byte version;
/*     */   private byte[] flags;
/*     */   private String url;
/*     */   
/*     */   public static String[] getElementNames() {
/* 101 */     return elementNames;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DataEntryURLBox(byte[] data) {
/* 111 */     super(8 + data.length, 1970433056, data);
/*     */   }
/*     */ 
/*     */   
/*     */   public DataEntryURLBox(byte version, byte[] flags, String url) {
/* 116 */     super(12 + url.length(), 1970433056, null);
/* 117 */     this.version = version;
/* 118 */     this.flags = flags;
/* 119 */     this.url = url;
/*     */   }
/*     */ 
/*     */   
/*     */   public DataEntryURLBox(Node node) throws IIOInvalidTreeException {
/* 124 */     super(node);
/* 125 */     NodeList children = node.getChildNodes();
/*     */     
/* 127 */     for (int i = 0; i < children.getLength(); i++) {
/* 128 */       Node child = children.item(i);
/* 129 */       String name = child.getNodeName();
/*     */       
/* 131 */       if ("Version".equals(name)) {
/* 132 */         this.version = Box.getByteElementValue(child);
/*     */       }
/*     */       
/* 135 */       if ("Flags".equals(name)) {
/* 136 */         this.flags = Box.getByteArrayElementValue(child);
/*     */       }
/*     */       
/* 139 */       if ("URL".equals(name)) {
/* 140 */         this.url = Box.getStringElementValue(child);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void parse(byte[] data) {
/* 147 */     this.version = data[0];
/* 148 */     this.flags = new byte[3];
/* 149 */     this.flags[0] = data[1];
/* 150 */     this.flags[1] = data[2];
/* 151 */     this.flags[2] = data[3];
/*     */     
/* 153 */     this.url = new String(data, 4, data.length - 4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IIOMetadataNode getNativeNode() {
/* 161 */     return getNativeNodeForSimpleBox();
/*     */   }
/*     */ 
/*     */   
/*     */   public byte getVersion() {
/* 166 */     return this.version;
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] getFlags() {
/* 171 */     return this.flags;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getURL() {
/* 176 */     return this.url;
/*     */   }
/*     */   
/*     */   protected void compose() {
/* 180 */     if (this.data != null)
/*     */       return; 
/* 182 */     this.data = new byte[4 + this.url.length()];
/*     */     
/* 184 */     this.data[0] = this.version;
/* 185 */     this.data[1] = this.flags[0];
/* 186 */     this.data[2] = this.flags[1];
/* 187 */     this.data[3] = this.flags[2];
/* 188 */     System.arraycopy(this.url.getBytes(), 0, this.data, 4, this.url.length());
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/jpeg2000/DataEntryURLBox.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */