/*     */ package com.sun.media.imageioimpl.plugins.pnm;
/*     */ 
/*     */ import java.util.Hashtable;
/*     */ import javax.imageio.ImageTypeSpecifier;
/*     */ import javax.imageio.metadata.IIOMetadataFormatImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PNMMetadataFormat
/*     */   extends IIOMetadataFormatImpl
/*     */ {
/*  90 */   private static Hashtable parents = new Hashtable<Object, Object>();
/*     */   private static PNMMetadataFormat instance;
/*     */   
/*     */   static {
/*  94 */     parents.put("FormatName", "com_sun_media_imageio_plugins_pnm_image_1.0");
/*  95 */     parents.put("Variant", "com_sun_media_imageio_plugins_pnm_image_1.0");
/*  96 */     parents.put("Width", "com_sun_media_imageio_plugins_pnm_image_1.0");
/*  97 */     parents.put("Height", "com_sun_media_imageio_plugins_pnm_image_1.0");
/*  98 */     parents.put("MaximumSample", "com_sun_media_imageio_plugins_pnm_image_1.0");
/*  99 */     parents.put("Comment", "com_sun_media_imageio_plugins_pnm_image_1.0");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized PNMMetadataFormat getInstance() {
/* 105 */     if (instance == null)
/* 106 */       instance = new PNMMetadataFormat(); 
/* 107 */     return instance;
/*     */   }
/*     */   
/* 110 */   String resourceBaseName = getClass().getName() + "Resources";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   PNMMetadataFormat() {
/* 117 */     super("com_sun_media_imageio_plugins_pnm_image_1.0", 1);
/* 118 */     setResourceBaseName(this.resourceBaseName);
/* 119 */     addElements();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addElements() {
/* 126 */     addElement("FormatName", getParent("FormatName"), 0);
/*     */ 
/*     */ 
/*     */     
/* 130 */     addElement("Variant", getParent("Variant"), 0);
/*     */ 
/*     */     
/* 133 */     addElement("Width", getParent("Width"), 0);
/*     */ 
/*     */     
/* 136 */     addElement("Height", getParent("Height"), 0);
/*     */ 
/*     */     
/* 139 */     addElement("MaximumSample", getParent("MaximumSample"), 0);
/*     */ 
/*     */     
/* 142 */     addElement("Comment", getParent("Comment"), 0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getParent(String elementName) {
/* 148 */     return (String)parents.get(elementName);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canNodeAppear(String elementName, ImageTypeSpecifier imageType) {
/* 153 */     if (getParent(elementName) != null)
/* 154 */       return true; 
/* 155 */     return false;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/pnm/PNMMetadataFormat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */