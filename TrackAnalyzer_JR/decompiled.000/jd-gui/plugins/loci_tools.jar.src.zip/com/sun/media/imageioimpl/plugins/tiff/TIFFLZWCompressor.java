/*     */ package com.sun.media.imageioimpl.plugins.tiff;
/*     */ 
/*     */ import com.sun.media.imageio.plugins.tiff.TIFFCompressor;
/*     */ import com.sun.media.imageioimpl.common.LZWCompressor;
/*     */ import java.io.IOException;
/*     */ import javax.imageio.stream.ImageOutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TIFFLZWCompressor
/*     */   extends TIFFCompressor
/*     */ {
/*     */   int predictor;
/*     */   
/*     */   public TIFFLZWCompressor(int predictorValue) {
/*  97 */     super("LZW", 5, true);
/*  98 */     this.predictor = predictorValue;
/*     */   }
/*     */   
/*     */   public void setStream(ImageOutputStream stream) {
/* 102 */     super.setStream(stream);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int encode(byte[] b, int off, int width, int height, int[] bitsPerSample, int scanlineStride) throws IOException {
/* 110 */     LZWCompressor lzwCompressor = new LZWCompressor(this.stream, 8, true);
/*     */     
/* 112 */     int samplesPerPixel = bitsPerSample.length;
/* 113 */     int bitsPerPixel = 0;
/* 114 */     for (int i = 0; i < samplesPerPixel; i++) {
/* 115 */       bitsPerPixel += bitsPerSample[i];
/*     */     }
/* 117 */     int bytesPerRow = (bitsPerPixel * width + 7) / 8;
/*     */     
/* 119 */     long initialStreamPosition = this.stream.getStreamPosition();
/*     */     
/* 121 */     boolean usePredictor = (this.predictor == 2);
/*     */ 
/*     */     
/* 124 */     if (bytesPerRow == scanlineStride && !usePredictor) {
/* 125 */       lzwCompressor.compress(b, off, bytesPerRow * height);
/*     */     } else {
/* 127 */       byte[] rowBuf = usePredictor ? new byte[bytesPerRow] : null;
/* 128 */       for (int j = 0; j < height; j++) {
/* 129 */         if (usePredictor) {
/*     */ 
/*     */           
/* 132 */           System.arraycopy(b, off, rowBuf, 0, bytesPerRow);
/* 133 */           for (int k = bytesPerRow - 1; k >= samplesPerPixel; k--) {
/* 134 */             rowBuf[k] = (byte)(rowBuf[k] - rowBuf[k - samplesPerPixel]);
/*     */           }
/* 136 */           lzwCompressor.compress(rowBuf, 0, bytesPerRow);
/*     */         } else {
/* 138 */           lzwCompressor.compress(b, off, bytesPerRow);
/*     */         } 
/* 140 */         off += scanlineStride;
/*     */       } 
/*     */     } 
/*     */     
/* 144 */     lzwCompressor.flush();
/*     */     
/* 146 */     int bytesWritten = (int)(this.stream.getStreamPosition() - initialStreamPosition);
/*     */ 
/*     */     
/* 149 */     return bytesWritten;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/tiff/TIFFLZWCompressor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */