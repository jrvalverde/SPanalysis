/*     */ package com.sun.media.imageioimpl.plugins.gif;
/*     */ 
/*     */ import javax.imageio.metadata.IIOInvalidTreeException;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class GIFWritableStreamMetadata
/*     */   extends GIFStreamMetadata
/*     */ {
/*     */   static final String NATIVE_FORMAT_NAME = "javax_imageio_gif_stream_1.0";
/*     */   
/*     */   public GIFWritableStreamMetadata() {
/* 105 */     super(true, "javax_imageio_gif_stream_1.0", "com.sun.media.imageioimpl.plugins.gif.GIFStreamMetadataFormat", (String[])null, (String[])null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 111 */     reset();
/*     */   }
/*     */   
/*     */   public boolean isReadOnly() {
/* 115 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void mergeTree(String formatName, Node root) throws IIOInvalidTreeException {
/* 120 */     if (formatName.equals("javax_imageio_gif_stream_1.0")) {
/* 121 */       if (root == null) {
/* 122 */         throw new IllegalArgumentException("root == null!");
/*     */       }
/* 124 */       mergeNativeTree(root);
/* 125 */     } else if (formatName.equals("javax_imageio_1.0")) {
/*     */       
/* 127 */       if (root == null) {
/* 128 */         throw new IllegalArgumentException("root == null!");
/*     */       }
/* 130 */       mergeStandardTree(root);
/*     */     } else {
/* 132 */       throw new IllegalArgumentException("Not a recognized format!");
/*     */     } 
/*     */   }
/*     */   
/*     */   public void reset() {
/* 137 */     this.version = null;
/*     */     
/* 139 */     this.logicalScreenWidth = -1;
/* 140 */     this.logicalScreenHeight = -1;
/* 141 */     this.colorResolution = -1;
/* 142 */     this.pixelAspectRatio = 0;
/*     */     
/* 144 */     this.backgroundColorIndex = 0;
/* 145 */     this.sortFlag = false;
/* 146 */     this.globalColorTable = null;
/*     */   }
/*     */   
/*     */   protected void mergeNativeTree(Node root) throws IIOInvalidTreeException {
/* 150 */     Node node = root;
/* 151 */     if (!node.getNodeName().equals("javax_imageio_gif_stream_1.0")) {
/* 152 */       fatal(node, "Root must be javax_imageio_gif_stream_1.0");
/*     */     }
/*     */     
/* 155 */     node = node.getFirstChild();
/* 156 */     while (node != null) {
/* 157 */       String name = node.getNodeName();
/*     */       
/* 159 */       if (name.equals("Version")) {
/* 160 */         this.version = getStringAttribute(node, "value", null, true, versionStrings);
/*     */       }
/* 162 */       else if (name.equals("LogicalScreenDescriptor")) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 168 */         this.logicalScreenWidth = getIntAttribute(node, "logicalScreenWidth", -1, true, true, 1, 65535);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 174 */         this.logicalScreenHeight = getIntAttribute(node, "logicalScreenHeight", -1, true, true, 1, 65535);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 180 */         this.colorResolution = getIntAttribute(node, "colorResolution", -1, true, true, 1, 8);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 186 */         this.pixelAspectRatio = getIntAttribute(node, "pixelAspectRatio", 0, true, true, 0, 255);
/*     */ 
/*     */       
/*     */       }
/* 190 */       else if (name.equals("GlobalColorTable")) {
/* 191 */         int sizeOfGlobalColorTable = getIntAttribute(node, "sizeOfGlobalColorTable", true, 2, 256);
/*     */ 
/*     */         
/* 194 */         if (sizeOfGlobalColorTable != 2 && sizeOfGlobalColorTable != 4 && sizeOfGlobalColorTable != 8 && sizeOfGlobalColorTable != 16 && sizeOfGlobalColorTable != 32 && sizeOfGlobalColorTable != 64 && sizeOfGlobalColorTable != 128 && sizeOfGlobalColorTable != 256)
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 202 */           fatal(node, "Bad value for GlobalColorTable attribute sizeOfGlobalColorTable!");
/*     */         }
/*     */ 
/*     */         
/* 206 */         this.backgroundColorIndex = getIntAttribute(node, "backgroundColorIndex", 0, true, true, 0, 255);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 211 */         this.sortFlag = getBooleanAttribute(node, "sortFlag", false, true);
/*     */         
/* 213 */         this.globalColorTable = getColorTable(node, "ColorTableEntry", true, sizeOfGlobalColorTable);
/*     */       } else {
/*     */         
/* 216 */         fatal(node, "Unknown child of root node!");
/*     */       } 
/*     */       
/* 219 */       node = node.getNextSibling();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void mergeStandardTree(Node root) throws IIOInvalidTreeException {
/* 225 */     Node node = root;
/* 226 */     if (!node.getNodeName().equals("javax_imageio_1.0"))
/*     */     {
/* 228 */       fatal(node, "Root must be javax_imageio_1.0");
/*     */     }
/*     */ 
/*     */     
/* 232 */     node = node.getFirstChild();
/* 233 */     while (node != null) {
/* 234 */       String name = node.getNodeName();
/*     */       
/* 236 */       if (name.equals("Chroma")) {
/* 237 */         Node childNode = node.getFirstChild();
/* 238 */         while (childNode != null) {
/* 239 */           String childName = childNode.getNodeName();
/* 240 */           if (childName.equals("Palette")) {
/* 241 */             this.globalColorTable = getColorTable(childNode, "PaletteEntry", false, -1);
/*     */ 
/*     */           
/*     */           }
/* 245 */           else if (childName.equals("BackgroundIndex")) {
/* 246 */             this.backgroundColorIndex = getIntAttribute(childNode, "value", -1, true, true, 0, 255);
/*     */           } 
/*     */ 
/*     */ 
/*     */           
/* 251 */           childNode = childNode.getNextSibling();
/*     */         } 
/* 253 */       } else if (name.equals("Data")) {
/* 254 */         Node childNode = node.getFirstChild();
/* 255 */         while (childNode != null) {
/* 256 */           String childName = childNode.getNodeName();
/* 257 */           if (childName.equals("BitsPerSample")) {
/* 258 */             this.colorResolution = getIntAttribute(childNode, "value", -1, true, true, 1, 8);
/*     */ 
/*     */             
/*     */             break;
/*     */           } 
/*     */           
/* 264 */           childNode = childNode.getNextSibling();
/*     */         } 
/* 266 */       } else if (name.equals("Dimension")) {
/* 267 */         Node childNode = node.getFirstChild();
/* 268 */         while (childNode != null) {
/* 269 */           String childName = childNode.getNodeName();
/* 270 */           if (childName.equals("PixelAspectRatio")) {
/* 271 */             float aspectRatio = getFloatAttribute(childNode, "value");
/*     */             
/* 273 */             if (aspectRatio == 1.0F) {
/* 274 */               this.pixelAspectRatio = 0;
/*     */             } else {
/* 276 */               int ratio = (int)(aspectRatio * 64.0F - 15.0F);
/* 277 */               this.pixelAspectRatio = Math.max(Math.min(ratio, 255), 0);
/*     */             }
/*     */           
/* 280 */           } else if (childName.equals("HorizontalScreenSize")) {
/* 281 */             this.logicalScreenWidth = getIntAttribute(childNode, "value", -1, true, true, 1, 65535);
/*     */ 
/*     */           
/*     */           }
/* 285 */           else if (childName.equals("VerticalScreenSize")) {
/* 286 */             this.logicalScreenHeight = getIntAttribute(childNode, "value", -1, true, true, 1, 65535);
/*     */           } 
/*     */ 
/*     */ 
/*     */           
/* 291 */           childNode = childNode.getNextSibling();
/*     */         } 
/* 293 */       } else if (name.equals("Document")) {
/* 294 */         Node childNode = node.getFirstChild();
/* 295 */         while (childNode != null) {
/* 296 */           String childName = childNode.getNodeName();
/* 297 */           if (childName.equals("FormatVersion")) {
/* 298 */             String formatVersion = getStringAttribute(childNode, "value", null, true, null);
/*     */ 
/*     */             
/* 301 */             for (int i = 0; i < versionStrings.length; i++) {
/* 302 */               if (formatVersion.equals(versionStrings[i])) {
/* 303 */                 this.version = formatVersion;
/*     */                 break;
/*     */               } 
/*     */             } 
/*     */             break;
/*     */           } 
/* 309 */           childNode = childNode.getNextSibling();
/*     */         } 
/*     */       } 
/*     */       
/* 313 */       node = node.getNextSibling();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFromTree(String formatName, Node root) throws IIOInvalidTreeException {
/* 320 */     reset();
/* 321 */     mergeTree(formatName, root);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/gif/GIFWritableStreamMetadata.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */