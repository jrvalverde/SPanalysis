/*      */ package com.sun.media.imageioimpl.plugins.bmp;
/*      */ 
/*      */ import com.sun.media.imageioimpl.common.ImageUtil;
/*      */ import java.awt.Point;
/*      */ import java.awt.Rectangle;
/*      */ import java.awt.color.ColorSpace;
/*      */ import java.awt.color.ICC_ColorSpace;
/*      */ import java.awt.color.ICC_Profile;
/*      */ import java.awt.image.BufferedImage;
/*      */ import java.awt.image.ColorModel;
/*      */ import java.awt.image.ComponentSampleModel;
/*      */ import java.awt.image.DataBufferByte;
/*      */ import java.awt.image.DataBufferInt;
/*      */ import java.awt.image.DataBufferUShort;
/*      */ import java.awt.image.DirectColorModel;
/*      */ import java.awt.image.IndexColorModel;
/*      */ import java.awt.image.MultiPixelPackedSampleModel;
/*      */ import java.awt.image.PixelInterleavedSampleModel;
/*      */ import java.awt.image.Raster;
/*      */ import java.awt.image.SampleModel;
/*      */ import java.awt.image.SinglePixelPackedSampleModel;
/*      */ import java.awt.image.WritableRaster;
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.IOException;
/*      */ import java.nio.ByteOrder;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Iterator;
/*      */ import javax.imageio.ImageIO;
/*      */ import javax.imageio.ImageReadParam;
/*      */ import javax.imageio.ImageReader;
/*      */ import javax.imageio.ImageTypeSpecifier;
/*      */ import javax.imageio.event.IIOReadProgressListener;
/*      */ import javax.imageio.event.IIOReadUpdateListener;
/*      */ import javax.imageio.event.IIOReadWarningListener;
/*      */ import javax.imageio.metadata.IIOMetadata;
/*      */ import javax.imageio.spi.ImageReaderSpi;
/*      */ import javax.imageio.stream.ImageInputStream;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class BMPImageReader
/*      */   extends ImageReader
/*      */   implements BMPConstants
/*      */ {
/*      */   private static final int VERSION_2_1_BIT = 0;
/*      */   private static final int VERSION_2_4_BIT = 1;
/*      */   private static final int VERSION_2_8_BIT = 2;
/*      */   private static final int VERSION_2_24_BIT = 3;
/*      */   private static final int VERSION_3_1_BIT = 4;
/*      */   private static final int VERSION_3_4_BIT = 5;
/*      */   private static final int VERSION_3_8_BIT = 6;
/*      */   private static final int VERSION_3_24_BIT = 7;
/*      */   private static final int VERSION_3_NT_16_BIT = 8;
/*      */   private static final int VERSION_3_NT_32_BIT = 9;
/*      */   private static final int VERSION_4_1_BIT = 10;
/*      */   private static final int VERSION_4_4_BIT = 11;
/*      */   private static final int VERSION_4_8_BIT = 12;
/*      */   private static final int VERSION_4_16_BIT = 13;
/*      */   private static final int VERSION_4_24_BIT = 14;
/*      */   private static final int VERSION_4_32_BIT = 15;
/*      */   private static final int VERSION_3_XP_EMBEDDED = 16;
/*      */   private static final int VERSION_4_XP_EMBEDDED = 17;
/*      */   private static final int VERSION_5_XP_EMBEDDED = 18;
/*      */   private long bitmapFileSize;
/*      */   private long bitmapOffset;
/*      */   private long compression;
/*      */   private long imageSize;
/*      */   private byte[] palette;
/*      */   private int imageType;
/*      */   private int numBands;
/*      */   private boolean isBottomUp;
/*      */   private int bitsPerPixel;
/*      */   private int redMask;
/*      */   private int greenMask;
/*      */   private int blueMask;
/*      */   private int alphaMask;
/*      */   private SampleModel sampleModel;
/*      */   private SampleModel originalSampleModel;
/*      */   private ColorModel colorModel;
/*      */   private ColorModel originalColorModel;
/*  177 */   private ImageInputStream iis = null;
/*      */ 
/*      */   
/*      */   private boolean gotHeader = false;
/*      */ 
/*      */   
/*      */   private long imageDataOffset;
/*      */ 
/*      */   
/*      */   private int width;
/*      */ 
/*      */   
/*      */   private int height;
/*      */ 
/*      */   
/*      */   private Rectangle destinationRegion;
/*      */ 
/*      */   
/*      */   private Rectangle sourceRegion;
/*      */ 
/*      */   
/*      */   private BMPMetadata metadata;
/*      */ 
/*      */   
/*      */   private BufferedImage bi;
/*      */ 
/*      */   
/*      */   private boolean noTransform = true;
/*      */ 
/*      */   
/*      */   private boolean seleBand = false;
/*      */ 
/*      */   
/*      */   private int scaleX;
/*      */ 
/*      */   
/*      */   private int scaleY;
/*      */   
/*      */   private int[] sourceBands;
/*      */   
/*      */   private int[] destBands;
/*      */ 
/*      */   
/*      */   public BMPImageReader(ImageReaderSpi originator) {
/*  221 */     super(originator);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setInput(Object input, boolean seekForwardOnly, boolean ignoreMetadata) {
/*  228 */     super.setInput(input, seekForwardOnly, ignoreMetadata);
/*  229 */     this.iis = (ImageInputStream)input;
/*  230 */     if (this.iis != null)
/*  231 */       this.iis.setByteOrder(ByteOrder.LITTLE_ENDIAN); 
/*  232 */     resetHeaderInfo();
/*      */   }
/*      */ 
/*      */   
/*      */   public int getNumImages(boolean allowSearch) throws IOException {
/*  237 */     if (this.iis == null) {
/*  238 */       throw new IllegalStateException(I18N.getString("GetNumImages0"));
/*      */     }
/*  240 */     if (this.seekForwardOnly && allowSearch) {
/*  241 */       throw new IllegalStateException(I18N.getString("GetNumImages1"));
/*      */     }
/*  243 */     return 1;
/*      */   }
/*      */   
/*      */   public int getWidth(int imageIndex) throws IOException {
/*  247 */     checkIndex(imageIndex);
/*  248 */     readHeader();
/*  249 */     return this.width;
/*      */   }
/*      */   
/*      */   public int getHeight(int imageIndex) throws IOException {
/*  253 */     checkIndex(imageIndex);
/*  254 */     readHeader();
/*  255 */     return this.height;
/*      */   }
/*      */   
/*      */   private void checkIndex(int imageIndex) {
/*  259 */     if (imageIndex != 0) {
/*  260 */       throw new IndexOutOfBoundsException(I18N.getString("BMPImageReader0"));
/*      */     }
/*      */   }
/*      */   
/*      */   public void readHeader() throws IOException {
/*  265 */     if (this.gotHeader) {
/*      */ 
/*      */       
/*  268 */       this.iis.seek(this.imageDataOffset);
/*      */       
/*      */       return;
/*      */     } 
/*  272 */     if (this.iis == null) {
/*  273 */       throw new IllegalStateException(I18N.getString("BMPImageReader5"));
/*      */     }
/*  275 */     int profileData = 0, profileSize = 0;
/*      */     
/*  277 */     this.metadata = new BMPMetadata();
/*  278 */     this.iis.mark();
/*      */ 
/*      */     
/*  281 */     byte[] marker = new byte[2];
/*  282 */     this.iis.read(marker);
/*  283 */     if (marker[0] != 66 || marker[1] != 77) {
/*  284 */       throw new IllegalArgumentException(I18N.getString("BMPImageReader1"));
/*      */     }
/*      */     
/*  287 */     this.bitmapFileSize = this.iis.readUnsignedInt();
/*      */     
/*  289 */     this.iis.skipBytes(4);
/*      */ 
/*      */     
/*  292 */     this.bitmapOffset = this.iis.readUnsignedInt();
/*      */ 
/*      */ 
/*      */     
/*  296 */     long size = this.iis.readUnsignedInt();
/*      */     
/*  298 */     if (size == 12L) {
/*  299 */       this.width = this.iis.readShort();
/*  300 */       this.height = this.iis.readShort();
/*      */     } else {
/*  302 */       this.width = this.iis.readInt();
/*  303 */       this.height = this.iis.readInt();
/*      */     } 
/*      */     
/*  306 */     this.metadata.width = this.width;
/*  307 */     this.metadata.height = this.height;
/*      */     
/*  309 */     int planes = this.iis.readUnsignedShort();
/*  310 */     this.bitsPerPixel = this.iis.readUnsignedShort();
/*      */ 
/*      */     
/*  313 */     this.metadata.bitsPerPixel = (short)this.bitsPerPixel;
/*      */ 
/*      */ 
/*      */     
/*  317 */     this.numBands = 3;
/*      */     
/*  319 */     if (size == 12L) {
/*      */       
/*  321 */       this.metadata.bmpVersion = "BMP v. 2.x";
/*      */ 
/*      */       
/*  324 */       if (this.bitsPerPixel == 1) {
/*  325 */         this.imageType = 0;
/*  326 */       } else if (this.bitsPerPixel == 4) {
/*  327 */         this.imageType = 1;
/*  328 */       } else if (this.bitsPerPixel == 8) {
/*  329 */         this.imageType = 2;
/*  330 */       } else if (this.bitsPerPixel == 24) {
/*  331 */         this.imageType = 3;
/*      */       } 
/*      */ 
/*      */       
/*  335 */       int numberOfEntries = (int)((this.bitmapOffset - 14L - size) / 3L);
/*  336 */       int sizeOfPalette = numberOfEntries * 3;
/*  337 */       this.palette = new byte[sizeOfPalette];
/*  338 */       this.iis.readFully(this.palette, 0, sizeOfPalette);
/*  339 */       this.metadata.palette = this.palette;
/*  340 */       this.metadata.paletteSize = numberOfEntries;
/*      */     } else {
/*  342 */       this.compression = this.iis.readUnsignedInt();
/*  343 */       this.imageSize = this.iis.readUnsignedInt();
/*  344 */       long xPelsPerMeter = this.iis.readInt();
/*  345 */       long yPelsPerMeter = this.iis.readInt();
/*  346 */       long colorsUsed = this.iis.readUnsignedInt();
/*  347 */       long colorsImportant = this.iis.readUnsignedInt();
/*      */       
/*  349 */       this.metadata.compression = (int)this.compression;
/*  350 */       this.metadata.imageSize = (int)this.imageSize;
/*  351 */       this.metadata.xPixelsPerMeter = (int)xPelsPerMeter;
/*  352 */       this.metadata.yPixelsPerMeter = (int)yPelsPerMeter;
/*  353 */       this.metadata.colorsUsed = (int)colorsUsed;
/*  354 */       this.metadata.colorsImportant = (int)colorsImportant;
/*      */       
/*  356 */       if (size == 40L) {
/*      */         int numberOfEntries; int sizeOfPalette;
/*  358 */         switch ((int)this.compression) {
/*      */           
/*      */           case 4:
/*      */           case 5:
/*  362 */             this.metadata.bmpVersion = "BMP v. 3.x";
/*  363 */             this.imageType = 16;
/*      */             break;
/*      */ 
/*      */ 
/*      */           
/*      */           case 0:
/*      */           case 1:
/*      */           case 2:
/*  371 */             numberOfEntries = (int)((this.bitmapOffset - 14L - size) / 4L);
/*  372 */             sizeOfPalette = numberOfEntries * 4;
/*  373 */             this.palette = new byte[sizeOfPalette];
/*  374 */             this.iis.readFully(this.palette, 0, sizeOfPalette);
/*      */             
/*  376 */             this.metadata.palette = this.palette;
/*  377 */             this.metadata.paletteSize = numberOfEntries;
/*      */             
/*  379 */             if (this.bitsPerPixel == 1) {
/*  380 */               this.imageType = 4;
/*  381 */             } else if (this.bitsPerPixel == 4) {
/*  382 */               this.imageType = 5;
/*  383 */             } else if (this.bitsPerPixel == 8) {
/*  384 */               this.imageType = 6;
/*  385 */             } else if (this.bitsPerPixel == 24) {
/*  386 */               this.imageType = 7;
/*  387 */             } else if (this.bitsPerPixel == 16) {
/*  388 */               this.imageType = 8;
/*      */               
/*  390 */               this.redMask = 31744;
/*  391 */               this.greenMask = 992;
/*  392 */               this.blueMask = 31;
/*  393 */               this.metadata.redMask = this.redMask;
/*  394 */               this.metadata.greenMask = this.greenMask;
/*  395 */               this.metadata.blueMask = this.blueMask;
/*  396 */             } else if (this.bitsPerPixel == 32) {
/*  397 */               this.imageType = 9;
/*  398 */               this.redMask = 16711680;
/*  399 */               this.greenMask = 65280;
/*  400 */               this.blueMask = 255;
/*  401 */               this.metadata.redMask = this.redMask;
/*  402 */               this.metadata.greenMask = this.greenMask;
/*  403 */               this.metadata.blueMask = this.blueMask;
/*      */             } 
/*      */             
/*  406 */             this.metadata.bmpVersion = "BMP v. 3.x";
/*      */             break;
/*      */ 
/*      */           
/*      */           case 3:
/*  411 */             if (this.bitsPerPixel == 16) {
/*  412 */               this.imageType = 8;
/*  413 */             } else if (this.bitsPerPixel == 32) {
/*  414 */               this.imageType = 9;
/*      */             } 
/*      */ 
/*      */             
/*  418 */             this.redMask = (int)this.iis.readUnsignedInt();
/*  419 */             this.greenMask = (int)this.iis.readUnsignedInt();
/*  420 */             this.blueMask = (int)this.iis.readUnsignedInt();
/*  421 */             this.metadata.redMask = this.redMask;
/*  422 */             this.metadata.greenMask = this.greenMask;
/*  423 */             this.metadata.blueMask = this.blueMask;
/*      */             
/*  425 */             if (colorsUsed != 0L) {
/*      */               
/*  427 */               sizeOfPalette = (int)colorsUsed * 4;
/*  428 */               this.palette = new byte[sizeOfPalette];
/*  429 */               this.iis.readFully(this.palette, 0, sizeOfPalette);
/*  430 */               this.metadata.palette = this.palette;
/*  431 */               this.metadata.paletteSize = (int)colorsUsed;
/*      */             } 
/*  433 */             this.metadata.bmpVersion = "BMP v. 3.x NT";
/*      */             break;
/*      */           
/*      */           default:
/*  437 */             throw new RuntimeException(I18N.getString("BMPImageReader2"));
/*      */         } 
/*      */       
/*  440 */       } else if (size == 108L || size == 124L) {
/*      */         
/*  442 */         if (size == 108L) {
/*  443 */           this.metadata.bmpVersion = "BMP v. 4.x";
/*  444 */         } else if (size == 124L) {
/*  445 */           this.metadata.bmpVersion = "BMP v. 5.x";
/*      */         } 
/*      */         
/*  448 */         this.redMask = (int)this.iis.readUnsignedInt();
/*  449 */         this.greenMask = (int)this.iis.readUnsignedInt();
/*  450 */         this.blueMask = (int)this.iis.readUnsignedInt();
/*      */         
/*  452 */         this.alphaMask = (int)this.iis.readUnsignedInt();
/*  453 */         long csType = this.iis.readUnsignedInt();
/*  454 */         int redX = this.iis.readInt();
/*  455 */         int redY = this.iis.readInt();
/*  456 */         int redZ = this.iis.readInt();
/*  457 */         int greenX = this.iis.readInt();
/*  458 */         int greenY = this.iis.readInt();
/*  459 */         int greenZ = this.iis.readInt();
/*  460 */         int blueX = this.iis.readInt();
/*  461 */         int blueY = this.iis.readInt();
/*  462 */         int blueZ = this.iis.readInt();
/*  463 */         long gammaRed = this.iis.readUnsignedInt();
/*  464 */         long gammaGreen = this.iis.readUnsignedInt();
/*  465 */         long gammaBlue = this.iis.readUnsignedInt();
/*      */         
/*  467 */         if (size == 124L) {
/*  468 */           this.metadata.intent = this.iis.readInt();
/*  469 */           profileData = this.iis.readInt();
/*  470 */           profileSize = this.iis.readInt();
/*  471 */           this.iis.skipBytes(4);
/*      */         } 
/*      */         
/*  474 */         this.metadata.colorSpace = (int)csType;
/*      */         
/*  476 */         if (csType == 0L) {
/*      */           
/*  478 */           this.metadata.redX = redX;
/*  479 */           this.metadata.redY = redY;
/*  480 */           this.metadata.redZ = redZ;
/*  481 */           this.metadata.greenX = greenX;
/*  482 */           this.metadata.greenY = greenY;
/*  483 */           this.metadata.greenZ = greenZ;
/*  484 */           this.metadata.blueX = blueX;
/*  485 */           this.metadata.blueY = blueY;
/*  486 */           this.metadata.blueZ = blueZ;
/*  487 */           this.metadata.gammaRed = (int)gammaRed;
/*  488 */           this.metadata.gammaGreen = (int)gammaGreen;
/*  489 */           this.metadata.gammaBlue = (int)gammaBlue;
/*      */         } 
/*      */ 
/*      */         
/*  493 */         int numberOfEntries = (int)((this.bitmapOffset - 14L - size) / 4L);
/*  494 */         int sizeOfPalette = numberOfEntries * 4;
/*  495 */         this.palette = new byte[sizeOfPalette];
/*  496 */         this.iis.readFully(this.palette, 0, sizeOfPalette);
/*  497 */         this.metadata.palette = this.palette;
/*  498 */         this.metadata.paletteSize = numberOfEntries;
/*      */         
/*  500 */         switch ((int)this.compression) {
/*      */           case 4:
/*      */           case 5:
/*  503 */             if (size == 108L) {
/*  504 */               this.imageType = 17; break;
/*  505 */             }  if (size == 124L) {
/*  506 */               this.imageType = 18;
/*      */             }
/*      */             break;
/*      */           default:
/*  510 */             if (this.bitsPerPixel == 1) {
/*  511 */               this.imageType = 10;
/*  512 */             } else if (this.bitsPerPixel == 4) {
/*  513 */               this.imageType = 11;
/*  514 */             } else if (this.bitsPerPixel == 8) {
/*  515 */               this.imageType = 12;
/*  516 */             } else if (this.bitsPerPixel == 16) {
/*  517 */               this.imageType = 13;
/*  518 */               if ((int)this.compression == 0) {
/*  519 */                 this.redMask = 31744;
/*  520 */                 this.greenMask = 992;
/*  521 */                 this.blueMask = 31;
/*      */               } 
/*  523 */             } else if (this.bitsPerPixel == 24) {
/*  524 */               this.imageType = 14;
/*  525 */             } else if (this.bitsPerPixel == 32) {
/*  526 */               this.imageType = 15;
/*  527 */               if ((int)this.compression == 0) {
/*  528 */                 this.redMask = 16711680;
/*  529 */                 this.greenMask = 65280;
/*  530 */                 this.blueMask = 255;
/*      */               } 
/*      */             } 
/*      */             
/*  534 */             this.metadata.redMask = this.redMask;
/*  535 */             this.metadata.greenMask = this.greenMask;
/*  536 */             this.metadata.blueMask = this.blueMask;
/*  537 */             this.metadata.alphaMask = this.alphaMask; break;
/*      */         } 
/*      */       } else {
/*  540 */         throw new RuntimeException(I18N.getString("BMPImageReader3"));
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  545 */     if (this.height > 0) {
/*      */       
/*  547 */       this.isBottomUp = true;
/*      */     } else {
/*      */       
/*  550 */       this.isBottomUp = false;
/*  551 */       this.height = Math.abs(this.height);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  556 */     ColorSpace colorSpace = ColorSpace.getInstance(1000);
/*  557 */     if (this.metadata.colorSpace == 3 || this.metadata.colorSpace == 4) {
/*      */ 
/*      */       
/*  560 */       this.iis.mark();
/*  561 */       this.iis.skipBytes(profileData - size);
/*  562 */       byte[] profile = new byte[profileSize];
/*  563 */       this.iis.readFully(profile, 0, profileSize);
/*  564 */       this.iis.reset();
/*      */       
/*      */       try {
/*  567 */         if (this.metadata.colorSpace == 3) {
/*  568 */           colorSpace = new ICC_ColorSpace(ICC_Profile.getInstance(new String(profile)));
/*      */         } else {
/*      */           
/*  571 */           colorSpace = new ICC_ColorSpace(ICC_Profile.getInstance(profile));
/*      */         } 
/*  573 */       } catch (Exception e) {
/*  574 */         colorSpace = ColorSpace.getInstance(1000);
/*      */       } 
/*      */     } 
/*      */     
/*  578 */     if (this.bitsPerPixel == 0 || this.compression == 4L || this.compression == 5L) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  583 */       this.colorModel = null;
/*  584 */       this.sampleModel = null;
/*  585 */     } else if (this.bitsPerPixel == 1 || this.bitsPerPixel == 4 || this.bitsPerPixel == 8) {
/*      */       byte[] r, g, b;
/*  587 */       this.numBands = 1;
/*      */       
/*  589 */       if (this.bitsPerPixel == 8) {
/*  590 */         int[] bandOffsets = new int[this.numBands];
/*  591 */         for (int i = 0; i < this.numBands; i++) {
/*  592 */           bandOffsets[i] = this.numBands - 1 - i;
/*      */         }
/*  594 */         this.sampleModel = new PixelInterleavedSampleModel(0, this.width, this.height, this.numBands, this.numBands * this.width, bandOffsets);
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */ 
/*      */         
/*  602 */         this.sampleModel = new MultiPixelPackedSampleModel(0, this.width, this.height, this.bitsPerPixel);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  610 */       if (this.imageType == 0 || this.imageType == 1 || this.imageType == 2) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  615 */         size = (this.palette.length / 3);
/*      */         
/*  617 */         if (size > 256L) {
/*  618 */           size = 256L;
/*      */         }
/*      */ 
/*      */         
/*  622 */         r = new byte[(int)size];
/*  623 */         g = new byte[(int)size];
/*  624 */         b = new byte[(int)size];
/*  625 */         for (int i = 0; i < (int)size; i++) {
/*  626 */           int off = 3 * i;
/*  627 */           b[i] = this.palette[off];
/*  628 */           g[i] = this.palette[off + 1];
/*  629 */           r[i] = this.palette[off + 2];
/*      */         } 
/*      */       } else {
/*  632 */         size = (this.palette.length / 4);
/*      */         
/*  634 */         if (size > 256L) {
/*  635 */           size = 256L;
/*      */         }
/*      */ 
/*      */         
/*  639 */         r = new byte[(int)size];
/*  640 */         g = new byte[(int)size];
/*  641 */         b = new byte[(int)size];
/*  642 */         for (int i = 0; i < size; i++) {
/*  643 */           int off = 4 * i;
/*  644 */           b[i] = this.palette[off];
/*  645 */           g[i] = this.palette[off + 1];
/*  646 */           r[i] = this.palette[off + 2];
/*      */         } 
/*      */       } 
/*      */       
/*  650 */       if (ImageUtil.isIndicesForGrayscale(r, g, b))
/*  651 */       { this.colorModel = ImageUtil.createColorModel(null, this.sampleModel); }
/*      */       else
/*      */       
/*  654 */       { this.colorModel = new IndexColorModel(this.bitsPerPixel, (int)size, r, g, b); } 
/*  655 */     } else if (this.bitsPerPixel == 16) {
/*  656 */       this.numBands = 3;
/*  657 */       this.sampleModel = new SinglePixelPackedSampleModel(1, this.width, this.height, new int[] { this.redMask, this.greenMask, this.blueMask });
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  662 */       this.colorModel = new DirectColorModel(colorSpace, 16, this.redMask, this.greenMask, this.blueMask, 0, false, 1);
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*  667 */     else if (this.bitsPerPixel == 32) {
/*  668 */       this.numBands = (this.alphaMask == 0) ? 3 : 4;
/*      */       
/*  670 */       if (this.redMask == 0 || this.greenMask == 0 || this.blueMask == 0) {
/*  671 */         this.redMask = 16711680;
/*  672 */         this.greenMask = 65280;
/*  673 */         this.blueMask = 255;
/*  674 */         this.alphaMask = -16777216;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  679 */       (new int[3])[0] = this.redMask; (new int[3])[1] = this.greenMask; (new int[3])[2] = this.blueMask; (new int[4])[0] = this.redMask; (new int[4])[1] = this.greenMask; (new int[4])[2] = this.blueMask; (new int[4])[3] = this.alphaMask; int[] bitMasks = (this.numBands == 3) ? new int[3] : new int[4];
/*      */ 
/*      */ 
/*      */       
/*  683 */       this.sampleModel = new SinglePixelPackedSampleModel(3, this.width, this.height, bitMasks);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  688 */       this.colorModel = new DirectColorModel(colorSpace, 32, this.redMask, this.greenMask, this.blueMask, this.alphaMask, false, 3);
/*      */     
/*      */     }
/*      */     else {
/*      */       
/*  693 */       this.numBands = 3;
/*      */       
/*  695 */       int[] bandOffsets = new int[this.numBands];
/*  696 */       for (int i = 0; i < this.numBands; i++) {
/*  697 */         bandOffsets[i] = this.numBands - 1 - i;
/*      */       }
/*      */       
/*  700 */       this.sampleModel = new PixelInterleavedSampleModel(0, this.width, this.height, this.numBands, this.numBands * this.width, bandOffsets);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  707 */       this.colorModel = ImageUtil.createColorModel(colorSpace, this.sampleModel);
/*      */     } 
/*      */ 
/*      */     
/*  711 */     this.originalSampleModel = this.sampleModel;
/*  712 */     this.originalColorModel = this.colorModel;
/*      */ 
/*      */ 
/*      */     
/*  716 */     this.iis.reset();
/*  717 */     this.iis.skipBytes(this.bitmapOffset);
/*  718 */     this.gotHeader = true;
/*      */ 
/*      */     
/*  721 */     this.imageDataOffset = this.iis.getStreamPosition();
/*      */   }
/*      */ 
/*      */   
/*      */   public Iterator getImageTypes(int imageIndex) throws IOException {
/*  726 */     checkIndex(imageIndex);
/*  727 */     readHeader();
/*  728 */     ArrayList<ImageTypeSpecifier> list = new ArrayList(1);
/*  729 */     list.add(new ImageTypeSpecifier(this.originalColorModel, this.originalSampleModel));
/*      */     
/*  731 */     return list.iterator();
/*      */   }
/*      */   
/*      */   public ImageReadParam getDefaultReadParam() {
/*  735 */     return new ImageReadParam();
/*      */   }
/*      */ 
/*      */   
/*      */   public IIOMetadata getImageMetadata(int imageIndex) throws IOException {
/*  740 */     checkIndex(imageIndex);
/*  741 */     if (this.metadata == null) {
/*  742 */       readHeader();
/*      */     }
/*  744 */     return this.metadata;
/*      */   }
/*      */   
/*      */   public IIOMetadata getStreamMetadata() throws IOException {
/*  748 */     return null;
/*      */   }
/*      */   
/*      */   public boolean isRandomAccessEasy(int imageIndex) throws IOException {
/*  752 */     checkIndex(imageIndex);
/*  753 */     readHeader();
/*  754 */     return (this.metadata.compression == 0);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public BufferedImage read(int imageIndex, ImageReadParam param) throws IOException {
/*  760 */     if (this.iis == null) {
/*  761 */       throw new IllegalStateException(I18N.getString("BMPImageReader5"));
/*      */     }
/*      */     
/*  764 */     checkIndex(imageIndex);
/*  765 */     clearAbortRequest();
/*  766 */     processImageStarted(imageIndex);
/*      */     
/*  768 */     if (param == null) {
/*  769 */       param = getDefaultReadParam();
/*      */     }
/*      */     
/*  772 */     readHeader();
/*      */     
/*  774 */     this.sourceRegion = new Rectangle(0, 0, 0, 0);
/*  775 */     this.destinationRegion = new Rectangle(0, 0, 0, 0);
/*      */     
/*  777 */     computeRegions(param, this.width, this.height, param.getDestination(), this.sourceRegion, this.destinationRegion);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  782 */     this.scaleX = param.getSourceXSubsampling();
/*  783 */     this.scaleY = param.getSourceYSubsampling();
/*      */ 
/*      */     
/*  786 */     this.sourceBands = param.getSourceBands();
/*  787 */     this.destBands = param.getDestinationBands();
/*      */     
/*  789 */     this.seleBand = (this.sourceBands != null && this.destBands != null);
/*  790 */     this.noTransform = (this.destinationRegion.equals(new Rectangle(0, 0, this.width, this.height)) || this.seleBand);
/*      */ 
/*      */ 
/*      */     
/*  794 */     if (!this.seleBand) {
/*  795 */       this.sourceBands = new int[this.numBands];
/*  796 */       this.destBands = new int[this.numBands];
/*  797 */       for (int i = 0; i < this.numBands; i++) {
/*  798 */         this.sourceBands[i] = i; this.destBands[i] = i;
/*      */       } 
/*      */     } 
/*      */     
/*  802 */     this.bi = param.getDestination();
/*      */ 
/*      */     
/*  805 */     WritableRaster raster = null;
/*      */     
/*  807 */     if (this.bi == null) {
/*  808 */       if (this.sampleModel != null && this.colorModel != null) {
/*  809 */         this.sampleModel = this.sampleModel.createCompatibleSampleModel(this.destinationRegion.x + this.destinationRegion.width, this.destinationRegion.y + this.destinationRegion.height);
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  814 */         if (this.seleBand)
/*  815 */           this.sampleModel = this.sampleModel.createSubsetSampleModel(this.sourceBands); 
/*  816 */         raster = Raster.createWritableRaster(this.sampleModel, new Point());
/*  817 */         this.bi = new BufferedImage(this.colorModel, raster, false, null);
/*      */       } 
/*      */     } else {
/*  820 */       raster = this.bi.getWritableTile(0, 0);
/*  821 */       this.sampleModel = this.bi.getSampleModel();
/*  822 */       this.colorModel = this.bi.getColorModel();
/*      */       
/*  824 */       this.noTransform &= this.destinationRegion.equals(raster.getBounds());
/*      */     } 
/*      */     
/*  827 */     byte[] bdata = null;
/*  828 */     short[] sdata = null;
/*  829 */     int[] idata = null;
/*      */ 
/*      */     
/*  832 */     if (this.sampleModel != null) {
/*  833 */       if (this.sampleModel.getDataType() == 0) {
/*  834 */         bdata = ((DataBufferByte)raster.getDataBuffer()).getData();
/*      */       }
/*  836 */       else if (this.sampleModel.getDataType() == 1) {
/*  837 */         sdata = ((DataBufferUShort)raster.getDataBuffer()).getData();
/*      */       }
/*  839 */       else if (this.sampleModel.getDataType() == 3) {
/*  840 */         idata = ((DataBufferInt)raster.getDataBuffer()).getData();
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*  845 */     switch (this.imageType) {
/*      */ 
/*      */       
/*      */       case 0:
/*  849 */         read1Bit(bdata);
/*      */         break;
/*      */ 
/*      */       
/*      */       case 1:
/*  854 */         read4Bit(bdata);
/*      */         break;
/*      */ 
/*      */       
/*      */       case 2:
/*  859 */         read8Bit(bdata);
/*      */         break;
/*      */ 
/*      */       
/*      */       case 3:
/*  864 */         read24Bit(bdata);
/*      */         break;
/*      */ 
/*      */       
/*      */       case 4:
/*  869 */         read1Bit(bdata);
/*      */         break;
/*      */       
/*      */       case 5:
/*  873 */         switch ((int)this.compression) {
/*      */           case 0:
/*  875 */             read4Bit(bdata);
/*      */             break;
/*      */           
/*      */           case 2:
/*  879 */             readRLE4(bdata);
/*      */             break;
/*      */         } 
/*      */         
/*  883 */         throw new RuntimeException(I18N.getString("BMPImageReader1"));
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 6:
/*  889 */         switch ((int)this.compression) {
/*      */           case 0:
/*  891 */             read8Bit(bdata);
/*      */             break;
/*      */           
/*      */           case 1:
/*  895 */             readRLE8(bdata);
/*      */             break;
/*      */         } 
/*      */         
/*  899 */         throw new RuntimeException(I18N.getString("BMPImageReader1"));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 7:
/*  907 */         read24Bit(bdata);
/*      */         break;
/*      */       
/*      */       case 8:
/*  911 */         read16Bit(sdata);
/*      */         break;
/*      */       
/*      */       case 9:
/*  915 */         read32Bit(idata);
/*      */         break;
/*      */       
/*      */       case 16:
/*      */       case 17:
/*      */       case 18:
/*  921 */         this.bi = readEmbedded((int)this.compression, this.bi, param);
/*      */         break;
/*      */       
/*      */       case 10:
/*  925 */         read1Bit(bdata);
/*      */         break;
/*      */       
/*      */       case 11:
/*  929 */         switch ((int)this.compression) {
/*      */           
/*      */           case 0:
/*  932 */             read4Bit(bdata);
/*      */             break;
/*      */           
/*      */           case 2:
/*  936 */             readRLE4(bdata);
/*      */             break;
/*      */           
/*      */           default:
/*  940 */             throw new RuntimeException(I18N.getString("BMPImageReader1"));
/*      */         } 
/*      */       
/*      */       
/*      */       case 12:
/*  945 */         switch ((int)this.compression) {
/*      */           
/*      */           case 0:
/*  948 */             read8Bit(bdata);
/*      */             break;
/*      */           
/*      */           case 1:
/*  952 */             readRLE8(bdata);
/*      */             break;
/*      */         } 
/*      */         
/*  956 */         throw new RuntimeException(I18N.getString("BMPImageReader1"));
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 13:
/*  962 */         read16Bit(sdata);
/*      */         break;
/*      */       
/*      */       case 14:
/*  966 */         read24Bit(bdata);
/*      */         break;
/*      */       
/*      */       case 15:
/*  970 */         read32Bit(idata);
/*      */         break;
/*      */     } 
/*      */     
/*  974 */     if (abortRequested()) {
/*  975 */       processReadAborted();
/*      */     } else {
/*  977 */       processImageComplete();
/*      */     } 
/*  979 */     return this.bi;
/*      */   }
/*      */   
/*      */   public boolean canReadRaster() {
/*  983 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public Raster readRaster(int imageIndex, ImageReadParam param) throws IOException {
/*  988 */     BufferedImage bi = read(imageIndex, param);
/*  989 */     return bi.getData();
/*      */   }
/*      */   
/*      */   private void resetHeaderInfo() {
/*  993 */     this.gotHeader = false;
/*  994 */     this.bi = null;
/*  995 */     this.sampleModel = this.originalSampleModel = null;
/*  996 */     this.colorModel = this.originalColorModel = null;
/*      */   }
/*      */   
/*      */   public void reset() {
/* 1000 */     super.reset();
/* 1001 */     this.iis = null;
/* 1002 */     resetHeaderInfo();
/*      */   }
/*      */ 
/*      */   
/*      */   private void read1Bit(byte[] bdata) throws IOException {
/* 1007 */     int bytesPerScanline = (this.width + 7) / 8;
/* 1008 */     int padding = bytesPerScanline % 4;
/* 1009 */     if (padding != 0) {
/* 1010 */       padding = 4 - padding;
/*      */     }
/*      */     
/* 1013 */     int lineLength = bytesPerScanline + padding;
/*      */     
/* 1015 */     if (this.noTransform) {
/* 1016 */       int j = this.isBottomUp ? ((this.height - 1) * bytesPerScanline) : 0;
/*      */       
/* 1018 */       for (int i = 0; i < this.height && 
/* 1019 */         !abortRequested(); i++) {
/*      */ 
/*      */         
/* 1022 */         this.iis.readFully(bdata, j, bytesPerScanline);
/* 1023 */         this.iis.skipBytes(padding);
/* 1024 */         j += this.isBottomUp ? -bytesPerScanline : bytesPerScanline;
/* 1025 */         processImageUpdate(this.bi, 0, i, this.destinationRegion.width, 1, 1, 1, new int[] { 0 });
/*      */ 
/*      */         
/* 1028 */         processImageProgress(100.0F * i / this.destinationRegion.height);
/*      */       } 
/*      */     } else {
/* 1031 */       byte[] buf = new byte[lineLength];
/* 1032 */       int lineStride = ((MultiPixelPackedSampleModel)this.sampleModel).getScanlineStride();
/*      */ 
/*      */       
/* 1035 */       if (this.isBottomUp) {
/* 1036 */         int lastLine = this.sourceRegion.y + (this.destinationRegion.height - 1) * this.scaleY;
/*      */         
/* 1038 */         this.iis.skipBytes(lineLength * (this.height - 1 - lastLine));
/*      */       } else {
/* 1040 */         this.iis.skipBytes(lineLength * this.sourceRegion.y);
/*      */       } 
/* 1042 */       int skipLength = lineLength * (this.scaleY - 1);
/*      */ 
/*      */       
/* 1045 */       int[] srcOff = new int[this.destinationRegion.width];
/* 1046 */       int[] destOff = new int[this.destinationRegion.width];
/* 1047 */       int[] srcPos = new int[this.destinationRegion.width];
/* 1048 */       int[] destPos = new int[this.destinationRegion.width];
/*      */       
/* 1050 */       int i = this.destinationRegion.x, x = this.sourceRegion.x, m = 0;
/* 1051 */       for (; i < this.destinationRegion.x + this.destinationRegion.width; 
/* 1052 */         i++, m++, x += this.scaleX) {
/* 1053 */         srcPos[m] = x >> 3;
/* 1054 */         srcOff[m] = 7 - (x & 0x7);
/* 1055 */         destPos[m] = i >> 3;
/* 1056 */         destOff[m] = 7 - (i & 0x7);
/*      */       } 
/*      */       
/* 1059 */       int k = this.destinationRegion.y * lineStride;
/* 1060 */       if (this.isBottomUp) {
/* 1061 */         k += (this.destinationRegion.height - 1) * lineStride;
/*      */       }
/* 1063 */       int j = 0, y = this.sourceRegion.y;
/* 1064 */       for (; j < this.destinationRegion.height; j++, y += this.scaleY) {
/*      */         
/* 1066 */         if (abortRequested())
/*      */           break; 
/* 1068 */         this.iis.read(buf, 0, lineLength);
/* 1069 */         for (int n = 0; n < this.destinationRegion.width; n++) {
/*      */           
/* 1071 */           int v = buf[srcPos[n]] >> srcOff[n] & 0x1;
/* 1072 */           bdata[k + destPos[n]] = (byte)(bdata[k + destPos[n]] | v << destOff[n]);
/*      */         } 
/*      */         
/* 1075 */         k += this.isBottomUp ? -lineStride : lineStride;
/* 1076 */         this.iis.skipBytes(skipLength);
/* 1077 */         processImageUpdate(this.bi, 0, j, this.destinationRegion.width, 1, 1, 1, new int[] { 0 });
/*      */ 
/*      */         
/* 1080 */         processImageProgress(100.0F * j / this.destinationRegion.height);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void read4Bit(byte[] bdata) throws IOException {
/* 1088 */     int bytesPerScanline = (this.width + 1) / 2;
/*      */ 
/*      */     
/* 1091 */     int padding = bytesPerScanline % 4;
/* 1092 */     if (padding != 0) {
/* 1093 */       padding = 4 - padding;
/*      */     }
/* 1095 */     int lineLength = bytesPerScanline + padding;
/*      */     
/* 1097 */     if (this.noTransform) {
/* 1098 */       int j = this.isBottomUp ? ((this.height - 1) * bytesPerScanline) : 0;
/*      */       
/* 1100 */       for (int i = 0; i < this.height && 
/* 1101 */         !abortRequested(); i++) {
/*      */ 
/*      */         
/* 1104 */         this.iis.readFully(bdata, j, bytesPerScanline);
/* 1105 */         this.iis.skipBytes(padding);
/* 1106 */         j += this.isBottomUp ? -bytesPerScanline : bytesPerScanline;
/* 1107 */         processImageUpdate(this.bi, 0, i, this.destinationRegion.width, 1, 1, 1, new int[] { 0 });
/*      */ 
/*      */         
/* 1110 */         processImageProgress(100.0F * i / this.destinationRegion.height);
/*      */       } 
/*      */     } else {
/* 1113 */       byte[] buf = new byte[lineLength];
/* 1114 */       int lineStride = ((MultiPixelPackedSampleModel)this.sampleModel).getScanlineStride();
/*      */ 
/*      */       
/* 1117 */       if (this.isBottomUp) {
/* 1118 */         int lastLine = this.sourceRegion.y + (this.destinationRegion.height - 1) * this.scaleY;
/*      */         
/* 1120 */         this.iis.skipBytes(lineLength * (this.height - 1 - lastLine));
/*      */       } else {
/* 1122 */         this.iis.skipBytes(lineLength * this.sourceRegion.y);
/*      */       } 
/* 1124 */       int skipLength = lineLength * (this.scaleY - 1);
/*      */ 
/*      */       
/* 1127 */       int[] srcOff = new int[this.destinationRegion.width];
/* 1128 */       int[] destOff = new int[this.destinationRegion.width];
/* 1129 */       int[] srcPos = new int[this.destinationRegion.width];
/* 1130 */       int[] destPos = new int[this.destinationRegion.width];
/*      */       
/* 1132 */       int i = this.destinationRegion.x, x = this.sourceRegion.x, m = 0;
/* 1133 */       for (; i < this.destinationRegion.x + this.destinationRegion.width; 
/* 1134 */         i++, m++, x += this.scaleX) {
/* 1135 */         srcPos[m] = x >> 1;
/* 1136 */         srcOff[m] = 1 - (x & 0x1) << 2;
/* 1137 */         destPos[m] = i >> 1;
/* 1138 */         destOff[m] = 1 - (i & 0x1) << 2;
/*      */       } 
/*      */       
/* 1141 */       int k = this.destinationRegion.y * lineStride;
/* 1142 */       if (this.isBottomUp) {
/* 1143 */         k += (this.destinationRegion.height - 1) * lineStride;
/*      */       }
/* 1145 */       int j = 0, y = this.sourceRegion.y;
/* 1146 */       for (; j < this.destinationRegion.height; j++, y += this.scaleY) {
/*      */         
/* 1148 */         if (abortRequested())
/*      */           break; 
/* 1150 */         this.iis.read(buf, 0, lineLength);
/* 1151 */         for (int n = 0; n < this.destinationRegion.width; n++) {
/*      */           
/* 1153 */           int v = buf[srcPos[n]] >> srcOff[n] & 0xF;
/* 1154 */           bdata[k + destPos[n]] = (byte)(bdata[k + destPos[n]] | v << destOff[n]);
/*      */         } 
/*      */         
/* 1157 */         k += this.isBottomUp ? -lineStride : lineStride;
/* 1158 */         this.iis.skipBytes(skipLength);
/* 1159 */         processImageUpdate(this.bi, 0, j, this.destinationRegion.width, 1, 1, 1, new int[] { 0 });
/*      */ 
/*      */         
/* 1162 */         processImageProgress(100.0F * j / this.destinationRegion.height);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void read8Bit(byte[] bdata) throws IOException {
/* 1171 */     int padding = this.width % 4;
/* 1172 */     if (padding != 0) {
/* 1173 */       padding = 4 - padding;
/*      */     }
/*      */     
/* 1176 */     int lineLength = this.width + padding;
/*      */     
/* 1178 */     if (this.noTransform) {
/* 1179 */       int j = this.isBottomUp ? ((this.height - 1) * this.width) : 0;
/*      */       
/* 1181 */       for (int i = 0; i < this.height && 
/* 1182 */         !abortRequested(); i++) {
/*      */ 
/*      */         
/* 1185 */         this.iis.readFully(bdata, j, this.width);
/* 1186 */         this.iis.skipBytes(padding);
/* 1187 */         j += this.isBottomUp ? -this.width : this.width;
/* 1188 */         processImageUpdate(this.bi, 0, i, this.destinationRegion.width, 1, 1, 1, new int[] { 0 });
/*      */ 
/*      */         
/* 1191 */         processImageProgress(100.0F * i / this.destinationRegion.height);
/*      */       } 
/*      */     } else {
/* 1194 */       byte[] buf = new byte[lineLength];
/* 1195 */       int lineStride = ((ComponentSampleModel)this.sampleModel).getScanlineStride();
/*      */ 
/*      */       
/* 1198 */       if (this.isBottomUp) {
/* 1199 */         int lastLine = this.sourceRegion.y + (this.destinationRegion.height - 1) * this.scaleY;
/*      */         
/* 1201 */         this.iis.skipBytes(lineLength * (this.height - 1 - lastLine));
/*      */       } else {
/* 1203 */         this.iis.skipBytes(lineLength * this.sourceRegion.y);
/*      */       } 
/* 1205 */       int skipLength = lineLength * (this.scaleY - 1);
/*      */       
/* 1207 */       int k = this.destinationRegion.y * lineStride;
/* 1208 */       if (this.isBottomUp)
/* 1209 */         k += (this.destinationRegion.height - 1) * lineStride; 
/* 1210 */       k += this.destinationRegion.x;
/*      */       
/* 1212 */       int j = 0, y = this.sourceRegion.y;
/* 1213 */       for (; j < this.destinationRegion.height; j++, y += this.scaleY) {
/*      */         
/* 1215 */         if (abortRequested())
/*      */           break; 
/* 1217 */         this.iis.read(buf, 0, lineLength);
/* 1218 */         int i = 0, m = this.sourceRegion.x;
/* 1219 */         for (; i < this.destinationRegion.width; i++, m += this.scaleX)
/*      */         {
/* 1221 */           bdata[k + i] = buf[m];
/*      */         }
/*      */         
/* 1224 */         k += this.isBottomUp ? -lineStride : lineStride;
/* 1225 */         this.iis.skipBytes(skipLength);
/* 1226 */         processImageUpdate(this.bi, 0, j, this.destinationRegion.width, 1, 1, 1, new int[] { 0 });
/*      */ 
/*      */         
/* 1229 */         processImageProgress(100.0F * j / this.destinationRegion.height);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void read24Bit(byte[] bdata) throws IOException {
/* 1238 */     int padding = this.width * 3 % 4;
/* 1239 */     if (padding != 0) {
/* 1240 */       padding = 4 - padding;
/*      */     }
/* 1242 */     int lineStride = this.width * 3;
/* 1243 */     int lineLength = lineStride + padding;
/*      */     
/* 1245 */     if (this.noTransform) {
/* 1246 */       int j = this.isBottomUp ? ((this.height - 1) * this.width * 3) : 0;
/*      */       
/* 1248 */       for (int i = 0; i < this.height && 
/* 1249 */         !abortRequested(); i++) {
/*      */ 
/*      */         
/* 1252 */         this.iis.readFully(bdata, j, lineStride);
/* 1253 */         this.iis.skipBytes(padding);
/* 1254 */         j += this.isBottomUp ? -lineStride : lineStride;
/* 1255 */         processImageUpdate(this.bi, 0, i, this.destinationRegion.width, 1, 1, 1, new int[] { 0 });
/*      */ 
/*      */         
/* 1258 */         processImageProgress(100.0F * i / this.destinationRegion.height);
/*      */       } 
/*      */     } else {
/* 1261 */       byte[] buf = new byte[lineLength];
/* 1262 */       lineStride = ((ComponentSampleModel)this.sampleModel).getScanlineStride();
/*      */ 
/*      */       
/* 1265 */       if (this.isBottomUp) {
/* 1266 */         int lastLine = this.sourceRegion.y + (this.destinationRegion.height - 1) * this.scaleY;
/*      */         
/* 1268 */         this.iis.skipBytes(lineLength * (this.height - 1 - lastLine));
/*      */       } else {
/* 1270 */         this.iis.skipBytes(lineLength * this.sourceRegion.y);
/*      */       } 
/* 1272 */       int skipLength = lineLength * (this.scaleY - 1);
/*      */       
/* 1274 */       int k = this.destinationRegion.y * lineStride;
/* 1275 */       if (this.isBottomUp)
/* 1276 */         k += (this.destinationRegion.height - 1) * lineStride; 
/* 1277 */       k += this.destinationRegion.x * 3;
/*      */       
/* 1279 */       int j = 0, y = this.sourceRegion.y;
/* 1280 */       for (; j < this.destinationRegion.height; j++, y += this.scaleY) {
/*      */         
/* 1282 */         if (abortRequested())
/*      */           break; 
/* 1284 */         this.iis.read(buf, 0, lineLength);
/* 1285 */         int i = 0, m = 3 * this.sourceRegion.x;
/* 1286 */         for (; i < this.destinationRegion.width; i++, m += 3 * this.scaleX) {
/*      */           
/* 1288 */           int n = 3 * i + k;
/* 1289 */           for (int b = 0; b < this.destBands.length; b++) {
/* 1290 */             bdata[n + this.destBands[b]] = buf[m + this.sourceBands[b]];
/*      */           }
/*      */         } 
/* 1293 */         k += this.isBottomUp ? -lineStride : lineStride;
/* 1294 */         this.iis.skipBytes(skipLength);
/* 1295 */         processImageUpdate(this.bi, 0, j, this.destinationRegion.width, 1, 1, 1, new int[] { 0 });
/*      */ 
/*      */         
/* 1298 */         processImageProgress(100.0F * j / this.destinationRegion.height);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void read16Bit(short[] sdata) throws IOException {
/* 1306 */     int padding = this.width * 2 % 4;
/*      */     
/* 1308 */     if (padding != 0) {
/* 1309 */       padding = 4 - padding;
/*      */     }
/* 1311 */     int lineLength = this.width + padding / 2;
/*      */     
/* 1313 */     if (this.noTransform) {
/* 1314 */       int j = this.isBottomUp ? ((this.height - 1) * this.width) : 0;
/* 1315 */       for (int i = 0; i < this.height && 
/* 1316 */         !abortRequested(); i++) {
/*      */ 
/*      */ 
/*      */         
/* 1320 */         this.iis.readFully(sdata, j, this.width);
/* 1321 */         this.iis.skipBytes(padding);
/* 1322 */         j += this.isBottomUp ? -this.width : this.width;
/* 1323 */         processImageUpdate(this.bi, 0, i, this.destinationRegion.width, 1, 1, 1, new int[] { 0 });
/*      */ 
/*      */         
/* 1326 */         processImageProgress(100.0F * i / this.destinationRegion.height);
/*      */       } 
/*      */     } else {
/* 1329 */       short[] buf = new short[lineLength];
/* 1330 */       int lineStride = ((SinglePixelPackedSampleModel)this.sampleModel).getScanlineStride();
/*      */ 
/*      */       
/* 1333 */       if (this.isBottomUp) {
/* 1334 */         int lastLine = this.sourceRegion.y + (this.destinationRegion.height - 1) * this.scaleY;
/*      */         
/* 1336 */         this.iis.skipBytes(lineLength * (this.height - 1 - lastLine) << 1);
/*      */       } else {
/* 1338 */         this.iis.skipBytes(lineLength * this.sourceRegion.y << 1);
/*      */       } 
/* 1340 */       int skipLength = lineLength * (this.scaleY - 1) << 1;
/*      */       
/* 1342 */       int k = this.destinationRegion.y * lineStride;
/* 1343 */       if (this.isBottomUp)
/* 1344 */         k += (this.destinationRegion.height - 1) * lineStride; 
/* 1345 */       k += this.destinationRegion.x;
/*      */       
/* 1347 */       int j = 0, y = this.sourceRegion.y;
/* 1348 */       for (; j < this.destinationRegion.height; j++, y += this.scaleY) {
/*      */         
/* 1350 */         if (abortRequested())
/*      */           break; 
/* 1352 */         this.iis.readFully(buf, 0, lineLength);
/* 1353 */         int i = 0, m = this.sourceRegion.x;
/* 1354 */         for (; i < this.destinationRegion.width; i++, m += this.scaleX)
/*      */         {
/* 1356 */           sdata[k + i] = buf[m];
/*      */         }
/*      */         
/* 1359 */         k += this.isBottomUp ? -lineStride : lineStride;
/* 1360 */         this.iis.skipBytes(skipLength);
/* 1361 */         processImageUpdate(this.bi, 0, j, this.destinationRegion.width, 1, 1, 1, new int[] { 0 });
/*      */ 
/*      */         
/* 1364 */         processImageProgress(100.0F * j / this.destinationRegion.height);
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private void read32Bit(int[] idata) throws IOException {
/* 1370 */     if (this.noTransform) {
/* 1371 */       int j = this.isBottomUp ? ((this.height - 1) * this.width) : 0;
/*      */       
/* 1373 */       for (int i = 0; i < this.height && 
/* 1374 */         !abortRequested(); i++) {
/*      */ 
/*      */         
/* 1377 */         this.iis.readFully(idata, j, this.width);
/* 1378 */         j += this.isBottomUp ? -this.width : this.width;
/* 1379 */         processImageUpdate(this.bi, 0, i, this.destinationRegion.width, 1, 1, 1, new int[] { 0 });
/*      */ 
/*      */         
/* 1382 */         processImageProgress(100.0F * i / this.destinationRegion.height);
/*      */       } 
/*      */     } else {
/* 1385 */       int[] buf = new int[this.width];
/* 1386 */       int lineStride = ((SinglePixelPackedSampleModel)this.sampleModel).getScanlineStride();
/*      */ 
/*      */       
/* 1389 */       if (this.isBottomUp) {
/* 1390 */         int lastLine = this.sourceRegion.y + (this.destinationRegion.height - 1) * this.scaleY;
/*      */         
/* 1392 */         this.iis.skipBytes(this.width * (this.height - 1 - lastLine) << 2);
/*      */       } else {
/* 1394 */         this.iis.skipBytes(this.width * this.sourceRegion.y << 2);
/*      */       } 
/* 1396 */       int skipLength = this.width * (this.scaleY - 1) << 2;
/*      */       
/* 1398 */       int k = this.destinationRegion.y * lineStride;
/* 1399 */       if (this.isBottomUp)
/* 1400 */         k += (this.destinationRegion.height - 1) * lineStride; 
/* 1401 */       k += this.destinationRegion.x;
/*      */       
/* 1403 */       int j = 0, y = this.sourceRegion.y;
/* 1404 */       for (; j < this.destinationRegion.height; j++, y += this.scaleY) {
/*      */         
/* 1406 */         if (abortRequested())
/*      */           break; 
/* 1408 */         this.iis.readFully(buf, 0, this.width);
/* 1409 */         int i = 0, m = this.sourceRegion.x;
/* 1410 */         for (; i < this.destinationRegion.width; i++, m += this.scaleX)
/*      */         {
/* 1412 */           idata[k + i] = buf[m];
/*      */         }
/*      */         
/* 1415 */         k += this.isBottomUp ? -lineStride : lineStride;
/* 1416 */         this.iis.skipBytes(skipLength);
/* 1417 */         processImageUpdate(this.bi, 0, j, this.destinationRegion.width, 1, 1, 1, new int[] { 0 });
/*      */ 
/*      */         
/* 1420 */         processImageProgress(100.0F * j / this.destinationRegion.height);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void readRLE8(byte[] bdata) throws IOException {
/* 1427 */     int imSize = (int)this.imageSize;
/* 1428 */     if (imSize == 0) {
/* 1429 */       imSize = (int)(this.bitmapFileSize - this.bitmapOffset);
/*      */     }
/*      */     
/* 1432 */     int padding = 0;
/*      */ 
/*      */     
/* 1435 */     int remainder = this.width % 4;
/* 1436 */     if (remainder != 0) {
/* 1437 */       padding = 4 - remainder;
/*      */     }
/*      */ 
/*      */     
/* 1441 */     byte[] values = new byte[imSize];
/* 1442 */     int bytesRead = 0;
/* 1443 */     this.iis.readFully(values, 0, imSize);
/*      */ 
/*      */     
/* 1446 */     decodeRLE8(imSize, padding, values, bdata);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void decodeRLE8(int imSize, int padding, byte[] values, byte[] bdata) throws IOException {
/* 1454 */     byte[] val = new byte[this.width * this.height];
/* 1455 */     int count = 0, l = 0;
/*      */     
/* 1457 */     boolean flag = false;
/* 1458 */     int lineNo = this.isBottomUp ? (this.height - 1) : 0;
/* 1459 */     int lineStride = ((ComponentSampleModel)this.sampleModel).getScanlineStride();
/*      */     
/* 1461 */     int finished = 0;
/*      */     
/* 1463 */     while (count != imSize) {
/* 1464 */       int value = values[count++] & 0xFF;
/* 1465 */       if (value == 0) {
/* 1466 */         int xoff; int yoff; int end; int i; switch (values[count++] & 0xFF) {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 0:
/*      */           case 1:
/* 1473 */             if (lineNo >= this.sourceRegion.y && lineNo < this.sourceRegion.y + this.sourceRegion.height)
/*      */             {
/* 1475 */               if (this.noTransform) {
/* 1476 */                 int pos = lineNo * this.width;
/* 1477 */                 for (int j = 0; j < this.width; j++)
/* 1478 */                   bdata[pos++] = val[j]; 
/* 1479 */                 processImageUpdate(this.bi, 0, lineNo, this.destinationRegion.width, 1, 1, 1, new int[] { 0 });
/*      */ 
/*      */                 
/* 1482 */                 finished++;
/* 1483 */               } else if ((lineNo - this.sourceRegion.y) % this.scaleY == 0) {
/* 1484 */                 int currentLine = (lineNo - this.sourceRegion.y) / this.scaleY + this.destinationRegion.y;
/*      */                 
/* 1486 */                 int pos = currentLine * lineStride;
/* 1487 */                 pos += this.destinationRegion.x;
/* 1488 */                 int j = this.sourceRegion.x;
/* 1489 */                 for (; j < this.sourceRegion.x + this.sourceRegion.width; 
/* 1490 */                   j += this.scaleX)
/* 1491 */                   bdata[pos++] = val[j]; 
/* 1492 */                 processImageUpdate(this.bi, 0, currentLine, this.destinationRegion.width, 1, 1, 1, new int[] { 0 });
/*      */ 
/*      */                 
/* 1495 */                 finished++;
/*      */               } 
/*      */             }
/* 1498 */             processImageProgress(100.0F * finished / this.destinationRegion.height);
/* 1499 */             lineNo += this.isBottomUp ? -1 : 1;
/* 1500 */             l = 0;
/*      */             
/* 1502 */             if (abortRequested()) {
/*      */               break;
/*      */             }
/*      */ 
/*      */             
/* 1507 */             if ((values[count - 1] & 0xFF) == 1) {
/* 1508 */               flag = true;
/*      */             }
/*      */             break;
/*      */ 
/*      */           
/*      */           case 2:
/* 1514 */             xoff = values[count++] & 0xFF;
/* 1515 */             yoff = values[count] & 0xFF;
/*      */             
/* 1517 */             l += xoff + yoff * this.width;
/*      */             break;
/*      */           
/*      */           default:
/* 1521 */             end = values[count - 1] & 0xFF;
/* 1522 */             for (i = 0; i < end; i++) {
/* 1523 */               val[l++] = (byte)(values[count++] & 0xFF);
/*      */             }
/*      */ 
/*      */ 
/*      */             
/* 1528 */             if ((end & 0x1) == 1)
/* 1529 */               count++; 
/*      */             break;
/*      */         } 
/*      */       } else {
/* 1533 */         for (int i = 0; i < value; i++) {
/* 1534 */           val[l++] = (byte)(values[count] & 0xFF);
/*      */         }
/*      */         
/* 1537 */         count++;
/*      */       } 
/*      */ 
/*      */       
/* 1541 */       if (flag) {
/*      */         break;
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void readRLE4(byte[] bdata) throws IOException {
/* 1550 */     int imSize = (int)this.imageSize;
/* 1551 */     if (imSize == 0) {
/* 1552 */       imSize = (int)(this.bitmapFileSize - this.bitmapOffset);
/*      */     }
/*      */     
/* 1555 */     int padding = 0;
/*      */ 
/*      */     
/* 1558 */     int remainder = this.width % 4;
/* 1559 */     if (remainder != 0) {
/* 1560 */       padding = 4 - remainder;
/*      */     }
/*      */ 
/*      */     
/* 1564 */     byte[] values = new byte[imSize];
/* 1565 */     this.iis.readFully(values, 0, imSize);
/*      */ 
/*      */     
/* 1568 */     decodeRLE4(imSize, padding, values, bdata);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void decodeRLE4(int imSize, int padding, byte[] values, byte[] bdata) throws IOException {
/* 1575 */     byte[] val = new byte[this.width];
/* 1576 */     int count = 0, l = 0;
/*      */     
/* 1578 */     boolean flag = false;
/* 1579 */     int lineNo = this.isBottomUp ? (this.height - 1) : 0;
/* 1580 */     int lineStride = ((MultiPixelPackedSampleModel)this.sampleModel).getScanlineStride();
/*      */     
/* 1582 */     int finished = 0;
/*      */     
/* 1584 */     while (count != imSize) {
/*      */       
/* 1586 */       int value = values[count++] & 0xFF;
/* 1587 */       if (value == 0) {
/*      */         int xoff; int yoff;
/*      */         int end;
/*      */         int i;
/* 1591 */         switch (values[count++] & 0xFF) {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 0:
/*      */           case 1:
/* 1598 */             if (lineNo >= this.sourceRegion.y && lineNo < this.sourceRegion.y + this.sourceRegion.height)
/*      */             {
/* 1600 */               if (this.noTransform) {
/* 1601 */                 int pos = lineNo * (this.width + 1 >> 1);
/* 1602 */                 for (int k = 0, j = 0; k < this.width >> 1; k++) {
/* 1603 */                   bdata[pos++] = (byte)(val[j++] << 4 | val[j++]);
/*      */                 }
/* 1605 */                 if ((this.width & 0x1) == 1) {
/* 1606 */                   bdata[pos] = (byte)(bdata[pos] | val[this.width - 1] << 4);
/*      */                 }
/* 1608 */                 processImageUpdate(this.bi, 0, lineNo, this.destinationRegion.width, 1, 1, 1, new int[] { 0 });
/*      */ 
/*      */                 
/* 1611 */                 finished++;
/* 1612 */               } else if ((lineNo - this.sourceRegion.y) % this.scaleY == 0) {
/* 1613 */                 int currentLine = (lineNo - this.sourceRegion.y) / this.scaleY + this.destinationRegion.y;
/*      */                 
/* 1615 */                 int pos = currentLine * lineStride;
/* 1616 */                 pos += this.destinationRegion.x >> 1;
/* 1617 */                 int shift = 1 - (this.destinationRegion.x & 0x1) << 2;
/* 1618 */                 int j = this.sourceRegion.x;
/* 1619 */                 for (; j < this.sourceRegion.x + this.sourceRegion.width; 
/* 1620 */                   j += this.scaleX) {
/* 1621 */                   bdata[pos] = (byte)(bdata[pos] | val[j] << shift);
/* 1622 */                   shift += 4;
/* 1623 */                   if (shift == 4) {
/* 1624 */                     pos++;
/*      */                   }
/* 1626 */                   shift &= 0x7;
/*      */                 } 
/* 1628 */                 processImageUpdate(this.bi, 0, currentLine, this.destinationRegion.width, 1, 1, 1, new int[] { 0 });
/*      */ 
/*      */                 
/* 1631 */                 finished++;
/*      */               } 
/*      */             }
/* 1634 */             processImageProgress(100.0F * finished / this.destinationRegion.height);
/* 1635 */             lineNo += this.isBottomUp ? -1 : 1;
/* 1636 */             l = 0;
/*      */             
/* 1638 */             if (abortRequested()) {
/*      */               break;
/*      */             }
/*      */ 
/*      */             
/* 1643 */             if ((values[count - 1] & 0xFF) == 1) {
/* 1644 */               flag = true;
/*      */             }
/*      */             break;
/*      */           
/*      */           case 2:
/* 1649 */             xoff = values[count++] & 0xFF;
/* 1650 */             yoff = values[count] & 0xFF;
/*      */             
/* 1652 */             l += xoff + yoff * this.width;
/*      */             break;
/*      */           
/*      */           default:
/* 1656 */             end = values[count - 1] & 0xFF;
/* 1657 */             for (i = 0; i < end; i++) {
/* 1658 */               val[l++] = (byte)(((i & 0x1) == 0) ? ((values[count] & 0xF0) >> 4) : (values[count++] & 0xF));
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1664 */             if ((end & 0x1) == 1) {
/* 1665 */               count++;
/*      */             }
/*      */ 
/*      */ 
/*      */             
/* 1670 */             if (((int)Math.ceil((end / 2)) & 0x1) == 1) {
/* 1671 */               count++;
/*      */             }
/*      */             break;
/*      */         } 
/*      */       
/*      */       } else {
/* 1677 */         int[] alternate = { (values[count] & 0xF0) >> 4, values[count] & 0xF };
/*      */         
/* 1679 */         for (int i = 0; i < value && l < this.width; i++) {
/* 1680 */           val[l++] = (byte)alternate[i & 0x1];
/*      */         }
/*      */         
/* 1683 */         count++;
/*      */       } 
/*      */ 
/*      */       
/* 1687 */       if (flag) {
/*      */         break;
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private BufferedImage readEmbedded(int type, BufferedImage bi, ImageReadParam bmpParam) throws IOException {
/*      */     String format;
/* 1706 */     switch (type) {
/*      */       case 4:
/* 1708 */         format = "JPEG";
/*      */         break;
/*      */       case 5:
/* 1711 */         format = "PNG";
/*      */         break;
/*      */       default:
/* 1714 */         throw new IOException("Unexpected compression type: " + type);
/*      */     } 
/*      */     
/* 1717 */     ImageReader reader = ImageIO.getImageReadersByFormatName(format).next();
/*      */     
/* 1719 */     if (reader == null) {
/* 1720 */       throw new RuntimeException(I18N.getString("BMPImageReader4") + " " + format);
/*      */     }
/*      */ 
/*      */     
/* 1724 */     byte[] buff = new byte[(int)this.imageSize];
/* 1725 */     this.iis.read(buff);
/* 1726 */     reader.setInput(ImageIO.createImageInputStream(new ByteArrayInputStream(buff)));
/* 1727 */     if (bi == null) {
/* 1728 */       ImageTypeSpecifier embType = reader.getImageTypes(0).next();
/* 1729 */       bi = embType.createBufferedImage(this.destinationRegion.x + this.destinationRegion.width, this.destinationRegion.y + this.destinationRegion.height);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1735 */     reader.addIIOReadProgressListener(new EmbeddedProgressAdapter()
/*      */         {
/*      */           public void imageProgress(ImageReader source, float percentageDone)
/*      */           {
/* 1739 */             BMPImageReader.this.processImageProgress(percentageDone);
/*      */           }
/*      */         });
/*      */     
/* 1743 */     reader.addIIOReadUpdateListener(new IIOReadUpdateListener()
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public void imageUpdate(ImageReader source, BufferedImage theImage, int minX, int minY, int width, int height, int periodX, int periodY, int[] bands)
/*      */           {
/* 1751 */             BMPImageReader.this.processImageUpdate(theImage, minX, minY, width, height, periodX, periodY, bands);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public void passComplete(ImageReader source, BufferedImage theImage) {
/* 1758 */             BMPImageReader.this.processPassComplete(theImage);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public void passStarted(ImageReader source, BufferedImage theImage, int pass, int minPass, int maxPass, int minX, int minY, int periodX, int periodY, int[] bands) {
/* 1768 */             BMPImageReader.this.processPassStarted(theImage, pass, minPass, maxPass, minX, minY, periodX, periodY, bands);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public void thumbnailPassComplete(ImageReader source, BufferedImage thumb) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public void thumbnailPassStarted(ImageReader source, BufferedImage thumb, int pass, int minPass, int maxPass, int minX, int minY, int periodX, int periodY, int[] bands) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public void thumbnailUpdate(ImageReader source, BufferedImage theThumbnail, int minX, int minY, int width, int height, int periodX, int periodY, int[] bands) {}
/*      */         });
/* 1789 */     reader.addIIOReadWarningListener(new IIOReadWarningListener()
/*      */         {
/*      */           public void warningOccurred(ImageReader source, String warning) {
/* 1792 */             BMPImageReader.this.processWarningOccurred(warning);
/*      */           }
/*      */         });
/*      */     
/* 1796 */     ImageReadParam param = reader.getDefaultReadParam();
/* 1797 */     param.setDestination(bi);
/* 1798 */     param.setDestinationBands(bmpParam.getDestinationBands());
/* 1799 */     param.setDestinationOffset(bmpParam.getDestinationOffset());
/* 1800 */     param.setSourceBands(bmpParam.getSourceBands());
/* 1801 */     param.setSourceRegion(bmpParam.getSourceRegion());
/* 1802 */     param.setSourceSubsampling(bmpParam.getSourceXSubsampling(), bmpParam.getSourceYSubsampling(), bmpParam.getSubsamplingXOffset(), bmpParam.getSubsamplingYOffset());
/*      */ 
/*      */ 
/*      */     
/* 1806 */     reader.read(0, param);
/* 1807 */     return bi;
/*      */   }
/*      */   
/*      */   private class EmbeddedProgressAdapter implements IIOReadProgressListener {
/*      */     private EmbeddedProgressAdapter() {}
/*      */     
/*      */     public void imageComplete(ImageReader src) {}
/*      */     
/*      */     public void imageProgress(ImageReader src, float percentageDone) {}
/*      */     
/*      */     public void imageStarted(ImageReader src, int imageIndex) {}
/*      */     
/*      */     public void thumbnailComplete(ImageReader src) {}
/*      */     
/*      */     public void thumbnailProgress(ImageReader src, float percentageDone) {}
/*      */     
/*      */     public void thumbnailStarted(ImageReader src, int iIdx, int tIdx) {}
/*      */     
/*      */     public void sequenceComplete(ImageReader src) {}
/*      */     
/*      */     public void sequenceStarted(ImageReader src, int minIndex) {}
/*      */     
/*      */     public void readAborted(ImageReader src) {}
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/bmp/BMPImageReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */