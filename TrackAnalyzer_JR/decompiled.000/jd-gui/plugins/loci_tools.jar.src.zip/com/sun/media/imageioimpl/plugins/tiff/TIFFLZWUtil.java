/*     */ package com.sun.media.imageioimpl.plugins.tiff;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.imageio.IIOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TIFFLZWUtil
/*     */ {
/*     */   private static final boolean debug = false;
/*     */   byte[] srcData;
/*     */   int srcIndex;
/*     */   byte[] dstData;
/* 101 */   int dstIndex = 0;
/*     */   byte[][] stringTable;
/*     */   int tableIndex;
/* 104 */   int bitsToGet = 9;
/*     */   int predictor;
/*     */   int samplesPerPixel;
/* 107 */   int nextData = 0;
/* 108 */   int nextBits = 0;
/*     */   
/* 110 */   private static final int[] andTable = new int[] { 511, 1023, 2047, 4095 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] decode(byte[] data, int predictor, int samplesPerPixel, int width, int height) throws IOException {
/* 119 */     if (data[0] == 0 && data[1] == 1) {
/* 120 */       throw new IIOException("TIFF 5.0-style LZW compression is not supported!");
/*     */     }
/*     */     
/* 123 */     this.srcData = data;
/* 124 */     this.srcIndex = 0;
/* 125 */     this.nextData = 0;
/* 126 */     this.nextBits = 0;
/*     */     
/* 128 */     this.dstData = new byte[8192];
/* 129 */     this.dstIndex = 0;
/*     */     
/* 131 */     initializeStringTable();
/*     */     
/* 133 */     int oldCode = 0;
/*     */     
/*     */     int code;
/* 136 */     while ((code = getNextCode()) != 257) {
/* 137 */       if (code == 256) {
/* 138 */         initializeStringTable();
/* 139 */         code = getNextCode();
/* 140 */         if (code == 257) {
/*     */           break;
/*     */         }
/*     */         
/* 144 */         writeString(this.stringTable[code]);
/* 145 */         oldCode = code; continue;
/*     */       } 
/* 147 */       if (code < this.tableIndex) {
/* 148 */         byte[] arrayOfByte = this.stringTable[code];
/*     */         
/* 150 */         writeString(arrayOfByte);
/* 151 */         addStringToTable(this.stringTable[oldCode], arrayOfByte[0]);
/* 152 */         oldCode = code; continue;
/*     */       } 
/* 154 */       byte[] string = this.stringTable[oldCode];
/* 155 */       string = composeString(string, string[0]);
/* 156 */       writeString(string);
/* 157 */       addStringToTable(string);
/* 158 */       oldCode = code;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 163 */     if (predictor == 2)
/*     */     {
/*     */       
/* 166 */       for (int j = 0; j < height; j++) {
/*     */         
/* 168 */         int count = samplesPerPixel * (j * width + 1);
/*     */         
/* 170 */         for (int i = samplesPerPixel; i < width * samplesPerPixel; i++) {
/*     */           
/* 172 */           this.dstData[count] = (byte)(this.dstData[count] + this.dstData[count - samplesPerPixel]);
/* 173 */           count++;
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/* 178 */     byte[] newDstData = new byte[this.dstIndex];
/* 179 */     System.arraycopy(this.dstData, 0, newDstData, 0, this.dstIndex);
/* 180 */     return newDstData;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initializeStringTable() {
/* 187 */     this.stringTable = new byte[4096][];
/*     */     
/* 189 */     for (int i = 0; i < 256; i++) {
/* 190 */       this.stringTable[i] = new byte[1];
/* 191 */       this.stringTable[i][0] = (byte)i;
/*     */     } 
/*     */     
/* 194 */     this.tableIndex = 258;
/* 195 */     this.bitsToGet = 9;
/*     */   }
/*     */   
/*     */   private void ensureCapacity(int bytesToAdd) {
/* 199 */     if (this.dstIndex + bytesToAdd > this.dstData.length) {
/* 200 */       byte[] newDstData = new byte[Math.max((int)(this.dstData.length * 1.2F), this.dstIndex + bytesToAdd)];
/*     */       
/* 202 */       System.arraycopy(this.dstData, 0, newDstData, 0, this.dstData.length);
/* 203 */       this.dstData = newDstData;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeString(byte[] string) {
/* 211 */     ensureCapacity(string.length);
/* 212 */     for (int i = 0; i < string.length; i++) {
/* 213 */       this.dstData[this.dstIndex++] = string[i];
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addStringToTable(byte[] oldString, byte newString) {
/* 221 */     int length = oldString.length;
/* 222 */     byte[] string = new byte[length + 1];
/* 223 */     System.arraycopy(oldString, 0, string, 0, length);
/* 224 */     string[length] = newString;
/*     */ 
/*     */     
/* 227 */     this.stringTable[this.tableIndex++] = string;
/*     */     
/* 229 */     if (this.tableIndex == 511) {
/* 230 */       this.bitsToGet = 10;
/* 231 */     } else if (this.tableIndex == 1023) {
/* 232 */       this.bitsToGet = 11;
/* 233 */     } else if (this.tableIndex == 2047) {
/* 234 */       this.bitsToGet = 12;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addStringToTable(byte[] string) {
/* 243 */     this.stringTable[this.tableIndex++] = string;
/*     */     
/* 245 */     if (this.tableIndex == 511) {
/* 246 */       this.bitsToGet = 10;
/* 247 */     } else if (this.tableIndex == 1023) {
/* 248 */       this.bitsToGet = 11;
/* 249 */     } else if (this.tableIndex == 2047) {
/* 250 */       this.bitsToGet = 12;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] composeString(byte[] oldString, byte newString) {
/* 258 */     int length = oldString.length;
/* 259 */     byte[] string = new byte[length + 1];
/* 260 */     System.arraycopy(oldString, 0, string, 0, length);
/* 261 */     string[length] = newString;
/*     */     
/* 263 */     return string;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNextCode() {
/*     */     try {
/* 274 */       this.nextData = this.nextData << 8 | this.srcData[this.srcIndex++] & 0xFF;
/* 275 */       this.nextBits += 8;
/*     */       
/* 277 */       if (this.nextBits < this.bitsToGet) {
/* 278 */         this.nextData = this.nextData << 8 | this.srcData[this.srcIndex++] & 0xFF;
/* 279 */         this.nextBits += 8;
/*     */       } 
/*     */       
/* 282 */       int code = this.nextData >> this.nextBits - this.bitsToGet & andTable[this.bitsToGet - 9];
/*     */       
/* 284 */       this.nextBits -= this.bitsToGet;
/*     */       
/* 286 */       return code;
/* 287 */     } catch (ArrayIndexOutOfBoundsException e) {
/*     */       
/* 289 */       return 257;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/tiff/TIFFLZWUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */