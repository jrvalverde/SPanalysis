/*     */ package com.sun.media.imageioimpl.plugins.gif;
/*     */ 
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import javax.imageio.metadata.IIOInvalidTreeException;
/*     */ import javax.imageio.metadata.IIOMetadataNode;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GIFImageMetadata
/*     */   extends GIFMetadata
/*     */ {
/*     */   static final String nativeMetadataFormatName = "javax_imageio_gif_image_1.0";
/* 105 */   static final String[] disposalMethodNames = new String[] { "none", "doNotDispose", "restoreToBackgroundColor", "restoreToPrevious", "undefinedDisposalMethod4", "undefinedDisposalMethod5", "undefinedDisposalMethod6", "undefinedDisposalMethod7" };
/*     */ 
/*     */   
/*     */   public int imageLeftPosition;
/*     */ 
/*     */   
/*     */   public int imageTopPosition;
/*     */ 
/*     */   
/*     */   public int imageWidth;
/*     */ 
/*     */   
/*     */   public int imageHeight;
/*     */   
/*     */   public boolean interlaceFlag = false;
/*     */   
/*     */   public boolean sortFlag = false;
/*     */   
/* 123 */   public byte[] localColorTable = null;
/*     */ 
/*     */   
/* 126 */   public int disposalMethod = 0;
/*     */   public boolean userInputFlag = false;
/*     */   public boolean transparentColorFlag = false;
/* 129 */   public int delayTime = 0;
/* 130 */   public int transparentColorIndex = 0;
/*     */   
/*     */   public boolean hasPlainTextExtension = false;
/*     */   
/*     */   public int textGridLeft;
/*     */   
/*     */   public int textGridTop;
/*     */   
/*     */   public int textGridWidth;
/*     */   
/*     */   public int textGridHeight;
/*     */   public int characterCellWidth;
/*     */   public int characterCellHeight;
/*     */   public int textForegroundColor;
/*     */   public int textBackgroundColor;
/*     */   public byte[] text;
/* 146 */   public List applicationIDs = null;
/*     */ 
/*     */   
/* 149 */   public List authenticationCodes = null;
/*     */ 
/*     */   
/* 152 */   public List applicationData = null;
/*     */ 
/*     */ 
/*     */   
/* 156 */   public List comments = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected GIFImageMetadata(boolean standardMetadataFormatSupported, String nativeMetadataFormatName, String nativeMetadataFormatClassName, String[] extraMetadataFormatNames, String[] extraMetadataFormatClassNames) {
/* 164 */     super(standardMetadataFormatSupported, nativeMetadataFormatName, nativeMetadataFormatClassName, extraMetadataFormatNames, extraMetadataFormatClassNames);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GIFImageMetadata() {
/* 172 */     this(true, "javax_imageio_gif_image_1.0", "com.sun.media.imageioimpl.plugins.gif.GIFImageMetadataFormat", null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isReadOnly() {
/* 179 */     return true;
/*     */   }
/*     */   
/*     */   public Node getAsTree(String formatName) {
/* 183 */     if (formatName.equals("javax_imageio_gif_image_1.0"))
/* 184 */       return getNativeTree(); 
/* 185 */     if (formatName.equals("javax_imageio_1.0"))
/*     */     {
/* 187 */       return getStandardTree();
/*     */     }
/* 189 */     throw new IllegalArgumentException("Not a recognized format!");
/*     */   }
/*     */ 
/*     */   
/*     */   private String toISO8859(byte[] data) {
/*     */     try {
/* 195 */       return new String(data, "ISO-8859-1");
/* 196 */     } catch (UnsupportedEncodingException e) {
/* 197 */       return "";
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private Node getNativeTree() {
/* 203 */     IIOMetadataNode root = new IIOMetadataNode("javax_imageio_gif_image_1.0");
/*     */ 
/*     */ 
/*     */     
/* 207 */     IIOMetadataNode node = new IIOMetadataNode("ImageDescriptor");
/* 208 */     node.setAttribute("imageLeftPosition", Integer.toString(this.imageLeftPosition));
/*     */     
/* 210 */     node.setAttribute("imageTopPosition", Integer.toString(this.imageTopPosition));
/*     */     
/* 212 */     node.setAttribute("imageWidth", Integer.toString(this.imageWidth));
/* 213 */     node.setAttribute("imageHeight", Integer.toString(this.imageHeight));
/* 214 */     node.setAttribute("interlaceFlag", this.interlaceFlag ? "true" : "false");
/*     */     
/* 216 */     root.appendChild(node);
/*     */ 
/*     */     
/* 219 */     if (this.localColorTable != null) {
/* 220 */       node = new IIOMetadataNode("LocalColorTable");
/* 221 */       int numEntries = this.localColorTable.length / 3;
/* 222 */       node.setAttribute("sizeOfLocalColorTable", Integer.toString(numEntries));
/*     */       
/* 224 */       node.setAttribute("sortFlag", this.sortFlag ? "TRUE" : "FALSE");
/*     */ 
/*     */       
/* 227 */       for (int i = 0; i < numEntries; i++) {
/* 228 */         IIOMetadataNode entry = new IIOMetadataNode("ColorTableEntry");
/*     */         
/* 230 */         entry.setAttribute("index", Integer.toString(i));
/* 231 */         int r = this.localColorTable[3 * i] & 0xFF;
/* 232 */         int g = this.localColorTable[3 * i + 1] & 0xFF;
/* 233 */         int b = this.localColorTable[3 * i + 2] & 0xFF;
/* 234 */         entry.setAttribute("red", Integer.toString(r));
/* 235 */         entry.setAttribute("green", Integer.toString(g));
/* 236 */         entry.setAttribute("blue", Integer.toString(b));
/* 237 */         node.appendChild(entry);
/*     */       } 
/* 239 */       root.appendChild(node);
/*     */     } 
/*     */ 
/*     */     
/* 243 */     node = new IIOMetadataNode("GraphicControlExtension");
/* 244 */     node.setAttribute("disposalMethod", disposalMethodNames[this.disposalMethod]);
/*     */     
/* 246 */     node.setAttribute("userInputFlag", this.userInputFlag ? "true" : "false");
/*     */     
/* 248 */     node.setAttribute("transparentColorFlag", this.transparentColorFlag ? "true" : "false");
/*     */     
/* 250 */     node.setAttribute("delayTime", Integer.toString(this.delayTime));
/*     */     
/* 252 */     node.setAttribute("transparentColorIndex", Integer.toString(this.transparentColorIndex));
/*     */     
/* 254 */     root.appendChild(node);
/*     */     
/* 256 */     if (this.hasPlainTextExtension) {
/* 257 */       node = new IIOMetadataNode("PlainTextExtension");
/* 258 */       node.setAttribute("textGridLeft", Integer.toString(this.textGridLeft));
/*     */       
/* 260 */       node.setAttribute("textGridTop", Integer.toString(this.textGridTop));
/*     */       
/* 262 */       node.setAttribute("textGridWidth", Integer.toString(this.textGridWidth));
/*     */       
/* 264 */       node.setAttribute("textGridHeight", Integer.toString(this.textGridHeight));
/*     */       
/* 266 */       node.setAttribute("characterCellWidth", Integer.toString(this.characterCellWidth));
/*     */       
/* 268 */       node.setAttribute("characterCellHeight", Integer.toString(this.characterCellHeight));
/*     */       
/* 270 */       node.setAttribute("textForegroundColor", Integer.toString(this.textForegroundColor));
/*     */       
/* 272 */       node.setAttribute("textBackgroundColor", Integer.toString(this.textBackgroundColor));
/*     */       
/* 274 */       node.setAttribute("text", toISO8859(this.text));
/*     */       
/* 276 */       root.appendChild(node);
/*     */     } 
/*     */ 
/*     */     
/* 280 */     int numAppExtensions = (this.applicationIDs == null) ? 0 : this.applicationIDs.size();
/*     */     
/* 282 */     if (numAppExtensions > 0) {
/* 283 */       node = new IIOMetadataNode("ApplicationExtensions");
/* 284 */       for (int i = 0; i < numAppExtensions; i++) {
/* 285 */         IIOMetadataNode appExtNode = new IIOMetadataNode("ApplicationExtension");
/*     */         
/* 287 */         byte[] applicationID = this.applicationIDs.get(i);
/* 288 */         appExtNode.setAttribute("applicationID", toISO8859(applicationID));
/*     */         
/* 290 */         byte[] authenticationCode = this.authenticationCodes.get(i);
/* 291 */         appExtNode.setAttribute("authenticationCode", toISO8859(authenticationCode));
/*     */         
/* 293 */         byte[] appData = this.applicationData.get(i);
/* 294 */         appExtNode.setUserObject(appData.clone());
/* 295 */         node.appendChild(appExtNode);
/*     */       } 
/*     */       
/* 298 */       root.appendChild(node);
/*     */     } 
/*     */ 
/*     */     
/* 302 */     int numComments = (this.comments == null) ? 0 : this.comments.size();
/* 303 */     if (numComments > 0) {
/* 304 */       node = new IIOMetadataNode("CommentExtensions");
/* 305 */       for (int i = 0; i < numComments; i++) {
/* 306 */         IIOMetadataNode commentNode = new IIOMetadataNode("CommentExtension");
/*     */         
/* 308 */         byte[] comment = this.comments.get(i);
/* 309 */         commentNode.setAttribute("value", toISO8859(comment));
/* 310 */         node.appendChild(commentNode);
/*     */       } 
/*     */       
/* 313 */       root.appendChild(node);
/*     */     } 
/*     */     
/* 316 */     return root;
/*     */   }
/*     */   
/*     */   public IIOMetadataNode getStandardChromaNode() {
/* 320 */     IIOMetadataNode chroma_node = new IIOMetadataNode("Chroma");
/* 321 */     IIOMetadataNode node = null;
/*     */     
/* 323 */     node = new IIOMetadataNode("ColorSpaceType");
/* 324 */     node.setAttribute("name", "RGB");
/* 325 */     chroma_node.appendChild(node);
/*     */     
/* 327 */     node = new IIOMetadataNode("NumChannels");
/* 328 */     node.setAttribute("value", this.transparentColorFlag ? "4" : "3");
/* 329 */     chroma_node.appendChild(node);
/*     */ 
/*     */ 
/*     */     
/* 333 */     node = new IIOMetadataNode("BlackIsZero");
/* 334 */     node.setAttribute("value", "TRUE");
/* 335 */     chroma_node.appendChild(node);
/*     */     
/* 337 */     if (this.localColorTable != null) {
/* 338 */       node = new IIOMetadataNode("Palette");
/* 339 */       int numEntries = this.localColorTable.length / 3;
/* 340 */       for (int i = 0; i < numEntries; i++) {
/* 341 */         IIOMetadataNode entry = new IIOMetadataNode("PaletteEntry");
/*     */         
/* 343 */         entry.setAttribute("index", Integer.toString(i));
/* 344 */         entry.setAttribute("red", Integer.toString(this.localColorTable[3 * i] & 0xFF));
/*     */         
/* 346 */         entry.setAttribute("green", Integer.toString(this.localColorTable[3 * i + 1] & 0xFF));
/*     */         
/* 348 */         entry.setAttribute("blue", Integer.toString(this.localColorTable[3 * i + 2] & 0xFF));
/*     */         
/* 350 */         node.appendChild(entry);
/*     */       } 
/* 352 */       chroma_node.appendChild(node);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 358 */     return chroma_node;
/*     */   }
/*     */   
/*     */   public IIOMetadataNode getStandardCompressionNode() {
/* 362 */     IIOMetadataNode compression_node = new IIOMetadataNode("Compression");
/* 363 */     IIOMetadataNode node = null;
/*     */     
/* 365 */     node = new IIOMetadataNode("CompressionTypeName");
/* 366 */     node.setAttribute("value", "lzw");
/* 367 */     compression_node.appendChild(node);
/*     */     
/* 369 */     node = new IIOMetadataNode("Lossless");
/* 370 */     node.setAttribute("value", "TRUE");
/* 371 */     compression_node.appendChild(node);
/*     */     
/* 373 */     node = new IIOMetadataNode("NumProgressiveScans");
/* 374 */     node.setAttribute("value", this.interlaceFlag ? "4" : "1");
/* 375 */     compression_node.appendChild(node);
/*     */ 
/*     */ 
/*     */     
/* 379 */     return compression_node;
/*     */   }
/*     */   
/*     */   public IIOMetadataNode getStandardDataNode() {
/* 383 */     IIOMetadataNode data_node = new IIOMetadataNode("Data");
/* 384 */     IIOMetadataNode node = null;
/*     */ 
/*     */ 
/*     */     
/* 388 */     node = new IIOMetadataNode("SampleFormat");
/* 389 */     node.setAttribute("value", "Index");
/* 390 */     data_node.appendChild(node);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 396 */     return data_node;
/*     */   }
/*     */   
/*     */   public IIOMetadataNode getStandardDimensionNode() {
/* 400 */     IIOMetadataNode dimension_node = new IIOMetadataNode("Dimension");
/* 401 */     IIOMetadataNode node = null;
/*     */ 
/*     */ 
/*     */     
/* 405 */     node = new IIOMetadataNode("ImageOrientation");
/* 406 */     node.setAttribute("value", "Normal");
/* 407 */     dimension_node.appendChild(node);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 416 */     node = new IIOMetadataNode("HorizontalPixelOffset");
/* 417 */     node.setAttribute("value", Integer.toString(this.imageLeftPosition));
/* 418 */     dimension_node.appendChild(node);
/*     */     
/* 420 */     node = new IIOMetadataNode("VerticalPixelOffset");
/* 421 */     node.setAttribute("value", Integer.toString(this.imageTopPosition));
/* 422 */     dimension_node.appendChild(node);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 427 */     return dimension_node;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IIOMetadataNode getStandardTextNode() {
/* 433 */     if (this.comments == null) {
/* 434 */       return null;
/*     */     }
/* 436 */     Iterator<byte[]> commentIter = this.comments.iterator();
/* 437 */     if (!commentIter.hasNext()) {
/* 438 */       return null;
/*     */     }
/*     */     
/* 441 */     IIOMetadataNode text_node = new IIOMetadataNode("Text");
/* 442 */     IIOMetadataNode node = null;
/*     */     
/* 444 */     while (commentIter.hasNext()) {
/* 445 */       byte[] comment = commentIter.next();
/* 446 */       String s = null;
/*     */       try {
/* 448 */         s = new String(comment, "ISO-8859-1");
/* 449 */       } catch (UnsupportedEncodingException e) {
/* 450 */         throw new RuntimeException("Encoding ISO-8859-1 unknown!");
/*     */       } 
/*     */       
/* 453 */       node = new IIOMetadataNode("TextEntry");
/* 454 */       node.setAttribute("value", s);
/* 455 */       node.setAttribute("encoding", "ISO-8859-1");
/* 456 */       node.setAttribute("compression", "none");
/* 457 */       text_node.appendChild(node);
/*     */     } 
/*     */     
/* 460 */     return text_node;
/*     */   }
/*     */   
/*     */   public IIOMetadataNode getStandardTransparencyNode() {
/* 464 */     if (!this.transparentColorFlag) {
/* 465 */       return null;
/*     */     }
/*     */     
/* 468 */     IIOMetadataNode transparency_node = new IIOMetadataNode("Transparency");
/*     */     
/* 470 */     IIOMetadataNode node = null;
/*     */ 
/*     */ 
/*     */     
/* 474 */     node = new IIOMetadataNode("TransparentIndex");
/* 475 */     node.setAttribute("value", Integer.toString(this.transparentColorIndex));
/*     */     
/* 477 */     transparency_node.appendChild(node);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 483 */     return transparency_node;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFromTree(String formatName, Node root) throws IIOInvalidTreeException {
/* 489 */     throw new IllegalStateException("Metadata is read-only!");
/*     */   }
/*     */ 
/*     */   
/*     */   protected void mergeNativeTree(Node root) throws IIOInvalidTreeException {
/* 494 */     throw new IllegalStateException("Metadata is read-only!");
/*     */   }
/*     */ 
/*     */   
/*     */   protected void mergeStandardTree(Node root) throws IIOInvalidTreeException {
/* 499 */     throw new IllegalStateException("Metadata is read-only!");
/*     */   }
/*     */   
/*     */   public void reset() {
/* 503 */     throw new IllegalStateException("Metadata is read-only!");
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/gif/GIFImageMetadata.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */