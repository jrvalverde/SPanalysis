/*     */ package com.sun.media.imageioimpl.plugins.tiff;
/*     */ 
/*     */ import com.sun.media.imageio.plugins.tiff.TIFFDecompressor;
/*     */ import java.io.IOException;
/*     */ import javax.imageio.IIOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TIFFLZWDecompressor
/*     */   extends TIFFDecompressor
/*     */ {
/*     */   private static final boolean DEBUG = false;
/*  95 */   private static final int[] andTable = new int[] { 511, 1023, 2047, 4095 };
/*     */   
/*     */   int predictor;
/*     */   
/*     */   byte[] srcData;
/*     */   
/*     */   byte[] dstData;
/*     */   
/*     */   int srcIndex;
/*     */   
/*     */   int dstIndex;
/*     */   
/*     */   byte[][] stringTable;
/*     */   
/*     */   int tableIndex;
/*     */   
/* 111 */   int bitsToGet = 9;
/*     */   
/* 113 */   int nextData = 0;
/* 114 */   int nextBits = 0;
/*     */ 
/*     */ 
/*     */   
/*     */   public TIFFLZWDecompressor(int predictor) throws IIOException {
/* 119 */     if (predictor != 1 && predictor != 2)
/*     */     {
/*     */       
/* 122 */       throw new IIOException("Illegal value for Predictor in TIFF file");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 130 */     this.predictor = predictor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void decodeRaw(byte[] b, int dstOffset, int bitsPerPixel, int scanlineStride) throws IOException {
/*     */     byte[] buf;
/*     */     int bufOffset;
/* 139 */     if (this.predictor == 2) {
/*     */       
/* 141 */       int len = this.bitsPerSample.length;
/* 142 */       for (int i = 0; i < len; i++) {
/* 143 */         if (this.bitsPerSample[i] != 8) {
/* 144 */           throw new IIOException(this.bitsPerSample[i] + "-bit samples " + "are not supported for Horizontal " + "differencing Predictor");
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 152 */     this.stream.seek(this.offset);
/*     */     
/* 154 */     byte[] sdata = new byte[this.byteCount];
/* 155 */     this.stream.readFully(sdata);
/*     */     
/* 157 */     int bytesPerRow = (this.srcWidth * bitsPerPixel + 7) / 8;
/*     */ 
/*     */     
/* 160 */     if (bytesPerRow == scanlineStride) {
/* 161 */       buf = b;
/* 162 */       bufOffset = dstOffset;
/*     */     } else {
/* 164 */       buf = new byte[bytesPerRow * this.srcHeight];
/* 165 */       bufOffset = 0;
/*     */     } 
/*     */     
/* 168 */     int numBytesDecoded = decode(sdata, 0, buf, bufOffset);
/*     */     
/* 170 */     if (bytesPerRow != scanlineStride) {
/*     */ 
/*     */ 
/*     */       
/* 174 */       int off = 0;
/* 175 */       for (int y = 0; y < this.srcHeight; y++) {
/* 176 */         System.arraycopy(buf, off, b, dstOffset, bytesPerRow);
/* 177 */         off += bytesPerRow;
/* 178 */         dstOffset += scanlineStride;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int decode(byte[] sdata, int srcOffset, byte[] ddata, int dstOffset) throws IOException {
/* 186 */     if (sdata[0] == 0 && sdata[1] == 1) {
/* 187 */       throw new IIOException("TIFF 5.0-style LZW compression is not supported!");
/*     */     }
/*     */ 
/*     */     
/* 191 */     this.srcData = sdata;
/* 192 */     this.dstData = ddata;
/*     */     
/* 194 */     this.srcIndex = srcOffset;
/* 195 */     this.dstIndex = dstOffset;
/*     */     
/* 197 */     this.nextData = 0;
/* 198 */     this.nextBits = 0;
/*     */     
/* 200 */     initializeStringTable();
/*     */     
/* 202 */     int oldCode = 0;
/*     */     
/*     */     int code;
/* 205 */     while ((code = getNextCode()) != 257) {
/* 206 */       if (code == 256) {
/* 207 */         initializeStringTable();
/* 208 */         code = getNextCode();
/* 209 */         if (code == 257) {
/*     */           break;
/*     */         }
/*     */         
/* 213 */         writeString(this.stringTable[code]);
/* 214 */         oldCode = code; continue;
/*     */       } 
/* 216 */       if (code < this.tableIndex) {
/* 217 */         byte[] arrayOfByte = this.stringTable[code];
/*     */         
/* 219 */         writeString(arrayOfByte);
/* 220 */         addStringToTable(this.stringTable[oldCode], arrayOfByte[0]);
/* 221 */         oldCode = code; continue;
/*     */       } 
/* 223 */       byte[] string = this.stringTable[oldCode];
/* 224 */       string = composeString(string, string[0]);
/* 225 */       writeString(string);
/* 226 */       addStringToTable(string);
/* 227 */       oldCode = code;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 232 */     if (this.predictor == 2)
/*     */     {
/*     */       
/* 235 */       for (int j = 0; j < this.srcHeight; j++) {
/*     */         
/* 237 */         int count = dstOffset + this.samplesPerPixel * (j * this.srcWidth + 1);
/*     */         
/* 239 */         for (int i = this.samplesPerPixel; i < this.srcWidth * this.samplesPerPixel; i++) {
/*     */           
/* 241 */           this.dstData[count] = (byte)(this.dstData[count] + this.dstData[count - this.samplesPerPixel]);
/* 242 */           count++;
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/* 247 */     return this.dstIndex - dstOffset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initializeStringTable() {
/* 254 */     this.stringTable = new byte[4096][];
/*     */     
/* 256 */     for (int i = 0; i < 256; i++) {
/* 257 */       this.stringTable[i] = new byte[1];
/* 258 */       this.stringTable[i][0] = (byte)i;
/*     */     } 
/*     */     
/* 261 */     this.tableIndex = 258;
/* 262 */     this.bitsToGet = 9;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeString(byte[] string) {
/* 269 */     if (this.dstIndex < this.dstData.length) {
/* 270 */       int maxIndex = Math.min(string.length, this.dstData.length - this.dstIndex);
/*     */ 
/*     */       
/* 273 */       for (int i = 0; i < maxIndex; i++) {
/* 274 */         this.dstData[this.dstIndex++] = string[i];
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addStringToTable(byte[] oldString, byte newString) {
/* 283 */     int length = oldString.length;
/* 284 */     byte[] string = new byte[length + 1];
/* 285 */     System.arraycopy(oldString, 0, string, 0, length);
/* 286 */     string[length] = newString;
/*     */ 
/*     */     
/* 289 */     this.stringTable[this.tableIndex++] = string;
/*     */     
/* 291 */     if (this.tableIndex == 511) {
/* 292 */       this.bitsToGet = 10;
/* 293 */     } else if (this.tableIndex == 1023) {
/* 294 */       this.bitsToGet = 11;
/* 295 */     } else if (this.tableIndex == 2047) {
/* 296 */       this.bitsToGet = 12;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addStringToTable(byte[] string) {
/* 305 */     this.stringTable[this.tableIndex++] = string;
/*     */     
/* 307 */     if (this.tableIndex == 511) {
/* 308 */       this.bitsToGet = 10;
/* 309 */     } else if (this.tableIndex == 1023) {
/* 310 */       this.bitsToGet = 11;
/* 311 */     } else if (this.tableIndex == 2047) {
/* 312 */       this.bitsToGet = 12;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] composeString(byte[] oldString, byte newString) {
/* 320 */     int length = oldString.length;
/* 321 */     byte[] string = new byte[length + 1];
/* 322 */     System.arraycopy(oldString, 0, string, 0, length);
/* 323 */     string[length] = newString;
/*     */     
/* 325 */     return string;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNextCode() {
/*     */     try {
/* 336 */       this.nextData = this.nextData << 8 | this.srcData[this.srcIndex++] & 0xFF;
/* 337 */       this.nextBits += 8;
/*     */       
/* 339 */       if (this.nextBits < this.bitsToGet) {
/* 340 */         this.nextData = this.nextData << 8 | this.srcData[this.srcIndex++] & 0xFF;
/* 341 */         this.nextBits += 8;
/*     */       } 
/*     */       
/* 344 */       int code = this.nextData >> this.nextBits - this.bitsToGet & andTable[this.bitsToGet - 9];
/*     */       
/* 346 */       this.nextBits -= this.bitsToGet;
/*     */       
/* 348 */       return code;
/* 349 */     } catch (ArrayIndexOutOfBoundsException e) {
/*     */       
/* 351 */       return 257;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/tiff/TIFFLZWDecompressor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */