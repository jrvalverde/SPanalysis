/*     */ package com.sun.media.imageioimpl.plugins.jpeg2000;
/*     */ 
/*     */ import java.awt.color.ICC_Profile;
/*     */ import javax.imageio.metadata.IIOInvalidTreeException;
/*     */ import javax.imageio.metadata.IIOMetadataNode;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ColorSpecificationBox
/*     */   extends Box
/*     */ {
/*     */   public static final int ECS_sRGB = 16;
/*     */   public static final int ECS_GRAY = 17;
/*     */   public static final int ECS_YCC = 18;
/* 102 */   private static String[] elementNames = new String[] { "Method", "Precedence", "ApproximationAccuracy", "EnumeratedColorSpace", "ICCProfile" };
/*     */   
/*     */   private byte method;
/*     */   private byte precedence;
/*     */   private byte approximation;
/*     */   private int ecs;
/*     */   private ICC_Profile profile;
/*     */   
/*     */   public static String[] getElementNames() {
/* 111 */     return elementNames;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int computeLength(byte m, ICC_Profile profile) {
/* 123 */     int ret = 15;
/* 124 */     if (m == 2 && profile != null) {
/* 125 */       ret += (profile.getData()).length;
/*     */     }
/* 127 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ColorSpecificationBox(byte m, byte p, byte a, int ecs, ICC_Profile profile) {
/* 135 */     super(computeLength(m, profile), 1668246642, null);
/* 136 */     this.method = m;
/* 137 */     this.precedence = p;
/* 138 */     this.approximation = a;
/* 139 */     this.ecs = ecs;
/* 140 */     this.profile = profile;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ColorSpecificationBox(byte[] data) {
/* 147 */     super(8 + data.length, 1668246642, data);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ColorSpecificationBox(Node node) throws IIOInvalidTreeException {
/* 154 */     super(node);
/* 155 */     NodeList children = node.getChildNodes();
/*     */     
/* 157 */     for (int i = 0; i < children.getLength(); i++) {
/* 158 */       Node child = children.item(i);
/* 159 */       String name = child.getNodeName();
/*     */       
/* 161 */       if ("Method".equals(name)) {
/* 162 */         this.method = Box.getByteElementValue(child);
/*     */       }
/*     */       
/* 165 */       if ("Precedence".equals(name)) {
/* 166 */         this.precedence = Box.getByteElementValue(child);
/*     */       }
/*     */       
/* 169 */       if ("ApproximationAccuracy".equals(name)) {
/* 170 */         this.approximation = Box.getByteElementValue(child);
/*     */       }
/*     */       
/* 173 */       if ("EnumeratedColorSpace".equals(name)) {
/* 174 */         this.ecs = Box.getIntElementValue(child);
/*     */       }
/*     */       
/* 177 */       if ("ICCProfile".equals(name)) {
/* 178 */         if (child instanceof IIOMetadataNode) {
/* 179 */           this.profile = (ICC_Profile)((IIOMetadataNode)child).getUserObject();
/*     */         } else {
/*     */           
/* 182 */           String value = node.getNodeValue();
/* 183 */           if (value != null) {
/* 184 */             this.profile = ICC_Profile.getInstance(Box.parseByteArray(value));
/*     */           }
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public byte getMethod() {
/* 192 */     return this.method;
/*     */   }
/*     */ 
/*     */   
/*     */   public byte getPrecedence() {
/* 197 */     return this.precedence;
/*     */   }
/*     */ 
/*     */   
/*     */   public byte getApproximationAccuracy() {
/* 202 */     return this.approximation;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getEnumeratedColorSpace() {
/* 207 */     return this.ecs;
/*     */   }
/*     */ 
/*     */   
/*     */   public ICC_Profile getICCProfile() {
/* 212 */     return this.profile;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IIOMetadataNode getNativeNode() {
/* 220 */     return getNativeNodeForSimpleBox();
/*     */   }
/*     */   
/*     */   protected void parse(byte[] data) {
/* 224 */     this.method = data[0];
/* 225 */     this.precedence = data[1];
/* 226 */     this.approximation = data[2];
/* 227 */     if (this.method == 2) {
/* 228 */       byte[] proData = new byte[data.length - 3];
/* 229 */       System.arraycopy(data, 3, proData, 0, data.length - 3);
/* 230 */       this.profile = ICC_Profile.getInstance(proData);
/*     */     } else {
/* 232 */       this.ecs = (data[3] & 0xFF) << 24 | (data[4] & 0xFF) << 16 | (data[5] & 0xFF) << 8 | data[6] & 0xFF;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void compose() {
/* 238 */     if (this.data != null)
/*     */       return; 
/* 240 */     int len = 7;
/* 241 */     byte[] profileData = null;
/* 242 */     if (this.profile != null) {
/* 243 */       profileData = this.profile.getData();
/* 244 */       len += profileData.length;
/*     */     } 
/*     */     
/* 247 */     this.data = new byte[len];
/*     */     
/* 249 */     this.data[0] = this.method;
/* 250 */     this.data[1] = this.precedence;
/* 251 */     this.data[2] = this.approximation;
/*     */     
/* 253 */     copyInt(this.data, 3, this.ecs);
/*     */     
/* 255 */     if (this.profile != null)
/* 256 */       System.arraycopy(profileData, 0, this.data, 7, len - 7); 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/jpeg2000/ColorSpecificationBox.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */