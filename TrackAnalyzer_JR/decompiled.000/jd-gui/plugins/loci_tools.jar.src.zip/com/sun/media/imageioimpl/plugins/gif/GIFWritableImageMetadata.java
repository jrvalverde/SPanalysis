/*     */ package com.sun.media.imageioimpl.plugins.gif;
/*     */ 
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.ArrayList;
/*     */ import javax.imageio.metadata.IIOInvalidTreeException;
/*     */ import javax.imageio.metadata.IIOMetadataNode;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class GIFWritableImageMetadata
/*     */   extends GIFImageMetadata
/*     */ {
/*     */   static final String NATIVE_FORMAT_NAME = "javax_imageio_gif_image_1.0";
/*     */   
/*     */   GIFWritableImageMetadata() {
/* 104 */     super(true, "javax_imageio_gif_image_1.0", "com.sun.media.imageioimpl.plugins.gif.GIFImageMetadataFormat", (String[])null, (String[])null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isReadOnly() {
/* 111 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void reset() {
/* 116 */     this.imageLeftPosition = 0;
/* 117 */     this.imageTopPosition = 0;
/* 118 */     this.imageWidth = 0;
/* 119 */     this.imageHeight = 0;
/* 120 */     this.interlaceFlag = false;
/* 121 */     this.sortFlag = false;
/* 122 */     this.localColorTable = null;
/*     */ 
/*     */     
/* 125 */     this.disposalMethod = 0;
/* 126 */     this.userInputFlag = false;
/* 127 */     this.transparentColorFlag = false;
/* 128 */     this.delayTime = 0;
/* 129 */     this.transparentColorIndex = 0;
/*     */ 
/*     */     
/* 132 */     this.hasPlainTextExtension = false;
/* 133 */     this.textGridLeft = 0;
/* 134 */     this.textGridTop = 0;
/* 135 */     this.textGridWidth = 0;
/* 136 */     this.textGridHeight = 0;
/* 137 */     this.characterCellWidth = 0;
/* 138 */     this.characterCellHeight = 0;
/* 139 */     this.textForegroundColor = 0;
/* 140 */     this.textBackgroundColor = 0;
/* 141 */     this.text = null;
/*     */ 
/*     */     
/* 144 */     this.applicationIDs = null;
/* 145 */     this.authenticationCodes = null;
/* 146 */     this.applicationData = null;
/*     */ 
/*     */ 
/*     */     
/* 150 */     this.comments = null;
/*     */   }
/*     */   
/*     */   private byte[] fromISO8859(String data) {
/*     */     try {
/* 155 */       return data.getBytes("ISO-8859-1");
/* 156 */     } catch (UnsupportedEncodingException e) {
/* 157 */       return (new String("")).getBytes();
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void mergeNativeTree(Node root) throws IIOInvalidTreeException {
/* 162 */     Node node = root;
/* 163 */     if (!node.getNodeName().equals("javax_imageio_gif_image_1.0")) {
/* 164 */       fatal(node, "Root must be javax_imageio_gif_image_1.0");
/*     */     }
/*     */     
/* 167 */     node = node.getFirstChild();
/* 168 */     while (node != null) {
/* 169 */       String name = node.getNodeName();
/*     */       
/* 171 */       if (name.equals("ImageDescriptor")) {
/* 172 */         this.imageLeftPosition = getIntAttribute(node, "imageLeftPosition", -1, true, true, 0, 65535);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 177 */         this.imageTopPosition = getIntAttribute(node, "imageTopPosition", -1, true, true, 0, 65535);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 182 */         this.imageWidth = getIntAttribute(node, "imageWidth", -1, true, true, 1, 65535);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 187 */         this.imageHeight = getIntAttribute(node, "imageHeight", -1, true, true, 1, 65535);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 192 */         this.interlaceFlag = getBooleanAttribute(node, "interlaceFlag", false, true);
/*     */       }
/* 194 */       else if (name.equals("LocalColorTable")) {
/* 195 */         int sizeOfLocalColorTable = getIntAttribute(node, "sizeOfLocalColorTable", true, 2, 256);
/*     */ 
/*     */         
/* 198 */         if (sizeOfLocalColorTable != 2 && sizeOfLocalColorTable != 4 && sizeOfLocalColorTable != 8 && sizeOfLocalColorTable != 16 && sizeOfLocalColorTable != 32 && sizeOfLocalColorTable != 64 && sizeOfLocalColorTable != 128 && sizeOfLocalColorTable != 256)
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 206 */           fatal(node, "Bad value for LocalColorTable attribute sizeOfLocalColorTable!");
/*     */         }
/*     */ 
/*     */         
/* 210 */         this.sortFlag = getBooleanAttribute(node, "sortFlag", false, true);
/*     */         
/* 212 */         this.localColorTable = getColorTable(node, "ColorTableEntry", true, sizeOfLocalColorTable);
/*     */       }
/* 214 */       else if (name.equals("GraphicControlExtension")) {
/* 215 */         String disposalMethodName = getStringAttribute(node, "disposalMethod", null, true, disposalMethodNames);
/*     */ 
/*     */         
/* 218 */         this.disposalMethod = 0;
/* 219 */         while (!disposalMethodName.equals(disposalMethodNames[this.disposalMethod])) {
/* 220 */           this.disposalMethod++;
/*     */         }
/*     */         
/* 223 */         this.userInputFlag = getBooleanAttribute(node, "userInputFlag", false, true);
/*     */ 
/*     */         
/* 226 */         this.transparentColorFlag = getBooleanAttribute(node, "transparentColorFlag", false, true);
/*     */ 
/*     */ 
/*     */         
/* 230 */         this.delayTime = getIntAttribute(node, "delayTime", -1, true, true, 0, 65535);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 235 */         this.transparentColorIndex = getIntAttribute(node, "transparentColorIndex", -1, true, true, 0, 65535);
/*     */ 
/*     */       
/*     */       }
/* 239 */       else if (name.equals("PlainTextExtension")) {
/* 240 */         this.hasPlainTextExtension = true;
/*     */         
/* 242 */         this.textGridLeft = getIntAttribute(node, "textGridLeft", -1, true, true, 0, 65535);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 247 */         this.textGridTop = getIntAttribute(node, "textGridTop", -1, true, true, 0, 65535);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 252 */         this.textGridWidth = getIntAttribute(node, "textGridWidth", -1, true, true, 1, 65535);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 257 */         this.textGridHeight = getIntAttribute(node, "textGridHeight", -1, true, true, 1, 65535);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 262 */         this.characterCellWidth = getIntAttribute(node, "characterCellWidth", -1, true, true, 1, 65535);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 267 */         this.characterCellHeight = getIntAttribute(node, "characterCellHeight", -1, true, true, 1, 65535);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 272 */         this.textForegroundColor = getIntAttribute(node, "textForegroundColor", -1, true, true, 0, 255);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 277 */         this.textBackgroundColor = getIntAttribute(node, "textBackgroundColor", -1, true, true, 0, 255);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 288 */         String textString = getStringAttribute(node, "text", "", false, null);
/*     */         
/* 290 */         this.text = fromISO8859(textString);
/* 291 */       } else if (name.equals("ApplicationExtensions")) {
/* 292 */         IIOMetadataNode applicationExtension = (IIOMetadataNode)node.getFirstChild();
/*     */ 
/*     */         
/* 295 */         if (!applicationExtension.getNodeName().equals("ApplicationExtension")) {
/* 296 */           fatal(node, "Only a ApplicationExtension may be a child of a ApplicationExtensions!");
/*     */         }
/*     */ 
/*     */         
/* 300 */         String applicationIDString = getStringAttribute(applicationExtension, "applicationID", null, true, null);
/*     */ 
/*     */ 
/*     */         
/* 304 */         String authenticationCodeString = getStringAttribute(applicationExtension, "authenticationCode", null, true, null);
/*     */ 
/*     */ 
/*     */         
/* 308 */         Object applicationExtensionData = applicationExtension.getUserObject();
/*     */         
/* 310 */         if (applicationExtensionData == null || !(applicationExtensionData instanceof byte[]))
/*     */         {
/* 312 */           fatal(applicationExtension, "Bad user object in ApplicationExtension!");
/*     */         }
/*     */ 
/*     */         
/* 316 */         if (this.applicationIDs == null) {
/* 317 */           this.applicationIDs = new ArrayList();
/* 318 */           this.authenticationCodes = new ArrayList();
/* 319 */           this.applicationData = new ArrayList();
/*     */         } 
/*     */         
/* 322 */         this.applicationIDs.add(fromISO8859(applicationIDString));
/* 323 */         this.authenticationCodes.add(fromISO8859(authenticationCodeString));
/* 324 */         this.applicationData.add(applicationExtensionData);
/* 325 */       } else if (name.equals("CommentExtensions")) {
/* 326 */         Node commentExtension = node.getFirstChild();
/* 327 */         if (commentExtension != null) {
/* 328 */           while (commentExtension != null) {
/* 329 */             if (!commentExtension.getNodeName().equals("CommentExtension")) {
/* 330 */               fatal(node, "Only a CommentExtension may be a child of a CommentExtensions!");
/*     */             }
/*     */ 
/*     */             
/* 334 */             if (this.comments == null) {
/* 335 */               this.comments = new ArrayList();
/*     */             }
/*     */             
/* 338 */             String comment = getStringAttribute(commentExtension, "value", null, true, null);
/*     */ 
/*     */ 
/*     */             
/* 342 */             this.comments.add(fromISO8859(comment));
/*     */             
/* 344 */             commentExtension = commentExtension.getNextSibling();
/*     */           } 
/*     */         }
/*     */       } else {
/* 348 */         fatal(node, "Unknown child of root node!");
/*     */       } 
/*     */       
/* 351 */       node = node.getNextSibling();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void mergeStandardTree(Node root) throws IIOInvalidTreeException {
/* 357 */     Node node = root;
/* 358 */     if (!node.getNodeName().equals("javax_imageio_1.0"))
/*     */     {
/* 360 */       fatal(node, "Root must be javax_imageio_1.0");
/*     */     }
/*     */ 
/*     */     
/* 364 */     node = node.getFirstChild();
/* 365 */     while (node != null) {
/* 366 */       String name = node.getNodeName();
/*     */       
/* 368 */       if (name.equals("Chroma")) {
/* 369 */         Node childNode = node.getFirstChild();
/* 370 */         while (childNode != null) {
/* 371 */           String childName = childNode.getNodeName();
/* 372 */           if (childName.equals("Palette")) {
/* 373 */             this.localColorTable = getColorTable(childNode, "PaletteEntry", false, -1);
/*     */             
/*     */             break;
/*     */           } 
/*     */           
/* 378 */           childNode = childNode.getNextSibling();
/*     */         } 
/* 380 */       } else if (name.equals("Compression")) {
/* 381 */         Node childNode = node.getFirstChild();
/* 382 */         while (childNode != null) {
/* 383 */           String childName = childNode.getNodeName();
/* 384 */           if (childName.equals("NumProgressiveScans")) {
/* 385 */             int numProgressiveScans = getIntAttribute(childNode, "value", 4, false, true, 1, 2147483647);
/*     */ 
/*     */             
/* 388 */             if (numProgressiveScans > 1) {
/* 389 */               this.interlaceFlag = true;
/*     */             }
/*     */             break;
/*     */           } 
/* 393 */           childNode = childNode.getNextSibling();
/*     */         } 
/* 395 */       } else if (name.equals("Dimension")) {
/* 396 */         Node childNode = node.getFirstChild();
/* 397 */         while (childNode != null) {
/* 398 */           String childName = childNode.getNodeName();
/* 399 */           if (childName.equals("HorizontalPixelOffset")) {
/* 400 */             this.imageLeftPosition = getIntAttribute(childNode, "value", -1, true, true, 0, 65535);
/*     */ 
/*     */           
/*     */           }
/* 404 */           else if (childName.equals("VerticalPixelOffset")) {
/* 405 */             this.imageTopPosition = getIntAttribute(childNode, "value", -1, true, true, 0, 65535);
/*     */           } 
/*     */ 
/*     */ 
/*     */           
/* 410 */           childNode = childNode.getNextSibling();
/*     */         } 
/* 412 */       } else if (name.equals("Text")) {
/* 413 */         Node childNode = node.getFirstChild();
/* 414 */         while (childNode != null) {
/* 415 */           String childName = childNode.getNodeName();
/* 416 */           if (childName.equals("TextEntry") && getAttribute(childNode, "compression", "none", false).equals("none") && Charset.isSupported(getAttribute(childNode, "encoding", "ISO-8859-1", false))) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 423 */             String value = getAttribute(childNode, "value");
/* 424 */             byte[] comment = fromISO8859(value);
/* 425 */             if (this.comments == null) {
/* 426 */               this.comments = new ArrayList();
/*     */             }
/* 428 */             this.comments.add(comment);
/*     */           } 
/* 430 */           childNode = childNode.getNextSibling();
/*     */         } 
/* 432 */       } else if (name.equals("Transparency")) {
/* 433 */         Node childNode = node.getFirstChild();
/* 434 */         while (childNode != null) {
/* 435 */           String childName = childNode.getNodeName();
/* 436 */           if (childName.equals("TransparentIndex")) {
/* 437 */             this.transparentColorIndex = getIntAttribute(childNode, "value", -1, true, true, 0, 255);
/*     */ 
/*     */ 
/*     */             
/* 441 */             this.transparentColorFlag = true;
/*     */             break;
/*     */           } 
/* 444 */           childNode = childNode.getNextSibling();
/*     */         } 
/*     */       } 
/*     */       
/* 448 */       node = node.getNextSibling();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFromTree(String formatName, Node root) throws IIOInvalidTreeException {
/* 455 */     reset();
/* 456 */     mergeTree(formatName, root);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/gif/GIFWritableImageMetadata.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */