/*     */ package com.sun.media.imageioimpl.plugins.jpeg2000;
/*     */ 
/*     */ import javax.imageio.metadata.IIOInvalidTreeException;
/*     */ import javax.imageio.metadata.IIOMetadataNode;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResolutionBox
/*     */   extends Box
/*     */ {
/*     */   private short numV;
/*     */   private short numH;
/*     */   private short denomV;
/*     */   private short denomH;
/*     */   private byte expV;
/*     */   private byte expH;
/*     */   private float hRes;
/*     */   private float vRes;
/*     */   
/*     */   public ResolutionBox(int type, byte[] data) {
/* 112 */     super(18, type, data);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResolutionBox(int type, float hRes, float vRes) {
/* 119 */     super(18, type, null);
/* 120 */     this.hRes = hRes;
/* 121 */     this.vRes = vRes;
/* 122 */     this.denomH = this.denomV = 1;
/*     */     
/* 124 */     this.expV = 0;
/* 125 */     if (vRes >= 32768.0F) {
/* 126 */       int temp = (int)vRes;
/* 127 */       while (temp >= 32768) {
/* 128 */         this.expV = (byte)(this.expV + 1);
/* 129 */         temp /= 10;
/*     */       } 
/* 131 */       this.numV = (short)(temp & 0xFFFF);
/*     */     } else {
/* 133 */       this.numV = (short)(int)vRes;
/*     */     } 
/*     */     
/* 136 */     this.expH = 0;
/* 137 */     if (hRes >= 32768.0F) {
/* 138 */       int temp = (int)hRes;
/* 139 */       while (temp >= 32768) {
/* 140 */         this.expH = (byte)(this.expH + 1);
/* 141 */         temp /= 10;
/*     */       } 
/* 143 */       this.numH = (short)(temp & 0xFFFF);
/*     */     } else {
/* 145 */       this.numH = (short)(int)hRes;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResolutionBox(Node node) throws IIOInvalidTreeException {
/* 153 */     super(node);
/* 154 */     NodeList children = node.getChildNodes();
/* 155 */     for (int i = 0; i < children.getLength(); i++) {
/* 156 */       Node child = children.item(i);
/* 157 */       String name = child.getNodeName();
/*     */       
/* 159 */       if ("VerticalResolutionNumerator".equals(name)) {
/* 160 */         this.numV = Box.getShortElementValue(child);
/*     */       }
/*     */       
/* 163 */       if ("VerticalResolutionDenominator".equals(name)) {
/* 164 */         this.denomV = Box.getShortElementValue(child);
/*     */       }
/*     */       
/* 167 */       if ("HorizontalResolutionNumerator".equals(name)) {
/* 168 */         this.numH = Box.getShortElementValue(child);
/*     */       }
/*     */       
/* 171 */       if ("HorizontalResolutionDenominator".equals(name)) {
/* 172 */         this.denomH = Box.getShortElementValue(child);
/*     */       }
/*     */       
/* 175 */       if ("VerticalResolutionExponent".equals(name)) {
/* 176 */         this.expV = Box.getByteElementValue(child);
/*     */       }
/*     */       
/* 179 */       if ("HorizontalResolutionExponent".equals(name)) {
/* 180 */         this.expH = Box.getByteElementValue(child);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public float getHorizontalResolution() {
/* 187 */     return this.hRes;
/*     */   }
/*     */ 
/*     */   
/*     */   public float getVerticalResolution() {
/* 192 */     return this.vRes;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void parse(byte[] data) {
/* 197 */     this.numV = (short)((data[0] & 0xFF) << 8 | data[1] & 0xFF);
/* 198 */     this.denomV = (short)((data[2] & 0xFF) << 8 | data[3] & 0xFF);
/* 199 */     this.numH = (short)((data[4] & 0xFF) << 8 | data[5] & 0xFF);
/* 200 */     this.denomH = (short)((data[6] & 0xFF) << 8 | data[7] & 0xFF);
/* 201 */     this.expV = data[8];
/* 202 */     this.expH = data[9];
/* 203 */     this.vRes = (float)((this.numV & 0xFFFF) * Math.pow(10.0D, this.expV) / (this.denomV & 0xFFFF));
/* 204 */     this.hRes = (float)((this.numH & 0xFFFF) * Math.pow(10.0D, this.expH) / (this.denomH & 0xFFFF));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IIOMetadataNode getNativeNode() {
/* 212 */     IIOMetadataNode node = new IIOMetadataNode(Box.getName(getType()));
/* 213 */     setDefaultAttributes(node);
/*     */     
/* 215 */     IIOMetadataNode child = new IIOMetadataNode("VerticalResolutionNumerator");
/* 216 */     child.setUserObject(new Short(this.numV));
/* 217 */     child.setNodeValue("" + this.numV);
/* 218 */     node.appendChild(child);
/*     */     
/* 220 */     child = new IIOMetadataNode("VerticalResolutionDenominator");
/* 221 */     child.setUserObject(new Short(this.denomV));
/* 222 */     child.setNodeValue("" + this.denomV);
/* 223 */     node.appendChild(child);
/*     */     
/* 225 */     child = new IIOMetadataNode("HorizontalResolutionNumerator");
/* 226 */     child.setUserObject(new Short(this.numH));
/* 227 */     child.setNodeValue("" + this.numH);
/* 228 */     node.appendChild(child);
/*     */     
/* 230 */     child = new IIOMetadataNode("HorizontalResolutionDenominator");
/* 231 */     child.setUserObject(new Short(this.denomH));
/* 232 */     child.setNodeValue("" + this.denomH);
/* 233 */     node.appendChild(child);
/*     */     
/* 235 */     child = new IIOMetadataNode("VerticalResolutionExponent");
/* 236 */     child.setUserObject(new Byte(this.expV));
/* 237 */     child.setNodeValue("" + this.expV);
/* 238 */     node.appendChild(child);
/*     */     
/* 240 */     child = new IIOMetadataNode("HorizontalResolutionExponent");
/* 241 */     child.setUserObject(new Byte(this.expH));
/* 242 */     child.setNodeValue("" + this.expH);
/* 243 */     node.appendChild(child);
/*     */     
/* 245 */     return node;
/*     */   }
/*     */   
/*     */   protected void compose() {
/* 249 */     if (this.data != null)
/*     */       return; 
/* 251 */     this.data = new byte[10];
/* 252 */     this.data[0] = (byte)(this.numV >> 8);
/* 253 */     this.data[1] = (byte)(this.numV & 0xFF);
/* 254 */     this.data[2] = (byte)(this.denomV >> 8);
/* 255 */     this.data[3] = (byte)(this.denomV & 0xFF);
/*     */     
/* 257 */     this.data[4] = (byte)(this.numH >> 8);
/* 258 */     this.data[5] = (byte)(this.numH & 0xFF);
/* 259 */     this.data[6] = (byte)(this.denomH >> 8);
/* 260 */     this.data[7] = (byte)(this.denomH & 0xFF);
/*     */     
/* 262 */     this.data[8] = this.expV;
/* 263 */     this.data[9] = this.expH;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/jpeg2000/ResolutionBox.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */