/*     */ package com.sun.media.imageioimpl.plugins.jpeg2000;
/*     */ 
/*     */ import com.sun.media.imageioimpl.common.PackageUtil;
/*     */ import java.io.IOException;
/*     */ import java.util.Locale;
/*     */ import javax.imageio.IIOException;
/*     */ import javax.imageio.ImageReader;
/*     */ import javax.imageio.spi.ImageReaderSpi;
/*     */ import javax.imageio.spi.ServiceRegistry;
/*     */ import javax.imageio.stream.ImageInputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class J2KImageReaderSpi
/*     */   extends ImageReaderSpi
/*     */ {
/*  96 */   private static String[] writerSpiNames = new String[] { "com.sun.media.imageioimpl.plugins.jpeg2000.J2KImageWriterSpi" };
/*     */   
/*  98 */   private static String[] formatNames = new String[] { "jpeg 2000", "JPEG 2000", "jpeg2000", "JPEG2000" };
/*     */   
/* 100 */   private static String[] extensions = new String[] { "jp2" };
/*     */   
/* 102 */   private static String[] mimeTypes = new String[] { "image/jp2", "image/jpeg2000" };
/*     */   private boolean registered = false;
/*     */   
/*     */   public J2KImageReaderSpi() {
/* 106 */     super(PackageUtil.getVendor(), PackageUtil.getVersion(), formatNames, extensions, mimeTypes, "com.sun.media.imageioimpl.plugins.jpeg2000.J2KImageReader", STANDARD_INPUT_TYPE, writerSpiNames, false, null, null, null, null, true, "com_sun_media_imageio_plugins_jpeg2000_image_1.0", "com.sun.media.imageioimpl.plugins.jpeg2000.J2KMetadataFormat", null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onRegistration(ServiceRegistry registry, Class category) {
/* 125 */     if (this.registered) {
/*     */       return;
/*     */     }
/*     */     
/* 129 */     this.registered = true;
/*     */ 
/*     */     
/* 132 */     Class<?> codecLibReaderSPIClass = null;
/*     */     try {
/* 134 */       codecLibReaderSPIClass = Class.forName("com.sun.media.imageioimpl.plugins.jpeg2000.J2KImageReaderCodecLibSpi");
/*     */     }
/* 136 */     catch (Throwable t) {}
/*     */ 
/*     */ 
/*     */     
/* 140 */     if (codecLibReaderSPIClass != null) {
/* 141 */       Object codecLibReaderSPI = registry.getServiceProviderByClass(codecLibReaderSPIClass);
/*     */       
/* 143 */       if (codecLibReaderSPI != null) {
/* 144 */         registry.setOrdering(category, codecLibReaderSPI, this);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public String getDescription(Locale locale) {
/* 150 */     String desc = PackageUtil.getSpecificationTitle() + " JPEG 2000 Image Reader";
/*     */     
/* 152 */     return desc;
/*     */   }
/*     */   
/*     */   public boolean canDecodeInput(Object source) throws IOException {
/* 156 */     if (!(source instanceof ImageInputStream)) {
/* 157 */       return false;
/*     */     }
/*     */     
/* 160 */     ImageInputStream stream = (ImageInputStream)source;
/*     */ 
/*     */     
/* 163 */     stream.mark();
/* 164 */     int marker = stream.read() << 8 | stream.read();
/*     */     
/* 166 */     if (marker == 65359) {
/* 167 */       stream.reset();
/* 168 */       return true;
/*     */     } 
/*     */     
/* 171 */     stream.reset();
/* 172 */     stream.mark();
/* 173 */     byte[] b = new byte[12];
/* 174 */     stream.readFully(b);
/* 175 */     stream.reset();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 180 */     if (b[0] != 0 || b[1] != 0 || b[2] != 0 || b[3] != 12) {
/* 181 */       return false;
/*     */     }
/*     */     
/* 184 */     if ((b[4] & 0xFF) != 106 || (b[5] & 0xFF) != 80 || (b[6] & 0xFF) != 32 || (b[7] & 0xFF) != 32)
/*     */     {
/* 186 */       return false;
/*     */     }
/*     */     
/* 189 */     if ((b[8] & 0xFF) != 13 || (b[9] & 0xFF) != 10 || (b[10] & 0xFF) != 135 || (b[11] & 0xFF) != 10)
/*     */     {
/* 191 */       return false;
/*     */     }
/* 193 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public ImageReader createReaderInstance(Object extension) throws IIOException {
/* 198 */     return new J2KImageReader(this);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/jpeg2000/J2KImageReaderSpi.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */