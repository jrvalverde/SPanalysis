/*     */ package com.sun.media.imageioimpl.plugins.jpeg2000;
/*     */ 
/*     */ import com.sun.media.imageio.plugins.jpeg2000.J2KImageWriteParam;
/*     */ import com.sun.media.imageioimpl.common.ImageUtil;
/*     */ import java.awt.image.ColorModel;
/*     */ import java.awt.image.Raster;
/*     */ import java.awt.image.RenderedImage;
/*     */ import java.awt.image.SampleModel;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import javax.imageio.IIOException;
/*     */ import javax.imageio.IIOImage;
/*     */ import javax.imageio.ImageTypeSpecifier;
/*     */ import javax.imageio.ImageWriteParam;
/*     */ import javax.imageio.ImageWriter;
/*     */ import javax.imageio.metadata.IIOInvalidTreeException;
/*     */ import javax.imageio.metadata.IIOMetadata;
/*     */ import javax.imageio.spi.ImageWriterSpi;
/*     */ import javax.imageio.stream.ImageOutputStream;
/*     */ import jj2000.j2k.codestream.writer.CodestreamWriter;
/*     */ import jj2000.j2k.codestream.writer.FileCodestreamWriter;
/*     */ import jj2000.j2k.codestream.writer.HeaderEncoder;
/*     */ import jj2000.j2k.entropy.encoder.CodedCBlkDataSrcEnc;
/*     */ import jj2000.j2k.entropy.encoder.EntropyCoder;
/*     */ import jj2000.j2k.entropy.encoder.PostCompRateAllocator;
/*     */ import jj2000.j2k.fileformat.writer.FileFormatWriter;
/*     */ import jj2000.j2k.image.BlkImgDataSrc;
/*     */ import jj2000.j2k.image.ImgData;
/*     */ import jj2000.j2k.image.ImgDataConverter;
/*     */ import jj2000.j2k.image.Tiler;
/*     */ import jj2000.j2k.image.forwcomptransf.ForwCompTransf;
/*     */ import jj2000.j2k.quantization.quantizer.CBlkQuantDataSrcEnc;
/*     */ import jj2000.j2k.quantization.quantizer.Quantizer;
/*     */ import jj2000.j2k.roi.encoder.ROIScaler;
/*     */ import jj2000.j2k.util.CodestreamManipulator;
/*     */ import jj2000.j2k.wavelet.analysis.CBlkWTDataSrc;
/*     */ import jj2000.j2k.wavelet.analysis.ForwardWT;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class J2KImageWriter
/*     */   extends ImageWriter
/*     */ {
/*     */   public void processImageProgressWrapper(float percentageDone) {
/* 150 */     processImageProgress(percentageDone);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 157 */   public static String WRITE_ABORTED = "Write aborted.";
/*     */ 
/*     */   
/* 160 */   private ImageOutputStream stream = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public J2KImageWriter(ImageWriterSpi originator) {
/* 166 */     super(originator);
/*     */   }
/*     */   
/*     */   public void setOutput(Object output) {
/* 170 */     super.setOutput(output);
/* 171 */     if (output != null) {
/* 172 */       if (!(output instanceof ImageOutputStream))
/* 173 */         throw new IllegalArgumentException(I18N.getString("J2KImageWriter0")); 
/* 174 */       this.stream = (ImageOutputStream)output;
/*     */     } else {
/* 176 */       this.stream = null;
/*     */     } 
/*     */   }
/*     */   public ImageWriteParam getDefaultWriteParam() {
/* 180 */     return (ImageWriteParam)new J2KImageWriteParam();
/*     */   }
/*     */   
/*     */   public IIOMetadata getDefaultStreamMetadata(ImageWriteParam param) {
/* 184 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public IIOMetadata getDefaultImageMetadata(ImageTypeSpecifier imageType, ImageWriteParam param) {
/* 189 */     return new J2KMetadata(imageType, param, this);
/*     */   }
/*     */ 
/*     */   
/*     */   public IIOMetadata convertStreamMetadata(IIOMetadata inData, ImageWriteParam param) {
/* 194 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IIOMetadata convertImageMetadata(IIOMetadata inData, ImageTypeSpecifier imageType, ImageWriteParam param) {
/* 201 */     if (inData == null) {
/* 202 */       throw new IllegalArgumentException("inData == null!");
/*     */     }
/* 204 */     if (imageType == null) {
/* 205 */       throw new IllegalArgumentException("imageType == null!");
/*     */     }
/*     */ 
/*     */     
/* 209 */     if (inData instanceof J2KMetadata) {
/* 210 */       return (IIOMetadata)((J2KMetadata)inData).clone();
/*     */     }
/*     */     
/*     */     try {
/* 214 */       J2KMetadata outData = new J2KMetadata();
/*     */       
/* 216 */       List<String> formats = Arrays.asList(inData.getMetadataFormatNames());
/*     */       
/* 218 */       String format = null;
/* 219 */       if (formats.contains("com_sun_media_imageio_plugins_jpeg2000_image_1.0")) {
/*     */         
/* 221 */         format = "com_sun_media_imageio_plugins_jpeg2000_image_1.0";
/* 222 */       } else if (inData.isStandardMetadataFormatSupported()) {
/*     */         
/* 224 */         format = "javax_imageio_1.0";
/*     */       } 
/*     */       
/* 227 */       if (format != null) {
/* 228 */         outData.setFromTree(format, inData.getAsTree(format));
/* 229 */         return outData;
/*     */       } 
/* 231 */     } catch (IIOInvalidTreeException e) {
/* 232 */       return null;
/*     */     } 
/*     */     
/* 235 */     return null;
/*     */   }
/*     */   
/*     */   public boolean canWriteRasters() {
/* 239 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(IIOMetadata streamMetadata, IIOImage image, ImageWriteParam param) throws IOException {
/* 245 */     if (this.stream == null) {
/* 246 */       throw new IllegalStateException(I18N.getString("J2KImageWriter7"));
/*     */     }
/* 248 */     if (image == null) {
/* 249 */       throw new IllegalArgumentException(I18N.getString("J2KImageWriter8"));
/*     */     }
/*     */     
/* 252 */     clearAbortRequest();
/* 253 */     processImageStarted(0);
/* 254 */     RenderedImage input = null;
/*     */     
/* 256 */     boolean writeRaster = image.hasRaster();
/* 257 */     Raster raster = null;
/*     */     
/* 259 */     SampleModel sampleModel = null;
/* 260 */     if (writeRaster) {
/* 261 */       raster = image.getRaster();
/* 262 */       sampleModel = raster.getSampleModel();
/*     */     } else {
/* 264 */       input = image.getRenderedImage();
/* 265 */       sampleModel = input.getSampleModel();
/*     */     } 
/*     */     
/* 268 */     checkSampleModel(sampleModel);
/* 269 */     if (param == null) {
/* 270 */       param = getDefaultWriteParam();
/*     */     }
/* 272 */     J2KImageWriteParamJava j2kwparam = new J2KImageWriteParamJava(image, param);
/*     */ 
/*     */ 
/*     */     
/* 276 */     if (j2kwparam.getPackPacketHeaderInTile() && j2kwparam.getPackPacketHeaderInMain())
/*     */     {
/* 278 */       throw new IllegalArgumentException(I18N.getString("J2KImageWriter1"));
/*     */     }
/*     */     
/* 281 */     if (j2kwparam.getLossless() && j2kwparam.getEncodingRate() != Double.MAX_VALUE)
/*     */     {
/* 283 */       throw new IllegalArgumentException(I18N.getString("J2KImageWriter2"));
/*     */     }
/*     */ 
/*     */     
/* 287 */     if ((!writeRaster && input.getColorModel() instanceof java.awt.image.IndexColorModel) || (writeRaster && raster.getSampleModel() instanceof java.awt.image.MultiPixelPackedSampleModel)) {
/*     */ 
/*     */       
/* 290 */       j2kwparam.setDecompositionLevel("0");
/* 291 */       j2kwparam.setLossless(true);
/* 292 */       j2kwparam.setEncodingRate(Double.MAX_VALUE);
/* 293 */       j2kwparam.setQuantizationType("reversible");
/* 294 */       j2kwparam.setFilters("w5x3");
/* 295 */     } else if (j2kwparam.getEncodingRate() == Double.MAX_VALUE) {
/* 296 */       j2kwparam.setLossless(true);
/* 297 */       j2kwparam.setQuantizationType("reversible");
/* 298 */       j2kwparam.setFilters("w5x3");
/*     */     } 
/*     */ 
/*     */     
/* 302 */     boolean pphTile = j2kwparam.getPackPacketHeaderInTile();
/* 303 */     boolean pphMain = j2kwparam.getPackPacketHeaderInMain();
/* 304 */     boolean tempSop = false;
/* 305 */     boolean tempEph = false;
/*     */     
/* 307 */     int[] bands = param.getSourceBands();
/* 308 */     int ncomp = sampleModel.getNumBands();
/*     */     
/* 310 */     if (bands != null) {
/* 311 */       ncomp = bands.length;
/*     */     }
/*     */     
/* 314 */     RenderedImageSrc imgsrc = null;
/* 315 */     if (writeRaster) {
/* 316 */       imgsrc = new RenderedImageSrc(raster, j2kwparam, this);
/*     */     } else {
/* 318 */       imgsrc = new RenderedImageSrc(input, j2kwparam, this);
/*     */     } 
/*     */     
/* 321 */     boolean[] imsigned = new boolean[ncomp];
/* 322 */     if (bands != null) {
/* 323 */       for (int i = 0; i < ncomp; i++)
/* 324 */         imsigned[i] = imgsrc.isOrigSigned(bands[i]); 
/*     */     } else {
/* 326 */       for (int i = 0; i < ncomp; i++) {
/* 327 */         imsigned[i] = imgsrc.isOrigSigned(i);
/*     */       }
/*     */     } 
/*     */     
/* 331 */     int tw = j2kwparam.getTileWidth();
/* 332 */     int th = j2kwparam.getTileHeight();
/*     */ 
/*     */     
/* 335 */     int refx = j2kwparam.getMinX();
/* 336 */     int refy = j2kwparam.getMinY();
/* 337 */     if (refx < 0 || refy < 0) {
/* 338 */       throw new IIOException(I18N.getString("J2KImageWriter3"));
/*     */     }
/*     */     
/* 341 */     int trefx = j2kwparam.getTileGridXOffset();
/* 342 */     int trefy = j2kwparam.getTileGridYOffset();
/* 343 */     if (trefx < 0 || trefy < 0 || trefx > refx || trefy > refy) {
/* 344 */       throw new IIOException(I18N.getString("J2KImageWriter4"));
/*     */     }
/*     */     
/* 347 */     Tiler imgtiler = new Tiler(imgsrc, refx, refy, trefx, trefy, tw, th);
/*     */ 
/*     */     
/* 350 */     ForwCompTransf fctransf = new ForwCompTransf((BlkImgDataSrc)imgtiler, j2kwparam);
/*     */ 
/*     */     
/* 353 */     ImgDataConverter converter = new ImgDataConverter((BlkImgDataSrc)fctransf);
/*     */ 
/*     */     
/* 356 */     ForwardWT dwt = ForwardWT.createInstance((BlkImgDataSrc)converter, j2kwparam);
/*     */ 
/*     */     
/* 359 */     Quantizer quant = Quantizer.createInstance((CBlkWTDataSrc)dwt, j2kwparam);
/*     */ 
/*     */     
/* 362 */     ROIScaler rois = ROIScaler.createInstance(quant, j2kwparam);
/*     */ 
/*     */     
/* 365 */     EntropyCoder ecoder = EntropyCoder.createInstance((CBlkQuantDataSrcEnc)rois, j2kwparam, j2kwparam.getCodeBlockSize(), j2kwparam.getPrecinctPartition(), j2kwparam.getBypass(), j2kwparam.getResetMQ(), j2kwparam.getTerminateOnByte(), j2kwparam.getCausalCXInfo(), j2kwparam.getCodeSegSymbol(), j2kwparam.getMethodForMQLengthCalc(), j2kwparam.getMethodForMQTermination());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 378 */     File tmpFile = File.createTempFile("jiio-", ".tmp");
/* 379 */     tmpFile.deleteOnExit();
/*     */ 
/*     */     
/* 382 */     FileCodestreamWriter bwriter = new FileCodestreamWriter(tmpFile, 2147483647);
/*     */ 
/*     */ 
/*     */     
/* 386 */     float rate = (float)j2kwparam.getEncodingRate();
/* 387 */     PostCompRateAllocator ralloc = PostCompRateAllocator.createInstance((CodedCBlkDataSrcEnc)ecoder, rate, (CodestreamWriter)bwriter, j2kwparam);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 394 */     HeaderEncoder headenc = new HeaderEncoder((ImgData)imgsrc, imsigned, dwt, imgtiler, j2kwparam, rois, ralloc);
/*     */ 
/*     */ 
/*     */     
/* 398 */     ralloc.setHeaderEncoder(headenc);
/*     */ 
/*     */     
/* 401 */     headenc.encodeMainHeader();
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 406 */       ralloc.initialize();
/* 407 */     } catch (RuntimeException e) {
/* 408 */       if (WRITE_ABORTED.equals(e.getMessage())) {
/* 409 */         bwriter.close();
/* 410 */         tmpFile.delete();
/* 411 */         processWriteAborted(); return;
/*     */       } 
/* 413 */       throw e;
/*     */     } 
/*     */ 
/*     */     
/* 417 */     headenc.reset();
/* 418 */     headenc.encodeMainHeader();
/*     */ 
/*     */     
/* 421 */     bwriter.commitBitstreamHeader(headenc);
/*     */ 
/*     */     
/* 424 */     ralloc.runAndWrite();
/*     */ 
/*     */     
/* 427 */     bwriter.close();
/*     */ 
/*     */     
/* 430 */     int fileLength = bwriter.getLength();
/*     */ 
/*     */     
/* 433 */     int pktspertp = j2kwparam.getPacketPerTilePart();
/* 434 */     int ntiles = imgtiler.getNumTiles();
/* 435 */     if (pktspertp > 0 || pphTile || pphMain) {
/* 436 */       CodestreamManipulator cm = new CodestreamManipulator(tmpFile, ntiles, pktspertp, pphMain, pphTile, tempSop, tempEph);
/*     */ 
/*     */ 
/*     */       
/* 440 */       fileLength += cm.doCodestreamManipulation();
/*     */     } 
/*     */ 
/*     */     
/* 444 */     int nc = imgsrc.getNumComps();
/* 445 */     int[] bpc = new int[nc];
/* 446 */     for (int comp = 0; comp < nc; comp++) {
/* 447 */       bpc[comp] = imgsrc.getNomRangeBits(comp);
/*     */     }
/* 449 */     ColorModel colorModel = (input != null) ? input.getColorModel() : null;
/* 450 */     if (bands != null) {
/* 451 */       ImageTypeSpecifier type = param.getDestinationType();
/* 452 */       if (type != null) {
/* 453 */         colorModel = type.getColorModel();
/*     */       }
/*     */     } 
/*     */     
/* 457 */     if (colorModel == null) {
/* 458 */       colorModel = ImageUtil.createColorModel(sampleModel);
/*     */     }
/*     */     
/* 461 */     J2KMetadata metadata = null;
/*     */     
/* 463 */     if (param instanceof J2KImageWriteParam && !((J2KImageWriteParam)param).getWriteCodeStreamOnly()) {
/*     */       
/* 465 */       IIOMetadata inMetadata = image.getMetadata();
/*     */       
/* 467 */       J2KMetadata metadata1 = new J2KMetadata(colorModel, sampleModel, imgsrc.getImgWidth(), imgsrc.getImgHeight(), param, this);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 474 */       if (inMetadata == null) {
/* 475 */         metadata = metadata1;
/*     */       } else {
/*     */         
/* 478 */         if (colorModel != null) {
/* 479 */           ImageTypeSpecifier imageType = new ImageTypeSpecifier(colorModel, sampleModel);
/*     */           
/* 481 */           metadata = (J2KMetadata)convertImageMetadata(inMetadata, imageType, param);
/*     */         
/*     */         }
/*     */         else {
/*     */           
/* 486 */           String metaFormat = null;
/* 487 */           List<String> metaFormats = Arrays.asList(inMetadata.getMetadataFormatNames());
/*     */           
/* 489 */           if (metaFormats.contains("com_sun_media_imageio_plugins_jpeg2000_image_1.0")) {
/*     */             
/* 491 */             metaFormat = "com_sun_media_imageio_plugins_jpeg2000_image_1.0";
/* 492 */           } else if (inMetadata.isStandardMetadataFormatSupported()) {
/*     */ 
/*     */             
/* 495 */             metaFormat = "javax_imageio_1.0";
/*     */           } 
/*     */ 
/*     */           
/* 499 */           metadata = new J2KMetadata();
/* 500 */           if (metaFormat != null) {
/* 501 */             metadata.setFromTree(metaFormat, inMetadata.getAsTree(metaFormat));
/*     */           }
/*     */         } 
/*     */ 
/*     */         
/* 506 */         metadata.mergeTree("com_sun_media_imageio_plugins_jpeg2000_image_1.0", metadata1.getAsTree("com_sun_media_imageio_plugins_jpeg2000_image_1.0"));
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 511 */     FileFormatWriter ffw = new FileFormatWriter(tmpFile, this.stream, imgsrc.getImgHeight(), imgsrc.getImgWidth(), nc, bpc, fileLength, colorModel, sampleModel, metadata);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 519 */     fileLength += ffw.writeFileFormat();
/* 520 */     tmpFile.delete();
/*     */     
/* 522 */     processImageComplete();
/*     */   }
/*     */   
/*     */   public synchronized void abort() {
/* 526 */     super.abort();
/*     */   }
/*     */ 
/*     */   
/*     */   public void reset() {
/* 531 */     super.reset();
/* 532 */     this.stream = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getAbortRequest() {
/* 539 */     return abortRequested();
/*     */   }
/*     */   
/*     */   private void checkSampleModel(SampleModel sm) {
/* 543 */     int type = sm.getDataType();
/*     */     
/* 545 */     if (type < 0 || type > 3)
/* 546 */       throw new IllegalArgumentException(I18N.getString("J2KImageWriter5")); 
/* 547 */     if (sm.getNumBands() > 16384)
/* 548 */       throw new IllegalArgumentException(I18N.getString("J2KImageWriter6")); 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/jpeg2000/J2KImageWriter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */