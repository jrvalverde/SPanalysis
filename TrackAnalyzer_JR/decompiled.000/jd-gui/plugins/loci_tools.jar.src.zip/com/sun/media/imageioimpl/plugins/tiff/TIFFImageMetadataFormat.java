/*     */ package com.sun.media.imageioimpl.plugins.tiff;
/*     */ 
/*     */ import javax.imageio.ImageTypeSpecifier;
/*     */ import javax.imageio.metadata.IIOMetadataFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TIFFImageMetadataFormat
/*     */   extends TIFFMetadataFormat
/*     */ {
/*  98 */   private static TIFFImageMetadataFormat theInstance = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canNodeAppear(String elementName, ImageTypeSpecifier imageType) {
/* 105 */     return false;
/*     */   }
/*     */   
/*     */   private TIFFImageMetadataFormat() {
/* 109 */     this.resourceBaseName = "com.sun.media.imageioimpl.plugins.tiff.TIFFImageMetadataFormatResources";
/*     */     
/* 111 */     this.rootName = "com_sun_media_imageio_plugins_tiff_image_1.0";
/*     */ 
/*     */ 
/*     */     
/* 115 */     String[] empty = new String[0];
/*     */ 
/*     */ 
/*     */     
/* 119 */     String[] childNames = { "TIFFIFD" };
/* 120 */     TIFFElementInfo einfo = new TIFFElementInfo(childNames, empty, 4);
/*     */     
/* 122 */     this.elementInfoMap.put("com_sun_media_imageio_plugins_tiff_image_1.0", einfo);
/*     */ 
/*     */     
/* 125 */     childNames = new String[] { "TIFFField", "TIFFIFD" };
/* 126 */     String[] attrNames = { "tagSets", "parentTagNumber", "parentTagName" };
/*     */     
/* 128 */     einfo = new TIFFElementInfo(childNames, attrNames, 4);
/* 129 */     this.elementInfoMap.put("TIFFIFD", einfo);
/*     */     
/* 131 */     TIFFAttrInfo ainfo = new TIFFAttrInfo();
/* 132 */     ainfo.dataType = 0;
/* 133 */     ainfo.isRequired = true;
/* 134 */     this.attrInfoMap.put("TIFFIFD/tagSets", ainfo);
/*     */     
/* 136 */     ainfo = new TIFFAttrInfo();
/* 137 */     ainfo.dataType = 2;
/* 138 */     ainfo.isRequired = false;
/* 139 */     this.attrInfoMap.put("TIFFIFD/parentTagNumber", ainfo);
/*     */     
/* 141 */     ainfo = new TIFFAttrInfo();
/* 142 */     ainfo.dataType = 0;
/* 143 */     ainfo.isRequired = false;
/* 144 */     this.attrInfoMap.put("TIFFIFD/parentTagName", ainfo);
/*     */     
/* 146 */     String[] types = { "TIFFByte", "TIFFAscii", "TIFFShort", "TIFFSShort", "TIFFLong", "TIFFSLong", "TIFFRational", "TIFFSRational", "TIFFFloat", "TIFFDouble", "TIFFUndefined" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 160 */     attrNames = new String[] { "value", "description" };
/* 161 */     String[] attrNamesValueOnly = { "value" };
/* 162 */     TIFFAttrInfo ainfoValue = new TIFFAttrInfo();
/* 163 */     TIFFAttrInfo ainfoDescription = new TIFFAttrInfo();
/*     */     int i;
/* 165 */     for (i = 0; i < types.length; i++) {
/* 166 */       if (!types[i].equals("TIFFUndefined")) {
/* 167 */         childNames = new String[1];
/* 168 */         childNames[0] = types[i];
/* 169 */         einfo = new TIFFElementInfo(childNames, empty, 4);
/*     */         
/* 171 */         this.elementInfoMap.put(types[i] + "s", einfo);
/*     */       } 
/*     */       
/* 174 */       boolean hasDescription = (!types[i].equals("TIFFUndefined") && !types[i].equals("TIFFAscii") && !types[i].equals("TIFFRational") && !types[i].equals("TIFFSRational") && !types[i].equals("TIFFFloat") && !types[i].equals("TIFFDouble"));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 182 */       String[] anames = hasDescription ? attrNames : attrNamesValueOnly;
/* 183 */       einfo = new TIFFElementInfo(empty, anames, 0);
/* 184 */       this.elementInfoMap.put(types[i], einfo);
/*     */       
/* 186 */       this.attrInfoMap.put(types[i] + "/value", ainfoValue);
/* 187 */       if (hasDescription) {
/* 188 */         this.attrInfoMap.put(types[i] + "/description", ainfoDescription);
/*     */       }
/*     */     } 
/*     */     
/* 192 */     childNames = new String[2 * types.length - 1];
/* 193 */     for (i = 0; i < types.length; i++) {
/* 194 */       childNames[2 * i] = types[i];
/* 195 */       if (!types[i].equals("TIFFUndefined")) {
/* 196 */         childNames[2 * i + 1] = types[i] + "s";
/*     */       }
/*     */     } 
/* 199 */     attrNames = new String[] { "number", "name" };
/* 200 */     einfo = new TIFFElementInfo(childNames, attrNames, 3);
/* 201 */     this.elementInfoMap.put("TIFFField", einfo);
/*     */     
/* 203 */     ainfo = new TIFFAttrInfo();
/* 204 */     ainfo.isRequired = true;
/* 205 */     this.attrInfoMap.put("TIFFField/number", ainfo);
/*     */     
/* 207 */     ainfo = new TIFFAttrInfo();
/* 208 */     this.attrInfoMap.put("TIFFField/name", ainfo);
/*     */   }
/*     */   
/*     */   public static synchronized IIOMetadataFormat getInstance() {
/* 212 */     if (theInstance == null) {
/* 213 */       theInstance = new TIFFImageMetadataFormat();
/*     */     }
/* 215 */     return theInstance;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/tiff/TIFFImageMetadataFormat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */