/*     */ package com.sun.media.imageioimpl.plugins.tiff;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.MissingResourceException;
/*     */ import java.util.ResourceBundle;
/*     */ import javax.imageio.metadata.IIOMetadataFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TIFFMetadataFormat
/*     */   implements IIOMetadataFormat
/*     */ {
/*  98 */   protected Map elementInfoMap = new HashMap<Object, Object>();
/*  99 */   protected Map attrInfoMap = new HashMap<Object, Object>();
/*     */   
/*     */   protected String resourceBaseName;
/*     */   protected String rootName;
/*     */   
/*     */   public String getRootName() {
/* 105 */     return this.rootName;
/*     */   }
/*     */   
/*     */   private String getResource(String key, Locale locale) {
/* 109 */     if (locale == null) {
/* 110 */       locale = Locale.getDefault();
/*     */     }
/*     */     try {
/* 113 */       ResourceBundle bundle = ResourceBundle.getBundle(this.resourceBaseName, locale);
/*     */       
/* 115 */       return bundle.getString(key);
/* 116 */     } catch (MissingResourceException e) {
/* 117 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private TIFFElementInfo getElementInfo(String elementName) {
/* 122 */     if (elementName == null) {
/* 123 */       throw new IllegalArgumentException("elementName == null!");
/*     */     }
/* 125 */     TIFFElementInfo info = (TIFFElementInfo)this.elementInfoMap.get(elementName);
/*     */     
/* 127 */     if (info == null) {
/* 128 */       throw new IllegalArgumentException("No such element: " + elementName);
/*     */     }
/*     */     
/* 131 */     return info;
/*     */   }
/*     */   
/*     */   private TIFFAttrInfo getAttrInfo(String elementName, String attrName) {
/* 135 */     if (elementName == null) {
/* 136 */       throw new IllegalArgumentException("elementName == null!");
/*     */     }
/* 138 */     if (attrName == null) {
/* 139 */       throw new IllegalArgumentException("attrName == null!");
/*     */     }
/* 141 */     String key = elementName + "/" + attrName;
/* 142 */     TIFFAttrInfo info = (TIFFAttrInfo)this.attrInfoMap.get(key);
/* 143 */     if (info == null) {
/* 144 */       throw new IllegalArgumentException("No such attribute: " + key);
/*     */     }
/* 146 */     return info;
/*     */   }
/*     */   
/*     */   public int getElementMinChildren(String elementName) {
/* 150 */     TIFFElementInfo info = getElementInfo(elementName);
/* 151 */     return info.minChildren;
/*     */   }
/*     */   
/*     */   public int getElementMaxChildren(String elementName) {
/* 155 */     TIFFElementInfo info = getElementInfo(elementName);
/* 156 */     return info.maxChildren;
/*     */   }
/*     */   
/*     */   public String getElementDescription(String elementName, Locale locale) {
/* 160 */     if (!this.elementInfoMap.containsKey(elementName)) {
/* 161 */       throw new IllegalArgumentException("No such element: " + elementName);
/*     */     }
/*     */     
/* 164 */     return getResource(elementName, locale);
/*     */   }
/*     */   
/*     */   public int getChildPolicy(String elementName) {
/* 168 */     TIFFElementInfo info = getElementInfo(elementName);
/* 169 */     return info.childPolicy;
/*     */   }
/*     */   
/*     */   public String[] getChildNames(String elementName) {
/* 173 */     TIFFElementInfo info = getElementInfo(elementName);
/* 174 */     return info.childNames;
/*     */   }
/*     */   
/*     */   public String[] getAttributeNames(String elementName) {
/* 178 */     TIFFElementInfo info = getElementInfo(elementName);
/* 179 */     return info.attributeNames;
/*     */   }
/*     */   
/*     */   public int getAttributeValueType(String elementName, String attrName) {
/* 183 */     TIFFAttrInfo info = getAttrInfo(elementName, attrName);
/* 184 */     return info.valueType;
/*     */   }
/*     */   
/*     */   public int getAttributeDataType(String elementName, String attrName) {
/* 188 */     TIFFAttrInfo info = getAttrInfo(elementName, attrName);
/* 189 */     return info.dataType;
/*     */   }
/*     */   
/*     */   public boolean isAttributeRequired(String elementName, String attrName) {
/* 193 */     TIFFAttrInfo info = getAttrInfo(elementName, attrName);
/* 194 */     return info.isRequired;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getAttributeDefaultValue(String elementName, String attrName) {
/* 199 */     TIFFAttrInfo info = getAttrInfo(elementName, attrName);
/* 200 */     return info.defaultValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getAttributeEnumerations(String elementName, String attrName) {
/* 205 */     TIFFAttrInfo info = getAttrInfo(elementName, attrName);
/* 206 */     return info.enumerations;
/*     */   }
/*     */   
/*     */   public String getAttributeMinValue(String elementName, String attrName) {
/* 210 */     TIFFAttrInfo info = getAttrInfo(elementName, attrName);
/* 211 */     return info.minValue;
/*     */   }
/*     */   
/*     */   public String getAttributeMaxValue(String elementName, String attrName) {
/* 215 */     TIFFAttrInfo info = getAttrInfo(elementName, attrName);
/* 216 */     return info.maxValue;
/*     */   }
/*     */   
/*     */   public int getAttributeListMinLength(String elementName, String attrName) {
/* 220 */     TIFFAttrInfo info = getAttrInfo(elementName, attrName);
/* 221 */     return info.listMinLength;
/*     */   }
/*     */   
/*     */   public int getAttributeListMaxLength(String elementName, String attrName) {
/* 225 */     TIFFAttrInfo info = getAttrInfo(elementName, attrName);
/* 226 */     return info.listMaxLength;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getAttributeDescription(String elementName, String attrName, Locale locale) {
/* 231 */     String key = elementName + "/" + attrName;
/* 232 */     if (!this.attrInfoMap.containsKey(key)) {
/* 233 */       throw new IllegalArgumentException("No such attribute: " + key);
/*     */     }
/* 235 */     return getResource(key, locale);
/*     */   }
/*     */   
/*     */   public int getObjectValueType(String elementName) {
/* 239 */     TIFFElementInfo info = getElementInfo(elementName);
/* 240 */     return info.objectValueType;
/*     */   }
/*     */   
/*     */   public Class getObjectClass(String elementName) {
/* 244 */     TIFFElementInfo info = getElementInfo(elementName);
/* 245 */     if (info.objectValueType == 0) {
/* 246 */       throw new IllegalArgumentException("Element cannot contain an object value: " + elementName);
/*     */     }
/*     */     
/* 249 */     return info.objectClass;
/*     */   }
/*     */   
/*     */   public Object getObjectDefaultValue(String elementName) {
/* 253 */     TIFFElementInfo info = getElementInfo(elementName);
/* 254 */     if (info.objectValueType == 0) {
/* 255 */       throw new IllegalArgumentException("Element cannot contain an object value: " + elementName);
/*     */     }
/*     */     
/* 258 */     return info.objectDefaultValue;
/*     */   }
/*     */   
/*     */   public Object[] getObjectEnumerations(String elementName) {
/* 262 */     TIFFElementInfo info = getElementInfo(elementName);
/* 263 */     if (info.objectValueType == 0) {
/* 264 */       throw new IllegalArgumentException("Element cannot contain an object value: " + elementName);
/*     */     }
/*     */     
/* 267 */     return info.objectEnumerations;
/*     */   }
/*     */   
/*     */   public Comparable getObjectMinValue(String elementName) {
/* 271 */     TIFFElementInfo info = getElementInfo(elementName);
/* 272 */     if (info.objectValueType == 0) {
/* 273 */       throw new IllegalArgumentException("Element cannot contain an object value: " + elementName);
/*     */     }
/*     */     
/* 276 */     return info.objectMinValue;
/*     */   }
/*     */   
/*     */   public Comparable getObjectMaxValue(String elementName) {
/* 280 */     TIFFElementInfo info = getElementInfo(elementName);
/* 281 */     if (info.objectValueType == 0) {
/* 282 */       throw new IllegalArgumentException("Element cannot contain an object value: " + elementName);
/*     */     }
/*     */     
/* 285 */     return info.objectMaxValue;
/*     */   }
/*     */   
/*     */   public int getObjectArrayMinLength(String elementName) {
/* 289 */     TIFFElementInfo info = getElementInfo(elementName);
/* 290 */     if (info.objectValueType == 0) {
/* 291 */       throw new IllegalArgumentException("Element cannot contain an object value: " + elementName);
/*     */     }
/*     */     
/* 294 */     return info.objectArrayMinLength;
/*     */   }
/*     */   
/*     */   public int getObjectArrayMaxLength(String elementName) {
/* 298 */     TIFFElementInfo info = getElementInfo(elementName);
/* 299 */     if (info.objectValueType == 0) {
/* 300 */       throw new IllegalArgumentException("Element cannot contain an object value: " + elementName);
/*     */     }
/*     */     
/* 303 */     return info.objectArrayMaxLength;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/tiff/TIFFMetadataFormat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */