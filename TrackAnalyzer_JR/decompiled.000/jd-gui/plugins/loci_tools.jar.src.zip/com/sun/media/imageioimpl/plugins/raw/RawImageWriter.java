/*     */ package com.sun.media.imageioimpl.plugins.raw;
/*     */ 
/*     */ import com.sun.media.imageioimpl.common.ImageUtil;
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.image.ColorModel;
/*     */ import java.awt.image.ComponentSampleModel;
/*     */ import java.awt.image.DataBuffer;
/*     */ import java.awt.image.DataBufferByte;
/*     */ import java.awt.image.DataBufferDouble;
/*     */ import java.awt.image.DataBufferFloat;
/*     */ import java.awt.image.DataBufferInt;
/*     */ import java.awt.image.DataBufferShort;
/*     */ import java.awt.image.DataBufferUShort;
/*     */ import java.awt.image.Raster;
/*     */ import java.awt.image.RenderedImage;
/*     */ import java.awt.image.SampleModel;
/*     */ import java.awt.image.WritableRaster;
/*     */ import java.io.IOException;
/*     */ import javax.imageio.IIOImage;
/*     */ import javax.imageio.ImageTypeSpecifier;
/*     */ import javax.imageio.ImageWriteParam;
/*     */ import javax.imageio.ImageWriter;
/*     */ import javax.imageio.metadata.IIOMetadata;
/*     */ import javax.imageio.spi.ImageWriterSpi;
/*     */ import javax.imageio.stream.ImageOutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RawImageWriter
/*     */   extends ImageWriter
/*     */ {
/* 160 */   private ImageOutputStream stream = null;
/*     */   
/*     */   private int imageIndex;
/*     */   
/*     */   private int tileWidth;
/*     */   
/*     */   private int tileHeight;
/*     */   
/*     */   private int tileXOffset;
/*     */   
/*     */   private int tileYOffset;
/*     */   
/*     */   private int scaleX;
/*     */   
/*     */   private int scaleY;
/*     */   
/*     */   private int xOffset;
/*     */   private int yOffset;
/* 178 */   private int[] sourceBands = null;
/*     */ 
/*     */   
/*     */   private int numBands;
/*     */ 
/*     */   
/*     */   private RenderedImage input;
/*     */ 
/*     */   
/*     */   private Raster inputRaster;
/*     */   
/* 189 */   private Rectangle destinationRegion = null;
/*     */ 
/*     */   
/*     */   private SampleModel sampleModel;
/*     */ 
/*     */   
/*     */   private boolean noTransform = true;
/*     */ 
/*     */   
/*     */   private boolean noSubband = true;
/*     */   
/*     */   private boolean writeRaster = false;
/*     */   
/*     */   private boolean optimal = false;
/*     */   
/*     */   private int pxlStride;
/*     */   
/*     */   private int lineStride;
/*     */   
/*     */   private int bandStride;
/*     */ 
/*     */   
/*     */   public RawImageWriter(ImageWriterSpi originator) {
/* 212 */     super(originator);
/*     */   }
/*     */   
/*     */   public void setOutput(Object output) {
/* 216 */     super.setOutput(output);
/* 217 */     if (output != null) {
/* 218 */       if (!(output instanceof ImageOutputStream))
/* 219 */         throw new IllegalArgumentException(I18N.getString("RawImageWriter0")); 
/* 220 */       this.stream = (ImageOutputStream)output;
/*     */     } else {
/* 222 */       this.stream = null;
/*     */     } 
/*     */   }
/*     */   public IIOMetadata getDefaultStreamMetadata(ImageWriteParam param) {
/* 226 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public IIOMetadata getDefaultImageMetadata(ImageTypeSpecifier imageType, ImageWriteParam param) {
/* 231 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public IIOMetadata convertStreamMetadata(IIOMetadata inData, ImageWriteParam param) {
/* 236 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IIOMetadata convertImageMetadata(IIOMetadata metadata, ImageTypeSpecifier type, ImageWriteParam param) {
/* 242 */     return null;
/*     */   }
/*     */   
/*     */   public boolean canWriteRasters() {
/* 246 */     return true;
/*     */   }
/*     */   
/*     */   public ImageWriteParam getDefaultWriteParam() {
/* 250 */     return new RawImageWriteParam(getLocale());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(IIOMetadata streamMetadata, IIOImage image, ImageWriteParam param) throws IOException {
/* 256 */     clearAbortRequest();
/* 257 */     processImageStarted(this.imageIndex++);
/*     */     
/* 259 */     if (param == null) {
/* 260 */       param = getDefaultWriteParam();
/*     */     }
/* 262 */     this.writeRaster = image.hasRaster();
/* 263 */     Rectangle sourceRegion = param.getSourceRegion();
/* 264 */     ColorModel colorModel = null;
/* 265 */     Rectangle originalRegion = null;
/*     */     
/* 267 */     if (this.writeRaster) {
/* 268 */       this.inputRaster = image.getRaster();
/* 269 */       this.sampleModel = this.inputRaster.getSampleModel();
/* 270 */       originalRegion = this.inputRaster.getBounds();
/*     */     } else {
/* 272 */       this.input = image.getRenderedImage();
/* 273 */       this.sampleModel = this.input.getSampleModel();
/*     */       
/* 275 */       originalRegion = new Rectangle(this.input.getMinX(), this.input.getMinY(), this.input.getWidth(), this.input.getHeight());
/*     */ 
/*     */       
/* 278 */       colorModel = this.input.getColorModel();
/*     */     } 
/*     */     
/* 281 */     if (sourceRegion == null) {
/* 282 */       sourceRegion = (Rectangle)originalRegion.clone();
/*     */     } else {
/* 284 */       sourceRegion = sourceRegion.intersection(originalRegion);
/*     */     } 
/* 286 */     if (sourceRegion.isEmpty()) {
/* 287 */       throw new RuntimeException(I18N.getString("RawImageWriter1"));
/*     */     }
/* 289 */     this.scaleX = param.getSourceXSubsampling();
/* 290 */     this.scaleY = param.getSourceYSubsampling();
/* 291 */     this.xOffset = param.getSubsamplingXOffset();
/* 292 */     this.yOffset = param.getSubsamplingYOffset();
/*     */     
/* 294 */     sourceRegion.translate(this.xOffset, this.yOffset);
/* 295 */     sourceRegion.width -= this.xOffset;
/* 296 */     sourceRegion.height -= this.yOffset;
/*     */     
/* 298 */     this.xOffset = sourceRegion.x % this.scaleX;
/* 299 */     this.yOffset = sourceRegion.y % this.scaleY;
/*     */     
/* 301 */     int minX = sourceRegion.x / this.scaleX;
/* 302 */     int minY = sourceRegion.y / this.scaleY;
/* 303 */     int w = (sourceRegion.width + this.scaleX - 1) / this.scaleX;
/* 304 */     int h = (sourceRegion.height + this.scaleY - 1) / this.scaleY;
/*     */     
/* 306 */     this.destinationRegion = new Rectangle(minX, minY, w, h);
/* 307 */     this.noTransform = this.destinationRegion.equals(originalRegion);
/*     */     
/* 309 */     this.tileHeight = this.sampleModel.getHeight();
/* 310 */     this.tileWidth = this.sampleModel.getWidth();
/* 311 */     if (this.noTransform) {
/* 312 */       if (this.writeRaster) {
/* 313 */         this.tileXOffset = this.inputRaster.getMinX();
/* 314 */         this.tileYOffset = this.inputRaster.getMinY();
/*     */       } else {
/* 316 */         this.tileXOffset = this.input.getTileGridXOffset();
/* 317 */         this.tileYOffset = this.input.getTileGridYOffset();
/*     */       } 
/*     */     } else {
/* 320 */       this.tileXOffset = this.destinationRegion.x;
/* 321 */       this.tileYOffset = this.destinationRegion.y;
/*     */     } 
/*     */     
/* 324 */     this.sourceBands = param.getSourceBands();
/* 325 */     boolean noSubband = true;
/* 326 */     this.numBands = this.sampleModel.getNumBands();
/*     */     
/* 328 */     if (this.sourceBands != null) {
/* 329 */       this.sampleModel = this.sampleModel.createSubsetSampleModel(this.sourceBands);
/* 330 */       colorModel = null;
/* 331 */       noSubband = false;
/* 332 */       this.numBands = this.sampleModel.getNumBands();
/*     */     } else {
/* 334 */       this.sourceBands = new int[this.numBands];
/* 335 */       for (int i = 0; i < this.numBands; i++) {
/* 336 */         this.sourceBands[i] = i;
/*     */       }
/*     */     } 
/* 339 */     if (this.sampleModel instanceof ComponentSampleModel) {
/* 340 */       ComponentSampleModel csm = (ComponentSampleModel)this.sampleModel;
/* 341 */       int[] bandOffsets = csm.getBandOffsets();
/*     */       
/* 343 */       this.bandStride = bandOffsets[0];
/*     */       
/* 345 */       for (int i = 1; i < bandOffsets.length; i++) {
/* 346 */         if (this.bandStride > bandOffsets[i])
/* 347 */           this.bandStride = bandOffsets[i]; 
/*     */       } 
/* 349 */       int[] bankIndices = csm.getBankIndices();
/* 350 */       int numBank = bankIndices[0];
/* 351 */       for (int j = 1; j < bankIndices.length; j++) {
/* 352 */         if (numBank > bankIndices[j])
/* 353 */           numBank = bankIndices[j]; 
/*     */       } 
/* 355 */       this.pxlStride = csm.getPixelStride();
/* 356 */       this.lineStride = csm.getScanlineStride();
/*     */       
/* 358 */       this.optimal = (this.bandStride == 0 || (this.pxlStride < this.lineStride && this.pxlStride == this.numBands) || (this.lineStride < this.pxlStride && this.lineStride == this.numBands) || (this.pxlStride < this.lineStride && this.lineStride == this.numBands * csm.getWidth()) || (this.lineStride < this.pxlStride && this.pxlStride == this.numBands * csm.getHeight()) || csm instanceof java.awt.image.BandedSampleModel);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 366 */     else if (this.sampleModel instanceof java.awt.image.SinglePixelPackedSampleModel || this.sampleModel instanceof java.awt.image.MultiPixelPackedSampleModel) {
/*     */       
/* 368 */       this.optimal = true;
/*     */     } 
/*     */     
/* 371 */     int numXTiles = getMaxTileX() - getMinTileX() + 1;
/* 372 */     int totalTiles = numXTiles * (getMaxTileY() - getMinTileY() + 1);
/*     */     
/* 374 */     for (int y = getMinTileY(); y <= getMaxTileY(); y++) {
/* 375 */       for (int x = getMinTileX(); x <= getMaxTileX(); x++) {
/* 376 */         writeRaster(getTile(x, y));
/*     */         
/* 378 */         float percentage = ((x + y * numXTiles) + 1.0F) / totalTiles;
/* 379 */         processImageProgress(percentage * 100.0F);
/*     */       } 
/*     */     } 
/*     */     
/* 383 */     this.stream.flush();
/* 384 */     if (abortRequested()) {
/* 385 */       processWriteAborted();
/*     */     } else {
/* 387 */       processImageComplete();
/*     */     } 
/*     */   }
/*     */   
/*     */   public int getWidth() {
/* 392 */     return this.destinationRegion.width;
/*     */   }
/*     */   
/*     */   public int getHeight() {
/* 396 */     return this.destinationRegion.height;
/*     */   }
/*     */   
/*     */   private void writeRaster(Raster raster) throws IOException {
/* 400 */     int numBank = 0;
/* 401 */     int bandStride = 0;
/* 402 */     int[] bankIndices = null;
/* 403 */     int[] bandOffsets = null;
/* 404 */     int bandSize = 0;
/* 405 */     int numBand = this.sampleModel.getNumBands();
/* 406 */     int type = this.sampleModel.getDataType();
/*     */     
/* 408 */     if (this.sampleModel instanceof ComponentSampleModel) {
/* 409 */       ComponentSampleModel csm = (ComponentSampleModel)this.sampleModel;
/*     */       
/* 411 */       bandOffsets = csm.getBandOffsets(); int i;
/* 412 */       for (i = 0; i < numBand; i++) {
/* 413 */         if (bandStride < bandOffsets[i])
/* 414 */           bandStride = bandOffsets[i]; 
/*     */       } 
/* 416 */       bankIndices = csm.getBankIndices();
/* 417 */       for (i = 0; i < numBand; i++) {
/* 418 */         if (numBank < bankIndices[i])
/* 419 */           numBank = bankIndices[i]; 
/*     */       } 
/* 421 */       bandSize = (int)ImageUtil.getBandSize(this.sampleModel);
/*     */     } 
/*     */     
/* 424 */     byte[] bdata = null;
/* 425 */     short[] sdata = null;
/* 426 */     int[] idata = null;
/* 427 */     float[] fdata = null;
/* 428 */     double[] ddata = null;
/*     */     
/* 430 */     if (raster.getParent() != null && !this.sampleModel.equals(raster.getParent().getSampleModel())) {
/*     */       
/* 432 */       WritableRaster ras = Raster.createWritableRaster(this.sampleModel, new Point(raster.getMinX(), raster.getMinY()));
/*     */ 
/*     */ 
/*     */       
/* 436 */       ras.setRect(raster);
/* 437 */       raster = ras;
/*     */     } 
/*     */     
/* 440 */     DataBuffer data = raster.getDataBuffer();
/*     */     
/* 442 */     if (this.optimal) {
/* 443 */       if (numBank > 0) {
/* 444 */         for (int i = 0; i < this.numBands; i++) {
/* 445 */           int bank = bankIndices[this.sourceBands[i]];
/* 446 */           switch (type) {
/*     */             case 0:
/* 448 */               bdata = ((DataBufferByte)data).getData(bank);
/* 449 */               this.stream.write(bdata, 0, bdata.length);
/*     */               break;
/*     */             case 2:
/* 452 */               sdata = ((DataBufferShort)data).getData(bank);
/* 453 */               this.stream.writeShorts(sdata, 0, sdata.length);
/*     */               break;
/*     */             case 1:
/* 456 */               sdata = ((DataBufferUShort)data).getData(bank);
/* 457 */               this.stream.writeShorts(sdata, 0, sdata.length);
/*     */               break;
/*     */             case 3:
/* 460 */               idata = ((DataBufferInt)data).getData(bank);
/* 461 */               this.stream.writeInts(idata, 0, idata.length);
/*     */               break;
/*     */             case 4:
/* 464 */               fdata = ((DataBufferFloat)data).getData(bank);
/* 465 */               this.stream.writeFloats(fdata, 0, fdata.length);
/*     */               break;
/*     */             case 5:
/* 468 */               ddata = ((DataBufferDouble)data).getData(bank);
/* 469 */               this.stream.writeDoubles(ddata, 0, ddata.length);
/*     */               break;
/*     */           } 
/*     */         } 
/*     */       } else {
/* 474 */         switch (type) {
/*     */           case 0:
/* 476 */             bdata = ((DataBufferByte)data).getData();
/*     */             break;
/*     */           case 2:
/* 479 */             sdata = ((DataBufferShort)data).getData();
/*     */             break;
/*     */           case 1:
/* 482 */             sdata = ((DataBufferUShort)data).getData();
/*     */             break;
/*     */           case 3:
/* 485 */             idata = ((DataBufferInt)data).getData();
/*     */             break;
/*     */           case 4:
/* 488 */             fdata = ((DataBufferFloat)data).getData();
/*     */             break;
/*     */           case 5:
/* 491 */             ddata = ((DataBufferDouble)data).getData();
/*     */             break;
/*     */         } 
/*     */         
/* 495 */         if (!this.noSubband && bandStride >= raster.getWidth() * raster.getHeight() * (this.numBands - 1)) {
/*     */ 
/*     */ 
/*     */           
/* 499 */           for (int i = 0; i < this.numBands; i++) {
/* 500 */             int offset = bandOffsets[this.sourceBands[i]];
/* 501 */             switch (type) {
/*     */               case 0:
/* 503 */                 this.stream.write(bdata, offset, bandSize);
/*     */                 break;
/*     */               case 1:
/*     */               case 2:
/* 507 */                 this.stream.writeShorts(sdata, offset, bandSize);
/*     */                 break;
/*     */               case 3:
/* 510 */                 this.stream.writeInts(idata, offset, bandSize);
/*     */                 break;
/*     */               case 4:
/* 513 */                 this.stream.writeFloats(fdata, offset, bandSize);
/*     */                 break;
/*     */               case 5:
/* 516 */                 this.stream.writeDoubles(ddata, offset, bandSize);
/*     */                 break;
/*     */             } 
/*     */           } 
/*     */         } else {
/* 521 */           switch (type) {
/*     */             case 0:
/* 523 */               this.stream.write(bdata, 0, bdata.length);
/*     */               break;
/*     */             case 1:
/*     */             case 2:
/* 527 */               this.stream.writeShorts(sdata, 0, sdata.length);
/*     */               break;
/*     */             case 3:
/* 530 */               this.stream.writeInts(idata, 0, idata.length);
/*     */               break;
/*     */             case 4:
/* 533 */               this.stream.writeFloats(fdata, 0, fdata.length);
/*     */               break;
/*     */             case 5:
/* 536 */               this.stream.writeDoubles(ddata, 0, ddata.length);
/*     */               break;
/*     */           } 
/*     */         } 
/*     */       } 
/* 541 */     } else if (this.sampleModel instanceof ComponentSampleModel) {
/*     */       
/* 543 */       switch (type) {
/*     */         case 0:
/* 545 */           bdata = ((DataBufferByte)data).getData();
/*     */           break;
/*     */         case 2:
/* 548 */           sdata = ((DataBufferShort)data).getData();
/*     */           break;
/*     */         case 1:
/* 551 */           sdata = ((DataBufferUShort)data).getData();
/*     */           break;
/*     */         case 3:
/* 554 */           idata = ((DataBufferInt)data).getData();
/*     */           break;
/*     */         case 4:
/* 557 */           fdata = ((DataBufferFloat)data).getData();
/*     */           break;
/*     */         case 5:
/* 560 */           ddata = ((DataBufferDouble)data).getData();
/*     */           break;
/*     */       } 
/*     */       
/* 564 */       ComponentSampleModel csm = (ComponentSampleModel)this.sampleModel;
/* 565 */       int offset = csm.getOffset(raster.getMinX() - raster.getSampleModelTranslateX(), raster.getMinY() - raster.getSampleModelTranslateY()) - bandOffsets[0];
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 570 */       int srcSkip = this.pxlStride;
/* 571 */       int copyLength = 1;
/* 572 */       int innerStep = this.pxlStride;
/*     */       
/* 574 */       int width = raster.getWidth();
/* 575 */       int height = raster.getHeight();
/*     */       
/* 577 */       int innerBound = width;
/* 578 */       int outerBound = height;
/*     */       
/* 580 */       if (srcSkip < this.lineStride) {
/* 581 */         if (bandStride > this.pxlStride)
/* 582 */           copyLength = width; 
/* 583 */         srcSkip = this.lineStride;
/*     */       } else {
/* 585 */         if (bandStride > this.lineStride)
/* 586 */           copyLength = height; 
/* 587 */         innerStep = this.lineStride;
/* 588 */         innerBound = height;
/* 589 */         outerBound = width;
/*     */       } 
/*     */       
/* 592 */       int writeLength = innerBound * this.numBands;
/* 593 */       byte[] destBBuf = null;
/* 594 */       short[] destSBuf = null;
/* 595 */       int[] destIBuf = null;
/* 596 */       float[] destFBuf = null;
/* 597 */       double[] destDBuf = null;
/* 598 */       Object srcBuf = null;
/* 599 */       Object dstBuf = null;
/*     */       
/* 601 */       switch (type) {
/*     */         case 0:
/* 603 */           srcBuf = bdata;
/* 604 */           dstBuf = destBBuf = new byte[writeLength];
/*     */           break;
/*     */         case 1:
/*     */         case 2:
/* 608 */           srcBuf = sdata;
/* 609 */           dstBuf = destSBuf = new short[writeLength];
/*     */           break;
/*     */         case 3:
/* 612 */           srcBuf = idata;
/* 613 */           dstBuf = destIBuf = new int[writeLength];
/*     */           break;
/*     */         case 4:
/* 616 */           srcBuf = fdata;
/* 617 */           dstBuf = destFBuf = new float[writeLength];
/*     */           break;
/*     */         case 5:
/* 620 */           srcBuf = ddata;
/* 621 */           dstBuf = destDBuf = new double[writeLength];
/*     */           break;
/*     */       } 
/*     */       
/* 625 */       if (copyLength > 1) {
/* 626 */         for (int i = 0; i < outerBound; i++) {
/* 627 */           for (int b = 0; b < this.numBands; b++) {
/* 628 */             int bandOffset = bandOffsets[b];
/*     */             
/* 630 */             System.arraycopy(srcBuf, offset + bandOffset, dstBuf, b * innerBound, innerBound);
/*     */           } 
/*     */ 
/*     */           
/* 634 */           switch (type) {
/*     */             case 0:
/* 636 */               this.stream.write((byte[])dstBuf, 0, writeLength);
/*     */               break;
/*     */             case 1:
/*     */             case 2:
/* 640 */               this.stream.writeShorts((short[])dstBuf, 0, writeLength);
/*     */               break;
/*     */             case 3:
/* 643 */               this.stream.writeInts((int[])dstBuf, 0, writeLength);
/*     */               break;
/*     */             case 4:
/* 646 */               this.stream.writeFloats((float[])dstBuf, 0, writeLength);
/*     */               break;
/*     */             case 5:
/* 649 */               this.stream.writeDoubles((double[])dstBuf, 0, writeLength);
/*     */               break;
/*     */           } 
/* 652 */           offset += srcSkip;
/*     */         } 
/*     */       } else {
/* 655 */         int i; switch (type) {
/*     */           case 0:
/* 657 */             for (i = 0; i < outerBound; i++) {
/* 658 */               for (int b = 0, k = 0; b < this.numBands; b++) {
/* 659 */                 int bandOffset = bandOffsets[b];
/*     */                 int m;
/* 661 */                 for (int j = 0; j < innerBound; 
/* 662 */                   j++, m += innerStep)
/*     */                 {
/* 664 */                   destBBuf[k++] = bdata[m + bandOffset];
/*     */                 }
/*     */               } 
/* 667 */               this.stream.write(destBBuf, 0, writeLength);
/* 668 */               offset += srcSkip;
/*     */             } 
/*     */             break;
/*     */           
/*     */           case 1:
/*     */           case 2:
/* 674 */             for (i = 0; i < outerBound; i++) {
/* 675 */               for (int b = 0, k = 0; b < this.numBands; b++) {
/* 676 */                 int bandOffset = bandOffsets[b];
/*     */                 int m;
/* 678 */                 for (int j = 0; j < innerBound; 
/* 679 */                   j++, m += innerStep)
/*     */                 {
/* 681 */                   destSBuf[k++] = sdata[m + bandOffset];
/*     */                 }
/*     */               } 
/* 684 */               this.stream.writeShorts(destSBuf, 0, writeLength);
/* 685 */               offset += srcSkip;
/*     */             } 
/*     */             break;
/*     */           
/*     */           case 3:
/* 690 */             for (i = 0; i < outerBound; i++) {
/* 691 */               for (int b = 0, k = 0; b < this.numBands; b++) {
/* 692 */                 int bandOffset = bandOffsets[b];
/*     */                 int m;
/* 694 */                 for (int j = 0; j < innerBound; 
/* 695 */                   j++, m += innerStep)
/*     */                 {
/* 697 */                   destIBuf[k++] = idata[m + bandOffset];
/*     */                 }
/*     */               } 
/* 700 */               this.stream.writeInts(destIBuf, 0, writeLength);
/* 701 */               offset += srcSkip;
/*     */             } 
/*     */             break;
/*     */           
/*     */           case 4:
/* 706 */             for (i = 0; i < outerBound; i++) {
/* 707 */               for (int b = 0, k = 0; b < this.numBands; b++) {
/* 708 */                 int bandOffset = bandOffsets[b];
/*     */                 int m;
/* 710 */                 for (int j = 0; j < innerBound; 
/* 711 */                   j++, m += innerStep)
/*     */                 {
/* 713 */                   destFBuf[k++] = fdata[m + bandOffset];
/*     */                 }
/*     */               } 
/* 716 */               this.stream.writeFloats(destFBuf, 0, writeLength);
/* 717 */               offset += srcSkip;
/*     */             } 
/*     */             break;
/*     */           
/*     */           case 5:
/* 722 */             for (i = 0; i < outerBound; i++) {
/* 723 */               for (int b = 0, k = 0; b < this.numBands; b++) {
/* 724 */                 int bandOffset = bandOffsets[b];
/*     */                 int m;
/* 726 */                 for (int j = 0; j < innerBound; 
/* 727 */                   j++, m += innerStep)
/*     */                 {
/* 729 */                   destDBuf[k++] = ddata[m + bandOffset];
/*     */                 }
/*     */               } 
/* 732 */               this.stream.writeDoubles(destDBuf, 0, writeLength);
/* 733 */               offset += srcSkip;
/*     */             } 
/*     */             break;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private Raster getTile(int tileX, int tileY) {
/* 743 */     int sx = this.tileXOffset + tileX * this.tileWidth;
/* 744 */     int sy = this.tileYOffset + tileY * this.tileHeight;
/* 745 */     Rectangle bounds = new Rectangle(sx, sy, this.tileWidth, this.tileHeight);
/*     */     
/* 747 */     if (this.writeRaster) {
/* 748 */       bounds = bounds.intersection(this.destinationRegion);
/* 749 */       if (this.noTransform) {
/* 750 */         return this.inputRaster.createChild(bounds.x, bounds.y, bounds.width, bounds.height, bounds.x, bounds.y, this.sourceBands);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 755 */       sx = bounds.x;
/* 756 */       sy = bounds.y;
/*     */       
/* 758 */       WritableRaster writableRaster = Raster.createWritableRaster(this.sampleModel, new Point(sx, sy));
/*     */ 
/*     */       
/* 761 */       int i = mapToSourceX(sx);
/* 762 */       int k = mapToSourceY(sy);
/*     */       
/* 764 */       int m = this.inputRaster.getMinY();
/* 765 */       int n = this.inputRaster.getMinY() + this.inputRaster.getHeight();
/*     */       
/* 767 */       int i1 = bounds.width;
/*     */       
/* 769 */       int i2 = (i1 - 1) * this.scaleX + 1;
/*     */       
/* 771 */       for (int i3 = 0; i3 < bounds.height; i3++, sy++, k += this.scaleY) {
/* 772 */         if (k >= m && k < n) {
/*     */           
/* 774 */           Raster source = this.inputRaster.createChild(i, k, i2, 1, i, k, null);
/*     */ 
/*     */           
/* 777 */           int tempX = sx; int offset;
/* 778 */           for (int i4 = 0; i4 < i1; 
/* 779 */             i4++, tempX++, offset += this.scaleX) {
/* 780 */             for (int i5 = 0; i5 < this.numBands; i5++) {
/* 781 */               int p = source.getSample(offset, k, this.sourceBands[i5]);
/* 782 */               writableRaster.setSample(tempX, sy, i5, p);
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/* 787 */       return writableRaster;
/*     */     } 
/*     */     
/* 790 */     if (this.noTransform) {
/* 791 */       Raster raster = this.input.getTile(tileX, tileY);
/* 792 */       if (this.destinationRegion.contains(bounds) && this.noSubband) {
/* 793 */         return raster;
/*     */       }
/* 795 */       bounds = bounds.intersection(this.destinationRegion);
/* 796 */       return raster.createChild(bounds.x, bounds.y, bounds.width, bounds.height, bounds.x, bounds.y, this.sourceBands);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 802 */     bounds = bounds.intersection(this.destinationRegion);
/* 803 */     sx = bounds.x;
/* 804 */     sy = bounds.y;
/*     */     
/* 806 */     WritableRaster ras = Raster.createWritableRaster(this.sampleModel, new Point(sx, sy));
/*     */ 
/*     */     
/* 809 */     int x = mapToSourceX(sx);
/* 810 */     int y = mapToSourceY(sy);
/*     */     
/* 812 */     int minY = this.input.getMinY();
/* 813 */     int maxY = this.input.getMinY() + this.input.getHeight();
/*     */     
/* 815 */     int cTileWidth = bounds.width;
/* 816 */     int length = (cTileWidth - 1) * this.scaleX + 1;
/*     */     
/* 818 */     for (int j = 0; j < bounds.height; j++, sy++, y += this.scaleY) {
/* 819 */       if (y >= minY && y < maxY) {
/*     */ 
/*     */         
/* 822 */         Raster source = this.input.getData(new Rectangle(x, y, length, 1));
/*     */ 
/*     */         
/* 825 */         int tempX = sx; int offset;
/* 826 */         for (int i = 0; i < cTileWidth; 
/* 827 */           i++, tempX++, offset += this.scaleX) {
/* 828 */           for (int k = 0; k < this.numBands; k++) {
/* 829 */             int p = source.getSample(offset, y, this.sourceBands[k]);
/* 830 */             ras.setSample(tempX, sy, k, p);
/*     */           } 
/*     */         } 
/*     */       } 
/* 834 */     }  return ras;
/*     */   }
/*     */ 
/*     */   
/*     */   private int mapToSourceX(int x) {
/* 839 */     return x * this.scaleX + this.xOffset;
/*     */   }
/*     */   
/*     */   private int mapToSourceY(int y) {
/* 843 */     return y * this.scaleY + this.yOffset;
/*     */   }
/*     */   
/*     */   private int getMinTileX() {
/* 847 */     return ToTile(this.destinationRegion.x, this.tileXOffset, this.tileWidth);
/*     */   }
/*     */   
/*     */   private int getMaxTileX() {
/* 851 */     return ToTile(this.destinationRegion.x + this.destinationRegion.width - 1, this.tileXOffset, this.tileWidth);
/*     */   }
/*     */ 
/*     */   
/*     */   private int getMinTileY() {
/* 856 */     return ToTile(this.destinationRegion.y, this.tileYOffset, this.tileHeight);
/*     */   }
/*     */   
/*     */   private int getMaxTileY() {
/* 860 */     return ToTile(this.destinationRegion.y + this.destinationRegion.height - 1, this.tileYOffset, this.tileHeight);
/*     */   }
/*     */ 
/*     */   
/*     */   private static int ToTile(int pos, int tileOffset, int tileSize) {
/* 865 */     pos -= tileOffset;
/* 866 */     if (pos < 0) {
/* 867 */       pos += 1 - tileSize;
/*     */     }
/* 869 */     return pos / tileSize;
/*     */   }
/*     */   
/*     */   public void reset() {
/* 873 */     super.reset();
/* 874 */     this.stream = null;
/* 875 */     this.optimal = false;
/* 876 */     this.sourceBands = null;
/* 877 */     this.destinationRegion = null;
/* 878 */     this.noTransform = true;
/* 879 */     this.noSubband = true;
/* 880 */     this.writeRaster = false;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/raw/RawImageWriter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */