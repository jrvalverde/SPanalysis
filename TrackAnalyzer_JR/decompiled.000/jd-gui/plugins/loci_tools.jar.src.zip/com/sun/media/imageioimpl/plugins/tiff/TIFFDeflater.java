/*     */ package com.sun.media.imageioimpl.plugins.tiff;
/*     */ 
/*     */ import com.sun.media.imageio.plugins.tiff.TIFFCompressor;
/*     */ import java.io.IOException;
/*     */ import java.util.zip.Deflater;
/*     */ import javax.imageio.ImageWriteParam;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TIFFDeflater
/*     */   extends TIFFCompressor
/*     */ {
/*     */   Deflater deflater;
/*     */   int predictor;
/*     */   
/*     */   public TIFFDeflater(String compressionType, int compressionTagValue, ImageWriteParam param, int predictorValue) {
/* 101 */     super(compressionType, compressionTagValue, true);
/*     */     int deflateLevel;
/* 103 */     this.predictor = predictorValue;
/*     */ 
/*     */ 
/*     */     
/* 107 */     if (param != null && param.getCompressionMode() == 2) {
/*     */       
/* 109 */       float quality = param.getCompressionQuality();
/* 110 */       deflateLevel = (int)(1.0F + 8.0F * quality);
/*     */     } else {
/* 112 */       deflateLevel = -1;
/*     */     } 
/*     */     
/* 115 */     this.deflater = new Deflater(deflateLevel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int encode(byte[] b, int off, int width, int height, int[] bitsPerSample, int scanlineStride) throws IOException {
/* 123 */     int inputSize = height * scanlineStride;
/* 124 */     int blocks = (inputSize + 32767) / 32768;
/*     */ 
/*     */ 
/*     */     
/* 128 */     byte[] compData = new byte[inputSize + 5 * blocks + 6];
/*     */     
/* 130 */     int numCompressedBytes = 0;
/* 131 */     if (this.predictor == 2) {
/* 132 */       int samplesPerPixel = bitsPerSample.length;
/* 133 */       int bitsPerPixel = 0;
/* 134 */       for (int i = 0; i < samplesPerPixel; i++) {
/* 135 */         bitsPerPixel += bitsPerSample[i];
/*     */       }
/* 137 */       int bytesPerRow = (bitsPerPixel * width + 7) / 8;
/* 138 */       byte[] rowBuf = new byte[bytesPerRow];
/*     */       
/* 140 */       int maxRow = height - 1;
/* 141 */       for (int j = 0; j < height; j++) {
/*     */ 
/*     */         
/* 144 */         System.arraycopy(b, off, rowBuf, 0, bytesPerRow);
/* 145 */         for (int k = bytesPerRow - 1; k >= samplesPerPixel; k--) {
/* 146 */           rowBuf[k] = (byte)(rowBuf[k] - rowBuf[k - samplesPerPixel]);
/*     */         }
/*     */         
/* 149 */         this.deflater.setInput(rowBuf);
/* 150 */         if (j == maxRow) {
/* 151 */           this.deflater.finish();
/*     */         }
/*     */         
/* 154 */         int numBytes = 0;
/*     */ 
/*     */ 
/*     */         
/* 158 */         while ((numBytes = this.deflater.deflate(compData, numCompressedBytes, compData.length - numCompressedBytes)) != 0) {
/* 159 */           numCompressedBytes += numBytes;
/*     */         }
/*     */         
/* 162 */         off += scanlineStride;
/*     */       } 
/*     */     } else {
/* 165 */       this.deflater.setInput(b, off, height * scanlineStride);
/* 166 */       this.deflater.finish();
/*     */       
/* 168 */       numCompressedBytes = this.deflater.deflate(compData);
/*     */     } 
/*     */     
/* 171 */     this.deflater.reset();
/*     */     
/* 173 */     this.stream.write(compData, 0, numCompressedBytes);
/*     */     
/* 175 */     return numCompressedBytes;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/tiff/TIFFDeflater.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */