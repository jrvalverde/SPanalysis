/*     */ package com.sun.media.imageioimpl.plugins.tiff;
/*     */ 
/*     */ import com.sun.media.imageio.plugins.tiff.TIFFImageReadParam;
/*     */ import com.sun.media.imageio.plugins.tiff.TIFFTagSet;
/*     */ import java.awt.Image;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.ColorModel;
/*     */ import java.awt.image.Raster;
/*     */ import java.awt.image.RenderedImage;
/*     */ import java.awt.image.SampleModel;
/*     */ import java.awt.image.WritableRaster;
/*     */ import java.io.IOException;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Vector;
/*     */ import javax.imageio.ImageReadParam;
/*     */ import javax.imageio.ImageTypeSpecifier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TIFFRenderedImage
/*     */   implements RenderedImage
/*     */ {
/*     */   TIFFImageReader reader;
/*     */   int imageIndex;
/*     */   ImageReadParam tileParam;
/*     */   int subsampleX;
/*     */   int subsampleY;
/*     */   boolean isSubsampling;
/*     */   int width;
/*     */   int height;
/*     */   int tileWidth;
/*     */   int tileHeight;
/*     */   ImageTypeSpecifier its;
/*     */   
/*     */   public TIFFRenderedImage(TIFFImageReader reader, int imageIndex, ImageReadParam readParam, int width, int height) throws IOException {
/* 121 */     this.reader = reader;
/* 122 */     this.imageIndex = imageIndex;
/* 123 */     this.tileParam = cloneImageReadParam(readParam, false);
/*     */     
/* 125 */     this.subsampleX = this.tileParam.getSourceXSubsampling();
/* 126 */     this.subsampleY = this.tileParam.getSourceYSubsampling();
/*     */     
/* 128 */     this.isSubsampling = (this.subsampleX != 1 || this.subsampleY != 1);
/*     */     
/* 130 */     this.width = width / this.subsampleX;
/* 131 */     this.height = height / this.subsampleY;
/*     */ 
/*     */ 
/*     */     
/* 135 */     this.tileWidth = reader.getTileWidth(imageIndex) / this.subsampleX;
/* 136 */     this.tileHeight = reader.getTileHeight(imageIndex) / this.subsampleY;
/*     */     
/* 138 */     Iterator<ImageTypeSpecifier> iter = reader.getImageTypes(imageIndex);
/* 139 */     this.its = iter.next();
/* 140 */     this.tileParam.setDestinationType(this.its);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImageReadParam cloneImageReadParam(ImageReadParam param, boolean copyTagSets) {
/* 159 */     TIFFImageReadParam newParam = new TIFFImageReadParam();
/*     */ 
/*     */     
/* 162 */     newParam.setSourceSubsampling(param.getSourceXSubsampling(), param.getSourceYSubsampling(), param.getSubsamplingXOffset(), param.getSubsamplingYOffset());
/*     */ 
/*     */ 
/*     */     
/* 166 */     newParam.setSourceBands(param.getSourceBands());
/* 167 */     newParam.setDestinationBands(param.getDestinationBands());
/* 168 */     newParam.setDestinationOffset(param.getDestinationOffset());
/*     */ 
/*     */     
/* 171 */     if (param instanceof TIFFImageReadParam) {
/*     */       
/* 173 */       TIFFImageReadParam tparam = (TIFFImageReadParam)param;
/* 174 */       newParam.setTIFFDecompressor(tparam.getTIFFDecompressor());
/* 175 */       newParam.setColorConverter(tparam.getColorConverter());
/*     */       
/* 177 */       if (copyTagSets) {
/* 178 */         List tagSets = tparam.getAllowedTagSets();
/* 179 */         if (tagSets != null) {
/* 180 */           Iterator<TIFFTagSet> tagSetIter = tagSets.iterator();
/* 181 */           if (tagSetIter != null) {
/* 182 */             while (tagSetIter.hasNext()) {
/* 183 */               TIFFTagSet tagSet = tagSetIter.next();
/* 184 */               newParam.addAllowedTagSet(tagSet);
/*     */             } 
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } else {
/*     */       
/* 191 */       newParam.setTIFFDecompressor(null);
/* 192 */       newParam.setColorConverter(null);
/*     */     } 
/*     */     
/* 195 */     return (ImageReadParam)newParam;
/*     */   }
/*     */   
/*     */   public Vector getSources() {
/* 199 */     return null;
/*     */   }
/*     */   
/*     */   public Object getProperty(String name) {
/* 203 */     return Image.UndefinedProperty;
/*     */   }
/*     */   
/*     */   public String[] getPropertyNames() {
/* 207 */     return null;
/*     */   }
/*     */   
/*     */   public ColorModel getColorModel() {
/* 211 */     return this.its.getColorModel();
/*     */   }
/*     */   
/*     */   public SampleModel getSampleModel() {
/* 215 */     return this.its.getSampleModel();
/*     */   }
/*     */   
/*     */   public int getWidth() {
/* 219 */     return this.width;
/*     */   }
/*     */   
/*     */   public int getHeight() {
/* 223 */     return this.height;
/*     */   }
/*     */   
/*     */   public int getMinX() {
/* 227 */     return 0;
/*     */   }
/*     */   
/*     */   public int getMinY() {
/* 231 */     return 0;
/*     */   }
/*     */   
/*     */   public int getNumXTiles() {
/* 235 */     return (this.width + this.tileWidth - 1) / this.tileWidth;
/*     */   }
/*     */   
/*     */   public int getNumYTiles() {
/* 239 */     return (this.height + this.tileHeight - 1) / this.tileHeight;
/*     */   }
/*     */   
/*     */   public int getMinTileX() {
/* 243 */     return 0;
/*     */   }
/*     */   
/*     */   public int getMinTileY() {
/* 247 */     return 0;
/*     */   }
/*     */   
/*     */   public int getTileWidth() {
/* 251 */     return this.tileWidth;
/*     */   }
/*     */   
/*     */   public int getTileHeight() {
/* 255 */     return this.tileHeight;
/*     */   }
/*     */   
/*     */   public int getTileGridXOffset() {
/* 259 */     return 0;
/*     */   }
/*     */   
/*     */   public int getTileGridYOffset() {
/* 263 */     return 0;
/*     */   }
/*     */   
/*     */   public Raster getTile(int tileX, int tileY) {
/* 267 */     Rectangle tileRect = new Rectangle(tileX * this.tileWidth, tileY * this.tileHeight, this.tileWidth, this.tileHeight);
/*     */ 
/*     */ 
/*     */     
/* 271 */     return getData(tileRect);
/*     */   }
/*     */   
/*     */   public Raster getData() {
/* 275 */     return read(new Rectangle(0, 0, getWidth(), getHeight()));
/*     */   }
/*     */   
/*     */   public Raster getData(Rectangle rect) {
/* 279 */     return read(rect);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized WritableRaster read(Rectangle rect) {
/* 287 */     this.tileParam.setSourceRegion(this.isSubsampling ? new Rectangle(this.subsampleX * rect.x, this.subsampleY * rect.y, this.subsampleX * rect.width, this.subsampleY * rect.height) : rect);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 295 */       BufferedImage bi = this.reader.read(this.imageIndex, this.tileParam);
/* 296 */       WritableRaster ras = bi.getRaster();
/* 297 */       return ras.createWritableChild(0, 0, ras.getWidth(), ras.getHeight(), rect.x, rect.y, (int[])null);
/*     */ 
/*     */     
/*     */     }
/* 301 */     catch (IOException e) {
/* 302 */       throw new RuntimeException(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public WritableRaster copyData(WritableRaster raster) {
/* 307 */     if (raster == null) {
/* 308 */       return read(new Rectangle(0, 0, getWidth(), getHeight()));
/*     */     }
/* 310 */     Raster src = read(raster.getBounds());
/* 311 */     raster.setRect(src);
/* 312 */     return raster;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/tiff/TIFFRenderedImage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */