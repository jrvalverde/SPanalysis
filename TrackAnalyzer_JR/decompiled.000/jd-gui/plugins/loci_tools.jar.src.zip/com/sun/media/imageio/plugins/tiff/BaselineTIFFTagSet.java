/*      */ package com.sun.media.imageio.plugins.tiff;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class BaselineTIFFTagSet
/*      */   extends TIFFTagSet
/*      */ {
/*  118 */   private static BaselineTIFFTagSet theInstance = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_NEW_SUBFILE_TYPE = 254;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int NEW_SUBFILE_TYPE_REDUCED_RESOLUTION = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int NEW_SUBFILE_TYPE_SINGLE_PAGE = 2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int NEW_SUBFILE_TYPE_TRANSPARENCY = 4;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_SUBFILE_TYPE = 255;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int SUBFILE_TYPE_FULL_RESOLUTION = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int SUBFILE_TYPE_REDUCED_RESOLUTION = 2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int SUBFILE_TYPE_SINGLE_PAGE = 3;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_IMAGE_WIDTH = 256;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_IMAGE_LENGTH = 257;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_BITS_PER_SAMPLE = 258;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_COMPRESSION = 259;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int COMPRESSION_NONE = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int COMPRESSION_CCITT_RLE = 2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int COMPRESSION_CCITT_T_4 = 3;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int COMPRESSION_CCITT_T_6 = 4;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int COMPRESSION_LZW = 5;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int COMPRESSION_OLD_JPEG = 6;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int COMPRESSION_JPEG = 7;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int COMPRESSION_ZLIB = 8;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int COMPRESSION_PACKBITS = 32773;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int COMPRESSION_DEFLATE = 32946;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_PHOTOMETRIC_INTERPRETATION = 262;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int PHOTOMETRIC_INTERPRETATION_WHITE_IS_ZERO = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int PHOTOMETRIC_INTERPRETATION_BLACK_IS_ZERO = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int PHOTOMETRIC_INTERPRETATION_RGB = 2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int PHOTOMETRIC_INTERPRETATION_PALETTE_COLOR = 3;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int PHOTOMETRIC_INTERPRETATION_TRANSPARENCY_MASK = 4;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int PHOTOMETRIC_INTERPRETATION_CMYK = 5;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int PHOTOMETRIC_INTERPRETATION_Y_CB_CR = 6;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int PHOTOMETRIC_INTERPRETATION_CIELAB = 8;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int PHOTOMETRIC_INTERPRETATION_ICCLAB = 9;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_THRESHHOLDING = 263;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int THRESHHOLDING_NONE = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int THRESHHOLDING_ORDERED_DITHER = 2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int THRESHHOLDING_RANDOMIZED_DITHER = 3;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_CELL_WIDTH = 264;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_CELL_LENGTH = 265;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_FILL_ORDER = 266;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int FILL_ORDER_LEFT_TO_RIGHT = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int FILL_ORDER_RIGHT_TO_LEFT = 2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_DOCUMENT_NAME = 269;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_IMAGE_DESCRIPTION = 270;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_MAKE = 271;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_MODEL = 272;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_STRIP_OFFSETS = 273;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_ORIENTATION = 274;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int ORIENTATION_ROW_0_TOP_COLUMN_0_LEFT = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int ORIENTATION_ROW_0_TOP_COLUMN_0_RIGHT = 2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int ORIENTATION_ROW_0_BOTTOM_COLUMN_0_RIGHT = 3;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int ORIENTATION_ROW_0_BOTTOM_COLUMN_0_LEFT = 4;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int ORIENTATION_ROW_0_LEFT_COLUMN_0_TOP = 5;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int ORIENTATION_ROW_0_RIGHT_COLUMN_0_TOP = 6;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int ORIENTATION_ROW_0_RIGHT_COLUMN_0_BOTTOM = 7;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int ORIENTATION_ROW_0_LEFT_COLUMN_0_BOTTOM = 8;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_SAMPLES_PER_PIXEL = 277;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_ROWS_PER_STRIP = 278;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_STRIP_BYTE_COUNTS = 279;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_MIN_SAMPLE_VALUE = 280;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_MAX_SAMPLE_VALUE = 281;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_X_RESOLUTION = 282;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_Y_RESOLUTION = 283;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_PLANAR_CONFIGURATION = 284;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int PLANAR_CONFIGURATION_CHUNKY = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int PLANAR_CONFIGURATION_PLANAR = 2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_PAGE_NAME = 285;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_X_POSITION = 286;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_Y_POSITION = 287;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_FREE_OFFSETS = 288;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_FREE_BYTE_COUNTS = 289;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_GRAY_RESPONSE_UNIT = 290;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int GRAY_RESPONSE_UNIT_TENTHS = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int GRAY_RESPONSE_UNIT_HUNDREDTHS = 2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int GRAY_RESPONSE_UNIT_THOUSANDTHS = 3;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int GRAY_RESPONSE_UNIT_TEN_THOUSANDTHS = 4;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int GRAY_RESPONSE_UNIT_HUNDRED_THOUSANDTHS = 5;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_GRAY_RESPONSE_CURVE = 291;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_T4_OPTIONS = 292;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int T4_OPTIONS_2D_CODING = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int T4_OPTIONS_UNCOMPRESSED = 2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int T4_OPTIONS_EOL_BYTE_ALIGNED = 4;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_T6_OPTIONS = 293;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int T6_OPTIONS_UNCOMPRESSED = 2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_RESOLUTION_UNIT = 296;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int RESOLUTION_UNIT_NONE = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int RESOLUTION_UNIT_INCH = 2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int RESOLUTION_UNIT_CENTIMETER = 3;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_PAGE_NUMBER = 297;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_TRANSFER_FUNCTION = 301;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_SOFTWARE = 305;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_DATE_TIME = 306;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_ARTIST = 315;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_HOST_COMPUTER = 316;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_PREDICTOR = 317;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int PREDICTOR_NONE = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int PREDICTOR_HORIZONTAL_DIFFERENCING = 2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_WHITE_POINT = 318;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_PRIMARY_CHROMATICITES = 319;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_COLOR_MAP = 320;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_HALFTONE_HINTS = 321;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_TILE_WIDTH = 322;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_TILE_LENGTH = 323;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_TILE_OFFSETS = 324;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_TILE_BYTE_COUNTS = 325;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_INK_SET = 332;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int INK_SET_CMYK = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int INK_SET_NOT_CMYK = 2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_INK_NAMES = 333;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_NUMBER_OF_INKS = 334;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_DOT_RANGE = 336;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_TARGET_PRINTER = 337;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_EXTRA_SAMPLES = 338;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int EXTRA_SAMPLES_UNSPECIFIED = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int EXTRA_SAMPLES_ASSOCIATED_ALPHA = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int EXTRA_SAMPLES_UNASSOCIATED_ALPHA = 2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_SAMPLE_FORMAT = 339;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int SAMPLE_FORMAT_UNSIGNED_INTEGER = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int SAMPLE_FORMAT_SIGNED_INTEGER = 2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int SAMPLE_FORMAT_FLOATING_POINT = 3;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int SAMPLE_FORMAT_UNDEFINED = 4;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_S_MIN_SAMPLE_VALUE = 340;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_S_MAX_SAMPLE_VALUE = 341;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_TRANSFER_RANGE = 342;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_JPEG_TABLES = 347;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_JPEG_PROC = 512;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int JPEG_PROC_BASELINE = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int JPEG_PROC_LOSSLESS = 14;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_JPEG_INTERCHANGE_FORMAT = 513;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_JPEG_INTERCHANGE_FORMAT_LENGTH = 514;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_JPEG_RESTART_INTERVAL = 515;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_JPEG_LOSSLESS_PREDICTORS = 517;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_JPEG_POINT_TRANSFORMS = 518;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_JPEG_Q_TABLES = 519;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_JPEG_DC_TABLES = 520;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_JPEG_AC_TABLES = 521;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_Y_CB_CR_COEFFICIENTS = 529;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_Y_CB_CR_SUBSAMPLING = 530;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_Y_CB_CR_POSITIONING = 531;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int Y_CB_CR_POSITIONING_CENTERED = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int Y_CB_CR_POSITIONING_COSITED = 2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_REFERENCE_BLACK_WHITE = 532;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_COPYRIGHT = 33432;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TAG_ICC_PROFILE = 34675;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static List tags;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class Artist
/*      */     extends TIFFTag
/*      */   {
/*      */     public Artist() {
/* 1080 */       super("Artist", 315, 4);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class BitsPerSample
/*      */     extends TIFFTag
/*      */   {
/*      */     public BitsPerSample() {
/* 1091 */       super("BitsPerSample", 258, 8);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class CellLength
/*      */     extends TIFFTag
/*      */   {
/*      */     public CellLength() {
/* 1102 */       super("CellLength", 265, 8);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class CellWidth
/*      */     extends TIFFTag
/*      */   {
/*      */     public CellWidth() {
/* 1113 */       super("CellWidth", 264, 8);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class ColorMap
/*      */     extends TIFFTag
/*      */   {
/*      */     public ColorMap() {
/* 1124 */       super("ColorMap", 320, 8);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class Compression
/*      */     extends TIFFTag
/*      */   {
/*      */     public Compression() {
/* 1135 */       super("Compression", 259, 8);
/*      */ 
/*      */ 
/*      */       
/* 1139 */       addValueName(1, "Uncompressed");
/* 1140 */       addValueName(2, "CCITT RLE");
/* 1141 */       addValueName(3, "CCITT T.4");
/* 1142 */       addValueName(4, "CCITT T.6");
/* 1143 */       addValueName(5, "LZW");
/* 1144 */       addValueName(6, "Old JPEG");
/* 1145 */       addValueName(7, "JPEG");
/* 1146 */       addValueName(8, "ZLib");
/* 1147 */       addValueName(32773, "PackBits");
/* 1148 */       addValueName(32946, "Deflate");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class Copyright
/*      */     extends TIFFTag
/*      */   {
/*      */     public Copyright() {
/* 1164 */       super("Copyright", 33432, 4);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class DateTime
/*      */     extends TIFFTag
/*      */   {
/*      */     public DateTime() {
/* 1175 */       super("DateTime", 306, 4);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class DocumentName
/*      */     extends TIFFTag
/*      */   {
/*      */     public DocumentName() {
/* 1186 */       super("DocumentName", 269, 4);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class DotRange
/*      */     extends TIFFTag
/*      */   {
/*      */     public DotRange() {
/* 1197 */       super("DotRange", 336, 10);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class ExtraSamples
/*      */     extends TIFFTag
/*      */   {
/*      */     public ExtraSamples() {
/* 1209 */       super("ExtraSamples", 338, 8);
/*      */ 
/*      */ 
/*      */       
/* 1213 */       addValueName(0, "Unspecified");
/*      */       
/* 1215 */       addValueName(1, "Associated Alpha");
/*      */       
/* 1217 */       addValueName(2, "Unassociated Alpha");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static class FillOrder
/*      */     extends TIFFTag
/*      */   {
/*      */     public FillOrder() {
/* 1227 */       super("FillOrder", 266, 8);
/*      */ 
/*      */ 
/*      */       
/* 1231 */       addValueName(1, "LeftToRight");
/* 1232 */       addValueName(2, "RightToLeft");
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   static class FreeByteCounts
/*      */     extends TIFFTag
/*      */   {
/*      */     public FreeByteCounts() {
/* 1241 */       super("FreeByteCounts", 289, 16);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class FreeOffsets
/*      */     extends TIFFTag
/*      */   {
/*      */     public FreeOffsets() {
/* 1252 */       super("FreeOffsets", 288, 16);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class GrayResponseCurve
/*      */     extends TIFFTag
/*      */   {
/*      */     public GrayResponseCurve() {
/* 1263 */       super("GrayResponseCurve", 291, 8);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class GrayResponseUnit
/*      */     extends TIFFTag
/*      */   {
/*      */     public GrayResponseUnit() {
/* 1274 */       super("GrayResponseUnit", 290, 8);
/*      */ 
/*      */ 
/*      */       
/* 1278 */       addValueName(1, "Tenths");
/*      */       
/* 1280 */       addValueName(2, "Hundredths");
/*      */       
/* 1282 */       addValueName(3, "Thousandths");
/*      */       
/* 1284 */       addValueName(4, "Ten-Thousandths");
/*      */       
/* 1286 */       addValueName(5, "Hundred-Thousandths");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static class HalftoneHints
/*      */     extends TIFFTag
/*      */   {
/*      */     public HalftoneHints() {
/* 1296 */       super("HalftoneHints", 321, 8);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class HostComputer
/*      */     extends TIFFTag
/*      */   {
/*      */     public HostComputer() {
/* 1307 */       super("HostComputer", 316, 4);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class ImageDescription
/*      */     extends TIFFTag
/*      */   {
/*      */     public ImageDescription() {
/* 1318 */       super("ImageDescription", 270, 4);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class ImageLength
/*      */     extends TIFFTag
/*      */   {
/*      */     public ImageLength() {
/* 1329 */       super("ImageLength", 257, 24);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class ImageWidth
/*      */     extends TIFFTag
/*      */   {
/*      */     public ImageWidth() {
/* 1341 */       super("ImageWidth", 256, 24);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class InkNames
/*      */     extends TIFFTag
/*      */   {
/*      */     public InkNames() {
/* 1353 */       super("InkNames", 333, 4);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class InkSet
/*      */     extends TIFFTag
/*      */   {
/*      */     public InkSet() {
/* 1364 */       super("InkSet", 332, 8);
/*      */ 
/*      */ 
/*      */       
/* 1368 */       addValueName(1, "CMYK");
/* 1369 */       addValueName(2, "Not CMYK");
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   static class JPEGTables
/*      */     extends TIFFTag
/*      */   {
/*      */     public JPEGTables() {
/* 1378 */       super("JPEGTables", 347, 128);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class JPEGACTables
/*      */     extends TIFFTag
/*      */   {
/*      */     public JPEGACTables() {
/* 1389 */       super("JPEGACTables", 521, 16);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class JPEGDCTables
/*      */     extends TIFFTag
/*      */   {
/*      */     public JPEGDCTables() {
/* 1400 */       super("JPEGDCTables", 520, 16);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class JPEGInterchangeFormat
/*      */     extends TIFFTag
/*      */   {
/*      */     public JPEGInterchangeFormat() {
/* 1411 */       super("JPEGInterchangeFormat", 513, 16);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class JPEGInterchangeFormatLength
/*      */     extends TIFFTag
/*      */   {
/*      */     public JPEGInterchangeFormatLength() {
/* 1422 */       super("JPEGInterchangeFormatLength", 514, 16);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class JPEGLosslessPredictors
/*      */     extends TIFFTag
/*      */   {
/*      */     public JPEGLosslessPredictors() {
/* 1433 */       super("JPEGLosslessPredictors", 517, 8);
/*      */ 
/*      */ 
/*      */       
/* 1437 */       addValueName(1, "A");
/* 1438 */       addValueName(2, "B");
/* 1439 */       addValueName(3, "C");
/* 1440 */       addValueName(4, "A+B-C");
/* 1441 */       addValueName(5, "A+((B-C)/2)");
/* 1442 */       addValueName(6, "B+((A-C)/2)");
/* 1443 */       addValueName(7, "(A+B)/2");
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   static class JPEGPointTransforms
/*      */     extends TIFFTag
/*      */   {
/*      */     public JPEGPointTransforms() {
/* 1452 */       super("JPEGPointTransforms", 518, 8);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class JPEGProc
/*      */     extends TIFFTag
/*      */   {
/*      */     public JPEGProc() {
/* 1463 */       super("JPEGProc", 512, 8);
/*      */ 
/*      */ 
/*      */       
/* 1467 */       addValueName(1, "Baseline sequential process");
/* 1468 */       addValueName(14, "Lossless process with Huffman coding");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static class JPEGQTables
/*      */     extends TIFFTag
/*      */   {
/*      */     public JPEGQTables() {
/* 1478 */       super("JPEGQTables", 519, 16);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class JPEGRestartInterval
/*      */     extends TIFFTag
/*      */   {
/*      */     public JPEGRestartInterval() {
/* 1489 */       super("JPEGRestartInterval", 515, 8);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class Make
/*      */     extends TIFFTag
/*      */   {
/*      */     public Make() {
/* 1500 */       super("Make", 271, 4);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class MaxSampleValue
/*      */     extends TIFFTag
/*      */   {
/*      */     public MaxSampleValue() {
/* 1511 */       super("MaxSampleValue", 281, 8);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class MinSampleValue
/*      */     extends TIFFTag
/*      */   {
/*      */     public MinSampleValue() {
/* 1522 */       super("MinSampleValue", 280, 8);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class Model
/*      */     extends TIFFTag
/*      */   {
/*      */     public Model() {
/* 1533 */       super("Model", 272, 4);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class NewSubfileType
/*      */     extends TIFFTag
/*      */   {
/*      */     public NewSubfileType() {
/* 1544 */       super("NewSubfileType", 254, 16);
/*      */ 
/*      */ 
/*      */       
/* 1548 */       addValueName(0, "Default");
/*      */       
/* 1550 */       addValueName(1, "ReducedResolution");
/*      */       
/* 1552 */       addValueName(2, "SinglePage");
/*      */       
/* 1554 */       addValueName(3, "SinglePage+ReducedResolution");
/*      */ 
/*      */       
/* 1557 */       addValueName(4, "Transparency");
/*      */       
/* 1559 */       addValueName(5, "Transparency+ReducedResolution");
/*      */ 
/*      */       
/* 1562 */       addValueName(6, "Transparency+SinglePage");
/*      */ 
/*      */       
/* 1565 */       addValueName(7, "Transparency+SinglePage+ReducedResolution");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class NumberOfInks
/*      */     extends TIFFTag
/*      */   {
/*      */     public NumberOfInks() {
/* 1577 */       super("NumberOfInks", 334, 8);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class Orientation
/*      */     extends TIFFTag
/*      */   {
/*      */     public Orientation() {
/* 1588 */       super("Orientation", 274, 8);
/*      */ 
/*      */ 
/*      */       
/* 1592 */       addValueName(1, "Row 0=Top, Column 0=Left");
/*      */       
/* 1594 */       addValueName(2, "Row 0=Top, Column 0=Right");
/*      */       
/* 1596 */       addValueName(3, "Row 0=Bottom, Column 0=Right");
/*      */       
/* 1598 */       addValueName(4, "Row 0=Bottom, Column 0=Left");
/*      */       
/* 1600 */       addValueName(5, "Row 0=Left, Column 0=Top");
/*      */       
/* 1602 */       addValueName(6, "Row 0=Right, Column 0=Top");
/*      */       
/* 1604 */       addValueName(7, "Row 0=Right, Column 0=Bottom");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static class PageName
/*      */     extends TIFFTag
/*      */   {
/*      */     public PageName() {
/* 1614 */       super("PageName", 285, 4);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class PageNumber
/*      */     extends TIFFTag
/*      */   {
/*      */     public PageNumber() {
/* 1625 */       super("PageNumber", 297, 8);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class PhotometricInterpretation
/*      */     extends TIFFTag
/*      */   {
/*      */     public PhotometricInterpretation() {
/* 1636 */       super("PhotometricInterpretation", 262, 8);
/*      */ 
/*      */ 
/*      */       
/* 1640 */       addValueName(0, "WhiteIsZero");
/*      */       
/* 1642 */       addValueName(1, "BlackIsZero");
/*      */       
/* 1644 */       addValueName(2, "RGB");
/*      */       
/* 1646 */       addValueName(3, "Palette Color");
/*      */       
/* 1648 */       addValueName(4, "Transparency Mask");
/*      */       
/* 1650 */       addValueName(5, "CMYK");
/*      */       
/* 1652 */       addValueName(6, "YCbCr");
/*      */       
/* 1654 */       addValueName(8, "CIELAB");
/*      */       
/* 1656 */       addValueName(9, "ICCLAB");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static class PlanarConfiguration
/*      */     extends TIFFTag
/*      */   {
/*      */     public PlanarConfiguration() {
/* 1666 */       super("PlanarConfiguration", 284, 8);
/*      */ 
/*      */ 
/*      */       
/* 1670 */       addValueName(1, "Chunky");
/* 1671 */       addValueName(2, "Planar");
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   static class Predictor
/*      */     extends TIFFTag
/*      */   {
/*      */     public Predictor() {
/* 1680 */       super("Predictor", 317, 8);
/*      */ 
/*      */ 
/*      */       
/* 1684 */       addValueName(1, "None");
/*      */       
/* 1686 */       addValueName(2, "Horizontal Differencing");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static class PrimaryChromaticities
/*      */     extends TIFFTag
/*      */   {
/*      */     public PrimaryChromaticities() {
/* 1696 */       super("PrimaryChromaticities", 319, 32);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class ReferenceBlackWhite
/*      */     extends TIFFTag
/*      */   {
/*      */     public ReferenceBlackWhite() {
/* 1707 */       super("ReferenceBlackWhite", 532, 32);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class ResolutionUnit
/*      */     extends TIFFTag
/*      */   {
/*      */     public ResolutionUnit() {
/* 1718 */       super("ResolutionUnit", 296, 8);
/*      */ 
/*      */ 
/*      */       
/* 1722 */       addValueName(1, "None");
/* 1723 */       addValueName(2, "Inch");
/* 1724 */       addValueName(3, "Centimeter");
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   static class RowsPerStrip
/*      */     extends TIFFTag
/*      */   {
/*      */     public RowsPerStrip() {
/* 1733 */       super("RowsPerStrip", 278, 24);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class SampleFormat
/*      */     extends TIFFTag
/*      */   {
/*      */     public SampleFormat() {
/* 1745 */       super("SampleFormat", 339, 8);
/*      */ 
/*      */ 
/*      */       
/* 1749 */       addValueName(1, "Unsigned Integer");
/* 1750 */       addValueName(2, "Signed Integer");
/* 1751 */       addValueName(3, "Floating Point");
/* 1752 */       addValueName(4, "Undefined");
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   static class SamplesPerPixel
/*      */     extends TIFFTag
/*      */   {
/*      */     public SamplesPerPixel() {
/* 1761 */       super("SamplesPerPixel", 277, 8);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class SMaxSampleValue
/*      */     extends TIFFTag
/*      */   {
/*      */     public SMaxSampleValue() {
/* 1772 */       super("SMaxSampleValue", 341, 8058);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class SMinSampleValue
/*      */     extends TIFFTag
/*      */   {
/*      */     public SMinSampleValue() {
/* 1792 */       super("SMinSampleValue", 340, 8058);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class Software
/*      */     extends TIFFTag
/*      */   {
/*      */     public Software() {
/* 1812 */       super("Software", 305, 4);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class StripByteCounts
/*      */     extends TIFFTag
/*      */   {
/*      */     public StripByteCounts() {
/* 1823 */       super("StripByteCounts", 279, 24);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class StripOffsets
/*      */     extends TIFFTag
/*      */   {
/*      */     public StripOffsets() {
/* 1835 */       super("StripOffsets", 273, 24);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class SubfileType
/*      */     extends TIFFTag
/*      */   {
/*      */     public SubfileType() {
/* 1847 */       super("SubfileType", 255, 8);
/*      */ 
/*      */ 
/*      */       
/* 1851 */       addValueName(1, "FullResolution");
/* 1852 */       addValueName(2, "ReducedResolution");
/* 1853 */       addValueName(3, "SinglePage");
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   static class T4Options
/*      */     extends TIFFTag
/*      */   {
/*      */     public T4Options() {
/* 1862 */       super("T4Options", 292, 16);
/*      */ 
/*      */ 
/*      */       
/* 1866 */       addValueName(0, "Default 1DCoding");
/*      */       
/* 1868 */       addValueName(1, "2DCoding");
/*      */       
/* 1870 */       addValueName(2, "Uncompressed");
/*      */       
/* 1872 */       addValueName(3, "2DCoding+Uncompressed");
/*      */ 
/*      */       
/* 1875 */       addValueName(4, "EOLByteAligned");
/*      */       
/* 1877 */       addValueName(5, "2DCoding+EOLByteAligned");
/*      */ 
/*      */       
/* 1880 */       addValueName(6, "Uncompressed+EOLByteAligned");
/*      */ 
/*      */       
/* 1883 */       addValueName(7, "2DCoding+Uncompressed+EOLByteAligned");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class T6Options
/*      */     extends TIFFTag
/*      */   {
/*      */     public T6Options() {
/* 1895 */       super("T6Options", 293, 16);
/*      */ 
/*      */ 
/*      */       
/* 1899 */       addValueName(0, "Default");
/*      */ 
/*      */       
/* 1902 */       addValueName(2, "Uncompressed");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static class TargetPrinter
/*      */     extends TIFFTag
/*      */   {
/*      */     public TargetPrinter() {
/* 1912 */       super("TargetPrinter", 337, 4);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class Threshholding
/*      */     extends TIFFTag
/*      */   {
/*      */     public Threshholding() {
/* 1923 */       super("Threshholding", 263, 8);
/*      */ 
/*      */ 
/*      */       
/* 1927 */       addValueName(1, "None");
/* 1928 */       addValueName(2, "OrderedDither");
/* 1929 */       addValueName(3, "RandomizedDither");
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   static class TileByteCounts
/*      */     extends TIFFTag
/*      */   {
/*      */     public TileByteCounts() {
/* 1938 */       super("TileByteCounts", 325, 24);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class TileOffsets
/*      */     extends TIFFTag
/*      */   {
/*      */     public TileOffsets() {
/* 1950 */       super("TileOffsets", 324, 16);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class TileLength
/*      */     extends TIFFTag
/*      */   {
/*      */     public TileLength() {
/* 1961 */       super("TileLength", 323, 24);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class TileWidth
/*      */     extends TIFFTag
/*      */   {
/*      */     public TileWidth() {
/* 1973 */       super("TileWidth", 322, 24);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class TransferFunction
/*      */     extends TIFFTag
/*      */   {
/*      */     public TransferFunction() {
/* 1985 */       super("TransferFunction", 301, 8);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class TransferRange
/*      */     extends TIFFTag
/*      */   {
/*      */     public TransferRange() {
/* 1996 */       super("TransferRange", 342, 8);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class WhitePoint
/*      */     extends TIFFTag
/*      */   {
/*      */     public WhitePoint() {
/* 2007 */       super("WhitePoint", 318, 32);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class XPosition
/*      */     extends TIFFTag
/*      */   {
/*      */     public XPosition() {
/* 2018 */       super("XPosition", 286, 32);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class XResolution
/*      */     extends TIFFTag
/*      */   {
/*      */     public XResolution() {
/* 2029 */       super("XResolution", 282, 32);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class YCbCrCoefficients
/*      */     extends TIFFTag
/*      */   {
/*      */     public YCbCrCoefficients() {
/* 2040 */       super("YCbCrCoefficients", 529, 32);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class YCbCrPositioning
/*      */     extends TIFFTag
/*      */   {
/*      */     public YCbCrPositioning() {
/* 2051 */       super("YCbCrPositioning", 531, 8);
/*      */ 
/*      */ 
/*      */       
/* 2055 */       addValueName(1, "Centered");
/* 2056 */       addValueName(2, "Cosited");
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   static class YCbCrSubSampling
/*      */     extends TIFFTag
/*      */   {
/*      */     public YCbCrSubSampling() {
/* 2065 */       super("YCbCrSubSampling", 530, 8);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class YPosition
/*      */     extends TIFFTag
/*      */   {
/*      */     public YPosition() {
/* 2076 */       super("YPosition", 287, 32);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class YResolution
/*      */     extends TIFFTag
/*      */   {
/*      */     public YResolution() {
/* 2087 */       super("YResolution", 283, 32);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class ICCProfile
/*      */     extends TIFFTag
/*      */   {
/*      */     public ICCProfile() {
/* 2100 */       super("ICC Profile", 34675, 128);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void initTags() {
/* 2109 */     tags = new ArrayList(76);
/*      */     
/* 2111 */     tags.add(new Artist());
/* 2112 */     tags.add(new BitsPerSample());
/* 2113 */     tags.add(new CellLength());
/* 2114 */     tags.add(new CellWidth());
/* 2115 */     tags.add(new ColorMap());
/* 2116 */     tags.add(new Compression());
/* 2117 */     tags.add(new Copyright());
/* 2118 */     tags.add(new DateTime());
/* 2119 */     tags.add(new DocumentName());
/* 2120 */     tags.add(new DotRange());
/* 2121 */     tags.add(new ExtraSamples());
/* 2122 */     tags.add(new FillOrder());
/* 2123 */     tags.add(new FreeByteCounts());
/* 2124 */     tags.add(new FreeOffsets());
/* 2125 */     tags.add(new GrayResponseCurve());
/* 2126 */     tags.add(new GrayResponseUnit());
/* 2127 */     tags.add(new HalftoneHints());
/* 2128 */     tags.add(new HostComputer());
/* 2129 */     tags.add(new ImageDescription());
/* 2130 */     tags.add(new ICCProfile());
/* 2131 */     tags.add(new ImageLength());
/* 2132 */     tags.add(new ImageWidth());
/* 2133 */     tags.add(new InkNames());
/* 2134 */     tags.add(new InkSet());
/* 2135 */     tags.add(new JPEGACTables());
/* 2136 */     tags.add(new JPEGDCTables());
/* 2137 */     tags.add(new JPEGInterchangeFormat());
/* 2138 */     tags.add(new JPEGInterchangeFormatLength());
/* 2139 */     tags.add(new JPEGLosslessPredictors());
/* 2140 */     tags.add(new JPEGPointTransforms());
/* 2141 */     tags.add(new JPEGProc());
/* 2142 */     tags.add(new JPEGQTables());
/* 2143 */     tags.add(new JPEGRestartInterval());
/* 2144 */     tags.add(new JPEGTables());
/* 2145 */     tags.add(new Make());
/* 2146 */     tags.add(new MaxSampleValue());
/* 2147 */     tags.add(new MinSampleValue());
/* 2148 */     tags.add(new Model());
/* 2149 */     tags.add(new NewSubfileType());
/* 2150 */     tags.add(new NumberOfInks());
/* 2151 */     tags.add(new Orientation());
/* 2152 */     tags.add(new PageName());
/* 2153 */     tags.add(new PageNumber());
/* 2154 */     tags.add(new PhotometricInterpretation());
/* 2155 */     tags.add(new PlanarConfiguration());
/* 2156 */     tags.add(new Predictor());
/* 2157 */     tags.add(new PrimaryChromaticities());
/* 2158 */     tags.add(new ReferenceBlackWhite());
/* 2159 */     tags.add(new ResolutionUnit());
/* 2160 */     tags.add(new RowsPerStrip());
/* 2161 */     tags.add(new SampleFormat());
/* 2162 */     tags.add(new SamplesPerPixel());
/* 2163 */     tags.add(new SMaxSampleValue());
/* 2164 */     tags.add(new SMinSampleValue());
/* 2165 */     tags.add(new Software());
/* 2166 */     tags.add(new StripByteCounts());
/* 2167 */     tags.add(new StripOffsets());
/* 2168 */     tags.add(new SubfileType());
/* 2169 */     tags.add(new T4Options());
/* 2170 */     tags.add(new T6Options());
/* 2171 */     tags.add(new TargetPrinter());
/* 2172 */     tags.add(new Threshholding());
/* 2173 */     tags.add(new TileByteCounts());
/* 2174 */     tags.add(new TileOffsets());
/* 2175 */     tags.add(new TileLength());
/* 2176 */     tags.add(new TileWidth());
/* 2177 */     tags.add(new TransferFunction());
/* 2178 */     tags.add(new TransferRange());
/* 2179 */     tags.add(new WhitePoint());
/* 2180 */     tags.add(new XPosition());
/* 2181 */     tags.add(new XResolution());
/* 2182 */     tags.add(new YCbCrCoefficients());
/* 2183 */     tags.add(new YCbCrPositioning());
/* 2184 */     tags.add(new YCbCrSubSampling());
/* 2185 */     tags.add(new YPosition());
/* 2186 */     tags.add(new YResolution());
/*      */   }
/*      */   
/*      */   private BaselineTIFFTagSet() {
/* 2190 */     super(tags);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static synchronized BaselineTIFFTagSet getInstance() {
/* 2199 */     if (theInstance == null) {
/* 2200 */       initTags();
/* 2201 */       theInstance = new BaselineTIFFTagSet();
/* 2202 */       tags = null;
/*      */     } 
/* 2204 */     return theInstance;
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageio/plugins/tiff/BaselineTIFFTagSet.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */