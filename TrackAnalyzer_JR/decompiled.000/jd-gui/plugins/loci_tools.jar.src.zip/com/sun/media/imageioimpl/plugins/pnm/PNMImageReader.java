/*     */ package com.sun.media.imageioimpl.plugins.pnm;
/*     */ 
/*     */ import com.sun.media.imageioimpl.common.ImageUtil;
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.ColorModel;
/*     */ import java.awt.image.DataBuffer;
/*     */ import java.awt.image.DataBufferByte;
/*     */ import java.awt.image.DataBufferInt;
/*     */ import java.awt.image.DataBufferUShort;
/*     */ import java.awt.image.IndexColorModel;
/*     */ import java.awt.image.MultiPixelPackedSampleModel;
/*     */ import java.awt.image.PixelInterleavedSampleModel;
/*     */ import java.awt.image.Raster;
/*     */ import java.awt.image.SampleModel;
/*     */ import java.awt.image.WritableRaster;
/*     */ import java.io.IOException;
/*     */ import java.security.AccessController;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.imageio.ImageReadParam;
/*     */ import javax.imageio.ImageReader;
/*     */ import javax.imageio.ImageTypeSpecifier;
/*     */ import javax.imageio.metadata.IIOMetadata;
/*     */ import javax.imageio.spi.ImageReaderSpi;
/*     */ import javax.imageio.stream.ImageInputStream;
/*     */ import sun.security.action.GetPropertyAction;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PNMImageReader
/*     */   extends ImageReader
/*     */ {
/*     */   private static final int PBM_ASCII = 49;
/*     */   private static final int PGM_ASCII = 50;
/*     */   private static final int PPM_ASCII = 51;
/*     */   private static final int PBM_RAW = 52;
/*     */   private static final int PGM_RAW = 53;
/*     */   private static final int PPM_RAW = 54;
/*     */   private static final int LINE_FEED = 10;
/*     */   private static byte[] lineSeparator;
/*     */   private int variant;
/*     */   private int maxValue;
/*     */   
/*     */   static {
/* 134 */     if (lineSeparator == null) {
/* 135 */       String ls = AccessController.<String>doPrivileged(new GetPropertyAction("line.separator"));
/*     */       
/* 137 */       lineSeparator = ls.getBytes();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 148 */   private ImageInputStream iis = null;
/*     */ 
/*     */   
/*     */   private boolean gotHeader = false;
/*     */ 
/*     */   
/*     */   private long imageDataOffset;
/*     */ 
/*     */   
/*     */   private int width;
/*     */ 
/*     */   
/*     */   private int height;
/*     */ 
/*     */   
/*     */   private String aLine;
/*     */   
/*     */   private StringTokenizer token;
/*     */   
/*     */   private PNMMetadata metadata;
/*     */ 
/*     */   
/*     */   public PNMImageReader(ImageReaderSpi originator) {
/* 171 */     super(originator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInput(Object input, boolean seekForwardOnly, boolean ignoreMetadata) {
/* 178 */     super.setInput(input, seekForwardOnly, ignoreMetadata);
/* 179 */     this.iis = (ImageInputStream)input;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getNumImages(boolean allowSearch) throws IOException {
/* 184 */     return 1;
/*     */   }
/*     */   
/*     */   public int getWidth(int imageIndex) throws IOException {
/* 188 */     checkIndex(imageIndex);
/* 189 */     readHeader();
/* 190 */     return this.width;
/*     */   }
/*     */   
/*     */   public int getHeight(int imageIndex) throws IOException {
/* 194 */     checkIndex(imageIndex);
/* 195 */     readHeader();
/* 196 */     return this.height;
/*     */   }
/*     */   
/*     */   public int getVariant() {
/* 200 */     return this.variant;
/*     */   }
/*     */   
/*     */   public int getMaxValue() {
/* 204 */     return this.maxValue;
/*     */   }
/*     */   
/*     */   private void checkIndex(int imageIndex) {
/* 208 */     if (imageIndex != 0) {
/* 209 */       throw new IndexOutOfBoundsException(I18N.getString("PNMImageReader1"));
/*     */     }
/*     */   }
/*     */   
/*     */   public synchronized void readHeader() throws IOException {
/* 214 */     if (this.gotHeader) {
/*     */ 
/*     */       
/* 217 */       this.iis.seek(this.imageDataOffset);
/*     */       
/*     */       return;
/*     */     } 
/* 221 */     if (this.iis != null) {
/* 222 */       if (this.iis.readByte() != 80) {
/* 223 */         throw new RuntimeException(I18N.getString("PNMImageReader0"));
/*     */       }
/*     */       
/* 226 */       this.variant = this.iis.readByte();
/* 227 */       if (this.variant < 49 || this.variant > 54) {
/* 228 */         throw new RuntimeException(I18N.getString("PNMImageReader0"));
/*     */       }
/*     */ 
/*     */       
/* 232 */       this.metadata = new PNMMetadata();
/*     */ 
/*     */       
/* 235 */       this.metadata.setVariant(this.variant);
/*     */ 
/*     */       
/* 238 */       this.iis.readLine();
/*     */       
/* 240 */       readComments(this.iis, this.metadata);
/*     */       
/* 242 */       this.width = readInteger(this.iis);
/* 243 */       this.height = readInteger(this.iis);
/*     */       
/* 245 */       if (this.variant == 49 || this.variant == 52) {
/* 246 */         this.maxValue = 1;
/*     */       } else {
/* 248 */         this.maxValue = readInteger(this.iis);
/*     */       } 
/*     */       
/* 251 */       this.metadata.setWidth(this.width);
/* 252 */       this.metadata.setHeight(this.height);
/* 253 */       this.metadata.setMaxBitDepth(this.maxValue);
/*     */       
/* 255 */       this.gotHeader = true;
/*     */ 
/*     */       
/* 258 */       this.imageDataOffset = this.iis.getStreamPosition();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator getImageTypes(int imageIndex) throws IOException {
/* 264 */     checkIndex(imageIndex);
/*     */     
/* 266 */     readHeader();
/* 267 */     int tmp = (this.variant - 49) % 3;
/*     */     
/* 269 */     ArrayList<ImageTypeSpecifier> list = new ArrayList(1);
/* 270 */     int dataType = 3;
/*     */     
/* 272 */     if (this.maxValue < 256) {
/* 273 */       dataType = 0;
/* 274 */     } else if (this.maxValue < 65536) {
/* 275 */       dataType = 1;
/*     */     } 
/*     */ 
/*     */     
/* 279 */     SampleModel sampleModel = null;
/* 280 */     ColorModel colorModel = null;
/* 281 */     if (this.variant == 49 || this.variant == 52) {
/*     */       
/* 283 */       sampleModel = new MultiPixelPackedSampleModel(0, this.width, this.height, 1);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 288 */       byte[] color = { -1, 0 };
/* 289 */       colorModel = new IndexColorModel(1, 2, color, color, color);
/*     */     } else {
/* 291 */       (new int[1])[0] = 0; (new int[3])[0] = 0; (new int[3])[1] = 1; (new int[3])[2] = 2; sampleModel = new PixelInterleavedSampleModel(dataType, this.width, this.height, (tmp == 1) ? 1 : 3, this.width * ((tmp == 1) ? 1 : 3), (tmp == 1) ? new int[1] : new int[3]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 299 */       colorModel = ImageUtil.createColorModel(null, sampleModel);
/*     */     } 
/*     */     
/* 302 */     list.add(new ImageTypeSpecifier(colorModel, sampleModel));
/*     */     
/* 304 */     return list.iterator();
/*     */   }
/*     */   
/*     */   public ImageReadParam getDefaultReadParam() {
/* 308 */     return new ImageReadParam();
/*     */   }
/*     */ 
/*     */   
/*     */   public IIOMetadata getImageMetadata(int imageIndex) throws IOException {
/* 313 */     checkIndex(imageIndex);
/* 314 */     readHeader();
/* 315 */     return this.metadata;
/*     */   }
/*     */   
/*     */   public IIOMetadata getStreamMetadata() throws IOException {
/* 319 */     return null;
/*     */   }
/*     */   
/*     */   public boolean isRandomAccessEasy(int imageIndex) throws IOException {
/* 323 */     checkIndex(imageIndex);
/* 324 */     return true; } public BufferedImage read(int imageIndex, ImageReadParam param) throws IOException { DataBuffer dataBuffer; int skipX; byte[] buf; int skipY, originalLS, k, dsx; byte[] data; int m; DataBufferByte bbuf; int destLS, i1; byte[] byteArray; int offset, i; DataBufferUShort sbuf; int i2, n;
/*     */     short[] shortArray;
/*     */     int i3;
/*     */     DataBufferInt ibuf;
/*     */     int j, i4, intArray[], i6, i5, i7;
/* 329 */     checkIndex(imageIndex);
/* 330 */     clearAbortRequest();
/* 331 */     processImageStarted(imageIndex);
/*     */     
/* 333 */     if (param == null) {
/* 334 */       param = getDefaultReadParam();
/*     */     }
/*     */     
/* 337 */     readHeader();
/*     */     
/* 339 */     Rectangle sourceRegion = new Rectangle(0, 0, 0, 0);
/* 340 */     Rectangle destinationRegion = new Rectangle(0, 0, 0, 0);
/*     */     
/* 342 */     computeRegions(param, this.width, this.height, param.getDestination(), sourceRegion, destinationRegion);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 347 */     int scaleX = param.getSourceXSubsampling();
/* 348 */     int scaleY = param.getSourceYSubsampling();
/*     */ 
/*     */     
/* 351 */     int[] sourceBands = param.getSourceBands();
/* 352 */     int[] destBands = param.getDestinationBands();
/*     */     
/* 354 */     boolean seleBand = (sourceBands != null && destBands != null);
/* 355 */     boolean noTransform = (destinationRegion.equals(new Rectangle(0, 0, this.width, this.height)) || seleBand);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 362 */     if (isRaw(this.variant) && this.maxValue >= 256) {
/* 363 */       this.maxValue = 255;
/*     */     }
/*     */     
/* 366 */     int numBands = 1;
/*     */ 
/*     */     
/* 369 */     if (this.variant == 51 || this.variant == 54) {
/* 370 */       numBands = 3;
/*     */     }
/*     */     
/* 373 */     if (!seleBand) {
/* 374 */       sourceBands = new int[numBands];
/* 375 */       destBands = new int[numBands];
/* 376 */       for (int i8 = 0; i8 < numBands; i8++) {
/* 377 */         sourceBands[i8] = i8; destBands[i8] = i8;
/*     */       } 
/*     */     } 
/* 380 */     int dataType = 3;
/*     */     
/* 382 */     if (this.maxValue < 256) {
/* 383 */       dataType = 0;
/* 384 */     } else if (this.maxValue < 65536) {
/* 385 */       dataType = 1;
/*     */     } 
/*     */ 
/*     */     
/* 389 */     SampleModel sampleModel = null;
/* 390 */     ColorModel colorModel = null;
/* 391 */     if (this.variant == 49 || this.variant == 52) {
/*     */       
/* 393 */       sampleModel = new MultiPixelPackedSampleModel(0, destinationRegion.width, destinationRegion.height, 1);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 398 */       byte[] color = { -1, 0 };
/* 399 */       colorModel = new IndexColorModel(1, 2, color, color, color);
/*     */     } else {
/* 401 */       sampleModel = new PixelInterleavedSampleModel(dataType, destinationRegion.width, destinationRegion.height, sourceBands.length, destinationRegion.width * sourceBands.length, destBands);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 410 */       colorModel = ImageUtil.createColorModel(null, sampleModel);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 415 */     BufferedImage bi = param.getDestination();
/*     */ 
/*     */     
/* 418 */     WritableRaster raster = null;
/*     */     
/* 420 */     if (bi == null) {
/* 421 */       sampleModel = sampleModel.createCompatibleSampleModel(destinationRegion.x + destinationRegion.width, destinationRegion.y + destinationRegion.height);
/*     */ 
/*     */       
/* 424 */       if (seleBand) {
/* 425 */         sampleModel = sampleModel.createSubsetSampleModel(sourceBands);
/*     */       }
/* 427 */       raster = Raster.createWritableRaster(sampleModel, new Point());
/* 428 */       bi = new BufferedImage(colorModel, raster, false, null);
/*     */     } else {
/* 430 */       raster = bi.getWritableTile(0, 0);
/* 431 */       sampleModel = bi.getSampleModel();
/* 432 */       colorModel = bi.getColorModel();
/* 433 */       noTransform &= destinationRegion.equals(raster.getBounds());
/*     */     } 
/*     */     
/* 436 */     switch (this.variant) {
/*     */ 
/*     */ 
/*     */       
/*     */       case 52:
/* 441 */         dataBuffer = raster.getDataBuffer();
/*     */ 
/*     */         
/* 444 */         buf = ((DataBufferByte)dataBuffer).getData();
/* 445 */         if (noTransform) {
/* 446 */           this.iis.readFully(buf, 0, buf.length);
/* 447 */           processImageUpdate(bi, 0, 0, this.width, this.height, 1, 1, destBands);
/*     */ 
/*     */ 
/*     */           
/* 451 */           processImageProgress(100.0F); break;
/* 452 */         }  if (scaleX == 1 && sourceRegion.x % 8 == 0) {
/* 453 */           int skip = sourceRegion.x >> 3;
/* 454 */           int i8 = this.width + 7 >> 3;
/* 455 */           int i9 = raster.getWidth() + 7 >> 3;
/*     */           
/* 457 */           int readLength = sourceRegion.width + 7 >> 3;
/* 458 */           int i10 = sourceRegion.y * i8;
/* 459 */           this.iis.skipBytes(i10 + skip);
/* 460 */           i10 = i8 * (scaleY - 1) + i8 - readLength;
/* 461 */           byte[] lineData = new byte[readLength];
/*     */           
/* 463 */           int bitoff = destinationRegion.x & 0x7;
/* 464 */           boolean reformat = (bitoff != 0);
/*     */           
/* 466 */           int i11 = 0, i12 = 0;
/* 467 */           int i13 = destinationRegion.y * i9 + (destinationRegion.x >> 3);
/* 468 */           for (; i11 < destinationRegion.height; i11++, i12 += scaleY) {
/* 469 */             if (reformat) {
/* 470 */               this.iis.read(lineData, 0, readLength);
/* 471 */               int mask1 = 255 << bitoff & 0xFF;
/* 472 */               int mask2 = (mask1 ^ 0xFFFFFFFF) & 0xFF;
/* 473 */               int shift = 8 - bitoff;
/*     */               
/* 475 */               int i14 = 0;
/* 476 */               int i15 = i13;
/* 477 */               for (; i14 < readLength - 1; i14++, i15++) {
/* 478 */                 buf[i15] = (byte)((lineData[i14] & mask2) << shift | (lineData[i14 + 1] & mask1) >> bitoff);
/*     */               }
/* 480 */               buf[i15] = (byte)((lineData[i14] & mask2) << shift);
/*     */             } else {
/* 482 */               this.iis.read(buf, i13, readLength);
/*     */             } 
/*     */             
/* 485 */             this.iis.skipBytes(i10);
/* 486 */             i13 += i9;
/*     */             
/* 488 */             processImageUpdate(bi, 0, i11, destinationRegion.width, 1, 1, 1, destBands);
/*     */ 
/*     */ 
/*     */             
/* 492 */             processImageProgress(100.0F * i11 / destinationRegion.height);
/*     */           }  break;
/*     */         } 
/* 495 */         originalLS = this.width + 7 >> 3;
/* 496 */         data = new byte[originalLS];
/* 497 */         this.iis.skipBytes(sourceRegion.y * originalLS);
/* 498 */         destLS = bi.getWidth() + 7 >> 3;
/* 499 */         offset = originalLS * (scaleY - 1);
/* 500 */         i2 = destLS * destinationRegion.y + (destinationRegion.x >> 3);
/*     */         
/* 502 */         i3 = 0; j = 0; i6 = i2;
/* 503 */         for (; i3 < destinationRegion.height; i3++, j += scaleY) {
/* 504 */           this.iis.read(data, 0, originalLS);
/* 505 */           this.iis.skipBytes(offset);
/*     */           
/* 507 */           int b = 0;
/* 508 */           int pos = 7 - (destinationRegion.x & 0x7);
/* 509 */           int i8 = sourceRegion.x;
/* 510 */           for (; i8 < sourceRegion.x + sourceRegion.width; 
/* 511 */             i8 += scaleX) {
/* 512 */             b |= (data[i8 >> 3] >> 7 - (i8 & 0x7) & 0x1) << pos;
/* 513 */             pos--;
/* 514 */             if (pos == -1) {
/* 515 */               buf[i6++] = (byte)b;
/* 516 */               b = 0;
/* 517 */               pos = 7;
/*     */             } 
/*     */           } 
/*     */           
/* 521 */           if (pos != 7) {
/* 522 */             buf[i6++] = (byte)b;
/*     */           }
/* 524 */           i6 += destinationRegion.x >> 3;
/* 525 */           processImageUpdate(bi, 0, i3, destinationRegion.width, 1, 1, 1, destBands);
/*     */ 
/*     */ 
/*     */           
/* 529 */           processImageProgress(100.0F * i3 / destinationRegion.height);
/*     */         } 
/*     */         break;
/*     */ 
/*     */ 
/*     */       
/*     */       case 49:
/* 536 */         dataBuffer = raster.getDataBuffer();
/* 537 */         buf = ((DataBufferByte)dataBuffer).getData();
/* 538 */         if (noTransform) {
/* 539 */           for (int i8 = 0, i9 = 0; i8 < this.height; i8++) {
/* 540 */             int b = 0;
/* 541 */             int pos = 7;
/* 542 */             for (int i10 = 0; i10 < this.width; i10++) {
/* 543 */               b |= (readInteger(this.iis) & 0x1) << pos;
/* 544 */               pos--;
/* 545 */               if (pos == -1) {
/* 546 */                 buf[i9++] = (byte)b;
/* 547 */                 b = 0;
/* 548 */                 pos = 7;
/*     */               } 
/*     */             } 
/* 551 */             if (pos != 7)
/* 552 */               buf[i9++] = (byte)b; 
/* 553 */             processImageUpdate(bi, 0, i8, this.width, 1, 1, 1, destBands);
/*     */ 
/*     */ 
/*     */             
/* 557 */             processImageProgress(100.0F * i8 / this.height);
/*     */           }  break;
/*     */         } 
/* 560 */         skipInteger(this.iis, sourceRegion.y * this.width + sourceRegion.x);
/* 561 */         k = scaleX - 1;
/* 562 */         m = (scaleY - 1) * this.width + this.width - destinationRegion.width * scaleX;
/*     */         
/* 564 */         i1 = (bi.getWidth() + 7 >> 3) * destinationRegion.y + (destinationRegion.x >> 3);
/*     */         
/* 566 */         for (i = 0, n = i1; i < destinationRegion.height; i++) {
/* 567 */           int b = 0;
/* 568 */           int pos = 7 - (destinationRegion.x & 0x7);
/* 569 */           for (int i8 = 0; i8 < destinationRegion.width; i8++) {
/* 570 */             b |= (readInteger(this.iis) & 0x1) << pos;
/* 571 */             pos--;
/* 572 */             if (pos == -1) {
/* 573 */               buf[n++] = (byte)b;
/* 574 */               b = 0;
/* 575 */               pos = 7;
/*     */             } 
/* 577 */             skipInteger(this.iis, k);
/*     */           } 
/* 579 */           if (pos != 7) {
/* 580 */             buf[n++] = (byte)b;
/*     */           }
/* 582 */           n += destinationRegion.x >> 3;
/* 583 */           skipInteger(this.iis, m);
/* 584 */           processImageUpdate(bi, 0, i, destinationRegion.width, 1, 1, 1, destBands);
/*     */ 
/*     */ 
/*     */           
/* 588 */           processImageProgress(100.0F * i / destinationRegion.height);
/*     */         } 
/*     */         break;
/*     */ 
/*     */ 
/*     */       
/*     */       case 50:
/*     */       case 51:
/*     */       case 53:
/*     */       case 54:
/* 598 */         skipX = (scaleX - 1) * numBands;
/* 599 */         skipY = (scaleY * this.width - destinationRegion.width * scaleX) * numBands;
/*     */         
/* 601 */         dsx = (bi.getWidth() * destinationRegion.y + destinationRegion.x) * numBands;
/*     */         
/* 603 */         switch (dataType) {
/*     */           case 0:
/* 605 */             bbuf = (DataBufferByte)raster.getDataBuffer();
/*     */             
/* 607 */             byteArray = bbuf.getData();
/* 608 */             if (isRaw(this.variant)) {
/* 609 */               if (noTransform) {
/* 610 */                 this.iis.readFully(byteArray);
/* 611 */                 processImageUpdate(bi, 0, 0, this.width, this.height, 1, 1, destBands);
/*     */ 
/*     */ 
/*     */                 
/* 615 */                 processImageProgress(100.0F); break;
/*     */               } 
/* 617 */               this.iis.skipBytes(sourceRegion.y * this.width * numBands);
/* 618 */               int skip = (scaleY - 1) * this.width * numBands;
/* 619 */               byte[] arrayOfByte = new byte[this.width * numBands];
/* 620 */               int pixelStride = scaleX * numBands;
/* 621 */               int sx = sourceRegion.x * numBands;
/* 622 */               int ex = this.width;
/* 623 */               for (int i8 = 0, i9 = dsx; i8 < destinationRegion.height; i8++) {
/* 624 */                 this.iis.read(arrayOfByte);
/* 625 */                 int i10 = sourceRegion.x, i11 = sx;
/* 626 */                 for (; i10 < sourceRegion.x + sourceRegion.width; 
/* 627 */                   i10 += scaleX, i11 += pixelStride) {
/* 628 */                   for (int i12 = 0; i12 < sourceBands.length; i12++)
/* 629 */                     byteArray[i9 + destBands[i12]] = arrayOfByte[i11 + sourceBands[i12]]; 
/* 630 */                   i9 += sourceBands.length;
/*     */                 } 
/* 632 */                 i9 += destinationRegion.x * numBands;
/* 633 */                 this.iis.skipBytes(skip);
/* 634 */                 processImageUpdate(bi, 0, i8, destinationRegion.width, 1, 1, 1, destBands);
/*     */ 
/*     */ 
/*     */                 
/* 638 */                 processImageProgress(100.0F * i8 / destinationRegion.height);
/*     */               } 
/*     */               break;
/*     */             } 
/* 642 */             skipInteger(this.iis, (sourceRegion.y * this.width + sourceRegion.x) * numBands);
/*     */ 
/*     */ 
/*     */             
/* 646 */             if (seleBand) {
/* 647 */               byte[] arrayOfByte = new byte[numBands];
/* 648 */               for (int i8 = 0, i9 = dsx; i8 < destinationRegion.height; i8++) {
/* 649 */                 for (j = 0; j < destinationRegion.width; j++) {
/* 650 */                   int i10; for (i10 = 0; i10 < numBands; i10++)
/* 651 */                     arrayOfByte[i10] = (byte)readInteger(this.iis); 
/* 652 */                   for (i10 = 0; i10 < sourceBands.length; i10++)
/* 653 */                     byteArray[i9 + destBands[i10]] = arrayOfByte[sourceBands[i10]]; 
/* 654 */                   i9 += sourceBands.length;
/* 655 */                   skipInteger(this.iis, skipX);
/*     */                 } 
/* 657 */                 i9 += destinationRegion.x * sourceBands.length;
/* 658 */                 skipInteger(this.iis, skipY);
/* 659 */                 processImageUpdate(bi, 0, i8, destinationRegion.width, 1, 1, 1, destBands);
/*     */ 
/*     */ 
/*     */                 
/* 663 */                 processImageProgress(100.0F * i8 / destinationRegion.height);
/*     */               }  break;
/*     */             } 
/* 666 */             for (i = 0, n = dsx; i < destinationRegion.height; i++) {
/* 667 */               for (int i8 = 0; i8 < destinationRegion.width; i8++) {
/* 668 */                 for (int i9 = 0; i9 < numBands; i9++)
/* 669 */                   byteArray[n++] = (byte)readInteger(this.iis); 
/* 670 */                 skipInteger(this.iis, skipX);
/*     */               } 
/* 672 */               n += destinationRegion.x * sourceBands.length;
/* 673 */               skipInteger(this.iis, skipY);
/* 674 */               processImageUpdate(bi, 0, i, destinationRegion.width, 1, 1, 1, destBands);
/*     */ 
/*     */ 
/*     */               
/* 678 */               processImageProgress(100.0F * i / destinationRegion.height);
/*     */             } 
/*     */             break;
/*     */ 
/*     */           
/*     */           case 1:
/* 684 */             sbuf = (DataBufferUShort)raster.getDataBuffer();
/*     */             
/* 686 */             shortArray = sbuf.getData();
/* 687 */             skipInteger(this.iis, sourceRegion.y * this.width * numBands + sourceRegion.x);
/*     */             
/* 689 */             if (seleBand) {
/* 690 */               short[] arrayOfShort = new short[numBands];
/* 691 */               for (int i8 = 0; i8 < destinationRegion.height; i8++) {
/* 692 */                 for (int i9 = 0; i9 < destinationRegion.width; i9++) {
/* 693 */                   int i10; for (i10 = 0; i10 < numBands; i10++)
/* 694 */                     arrayOfShort[i10] = (short)readInteger(this.iis); 
/* 695 */                   for (i10 = 0; i10 < sourceBands.length; i10++)
/* 696 */                     shortArray[i6 + destBands[i10]] = arrayOfShort[sourceBands[i10]]; 
/* 697 */                   i6 += sourceBands.length;
/* 698 */                   skipInteger(this.iis, skipX);
/*     */                 } 
/* 700 */                 i6 += destinationRegion.x * sourceBands.length;
/* 701 */                 skipInteger(this.iis, skipY);
/* 702 */                 processImageUpdate(bi, 0, i8, destinationRegion.width, 1, 1, 1, destBands);
/*     */ 
/*     */ 
/*     */                 
/* 706 */                 processImageProgress(100.0F * i8 / destinationRegion.height);
/*     */               }  break;
/*     */             } 
/* 709 */             for (i3 = 0, i4 = dsx; i3 < destinationRegion.height; i3++) {
/* 710 */               for (int i8 = 0; i8 < destinationRegion.width; i8++) {
/* 711 */                 for (int i9 = 0; i9 < numBands; i9++)
/* 712 */                   shortArray[i4++] = (short)readInteger(this.iis); 
/* 713 */                 skipInteger(this.iis, skipX);
/*     */               } 
/* 715 */               i4 += destinationRegion.x * sourceBands.length;
/* 716 */               skipInteger(this.iis, skipY);
/* 717 */               processImageUpdate(bi, 0, i3, destinationRegion.width, 1, 1, 1, destBands);
/*     */ 
/*     */ 
/*     */               
/* 721 */               processImageProgress(100.0F * i3 / destinationRegion.height);
/*     */             } 
/*     */             break;
/*     */           
/*     */           case 3:
/* 726 */             ibuf = (DataBufferInt)raster.getDataBuffer();
/*     */             
/* 728 */             intArray = ibuf.getData();
/* 729 */             skipInteger(this.iis, sourceRegion.y * this.width * numBands + sourceRegion.x);
/* 730 */             if (seleBand) {
/* 731 */               int[] arrayOfInt = new int[numBands];
/* 732 */               for (int i8 = 0, i9 = dsx; i8 < destinationRegion.height; i8++) {
/* 733 */                 for (int i10 = 0; i10 < destinationRegion.width; i10++) {
/* 734 */                   int i11; for (i11 = 0; i11 < numBands; i11++)
/* 735 */                     arrayOfInt[i11] = readInteger(this.iis); 
/* 736 */                   for (i11 = 0; i11 < sourceBands.length; i11++)
/* 737 */                     intArray[i9 + destBands[i11]] = arrayOfInt[sourceBands[i11]]; 
/* 738 */                   i9 += sourceBands.length;
/* 739 */                   skipInteger(this.iis, skipX);
/*     */                 } 
/* 741 */                 i9 += destinationRegion.x * sourceBands.length;
/* 742 */                 skipInteger(this.iis, skipY);
/* 743 */                 processImageUpdate(bi, 0, i8, destinationRegion.width, 1, 1, 1, destBands);
/*     */ 
/*     */ 
/*     */                 
/* 747 */                 processImageProgress(100.0F * i8 / destinationRegion.height);
/*     */               }  break;
/*     */             } 
/* 750 */             for (i5 = 0, i7 = dsx; i5 < destinationRegion.height; i5++) {
/* 751 */               for (int i8 = 0; i8 < destinationRegion.width; i8++) {
/* 752 */                 for (int i9 = 0; i9 < numBands; i9++)
/* 753 */                   intArray[i7++] = readInteger(this.iis); 
/* 754 */                 skipInteger(this.iis, skipX);
/*     */               } 
/* 756 */               i7 += destinationRegion.x * sourceBands.length;
/* 757 */               skipInteger(this.iis, skipY);
/* 758 */               processImageUpdate(bi, 0, i5, destinationRegion.width, 1, 1, 1, destBands);
/*     */ 
/*     */ 
/*     */               
/* 762 */               processImageProgress(100.0F * i5 / destinationRegion.height);
/*     */             } 
/*     */             break;
/*     */         } 
/*     */         
/*     */         break;
/*     */     } 
/* 769 */     if (abortRequested()) {
/* 770 */       processReadAborted();
/*     */     } else {
/* 772 */       processImageComplete();
/* 773 */     }  return bi; }
/*     */ 
/*     */   
/*     */   public boolean canReadRaster() {
/* 777 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public Raster readRaster(int imageIndex, ImageReadParam param) throws IOException {
/* 782 */     BufferedImage bi = read(imageIndex, param);
/* 783 */     return bi.getData();
/*     */   }
/*     */   
/*     */   public void reset() {
/* 787 */     super.reset();
/* 788 */     this.iis = null;
/* 789 */     this.gotHeader = false;
/* 790 */     System.gc();
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isRaw(int v) {
/* 795 */     return (v >= 52);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void readComments(ImageInputStream stream, PNMMetadata metadata) throws IOException {
/* 801 */     String line = null;
/* 802 */     int pos = -1;
/* 803 */     stream.mark();
/* 804 */     while ((line = stream.readLine()) != null && (pos = line.indexOf("#")) >= 0)
/*     */     {
/* 806 */       metadata.addComment(line.substring(pos + 1).trim());
/*     */     }
/* 808 */     stream.reset();
/*     */   }
/*     */ 
/*     */   
/*     */   private int readInteger(ImageInputStream stream) throws IOException {
/* 813 */     boolean foundDigit = false;
/*     */     
/* 815 */     while (this.aLine == null) {
/* 816 */       this.aLine = stream.readLine();
/* 817 */       if (this.aLine == null)
/* 818 */         return 0; 
/* 819 */       int pos = this.aLine.indexOf("#");
/* 820 */       if (pos == 0) {
/* 821 */         this.aLine = null;
/* 822 */       } else if (pos > 0) {
/* 823 */         this.aLine = this.aLine.substring(0, pos - 1);
/*     */       } 
/* 825 */       if (this.aLine != null) {
/* 826 */         this.token = new StringTokenizer(this.aLine);
/*     */       }
/*     */     } 
/* 829 */     while (this.token.hasMoreTokens()) {
/* 830 */       String s = this.token.nextToken();
/*     */       
/*     */       try {
/* 833 */         return (new Integer(s)).intValue();
/* 834 */       } catch (NumberFormatException e) {}
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 839 */     if (!foundDigit) {
/* 840 */       this.aLine = null;
/* 841 */       return readInteger(stream);
/*     */     } 
/*     */     
/* 844 */     return 0;
/*     */   }
/*     */   
/*     */   private void skipInteger(ImageInputStream stream, int num) throws IOException {
/* 848 */     for (int i = 0; i < num; i++)
/* 849 */       readInteger(stream); 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/pnm/PNMImageReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */