/*     */ package com.sun.media.imageioimpl.plugins.tiff;
/*     */ 
/*     */ import com.sun.media.imageio.plugins.tiff.TIFFCompressor;
/*     */ import java.awt.Point;
/*     */ import java.awt.color.ColorSpace;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.ColorModel;
/*     */ import java.awt.image.ComponentColorModel;
/*     */ import java.awt.image.DataBufferByte;
/*     */ import java.awt.image.PixelInterleavedSampleModel;
/*     */ import java.awt.image.Raster;
/*     */ import java.awt.image.SampleModel;
/*     */ import java.awt.image.WritableRaster;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import javax.imageio.IIOException;
/*     */ import javax.imageio.IIOImage;
/*     */ import javax.imageio.ImageIO;
/*     */ import javax.imageio.ImageWriteParam;
/*     */ import javax.imageio.ImageWriter;
/*     */ import javax.imageio.metadata.IIOInvalidTreeException;
/*     */ import javax.imageio.metadata.IIOMetadata;
/*     */ import javax.imageio.metadata.IIOMetadataNode;
/*     */ import javax.imageio.plugins.jpeg.JPEGImageWriteParam;
/*     */ import javax.imageio.spi.ImageWriterSpi;
/*     */ import javax.imageio.stream.ImageOutputStream;
/*     */ import javax.imageio.stream.MemoryCacheImageOutputStream;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TIFFBaseJPEGCompressor
/*     */   extends TIFFCompressor
/*     */ {
/*     */   private static final boolean DEBUG = false;
/*     */   protected static final String STREAM_METADATA_NAME = "javax_imageio_jpeg_stream_1.0";
/*     */   protected static final String IMAGE_METADATA_NAME = "javax_imageio_jpeg_image_1.0";
/* 133 */   private ImageWriteParam param = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 139 */   protected JPEGImageWriteParam JPEGParam = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 145 */   protected ImageWriter JPEGWriter = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean writeAbbreviatedStream = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 160 */   protected IIOMetadata JPEGStreamMetadata = null;
/*     */ 
/*     */   
/* 163 */   private IIOMetadata JPEGImageMetadata = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean usingCodecLib;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private IIOByteArrayOutputStream baos;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void pruneNodes(Node tree, boolean pruneTables) {
/* 185 */     if (tree == null) {
/* 186 */       throw new IllegalArgumentException("tree == null!");
/*     */     }
/* 188 */     if (!tree.getNodeName().equals("javax_imageio_jpeg_image_1.0")) {
/* 189 */       throw new IllegalArgumentException("root node name is not javax_imageio_jpeg_image_1.0!");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 197 */     List<String> wantedNodes = new ArrayList();
/* 198 */     wantedNodes.addAll(Arrays.asList(new String[] { "JPEGvariety", "markerSequence", "sof", "componentSpec", "sos", "scanComponentSpec" }));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 205 */     if (!pruneTables) {
/* 206 */       wantedNodes.add("dht");
/* 207 */       wantedNodes.add("dhtable");
/* 208 */       wantedNodes.add("dqt");
/* 209 */       wantedNodes.add("dqtable");
/*     */     } 
/*     */     
/* 212 */     IIOMetadataNode iioTree = (IIOMetadataNode)tree;
/*     */     
/* 214 */     List<Node> nodes = getAllNodes(iioTree, (List)null);
/* 215 */     int numNodes = nodes.size();
/*     */     
/* 217 */     for (int i = 0; i < numNodes; i++) {
/* 218 */       Node node = nodes.get(i);
/* 219 */       if (!wantedNodes.contains(node.getNodeName()))
/*     */       {
/*     */ 
/*     */         
/* 223 */         node.getParentNode().removeChild(node);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private static List getAllNodes(IIOMetadataNode root, List<Node> nodes) {
/* 229 */     if (nodes == null) nodes = new ArrayList();
/*     */     
/* 231 */     if (root.hasChildNodes()) {
/* 232 */       Node sibling = root.getFirstChild();
/* 233 */       while (sibling != null) {
/* 234 */         nodes.add(sibling);
/* 235 */         nodes = getAllNodes((IIOMetadataNode)sibling, nodes);
/* 236 */         sibling = sibling.getNextSibling();
/*     */       } 
/*     */     } 
/*     */     
/* 240 */     return nodes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TIFFBaseJPEGCompressor(String compressionType, int compressionTagValue, boolean isCompressionLossless, ImageWriteParam param) {
/* 247 */     super(compressionType, compressionTagValue, isCompressionLossless);
/*     */     
/* 249 */     this.param = param;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class IIOByteArrayOutputStream
/*     */     extends ByteArrayOutputStream
/*     */   {
/*     */     IIOByteArrayOutputStream() {}
/*     */ 
/*     */ 
/*     */     
/*     */     IIOByteArrayOutputStream(int size) {
/* 262 */       super(size);
/*     */     }
/*     */ 
/*     */     
/*     */     public synchronized void writeTo(ImageOutputStream ios) throws IOException {
/* 267 */       ios.write(this.buf, 0, this.count);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initJPEGWriter(boolean supportsStreamMetadata, boolean supportsImageMetadata) {
/* 284 */     if (this.JPEGWriter != null && (supportsStreamMetadata || supportsImageMetadata)) {
/*     */       
/* 286 */       ImageWriterSpi spi = this.JPEGWriter.getOriginatingProvider();
/* 287 */       if (supportsStreamMetadata) {
/* 288 */         String smName = spi.getNativeStreamMetadataFormatName();
/* 289 */         if (smName == null || !smName.equals("javax_imageio_jpeg_stream_1.0")) {
/* 290 */           this.JPEGWriter = null;
/*     */         }
/*     */       } 
/* 293 */       if (this.JPEGWriter != null && supportsImageMetadata) {
/* 294 */         String imName = spi.getNativeImageMetadataFormatName();
/* 295 */         if (imName == null || !imName.equals("javax_imageio_jpeg_image_1.0")) {
/* 296 */           this.JPEGWriter = null;
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 302 */     if (this.JPEGWriter == null) {
/* 303 */       Iterator<ImageWriter> iter = ImageIO.getImageWritersByFormatName("jpeg");
/*     */       
/* 305 */       while (iter.hasNext()) {
/*     */         
/* 307 */         ImageWriter writer = iter.next();
/*     */ 
/*     */         
/* 310 */         if (supportsStreamMetadata || supportsImageMetadata) {
/* 311 */           ImageWriterSpi spi = writer.getOriginatingProvider();
/* 312 */           if (supportsStreamMetadata) {
/* 313 */             String smName = spi.getNativeStreamMetadataFormatName();
/*     */             
/* 315 */             if (smName == null || !smName.equals("javax_imageio_jpeg_stream_1.0")) {
/*     */               continue;
/*     */             }
/*     */           } 
/*     */ 
/*     */           
/* 321 */           if (supportsImageMetadata) {
/* 322 */             String imName = spi.getNativeImageMetadataFormatName();
/*     */             
/* 324 */             if (imName == null || !imName.equals("javax_imageio_jpeg_image_1.0")) {
/*     */               continue;
/*     */             }
/*     */           } 
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 333 */         this.JPEGWriter = writer;
/*     */       } 
/*     */ 
/*     */       
/* 337 */       if (this.JPEGWriter == null)
/*     */       {
/* 339 */         throw new IllegalStateException("No appropriate JPEG writers found!");
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 344 */     this.usingCodecLib = this.JPEGWriter.getClass().getName().startsWith("com.sun.media");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 349 */     if (this.JPEGParam == null) {
/* 350 */       if (this.param != null && this.param instanceof JPEGImageWriteParam) {
/* 351 */         this.JPEGParam = (JPEGImageWriteParam)this.param;
/*     */       } else {
/* 353 */         this.JPEGParam = new JPEGImageWriteParam((this.writer != null) ? this.writer.getLocale() : null);
/*     */ 
/*     */         
/* 356 */         if (this.param.getCompressionMode() == 2) {
/*     */           
/* 358 */           this.JPEGParam.setCompressionMode(2);
/* 359 */           this.JPEGParam.setCompressionQuality(this.param.getCompressionQuality());
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private IIOMetadata getImageMetadata(boolean pruneTables) throws IIOException {
/* 373 */     if (this.JPEGImageMetadata == null && "javax_imageio_jpeg_image_1.0".equals(this.JPEGWriter.getOriginatingProvider().getNativeImageMetadataFormatName())) {
/*     */       
/* 375 */       TIFFImageWriter tiffWriter = (TIFFImageWriter)this.writer;
/*     */ 
/*     */       
/* 378 */       this.JPEGImageMetadata = this.JPEGWriter.getDefaultImageMetadata(tiffWriter.imageType, this.JPEGParam);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 383 */       Node tree = this.JPEGImageMetadata.getAsTree("javax_imageio_jpeg_image_1.0");
/*     */ 
/*     */       
/*     */       try {
/* 387 */         pruneNodes(tree, pruneTables);
/* 388 */       } catch (IllegalArgumentException e) {
/* 389 */         throw new IIOException("Error pruning unwanted nodes", e);
/*     */       } 
/*     */ 
/*     */       
/*     */       try {
/* 394 */         this.JPEGImageMetadata.setFromTree("javax_imageio_jpeg_image_1.0", tree);
/* 395 */       } catch (IIOInvalidTreeException e) {
/*     */ 
/*     */ 
/*     */         
/* 399 */         throw new IIOException("Cannot set pruned image metadata!", e);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 404 */     return this.JPEGImageMetadata; } public final int encode(byte[] b, int off, int width, int height, int[] bitsPerSample, int scanlineStride) throws IOException {
/*     */     ImageOutputStream ios;
/*     */     long initialStreamPosition;
/*     */     DataBufferByte dbb;
/*     */     int[] offsets;
/*     */     ColorSpace cs;
/*     */     int compDataLength;
/* 411 */     if (this.JPEGWriter == null) {
/* 412 */       throw new IIOException("JPEG writer has not been initialized!");
/*     */     }
/*     */     
/* 415 */     if ((bitsPerSample.length != 3 || bitsPerSample[0] != 8 || bitsPerSample[1] != 8 || bitsPerSample[2] != 8) && (bitsPerSample.length != 1 || bitsPerSample[0] != 8))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 421 */       throw new IIOException("Can only JPEG compress 8- and 24-bit images!");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 428 */     if (this.usingCodecLib && !this.writeAbbreviatedStream) {
/* 429 */       ios = this.stream;
/* 430 */       initialStreamPosition = this.stream.getStreamPosition();
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 437 */       if (this.baos == null) {
/* 438 */         this.baos = new IIOByteArrayOutputStream();
/*     */       } else {
/* 440 */         this.baos.reset();
/*     */       } 
/* 442 */       ios = new MemoryCacheImageOutputStream(this.baos);
/* 443 */       initialStreamPosition = 0L;
/*     */     } 
/* 445 */     this.JPEGWriter.setOutput(ios);
/*     */ 
/*     */ 
/*     */     
/* 449 */     if (off == 0 || this.usingCodecLib) {
/* 450 */       dbb = new DataBufferByte(b, b.length);
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 456 */       int bytesPerSegment = scanlineStride * height;
/* 457 */       byte[] btmp = new byte[bytesPerSegment];
/* 458 */       System.arraycopy(b, off, btmp, 0, bytesPerSegment);
/* 459 */       dbb = new DataBufferByte(btmp, bytesPerSegment);
/* 460 */       off = 0;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 466 */     if (bitsPerSample.length == 3) {
/* 467 */       offsets = new int[] { off, off + 1, off + 2 };
/* 468 */       cs = ColorSpace.getInstance(1000);
/*     */     } else {
/* 470 */       offsets = new int[] { off };
/* 471 */       cs = ColorSpace.getInstance(1003);
/*     */     } 
/*     */ 
/*     */     
/* 475 */     ColorModel cm = new ComponentColorModel(cs, false, false, 1, 0);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 482 */     SampleModel sm = new PixelInterleavedSampleModel(0, width, height, bitsPerSample.length, scanlineStride, offsets);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 490 */     WritableRaster wras = Raster.createWritableRaster(sm, dbb, new Point(0, 0));
/*     */ 
/*     */ 
/*     */     
/* 494 */     BufferedImage bi = new BufferedImage(cm, wras, false, null);
/*     */ 
/*     */     
/* 497 */     IIOMetadata imageMetadata = getImageMetadata(this.writeAbbreviatedStream);
/*     */ 
/*     */ 
/*     */     
/* 501 */     if (this.usingCodecLib && !this.writeAbbreviatedStream) {
/*     */       
/* 503 */       this.JPEGWriter.write(null, new IIOImage(bi, null, imageMetadata), this.JPEGParam);
/*     */ 
/*     */       
/* 506 */       compDataLength = (int)(this.stream.getStreamPosition() - initialStreamPosition);
/*     */     } else {
/*     */       
/* 509 */       if (this.writeAbbreviatedStream) {
/*     */ 
/*     */ 
/*     */         
/* 513 */         this.JPEGWriter.prepareWriteSequence(this.JPEGStreamMetadata);
/* 514 */         ios.flush();
/*     */ 
/*     */         
/* 517 */         this.baos.reset();
/*     */ 
/*     */         
/* 520 */         IIOImage image = new IIOImage(bi, null, imageMetadata);
/* 521 */         this.JPEGWriter.writeToSequence(image, this.JPEGParam);
/* 522 */         this.JPEGWriter.endWriteSequence();
/*     */       } else {
/*     */         
/* 525 */         this.JPEGWriter.write(null, new IIOImage(bi, null, imageMetadata), this.JPEGParam);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 530 */       compDataLength = this.baos.size();
/* 531 */       this.baos.writeTo(this.stream);
/* 532 */       this.baos.reset();
/*     */     } 
/*     */     
/* 535 */     return compDataLength;
/*     */   }
/*     */   
/*     */   protected void finalize() throws Throwable {
/* 539 */     super.finalize();
/* 540 */     if (this.JPEGWriter != null)
/* 541 */       this.JPEGWriter.dispose(); 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/tiff/TIFFBaseJPEGCompressor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */