/*     */ package com.sun.media.imageioimpl.plugins.jpeg2000;
/*     */ 
/*     */ import javax.imageio.metadata.IIOInvalidTreeException;
/*     */ import javax.imageio.metadata.IIOMetadataNode;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XMLBox
/*     */   extends Box
/*     */ {
/*  94 */   private static String[] elementNames = new String[] { "Content" };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] getElementNames() {
/* 100 */     return elementNames;
/*     */   }
/*     */ 
/*     */   
/*     */   public XMLBox(byte[] data) {
/* 105 */     super(8 + data.length, 2020437024, data);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XMLBox(Node node) throws IIOInvalidTreeException {
/* 112 */     super(node);
/* 113 */     NodeList children = node.getChildNodes();
/*     */     
/* 115 */     for (int i = 0; i < children.getLength(); i++) {
/* 116 */       Node child = children.item(i);
/* 117 */       String name = child.getNodeName();
/*     */       
/* 119 */       if ("Content".equals(name)) {
/* 120 */         String value = child.getNodeValue();
/* 121 */         if (value != null) {
/* 122 */           this.data = value.getBytes();
/* 123 */         } else if (child instanceof IIOMetadataNode) {
/* 124 */           value = (String)((IIOMetadataNode)child).getUserObject();
/* 125 */           if (value != null) {
/* 126 */             this.data = value.getBytes();
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IIOMetadataNode getNativeNode() {
/*     */     try {
/* 138 */       IIOMetadataNode node = new IIOMetadataNode(Box.getName(getType()));
/* 139 */       setDefaultAttributes(node);
/* 140 */       IIOMetadataNode child = new IIOMetadataNode("Content");
/* 141 */       String value = null;
/* 142 */       if (this.data != null)
/* 143 */         value = new String(this.data); 
/* 144 */       child.setUserObject(value);
/* 145 */       child.setNodeValue(value);
/* 146 */       node.appendChild(child);
/* 147 */       return node;
/* 148 */     } catch (Exception e) {
/* 149 */       throw new IllegalArgumentException(I18N.getString("Box0"));
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/jpeg2000/XMLBox.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */