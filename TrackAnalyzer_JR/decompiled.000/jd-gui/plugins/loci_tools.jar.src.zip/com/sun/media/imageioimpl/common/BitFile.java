/*     */ package com.sun.media.imageioimpl.common;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.imageio.stream.ImageOutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BitFile
/*     */ {
/*     */   ImageOutputStream output_;
/*     */   byte[] buffer_;
/*     */   int index_;
/*     */   int bitsLeft_;
/*     */   boolean blocks_ = false;
/*     */   
/*     */   public BitFile(ImageOutputStream output, boolean blocks) {
/* 108 */     this.output_ = output;
/* 109 */     this.blocks_ = blocks;
/* 110 */     this.buffer_ = new byte[256];
/* 111 */     this.index_ = 0;
/* 112 */     this.bitsLeft_ = 8;
/*     */   }
/*     */ 
/*     */   
/*     */   public void flush() throws IOException {
/* 117 */     int numBytes = this.index_ + ((this.bitsLeft_ == 8) ? 0 : 1);
/* 118 */     if (numBytes > 0) {
/*     */       
/* 120 */       if (this.blocks_)
/* 121 */         this.output_.write(numBytes); 
/* 122 */       this.output_.write(this.buffer_, 0, numBytes);
/* 123 */       this.buffer_[0] = 0;
/* 124 */       this.index_ = 0;
/* 125 */       this.bitsLeft_ = 8;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeBits(int bits, int numbits) throws IOException {
/* 131 */     int bitsWritten = 0;
/* 132 */     int numBytes = 255;
/*     */ 
/*     */     
/*     */     do {
/* 136 */       if ((this.index_ == 254 && this.bitsLeft_ == 0) || this.index_ > 254) {
/*     */         
/* 138 */         if (this.blocks_) {
/* 139 */           this.output_.write(numBytes);
/*     */         }
/* 141 */         this.output_.write(this.buffer_, 0, numBytes);
/*     */         
/* 143 */         this.buffer_[0] = 0;
/* 144 */         this.index_ = 0;
/* 145 */         this.bitsLeft_ = 8;
/*     */       } 
/*     */       
/* 148 */       if (numbits <= this.bitsLeft_)
/*     */       {
/* 150 */         if (this.blocks_)
/*     */         {
/* 152 */           this.buffer_[this.index_] = (byte)(this.buffer_[this.index_] | (bits & (1 << numbits) - 1) << 8 - this.bitsLeft_);
/* 153 */           bitsWritten += numbits;
/* 154 */           this.bitsLeft_ -= numbits;
/* 155 */           numbits = 0;
/*     */         }
/*     */         else
/*     */         {
/* 159 */           this.buffer_[this.index_] = (byte)(this.buffer_[this.index_] | (bits & (1 << numbits) - 1) << this.bitsLeft_ - numbits);
/* 160 */           bitsWritten += numbits;
/* 161 */           this.bitsLeft_ -= numbits;
/* 162 */           numbits = 0;
/*     */         
/*     */         }
/*     */ 
/*     */       
/*     */       }
/* 168 */       else if (this.blocks_)
/*     */       {
/*     */ 
/*     */         
/* 172 */         this.buffer_[this.index_] = (byte)(this.buffer_[this.index_] | (bits & (1 << this.bitsLeft_) - 1) << 8 - this.bitsLeft_);
/* 173 */         bitsWritten += this.bitsLeft_;
/* 174 */         bits >>= this.bitsLeft_;
/* 175 */         numbits -= this.bitsLeft_;
/* 176 */         this.buffer_[++this.index_] = 0;
/* 177 */         this.bitsLeft_ = 8;
/*     */ 
/*     */       
/*     */       }
/*     */       else
/*     */       {
/*     */         
/* 184 */         int topbits = bits >>> numbits - this.bitsLeft_ & (1 << this.bitsLeft_) - 1;
/* 185 */         this.buffer_[this.index_] = (byte)(this.buffer_[this.index_] | topbits);
/* 186 */         numbits -= this.bitsLeft_;
/* 187 */         bitsWritten += this.bitsLeft_;
/* 188 */         this.buffer_[++this.index_] = 0;
/* 189 */         this.bitsLeft_ = 8;
/*     */       }
/*     */     
/*     */     }
/* 193 */     while (numbits != 0);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/common/BitFile.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */