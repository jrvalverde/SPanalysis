/*     */ package com.sun.media.imageioimpl.common;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.ColorModel;
/*     */ import java.awt.image.IndexColorModel;
/*     */ import java.awt.image.Raster;
/*     */ import java.awt.image.RenderedImage;
/*     */ import java.awt.image.WritableRaster;
/*     */ import javax.imageio.ImageTypeSpecifier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PaletteBuilder
/*     */ {
/*     */   protected static final int MAXLEVEL = 8;
/*     */   protected RenderedImage src;
/*     */   protected ColorModel srcColorModel;
/*     */   protected Raster srcRaster;
/*     */   protected int requiredSize;
/*     */   protected ColorNode root;
/*     */   protected int numNodes;
/*     */   protected int maxNodes;
/*     */   protected int currLevel;
/*     */   protected int currSize;
/*     */   protected ColorNode[] reduceList;
/*     */   protected ColorNode[] palette;
/*     */   protected int transparency;
/*     */   protected ColorNode transColor;
/*     */   
/*     */   public static RenderedImage createIndexedImage(RenderedImage src) {
/* 150 */     PaletteBuilder pb = new PaletteBuilder(src);
/* 151 */     pb.buildPalette();
/* 152 */     return pb.getIndexedImage();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IndexColorModel createIndexColorModel(RenderedImage img) {
/* 173 */     PaletteBuilder pb = new PaletteBuilder(img);
/* 174 */     pb.buildPalette();
/* 175 */     return pb.getIndexColorModel();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean canCreatePalette(ImageTypeSpecifier type) {
/* 192 */     if (type == null) {
/* 193 */       throw new IllegalArgumentException("type == null");
/*     */     }
/* 195 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean canCreatePalette(RenderedImage image) {
/* 212 */     if (image == null) {
/* 213 */       throw new IllegalArgumentException("image == null");
/*     */     }
/* 215 */     ImageTypeSpecifier type = new ImageTypeSpecifier(image);
/* 216 */     return canCreatePalette(type);
/*     */   }
/*     */   
/*     */   protected RenderedImage getIndexedImage() {
/* 220 */     IndexColorModel icm = getIndexColorModel();
/*     */     
/* 222 */     BufferedImage dst = new BufferedImage(this.src.getWidth(), this.src.getHeight(), 13, icm);
/*     */ 
/*     */ 
/*     */     
/* 226 */     WritableRaster wr = dst.getRaster();
/* 227 */     int minX = this.src.getMinX();
/* 228 */     int minY = this.src.getMinY();
/* 229 */     for (int y = 0; y < dst.getHeight(); y++) {
/* 230 */       for (int x = 0; x < dst.getWidth(); x++) {
/* 231 */         Color aColor = getSrcColor(x + minX, y + minY);
/* 232 */         wr.setSample(x, y, 0, findColorIndex(this.root, aColor));
/*     */       } 
/*     */     } 
/*     */     
/* 236 */     return dst;
/*     */   }
/*     */ 
/*     */   
/*     */   protected PaletteBuilder(RenderedImage src) {
/* 241 */     this(src, 256);
/*     */   }
/*     */   
/*     */   protected PaletteBuilder(RenderedImage src, int size) {
/* 245 */     this.src = src;
/* 246 */     this.srcColorModel = src.getColorModel();
/* 247 */     this.srcRaster = src.getData();
/*     */     
/* 249 */     this.transparency = this.srcColorModel.getTransparency();
/*     */ 
/*     */     
/* 252 */     if (this.transparency != 1) {
/* 253 */       this.requiredSize = size - 1;
/* 254 */       this.transColor = new ColorNode();
/* 255 */       this.transColor.isLeaf = true;
/*     */     } else {
/* 257 */       this.requiredSize = size;
/*     */     } 
/*     */   }
/*     */   
/*     */   private Color getSrcColor(int x, int y) {
/* 262 */     int argb = this.srcColorModel.getRGB(this.srcRaster.getDataElements(x, y, null));
/* 263 */     return new Color(argb, (this.transparency != 1));
/*     */   }
/*     */   
/*     */   protected int findColorIndex(ColorNode aNode, Color aColor) {
/* 267 */     if (this.transparency != 1 && aColor.getAlpha() != 255)
/*     */     {
/*     */       
/* 270 */       return 0;
/*     */     }
/*     */     
/* 273 */     if (aNode.isLeaf) {
/* 274 */       return aNode.paletteIndex;
/*     */     }
/* 276 */     int childIndex = getBranchIndex(aColor, aNode.level);
/*     */     
/* 278 */     return findColorIndex(aNode.children[childIndex], aColor);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void buildPalette() {
/* 283 */     this.reduceList = new ColorNode[9];
/* 284 */     for (int i = 0; i < this.reduceList.length; i++) {
/* 285 */       this.reduceList[i] = null;
/*     */     }
/*     */     
/* 288 */     this.numNodes = 0;
/* 289 */     this.maxNodes = 0;
/* 290 */     this.root = null;
/* 291 */     this.currSize = 0;
/* 292 */     this.currLevel = 8;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 299 */     int w = this.src.getWidth();
/* 300 */     int h = this.src.getHeight();
/* 301 */     int minX = this.src.getMinX();
/* 302 */     int minY = this.src.getMinY();
/* 303 */     for (int y = 0; y < h; y++) {
/* 304 */       for (int x = 0; x < w; x++) {
/*     */         
/* 306 */         Color aColor = getSrcColor(w - x + minX - 1, h - y + minY - 1);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 311 */         if (this.transparency != 1 && aColor.getAlpha() != 255) {
/*     */ 
/*     */           
/* 314 */           this.transColor = insertNode(this.transColor, aColor, 0);
/*     */         } else {
/* 316 */           this.root = insertNode(this.root, aColor, 0);
/*     */         } 
/* 318 */         if (this.currSize > this.requiredSize) {
/* 319 */           reduceTree();
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected ColorNode insertNode(ColorNode aNode, Color aColor, int aLevel) {
/* 327 */     if (aNode == null) {
/* 328 */       aNode = new ColorNode();
/* 329 */       this.numNodes++;
/* 330 */       if (this.numNodes > this.maxNodes) {
/* 331 */         this.maxNodes = this.numNodes;
/*     */       }
/* 333 */       aNode.level = aLevel;
/* 334 */       aNode.isLeaf = (aLevel > 8);
/* 335 */       if (aNode.isLeaf) {
/* 336 */         this.currSize++;
/*     */       }
/*     */     } 
/* 339 */     aNode.colorCount++;
/* 340 */     aNode.red += aColor.getRed();
/* 341 */     aNode.green += aColor.getGreen();
/* 342 */     aNode.blue += aColor.getBlue();
/*     */     
/* 344 */     if (!aNode.isLeaf) {
/* 345 */       int branchIndex = getBranchIndex(aColor, aLevel);
/* 346 */       if (aNode.children[branchIndex] == null) {
/* 347 */         aNode.childCount++;
/* 348 */         if (aNode.childCount == 2) {
/* 349 */           aNode.nextReducible = this.reduceList[aLevel];
/* 350 */           this.reduceList[aLevel] = aNode;
/*     */         } 
/*     */       } 
/* 353 */       aNode.children[branchIndex] = insertNode(aNode.children[branchIndex], aColor, aLevel + 1);
/*     */     } 
/*     */     
/* 356 */     return aNode;
/*     */   }
/*     */   
/*     */   protected IndexColorModel getIndexColorModel() {
/* 360 */     int size = this.currSize;
/* 361 */     if (this.transparency != 1) {
/* 362 */       size++;
/*     */     }
/*     */     
/* 365 */     byte[] red = new byte[size];
/* 366 */     byte[] green = new byte[size];
/* 367 */     byte[] blue = new byte[size];
/*     */     
/* 369 */     int index = 0;
/* 370 */     this.palette = new ColorNode[size];
/* 371 */     if (this.transparency != 1) {
/* 372 */       index++;
/*     */     }
/*     */     
/* 375 */     int lastIndex = findPaletteEntry(this.root, index, red, green, blue);
/*     */     
/* 377 */     IndexColorModel icm = null;
/* 378 */     if (this.transparency != 1) {
/* 379 */       icm = new IndexColorModel(8, size, red, green, blue, 0);
/*     */     } else {
/* 381 */       icm = new IndexColorModel(8, this.currSize, red, green, blue);
/*     */     } 
/* 383 */     return icm;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected int findPaletteEntry(ColorNode aNode, int index, byte[] red, byte[] green, byte[] blue) {
/* 389 */     if (aNode.isLeaf) {
/* 390 */       red[index] = (byte)(int)(aNode.red / aNode.colorCount);
/* 391 */       green[index] = (byte)(int)(aNode.green / aNode.colorCount);
/* 392 */       blue[index] = (byte)(int)(aNode.blue / aNode.colorCount);
/* 393 */       aNode.paletteIndex = index;
/*     */       
/* 395 */       this.palette[index] = aNode;
/*     */       
/* 397 */       index++;
/*     */     } else {
/* 399 */       for (int i = 0; i < 8; i++) {
/* 400 */         if (aNode.children[i] != null) {
/* 401 */           index = findPaletteEntry(aNode.children[i], index, red, green, blue);
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 406 */     return index;
/*     */   }
/*     */   
/*     */   protected int getBranchIndex(Color aColor, int aLevel) {
/* 410 */     if (aLevel > 8 || aLevel < 0) {
/* 411 */       throw new IllegalArgumentException("Invalid octree node depth: " + aLevel);
/*     */     }
/*     */ 
/*     */     
/* 415 */     int shift = 8 - aLevel;
/* 416 */     int red_index = 0x1 & (0xFF & aColor.getRed()) >> shift;
/* 417 */     int green_index = 0x1 & (0xFF & aColor.getGreen()) >> shift;
/* 418 */     int blue_index = 0x1 & (0xFF & aColor.getBlue()) >> shift;
/* 419 */     int index = red_index << 2 | green_index << 1 | blue_index;
/* 420 */     return index;
/*     */   }
/*     */   
/*     */   protected void reduceTree() {
/* 424 */     int level = this.reduceList.length - 1;
/* 425 */     while (this.reduceList[level] == null && level >= 0) {
/* 426 */       level--;
/*     */     }
/*     */     
/* 429 */     ColorNode thisNode = this.reduceList[level];
/* 430 */     if (thisNode == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 436 */     ColorNode pList = thisNode;
/* 437 */     int minColorCount = pList.colorCount;
/*     */     
/* 439 */     int cnt = 1;
/* 440 */     while (pList.nextReducible != null) {
/* 441 */       if (minColorCount > pList.nextReducible.colorCount) {
/* 442 */         thisNode = pList;
/* 443 */         minColorCount = pList.colorCount;
/*     */       } 
/* 445 */       pList = pList.nextReducible;
/* 446 */       cnt++;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 451 */     if (thisNode == this.reduceList[level]) {
/* 452 */       this.reduceList[level] = thisNode.nextReducible;
/*     */     } else {
/* 454 */       pList = thisNode.nextReducible;
/* 455 */       thisNode.nextReducible = pList.nextReducible;
/* 456 */       thisNode = pList;
/*     */     } 
/*     */     
/* 459 */     if (thisNode.isLeaf) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 464 */     int leafChildCount = thisNode.getLeafChildCount();
/* 465 */     thisNode.isLeaf = true;
/* 466 */     this.currSize -= leafChildCount - 1;
/* 467 */     int aDepth = thisNode.level;
/* 468 */     for (int i = 0; i < 8; i++) {
/* 469 */       thisNode.children[i] = freeTree(thisNode.children[i]);
/*     */     }
/* 471 */     thisNode.childCount = 0;
/*     */   }
/*     */   
/*     */   protected ColorNode freeTree(ColorNode aNode) {
/* 475 */     if (aNode == null) {
/* 476 */       return null;
/*     */     }
/* 478 */     for (int i = 0; i < 8; i++) {
/* 479 */       aNode.children[i] = freeTree(aNode.children[i]);
/*     */     }
/*     */     
/* 482 */     this.numNodes--;
/* 483 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected class ColorNode
/*     */   {
/*     */     public boolean isLeaf = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 506 */     public int level = 0;
/* 507 */     public int childCount = 0;
/* 508 */     ColorNode[] children = new ColorNode[8]; public int colorCount; public long red; public long blue; public ColorNode() {
/* 509 */       for (int i = 0; i < 8; i++) {
/* 510 */         this.children[i] = null;
/*     */       }
/*     */       
/* 513 */       this.colorCount = 0;
/* 514 */       this.red = this.green = this.blue = 0L;
/*     */       
/* 516 */       this.paletteIndex = 0;
/*     */     }
/*     */     public long green; public int paletteIndex; ColorNode nextReducible;
/*     */     public int getLeafChildCount() {
/* 520 */       if (this.isLeaf) {
/* 521 */         return 0;
/*     */       }
/* 523 */       int cnt = 0;
/* 524 */       for (int i = 0; i < this.children.length; i++) {
/* 525 */         if (this.children[i] != null) {
/* 526 */           if ((this.children[i]).isLeaf) {
/* 527 */             cnt++;
/*     */           } else {
/* 529 */             cnt += this.children[i].getLeafChildCount();
/*     */           } 
/*     */         }
/*     */       } 
/* 533 */       return cnt;
/*     */     }
/*     */     
/*     */     public int getRGB() {
/* 537 */       int r = (int)this.red / this.colorCount;
/* 538 */       int g = (int)this.green / this.colorCount;
/* 539 */       int b = (int)this.blue / this.colorCount;
/*     */       
/* 541 */       int c = 0xFF000000 | (0xFF & r) << 16 | (0xFF & g) << 8 | 0xFF & b;
/* 542 */       return c;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/common/PaletteBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */