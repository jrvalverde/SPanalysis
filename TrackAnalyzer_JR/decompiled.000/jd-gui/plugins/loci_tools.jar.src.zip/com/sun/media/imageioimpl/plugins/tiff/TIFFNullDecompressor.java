/*     */ package com.sun.media.imageioimpl.plugins.tiff;
/*     */ 
/*     */ import com.sun.media.imageio.plugins.tiff.TIFFDecompressor;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TIFFNullDecompressor
/*     */   extends TIFFDecompressor
/*     */ {
/*     */   private static final boolean DEBUG = false;
/*     */   private boolean isReadActiveOnly = false;
/*     */   private int originalSrcMinX;
/*     */   private int originalSrcMinY;
/*     */   private int originalSrcWidth;
/*     */   private int originalSrcHeight;
/*     */   
/*     */   public void beginDecoding() {
/* 119 */     int bitsPerPixel = 0;
/* 120 */     for (int i = 0; i < this.bitsPerSample.length; i++) {
/* 121 */       bitsPerPixel += this.bitsPerSample[i];
/*     */     }
/*     */ 
/*     */     
/* 125 */     if ((this.activeSrcMinX != this.srcMinX || this.activeSrcMinY != this.srcMinY || this.activeSrcWidth != this.srcWidth || this.activeSrcHeight != this.srcHeight) && (this.activeSrcMinX - this.srcMinX) * bitsPerPixel % 8 == 0) {
/*     */ 
/*     */ 
/*     */       
/* 129 */       this.isReadActiveOnly = true;
/*     */ 
/*     */       
/* 132 */       this.originalSrcMinX = this.srcMinX;
/* 133 */       this.originalSrcMinY = this.srcMinY;
/* 134 */       this.originalSrcWidth = this.srcWidth;
/* 135 */       this.originalSrcHeight = this.srcHeight;
/*     */ 
/*     */       
/* 138 */       this.srcMinX = this.activeSrcMinX;
/* 139 */       this.srcMinY = this.activeSrcMinY;
/* 140 */       this.srcWidth = this.activeSrcWidth;
/* 141 */       this.srcHeight = this.activeSrcHeight;
/*     */     } else {
/*     */       
/* 144 */       this.isReadActiveOnly = false;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 175 */     super.beginDecoding();
/*     */   }
/*     */   
/*     */   public void decode() throws IOException {
/* 179 */     super.decode();
/*     */ 
/*     */     
/* 182 */     if (this.isReadActiveOnly) {
/*     */       
/* 184 */       this.srcMinX = this.originalSrcMinX;
/* 185 */       this.srcMinY = this.originalSrcMinY;
/* 186 */       this.srcWidth = this.originalSrcWidth;
/* 187 */       this.srcHeight = this.originalSrcHeight;
/*     */ 
/*     */       
/* 190 */       this.isReadActiveOnly = false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void decodeRaw(byte[] b, int dstOffset, int bitsPerPixel, int scanlineStride) throws IOException {
/* 198 */     if (this.isReadActiveOnly) {
/*     */ 
/*     */       
/* 201 */       int activeBytesPerRow = (this.activeSrcWidth * bitsPerPixel + 7) / 8;
/* 202 */       int totalBytesPerRow = (this.originalSrcWidth * bitsPerPixel + 7) / 8;
/* 203 */       int bytesToSkipPerRow = totalBytesPerRow - activeBytesPerRow;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 219 */       this.stream.seek(this.offset + ((this.activeSrcMinY - this.originalSrcMinY) * totalBytesPerRow) + ((this.activeSrcMinX - this.originalSrcMinX) * bitsPerPixel / 8));
/*     */ 
/*     */ 
/*     */       
/* 223 */       int lastRow = this.activeSrcHeight - 1;
/* 224 */       for (int y = 0; y < this.activeSrcHeight; y++) {
/* 225 */         this.stream.read(b, dstOffset, activeBytesPerRow);
/* 226 */         dstOffset += scanlineStride;
/*     */ 
/*     */         
/* 229 */         if (y != lastRow) {
/* 230 */           this.stream.skipBytes(bytesToSkipPerRow);
/*     */         }
/*     */       } 
/*     */     } else {
/*     */       
/* 235 */       this.stream.seek(this.offset);
/* 236 */       int bytesPerRow = (this.srcWidth * bitsPerPixel + 7) / 8;
/* 237 */       if (bytesPerRow == scanlineStride) {
/* 238 */         this.stream.read(b, dstOffset, bytesPerRow * this.srcHeight);
/*     */       } else {
/* 240 */         for (int y = 0; y < this.srcHeight; y++) {
/* 241 */           this.stream.read(b, dstOffset, bytesPerRow);
/* 242 */           dstOffset += scanlineStride;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/tiff/TIFFNullDecompressor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */