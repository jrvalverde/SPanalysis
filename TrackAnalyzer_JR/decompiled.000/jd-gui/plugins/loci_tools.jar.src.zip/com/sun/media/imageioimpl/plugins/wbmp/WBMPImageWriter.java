/*     */ package com.sun.media.imageioimpl.plugins.wbmp;
/*     */ 
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.image.DataBufferByte;
/*     */ import java.awt.image.IndexColorModel;
/*     */ import java.awt.image.MultiPixelPackedSampleModel;
/*     */ import java.awt.image.Raster;
/*     */ import java.awt.image.RenderedImage;
/*     */ import java.awt.image.SampleModel;
/*     */ import java.awt.image.WritableRaster;
/*     */ import java.io.IOException;
/*     */ import javax.imageio.IIOImage;
/*     */ import javax.imageio.ImageTypeSpecifier;
/*     */ import javax.imageio.ImageWriteParam;
/*     */ import javax.imageio.ImageWriter;
/*     */ import javax.imageio.metadata.IIOMetadata;
/*     */ import javax.imageio.spi.ImageWriterSpi;
/*     */ import javax.imageio.stream.ImageOutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WBMPImageWriter
/*     */   extends ImageWriter
/*     */ {
/* 119 */   private ImageOutputStream stream = null;
/*     */ 
/*     */   
/*     */   private static int getNumBits(int intValue) {
/* 123 */     int numBits = 32;
/* 124 */     int mask = Integer.MIN_VALUE;
/* 125 */     while (mask != 0 && (intValue & mask) == 0) {
/* 126 */       numBits--;
/* 127 */       mask >>>= 1;
/*     */     } 
/* 129 */     return numBits;
/*     */   }
/*     */ 
/*     */   
/*     */   private static byte[] intToMultiByte(int intValue) {
/* 134 */     int numBitsLeft = getNumBits(intValue);
/* 135 */     byte[] multiBytes = new byte[(numBitsLeft + 6) / 7];
/*     */     
/* 137 */     int maxIndex = multiBytes.length - 1;
/* 138 */     for (int b = 0; b <= maxIndex; b++) {
/* 139 */       multiBytes[b] = (byte)(intValue >>> (maxIndex - b) * 7 & 0x7F);
/* 140 */       if (b != maxIndex) {
/* 141 */         multiBytes[b] = (byte)(multiBytes[b] | Byte.MIN_VALUE);
/*     */       }
/*     */     } 
/*     */     
/* 145 */     return multiBytes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WBMPImageWriter(ImageWriterSpi originator) {
/* 152 */     super(originator);
/*     */   }
/*     */   
/*     */   public void setOutput(Object output) {
/* 156 */     super.setOutput(output);
/* 157 */     if (output != null) {
/* 158 */       if (!(output instanceof ImageOutputStream))
/* 159 */         throw new IllegalArgumentException(I18N.getString("WBMPImageWriter")); 
/* 160 */       this.stream = (ImageOutputStream)output;
/*     */     } else {
/* 162 */       this.stream = null;
/*     */     } 
/*     */   }
/*     */   public IIOMetadata getDefaultStreamMetadata(ImageWriteParam param) {
/* 166 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public IIOMetadata getDefaultImageMetadata(ImageTypeSpecifier imageType, ImageWriteParam param) {
/* 171 */     WBMPMetadata meta = new WBMPMetadata();
/* 172 */     meta.wbmpType = 0;
/* 173 */     return meta;
/*     */   }
/*     */ 
/*     */   
/*     */   public IIOMetadata convertStreamMetadata(IIOMetadata inData, ImageWriteParam param) {
/* 178 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IIOMetadata convertImageMetadata(IIOMetadata metadata, ImageTypeSpecifier type, ImageWriteParam param) {
/* 184 */     return null;
/*     */   }
/*     */   
/*     */   public boolean canWriteRasters() {
/* 188 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(IIOMetadata streamMetadata, IIOImage image, ImageWriteParam param) throws IOException {
/* 194 */     if (this.stream == null) {
/* 195 */       throw new IllegalStateException(I18N.getString("WBMPImageWriter3"));
/*     */     }
/*     */     
/* 198 */     if (image == null) {
/* 199 */       throw new IllegalArgumentException(I18N.getString("WBMPImageWriter4"));
/*     */     }
/*     */     
/* 202 */     clearAbortRequest();
/* 203 */     processImageStarted(0);
/* 204 */     if (param == null) {
/* 205 */       param = getDefaultWriteParam();
/*     */     }
/* 207 */     RenderedImage input = null;
/* 208 */     Raster inputRaster = null;
/* 209 */     boolean writeRaster = image.hasRaster();
/* 210 */     Rectangle sourceRegion = param.getSourceRegion();
/* 211 */     SampleModel sampleModel = null;
/*     */     
/* 213 */     if (writeRaster) {
/* 214 */       inputRaster = image.getRaster();
/* 215 */       sampleModel = inputRaster.getSampleModel();
/*     */     } else {
/* 217 */       input = image.getRenderedImage();
/* 218 */       sampleModel = input.getSampleModel();
/*     */       
/* 220 */       inputRaster = input.getData();
/*     */     } 
/*     */     
/* 223 */     checkSampleModel(sampleModel);
/* 224 */     if (sourceRegion == null) {
/* 225 */       sourceRegion = inputRaster.getBounds();
/*     */     } else {
/* 227 */       sourceRegion = sourceRegion.intersection(inputRaster.getBounds());
/*     */     } 
/* 229 */     if (sourceRegion.isEmpty()) {
/* 230 */       throw new RuntimeException(I18N.getString("WBMPImageWriter1"));
/*     */     }
/* 232 */     int scaleX = param.getSourceXSubsampling();
/* 233 */     int scaleY = param.getSourceYSubsampling();
/* 234 */     int xOffset = param.getSubsamplingXOffset();
/* 235 */     int yOffset = param.getSubsamplingYOffset();
/*     */     
/* 237 */     sourceRegion.translate(xOffset, yOffset);
/* 238 */     sourceRegion.width -= xOffset;
/* 239 */     sourceRegion.height -= yOffset;
/*     */     
/* 241 */     int minX = sourceRegion.x / scaleX;
/* 242 */     int minY = sourceRegion.y / scaleY;
/* 243 */     int w = (sourceRegion.width + scaleX - 1) / scaleX;
/* 244 */     int h = (sourceRegion.height + scaleY - 1) / scaleY;
/*     */     
/* 246 */     Rectangle destinationRegion = new Rectangle(minX, minY, w, h);
/* 247 */     sampleModel = sampleModel.createCompatibleSampleModel(w, h);
/*     */     
/* 249 */     SampleModel destSM = sampleModel;
/*     */ 
/*     */     
/* 252 */     if (sampleModel.getDataType() != 0 || !(sampleModel instanceof MultiPixelPackedSampleModel) || ((MultiPixelPackedSampleModel)sampleModel).getDataBitOffset() != 0)
/*     */     {
/*     */       
/* 255 */       destSM = new MultiPixelPackedSampleModel(0, w, h, 1, w + 7 >> 3, 0);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 261 */     if (!destinationRegion.equals(sourceRegion)) {
/* 262 */       if (scaleX == 1 && scaleY == 1) {
/* 263 */         inputRaster = inputRaster.createChild(inputRaster.getMinX(), inputRaster.getMinY(), w, h, minX, minY, null);
/*     */       }
/*     */       else {
/*     */         
/* 267 */         WritableRaster ras = Raster.createWritableRaster(destSM, new Point(minX, minY));
/*     */ 
/*     */         
/* 270 */         byte[] data = ((DataBufferByte)ras.getDataBuffer()).getData();
/*     */         
/* 272 */         int j = minY, y = sourceRegion.y, k = 0;
/* 273 */         for (; j < minY + h; j++, y += scaleY) {
/*     */           
/* 275 */           int i = 0, x = sourceRegion.x;
/* 276 */           for (; i < w; i++, x += scaleX) {
/* 277 */             int v = inputRaster.getSample(x, y, 0);
/* 278 */             data[k + (i >> 3)] = (byte)(data[k + (i >> 3)] | v << 7 - (i & 0x7));
/*     */           } 
/* 280 */           k += w + 7 >> 3;
/*     */         } 
/* 282 */         inputRaster = ras;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 287 */     if (!destSM.equals(inputRaster.getSampleModel())) {
/* 288 */       WritableRaster raster = Raster.createWritableRaster(destSM, new Point(inputRaster.getMinX(), inputRaster.getMinY()));
/*     */ 
/*     */ 
/*     */       
/* 292 */       raster.setRect(inputRaster);
/* 293 */       inputRaster = raster;
/*     */     } 
/*     */ 
/*     */     
/* 297 */     boolean isWhiteZero = false;
/* 298 */     if (!writeRaster && input.getColorModel() instanceof IndexColorModel) {
/* 299 */       IndexColorModel icm = (IndexColorModel)input.getColorModel();
/* 300 */       isWhiteZero = (icm.getRed(0) > icm.getRed(1));
/*     */     } 
/*     */ 
/*     */     
/* 304 */     int lineStride = ((MultiPixelPackedSampleModel)destSM).getScanlineStride();
/*     */     
/* 306 */     int bytesPerRow = (w + 7) / 8;
/* 307 */     byte[] bdata = ((DataBufferByte)inputRaster.getDataBuffer()).getData();
/*     */ 
/*     */     
/* 310 */     this.stream.write(0);
/* 311 */     this.stream.write(0);
/* 312 */     this.stream.write(intToMultiByte(w));
/* 313 */     this.stream.write(intToMultiByte(h));
/*     */ 
/*     */     
/* 316 */     if (!isWhiteZero && lineStride == bytesPerRow) {
/*     */       
/* 318 */       this.stream.write(bdata, 0, h * bytesPerRow);
/* 319 */       processImageProgress(100.0F);
/*     */     } else {
/*     */       
/* 322 */       int offset = 0;
/* 323 */       if (!isWhiteZero) {
/*     */         
/* 325 */         for (int row = 0; row < h && 
/* 326 */           !abortRequested(); row++) {
/*     */           
/* 328 */           this.stream.write(bdata, offset, bytesPerRow);
/* 329 */           offset += lineStride;
/* 330 */           processImageProgress(100.0F * row / h);
/*     */         } 
/*     */       } else {
/*     */         
/* 334 */         byte[] inverted = new byte[bytesPerRow];
/* 335 */         for (int row = 0; row < h && 
/* 336 */           !abortRequested(); row++) {
/*     */           
/* 338 */           for (int col = 0; col < bytesPerRow; col++) {
/* 339 */             inverted[col] = (byte)(bdata[col + offset] ^ 0xFFFFFFFF);
/*     */           }
/* 341 */           this.stream.write(inverted, 0, bytesPerRow);
/* 342 */           offset += lineStride;
/* 343 */           processImageProgress(100.0F * row / h);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 348 */     if (abortRequested()) {
/* 349 */       processWriteAborted();
/*     */     } else {
/* 351 */       processImageComplete();
/* 352 */       this.stream.flushBefore(this.stream.getStreamPosition());
/*     */     } 
/*     */   }
/*     */   
/*     */   public void reset() {
/* 357 */     super.reset();
/* 358 */     this.stream = null;
/*     */   }
/*     */   
/*     */   private void checkSampleModel(SampleModel sm) {
/* 362 */     int type = sm.getDataType();
/* 363 */     if (type < 0 || type > 3 || sm.getNumBands() != 1 || sm.getSampleSize(0) != 1)
/*     */     {
/* 365 */       throw new IllegalArgumentException(I18N.getString("WBMPImageWriter2"));
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/wbmp/WBMPImageWriter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */