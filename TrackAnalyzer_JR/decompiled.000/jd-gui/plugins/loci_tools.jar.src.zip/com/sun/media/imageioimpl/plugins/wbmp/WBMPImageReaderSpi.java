/*     */ package com.sun.media.imageioimpl.plugins.wbmp;
/*     */ 
/*     */ import com.sun.media.imageioimpl.common.ImageUtil;
/*     */ import com.sun.media.imageioimpl.common.PackageUtil;
/*     */ import java.io.IOException;
/*     */ import java.util.Locale;
/*     */ import javax.imageio.IIOException;
/*     */ import javax.imageio.ImageReader;
/*     */ import javax.imageio.spi.ImageReaderSpi;
/*     */ import javax.imageio.spi.ServiceRegistry;
/*     */ import javax.imageio.stream.ImageInputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WBMPImageReaderSpi
/*     */   extends ImageReaderSpi
/*     */ {
/*  96 */   private static String[] writerSpiNames = new String[] { "com.sun.media.imageioimpl.plugins.wbmp.WBMPImageWriterSpi" };
/*     */   
/*  98 */   private static String[] formatNames = new String[] { "wbmp", "WBMP" };
/*  99 */   private static String[] entensions = new String[] { "wbmp" };
/* 100 */   private static String[] mimeType = new String[] { "image/vnd.wap.wbmp" };
/*     */   
/*     */   private boolean registered = false;
/*     */   
/*     */   public WBMPImageReaderSpi() {
/* 105 */     super(PackageUtil.getVendor(), PackageUtil.getVersion(), formatNames, entensions, mimeType, "com.sun.media.imageioimpl.plugins.wbmp.WBMPImageReader", STANDARD_INPUT_TYPE, writerSpiNames, true, null, null, null, null, true, "com_sun_media_imageio_plugins_wbmp_image_1.0", "com.sun.media.imageioimpl.plugins.wbmp.WBMPMetadataFormat", null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onRegistration(ServiceRegistry registry, Class category) {
/* 123 */     if (this.registered) {
/*     */       return;
/*     */     }
/* 126 */     this.registered = true;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 131 */     ImageUtil.processOnRegistration(registry, category, "WBMP", this, 8, 7);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDescription(Locale locale) {
/* 136 */     String desc = PackageUtil.getSpecificationTitle() + " WBMP Image Reader";
/*     */     
/* 138 */     return desc;
/*     */   }
/*     */   
/*     */   public boolean canDecodeInput(Object source) throws IOException {
/* 142 */     if (!(source instanceof ImageInputStream)) {
/* 143 */       return false;
/*     */     }
/*     */     
/* 146 */     ImageInputStream stream = (ImageInputStream)source;
/*     */     
/* 148 */     stream.mark();
/* 149 */     int type = stream.readByte();
/* 150 */     byte fixHeaderField = stream.readByte();
/*     */     
/* 152 */     int width = ImageUtil.readMultiByteInteger(stream);
/* 153 */     int height = ImageUtil.readMultiByteInteger(stream);
/*     */     
/* 155 */     long remainingBytes = stream.length() - stream.getStreamPosition();
/* 156 */     stream.reset();
/*     */ 
/*     */     
/* 159 */     if (type != 0 || fixHeaderField != 0)
/*     */     {
/* 161 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 165 */     if (width <= 0 || height <= 0) {
/* 166 */       return false;
/*     */     }
/*     */     
/* 169 */     long scanSize = (width / 8 + ((width % 8 == 0) ? 0 : 1));
/*     */     
/* 171 */     return (remainingBytes == scanSize * height);
/*     */   }
/*     */ 
/*     */   
/*     */   public ImageReader createReaderInstance(Object extension) throws IIOException {
/* 176 */     return new WBMPImageReader(this);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/wbmp/WBMPImageReaderSpi.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */