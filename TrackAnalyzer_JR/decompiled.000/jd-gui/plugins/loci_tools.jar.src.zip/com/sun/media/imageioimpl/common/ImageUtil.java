/*      */ package com.sun.media.imageioimpl.common;
/*      */ 
/*      */ import java.awt.Rectangle;
/*      */ import java.awt.color.ColorSpace;
/*      */ import java.awt.image.BufferedImage;
/*      */ import java.awt.image.ColorModel;
/*      */ import java.awt.image.ComponentColorModel;
/*      */ import java.awt.image.ComponentSampleModel;
/*      */ import java.awt.image.DataBuffer;
/*      */ import java.awt.image.DataBufferByte;
/*      */ import java.awt.image.DataBufferInt;
/*      */ import java.awt.image.DataBufferShort;
/*      */ import java.awt.image.DataBufferUShort;
/*      */ import java.awt.image.DirectColorModel;
/*      */ import java.awt.image.IndexColorModel;
/*      */ import java.awt.image.MultiPixelPackedSampleModel;
/*      */ import java.awt.image.Raster;
/*      */ import java.awt.image.RenderedImage;
/*      */ import java.awt.image.SampleModel;
/*      */ import java.awt.image.SinglePixelPackedSampleModel;
/*      */ import java.awt.image.WritableRaster;
/*      */ import java.io.IOException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import javax.imageio.IIOException;
/*      */ import javax.imageio.ImageReadParam;
/*      */ import javax.imageio.ImageTypeSpecifier;
/*      */ import javax.imageio.ImageWriter;
/*      */ import javax.imageio.spi.IIORegistry;
/*      */ import javax.imageio.spi.ImageReaderSpi;
/*      */ import javax.imageio.spi.ImageReaderWriterSpi;
/*      */ import javax.imageio.spi.ImageWriterSpi;
/*      */ import javax.imageio.spi.ServiceRegistry;
/*      */ import javax.imageio.stream.ImageInputStream;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ImageUtil
/*      */ {
/*      */   public static final ColorModel createColorModel(SampleModel sampleModel) {
/*  208 */     if (sampleModel == null) {
/*  209 */       throw new IllegalArgumentException("sampleModel == null!");
/*      */     }
/*      */ 
/*      */     
/*  213 */     int dataType = sampleModel.getDataType();
/*      */ 
/*      */     
/*  216 */     switch (dataType) {
/*      */       case 0:
/*      */       case 1:
/*      */       case 2:
/*      */       case 3:
/*      */       case 4:
/*      */       case 5:
/*      */         break;
/*      */       
/*      */       default:
/*  226 */         return null;
/*      */     } 
/*      */ 
/*      */     
/*  230 */     ColorModel colorModel = null;
/*      */ 
/*      */     
/*  233 */     int[] sampleSize = sampleModel.getSampleSize();
/*      */ 
/*      */     
/*  236 */     if (sampleModel instanceof ComponentSampleModel) {
/*      */       
/*  238 */       int numBands = sampleModel.getNumBands();
/*      */ 
/*      */       
/*  241 */       ColorSpace colorSpace = null;
/*  242 */       if (numBands <= 2) {
/*  243 */         colorSpace = ColorSpace.getInstance(1003);
/*  244 */       } else if (numBands <= 4) {
/*  245 */         colorSpace = ColorSpace.getInstance(1000);
/*      */       } else {
/*  247 */         colorSpace = new BogusColorSpace(numBands);
/*      */       } 
/*      */       
/*  250 */       boolean hasAlpha = (numBands == 2 || numBands == 4);
/*  251 */       boolean isAlphaPremultiplied = false;
/*  252 */       int transparency = hasAlpha ? 3 : 1;
/*      */ 
/*      */       
/*  255 */       colorModel = new ComponentColorModel(colorSpace, sampleSize, hasAlpha, isAlphaPremultiplied, transparency, dataType);
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */       
/*  261 */       if (sampleModel.getNumBands() <= 4 && sampleModel instanceof SinglePixelPackedSampleModel) {
/*      */         
/*  263 */         SinglePixelPackedSampleModel sppsm = (SinglePixelPackedSampleModel)sampleModel;
/*      */ 
/*      */         
/*  266 */         int[] bitMasks = sppsm.getBitMasks();
/*  267 */         int rmask = 0;
/*  268 */         int gmask = 0;
/*  269 */         int bmask = 0;
/*  270 */         int amask = 0;
/*      */         
/*  272 */         int numBands = bitMasks.length;
/*  273 */         if (numBands <= 2) {
/*  274 */           rmask = gmask = bmask = bitMasks[0];
/*  275 */           if (numBands == 2) {
/*  276 */             amask = bitMasks[1];
/*      */           }
/*      */         } else {
/*  279 */           rmask = bitMasks[0];
/*  280 */           gmask = bitMasks[1];
/*  281 */           bmask = bitMasks[2];
/*  282 */           if (numBands == 4) {
/*  283 */             amask = bitMasks[3];
/*      */           }
/*      */         } 
/*      */         
/*  287 */         int bits = 0;
/*  288 */         for (int i = 0; i < sampleSize.length; i++) {
/*  289 */           bits += sampleSize[i];
/*      */         }
/*      */         
/*  292 */         return new DirectColorModel(bits, rmask, gmask, bmask, amask);
/*      */       } 
/*  294 */       if (sampleModel instanceof MultiPixelPackedSampleModel) {
/*      */         
/*  296 */         int bitsPerSample = sampleSize[0];
/*  297 */         int numEntries = 1 << bitsPerSample;
/*  298 */         byte[] map = new byte[numEntries];
/*  299 */         for (int i = 0; i < numEntries; i++) {
/*  300 */           map[i] = (byte)(i * 255 / (numEntries - 1));
/*      */         }
/*      */         
/*  303 */         colorModel = new IndexColorModel(bitsPerSample, numEntries, map, map, map);
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  308 */     return colorModel;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] getPackedBinaryData(Raster raster, Rectangle rect) {
/*  328 */     SampleModel sm = raster.getSampleModel();
/*  329 */     if (!isBinary(sm)) {
/*  330 */       throw new IllegalArgumentException(I18N.getString("ImageUtil0"));
/*      */     }
/*      */     
/*  333 */     int rectX = rect.x;
/*  334 */     int rectY = rect.y;
/*  335 */     int rectWidth = rect.width;
/*  336 */     int rectHeight = rect.height;
/*      */     
/*  338 */     DataBuffer dataBuffer = raster.getDataBuffer();
/*      */     
/*  340 */     int dx = rectX - raster.getSampleModelTranslateX();
/*  341 */     int dy = rectY - raster.getSampleModelTranslateY();
/*      */     
/*  343 */     MultiPixelPackedSampleModel mpp = (MultiPixelPackedSampleModel)sm;
/*  344 */     int lineStride = mpp.getScanlineStride();
/*  345 */     int eltOffset = dataBuffer.getOffset() + mpp.getOffset(dx, dy);
/*  346 */     int bitOffset = mpp.getBitOffset(dx);
/*      */     
/*  348 */     int numBytesPerRow = (rectWidth + 7) / 8;
/*  349 */     if (dataBuffer instanceof DataBufferByte && eltOffset == 0 && bitOffset == 0 && numBytesPerRow == lineStride && (((DataBufferByte)dataBuffer).getData()).length == numBytesPerRow * rectHeight)
/*      */     {
/*      */ 
/*      */ 
/*      */       
/*  354 */       return ((DataBufferByte)dataBuffer).getData();
/*      */     }
/*      */     
/*  357 */     byte[] binaryDataArray = new byte[numBytesPerRow * rectHeight];
/*      */     
/*  359 */     int b = 0;
/*      */     
/*  361 */     if (bitOffset == 0) {
/*  362 */       if (dataBuffer instanceof DataBufferByte) {
/*  363 */         byte[] data = ((DataBufferByte)dataBuffer).getData();
/*  364 */         int stride = numBytesPerRow;
/*  365 */         int offset = 0;
/*  366 */         for (int y = 0; y < rectHeight; y++) {
/*  367 */           System.arraycopy(data, eltOffset, binaryDataArray, offset, stride);
/*      */ 
/*      */           
/*  370 */           offset += stride;
/*  371 */           eltOffset += lineStride;
/*      */         } 
/*  373 */       } else if (dataBuffer instanceof DataBufferShort || dataBuffer instanceof DataBufferUShort) {
/*      */         
/*  375 */         short[] data = (dataBuffer instanceof DataBufferShort) ? ((DataBufferShort)dataBuffer).getData() : ((DataBufferUShort)dataBuffer).getData();
/*      */ 
/*      */ 
/*      */         
/*  379 */         for (int y = 0; y < rectHeight; y++) {
/*  380 */           int xRemaining = rectWidth;
/*  381 */           int i = eltOffset;
/*  382 */           while (xRemaining > 8) {
/*  383 */             short datum = data[i++];
/*  384 */             binaryDataArray[b++] = (byte)(datum >>> 8 & 0xFF);
/*  385 */             binaryDataArray[b++] = (byte)(datum & 0xFF);
/*  386 */             xRemaining -= 16;
/*      */           } 
/*  388 */           if (xRemaining > 0) {
/*  389 */             binaryDataArray[b++] = (byte)(data[i] >>> 8 & 0xFF);
/*      */           }
/*  391 */           eltOffset += lineStride;
/*      */         } 
/*  393 */       } else if (dataBuffer instanceof DataBufferInt) {
/*  394 */         int[] data = ((DataBufferInt)dataBuffer).getData();
/*      */         
/*  396 */         for (int y = 0; y < rectHeight; y++) {
/*  397 */           int xRemaining = rectWidth;
/*  398 */           int i = eltOffset;
/*  399 */           while (xRemaining > 24) {
/*  400 */             int datum = data[i++];
/*  401 */             binaryDataArray[b++] = (byte)(datum >>> 24 & 0xFF);
/*  402 */             binaryDataArray[b++] = (byte)(datum >>> 16 & 0xFF);
/*  403 */             binaryDataArray[b++] = (byte)(datum >>> 8 & 0xFF);
/*  404 */             binaryDataArray[b++] = (byte)(datum & 0xFF);
/*  405 */             xRemaining -= 32;
/*      */           } 
/*  407 */           int shift = 24;
/*  408 */           while (xRemaining > 0) {
/*  409 */             binaryDataArray[b++] = (byte)(data[i] >>> shift & 0xFF);
/*      */             
/*  411 */             shift -= 8;
/*  412 */             xRemaining -= 8;
/*      */           } 
/*  414 */           eltOffset += lineStride;
/*      */         }
/*      */       
/*      */       } 
/*  418 */     } else if (dataBuffer instanceof DataBufferByte) {
/*  419 */       byte[] data = ((DataBufferByte)dataBuffer).getData();
/*      */       
/*  421 */       if ((bitOffset & 0x7) == 0) {
/*  422 */         int stride = numBytesPerRow;
/*  423 */         int offset = 0;
/*  424 */         for (int y = 0; y < rectHeight; y++) {
/*  425 */           System.arraycopy(data, eltOffset, binaryDataArray, offset, stride);
/*      */ 
/*      */           
/*  428 */           offset += stride;
/*  429 */           eltOffset += lineStride;
/*      */         } 
/*      */       } else {
/*  432 */         int leftShift = bitOffset & 0x7;
/*  433 */         int rightShift = 8 - leftShift;
/*  434 */         for (int y = 0; y < rectHeight; y++) {
/*  435 */           int i = eltOffset;
/*  436 */           int xRemaining = rectWidth;
/*  437 */           while (xRemaining > 0) {
/*  438 */             if (xRemaining > rightShift) {
/*  439 */               binaryDataArray[b++] = (byte)((data[i++] & 0xFF) << leftShift | (data[i] & 0xFF) >>> rightShift);
/*      */             }
/*      */             else {
/*      */               
/*  443 */               binaryDataArray[b++] = (byte)((data[i] & 0xFF) << leftShift);
/*      */             } 
/*      */             
/*  446 */             xRemaining -= 8;
/*      */           } 
/*  448 */           eltOffset += lineStride;
/*      */         } 
/*      */       } 
/*  451 */     } else if (dataBuffer instanceof DataBufferShort || dataBuffer instanceof DataBufferUShort) {
/*      */       
/*  453 */       short[] data = (dataBuffer instanceof DataBufferShort) ? ((DataBufferShort)dataBuffer).getData() : ((DataBufferUShort)dataBuffer).getData();
/*      */ 
/*      */ 
/*      */       
/*  457 */       for (int y = 0; y < rectHeight; y++) {
/*  458 */         int bOffset = bitOffset;
/*  459 */         for (int x = 0; x < rectWidth; x += 8, bOffset += 8) {
/*  460 */           int i = eltOffset + bOffset / 16;
/*  461 */           int mod = bOffset % 16;
/*  462 */           int left = data[i] & 0xFFFF;
/*  463 */           if (mod <= 8) {
/*  464 */             binaryDataArray[b++] = (byte)(left >>> 8 - mod);
/*      */           } else {
/*  466 */             int delta = mod - 8;
/*  467 */             int right = data[i + 1] & 0xFFFF;
/*  468 */             binaryDataArray[b++] = (byte)(left << delta | right >>> 16 - delta);
/*      */           } 
/*      */         } 
/*      */ 
/*      */         
/*  473 */         eltOffset += lineStride;
/*      */       } 
/*  475 */     } else if (dataBuffer instanceof DataBufferInt) {
/*  476 */       int[] data = ((DataBufferInt)dataBuffer).getData();
/*      */       
/*  478 */       for (int y = 0; y < rectHeight; y++) {
/*  479 */         int bOffset = bitOffset;
/*  480 */         for (int x = 0; x < rectWidth; x += 8, bOffset += 8) {
/*  481 */           int i = eltOffset + bOffset / 32;
/*  482 */           int mod = bOffset % 32;
/*  483 */           int left = data[i];
/*  484 */           if (mod <= 24) {
/*  485 */             binaryDataArray[b++] = (byte)(left >>> 24 - mod);
/*      */           } else {
/*      */             
/*  488 */             int delta = mod - 24;
/*  489 */             int right = data[i + 1];
/*  490 */             binaryDataArray[b++] = (byte)(left << delta | right >>> 32 - delta);
/*      */           } 
/*      */         } 
/*      */ 
/*      */         
/*  495 */         eltOffset += lineStride;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  500 */     return binaryDataArray;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] getUnpackedBinaryData(Raster raster, Rectangle rect) {
/*  513 */     SampleModel sm = raster.getSampleModel();
/*  514 */     if (!isBinary(sm)) {
/*  515 */       throw new IllegalArgumentException(I18N.getString("ImageUtil0"));
/*      */     }
/*      */     
/*  518 */     int rectX = rect.x;
/*  519 */     int rectY = rect.y;
/*  520 */     int rectWidth = rect.width;
/*  521 */     int rectHeight = rect.height;
/*      */     
/*  523 */     DataBuffer dataBuffer = raster.getDataBuffer();
/*      */     
/*  525 */     int dx = rectX - raster.getSampleModelTranslateX();
/*  526 */     int dy = rectY - raster.getSampleModelTranslateY();
/*      */     
/*  528 */     MultiPixelPackedSampleModel mpp = (MultiPixelPackedSampleModel)sm;
/*  529 */     int lineStride = mpp.getScanlineStride();
/*  530 */     int eltOffset = dataBuffer.getOffset() + mpp.getOffset(dx, dy);
/*  531 */     int bitOffset = mpp.getBitOffset(dx);
/*      */     
/*  533 */     byte[] bdata = new byte[rectWidth * rectHeight];
/*  534 */     int maxY = rectY + rectHeight;
/*  535 */     int maxX = rectX + rectWidth;
/*  536 */     int k = 0;
/*      */     
/*  538 */     if (dataBuffer instanceof DataBufferByte) {
/*  539 */       byte[] data = ((DataBufferByte)dataBuffer).getData();
/*  540 */       for (int y = rectY; y < maxY; y++) {
/*  541 */         int bOffset = eltOffset * 8 + bitOffset;
/*  542 */         for (int x = rectX; x < maxX; x++) {
/*  543 */           byte b = data[bOffset / 8];
/*  544 */           bdata[k++] = (byte)(b >>> (7 - bOffset & 0x7) & 0x1);
/*      */           
/*  546 */           bOffset++;
/*      */         } 
/*  548 */         eltOffset += lineStride;
/*      */       } 
/*  550 */     } else if (dataBuffer instanceof DataBufferShort || dataBuffer instanceof DataBufferUShort) {
/*      */       
/*  552 */       short[] data = (dataBuffer instanceof DataBufferShort) ? ((DataBufferShort)dataBuffer).getData() : ((DataBufferUShort)dataBuffer).getData();
/*      */ 
/*      */       
/*  555 */       for (int y = rectY; y < maxY; y++) {
/*  556 */         int bOffset = eltOffset * 16 + bitOffset;
/*  557 */         for (int x = rectX; x < maxX; x++) {
/*  558 */           short s = data[bOffset / 16];
/*  559 */           bdata[k++] = (byte)(s >>> 15 - bOffset % 16 & 0x1);
/*      */ 
/*      */           
/*  562 */           bOffset++;
/*      */         } 
/*  564 */         eltOffset += lineStride;
/*      */       } 
/*  566 */     } else if (dataBuffer instanceof DataBufferInt) {
/*  567 */       int[] data = ((DataBufferInt)dataBuffer).getData();
/*  568 */       for (int y = rectY; y < maxY; y++) {
/*  569 */         int bOffset = eltOffset * 32 + bitOffset;
/*  570 */         for (int x = rectX; x < maxX; x++) {
/*  571 */           int i = data[bOffset / 32];
/*  572 */           bdata[k++] = (byte)(i >>> 31 - bOffset % 32 & 0x1);
/*      */ 
/*      */           
/*  575 */           bOffset++;
/*      */         } 
/*  577 */         eltOffset += lineStride;
/*      */       } 
/*      */     } 
/*      */     
/*  581 */     return bdata;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setPackedBinaryData(byte[] binaryDataArray, WritableRaster raster, Rectangle rect) {
/*  596 */     SampleModel sm = raster.getSampleModel();
/*  597 */     if (!isBinary(sm)) {
/*  598 */       throw new IllegalArgumentException(I18N.getString("ImageUtil0"));
/*      */     }
/*      */     
/*  601 */     int rectX = rect.x;
/*  602 */     int rectY = rect.y;
/*  603 */     int rectWidth = rect.width;
/*  604 */     int rectHeight = rect.height;
/*      */     
/*  606 */     DataBuffer dataBuffer = raster.getDataBuffer();
/*      */     
/*  608 */     int dx = rectX - raster.getSampleModelTranslateX();
/*  609 */     int dy = rectY - raster.getSampleModelTranslateY();
/*      */     
/*  611 */     MultiPixelPackedSampleModel mpp = (MultiPixelPackedSampleModel)sm;
/*  612 */     int lineStride = mpp.getScanlineStride();
/*  613 */     int eltOffset = dataBuffer.getOffset() + mpp.getOffset(dx, dy);
/*  614 */     int bitOffset = mpp.getBitOffset(dx);
/*      */     
/*  616 */     int b = 0;
/*      */     
/*  618 */     if (bitOffset == 0) {
/*  619 */       if (dataBuffer instanceof DataBufferByte) {
/*  620 */         byte[] data = ((DataBufferByte)dataBuffer).getData();
/*  621 */         if (data == binaryDataArray) {
/*      */           return;
/*      */         }
/*      */         
/*  625 */         int stride = (rectWidth + 7) / 8;
/*  626 */         int offset = 0;
/*  627 */         for (int y = 0; y < rectHeight; y++) {
/*  628 */           System.arraycopy(binaryDataArray, offset, data, eltOffset, stride);
/*      */ 
/*      */           
/*  631 */           offset += stride;
/*  632 */           eltOffset += lineStride;
/*      */         } 
/*  634 */       } else if (dataBuffer instanceof DataBufferShort || dataBuffer instanceof DataBufferUShort) {
/*      */         
/*  636 */         short[] data = (dataBuffer instanceof DataBufferShort) ? ((DataBufferShort)dataBuffer).getData() : ((DataBufferUShort)dataBuffer).getData();
/*      */ 
/*      */ 
/*      */         
/*  640 */         for (int y = 0; y < rectHeight; y++) {
/*  641 */           int xRemaining = rectWidth;
/*  642 */           int i = eltOffset;
/*  643 */           while (xRemaining > 8) {
/*  644 */             data[i++] = (short)((binaryDataArray[b++] & 0xFF) << 8 | binaryDataArray[b++] & 0xFF);
/*      */ 
/*      */             
/*  647 */             xRemaining -= 16;
/*      */           } 
/*  649 */           if (xRemaining > 0) {
/*  650 */             data[i++] = (short)((binaryDataArray[b++] & 0xFF) << 8);
/*      */           }
/*      */           
/*  653 */           eltOffset += lineStride;
/*      */         } 
/*  655 */       } else if (dataBuffer instanceof DataBufferInt) {
/*  656 */         int[] data = ((DataBufferInt)dataBuffer).getData();
/*      */         
/*  658 */         for (int y = 0; y < rectHeight; y++) {
/*  659 */           int xRemaining = rectWidth;
/*  660 */           int i = eltOffset;
/*  661 */           while (xRemaining > 24) {
/*  662 */             data[i++] = (binaryDataArray[b++] & 0xFF) << 24 | (binaryDataArray[b++] & 0xFF) << 16 | (binaryDataArray[b++] & 0xFF) << 8 | binaryDataArray[b++] & 0xFF;
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  667 */             xRemaining -= 32;
/*      */           } 
/*  669 */           int shift = 24;
/*  670 */           while (xRemaining > 0) {
/*  671 */             data[i] = data[i] | (binaryDataArray[b++] & 0xFF) << shift;
/*      */             
/*  673 */             shift -= 8;
/*  674 */             xRemaining -= 8;
/*      */           } 
/*  676 */           eltOffset += lineStride;
/*      */         } 
/*      */       } 
/*      */     } else {
/*  680 */       int stride = (rectWidth + 7) / 8;
/*  681 */       int offset = 0;
/*  682 */       if (dataBuffer instanceof DataBufferByte) {
/*  683 */         byte[] data = ((DataBufferByte)dataBuffer).getData();
/*      */         
/*  685 */         if ((bitOffset & 0x7) == 0) {
/*  686 */           for (int y = 0; y < rectHeight; y++) {
/*  687 */             System.arraycopy(binaryDataArray, offset, data, eltOffset, stride);
/*      */ 
/*      */             
/*  690 */             offset += stride;
/*  691 */             eltOffset += lineStride;
/*      */           } 
/*      */         } else {
/*  694 */           int rightShift = bitOffset & 0x7;
/*  695 */           int leftShift = 8 - rightShift;
/*  696 */           int leftShift8 = 8 + leftShift;
/*  697 */           int mask = (byte)(255 << leftShift);
/*  698 */           int mask1 = (byte)(mask ^ 0xFFFFFFFF);
/*      */           
/*  700 */           for (int y = 0; y < rectHeight; y++) {
/*  701 */             int i = eltOffset;
/*  702 */             int xRemaining = rectWidth;
/*  703 */             while (xRemaining > 0) {
/*  704 */               byte datum = binaryDataArray[b++];
/*      */               
/*  706 */               if (xRemaining > leftShift8) {
/*      */ 
/*      */                 
/*  709 */                 data[i] = (byte)(data[i] & mask | (datum & 0xFF) >>> rightShift);
/*      */                 
/*  711 */                 data[++i] = (byte)((datum & 0xFF) << leftShift);
/*  712 */               } else if (xRemaining > leftShift) {
/*      */ 
/*      */ 
/*      */                 
/*  716 */                 data[i] = (byte)(data[i] & mask | (datum & 0xFF) >>> rightShift);
/*      */                 
/*  718 */                 i++;
/*  719 */                 data[i] = (byte)(data[i] & mask1 | (datum & 0xFF) << leftShift);
/*      */               
/*      */               }
/*      */               else {
/*      */                 
/*  724 */                 int remainMask = (1 << leftShift - xRemaining) - 1;
/*  725 */                 data[i] = (byte)(data[i] & (mask | remainMask) | (datum & 0xFF) >>> rightShift & (remainMask ^ 0xFFFFFFFF));
/*      */               } 
/*      */ 
/*      */               
/*  729 */               xRemaining -= 8;
/*      */             } 
/*  731 */             eltOffset += lineStride;
/*      */           } 
/*      */         } 
/*  734 */       } else if (dataBuffer instanceof DataBufferShort || dataBuffer instanceof DataBufferUShort) {
/*      */         
/*  736 */         short[] data = (dataBuffer instanceof DataBufferShort) ? ((DataBufferShort)dataBuffer).getData() : ((DataBufferUShort)dataBuffer).getData();
/*      */ 
/*      */ 
/*      */         
/*  740 */         int rightShift = bitOffset & 0x7;
/*  741 */         int leftShift = 8 - rightShift;
/*  742 */         int leftShift16 = 16 + leftShift;
/*  743 */         int mask = (short)(255 << leftShift ^ 0xFFFFFFFF);
/*  744 */         int mask1 = (short)(65535 << leftShift);
/*  745 */         int mask2 = (short)(mask1 ^ 0xFFFFFFFF);
/*      */         
/*  747 */         for (int y = 0; y < rectHeight; y++) {
/*  748 */           int bOffset = bitOffset;
/*  749 */           int xRemaining = rectWidth;
/*  750 */           for (int x = 0; x < rectWidth; 
/*  751 */             x += 8, bOffset += 8, xRemaining -= 8) {
/*  752 */             int i = eltOffset + (bOffset >> 4);
/*  753 */             int mod = bOffset & 0xF;
/*  754 */             int datum = binaryDataArray[b++] & 0xFF;
/*  755 */             if (mod <= 8) {
/*      */               
/*  757 */               if (xRemaining < 8)
/*      */               {
/*  759 */                 datum &= 255 << 8 - xRemaining;
/*      */               }
/*  761 */               data[i] = (short)(data[i] & mask | datum << leftShift);
/*  762 */             } else if (xRemaining > leftShift16) {
/*      */               
/*  764 */               data[i] = (short)(data[i] & mask1 | datum >>> rightShift & 0xFFFF);
/*  765 */               data[++i] = (short)(datum << leftShift & 0xFFFF);
/*      */             }
/*  767 */             else if (xRemaining > leftShift) {
/*      */ 
/*      */               
/*  770 */               data[i] = (short)(data[i] & mask1 | datum >>> rightShift & 0xFFFF);
/*  771 */               i++;
/*  772 */               data[i] = (short)(data[i] & mask2 | datum << leftShift & 0xFFFF);
/*      */             
/*      */             }
/*      */             else {
/*      */               
/*  777 */               int remainMask = (1 << leftShift - xRemaining) - 1;
/*  778 */               data[i] = (short)(data[i] & (mask1 | remainMask) | datum >>> rightShift & 0xFFFF & (remainMask ^ 0xFFFFFFFF));
/*      */             } 
/*      */           } 
/*      */           
/*  782 */           eltOffset += lineStride;
/*      */         } 
/*  784 */       } else if (dataBuffer instanceof DataBufferInt) {
/*  785 */         int[] data = ((DataBufferInt)dataBuffer).getData();
/*  786 */         int rightShift = bitOffset & 0x7;
/*  787 */         int leftShift = 8 - rightShift;
/*  788 */         int leftShift32 = 32 + leftShift;
/*  789 */         int mask = -1 << leftShift;
/*  790 */         int mask1 = mask ^ 0xFFFFFFFF;
/*      */         
/*  792 */         for (int y = 0; y < rectHeight; y++) {
/*  793 */           int bOffset = bitOffset;
/*  794 */           int xRemaining = rectWidth;
/*  795 */           for (int x = 0; x < rectWidth; 
/*  796 */             x += 8, bOffset += 8, xRemaining -= 8) {
/*  797 */             int i = eltOffset + (bOffset >> 5);
/*  798 */             int mod = bOffset & 0x1F;
/*  799 */             int datum = binaryDataArray[b++] & 0xFF;
/*  800 */             if (mod <= 24) {
/*      */               
/*  802 */               int shift = 24 - mod;
/*  803 */               if (xRemaining < 8)
/*      */               {
/*  805 */                 datum &= 255 << 8 - xRemaining;
/*      */               }
/*  807 */               data[i] = data[i] & (255 << shift ^ 0xFFFFFFFF) | datum << shift;
/*  808 */             } else if (xRemaining > leftShift32) {
/*      */               
/*  810 */               data[i] = data[i] & mask | datum >>> rightShift;
/*  811 */               data[++i] = datum << leftShift;
/*  812 */             } else if (xRemaining > leftShift) {
/*      */ 
/*      */               
/*  815 */               data[i] = data[i] & mask | datum >>> rightShift;
/*  816 */               i++;
/*  817 */               data[i] = data[i] & mask1 | datum << leftShift;
/*      */             } else {
/*      */               
/*  820 */               int remainMask = (1 << leftShift - xRemaining) - 1;
/*  821 */               data[i] = data[i] & (mask | remainMask) | datum >>> rightShift & (remainMask ^ 0xFFFFFFFF);
/*      */             } 
/*      */           } 
/*      */           
/*  825 */           eltOffset += lineStride;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setUnpackedBinaryData(byte[] bdata, WritableRaster raster, Rectangle rect) {
/*  846 */     SampleModel sm = raster.getSampleModel();
/*  847 */     if (!isBinary(sm)) {
/*  848 */       throw new IllegalArgumentException(I18N.getString("ImageUtil0"));
/*      */     }
/*      */     
/*  851 */     int rectX = rect.x;
/*  852 */     int rectY = rect.y;
/*  853 */     int rectWidth = rect.width;
/*  854 */     int rectHeight = rect.height;
/*      */     
/*  856 */     DataBuffer dataBuffer = raster.getDataBuffer();
/*      */     
/*  858 */     int dx = rectX - raster.getSampleModelTranslateX();
/*  859 */     int dy = rectY - raster.getSampleModelTranslateY();
/*      */     
/*  861 */     MultiPixelPackedSampleModel mpp = (MultiPixelPackedSampleModel)sm;
/*  862 */     int lineStride = mpp.getScanlineStride();
/*  863 */     int eltOffset = dataBuffer.getOffset() + mpp.getOffset(dx, dy);
/*  864 */     int bitOffset = mpp.getBitOffset(dx);
/*      */     
/*  866 */     int k = 0;
/*      */     
/*  868 */     if (dataBuffer instanceof DataBufferByte) {
/*  869 */       byte[] data = ((DataBufferByte)dataBuffer).getData();
/*  870 */       for (int y = 0; y < rectHeight; y++) {
/*  871 */         int bOffset = eltOffset * 8 + bitOffset;
/*  872 */         for (int x = 0; x < rectWidth; x++) {
/*  873 */           if (bdata[k++] != 0) {
/*  874 */             data[bOffset / 8] = (byte)(data[bOffset / 8] | (byte)(1 << (7 - bOffset & 0x7)));
/*      */           }
/*      */           
/*  877 */           bOffset++;
/*      */         } 
/*  879 */         eltOffset += lineStride;
/*      */       } 
/*  881 */     } else if (dataBuffer instanceof DataBufferShort || dataBuffer instanceof DataBufferUShort) {
/*      */       
/*  883 */       short[] data = (dataBuffer instanceof DataBufferShort) ? ((DataBufferShort)dataBuffer).getData() : ((DataBufferUShort)dataBuffer).getData();
/*      */ 
/*      */       
/*  886 */       for (int y = 0; y < rectHeight; y++) {
/*  887 */         int bOffset = eltOffset * 16 + bitOffset;
/*  888 */         for (int x = 0; x < rectWidth; x++) {
/*  889 */           if (bdata[k++] != 0) {
/*  890 */             data[bOffset / 16] = (short)(data[bOffset / 16] | (short)(1 << 15 - bOffset % 16));
/*      */           }
/*      */ 
/*      */           
/*  894 */           bOffset++;
/*      */         } 
/*  896 */         eltOffset += lineStride;
/*      */       } 
/*  898 */     } else if (dataBuffer instanceof DataBufferInt) {
/*  899 */       int[] data = ((DataBufferInt)dataBuffer).getData();
/*  900 */       for (int y = 0; y < rectHeight; y++) {
/*  901 */         int bOffset = eltOffset * 32 + bitOffset;
/*  902 */         for (int x = 0; x < rectWidth; x++) {
/*  903 */           if (bdata[k++] != 0) {
/*  904 */             data[bOffset / 32] = data[bOffset / 32] | 1 << 31 - bOffset % 32;
/*      */           }
/*      */ 
/*      */           
/*  908 */           bOffset++;
/*      */         } 
/*  910 */         eltOffset += lineStride;
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   public static boolean isBinary(SampleModel sm) {
/*  916 */     return (sm instanceof MultiPixelPackedSampleModel && ((MultiPixelPackedSampleModel)sm).getPixelBitStride() == 1 && sm.getNumBands() == 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ColorModel createColorModel(ColorSpace colorSpace, SampleModel sampleModel) {
/*  923 */     ColorModel colorModel = null;
/*      */     
/*  925 */     if (sampleModel == null) {
/*  926 */       throw new IllegalArgumentException(I18N.getString("ImageUtil1"));
/*      */     }
/*      */     
/*  929 */     int numBands = sampleModel.getNumBands();
/*  930 */     if (numBands < 1 || numBands > 4) {
/*  931 */       return null;
/*      */     }
/*      */     
/*  934 */     int dataType = sampleModel.getDataType();
/*  935 */     if (sampleModel instanceof ComponentSampleModel) {
/*  936 */       if (dataType < 0 || dataType > 5)
/*      */       {
/*      */         
/*  939 */         return null;
/*      */       }
/*      */       
/*  942 */       if (colorSpace == null) {
/*  943 */         colorSpace = (numBands <= 2) ? ColorSpace.getInstance(1003) : ColorSpace.getInstance(1000);
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  948 */       boolean useAlpha = (numBands == 2 || numBands == 4);
/*  949 */       int transparency = useAlpha ? 3 : 1;
/*      */ 
/*      */       
/*  952 */       boolean premultiplied = false;
/*      */       
/*  954 */       int dataTypeSize = DataBuffer.getDataTypeSize(dataType);
/*  955 */       int[] bits = new int[numBands];
/*  956 */       for (int i = 0; i < numBands; i++) {
/*  957 */         bits[i] = dataTypeSize;
/*      */       }
/*      */       
/*  960 */       colorModel = new ComponentColorModel(colorSpace, bits, useAlpha, premultiplied, transparency, dataType);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*  966 */     else if (sampleModel instanceof SinglePixelPackedSampleModel) {
/*  967 */       SinglePixelPackedSampleModel sppsm = (SinglePixelPackedSampleModel)sampleModel;
/*      */ 
/*      */       
/*  970 */       int[] bitMasks = sppsm.getBitMasks();
/*  971 */       int rmask = 0;
/*  972 */       int gmask = 0;
/*  973 */       int bmask = 0;
/*  974 */       int amask = 0;
/*      */       
/*  976 */       numBands = bitMasks.length;
/*  977 */       if (numBands <= 2) {
/*  978 */         rmask = gmask = bmask = bitMasks[0];
/*  979 */         if (numBands == 2) {
/*  980 */           amask = bitMasks[1];
/*      */         }
/*      */       } else {
/*  983 */         rmask = bitMasks[0];
/*  984 */         gmask = bitMasks[1];
/*  985 */         bmask = bitMasks[2];
/*  986 */         if (numBands == 4) {
/*  987 */           amask = bitMasks[3];
/*      */         }
/*      */       } 
/*      */       
/*  991 */       int[] sampleSize = sppsm.getSampleSize();
/*  992 */       int bits = 0;
/*  993 */       for (int i = 0; i < sampleSize.length; i++) {
/*  994 */         bits += sampleSize[i];
/*      */       }
/*      */       
/*  997 */       if (colorSpace == null) {
/*  998 */         colorSpace = ColorSpace.getInstance(1000);
/*      */       }
/* 1000 */       colorModel = new DirectColorModel(colorSpace, bits, rmask, gmask, bmask, amask, false, sampleModel.getDataType());
/*      */ 
/*      */ 
/*      */     
/*      */     }
/* 1005 */     else if (sampleModel instanceof MultiPixelPackedSampleModel) {
/* 1006 */       int bits = ((MultiPixelPackedSampleModel)sampleModel).getPixelBitStride();
/*      */       
/* 1008 */       int size = 1 << bits;
/* 1009 */       byte[] comp = new byte[size];
/*      */       
/* 1011 */       for (int i = 0; i < size; i++) {
/* 1012 */         comp[i] = (byte)(255 * i / (size - 1));
/*      */       }
/* 1014 */       colorModel = new IndexColorModel(bits, size, comp, comp, comp);
/*      */     } 
/*      */     
/* 1017 */     return colorModel;
/*      */   }
/*      */   
/*      */   public static int getElementSize(SampleModel sm) {
/* 1021 */     int elementSize = DataBuffer.getDataTypeSize(sm.getDataType());
/*      */     
/* 1023 */     if (sm instanceof MultiPixelPackedSampleModel) {
/* 1024 */       MultiPixelPackedSampleModel mppsm = (MultiPixelPackedSampleModel)sm;
/*      */       
/* 1026 */       return mppsm.getSampleSize(0) * mppsm.getNumBands();
/* 1027 */     }  if (sm instanceof ComponentSampleModel)
/* 1028 */       return sm.getNumBands() * elementSize; 
/* 1029 */     if (sm instanceof SinglePixelPackedSampleModel) {
/* 1030 */       return elementSize;
/*      */     }
/*      */     
/* 1033 */     return elementSize * sm.getNumBands();
/*      */   }
/*      */ 
/*      */   
/*      */   public static long getTileSize(SampleModel sm) {
/* 1038 */     int elementSize = DataBuffer.getDataTypeSize(sm.getDataType());
/*      */     
/* 1040 */     if (sm instanceof MultiPixelPackedSampleModel) {
/* 1041 */       MultiPixelPackedSampleModel mppsm = (MultiPixelPackedSampleModel)sm;
/*      */       
/* 1043 */       return ((mppsm.getScanlineStride() * mppsm.getHeight() + (mppsm.getDataBitOffset() + elementSize - 1) / elementSize) * (elementSize + 7) / 8);
/*      */     } 
/*      */     
/* 1046 */     if (sm instanceof ComponentSampleModel) {
/* 1047 */       ComponentSampleModel csm = (ComponentSampleModel)sm;
/* 1048 */       int[] bandOffsets = csm.getBandOffsets();
/* 1049 */       int maxBandOff = bandOffsets[0];
/* 1050 */       for (int i = 1; i < bandOffsets.length; i++) {
/* 1051 */         maxBandOff = Math.max(maxBandOff, bandOffsets[i]);
/*      */       }
/* 1053 */       long size = 0L;
/* 1054 */       int pixelStride = csm.getPixelStride();
/* 1055 */       int scanlineStride = csm.getScanlineStride();
/* 1056 */       if (maxBandOff >= 0)
/* 1057 */         size += (maxBandOff + 1); 
/* 1058 */       if (pixelStride > 0)
/* 1059 */         size += (pixelStride * (sm.getWidth() - 1)); 
/* 1060 */       if (scanlineStride > 0) {
/* 1061 */         size += (scanlineStride * (sm.getHeight() - 1));
/*      */       }
/* 1063 */       int[] bankIndices = csm.getBankIndices();
/* 1064 */       maxBandOff = bankIndices[0];
/* 1065 */       for (int j = 1; j < bankIndices.length; j++)
/* 1066 */         maxBandOff = Math.max(maxBandOff, bankIndices[j]); 
/* 1067 */       return size * (maxBandOff + 1) * ((elementSize + 7) / 8);
/* 1068 */     }  if (sm instanceof SinglePixelPackedSampleModel) {
/* 1069 */       SinglePixelPackedSampleModel sppsm = (SinglePixelPackedSampleModel)sm;
/*      */       
/* 1071 */       long size = (sppsm.getScanlineStride() * (sppsm.getHeight() - 1) + sppsm.getWidth());
/*      */       
/* 1073 */       return size * ((elementSize + 7) / 8);
/*      */     } 
/*      */     
/* 1076 */     return 0L;
/*      */   }
/*      */   
/*      */   public static long getBandSize(SampleModel sm) {
/* 1080 */     int elementSize = DataBuffer.getDataTypeSize(sm.getDataType());
/*      */     
/* 1082 */     if (sm instanceof ComponentSampleModel) {
/* 1083 */       ComponentSampleModel csm = (ComponentSampleModel)sm;
/* 1084 */       int pixelStride = csm.getPixelStride();
/* 1085 */       int scanlineStride = csm.getScanlineStride();
/* 1086 */       long size = Math.min(pixelStride, scanlineStride);
/*      */       
/* 1088 */       if (pixelStride > 0)
/* 1089 */         size += (pixelStride * (sm.getWidth() - 1)); 
/* 1090 */       if (scanlineStride > 0)
/* 1091 */         size += (scanlineStride * (sm.getHeight() - 1)); 
/* 1092 */       return size * ((elementSize + 7) / 8);
/*      */     } 
/* 1094 */     return getTileSize(sm);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isGrayscaleMapping(IndexColorModel icm) {
/* 1110 */     if (icm == null) {
/* 1111 */       throw new IllegalArgumentException("icm == null!");
/*      */     }
/*      */ 
/*      */     
/* 1115 */     int mapSize = icm.getMapSize();
/*      */     
/* 1117 */     byte[] r = new byte[mapSize];
/* 1118 */     byte[] g = new byte[mapSize];
/* 1119 */     byte[] b = new byte[mapSize];
/*      */     
/* 1121 */     icm.getReds(r);
/* 1122 */     icm.getGreens(g);
/* 1123 */     icm.getBlues(b);
/*      */     
/* 1125 */     boolean isGrayToColor = true;
/*      */     
/*      */     int i;
/* 1128 */     for (i = 0; i < mapSize; i++) {
/* 1129 */       byte temp = (byte)(i * 255 / (mapSize - 1));
/*      */       
/* 1131 */       if (r[i] != temp || g[i] != temp || b[i] != temp) {
/* 1132 */         isGrayToColor = false;
/*      */         
/*      */         break;
/*      */       } 
/*      */     } 
/* 1137 */     if (!isGrayToColor) {
/* 1138 */       isGrayToColor = true;
/*      */       
/*      */       int j;
/* 1141 */       for (i = 0, j = mapSize - 1; i < mapSize; i++, j--) {
/* 1142 */         byte temp = (byte)(j * 255 / (mapSize - 1));
/*      */         
/* 1144 */         if (r[i] != temp || g[i] != temp || b[i] != temp) {
/* 1145 */           isGrayToColor = false;
/*      */           
/*      */           break;
/*      */         } 
/*      */       } 
/*      */     } 
/* 1151 */     return isGrayToColor;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isIndicesForGrayscale(byte[] r, byte[] g, byte[] b) {
/* 1164 */     if (r.length != g.length || r.length != b.length) {
/* 1165 */       return false;
/*      */     }
/* 1167 */     int size = r.length;
/*      */     
/* 1169 */     if (size != 256) {
/* 1170 */       return false;
/*      */     }
/* 1172 */     for (int i = 0; i < size; i++) {
/* 1173 */       byte temp = (byte)i;
/*      */       
/* 1175 */       if (r[i] != temp || g[i] != temp || b[i] != temp) {
/* 1176 */         return false;
/*      */       }
/*      */     } 
/* 1179 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public static String convertObjectToString(Object obj) {
/* 1184 */     if (obj == null) {
/* 1185 */       return "";
/*      */     }
/* 1187 */     String s = "";
/* 1188 */     if (obj instanceof byte[]) {
/* 1189 */       byte[] bArray = (byte[])obj;
/* 1190 */       for (int i = 0; i < bArray.length; i++)
/* 1191 */         s = s + bArray[i] + " "; 
/* 1192 */       return s;
/*      */     } 
/*      */     
/* 1195 */     if (obj instanceof int[]) {
/* 1196 */       int[] iArray = (int[])obj;
/* 1197 */       for (int i = 0; i < iArray.length; i++)
/* 1198 */         s = s + iArray[i] + " "; 
/* 1199 */       return s;
/*      */     } 
/*      */     
/* 1202 */     if (obj instanceof short[]) {
/* 1203 */       short[] sArray = (short[])obj;
/* 1204 */       for (int i = 0; i < sArray.length; i++)
/* 1205 */         s = s + sArray[i] + " "; 
/* 1206 */       return s;
/*      */     } 
/*      */     
/* 1209 */     return obj.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final void canEncodeImage(ImageWriter writer, ImageTypeSpecifier type) throws IIOException {
/* 1223 */     ImageWriterSpi spi = writer.getOriginatingProvider();
/*      */     
/* 1225 */     if (type != null && spi != null && !spi.canEncodeImage(type)) {
/* 1226 */       throw new IIOException(I18N.getString("ImageUtil2") + " " + writer.getClass().getName());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final void canEncodeImage(ImageWriter writer, ColorModel colorModel, SampleModel sampleModel) throws IIOException {
/* 1243 */     ImageTypeSpecifier type = null;
/* 1244 */     if (colorModel != null && sampleModel != null)
/* 1245 */       type = new ImageTypeSpecifier(colorModel, sampleModel); 
/* 1246 */     canEncodeImage(writer, type);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final boolean imageIsContiguous(RenderedImage image) {
/*      */     SampleModel sm;
/* 1254 */     if (image instanceof BufferedImage) {
/* 1255 */       WritableRaster ras = ((BufferedImage)image).getRaster();
/* 1256 */       sm = ras.getSampleModel();
/*      */     } else {
/* 1258 */       sm = image.getSampleModel();
/*      */     } 
/*      */     
/* 1261 */     if (sm instanceof ComponentSampleModel) {
/*      */ 
/*      */       
/* 1264 */       ComponentSampleModel csm = (ComponentSampleModel)sm;
/*      */       
/* 1266 */       if (csm.getPixelStride() != csm.getNumBands()) {
/* 1267 */         return false;
/*      */       }
/*      */       
/* 1270 */       int[] bandOffsets = csm.getBandOffsets();
/* 1271 */       for (int i = 0; i < bandOffsets.length; i++) {
/* 1272 */         if (bandOffsets[i] != i) {
/* 1273 */           return false;
/*      */         }
/*      */       } 
/*      */       
/* 1277 */       int[] bankIndices = csm.getBankIndices();
/* 1278 */       for (int j = 0; j < bandOffsets.length; j++) {
/* 1279 */         if (bankIndices[j] != 0) {
/* 1280 */           return false;
/*      */         }
/*      */       } 
/*      */       
/* 1284 */       return true;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1290 */     return isBinary(sm);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ImageTypeSpecifier getDestinationType(ImageReadParam param, Iterator<ImageTypeSpecifier> imageTypes) throws IIOException {
/* 1301 */     if (imageTypes == null || !imageTypes.hasNext()) {
/* 1302 */       throw new IllegalArgumentException("imageTypes null or empty!");
/*      */     }
/*      */     
/* 1305 */     ImageTypeSpecifier imageType = null;
/*      */ 
/*      */     
/* 1308 */     if (param != null) {
/* 1309 */       imageType = param.getDestinationType();
/*      */     }
/*      */ 
/*      */     
/* 1313 */     if (imageType == null) {
/* 1314 */       Object o = imageTypes.next();
/* 1315 */       if (!(o instanceof ImageTypeSpecifier)) {
/* 1316 */         throw new IllegalArgumentException("Non-ImageTypeSpecifier retrieved from imageTypes!");
/*      */       }
/*      */       
/* 1319 */       imageType = (ImageTypeSpecifier)o;
/*      */     } else {
/* 1321 */       boolean foundIt = false;
/* 1322 */       while (imageTypes.hasNext()) {
/* 1323 */         ImageTypeSpecifier type = imageTypes.next();
/*      */         
/* 1325 */         if (type.equals(imageType)) {
/* 1326 */           foundIt = true;
/*      */           
/*      */           break;
/*      */         } 
/*      */       } 
/* 1331 */       if (!foundIt) {
/* 1332 */         throw new IIOException("Destination type from ImageReadParam does not match!");
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 1337 */     return imageType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isNonStandardICCColorSpace(ColorSpace cs) {
/* 1349 */     boolean retval = false;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 1355 */       retval = (cs instanceof java.awt.color.ICC_ColorSpace && !cs.isCS_sRGB() && !cs.equals(ColorSpace.getInstance(1004)) && !cs.equals(ColorSpace.getInstance(1003)) && !cs.equals(ColorSpace.getInstance(1001)) && !cs.equals(ColorSpace.getInstance(1002)));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/* 1362 */     catch (IllegalArgumentException e) {}
/*      */ 
/*      */ 
/*      */     
/* 1366 */     return retval;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List getJDKImageReaderWriterSPI(ServiceRegistry registry, String formatName, boolean isReader) {
/*      */     Class<ImageWriterSpi> spiClass;
/*      */     String descPart;
/* 1375 */     IIORegistry iioRegistry = (IIORegistry)registry;
/*      */ 
/*      */ 
/*      */     
/* 1379 */     if (isReader) {
/* 1380 */       Class<ImageReaderSpi> clazz = ImageReaderSpi.class;
/* 1381 */       descPart = " image reader";
/*      */     } else {
/* 1383 */       spiClass = ImageWriterSpi.class;
/* 1384 */       descPart = " image writer";
/*      */     } 
/*      */     
/* 1387 */     Iterator<ImageWriterSpi> iter = iioRegistry.getServiceProviders(spiClass, true);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1392 */     String desc = "standard " + formatName + descPart;
/* 1393 */     String jiioPath = "com.sun.media.imageioimpl";
/* 1394 */     Locale locale = Locale.getDefault();
/* 1395 */     ArrayList<ImageReaderWriterSpi> list = new ArrayList();
/* 1396 */     while (iter.hasNext()) {
/* 1397 */       ImageReaderWriterSpi provider = iter.next();
/*      */ 
/*      */       
/* 1400 */       if (provider.getVendorName().startsWith("Sun Microsystems") && desc.equalsIgnoreCase(provider.getDescription(locale)) && !provider.getPluginClassName().startsWith(jiioPath)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1406 */         String[] formatNames = provider.getFormatNames();
/* 1407 */         for (int i = 0; i < formatNames.length; i++) {
/* 1408 */           if (formatNames[i].equalsIgnoreCase(formatName)) {
/*      */             
/* 1410 */             list.add(provider);
/*      */             
/*      */             break;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/* 1417 */     return list;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void processOnRegistration(ServiceRegistry registry, Class<ImageReaderWriterSpi> category, String formatName, ImageReaderWriterSpi spi, int deregisterJvmVersion, int priorityJvmVersion) {
/* 1428 */     String jvmVendor = System.getProperty("java.vendor");
/* 1429 */     String jvmVersionString = System.getProperty("java.specification.version");
/*      */     
/* 1431 */     int verIndex = jvmVersionString.indexOf("1.");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1440 */     jvmVersionString = jvmVersionString.substring(verIndex + 2);
/*      */     
/* 1442 */     int jvmVersion = Integer.parseInt(jvmVersionString);
/*      */     
/* 1444 */     if (jvmVendor.equals("Sun Microsystems Inc.")) {
/*      */       List<ImageReaderWriterSpi> list;
/*      */       
/* 1447 */       if (spi instanceof ImageReaderSpi) {
/* 1448 */         list = getJDKImageReaderWriterSPI(registry, formatName, true);
/*      */       } else {
/* 1450 */         list = getJDKImageReaderWriterSPI(registry, formatName, false);
/*      */       } 
/* 1452 */       if (jvmVersion >= deregisterJvmVersion && list.size() != 0) {
/*      */         
/* 1454 */         registry.deregisterServiceProvider(spi, category);
/*      */       } else {
/* 1456 */         for (int i = 0; i < list.size(); i++) {
/* 1457 */           if (jvmVersion >= priorityJvmVersion) {
/*      */             
/* 1459 */             registry.setOrdering(category, list.get(i), spi);
/*      */           
/*      */           }
/*      */           else {
/*      */             
/* 1464 */             registry.setOrdering(category, spi, list.get(i));
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static int readMultiByteInteger(ImageInputStream iis) throws IOException {
/* 1474 */     int value = iis.readByte();
/* 1475 */     int result = value & 0x7F;
/* 1476 */     while ((value & 0x80) == 128) {
/* 1477 */       result <<= 7;
/* 1478 */       value = iis.readByte();
/* 1479 */       result |= value & 0x7F;
/*      */     } 
/* 1481 */     return result;
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/common/ImageUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */