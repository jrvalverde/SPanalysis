/*     */ package com.sun.media.imageioimpl.plugins.pnm;
/*     */ 
/*     */ import com.sun.media.imageioimpl.common.PackageUtil;
/*     */ import java.util.Locale;
/*     */ import javax.imageio.IIOException;
/*     */ import javax.imageio.ImageTypeSpecifier;
/*     */ import javax.imageio.ImageWriter;
/*     */ import javax.imageio.spi.ImageWriterSpi;
/*     */ import javax.imageio.spi.ServiceRegistry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PNMImageWriterSpi
/*     */   extends ImageWriterSpi
/*     */ {
/*  97 */   private static String[] readerSpiNames = new String[] { "com.sun.media.imageioimpl.plugins.pnm.PNMImageReaderSpi" };
/*     */   
/*  99 */   private static String[] formatNames = new String[] { "pnm", "PNM" };
/* 100 */   private static String[] entensions = new String[] { "pbm", "pgm", "ppm" };
/* 101 */   private static String[] mimeType = new String[] { "image/x-portable-anymap", "image/x-portable-bitmap", "image/x-portable-graymap", "image/x-portable-pixmap" };
/*     */ 
/*     */   
/*     */   private boolean registered = false;
/*     */ 
/*     */ 
/*     */   
/*     */   public PNMImageWriterSpi() {
/* 109 */     super(PackageUtil.getVendor(), PackageUtil.getVersion(), formatNames, entensions, mimeType, "com.sun.media.imageioimpl.plugins.pnm.PNMImageWriter", STANDARD_OUTPUT_TYPE, readerSpiNames, true, null, null, null, null, true, null, null, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDescription(Locale locale) {
/* 124 */     String desc = PackageUtil.getSpecificationTitle() + " PNM Image Writer";
/*     */     
/* 126 */     return desc;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onRegistration(ServiceRegistry registry, Class category) {
/* 131 */     if (this.registered) {
/*     */       return;
/*     */     }
/*     */     
/* 135 */     this.registered = true;
/*     */   }
/*     */   
/*     */   public boolean canEncodeImage(ImageTypeSpecifier type) {
/* 139 */     int dataType = type.getSampleModel().getDataType();
/* 140 */     if (dataType < 0 || dataType > 3)
/*     */     {
/* 142 */       return false;
/*     */     }
/* 144 */     int numBands = type.getSampleModel().getNumBands();
/* 145 */     if (numBands != 1 && numBands != 3) {
/* 146 */       return false;
/*     */     }
/* 148 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public ImageWriter createWriterInstance(Object extension) throws IIOException {
/* 153 */     return new PNMImageWriter(this);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/pnm/PNMImageWriterSpi.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */