/*      */ package com.sun.media.imageioimpl.plugins.raw;
/*      */ 
/*      */ import com.sun.media.imageio.stream.RawImageInputStream;
/*      */ import com.sun.media.imageioimpl.common.ImageUtil;
/*      */ import com.sun.media.imageioimpl.common.SimpleRenderedImage;
/*      */ import java.awt.Dimension;
/*      */ import java.awt.Point;
/*      */ import java.awt.Rectangle;
/*      */ import java.awt.image.BufferedImage;
/*      */ import java.awt.image.ComponentSampleModel;
/*      */ import java.awt.image.DataBuffer;
/*      */ import java.awt.image.DataBufferByte;
/*      */ import java.awt.image.DataBufferDouble;
/*      */ import java.awt.image.DataBufferFloat;
/*      */ import java.awt.image.DataBufferInt;
/*      */ import java.awt.image.DataBufferShort;
/*      */ import java.awt.image.DataBufferUShort;
/*      */ import java.awt.image.MultiPixelPackedSampleModel;
/*      */ import java.awt.image.Raster;
/*      */ import java.awt.image.SampleModel;
/*      */ import java.awt.image.SinglePixelPackedSampleModel;
/*      */ import java.awt.image.WritableRaster;
/*      */ import java.io.IOException;
/*      */ import javax.imageio.ImageReadParam;
/*      */ import javax.imageio.ImageTypeSpecifier;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class RawRenderedImage
/*      */   extends SimpleRenderedImage
/*      */ {
/*      */   private SampleModel originalSampleModel;
/*      */   private Raster currentTile;
/*      */   private Point currentTileGrid;
/*  131 */   private RawImageInputStream iis = null;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private RawImageReader reader;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  141 */   private ImageReadParam param = null;
/*      */   
/*      */   private int imageIndex;
/*      */   
/*      */   private Rectangle destinationRegion;
/*      */   private Rectangle originalRegion;
/*      */   private Point sourceOrigin;
/*      */   private Dimension originalDimension;
/*      */   private int maxXTile;
/*      */   private int maxYTile;
/*      */   private int scaleX;
/*      */   private int scaleY;
/*      */   private int xOffset;
/*      */   private int yOffset;
/*  155 */   private int[] destinationBands = null;
/*  156 */   private int[] sourceBands = null;
/*      */ 
/*      */   
/*      */   private int nComp;
/*      */ 
/*      */   
/*      */   private boolean noTransform = true;
/*      */ 
/*      */   
/*      */   private WritableRaster rasForATile;
/*      */ 
/*      */   
/*      */   private BufferedImage destImage;
/*      */ 
/*      */   
/*      */   private long position;
/*      */ 
/*      */   
/*      */   private long tileDataSize;
/*      */ 
/*      */   
/*      */   private int originalNumXTiles;
/*      */ 
/*      */ 
/*      */   
/*      */   public RawRenderedImage(RawImageInputStream iis, RawImageReader reader, ImageReadParam param, int imageIndex) throws IOException {
/*  182 */     this.iis = iis;
/*  183 */     this.reader = reader;
/*  184 */     this.param = param;
/*  185 */     this.imageIndex = imageIndex;
/*  186 */     this.position = iis.getImageOffset(imageIndex);
/*  187 */     this.originalDimension = iis.getImageDimension(imageIndex);
/*      */     
/*  189 */     ImageTypeSpecifier type = iis.getImageType();
/*  190 */     this.sampleModel = this.originalSampleModel = type.getSampleModel();
/*  191 */     this.colorModel = type.getColorModel();
/*      */ 
/*      */     
/*  194 */     this.sourceBands = (param == null) ? null : param.getSourceBands();
/*      */     
/*  196 */     if (this.sourceBands == null) {
/*  197 */       this.nComp = this.originalSampleModel.getNumBands();
/*  198 */       this.sourceBands = new int[this.nComp];
/*  199 */       for (int i = 0; i < this.nComp; i++)
/*  200 */         this.sourceBands[i] = i; 
/*      */     } else {
/*  202 */       this.sampleModel = this.originalSampleModel.createSubsetSampleModel(this.sourceBands);
/*      */       
/*  204 */       this.colorModel = ImageUtil.createColorModel(null, this.sampleModel);
/*      */     } 
/*      */     
/*  207 */     this.nComp = this.sourceBands.length;
/*      */     
/*  209 */     this.destinationBands = (param == null) ? null : param.getDestinationBands();
/*  210 */     if (this.destinationBands == null) {
/*  211 */       this.destinationBands = new int[this.nComp];
/*  212 */       for (int i = 0; i < this.nComp; i++) {
/*  213 */         this.destinationBands[i] = i;
/*      */       }
/*      */     } 
/*  216 */     Dimension dim = iis.getImageDimension(imageIndex);
/*  217 */     this.width = dim.width;
/*  218 */     this.height = dim.height;
/*      */     
/*  220 */     Rectangle sourceRegion = new Rectangle(0, 0, this.width, this.height);
/*      */ 
/*      */     
/*  223 */     this.originalRegion = (Rectangle)sourceRegion.clone();
/*      */     
/*  225 */     this.destinationRegion = (Rectangle)sourceRegion.clone();
/*      */     
/*  227 */     if (param != null) {
/*  228 */       RawImageReader.computeRegionsWrapper(param, this.width, this.height, param.getDestination(), sourceRegion, this.destinationRegion);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  233 */       this.scaleX = param.getSourceXSubsampling();
/*  234 */       this.scaleY = param.getSourceYSubsampling();
/*  235 */       this.xOffset = param.getSubsamplingXOffset();
/*  236 */       this.yOffset = param.getSubsamplingYOffset();
/*      */     } 
/*      */     
/*  239 */     this.sourceOrigin = new Point(sourceRegion.x, sourceRegion.y);
/*  240 */     if (!this.destinationRegion.equals(sourceRegion)) {
/*  241 */       this.noTransform = false;
/*      */     }
/*  243 */     this.tileDataSize = ImageUtil.getTileSize(this.originalSampleModel);
/*      */     
/*  245 */     this.tileWidth = this.originalSampleModel.getWidth();
/*  246 */     this.tileHeight = this.originalSampleModel.getHeight();
/*  247 */     this.tileGridXOffset = this.destinationRegion.x;
/*  248 */     this.tileGridYOffset = this.destinationRegion.y;
/*  249 */     this.originalNumXTiles = getNumXTiles();
/*      */     
/*  251 */     this.width = this.destinationRegion.width;
/*  252 */     this.height = this.destinationRegion.height;
/*  253 */     this.minX = this.destinationRegion.x;
/*  254 */     this.minY = this.destinationRegion.y;
/*      */     
/*  256 */     this.sampleModel = this.sampleModel.createCompatibleSampleModel(this.tileWidth, this.tileHeight);
/*      */ 
/*      */     
/*  259 */     this.maxXTile = this.originalDimension.width / this.tileWidth;
/*  260 */     this.maxYTile = this.originalDimension.height / this.tileHeight;
/*      */   }
/*      */   
/*      */   public synchronized Raster getTile(int tileX, int tileY) {
/*  264 */     if (this.currentTile != null && this.currentTileGrid.x == tileX && this.currentTileGrid.y == tileY)
/*      */     {
/*      */       
/*  267 */       return this.currentTile;
/*      */     }
/*  269 */     if (tileX >= getNumXTiles() || tileY >= getNumYTiles()) {
/*  270 */       throw new IllegalArgumentException(I18N.getString("RawRenderedImage0"));
/*      */     }
/*      */     try {
/*  273 */       this.iis.seek(this.position + (tileY * this.originalNumXTiles + tileX) * this.tileDataSize);
/*      */       
/*  275 */       int x = tileXToX(tileX);
/*  276 */       int y = tileYToY(tileY);
/*  277 */       this.currentTile = Raster.createWritableRaster(this.sampleModel, new Point(x, y));
/*      */       
/*  279 */       if (this.noTransform) {
/*  280 */         byte[][] buf; int i; short[][] sbuf; int j; short[][] usbuf; int k; int[][] ibuf; int m; float[][] fbuf; int n; double[][] dbuf; int i1; switch (this.sampleModel.getDataType()) {
/*      */           case 0:
/*  282 */             buf = ((DataBufferByte)this.currentTile.getDataBuffer()).getBankData();
/*      */             
/*  284 */             for (i = 0; i < buf.length; i++) {
/*  285 */               this.iis.readFully(buf[i], 0, (buf[i]).length);
/*      */             }
/*      */             break;
/*      */           case 2:
/*  289 */             sbuf = ((DataBufferShort)this.currentTile.getDataBuffer()).getBankData();
/*      */             
/*  291 */             for (j = 0; j < sbuf.length; j++) {
/*  292 */               this.iis.readFully(sbuf[j], 0, (sbuf[j]).length);
/*      */             }
/*      */             break;
/*      */           case 1:
/*  296 */             usbuf = ((DataBufferUShort)this.currentTile.getDataBuffer()).getBankData();
/*      */             
/*  298 */             for (k = 0; k < usbuf.length; k++)
/*  299 */               this.iis.readFully(usbuf[k], 0, (usbuf[k]).length); 
/*      */             break;
/*      */           case 3:
/*  302 */             ibuf = ((DataBufferInt)this.currentTile.getDataBuffer()).getBankData();
/*      */             
/*  304 */             for (m = 0; m < ibuf.length; m++)
/*  305 */               this.iis.readFully(ibuf[m], 0, (ibuf[m]).length); 
/*      */             break;
/*      */           case 4:
/*  308 */             fbuf = ((DataBufferFloat)this.currentTile.getDataBuffer()).getBankData();
/*      */             
/*  310 */             for (n = 0; n < fbuf.length; n++)
/*  311 */               this.iis.readFully(fbuf[n], 0, (fbuf[n]).length); 
/*      */             break;
/*      */           case 5:
/*  314 */             dbuf = ((DataBufferDouble)this.currentTile.getDataBuffer()).getBankData();
/*      */             
/*  316 */             for (i1 = 0; i1 < dbuf.length; i1++)
/*  317 */               this.iis.readFully(dbuf[i1], 0, (dbuf[i1]).length); 
/*      */             break;
/*      */         } 
/*      */       } else {
/*  321 */         this.currentTile = readSubsampledRaster((WritableRaster)this.currentTile);
/*      */       } 
/*  323 */     } catch (IOException e) {
/*  324 */       throw new RuntimeException(e);
/*      */     } 
/*      */     
/*  327 */     if (this.currentTileGrid == null) {
/*  328 */       this.currentTileGrid = new Point(tileX, tileY);
/*      */     } else {
/*  330 */       this.currentTileGrid.x = tileX;
/*  331 */       this.currentTileGrid.y = tileY;
/*      */     } 
/*      */     
/*  334 */     return this.currentTile;
/*      */   }
/*      */   
/*      */   public void readAsRaster(WritableRaster raster) throws IOException {
/*  338 */     readSubsampledRaster(raster);
/*      */   }
/*      */   
/*      */   private Raster readSubsampledRaster(WritableRaster raster) throws IOException {
/*  342 */     if (raster == null) {
/*  343 */       raster = Raster.createWritableRaster(this.sampleModel.createCompatibleSampleModel(this.destinationRegion.x + this.destinationRegion.width, this.destinationRegion.y + this.destinationRegion.height), new Point(this.destinationRegion.x, this.destinationRegion.y));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  350 */     int numBands = this.sourceBands.length;
/*  351 */     int dataType = this.sampleModel.getDataType();
/*  352 */     int sampleSizeBit = DataBuffer.getDataTypeSize(dataType);
/*  353 */     int sampleSizeByte = (sampleSizeBit + 7) / 8;
/*      */     
/*  355 */     Rectangle destRect = raster.getBounds().intersection(this.destinationRegion);
/*      */     
/*  357 */     int offx = this.destinationRegion.x;
/*  358 */     int offy = this.destinationRegion.y;
/*      */     
/*  360 */     int sourceSX = (destRect.x - offx) * this.scaleX + this.sourceOrigin.x;
/*  361 */     int sourceSY = (destRect.y - offy) * this.scaleY + this.sourceOrigin.y;
/*  362 */     int sourceEX = (destRect.width - 1) * this.scaleX + sourceSX;
/*  363 */     int sourceEY = (destRect.height - 1) * this.scaleY + sourceSY;
/*  364 */     int startXTile = sourceSX / this.tileWidth;
/*  365 */     int startYTile = sourceSY / this.tileHeight;
/*  366 */     int endXTile = sourceEX / this.tileWidth;
/*  367 */     int endYTile = sourceEY / this.tileHeight;
/*      */     
/*  369 */     startXTile = clip(startXTile, 0, this.maxXTile);
/*  370 */     startYTile = clip(startYTile, 0, this.maxYTile);
/*  371 */     endXTile = clip(endXTile, 0, this.maxXTile);
/*  372 */     endYTile = clip(endYTile, 0, this.maxYTile);
/*      */     
/*  374 */     int totalXTiles = getNumXTiles();
/*  375 */     int totalYTiles = getNumYTiles();
/*  376 */     int totalTiles = totalXTiles * totalYTiles;
/*      */ 
/*      */     
/*  379 */     byte[] pixbuf = null;
/*  380 */     short[] spixbuf = null;
/*  381 */     int[] ipixbuf = null;
/*  382 */     float[] fpixbuf = null;
/*  383 */     double[] dpixbuf = null;
/*      */ 
/*      */     
/*  386 */     boolean singleBank = true;
/*  387 */     int pixelStride = 0;
/*  388 */     int scanlineStride = 0;
/*  389 */     int bandStride = 0;
/*  390 */     int[] bandOffsets = null;
/*  391 */     int[] bankIndices = null;
/*      */     
/*  393 */     if (this.originalSampleModel instanceof ComponentSampleModel) {
/*  394 */       ComponentSampleModel csm = (ComponentSampleModel)this.originalSampleModel;
/*  395 */       bankIndices = csm.getBankIndices();
/*  396 */       int maxBank = 0; int i;
/*  397 */       for (i = 0; i < bankIndices.length; i++) {
/*  398 */         if (maxBank > bankIndices[i])
/*  399 */           maxBank = bankIndices[i]; 
/*      */       } 
/*  401 */       if (maxBank > 0)
/*  402 */         singleBank = false; 
/*  403 */       pixelStride = csm.getPixelStride();
/*      */       
/*  405 */       scanlineStride = csm.getScanlineStride();
/*  406 */       bandOffsets = csm.getBandOffsets();
/*  407 */       for (i = 0; i < bandOffsets.length; i++)
/*  408 */       { if (bandStride < bandOffsets[i])
/*  409 */           bandStride = bandOffsets[i];  } 
/*  410 */     } else if (this.originalSampleModel instanceof MultiPixelPackedSampleModel) {
/*  411 */       scanlineStride = ((MultiPixelPackedSampleModel)this.originalSampleModel).getScanlineStride();
/*      */     }
/*  413 */     else if (this.originalSampleModel instanceof SinglePixelPackedSampleModel) {
/*  414 */       pixelStride = 1;
/*  415 */       scanlineStride = ((SinglePixelPackedSampleModel)this.originalSampleModel).getScanlineStride();
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  420 */     byte[] destPixbuf = null;
/*  421 */     short[] destSPixbuf = null;
/*  422 */     int[] destIPixbuf = null;
/*  423 */     float[] destFPixbuf = null;
/*  424 */     double[] destDPixbuf = null;
/*  425 */     int[] destBandOffsets = null;
/*  426 */     int destPixelStride = 0;
/*  427 */     int destScanlineStride = 0;
/*  428 */     int destSX = 0;
/*      */     
/*  430 */     if (raster.getSampleModel() instanceof ComponentSampleModel) {
/*  431 */       ComponentSampleModel csm = (ComponentSampleModel)raster.getSampleModel();
/*      */       
/*  433 */       bankIndices = csm.getBankIndices();
/*  434 */       destBandOffsets = csm.getBandOffsets();
/*  435 */       destPixelStride = csm.getPixelStride();
/*  436 */       destScanlineStride = csm.getScanlineStride();
/*  437 */       destSX = csm.getOffset(raster.getMinX() - raster.getSampleModelTranslateX(), raster.getMinY() - raster.getSampleModelTranslateY()) - destBandOffsets[0];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  443 */       switch (dataType) {
/*      */         case 0:
/*  445 */           destPixbuf = ((DataBufferByte)raster.getDataBuffer()).getData();
/*      */           break;
/*      */         case 2:
/*  448 */           destSPixbuf = ((DataBufferShort)raster.getDataBuffer()).getData();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 1:
/*  453 */           destSPixbuf = ((DataBufferUShort)raster.getDataBuffer()).getData();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 3:
/*  458 */           destIPixbuf = ((DataBufferInt)raster.getDataBuffer()).getData();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 4:
/*  463 */           destFPixbuf = ((DataBufferFloat)raster.getDataBuffer()).getData();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 5:
/*  468 */           destDPixbuf = ((DataBufferDouble)raster.getDataBuffer()).getData();
/*      */           break;
/*      */       } 
/*      */     
/*  472 */     } else if (raster.getSampleModel() instanceof SinglePixelPackedSampleModel) {
/*  473 */       numBands = 1;
/*  474 */       bankIndices = new int[] { 0 };
/*  475 */       destBandOffsets = new int[numBands];
/*  476 */       for (int i = 0; i < numBands; i++)
/*  477 */         destBandOffsets[i] = 0; 
/*  478 */       destPixelStride = 1;
/*  479 */       destScanlineStride = ((SinglePixelPackedSampleModel)raster.getSampleModel()).getScanlineStride();
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  484 */     for (int y = startYTile; y <= endYTile && 
/*  485 */       !this.reader.getAbortRequest(); y++) {
/*      */ 
/*      */ 
/*      */       
/*  489 */       for (int x = startXTile; x <= endXTile && 
/*  490 */         !this.reader.getAbortRequest(); x++) {
/*      */ 
/*      */         
/*  493 */         long tilePosition = this.position + (y * this.originalNumXTiles + x) * this.tileDataSize;
/*      */         
/*  495 */         this.iis.seek(tilePosition);
/*  496 */         float percentage = ((x - startXTile + y * totalXTiles) / totalXTiles);
/*      */ 
/*      */         
/*  499 */         int startX = x * this.tileWidth;
/*  500 */         int startY = y * this.tileHeight;
/*      */         
/*  502 */         int cTileHeight = this.tileHeight;
/*  503 */         int cTileWidth = this.tileWidth;
/*      */         
/*  505 */         if (startY + cTileHeight >= this.originalDimension.height) {
/*  506 */           cTileHeight = this.originalDimension.height - startY;
/*      */         }
/*  508 */         if (startX + cTileWidth >= this.originalDimension.width) {
/*  509 */           cTileWidth = this.originalDimension.width - startX;
/*      */         }
/*  511 */         int tx = startX;
/*  512 */         int ty = startY;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  517 */         if (sourceSX > startX) {
/*  518 */           cTileWidth += startX - sourceSX;
/*  519 */           tx = sourceSX;
/*  520 */           startX = sourceSX;
/*      */         } 
/*      */         
/*  523 */         if (sourceSY > startY) {
/*  524 */           cTileHeight += startY - sourceSY;
/*  525 */           ty = sourceSY;
/*  526 */           startY = sourceSY;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  532 */         if (sourceEX < startX + cTileWidth - 1) {
/*  533 */           cTileWidth += sourceEX - startX - cTileWidth + 1;
/*      */         }
/*      */         
/*  536 */         if (sourceEY < startY + cTileHeight - 1) {
/*  537 */           cTileHeight += sourceEY - startY - cTileHeight + 1;
/*      */         }
/*      */ 
/*      */         
/*  541 */         int x1 = (startX + this.scaleX - 1 - this.sourceOrigin.x) / this.scaleX;
/*  542 */         int x2 = (startX + this.scaleX - 1 + cTileWidth - this.sourceOrigin.x) / this.scaleX;
/*      */         
/*  544 */         int lineLength = x2 - x1;
/*  545 */         x2 = (x2 - 1) * this.scaleX + this.sourceOrigin.x;
/*      */         
/*  547 */         int y1 = (startY + this.scaleY - 1 - this.sourceOrigin.y) / this.scaleY;
/*  548 */         startX = x1 * this.scaleX + this.sourceOrigin.x;
/*  549 */         startY = y1 * this.scaleY + this.sourceOrigin.y;
/*      */ 
/*      */         
/*  552 */         x1 += offx;
/*  553 */         y1 += offy;
/*      */         
/*  555 */         tx -= x * this.tileWidth;
/*  556 */         ty -= y * this.tileHeight;
/*      */         
/*  558 */         if (this.sampleModel instanceof MultiPixelPackedSampleModel) {
/*  559 */           MultiPixelPackedSampleModel mppsm = (MultiPixelPackedSampleModel)this.originalSampleModel;
/*      */ 
/*      */           
/*  562 */           this.iis.skipBytes(mppsm.getOffset(tx, ty) * sampleSizeByte);
/*      */           
/*  564 */           int readBytes = (mppsm.getOffset(x2, 0) - mppsm.getOffset(startX, 0) + 1) * sampleSizeByte;
/*      */ 
/*      */ 
/*      */           
/*  568 */           int skipLength = (scanlineStride * this.scaleY - readBytes) * sampleSizeByte;
/*      */           
/*  570 */           readBytes *= sampleSizeByte;
/*      */           
/*  572 */           if (pixbuf == null || pixbuf.length < readBytes) {
/*  573 */             pixbuf = new byte[readBytes];
/*      */           }
/*  575 */           int bitoff = mppsm.getBitOffset(tx);
/*      */           
/*  577 */           for (int l = 0, m = y1; l < cTileHeight; 
/*  578 */             l += this.scaleY, m++) {
/*  579 */             if (this.reader.getAbortRequest())
/*      */               break; 
/*  581 */             this.iis.readFully(pixbuf, 0, readBytes);
/*  582 */             if (this.scaleX == 1) {
/*      */               
/*  584 */               if (bitoff != 0) {
/*  585 */                 int mask1 = 255 << bitoff & 0xFF;
/*  586 */                 int mask2 = (mask1 ^ 0xFFFFFFFF) & 0xFF;
/*  587 */                 int shift = 8 - bitoff;
/*      */                 
/*  589 */                 int n = 0;
/*  590 */                 for (; n < readBytes - 1; n++) {
/*  591 */                   pixbuf[n] = (byte)((pixbuf[n] & mask2) << shift | (pixbuf[n + 1] & mask1) >> bitoff);
/*      */                 }
/*  593 */                 pixbuf[n] = (byte)((pixbuf[n] & mask2) << shift);
/*      */               } 
/*      */             } else {
/*      */               
/*  597 */               int bit = 7;
/*  598 */               int pos = 0;
/*  599 */               int mask = 128;
/*      */               
/*  601 */               int n = 0, n1 = startX & 0x7;
/*  602 */               for (; n < lineLength; n++, n1 += this.scaleX) {
/*  603 */                 pixbuf[pos] = (byte)(pixbuf[pos] & (1 << bit ^ 0xFFFFFFFF) | (pixbuf[n1 >> 3] >> 7 - (n1 & 0x7) & 0x1) << bit);
/*      */                 
/*  605 */                 bit--;
/*  606 */                 if (bit == -1) {
/*  607 */                   bit = 7;
/*  608 */                   pos++;
/*      */                 } 
/*      */               } 
/*      */             } 
/*      */             
/*  613 */             ImageUtil.setPackedBinaryData(pixbuf, raster, new Rectangle(x1, m, lineLength, 1));
/*      */ 
/*      */ 
/*      */             
/*  617 */             this.iis.skipBytes(skipLength);
/*  618 */             if (this.destImage != null) {
/*  619 */               this.reader.processImageUpdateWrapper(this.destImage, x1, m, cTileWidth, 1, 1, 1, this.destinationBands);
/*      */             }
/*      */ 
/*      */             
/*  623 */             this.reader.processImageProgressWrapper(percentage + ((l - startY) + 1.0F) / cTileHeight / totalTiles);
/*      */           } 
/*      */         } else {
/*      */           int readLength;
/*      */           
/*      */           int skipLength;
/*      */           
/*  630 */           if (pixelStride < scanlineStride) {
/*  631 */             readLength = cTileWidth * pixelStride;
/*  632 */             skipLength = (scanlineStride * this.scaleY - readLength) * sampleSizeByte;
/*      */           } else {
/*      */             
/*  635 */             readLength = cTileHeight * scanlineStride;
/*  636 */             skipLength = (pixelStride * this.scaleX - readLength) * sampleSizeByte;
/*      */           } 
/*      */ 
/*      */ 
/*      */           
/*  641 */           switch (this.sampleModel.getDataType()) {
/*      */             case 0:
/*  643 */               if (pixbuf == null || pixbuf.length < readLength) {
/*  644 */                 pixbuf = new byte[readLength];
/*      */               }
/*      */               break;
/*      */             case 1:
/*      */             case 2:
/*  649 */               if (spixbuf == null || spixbuf.length < readLength) {
/*  650 */                 spixbuf = new short[readLength];
/*      */               }
/*      */               break;
/*      */             case 3:
/*  654 */               if (ipixbuf == null || ipixbuf.length < readLength) {
/*  655 */                 ipixbuf = new int[readLength];
/*      */               }
/*      */               break;
/*      */             case 4:
/*  659 */               if (fpixbuf == null || fpixbuf.length < readLength) {
/*  660 */                 fpixbuf = new float[readLength];
/*      */               }
/*      */               break;
/*      */             case 5:
/*  664 */               if (dpixbuf == null || dpixbuf.length < readLength) {
/*  665 */                 dpixbuf = new double[readLength];
/*      */               }
/*      */               break;
/*      */           } 
/*  669 */           if (this.sampleModel instanceof java.awt.image.PixelInterleavedSampleModel) {
/*  670 */             int outerFirst, outerSecond, outerStep, outerBound, innerStep, innerStep1, outerStep1; this.iis.skipBytes((tx * pixelStride + ty * scanlineStride) * sampleSizeByte);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  676 */             if (pixelStride < scanlineStride) {
/*  677 */               outerFirst = 0;
/*  678 */               outerSecond = y1;
/*  679 */               outerStep = this.scaleY;
/*  680 */               outerBound = cTileHeight;
/*  681 */               innerStep = this.scaleX * pixelStride;
/*  682 */               innerStep1 = destPixelStride;
/*  683 */               outerStep1 = destScanlineStride;
/*      */             } else {
/*  685 */               outerFirst = 0;
/*  686 */               outerSecond = x1;
/*  687 */               outerStep = this.scaleX;
/*  688 */               outerBound = cTileWidth;
/*  689 */               innerStep = this.scaleY * scanlineStride;
/*  690 */               innerStep1 = destScanlineStride;
/*  691 */               outerStep1 = destPixelStride;
/*      */             } 
/*      */             
/*  694 */             int destPos = destSX + (y1 - raster.getSampleModelTranslateY()) * destScanlineStride + (x1 - raster.getSampleModelTranslateX()) * destPixelStride;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  700 */             for (int l = outerFirst, m = outerSecond; l < outerBound; 
/*  701 */               l += outerStep, m++) {
/*  702 */               if (this.reader.getAbortRequest()) {
/*      */                 break;
/*      */               }
/*  705 */               switch (dataType) {
/*      */                 case 0:
/*  707 */                   if (innerStep == numBands && innerStep1 == numBands) {
/*      */                     
/*  709 */                     this.iis.readFully(destPixbuf, destPos, readLength); break;
/*      */                   } 
/*  711 */                   this.iis.readFully(pixbuf, 0, readLength);
/*      */                   break;
/*      */                 case 1:
/*      */                 case 2:
/*  715 */                   if (innerStep == numBands && innerStep1 == numBands) {
/*      */                     
/*  717 */                     this.iis.readFully(destSPixbuf, destPos, readLength); break;
/*      */                   } 
/*  719 */                   this.iis.readFully(spixbuf, 0, readLength);
/*      */                   break;
/*      */                 case 3:
/*  722 */                   if (innerStep == numBands && innerStep1 == numBands) {
/*      */                     
/*  724 */                     this.iis.readFully(destIPixbuf, destPos, readLength); break;
/*      */                   } 
/*  726 */                   this.iis.readFully(ipixbuf, 0, readLength);
/*      */                   break;
/*      */                 case 4:
/*  729 */                   if (innerStep == numBands && innerStep1 == numBands) {
/*      */                     
/*  731 */                     this.iis.readFully(destFPixbuf, destPos, readLength); break;
/*      */                   } 
/*  733 */                   this.iis.readFully(fpixbuf, 0, readLength);
/*      */                   break;
/*      */                 case 5:
/*  736 */                   if (innerStep == numBands && innerStep1 == numBands) {
/*      */                     
/*  738 */                     this.iis.readFully(destDPixbuf, destPos, readLength); break;
/*      */                   } 
/*  740 */                   this.iis.readFully(dpixbuf, 0, readLength);
/*      */                   break;
/*      */               } 
/*      */               
/*  744 */               if (innerStep != numBands || innerStep1 != numBands) {
/*  745 */                 for (int b = 0; b < numBands; b++) {
/*  746 */                   int m1, n, destBandOffset = destBandOffsets[this.destinationBands[b]];
/*      */                   
/*  748 */                   destPos += destBandOffset;
/*      */                   
/*  750 */                   int sourceBandOffset = bandOffsets[this.sourceBands[b]];
/*      */ 
/*      */                   
/*  753 */                   switch (dataType) {
/*      */                     case 0:
/*  755 */                       for (m1 = 0, n = destPos; m1 < readLength; 
/*  756 */                         m1 += innerStep, n += innerStep1) {
/*  757 */                         destPixbuf[n] = pixbuf[m1 + sourceBandOffset];
/*      */                       }
/*      */                       break;
/*      */                     
/*      */                     case 1:
/*      */                     case 2:
/*  763 */                       for (m1 = 0, n = destPos; m1 < readLength; 
/*  764 */                         m1 += innerStep, n += innerStep1) {
/*  765 */                         destSPixbuf[n] = spixbuf[m1 + sourceBandOffset];
/*      */                       }
/*      */                       break;
/*      */                     
/*      */                     case 3:
/*  770 */                       for (m1 = 0, n = destPos; m1 < readLength; 
/*  771 */                         m1 += innerStep, n += innerStep1) {
/*  772 */                         destIPixbuf[n] = ipixbuf[m1 + sourceBandOffset];
/*      */                       }
/*      */                       break;
/*      */                     
/*      */                     case 4:
/*  777 */                       for (m1 = 0, n = destPos; m1 < readLength; 
/*  778 */                         m1 += innerStep, n += innerStep1) {
/*  779 */                         destFPixbuf[n] = fpixbuf[m1 + sourceBandOffset];
/*      */                       }
/*      */                       break;
/*      */                     
/*      */                     case 5:
/*  784 */                       for (m1 = 0, n = destPos; m1 < readLength; 
/*  785 */                         m1 += innerStep, n += innerStep1) {
/*  786 */                         destDPixbuf[n] = dpixbuf[m1 + sourceBandOffset];
/*      */                       }
/*      */                       break;
/*      */                   } 
/*      */                   
/*  791 */                   destPos -= destBandOffset;
/*      */                 } 
/*      */               }
/*  794 */               this.iis.skipBytes(skipLength);
/*  795 */               destPos += outerStep1;
/*      */               
/*  797 */               if (this.destImage != null) {
/*  798 */                 if (pixelStride < scanlineStride) {
/*  799 */                   this.reader.processImageUpdateWrapper(this.destImage, x1, m, outerBound, 1, 1, 1, this.destinationBands);
/*      */                 
/*      */                 }
/*      */                 else {
/*      */ 
/*      */                   
/*  805 */                   this.reader.processImageUpdateWrapper(this.destImage, m, y1, 1, outerBound, 1, 1, this.destinationBands);
/*      */                 } 
/*      */               }
/*      */ 
/*      */ 
/*      */               
/*  811 */               this.reader.processImageProgressWrapper(percentage + (l + 1.0F) / outerBound / totalTiles);
/*      */             
/*      */             }
/*      */           
/*      */           }
/*  816 */           else if (this.sampleModel instanceof java.awt.image.BandedSampleModel || this.sampleModel instanceof SinglePixelPackedSampleModel || bandStride == 0) {
/*      */ 
/*      */             
/*  819 */             boolean isBanded = this.sampleModel instanceof java.awt.image.BandedSampleModel;
/*      */             
/*  821 */             int bandSize = (int)ImageUtil.getBandSize(this.originalSampleModel);
/*      */ 
/*      */             
/*  824 */             for (int b = 0; b < numBands; b++) {
/*  825 */               int outerFirst, outerSecond, outerStep, outerBound, innerStep, innerStep1, outerStep1; this.iis.seek(tilePosition + (bandSize * this.sourceBands[b] * sampleSizeByte));
/*      */               
/*  827 */               int destBandOffset = destBandOffsets[this.destinationBands[b]];
/*      */ 
/*      */               
/*  830 */               this.iis.skipBytes((ty * scanlineStride + tx * pixelStride) * sampleSizeByte);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*  836 */               if (pixelStride < scanlineStride) {
/*  837 */                 outerFirst = 0;
/*  838 */                 outerSecond = y1;
/*  839 */                 outerStep = this.scaleY;
/*  840 */                 outerBound = cTileHeight;
/*  841 */                 innerStep = this.scaleX * pixelStride;
/*  842 */                 innerStep1 = destPixelStride;
/*  843 */                 outerStep1 = destScanlineStride;
/*      */               } else {
/*  845 */                 outerFirst = 0;
/*  846 */                 outerSecond = x1;
/*  847 */                 outerStep = this.scaleX;
/*  848 */                 outerBound = cTileWidth;
/*  849 */                 innerStep = this.scaleY * scanlineStride;
/*  850 */                 innerStep1 = destScanlineStride;
/*  851 */                 outerStep1 = destPixelStride;
/*      */               } 
/*      */               
/*  854 */               int destPos = destSX + (y1 - raster.getSampleModelTranslateY()) * destScanlineStride + (x1 - raster.getSampleModelTranslateX()) * destPixelStride + destBandOffset;
/*      */ 
/*      */               
/*  857 */               int bank = bankIndices[this.destinationBands[b]];
/*      */               
/*  859 */               switch (dataType) {
/*      */                 case 0:
/*  861 */                   destPixbuf = ((DataBufferByte)raster.getDataBuffer()).getData(bank);
/*      */                   break;
/*      */                 
/*      */                 case 2:
/*  865 */                   destSPixbuf = ((DataBufferShort)raster.getDataBuffer()).getData(bank);
/*      */                   break;
/*      */ 
/*      */                 
/*      */                 case 1:
/*  870 */                   destSPixbuf = ((DataBufferUShort)raster.getDataBuffer()).getData(bank);
/*      */                   break;
/*      */ 
/*      */                 
/*      */                 case 3:
/*  875 */                   destIPixbuf = ((DataBufferInt)raster.getDataBuffer()).getData(bank);
/*      */                   break;
/*      */ 
/*      */                 
/*      */                 case 4:
/*  880 */                   destFPixbuf = ((DataBufferFloat)raster.getDataBuffer()).getData(bank);
/*      */                   break;
/*      */ 
/*      */                 
/*      */                 case 5:
/*  885 */                   destDPixbuf = ((DataBufferDouble)raster.getDataBuffer()).getData(bank);
/*      */                   break;
/*      */               } 
/*      */ 
/*      */               
/*  890 */               for (int l = outerFirst, m = outerSecond; l < outerBound; 
/*  891 */                 l += outerStep, m++) {
/*  892 */                 int m1, n; if (this.reader.getAbortRequest()) {
/*      */                   break;
/*      */                 }
/*  895 */                 switch (dataType) {
/*      */                   case 0:
/*  897 */                     if (innerStep == 1 && innerStep1 == 1) {
/*  898 */                       this.iis.readFully(destPixbuf, destPos, readLength); break;
/*      */                     } 
/*  900 */                     this.iis.readFully(pixbuf, 0, readLength);
/*  901 */                     for (m1 = 0, n = destPos; m1 < readLength; 
/*  902 */                       m1 += innerStep, n += innerStep1) {
/*  903 */                       destPixbuf[n] = pixbuf[m1];
/*      */                     }
/*      */                     break;
/*      */                   
/*      */                   case 1:
/*      */                   case 2:
/*  909 */                     if (innerStep == 1 && innerStep1 == 1) {
/*  910 */                       this.iis.readFully(destSPixbuf, destPos, readLength); break;
/*      */                     } 
/*  912 */                     this.iis.readFully(spixbuf, 0, readLength);
/*  913 */                     for (m1 = 0, n = destPos; m1 < readLength; 
/*  914 */                       m1 += innerStep, n += innerStep1) {
/*  915 */                       destSPixbuf[n] = spixbuf[m1];
/*      */                     }
/*      */                     break;
/*      */                   
/*      */                   case 3:
/*  920 */                     if (innerStep == 1 && innerStep1 == 1) {
/*  921 */                       this.iis.readFully(destIPixbuf, destPos, readLength); break;
/*      */                     } 
/*  923 */                     this.iis.readFully(ipixbuf, 0, readLength);
/*  924 */                     for (m1 = 0, n = destPos; m1 < readLength; 
/*  925 */                       m1 += innerStep, n += innerStep1) {
/*  926 */                       destIPixbuf[n] = ipixbuf[m1];
/*      */                     }
/*      */                     break;
/*      */                   
/*      */                   case 4:
/*  931 */                     if (innerStep == 1 && innerStep1 == 1) {
/*  932 */                       this.iis.readFully(destFPixbuf, destPos, readLength); break;
/*      */                     } 
/*  934 */                     this.iis.readFully(fpixbuf, 0, readLength);
/*  935 */                     for (m1 = 0, n = destPos; m1 < readLength; 
/*  936 */                       m1 += innerStep, n += innerStep1) {
/*  937 */                       destFPixbuf[n] = fpixbuf[m1];
/*      */                     }
/*      */                     break;
/*      */                   
/*      */                   case 5:
/*  942 */                     if (innerStep == 1 && innerStep1 == 1) {
/*  943 */                       this.iis.readFully(destDPixbuf, destPos, readLength); break;
/*      */                     } 
/*  945 */                     this.iis.readFully(dpixbuf, 0, readLength);
/*  946 */                     for (m1 = 0, n = destPos; m1 < readLength; 
/*  947 */                       m1 += innerStep, n += innerStep1) {
/*  948 */                       destDPixbuf[n] = dpixbuf[m1];
/*      */                     }
/*      */                     break;
/*      */                 } 
/*      */ 
/*      */                 
/*  954 */                 this.iis.skipBytes(skipLength);
/*  955 */                 destPos += outerStep1;
/*      */                 
/*  957 */                 if (this.destImage != null) {
/*  958 */                   int[] destBands = { this.destinationBands[b] };
/*      */                   
/*  960 */                   if (pixelStride < scanlineStride) {
/*  961 */                     this.reader.processImageUpdateWrapper(this.destImage, x1, m, outerBound, 1, 1, 1, destBands);
/*      */                   
/*      */                   }
/*      */                   else {
/*      */ 
/*      */                     
/*  967 */                     this.reader.processImageUpdateWrapper(this.destImage, m, y1, 1, outerBound, 1, 1, destBands);
/*      */                   } 
/*      */                 } 
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*  974 */                 this.reader.processImageProgressWrapper((percentage + (l + 1.0F) / outerBound / numBands / totalTiles) * 100.0F);
/*      */               }
/*      */             
/*      */             }
/*      */           
/*      */           }
/*  980 */           else if (this.sampleModel instanceof ComponentSampleModel) {
/*      */ 
/*      */             
/*  983 */             int bufferSize = (int)this.tileDataSize;
/*      */             
/*  985 */             switch (this.sampleModel.getDataType()) {
/*      */               case 0:
/*  987 */                 if (pixbuf == null || pixbuf.length < this.tileDataSize)
/*  988 */                   pixbuf = new byte[(int)this.tileDataSize]; 
/*  989 */                 this.iis.readFully(pixbuf, 0, (int)this.tileDataSize);
/*      */                 break;
/*      */               
/*      */               case 1:
/*      */               case 2:
/*  994 */                 bufferSize /= 2;
/*  995 */                 if (spixbuf == null || spixbuf.length < bufferSize)
/*  996 */                   spixbuf = new short[bufferSize]; 
/*  997 */                 this.iis.readFully(spixbuf, 0, bufferSize);
/*      */                 break;
/*      */               
/*      */               case 3:
/* 1001 */                 bufferSize /= 4;
/* 1002 */                 if (ipixbuf == null || ipixbuf.length < bufferSize)
/* 1003 */                   ipixbuf = new int[bufferSize]; 
/* 1004 */                 this.iis.readFully(ipixbuf, 0, bufferSize);
/*      */                 break;
/*      */               
/*      */               case 4:
/* 1008 */                 bufferSize /= 4;
/* 1009 */                 if (fpixbuf == null || fpixbuf.length < bufferSize)
/* 1010 */                   fpixbuf = new float[bufferSize]; 
/* 1011 */                 this.iis.readFully(fpixbuf, 0, bufferSize);
/*      */                 break;
/*      */               
/*      */               case 5:
/* 1015 */                 bufferSize /= 8;
/* 1016 */                 if (dpixbuf == null || dpixbuf.length < bufferSize)
/* 1017 */                   dpixbuf = new double[bufferSize]; 
/* 1018 */                 this.iis.readFully(dpixbuf, 0, bufferSize);
/*      */                 break;
/*      */             } 
/*      */             
/* 1022 */             for (int b = 0; b < numBands; b++) {
/* 1023 */               int destBandOffset = destBandOffsets[this.destinationBands[b]];
/*      */ 
/*      */               
/* 1026 */               int destPos = ((ComponentSampleModel)raster.getSampleModel()).getOffset(x1 - raster.getSampleModelTranslateX(), y1 - raster.getSampleModelTranslateY(), this.destinationBands[b]);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 1032 */               int bank = bankIndices[this.destinationBands[b]];
/*      */               
/* 1034 */               switch (dataType) {
/*      */                 case 0:
/* 1036 */                   destPixbuf = ((DataBufferByte)raster.getDataBuffer()).getData(bank);
/*      */                   break;
/*      */                 
/*      */                 case 2:
/* 1040 */                   destSPixbuf = ((DataBufferShort)raster.getDataBuffer()).getData(bank);
/*      */                   break;
/*      */ 
/*      */                 
/*      */                 case 1:
/* 1045 */                   destSPixbuf = ((DataBufferUShort)raster.getDataBuffer()).getData(bank);
/*      */                   break;
/*      */ 
/*      */                 
/*      */                 case 3:
/* 1050 */                   destIPixbuf = ((DataBufferInt)raster.getDataBuffer()).getData(bank);
/*      */                   break;
/*      */ 
/*      */                 
/*      */                 case 4:
/* 1055 */                   destFPixbuf = ((DataBufferFloat)raster.getDataBuffer()).getData(bank);
/*      */                   break;
/*      */ 
/*      */                 
/*      */                 case 5:
/* 1060 */                   destDPixbuf = ((DataBufferDouble)raster.getDataBuffer()).getData(bank);
/*      */                   break;
/*      */               } 
/*      */ 
/*      */               
/* 1065 */               int srcPos = ((ComponentSampleModel)this.originalSampleModel).getOffset(tx, ty, this.sourceBands[b]);
/*      */               
/* 1067 */               int skipX = this.scaleX * pixelStride;
/* 1068 */               for (int l = 0, m = y1; l < cTileHeight; 
/* 1069 */                 l += this.scaleY, m++) {
/* 1070 */                 int n, m1, m2; if (this.reader.getAbortRequest()) {
/*      */                   break;
/*      */                 }
/* 1073 */                 switch (dataType) {
/*      */                   case 0:
/* 1075 */                     n = 0; m1 = srcPos; m2 = destPos;
/* 1076 */                     for (; n < lineLength; 
/* 1077 */                       n++, m1 += skipX, m2 += destPixelStride)
/* 1078 */                       destPixbuf[m2] = pixbuf[m1]; 
/*      */                     break;
/*      */                   case 1:
/*      */                   case 2:
/* 1082 */                     n = 0; m1 = srcPos; m2 = destPos;
/* 1083 */                     for (; n < lineLength; 
/* 1084 */                       n++, m1 += skipX, m2 += destPixelStride)
/* 1085 */                       destSPixbuf[m2] = spixbuf[m1]; 
/*      */                     break;
/*      */                   case 3:
/* 1088 */                     n = 0; m1 = srcPos; m2 = destPos;
/* 1089 */                     for (; n < lineLength; 
/* 1090 */                       n++, m1 += skipX, m2 += destPixelStride)
/* 1091 */                       destIPixbuf[m2] = ipixbuf[m1]; 
/*      */                     break;
/*      */                   case 4:
/* 1094 */                     n = 0; m1 = srcPos; m2 = destPos;
/* 1095 */                     for (; n < lineLength; 
/* 1096 */                       n++, m1 += skipX, m2 += destPixelStride)
/* 1097 */                       destFPixbuf[m2] = fpixbuf[m1]; 
/*      */                     break;
/*      */                   case 5:
/* 1100 */                     n = 0; m1 = srcPos; m2 = destPos;
/* 1101 */                     for (; n < lineLength; 
/* 1102 */                       n++, m1 += skipX, m2 += destPixelStride) {
/* 1103 */                       destDPixbuf[m2] = dpixbuf[m1];
/*      */                     }
/*      */                     break;
/*      */                 } 
/* 1107 */                 destPos += destScanlineStride;
/* 1108 */                 srcPos += scanlineStride * this.scaleY;
/*      */                 
/* 1110 */                 if (this.destImage != null) {
/* 1111 */                   int[] destBands = { this.destinationBands[b] };
/*      */                   
/* 1113 */                   this.reader.processImageUpdateWrapper(this.destImage, x1, m, cTileHeight, 1, 1, 1, destBands);
/*      */                 } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/* 1120 */                 this.reader.processImageProgressWrapper(percentage + (l + 1.0F) / cTileHeight / numBands / totalTiles);
/*      */               }
/*      */             
/*      */             }
/*      */           
/*      */           }
/*      */           else {
/*      */             
/* 1128 */             throw new IllegalArgumentException(I18N.getString("RawRenderedImage1"));
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 1134 */     return raster;
/*      */   }
/*      */   
/*      */   public void setDestImage(BufferedImage image) {
/* 1138 */     this.destImage = image;
/*      */   }
/*      */   
/*      */   public void clearDestImage() {
/* 1142 */     this.destImage = null;
/*      */   }
/*      */   
/*      */   private int getTileNum(int x, int y) {
/* 1146 */     int num = (y - getMinTileY()) * getNumXTiles() + x - getMinTileX();
/*      */     
/* 1148 */     if (num < 0 || num >= getNumXTiles() * getNumYTiles()) {
/* 1149 */       throw new IllegalArgumentException(I18N.getString("RawRenderedImage0"));
/*      */     }
/* 1151 */     return num;
/*      */   }
/*      */   
/*      */   private int clip(int value, int min, int max) {
/* 1155 */     if (value < min)
/* 1156 */       value = min; 
/* 1157 */     if (value > max)
/* 1158 */       value = max; 
/* 1159 */     return value;
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/raw/RawRenderedImage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */