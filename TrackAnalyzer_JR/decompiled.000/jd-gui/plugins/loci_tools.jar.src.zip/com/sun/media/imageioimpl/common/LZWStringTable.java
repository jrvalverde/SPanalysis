/*     */ package com.sun.media.imageioimpl.common;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LZWStringTable
/*     */ {
/* 124 */   byte[] strChr_ = new byte[4096];
/* 125 */   short[] strNxt_ = new short[4096];
/* 126 */   int[] strLen_ = new int[4096];
/* 127 */   short[] strHsh_ = new short[9973];
/*     */   
/*     */   private static final int RES_CODES = 2;
/*     */   
/*     */   private static final short HASH_FREE = -1;
/*     */   
/*     */   private static final short NEXT_FIRST = -1;
/*     */   private static final int MAXBITS = 12;
/*     */   private static final int MAXSTR = 4096;
/*     */   private static final short HASHSIZE = 9973;
/*     */   private static final short HASHSTEP = 2039;
/*     */   short numStrings_;
/*     */   
/*     */   public int AddCharString(short index, byte b) {
/* 141 */     if (this.numStrings_ >= 4096)
/*     */     {
/* 143 */       return 65535;
/*     */     }
/*     */     
/* 146 */     int hshidx = Hash(index, b);
/* 147 */     while (this.strHsh_[hshidx] != -1) {
/* 148 */       hshidx = (hshidx + 2039) % 9973;
/*     */     }
/* 150 */     this.strHsh_[hshidx] = this.numStrings_;
/* 151 */     this.strChr_[this.numStrings_] = b;
/* 152 */     if (index == -1) {
/*     */       
/* 154 */       this.strNxt_[this.numStrings_] = -1;
/* 155 */       this.strLen_[this.numStrings_] = 1;
/*     */     }
/*     */     else {
/*     */       
/* 159 */       this.strNxt_[this.numStrings_] = index;
/* 160 */       this.strLen_[this.numStrings_] = this.strLen_[index] + 1;
/*     */     } 
/*     */     
/* 163 */     this.numStrings_ = (short)(this.numStrings_ + 1); return this.numStrings_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public short FindCharString(short index, byte b) {
/* 176 */     if (index == -1) {
/* 177 */       return (short)(b & 0xFF);
/*     */     }
/* 179 */     int hshidx = Hash(index, b); int nxtidx;
/* 180 */     while ((nxtidx = this.strHsh_[hshidx]) != -1) {
/*     */       
/* 182 */       if (this.strNxt_[nxtidx] == index && this.strChr_[nxtidx] == b)
/* 183 */         return (short)nxtidx; 
/* 184 */       hshidx = (hshidx + 2039) % 9973;
/*     */     } 
/*     */     
/* 187 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void ClearTable(int codesize) {
/* 196 */     this.numStrings_ = 0;
/*     */     
/* 198 */     for (int q = 0; q < 9973; q++) {
/* 199 */       this.strHsh_[q] = -1;
/*     */     }
/* 201 */     int w = (1 << codesize) + 2;
/* 202 */     for (int i = 0; i < w; i++) {
/* 203 */       AddCharString((short)-1, (byte)i);
/*     */     }
/*     */   }
/*     */   
/*     */   public static int Hash(short index, byte lastbyte) {
/* 208 */     return (((short)(lastbyte << 8) ^ index) & 0xFFFF) % 9973;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int expandCode(byte[] buf, int offset, short code, int skipHead) {
/*     */     int expandLen;
/* 233 */     if (offset == -2)
/*     */     {
/* 235 */       if (skipHead == 1) skipHead = 0; 
/*     */     }
/* 237 */     if (code == -1 || skipHead == this.strLen_[code])
/*     */     {
/* 239 */       return 0;
/*     */     }
/*     */     
/* 242 */     int codeLen = this.strLen_[code] - skipHead;
/* 243 */     int bufSpace = buf.length - offset;
/* 244 */     if (bufSpace > codeLen) {
/* 245 */       expandLen = codeLen;
/*     */     } else {
/* 247 */       expandLen = bufSpace;
/*     */     } 
/* 249 */     int skipTail = codeLen - expandLen;
/*     */     
/* 251 */     int idx = offset + expandLen;
/*     */ 
/*     */ 
/*     */     
/* 255 */     while (idx > offset && code != -1) {
/*     */       
/* 257 */       if (--skipTail < 0)
/*     */       {
/* 259 */         buf[--idx] = this.strChr_[code];
/*     */       }
/* 261 */       code = this.strNxt_[code];
/*     */     } 
/*     */     
/* 264 */     if (codeLen > expandLen) {
/* 265 */       return -expandLen;
/*     */     }
/* 267 */     return expandLen;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void dump(PrintStream out) {
/* 273 */     for (int i = 258; i < this.numStrings_; i++)
/* 274 */       out.println(" strNxt_[" + i + "] = " + this.strNxt_[i] + " strChr_ " + Integer.toHexString(this.strChr_[i] & 0xFF) + " strLen_ " + Integer.toHexString(this.strLen_[i])); 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/common/LZWStringTable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */