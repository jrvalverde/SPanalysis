/*      */ package com.sun.media.imageioimpl.plugins.jpeg2000;
/*      */ 
/*      */ import com.sun.media.imageio.plugins.jpeg2000.J2KImageWriteParam;
/*      */ import java.awt.Rectangle;
/*      */ import java.awt.image.Raster;
/*      */ import java.awt.image.RenderedImage;
/*      */ import java.util.Locale;
/*      */ import javax.imageio.IIOImage;
/*      */ import javax.imageio.ImageWriteParam;
/*      */ import jj2000.j2k.IntegerSpec;
/*      */ import jj2000.j2k.StringSpec;
/*      */ import jj2000.j2k.entropy.CBlkSizeSpec;
/*      */ import jj2000.j2k.entropy.PrecinctSizeSpec;
/*      */ import jj2000.j2k.entropy.ProgressionSpec;
/*      */ import jj2000.j2k.entropy.encoder.LayersInfo;
/*      */ import jj2000.j2k.image.forwcomptransf.ForwCompTransfSpec;
/*      */ import jj2000.j2k.quantization.GuardBitsSpec;
/*      */ import jj2000.j2k.quantization.QuantStepSizeSpec;
/*      */ import jj2000.j2k.quantization.QuantTypeSpec;
/*      */ import jj2000.j2k.roi.MaxShiftSpec;
/*      */ import jj2000.j2k.wavelet.analysis.AnWTFilterSpec;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class J2KImageWriteParamJava
/*      */   extends ImageWriteParam
/*      */ {
/*      */   private boolean packPacketHeaderInTile;
/*      */   private boolean packPacketHeaderInMain;
/*      */   private int packetPerTilePart;
/*      */   private double encodingRate;
/*      */   private boolean lossless;
/*      */   private ForwCompTransfSpec componentTransformation;
/*      */   private boolean enableCT;
/*      */   private AnWTFilterSpec filters;
/*      */   private IntegerSpec decompositionLevel;
/*      */   private GuardBitsSpec guardBits;
/*      */   private QuantStepSizeSpec quantizationStep;
/*      */   private QuantTypeSpec quantizationType;
/*      */   private int startLevelROI;
/*      */   private boolean alignROI;
/*      */   private MaxShiftSpec ROIs;
/*      */   private CBlkSizeSpec codeBlockSize;
/*      */   private StringSpec bypass;
/*      */   private StringSpec resetMQ;
/*      */   private StringSpec terminateOnByte;
/*      */   private StringSpec causalCXInfo;
/*      */   private StringSpec codeSegSymbol;
/*      */   private StringSpec methodForMQTermination;
/*      */   private StringSpec methodForMQLengthCalc;
/*      */   private PrecinctSizeSpec precinctPartition;
/*      */   private ProgressionSpec progressionType;
/*      */   private String progressionName;
/*      */   private String layers;
/*      */   private StringSpec EPH;
/*      */   private StringSpec SOP;
/*      */   private int numTiles;
/*      */   private int numComponents;
/*      */   private RenderedImage imgsrc;
/*      */   private Raster raster;
/*      */   private int minX;
/*      */   private int minY;
/*      */   
/*      */   public J2KImageWriteParamJava(RenderedImage imgsrc, Locale locale) {
/*  663 */     super(locale); this.packPacketHeaderInTile = false; this.packPacketHeaderInMain = false; this.packetPerTilePart = 0; this.encodingRate = Double.MAX_VALUE; this.lossless = true; this.componentTransformation = null; this.enableCT = true; this.filters = null; this.decompositionLevel = null; this.guardBits = null; this.quantizationStep = null; this.quantizationType = null; this.startLevelROI = -1; this.alignROI = false; this.ROIs = null; this.codeBlockSize = null; this.bypass = null; this.resetMQ = null; this.terminateOnByte = null; this.causalCXInfo = null; this.codeSegSymbol = null; this.methodForMQTermination = null; this.methodForMQLengthCalc = null; this.precinctPartition = null; this.progressionType = null; this.progressionName = null; this.layers = "0.015 +20 2.0 +10"; this.EPH = null; this.SOP = null;
/*  664 */     setDefaults(imgsrc);
/*      */   }
/*      */ 
/*      */   
/*      */   public J2KImageWriteParamJava(IIOImage image, ImageWriteParam param) {
/*  669 */     super(param.getLocale()); J2KImageWriteParam j2kParam; this.packPacketHeaderInTile = false; this.packPacketHeaderInMain = false; this.packetPerTilePart = 0; this.encodingRate = Double.MAX_VALUE; this.lossless = true; this.componentTransformation = null; this.enableCT = true; this.filters = null; this.decompositionLevel = null; this.guardBits = null; this.quantizationStep = null; this.quantizationType = null; this.startLevelROI = -1; this.alignROI = false; this.ROIs = null; this.codeBlockSize = null; this.bypass = null; this.resetMQ = null; this.terminateOnByte = null; this.causalCXInfo = null; this.codeSegSymbol = null; this.methodForMQTermination = null; this.methodForMQLengthCalc = null; this.precinctPartition = null; this.progressionType = null; this.progressionName = null; this.layers = "0.015 +20 2.0 +10"; this.EPH = null; this.SOP = null;
/*  670 */     if (image != null) {
/*  671 */       if (image.hasRaster()) {
/*  672 */         setDefaults(image.getRaster());
/*      */       } else {
/*  674 */         setDefaults(image.getRenderedImage());
/*      */       } 
/*      */     }
/*  677 */     setSourceRegion(param.getSourceRegion());
/*  678 */     setSourceBands(param.getSourceBands());
/*      */     try {
/*  680 */       setTiling(param.getTileWidth(), param.getTileHeight(), param.getTileGridXOffset(), param.getTileGridYOffset());
/*      */     }
/*  682 */     catch (IllegalStateException e) {}
/*      */ 
/*      */ 
/*      */     
/*  686 */     setDestinationOffset(param.getDestinationOffset());
/*  687 */     setSourceSubsampling(param.getSourceXSubsampling(), param.getSourceYSubsampling(), param.getSubsamplingXOffset(), param.getSubsamplingYOffset());
/*      */ 
/*      */ 
/*      */     
/*  691 */     setDestinationType(param.getDestinationType());
/*      */ 
/*      */     
/*  694 */     if (param instanceof J2KImageWriteParam) {
/*  695 */       j2kParam = (J2KImageWriteParam)param;
/*      */     } else {
/*  697 */       j2kParam = new J2KImageWriteParam();
/*      */     } 
/*      */     
/*  700 */     setDecompositionLevel("" + j2kParam.getNumDecompositionLevels());
/*  701 */     setEncodingRate(j2kParam.getEncodingRate());
/*  702 */     setLossless(j2kParam.getLossless());
/*  703 */     setFilters(j2kParam.getFilter());
/*  704 */     setEPH("" + j2kParam.getEPH());
/*  705 */     setSOP("" + j2kParam.getSOP());
/*  706 */     setProgressionName(j2kParam.getProgressionType());
/*  707 */     int[] size = j2kParam.getCodeBlockSize();
/*  708 */     setCodeBlockSize("" + size[0] + " " + size[1]);
/*  709 */     this.enableCT = j2kParam.getComponentTransformation();
/*  710 */     setComponentTransformation("" + this.enableCT); } public J2KImageWriteParamJava() { this.packPacketHeaderInTile = false; this.packPacketHeaderInMain = false; this.packetPerTilePart = 0; this.encodingRate = Double.MAX_VALUE; this.lossless = true; this.componentTransformation = null; this.enableCT = true; this.filters = null; this.decompositionLevel = null; this.guardBits = null; this.quantizationStep = null; this.quantizationType = null; this.startLevelROI = -1; this.alignROI = false; this.ROIs = null; this.codeBlockSize = null; this.bypass = null; this.resetMQ = null; this.terminateOnByte = null; this.causalCXInfo = null;
/*      */     this.codeSegSymbol = null;
/*      */     this.methodForMQTermination = null;
/*      */     this.methodForMQLengthCalc = null;
/*      */     this.precinctPartition = null;
/*      */     this.progressionType = null;
/*      */     this.progressionName = null;
/*      */     this.layers = "0.015 +20 2.0 +10";
/*      */     this.EPH = null;
/*      */     this.SOP = null;
/*  720 */     setSuperProperties(); } public J2KImageWriteParamJava(RenderedImage imgsrc) { this.packPacketHeaderInTile = false; this.packPacketHeaderInMain = false; this.packetPerTilePart = 0; this.encodingRate = Double.MAX_VALUE; this.lossless = true; this.componentTransformation = null; this.enableCT = true; this.filters = null; this.decompositionLevel = null; this.guardBits = null; this.quantizationStep = null; this.quantizationType = null; this.startLevelROI = -1; this.alignROI = false; this.ROIs = null; this.codeBlockSize = null; this.bypass = null; this.resetMQ = null; this.terminateOnByte = null; this.causalCXInfo = null; this.codeSegSymbol = null;
/*      */     this.methodForMQTermination = null;
/*      */     this.methodForMQLengthCalc = null;
/*      */     this.precinctPartition = null;
/*      */     this.progressionType = null;
/*      */     this.progressionName = null;
/*      */     this.layers = "0.015 +20 2.0 +10";
/*      */     this.EPH = null;
/*      */     this.SOP = null;
/*  729 */     setDefaults(imgsrc); } public J2KImageWriteParamJava(Raster raster) { this.packPacketHeaderInTile = false; this.packPacketHeaderInMain = false; this.packetPerTilePart = 0; this.encodingRate = Double.MAX_VALUE; this.lossless = true; this.componentTransformation = null; this.enableCT = true; this.filters = null; this.decompositionLevel = null; this.guardBits = null; this.quantizationStep = null; this.quantizationType = null; this.startLevelROI = -1; this.alignROI = false; this.ROIs = null; this.codeBlockSize = null; this.bypass = null; this.resetMQ = null; this.terminateOnByte = null; this.causalCXInfo = null; this.codeSegSymbol = null;
/*      */     this.methodForMQTermination = null;
/*      */     this.methodForMQLengthCalc = null;
/*      */     this.precinctPartition = null;
/*      */     this.progressionType = null;
/*      */     this.progressionName = null;
/*      */     this.layers = "0.015 +20 2.0 +10";
/*      */     this.EPH = null;
/*      */     this.SOP = null;
/*  738 */     setDefaults(raster); }
/*      */ 
/*      */   
/*      */   private void setSuperProperties() {
/*  742 */     this.canOffsetTiles = true;
/*  743 */     this.canWriteTiles = true;
/*  744 */     this.canOffsetTiles = true;
/*  745 */     this.canWriteProgressive = true;
/*  746 */     this.tilingMode = 2;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void setDefaults(Raster raster) {
/*  752 */     setSuperProperties();
/*      */     
/*  754 */     if (raster != null) {
/*  755 */       this.raster = raster;
/*  756 */       this.tileGridXOffset = raster.getMinX();
/*  757 */       this.tileGridYOffset = raster.getMinY();
/*  758 */       this.tileWidth = raster.getWidth();
/*  759 */       this.tileHeight = raster.getHeight();
/*  760 */       this.tilingSet = true;
/*      */       
/*  762 */       this.numTiles = 1;
/*  763 */       this.numComponents = raster.getSampleModel().getNumBands();
/*      */     } 
/*  765 */     setDefaults();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void setDefaults(RenderedImage imgsrc) {
/*  771 */     setSuperProperties();
/*      */     
/*  773 */     this.tilingMode = 2;
/*      */     
/*  775 */     if (imgsrc != null) {
/*  776 */       this.imgsrc = imgsrc;
/*  777 */       this.tileGridXOffset = imgsrc.getTileGridXOffset();
/*  778 */       this.tileGridYOffset = imgsrc.getTileGridYOffset();
/*  779 */       this.tileWidth = imgsrc.getTileWidth();
/*  780 */       this.tileHeight = imgsrc.getTileHeight();
/*  781 */       this.tilingSet = true;
/*      */       
/*  783 */       this.numTiles = imgsrc.getNumXTiles() * imgsrc.getNumYTiles();
/*  784 */       this.numComponents = imgsrc.getSampleModel().getNumBands();
/*      */     } 
/*  786 */     setDefaults();
/*      */   }
/*      */   
/*      */   private void setDefaults() {
/*  790 */     setROIs((String)null);
/*  791 */     setQuantizationType((String)null);
/*  792 */     setQuantizationStep((String)null);
/*  793 */     setGuardBits((String)null);
/*  794 */     setFilters((String)null);
/*  795 */     setDecompositionLevel((String)null);
/*  796 */     setComponentTransformation((String)null);
/*  797 */     setMethodForMQLengthCalc((String)null);
/*  798 */     setMethodForMQTermination((String)null);
/*  799 */     setCodeSegSymbol((String)null);
/*  800 */     setCausalCXInfo((String)null);
/*  801 */     setTerminateOnByte((String)null);
/*  802 */     setResetMQ((String)null);
/*  803 */     setBypass((String)null);
/*  804 */     setCodeBlockSize((String)null);
/*  805 */     setPrecinctPartition((String)null);
/*  806 */     setSOP((String)null);
/*  807 */     setEPH((String)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setEncodingRate(double rate) {
/*  812 */     this.encodingRate = rate;
/*      */   }
/*      */ 
/*      */   
/*      */   public double getEncodingRate() {
/*  817 */     return this.encodingRate;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setLossless(boolean lossless) {
/*  822 */     this.lossless = lossless;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean getLossless() {
/*  827 */     return this.lossless;
/*      */   }
/*      */   
/*      */   public void setPacketPerTilePart(int packetPerTilePart) {
/*  831 */     if (packetPerTilePart < 0) {
/*  832 */       throw new IllegalArgumentException(I18N.getString("J2KImageWriteParamJava0"));
/*      */     }
/*  834 */     this.packetPerTilePart = packetPerTilePart;
/*  835 */     if (packetPerTilePart > 0) {
/*  836 */       setSOP("true");
/*  837 */       setEPH("true");
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public int getPacketPerTilePart() {
/*  843 */     return this.packetPerTilePart;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setPackPacketHeaderInTile(boolean packPacketHeaderInTile) {
/*  848 */     this.packPacketHeaderInTile = packPacketHeaderInTile;
/*  849 */     if (packPacketHeaderInTile) {
/*  850 */       setSOP("true");
/*  851 */       setEPH("true");
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean getPackPacketHeaderInTile() {
/*  857 */     return this.packPacketHeaderInTile;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setPackPacketHeaderInMain(boolean packPacketHeaderInMain) {
/*  862 */     this.packPacketHeaderInMain = packPacketHeaderInMain;
/*  863 */     if (packPacketHeaderInMain) {
/*  864 */       setSOP("true");
/*  865 */       setEPH("true");
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean getPackPacketHeaderInMain() {
/*  871 */     return this.packPacketHeaderInMain;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setAlignROI(boolean align) {
/*  876 */     this.alignROI = align;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean getAlignROI() {
/*  881 */     return this.alignROI;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setROIs(String values) {
/*  886 */     this.ROIs = new MaxShiftSpec(this.numTiles, this.numComponents, (byte)2, values);
/*      */   }
/*      */ 
/*      */   
/*      */   public MaxShiftSpec getROIs() {
/*  891 */     return this.ROIs;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setQuantizationType(String values) {
/*  896 */     this.quantizationType = new QuantTypeSpec(this.numTiles, this.numComponents, (byte)2, this, values);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QuantTypeSpec getQuantizationType() {
/*  902 */     return this.quantizationType;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setQuantizationStep(String values) {
/*  907 */     this.quantizationStep = new QuantStepSizeSpec(this.numTiles, this.numComponents, (byte)2, this, values);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public QuantStepSizeSpec getQuantizationStep() {
/*  916 */     return this.quantizationStep;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setGuardBits(String values) {
/*  921 */     this.guardBits = new GuardBitsSpec(this.numTiles, this.numComponents, (byte)2, this, values);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public GuardBitsSpec getGuardBits() {
/*  930 */     return this.guardBits;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFilters(String values) {
/*  936 */     if ("w9x7".equals(values)) {
/*  937 */       setQuantizationType("expounded");
/*      */     } else {
/*  939 */       setQuantizationType("reversible");
/*      */     } 
/*  941 */     this.filters = new AnWTFilterSpec(this.numTiles, this.numComponents, (byte)2, this.quantizationType, this, values);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  947 */     setComponentTransformation("" + this.enableCT);
/*      */   }
/*      */ 
/*      */   
/*      */   public AnWTFilterSpec getFilters() {
/*  952 */     return this.filters;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setDecompositionLevel(String values) {
/*  957 */     this.decompositionLevel = new IntegerSpec(this.numTiles, this.numComponents, (byte)2, this, values, "5");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  967 */     setPrecinctPartition((String)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public IntegerSpec getDecompositionLevel() {
/*  972 */     return this.decompositionLevel;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setComponentTransformation(String values) {
/*  978 */     this.componentTransformation = new ForwCompTransfSpec(this.numTiles, this.numComponents, (byte)1, this.filters, this, values);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ForwCompTransfSpec getComponentTransformation() {
/*  989 */     return this.componentTransformation;
/*      */   }
/*      */   
/*      */   public void setMethodForMQLengthCalc(String values) {
/*  993 */     String[] strLcs = { "near_opt", "lazy_good", "lazy" };
/*  994 */     this.methodForMQLengthCalc = new StringSpec(this.numTiles, this.numComponents, (byte)2, "near_opt", strLcs, this, values);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StringSpec getMethodForMQLengthCalc() {
/* 1006 */     return this.methodForMQLengthCalc;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setMethodForMQTermination(String values) {
/* 1011 */     String[] strTerm = { "near_opt", "easy", "predict", "full" };
/* 1012 */     this.methodForMQTermination = new StringSpec(this.numTiles, this.numComponents, (byte)2, "near_opt", strTerm, this, values);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StringSpec getMethodForMQTermination() {
/* 1024 */     return this.methodForMQTermination;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setCodeSegSymbol(String values) {
/* 1029 */     String[] strBoolean = { "true", "false" };
/* 1030 */     this.codeSegSymbol = new StringSpec(this.numTiles, this.numComponents, (byte)2, "false", strBoolean, this, values);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StringSpec getCodeSegSymbol() {
/* 1042 */     return this.codeSegSymbol;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setCausalCXInfo(String values) {
/* 1047 */     String[] strBoolean = { "true", "false" };
/* 1048 */     this.causalCXInfo = new StringSpec(this.numTiles, this.numComponents, (byte)2, "false", strBoolean, this, values);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StringSpec getCausalCXInfo() {
/* 1059 */     return this.causalCXInfo;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setTerminateOnByte(String values) {
/* 1064 */     String[] strBoolean = { "true", "false" };
/* 1065 */     this.terminateOnByte = new StringSpec(this.numTiles, this.numComponents, (byte)2, "false", strBoolean, this, values);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StringSpec getTerminateOnByte() {
/* 1076 */     return this.terminateOnByte;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setResetMQ(String values) {
/* 1081 */     String[] strBoolean = { "true", "false" };
/* 1082 */     this.resetMQ = new StringSpec(this.numTiles, this.numComponents, (byte)2, "false", strBoolean, this, values);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StringSpec getResetMQ() {
/* 1093 */     return this.resetMQ;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setBypass(String values) {
/* 1098 */     String[] strBoolean = { "true", "false" };
/* 1099 */     this.bypass = new StringSpec(this.numTiles, this.numComponents, (byte)2, "false", strBoolean, this, values);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StringSpec getBypass() {
/* 1110 */     return this.bypass;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setCodeBlockSize(String values) {
/* 1115 */     this.codeBlockSize = new CBlkSizeSpec(this.numTiles, this.numComponents, (byte)2, this, values);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CBlkSizeSpec getCodeBlockSize() {
/* 1124 */     return this.codeBlockSize;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setPrecinctPartition(String values) {
/* 1129 */     String[] strBoolean = { "true", "false" };
/* 1130 */     if (this.imgsrc != null) {
/* 1131 */       this.precinctPartition = new PrecinctSizeSpec(this.numTiles, this.numComponents, (byte)2, new RenderedImageSrc(this.imgsrc, this, null), this.decompositionLevel, this, values);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/* 1139 */     else if (this.raster != null) {
/* 1140 */       this.precinctPartition = new PrecinctSizeSpec(this.numTiles, this.numComponents, (byte)2, new RenderedImageSrc(this.raster, this, null), this.decompositionLevel, this, values);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PrecinctSizeSpec getPrecinctPartition() {
/* 1152 */     return this.precinctPartition;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setSOP(String values) {
/* 1157 */     String[] strBoolean = { "true", "false" };
/* 1158 */     this.SOP = new StringSpec(this.numTiles, this.numComponents, (byte)2, "false", strBoolean, this, values);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StringSpec getSOP() {
/* 1169 */     return this.SOP;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setEPH(String values) {
/* 1174 */     String[] strBoolean = { "true", "false" };
/* 1175 */     this.EPH = new StringSpec(this.numTiles, this.numComponents, (byte)2, "false", strBoolean, this, values);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StringSpec getEPH() {
/* 1186 */     return this.EPH;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setProgressionName(String values) {
/* 1191 */     this.progressionName = values;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getProgressionName() {
/* 1196 */     return this.progressionName;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setProgressionType(LayersInfo lyrs, String values) {
/* 1201 */     String[] strBoolean = { "true", "false" };
/* 1202 */     this.progressionType = new ProgressionSpec(this.numTiles, this.numComponents, lyrs.getTotNumLayers(), this.decompositionLevel, (byte)2, this, values);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ProgressionSpec getProgressionType() {
/* 1213 */     return this.progressionType;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setStartLevelROI(int value) {
/* 1218 */     this.startLevelROI = value;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getStartLevelROI() {
/* 1223 */     return this.startLevelROI;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setLayers(String value) {
/* 1228 */     this.layers = value;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getLayers() {
/* 1233 */     return this.layers;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setMinX(int minX) {
/* 1238 */     this.minX = minX;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getMinX() {
/* 1243 */     return this.minX;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setMinY(int minY) {
/* 1248 */     this.minY = minY;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getMinY() {
/* 1253 */     return this.minY;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getNumTiles() {
/* 1258 */     Rectangle sourceRegion = getSourceRegion();
/* 1259 */     if (sourceRegion == null) {
/* 1260 */       if (this.imgsrc != null) {
/* 1261 */         sourceRegion = new Rectangle(this.imgsrc.getMinX(), this.imgsrc.getMinY(), this.imgsrc.getWidth(), this.imgsrc.getHeight());
/*      */       }
/*      */       else {
/*      */         
/* 1265 */         sourceRegion = this.raster.getBounds();
/*      */       } 
/* 1267 */     } else if (this.imgsrc != null) {
/* 1268 */       sourceRegion = sourceRegion.intersection(new Rectangle(this.imgsrc.getMinX(), this.imgsrc.getMinY(), this.imgsrc.getWidth(), this.imgsrc.getHeight()));
/*      */     
/*      */     }
/*      */     else {
/*      */       
/* 1273 */       sourceRegion = sourceRegion.intersection(this.raster.getBounds());
/*      */     } 
/*      */     
/* 1276 */     int scaleX = getSourceXSubsampling();
/* 1277 */     int scaleY = getSourceYSubsampling();
/* 1278 */     int xOffset = getSubsamplingXOffset();
/* 1279 */     int yOffset = getSubsamplingYOffset();
/*      */     
/* 1281 */     int w = (sourceRegion.width - xOffset + scaleX - 1) / scaleX;
/* 1282 */     int h = (sourceRegion.height - yOffset + scaleY - 1) / scaleY;
/*      */     
/* 1284 */     this.minX = (sourceRegion.x + xOffset) / scaleX;
/* 1285 */     this.minY = (sourceRegion.y + yOffset) / scaleY;
/*      */     
/* 1287 */     this.numTiles = (int)((Math.floor(((this.minX + w + this.tileWidth) - 1.0D) / this.tileWidth) - Math.floor(this.minX / this.tileWidth)) * (Math.floor(((this.minY + h + this.tileHeight) - 1.0D) / this.tileHeight) - Math.floor(this.minY / this.tileHeight)));
/*      */ 
/*      */ 
/*      */     
/* 1291 */     this.tileGridXOffset += (this.minX - this.tileGridXOffset) / this.tileWidth * this.tileWidth;
/* 1292 */     this.tileGridYOffset += (this.minY - this.tileGridYOffset) / this.tileHeight * this.tileHeight;
/*      */     
/* 1294 */     return this.numTiles;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getNumComponents() {
/* 1299 */     return this.numComponents;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSourceBands(int[] bands) {
/* 1307 */     super.setSourceBands(bands);
/* 1308 */     if (bands != null) {
/* 1309 */       this.numComponents = bands.length;
/* 1310 */       setDefaults();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTiling(int tw, int th, int xOff, int yOff) {
/* 1319 */     super.setTiling(tw, th, xOff, yOff);
/* 1320 */     getNumTiles();
/* 1321 */     setDefaults();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSourceSubsampling(int sx, int sy, int xOff, int yOff) {
/* 1329 */     super.setSourceSubsampling(sx, sy, xOff, yOff);
/* 1330 */     getNumTiles();
/* 1331 */     setDefaults();
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/jpeg2000/J2KImageWriteParamJava.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */