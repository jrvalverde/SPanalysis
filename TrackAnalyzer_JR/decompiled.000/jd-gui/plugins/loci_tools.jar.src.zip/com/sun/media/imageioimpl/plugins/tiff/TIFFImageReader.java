/*      */ package com.sun.media.imageioimpl.plugins.tiff;
/*      */ 
/*      */ import com.sun.media.imageio.plugins.tiff.BaselineTIFFTagSet;
/*      */ import com.sun.media.imageio.plugins.tiff.TIFFColorConverter;
/*      */ import com.sun.media.imageio.plugins.tiff.TIFFDecompressor;
/*      */ import com.sun.media.imageio.plugins.tiff.TIFFField;
/*      */ import com.sun.media.imageio.plugins.tiff.TIFFImageReadParam;
/*      */ import com.sun.media.imageioimpl.common.ImageUtil;
/*      */ import java.awt.Point;
/*      */ import java.awt.Rectangle;
/*      */ import java.awt.color.ColorSpace;
/*      */ import java.awt.color.ICC_ColorSpace;
/*      */ import java.awt.color.ICC_Profile;
/*      */ import java.awt.image.BufferedImage;
/*      */ import java.awt.image.ColorModel;
/*      */ import java.awt.image.ComponentColorModel;
/*      */ import java.awt.image.Raster;
/*      */ import java.awt.image.RenderedImage;
/*      */ import java.awt.image.SampleModel;
/*      */ import java.io.IOException;
/*      */ import java.nio.ByteOrder;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import javax.imageio.IIOException;
/*      */ import javax.imageio.ImageIO;
/*      */ import javax.imageio.ImageReadParam;
/*      */ import javax.imageio.ImageReader;
/*      */ import javax.imageio.ImageTypeSpecifier;
/*      */ import javax.imageio.metadata.IIOMetadata;
/*      */ import javax.imageio.spi.ImageReaderSpi;
/*      */ import javax.imageio.stream.ImageInputStream;
/*      */ import org.w3c.dom.Node;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class TIFFImageReader
/*      */   extends ImageReader
/*      */ {
/*      */   private static final boolean DEBUG = false;
/*  133 */   ImageInputStream stream = null;
/*      */ 
/*      */   
/*      */   boolean gotHeader = false;
/*      */   
/*  138 */   ImageReadParam imageReadParam = getDefaultReadParam();
/*      */ 
/*      */   
/*  141 */   TIFFStreamMetadata streamMetadata = null;
/*      */ 
/*      */   
/*  144 */   int currIndex = -1;
/*      */ 
/*      */   
/*  147 */   TIFFImageMetadata imageMetadata = null;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  152 */   List imageStartPosition = new ArrayList();
/*      */ 
/*      */   
/*  155 */   int numImages = -1;
/*      */ 
/*      */ 
/*      */   
/*  159 */   HashMap imageTypeMap = new HashMap<Object, Object>();
/*      */   
/*  161 */   BufferedImage theImage = null;
/*      */   
/*  163 */   int width = -1;
/*  164 */   int height = -1;
/*  165 */   int numBands = -1;
/*  166 */   int tileOrStripWidth = -1, tileOrStripHeight = -1;
/*      */   
/*  168 */   int planarConfiguration = 1;
/*      */   
/*  170 */   int rowsDone = 0;
/*      */   
/*      */   int compression;
/*      */   
/*      */   int photometricInterpretation;
/*      */   int samplesPerPixel;
/*      */   int[] sampleFormat;
/*      */   int[] bitsPerSample;
/*      */   int[] extraSamples;
/*      */   char[] colorMap;
/*      */   int sourceXOffset;
/*      */   int sourceYOffset;
/*      */   int srcXSubsampling;
/*      */   int srcYSubsampling;
/*      */   int dstWidth;
/*      */   int dstHeight;
/*      */   int dstMinX;
/*      */   int dstMinY;
/*      */   int dstXOffset;
/*      */   int dstYOffset;
/*      */   int tilesAcross;
/*      */   int tilesDown;
/*      */   int pixelsRead;
/*      */   int pixelsToRead;
/*      */   private int[] sourceBands;
/*      */   private int[] destinationBands;
/*      */   private TIFFDecompressor decompressor;
/*      */   
/*      */   public TIFFImageReader(ImageReaderSpi originatingProvider) {
/*  199 */     super(originatingProvider);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setInput(Object input, boolean seekForwardOnly, boolean ignoreMetadata) {
/*  205 */     super.setInput(input, seekForwardOnly, ignoreMetadata);
/*      */ 
/*      */     
/*  208 */     resetLocal();
/*      */     
/*  210 */     if (input != null) {
/*  211 */       if (!(input instanceof ImageInputStream)) {
/*  212 */         throw new IllegalArgumentException("input not an ImageInputStream!");
/*      */       }
/*      */       
/*  215 */       this.stream = (ImageInputStream)input;
/*      */     } else {
/*  217 */       this.stream = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void readHeader() throws IIOException {
/*  224 */     if (this.gotHeader) {
/*      */       return;
/*      */     }
/*  227 */     if (this.stream == null) {
/*  228 */       throw new IllegalStateException("Input not set!");
/*      */     }
/*      */ 
/*      */     
/*  232 */     this.streamMetadata = new TIFFStreamMetadata();
/*      */     
/*      */     try {
/*  235 */       int byteOrder = this.stream.readUnsignedShort();
/*  236 */       if (byteOrder == 19789) {
/*  237 */         this.streamMetadata.byteOrder = ByteOrder.BIG_ENDIAN;
/*  238 */         this.stream.setByteOrder(ByteOrder.BIG_ENDIAN);
/*  239 */       } else if (byteOrder == 18761) {
/*  240 */         this.streamMetadata.byteOrder = ByteOrder.LITTLE_ENDIAN;
/*  241 */         this.stream.setByteOrder(ByteOrder.LITTLE_ENDIAN);
/*      */       } else {
/*  243 */         processWarningOccurred("Bad byte order in header, assuming little-endian");
/*      */         
/*  245 */         this.streamMetadata.byteOrder = ByteOrder.LITTLE_ENDIAN;
/*  246 */         this.stream.setByteOrder(ByteOrder.LITTLE_ENDIAN);
/*      */       } 
/*      */       
/*  249 */       int magic = this.stream.readUnsignedShort();
/*  250 */       if (magic != 42) {
/*  251 */         processWarningOccurred("Bad magic number in header, continuing");
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  256 */       long offset = this.stream.readUnsignedInt();
/*  257 */       this.imageStartPosition.add(new Long(offset));
/*  258 */       this.stream.seek(offset);
/*  259 */     } catch (IOException e) {
/*  260 */       throw new IIOException("I/O error reading header!", e);
/*      */     } 
/*      */     
/*  263 */     this.gotHeader = true;
/*      */   }
/*      */   
/*      */   private int locateImage(int imageIndex) throws IIOException {
/*  267 */     readHeader();
/*      */ 
/*      */     
/*      */     try {
/*  271 */       int index = Math.min(imageIndex, this.imageStartPosition.size() - 1);
/*      */ 
/*      */       
/*  274 */       Long l = this.imageStartPosition.get(index);
/*  275 */       this.stream.seek(l.longValue());
/*      */ 
/*      */       
/*  278 */       while (index < imageIndex) {
/*  279 */         int count = this.stream.readUnsignedShort();
/*  280 */         this.stream.skipBytes(12 * count);
/*      */         
/*  282 */         long offset = this.stream.readUnsignedInt();
/*  283 */         if (offset == 0L) {
/*  284 */           return index;
/*      */         }
/*      */         
/*  287 */         this.imageStartPosition.add(new Long(offset));
/*  288 */         this.stream.seek(offset);
/*  289 */         index++;
/*      */       } 
/*  291 */     } catch (IOException e) {
/*  292 */       throw new IIOException("Couldn't seek!", e);
/*      */     } 
/*      */     
/*  295 */     if (this.currIndex != imageIndex) {
/*  296 */       this.imageMetadata = null;
/*      */     }
/*  298 */     this.currIndex = imageIndex;
/*  299 */     return imageIndex;
/*      */   }
/*      */   
/*      */   public int getNumImages(boolean allowSearch) throws IOException {
/*  303 */     if (this.stream == null) {
/*  304 */       throw new IllegalStateException("Input not set!");
/*      */     }
/*  306 */     if (this.seekForwardOnly && allowSearch) {
/*  307 */       throw new IllegalStateException("seekForwardOnly and allowSearch can't both be true!");
/*      */     }
/*      */ 
/*      */     
/*  311 */     if (this.numImages > 0) {
/*  312 */       return this.numImages;
/*      */     }
/*  314 */     if (allowSearch) {
/*  315 */       this.numImages = locateImage(2147483647) + 1;
/*      */     }
/*  317 */     return this.numImages;
/*      */   }
/*      */   
/*      */   public IIOMetadata getStreamMetadata() throws IIOException {
/*  321 */     readHeader();
/*  322 */     return this.streamMetadata;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void checkIndex(int imageIndex) {
/*  328 */     if (imageIndex < this.minIndex) {
/*  329 */       throw new IndexOutOfBoundsException("imageIndex < minIndex!");
/*      */     }
/*  331 */     if (this.seekForwardOnly) {
/*  332 */       this.minIndex = imageIndex;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void seekToImage(int imageIndex) throws IIOException {
/*  339 */     checkIndex(imageIndex);
/*      */     
/*  341 */     int index = locateImage(imageIndex);
/*  342 */     if (index != imageIndex) {
/*  343 */       throw new IndexOutOfBoundsException("imageIndex out of bounds!");
/*      */     }
/*      */     
/*  346 */     readMetadata();
/*      */     
/*  348 */     initializeFromMetadata();
/*      */   }
/*      */ 
/*      */   
/*      */   private void readMetadata() throws IIOException {
/*  353 */     if (this.stream == null) {
/*  354 */       throw new IllegalStateException("Input not set!");
/*      */     }
/*      */     
/*  357 */     if (this.imageMetadata != null) {
/*      */       return;
/*      */     }
/*      */     
/*      */     try {
/*      */       List<BaselineTIFFTagSet> tagSets;
/*  363 */       if (this.imageReadParam instanceof TIFFImageReadParam) {
/*  364 */         tagSets = ((TIFFImageReadParam)this.imageReadParam).getAllowedTagSets();
/*      */       } else {
/*      */         
/*  367 */         tagSets = new ArrayList(1);
/*  368 */         tagSets.add(BaselineTIFFTagSet.getInstance());
/*      */       } 
/*      */       
/*  371 */       this.imageMetadata = new TIFFImageMetadata(tagSets);
/*  372 */       this.imageMetadata.initializeFromStream(this.stream, this.ignoreMetadata);
/*  373 */     } catch (IIOException iioe) {
/*  374 */       throw iioe;
/*  375 */     } catch (IOException ioe) {
/*  376 */       throw new IIOException("I/O error reading image metadata!", ioe);
/*      */     } 
/*      */   }
/*      */   
/*      */   private int getWidth() {
/*  381 */     return this.width;
/*      */   }
/*      */   
/*      */   private int getHeight() {
/*  385 */     return this.height;
/*      */   }
/*      */   
/*      */   private int getNumBands() {
/*  389 */     return this.numBands;
/*      */   }
/*      */ 
/*      */   
/*      */   private int getTileOrStripWidth() {
/*  394 */     TIFFField f = this.imageMetadata.getTIFFField(322);
/*      */     
/*  396 */     return (f == null) ? getWidth() : f.getAsInt(0);
/*      */   }
/*      */ 
/*      */   
/*      */   private int getTileOrStripHeight() {
/*  401 */     TIFFField f = this.imageMetadata.getTIFFField(323);
/*      */     
/*  403 */     if (f != null) {
/*  404 */       return f.getAsInt(0);
/*      */     }
/*      */     
/*  407 */     f = this.imageMetadata.getTIFFField(278);
/*      */     
/*  409 */     int h = (f == null) ? -1 : f.getAsInt(0);
/*  410 */     return (h == -1) ? getHeight() : h;
/*      */   }
/*      */   
/*      */   private int getPlanarConfiguration() {
/*  414 */     TIFFField f = this.imageMetadata.getTIFFField(284);
/*      */     
/*  416 */     if (f != null) {
/*  417 */       int planarConfigurationValue = f.getAsInt(0);
/*  418 */       if (planarConfigurationValue == 2)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  424 */         if (getCompression() == 6 && this.imageMetadata.getTIFFField(513) != null) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  430 */           processWarningOccurred("PlanarConfiguration \"Planar\" value inconsistent with JPEGInterchangeFormat; resetting to \"Chunky\".");
/*  431 */           planarConfigurationValue = 1;
/*      */         } else {
/*      */           
/*  434 */           TIFFField offsetField = this.imageMetadata.getTIFFField(324);
/*      */           
/*  436 */           if (offsetField == null) {
/*      */             
/*  438 */             offsetField = this.imageMetadata.getTIFFField(273);
/*      */             
/*  440 */             int tw = getTileOrStripWidth();
/*  441 */             int th = getTileOrStripHeight();
/*  442 */             int tAcross = (getWidth() + tw - 1) / tw;
/*  443 */             int tDown = (getHeight() + th - 1) / th;
/*  444 */             int tilesPerImage = tAcross * tDown;
/*  445 */             long[] offsetArray = offsetField.getAsLongs();
/*  446 */             if (offsetArray != null && offsetArray.length == tilesPerImage)
/*      */             {
/*      */ 
/*      */ 
/*      */               
/*  451 */               processWarningOccurred("PlanarConfiguration \"Planar\" value inconsistent with TileOffsets field value count; resetting to \"Chunky\".");
/*  452 */               planarConfigurationValue = 1;
/*      */             }
/*      */           
/*      */           } else {
/*      */             
/*  457 */             int rowsPerStrip = getTileOrStripHeight();
/*  458 */             int stripsPerImage = (getHeight() + rowsPerStrip - 1) / rowsPerStrip;
/*      */             
/*  460 */             long[] offsetArray = offsetField.getAsLongs();
/*  461 */             if (offsetArray != null && offsetArray.length == stripsPerImage) {
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*  466 */               processWarningOccurred("PlanarConfiguration \"Planar\" value inconsistent with StripOffsets field value count; resetting to \"Chunky\".");
/*  467 */               planarConfigurationValue = 1;
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       }
/*      */       
/*  473 */       return planarConfigurationValue;
/*      */     } 
/*      */     
/*  476 */     return 1;
/*      */   }
/*      */   
/*      */   private long getTileOrStripOffset(int tileIndex) throws IIOException {
/*  480 */     TIFFField f = this.imageMetadata.getTIFFField(324);
/*      */     
/*  482 */     if (f == null) {
/*  483 */       f = this.imageMetadata.getTIFFField(273);
/*      */     }
/*  485 */     if (f == null) {
/*  486 */       f = this.imageMetadata.getTIFFField(513);
/*      */     }
/*      */     
/*  489 */     if (f == null) {
/*  490 */       throw new IIOException("Missing required strip or tile offsets field.");
/*      */     }
/*      */ 
/*      */     
/*  494 */     return f.getAsLong(tileIndex);
/*      */   }
/*      */   private long getTileOrStripByteCount(int tileIndex) throws IOException {
/*      */     long tileOrStripByteCount;
/*  498 */     TIFFField f = this.imageMetadata.getTIFFField(325);
/*      */     
/*  500 */     if (f == null) {
/*  501 */       f = this.imageMetadata.getTIFFField(279);
/*      */     }
/*      */     
/*  504 */     if (f == null) {
/*  505 */       f = this.imageMetadata.getTIFFField(514);
/*      */     }
/*      */ 
/*      */     
/*  509 */     if (f != null) {
/*  510 */       tileOrStripByteCount = f.getAsLong(tileIndex);
/*      */     } else {
/*  512 */       processWarningOccurred("TIFF directory contains neither StripByteCounts nor TileByteCounts field: attempting to calculate from strip or tile width and height.");
/*      */ 
/*      */ 
/*      */       
/*  516 */       int bitsPerPixel = this.bitsPerSample[0];
/*  517 */       for (int i = 1; i < this.samplesPerPixel; i++) {
/*  518 */         bitsPerPixel += this.bitsPerSample[i];
/*      */       }
/*  520 */       int bytesPerRow = (getTileOrStripWidth() * bitsPerPixel + 7) / 8;
/*  521 */       tileOrStripByteCount = (bytesPerRow * getTileOrStripHeight());
/*      */ 
/*      */       
/*  524 */       long streamLength = this.stream.length();
/*  525 */       if (streamLength != -1L) {
/*  526 */         tileOrStripByteCount = Math.min(tileOrStripByteCount, streamLength - getTileOrStripOffset(tileIndex));
/*      */       }
/*      */       else {
/*      */         
/*  530 */         processWarningOccurred("Stream length is unknown: cannot clamp estimated strip or tile byte count to EOF.");
/*      */       } 
/*      */     } 
/*      */     
/*  534 */     return tileOrStripByteCount;
/*      */   }
/*      */   
/*      */   private int getCompression() {
/*  538 */     TIFFField f = this.imageMetadata.getTIFFField(259);
/*      */     
/*  540 */     if (f == null) {
/*  541 */       return 1;
/*      */     }
/*  543 */     return f.getAsInt(0);
/*      */   }
/*      */ 
/*      */   
/*      */   public int getWidth(int imageIndex) throws IOException {
/*  548 */     seekToImage(imageIndex);
/*  549 */     return getWidth();
/*      */   }
/*      */   
/*      */   public int getHeight(int imageIndex) throws IOException {
/*  553 */     seekToImage(imageIndex);
/*  554 */     return getHeight();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void initializeFromMetadata() {
/*  578 */     TIFFField f = this.imageMetadata.getTIFFField(259);
/*  579 */     if (f == null) {
/*  580 */       processWarningOccurred("Compression field is missing; assuming no compression");
/*      */       
/*  582 */       this.compression = 1;
/*      */     } else {
/*  584 */       this.compression = f.getAsInt(0);
/*      */     } 
/*      */ 
/*      */     
/*  588 */     boolean isMissingDimension = false;
/*      */ 
/*      */     
/*  591 */     f = this.imageMetadata.getTIFFField(256);
/*  592 */     if (f != null) {
/*  593 */       this.width = f.getAsInt(0);
/*      */     } else {
/*  595 */       processWarningOccurred("ImageWidth field is missing.");
/*  596 */       isMissingDimension = true;
/*      */     } 
/*      */ 
/*      */     
/*  600 */     f = this.imageMetadata.getTIFFField(257);
/*  601 */     if (f != null) {
/*  602 */       this.height = f.getAsInt(0);
/*      */     } else {
/*  604 */       processWarningOccurred("ImageLength field is missing.");
/*  605 */       isMissingDimension = true;
/*      */     } 
/*      */ 
/*      */     
/*  609 */     f = this.imageMetadata.getTIFFField(277);
/*      */     
/*  611 */     if (f != null) {
/*  612 */       this.samplesPerPixel = f.getAsInt(0);
/*      */     } else {
/*  614 */       this.samplesPerPixel = 1;
/*  615 */       isMissingDimension = true;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  620 */     int defaultBitDepth = 1;
/*  621 */     if (isMissingDimension && (f = this.imageMetadata.getTIFFField(513)) != null) {
/*      */       
/*  623 */       Iterator<ImageReader> iter = ImageIO.getImageReadersByFormatName("JPEG");
/*  624 */       if (iter != null && iter.hasNext()) {
/*  625 */         ImageReader jreader = iter.next();
/*      */         try {
/*  627 */           this.stream.mark();
/*  628 */           this.stream.seek(f.getAsLong(0));
/*  629 */           jreader.setInput(this.stream);
/*  630 */           if (this.imageMetadata.getTIFFField(256) == null) {
/*  631 */             this.width = jreader.getWidth(0);
/*      */           }
/*  633 */           if (this.imageMetadata.getTIFFField(257) == null) {
/*  634 */             this.height = jreader.getHeight(0);
/*      */           }
/*  636 */           ImageTypeSpecifier imageType = jreader.getRawImageType(0);
/*  637 */           if (this.imageMetadata.getTIFFField(277) == null) {
/*  638 */             this.samplesPerPixel = imageType.getSampleModel().getNumBands();
/*      */           }
/*      */           
/*  641 */           this.stream.reset();
/*  642 */           defaultBitDepth = imageType.getColorModel().getComponentSize(0);
/*      */         }
/*  644 */         catch (IOException e) {}
/*      */ 
/*      */         
/*  647 */         jreader.dispose();
/*      */       } 
/*      */     } 
/*      */     
/*  651 */     if (this.samplesPerPixel < 1) {
/*  652 */       processWarningOccurred("Samples per pixel < 1!");
/*      */     }
/*      */ 
/*      */     
/*  656 */     this.numBands = this.samplesPerPixel;
/*      */ 
/*      */     
/*  659 */     this.colorMap = null;
/*  660 */     f = this.imageMetadata.getTIFFField(320);
/*  661 */     if (f != null)
/*      */     {
/*  663 */       this.colorMap = f.getAsChars();
/*      */     }
/*      */ 
/*      */     
/*  667 */     f = this.imageMetadata.getTIFFField(262);
/*      */     
/*  669 */     if (f == null) {
/*  670 */       if (this.compression == 2 || this.compression == 3 || this.compression == 4) {
/*      */ 
/*      */         
/*  673 */         processWarningOccurred("PhotometricInterpretation field is missing; assuming WhiteIsZero");
/*      */ 
/*      */         
/*  676 */         this.photometricInterpretation = 0;
/*      */       }
/*  678 */       else if (this.colorMap != null) {
/*  679 */         this.photometricInterpretation = 3;
/*      */       }
/*  681 */       else if (this.samplesPerPixel == 3 || this.samplesPerPixel == 4) {
/*  682 */         this.photometricInterpretation = 2;
/*      */       } else {
/*      */         
/*  685 */         processWarningOccurred("PhotometricInterpretation field is missing; assuming BlackIsZero");
/*      */ 
/*      */         
/*  688 */         this.photometricInterpretation = 1;
/*      */       } 
/*      */     } else {
/*      */       
/*  692 */       this.photometricInterpretation = f.getAsInt(0);
/*      */     } 
/*      */ 
/*      */     
/*  696 */     boolean replicateFirst = false;
/*  697 */     int first = -1;
/*      */     
/*  699 */     f = this.imageMetadata.getTIFFField(339);
/*  700 */     this.sampleFormat = new int[this.samplesPerPixel];
/*  701 */     replicateFirst = false;
/*  702 */     if (f == null) {
/*  703 */       replicateFirst = true;
/*  704 */       first = 4;
/*  705 */     } else if (f.getCount() != this.samplesPerPixel) {
/*  706 */       replicateFirst = true;
/*  707 */       first = f.getAsInt(0);
/*      */     } 
/*      */     int i;
/*  710 */     for (i = 0; i < this.samplesPerPixel; i++) {
/*  711 */       this.sampleFormat[i] = replicateFirst ? first : f.getAsInt(i);
/*  712 */       if (this.sampleFormat[i] != 1 && this.sampleFormat[i] != 2 && this.sampleFormat[i] != 3 && this.sampleFormat[i] != 4) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  720 */         processWarningOccurred("Illegal value for SAMPLE_FORMAT, assuming SAMPLE_FORMAT_UNDEFINED");
/*      */         
/*  722 */         this.sampleFormat[i] = 4;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  727 */     f = this.imageMetadata.getTIFFField(258);
/*  728 */     this.bitsPerSample = new int[this.samplesPerPixel];
/*  729 */     replicateFirst = false;
/*  730 */     if (f == null) {
/*  731 */       replicateFirst = true;
/*  732 */       first = defaultBitDepth;
/*  733 */     } else if (f.getCount() != this.samplesPerPixel) {
/*  734 */       replicateFirst = true;
/*  735 */       first = f.getAsInt(0);
/*      */     } 
/*      */     
/*  738 */     for (i = 0; i < this.samplesPerPixel; i++)
/*      */     {
/*  740 */       this.bitsPerSample[i] = replicateFirst ? first : f.getAsInt(i);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  749 */     this.extraSamples = null;
/*  750 */     f = this.imageMetadata.getTIFFField(338);
/*  751 */     if (f != null) {
/*  752 */       this.extraSamples = f.getAsInts();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Iterator getImageTypes(int imageIndex) throws IIOException {
/*      */     List<ImageTypeSpecifier> l;
/*  767 */     Integer imageIndexInteger = new Integer(imageIndex);
/*  768 */     if (this.imageTypeMap.containsKey(imageIndexInteger)) {
/*      */       
/*  770 */       l = (List)this.imageTypeMap.get(imageIndexInteger);
/*      */     } else {
/*      */       
/*  773 */       l = new ArrayList(1);
/*      */ 
/*      */ 
/*      */       
/*  777 */       seekToImage(imageIndex);
/*  778 */       ImageTypeSpecifier itsRaw = TIFFDecompressor.getRawImageTypeSpecifier(this.photometricInterpretation, this.compression, this.samplesPerPixel, this.bitsPerSample, this.sampleFormat, this.extraSamples, this.colorMap);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  789 */       TIFFField iccProfileField = this.imageMetadata.getTIFFField(34675);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  794 */       if (iccProfileField != null && itsRaw.getColorModel() instanceof ComponentColorModel) {
/*      */ 
/*      */         
/*  797 */         byte[] iccProfileValue = iccProfileField.getAsBytes();
/*  798 */         ICC_Profile iccProfile = ICC_Profile.getInstance(iccProfileValue);
/*      */         
/*  800 */         ICC_ColorSpace iccColorSpace = new ICC_ColorSpace(iccProfile);
/*      */ 
/*      */ 
/*      */         
/*  804 */         ColorModel cmRaw = itsRaw.getColorModel();
/*  805 */         ColorSpace csRaw = cmRaw.getColorSpace();
/*  806 */         SampleModel smRaw = itsRaw.getSampleModel();
/*      */ 
/*      */ 
/*      */         
/*  810 */         int numBands = smRaw.getNumBands();
/*  811 */         int numComponents = iccColorSpace.getNumComponents();
/*      */ 
/*      */ 
/*      */         
/*  815 */         if (numBands == numComponents || numBands == numComponents + 1) {
/*      */ 
/*      */           
/*  818 */           boolean hasAlpha = (numComponents != numBands);
/*  819 */           boolean isAlphaPre = (hasAlpha && cmRaw.isAlphaPremultiplied());
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  824 */           ColorModel iccColorModel = new ComponentColorModel(iccColorSpace, cmRaw.getComponentSize(), hasAlpha, isAlphaPre, cmRaw.getTransparency(), cmRaw.getTransferType());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  837 */           l.add(new ImageTypeSpecifier(iccColorModel, smRaw));
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  842 */           if (csRaw.getType() == iccColorSpace.getType() && csRaw.getNumComponents() == iccColorSpace.getNumComponents())
/*      */           {
/*      */             
/*  845 */             l.add(itsRaw);
/*      */           }
/*      */         } else {
/*      */           
/*  849 */           l.add(itsRaw);
/*      */         } 
/*      */       } else {
/*      */         
/*  853 */         l.add(itsRaw);
/*      */       } 
/*      */ 
/*      */       
/*  857 */       this.imageTypeMap.put(imageIndexInteger, l);
/*      */     } 
/*      */     
/*  860 */     return l.iterator();
/*      */   }
/*      */   
/*      */   public IIOMetadata getImageMetadata(int imageIndex) throws IIOException {
/*  864 */     seekToImage(imageIndex);
/*  865 */     TIFFImageMetadata im = new TIFFImageMetadata(this.imageMetadata.getRootIFD().getTagSetList());
/*      */     
/*  867 */     Node root = this.imageMetadata.getAsTree("com_sun_media_imageio_plugins_tiff_image_1.0");
/*      */     
/*  869 */     im.setFromTree("com_sun_media_imageio_plugins_tiff_image_1.0", root);
/*  870 */     return im;
/*      */   }
/*      */   
/*      */   public IIOMetadata getStreamMetadata(int imageIndex) throws IIOException {
/*  874 */     readHeader();
/*  875 */     TIFFStreamMetadata sm = new TIFFStreamMetadata();
/*  876 */     Node root = sm.getAsTree("com_sun_media_imageio_plugins_tiff_stream_1.0");
/*  877 */     sm.setFromTree("com_sun_media_imageio_plugins_tiff_stream_1.0", root);
/*  878 */     return sm;
/*      */   }
/*      */   
/*      */   public boolean isRandomAccessEasy(int imageIndex) throws IOException {
/*  882 */     if (this.currIndex != -1) {
/*  883 */       seekToImage(this.currIndex);
/*  884 */       return (getCompression() == 1);
/*      */     } 
/*  886 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean readSupportsThumbnails() {
/*  893 */     return false;
/*      */   }
/*      */   
/*      */   public boolean hasThumbnails(int imageIndex) {
/*  897 */     return false;
/*      */   }
/*      */   
/*      */   public int getNumThumbnails(int imageIndex) throws IOException {
/*  901 */     return 0;
/*      */   }
/*      */   
/*      */   public ImageReadParam getDefaultReadParam() {
/*  905 */     return (ImageReadParam)new TIFFImageReadParam();
/*      */   }
/*      */   
/*      */   public boolean isImageTiled(int imageIndex) throws IOException {
/*  909 */     seekToImage(imageIndex);
/*      */     
/*  911 */     TIFFField f = this.imageMetadata.getTIFFField(322);
/*      */     
/*  913 */     return (f != null);
/*      */   }
/*      */   
/*      */   public int getTileWidth(int imageIndex) throws IOException {
/*  917 */     seekToImage(imageIndex);
/*  918 */     return getTileOrStripWidth();
/*      */   }
/*      */   
/*      */   public int getTileHeight(int imageIndex) throws IOException {
/*  922 */     seekToImage(imageIndex);
/*  923 */     return getTileOrStripHeight();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public BufferedImage readTile(int imageIndex, int tileX, int tileY) throws IOException {
/*  929 */     int w = getWidth(imageIndex);
/*  930 */     int h = getHeight(imageIndex);
/*  931 */     int tw = getTileWidth(imageIndex);
/*  932 */     int th = getTileHeight(imageIndex);
/*      */     
/*  934 */     int x = tw * tileX;
/*  935 */     int y = th * tileY;
/*      */     
/*  937 */     if (tileX < 0 || tileY < 0 || x >= w || y >= h) {
/*  938 */       throw new IllegalArgumentException("Tile indices are out of bounds!");
/*      */     }
/*      */ 
/*      */     
/*  942 */     if (x + tw > w) {
/*  943 */       tw = w - x;
/*      */     }
/*      */     
/*  946 */     if (y + th > h) {
/*  947 */       th = h - y;
/*      */     }
/*      */     
/*  950 */     ImageReadParam param = getDefaultReadParam();
/*  951 */     Rectangle tileRect = new Rectangle(x, y, tw, th);
/*  952 */     param.setSourceRegion(tileRect);
/*      */     
/*  954 */     return read(imageIndex, param);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean canReadRaster() {
/*  959 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Raster readRaster(int imageIndex, ImageReadParam param) throws IOException {
/*  965 */     throw new UnsupportedOperationException();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int ifloor(int num, int den) {
/*  980 */     if (num < 0) {
/*  981 */       num -= den - 1;
/*      */     }
/*  983 */     return num / den;
/*      */   }
/*      */ 
/*      */   
/*      */   private static int iceil(int num, int den) {
/*  988 */     if (num > 0) {
/*  989 */       num += den - 1;
/*      */     }
/*  991 */     return num / den;
/*      */   }
/*      */ 
/*      */   
/*      */   private void prepareRead(int imageIndex, ImageReadParam param) throws IOException {
/*  996 */     if (this.stream == null) {
/*  997 */       throw new IllegalStateException("Input not set!");
/*      */     }
/*      */ 
/*      */     
/* 1001 */     if (param == null) {
/* 1002 */       param = getDefaultReadParam();
/*      */     }
/*      */     
/* 1005 */     this.imageReadParam = param;
/*      */     
/* 1007 */     seekToImage(imageIndex);
/*      */     
/* 1009 */     this.tileOrStripWidth = getTileOrStripWidth();
/* 1010 */     this.tileOrStripHeight = getTileOrStripHeight();
/* 1011 */     this.planarConfiguration = getPlanarConfiguration();
/*      */     
/* 1013 */     this.sourceBands = param.getSourceBands();
/* 1014 */     if (this.sourceBands == null) {
/* 1015 */       this.sourceBands = new int[this.numBands];
/* 1016 */       for (int j = 0; j < this.numBands; j++) {
/* 1017 */         this.sourceBands[j] = j;
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 1022 */     Iterator imageTypes = getImageTypes(imageIndex);
/* 1023 */     ImageTypeSpecifier theImageType = ImageUtil.getDestinationType(param, imageTypes);
/*      */ 
/*      */     
/* 1026 */     int destNumBands = theImageType.getSampleModel().getNumBands();
/*      */     
/* 1028 */     this.destinationBands = param.getDestinationBands();
/* 1029 */     if (this.destinationBands == null) {
/* 1030 */       this.destinationBands = new int[destNumBands];
/* 1031 */       for (int j = 0; j < destNumBands; j++) {
/* 1032 */         this.destinationBands[j] = j;
/*      */       }
/*      */     } 
/*      */     
/* 1036 */     if (this.sourceBands.length != this.destinationBands.length) {
/* 1037 */       throw new IllegalArgumentException("sourceBands.length != destinationBands.length");
/*      */     }
/*      */ 
/*      */     
/* 1041 */     for (int i = 0; i < this.sourceBands.length; i++) {
/* 1042 */       int sb = this.sourceBands[i];
/* 1043 */       if (sb < 0 || sb >= this.numBands) {
/* 1044 */         throw new IllegalArgumentException("Source band out of range!");
/*      */       }
/*      */       
/* 1047 */       int db = this.destinationBands[i];
/* 1048 */       if (db < 0 || db >= destNumBands) {
/* 1049 */         throw new IllegalArgumentException("Destination band out of range!");
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RenderedImage readAsRenderedImage(int imageIndex, ImageReadParam param) throws IOException {
/* 1058 */     prepareRead(imageIndex, param);
/* 1059 */     return new TIFFRenderedImage(this, imageIndex, this.imageReadParam, this.width, this.height);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void decodeTile(int ti, int tj, int band) throws IOException {
/* 1069 */     Rectangle tileRect = new Rectangle(ti * this.tileOrStripWidth, tj * this.tileOrStripHeight, this.tileOrStripWidth, this.tileOrStripHeight);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1076 */     if (!isImageTiled(this.currIndex)) {
/* 1077 */       tileRect = tileRect.intersection(new Rectangle(0, 0, this.width, this.height));
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1082 */     if (tileRect.width <= 0 || tileRect.height <= 0) {
/*      */       return;
/*      */     }
/*      */     
/* 1086 */     int srcMinX = tileRect.x;
/* 1087 */     int srcMinY = tileRect.y;
/* 1088 */     int srcWidth = tileRect.width;
/* 1089 */     int srcHeight = tileRect.height;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1094 */     this.dstMinX = iceil(srcMinX - this.sourceXOffset, this.srcXSubsampling);
/* 1095 */     int dstMaxX = ifloor(srcMinX + srcWidth - 1 - this.sourceXOffset, this.srcXSubsampling);
/*      */ 
/*      */     
/* 1098 */     this.dstMinY = iceil(srcMinY - this.sourceYOffset, this.srcYSubsampling);
/* 1099 */     int dstMaxY = ifloor(srcMinY + srcHeight - 1 - this.sourceYOffset, this.srcYSubsampling);
/*      */ 
/*      */     
/* 1102 */     this.dstWidth = dstMaxX - this.dstMinX + 1;
/* 1103 */     this.dstHeight = dstMaxY - this.dstMinY + 1;
/*      */     
/* 1105 */     this.dstMinX += this.dstXOffset;
/* 1106 */     this.dstMinY += this.dstYOffset;
/*      */ 
/*      */ 
/*      */     
/* 1110 */     Rectangle dstRect = new Rectangle(this.dstMinX, this.dstMinY, this.dstWidth, this.dstHeight);
/*      */     
/* 1112 */     dstRect = dstRect.intersection(this.theImage.getRaster().getBounds());
/*      */ 
/*      */     
/* 1115 */     this.dstMinX = dstRect.x;
/* 1116 */     this.dstMinY = dstRect.y;
/* 1117 */     this.dstWidth = dstRect.width;
/* 1118 */     this.dstHeight = dstRect.height;
/*      */     
/* 1120 */     if (this.dstWidth <= 0 || this.dstHeight <= 0) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1127 */     int activeSrcMinX = (this.dstMinX - this.dstXOffset) * this.srcXSubsampling + this.sourceXOffset;
/*      */     
/* 1129 */     int sxmax = (this.dstMinX + this.dstWidth - 1 - this.dstXOffset) * this.srcXSubsampling + this.sourceXOffset;
/*      */ 
/*      */     
/* 1132 */     int activeSrcWidth = sxmax - activeSrcMinX + 1;
/*      */     
/* 1134 */     int activeSrcMinY = (this.dstMinY - this.dstYOffset) * this.srcYSubsampling + this.sourceYOffset;
/*      */     
/* 1136 */     int symax = (this.dstMinY + this.dstHeight - 1 - this.dstYOffset) * this.srcYSubsampling + this.sourceYOffset;
/*      */ 
/*      */     
/* 1139 */     int activeSrcHeight = symax - activeSrcMinY + 1;
/*      */     
/* 1141 */     this.decompressor.setSrcMinX(srcMinX);
/* 1142 */     this.decompressor.setSrcMinY(srcMinY);
/* 1143 */     this.decompressor.setSrcWidth(srcWidth);
/* 1144 */     this.decompressor.setSrcHeight(srcHeight);
/*      */     
/* 1146 */     this.decompressor.setDstMinX(this.dstMinX);
/* 1147 */     this.decompressor.setDstMinY(this.dstMinY);
/* 1148 */     this.decompressor.setDstWidth(this.dstWidth);
/* 1149 */     this.decompressor.setDstHeight(this.dstHeight);
/*      */     
/* 1151 */     this.decompressor.setActiveSrcMinX(activeSrcMinX);
/* 1152 */     this.decompressor.setActiveSrcMinY(activeSrcMinY);
/* 1153 */     this.decompressor.setActiveSrcWidth(activeSrcWidth);
/* 1154 */     this.decompressor.setActiveSrcHeight(activeSrcHeight);
/*      */     
/* 1156 */     int tileIndex = tj * this.tilesAcross + ti;
/*      */     
/* 1158 */     if (this.planarConfiguration == 2)
/*      */     {
/* 1160 */       tileIndex += band * this.tilesAcross * this.tilesDown;
/*      */     }
/*      */     
/* 1163 */     long offset = getTileOrStripOffset(tileIndex);
/* 1164 */     long byteCount = getTileOrStripByteCount(tileIndex);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1173 */     long streamLength = this.stream.length();
/*      */     
/* 1175 */     processWarningOccurred("Attempting to process truncated stream.");
/* 1176 */     if (streamLength > 0L && offset + byteCount > streamLength && Math.max(byteCount = streamLength - offset, 0L) == 0L) {
/* 1177 */       processWarningOccurred("No bytes in strip/tile: skipping.");
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 1182 */     this.decompressor.setStream(this.stream);
/* 1183 */     this.decompressor.setOffset(offset);
/* 1184 */     this.decompressor.setByteCount((int)byteCount);
/*      */     
/* 1186 */     this.decompressor.beginDecoding();
/*      */     
/* 1188 */     this.stream.mark();
/* 1189 */     this.decompressor.decode();
/* 1190 */     this.stream.reset();
/*      */   }
/*      */ 
/*      */   
/*      */   private void reportProgress() {
/* 1195 */     this.pixelsRead += this.dstWidth * this.dstHeight;
/* 1196 */     processImageProgress(100.0F * this.pixelsRead / this.pixelsToRead);
/* 1197 */     processImageUpdate(this.theImage, this.dstMinX, this.dstMinY, this.dstWidth, this.dstHeight, 1, 1, this.destinationBands);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BufferedImage read(int imageIndex, ImageReadParam param) throws IOException {
/* 1205 */     prepareRead(imageIndex, param);
/* 1206 */     this.theImage = ImageReader.getDestination(param, getImageTypes(imageIndex), this.width, this.height);
/*      */ 
/*      */ 
/*      */     
/* 1210 */     this.srcXSubsampling = this.imageReadParam.getSourceXSubsampling();
/* 1211 */     this.srcYSubsampling = this.imageReadParam.getSourceYSubsampling();
/*      */     
/* 1213 */     Point p = this.imageReadParam.getDestinationOffset();
/* 1214 */     this.dstXOffset = p.x;
/* 1215 */     this.dstYOffset = p.y;
/*      */ 
/*      */     
/* 1218 */     Rectangle srcRegion = new Rectangle(0, 0, 0, 0);
/* 1219 */     Rectangle destRegion = new Rectangle(0, 0, 0, 0);
/*      */     
/* 1221 */     computeRegions(this.imageReadParam, this.width, this.height, this.theImage, srcRegion, destRegion);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1226 */     this.sourceXOffset = srcRegion.x;
/* 1227 */     this.sourceYOffset = srcRegion.y;
/*      */     
/* 1229 */     this.pixelsToRead = destRegion.width * destRegion.height;
/* 1230 */     this.pixelsRead = 0;
/*      */     
/* 1232 */     processImageStarted(imageIndex);
/* 1233 */     processImageProgress(0.0F);
/*      */     
/* 1235 */     this.tilesAcross = (this.width + this.tileOrStripWidth - 1) / this.tileOrStripWidth;
/* 1236 */     this.tilesDown = (this.height + this.tileOrStripHeight - 1) / this.tileOrStripHeight;
/*      */     
/* 1238 */     int compression = getCompression();
/*      */ 
/*      */ 
/*      */     
/* 1242 */     TIFFColorConverter colorConverter = null;
/* 1243 */     if (this.imageReadParam instanceof TIFFImageReadParam) {
/* 1244 */       TIFFImageReadParam tparam = (TIFFImageReadParam)this.imageReadParam;
/*      */       
/* 1246 */       this.decompressor = tparam.getTIFFDecompressor();
/* 1247 */       colorConverter = tparam.getColorConverter();
/*      */     } 
/*      */ 
/*      */     
/* 1251 */     if (this.decompressor == null) {
/* 1252 */       if (compression == 1) {
/*      */ 
/*      */         
/* 1255 */         TIFFField fillOrderField = this.imageMetadata.getTIFFField(266);
/*      */ 
/*      */ 
/*      */         
/* 1259 */         if (fillOrderField != null && fillOrderField.getAsInt(0) == 2) {
/* 1260 */           this.decompressor = new TIFFLSBDecompressor();
/*      */         } else {
/* 1262 */           this.decompressor = new TIFFNullDecompressor();
/*      */         } 
/* 1264 */       } else if (compression == 4) {
/*      */ 
/*      */         
/* 1267 */         if (this.decompressor == null)
/*      */         {
/*      */ 
/*      */           
/* 1271 */           this.decompressor = new TIFFFaxDecompressor();
/*      */         }
/* 1273 */       } else if (compression == 3) {
/*      */ 
/*      */         
/* 1276 */         if (this.decompressor == null)
/*      */         {
/*      */ 
/*      */           
/* 1280 */           this.decompressor = new TIFFFaxDecompressor();
/*      */         }
/* 1282 */       } else if (compression == 2) {
/*      */         
/* 1284 */         this.decompressor = new TIFFFaxDecompressor();
/* 1285 */       } else if (compression == 32773) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1290 */         this.decompressor = new TIFFPackBitsDecompressor();
/* 1291 */       } else if (compression == 5) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1296 */         TIFFField predictorField = this.imageMetadata.getTIFFField(317);
/*      */         
/* 1298 */         int predictor = (predictorField == null) ? 1 : predictorField.getAsInt(0);
/*      */ 
/*      */         
/* 1301 */         this.decompressor = new TIFFLZWDecompressor(predictor);
/* 1302 */       } else if (compression == 7) {
/*      */         
/* 1304 */         this.decompressor = new TIFFJPEGDecompressor();
/* 1305 */       } else if (compression == 8 || compression == 32946) {
/*      */ 
/*      */ 
/*      */         
/* 1309 */         TIFFField predictorField = this.imageMetadata.getTIFFField(317);
/*      */         
/* 1311 */         int predictor = (predictorField == null) ? 1 : predictorField.getAsInt(0);
/*      */ 
/*      */         
/* 1314 */         this.decompressor = new TIFFDeflateDecompressor(predictor);
/* 1315 */       } else if (compression == 6) {
/*      */         
/* 1317 */         TIFFField JPEGProcField = this.imageMetadata.getTIFFField(512);
/*      */         
/* 1319 */         if (JPEGProcField == null) {
/* 1320 */           processWarningOccurred("JPEGProc field missing; assuming baseline sequential JPEG process.");
/*      */         }
/* 1322 */         else if (JPEGProcField.getAsInt(0) != 1) {
/*      */           
/* 1324 */           throw new IIOException("Old-style JPEG supported for baseline sequential JPEG process only!");
/*      */         } 
/*      */         
/* 1327 */         this.decompressor = new TIFFOldJPEGDecompressor();
/*      */       } else {
/*      */         
/* 1330 */         throw new IIOException("Unsupported compression type (tag number = " + compression + ")!");
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1335 */       if (this.photometricInterpretation == 6 && compression != 7 && compression != 6) {
/*      */ 
/*      */ 
/*      */         
/* 1339 */         boolean convertYCbCrToRGB = (this.theImage.getColorModel().getColorSpace().getType() == 5);
/*      */ 
/*      */         
/* 1342 */         TIFFDecompressor wrappedDecompressor = (this.decompressor instanceof TIFFNullDecompressor) ? null : this.decompressor;
/*      */ 
/*      */         
/* 1345 */         this.decompressor = new TIFFYCbCrDecompressor(wrappedDecompressor, convertYCbCrToRGB);
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1356 */     if (colorConverter == null) {
/* 1357 */       if (this.photometricInterpretation == 8 && this.theImage.getColorModel().getColorSpace().getType() == 5) {
/*      */ 
/*      */ 
/*      */         
/* 1361 */         colorConverter = new TIFFCIELabColorConverter();
/* 1362 */       } else if (this.photometricInterpretation == 6 && !(this.decompressor instanceof TIFFYCbCrDecompressor) && compression != 7 && compression != 6) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1367 */         colorConverter = new TIFFYCbCrColorConverter(this.imageMetadata);
/*      */       } 
/*      */     }
/*      */     
/* 1371 */     this.decompressor.setReader(this);
/* 1372 */     this.decompressor.setMetadata(this.imageMetadata);
/* 1373 */     this.decompressor.setImage(this.theImage);
/*      */     
/* 1375 */     this.decompressor.setPhotometricInterpretation(this.photometricInterpretation);
/* 1376 */     this.decompressor.setCompression(compression);
/* 1377 */     this.decompressor.setSamplesPerPixel(this.samplesPerPixel);
/* 1378 */     this.decompressor.setBitsPerSample(this.bitsPerSample);
/* 1379 */     this.decompressor.setSampleFormat(this.sampleFormat);
/* 1380 */     this.decompressor.setExtraSamples(this.extraSamples);
/* 1381 */     this.decompressor.setColorMap(this.colorMap);
/*      */     
/* 1383 */     this.decompressor.setColorConverter(colorConverter);
/*      */     
/* 1385 */     this.decompressor.setSourceXOffset(this.sourceXOffset);
/* 1386 */     this.decompressor.setSourceYOffset(this.sourceYOffset);
/* 1387 */     this.decompressor.setSubsampleX(this.srcXSubsampling);
/* 1388 */     this.decompressor.setSubsampleY(this.srcYSubsampling);
/*      */     
/* 1390 */     this.decompressor.setDstXOffset(this.dstXOffset);
/* 1391 */     this.decompressor.setDstYOffset(this.dstYOffset);
/*      */     
/* 1393 */     this.decompressor.setSourceBands(this.sourceBands);
/* 1394 */     this.decompressor.setDestinationBands(this.destinationBands);
/*      */ 
/*      */     
/* 1397 */     int minTileX = TIFFImageWriter.XToTileX(srcRegion.x, 0, this.tileOrStripWidth);
/*      */     
/* 1399 */     int minTileY = TIFFImageWriter.YToTileY(srcRegion.y, 0, this.tileOrStripHeight);
/*      */     
/* 1401 */     int maxTileX = TIFFImageWriter.XToTileX(srcRegion.x + srcRegion.width - 1, 0, this.tileOrStripWidth);
/*      */ 
/*      */     
/* 1404 */     int maxTileY = TIFFImageWriter.YToTileY(srcRegion.y + srcRegion.height - 1, 0, this.tileOrStripHeight);
/*      */ 
/*      */ 
/*      */     
/* 1408 */     boolean isAbortRequested = false;
/* 1409 */     if (this.planarConfiguration == 2) {
/*      */ 
/*      */       
/* 1412 */       this.decompressor.setPlanar(true);
/*      */       
/* 1414 */       int[] sb = new int[1];
/* 1415 */       int[] db = new int[1];
/* 1416 */       for (int tj = minTileY; tj <= maxTileY; tj++) {
/* 1417 */         for (int ti = minTileX; ti <= maxTileX; ti++) {
/* 1418 */           for (int band = 0; band < this.numBands; band++) {
/* 1419 */             sb[0] = this.sourceBands[band];
/* 1420 */             this.decompressor.setSourceBands(sb);
/* 1421 */             db[0] = this.destinationBands[band];
/* 1422 */             this.decompressor.setDestinationBands(db);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1428 */             if (abortRequested()) {
/* 1429 */               isAbortRequested = true;
/*      */               
/*      */               break;
/*      */             } 
/* 1433 */             decodeTile(ti, tj, band);
/*      */           } 
/*      */           
/* 1436 */           if (isAbortRequested)
/*      */             break; 
/* 1438 */           reportProgress();
/*      */         } 
/*      */         
/* 1441 */         if (isAbortRequested) {
/*      */           break;
/*      */         }
/*      */       } 
/*      */     } else {
/* 1446 */       for (int tj = minTileY; tj <= maxTileY; tj++) {
/* 1447 */         for (int ti = minTileX; ti <= maxTileX; ti++) {
/*      */ 
/*      */ 
/*      */           
/* 1451 */           if (abortRequested()) {
/* 1452 */             isAbortRequested = true;
/*      */             
/*      */             break;
/*      */           } 
/* 1456 */           decodeTile(ti, tj, -1);
/*      */           
/* 1458 */           reportProgress();
/*      */         } 
/*      */         
/* 1461 */         if (isAbortRequested)
/*      */           break; 
/*      */       } 
/*      */     } 
/* 1465 */     if (isAbortRequested) {
/* 1466 */       processReadAborted();
/*      */     } else {
/* 1468 */       processImageComplete();
/*      */     } 
/*      */     
/* 1471 */     return this.theImage;
/*      */   }
/*      */   
/*      */   public void reset() {
/* 1475 */     super.reset();
/* 1476 */     resetLocal();
/*      */   }
/*      */   
/*      */   protected void resetLocal() {
/* 1480 */     this.stream = null;
/* 1481 */     this.gotHeader = false;
/* 1482 */     this.imageReadParam = getDefaultReadParam();
/* 1483 */     this.streamMetadata = null;
/* 1484 */     this.currIndex = -1;
/* 1485 */     this.imageMetadata = null;
/* 1486 */     this.imageStartPosition = new ArrayList();
/* 1487 */     this.numImages = -1;
/* 1488 */     this.imageTypeMap = new HashMap<Object, Object>();
/* 1489 */     this.width = -1;
/* 1490 */     this.height = -1;
/* 1491 */     this.numBands = -1;
/* 1492 */     this.tileOrStripWidth = -1;
/* 1493 */     this.tileOrStripHeight = -1;
/* 1494 */     this.planarConfiguration = 1;
/* 1495 */     this.rowsDone = 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void forwardWarningMessage(String warning) {
/* 1503 */     processWarningOccurred(warning);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static BufferedImage getDestination(ImageReadParam param, Iterator<ImageTypeSpecifier> imageTypes, int width, int height) throws IIOException {
/* 1510 */     if (imageTypes == null || !imageTypes.hasNext()) {
/* 1511 */       throw new IllegalArgumentException("imageTypes null or empty!");
/*      */     }
/*      */     
/* 1514 */     BufferedImage dest = null;
/* 1515 */     ImageTypeSpecifier imageType = null;
/*      */ 
/*      */     
/* 1518 */     if (param != null) {
/*      */       
/* 1520 */       dest = param.getDestination();
/* 1521 */       if (dest != null) {
/* 1522 */         return dest;
/*      */       }
/*      */ 
/*      */       
/* 1526 */       imageType = param.getDestinationType();
/*      */     } 
/*      */ 
/*      */     
/* 1530 */     if (imageType == null) {
/* 1531 */       Object o = imageTypes.next();
/* 1532 */       if (!(o instanceof ImageTypeSpecifier)) {
/* 1533 */         throw new IllegalArgumentException("Non-ImageTypeSpecifier retrieved from imageTypes!");
/*      */       }
/*      */       
/* 1536 */       imageType = (ImageTypeSpecifier)o;
/*      */     } else {
/* 1538 */       boolean foundIt = false;
/* 1539 */       while (imageTypes.hasNext()) {
/* 1540 */         ImageTypeSpecifier type = imageTypes.next();
/*      */         
/* 1542 */         if (type.equals(imageType)) {
/* 1543 */           foundIt = true;
/*      */           
/*      */           break;
/*      */         } 
/*      */       } 
/* 1548 */       if (!foundIt) {
/* 1549 */         throw new IIOException("Destination type from ImageReadParam does not match!");
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 1554 */     Rectangle srcRegion = new Rectangle(0, 0, 0, 0);
/* 1555 */     Rectangle destRegion = new Rectangle(0, 0, 0, 0);
/* 1556 */     computeRegions(param, width, height, null, srcRegion, destRegion);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1563 */     int destWidth = destRegion.x + destRegion.width;
/* 1564 */     int destHeight = destRegion.y + destRegion.height;
/*      */ 
/*      */     
/* 1567 */     if (destWidth * destHeight > 2147483647L) {
/* 1568 */       throw new IllegalArgumentException("width*height > Integer.MAX_VALUE!");
/*      */     }
/*      */ 
/*      */     
/* 1572 */     return imageType.createBufferedImage(destWidth, destHeight);
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/tiff/TIFFImageReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */