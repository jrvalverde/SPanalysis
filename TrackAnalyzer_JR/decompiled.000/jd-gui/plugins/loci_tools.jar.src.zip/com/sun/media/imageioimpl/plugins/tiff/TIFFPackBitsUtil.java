/*     */ package com.sun.media.imageioimpl.plugins.tiff;
/*     */ 
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TIFFPackBitsUtil
/*     */ {
/*     */   private static final boolean debug = false;
/*  93 */   byte[] dstData = new byte[8192];
/*  94 */   int dstIndex = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void ensureCapacity(int bytesToAdd) {
/* 100 */     if (this.dstIndex + bytesToAdd > this.dstData.length) {
/* 101 */       byte[] newDstData = new byte[Math.max((int)(this.dstData.length * 1.2F), this.dstIndex + bytesToAdd)];
/*     */       
/* 103 */       System.arraycopy(this.dstData, 0, newDstData, 0, this.dstData.length);
/* 104 */       this.dstData = newDstData;
/*     */     } 
/*     */   }
/*     */   
/*     */   public byte[] decode(byte[] srcData) throws IOException {
/* 109 */     int inIndex = 0;
/* 110 */     while (inIndex < srcData.length) {
/* 111 */       byte b = srcData[inIndex++];
/*     */       
/* 113 */       if (b >= 0 && b <= Byte.MAX_VALUE) {
/*     */ 
/*     */         
/* 116 */         ensureCapacity(b + 1);
/* 117 */         for (int i = 0; i < b + 1; i++)
/* 118 */           this.dstData[this.dstIndex++] = srcData[inIndex++];  continue;
/*     */       } 
/* 120 */       if (b <= -1 && b >= -127) {
/*     */         
/* 122 */         byte repeat = srcData[inIndex++];
/* 123 */         ensureCapacity(-b + 1);
/* 124 */         for (int i = 0; i < -b + 1; i++) {
/* 125 */           this.dstData[this.dstIndex++] = repeat;
/*     */         }
/*     */         continue;
/*     */       } 
/* 129 */       inIndex++;
/*     */     } 
/*     */ 
/*     */     
/* 133 */     byte[] newDstData = new byte[this.dstIndex];
/* 134 */     System.arraycopy(this.dstData, 0, newDstData, 0, this.dstIndex);
/* 135 */     return newDstData;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/tiff/TIFFPackBitsUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */