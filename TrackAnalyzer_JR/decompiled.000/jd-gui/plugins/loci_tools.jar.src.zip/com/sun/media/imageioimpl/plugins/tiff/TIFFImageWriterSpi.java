/*     */ package com.sun.media.imageioimpl.plugins.tiff;
/*     */ 
/*     */ import com.sun.media.imageioimpl.common.PackageUtil;
/*     */ import java.util.Locale;
/*     */ import javax.imageio.ImageTypeSpecifier;
/*     */ import javax.imageio.ImageWriter;
/*     */ import javax.imageio.spi.ImageWriterSpi;
/*     */ import javax.imageio.spi.ServiceRegistry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TIFFImageWriterSpi
/*     */   extends ImageWriterSpi
/*     */ {
/*  92 */   private static final String[] names = new String[] { "tif", "TIF", "tiff", "TIFF" };
/*     */   
/*  94 */   private static final String[] suffixes = new String[] { "tif", "tiff" };
/*     */   
/*  96 */   private static final String[] MIMETypes = new String[] { "image/tiff" };
/*     */ 
/*     */   
/*     */   private static final String writerClassName = "com.sun.media.imageioimpl.plugins.tiff.TIFFImageWriter";
/*     */   
/* 101 */   private static final String[] readerSpiNames = new String[] { "com.sun.media.imageioimpl.plugins.tiff.TIFFImageReaderSpi" };
/*     */ 
/*     */   
/*     */   private boolean registered = false;
/*     */ 
/*     */   
/*     */   public TIFFImageWriterSpi() {
/* 108 */     super(PackageUtil.getVendor(), PackageUtil.getVersion(), names, suffixes, MIMETypes, "com.sun.media.imageioimpl.plugins.tiff.TIFFImageWriter", STANDARD_OUTPUT_TYPE, readerSpiNames, false, "com_sun_media_imageio_plugins_tiff_stream_1.0", "com.sun.media.imageioimpl.plugins.tiff.TIFFStreamMetadataFormat", null, null, false, "com_sun_media_imageio_plugins_tiff_image_1.0", "com.sun.media.imageioimpl.plugins.tiff.TIFFImageMetadataFormat", null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canEncodeImage(ImageTypeSpecifier type) {
/* 128 */     return true;
/*     */   }
/*     */   
/*     */   public String getDescription(Locale locale) {
/* 132 */     String desc = PackageUtil.getSpecificationTitle() + " TIFF Image Writer";
/*     */     
/* 134 */     return desc;
/*     */   }
/*     */   
/*     */   public ImageWriter createWriterInstance(Object extension) {
/* 138 */     return new TIFFImageWriter(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onRegistration(ServiceRegistry registry, Class category) {
/* 143 */     if (this.registered) {
/*     */       return;
/*     */     }
/*     */     
/* 147 */     this.registered = true;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/tiff/TIFFImageWriterSpi.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */