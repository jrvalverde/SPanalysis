/*     */ package com.sun.media.imageioimpl.plugins.tiff;
/*     */ 
/*     */ import com.sun.media.imageio.plugins.tiff.TIFFCompressor;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TIFFPackBitsCompressor
/*     */   extends TIFFCompressor
/*     */ {
/*     */   public TIFFPackBitsCompressor() {
/*  93 */     super("PackBits", 32773, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int packBits(byte[] input, int inOffset, int inCount, byte[] output, int outOffset) {
/* 103 */     int inMax = inOffset + inCount - 1;
/* 104 */     int inMaxMinus1 = inMax - 1;
/*     */     
/* 106 */     while (inOffset <= inMax) {
/* 107 */       int run = 1;
/* 108 */       byte replicate = input[inOffset];
/* 109 */       while (run < 127 && inOffset < inMax && input[inOffset] == input[inOffset + 1]) {
/*     */         
/* 111 */         run++;
/* 112 */         inOffset++;
/*     */       } 
/* 114 */       if (run > 1) {
/* 115 */         inOffset++;
/* 116 */         output[outOffset++] = (byte)-(run - 1);
/* 117 */         output[outOffset++] = replicate;
/*     */       } 
/*     */       
/* 120 */       run = 0;
/* 121 */       int saveOffset = outOffset;
/* 122 */       while (run < 128 && ((inOffset < inMax && input[inOffset] != input[inOffset + 1]) || (inOffset < inMaxMinus1 && input[inOffset] != input[inOffset + 2]))) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 127 */         run++;
/* 128 */         output[++outOffset] = input[inOffset++];
/*     */       } 
/* 130 */       if (run > 0) {
/* 131 */         output[saveOffset] = (byte)(run - 1);
/* 132 */         outOffset++;
/*     */       } 
/*     */       
/* 135 */       if (inOffset == inMax) {
/* 136 */         if (run > 0 && run < 128) {
/* 137 */           output[saveOffset] = (byte)(output[saveOffset] + 1);
/* 138 */           output[outOffset++] = input[inOffset++]; continue;
/*     */         } 
/* 140 */         output[outOffset++] = 0;
/* 141 */         output[outOffset++] = input[inOffset++];
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 146 */     return outOffset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int encode(byte[] b, int off, int width, int height, int[] bitsPerSample, int scanlineStride) throws IOException {
/* 153 */     int bitsPerPixel = 0;
/* 154 */     for (int i = 0; i < bitsPerSample.length; i++) {
/* 155 */       bitsPerPixel += bitsPerSample[i];
/*     */     }
/* 157 */     int bytesPerRow = (bitsPerPixel * width + 7) / 8;
/* 158 */     int bufSize = bytesPerRow + (bytesPerRow + 127) / 128;
/* 159 */     byte[] compData = new byte[bufSize];
/*     */     
/* 161 */     int bytesWritten = 0;
/*     */     
/* 163 */     for (int j = 0; j < height; j++) {
/* 164 */       int bytes = packBits(b, off, scanlineStride, compData, 0);
/* 165 */       off += scanlineStride;
/* 166 */       bytesWritten += bytes;
/* 167 */       this.stream.write(compData, 0, bytes);
/*     */     } 
/*     */     
/* 170 */     return bytesWritten;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/tiff/TIFFPackBitsCompressor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */