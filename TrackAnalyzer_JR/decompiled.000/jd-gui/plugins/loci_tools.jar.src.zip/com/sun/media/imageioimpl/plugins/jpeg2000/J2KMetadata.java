/*      */ package com.sun.media.imageioimpl.plugins.jpeg2000;
/*      */ 
/*      */ import java.awt.color.ColorSpace;
/*      */ import java.awt.color.ICC_ColorSpace;
/*      */ import java.awt.image.ColorModel;
/*      */ import java.awt.image.IndexColorModel;
/*      */ import java.awt.image.SampleModel;
/*      */ import java.io.IOException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Iterator;
/*      */ import javax.imageio.ImageTypeSpecifier;
/*      */ import javax.imageio.ImageWriteParam;
/*      */ import javax.imageio.ImageWriter;
/*      */ import javax.imageio.metadata.IIOInvalidTreeException;
/*      */ import javax.imageio.metadata.IIOMetadata;
/*      */ import javax.imageio.metadata.IIOMetadataNode;
/*      */ import javax.imageio.stream.ImageInputStream;
/*      */ import jj2000.j2k.fileformat.reader.FileFormatReader;
/*      */ import jj2000.j2k.io.RandomAccessIO;
/*      */ import org.w3c.dom.NamedNodeMap;
/*      */ import org.w3c.dom.Node;
/*      */ import org.w3c.dom.NodeList;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class J2KMetadata
/*      */   extends IIOMetadata
/*      */   implements Cloneable
/*      */ {
/*      */   static final String nativeMetadataFormatName = "com_sun_media_imageio_plugins_jpeg2000_image_1.0";
/*      */   private J2KMetadataFormat format;
/*  137 */   private ArrayList boxes = new ArrayList();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public J2KMetadata() {
/*  143 */     super(true, "com_sun_media_imageio_plugins_jpeg2000_image_1.0", "com.sun.media.imageioimpl.plugins.jpeg2000.J2KMetadataFormat", null, null);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  148 */     this.format = (J2KMetadataFormat)getMetadataFormat("com_sun_media_imageio_plugins_jpeg2000_image_1.0");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public J2KMetadata(ImageInputStream iis, J2KImageReader reader) throws IOException {
/*  163 */     this();
/*  164 */     RandomAccessIO in = new IISRandomAccessIO(iis);
/*      */     
/*  166 */     iis.mark();
/*      */ 
/*      */ 
/*      */     
/*  170 */     FileFormatReader ff = new FileFormatReader(in, this);
/*  171 */     ff.readFileFormat();
/*  172 */     iis.reset();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public J2KMetadata(ImageWriteParam param, ImageWriter writer) {
/*  180 */     this((ImageTypeSpecifier)null, param, writer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public J2KMetadata(ImageTypeSpecifier imageType, ImageWriteParam param, ImageWriter writer) {
/*  190 */     this((imageType != null) ? imageType.getColorModel() : null, (imageType != null) ? imageType.getSampleModel() : null, 0, 0, param, writer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public J2KMetadata(ColorModel colorModel, SampleModel sampleModel, int width, int height, ImageWriteParam param, ImageWriter writer) {
/*  206 */     this();
/*  207 */     addNode(new SignatureBox());
/*  208 */     addNode(new FileTypeBox(1785737760, 0, new int[] { 1785737760 }));
/*      */     
/*  210 */     ImageTypeSpecifier destType = null;
/*      */     
/*  212 */     if (param != null) {
/*  213 */       destType = param.getDestinationType();
/*  214 */       if (colorModel == null && sampleModel == null) {
/*  215 */         colorModel = (destType == null) ? null : destType.getColorModel();
/*  216 */         sampleModel = (destType == null) ? null : destType.getSampleModel();
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  221 */     int[] bitDepths = null;
/*  222 */     if (colorModel != null) {
/*  223 */       bitDepths = colorModel.getComponentSize();
/*  224 */     } else if (sampleModel != null) {
/*  225 */       bitDepths = sampleModel.getSampleSize();
/*      */     } 
/*      */     
/*  228 */     int bitsPerComponent = 255;
/*  229 */     if (bitDepths != null) {
/*  230 */       bitsPerComponent = bitDepths[0];
/*  231 */       int numComponents = bitDepths.length;
/*  232 */       for (int i = 1; i < numComponents; i++) {
/*      */ 
/*      */         
/*  235 */         if (bitDepths[i] > bitsPerComponent) {
/*  236 */           bitsPerComponent = bitDepths[i];
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  250 */     if (colorModel != null) {
/*  251 */       ColorSpace cs = colorModel.getColorSpace();
/*  252 */       boolean iccColor = cs instanceof ICC_ColorSpace;
/*  253 */       int type = cs.getType();
/*      */       
/*  255 */       if (type == 5) {
/*  256 */         addNode(new ColorSpecificationBox((byte)1, (byte)0, (byte)0, 16, null));
/*      */ 
/*      */       
/*      */       }
/*  260 */       else if (type == 6) {
/*  261 */         addNode(new ColorSpecificationBox((byte)1, (byte)0, (byte)0, 17, null));
/*      */ 
/*      */       
/*      */       }
/*  265 */       else if (cs instanceof ICC_ColorSpace) {
/*  266 */         addNode(new ColorSpecificationBox((byte)2, (byte)0, (byte)0, 0, ((ICC_ColorSpace)cs).getProfile()));
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  271 */       if (colorModel.hasAlpha()) {
/*  272 */         addNode(new ChannelDefinitionBox(colorModel));
/*      */       }
/*      */       
/*  275 */       if (colorModel instanceof IndexColorModel) {
/*  276 */         addNode(new PaletteBox((IndexColorModel)colorModel));
/*  277 */         int numComp = (colorModel.getComponentSize()).length;
/*  278 */         short[] channels = new short[numComp];
/*  279 */         byte[] types = new byte[numComp];
/*  280 */         byte[] maps = new byte[numComp];
/*  281 */         for (int i = 0; i < numComp; i++) {
/*  282 */           channels[i] = 0;
/*  283 */           types[i] = 1;
/*  284 */           maps[i] = (byte)i;
/*      */         } 
/*  286 */         addNode(new ComponentMappingBox(channels, types, maps));
/*      */       } 
/*      */     } 
/*      */     
/*  290 */     if (sampleModel != null) {
/*  291 */       if (width <= 0)
/*  292 */         width = sampleModel.getWidth(); 
/*  293 */       if (height <= 0)
/*  294 */         height = sampleModel.getHeight(); 
/*  295 */       int bpc = (bitsPerComponent == 255) ? 255 : (bitsPerComponent - 1 | (isOriginalSigned(sampleModel) ? 128 : 0));
/*      */ 
/*      */       
/*  298 */       addNode(new HeaderBox(height, width, sampleModel.getNumBands(), bpc, 7, (colorModel == null) ? 1 : 0, (getElement("JPEG2000IntellectualPropertyRightsBox") == null) ? 0 : 1));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object clone() {
/*  309 */     J2KMetadata theClone = null;
/*      */     
/*      */     try {
/*  312 */       theClone = (J2KMetadata)super.clone();
/*  313 */     } catch (CloneNotSupportedException e) {}
/*      */     
/*  315 */     if (this.boxes != null) {
/*  316 */       int numBoxes = this.boxes.size();
/*  317 */       for (int i = 0; i < numBoxes; i++) {
/*  318 */         theClone.addNode(this.boxes.get(i));
/*      */       }
/*      */     } 
/*  321 */     return theClone;
/*      */   }
/*      */   
/*      */   public Node getAsTree(String formatName) {
/*  325 */     if (formatName == null) {
/*  326 */       throw new IllegalArgumentException(I18N.getString("J2KMetadata0"));
/*      */     }
/*      */     
/*  329 */     if (formatName.equals("com_sun_media_imageio_plugins_jpeg2000_image_1.0")) {
/*  330 */       return getNativeTree();
/*      */     }
/*      */     
/*  333 */     if (formatName.equals("javax_imageio_1.0"))
/*      */     {
/*  335 */       return getStandardTree();
/*      */     }
/*      */     
/*  338 */     throw new IllegalArgumentException(I18N.getString("J2KMetadata1") + " " + formatName);
/*      */   }
/*      */ 
/*      */   
/*      */   IIOMetadataNode getNativeTree() {
/*  343 */     IIOMetadataNode root = new IIOMetadataNode("com_sun_media_imageio_plugins_jpeg2000_image_1.0");
/*      */ 
/*      */     
/*  346 */     Box signatureBox = null, fileTypeBox = null, headerBox = null;
/*  347 */     int signatureIndex = -1, fileTypeIndex = -1, headerIndex = -1;
/*      */     
/*  349 */     int numBoxes = this.boxes.size();
/*      */     
/*  351 */     int found = 0; int i;
/*  352 */     for (i = 0; i < numBoxes && found < 3; i++) {
/*  353 */       Box box = this.boxes.get(i);
/*  354 */       if (Box.getName(box.getType()).equals("JPEG2000SignatureBox")) {
/*  355 */         signatureBox = box;
/*  356 */         signatureIndex = i;
/*  357 */         found++;
/*  358 */       } else if (Box.getName(box.getType()).equals("JPEG2000FileTypeBox")) {
/*  359 */         fileTypeBox = box;
/*  360 */         fileTypeIndex = i;
/*  361 */         found++;
/*  362 */       } else if (Box.getName(box.getType()).equals("JPEG2000HeaderBox")) {
/*  363 */         headerBox = box;
/*  364 */         headerIndex = i;
/*  365 */         found++;
/*      */       } 
/*      */     } 
/*      */     
/*  369 */     if (signatureBox != null) {
/*  370 */       insertNodeIntoTree(root, signatureBox.getNativeNode());
/*      */     }
/*      */     
/*  373 */     if (fileTypeBox != null) {
/*  374 */       insertNodeIntoTree(root, fileTypeBox.getNativeNode());
/*      */     }
/*      */     
/*  377 */     if (headerBox != null) {
/*  378 */       insertNodeIntoTree(root, headerBox.getNativeNode());
/*      */     }
/*      */     
/*  381 */     for (i = 0; i < numBoxes; i++) {
/*  382 */       if (i != signatureIndex && i != fileTypeIndex && i != headerIndex) {
/*      */ 
/*      */         
/*  385 */         Box box = this.boxes.get(i);
/*  386 */         IIOMetadataNode node = box.getNativeNode();
/*  387 */         insertNodeIntoTree(root, node);
/*      */       } 
/*  389 */     }  return root;
/*      */   }
/*      */ 
/*      */   
/*      */   protected IIOMetadataNode getStandardChromaNode() {
/*  394 */     HeaderBox header = (HeaderBox)getElement("JPEG2000HeaderBox");
/*  395 */     PaletteBox palette = (PaletteBox)getElement("JPEG2000PaletteBox");
/*  396 */     ColorSpecificationBox color = (ColorSpecificationBox)getElement("JPEG2000ColorSpecificationBox");
/*      */ 
/*      */     
/*  399 */     IIOMetadataNode node = new IIOMetadataNode("Chroma");
/*  400 */     IIOMetadataNode subNode = null;
/*  401 */     if (header != null) {
/*  402 */       if (header.getUnknownColorspace() == 0 && 
/*  403 */         color != null && color.getMethod() == 1) {
/*  404 */         subNode = new IIOMetadataNode("ColorSpaceType");
/*  405 */         int ecs = color.getEnumeratedColorSpace();
/*  406 */         if (ecs == 16)
/*  407 */           subNode.setAttribute("name", "RGB"); 
/*  408 */         if (ecs == 17)
/*  409 */           subNode.setAttribute("name", "GRAY"); 
/*  410 */         node.appendChild(subNode);
/*      */       } 
/*      */ 
/*      */       
/*  414 */       subNode = new IIOMetadataNode("NumChannels");
/*  415 */       subNode.setAttribute("value", "" + header.getNumComponents());
/*  416 */       node.appendChild(subNode);
/*      */       
/*  418 */       if (palette != null) {
/*  419 */         subNode.setAttribute("value", "" + palette.getNumComp());
/*  420 */         subNode = new IIOMetadataNode("Palette");
/*  421 */         byte[][] lut = palette.getLUT();
/*      */         
/*  423 */         int size = (lut[0]).length;
/*  424 */         int numComp = lut.length;
/*      */         
/*  426 */         for (int i = 0; i < size; i++) {
/*  427 */           IIOMetadataNode subNode1 = new IIOMetadataNode("PaletteEntry");
/*      */           
/*  429 */           subNode1.setAttribute("index", "" + i);
/*  430 */           subNode1.setAttribute("red", "" + (lut[0][i] & 0xFF));
/*  431 */           subNode1.setAttribute("green", "" + (lut[1][i] & 0xFF));
/*  432 */           subNode1.setAttribute("blue", "" + (lut[2][i] & 0xFF));
/*  433 */           if (numComp == 4)
/*  434 */             subNode1.setAttribute("alpha", "" + (lut[3][i] & 0xFF)); 
/*  435 */           subNode.appendChild(subNode1);
/*      */         } 
/*  437 */         node.appendChild(subNode);
/*      */       } 
/*      */     } 
/*  440 */     return node;
/*      */   }
/*      */   
/*      */   protected IIOMetadataNode getStandardCompressionNode() {
/*  444 */     IIOMetadataNode node = new IIOMetadataNode("Compression");
/*      */ 
/*      */     
/*  447 */     IIOMetadataNode subNode = new IIOMetadataNode("CompressionTypeName");
/*  448 */     subNode.setAttribute("value", "JPEG2000");
/*  449 */     node.appendChild(subNode);
/*  450 */     return node;
/*      */   }
/*      */   
/*      */   protected IIOMetadataNode getStandardDataNode() {
/*  454 */     IIOMetadataNode node = new IIOMetadataNode("Data");
/*  455 */     PaletteBox palette = (PaletteBox)getElement("JPEG2000PaletteBox");
/*  456 */     boolean sampleFormat = false;
/*      */     
/*  458 */     if (palette != null) {
/*  459 */       IIOMetadataNode iIOMetadataNode = new IIOMetadataNode("SampleFormat");
/*  460 */       iIOMetadataNode.setAttribute("value", "Index");
/*  461 */       node.appendChild(iIOMetadataNode);
/*  462 */       sampleFormat = true;
/*      */     } 
/*      */     
/*  465 */     BitsPerComponentBox bitDepth = (BitsPerComponentBox)getElement("JPEG2000BitsPerComponentBox");
/*      */     
/*  467 */     String value = "";
/*  468 */     boolean signed = false;
/*  469 */     boolean gotSampleInfo = false;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  474 */     if (bitDepth != null) {
/*  475 */       byte[] bits = bitDepth.getBitDepth();
/*  476 */       if ((bits[0] & 0x80) == 128) {
/*  477 */         signed = true;
/*      */       }
/*  479 */       int numComp = bits.length;
/*  480 */       for (int i = 0; i < numComp; i++) {
/*  481 */         value = value + ((bits[i] & Byte.MAX_VALUE) + 1);
/*  482 */         if (i != numComp - 1) value = value + " ";
/*      */       
/*      */       } 
/*  485 */       gotSampleInfo = true;
/*      */     } else {
/*  487 */       HeaderBox header = (HeaderBox)getElement("JPEG2000HeaderBox");
/*  488 */       if (header != null) {
/*  489 */         int bits = header.getBitDepth();
/*  490 */         if ((bits & 0x80) == 128)
/*  491 */           signed = true; 
/*  492 */         bits = (bits & 0x7F) + 1;
/*  493 */         int numComp = header.getNumComponents();
/*  494 */         for (int i = 0; i < numComp; i++) {
/*  495 */           value = value + bits;
/*  496 */           if (i != numComp - 1) value = value + " ";
/*      */         
/*      */         } 
/*  499 */         gotSampleInfo = true;
/*      */       } 
/*      */     } 
/*      */     
/*  503 */     IIOMetadataNode subNode = null;
/*      */     
/*  505 */     if (gotSampleInfo) {
/*  506 */       subNode = new IIOMetadataNode("BitsPerSample");
/*  507 */       subNode.setAttribute("value", value);
/*  508 */       node.appendChild(subNode);
/*      */     } 
/*      */     
/*  511 */     subNode = new IIOMetadataNode("PlanarConfiguration");
/*  512 */     subNode.setAttribute("value", "TileInterleaved");
/*  513 */     node.appendChild(subNode);
/*      */     
/*  515 */     if (!sampleFormat && gotSampleInfo) {
/*  516 */       subNode = new IIOMetadataNode("SampleFormat");
/*  517 */       subNode.setAttribute("value", signed ? "SignedIntegral" : "UnsignedIntegral");
/*      */       
/*  519 */       node.appendChild(subNode);
/*      */     } 
/*      */     
/*  522 */     return node;
/*      */   }
/*      */   
/*      */   protected IIOMetadataNode getStandardDimensionNode() {
/*  526 */     ResolutionBox box = (ResolutionBox)getElement("JPEG2000CaptureResolutionBox");
/*      */     
/*  528 */     if (box != null) {
/*  529 */       IIOMetadataNode node = new IIOMetadataNode("Dimension");
/*  530 */       float hRes = box.getHorizontalResolution();
/*  531 */       float vRes = box.getVerticalResolution();
/*  532 */       float ratio = vRes / hRes;
/*  533 */       IIOMetadataNode subNode = new IIOMetadataNode("PixelAspectRatio");
/*  534 */       subNode.setAttribute("value", "" + ratio);
/*  535 */       node.appendChild(subNode);
/*      */       
/*  537 */       subNode = new IIOMetadataNode("HorizontalPixelSize");
/*  538 */       subNode.setAttribute("value", "" + (1000.0F / hRes));
/*  539 */       node.appendChild(subNode);
/*      */       
/*  541 */       subNode = new IIOMetadataNode("VerticalPixelSize");
/*  542 */       subNode.setAttribute("value", "" + (1000.0F / vRes));
/*  543 */       node.appendChild(subNode);
/*      */       
/*  545 */       return node;
/*      */     } 
/*      */     
/*  548 */     return null;
/*      */   }
/*      */   
/*      */   protected IIOMetadataNode getStandardTransparencyNode() {
/*  552 */     ChannelDefinitionBox channel = (ChannelDefinitionBox)getElement("JPEG2000ChannelDefinitionBox");
/*      */     
/*  554 */     if (channel != null) {
/*  555 */       IIOMetadataNode iIOMetadataNode1 = new IIOMetadataNode("Transparency");
/*      */       
/*  557 */       boolean hasAlpha = false;
/*  558 */       boolean isPremultiplied = false;
/*  559 */       short[] type = channel.getTypes();
/*      */       
/*  561 */       for (int i = 0; i < type.length; i++) {
/*  562 */         if (type[i] == 1)
/*  563 */           hasAlpha = true; 
/*  564 */         if (type[i] == 2) {
/*  565 */           isPremultiplied = true;
/*      */         }
/*      */       } 
/*  568 */       String value = "none";
/*  569 */       if (isPremultiplied) {
/*  570 */         value = "premultiplied";
/*  571 */       } else if (hasAlpha) {
/*  572 */         value = "nonpremultiplied";
/*      */       } 
/*  574 */       IIOMetadataNode iIOMetadataNode2 = new IIOMetadataNode("Alpha");
/*  575 */       iIOMetadataNode2.setAttribute("value", value);
/*  576 */       iIOMetadataNode1.appendChild(iIOMetadataNode2);
/*      */       
/*  578 */       return iIOMetadataNode1;
/*      */     } 
/*      */     
/*  581 */     IIOMetadataNode node = new IIOMetadataNode("Transparency");
/*  582 */     IIOMetadataNode subNode = new IIOMetadataNode("Alpha");
/*  583 */     subNode.setAttribute("value", "none");
/*  584 */     node.appendChild(subNode);
/*      */     
/*  586 */     return null;
/*      */   }
/*      */   
/*      */   protected IIOMetadataNode getStandardTextNode() {
/*  590 */     if (this.boxes == null)
/*  591 */       return null; 
/*  592 */     IIOMetadataNode text = null;
/*      */     
/*  594 */     Iterator<Box> iterator = this.boxes.iterator();
/*      */     
/*  596 */     while (iterator.hasNext()) {
/*  597 */       Box box = iterator.next();
/*  598 */       if (box instanceof XMLBox) {
/*  599 */         if (text == null)
/*  600 */           text = new IIOMetadataNode("Text"); 
/*  601 */         IIOMetadataNode subNode = new IIOMetadataNode("TextEntry");
/*  602 */         String content = new String(box.getContent());
/*  603 */         subNode.setAttribute("value", content);
/*  604 */         text.appendChild(subNode);
/*      */       } 
/*      */     } 
/*  607 */     return text;
/*      */   }
/*      */   
/*      */   public boolean isReadOnly() {
/*  611 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public void mergeTree(String formatName, Node root) throws IIOInvalidTreeException {
/*  616 */     if (formatName == null) {
/*  617 */       throw new IllegalArgumentException(I18N.getString("J2KMetadata0"));
/*      */     }
/*      */     
/*  620 */     if (root == null) {
/*  621 */       throw new IllegalArgumentException(I18N.getString("J2KMetadata2"));
/*      */     }
/*      */     
/*  624 */     if (formatName.equals("com_sun_media_imageio_plugins_jpeg2000_image_1.0") && root.getNodeName().equals("com_sun_media_imageio_plugins_jpeg2000_image_1.0")) {
/*      */       
/*  626 */       mergeNativeTree(root);
/*  627 */     } else if (formatName.equals("javax_imageio_1.0")) {
/*      */       
/*  629 */       mergeStandardTree(root);
/*      */     } else {
/*  631 */       throw new IllegalArgumentException(I18N.getString("J2KMetadata1") + " " + formatName);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFromTree(String formatName, Node root) throws IIOInvalidTreeException {
/*  638 */     if (formatName == null) {
/*  639 */       throw new IllegalArgumentException(I18N.getString("J2KMetadata0"));
/*      */     }
/*      */     
/*  642 */     if (root == null) {
/*  643 */       throw new IllegalArgumentException(I18N.getString("J2KMetadata2"));
/*      */     }
/*      */     
/*  646 */     if (formatName.equals("com_sun_media_imageio_plugins_jpeg2000_image_1.0") && root.getNodeName().equals("com_sun_media_imageio_plugins_jpeg2000_image_1.0")) {
/*      */       
/*  648 */       this.boxes = new ArrayList();
/*  649 */       mergeNativeTree(root);
/*  650 */     } else if (formatName.equals("javax_imageio_1.0")) {
/*      */       
/*  652 */       this.boxes = new ArrayList();
/*  653 */       mergeStandardTree(root);
/*      */     } else {
/*  655 */       throw new IllegalArgumentException(I18N.getString("J2KMetadata1") + " " + formatName);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void reset() {
/*  661 */     this.boxes.clear();
/*      */   }
/*      */   
/*      */   public void addNode(Box node) {
/*  665 */     if (this.boxes == null)
/*  666 */       this.boxes = new ArrayList(); 
/*  667 */     replace(Box.getName(node.getType()), node);
/*      */   }
/*      */   
/*      */   public Box getElement(String name) {
/*  671 */     for (int i = this.boxes.size() - 1; i >= 0; i--) {
/*  672 */       Box box = this.boxes.get(i);
/*  673 */       if (name.equals(Box.getName(box.getType())))
/*  674 */         return box; 
/*      */     } 
/*  676 */     return null;
/*      */   }
/*      */   
/*      */   private void mergeNativeTree(Node root) throws IIOInvalidTreeException {
/*  680 */     NodeList list = root.getChildNodes();
/*  681 */     for (int i = list.getLength() - 1; i >= 0; i--) {
/*  682 */       Node node = list.item(i);
/*  683 */       String name = node.getNodeName();
/*  684 */       if (this.format.getParent(name) != null) {
/*  685 */         if (this.format.isLeaf(name))
/*  686 */         { String s = (String)Box.getAttribute(node, "Type");
/*  687 */           Box box = Box.createBox(Box.getTypeInt(s), node);
/*  688 */           if (this.format.singleInstance(name) && getElement(name) != null) {
/*  689 */             replace(name, box);
/*      */           } else {
/*  691 */             this.boxes.add(box);
/*      */           }  }
/*  693 */         else { mergeNativeTree(node); }
/*      */       
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   private void mergeStandardTree(Node root) throws IIOInvalidTreeException {
/*  700 */     NodeList children = root.getChildNodes();
/*  701 */     int numComps = 0;
/*      */     
/*  703 */     for (int i = 0; i < children.getLength(); i++) {
/*  704 */       Node node = children.item(i);
/*  705 */       String name = node.getNodeName();
/*  706 */       if (name.equals("Chroma")) {
/*  707 */         NodeList children1 = node.getChildNodes();
/*  708 */         for (int j = 0; j < children1.getLength(); j++) {
/*  709 */           Node child = children1.item(j);
/*  710 */           String name1 = child.getNodeName();
/*      */           
/*  712 */           if (name1.equals("NumChannels")) {
/*  713 */             String s = (String)Box.getAttribute(child, "value");
/*  714 */             numComps = (new Integer(s)).intValue();
/*      */           } 
/*      */           
/*  717 */           if (name1.equals("ColorSpaceType")) {
/*  718 */             createColorSpecificationBoxFromStandardNode(child);
/*      */           }
/*  720 */           if (name1.equals("Palette")) {
/*  721 */             createPaletteBoxFromStandardNode(child);
/*      */           }
/*      */         } 
/*  724 */       } else if (!name.equals("Compression")) {
/*      */ 
/*      */ 
/*      */         
/*  728 */         if (name.equals("Data")) {
/*  729 */           createBitsPerComponentBoxFromStandardNode(node);
/*  730 */           createHeaderBoxFromStandardNode(node, numComps);
/*  731 */         } else if (name.equals("Dimension")) {
/*  732 */           createResolutionBoxFromStandardNode(node);
/*  733 */         } else if (name.equals("Document")) {
/*  734 */           createXMLBoxFromStandardNode(node);
/*  735 */         } else if (name.equals("Text")) {
/*  736 */           createXMLBoxFromStandardNode(node);
/*  737 */         } else if (name.equals("Transparency")) {
/*  738 */           createChannelDefinitionFromStandardNode(node);
/*      */         } else {
/*  740 */           throw new IIOInvalidTreeException(I18N.getString("J2KMetadata3") + " " + name, node);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private void createColorSpecificationBoxFromStandardNode(Node node) {
/*  747 */     if (node.getNodeName() != "ColorSpaceType")
/*  748 */       throw new IllegalArgumentException(I18N.getString("J2KMetadata4")); 
/*  749 */     String name = (String)Box.getAttribute(node, "name");
/*  750 */     int ecs = name.equals("RGB") ? 16 : (name.equals("Gray") ? 17 : 0);
/*      */ 
/*      */     
/*  753 */     if (ecs == 16 || ecs == 17)
/*      */     {
/*  755 */       replace("JPEG2000ColorSpecificationBox", new ColorSpecificationBox((byte)1, (byte)0, (byte)0, ecs, null));
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private void createPaletteBoxFromStandardNode(Node node) {
/*      */     IndexColorModel icm;
/*  762 */     if (node.getNodeName() != "Palette")
/*  763 */       throw new IllegalArgumentException(I18N.getString("J2KMetadata5")); 
/*  764 */     NodeList children = node.getChildNodes();
/*  765 */     int maxIndex = -1;
/*  766 */     boolean hasAlpha = false;
/*  767 */     for (int i = 0; i < children.getLength(); i++) {
/*  768 */       Node child = children.item(i);
/*  769 */       String name = child.getNodeName();
/*      */       
/*  771 */       if (name.equals("PaletteEntry")) {
/*  772 */         String s = (String)Box.getAttribute(child, "index");
/*  773 */         int index = (new Integer(s)).intValue();
/*  774 */         if (index > maxIndex) {
/*  775 */           maxIndex = index;
/*      */         }
/*  777 */         if (Box.getAttribute(child, "alpha") != null) {
/*  778 */           hasAlpha = true;
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  784 */     int numBits = 32;
/*  785 */     int mask = Integer.MIN_VALUE;
/*  786 */     while (mask != 0 && (maxIndex & mask) == 0) {
/*  787 */       numBits--;
/*  788 */       mask >>>= 1;
/*      */     } 
/*  790 */     int size = 1 << numBits;
/*      */     
/*  792 */     byte[] red = new byte[size];
/*  793 */     byte[] green = new byte[size];
/*  794 */     byte[] blue = new byte[size];
/*  795 */     byte[] alpha = hasAlpha ? new byte[size] : null;
/*      */     
/*  797 */     for (int j = 0; j < children.getLength(); j++) {
/*  798 */       Node child = children.item(j);
/*  799 */       String name = child.getNodeName();
/*      */       
/*  801 */       if (name.equals("PaletteEntry")) {
/*  802 */         String s = (String)Box.getAttribute(child, "index");
/*  803 */         int index = (new Integer(s)).intValue();
/*  804 */         s = (String)Box.getAttribute(child, "red");
/*  805 */         red[index] = (byte)(new Integer(s)).intValue();
/*  806 */         s = (String)Box.getAttribute(child, "green");
/*  807 */         green[index] = (byte)(new Integer(s)).intValue();
/*  808 */         s = (String)Box.getAttribute(child, "blue");
/*  809 */         blue[index] = (byte)(new Integer(s)).intValue();
/*      */         
/*  811 */         byte t = -1;
/*  812 */         s = (String)Box.getAttribute(child, "alpha");
/*  813 */         if (s != null) {
/*  814 */           t = (byte)(new Integer(s)).intValue();
/*      */         }
/*      */         
/*  817 */         if (alpha != null) {
/*  818 */           alpha[index] = t;
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  824 */     if (alpha == null) {
/*  825 */       icm = new IndexColorModel(numBits, size, red, green, blue);
/*      */     } else {
/*  827 */       icm = new IndexColorModel(numBits, size, red, green, blue, alpha);
/*      */     } 
/*  829 */     replace("JPEG2000PaletteBox", new PaletteBox(icm));
/*      */   }
/*      */   
/*      */   private void createBitsPerComponentBoxFromStandardNode(Node node) {
/*  833 */     if (node.getNodeName() != "Data") {
/*  834 */       throw new IllegalArgumentException(I18N.getString("J2KMetadata6"));
/*      */     }
/*  836 */     NodeList children = node.getChildNodes();
/*      */     
/*  838 */     byte[] bits = null;
/*  839 */     boolean isSigned = false; int i;
/*  840 */     for (i = 0; i < children.getLength(); i++) {
/*  841 */       Node child = children.item(i);
/*  842 */       String name = child.getNodeName();
/*      */       
/*  844 */       if (name.equals("BitsPerSample")) {
/*  845 */         String s = (String)Box.getAttribute(child, "value");
/*  846 */         bits = (byte[])Box.parseByteArray(s).clone();
/*  847 */       } else if (name.equals("SampleFormat")) {
/*  848 */         String s = (String)Box.getAttribute(child, "value");
/*  849 */         isSigned = s.equals("SignedIntegral");
/*      */       } 
/*      */     } 
/*      */     
/*  853 */     if (bits != null) {
/*      */ 
/*      */ 
/*      */       
/*  857 */       for (i = 0; i < bits.length; i++) {
/*  858 */         bits[i] = (byte)((bits[i] & 0xFF) - 1);
/*  859 */         if (isSigned) {
/*  860 */           bits[i] = (byte)(bits[i] | 0x80);
/*      */         }
/*      */       } 
/*      */       
/*  864 */       replace("JPEG2000BitsPerComponent", new BitsPerComponentBox(bits));
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void createResolutionBoxFromStandardNode(Node node) {
/*  870 */     if (node.getNodeName() != "Dimension")
/*  871 */       throw new IllegalArgumentException(I18N.getString("J2KMetadata7")); 
/*  872 */     NodeList children = node.getChildNodes();
/*  873 */     float hRes = 0.0F;
/*  874 */     float vRes = 0.0F;
/*      */     
/*  876 */     boolean gotH = false, gotV = false;
/*      */     
/*  878 */     for (int i = 0; i < children.getLength(); i++) {
/*  879 */       Node child = children.item(i);
/*  880 */       String name = child.getNodeName();
/*      */       
/*  882 */       if (name.equals("HorizontalPixelSize")) {
/*  883 */         String s = (String)Box.getAttribute(child, "value");
/*  884 */         hRes = (new Float(s)).floatValue();
/*  885 */         hRes = 1000.0F / hRes;
/*  886 */         gotH = true;
/*      */       } 
/*      */       
/*  889 */       if (name.equals("VerticalPixelSize")) {
/*  890 */         String s = (String)Box.getAttribute(child, "value");
/*  891 */         vRes = (new Float(s)).floatValue();
/*  892 */         vRes = 1000.0F / vRes;
/*  893 */         gotV = true;
/*      */       } 
/*      */     } 
/*      */     
/*  897 */     if (gotH && !gotV) {
/*  898 */       vRes = hRes;
/*  899 */     } else if (gotV && !gotH) {
/*  900 */       hRes = vRes;
/*      */     } 
/*      */     
/*  903 */     if (gotH || gotV) {
/*  904 */       replace("JPEG2000CaptureResolutionBox", new ResolutionBox(1919251299, hRes, vRes));
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private void createXMLBoxFromStandardNode(Node node) {
/*  910 */     NodeList children = node.getChildNodes();
/*  911 */     String value = "<" + node.getNodeName() + ">";
/*      */     
/*  913 */     for (int i = 0; i < children.getLength(); i++) {
/*  914 */       Node child = children.item(i);
/*  915 */       String name = child.getNodeName();
/*  916 */       value = value + "<" + name + " ";
/*      */       
/*  918 */       NamedNodeMap map = child.getAttributes();
/*      */       
/*  920 */       for (int j = 0; j < map.getLength(); j++) {
/*  921 */         Node att = map.item(j);
/*  922 */         value = value + att.getNodeName() + "=\"" + att.getNodeValue() + "\" ";
/*      */       } 
/*      */ 
/*      */       
/*  926 */       value = value + " />";
/*      */     } 
/*      */     
/*  929 */     value = value + "</" + node.getNodeName() + ">";
/*      */     
/*  931 */     this.boxes.add(new XMLBox(value.getBytes()));
/*      */   }
/*      */   
/*      */   private void createHeaderBoxFromStandardNode(Node node, int numComps) {
/*  935 */     HeaderBox header = (HeaderBox)getElement("JPEG2000HeaderBox");
/*  936 */     byte unknownColor = (byte)((getElement("JPEG2000ColorSpecificationBox") == null) ? 1 : 0);
/*      */     
/*  938 */     if (header != null) {
/*  939 */       if (numComps == 0);
/*  940 */       numComps = header.getNumComponents();
/*      */       
/*  942 */       header = new HeaderBox(header.getHeight(), header.getWidth(), numComps, header.getBitDepth(), header.getCompressionType(), unknownColor, header.getIntellectualProperty());
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */       
/*  949 */       header = new HeaderBox(0, 0, numComps, 0, 0, unknownColor, 0);
/*      */     } 
/*  951 */     replace("JPEG2000HeaderBox", header);
/*      */   }
/*      */   
/*      */   private void createChannelDefinitionFromStandardNode(Node node) {
/*  955 */     if (node.getNodeName() != "Transparency") {
/*  956 */       throw new IllegalArgumentException(I18N.getString("J2KMetadata8"));
/*      */     }
/*  958 */     HeaderBox header = (HeaderBox)getElement("JPEG2000HeaderBox");
/*  959 */     int numComps = 3;
/*      */     
/*  961 */     if (header != null) {
/*  962 */       numComps = header.getNumComponents();
/*      */     }
/*      */     
/*  965 */     NodeList children = node.getChildNodes();
/*  966 */     boolean hasAlpha = false;
/*  967 */     boolean isPremultiplied = false;
/*      */     
/*  969 */     for (int i = 0; i < children.getLength(); i++) {
/*  970 */       Node child = children.item(i);
/*  971 */       String name = child.getNodeName();
/*      */       
/*  973 */       if (name.equals("Alpha")) {
/*  974 */         String value = (String)Box.getAttribute(child, "value");
/*  975 */         if (value.equals("premultiplied"))
/*  976 */           isPremultiplied = true; 
/*  977 */         if (value.equals("nonpremultiplied")) {
/*  978 */           hasAlpha = true;
/*      */         }
/*      */       } 
/*      */     } 
/*  982 */     if (!hasAlpha) {
/*      */       return;
/*      */     }
/*  985 */     int num = (short)(numComps * (isPremultiplied ? 3 : 2));
/*  986 */     short[] channels = new short[num];
/*  987 */     short[] types = new short[num];
/*  988 */     short[] associations = new short[num];
/*  989 */     ChannelDefinitionBox.fillBasedOnBands(numComps, isPremultiplied, channels, types, associations);
/*      */     
/*  991 */     replace("JPEG2000ChannelDefinitionBox", new ChannelDefinitionBox(channels, types, associations));
/*      */   }
/*      */ 
/*      */   
/*      */   private void replace(String name, Box box) {
/*  996 */     for (int i = this.boxes.size() - 1; i >= 0; i--) {
/*  997 */       Box box1 = this.boxes.get(i);
/*  998 */       if (name.equals(Box.getName(box1.getType()))) {
/*  999 */         this.boxes.set(i, box);
/*      */         
/*      */         return;
/*      */       } 
/*      */     } 
/* 1004 */     this.boxes.add(box);
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean insertNodeIntoTree(IIOMetadataNode root, IIOMetadataNode node) {
/* 1009 */     String name = node.getNodeName();
/* 1010 */     String parent = this.format.getParent(name);
/* 1011 */     if (parent == null) {
/* 1012 */       return false;
/*      */     }
/* 1014 */     IIOMetadataNode parentNode = getNodeFromTree(root, parent, name);
/* 1015 */     if (parentNode == null)
/* 1016 */       parentNode = createNodeIntoTree(root, parent); 
/* 1017 */     parentNode.appendChild(node);
/* 1018 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private IIOMetadataNode getNodeFromTree(IIOMetadataNode root, String name, String childName) {
/* 1024 */     if (name.equals(root.getNodeName())) {
/* 1025 */       return root;
/*      */     }
/* 1027 */     NodeList list = root.getChildNodes();
/* 1028 */     for (int i = 0; i < list.getLength(); i++) {
/* 1029 */       IIOMetadataNode node = (IIOMetadataNode)list.item(i);
/* 1030 */       if (node.getNodeName().equals(name)) {
/* 1031 */         if (!name.equals("JPEG2000UUIDInfoBox") || !checkUUIDInfoBox(node, childName))
/*      */         {
/*      */ 
/*      */           
/* 1035 */           return node; } 
/*      */       } else {
/* 1037 */         node = getNodeFromTree(node, name, childName);
/* 1038 */         if (node != null)
/* 1039 */           return node; 
/*      */       } 
/*      */     } 
/* 1042 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   private IIOMetadataNode createNodeIntoTree(IIOMetadataNode root, String name) {
/* 1047 */     IIOMetadataNode node = getNodeFromTree(root, name, (String)null);
/* 1048 */     if (node != null) {
/* 1049 */       return node;
/*      */     }
/* 1051 */     node = new IIOMetadataNode(name);
/*      */     
/* 1053 */     String parent = this.format.getParent(name);
/* 1054 */     IIOMetadataNode parentNode = createNodeIntoTree(root, parent);
/* 1055 */     parentNode.appendChild(node);
/*      */     
/* 1057 */     return node;
/*      */   }
/*      */   
/*      */   private boolean isOriginalSigned(SampleModel sampleModel) {
/* 1061 */     int type = sampleModel.getDataType();
/* 1062 */     if (type == 0 || type == 1)
/* 1063 */       return false; 
/* 1064 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean checkUUIDInfoBox(Node node, String childName) {
/* 1076 */     NodeList list = node.getChildNodes();
/* 1077 */     for (int i = 0; i < list.getLength(); i++) {
/* 1078 */       IIOMetadataNode child = (IIOMetadataNode)list.item(i);
/* 1079 */       String name = child.getNodeName();
/*      */       
/* 1081 */       if (name.equals(childName)) {
/* 1082 */         return true;
/*      */       }
/*      */     } 
/* 1085 */     return false;
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/jpeg2000/J2KMetadata.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */