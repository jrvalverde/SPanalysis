/*     */ package com.sun.media.imageioimpl.plugins.tiff;
/*     */ 
/*     */ import com.sun.media.imageio.plugins.tiff.TIFFCompressor;
/*     */ import com.sun.media.imageio.plugins.tiff.TIFFField;
/*     */ import javax.imageio.metadata.IIOMetadata;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TIFFFaxCompressor
/*     */   extends TIFFCompressor
/*     */ {
/*     */   public static final int WHITE = 0;
/*     */   public static final int BLACK = 1;
/* 106 */   public static byte[] byteTable = new byte[] { 8, 7, 6, 6, 5, 5, 5, 5, 4, 4, 4, 4, 4, 4, 4, 4, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 128 */   public static int[] termCodesBlack = new int[] { 230686730, 1073741827, -1073741822, -2147483646, 1610612739, 805306372, 536870916, 402653189, 335544326, 268435462, 134217735, 167772167, 234881031, 67108872, 117440520, 201326601, 96469002, 100663306, 33554442, 216006667, 218103819, 226492427, 115343371, 83886091, 48234507, 50331659, 211812364, 212860940, 213909516, 214958092, 109051916, 110100492, 111149068, 112197644, 220200972, 221249548, 222298124, 223346700, 224395276, 225443852, 113246220, 114294796, 228589580, 229638156, 88080396, 89128972, 90177548, 91226124, 104857612, 105906188, 85983244, 87031820, 37748748, 57671692, 58720268, 40894476, 41943052, 92274700, 93323276, 45088780, 46137356, 94371852, 106954764, 108003340 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 150 */   public static int[] termCodesWhite = new int[] { 889192456, 469762054, 1879048196, -2147483644, -1342177276, -1073741820, -536870908, -268435452, -1744830459, -1610612731, 939524101, 1073741829, 536870918, 201326598, -805306362, -738197498, -1476395002, -1409286138, 1308622855, 402653191, 268435463, 771751943, 100663303, 134217735, 1342177287, 1442840583, 637534215, 1207959559, 805306375, 33554440, 50331656, 436207624, 452984840, 301989896, 318767112, 335544328, 352321544, 369098760, 385875976, 671088648, 687865864, 704643080, 721420296, 738197512, 754974728, 67108872, 83886088, 167772168, 184549384, 1375731720, 1392508936, 1409286152, 1426063368, 603979784, 620757000, 1476395016, 1493172232, 1509949448, 1526726664, 1241513992, 1258291208, 838860808, 855638024, 872415240 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 172 */   public static int[] makeupCodesBlack = new int[] { 0, 62914570, 209715212, 210763788, 95420428, 53477388, 54525964, 55574540, 56623117, 57147405, 38797325, 39321613, 39845901, 40370189, 59768845, 60293133, 60817421, 61341709, 61865997, 62390285, 42991629, 43515917, 44040205, 44564493, 47185933, 47710221, 52428813, 52953101, 16777227, 25165835, 27262987, 18874380, 19922956, 20971532, 22020108, 23068684, 24117260, 29360140, 30408716, 31457292, 32505868, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 193 */   public static int[] makeupCodesWhite = new int[] { 0, -671088635, -1879048187, 1543503878, 1845493767, 905969672, 922746888, 1677721608, 1694498824, 1744830472, 1728053256, 1711276041, 1719664649, 1761607689, 1769996297, 1778384905, 1786773513, 1795162121, 1803550729, 1811939337, 1820327945, 1828716553, 1837105161, 1275068425, 1283457033, 1291845641, 1610612742, 1300234249, 16777227, 25165835, 27262987, 18874380, 19922956, 20971532, 22020108, 23068684, 24117260, 29360140, 30408716, 31457292, 32505868, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 214 */   public static int[] passMode = new int[] { 268435460 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 221 */   public static int[] vertMode = new int[] { 100663303, 201326598, 1610612739, -2147483647, 1073741827, 134217734, 67108871 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 234 */   public static int[] horzMode = new int[] { 536870915 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 241 */   public static int[][] termCodes = new int[][] { termCodesWhite, termCodesBlack };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 247 */   public static int[][] makeupCodes = new int[][] { makeupCodesWhite, makeupCodesBlack };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 253 */   public static int[][] pass = new int[][] { passMode, passMode };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 258 */   public static int[][] vert = new int[][] { vertMode, vertMode };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 263 */   public static int[][] horz = new int[][] { horzMode, horzMode };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean inverseFill = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int bits;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int ndex;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected TIFFFaxCompressor(String compressionType, int compressionTagValue, boolean isCompressionLossless) {
/* 289 */     super(compressionType, compressionTagValue, isCompressionLossless);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMetadata(IIOMetadata metadata) {
/* 304 */     super.setMetadata(metadata);
/*     */     
/* 306 */     if (metadata instanceof TIFFImageMetadata) {
/* 307 */       TIFFImageMetadata tim = (TIFFImageMetadata)metadata;
/* 308 */       TIFFField f = tim.getTIFFField(266);
/* 309 */       this.inverseFill = (f != null && f.getAsInt(0) == 2);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int nextState(byte[] data, int base, int bitOffset, int maxOffset) {
/*     */     int testbyte;
/* 322 */     if (data == null) {
/* 323 */       return maxOffset;
/*     */     }
/*     */     
/* 326 */     int next = base + (bitOffset >>> 3);
/*     */ 
/*     */     
/* 329 */     if (next >= data.length) {
/* 330 */       return maxOffset;
/*     */     }
/* 332 */     int end = base + (maxOffset >>> 3);
/* 333 */     if (end == data.length) {
/* 334 */       end--;
/*     */     }
/* 336 */     int extra = bitOffset & 0x7;
/*     */ 
/*     */ 
/*     */     
/* 340 */     if ((data[next] & 128 >>> extra) != 0) {
/* 341 */       testbyte = (data[next] ^ 0xFFFFFFFF) & 255 >>> extra;
/* 342 */       while (next < end && 
/* 343 */         testbyte == 0)
/*     */       {
/*     */         
/* 346 */         testbyte = (data[++next] ^ 0xFFFFFFFF) & 0xFF;
/*     */       }
/*     */     } else {
/* 349 */       if ((testbyte = data[next] & 255 >>> extra) != 0) {
/* 350 */         bitOffset = (next - base) * 8 + byteTable[testbyte];
/* 351 */         return (bitOffset < maxOffset) ? bitOffset : maxOffset;
/*     */       } 
/* 353 */       while (next < end) {
/* 354 */         if ((testbyte = data[++next] & 0xFF) != 0) {
/*     */           
/* 356 */           bitOffset = (next - base) * 8 + byteTable[testbyte];
/* 357 */           return (bitOffset < maxOffset) ? bitOffset : maxOffset;
/*     */         } 
/*     */       } 
/*     */     } 
/* 361 */     bitOffset = (next - base) * 8 + byteTable[testbyte];
/* 362 */     return (bitOffset < maxOffset) ? bitOffset : maxOffset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initBitBuf() {
/* 370 */     this.ndex = 0;
/* 371 */     this.bits = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int add1DBits(byte[] buf, int where, int count, int color) {
/* 384 */     int len = where;
/*     */     
/* 386 */     int sixtyfours = count >>> 6;
/* 387 */     count &= 0x3F;
/* 388 */     if (sixtyfours != 0) {
/* 389 */       for (; sixtyfours > 40; sixtyfours -= 40) {
/* 390 */         int j = makeupCodes[color][40];
/* 391 */         this.bits |= (j & 0xFFF80000) >>> this.ndex;
/* 392 */         this.ndex += j & 0xFFFF;
/* 393 */         while (this.ndex > 7) {
/* 394 */           buf[len++] = (byte)(this.bits >>> 24);
/* 395 */           this.bits <<= 8;
/* 396 */           this.ndex -= 8;
/*     */         } 
/*     */       } 
/*     */       
/* 400 */       int i = makeupCodes[color][sixtyfours];
/* 401 */       this.bits |= (i & 0xFFF80000) >>> this.ndex;
/* 402 */       this.ndex += i & 0xFFFF;
/* 403 */       while (this.ndex > 7) {
/* 404 */         buf[len++] = (byte)(this.bits >>> 24);
/* 405 */         this.bits <<= 8;
/* 406 */         this.ndex -= 8;
/*     */       } 
/*     */     } 
/*     */     
/* 410 */     int mask = termCodes[color][count];
/* 411 */     this.bits |= (mask & 0xFFF80000) >>> this.ndex;
/* 412 */     this.ndex += mask & 0xFFFF;
/* 413 */     while (this.ndex > 7) {
/* 414 */       buf[len++] = (byte)(this.bits >>> 24);
/* 415 */       this.bits <<= 8;
/* 416 */       this.ndex -= 8;
/*     */     } 
/*     */     
/* 419 */     return len - where;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int add2DBits(byte[] buf, int where, int[][] mode, int entry) {
/* 431 */     int len = where;
/* 432 */     int color = 0;
/*     */     
/* 434 */     int mask = mode[color][entry];
/* 435 */     this.bits |= (mask & 0xFFF80000) >>> this.ndex;
/* 436 */     this.ndex += mask & 0xFFFF;
/* 437 */     while (this.ndex > 7) {
/* 438 */       buf[len++] = (byte)(this.bits >>> 24);
/* 439 */       this.bits <<= 8;
/* 440 */       this.ndex -= 8;
/*     */     } 
/*     */     
/* 443 */     return len - where;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int addEOL(boolean is1DMode, boolean addFill, boolean add1, byte[] buf, int where) {
/* 456 */     int len = where;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 463 */     if (addFill)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 471 */       this.ndex += (this.ndex <= 4) ? (4 - this.ndex) : (12 - this.ndex);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 477 */     if (is1DMode) {
/* 478 */       this.bits |= 1048576 >>> this.ndex;
/* 479 */       this.ndex += 12;
/*     */     } else {
/* 481 */       this.bits |= (add1 ? 1572864 : 1048576) >>> this.ndex;
/* 482 */       this.ndex += 13;
/*     */     } 
/*     */     
/* 485 */     while (this.ndex > 7) {
/* 486 */       buf[len++] = (byte)(this.bits >>> 24);
/* 487 */       this.bits <<= 8;
/* 488 */       this.ndex -= 8;
/*     */     } 
/*     */     
/* 491 */     return len - where;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int addEOFB(byte[] buf, int where) {
/* 501 */     int len = where;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 506 */     this.bits |= 1048832 >>> this.ndex;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 511 */     this.ndex += 24;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 516 */     while (this.ndex > 0) {
/* 517 */       buf[len++] = (byte)(this.bits >>> 24);
/* 518 */       this.bits <<= 8;
/* 519 */       this.ndex -= 8;
/*     */     } 
/*     */     
/* 522 */     return len - where;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int encode1D(byte[] data, int rowOffset, int colOffset, int rowLength, byte[] compData, int compOffset) {
/* 538 */     int lineAddr = rowOffset;
/* 539 */     int bitIndex = colOffset;
/*     */     
/* 541 */     int last = bitIndex + rowLength;
/* 542 */     int outIndex = compOffset;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 547 */     int testbit = (data[lineAddr + (bitIndex >>> 3)] & 0xFF) >>> 7 - (bitIndex & 0x7) & 0x1;
/*     */ 
/*     */     
/* 550 */     int currentColor = 1;
/* 551 */     if (testbit != 0) {
/* 552 */       outIndex += add1DBits(compData, outIndex, 0, 0);
/*     */     } else {
/* 554 */       currentColor = 0;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 560 */     while (bitIndex < last) {
/* 561 */       int bitCount = nextState(data, lineAddr, bitIndex, last) - bitIndex;
/*     */       
/* 563 */       outIndex += add1DBits(compData, outIndex, bitCount, currentColor);
/*     */       
/* 565 */       bitIndex += bitCount;
/* 566 */       currentColor ^= 0x1;
/*     */     } 
/*     */     
/* 569 */     return outIndex - compOffset;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/tiff/TIFFFaxCompressor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */