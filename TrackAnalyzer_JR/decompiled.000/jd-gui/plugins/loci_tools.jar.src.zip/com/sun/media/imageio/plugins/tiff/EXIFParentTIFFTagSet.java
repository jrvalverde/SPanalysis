/*     */ package com.sun.media.imageio.plugins.tiff;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EXIFParentTIFFTagSet
/*     */   extends TIFFTagSet
/*     */ {
/*  95 */   private static EXIFParentTIFFTagSet theInstance = null;
/*     */   
/*     */   public static final int TAG_EXIF_IFD_POINTER = 34665;
/*     */   
/*     */   public static final int TAG_GPS_INFO_IFD_POINTER = 34853;
/*     */   
/*     */   private static List tags;
/*     */ 
/*     */   
/*     */   static class EXIFIFDPointer
/*     */     extends TIFFTag
/*     */   {
/*     */     public EXIFIFDPointer() {
/* 108 */       super("EXIFIFDPointer", 34665, 16, EXIFTIFFTagSet.getInstance());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class GPSInfoIFDPointer
/*     */     extends TIFFTag
/*     */   {
/*     */     public GPSInfoIFDPointer() {
/* 119 */       super("GPSInfoIFDPointer", 34853, 16, EXIFGPSTagSet.getInstance());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void initTags() {
/* 129 */     tags = new ArrayList(1);
/* 130 */     tags.add(new EXIFIFDPointer());
/* 131 */     tags.add(new GPSInfoIFDPointer());
/*     */   }
/*     */   
/*     */   private EXIFParentTIFFTagSet() {
/* 135 */     super(tags);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized EXIFParentTIFFTagSet getInstance() {
/* 144 */     if (theInstance == null) {
/* 145 */       initTags();
/* 146 */       theInstance = new EXIFParentTIFFTagSet();
/* 147 */       tags = null;
/*     */     } 
/* 149 */     return theInstance;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageio/plugins/tiff/EXIFParentTIFFTagSet.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */