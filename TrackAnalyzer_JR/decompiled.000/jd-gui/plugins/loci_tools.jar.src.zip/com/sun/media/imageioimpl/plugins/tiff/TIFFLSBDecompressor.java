/*     */ package com.sun.media.imageioimpl.plugins.tiff;
/*     */ 
/*     */ import com.sun.media.imageio.plugins.tiff.TIFFDecompressor;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TIFFLSBDecompressor
/*     */   extends TIFFDecompressor
/*     */ {
/*  91 */   private static byte[] flipTable = TIFFFaxDecompressor.flipTable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void decodeRaw(byte[] b, int dstOffset, int bitsPerPixel, int scanlineStride) throws IOException {
/*  99 */     this.stream.seek(this.offset);
/*     */     
/* 101 */     int bytesPerRow = (this.srcWidth * bitsPerPixel + 7) / 8;
/* 102 */     if (bytesPerRow == scanlineStride) {
/* 103 */       int numBytes = bytesPerRow * this.srcHeight;
/* 104 */       this.stream.readFully(b, dstOffset, numBytes);
/* 105 */       int xMax = dstOffset + numBytes;
/* 106 */       for (int x = dstOffset; x < xMax; x++) {
/* 107 */         b[x] = flipTable[b[x] & 0xFF];
/*     */       }
/*     */     } else {
/* 110 */       for (int y = 0; y < this.srcHeight; y++) {
/* 111 */         this.stream.readFully(b, dstOffset, bytesPerRow);
/* 112 */         int xMax = dstOffset + bytesPerRow;
/* 113 */         for (int x = dstOffset; x < xMax; x++) {
/* 114 */           b[x] = flipTable[b[x] & 0xFF];
/*     */         }
/* 116 */         dstOffset += scanlineStride;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/tiff/TIFFLSBDecompressor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */