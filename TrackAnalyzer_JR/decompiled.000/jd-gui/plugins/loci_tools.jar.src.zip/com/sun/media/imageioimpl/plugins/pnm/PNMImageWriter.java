/*     */ package com.sun.media.imageioimpl.plugins.pnm;
/*     */ 
/*     */ import com.sun.media.imageio.plugins.pnm.PNMImageWriteParam;
/*     */ import com.sun.media.imageioimpl.common.ImageUtil;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.color.ColorSpace;
/*     */ import java.awt.image.ColorModel;
/*     */ import java.awt.image.ComponentSampleModel;
/*     */ import java.awt.image.DataBufferByte;
/*     */ import java.awt.image.IndexColorModel;
/*     */ import java.awt.image.MultiPixelPackedSampleModel;
/*     */ import java.awt.image.Raster;
/*     */ import java.awt.image.RenderedImage;
/*     */ import java.awt.image.SampleModel;
/*     */ import java.io.IOException;
/*     */ import java.security.AccessController;
/*     */ import java.util.Iterator;
/*     */ import javax.imageio.IIOException;
/*     */ import javax.imageio.IIOImage;
/*     */ import javax.imageio.ImageTypeSpecifier;
/*     */ import javax.imageio.ImageWriteParam;
/*     */ import javax.imageio.ImageWriter;
/*     */ import javax.imageio.metadata.IIOInvalidTreeException;
/*     */ import javax.imageio.metadata.IIOMetadata;
/*     */ import javax.imageio.spi.ImageWriterSpi;
/*     */ import javax.imageio.stream.ImageOutputStream;
/*     */ import sun.security.action.GetPropertyAction;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PNMImageWriter
/*     */   extends ImageWriter
/*     */ {
/*     */   private static final int PBM_ASCII = 49;
/*     */   private static final int PGM_ASCII = 50;
/*     */   private static final int PPM_ASCII = 51;
/*     */   private static final int PBM_RAW = 52;
/*     */   private static final int PGM_RAW = 53;
/*     */   private static final int PPM_RAW = 54;
/*     */   private static final int SPACE = 32;
/*     */   private static final String COMMENT = "# written by com.sun.media.imageioimpl.PNMImageWriter";
/*     */   private static byte[] lineSeparator;
/*     */   private int variant;
/*     */   private int maxValue;
/*     */   
/*     */   static {
/* 146 */     if (lineSeparator == null) {
/* 147 */       String ls = AccessController.<String>doPrivileged(new GetPropertyAction("line.separator"));
/*     */       
/* 149 */       lineSeparator = ls.getBytes();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/* 154 */   private ImageOutputStream stream = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PNMImageWriter(ImageWriterSpi originator) {
/* 160 */     super(originator);
/*     */   }
/*     */   
/*     */   public void setOutput(Object output) {
/* 164 */     super.setOutput(output);
/* 165 */     if (output != null) {
/* 166 */       if (!(output instanceof ImageOutputStream))
/* 167 */         throw new IllegalArgumentException(I18N.getString("PNMImageWriter0")); 
/* 168 */       this.stream = (ImageOutputStream)output;
/*     */     } else {
/* 170 */       this.stream = null;
/*     */     } 
/*     */   }
/*     */   public ImageWriteParam getDefaultWriteParam() {
/* 174 */     return (ImageWriteParam)new PNMImageWriteParam();
/*     */   }
/*     */   
/*     */   public IIOMetadata getDefaultStreamMetadata(ImageWriteParam param) {
/* 178 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public IIOMetadata getDefaultImageMetadata(ImageTypeSpecifier imageType, ImageWriteParam param) {
/* 183 */     return new PNMMetadata(imageType, param);
/*     */   }
/*     */ 
/*     */   
/*     */   public IIOMetadata convertStreamMetadata(IIOMetadata inData, ImageWriteParam param) {
/* 188 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IIOMetadata convertImageMetadata(IIOMetadata inData, ImageTypeSpecifier imageType, ImageWriteParam param) {
/* 195 */     if (inData == null) {
/* 196 */       throw new IllegalArgumentException("inData == null!");
/*     */     }
/* 198 */     if (imageType == null) {
/* 199 */       throw new IllegalArgumentException("imageType == null!");
/*     */     }
/*     */     
/* 202 */     PNMMetadata outData = null;
/*     */ 
/*     */     
/* 205 */     if (inData instanceof PNMMetadata) {
/*     */       
/* 207 */       outData = (PNMMetadata)((PNMMetadata)inData).clone();
/*     */     } else {
/*     */       try {
/* 210 */         outData = new PNMMetadata(inData);
/* 211 */       } catch (IIOInvalidTreeException e) {
/*     */         
/* 213 */         outData = new PNMMetadata();
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 218 */     outData.initialize(imageType, param);
/*     */     
/* 220 */     return outData;
/*     */   }
/*     */   
/*     */   public boolean canWriteRasters() {
/* 224 */     return true;
/*     */   }
/*     */   public void write(IIOMetadata streamMetadata, IIOImage image, ImageWriteParam param) throws IOException {
/*     */     ImageTypeSpecifier imageType;
/*     */     PNMMetadata metadata;
/*     */     boolean isRawPNM;
/* 230 */     clearAbortRequest();
/* 231 */     processImageStarted(0);
/* 232 */     if (param == null) {
/* 233 */       param = getDefaultWriteParam();
/*     */     }
/* 235 */     RenderedImage input = null;
/* 236 */     Raster inputRaster = null;
/* 237 */     boolean writeRaster = image.hasRaster();
/* 238 */     Rectangle sourceRegion = param.getSourceRegion();
/* 239 */     SampleModel sampleModel = null;
/* 240 */     ColorModel colorModel = null;
/*     */     
/* 242 */     if (writeRaster)
/* 243 */     { inputRaster = image.getRaster();
/* 244 */       sampleModel = inputRaster.getSampleModel();
/* 245 */       if (sourceRegion == null) {
/* 246 */         sourceRegion = inputRaster.getBounds();
/*     */       } else {
/* 248 */         sourceRegion = sourceRegion.intersection(inputRaster.getBounds());
/*     */       }  }
/* 250 */     else { input = image.getRenderedImage();
/* 251 */       sampleModel = input.getSampleModel();
/* 252 */       colorModel = input.getColorModel();
/* 253 */       Rectangle rect = new Rectangle(input.getMinX(), input.getMinY(), input.getWidth(), input.getHeight());
/*     */       
/* 255 */       if (sourceRegion == null) {
/* 256 */         sourceRegion = rect;
/*     */       } else {
/* 258 */         sourceRegion = sourceRegion.intersection(rect);
/*     */       }  }
/*     */     
/* 261 */     if (sourceRegion.isEmpty()) {
/* 262 */       throw new RuntimeException(I18N.getString("PNMImageWrite1"));
/*     */     }
/* 264 */     ImageUtil.canEncodeImage(this, colorModel, sampleModel);
/*     */     
/* 266 */     int scaleX = param.getSourceXSubsampling();
/* 267 */     int scaleY = param.getSourceYSubsampling();
/* 268 */     int xOffset = param.getSubsamplingXOffset();
/* 269 */     int yOffset = param.getSubsamplingYOffset();
/*     */     
/* 271 */     sourceRegion.translate(xOffset, yOffset);
/* 272 */     sourceRegion.width -= xOffset;
/* 273 */     sourceRegion.height -= yOffset;
/*     */     
/* 275 */     int minX = sourceRegion.x / scaleX;
/* 276 */     int minY = sourceRegion.y / scaleY;
/* 277 */     int w = (sourceRegion.width + scaleX - 1) / scaleX;
/* 278 */     int h = (sourceRegion.height + scaleY - 1) / scaleY;
/*     */     
/* 280 */     Rectangle destinationRegion = new Rectangle(minX, minY, w, h);
/*     */     
/* 282 */     int tileHeight = sampleModel.getHeight();
/* 283 */     int tileWidth = sampleModel.getWidth();
/*     */ 
/*     */     
/* 286 */     int[] sampleSize = sampleModel.getSampleSize();
/* 287 */     int[] sourceBands = param.getSourceBands();
/* 288 */     boolean noSubband = true;
/* 289 */     int numBands = sampleModel.getNumBands();
/*     */     
/* 291 */     if (sourceBands != null) {
/* 292 */       sampleModel = sampleModel.createSubsetSampleModel(sourceBands);
/* 293 */       colorModel = null;
/* 294 */       noSubband = false;
/* 295 */       numBands = sampleModel.getNumBands();
/*     */     } else {
/* 297 */       sourceBands = new int[numBands];
/* 298 */       for (int j = 0; j < numBands; j++) {
/* 299 */         sourceBands[j] = j;
/*     */       }
/*     */     } 
/*     */     
/* 303 */     byte[] reds = null;
/* 304 */     byte[] greens = null;
/* 305 */     byte[] blues = null;
/*     */ 
/*     */     
/* 308 */     boolean isPBMInverted = false;
/*     */     
/* 310 */     if (numBands == 1) {
/* 311 */       if (colorModel instanceof IndexColorModel) {
/* 312 */         IndexColorModel icm = (IndexColorModel)colorModel;
/*     */         
/* 314 */         int mapSize = icm.getMapSize();
/* 315 */         if (mapSize < 1 << sampleSize[0]) {
/* 316 */           throw new RuntimeException(I18N.getString("PNMImageWrite2"));
/*     */         }
/* 318 */         if (sampleSize[0] == 1) {
/* 319 */           this.variant = 52;
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 324 */           isPBMInverted = (icm.getRed(1) > icm.getRed(0));
/*     */         } else {
/* 326 */           this.variant = 54;
/*     */           
/* 328 */           reds = new byte[mapSize];
/* 329 */           greens = new byte[mapSize];
/* 330 */           blues = new byte[mapSize];
/*     */           
/* 332 */           icm.getReds(reds);
/* 333 */           icm.getGreens(greens);
/* 334 */           icm.getBlues(blues);
/*     */         } 
/* 336 */       } else if (sampleSize[0] == 1) {
/* 337 */         this.variant = 52;
/* 338 */       } else if (sampleSize[0] <= 8) {
/* 339 */         this.variant = 53;
/*     */       } else {
/* 341 */         this.variant = 50;
/*     */       } 
/* 343 */     } else if (numBands == 3) {
/* 344 */       if (sampleSize[0] <= 8 && sampleSize[1] <= 8 && sampleSize[2] <= 8) {
/*     */         
/* 346 */         this.variant = 54;
/*     */       } else {
/* 348 */         this.variant = 51;
/*     */       } 
/*     */     } else {
/* 351 */       throw new RuntimeException(I18N.getString("PNMImageWrite3"));
/*     */     } 
/*     */     
/* 354 */     IIOMetadata inputMetadata = image.getMetadata();
/*     */     
/* 356 */     if (colorModel != null) {
/* 357 */       imageType = new ImageTypeSpecifier(colorModel, sampleModel);
/*     */     } else {
/* 359 */       ColorSpace cs; int dataType = sampleModel.getDataType();
/* 360 */       switch (numBands) {
/*     */         case 1:
/* 362 */           imageType = ImageTypeSpecifier.createGrayscale(sampleSize[0], dataType, false);
/*     */           break;
/*     */ 
/*     */         
/*     */         case 3:
/* 367 */           cs = ColorSpace.getInstance(1000);
/* 368 */           imageType = ImageTypeSpecifier.createInterleaved(cs, new int[] { 0, 1, 2 }, dataType, false, false);
/*     */           break;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         default:
/* 375 */           throw new IIOException("Cannot encode image with " + numBands + " bands!");
/*     */       } 
/*     */ 
/*     */ 
/*     */     
/*     */     } 
/* 381 */     if (inputMetadata != null) {
/*     */       
/* 383 */       metadata = (PNMMetadata)convertImageMetadata(inputMetadata, imageType, param);
/*     */     }
/*     */     else {
/*     */       
/* 387 */       metadata = (PNMMetadata)getDefaultImageMetadata(imageType, param);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 392 */     if (param instanceof PNMImageWriteParam) {
/* 393 */       isRawPNM = ((PNMImageWriteParam)param).getRaw();
/*     */     } else {
/* 395 */       isRawPNM = metadata.isRaw();
/*     */     } 
/*     */     
/* 398 */     this.maxValue = metadata.getMaxValue();
/* 399 */     for (int i = 0; i < sampleSize.length; i++) {
/* 400 */       int v = (1 << sampleSize[i]) - 1;
/* 401 */       if (v > this.maxValue) {
/* 402 */         this.maxValue = v;
/*     */       }
/*     */     } 
/*     */     
/* 406 */     if (isRawPNM) {
/*     */       
/* 408 */       int maxBitDepth = metadata.getMaxBitDepth();
/* 409 */       if (!isRaw(this.variant) && maxBitDepth <= 8) {
/*     */ 
/*     */         
/* 412 */         this.variant += 3;
/* 413 */       } else if (isRaw(this.variant) && maxBitDepth > 8) {
/*     */ 
/*     */         
/* 416 */         this.variant -= 3;
/*     */       }
/*     */     
/*     */     }
/* 420 */     else if (isRaw(this.variant)) {
/*     */       
/* 422 */       this.variant -= 3;
/*     */     } 
/*     */ 
/*     */     
/* 426 */     this.stream.writeByte(80);
/* 427 */     this.stream.writeByte(this.variant);
/*     */     
/* 429 */     this.stream.write(lineSeparator);
/* 430 */     this.stream.write("# written by com.sun.media.imageioimpl.PNMImageWriter".getBytes());
/*     */ 
/*     */     
/* 433 */     Iterator<String> comments = metadata.getComments();
/* 434 */     if (comments != null) {
/* 435 */       while (comments.hasNext()) {
/* 436 */         this.stream.write(lineSeparator);
/* 437 */         String comment = "# " + (String)comments.next();
/* 438 */         this.stream.write(comment.getBytes());
/*     */       } 
/*     */     }
/*     */     
/* 442 */     this.stream.write(lineSeparator);
/* 443 */     writeInteger(this.stream, w);
/* 444 */     this.stream.write(32);
/* 445 */     writeInteger(this.stream, h);
/*     */ 
/*     */     
/* 448 */     if (this.variant != 52 && this.variant != 49) {
/* 449 */       this.stream.write(lineSeparator);
/* 450 */       writeInteger(this.stream, this.maxValue);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 455 */     if (this.variant == 52 || this.variant == 53 || this.variant == 54)
/*     */     {
/*     */       
/* 458 */       this.stream.write(10);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 463 */     boolean writeOptimal = false;
/* 464 */     if (this.variant == 52 && sampleModel.getTransferType() == 0 && sampleModel instanceof MultiPixelPackedSampleModel) {
/*     */ 
/*     */ 
/*     */       
/* 468 */       MultiPixelPackedSampleModel mppsm = (MultiPixelPackedSampleModel)sampleModel;
/*     */ 
/*     */       
/* 471 */       int originX = 0;
/* 472 */       if (writeRaster) {
/* 473 */         originX = inputRaster.getMinX();
/*     */       } else {
/* 475 */         originX = input.getMinX();
/*     */       } 
/*     */       
/* 478 */       if (mppsm.getBitOffset((sourceRegion.x - originX) % tileWidth) == 0 && mppsm.getPixelBitStride() == 1 && scaleX == 1)
/*     */       {
/* 480 */         writeOptimal = true; } 
/* 481 */     } else if ((this.variant == 53 || this.variant == 54) && sampleModel instanceof ComponentSampleModel && !(colorModel instanceof IndexColorModel)) {
/*     */ 
/*     */ 
/*     */       
/* 485 */       ComponentSampleModel csm = (ComponentSampleModel)sampleModel;
/*     */ 
/*     */ 
/*     */       
/* 489 */       if (csm.getPixelStride() == numBands && scaleX == 1) {
/* 490 */         writeOptimal = true;
/*     */ 
/*     */         
/* 493 */         if (this.variant == 54) {
/* 494 */           int[] bandOffsets = csm.getBandOffsets();
/* 495 */           for (int b = 0; b < numBands; b++) {
/* 496 */             if (bandOffsets[b] != b) {
/* 497 */               writeOptimal = false;
/*     */               
/*     */               break;
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 506 */     if (writeOptimal) {
/* 507 */       int bytesPerRow = (this.variant == 52) ? ((w + 7) / 8) : (w * sampleModel.getNumBands());
/*     */       
/* 509 */       byte[] bdata = null;
/* 510 */       byte[] invertedData = new byte[bytesPerRow];
/*     */ 
/*     */       
/* 513 */       for (int j = 0; j < sourceRegion.height && 
/* 514 */         !abortRequested(); j++) {
/*     */         
/* 516 */         Raster lineRaster = null;
/* 517 */         if (writeRaster) {
/* 518 */           lineRaster = inputRaster.createChild(sourceRegion.x, j, sourceRegion.width, 1, 0, 0, null);
/*     */         
/*     */         }
/*     */         else {
/*     */           
/* 523 */           lineRaster = input.getData(new Rectangle(sourceRegion.x, sourceRegion.y + j, w, 1));
/*     */ 
/*     */ 
/*     */           
/* 527 */           lineRaster = lineRaster.createTranslatedChild(0, 0);
/*     */         } 
/*     */         
/* 530 */         bdata = ((DataBufferByte)lineRaster.getDataBuffer()).getData();
/*     */         
/* 532 */         sampleModel = lineRaster.getSampleModel();
/* 533 */         int offset = 0;
/* 534 */         if (sampleModel instanceof ComponentSampleModel) {
/* 535 */           offset = ((ComponentSampleModel)sampleModel).getOffset(lineRaster.getMinX() - lineRaster.getSampleModelTranslateX(), lineRaster.getMinY() - lineRaster.getSampleModelTranslateY());
/*     */         
/*     */         }
/* 538 */         else if (sampleModel instanceof MultiPixelPackedSampleModel) {
/* 539 */           offset = ((MultiPixelPackedSampleModel)sampleModel).getOffset(lineRaster.getMinX() - lineRaster.getSampleModelTranslateX(), lineRaster.getMinX() - lineRaster.getSampleModelTranslateY());
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 544 */         if (isPBMInverted) {
/* 545 */           for (int k = offset, m = 0; m < bytesPerRow; k++, m++)
/* 546 */             invertedData[m] = (byte)(bdata[k] ^ 0xFFFFFFFF); 
/* 547 */           bdata = invertedData;
/* 548 */           offset = 0;
/*     */         } 
/*     */         
/* 551 */         this.stream.write(bdata, offset, bytesPerRow);
/* 552 */         processImageProgress(100.0F * j / sourceRegion.height);
/*     */       } 
/*     */ 
/*     */       
/* 556 */       this.stream.flush();
/* 557 */       if (abortRequested()) {
/* 558 */         processWriteAborted();
/*     */       } else {
/* 560 */         processImageComplete();
/*     */       } 
/*     */       
/*     */       return;
/*     */     } 
/* 565 */     int size = sourceRegion.width * numBands;
/*     */     
/* 567 */     int[] pixels = new int[size];
/*     */ 
/*     */ 
/*     */     
/* 571 */     byte[] bpixels = (reds == null) ? new byte[w * numBands] : new byte[w * 3];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 577 */     int count = 0;
/*     */ 
/*     */     
/* 580 */     int lastRow = sourceRegion.y + sourceRegion.height;
/*     */     int row;
/* 582 */     for (row = sourceRegion.y; row < lastRow && 
/* 583 */       !abortRequested(); row += scaleY) {
/*     */       int k, kdst, ksrc, b, pos, m, j;
/*     */       
/* 586 */       Raster src = null;
/*     */       
/* 588 */       if (writeRaster) {
/* 589 */         src = inputRaster.createChild(sourceRegion.x, row, sourceRegion.width, 1, sourceRegion.x, row, sourceBands);
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 594 */         src = input.getData(new Rectangle(sourceRegion.x, row, sourceRegion.width, 1));
/*     */       } 
/* 596 */       src.getPixels(sourceRegion.x, row, sourceRegion.width, 1, pixels);
/*     */       
/* 598 */       if (isPBMInverted) {
/* 599 */         int n; for (n = 0; n < size; n += scaleX)
/* 600 */           bpixels[n] = (byte)(bpixels[n] ^ 0x1); 
/*     */       } 
/* 602 */       switch (this.variant) {
/*     */         case 49:
/*     */         case 50:
/* 605 */           for (k = 0; k < size; k += scaleX) {
/* 606 */             if (count++ % 16 == 0) {
/* 607 */               this.stream.write(lineSeparator);
/*     */             } else {
/* 609 */               this.stream.write(32);
/*     */             } 
/* 611 */             writeInteger(this.stream, pixels[k]);
/*     */           } 
/* 613 */           this.stream.write(lineSeparator);
/*     */           break;
/*     */         
/*     */         case 51:
/* 617 */           if (reds == null) {
/* 618 */             int[] bandOffset = ((ComponentSampleModel)sampleModel).getBandOffsets();
/*     */             int n;
/* 620 */             for (n = 0; n < size; n += scaleX * numBands) {
/* 621 */               for (int i1 = 0; i1 < numBands; i1++) {
/* 622 */                 if (count++ % 16 == 0) {
/* 623 */                   this.stream.write(lineSeparator);
/*     */                 } else {
/* 625 */                   this.stream.write(32);
/*     */                 } 
/* 627 */                 writeInteger(this.stream, pixels[n + i1]);
/*     */               } 
/*     */             } 
/*     */           } else {
/* 631 */             for (k = 0; k < size; k += scaleX) {
/* 632 */               if (count++ % 5 == 0) {
/* 633 */                 this.stream.write(lineSeparator);
/*     */               } else {
/* 635 */                 this.stream.write(32);
/*     */               } 
/* 637 */               writeInteger(this.stream, reds[pixels[k]] & 0xFF);
/* 638 */               this.stream.write(32);
/* 639 */               writeInteger(this.stream, greens[pixels[k]] & 0xFF);
/* 640 */               this.stream.write(32);
/* 641 */               writeInteger(this.stream, blues[pixels[k]] & 0xFF);
/*     */             } 
/*     */           } 
/* 644 */           this.stream.write(lineSeparator);
/*     */           break;
/*     */ 
/*     */         
/*     */         case 52:
/* 649 */           kdst = 0;
/* 650 */           ksrc = 0;
/* 651 */           b = 0;
/* 652 */           pos = 7;
/* 653 */           for (m = 0; m < size; m += scaleX) {
/* 654 */             b |= pixels[m] << pos;
/* 655 */             pos--;
/* 656 */             if (pos == -1) {
/* 657 */               bpixels[kdst++] = (byte)b;
/* 658 */               b = 0;
/* 659 */               pos = 7;
/*     */             } 
/*     */           } 
/*     */           
/* 663 */           if (pos != 7) {
/* 664 */             bpixels[kdst++] = (byte)b;
/*     */           }
/* 666 */           this.stream.write(bpixels, 0, kdst);
/*     */           break;
/*     */         
/*     */         case 53:
/* 670 */           for (m = 0, j = 0; m < size; m += scaleX) {
/* 671 */             bpixels[j++] = (byte)pixels[m];
/*     */           }
/* 673 */           this.stream.write(bpixels, 0, w);
/*     */           break;
/*     */         
/*     */         case 54:
/* 677 */           if (reds == null) {
/* 678 */             int n; for (m = 0, n = 0; m < size; m += scaleX * numBands) {
/* 679 */               for (int i1 = 0; i1 < numBands; i1++)
/* 680 */                 bpixels[n++] = (byte)(pixels[m + i1] & 0xFF); 
/*     */             } 
/*     */           } else {
/* 683 */             for (m = 0, j = 0; m < size; m += scaleX) {
/* 684 */               bpixels[j++] = reds[pixels[m]];
/* 685 */               bpixels[j++] = greens[pixels[m]];
/* 686 */               bpixels[j++] = blues[pixels[m]];
/*     */             } 
/*     */           } 
/* 689 */           this.stream.write(bpixels, 0, bpixels.length);
/*     */           break;
/*     */       } 
/*     */       
/* 693 */       processImageProgress(100.0F * (row - sourceRegion.y) / sourceRegion.height);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 698 */     this.stream.flush();
/*     */     
/* 700 */     if (abortRequested()) {
/* 701 */       processWriteAborted();
/*     */     } else {
/* 703 */       processImageComplete();
/*     */     } 
/*     */   }
/*     */   public void reset() {
/* 707 */     super.reset();
/* 708 */     this.stream = null;
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeInteger(ImageOutputStream output, int i) throws IOException {
/* 713 */     output.write(Integer.toString(i).getBytes());
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeByte(ImageOutputStream output, byte b) throws IOException {
/* 718 */     output.write(Byte.toString(b).getBytes());
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isRaw(int v) {
/* 723 */     return (v >= 52);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/pnm/PNMImageWriter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */