/*      */ package com.sun.media.imageioimpl.plugins.bmp;
/*      */ 
/*      */ import com.sun.media.imageio.plugins.bmp.BMPImageWriteParam;
/*      */ import com.sun.media.imageioimpl.common.ImageUtil;
/*      */ import java.awt.Rectangle;
/*      */ import java.awt.image.ColorModel;
/*      */ import java.awt.image.ComponentSampleModel;
/*      */ import java.awt.image.DataBuffer;
/*      */ import java.awt.image.DataBufferByte;
/*      */ import java.awt.image.DataBufferInt;
/*      */ import java.awt.image.DataBufferShort;
/*      */ import java.awt.image.DataBufferUShort;
/*      */ import java.awt.image.DirectColorModel;
/*      */ import java.awt.image.IndexColorModel;
/*      */ import java.awt.image.MultiPixelPackedSampleModel;
/*      */ import java.awt.image.Raster;
/*      */ import java.awt.image.RenderedImage;
/*      */ import java.awt.image.SampleModel;
/*      */ import java.awt.image.SinglePixelPackedSampleModel;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.nio.ByteOrder;
/*      */ import java.util.Iterator;
/*      */ import javax.imageio.IIOException;
/*      */ import javax.imageio.IIOImage;
/*      */ import javax.imageio.ImageIO;
/*      */ import javax.imageio.ImageTypeSpecifier;
/*      */ import javax.imageio.ImageWriteParam;
/*      */ import javax.imageio.ImageWriter;
/*      */ import javax.imageio.event.IIOWriteProgressListener;
/*      */ import javax.imageio.event.IIOWriteWarningListener;
/*      */ import javax.imageio.metadata.IIOInvalidTreeException;
/*      */ import javax.imageio.metadata.IIOMetadata;
/*      */ import javax.imageio.spi.ImageWriterSpi;
/*      */ import javax.imageio.stream.ImageOutputStream;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class BMPImageWriter
/*      */   extends ImageWriter
/*      */   implements BMPConstants
/*      */ {
/*  140 */   private ImageOutputStream stream = null;
/*  141 */   private ByteArrayOutputStream embedded_stream = null; private int compressionType;
/*      */   private boolean isTopDown;
/*      */   private int w;
/*      */   private int h;
/*  145 */   private int compImageSize = 0;
/*      */   
/*      */   private int[] bitMasks;
/*      */   
/*      */   private int[] bitPos;
/*      */   
/*      */   private byte[] bpixels;
/*      */   private short[] spixels;
/*      */   private int[] ipixels;
/*      */   
/*      */   public BMPImageWriter(ImageWriterSpi originator) {
/*  156 */     super(originator);
/*      */   }
/*      */   
/*      */   public void setOutput(Object output) {
/*  160 */     super.setOutput(output);
/*  161 */     if (output != null) {
/*  162 */       if (!(output instanceof ImageOutputStream))
/*  163 */         throw new IllegalArgumentException(I18N.getString("BMPImageWriter0")); 
/*  164 */       this.stream = (ImageOutputStream)output;
/*  165 */       this.stream.setByteOrder(ByteOrder.LITTLE_ENDIAN);
/*      */     } else {
/*  167 */       this.stream = null;
/*      */     } 
/*      */   }
/*      */   public ImageWriteParam getDefaultWriteParam() {
/*  171 */     return (ImageWriteParam)new BMPImageWriteParam();
/*      */   }
/*      */   
/*      */   public IIOMetadata getDefaultStreamMetadata(ImageWriteParam param) {
/*  175 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public IIOMetadata getDefaultImageMetadata(ImageTypeSpecifier imageType, ImageWriteParam param) {
/*  180 */     BMPMetadata meta = new BMPMetadata();
/*  181 */     meta.initialize(imageType.getColorModel(), imageType.getSampleModel(), param);
/*      */ 
/*      */     
/*  184 */     return meta;
/*      */   }
/*      */ 
/*      */   
/*      */   public IIOMetadata convertStreamMetadata(IIOMetadata inData, ImageWriteParam param) {
/*  189 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IIOMetadata convertImageMetadata(IIOMetadata inData, ImageTypeSpecifier imageType, ImageWriteParam param) {
/*  197 */     if (inData == null) {
/*  198 */       throw new IllegalArgumentException("inData == null!");
/*      */     }
/*  200 */     if (imageType == null) {
/*  201 */       throw new IllegalArgumentException("imageType == null!");
/*      */     }
/*      */     
/*  204 */     BMPMetadata outData = null;
/*      */ 
/*      */     
/*  207 */     if (inData instanceof BMPMetadata) {
/*      */       
/*  209 */       outData = (BMPMetadata)((BMPMetadata)inData).clone();
/*      */     } else {
/*      */       try {
/*  212 */         outData = new BMPMetadata(inData);
/*  213 */       } catch (IIOInvalidTreeException e) {
/*      */         
/*  215 */         outData = new BMPMetadata();
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  220 */     outData.initialize(imageType.getColorModel(), imageType.getSampleModel(), param);
/*      */ 
/*      */ 
/*      */     
/*  224 */     return outData;
/*      */   }
/*      */   
/*      */   public boolean canWriteRasters() {
/*  228 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void write(IIOMetadata streamMetadata, IIOImage image, ImageWriteParam param) throws IOException {
/*      */     int k;
/*  235 */     if (this.stream == null) {
/*  236 */       throw new IllegalStateException(I18N.getString("BMPImageWriter7"));
/*      */     }
/*      */     
/*  239 */     if (image == null) {
/*  240 */       throw new IllegalArgumentException(I18N.getString("BMPImageWriter8"));
/*      */     }
/*      */     
/*  243 */     clearAbortRequest();
/*  244 */     processImageStarted(0);
/*  245 */     if (param == null) {
/*  246 */       param = getDefaultWriteParam();
/*      */     }
/*  248 */     BMPImageWriteParam bmpParam = (BMPImageWriteParam)param;
/*      */ 
/*      */     
/*  251 */     int bitsPerPixel = 24;
/*  252 */     boolean isPalette = false;
/*  253 */     int paletteEntries = 0;
/*  254 */     IndexColorModel icm = null;
/*      */     
/*  256 */     RenderedImage input = null;
/*  257 */     Raster inputRaster = null;
/*  258 */     boolean writeRaster = image.hasRaster();
/*  259 */     Rectangle sourceRegion = param.getSourceRegion();
/*  260 */     SampleModel sampleModel = null;
/*  261 */     ColorModel colorModel = null;
/*      */     
/*  263 */     this.compImageSize = 0;
/*      */     
/*  265 */     if (writeRaster)
/*  266 */     { inputRaster = image.getRaster();
/*  267 */       sampleModel = inputRaster.getSampleModel();
/*  268 */       colorModel = ImageUtil.createColorModel(null, sampleModel);
/*  269 */       if (sourceRegion == null) {
/*  270 */         sourceRegion = inputRaster.getBounds();
/*      */       } else {
/*  272 */         sourceRegion = sourceRegion.intersection(inputRaster.getBounds());
/*      */       }  }
/*  274 */     else { input = image.getRenderedImage();
/*  275 */       sampleModel = input.getSampleModel();
/*  276 */       colorModel = input.getColorModel();
/*  277 */       Rectangle rect = new Rectangle(input.getMinX(), input.getMinY(), input.getWidth(), input.getHeight());
/*      */       
/*  279 */       if (sourceRegion == null) {
/*  280 */         sourceRegion = rect;
/*      */       } else {
/*  282 */         sourceRegion = sourceRegion.intersection(rect);
/*      */       }  }
/*      */     
/*  285 */     IIOMetadata imageMetadata = image.getMetadata();
/*  286 */     BMPMetadata bmpImageMetadata = null;
/*  287 */     ImageTypeSpecifier imageType = new ImageTypeSpecifier(colorModel, sampleModel);
/*      */     
/*  289 */     if (imageMetadata != null) {
/*      */       
/*  291 */       bmpImageMetadata = (BMPMetadata)convertImageMetadata(imageMetadata, imageType, param);
/*      */     
/*      */     }
/*      */     else {
/*      */       
/*  296 */       bmpImageMetadata = (BMPMetadata)getDefaultImageMetadata(imageType, param);
/*      */     } 
/*      */ 
/*      */     
/*  300 */     if (sourceRegion.isEmpty()) {
/*  301 */       throw new RuntimeException(I18N.getString("BMPImageWrite0"));
/*      */     }
/*  303 */     int scaleX = param.getSourceXSubsampling();
/*  304 */     int scaleY = param.getSourceYSubsampling();
/*  305 */     int xOffset = param.getSubsamplingXOffset();
/*  306 */     int yOffset = param.getSubsamplingYOffset();
/*      */ 
/*      */     
/*  309 */     int dataType = sampleModel.getDataType();
/*      */     
/*  311 */     sourceRegion.translate(xOffset, yOffset);
/*  312 */     sourceRegion.width -= xOffset;
/*  313 */     sourceRegion.height -= yOffset;
/*      */     
/*  315 */     int minX = sourceRegion.x / scaleX;
/*  316 */     int minY = sourceRegion.y / scaleY;
/*  317 */     this.w = (sourceRegion.width + scaleX - 1) / scaleX;
/*  318 */     this.h = (sourceRegion.height + scaleY - 1) / scaleY;
/*  319 */     xOffset = sourceRegion.x % scaleX;
/*  320 */     yOffset = sourceRegion.y % scaleY;
/*      */     
/*  322 */     Rectangle destinationRegion = new Rectangle(minX, minY, this.w, this.h);
/*  323 */     int noTransform = destinationRegion.equals(sourceRegion);
/*      */ 
/*      */     
/*  326 */     int[] sourceBands = param.getSourceBands();
/*  327 */     boolean noSubband = true;
/*  328 */     int numBands = sampleModel.getNumBands();
/*      */     
/*  330 */     if (sourceBands != null) {
/*  331 */       sampleModel = sampleModel.createSubsetSampleModel(sourceBands);
/*  332 */       colorModel = null;
/*  333 */       noSubband = false;
/*  334 */       numBands = sampleModel.getNumBands();
/*      */     } else {
/*  336 */       sourceBands = new int[numBands];
/*  337 */       for (int n = 0; n < numBands; n++) {
/*  338 */         sourceBands[n] = n;
/*      */       }
/*      */     } 
/*  341 */     int[] bandOffsets = null;
/*  342 */     boolean bgrOrder = true;
/*      */     
/*  344 */     if (sampleModel instanceof ComponentSampleModel) {
/*  345 */       bandOffsets = ((ComponentSampleModel)sampleModel).getBandOffsets();
/*  346 */       if (sampleModel instanceof java.awt.image.BandedSampleModel)
/*      */       {
/*      */         
/*  349 */         bgrOrder = false;
/*      */       
/*      */       }
/*      */       else
/*      */       {
/*  354 */         for (int n = 0; n < bandOffsets.length; n++) {
/*  355 */           k = bgrOrder & ((bandOffsets[n] == bandOffsets.length - n - 1) ? 1 : 0);
/*      */         }
/*      */       }
/*      */     
/*  359 */     } else if (sampleModel instanceof SinglePixelPackedSampleModel) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  364 */       int[] bitOffsets = ((SinglePixelPackedSampleModel)sampleModel).getBitOffsets();
/*  365 */       for (int n = 0; n < bitOffsets.length - 1; n++) {
/*  366 */         k &= (bitOffsets[n] > bitOffsets[n + 1]) ? 1 : 0;
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  371 */     if (bandOffsets == null) {
/*      */ 
/*      */       
/*  374 */       bandOffsets = new int[numBands];
/*  375 */       for (int n = 0; n < numBands; n++) {
/*  376 */         bandOffsets[n] = n;
/*      */       }
/*      */     } 
/*  379 */     int j = noTransform & k;
/*      */     
/*  381 */     int[] sampleSize = sampleModel.getSampleSize();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  386 */     int destScanlineBytes = this.w * numBands;
/*      */     
/*  388 */     switch (bmpParam.getCompressionMode()) {
/*      */       case 2:
/*  390 */         this.compressionType = getCompressionType(bmpParam.getCompressionType());
/*      */         break;
/*      */       case 3:
/*  393 */         this.compressionType = bmpImageMetadata.compression;
/*      */         break;
/*      */       case 1:
/*  396 */         this.compressionType = getPreferredCompressionType(colorModel, sampleModel);
/*      */         break;
/*      */       
/*      */       default:
/*  400 */         this.compressionType = 0;
/*      */         break;
/*      */     } 
/*  403 */     if (!canEncodeImage(this.compressionType, colorModel, sampleModel)) {
/*  404 */       if (param.getCompressionMode() == 2) {
/*  405 */         throw new IIOException("Image can not be encoded with compression type " + compressionTypeNames[this.compressionType]);
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  410 */       this.compressionType = getPreferredCompressionType(colorModel, sampleModel);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  415 */     byte[] r = null, g = null, b = null, a = null;
/*      */     
/*  417 */     if (this.compressionType == 3) {
/*  418 */       bitsPerPixel = DataBuffer.getDataTypeSize(sampleModel.getDataType());
/*      */ 
/*      */       
/*  421 */       if (bitsPerPixel != 16 && bitsPerPixel != 32) {
/*      */ 
/*      */         
/*  424 */         bitsPerPixel = 32;
/*      */ 
/*      */ 
/*      */         
/*  428 */         j = 0;
/*      */       } 
/*      */       
/*  431 */       destScanlineBytes = this.w * bitsPerPixel + 7 >> 3;
/*      */       
/*  433 */       isPalette = true;
/*  434 */       paletteEntries = 3;
/*  435 */       r = new byte[paletteEntries];
/*  436 */       g = new byte[paletteEntries];
/*  437 */       b = new byte[paletteEntries];
/*  438 */       a = new byte[paletteEntries];
/*      */       
/*  440 */       int rmask = 16711680;
/*  441 */       int gmask = 65280;
/*  442 */       int bmask = 255;
/*      */       
/*  444 */       if (bitsPerPixel == 16)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  451 */         if (colorModel instanceof DirectColorModel) {
/*  452 */           DirectColorModel dcm = (DirectColorModel)colorModel;
/*  453 */           rmask = dcm.getRedMask();
/*  454 */           gmask = dcm.getGreenMask();
/*  455 */           bmask = dcm.getBlueMask();
/*      */         }
/*      */         else {
/*      */           
/*  459 */           throw new IOException("Image can not be encoded with compression type " + compressionTypeNames[this.compressionType]);
/*      */         } 
/*      */       }
/*      */ 
/*      */       
/*  464 */       writeMaskToPalette(rmask, 0, r, g, b, a);
/*  465 */       writeMaskToPalette(gmask, 1, r, g, b, a);
/*  466 */       writeMaskToPalette(bmask, 2, r, g, b, a);
/*      */       
/*  468 */       if (j == 0) {
/*      */         
/*  470 */         this.bitMasks = new int[3];
/*  471 */         this.bitMasks[0] = rmask;
/*  472 */         this.bitMasks[1] = gmask;
/*  473 */         this.bitMasks[2] = bmask;
/*      */         
/*  475 */         this.bitPos = new int[3];
/*  476 */         this.bitPos[0] = firstLowBit(rmask);
/*  477 */         this.bitPos[1] = firstLowBit(gmask);
/*  478 */         this.bitPos[2] = firstLowBit(bmask);
/*      */       } 
/*      */       
/*  481 */       if (colorModel instanceof IndexColorModel) {
/*  482 */         icm = (IndexColorModel)colorModel;
/*      */       }
/*      */     }
/*  485 */     else if (colorModel instanceof IndexColorModel) {
/*  486 */       isPalette = true;
/*  487 */       icm = (IndexColorModel)colorModel;
/*  488 */       paletteEntries = icm.getMapSize();
/*      */       
/*  490 */       if (paletteEntries <= 2) {
/*  491 */         bitsPerPixel = 1;
/*  492 */         destScanlineBytes = this.w + 7 >> 3;
/*  493 */       } else if (paletteEntries <= 16) {
/*  494 */         bitsPerPixel = 4;
/*  495 */         destScanlineBytes = this.w + 1 >> 1;
/*  496 */       } else if (paletteEntries <= 256) {
/*  497 */         bitsPerPixel = 8;
/*      */       }
/*      */       else {
/*      */         
/*  501 */         bitsPerPixel = 24;
/*  502 */         isPalette = false;
/*  503 */         paletteEntries = 0;
/*  504 */         destScanlineBytes = this.w * 3;
/*      */       } 
/*      */       
/*  507 */       if (isPalette == true) {
/*  508 */         r = new byte[paletteEntries];
/*  509 */         g = new byte[paletteEntries];
/*  510 */         b = new byte[paletteEntries];
/*      */         
/*  512 */         icm.getReds(r);
/*  513 */         icm.getGreens(g);
/*  514 */         icm.getBlues(b);
/*      */       
/*      */       }
/*      */     
/*      */     }
/*  519 */     else if (numBands == 1) {
/*      */       
/*  521 */       isPalette = true;
/*  522 */       paletteEntries = 256;
/*  523 */       bitsPerPixel = sampleSize[0];
/*      */       
/*  525 */       destScanlineBytes = this.w * bitsPerPixel + 7 >> 3;
/*      */       
/*  527 */       r = new byte[256];
/*  528 */       g = new byte[256];
/*  529 */       b = new byte[256];
/*      */       
/*  531 */       for (int n = 0; n < 256; n++) {
/*  532 */         r[n] = (byte)n;
/*  533 */         g[n] = (byte)n;
/*  534 */         b[n] = (byte)n;
/*      */       }
/*      */     
/*      */     }
/*  538 */     else if (sampleModel instanceof SinglePixelPackedSampleModel && noSubband) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  547 */       int[] sample_sizes = sampleModel.getSampleSize();
/*  548 */       bitsPerPixel = 0;
/*  549 */       for (int n = 0; n < sample_sizes.length; n++) {
/*  550 */         bitsPerPixel += sample_sizes[n];
/*      */       }
/*  552 */       bitsPerPixel = roundBpp(bitsPerPixel);
/*  553 */       if (bitsPerPixel != DataBuffer.getDataTypeSize(sampleModel.getDataType())) {
/*  554 */         j = 0;
/*      */       }
/*  556 */       destScanlineBytes = this.w * bitsPerPixel + 7 >> 3;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  563 */     int fileSize = 0;
/*  564 */     int offset = 0;
/*  565 */     int headerSize = 0;
/*  566 */     int imageSize = 0;
/*  567 */     int xPelsPerMeter = bmpImageMetadata.xPixelsPerMeter;
/*  568 */     int yPelsPerMeter = bmpImageMetadata.yPixelsPerMeter;
/*  569 */     int colorsUsed = (bmpImageMetadata.colorsUsed > 0) ? bmpImageMetadata.colorsUsed : paletteEntries;
/*      */     
/*  571 */     int colorsImportant = paletteEntries;
/*      */ 
/*      */     
/*  574 */     int padding = destScanlineBytes % 4;
/*  575 */     if (padding != 0) {
/*  576 */       padding = 4 - padding;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  582 */     offset = 54 + paletteEntries * 4;
/*      */     
/*  584 */     imageSize = (destScanlineBytes + padding) * this.h;
/*  585 */     fileSize = imageSize + offset;
/*  586 */     headerSize = 40;
/*      */     
/*  588 */     long headPos = this.stream.getStreamPosition();
/*      */     
/*  590 */     if (param instanceof BMPImageWriteParam) {
/*  591 */       this.isTopDown = ((BMPImageWriteParam)param).isTopDown();
/*      */ 
/*      */       
/*  594 */       if (this.compressionType != 0 && this.compressionType != 3)
/*  595 */         this.isTopDown = false; 
/*      */     } else {
/*  597 */       this.isTopDown = false;
/*      */     } 
/*      */     
/*  600 */     writeFileHeader(fileSize, offset);
/*      */     
/*  602 */     writeInfoHeader(headerSize, bitsPerPixel);
/*      */ 
/*      */     
/*  605 */     this.stream.writeInt(this.compressionType);
/*      */ 
/*      */     
/*  608 */     this.stream.writeInt(imageSize);
/*      */ 
/*      */     
/*  611 */     this.stream.writeInt(xPelsPerMeter);
/*      */ 
/*      */     
/*  614 */     this.stream.writeInt(yPelsPerMeter);
/*      */ 
/*      */     
/*  617 */     this.stream.writeInt(colorsUsed);
/*      */ 
/*      */     
/*  620 */     this.stream.writeInt(colorsImportant);
/*      */ 
/*      */     
/*  623 */     if (isPalette == true)
/*      */     {
/*      */       
/*  626 */       if (this.compressionType == 3) {
/*      */         
/*  628 */         for (int n = 0; n < 3; n++) {
/*  629 */           int mask = (a[n] & 0xFF) + (r[n] & 0xFF) * 256 + (g[n] & 0xFF) * 65536 + (b[n] & 0xFF) * 16777216;
/*  630 */           this.stream.writeInt(mask);
/*      */         } 
/*      */       } else {
/*  633 */         for (int n = 0; n < paletteEntries; n++) {
/*  634 */           this.stream.writeByte(b[n]);
/*  635 */           this.stream.writeByte(g[n]);
/*  636 */           this.stream.writeByte(r[n]);
/*  637 */           this.stream.writeByte(0);
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*  643 */     int scanlineBytes = this.w * numBands;
/*      */ 
/*      */     
/*  646 */     int[] pixels = new int[scanlineBytes * scaleX];
/*      */ 
/*      */ 
/*      */     
/*  650 */     this.bpixels = new byte[destScanlineBytes];
/*      */ 
/*      */ 
/*      */     
/*  654 */     if (this.compressionType == 4 || this.compressionType == 5) {
/*      */ 
/*      */       
/*  657 */       this.embedded_stream = new ByteArrayOutputStream();
/*  658 */       writeEmbedded(image, (ImageWriteParam)bmpParam);
/*      */       
/*  660 */       this.embedded_stream.flush();
/*  661 */       imageSize = this.embedded_stream.size();
/*      */       
/*  663 */       long endPos = this.stream.getStreamPosition();
/*  664 */       fileSize = offset + imageSize;
/*  665 */       this.stream.seek(headPos);
/*  666 */       writeSize(fileSize, 2);
/*  667 */       this.stream.seek(headPos);
/*  668 */       writeSize(imageSize, 34);
/*  669 */       this.stream.seek(endPos);
/*  670 */       this.stream.write(this.embedded_stream.toByteArray());
/*  671 */       this.embedded_stream = null;
/*      */       
/*  673 */       if (abortRequested()) {
/*  674 */         processWriteAborted();
/*      */       } else {
/*  676 */         processImageComplete();
/*  677 */         this.stream.flushBefore(this.stream.getStreamPosition());
/*      */       } 
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/*  683 */     int maxBandOffset = bandOffsets[0];
/*  684 */     for (int i = 1; i < bandOffsets.length; i++) {
/*  685 */       if (bandOffsets[i] > maxBandOffset)
/*  686 */         maxBandOffset = bandOffsets[i]; 
/*      */     } 
/*  688 */     int[] pixel = new int[maxBandOffset + 1];
/*      */     
/*  690 */     int destScanlineLength = destScanlineBytes;
/*      */     
/*  692 */     if (j != 0 && noSubband) {
/*  693 */       destScanlineLength = destScanlineBytes / (DataBuffer.getDataTypeSize(dataType) >> 3);
/*      */     }
/*  695 */     for (int m = 0; m < this.h && 
/*  696 */       !abortRequested(); m++) {
/*      */ 
/*      */ 
/*      */       
/*  700 */       int row = minY + m;
/*      */       
/*  702 */       if (!this.isTopDown) {
/*  703 */         row = minY + this.h - m - 1;
/*      */       }
/*      */       
/*  706 */       Raster src = inputRaster;
/*      */       
/*  708 */       Rectangle srcRect = new Rectangle(minX * scaleX + xOffset, row * scaleY + yOffset, (this.w - 1) * scaleX + 1, 1);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  713 */       if (!writeRaster) {
/*  714 */         src = input.getData(srcRect);
/*      */       }
/*  716 */       if (j != 0 && noSubband) {
/*  717 */         SampleModel sm = src.getSampleModel();
/*  718 */         int pos = 0;
/*  719 */         int startX = srcRect.x - src.getSampleModelTranslateX();
/*  720 */         int startY = srcRect.y - src.getSampleModelTranslateY();
/*  721 */         if (sm instanceof ComponentSampleModel) {
/*  722 */           ComponentSampleModel csm = (ComponentSampleModel)sm;
/*  723 */           pos = csm.getOffset(startX, startY, 0);
/*  724 */           for (int nb = 1; nb < csm.getNumBands(); nb++) {
/*  725 */             if (pos > csm.getOffset(startX, startY, nb)) {
/*  726 */               pos = csm.getOffset(startX, startY, nb);
/*      */             }
/*      */           } 
/*  729 */         } else if (sm instanceof MultiPixelPackedSampleModel) {
/*  730 */           MultiPixelPackedSampleModel mppsm = (MultiPixelPackedSampleModel)sm;
/*      */           
/*  732 */           pos = mppsm.getOffset(startX, startY);
/*  733 */         } else if (sm instanceof SinglePixelPackedSampleModel) {
/*  734 */           SinglePixelPackedSampleModel sppsm = (SinglePixelPackedSampleModel)sm;
/*      */           
/*  736 */           pos = sppsm.getOffset(startX, startY);
/*      */         } 
/*      */         
/*  739 */         if (this.compressionType == 0 || this.compressionType == 3) {
/*  740 */           byte[] bdata; short[] sdata; short[] usdata; int[] idata; switch (dataType) {
/*      */             case 0:
/*  742 */               bdata = ((DataBufferByte)src.getDataBuffer()).getData();
/*      */               
/*  744 */               this.stream.write(bdata, pos, destScanlineLength);
/*      */               break;
/*      */             
/*      */             case 2:
/*  748 */               sdata = ((DataBufferShort)src.getDataBuffer()).getData();
/*      */               
/*  750 */               this.stream.writeShorts(sdata, pos, destScanlineLength);
/*      */               break;
/*      */             
/*      */             case 1:
/*  754 */               usdata = ((DataBufferUShort)src.getDataBuffer()).getData();
/*      */               
/*  756 */               this.stream.writeShorts(usdata, pos, destScanlineLength);
/*      */               break;
/*      */             
/*      */             case 3:
/*  760 */               idata = ((DataBufferInt)src.getDataBuffer()).getData();
/*      */               
/*  762 */               this.stream.writeInts(idata, pos, destScanlineLength);
/*      */               break;
/*      */           } 
/*      */           
/*  766 */           for (int n = 0; n < padding; n++) {
/*  767 */             this.stream.writeByte(0);
/*      */           }
/*  769 */         } else if (this.compressionType == 2) {
/*  770 */           if (this.bpixels == null || this.bpixels.length < scanlineBytes)
/*  771 */             this.bpixels = new byte[scanlineBytes]; 
/*  772 */           src.getPixels(srcRect.x, srcRect.y, srcRect.width, srcRect.height, pixels);
/*      */           
/*  774 */           for (int h = 0; h < scanlineBytes; h++) {
/*  775 */             this.bpixels[h] = (byte)pixels[h];
/*      */           }
/*  777 */           encodeRLE4(this.bpixels, scanlineBytes);
/*  778 */         } else if (this.compressionType == 1) {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  783 */           if (this.bpixels == null || this.bpixels.length < scanlineBytes)
/*  784 */             this.bpixels = new byte[scanlineBytes]; 
/*  785 */           src.getPixels(srcRect.x, srcRect.y, srcRect.width, srcRect.height, pixels);
/*      */           
/*  787 */           for (int h = 0; h < scanlineBytes; h++) {
/*  788 */             this.bpixels[h] = (byte)pixels[h];
/*      */           }
/*      */           
/*  791 */           encodeRLE8(this.bpixels, scanlineBytes);
/*      */         } 
/*      */       } else {
/*  794 */         src.getPixels(srcRect.x, srcRect.y, srcRect.width, srcRect.height, pixels);
/*      */ 
/*      */         
/*  797 */         if (scaleX != 1 || maxBandOffset != numBands - 1) {
/*  798 */           int n; for (int i1 = 0, i2 = 0; i1 < this.w; 
/*  799 */             i1++, i2 += scaleX * numBands, n += numBands) {
/*      */             
/*  801 */             System.arraycopy(pixels, i2, pixel, 0, pixel.length);
/*      */             
/*  803 */             for (int i3 = 0; i3 < numBands; i3++)
/*      */             {
/*  805 */               pixels[n + i3] = pixel[sourceBands[i3]];
/*      */             }
/*      */           } 
/*      */         } 
/*  809 */         writePixels(0, scanlineBytes, bitsPerPixel, pixels, padding, numBands, icm);
/*      */       } 
/*      */ 
/*      */       
/*  813 */       processImageProgress(100.0F * m / this.h);
/*      */     } 
/*      */     
/*  816 */     if (this.compressionType == 2 || this.compressionType == 1) {
/*      */ 
/*      */       
/*  819 */       this.stream.writeByte(0);
/*  820 */       this.stream.writeByte(1);
/*  821 */       incCompImageSize(2);
/*      */       
/*  823 */       imageSize = this.compImageSize;
/*  824 */       fileSize = this.compImageSize + offset;
/*  825 */       long endPos = this.stream.getStreamPosition();
/*  826 */       this.stream.seek(headPos);
/*  827 */       writeSize(fileSize, 2);
/*  828 */       this.stream.seek(headPos);
/*  829 */       writeSize(imageSize, 34);
/*  830 */       this.stream.seek(endPos);
/*      */     } 
/*      */     
/*  833 */     if (abortRequested()) {
/*  834 */       processWriteAborted();
/*      */     } else {
/*  836 */       processImageComplete();
/*  837 */       this.stream.flushBefore(this.stream.getStreamPosition());
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void writePixels(int l, int scanlineBytes, int bitsPerPixel, int[] pixels, int padding, int numBands, IndexColorModel icm) throws IOException {
/*      */     int j, entries, m;
/*      */     byte[] r, g, b;
/*  845 */     int i, pixel = 0;
/*  846 */     int k = 0;
/*  847 */     switch (bitsPerPixel) {
/*      */ 
/*      */       
/*      */       case 1:
/*  851 */         for (j = 0; j < scanlineBytes / 8; j++) {
/*  852 */           this.bpixels[k++] = (byte)(pixels[l++] << 7 | pixels[l++] << 6 | pixels[l++] << 5 | pixels[l++] << 4 | pixels[l++] << 3 | pixels[l++] << 2 | pixels[l++] << 1 | pixels[l++]);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  863 */         if (scanlineBytes % 8 > 0) {
/*  864 */           pixel = 0;
/*  865 */           for (j = 0; j < scanlineBytes % 8; j++) {
/*  866 */             pixel |= pixels[l++] << 7 - j;
/*      */           }
/*  868 */           this.bpixels[k++] = (byte)pixel;
/*      */         } 
/*  870 */         this.stream.write(this.bpixels, 0, (scanlineBytes + 7) / 8);
/*      */         break;
/*      */ 
/*      */       
/*      */       case 4:
/*  875 */         if (this.compressionType == 2) {
/*  876 */           byte[] bipixels = new byte[scanlineBytes];
/*  877 */           for (int h = 0; h < scanlineBytes; h++) {
/*  878 */             bipixels[h] = (byte)pixels[l++];
/*      */           }
/*  880 */           encodeRLE4(bipixels, scanlineBytes); break;
/*      */         } 
/*  882 */         for (j = 0; j < scanlineBytes / 2; j++) {
/*  883 */           pixel = pixels[l++] << 4 | pixels[l++];
/*  884 */           this.bpixels[k++] = (byte)pixel;
/*      */         } 
/*      */         
/*  887 */         if (scanlineBytes % 2 == 1) {
/*  888 */           pixel = pixels[l] << 4;
/*  889 */           this.bpixels[k++] = (byte)pixel;
/*      */         } 
/*  891 */         this.stream.write(this.bpixels, 0, (scanlineBytes + 1) / 2);
/*      */         break;
/*      */ 
/*      */       
/*      */       case 8:
/*  896 */         if (this.compressionType == 1) {
/*  897 */           for (int h = 0; h < scanlineBytes; h++) {
/*  898 */             this.bpixels[h] = (byte)pixels[l++];
/*      */           }
/*  900 */           encodeRLE8(this.bpixels, scanlineBytes); break;
/*      */         } 
/*  902 */         for (j = 0; j < scanlineBytes; j++) {
/*  903 */           this.bpixels[j] = (byte)pixels[l++];
/*      */         }
/*  905 */         this.stream.write(this.bpixels, 0, scanlineBytes);
/*      */         break;
/*      */ 
/*      */       
/*      */       case 16:
/*  910 */         if (this.spixels == null) {
/*  911 */           this.spixels = new short[scanlineBytes / numBands];
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  921 */         for (j = 0, m = 0; j < scanlineBytes; m++) {
/*  922 */           this.spixels[m] = 0;
/*  923 */           if (this.compressionType == 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  928 */             this.spixels[m] = (short)((0x1F & pixels[j]) << 10 | (0x1F & pixels[j + 1]) << 5 | 0x1F & pixels[j + 2]);
/*      */ 
/*      */ 
/*      */             
/*  932 */             j += 3;
/*      */           } else {
/*  934 */             for (int n = 0; n < numBands; n++, j++) {
/*  935 */               this.spixels[m] = (short)(this.spixels[m] | pixels[j] << this.bitPos[n] & this.bitMasks[n]);
/*      */             }
/*      */           } 
/*      */         } 
/*      */         
/*  940 */         this.stream.writeShorts(this.spixels, 0, this.spixels.length);
/*      */         break;
/*      */       
/*      */       case 24:
/*  944 */         if (numBands == 3) {
/*  945 */           for (j = 0; j < scanlineBytes; j += 3) {
/*      */             
/*  947 */             this.bpixels[k++] = (byte)pixels[l + 2];
/*  948 */             this.bpixels[k++] = (byte)pixels[l + 1];
/*  949 */             this.bpixels[k++] = (byte)pixels[l];
/*  950 */             l += 3;
/*      */           } 
/*  952 */           this.stream.write(this.bpixels, 0, scanlineBytes);
/*      */           break;
/*      */         } 
/*  955 */         entries = icm.getMapSize();
/*      */         
/*  957 */         r = new byte[entries];
/*  958 */         g = new byte[entries];
/*  959 */         b = new byte[entries];
/*      */         
/*  961 */         icm.getReds(r);
/*  962 */         icm.getGreens(g);
/*  963 */         icm.getBlues(b);
/*      */ 
/*      */         
/*  966 */         for (i = 0; i < scanlineBytes; i++) {
/*  967 */           int index = pixels[l];
/*  968 */           this.bpixels[k++] = b[index];
/*  969 */           this.bpixels[k++] = g[index];
/*  970 */           this.bpixels[k++] = b[index];
/*  971 */           l++;
/*      */         } 
/*  973 */         this.stream.write(this.bpixels, 0, scanlineBytes * 3);
/*      */         break;
/*      */ 
/*      */       
/*      */       case 32:
/*  978 */         if (this.ipixels == null)
/*  979 */           this.ipixels = new int[scanlineBytes / numBands]; 
/*  980 */         if (numBands == 3) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  990 */           for (int n = 0, i1 = 0; n < scanlineBytes; i1++) {
/*  991 */             this.ipixels[i1] = 0;
/*  992 */             if (this.compressionType == 0) {
/*  993 */               this.ipixels[i1] = (0xFF & pixels[n + 2]) << 16 | (0xFF & pixels[n + 1]) << 8 | 0xFF & pixels[n];
/*      */ 
/*      */ 
/*      */               
/*  997 */               n += 3;
/*      */             } else {
/*  999 */               for (int i2 = 0; i2 < numBands; i2++, n++) {
/* 1000 */                 this.ipixels[i1] = this.ipixels[i1] | pixels[n] << this.bitPos[i2] & this.bitMasks[i2];
/*      */               
/*      */               }
/*      */             
/*      */             }
/*      */ 
/*      */           
/*      */           }
/*      */ 
/*      */         
/*      */         }
/*      */         else {
/*      */           
/* 1013 */           for (int n = 0; n < scanlineBytes; n++) {
/* 1014 */             if (icm != null) {
/* 1015 */               this.ipixels[n] = icm.getRGB(pixels[n]);
/*      */             } else {
/* 1017 */               this.ipixels[n] = pixels[n] << 16 | pixels[n] << 8 | pixels[n];
/*      */             } 
/*      */           } 
/*      */         } 
/*      */         
/* 1022 */         this.stream.writeInts(this.ipixels, 0, this.ipixels.length);
/*      */         break;
/*      */     } 
/*      */ 
/*      */     
/* 1027 */     if (this.compressionType == 0 || this.compressionType == 3)
/*      */     {
/* 1029 */       for (k = 0; k < padding; k++) {
/* 1030 */         this.stream.writeByte(0);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void encodeRLE8(byte[] bpixels, int scanlineBytes) throws IOException {
/* 1038 */     int runCount = 1, absVal = -1, j = -1;
/* 1039 */     byte runVal = 0, nextVal = 0;
/*      */     
/* 1041 */     runVal = bpixels[++j];
/* 1042 */     byte[] absBuf = new byte[256];
/*      */     
/* 1044 */     while (j < scanlineBytes - 1) {
/* 1045 */       nextVal = bpixels[++j];
/* 1046 */       if (nextVal == runVal) {
/* 1047 */         if (absVal >= 3) {
/*      */           
/* 1049 */           this.stream.writeByte(0);
/* 1050 */           this.stream.writeByte(absVal);
/* 1051 */           incCompImageSize(2);
/* 1052 */           for (int a = 0; a < absVal; a++) {
/* 1053 */             this.stream.writeByte(absBuf[a]);
/* 1054 */             incCompImageSize(1);
/*      */           } 
/* 1056 */           if (!isEven(absVal))
/*      */           {
/* 1058 */             this.stream.writeByte(0);
/* 1059 */             incCompImageSize(1);
/*      */           }
/*      */         
/* 1062 */         } else if (absVal > -1) {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1067 */           for (int b = 0; b < absVal; b++) {
/* 1068 */             this.stream.writeByte(1);
/* 1069 */             this.stream.writeByte(absBuf[b]);
/* 1070 */             incCompImageSize(2);
/*      */           } 
/*      */         } 
/* 1073 */         absVal = -1;
/* 1074 */         runCount++;
/* 1075 */         if (runCount == 256) {
/*      */           
/* 1077 */           this.stream.writeByte(runCount - 1);
/* 1078 */           this.stream.writeByte(runVal);
/* 1079 */           incCompImageSize(2);
/* 1080 */           runCount = 1;
/*      */         } 
/*      */       } else {
/*      */         
/* 1084 */         if (runCount > 1) {
/*      */           
/* 1086 */           this.stream.writeByte(runCount);
/* 1087 */           this.stream.writeByte(runVal);
/* 1088 */           incCompImageSize(2);
/* 1089 */         } else if (absVal < 0) {
/*      */           
/* 1091 */           absBuf[++absVal] = runVal;
/* 1092 */           absBuf[++absVal] = nextVal;
/* 1093 */         } else if (absVal < 254) {
/*      */           
/* 1095 */           absBuf[++absVal] = nextVal;
/*      */         } else {
/* 1097 */           this.stream.writeByte(0);
/* 1098 */           this.stream.writeByte(absVal + 1);
/* 1099 */           incCompImageSize(2);
/* 1100 */           for (int a = 0; a <= absVal; a++) {
/* 1101 */             this.stream.writeByte(absBuf[a]);
/* 1102 */             incCompImageSize(1);
/*      */           } 
/*      */           
/* 1105 */           this.stream.writeByte(0);
/* 1106 */           incCompImageSize(1);
/* 1107 */           absVal = -1;
/*      */         } 
/* 1109 */         runVal = nextVal;
/* 1110 */         runCount = 1;
/*      */       } 
/*      */       
/* 1113 */       if (j == scanlineBytes - 1) {
/*      */         
/* 1115 */         if (absVal == -1) {
/* 1116 */           this.stream.writeByte(runCount);
/* 1117 */           this.stream.writeByte(runVal);
/* 1118 */           incCompImageSize(2);
/* 1119 */           runCount = 1;
/*      */ 
/*      */         
/*      */         }
/* 1123 */         else if (absVal >= 2) {
/* 1124 */           this.stream.writeByte(0);
/* 1125 */           this.stream.writeByte(absVal + 1);
/* 1126 */           incCompImageSize(2);
/* 1127 */           for (int a = 0; a <= absVal; a++) {
/* 1128 */             this.stream.writeByte(absBuf[a]);
/* 1129 */             incCompImageSize(1);
/*      */           } 
/* 1131 */           if (!isEven(absVal + 1))
/*      */           {
/* 1133 */             this.stream.writeByte(0);
/* 1134 */             incCompImageSize(1);
/*      */           }
/*      */         
/*      */         }
/* 1138 */         else if (absVal > -1) {
/* 1139 */           for (int b = 0; b <= absVal; b++) {
/* 1140 */             this.stream.writeByte(1);
/* 1141 */             this.stream.writeByte(absBuf[b]);
/* 1142 */             incCompImageSize(2);
/*      */           } 
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 1148 */         this.stream.writeByte(0);
/* 1149 */         this.stream.writeByte(0);
/* 1150 */         incCompImageSize(2);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void encodeRLE4(byte[] bipixels, int scanlineBytes) throws IOException {
/* 1158 */     int runCount = 2, absVal = -1, j = -1, pixel = 0, q = 0;
/* 1159 */     byte runVal1 = 0, runVal2 = 0, nextVal1 = 0, nextVal2 = 0;
/* 1160 */     byte[] absBuf = new byte[256];
/*      */ 
/*      */     
/* 1163 */     runVal1 = bipixels[++j];
/* 1164 */     runVal2 = bipixels[++j];
/*      */     
/* 1166 */     while (j < scanlineBytes - 2) {
/* 1167 */       nextVal1 = bipixels[++j];
/* 1168 */       nextVal2 = bipixels[++j];
/*      */       
/* 1170 */       if (nextVal1 == runVal1) {
/*      */ 
/*      */         
/* 1173 */         if (absVal >= 4) {
/* 1174 */           this.stream.writeByte(0);
/* 1175 */           this.stream.writeByte(absVal - 1);
/* 1176 */           incCompImageSize(2);
/*      */ 
/*      */           
/* 1179 */           for (int a = 0; a < absVal - 2; a += 2) {
/* 1180 */             pixel = absBuf[a] << 4 | absBuf[a + 1];
/* 1181 */             this.stream.writeByte((byte)pixel);
/* 1182 */             incCompImageSize(1);
/*      */           } 
/*      */           
/* 1185 */           if (!isEven(absVal - 1)) {
/* 1186 */             q = absBuf[absVal - 2] << 4 | 0x0;
/* 1187 */             this.stream.writeByte(q);
/* 1188 */             incCompImageSize(1);
/*      */           } 
/*      */           
/* 1191 */           if (!isEven((int)Math.ceil(((absVal - 1) / 2)))) {
/* 1192 */             this.stream.writeByte(0);
/* 1193 */             incCompImageSize(1);
/*      */           } 
/* 1195 */         } else if (absVal > -1) {
/* 1196 */           this.stream.writeByte(2);
/* 1197 */           pixel = absBuf[0] << 4 | absBuf[1];
/* 1198 */           this.stream.writeByte(pixel);
/* 1199 */           incCompImageSize(2);
/*      */         } 
/* 1201 */         absVal = -1;
/*      */         
/* 1203 */         if (nextVal2 == runVal2) {
/*      */           
/* 1205 */           runCount += 2;
/* 1206 */           if (runCount == 256) {
/* 1207 */             this.stream.writeByte(runCount - 1);
/* 1208 */             pixel = runVal1 << 4 | runVal2;
/* 1209 */             this.stream.writeByte(pixel);
/* 1210 */             incCompImageSize(2);
/* 1211 */             runCount = 2;
/* 1212 */             if (j < scanlineBytes - 1) {
/* 1213 */               runVal1 = runVal2;
/* 1214 */               runVal2 = bipixels[++j];
/*      */             } else {
/* 1216 */               this.stream.writeByte(1);
/* 1217 */               int r = runVal2 << 4 | 0x0;
/* 1218 */               this.stream.writeByte(r);
/* 1219 */               incCompImageSize(2);
/* 1220 */               runCount = -1;
/*      */             }
/*      */           
/*      */           }
/*      */         
/*      */         } else {
/*      */           
/* 1227 */           runCount++;
/* 1228 */           pixel = runVal1 << 4 | runVal2;
/* 1229 */           this.stream.writeByte(runCount);
/* 1230 */           this.stream.writeByte(pixel);
/* 1231 */           incCompImageSize(2);
/* 1232 */           runCount = 2;
/* 1233 */           runVal1 = nextVal2;
/*      */           
/* 1235 */           if (j < scanlineBytes - 1) {
/* 1236 */             runVal2 = bipixels[++j];
/*      */           } else {
/* 1238 */             this.stream.writeByte(1);
/* 1239 */             int r = nextVal2 << 4 | 0x0;
/* 1240 */             this.stream.writeByte(r);
/* 1241 */             incCompImageSize(2);
/* 1242 */             runCount = -1;
/*      */           }
/*      */         
/*      */         } 
/*      */       } else {
/*      */         
/* 1248 */         if (runCount > 2) {
/* 1249 */           pixel = runVal1 << 4 | runVal2;
/* 1250 */           this.stream.writeByte(runCount);
/* 1251 */           this.stream.writeByte(pixel);
/* 1252 */           incCompImageSize(2);
/* 1253 */         } else if (absVal < 0) {
/* 1254 */           absBuf[++absVal] = runVal1;
/* 1255 */           absBuf[++absVal] = runVal2;
/* 1256 */           absBuf[++absVal] = nextVal1;
/* 1257 */           absBuf[++absVal] = nextVal2;
/* 1258 */         } else if (absVal < 253) {
/* 1259 */           absBuf[++absVal] = nextVal1;
/* 1260 */           absBuf[++absVal] = nextVal2;
/*      */         } else {
/* 1262 */           this.stream.writeByte(0);
/* 1263 */           this.stream.writeByte(absVal + 1);
/* 1264 */           incCompImageSize(2);
/* 1265 */           for (int a = 0; a < absVal; a += 2) {
/* 1266 */             pixel = absBuf[a] << 4 | absBuf[a + 1];
/* 1267 */             this.stream.writeByte((byte)pixel);
/* 1268 */             incCompImageSize(1);
/*      */           } 
/*      */ 
/*      */           
/* 1272 */           this.stream.writeByte(0);
/* 1273 */           incCompImageSize(1);
/* 1274 */           absVal = -1;
/*      */         } 
/*      */         
/* 1277 */         runVal1 = nextVal1;
/* 1278 */         runVal2 = nextVal2;
/* 1279 */         runCount = 2;
/*      */       } 
/*      */       
/* 1282 */       if (j >= scanlineBytes - 2) {
/* 1283 */         if (absVal == -1 && runCount >= 2) {
/* 1284 */           if (j == scanlineBytes - 2) {
/* 1285 */             if (bipixels[++j] == runVal1) {
/* 1286 */               runCount++;
/* 1287 */               pixel = runVal1 << 4 | runVal2;
/* 1288 */               this.stream.writeByte(runCount);
/* 1289 */               this.stream.writeByte(pixel);
/* 1290 */               incCompImageSize(2);
/*      */             } else {
/* 1292 */               pixel = runVal1 << 4 | runVal2;
/* 1293 */               this.stream.writeByte(runCount);
/* 1294 */               this.stream.writeByte(pixel);
/* 1295 */               this.stream.writeByte(1);
/* 1296 */               pixel = bipixels[j] << 4 | 0x0;
/* 1297 */               this.stream.writeByte(pixel);
/* 1298 */               int n = bipixels[j] << 4 | 0x0;
/* 1299 */               incCompImageSize(4);
/*      */             } 
/*      */           } else {
/* 1302 */             this.stream.writeByte(runCount);
/* 1303 */             pixel = runVal1 << 4 | runVal2;
/* 1304 */             this.stream.writeByte(pixel);
/* 1305 */             incCompImageSize(2);
/*      */           } 
/* 1307 */         } else if (absVal > -1) {
/* 1308 */           if (j == scanlineBytes - 2) {
/* 1309 */             absBuf[++absVal] = bipixels[++j];
/*      */           }
/* 1311 */           if (absVal >= 2) {
/* 1312 */             this.stream.writeByte(0);
/* 1313 */             this.stream.writeByte(absVal + 1);
/* 1314 */             incCompImageSize(2);
/* 1315 */             for (int a = 0; a < absVal; a += 2) {
/* 1316 */               pixel = absBuf[a] << 4 | absBuf[a + 1];
/* 1317 */               this.stream.writeByte((byte)pixel);
/* 1318 */               incCompImageSize(1);
/*      */             } 
/* 1320 */             if (!isEven(absVal + 1)) {
/* 1321 */               q = absBuf[absVal] << 4 | 0x0;
/* 1322 */               this.stream.writeByte(q);
/* 1323 */               incCompImageSize(1);
/*      */             } 
/*      */ 
/*      */             
/* 1327 */             if (!isEven((int)Math.ceil(((absVal + 1) / 2)))) {
/* 1328 */               this.stream.writeByte(0);
/* 1329 */               incCompImageSize(1);
/*      */             } 
/*      */           } else {
/*      */             int n;
/* 1333 */             switch (absVal) {
/*      */               case 0:
/* 1335 */                 this.stream.writeByte(1);
/* 1336 */                 n = absBuf[0] << 4 | 0x0;
/* 1337 */                 this.stream.writeByte(n);
/* 1338 */                 incCompImageSize(2);
/*      */                 break;
/*      */               case 1:
/* 1341 */                 this.stream.writeByte(2);
/* 1342 */                 pixel = absBuf[0] << 4 | absBuf[1];
/* 1343 */                 this.stream.writeByte(pixel);
/* 1344 */                 incCompImageSize(2);
/*      */                 break;
/*      */             } 
/*      */           
/*      */           } 
/*      */         } 
/* 1350 */         this.stream.writeByte(0);
/* 1351 */         this.stream.writeByte(0);
/* 1352 */         incCompImageSize(2);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private synchronized void incCompImageSize(int value) {
/* 1359 */     this.compImageSize += value;
/*      */   }
/*      */   
/*      */   private boolean isEven(int number) {
/* 1363 */     return (number % 2 == 0);
/*      */   }
/*      */ 
/*      */   
/*      */   private void writeFileHeader(int fileSize, int offset) throws IOException {
/* 1368 */     this.stream.writeByte(66);
/* 1369 */     this.stream.writeByte(77);
/*      */ 
/*      */     
/* 1372 */     this.stream.writeInt(fileSize);
/*      */ 
/*      */     
/* 1375 */     this.stream.writeInt(0);
/*      */ 
/*      */     
/* 1378 */     this.stream.writeInt(offset);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void writeInfoHeader(int headerSize, int bitsPerPixel) throws IOException {
/* 1385 */     this.stream.writeInt(headerSize);
/*      */ 
/*      */     
/* 1388 */     this.stream.writeInt(this.w);
/*      */ 
/*      */     
/* 1391 */     if (this.isTopDown == true) {
/* 1392 */       this.stream.writeInt(-this.h);
/*      */     } else {
/* 1394 */       this.stream.writeInt(this.h);
/*      */     } 
/*      */     
/* 1397 */     this.stream.writeShort(1);
/*      */ 
/*      */     
/* 1400 */     this.stream.writeShort(bitsPerPixel);
/*      */   }
/*      */   
/*      */   private void writeSize(int dword, int offset) throws IOException {
/* 1404 */     this.stream.skipBytes(offset);
/* 1405 */     this.stream.writeInt(dword);
/*      */   }
/*      */   
/*      */   public void reset() {
/* 1409 */     super.reset();
/* 1410 */     this.stream = null;
/*      */   }
/*      */   
/*      */   static int getCompressionType(String typeString) {
/* 1414 */     for (int i = 0; i < BMPConstants.compressionTypeNames.length; i++) {
/* 1415 */       if (BMPConstants.compressionTypeNames[i].equals(typeString))
/* 1416 */         return i; 
/* 1417 */     }  return 0;
/*      */   }
/*      */ 
/*      */   
/*      */   private void writeEmbedded(IIOImage image, ImageWriteParam bmpParam) throws IOException {
/* 1422 */     String format = (this.compressionType == 4) ? "jpeg" : "png";
/*      */     
/* 1424 */     Iterator<ImageWriter> iterator = ImageIO.getImageWritersByFormatName(format);
/* 1425 */     ImageWriter writer = null;
/* 1426 */     if (iterator.hasNext())
/* 1427 */       writer = iterator.next(); 
/* 1428 */     if (writer != null) {
/* 1429 */       if (this.embedded_stream == null) {
/* 1430 */         throw new RuntimeException("No stream for writing embedded image!");
/*      */       }
/*      */       
/* 1433 */       writer.addIIOWriteProgressListener(new IIOWriteProgressAdapter() {
/*      */             public void imageProgress(ImageWriter source, float percentageDone) {
/* 1435 */               BMPImageWriter.this.processImageProgress(percentageDone);
/*      */             }
/*      */           });
/*      */       
/* 1439 */       writer.addIIOWriteWarningListener(new IIOWriteWarningListener() {
/*      */             public void warningOccurred(ImageWriter source, int imageIndex, String warning) {
/* 1441 */               BMPImageWriter.this.processWarningOccurred(imageIndex, warning);
/*      */             }
/*      */           });
/*      */       
/* 1445 */       ImageOutputStream emb_ios = ImageIO.createImageOutputStream(this.embedded_stream);
/*      */       
/* 1447 */       writer.setOutput(emb_ios);
/* 1448 */       ImageWriteParam param = writer.getDefaultWriteParam();
/*      */       
/* 1450 */       param.setDestinationOffset(bmpParam.getDestinationOffset());
/* 1451 */       param.setSourceBands(bmpParam.getSourceBands());
/* 1452 */       param.setSourceRegion(bmpParam.getSourceRegion());
/* 1453 */       param.setSourceSubsampling(bmpParam.getSourceXSubsampling(), bmpParam.getSourceYSubsampling(), bmpParam.getSubsamplingXOffset(), bmpParam.getSubsamplingYOffset());
/*      */ 
/*      */ 
/*      */       
/* 1457 */       writer.write((IIOMetadata)null, image, param);
/* 1458 */       emb_ios.flush();
/*      */     } else {
/* 1460 */       throw new RuntimeException(I18N.getString("BMPImageWrite5") + " " + format);
/*      */     } 
/*      */   }
/*      */   
/*      */   private int firstLowBit(int num) {
/* 1465 */     int count = 0;
/* 1466 */     while ((num & 0x1) == 0) {
/* 1467 */       count++;
/* 1468 */       num >>>= 1;
/*      */     } 
/* 1470 */     return count;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private class IIOWriteProgressAdapter
/*      */     implements IIOWriteProgressListener
/*      */   {
/*      */     private IIOWriteProgressAdapter() {}
/*      */ 
/*      */ 
/*      */     
/*      */     public void imageComplete(ImageWriter source) {}
/*      */ 
/*      */ 
/*      */     
/*      */     public void imageProgress(ImageWriter source, float percentageDone) {}
/*      */ 
/*      */ 
/*      */     
/*      */     public void imageStarted(ImageWriter source, int imageIndex) {}
/*      */ 
/*      */ 
/*      */     
/*      */     public void thumbnailComplete(ImageWriter source) {}
/*      */ 
/*      */ 
/*      */     
/*      */     public void thumbnailProgress(ImageWriter source, float percentageDone) {}
/*      */ 
/*      */     
/*      */     public void thumbnailStarted(ImageWriter source, int imageIndex, int thumbnailIndex) {}
/*      */ 
/*      */     
/*      */     public void writeAborted(ImageWriter source) {}
/*      */   }
/*      */ 
/*      */   
/*      */   static int getPreferredCompressionType(ColorModel cm, SampleModel sm) {
/* 1509 */     ImageTypeSpecifier imageType = new ImageTypeSpecifier(cm, sm);
/* 1510 */     return getPreferredCompressionType(imageType);
/*      */   }
/*      */   
/*      */   static int getPreferredCompressionType(ImageTypeSpecifier imageType) {
/* 1514 */     int biType = imageType.getBufferedImageType();
/* 1515 */     if (biType == 8 || biType == 9)
/*      */     {
/* 1517 */       return 3;
/*      */     }
/* 1519 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean canEncodeImage(int compression, ColorModel cm, SampleModel sm) {
/* 1531 */     ImageTypeSpecifier imgType = new ImageTypeSpecifier(cm, sm);
/* 1532 */     return canEncodeImage(compression, imgType);
/*      */   }
/*      */   
/*      */   protected boolean canEncodeImage(int compression, ImageTypeSpecifier imgType) {
/* 1536 */     ImageWriterSpi spi = getOriginatingProvider();
/* 1537 */     if (!spi.canEncodeImage(imgType)) {
/* 1538 */       return false;
/*      */     }
/* 1540 */     int bpp = imgType.getColorModel().getPixelSize();
/* 1541 */     if (this.compressionType == 2 && bpp != 4)
/*      */     {
/* 1543 */       return false;
/*      */     }
/* 1545 */     if (this.compressionType == 1 && bpp != 8)
/*      */     {
/* 1547 */       return false;
/*      */     }
/* 1549 */     if (bpp == 16) {
/*      */       int i, j;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1576 */       boolean canUseRGB = false;
/* 1577 */       boolean canUseBITFIELDS = false;
/*      */       
/* 1579 */       SampleModel sm = imgType.getSampleModel();
/* 1580 */       if (sm instanceof SinglePixelPackedSampleModel) {
/* 1581 */         int[] sizes = ((SinglePixelPackedSampleModel)sm).getSampleSize();
/*      */ 
/*      */         
/* 1584 */         canUseRGB = true;
/* 1585 */         canUseBITFIELDS = true;
/* 1586 */         for (int k = 0; k < sizes.length; k++) {
/* 1587 */           i = canUseRGB & ((sizes[k] == 5) ? 1 : 0);
/* 1588 */           j = canUseBITFIELDS & ((sizes[k] == 5 || (k == 1 && sizes[k] == 6)) ? 1 : 0);
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/* 1593 */       return ((this.compressionType == 0 && i != 0) || (this.compressionType == 3 && j != 0));
/*      */     } 
/*      */     
/* 1596 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   protected void writeMaskToPalette(int mask, int i, byte[] r, byte[] g, byte[] b, byte[] a) {
/* 1601 */     b[i] = (byte)(0xFF & mask >> 24);
/* 1602 */     g[i] = (byte)(0xFF & mask >> 16);
/* 1603 */     r[i] = (byte)(0xFF & mask >> 8);
/* 1604 */     a[i] = (byte)(0xFF & mask);
/*      */   }
/*      */   
/*      */   private int roundBpp(int x) {
/* 1608 */     if (x <= 8)
/* 1609 */       return 8; 
/* 1610 */     if (x <= 16)
/* 1611 */       return 16; 
/* 1612 */     if (x <= 24) {
/* 1613 */       return 24;
/*      */     }
/* 1615 */     return 32;
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/bmp/BMPImageWriter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */