/*      */ package com.sun.media.imageioimpl.plugins.bmp;
/*      */ 
/*      */ import com.sun.media.imageioimpl.common.ImageUtil;
/*      */ import java.awt.image.ColorModel;
/*      */ import java.awt.image.DirectColorModel;
/*      */ import java.awt.image.IndexColorModel;
/*      */ import java.awt.image.SampleModel;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.StringTokenizer;
/*      */ import javax.imageio.ImageWriteParam;
/*      */ import javax.imageio.metadata.IIOInvalidTreeException;
/*      */ import javax.imageio.metadata.IIOMetadata;
/*      */ import javax.imageio.metadata.IIOMetadataNode;
/*      */ import org.w3c.dom.Node;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class BMPMetadata
/*      */   extends IIOMetadata
/*      */   implements Cloneable, BMPConstants
/*      */ {
/*      */   public static final String nativeMetadataFormatName = "com_sun_media_imageio_plugins_bmp_image_1.0";
/*      */   public String bmpVersion;
/*      */   public int width;
/*      */   public int height;
/*      */   public short bitsPerPixel;
/*      */   public int compression;
/*      */   public int imageSize;
/*      */   public int xPixelsPerMeter;
/*      */   public int yPixelsPerMeter;
/*      */   public int colorsUsed;
/*      */   public int colorsImportant;
/*      */   public int redMask;
/*      */   public int greenMask;
/*      */   public int blueMask;
/*      */   public int alphaMask;
/*      */   public int colorSpace;
/*      */   public double redX;
/*      */   public double redY;
/*      */   public double redZ;
/*      */   public double greenX;
/*      */   public double greenY;
/*      */   public double greenZ;
/*      */   public double blueX;
/*      */   public double blueY;
/*      */   public double blueZ;
/*      */   public int gammaRed;
/*      */   public int gammaGreen;
/*      */   public int gammaBlue;
/*      */   public int intent;
/*  152 */   public byte[] palette = null;
/*      */   
/*      */   public int paletteSize;
/*      */   
/*      */   public int red;
/*      */   
/*      */   public int green;
/*      */   public int blue;
/*  160 */   public List comments = null;
/*      */   
/*      */   public BMPMetadata() {
/*  163 */     super(true, "com_sun_media_imageio_plugins_bmp_image_1.0", "com.sun.media.imageioimpl.bmp.BMPMetadataFormat", (String[])null, (String[])null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BMPMetadata(IIOMetadata metadata) throws IIOInvalidTreeException {
/*  172 */     this();
/*      */     
/*  174 */     if (metadata != null) {
/*  175 */       List<String> formats = Arrays.asList(metadata.getMetadataFormatNames());
/*      */       
/*  177 */       if (formats.contains("com_sun_media_imageio_plugins_bmp_image_1.0")) {
/*      */         
/*  179 */         setFromTree("com_sun_media_imageio_plugins_bmp_image_1.0", metadata.getAsTree("com_sun_media_imageio_plugins_bmp_image_1.0"));
/*      */       }
/*  181 */       else if (metadata.isStandardMetadataFormatSupported()) {
/*      */         
/*  183 */         String format = "javax_imageio_1.0";
/*      */         
/*  185 */         setFromTree(format, metadata.getAsTree(format));
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   public boolean isReadOnly() {
/*  191 */     return false;
/*      */   }
/*      */   
/*      */   public Object clone() {
/*      */     BMPMetadata metadata;
/*      */     try {
/*  197 */       metadata = (BMPMetadata)super.clone();
/*  198 */     } catch (CloneNotSupportedException e) {
/*  199 */       return null;
/*      */     } 
/*      */     
/*  202 */     return metadata;
/*      */   }
/*      */   
/*      */   public Node getAsTree(String formatName) {
/*  206 */     if (formatName.equals("com_sun_media_imageio_plugins_bmp_image_1.0"))
/*  207 */       return getNativeTree(); 
/*  208 */     if (formatName.equals("javax_imageio_1.0"))
/*      */     {
/*  210 */       return getStandardTree();
/*      */     }
/*  212 */     throw new IllegalArgumentException(I18N.getString("BMPMetadata0"));
/*      */   }
/*      */ 
/*      */   
/*      */   private Node getNativeTree() {
/*  217 */     IIOMetadataNode root = new IIOMetadataNode("com_sun_media_imageio_plugins_bmp_image_1.0");
/*      */ 
/*      */     
/*  220 */     addChildNode(root, "BMPVersion", this.bmpVersion);
/*  221 */     addChildNode(root, "Width", new Integer(this.width));
/*  222 */     addChildNode(root, "Height", new Integer(this.height));
/*  223 */     addChildNode(root, "BitsPerPixel", new Short(this.bitsPerPixel));
/*  224 */     addChildNode(root, "Compression", new Integer(this.compression));
/*  225 */     addChildNode(root, "ImageSize", new Integer(this.imageSize));
/*      */ 
/*      */     
/*  228 */     if (this.xPixelsPerMeter > 0 && this.yPixelsPerMeter > 0) {
/*  229 */       IIOMetadataNode node = addChildNode(root, "PixelsPerMeter", (Object)null);
/*  230 */       addChildNode(node, "X", new Integer(this.xPixelsPerMeter));
/*  231 */       addChildNode(node, "Y", new Integer(this.yPixelsPerMeter));
/*      */     } 
/*      */     
/*  234 */     addChildNode(root, "ColorsUsed", new Integer(this.colorsUsed));
/*  235 */     addChildNode(root, "ColorsImportant", new Integer(this.colorsImportant));
/*      */     
/*  237 */     int version = 0;
/*  238 */     for (int i = 0; i < this.bmpVersion.length(); i++) {
/*  239 */       if (Character.isDigit(this.bmpVersion.charAt(i)))
/*  240 */         version = this.bmpVersion.charAt(i) - 48; 
/*      */     } 
/*  242 */     if (version >= 4) {
/*  243 */       IIOMetadataNode node = addChildNode(root, "Mask", (Object)null);
/*  244 */       addChildNode(node, "Red", new Integer(this.redMask));
/*  245 */       addChildNode(node, "Green", new Integer(this.greenMask));
/*  246 */       addChildNode(node, "Blue", new Integer(this.blueMask));
/*  247 */       addChildNode(node, "Alpha", new Integer(this.alphaMask));
/*      */       
/*  249 */       addChildNode(root, "ColorSpaceType", new Integer(this.colorSpace));
/*      */       
/*  251 */       node = addChildNode(root, "CIEXYZEndpoints", (Object)null);
/*  252 */       addXYZPoints(node, "Red", this.redX, this.redY, this.redZ);
/*  253 */       addXYZPoints(node, "Green", this.greenX, this.greenY, this.greenZ);
/*  254 */       addXYZPoints(node, "Blue", this.blueX, this.blueY, this.blueZ);
/*      */       
/*  256 */       node = addChildNode(root, "Gamma", (Object)null);
/*  257 */       addChildNode(node, "Red", new Integer(this.gammaRed));
/*  258 */       addChildNode(node, "Green", new Integer(this.gammaGreen));
/*  259 */       addChildNode(node, "Blue", new Integer(this.gammaBlue));
/*      */       
/*  261 */       node = addChildNode(root, "Intent", new Integer(this.intent));
/*      */     } 
/*      */ 
/*      */     
/*  265 */     if (this.palette != null && this.paletteSize > 0) {
/*  266 */       IIOMetadataNode node = addChildNode(root, "Palette", (Object)null);
/*  267 */       boolean isVersion2 = (this.bmpVersion != null && this.bmpVersion.equals("BMP v. 2.x"));
/*      */ 
/*      */       
/*  270 */       for (int k = 0, j = 0; k < this.paletteSize; k++) {
/*  271 */         IIOMetadataNode entry = addChildNode(node, "PaletteEntry", (Object)null);
/*      */         
/*  273 */         this.blue = this.palette[j++] & 0xFF;
/*  274 */         this.green = this.palette[j++] & 0xFF;
/*  275 */         this.red = this.palette[j++] & 0xFF;
/*  276 */         addChildNode(entry, "Red", new Integer(this.red));
/*  277 */         addChildNode(entry, "Green", new Integer(this.green));
/*  278 */         addChildNode(entry, "Blue", new Integer(this.blue));
/*  279 */         if (!isVersion2) j++;
/*      */       
/*      */       } 
/*      */     } 
/*  283 */     return root;
/*      */   }
/*      */ 
/*      */   
/*      */   protected IIOMetadataNode getStandardChromaNode() {
/*      */     String colorSpaceType, numChannels;
/*  289 */     IIOMetadataNode node = new IIOMetadataNode("Chroma");
/*      */     
/*  291 */     IIOMetadataNode subNode = new IIOMetadataNode("ColorSpaceType");
/*      */     
/*  293 */     if ((this.palette != null && this.paletteSize > 0) || this.redMask != 0 || this.greenMask != 0 || this.blueMask != 0 || this.bitsPerPixel > 8) {
/*      */ 
/*      */       
/*  296 */       colorSpaceType = "RGB";
/*      */     } else {
/*  298 */       colorSpaceType = "GRAY";
/*      */     } 
/*  300 */     subNode.setAttribute("name", colorSpaceType);
/*  301 */     node.appendChild(subNode);
/*      */     
/*  303 */     subNode = new IIOMetadataNode("NumChannels");
/*      */     
/*  305 */     if ((this.palette != null && this.paletteSize > 0) || this.redMask != 0 || this.greenMask != 0 || this.blueMask != 0 || this.bitsPerPixel > 8) {
/*      */ 
/*      */       
/*  308 */       if (this.alphaMask != 0) {
/*  309 */         numChannels = "4";
/*      */       } else {
/*  311 */         numChannels = "3";
/*      */       } 
/*      */     } else {
/*  314 */       numChannels = "1";
/*      */     } 
/*  316 */     subNode.setAttribute("value", numChannels);
/*  317 */     node.appendChild(subNode);
/*      */     
/*  319 */     if (this.gammaRed != 0 && this.gammaGreen != 0 && this.gammaBlue != 0) {
/*  320 */       subNode = new IIOMetadataNode("Gamma");
/*  321 */       Double gamma = new Double((this.gammaRed + this.gammaGreen + this.gammaBlue) / 3.0D);
/*  322 */       subNode.setAttribute("value", gamma.toString());
/*  323 */       node.appendChild(subNode);
/*      */     } 
/*      */     
/*  326 */     if (numChannels.equals("1") && (this.palette == null || this.paletteSize == 0)) {
/*      */       
/*  328 */       subNode = new IIOMetadataNode("BlackIsZero");
/*  329 */       subNode.setAttribute("value", "TRUE");
/*  330 */       node.appendChild(subNode);
/*      */     } 
/*      */     
/*  333 */     if (this.palette != null && this.paletteSize > 0) {
/*  334 */       subNode = new IIOMetadataNode("Palette");
/*  335 */       boolean isVersion2 = (this.bmpVersion != null && this.bmpVersion.equals("BMP v. 2.x"));
/*      */ 
/*      */       
/*  338 */       for (int i = 0, j = 0; i < this.paletteSize; i++) {
/*  339 */         IIOMetadataNode subNode1 = new IIOMetadataNode("PaletteEntry");
/*      */         
/*  341 */         subNode1.setAttribute("index", "" + i);
/*  342 */         subNode1.setAttribute("blue", "" + (this.palette[j++] & 0xFF));
/*  343 */         subNode1.setAttribute("green", "" + (this.palette[j++] & 0xFF));
/*  344 */         subNode1.setAttribute("red", "" + (this.palette[j++] & 0xFF));
/*  345 */         if (!isVersion2) j++; 
/*  346 */         subNode.appendChild(subNode1);
/*      */       } 
/*  348 */       node.appendChild(subNode);
/*      */     } 
/*      */     
/*  351 */     return node;
/*      */   }
/*      */   
/*      */   protected IIOMetadataNode getStandardCompressionNode() {
/*  355 */     IIOMetadataNode node = new IIOMetadataNode("Compression");
/*      */ 
/*      */     
/*  358 */     IIOMetadataNode subNode = new IIOMetadataNode("CompressionTypeName");
/*  359 */     subNode.setAttribute("value", compressionTypeNames[this.compression]);
/*  360 */     node.appendChild(subNode);
/*      */     
/*  362 */     subNode = new IIOMetadataNode("Lossless");
/*  363 */     subNode.setAttribute("value", (this.compression == 4) ? "FALSE" : "TRUE");
/*      */     
/*  365 */     node.appendChild(subNode);
/*      */     
/*  367 */     return node;
/*      */   }
/*      */   
/*      */   protected IIOMetadataNode getStandardDataNode() {
/*  371 */     IIOMetadataNode node = new IIOMetadataNode("Data");
/*      */     
/*  373 */     String sampleFormat = (this.palette != null && this.paletteSize > 0) ? "Index" : "UnsignedIntegral";
/*      */     
/*  375 */     IIOMetadataNode subNode = new IIOMetadataNode("SampleFormat");
/*  376 */     subNode.setAttribute("value", sampleFormat);
/*  377 */     node.appendChild(subNode);
/*      */     
/*  379 */     String bits = "";
/*  380 */     if (this.redMask != 0 || this.greenMask != 0 || this.blueMask != 0) {
/*  381 */       bits = countBits(this.redMask) + " " + countBits(this.greenMask) + " " + countBits(this.blueMask);
/*      */ 
/*      */ 
/*      */       
/*  385 */       if (this.alphaMask != 0) {
/*  386 */         bits = bits + " " + countBits(this.alphaMask);
/*      */       }
/*  388 */     } else if (this.palette != null && this.paletteSize > 0) {
/*  389 */       for (int i = 1; i <= 3; i++) {
/*  390 */         bits = bits + this.bitsPerPixel;
/*  391 */         if (i != 3) {
/*  392 */           bits = bits + " ";
/*      */         }
/*      */       }
/*      */     
/*  396 */     } else if (this.bitsPerPixel == 1) {
/*  397 */       bits = "1";
/*  398 */     } else if (this.bitsPerPixel == 4) {
/*  399 */       bits = "4";
/*  400 */     } else if (this.bitsPerPixel == 8) {
/*  401 */       bits = "8";
/*  402 */     } else if (this.bitsPerPixel == 16) {
/*  403 */       bits = "5 6 5";
/*  404 */     } else if (this.bitsPerPixel == 24) {
/*  405 */       bits = "8 8 8";
/*  406 */     } else if (this.bitsPerPixel == 32) {
/*  407 */       bits = "8 8 8 8";
/*      */     } 
/*      */ 
/*      */     
/*  411 */     if (!bits.equals("")) {
/*  412 */       subNode = new IIOMetadataNode("BitsPerSample");
/*  413 */       subNode.setAttribute("value", bits);
/*  414 */       node.appendChild(subNode);
/*      */     } 
/*      */     
/*  417 */     return node;
/*      */   }
/*      */   
/*      */   protected IIOMetadataNode getStandardDimensionNode() {
/*  421 */     if (this.yPixelsPerMeter > 0 && this.xPixelsPerMeter > 0) {
/*  422 */       IIOMetadataNode node = new IIOMetadataNode("Dimension");
/*  423 */       float ratio = this.yPixelsPerMeter / this.xPixelsPerMeter;
/*  424 */       IIOMetadataNode subNode = new IIOMetadataNode("PixelAspectRatio");
/*  425 */       subNode.setAttribute("value", "" + ratio);
/*  426 */       node.appendChild(subNode);
/*      */       
/*  428 */       subNode = new IIOMetadataNode("HorizontalPixelSize");
/*  429 */       subNode.setAttribute("value", "" + (1000.0F / this.xPixelsPerMeter));
/*  430 */       node.appendChild(subNode);
/*      */       
/*  432 */       subNode = new IIOMetadataNode("VerticalPixelSize");
/*  433 */       subNode.setAttribute("value", "" + (1000.0F / this.yPixelsPerMeter));
/*  434 */       node.appendChild(subNode);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  440 */       subNode = new IIOMetadataNode("HorizontalPhysicalPixelSpacing");
/*  441 */       subNode.setAttribute("value", "" + (1000.0F / this.xPixelsPerMeter));
/*  442 */       node.appendChild(subNode);
/*      */       
/*  444 */       subNode = new IIOMetadataNode("VerticalPhysicalPixelSpacing");
/*  445 */       subNode.setAttribute("value", "" + (1000.0F / this.yPixelsPerMeter));
/*  446 */       node.appendChild(subNode);
/*      */       
/*  448 */       return node;
/*      */     } 
/*  450 */     return null;
/*      */   }
/*      */   
/*      */   protected IIOMetadataNode getStandardDocumentNode() {
/*  454 */     if (this.bmpVersion != null) {
/*  455 */       IIOMetadataNode node = new IIOMetadataNode("Document");
/*  456 */       IIOMetadataNode subNode = new IIOMetadataNode("FormatVersion");
/*  457 */       subNode.setAttribute("value", this.bmpVersion);
/*  458 */       node.appendChild(subNode);
/*  459 */       return node;
/*      */     } 
/*  461 */     return null;
/*      */   }
/*      */   
/*      */   protected IIOMetadataNode getStandardTextNode() {
/*  465 */     if (this.comments != null) {
/*  466 */       IIOMetadataNode node = new IIOMetadataNode("Text");
/*  467 */       Iterator<String> iter = this.comments.iterator();
/*  468 */       while (iter.hasNext()) {
/*  469 */         String comment = iter.next();
/*  470 */         IIOMetadataNode subNode = new IIOMetadataNode("TextEntry");
/*  471 */         subNode.setAttribute("keyword", "comment");
/*  472 */         subNode.setAttribute("value", comment);
/*  473 */         node.appendChild(subNode);
/*      */       } 
/*  475 */       return node;
/*      */     } 
/*  477 */     return null;
/*      */   }
/*      */   protected IIOMetadataNode getStandardTransparencyNode() {
/*      */     String alpha;
/*  481 */     IIOMetadataNode node = new IIOMetadataNode("Transparency");
/*  482 */     IIOMetadataNode subNode = new IIOMetadataNode("Alpha");
/*      */     
/*  484 */     if (this.alphaMask != 0) {
/*  485 */       alpha = "nonpremultiplied";
/*      */     } else {
/*  487 */       alpha = "none";
/*      */     } 
/*      */     
/*  490 */     subNode.setAttribute("value", alpha);
/*  491 */     node.appendChild(subNode);
/*  492 */     return node;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void fatal(Node node, String reason) throws IIOInvalidTreeException {
/*  498 */     throw new IIOInvalidTreeException(reason, node);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int getIntAttribute(Node node, String name, int defaultValue, boolean required) throws IIOInvalidTreeException {
/*  505 */     String value = getAttribute(node, name, (String)null, required);
/*  506 */     if (value == null) {
/*  507 */       return defaultValue;
/*      */     }
/*  509 */     return Integer.parseInt(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private double getDoubleAttribute(Node node, String name, double defaultValue, boolean required) throws IIOInvalidTreeException {
/*  516 */     String value = getAttribute(node, name, (String)null, required);
/*  517 */     if (value == null) {
/*  518 */       return defaultValue;
/*      */     }
/*  520 */     return Double.parseDouble(value);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private int getIntAttribute(Node node, String name) throws IIOInvalidTreeException {
/*  526 */     return getIntAttribute(node, name, -1, true);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private double getDoubleAttribute(Node node, String name) throws IIOInvalidTreeException {
/*  532 */     return getDoubleAttribute(node, name, -1.0D, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String getAttribute(Node node, String name, String defaultValue, boolean required) throws IIOInvalidTreeException {
/*  539 */     Node attr = node.getAttributes().getNamedItem(name);
/*  540 */     if (attr == null) {
/*  541 */       if (!required) {
/*  542 */         return defaultValue;
/*      */       }
/*  544 */       fatal(node, "Required attribute " + name + " not present!");
/*      */     } 
/*      */     
/*  547 */     return attr.getNodeValue();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private String getAttribute(Node node, String name) throws IIOInvalidTreeException {
/*  553 */     return getAttribute(node, name, (String)null, true);
/*      */   }
/*      */ 
/*      */   
/*      */   void initialize(ColorModel cm, SampleModel sm, ImageWriteParam param) {
/*  558 */     if (param != null) {
/*  559 */       this.bmpVersion = "BMP v. 3.x";
/*      */       
/*  561 */       if (param.getCompressionMode() == 2) {
/*  562 */         String compressionType = param.getCompressionType();
/*  563 */         this.compression = BMPImageWriter.getCompressionType(compressionType);
/*      */       } 
/*      */     } else {
/*      */       
/*  567 */       this.bmpVersion = "BMP v. 3.x";
/*  568 */       this.compression = BMPImageWriter.getPreferredCompressionType(cm, sm);
/*      */     } 
/*      */ 
/*      */     
/*  572 */     this.width = sm.getWidth();
/*  573 */     this.height = sm.getHeight();
/*      */ 
/*      */     
/*  576 */     this.bitsPerPixel = (short)cm.getPixelSize();
/*      */ 
/*      */     
/*  579 */     if (cm instanceof DirectColorModel) {
/*  580 */       DirectColorModel dcm = (DirectColorModel)cm;
/*  581 */       this.redMask = dcm.getRedMask();
/*  582 */       this.greenMask = dcm.getGreenMask();
/*  583 */       this.blueMask = dcm.getBlueMask();
/*  584 */       this.alphaMask = dcm.getAlphaMask();
/*      */     } 
/*      */ 
/*      */     
/*  588 */     if (cm instanceof IndexColorModel) {
/*  589 */       IndexColorModel icm = (IndexColorModel)cm;
/*  590 */       this.paletteSize = icm.getMapSize();
/*      */       
/*  592 */       byte[] r = new byte[this.paletteSize];
/*  593 */       byte[] g = new byte[this.paletteSize];
/*  594 */       byte[] b = new byte[this.paletteSize];
/*      */       
/*  596 */       icm.getReds(r);
/*  597 */       icm.getGreens(g);
/*  598 */       icm.getBlues(b);
/*      */       
/*  600 */       boolean isVersion2 = (this.bmpVersion != null && this.bmpVersion.equals("BMP v. 2.x"));
/*      */ 
/*      */       
/*  603 */       this.palette = new byte[(isVersion2 ? 3 : 4) * this.paletteSize];
/*  604 */       for (int i = 0, j = 0; i < this.paletteSize; i++) {
/*  605 */         this.palette[j++] = b[i];
/*  606 */         this.palette[j++] = g[i];
/*  607 */         this.palette[j++] = r[i];
/*  608 */         if (!isVersion2) j++;
/*      */       
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   public void mergeTree(String formatName, Node root) throws IIOInvalidTreeException {
/*  615 */     if (formatName.equals("com_sun_media_imageio_plugins_bmp_image_1.0")) {
/*  616 */       if (root == null) {
/*  617 */         throw new IllegalArgumentException("root == null!");
/*      */       }
/*  619 */       mergeNativeTree(root);
/*  620 */     } else if (formatName.equals("javax_imageio_1.0")) {
/*      */       
/*  622 */       if (root == null) {
/*  623 */         throw new IllegalArgumentException("root == null!");
/*      */       }
/*  625 */       mergeStandardTree(root);
/*      */     } else {
/*  627 */       throw new IllegalArgumentException("Not a recognized format!");
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void mergeNativeTree(Node root) throws IIOInvalidTreeException {
/*  633 */     Node node = root;
/*  634 */     if (!node.getNodeName().equals("com_sun_media_imageio_plugins_bmp_image_1.0")) {
/*  635 */       fatal(node, "Root must be com_sun_media_imageio_plugins_bmp_image_1.0");
/*      */     }
/*      */     
/*  638 */     byte[] r = null, g = null, b = null;
/*  639 */     int maxIndex = -1;
/*      */     
/*  641 */     node = node.getFirstChild();
/*  642 */     while (node != null) {
/*  643 */       String name = node.getNodeName();
/*      */       
/*  645 */       if (name.equals("BMPVersion")) {
/*  646 */         String value = getStringValue(node);
/*  647 */         if (value != null) this.bmpVersion = value; 
/*  648 */       } else if (name.equals("Width")) {
/*  649 */         Integer value = getIntegerValue(node);
/*  650 */         if (value != null) this.width = value.intValue(); 
/*  651 */       } else if (name.equals("Height")) {
/*  652 */         Integer value = getIntegerValue(node);
/*  653 */         if (value != null) this.height = value.intValue(); 
/*  654 */       } else if (name.equals("BitsPerPixel")) {
/*  655 */         Short value = getShortValue(node);
/*  656 */         if (value != null) this.bitsPerPixel = value.shortValue(); 
/*  657 */       } else if (name.equals("Compression")) {
/*  658 */         Integer value = getIntegerValue(node);
/*  659 */         if (value != null) this.compression = value.intValue(); 
/*  660 */       } else if (name.equals("ImageSize")) {
/*  661 */         Integer value = getIntegerValue(node);
/*  662 */         if (value != null) this.imageSize = value.intValue(); 
/*  663 */       } else if (name.equals("PixelsPerMeter")) {
/*  664 */         Node subNode = node.getFirstChild();
/*  665 */         while (subNode != null) {
/*  666 */           String subName = subNode.getNodeName();
/*  667 */           if (subName.equals("X")) {
/*  668 */             Integer value = getIntegerValue(subNode);
/*  669 */             if (value != null)
/*  670 */               this.xPixelsPerMeter = value.intValue(); 
/*  671 */           } else if (subName.equals("Y")) {
/*  672 */             Integer value = getIntegerValue(subNode);
/*  673 */             if (value != null)
/*  674 */               this.yPixelsPerMeter = value.intValue(); 
/*      */           } 
/*  676 */           subNode = subNode.getNextSibling();
/*      */         } 
/*  678 */       } else if (name.equals("ColorsUsed")) {
/*  679 */         Integer value = getIntegerValue(node);
/*  680 */         if (value != null) this.colorsUsed = value.intValue(); 
/*  681 */       } else if (name.equals("ColorsImportant")) {
/*  682 */         Integer value = getIntegerValue(node);
/*  683 */         if (value != null) this.colorsImportant = value.intValue(); 
/*  684 */       } else if (name.equals("Mask")) {
/*  685 */         Node subNode = node.getFirstChild();
/*  686 */         while (subNode != null) {
/*  687 */           String subName = subNode.getNodeName();
/*  688 */           if (subName.equals("Red")) {
/*  689 */             Integer value = getIntegerValue(subNode);
/*  690 */             if (value != null)
/*  691 */               this.redMask = value.intValue(); 
/*  692 */           } else if (subName.equals("Green")) {
/*  693 */             Integer value = getIntegerValue(subNode);
/*  694 */             if (value != null)
/*  695 */               this.greenMask = value.intValue(); 
/*  696 */           } else if (subName.equals("Blue")) {
/*  697 */             Integer value = getIntegerValue(subNode);
/*  698 */             if (value != null)
/*  699 */               this.blueMask = value.intValue(); 
/*  700 */           } else if (subName.equals("Alpha")) {
/*  701 */             Integer value = getIntegerValue(subNode);
/*  702 */             if (value != null)
/*  703 */               this.alphaMask = value.intValue(); 
/*      */           } 
/*  705 */           subNode = subNode.getNextSibling();
/*      */         } 
/*  707 */       } else if (name.equals("ColorSpace")) {
/*  708 */         Integer value = getIntegerValue(node);
/*  709 */         if (value != null) this.colorSpace = value.intValue(); 
/*  710 */       } else if (name.equals("CIEXYZEndpoints")) {
/*  711 */         Node subNode = node.getFirstChild();
/*  712 */         while (subNode != null) {
/*  713 */           String subName = subNode.getNodeName();
/*  714 */           if (subName.equals("Red")) {
/*  715 */             Node subNode1 = subNode.getFirstChild();
/*  716 */             while (subNode1 != null) {
/*  717 */               String subName1 = subNode1.getNodeName();
/*  718 */               if (subName1.equals("X")) {
/*  719 */                 Double value = getDoubleValue(subNode1);
/*  720 */                 if (value != null)
/*  721 */                   this.redX = value.doubleValue(); 
/*  722 */               } else if (subName1.equals("Y")) {
/*  723 */                 Double value = getDoubleValue(subNode1);
/*  724 */                 if (value != null)
/*  725 */                   this.redY = value.doubleValue(); 
/*  726 */               } else if (subName1.equals("Z")) {
/*  727 */                 Double value = getDoubleValue(subNode1);
/*  728 */                 if (value != null)
/*  729 */                   this.redZ = value.doubleValue(); 
/*      */               } 
/*  731 */               subNode1 = subNode1.getNextSibling();
/*      */             } 
/*  733 */           } else if (subName.equals("Green")) {
/*  734 */             Node subNode1 = subNode.getFirstChild();
/*  735 */             while (subNode1 != null) {
/*  736 */               String subName1 = subNode1.getNodeName();
/*  737 */               if (subName1.equals("X")) {
/*  738 */                 Double value = getDoubleValue(subNode1);
/*  739 */                 if (value != null)
/*  740 */                   this.greenX = value.doubleValue(); 
/*  741 */               } else if (subName1.equals("Y")) {
/*  742 */                 Double value = getDoubleValue(subNode1);
/*  743 */                 if (value != null)
/*  744 */                   this.greenY = value.doubleValue(); 
/*  745 */               } else if (subName1.equals("Z")) {
/*  746 */                 Double value = getDoubleValue(subNode1);
/*  747 */                 if (value != null)
/*  748 */                   this.greenZ = value.doubleValue(); 
/*      */               } 
/*  750 */               subNode1 = subNode1.getNextSibling();
/*      */             } 
/*  752 */           } else if (subName.equals("Blue")) {
/*  753 */             Node subNode1 = subNode.getFirstChild();
/*  754 */             while (subNode1 != null) {
/*  755 */               String subName1 = subNode1.getNodeName();
/*  756 */               if (subName1.equals("X")) {
/*  757 */                 Double value = getDoubleValue(subNode1);
/*  758 */                 if (value != null)
/*  759 */                   this.blueX = value.doubleValue(); 
/*  760 */               } else if (subName1.equals("Y")) {
/*  761 */                 Double value = getDoubleValue(subNode1);
/*  762 */                 if (value != null)
/*  763 */                   this.blueY = value.doubleValue(); 
/*  764 */               } else if (subName1.equals("Z")) {
/*  765 */                 Double value = getDoubleValue(subNode1);
/*  766 */                 if (value != null)
/*  767 */                   this.blueZ = value.doubleValue(); 
/*      */               } 
/*  769 */               subNode1 = subNode1.getNextSibling();
/*      */             } 
/*      */           } 
/*  772 */           subNode = subNode.getNextSibling();
/*      */         } 
/*  774 */       } else if (name.equals("Gamma")) {
/*  775 */         Node subNode = node.getFirstChild();
/*  776 */         while (subNode != null) {
/*  777 */           String subName = subNode.getNodeName();
/*  778 */           if (subName.equals("Red")) {
/*  779 */             Integer value = getIntegerValue(subNode);
/*  780 */             if (value != null)
/*  781 */               this.gammaRed = value.intValue(); 
/*  782 */           } else if (subName.equals("Green")) {
/*  783 */             Integer value = getIntegerValue(subNode);
/*  784 */             if (value != null)
/*  785 */               this.gammaGreen = value.intValue(); 
/*  786 */           } else if (subName.equals("Blue")) {
/*  787 */             Integer value = getIntegerValue(subNode);
/*  788 */             if (value != null)
/*  789 */               this.gammaBlue = value.intValue(); 
/*      */           } 
/*  791 */           subNode = subNode.getNextSibling();
/*      */         } 
/*  793 */       } else if (name.equals("Intent")) {
/*  794 */         Integer value = getIntegerValue(node);
/*  795 */         if (value != null) this.intent = value.intValue(); 
/*  796 */       } else if (name.equals("Palette")) {
/*  797 */         this.paletteSize = getIntAttribute(node, "sizeOfPalette");
/*      */         
/*  799 */         r = new byte[this.paletteSize];
/*  800 */         g = new byte[this.paletteSize];
/*  801 */         b = new byte[this.paletteSize];
/*  802 */         maxIndex = -1;
/*      */         
/*  804 */         Node paletteEntry = node.getFirstChild();
/*  805 */         if (paletteEntry == null) {
/*  806 */           fatal(node, "Palette has no entries!");
/*      */         }
/*      */         
/*  809 */         int numPaletteEntries = 0;
/*  810 */         while (paletteEntry != null) {
/*  811 */           if (!paletteEntry.getNodeName().equals("PaletteEntry")) {
/*  812 */             fatal(node, "Only a PaletteEntry may be a child of a Palette!");
/*      */           }
/*      */ 
/*      */           
/*  816 */           int index = -1;
/*  817 */           Node subNode = paletteEntry.getFirstChild();
/*  818 */           while (subNode != null) {
/*  819 */             String subName = subNode.getNodeName();
/*  820 */             if (subName.equals("Index")) {
/*  821 */               Integer value = getIntegerValue(subNode);
/*  822 */               if (value != null)
/*  823 */                 index = value.intValue(); 
/*  824 */               if (index < 0 || index > this.paletteSize - 1) {
/*  825 */                 fatal(node, "Bad value for PaletteEntry attribute index!");
/*      */               }
/*      */             }
/*  828 */             else if (subName.equals("Red")) {
/*  829 */               Integer value = getIntegerValue(subNode);
/*  830 */               if (value != null)
/*  831 */                 this.red = value.intValue(); 
/*  832 */             } else if (subName.equals("Green")) {
/*  833 */               Integer value = getIntegerValue(subNode);
/*  834 */               if (value != null)
/*  835 */                 this.green = value.intValue(); 
/*  836 */             } else if (subName.equals("Blue")) {
/*  837 */               Integer value = getIntegerValue(subNode);
/*  838 */               if (value != null)
/*  839 */                 this.blue = value.intValue(); 
/*      */             } 
/*  841 */             subNode = subNode.getNextSibling();
/*      */           } 
/*      */           
/*  844 */           if (index == -1) {
/*  845 */             index = numPaletteEntries;
/*      */           }
/*  847 */           if (index > maxIndex) {
/*  848 */             maxIndex = index;
/*      */           }
/*      */           
/*  851 */           r[index] = (byte)this.red;
/*  852 */           g[index] = (byte)this.green;
/*  853 */           b[index] = (byte)this.blue;
/*      */           
/*  855 */           numPaletteEntries++;
/*  856 */           paletteEntry = paletteEntry.getNextSibling();
/*      */         } 
/*  858 */       } else if (name.equals("CommentExtensions")) {
/*      */         
/*  860 */         Node commentExtension = node.getFirstChild();
/*  861 */         if (commentExtension == null) {
/*  862 */           fatal(node, "CommentExtensions has no entries!");
/*      */         }
/*      */         
/*  865 */         if (this.comments == null) {
/*  866 */           this.comments = new ArrayList();
/*      */         }
/*      */         
/*  869 */         while (commentExtension != null) {
/*  870 */           if (!commentExtension.getNodeName().equals("CommentExtension")) {
/*  871 */             fatal(node, "Only a CommentExtension may be a child of a CommentExtensions!");
/*      */           }
/*      */ 
/*      */           
/*  875 */           this.comments.add(getAttribute(commentExtension, "value"));
/*      */           
/*  877 */           commentExtension = commentExtension.getNextSibling();
/*      */         } 
/*      */       } else {
/*  880 */         fatal(node, "Unknown child of root node!");
/*      */       } 
/*      */       
/*  883 */       node = node.getNextSibling();
/*      */     } 
/*      */     
/*  886 */     if (r != null && g != null && b != null) {
/*  887 */       boolean isVersion2 = (this.bmpVersion != null && this.bmpVersion.equals("BMP v. 2.x"));
/*      */ 
/*      */       
/*  890 */       int numEntries = maxIndex + 1;
/*  891 */       this.palette = new byte[(isVersion2 ? 3 : 4) * numEntries];
/*  892 */       for (int i = 0, j = 0; i < numEntries; i++) {
/*  893 */         this.palette[j++] = b[i];
/*  894 */         this.palette[j++] = g[i];
/*  895 */         this.palette[j++] = r[i];
/*  896 */         if (!isVersion2) j++;
/*      */       
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private void mergeStandardTree(Node root) throws IIOInvalidTreeException {
/*  903 */     Node node = root;
/*  904 */     if (!node.getNodeName().equals("javax_imageio_1.0"))
/*      */     {
/*  906 */       fatal(node, "Root must be javax_imageio_1.0");
/*      */     }
/*      */ 
/*      */     
/*  910 */     String colorSpaceType = null;
/*  911 */     int numChannels = 0;
/*  912 */     int[] bitsPerSample = null;
/*  913 */     boolean hasAlpha = false;
/*      */     
/*  915 */     byte[] r = null, g = null, b = null;
/*  916 */     int maxIndex = -1;
/*      */     
/*  918 */     node = node.getFirstChild();
/*  919 */     while (node != null) {
/*  920 */       String name = node.getNodeName();
/*      */       
/*  922 */       if (name.equals("Chroma")) {
/*  923 */         Node child = node.getFirstChild();
/*  924 */         while (child != null) {
/*  925 */           String childName = child.getNodeName();
/*  926 */           if (childName.equals("ColorSpaceType")) {
/*  927 */             colorSpaceType = getAttribute(child, "name");
/*  928 */           } else if (childName.equals("NumChannels")) {
/*  929 */             numChannels = getIntAttribute(child, "value");
/*  930 */           } else if (childName.equals("Gamma")) {
/*  931 */             this.gammaRed = this.gammaGreen = this.gammaBlue = (int)(getDoubleAttribute(child, "value") + 0.5D);
/*      */           }
/*  933 */           else if (childName.equals("Palette")) {
/*  934 */             r = new byte[256];
/*  935 */             g = new byte[256];
/*  936 */             b = new byte[256];
/*  937 */             maxIndex = -1;
/*      */             
/*  939 */             Node paletteEntry = child.getFirstChild();
/*  940 */             if (paletteEntry == null) {
/*  941 */               fatal(node, "Palette has no entries!");
/*      */             }
/*      */             
/*  944 */             while (paletteEntry != null) {
/*  945 */               if (!paletteEntry.getNodeName().equals("PaletteEntry")) {
/*  946 */                 fatal(node, "Only a PaletteEntry may be a child of a Palette!");
/*      */               }
/*      */ 
/*      */               
/*  950 */               int index = getIntAttribute(paletteEntry, "index");
/*  951 */               if (index < 0 || index > 255) {
/*  952 */                 fatal(node, "Bad value for PaletteEntry attribute index!");
/*      */               }
/*      */               
/*  955 */               if (index > maxIndex) {
/*  956 */                 maxIndex = index;
/*      */               }
/*  958 */               r[index] = (byte)getIntAttribute(paletteEntry, "red");
/*      */               
/*  960 */               g[index] = (byte)getIntAttribute(paletteEntry, "green");
/*      */               
/*  962 */               b[index] = (byte)getIntAttribute(paletteEntry, "blue");
/*      */ 
/*      */               
/*  965 */               paletteEntry = paletteEntry.getNextSibling();
/*      */             } 
/*      */           } 
/*      */           
/*  969 */           child = child.getNextSibling();
/*      */         } 
/*  971 */       } else if (name.equals("Compression")) {
/*  972 */         Node child = node.getFirstChild();
/*  973 */         while (child != null) {
/*  974 */           String childName = child.getNodeName();
/*  975 */           if (childName.equals("CompressionTypeName")) {
/*  976 */             String compressionName = getAttribute(child, "value");
/*  977 */             this.compression = BMPImageWriter.getCompressionType(compressionName);
/*      */           } 
/*      */           
/*  980 */           child = child.getNextSibling();
/*      */         } 
/*  982 */       } else if (name.equals("Data")) {
/*  983 */         Node child = node.getFirstChild();
/*  984 */         while (child != null) {
/*  985 */           String childName = child.getNodeName();
/*  986 */           if (childName.equals("BitsPerSample")) {
/*  987 */             List<Integer> bps = new ArrayList(4);
/*  988 */             String s = getAttribute(child, "value");
/*  989 */             StringTokenizer t = new StringTokenizer(s);
/*  990 */             while (t.hasMoreTokens()) {
/*  991 */               bps.add(Integer.valueOf(t.nextToken()));
/*      */             }
/*  993 */             bitsPerSample = new int[bps.size()];
/*  994 */             for (int i = 0; i < bitsPerSample.length; i++) {
/*  995 */               bitsPerSample[i] = ((Integer)bps.get(i)).intValue();
/*      */             }
/*      */             
/*      */             break;
/*      */           } 
/* 1000 */           child = child.getNextSibling();
/*      */         } 
/* 1002 */       } else if (name.equals("Dimension")) {
/* 1003 */         boolean gotWidth = false;
/* 1004 */         boolean gotHeight = false;
/* 1005 */         boolean gotAspectRatio = false;
/* 1006 */         boolean gotSpaceX = false;
/* 1007 */         boolean gotSpaceY = false;
/*      */         
/* 1009 */         double width = -1.0D;
/* 1010 */         double height = -1.0D;
/* 1011 */         double aspectRatio = -1.0D;
/* 1012 */         double spaceX = -1.0D;
/* 1013 */         double spaceY = -1.0D;
/*      */         
/* 1015 */         Node child = node.getFirstChild();
/* 1016 */         while (child != null) {
/* 1017 */           String childName = child.getNodeName();
/* 1018 */           if (childName.equals("PixelAspectRatio")) {
/* 1019 */             aspectRatio = getDoubleAttribute(child, "value");
/* 1020 */             gotAspectRatio = true;
/* 1021 */           } else if (childName.equals("HorizontalPixelSize")) {
/* 1022 */             width = getDoubleAttribute(child, "value");
/* 1023 */             gotWidth = true;
/* 1024 */           } else if (childName.equals("VerticalPixelSize")) {
/* 1025 */             height = getDoubleAttribute(child, "value");
/* 1026 */             gotHeight = true;
/* 1027 */           } else if (childName.equals("HorizontalPhysicalPixelSpacing")) {
/* 1028 */             spaceX = getDoubleAttribute(child, "value");
/* 1029 */             gotSpaceX = true;
/* 1030 */           } else if (childName.equals("VerticalPhysicalPixelSpacing")) {
/* 1031 */             spaceY = getDoubleAttribute(child, "value");
/* 1032 */             gotSpaceY = true;
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1039 */           child = child.getNextSibling();
/*      */         } 
/*      */ 
/*      */         
/* 1043 */         if (!gotWidth && !gotHeight && (gotSpaceX || gotSpaceY)) {
/* 1044 */           width = spaceX;
/* 1045 */           gotWidth = gotSpaceX;
/* 1046 */           height = spaceY;
/* 1047 */           gotHeight = gotSpaceY;
/*      */         } 
/*      */ 
/*      */         
/* 1051 */         if (gotWidth && gotHeight) {
/* 1052 */           this.xPixelsPerMeter = (int)(1000.0D / width + 0.5D);
/* 1053 */           this.yPixelsPerMeter = (int)(1000.0D / height + 0.5D);
/* 1054 */         } else if (gotAspectRatio && aspectRatio != 0.0D) {
/* 1055 */           if (gotWidth) {
/* 1056 */             this.xPixelsPerMeter = (int)(1000.0D / width + 0.5D);
/* 1057 */             this.yPixelsPerMeter = (int)(aspectRatio * 1000.0D / width + 0.5D);
/*      */           }
/* 1059 */           else if (gotHeight) {
/* 1060 */             this.xPixelsPerMeter = (int)(1000.0D / height / aspectRatio + 0.5D);
/*      */             
/* 1062 */             this.yPixelsPerMeter = (int)(1000.0D / height + 0.5D);
/*      */           } 
/*      */         } 
/* 1065 */       } else if (name.equals("Document")) {
/* 1066 */         Node child = node.getFirstChild();
/* 1067 */         while (child != null) {
/* 1068 */           String childName = child.getNodeName();
/* 1069 */           if (childName.equals("FormatVersion")) {
/* 1070 */             this.bmpVersion = getAttribute(child, "value");
/*      */             break;
/*      */           } 
/* 1073 */           child = child.getNextSibling();
/*      */         } 
/* 1075 */       } else if (name.equals("Text")) {
/* 1076 */         Node child = node.getFirstChild();
/* 1077 */         while (child != null) {
/* 1078 */           String childName = child.getNodeName();
/* 1079 */           if (childName.equals("TextEntry")) {
/* 1080 */             if (this.comments == null) {
/* 1081 */               this.comments = new ArrayList();
/*      */             }
/* 1083 */             this.comments.add(getAttribute(child, "value"));
/*      */           } 
/* 1085 */           child = child.getNextSibling();
/*      */         } 
/* 1087 */       } else if (name.equals("Transparency")) {
/* 1088 */         Node child = node.getFirstChild();
/* 1089 */         while (child != null) {
/* 1090 */           String childName = child.getNodeName();
/* 1091 */           if (childName.equals("Alpha")) {
/* 1092 */             hasAlpha = !getAttribute(child, "value").equals("none");
/*      */             
/*      */             break;
/*      */           } 
/* 1096 */           child = child.getNextSibling();
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1102 */       node = node.getNextSibling();
/*      */     } 
/*      */ 
/*      */     
/* 1106 */     if (bitsPerSample != null) {
/* 1107 */       if (this.palette != null && this.paletteSize > 0) {
/* 1108 */         this.bitsPerPixel = (short)bitsPerSample[0];
/*      */       } else {
/* 1110 */         this.bitsPerPixel = 0;
/* 1111 */         for (int i = 0; i < bitsPerSample.length; i++) {
/* 1112 */           this.bitsPerPixel = (short)(this.bitsPerPixel + bitsPerSample[i]);
/*      */         }
/*      */       } 
/* 1115 */     } else if (this.palette != null) {
/* 1116 */       this.bitsPerPixel = 8;
/* 1117 */     } else if (numChannels == 1) {
/* 1118 */       this.bitsPerPixel = 8;
/* 1119 */     } else if (numChannels == 3) {
/* 1120 */       this.bitsPerPixel = 24;
/* 1121 */     } else if (numChannels == 4) {
/* 1122 */       this.bitsPerPixel = 32;
/* 1123 */     } else if (colorSpaceType.equals("GRAY")) {
/* 1124 */       this.bitsPerPixel = 8;
/* 1125 */     } else if (colorSpaceType.equals("RGB")) {
/* 1126 */       this.bitsPerPixel = (short)(hasAlpha ? 32 : 24);
/*      */     } 
/*      */ 
/*      */     
/* 1130 */     if ((bitsPerSample != null && bitsPerSample.length == 4) || this.bitsPerPixel >= 24) {
/*      */       
/* 1132 */       this.redMask = 16711680;
/* 1133 */       this.greenMask = 65280;
/* 1134 */       this.blueMask = 255;
/*      */     } 
/*      */ 
/*      */     
/* 1138 */     if ((bitsPerSample != null && bitsPerSample.length == 4) || this.bitsPerPixel > 24)
/*      */     {
/* 1140 */       this.alphaMask = -16777216;
/*      */     }
/*      */ 
/*      */     
/* 1144 */     if (r != null && g != null && b != null) {
/* 1145 */       boolean isVersion2 = (this.bmpVersion != null && this.bmpVersion.equals("BMP v. 2.x"));
/*      */ 
/*      */       
/* 1148 */       this.paletteSize = maxIndex + 1;
/* 1149 */       this.palette = new byte[(isVersion2 ? 3 : 4) * this.paletteSize];
/* 1150 */       for (int i = 0, j = 0; i < this.paletteSize; i++) {
/* 1151 */         this.palette[j++] = b[i];
/* 1152 */         this.palette[j++] = g[i];
/* 1153 */         this.palette[j++] = r[i];
/* 1154 */         if (!isVersion2) j++;
/*      */       
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   public void reset() {
/* 1161 */     this.bmpVersion = null;
/* 1162 */     this.width = 0;
/* 1163 */     this.height = 0;
/* 1164 */     this.bitsPerPixel = 0;
/* 1165 */     this.compression = 0;
/* 1166 */     this.imageSize = 0;
/*      */ 
/*      */     
/* 1169 */     this.xPixelsPerMeter = 0;
/* 1170 */     this.yPixelsPerMeter = 0;
/*      */     
/* 1172 */     this.colorsUsed = 0;
/* 1173 */     this.colorsImportant = 0;
/*      */ 
/*      */     
/* 1176 */     this.redMask = 0;
/* 1177 */     this.greenMask = 0;
/* 1178 */     this.blueMask = 0;
/* 1179 */     this.alphaMask = 0;
/*      */     
/* 1181 */     this.colorSpace = 0;
/*      */ 
/*      */     
/* 1184 */     this.redX = 0.0D;
/* 1185 */     this.redY = 0.0D;
/* 1186 */     this.redZ = 0.0D;
/* 1187 */     this.greenX = 0.0D;
/* 1188 */     this.greenY = 0.0D;
/* 1189 */     this.greenZ = 0.0D;
/* 1190 */     this.blueX = 0.0D;
/* 1191 */     this.blueY = 0.0D;
/* 1192 */     this.blueZ = 0.0D;
/*      */ 
/*      */     
/* 1195 */     this.gammaRed = 0;
/* 1196 */     this.gammaGreen = 0;
/* 1197 */     this.gammaBlue = 0;
/*      */     
/* 1199 */     this.intent = 0;
/*      */ 
/*      */     
/* 1202 */     this.palette = null;
/* 1203 */     this.paletteSize = 0;
/* 1204 */     this.red = 0;
/* 1205 */     this.green = 0;
/* 1206 */     this.blue = 0;
/*      */ 
/*      */     
/* 1209 */     this.comments = null;
/*      */   }
/*      */   
/*      */   private String countBits(int num) {
/* 1213 */     int count = 0;
/* 1214 */     while (num != 0) {
/* 1215 */       if ((num & 0x1) == 1)
/* 1216 */         count++; 
/* 1217 */       num >>>= 1;
/*      */     } 
/*      */     
/* 1220 */     return (count == 0) ? "0" : ("" + count);
/*      */   }
/*      */   
/*      */   private void addXYZPoints(IIOMetadataNode root, String name, double x, double y, double z) {
/* 1224 */     IIOMetadataNode node = addChildNode(root, name, (Object)null);
/* 1225 */     addChildNode(node, "X", new Double(x));
/* 1226 */     addChildNode(node, "Y", new Double(y));
/* 1227 */     addChildNode(node, "Z", new Double(z));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private IIOMetadataNode addChildNode(IIOMetadataNode root, String name, Object object) {
/* 1233 */     IIOMetadataNode child = new IIOMetadataNode(name);
/* 1234 */     if (object != null) {
/* 1235 */       child.setUserObject(object);
/* 1236 */       child.setNodeValue(ImageUtil.convertObjectToString(object));
/*      */     } 
/* 1238 */     root.appendChild(child);
/* 1239 */     return child;
/*      */   }
/*      */   
/*      */   private Object getObjectValue(Node node) {
/* 1243 */     Object tmp = node.getNodeValue();
/*      */     
/* 1245 */     if (tmp == null && node instanceof IIOMetadataNode) {
/* 1246 */       tmp = ((IIOMetadataNode)node).getUserObject();
/*      */     }
/*      */     
/* 1249 */     return tmp;
/*      */   }
/*      */   
/*      */   private String getStringValue(Node node) {
/* 1253 */     Object tmp = getObjectValue(node);
/* 1254 */     return (tmp instanceof String) ? (String)tmp : null;
/*      */   }
/*      */   
/*      */   private Byte getByteValue(Node node) {
/* 1258 */     Object tmp = getObjectValue(node);
/* 1259 */     Byte value = null;
/* 1260 */     if (tmp instanceof String) {
/* 1261 */       value = Byte.valueOf((String)tmp);
/* 1262 */     } else if (tmp instanceof Byte) {
/* 1263 */       value = (Byte)tmp;
/*      */     } 
/* 1265 */     return value;
/*      */   }
/*      */   
/*      */   private Short getShortValue(Node node) {
/* 1269 */     Object tmp = getObjectValue(node);
/* 1270 */     Short value = null;
/* 1271 */     if (tmp instanceof String) {
/* 1272 */       value = Short.valueOf((String)tmp);
/* 1273 */     } else if (tmp instanceof Short) {
/* 1274 */       value = (Short)tmp;
/*      */     } 
/* 1276 */     return value;
/*      */   }
/*      */   
/*      */   private Integer getIntegerValue(Node node) {
/* 1280 */     Object tmp = getObjectValue(node);
/* 1281 */     Integer value = null;
/* 1282 */     if (tmp instanceof String) {
/* 1283 */       value = Integer.valueOf((String)tmp);
/* 1284 */     } else if (tmp instanceof Integer) {
/* 1285 */       value = (Integer)tmp;
/* 1286 */     } else if (tmp instanceof Byte) {
/* 1287 */       value = new Integer(((Byte)tmp).byteValue() & 0xFF);
/*      */     } 
/* 1289 */     return value;
/*      */   }
/*      */   
/*      */   private Double getDoubleValue(Node node) {
/* 1293 */     Object tmp = getObjectValue(node);
/* 1294 */     Double value = null;
/* 1295 */     if (tmp instanceof String) {
/* 1296 */       value = Double.valueOf((String)tmp);
/* 1297 */     } else if (tmp instanceof Double) {
/* 1298 */       value = (Double)tmp;
/*      */     } 
/* 1300 */     return value;
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/bmp/BMPMetadata.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */