/*     */ package com.sun.media.imageioimpl.common;
/*     */ 
/*     */ import java.awt.color.ColorSpace;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SimpleCMYKColorSpace
/*     */   extends ColorSpace
/*     */ {
/*  90 */   private static ColorSpace theInstance = null;
/*     */   
/*     */   private ColorSpace csRGB;
/*     */   
/*     */   private static final double power1 = 0.4166666666666667D;
/*     */   
/*     */   public static final synchronized ColorSpace getInstance() {
/*  97 */     if (theInstance == null) {
/*  98 */       theInstance = new SimpleCMYKColorSpace();
/*     */     }
/* 100 */     return theInstance;
/*     */   }
/*     */   
/*     */   private SimpleCMYKColorSpace() {
/* 104 */     super(9, 4);
/* 105 */     this.csRGB = ColorSpace.getInstance(1004);
/*     */   }
/*     */   
/*     */   public boolean equals(Object o) {
/* 109 */     return (o != null && o instanceof SimpleCMYKColorSpace);
/*     */   }
/*     */   
/*     */   public float[] toRGB(float[] colorvalue) {
/* 113 */     float C = colorvalue[0];
/* 114 */     float M = colorvalue[1];
/* 115 */     float Y = colorvalue[2];
/* 116 */     float K = colorvalue[3];
/*     */     
/* 118 */     float K1 = 1.0F - K;
/*     */ 
/*     */     
/* 121 */     float[] rgbvalue = { K1 * (1.0F - C), K1 * (1.0F - M), K1 * (1.0F - Y) };
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 126 */     for (int i = 0; i < 3; i++) {
/* 127 */       float v = rgbvalue[i];
/*     */       
/* 129 */       if (v < 0.0F) v = 0.0F;
/*     */       
/* 131 */       if (v < 0.0031308F) {
/* 132 */         rgbvalue[i] = 12.92F * v;
/*     */       } else {
/* 134 */         if (v > 1.0F) v = 1.0F;
/*     */         
/* 136 */         rgbvalue[i] = (float)(1.055D * Math.pow(v, 0.4166666666666667D) - 0.055D);
/*     */       } 
/*     */     } 
/*     */     
/* 140 */     return rgbvalue;
/*     */   }
/*     */ 
/*     */   
/*     */   public float[] fromRGB(float[] rgbvalue) {
/* 145 */     for (int i = 0; i < 3; i++) {
/* 146 */       if (rgbvalue[i] < 0.040449936F) {
/* 147 */         rgbvalue[i] = rgbvalue[i] / 12.92F;
/*     */       } else {
/* 149 */         rgbvalue[i] = (float)Math.pow((rgbvalue[i] + 0.055D) / 1.055D, 2.4D);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 155 */     float C = 1.0F - rgbvalue[0];
/* 156 */     float M = 1.0F - rgbvalue[1];
/* 157 */     float Y = 1.0F - rgbvalue[2];
/* 158 */     float K = Math.min(C, Math.min(M, Y));
/*     */ 
/*     */     
/* 161 */     if (K != 1.0F) {
/* 162 */       float K1 = 1.0F - K;
/*     */       
/* 164 */       C = (C - K) / K1;
/* 165 */       M = (M - K) / K1;
/* 166 */       Y = (Y - K) / K1;
/*     */     } else {
/* 168 */       C = M = Y = 0.0F;
/*     */     } 
/*     */     
/* 171 */     return new float[] { C, M, Y, K };
/*     */   }
/*     */   
/*     */   public float[] toCIEXYZ(float[] colorvalue) {
/* 175 */     return this.csRGB.toCIEXYZ(toRGB(colorvalue));
/*     */   }
/*     */   
/*     */   public float[] fromCIEXYZ(float[] xyzvalue) {
/* 179 */     return fromRGB(this.csRGB.fromCIEXYZ(xyzvalue));
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/common/SimpleCMYKColorSpace.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */