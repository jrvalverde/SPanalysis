/*     */ package com.sun.media.imageioimpl.common;
/*     */ 
/*     */ import java.awt.image.ColorModel;
/*     */ import java.awt.image.Raster;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SingleTileRenderedImage
/*     */   extends SimpleRenderedImage
/*     */ {
/*     */   Raster ras;
/*     */   
/*     */   public SingleTileRenderedImage(Raster ras, ColorModel colorModel) {
/* 103 */     this.ras = ras;
/*     */     
/* 105 */     this.tileGridXOffset = this.minX = ras.getMinX();
/* 106 */     this.tileGridYOffset = this.minY = ras.getMinY();
/* 107 */     this.tileWidth = this.width = ras.getWidth();
/* 108 */     this.tileHeight = this.height = ras.getHeight();
/* 109 */     this.sampleModel = ras.getSampleModel();
/* 110 */     this.colorModel = colorModel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Raster getTile(int tileX, int tileY) {
/* 117 */     if (tileX != 0 || tileY != 0) {
/* 118 */       throw new IllegalArgumentException("tileX != 0 || tileY != 0");
/*     */     }
/* 120 */     return this.ras;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/common/SingleTileRenderedImage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */