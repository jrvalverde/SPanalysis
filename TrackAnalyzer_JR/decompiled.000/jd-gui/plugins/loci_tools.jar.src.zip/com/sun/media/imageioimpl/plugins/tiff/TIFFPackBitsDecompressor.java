/*     */ package com.sun.media.imageioimpl.plugins.tiff;
/*     */ 
/*     */ import com.sun.media.imageio.plugins.tiff.TIFFDecompressor;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TIFFPackBitsDecompressor
/*     */   extends TIFFDecompressor
/*     */ {
/*     */   private static final boolean DEBUG = false;
/*     */   
/*     */   public int decode(byte[] srcData, int srcOffset, byte[] dstData, int dstOffset) throws IOException {
/* 101 */     int srcIndex = srcOffset;
/* 102 */     int dstIndex = dstOffset;
/*     */     
/* 104 */     int dstArraySize = dstData.length;
/* 105 */     int srcArraySize = srcData.length;
/*     */     try {
/* 107 */       while (dstIndex < dstArraySize && srcIndex < srcArraySize) {
/* 108 */         byte b = srcData[srcIndex++];
/*     */         
/* 110 */         if (b >= 0 && b <= Byte.MAX_VALUE) {
/*     */ 
/*     */           
/* 113 */           for (int i = 0; i < b + 1; i++)
/* 114 */             dstData[dstIndex++] = srcData[srcIndex++];  continue;
/*     */         } 
/* 116 */         if (b <= -1 && b >= -127) {
/*     */           
/* 118 */           byte repeat = srcData[srcIndex++];
/* 119 */           for (int i = 0; i < -b + 1; i++) {
/* 120 */             dstData[dstIndex++] = repeat;
/*     */           }
/*     */           continue;
/*     */         } 
/* 124 */         srcIndex++;
/*     */       }
/*     */     
/* 127 */     } catch (ArrayIndexOutOfBoundsException e) {
/* 128 */       if (this.reader instanceof TIFFImageReader) {
/* 129 */         ((TIFFImageReader)this.reader).forwardWarningMessage("ArrayIndexOutOfBoundsException ignored in TIFFPackBitsDecompressor.decode()");
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 134 */     return dstIndex - dstOffset;
/*     */   }
/*     */ 
/*     */   
/*     */   public void decodeRaw(byte[] b, int dstOffset, int bitsPerPixel, int scanlineStride) throws IOException {
/*     */     byte[] buf;
/*     */     int bufOffset;
/* 141 */     this.stream.seek(this.offset);
/*     */     
/* 143 */     byte[] srcData = new byte[this.byteCount];
/* 144 */     this.stream.readFully(srcData);
/*     */     
/* 146 */     int bytesPerRow = (this.srcWidth * bitsPerPixel + 7) / 8;
/*     */ 
/*     */     
/* 149 */     if (bytesPerRow == scanlineStride) {
/* 150 */       buf = b;
/* 151 */       bufOffset = dstOffset;
/*     */     } else {
/* 153 */       buf = new byte[bytesPerRow * this.srcHeight];
/* 154 */       bufOffset = 0;
/*     */     } 
/*     */     
/* 157 */     decode(srcData, 0, buf, bufOffset);
/*     */     
/* 159 */     if (bytesPerRow != scanlineStride) {
/*     */ 
/*     */ 
/*     */       
/* 163 */       int off = 0;
/* 164 */       for (int y = 0; y < this.srcHeight; y++) {
/* 165 */         System.arraycopy(buf, off, b, dstOffset, bytesPerRow);
/* 166 */         off += bytesPerRow;
/* 167 */         dstOffset += scanlineStride;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/tiff/TIFFPackBitsDecompressor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */