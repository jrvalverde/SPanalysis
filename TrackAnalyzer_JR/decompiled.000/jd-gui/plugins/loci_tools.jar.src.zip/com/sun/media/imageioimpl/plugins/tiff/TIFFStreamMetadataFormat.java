/*     */ package com.sun.media.imageioimpl.plugins.tiff;
/*     */ 
/*     */ import javax.imageio.ImageTypeSpecifier;
/*     */ import javax.imageio.metadata.IIOMetadataFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TIFFStreamMetadataFormat
/*     */   extends TIFFMetadataFormat
/*     */ {
/*  98 */   private static TIFFStreamMetadataFormat theInstance = null;
/*     */ 
/*     */   
/*     */   public boolean canNodeAppear(String elementName, ImageTypeSpecifier imageType) {
/* 102 */     return false;
/*     */   }
/*     */   
/*     */   private TIFFStreamMetadataFormat() {
/* 106 */     this.resourceBaseName = "com.sun.media.imageioimpl.plugins.tiff.TIFFStreamMetadataFormatResources";
/*     */     
/* 108 */     this.rootName = "com_sun_media_imageio_plugins_tiff_stream_1.0";
/*     */ 
/*     */ 
/*     */     
/* 112 */     String[] empty = new String[0];
/*     */ 
/*     */ 
/*     */     
/* 116 */     String[] childNames = { "ByteOrder" };
/* 117 */     TIFFElementInfo einfo = new TIFFElementInfo(childNames, empty, 1);
/*     */     
/* 119 */     this.elementInfoMap.put("com_sun_media_imageio_plugins_tiff_stream_1.0", einfo);
/*     */ 
/*     */     
/* 122 */     childNames = empty;
/* 123 */     String[] attrNames = { "value" };
/* 124 */     einfo = new TIFFElementInfo(childNames, attrNames, 0);
/* 125 */     this.elementInfoMap.put("ByteOrder", einfo);
/*     */     
/* 127 */     TIFFAttrInfo ainfo = new TIFFAttrInfo();
/* 128 */     ainfo.dataType = 0;
/* 129 */     ainfo.isRequired = true;
/* 130 */     this.attrInfoMap.put("ByteOrder/value", ainfo);
/*     */   }
/*     */   
/*     */   public static synchronized IIOMetadataFormat getInstance() {
/* 134 */     if (theInstance == null) {
/* 135 */       theInstance = new TIFFStreamMetadataFormat();
/*     */     }
/* 137 */     return theInstance;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/tiff/TIFFStreamMetadataFormat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */