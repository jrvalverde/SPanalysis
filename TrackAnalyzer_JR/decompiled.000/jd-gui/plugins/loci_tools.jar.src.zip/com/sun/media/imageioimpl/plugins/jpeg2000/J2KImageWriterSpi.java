/*     */ package com.sun.media.imageioimpl.plugins.jpeg2000;
/*     */ 
/*     */ import com.sun.media.imageioimpl.common.PackageUtil;
/*     */ import java.awt.image.SampleModel;
/*     */ import java.util.Locale;
/*     */ import javax.imageio.IIOException;
/*     */ import javax.imageio.ImageTypeSpecifier;
/*     */ import javax.imageio.ImageWriter;
/*     */ import javax.imageio.spi.ImageWriterSpi;
/*     */ import javax.imageio.spi.ServiceRegistry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class J2KImageWriterSpi
/*     */   extends ImageWriterSpi
/*     */ {
/* 100 */   private static String[] readerSpiNames = new String[] { "com.sun.media.imageioimpl.plugins.jpeg2000.J2KImageReaderSpi" };
/*     */   
/* 102 */   private static String[] formatNames = new String[] { "jpeg 2000", "JPEG 2000", "jpeg2000", "JPEG2000" };
/*     */   
/* 104 */   private static String[] extensions = new String[] { "jp2" };
/*     */   
/* 106 */   private static String[] mimeTypes = new String[] { "image/jp2", "image/jpeg2000" };
/*     */   private boolean registered = false;
/*     */   
/*     */   public J2KImageWriterSpi() {
/* 110 */     super(PackageUtil.getVendor(), PackageUtil.getVersion(), formatNames, extensions, mimeTypes, "com.sun.media.imageioimpl.plugins.jpeg2000.J2KImageWriter", STANDARD_OUTPUT_TYPE, readerSpiNames, false, null, null, null, null, true, "com_sun_media_imageio_plugins_jpeg2000_image_1.0", "com.sun.media.imageioimpl.plugins.jpeg2000.J2KMetadataFormat", null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDescription(Locale locale) {
/* 128 */     String desc = PackageUtil.getSpecificationTitle() + " JPEG 2000 Image Writer";
/*     */     
/* 130 */     return desc;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onRegistration(ServiceRegistry registry, Class category) {
/* 135 */     if (this.registered) {
/*     */       return;
/*     */     }
/*     */     
/* 139 */     this.registered = true;
/*     */ 
/*     */     
/* 142 */     Class<?> codecLibWriterSPIClass = null;
/*     */     try {
/* 144 */       codecLibWriterSPIClass = Class.forName("com.sun.media.imageioimpl.plugins.jpeg2000.J2KImageWriterCodecLibSpi");
/*     */     }
/* 146 */     catch (Throwable t) {}
/*     */ 
/*     */ 
/*     */     
/* 150 */     if (codecLibWriterSPIClass != null) {
/* 151 */       Object codecLibWriterSPI = registry.getServiceProviderByClass(codecLibWriterSPIClass);
/*     */       
/* 153 */       if (codecLibWriterSPI != null) {
/* 154 */         registry.setOrdering(category, codecLibWriterSPI, this);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean canEncodeImage(ImageTypeSpecifier type) {
/* 160 */     SampleModel sm = type.getSampleModel();
/* 161 */     if (sm.getNumBands() > 16384)
/* 162 */       return false; 
/* 163 */     if (sm.getDataType() < 0 || sm.getDataType() > 3)
/*     */     {
/* 165 */       return false; } 
/* 166 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public ImageWriter createWriterInstance(Object extension) throws IIOException {
/* 171 */     return new J2KImageWriter(this);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/jpeg2000/J2KImageWriterSpi.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */