/*     */ package com.sun.media.imageio.stream;
/*     */ 
/*     */ import com.sun.media.imageioimpl.common.ImageUtil;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.color.ColorSpace;
/*     */ import java.awt.color.ICC_ColorSpace;
/*     */ import java.awt.color.ICC_Profile;
/*     */ import java.awt.image.ColorModel;
/*     */ import java.awt.image.ComponentColorModel;
/*     */ import java.awt.image.ComponentSampleModel;
/*     */ import java.awt.image.DirectColorModel;
/*     */ import java.awt.image.IndexColorModel;
/*     */ import java.awt.image.MultiPixelPackedSampleModel;
/*     */ import java.awt.image.SampleModel;
/*     */ import java.awt.image.SinglePixelPackedSampleModel;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.nio.ByteOrder;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.imageio.ImageTypeSpecifier;
/*     */ import javax.imageio.stream.IIOByteBuffer;
/*     */ import javax.imageio.stream.ImageInputStream;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RawImageInputStream
/*     */   implements ImageInputStream
/*     */ {
/* 129 */   private static final String[] preDefinedColorSpaces = new String[] { "GRAY", "sRGB", "LINEAR_RGB", "PYCC", "CIEXYZ" };
/*     */ 
/*     */   
/* 132 */   private static final int[] preDefinedTypes = new int[] { 1003, 1000, 1004, 1002, 1001 };
/*     */   private ImageInputStream source;
/*     */   private ImageTypeSpecifier type;
/*     */   private long[] imageOffsets;
/*     */   private Dimension[] imageDimensions;
/*     */   
/*     */   private static String getAttribute(Node node, String name) {
/* 139 */     NamedNodeMap map = node.getAttributes();
/* 140 */     node = map.getNamedItem(name);
/* 141 */     return (node != null) ? node.getNodeValue() : null;
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean getBoolean(Node node, String name) {
/* 146 */     String s = getAttribute(node, name);
/* 147 */     return (s == null) ? false : (new Boolean(s)).booleanValue();
/*     */   }
/*     */ 
/*     */   
/*     */   private static int getInt(Node node, String name) {
/* 152 */     String s = getAttribute(node, name);
/* 153 */     return (s == null) ? 0 : (new Integer(s)).intValue();
/*     */   }
/*     */ 
/*     */   
/*     */   private static byte[] getByteArray(Node node, String name) {
/* 158 */     String s = getAttribute(node, name);
/* 159 */     if (s == null)
/* 160 */       return null; 
/* 161 */     StringTokenizer token = new StringTokenizer(s);
/* 162 */     int count = token.countTokens();
/* 163 */     if (count == 0) {
/* 164 */       return null;
/*     */     }
/* 166 */     byte[] buf = new byte[count];
/* 167 */     int i = 0;
/* 168 */     while (token.hasMoreElements()) {
/* 169 */       buf[i++] = (new Byte(token.nextToken())).byteValue();
/*     */     }
/* 171 */     return buf;
/*     */   }
/*     */ 
/*     */   
/*     */   private static int[] getIntArray(Node node, String name) {
/* 176 */     String s = getAttribute(node, name);
/* 177 */     if (s == null) {
/* 178 */       return null;
/*     */     }
/* 180 */     StringTokenizer token = new StringTokenizer(s);
/* 181 */     int count = token.countTokens();
/* 182 */     if (count == 0) {
/* 183 */       return null;
/*     */     }
/* 185 */     int[] buf = new int[count];
/* 186 */     int i = 0;
/* 187 */     while (token.hasMoreElements()) {
/* 188 */       buf[i++] = (new Integer(token.nextToken())).intValue();
/*     */     }
/* 190 */     return buf;
/*     */   }
/*     */   
/*     */   private static int getTransparency(String s) {
/* 194 */     if ("BITMASK".equals(s))
/* 195 */       return 2; 
/* 196 */     if ("OPAQUE".equals(s))
/* 197 */       return 1; 
/* 198 */     if ("TRANSLUCENT".equals(s))
/* 199 */       return 3; 
/* 200 */     return 0;
/*     */   }
/*     */   
/*     */   private static ColorSpace getColorSpace(Node node) throws IOException {
/* 204 */     NodeList nodes = node.getChildNodes();
/* 205 */     for (int i = 0; i < nodes.getLength(); i++) {
/* 206 */       Node child = nodes.item(i);
/* 207 */       if ("colorSpace".equals(child.getNodeName())) {
/* 208 */         String s = child.getNodeValue();
/* 209 */         for (int j = 0; j < preDefinedColorSpaces.length; j++) {
/* 210 */           if (preDefinedColorSpaces[j].equals(s)) {
/* 211 */             return ColorSpace.getInstance(preDefinedTypes[j]);
/*     */           }
/*     */         } 
/* 214 */         InputStream stm = (new URL(s)).openStream();
/*     */         
/* 216 */         ColorSpace cp = new ICC_ColorSpace(ICC_Profile.getInstance(stm));
/* 217 */         stm.close();
/* 218 */         return cp;
/*     */       } 
/*     */     } 
/* 221 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RawImageInputStream(ImageInputStream source, ImageTypeSpecifier type, long[] imageOffsets, Dimension[] imageDimensions) {
/* 254 */     if (imageOffsets == null || imageDimensions == null || imageOffsets.length != imageDimensions.length)
/*     */     {
/* 256 */       throw new IllegalArgumentException(I18N.getString("RawImageInputStream0"));
/*     */     }
/*     */ 
/*     */     
/* 260 */     this.source = source;
/* 261 */     this.type = type;
/* 262 */     this.imageOffsets = imageOffsets;
/* 263 */     this.imageDimensions = imageDimensions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RawImageInputStream(ImageInputStream source, SampleModel sampleModel, long[] imageOffsets, Dimension[] imageDimensions) {
/* 319 */     if (imageOffsets == null || imageDimensions == null || imageOffsets.length != imageDimensions.length)
/*     */     {
/* 321 */       throw new IllegalArgumentException(I18N.getString("RawImageInputStream0"));
/*     */     }
/*     */ 
/*     */     
/* 325 */     this.source = source;
/* 326 */     ColorModel colorModel = ImageUtil.createColorModel(sampleModel);
/* 327 */     if (colorModel == null) {
/* 328 */       throw new IllegalArgumentException(I18N.getString("RawImageInputStream4"));
/*     */     }
/*     */     
/* 331 */     this.type = new ImageTypeSpecifier(colorModel, sampleModel);
/* 332 */     this.imageOffsets = imageOffsets;
/* 333 */     this.imageDimensions = imageDimensions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RawImageInputStream(ImageInputStream source, InputSource xmlSource) throws SAXException, IOException {
/* 533 */     this.source = source;
/*     */     
/* 535 */     DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
/* 536 */     dbf.setValidating(true);
/* 537 */     dbf.setNamespaceAware(true);
/* 538 */     dbf.setAttribute("http://java.sun.com/xml/jaxp/properties/schemaLanguage", "http://www.w3.org/2001/XMLSchema");
/*     */     
/* 540 */     DocumentBuilder db = null;
/*     */     try {
/* 542 */       db = dbf.newDocumentBuilder();
/* 543 */     } catch (ParserConfigurationException ex) {
/* 544 */       throw new RuntimeException(I18N.getString("RawImageInputStream1"), ex);
/*     */     } 
/*     */ 
/*     */     
/* 548 */     Document doc = db.parse(xmlSource);
/*     */ 
/*     */     
/* 551 */     NodeList nodes = doc.getElementsByTagName("byteOrder");
/* 552 */     String byteOrder = nodes.item(0).getNodeValue();
/* 553 */     if ("NETWORK".equals(byteOrder)) {
/* 554 */       setByteOrder(ByteOrder.BIG_ENDIAN);
/* 555 */       this.source.setByteOrder(ByteOrder.BIG_ENDIAN);
/* 556 */     } else if ("REVERSE".equals(byteOrder)) {
/* 557 */       setByteOrder(ByteOrder.LITTLE_ENDIAN);
/* 558 */       setByteOrder(ByteOrder.LITTLE_ENDIAN);
/*     */     } 
/*     */ 
/*     */     
/* 562 */     nodes = doc.getElementsByTagName("offset");
/* 563 */     int length = nodes.getLength();
/* 564 */     this.imageOffsets = new long[length];
/* 565 */     for (int i = 0; i < length; i++) {
/* 566 */       this.imageOffsets[i] = (new Long(nodes.item(i).getNodeValue())).longValue();
/*     */     }
/*     */ 
/*     */     
/* 570 */     nodes = doc.getElementsByTagName("width");
/* 571 */     NodeList nodes1 = doc.getElementsByTagName("height");
/* 572 */     length = nodes.getLength();
/* 573 */     if (length != nodes1.getLength()) {
/* 574 */       throw new IllegalArgumentException(I18N.getString("RawImageInputStream2"));
/*     */     }
/*     */     
/* 577 */     this.imageDimensions = new Dimension[length];
/* 578 */     for (int j = 0; j < length; j++) {
/* 579 */       String w = nodes.item(j).getNodeValue();
/* 580 */       String h = nodes1.item(j).getNodeValue();
/*     */       
/* 582 */       this.imageDimensions[j] = new Dimension((new Integer(w)).intValue(), (new Integer(h)).intValue());
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 588 */     SampleModel sampleModel = null;
/*     */ 
/*     */     
/* 591 */     nodes = doc.getElementsByTagName("ComponentSampleModel");
/* 592 */     if (nodes.getLength() > 0) {
/* 593 */       Node node = nodes.item(0);
/* 594 */       int[] bankIndices = getIntArray(node, "bankIndices");
/*     */       
/* 596 */       if (bankIndices == null) {
/* 597 */         sampleModel = new ComponentSampleModel(getInt(node, "dataType"), getInt(node, "w"), getInt(node, "h"), getInt(node, "pixelStride"), getInt(node, "scanlineStride"), getIntArray(node, "bandOffsets"));
/*     */ 
/*     */       
/*     */       }
/*     */       else {
/*     */ 
/*     */ 
/*     */         
/* 605 */         sampleModel = new ComponentSampleModel(getInt(node, "dataType"), getInt(node, "w"), getInt(node, "h"), getInt(node, "pixelStride"), getInt(node, "scanlineStride"), bankIndices, getIntArray(node, "bandOffsets"));
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 616 */     nodes = doc.getElementsByTagName("MultiPixelPackedSampleModel");
/* 617 */     if (nodes.getLength() > 0) {
/* 618 */       Node node = nodes.item(0);
/* 619 */       sampleModel = new MultiPixelPackedSampleModel(getInt(node, "dataType"), getInt(node, "w"), getInt(node, "h"), getInt(node, "numberOfBits"), getInt(node, "scanlineStride"), getInt(node, "dataBitOffset"));
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 629 */     nodes = doc.getElementsByTagName("SinglePixelPackedSampleModel");
/* 630 */     if (nodes.getLength() > 0) {
/* 631 */       Node node = nodes.item(0);
/* 632 */       sampleModel = new SinglePixelPackedSampleModel(getInt(node, "dataType"), getInt(node, "w"), getInt(node, "h"), getInt(node, "scanlineStride"), getIntArray(node, "bitMasks"));
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 641 */     ColorModel colorModel = null;
/*     */ 
/*     */     
/* 644 */     nodes = doc.getElementsByTagName("ComponentColorModel");
/* 645 */     if (nodes.getLength() > 0) {
/* 646 */       Node node = nodes.item(0);
/* 647 */       colorModel = new ComponentColorModel(getColorSpace(node), getIntArray(node, "bits"), getBoolean(node, "hasAlpha"), getBoolean(node, "isAlphaPremultiplied"), getTransparency(getAttribute(node, "transparency")), getInt(node, "transferType"));
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 657 */     nodes = doc.getElementsByTagName("DirectColorModel");
/* 658 */     if (nodes.getLength() > 0) {
/* 659 */       Node node = nodes.item(0);
/* 660 */       colorModel = new DirectColorModel(getColorSpace(node), getInt(node, "bits"), getInt(node, "rmask"), getInt(node, "gmask"), getInt(node, "bmask"), getInt(node, "amask"), false, 1);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 672 */     nodes = doc.getElementsByTagName("IndexColorModel");
/* 673 */     if (nodes.getLength() > 0) {
/* 674 */       Node node = nodes.item(0);
/* 675 */       byte[] alpha = getByteArray(node, "a");
/*     */       
/* 677 */       if (alpha == null) {
/* 678 */         colorModel = new IndexColorModel(getInt(node, "bits"), getInt(node, "size"), getByteArray(node, "r"), getByteArray(node, "g"), getByteArray(node, "b"));
/*     */ 
/*     */       
/*     */       }
/*     */       else {
/*     */ 
/*     */         
/* 685 */         colorModel = new IndexColorModel(getInt(node, "bits"), getInt(node, "size"), getByteArray(node, "r"), getByteArray(node, "g"), getByteArray(node, "b"), alpha);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 695 */     this.type = new ImageTypeSpecifier(colorModel, sampleModel);
/*     */ 
/*     */     
/* 698 */     if (this.imageDimensions.length == 0) {
/* 699 */       this.imageDimensions = new Dimension[this.imageOffsets.length];
/*     */       
/* 701 */       this.imageDimensions[0] = new Dimension(sampleModel.getWidth(), sampleModel.getHeight());
/*     */       
/* 703 */       for (int k = 1; k < this.imageDimensions.length; k++) {
/* 704 */         this.imageDimensions[k] = this.imageDimensions[0];
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageTypeSpecifier getImageType() {
/* 714 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getImageOffset(int imageIndex) {
/* 726 */     if (imageIndex < 0 || imageIndex >= this.imageOffsets.length) {
/* 727 */       throw new IllegalArgumentException(I18N.getString("RawImageInputStream3"));
/*     */     }
/* 729 */     return this.imageOffsets[imageIndex];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Dimension getImageDimension(int imageIndex) {
/* 739 */     if (imageIndex < 0 || imageIndex >= this.imageOffsets.length) {
/* 740 */       throw new IllegalArgumentException(I18N.getString("RawImageInputStream3"));
/*     */     }
/* 742 */     return this.imageDimensions[imageIndex];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNumImages() {
/* 750 */     return this.imageOffsets.length;
/*     */   }
/*     */   
/*     */   public void setByteOrder(ByteOrder byteOrder) {
/* 754 */     this.source.setByteOrder(byteOrder);
/*     */   }
/*     */   
/*     */   public ByteOrder getByteOrder() {
/* 758 */     return this.source.getByteOrder();
/*     */   }
/*     */   
/*     */   public int read() throws IOException {
/* 762 */     return this.source.read();
/*     */   }
/*     */   
/*     */   public int read(byte[] b) throws IOException {
/* 766 */     return this.source.read(b);
/*     */   }
/*     */   
/*     */   public int read(byte[] b, int off, int len) throws IOException {
/* 770 */     return this.source.read(b, off, len);
/*     */   }
/*     */   
/*     */   public void readBytes(IIOByteBuffer buf, int len) throws IOException {
/* 774 */     this.source.readBytes(buf, len);
/*     */   }
/*     */   
/*     */   public boolean readBoolean() throws IOException {
/* 778 */     return this.source.readBoolean();
/*     */   }
/*     */   
/*     */   public byte readByte() throws IOException {
/* 782 */     return this.source.readByte();
/*     */   }
/*     */   
/*     */   public int readUnsignedByte() throws IOException {
/* 786 */     return this.source.readUnsignedByte();
/*     */   }
/*     */   
/*     */   public short readShort() throws IOException {
/* 790 */     return this.source.readShort();
/*     */   }
/*     */   
/*     */   public int readUnsignedShort() throws IOException {
/* 794 */     return this.source.readUnsignedShort();
/*     */   }
/*     */   
/*     */   public char readChar() throws IOException {
/* 798 */     return this.source.readChar();
/*     */   }
/*     */   
/*     */   public int readInt() throws IOException {
/* 802 */     return this.source.readInt();
/*     */   }
/*     */   
/*     */   public long readUnsignedInt() throws IOException {
/* 806 */     return this.source.readUnsignedInt();
/*     */   }
/*     */   
/*     */   public long readLong() throws IOException {
/* 810 */     return this.source.readLong();
/*     */   }
/*     */   
/*     */   public float readFloat() throws IOException {
/* 814 */     return this.source.readFloat();
/*     */   }
/*     */   
/*     */   public double readDouble() throws IOException {
/* 818 */     return this.source.readDouble();
/*     */   }
/*     */   
/*     */   public String readLine() throws IOException {
/* 822 */     return this.source.readLine();
/*     */   }
/*     */   
/*     */   public String readUTF() throws IOException {
/* 826 */     return this.source.readUTF();
/*     */   }
/*     */   
/*     */   public void readFully(byte[] b, int off, int len) throws IOException {
/* 830 */     this.source.readFully(b, off, len);
/*     */   }
/*     */   
/*     */   public void readFully(byte[] b) throws IOException {
/* 834 */     this.source.readFully(b);
/*     */   }
/*     */   
/*     */   public void readFully(short[] s, int off, int len) throws IOException {
/* 838 */     this.source.readFully(s, off, len);
/*     */   }
/*     */   
/*     */   public void readFully(char[] c, int off, int len) throws IOException {
/* 842 */     this.source.readFully(c, off, len);
/*     */   }
/*     */   
/*     */   public void readFully(int[] i, int off, int len) throws IOException {
/* 846 */     this.source.readFully(i, off, len);
/*     */   }
/*     */   
/*     */   public void readFully(long[] l, int off, int len) throws IOException {
/* 850 */     this.source.readFully(l, off, len);
/*     */   }
/*     */   
/*     */   public void readFully(float[] f, int off, int len) throws IOException {
/* 854 */     this.source.readFully(f, off, len);
/*     */   }
/*     */   
/*     */   public void readFully(double[] d, int off, int len) throws IOException {
/* 858 */     this.source.readFully(d, off, len);
/*     */   }
/*     */   
/*     */   public long getStreamPosition() throws IOException {
/* 862 */     return this.source.getStreamPosition();
/*     */   }
/*     */   
/*     */   public int getBitOffset() throws IOException {
/* 866 */     return this.source.getBitOffset();
/*     */   }
/*     */   
/*     */   public void setBitOffset(int bitOffset) throws IOException {
/* 870 */     this.source.setBitOffset(bitOffset);
/*     */   }
/*     */   
/*     */   public int readBit() throws IOException {
/* 874 */     return this.source.readBit();
/*     */   }
/*     */   
/*     */   public long readBits(int numBits) throws IOException {
/* 878 */     return this.source.readBits(numBits);
/*     */   }
/*     */   
/*     */   public long length() throws IOException {
/* 882 */     return this.source.length();
/*     */   }
/*     */   
/*     */   public int skipBytes(int n) throws IOException {
/* 886 */     return this.source.skipBytes(n);
/*     */   }
/*     */   
/*     */   public long skipBytes(long n) throws IOException {
/* 890 */     return this.source.skipBytes(n);
/*     */   }
/*     */   
/*     */   public void seek(long pos) throws IOException {
/* 894 */     this.source.seek(pos);
/*     */   }
/*     */   
/*     */   public void mark() {
/* 898 */     this.source.mark();
/*     */   }
/*     */   
/*     */   public void reset() throws IOException {
/* 902 */     this.source.reset();
/*     */   }
/*     */   
/*     */   public void flushBefore(long pos) throws IOException {
/* 906 */     this.source.flushBefore(pos);
/*     */   }
/*     */   
/*     */   public void flush() throws IOException {
/* 910 */     this.source.flush();
/*     */   }
/*     */   
/*     */   public long getFlushedPosition() {
/* 914 */     return this.source.getFlushedPosition();
/*     */   }
/*     */   
/*     */   public boolean isCached() {
/* 918 */     return this.source.isCached();
/*     */   }
/*     */   
/*     */   public boolean isCachedMemory() {
/* 922 */     return this.source.isCachedMemory();
/*     */   }
/*     */   
/*     */   public boolean isCachedFile() {
/* 926 */     return this.source.isCachedFile();
/*     */   }
/*     */   
/*     */   public void close() throws IOException {
/* 930 */     this.source.close();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageio/stream/RawImageInputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */