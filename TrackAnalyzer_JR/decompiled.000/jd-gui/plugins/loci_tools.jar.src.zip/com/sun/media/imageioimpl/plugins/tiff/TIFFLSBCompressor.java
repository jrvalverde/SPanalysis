/*     */ package com.sun.media.imageioimpl.plugins.tiff;
/*     */ 
/*     */ import com.sun.media.imageio.plugins.tiff.TIFFCompressor;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TIFFLSBCompressor
/*     */   extends TIFFCompressor
/*     */ {
/*     */   public TIFFLSBCompressor() {
/*  93 */     super("", 1, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int encode(byte[] b, int off, int width, int height, int[] bitsPerSample, int scanlineStride) throws IOException {
/* 100 */     int bitsPerPixel = 0;
/* 101 */     for (int i = 0; i < bitsPerSample.length; i++) {
/* 102 */       bitsPerPixel += bitsPerSample[i];
/*     */     }
/* 104 */     int bytesPerRow = (bitsPerPixel * width + 7) / 8;
/* 105 */     byte[] compData = new byte[bytesPerRow];
/* 106 */     byte[] flipTable = TIFFFaxDecompressor.flipTable;
/* 107 */     for (int row = 0; row < height; row++) {
/* 108 */       System.arraycopy(b, off, compData, 0, bytesPerRow);
/* 109 */       for (int j = 0; j < bytesPerRow; j++) {
/* 110 */         compData[j] = flipTable[compData[j] & 0xFF];
/*     */       }
/* 112 */       this.stream.write(compData, 0, bytesPerRow);
/* 113 */       off += scanlineStride;
/*     */     } 
/* 115 */     return height * bytesPerRow;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/tiff/TIFFLSBCompressor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */