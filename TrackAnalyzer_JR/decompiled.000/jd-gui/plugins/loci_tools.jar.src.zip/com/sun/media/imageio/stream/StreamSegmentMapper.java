package com.sun.media.imageio.stream;

public interface StreamSegmentMapper {
  StreamSegment getStreamSegment(long paramLong, int paramInt);
  
  void getStreamSegment(long paramLong, int paramInt, StreamSegment paramStreamSegment);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageio/stream/StreamSegmentMapper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */