/*     */ package com.sun.media.imageioimpl.plugins.tiff;
/*     */ 
/*     */ import com.sun.media.imageio.plugins.tiff.BaselineTIFFTagSet;
/*     */ import com.sun.media.imageio.plugins.tiff.TIFFField;
/*     */ import java.io.IOException;
/*     */ import javax.imageio.IIOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TIFFT6Compressor
/*     */   extends TIFFFaxCompressor
/*     */ {
/*     */   public TIFFT6Compressor() {
/*  96 */     super("CCITT T.6", 4, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized int encodeT6(byte[] data, int lineStride, int colOffset, int width, int height, byte[] compData) {
/* 124 */     byte[] refData = null;
/* 125 */     int refAddr = 0;
/* 126 */     int lineAddr = 0;
/* 127 */     int outIndex = 0;
/*     */     
/* 129 */     initBitBuf();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 134 */     while (height-- != 0) {
/* 135 */       int a0 = colOffset;
/* 136 */       int last = a0 + width;
/*     */       
/* 138 */       int testbit = (data[lineAddr + (a0 >>> 3)] & 0xFF) >>> 7 - (a0 & 0x7) & 0x1;
/*     */ 
/*     */       
/* 141 */       int a1 = (testbit != 0) ? a0 : nextState(data, lineAddr, a0, last);
/*     */ 
/*     */       
/* 144 */       testbit = (refData == null) ? 0 : ((refData[refAddr + (a0 >>> 3)] & 0xFF) >>> 7 - (a0 & 0x7) & 0x1);
/*     */ 
/*     */       
/* 147 */       int b1 = (testbit != 0) ? a0 : nextState(refData, refAddr, a0, last);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 153 */       int color = 0;
/*     */       
/*     */       while (true) {
/* 156 */         int b2 = nextState(refData, refAddr, b1, last);
/* 157 */         if (b2 < a1) {
/* 158 */           outIndex += add2DBits(compData, outIndex, pass, 0);
/* 159 */           a0 = b2;
/*     */         } else {
/* 161 */           int tmp = b1 - a1 + 3;
/* 162 */           if (tmp <= 6 && tmp >= 0) {
/* 163 */             outIndex += add2DBits(compData, outIndex, vert, tmp);
/* 164 */             a0 = a1;
/*     */           } else {
/* 166 */             int a2 = nextState(data, lineAddr, a1, last);
/* 167 */             outIndex += add2DBits(compData, outIndex, horz, 0);
/* 168 */             outIndex += add1DBits(compData, outIndex, a1 - a0, color);
/* 169 */             outIndex += add1DBits(compData, outIndex, a2 - a1, color ^ 0x1);
/* 170 */             a0 = a2;
/*     */           } 
/*     */         } 
/* 173 */         if (a0 >= last) {
/*     */           break;
/*     */         }
/* 176 */         color = (data[lineAddr + (a0 >>> 3)] & 0xFF) >>> 7 - (a0 & 0x7) & 0x1;
/*     */         
/* 178 */         a1 = nextState(data, lineAddr, a0, last);
/* 179 */         b1 = nextState(refData, refAddr, a0, last);
/* 180 */         testbit = (refData == null) ? 0 : ((refData[refAddr + (b1 >>> 3)] & 0xFF) >>> 7 - (b1 & 0x7) & 0x1);
/*     */ 
/*     */         
/* 183 */         if (testbit == color) {
/* 184 */           b1 = nextState(refData, refAddr, b1, last);
/*     */         }
/*     */       } 
/*     */       
/* 188 */       refData = data;
/* 189 */       refAddr = lineAddr;
/* 190 */       lineAddr += lineStride;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 197 */     outIndex += addEOFB(compData, outIndex);
/*     */ 
/*     */     
/* 200 */     if (this.inverseFill) {
/* 201 */       for (int i = 0; i < outIndex; i++) {
/* 202 */         compData[i] = TIFFFaxDecompressor.flipTable[compData[i] & 0xFF];
/*     */       }
/*     */     }
/*     */     
/* 206 */     return outIndex;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int encode(byte[] b, int off, int width, int height, int[] bitsPerSample, int scanlineStride) throws IOException {
/* 213 */     if (bitsPerSample.length != 1 || bitsPerSample[0] != 1) {
/* 214 */       throw new IIOException("Bits per sample must be 1 for T6 compression!");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 219 */     if (this.metadata instanceof TIFFImageMetadata) {
/* 220 */       TIFFImageMetadata tim = (TIFFImageMetadata)this.metadata;
/*     */       
/* 222 */       long[] options = new long[1];
/* 223 */       options[0] = 0L;
/*     */       
/* 225 */       BaselineTIFFTagSet base = BaselineTIFFTagSet.getInstance();
/* 226 */       TIFFField T6Options = new TIFFField(base.getTag(293), 4, 1, options);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 231 */       tim.rootIFD.addTIFFField(T6Options);
/*     */     } 
/*     */ 
/*     */     
/* 235 */     int maxBits = 9 * (width + 1) / 2 + 2;
/* 236 */     int bufSize = (maxBits + 7) / 8;
/* 237 */     bufSize = height * (bufSize + 2) + 12;
/*     */     
/* 239 */     byte[] compData = new byte[bufSize];
/* 240 */     int bytes = encodeT6(b, scanlineStride, 8 * off, width, height, compData);
/*     */     
/* 242 */     this.stream.write(compData, 0, bytes);
/* 243 */     return bytes;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/tiff/TIFFT6Compressor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */