/*     */ package com.sun.media.imageio.plugins.tiff;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.SortedMap;
/*     */ import java.util.SortedSet;
/*     */ import java.util.TreeMap;
/*     */ import java.util.TreeSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TIFFTagSet
/*     */ {
/* 109 */   private SortedMap allowedTagsByNumber = new TreeMap<Object, Object>();
/*     */   
/* 111 */   private SortedMap allowedTagsByName = new TreeMap<Object, Object>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private TIFFTagSet() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TIFFTagSet(List tags) {
/* 130 */     if (tags == null) {
/* 131 */       throw new IllegalArgumentException("tags == null!");
/*     */     }
/* 133 */     Iterator iter = tags.iterator();
/* 134 */     while (iter.hasNext()) {
/* 135 */       Object o = iter.next();
/* 136 */       if (!(o instanceof TIFFTag)) {
/* 137 */         throw new IllegalArgumentException("tags contains a non-TIFFTag!");
/*     */       }
/*     */       
/* 140 */       TIFFTag tag = (TIFFTag)o;
/*     */       
/* 142 */       this.allowedTagsByNumber.put(new Integer(tag.getNumber()), tag);
/* 143 */       this.allowedTagsByName.put(tag.getName(), tag);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TIFFTag getTag(int tagNumber) {
/* 157 */     return (TIFFTag)this.allowedTagsByNumber.get(new Integer(tagNumber));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TIFFTag getTag(String tagName) {
/* 173 */     if (tagName == null) {
/* 174 */       throw new IllegalArgumentException("tagName == null!");
/*     */     }
/* 176 */     return (TIFFTag)this.allowedTagsByName.get(tagName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SortedSet getTagNumbers() {
/*     */     SortedSet<?> sortedTagNumbers;
/* 190 */     Set<?> tagNumbers = this.allowedTagsByNumber.keySet();
/*     */     
/* 192 */     if (tagNumbers instanceof SortedSet) {
/* 193 */       sortedTagNumbers = (SortedSet)tagNumbers;
/*     */     } else {
/* 195 */       sortedTagNumbers = new TreeSet(tagNumbers);
/*     */     } 
/*     */     
/* 198 */     return Collections.unmodifiableSortedSet(sortedTagNumbers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SortedSet getTagNames() {
/*     */     SortedSet<?> sortedTagNames;
/* 212 */     Set<?> tagNames = this.allowedTagsByName.keySet();
/*     */     
/* 214 */     if (tagNames instanceof SortedSet) {
/* 215 */       sortedTagNames = (SortedSet)tagNames;
/*     */     } else {
/* 217 */       sortedTagNames = new TreeSet(tagNames);
/*     */     } 
/*     */     
/* 220 */     return Collections.unmodifiableSortedSet(sortedTagNames);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageio/plugins/tiff/TIFFTagSet.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */