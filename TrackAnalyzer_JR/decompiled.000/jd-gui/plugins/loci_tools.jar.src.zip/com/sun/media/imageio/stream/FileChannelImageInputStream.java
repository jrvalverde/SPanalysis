/*     */ package com.sun.media.imageio.stream;
/*     */ 
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.ByteOrder;
/*     */ import java.nio.CharBuffer;
/*     */ import java.nio.DoubleBuffer;
/*     */ import java.nio.FloatBuffer;
/*     */ import java.nio.IntBuffer;
/*     */ import java.nio.LongBuffer;
/*     */ import java.nio.MappedByteBuffer;
/*     */ import java.nio.ShortBuffer;
/*     */ import java.nio.channels.FileChannel;
/*     */ import javax.imageio.stream.ImageInputStreamImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FileChannelImageInputStream
/*     */   extends ImageInputStreamImpl
/*     */ {
/*     */   private FileChannel channel;
/*     */   private MappedByteBuffer mappedBuffer;
/*     */   private long mappedPos;
/*     */   private long mappedUpperBound;
/*     */   
/*     */   public FileChannelImageInputStream(FileChannel channel) throws IOException {
/* 149 */     if (channel == null)
/* 150 */       throw new IllegalArgumentException("channel == null"); 
/* 151 */     if (!channel.isOpen()) {
/* 152 */       throw new IllegalArgumentException("channel.isOpen() == false");
/*     */     }
/*     */ 
/*     */     
/* 156 */     this.channel = channel;
/*     */ 
/*     */     
/* 159 */     long channelPosition = channel.position();
/*     */ 
/*     */     
/* 162 */     this.streamPos = this.flushedPos = channelPosition;
/*     */ 
/*     */     
/* 165 */     long fullSize = channel.size() - channelPosition;
/* 166 */     long mappedSize = Math.min(fullSize, 2147483647L);
/*     */ 
/*     */     
/* 169 */     this.mappedPos = 0L;
/* 170 */     this.mappedUpperBound = this.mappedPos + mappedSize;
/*     */ 
/*     */     
/* 173 */     this.mappedBuffer = channel.map(FileChannel.MapMode.READ_ONLY, channelPosition, mappedSize);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MappedByteBuffer getMappedBuffer(int len) throws IOException {
/* 189 */     if (this.streamPos < this.mappedPos || this.streamPos + len >= this.mappedUpperBound) {
/*     */ 
/*     */       
/* 192 */       this.mappedPos = this.streamPos;
/*     */ 
/*     */       
/* 195 */       long mappedSize = Math.min(this.channel.size() - this.mappedPos, 2147483647L);
/*     */ 
/*     */ 
/*     */       
/* 199 */       this.mappedUpperBound = this.mappedPos + mappedSize;
/*     */ 
/*     */       
/* 202 */       this.mappedBuffer = this.channel.map(FileChannel.MapMode.READ_ONLY, this.mappedPos, mappedSize);
/*     */ 
/*     */ 
/*     */       
/* 206 */       this.mappedBuffer.order(getByteOrder());
/*     */     } 
/*     */ 
/*     */     
/* 210 */     return this.mappedBuffer;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int read() throws IOException {
/* 216 */     checkClosed();
/* 217 */     this.bitOffset = 0;
/*     */ 
/*     */     
/* 220 */     ByteBuffer byteBuffer = getMappedBuffer(1);
/*     */ 
/*     */     
/* 223 */     if (byteBuffer.remaining() < 1)
/*     */     {
/* 225 */       return -1;
/*     */     }
/*     */ 
/*     */     
/* 229 */     int value = byteBuffer.get() & 0xFF;
/*     */ 
/*     */     
/* 232 */     this.streamPos++;
/*     */ 
/*     */ 
/*     */     
/* 236 */     return value;
/*     */   }
/*     */   
/*     */   public int read(byte[] b, int off, int len) throws IOException {
/* 240 */     if (off < 0 || len < 0 || off + len > b.length)
/*     */     {
/* 242 */       throw new IndexOutOfBoundsException("off < 0 || len < 0 || off + len > b.length");
/*     */     }
/* 244 */     if (len == 0) {
/* 245 */       return 0;
/*     */     }
/*     */     
/* 248 */     checkClosed();
/* 249 */     this.bitOffset = 0;
/*     */ 
/*     */     
/* 252 */     ByteBuffer byteBuffer = getMappedBuffer(len);
/*     */ 
/*     */     
/* 255 */     int numBytesRemaining = byteBuffer.remaining();
/*     */ 
/*     */     
/* 258 */     if (numBytesRemaining < 1)
/*     */     {
/* 260 */       return -1; } 
/* 261 */     if (len > numBytesRemaining)
/*     */     {
/*     */       
/* 264 */       len = numBytesRemaining;
/*     */     }
/*     */ 
/*     */     
/* 268 */     byteBuffer.get(b, off, len);
/*     */ 
/*     */     
/* 271 */     this.streamPos += len;
/*     */     
/* 273 */     return len;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 286 */     super.close();
/* 287 */     this.channel = null;
/*     */   }
/*     */   
/*     */   public void readFully(char[] c, int off, int len) throws IOException {
/* 291 */     if (off < 0 || len < 0 || off + len > c.length)
/*     */     {
/* 293 */       throw new IndexOutOfBoundsException("off < 0 || len < 0 || off + len > c.length");
/*     */     }
/* 295 */     if (len == 0) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 300 */     int byteLen = 2 * len;
/*     */ 
/*     */     
/* 303 */     ByteBuffer byteBuffer = getMappedBuffer(byteLen);
/*     */ 
/*     */     
/* 306 */     if (byteBuffer.remaining() < byteLen) {
/* 307 */       throw new EOFException();
/*     */     }
/*     */ 
/*     */     
/* 311 */     CharBuffer viewBuffer = byteBuffer.asCharBuffer();
/*     */ 
/*     */     
/* 314 */     viewBuffer.get(c, off, len);
/*     */ 
/*     */     
/* 317 */     seek(this.streamPos + byteLen);
/*     */   }
/*     */   
/*     */   public void readFully(short[] s, int off, int len) throws IOException {
/* 321 */     if (off < 0 || len < 0 || off + len > s.length)
/*     */     {
/* 323 */       throw new IndexOutOfBoundsException("off < 0 || len < 0 || off + len > s.length");
/*     */     }
/* 325 */     if (len == 0) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 330 */     int byteLen = 2 * len;
/*     */ 
/*     */     
/* 333 */     ByteBuffer byteBuffer = getMappedBuffer(byteLen);
/*     */ 
/*     */     
/* 336 */     if (byteBuffer.remaining() < byteLen) {
/* 337 */       throw new EOFException();
/*     */     }
/*     */ 
/*     */     
/* 341 */     ShortBuffer viewBuffer = byteBuffer.asShortBuffer();
/*     */ 
/*     */     
/* 344 */     viewBuffer.get(s, off, len);
/*     */ 
/*     */     
/* 347 */     seek(this.streamPos + byteLen);
/*     */   }
/*     */   
/*     */   public void readFully(int[] i, int off, int len) throws IOException {
/* 351 */     if (off < 0 || len < 0 || off + len > i.length)
/*     */     {
/* 353 */       throw new IndexOutOfBoundsException("off < 0 || len < 0 || off + len > i.length");
/*     */     }
/* 355 */     if (len == 0) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 360 */     int byteLen = 4 * len;
/*     */ 
/*     */     
/* 363 */     ByteBuffer byteBuffer = getMappedBuffer(byteLen);
/*     */ 
/*     */     
/* 366 */     if (byteBuffer.remaining() < byteLen) {
/* 367 */       throw new EOFException();
/*     */     }
/*     */ 
/*     */     
/* 371 */     IntBuffer viewBuffer = byteBuffer.asIntBuffer();
/*     */ 
/*     */     
/* 374 */     viewBuffer.get(i, off, len);
/*     */ 
/*     */     
/* 377 */     seek(this.streamPos + byteLen);
/*     */   }
/*     */   
/*     */   public void readFully(long[] l, int off, int len) throws IOException {
/* 381 */     if (off < 0 || len < 0 || off + len > l.length)
/*     */     {
/* 383 */       throw new IndexOutOfBoundsException("off < 0 || len < 0 || off + len > l.length");
/*     */     }
/* 385 */     if (len == 0) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 390 */     int byteLen = 8 * len;
/*     */ 
/*     */     
/* 393 */     ByteBuffer byteBuffer = getMappedBuffer(byteLen);
/*     */ 
/*     */     
/* 396 */     if (byteBuffer.remaining() < byteLen) {
/* 397 */       throw new EOFException();
/*     */     }
/*     */ 
/*     */     
/* 401 */     LongBuffer viewBuffer = byteBuffer.asLongBuffer();
/*     */ 
/*     */     
/* 404 */     viewBuffer.get(l, off, len);
/*     */ 
/*     */     
/* 407 */     seek(this.streamPos + byteLen);
/*     */   }
/*     */   
/*     */   public void readFully(float[] f, int off, int len) throws IOException {
/* 411 */     if (off < 0 || len < 0 || off + len > f.length)
/*     */     {
/* 413 */       throw new IndexOutOfBoundsException("off < 0 || len < 0 || off + len > f.length");
/*     */     }
/* 415 */     if (len == 0) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 420 */     int byteLen = 4 * len;
/*     */ 
/*     */     
/* 423 */     ByteBuffer byteBuffer = getMappedBuffer(byteLen);
/*     */ 
/*     */     
/* 426 */     if (byteBuffer.remaining() < byteLen) {
/* 427 */       throw new EOFException();
/*     */     }
/*     */ 
/*     */     
/* 431 */     FloatBuffer viewBuffer = byteBuffer.asFloatBuffer();
/*     */ 
/*     */     
/* 434 */     viewBuffer.get(f, off, len);
/*     */ 
/*     */     
/* 437 */     seek(this.streamPos + byteLen);
/*     */   }
/*     */   
/*     */   public void readFully(double[] d, int off, int len) throws IOException {
/* 441 */     if (off < 0 || len < 0 || off + len > d.length)
/*     */     {
/* 443 */       throw new IndexOutOfBoundsException("off < 0 || len < 0 || off + len > d.length");
/*     */     }
/* 445 */     if (len == 0) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 450 */     int byteLen = 8 * len;
/*     */ 
/*     */     
/* 453 */     ByteBuffer byteBuffer = getMappedBuffer(byteLen);
/*     */ 
/*     */     
/* 456 */     if (byteBuffer.remaining() < byteLen) {
/* 457 */       throw new EOFException();
/*     */     }
/*     */ 
/*     */     
/* 461 */     DoubleBuffer viewBuffer = byteBuffer.asDoubleBuffer();
/*     */ 
/*     */     
/* 464 */     viewBuffer.get(d, off, len);
/*     */ 
/*     */     
/* 467 */     seek(this.streamPos + byteLen);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long length() {
/* 480 */     long length = -1L;
/*     */ 
/*     */     
/*     */     try {
/* 484 */       length = this.channel.size();
/* 485 */     } catch (IOException e) {}
/*     */ 
/*     */ 
/*     */     
/* 489 */     return length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void seek(long pos) throws IOException {
/* 499 */     super.seek(pos);
/*     */     
/* 501 */     if (pos >= this.mappedPos && pos < this.mappedUpperBound) {
/*     */       
/* 503 */       this.mappedBuffer.position((int)(pos - this.mappedPos));
/*     */     }
/*     */     else {
/*     */       
/* 507 */       int len = (int)Math.min(this.channel.size() - pos, 2147483647L);
/* 508 */       this.mappedBuffer = getMappedBuffer(len);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setByteOrder(ByteOrder networkByteOrder) {
/* 513 */     super.setByteOrder(networkByteOrder);
/* 514 */     this.mappedBuffer.order(networkByteOrder);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageio/stream/FileChannelImageInputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */