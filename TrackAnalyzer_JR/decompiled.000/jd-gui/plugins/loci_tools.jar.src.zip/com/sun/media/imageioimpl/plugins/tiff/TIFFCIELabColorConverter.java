/*     */ package com.sun.media.imageioimpl.plugins.tiff;
/*     */ 
/*     */ import com.sun.media.imageio.plugins.tiff.TIFFColorConverter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TIFFCIELabColorConverter
/*     */   extends TIFFColorConverter
/*     */ {
/*     */   private static final float Xn = 95.047F;
/*     */   private static final float Yn = 100.0F;
/*     */   private static final float Zn = 108.883F;
/*  94 */   private static final float THRESHOLD = (float)Math.pow(0.008856D, 0.3333333333333333D);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private float clamp(float x) {
/* 100 */     if (x < 0.0F)
/* 101 */       return 0.0F; 
/* 102 */     if (x > 100.0F) {
/* 103 */       return 255.0F;
/*     */     }
/* 105 */     return x * 2.55F;
/*     */   }
/*     */ 
/*     */   
/*     */   private float clamp2(float x) {
/* 110 */     if (x < 0.0F)
/* 111 */       return 0.0F; 
/* 112 */     if (x > 255.0F) {
/* 113 */       return 255.0F;
/*     */     }
/* 115 */     return x;
/*     */   }
/*     */ 
/*     */   
/*     */   public void fromRGB(float r, float g, float b, float[] result) {
/* 120 */     float X = 0.412453F * r + 0.35758F * g + 0.180423F * b;
/* 121 */     float Y = 0.212671F * r + 0.71516F * g + 0.072169F * b;
/* 122 */     float Z = 0.019334F * r + 0.119193F * g + 0.950227F * b;
/*     */     
/* 124 */     float YYn = Y / 100.0F;
/* 125 */     float XXn = X / 95.047F;
/* 126 */     float ZZn = Z / 108.883F;
/*     */     
/* 128 */     if (YYn < 0.008856F) {
/* 129 */       YYn = 7.787F * YYn + 0.13793103F;
/*     */     } else {
/* 131 */       YYn = (float)Math.pow(YYn, 0.3333333333333333D);
/*     */     } 
/*     */     
/* 134 */     if (XXn < 0.008856F) {
/* 135 */       XXn = 7.787F * XXn + 0.13793103F;
/*     */     } else {
/* 137 */       XXn = (float)Math.pow(XXn, 0.3333333333333333D);
/*     */     } 
/*     */     
/* 140 */     if (ZZn < 0.008856F) {
/* 141 */       ZZn = 7.787F * ZZn + 0.13793103F;
/*     */     } else {
/* 143 */       ZZn = (float)Math.pow(ZZn, 0.3333333333333333D);
/*     */     } 
/*     */     
/* 146 */     float LStar = 116.0F * YYn - 16.0F;
/* 147 */     float aStar = 500.0F * (XXn - YYn);
/* 148 */     float bStar = 200.0F * (YYn - ZZn);
/*     */     
/* 150 */     LStar *= 2.55F;
/* 151 */     if (aStar < 0.0F) {
/* 152 */       aStar += 256.0F;
/*     */     }
/* 154 */     if (bStar < 0.0F) {
/* 155 */       bStar += 256.0F;
/*     */     }
/*     */     
/* 158 */     result[0] = clamp2(LStar);
/* 159 */     result[1] = clamp2(aStar);
/* 160 */     result[2] = clamp2(bStar);
/*     */   }
/*     */   
/*     */   public void toRGB(float x0, float x1, float x2, float[] rgb) {
/* 164 */     float YYn, fY, X, Z, LStar = x0 * 100.0F / 255.0F;
/* 165 */     float aStar = (x1 > 128.0F) ? (x1 - 256.0F) : x1;
/* 166 */     float bStar = (x2 > 128.0F) ? (x2 - 256.0F) : x2;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 171 */     if (LStar < 8.0F) {
/* 172 */       YYn = LStar / 903.3F;
/* 173 */       fY = 7.787F * YYn + 0.13793103F;
/*     */     } else {
/* 175 */       float YYn_cubeRoot = (LStar + 16.0F) / 116.0F;
/* 176 */       YYn = YYn_cubeRoot * YYn_cubeRoot * YYn_cubeRoot;
/* 177 */       fY = (float)Math.pow(YYn, 0.3333333333333333D);
/*     */     } 
/* 179 */     float Y = YYn * 100.0F;
/*     */     
/* 181 */     float fX = fY + aStar / 500.0F;
/*     */     
/* 183 */     if (fX <= THRESHOLD) {
/* 184 */       X = 95.047F * (fX - 0.13793103F) / 7.787F;
/*     */     } else {
/* 186 */       X = 95.047F * fX * fX * fX;
/*     */     } 
/*     */     
/* 189 */     float fZ = fY - bStar / 200.0F;
/*     */     
/* 191 */     if (fZ <= THRESHOLD) {
/* 192 */       Z = 108.883F * (fZ - 0.13793103F) / 7.787F;
/*     */     } else {
/* 194 */       Z = 108.883F * fZ * fZ * fZ;
/*     */     } 
/*     */     
/* 197 */     float R = 3.240479F * X - 1.53715F * Y - 0.498535F * Z;
/* 198 */     float G = -0.969256F * X + 1.875992F * Y + 0.041556F * Z;
/* 199 */     float B = 0.055648F * X - 0.204043F * Y + 1.057311F * Z;
/*     */     
/* 201 */     rgb[0] = clamp(R);
/* 202 */     rgb[1] = clamp(G);
/* 203 */     rgb[2] = clamp(B);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/tiff/TIFFCIELabColorConverter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */