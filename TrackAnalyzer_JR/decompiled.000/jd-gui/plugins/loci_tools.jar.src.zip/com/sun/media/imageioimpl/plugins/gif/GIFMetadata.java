/*     */ package com.sun.media.imageioimpl.plugins.gif;
/*     */ 
/*     */ import javax.imageio.metadata.IIOInvalidTreeException;
/*     */ import javax.imageio.metadata.IIOMetadata;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class GIFMetadata
/*     */   extends IIOMetadata
/*     */ {
/*     */   static final int UNDEFINED_INTEGER_VALUE = -1;
/*     */   
/*     */   protected static void fatal(Node node, String reason) throws IIOInvalidTreeException {
/* 108 */     throw new IIOInvalidTreeException(reason, node);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static String getStringAttribute(Node node, String name, String defaultValue, boolean required, String[] range) throws IIOInvalidTreeException {
/* 117 */     Node attr = node.getAttributes().getNamedItem(name);
/* 118 */     if (attr == null) {
/* 119 */       if (!required) {
/* 120 */         return defaultValue;
/*     */       }
/* 122 */       fatal(node, "Required attribute " + name + " not present!");
/*     */     } 
/*     */     
/* 125 */     String value = attr.getNodeValue();
/*     */     
/* 127 */     if (range != null) {
/* 128 */       if (value == null) {
/* 129 */         fatal(node, "Null value for " + node.getNodeName() + " attribute " + name + "!");
/*     */       }
/*     */ 
/*     */       
/* 133 */       boolean validValue = false;
/* 134 */       int len = range.length;
/* 135 */       for (int i = 0; i < len; i++) {
/* 136 */         if (value.equals(range[i])) {
/* 137 */           validValue = true;
/*     */           break;
/*     */         } 
/*     */       } 
/* 141 */       if (!validValue) {
/* 142 */         fatal(node, "Bad value for " + node.getNodeName() + " attribute " + name + "!");
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 148 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static int getIntAttribute(Node node, String name, int defaultValue, boolean required, boolean bounded, int min, int max) throws IIOInvalidTreeException {
/* 157 */     String value = getStringAttribute(node, name, null, required, null);
/* 158 */     if (value == null || "".equals(value)) {
/* 159 */       return defaultValue;
/*     */     }
/*     */     
/* 162 */     int intValue = defaultValue;
/*     */     try {
/* 164 */       intValue = Integer.parseInt(value);
/* 165 */     } catch (NumberFormatException e) {
/* 166 */       fatal(node, "Bad value for " + node.getNodeName() + " attribute " + name + "!");
/*     */     } 
/*     */ 
/*     */     
/* 170 */     if (bounded && (intValue < min || intValue > max)) {
/* 171 */       fatal(node, "Bad value for " + node.getNodeName() + " attribute " + name + "!");
/*     */     }
/*     */ 
/*     */     
/* 175 */     return intValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static float getFloatAttribute(Node node, String name, float defaultValue, boolean required) throws IIOInvalidTreeException {
/* 183 */     String value = getStringAttribute(node, name, null, required, null);
/* 184 */     if (value == null) {
/* 185 */       return defaultValue;
/*     */     }
/* 187 */     return Float.parseFloat(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static int getIntAttribute(Node node, String name, boolean bounded, int min, int max) throws IIOInvalidTreeException {
/* 194 */     return getIntAttribute(node, name, -1, true, bounded, min, max);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected static float getFloatAttribute(Node node, String name) throws IIOInvalidTreeException {
/* 200 */     return getFloatAttribute(node, name, -1.0F, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static boolean getBooleanAttribute(Node node, String name, boolean defaultValue, boolean required) throws IIOInvalidTreeException {
/* 208 */     Node attr = node.getAttributes().getNamedItem(name);
/* 209 */     if (attr == null) {
/* 210 */       if (!required) {
/* 211 */         return defaultValue;
/*     */       }
/* 213 */       fatal(node, "Required attribute " + name + " not present!");
/*     */     } 
/*     */     
/* 216 */     String value = attr.getNodeValue();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 221 */     if (value.equalsIgnoreCase("TRUE"))
/* 222 */       return true; 
/* 223 */     if (value.equalsIgnoreCase("FALSE")) {
/* 224 */       return false;
/*     */     }
/* 226 */     fatal(node, "Attribute " + name + " must be 'TRUE' or 'FALSE'!");
/* 227 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static boolean getBooleanAttribute(Node node, String name) throws IIOInvalidTreeException {
/* 234 */     return getBooleanAttribute(node, name, false, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static int getEnumeratedAttribute(Node node, String name, String[] legalNames, int defaultValue, boolean required) throws IIOInvalidTreeException {
/* 244 */     Node attr = node.getAttributes().getNamedItem(name);
/* 245 */     if (attr == null) {
/* 246 */       if (!required) {
/* 247 */         return defaultValue;
/*     */       }
/* 249 */       fatal(node, "Required attribute " + name + " not present!");
/*     */     } 
/*     */     
/* 252 */     String value = attr.getNodeValue();
/* 253 */     for (int i = 0; i < legalNames.length; i++) {
/* 254 */       if (value.equals(legalNames[i])) {
/* 255 */         return i;
/*     */       }
/*     */     } 
/*     */     
/* 259 */     fatal(node, "Illegal value for attribute " + name + "!");
/* 260 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static int getEnumeratedAttribute(Node node, String name, String[] legalNames) throws IIOInvalidTreeException {
/* 268 */     return getEnumeratedAttribute(node, name, legalNames, -1, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static String getAttribute(Node node, String name, String defaultValue, boolean required) throws IIOInvalidTreeException {
/* 275 */     Node attr = node.getAttributes().getNamedItem(name);
/* 276 */     if (attr == null) {
/* 277 */       if (!required) {
/* 278 */         return defaultValue;
/*     */       }
/* 280 */       fatal(node, "Required attribute " + name + " not present!");
/*     */     } 
/*     */     
/* 283 */     return attr.getNodeValue();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected static String getAttribute(Node node, String name) throws IIOInvalidTreeException {
/* 289 */     return getAttribute(node, name, null, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected GIFMetadata(boolean standardMetadataFormatSupported, String nativeMetadataFormatName, String nativeMetadataFormatClassName, String[] extraMetadataFormatNames, String[] extraMetadataFormatClassNames) {
/* 297 */     super(standardMetadataFormatSupported, nativeMetadataFormatName, nativeMetadataFormatClassName, extraMetadataFormatNames, extraMetadataFormatClassNames);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mergeTree(String formatName, Node root) throws IIOInvalidTreeException {
/* 306 */     if (formatName.equals(this.nativeMetadataFormatName)) {
/* 307 */       if (root == null) {
/* 308 */         throw new IllegalArgumentException("root == null!");
/*     */       }
/* 310 */       mergeNativeTree(root);
/* 311 */     } else if (formatName.equals("javax_imageio_1.0")) {
/*     */       
/* 313 */       if (root == null) {
/* 314 */         throw new IllegalArgumentException("root == null!");
/*     */       }
/* 316 */       mergeStandardTree(root);
/*     */     } else {
/* 318 */       throw new IllegalArgumentException("Not a recognized format!");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected byte[] getColorTable(Node colorTableNode, String entryNodeName, boolean lengthExpected, int expectedLength) throws IIOInvalidTreeException {
/* 327 */     byte[] red = new byte[256];
/* 328 */     byte[] green = new byte[256];
/* 329 */     byte[] blue = new byte[256];
/* 330 */     int maxIndex = -1;
/*     */     
/* 332 */     Node entry = colorTableNode.getFirstChild();
/* 333 */     if (entry == null) {
/* 334 */       fatal(colorTableNode, "Palette has no entries!");
/*     */     }
/*     */     
/* 337 */     while (entry != null) {
/* 338 */       if (!entry.getNodeName().equals(entryNodeName)) {
/* 339 */         fatal(colorTableNode, "Only a " + entryNodeName + " may be a child of a " + entry.getNodeName() + "!");
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 344 */       int index = getIntAttribute(entry, "index", true, 0, 255);
/* 345 */       if (index > maxIndex) {
/* 346 */         maxIndex = index;
/*     */       }
/* 348 */       red[index] = (byte)getIntAttribute(entry, "red", true, 0, 255);
/* 349 */       green[index] = (byte)getIntAttribute(entry, "green", true, 0, 255);
/* 350 */       blue[index] = (byte)getIntAttribute(entry, "blue", true, 0, 255);
/*     */       
/* 352 */       entry = entry.getNextSibling();
/*     */     } 
/*     */     
/* 355 */     int numEntries = maxIndex + 1;
/*     */     
/* 357 */     if (lengthExpected && numEntries != expectedLength) {
/* 358 */       fatal(colorTableNode, "Unexpected length for palette!");
/*     */     }
/*     */     
/* 361 */     byte[] colorTable = new byte[3 * numEntries];
/* 362 */     for (int i = 0, j = 0; i < numEntries; i++) {
/* 363 */       colorTable[j++] = red[i];
/* 364 */       colorTable[j++] = green[i];
/* 365 */       colorTable[j++] = blue[i];
/*     */     } 
/*     */     
/* 368 */     return colorTable;
/*     */   }
/*     */   
/*     */   protected abstract void mergeNativeTree(Node paramNode) throws IIOInvalidTreeException;
/*     */   
/*     */   protected abstract void mergeStandardTree(Node paramNode) throws IIOInvalidTreeException;
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/gif/GIFMetadata.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */