/*     */ package com.sun.media.imageioimpl.stream;
/*     */ 
/*     */ import com.sun.media.imageio.stream.FileChannelImageOutputStream;
/*     */ import com.sun.media.imageioimpl.common.PackageUtil;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.nio.channels.Channels;
/*     */ import java.nio.channels.FileChannel;
/*     */ import java.nio.channels.NonReadableChannelException;
/*     */ import java.nio.channels.WritableByteChannel;
/*     */ import java.util.Locale;
/*     */ import javax.imageio.spi.ImageOutputStreamSpi;
/*     */ import javax.imageio.stream.FileCacheImageOutputStream;
/*     */ import javax.imageio.stream.ImageOutputStream;
/*     */ import javax.imageio.stream.MemoryCacheImageOutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ChannelImageOutputStreamSpi
/*     */   extends ImageOutputStreamSpi
/*     */ {
/*     */   public ChannelImageOutputStreamSpi() {
/* 100 */     super(PackageUtil.getVendor(), PackageUtil.getVersion(), WritableByteChannel.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageOutputStream createOutputStreamInstance(Object output, boolean useCache, File cacheDir) throws IOException {
/*     */     FileChannelImageOutputStream fileChannelImageOutputStream;
/*     */     MemoryCacheImageOutputStream memoryCacheImageOutputStream;
/* 110 */     if (output == null || !(output instanceof WritableByteChannel))
/*     */     {
/* 112 */       throw new IllegalArgumentException("Cannot create ImageOutputStream from " + output.getClass().getName());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 117 */     ImageOutputStream stream = null;
/*     */     
/* 119 */     if (output instanceof FileChannel) {
/* 120 */       FileChannel channel = (FileChannel)output;
/*     */       
/*     */       try {
/* 123 */         channel.map(FileChannel.MapMode.READ_ONLY, channel.position(), 1L);
/*     */ 
/*     */         
/* 126 */         fileChannelImageOutputStream = new FileChannelImageOutputStream((FileChannel)output);
/* 127 */       } catch (NonReadableChannelException nrce) {}
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 132 */     if (fileChannelImageOutputStream == null) {
/* 133 */       FileCacheImageOutputStream fileCacheImageOutputStream; OutputStream outStream = Channels.newOutputStream((WritableByteChannel)output);
/*     */ 
/*     */       
/* 136 */       if (useCache) {
/*     */         try {
/* 138 */           fileCacheImageOutputStream = new FileCacheImageOutputStream(outStream, cacheDir);
/*     */         }
/* 140 */         catch (IOException e) {}
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 145 */       if (fileCacheImageOutputStream == null) {
/* 146 */         memoryCacheImageOutputStream = new MemoryCacheImageOutputStream(outStream);
/*     */       }
/*     */     } 
/*     */     
/* 150 */     return memoryCacheImageOutputStream;
/*     */   }
/*     */   
/*     */   public String getDescription(Locale locale) {
/* 154 */     return "NIO Channel ImageOutputStream";
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/stream/ChannelImageOutputStreamSpi.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */