/*     */ package com.sun.media.imageioimpl.common;
/*     */ 
/*     */ import java.awt.color.ColorSpace;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BogusColorSpace
/*     */   extends ColorSpace
/*     */ {
/*     */   private static int getType(int numComponents) {
/*  99 */     if (numComponents < 1) {
/* 100 */       throw new IllegalArgumentException("numComponents < 1!");
/*     */     }
/*     */ 
/*     */     
/* 104 */     switch (numComponents)
/*     */     { case 1:
/* 106 */         type = 6;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 115 */         return type; }  int type = numComponents + 10; return type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BogusColorSpace(int numComponents) {
/* 127 */     super(getType(numComponents), numComponents);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float[] toRGB(float[] colorvalue) {
/* 137 */     if (colorvalue.length < getNumComponents()) {
/* 138 */       throw new ArrayIndexOutOfBoundsException("colorvalue.length < getNumComponents()");
/*     */     }
/*     */ 
/*     */     
/* 142 */     float[] rgbvalue = new float[3];
/*     */     
/* 144 */     System.arraycopy(colorvalue, 0, rgbvalue, 0, Math.min(3, getNumComponents()));
/*     */ 
/*     */     
/* 147 */     return colorvalue;
/*     */   }
/*     */   
/*     */   public float[] fromRGB(float[] rgbvalue) {
/* 151 */     if (rgbvalue.length < 3) {
/* 152 */       throw new ArrayIndexOutOfBoundsException("rgbvalue.length < 3");
/*     */     }
/*     */ 
/*     */     
/* 156 */     float[] colorvalue = new float[getNumComponents()];
/*     */     
/* 158 */     System.arraycopy(rgbvalue, 0, colorvalue, 0, Math.min(3, colorvalue.length));
/*     */ 
/*     */     
/* 161 */     return rgbvalue;
/*     */   }
/*     */   
/*     */   public float[] toCIEXYZ(float[] colorvalue) {
/* 165 */     if (colorvalue.length < getNumComponents()) {
/* 166 */       throw new ArrayIndexOutOfBoundsException("colorvalue.length < getNumComponents()");
/*     */     }
/*     */ 
/*     */     
/* 170 */     float[] xyzvalue = new float[3];
/*     */     
/* 172 */     System.arraycopy(colorvalue, 0, xyzvalue, 0, Math.min(3, getNumComponents()));
/*     */ 
/*     */     
/* 175 */     return colorvalue;
/*     */   }
/*     */   
/*     */   public float[] fromCIEXYZ(float[] xyzvalue) {
/* 179 */     if (xyzvalue.length < 3) {
/* 180 */       throw new ArrayIndexOutOfBoundsException("xyzvalue.length < 3");
/*     */     }
/*     */ 
/*     */     
/* 184 */     float[] colorvalue = new float[getNumComponents()];
/*     */     
/* 186 */     System.arraycopy(xyzvalue, 0, colorvalue, 0, Math.min(3, colorvalue.length));
/*     */ 
/*     */     
/* 189 */     return xyzvalue;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/common/BogusColorSpace.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */