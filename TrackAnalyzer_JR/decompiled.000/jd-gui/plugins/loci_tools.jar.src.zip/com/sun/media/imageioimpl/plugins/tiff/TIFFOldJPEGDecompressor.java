/*     */ package com.sun.media.imageioimpl.plugins.tiff;
/*     */ 
/*     */ import com.sun.media.imageio.plugins.tiff.TIFFField;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import javax.imageio.IIOException;
/*     */ import javax.imageio.stream.ImageInputStream;
/*     */ import javax.imageio.stream.MemoryCacheImageInputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TIFFOldJPEGDecompressor
/*     */   extends TIFFJPEGDecompressor
/*     */ {
/*     */   private static final boolean DEBUG = false;
/*     */   private static final int DHT = 196;
/*     */   private static final int DQT = 219;
/*     */   private static final int DRI = 221;
/*     */   private static final int SOF0 = 192;
/*     */   private static final int SOS = 218;
/*     */   private boolean isInitialized = false;
/* 137 */   private Long JPEGStreamOffset = null;
/*     */   
/* 139 */   private int SOFPosition = -1;
/*     */   
/* 141 */   private byte[] SOSMarker = null;
/*     */ 
/*     */   
/* 144 */   private int subsamplingX = 2;
/*     */ 
/*     */   
/* 147 */   private int subsamplingY = 2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized void initialize() throws IOException {
/* 224 */     if (this.isInitialized) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 229 */     TIFFImageMetadata tim = (TIFFImageMetadata)this.metadata;
/*     */ 
/*     */     
/* 232 */     TIFFField JPEGInterchangeFormatField = tim.getTIFFField(513);
/*     */ 
/*     */ 
/*     */     
/* 236 */     TIFFField segmentOffsetField = tim.getTIFFField(324);
/*     */     
/* 238 */     if (segmentOffsetField == null) {
/* 239 */       segmentOffsetField = tim.getTIFFField(273);
/*     */       
/* 241 */       if (segmentOffsetField == null) {
/* 242 */         segmentOffsetField = JPEGInterchangeFormatField;
/*     */       }
/*     */     } 
/* 245 */     long[] segmentOffsets = segmentOffsetField.getAsLongs();
/*     */ 
/*     */     
/* 248 */     boolean isTiled = (segmentOffsets.length > 1);
/*     */     
/* 250 */     if (!isTiled) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 258 */       this.stream.seek(this.offset);
/* 259 */       this.stream.mark();
/* 260 */       if (this.stream.read() == 255 && this.stream.read() == 216) {
/*     */         
/* 262 */         this.JPEGStreamOffset = new Long(this.offset);
/*     */ 
/*     */ 
/*     */         
/* 266 */         ((TIFFImageReader)this.reader).forwardWarningMessage("SOI marker detected at start of strip or tile.");
/* 267 */         this.isInitialized = true;
/* 268 */         this.stream.reset();
/*     */         return;
/*     */       } 
/* 271 */       this.stream.reset();
/*     */       
/* 273 */       if (JPEGInterchangeFormatField != null) {
/*     */         
/* 275 */         long jpegInterchangeOffset = JPEGInterchangeFormatField.getAsLong(0);
/*     */ 
/*     */ 
/*     */         
/* 279 */         this.stream.mark();
/* 280 */         this.stream.seek(jpegInterchangeOffset);
/* 281 */         if (this.stream.read() == 255 && this.stream.read() == 216) {
/*     */           
/* 283 */           this.JPEGStreamOffset = new Long(jpegInterchangeOffset);
/*     */         } else {
/* 285 */           ((TIFFImageReader)this.reader).forwardWarningMessage("JPEGInterchangeFormat does not point to SOI");
/* 286 */         }  this.stream.reset();
/*     */ 
/*     */         
/* 289 */         TIFFField JPEGInterchangeFormatLengthField = tim.getTIFFField(514);
/*     */ 
/*     */         
/* 292 */         if (JPEGInterchangeFormatLengthField == null) {
/*     */           
/* 294 */           ((TIFFImageReader)this.reader).forwardWarningMessage("JPEGInterchangeFormatLength field is missing");
/*     */         } else {
/*     */           
/* 297 */           long jpegInterchangeLength = JPEGInterchangeFormatLengthField.getAsLong(0);
/*     */ 
/*     */           
/* 300 */           if (jpegInterchangeOffset >= segmentOffsets[0] || jpegInterchangeOffset + jpegInterchangeLength <= segmentOffsets[0])
/*     */           {
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 306 */             ((TIFFImageReader)this.reader).forwardWarningMessage("JPEGInterchangeFormatLength field value is invalid");
/*     */           }
/*     */         } 
/*     */ 
/*     */         
/* 311 */         if (this.JPEGStreamOffset != null) {
/* 312 */           this.isInitialized = true;
/*     */           
/*     */           return;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 319 */     TIFFField YCbCrSubsamplingField = tim.getTIFFField(530);
/*     */     
/* 321 */     if (YCbCrSubsamplingField != null) {
/* 322 */       this.subsamplingX = YCbCrSubsamplingField.getAsChars()[0];
/* 323 */       this.subsamplingY = YCbCrSubsamplingField.getAsChars()[1];
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 330 */     if (JPEGInterchangeFormatField != null) {
/*     */       
/* 332 */       long jpegInterchangeOffset = JPEGInterchangeFormatField.getAsLong(0);
/*     */ 
/*     */ 
/*     */       
/* 336 */       TIFFField JPEGInterchangeFormatLengthField = tim.getTIFFField(514);
/*     */ 
/*     */       
/* 339 */       if (JPEGInterchangeFormatLengthField != null) {
/*     */         
/* 341 */         long jpegInterchangeLength = JPEGInterchangeFormatLengthField.getAsLong(0);
/*     */ 
/*     */         
/* 344 */         if (jpegInterchangeLength >= 2L && jpegInterchangeOffset + jpegInterchangeLength <= segmentOffsets[0]) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 349 */           this.stream.mark();
/* 350 */           this.stream.seek(jpegInterchangeOffset + jpegInterchangeLength - 2L);
/* 351 */           if (this.stream.read() == 255 && this.stream.read() == 217) {
/* 352 */             this.tables = new byte[(int)(jpegInterchangeLength - 2L)];
/*     */           } else {
/* 354 */             this.tables = new byte[(int)jpegInterchangeLength];
/*     */           } 
/* 356 */           this.stream.reset();
/*     */ 
/*     */           
/* 359 */           this.stream.mark();
/* 360 */           this.stream.seek(jpegInterchangeOffset);
/* 361 */           this.stream.readFully(this.tables);
/* 362 */           this.stream.reset();
/*     */ 
/*     */           
/* 365 */           ((TIFFImageReader)this.reader).forwardWarningMessage("Incorrect JPEG interchange format: using JPEGInterchangeFormat offset to derive tables.");
/*     */         } else {
/* 367 */           ((TIFFImageReader)this.reader).forwardWarningMessage("JPEGInterchangeFormat+JPEGInterchangeFormatLength > offset to first strip or tile.");
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 372 */     if (this.tables == null) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 378 */       ByteArrayOutputStream baos = new ByteArrayOutputStream();
/*     */ 
/*     */ 
/*     */       
/* 382 */       long streamLength = this.stream.length();
/*     */ 
/*     */       
/* 385 */       baos.write(255);
/* 386 */       baos.write(216);
/*     */ 
/*     */       
/* 389 */       TIFFField f = tim.getTIFFField(519);
/*     */       
/* 391 */       if (f == null) {
/* 392 */         throw new IIOException("JPEGQTables field missing!");
/*     */       }
/* 394 */       long[] off = f.getAsLongs();
/*     */       
/* 396 */       for (int i = 0; i < off.length; i++) {
/* 397 */         baos.write(255);
/* 398 */         baos.write(219);
/*     */         
/* 400 */         char markerLength = 'C';
/* 401 */         baos.write(markerLength >>> 8 & 0xFF);
/* 402 */         baos.write(markerLength & 0xFF);
/*     */         
/* 404 */         baos.write(i);
/*     */         
/* 406 */         byte[] qtable = new byte[64];
/* 407 */         if (streamLength != -1L && off[i] > streamLength) {
/* 408 */           throw new IIOException("JPEGQTables offset for index " + i + " is not in the stream!");
/*     */         }
/*     */         
/* 411 */         this.stream.seek(off[i]);
/* 412 */         this.stream.readFully(qtable);
/*     */         
/* 414 */         baos.write(qtable);
/*     */       } 
/*     */ 
/*     */       
/* 418 */       for (int k = 0; k < 2; k++) {
/* 419 */         int tableTagNumber = (k == 0) ? 520 : 521;
/*     */ 
/*     */         
/* 422 */         f = tim.getTIFFField(tableTagNumber);
/* 423 */         String fieldName = (tableTagNumber == 520) ? "JPEGDCTables" : "JPEGACTables";
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 428 */         if (f == null) {
/* 429 */           throw new IIOException(fieldName + " field missing!");
/*     */         }
/* 431 */         off = f.getAsLongs();
/*     */         
/* 433 */         for (int j = 0; j < off.length; j++) {
/* 434 */           baos.write(255);
/* 435 */           baos.write(196);
/*     */           
/* 437 */           byte[] blengths = new byte[16];
/* 438 */           if (streamLength != -1L && off[j] > streamLength) {
/* 439 */             throw new IIOException(fieldName + " offset for index " + j + " is not in the stream!");
/*     */           }
/*     */           
/* 442 */           this.stream.seek(off[j]);
/* 443 */           this.stream.readFully(blengths);
/* 444 */           int numCodes = 0;
/* 445 */           for (int m = 0; m < 16; m++) {
/* 446 */             numCodes += blengths[m] & 0xFF;
/*     */           }
/*     */           
/* 449 */           char markerLength = (char)(19 + numCodes);
/*     */           
/* 451 */           baos.write(markerLength >>> 8 & 0xFF);
/* 452 */           baos.write(markerLength & 0xFF);
/*     */           
/* 454 */           baos.write(j | k << 4);
/*     */           
/* 456 */           baos.write(blengths);
/*     */           
/* 458 */           byte[] bcodes = new byte[numCodes];
/* 459 */           this.stream.readFully(bcodes);
/* 460 */           baos.write(bcodes);
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 465 */       baos.write(-1);
/* 466 */       baos.write(-64);
/* 467 */       short sval = (short)(8 + 3 * this.samplesPerPixel);
/* 468 */       baos.write((byte)(sval >>> 8 & 0xFF));
/* 469 */       baos.write((byte)(sval & 0xFF));
/* 470 */       baos.write(8);
/* 471 */       sval = (short)this.srcHeight;
/* 472 */       baos.write((byte)(sval >>> 8 & 0xFF));
/* 473 */       baos.write((byte)(sval & 0xFF));
/* 474 */       sval = (short)this.srcWidth;
/* 475 */       baos.write((byte)(sval >>> 8 & 0xFF));
/* 476 */       baos.write((byte)(sval & 0xFF));
/* 477 */       baos.write((byte)this.samplesPerPixel);
/* 478 */       if (this.samplesPerPixel == 1) {
/* 479 */         baos.write(1);
/* 480 */         baos.write(17);
/* 481 */         baos.write(0);
/*     */       } else {
/* 483 */         for (int j = 0; j < 3; j++) {
/* 484 */           baos.write((byte)(j + 1));
/* 485 */           baos.write((j != 0) ? 17 : (byte)((this.subsamplingX & 0xF) << 4 | this.subsamplingY & 0xF));
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 490 */           baos.write((byte)j);
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 496 */       f = tim.getTIFFField(515);
/* 497 */       if (f != null) {
/* 498 */         char restartInterval = f.getAsChars()[0];
/*     */         
/* 500 */         if (restartInterval != '\000') {
/* 501 */           baos.write(-1);
/* 502 */           baos.write(-35);
/*     */           
/* 504 */           sval = 4;
/* 505 */           baos.write((byte)(sval >>> 8 & 0xFF));
/* 506 */           baos.write((byte)(sval & 0xFF));
/*     */ 
/*     */           
/* 509 */           baos.write((byte)(restartInterval >>> 8 & 0xFF));
/* 510 */           baos.write((byte)(restartInterval & 0xFF));
/*     */         } 
/*     */       } 
/*     */       
/* 514 */       this.tables = baos.toByteArray();
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 522 */     int idx = 0;
/* 523 */     int idxMax = this.tables.length - 1;
/* 524 */     while (idx < idxMax) {
/* 525 */       if ((this.tables[idx] & 0xFF) == 255 && (this.tables[idx + 1] & 0xFF) == 192) {
/*     */         
/* 527 */         this.SOFPosition = idx;
/*     */         break;
/*     */       } 
/* 530 */       idx++;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 536 */     if (this.SOFPosition == -1) {
/* 537 */       byte[] tmpTables = new byte[this.tables.length + 10 + 3 * this.samplesPerPixel];
/*     */       
/* 539 */       System.arraycopy(this.tables, 0, tmpTables, 0, this.tables.length);
/* 540 */       int tmpOffset = this.tables.length;
/* 541 */       this.SOFPosition = this.tables.length;
/* 542 */       this.tables = tmpTables;
/*     */       
/* 544 */       this.tables[tmpOffset++] = -1;
/* 545 */       this.tables[tmpOffset++] = -64;
/* 546 */       short sval = (short)(8 + 3 * this.samplesPerPixel);
/* 547 */       this.tables[tmpOffset++] = (byte)(sval >>> 8 & 0xFF);
/* 548 */       this.tables[tmpOffset++] = (byte)(sval & 0xFF);
/* 549 */       this.tables[tmpOffset++] = 8;
/* 550 */       sval = (short)this.srcHeight;
/* 551 */       this.tables[tmpOffset++] = (byte)(sval >>> 8 & 0xFF);
/* 552 */       this.tables[tmpOffset++] = (byte)(sval & 0xFF);
/* 553 */       sval = (short)this.srcWidth;
/* 554 */       this.tables[tmpOffset++] = (byte)(sval >>> 8 & 0xFF);
/* 555 */       this.tables[tmpOffset++] = (byte)(sval & 0xFF);
/* 556 */       this.tables[tmpOffset++] = (byte)this.samplesPerPixel;
/* 557 */       if (this.samplesPerPixel == 1) {
/* 558 */         this.tables[tmpOffset++] = 1;
/* 559 */         this.tables[tmpOffset++] = 17;
/* 560 */         this.tables[tmpOffset++] = 0;
/*     */       } else {
/* 562 */         for (int i = 0; i < 3; i++) {
/* 563 */           this.tables[tmpOffset++] = (byte)(i + 1);
/* 564 */           this.tables[tmpOffset++] = (i != 0) ? 17 : (byte)((this.subsamplingX & 0xF) << 4 | this.subsamplingY & 0xF);
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 569 */           this.tables[tmpOffset++] = (byte)i;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 577 */     this.stream.mark();
/* 578 */     this.stream.seek(segmentOffsets[0]);
/* 579 */     if (this.stream.read() == 255 && this.stream.read() == 218) {
/*     */ 
/*     */ 
/*     */       
/* 583 */       int SOSLength = this.stream.read() << 8 | this.stream.read();
/* 584 */       this.SOSMarker = new byte[SOSLength + 2];
/* 585 */       this.SOSMarker[0] = -1;
/* 586 */       this.SOSMarker[1] = -38;
/* 587 */       this.SOSMarker[2] = (byte)((SOSLength & 0xFF00) >> 8);
/* 588 */       this.SOSMarker[3] = (byte)(SOSLength & 0xFF);
/* 589 */       this.stream.readFully(this.SOSMarker, 4, SOSLength - 2);
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 594 */       this.SOSMarker = new byte[8 + 2 * this.samplesPerPixel];
/* 595 */       int SOSMarkerIndex = 0;
/* 596 */       this.SOSMarker[SOSMarkerIndex++] = -1;
/* 597 */       this.SOSMarker[SOSMarkerIndex++] = -38;
/* 598 */       short sval = (short)(6 + 2 * this.samplesPerPixel);
/* 599 */       this.SOSMarker[SOSMarkerIndex++] = (byte)(sval >>> 8 & 0xFF);
/* 600 */       this.SOSMarker[SOSMarkerIndex++] = (byte)(sval & 0xFF);
/*     */       
/* 602 */       this.SOSMarker[SOSMarkerIndex++] = (byte)this.samplesPerPixel;
/* 603 */       if (this.samplesPerPixel == 1) {
/* 604 */         this.SOSMarker[SOSMarkerIndex++] = 1;
/* 605 */         this.SOSMarker[SOSMarkerIndex++] = 0;
/*     */       } else {
/* 607 */         for (int i = 0; i < 3; i++) {
/* 608 */           this.SOSMarker[SOSMarkerIndex++] = (byte)(i + 1);
/*     */           
/* 610 */           this.SOSMarker[SOSMarkerIndex++] = (byte)(i << 4 | i);
/*     */         } 
/*     */       } 
/*     */       
/* 614 */       this.SOSMarker[SOSMarkerIndex++] = 0;
/* 615 */       this.SOSMarker[SOSMarkerIndex++] = 63;
/* 616 */       this.SOSMarker[SOSMarkerIndex++] = 0;
/*     */     } 
/* 618 */     this.stream.reset();
/*     */ 
/*     */     
/* 621 */     this.isInitialized = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void decodeRaw(byte[] b, int dstOffset, int bitsPerPixel, int scanlineStride) throws IOException {
/* 636 */     initialize();
/*     */     
/* 638 */     TIFFImageMetadata tim = (TIFFImageMetadata)this.metadata;
/*     */     
/* 640 */     if (this.JPEGStreamOffset != null) {
/* 641 */       this.stream.seek(this.JPEGStreamOffset.longValue());
/* 642 */       this.JPEGReader.setInput(this.stream, false, true);
/*     */     } else {
/*     */       
/* 645 */       int tableLength = this.tables.length;
/* 646 */       int bufLength = tableLength + this.SOSMarker.length + this.byteCount + 2;
/*     */       
/* 648 */       byte[] buf = new byte[bufLength];
/* 649 */       if (this.tables != null) {
/* 650 */         System.arraycopy(this.tables, 0, buf, 0, tableLength);
/*     */       }
/* 652 */       int bufOffset = tableLength;
/*     */ 
/*     */       
/* 655 */       short sval = (short)this.srcHeight;
/* 656 */       buf[this.SOFPosition + 5] = (byte)(sval >>> 8 & 0xFF);
/* 657 */       buf[this.SOFPosition + 6] = (byte)(sval & 0xFF);
/* 658 */       sval = (short)this.srcWidth;
/* 659 */       buf[this.SOFPosition + 7] = (byte)(sval >>> 8 & 0xFF);
/* 660 */       buf[this.SOFPosition + 8] = (byte)(sval & 0xFF);
/*     */ 
/*     */       
/* 663 */       this.stream.seek(this.offset);
/*     */ 
/*     */       
/* 666 */       byte[] twoBytes = new byte[2];
/* 667 */       this.stream.readFully(twoBytes);
/* 668 */       if ((twoBytes[0] & 0xFF) != 255 || (twoBytes[1] & 0xFF) != 218) {
/*     */ 
/*     */         
/* 671 */         System.arraycopy(this.SOSMarker, 0, buf, bufOffset, this.SOSMarker.length);
/*     */         
/* 673 */         bufOffset += this.SOSMarker.length;
/*     */       } 
/*     */ 
/*     */       
/* 677 */       buf[bufOffset++] = twoBytes[0];
/* 678 */       buf[bufOffset++] = twoBytes[1];
/* 679 */       this.stream.readFully(buf, bufOffset, this.byteCount - 2);
/* 680 */       bufOffset += this.byteCount - 2;
/*     */ 
/*     */       
/* 683 */       buf[bufOffset++] = -1;
/* 684 */       buf[bufOffset++] = -39;
/*     */       
/* 686 */       ByteArrayInputStream bais = new ByteArrayInputStream(buf, 0, bufOffset);
/*     */       
/* 688 */       ImageInputStream is = new MemoryCacheImageInputStream(bais);
/*     */       
/* 690 */       this.JPEGReader.setInput(is, true, true);
/*     */     } 
/*     */ 
/*     */     
/* 694 */     this.JPEGParam.setDestination(this.rawImage);
/* 695 */     this.JPEGReader.read(0, this.JPEGParam);
/*     */   }
/*     */   
/*     */   protected void finalize() throws Throwable {
/* 699 */     super.finalize();
/* 700 */     this.JPEGReader.dispose();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/tiff/TIFFOldJPEGDecompressor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */