/*     */ package com.sun.media.imageioimpl.plugins.pcx;
/*     */ 
/*     */ import com.sun.media.imageioimpl.common.ImageUtil;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.image.ColorModel;
/*     */ import java.awt.image.IndexColorModel;
/*     */ import java.awt.image.Raster;
/*     */ import java.awt.image.RenderedImage;
/*     */ import java.awt.image.SampleModel;
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteOrder;
/*     */ import javax.imageio.IIOImage;
/*     */ import javax.imageio.ImageTypeSpecifier;
/*     */ import javax.imageio.ImageWriteParam;
/*     */ import javax.imageio.ImageWriter;
/*     */ import javax.imageio.metadata.IIOMetadata;
/*     */ import javax.imageio.stream.ImageOutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PCXImageWriter
/*     */   extends ImageWriter
/*     */   implements PCXConstants
/*     */ {
/*     */   private ImageOutputStream ios;
/*     */   private Rectangle sourceRegion;
/*     */   private Rectangle destinationRegion;
/*     */   private int colorPlanes;
/*     */   private int bytesPerLine;
/* 101 */   private Raster inputRaster = null;
/*     */   private int scaleX;
/*     */   
/*     */   public PCXImageWriter(PCXImageWriterSpi imageWriterSpi) {
/* 105 */     super(imageWriterSpi);
/*     */   }
/*     */   private int scaleY;
/*     */   public void setOutput(Object output) {
/* 109 */     super.setOutput(output);
/* 110 */     if (output != null) {
/* 111 */       if (!(output instanceof ImageOutputStream))
/* 112 */         throw new IllegalArgumentException("output not instance of ImageOutputStream"); 
/* 113 */       this.ios = (ImageOutputStream)output;
/* 114 */       this.ios.setByteOrder(ByteOrder.LITTLE_ENDIAN);
/*     */     } else {
/* 116 */       this.ios = null;
/*     */     } 
/*     */   }
/*     */   public IIOMetadata convertImageMetadata(IIOMetadata inData, ImageTypeSpecifier imageType, ImageWriteParam param) {
/* 120 */     if (inData instanceof PCXMetadata)
/* 121 */       return inData; 
/* 122 */     return null;
/*     */   }
/*     */   
/*     */   public IIOMetadata convertStreamMetadata(IIOMetadata inData, ImageWriteParam param) {
/* 126 */     return null;
/*     */   }
/*     */   
/*     */   public IIOMetadata getDefaultImageMetadata(ImageTypeSpecifier imageType, ImageWriteParam param) {
/* 130 */     PCXMetadata md = new PCXMetadata();
/* 131 */     md.bitsPerPixel = (byte)imageType.getSampleModel().getSampleSize()[0];
/* 132 */     return md;
/*     */   }
/*     */   
/*     */   public IIOMetadata getDefaultStreamMetadata(ImageWriteParam param) {
/* 136 */     return null;
/*     */   }
/*     */   
/*     */   public void write(IIOMetadata streamMetadata, IIOImage image, ImageWriteParam param) throws IOException {
/* 140 */     if (this.ios == null) {
/* 141 */       throw new IllegalStateException("output stream is null");
/*     */     }
/*     */     
/* 144 */     if (image == null) {
/* 145 */       throw new IllegalArgumentException("image is null");
/*     */     }
/*     */     
/* 148 */     clearAbortRequest();
/* 149 */     processImageStarted(0);
/* 150 */     if (param == null) {
/* 151 */       param = getDefaultWriteParam();
/*     */     }
/* 153 */     boolean writeRaster = image.hasRaster();
/*     */     
/* 155 */     this.sourceRegion = param.getSourceRegion();
/*     */     
/* 157 */     SampleModel sampleModel = null;
/* 158 */     ColorModel colorModel = null;
/*     */     
/* 160 */     if (writeRaster)
/* 161 */     { this.inputRaster = image.getRaster();
/* 162 */       sampleModel = this.inputRaster.getSampleModel();
/* 163 */       colorModel = ImageUtil.createColorModel(null, sampleModel);
/* 164 */       if (this.sourceRegion == null) {
/* 165 */         this.sourceRegion = this.inputRaster.getBounds();
/*     */       } else {
/* 167 */         this.sourceRegion = this.sourceRegion.intersection(this.inputRaster.getBounds());
/*     */       }  }
/* 169 */     else { RenderedImage input = image.getRenderedImage();
/* 170 */       this.inputRaster = input.getData();
/* 171 */       sampleModel = input.getSampleModel();
/* 172 */       colorModel = input.getColorModel();
/* 173 */       Rectangle rect = new Rectangle(input.getMinX(), input.getMinY(), input.getWidth(), input.getHeight());
/*     */       
/* 175 */       if (this.sourceRegion == null) {
/* 176 */         this.sourceRegion = rect;
/*     */       } else {
/* 178 */         this.sourceRegion = this.sourceRegion.intersection(rect);
/*     */       }  }
/*     */     
/* 181 */     if (this.sourceRegion.isEmpty()) {
/* 182 */       throw new IllegalArgumentException("source region is empty");
/*     */     }
/* 184 */     IIOMetadata imageMetadata = image.getMetadata();
/* 185 */     PCXMetadata pcxImageMetadata = null;
/*     */     
/* 187 */     ImageTypeSpecifier imageType = new ImageTypeSpecifier(colorModel, sampleModel);
/* 188 */     if (imageMetadata != null) {
/*     */       
/* 190 */       pcxImageMetadata = (PCXMetadata)convertImageMetadata(imageMetadata, imageType, param);
/*     */     } else {
/*     */       
/* 193 */       pcxImageMetadata = (PCXMetadata)getDefaultImageMetadata(imageType, param);
/*     */     } 
/*     */     
/* 196 */     this.scaleX = param.getSourceXSubsampling();
/* 197 */     this.scaleY = param.getSourceYSubsampling();
/*     */     
/* 199 */     int xOffset = param.getSubsamplingXOffset();
/* 200 */     int yOffset = param.getSubsamplingYOffset();
/*     */ 
/*     */     
/* 203 */     int dataType = sampleModel.getDataType();
/*     */     
/* 205 */     this.sourceRegion.translate(xOffset, yOffset);
/* 206 */     this.sourceRegion.width -= xOffset;
/* 207 */     this.sourceRegion.height -= yOffset;
/*     */     
/* 209 */     int minX = this.sourceRegion.x / this.scaleX;
/* 210 */     int minY = this.sourceRegion.y / this.scaleY;
/* 211 */     int w = (this.sourceRegion.width + this.scaleX - 1) / this.scaleX;
/* 212 */     int h = (this.sourceRegion.height + this.scaleY - 1) / this.scaleY;
/*     */     
/* 214 */     xOffset = this.sourceRegion.x % this.scaleX;
/* 215 */     yOffset = this.sourceRegion.y % this.scaleY;
/*     */     
/* 217 */     this.destinationRegion = new Rectangle(minX, minY, w, h);
/*     */     
/* 219 */     boolean noTransform = this.destinationRegion.equals(this.sourceRegion);
/*     */ 
/*     */     
/* 222 */     int[] sourceBands = param.getSourceBands();
/* 223 */     boolean noSubband = true;
/* 224 */     int numBands = sampleModel.getNumBands();
/*     */     
/* 226 */     if (sourceBands != null) {
/* 227 */       sampleModel = sampleModel.createSubsetSampleModel(sourceBands);
/* 228 */       colorModel = null;
/* 229 */       noSubband = false;
/* 230 */       numBands = sampleModel.getNumBands();
/*     */     } else {
/* 232 */       sourceBands = new int[numBands];
/* 233 */       for (int j = 0; j < numBands; j++) {
/* 234 */         sourceBands[j] = j;
/*     */       }
/*     */     } 
/* 237 */     this.ios.writeByte(10);
/* 238 */     this.ios.writeByte(5);
/* 239 */     this.ios.writeByte(1);
/*     */     
/* 241 */     int bitsPerPixel = sampleModel.getSampleSize(0);
/* 242 */     this.ios.writeByte(bitsPerPixel);
/*     */     
/* 244 */     this.ios.writeShort(this.destinationRegion.x);
/* 245 */     this.ios.writeShort(this.destinationRegion.y);
/* 246 */     this.ios.writeShort(this.destinationRegion.x + this.destinationRegion.width - 1);
/* 247 */     this.ios.writeShort(this.destinationRegion.y + this.destinationRegion.height - 1);
/*     */     
/* 249 */     this.ios.writeShort(pcxImageMetadata.hdpi);
/* 250 */     this.ios.writeShort(pcxImageMetadata.vdpi);
/*     */     
/* 252 */     byte[] smallpalette = createSmallPalette(colorModel);
/* 253 */     this.ios.write(smallpalette);
/* 254 */     this.ios.writeByte(0);
/*     */     
/* 256 */     this.colorPlanes = sampleModel.getNumBands();
/*     */     
/* 258 */     this.ios.writeByte(this.colorPlanes);
/*     */     
/* 260 */     this.bytesPerLine = this.destinationRegion.width * bitsPerPixel / 8;
/* 261 */     this.bytesPerLine += this.bytesPerLine % 2;
/*     */     
/* 263 */     this.ios.writeShort(this.bytesPerLine);
/*     */     
/* 265 */     if (colorModel.getColorSpace().getType() == 6) {
/* 266 */       this.ios.writeShort(2);
/*     */     } else {
/* 268 */       this.ios.writeShort(1);
/*     */     } 
/* 270 */     this.ios.writeShort(pcxImageMetadata.hsize);
/* 271 */     this.ios.writeShort(pcxImageMetadata.vsize);
/*     */     
/* 273 */     for (int i = 0; i < 54; i++) {
/* 274 */       this.ios.writeByte(0);
/*     */     }
/*     */ 
/*     */     
/* 278 */     if (this.colorPlanes == 1 && bitsPerPixel == 1) {
/* 279 */       write1Bit();
/*     */     }
/* 281 */     else if (this.colorPlanes == 1 && bitsPerPixel == 4) {
/* 282 */       write4Bit();
/*     */     } else {
/*     */       
/* 285 */       write8Bit();
/*     */     } 
/*     */ 
/*     */     
/* 289 */     if (this.colorPlanes == 1 && bitsPerPixel == 8 && colorModel.getColorSpace().getType() != 6) {
/*     */       
/* 291 */       this.ios.writeByte(12);
/* 292 */       this.ios.write(createLargePalette(colorModel));
/*     */     } 
/*     */     
/* 295 */     if (abortRequested()) {
/* 296 */       processWriteAborted();
/*     */     } else {
/* 298 */       processImageComplete();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void write4Bit() throws IOException {
/* 303 */     int[] unpacked = new int[this.sourceRegion.width];
/* 304 */     int[] samples = new int[this.bytesPerLine];
/*     */     
/* 306 */     for (int line = 0; line < this.sourceRegion.height; line += this.scaleY) {
/* 307 */       this.inputRaster.getSamples(this.sourceRegion.x, line + this.sourceRegion.y, this.sourceRegion.width, 1, 0, unpacked);
/*     */       
/* 309 */       int val = 0, dst = 0; int x, nibble;
/* 310 */       for (x = 0, nibble = 0; x < this.sourceRegion.width; x += this.scaleX) {
/* 311 */         val |= unpacked[x] & 0xF;
/* 312 */         if (nibble == 1) {
/* 313 */           samples[dst++] = val;
/* 314 */           nibble = 0;
/* 315 */           val = 0;
/*     */         } else {
/* 317 */           nibble = 1;
/* 318 */           val <<= 4;
/*     */         } 
/*     */       } 
/*     */       
/* 322 */       int last = samples[0];
/* 323 */       int count = 0;
/*     */       int i;
/* 325 */       for (i = 0; i < this.bytesPerLine; i += this.scaleX) {
/* 326 */         int sample = samples[i];
/* 327 */         if (sample != last || count == 63) {
/* 328 */           writeRLE(last, count);
/* 329 */           count = 1;
/* 330 */           last = sample;
/*     */         } else {
/* 332 */           count++;
/*     */         } 
/* 334 */       }  if (count >= 1) {
/* 335 */         writeRLE(last, count);
/*     */       }
/*     */       
/* 338 */       processImageProgress(100.0F * line / this.sourceRegion.height);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void write1Bit() throws IOException {
/* 343 */     int[] unpacked = new int[this.sourceRegion.width];
/* 344 */     int[] samples = new int[this.bytesPerLine];
/*     */     
/* 346 */     for (int line = 0; line < this.sourceRegion.height; line += this.scaleY) {
/* 347 */       this.inputRaster.getSamples(this.sourceRegion.x, line + this.sourceRegion.y, this.sourceRegion.width, 1, 0, unpacked);
/*     */       
/* 349 */       int val = 0, dst = 0; int x, bit;
/* 350 */       for (x = 0, bit = 128; x < this.sourceRegion.width; x += this.scaleX) {
/* 351 */         if (unpacked[x] > 0)
/* 352 */           val |= bit; 
/* 353 */         if (bit == 1) {
/* 354 */           samples[dst++] = val;
/* 355 */           bit = 128;
/* 356 */           val = 0;
/*     */         } else {
/* 358 */           bit >>= 1;
/*     */         } 
/*     */       } 
/*     */       
/* 362 */       int last = samples[0];
/* 363 */       int count = 0;
/*     */       int i;
/* 365 */       for (i = 0; i < this.bytesPerLine; i += this.scaleX) {
/* 366 */         int sample = samples[i];
/* 367 */         if (sample != last || count == 63) {
/* 368 */           writeRLE(last, count);
/* 369 */           count = 1;
/* 370 */           last = sample;
/*     */         } else {
/* 372 */           count++;
/*     */         } 
/* 374 */       }  if (count >= 1) {
/* 375 */         writeRLE(last, count);
/*     */       }
/*     */       
/* 378 */       processImageProgress(100.0F * line / this.sourceRegion.height);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void write8Bit() throws IOException {
/* 383 */     int[][] samples = new int[this.colorPlanes][this.bytesPerLine];
/*     */     
/* 385 */     for (int line = 0; line < this.sourceRegion.height; line += this.scaleY) {
/* 386 */       for (int band = 0; band < this.colorPlanes; band++) {
/* 387 */         this.inputRaster.getSamples(this.sourceRegion.x, line + this.sourceRegion.y, this.sourceRegion.width, 1, band, samples[band]);
/*     */       }
/*     */       
/* 390 */       int last = samples[0][0];
/* 391 */       int count = 0;
/*     */       
/* 393 */       for (int i = 0; i < this.colorPlanes; i++) {
/* 394 */         int x; for (x = 0; x < this.bytesPerLine; x += this.scaleX) {
/* 395 */           int sample = samples[i][x];
/* 396 */           if (sample != last || count == 63) {
/* 397 */             writeRLE(last, count);
/* 398 */             count = 1;
/* 399 */             last = sample;
/*     */           } else {
/* 401 */             count++;
/*     */           } 
/*     */         } 
/* 404 */       }  if (count >= 1) {
/* 405 */         writeRLE(last, count);
/*     */       }
/*     */       
/* 408 */       processImageProgress(100.0F * line / this.sourceRegion.height);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void writeRLE(int val, int count) throws IOException {
/* 413 */     if (count == 1 && (val & 0xC0) != 192) {
/* 414 */       this.ios.writeByte(val);
/*     */     } else {
/* 416 */       this.ios.writeByte(0xC0 | count);
/* 417 */       this.ios.writeByte(val);
/*     */     } 
/*     */   }
/*     */   
/*     */   private byte[] createSmallPalette(ColorModel cm) {
/* 422 */     byte[] palette = new byte[48];
/*     */     
/* 424 */     if (!(cm instanceof IndexColorModel)) {
/* 425 */       return palette;
/*     */     }
/* 427 */     IndexColorModel icm = (IndexColorModel)cm;
/* 428 */     if (icm.getMapSize() > 16) {
/* 429 */       return palette;
/*     */     }
/* 431 */     for (int i = 0, offset = 0; i < icm.getMapSize(); i++) {
/* 432 */       palette[offset++] = (byte)icm.getRed(i);
/* 433 */       palette[offset++] = (byte)icm.getGreen(i);
/* 434 */       palette[offset++] = (byte)icm.getBlue(i);
/*     */     } 
/*     */     
/* 437 */     return palette;
/*     */   }
/*     */   private byte[] createLargePalette(ColorModel cm) {
/* 440 */     byte[] palette = new byte[768];
/*     */     
/* 442 */     if (!(cm instanceof IndexColorModel)) {
/* 443 */       return palette;
/*     */     }
/* 445 */     IndexColorModel icm = (IndexColorModel)cm;
/*     */     
/* 447 */     for (int i = 0, offset = 0; i < icm.getMapSize(); i++) {
/* 448 */       palette[offset++] = (byte)icm.getRed(i);
/* 449 */       palette[offset++] = (byte)icm.getGreen(i);
/* 450 */       palette[offset++] = (byte)icm.getBlue(i);
/*     */     } 
/*     */     
/* 453 */     return palette;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/pcx/PCXImageWriter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */