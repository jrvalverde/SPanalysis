/*      */ package com.sun.media.imageioimpl.plugins.tiff;
/*      */ 
/*      */ import com.sun.media.imageio.plugins.tiff.TIFFDecompressor;
/*      */ import com.sun.media.imageio.plugins.tiff.TIFFField;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.EOFException;
/*      */ import java.io.IOException;
/*      */ import java.io.PrintStream;
/*      */ import javax.imageio.IIOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class TIFFFaxDecompressor
/*      */   extends TIFFDecompressor
/*      */ {
/*      */   protected int fillOrder;
/*      */   protected int compression;
/*      */   private int t4Options;
/*      */   private int t6Options;
/*  115 */   protected int uncompressedMode = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  121 */   protected int fillBits = 0;
/*      */   
/*      */   protected int oneD;
/*      */   
/*      */   private byte[] data;
/*      */   
/*      */   private int bitPointer;
/*      */   
/*      */   private int bytePointer;
/*      */   
/*      */   private byte[] buffer;
/*      */   
/*      */   private int w;
/*      */   
/*      */   private int h;
/*      */   private int bitsPerScanline;
/*      */   private int lineBitNum;
/*  138 */   private int changingElemSize = 0;
/*      */   
/*      */   private int[] prevChangingElems;
/*      */   
/*      */   private int[] currChangingElems;
/*  143 */   private int lastChangingElement = 0;
/*      */   
/*  145 */   static int[] table1 = new int[] { 0, 1, 3, 7, 15, 31, 63, 127, 255 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  157 */   static int[] table2 = new int[] { 0, 128, 192, 224, 240, 248, 252, 254, 255 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  170 */   static byte[] flipTable = new byte[] { 0, Byte.MIN_VALUE, 64, -64, 32, -96, 96, -32, 16, -112, 80, -48, 48, -80, 112, -16, 8, -120, 72, -56, 40, -88, 104, -24, 24, -104, 88, -40, 56, -72, 120, -8, 4, -124, 68, -60, 36, -92, 100, -28, 20, -108, 84, -44, 52, -76, 116, -12, 12, -116, 76, -52, 44, -84, 108, -20, 28, -100, 92, -36, 60, -68, 124, -4, 2, -126, 66, -62, 34, -94, 98, -30, 18, -110, 82, -46, 50, -78, 114, -14, 10, -118, 74, -54, 42, -86, 106, -22, 26, -102, 90, -38, 58, -70, 122, -6, 6, -122, 70, -58, 38, -90, 102, -26, 22, -106, 86, -42, 54, -74, 118, -10, 14, -114, 78, -50, 46, -82, 110, -18, 30, -98, 94, -34, 62, -66, 126, -2, 1, -127, 65, -63, 33, -95, 97, -31, 17, -111, 81, -47, 49, -79, 113, -15, 9, -119, 73, -55, 41, -87, 105, -23, 25, -103, 89, -39, 57, -71, 121, -7, 5, -123, 69, -59, 37, -91, 101, -27, 21, -107, 85, -43, 53, -75, 117, -11, 13, -115, 77, -51, 45, -83, 109, -19, 29, -99, 93, -35, 61, -67, 125, -3, 3, -125, 67, -61, 35, -93, 99, -29, 19, -109, 83, -45, 51, -77, 115, -13, 11, -117, 75, -53, 43, -85, 107, -21, 27, -101, 91, -37, 59, -69, 123, -5, 7, -121, 71, -57, 39, -89, 103, -25, 23, -105, 87, -41, 55, -73, 119, -9, 15, -113, 79, -49, 47, -81, 111, -17, 31, -97, 95, -33, 63, -65, Byte.MAX_VALUE, -1 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  206 */   static short[] white = new short[] { 6430, 6400, 6400, 6400, 3225, 3225, 3225, 3225, 944, 944, 944, 944, 976, 976, 976, 976, 1456, 1456, 1456, 1456, 1488, 1488, 1488, 1488, 718, 718, 718, 718, 718, 718, 718, 718, 750, 750, 750, 750, 750, 750, 750, 750, 1520, 1520, 1520, 1520, 1552, 1552, 1552, 1552, 428, 428, 428, 428, 428, 428, 428, 428, 428, 428, 428, 428, 428, 428, 428, 428, 654, 654, 654, 654, 654, 654, 654, 654, 1072, 1072, 1072, 1072, 1104, 1104, 1104, 1104, 1136, 1136, 1136, 1136, 1168, 1168, 1168, 1168, 1200, 1200, 1200, 1200, 1232, 1232, 1232, 1232, 622, 622, 622, 622, 622, 622, 622, 622, 1008, 1008, 1008, 1008, 1040, 1040, 1040, 1040, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 396, 396, 396, 396, 396, 396, 396, 396, 396, 396, 396, 396, 396, 396, 396, 396, 1712, 1712, 1712, 1712, 1744, 1744, 1744, 1744, 846, 846, 846, 846, 846, 846, 846, 846, 1264, 1264, 1264, 1264, 1296, 1296, 1296, 1296, 1328, 1328, 1328, 1328, 1360, 1360, 1360, 1360, 1392, 1392, 1392, 1392, 1424, 1424, 1424, 1424, 686, 686, 686, 686, 686, 686, 686, 686, 910, 910, 910, 910, 910, 910, 910, 910, 1968, 1968, 1968, 1968, 2000, 2000, 2000, 2000, 2032, 2032, 2032, 2032, 16, 16, 16, 16, 10257, 10257, 10257, 10257, 12305, 12305, 12305, 12305, 330, 330, 330, 330, 330, 330, 330, 330, 330, 330, 330, 330, 330, 330, 330, 330, 330, 330, 330, 330, 330, 330, 330, 330, 330, 330, 330, 330, 330, 330, 330, 330, 362, 362, 362, 362, 362, 362, 362, 362, 362, 362, 362, 362, 362, 362, 362, 362, 362, 362, 362, 362, 362, 362, 362, 362, 362, 362, 362, 362, 362, 362, 362, 362, 878, 878, 878, 878, 878, 878, 878, 878, 1904, 1904, 1904, 1904, 1936, 1936, 1936, 1936, -18413, -18413, -16365, -16365, -14317, -14317, -10221, -10221, 590, 590, 590, 590, 590, 590, 590, 590, 782, 782, 782, 782, 782, 782, 782, 782, 1584, 1584, 1584, 1584, 1616, 1616, 1616, 1616, 1648, 1648, 1648, 1648, 1680, 1680, 1680, 1680, 814, 814, 814, 814, 814, 814, 814, 814, 1776, 1776, 1776, 1776, 1808, 1808, 1808, 1808, 1840, 1840, 1840, 1840, 1872, 1872, 1872, 1872, 6157, 6157, 6157, 6157, 6157, 6157, 6157, 6157, 6157, 6157, 6157, 6157, 6157, 6157, 6157, 6157, -12275, -12275, -12275, -12275, -12275, -12275, -12275, -12275, -12275, -12275, -12275, -12275, -12275, -12275, -12275, -12275, 14353, 14353, 14353, 14353, 16401, 16401, 16401, 16401, 22547, 22547, 24595, 24595, 20497, 20497, 20497, 20497, 18449, 18449, 18449, 18449, 26643, 26643, 28691, 28691, 30739, 30739, -32749, -32749, -30701, -30701, -28653, -28653, -26605, -26605, -24557, -24557, -22509, -22509, -20461, -20461, 8207, 8207, 8207, 8207, 8207, 8207, 8207, 8207, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 104, 104, 104, 104, 104, 104, 104, 104, 104, 104, 104, 104, 104, 104, 104, 104, 104, 104, 104, 104, 104, 104, 104, 104, 104, 104, 104, 104, 104, 104, 104, 104, 104, 104, 104, 104, 104, 104, 104, 104, 104, 104, 104, 104, 104, 104, 104, 104, 104, 104, 104, 104, 104, 104, 104, 104, 104, 104, 104, 104, 104, 104, 104, 104, 4107, 4107, 4107, 4107, 4107, 4107, 4107, 4107, 4107, 4107, 4107, 4107, 4107, 4107, 4107, 4107, 4107, 4107, 4107, 4107, 4107, 4107, 4107, 4107, 4107, 4107, 4107, 4107, 4107, 4107, 4107, 4107, 266, 266, 266, 266, 266, 266, 266, 266, 266, 266, 266, 266, 266, 266, 266, 266, 266, 266, 266, 266, 266, 266, 266, 266, 266, 266, 266, 266, 266, 266, 266, 266, 298, 298, 298, 298, 298, 298, 298, 298, 298, 298, 298, 298, 298, 298, 298, 298, 298, 298, 298, 298, 298, 298, 298, 298, 298, 298, 298, 298, 298, 298, 298, 298, 524, 524, 524, 524, 524, 524, 524, 524, 524, 524, 524, 524, 524, 524, 524, 524, 556, 556, 556, 556, 556, 556, 556, 556, 556, 556, 556, 556, 556, 556, 556, 556, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 168, 168, 168, 168, 168, 168, 168, 168, 168, 168, 168, 168, 168, 168, 168, 168, 168, 168, 168, 168, 168, 168, 168, 168, 168, 168, 168, 168, 168, 168, 168, 168, 168, 168, 168, 168, 168, 168, 168, 168, 168, 168, 168, 168, 168, 168, 168, 168, 168, 168, 168, 168, 168, 168, 168, 168, 168, 168, 168, 168, 168, 168, 168, 168, 460, 460, 460, 460, 460, 460, 460, 460, 460, 460, 460, 460, 460, 460, 460, 460, 492, 492, 492, 492, 492, 492, 492, 492, 492, 492, 492, 492, 492, 492, 492, 492, 2059, 2059, 2059, 2059, 2059, 2059, 2059, 2059, 2059, 2059, 2059, 2059, 2059, 2059, 2059, 2059, 2059, 2059, 2059, 2059, 2059, 2059, 2059, 2059, 2059, 2059, 2059, 2059, 2059, 2059, 2059, 2059, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  466 */   static short[] additionalMakeup = new short[] { 28679, 28679, 31752, -32759, -31735, -30711, -29687, -28663, 29703, 29703, 30727, 30727, -27639, -26615, -25591, -24567 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  474 */   static short[] initBlack = new short[] { 3226, 6412, 200, 168, 38, 38, 134, 134, 100, 100, 100, 100, 68, 68, 68, 68 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  482 */   static short[] twoBitBlack = new short[] { 292, 260, 226, 226 };
/*      */ 
/*      */   
/*  485 */   static short[] black = new short[] { 62, 62, 30, 30, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3225, 3225, 3225, 3225, 3225, 3225, 3225, 3225, 3225, 3225, 3225, 3225, 3225, 3225, 3225, 3225, 3225, 3225, 3225, 3225, 3225, 3225, 3225, 3225, 3225, 3225, 3225, 3225, 3225, 3225, 3225, 3225, 588, 588, 588, 588, 588, 588, 588, 588, 1680, 1680, 20499, 22547, 24595, 26643, 1776, 1776, 1808, 1808, -24557, -22509, -20461, -18413, 1904, 1904, 1936, 1936, -16365, -14317, 782, 782, 782, 782, 814, 814, 814, 814, -12269, -10221, 10257, 10257, 12305, 12305, 14353, 14353, 16403, 18451, 1712, 1712, 1744, 1744, 28691, 30739, -32749, -30701, -28653, -26605, 2061, 2061, 2061, 2061, 2061, 2061, 2061, 2061, 424, 424, 424, 424, 424, 424, 424, 424, 424, 424, 424, 424, 424, 424, 424, 424, 424, 424, 424, 424, 424, 424, 424, 424, 424, 424, 424, 424, 424, 424, 424, 424, 750, 750, 750, 750, 1616, 1616, 1648, 1648, 1424, 1424, 1456, 1456, 1488, 1488, 1520, 1520, 1840, 1840, 1872, 1872, 1968, 1968, 8209, 8209, 524, 524, 524, 524, 524, 524, 524, 524, 556, 556, 556, 556, 556, 556, 556, 556, 1552, 1552, 1584, 1584, 2000, 2000, 2032, 2032, 976, 976, 1008, 1008, 1040, 1040, 1072, 1072, 1296, 1296, 1328, 1328, 718, 718, 718, 718, 456, 456, 456, 456, 456, 456, 456, 456, 456, 456, 456, 456, 456, 456, 456, 456, 456, 456, 456, 456, 456, 456, 456, 456, 456, 456, 456, 456, 456, 456, 456, 456, 326, 326, 326, 326, 326, 326, 326, 326, 326, 326, 326, 326, 326, 326, 326, 326, 326, 326, 326, 326, 326, 326, 326, 326, 326, 326, 326, 326, 326, 326, 326, 326, 326, 326, 326, 326, 326, 326, 326, 326, 326, 326, 326, 326, 326, 326, 326, 326, 326, 326, 326, 326, 326, 326, 326, 326, 326, 326, 326, 326, 326, 326, 326, 326, 358, 358, 358, 358, 358, 358, 358, 358, 358, 358, 358, 358, 358, 358, 358, 358, 358, 358, 358, 358, 358, 358, 358, 358, 358, 358, 358, 358, 358, 358, 358, 358, 358, 358, 358, 358, 358, 358, 358, 358, 358, 358, 358, 358, 358, 358, 358, 358, 358, 358, 358, 358, 358, 358, 358, 358, 358, 358, 358, 358, 358, 358, 358, 358, 490, 490, 490, 490, 490, 490, 490, 490, 490, 490, 490, 490, 490, 490, 490, 490, 4113, 4113, 6161, 6161, 848, 848, 880, 880, 912, 912, 944, 944, 622, 622, 622, 622, 654, 654, 654, 654, 1104, 1104, 1136, 1136, 1168, 1168, 1200, 1200, 1232, 1232, 1264, 1264, 686, 686, 686, 686, 1360, 1360, 1392, 1392, 12, 12, 12, 12, 12, 12, 12, 12, 390, 390, 390, 390, 390, 390, 390, 390, 390, 390, 390, 390, 390, 390, 390, 390, 390, 390, 390, 390, 390, 390, 390, 390, 390, 390, 390, 390, 390, 390, 390, 390, 390, 390, 390, 390, 390, 390, 390, 390, 390, 390, 390, 390, 390, 390, 390, 390, 390, 390, 390, 390, 390, 390, 390, 390, 390, 390, 390, 390, 390, 390, 390, 390 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  616 */   static byte[] twoDCodes = new byte[] { 80, 88, 23, 71, 30, 30, 62, 62, 4, 4, 4, 4, 4, 4, 4, 4, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void beginDecoding() {
/*  658 */     super.beginDecoding();
/*      */     
/*  660 */     if (this.metadata instanceof TIFFImageMetadata) {
/*  661 */       TIFFImageMetadata tmetadata = (TIFFImageMetadata)this.metadata;
/*      */ 
/*      */       
/*  664 */       TIFFField f = tmetadata.getTIFFField(266);
/*  665 */       this.fillOrder = (f == null) ? 1 : f.getAsInt(0);
/*      */       
/*  667 */       f = tmetadata.getTIFFField(259);
/*  668 */       this.compression = (f == null) ? 2 : f.getAsInt(0);
/*      */ 
/*      */       
/*  671 */       f = tmetadata.getTIFFField(292);
/*  672 */       this.t4Options = (f == null) ? 0 : f.getAsInt(0);
/*  673 */       this.oneD = this.t4Options & 0x1;
/*      */       
/*  675 */       this.uncompressedMode = (this.t4Options & 0x2) >> 1;
/*  676 */       this.fillBits = (this.t4Options & 0x4) >> 2;
/*  677 */       f = tmetadata.getTIFFField(293);
/*  678 */       this.t6Options = (f == null) ? 0 : f.getAsInt(0);
/*      */     } else {
/*  680 */       this.fillOrder = 1;
/*      */       
/*  682 */       this.compression = 2;
/*      */       
/*  684 */       this.t4Options = 0;
/*  685 */       this.oneD = 0;
/*  686 */       this.uncompressedMode = 0;
/*  687 */       this.fillBits = 0;
/*  688 */       this.t6Options = 0;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void decodeRaw(byte[] b, int dstOffset, int pixelBitStride, int scanlineStride) throws IOException {
/*  696 */     this.buffer = b;
/*      */     
/*  698 */     this.w = this.srcWidth;
/*  699 */     this.h = this.srcHeight;
/*  700 */     this.bitsPerScanline = scanlineStride * 8;
/*  701 */     this.lineBitNum = 8 * dstOffset;
/*      */     
/*  703 */     this.data = new byte[this.byteCount];
/*  704 */     this.bitPointer = 0;
/*  705 */     this.bytePointer = 0;
/*  706 */     this.prevChangingElems = new int[this.w + 1];
/*  707 */     this.currChangingElems = new int[this.w + 1];
/*      */     
/*  709 */     this.stream.seek(this.offset);
/*  710 */     this.stream.readFully(this.data);
/*      */     
/*      */     try {
/*  713 */       if (this.compression == 2) {
/*  714 */         decodeRLE();
/*  715 */       } else if (this.compression == 3) {
/*  716 */         decodeT4();
/*  717 */       } else if (this.compression == 4) {
/*  718 */         this.uncompressedMode = (this.t6Options & 0x2) >> 1;
/*  719 */         decodeT6();
/*      */       } else {
/*  721 */         throw new IIOException("Unknown compression type " + this.compression);
/*      */       } 
/*  723 */     } catch (ArrayIndexOutOfBoundsException e) {
/*  724 */       ByteArrayOutputStream baos = new ByteArrayOutputStream();
/*  725 */       e.printStackTrace(new PrintStream(baos));
/*  726 */       String s = new String(baos.toByteArray());
/*  727 */       warning("Ignoring exception:\n " + s);
/*      */     } 
/*      */   }
/*      */   
/*      */   public void decodeRLE() throws IIOException {
/*  732 */     for (int i = 0; i < this.h; i++) {
/*      */       
/*  734 */       decodeNextScanline(this.srcMinY + i);
/*      */ 
/*      */       
/*  737 */       if (this.bitPointer != 0) {
/*  738 */         this.bytePointer++;
/*  739 */         this.bitPointer = 0;
/*      */       } 
/*      */ 
/*      */       
/*  743 */       this.lineBitNum += this.bitsPerScanline;
/*      */     } 
/*      */   }
/*      */   
/*      */   public void decodeNextScanline(int lineIndex) throws IIOException {
/*  748 */     int bits = 0, code = 0, isT = 0;
/*      */     
/*  750 */     boolean isWhite = true;
/*  751 */     int dstEnd = 0;
/*      */     
/*  753 */     int bitOffset = 0;
/*      */ 
/*      */     
/*  756 */     this.changingElemSize = 0;
/*      */ 
/*      */     
/*  759 */     while (bitOffset < this.w) {
/*      */ 
/*      */       
/*  762 */       int runOffset = bitOffset;
/*      */       
/*  764 */       while (isWhite && bitOffset < this.w) {
/*      */         
/*  766 */         int current = nextNBits(10);
/*  767 */         int entry = white[current];
/*      */ 
/*      */         
/*  770 */         isT = entry & 0x1;
/*  771 */         bits = entry >>> 1 & 0xF;
/*      */         
/*  773 */         if (bits == 12) {
/*      */           
/*  775 */           int twoBits = nextLesserThan8Bits(2);
/*      */           
/*  777 */           current = current << 2 & 0xC | twoBits;
/*  778 */           entry = additionalMakeup[current];
/*  779 */           bits = entry >>> 1 & 0x7;
/*  780 */           code = entry >>> 4 & 0xFFF;
/*  781 */           bitOffset += code;
/*      */           
/*  783 */           updatePointer(4 - bits); continue;
/*  784 */         }  if (bits == 0) {
/*  785 */           warning("Error 0"); continue;
/*      */         } 
/*  787 */         if (bits == 15) {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  792 */           warning("Premature EOL in white run of line " + lineIndex + ": read " + bitOffset + " of " + this.w + " expected pixels.");
/*      */           
/*      */           return;
/*      */         } 
/*      */         
/*  797 */         code = entry >>> 5 & 0x7FF;
/*  798 */         bitOffset += code;
/*      */         
/*  800 */         updatePointer(10 - bits);
/*  801 */         if (isT == 0) {
/*  802 */           isWhite = false;
/*  803 */           this.currChangingElems[this.changingElemSize++] = bitOffset;
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  809 */       if (bitOffset == this.w) {
/*      */ 
/*      */ 
/*      */         
/*  813 */         int runLength = bitOffset - runOffset;
/*  814 */         if (isWhite && runLength != 0 && runLength % 64 == 0 && nextNBits(8) != 53) {
/*      */ 
/*      */           
/*  817 */           warning("Missing zero white run length terminating code!");
/*  818 */           updatePointer(8);
/*      */         } 
/*      */         
/*      */         break;
/*      */       } 
/*      */       
/*  824 */       runOffset = bitOffset;
/*      */       
/*  826 */       while (!isWhite && bitOffset < this.w) {
/*      */         
/*  828 */         int current = nextLesserThan8Bits(4);
/*  829 */         int entry = initBlack[current];
/*      */ 
/*      */         
/*  832 */         isT = entry & 0x1;
/*  833 */         bits = entry >>> 1 & 0xF;
/*  834 */         code = entry >>> 5 & 0x7FF;
/*      */         
/*  836 */         if (code == 100) {
/*  837 */           current = nextNBits(9);
/*  838 */           entry = black[current];
/*      */ 
/*      */           
/*  841 */           isT = entry & 0x1;
/*  842 */           bits = entry >>> 1 & 0xF;
/*  843 */           code = entry >>> 5 & 0x7FF;
/*      */           
/*  845 */           if (bits == 12) {
/*      */             
/*  847 */             updatePointer(5);
/*  848 */             current = nextLesserThan8Bits(4);
/*  849 */             entry = additionalMakeup[current];
/*  850 */             bits = entry >>> 1 & 0x7;
/*  851 */             code = entry >>> 4 & 0xFFF;
/*      */             
/*  853 */             setToBlack(bitOffset, code);
/*  854 */             bitOffset += code;
/*      */             
/*  856 */             updatePointer(4 - bits); continue;
/*  857 */           }  if (bits == 15) {
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  862 */             warning("Premature EOL in black run of line " + lineIndex + ": read " + bitOffset + " of " + this.w + " expected pixels.");
/*      */             
/*      */             return;
/*      */           } 
/*      */           
/*  867 */           setToBlack(bitOffset, code);
/*  868 */           bitOffset += code;
/*      */           
/*  870 */           updatePointer(9 - bits);
/*  871 */           if (isT == 0) {
/*  872 */             isWhite = true;
/*  873 */             this.currChangingElems[this.changingElemSize++] = bitOffset;
/*      */           }  continue;
/*      */         } 
/*  876 */         if (code == 200) {
/*      */           
/*  878 */           current = nextLesserThan8Bits(2);
/*  879 */           entry = twoBitBlack[current];
/*  880 */           code = entry >>> 5 & 0x7FF;
/*  881 */           bits = entry >>> 1 & 0xF;
/*      */           
/*  883 */           setToBlack(bitOffset, code);
/*  884 */           bitOffset += code;
/*      */           
/*  886 */           updatePointer(2 - bits);
/*  887 */           isWhite = true;
/*  888 */           this.currChangingElems[this.changingElemSize++] = bitOffset;
/*      */           continue;
/*      */         } 
/*  891 */         setToBlack(bitOffset, code);
/*  892 */         bitOffset += code;
/*      */         
/*  894 */         updatePointer(4 - bits);
/*  895 */         isWhite = true;
/*  896 */         this.currChangingElems[this.changingElemSize++] = bitOffset;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  901 */       if (bitOffset == this.w) {
/*      */ 
/*      */ 
/*      */         
/*  905 */         int runLength = bitOffset - runOffset;
/*  906 */         if (!isWhite && runLength != 0 && runLength % 64 == 0 && nextNBits(10) != 55) {
/*      */ 
/*      */           
/*  909 */           warning("Missing zero black run length terminating code!");
/*  910 */           updatePointer(10);
/*      */         } 
/*      */         
/*      */         break;
/*      */       } 
/*      */     } 
/*  916 */     this.currChangingElems[this.changingElemSize++] = bitOffset;
/*      */   }
/*      */   
/*      */   public void decodeT4() throws IIOException {
/*  920 */     int height = this.h;
/*      */ 
/*      */     
/*  923 */     int[] b = new int[2];
/*      */ 
/*      */     
/*  926 */     int currIndex = 0;
/*      */ 
/*      */     
/*  929 */     if (this.data.length < 2) {
/*  930 */       throw new IIOException("Insufficient data to read initial EOL.");
/*      */     }
/*      */ 
/*      */     
/*  934 */     int next12 = nextNBits(12);
/*  935 */     if (next12 != 1) {
/*  936 */       warning("T.4 compressed data should begin with EOL.");
/*      */     }
/*  938 */     updatePointer(12);
/*      */ 
/*      */     
/*  941 */     int modeFlag = 0;
/*  942 */     int lines = -1;
/*  943 */     while (modeFlag != 1) {
/*      */       try {
/*  945 */         modeFlag = findNextLine();
/*  946 */         lines++;
/*  947 */       } catch (EOFException eofe) {
/*  948 */         throw new IIOException("No reference line present.");
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  956 */     decodeNextScanline(this.srcMinY);
/*  957 */     lines++;
/*  958 */     this.lineBitNum += this.bitsPerScanline;
/*      */     
/*  960 */     while (lines < height) {
/*      */ 
/*      */       
/*      */       try {
/*      */         
/*  965 */         modeFlag = findNextLine();
/*  966 */       } catch (EOFException eofe) {
/*  967 */         warning("Input exhausted before EOL found at line " + (this.srcMinY + lines) + ": read 0 of " + this.w + " expected pixels.");
/*      */         
/*      */         break;
/*      */       } 
/*  971 */       if (modeFlag == 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  976 */         int[] temp = this.prevChangingElems;
/*  977 */         this.prevChangingElems = this.currChangingElems;
/*  978 */         this.currChangingElems = temp;
/*  979 */         currIndex = 0;
/*      */ 
/*      */         
/*  982 */         int a0 = -1;
/*  983 */         boolean isWhite = true;
/*  984 */         int bitOffset = 0;
/*      */         
/*  986 */         this.lastChangingElement = 0;
/*      */         
/*  988 */         while (bitOffset < this.w) {
/*      */           
/*  990 */           getNextChangingElement(a0, isWhite, b);
/*      */           
/*  992 */           int b1 = b[0];
/*  993 */           int b2 = b[1];
/*      */ 
/*      */           
/*  996 */           int entry = nextLesserThan8Bits(7);
/*      */ 
/*      */           
/*  999 */           entry = twoDCodes[entry] & 0xFF;
/*      */ 
/*      */           
/* 1002 */           int code = (entry & 0x78) >>> 3;
/* 1003 */           int bits = entry & 0x7;
/*      */           
/* 1005 */           if (code == 0) {
/* 1006 */             if (!isWhite) {
/* 1007 */               setToBlack(bitOffset, b2 - bitOffset);
/*      */             }
/* 1009 */             bitOffset = a0 = b2;
/*      */ 
/*      */             
/* 1012 */             updatePointer(7 - bits); continue;
/* 1013 */           }  if (code == 1) {
/*      */             
/* 1015 */             updatePointer(7 - bits);
/*      */ 
/*      */ 
/*      */             
/* 1019 */             if (isWhite) {
/* 1020 */               int number = decodeWhiteCodeWord();
/* 1021 */               bitOffset += number;
/* 1022 */               this.currChangingElems[currIndex++] = bitOffset;
/*      */               
/* 1024 */               number = decodeBlackCodeWord();
/* 1025 */               setToBlack(bitOffset, number);
/* 1026 */               bitOffset += number;
/* 1027 */               this.currChangingElems[currIndex++] = bitOffset;
/*      */             } else {
/* 1029 */               int number = decodeBlackCodeWord();
/* 1030 */               setToBlack(bitOffset, number);
/* 1031 */               bitOffset += number;
/* 1032 */               this.currChangingElems[currIndex++] = bitOffset;
/*      */               
/* 1034 */               number = decodeWhiteCodeWord();
/* 1035 */               bitOffset += number;
/* 1036 */               this.currChangingElems[currIndex++] = bitOffset;
/*      */             } 
/*      */             
/* 1039 */             a0 = bitOffset; continue;
/* 1040 */           }  if (code <= 8) {
/*      */             
/* 1042 */             int a1 = b1 + code - 5;
/*      */             
/* 1044 */             this.currChangingElems[currIndex++] = a1;
/*      */ 
/*      */ 
/*      */             
/* 1048 */             if (!isWhite) {
/* 1049 */               setToBlack(bitOffset, a1 - bitOffset);
/*      */             }
/* 1051 */             bitOffset = a0 = a1;
/* 1052 */             isWhite = !isWhite;
/*      */             
/* 1054 */             updatePointer(7 - bits); continue;
/*      */           } 
/* 1056 */           warning("Unknown coding mode encountered at line " + (this.srcMinY + lines) + ": read " + bitOffset + " of " + this.w + " expected pixels.");
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1061 */           int numLinesTested = 0;
/* 1062 */           while (modeFlag != 1) {
/*      */             try {
/* 1064 */               modeFlag = findNextLine();
/* 1065 */               numLinesTested++;
/* 1066 */             } catch (EOFException eofe) {
/* 1067 */               warning("Sync loss at line " + (this.srcMinY + lines) + ": read " + lines + " of " + height + " lines.");
/*      */               
/*      */               return;
/*      */             } 
/*      */           } 
/*      */           
/* 1073 */           lines += numLinesTested - 1;
/* 1074 */           updatePointer(13);
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1081 */         this.currChangingElems[currIndex++] = bitOffset;
/* 1082 */         this.changingElemSize = currIndex;
/*      */       } else {
/*      */         
/* 1085 */         decodeNextScanline(this.srcMinY + lines);
/*      */       } 
/*      */       
/* 1088 */       this.lineBitNum += this.bitsPerScanline;
/* 1089 */       lines++;
/*      */     } 
/*      */   }
/*      */   
/*      */   public synchronized void decodeT6() throws IIOException {
/* 1094 */     int height = this.h;
/*      */     
/* 1096 */     int bufferOffset = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1106 */     int[] b = new int[2];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1113 */     int[] cce = this.currChangingElems;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1118 */     this.changingElemSize = 0;
/* 1119 */     cce[this.changingElemSize++] = this.w;
/* 1120 */     cce[this.changingElemSize++] = this.w;
/*      */ 
/*      */ 
/*      */     
/* 1124 */     for (int lines = 0; lines < height; lines++) {
/*      */       
/* 1126 */       int a0 = -1;
/* 1127 */       boolean isWhite = true;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1132 */       int[] temp = this.prevChangingElems;
/* 1133 */       this.prevChangingElems = this.currChangingElems;
/* 1134 */       cce = this.currChangingElems = temp;
/* 1135 */       int currIndex = 0;
/*      */ 
/*      */       
/* 1138 */       int bitOffset = 0;
/*      */ 
/*      */       
/* 1141 */       this.lastChangingElement = 0;
/*      */ 
/*      */       
/* 1144 */       while (bitOffset < this.w) {
/*      */         
/* 1146 */         getNextChangingElement(a0, isWhite, b);
/* 1147 */         int b1 = b[0];
/* 1148 */         int b2 = b[1];
/*      */ 
/*      */         
/* 1151 */         int entry = nextLesserThan8Bits(7);
/*      */         
/* 1153 */         entry = twoDCodes[entry] & 0xFF;
/*      */ 
/*      */         
/* 1156 */         int code = (entry & 0x78) >>> 3;
/* 1157 */         int bits = entry & 0x7;
/*      */         
/* 1159 */         if (code == 0) {
/*      */           
/* 1161 */           if (!isWhite) {
/* 1162 */             if (b2 > this.w) {
/* 1163 */               b2 = this.w;
/* 1164 */               warning("Decoded row " + (this.srcMinY + lines) + " too long; ignoring extra samples.");
/*      */             } 
/*      */             
/* 1167 */             setToBlack(bitOffset, b2 - bitOffset);
/*      */           } 
/* 1169 */           bitOffset = a0 = b2;
/*      */ 
/*      */           
/* 1172 */           updatePointer(7 - bits); continue;
/* 1173 */         }  if (code == 1) {
/*      */           
/* 1175 */           updatePointer(7 - bits);
/*      */ 
/*      */ 
/*      */           
/* 1179 */           if (isWhite) {
/*      */             
/* 1181 */             int number = decodeWhiteCodeWord();
/* 1182 */             bitOffset += number;
/* 1183 */             cce[currIndex++] = bitOffset;
/*      */             
/* 1185 */             number = decodeBlackCodeWord();
/* 1186 */             if (number > this.w - bitOffset) {
/* 1187 */               number = this.w - bitOffset;
/* 1188 */               warning("Decoded row " + (this.srcMinY + lines) + " too long; ignoring extra samples.");
/*      */             } 
/*      */             
/* 1191 */             setToBlack(bitOffset, number);
/* 1192 */             bitOffset += number;
/* 1193 */             cce[currIndex++] = bitOffset;
/*      */           } else {
/*      */             
/* 1196 */             int number = decodeBlackCodeWord();
/* 1197 */             if (number > this.w - bitOffset) {
/* 1198 */               number = this.w - bitOffset;
/* 1199 */               warning("Decoded row " + (this.srcMinY + lines) + " too long; ignoring extra samples.");
/*      */             } 
/*      */             
/* 1202 */             setToBlack(bitOffset, number);
/* 1203 */             bitOffset += number;
/* 1204 */             cce[currIndex++] = bitOffset;
/*      */             
/* 1206 */             number = decodeWhiteCodeWord();
/* 1207 */             bitOffset += number;
/* 1208 */             cce[currIndex++] = bitOffset;
/*      */           } 
/*      */           
/* 1211 */           a0 = bitOffset; continue;
/* 1212 */         }  if (code <= 8) {
/* 1213 */           int a1 = b1 + code - 5;
/* 1214 */           cce[currIndex++] = a1;
/*      */ 
/*      */ 
/*      */           
/* 1218 */           if (!isWhite) {
/* 1219 */             if (a1 > this.w) {
/* 1220 */               a1 = this.w;
/* 1221 */               warning("Decoded row " + (this.srcMinY + lines) + " too long; ignoring extra samples.");
/*      */             } 
/*      */             
/* 1224 */             setToBlack(bitOffset, a1 - bitOffset);
/*      */           } 
/* 1226 */           bitOffset = a0 = a1;
/* 1227 */           isWhite = !isWhite;
/*      */           
/* 1229 */           updatePointer(7 - bits); continue;
/* 1230 */         }  if (code == 11) {
/* 1231 */           int entranceCode = nextLesserThan8Bits(3);
/* 1232 */           if (entranceCode != 7) {
/* 1233 */             String str = "Unsupported entrance code " + entranceCode + " for extension mode at line " + (this.srcMinY + lines) + ".";
/*      */ 
/*      */             
/* 1236 */             warning(str);
/*      */           } 
/*      */           
/* 1239 */           int zeros = 0;
/* 1240 */           boolean exit = false;
/*      */           
/* 1242 */           while (!exit) {
/* 1243 */             while (nextLesserThan8Bits(1) != 1) {
/* 1244 */               zeros++;
/*      */             }
/*      */             
/* 1247 */             if (zeros > 5) {
/*      */ 
/*      */ 
/*      */               
/* 1251 */               zeros -= 6;
/*      */               
/* 1253 */               if (!isWhite && zeros > 0) {
/* 1254 */                 cce[currIndex++] = bitOffset;
/*      */               }
/*      */ 
/*      */               
/* 1258 */               bitOffset += zeros;
/* 1259 */               if (zeros > 0)
/*      */               {
/* 1261 */                 isWhite = true;
/*      */               }
/*      */ 
/*      */ 
/*      */               
/* 1266 */               if (nextLesserThan8Bits(1) == 0) {
/* 1267 */                 if (!isWhite) {
/* 1268 */                   cce[currIndex++] = bitOffset;
/*      */                 }
/* 1270 */                 isWhite = true;
/*      */               } else {
/* 1272 */                 if (isWhite) {
/* 1273 */                   cce[currIndex++] = bitOffset;
/*      */                 }
/* 1275 */                 isWhite = false;
/*      */               } 
/*      */               
/* 1278 */               exit = true;
/*      */             } 
/*      */             
/* 1281 */             if (zeros == 5) {
/* 1282 */               if (!isWhite) {
/* 1283 */                 cce[currIndex++] = bitOffset;
/*      */               }
/* 1285 */               bitOffset += zeros;
/*      */ 
/*      */               
/* 1288 */               isWhite = true; continue;
/*      */             } 
/* 1290 */             bitOffset += zeros;
/*      */             
/* 1292 */             cce[currIndex++] = bitOffset;
/* 1293 */             setToBlack(bitOffset, 1);
/* 1294 */             bitOffset++;
/*      */ 
/*      */             
/* 1297 */             isWhite = false;
/*      */           } 
/*      */           
/*      */           continue;
/*      */         } 
/* 1302 */         String msg = "Unknown coding mode encountered at line " + (this.srcMinY + lines) + ".";
/*      */ 
/*      */         
/* 1305 */         warning(msg);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1311 */       if (currIndex <= this.w) {
/* 1312 */         cce[currIndex++] = bitOffset;
/*      */       }
/*      */       
/* 1315 */       this.changingElemSize = currIndex;
/*      */       
/* 1317 */       this.lineBitNum += this.bitsPerScanline;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void setToBlack(int bitNum, int numBits) {
/* 1323 */     bitNum += this.lineBitNum;
/*      */     
/* 1325 */     int lastBit = bitNum + numBits;
/* 1326 */     int byteNum = bitNum >> 3;
/*      */ 
/*      */     
/* 1329 */     int shift = bitNum & 0x7;
/* 1330 */     if (shift > 0) {
/* 1331 */       int maskVal = 1 << 7 - shift;
/* 1332 */       byte val = this.buffer[byteNum];
/* 1333 */       while (maskVal > 0 && bitNum < lastBit) {
/* 1334 */         val = (byte)(val | maskVal);
/* 1335 */         maskVal >>= 1;
/* 1336 */         bitNum++;
/*      */       } 
/* 1338 */       this.buffer[byteNum] = val;
/*      */     } 
/*      */ 
/*      */     
/* 1342 */     byteNum = bitNum >> 3;
/* 1343 */     while (bitNum < lastBit - 7) {
/* 1344 */       this.buffer[byteNum++] = -1;
/* 1345 */       bitNum += 8;
/*      */     } 
/*      */ 
/*      */     
/* 1349 */     while (bitNum < lastBit) {
/* 1350 */       byteNum = bitNum >> 3;
/* 1351 */       this.buffer[byteNum] = (byte)(this.buffer[byteNum] | 1 << 7 - (bitNum & 0x7));
/* 1352 */       bitNum++;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private int decodeWhiteCodeWord() throws IIOException {
/* 1358 */     int code = -1;
/* 1359 */     int runLength = 0;
/* 1360 */     boolean isWhite = true;
/*      */     
/* 1362 */     while (isWhite) {
/* 1363 */       int current = nextNBits(10);
/* 1364 */       int entry = white[current];
/*      */ 
/*      */       
/* 1367 */       int isT = entry & 0x1;
/* 1368 */       int bits = entry >>> 1 & 0xF;
/*      */       
/* 1370 */       if (bits == 12) {
/*      */         
/* 1372 */         int twoBits = nextLesserThan8Bits(2);
/*      */         
/* 1374 */         current = current << 2 & 0xC | twoBits;
/* 1375 */         entry = additionalMakeup[current];
/* 1376 */         bits = entry >>> 1 & 0x7;
/* 1377 */         code = entry >>> 4 & 0xFFF;
/* 1378 */         runLength += code;
/* 1379 */         updatePointer(4 - bits); continue;
/* 1380 */       }  if (bits == 0)
/* 1381 */         throw new IIOException("Error 0"); 
/* 1382 */       if (bits == 15) {
/* 1383 */         throw new IIOException("Error 1");
/*      */       }
/*      */       
/* 1386 */       code = entry >>> 5 & 0x7FF;
/* 1387 */       runLength += code;
/* 1388 */       updatePointer(10 - bits);
/* 1389 */       if (isT == 0) {
/* 1390 */         isWhite = false;
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 1395 */     return runLength;
/*      */   }
/*      */ 
/*      */   
/*      */   private int decodeBlackCodeWord() throws IIOException {
/* 1400 */     int code = -1;
/* 1401 */     int runLength = 0;
/* 1402 */     boolean isWhite = false;
/*      */     
/* 1404 */     while (!isWhite) {
/* 1405 */       int current = nextLesserThan8Bits(4);
/* 1406 */       int entry = initBlack[current];
/*      */ 
/*      */       
/* 1409 */       int isT = entry & 0x1;
/* 1410 */       int bits = entry >>> 1 & 0xF;
/* 1411 */       code = entry >>> 5 & 0x7FF;
/*      */       
/* 1413 */       if (code == 100) {
/* 1414 */         current = nextNBits(9);
/* 1415 */         entry = black[current];
/*      */ 
/*      */         
/* 1418 */         isT = entry & 0x1;
/* 1419 */         bits = entry >>> 1 & 0xF;
/* 1420 */         code = entry >>> 5 & 0x7FF;
/*      */         
/* 1422 */         if (bits == 12) {
/*      */           
/* 1424 */           updatePointer(5);
/* 1425 */           current = nextLesserThan8Bits(4);
/* 1426 */           entry = additionalMakeup[current];
/* 1427 */           bits = entry >>> 1 & 0x7;
/* 1428 */           code = entry >>> 4 & 0xFFF;
/* 1429 */           runLength += code;
/*      */           
/* 1431 */           updatePointer(4 - bits); continue;
/* 1432 */         }  if (bits == 15)
/*      */         {
/* 1434 */           throw new IIOException("Error 2");
/*      */         }
/* 1436 */         runLength += code;
/* 1437 */         updatePointer(9 - bits);
/* 1438 */         if (isT == 0)
/* 1439 */           isWhite = true; 
/*      */         continue;
/*      */       } 
/* 1442 */       if (code == 200) {
/*      */         
/* 1444 */         current = nextLesserThan8Bits(2);
/* 1445 */         entry = twoBitBlack[current];
/* 1446 */         code = entry >>> 5 & 0x7FF;
/* 1447 */         runLength += code;
/* 1448 */         bits = entry >>> 1 & 0xF;
/* 1449 */         updatePointer(2 - bits);
/* 1450 */         isWhite = true;
/*      */         continue;
/*      */       } 
/* 1453 */       runLength += code;
/* 1454 */       updatePointer(4 - bits);
/* 1455 */       isWhite = true;
/*      */     } 
/*      */ 
/*      */     
/* 1459 */     return runLength;
/*      */   }
/*      */ 
/*      */   
/*      */   private int findNextLine() throws IIOException, EOFException {
/* 1464 */     int bitIndexMax = this.data.length * 8 - 1;
/* 1465 */     int bitIndexMax12 = bitIndexMax - 12;
/* 1466 */     int bitIndex = this.bytePointer * 8 + this.bitPointer;
/*      */ 
/*      */     
/* 1469 */     while (bitIndex <= bitIndexMax12) {
/*      */       
/* 1471 */       int next12Bits = nextNBits(12);
/* 1472 */       bitIndex += 12;
/*      */ 
/*      */ 
/*      */       
/* 1476 */       while (next12Bits != 1 && bitIndex < bitIndexMax) {
/* 1477 */         next12Bits = (next12Bits & 0x7FF) << 1 | nextLesserThan8Bits(1) & 0x1;
/*      */ 
/*      */         
/* 1480 */         bitIndex++;
/*      */       } 
/*      */       
/* 1483 */       if (next12Bits == 1) {
/* 1484 */         if (this.oneD == 1) {
/* 1485 */           if (bitIndex < bitIndexMax)
/*      */           {
/* 1487 */             return nextLesserThan8Bits(1); } 
/*      */           continue;
/*      */         } 
/* 1490 */         return 1;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1496 */     throw new EOFException();
/*      */   }
/*      */ 
/*      */   
/*      */   private void getNextChangingElement(int a0, boolean isWhite, int[] ret) throws IIOException {
/* 1501 */     int[] pce = this.prevChangingElems;
/* 1502 */     int ces = this.changingElemSize;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1507 */     int start = (this.lastChangingElement > 0) ? (this.lastChangingElement - 1) : 0;
/* 1508 */     if (isWhite) {
/* 1509 */       start &= 0xFFFFFFFE;
/*      */     } else {
/* 1511 */       start |= 0x1;
/*      */     } 
/*      */     
/* 1514 */     int i = start;
/* 1515 */     for (; i < ces; i += 2) {
/* 1516 */       int temp = pce[i];
/* 1517 */       if (temp > a0) {
/* 1518 */         this.lastChangingElement = i;
/* 1519 */         ret[0] = temp;
/*      */         
/*      */         break;
/*      */       } 
/*      */     } 
/* 1524 */     if (i + 1 < ces) {
/* 1525 */       ret[1] = pce[i + 1];
/*      */     }
/*      */   }
/*      */   
/*      */   private int nextNBits(int bitsToGet) throws IIOException {
/*      */     byte b, next, next2next;
/* 1531 */     int l = this.data.length - 1;
/* 1532 */     int bp = this.bytePointer;
/*      */     
/* 1534 */     if (this.fillOrder == 1) {
/* 1535 */       b = this.data[bp];
/*      */       
/* 1537 */       if (bp == l) {
/* 1538 */         next = 0;
/* 1539 */         next2next = 0;
/* 1540 */       } else if (bp + 1 == l) {
/* 1541 */         next = this.data[bp + 1];
/* 1542 */         next2next = 0;
/*      */       } else {
/* 1544 */         next = this.data[bp + 1];
/* 1545 */         next2next = this.data[bp + 2];
/*      */       } 
/* 1547 */     } else if (this.fillOrder == 2) {
/* 1548 */       b = flipTable[this.data[bp] & 0xFF];
/*      */       
/* 1550 */       if (bp == l) {
/* 1551 */         next = 0;
/* 1552 */         next2next = 0;
/* 1553 */       } else if (bp + 1 == l) {
/* 1554 */         next = flipTable[this.data[bp + 1] & 0xFF];
/* 1555 */         next2next = 0;
/*      */       } else {
/* 1557 */         next = flipTable[this.data[bp + 1] & 0xFF];
/* 1558 */         next2next = flipTable[this.data[bp + 2] & 0xFF];
/*      */       } 
/*      */     } else {
/* 1561 */       throw new IIOException("Invalid FillOrder");
/*      */     } 
/*      */     
/* 1564 */     int bitsLeft = 8 - this.bitPointer;
/* 1565 */     int bitsFromNextByte = bitsToGet - bitsLeft;
/* 1566 */     int bitsFromNext2NextByte = 0;
/* 1567 */     if (bitsFromNextByte > 8) {
/* 1568 */       bitsFromNext2NextByte = bitsFromNextByte - 8;
/* 1569 */       bitsFromNextByte = 8;
/*      */     } 
/*      */     
/* 1572 */     this.bytePointer++;
/*      */     
/* 1574 */     int i1 = (b & table1[bitsLeft]) << bitsToGet - bitsLeft;
/* 1575 */     int i2 = (next & table2[bitsFromNextByte]) >>> 8 - bitsFromNextByte;
/*      */     
/* 1577 */     int i3 = 0;
/* 1578 */     if (bitsFromNext2NextByte != 0) {
/* 1579 */       i2 <<= bitsFromNext2NextByte;
/* 1580 */       i3 = (next2next & table2[bitsFromNext2NextByte]) >>> 8 - bitsFromNext2NextByte;
/*      */       
/* 1582 */       i2 |= i3;
/* 1583 */       this.bytePointer++;
/* 1584 */       this.bitPointer = bitsFromNext2NextByte;
/*      */     }
/* 1586 */     else if (bitsFromNextByte == 8) {
/* 1587 */       this.bitPointer = 0;
/* 1588 */       this.bytePointer++;
/*      */     } else {
/* 1590 */       this.bitPointer = bitsFromNextByte;
/*      */     } 
/*      */ 
/*      */     
/* 1594 */     int i = i1 | i2;
/* 1595 */     return i;
/*      */   }
/*      */   
/*      */   private int nextLesserThan8Bits(int bitsToGet) throws IIOException {
/*      */     byte b, next;
/* 1600 */     int i1, l = this.data.length - 1;
/* 1601 */     int bp = this.bytePointer;
/*      */     
/* 1603 */     if (this.fillOrder == 1) {
/* 1604 */       b = this.data[bp];
/* 1605 */       if (bp == l) {
/* 1606 */         next = 0;
/*      */       } else {
/* 1608 */         next = this.data[bp + 1];
/*      */       } 
/* 1610 */     } else if (this.fillOrder == 2) {
/* 1611 */       b = flipTable[this.data[bp] & 0xFF];
/* 1612 */       if (bp == l) {
/* 1613 */         next = 0;
/*      */       } else {
/* 1615 */         next = flipTable[this.data[bp + 1] & 0xFF];
/*      */       } 
/*      */     } else {
/* 1618 */       throw new IIOException("Invalid FillOrder");
/*      */     } 
/*      */     
/* 1621 */     int bitsLeft = 8 - this.bitPointer;
/* 1622 */     int bitsFromNextByte = bitsToGet - bitsLeft;
/*      */     
/* 1624 */     int shift = bitsLeft - bitsToGet;
/*      */     
/* 1626 */     if (shift >= 0) {
/* 1627 */       i1 = (b & table1[bitsLeft]) >>> shift;
/* 1628 */       this.bitPointer += bitsToGet;
/* 1629 */       if (this.bitPointer == 8) {
/* 1630 */         this.bitPointer = 0;
/* 1631 */         this.bytePointer++;
/*      */       } 
/*      */     } else {
/* 1634 */       i1 = (b & table1[bitsLeft]) << -shift;
/* 1635 */       int i2 = (next & table2[bitsFromNextByte]) >>> 8 - bitsFromNextByte;
/*      */       
/* 1637 */       i1 |= i2;
/* 1638 */       this.bytePointer++;
/* 1639 */       this.bitPointer = bitsFromNextByte;
/*      */     } 
/*      */     
/* 1642 */     return i1;
/*      */   }
/*      */ 
/*      */   
/*      */   private void updatePointer(int bitsToMoveBack) {
/* 1647 */     if (bitsToMoveBack > 8) {
/* 1648 */       this.bytePointer -= bitsToMoveBack / 8;
/* 1649 */       bitsToMoveBack %= 8;
/*      */     } 
/*      */     
/* 1652 */     int i = this.bitPointer - bitsToMoveBack;
/* 1653 */     if (i < 0) {
/* 1654 */       this.bytePointer--;
/* 1655 */       this.bitPointer = 8 + i;
/*      */     } else {
/* 1657 */       this.bitPointer = i;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void warning(String msg) {
/* 1663 */     if (this.reader instanceof TIFFImageReader)
/* 1664 */       ((TIFFImageReader)this.reader).forwardWarningMessage(msg); 
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/tiff/TIFFFaxDecompressor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */