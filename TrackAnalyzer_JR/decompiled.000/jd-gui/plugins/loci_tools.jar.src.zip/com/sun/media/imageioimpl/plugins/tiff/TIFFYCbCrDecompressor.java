/*     */ package com.sun.media.imageioimpl.plugins.tiff;
/*     */ 
/*     */ import com.sun.media.imageio.plugins.tiff.TIFFDecompressor;
/*     */ import com.sun.media.imageio.plugins.tiff.TIFFField;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.ColorModel;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import javax.imageio.ImageReader;
/*     */ import javax.imageio.metadata.IIOMetadata;
/*     */ import javax.imageio.stream.ImageInputStream;
/*     */ import javax.imageio.stream.MemoryCacheImageInputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TIFFYCbCrDecompressor
/*     */   extends TIFFDecompressor
/*     */ {
/*     */   private static final boolean debug = false;
/*     */   private static final int FRAC_BITS = 16;
/*     */   private static final float FRAC_SCALE = 65536.0F;
/* 106 */   private float LumaRed = 0.299F;
/* 107 */   private float LumaGreen = 0.587F;
/* 108 */   private float LumaBlue = 0.114F;
/*     */   
/* 110 */   private float referenceBlackY = 0.0F;
/* 111 */   private float referenceWhiteY = 255.0F;
/*     */   
/* 113 */   private float referenceBlackCb = 128.0F;
/* 114 */   private float referenceWhiteCb = 255.0F;
/*     */   
/* 116 */   private float referenceBlackCr = 128.0F;
/* 117 */   private float referenceWhiteCr = 255.0F;
/*     */   
/* 119 */   private float codingRangeY = 255.0F;
/*     */   
/* 121 */   private int[] iYTab = new int[256];
/* 122 */   private int[] iCbTab = new int[256];
/* 123 */   private int[] iCrTab = new int[256];
/*     */   
/* 125 */   private int[] iGYTab = new int[256];
/* 126 */   private int[] iGCbTab = new int[256];
/* 127 */   private int[] iGCrTab = new int[256];
/*     */   
/* 129 */   private int chromaSubsampleH = 2;
/* 130 */   private int chromaSubsampleV = 2;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean colorConvert;
/*     */ 
/*     */ 
/*     */   
/*     */   private TIFFDecompressor decompressor;
/*     */ 
/*     */   
/*     */   private BufferedImage tmpImage;
/*     */ 
/*     */ 
/*     */   
/*     */   public TIFFYCbCrDecompressor(TIFFDecompressor decompressor, boolean colorConvert) {
/* 146 */     this.decompressor = decompressor;
/* 147 */     this.colorConvert = colorConvert;
/*     */   }
/*     */   
/*     */   private void warning(String message) {
/* 151 */     if (this.reader instanceof TIFFImageReader) {
/* 152 */       ((TIFFImageReader)this.reader).forwardWarningMessage(message);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setReader(ImageReader reader) {
/* 161 */     if (this.decompressor != null) {
/* 162 */       this.decompressor.setReader(reader);
/*     */     }
/* 164 */     super.setReader(reader);
/*     */   }
/*     */   
/*     */   public void setMetadata(IIOMetadata metadata) {
/* 168 */     if (this.decompressor != null) {
/* 169 */       this.decompressor.setMetadata(metadata);
/*     */     }
/* 171 */     super.setMetadata(metadata);
/*     */   }
/*     */   
/*     */   public void setPhotometricInterpretation(int photometricInterpretation) {
/* 175 */     if (this.decompressor != null) {
/* 176 */       this.decompressor.setPhotometricInterpretation(photometricInterpretation);
/*     */     }
/* 178 */     super.setPhotometricInterpretation(photometricInterpretation);
/*     */   }
/*     */   
/*     */   public void setCompression(int compression) {
/* 182 */     if (this.decompressor != null) {
/* 183 */       this.decompressor.setCompression(compression);
/*     */     }
/* 185 */     super.setCompression(compression);
/*     */   }
/*     */   
/*     */   public void setPlanar(boolean planar) {
/* 189 */     if (this.decompressor != null) {
/* 190 */       this.decompressor.setPlanar(planar);
/*     */     }
/* 192 */     super.setPlanar(planar);
/*     */   }
/*     */   
/*     */   public void setSamplesPerPixel(int samplesPerPixel) {
/* 196 */     if (this.decompressor != null) {
/* 197 */       this.decompressor.setSamplesPerPixel(samplesPerPixel);
/*     */     }
/* 199 */     super.setSamplesPerPixel(samplesPerPixel);
/*     */   }
/*     */   
/*     */   public void setBitsPerSample(int[] bitsPerSample) {
/* 203 */     if (this.decompressor != null) {
/* 204 */       this.decompressor.setBitsPerSample(bitsPerSample);
/*     */     }
/* 206 */     super.setBitsPerSample(bitsPerSample);
/*     */   }
/*     */   
/*     */   public void setSampleFormat(int[] sampleFormat) {
/* 210 */     if (this.decompressor != null) {
/* 211 */       this.decompressor.setSampleFormat(sampleFormat);
/*     */     }
/* 213 */     super.setSampleFormat(sampleFormat);
/*     */   }
/*     */   
/*     */   public void setExtraSamples(int[] extraSamples) {
/* 217 */     if (this.decompressor != null) {
/* 218 */       this.decompressor.setExtraSamples(extraSamples);
/*     */     }
/* 220 */     super.setExtraSamples(extraSamples);
/*     */   }
/*     */   
/*     */   public void setColorMap(char[] colorMap) {
/* 224 */     if (this.decompressor != null) {
/* 225 */       this.decompressor.setColorMap(colorMap);
/*     */     }
/* 227 */     super.setColorMap(colorMap);
/*     */   }
/*     */   
/*     */   public void setStream(ImageInputStream stream) {
/* 231 */     if (this.decompressor != null) {
/* 232 */       this.decompressor.setStream(stream);
/*     */     } else {
/* 234 */       super.setStream(stream);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setOffset(long offset) {
/* 239 */     if (this.decompressor != null) {
/* 240 */       this.decompressor.setOffset(offset);
/*     */     }
/* 242 */     super.setOffset(offset);
/*     */   }
/*     */   
/*     */   public void setByteCount(int byteCount) {
/* 246 */     if (this.decompressor != null) {
/* 247 */       this.decompressor.setByteCount(byteCount);
/*     */     }
/* 249 */     super.setByteCount(byteCount);
/*     */   }
/*     */   
/*     */   public void setSrcMinX(int srcMinX) {
/* 253 */     if (this.decompressor != null) {
/* 254 */       this.decompressor.setSrcMinX(srcMinX);
/*     */     }
/* 256 */     super.setSrcMinX(srcMinX);
/*     */   }
/*     */   
/*     */   public void setSrcMinY(int srcMinY) {
/* 260 */     if (this.decompressor != null) {
/* 261 */       this.decompressor.setSrcMinY(srcMinY);
/*     */     }
/* 263 */     super.setSrcMinY(srcMinY);
/*     */   }
/*     */   
/*     */   public void setSrcWidth(int srcWidth) {
/* 267 */     if (this.decompressor != null) {
/* 268 */       this.decompressor.setSrcWidth(srcWidth);
/*     */     }
/* 270 */     super.setSrcWidth(srcWidth);
/*     */   }
/*     */   
/*     */   public void setSrcHeight(int srcHeight) {
/* 274 */     if (this.decompressor != null) {
/* 275 */       this.decompressor.setSrcHeight(srcHeight);
/*     */     }
/* 277 */     super.setSrcHeight(srcHeight);
/*     */   }
/*     */   
/*     */   public void setSourceXOffset(int sourceXOffset) {
/* 281 */     if (this.decompressor != null) {
/* 282 */       this.decompressor.setSourceXOffset(sourceXOffset);
/*     */     }
/* 284 */     super.setSourceXOffset(sourceXOffset);
/*     */   }
/*     */   
/*     */   public void setDstXOffset(int dstXOffset) {
/* 288 */     if (this.decompressor != null) {
/* 289 */       this.decompressor.setDstXOffset(dstXOffset);
/*     */     }
/* 291 */     super.setDstXOffset(dstXOffset);
/*     */   }
/*     */   
/*     */   public void setSourceYOffset(int sourceYOffset) {
/* 295 */     if (this.decompressor != null) {
/* 296 */       this.decompressor.setSourceYOffset(sourceYOffset);
/*     */     }
/* 298 */     super.setSourceYOffset(sourceYOffset);
/*     */   }
/*     */   
/*     */   public void setDstYOffset(int dstYOffset) {
/* 302 */     if (this.decompressor != null) {
/* 303 */       this.decompressor.setDstYOffset(dstYOffset);
/*     */     }
/* 305 */     super.setDstYOffset(dstYOffset);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSourceBands(int[] sourceBands) {
/* 326 */     if (this.decompressor != null) {
/* 327 */       this.decompressor.setSourceBands(sourceBands);
/*     */     }
/* 329 */     super.setSourceBands(sourceBands);
/*     */   }
/*     */   
/*     */   public void setDestinationBands(int[] destinationBands) {
/* 333 */     if (this.decompressor != null) {
/* 334 */       this.decompressor.setDestinationBands(destinationBands);
/*     */     }
/* 336 */     super.setDestinationBands(destinationBands);
/*     */   }
/*     */   
/*     */   public void setImage(BufferedImage image) {
/* 340 */     if (this.decompressor != null) {
/* 341 */       ColorModel cm = image.getColorModel();
/* 342 */       this.tmpImage = new BufferedImage(cm, image.getRaster().createCompatibleWritableRaster(1, 1), cm.isAlphaPremultiplied(), null);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 347 */       this.decompressor.setImage(this.tmpImage);
/*     */     } 
/* 349 */     super.setImage(image);
/*     */   }
/*     */   
/*     */   public void setDstMinX(int dstMinX) {
/* 353 */     if (this.decompressor != null) {
/* 354 */       this.decompressor.setDstMinX(dstMinX);
/*     */     }
/* 356 */     super.setDstMinX(dstMinX);
/*     */   }
/*     */   
/*     */   public void setDstMinY(int dstMinY) {
/* 360 */     if (this.decompressor != null) {
/* 361 */       this.decompressor.setDstMinY(dstMinY);
/*     */     }
/* 363 */     super.setDstMinY(dstMinY);
/*     */   }
/*     */   
/*     */   public void setDstWidth(int dstWidth) {
/* 367 */     if (this.decompressor != null) {
/* 368 */       this.decompressor.setDstWidth(dstWidth);
/*     */     }
/* 370 */     super.setDstWidth(dstWidth);
/*     */   }
/*     */   
/*     */   public void setDstHeight(int dstHeight) {
/* 374 */     if (this.decompressor != null) {
/* 375 */       this.decompressor.setDstHeight(dstHeight);
/*     */     }
/* 377 */     super.setDstHeight(dstHeight);
/*     */   }
/*     */   
/*     */   public void setActiveSrcMinX(int activeSrcMinX) {
/* 381 */     if (this.decompressor != null) {
/* 382 */       this.decompressor.setActiveSrcMinX(activeSrcMinX);
/*     */     }
/* 384 */     super.setActiveSrcMinX(activeSrcMinX);
/*     */   }
/*     */   
/*     */   public void setActiveSrcMinY(int activeSrcMinY) {
/* 388 */     if (this.decompressor != null) {
/* 389 */       this.decompressor.setActiveSrcMinY(activeSrcMinY);
/*     */     }
/* 391 */     super.setActiveSrcMinY(activeSrcMinY);
/*     */   }
/*     */   
/*     */   public void setActiveSrcWidth(int activeSrcWidth) {
/* 395 */     if (this.decompressor != null) {
/* 396 */       this.decompressor.setActiveSrcWidth(activeSrcWidth);
/*     */     }
/* 398 */     super.setActiveSrcWidth(activeSrcWidth);
/*     */   }
/*     */   
/*     */   public void setActiveSrcHeight(int activeSrcHeight) {
/* 402 */     if (this.decompressor != null) {
/* 403 */       this.decompressor.setActiveSrcHeight(activeSrcHeight);
/*     */     }
/* 405 */     super.setActiveSrcHeight(activeSrcHeight);
/*     */   }
/*     */   
/*     */   private byte clamp(int f) {
/* 409 */     if (f < 0)
/* 410 */       return 0; 
/* 411 */     if (f > 16711680) {
/* 412 */       return -1;
/*     */     }
/* 414 */     return (byte)(f >> 16);
/*     */   }
/*     */ 
/*     */   
/*     */   public void beginDecoding() {
/* 419 */     if (this.decompressor != null) {
/* 420 */       this.decompressor.beginDecoding();
/*     */     }
/*     */     
/* 423 */     TIFFImageMetadata tmetadata = (TIFFImageMetadata)this.metadata;
/*     */ 
/*     */     
/* 426 */     TIFFField f = tmetadata.getTIFFField(530);
/* 427 */     if (f != null) {
/* 428 */       if (f.getCount() == 2) {
/* 429 */         this.chromaSubsampleH = f.getAsInt(0);
/* 430 */         this.chromaSubsampleV = f.getAsInt(1);
/*     */         
/* 432 */         if (this.chromaSubsampleH != 1 && this.chromaSubsampleH != 2 && this.chromaSubsampleH != 4) {
/*     */           
/* 434 */           warning("Y_CB_CR_SUBSAMPLING[0] has illegal value " + this.chromaSubsampleH + " (should be 1, 2, or 4), setting to 1");
/*     */ 
/*     */           
/* 437 */           this.chromaSubsampleH = 1;
/*     */         } 
/*     */         
/* 440 */         if (this.chromaSubsampleV != 1 && this.chromaSubsampleV != 2 && this.chromaSubsampleV != 4) {
/*     */           
/* 442 */           warning("Y_CB_CR_SUBSAMPLING[1] has illegal value " + this.chromaSubsampleV + " (should be 1, 2, or 4), setting to 1");
/*     */ 
/*     */           
/* 445 */           this.chromaSubsampleV = 1;
/*     */         } 
/*     */       } else {
/* 448 */         warning("Y_CB_CR_SUBSAMPLING count != 2, assuming no subsampling");
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 453 */     f = tmetadata.getTIFFField(529);
/*     */     
/* 455 */     if (f != null) {
/* 456 */       if (f.getCount() == 3) {
/* 457 */         this.LumaRed = f.getAsFloat(0);
/* 458 */         this.LumaGreen = f.getAsFloat(1);
/* 459 */         this.LumaBlue = f.getAsFloat(2);
/*     */       } else {
/* 461 */         warning("Y_CB_CR_COEFFICIENTS count != 3, assuming default values for CCIR 601-1");
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 466 */     f = tmetadata.getTIFFField(532);
/*     */     
/* 468 */     if (f != null) {
/* 469 */       if (f.getCount() == 6) {
/* 470 */         this.referenceBlackY = f.getAsFloat(0);
/* 471 */         this.referenceWhiteY = f.getAsFloat(1);
/* 472 */         this.referenceBlackCb = f.getAsFloat(2);
/* 473 */         this.referenceWhiteCb = f.getAsFloat(3);
/* 474 */         this.referenceBlackCr = f.getAsFloat(4);
/* 475 */         this.referenceWhiteCr = f.getAsFloat(5);
/*     */       } else {
/* 477 */         warning("REFERENCE_BLACK_WHITE count != 6, ignoring it");
/*     */       } 
/*     */     } else {
/* 480 */       warning("REFERENCE_BLACK_WHITE not found, assuming 0-255/128-255/128-255");
/*     */     } 
/*     */     
/* 483 */     this.colorConvert = true;
/*     */     
/* 485 */     float BCb = 2.0F - 2.0F * this.LumaBlue;
/* 486 */     float RCr = 2.0F - 2.0F * this.LumaRed;
/*     */     
/* 488 */     float GY = (1.0F - this.LumaBlue - this.LumaRed) / this.LumaGreen;
/* 489 */     float GCb = 2.0F * this.LumaBlue * (this.LumaBlue - 1.0F) / this.LumaGreen;
/* 490 */     float GCr = 2.0F * this.LumaRed * (this.LumaRed - 1.0F) / this.LumaGreen;
/*     */     
/* 492 */     for (int i = 0; i < 256; i++) {
/* 493 */       float fY = (i - this.referenceBlackY) * this.codingRangeY / (this.referenceWhiteY - this.referenceBlackY);
/*     */       
/* 495 */       float fCb = (i - this.referenceBlackCb) * 127.0F / (this.referenceWhiteCb - this.referenceBlackCb);
/*     */       
/* 497 */       float fCr = (i - this.referenceBlackCr) * 127.0F / (this.referenceWhiteCr - this.referenceBlackCr);
/*     */ 
/*     */       
/* 500 */       this.iYTab[i] = (int)(fY * 65536.0F);
/* 501 */       this.iCbTab[i] = (int)(fCb * BCb * 65536.0F);
/* 502 */       this.iCrTab[i] = (int)(fCr * RCr * 65536.0F);
/*     */       
/* 504 */       this.iGYTab[i] = (int)(fY * GY * 65536.0F);
/* 505 */       this.iGCbTab[i] = (int)(fCb * GCb * 65536.0F);
/* 506 */       this.iGCrTab[i] = (int)(fCr * GCr * 65536.0F);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void decodeRaw(byte[] buf, int dstOffset, int bitsPerPixel, int scanlineStride) throws IOException {
/* 514 */     byte[] rows = new byte[3 * this.srcWidth * this.chromaSubsampleV];
/*     */     
/* 516 */     int elementsPerPacket = this.chromaSubsampleH * this.chromaSubsampleV + 2;
/* 517 */     byte[] packet = new byte[elementsPerPacket];
/*     */     
/* 519 */     if (this.decompressor != null) {
/* 520 */       int bytesPerRow = 3 * this.srcWidth;
/* 521 */       byte[] tmpBuf = new byte[bytesPerRow * this.srcHeight];
/* 522 */       this.decompressor.decodeRaw(tmpBuf, dstOffset, bitsPerPixel, bytesPerRow);
/*     */       
/* 524 */       ByteArrayInputStream byteStream = new ByteArrayInputStream(tmpBuf);
/*     */       
/* 526 */       this.stream = new MemoryCacheImageInputStream(byteStream);
/*     */     } else {
/* 528 */       this.stream.seek(this.offset);
/*     */     } 
/*     */     int y;
/* 531 */     for (y = this.srcMinY; y < this.srcMinY + this.srcHeight; y += this.chromaSubsampleV) {
/*     */       int x;
/* 533 */       for (x = this.srcMinX; x < this.srcMinX + this.srcWidth; 
/* 534 */         x += this.chromaSubsampleH) {
/*     */         try {
/* 536 */           this.stream.readFully(packet);
/* 537 */         } catch (EOFException e) {
/* 538 */           System.out.println("e = " + e);
/*     */           
/*     */           return;
/*     */         } 
/* 542 */         byte Cb = packet[elementsPerPacket - 2];
/* 543 */         byte Cr = packet[elementsPerPacket - 1];
/*     */         
/* 545 */         int iCb = 0, iCr = 0, iGCb = 0, iGCr = 0;
/*     */         
/* 547 */         if (this.colorConvert) {
/* 548 */           int Cbp = Cb & 0xFF;
/* 549 */           int Crp = Cr & 0xFF;
/*     */           
/* 551 */           iCb = this.iCbTab[Cbp];
/* 552 */           iCr = this.iCrTab[Crp];
/*     */           
/* 554 */           iGCb = this.iGCbTab[Cbp];
/* 555 */           iGCr = this.iGCrTab[Crp];
/*     */         } 
/*     */         
/* 558 */         int yIndex = 0;
/* 559 */         for (int v = 0; v < this.chromaSubsampleV; v++) {
/* 560 */           int idx = dstOffset + 3 * (x - this.srcMinX) + scanlineStride * (y - this.srcMinY + v);
/*     */ 
/*     */ 
/*     */           
/* 564 */           if (y + v >= this.srcMinY + this.srcHeight) {
/*     */             break;
/*     */           }
/*     */           
/* 568 */           for (int h = 0; h < this.chromaSubsampleH && 
/* 569 */             x + h < this.srcMinX + this.srcWidth; h++) {
/*     */ 
/*     */ 
/*     */             
/* 573 */             byte Y = packet[yIndex++];
/*     */             
/* 575 */             if (this.colorConvert) {
/* 576 */               int Yp = Y & 0xFF;
/* 577 */               int iY = this.iYTab[Yp];
/* 578 */               int iGY = this.iGYTab[Yp];
/*     */               
/* 580 */               int iR = iY + iCr;
/* 581 */               int iG = iGY + iGCb + iGCr;
/* 582 */               int iB = iY + iCb;
/*     */               
/* 584 */               byte r = clamp(iR);
/* 585 */               byte g = clamp(iG);
/* 586 */               byte b = clamp(iB);
/*     */               
/* 588 */               buf[idx] = r;
/* 589 */               buf[idx + 1] = g;
/* 590 */               buf[idx + 2] = b;
/*     */             } else {
/* 592 */               buf[idx] = Y;
/* 593 */               buf[idx + 1] = Cb;
/* 594 */               buf[idx + 2] = Cr;
/*     */             } 
/*     */             
/* 597 */             idx += 3;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/tiff/TIFFYCbCrDecompressor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */