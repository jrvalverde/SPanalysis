/*     */ package com.sun.media.imageioimpl.plugins.bmp;
/*     */ 
/*     */ import javax.imageio.ImageTypeSpecifier;
/*     */ import javax.imageio.metadata.IIOMetadataFormat;
/*     */ import javax.imageio.metadata.IIOMetadataFormatImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BMPMetadataFormat
/*     */   extends IIOMetadataFormatImpl
/*     */ {
/*  90 */   private static IIOMetadataFormat instance = null;
/*     */   
/*     */   private BMPMetadataFormat() {
/*  93 */     super("com_sun_media_imageio_plugins_bmp_image_1.0", 2);
/*     */ 
/*     */ 
/*     */     
/*  97 */     addElement("ImageDescriptor", "com_sun_media_imageio_plugins_bmp_image_1.0", 0);
/*     */ 
/*     */     
/* 100 */     addAttribute("ImageDescriptor", "bmpVersion", 0, true, null);
/*     */     
/* 102 */     addAttribute("ImageDescriptor", "width", 2, true, null, "0", "65535", true, true);
/*     */ 
/*     */     
/* 105 */     addAttribute("ImageDescriptor", "height", 2, true, null, "1", "65535", true, true);
/*     */ 
/*     */     
/* 108 */     addAttribute("ImageDescriptor", "bitsPerPixel", 2, true, null, "1", "65535", true, true);
/*     */ 
/*     */     
/* 111 */     addAttribute("ImageDescriptor", "compression", 2, false, null);
/*     */     
/* 113 */     addAttribute("ImageDescriptor", "imageSize", 2, true, null, "1", "65535", true, true);
/*     */ 
/*     */ 
/*     */     
/* 117 */     addElement("PixelsPerMeter", "com_sun_media_imageio_plugins_bmp_image_1.0", 0);
/*     */ 
/*     */     
/* 120 */     addAttribute("PixelsPerMeter", "X", 2, false, null, "1", "65535", true, true);
/*     */ 
/*     */     
/* 123 */     addAttribute("PixelsPerMeter", "Y", 2, false, null, "1", "65535", true, true);
/*     */ 
/*     */ 
/*     */     
/* 127 */     addElement("ColorsUsed", "com_sun_media_imageio_plugins_bmp_image_1.0", 0);
/*     */ 
/*     */     
/* 130 */     addAttribute("ColorsUsed", "value", 2, true, null, "0", "65535", true, true);
/*     */ 
/*     */ 
/*     */     
/* 134 */     addElement("ColorsImportant", "com_sun_media_imageio_plugins_bmp_image_1.0", 0);
/*     */ 
/*     */     
/* 137 */     addAttribute("ColorsImportant", "value", 2, false, null, "0", "65535", true, true);
/*     */ 
/*     */ 
/*     */     
/* 141 */     addElement("BI_BITFIELDS_Mask", "com_sun_media_imageio_plugins_bmp_image_1.0", 0);
/*     */ 
/*     */     
/* 144 */     addAttribute("BI_BITFIELDS_Mask", "red", 2, false, null, "0", "65535", true, true);
/*     */ 
/*     */     
/* 147 */     addAttribute("BI_BITFIELDS_Mask", "green", 2, false, null, "0", "65535", true, true);
/*     */ 
/*     */     
/* 150 */     addAttribute("BI_BITFIELDS_Mask", "blue", 2, false, null, "0", "65535", true, true);
/*     */ 
/*     */ 
/*     */     
/* 154 */     addElement("ColorSpace", "com_sun_media_imageio_plugins_bmp_image_1.0", 0);
/*     */ 
/*     */     
/* 157 */     addAttribute("ColorSpace", "value", 2, false, null, "0", "65535", true, true);
/*     */ 
/*     */ 
/*     */     
/* 161 */     addElement("LCS_CALIBRATED_RGB", "com_sun_media_imageio_plugins_bmp_image_1.0", 0);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 166 */     addAttribute("LCS_CALIBRATED_RGB", "redX", 4, false, null, "0", "65535", true, true);
/*     */ 
/*     */     
/* 169 */     addAttribute("LCS_CALIBRATED_RGB", "redY", 4, false, null, "0", "65535", true, true);
/*     */ 
/*     */     
/* 172 */     addAttribute("LCS_CALIBRATED_RGB", "redZ", 4, false, null, "0", "65535", true, true);
/*     */ 
/*     */     
/* 175 */     addAttribute("LCS_CALIBRATED_RGB", "greenX", 4, false, null, "0", "65535", true, true);
/*     */ 
/*     */     
/* 178 */     addAttribute("LCS_CALIBRATED_RGB", "greenY", 4, false, null, "0", "65535", true, true);
/*     */ 
/*     */     
/* 181 */     addAttribute("LCS_CALIBRATED_RGB", "greenZ", 4, false, null, "0", "65535", true, true);
/*     */ 
/*     */     
/* 184 */     addAttribute("LCS_CALIBRATED_RGB", "blueX", 4, false, null, "0", "65535", true, true);
/*     */ 
/*     */     
/* 187 */     addAttribute("LCS_CALIBRATED_RGB", "blueY", 4, false, null, "0", "65535", true, true);
/*     */ 
/*     */     
/* 190 */     addAttribute("LCS_CALIBRATED_RGB", "blueZ", 4, false, null, "0", "65535", true, true);
/*     */ 
/*     */ 
/*     */     
/* 194 */     addElement("LCS_CALIBRATED_RGB_GAMMA", "com_sun_media_imageio_plugins_bmp_image_1.0", 0);
/*     */ 
/*     */     
/* 197 */     addAttribute("LCS_CALIBRATED_RGB_GAMMA", "red", 2, false, null, "0", "65535", true, true);
/*     */ 
/*     */     
/* 200 */     addAttribute("LCS_CALIBRATED_RGB_GAMMA", "green", 2, false, null, "0", "65535", true, true);
/*     */ 
/*     */     
/* 203 */     addAttribute("LCS_CALIBRATED_RGB_GAMMA", "blue", 2, false, null, "0", "65535", true, true);
/*     */ 
/*     */ 
/*     */     
/* 207 */     addElement("Intent", "com_sun_media_imageio_plugins_bmp_image_1.0", 0);
/*     */ 
/*     */     
/* 210 */     addAttribute("Intent", "value", 2, false, null, "0", "65535", true, true);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 215 */     addElement("Palette", "com_sun_media_imageio_plugins_bmp_image_1.0", 2, 256);
/*     */ 
/*     */     
/* 218 */     addAttribute("Palette", "sizeOfPalette", 2, true, null);
/*     */     
/* 220 */     addBooleanAttribute("Palette", "sortFlag", false, false);
/*     */ 
/*     */ 
/*     */     
/* 224 */     addElement("PaletteEntry", "Palette", 0);
/*     */     
/* 226 */     addAttribute("PaletteEntry", "index", 2, true, null, "0", "255", true, true);
/*     */ 
/*     */     
/* 229 */     addAttribute("PaletteEntry", "red", 2, true, null, "0", "255", true, true);
/*     */ 
/*     */     
/* 232 */     addAttribute("PaletteEntry", "green", 2, true, null, "0", "255", true, true);
/*     */ 
/*     */     
/* 235 */     addAttribute("PaletteEntry", "blue", 2, true, null, "0", "255", true, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 241 */     addElement("CommentExtensions", "com_sun_media_imageio_plugins_bmp_image_1.0", 1, 2147483647);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 246 */     addElement("CommentExtension", "CommentExtensions", 0);
/*     */     
/* 248 */     addAttribute("CommentExtension", "value", 0, true, null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canNodeAppear(String elementName, ImageTypeSpecifier imageType) {
/* 254 */     return true;
/*     */   }
/*     */   
/*     */   public static synchronized IIOMetadataFormat getInstance() {
/* 258 */     if (instance == null) {
/* 259 */       instance = new BMPMetadataFormat();
/*     */     }
/* 261 */     return instance;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/bmp/BMPMetadataFormat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */