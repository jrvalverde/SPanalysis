/*     */ package com.sun.media.imageioimpl.plugins.tiff;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TIFFElementInfo
/*     */ {
/*     */   String[] childNames;
/*     */   String[] attributeNames;
/*     */   int childPolicy;
/*  90 */   int minChildren = 0;
/*  91 */   int maxChildren = Integer.MAX_VALUE;
/*     */   
/*  93 */   int objectValueType = 0;
/*  94 */   Class objectClass = null;
/*  95 */   Object objectDefaultValue = null;
/*  96 */   Object[] objectEnumerations = null;
/*  97 */   Comparable objectMinValue = null;
/*  98 */   Comparable objectMaxValue = null;
/*  99 */   int objectArrayMinLength = 0;
/* 100 */   int objectArrayMaxLength = 0;
/*     */ 
/*     */ 
/*     */   
/*     */   public TIFFElementInfo(String[] childNames, String[] attributeNames, int childPolicy) {
/* 105 */     this.childNames = childNames;
/* 106 */     this.attributeNames = attributeNames;
/* 107 */     this.childPolicy = childPolicy;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/tiff/TIFFElementInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */