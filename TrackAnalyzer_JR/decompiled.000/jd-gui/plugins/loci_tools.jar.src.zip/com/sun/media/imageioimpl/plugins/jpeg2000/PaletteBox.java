/*     */ package com.sun.media.imageioimpl.plugins.jpeg2000;
/*     */ 
/*     */ import com.sun.media.imageioimpl.common.ImageUtil;
/*     */ import java.awt.image.IndexColorModel;
/*     */ import javax.imageio.metadata.IIOInvalidTreeException;
/*     */ import javax.imageio.metadata.IIOMetadataNode;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PaletteBox
/*     */   extends Box
/*     */ {
/*     */   private int numEntries;
/*     */   private int numComps;
/*     */   private byte[] bitDepth;
/*     */   private byte[][] lut;
/*     */   
/*     */   private static int computeLength(IndexColorModel icm) {
/* 109 */     int size = icm.getMapSize();
/* 110 */     int[] comp = icm.getComponentSize();
/* 111 */     return 11 + comp.length + size * comp.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static byte[] getCompSize(IndexColorModel icm) {
/* 118 */     int[] comp = icm.getComponentSize();
/* 119 */     int size = comp.length;
/* 120 */     byte[] buf = new byte[size];
/* 121 */     for (int i = 0; i < size; i++)
/* 122 */       buf[i] = (byte)(comp[i] - 1); 
/* 123 */     return buf;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static byte[][] getLUT(IndexColorModel icm) {
/* 130 */     int[] comp = icm.getComponentSize();
/* 131 */     int size = icm.getMapSize();
/* 132 */     byte[][] lut = new byte[comp.length][size];
/* 133 */     icm.getReds(lut[0]);
/* 134 */     icm.getGreens(lut[1]);
/* 135 */     icm.getBlues(lut[2]);
/* 136 */     if (comp.length == 4)
/* 137 */       icm.getAlphas(lut[3]); 
/* 138 */     return lut;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PaletteBox(IndexColorModel icm) {
/* 145 */     this(computeLength(icm), getCompSize(icm), getLUT(icm));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PaletteBox(Node node) throws IIOInvalidTreeException {
/* 152 */     super(node);
/* 153 */     byte[][] tlut = (byte[][])null;
/* 154 */     int index = 0;
/*     */     
/* 156 */     NodeList children = node.getChildNodes(); int i;
/* 157 */     for (i = 0; i < children.getLength(); i++) {
/* 158 */       Node child = children.item(i);
/* 159 */       String name = child.getNodeName();
/*     */       
/* 161 */       if ("NumberEntries".equals(name)) {
/* 162 */         this.numEntries = Box.getIntElementValue(child);
/*     */       }
/*     */       
/* 165 */       if ("NumberColors".equals(name)) {
/* 166 */         this.numComps = Box.getIntElementValue(child);
/*     */       }
/*     */       
/* 169 */       if ("BitDepth".equals(name)) {
/* 170 */         this.bitDepth = Box.getByteArrayElementValue(child);
/*     */       }
/*     */       
/* 173 */       if ("LUT".equals(name)) {
/* 174 */         tlut = new byte[this.numEntries][];
/*     */         
/* 176 */         NodeList children1 = child.getChildNodes();
/*     */         
/* 178 */         for (int j = 0; j < children1.getLength(); j++) {
/* 179 */           Node child1 = children1.item(j);
/* 180 */           name = child1.getNodeName();
/* 181 */           if ("LUTRow".equals(name)) {
/* 182 */             tlut[index++] = Box.getByteArrayElementValue(child1);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 190 */     this.lut = new byte[this.numComps][this.numEntries];
/*     */     
/* 192 */     for (i = 0; i < this.numComps; i++) {
/* 193 */       for (int j = 0; j < this.numEntries; j++) {
/* 194 */         this.lut[i][j] = tlut[j][i];
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public PaletteBox(int length, byte[] comp, byte[][] lut) {
/* 202 */     super(length, 1885564018, null);
/* 203 */     this.bitDepth = comp;
/* 204 */     this.lut = lut;
/* 205 */     this.numEntries = (lut[0]).length;
/* 206 */     this.numComps = lut.length;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public PaletteBox(byte[] data) {
/* 212 */     super(8 + data.length, 1885564018, data);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getNumEntries() {
/* 217 */     return this.numEntries;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getNumComp() {
/* 222 */     return this.numComps;
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] getBitDepths() {
/* 227 */     return this.bitDepth;
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[][] getLUT() {
/* 232 */     return this.lut;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IIOMetadataNode getNativeNode() {
/* 240 */     IIOMetadataNode node = new IIOMetadataNode(Box.getName(getType()));
/* 241 */     setDefaultAttributes(node);
/*     */     
/* 243 */     IIOMetadataNode child = new IIOMetadataNode("NumberEntries");
/* 244 */     child.setUserObject(new Integer(this.numEntries));
/* 245 */     child.setNodeValue("" + this.numEntries);
/* 246 */     node.appendChild(child);
/*     */     
/* 248 */     child = new IIOMetadataNode("NumberColors");
/* 249 */     child.setUserObject(new Integer(this.numComps));
/* 250 */     child.setNodeValue("" + this.numComps);
/* 251 */     node.appendChild(child);
/*     */     
/* 253 */     child = new IIOMetadataNode("BitDepth");
/* 254 */     child.setUserObject(this.bitDepth);
/* 255 */     child.setNodeValue(ImageUtil.convertObjectToString(this.bitDepth));
/* 256 */     node.appendChild(child);
/*     */     
/* 258 */     child = new IIOMetadataNode("LUT");
/* 259 */     for (int i = 0; i < this.numEntries; i++) {
/* 260 */       IIOMetadataNode child1 = new IIOMetadataNode("LUTRow");
/* 261 */       byte[] row = new byte[this.numComps];
/* 262 */       for (int j = 0; j < this.numComps; j++) {
/* 263 */         row[j] = this.lut[j][i];
/*     */       }
/* 265 */       child1.setUserObject(row);
/* 266 */       child1.setNodeValue(ImageUtil.convertObjectToString(row));
/* 267 */       child.appendChild(child1);
/*     */     } 
/* 269 */     node.appendChild(child);
/*     */     
/* 271 */     return node;
/*     */   }
/*     */   
/*     */   protected void parse(byte[] data) {
/* 275 */     if (data == null)
/*     */       return; 
/* 277 */     this.numEntries = (short)((data[0] & 0xFF) << 8 | data[1] & 0xFF);
/*     */     
/* 279 */     this.numComps = data[2];
/* 280 */     this.bitDepth = new byte[this.numComps];
/* 281 */     System.arraycopy(data, 3, this.bitDepth, 0, this.numComps);
/*     */     
/* 283 */     this.lut = new byte[this.numComps][this.numEntries];
/* 284 */     for (int i = 0, k = 3 + this.numComps; i < this.numEntries; i++) {
/* 285 */       for (int j = 0; j < this.numComps; j++)
/* 286 */         this.lut[j][i] = data[k++]; 
/*     */     } 
/*     */   }
/*     */   protected void compose() {
/* 290 */     if (this.data != null)
/*     */       return; 
/* 292 */     this.data = new byte[3 + this.numComps + this.numEntries * this.numComps];
/* 293 */     this.data[0] = (byte)(this.numEntries >> 8);
/* 294 */     this.data[1] = (byte)(this.numEntries & 0xFF);
/*     */     
/* 296 */     this.data[2] = (byte)this.numComps;
/* 297 */     System.arraycopy(this.bitDepth, 0, this.data, 3, this.numComps);
/*     */     
/* 299 */     for (int i = 0, k = 3 + this.numComps; i < this.numEntries; i++) {
/* 300 */       for (int j = 0; j < this.numComps; j++)
/* 301 */         this.data[k++] = this.lut[j][i]; 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/jpeg2000/PaletteBox.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */