/*     */ package com.sun.media.imageioimpl.plugins.jpeg2000;
/*     */ 
/*     */ import javax.imageio.metadata.IIOInvalidTreeException;
/*     */ import javax.imageio.metadata.IIOMetadataNode;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ComponentMappingBox
/*     */   extends Box
/*     */ {
/*     */   private short[] components;
/*     */   private byte[] type;
/*     */   private byte[] map;
/*     */   
/*     */   public ComponentMappingBox(byte[] data) {
/* 104 */     super(8 + data.length, 1668112752, data);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ComponentMappingBox(short[] comp, byte[] t, byte[] m) {
/* 111 */     super(8 + (comp.length << 2), 1668112752, null);
/* 112 */     this.components = comp;
/* 113 */     this.type = t;
/* 114 */     this.map = m;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ComponentMappingBox(Node node) throws IIOInvalidTreeException {
/* 121 */     super(node);
/* 122 */     NodeList children = node.getChildNodes();
/* 123 */     int len = children.getLength() / 3;
/* 124 */     this.components = new short[len];
/* 125 */     this.type = new byte[len];
/* 126 */     this.map = new byte[len];
/*     */     
/* 128 */     len *= 3;
/* 129 */     int index = 0;
/*     */     
/* 131 */     for (int i = 0; i < len; i++) {
/* 132 */       Node child = children.item(i);
/* 133 */       String name = child.getNodeName();
/*     */       
/* 135 */       if ("Component".equals(name)) {
/* 136 */         this.components[index] = Box.getShortElementValue(child);
/*     */       }
/*     */       
/* 139 */       if ("ComponentType".equals(name)) {
/* 140 */         this.type[index] = Box.getByteElementValue(child);
/*     */       }
/*     */       
/* 143 */       if ("ComponentAssociation".equals(name)) {
/* 144 */         this.map[index++] = Box.getByteElementValue(child);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void parse(byte[] data) {
/* 151 */     int len = data.length / 4;
/* 152 */     this.components = new short[len];
/* 153 */     this.type = new byte[len];
/* 154 */     this.map = new byte[len];
/*     */     
/* 156 */     for (int i = 0, j = 0; i < len; i++) {
/* 157 */       this.components[i] = (short)((data[j++] & 0xFF) << 8 | data[j++] & 0xFF);
/*     */       
/* 159 */       this.type[i] = data[j++];
/* 160 */       this.map[i] = data[j++];
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IIOMetadataNode getNativeNode() {
/* 169 */     IIOMetadataNode node = new IIOMetadataNode(Box.getName(getType()));
/* 170 */     setDefaultAttributes(node);
/*     */     
/* 172 */     for (int i = 0; i < this.components.length; i++) {
/* 173 */       IIOMetadataNode child = new IIOMetadataNode("Component");
/* 174 */       Short obj = new Short(this.components[i]);
/* 175 */       child.setUserObject(new Short(this.components[i]));
/* 176 */       child.setNodeValue("" + this.components[i]);
/* 177 */       node.appendChild(child);
/*     */       
/* 179 */       child = new IIOMetadataNode("ComponentType");
/* 180 */       child.setUserObject(new Byte(this.type[i]));
/* 181 */       child.setNodeValue("" + this.type[i]);
/* 182 */       node.appendChild(child);
/*     */       
/* 184 */       child = new IIOMetadataNode("ComponentAssociation");
/* 185 */       child.setUserObject(new Byte(this.map[i]));
/* 186 */       child.setNodeValue("" + this.map[i]);
/* 187 */       node.appendChild(child);
/*     */     } 
/*     */     
/* 190 */     return node;
/*     */   }
/*     */   
/*     */   public short[] getComponent() {
/* 194 */     return this.components;
/*     */   }
/*     */   
/*     */   public byte[] getComponentType() {
/* 198 */     return this.type;
/*     */   }
/*     */   
/*     */   public byte[] getComponentAssociation() {
/* 202 */     return this.map;
/*     */   }
/*     */   
/*     */   protected void compose() {
/* 206 */     if (this.data != null)
/*     */       return; 
/* 208 */     this.data = new byte[this.type.length << 2];
/*     */     
/* 210 */     for (int i = 0, j = 0; i < this.type.length; i++) {
/* 211 */       this.data[j++] = (byte)(this.components[i] >> 8);
/* 212 */       this.data[j++] = (byte)(this.components[i] & 0xFF);
/* 213 */       this.data[j++] = this.type[i];
/* 214 */       this.data[j++] = this.map[i];
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/jpeg2000/ComponentMappingBox.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */