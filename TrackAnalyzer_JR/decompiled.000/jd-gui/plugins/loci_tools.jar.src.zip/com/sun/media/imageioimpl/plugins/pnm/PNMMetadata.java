/*     */ package com.sun.media.imageioimpl.plugins.pnm;
/*     */ 
/*     */ import com.sun.media.imageio.plugins.pnm.PNMImageWriteParam;
/*     */ import com.sun.media.imageioimpl.common.ImageUtil;
/*     */ import java.awt.image.SampleModel;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.imageio.ImageTypeSpecifier;
/*     */ import javax.imageio.ImageWriteParam;
/*     */ import javax.imageio.metadata.IIOInvalidTreeException;
/*     */ import javax.imageio.metadata.IIOMetadata;
/*     */ import javax.imageio.metadata.IIOMetadataNode;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PNMMetadata
/*     */   extends IIOMetadata
/*     */   implements Cloneable
/*     */ {
/*     */   static final String nativeMetadataFormatName = "com_sun_media_imageio_plugins_pnm_image_1.0";
/*     */   private int maxSample;
/*     */   private int width;
/*     */   private int height;
/*     */   private int variant;
/*     */   private ArrayList comments;
/*     */   private int maxSampleSize;
/*     */   
/*     */   PNMMetadata() {
/* 149 */     super(true, "com_sun_media_imageio_plugins_pnm_image_1.0", "com.sun.media.imageioimpl.plugins.pnm.PNMMetadataFormat", null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PNMMetadata(IIOMetadata metadata) throws IIOInvalidTreeException {
/* 157 */     this();
/*     */     
/* 159 */     if (metadata != null) {
/* 160 */       List<String> formats = Arrays.asList(metadata.getMetadataFormatNames());
/*     */       
/* 162 */       if (formats.contains("com_sun_media_imageio_plugins_pnm_image_1.0")) {
/*     */         
/* 164 */         setFromTree("com_sun_media_imageio_plugins_pnm_image_1.0", metadata.getAsTree("com_sun_media_imageio_plugins_pnm_image_1.0"));
/*     */       }
/* 166 */       else if (metadata.isStandardMetadataFormatSupported()) {
/*     */         
/* 168 */         String format = "javax_imageio_1.0";
/*     */         
/* 170 */         setFromTree(format, metadata.getAsTree(format));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   PNMMetadata(ImageTypeSpecifier imageType, ImageWriteParam param) {
/* 181 */     this();
/* 182 */     initialize(imageType, param);
/*     */   }
/*     */ 
/*     */   
/*     */   void initialize(ImageTypeSpecifier imageType, ImageWriteParam param) {
/* 187 */     ImageTypeSpecifier destType = null;
/*     */     
/* 189 */     if (param != null) {
/* 190 */       destType = param.getDestinationType();
/* 191 */       if (destType == null) {
/* 192 */         destType = imageType;
/*     */       }
/*     */     } else {
/* 195 */       destType = imageType;
/*     */     } 
/*     */     
/* 198 */     if (destType != null) {
/* 199 */       SampleModel sm = destType.getSampleModel();
/* 200 */       int[] sampleSize = sm.getSampleSize();
/*     */       
/* 202 */       this.width = sm.getWidth();
/* 203 */       this.height = sm.getHeight();
/*     */       
/* 205 */       for (int i = 0; i < sampleSize.length; i++) {
/* 206 */         if (sampleSize[i] > this.maxSampleSize) {
/* 207 */           this.maxSampleSize = sampleSize[i];
/*     */         }
/*     */       } 
/* 210 */       this.maxSample = (1 << this.maxSampleSize) - 1;
/*     */       
/* 212 */       boolean isRaw = true;
/* 213 */       if (param instanceof PNMImageWriteParam) {
/* 214 */         isRaw = ((PNMImageWriteParam)param).getRaw();
/*     */       }
/*     */       
/* 217 */       if (this.maxSampleSize == 1) {
/* 218 */         this.variant = 49;
/* 219 */       } else if (sm.getNumBands() == 1) {
/* 220 */         this.variant = 50;
/* 221 */       } else if (sm.getNumBands() == 3) {
/* 222 */         this.variant = 51;
/*     */       } 
/*     */ 
/*     */       
/* 226 */       if (this.variant <= 51 && isRaw && this.maxSampleSize <= 8) {
/* 227 */         this.variant += 3;
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   protected Object clone() {
/* 233 */     PNMMetadata theClone = null;
/*     */     
/*     */     try {
/* 236 */       theClone = (PNMMetadata)super.clone();
/* 237 */     } catch (CloneNotSupportedException e) {}
/*     */     
/* 239 */     if (this.comments != null) {
/* 240 */       int numComments = this.comments.size();
/* 241 */       for (int i = 0; i < numComments; i++) {
/* 242 */         theClone.addComment(this.comments.get(i));
/*     */       }
/*     */     } 
/* 245 */     return theClone;
/*     */   }
/*     */   
/*     */   public Node getAsTree(String formatName) {
/* 249 */     if (formatName == null) {
/* 250 */       throw new IllegalArgumentException(I18N.getString("PNMMetadata0"));
/*     */     }
/*     */     
/* 253 */     if (formatName.equals("com_sun_media_imageio_plugins_pnm_image_1.0")) {
/* 254 */       return getNativeTree();
/*     */     }
/*     */     
/* 257 */     if (formatName.equals("javax_imageio_1.0"))
/*     */     {
/* 259 */       return getStandardTree();
/*     */     }
/*     */     
/* 262 */     throw new IllegalArgumentException(I18N.getString("PNMMetadata1") + " " + formatName);
/*     */   }
/*     */ 
/*     */   
/*     */   IIOMetadataNode getNativeTree() {
/* 267 */     IIOMetadataNode root = new IIOMetadataNode("com_sun_media_imageio_plugins_pnm_image_1.0");
/*     */ 
/*     */     
/* 270 */     IIOMetadataNode child = new IIOMetadataNode("FormatName");
/* 271 */     child.setUserObject(getFormatName());
/* 272 */     child.setNodeValue(getFormatName());
/* 273 */     root.appendChild(child);
/*     */     
/* 275 */     child = new IIOMetadataNode("Variant");
/* 276 */     child.setUserObject(getVariant());
/* 277 */     child.setNodeValue(getVariant());
/* 278 */     root.appendChild(child);
/*     */     
/* 280 */     child = new IIOMetadataNode("Width");
/* 281 */     Object tmp = new Integer(this.width);
/* 282 */     child.setUserObject(tmp);
/* 283 */     child.setNodeValue(ImageUtil.convertObjectToString(tmp));
/* 284 */     root.appendChild(child);
/*     */     
/* 286 */     child = new IIOMetadataNode("Height");
/* 287 */     tmp = new Integer(this.height);
/* 288 */     child.setUserObject(tmp);
/* 289 */     child.setNodeValue(ImageUtil.convertObjectToString(tmp));
/* 290 */     root.appendChild(child);
/*     */     
/* 292 */     child = new IIOMetadataNode("MaximumSample");
/* 293 */     tmp = new Byte((byte)this.maxSample);
/* 294 */     child.setUserObject(tmp);
/* 295 */     child.setNodeValue(ImageUtil.convertObjectToString(new Integer(this.maxSample)));
/* 296 */     root.appendChild(child);
/*     */     
/* 298 */     if (this.comments != null) {
/* 299 */       for (int i = 0; i < this.comments.size(); i++) {
/* 300 */         child = new IIOMetadataNode("Comment");
/* 301 */         tmp = this.comments.get(i);
/* 302 */         child.setUserObject(tmp);
/* 303 */         child.setNodeValue(ImageUtil.convertObjectToString(tmp));
/* 304 */         root.appendChild(child);
/*     */       } 
/*     */     }
/*     */     
/* 308 */     return root;
/*     */   }
/*     */ 
/*     */   
/*     */   protected IIOMetadataNode getStandardChromaNode() {
/* 313 */     IIOMetadataNode node = new IIOMetadataNode("Chroma");
/*     */     
/* 315 */     int temp = (this.variant - 49) % 3 + 1;
/*     */     
/* 317 */     IIOMetadataNode subNode = new IIOMetadataNode("ColorSpaceType");
/* 318 */     if (temp == 3) {
/* 319 */       subNode.setAttribute("name", "RGB");
/*     */     } else {
/* 321 */       subNode.setAttribute("name", "GRAY");
/*     */     } 
/* 323 */     node.appendChild(subNode);
/*     */     
/* 325 */     subNode = new IIOMetadataNode("NumChannels");
/* 326 */     subNode.setAttribute("value", "" + ((temp == 3) ? 3 : 1));
/* 327 */     node.appendChild(subNode);
/*     */     
/* 329 */     if (temp != 3) {
/* 330 */       subNode = new IIOMetadataNode("BlackIsZero");
/* 331 */       subNode.setAttribute("value", "TRUE");
/* 332 */       node.appendChild(subNode);
/*     */     } 
/*     */     
/* 335 */     return node;
/*     */   }
/*     */   
/*     */   protected IIOMetadataNode getStandardDataNode() {
/* 339 */     IIOMetadataNode node = new IIOMetadataNode("Data");
/*     */     
/* 341 */     IIOMetadataNode subNode = new IIOMetadataNode("SampleFormat");
/* 342 */     subNode.setAttribute("value", "UnsignedIntegral");
/* 343 */     node.appendChild(subNode);
/*     */     
/* 345 */     int temp = (this.variant - 49) % 3 + 1;
/* 346 */     subNode = new IIOMetadataNode("BitsPerSample");
/* 347 */     if (temp == 1) {
/* 348 */       subNode.setAttribute("value", "1");
/* 349 */     } else if (temp == 2) {
/* 350 */       subNode.setAttribute("value", "8");
/*     */     } else {
/* 352 */       subNode.setAttribute("value", "8 8 8");
/*     */     } 
/* 354 */     node.appendChild(subNode);
/*     */     
/* 356 */     subNode = new IIOMetadataNode("SignificantBitsPerSample");
/* 357 */     if (temp == 1 || temp == 2) {
/* 358 */       subNode.setAttribute("value", "" + this.maxSampleSize);
/*     */     } else {
/* 360 */       subNode.setAttribute("value", this.maxSampleSize + " " + this.maxSampleSize + " " + this.maxSampleSize);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 365 */     node.appendChild(subNode);
/*     */     
/* 367 */     return node;
/*     */   }
/*     */   
/*     */   protected IIOMetadataNode getStandardDimensionNode() {
/* 371 */     IIOMetadataNode node = new IIOMetadataNode("Dimension");
/*     */     
/* 373 */     IIOMetadataNode subNode = new IIOMetadataNode("ImageOrientation");
/* 374 */     subNode.setAttribute("value", "Normal");
/* 375 */     node.appendChild(subNode);
/*     */     
/* 377 */     return node;
/*     */   }
/*     */   
/*     */   protected IIOMetadataNode getStandardTextNode() {
/* 381 */     if (this.comments != null) {
/* 382 */       IIOMetadataNode node = new IIOMetadataNode("Text");
/* 383 */       Iterator<String> iter = this.comments.iterator();
/* 384 */       while (iter.hasNext()) {
/* 385 */         String comment = iter.next();
/* 386 */         IIOMetadataNode subNode = new IIOMetadataNode("TextEntry");
/* 387 */         subNode.setAttribute("keyword", "comment");
/* 388 */         subNode.setAttribute("value", comment);
/* 389 */         node.appendChild(subNode);
/*     */       } 
/* 391 */       return node;
/*     */     } 
/* 393 */     return null;
/*     */   }
/*     */   
/*     */   public boolean isReadOnly() {
/* 397 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void mergeTree(String formatName, Node root) throws IIOInvalidTreeException {
/* 402 */     if (formatName == null) {
/* 403 */       throw new IllegalArgumentException(I18N.getString("PNMMetadata0"));
/*     */     }
/*     */     
/* 406 */     if (root == null) {
/* 407 */       throw new IllegalArgumentException(I18N.getString("PNMMetadata2"));
/*     */     }
/*     */     
/* 410 */     if (formatName.equals("com_sun_media_imageio_plugins_pnm_image_1.0") && root.getNodeName().equals("com_sun_media_imageio_plugins_pnm_image_1.0")) {
/*     */       
/* 412 */       mergeNativeTree(root);
/* 413 */     } else if (formatName.equals("javax_imageio_1.0")) {
/*     */       
/* 415 */       mergeStandardTree(root);
/*     */     } else {
/* 417 */       throw new IllegalArgumentException(I18N.getString("PNMMetadata1") + " " + formatName);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFromTree(String formatName, Node root) throws IIOInvalidTreeException {
/* 424 */     if (formatName == null) {
/* 425 */       throw new IllegalArgumentException(I18N.getString("PNMMetadata0"));
/*     */     }
/*     */     
/* 428 */     if (root == null) {
/* 429 */       throw new IllegalArgumentException(I18N.getString("PNMMetadata2"));
/*     */     }
/*     */     
/* 432 */     if (formatName.equals("com_sun_media_imageio_plugins_pnm_image_1.0") && root.getNodeName().equals("com_sun_media_imageio_plugins_pnm_image_1.0")) {
/*     */       
/* 434 */       mergeNativeTree(root);
/* 435 */     } else if (formatName.equals("javax_imageio_1.0")) {
/*     */       
/* 437 */       mergeStandardTree(root);
/*     */     } else {
/* 439 */       throw new IllegalArgumentException(I18N.getString("PNMMetadata2") + " " + formatName);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void reset() {
/* 445 */     this.maxSample = this.width = this.height = this.variant = this.maxSampleSize = 0;
/* 446 */     this.comments = null;
/*     */   }
/*     */   
/*     */   public String getFormatName() {
/* 450 */     int v = (this.variant - 49) % 3 + 1;
/* 451 */     if (v == 1)
/* 452 */       return "PBM"; 
/* 453 */     if (v == 2)
/* 454 */       return "PGM"; 
/* 455 */     if (v == 3)
/* 456 */       return "PPM"; 
/* 457 */     return null;
/*     */   }
/*     */   
/*     */   public String getVariant() {
/* 461 */     if (this.variant > 51)
/* 462 */       return "RAWBITS"; 
/* 463 */     return "ASCII";
/*     */   }
/*     */   
/*     */   boolean isRaw() {
/* 467 */     return getVariant().equals("RAWBITS");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setVariant(int v) {
/* 472 */     this.variant = v;
/*     */   }
/*     */   
/*     */   public void setWidth(int w) {
/* 476 */     this.width = w;
/*     */   }
/*     */   
/*     */   public void setHeight(int h) {
/* 480 */     this.height = h;
/*     */   }
/*     */   
/*     */   int getMaxBitDepth() {
/* 484 */     return this.maxSampleSize;
/*     */   }
/*     */   
/*     */   int getMaxValue() {
/* 488 */     return this.maxSample;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMaxBitDepth(int maxValue) {
/* 496 */     this.maxSample = maxValue;
/*     */     
/* 498 */     this.maxSampleSize = 0;
/* 499 */     while (maxValue > 0) {
/* 500 */       maxValue >>>= 1;
/* 501 */       this.maxSampleSize++;
/*     */     } 
/*     */   }
/*     */   
/*     */   public synchronized void addComment(String comment) {
/* 506 */     if (this.comments == null) {
/* 507 */       this.comments = new ArrayList();
/*     */     }
/* 509 */     comment = comment.replaceAll("[\n\r\f]", " ");
/* 510 */     this.comments.add(comment);
/*     */   }
/*     */   
/*     */   Iterator getComments() {
/* 514 */     return (this.comments == null) ? null : this.comments.iterator();
/*     */   }
/*     */   
/*     */   private void mergeNativeTree(Node root) throws IIOInvalidTreeException {
/* 518 */     NodeList list = root.getChildNodes();
/* 519 */     String format = null;
/* 520 */     String var = null;
/*     */     
/* 522 */     for (int i = list.getLength() - 1; i >= 0; i--) {
/* 523 */       IIOMetadataNode node = (IIOMetadataNode)list.item(i);
/* 524 */       String name = node.getNodeName();
/*     */       
/* 526 */       if (name.equals("Comment")) {
/* 527 */         addComment((String)node.getUserObject());
/* 528 */       } else if (name.equals("Width")) {
/* 529 */         this.width = ((Integer)node.getUserObject()).intValue();
/* 530 */       } else if (name.equals("Height")) {
/* 531 */         this.width = ((Integer)node.getUserObject()).intValue();
/* 532 */       } else if (name.equals("MaximumSample")) {
/* 533 */         int maxValue = ((Integer)node.getUserObject()).intValue();
/* 534 */         setMaxBitDepth(maxValue);
/* 535 */       } else if (name.equals("FormatName")) {
/* 536 */         format = (String)node.getUserObject();
/* 537 */       } else if (name.equals("Variant")) {
/* 538 */         var = (String)node.getUserObject();
/*     */       } 
/*     */     } 
/*     */     
/* 542 */     if (format.equals("PBM")) {
/* 543 */       this.variant = 49;
/* 544 */     } else if (format.equals("PGM")) {
/* 545 */       this.variant = 50;
/* 546 */     } else if (format.equals("PPM")) {
/* 547 */       this.variant = 51;
/*     */     } 
/* 549 */     if (var.equals("RAWBITS"))
/* 550 */       this.variant += 3; 
/*     */   }
/*     */   
/*     */   private void mergeStandardTree(Node root) throws IIOInvalidTreeException {
/* 554 */     NodeList children = root.getChildNodes();
/*     */     
/* 556 */     String colorSpace = null;
/* 557 */     int numComps = 0;
/* 558 */     int[] bitsPerSample = null;
/*     */     
/* 560 */     for (int i = 0; i < children.getLength(); i++) {
/* 561 */       Node node = children.item(i);
/* 562 */       String name = node.getNodeName();
/* 563 */       if (name.equals("Chroma")) {
/* 564 */         NodeList children1 = node.getChildNodes();
/* 565 */         for (int j = 0; j < children1.getLength(); j++) {
/* 566 */           Node child = children1.item(j);
/* 567 */           String name1 = child.getNodeName();
/*     */           
/* 569 */           if (name1.equals("NumChannels")) {
/* 570 */             String s = (String)getAttribute(child, "value");
/* 571 */             numComps = (new Integer(s)).intValue();
/* 572 */           } else if (name1.equals("ColorSpaceType")) {
/* 573 */             colorSpace = (String)getAttribute(child, "name");
/*     */           } 
/*     */         } 
/* 576 */       } else if (!name.equals("Compression")) {
/*     */         
/* 578 */         if (name.equals("Data")) {
/* 579 */           NodeList children1 = node.getChildNodes();
/* 580 */           int maxBitDepth = -1;
/* 581 */           for (int j = 0; j < children1.getLength(); j++) {
/* 582 */             Node child = children1.item(j);
/* 583 */             String name1 = child.getNodeName();
/*     */             
/* 585 */             if (name1.equals("BitsPerSample")) {
/* 586 */               List<Integer> bps = new ArrayList(3);
/* 587 */               String s = (String)getAttribute(child, "value");
/* 588 */               StringTokenizer t = new StringTokenizer(s);
/* 589 */               while (t.hasMoreTokens()) {
/* 590 */                 bps.add(Integer.valueOf(t.nextToken()));
/*     */               }
/* 592 */               bitsPerSample = new int[bps.size()];
/* 593 */               for (int k = 0; k < bitsPerSample.length; k++) {
/* 594 */                 bitsPerSample[k] = ((Integer)bps.get(k)).intValue();
/*     */               }
/*     */             }
/* 597 */             else if (name1.equals("SignificantBitsPerSample")) {
/* 598 */               String s = (String)getAttribute(child, "value");
/* 599 */               StringTokenizer t = new StringTokenizer(s);
/* 600 */               while (t.hasMoreTokens()) {
/* 601 */                 int sbps = Integer.valueOf(t.nextToken()).intValue();
/*     */                 
/* 603 */                 maxBitDepth = Math.max(sbps, maxBitDepth);
/*     */               } 
/*     */             } 
/*     */           } 
/*     */ 
/*     */           
/* 609 */           if (maxBitDepth > 0) {
/* 610 */             setMaxBitDepth((1 << maxBitDepth) - 1);
/* 611 */           } else if (bitsPerSample != null) {
/* 612 */             for (int k = 0; k < bitsPerSample.length; k++) {
/* 613 */               if (bitsPerSample[k] > maxBitDepth) {
/* 614 */                 maxBitDepth = bitsPerSample[k];
/*     */               }
/*     */             } 
/* 617 */             setMaxBitDepth((1 << maxBitDepth) - 1);
/*     */           } 
/* 619 */         } else if (!name.equals("Dimension")) {
/*     */           
/* 621 */           if (!name.equals("Document"))
/*     */           {
/* 623 */             if (name.equals("Text")) {
/* 624 */               NodeList children1 = node.getChildNodes();
/* 625 */               for (int j = 0; j < children1.getLength(); j++) {
/* 626 */                 Node child = children1.item(j);
/* 627 */                 String name1 = child.getNodeName();
/*     */                 
/* 629 */                 if (name1.equals("TextEntry")) {
/* 630 */                   addComment((String)getAttribute(child, "value"));
/*     */                 }
/*     */               } 
/* 633 */             } else if (!name.equals("Transparency")) {
/*     */ 
/*     */               
/* 636 */               throw new IIOInvalidTreeException(I18N.getString("PNMMetadata3") + " " + name, node);
/*     */             } 
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 642 */     if ((colorSpace != null && colorSpace.equals("RGB")) || numComps > 1 || bitsPerSample.length > 1) {
/*     */ 
/*     */       
/* 645 */       this.variant = 51;
/* 646 */     } else if (this.maxSampleSize > 1) {
/* 647 */       this.variant = 50;
/*     */     } else {
/* 649 */       this.variant = 49;
/*     */     } 
/*     */   }
/*     */   
/*     */   public Object getAttribute(Node node, String name) {
/* 654 */     NamedNodeMap map = node.getAttributes();
/* 655 */     node = map.getNamedItem(name);
/* 656 */     return (node != null) ? node.getNodeValue() : null;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/pnm/PNMMetadata.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */