/*     */ package com.sun.media.imageioimpl.plugins.jpeg2000;
/*     */ 
/*     */ import com.sun.media.imageio.plugins.jpeg2000.J2KImageReadParam;
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.Raster;
/*     */ import java.awt.image.RenderedImage;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import javax.imageio.ImageReadParam;
/*     */ import javax.imageio.ImageReader;
/*     */ import javax.imageio.ImageTypeSpecifier;
/*     */ import javax.imageio.metadata.IIOMetadata;
/*     */ import javax.imageio.spi.ImageReaderSpi;
/*     */ import javax.imageio.stream.ImageInputStream;
/*     */ import jj2000.j2k.codestream.reader.HeaderDecoder;
/*     */ import jj2000.j2k.util.FacilityManager;
/*     */ import jj2000.j2k.util.MsgLogger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class J2KImageReader
/*     */   extends ImageReader
/*     */   implements MsgLogger
/*     */ {
/* 127 */   private ImageInputStream iis = null;
/*     */ 
/*     */   
/*     */   private long streamPosition0;
/*     */ 
/*     */   
/*     */   private boolean gotHeader = false;
/*     */ 
/*     */   
/*     */   private int width;
/*     */ 
/*     */   
/*     */   private int height;
/*     */ 
/*     */   
/* 142 */   private J2KMetadata imageMetadata = null;
/*     */ 
/*     */   
/* 145 */   private int imageMetadataIndex = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private HeaderDecoder hd;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 155 */   private J2KReadState readState = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean logJJ2000Msg = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void computeRegionsWrapper(ImageReadParam param, boolean allowZeroDestOffset, int srcWidth, int srcHeight, BufferedImage image, Rectangle srcRegion, Rectangle destRegion) {
/* 173 */     if (srcRegion == null) {
/* 174 */       throw new IllegalArgumentException(I18N.getString("J2KImageReader0"));
/*     */     }
/* 176 */     if (destRegion == null) {
/* 177 */       throw new IllegalArgumentException(I18N.getString("J2KImageReader1"));
/*     */     }
/*     */ 
/*     */     
/* 181 */     int periodX = 1;
/* 182 */     int periodY = 1;
/* 183 */     int gridX = 0;
/* 184 */     int gridY = 0;
/* 185 */     if (param != null) {
/* 186 */       Rectangle paramSrcRegion = param.getSourceRegion();
/* 187 */       if (paramSrcRegion != null) {
/* 188 */         srcRegion.setBounds(srcRegion.intersection(paramSrcRegion));
/*     */       }
/* 190 */       periodX = param.getSourceXSubsampling();
/* 191 */       periodY = param.getSourceYSubsampling();
/* 192 */       gridX = param.getSubsamplingXOffset();
/* 193 */       gridY = param.getSubsamplingYOffset();
/* 194 */       srcRegion.translate(gridX, gridY);
/* 195 */       srcRegion.width -= gridX;
/* 196 */       srcRegion.height -= gridY;
/* 197 */       if (allowZeroDestOffset) {
/* 198 */         destRegion.setLocation(param.getDestinationOffset());
/*     */       } else {
/* 200 */         Point destOffset = param.getDestinationOffset();
/* 201 */         if (destOffset.x != 0 || destOffset.y != 0) {
/* 202 */           destRegion.setLocation(param.getDestinationOffset());
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 209 */     if (destRegion.x < 0) {
/* 210 */       int delta = -destRegion.x * periodX;
/* 211 */       srcRegion.x += delta;
/* 212 */       srcRegion.width -= delta;
/* 213 */       destRegion.x = 0;
/*     */     } 
/* 215 */     if (destRegion.y < 0) {
/* 216 */       int delta = -destRegion.y * periodY;
/* 217 */       srcRegion.y += delta;
/* 218 */       srcRegion.height -= delta;
/* 219 */       destRegion.y = 0;
/*     */     } 
/*     */ 
/*     */     
/* 223 */     int subsampledWidth = (srcRegion.width + periodX - 1) / periodX;
/* 224 */     int subsampledHeight = (srcRegion.height + periodY - 1) / periodY;
/* 225 */     destRegion.width = subsampledWidth;
/* 226 */     destRegion.height = subsampledHeight;
/*     */ 
/*     */ 
/*     */     
/* 230 */     if (image != null) {
/* 231 */       Rectangle destImageRect = new Rectangle(0, 0, image.getWidth(), image.getHeight());
/*     */ 
/*     */       
/* 234 */       destRegion.setBounds(destRegion.intersection(destImageRect));
/* 235 */       if (destRegion.isEmpty()) {
/* 236 */         throw new IllegalArgumentException(I18N.getString("J2KImageReader2"));
/*     */       }
/*     */ 
/*     */       
/* 240 */       int deltaX = destRegion.x + subsampledWidth - image.getWidth();
/* 241 */       if (deltaX > 0) {
/* 242 */         srcRegion.width -= deltaX * periodX;
/*     */       }
/* 244 */       int deltaY = destRegion.y + subsampledHeight - image.getHeight();
/* 245 */       if (deltaY > 0) {
/* 246 */         srcRegion.height -= deltaY * periodY;
/*     */       }
/*     */     } 
/* 249 */     if (srcRegion.isEmpty() || destRegion.isEmpty()) {
/* 250 */       throw new IllegalArgumentException(I18N.getString("J2KImageReader3"));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void checkReadParamBandSettingsWrapper(ImageReadParam param, int numSrcBands, int numDstBands) {
/* 261 */     checkReadParamBandSettings(param, numSrcBands, numDstBands);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Rectangle getReducedRect(Rectangle r, int maxLevel, int level, int subX, int subY) {
/* 281 */     if (r == null)
/* 282 */       throw new IllegalArgumentException("r == null!"); 
/* 283 */     if (maxLevel < 0 || level < 0)
/* 284 */       throw new IllegalArgumentException("maxLevel < 0 || level < 0!"); 
/* 285 */     if (level > maxLevel) {
/* 286 */       throw new IllegalArgumentException("level > maxLevel");
/*     */     }
/*     */ 
/*     */     
/* 290 */     if (level == maxLevel && subX == 1 && subY == 1) {
/* 291 */       return r;
/*     */     }
/*     */ 
/*     */     
/* 295 */     int divisor = 1 << maxLevel - level;
/* 296 */     int divX = divisor * subX;
/* 297 */     int divY = divisor * subY;
/*     */ 
/*     */     
/* 300 */     int x1 = (r.x + divX - 1) / divX;
/* 301 */     int x2 = (r.x + r.width + divX - 1) / divX;
/* 302 */     int y1 = (r.y + divY - 1) / divY;
/* 303 */     int y2 = (r.y + r.height + divY - 1) / divY;
/*     */ 
/*     */     
/* 306 */     return new Rectangle(x1, y1, x2 - x1, y2 - y1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void processImageUpdateWrapper(BufferedImage theImage, int minX, int minY, int width, int height, int periodX, int periodY, int[] bands) {
/* 318 */     processImageUpdate(theImage, minX, minY, width, height, periodX, periodY, bands);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void processImageProgressWrapper(float percentageDone) {
/* 330 */     processImageProgress(percentageDone);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public J2KImageReader(ImageReaderSpi originator) {
/* 337 */     super(originator);
/*     */     
/* 339 */     this.logJJ2000Msg = Boolean.getBoolean("jj2000.j2k.decoder.log");
/*     */     
/* 341 */     FacilityManager.registerMsgLogger(null, this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInput(Object input, boolean seekForwardOnly, boolean ignoreMetadata) {
/* 348 */     super.setInput(input, seekForwardOnly, ignoreMetadata);
/* 349 */     this.ignoreMetadata = ignoreMetadata;
/* 350 */     this.iis = (ImageInputStream)input;
/* 351 */     this.imageMetadata = null;
/*     */     try {
/* 353 */       this.streamPosition0 = this.iis.getStreamPosition();
/* 354 */     } catch (IOException e) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNumImages(boolean allowSearch) throws IOException {
/* 361 */     return 1;
/*     */   }
/*     */   
/*     */   public int getWidth(int imageIndex) throws IOException {
/* 365 */     checkIndex(imageIndex);
/* 366 */     readHeader();
/* 367 */     return this.width;
/*     */   }
/*     */   
/*     */   public int getHeight(int imageIndex) throws IOException {
/* 371 */     checkIndex(imageIndex);
/* 372 */     readHeader();
/* 373 */     return this.height;
/*     */   }
/*     */   
/*     */   public int getTileGridXOffset(int imageIndex) throws IOException {
/* 377 */     checkIndex(imageIndex);
/* 378 */     readHeader();
/* 379 */     return (this.hd.getTilingOrigin(null)).x;
/*     */   }
/*     */   
/*     */   public int getTileGridYOffset(int imageIndex) throws IOException {
/* 383 */     checkIndex(imageIndex);
/* 384 */     readHeader();
/* 385 */     return (this.hd.getTilingOrigin(null)).y;
/*     */   }
/*     */   
/*     */   public int getTileWidth(int imageIndex) throws IOException {
/* 389 */     checkIndex(imageIndex);
/* 390 */     readHeader();
/* 391 */     return this.hd.getNomTileWidth();
/*     */   }
/*     */   
/*     */   public int getTileHeight(int imageIndex) throws IOException {
/* 395 */     checkIndex(imageIndex);
/* 396 */     readHeader();
/* 397 */     return this.hd.getNomTileHeight();
/*     */   }
/*     */   
/*     */   private void checkIndex(int imageIndex) {
/* 401 */     if (imageIndex != 0) {
/* 402 */       throw new IndexOutOfBoundsException(I18N.getString("J2KImageReader4"));
/*     */     }
/*     */   }
/*     */   
/*     */   public void readHeader() {
/* 407 */     if (this.gotHeader) {
/*     */       return;
/*     */     }
/* 410 */     if (this.readState == null) {
/*     */       try {
/* 412 */         this.iis.seek(this.streamPosition0);
/* 413 */       } catch (IOException e) {}
/*     */ 
/*     */ 
/*     */       
/* 417 */       this.readState = new J2KReadState(this.iis, new J2KImageReadParamJava(getDefaultReadParam()), this);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 423 */     this.hd = this.readState.getHeader();
/* 424 */     this.gotHeader = true;
/*     */     
/* 426 */     this.width = this.hd.getImgWidth();
/* 427 */     this.height = this.hd.getImgHeight();
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator getImageTypes(int imageIndex) throws IOException {
/* 432 */     checkIndex(imageIndex);
/* 433 */     readHeader();
/* 434 */     if (this.readState != null) {
/* 435 */       ArrayList<ImageTypeSpecifier> list = new ArrayList();
/* 436 */       list.add(new ImageTypeSpecifier(this.readState.getColorModel(), this.readState.getSampleModel()));
/*     */       
/* 438 */       return list.iterator();
/*     */     } 
/* 440 */     return null;
/*     */   }
/*     */   
/*     */   public ImageReadParam getDefaultReadParam() {
/* 444 */     return (ImageReadParam)new J2KImageReadParam();
/*     */   }
/*     */ 
/*     */   
/*     */   public IIOMetadata getImageMetadata(int imageIndex) throws IOException {
/* 449 */     checkIndex(imageIndex);
/* 450 */     if (this.ignoreMetadata) {
/* 451 */       return null;
/*     */     }
/* 453 */     if (this.imageMetadata == null) {
/* 454 */       this.iis.mark();
/* 455 */       this.imageMetadata = new J2KMetadata(this.iis, this);
/* 456 */       this.iis.reset();
/*     */     } 
/* 458 */     return this.imageMetadata;
/*     */   }
/*     */   
/*     */   public IIOMetadata getStreamMetadata() throws IOException {
/* 462 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public BufferedImage read(int imageIndex, ImageReadParam param) throws IOException {
/* 467 */     checkIndex(imageIndex);
/* 468 */     clearAbortRequest();
/* 469 */     processImageStarted(imageIndex);
/*     */     
/* 471 */     if (param == null) {
/* 472 */       param = getDefaultReadParam();
/*     */     }
/* 474 */     J2KImageReadParamJava j2KImageReadParamJava = new J2KImageReadParamJava(param);
/*     */     
/* 476 */     if (!this.ignoreMetadata) {
/* 477 */       this.imageMetadata = new J2KMetadata();
/* 478 */       this.iis.seek(this.streamPosition0);
/* 479 */       this.readState = new J2KReadState(this.iis, j2KImageReadParamJava, this.imageMetadata, this);
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 484 */       this.iis.seek(this.streamPosition0);
/* 485 */       this.readState = new J2KReadState(this.iis, j2KImageReadParamJava, this);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 490 */     BufferedImage bi = this.readState.readBufferedImage();
/* 491 */     if (abortRequested()) {
/* 492 */       processReadAborted();
/*     */     } else {
/* 494 */       processImageComplete();
/* 495 */     }  return bi;
/*     */   }
/*     */ 
/*     */   
/*     */   public RenderedImage readAsRenderedImage(int imageIndex, ImageReadParam param) throws IOException {
/*     */     J2KRenderedImage j2KRenderedImage;
/* 501 */     checkIndex(imageIndex);
/* 502 */     RenderedImage ri = null;
/* 503 */     clearAbortRequest();
/* 504 */     processImageStarted(imageIndex);
/*     */     
/* 506 */     if (param == null) {
/* 507 */       param = getDefaultReadParam();
/*     */     }
/* 509 */     J2KImageReadParamJava j2KImageReadParamJava = new J2KImageReadParamJava(param);
/* 510 */     if (!this.ignoreMetadata) {
/* 511 */       if (this.imageMetadata == null)
/* 512 */         this.imageMetadata = new J2KMetadata(); 
/* 513 */       j2KRenderedImage = new J2KRenderedImage(this.iis, j2KImageReadParamJava, this.imageMetadata, this);
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 519 */       j2KRenderedImage = new J2KRenderedImage(this.iis, j2KImageReadParamJava, this);
/* 520 */     }  if (abortRequested()) {
/* 521 */       processReadAborted();
/*     */     } else {
/* 523 */       processImageComplete();
/* 524 */     }  return (RenderedImage)j2KRenderedImage;
/*     */   }
/*     */   
/*     */   public boolean canReadRaster() {
/* 528 */     return true;
/*     */   }
/*     */   
/*     */   public boolean isRandomAccessEasy(int imageIndex) throws IOException {
/* 532 */     checkIndex(imageIndex);
/* 533 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public Raster readRaster(int imageIndex, ImageReadParam param) throws IOException {
/* 538 */     checkIndex(imageIndex);
/* 539 */     processImageStarted(imageIndex);
/*     */     
/* 541 */     if (param == null) {
/* 542 */       param = getDefaultReadParam();
/*     */     }
/* 544 */     J2KImageReadParamJava j2KImageReadParamJava = new J2KImageReadParamJava(param);
/*     */     
/* 546 */     if (!this.ignoreMetadata) {
/* 547 */       this.imageMetadata = new J2KMetadata();
/* 548 */       this.iis.seek(this.streamPosition0);
/* 549 */       this.readState = new J2KReadState(this.iis, j2KImageReadParamJava, this.imageMetadata, this);
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 554 */       this.iis.seek(this.streamPosition0);
/* 555 */       this.readState = new J2KReadState(this.iis, j2KImageReadParamJava, this);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 560 */     Raster ras = this.readState.readAsRaster();
/* 561 */     if (abortRequested()) {
/* 562 */       processReadAborted();
/*     */     } else {
/* 564 */       processImageComplete();
/* 565 */     }  return ras;
/*     */   }
/*     */   
/*     */   public boolean isImageTiled(int imageIndex) {
/* 569 */     checkIndex(imageIndex);
/* 570 */     readHeader();
/* 571 */     if (this.readState != null) {
/* 572 */       J2KRenderedImage j2KRenderedImage = new J2KRenderedImage(this.readState);
/* 573 */       if (j2KRenderedImage.getNumXTiles() * j2KRenderedImage.getNumYTiles() > 0)
/* 574 */         return true; 
/* 575 */       return false;
/*     */     } 
/* 577 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void reset() {
/* 582 */     super.reset();
/*     */     
/* 584 */     this.iis = null;
/* 585 */     this.gotHeader = false;
/* 586 */     this.imageMetadata = null;
/* 587 */     this.readState = null;
/* 588 */     System.gc();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getAbortRequest() {
/* 595 */     return abortRequested();
/*     */   }
/*     */ 
/*     */   
/*     */   private ImageTypeSpecifier getImageType(int imageIndex) throws IOException {
/* 600 */     checkIndex(imageIndex);
/* 601 */     readHeader();
/* 602 */     if (this.readState != null) {
/* 603 */       return new ImageTypeSpecifier(this.readState.getColorModel(), this.readState.getSampleModel());
/*     */     }
/*     */     
/* 606 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void flush() {}
/*     */ 
/*     */   
/*     */   public void println(String str, int flind, int ind) {
/* 615 */     printmsg(1, str);
/*     */   }
/*     */   
/*     */   public void printmsg(int sev, String msg) {
/* 619 */     if (this.logJJ2000Msg) {
/*     */       String msgSev;
/* 621 */       switch (sev) {
/*     */         case 3:
/* 623 */           msgSev = "ERROR";
/*     */           break;
/*     */         case 1:
/* 626 */           msgSev = "INFO";
/*     */           break;
/*     */         case 0:
/* 629 */           msgSev = "LOG";
/*     */           break;
/*     */         
/*     */         default:
/* 633 */           msgSev = "WARNING";
/*     */           break;
/*     */       } 
/*     */       
/* 637 */       processWarningOccurred("[JJ2000 " + msgSev + "] " + msg);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/jpeg2000/J2KImageReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */