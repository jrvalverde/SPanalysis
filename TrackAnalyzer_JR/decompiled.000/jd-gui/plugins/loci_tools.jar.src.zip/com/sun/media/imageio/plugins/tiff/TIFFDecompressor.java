/*      */ package com.sun.media.imageio.plugins.tiff;
/*      */ 
/*      */ import com.sun.media.imageioimpl.common.BogusColorSpace;
/*      */ import com.sun.media.imageioimpl.common.ImageUtil;
/*      */ import com.sun.media.imageioimpl.common.SimpleCMYKColorSpace;
/*      */ import java.awt.Rectangle;
/*      */ import java.awt.color.ColorSpace;
/*      */ import java.awt.image.BufferedImage;
/*      */ import java.awt.image.ColorModel;
/*      */ import java.awt.image.ComponentColorModel;
/*      */ import java.awt.image.ComponentSampleModel;
/*      */ import java.awt.image.DataBuffer;
/*      */ import java.awt.image.DataBufferByte;
/*      */ import java.awt.image.DataBufferFloat;
/*      */ import java.awt.image.DataBufferInt;
/*      */ import java.awt.image.DataBufferShort;
/*      */ import java.awt.image.DataBufferUShort;
/*      */ import java.awt.image.IndexColorModel;
/*      */ import java.awt.image.MultiPixelPackedSampleModel;
/*      */ import java.awt.image.PixelInterleavedSampleModel;
/*      */ import java.awt.image.Raster;
/*      */ import java.awt.image.SampleModel;
/*      */ import java.awt.image.SinglePixelPackedSampleModel;
/*      */ import java.awt.image.WritableRaster;
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.IOException;
/*      */ import java.nio.ByteOrder;
/*      */ import javax.imageio.IIOException;
/*      */ import javax.imageio.ImageReader;
/*      */ import javax.imageio.ImageTypeSpecifier;
/*      */ import javax.imageio.metadata.IIOMetadata;
/*      */ import javax.imageio.stream.ImageInputStream;
/*      */ import javax.imageio.stream.MemoryCacheImageInputStream;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class TIFFDecompressor
/*      */ {
/*      */   private static final boolean DEBUG = false;
/*      */   protected ImageReader reader;
/*      */   protected IIOMetadata metadata;
/*      */   protected int photometricInterpretation;
/*      */   protected int compression;
/*      */   protected boolean planar;
/*      */   protected int samplesPerPixel;
/*      */   protected int[] bitsPerSample;
/*  234 */   protected int[] sampleFormat = new int[] { 1 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int[] extraSamples;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected char[] colorMap;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ImageInputStream stream;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected long offset;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int byteCount;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int srcMinX;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int srcMinY;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int srcWidth;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int srcHeight;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int sourceXOffset;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int dstXOffset;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int sourceYOffset;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int dstYOffset;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int subsampleX;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int subsampleY;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int[] sourceBands;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int[] destinationBands;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected BufferedImage rawImage;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected BufferedImage image;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int dstMinX;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int dstMinY;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int dstWidth;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int dstHeight;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int activeSrcMinX;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int activeSrcMinY;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int activeSrcWidth;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int activeSrcHeight;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected TIFFColorConverter colorConverter;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isBilevel;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isContiguous;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isImageSimple;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean adjustBitDepths;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int[][] bitDepthScale;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static SampleModel createInterleavedSM(int dataType, int numBands) {
/*  491 */     int[] bandOffsets = new int[numBands];
/*  492 */     for (int i = 0; i < numBands; i++) {
/*  493 */       bandOffsets[i] = i;
/*      */     }
/*  495 */     return new PixelInterleavedSampleModel(dataType, 1, 1, numBands, numBands, bandOffsets);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static ColorModel createComponentCM(ColorSpace colorSpace, int numBands, int dataType, boolean hasAlpha, boolean isAlphaPremultiplied) {
/*      */     ColorModel colorModel;
/*  514 */     int transparency = hasAlpha ? 3 : 1;
/*      */ 
/*      */ 
/*      */     
/*  518 */     if (dataType == 4 || dataType == 5) {
/*      */ 
/*      */       
/*  521 */       colorModel = new ComponentColorModel(colorSpace, hasAlpha, isAlphaPremultiplied, transparency, dataType);
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */       
/*  527 */       int bits, numBits[] = new int[numBands];
/*      */       
/*  529 */       if (dataType == 0) {
/*  530 */         bits = 8;
/*  531 */       } else if (dataType == 2 || dataType == 1) {
/*      */         
/*  533 */         bits = 16;
/*  534 */       } else if (dataType == 3) {
/*  535 */         bits = 32;
/*      */       } else {
/*  537 */         throw new IllegalArgumentException("dataType = " + dataType);
/*      */       } 
/*  539 */       for (int i = 0; i < numBands; i++) {
/*  540 */         numBits[i] = bits;
/*      */       }
/*      */       
/*  543 */       colorModel = new ComponentColorModel(colorSpace, numBits, hasAlpha, isAlphaPremultiplied, transparency, dataType);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  551 */     return colorModel;
/*      */   }
/*      */   
/*      */   private static int createMask(int[] bitsPerSample, int band) {
/*  555 */     int mask = (1 << bitsPerSample[band]) - 1;
/*  556 */     for (int i = band + 1; i < bitsPerSample.length; i++) {
/*  557 */       mask <<= bitsPerSample[i];
/*      */     }
/*      */     
/*  560 */     return mask;
/*      */   }
/*      */ 
/*      */   
/*      */   private static int getDataTypeFromNumBits(int numBits, boolean isSigned) {
/*      */     int dataType;
/*  566 */     if (numBits <= 8) {
/*  567 */       dataType = 0;
/*  568 */     } else if (numBits <= 16) {
/*  569 */       dataType = isSigned ? 2 : 1;
/*      */     } else {
/*      */       
/*  572 */       dataType = 3;
/*      */     } 
/*      */     
/*  575 */     return dataType;
/*      */   }
/*      */   
/*      */   private static boolean areIntArraysEqual(int[] a, int[] b) {
/*  579 */     if (a == null || b == null) {
/*  580 */       if (a == null && b == null) {
/*  581 */         return true;
/*      */       }
/*  583 */       return false;
/*      */     } 
/*      */ 
/*      */     
/*  587 */     if (a.length != b.length) {
/*  588 */       return false;
/*      */     }
/*      */     
/*  591 */     int length = a.length;
/*  592 */     for (int i = 0; i < length; i++) {
/*  593 */       if (a[i] != b[i]) {
/*  594 */         return false;
/*      */       }
/*      */     } 
/*      */     
/*  598 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int getDataTypeSize(int dataType) throws IIOException {
/*  606 */     int dataTypeSize = 0;
/*  607 */     switch (dataType) {
/*      */       case 0:
/*  609 */         dataTypeSize = 8;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  626 */         return dataTypeSize;case 1: case 2: dataTypeSize = 16; return dataTypeSize;case 3: case 4: dataTypeSize = 32; return dataTypeSize;case 5: dataTypeSize = 64; return dataTypeSize;
/*      */     } 
/*      */     throw new IIOException("Unknown data type " + dataType);
/*      */   }
/*      */ 
/*      */   
/*      */   private static int getBitsPerPixel(SampleModel sm) {
/*  633 */     int bitsPerPixel = 0;
/*  634 */     int[] sampleSize = sm.getSampleSize();
/*  635 */     int numBands = sampleSize.length;
/*  636 */     for (int i = 0; i < numBands; i++) {
/*  637 */       bitsPerPixel += sampleSize[i];
/*      */     }
/*  639 */     return bitsPerPixel;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean areSampleSizesEqual(SampleModel sm) {
/*  646 */     boolean allSameSize = true;
/*  647 */     int[] sampleSize = sm.getSampleSize();
/*  648 */     int sampleSize0 = sampleSize[0];
/*  649 */     int numBands = sampleSize.length;
/*      */     
/*  651 */     for (int i = 1; i < numBands; i++) {
/*  652 */       if (sampleSize[i] != sampleSize0) {
/*  653 */         allSameSize = false;
/*      */         
/*      */         break;
/*      */       } 
/*      */     } 
/*  658 */     return allSameSize;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean isDataBufferBitContiguous(SampleModel sm) throws IIOException {
/*  667 */     int dataTypeSize = getDataTypeSize(sm.getDataType());
/*      */     
/*  669 */     if (sm instanceof ComponentSampleModel) {
/*  670 */       int numBands = sm.getNumBands();
/*  671 */       for (int i = 0; i < numBands; i++) {
/*  672 */         if (sm.getSampleSize(i) != dataTypeSize)
/*      */         {
/*  674 */           return false;
/*      */         }
/*      */       } 
/*  677 */     } else if (sm instanceof MultiPixelPackedSampleModel) {
/*  678 */       MultiPixelPackedSampleModel mppsm = (MultiPixelPackedSampleModel)sm;
/*      */       
/*  680 */       if (dataTypeSize % mppsm.getPixelBitStride() != 0)
/*      */       {
/*  682 */         return false;
/*      */       }
/*  684 */     } else if (sm instanceof SinglePixelPackedSampleModel) {
/*  685 */       SinglePixelPackedSampleModel sppsm = (SinglePixelPackedSampleModel)sm;
/*      */       
/*  687 */       int numBands = sm.getNumBands();
/*  688 */       int numBits = 0;
/*  689 */       for (int i = 0; i < numBands; i++) {
/*  690 */         numBits += sm.getSampleSize(i);
/*      */       }
/*  692 */       if (numBits != dataTypeSize)
/*      */       {
/*  694 */         return false;
/*      */       }
/*      */     } else {
/*      */       
/*  698 */       return false;
/*      */     } 
/*      */     
/*  701 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void reformatData(byte[] buf, int bytesPerRow, int numRows, short[] shortData, int[] intData, int outOffset, int outStride) throws IIOException {
/*  716 */     if (shortData != null) {
/*      */ 
/*      */ 
/*      */       
/*  720 */       int inOffset = 0;
/*  721 */       int shortsPerRow = bytesPerRow / 2;
/*  722 */       int numExtraBytes = bytesPerRow % 2;
/*  723 */       for (int j = 0; j < numRows; j++) {
/*  724 */         int k = outOffset;
/*  725 */         for (int i = 0; i < shortsPerRow; i++) {
/*  726 */           shortData[k++] = (short)((buf[inOffset++] & 0xFF) << 8 | buf[inOffset++] & 0xFF);
/*      */         }
/*      */ 
/*      */         
/*  730 */         if (numExtraBytes != 0) {
/*  731 */           shortData[k++] = (short)((buf[inOffset++] & 0xFF) << 8);
/*      */         }
/*  733 */         outOffset += outStride;
/*      */       } 
/*  735 */     } else if (intData != null) {
/*      */ 
/*      */ 
/*      */       
/*  739 */       int inOffset = 0;
/*  740 */       int intsPerRow = bytesPerRow / 4;
/*  741 */       int numExtraBytes = bytesPerRow % 4;
/*  742 */       for (int j = 0; j < numRows; j++) {
/*  743 */         int k = outOffset;
/*  744 */         for (int i = 0; i < intsPerRow; i++) {
/*  745 */           intData[k++] = (buf[inOffset++] & 0xFF) << 24 | (buf[inOffset++] & 0xFF) << 16 | (buf[inOffset++] & 0xFF) << 8 | buf[inOffset++] & 0xFF;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  751 */         if (numExtraBytes != 0) {
/*  752 */           int shift = 24;
/*  753 */           int ival = 0;
/*  754 */           for (int b = 0; b < numExtraBytes; b++) {
/*  755 */             ival |= (buf[inOffset++] & 0xFF) << shift;
/*  756 */             shift -= 8;
/*      */           } 
/*  758 */           intData[k++] = ival;
/*      */         } 
/*  760 */         outOffset += outStride;
/*      */       } 
/*      */     } else {
/*  763 */       throw new IIOException("shortData == null && intData == null!");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void reformatDiscontiguousData(byte[] buf, int stride, int w, int h, WritableRaster raster) throws IOException {
/*  783 */     SampleModel sm = raster.getSampleModel();
/*  784 */     int numBands = sm.getNumBands();
/*  785 */     int[] sampleSize = sm.getSampleSize();
/*      */ 
/*      */     
/*  788 */     ByteArrayInputStream is = new ByteArrayInputStream(buf);
/*  789 */     ImageInputStream iis = new MemoryCacheImageInputStream(is);
/*      */ 
/*      */     
/*  792 */     long iisPosition = 0L;
/*  793 */     int y = raster.getMinY();
/*  794 */     for (int j = 0; j < h; j++, y++) {
/*  795 */       iis.seek(iisPosition);
/*  796 */       int x = raster.getMinX();
/*  797 */       for (int i = 0; i < w; i++, x++) {
/*  798 */         for (int b = 0; b < numBands; b++) {
/*  799 */           long bits = iis.readBits(sampleSize[b]);
/*  800 */           raster.setSample(x, y, b, (int)bits);
/*      */         } 
/*      */       } 
/*  803 */       iisPosition += stride;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImageTypeSpecifier getRawImageTypeSpecifier(int photometricInterpretation, int compression, int samplesPerPixel, int[] bitsPerSample, int[] sampleFormat, int[] extraSamples, char[] colorMap) {
/*  885 */     if (samplesPerPixel == 1 && (bitsPerSample[0] == 1 || bitsPerSample[0] == 2 || bitsPerSample[0] == 4 || bitsPerSample[0] == 8 || bitsPerSample[0] == 16)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  898 */       if (colorMap == null) {
/*      */         int k;
/*  900 */         boolean isSigned = (sampleFormat[0] == 2);
/*      */ 
/*      */         
/*  903 */         if (bitsPerSample[0] <= 8) {
/*  904 */           k = 0;
/*      */         } else {
/*  906 */           k = (sampleFormat[0] == 2) ? 2 : 1;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  912 */         return ImageTypeSpecifier.createGrayscale(bitsPerSample[0], k, isSigned);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  917 */       int mapSize = 1 << bitsPerSample[0];
/*  918 */       byte[] redLut = new byte[mapSize];
/*  919 */       byte[] greenLut = new byte[mapSize];
/*  920 */       byte[] blueLut = new byte[mapSize];
/*  921 */       byte[] alphaLut = null;
/*      */       
/*  923 */       int idx = 0;
/*  924 */       for (int j = 0; j < mapSize; j++) {
/*  925 */         redLut[j] = (byte)(colorMap[j] * 255 / 65535);
/*  926 */         greenLut[j] = (byte)(colorMap[mapSize + j] * 255 / 65535);
/*  927 */         blueLut[j] = (byte)(colorMap[2 * mapSize + j] * 255 / 65535);
/*      */       } 
/*      */       
/*  930 */       int dataType = (bitsPerSample[0] == 8) ? 0 : 1;
/*      */       
/*  932 */       return ImageTypeSpecifier.createIndexed(redLut, greenLut, blueLut, alphaLut, bitsPerSample[0], dataType);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  942 */     if (samplesPerPixel == 2 && bitsPerSample[0] == 8 && bitsPerSample[1] == 8) {
/*      */ 
/*      */       
/*  945 */       int dataType = 0;
/*  946 */       boolean alphaPremultiplied = false;
/*  947 */       if (extraSamples != null && extraSamples[0] == 1)
/*      */       {
/*      */         
/*  950 */         alphaPremultiplied = true;
/*      */       }
/*      */       
/*  953 */       return ImageTypeSpecifier.createGrayscale(8, dataType, false, alphaPremultiplied);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  960 */     if (samplesPerPixel == 2 && bitsPerSample[0] == 16 && bitsPerSample[1] == 16) {
/*      */ 
/*      */       
/*  963 */       int dataType = (sampleFormat[0] == 2) ? 2 : 1;
/*      */ 
/*      */ 
/*      */       
/*  967 */       boolean alphaPremultiplied = false;
/*  968 */       if (extraSamples != null && extraSamples[0] == 1)
/*      */       {
/*      */         
/*  971 */         alphaPremultiplied = true;
/*      */       }
/*      */       
/*  974 */       boolean isSigned = (dataType == 2);
/*  975 */       return ImageTypeSpecifier.createGrayscale(16, dataType, isSigned, alphaPremultiplied);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  981 */     ColorSpace rgb = ColorSpace.getInstance(1000);
/*      */ 
/*      */     
/*  984 */     if (samplesPerPixel == 3 && bitsPerSample[0] == 8 && bitsPerSample[1] == 8 && bitsPerSample[2] == 8) {
/*      */       ColorSpace theColorSpace;
/*      */ 
/*      */       
/*  988 */       int[] bandOffsets = new int[3];
/*  989 */       bandOffsets[0] = 0;
/*  990 */       bandOffsets[1] = 1;
/*  991 */       bandOffsets[2] = 2;
/*  992 */       int dataType = 0;
/*      */       
/*  994 */       if ((photometricInterpretation == 6 && compression != 7 && compression != 6) || photometricInterpretation == 8) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1000 */         theColorSpace = ColorSpace.getInstance(1004);
/*      */       } else {
/*      */         
/* 1003 */         theColorSpace = rgb;
/*      */       } 
/* 1005 */       return ImageTypeSpecifier.createInterleaved(theColorSpace, bandOffsets, dataType, false, false);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1013 */     if (samplesPerPixel == 4 && bitsPerSample[0] == 8 && bitsPerSample[1] == 8 && bitsPerSample[2] == 8 && bitsPerSample[3] == 8) {
/*      */       ColorSpace theColorSpace;
/*      */       
/*      */       boolean hasAlpha;
/*      */       
/* 1018 */       int[] bandOffsets = new int[4];
/* 1019 */       bandOffsets[0] = 0;
/* 1020 */       bandOffsets[1] = 1;
/* 1021 */       bandOffsets[2] = 2;
/* 1022 */       bandOffsets[3] = 3;
/* 1023 */       int dataType = 0;
/*      */ 
/*      */ 
/*      */       
/* 1027 */       boolean alphaPremultiplied = false;
/* 1028 */       if (photometricInterpretation == 5) {
/*      */         
/* 1030 */         theColorSpace = SimpleCMYKColorSpace.getInstance();
/* 1031 */         hasAlpha = false;
/*      */       } else {
/* 1033 */         theColorSpace = rgb;
/* 1034 */         hasAlpha = true;
/* 1035 */         if (extraSamples != null && extraSamples[0] == 1)
/*      */         {
/*      */           
/* 1038 */           alphaPremultiplied = true;
/*      */         }
/*      */       } 
/*      */       
/* 1042 */       return ImageTypeSpecifier.createInterleaved(theColorSpace, bandOffsets, dataType, hasAlpha, alphaPremultiplied);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1050 */     if (samplesPerPixel == 3 && bitsPerSample[0] == 16 && bitsPerSample[1] == 16 && bitsPerSample[2] == 16) {
/*      */ 
/*      */ 
/*      */       
/* 1054 */       int[] bandOffsets = new int[3];
/* 1055 */       bandOffsets[0] = 0;
/* 1056 */       bandOffsets[1] = 1;
/* 1057 */       bandOffsets[2] = 2;
/* 1058 */       int dataType = (sampleFormat[0] == 2) ? 2 : 1;
/*      */ 
/*      */ 
/*      */       
/* 1062 */       return ImageTypeSpecifier.createInterleaved(rgb, bandOffsets, dataType, false, false);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1070 */     if (samplesPerPixel == 4 && bitsPerSample[0] == 16 && bitsPerSample[1] == 16 && bitsPerSample[2] == 16 && bitsPerSample[3] == 16) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1075 */       int[] bandOffsets = new int[4];
/* 1076 */       bandOffsets[0] = 0;
/* 1077 */       bandOffsets[1] = 1;
/* 1078 */       bandOffsets[2] = 2;
/* 1079 */       bandOffsets[3] = 3;
/* 1080 */       int dataType = (sampleFormat[0] == 2) ? 2 : 1;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1085 */       boolean alphaPremultiplied = false;
/* 1086 */       if (extraSamples != null && extraSamples[0] == 1)
/*      */       {
/*      */         
/* 1089 */         alphaPremultiplied = true;
/*      */       }
/* 1091 */       return ImageTypeSpecifier.createInterleaved(rgb, bandOffsets, dataType, true, alphaPremultiplied);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1100 */     if (photometricInterpretation == 5 && (bitsPerSample[0] == 1 || bitsPerSample[0] == 2 || bitsPerSample[0] == 4)) {
/*      */       BogusColorSpace bogusColorSpace;
/*      */ 
/*      */       
/* 1104 */       ColorSpace cs = null;
/* 1105 */       if (samplesPerPixel == 4) {
/* 1106 */         cs = SimpleCMYKColorSpace.getInstance();
/*      */       } else {
/* 1108 */         bogusColorSpace = new BogusColorSpace(samplesPerPixel);
/*      */       } 
/*      */       
/* 1111 */       ColorModel cm = new ComponentColorModel((ColorSpace)bogusColorSpace, bitsPerSample, false, false, 1, 0);
/*      */ 
/*      */ 
/*      */       
/* 1115 */       return new ImageTypeSpecifier(cm, cm.createCompatibleSampleModel(1, 1));
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1120 */     int totalBits = 0;
/* 1121 */     for (int i = 0; i < bitsPerSample.length; i++) {
/* 1122 */       totalBits += bitsPerSample[i];
/*      */     }
/*      */ 
/*      */     
/* 1126 */     if ((samplesPerPixel == 3 || samplesPerPixel == 4) && (totalBits == 8 || totalBits == 16)) {
/*      */       
/* 1128 */       int redMask = createMask(bitsPerSample, 0);
/* 1129 */       int greenMask = createMask(bitsPerSample, 1);
/* 1130 */       int blueMask = createMask(bitsPerSample, 2);
/* 1131 */       int alphaMask = (samplesPerPixel == 4) ? createMask(bitsPerSample, 3) : 0;
/*      */       
/* 1133 */       int transferType = (totalBits == 8) ? 0 : 1;
/*      */       
/* 1135 */       boolean alphaPremultiplied = false;
/* 1136 */       if (extraSamples != null && extraSamples[0] == 1)
/*      */       {
/*      */         
/* 1139 */         alphaPremultiplied = true;
/*      */       }
/* 1141 */       return ImageTypeSpecifier.createPacked(rgb, redMask, greenMask, blueMask, alphaMask, transferType, alphaPremultiplied);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1151 */     if (bitsPerSample[0] % 8 == 0) {
/*      */       
/* 1153 */       boolean allSameBitDepth = true;
/* 1154 */       for (int j = 1; j < bitsPerSample.length; j++) {
/* 1155 */         if (bitsPerSample[j] != bitsPerSample[j - 1]) {
/* 1156 */           allSameBitDepth = false;
/*      */           
/*      */           break;
/*      */         } 
/*      */       } 
/*      */       
/* 1162 */       if (allSameBitDepth) {
/*      */         
/* 1164 */         int dataType = -1;
/* 1165 */         boolean isDataTypeSet = false;
/* 1166 */         switch (bitsPerSample[0]) {
/*      */           case 8:
/* 1168 */             if (sampleFormat[0] != 3) {
/*      */ 
/*      */ 
/*      */               
/* 1172 */               dataType = 0;
/* 1173 */               isDataTypeSet = true;
/*      */             } 
/*      */             break;
/*      */           case 16:
/* 1177 */             if (sampleFormat[0] != 3) {
/*      */               
/* 1179 */               if (sampleFormat[0] == 2) {
/*      */                 
/* 1181 */                 dataType = 2;
/*      */               } else {
/* 1183 */                 dataType = 1;
/*      */               } 
/* 1185 */               isDataTypeSet = true;
/*      */             } 
/*      */             break;
/*      */           case 32:
/* 1189 */             if (sampleFormat[0] == 3) {
/*      */               
/* 1191 */               dataType = 4;
/*      */             } else {
/* 1193 */               dataType = 3;
/*      */             } 
/* 1195 */             isDataTypeSet = true;
/*      */             break;
/*      */         } 
/*      */         
/* 1199 */         if (isDataTypeSet) {
/*      */           ColorModel cm;
/* 1201 */           SampleModel sm = createInterleavedSM(dataType, samplesPerPixel);
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1206 */           if (samplesPerPixel >= 1 && samplesPerPixel <= 4 && (dataType == 3 || dataType == 4)) {
/*      */ 
/*      */ 
/*      */             
/* 1210 */             ColorSpace cs = (samplesPerPixel <= 2) ? ColorSpace.getInstance(1003) : rgb;
/*      */             
/* 1212 */             boolean hasAlpha = (samplesPerPixel % 2 == 0);
/* 1213 */             boolean alphaPremultiplied = false;
/* 1214 */             if (hasAlpha && extraSamples != null && extraSamples[0] == 1)
/*      */             {
/*      */               
/* 1217 */               alphaPremultiplied = true;
/*      */             }
/*      */             
/* 1220 */             cm = createComponentCM(cs, samplesPerPixel, dataType, hasAlpha, alphaPremultiplied);
/*      */           
/*      */           }
/*      */           else {
/*      */ 
/*      */             
/* 1226 */             BogusColorSpace bogusColorSpace = new BogusColorSpace(samplesPerPixel);
/* 1227 */             cm = createComponentCM((ColorSpace)bogusColorSpace, samplesPerPixel, dataType, false, false);
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1234 */           return new ImageTypeSpecifier(cm, sm);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1242 */     if (colorMap == null && sampleFormat[0] != 3) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1247 */       int maxBitsPerSample = 0;
/* 1248 */       for (int j = 0; j < bitsPerSample.length; j++) {
/* 1249 */         if (bitsPerSample[j] > maxBitsPerSample) {
/* 1250 */           maxBitsPerSample = bitsPerSample[j];
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/* 1255 */       boolean isSigned = (sampleFormat[0] == 2);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1260 */       if (samplesPerPixel == 1) {
/* 1261 */         int dataType = getDataTypeFromNumBits(maxBitsPerSample, isSigned);
/*      */ 
/*      */         
/* 1264 */         return ImageTypeSpecifier.createGrayscale(maxBitsPerSample, dataType, isSigned);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1270 */       if (samplesPerPixel == 2) {
/* 1271 */         boolean alphaPremultiplied = false;
/* 1272 */         if (extraSamples != null && extraSamples[0] == 1)
/*      */         {
/*      */           
/* 1275 */           alphaPremultiplied = true;
/*      */         }
/*      */         
/* 1278 */         int dataType = getDataTypeFromNumBits(maxBitsPerSample, isSigned);
/*      */ 
/*      */         
/* 1281 */         return ImageTypeSpecifier.createGrayscale(maxBitsPerSample, dataType, false, alphaPremultiplied);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1287 */       if (samplesPerPixel == 3 || samplesPerPixel == 4) {
/* 1288 */         if (totalBits <= 32 && !isSigned) {
/*      */           
/* 1290 */           int redMask = createMask(bitsPerSample, 0);
/* 1291 */           int greenMask = createMask(bitsPerSample, 1);
/* 1292 */           int blueMask = createMask(bitsPerSample, 2);
/* 1293 */           int alphaMask = (samplesPerPixel == 4) ? createMask(bitsPerSample, 3) : 0;
/*      */           
/* 1295 */           int transferType = getDataTypeFromNumBits(totalBits, false);
/*      */           
/* 1297 */           boolean alphaPremultiplied = false;
/* 1298 */           if (extraSamples != null && extraSamples[0] == 1)
/*      */           {
/*      */             
/* 1301 */             alphaPremultiplied = true;
/*      */           }
/* 1303 */           return ImageTypeSpecifier.createPacked(rgb, redMask, greenMask, blueMask, alphaMask, transferType, alphaPremultiplied);
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1310 */         if (samplesPerPixel == 3) {
/*      */           
/* 1312 */           int[] bandOffsets = { 0, 1, 2 };
/* 1313 */           int dataType = getDataTypeFromNumBits(maxBitsPerSample, isSigned);
/*      */           
/* 1315 */           return ImageTypeSpecifier.createInterleaved(rgb, bandOffsets, dataType, false, false);
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 1320 */         if (samplesPerPixel == 4)
/*      */         {
/* 1322 */           int[] bandOffsets = { 0, 1, 2, 3 };
/* 1323 */           int dataType = getDataTypeFromNumBits(maxBitsPerSample, isSigned);
/*      */           
/* 1325 */           boolean alphaPremultiplied = false;
/* 1326 */           if (extraSamples != null && extraSamples[0] == 1)
/*      */           {
/*      */             
/* 1329 */             alphaPremultiplied = true;
/*      */           }
/* 1331 */           return ImageTypeSpecifier.createInterleaved(rgb, bandOffsets, dataType, true, alphaPremultiplied);
/*      */         
/*      */         }
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */         
/* 1339 */         int dataType = getDataTypeFromNumBits(maxBitsPerSample, isSigned);
/*      */         
/* 1341 */         SampleModel sm = createInterleavedSM(dataType, samplesPerPixel);
/*      */         
/* 1343 */         BogusColorSpace bogusColorSpace = new BogusColorSpace(samplesPerPixel);
/* 1344 */         ColorModel cm = createComponentCM((ColorSpace)bogusColorSpace, samplesPerPixel, dataType, false, false);
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1349 */         return new ImageTypeSpecifier(cm, sm);
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1386 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setReader(ImageReader reader) {
/* 1399 */     this.reader = reader;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMetadata(IIOMetadata metadata) {
/* 1413 */     this.metadata = metadata;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPhotometricInterpretation(int photometricInterpretation) {
/* 1428 */     this.photometricInterpretation = photometricInterpretation;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCompression(int compression) {
/* 1441 */     this.compression = compression;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPlanar(boolean planar) {
/* 1455 */     this.planar = planar;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSamplesPerPixel(int samplesPerPixel) {
/* 1469 */     this.samplesPerPixel = samplesPerPixel;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBitsPerSample(int[] bitsPerSample) {
/* 1483 */     this.bitsPerSample = (bitsPerSample == null) ? null : (int[])bitsPerSample.clone();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSampleFormat(int[] sampleFormat) {
/* 1498 */     (new int[1])[0] = 1; this.sampleFormat = (sampleFormat == null) ? new int[1] : (int[])sampleFormat.clone();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setExtraSamples(int[] extraSamples) {
/* 1515 */     this.extraSamples = (extraSamples == null) ? null : (int[])extraSamples.clone();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setColorMap(char[] colorMap) {
/* 1530 */     this.colorMap = (colorMap == null) ? null : (char[])colorMap.clone();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setStream(ImageInputStream stream) {
/* 1544 */     this.stream = stream;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setOffset(long offset) {
/* 1558 */     this.offset = offset;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setByteCount(int byteCount) {
/* 1571 */     this.byteCount = byteCount;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSrcMinX(int srcMinX) {
/* 1588 */     this.srcMinX = srcMinX;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSrcMinY(int srcMinY) {
/* 1603 */     this.srcMinY = srcMinY;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSrcWidth(int srcWidth) {
/* 1617 */     this.srcWidth = srcWidth;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSrcHeight(int srcHeight) {
/* 1631 */     this.srcHeight = srcHeight;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSourceXOffset(int sourceXOffset) {
/* 1647 */     this.sourceXOffset = sourceXOffset;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDstXOffset(int dstXOffset) {
/* 1661 */     this.dstXOffset = dstXOffset;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSourceYOffset(int sourceYOffset) {
/* 1675 */     this.sourceYOffset = sourceYOffset;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDstYOffset(int dstYOffset) {
/* 1689 */     this.dstYOffset = dstYOffset;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSubsampleX(int subsampleX) {
/* 1707 */     if (subsampleX <= 0) {
/* 1708 */       throw new IllegalArgumentException("subsampleX <= 0!");
/*      */     }
/* 1710 */     this.subsampleX = subsampleX;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSubsampleY(int subsampleY) {
/* 1726 */     if (subsampleY <= 0) {
/* 1727 */       throw new IllegalArgumentException("subsampleY <= 0!");
/*      */     }
/* 1729 */     this.subsampleY = subsampleY;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSourceBands(int[] sourceBands) {
/* 1745 */     this.sourceBands = (sourceBands == null) ? null : (int[])sourceBands.clone();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDestinationBands(int[] destinationBands) {
/* 1760 */     this.destinationBands = (destinationBands == null) ? null : (int[])destinationBands.clone();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setImage(BufferedImage image) {
/* 1776 */     this.image = image;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDstMinX(int dstMinX) {
/* 1790 */     this.dstMinX = dstMinX;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDstMinY(int dstMinY) {
/* 1804 */     this.dstMinY = dstMinY;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDstWidth(int dstWidth) {
/* 1817 */     this.dstWidth = dstWidth;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDstHeight(int dstHeight) {
/* 1830 */     this.dstHeight = dstHeight;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setActiveSrcMinX(int activeSrcMinX) {
/* 1846 */     this.activeSrcMinX = activeSrcMinX;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setActiveSrcMinY(int activeSrcMinY) {
/* 1860 */     this.activeSrcMinY = activeSrcMinY;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setActiveSrcWidth(int activeSrcWidth) {
/* 1873 */     this.activeSrcWidth = activeSrcWidth;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setActiveSrcHeight(int activeSrcHeight) {
/* 1886 */     this.activeSrcHeight = activeSrcHeight;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setColorConverter(TIFFColorConverter colorConverter) {
/* 1898 */     this.colorConverter = colorConverter;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImageTypeSpecifier getRawImageType() {
/* 1909 */     ImageTypeSpecifier its = getRawImageTypeSpecifier(this.photometricInterpretation, this.compression, this.samplesPerPixel, this.bitsPerSample, this.sampleFormat, this.extraSamples, this.colorMap);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1917 */     return its;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BufferedImage createRawImage() {
/* 1936 */     if (this.planar) {
/*      */ 
/*      */ 
/*      */       
/* 1940 */       int dataType, bps = this.bitsPerSample[this.sourceBands[0]];
/*      */ 
/*      */ 
/*      */       
/* 1944 */       if (this.sampleFormat[0] == 3) {
/*      */         
/* 1946 */         dataType = 4;
/* 1947 */       } else if (bps <= 8) {
/* 1948 */         dataType = 0;
/* 1949 */       } else if (bps <= 16) {
/* 1950 */         if (this.sampleFormat[0] == 2) {
/*      */           
/* 1952 */           dataType = 2;
/*      */         } else {
/* 1954 */           dataType = 1;
/*      */         } 
/*      */       } else {
/* 1957 */         dataType = 3;
/*      */       } 
/*      */       
/* 1960 */       ColorSpace csGray = ColorSpace.getInstance(1003);
/*      */       
/* 1962 */       ImageTypeSpecifier imageTypeSpecifier = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1968 */       if (bps == 1 || bps == 2 || bps == 4) {
/* 1969 */         int bits = bps;
/* 1970 */         int size = 1 << bits;
/* 1971 */         byte[] r = new byte[size];
/* 1972 */         byte[] g = new byte[size];
/* 1973 */         byte[] b = new byte[size];
/* 1974 */         for (int j = 0; j < r.length; j++) {
/* 1975 */           r[j] = 0;
/* 1976 */           g[j] = 0;
/* 1977 */           b[j] = 0;
/*      */         } 
/* 1979 */         ColorModel cmGray = new IndexColorModel(bits, size, r, g, b);
/* 1980 */         SampleModel smGray = new MultiPixelPackedSampleModel(0, 1, 1, bits);
/* 1981 */         imageTypeSpecifier = new ImageTypeSpecifier(cmGray, smGray);
/*      */       } else {
/*      */         
/* 1984 */         imageTypeSpecifier = ImageTypeSpecifier.createInterleaved(csGray, new int[] { 0 }, dataType, false, false);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1991 */       return imageTypeSpecifier.createBufferedImage(this.srcWidth, this.srcHeight);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1998 */     ImageTypeSpecifier its = getRawImageType();
/* 1999 */     if (its == null) {
/* 2000 */       return null;
/*      */     }
/*      */     
/* 2003 */     BufferedImage bi = its.createBufferedImage(this.srcWidth, this.srcHeight);
/* 2004 */     return bi;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void decodeRaw(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, int paramInt3) throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void decodeRaw(short[] s, int dstOffset, int bitsPerPixel, int scanlineStride) throws IOException {
/* 2056 */     int bytesPerRow = (this.srcWidth * bitsPerPixel + 7) / 8;
/* 2057 */     int shortsPerRow = bytesPerRow / 2;
/*      */     
/* 2059 */     byte[] b = new byte[bytesPerRow * this.srcHeight];
/* 2060 */     decodeRaw(b, 0, bitsPerPixel, bytesPerRow);
/*      */     
/* 2062 */     int bOffset = 0;
/* 2063 */     if (this.stream.getByteOrder() == ByteOrder.BIG_ENDIAN) {
/* 2064 */       for (int j = 0; j < this.srcHeight; j++) {
/* 2065 */         for (int i = 0; i < shortsPerRow; i++) {
/* 2066 */           short hiVal = (short)b[bOffset++];
/* 2067 */           short loVal = (short)b[bOffset++];
/* 2068 */           short sval = (short)(hiVal << 8 | loVal & 0xFF);
/* 2069 */           s[dstOffset + i] = sval;
/*      */         } 
/*      */         
/* 2072 */         dstOffset += scanlineStride;
/*      */       } 
/*      */     } else {
/* 2075 */       for (int j = 0; j < this.srcHeight; j++) {
/* 2076 */         for (int i = 0; i < shortsPerRow; i++) {
/* 2077 */           short loVal = (short)b[bOffset++];
/* 2078 */           short hiVal = (short)b[bOffset++];
/* 2079 */           short sval = (short)(hiVal << 8 | loVal & 0xFF);
/* 2080 */           s[dstOffset + i] = sval;
/*      */         } 
/*      */         
/* 2083 */         dstOffset += scanlineStride;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void decodeRaw(int[] i, int dstOffset, int bitsPerPixel, int scanlineStride) throws IOException {
/* 2113 */     int numBands = bitsPerPixel / 32;
/* 2114 */     int intsPerRow = this.srcWidth * numBands;
/* 2115 */     int bytesPerRow = intsPerRow * 4;
/*      */     
/* 2117 */     byte[] b = new byte[bytesPerRow * this.srcHeight];
/* 2118 */     decodeRaw(b, 0, bitsPerPixel, bytesPerRow);
/*      */     
/* 2120 */     int bOffset = 0;
/* 2121 */     if (this.stream.getByteOrder() == ByteOrder.BIG_ENDIAN) {
/* 2122 */       for (int j = 0; j < this.srcHeight; j++) {
/* 2123 */         for (int k = 0; k < intsPerRow; k++) {
/* 2124 */           int v0 = b[bOffset++] & 0xFF;
/* 2125 */           int v1 = b[bOffset++] & 0xFF;
/* 2126 */           int v2 = b[bOffset++] & 0xFF;
/* 2127 */           int v3 = b[bOffset++] & 0xFF;
/* 2128 */           int ival = v0 << 24 | v1 << 16 | v2 << 8 | v3;
/* 2129 */           i[dstOffset + k] = ival;
/*      */         } 
/*      */         
/* 2132 */         dstOffset += scanlineStride;
/*      */       } 
/*      */     } else {
/* 2135 */       for (int j = 0; j < this.srcHeight; j++) {
/* 2136 */         for (int k = 0; k < intsPerRow; k++) {
/* 2137 */           int v3 = b[bOffset++] & 0xFF;
/* 2138 */           int v2 = b[bOffset++] & 0xFF;
/* 2139 */           int v1 = b[bOffset++] & 0xFF;
/* 2140 */           int v0 = b[bOffset++] & 0xFF;
/* 2141 */           int ival = v0 << 24 | v1 << 16 | v2 << 8 | v3;
/* 2142 */           i[dstOffset + k] = ival;
/*      */         } 
/*      */         
/* 2145 */         dstOffset += scanlineStride;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void decodeRaw(float[] f, int dstOffset, int bitsPerPixel, int scanlineStride) throws IOException {
/* 2175 */     int numBands = bitsPerPixel / 32;
/* 2176 */     int floatsPerRow = this.srcWidth * numBands;
/* 2177 */     int bytesPerRow = floatsPerRow * 4;
/*      */     
/* 2179 */     byte[] b = new byte[bytesPerRow * this.srcHeight];
/* 2180 */     decodeRaw(b, 0, bitsPerPixel, bytesPerRow);
/*      */     
/* 2182 */     int bOffset = 0;
/* 2183 */     if (this.stream.getByteOrder() == ByteOrder.BIG_ENDIAN) {
/* 2184 */       for (int j = 0; j < this.srcHeight; j++) {
/* 2185 */         for (int i = 0; i < floatsPerRow; i++) {
/* 2186 */           int v0 = b[bOffset++] & 0xFF;
/* 2187 */           int v1 = b[bOffset++] & 0xFF;
/* 2188 */           int v2 = b[bOffset++] & 0xFF;
/* 2189 */           int v3 = b[bOffset++] & 0xFF;
/* 2190 */           int ival = v0 << 24 | v1 << 16 | v2 << 8 | v3;
/* 2191 */           float fval = Float.intBitsToFloat(ival);
/* 2192 */           f[dstOffset + i] = fval;
/*      */         } 
/*      */         
/* 2195 */         dstOffset += scanlineStride;
/*      */       } 
/*      */     } else {
/* 2198 */       for (int j = 0; j < this.srcHeight; j++) {
/* 2199 */         for (int i = 0; i < floatsPerRow; i++) {
/* 2200 */           int v3 = b[bOffset++] & 0xFF;
/* 2201 */           int v2 = b[bOffset++] & 0xFF;
/* 2202 */           int v1 = b[bOffset++] & 0xFF;
/* 2203 */           int v0 = b[bOffset++] & 0xFF;
/* 2204 */           int ival = v0 << 24 | v1 << 16 | v2 << 8 | v3;
/* 2205 */           float fval = Float.intBitsToFloat(ival);
/* 2206 */           f[dstOffset + i] = fval;
/*      */         } 
/*      */         
/* 2209 */         dstOffset += scanlineStride;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean isFirstBitDepthTable = true;
/*      */   
/*      */   private boolean planarCache = false;
/*      */   
/* 2219 */   private int[] destBitsPerSampleCache = null;
/* 2220 */   private int[] sourceBandsCache = null;
/* 2221 */   private int[] bitsPerSampleCache = null;
/* 2222 */   private int[] destinationBandsCache = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void beginDecoding() {
/* 2246 */     this.adjustBitDepths = false;
/* 2247 */     int numBands = this.destinationBands.length;
/* 2248 */     int[] destBitsPerSample = null;
/* 2249 */     if (this.planar) {
/* 2250 */       int totalNumBands = this.bitsPerSample.length;
/* 2251 */       destBitsPerSample = new int[totalNumBands];
/* 2252 */       int dbps = this.image.getSampleModel().getSampleSize(0);
/* 2253 */       for (int b = 0; b < totalNumBands; b++) {
/* 2254 */         destBitsPerSample[b] = dbps;
/*      */       }
/*      */     } else {
/* 2257 */       destBitsPerSample = this.image.getSampleModel().getSampleSize();
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 2262 */     if (this.photometricInterpretation != 5 || (this.bitsPerSample[0] != 1 && this.bitsPerSample[0] != 2 && this.bitsPerSample[0] != 4))
/*      */     {
/*      */ 
/*      */       
/* 2266 */       for (int b = 0; b < numBands; b++) {
/* 2267 */         if (destBitsPerSample[this.destinationBands[b]] != this.bitsPerSample[this.sourceBands[b]]) {
/*      */           
/* 2269 */           this.adjustBitDepths = true;
/*      */ 
/*      */           
/*      */           break;
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/* 2277 */     if (this.adjustBitDepths) {
/*      */ 
/*      */ 
/*      */       
/* 2281 */       if (this.isFirstBitDepthTable || this.planar != this.planarCache || !areIntArraysEqual(destBitsPerSample, this.destBitsPerSampleCache) || !areIntArraysEqual(this.sourceBands, this.sourceBandsCache) || !areIntArraysEqual(this.bitsPerSample, this.bitsPerSampleCache) || !areIntArraysEqual(this.destinationBands, this.destinationBandsCache))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2292 */         this.isFirstBitDepthTable = false;
/*      */ 
/*      */         
/* 2295 */         this.planarCache = this.planar;
/* 2296 */         this.destBitsPerSampleCache = (int[])destBitsPerSample.clone();
/*      */         
/* 2298 */         this.sourceBandsCache = (this.sourceBands == null) ? null : (int[])this.sourceBands.clone();
/*      */         
/* 2300 */         this.bitsPerSampleCache = (this.bitsPerSample == null) ? null : (int[])this.bitsPerSample.clone();
/*      */         
/* 2302 */         this.destinationBandsCache = (this.destinationBands == null) ? null : (int[])this.destinationBands.clone();
/*      */ 
/*      */ 
/*      */         
/* 2306 */         this.bitDepthScale = new int[numBands][];
/* 2307 */         for (int b = 0; b < numBands; b++) {
/* 2308 */           int maxInSample = (1 << this.bitsPerSample[this.sourceBands[b]]) - 1;
/* 2309 */           int halfMaxInSample = maxInSample / 2;
/*      */           
/* 2311 */           int maxOutSample = (1 << destBitsPerSample[this.destinationBands[b]]) - 1;
/*      */ 
/*      */           
/* 2314 */           this.bitDepthScale[b] = new int[maxInSample + 1];
/* 2315 */           for (int s = 0; s <= maxInSample; s++) {
/* 2316 */             this.bitDepthScale[b][s] = (s * maxOutSample + halfMaxInSample) / maxInSample;
/*      */           }
/*      */         }
/*      */       
/*      */       }
/*      */     
/*      */     } else {
/*      */       
/* 2324 */       this.bitDepthScale = (int[][])null;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2333 */     boolean sourceBandsNormal = false;
/* 2334 */     boolean destinationBandsNormal = false;
/* 2335 */     if (numBands == this.samplesPerPixel) {
/* 2336 */       sourceBandsNormal = true;
/* 2337 */       destinationBandsNormal = true;
/* 2338 */       for (int i = 0; i < numBands; i++) {
/* 2339 */         if (this.sourceBands[i] != i) {
/* 2340 */           sourceBandsNormal = false;
/*      */         }
/* 2342 */         if (this.destinationBands[i] != i) {
/* 2343 */           destinationBandsNormal = false;
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2352 */     this.isBilevel = ImageUtil.isBinary(this.image.getRaster().getSampleModel());
/*      */     
/* 2354 */     this.isContiguous = this.isBilevel ? true : ImageUtil.imageIsContiguous(this.image);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2360 */     this.isImageSimple = (this.colorConverter == null && this.subsampleX == 1 && this.subsampleY == 1 && this.srcWidth == this.dstWidth && this.srcHeight == this.dstHeight && this.dstMinX + this.dstWidth <= this.image.getWidth() && this.dstMinY + this.dstHeight <= this.image.getHeight() && sourceBandsNormal && destinationBandsNormal && !this.adjustBitDepths);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void decode() throws IOException {
/* 2461 */     byte[] byteData = null;
/* 2462 */     short[] shortData = null;
/* 2463 */     int[] intData = null;
/* 2464 */     float[] floatData = null;
/*      */     
/* 2466 */     int dstOffset = 0;
/* 2467 */     int pixelBitStride = 1;
/* 2468 */     int scanlineStride = 0;
/*      */ 
/*      */ 
/*      */     
/* 2472 */     this.rawImage = null;
/* 2473 */     if (this.isImageSimple) {
/* 2474 */       if (this.isBilevel) {
/* 2475 */         this.rawImage = this.image;
/* 2476 */       } else if (this.isContiguous) {
/* 2477 */         this.rawImage = this.image.getSubimage(this.dstMinX, this.dstMinY, this.dstWidth, this.dstHeight);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/* 2482 */     boolean isDirectCopy = (this.rawImage != null);
/*      */     
/* 2484 */     if (this.rawImage == null) {
/* 2485 */       this.rawImage = createRawImage();
/* 2486 */       if (this.rawImage == null) {
/* 2487 */         throw new IIOException("Couldn't create image buffer!");
/*      */       }
/*      */     } 
/*      */     
/* 2491 */     WritableRaster ras = this.rawImage.getRaster();
/*      */     
/* 2493 */     if (this.isBilevel) {
/* 2494 */       Rectangle rect = this.isImageSimple ? new Rectangle(this.dstMinX, this.dstMinY, this.dstWidth, this.dstHeight) : ras.getBounds();
/*      */ 
/*      */       
/* 2497 */       byteData = ImageUtil.getPackedBinaryData(ras, rect);
/* 2498 */       dstOffset = 0;
/* 2499 */       pixelBitStride = 1;
/* 2500 */       scanlineStride = (rect.width + 7) / 8;
/*      */     } else {
/* 2502 */       SampleModel sm = ras.getSampleModel();
/* 2503 */       DataBuffer db = ras.getDataBuffer();
/*      */       
/* 2505 */       boolean isSupportedType = false;
/*      */       
/* 2507 */       if (sm instanceof ComponentSampleModel) {
/* 2508 */         ComponentSampleModel csm = (ComponentSampleModel)sm;
/* 2509 */         dstOffset = csm.getOffset(-ras.getSampleModelTranslateX(), -ras.getSampleModelTranslateY());
/*      */         
/* 2511 */         scanlineStride = csm.getScanlineStride();
/* 2512 */         if (db instanceof DataBufferByte) {
/* 2513 */           DataBufferByte dbb = (DataBufferByte)db;
/*      */           
/* 2515 */           byteData = dbb.getData();
/* 2516 */           pixelBitStride = csm.getPixelStride() * 8;
/* 2517 */           isSupportedType = true;
/* 2518 */         } else if (db instanceof DataBufferUShort) {
/* 2519 */           DataBufferUShort dbus = (DataBufferUShort)db;
/*      */           
/* 2521 */           shortData = dbus.getData();
/* 2522 */           pixelBitStride = csm.getPixelStride() * 16;
/* 2523 */           isSupportedType = true;
/* 2524 */         } else if (db instanceof DataBufferShort) {
/* 2525 */           DataBufferShort dbs = (DataBufferShort)db;
/*      */           
/* 2527 */           shortData = dbs.getData();
/* 2528 */           pixelBitStride = csm.getPixelStride() * 16;
/* 2529 */           isSupportedType = true;
/* 2530 */         } else if (db instanceof DataBufferInt) {
/* 2531 */           DataBufferInt dbi = (DataBufferInt)db;
/*      */           
/* 2533 */           intData = dbi.getData();
/* 2534 */           pixelBitStride = csm.getPixelStride() * 32;
/* 2535 */           isSupportedType = true;
/* 2536 */         } else if (db instanceof DataBufferFloat) {
/* 2537 */           DataBufferFloat dbf = (DataBufferFloat)db;
/*      */           
/* 2539 */           floatData = dbf.getData();
/* 2540 */           pixelBitStride = csm.getPixelStride() * 32;
/* 2541 */           isSupportedType = true;
/*      */         } 
/* 2543 */       } else if (sm instanceof MultiPixelPackedSampleModel) {
/* 2544 */         MultiPixelPackedSampleModel mppsm = (MultiPixelPackedSampleModel)sm;
/*      */         
/* 2546 */         dstOffset = mppsm.getOffset(-ras.getSampleModelTranslateX(), -ras.getSampleModelTranslateY());
/*      */ 
/*      */         
/* 2549 */         pixelBitStride = mppsm.getPixelBitStride();
/* 2550 */         scanlineStride = mppsm.getScanlineStride();
/* 2551 */         if (db instanceof DataBufferByte) {
/* 2552 */           DataBufferByte dbb = (DataBufferByte)db;
/*      */           
/* 2554 */           byteData = dbb.getData();
/* 2555 */           isSupportedType = true;
/* 2556 */         } else if (db instanceof DataBufferUShort) {
/* 2557 */           DataBufferUShort dbus = (DataBufferUShort)db;
/*      */           
/* 2559 */           shortData = dbus.getData();
/* 2560 */           isSupportedType = true;
/* 2561 */         } else if (db instanceof DataBufferInt) {
/* 2562 */           DataBufferInt dbi = (DataBufferInt)db;
/*      */           
/* 2564 */           intData = dbi.getData();
/* 2565 */           isSupportedType = true;
/*      */         } 
/* 2567 */       } else if (sm instanceof SinglePixelPackedSampleModel) {
/* 2568 */         SinglePixelPackedSampleModel sppsm = (SinglePixelPackedSampleModel)sm;
/*      */         
/* 2570 */         dstOffset = sppsm.getOffset(-ras.getSampleModelTranslateX(), -ras.getSampleModelTranslateY());
/*      */ 
/*      */         
/* 2573 */         scanlineStride = sppsm.getScanlineStride();
/* 2574 */         if (db instanceof DataBufferByte) {
/* 2575 */           DataBufferByte dbb = (DataBufferByte)db;
/*      */           
/* 2577 */           byteData = dbb.getData();
/* 2578 */           pixelBitStride = 8;
/* 2579 */           isSupportedType = true;
/* 2580 */         } else if (db instanceof DataBufferUShort) {
/* 2581 */           DataBufferUShort dbus = (DataBufferUShort)db;
/*      */           
/* 2583 */           shortData = dbus.getData();
/* 2584 */           pixelBitStride = 16;
/* 2585 */           isSupportedType = true;
/* 2586 */         } else if (db instanceof DataBufferInt) {
/* 2587 */           DataBufferInt dbi = (DataBufferInt)db;
/*      */           
/* 2589 */           intData = dbi.getData();
/* 2590 */           pixelBitStride = 32;
/* 2591 */           isSupportedType = true;
/*      */         } 
/*      */       } 
/*      */       
/* 2595 */       if (!isSupportedType) {
/* 2596 */         throw new IIOException("Unsupported raw image type: SampleModel = " + sm + "; DataBuffer = " + db);
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 2602 */     if (this.isBilevel) {
/*      */       
/* 2604 */       decodeRaw(byteData, dstOffset, pixelBitStride, scanlineStride);
/*      */     } else {
/* 2606 */       SampleModel sm = ras.getSampleModel();
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2611 */       if (isDataBufferBitContiguous(sm)) {
/*      */         
/* 2613 */         if (byteData != null) {
/*      */ 
/*      */ 
/*      */           
/* 2617 */           decodeRaw(byteData, dstOffset, pixelBitStride, scanlineStride);
/*      */         }
/* 2619 */         else if (floatData != null) {
/*      */ 
/*      */ 
/*      */           
/* 2623 */           decodeRaw(floatData, dstOffset, pixelBitStride, scanlineStride);
/*      */         
/*      */         }
/* 2626 */         else if (shortData != null) {
/* 2627 */           if (areSampleSizesEqual(sm) && sm.getSampleSize(0) == 16)
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 2633 */             decodeRaw(shortData, dstOffset, pixelBitStride, scanlineStride);
/*      */ 
/*      */           
/*      */           }
/*      */           else
/*      */           {
/*      */             
/* 2640 */             int bpp = getBitsPerPixel(sm);
/* 2641 */             int bytesPerRow = (bpp * this.srcWidth + 7) / 8;
/* 2642 */             byte[] buf = new byte[bytesPerRow * this.srcHeight];
/* 2643 */             decodeRaw(buf, 0, bpp, bytesPerRow);
/* 2644 */             reformatData(buf, bytesPerRow, this.srcHeight, shortData, null, dstOffset, scanlineStride);
/*      */           }
/*      */         
/*      */         }
/* 2648 */         else if (intData != null) {
/* 2649 */           if (areSampleSizesEqual(sm) && sm.getSampleSize(0) == 32)
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 2655 */             decodeRaw(intData, dstOffset, pixelBitStride, scanlineStride);
/*      */ 
/*      */           
/*      */           }
/*      */           else
/*      */           {
/*      */             
/* 2662 */             int bpp = getBitsPerPixel(sm);
/* 2663 */             int bytesPerRow = (bpp * this.srcWidth + 7) / 8;
/* 2664 */             byte[] buf = new byte[bytesPerRow * this.srcHeight];
/* 2665 */             decodeRaw(buf, 0, bpp, bytesPerRow);
/* 2666 */             reformatData(buf, bytesPerRow, this.srcHeight, null, intData, dstOffset, scanlineStride);
/*      */           
/*      */           }
/*      */ 
/*      */         
/*      */         }
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */         
/* 2678 */         int bpp = getBitsPerPixel(sm);
/* 2679 */         int bytesPerRow = (bpp * this.srcWidth + 7) / 8;
/* 2680 */         byte[] buf = new byte[bytesPerRow * this.srcHeight];
/* 2681 */         decodeRaw(buf, 0, bpp, bytesPerRow);
/* 2682 */         reformatDiscontiguousData(buf, bytesPerRow, this.srcWidth, this.srcHeight, ras);
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2690 */     if (this.colorConverter != null) {
/* 2691 */       float[] rgb = new float[3];
/*      */       
/* 2693 */       if (byteData != null) {
/* 2694 */         for (int j = 0; j < this.dstHeight; j++) {
/* 2695 */           int idx = dstOffset;
/* 2696 */           for (int i = 0; i < this.dstWidth; i++) {
/* 2697 */             float x0 = (byteData[idx] & 0xFF);
/* 2698 */             float x1 = (byteData[idx + 1] & 0xFF);
/* 2699 */             float x2 = (byteData[idx + 2] & 0xFF);
/*      */             
/* 2701 */             this.colorConverter.toRGB(x0, x1, x2, rgb);
/*      */             
/* 2703 */             byteData[idx] = (byte)(int)rgb[0];
/* 2704 */             byteData[idx + 1] = (byte)(int)rgb[1];
/* 2705 */             byteData[idx + 2] = (byte)(int)rgb[2];
/*      */             
/* 2707 */             idx += 3;
/*      */           } 
/*      */           
/* 2710 */           dstOffset += scanlineStride;
/*      */         } 
/* 2712 */       } else if (shortData != null) {
/* 2713 */         if (this.sampleFormat[0] == 2) {
/*      */           
/* 2715 */           for (int j = 0; j < this.dstHeight; j++) {
/* 2716 */             int idx = dstOffset;
/* 2717 */             for (int i = 0; i < this.dstWidth; i++) {
/* 2718 */               float x0 = shortData[idx];
/* 2719 */               float x1 = shortData[idx + 1];
/* 2720 */               float x2 = shortData[idx + 2];
/*      */               
/* 2722 */               this.colorConverter.toRGB(x0, x1, x2, rgb);
/*      */               
/* 2724 */               shortData[idx] = (short)(int)rgb[0];
/* 2725 */               shortData[idx + 1] = (short)(int)rgb[1];
/* 2726 */               shortData[idx + 2] = (short)(int)rgb[2];
/*      */               
/* 2728 */               idx += 3;
/*      */             } 
/*      */             
/* 2731 */             dstOffset += scanlineStride;
/*      */           } 
/*      */         } else {
/* 2734 */           for (int j = 0; j < this.dstHeight; j++) {
/* 2735 */             int idx = dstOffset;
/* 2736 */             for (int i = 0; i < this.dstWidth; i++) {
/* 2737 */               float x0 = (shortData[idx] & 0xFFFF);
/* 2738 */               float x1 = (shortData[idx + 1] & 0xFFFF);
/* 2739 */               float x2 = (shortData[idx + 2] & 0xFFFF);
/*      */               
/* 2741 */               this.colorConverter.toRGB(x0, x1, x2, rgb);
/*      */               
/* 2743 */               shortData[idx] = (short)(int)rgb[0];
/* 2744 */               shortData[idx + 1] = (short)(int)rgb[1];
/* 2745 */               shortData[idx + 2] = (short)(int)rgb[2];
/*      */               
/* 2747 */               idx += 3;
/*      */             } 
/*      */             
/* 2750 */             dstOffset += scanlineStride;
/*      */           } 
/*      */         } 
/* 2753 */       } else if (intData != null) {
/* 2754 */         for (int j = 0; j < this.dstHeight; j++) {
/* 2755 */           int idx = dstOffset;
/* 2756 */           for (int i = 0; i < this.dstWidth; i++) {
/* 2757 */             float x0 = intData[idx];
/* 2758 */             float x1 = intData[idx + 1];
/* 2759 */             float x2 = intData[idx + 2];
/*      */             
/* 2761 */             this.colorConverter.toRGB(x0, x1, x2, rgb);
/*      */             
/* 2763 */             intData[idx] = (int)rgb[0];
/* 2764 */             intData[idx + 1] = (int)rgb[1];
/* 2765 */             intData[idx + 2] = (int)rgb[2];
/*      */             
/* 2767 */             idx += 3;
/*      */           } 
/*      */           
/* 2770 */           dstOffset += scanlineStride;
/*      */         } 
/* 2772 */       } else if (floatData != null) {
/* 2773 */         for (int j = 0; j < this.dstHeight; j++) {
/* 2774 */           int idx = dstOffset;
/* 2775 */           for (int i = 0; i < this.dstWidth; i++) {
/* 2776 */             float x0 = floatData[idx];
/* 2777 */             float x1 = floatData[idx + 1];
/* 2778 */             float x2 = floatData[idx + 2];
/*      */             
/* 2780 */             this.colorConverter.toRGB(x0, x1, x2, rgb);
/*      */             
/* 2782 */             floatData[idx] = rgb[0];
/* 2783 */             floatData[idx + 1] = rgb[1];
/* 2784 */             floatData[idx + 2] = rgb[2];
/*      */             
/* 2786 */             idx += 3;
/*      */           } 
/*      */           
/* 2789 */           dstOffset += scanlineStride;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2814 */     if (this.photometricInterpretation == 0)
/*      */     {
/* 2816 */       if (byteData != null) {
/* 2817 */         int bytesPerRow = (this.srcWidth * pixelBitStride + 7) / 8;
/* 2818 */         for (int y = 0; y < this.srcHeight; y++) {
/* 2819 */           int offset = dstOffset + y * scanlineStride;
/* 2820 */           for (int i = 0; i < bytesPerRow; i++) {
/* 2821 */             byteData[offset + i] = (byte)(byteData[offset + i] ^ 0xFF);
/*      */           }
/*      */         } 
/* 2824 */       } else if (shortData != null) {
/* 2825 */         int shortsPerRow = (this.srcWidth * pixelBitStride + 15) / 16;
/* 2826 */         if (this.sampleFormat[0] == 2) {
/*      */           
/* 2828 */           for (int y = 0; y < this.srcHeight; y++) {
/* 2829 */             int offset = dstOffset + y * scanlineStride;
/* 2830 */             for (int i = 0; i < shortsPerRow; i++) {
/* 2831 */               int shortOffset = offset + i;
/*      */               
/* 2833 */               shortData[shortOffset] = (short)(32767 - shortData[shortOffset]);
/*      */             }
/*      */           
/*      */           } 
/*      */         } else {
/*      */           
/* 2839 */           for (int y = 0; y < this.srcHeight; y++) {
/* 2840 */             int offset = dstOffset + y * scanlineStride;
/* 2841 */             for (int i = 0; i < shortsPerRow; i++) {
/* 2842 */               shortData[offset + i] = (short)(shortData[offset + i] ^ 0xFFFF);
/*      */             }
/*      */           } 
/*      */         } 
/* 2846 */       } else if (intData != null) {
/* 2847 */         int intsPerRow = (this.srcWidth * pixelBitStride + 15) / 16;
/* 2848 */         for (int y = 0; y < this.srcHeight; y++) {
/* 2849 */           int offset = dstOffset + y * scanlineStride;
/* 2850 */           for (int i = 0; i < intsPerRow; i++) {
/* 2851 */             int intOffset = offset + i;
/*      */             
/* 2853 */             intData[intOffset] = Integer.MAX_VALUE - intData[intOffset];
/*      */           }
/*      */         
/*      */         } 
/* 2857 */       } else if (floatData != null) {
/* 2858 */         int floatsPerRow = (this.srcWidth * pixelBitStride + 15) / 16;
/* 2859 */         for (int y = 0; y < this.srcHeight; y++) {
/* 2860 */           int offset = dstOffset + y * scanlineStride;
/* 2861 */           for (int i = 0; i < floatsPerRow; i++) {
/* 2862 */             int floatOffset = offset + i;
/*      */             
/* 2864 */             floatData[floatOffset] = 1.0F - floatData[floatOffset];
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/* 2871 */     if (this.isBilevel) {
/* 2872 */       Rectangle rect = this.isImageSimple ? new Rectangle(this.dstMinX, this.dstMinY, this.dstWidth, this.dstHeight) : ras.getBounds();
/*      */ 
/*      */       
/* 2875 */       ImageUtil.setPackedBinaryData(byteData, ras, rect);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 2880 */     if (isDirectCopy) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/* 2885 */     Raster src = this.rawImage.getRaster();
/*      */ 
/*      */     
/* 2888 */     Raster srcChild = src.createChild(0, 0, this.srcWidth, this.srcHeight, this.srcMinX, this.srcMinY, this.planar ? null : this.sourceBands);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2893 */     WritableRaster dst = this.image.getRaster();
/*      */ 
/*      */     
/* 2896 */     WritableRaster dstChild = dst.createWritableChild(this.dstMinX, this.dstMinY, this.dstWidth, this.dstHeight, this.dstMinX, this.dstMinY, this.destinationBands);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2901 */     if (this.subsampleX == 1 && this.subsampleY == 1 && !this.adjustBitDepths) {
/* 2902 */       srcChild = srcChild.createChild(this.activeSrcMinX, this.activeSrcMinY, this.activeSrcWidth, this.activeSrcHeight, this.dstMinX, this.dstMinY, null);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2908 */       dstChild.setRect(srcChild);
/* 2909 */     } else if (this.subsampleX == 1 && !this.adjustBitDepths) {
/* 2910 */       int sy = this.activeSrcMinY;
/* 2911 */       int dy = this.dstMinY;
/* 2912 */       while (sy < this.srcMinY + this.srcHeight) {
/* 2913 */         Raster srcRow = srcChild.createChild(this.activeSrcMinX, sy, this.activeSrcWidth, 1, this.dstMinX, dy, null);
/*      */ 
/*      */ 
/*      */         
/* 2917 */         dstChild.setRect(srcRow);
/*      */         
/* 2919 */         sy += this.subsampleY;
/* 2920 */         dy++;
/*      */       } 
/*      */     } else {
/* 2923 */       int[] p = srcChild.getPixel(this.srcMinX, this.srcMinY, (int[])null);
/* 2924 */       int numBands = p.length;
/*      */       
/* 2926 */       int sy = this.activeSrcMinY;
/* 2927 */       int dy = this.dstMinY;
/*      */       
/* 2929 */       while (sy < this.activeSrcMinY + this.activeSrcHeight) {
/* 2930 */         int sx = this.activeSrcMinX;
/* 2931 */         int dx = this.dstMinX;
/*      */         
/* 2933 */         while (sx < this.activeSrcMinX + this.activeSrcWidth) {
/* 2934 */           srcChild.getPixel(sx, sy, p);
/* 2935 */           if (this.adjustBitDepths) {
/* 2936 */             for (int band = 0; band < numBands; band++) {
/* 2937 */               p[band] = this.bitDepthScale[band][p[band]];
/*      */             }
/*      */           }
/* 2940 */           dstChild.setPixel(dx, dy, p);
/*      */           
/* 2942 */           sx += this.subsampleX;
/* 2943 */           dx++;
/*      */         } 
/*      */         
/* 2946 */         sy += this.subsampleY;
/* 2947 */         dy++;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageio/plugins/tiff/TIFFDecompressor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */