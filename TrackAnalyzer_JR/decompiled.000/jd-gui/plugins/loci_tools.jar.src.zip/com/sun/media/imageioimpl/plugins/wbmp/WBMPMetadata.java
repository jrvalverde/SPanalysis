/*     */ package com.sun.media.imageioimpl.plugins.wbmp;
/*     */ 
/*     */ import com.sun.media.imageioimpl.common.ImageUtil;
/*     */ import javax.imageio.metadata.IIOMetadata;
/*     */ import javax.imageio.metadata.IIOMetadataNode;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WBMPMetadata
/*     */   extends IIOMetadata
/*     */ {
/*     */   public static final String nativeMetadataFormatName = "com_sun_media_imageio_plugins_wbmp_image_1.0";
/*     */   public int wbmpType;
/*     */   public int width;
/*     */   public int height;
/*     */   
/*     */   public WBMPMetadata() {
/* 107 */     super(true, "com_sun_media_imageio_plugins_wbmp_image_1.0", "com.sun.media.imageioimpl.plugins.wbmp.WBMPMetadataFormat", null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isReadOnly() {
/* 114 */     return true;
/*     */   }
/*     */   
/*     */   public Node getAsTree(String formatName) {
/* 118 */     if (formatName.equals("com_sun_media_imageio_plugins_wbmp_image_1.0"))
/* 119 */       return getNativeTree(); 
/* 120 */     if (formatName.equals("javax_imageio_1.0"))
/*     */     {
/* 122 */       return getStandardTree();
/*     */     }
/* 124 */     throw new IllegalArgumentException(I18N.getString("WBMPMetadata0"));
/*     */   }
/*     */ 
/*     */   
/*     */   private Node getNativeTree() {
/* 129 */     IIOMetadataNode root = new IIOMetadataNode("com_sun_media_imageio_plugins_wbmp_image_1.0");
/*     */ 
/*     */     
/* 132 */     addChildNode(root, "WBMPType", new Integer(this.wbmpType));
/* 133 */     addChildNode(root, "Width", new Integer(this.width));
/* 134 */     addChildNode(root, "Height", new Integer(this.height));
/*     */     
/* 136 */     return root;
/*     */   }
/*     */   
/*     */   public void setFromTree(String formatName, Node root) {
/* 140 */     throw new IllegalStateException(I18N.getString("WBMPMetadata1"));
/*     */   }
/*     */   
/*     */   public void mergeTree(String formatName, Node root) {
/* 144 */     throw new IllegalStateException(I18N.getString("WBMPMetadata1"));
/*     */   }
/*     */   
/*     */   public void reset() {
/* 148 */     throw new IllegalStateException(I18N.getString("WBMPMetadata1"));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private IIOMetadataNode addChildNode(IIOMetadataNode root, String name, Object object) {
/* 154 */     IIOMetadataNode child = new IIOMetadataNode(name);
/* 155 */     if (object != null) {
/* 156 */       child.setUserObject(object);
/* 157 */       child.setNodeValue(ImageUtil.convertObjectToString(object));
/*     */     } 
/* 159 */     root.appendChild(child);
/* 160 */     return child;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected IIOMetadataNode getStandardChromaNode() {
/* 166 */     IIOMetadataNode node = new IIOMetadataNode("Chroma");
/*     */     
/* 168 */     IIOMetadataNode subNode = new IIOMetadataNode("ColorSpaceType");
/* 169 */     subNode.setAttribute("name", "GRAY");
/* 170 */     node.appendChild(subNode);
/*     */     
/* 172 */     subNode = new IIOMetadataNode("NumChannels");
/* 173 */     subNode.setAttribute("value", "1");
/* 174 */     node.appendChild(subNode);
/*     */     
/* 176 */     subNode = new IIOMetadataNode("BlackIsZero");
/* 177 */     subNode.setAttribute("value", "TRUE");
/* 178 */     node.appendChild(subNode);
/*     */     
/* 180 */     return node;
/*     */   }
/*     */ 
/*     */   
/*     */   protected IIOMetadataNode getStandardDataNode() {
/* 185 */     IIOMetadataNode node = new IIOMetadataNode("Data");
/*     */     
/* 187 */     IIOMetadataNode subNode = new IIOMetadataNode("SampleFormat");
/* 188 */     subNode.setAttribute("value", "UnsignedIntegral");
/* 189 */     node.appendChild(subNode);
/*     */     
/* 191 */     subNode = new IIOMetadataNode("BitsPerSample");
/* 192 */     subNode.setAttribute("value", "1");
/* 193 */     node.appendChild(subNode);
/*     */     
/* 195 */     return node;
/*     */   }
/*     */   
/*     */   protected IIOMetadataNode getStandardDimensionNode() {
/* 199 */     IIOMetadataNode dimension_node = new IIOMetadataNode("Dimension");
/* 200 */     IIOMetadataNode node = null;
/*     */ 
/*     */ 
/*     */     
/* 204 */     node = new IIOMetadataNode("ImageOrientation");
/* 205 */     node.setAttribute("value", "Normal");
/* 206 */     dimension_node.appendChild(node);
/*     */     
/* 208 */     return dimension_node;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/wbmp/WBMPMetadata.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */