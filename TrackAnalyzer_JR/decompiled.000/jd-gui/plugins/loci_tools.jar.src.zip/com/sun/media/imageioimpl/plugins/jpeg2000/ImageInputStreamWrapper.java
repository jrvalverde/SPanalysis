/*     */ package com.sun.media.imageioimpl.plugins.jpeg2000;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import javax.imageio.stream.ImageInputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ImageInputStreamWrapper
/*     */   extends InputStream
/*     */ {
/*     */   private ImageInputStream src;
/*     */   
/*     */   public ImageInputStreamWrapper(ImageInputStream src) {
/* 105 */     this.src = src;
/*     */   }
/*     */ 
/*     */   
/*     */   public int read() throws IOException {
/* 110 */     return this.src.read();
/*     */   }
/*     */   
/*     */   public void close() throws IOException {
/* 114 */     this.src.close();
/*     */   }
/*     */   
/*     */   public synchronized void mark(int readlimit) {
/* 118 */     this.src.mark();
/*     */   }
/*     */   
/*     */   public boolean markSupported() {
/* 122 */     return true;
/*     */   }
/*     */   
/*     */   public int read(byte[] b) throws IOException {
/* 126 */     return this.src.read(b, 0, b.length);
/*     */   }
/*     */   
/*     */   public int read(byte[] b, int off, int len) throws IOException {
/* 130 */     return this.src.read(b, off, len);
/*     */   }
/*     */   
/*     */   public synchronized void reset() throws IOException {
/* 134 */     this.src.reset();
/*     */   }
/*     */   
/*     */   public long skip(long n) throws IOException {
/* 138 */     return this.src.skipBytes(n);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/jpeg2000/ImageInputStreamWrapper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */