/*     */ package com.sun.media.imageio.stream;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.imageio.stream.ImageInputStream;
/*     */ import javax.imageio.stream.ImageInputStreamImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SegmentedImageInputStream
/*     */   extends ImageInputStreamImpl
/*     */ {
/*     */   private ImageInputStream stream;
/*     */   private StreamSegmentMapper mapper;
/*     */   private StreamSegment streamSegment;
/*     */   
/*     */   public SegmentedImageInputStream(ImageInputStream stream, StreamSegmentMapper mapper) {
/* 311 */     this.streamSegment = new StreamSegment();
/*     */     this.stream = stream;
/*     */     this.mapper = mapper;
/*     */   }
/*     */ 
/*     */   
/*     */   public SegmentedImageInputStream(ImageInputStream stream, long[] segmentPositions, int[] segmentLengths) {
/*     */     this(stream, new StreamSegmentMapperImpl(segmentPositions, segmentLengths));
/*     */   }
/*     */   
/*     */   public SegmentedImageInputStream(ImageInputStream stream, long[] segmentPositions, int segmentLength, int totalLength) {
/*     */     this(stream, new SectorStreamSegmentMapper(segmentPositions, segmentLength, totalLength));
/*     */   }
/*     */   
/*     */   public int read() throws IOException {
/* 326 */     this.mapper.getStreamSegment(this.streamPos, 1, this.streamSegment);
/* 327 */     int streamSegmentLength = this.streamSegment.getSegmentLength();
/* 328 */     if (streamSegmentLength < 0) {
/* 329 */       return -1;
/*     */     }
/* 331 */     this.stream.seek(this.streamSegment.getStartPos());
/*     */ 
/*     */ 
/*     */     
/* 335 */     int val = this.stream.read();
/* 336 */     this.streamPos++;
/* 337 */     return val;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read(byte[] b, int off, int len) throws IOException {
/* 389 */     if (b == null) {
/* 390 */       throw new NullPointerException();
/*     */     }
/* 392 */     if (off < 0 || len < 0 || off + len > b.length) {
/* 393 */       throw new IndexOutOfBoundsException();
/*     */     }
/* 395 */     if (len == 0) {
/* 396 */       return 0;
/*     */     }
/*     */     
/* 399 */     this.mapper.getStreamSegment(this.streamPos, len, this.streamSegment);
/* 400 */     int streamSegmentLength = this.streamSegment.getSegmentLength();
/* 401 */     if (streamSegmentLength < 0) {
/* 402 */       return -1;
/*     */     }
/* 404 */     this.stream.seek(this.streamSegment.getStartPos());
/*     */     
/* 406 */     int nbytes = this.stream.read(b, off, streamSegmentLength);
/* 407 */     this.streamPos += nbytes;
/* 408 */     return nbytes;
/*     */   }
/*     */   
/*     */   public long length() {
/*     */     long len;
/* 413 */     if (this.mapper instanceof StreamSegmentMapperImpl) {
/* 414 */       len = ((StreamSegmentMapperImpl)this.mapper).length();
/* 415 */     } else if (this.mapper instanceof SectorStreamSegmentMapper) {
/* 416 */       len = ((SectorStreamSegmentMapper)this.mapper).length();
/* 417 */     } else if (this.mapper != null) {
/* 418 */       long pos = len = 0L;
/* 419 */       StreamSegment seg = this.mapper.getStreamSegment(pos, 2147483647);
/* 420 */       while ((len = seg.getSegmentLength()) > 0L) {
/* 421 */         pos += len;
/* 422 */         seg.setSegmentLength(0);
/* 423 */         this.mapper.getStreamSegment(pos, 2147483647, seg);
/*     */       } 
/* 425 */       len = pos;
/*     */     } else {
/* 427 */       len = super.length();
/*     */     } 
/*     */     
/* 430 */     return len;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageio/stream/SegmentedImageInputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */