/*     */ package com.sun.media.imageioimpl.plugins.wbmp;
/*     */ 
/*     */ import com.sun.media.imageioimpl.common.ImageUtil;
/*     */ import com.sun.media.imageioimpl.common.PackageUtil;
/*     */ import java.awt.image.SampleModel;
/*     */ import java.util.Locale;
/*     */ import javax.imageio.IIOException;
/*     */ import javax.imageio.ImageTypeSpecifier;
/*     */ import javax.imageio.ImageWriter;
/*     */ import javax.imageio.spi.ImageWriterSpi;
/*     */ import javax.imageio.spi.ServiceRegistry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WBMPImageWriterSpi
/*     */   extends ImageWriterSpi
/*     */ {
/* 100 */   private static String[] readerSpiNames = new String[] { "com.sun.media.imageioimpl.plugins.wbmp.WBMPImageReaderSpi" };
/*     */   
/* 102 */   private static String[] formatNames = new String[] { "wbmp", "WBMP" };
/* 103 */   private static String[] entensions = new String[] { "wbmp" };
/* 104 */   private static String[] mimeType = new String[] { "image/vnd.wap.wbmp" };
/*     */   
/*     */   private boolean registered = false;
/*     */   
/*     */   public WBMPImageWriterSpi() {
/* 109 */     super(PackageUtil.getVendor(), PackageUtil.getVersion(), formatNames, entensions, mimeType, "com.sun.media.imageioimpl.plugins.wbmp.WBMPImageWriter", STANDARD_OUTPUT_TYPE, readerSpiNames, true, null, null, null, null, true, "com_sun_media_imageio_plugins_wbmp_image_1.0", "com.sun.media.imageioimpl.plugins.wbmp.WBMPMetadataFormat", null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDescription(Locale locale) {
/* 126 */     String desc = PackageUtil.getSpecificationTitle() + " WBMP Image Writer";
/*     */     
/* 128 */     return desc;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onRegistration(ServiceRegistry registry, Class category) {
/* 133 */     if (this.registered) {
/*     */       return;
/*     */     }
/*     */     
/* 137 */     this.registered = true;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 142 */     ImageUtil.processOnRegistration(registry, category, "WBMP", this, 8, 7);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canEncodeImage(ImageTypeSpecifier type) {
/* 147 */     SampleModel sm = type.getSampleModel();
/* 148 */     if (!(sm instanceof java.awt.image.MultiPixelPackedSampleModel))
/* 149 */       return false; 
/* 150 */     if (sm.getSampleSize(0) != 1) {
/* 151 */       return false;
/*     */     }
/* 153 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public ImageWriter createWriterInstance(Object extension) throws IIOException {
/* 158 */     return new WBMPImageWriter(this);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/wbmp/WBMPImageWriterSpi.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */