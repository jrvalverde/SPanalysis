/*      */ package com.sun.media.imageioimpl.plugins.tiff;
/*      */ 
/*      */ import com.sun.media.imageio.plugins.tiff.TIFFField;
/*      */ import com.sun.media.imageio.plugins.tiff.TIFFTag;
/*      */ import com.sun.media.imageio.plugins.tiff.TIFFTagSet;
/*      */ import java.io.IOException;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.lang.reflect.Method;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.StringTokenizer;
/*      */ import javax.imageio.metadata.IIOInvalidTreeException;
/*      */ import javax.imageio.metadata.IIOMetadata;
/*      */ import javax.imageio.metadata.IIOMetadataNode;
/*      */ import javax.imageio.stream.ImageInputStream;
/*      */ import org.w3c.dom.NamedNodeMap;
/*      */ import org.w3c.dom.Node;
/*      */ import org.w3c.dom.NodeList;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class TIFFImageMetadata
/*      */   extends IIOMetadata
/*      */ {
/*      */   public static final String nativeMetadataFormatName = "com_sun_media_imageio_plugins_tiff_image_1.0";
/*      */   public static final String nativeMetadataFormatClassName = "com.sun.media.imageioimpl.plugins.tiff.TIFFImageMetadataFormat";
/*      */   List tagSets;
/*      */   TIFFIFD rootIFD;
/*      */   
/*      */   public TIFFImageMetadata(List tagSets) {
/*  125 */     super(true, "com_sun_media_imageio_plugins_tiff_image_1.0", "com.sun.media.imageioimpl.plugins.tiff.TIFFImageMetadataFormat", null, null);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  130 */     this.tagSets = tagSets;
/*  131 */     this.rootIFD = new TIFFIFD(tagSets);
/*      */   }
/*      */   
/*      */   public TIFFImageMetadata(TIFFIFD ifd) {
/*  135 */     super(true, "com_sun_media_imageio_plugins_tiff_image_1.0", "com.sun.media.imageioimpl.plugins.tiff.TIFFImageMetadataFormat", null, null);
/*      */ 
/*      */ 
/*      */     
/*  139 */     this.tagSets = ifd.getTagSetList();
/*  140 */     this.rootIFD = ifd;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void initializeFromStream(ImageInputStream stream, boolean ignoreUnknownFields) throws IOException {
/*  146 */     this.rootIFD.initialize(stream, ignoreUnknownFields);
/*      */   }
/*      */   
/*      */   public void addShortOrLongField(int tagNumber, int value) {
/*  150 */     TIFFField field = new TIFFField(this.rootIFD.getTag(tagNumber), value);
/*  151 */     this.rootIFD.addTIFFField(field);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isReadOnly() {
/*  172 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private Node getIFDAsTree(TIFFIFD ifd, String parentTagName, int parentTagNumber) {
/*  177 */     IIOMetadataNode IFDRoot = new IIOMetadataNode("TIFFIFD");
/*  178 */     if (parentTagNumber != 0) {
/*  179 */       IFDRoot.setAttribute("parentTagNumber", Integer.toString(parentTagNumber));
/*      */     }
/*      */     
/*  182 */     if (parentTagName != null) {
/*  183 */       IFDRoot.setAttribute("parentTagName", parentTagName);
/*      */     }
/*      */     
/*  186 */     List tagSets = ifd.getTagSetList();
/*  187 */     if (tagSets.size() > 0) {
/*  188 */       Iterator<TIFFTagSet> iterator = tagSets.iterator();
/*  189 */       String tagSetNames = "";
/*  190 */       while (iterator.hasNext()) {
/*  191 */         TIFFTagSet tagSet = iterator.next();
/*  192 */         tagSetNames = tagSetNames + tagSet.getClass().getName();
/*  193 */         if (iterator.hasNext()) {
/*  194 */           tagSetNames = tagSetNames + ",";
/*      */         }
/*      */       } 
/*      */       
/*  198 */       IFDRoot.setAttribute("tagSets", tagSetNames);
/*      */     } 
/*      */     
/*  201 */     Iterator<TIFFField> iter = ifd.iterator();
/*  202 */     while (iter.hasNext()) {
/*  203 */       TIFFField f = iter.next();
/*  204 */       int tagNumber = f.getTagNumber();
/*  205 */       TIFFTag tag = TIFFIFD.getTag(tagNumber, tagSets);
/*      */       
/*  207 */       Node node = null;
/*  208 */       if (tag == null) {
/*  209 */         node = f.getAsNativeNode();
/*  210 */       } else if (tag.isIFDPointer()) {
/*  211 */         TIFFIFD subIFD = (TIFFIFD)f.getData();
/*      */ 
/*      */         
/*  214 */         node = getIFDAsTree(subIFD, tag.getName(), tag.getNumber());
/*      */       } else {
/*  216 */         node = f.getAsNativeNode();
/*      */       } 
/*      */       
/*  219 */       if (node != null) {
/*  220 */         IFDRoot.appendChild(node);
/*      */       }
/*      */     } 
/*      */     
/*  224 */     return IFDRoot;
/*      */   }
/*      */   
/*      */   public Node getAsTree(String formatName) {
/*  228 */     if (formatName.equals("com_sun_media_imageio_plugins_tiff_image_1.0"))
/*  229 */       return getNativeTree(); 
/*  230 */     if (formatName.equals("javax_imageio_1.0"))
/*      */     {
/*  232 */       return getStandardTree();
/*      */     }
/*  234 */     throw new IllegalArgumentException("Not a recognized format!");
/*      */   }
/*      */ 
/*      */   
/*      */   private Node getNativeTree() {
/*  239 */     IIOMetadataNode root = new IIOMetadataNode("com_sun_media_imageio_plugins_tiff_image_1.0");
/*      */     
/*  241 */     Node IFDNode = getIFDAsTree(this.rootIFD, null, 0);
/*  242 */     root.appendChild(IFDNode);
/*      */     
/*  244 */     return root;
/*      */   }
/*      */   
/*  247 */   private static final String[] colorSpaceNames = new String[] { "GRAY", "GRAY", "RGB", "RGB", "GRAY", "CMYK", "YCbCr", "Lab", "Lab" };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IIOMetadataNode getStandardChromaNode() {
/*  260 */     IIOMetadataNode chroma_node = new IIOMetadataNode("Chroma");
/*  261 */     IIOMetadataNode node = null;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  266 */     int photometricInterpretation = -1;
/*  267 */     boolean isPaletteColor = false;
/*  268 */     TIFFField f = getTIFFField(262);
/*  269 */     if (f != null) {
/*  270 */       photometricInterpretation = f.getAsInt(0);
/*      */       
/*  272 */       isPaletteColor = (photometricInterpretation == 3);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  278 */     int numChannels = -1;
/*  279 */     if (isPaletteColor) {
/*  280 */       numChannels = 3;
/*      */     } else {
/*  282 */       f = getTIFFField(277);
/*  283 */       if (f != null) {
/*  284 */         numChannels = f.getAsInt(0);
/*      */       } else {
/*  286 */         f = getTIFFField(258);
/*  287 */         if (f != null) {
/*  288 */           numChannels = f.getCount();
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/*  293 */     if (photometricInterpretation != -1) {
/*  294 */       if (photometricInterpretation >= 0 && photometricInterpretation < colorSpaceNames.length) {
/*      */         String csName;
/*  296 */         node = new IIOMetadataNode("ColorSpaceType");
/*      */         
/*  298 */         if (photometricInterpretation == 5 && numChannels == 3) {
/*      */ 
/*      */           
/*  301 */           csName = "CMY";
/*      */         } else {
/*  303 */           csName = colorSpaceNames[photometricInterpretation];
/*      */         } 
/*  305 */         node.setAttribute("name", csName);
/*  306 */         chroma_node.appendChild(node);
/*      */       } 
/*      */       
/*  309 */       node = new IIOMetadataNode("BlackIsZero");
/*  310 */       node.setAttribute("value", (photometricInterpretation == 0) ? "FALSE" : "TRUE");
/*      */ 
/*      */ 
/*      */       
/*  314 */       chroma_node.appendChild(node);
/*      */     } 
/*      */     
/*  317 */     if (numChannels != -1) {
/*  318 */       node = new IIOMetadataNode("NumChannels");
/*  319 */       node.setAttribute("value", Integer.toString(numChannels));
/*  320 */       chroma_node.appendChild(node);
/*      */     } 
/*      */     
/*  323 */     f = getTIFFField(320);
/*  324 */     if (f != null) {
/*      */ 
/*      */ 
/*      */       
/*  328 */       boolean hasAlpha = false;
/*      */       
/*  330 */       node = new IIOMetadataNode("Palette");
/*  331 */       int len = f.getCount() / (hasAlpha ? 4 : 3);
/*  332 */       for (int i = 0; i < len; i++) {
/*  333 */         IIOMetadataNode entry = new IIOMetadataNode("PaletteEntry");
/*      */         
/*  335 */         entry.setAttribute("index", Integer.toString(i));
/*      */         
/*  337 */         int r = f.getAsInt(i) * 255 / 65535;
/*  338 */         int g = f.getAsInt(len + i) * 255 / 65535;
/*  339 */         int b = f.getAsInt(2 * len + i) * 255 / 65535;
/*      */         
/*  341 */         entry.setAttribute("red", Integer.toString(r));
/*  342 */         entry.setAttribute("green", Integer.toString(g));
/*  343 */         entry.setAttribute("blue", Integer.toString(b));
/*  344 */         if (hasAlpha) {
/*  345 */           int alpha = 0;
/*  346 */           entry.setAttribute("alpha", Integer.toString(alpha));
/*      */         } 
/*  348 */         node.appendChild(entry);
/*      */       } 
/*  350 */       chroma_node.appendChild(node);
/*      */     } 
/*      */     
/*  353 */     return chroma_node;
/*      */   }
/*      */   
/*      */   public IIOMetadataNode getStandardCompressionNode() {
/*  357 */     IIOMetadataNode compression_node = new IIOMetadataNode("Compression");
/*  358 */     IIOMetadataNode node = null;
/*      */ 
/*      */ 
/*      */     
/*  362 */     TIFFField f = getTIFFField(259);
/*  363 */     if (f != null) {
/*  364 */       String compressionTypeName = null;
/*  365 */       int compression = f.getAsInt(0);
/*  366 */       boolean isLossless = true;
/*  367 */       if (compression == 1) {
/*  368 */         compressionTypeName = "None";
/*  369 */         isLossless = true;
/*      */       } else {
/*  371 */         int[] compressionNumbers = TIFFImageWriter.compressionNumbers;
/*  372 */         for (int i = 0; i < compressionNumbers.length; i++) {
/*  373 */           if (compression == compressionNumbers[i]) {
/*  374 */             compressionTypeName = TIFFImageWriter.compressionTypes[i];
/*      */             
/*  376 */             isLossless = TIFFImageWriter.isCompressionLossless[i];
/*      */             
/*      */             break;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */       
/*  383 */       if (compressionTypeName != null) {
/*  384 */         node = new IIOMetadataNode("CompressionTypeName");
/*  385 */         node.setAttribute("value", compressionTypeName);
/*  386 */         compression_node.appendChild(node);
/*      */         
/*  388 */         node = new IIOMetadataNode("Lossless");
/*  389 */         node.setAttribute("value", isLossless ? "TRUE" : "FALSE");
/*  390 */         compression_node.appendChild(node);
/*      */       } 
/*      */     } 
/*      */     
/*  394 */     node = new IIOMetadataNode("NumProgressiveScans");
/*  395 */     node.setAttribute("value", "1");
/*  396 */     compression_node.appendChild(node);
/*      */     
/*  398 */     return compression_node;
/*      */   }
/*      */   
/*      */   private String repeat(String s, int times) {
/*  402 */     if (times == 1) {
/*  403 */       return s;
/*      */     }
/*  405 */     StringBuffer sb = new StringBuffer((s.length() + 1) * times - 1);
/*  406 */     sb.append(s);
/*  407 */     for (int i = 1; i < times; i++) {
/*  408 */       sb.append(" ");
/*  409 */       sb.append(s);
/*      */     } 
/*  411 */     return sb.toString();
/*      */   }
/*      */   
/*      */   public IIOMetadataNode getStandardDataNode() {
/*  415 */     IIOMetadataNode data_node = new IIOMetadataNode("Data");
/*  416 */     IIOMetadataNode node = null;
/*      */ 
/*      */ 
/*      */     
/*  420 */     boolean isPaletteColor = false;
/*  421 */     TIFFField f = getTIFFField(262);
/*  422 */     if (f != null) {
/*  423 */       isPaletteColor = (f.getAsInt(0) == 3);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  428 */     f = getTIFFField(284);
/*  429 */     String planarConfiguration = "PixelInterleaved";
/*  430 */     if (f != null && f.getAsInt(0) == 2)
/*      */     {
/*  432 */       planarConfiguration = "PlaneInterleaved";
/*      */     }
/*      */     
/*  435 */     node = new IIOMetadataNode("PlanarConfiguration");
/*  436 */     node.setAttribute("value", planarConfiguration);
/*  437 */     data_node.appendChild(node);
/*      */     
/*  439 */     f = getTIFFField(262);
/*  440 */     if (f != null) {
/*  441 */       int photometricInterpretation = f.getAsInt(0);
/*  442 */       String sampleFormat = "UnsignedIntegral";
/*      */       
/*  444 */       if (photometricInterpretation == 3) {
/*      */         
/*  446 */         sampleFormat = "Index";
/*      */       } else {
/*  448 */         f = getTIFFField(339);
/*  449 */         if (f != null) {
/*  450 */           int format = f.getAsInt(0);
/*  451 */           if (format == 2) {
/*      */             
/*  453 */             sampleFormat = "SignedIntegral";
/*  454 */           } else if (format == 1) {
/*      */             
/*  456 */             sampleFormat = "UnsignedIntegral";
/*  457 */           } else if (format == 3) {
/*      */             
/*  459 */             sampleFormat = "Real";
/*      */           } else {
/*  461 */             sampleFormat = null;
/*      */           } 
/*      */         } 
/*      */       } 
/*  465 */       if (sampleFormat != null) {
/*  466 */         node = new IIOMetadataNode("SampleFormat");
/*  467 */         node.setAttribute("value", sampleFormat);
/*  468 */         data_node.appendChild(node);
/*      */       } 
/*      */     } 
/*      */     
/*  472 */     f = getTIFFField(258);
/*  473 */     int[] bitsPerSample = null;
/*  474 */     if (f != null) {
/*  475 */       bitsPerSample = f.getAsInts();
/*      */     } else {
/*  477 */       f = getTIFFField(259);
/*  478 */       int compression = (f != null) ? f.getAsInt(0) : 1;
/*      */       
/*  480 */       if (getTIFFField(34665) != null || compression == 7 || compression == 6 || getTIFFField(513) != null) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  486 */         f = getTIFFField(262);
/*  487 */         if (f != null && (f.getAsInt(0) == 0 || f.getAsInt(0) == 1)) {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  492 */           bitsPerSample = new int[] { 8 };
/*      */         } else {
/*  494 */           bitsPerSample = new int[] { 8, 8, 8 };
/*      */         } 
/*      */       } else {
/*  497 */         bitsPerSample = new int[] { 1 };
/*      */       } 
/*      */     } 
/*  500 */     StringBuffer sb = new StringBuffer();
/*  501 */     for (int i = 0; i < bitsPerSample.length; i++) {
/*  502 */       if (i > 0) {
/*  503 */         sb.append(" ");
/*      */       }
/*  505 */       sb.append(Integer.toString(bitsPerSample[i]));
/*      */     } 
/*  507 */     node = new IIOMetadataNode("BitsPerSample");
/*  508 */     if (isPaletteColor) {
/*  509 */       node.setAttribute("value", repeat(sb.toString(), 3));
/*      */     } else {
/*  511 */       node.setAttribute("value", sb.toString());
/*      */     } 
/*  513 */     data_node.appendChild(node);
/*      */ 
/*      */     
/*  516 */     f = getTIFFField(266);
/*  517 */     int fillOrder = (f != null) ? f.getAsInt(0) : 1;
/*      */     
/*  519 */     sb = new StringBuffer();
/*  520 */     for (int j = 0; j < bitsPerSample.length; j++) {
/*  521 */       if (j > 0) {
/*  522 */         sb.append(" ");
/*      */       }
/*  524 */       int maxBitIndex = (bitsPerSample[j] == 1) ? 7 : (bitsPerSample[j] - 1);
/*      */       
/*  526 */       int msb = (fillOrder == 1) ? maxBitIndex : 0;
/*      */ 
/*      */       
/*  529 */       sb.append(Integer.toString(msb));
/*      */     } 
/*  531 */     node = new IIOMetadataNode("SampleMSB");
/*  532 */     if (isPaletteColor) {
/*  533 */       node.setAttribute("value", repeat(sb.toString(), 3));
/*      */     } else {
/*  535 */       node.setAttribute("value", sb.toString());
/*      */     } 
/*  537 */     data_node.appendChild(node);
/*      */     
/*  539 */     return data_node;
/*      */   }
/*      */   
/*  542 */   private static final String[] orientationNames = new String[] { null, "Normal", "FlipH", "Rotate180", "FlipV", "FlipHRotate90", "Rotate270", "FlipVRotate90", "Rotate90" };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IIOMetadataNode getStandardDimensionNode() {
/*  555 */     IIOMetadataNode dimension_node = new IIOMetadataNode("Dimension");
/*  556 */     IIOMetadataNode node = null;
/*      */ 
/*      */ 
/*      */     
/*  560 */     long[] xres = null;
/*  561 */     long[] yres = null;
/*      */     
/*  563 */     TIFFField f = getTIFFField(282);
/*  564 */     if (f != null) {
/*  565 */       xres = (long[])f.getAsRational(0).clone();
/*      */     }
/*      */     
/*  568 */     f = getTIFFField(283);
/*  569 */     if (f != null) {
/*  570 */       yres = (long[])f.getAsRational(0).clone();
/*      */     }
/*      */     
/*  573 */     if (xres != null && yres != null) {
/*  574 */       node = new IIOMetadataNode("PixelAspectRatio");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  580 */       float ratio = (float)(xres[1] * yres[0]) / (float)(xres[0] * yres[1]);
/*  581 */       node.setAttribute("value", Float.toString(ratio));
/*  582 */       dimension_node.appendChild(node);
/*      */     } 
/*      */     
/*  585 */     if (xres != null || yres != null) {
/*      */       
/*  587 */       f = getTIFFField(296);
/*      */ 
/*      */       
/*  590 */       int i = (f != null) ? f.getAsInt(0) : 2;
/*      */ 
/*      */ 
/*      */       
/*  594 */       boolean gotPixelSize = (i != 1);
/*      */ 
/*      */ 
/*      */       
/*  598 */       if (i == 2) {
/*      */         
/*  600 */         if (xres != null) {
/*  601 */           xres[0] = xres[0] * 100L;
/*  602 */           xres[1] = xres[1] * 254L;
/*      */         } 
/*      */ 
/*      */         
/*  606 */         if (yres != null) {
/*  607 */           yres[0] = yres[0] * 100L;
/*  608 */           yres[1] = yres[1] * 254L;
/*      */         } 
/*      */       } 
/*      */       
/*  612 */       if (gotPixelSize) {
/*  613 */         if (xres != null) {
/*  614 */           float horizontalPixelSize = (float)(10.0D * xres[1] / xres[0]);
/*  615 */           node = new IIOMetadataNode("HorizontalPixelSize");
/*  616 */           node.setAttribute("value", Float.toString(horizontalPixelSize));
/*      */           
/*  618 */           dimension_node.appendChild(node);
/*      */         } 
/*      */         
/*  621 */         if (yres != null) {
/*  622 */           float verticalPixelSize = (float)(10.0D * yres[1] / yres[0]);
/*  623 */           node = new IIOMetadataNode("VerticalPixelSize");
/*  624 */           node.setAttribute("value", Float.toString(verticalPixelSize));
/*      */           
/*  626 */           dimension_node.appendChild(node);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  631 */     f = getTIFFField(296);
/*  632 */     int resolutionUnit = (f != null) ? f.getAsInt(0) : 2;
/*      */     
/*  634 */     if (resolutionUnit == 2 || resolutionUnit == 3) {
/*      */       
/*  636 */       f = getTIFFField(286);
/*  637 */       if (f != null) {
/*  638 */         long[] xpos = f.getAsRational(0);
/*  639 */         float xPosition = (float)xpos[0] / (float)xpos[1];
/*      */         
/*  641 */         if (resolutionUnit == 2) {
/*  642 */           xPosition *= 254.0F;
/*      */         } else {
/*  644 */           xPosition *= 10.0F;
/*      */         } 
/*  646 */         node = new IIOMetadataNode("HorizontalPosition");
/*  647 */         node.setAttribute("value", Float.toString(xPosition));
/*      */         
/*  649 */         dimension_node.appendChild(node);
/*      */       } 
/*      */       
/*  652 */       f = getTIFFField(287);
/*  653 */       if (f != null) {
/*  654 */         long[] ypos = f.getAsRational(0);
/*  655 */         float yPosition = (float)ypos[0] / (float)ypos[1];
/*      */         
/*  657 */         if (resolutionUnit == 2) {
/*  658 */           yPosition *= 254.0F;
/*      */         } else {
/*  660 */           yPosition *= 10.0F;
/*      */         } 
/*  662 */         node = new IIOMetadataNode("VerticalPosition");
/*  663 */         node.setAttribute("value", Float.toString(yPosition));
/*      */         
/*  665 */         dimension_node.appendChild(node);
/*      */       } 
/*      */     } 
/*      */     
/*  669 */     f = getTIFFField(274);
/*  670 */     if (f != null) {
/*  671 */       int o = f.getAsInt(0);
/*  672 */       if (o >= 0 && o < orientationNames.length) {
/*  673 */         node = new IIOMetadataNode("ImageOrientation");
/*  674 */         node.setAttribute("value", orientationNames[o]);
/*  675 */         dimension_node.appendChild(node);
/*      */       } 
/*      */     } 
/*      */     
/*  679 */     return dimension_node;
/*      */   }
/*      */   
/*      */   public IIOMetadataNode getStandardDocumentNode() {
/*  683 */     IIOMetadataNode document_node = new IIOMetadataNode("Document");
/*  684 */     IIOMetadataNode node = null;
/*      */ 
/*      */ 
/*      */     
/*  688 */     node = new IIOMetadataNode("FormatVersion");
/*  689 */     node.setAttribute("value", "6.0");
/*  690 */     document_node.appendChild(node);
/*      */     
/*  692 */     TIFFField f = getTIFFField(254);
/*  693 */     if (f != null) {
/*  694 */       int newSubFileType = f.getAsInt(0);
/*  695 */       String value = null;
/*  696 */       if ((newSubFileType & 0x4) != 0) {
/*      */         
/*  698 */         value = "TransparencyMask";
/*  699 */       } else if ((newSubFileType & 0x1) != 0) {
/*      */         
/*  701 */         value = "ReducedResolution";
/*  702 */       } else if ((newSubFileType & 0x2) != 0) {
/*      */         
/*  704 */         value = "SinglePage";
/*      */       } 
/*  706 */       if (value != null) {
/*  707 */         node = new IIOMetadataNode("SubimageInterpretation");
/*  708 */         node.setAttribute("value", value);
/*  709 */         document_node.appendChild(node);
/*      */       } 
/*      */     } 
/*      */     
/*  713 */     f = getTIFFField(306);
/*  714 */     if (f != null) {
/*  715 */       String s = f.getAsString(0);
/*      */ 
/*      */       
/*  718 */       if (s.length() == 19) {
/*  719 */         boolean bool; node = new IIOMetadataNode("ImageCreationTime");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         try {
/*  727 */           node.setAttribute("year", s.substring(0, 4));
/*  728 */           node.setAttribute("month", s.substring(5, 7));
/*  729 */           node.setAttribute("day", s.substring(8, 10));
/*  730 */           node.setAttribute("hour", s.substring(11, 13));
/*  731 */           node.setAttribute("minute", s.substring(14, 16));
/*  732 */           node.setAttribute("second", s.substring(17, 19));
/*  733 */           bool = true;
/*  734 */         } catch (IndexOutOfBoundsException e) {
/*  735 */           bool = false;
/*      */         } 
/*      */         
/*  738 */         if (bool) {
/*  739 */           document_node.appendChild(node);
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/*  744 */     return document_node;
/*      */   }
/*      */   
/*      */   public IIOMetadataNode getStandardTextNode() {
/*  748 */     IIOMetadataNode text_node = null;
/*  749 */     IIOMetadataNode node = null;
/*      */ 
/*      */ 
/*      */     
/*  753 */     int[] textFieldTagNumbers = { 269, 270, 271, 272, 285, 305, 315, 316, 333, 33432 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  766 */     for (int i = 0; i < textFieldTagNumbers.length; i++) {
/*  767 */       TIFFField f = getTIFFField(textFieldTagNumbers[i]);
/*  768 */       if (f != null) {
/*  769 */         String value = f.getAsString(0);
/*  770 */         if (text_node == null) {
/*  771 */           text_node = new IIOMetadataNode("Text");
/*      */         }
/*  773 */         node = new IIOMetadataNode("TextEntry");
/*  774 */         node.setAttribute("keyword", f.getTag().getName());
/*  775 */         node.setAttribute("value", value);
/*  776 */         text_node.appendChild(node);
/*      */       } 
/*      */     } 
/*      */     
/*  780 */     return text_node;
/*      */   }
/*      */   
/*      */   public IIOMetadataNode getStandardTransparencyNode() {
/*  784 */     IIOMetadataNode transparency_node = new IIOMetadataNode("Transparency");
/*      */     
/*  786 */     IIOMetadataNode node = null;
/*      */ 
/*      */ 
/*      */     
/*  790 */     node = new IIOMetadataNode("Alpha");
/*  791 */     String value = "none";
/*      */     
/*  793 */     TIFFField f = getTIFFField(338);
/*  794 */     if (f != null) {
/*  795 */       int[] extraSamples = f.getAsInts();
/*  796 */       for (int i = 0; i < extraSamples.length; i++) {
/*  797 */         if (extraSamples[i] == 1) {
/*      */           
/*  799 */           value = "premultiplied"; break;
/*      */         } 
/*  801 */         if (extraSamples[i] == 2) {
/*      */           
/*  803 */           value = "nonpremultiplied";
/*      */           
/*      */           break;
/*      */         } 
/*      */       } 
/*      */     } 
/*  809 */     node.setAttribute("value", value);
/*  810 */     transparency_node.appendChild(node);
/*      */     
/*  812 */     return transparency_node;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static void fatal(Node node, String reason) throws IIOInvalidTreeException {
/*  818 */     throw new IIOInvalidTreeException(reason, node);
/*      */   }
/*      */   
/*      */   private int[] listToIntArray(String list) {
/*  822 */     StringTokenizer st = new StringTokenizer(list, " ");
/*  823 */     ArrayList<Integer> intList = new ArrayList();
/*  824 */     while (st.hasMoreTokens()) {
/*  825 */       String nextInteger = st.nextToken();
/*  826 */       Integer nextInt = new Integer(nextInteger);
/*  827 */       intList.add(nextInt);
/*      */     } 
/*      */     
/*  830 */     int[] intArray = new int[intList.size()];
/*  831 */     for (int i = 0; i < intArray.length; i++) {
/*  832 */       intArray[i] = ((Integer)intList.get(i)).intValue();
/*      */     }
/*      */     
/*  835 */     return intArray;
/*      */   }
/*      */   
/*      */   private char[] listToCharArray(String list) {
/*  839 */     StringTokenizer st = new StringTokenizer(list, " ");
/*  840 */     ArrayList<Integer> intList = new ArrayList();
/*  841 */     while (st.hasMoreTokens()) {
/*  842 */       String nextInteger = st.nextToken();
/*  843 */       Integer nextInt = new Integer(nextInteger);
/*  844 */       intList.add(nextInt);
/*      */     } 
/*      */     
/*  847 */     char[] charArray = new char[intList.size()];
/*  848 */     for (int i = 0; i < charArray.length; i++) {
/*  849 */       charArray[i] = (char)((Integer)intList.get(i)).intValue();
/*      */     }
/*      */     
/*  852 */     return charArray;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void mergeStandardTree(Node root) throws IIOInvalidTreeException {
/*  860 */     Node node = root;
/*  861 */     if (!node.getNodeName().equals("javax_imageio_1.0"))
/*      */     {
/*  863 */       fatal(node, "Root must be javax_imageio_1.0");
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  868 */     String sampleFormat = null;
/*  869 */     Node dataNode = getChildNode(root, "Data");
/*  870 */     boolean isPaletteColor = false;
/*  871 */     if (dataNode != null) {
/*  872 */       Node sampleFormatNode = getChildNode(dataNode, "SampleFormat");
/*  873 */       if (sampleFormatNode != null) {
/*  874 */         sampleFormat = getAttribute(sampleFormatNode, "value");
/*  875 */         isPaletteColor = sampleFormat.equals("Index");
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  880 */     if (!isPaletteColor) {
/*  881 */       Node chromaNode = getChildNode(root, "Chroma");
/*  882 */       if (chromaNode != null && getChildNode(chromaNode, "Palette") != null)
/*      */       {
/*  884 */         isPaletteColor = true;
/*      */       }
/*      */     } 
/*      */     
/*  888 */     node = node.getFirstChild();
/*  889 */     while (node != null) {
/*  890 */       String name = node.getNodeName();
/*      */       
/*  892 */       if (name.equals("Chroma")) {
/*  893 */         String colorSpaceType = null;
/*  894 */         String blackIsZero = null;
/*  895 */         boolean gotPalette = false;
/*  896 */         Node child = node.getFirstChild();
/*  897 */         while (child != null) {
/*  898 */           String childName = child.getNodeName();
/*  899 */           if (childName.equals("ColorSpaceType")) {
/*  900 */             colorSpaceType = getAttribute(child, "name");
/*  901 */           } else if (childName.equals("NumChannels")) {
/*  902 */             TIFFTag tag = this.rootIFD.getTag(277);
/*  903 */             int samplesPerPixel = isPaletteColor ? 1 : Integer.parseInt(getAttribute(child, "value"));
/*      */             
/*  905 */             TIFFField f = new TIFFField(tag, samplesPerPixel);
/*  906 */             this.rootIFD.addTIFFField(f);
/*  907 */           } else if (childName.equals("BlackIsZero")) {
/*  908 */             blackIsZero = getAttribute(child, "value");
/*  909 */           } else if (childName.equals("Palette")) {
/*  910 */             Node entry = child.getFirstChild();
/*  911 */             HashMap<Object, Object> palette = new HashMap<Object, Object>();
/*  912 */             int maxIndex = -1;
/*  913 */             while (entry != null) {
/*  914 */               String entryName = entry.getNodeName();
/*  915 */               if (entryName.equals("PaletteEntry")) {
/*  916 */                 String idx = getAttribute(entry, "index");
/*  917 */                 int id = Integer.parseInt(idx);
/*  918 */                 if (id > maxIndex) {
/*  919 */                   maxIndex = id;
/*      */                 }
/*  921 */                 char red = (char)Integer.parseInt(getAttribute(entry, "red"));
/*      */ 
/*      */                 
/*  924 */                 char green = (char)Integer.parseInt(getAttribute(entry, "green"));
/*      */ 
/*      */                 
/*  927 */                 char blue = (char)Integer.parseInt(getAttribute(entry, "blue"));
/*      */ 
/*      */                 
/*  930 */                 palette.put(new Integer(id), new char[] { red, green, blue });
/*      */ 
/*      */                 
/*  933 */                 gotPalette = true;
/*      */               } 
/*  935 */               entry = entry.getNextSibling();
/*      */             } 
/*      */             
/*  938 */             if (gotPalette) {
/*  939 */               int mapSize = maxIndex + 1;
/*  940 */               int paletteLength = 3 * mapSize;
/*  941 */               char[] paletteEntries = new char[paletteLength];
/*  942 */               Iterator<Integer> paletteIter = palette.keySet().iterator();
/*  943 */               while (paletteIter.hasNext()) {
/*  944 */                 Integer index = paletteIter.next();
/*  945 */                 char[] rgb = (char[])palette.get(index);
/*  946 */                 int idx = index.intValue();
/*  947 */                 paletteEntries[idx] = (char)(rgb[0] * 65535 / 255);
/*      */                 
/*  949 */                 paletteEntries[mapSize + idx] = (char)(rgb[1] * 65535 / 255);
/*      */                 
/*  951 */                 paletteEntries[2 * mapSize + idx] = (char)(rgb[2] * 65535 / 255);
/*      */               } 
/*      */ 
/*      */               
/*  955 */               TIFFTag tag = this.rootIFD.getTag(320);
/*  956 */               TIFFField f = new TIFFField(tag, 3, paletteLength, paletteEntries);
/*      */               
/*  958 */               this.rootIFD.addTIFFField(f);
/*      */             } 
/*      */           } 
/*      */           
/*  962 */           child = child.getNextSibling();
/*      */         } 
/*      */         
/*  965 */         int photometricInterpretation = -1;
/*  966 */         if ((colorSpaceType == null || colorSpaceType.equals("GRAY")) && blackIsZero != null && blackIsZero.equalsIgnoreCase("FALSE")) {
/*      */ 
/*      */           
/*  969 */           photometricInterpretation = 0;
/*      */         }
/*  971 */         else if (colorSpaceType != null) {
/*  972 */           if (colorSpaceType.equals("GRAY")) {
/*  973 */             boolean isTransparency = false;
/*  974 */             if (root instanceof IIOMetadataNode) {
/*  975 */               IIOMetadataNode iioRoot = (IIOMetadataNode)root;
/*  976 */               NodeList siNodeList = iioRoot.getElementsByTagName("SubimageInterpretation");
/*      */               
/*  978 */               if (siNodeList.getLength() == 1) {
/*  979 */                 Node siNode = siNodeList.item(0);
/*  980 */                 String value = getAttribute(siNode, "value");
/*  981 */                 if (value.equals("TransparencyMask")) {
/*  982 */                   isTransparency = true;
/*      */                 }
/*      */               } 
/*      */             } 
/*  986 */             if (isTransparency) {
/*  987 */               photometricInterpretation = 4;
/*      */             } else {
/*      */               
/*  990 */               photometricInterpretation = 1;
/*      */             }
/*      */           
/*  993 */           } else if (colorSpaceType.equals("RGB")) {
/*  994 */             photometricInterpretation = gotPalette ? 3 : 2;
/*      */ 
/*      */           
/*      */           }
/*  998 */           else if (colorSpaceType.equals("YCbCr")) {
/*  999 */             photometricInterpretation = 6;
/*      */           }
/* 1001 */           else if (colorSpaceType.equals("CMYK")) {
/* 1002 */             photometricInterpretation = 5;
/*      */           }
/* 1004 */           else if (colorSpaceType.equals("Lab")) {
/* 1005 */             photometricInterpretation = 8;
/*      */           } 
/*      */         } 
/*      */ 
/*      */         
/* 1010 */         if (photometricInterpretation != -1) {
/* 1011 */           TIFFTag tag = this.rootIFD.getTag(262);
/* 1012 */           TIFFField f = new TIFFField(tag, photometricInterpretation);
/* 1013 */           this.rootIFD.addTIFFField(f);
/*      */         } 
/* 1015 */       } else if (name.equals("Compression")) {
/* 1016 */         Node child = node.getFirstChild();
/* 1017 */         while (child != null) {
/* 1018 */           String childName = child.getNodeName();
/* 1019 */           if (childName.equals("CompressionTypeName")) {
/* 1020 */             int compression = -1;
/* 1021 */             String compressionTypeName = getAttribute(child, "value");
/*      */             
/* 1023 */             if (compressionTypeName.equalsIgnoreCase("None")) {
/* 1024 */               compression = 1;
/*      */             } else {
/*      */               
/* 1027 */               String[] compressionNames = TIFFImageWriter.compressionTypes;
/*      */               
/* 1029 */               for (int i = 0; i < compressionNames.length; i++) {
/* 1030 */                 if (compressionNames[i].equalsIgnoreCase(compressionTypeName)) {
/* 1031 */                   compression = TIFFImageWriter.compressionNumbers[i];
/*      */                   
/*      */                   break;
/*      */                 } 
/*      */               } 
/*      */             } 
/*      */             
/* 1038 */             if (compression != -1) {
/* 1039 */               TIFFTag tag = this.rootIFD.getTag(259);
/* 1040 */               TIFFField f = new TIFFField(tag, compression);
/* 1041 */               this.rootIFD.addTIFFField(f);
/*      */             } 
/*      */           } 
/*      */ 
/*      */ 
/*      */           
/* 1047 */           child = child.getNextSibling();
/*      */         } 
/* 1049 */       } else if (name.equals("Data")) {
/* 1050 */         Node child = node.getFirstChild();
/* 1051 */         while (child != null) {
/* 1052 */           String childName = child.getNodeName();
/*      */           
/* 1054 */           if (childName.equals("PlanarConfiguration")) {
/* 1055 */             String pc = getAttribute(child, "value");
/* 1056 */             int planarConfiguration = -1;
/* 1057 */             if (pc.equals("PixelInterleaved")) {
/* 1058 */               planarConfiguration = 1;
/*      */             }
/* 1060 */             else if (pc.equals("PlaneInterleaved")) {
/* 1061 */               planarConfiguration = 2;
/*      */             } 
/*      */             
/* 1064 */             if (planarConfiguration != -1) {
/* 1065 */               TIFFTag tag = this.rootIFD.getTag(284);
/* 1066 */               TIFFField f = new TIFFField(tag, planarConfiguration);
/* 1067 */               this.rootIFD.addTIFFField(f);
/*      */             } 
/* 1069 */           } else if (childName.equals("BitsPerSample")) {
/* 1070 */             TIFFField f; String bps = getAttribute(child, "value");
/* 1071 */             char[] bitsPerSample = listToCharArray(bps);
/* 1072 */             TIFFTag tag = this.rootIFD.getTag(258);
/* 1073 */             if (isPaletteColor) {
/* 1074 */               f = new TIFFField(tag, 3, 1, new char[] { bitsPerSample[0] });
/*      */             } else {
/*      */               
/* 1077 */               f = new TIFFField(tag, 3, bitsPerSample.length, bitsPerSample);
/*      */             } 
/*      */ 
/*      */             
/* 1081 */             this.rootIFD.addTIFFField(f);
/* 1082 */           } else if (childName.equals("SampleMSB")) {
/*      */ 
/*      */ 
/*      */             
/* 1086 */             String sMSB = getAttribute(child, "value");
/* 1087 */             int[] sampleMSB = listToIntArray(sMSB);
/* 1088 */             boolean isRightToLeft = true;
/* 1089 */             for (int i = 0; i < sampleMSB.length; i++) {
/* 1090 */               if (sampleMSB[i] != 0) {
/* 1091 */                 isRightToLeft = false;
/*      */                 break;
/*      */               } 
/*      */             } 
/* 1095 */             int fillOrder = isRightToLeft ? 2 : 1;
/*      */ 
/*      */             
/* 1098 */             TIFFTag tag = this.rootIFD.getTag(266);
/*      */             
/* 1100 */             TIFFField f = new TIFFField(tag, fillOrder);
/* 1101 */             this.rootIFD.addTIFFField(f);
/*      */           } 
/*      */           
/* 1104 */           child = child.getNextSibling();
/*      */         } 
/* 1106 */       } else if (name.equals("Dimension")) {
/* 1107 */         float pixelAspectRatio = -1.0F;
/* 1108 */         boolean gotPixelAspectRatio = false;
/*      */         
/* 1110 */         float horizontalPixelSize = -1.0F;
/* 1111 */         boolean gotHorizontalPixelSize = false;
/*      */         
/* 1113 */         float verticalPixelSize = -1.0F;
/* 1114 */         boolean gotVerticalPixelSize = false;
/*      */         
/* 1116 */         boolean sizeIsAbsolute = false;
/*      */         
/* 1118 */         float horizontalPosition = -1.0F;
/* 1119 */         boolean gotHorizontalPosition = false;
/*      */         
/* 1121 */         float verticalPosition = -1.0F;
/* 1122 */         boolean gotVerticalPosition = false;
/*      */         
/* 1124 */         Node child = node.getFirstChild();
/* 1125 */         while (child != null) {
/* 1126 */           String childName = child.getNodeName();
/* 1127 */           if (childName.equals("PixelAspectRatio")) {
/* 1128 */             String par = getAttribute(child, "value");
/* 1129 */             pixelAspectRatio = Float.parseFloat(par);
/* 1130 */             gotPixelAspectRatio = true;
/* 1131 */           } else if (childName.equals("ImageOrientation")) {
/* 1132 */             String orientation = getAttribute(child, "value");
/* 1133 */             for (int i = 0; i < orientationNames.length; i++) {
/* 1134 */               if (orientation.equals(orientationNames[i])) {
/* 1135 */                 char[] oData = new char[1];
/* 1136 */                 oData[0] = (char)i;
/*      */                 
/* 1138 */                 TIFFField tIFFField = new TIFFField(this.rootIFD.getTag(274), 3, 1, oData);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/* 1144 */                 this.rootIFD.addTIFFField(tIFFField);
/*      */                 
/*      */                 break;
/*      */               } 
/*      */             } 
/* 1149 */           } else if (childName.equals("HorizontalPixelSize")) {
/* 1150 */             String hps = getAttribute(child, "value");
/* 1151 */             horizontalPixelSize = Float.parseFloat(hps);
/* 1152 */             gotHorizontalPixelSize = true;
/* 1153 */           } else if (childName.equals("VerticalPixelSize")) {
/* 1154 */             String vps = getAttribute(child, "value");
/* 1155 */             verticalPixelSize = Float.parseFloat(vps);
/* 1156 */             gotVerticalPixelSize = true;
/* 1157 */           } else if (childName.equals("HorizontalPosition")) {
/* 1158 */             String hp = getAttribute(child, "value");
/* 1159 */             horizontalPosition = Float.parseFloat(hp);
/* 1160 */             gotHorizontalPosition = true;
/* 1161 */           } else if (childName.equals("VerticalPosition")) {
/* 1162 */             String vp = getAttribute(child, "value");
/* 1163 */             verticalPosition = Float.parseFloat(vp);
/* 1164 */             gotVerticalPosition = true;
/*      */           } 
/*      */           
/* 1167 */           child = child.getNextSibling();
/*      */         } 
/*      */         
/* 1170 */         sizeIsAbsolute = (gotHorizontalPixelSize || gotVerticalPixelSize);
/*      */ 
/*      */ 
/*      */         
/* 1174 */         if (gotPixelAspectRatio) {
/* 1175 */           if (gotHorizontalPixelSize && !gotVerticalPixelSize) {
/* 1176 */             verticalPixelSize = horizontalPixelSize / pixelAspectRatio;
/*      */             
/* 1178 */             gotVerticalPixelSize = true;
/* 1179 */           } else if (gotVerticalPixelSize && !gotHorizontalPixelSize) {
/*      */             
/* 1181 */             horizontalPixelSize = verticalPixelSize * pixelAspectRatio;
/*      */             
/* 1183 */             gotHorizontalPixelSize = true;
/* 1184 */           } else if (!gotHorizontalPixelSize && !gotVerticalPixelSize) {
/*      */             
/* 1186 */             horizontalPixelSize = pixelAspectRatio;
/* 1187 */             verticalPixelSize = 1.0F;
/* 1188 */             gotHorizontalPixelSize = true;
/* 1189 */             gotVerticalPixelSize = true;
/*      */           } 
/*      */         }
/*      */ 
/*      */         
/* 1194 */         if (gotHorizontalPixelSize) {
/* 1195 */           float xResolution = (sizeIsAbsolute ? 10.0F : 1.0F) / horizontalPixelSize;
/*      */           
/* 1197 */           long[][] hData = new long[1][2];
/* 1198 */           hData[0] = new long[2];
/* 1199 */           hData[0][0] = (long)(xResolution * 10000.0F);
/* 1200 */           hData[0][1] = 10000L;
/*      */           
/* 1202 */           TIFFField tIFFField = new TIFFField(this.rootIFD.getTag(282), 5, 1, hData);
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1207 */           this.rootIFD.addTIFFField(tIFFField);
/*      */         } 
/*      */         
/* 1210 */         if (gotVerticalPixelSize) {
/* 1211 */           float yResolution = (sizeIsAbsolute ? 10.0F : 1.0F) / verticalPixelSize;
/*      */           
/* 1213 */           long[][] vData = new long[1][2];
/* 1214 */           vData[0] = new long[2];
/* 1215 */           vData[0][0] = (long)(yResolution * 10000.0F);
/* 1216 */           vData[0][1] = 10000L;
/*      */           
/* 1218 */           TIFFField tIFFField = new TIFFField(this.rootIFD.getTag(283), 5, 1, vData);
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1223 */           this.rootIFD.addTIFFField(tIFFField);
/*      */         } 
/*      */ 
/*      */         
/* 1227 */         char[] res = new char[1];
/* 1228 */         res[0] = (char)(sizeIsAbsolute ? '\003' : '\001');
/*      */ 
/*      */ 
/*      */         
/* 1232 */         TIFFField f = new TIFFField(this.rootIFD.getTag(296), 3, 1, res);
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1237 */         this.rootIFD.addTIFFField(f);
/*      */ 
/*      */         
/* 1240 */         if (sizeIsAbsolute) {
/* 1241 */           if (gotHorizontalPosition) {
/*      */ 
/*      */             
/* 1244 */             long[][] hData = new long[1][2];
/* 1245 */             hData[0][0] = (long)(horizontalPosition * 10000.0F);
/* 1246 */             hData[0][1] = 100000L;
/*      */             
/* 1248 */             f = new TIFFField(this.rootIFD.getTag(286), 5, 1, hData);
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1253 */             this.rootIFD.addTIFFField(f);
/*      */           } 
/*      */           
/* 1256 */           if (gotVerticalPosition) {
/*      */ 
/*      */             
/* 1259 */             long[][] vData = new long[1][2];
/* 1260 */             vData[0][0] = (long)(verticalPosition * 10000.0F);
/* 1261 */             vData[0][1] = 100000L;
/*      */             
/* 1263 */             f = new TIFFField(this.rootIFD.getTag(287), 5, 1, vData);
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1268 */             this.rootIFD.addTIFFField(f);
/*      */           } 
/*      */         } 
/* 1271 */       } else if (name.equals("Document")) {
/* 1272 */         Node child = node.getFirstChild();
/* 1273 */         while (child != null) {
/* 1274 */           String childName = child.getNodeName();
/*      */           
/* 1276 */           if (childName.equals("SubimageInterpretation")) {
/* 1277 */             String si = getAttribute(child, "value");
/* 1278 */             int newSubFileType = -1;
/* 1279 */             if (si.equals("TransparencyMask")) {
/* 1280 */               newSubFileType = 4;
/*      */             }
/* 1282 */             else if (si.equals("ReducedResolution")) {
/* 1283 */               newSubFileType = 1;
/*      */             }
/* 1285 */             else if (si.equals("SinglePage")) {
/* 1286 */               newSubFileType = 2;
/*      */             } 
/*      */             
/* 1289 */             if (newSubFileType != -1) {
/* 1290 */               TIFFTag tag = this.rootIFD.getTag(254);
/*      */               
/* 1292 */               TIFFField f = new TIFFField(tag, newSubFileType);
/* 1293 */               this.rootIFD.addTIFFField(f);
/*      */             } 
/*      */           } 
/*      */           
/* 1297 */           if (childName.equals("ImageCreationTime")) {
/* 1298 */             String year = getAttribute(child, "year");
/* 1299 */             String month = getAttribute(child, "month");
/* 1300 */             String day = getAttribute(child, "day");
/* 1301 */             String hour = getAttribute(child, "hour");
/* 1302 */             String minute = getAttribute(child, "minute");
/* 1303 */             String second = getAttribute(child, "second");
/*      */             
/* 1305 */             StringBuffer sb = new StringBuffer();
/* 1306 */             sb.append(year);
/* 1307 */             sb.append(":");
/* 1308 */             if (month.length() == 1) {
/* 1309 */               sb.append("0");
/*      */             }
/* 1311 */             sb.append(month);
/* 1312 */             sb.append(":");
/* 1313 */             if (day.length() == 1) {
/* 1314 */               sb.append("0");
/*      */             }
/* 1316 */             sb.append(day);
/* 1317 */             sb.append(" ");
/* 1318 */             if (hour.length() == 1) {
/* 1319 */               sb.append("0");
/*      */             }
/* 1321 */             sb.append(hour);
/* 1322 */             sb.append(":");
/* 1323 */             if (minute.length() == 1) {
/* 1324 */               sb.append("0");
/*      */             }
/* 1326 */             sb.append(minute);
/* 1327 */             sb.append(":");
/* 1328 */             if (second.length() == 1) {
/* 1329 */               sb.append("0");
/*      */             }
/* 1331 */             sb.append(second);
/*      */             
/* 1333 */             String[] dt = new String[1];
/* 1334 */             dt[0] = sb.toString();
/*      */             
/* 1336 */             TIFFField f = new TIFFField(this.rootIFD.getTag(306), 2, 1, dt);
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1341 */             this.rootIFD.addTIFFField(f);
/*      */           } 
/*      */           
/* 1344 */           child = child.getNextSibling();
/*      */         } 
/* 1346 */       } else if (name.equals("Text")) {
/* 1347 */         Node child = node.getFirstChild();
/* 1348 */         String theAuthor = null;
/* 1349 */         String theDescription = null;
/* 1350 */         String theTitle = null;
/* 1351 */         while (child != null) {
/* 1352 */           String childName = child.getNodeName();
/* 1353 */           if (childName.equals("TextEntry")) {
/* 1354 */             int tagNumber = -1;
/* 1355 */             NamedNodeMap childAttrs = child.getAttributes();
/* 1356 */             Node keywordNode = childAttrs.getNamedItem("keyword");
/* 1357 */             if (keywordNode != null) {
/* 1358 */               String keyword = keywordNode.getNodeValue();
/* 1359 */               String value = getAttribute(child, "value");
/* 1360 */               if (!keyword.equals("") && !value.equals("")) {
/* 1361 */                 if (keyword.equalsIgnoreCase("DocumentName")) {
/* 1362 */                   tagNumber = 269;
/*      */                 }
/* 1364 */                 else if (keyword.equalsIgnoreCase("ImageDescription")) {
/* 1365 */                   tagNumber = 270;
/*      */                 }
/* 1367 */                 else if (keyword.equalsIgnoreCase("Make")) {
/* 1368 */                   tagNumber = 271;
/*      */                 }
/* 1370 */                 else if (keyword.equalsIgnoreCase("Model")) {
/* 1371 */                   tagNumber = 272;
/*      */                 }
/* 1373 */                 else if (keyword.equalsIgnoreCase("PageName")) {
/* 1374 */                   tagNumber = 285;
/*      */                 }
/* 1376 */                 else if (keyword.equalsIgnoreCase("Software")) {
/* 1377 */                   tagNumber = 305;
/*      */                 }
/* 1379 */                 else if (keyword.equalsIgnoreCase("Artist")) {
/* 1380 */                   tagNumber = 315;
/*      */                 }
/* 1382 */                 else if (keyword.equalsIgnoreCase("HostComputer")) {
/* 1383 */                   tagNumber = 316;
/*      */                 }
/* 1385 */                 else if (keyword.equalsIgnoreCase("InkNames")) {
/* 1386 */                   tagNumber = 333;
/*      */                 }
/* 1388 */                 else if (keyword.equalsIgnoreCase("Copyright")) {
/* 1389 */                   tagNumber = 33432;
/*      */                 }
/* 1391 */                 else if (keyword.equalsIgnoreCase("author")) {
/* 1392 */                   theAuthor = value;
/* 1393 */                 } else if (keyword.equalsIgnoreCase("description")) {
/* 1394 */                   theDescription = value;
/* 1395 */                 } else if (keyword.equalsIgnoreCase("title")) {
/* 1396 */                   theTitle = value;
/*      */                 } 
/* 1398 */                 if (tagNumber != -1) {
/* 1399 */                   TIFFField f = new TIFFField(this.rootIFD.getTag(tagNumber), 2, 1, new String[] { value });
/*      */ 
/*      */ 
/*      */                   
/* 1403 */                   this.rootIFD.addTIFFField(f);
/*      */                 } 
/*      */               } 
/*      */             } 
/*      */           } 
/* 1408 */           child = child.getNextSibling();
/*      */         } 
/* 1410 */         if (theAuthor != null && getTIFFField(315) == null) {
/*      */           
/* 1412 */           TIFFField f = new TIFFField(this.rootIFD.getTag(315), 2, 1, new String[] { theAuthor });
/*      */ 
/*      */ 
/*      */           
/* 1416 */           this.rootIFD.addTIFFField(f);
/*      */         } 
/* 1418 */         if (theDescription != null && getTIFFField(270) == null) {
/*      */           
/* 1420 */           TIFFField f = new TIFFField(this.rootIFD.getTag(270), 2, 1, new String[] { theDescription });
/*      */ 
/*      */ 
/*      */           
/* 1424 */           this.rootIFD.addTIFFField(f);
/*      */         } 
/* 1426 */         if (theTitle != null && getTIFFField(269) == null) {
/*      */           
/* 1428 */           TIFFField f = new TIFFField(this.rootIFD.getTag(269), 2, 1, new String[] { theTitle });
/*      */ 
/*      */ 
/*      */           
/* 1432 */           this.rootIFD.addTIFFField(f);
/*      */         } 
/* 1434 */       } else if (name.equals("Transparency")) {
/* 1435 */         Node child = node.getFirstChild();
/* 1436 */         while (child != null) {
/* 1437 */           String childName = child.getNodeName();
/*      */           
/* 1439 */           if (childName.equals("Alpha")) {
/* 1440 */             String alpha = getAttribute(child, "value");
/*      */             
/* 1442 */             TIFFField f = null;
/* 1443 */             if (alpha.equals("premultiplied")) {
/* 1444 */               f = new TIFFField(this.rootIFD.getTag(338), 1);
/*      */             
/*      */             }
/* 1447 */             else if (alpha.equals("nonpremultiplied")) {
/* 1448 */               f = new TIFFField(this.rootIFD.getTag(338), 2);
/*      */             } 
/*      */ 
/*      */             
/* 1452 */             if (f != null) {
/* 1453 */               this.rootIFD.addTIFFField(f);
/*      */             }
/*      */           } 
/*      */           
/* 1457 */           child = child.getNextSibling();
/*      */         } 
/*      */       } 
/*      */       
/* 1461 */       node = node.getNextSibling();
/*      */     } 
/*      */ 
/*      */     
/* 1465 */     if (sampleFormat != null) {
/*      */       
/* 1467 */       int sf = -1;
/* 1468 */       if (sampleFormat.equals("SignedIntegral")) {
/* 1469 */         sf = 2;
/* 1470 */       } else if (sampleFormat.equals("UnsignedIntegral")) {
/* 1471 */         sf = 1;
/* 1472 */       } else if (sampleFormat.equals("Real")) {
/* 1473 */         sf = 3;
/* 1474 */       } else if (sampleFormat.equals("Index")) {
/* 1475 */         sf = 1;
/*      */       } 
/*      */       
/* 1478 */       if (sf != -1) {
/*      */         
/* 1480 */         int count = 1;
/*      */ 
/*      */         
/* 1483 */         TIFFField f = getTIFFField(277);
/* 1484 */         if (f != null) {
/* 1485 */           count = f.getAsInt(0);
/*      */         } else {
/*      */           
/* 1488 */           f = getTIFFField(258);
/* 1489 */           if (f != null) {
/* 1490 */             count = f.getCount();
/*      */           }
/*      */         } 
/*      */         
/* 1494 */         char[] sampleFormatArray = new char[count];
/* 1495 */         Arrays.fill(sampleFormatArray, (char)sf);
/*      */ 
/*      */         
/* 1498 */         TIFFTag tag = this.rootIFD.getTag(339);
/* 1499 */         f = new TIFFField(tag, 3, sampleFormatArray.length, sampleFormatArray);
/*      */         
/* 1501 */         this.rootIFD.addTIFFField(f);
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private static String getAttribute(Node node, String attrName) {
/* 1507 */     NamedNodeMap attrs = node.getAttributes();
/* 1508 */     Node attr = attrs.getNamedItem(attrName);
/* 1509 */     return (attr != null) ? attr.getNodeValue() : null;
/*      */   }
/*      */   
/*      */   private Node getChildNode(Node node, String childName) {
/* 1513 */     Node childNode = null;
/* 1514 */     if (node.hasChildNodes()) {
/* 1515 */       NodeList childNodes = node.getChildNodes();
/* 1516 */       int length = childNodes.getLength();
/* 1517 */       for (int i = 0; i < length; i++) {
/* 1518 */         Node item = childNodes.item(i);
/* 1519 */         if (item.getNodeName().equals(childName)) {
/* 1520 */           childNode = item;
/*      */           break;
/*      */         } 
/*      */       } 
/*      */     } 
/* 1525 */     return childNode;
/*      */   }
/*      */   
/*      */   public static TIFFIFD parseIFD(Node node) throws IIOInvalidTreeException {
/* 1529 */     if (!node.getNodeName().equals("TIFFIFD")) {
/* 1530 */       fatal(node, "Expected \"TIFFIFD\" node");
/*      */     }
/*      */     
/* 1533 */     String tagSetNames = getAttribute(node, "tagSets");
/* 1534 */     List<TIFFTagSet> tagSets = new ArrayList(5);
/*      */     
/* 1536 */     if (tagSetNames != null) {
/* 1537 */       StringTokenizer st = new StringTokenizer(tagSetNames, ",");
/* 1538 */       while (st.hasMoreTokens()) {
/* 1539 */         String className = st.nextToken();
/*      */         
/* 1541 */         Object o = null;
/*      */         try {
/* 1543 */           Class<?> setClass = Class.forName(className);
/* 1544 */           Method getInstanceMethod = setClass.getMethod("getInstance", (Class[])null);
/*      */           
/* 1546 */           o = getInstanceMethod.invoke(null, (Object[])null);
/* 1547 */         } catch (NoSuchMethodException e) {
/* 1548 */           throw new RuntimeException(e);
/* 1549 */         } catch (IllegalAccessException e) {
/* 1550 */           throw new RuntimeException(e);
/* 1551 */         } catch (InvocationTargetException e) {
/* 1552 */           throw new RuntimeException(e);
/* 1553 */         } catch (ClassNotFoundException e) {
/* 1554 */           throw new RuntimeException(e);
/*      */         } 
/*      */         
/* 1557 */         if (!(o instanceof TIFFTagSet)) {
/* 1558 */           fatal(node, "Specified tag set class \"" + className + "\" is not an instance of TIFFTagSet");
/*      */           
/*      */           continue;
/*      */         } 
/* 1562 */         tagSets.add((TIFFTagSet)o);
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1567 */     TIFFIFD ifd = new TIFFIFD(tagSets);
/*      */     
/* 1569 */     node = node.getFirstChild();
/* 1570 */     while (node != null) {
/* 1571 */       String name = node.getNodeName();
/*      */       
/* 1573 */       TIFFField f = null;
/* 1574 */       if (name.equals("TIFFIFD")) {
/* 1575 */         int type; TIFFIFD subIFD = parseIFD(node);
/* 1576 */         String parentTagName = getAttribute(node, "parentTagName");
/* 1577 */         String parentTagNumber = getAttribute(node, "parentTagNumber");
/* 1578 */         TIFFTag tag = null;
/* 1579 */         if (parentTagName != null) {
/* 1580 */           tag = TIFFIFD.getTag(parentTagName, tagSets);
/* 1581 */         } else if (parentTagNumber != null) {
/* 1582 */           int tagNumber = Integer.valueOf(parentTagNumber).intValue();
/*      */           
/* 1584 */           tag = TIFFIFD.getTag(tagNumber, tagSets);
/*      */         } 
/*      */         
/* 1587 */         if (tag == null) {
/* 1588 */           tag = new TIFFTag("unknown", 0, 0, null);
/*      */         }
/*      */ 
/*      */         
/* 1592 */         if (tag.isDataTypeOK(13)) {
/* 1593 */           type = 13;
/*      */         } else {
/* 1595 */           type = 4;
/*      */         } 
/*      */         
/* 1598 */         f = new TIFFField(tag, type, 1, subIFD);
/* 1599 */       } else if (name.equals("TIFFField")) {
/* 1600 */         int number = Integer.parseInt(getAttribute(node, "number"));
/*      */         
/* 1602 */         TIFFTagSet tagSet = null;
/* 1603 */         Iterator<TIFFTagSet> iter = tagSets.iterator();
/* 1604 */         while (iter.hasNext()) {
/* 1605 */           TIFFTagSet t = iter.next();
/* 1606 */           if (t.getTag(number) != null) {
/* 1607 */             tagSet = t;
/*      */             
/*      */             break;
/*      */           } 
/*      */         } 
/* 1612 */         f = TIFFField.createFromMetadataNode(tagSet, node);
/*      */       } else {
/* 1614 */         fatal(node, "Expected either \"TIFFIFD\" or \"TIFFField\" node, got " + name);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1619 */       ifd.addTIFFField(f);
/* 1620 */       node = node.getNextSibling();
/*      */     } 
/*      */     
/* 1623 */     return ifd;
/*      */   }
/*      */   
/*      */   private void mergeNativeTree(Node root) throws IIOInvalidTreeException {
/* 1627 */     Node node = root;
/* 1628 */     if (!node.getNodeName().equals("com_sun_media_imageio_plugins_tiff_image_1.0")) {
/* 1629 */       fatal(node, "Root must be com_sun_media_imageio_plugins_tiff_image_1.0");
/*      */     }
/*      */     
/* 1632 */     node = node.getFirstChild();
/* 1633 */     if (node == null || !node.getNodeName().equals("TIFFIFD")) {
/* 1634 */       fatal(root, "Root must have \"TIFFIFD\" child");
/*      */     }
/* 1636 */     TIFFIFD ifd = parseIFD(node);
/*      */     
/* 1638 */     List rootIFDTagSets = this.rootIFD.getTagSetList();
/* 1639 */     Iterator tagSetIter = ifd.getTagSetList().iterator();
/* 1640 */     while (tagSetIter.hasNext()) {
/* 1641 */       Object o = tagSetIter.next();
/* 1642 */       if (o instanceof TIFFTagSet && !rootIFDTagSets.contains(o)) {
/* 1643 */         this.rootIFD.addTagSet((TIFFTagSet)o);
/*      */       }
/*      */     } 
/*      */     
/* 1647 */     Iterator<TIFFField> ifdIter = ifd.iterator();
/* 1648 */     while (ifdIter.hasNext()) {
/* 1649 */       TIFFField field = ifdIter.next();
/* 1650 */       this.rootIFD.addTIFFField(field);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void mergeTree(String formatName, Node root) throws IIOInvalidTreeException {
/* 1656 */     if (formatName.equals("com_sun_media_imageio_plugins_tiff_image_1.0")) {
/* 1657 */       if (root == null) {
/* 1658 */         throw new IllegalArgumentException("root == null!");
/*      */       }
/* 1660 */       mergeNativeTree(root);
/* 1661 */     } else if (formatName.equals("javax_imageio_1.0")) {
/*      */       
/* 1663 */       if (root == null) {
/* 1664 */         throw new IllegalArgumentException("root == null!");
/*      */       }
/* 1666 */       mergeStandardTree(root);
/*      */     } else {
/* 1668 */       throw new IllegalArgumentException("Not a recognized format!");
/*      */     } 
/*      */   }
/*      */   
/*      */   public void reset() {
/* 1673 */     this.rootIFD = new TIFFIFD(this.tagSets);
/*      */   }
/*      */   
/*      */   public TIFFIFD getRootIFD() {
/* 1677 */     return this.rootIFD;
/*      */   }
/*      */   
/*      */   public TIFFField getTIFFField(int tagNumber) {
/* 1681 */     return this.rootIFD.getTIFFField(tagNumber);
/*      */   }
/*      */   
/*      */   public void removeTIFFField(int tagNumber) {
/* 1685 */     this.rootIFD.removeTIFFField(tagNumber);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TIFFImageMetadata getShallowClone() {
/* 1694 */     return new TIFFImageMetadata(this.rootIFD.getShallowClone());
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/tiff/TIFFImageMetadata.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */