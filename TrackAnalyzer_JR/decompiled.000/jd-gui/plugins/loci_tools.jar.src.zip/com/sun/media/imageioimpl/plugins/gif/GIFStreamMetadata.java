/*     */ package com.sun.media.imageioimpl.plugins.gif;
/*     */ 
/*     */ import javax.imageio.metadata.IIOInvalidTreeException;
/*     */ import javax.imageio.metadata.IIOMetadataNode;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GIFStreamMetadata
/*     */   extends GIFMetadata
/*     */ {
/*     */   static final String nativeMetadataFormatName = "javax_imageio_gif_stream_1.0";
/* 103 */   public static final String[] versionStrings = new String[] { "87a", "89a" };
/*     */   
/*     */   public String version;
/*     */   
/*     */   public int logicalScreenWidth;
/*     */   
/*     */   public int logicalScreenHeight;
/*     */   public int colorResolution;
/*     */   public int pixelAspectRatio;
/*     */   public int backgroundColorIndex;
/*     */   public boolean sortFlag;
/* 114 */   public static final String[] colorTableSizes = new String[] { "2", "4", "8", "16", "32", "64", "128", "256" };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 119 */   public byte[] globalColorTable = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected GIFStreamMetadata(boolean standardMetadataFormatSupported, String nativeMetadataFormatName, String nativeMetadataFormatClassName, String[] extraMetadataFormatNames, String[] extraMetadataFormatClassNames) {
/* 127 */     super(standardMetadataFormatSupported, nativeMetadataFormatName, nativeMetadataFormatClassName, extraMetadataFormatNames, extraMetadataFormatClassNames);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GIFStreamMetadata() {
/* 135 */     this(true, "javax_imageio_gif_stream_1.0", "com.sun.media.imageioimpl.plugins.gif.GIFStreamMetadataFormat", null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isReadOnly() {
/* 143 */     return true;
/*     */   }
/*     */   
/*     */   public Node getAsTree(String formatName) {
/* 147 */     if (formatName.equals("javax_imageio_gif_stream_1.0"))
/* 148 */       return getNativeTree(); 
/* 149 */     if (formatName.equals("javax_imageio_1.0"))
/*     */     {
/* 151 */       return getStandardTree();
/*     */     }
/* 153 */     throw new IllegalArgumentException("Not a recognized format!");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Node getNativeTree() {
/* 159 */     IIOMetadataNode root = new IIOMetadataNode("javax_imageio_gif_stream_1.0");
/*     */ 
/*     */     
/* 162 */     IIOMetadataNode node = new IIOMetadataNode("Version");
/* 163 */     node.setAttribute("value", this.version);
/* 164 */     root.appendChild(node);
/*     */ 
/*     */     
/* 167 */     node = new IIOMetadataNode("LogicalScreenDescriptor");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 172 */     node.setAttribute("logicalScreenWidth", (this.logicalScreenWidth == -1) ? "" : Integer.toString(this.logicalScreenWidth));
/*     */ 
/*     */     
/* 175 */     node.setAttribute("logicalScreenHeight", (this.logicalScreenHeight == -1) ? "" : Integer.toString(this.logicalScreenHeight));
/*     */ 
/*     */ 
/*     */     
/* 179 */     node.setAttribute("colorResolution", (this.colorResolution == -1) ? "" : Integer.toString(this.colorResolution));
/*     */ 
/*     */     
/* 182 */     node.setAttribute("pixelAspectRatio", Integer.toString(this.pixelAspectRatio));
/*     */     
/* 184 */     root.appendChild(node);
/*     */     
/* 186 */     if (this.globalColorTable != null) {
/* 187 */       node = new IIOMetadataNode("GlobalColorTable");
/* 188 */       int numEntries = this.globalColorTable.length / 3;
/* 189 */       node.setAttribute("sizeOfGlobalColorTable", Integer.toString(numEntries));
/*     */       
/* 191 */       node.setAttribute("backgroundColorIndex", Integer.toString(this.backgroundColorIndex));
/*     */       
/* 193 */       node.setAttribute("sortFlag", this.sortFlag ? "TRUE" : "FALSE");
/*     */ 
/*     */       
/* 196 */       for (int i = 0; i < numEntries; i++) {
/* 197 */         IIOMetadataNode entry = new IIOMetadataNode("ColorTableEntry");
/*     */         
/* 199 */         entry.setAttribute("index", Integer.toString(i));
/* 200 */         int r = this.globalColorTable[3 * i] & 0xFF;
/* 201 */         int g = this.globalColorTable[3 * i + 1] & 0xFF;
/* 202 */         int b = this.globalColorTable[3 * i + 2] & 0xFF;
/* 203 */         entry.setAttribute("red", Integer.toString(r));
/* 204 */         entry.setAttribute("green", Integer.toString(g));
/* 205 */         entry.setAttribute("blue", Integer.toString(b));
/* 206 */         node.appendChild(entry);
/*     */       } 
/* 208 */       root.appendChild(node);
/*     */     } 
/*     */     
/* 211 */     return root;
/*     */   }
/*     */   
/*     */   public IIOMetadataNode getStandardChromaNode() {
/* 215 */     IIOMetadataNode chroma_node = new IIOMetadataNode("Chroma");
/* 216 */     IIOMetadataNode node = null;
/*     */     
/* 218 */     node = new IIOMetadataNode("ColorSpaceType");
/* 219 */     node.setAttribute("name", "RGB");
/* 220 */     chroma_node.appendChild(node);
/*     */     
/* 222 */     node = new IIOMetadataNode("BlackIsZero");
/* 223 */     node.setAttribute("value", "TRUE");
/* 224 */     chroma_node.appendChild(node);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 229 */     if (this.globalColorTable != null) {
/* 230 */       node = new IIOMetadataNode("Palette");
/* 231 */       int numEntries = this.globalColorTable.length / 3;
/* 232 */       for (int i = 0; i < numEntries; i++) {
/* 233 */         IIOMetadataNode entry = new IIOMetadataNode("PaletteEntry");
/*     */         
/* 235 */         entry.setAttribute("index", Integer.toString(i));
/* 236 */         entry.setAttribute("red", Integer.toString(this.globalColorTable[3 * i] & 0xFF));
/*     */         
/* 238 */         entry.setAttribute("green", Integer.toString(this.globalColorTable[3 * i + 1] & 0xFF));
/*     */         
/* 240 */         entry.setAttribute("blue", Integer.toString(this.globalColorTable[3 * i + 2] & 0xFF));
/*     */         
/* 242 */         node.appendChild(entry);
/*     */       } 
/* 244 */       chroma_node.appendChild(node);
/*     */ 
/*     */       
/* 247 */       node = new IIOMetadataNode("BackgroundIndex");
/* 248 */       node.setAttribute("value", Integer.toString(this.backgroundColorIndex));
/* 249 */       chroma_node.appendChild(node);
/*     */     } 
/*     */     
/* 252 */     return chroma_node;
/*     */   }
/*     */   
/*     */   public IIOMetadataNode getStandardCompressionNode() {
/* 256 */     IIOMetadataNode compression_node = new IIOMetadataNode("Compression");
/* 257 */     IIOMetadataNode node = null;
/*     */     
/* 259 */     node = new IIOMetadataNode("CompressionTypeName");
/* 260 */     node.setAttribute("value", "lzw");
/* 261 */     compression_node.appendChild(node);
/*     */     
/* 263 */     node = new IIOMetadataNode("Lossless");
/* 264 */     node.setAttribute("value", "true");
/* 265 */     compression_node.appendChild(node);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 270 */     return compression_node;
/*     */   }
/*     */   
/*     */   public IIOMetadataNode getStandardDataNode() {
/* 274 */     IIOMetadataNode data_node = new IIOMetadataNode("Data");
/* 275 */     IIOMetadataNode node = null;
/*     */ 
/*     */ 
/*     */     
/* 279 */     node = new IIOMetadataNode("SampleFormat");
/* 280 */     node.setAttribute("value", "Index");
/* 281 */     data_node.appendChild(node);
/*     */     
/* 283 */     node = new IIOMetadataNode("BitsPerSample");
/* 284 */     node.setAttribute("value", (this.colorResolution == -1) ? "" : Integer.toString(this.colorResolution));
/*     */ 
/*     */     
/* 287 */     data_node.appendChild(node);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 292 */     return data_node;
/*     */   }
/*     */   
/*     */   public IIOMetadataNode getStandardDimensionNode() {
/* 296 */     IIOMetadataNode dimension_node = new IIOMetadataNode("Dimension");
/* 297 */     IIOMetadataNode node = null;
/*     */     
/* 299 */     node = new IIOMetadataNode("PixelAspectRatio");
/* 300 */     float aspectRatio = 1.0F;
/* 301 */     if (this.pixelAspectRatio != 0) {
/* 302 */       aspectRatio = (this.pixelAspectRatio + 15) / 64.0F;
/*     */     }
/* 304 */     node.setAttribute("value", Float.toString(aspectRatio));
/* 305 */     dimension_node.appendChild(node);
/*     */     
/* 307 */     node = new IIOMetadataNode("ImageOrientation");
/* 308 */     node.setAttribute("value", "Normal");
/* 309 */     dimension_node.appendChild(node);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 320 */     node = new IIOMetadataNode("HorizontalScreenSize");
/* 321 */     node.setAttribute("value", (this.logicalScreenWidth == -1) ? "" : Integer.toString(this.logicalScreenWidth));
/*     */ 
/*     */     
/* 324 */     dimension_node.appendChild(node);
/*     */     
/* 326 */     node = new IIOMetadataNode("VerticalScreenSize");
/* 327 */     node.setAttribute("value", (this.logicalScreenHeight == -1) ? "" : Integer.toString(this.logicalScreenHeight));
/*     */ 
/*     */     
/* 330 */     dimension_node.appendChild(node);
/*     */     
/* 332 */     return dimension_node;
/*     */   }
/*     */   
/*     */   public IIOMetadataNode getStandardDocumentNode() {
/* 336 */     IIOMetadataNode document_node = new IIOMetadataNode("Document");
/* 337 */     IIOMetadataNode node = null;
/*     */     
/* 339 */     node = new IIOMetadataNode("FormatVersion");
/* 340 */     node.setAttribute("value", this.version);
/* 341 */     document_node.appendChild(node);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 347 */     return document_node;
/*     */   }
/*     */ 
/*     */   
/*     */   public IIOMetadataNode getStandardTextNode() {
/* 352 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public IIOMetadataNode getStandardTransparencyNode() {
/* 357 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFromTree(String formatName, Node root) throws IIOInvalidTreeException {
/* 363 */     throw new IllegalStateException("Metadata is read-only!");
/*     */   }
/*     */ 
/*     */   
/*     */   protected void mergeNativeTree(Node root) throws IIOInvalidTreeException {
/* 368 */     throw new IllegalStateException("Metadata is read-only!");
/*     */   }
/*     */ 
/*     */   
/*     */   protected void mergeStandardTree(Node root) throws IIOInvalidTreeException {
/* 373 */     throw new IllegalStateException("Metadata is read-only!");
/*     */   }
/*     */   
/*     */   public void reset() {
/* 377 */     throw new IllegalStateException("Metadata is read-only!");
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/gif/GIFStreamMetadata.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */