/*      */ package com.sun.media.imageioimpl.plugins.jpeg2000;
/*      */ 
/*      */ import com.sun.media.imageioimpl.common.ImageUtil;
/*      */ import java.awt.Point;
/*      */ import java.awt.Rectangle;
/*      */ import java.awt.color.ColorSpace;
/*      */ import java.awt.image.BufferedImage;
/*      */ import java.awt.image.ColorModel;
/*      */ import java.awt.image.ComponentColorModel;
/*      */ import java.awt.image.MultiPixelPackedSampleModel;
/*      */ import java.awt.image.PixelInterleavedSampleModel;
/*      */ import java.awt.image.Raster;
/*      */ import java.awt.image.SampleModel;
/*      */ import java.awt.image.WritableRaster;
/*      */ import java.io.EOFException;
/*      */ import java.io.IOException;
/*      */ import java.util.Hashtable;
/*      */ import javax.imageio.ImageReadParam;
/*      */ import javax.imageio.ImageTypeSpecifier;
/*      */ import javax.imageio.stream.ImageInputStream;
/*      */ import jj2000.j2k.codestream.HeaderInfo;
/*      */ import jj2000.j2k.codestream.reader.BitstreamReaderAgent;
/*      */ import jj2000.j2k.codestream.reader.HeaderDecoder;
/*      */ import jj2000.j2k.decoder.DecoderSpecs;
/*      */ import jj2000.j2k.entropy.decoder.CodedCBlkDataSrcDec;
/*      */ import jj2000.j2k.entropy.decoder.EntropyDecoder;
/*      */ import jj2000.j2k.fileformat.reader.FileFormatReader;
/*      */ import jj2000.j2k.image.BlkImgDataSrc;
/*      */ import jj2000.j2k.image.DataBlk;
/*      */ import jj2000.j2k.image.DataBlkInt;
/*      */ import jj2000.j2k.image.ImgDataConverter;
/*      */ import jj2000.j2k.image.invcomptransf.InvCompTransf;
/*      */ import jj2000.j2k.io.RandomAccessIO;
/*      */ import jj2000.j2k.quantization.dequantizer.CBlkQuantDataSrcDec;
/*      */ import jj2000.j2k.quantization.dequantizer.Dequantizer;
/*      */ import jj2000.j2k.roi.ROIDeScaler;
/*      */ import jj2000.j2k.wavelet.synthesis.CBlkWTDataSrcDec;
/*      */ import jj2000.j2k.wavelet.synthesis.InverseWT;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class J2KReadState
/*      */ {
/*  135 */   private ImageInputStream iis = null;
/*      */   private FileFormatReader ff;
/*      */   private HeaderInfo hi;
/*      */   private HeaderDecoder hd;
/*      */   private RandomAccessIO in;
/*      */   private BitstreamReaderAgent breader;
/*      */   private EntropyDecoder entdec;
/*      */   private ROIDeScaler roids;
/*      */   private Dequantizer deq;
/*      */   private InverseWT invWT;
/*      */   private InvCompTransf ictransf;
/*      */   private ImgDataConverter converter;
/*      */   private ImgDataConverter converter2;
/*  148 */   private DecoderSpecs decSpec = null;
/*  149 */   private J2KImageReadParamJava j2krparam = null;
/*  150 */   private int[] destinationBands = null;
/*  151 */   private int[] sourceBands = null;
/*      */   
/*  153 */   private int[] levelShift = null;
/*  154 */   private int[] minValues = null;
/*  155 */   private int[] maxValues = null;
/*  156 */   private int[] fracBits = null;
/*  157 */   private DataBlkInt[] dataBlocks = null;
/*      */   
/*  159 */   private int[] bandOffsets = null;
/*  160 */   private int maxDepth = 0;
/*      */   
/*      */   private boolean isSigned = false;
/*  163 */   private ColorModel colorModel = null;
/*  164 */   private SampleModel sampleModel = null;
/*  165 */   private int nComp = 0;
/*  166 */   private int tileWidth = 0;
/*  167 */   private int tileHeight = 0; private int scaleX;
/*      */   private int scaleY;
/*      */   private int xOffset;
/*      */   private int yOffset;
/*  171 */   private Rectangle destinationRegion = null;
/*      */   
/*      */   private Point sourceOrigin;
/*      */   
/*      */   private int tileXOffset;
/*      */   private int tileYOffset;
/*      */   private int width;
/*      */   private int height;
/*  179 */   private int[] pixbuf = null;
/*  180 */   private byte[] bytebuf = null;
/*  181 */   private int[] channelMap = null;
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean noTransform = true;
/*      */ 
/*      */ 
/*      */   
/*      */   private int resolution;
/*      */ 
/*      */ 
/*      */   
/*      */   private int stepX;
/*      */ 
/*      */ 
/*      */   
/*      */   private int stepY;
/*      */ 
/*      */   
/*      */   private int tileStepX;
/*      */ 
/*      */   
/*      */   private int tileStepY;
/*      */ 
/*      */   
/*      */   private J2KMetadata metadata;
/*      */ 
/*      */   
/*      */   private BufferedImage destImage;
/*      */ 
/*      */   
/*      */   private J2KImageReader reader;
/*      */ 
/*      */ 
/*      */   
/*      */   public J2KReadState(ImageInputStream iis, J2KImageReadParamJava param, J2KMetadata metadata, J2KImageReader reader) {
/*  217 */     if (iis == null || param == null || metadata == null) {
/*  218 */       throw new IllegalArgumentException(I18N.getString("J2KReadState0"));
/*      */     }
/*  220 */     this.iis = iis;
/*  221 */     this.j2krparam = param;
/*  222 */     this.metadata = metadata;
/*  223 */     this.reader = reader;
/*      */     
/*  225 */     initializeRead(0, param, metadata);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public J2KReadState(ImageInputStream iis, J2KImageReadParamJava param, J2KImageReader reader) {
/*  239 */     if (iis == null || param == null) {
/*  240 */       throw new IllegalArgumentException(I18N.getString("J2KReadState0"));
/*      */     }
/*  242 */     this.iis = iis;
/*  243 */     this.j2krparam = param;
/*  244 */     this.reader = reader;
/*  245 */     initializeRead(0, param, null);
/*      */   }
/*      */   
/*      */   public int getWidth() throws IOException {
/*  249 */     return this.width;
/*      */   }
/*      */   
/*      */   public int getHeight() throws IOException {
/*  253 */     return this.height;
/*      */   }
/*      */   
/*      */   public HeaderDecoder getHeader() {
/*  257 */     return this.hd;
/*      */   }
/*      */ 
/*      */   
/*      */   public Raster getTile(int tileX, int tileY, WritableRaster raster) throws IOException {
/*  262 */     Point nT = this.ictransf.getNumTiles(null);
/*      */     
/*  264 */     if (this.noTransform) {
/*  265 */       int tOffx, tOffy, cTileWidth, cTileHeight; if (tileX >= nT.x || tileY >= nT.y) {
/*  266 */         throw new IllegalArgumentException(I18N.getString("J2KImageReader0"));
/*      */       }
/*  268 */       this.ictransf.setTile(tileX * this.tileStepX, tileY * this.tileStepY);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  276 */       if ((raster != null && this.resolution < (this.hd.getDecoderSpecs()).dls.getMin()) || this.stepX != 1 || this.stepY != 1) {
/*      */ 
/*      */         
/*  279 */         tOffx = raster.getMinX();
/*  280 */         tOffy = raster.getMinY();
/*  281 */         cTileWidth = Math.min(raster.getWidth(), this.ictransf.getTileWidth());
/*      */         
/*  283 */         cTileHeight = Math.min(raster.getHeight(), this.ictransf.getTileHeight());
/*      */       } else {
/*      */         
/*  286 */         tOffx = this.ictransf.getCompULX(0) - (this.ictransf.getImgULX() + this.ictransf.getCompSubsX(0) - 1) / this.ictransf.getCompSubsX(0) + this.destinationRegion.x;
/*      */ 
/*      */         
/*  289 */         tOffy = this.ictransf.getCompULY(0) - (this.ictransf.getImgULY() + this.ictransf.getCompSubsY(0) - 1) / this.ictransf.getCompSubsY(0) + this.destinationRegion.y;
/*      */ 
/*      */         
/*  292 */         cTileWidth = this.ictransf.getTileWidth();
/*  293 */         cTileHeight = this.ictransf.getTileHeight();
/*      */       } 
/*      */       
/*  296 */       if (raster == null) {
/*  297 */         raster = Raster.createWritableRaster(this.sampleModel, new Point(tOffx, tOffy));
/*      */       }
/*      */       
/*  300 */       int numBands = this.sampleModel.getNumBands();
/*      */       
/*  302 */       if (tOffx + cTileWidth >= this.destinationRegion.width + this.destinationRegion.x)
/*      */       {
/*  304 */         cTileWidth = this.destinationRegion.width + this.destinationRegion.x - tOffx;
/*      */       }
/*      */       
/*  307 */       if (tOffy + cTileHeight >= this.destinationRegion.height + this.destinationRegion.y)
/*      */       {
/*  309 */         cTileHeight = this.destinationRegion.height + this.destinationRegion.y - tOffy;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  314 */       if (this.pixbuf == null || this.pixbuf.length < cTileWidth * numBands)
/*  315 */         this.pixbuf = new int[cTileWidth * numBands]; 
/*  316 */       boolean prog = false;
/*      */ 
/*      */       
/*  319 */       for (int l = 0; l < cTileHeight && 
/*  320 */         !this.reader.getAbortRequest(); l++)
/*      */       {
/*      */ 
/*      */         
/*  324 */         for (int i = 0; i < numBands && 
/*  325 */           !this.reader.getAbortRequest(); i++)
/*      */         {
/*  327 */           DataBlkInt db = this.dataBlocks[i];
/*  328 */           db.ulx = 0;
/*  329 */           db.uly = l;
/*  330 */           db.w = cTileWidth;
/*  331 */           db.h = 1;
/*  332 */           this.ictransf.getInternCompData((DataBlk)db, this.channelMap[this.sourceBands[i]]);
/*  333 */           prog = (prog || db.progressive);
/*      */           
/*  335 */           int[] data = db.data;
/*  336 */           int k1 = db.offset + cTileWidth - 1;
/*      */           
/*  338 */           int fracBit = this.fracBits[i];
/*  339 */           int lS = this.levelShift[i];
/*  340 */           int min = this.minValues[i];
/*  341 */           int max = this.maxValues[i];
/*      */           
/*  343 */           if (ImageUtil.isBinary(this.sampleModel))
/*      */           {
/*  345 */             min = 0;
/*  346 */             max = 1;
/*  347 */             if (this.bytebuf == null || this.bytebuf.length < cTileWidth * numBands)
/*  348 */               this.bytebuf = new byte[cTileWidth * numBands]; 
/*  349 */             int j = cTileWidth - 1;
/*  350 */             for (; j >= 0; j--) {
/*  351 */               int tmp = (data[k1--] >> fracBit) + lS;
/*  352 */               this.bytebuf[j] = (byte)((tmp < min) ? min : ((tmp > max) ? max : tmp));
/*      */             } 
/*      */ 
/*      */ 
/*      */             
/*  357 */             ImageUtil.setUnpackedBinaryData(this.bytebuf, raster, new Rectangle(tOffx, tOffy + l, cTileWidth, 1));
/*      */ 
/*      */           
/*      */           }
/*      */           else
/*      */           {
/*      */ 
/*      */             
/*  365 */             int j = cTileWidth - 1;
/*  366 */             for (; j >= 0; j--) {
/*  367 */               int tmp = (data[k1--] >> fracBit) + lS;
/*  368 */               this.pixbuf[j] = (tmp < min) ? min : ((tmp > max) ? max : tmp);
/*      */             } 
/*      */ 
/*      */             
/*  372 */             raster.setSamples(tOffx, tOffy + l, cTileWidth, 1, this.destinationBands[i], this.pixbuf);
/*      */           }
/*      */         
/*      */         }
/*      */       
/*      */       }
/*      */     
/*      */     }
/*      */     else {
/*      */       
/*  382 */       readSubsampledRaster(raster);
/*      */     } 
/*      */     
/*  385 */     return raster;
/*      */   }
/*      */   
/*      */   public Rectangle getDestinationRegion() {
/*  389 */     return this.destinationRegion;
/*      */   }
/*      */   
/*      */   public BufferedImage readBufferedImage() throws IOException {
/*  393 */     this.colorModel = getColorModel();
/*  394 */     this.sampleModel = getSampleModel();
/*  395 */     WritableRaster raster = null;
/*  396 */     BufferedImage image = this.j2krparam.getDestination();
/*      */     
/*  398 */     int x = this.destinationRegion.x;
/*  399 */     int y = this.destinationRegion.y;
/*  400 */     this.destinationRegion.setLocation(this.j2krparam.getDestinationOffset());
/*  401 */     if (image == null) {
/*      */       
/*  403 */       ImageTypeSpecifier type = this.j2krparam.getDestinationType();
/*  404 */       if (type != null) {
/*  405 */         this.colorModel = type.getColorModel();
/*      */       }
/*  407 */       raster = Raster.createWritableRaster(this.sampleModel.createCompatibleSampleModel(this.destinationRegion.x + this.destinationRegion.width, this.destinationRegion.y + this.destinationRegion.height), new Point(0, 0));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  413 */       image = new BufferedImage(this.colorModel, raster, this.colorModel.isAlphaPremultiplied(), new Hashtable<Object, Object>());
/*      */     }
/*      */     else {
/*      */       
/*  417 */       raster = image.getWritableTile(0, 0);
/*      */     } 
/*  419 */     this.destImage = image;
/*  420 */     readSubsampledRaster(raster);
/*  421 */     this.destinationRegion.setLocation(x, y);
/*  422 */     this.destImage = null;
/*  423 */     return image;
/*      */   }
/*      */   
/*      */   public Raster readAsRaster() throws IOException {
/*  427 */     BufferedImage image = this.j2krparam.getDestination();
/*  428 */     WritableRaster raster = null;
/*      */     
/*  430 */     if (image == null) {
/*  431 */       this.sampleModel = getSampleModel();
/*  432 */       raster = Raster.createWritableRaster(this.sampleModel.createCompatibleSampleModel(this.destinationRegion.x + this.destinationRegion.width, this.destinationRegion.y + this.destinationRegion.height), new Point(0, 0));
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */       
/*  439 */       raster = image.getWritableTile(0, 0);
/*      */     } 
/*  441 */     readSubsampledRaster(raster);
/*  442 */     return raster;
/*      */   }
/*      */ 
/*      */   
/*      */   private void initializeRead(int imageIndex, J2KImageReadParamJava param, J2KMetadata metadata) {
/*      */     try {
/*  448 */       this.iis.mark();
/*  449 */       this.in = new IISRandomAccessIO(this.iis);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  454 */       this.ff = new FileFormatReader(this.in, metadata);
/*  455 */       this.ff.readFileFormat();
/*  456 */       this.in.seek(this.ff.getFirstCodeStreamPos());
/*      */       
/*  458 */       this.hi = new HeaderInfo();
/*      */       try {
/*  460 */         this.hd = new HeaderDecoder(this.in, this.j2krparam, this.hi);
/*  461 */       } catch (EOFException e) {
/*  462 */         throw new RuntimeException(I18N.getString("J2KReadState2"));
/*  463 */       } catch (IOException ioe) {
/*  464 */         throw new RuntimeException(ioe);
/*      */       } 
/*      */       
/*  467 */       this.width = this.hd.getImgWidth();
/*  468 */       this.height = this.hd.getImgHeight();
/*      */       
/*  470 */       Rectangle sourceRegion = param.getSourceRegion();
/*  471 */       this.sourceOrigin = new Point();
/*  472 */       sourceRegion = new Rectangle(this.hd.getImgULX(), this.hd.getImgULY(), this.width, this.height);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  477 */       boolean compConsistent = true;
/*  478 */       this.stepX = this.hd.getCompSubsX(0);
/*  479 */       this.stepY = this.hd.getCompSubsY(0);
/*  480 */       for (int i = 1; i < this.nComp; i++) {
/*  481 */         if (this.stepX != this.hd.getCompSubsX(i) || this.stepY != this.hd.getCompSubsY(i)) {
/*  482 */           throw new RuntimeException(I18N.getString("J2KReadState12"));
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/*  487 */       int minResLevels = (this.hd.getDecoderSpecs()).dls.getMin();
/*      */ 
/*      */       
/*  490 */       this.resolution = (param != null) ? param.getResolution() : minResLevels;
/*      */       
/*  492 */       if (this.resolution < 0 || this.resolution > minResLevels) {
/*  493 */         this.resolution = minResLevels;
/*      */       }
/*      */ 
/*      */       
/*  497 */       if (this.resolution != minResLevels || this.stepX != 1 || this.stepY != 1) {
/*  498 */         sourceRegion = J2KImageReader.getReducedRect(sourceRegion, minResLevels, this.resolution, this.stepX, this.stepY);
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  503 */       this.destinationRegion = (Rectangle)sourceRegion.clone();
/*      */       
/*  505 */       J2KImageReader.computeRegionsWrapper((ImageReadParam)param, false, this.width, this.height, param.getDestination(), sourceRegion, this.destinationRegion);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  513 */       this.sourceOrigin = new Point(sourceRegion.x, sourceRegion.y);
/*  514 */       this.scaleX = param.getSourceXSubsampling();
/*  515 */       this.scaleY = param.getSourceYSubsampling();
/*  516 */       this.xOffset = param.getSubsamplingXOffset();
/*  517 */       this.yOffset = param.getSubsamplingYOffset();
/*      */       
/*  519 */       this.width = this.destinationRegion.width;
/*  520 */       this.height = this.destinationRegion.height;
/*      */       
/*  522 */       Point tileOffset = this.hd.getTilingOrigin(null);
/*      */       
/*  524 */       this.tileWidth = this.hd.getNomTileWidth();
/*  525 */       this.tileHeight = this.hd.getNomTileHeight();
/*      */ 
/*      */       
/*  528 */       if (this.resolution != minResLevels || this.stepX != 1 || this.stepY != 1) {
/*  529 */         Rectangle tileRect = new Rectangle(tileOffset);
/*  530 */         tileRect.width = this.tileWidth;
/*  531 */         tileRect.height = this.tileHeight;
/*  532 */         tileRect = J2KImageReader.getReducedRect(tileRect, minResLevels, this.resolution, this.stepX, this.stepY);
/*      */ 
/*      */         
/*  535 */         tileOffset = tileRect.getLocation();
/*  536 */         this.tileWidth = tileRect.width;
/*  537 */         this.tileHeight = tileRect.height;
/*      */       } 
/*      */       
/*  540 */       this.tileXOffset = tileOffset.x;
/*  541 */       this.tileYOffset = tileOffset.y;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  549 */       if (this.tileWidth * (1 << minResLevels - this.resolution) * this.stepX > this.hd.getNomTileWidth()) {
/*      */         
/*  551 */         this.tileStepX = (this.tileWidth * (1 << minResLevels - this.resolution) * this.stepX + this.hd.getNomTileWidth() - 1) / this.hd.getNomTileWidth();
/*      */       }
/*      */       else {
/*      */         
/*  555 */         this.tileStepX = 1;
/*      */       } 
/*      */       
/*  558 */       if (this.tileHeight * (1 << minResLevels - this.resolution) * this.stepY > this.hd.getNomTileHeight()) {
/*      */         
/*  560 */         this.tileStepY = (this.tileHeight * (1 << minResLevels - this.resolution) * this.stepY + this.hd.getNomTileHeight() - 1) / this.hd.getNomTileHeight();
/*      */       }
/*      */       else {
/*      */         
/*  564 */         this.tileStepY = 1;
/*      */       } 
/*      */       
/*  567 */       if (!this.destinationRegion.equals(sourceRegion)) {
/*  568 */         this.noTransform = false;
/*      */       }
/*      */ 
/*      */       
/*  572 */       this.decSpec = this.hd.getDecoderSpecs();
/*      */ 
/*      */ 
/*      */       
/*  576 */       this.nComp = this.hd.getNumComps();
/*      */       
/*  578 */       int[] depth = new int[this.nComp];
/*  579 */       for (int j = 0; j < this.nComp; j++) {
/*  580 */         depth[j] = this.hd.getOriginalBitDepth(j);
/*      */       }
/*      */       
/*  583 */       ChannelDefinitionBox cdb = null;
/*  584 */       if (metadata != null) {
/*  585 */         cdb = (ChannelDefinitionBox)metadata.getElement("JPEG2000ChannelDefinitionBox");
/*      */       }
/*  587 */       this.channelMap = new int[this.nComp];
/*  588 */       if (cdb != null && metadata.getElement("JPEG2000PaletteBox") == null)
/*      */       
/*  590 */       { short[] assoc = cdb.getAssociation();
/*  591 */         short[] types = cdb.getTypes();
/*  592 */         short[] channels = cdb.getChannel();
/*      */         
/*  594 */         for (int m = 0; m < types.length; m++) {
/*  595 */           if (types[m] == 0)
/*  596 */           { this.channelMap[channels[m]] = assoc[m] - 1; }
/*  597 */           else if (types[m] == 1 || types[m] == 2)
/*  598 */           { this.channelMap[channels[m]] = channels[m]; } 
/*      */         }  }
/*  600 */       else { for (int m = 0; m < this.nComp; m++) {
/*  601 */           this.channelMap[m] = m;
/*      */         } }
/*      */ 
/*      */       
/*      */       try {
/*  606 */         boolean logJJ2000Messages = Boolean.getBoolean("jj2000.j2k.decoder.log");
/*      */         
/*  608 */         this.breader = BitstreamReaderAgent.createInstance(this.in, this.hd, this.j2krparam, this.decSpec, logJJ2000Messages, this.hi);
/*      */ 
/*      */       
/*      */       }
/*  612 */       catch (IOException e) {
/*  613 */         throw new RuntimeException(I18N.getString("J2KReadState3") + " " + ((e.getMessage() != null) ? (":\n" + e.getMessage()) : ""));
/*      */       
/*      */       }
/*  616 */       catch (IllegalArgumentException e) {
/*  617 */         throw new RuntimeException(I18N.getString("J2KReadState4") + " " + ((e.getMessage() != null) ? (":\n" + e.getMessage()) : ""));
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/*  624 */         this.entdec = this.hd.createEntropyDecoder((CodedCBlkDataSrcDec)this.breader, this.j2krparam);
/*  625 */       } catch (IllegalArgumentException e) {
/*  626 */         throw new RuntimeException(I18N.getString("J2KReadState5") + " " + ((e.getMessage() != null) ? (":\n" + e.getMessage()) : ""));
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/*  633 */         this.roids = this.hd.createROIDeScaler((CBlkQuantDataSrcDec)this.entdec, this.j2krparam, this.decSpec);
/*  634 */       } catch (IllegalArgumentException e) {
/*  635 */         throw new RuntimeException(I18N.getString("J2KReadState6") + " " + ((e.getMessage() != null) ? (":\n" + e.getMessage()) : ""));
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/*  643 */         this.deq = this.hd.createDequantizer((CBlkQuantDataSrcDec)this.roids, depth, this.decSpec);
/*  644 */       } catch (IllegalArgumentException e) {
/*  645 */         throw new RuntimeException(I18N.getString("J2KReadState7") + " " + ((e.getMessage() != null) ? (":\n" + e.getMessage()) : ""));
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/*  653 */         this.invWT = InverseWT.createInstance((CBlkWTDataSrcDec)this.deq, this.decSpec);
/*  654 */       } catch (IllegalArgumentException e) {
/*  655 */         throw new RuntimeException(I18N.getString("J2KReadState8") + " " + ((e.getMessage() != null) ? (":\n" + e.getMessage()) : ""));
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  660 */       int res = this.breader.getImgRes();
/*  661 */       int mrl = this.decSpec.dls.getMin();
/*  662 */       this.invWT.setImgResLevel(res);
/*      */ 
/*      */       
/*  665 */       this.converter = new ImgDataConverter((BlkImgDataSrc)this.invWT, 0);
/*      */ 
/*      */       
/*  668 */       this.ictransf = new InvCompTransf((BlkImgDataSrc)this.converter, this.decSpec, depth);
/*      */ 
/*      */       
/*  671 */       this.sourceBands = this.j2krparam.getSourceBands();
/*      */       
/*  673 */       if (this.sourceBands == null) {
/*  674 */         this.sourceBands = new int[this.nComp];
/*  675 */         for (int m = 0; m < this.nComp; m++) {
/*  676 */           this.sourceBands[m] = m;
/*      */         }
/*      */       } 
/*  679 */       this.nComp = this.sourceBands.length;
/*      */       
/*  681 */       this.destinationBands = this.j2krparam.getDestinationBands();
/*  682 */       if (this.destinationBands == null) {
/*  683 */         this.destinationBands = new int[this.nComp];
/*  684 */         for (int m = 0; m < this.nComp; m++) {
/*  685 */           this.destinationBands[m] = m;
/*      */         }
/*      */       } 
/*  688 */       J2KImageReader.checkReadParamBandSettingsWrapper((ImageReadParam)param, this.hd.getNumComps(), this.destinationBands.length);
/*      */ 
/*      */ 
/*      */       
/*  692 */       this.levelShift = new int[this.nComp];
/*  693 */       this.minValues = new int[this.nComp];
/*  694 */       this.maxValues = new int[this.nComp];
/*  695 */       this.fracBits = new int[this.nComp];
/*  696 */       this.dataBlocks = new DataBlkInt[this.nComp];
/*      */       
/*  698 */       depth = new int[this.nComp];
/*  699 */       this.bandOffsets = new int[this.nComp];
/*  700 */       this.maxDepth = 0;
/*  701 */       this.isSigned = false;
/*  702 */       for (int k = 0; k < this.nComp; k++) {
/*  703 */         depth[k] = this.hd.getOriginalBitDepth(this.sourceBands[k]);
/*  704 */         if (depth[k] > this.maxDepth)
/*  705 */           this.maxDepth = depth[k]; 
/*  706 */         this.dataBlocks[k] = new DataBlkInt();
/*      */ 
/*      */ 
/*      */         
/*  710 */         this.bandOffsets[k] = k;
/*  711 */         if (this.hd.isOriginalSigned(this.sourceBands[k])) {
/*  712 */           this.isSigned = true;
/*      */         } else {
/*  714 */           this.levelShift[k] = 1 << this.ictransf.getNomRangeBits(this.sourceBands[k]) - 1;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  720 */         int nomRangeBits = this.ictransf.getNomRangeBits(this.sourceBands[k]);
/*  721 */         this.maxValues[k] = (1 << ((this.isSigned == true) ? (nomRangeBits - 1) : nomRangeBits)) - 1;
/*      */         
/*  723 */         this.minValues[k] = this.isSigned ? -(this.maxValues[k] + 1) : 0;
/*      */         
/*  725 */         this.fracBits[k] = this.ictransf.getFixedPoint(this.sourceBands[k]);
/*      */       } 
/*      */       
/*  728 */       this.iis.reset();
/*  729 */     } catch (IllegalArgumentException e) {
/*  730 */       throw new RuntimeException(e.getMessage(), e);
/*  731 */     } catch (Error e) {
/*  732 */       if (e.getMessage() != null) {
/*  733 */         throw new RuntimeException(e.getMessage(), e);
/*      */       }
/*  735 */       throw new RuntimeException(I18N.getString("J2KReadState9"), e);
/*      */     }
/*  737 */     catch (RuntimeException e) {
/*  738 */       if (e.getMessage() != null) {
/*  739 */         throw new RuntimeException(I18N.getString("J2KReadState10") + " " + e.getMessage(), e);
/*      */       }
/*      */       
/*  742 */       throw new RuntimeException(I18N.getString("J2KReadState10"), e);
/*      */     }
/*  744 */     catch (Throwable e) {
/*  745 */       throw new RuntimeException(I18N.getString("J2KReadState10"), e);
/*      */     } 
/*      */   }
/*      */   
/*      */   private Raster readSubsampledRaster(WritableRaster raster) throws IOException {
/*  750 */     if (raster == null) {
/*  751 */       raster = Raster.createWritableRaster(this.sampleModel.createCompatibleSampleModel(this.destinationRegion.x + this.destinationRegion.width, this.destinationRegion.y + this.destinationRegion.height), new Point(this.destinationRegion.x, this.destinationRegion.y));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  758 */     int[] pixbuf = null;
/*  759 */     boolean prog = false;
/*  760 */     Point nT = this.ictransf.getNumTiles(null);
/*  761 */     int numBands = this.sourceBands.length;
/*      */     
/*  763 */     Rectangle destRect = raster.getBounds().intersection(this.destinationRegion);
/*      */     
/*  765 */     int offx = this.destinationRegion.x;
/*  766 */     int offy = this.destinationRegion.y;
/*      */     
/*  768 */     int sourceSX = (destRect.x - offx) * this.scaleX + this.sourceOrigin.x;
/*  769 */     int sourceSY = (destRect.y - offy) * this.scaleY + this.sourceOrigin.y;
/*  770 */     int sourceEX = (destRect.width - 1) * this.scaleX + sourceSX;
/*  771 */     int sourceEY = (destRect.height - 1) * this.scaleY + sourceSY;
/*      */     
/*  773 */     int startXTile = (sourceSX - this.tileXOffset) / this.tileWidth;
/*  774 */     int startYTile = (sourceSY - this.tileYOffset) / this.tileHeight;
/*  775 */     int endXTile = (sourceEX - this.tileXOffset) / this.tileWidth;
/*  776 */     int endYTile = (sourceEY - this.tileYOffset) / this.tileHeight;
/*      */     
/*  778 */     startXTile = clip(startXTile, 0, nT.x - 1);
/*  779 */     startYTile = clip(startYTile, 0, nT.y - 1);
/*  780 */     endXTile = clip(endXTile, 0, nT.x - 1);
/*  781 */     endYTile = clip(endYTile, 0, nT.y - 1);
/*      */     
/*  783 */     int totalXTiles = endXTile - startXTile + 1;
/*  784 */     int totalYTiles = endYTile - startYTile + 1;
/*  785 */     int totalTiles = totalXTiles * totalYTiles;
/*      */ 
/*      */     
/*  788 */     for (int y = startYTile; y <= endYTile && 
/*  789 */       !this.reader.getAbortRequest(); y++) {
/*      */ 
/*      */ 
/*      */       
/*  793 */       for (int x = startXTile; x <= endXTile && 
/*  794 */         !this.reader.getAbortRequest(); x++) {
/*      */ 
/*      */         
/*  797 */         float initialFraction = ((x - startXTile + (y - startYTile) * totalXTiles) / totalTiles);
/*      */ 
/*      */         
/*  800 */         this.ictransf.setTile(x * this.tileStepX, y * this.tileStepY);
/*      */         
/*  802 */         int sx = this.hd.getCompSubsX(0);
/*  803 */         int cTileWidth = (this.ictransf.getTileWidth() + sx - 1) / sx;
/*  804 */         int sy = this.hd.getCompSubsY(0);
/*  805 */         int cTileHeight = (this.ictransf.getTileHeight() + sy - 1) / sy;
/*      */ 
/*      */         
/*  808 */         int tx = 0;
/*  809 */         int ty = 0;
/*      */ 
/*      */         
/*  812 */         int startX = this.tileXOffset + x * this.tileWidth;
/*  813 */         int startY = this.tileYOffset + y * this.tileHeight;
/*      */ 
/*      */         
/*  816 */         if (sourceSX > startX) {
/*  817 */           if (startX >= this.hd.getImgULX()) {
/*  818 */             tx = sourceSX - startX;
/*  819 */             cTileWidth -= tx;
/*      */           } 
/*  821 */           startX = sourceSX;
/*      */         } 
/*      */ 
/*      */         
/*  825 */         if (sourceSY > startY) {
/*  826 */           if (startY >= this.hd.getImgULY()) {
/*  827 */             ty = sourceSY - startY;
/*  828 */             cTileHeight -= ty;
/*      */           } 
/*  830 */           startY = sourceSY;
/*      */         } 
/*      */ 
/*      */         
/*  834 */         if (sourceEX < startX + cTileWidth - 1) {
/*  835 */           cTileWidth += sourceEX - startX - cTileWidth + 1;
/*      */         }
/*  837 */         if (sourceEY < startY + cTileHeight - 1) {
/*  838 */           cTileHeight += sourceEY - startY - cTileHeight + 1;
/*      */         }
/*      */ 
/*      */         
/*  842 */         int x1 = (startX + this.scaleX - 1 - this.sourceOrigin.x) / this.scaleX;
/*  843 */         int x2 = (startX + this.scaleX - 1 + cTileWidth - this.sourceOrigin.x) / this.scaleX;
/*      */         
/*  845 */         int lineLength = x2 - x1;
/*  846 */         if (pixbuf == null || pixbuf.length < lineLength)
/*  847 */           pixbuf = new int[lineLength]; 
/*  848 */         x2 = (x2 - 1) * this.scaleX + this.sourceOrigin.x - startX;
/*      */         
/*  850 */         int y1 = (startY + this.scaleY - 1 - this.sourceOrigin.y) / this.scaleY;
/*      */         
/*  852 */         x1 += offx;
/*  853 */         y1 += offy;
/*      */ 
/*      */         
/*  856 */         boolean ycbcr = false;
/*      */         
/*  858 */         for (int i = 0; i < numBands; i++) {
/*  859 */           DataBlkInt db = this.dataBlocks[i];
/*  860 */           db.ulx = tx;
/*  861 */           db.uly = ty + cTileHeight - 1;
/*  862 */           db.w = cTileWidth;
/*  863 */           db.h = 1;
/*      */           
/*      */           try {
/*  866 */             this.ictransf.getInternCompData((DataBlk)db, this.channelMap[this.sourceBands[i]]);
/*      */           }
/*  868 */           catch (ArrayIndexOutOfBoundsException e) {
/*  869 */             ycbcr = true;
/*      */             
/*      */             break;
/*      */           } 
/*      */         } 
/*      */         
/*  875 */         int l = ty, m = y1;
/*  876 */         for (; l < ty + cTileHeight; 
/*  877 */           l += this.scaleY, m++) {
/*  878 */           if (this.reader.getAbortRequest()) {
/*      */             break;
/*      */           }
/*      */           
/*  882 */           if (ycbcr) {
/*  883 */             DataBlkInt lum = this.dataBlocks[0];
/*  884 */             DataBlkInt cb = this.dataBlocks[1];
/*  885 */             DataBlkInt cr = this.dataBlocks[2];
/*      */             
/*  887 */             lum.ulx = tx;
/*  888 */             lum.uly = l;
/*  889 */             lum.w = cTileWidth;
/*  890 */             lum.h = 1;
/*  891 */             this.ictransf.getInternCompData((DataBlk)lum, this.channelMap[this.sourceBands[0]]);
/*  892 */             prog = (prog || lum.progressive);
/*      */             
/*  894 */             cb.ulx = tx;
/*  895 */             cb.uly = l;
/*  896 */             cb.w = cTileWidth / 2;
/*  897 */             cb.h = 1;
/*  898 */             this.ictransf.getInternCompData((DataBlk)cb, this.channelMap[this.sourceBands[1]]);
/*  899 */             prog = (prog || cb.progressive);
/*      */             
/*  901 */             cr.ulx = tx;
/*  902 */             cr.uly = l;
/*  903 */             cr.w = cTileWidth / 2;
/*  904 */             cr.h = 1;
/*  905 */             this.ictransf.getInternCompData((DataBlk)cr, this.channelMap[this.sourceBands[2]]);
/*  906 */             prog = (prog || cr.progressive);
/*      */             
/*  908 */             int[] lumdata = lum.data;
/*  909 */             int[] cbdata = cb.data;
/*  910 */             int[] crdata = cr.data;
/*      */             
/*  912 */             int k1 = lum.offset + x2;
/*      */             
/*  914 */             int fracBit = this.fracBits[0];
/*  915 */             int lS = this.levelShift[0];
/*  916 */             int min = this.minValues[0];
/*  917 */             int max = this.maxValues[0];
/*      */             
/*  919 */             int[][] pix = new int[3][lineLength];
/*      */             
/*  921 */             for (int j = lineLength - 1; j >= 0; j--, k1 -= this.scaleX) {
/*  922 */               int red = (lumdata[k1] >> fracBit) + lS;
/*  923 */               red = (red < min) ? min : ((red > max) ? max : red);
/*      */               
/*  925 */               int cIndex = k1 / 2;
/*      */               
/*  927 */               int chrom1 = cbdata[cIndex];
/*  928 */               int chrom2 = crdata[cIndex];
/*  929 */               int lumval = red;
/*      */               
/*  931 */               red = (int)(chrom2 * 1.542D + lumval);
/*  932 */               int blue = (int)(lumval + 1.772D * chrom1 - 0.886D);
/*  933 */               int green = (int)(lumval - 0.34413D * chrom1 - 0.71414D * chrom2 - 0.1228785D);
/*      */ 
/*      */               
/*  936 */               if (red > 255) red = 255; 
/*  937 */               if (green > 255) green = 255; 
/*  938 */               if (blue > 255) blue = 255;
/*      */               
/*  940 */               if (red < 0) red = 0; 
/*  941 */               if (green < 0) green = 0; 
/*  942 */               if (blue < 0) blue = 0;
/*      */               
/*  944 */               pix[0][j] = red;
/*  945 */               pix[1][j] = green;
/*  946 */               pix[2][j] = blue;
/*      */             } 
/*      */ 
/*      */             
/*  950 */             raster.setSamples(x1, m, lineLength, 1, this.destinationBands[0], pix[0]);
/*      */             
/*  952 */             raster.setSamples(x1, m, lineLength, 1, this.destinationBands[1], pix[1]);
/*      */             
/*  954 */             raster.setSamples(x1, m, lineLength, 1, this.destinationBands[2], pix[2]);
/*      */ 
/*      */           
/*      */           }
/*      */           else {
/*      */ 
/*      */             
/*  961 */             for (int j = 0; j < numBands; j++) {
/*  962 */               DataBlkInt db = this.dataBlocks[j];
/*  963 */               db.ulx = tx;
/*  964 */               db.uly = l;
/*  965 */               db.w = (ycbcr && j > 0) ? (cTileWidth / 2) : cTileWidth;
/*  966 */               db.h = 1;
/*  967 */               this.ictransf.getInternCompData((DataBlk)db, this.channelMap[this.sourceBands[j]]);
/*  968 */               prog = (prog || db.progressive);
/*      */               
/*  970 */               int[] data = db.data;
/*  971 */               int k1 = db.offset + x2;
/*      */               
/*  973 */               int fracBit = this.fracBits[j];
/*  974 */               int lS = this.levelShift[j];
/*  975 */               int min = this.minValues[j];
/*  976 */               int max = this.maxValues[j];
/*      */               
/*  978 */               if (ImageUtil.isBinary(this.sampleModel)) {
/*      */                 
/*  980 */                 min = 0;
/*  981 */                 max = 1;
/*  982 */                 if (this.bytebuf == null || this.bytebuf.length < cTileWidth * numBands)
/*  983 */                   this.bytebuf = new byte[cTileWidth * numBands]; 
/*  984 */                 for (int k = lineLength - 1; k >= 0; k--, k1 -= this.scaleX) {
/*  985 */                   int tmp = (data[k1] >> fracBit) + lS;
/*  986 */                   this.bytebuf[k] = (byte)((tmp < min) ? min : ((tmp > max) ? max : tmp));
/*      */                 } 
/*      */ 
/*      */ 
/*      */                 
/*  991 */                 ImageUtil.setUnpackedBinaryData(this.bytebuf, raster, new Rectangle(x1, m, lineLength, 1));
/*      */ 
/*      */               
/*      */               }
/*      */               else {
/*      */ 
/*      */                 
/*  998 */                 for (int k = lineLength - 1; k >= 0; k--, k1 -= this.scaleX) {
/*  999 */                   int tmp = (data[k1] >> fracBit) + lS;
/* 1000 */                   pixbuf[k] = (tmp < min) ? min : ((tmp > max) ? max : tmp);
/*      */                 } 
/*      */ 
/*      */ 
/*      */                 
/* 1005 */                 raster.setSamples(x1, m, lineLength, 1, this.destinationBands[j], pixbuf);
/*      */               } 
/*      */             } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1014 */             if (this.destImage != null) {
/* 1015 */               this.reader.processImageUpdateWrapper(this.destImage, x1, m, cTileWidth, 1, 1, 1, this.destinationBands);
/*      */             }
/*      */ 
/*      */             
/* 1019 */             float fraction = initialFraction + ((l - ty) + 1.0F) / cTileHeight / totalTiles;
/*      */             
/* 1021 */             this.reader.processImageProgressWrapper(100.0F * fraction);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/* 1026 */     return raster;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ImageTypeSpecifier getImageType() throws IOException {
/* 1032 */     getSampleModel();
/* 1033 */     getColorModel();
/*      */     
/* 1035 */     return new ImageTypeSpecifier(this.colorModel, this.sampleModel);
/*      */   }
/*      */   
/*      */   public SampleModel getSampleModel() {
/* 1039 */     if (this.sampleModel != null) {
/* 1040 */       return this.sampleModel;
/*      */     }
/* 1042 */     int realWidth = Math.min(this.tileWidth, this.width);
/* 1043 */     int realHeight = Math.min(this.tileHeight, this.height);
/*      */     
/* 1045 */     if (this.nComp == 1 && (this.maxDepth == 1 || this.maxDepth == 2 || this.maxDepth == 4)) {
/* 1046 */       this.sampleModel = new MultiPixelPackedSampleModel(0, realWidth, realHeight, this.maxDepth);
/*      */ 
/*      */ 
/*      */     
/*      */     }
/* 1051 */     else if (this.maxDepth <= 8) {
/* 1052 */       this.sampleModel = new PixelInterleavedSampleModel(0, realWidth, realHeight, this.nComp, realWidth * this.nComp, this.bandOffsets);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/* 1059 */     else if (this.maxDepth <= 16) {
/* 1060 */       this.sampleModel = new PixelInterleavedSampleModel(this.isSigned ? 2 : 1, realWidth, realHeight, this.nComp, realWidth * this.nComp, this.bandOffsets);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/* 1068 */     else if (this.maxDepth <= 32) {
/* 1069 */       this.sampleModel = new PixelInterleavedSampleModel(3, realWidth, realHeight, this.nComp, realWidth * this.nComp, this.bandOffsets);
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */ 
/*      */       
/* 1077 */       throw new IllegalArgumentException(I18N.getString("J2KReadState11") + " " + this.maxDepth);
/*      */     } 
/* 1079 */     return this.sampleModel;
/*      */   }
/*      */ 
/*      */   
/*      */   public ColorModel getColorModel() {
/* 1084 */     if (this.colorModel != null) {
/* 1085 */       return this.colorModel;
/*      */     }
/*      */     
/* 1088 */     this.colorModel = this.ff.getColorModel();
/* 1089 */     if (this.colorModel != null) {
/* 1090 */       return this.colorModel;
/*      */     }
/* 1092 */     if (this.hi.siz.csiz <= 4) {
/*      */       ColorSpace cs;
/*      */ 
/*      */       
/* 1096 */       if (this.hi.siz.csiz > 2) {
/* 1097 */         cs = ColorSpace.getInstance(1000);
/*      */       } else {
/* 1099 */         cs = ColorSpace.getInstance(1003);
/*      */       } 
/*      */       
/* 1102 */       int[] bitsPerComponent = new int[this.hi.siz.csiz];
/* 1103 */       boolean isSigned = false;
/* 1104 */       int maxBitDepth = -1;
/* 1105 */       for (int i = 0; i < this.hi.siz.csiz; i++) {
/* 1106 */         bitsPerComponent[i] = this.hi.siz.getOrigBitDepth(i);
/* 1107 */         if (maxBitDepth < bitsPerComponent[i]) {
/* 1108 */           maxBitDepth = bitsPerComponent[i];
/*      */         }
/* 1110 */         isSigned |= this.hi.siz.isOrigSigned(i);
/*      */       } 
/*      */       
/* 1113 */       boolean hasAlpha = (this.hi.siz.csiz % 2 == 0);
/*      */       
/* 1115 */       int type = -1;
/*      */       
/* 1117 */       if (maxBitDepth <= 8) {
/* 1118 */         type = 0;
/* 1119 */       } else if (maxBitDepth <= 16) {
/* 1120 */         type = isSigned ? 2 : 1;
/* 1121 */       } else if (maxBitDepth <= 32) {
/* 1122 */         type = 3;
/*      */       } 
/*      */       
/* 1125 */       if (type != -1) {
/* 1126 */         if (this.hi.siz.csiz == 1 && (maxBitDepth == 1 || maxBitDepth == 2 || maxBitDepth == 4)) {
/*      */           
/* 1128 */           this.colorModel = ImageUtil.createColorModel(getSampleModel());
/*      */         } else {
/* 1130 */           this.colorModel = new ComponentColorModel(cs, bitsPerComponent, hasAlpha, false, hasAlpha ? 3 : 1, type);
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1140 */         return this.colorModel;
/*      */       } 
/*      */     } 
/*      */     
/* 1144 */     if (this.sampleModel == null) {
/* 1145 */       this.sampleModel = getSampleModel();
/*      */     }
/*      */     
/* 1148 */     if (this.sampleModel == null) {
/* 1149 */       return null;
/*      */     }
/* 1151 */     return ImageUtil.createColorModel(null, this.sampleModel);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Rectangle getTile0Rect() {
/* 1159 */     return new Rectangle(this.tileXOffset, this.tileYOffset, this.tileWidth, this.tileHeight);
/*      */   }
/*      */   
/*      */   private int clip(int value, int min, int max) {
/* 1163 */     if (value < min)
/* 1164 */       value = min; 
/* 1165 */     if (value > max)
/* 1166 */       value = max; 
/* 1167 */     return value;
/*      */   }
/*      */   
/*      */   private void clipDestination(Rectangle dest) {
/* 1171 */     Point offset = this.j2krparam.getDestinationOffset();
/* 1172 */     if (dest.x < offset.x) {
/* 1173 */       dest.width += dest.x - offset.x;
/* 1174 */       dest.x = offset.x;
/*      */     } 
/* 1176 */     if (dest.y < offset.y) {
/* 1177 */       dest.height += dest.y - offset.y;
/* 1178 */       dest.y = offset.y;
/*      */     } 
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/jpeg2000/J2KReadState.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */