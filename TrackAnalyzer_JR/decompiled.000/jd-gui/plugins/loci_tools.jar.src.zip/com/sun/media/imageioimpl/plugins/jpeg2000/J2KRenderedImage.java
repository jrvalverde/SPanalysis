/*     */ package com.sun.media.imageioimpl.plugins.jpeg2000;
/*     */ 
/*     */ import com.sun.media.imageioimpl.common.SimpleRenderedImage;
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.image.Raster;
/*     */ import java.awt.image.WritableRaster;
/*     */ import java.io.IOException;
/*     */ import javax.imageio.stream.ImageInputStream;
/*     */ import jj2000.j2k.codestream.reader.HeaderDecoder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class J2KRenderedImage
/*     */   extends SimpleRenderedImage
/*     */ {
/*     */   private Raster currentTile;
/*     */   private Point currentTileGrid;
/*     */   private J2KReadState readState;
/*     */   
/*     */   public J2KRenderedImage(ImageInputStream iis, J2KImageReadParamJava param, J2KMetadata metadata, J2KImageReader reader) throws IOException {
/* 103 */     this(new J2KReadState(iis, param, metadata, reader));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public J2KRenderedImage(ImageInputStream iis, J2KImageReadParamJava param, J2KImageReader reader) throws IOException {
/* 109 */     this(new J2KReadState(iis, param, reader));
/*     */   }
/*     */   
/*     */   public J2KRenderedImage(J2KReadState readState) {
/* 113 */     this.readState = readState;
/*     */     
/* 115 */     HeaderDecoder hd = readState.getHeader();
/*     */ 
/*     */     
/* 118 */     Rectangle destinationRegion = readState.getDestinationRegion();
/* 119 */     this.width = destinationRegion.width;
/* 120 */     this.height = destinationRegion.height;
/* 121 */     this.minX = destinationRegion.x;
/* 122 */     this.minY = destinationRegion.y;
/*     */     
/* 124 */     Rectangle tile0Rect = readState.getTile0Rect();
/* 125 */     this.tileWidth = tile0Rect.width;
/* 126 */     this.tileHeight = tile0Rect.height;
/* 127 */     this.tileGridXOffset = tile0Rect.x;
/* 128 */     this.tileGridYOffset = tile0Rect.y;
/*     */     
/* 130 */     this.sampleModel = readState.getSampleModel();
/* 131 */     this.colorModel = readState.getColorModel();
/*     */   }
/*     */   
/*     */   public synchronized Raster getTile(int tileX, int tileY) {
/* 135 */     if (this.currentTile != null && this.currentTileGrid.x == tileX && this.currentTileGrid.y == tileY)
/*     */     {
/*     */       
/* 138 */       return this.currentTile;
/*     */     }
/* 140 */     if (tileX >= getNumXTiles() || tileY >= getNumYTiles()) {
/* 141 */       throw new IllegalArgumentException(I18N.getString("J2KReadState1"));
/*     */     }
/*     */     try {
/* 144 */       int x = tileXToX(tileX);
/* 145 */       int y = tileYToY(tileY);
/* 146 */       this.currentTile = Raster.createWritableRaster(this.sampleModel, new Point(x, y));
/*     */ 
/*     */       
/* 149 */       this.currentTile = this.readState.getTile(tileX, tileY, (WritableRaster)this.currentTile);
/*     */     
/*     */     }
/* 152 */     catch (IOException e) {
/* 153 */       throw new RuntimeException(e);
/*     */     } 
/*     */     
/* 156 */     if (this.currentTileGrid == null) {
/* 157 */       this.currentTileGrid = new Point(tileX, tileY);
/*     */     } else {
/* 159 */       this.currentTileGrid.x = tileX;
/* 160 */       this.currentTileGrid.y = tileY;
/*     */     } 
/*     */     
/* 163 */     return this.currentTile;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/jpeg2000/J2KRenderedImage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */