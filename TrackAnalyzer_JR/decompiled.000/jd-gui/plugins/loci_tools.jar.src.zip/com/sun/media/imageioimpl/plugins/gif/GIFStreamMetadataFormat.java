/*     */ package com.sun.media.imageioimpl.plugins.gif;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import javax.imageio.ImageTypeSpecifier;
/*     */ import javax.imageio.metadata.IIOMetadataFormat;
/*     */ import javax.imageio.metadata.IIOMetadataFormatImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GIFStreamMetadataFormat
/*     */   extends IIOMetadataFormatImpl
/*     */ {
/*  91 */   private static IIOMetadataFormat instance = null;
/*     */   
/*     */   private GIFStreamMetadataFormat() {
/*  94 */     super("javax_imageio_gif_stream_1.0", 2);
/*     */ 
/*     */ 
/*     */     
/*  98 */     addElement("Version", "javax_imageio_gif_stream_1.0", 0);
/*     */     
/* 100 */     addAttribute("Version", "value", 0, true, (String)null, Arrays.asList(GIFStreamMetadata.versionStrings));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 105 */     addElement("LogicalScreenDescriptor", "javax_imageio_gif_stream_1.0", 0);
/*     */ 
/*     */     
/* 108 */     addAttribute("LogicalScreenDescriptor", "logicalScreenWidth", 2, true, null, "1", "65535", true, true);
/*     */ 
/*     */     
/* 111 */     addAttribute("LogicalScreenDescriptor", "logicalScreenHeight", 2, true, null, "1", "65535", true, true);
/*     */ 
/*     */     
/* 114 */     addAttribute("LogicalScreenDescriptor", "colorResolution", 2, true, null, "1", "8", true, true);
/*     */ 
/*     */     
/* 117 */     addAttribute("LogicalScreenDescriptor", "pixelAspectRatio", 2, true, null, "0", "255", true, true);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 122 */     addElement("GlobalColorTable", "javax_imageio_gif_stream_1.0", 2, 256);
/*     */ 
/*     */     
/* 125 */     addAttribute("GlobalColorTable", "sizeOfGlobalColorTable", 2, true, (String)null, Arrays.asList(GIFStreamMetadata.colorTableSizes));
/*     */ 
/*     */     
/* 128 */     addAttribute("GlobalColorTable", "backgroundColorIndex", 2, true, null, "0", "255", true, true);
/*     */ 
/*     */     
/* 131 */     addBooleanAttribute("GlobalColorTable", "sortFlag", false, false);
/*     */ 
/*     */ 
/*     */     
/* 135 */     addElement("ColorTableEntry", "GlobalColorTable", 0);
/*     */     
/* 137 */     addAttribute("ColorTableEntry", "index", 2, true, null, "0", "255", true, true);
/*     */ 
/*     */     
/* 140 */     addAttribute("ColorTableEntry", "red", 2, true, null, "0", "255", true, true);
/*     */ 
/*     */     
/* 143 */     addAttribute("ColorTableEntry", "green", 2, true, null, "0", "255", true, true);
/*     */ 
/*     */     
/* 146 */     addAttribute("ColorTableEntry", "blue", 2, true, null, "0", "255", true, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canNodeAppear(String elementName, ImageTypeSpecifier imageType) {
/* 153 */     return true;
/*     */   }
/*     */   
/*     */   public static synchronized IIOMetadataFormat getInstance() {
/* 157 */     if (instance == null) {
/* 158 */       instance = new GIFStreamMetadataFormat();
/*     */     }
/* 160 */     return instance;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/gif/GIFStreamMetadataFormat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */