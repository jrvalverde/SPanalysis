/*     */ package com.sun.media.imageioimpl.plugins.jpeg2000;
/*     */ 
/*     */ import com.sun.media.imageioimpl.common.ImageUtil;
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.imageio.IIOException;
/*     */ import javax.imageio.metadata.IIOInvalidTreeException;
/*     */ import javax.imageio.metadata.IIOMetadataNode;
/*     */ import javax.imageio.stream.ImageInputStream;
/*     */ import javax.imageio.stream.ImageOutputStream;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Box
/*     */ {
/* 112 */   private static Hashtable names = new Hashtable<Object, Object>();
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/* 117 */     names.put(new Integer(1783636000), "JPEG2000SignatureBox");
/* 118 */     names.put(new Integer(1718909296), "JPEG2000FileTypeBox");
/*     */ 
/*     */ 
/*     */     
/* 122 */     names.put(new Integer(1785737833), "JPEG2000IntellectualPropertyRightsBox");
/*     */     
/* 124 */     names.put(new Integer(2020437024), "JPEG2000XMLBox");
/* 125 */     names.put(new Integer(1970628964), "JPEG2000UUIDBox");
/* 126 */     names.put(new Integer(1969843814), "JPEG2000UUIDInfoBox");
/*     */ 
/*     */     
/* 129 */     names.put(new Integer(1785737832), "JPEG2000HeaderSuperBox");
/* 130 */     names.put(new Integer(1785737827), "JPEG2000CodeStreamBox");
/*     */ 
/*     */     
/* 133 */     names.put(new Integer(1768449138), "JPEG2000HeaderBox");
/*     */ 
/*     */     
/* 136 */     names.put(new Integer(1651532643), "JPEG2000BitsPerComponentBox");
/* 137 */     names.put(new Integer(1668246642), "JPEG2000ColorSpecificationBox");
/* 138 */     names.put(new Integer(1885564018), "JPEG2000PaletteBox");
/* 139 */     names.put(new Integer(1668112752), "JPEG2000ComponentMappingBox");
/* 140 */     names.put(new Integer(1667523942), "JPEG2000ChannelDefinitionBox");
/* 141 */     names.put(new Integer(1919251232), "JPEG2000ResolutionBox");
/*     */ 
/*     */     
/* 144 */     names.put(new Integer(1919251299), "JPEG2000CaptureResolutionBox");
/* 145 */     names.put(new Integer(1919251300), "JPEG2000DefaultDisplayResolutionBox");
/*     */ 
/*     */ 
/*     */     
/* 149 */     names.put(new Integer(1970041716), "JPEG2000UUIDListBox");
/* 150 */     names.put(new Integer(1970433056), "JPEG2000DataEntryURLBox");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 157 */   private static Hashtable boxClasses = new Hashtable<Object, Object>();
/*     */   protected int length;
/*     */   protected long extraLength;
/*     */   
/*     */   static {
/* 162 */     boxClasses.put(new Integer(1783636000), SignatureBox.class);
/* 163 */     boxClasses.put(new Integer(1718909296), FileTypeBox.class);
/*     */ 
/*     */ 
/*     */     
/* 167 */     boxClasses.put(new Integer(1785737833), Box.class);
/* 168 */     boxClasses.put(new Integer(2020437024), XMLBox.class);
/* 169 */     boxClasses.put(new Integer(1970628964), UUIDBox.class);
/*     */ 
/*     */     
/* 172 */     boxClasses.put(new Integer(1768449138), HeaderBox.class);
/*     */ 
/*     */     
/* 175 */     boxClasses.put(new Integer(1651532643), BitsPerComponentBox.class);
/* 176 */     boxClasses.put(new Integer(1668246642), ColorSpecificationBox.class);
/* 177 */     boxClasses.put(new Integer(1885564018), PaletteBox.class);
/* 178 */     boxClasses.put(new Integer(1668112752), ComponentMappingBox.class);
/* 179 */     boxClasses.put(new Integer(1667523942), ChannelDefinitionBox.class);
/* 180 */     boxClasses.put(new Integer(1919251232), ResolutionBox.class);
/*     */ 
/*     */     
/* 183 */     boxClasses.put(new Integer(1919251299), ResolutionBox.class);
/* 184 */     boxClasses.put(new Integer(1919251300), ResolutionBox.class);
/*     */ 
/*     */     
/* 187 */     boxClasses.put(new Integer(1970041716), UUIDListBox.class);
/* 188 */     boxClasses.put(new Integer(1970433056), DataEntryURLBox.class);
/*     */   }
/*     */ 
/*     */   
/*     */   protected int type;
/*     */   protected byte[] data;
/*     */   
/*     */   public static String getName(int type) {
/* 196 */     String name = (String)names.get(new Integer(type));
/* 197 */     return (name == null) ? "unknown" : name;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static Class getBoxClass(int type) {
/* 203 */     if (type == 1785737832 || type == 1919251232)
/* 204 */       return null; 
/* 205 */     return (Class)boxClasses.get(new Integer(type));
/*     */   }
/*     */ 
/*     */   
/*     */   public static String getTypeByName(String name) {
/* 210 */     Enumeration<Integer> keys = names.keys();
/* 211 */     while (keys.hasMoreElements()) {
/* 212 */       Integer i = keys.nextElement();
/* 213 */       if (name.equals(names.get(i)))
/* 214 */         return getTypeString(i.intValue()); 
/*     */     } 
/* 216 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Box createBox(int type, Node node) throws IIOInvalidTreeException {
/* 224 */     Class boxClass = (Class)boxClasses.get(new Integer(type));
/*     */ 
/*     */     
/*     */     try {
/* 228 */       Constructor<Box> cons = boxClass.getConstructor(new Class[] { Node.class });
/*     */       
/* 230 */       if (cons != null) {
/* 231 */         return cons.newInstance(new Object[] { node });
/*     */       }
/* 233 */     } catch (NoSuchMethodException e) {
/*     */       
/* 235 */       e.printStackTrace();
/* 236 */       return new Box(node);
/* 237 */     } catch (InvocationTargetException e) {
/* 238 */       e.printStackTrace();
/* 239 */       return new Box(node);
/* 240 */     } catch (IllegalAccessException e) {
/* 241 */       e.printStackTrace();
/* 242 */       return new Box(node);
/* 243 */     } catch (InstantiationException e) {
/* 244 */       e.printStackTrace();
/* 245 */       return new Box(node);
/*     */     } 
/*     */     
/* 248 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public static Object getAttribute(Node node, String name) {
/* 253 */     NamedNodeMap map = node.getAttributes();
/* 254 */     node = map.getNamedItem(name);
/* 255 */     return (node != null) ? node.getNodeValue() : null;
/*     */   }
/*     */ 
/*     */   
/*     */   public static byte[] parseByteArray(String value) {
/* 260 */     if (value == null) {
/* 261 */       return null;
/*     */     }
/* 263 */     StringTokenizer token = new StringTokenizer(value);
/* 264 */     int count = token.countTokens();
/*     */     
/* 266 */     byte[] buf = new byte[count];
/* 267 */     int i = 0;
/* 268 */     while (token.hasMoreElements()) {
/* 269 */       buf[i++] = (new Byte(token.nextToken())).byteValue();
/*     */     }
/* 271 */     return buf;
/*     */   }
/*     */ 
/*     */   
/*     */   protected static int[] parseIntArray(String value) {
/* 276 */     if (value == null) {
/* 277 */       return null;
/*     */     }
/* 279 */     StringTokenizer token = new StringTokenizer(value);
/* 280 */     int count = token.countTokens();
/*     */     
/* 282 */     int[] buf = new int[count];
/* 283 */     int i = 0;
/* 284 */     while (token.hasMoreElements()) {
/* 285 */       buf[i++] = (new Integer(token.nextToken())).intValue();
/*     */     }
/* 287 */     return buf;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static String getStringElementValue(Node node) {
/* 294 */     if (node instanceof IIOMetadataNode) {
/* 295 */       Object obj = ((IIOMetadataNode)node).getUserObject();
/* 296 */       if (obj instanceof String) {
/* 297 */         return (String)obj;
/*     */       }
/*     */     } 
/* 300 */     return node.getNodeValue();
/*     */   }
/*     */ 
/*     */   
/*     */   protected static byte getByteElementValue(Node node) {
/* 305 */     if (node instanceof IIOMetadataNode) {
/* 306 */       Object obj = ((IIOMetadataNode)node).getUserObject();
/* 307 */       if (obj instanceof Byte) {
/* 308 */         return ((Byte)obj).byteValue();
/*     */       }
/*     */     } 
/* 311 */     String value = node.getNodeValue();
/* 312 */     if (value != null)
/* 313 */       return (new Byte(value)).byteValue(); 
/* 314 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   protected static int getIntElementValue(Node node) {
/* 319 */     if (node instanceof IIOMetadataNode) {
/* 320 */       Object obj = ((IIOMetadataNode)node).getUserObject();
/* 321 */       if (obj instanceof Integer) {
/* 322 */         return ((Integer)obj).intValue();
/*     */       }
/*     */     } 
/* 325 */     String value = node.getNodeValue();
/* 326 */     if (value != null)
/* 327 */       return (new Integer(value)).intValue(); 
/* 328 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   protected static short getShortElementValue(Node node) {
/* 333 */     if (node instanceof IIOMetadataNode) {
/* 334 */       Object obj = ((IIOMetadataNode)node).getUserObject();
/* 335 */       if (obj instanceof Short)
/* 336 */         return ((Short)obj).shortValue(); 
/*     */     } 
/* 338 */     String value = node.getNodeValue();
/* 339 */     if (value != null)
/* 340 */       return (new Short(value)).shortValue(); 
/* 341 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   protected static byte[] getByteArrayElementValue(Node node) {
/* 346 */     if (node instanceof IIOMetadataNode) {
/* 347 */       Object obj = ((IIOMetadataNode)node).getUserObject();
/* 348 */       if (obj instanceof byte[]) {
/* 349 */         return (byte[])obj;
/*     */       }
/*     */     } 
/* 352 */     return parseByteArray(node.getNodeValue());
/*     */   }
/*     */ 
/*     */   
/*     */   protected static int[] getIntArrayElementValue(Node node) {
/* 357 */     if (node instanceof IIOMetadataNode) {
/* 358 */       Object obj = ((IIOMetadataNode)node).getUserObject();
/* 359 */       if (obj instanceof int[]) {
/* 360 */         return (int[])obj;
/*     */       }
/*     */     } 
/* 363 */     return parseIntArray(node.getNodeValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void copyInt(byte[] data, int pos, int value) {
/* 370 */     data[pos++] = (byte)(value >> 24);
/* 371 */     data[pos++] = (byte)(value >> 16);
/* 372 */     data[pos++] = (byte)(value >> 8);
/* 373 */     data[pos++] = (byte)(value & 0xFF);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getTypeString(int type) {
/* 380 */     byte[] buf = new byte[4];
/* 381 */     for (int i = 3; i >= 0; i--) {
/* 382 */       buf[i] = (byte)(type & 0xFF);
/* 383 */       type >>>= 8;
/*     */     } 
/*     */     
/* 386 */     return new String(buf);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getTypeInt(String s) {
/* 394 */     byte[] buf = s.getBytes();
/* 395 */     int t = buf[0];
/* 396 */     for (int i = 1; i < 4; i++) {
/* 397 */       t = t << 8 | buf[i];
/*     */     }
/*     */     
/* 400 */     return t;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Box(int length, int type, byte[] data) {
/* 420 */     this.type = type;
/* 421 */     setLength(length);
/* 422 */     setContent(data);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Box(int length, int type, long extraLength, byte[] data) {
/* 439 */     this.type = type;
/* 440 */     setLength(length);
/* 441 */     if (length == 1)
/* 442 */       setExtraLength(extraLength); 
/* 443 */     setContent(data);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Box(ImageInputStream iis, int pos) throws IOException {
/* 455 */     read(iis, pos);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Box(Node node) throws IIOInvalidTreeException {
/* 465 */     NodeList children = node.getChildNodes();
/*     */     
/* 467 */     String value = (String)getAttribute(node, "Type");
/* 468 */     this.type = getTypeInt(value);
/* 469 */     if (value == null || names.get(new Integer(this.type)) == null) {
/* 470 */       throw new IIOInvalidTreeException("Type is not defined", node);
/*     */     }
/* 472 */     value = (String)getAttribute(node, "Length");
/* 473 */     if (value != null) {
/* 474 */       this.length = (new Integer(value)).intValue();
/*     */     }
/* 476 */     value = (String)getAttribute(node, "ExtraLength");
/* 477 */     if (value != null) {
/* 478 */       this.extraLength = (new Long(value)).longValue();
/*     */     }
/* 480 */     for (int i = 0; i < children.getLength(); i++) {
/* 481 */       Node child = children.item(i);
/* 482 */       if ("Content".equals(child.getNodeName())) {
/* 483 */         if (child instanceof IIOMetadataNode) {
/* 484 */           IIOMetadataNode cnode = (IIOMetadataNode)child;
/*     */           try {
/* 486 */             this.data = (byte[])cnode.getUserObject();
/* 487 */           } catch (Exception e) {}
/*     */         } else {
/*     */           
/* 490 */           this.data = getByteArrayElementValue(child);
/*     */         } 
/*     */         
/* 493 */         if (this.data == null) {
/* 494 */           value = node.getNodeValue();
/* 495 */           if (value != null) {
/* 496 */             this.data = value.getBytes();
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IIOMetadataNode getNativeNode() {
/* 507 */     String name = getName(getType());
/* 508 */     if (name == null) {
/* 509 */       name = "unknown";
/*     */     }
/* 511 */     IIOMetadataNode node = new IIOMetadataNode(name);
/* 512 */     setDefaultAttributes(node);
/* 513 */     IIOMetadataNode child = new IIOMetadataNode("Content");
/* 514 */     child.setUserObject(this.data);
/* 515 */     child.setNodeValue(ImageUtil.convertObjectToString(this.data));
/* 516 */     node.appendChild(child);
/*     */     
/* 518 */     return node;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IIOMetadataNode getNativeNodeForSimpleBox() {
/*     */     try {
/* 530 */       Method m = getClass().getMethod("getElementNames", (Class[])null);
/*     */       
/* 532 */       String[] elementNames = (String[])m.invoke(null, (Object[])null);
/*     */       
/* 534 */       IIOMetadataNode node = new IIOMetadataNode(getName(getType()));
/* 535 */       setDefaultAttributes(node);
/* 536 */       for (int i = 0; i < elementNames.length; i++) {
/* 537 */         IIOMetadataNode child = new IIOMetadataNode(elementNames[i]);
/* 538 */         m = getClass().getMethod("get" + elementNames[i], (Class[])null);
/*     */         
/* 540 */         Object obj = m.invoke(this, (Object[])null);
/* 541 */         child.setUserObject(obj);
/* 542 */         child.setNodeValue(ImageUtil.convertObjectToString(obj));
/* 543 */         node.appendChild(child);
/*     */       } 
/* 545 */       return node;
/* 546 */     } catch (Exception e) {
/* 547 */       throw new IllegalArgumentException(I18N.getString("Box0"));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setDefaultAttributes(IIOMetadataNode node) {
/* 555 */     node.setAttribute("Length", Integer.toString(this.length));
/* 556 */     node.setAttribute("Type", getTypeString(this.type));
/*     */     
/* 558 */     if (this.length == 1) {
/* 559 */       node.setAttribute("ExtraLength", Long.toString(this.extraLength));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public int getLength() {
/* 565 */     return this.length;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getType() {
/* 570 */     return this.type;
/*     */   }
/*     */ 
/*     */   
/*     */   public long getExtraLength() {
/* 575 */     return this.extraLength;
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] getContent() {
/* 580 */     if (this.data == null)
/* 581 */       compose(); 
/* 582 */     return this.data;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setLength(int length) {
/* 587 */     this.length = length;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setExtraLength(long extraLength) {
/* 592 */     if (this.length != 1)
/* 593 */       throw new IllegalArgumentException(I18N.getString("Box1")); 
/* 594 */     this.extraLength = extraLength;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setContent(byte[] data) {
/* 601 */     if (data != null && ((this.length == 1 && this.extraLength - 16L != data.length) || (this.length != 1 && this.length - 8 != data.length)))
/*     */     {
/*     */       
/* 604 */       throw new IllegalArgumentException(I18N.getString("Box2")); } 
/* 605 */     this.data = data;
/* 606 */     if (data != null) {
/* 607 */       parse(data);
/*     */     }
/*     */   }
/*     */   
/*     */   public void write(ImageOutputStream ios) throws IOException {
/* 612 */     ios.writeInt(this.length);
/* 613 */     ios.writeInt(this.type);
/* 614 */     if (this.length == 1) {
/* 615 */       ios.writeLong(this.extraLength);
/* 616 */       ios.write(this.data, 0, (int)this.extraLength);
/* 617 */     } else if (this.data != null) {
/* 618 */       ios.write(this.data, 0, this.length);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void read(ImageInputStream iis, int pos) throws IOException {
/* 625 */     iis.mark();
/* 626 */     iis.seek(pos);
/* 627 */     this.length = iis.readInt();
/* 628 */     this.type = iis.readInt();
/* 629 */     int dataLength = 0;
/* 630 */     if (this.length == 0) {
/*     */       
/* 632 */       long streamLength = iis.length();
/* 633 */       if (streamLength != -1L) {
/*     */         
/* 635 */         dataLength = (int)(streamLength - iis.getStreamPosition());
/*     */       } else {
/*     */         
/* 638 */         long dataPos = iis.getStreamPosition();
/* 639 */         int bufLen = 1024;
/* 640 */         byte[] buf = new byte[bufLen];
/* 641 */         long savePos = dataPos;
/*     */         try {
/* 643 */           iis.readFully(buf);
/* 644 */           dataLength += bufLen;
/* 645 */           savePos = iis.getStreamPosition();
/* 646 */         } catch (EOFException eofe) {
/* 647 */           iis.seek(savePos);
/* 648 */           for (; iis.read() != -1; dataLength++);
/*     */         } 
/* 650 */         iis.seek(dataPos);
/*     */       } 
/* 652 */     } else if (this.length == 1) {
/*     */       
/* 654 */       this.extraLength = iis.readLong();
/* 655 */       dataLength = (int)(this.extraLength - 16L);
/* 656 */     } else if (this.length >= 8 && this.length < 1) {
/*     */       
/* 658 */       dataLength = this.length - 8;
/*     */     } else {
/*     */       
/* 661 */       throw new IIOException("Illegal value " + this.length + " for box length parameter.");
/*     */     } 
/*     */     
/* 664 */     this.data = new byte[dataLength];
/* 665 */     iis.readFully(this.data);
/* 666 */     iis.reset();
/*     */   }
/*     */   
/*     */   protected void parse(byte[] data) {}
/*     */   
/*     */   protected void compose() {}
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/jpeg2000/Box.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */