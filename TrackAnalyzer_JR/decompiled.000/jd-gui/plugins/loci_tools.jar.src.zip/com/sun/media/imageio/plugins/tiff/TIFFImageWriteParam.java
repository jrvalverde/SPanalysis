/*     */ package com.sun.media.imageio.plugins.tiff;
/*     */ 
/*     */ import com.sun.media.imageioimpl.plugins.tiff.TIFFImageWriter;
/*     */ import java.util.Locale;
/*     */ import javax.imageio.ImageWriteParam;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TIFFImageWriteParam
/*     */   extends ImageWriteParam
/*     */ {
/* 202 */   TIFFCompressor compressor = null;
/*     */   
/* 204 */   TIFFColorConverter colorConverter = null;
/*     */ 
/*     */ 
/*     */   
/*     */   int photometricInterpretation;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean appendedCompressionType = false;
/*     */ 
/*     */ 
/*     */   
/*     */   public TIFFImageWriteParam(Locale locale) {
/* 217 */     super(locale);
/* 218 */     this.canWriteCompressed = true;
/* 219 */     this.canWriteTiles = true;
/* 220 */     this.compressionTypes = TIFFImageWriter.TIFFCompressionTypes;
/*     */   }
/*     */   
/*     */   public boolean isCompressionLossless() {
/* 224 */     if (getCompressionMode() != 2) {
/* 225 */       throw new IllegalStateException("Compression mode not MODE_EXPLICIT!");
/*     */     }
/*     */ 
/*     */     
/* 229 */     if (this.compressionType == null) {
/* 230 */       throw new IllegalStateException("No compression type set!");
/*     */     }
/*     */     
/* 233 */     if (this.compressor != null && this.compressionType.equals(this.compressor.getCompressionType()))
/*     */     {
/* 235 */       return this.compressor.isCompressionLossless();
/*     */     }
/*     */     
/* 238 */     for (int i = 0; i < this.compressionTypes.length; i++) {
/* 239 */       if (this.compressionType.equals(this.compressionTypes[i])) {
/* 240 */         return TIFFImageWriter.isCompressionLossless[i];
/*     */       }
/*     */     } 
/*     */     
/* 244 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTIFFCompressor(TIFFCompressor compressor) {
/* 288 */     if (getCompressionMode() != 2) {
/* 289 */       throw new IllegalStateException("Compression mode not MODE_EXPLICIT!");
/*     */     }
/*     */ 
/*     */     
/* 293 */     this.compressor = compressor;
/*     */     
/* 295 */     if (this.appendedCompressionType) {
/*     */       
/* 297 */       int len = this.compressionTypes.length - 1;
/* 298 */       String[] types = new String[len];
/* 299 */       System.arraycopy(this.compressionTypes, 0, types, 0, len);
/* 300 */       this.compressionTypes = types;
/* 301 */       this.appendedCompressionType = false;
/*     */     } 
/*     */     
/* 304 */     if (compressor != null) {
/*     */       
/* 306 */       String compressorType = compressor.getCompressionType();
/* 307 */       int len = this.compressionTypes.length;
/* 308 */       boolean appendCompressionType = true;
/* 309 */       for (int i = 0; i < len; i++) {
/* 310 */         if (compressorType.equals(this.compressionTypes[i])) {
/* 311 */           appendCompressionType = false;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/* 316 */       if (appendCompressionType) {
/*     */         
/* 318 */         String[] types = new String[len + 1];
/* 319 */         System.arraycopy(this.compressionTypes, 0, types, 0, len);
/* 320 */         types[len] = compressorType;
/* 321 */         this.compressionTypes = types;
/* 322 */         this.appendedCompressionType = true;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TIFFCompressor getTIFFCompressor() {
/* 342 */     if (getCompressionMode() != 2) {
/* 343 */       throw new IllegalStateException("Compression mode not MODE_EXPLICIT!");
/*     */     }
/*     */     
/* 346 */     return this.compressor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setColorConverter(TIFFColorConverter colorConverter, int photometricInterpretation) {
/* 366 */     this.colorConverter = colorConverter;
/* 367 */     this.photometricInterpretation = photometricInterpretation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TIFFColorConverter getColorConverter() {
/* 381 */     return this.colorConverter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPhotometricInterpretation() {
/* 398 */     if (this.colorConverter == null) {
/* 399 */       throw new IllegalStateException("Color converter not set!");
/*     */     }
/* 401 */     return this.photometricInterpretation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unsetColorConverter() {
/* 411 */     this.colorConverter = null;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageio/plugins/tiff/TIFFImageWriteParam.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */