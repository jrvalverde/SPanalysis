/*     */ package com.sun.media.imageioimpl.plugins.pcx;
/*     */ 
/*     */ import javax.imageio.metadata.IIOInvalidTreeException;
/*     */ import javax.imageio.metadata.IIOMetadata;
/*     */ import javax.imageio.metadata.IIOMetadataNode;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PCXMetadata
/*     */   extends IIOMetadata
/*     */   implements Cloneable, PCXConstants
/*     */ {
/*     */   short version;
/*     */   byte bitsPerPixel;
/*     */   boolean gotxmin;
/*     */   boolean gotymin;
/*     */   short xmin;
/*     */   short ymin;
/*     */   int vdpi;
/*     */   int hdpi;
/*     */   int hsize;
/*     */   int vsize;
/*     */   
/*     */   PCXMetadata() {
/* 103 */     super(true, null, null, null, null);
/* 104 */     reset();
/*     */   }
/*     */   
/*     */   public Node getAsTree(String formatName) {
/* 108 */     if (formatName.equals("javax_imageio_1.0")) {
/* 109 */       return getStandardTree();
/*     */     }
/* 111 */     throw new IllegalArgumentException("Not a recognized format!");
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isReadOnly() {
/* 116 */     return false;
/*     */   }
/*     */   
/*     */   public void mergeTree(String formatName, Node root) throws IIOInvalidTreeException {
/* 120 */     if (formatName.equals("javax_imageio_1.0")) {
/* 121 */       if (root == null) {
/* 122 */         throw new IllegalArgumentException("root == null!");
/*     */       }
/* 124 */       mergeStandardTree(root);
/*     */     } else {
/* 126 */       throw new IllegalArgumentException("Not a recognized format!");
/*     */     } 
/*     */   }
/*     */   
/*     */   public void reset() {
/* 131 */     this.version = 5;
/* 132 */     this.bitsPerPixel = 0;
/* 133 */     this.gotxmin = false;
/* 134 */     this.gotymin = false;
/* 135 */     this.xmin = 0;
/* 136 */     this.ymin = 0;
/* 137 */     this.vdpi = 72;
/* 138 */     this.hdpi = 72;
/* 139 */     this.hsize = 0;
/* 140 */     this.vsize = 0;
/*     */   }
/*     */   
/*     */   public IIOMetadataNode getStandardDocumentNode() {
/*     */     String versionString;
/* 145 */     switch (this.version) {
/*     */       case 0:
/* 147 */         versionString = "2.5";
/*     */         break;
/*     */       case 2:
/* 150 */         versionString = "2.8 with palette";
/*     */         break;
/*     */       case 3:
/* 153 */         versionString = "2.8 without palette";
/*     */         break;
/*     */       case 4:
/* 156 */         versionString = "PC Paintbrush for Windows";
/*     */         break;
/*     */       case 5:
/* 159 */         versionString = "3.0";
/*     */         break;
/*     */       
/*     */       default:
/* 163 */         versionString = null;
/*     */         break;
/*     */     } 
/* 166 */     IIOMetadataNode documentNode = null;
/* 167 */     if (versionString != null) {
/* 168 */       documentNode = new IIOMetadataNode("Document");
/* 169 */       IIOMetadataNode node = new IIOMetadataNode("FormatVersion");
/* 170 */       node.setAttribute("value", versionString);
/* 171 */       documentNode.appendChild(node);
/*     */     } 
/*     */     
/* 174 */     return documentNode;
/*     */   }
/*     */   
/*     */   public IIOMetadataNode getStandardDimensionNode() {
/* 178 */     IIOMetadataNode dimensionNode = new IIOMetadataNode("Dimension");
/* 179 */     IIOMetadataNode node = null;
/*     */     
/* 181 */     node = new IIOMetadataNode("HorizontalPixelOffset");
/* 182 */     node.setAttribute("value", String.valueOf(this.xmin));
/* 183 */     dimensionNode.appendChild(node);
/*     */     
/* 185 */     node = new IIOMetadataNode("VerticalPixelOffset");
/* 186 */     node.setAttribute("value", String.valueOf(this.ymin));
/* 187 */     dimensionNode.appendChild(node);
/*     */     
/* 189 */     node = new IIOMetadataNode("HorizontalPixelSize");
/* 190 */     node.setAttribute("value", String.valueOf(254.0D / this.hdpi));
/* 191 */     dimensionNode.appendChild(node);
/*     */     
/* 193 */     node = new IIOMetadataNode("VerticalPixelSize");
/* 194 */     node.setAttribute("value", String.valueOf(254.0D / this.vdpi));
/* 195 */     dimensionNode.appendChild(node);
/*     */     
/* 197 */     if (this.hsize != 0) {
/* 198 */       node = new IIOMetadataNode("HorizontalScreenSize");
/* 199 */       node.setAttribute("value", String.valueOf(this.hsize));
/* 200 */       dimensionNode.appendChild(node);
/*     */     } 
/*     */     
/* 203 */     if (this.vsize != 0) {
/* 204 */       node = new IIOMetadataNode("VerticalScreenSize");
/* 205 */       node.setAttribute("value", String.valueOf(this.vsize));
/* 206 */       dimensionNode.appendChild(node);
/*     */     } 
/*     */     
/* 209 */     return dimensionNode;
/*     */   }
/*     */   
/*     */   private void mergeStandardTree(Node root) throws IIOInvalidTreeException {
/* 213 */     Node node = root;
/* 214 */     if (!node.getNodeName().equals("javax_imageio_1.0")) {
/* 215 */       throw new IIOInvalidTreeException("Root must be javax_imageio_1.0", node);
/*     */     }
/*     */ 
/*     */     
/* 219 */     node = node.getFirstChild();
/* 220 */     while (node != null) {
/* 221 */       String name = node.getNodeName();
/*     */       
/* 223 */       if (name.equals("Dimension")) {
/* 224 */         Node child = node.getFirstChild();
/*     */         
/* 226 */         while (child != null) {
/* 227 */           String childName = child.getNodeName();
/* 228 */           if (childName.equals("HorizontalPixelOffset")) {
/* 229 */             String hpo = getAttribute(child, "value");
/* 230 */             this.xmin = Short.valueOf(hpo).shortValue();
/* 231 */             this.gotxmin = true;
/* 232 */           } else if (childName.equals("VerticalPixelOffset")) {
/* 233 */             String vpo = getAttribute(child, "value");
/* 234 */             this.ymin = Short.valueOf(vpo).shortValue();
/* 235 */             this.gotymin = true;
/* 236 */           } else if (childName.equals("HorizontalPixelSize")) {
/* 237 */             String hps = getAttribute(child, "value");
/* 238 */             this.hdpi = (int)(254.0F / Float.parseFloat(hps) + 0.5F);
/* 239 */           } else if (childName.equals("VerticalPixelSize")) {
/* 240 */             String vps = getAttribute(child, "value");
/* 241 */             this.vdpi = (int)(254.0F / Float.parseFloat(vps) + 0.5F);
/* 242 */           } else if (childName.equals("HorizontalScreenSize")) {
/* 243 */             String hss = getAttribute(child, "value");
/* 244 */             this.hsize = Integer.valueOf(hss).intValue();
/* 245 */           } else if (childName.equals("VerticalScreenSize")) {
/* 246 */             String vss = getAttribute(child, "value");
/* 247 */             this.vsize = Integer.valueOf(vss).intValue();
/*     */           } 
/*     */           
/* 250 */           child = child.getNextSibling();
/*     */         } 
/*     */       } 
/*     */       
/* 254 */       node = node.getNextSibling();
/*     */     } 
/*     */   }
/*     */   
/*     */   private static String getAttribute(Node node, String attrName) {
/* 259 */     NamedNodeMap attrs = node.getAttributes();
/* 260 */     Node attr = attrs.getNamedItem(attrName);
/* 261 */     return (attr != null) ? attr.getNodeValue() : null;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/pcx/PCXMetadata.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */