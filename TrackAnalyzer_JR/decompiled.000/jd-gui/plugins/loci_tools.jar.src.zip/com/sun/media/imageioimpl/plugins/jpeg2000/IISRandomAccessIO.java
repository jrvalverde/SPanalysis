/*     */ package com.sun.media.imageioimpl.plugins.jpeg2000;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteOrder;
/*     */ import javax.imageio.stream.ImageInputStream;
/*     */ import jj2000.j2k.io.RandomAccessIO;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IISRandomAccessIO
/*     */   implements RandomAccessIO
/*     */ {
/*     */   private ImageInputStream iis;
/*     */   
/*     */   public IISRandomAccessIO(ImageInputStream iis) {
/* 105 */     if (iis == null) {
/* 106 */       throw new IllegalArgumentException("iis == null!");
/*     */     }
/* 108 */     this.iis = iis;
/*     */   }
/*     */   
/*     */   public void close() throws IOException {
/* 112 */     this.iis.close();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPos() throws IOException {
/* 120 */     long pos = this.iis.getStreamPosition();
/* 121 */     return (pos > 2147483647L) ? Integer.MAX_VALUE : (int)pos;
/*     */   }
/*     */   
/*     */   public void seek(int off) throws IOException {
/* 125 */     this.iis.seek(off);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int length() throws IOException {
/* 140 */     long len = this.iis.length();
/*     */ 
/*     */     
/* 143 */     if (len != -1L) {
/* 144 */       return (len > 2147483647L) ? Integer.MAX_VALUE : (int)len;
/*     */     }
/*     */ 
/*     */     
/* 148 */     this.iis.mark();
/* 149 */     int bufLen = 1024;
/* 150 */     byte[] buf = new byte[bufLen];
/* 151 */     long pos = this.iis.getStreamPosition();
/* 152 */     while (pos < 2147483647L) {
/* 153 */       int numRead = this.iis.read(buf, 0, bufLen);
/* 154 */       if (numRead == -1)
/* 155 */         break;  pos += numRead;
/*     */     } 
/* 157 */     this.iis.reset();
/*     */ 
/*     */     
/* 160 */     return (pos > 2147483647L) ? Integer.MAX_VALUE : (int)pos;
/*     */   }
/*     */   
/*     */   public int read() throws IOException {
/* 164 */     return this.iis.read();
/*     */   }
/*     */   
/*     */   public void readFully(byte[] b, int off, int n) throws IOException {
/* 168 */     this.iis.readFully(b, off, n);
/*     */   }
/*     */   
/*     */   public int getByteOrdering() {
/* 172 */     return (this.iis.getByteOrder() == ByteOrder.BIG_ENDIAN) ? 0 : 1;
/*     */   }
/*     */ 
/*     */   
/*     */   public byte readByte() throws IOException {
/* 177 */     return this.iis.readByte();
/*     */   }
/*     */   
/*     */   public int readUnsignedByte() throws IOException {
/* 181 */     return this.iis.readUnsignedByte();
/*     */   }
/*     */   
/*     */   public short readShort() throws IOException {
/* 185 */     return this.iis.readShort();
/*     */   }
/*     */   
/*     */   public int readUnsignedShort() throws IOException {
/* 189 */     return this.iis.readUnsignedShort();
/*     */   }
/*     */   
/*     */   public int readInt() throws IOException {
/* 193 */     return this.iis.readInt();
/*     */   }
/*     */   
/*     */   public long readUnsignedInt() throws IOException {
/* 197 */     return this.iis.readUnsignedInt();
/*     */   }
/*     */   
/*     */   public long readLong() throws IOException {
/* 201 */     return this.iis.readLong();
/*     */   }
/*     */   
/*     */   public float readFloat() throws IOException {
/* 205 */     return this.iis.readFloat();
/*     */   }
/*     */   
/*     */   public double readDouble() throws IOException {
/* 209 */     return this.iis.readDouble();
/*     */   }
/*     */   
/*     */   public int skipBytes(int n) throws IOException {
/* 213 */     return this.iis.skipBytes(n);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void flush() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(int b) throws IOException {
/* 227 */     throw new IOException("Writing is not supported!");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeByte(int v) throws IOException {
/* 234 */     throw new IOException("Writing is not supported!");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeShort(int v) throws IOException {
/* 241 */     throw new IOException("Writing is not supported!");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeInt(int v) throws IOException {
/* 248 */     throw new IOException("Writing is not supported!");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeLong(long v) throws IOException {
/* 255 */     throw new IOException("Writing is not supported!");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeFloat(float v) throws IOException {
/* 262 */     throw new IOException("Writing is not supported!");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeDouble(double v) throws IOException {
/* 269 */     throw new IOException("Writing is not supported!");
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/jpeg2000/IISRandomAccessIO.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */