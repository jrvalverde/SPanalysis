/*     */ package com.sun.media.imageioimpl.plugins.raw;
/*     */ 
/*     */ import com.sun.media.imageio.stream.RawImageInputStream;
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.ColorModel;
/*     */ import java.awt.image.Raster;
/*     */ import java.awt.image.RenderedImage;
/*     */ import java.awt.image.SampleModel;
/*     */ import java.awt.image.WritableRaster;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Iterator;
/*     */ import javax.imageio.ImageReadParam;
/*     */ import javax.imageio.ImageReader;
/*     */ import javax.imageio.ImageTypeSpecifier;
/*     */ import javax.imageio.metadata.IIOMetadata;
/*     */ import javax.imageio.spi.ImageReaderSpi;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RawImageReader
/*     */   extends ImageReader
/*     */ {
/* 126 */   private RawImageInputStream iis = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void computeRegionsWrapper(ImageReadParam param, int srcWidth, int srcHeight, BufferedImage image, Rectangle srcRegion, Rectangle destRegion) {
/* 138 */     computeRegions(param, srcWidth, srcHeight, image, srcRegion, destRegion);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RawImageReader(ImageReaderSpi originator) {
/* 146 */     super(originator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInput(Object input, boolean seekForwardOnly, boolean ignoreMetadata) {
/* 156 */     super.setInput(input, seekForwardOnly, ignoreMetadata);
/* 157 */     this.iis = (RawImageInputStream)input;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getNumImages(boolean allowSearch) throws IOException {
/* 162 */     return this.iis.getNumImages();
/*     */   }
/*     */   
/*     */   public int getWidth(int imageIndex) throws IOException {
/* 166 */     checkIndex(imageIndex);
/* 167 */     return (this.iis.getImageDimension(imageIndex)).width;
/*     */   }
/*     */   
/*     */   public int getHeight(int imageIndex) throws IOException {
/* 171 */     checkIndex(imageIndex);
/*     */     
/* 173 */     return (this.iis.getImageDimension(imageIndex)).height;
/*     */   }
/*     */   
/*     */   public int getTileWidth(int imageIndex) throws IOException {
/* 177 */     checkIndex(imageIndex);
/* 178 */     return this.iis.getImageType().getSampleModel().getWidth();
/*     */   }
/*     */   
/*     */   public int getTileHeight(int imageIndex) throws IOException {
/* 182 */     checkIndex(imageIndex);
/* 183 */     return this.iis.getImageType().getSampleModel().getHeight();
/*     */   }
/*     */   
/*     */   private void checkIndex(int imageIndex) throws IOException {
/* 187 */     if (imageIndex < 0 || imageIndex >= getNumImages(true)) {
/* 188 */       throw new IndexOutOfBoundsException(I18N.getString("RawImageReader0"));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator getImageTypes(int imageIndex) throws IOException {
/* 194 */     checkIndex(imageIndex);
/* 195 */     ArrayList<ImageTypeSpecifier> list = new ArrayList(1);
/* 196 */     list.add(this.iis.getImageType());
/* 197 */     return list.iterator();
/*     */   }
/*     */   
/*     */   public ImageReadParam getDefaultReadParam() {
/* 201 */     return new ImageReadParam();
/*     */   }
/*     */ 
/*     */   
/*     */   public IIOMetadata getImageMetadata(int imageIndex) throws IOException {
/* 206 */     return null;
/*     */   }
/*     */   
/*     */   public IIOMetadata getStreamMetadata() throws IOException {
/* 210 */     return null;
/*     */   }
/*     */   
/*     */   public boolean isRandomAccessEasy(int imageIndex) throws IOException {
/* 214 */     checkIndex(imageIndex);
/* 215 */     return true;
/*     */   }
/*     */   
/*     */   public BufferedImage read(int imageIndex, ImageReadParam param) throws IOException {
/*     */     WritableRaster raster;
/* 220 */     if (param == null)
/* 221 */       param = getDefaultReadParam(); 
/* 222 */     checkIndex(imageIndex);
/* 223 */     clearAbortRequest();
/* 224 */     processImageStarted(imageIndex);
/*     */     
/* 226 */     BufferedImage bi = param.getDestination();
/* 227 */     RawRenderedImage image = new RawRenderedImage(this.iis, this, param, imageIndex);
/*     */     
/* 229 */     Point offset = param.getDestinationOffset();
/*     */ 
/*     */     
/* 232 */     if (bi == null) {
/* 233 */       ColorModel colorModel = image.getColorModel();
/* 234 */       SampleModel sampleModel = image.getSampleModel();
/*     */ 
/*     */       
/* 237 */       ImageTypeSpecifier type = param.getDestinationType();
/* 238 */       if (type != null) {
/* 239 */         colorModel = type.getColorModel();
/*     */       }
/* 241 */       raster = Raster.createWritableRaster(sampleModel.createCompatibleSampleModel(image.getMinX() + image.getWidth(), image.getMinY() + image.getHeight()), new Point(0, 0));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 248 */       bi = new BufferedImage(colorModel, raster, (colorModel != null) ? colorModel.isAlphaPremultiplied() : false, new Hashtable<Object, Object>());
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 254 */       raster = bi.getWritableTile(0, 0);
/*     */     } 
/*     */     
/* 257 */     image.setDestImage(bi);
/*     */     
/* 259 */     image.readAsRaster(raster);
/* 260 */     image.clearDestImage();
/*     */     
/* 262 */     if (abortRequested()) {
/* 263 */       processReadAborted();
/*     */     } else {
/* 265 */       processImageComplete();
/* 266 */     }  return bi;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public RenderedImage readAsRenderedImage(int imageIndex, ImageReadParam param) throws IOException {
/* 272 */     if (param == null) {
/* 273 */       param = getDefaultReadParam();
/*     */     }
/* 275 */     checkIndex(imageIndex);
/* 276 */     clearAbortRequest();
/* 277 */     processImageStarted(0);
/*     */     
/* 279 */     RawRenderedImage rawRenderedImage = new RawRenderedImage(this.iis, this, param, imageIndex);
/*     */ 
/*     */     
/* 282 */     if (abortRequested()) {
/* 283 */       processReadAborted();
/*     */     } else {
/* 285 */       processImageComplete();
/* 286 */     }  return (RenderedImage)rawRenderedImage;
/*     */   }
/*     */ 
/*     */   
/*     */   public Raster readRaster(int imageIndex, ImageReadParam param) throws IOException {
/* 291 */     BufferedImage bi = read(imageIndex, param);
/* 292 */     return bi.getData();
/*     */   }
/*     */   
/*     */   public boolean canReadRaster() {
/* 296 */     return true;
/*     */   }
/*     */   
/*     */   public void reset() {
/* 300 */     super.reset();
/* 301 */     this.iis = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void processImageUpdateWrapper(BufferedImage theImage, int minX, int minY, int width, int height, int periodX, int periodY, int[] bands) {
/* 313 */     processImageUpdate(theImage, minX, minY, width, height, periodX, periodY, bands);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void processImageProgressWrapper(float percentageDone) {
/* 325 */     processImageProgress(percentageDone);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getAbortRequest() {
/* 332 */     return abortRequested();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/raw/RawImageReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */