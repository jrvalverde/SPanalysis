/*      */ package com.sun.media.imageioimpl.plugins.gif;
/*      */ 
/*      */ import com.sun.media.imageioimpl.common.LZWCompressor;
/*      */ import com.sun.media.imageioimpl.common.PaletteBuilder;
/*      */ import java.awt.Dimension;
/*      */ import java.awt.Rectangle;
/*      */ import java.awt.image.ColorModel;
/*      */ import java.awt.image.ComponentSampleModel;
/*      */ import java.awt.image.DataBufferByte;
/*      */ import java.awt.image.IndexColorModel;
/*      */ import java.awt.image.Raster;
/*      */ import java.awt.image.RenderedImage;
/*      */ import java.awt.image.SampleModel;
/*      */ import java.io.IOException;
/*      */ import java.nio.ByteOrder;
/*      */ import java.util.Arrays;
/*      */ import java.util.Iterator;
/*      */ import javax.imageio.IIOException;
/*      */ import javax.imageio.IIOImage;
/*      */ import javax.imageio.ImageTypeSpecifier;
/*      */ import javax.imageio.ImageWriteParam;
/*      */ import javax.imageio.ImageWriter;
/*      */ import javax.imageio.metadata.IIOInvalidTreeException;
/*      */ import javax.imageio.metadata.IIOMetadata;
/*      */ import javax.imageio.metadata.IIOMetadataNode;
/*      */ import javax.imageio.stream.ImageOutputStream;
/*      */ import org.w3c.dom.Node;
/*      */ import org.w3c.dom.NodeList;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class GIFImageWriter
/*      */   extends ImageWriter
/*      */ {
/*      */   private static final boolean DEBUG = false;
/*      */   static final String STANDARD_METADATA_NAME = "javax_imageio_1.0";
/*      */   static final String STREAM_METADATA_NAME = "javax_imageio_gif_stream_1.0";
/*      */   static final String IMAGE_METADATA_NAME = "javax_imageio_gif_image_1.0";
/*  130 */   private ImageOutputStream stream = null;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isWritingSequence = false;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean wroteSequenceHeader = false;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  145 */   private GIFWritableStreamMetadata theStreamMetadata = null;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  150 */   private int imageIndex = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int getNumBits(int value) throws IOException {
/*      */     int numBits;
/*  158 */     switch (value) {
/*      */       case 2:
/*  160 */         numBits = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  187 */         return numBits;case 4: numBits = 2; return numBits;case 8: numBits = 3; return numBits;case 16: numBits = 4; return numBits;case 32: numBits = 5; return numBits;case 64: numBits = 6; return numBits;case 128: numBits = 7; return numBits;case 256: numBits = 8; return numBits;
/*      */     } 
/*      */     throw new IOException("Bad palette length: " + value + "!");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void computeRegions(Rectangle sourceBounds, Dimension destSize, ImageWriteParam p) {
/*  198 */     int periodX = 1;
/*  199 */     int periodY = 1;
/*  200 */     if (p != null) {
/*  201 */       int[] sourceBands = p.getSourceBands();
/*  202 */       if (sourceBands != null && (sourceBands.length != 1 || sourceBands[0] != 0))
/*      */       {
/*      */         
/*  205 */         throw new IllegalArgumentException("Cannot sub-band image!");
/*      */       }
/*      */ 
/*      */       
/*  209 */       Rectangle sourceRegion = p.getSourceRegion();
/*  210 */       if (sourceRegion != null) {
/*      */         
/*  212 */         sourceRegion = sourceRegion.intersection(sourceBounds);
/*  213 */         sourceBounds.setBounds(sourceRegion);
/*      */       } 
/*      */ 
/*      */       
/*  217 */       int gridX = p.getSubsamplingXOffset();
/*  218 */       int gridY = p.getSubsamplingYOffset();
/*  219 */       sourceBounds.x += gridX;
/*  220 */       sourceBounds.y += gridY;
/*  221 */       sourceBounds.width -= gridX;
/*  222 */       sourceBounds.height -= gridY;
/*      */ 
/*      */       
/*  225 */       periodX = p.getSourceXSubsampling();
/*  226 */       periodY = p.getSourceYSubsampling();
/*      */     } 
/*      */ 
/*      */     
/*  230 */     destSize.setSize((sourceBounds.width + periodX - 1) / periodX, (sourceBounds.height + periodY - 1) / periodY);
/*      */     
/*  232 */     if (destSize.width <= 0 || destSize.height <= 0) {
/*  233 */       throw new IllegalArgumentException("Empty source region!");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static byte[] createColorTable(ColorModel colorModel, SampleModel sampleModel) {
/*      */     byte[] colorTable;
/*  244 */     if (colorModel instanceof IndexColorModel) {
/*  245 */       IndexColorModel icm = (IndexColorModel)colorModel;
/*  246 */       int mapSize = icm.getMapSize();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  253 */       int ctSize = getGifPaletteSize(mapSize);
/*      */       
/*  255 */       byte[] reds = new byte[ctSize];
/*  256 */       byte[] greens = new byte[ctSize];
/*  257 */       byte[] blues = new byte[ctSize];
/*  258 */       icm.getReds(reds);
/*  259 */       icm.getGreens(greens);
/*  260 */       icm.getBlues(blues);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  266 */       for (int i = mapSize; i < ctSize; i++) {
/*  267 */         reds[i] = reds[0];
/*  268 */         greens[i] = greens[0];
/*  269 */         blues[i] = blues[0];
/*      */       } 
/*      */       
/*  272 */       colorTable = new byte[3 * ctSize];
/*  273 */       int idx = 0;
/*  274 */       for (int j = 0; j < ctSize; j++) {
/*  275 */         colorTable[idx++] = reds[j];
/*  276 */         colorTable[idx++] = greens[j];
/*  277 */         colorTable[idx++] = blues[j];
/*      */       } 
/*  279 */     } else if (sampleModel.getNumBands() == 1) {
/*      */       
/*  281 */       int numBits = sampleModel.getSampleSize()[0];
/*  282 */       if (numBits > 8) {
/*  283 */         numBits = 8;
/*      */       }
/*  285 */       int colorTableLength = 3 * (1 << numBits);
/*  286 */       colorTable = new byte[colorTableLength];
/*  287 */       for (int i = 0; i < colorTableLength; i++) {
/*  288 */         colorTable[i] = (byte)(i / 3);
/*      */       }
/*      */     }
/*      */     else {
/*      */       
/*  293 */       colorTable = null;
/*      */     } 
/*      */     
/*  296 */     return colorTable;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int getGifPaletteSize(int x) {
/*  304 */     if (x <= 2) {
/*  305 */       return 2;
/*      */     }
/*  307 */     x--;
/*  308 */     x |= x >> 1;
/*  309 */     x |= x >> 2;
/*  310 */     x |= x >> 4;
/*  311 */     x |= x >> 8;
/*  312 */     x |= x >> 16;
/*  313 */     return x + 1;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public GIFImageWriter(GIFImageWriterSpi originatingProvider) {
/*  319 */     super(originatingProvider);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean canWriteSequence() {
/*  326 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void convertMetadata(String metadataFormatName, IIOMetadata inData, IIOMetadata outData) {
/*  337 */     String formatName = null;
/*      */     
/*  339 */     String nativeFormatName = inData.getNativeMetadataFormatName();
/*  340 */     if (nativeFormatName != null && nativeFormatName.equals(metadataFormatName)) {
/*      */       
/*  342 */       formatName = metadataFormatName;
/*      */     } else {
/*  344 */       String[] extraFormatNames = inData.getExtraMetadataFormatNames();
/*      */       
/*  346 */       if (extraFormatNames != null) {
/*  347 */         for (int i = 0; i < extraFormatNames.length; i++) {
/*  348 */           if (extraFormatNames[i].equals(metadataFormatName)) {
/*  349 */             formatName = metadataFormatName;
/*      */             
/*      */             break;
/*      */           } 
/*      */         } 
/*      */       }
/*      */     } 
/*  356 */     if (formatName == null && inData.isStandardMetadataFormatSupported())
/*      */     {
/*  358 */       formatName = "javax_imageio_1.0";
/*      */     }
/*      */     
/*  361 */     if (formatName != null) {
/*      */       try {
/*  363 */         Node root = inData.getAsTree(formatName);
/*  364 */         outData.mergeTree(formatName, root);
/*  365 */       } catch (IIOInvalidTreeException e) {}
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IIOMetadata convertStreamMetadata(IIOMetadata inData, ImageWriteParam param) {
/*  377 */     if (inData == null) {
/*  378 */       throw new IllegalArgumentException("inData == null!");
/*      */     }
/*      */     
/*  381 */     IIOMetadata sm = getDefaultStreamMetadata(param);
/*      */     
/*  383 */     convertMetadata("javax_imageio_gif_stream_1.0", inData, sm);
/*      */     
/*  385 */     return sm;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IIOMetadata convertImageMetadata(IIOMetadata inData, ImageTypeSpecifier imageType, ImageWriteParam param) {
/*  395 */     if (inData == null) {
/*  396 */       throw new IllegalArgumentException("inData == null!");
/*      */     }
/*  398 */     if (imageType == null) {
/*  399 */       throw new IllegalArgumentException("imageType == null!");
/*      */     }
/*      */     
/*  402 */     GIFWritableImageMetadata im = (GIFWritableImageMetadata)getDefaultImageMetadata(imageType, param);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  408 */     boolean isProgressive = im.interlaceFlag;
/*      */     
/*  410 */     convertMetadata("javax_imageio_gif_image_1.0", inData, im);
/*      */ 
/*      */ 
/*      */     
/*  414 */     if (param != null && param.canWriteProgressive() && param.getProgressiveMode() != 3)
/*      */     {
/*  416 */       im.interlaceFlag = isProgressive;
/*      */     }
/*      */     
/*  419 */     return im;
/*      */   }
/*      */   
/*      */   public void endWriteSequence() throws IOException {
/*  423 */     if (this.stream == null) {
/*  424 */       throw new IllegalStateException("output == null!");
/*      */     }
/*  426 */     if (!this.isWritingSequence) {
/*  427 */       throw new IllegalStateException("prepareWriteSequence() was not invoked!");
/*      */     }
/*  429 */     writeTrailer();
/*  430 */     resetLocal();
/*      */   }
/*      */ 
/*      */   
/*      */   public IIOMetadata getDefaultImageMetadata(ImageTypeSpecifier imageType, ImageWriteParam param) {
/*  435 */     GIFWritableImageMetadata imageMetadata = new GIFWritableImageMetadata();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  440 */     SampleModel sampleModel = imageType.getSampleModel();
/*      */     
/*  442 */     Rectangle sourceBounds = new Rectangle(sampleModel.getWidth(), sampleModel.getHeight());
/*      */     
/*  444 */     Dimension destSize = new Dimension();
/*  445 */     computeRegions(sourceBounds, destSize, param);
/*      */     
/*  447 */     imageMetadata.imageWidth = destSize.width;
/*  448 */     imageMetadata.imageHeight = destSize.height;
/*      */ 
/*      */ 
/*      */     
/*  452 */     if (param != null && param.canWriteProgressive() && param.getProgressiveMode() == 0) {
/*      */       
/*  454 */       imageMetadata.interlaceFlag = false;
/*      */     } else {
/*  456 */       imageMetadata.interlaceFlag = true;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  461 */     ColorModel colorModel = imageType.getColorModel();
/*      */     
/*  463 */     imageMetadata.localColorTable = createColorTable(colorModel, sampleModel);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  468 */     if (colorModel instanceof IndexColorModel) {
/*  469 */       int transparentIndex = ((IndexColorModel)colorModel).getTransparentPixel();
/*      */       
/*  471 */       if (transparentIndex != -1) {
/*  472 */         imageMetadata.transparentColorFlag = true;
/*  473 */         imageMetadata.transparentColorIndex = transparentIndex;
/*      */       } 
/*      */     } 
/*      */     
/*  477 */     return imageMetadata;
/*      */   }
/*      */   
/*      */   public IIOMetadata getDefaultStreamMetadata(ImageWriteParam param) {
/*  481 */     GIFWritableStreamMetadata streamMetadata = new GIFWritableStreamMetadata();
/*      */     
/*  483 */     streamMetadata.version = "89a";
/*  484 */     return streamMetadata;
/*      */   }
/*      */   
/*      */   public ImageWriteParam getDefaultWriteParam() {
/*  488 */     return new GIFImageWriteParam(getLocale());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void prepareWriteSequence(IIOMetadata streamMetadata) throws IOException {
/*  494 */     if (this.stream == null) {
/*  495 */       throw new IllegalStateException("Output is not set.");
/*      */     }
/*      */     
/*  498 */     resetLocal();
/*      */ 
/*      */     
/*  501 */     if (streamMetadata == null) {
/*  502 */       this.theStreamMetadata = (GIFWritableStreamMetadata)getDefaultStreamMetadata((ImageWriteParam)null);
/*      */     } else {
/*      */       
/*  505 */       this.theStreamMetadata = new GIFWritableStreamMetadata();
/*  506 */       convertMetadata("javax_imageio_gif_stream_1.0", streamMetadata, this.theStreamMetadata);
/*      */     } 
/*      */ 
/*      */     
/*  510 */     this.isWritingSequence = true;
/*      */   }
/*      */   
/*      */   public void reset() {
/*  514 */     super.reset();
/*  515 */     resetLocal();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void resetLocal() {
/*  522 */     this.isWritingSequence = false;
/*  523 */     this.wroteSequenceHeader = false;
/*  524 */     this.theStreamMetadata = null;
/*  525 */     this.imageIndex = 0;
/*      */   }
/*      */   
/*      */   public void setOutput(Object output) {
/*  529 */     super.setOutput(output);
/*  530 */     if (output != null) {
/*  531 */       if (!(output instanceof ImageOutputStream)) {
/*  532 */         throw new IllegalArgumentException("output is not an ImageOutputStream");
/*      */       }
/*      */       
/*  535 */       this.stream = (ImageOutputStream)output;
/*  536 */       this.stream.setByteOrder(ByteOrder.LITTLE_ENDIAN);
/*      */     } else {
/*  538 */       this.stream = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void write(IIOMetadata sm, IIOImage iioimage, ImageWriteParam p) throws IOException {
/*      */     GIFWritableStreamMetadata streamMetadata;
/*  545 */     if (this.stream == null) {
/*  546 */       throw new IllegalStateException("output == null!");
/*      */     }
/*  548 */     if (iioimage == null) {
/*  549 */       throw new IllegalArgumentException("iioimage == null!");
/*      */     }
/*  551 */     if (iioimage.hasRaster()) {
/*  552 */       throw new UnsupportedOperationException("canWriteRasters() == false!");
/*      */     }
/*      */     
/*  555 */     resetLocal();
/*      */ 
/*      */     
/*  558 */     if (sm == null) {
/*  559 */       streamMetadata = (GIFWritableStreamMetadata)getDefaultStreamMetadata(p);
/*      */     } else {
/*      */       
/*  562 */       streamMetadata = (GIFWritableStreamMetadata)convertStreamMetadata(sm, p);
/*      */     } 
/*      */ 
/*      */     
/*  566 */     write(true, true, streamMetadata, iioimage, p);
/*      */   }
/*      */ 
/*      */   
/*      */   public void writeToSequence(IIOImage image, ImageWriteParam param) throws IOException {
/*  571 */     if (this.stream == null) {
/*  572 */       throw new IllegalStateException("output == null!");
/*      */     }
/*  574 */     if (image == null) {
/*  575 */       throw new IllegalArgumentException("image == null!");
/*      */     }
/*  577 */     if (image.hasRaster()) {
/*  578 */       throw new UnsupportedOperationException("canWriteRasters() == false!");
/*      */     }
/*  580 */     if (!this.isWritingSequence) {
/*  581 */       throw new IllegalStateException("prepareWriteSequence() was not invoked!");
/*      */     }
/*      */     
/*  584 */     write(!this.wroteSequenceHeader, false, this.theStreamMetadata, image, param);
/*      */ 
/*      */     
/*  587 */     if (!this.wroteSequenceHeader) {
/*  588 */       this.wroteSequenceHeader = true;
/*      */     }
/*      */     
/*  591 */     this.imageIndex++;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean needToCreateIndex(RenderedImage image) {
/*  597 */     SampleModel sampleModel = image.getSampleModel();
/*  598 */     ColorModel colorModel = image.getColorModel();
/*      */     
/*  600 */     return (sampleModel.getNumBands() != 1 || sampleModel.getSampleSize()[0] > 8 || colorModel.getComponentSize()[0] > 8);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void write(boolean writeHeader, boolean writeTrailer, IIOMetadata sm, IIOImage iioimage, ImageWriteParam p) throws IOException {
/*  632 */     clearAbortRequest();
/*      */     
/*  634 */     RenderedImage image = iioimage.getRenderedImage();
/*      */ 
/*      */     
/*  637 */     if (needToCreateIndex(image)) {
/*  638 */       image = PaletteBuilder.createIndexedImage(image);
/*  639 */       iioimage.setRenderedImage(image);
/*      */     } 
/*      */     
/*  642 */     ColorModel colorModel = image.getColorModel();
/*  643 */     SampleModel sampleModel = image.getSampleModel();
/*      */ 
/*      */     
/*  646 */     Rectangle sourceBounds = new Rectangle(image.getMinX(), image.getMinY(), image.getWidth(), image.getHeight());
/*      */ 
/*      */ 
/*      */     
/*  650 */     Dimension destSize = new Dimension();
/*  651 */     computeRegions(sourceBounds, destSize, p);
/*      */ 
/*      */     
/*  654 */     GIFWritableImageMetadata imageMetadata = null;
/*  655 */     if (iioimage.getMetadata() != null) {
/*  656 */       imageMetadata = new GIFWritableImageMetadata();
/*  657 */       convertMetadata("javax_imageio_gif_image_1.0", iioimage.getMetadata(), imageMetadata);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  666 */       if (imageMetadata.localColorTable == null) {
/*  667 */         imageMetadata.localColorTable = createColorTable(colorModel, sampleModel);
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  672 */         if (colorModel instanceof IndexColorModel) {
/*  673 */           IndexColorModel icm = (IndexColorModel)colorModel;
/*      */           
/*  675 */           int index = icm.getTransparentPixel();
/*  676 */           imageMetadata.transparentColorFlag = (index != -1);
/*  677 */           if (imageMetadata.transparentColorFlag) {
/*  678 */             imageMetadata.transparentColorIndex = index;
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  691 */     byte[] globalColorTable = null;
/*      */ 
/*      */ 
/*      */     
/*  695 */     if (writeHeader) {
/*  696 */       int bitsPerPixel; if (sm == null) {
/*  697 */         throw new IllegalArgumentException("Cannot write null header!");
/*      */       }
/*      */       
/*  700 */       GIFWritableStreamMetadata streamMetadata = (GIFWritableStreamMetadata)sm;
/*      */ 
/*      */ 
/*      */       
/*  704 */       if (streamMetadata.version == null) {
/*  705 */         streamMetadata.version = "89a";
/*      */       }
/*      */ 
/*      */       
/*  709 */       if (streamMetadata.logicalScreenWidth == -1)
/*      */       {
/*      */         
/*  712 */         streamMetadata.logicalScreenWidth = destSize.width;
/*      */       }
/*      */       
/*  715 */       if (streamMetadata.logicalScreenHeight == -1)
/*      */       {
/*      */         
/*  718 */         streamMetadata.logicalScreenHeight = destSize.height;
/*      */       }
/*      */       
/*  721 */       if (streamMetadata.colorResolution == -1)
/*      */       {
/*      */         
/*  724 */         streamMetadata.colorResolution = (colorModel != null) ? colorModel.getComponentSize()[0] : sampleModel.getSampleSize()[0];
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  731 */       if (streamMetadata.globalColorTable == null) {
/*  732 */         if (this.isWritingSequence && imageMetadata != null && imageMetadata.localColorTable != null) {
/*      */ 
/*      */ 
/*      */           
/*  736 */           streamMetadata.globalColorTable = imageMetadata.localColorTable;
/*      */         }
/*  738 */         else if (imageMetadata == null || imageMetadata.localColorTable == null) {
/*      */ 
/*      */           
/*  741 */           streamMetadata.globalColorTable = createColorTable(colorModel, sampleModel);
/*      */         } 
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  755 */       globalColorTable = streamMetadata.globalColorTable;
/*      */ 
/*      */ 
/*      */       
/*  759 */       if (globalColorTable != null) {
/*  760 */         bitsPerPixel = getNumBits(globalColorTable.length / 3);
/*  761 */       } else if (imageMetadata != null && imageMetadata.localColorTable != null) {
/*      */         
/*  763 */         bitsPerPixel = getNumBits(imageMetadata.localColorTable.length / 3);
/*      */       } else {
/*      */         
/*  766 */         bitsPerPixel = sampleModel.getSampleSize(0);
/*      */       } 
/*  768 */       writeHeader(streamMetadata, bitsPerPixel);
/*  769 */     } else if (this.isWritingSequence) {
/*  770 */       globalColorTable = this.theStreamMetadata.globalColorTable;
/*      */     } else {
/*  772 */       throw new IllegalArgumentException("Must write header for single image!");
/*      */     } 
/*      */ 
/*      */     
/*  776 */     writeImage(iioimage.getRenderedImage(), imageMetadata, p, globalColorTable, sourceBounds, destSize);
/*      */ 
/*      */ 
/*      */     
/*  780 */     if (writeTrailer) {
/*  781 */       writeTrailer();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void writeImage(RenderedImage image, GIFWritableImageMetadata imageMetadata, ImageWriteParam param, byte[] globalColorTable, Rectangle sourceBounds, Dimension destSize) throws IOException {
/*      */     boolean writeGraphicsControlExtension;
/*  799 */     ColorModel colorModel = image.getColorModel();
/*  800 */     SampleModel sampleModel = image.getSampleModel();
/*      */ 
/*      */     
/*  803 */     if (imageMetadata == null) {
/*      */       
/*  805 */       imageMetadata = (GIFWritableImageMetadata)getDefaultImageMetadata(new ImageTypeSpecifier(image), param);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  810 */       writeGraphicsControlExtension = imageMetadata.transparentColorFlag;
/*      */     } else {
/*      */       
/*  813 */       NodeList list = null;
/*      */       try {
/*  815 */         IIOMetadataNode root = (IIOMetadataNode)imageMetadata.getAsTree("javax_imageio_gif_image_1.0");
/*      */         
/*  817 */         list = root.getElementsByTagName("GraphicControlExtension");
/*  818 */       } catch (IllegalArgumentException iae) {}
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  823 */       writeGraphicsControlExtension = (list != null && list.getLength() > 0);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  828 */       if (param != null && param.canWriteProgressive()) {
/*  829 */         if (param.getProgressiveMode() == 0) {
/*      */           
/*  831 */           imageMetadata.interlaceFlag = false;
/*  832 */         } else if (param.getProgressiveMode() == 1) {
/*      */           
/*  834 */           imageMetadata.interlaceFlag = true;
/*      */         } 
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  840 */     if (Arrays.equals(globalColorTable, imageMetadata.localColorTable)) {
/*  841 */       imageMetadata.localColorTable = null;
/*      */     }
/*      */ 
/*      */     
/*  845 */     imageMetadata.imageWidth = destSize.width;
/*  846 */     imageMetadata.imageHeight = destSize.height;
/*      */ 
/*      */     
/*  849 */     if (writeGraphicsControlExtension) {
/*  850 */       writeGraphicControlExtension(imageMetadata);
/*      */     }
/*      */ 
/*      */     
/*  854 */     writePlainTextExtension(imageMetadata);
/*  855 */     writeApplicationExtension(imageMetadata);
/*  856 */     writeCommentExtension(imageMetadata);
/*      */ 
/*      */     
/*  859 */     int bitsPerPixel = getNumBits((imageMetadata.localColorTable == null) ? ((globalColorTable == null) ? sampleModel.getSampleSize(0) : (globalColorTable.length / 3)) : (imageMetadata.localColorTable.length / 3));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  865 */     writeImageDescriptor(imageMetadata, bitsPerPixel);
/*      */ 
/*      */     
/*  868 */     writeRasterData(image, sourceBounds, destSize, param, imageMetadata.interlaceFlag);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void writeRows(RenderedImage image, LZWCompressor compressor, int sx, int sdx, int sy, int sdy, int sw, int dy, int ddy, int dw, int dh, int numRowsWritten, int progressReportRowPeriod) throws IOException {
/*  879 */     int[] sbuf = new int[sw];
/*  880 */     byte[] dbuf = new byte[dw];
/*      */     
/*  882 */     Raster raster = (image.getNumXTiles() == 1 && image.getNumYTiles() == 1) ? image.getTile(0, 0) : image.getData();
/*      */     
/*      */     int y;
/*  885 */     for (y = dy; y < dh; y += ddy) {
/*  886 */       if (numRowsWritten % progressReportRowPeriod == 0) {
/*  887 */         if (abortRequested()) {
/*  888 */           processWriteAborted();
/*      */           return;
/*      */         } 
/*  891 */         processImageProgress(numRowsWritten * 100.0F / dh);
/*      */       } 
/*      */       
/*  894 */       raster.getSamples(sx, sy, sw, 1, 0, sbuf); int j;
/*  895 */       for (int i = 0; i < dw; i++, j += sdx) {
/*  896 */         dbuf[i] = (byte)sbuf[j];
/*      */       }
/*  898 */       compressor.compress(dbuf, 0, dw);
/*  899 */       numRowsWritten++;
/*  900 */       sy += sdy;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void writeRowsOpt(byte[] data, int offset, int lineStride, LZWCompressor compressor, int dy, int ddy, int dw, int dh, int numRowsWritten, int progressReportRowPeriod) throws IOException {
/*  911 */     offset += dy * lineStride;
/*  912 */     lineStride *= ddy; int y;
/*  913 */     for (y = dy; y < dh; y += ddy) {
/*  914 */       if (numRowsWritten % progressReportRowPeriod == 0) {
/*  915 */         if (abortRequested()) {
/*  916 */           processWriteAborted();
/*      */           return;
/*      */         } 
/*  919 */         processImageProgress(numRowsWritten * 100.0F / dh);
/*      */       } 
/*      */       
/*  922 */       compressor.compress(data, offset, dw);
/*  923 */       numRowsWritten++;
/*  924 */       offset += lineStride;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void writeRasterData(RenderedImage image, Rectangle sourceBounds, Dimension destSize, ImageWriteParam param, boolean interlaceFlag) throws IOException {
/*  934 */     int periodX, periodY, sourceXOffset = sourceBounds.x;
/*  935 */     int sourceYOffset = sourceBounds.y;
/*  936 */     int sourceWidth = sourceBounds.width;
/*  937 */     int sourceHeight = sourceBounds.height;
/*      */     
/*  939 */     int destWidth = destSize.width;
/*  940 */     int destHeight = destSize.height;
/*      */ 
/*      */ 
/*      */     
/*  944 */     if (param == null) {
/*  945 */       periodX = 1;
/*  946 */       periodY = 1;
/*      */     } else {
/*  948 */       periodX = param.getSourceXSubsampling();
/*  949 */       periodY = param.getSourceYSubsampling();
/*      */     } 
/*      */     
/*  952 */     SampleModel sampleModel = image.getSampleModel();
/*  953 */     int bitsPerPixel = sampleModel.getSampleSize()[0];
/*      */     
/*  955 */     int initCodeSize = bitsPerPixel;
/*  956 */     if (initCodeSize == 1) {
/*  957 */       initCodeSize++;
/*      */     }
/*  959 */     this.stream.write(initCodeSize);
/*      */     
/*  961 */     LZWCompressor compressor = new LZWCompressor(this.stream, initCodeSize, false);
/*      */ 
/*      */     
/*  964 */     boolean isOptimizedCase = (periodX == 1 && periodY == 1 && sampleModel instanceof ComponentSampleModel && image.getNumXTiles() == 1 && image.getNumYTiles() == 1 && image.getTile(0, 0).getDataBuffer() instanceof DataBufferByte);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  970 */     int numRowsWritten = 0;
/*      */     
/*  972 */     int progressReportRowPeriod = Math.max(destHeight / 20, 1);
/*      */     
/*  974 */     processImageStarted(this.imageIndex);
/*      */     
/*  976 */     if (interlaceFlag) {
/*      */ 
/*      */       
/*  979 */       if (isOptimizedCase) {
/*  980 */         Raster tile = image.getTile(0, 0);
/*  981 */         byte[] data = ((DataBufferByte)tile.getDataBuffer()).getData();
/*  982 */         ComponentSampleModel csm = (ComponentSampleModel)tile.getSampleModel();
/*      */         
/*  984 */         int offset = csm.getOffset(sourceXOffset - tile.getSampleModelTranslateX(), sourceYOffset - tile.getSampleModelTranslateY(), 0);
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  989 */         int lineStride = csm.getScanlineStride();
/*      */         
/*  991 */         writeRowsOpt(data, offset, lineStride, compressor, 0, 8, destWidth, destHeight, numRowsWritten, progressReportRowPeriod);
/*      */ 
/*      */ 
/*      */         
/*  995 */         if (abortRequested()) {
/*      */           return;
/*      */         }
/*      */         
/*  999 */         numRowsWritten += destHeight / 8;
/*      */         
/* 1001 */         writeRowsOpt(data, offset, lineStride, compressor, 4, 8, destWidth, destHeight, numRowsWritten, progressReportRowPeriod);
/*      */ 
/*      */ 
/*      */         
/* 1005 */         if (abortRequested()) {
/*      */           return;
/*      */         }
/*      */         
/* 1009 */         numRowsWritten += (destHeight - 4) / 8;
/*      */         
/* 1011 */         writeRowsOpt(data, offset, lineStride, compressor, 2, 4, destWidth, destHeight, numRowsWritten, progressReportRowPeriod);
/*      */ 
/*      */ 
/*      */         
/* 1015 */         if (abortRequested()) {
/*      */           return;
/*      */         }
/*      */         
/* 1019 */         numRowsWritten += (destHeight - 2) / 4;
/*      */         
/* 1021 */         writeRowsOpt(data, offset, lineStride, compressor, 1, 2, destWidth, destHeight, numRowsWritten, progressReportRowPeriod);
/*      */       }
/*      */       else {
/*      */         
/* 1025 */         writeRows(image, compressor, sourceXOffset, periodX, sourceYOffset, 8 * periodY, sourceWidth, 0, 8, destWidth, destHeight, numRowsWritten, progressReportRowPeriod);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1032 */         if (abortRequested()) {
/*      */           return;
/*      */         }
/*      */         
/* 1036 */         numRowsWritten += destHeight / 8;
/*      */         
/* 1038 */         writeRows(image, compressor, sourceXOffset, periodX, sourceYOffset + 4 * periodY, 8 * periodY, sourceWidth, 4, 8, destWidth, destHeight, numRowsWritten, progressReportRowPeriod);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1044 */         if (abortRequested()) {
/*      */           return;
/*      */         }
/*      */         
/* 1048 */         numRowsWritten += (destHeight - 4) / 8;
/*      */         
/* 1050 */         writeRows(image, compressor, sourceXOffset, periodX, sourceYOffset + 2 * periodY, 4 * periodY, sourceWidth, 2, 4, destWidth, destHeight, numRowsWritten, progressReportRowPeriod);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1056 */         if (abortRequested()) {
/*      */           return;
/*      */         }
/*      */         
/* 1060 */         numRowsWritten += (destHeight - 2) / 4;
/*      */         
/* 1062 */         writeRows(image, compressor, sourceXOffset, periodX, sourceYOffset + periodY, 2 * periodY, sourceWidth, 1, 2, destWidth, destHeight, numRowsWritten, progressReportRowPeriod);
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*      */ 
/*      */ 
/*      */     
/*      */     }
/* 1071 */     else if (isOptimizedCase) {
/* 1072 */       Raster tile = image.getTile(0, 0);
/* 1073 */       byte[] data = ((DataBufferByte)tile.getDataBuffer()).getData();
/* 1074 */       ComponentSampleModel csm = (ComponentSampleModel)tile.getSampleModel();
/*      */       
/* 1076 */       int offset = csm.getOffset(sourceXOffset - tile.getSampleModelTranslateX(), sourceYOffset - tile.getSampleModelTranslateY(), 0);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1081 */       int lineStride = csm.getScanlineStride();
/*      */       
/* 1083 */       writeRowsOpt(data, offset, lineStride, compressor, 0, 1, destWidth, destHeight, numRowsWritten, progressReportRowPeriod);
/*      */     }
/*      */     else {
/*      */       
/* 1087 */       writeRows(image, compressor, sourceXOffset, periodX, sourceYOffset, periodY, sourceWidth, 0, 1, destWidth, destHeight, numRowsWritten, progressReportRowPeriod);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1096 */     if (abortRequested()) {
/*      */       return;
/*      */     }
/*      */     
/* 1100 */     processImageProgress(100.0F);
/*      */     
/* 1102 */     compressor.flush();
/*      */     
/* 1104 */     this.stream.write(0);
/*      */     
/* 1106 */     processImageComplete();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void writeHeader(String version, int logicalScreenWidth, int logicalScreenHeight, int colorResolution, int pixelAspectRatio, int backgroundColorIndex, boolean sortFlag, int bitsPerPixel, byte[] globalColorTable) throws IOException {
/*      */     try {
/* 1120 */       this.stream.writeBytes("GIF" + version);
/*      */ 
/*      */ 
/*      */       
/* 1124 */       this.stream.writeShort((short)logicalScreenWidth);
/*      */ 
/*      */       
/* 1127 */       this.stream.writeShort((short)logicalScreenHeight);
/*      */ 
/*      */ 
/*      */       
/* 1131 */       int packedFields = (globalColorTable != null) ? 128 : 0;
/* 1132 */       packedFields |= (colorResolution - 1 & 0x7) << 4;
/* 1133 */       if (sortFlag) {
/* 1134 */         packedFields |= 0x8;
/*      */       }
/* 1136 */       packedFields |= bitsPerPixel - 1;
/* 1137 */       this.stream.write(packedFields);
/*      */ 
/*      */       
/* 1140 */       this.stream.write(backgroundColorIndex);
/*      */ 
/*      */       
/* 1143 */       this.stream.write(pixelAspectRatio);
/*      */ 
/*      */       
/* 1146 */       if (globalColorTable != null) {
/* 1147 */         this.stream.write(globalColorTable);
/*      */       }
/* 1149 */     } catch (IOException e) {
/* 1150 */       throw new IIOException("I/O error writing header!", e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void writeHeader(IIOMetadata streamMetadata, int bitsPerPixel) throws IOException {
/*      */     GIFWritableStreamMetadata sm;
/* 1158 */     if (streamMetadata instanceof GIFWritableStreamMetadata) {
/* 1159 */       sm = (GIFWritableStreamMetadata)streamMetadata;
/*      */     } else {
/* 1161 */       sm = new GIFWritableStreamMetadata();
/* 1162 */       Node root = streamMetadata.getAsTree("javax_imageio_gif_stream_1.0");
/*      */       
/* 1164 */       sm.setFromTree("javax_imageio_gif_stream_1.0", root);
/*      */     } 
/*      */     
/* 1167 */     writeHeader(sm.version, sm.logicalScreenWidth, sm.logicalScreenHeight, sm.colorResolution, sm.pixelAspectRatio, sm.backgroundColorIndex, sm.sortFlag, bitsPerPixel, sm.globalColorTable);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void writeGraphicControlExtension(int disposalMethod, boolean userInputFlag, boolean transparentColorFlag, int delayTime, int transparentColorIndex) throws IOException {
/*      */     try {
/* 1185 */       this.stream.write(33);
/* 1186 */       this.stream.write(249);
/*      */       
/* 1188 */       this.stream.write(4);
/*      */       
/* 1190 */       int packedFields = (disposalMethod & 0x3) << 2;
/* 1191 */       if (userInputFlag) {
/* 1192 */         packedFields |= 0x2;
/*      */       }
/* 1194 */       if (transparentColorFlag) {
/* 1195 */         packedFields |= 0x1;
/*      */       }
/* 1197 */       this.stream.write(packedFields);
/*      */       
/* 1199 */       this.stream.writeShort((short)delayTime);
/*      */       
/* 1201 */       this.stream.write(transparentColorIndex);
/* 1202 */       this.stream.write(0);
/* 1203 */     } catch (IOException e) {
/* 1204 */       throw new IIOException("I/O error writing Graphic Control Extension!", e);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void writeGraphicControlExtension(GIFWritableImageMetadata im) throws IOException {
/* 1210 */     writeGraphicControlExtension(im.disposalMethod, im.userInputFlag, im.transparentColorFlag, im.delayTime, im.transparentColorIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void writeBlocks(byte[] data) throws IOException {
/* 1218 */     if (data != null && data.length > 0) {
/* 1219 */       int offset = 0;
/* 1220 */       while (offset < data.length) {
/* 1221 */         int len = Math.min(data.length - offset, 255);
/* 1222 */         this.stream.write(len);
/* 1223 */         this.stream.write(data, offset, len);
/* 1224 */         offset += len;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void writePlainTextExtension(GIFWritableImageMetadata im) throws IOException {
/* 1231 */     if (im.hasPlainTextExtension) {
/*      */       try {
/* 1233 */         this.stream.write(33);
/* 1234 */         this.stream.write(1);
/*      */         
/* 1236 */         this.stream.write(12);
/*      */         
/* 1238 */         this.stream.writeShort(im.textGridLeft);
/* 1239 */         this.stream.writeShort(im.textGridTop);
/* 1240 */         this.stream.writeShort(im.textGridWidth);
/* 1241 */         this.stream.writeShort(im.textGridHeight);
/* 1242 */         this.stream.write(im.characterCellWidth);
/* 1243 */         this.stream.write(im.characterCellHeight);
/* 1244 */         this.stream.write(im.textForegroundColor);
/* 1245 */         this.stream.write(im.textBackgroundColor);
/*      */         
/* 1247 */         writeBlocks(im.text);
/*      */         
/* 1249 */         this.stream.write(0);
/* 1250 */       } catch (IOException e) {
/* 1251 */         throw new IIOException("I/O error writing Plain Text Extension!", e);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private void writeApplicationExtension(GIFWritableImageMetadata im) throws IOException {
/* 1258 */     if (im.applicationIDs != null) {
/* 1259 */       Iterator<byte[]> iterIDs = im.applicationIDs.iterator();
/* 1260 */       Iterator<byte[]> iterCodes = im.authenticationCodes.iterator();
/* 1261 */       Iterator<byte[]> iterData = im.applicationData.iterator();
/*      */       
/* 1263 */       while (iterIDs.hasNext()) {
/*      */         try {
/* 1265 */           this.stream.write(33);
/* 1266 */           this.stream.write(255);
/*      */           
/* 1268 */           this.stream.write(11);
/* 1269 */           this.stream.write(iterIDs.next(), 0, 8);
/* 1270 */           this.stream.write(iterCodes.next(), 0, 3);
/*      */           
/* 1272 */           writeBlocks(iterData.next());
/*      */           
/* 1274 */           this.stream.write(0);
/* 1275 */         } catch (IOException e) {
/* 1276 */           throw new IIOException("I/O error writing Application Extension!", e);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void writeCommentExtension(GIFWritableImageMetadata im) throws IOException {
/* 1284 */     if (im.comments != null) {
/*      */       try {
/* 1286 */         Iterator<byte[]> iter = im.comments.iterator();
/* 1287 */         while (iter.hasNext()) {
/* 1288 */           this.stream.write(33);
/* 1289 */           this.stream.write(254);
/* 1290 */           writeBlocks(iter.next());
/* 1291 */           this.stream.write(0);
/*      */         } 
/* 1293 */       } catch (IOException e) {
/* 1294 */         throw new IIOException("I/O error writing Comment Extension!", e);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void writeImageDescriptor(int imageLeftPosition, int imageTopPosition, int imageWidth, int imageHeight, boolean interlaceFlag, boolean sortFlag, int bitsPerPixel, byte[] localColorTable) throws IOException {
/*      */     try {
/* 1310 */       this.stream.write(44);
/*      */       
/* 1312 */       this.stream.writeShort((short)imageLeftPosition);
/* 1313 */       this.stream.writeShort((short)imageTopPosition);
/* 1314 */       this.stream.writeShort((short)imageWidth);
/* 1315 */       this.stream.writeShort((short)imageHeight);
/*      */       
/* 1317 */       int packedFields = (localColorTable != null) ? 128 : 0;
/* 1318 */       if (interlaceFlag) {
/* 1319 */         packedFields |= 0x40;
/*      */       }
/* 1321 */       if (sortFlag) {
/* 1322 */         packedFields |= 0x8;
/*      */       }
/* 1324 */       packedFields |= bitsPerPixel - 1;
/* 1325 */       this.stream.write(packedFields);
/*      */       
/* 1327 */       if (localColorTable != null) {
/* 1328 */         this.stream.write(localColorTable);
/*      */       }
/* 1330 */     } catch (IOException e) {
/* 1331 */       throw new IIOException("I/O error writing Image Descriptor!", e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void writeImageDescriptor(GIFWritableImageMetadata imageMetadata, int bitsPerPixel) throws IOException {
/* 1339 */     writeImageDescriptor(imageMetadata.imageLeftPosition, imageMetadata.imageTopPosition, imageMetadata.imageWidth, imageMetadata.imageHeight, imageMetadata.interlaceFlag, imageMetadata.sortFlag, bitsPerPixel, imageMetadata.localColorTable);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void writeTrailer() throws IOException {
/* 1350 */     this.stream.write(59);
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/gif/GIFImageWriter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */