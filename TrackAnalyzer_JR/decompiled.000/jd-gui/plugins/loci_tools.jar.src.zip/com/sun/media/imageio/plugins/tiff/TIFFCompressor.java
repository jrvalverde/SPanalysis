/*     */ package com.sun.media.imageio.plugins.tiff;
/*     */ 
/*     */ import com.sun.media.imageioimpl.plugins.tiff.TIFFImageWriter;
/*     */ import java.io.IOException;
/*     */ import javax.imageio.ImageWriter;
/*     */ import javax.imageio.metadata.IIOMetadata;
/*     */ import javax.imageio.stream.ImageOutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TIFFCompressor
/*     */ {
/*     */   protected ImageWriter writer;
/*     */   protected IIOMetadata metadata;
/*     */   protected String compressionType;
/*     */   protected int compressionTagValue;
/*     */   protected boolean isCompressionLossless;
/*     */   protected ImageOutputStream stream;
/*     */   
/*     */   public TIFFCompressor(String compressionType, int compressionTagValue, boolean isCompressionLossless) {
/* 158 */     if (compressionType == null)
/* 159 */       throw new IllegalArgumentException("compressionType == null"); 
/* 160 */     if (compressionTagValue < 1) {
/* 161 */       throw new IllegalArgumentException("compressionTagValue < 1");
/*     */     }
/*     */ 
/*     */     
/* 165 */     this.compressionType = compressionType;
/*     */ 
/*     */ 
/*     */     
/* 169 */     int compressionIndex = -1;
/* 170 */     String[] compressionTypes = TIFFImageWriter.compressionTypes;
/* 171 */     int len = compressionTypes.length;
/* 172 */     for (int i = 0; i < len; i++) {
/* 173 */       if (compressionTypes[i].equals(compressionType)) {
/*     */         
/* 175 */         compressionIndex = i;
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/* 180 */     if (compressionIndex != -1) {
/*     */       
/* 182 */       this.compressionTagValue = TIFFImageWriter.compressionNumbers[compressionIndex];
/*     */       
/* 184 */       this.isCompressionLossless = TIFFImageWriter.isCompressionLossless[compressionIndex];
/*     */     }
/*     */     else {
/*     */       
/* 188 */       this.compressionTagValue = compressionTagValue;
/* 189 */       this.isCompressionLossless = isCompressionLossless;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCompressionType() {
/* 199 */     return this.compressionType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getCompressionTagValue() {
/* 209 */     return this.compressionTagValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCompressionLossless() {
/* 218 */     return this.isCompressionLossless;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setStream(ImageOutputStream stream) {
/* 229 */     this.stream = stream;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageOutputStream getStream() {
/* 240 */     return this.stream;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setWriter(ImageWriter writer) {
/* 251 */     this.writer = writer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageWriter getWriter() {
/* 262 */     return this.writer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMetadata(IIOMetadata metadata) {
/* 274 */     this.metadata = metadata;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IIOMetadata getMetadata() {
/* 286 */     return this.metadata;
/*     */   }
/*     */   
/*     */   public abstract int encode(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, int paramInt3, int[] paramArrayOfint, int paramInt4) throws IOException;
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageio/plugins/tiff/TIFFCompressor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */