/*     */ package com.sun.media.imageioimpl.common;
/*     */ 
/*     */ import java.awt.color.ColorSpace;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class InvertedCMYKColorSpace
/*     */   extends ColorSpace
/*     */ {
/*  90 */   private static ColorSpace theInstance = null;
/*     */   
/*     */   private ColorSpace csRGB;
/*     */   
/*     */   private static final double power1 = 0.4166666666666667D;
/*     */   
/*     */   public static final synchronized ColorSpace getInstance() {
/*  97 */     if (theInstance == null) {
/*  98 */       theInstance = new InvertedCMYKColorSpace();
/*     */     }
/* 100 */     return theInstance;
/*     */   }
/*     */   
/*     */   private InvertedCMYKColorSpace() {
/* 104 */     super(9, 4);
/* 105 */     this.csRGB = ColorSpace.getInstance(1004);
/*     */   }
/*     */   
/*     */   public boolean equals(Object o) {
/* 109 */     return (o != null && o instanceof InvertedCMYKColorSpace);
/*     */   }
/*     */   
/*     */   public float[] toRGB(float[] colorvalue) {
/* 113 */     float C = colorvalue[0];
/* 114 */     float M = colorvalue[1];
/* 115 */     float Y = colorvalue[2];
/* 116 */     float K = colorvalue[3];
/*     */ 
/*     */     
/* 119 */     float[] rgbvalue = { K * C, K * M, K * Y };
/*     */ 
/*     */     
/* 122 */     for (int i = 0; i < 3; i++) {
/* 123 */       float v = rgbvalue[i];
/*     */       
/* 125 */       if (v < 0.0F) v = 0.0F;
/*     */       
/* 127 */       if (v < 0.0031308F) {
/* 128 */         rgbvalue[i] = 12.92F * v;
/*     */       } else {
/* 130 */         if (v > 1.0F) v = 1.0F;
/*     */         
/* 132 */         rgbvalue[i] = (float)(1.055D * Math.pow(v, 0.4166666666666667D) - 0.055D);
/*     */       } 
/*     */     } 
/*     */     
/* 136 */     return rgbvalue;
/*     */   }
/*     */ 
/*     */   
/*     */   public float[] fromRGB(float[] rgbvalue) {
/* 141 */     for (int i = 0; i < 3; i++) {
/* 142 */       if (rgbvalue[i] < 0.040449936F) {
/* 143 */         rgbvalue[i] = rgbvalue[i] / 12.92F;
/*     */       } else {
/* 145 */         rgbvalue[i] = (float)Math.pow((rgbvalue[i] + 0.055D) / 1.055D, 2.4D);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 151 */     float C = rgbvalue[0];
/* 152 */     float M = rgbvalue[1];
/* 153 */     float Y = rgbvalue[2];
/* 154 */     float K = Math.max(C, Math.max(M, Y));
/*     */ 
/*     */     
/* 157 */     if (K != 0.0F) {
/* 158 */       C /= K;
/* 159 */       M /= K;
/* 160 */       Y /= K;
/*     */     } else {
/* 162 */       C = M = Y = 1.0F;
/*     */     } 
/*     */     
/* 165 */     return new float[] { C, M, Y, K };
/*     */   }
/*     */   
/*     */   public float[] toCIEXYZ(float[] colorvalue) {
/* 169 */     return this.csRGB.toCIEXYZ(toRGB(colorvalue));
/*     */   }
/*     */   
/*     */   public float[] fromCIEXYZ(float[] xyzvalue) {
/* 173 */     return fromRGB(this.csRGB.fromCIEXYZ(xyzvalue));
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/common/InvertedCMYKColorSpace.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */