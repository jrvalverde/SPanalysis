/*     */ package com.sun.media.imageioimpl.common;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import javax.imageio.stream.ImageOutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LZWCompressor
/*     */ {
/*     */   int codeSize_;
/*     */   int clearCode_;
/*     */   int endOfInfo_;
/*     */   int numBits_;
/*     */   int limit_;
/*     */   short prefix_;
/*     */   BitFile bf_;
/*     */   LZWStringTable lzss_;
/*     */   boolean tiffFudge_;
/*     */   
/*     */   public LZWCompressor(ImageOutputStream out, int codeSize, boolean TIFF) throws IOException {
/* 129 */     this.bf_ = new BitFile(out, !TIFF);
/* 130 */     this.codeSize_ = codeSize;
/* 131 */     this.tiffFudge_ = TIFF;
/* 132 */     this.clearCode_ = 1 << this.codeSize_;
/* 133 */     this.endOfInfo_ = this.clearCode_ + 1;
/* 134 */     this.numBits_ = this.codeSize_ + 1;
/*     */     
/* 136 */     this.limit_ = (1 << this.numBits_) - 1;
/* 137 */     if (this.tiffFudge_) {
/* 138 */       this.limit_--;
/*     */     }
/* 140 */     this.prefix_ = -1;
/* 141 */     this.lzss_ = new LZWStringTable();
/* 142 */     this.lzss_.ClearTable(this.codeSize_);
/* 143 */     this.bf_.writeBits(this.clearCode_, this.numBits_);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void compress(byte[] buf, int offset, int length) throws IOException {
/* 157 */     int maxOffset = offset + length;
/* 158 */     for (int idx = offset; idx < maxOffset; idx++) {
/*     */       
/* 160 */       byte c = buf[idx]; short index;
/* 161 */       if ((index = this.lzss_.FindCharString(this.prefix_, c)) != -1) {
/* 162 */         this.prefix_ = index;
/*     */       } else {
/*     */         
/* 165 */         this.bf_.writeBits(this.prefix_, this.numBits_);
/* 166 */         if (this.lzss_.AddCharString(this.prefix_, c) > this.limit_) {
/*     */           
/* 168 */           if (this.numBits_ == 12) {
/*     */             
/* 170 */             this.bf_.writeBits(this.clearCode_, this.numBits_);
/* 171 */             this.lzss_.ClearTable(this.codeSize_);
/* 172 */             this.numBits_ = this.codeSize_ + 1;
/*     */           } else {
/*     */             
/* 175 */             this.numBits_++;
/*     */           } 
/* 177 */           this.limit_ = (1 << this.numBits_) - 1;
/* 178 */           if (this.tiffFudge_)
/* 179 */             this.limit_--; 
/*     */         } 
/* 181 */         this.prefix_ = (short)((short)c & 0xFF);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void flush() throws IOException {
/* 194 */     if (this.prefix_ != -1) {
/* 195 */       this.bf_.writeBits(this.prefix_, this.numBits_);
/*     */     }
/* 197 */     this.bf_.writeBits(this.endOfInfo_, this.numBits_);
/* 198 */     this.bf_.flush();
/*     */   }
/*     */ 
/*     */   
/*     */   public void dump(PrintStream out) {
/* 203 */     this.lzss_.dump(out);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/common/LZWCompressor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */