/*     */ package com.sun.media.imageioimpl.plugins.tiff;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.imageio.IIOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TIFFRLECompressor
/*     */   extends TIFFFaxCompressor
/*     */ {
/*     */   public TIFFRLECompressor() {
/*  94 */     super("CCITT RLE", 2, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int encodeRLE(byte[] data, int rowOffset, int colOffset, int rowLength, byte[] compData) {
/* 117 */     initBitBuf();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 122 */     int outIndex = encode1D(data, rowOffset, colOffset, rowLength, compData, 0);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 128 */     while (this.ndex > 0) {
/* 129 */       compData[outIndex++] = (byte)(this.bits >>> 24);
/* 130 */       this.bits <<= 8;
/* 131 */       this.ndex -= 8;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 137 */     if (this.inverseFill) {
/* 138 */       byte[] flipTable = TIFFFaxDecompressor.flipTable;
/* 139 */       for (int i = 0; i < outIndex; i++) {
/* 140 */         compData[i] = flipTable[compData[i] & 0xFF];
/*     */       }
/*     */     } 
/*     */     
/* 144 */     return outIndex;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int encode(byte[] b, int off, int width, int height, int[] bitsPerSample, int scanlineStride) throws IOException {
/* 151 */     if (bitsPerSample.length != 1 || bitsPerSample[0] != 1) {
/* 152 */       throw new IIOException("Bits per sample must be 1 for RLE compression!");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 158 */     int maxBits = 9 * (width + 1) / 2 + 2;
/* 159 */     byte[] compData = new byte[(maxBits + 7) / 8];
/*     */     
/* 161 */     int bytes = 0;
/* 162 */     int rowOffset = off;
/*     */     
/* 164 */     for (int i = 0; i < height; i++) {
/* 165 */       int rowBytes = encodeRLE(b, rowOffset, 0, width, compData);
/* 166 */       this.stream.write(compData, 0, rowBytes);
/*     */       
/* 168 */       rowOffset += scanlineStride;
/* 169 */       bytes += rowBytes;
/*     */     } 
/*     */     
/* 172 */     return bytes;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/tiff/TIFFRLECompressor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */