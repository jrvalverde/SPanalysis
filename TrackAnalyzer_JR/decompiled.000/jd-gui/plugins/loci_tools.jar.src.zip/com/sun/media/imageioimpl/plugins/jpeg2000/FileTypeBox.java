/*     */ package com.sun.media.imageioimpl.plugins.jpeg2000;
/*     */ 
/*     */ import javax.imageio.metadata.IIOInvalidTreeException;
/*     */ import javax.imageio.metadata.IIOMetadataNode;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FileTypeBox
/*     */   extends Box
/*     */ {
/*  97 */   private static String[] elementNames = new String[] { "Brand", "MinorVersion", "CompatibilityList" };
/*     */   
/*     */   private int brand;
/*     */   
/*     */   private int minorVersion;
/*     */   private int[] compatibility;
/*     */   
/*     */   public static String[] getElementNames() {
/* 105 */     return elementNames;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FileTypeBox(int br, int minorVersion, int[] comp) {
/* 117 */     super(16 + ((comp == null) ? 0 : (comp.length << 2)), 1718909296, null);
/* 118 */     this.brand = br;
/* 119 */     this.minorVersion = minorVersion;
/* 120 */     this.compatibility = comp;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public FileTypeBox(byte[] data) {
/* 126 */     super(8 + data.length, 1718909296, data);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FileTypeBox(Node node) throws IIOInvalidTreeException {
/* 133 */     super(node);
/* 134 */     NodeList children = node.getChildNodes();
/*     */     
/* 136 */     for (int i = 0; i < children.getLength(); i++) {
/* 137 */       Node child = children.item(i);
/* 138 */       String name = child.getNodeName();
/*     */       
/* 140 */       if ("Brand".equals(name)) {
/* 141 */         this.brand = Box.getIntElementValue(child);
/*     */       }
/*     */       
/* 144 */       if ("MinorVersion".equals(name)) {
/* 145 */         this.minorVersion = Box.getIntElementValue(child);
/*     */       }
/*     */       
/* 148 */       if ("CompatibilityList".equals(name)) {
/* 149 */         this.compatibility = Box.getIntArrayElementValue(child);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int getBrand() {
/* 156 */     return this.brand;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getMinorVersion() {
/* 161 */     return this.minorVersion;
/*     */   }
/*     */ 
/*     */   
/*     */   public int[] getCompatibilityList() {
/* 166 */     return this.compatibility;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IIOMetadataNode getNativeNode() {
/* 174 */     return getNativeNodeForSimpleBox();
/*     */   }
/*     */   
/*     */   protected void parse(byte[] data) {
/* 178 */     if (data == null)
/*     */       return; 
/* 180 */     this.brand = (data[0] & 0xFF) << 24 | (data[1] & 0xFF) << 16 | (data[2] & 0xFF) << 8 | data[3] & 0xFF;
/*     */ 
/*     */     
/* 183 */     this.minorVersion = (data[4] & 0xFF) << 24 | (data[5] & 0xFF) << 16 | (data[6] & 0xFF) << 8 | data[7] & 0xFF;
/*     */ 
/*     */     
/* 186 */     int len = (data.length - 8) / 4;
/* 187 */     if (len > 0) {
/* 188 */       this.compatibility = new int[len];
/* 189 */       for (int i = 0, j = 8; i < len; i++, j += 4) {
/* 190 */         this.compatibility[i] = (data[j] & 0xFF) << 24 | (data[j + 1] & 0xFF) << 16 | (data[j + 2] & 0xFF) << 8 | data[j + 3] & 0xFF;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void compose() {
/* 198 */     if (this.data != null)
/*     */       return; 
/* 200 */     this.data = new byte[8 + ((this.compatibility != null) ? (this.compatibility.length << 2) : 0)];
/*     */ 
/*     */ 
/*     */     
/* 204 */     copyInt(this.data, 0, this.brand);
/* 205 */     copyInt(this.data, 4, this.minorVersion);
/* 206 */     if (this.compatibility != null)
/* 207 */       for (int i = 0, j = 8; i < this.compatibility.length; i++, j += 4)
/* 208 */         copyInt(this.data, j, this.compatibility[i]);  
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/jpeg2000/FileTypeBox.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */