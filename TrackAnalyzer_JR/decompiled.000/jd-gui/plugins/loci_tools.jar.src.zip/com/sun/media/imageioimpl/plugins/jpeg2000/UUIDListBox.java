/*     */ package com.sun.media.imageioimpl.plugins.jpeg2000;
/*     */ 
/*     */ import com.sun.media.imageioimpl.common.ImageUtil;
/*     */ import javax.imageio.metadata.IIOInvalidTreeException;
/*     */ import javax.imageio.metadata.IIOMetadataNode;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UUIDListBox
/*     */   extends Box
/*     */ {
/*     */   private short num;
/*     */   private byte[][] uuids;
/*     */   
/*     */   public UUIDListBox(short num, byte[][] uuids) {
/* 105 */     super(10 + (uuids.length << 4), 1970041716, null);
/* 106 */     this.num = num;
/* 107 */     this.uuids = uuids;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UUIDListBox(byte[] data) {
/* 114 */     super(8 + data.length, 1970041716, data);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UUIDListBox(Node node) throws IIOInvalidTreeException {
/* 121 */     super(node);
/* 122 */     NodeList children = node.getChildNodes();
/* 123 */     int index = 0;
/*     */     int i;
/* 125 */     for (i = 0; i < children.getLength(); i++) {
/* 126 */       Node child = children.item(i);
/*     */       
/* 128 */       if ("NumberUUID".equals(child.getNodeName())) {
/* 129 */         this.num = Box.getShortElementValue(child);
/* 130 */         this.uuids = new byte[this.num][];
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 135 */     for (i = 0; i < children.getLength(); i++) {
/* 136 */       Node child = children.item(i);
/*     */       
/* 138 */       if ("UUID".equals(child.getNodeName()) && index < this.num) {
/* 139 */         this.uuids[index++] = Box.getByteArrayElementValue(child);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void parse(byte[] data) {
/* 146 */     this.num = (short)((data[0] & 0xFF) << 8 | data[1] & 0xFF);
/*     */     
/* 148 */     this.uuids = new byte[this.num][];
/* 149 */     int pos = 2;
/* 150 */     for (int i = 0; i < this.num; i++) {
/* 151 */       this.uuids[i] = new byte[16];
/* 152 */       System.arraycopy(data, pos, this.uuids[i], 0, 16);
/* 153 */       pos += 16;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IIOMetadataNode getNativeNode() {
/* 162 */     IIOMetadataNode node = new IIOMetadataNode(Box.getName(getType()));
/* 163 */     setDefaultAttributes(node);
/*     */     
/* 165 */     IIOMetadataNode child = new IIOMetadataNode("NumberUUID");
/* 166 */     child.setUserObject(new Short(this.num));
/* 167 */     child.setNodeValue("" + this.num);
/* 168 */     node.appendChild(child);
/*     */     
/* 170 */     for (int i = 0; i < this.num; i++) {
/* 171 */       child = new IIOMetadataNode("UUID");
/* 172 */       child.setUserObject(this.uuids[i]);
/* 173 */       child.setNodeValue(ImageUtil.convertObjectToString(this.uuids[i]));
/* 174 */       node.appendChild(child);
/*     */     } 
/*     */     
/* 177 */     return node;
/*     */   }
/*     */   
/*     */   protected void compose() {
/* 181 */     if (this.data != null)
/*     */       return; 
/* 183 */     this.data = new byte[2 + this.num * 16];
/*     */     
/* 185 */     this.data[0] = (byte)(this.num >> 8);
/* 186 */     this.data[1] = (byte)(this.num & 0xFF);
/*     */     
/* 188 */     for (int i = 0, pos = 2; i < this.num; i++) {
/* 189 */       System.arraycopy(this.uuids[i], 0, this.data, pos, 16);
/* 190 */       pos += 16;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/jpeg2000/UUIDListBox.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */