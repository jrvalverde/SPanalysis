/*     */ package com.sun.media.imageio.stream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class StreamSegmentMapperImpl
/*     */   implements StreamSegmentMapper
/*     */ {
/*     */   private long[] segmentPositions;
/*     */   private int[] segmentLengths;
/*     */   
/*     */   public StreamSegmentMapperImpl(long[] segmentPositions, int[] segmentLengths) {
/* 100 */     this.segmentPositions = (long[])segmentPositions.clone();
/* 101 */     this.segmentLengths = (int[])segmentLengths.clone();
/*     */   }
/*     */   
/*     */   public StreamSegment getStreamSegment(long position, int length) {
/* 105 */     int numSegments = this.segmentLengths.length;
/* 106 */     for (int i = 0; i < numSegments; i++) {
/* 107 */       int len = this.segmentLengths[i];
/* 108 */       if (position < len) {
/* 109 */         return new StreamSegment(this.segmentPositions[i] + position, Math.min(len - (int)position, length));
/*     */       }
/*     */ 
/*     */       
/* 113 */       position -= len;
/*     */     } 
/*     */     
/* 116 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void getStreamSegment(long position, int length, StreamSegment seg) {
/* 121 */     int numSegments = this.segmentLengths.length;
/* 122 */     for (int i = 0; i < numSegments; i++) {
/* 123 */       int len = this.segmentLengths[i];
/* 124 */       if (position < len) {
/* 125 */         seg.setStartPos(this.segmentPositions[i] + position);
/* 126 */         seg.setSegmentLength(Math.min(len - (int)position, length));
/*     */         return;
/*     */       } 
/* 129 */       position -= len;
/*     */     } 
/*     */     
/* 132 */     seg.setStartPos(-1L);
/* 133 */     seg.setSegmentLength(-1);
/*     */   }
/*     */ 
/*     */   
/*     */   long length() {
/* 138 */     int numSegments = this.segmentLengths.length;
/* 139 */     long len = 0L;
/*     */     
/* 141 */     for (int i = 0; i < numSegments; i++) {
/* 142 */       len += this.segmentLengths[i];
/*     */     }
/*     */     
/* 145 */     return len;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageio/stream/StreamSegmentMapperImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */