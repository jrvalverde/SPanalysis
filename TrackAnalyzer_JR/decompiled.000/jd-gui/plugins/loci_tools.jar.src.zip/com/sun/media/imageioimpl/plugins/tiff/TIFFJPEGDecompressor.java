/*     */ package com.sun.media.imageioimpl.plugins.tiff;
/*     */ 
/*     */ import com.sun.media.imageio.plugins.tiff.TIFFDecompressor;
/*     */ import com.sun.media.imageio.plugins.tiff.TIFFField;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.Iterator;
/*     */ import javax.imageio.ImageIO;
/*     */ import javax.imageio.ImageReadParam;
/*     */ import javax.imageio.ImageReader;
/*     */ import javax.imageio.stream.ImageInputStream;
/*     */ import javax.imageio.stream.MemoryCacheImageInputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TIFFJPEGDecompressor
/*     */   extends TIFFDecompressor
/*     */ {
/*     */   private static final boolean DEBUG = false;
/*     */   protected static final int SOI = 216;
/*     */   protected static final int EOI = 217;
/* 106 */   protected ImageReader JPEGReader = null;
/*     */   
/*     */   protected ImageReadParam JPEGParam;
/*     */   protected boolean hasJPEGTables = false;
/* 110 */   protected byte[] tables = null;
/*     */   
/* 112 */   private byte[] data = new byte[0];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void beginDecoding() {
/* 159 */     if (this.JPEGReader == null) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 174 */       Iterator<ImageReader> iter = ImageIO.getImageReadersByFormatName("jpeg");
/*     */       
/* 176 */       if (!iter.hasNext())
/*     */       {
/* 178 */         throw new IllegalStateException("No JPEG readers found!");
/*     */       }
/*     */ 
/*     */       
/* 182 */       this.JPEGReader = iter.next();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 187 */       this.JPEGParam = this.JPEGReader.getDefaultReadParam();
/*     */     } 
/*     */ 
/*     */     
/* 191 */     TIFFImageMetadata tmetadata = (TIFFImageMetadata)this.metadata;
/* 192 */     TIFFField f = tmetadata.getTIFFField(347);
/*     */ 
/*     */     
/* 195 */     if (f != null) {
/* 196 */       this.hasJPEGTables = true;
/* 197 */       this.tables = f.getAsBytes();
/*     */     } else {
/* 199 */       this.hasJPEGTables = false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void decodeRaw(byte[] b, int dstOffset, int bitsPerPixel, int scanlineStride) throws IOException {
/*     */     ImageInputStream is;
/* 208 */     this.stream.seek(this.offset);
/*     */ 
/*     */ 
/*     */     
/* 212 */     if (this.hasJPEGTables) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 217 */       int dataLength = this.tables.length + this.byteCount;
/* 218 */       if (this.data.length < dataLength) {
/* 219 */         this.data = new byte[dataLength];
/*     */       }
/*     */ 
/*     */       
/* 223 */       int dataOffset = this.tables.length;
/* 224 */       for (int i = this.tables.length - 2; i > 0; i--) {
/* 225 */         if ((this.tables[i] & 0xFF) == 255 && (this.tables[i + 1] & 0xFF) == 217) {
/*     */           
/* 227 */           dataOffset = i;
/*     */           break;
/*     */         } 
/*     */       } 
/* 231 */       System.arraycopy(this.tables, 0, this.data, 0, dataOffset);
/*     */ 
/*     */       
/* 234 */       byte byte1 = (byte)this.stream.read();
/* 235 */       byte byte2 = (byte)this.stream.read();
/* 236 */       if ((byte1 & 0xFF) != 255 || (byte2 & 0xFF) != 216) {
/* 237 */         this.data[dataOffset++] = byte1;
/* 238 */         this.data[dataOffset++] = byte2;
/*     */       } 
/*     */ 
/*     */       
/* 242 */       this.stream.readFully(this.data, dataOffset, this.byteCount - 2);
/*     */ 
/*     */       
/* 245 */       ByteArrayInputStream bais = new ByteArrayInputStream(this.data);
/* 246 */       is = new MemoryCacheImageInputStream(bais);
/*     */     }
/*     */     else {
/*     */       
/* 250 */       is = this.stream;
/*     */     } 
/*     */ 
/*     */     
/* 254 */     this.JPEGReader.setInput(is, false, true);
/*     */ 
/*     */     
/* 257 */     this.JPEGParam.setDestination(this.rawImage);
/*     */ 
/*     */     
/* 260 */     this.JPEGReader.read(0, this.JPEGParam);
/*     */   }
/*     */   
/*     */   protected void finalize() throws Throwable {
/* 264 */     super.finalize();
/* 265 */     this.JPEGReader.dispose();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/tiff/TIFFJPEGDecompressor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */