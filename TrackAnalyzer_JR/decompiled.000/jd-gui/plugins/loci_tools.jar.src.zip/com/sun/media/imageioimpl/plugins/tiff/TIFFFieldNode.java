/*     */ package com.sun.media.imageioimpl.plugins.tiff;
/*     */ 
/*     */ import com.sun.media.imageio.plugins.tiff.TIFFDirectory;
/*     */ import com.sun.media.imageio.plugins.tiff.TIFFField;
/*     */ import com.sun.media.imageio.plugins.tiff.TIFFTag;
/*     */ import com.sun.media.imageio.plugins.tiff.TIFFTagSet;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import javax.imageio.metadata.IIOMetadataNode;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TIFFFieldNode
/*     */   extends IIOMetadataNode
/*     */ {
/*     */   private boolean isIFD;
/*     */   
/*     */   private static String getNodeName(TIFFField f) {
/* 107 */     return (f.getData() instanceof TIFFDirectory) ? "TIFFIFD" : "TIFFField";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 114 */   private Boolean isInitialized = Boolean.FALSE;
/*     */   
/*     */   private TIFFField field;
/*     */ 
/*     */   
/*     */   public TIFFFieldNode(TIFFField field) {
/* 120 */     super(getNodeName(field));
/*     */     
/* 122 */     this.isIFD = field.getData() instanceof TIFFDirectory;
/*     */     
/* 124 */     this.field = field;
/*     */     
/* 126 */     TIFFTag tag = field.getTag();
/* 127 */     int tagNumber = tag.getNumber();
/* 128 */     String tagName = tag.getName();
/*     */     
/* 130 */     if (this.isIFD) {
/* 131 */       if (tagNumber != 0) {
/* 132 */         setAttribute("parentTagNumber", Integer.toString(tagNumber));
/*     */       }
/* 134 */       if (tagName != null) {
/* 135 */         setAttribute("parentTagName", tagName);
/*     */       }
/*     */       
/* 138 */       TIFFDirectory dir = (TIFFDirectory)field.getData();
/* 139 */       TIFFTagSet[] tagSets = dir.getTagSets();
/* 140 */       if (tagSets != null) {
/* 141 */         String tagSetNames = "";
/* 142 */         for (int i = 0; i < tagSets.length; i++) {
/* 143 */           tagSetNames = tagSetNames + tagSets[i].getClass().getName();
/* 144 */           if (i != tagSets.length - 1) {
/* 145 */             tagSetNames = tagSetNames + ",";
/*     */           }
/*     */         } 
/* 148 */         setAttribute("tagSets", tagSetNames);
/*     */       } 
/*     */     } else {
/* 151 */       setAttribute("number", Integer.toString(tagNumber));
/* 152 */       setAttribute("name", tagName);
/*     */     } 
/*     */   }
/*     */   
/*     */   private synchronized void initialize() {
/* 157 */     if (this.isInitialized == Boolean.TRUE)
/*     */       return; 
/* 159 */     if (this.isIFD) {
/* 160 */       TIFFDirectory dir = (TIFFDirectory)this.field.getData();
/* 161 */       TIFFField[] fields = dir.getTIFFFields();
/* 162 */       if (fields != null) {
/* 163 */         TIFFTagSet[] tagSets = dir.getTagSets();
/* 164 */         List<TIFFTagSet> tagSetList = Arrays.asList(tagSets);
/* 165 */         int numFields = fields.length;
/* 166 */         for (int i = 0; i < numFields; i++) {
/* 167 */           TIFFField f = fields[i];
/* 168 */           int tagNumber = f.getTagNumber();
/* 169 */           TIFFTag tag = TIFFIFD.getTag(tagNumber, tagSetList);
/*     */           
/* 171 */           Node node = f.getAsNativeNode();
/*     */           
/* 173 */           if (node != null) {
/* 174 */             appendChild(node);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } else {
/*     */       IIOMetadataNode child;
/* 180 */       int count = this.field.getCount();
/* 181 */       if (this.field.getType() == 7) {
/* 182 */         child = new IIOMetadataNode("TIFFUndefined");
/*     */         
/* 184 */         byte[] data = this.field.getAsBytes();
/* 185 */         StringBuffer sb = new StringBuffer();
/* 186 */         for (int i = 0; i < count; i++) {
/* 187 */           sb.append(Integer.toString(data[i] & 0xFF));
/* 188 */           if (i < count - 1) {
/* 189 */             sb.append(",");
/*     */           }
/*     */         } 
/* 192 */         child.setAttribute("value", sb.toString());
/*     */       } else {
/* 194 */         child = new IIOMetadataNode("TIFF" + TIFFField.getTypeName(this.field.getType()) + "s");
/*     */ 
/*     */ 
/*     */         
/* 198 */         TIFFTag tag = this.field.getTag();
/*     */         
/* 200 */         for (int i = 0; i < count; i++) {
/* 201 */           IIOMetadataNode cchild = new IIOMetadataNode("TIFF" + TIFFField.getTypeName(this.field.getType()));
/*     */ 
/*     */ 
/*     */           
/* 205 */           cchild.setAttribute("value", this.field.getValueAsString(i));
/* 206 */           if (tag.hasValueNames() && this.field.isIntegral()) {
/* 207 */             int value = this.field.getAsInt(i);
/* 208 */             String name = tag.getValueName(value);
/* 209 */             if (name != null) {
/* 210 */               cchild.setAttribute("description", name);
/*     */             }
/*     */           } 
/*     */           
/* 214 */           child.appendChild(cchild);
/*     */         } 
/*     */       } 
/* 217 */       appendChild(child);
/*     */     } 
/*     */     
/* 220 */     this.isInitialized = Boolean.TRUE;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Node appendChild(Node newChild) {
/* 226 */     if (newChild == null) {
/* 227 */       throw new IllegalArgumentException("newChild == null!");
/*     */     }
/*     */     
/* 230 */     return super.insertBefore(newChild, null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasChildNodes() {
/* 236 */     initialize();
/* 237 */     return super.hasChildNodes();
/*     */   }
/*     */   
/*     */   public int getLength() {
/* 241 */     initialize();
/* 242 */     return super.getLength();
/*     */   }
/*     */   
/*     */   public Node getFirstChild() {
/* 246 */     initialize();
/* 247 */     return super.getFirstChild();
/*     */   }
/*     */   
/*     */   public Node getLastChild() {
/* 251 */     initialize();
/* 252 */     return super.getLastChild();
/*     */   }
/*     */   
/*     */   public Node getPreviousSibling() {
/* 256 */     initialize();
/* 257 */     return super.getPreviousSibling();
/*     */   }
/*     */   
/*     */   public Node getNextSibling() {
/* 261 */     initialize();
/* 262 */     return super.getNextSibling();
/*     */   }
/*     */ 
/*     */   
/*     */   public Node insertBefore(Node newChild, Node refChild) {
/* 267 */     initialize();
/* 268 */     return super.insertBefore(newChild, refChild);
/*     */   }
/*     */ 
/*     */   
/*     */   public Node replaceChild(Node newChild, Node oldChild) {
/* 273 */     initialize();
/* 274 */     return super.replaceChild(newChild, oldChild);
/*     */   }
/*     */   
/*     */   public Node removeChild(Node oldChild) {
/* 278 */     initialize();
/* 279 */     return super.removeChild(oldChild);
/*     */   }
/*     */   
/*     */   public Node cloneNode(boolean deep) {
/* 283 */     initialize();
/* 284 */     return super.cloneNode(deep);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/tiff/TIFFFieldNode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */