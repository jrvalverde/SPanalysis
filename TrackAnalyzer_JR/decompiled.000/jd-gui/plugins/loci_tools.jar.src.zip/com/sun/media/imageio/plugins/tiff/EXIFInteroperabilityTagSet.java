/*     */ package com.sun.media.imageio.plugins.tiff;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EXIFInteroperabilityTagSet
/*     */   extends TIFFTagSet
/*     */ {
/*     */   public static final int TAG_INTEROPERABILITY_INDEX = 1;
/*     */   public static final String INTEROPERABILITY_INDEX_R98 = "R98";
/*     */   public static final String INTEROPERABILITY_INDEX_THM = "THM";
/* 121 */   private static EXIFInteroperabilityTagSet theInstance = null;
/*     */   private static List tags;
/*     */   
/*     */   static class InteroperabilityIndex extends TIFFTag {
/*     */     public InteroperabilityIndex() {
/* 126 */       super("InteroperabilityIndex", 1, 4);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void initTags() {
/* 135 */     tags = new ArrayList(42);
/*     */     
/* 137 */     tags.add(new InteroperabilityIndex());
/*     */   }
/*     */   
/*     */   private EXIFInteroperabilityTagSet() {
/* 141 */     super(tags);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized EXIFInteroperabilityTagSet getInstance() {
/* 151 */     if (theInstance == null) {
/* 152 */       initTags();
/* 153 */       theInstance = new EXIFInteroperabilityTagSet();
/* 154 */       tags = null;
/*     */     } 
/* 156 */     return theInstance;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageio/plugins/tiff/EXIFInteroperabilityTagSet.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */