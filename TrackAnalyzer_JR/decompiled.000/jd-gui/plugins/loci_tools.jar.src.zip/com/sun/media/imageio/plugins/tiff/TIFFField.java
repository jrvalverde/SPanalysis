/*      */ package com.sun.media.imageio.plugins.tiff;
/*      */ 
/*      */ import com.sun.media.imageioimpl.plugins.tiff.TIFFFieldNode;
/*      */ import java.util.StringTokenizer;
/*      */ import org.w3c.dom.NamedNodeMap;
/*      */ import org.w3c.dom.Node;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class TIFFField
/*      */   implements Comparable
/*      */ {
/*  325 */   private static final String[] typeNames = new String[] { null, "Byte", "Ascii", "Short", "Long", "Rational", "SByte", "Undefined", "SShort", "SLong", "SRational", "Float", "Double", "IFDPointer" };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  332 */   private static final boolean[] isIntegral = new boolean[] { 
/*      */       false, true, false, true, true, false, true, true, true, true, 
/*      */       false, false, false, false };
/*      */ 
/*      */   
/*      */   private TIFFTag tag;
/*      */ 
/*      */   
/*      */   private int tagNumber;
/*      */ 
/*      */   
/*      */   private int type;
/*      */ 
/*      */   
/*      */   private int count;
/*      */ 
/*      */   
/*      */   private Object data;
/*      */ 
/*      */ 
/*      */   
/*      */   private TIFFField() {}
/*      */ 
/*      */ 
/*      */   
/*      */   private static String getAttribute(Node node, String attrName) {
/*  358 */     NamedNodeMap attrs = node.getAttributes();
/*  359 */     return attrs.getNamedItem(attrName).getNodeValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void initData(Node node, int[] otype, int[] ocount, Object[] odata) {
/*  366 */     Object data = null;
/*      */     
/*  368 */     String typeName = node.getNodeName();
/*  369 */     typeName = typeName.substring(4);
/*  370 */     typeName = typeName.substring(0, typeName.length() - 1);
/*  371 */     int type = getTypeByName(typeName);
/*  372 */     if (type == -1) {
/*  373 */       throw new IllegalArgumentException("typeName = " + typeName);
/*      */     }
/*      */     
/*  376 */     Node child = node.getFirstChild();
/*      */     
/*  378 */     int count = 0;
/*  379 */     while (child != null) {
/*  380 */       String childTypeName = child.getNodeName().substring(4);
/*  381 */       if (!typeName.equals(childTypeName));
/*      */ 
/*      */ 
/*      */       
/*  385 */       count++;
/*  386 */       child = child.getNextSibling();
/*      */     } 
/*      */     
/*  389 */     if (count > 0) {
/*  390 */       data = createArrayForType(type, count);
/*  391 */       child = node.getFirstChild();
/*  392 */       int idx = 0;
/*  393 */       while (child != null) {
/*  394 */         String numerator, denominator; int slashPos; String value = getAttribute(child, "value");
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  399 */         switch (type) {
/*      */           case 2:
/*  401 */             ((String[])data)[idx] = value;
/*      */             break;
/*      */           case 1:
/*      */           case 6:
/*  405 */             ((byte[])data)[idx] = (byte)Integer.parseInt(value);
/*      */             break;
/*      */           
/*      */           case 3:
/*  409 */             ((char[])data)[idx] = (char)Integer.parseInt(value);
/*      */             break;
/*      */           
/*      */           case 8:
/*  413 */             ((short[])data)[idx] = (short)Integer.parseInt(value);
/*      */             break;
/*      */           
/*      */           case 9:
/*  417 */             ((int[])data)[idx] = Integer.parseInt(value);
/*      */             break;
/*      */           
/*      */           case 4:
/*      */           case 13:
/*  422 */             ((long[])data)[idx] = Long.parseLong(value);
/*      */             break;
/*      */           
/*      */           case 11:
/*  426 */             ((float[])data)[idx] = Float.parseFloat(value);
/*      */             break;
/*      */           
/*      */           case 12:
/*  430 */             ((double[])data)[idx] = Double.parseDouble(value);
/*      */             break;
/*      */           
/*      */           case 10:
/*  434 */             slashPos = value.indexOf("/");
/*  435 */             numerator = value.substring(0, slashPos);
/*  436 */             denominator = value.substring(slashPos + 1);
/*      */             
/*  438 */             ((int[][])data)[idx] = new int[2];
/*  439 */             ((int[][])data)[idx][0] = Integer.parseInt(numerator);
/*      */             
/*  441 */             ((int[][])data)[idx][1] = Integer.parseInt(denominator);
/*      */             break;
/*      */           
/*      */           case 5:
/*  445 */             slashPos = value.indexOf("/");
/*  446 */             numerator = value.substring(0, slashPos);
/*  447 */             denominator = value.substring(slashPos + 1);
/*      */             
/*  449 */             ((long[][])data)[idx] = new long[2];
/*  450 */             ((long[][])data)[idx][0] = Long.parseLong(numerator);
/*      */             
/*  452 */             ((long[][])data)[idx][1] = Long.parseLong(denominator);
/*      */             break;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  459 */         idx++;
/*  460 */         child = child.getNextSibling();
/*      */       } 
/*      */     } 
/*      */     
/*  464 */     otype[0] = type;
/*  465 */     ocount[0] = count;
/*  466 */     odata[0] = data;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static TIFFField createFromMetadataNode(TIFFTagSet tagSet, Node node) {
/*      */     TIFFTag tag;
/*  486 */     if (node == null) {
/*  487 */       throw new IllegalArgumentException("node == null!");
/*      */     }
/*  489 */     String name = node.getNodeName();
/*  490 */     if (!name.equals("TIFFField")) {
/*  491 */       throw new IllegalArgumentException("!name.equals(\"TIFFField\")");
/*      */     }
/*      */     
/*  494 */     int tagNumber = Integer.parseInt(getAttribute(node, "number"));
/*      */     
/*  496 */     if (tagSet != null) {
/*  497 */       tag = tagSet.getTag(tagNumber);
/*      */     } else {
/*  499 */       tag = new TIFFTag("unknown", tagNumber, 0, null);
/*      */     } 
/*      */     
/*  502 */     int type = 7;
/*  503 */     int count = 0;
/*  504 */     Object data = null;
/*      */     
/*  506 */     Node child = node.getFirstChild();
/*  507 */     if (child != null) {
/*  508 */       String typeName = child.getNodeName();
/*  509 */       if (typeName.equals("TIFFUndefined")) {
/*  510 */         String values = getAttribute(child, "value");
/*  511 */         StringTokenizer st = new StringTokenizer(values, ",");
/*  512 */         count = st.countTokens();
/*      */         
/*  514 */         byte[] bdata = new byte[count];
/*  515 */         for (int i = 0; i < count; i++) {
/*  516 */           bdata[i] = (byte)Integer.parseInt(st.nextToken());
/*      */         }
/*      */         
/*  519 */         type = 7;
/*  520 */         data = bdata;
/*      */       } else {
/*  522 */         int[] otype = new int[1];
/*  523 */         int[] ocount = new int[1];
/*  524 */         Object[] odata = new Object[1];
/*      */         
/*  526 */         initData(node.getFirstChild(), otype, ocount, odata);
/*  527 */         type = otype[0];
/*  528 */         count = ocount[0];
/*  529 */         data = odata[0];
/*      */       } 
/*      */     } else {
/*  532 */       int t = 13;
/*  533 */       while (t >= 1 && !tag.isDataTypeOK(t)) {
/*  534 */         t--;
/*      */       }
/*  536 */       type = t;
/*      */     } 
/*      */     
/*  539 */     return new TIFFField(tag, type, count, data);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TIFFField(TIFFTag tag, int type, int count, Object data) {
/*  585 */     if (tag == null)
/*  586 */       throw new IllegalArgumentException("tag == null!"); 
/*  587 */     if (type < 1 || type > 13)
/*  588 */       throw new IllegalArgumentException("Unknown data type " + type); 
/*  589 */     if (count < 0) {
/*  590 */       throw new IllegalArgumentException("count < 0!");
/*      */     }
/*  592 */     this.tag = tag;
/*  593 */     this.tagNumber = tag.getNumber();
/*  594 */     this.type = type;
/*  595 */     this.count = count;
/*  596 */     this.data = data;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TIFFField(TIFFTag tag, int type, int count) {
/*  608 */     this(tag, type, count, createArrayForType(type, count));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TIFFField(TIFFTag tag, int value) {
/*  626 */     if (tag == null) {
/*  627 */       throw new IllegalArgumentException("tag == null!");
/*      */     }
/*  629 */     if (value < 0) {
/*  630 */       throw new IllegalArgumentException("value < 0!");
/*      */     }
/*      */     
/*  633 */     this.tag = tag;
/*  634 */     this.tagNumber = tag.getNumber();
/*  635 */     this.count = 1;
/*      */     
/*  637 */     if (value < 65536) {
/*  638 */       this.type = 3;
/*  639 */       char[] cdata = new char[1];
/*  640 */       cdata[0] = (char)value;
/*  641 */       this.data = cdata;
/*      */     } else {
/*  643 */       this.type = 4;
/*  644 */       long[] ldata = new long[1];
/*  645 */       ldata[0] = value;
/*  646 */       this.data = ldata;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TIFFTag getTag() {
/*  656 */     return this.tag;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getTagNumber() {
/*  665 */     return this.tagNumber;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getType() {
/*  676 */     return this.type;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getTypeName(int dataType) {
/*  689 */     if (dataType < 1 || dataType > 13)
/*      */     {
/*  691 */       throw new IllegalArgumentException("Unknown data type " + dataType);
/*      */     }
/*      */     
/*  694 */     return typeNames[dataType];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int getTypeByName(String typeName) {
/*  705 */     for (int i = 1; i <= 13; i++) {
/*  706 */       if (typeName.equals(typeNames[i])) {
/*  707 */         return i;
/*      */       }
/*      */     } 
/*      */     
/*  711 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object createArrayForType(int dataType, int count) {
/*  726 */     if (count < 0) {
/*  727 */       throw new IllegalArgumentException("count < 0!");
/*      */     }
/*  729 */     switch (dataType) {
/*      */       case 1:
/*      */       case 6:
/*      */       case 7:
/*  733 */         return new byte[count];
/*      */       case 2:
/*  735 */         return new String[count];
/*      */       case 3:
/*  737 */         return new char[count];
/*      */       case 4:
/*      */       case 13:
/*  740 */         return new long[count];
/*      */       case 5:
/*  742 */         return new long[count][2];
/*      */       case 8:
/*  744 */         return new short[count];
/*      */       case 9:
/*  746 */         return new int[count];
/*      */       case 10:
/*  748 */         return new int[count][2];
/*      */       case 11:
/*  750 */         return new float[count];
/*      */       case 12:
/*  752 */         return new double[count];
/*      */     } 
/*  754 */     throw new IllegalArgumentException("Unknown data type " + dataType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Node getAsNativeNode() {
/*  771 */     return (Node)new TIFFFieldNode(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isIntegral() {
/*  781 */     return isIntegral[this.type];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getCount() {
/*  791 */     return this.count;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getData() {
/*  800 */     return this.data;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] getAsBytes() {
/*  818 */     return (byte[])this.data;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public char[] getAsChars() {
/*  829 */     return (char[])this.data;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public short[] getAsShorts() {
/*  840 */     return (short[])this.data;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int[] getAsInts() {
/*  852 */     if (this.data instanceof int[])
/*  853 */       return (int[])this.data; 
/*  854 */     if (this.data instanceof char[]) {
/*  855 */       char[] cdata = (char[])this.data;
/*  856 */       int[] idata = new int[cdata.length];
/*  857 */       for (int i = 0; i < cdata.length; i++) {
/*  858 */         idata[i] = cdata[i] & Character.MAX_VALUE;
/*      */       }
/*  860 */       return idata;
/*  861 */     }  if (this.data instanceof short[]) {
/*  862 */       short[] sdata = (short[])this.data;
/*  863 */       int[] idata = new int[sdata.length];
/*  864 */       for (int i = 0; i < sdata.length; i++) {
/*  865 */         idata[i] = sdata[i];
/*      */       }
/*  867 */       return idata;
/*      */     } 
/*  869 */     throw new ClassCastException("Data not char[], short[], or int[]!");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long[] getAsLongs() {
/*  883 */     return (long[])this.data;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float[] getAsFloats() {
/*  894 */     return (float[])this.data;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double[] getAsDoubles() {
/*  905 */     return (double[])this.data;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int[][] getAsSRationals() {
/*  916 */     return (int[][])this.data;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long[][] getAsRationals() {
/*  927 */     return (long[][])this.data;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getAsInt(int index) {
/*      */     int[] ivalue;
/*      */     long[] lvalue;
/*      */     String s;
/*  957 */     switch (this.type) { case 1:
/*      */       case 7:
/*  959 */         return ((byte[])this.data)[index] & 0xFF;
/*      */       case 6:
/*  961 */         return ((byte[])this.data)[index];
/*      */       case 3:
/*  963 */         return ((char[])this.data)[index] & Character.MAX_VALUE;
/*      */       case 8:
/*  965 */         return ((short[])this.data)[index];
/*      */       case 9:
/*  967 */         return ((int[])this.data)[index];
/*      */       case 4: case 13:
/*  969 */         return (int)((long[])this.data)[index];
/*      */       case 11:
/*  971 */         return (int)((float[])this.data)[index];
/*      */       case 12:
/*  973 */         return (int)((double[])this.data)[index];
/*      */       case 10:
/*  975 */         ivalue = getAsSRational(index);
/*  976 */         return (int)(ivalue[0] / ivalue[1]);
/*      */       case 5:
/*  978 */         lvalue = getAsRational(index);
/*  979 */         return (int)(lvalue[0] / lvalue[1]);
/*      */       case 2:
/*  981 */         s = ((String[])this.data)[index];
/*  982 */         return (int)Double.parseDouble(s); }
/*      */     
/*  984 */     throw new ClassCastException();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getAsLong(int index) {
/*      */     int[] ivalue;
/*      */     long[] lvalue;
/*      */     String s;
/* 1002 */     switch (this.type) { case 1:
/*      */       case 7:
/* 1004 */         return (((byte[])this.data)[index] & 0xFF);
/*      */       case 6:
/* 1006 */         return ((byte[])this.data)[index];
/*      */       case 3:
/* 1008 */         return (((char[])this.data)[index] & Character.MAX_VALUE);
/*      */       case 8:
/* 1010 */         return ((short[])this.data)[index];
/*      */       case 9:
/* 1012 */         return ((int[])this.data)[index];
/*      */       case 4: case 13:
/* 1014 */         return ((long[])this.data)[index];
/*      */       case 10:
/* 1016 */         ivalue = getAsSRational(index);
/* 1017 */         return (long)(ivalue[0] / ivalue[1]);
/*      */       case 5:
/* 1019 */         lvalue = getAsRational(index);
/* 1020 */         return (long)(lvalue[0] / lvalue[1]);
/*      */       case 2:
/* 1022 */         s = ((String[])this.data)[index];
/* 1023 */         return (long)Double.parseDouble(s); }
/*      */     
/* 1025 */     throw new ClassCastException();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getAsFloat(int index) {
/*      */     int[] ivalue;
/*      */     long[] lvalue;
/*      */     String s;
/* 1053 */     switch (this.type) { case 1:
/*      */       case 7:
/* 1055 */         return (((byte[])this.data)[index] & 0xFF);
/*      */       case 6:
/* 1057 */         return ((byte[])this.data)[index];
/*      */       case 3:
/* 1059 */         return (((char[])this.data)[index] & Character.MAX_VALUE);
/*      */       case 8:
/* 1061 */         return ((short[])this.data)[index];
/*      */       case 9:
/* 1063 */         return ((int[])this.data)[index];
/*      */       case 4: case 13:
/* 1065 */         return (float)((long[])this.data)[index];
/*      */       case 11:
/* 1067 */         return ((float[])this.data)[index];
/*      */       case 12:
/* 1069 */         return (float)((double[])this.data)[index];
/*      */       case 10:
/* 1071 */         ivalue = getAsSRational(index);
/* 1072 */         return (float)(ivalue[0] / ivalue[1]);
/*      */       case 5:
/* 1074 */         lvalue = getAsRational(index);
/* 1075 */         return (float)(lvalue[0] / lvalue[1]);
/*      */       case 2:
/* 1077 */         s = ((String[])this.data)[index];
/* 1078 */         return (float)Double.parseDouble(s); }
/*      */     
/* 1080 */     throw new ClassCastException();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double getAsDouble(int index) {
/*      */     int[] ivalue;
/*      */     long[] lvalue;
/*      */     String s;
/* 1102 */     switch (this.type) { case 1:
/*      */       case 7:
/* 1104 */         return (((byte[])this.data)[index] & 0xFF);
/*      */       case 6:
/* 1106 */         return ((byte[])this.data)[index];
/*      */       case 3:
/* 1108 */         return (((char[])this.data)[index] & Character.MAX_VALUE);
/*      */       case 8:
/* 1110 */         return ((short[])this.data)[index];
/*      */       case 9:
/* 1112 */         return ((int[])this.data)[index];
/*      */       case 4: case 13:
/* 1114 */         return ((long[])this.data)[index];
/*      */       case 11:
/* 1116 */         return ((float[])this.data)[index];
/*      */       case 12:
/* 1118 */         return ((double[])this.data)[index];
/*      */       case 10:
/* 1120 */         ivalue = getAsSRational(index);
/* 1121 */         return ivalue[0] / ivalue[1];
/*      */       case 5:
/* 1123 */         lvalue = getAsRational(index);
/* 1124 */         return lvalue[0] / lvalue[1];
/*      */       case 2:
/* 1126 */         s = ((String[])this.data)[index];
/* 1127 */         return Double.parseDouble(s); }
/*      */     
/* 1129 */     throw new ClassCastException();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getAsString(int index) {
/* 1141 */     return ((String[])this.data)[index];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int[] getAsSRational(int index) {
/* 1152 */     return ((int[][])this.data)[index];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long[] getAsRational(int index) {
/* 1163 */     return ((long[][])this.data)[index];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getValueAsString(int index) {
/*      */     int[] ivalue;
/*      */     String srationalString;
/*      */     long[] lvalue;
/*      */     String rationalString;
/* 1178 */     switch (this.type) {
/*      */       case 2:
/* 1180 */         return ((String[])this.data)[index];
/*      */       case 1: case 7:
/* 1182 */         return Integer.toString(((byte[])this.data)[index] & 0xFF);
/*      */       case 6:
/* 1184 */         return Integer.toString(((byte[])this.data)[index]);
/*      */       case 3:
/* 1186 */         return Integer.toString(((char[])this.data)[index] & Character.MAX_VALUE);
/*      */       case 8:
/* 1188 */         return Integer.toString(((short[])this.data)[index]);
/*      */       case 9:
/* 1190 */         return Integer.toString(((int[])this.data)[index]);
/*      */       case 4: case 13:
/* 1192 */         return Long.toString(((long[])this.data)[index]);
/*      */       case 11:
/* 1194 */         return Float.toString(((float[])this.data)[index]);
/*      */       case 12:
/* 1196 */         return Double.toString(((double[])this.data)[index]);
/*      */       case 10:
/* 1198 */         ivalue = getAsSRational(index);
/*      */         
/* 1200 */         if (ivalue[1] != 0 && ivalue[0] % ivalue[1] == 0) {
/*      */ 
/*      */ 
/*      */           
/* 1204 */           srationalString = Integer.toString(ivalue[0] / ivalue[1]) + "/1";
/*      */         }
/*      */         else {
/*      */           
/* 1208 */           srationalString = Integer.toString(ivalue[0]) + "/" + Integer.toString(ivalue[1]);
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 1213 */         return srationalString;
/*      */       case 5:
/* 1215 */         lvalue = getAsRational(index);
/*      */         
/* 1217 */         if (lvalue[1] != 0L && lvalue[0] % lvalue[1] == 0L) {
/*      */ 
/*      */ 
/*      */           
/* 1221 */           rationalString = Long.toString(lvalue[0] / lvalue[1]) + "/1";
/*      */         }
/*      */         else {
/*      */           
/* 1225 */           rationalString = Long.toString(lvalue[0]) + "/" + Long.toString(lvalue[1]);
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 1230 */         return rationalString;
/*      */     } 
/* 1232 */     throw new ClassCastException();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int compareTo(Object o) {
/* 1248 */     if (o == null) {
/* 1249 */       throw new IllegalArgumentException();
/*      */     }
/*      */     
/* 1252 */     int oTagNumber = ((TIFFField)o).getTagNumber();
/* 1253 */     if (this.tagNumber < oTagNumber)
/* 1254 */       return -1; 
/* 1255 */     if (this.tagNumber > oTagNumber) {
/* 1256 */       return 1;
/*      */     }
/* 1258 */     return 0;
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageio/plugins/tiff/TIFFField.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */