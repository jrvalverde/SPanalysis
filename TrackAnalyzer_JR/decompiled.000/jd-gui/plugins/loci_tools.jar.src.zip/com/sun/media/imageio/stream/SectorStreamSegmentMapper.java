/*     */ package com.sun.media.imageio.stream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SectorStreamSegmentMapper
/*     */   implements StreamSegmentMapper
/*     */ {
/*     */   long[] segmentPositions;
/*     */   int segmentLength;
/*     */   int totalLength;
/*     */   int lastSegmentLength;
/*     */   
/*     */   public SectorStreamSegmentMapper(long[] segmentPositions, int segmentLength, int totalLength) {
/* 163 */     this.segmentPositions = (long[])segmentPositions.clone();
/* 164 */     this.segmentLength = segmentLength;
/* 165 */     this.totalLength = totalLength;
/* 166 */     this.lastSegmentLength = totalLength - (segmentPositions.length - 1) * segmentLength;
/*     */   }
/*     */ 
/*     */   
/*     */   public StreamSegment getStreamSegment(long position, int length) {
/* 171 */     int index = (int)(position / this.segmentLength);
/*     */ 
/*     */     
/* 174 */     int len = (index == this.segmentPositions.length - 1) ? this.lastSegmentLength : this.segmentLength;
/*     */ 
/*     */ 
/*     */     
/* 178 */     position -= (index * this.segmentLength);
/*     */ 
/*     */     
/* 181 */     len = (int)(len - position);
/* 182 */     if (len > length) {
/* 183 */       len = length;
/*     */     }
/* 185 */     return new StreamSegment(this.segmentPositions[index] + position, len);
/*     */   }
/*     */ 
/*     */   
/*     */   public void getStreamSegment(long position, int length, StreamSegment seg) {
/* 190 */     int index = (int)(position / this.segmentLength);
/*     */ 
/*     */     
/* 193 */     int len = (index == this.segmentPositions.length - 1) ? this.lastSegmentLength : this.segmentLength;
/*     */ 
/*     */ 
/*     */     
/* 197 */     position -= (index * this.segmentLength);
/*     */ 
/*     */     
/* 200 */     len = (int)(len - position);
/* 201 */     if (len > length) {
/* 202 */       len = length;
/*     */     }
/*     */     
/* 205 */     seg.setStartPos(this.segmentPositions[index] + position);
/* 206 */     seg.setSegmentLength(len);
/*     */   }
/*     */   
/*     */   long length() {
/* 210 */     return this.totalLength;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageio/stream/SectorStreamSegmentMapper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */