/*     */ package com.sun.media.imageioimpl.plugins.pcx;
/*     */ 
/*     */ import com.sun.media.imageioimpl.common.PackageUtil;
/*     */ import java.awt.image.SampleModel;
/*     */ import java.util.Locale;
/*     */ import javax.imageio.IIOException;
/*     */ import javax.imageio.ImageTypeSpecifier;
/*     */ import javax.imageio.ImageWriter;
/*     */ import javax.imageio.spi.ImageWriterSpi;
/*     */ import javax.imageio.spi.ServiceRegistry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PCXImageWriterSpi
/*     */   extends ImageWriterSpi
/*     */ {
/*  92 */   private static String[] readerSpiNames = new String[] { "com.sun.media.imageioimpl.plugins.pcx.PCXImageReaderSpi" };
/*     */   
/*  94 */   private static String[] formatNames = new String[] { "pcx", "PCX" };
/*  95 */   private static String[] extensions = new String[] { "pcx" };
/*  96 */   private static String[] mimeTypes = new String[] { "image/pcx", "image/x-pcx", "image/x-windows-pcx", "image/x-pc-paintbrush" };
/*     */   
/*     */   private boolean registered = false;
/*     */ 
/*     */   
/*     */   public PCXImageWriterSpi() {
/* 102 */     super(PackageUtil.getVendor(), PackageUtil.getVersion(), formatNames, extensions, mimeTypes, "com.sun.media.imageioimpl.plugins.pcx.PCXImageWriter", STANDARD_OUTPUT_TYPE, readerSpiNames, false, null, null, null, null, true, null, null, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDescription(Locale locale) {
/* 119 */     String desc = PackageUtil.getSpecificationTitle() + " PCX Image Writer";
/*     */     
/* 121 */     return desc;
/*     */   }
/*     */   
/*     */   public void onRegistration(ServiceRegistry registry, Class category) {
/* 125 */     if (this.registered) {
/*     */       return;
/*     */     }
/*     */     
/* 129 */     this.registered = true;
/*     */   }
/*     */   
/*     */   public boolean canEncodeImage(ImageTypeSpecifier type) {
/* 133 */     int dataType = type.getSampleModel().getDataType();
/* 134 */     if (dataType < 0 || dataType > 3) {
/* 135 */       return false;
/*     */     }
/* 137 */     SampleModel sm = type.getSampleModel();
/* 138 */     int numBands = sm.getNumBands();
/* 139 */     if (numBands != 1 && numBands != 3) {
/* 140 */       return false;
/*     */     }
/* 142 */     if (numBands == 1 && dataType != 0) {
/* 143 */       return false;
/*     */     }
/* 145 */     if (dataType > 0 && !(sm instanceof java.awt.image.SinglePixelPackedSampleModel)) {
/* 146 */       return false;
/*     */     }
/* 148 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public ImageWriter createWriterInstance(Object extension) throws IIOException {
/* 153 */     return new PCXImageWriter(this);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/pcx/PCXImageWriterSpi.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */