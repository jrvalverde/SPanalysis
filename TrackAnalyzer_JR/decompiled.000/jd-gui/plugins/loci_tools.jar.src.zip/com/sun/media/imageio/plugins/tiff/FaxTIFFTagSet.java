/*     */ package com.sun.media.imageio.plugins.tiff;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FaxTIFFTagSet
/*     */   extends TIFFTagSet
/*     */ {
/*  93 */   private static FaxTIFFTagSet theInstance = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int TAG_BAD_FAX_LINES = 326;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int TAG_CLEAN_FAX_DATA = 327;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int CLEAN_FAX_DATA_NO_ERRORS = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int CLEAN_FAX_DATA_ERRORS_CORRECTED = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int CLEAN_FAX_DATA_ERRORS_UNCORRECTED = 2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int TAG_CONSECUTIVE_BAD_LINES = 328;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static List tags;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class BadFaxLines
/*     */     extends TIFFTag
/*     */   {
/*     */     public BadFaxLines() {
/* 144 */       super("BadFaxLines", 326, 24);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static class CleanFaxData
/*     */     extends TIFFTag
/*     */   {
/*     */     public CleanFaxData() {
/* 154 */       super("CleanFaxData", 327, 8);
/*     */ 
/*     */ 
/*     */       
/* 158 */       addValueName(0, "No errors");
/*     */       
/* 160 */       addValueName(1, "Errors corrected");
/*     */       
/* 162 */       addValueName(2, "Errors uncorrected");
/*     */     }
/*     */   }
/*     */   
/*     */   static class ConsecutiveBadFaxLines
/*     */     extends TIFFTag
/*     */   {
/*     */     public ConsecutiveBadFaxLines() {
/* 170 */       super("ConsecutiveBadFaxLines", 328, 24);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void initTags() {
/* 180 */     tags = new ArrayList(42);
/*     */     
/* 182 */     tags.add(new BadFaxLines());
/* 183 */     tags.add(new CleanFaxData());
/* 184 */     tags.add(new ConsecutiveBadFaxLines());
/*     */   }
/*     */   
/*     */   private FaxTIFFTagSet() {
/* 188 */     super(tags);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized FaxTIFFTagSet getInstance() {
/* 197 */     if (theInstance == null) {
/* 198 */       initTags();
/* 199 */       theInstance = new FaxTIFFTagSet();
/* 200 */       tags = null;
/*     */     } 
/* 202 */     return theInstance;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageio/plugins/tiff/FaxTIFFTagSet.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */