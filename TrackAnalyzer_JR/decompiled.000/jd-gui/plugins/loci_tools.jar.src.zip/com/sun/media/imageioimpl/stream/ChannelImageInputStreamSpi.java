/*     */ package com.sun.media.imageioimpl.stream;
/*     */ 
/*     */ import com.sun.media.imageio.stream.FileChannelImageInputStream;
/*     */ import com.sun.media.imageioimpl.common.PackageUtil;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.nio.channels.Channels;
/*     */ import java.nio.channels.FileChannel;
/*     */ import java.nio.channels.ReadableByteChannel;
/*     */ import java.util.Locale;
/*     */ import javax.imageio.spi.ImageInputStreamSpi;
/*     */ import javax.imageio.stream.FileCacheImageInputStream;
/*     */ import javax.imageio.stream.ImageInputStream;
/*     */ import javax.imageio.stream.MemoryCacheImageInputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ChannelImageInputStreamSpi
/*     */   extends ImageInputStreamSpi
/*     */ {
/*     */   public ChannelImageInputStreamSpi() {
/*  99 */     super(PackageUtil.getVendor(), PackageUtil.getVersion(), ReadableByteChannel.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageInputStream createInputStreamInstance(Object input, boolean useCache, File cacheDir) throws IOException {
/* 109 */     if (input == null || !(input instanceof ReadableByteChannel))
/*     */     {
/* 111 */       throw new IllegalArgumentException("XXX");
/*     */     }
/*     */     
/* 114 */     ImageInputStream stream = null;
/*     */     
/* 116 */     if (input instanceof FileChannel) {
/* 117 */       FileChannelImageInputStream fileChannelImageInputStream = new FileChannelImageInputStream((FileChannel)input);
/*     */     } else {
/* 119 */       InputStream inStream = Channels.newInputStream((ReadableByteChannel)input);
/*     */ 
/*     */       
/* 122 */       if (useCache) {
/*     */         try {
/* 124 */           stream = new FileCacheImageInputStream(inStream, cacheDir);
/*     */         }
/* 126 */         catch (IOException e) {}
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 131 */       if (stream == null) {
/* 132 */         stream = new MemoryCacheImageInputStream(inStream);
/*     */       }
/*     */     } 
/*     */     
/* 136 */     return stream;
/*     */   }
/*     */   
/*     */   public String getDescription(Locale locale) {
/* 140 */     return "NIO Channel ImageInputStream";
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/stream/ChannelImageInputStreamSpi.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */