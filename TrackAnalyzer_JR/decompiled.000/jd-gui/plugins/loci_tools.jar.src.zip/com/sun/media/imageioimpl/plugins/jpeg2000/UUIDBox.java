/*     */ package com.sun.media.imageioimpl.plugins.jpeg2000;
/*     */ 
/*     */ import javax.imageio.metadata.IIOInvalidTreeException;
/*     */ import javax.imageio.metadata.IIOMetadataNode;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UUIDBox
/*     */   extends Box
/*     */ {
/*  94 */   private static String[] elementNames = new String[] { "UUID", "Data" };
/*     */   
/*     */   private byte[] uuid;
/*     */   private byte[] udata;
/*     */   
/*     */   public static String[] getElementNames() {
/* 100 */     return elementNames;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UUIDBox(byte[] data) {
/* 109 */     super(8 + data.length, 1970628964, data);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UUIDBox(Node node) throws IIOInvalidTreeException {
/* 116 */     super(node);
/* 117 */     NodeList children = node.getChildNodes();
/*     */     
/* 119 */     for (int i = 0; i < children.getLength(); i++) {
/* 120 */       Node child = children.item(i);
/* 121 */       String name = child.getNodeName();
/*     */       
/* 123 */       if ("UUID".equals(name)) {
/* 124 */         this.uuid = Box.getByteArrayElementValue(child);
/*     */       }
/*     */       
/* 127 */       if ("Data".equals(name)) {
/* 128 */         this.udata = Box.getByteArrayElementValue(child);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void parse(byte[] data) {
/* 135 */     this.uuid = new byte[16];
/* 136 */     System.arraycopy(data, 0, this.uuid, 0, 16);
/* 137 */     this.udata = new byte[data.length - 16];
/* 138 */     System.arraycopy(data, 16, this.udata, 0, this.udata.length);
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] getUUID() {
/* 143 */     return this.uuid;
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] getData() {
/* 148 */     return this.udata;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IIOMetadataNode getNativeNode() {
/* 156 */     return getNativeNodeForSimpleBox();
/*     */   }
/*     */   
/*     */   protected void compose() {
/* 160 */     if (this.data != null)
/*     */       return; 
/* 162 */     this.data = new byte[16 + this.udata.length];
/* 163 */     System.arraycopy(this.uuid, 0, this.data, 0, 16);
/* 164 */     System.arraycopy(this.udata, 0, this.data, 16, this.udata.length);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/jpeg2000/UUIDBox.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */