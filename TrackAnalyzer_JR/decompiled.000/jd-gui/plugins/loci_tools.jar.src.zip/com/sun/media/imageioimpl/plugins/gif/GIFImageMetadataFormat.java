/*     */ package com.sun.media.imageioimpl.plugins.gif;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import javax.imageio.ImageTypeSpecifier;
/*     */ import javax.imageio.metadata.IIOMetadataFormat;
/*     */ import javax.imageio.metadata.IIOMetadataFormatImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GIFImageMetadataFormat
/*     */   extends IIOMetadataFormatImpl
/*     */ {
/*  91 */   private static IIOMetadataFormat instance = null;
/*     */   
/*     */   private GIFImageMetadataFormat() {
/*  94 */     super("javax_imageio_gif_image_1.0", 2);
/*     */ 
/*     */ 
/*     */     
/*  98 */     addElement("ImageDescriptor", "javax_imageio_gif_image_1.0", 0);
/*     */ 
/*     */     
/* 101 */     addAttribute("ImageDescriptor", "imageLeftPosition", 2, true, null, "0", "65535", true, true);
/*     */ 
/*     */     
/* 104 */     addAttribute("ImageDescriptor", "imageTopPosition", 2, true, null, "0", "65535", true, true);
/*     */ 
/*     */     
/* 107 */     addAttribute("ImageDescriptor", "imageWidth", 2, true, null, "1", "65535", true, true);
/*     */ 
/*     */     
/* 110 */     addAttribute("ImageDescriptor", "imageHeight", 2, true, null, "1", "65535", true, true);
/*     */ 
/*     */     
/* 113 */     addBooleanAttribute("ImageDescriptor", "interlaceFlag", false, false);
/*     */ 
/*     */ 
/*     */     
/* 117 */     addElement("LocalColorTable", "javax_imageio_gif_image_1.0", 2, 256);
/*     */ 
/*     */     
/* 120 */     addAttribute("LocalColorTable", "sizeOfLocalColorTable", 2, true, (String)null, Arrays.asList(GIFStreamMetadata.colorTableSizes));
/*     */ 
/*     */     
/* 123 */     addBooleanAttribute("LocalColorTable", "sortFlag", false, false);
/*     */ 
/*     */ 
/*     */     
/* 127 */     addElement("ColorTableEntry", "LocalColorTable", 0);
/*     */     
/* 129 */     addAttribute("ColorTableEntry", "index", 2, true, null, "0", "255", true, true);
/*     */ 
/*     */     
/* 132 */     addAttribute("ColorTableEntry", "red", 2, true, null, "0", "255", true, true);
/*     */ 
/*     */     
/* 135 */     addAttribute("ColorTableEntry", "green", 2, true, null, "0", "255", true, true);
/*     */ 
/*     */     
/* 138 */     addAttribute("ColorTableEntry", "blue", 2, true, null, "0", "255", true, true);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 143 */     addElement("GraphicControlExtension", "javax_imageio_gif_image_1.0", 0);
/*     */ 
/*     */     
/* 146 */     addAttribute("GraphicControlExtension", "disposalMethod", 0, true, (String)null, Arrays.asList(GIFImageMetadata.disposalMethodNames));
/*     */ 
/*     */     
/* 149 */     addBooleanAttribute("GraphicControlExtension", "userInputFlag", false, false);
/*     */     
/* 151 */     addBooleanAttribute("GraphicControlExtension", "transparentColorFlag", false, false);
/*     */     
/* 153 */     addAttribute("GraphicControlExtension", "delayTime", 2, true, null, "0", "65535", true, true);
/*     */ 
/*     */     
/* 156 */     addAttribute("GraphicControlExtension", "transparentColorIndex", 2, true, null, "0", "255", true, true);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 161 */     addElement("PlainTextExtension", "javax_imageio_gif_image_1.0", 0);
/*     */ 
/*     */     
/* 164 */     addAttribute("PlainTextExtension", "textGridLeft", 2, true, null, "0", "65535", true, true);
/*     */ 
/*     */     
/* 167 */     addAttribute("PlainTextExtension", "textGridTop", 2, true, null, "0", "65535", true, true);
/*     */ 
/*     */     
/* 170 */     addAttribute("PlainTextExtension", "textGridWidth", 2, true, null, "1", "65535", true, true);
/*     */ 
/*     */     
/* 173 */     addAttribute("PlainTextExtension", "textGridHeight", 2, true, null, "1", "65535", true, true);
/*     */ 
/*     */     
/* 176 */     addAttribute("PlainTextExtension", "characterCellWidth", 2, true, null, "1", "65535", true, true);
/*     */ 
/*     */     
/* 179 */     addAttribute("PlainTextExtension", "characterCellHeight", 2, true, null, "1", "65535", true, true);
/*     */ 
/*     */     
/* 182 */     addAttribute("PlainTextExtension", "textForegroundColor", 2, true, null, "0", "255", true, true);
/*     */ 
/*     */     
/* 185 */     addAttribute("PlainTextExtension", "textBackgroundColor", 2, true, null, "0", "255", true, true);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 190 */     addElement("ApplicationExtensions", "javax_imageio_gif_image_1.0", 1, 2147483647);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 195 */     addElement("ApplicationExtension", "ApplicationExtensions", 0);
/*     */     
/* 197 */     addAttribute("ApplicationExtension", "applicationID", 0, true, null);
/*     */     
/* 199 */     addAttribute("ApplicationExtension", "authenticationCode", 0, true, null);
/*     */     
/* 201 */     addObjectValue("ApplicationExtension", byte.class, 0, 2147483647);
/*     */ 
/*     */ 
/*     */     
/* 205 */     addElement("CommentExtensions", "javax_imageio_gif_image_1.0", 1, 2147483647);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 210 */     addElement("CommentExtension", "CommentExtensions", 0);
/*     */     
/* 212 */     addAttribute("CommentExtension", "value", 0, true, null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canNodeAppear(String elementName, ImageTypeSpecifier imageType) {
/* 218 */     return true;
/*     */   }
/*     */   
/*     */   public static synchronized IIOMetadataFormat getInstance() {
/* 222 */     if (instance == null) {
/* 223 */       instance = new GIFImageMetadataFormat();
/*     */     }
/* 225 */     return instance;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/gif/GIFImageMetadataFormat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */