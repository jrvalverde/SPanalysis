/*     */ package com.sun.media.imageioimpl.plugins.clib;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import javax.imageio.stream.ImageInputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class InputStreamAdapter
/*     */   extends InputStream
/*     */ {
/*     */   ImageInputStream stream;
/*     */   
/*     */   public InputStreamAdapter(ImageInputStream stream) {
/*  96 */     this.stream = stream;
/*     */   }
/*     */   
/*     */   public void close() throws IOException {
/* 100 */     this.stream.close();
/*     */   }
/*     */   
/*     */   public void mark(int readlimit) {
/* 104 */     this.stream.mark();
/*     */   }
/*     */   
/*     */   public boolean markSupported() {
/* 108 */     return true;
/*     */   }
/*     */   
/*     */   public int read() throws IOException {
/* 112 */     return this.stream.read();
/*     */   }
/*     */   
/*     */   public int read(byte[] b, int off, int len) throws IOException {
/* 116 */     return this.stream.read(b, off, len);
/*     */   }
/*     */   
/*     */   public void reset() throws IOException {
/* 120 */     this.stream.reset();
/*     */   }
/*     */   
/*     */   public long skip(long n) throws IOException {
/* 124 */     return this.stream.skipBytes(n);
/*     */   }
/*     */   
/*     */   public ImageInputStream getWrappedStream() {
/* 128 */     return this.stream;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/clib/InputStreamAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */