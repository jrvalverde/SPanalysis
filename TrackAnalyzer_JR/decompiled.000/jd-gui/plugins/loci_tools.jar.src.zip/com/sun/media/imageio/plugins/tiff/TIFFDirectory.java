/*     */ package com.sun.media.imageio.plugins.tiff;
/*     */ 
/*     */ import com.sun.media.imageioimpl.plugins.tiff.TIFFIFD;
/*     */ import com.sun.media.imageioimpl.plugins.tiff.TIFFImageMetadata;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.TreeMap;
/*     */ import javax.imageio.metadata.IIOInvalidTreeException;
/*     */ import javax.imageio.metadata.IIOMetadata;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TIFFDirectory
/*     */   implements Cloneable
/*     */ {
/*     */   private static final int MAX_LOW_FIELD_TAG_NUM = 532;
/*     */   private List tagSets;
/*     */   private TIFFTag parentTag;
/* 181 */   private TIFFField[] lowFields = new TIFFField[533];
/*     */ 
/*     */   
/* 184 */   private int numLowFields = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 190 */   private Map highFields = new TreeMap<Object, Object>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TIFFDirectory createFromMetadata(IIOMetadata tiffImageMetadata) throws IIOInvalidTreeException {
/*     */     TIFFImageMetadata tim;
/* 217 */     if (tiffImageMetadata == null) {
/* 218 */       throw new IllegalArgumentException("tiffImageMetadata == null");
/*     */     }
/*     */ 
/*     */     
/* 222 */     if (tiffImageMetadata instanceof TIFFImageMetadata) {
/* 223 */       tim = (TIFFImageMetadata)tiffImageMetadata;
/*     */     } else {
/*     */       
/* 226 */       ArrayList<BaselineTIFFTagSet> l = new ArrayList(1);
/* 227 */       l.add(BaselineTIFFTagSet.getInstance());
/* 228 */       tim = new TIFFImageMetadata(l);
/*     */ 
/*     */       
/* 231 */       String formatName = null;
/* 232 */       if ("com_sun_media_imageio_plugins_tiff_image_1.0".equals(tiffImageMetadata.getNativeMetadataFormatName())) {
/*     */         
/* 234 */         formatName = "com_sun_media_imageio_plugins_tiff_image_1.0";
/*     */       } else {
/* 236 */         String[] extraNames = tiffImageMetadata.getExtraMetadataFormatNames();
/*     */         
/* 238 */         if (extraNames != null) {
/* 239 */           for (int i = 0; i < extraNames.length; i++) {
/* 240 */             if ("com_sun_media_imageio_plugins_tiff_image_1.0".equals(extraNames[i])) {
/*     */               
/* 242 */               formatName = extraNames[i];
/*     */               
/*     */               break;
/*     */             } 
/*     */           } 
/*     */         }
/* 248 */         if (formatName == null) {
/* 249 */           if (tiffImageMetadata.isStandardMetadataFormatSupported()) {
/* 250 */             formatName = "javax_imageio_1.0";
/*     */           } else {
/*     */             
/* 253 */             throw new IllegalArgumentException("Parameter does not support required metadata format!");
/*     */           } 
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 260 */       tim.setFromTree(formatName, tiffImageMetadata.getAsTree(formatName));
/*     */     } 
/*     */ 
/*     */     
/* 264 */     return (TIFFDirectory)tim.getRootIFD();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static TIFFIFD getDirectoryAsIFD(TIFFDirectory dir) {
/* 271 */     if (dir instanceof TIFFIFD) {
/* 272 */       return (TIFFIFD)dir;
/*     */     }
/*     */     
/* 275 */     TIFFIFD ifd = new TIFFIFD(Arrays.asList(dir.getTagSets()), dir.getParentTag());
/*     */     
/* 277 */     TIFFField[] fields = dir.getTIFFFields();
/* 278 */     int numFields = fields.length;
/* 279 */     for (int i = 0; i < numFields; i++) {
/* 280 */       TIFFField f = fields[i];
/* 281 */       TIFFTag tag = f.getTag();
/* 282 */       if (tag.isIFDPointer()) {
/* 283 */         TIFFIFD tIFFIFD = getDirectoryAsIFD((TIFFDirectory)f.getData());
/*     */         
/* 285 */         f = new TIFFField(tag, f.getType(), f.getCount(), tIFFIFD);
/*     */       } 
/* 287 */       ifd.addTIFFField(f);
/*     */     } 
/*     */     
/* 290 */     return ifd;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TIFFDirectory(TIFFTagSet[] tagSets, TIFFTag parentTag) {
/* 306 */     if (tagSets == null) {
/* 307 */       throw new IllegalArgumentException("tagSets == null!");
/*     */     }
/* 309 */     this.tagSets = new ArrayList(tagSets.length);
/* 310 */     int numTagSets = tagSets.length;
/* 311 */     for (int i = 0; i < numTagSets; i++) {
/* 312 */       this.tagSets.add(tagSets[i]);
/*     */     }
/* 314 */     this.parentTag = parentTag;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TIFFTagSet[] getTagSets() {
/* 324 */     return (TIFFTagSet[])this.tagSets.toArray((Object[])new TIFFTagSet[this.tagSets.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addTagSet(TIFFTagSet tagSet) {
/* 336 */     if (tagSet == null) {
/* 337 */       throw new IllegalArgumentException("tagSet == null");
/*     */     }
/*     */     
/* 340 */     if (!this.tagSets.contains(tagSet)) {
/* 341 */       this.tagSets.add(tagSet);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeTagSet(TIFFTagSet tagSet) {
/* 354 */     if (tagSet == null) {
/* 355 */       throw new IllegalArgumentException("tagSet == null");
/*     */     }
/*     */     
/* 358 */     if (this.tagSets.contains(tagSet)) {
/* 359 */       this.tagSets.remove(tagSet);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TIFFTag getParentTag() {
/* 371 */     return this.parentTag;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TIFFTag getTag(int tagNumber) {
/* 384 */     return TIFFIFD.getTag(tagNumber, this.tagSets);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNumTIFFFields() {
/* 394 */     return this.numLowFields + this.highFields.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsTIFFField(int tagNumber) {
/* 405 */     return ((tagNumber >= 0 && tagNumber <= 532 && this.lowFields[tagNumber] != null) || this.highFields.containsKey(new Integer(tagNumber)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addTIFFField(TIFFField f) {
/* 417 */     if (f == null) {
/* 418 */       throw new IllegalArgumentException("f == null");
/*     */     }
/* 420 */     int tagNumber = f.getTagNumber();
/* 421 */     if (tagNumber >= 0 && tagNumber <= 532) {
/* 422 */       if (this.lowFields[tagNumber] == null) {
/* 423 */         this.numLowFields++;
/*     */       }
/* 425 */       this.lowFields[tagNumber] = f;
/*     */     } else {
/* 427 */       this.highFields.put(new Integer(tagNumber), f);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TIFFField getTIFFField(int tagNumber) {
/*     */     TIFFField f;
/* 440 */     if (tagNumber >= 0 && tagNumber <= 532) {
/* 441 */       f = this.lowFields[tagNumber];
/*     */     } else {
/* 443 */       f = (TIFFField)this.highFields.get(new Integer(tagNumber));
/*     */     } 
/* 445 */     return f;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeTIFFField(int tagNumber) {
/* 454 */     if (tagNumber >= 0 && tagNumber <= 532) {
/* 455 */       if (this.lowFields[tagNumber] != null) {
/* 456 */         this.numLowFields--;
/* 457 */         this.lowFields[tagNumber] = null;
/*     */       } 
/*     */     } else {
/* 460 */       this.highFields.remove(new Integer(tagNumber));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TIFFField[] getTIFFFields() {
/* 472 */     TIFFField[] fields = new TIFFField[this.numLowFields + this.highFields.size()];
/*     */ 
/*     */     
/* 475 */     int nextIndex = 0;
/* 476 */     for (int i = 0; i <= 532; i++) {
/* 477 */       if (this.lowFields[i] != null) {
/* 478 */         fields[nextIndex++] = this.lowFields[i];
/* 479 */         if (nextIndex == this.numLowFields) {
/*     */           break;
/*     */         }
/*     */       } 
/*     */     } 
/* 484 */     if (!this.highFields.isEmpty()) {
/* 485 */       Iterator keys = this.highFields.keySet().iterator();
/* 486 */       while (keys.hasNext()) {
/* 487 */         fields[nextIndex++] = (TIFFField)this.highFields.get(keys.next());
/*     */       }
/*     */     } 
/*     */     
/* 491 */     return fields;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeTIFFFields() {
/* 498 */     Arrays.fill((Object[])this.lowFields, (Object)null);
/* 499 */     this.numLowFields = 0;
/* 500 */     this.highFields.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IIOMetadata getAsMetadata() {
/* 510 */     return (IIOMetadata)new TIFFImageMetadata(getDirectoryAsIFD(this));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object clone() {
/* 519 */     TIFFDirectory dir = new TIFFDirectory(getTagSets(), getParentTag());
/* 520 */     TIFFField[] fields = getTIFFFields();
/* 521 */     int numFields = fields.length;
/* 522 */     for (int i = 0; i < numFields; i++) {
/* 523 */       dir.addTIFFField(fields[i]);
/*     */     }
/*     */     
/* 526 */     return dir;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageio/plugins/tiff/TIFFDirectory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */