/*     */ package com.sun.media.imageioimpl.plugins.tiff;
/*     */ 
/*     */ import com.sun.media.imageio.plugins.tiff.TIFFColorConverter;
/*     */ import com.sun.media.imageio.plugins.tiff.TIFFField;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TIFFYCbCrColorConverter
/*     */   extends TIFFColorConverter
/*     */ {
/*  92 */   private float LumaRed = 0.299F;
/*  93 */   private float LumaGreen = 0.587F;
/*  94 */   private float LumaBlue = 0.114F;
/*     */   
/*  96 */   private float referenceBlackY = 0.0F;
/*  97 */   private float referenceWhiteY = 255.0F;
/*     */   
/*  99 */   private float referenceBlackCb = 128.0F;
/* 100 */   private float referenceWhiteCb = 255.0F;
/*     */   
/* 102 */   private float referenceBlackCr = 128.0F;
/* 103 */   private float referenceWhiteCr = 255.0F;
/*     */   
/* 105 */   private float codingRangeY = 255.0F;
/* 106 */   private float codingRangeCbCr = 127.0F;
/*     */   
/*     */   public TIFFYCbCrColorConverter(TIFFImageMetadata metadata) {
/* 109 */     TIFFImageMetadata tmetadata = metadata;
/*     */     
/* 111 */     TIFFField f = tmetadata.getTIFFField(529);
/*     */     
/* 113 */     if (f != null && f.getCount() == 3) {
/* 114 */       this.LumaRed = f.getAsFloat(0);
/* 115 */       this.LumaGreen = f.getAsFloat(1);
/* 116 */       this.LumaBlue = f.getAsFloat(2);
/*     */     } 
/*     */     
/* 119 */     f = tmetadata.getTIFFField(532);
/*     */     
/* 121 */     if (f != null && f.getCount() == 6) {
/* 122 */       this.referenceBlackY = f.getAsFloat(0);
/* 123 */       this.referenceWhiteY = f.getAsFloat(1);
/* 124 */       this.referenceBlackCb = f.getAsFloat(2);
/* 125 */       this.referenceWhiteCb = f.getAsFloat(3);
/* 126 */       this.referenceBlackCr = f.getAsFloat(4);
/* 127 */       this.referenceWhiteCr = f.getAsFloat(5);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void fromRGB(float r, float g, float b, float[] result) {
/* 145 */     float Y = this.LumaRed * r + this.LumaGreen * g + this.LumaBlue * b;
/* 146 */     float Cb = (b - Y) / (2.0F - 2.0F * this.LumaBlue);
/* 147 */     float Cr = (r - Y) / (2.0F - 2.0F * this.LumaRed);
/*     */ 
/*     */     
/* 150 */     result[0] = Y * (this.referenceWhiteY - this.referenceBlackY) / this.codingRangeY + this.referenceBlackY;
/*     */     
/* 152 */     result[1] = Cb * (this.referenceWhiteCb - this.referenceBlackCb) / this.codingRangeCbCr + this.referenceBlackCb;
/*     */     
/* 154 */     result[2] = Cr * (this.referenceWhiteCr - this.referenceBlackCr) / this.codingRangeCbCr + this.referenceBlackCr;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void toRGB(float x0, float x1, float x2, float[] rgb) {
/* 160 */     float Y = (x0 - this.referenceBlackY) * this.codingRangeY / (this.referenceWhiteY - this.referenceBlackY);
/*     */     
/* 162 */     float Cb = (x1 - this.referenceBlackCb) * this.codingRangeCbCr / (this.referenceWhiteCb - this.referenceBlackCb);
/*     */     
/* 164 */     float Cr = (x2 - this.referenceBlackCr) * this.codingRangeCbCr / (this.referenceWhiteCr - this.referenceBlackCr);
/*     */ 
/*     */ 
/*     */     
/* 168 */     rgb[0] = Cr * (2.0F - 2.0F * this.LumaRed) + Y;
/* 169 */     rgb[2] = Cb * (2.0F - 2.0F * this.LumaBlue) + Y;
/* 170 */     rgb[1] = (Y - this.LumaBlue * rgb[2] - this.LumaRed * rgb[0]) / this.LumaGreen;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/tiff/TIFFYCbCrColorConverter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */