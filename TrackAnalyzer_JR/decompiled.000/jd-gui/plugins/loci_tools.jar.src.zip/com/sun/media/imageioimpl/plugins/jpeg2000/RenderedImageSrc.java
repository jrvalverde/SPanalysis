/*      */ package com.sun.media.imageioimpl.plugins.jpeg2000;
/*      */ 
/*      */ import com.sun.media.imageioimpl.common.ImageUtil;
/*      */ import java.awt.Point;
/*      */ import java.awt.Rectangle;
/*      */ import java.awt.image.ColorModel;
/*      */ import java.awt.image.Raster;
/*      */ import java.awt.image.RenderedImage;
/*      */ import java.awt.image.SampleModel;
/*      */ import java.awt.image.WritableRaster;
/*      */ import jj2000.j2k.image.BlkImgDataSrc;
/*      */ import jj2000.j2k.image.DataBlk;
/*      */ import jj2000.j2k.image.DataBlkInt;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class RenderedImageSrc
/*      */   implements BlkImgDataSrc
/*      */ {
/*      */   private int w;
/*      */   private int h;
/*      */   int tileWidth;
/*      */   int tileHeight;
/*      */   int tileXOffset;
/*      */   int tileYOffset;
/*      */   int scaleX;
/*      */   int scaleY;
/*      */   int xOffset;
/*      */   int yOffset;
/*  123 */   int[] sourceBands = null;
/*      */ 
/*      */   
/*      */   int minX;
/*      */ 
/*      */   
/*      */   int minY;
/*      */ 
/*      */   
/*      */   private int nc;
/*      */   
/*      */   private int rb;
/*      */   
/*  136 */   private int[][] barr = (int[][])null;
/*      */ 
/*      */   
/*  139 */   private DataBlkInt dbi = new DataBlkInt();
/*      */ 
/*      */   
/*      */   private byte[] buf;
/*      */ 
/*      */   
/*      */   private DataBlkInt intBlk;
/*      */ 
/*      */   
/*      */   private RenderedImage src;
/*      */ 
/*      */   
/*      */   private J2KImageWriteParamJava param;
/*      */   
/*      */   private Raster raster;
/*      */   
/*      */   private Raster aTile;
/*      */   
/*  157 */   private Point co = new Point();
/*      */   
/*  159 */   private int dcOffset = 0;
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isBinary = false;
/*      */ 
/*      */   
/*      */   private Rectangle destinationRegion;
/*      */ 
/*      */   
/*      */   private Rectangle sourceRegion;
/*      */ 
/*      */   
/*      */   private ColorModel cm;
/*      */ 
/*      */   
/*      */   private SampleModel sm;
/*      */ 
/*      */   
/*      */   private boolean noTransform = true;
/*      */ 
/*      */   
/*      */   private boolean noSubband = true;
/*      */ 
/*      */   
/*      */   private J2KImageWriter writer;
/*      */ 
/*      */   
/*      */   private boolean inputIsRaster = false;
/*      */ 
/*      */ 
/*      */   
/*      */   public RenderedImageSrc(Raster raster, J2KImageWriteParamJava param, J2KImageWriter writer) {
/*  192 */     this.raster = raster;
/*  193 */     this.param = param;
/*  194 */     this.writer = writer;
/*  195 */     this.inputIsRaster = true;
/*      */     
/*  197 */     this.sourceRegion = param.getSourceRegion();
/*      */     
/*  199 */     if (this.sourceRegion == null) {
/*  200 */       this.sourceRegion = new Rectangle(raster.getMinX(), raster.getMinY(), raster.getWidth(), raster.getHeight());
/*      */     } else {
/*      */       
/*  203 */       this.sourceRegion = this.sourceRegion.intersection(raster.getBounds());
/*      */     } 
/*  205 */     if (this.sourceRegion.isEmpty()) {
/*  206 */       throw new RuntimeException(I18N.getString("J2KImageWriterCodecLib0"));
/*      */     }
/*  208 */     this.sm = raster.getSampleModel();
/*  209 */     getFromParam();
/*  210 */     setSampleModelAndMore();
/*  211 */     setTile(0, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RenderedImageSrc(RenderedImage src, J2KImageWriteParamJava param, J2KImageWriter writer) {
/*  227 */     this.src = src;
/*  228 */     this.param = param;
/*  229 */     this.writer = writer;
/*      */     
/*  231 */     this.sourceRegion = param.getSourceRegion();
/*      */     
/*  233 */     if (this.sourceRegion == null) {
/*  234 */       this.sourceRegion = new Rectangle(src.getMinX(), src.getMinY(), src.getWidth(), src.getHeight());
/*      */     } else {
/*      */       
/*  237 */       this.sourceRegion = this.sourceRegion.intersection(new Rectangle(src.getMinX(), src.getMinY(), src.getWidth(), src.getHeight()));
/*      */     } 
/*      */ 
/*      */     
/*  241 */     if (this.sourceRegion.isEmpty()) {
/*  242 */       throw new RuntimeException(I18N.getString("J2KImageWriterCodecLib0"));
/*      */     }
/*  244 */     this.sm = src.getSampleModel();
/*  245 */     this.cm = src.getColorModel();
/*  246 */     getFromParam();
/*  247 */     setSampleModelAndMore();
/*      */   }
/*      */   
/*      */   private void getFromParam() {
/*      */     try {
/*  252 */       this.tileWidth = this.param.getTileWidth();
/*  253 */       this.tileHeight = this.param.getTileHeight();
/*  254 */       this.tileXOffset = this.param.getTileGridXOffset();
/*  255 */       this.tileYOffset = this.param.getTileGridYOffset();
/*  256 */     } catch (IllegalStateException e) {
/*  257 */       this.param.setTilingMode(2);
/*  258 */       if (this.inputIsRaster) {
/*  259 */         this.param.setTiling(this.raster.getWidth(), this.raster.getHeight(), this.raster.getMinX(), this.raster.getMinY());
/*      */       } else {
/*      */         
/*  262 */         this.param.setTiling(this.src.getWidth(), this.src.getHeight(), this.src.getMinX(), this.src.getMinY());
/*      */       } 
/*      */       
/*  265 */       this.tileWidth = this.param.getTileWidth();
/*  266 */       this.tileHeight = this.param.getTileHeight();
/*  267 */       this.tileXOffset = this.param.getTileGridXOffset();
/*  268 */       this.tileYOffset = this.param.getTileGridYOffset();
/*      */     } 
/*      */     
/*  271 */     this.scaleX = this.param.getSourceXSubsampling();
/*  272 */     this.scaleY = this.param.getSourceYSubsampling();
/*  273 */     this.xOffset = this.param.getSubsamplingXOffset();
/*  274 */     this.yOffset = this.param.getSubsamplingYOffset();
/*      */     
/*  276 */     this.sourceRegion.translate(this.xOffset, this.yOffset);
/*  277 */     this.sourceRegion.width -= this.xOffset;
/*  278 */     this.sourceRegion.height -= this.yOffset;
/*      */     
/*  280 */     this.xOffset = this.sourceRegion.x % this.scaleX;
/*  281 */     this.yOffset = this.sourceRegion.y % this.scaleY;
/*      */     
/*  283 */     this.minX = this.sourceRegion.x / this.scaleX;
/*  284 */     this.minY = this.sourceRegion.y / this.scaleY;
/*      */     
/*  286 */     this.w = (this.sourceRegion.width + this.scaleX - 1) / this.scaleX;
/*  287 */     this.h = (this.sourceRegion.height + this.scaleY - 1) / this.scaleY;
/*      */     
/*  289 */     this.tileXOffset += (this.minX - this.tileXOffset) / this.tileWidth * this.tileWidth;
/*  290 */     this.tileYOffset += (this.minY - this.tileYOffset) / this.tileHeight * this.tileHeight;
/*      */     
/*  292 */     this.destinationRegion = new Rectangle(this.minX, this.minY, this.w, this.h);
/*      */     
/*  294 */     if (!this.destinationRegion.equals(this.sourceRegion) || this.tileWidth != this.sm.getWidth() || this.tileHeight != this.sm.getHeight() || (!this.inputIsRaster && (this.tileXOffset != this.src.getTileGridXOffset() || this.tileYOffset != this.src.getTileGridYOffset())) || (this.inputIsRaster && (this.tileXOffset != this.raster.getMinX() || this.tileYOffset != this.raster.getMinY())))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  303 */       this.noTransform = false;
/*      */     }
/*      */   }
/*      */   
/*      */   private void setSampleModelAndMore() {
/*  308 */     this.nc = this.sm.getNumBands();
/*  309 */     this.sourceBands = this.param.getSourceBands();
/*  310 */     if (this.sourceBands != null) {
/*  311 */       this.sm = this.sm.createSubsetSampleModel(this.sourceBands);
/*  312 */       this.noSubband = false;
/*      */     } else {
/*  314 */       this.sourceBands = new int[this.nc];
/*  315 */       for (int i = 0; i < this.nc; i++) {
/*  316 */         this.sourceBands[i] = i;
/*      */       }
/*      */     } 
/*  319 */     this.sm = this.sm.createCompatibleSampleModel(this.tileWidth, this.tileHeight);
/*  320 */     this.nc = this.sm.getNumBands();
/*  321 */     this.isBinary = ImageUtil.isBinary(this.sm);
/*      */     
/*  323 */     if (this.cm != null) {
/*      */       
/*  325 */       this.rb = this.cm.getComponentSize(0);
/*  326 */       for (int i = 1; i < this.cm.getNumComponents(); i++) {
/*  327 */         if (this.rb < this.cm.getComponentSize(i))
/*  328 */           this.rb = this.cm.getComponentSize(i); 
/*      */       } 
/*      */     } else {
/*  331 */       this.rb = this.sm.getSampleSize(0);
/*  332 */       for (int i = 1; i < this.sm.getNumBands(); i++) {
/*  333 */         if (this.rb < this.sm.getSampleSize(i))
/*  334 */           this.rb = this.sm.getSampleSize(i); 
/*      */       } 
/*      */     } 
/*  337 */     if (!isOrigSigned(0) && this.rb > 1)
/*      */     {
/*  339 */       this.dcOffset = 1 << this.rb - 1;
/*      */     }
/*      */   }
/*      */   
/*      */   public int getTilePartULX() {
/*  344 */     return this.tileXOffset;
/*      */   }
/*      */   
/*      */   public int getTilePartULY() {
/*  348 */     return this.tileYOffset;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getTileWidth() {
/*  357 */     int width = this.tileWidth;
/*  358 */     int maxX = getImgULX() + getImgWidth();
/*  359 */     int x = this.co.x * this.tileWidth + this.tileXOffset;
/*  360 */     if (x + this.tileWidth >= maxX)
/*  361 */       width = maxX - x; 
/*  362 */     return width;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getTileHeight() {
/*  370 */     int height = this.tileHeight;
/*  371 */     int maxY = getImgULY() + getImgHeight();
/*  372 */     int y = this.co.y * this.tileHeight + this.tileYOffset;
/*  373 */     if (y + this.tileHeight >= maxY) {
/*  374 */       height = maxY - y;
/*      */     }
/*  376 */     return height;
/*      */   }
/*      */   
/*      */   public int getNomTileWidth() {
/*  380 */     return this.tileWidth;
/*      */   }
/*      */   
/*      */   public int getNomTileHeight() {
/*  384 */     return this.tileHeight;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getImgWidth() {
/*  395 */     return this.w;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getImgHeight() {
/*  406 */     return this.h;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getNumComps() {
/*  416 */     return this.nc;
/*      */   }
/*      */   
/*      */   public int getTileGridXOffset() {
/*  420 */     return this.param.getTileGridXOffset();
/*      */   }
/*      */   
/*      */   public int getTileGridYOffset() {
/*  424 */     return this.param.getTileGridYOffset();
/*      */   }
/*      */   
/*      */   public int getTileCompHeight(int t, int c) {
/*  428 */     return this.tileHeight;
/*      */   }
/*      */   
/*      */   public int getTileCompWidth(int t, int c) {
/*  432 */     return this.tileWidth;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getCompSubsX(int c) {
/*  448 */     return 1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getCompSubsY(int c) {
/*  464 */     return 1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getCompWidth(int n) {
/*  479 */     return this.w;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getCompHeight(int c) {
/*  494 */     return this.h;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getCompImgWidth(int c) {
/*  508 */     return this.w;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getCompImgHeight(int c) {
/*  522 */     return this.h;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTile(int x, int y) {
/*  533 */     if (x >= getNumXTiles()) {
/*  534 */       y += x / getNumXTiles();
/*  535 */       x %= getNumXTiles();
/*      */     } 
/*  537 */     this.co.x = x;
/*  538 */     this.co.y = y;
/*  539 */     this.aTile = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void nextTile() {
/*  547 */     this.co.x++;
/*  548 */     if (this.co.x >= getNumXTiles()) {
/*  549 */       this.co.x = 0;
/*  550 */       this.co.y++;
/*      */     } 
/*  552 */     setTile(this.co.x, this.co.y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Point getTile(Point co) {
/*  565 */     if (co != null) {
/*  566 */       return co;
/*      */     }
/*  568 */     return new Point(0, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getTileIdx() {
/*  578 */     return getNumXTiles() * this.co.y + this.co.x;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Point getTileOff(Point p, int c) {
/*  598 */     if (p != null) {
/*  599 */       p.x = this.co.x * this.tileWidth + this.tileXOffset;
/*  600 */       p.y = this.co.y * this.tileHeight + this.tileYOffset;
/*  601 */       return this.co;
/*      */     } 
/*  603 */     return new Point(this.co.x * this.tileWidth + this.tileXOffset, this.co.y * this.tileHeight + this.tileYOffset);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getCompULX(int c) {
/*  619 */     return this.raster.getMinX();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getCompULY(int c) {
/*  634 */     return this.raster.getMinY();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getImgULX() {
/*  645 */     return this.destinationRegion.x;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getImgULY() {
/*  656 */     return this.destinationRegion.y;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Point getNumTiles(Point co) {
/*  670 */     if (co != null) {
/*  671 */       co.x = getNumXTiles();
/*  672 */       co.y = getNumYTiles();
/*  673 */       return co;
/*      */     } 
/*      */     
/*  676 */     return new Point(getNumXTiles(), getNumYTiles());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getNumTiles() {
/*  687 */     return getNumXTiles() * getNumYTiles();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getNomRangeBits(int c) {
/*  709 */     return this.rb;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getFixedPoint(int c) {
/*  724 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final DataBlk getInternCompData(DataBlk blk, int c) {
/*      */     DataBlkInt dataBlkInt;
/*  775 */     if (this.writer != null && this.writer.getAbortRequest()) {
/*  776 */       throw new RuntimeException(J2KImageWriter.WRITE_ABORTED);
/*      */     }
/*  778 */     if (this.barr == null) {
/*  779 */       this.barr = new int[this.nc][];
/*      */     }
/*      */     
/*  782 */     if (blk.getDataType() != 3) {
/*  783 */       if (this.intBlk == null) {
/*  784 */         this.intBlk = new DataBlkInt(blk.ulx, blk.uly, blk.w, blk.h);
/*      */       } else {
/*  786 */         this.intBlk.ulx = blk.ulx;
/*  787 */         this.intBlk.uly = blk.uly;
/*  788 */         this.intBlk.w = blk.w;
/*  789 */         this.intBlk.h = blk.h;
/*      */       } 
/*  791 */       dataBlkInt = this.intBlk;
/*      */     } 
/*      */     
/*  794 */     float percentage = (getTileIdx() + (((DataBlk)dataBlkInt).uly + 1.0F) / ((DataBlk)dataBlkInt).h) / getNumTiles();
/*      */     
/*  796 */     this.writer.processImageProgressWrapper(percentage * 100.0F);
/*      */ 
/*      */ 
/*      */     
/*  800 */     if (this.barr[c] == null || this.dbi.ulx > ((DataBlk)dataBlkInt).ulx || this.dbi.uly > ((DataBlk)dataBlkInt).uly || this.dbi.ulx + this.dbi.w < ((DataBlk)dataBlkInt).ulx + ((DataBlk)dataBlkInt).w || this.dbi.uly + this.dbi.h < ((DataBlk)dataBlkInt).uly + ((DataBlk)dataBlkInt).h) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  807 */       if (this.barr[c] == null || (this.barr[c]).length < ((DataBlk)dataBlkInt).w * ((DataBlk)dataBlkInt).h) {
/*  808 */         this.barr[c] = new int[((DataBlk)dataBlkInt).w * ((DataBlk)dataBlkInt).h];
/*      */       }
/*  810 */       dataBlkInt.setData(this.barr[c]);
/*      */       int i;
/*  812 */       for (i = (c + 1) % this.nc; i != c; i = (i + 1) % this.nc) {
/*  813 */         if (this.barr[i] == null || (this.barr[i]).length < ((DataBlk)dataBlkInt).w * ((DataBlk)dataBlkInt).h) {
/*  814 */           this.barr[i] = new int[((DataBlk)dataBlkInt).w * ((DataBlk)dataBlkInt).h];
/*      */         }
/*      */       } 
/*      */       
/*  818 */       this.dbi.ulx = ((DataBlk)dataBlkInt).ulx;
/*  819 */       this.dbi.uly = ((DataBlk)dataBlkInt).uly;
/*  820 */       this.dbi.w = ((DataBlk)dataBlkInt).w;
/*  821 */       this.dbi.h = ((DataBlk)dataBlkInt).h;
/*      */ 
/*      */       
/*  824 */       if (this.aTile == null) {
/*  825 */         this.aTile = getTile(this.co.x, this.co.y);
/*  826 */         Rectangle temp = this.aTile.getBounds();
/*  827 */         this.aTile = this.aTile.createTranslatedChild(temp.x - this.minX, temp.y - this.minY);
/*      */       } 
/*      */ 
/*      */       
/*  831 */       for (i = 0; i < this.nc; i++) {
/*  832 */         this.aTile.getSamples(((DataBlk)dataBlkInt).ulx, ((DataBlk)dataBlkInt).uly, ((DataBlk)dataBlkInt).w, ((DataBlk)dataBlkInt).h, i, this.barr[i]);
/*  833 */         for (int k = 0; k < (this.barr[i]).length; k++) {
/*  834 */           this.barr[i][k] = this.barr[i][k] - this.dcOffset;
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/*  839 */       dataBlkInt.setData(this.barr[c]);
/*  840 */       ((DataBlk)dataBlkInt).offset = 0;
/*  841 */       ((DataBlk)dataBlkInt).scanw = ((DataBlk)dataBlkInt).w;
/*      */     } else {
/*  843 */       dataBlkInt.setData(this.barr[c]);
/*  844 */       ((DataBlk)dataBlkInt).offset = (((DataBlk)dataBlkInt).ulx - this.dbi.ulx) * this.dbi.w + ((DataBlk)dataBlkInt).ulx - this.dbi.ulx;
/*  845 */       ((DataBlk)dataBlkInt).scanw = this.dbi.scanw;
/*      */     } 
/*      */ 
/*      */     
/*  849 */     ((DataBlk)dataBlkInt).progressive = false;
/*  850 */     return (DataBlk)dataBlkInt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final DataBlk getCompData(DataBlk blk, int c) {
/*      */     DataBlkInt dataBlkInt;
/*  901 */     if (blk.getDataType() != 3) {
/*  902 */       DataBlkInt tmp = new DataBlkInt(blk.ulx, blk.uly, blk.w, blk.h);
/*  903 */       dataBlkInt = tmp;
/*      */     } 
/*      */     
/*  906 */     int[] bakarr = (int[])dataBlkInt.getData();
/*      */     
/*  908 */     int ulx = ((DataBlk)dataBlkInt).ulx;
/*  909 */     int uly = ((DataBlk)dataBlkInt).uly;
/*  910 */     int w = ((DataBlk)dataBlkInt).w;
/*  911 */     int h = ((DataBlk)dataBlkInt).h;
/*      */     
/*  913 */     dataBlkInt.setData(null);
/*  914 */     getInternCompData((DataBlk)dataBlkInt, c);
/*      */     
/*  916 */     if (bakarr == null) {
/*  917 */       bakarr = new int[w * h];
/*      */     }
/*  919 */     if (((DataBlk)dataBlkInt).offset == 0 && ((DataBlk)dataBlkInt).scanw == w) {
/*      */       
/*  921 */       System.arraycopy(dataBlkInt.getData(), 0, bakarr, 0, w * h);
/*      */     } else {
/*      */       
/*  924 */       for (int i = h - 1; i >= 0; i--) {
/*  925 */         System.arraycopy(dataBlkInt.getData(), ((DataBlk)dataBlkInt).offset + i * ((DataBlk)dataBlkInt).scanw, bakarr, i * w, w);
/*      */       }
/*      */     } 
/*      */     
/*  929 */     dataBlkInt.setData(bakarr);
/*  930 */     ((DataBlk)dataBlkInt).offset = 0;
/*  931 */     ((DataBlk)dataBlkInt).scanw = ((DataBlk)dataBlkInt).w;
/*  932 */     return (DataBlk)dataBlkInt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isOrigSigned(int c) {
/*  945 */     if (this.isBinary) return true;
/*      */ 
/*      */     
/*  948 */     SampleModel sm = null;
/*  949 */     if (this.inputIsRaster) {
/*  950 */       sm = this.raster.getSampleModel();
/*      */     } else {
/*  952 */       sm = this.src.getSampleModel();
/*      */     } 
/*  954 */     if (sm.getDataType() == 1 || sm.getDataType() == 0)
/*      */     {
/*  956 */       return false; } 
/*  957 */     return true;
/*      */   }
/*      */   
/*      */   private int getNumXTiles() {
/*  961 */     int x = this.destinationRegion.x;
/*  962 */     int tx = this.tileXOffset;
/*  963 */     int tw = this.tileWidth;
/*  964 */     return ToTile(x + this.destinationRegion.width - 1, tx, tw) - ToTile(x, tx, tw) + 1;
/*      */   }
/*      */   
/*      */   private int getNumYTiles() {
/*  968 */     int y = this.destinationRegion.y;
/*  969 */     int ty = this.tileYOffset;
/*  970 */     int th = this.tileHeight;
/*  971 */     return ToTile(y + this.destinationRegion.height - 1, ty, th) - ToTile(y, ty, th) + 1;
/*      */   }
/*      */   
/*      */   private static int ToTile(int pos, int tileOffset, int tileSize) {
/*  975 */     pos -= tileOffset;
/*  976 */     if (pos < 0) {
/*  977 */       pos += 1 - tileSize;
/*      */     }
/*  979 */     return pos / tileSize;
/*      */   }
/*      */   
/*      */   private Raster getTile(int tileX, int tileY) {
/*  983 */     int sx = this.tileXOffset + tileX * this.tileWidth;
/*  984 */     int sy = this.tileYOffset + tileY * this.tileHeight;
/*  985 */     tileX += this.tileXOffset / this.tileWidth;
/*  986 */     tileY += this.tileYOffset / this.tileHeight;
/*      */     
/*  988 */     if (this.inputIsRaster) {
/*  989 */       if (this.noTransform) {
/*  990 */         return this.raster.createChild(sx, sy, getTileWidth(), getTileHeight(), sx, sy, this.sourceBands);
/*      */       }
/*      */ 
/*      */       
/*  994 */       WritableRaster writableRaster = Raster.createWritableRaster(this.sm, new Point(sx, sy));
/*      */ 
/*      */       
/*  997 */       int i = mapToSourceX(sx);
/*  998 */       int k = mapToSourceY(sy);
/*      */       
/* 1000 */       int m = this.raster.getMinY();
/* 1001 */       int n = this.raster.getMinY() + this.raster.getHeight();
/*      */       
/* 1003 */       int cTileWidth = getTileWidth();
/* 1004 */       for (int i1 = 0; i1 < getTileHeight(); i1++, sy++, k += this.scaleY) {
/* 1005 */         if (k >= m && k < n) {
/*      */           
/* 1007 */           Raster source = this.raster.createChild(i, k, (cTileWidth - 1) * this.scaleX + 1, 1, i, k, null);
/*      */           
/* 1009 */           int tempX = sx; int offset;
/* 1010 */           for (int i2 = 0; i2 < cTileWidth; i2++, tempX++, offset += this.scaleX) {
/* 1011 */             for (int i3 = 0; i3 < this.nc; i3++) {
/* 1012 */               int p = source.getSample(offset, k, this.sourceBands[i3]);
/* 1013 */               writableRaster.setSample(tempX, sy, i3, p);
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/* 1018 */       return writableRaster;
/*      */     } 
/*      */     
/* 1021 */     if (this.noTransform) {
/* 1022 */       Raster raster = this.src.getTile(tileX, tileY);
/* 1023 */       if (this.noSubband) {
/* 1024 */         return raster;
/*      */       }
/* 1026 */       return raster.createChild(sx, sy, this.tileWidth, this.tileHeight, sx, sy, this.sourceBands);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1031 */     WritableRaster ras = Raster.createWritableRaster(this.sm, new Point(sx, sy));
/*      */     
/* 1033 */     int x = mapToSourceX(sx);
/* 1034 */     int y = mapToSourceY(sy);
/*      */     
/* 1036 */     int minY = this.src.getMinY();
/* 1037 */     int maxY = this.src.getMinY() + this.src.getHeight();
/* 1038 */     int length = this.tileWidth * this.scaleX;
/*      */     
/* 1040 */     if (x + length >= this.src.getWidth())
/* 1041 */       length = this.src.getWidth() - x; 
/* 1042 */     int dLength = (length + this.scaleX - 1) / this.scaleX;
/*      */     
/* 1044 */     for (int j = 0; j < this.tileHeight; j++, sy++, y += this.scaleY) {
/* 1045 */       if (y >= minY && y < maxY) {
/*      */ 
/*      */         
/* 1048 */         Raster source = this.src.getData(new Rectangle(x, y, length, 1));
/*      */         
/* 1050 */         int tempX = sx; int offset;
/* 1051 */         for (int i = 0; i < dLength; i++, tempX++, offset += this.scaleX) {
/*      */           
/* 1053 */           for (int k = 0; k < this.nc; k++) {
/* 1054 */             int p = source.getSample(offset, y, this.sourceBands[k]);
/*      */             
/* 1056 */             ras.setSample(tempX, sy, k, p);
/*      */           } 
/*      */         } 
/*      */       } 
/* 1060 */     }  return ras;
/*      */   }
/*      */ 
/*      */   
/*      */   private int mapToSourceX(int x) {
/* 1065 */     return x * this.scaleX + this.xOffset;
/*      */   }
/*      */   
/*      */   private int mapToSourceY(int y) {
/* 1069 */     return y * this.scaleY + this.yOffset;
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/jpeg2000/RenderedImageSrc.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */