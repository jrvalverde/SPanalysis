/*     */ package com.sun.media.imageioimpl.plugins.bmp;
/*     */ 
/*     */ import com.sun.media.imageioimpl.common.ImageUtil;
/*     */ import com.sun.media.imageioimpl.common.PackageUtil;
/*     */ import java.awt.image.SampleModel;
/*     */ import java.util.Locale;
/*     */ import javax.imageio.IIOException;
/*     */ import javax.imageio.ImageTypeSpecifier;
/*     */ import javax.imageio.ImageWriter;
/*     */ import javax.imageio.spi.ImageWriterSpi;
/*     */ import javax.imageio.spi.ServiceRegistry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BMPImageWriterSpi
/*     */   extends ImageWriterSpi
/*     */ {
/* 100 */   private static String[] readerSpiNames = new String[] { "com.sun.media.imageioimpl.plugins.bmp.BMPImageReaderSpi" };
/*     */   
/* 102 */   private static String[] formatNames = new String[] { "bmp", "BMP" };
/* 103 */   private static String[] extensions = new String[] { "bmp" };
/* 104 */   private static String[] mimeTypes = new String[] { "image/bmp", "image/x-bmp", "image/x-windows-bmp" };
/*     */   
/*     */   private boolean registered = false;
/*     */ 
/*     */   
/*     */   public BMPImageWriterSpi() {
/* 110 */     super(PackageUtil.getVendor(), PackageUtil.getVersion(), formatNames, extensions, mimeTypes, "com.sun.media.imageioimpl.plugins.bmp.BMPImageWriter", STANDARD_OUTPUT_TYPE, readerSpiNames, false, null, null, null, null, true, "com_sun_media_imageio_plugins_bmp_image_1.0", "com.sun.media.imageioimpl.plugins.bmp.BMPMetadataFormat", null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDescription(Locale locale) {
/* 127 */     String desc = PackageUtil.getSpecificationTitle() + " BMP Image Writer";
/*     */     
/* 129 */     return desc;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onRegistration(ServiceRegistry registry, Class category) {
/* 134 */     if (this.registered) {
/*     */       return;
/*     */     }
/*     */     
/* 138 */     this.registered = true;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 143 */     ImageUtil.processOnRegistration(registry, category, "BMP", this, 8, 7);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canEncodeImage(ImageTypeSpecifier type) {
/* 148 */     int dataType = type.getSampleModel().getDataType();
/* 149 */     if (dataType < 0 || dataType > 3) {
/* 150 */       return false;
/*     */     }
/* 152 */     SampleModel sm = type.getSampleModel();
/* 153 */     int numBands = sm.getNumBands();
/* 154 */     if (numBands != 1 && numBands != 3) {
/* 155 */       return false;
/*     */     }
/* 157 */     if (numBands == 1 && dataType != 0) {
/* 158 */       return false;
/*     */     }
/* 160 */     if (dataType > 0 && !(sm instanceof java.awt.image.SinglePixelPackedSampleModel))
/*     */     {
/* 162 */       return false;
/*     */     }
/* 164 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public ImageWriter createWriterInstance(Object extension) throws IIOException {
/* 169 */     return new BMPImageWriter(this);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/bmp/BMPImageWriterSpi.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */