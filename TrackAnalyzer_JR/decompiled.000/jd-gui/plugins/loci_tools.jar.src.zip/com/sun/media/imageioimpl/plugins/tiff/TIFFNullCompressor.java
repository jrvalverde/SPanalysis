/*     */ package com.sun.media.imageioimpl.plugins.tiff;
/*     */ 
/*     */ import com.sun.media.imageio.plugins.tiff.TIFFCompressor;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TIFFNullCompressor
/*     */   extends TIFFCompressor
/*     */ {
/*     */   public TIFFNullCompressor() {
/*  93 */     super("", 1, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int encode(byte[] b, int off, int width, int height, int[] bitsPerSample, int scanlineStride) throws IOException {
/* 100 */     int bitsPerPixel = 0;
/* 101 */     for (int i = 0; i < bitsPerSample.length; i++) {
/* 102 */       bitsPerPixel += bitsPerSample[i];
/*     */     }
/*     */     
/* 105 */     int bytesPerRow = (bitsPerPixel * width + 7) / 8;
/* 106 */     int numBytes = height * bytesPerRow;
/*     */     
/* 108 */     if (bytesPerRow == scanlineStride) {
/* 109 */       this.stream.write(b, off, numBytes);
/*     */     } else {
/* 111 */       for (int row = 0; row < height; row++) {
/* 112 */         this.stream.write(b, off, bytesPerRow);
/* 113 */         off += scanlineStride;
/*     */       } 
/*     */     } 
/*     */     
/* 117 */     return numBytes;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/tiff/TIFFNullCompressor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */