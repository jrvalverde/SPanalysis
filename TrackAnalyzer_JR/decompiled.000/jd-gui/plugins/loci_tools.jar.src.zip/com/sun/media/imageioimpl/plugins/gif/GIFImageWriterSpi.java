/*     */ package com.sun.media.imageioimpl.plugins.gif;
/*     */ 
/*     */ import com.sun.media.imageioimpl.common.ImageUtil;
/*     */ import com.sun.media.imageioimpl.common.PackageUtil;
/*     */ import com.sun.media.imageioimpl.common.PaletteBuilder;
/*     */ import java.awt.image.ColorModel;
/*     */ import java.awt.image.SampleModel;
/*     */ import java.util.Locale;
/*     */ import javax.imageio.ImageTypeSpecifier;
/*     */ import javax.imageio.ImageWriter;
/*     */ import javax.imageio.spi.ImageWriterSpi;
/*     */ import javax.imageio.spi.ServiceRegistry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GIFImageWriterSpi
/*     */   extends ImageWriterSpi
/*     */ {
/*     */   private static final String vendorName = "Sun Microsystems, Inc.";
/*     */   private static final String version = "1.0";
/* 101 */   private static final String[] names = new String[] { "gif", "GIF" };
/*     */   
/* 103 */   private static final String[] suffixes = new String[] { "gif" };
/*     */   
/* 105 */   private static final String[] MIMETypes = new String[] { "image/gif" };
/*     */ 
/*     */   
/*     */   private static final String writerClassName = "com.sun.media.imageioimpl.plugins.gif.GIFImageWriter";
/*     */   
/* 110 */   private static final String[] readerSpiNames = new String[] { "com.sun.imageio.plugins.gif.GIFImageReaderSpi" };
/*     */ 
/*     */   
/*     */   private boolean registered = false;
/*     */ 
/*     */   
/*     */   public GIFImageWriterSpi() {
/* 117 */     super("Sun Microsystems, Inc.", "1.0", names, suffixes, MIMETypes, "com.sun.media.imageioimpl.plugins.gif.GIFImageWriter", STANDARD_OUTPUT_TYPE, readerSpiNames, true, "javax_imageio_gif_stream_1.0", "com.sun.media.imageioimpl.plugins.gif.GIFStreamMetadataFormat", null, null, true, "javax_imageio_gif_image_1.0", "com.sun.media.imageioimpl.plugins.gif.GIFStreamMetadataFormat", null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canEncodeImage(ImageTypeSpecifier type) {
/* 137 */     if (type == null) {
/* 138 */       throw new IllegalArgumentException("type == null!");
/*     */     }
/*     */     
/* 141 */     SampleModel sm = type.getSampleModel();
/* 142 */     ColorModel cm = type.getColorModel();
/*     */     
/* 144 */     boolean canEncode = (sm.getNumBands() == 1 && sm.getSampleSize(0) <= 8 && sm.getWidth() <= 65535 && sm.getHeight() <= 65535 && (cm == null || cm.getComponentSize()[0] <= 8));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 150 */     if (canEncode) {
/* 151 */       return true;
/*     */     }
/* 153 */     return PaletteBuilder.canCreatePalette(type);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDescription(Locale locale) {
/* 158 */     String desc = PackageUtil.getSpecificationTitle() + " GIF Image Writer";
/*     */     
/* 160 */     return desc;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onRegistration(ServiceRegistry registry, Class category) {
/* 165 */     if (this.registered) {
/*     */       return;
/*     */     }
/*     */     
/* 169 */     this.registered = true;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 174 */     ImageUtil.processOnRegistration(registry, category, "GIF", this, 9, 8);
/*     */   }
/*     */ 
/*     */   
/*     */   public ImageWriter createWriterInstance(Object extension) {
/* 179 */     return new GIFImageWriter(this);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/gif/GIFImageWriterSpi.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */