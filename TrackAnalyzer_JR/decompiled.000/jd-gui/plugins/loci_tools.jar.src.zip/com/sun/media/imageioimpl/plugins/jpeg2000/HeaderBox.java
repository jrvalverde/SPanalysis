/*     */ package com.sun.media.imageioimpl.plugins.jpeg2000;
/*     */ 
/*     */ import javax.imageio.metadata.IIOInvalidTreeException;
/*     */ import javax.imageio.metadata.IIOMetadataNode;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HeaderBox
/*     */   extends Box
/*     */ {
/*  99 */   private static String[] elementNames = new String[] { "Height", "Width", "NumComponents", "BitDepth", "CompressionType", "UnknownColorspace", "IntellectualProperty" };
/*     */   
/*     */   private int width;
/*     */   
/*     */   private int height;
/*     */   private short numComp;
/*     */   private byte bitDepth;
/*     */   private byte compressionType;
/*     */   private byte unknownColor;
/*     */   private byte intelProp;
/*     */   
/*     */   public static String[] getElementNames() {
/* 111 */     return elementNames;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HeaderBox(int height, int width, int numComp, int bitDepth, int compressionType, int unknownColor, int intelProp) {
/* 126 */     super(22, 1768449138, null);
/* 127 */     this.height = height;
/* 128 */     this.width = width;
/* 129 */     this.numComp = (short)numComp;
/* 130 */     this.bitDepth = (byte)bitDepth;
/* 131 */     this.compressionType = (byte)compressionType;
/* 132 */     this.unknownColor = (byte)unknownColor;
/* 133 */     this.intelProp = (byte)intelProp;
/*     */   }
/*     */ 
/*     */   
/*     */   public HeaderBox(byte[] data) {
/* 138 */     super(8 + data.length, 1768449138, data);
/*     */   }
/*     */ 
/*     */   
/*     */   public HeaderBox(Node node) throws IIOInvalidTreeException {
/* 143 */     super(node);
/* 144 */     NodeList children = node.getChildNodes();
/*     */     
/* 146 */     for (int i = 0; i < children.getLength(); i++) {
/* 147 */       Node child = children.item(i);
/* 148 */       String name = child.getNodeName();
/*     */       
/* 150 */       if ("Height".equals(name)) {
/* 151 */         this.height = Box.getIntElementValue(child);
/*     */       }
/*     */       
/* 154 */       if ("Width".equals(name)) {
/* 155 */         this.width = Box.getIntElementValue(child);
/*     */       }
/*     */       
/* 158 */       if ("NumComponents".equals(name)) {
/* 159 */         this.numComp = Box.getShortElementValue(child);
/*     */       }
/*     */       
/* 162 */       if ("BitDepth".equals(name)) {
/* 163 */         this.bitDepth = Box.getByteElementValue(child);
/*     */       }
/*     */       
/* 166 */       if ("CompressionType".equals(name)) {
/* 167 */         this.compressionType = Box.getByteElementValue(child);
/*     */       }
/*     */       
/* 170 */       if ("UnknownColorspace".equals(name)) {
/* 171 */         this.unknownColor = Box.getByteElementValue(child);
/*     */       }
/*     */       
/* 174 */       if ("IntellectualProperty".equals(name)) {
/* 175 */         this.intelProp = Box.getByteElementValue(child);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void parse(byte[] data) {
/* 182 */     this.height = (data[0] & 0xFF) << 24 | (data[1] & 0xFF) << 16 | (data[2] & 0xFF) << 8 | data[3] & 0xFF;
/*     */ 
/*     */ 
/*     */     
/* 186 */     this.width = (data[4] & 0xFF) << 24 | (data[5] & 0xFF) << 16 | (data[6] & 0xFF) << 8 | data[7] & 0xFF;
/*     */ 
/*     */ 
/*     */     
/* 190 */     this.numComp = (short)((data[8] & 0xFF) << 8 | data[9] & 0xFF);
/* 191 */     this.bitDepth = data[10];
/* 192 */     this.compressionType = data[11];
/* 193 */     this.unknownColor = data[12];
/* 194 */     this.intelProp = data[13];
/*     */   }
/*     */ 
/*     */   
/*     */   public int getHeight() {
/* 199 */     return this.height;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getWidth() {
/* 204 */     return this.width;
/*     */   }
/*     */ 
/*     */   
/*     */   public short getNumComponents() {
/* 209 */     return this.numComp;
/*     */   }
/*     */ 
/*     */   
/*     */   public byte getCompressionType() {
/* 214 */     return this.compressionType;
/*     */   }
/*     */ 
/*     */   
/*     */   public byte getBitDepth() {
/* 219 */     return this.bitDepth;
/*     */   }
/*     */ 
/*     */   
/*     */   public byte getUnknownColorspace() {
/* 224 */     return this.unknownColor;
/*     */   }
/*     */ 
/*     */   
/*     */   public byte getIntellectualProperty() {
/* 229 */     return this.intelProp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IIOMetadataNode getNativeNode() {
/* 237 */     return getNativeNodeForSimpleBox();
/*     */   }
/*     */   
/*     */   protected void compose() {
/* 241 */     if (this.data != null)
/*     */       return; 
/* 243 */     this.data = new byte[14];
/* 244 */     copyInt(this.data, 0, this.height);
/* 245 */     copyInt(this.data, 4, this.width);
/*     */     
/* 247 */     this.data[8] = (byte)(this.numComp >> 8);
/* 248 */     this.data[9] = (byte)(this.numComp & 0xFF);
/* 249 */     this.data[10] = this.bitDepth;
/* 250 */     this.data[11] = this.compressionType;
/* 251 */     this.data[12] = this.unknownColor;
/* 252 */     this.data[13] = this.intelProp;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/jpeg2000/HeaderBox.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */