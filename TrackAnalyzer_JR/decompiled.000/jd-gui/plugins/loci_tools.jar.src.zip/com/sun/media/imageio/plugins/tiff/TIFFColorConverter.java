package com.sun.media.imageio.plugins.tiff;

public abstract class TIFFColorConverter {
  public abstract void fromRGB(float paramFloat1, float paramFloat2, float paramFloat3, float[] paramArrayOffloat);
  
  public abstract void toRGB(float paramFloat1, float paramFloat2, float paramFloat3, float[] paramArrayOffloat);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageio/plugins/tiff/TIFFColorConverter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */