/*     */ package com.sun.media.imageioimpl.plugins.tiff;
/*     */ 
/*     */ import com.sun.media.imageio.plugins.tiff.TIFFDecompressor;
/*     */ import java.io.IOException;
/*     */ import java.util.zip.DataFormatException;
/*     */ import java.util.zip.Inflater;
/*     */ import javax.imageio.IIOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TIFFDeflateDecompressor
/*     */   extends TIFFDecompressor
/*     */ {
/*     */   private static final boolean DEBUG = false;
/*  94 */   Inflater inflater = null;
/*     */   int predictor;
/*     */   
/*     */   public TIFFDeflateDecompressor(int predictor) throws IIOException {
/*  98 */     this.inflater = new Inflater();
/*     */     
/* 100 */     if (predictor != 1 && predictor != 2)
/*     */     {
/*     */       
/* 103 */       throw new IIOException("Illegal value for Predictor in TIFF file");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 111 */     this.predictor = predictor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void decodeRaw(byte[] b, int dstOffset, int bitsPerPixel, int scanlineStride) throws IOException {
/*     */     byte[] buf;
/*     */     int bufOffset;
/* 120 */     if (this.predictor == 2) {
/*     */       
/* 122 */       int len = this.bitsPerSample.length;
/* 123 */       for (int i = 0; i < len; i++) {
/* 124 */         if (this.bitsPerSample[i] != 8) {
/* 125 */           throw new IIOException(this.bitsPerSample[i] + "-bit samples " + "are not supported for Horizontal " + "differencing Predictor");
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 134 */     this.stream.seek(this.offset);
/*     */ 
/*     */     
/* 137 */     byte[] srcData = new byte[this.byteCount];
/* 138 */     this.stream.readFully(srcData);
/*     */     
/* 140 */     int bytesPerRow = (this.srcWidth * bitsPerPixel + 7) / 8;
/*     */ 
/*     */     
/* 143 */     if (bytesPerRow == scanlineStride) {
/* 144 */       buf = b;
/* 145 */       bufOffset = dstOffset;
/*     */     } else {
/* 147 */       buf = new byte[bytesPerRow * this.srcHeight];
/* 148 */       bufOffset = 0;
/*     */     } 
/*     */ 
/*     */     
/* 152 */     this.inflater.setInput(srcData);
/*     */ 
/*     */     
/*     */     try {
/* 156 */       this.inflater.inflate(buf, bufOffset, bytesPerRow * this.srcHeight);
/* 157 */     } catch (DataFormatException dfe) {
/* 158 */       throw new IIOException(I18N.getString("TIFFDeflateDecompressor0"), dfe);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 163 */     this.inflater.reset();
/*     */     
/* 165 */     if (this.predictor == 2)
/*     */     {
/*     */       
/* 168 */       for (int j = 0; j < this.srcHeight; j++) {
/* 169 */         int count = bufOffset + this.samplesPerPixel * (j * this.srcWidth + 1);
/* 170 */         for (int i = this.samplesPerPixel; i < this.srcWidth * this.samplesPerPixel; i++) {
/* 171 */           buf[count] = (byte)(buf[count] + buf[count - this.samplesPerPixel]);
/* 172 */           count++;
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/* 177 */     if (bytesPerRow != scanlineStride) {
/*     */ 
/*     */ 
/*     */       
/* 181 */       int off = 0;
/* 182 */       for (int y = 0; y < this.srcHeight; y++) {
/* 183 */         System.arraycopy(buf, off, b, dstOffset, bytesPerRow);
/* 184 */         off += bytesPerRow;
/* 185 */         dstOffset += scanlineStride;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/tiff/TIFFDeflateDecompressor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */