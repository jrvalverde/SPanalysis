/*     */ package com.sun.media.imageioimpl.plugins.wbmp;
/*     */ 
/*     */ import com.sun.media.imageioimpl.common.ImageUtil;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.DataBufferByte;
/*     */ import java.awt.image.MultiPixelPackedSampleModel;
/*     */ import java.awt.image.Raster;
/*     */ import java.awt.image.WritableRaster;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import javax.imageio.IIOException;
/*     */ import javax.imageio.ImageReadParam;
/*     */ import javax.imageio.ImageReader;
/*     */ import javax.imageio.ImageTypeSpecifier;
/*     */ import javax.imageio.metadata.IIOMetadata;
/*     */ import javax.imageio.spi.ImageReaderSpi;
/*     */ import javax.imageio.stream.ImageInputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WBMPImageReader
/*     */   extends ImageReader
/*     */ {
/* 111 */   private ImageInputStream iis = null;
/*     */ 
/*     */   
/*     */   private boolean gotHeader = false;
/*     */ 
/*     */   
/*     */   private long imageDataOffset;
/*     */ 
/*     */   
/*     */   private int width;
/*     */ 
/*     */   
/*     */   private int height;
/*     */ 
/*     */   
/*     */   private int wbmpType;
/*     */ 
/*     */   
/*     */   private WBMPMetadata metadata;
/*     */ 
/*     */   
/*     */   public WBMPImageReader(ImageReaderSpi originator) {
/* 133 */     super(originator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInput(Object input, boolean seekForwardOnly, boolean ignoreMetadata) {
/* 140 */     super.setInput(input, seekForwardOnly, ignoreMetadata);
/* 141 */     this.iis = (ImageInputStream)input;
/* 142 */     this.gotHeader = false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getNumImages(boolean allowSearch) throws IOException {
/* 147 */     if (this.iis == null) {
/* 148 */       throw new IllegalStateException(I18N.getString("GetNumImages0"));
/*     */     }
/* 150 */     if (this.seekForwardOnly && allowSearch) {
/* 151 */       throw new IllegalStateException(I18N.getString("GetNumImages1"));
/*     */     }
/* 153 */     return 1;
/*     */   }
/*     */   
/*     */   public int getWidth(int imageIndex) throws IOException {
/* 157 */     checkIndex(imageIndex);
/* 158 */     readHeader();
/* 159 */     return this.width;
/*     */   }
/*     */   
/*     */   public int getHeight(int imageIndex) throws IOException {
/* 163 */     checkIndex(imageIndex);
/* 164 */     readHeader();
/* 165 */     return this.height;
/*     */   }
/*     */   
/*     */   public boolean isRandomAccessEasy(int imageIndex) throws IOException {
/* 169 */     checkIndex(imageIndex);
/* 170 */     return true;
/*     */   }
/*     */   
/*     */   private void checkIndex(int imageIndex) {
/* 174 */     if (imageIndex != 0) {
/* 175 */       throw new IndexOutOfBoundsException(I18N.getString("WBMPImageReader0"));
/*     */     }
/*     */   }
/*     */   
/*     */   public void readHeader() throws IOException {
/* 180 */     if (this.gotHeader) {
/*     */ 
/*     */       
/* 183 */       this.iis.seek(this.imageDataOffset);
/*     */       
/*     */       return;
/*     */     } 
/* 187 */     if (this.iis == null) {
/* 188 */       throw new IllegalStateException(I18N.getString("WBMPImageReader1"));
/*     */     }
/*     */     
/* 191 */     this.metadata = new WBMPMetadata();
/* 192 */     this.wbmpType = this.iis.readByte();
/* 193 */     byte fixHeaderField = this.iis.readByte();
/*     */ 
/*     */     
/* 196 */     if (fixHeaderField != 0 || !isValidWbmpType(this.wbmpType))
/*     */     {
/* 198 */       throw new IIOException(I18N.getString("WBMPImageReader2"));
/*     */     }
/*     */     
/* 201 */     this.metadata.wbmpType = this.wbmpType;
/*     */ 
/*     */     
/* 204 */     this.width = ImageUtil.readMultiByteInteger(this.iis);
/* 205 */     this.metadata.width = this.width;
/*     */ 
/*     */     
/* 208 */     this.height = ImageUtil.readMultiByteInteger(this.iis);
/* 209 */     this.metadata.height = this.height;
/*     */     
/* 211 */     this.gotHeader = true;
/*     */     
/* 213 */     this.imageDataOffset = this.iis.getStreamPosition();
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator getImageTypes(int imageIndex) throws IOException {
/* 218 */     checkIndex(imageIndex);
/* 219 */     readHeader();
/*     */     
/* 221 */     BufferedImage bi = new BufferedImage(1, 1, 12);
/*     */     
/* 223 */     ArrayList<ImageTypeSpecifier> list = new ArrayList(1);
/* 224 */     list.add(new ImageTypeSpecifier(bi));
/* 225 */     return list.iterator();
/*     */   }
/*     */   
/*     */   public ImageReadParam getDefaultReadParam() {
/* 229 */     return new ImageReadParam();
/*     */   }
/*     */ 
/*     */   
/*     */   public IIOMetadata getImageMetadata(int imageIndex) throws IOException {
/* 234 */     checkIndex(imageIndex);
/* 235 */     if (this.metadata == null) {
/* 236 */       readHeader();
/*     */     }
/* 238 */     return this.metadata;
/*     */   }
/*     */   
/*     */   public IIOMetadata getStreamMetadata() throws IOException {
/* 242 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public BufferedImage read(int imageIndex, ImageReadParam param) throws IOException {
/* 248 */     if (this.iis == null) {
/* 249 */       throw new IllegalStateException(I18N.getString("WBMPImageReader1"));
/*     */     }
/*     */     
/* 252 */     checkIndex(imageIndex);
/* 253 */     clearAbortRequest();
/* 254 */     processImageStarted(imageIndex);
/* 255 */     if (param == null) {
/* 256 */       param = getDefaultReadParam();
/*     */     }
/*     */     
/* 259 */     readHeader();
/*     */     
/* 261 */     Rectangle sourceRegion = new Rectangle(0, 0, 0, 0);
/* 262 */     Rectangle destinationRegion = new Rectangle(0, 0, 0, 0);
/*     */     
/* 264 */     computeRegions(param, this.width, this.height, param.getDestination(), sourceRegion, destinationRegion);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 269 */     int scaleX = param.getSourceXSubsampling();
/* 270 */     int scaleY = param.getSourceYSubsampling();
/* 271 */     int xOffset = param.getSubsamplingXOffset();
/* 272 */     int yOffset = param.getSubsamplingYOffset();
/*     */ 
/*     */     
/* 275 */     BufferedImage bi = param.getDestination();
/*     */     
/* 277 */     if (bi == null) {
/* 278 */       bi = new BufferedImage(destinationRegion.x + destinationRegion.width, destinationRegion.y + destinationRegion.height, 12);
/*     */     }
/*     */ 
/*     */     
/* 282 */     boolean noTransform = (destinationRegion.equals(new Rectangle(0, 0, this.width, this.height)) && destinationRegion.equals(new Rectangle(0, 0, bi.getWidth(), bi.getHeight())));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 287 */     WritableRaster tile = bi.getWritableTile(0, 0);
/*     */ 
/*     */     
/* 290 */     MultiPixelPackedSampleModel sm = (MultiPixelPackedSampleModel)bi.getSampleModel();
/*     */ 
/*     */     
/* 293 */     if (noTransform) {
/* 294 */       if (abortRequested()) {
/* 295 */         processReadAborted();
/* 296 */         return bi;
/*     */       } 
/*     */ 
/*     */       
/* 300 */       this.iis.read(((DataBufferByte)tile.getDataBuffer()).getData(), 0, this.height * sm.getScanlineStride());
/*     */       
/* 302 */       processImageUpdate(bi, 0, 0, this.width, this.height, 1, 1, new int[] { 0 });
/*     */ 
/*     */ 
/*     */       
/* 306 */       processImageProgress(100.0F);
/*     */     } else {
/* 308 */       int len = (this.width + 7) / 8;
/* 309 */       byte[] buf = new byte[len];
/* 310 */       byte[] data = ((DataBufferByte)tile.getDataBuffer()).getData();
/* 311 */       int lineStride = sm.getScanlineStride();
/* 312 */       this.iis.skipBytes(len * sourceRegion.y);
/* 313 */       int skipLength = len * (scaleY - 1);
/*     */ 
/*     */       
/* 316 */       int[] srcOff = new int[destinationRegion.width];
/* 317 */       int[] destOff = new int[destinationRegion.width];
/* 318 */       int[] srcPos = new int[destinationRegion.width];
/* 319 */       int[] destPos = new int[destinationRegion.width];
/*     */       
/* 321 */       int i = destinationRegion.x, x = sourceRegion.x, m = 0;
/* 322 */       for (; i < destinationRegion.x + destinationRegion.width; 
/* 323 */         i++, m++, x += scaleX) {
/* 324 */         srcPos[m] = x >> 3;
/* 325 */         srcOff[m] = 7 - (x & 0x7);
/* 326 */         destPos[m] = i >> 3;
/* 327 */         destOff[m] = 7 - (i & 0x7);
/*     */       } 
/*     */       
/* 330 */       int j = 0, y = sourceRegion.y;
/* 331 */       int k = destinationRegion.y * lineStride;
/* 332 */       for (; j < destinationRegion.height; j++, y += scaleY) {
/*     */         
/* 334 */         if (abortRequested())
/*     */           break; 
/* 336 */         this.iis.read(buf, 0, len);
/* 337 */         for (int n = 0; n < destinationRegion.width; n++) {
/*     */           
/* 339 */           int v = buf[srcPos[n]] >> srcOff[n] & 0x1;
/* 340 */           data[k + destPos[n]] = (byte)(data[k + destPos[n]] | v << destOff[n]);
/*     */         } 
/*     */         
/* 343 */         k += lineStride;
/* 344 */         this.iis.skipBytes(skipLength);
/* 345 */         processImageUpdate(bi, 0, j, destinationRegion.width, 1, 1, 1, new int[] { 0 });
/*     */ 
/*     */ 
/*     */         
/* 349 */         processImageProgress(100.0F * j / destinationRegion.height);
/*     */       } 
/*     */     } 
/*     */     
/* 353 */     if (abortRequested()) {
/* 354 */       processReadAborted();
/*     */     } else {
/* 356 */       processImageComplete();
/* 357 */     }  return bi;
/*     */   }
/*     */   
/*     */   public boolean canReadRaster() {
/* 361 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public Raster readRaster(int imageIndex, ImageReadParam param) throws IOException {
/* 366 */     BufferedImage bi = read(imageIndex, param);
/* 367 */     return bi.getData();
/*     */   }
/*     */   
/*     */   public void reset() {
/* 371 */     super.reset();
/* 372 */     this.iis = null;
/* 373 */     this.gotHeader = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isValidWbmpType(int type) {
/* 381 */     return (type == 0);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/wbmp/WBMPImageReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */