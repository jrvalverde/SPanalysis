/*     */ package com.sun.media.imageio.plugins.tiff;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GeoTIFFTagSet
/*     */   extends TIFFTagSet
/*     */ {
/* 101 */   private static GeoTIFFTagSet theInstance = null;
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int TAG_MODEL_PIXEL_SCALE = 33550;
/*     */ 
/*     */   
/*     */   public static final int TAG_MODEL_TRANSFORMATION = 34264;
/*     */ 
/*     */   
/*     */   public static final int TAG_MODEL_TIE_POINT = 33922;
/*     */ 
/*     */   
/*     */   public static final int TAG_GEO_KEY_DIRECTORY = 34735;
/*     */ 
/*     */   
/*     */   public static final int TAG_GEO_DOUBLE_PARAMS = 34736;
/*     */ 
/*     */   
/*     */   public static final int TAG_GEO_ASCII_PARAMS = 34737;
/*     */ 
/*     */   
/*     */   private static List tags;
/*     */ 
/*     */ 
/*     */   
/*     */   static class ModelPixelScale
/*     */     extends TIFFTag
/*     */   {
/*     */     public ModelPixelScale() {
/* 131 */       super("ModelPixelScaleTag", 33550, 4096);
/*     */     }
/*     */   }
/*     */   
/*     */   static class ModelTransformation
/*     */     extends TIFFTag
/*     */   {
/*     */     public ModelTransformation() {
/* 139 */       super("ModelTransformationTag", 34264, 4096);
/*     */     }
/*     */   }
/*     */   
/*     */   static class ModelTiePoint
/*     */     extends TIFFTag
/*     */   {
/*     */     public ModelTiePoint() {
/* 147 */       super("ModelTiePointTag", 33922, 4096);
/*     */     }
/*     */   }
/*     */   
/*     */   static class GeoKeyDirectory
/*     */     extends TIFFTag
/*     */   {
/*     */     public GeoKeyDirectory() {
/* 155 */       super("GeoKeyDirectory", 34735, 8);
/*     */     }
/*     */   }
/*     */   
/*     */   static class GeoDoubleParams
/*     */     extends TIFFTag
/*     */   {
/*     */     public GeoDoubleParams() {
/* 163 */       super("GeoDoubleParams", 34736, 4096);
/*     */     }
/*     */   }
/*     */   
/*     */   static class GeoAsciiParams
/*     */     extends TIFFTag
/*     */   {
/*     */     public GeoAsciiParams() {
/* 171 */       super("GeoAsciiParams", 34737, 4);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void initTags() {
/* 180 */     tags = new ArrayList(42);
/*     */     
/* 182 */     tags.add(new ModelPixelScale());
/* 183 */     tags.add(new ModelTransformation());
/* 184 */     tags.add(new ModelTiePoint());
/* 185 */     tags.add(new GeoKeyDirectory());
/* 186 */     tags.add(new GeoDoubleParams());
/* 187 */     tags.add(new GeoAsciiParams());
/*     */   }
/*     */   
/*     */   private GeoTIFFTagSet() {
/* 191 */     super(tags);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized GeoTIFFTagSet getInstance() {
/* 200 */     if (theInstance == null) {
/* 201 */       initTags();
/* 202 */       theInstance = new GeoTIFFTagSet();
/* 203 */       tags = null;
/*     */     } 
/* 205 */     return theInstance;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageio/plugins/tiff/GeoTIFFTagSet.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */