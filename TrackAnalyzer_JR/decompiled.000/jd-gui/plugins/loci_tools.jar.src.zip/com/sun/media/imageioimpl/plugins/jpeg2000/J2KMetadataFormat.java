/*     */ package com.sun.media.imageioimpl.plugins.jpeg2000;
/*     */ 
/*     */ import java.awt.image.ColorModel;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import javax.imageio.ImageTypeSpecifier;
/*     */ import javax.imageio.metadata.IIOMetadataFormatImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class J2KMetadataFormat
/*     */   extends IIOMetadataFormatImpl
/*     */ {
/*  99 */   private static Hashtable parents = new Hashtable<Object, Object>();
/*     */   private static J2KMetadataFormat instance;
/*     */   
/*     */   static {
/* 103 */     parents.put("JPEG2000SignatureBox", "com_sun_media_imageio_plugins_jpeg2000_image_1.0");
/* 104 */     parents.put("JPEG2000FileTypeBox", "com_sun_media_imageio_plugins_jpeg2000_image_1.0");
/* 105 */     parents.put("OtherBoxes", "com_sun_media_imageio_plugins_jpeg2000_image_1.0");
/*     */ 
/*     */ 
/*     */     
/* 109 */     parents.put("JPEG2000HeaderSuperBox", "OtherBoxes");
/* 110 */     parents.put("JPEG2000CodeStreamBox", "OtherBoxes");
/*     */     
/* 112 */     parents.put("JPEG2000IntellectualPropertyRightsBox", "OtherBoxes");
/* 113 */     parents.put("JPEG2000XMLBox", "OtherBoxes");
/* 114 */     parents.put("JPEG2000UUIDBox", "OtherBoxes");
/* 115 */     parents.put("JPEG2000UUIDInfoBox", "OtherBoxes");
/*     */ 
/*     */     
/* 118 */     parents.put("JPEG2000HeaderBox", "JPEG2000HeaderSuperBox");
/* 119 */     parents.put("OptionalBoxes", "JPEG2000HeaderSuperBox");
/*     */ 
/*     */     
/* 122 */     parents.put("JPEG2000BitsPerComponentBox", "OptionalBoxes");
/* 123 */     parents.put("JPEG2000ColorSpecificationBox", "OptionalBoxes");
/* 124 */     parents.put("JPEG2000PaletteBox", "OptionalBoxes");
/* 125 */     parents.put("JPEG2000ComponentMappingBox", "OptionalBoxes");
/* 126 */     parents.put("JPEG2000ChannelDefinitionBox", "OptionalBoxes");
/* 127 */     parents.put("JPEG2000ResolutionBox", "OptionalBoxes");
/*     */ 
/*     */     
/* 130 */     parents.put("JPEG2000CaptureResolutionBox", "JPEG2000ResolutionBox");
/* 131 */     parents.put("JPEG2000DefaultDisplayResolutionBox", "JPEG2000ResolutionBox");
/*     */ 
/*     */ 
/*     */     
/* 135 */     parents.put("JPEG2000UUIDListBox", "JPEG2000UUIDInfoBox");
/* 136 */     parents.put("JPEG2000DataEntryURLBox", "JPEG2000UUIDInfoBox");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized J2KMetadataFormat getInstance() {
/* 142 */     if (instance == null)
/* 143 */       instance = new J2KMetadataFormat(); 
/* 144 */     return instance;
/*     */   }
/*     */   
/* 147 */   String resourceBaseName = getClass().getName() + "Resources";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   J2KMetadataFormat() {
/* 154 */     super("com_sun_media_imageio_plugins_jpeg2000_image_1.0", 1);
/* 155 */     setResourceBaseName(this.resourceBaseName);
/* 156 */     addElements();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addElements() {
/* 163 */     addElement("JPEG2000SignatureBox", getParent("JPEG2000SignatureBox"), 0);
/*     */ 
/*     */ 
/*     */     
/* 167 */     addElement("JPEG2000FileTypeBox", getParent("JPEG2000FileTypeBox"), 1);
/*     */ 
/*     */     
/* 170 */     addElement("OtherBoxes", getParent("OtherBoxes"), 3);
/*     */ 
/*     */ 
/*     */     
/* 174 */     addElement("JPEG2000HeaderSuperBox", getParent("JPEG2000HeaderSuperBox"), 3);
/*     */ 
/*     */     
/* 177 */     addElement("JPEG2000CodeStreamBox", getParent("JPEG2000CodeStreamBox"), 0);
/*     */ 
/*     */     
/* 180 */     addElement("JPEG2000IntellectualPropertyRightsBox", getParent("JPEG2000IntellectualPropertyRightsBox"), 1);
/*     */ 
/*     */     
/* 183 */     addElement("JPEG2000XMLBox", getParent("JPEG2000XMLBox"), 1);
/*     */ 
/*     */     
/* 186 */     addElement("JPEG2000UUIDBox", getParent("JPEG2000UUIDBox"), 1);
/*     */ 
/*     */     
/* 189 */     addElement("JPEG2000UUIDInfoBox", getParent("JPEG2000UUIDInfoBox"), 1);
/*     */ 
/*     */ 
/*     */     
/* 193 */     addElement("JPEG2000HeaderBox", "JPEG2000HeaderSuperBox", 1);
/*     */ 
/*     */     
/* 196 */     addElement("OptionalBoxes", "JPEG2000HeaderSuperBox", 3);
/*     */ 
/*     */     
/* 199 */     addElement("JPEG2000BitsPerComponentBox", "OptionalBoxes", 1);
/*     */ 
/*     */     
/* 202 */     addElement("JPEG2000ColorSpecificationBox", "OptionalBoxes", 1);
/*     */ 
/*     */     
/* 205 */     addElement("JPEG2000PaletteBox", "OptionalBoxes", 1);
/*     */ 
/*     */     
/* 208 */     addElement("JPEG2000ComponentMappingBox", "OptionalBoxes", 1);
/*     */ 
/*     */     
/* 211 */     addElement("JPEG2000ChannelDefinitionBox", "OptionalBoxes", 1);
/*     */ 
/*     */     
/* 214 */     addElement("JPEG2000ResolutionBox", "OptionalBoxes", 1);
/*     */ 
/*     */ 
/*     */     
/* 218 */     addElement("JPEG2000CaptureResolutionBox", "JPEG2000ResolutionBox", 1);
/*     */ 
/*     */     
/* 221 */     addElement("JPEG2000DefaultDisplayResolutionBox", "JPEG2000ResolutionBox", 1);
/*     */ 
/*     */ 
/*     */     
/* 225 */     addElement("JPEG2000UUIDListBox", "JPEG2000UUIDInfoBox", 1);
/*     */ 
/*     */     
/* 228 */     addElement("JPEG2000DataEntryURLBox", "JPEG2000UUIDInfoBox", 1);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 233 */     Enumeration<String> keys = parents.keys();
/* 234 */     while (keys.hasMoreElements()) {
/* 235 */       String s = keys.nextElement();
/* 236 */       if (s.startsWith("JPEG2000")) {
/* 237 */         addAttribute(s, "Length", 2, true, null);
/* 238 */         addAttribute(s, "Type", 0, true, Box.getTypeByName(s));
/* 239 */         addAttribute(s, "ExtraLength", 0, false, null);
/*     */ 
/*     */ 
/*     */         
/* 243 */         Class c = Box.getBoxClass(Box.getTypeInt(Box.getTypeByName(s)));
/*     */         
/*     */         try {
/* 246 */           Method m = c.getMethod("getElementNames", (Class[])null);
/* 247 */           String[] elementNames = (String[])m.invoke(null, (Object[])null);
/*     */           
/* 249 */           for (int i = 0; i < elementNames.length; i++)
/* 250 */             addElement(elementNames[i], s, 0); 
/* 251 */         } catch (Exception e) {}
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 257 */     addAttribute("JPEG2000SignatureBox", "Signature", 0, true, "0D0A870A");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 263 */     addElement("BitDepth", "JPEG2000BitsPerComponentBox", 0);
/*     */ 
/*     */ 
/*     */     
/* 267 */     addElement("NumberEntries", "JPEG2000PaletteBox", 0);
/*     */ 
/*     */ 
/*     */     
/* 271 */     addElement("NumberColors", "JPEG2000PaletteBox", 0);
/*     */ 
/*     */ 
/*     */     
/* 275 */     addElement("BitDepth", "JPEG2000PaletteBox", 0);
/*     */ 
/*     */ 
/*     */     
/* 279 */     addElement("LUT", "JPEG2000PaletteBox", 1, 1024);
/*     */ 
/*     */ 
/*     */     
/* 283 */     addElement("LUTRow", "LUT", 0);
/*     */ 
/*     */ 
/*     */     
/* 287 */     addElement("Component", "JPEG2000ComponentMappingBox", 0);
/*     */ 
/*     */ 
/*     */     
/* 291 */     addElement("ComponentType", "JPEG2000ComponentMappingBox", 0);
/*     */ 
/*     */ 
/*     */     
/* 295 */     addElement("ComponentAssociation", "JPEG2000ComponentMappingBox", 0);
/*     */ 
/*     */ 
/*     */     
/* 299 */     addElement("NumberOfDefinition", "JPEG2000ChannelDefinitionBox", 0);
/*     */ 
/*     */ 
/*     */     
/* 303 */     addElement("Definitions", "JPEG2000ChannelDefinitionBox", 0, 9);
/*     */ 
/*     */ 
/*     */     
/* 307 */     addElement("ChannelNumber", "Definitions", 0);
/*     */ 
/*     */ 
/*     */     
/* 311 */     addElement("ChannelType", "Definitions", 0);
/*     */ 
/*     */     
/* 314 */     addElement("ChannelAssociation", "Definitions", 0);
/*     */ 
/*     */     
/* 317 */     addElement("CodeStream", "JPEG2000CodeStreamBox", 0);
/*     */ 
/*     */     
/* 320 */     addElement("Content", "JPEG2000IntellectualPropertyRightsBox", 0);
/*     */ 
/*     */     
/* 323 */     addElement("Content", "JPEG2000XMLBox", 0);
/*     */ 
/*     */     
/* 326 */     addElement("UUID", "JPEG2000UUIDBox", 0);
/*     */ 
/*     */     
/* 329 */     addElement("Data", "JPEG2000UUIDBox", 0);
/*     */ 
/*     */     
/* 332 */     addElement("NumberUUID", "JPEG2000UUIDListBox", 0);
/*     */ 
/*     */     
/* 335 */     addElement("UUID", "JPEG2000UUIDListBox", 0);
/*     */ 
/*     */     
/* 338 */     addElement("Version", "JPEG2000DataEntryURLBox", 0);
/*     */ 
/*     */     
/* 341 */     addElement("Flags", "JPEG2000DataEntryURLBox", 0);
/*     */ 
/*     */     
/* 344 */     addElement("URL", "JPEG2000DataEntryURLBox", 0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getParent(String elementName) {
/* 350 */     return (String)parents.get(elementName);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canNodeAppear(String elementName, ImageTypeSpecifier imageType) {
/* 355 */     ColorModel cm = imageType.getColorModel();
/* 356 */     if (!(cm instanceof java.awt.image.IndexColorModel) && 
/* 357 */       "JPEG2000PaletteBox".equals(elementName))
/* 358 */       return false; 
/* 359 */     if (!cm.hasAlpha() && 
/* 360 */       "JPEG2000ChannelDefinitionBox".equals(elementName)) {
/* 361 */       return false;
/*     */     }
/* 363 */     if (getParent(elementName) != null)
/* 364 */       return true; 
/* 365 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isLeaf(String name) {
/* 369 */     Set keys = parents.keySet();
/* 370 */     Iterator iterator = keys.iterator();
/* 371 */     while (iterator.hasNext()) {
/* 372 */       if (name.equals(parents.get(iterator.next()))) {
/* 373 */         return false;
/*     */       }
/*     */     } 
/* 376 */     return true;
/*     */   }
/*     */   
/*     */   public boolean singleInstance(String name) {
/* 380 */     return (!name.equals("JPEG2000IntellectualPropertyRightsBox") && !name.equals("JPEG2000XMLBox") && !name.equals("JPEG2000UUIDBox") && !name.equals("JPEG2000UUIDInfoBox") && !name.equals("JPEG2000UUIDListBox") && !name.equals("JPEG2000DataEntryURLBox"));
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/jpeg2000/J2KMetadataFormat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */