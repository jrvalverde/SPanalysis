/*     */ package com.sun.media.imageioimpl.common;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PackageUtil
/*     */ {
/*  90 */   private static String version = "1.0";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  95 */   private static String vendor = "Sun Microsystems, Inc.";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 100 */   private static String specTitle = "Java Advanced Imaging Image I/O Tools";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*     */     try {
/* 108 */       Class<?> thisClass = Class.forName("com.sun.media.imageioimpl.common.PackageUtil");
/*     */       
/* 110 */       Package thisPackage = thisClass.getPackage();
/* 111 */       version = thisPackage.getImplementationVersion();
/* 112 */       vendor = thisPackage.getImplementationVendor();
/* 113 */       specTitle = thisPackage.getSpecificationTitle();
/* 114 */     } catch (ClassNotFoundException e) {}
/*     */ 
/*     */ 
/*     */     
/* 118 */     if (vendor == null) vendor = ""; 
/* 119 */     if (version == null) version = "";
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String getVersion() {
/* 126 */     return version;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String getVendor() {
/* 133 */     return vendor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String getSpecificationTitle() {
/* 140 */     return specTitle;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/common/PackageUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */