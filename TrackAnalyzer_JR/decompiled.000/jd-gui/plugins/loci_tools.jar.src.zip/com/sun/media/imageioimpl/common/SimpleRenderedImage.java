/*     */ package com.sun.media.imageioimpl.common;
/*     */ 
/*     */ import java.awt.Image;
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.image.ColorModel;
/*     */ import java.awt.image.Raster;
/*     */ import java.awt.image.RenderedImage;
/*     */ import java.awt.image.SampleModel;
/*     */ import java.awt.image.WritableRaster;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Iterator;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SimpleRenderedImage
/*     */   implements RenderedImage
/*     */ {
/*     */   protected int minX;
/*     */   protected int minY;
/*     */   protected int width;
/*     */   protected int height;
/*     */   protected int tileWidth;
/*     */   protected int tileHeight;
/* 115 */   protected int tileGridXOffset = 0;
/*     */ 
/*     */   
/* 118 */   protected int tileGridYOffset = 0;
/*     */ 
/*     */   
/*     */   protected SampleModel sampleModel;
/*     */ 
/*     */   
/*     */   protected ColorModel colorModel;
/*     */ 
/*     */   
/* 127 */   protected Vector sources = new Vector();
/*     */ 
/*     */   
/* 130 */   protected Hashtable properties = new Hashtable<Object, Object>();
/*     */ 
/*     */   
/*     */   public int getMinX() {
/* 134 */     return this.minX;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getMaxX() {
/* 144 */     return getMinX() + getWidth();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getMinY() {
/* 149 */     return this.minY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getMaxY() {
/* 159 */     return getMinY() + getHeight();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getWidth() {
/* 164 */     return this.width;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getHeight() {
/* 169 */     return this.height;
/*     */   }
/*     */ 
/*     */   
/*     */   public Rectangle getBounds() {
/* 174 */     return new Rectangle(getMinX(), getMinY(), getWidth(), getHeight());
/*     */   }
/*     */ 
/*     */   
/*     */   public int getTileWidth() {
/* 179 */     return this.tileWidth;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getTileHeight() {
/* 184 */     return this.tileHeight;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTileGridXOffset() {
/* 191 */     return this.tileGridXOffset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTileGridYOffset() {
/* 198 */     return this.tileGridYOffset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMinTileX() {
/* 207 */     return XToTileX(getMinX());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaxTileX() {
/* 216 */     return XToTileX(getMaxX() - 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNumXTiles() {
/* 226 */     return getMaxTileX() - getMinTileX() + 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMinTileY() {
/* 235 */     return YToTileY(getMinY());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaxTileY() {
/* 244 */     return YToTileY(getMaxY() - 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNumYTiles() {
/* 254 */     return getMaxTileY() - getMinTileY() + 1;
/*     */   }
/*     */ 
/*     */   
/*     */   public SampleModel getSampleModel() {
/* 259 */     return this.sampleModel;
/*     */   }
/*     */ 
/*     */   
/*     */   public ColorModel getColorModel() {
/* 264 */     return this.colorModel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getProperty(String name) {
/* 278 */     name = name.toLowerCase();
/* 279 */     Object value = this.properties.get(name);
/* 280 */     return (value != null) ? value : Image.UndefinedProperty;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getPropertyNames() {
/* 292 */     String[] names = null;
/*     */     
/* 294 */     if (this.properties.size() > 0) {
/* 295 */       names = new String[this.properties.size()];
/* 296 */       int index = 0;
/*     */       
/* 298 */       Enumeration<String> e = this.properties.keys();
/* 299 */       while (e.hasMoreElements()) {
/* 300 */         String name = e.nextElement();
/* 301 */         names[index++] = name;
/*     */       } 
/*     */     } 
/*     */     
/* 305 */     return names;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getPropertyNames(String prefix) {
/* 322 */     String[] propertyNames = getPropertyNames();
/* 323 */     if (propertyNames == null) {
/* 324 */       return null;
/*     */     }
/*     */     
/* 327 */     prefix = prefix.toLowerCase();
/*     */     
/* 329 */     Vector<String> names = new Vector();
/* 330 */     for (int i = 0; i < propertyNames.length; i++) {
/* 331 */       if (propertyNames[i].startsWith(prefix)) {
/* 332 */         names.addElement(propertyNames[i]);
/*     */       }
/*     */     } 
/*     */     
/* 336 */     if (names.size() == 0) {
/* 337 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 341 */     String[] prefixNames = new String[names.size()];
/* 342 */     int count = 0;
/* 343 */     for (Iterator<String> it = names.iterator(); it.hasNext();) {
/* 344 */       prefixNames[count++] = it.next();
/*     */     }
/*     */     
/* 347 */     return prefixNames;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int XToTileX(int x, int tileGridXOffset, int tileWidth) {
/* 358 */     x -= tileGridXOffset;
/* 359 */     if (x < 0) {
/* 360 */       x += 1 - tileWidth;
/*     */     }
/* 362 */     return x / tileWidth;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int YToTileY(int y, int tileGridYOffset, int tileHeight) {
/* 371 */     y -= tileGridYOffset;
/* 372 */     if (y < 0) {
/* 373 */       y += 1 - tileHeight;
/*     */     }
/* 375 */     return y / tileHeight;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int XToTileX(int x) {
/* 387 */     return XToTileX(x, getTileGridXOffset(), getTileWidth());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int YToTileY(int y) {
/* 399 */     return YToTileY(y, getTileGridYOffset(), getTileHeight());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int tileXToX(int tx, int tileGridXOffset, int tileWidth) {
/* 408 */     return tx * tileWidth + tileGridXOffset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int tileYToY(int ty, int tileGridYOffset, int tileHeight) {
/* 417 */     return ty * tileHeight + tileGridYOffset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int tileXToX(int tx) {
/* 429 */     return tx * this.tileWidth + this.tileGridXOffset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int tileYToY(int ty) {
/* 441 */     return ty * this.tileHeight + this.tileGridYOffset;
/*     */   }
/*     */   
/*     */   public Vector getSources() {
/* 445 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Raster getData() {
/* 465 */     Rectangle rect = new Rectangle(getMinX(), getMinY(), getWidth(), getHeight());
/*     */     
/* 467 */     return getData(rect);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Raster getData(Rectangle bounds) {
/* 489 */     Rectangle imageBounds = getBounds();
/*     */ 
/*     */     
/* 492 */     if (bounds == null) {
/* 493 */       bounds = imageBounds;
/* 494 */     } else if (!bounds.intersects(imageBounds)) {
/* 495 */       throw new IllegalArgumentException(I18N.getString("SimpleRenderedImage0"));
/*     */     } 
/*     */ 
/*     */     
/* 499 */     int startX = XToTileX(bounds.x);
/* 500 */     int startY = YToTileY(bounds.y);
/* 501 */     int endX = XToTileX(bounds.x + bounds.width - 1);
/* 502 */     int endY = YToTileY(bounds.y + bounds.height - 1);
/*     */ 
/*     */ 
/*     */     
/* 506 */     if (startX == endX && startY == endY) {
/* 507 */       Raster tile = getTile(startX, startY);
/* 508 */       return tile.createChild(bounds.x, bounds.y, bounds.width, bounds.height, bounds.x, bounds.y, null);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 514 */     if (!imageBounds.contains(bounds)) {
/* 515 */       Rectangle xsect = bounds.intersection(imageBounds);
/* 516 */       startX = XToTileX(xsect.x);
/* 517 */       startY = YToTileY(xsect.y);
/* 518 */       endX = XToTileX(xsect.x + xsect.width - 1);
/* 519 */       endY = YToTileY(xsect.y + xsect.height - 1);
/*     */     } 
/*     */ 
/*     */     
/* 523 */     SampleModel sm = this.sampleModel.createCompatibleSampleModel(bounds.width, bounds.height);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 528 */     WritableRaster dest = Raster.createWritableRaster(sm, bounds.getLocation());
/*     */ 
/*     */ 
/*     */     
/* 532 */     for (int j = startY; j <= endY; j++) {
/* 533 */       for (int i = startX; i <= endX; i++) {
/*     */         
/* 535 */         Raster tile = getTile(i, j);
/*     */ 
/*     */ 
/*     */         
/* 539 */         Rectangle tileRect = tile.getBounds();
/* 540 */         Rectangle intersectRect = bounds.intersection(tile.getBounds());
/*     */         
/* 542 */         Raster liveRaster = tile.createChild(intersectRect.x, intersectRect.y, intersectRect.width, intersectRect.height, intersectRect.x, intersectRect.y, null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 551 */         dest.setRect(liveRaster);
/*     */       } 
/*     */     } 
/*     */     
/* 555 */     return dest;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WritableRaster copyData(WritableRaster dest) {
/* 578 */     Rectangle bounds, imageBounds = getBounds();
/*     */ 
/*     */     
/* 581 */     if (dest == null) {
/*     */       
/* 583 */       bounds = imageBounds;
/* 584 */       Point p = new Point(this.minX, this.minY);
/* 585 */       SampleModel sm = this.sampleModel.createCompatibleSampleModel(this.width, this.height);
/*     */       
/* 587 */       dest = Raster.createWritableRaster(sm, p);
/*     */     } else {
/* 589 */       bounds = dest.getBounds();
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 594 */     Rectangle xsect = imageBounds.contains(bounds) ? bounds : bounds.intersection(imageBounds);
/*     */     
/* 596 */     int startX = XToTileX(xsect.x);
/* 597 */     int startY = YToTileY(xsect.y);
/* 598 */     int endX = XToTileX(xsect.x + xsect.width - 1);
/* 599 */     int endY = YToTileY(xsect.y + xsect.height - 1);
/*     */ 
/*     */     
/* 602 */     for (int j = startY; j <= endY; j++) {
/* 603 */       for (int i = startX; i <= endX; i++) {
/*     */         
/* 605 */         Raster tile = getTile(i, j);
/*     */ 
/*     */ 
/*     */         
/* 609 */         Rectangle tileRect = tile.getBounds();
/* 610 */         Rectangle intersectRect = bounds.intersection(tile.getBounds());
/*     */         
/* 612 */         Raster liveRaster = tile.createChild(intersectRect.x, intersectRect.y, intersectRect.width, intersectRect.height, intersectRect.x, intersectRect.y, null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 621 */         dest.setRect(liveRaster);
/*     */       } 
/*     */     } 
/*     */     
/* 625 */     return dest;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/common/SimpleRenderedImage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */