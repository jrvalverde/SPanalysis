/*     */ package com.sun.media.imageioimpl.plugins.jpeg2000;
/*     */ 
/*     */ import java.awt.image.ColorModel;
/*     */ import javax.imageio.metadata.IIOInvalidTreeException;
/*     */ import javax.imageio.metadata.IIOMetadataNode;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ChannelDefinitionBox
/*     */   extends Box
/*     */ {
/*     */   private short num;
/*     */   private short[] channels;
/*     */   private short[] types;
/*     */   private short[] associations;
/*     */   
/*     */   private static int computeLength(ColorModel colorModel) {
/* 105 */     int length = (colorModel.getComponentSize()).length - 1;
/* 106 */     return 10 + (colorModel.isAlphaPremultiplied() ? (length * 18) : (length * 12));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void fillBasedOnBands(int numComps, boolean isPremultiplied, short[] c, short[] t, short[] a) {
/* 118 */     int num = numComps * (isPremultiplied ? 3 : 2);
/* 119 */     if (isPremultiplied) {
/* 120 */       for (int j = numComps * 2; j < num; j++) {
/* 121 */         c[j] = (short)(j - numComps * 2);
/* 122 */         t[j] = 2;
/* 123 */         a[j] = (short)(j + 1 - numComps * 2);
/*     */       } 
/*     */     }
/*     */     
/* 127 */     for (int i = 0; i < numComps; i++) {
/* 128 */       int j = i + numComps;
/* 129 */       c[i] = (short)i;
/* 130 */       t[i] = 0;
/* 131 */       a[i] = (short)(i + 1); a[j] = (short)(i + 1);
/*     */       
/* 133 */       c[j] = (short)numComps;
/* 134 */       t[j] = 1;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelDefinitionBox(ColorModel colorModel) {
/* 142 */     super(computeLength(colorModel), 1667523942, null);
/*     */ 
/*     */     
/* 145 */     short length = (short)((colorModel.getComponentSize()).length - 1);
/* 146 */     this.num = (short)(length * (colorModel.isAlphaPremultiplied() ? 3 : 2));
/* 147 */     this.channels = new short[this.num];
/* 148 */     this.types = new short[this.num];
/* 149 */     this.associations = new short[this.num];
/*     */ 
/*     */     
/* 152 */     fillBasedOnBands(length, colorModel.isAlphaPremultiplied(), this.channels, this.types, this.associations);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelDefinitionBox(byte[] data) {
/* 163 */     super(8 + data.length, 1667523942, data);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelDefinitionBox(short[] channel, short[] types, short[] associations) {
/* 171 */     super(10 + channel.length * 6, 1667523942, null);
/* 172 */     this.num = (short)channel.length;
/* 173 */     this.channels = channel;
/* 174 */     this.types = types;
/* 175 */     this.associations = associations;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelDefinitionBox(Node node) throws IIOInvalidTreeException {
/* 182 */     super(node);
/* 183 */     NodeList children = node.getChildNodes();
/* 184 */     int index = 0;
/*     */     
/* 186 */     for (int i = 0; i < children.getLength(); i++) {
/* 187 */       Node child = children.item(i);
/* 188 */       String name = child.getNodeName();
/*     */       
/* 190 */       if ("NumberOfDefinition".equals(name)) {
/* 191 */         this.num = Box.getShortElementValue(child);
/*     */       }
/*     */       
/* 194 */       if ("Definitions".equals(name)) {
/* 195 */         this.channels = new short[this.num];
/* 196 */         this.types = new short[this.num];
/* 197 */         this.associations = new short[this.num];
/*     */         
/* 199 */         NodeList children1 = child.getChildNodes();
/*     */         
/* 201 */         for (int j = 0; j < children1.getLength(); j++) {
/* 202 */           child = children1.item(j);
/* 203 */           name = child.getNodeName();
/* 204 */           if ("ChannelNumber".equals(name)) {
/* 205 */             this.channels[index] = Box.getShortElementValue(child);
/*     */           }
/*     */           
/* 208 */           if ("ChannelType".equals(name)) {
/* 209 */             this.types[index] = Box.getShortElementValue(child);
/*     */           }
/*     */           
/* 212 */           if ("Association".equals(name)) {
/* 213 */             this.associations[index++] = Box.getShortElementValue(child);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void parse(byte[] data) {
/* 222 */     this.num = (short)(data[0] << 8 | data[1]);
/* 223 */     this.channels = new short[this.num];
/* 224 */     this.types = new short[this.num];
/* 225 */     this.associations = new short[this.num];
/*     */     
/* 227 */     for (int i = 0, j = 2; i < this.num; i++) {
/* 228 */       this.channels[i] = (short)(((data[j++] & 0xFF) << 8) + (data[j++] & 0xFF));
/*     */       
/* 230 */       this.types[i] = (short)(((data[j++] & 0xFF) << 8) + (data[j++] & 0xFF));
/* 231 */       this.associations[i] = (short)(((data[j++] & 0xFF) << 8) + (data[j++] & 0xFF));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public short[] getChannel() {
/* 238 */     return this.channels;
/*     */   }
/*     */ 
/*     */   
/*     */   public short[] getTypes() {
/* 243 */     return this.types;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public short[] getAssociation() {
/* 250 */     return this.associations;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IIOMetadataNode getNativeNode() {
/* 258 */     IIOMetadataNode node = new IIOMetadataNode(Box.getName(getType()));
/* 259 */     setDefaultAttributes(node);
/*     */     
/* 261 */     IIOMetadataNode child = new IIOMetadataNode("NumberOfDefinition");
/* 262 */     child.setUserObject(new Short(this.num));
/* 263 */     child.setNodeValue("" + this.num);
/* 264 */     node.appendChild(child);
/*     */     
/* 266 */     child = new IIOMetadataNode("Definitions");
/* 267 */     node.appendChild(child);
/*     */     
/* 269 */     for (int i = 0; i < this.num; i++) {
/* 270 */       IIOMetadataNode child1 = new IIOMetadataNode("ChannelNumber");
/* 271 */       child1.setUserObject(new Short(this.channels[i]));
/* 272 */       child1.setNodeValue("" + this.channels[i]);
/* 273 */       child.appendChild(child1);
/*     */       
/* 275 */       child1 = new IIOMetadataNode("ChannelType");
/* 276 */       child1.setUserObject(new Short(this.types[i]));
/* 277 */       child1.setNodeValue("" + this.types[i]);
/* 278 */       child.appendChild(child1);
/*     */       
/* 280 */       child1 = new IIOMetadataNode("Association");
/* 281 */       child1.setUserObject(new Short(this.associations[i]));
/* 282 */       child1.setNodeValue("" + this.associations[i]);
/* 283 */       child.appendChild(child1);
/*     */     } 
/*     */     
/* 286 */     return node;
/*     */   }
/*     */   
/*     */   protected void compose() {
/* 290 */     if (this.data != null)
/*     */       return; 
/* 292 */     int len = this.num * 6 + 2;
/* 293 */     this.data = new byte[len];
/* 294 */     this.data[0] = (byte)(this.num >> 8);
/* 295 */     this.data[1] = (byte)(this.num & 0xFF);
/*     */     
/* 297 */     for (int i = 0, j = 2; i < this.num; i++) {
/* 298 */       this.data[j++] = (byte)(this.channels[i] >> 8);
/* 299 */       this.data[j++] = (byte)(this.channels[i] & 0xFF);
/*     */       
/* 301 */       this.data[j++] = (byte)(this.types[i] >> 8);
/* 302 */       this.data[j++] = (byte)(this.types[i] & 0xFF);
/*     */       
/* 304 */       this.data[j++] = (byte)(this.associations[i] >> 8);
/* 305 */       this.data[j++] = (byte)(this.associations[i] & 0xFF);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/jpeg2000/ChannelDefinitionBox.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */