/*     */ package com.sun.media.imageioimpl.plugins.tiff;
/*     */ 
/*     */ import com.sun.media.imageioimpl.common.PackageUtil;
/*     */ import java.io.IOException;
/*     */ import java.util.Locale;
/*     */ import javax.imageio.ImageReader;
/*     */ import javax.imageio.spi.ImageReaderSpi;
/*     */ import javax.imageio.spi.ServiceRegistry;
/*     */ import javax.imageio.stream.ImageInputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TIFFImageReaderSpi
/*     */   extends ImageReaderSpi
/*     */ {
/*  93 */   private static final String[] names = new String[] { "tif", "TIF", "tiff", "TIFF" };
/*     */   
/*  95 */   private static final String[] suffixes = new String[] { "tif", "tiff" };
/*     */   
/*  97 */   private static final String[] MIMETypes = new String[] { "image/tiff" };
/*     */ 
/*     */   
/*     */   private static final String readerClassName = "com.sun.media.imageioimpl.plugins.tiff.TIFFImageReader";
/*     */   
/* 102 */   private static final String[] writerSpiNames = new String[] { "com.sun.media.imageioimpl.plugins.tiff.TIFFImageWriterSpi" };
/*     */ 
/*     */   
/*     */   private boolean registered = false;
/*     */ 
/*     */   
/*     */   public TIFFImageReaderSpi() {
/* 109 */     super(PackageUtil.getVendor(), PackageUtil.getVersion(), names, suffixes, MIMETypes, "com.sun.media.imageioimpl.plugins.tiff.TIFFImageReader", STANDARD_INPUT_TYPE, writerSpiNames, false, "com_sun_media_imageio_plugins_tiff_stream_1.0", "com.sun.media.imageioimpl.plugins.tiff.TIFFStreamMetadataFormat", null, null, true, "com_sun_media_imageio_plugins_tiff_image_1.0", "com.sun.media.imageioimpl.plugins.tiff.TIFFImageMetadataFormat", null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDescription(Locale locale) {
/* 129 */     String desc = PackageUtil.getSpecificationTitle() + " TIFF Image Reader";
/*     */     
/* 131 */     return desc;
/*     */   }
/*     */   
/*     */   public boolean canDecodeInput(Object input) throws IOException {
/* 135 */     if (!(input instanceof ImageInputStream)) {
/* 136 */       return false;
/*     */     }
/*     */     
/* 139 */     ImageInputStream stream = (ImageInputStream)input;
/* 140 */     byte[] b = new byte[4];
/* 141 */     stream.mark();
/* 142 */     stream.readFully(b);
/* 143 */     stream.reset();
/*     */     
/* 145 */     return ((b[0] == 73 && b[1] == 73 && b[2] == 42 && b[3] == 0) || (b[0] == 77 && b[1] == 77 && b[2] == 0 && b[3] == 42));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageReader createReaderInstance(Object extension) {
/* 152 */     return new TIFFImageReader(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onRegistration(ServiceRegistry registry, Class category) {
/* 157 */     if (this.registered) {
/*     */       return;
/*     */     }
/*     */     
/* 161 */     this.registered = true;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/loci_tools.jar!/com/sun/media/imageioimpl/plugins/tiff/TIFFImageReaderSpi.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */