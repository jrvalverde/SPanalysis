package org.jgrapht;

import org.jgrapht.event.GraphListener;
import org.jgrapht.event.VertexSetListener;

public interface ListenableGraph<V, E> extends Graph<V, E> {
  void addGraphListener(GraphListener<V, E> paramGraphListener);
  
  void addVertexSetListener(VertexSetListener<V> paramVertexSetListener);
  
  void removeGraphListener(GraphListener<V, E> paramGraphListener);
  
  void removeVertexSetListener(VertexSetListener<V> paramVertexSetListener);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/ListenableGraph.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */