package org.jgrapht.alg;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.jgrapht.Graph;
import org.jgrapht.Graphs;

abstract class AbstractPathElement<V, E> {
  protected int nHops;
  
  protected E prevEdge;
  
  protected AbstractPathElement<V, E> prevPathElement;
  
  private V vertex;
  
  protected AbstractPathElement(Graph<V, E> paramGraph, AbstractPathElement<V, E> paramAbstractPathElement, E paramE) {
    this.vertex = (V)Graphs.getOppositeVertex(paramGraph, paramE, paramAbstractPathElement.getVertex());
    this.prevEdge = paramE;
    this.prevPathElement = paramAbstractPathElement;
    this.nHops = paramAbstractPathElement.getHopCount() + 1;
  }
  
  protected AbstractPathElement(AbstractPathElement<V, E> paramAbstractPathElement) {
    this.nHops = paramAbstractPathElement.nHops;
    this.prevEdge = paramAbstractPathElement.prevEdge;
    this.prevPathElement = paramAbstractPathElement.prevPathElement;
    this.vertex = paramAbstractPathElement.vertex;
  }
  
  protected AbstractPathElement(V paramV) {
    this.vertex = paramV;
    this.prevEdge = null;
    this.prevPathElement = null;
    this.nHops = 0;
  }
  
  public List<E> createEdgeListPath() {
    ArrayList<?> arrayList = new ArrayList();
    for (AbstractPathElement abstractPathElement = this; abstractPathElement.getPrevEdge() != null; abstractPathElement = abstractPathElement.getPrevPathElement())
      arrayList.add(abstractPathElement.getPrevEdge()); 
    Collections.reverse(arrayList);
    return (List)arrayList;
  }
  
  public int getHopCount() {
    return this.nHops;
  }
  
  public E getPrevEdge() {
    return this.prevEdge;
  }
  
  public AbstractPathElement<V, E> getPrevPathElement() {
    return this.prevPathElement;
  }
  
  public V getVertex() {
    return this.vertex;
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/alg/AbstractPathElement.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */