package org.jgrapht.alg;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.jgrapht.DirectedGraph;
import org.jgrapht.Graph;
import org.jgrapht.UndirectedGraph;
import org.jgrapht.event.ConnectedComponentTraversalEvent;
import org.jgrapht.event.GraphEdgeChangeEvent;
import org.jgrapht.event.GraphListener;
import org.jgrapht.event.GraphVertexChangeEvent;
import org.jgrapht.event.TraversalListener;
import org.jgrapht.event.TraversalListenerAdapter;
import org.jgrapht.event.VertexTraversalEvent;
import org.jgrapht.graph.AsUndirectedGraph;
import org.jgrapht.traverse.BreadthFirstIterator;

public class ConnectivityInspector<V, E> implements GraphListener<V, E> {
  List<Set<V>> connectedSets;
  
  Map<V, Set<V>> vertexToConnectedSet;
  
  private Graph<V, E> graph;
  
  public ConnectivityInspector(UndirectedGraph<V, E> paramUndirectedGraph) {
    init();
    this.graph = (Graph<V, E>)paramUndirectedGraph;
  }
  
  public ConnectivityInspector(DirectedGraph<V, E> paramDirectedGraph) {
    init();
    this.graph = (Graph<V, E>)new AsUndirectedGraph(paramDirectedGraph);
  }
  
  public boolean isGraphConnected() {
    return (lazyFindConnectedSets().size() == 1);
  }
  
  public Set<V> connectedSetOf(V paramV) {
    Set<Object> set = (Set)this.vertexToConnectedSet.get(paramV);
    if (set == null) {
      set = new HashSet();
      BreadthFirstIterator breadthFirstIterator = new BreadthFirstIterator(this.graph, paramV);
      while (breadthFirstIterator.hasNext())
        set.add(breadthFirstIterator.next()); 
      this.vertexToConnectedSet.put(paramV, set);
    } 
    return (Set)set;
  }
  
  public List<Set<V>> connectedSets() {
    return lazyFindConnectedSets();
  }
  
  public void edgeAdded(GraphEdgeChangeEvent<V, E> paramGraphEdgeChangeEvent) {
    init();
  }
  
  public void edgeRemoved(GraphEdgeChangeEvent<V, E> paramGraphEdgeChangeEvent) {
    init();
  }
  
  public boolean pathExists(V paramV1, V paramV2) {
    Set<V> set = connectedSetOf(paramV1);
    return set.contains(paramV2);
  }
  
  public void vertexAdded(GraphVertexChangeEvent<V> paramGraphVertexChangeEvent) {
    init();
  }
  
  public void vertexRemoved(GraphVertexChangeEvent<V> paramGraphVertexChangeEvent) {
    init();
  }
  
  private void init() {
    this.connectedSets = null;
    this.vertexToConnectedSet = new HashMap<V, Set<V>>();
  }
  
  private List<Set<V>> lazyFindConnectedSets() {
    if (this.connectedSets == null) {
      this.connectedSets = new ArrayList<Set<V>>();
      Set set = this.graph.vertexSet();
      if (set.size() > 0) {
        BreadthFirstIterator breadthFirstIterator = new BreadthFirstIterator(this.graph, null);
        breadthFirstIterator.addTraversalListener((TraversalListener)new MyTraversalListener());
        while (breadthFirstIterator.hasNext())
          breadthFirstIterator.next(); 
      } 
    } 
    return this.connectedSets;
  }
  
  private class MyTraversalListener extends TraversalListenerAdapter<V, E> {
    private Set<V> currentConnectedSet;
    
    private MyTraversalListener() {}
    
    public void connectedComponentFinished(ConnectedComponentTraversalEvent param1ConnectedComponentTraversalEvent) {
      ConnectivityInspector.this.connectedSets.add(this.currentConnectedSet);
    }
    
    public void connectedComponentStarted(ConnectedComponentTraversalEvent param1ConnectedComponentTraversalEvent) {
      this.currentConnectedSet = new HashSet<V>();
    }
    
    public void vertexTraversed(VertexTraversalEvent<V> param1VertexTraversalEvent) {
      Object object = param1VertexTraversalEvent.getVertex();
      this.currentConnectedSet.add((V)object);
      ConnectivityInspector.this.vertexToConnectedSet.put(object, this.currentConnectedSet);
    }
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/alg/ConnectivityInspector.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */