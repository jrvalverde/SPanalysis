package org.jgrapht.alg;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Set;
import org.jgrapht.Graph;

public class BronKerboschCliqueFinder<V, E> {
  private final Graph<V, E> graph;
  
  private Collection<Set<V>> cliques;
  
  public BronKerboschCliqueFinder(Graph<V, E> paramGraph) {
    this.graph = paramGraph;
  }
  
  public Collection<Set<V>> getAllMaximalCliques() {
    this.cliques = new ArrayList<Set<V>>();
    ArrayList<V> arrayList1 = new ArrayList();
    ArrayList<V> arrayList2 = new ArrayList();
    ArrayList<V> arrayList3 = new ArrayList();
    arrayList2.addAll(this.graph.vertexSet());
    findCliques(arrayList1, arrayList2, arrayList3);
    return this.cliques;
  }
  
  public Collection<Set<V>> getBiggestMaximalCliques() {
    getAllMaximalCliques();
    int i = 0;
    ArrayList<Set> arrayList = new ArrayList();
    for (Set<V> set : this.cliques) {
      if (i < set.size())
        i = set.size(); 
    } 
    for (Set<V> set : this.cliques) {
      if (i == set.size())
        arrayList.add(set); 
    } 
    return (Collection)arrayList;
  }
  
  private void findCliques(List<V> paramList1, List<V> paramList2, List<V> paramList3) {
    // Byte code:
    //   0: new java/util/ArrayList
    //   3: dup
    //   4: aload_2
    //   5: invokespecial <init> : (Ljava/util/Collection;)V
    //   8: astore #4
    //   10: aload_0
    //   11: aload_2
    //   12: aload_3
    //   13: invokespecial end : (Ljava/util/List;Ljava/util/List;)Z
    //   16: ifne -> 266
    //   19: aload #4
    //   21: invokeinterface iterator : ()Ljava/util/Iterator;
    //   26: astore #5
    //   28: aload #5
    //   30: invokeinterface hasNext : ()Z
    //   35: ifeq -> 266
    //   38: aload #5
    //   40: invokeinterface next : ()Ljava/lang/Object;
    //   45: astore #6
    //   47: new java/util/ArrayList
    //   50: dup
    //   51: invokespecial <init> : ()V
    //   54: astore #7
    //   56: new java/util/ArrayList
    //   59: dup
    //   60: invokespecial <init> : ()V
    //   63: astore #8
    //   65: aload_1
    //   66: aload #6
    //   68: invokeinterface add : (Ljava/lang/Object;)Z
    //   73: pop
    //   74: aload_2
    //   75: aload #6
    //   77: invokeinterface remove : (Ljava/lang/Object;)Z
    //   82: pop
    //   83: aload_2
    //   84: invokeinterface iterator : ()Ljava/util/Iterator;
    //   89: astore #9
    //   91: aload #9
    //   93: invokeinterface hasNext : ()Z
    //   98: ifeq -> 139
    //   101: aload #9
    //   103: invokeinterface next : ()Ljava/lang/Object;
    //   108: astore #10
    //   110: aload_0
    //   111: getfield graph : Lorg/jgrapht/Graph;
    //   114: aload #6
    //   116: aload #10
    //   118: invokeinterface containsEdge : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   123: ifeq -> 136
    //   126: aload #7
    //   128: aload #10
    //   130: invokeinterface add : (Ljava/lang/Object;)Z
    //   135: pop
    //   136: goto -> 91
    //   139: aload_3
    //   140: invokeinterface iterator : ()Ljava/util/Iterator;
    //   145: astore #9
    //   147: aload #9
    //   149: invokeinterface hasNext : ()Z
    //   154: ifeq -> 195
    //   157: aload #9
    //   159: invokeinterface next : ()Ljava/lang/Object;
    //   164: astore #10
    //   166: aload_0
    //   167: getfield graph : Lorg/jgrapht/Graph;
    //   170: aload #6
    //   172: aload #10
    //   174: invokeinterface containsEdge : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   179: ifeq -> 192
    //   182: aload #8
    //   184: aload #10
    //   186: invokeinterface add : (Ljava/lang/Object;)Z
    //   191: pop
    //   192: goto -> 147
    //   195: aload #7
    //   197: invokeinterface isEmpty : ()Z
    //   202: ifeq -> 236
    //   205: aload #8
    //   207: invokeinterface isEmpty : ()Z
    //   212: ifeq -> 236
    //   215: aload_0
    //   216: getfield cliques : Ljava/util/Collection;
    //   219: new java/util/HashSet
    //   222: dup
    //   223: aload_1
    //   224: invokespecial <init> : (Ljava/util/Collection;)V
    //   227: invokeinterface add : (Ljava/lang/Object;)Z
    //   232: pop
    //   233: goto -> 245
    //   236: aload_0
    //   237: aload_1
    //   238: aload #7
    //   240: aload #8
    //   242: invokespecial findCliques : (Ljava/util/List;Ljava/util/List;Ljava/util/List;)V
    //   245: aload_3
    //   246: aload #6
    //   248: invokeinterface add : (Ljava/lang/Object;)Z
    //   253: pop
    //   254: aload_1
    //   255: aload #6
    //   257: invokeinterface remove : (Ljava/lang/Object;)Z
    //   262: pop
    //   263: goto -> 28
    //   266: return
  }
  
  private boolean end(List<V> paramList1, List<V> paramList2) {
    // Byte code:
    //   0: iconst_0
    //   1: istore_3
    //   2: aload_2
    //   3: invokeinterface iterator : ()Ljava/util/Iterator;
    //   8: astore #5
    //   10: aload #5
    //   12: invokeinterface hasNext : ()Z
    //   17: ifeq -> 97
    //   20: aload #5
    //   22: invokeinterface next : ()Ljava/lang/Object;
    //   27: astore #6
    //   29: iconst_0
    //   30: istore #4
    //   32: aload_1
    //   33: invokeinterface iterator : ()Ljava/util/Iterator;
    //   38: astore #7
    //   40: aload #7
    //   42: invokeinterface hasNext : ()Z
    //   47: ifeq -> 81
    //   50: aload #7
    //   52: invokeinterface next : ()Ljava/lang/Object;
    //   57: astore #8
    //   59: aload_0
    //   60: getfield graph : Lorg/jgrapht/Graph;
    //   63: aload #6
    //   65: aload #8
    //   67: invokeinterface containsEdge : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   72: ifeq -> 78
    //   75: iinc #4, 1
    //   78: goto -> 40
    //   81: iload #4
    //   83: aload_1
    //   84: invokeinterface size : ()I
    //   89: if_icmpne -> 94
    //   92: iconst_1
    //   93: istore_3
    //   94: goto -> 10
    //   97: iload_3
    //   98: ireturn
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/alg/BronKerboschCliqueFinder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */