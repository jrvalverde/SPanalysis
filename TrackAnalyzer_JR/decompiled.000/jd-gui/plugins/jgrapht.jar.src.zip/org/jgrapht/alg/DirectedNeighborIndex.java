package org.jgrapht.alg;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.jgrapht.DirectedGraph;
import org.jgrapht.Graphs;
import org.jgrapht.event.GraphEdgeChangeEvent;
import org.jgrapht.event.GraphListener;
import org.jgrapht.event.GraphVertexChangeEvent;

public class DirectedNeighborIndex<V, E> implements GraphListener<V, E> {
  Map<V, NeighborIndex.Neighbors<V, E>> predecessorMap = new HashMap<V, NeighborIndex.Neighbors<V, E>>();
  
  Map<V, NeighborIndex.Neighbors<V, E>> successorMap = new HashMap<V, NeighborIndex.Neighbors<V, E>>();
  
  private DirectedGraph<V, E> graph;
  
  public DirectedNeighborIndex(DirectedGraph<V, E> paramDirectedGraph) {
    this.graph = paramDirectedGraph;
  }
  
  public Set<V> predecessorsOf(V paramV) {
    return getPredecessors(paramV).getNeighbors();
  }
  
  public List<V> predecessorListOf(V paramV) {
    return getPredecessors(paramV).getNeighborList();
  }
  
  public Set<V> successorsOf(V paramV) {
    return getSuccessors(paramV).getNeighbors();
  }
  
  public List<V> successorListOf(V paramV) {
    return getSuccessors(paramV).getNeighborList();
  }
  
  public void edgeAdded(GraphEdgeChangeEvent<V, E> paramGraphEdgeChangeEvent) {
    Object object1 = paramGraphEdgeChangeEvent.getEdge();
    Object object2 = this.graph.getEdgeSource(object1);
    Object object3 = this.graph.getEdgeTarget(object1);
    if (this.successorMap.containsKey(object2)) {
      getSuccessors((V)object2).addNeighbor((V)object3);
    } else {
      getSuccessors((V)object2);
    } 
    if (this.predecessorMap.containsKey(object3)) {
      getPredecessors((V)object3).addNeighbor((V)object2);
    } else {
      getPredecessors((V)object3);
    } 
  }
  
  public void edgeRemoved(GraphEdgeChangeEvent<V, E> paramGraphEdgeChangeEvent) {
    Object object1 = paramGraphEdgeChangeEvent.getEdge();
    Object object2 = this.graph.getEdgeSource(object1);
    Object object3 = this.graph.getEdgeTarget(object1);
    if (this.successorMap.containsKey(object2))
      ((NeighborIndex.Neighbors)this.successorMap.get(object2)).removeNeighbor(object3); 
    if (this.predecessorMap.containsKey(object3))
      ((NeighborIndex.Neighbors)this.predecessorMap.get(object3)).removeNeighbor(object2); 
  }
  
  public void vertexAdded(GraphVertexChangeEvent<V> paramGraphVertexChangeEvent) {}
  
  public void vertexRemoved(GraphVertexChangeEvent<V> paramGraphVertexChangeEvent) {
    this.predecessorMap.remove(paramGraphVertexChangeEvent.getVertex());
    this.successorMap.remove(paramGraphVertexChangeEvent.getVertex());
  }
  
  private NeighborIndex.Neighbors<V, E> getPredecessors(V paramV) {
    NeighborIndex.Neighbors<V, Object> neighbors = (NeighborIndex.Neighbors)this.predecessorMap.get(paramV);
    if (neighbors == null) {
      neighbors = new NeighborIndex.Neighbors<V, Object>(paramV, Graphs.predecessorListOf(this.graph, paramV));
      this.predecessorMap.put(paramV, neighbors);
    } 
    return (NeighborIndex.Neighbors)neighbors;
  }
  
  private NeighborIndex.Neighbors<V, E> getSuccessors(V paramV) {
    NeighborIndex.Neighbors<V, Object> neighbors = (NeighborIndex.Neighbors)this.successorMap.get(paramV);
    if (neighbors == null) {
      neighbors = new NeighborIndex.Neighbors<V, Object>(paramV, Graphs.successorListOf(this.graph, paramV));
      this.successorMap.put(paramV, neighbors);
    } 
    return (NeighborIndex.Neighbors)neighbors;
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/alg/DirectedNeighborIndex.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */