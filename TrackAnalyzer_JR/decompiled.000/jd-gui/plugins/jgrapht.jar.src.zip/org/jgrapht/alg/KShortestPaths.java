package org.jgrapht.alg;

import java.util.ArrayList;
import java.util.List;
import org.jgrapht.Graph;
import org.jgrapht.GraphPath;

public class KShortestPaths<V, E> {
  private Graph<V, E> graph;
  
  private int nMaxHops;
  
  private int nPaths;
  
  private V startVertex;
  
  public KShortestPaths(Graph<V, E> paramGraph, V paramV, int paramInt) {
    this(paramGraph, paramV, paramInt, paramGraph.vertexSet().size() - 1);
  }
  
  public KShortestPaths(Graph<V, E> paramGraph, V paramV, int paramInt1, int paramInt2) {
    assertKShortestPathsFinder(paramGraph, paramV, paramInt1, paramInt2);
    this.graph = paramGraph;
    this.startVertex = paramV;
    this.nPaths = paramInt1;
    this.nMaxHops = paramInt2;
  }
  
  public List<GraphPath<V, E>> getPaths(V paramV) {
    assertGetPaths(paramV);
    KShortestPathsIterator<V, E> kShortestPathsIterator = new KShortestPathsIterator<V, E>(this.graph, this.startVertex, paramV, this.nPaths);
    for (byte b = 1; b <= this.nMaxHops && kShortestPathsIterator.hasNext(); b++)
      kShortestPathsIterator.next(); 
    RankingPathElementList<V, E> rankingPathElementList = kShortestPathsIterator.getPathElements(paramV);
    if (rankingPathElementList == null)
      return null; 
    ArrayList<PathWrapper> arrayList = new ArrayList();
    for (RankingPathElement<V, E> rankingPathElement : rankingPathElementList)
      arrayList.add(new PathWrapper(rankingPathElement)); 
    return (List)arrayList;
  }
  
  private void assertGetPaths(V paramV) {
    if (paramV == null)
      throw new NullPointerException("endVertex is null"); 
    if (paramV.equals(this.startVertex))
      throw new IllegalArgumentException("The end vertex is the same as the start vertex!"); 
    if (!this.graph.vertexSet().contains(paramV))
      throw new IllegalArgumentException("Graph must contain the end vertex!"); 
  }
  
  private void assertKShortestPathsFinder(Graph<V, E> paramGraph, V paramV, int paramInt1, int paramInt2) {
    if (paramGraph == null)
      throw new NullPointerException("graph is null"); 
    if (paramV == null)
      throw new NullPointerException("startVertex is null"); 
    if (paramInt1 <= 0)
      throw new NullPointerException("nPaths is negative or 0"); 
    if (paramInt2 <= 0)
      throw new NullPointerException("nMaxHops is negative or 0"); 
  }
  
  private class PathWrapper implements GraphPath<V, E> {
    private RankingPathElement<V, E> rankingPathElement;
    
    private List<E> edgeList;
    
    PathWrapper(RankingPathElement<V, E> param1RankingPathElement) {
      this.rankingPathElement = param1RankingPathElement;
    }
    
    public Graph<V, E> getGraph() {
      return KShortestPaths.this.graph;
    }
    
    public V getStartVertex() {
      return KShortestPaths.this.startVertex;
    }
    
    public V getEndVertex() {
      return this.rankingPathElement.getVertex();
    }
    
    public List<E> getEdgeList() {
      if (this.edgeList == null)
        this.edgeList = this.rankingPathElement.createEdgeListPath(); 
      return this.edgeList;
    }
    
    public double getWeight() {
      return this.rankingPathElement.getWeight();
    }
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/alg/KShortestPaths.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */