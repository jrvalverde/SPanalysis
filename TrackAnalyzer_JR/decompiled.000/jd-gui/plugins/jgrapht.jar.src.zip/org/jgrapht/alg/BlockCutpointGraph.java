package org.jgrapht.alg;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.Stack;
import org.jgrapht.DirectedGraph;
import org.jgrapht.Graph;
import org.jgrapht.Graphs;
import org.jgrapht.UndirectedGraph;
import org.jgrapht.graph.DefaultEdge;
import org.jgrapht.graph.MaskFunctor;
import org.jgrapht.graph.SimpleGraph;

public class BlockCutpointGraph<V, E> extends SimpleGraph<UndirectedGraph<V, E>, DefaultEdge> {
  private static final long serialVersionUID = -9101341117013163934L;
  
  private Set<V> cutpoints;
  
  private DirectedGraph<V, DefaultEdge> dfsTree;
  
  private UndirectedGraph<V, E> graph;
  
  private int numOrder;
  
  private Stack<BCGEdge> stack;
  
  private Map<V, Set<UndirectedGraph<V, E>>> vertex2biconnectedSubgraphs;
  
  private Map<V, UndirectedGraph<V, E>> vertex2block;
  
  private Map<V, Integer> vertex2numOrder;
  
  public BlockCutpointGraph(UndirectedGraph<V, E> paramUndirectedGraph) {
    // Byte code:
    //   0: aload_0
    //   1: ldc_w org/jgrapht/graph/DefaultEdge
    //   4: invokespecial <init> : (Ljava/lang/Class;)V
    //   7: aload_0
    //   8: new java/util/HashSet
    //   11: dup
    //   12: invokespecial <init> : ()V
    //   15: putfield cutpoints : Ljava/util/Set;
    //   18: aload_0
    //   19: new java/util/Stack
    //   22: dup
    //   23: invokespecial <init> : ()V
    //   26: putfield stack : Ljava/util/Stack;
    //   29: aload_0
    //   30: new java/util/HashMap
    //   33: dup
    //   34: invokespecial <init> : ()V
    //   37: putfield vertex2biconnectedSubgraphs : Ljava/util/Map;
    //   40: aload_0
    //   41: new java/util/HashMap
    //   44: dup
    //   45: invokespecial <init> : ()V
    //   48: putfield vertex2block : Ljava/util/Map;
    //   51: aload_0
    //   52: new java/util/HashMap
    //   55: dup
    //   56: invokespecial <init> : ()V
    //   59: putfield vertex2numOrder : Ljava/util/Map;
    //   62: aload_0
    //   63: aload_1
    //   64: putfield graph : Lorg/jgrapht/UndirectedGraph;
    //   67: aload_0
    //   68: new org/jgrapht/graph/SimpleDirectedGraph
    //   71: dup
    //   72: ldc_w org/jgrapht/graph/DefaultEdge
    //   75: invokespecial <init> : (Ljava/lang/Class;)V
    //   78: putfield dfsTree : Lorg/jgrapht/DirectedGraph;
    //   81: aload_1
    //   82: invokeinterface vertexSet : ()Ljava/util/Set;
    //   87: invokeinterface iterator : ()Ljava/util/Iterator;
    //   92: invokeinterface next : ()Ljava/lang/Object;
    //   97: astore_2
    //   98: aload_0
    //   99: getfield dfsTree : Lorg/jgrapht/DirectedGraph;
    //   102: aload_2
    //   103: invokeinterface addVertex : (Ljava/lang/Object;)Z
    //   108: pop
    //   109: aload_0
    //   110: aload_2
    //   111: aload_2
    //   112: invokespecial dfsVisit : (Ljava/lang/Object;Ljava/lang/Object;)I
    //   115: pop
    //   116: aload_0
    //   117: getfield dfsTree : Lorg/jgrapht/DirectedGraph;
    //   120: aload_2
    //   121: invokeinterface edgesOf : (Ljava/lang/Object;)Ljava/util/Set;
    //   126: invokeinterface size : ()I
    //   131: iconst_1
    //   132: if_icmple -> 149
    //   135: aload_0
    //   136: getfield cutpoints : Ljava/util/Set;
    //   139: aload_2
    //   140: invokeinterface add : (Ljava/lang/Object;)Z
    //   145: pop
    //   146: goto -> 160
    //   149: aload_0
    //   150: getfield cutpoints : Ljava/util/Set;
    //   153: aload_2
    //   154: invokeinterface remove : (Ljava/lang/Object;)Z
    //   159: pop
    //   160: aload_0
    //   161: getfield cutpoints : Ljava/util/Set;
    //   164: invokeinterface iterator : ()Ljava/util/Iterator;
    //   169: astore_3
    //   170: aload_3
    //   171: invokeinterface hasNext : ()Z
    //   176: ifeq -> 318
    //   179: aload_3
    //   180: invokeinterface next : ()Ljava/lang/Object;
    //   185: astore #4
    //   187: new org/jgrapht/graph/SimpleGraph
    //   190: dup
    //   191: aload_0
    //   192: getfield graph : Lorg/jgrapht/UndirectedGraph;
    //   195: invokeinterface getEdgeFactory : ()Lorg/jgrapht/EdgeFactory;
    //   200: invokespecial <init> : (Lorg/jgrapht/EdgeFactory;)V
    //   203: astore #5
    //   205: aload #5
    //   207: aload #4
    //   209: invokeinterface addVertex : (Ljava/lang/Object;)Z
    //   214: pop
    //   215: aload_0
    //   216: getfield vertex2block : Ljava/util/Map;
    //   219: aload #4
    //   221: aload #5
    //   223: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   228: pop
    //   229: aload_0
    //   230: aload #5
    //   232: invokevirtual addVertex : (Ljava/lang/Object;)Z
    //   235: pop
    //   236: aload_0
    //   237: aload #4
    //   239: invokespecial getBiconnectedSubgraphs : (Ljava/lang/Object;)Ljava/util/Set;
    //   242: astore #6
    //   244: aload #6
    //   246: invokeinterface iterator : ()Ljava/util/Iterator;
    //   251: astore #7
    //   253: aload #7
    //   255: invokeinterface hasNext : ()Z
    //   260: ifeq -> 315
    //   263: aload #7
    //   265: invokeinterface next : ()Ljava/lang/Object;
    //   270: checkcast org/jgrapht/UndirectedGraph
    //   273: astore #8
    //   275: getstatic org/jgrapht/alg/BlockCutpointGraph.$assertionsDisabled : Z
    //   278: ifne -> 303
    //   281: aload_0
    //   282: invokevirtual vertexSet : ()Ljava/util/Set;
    //   285: aload #8
    //   287: invokeinterface contains : (Ljava/lang/Object;)Z
    //   292: ifne -> 303
    //   295: new java/lang/AssertionError
    //   298: dup
    //   299: invokespecial <init> : ()V
    //   302: athrow
    //   303: aload_0
    //   304: aload #5
    //   306: aload #8
    //   308: invokevirtual addEdge : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   311: pop
    //   312: goto -> 253
    //   315: goto -> 170
    //   318: return
  }
  
  public UndirectedGraph<V, E> getBlock(V paramV) {
    if (!this.graph.vertexSet().contains(paramV))
      throw new IllegalArgumentException("No such vertex in the graph!"); 
    return this.vertex2block.get(paramV);
  }
  
  public Set<V> getCutpoints() {
    return this.cutpoints;
  }
  
  public boolean isCutpoint(V paramV) {
    if (!this.graph.vertexSet().contains(paramV))
      throw new IllegalArgumentException("No such vertex in the graph!"); 
    return this.cutpoints.contains(paramV);
  }
  
  private void biconnectedComponentFinished(V paramV1, V paramV2) {
    // Byte code:
    //   0: aload_0
    //   1: getfield cutpoints : Ljava/util/Set;
    //   4: aload_1
    //   5: invokeinterface add : (Ljava/lang/Object;)Z
    //   10: pop
    //   11: new java/util/HashSet
    //   14: dup
    //   15: invokespecial <init> : ()V
    //   18: astore_3
    //   19: new java/util/HashSet
    //   22: dup
    //   23: invokespecial <init> : ()V
    //   26: astore #4
    //   28: aload_0
    //   29: getfield stack : Ljava/util/Stack;
    //   32: invokevirtual pop : ()Ljava/lang/Object;
    //   35: checkcast org/jgrapht/alg/BlockCutpointGraph$BCGEdge
    //   38: astore #5
    //   40: aload_0
    //   41: aload #5
    //   43: invokevirtual getSource : ()Ljava/lang/Object;
    //   46: invokespecial getNumOrder : (Ljava/lang/Object;)I
    //   49: aload_0
    //   50: aload_2
    //   51: invokespecial getNumOrder : (Ljava/lang/Object;)I
    //   54: if_icmplt -> 116
    //   57: aload_0
    //   58: getfield stack : Ljava/util/Stack;
    //   61: invokevirtual isEmpty : ()Z
    //   64: ifne -> 116
    //   67: aload #4
    //   69: aload #5
    //   71: invokeinterface add : (Ljava/lang/Object;)Z
    //   76: pop
    //   77: aload_3
    //   78: aload #5
    //   80: invokevirtual getSource : ()Ljava/lang/Object;
    //   83: invokeinterface add : (Ljava/lang/Object;)Z
    //   88: pop
    //   89: aload_3
    //   90: aload #5
    //   92: invokevirtual getTarget : ()Ljava/lang/Object;
    //   95: invokeinterface add : (Ljava/lang/Object;)Z
    //   100: pop
    //   101: aload_0
    //   102: getfield stack : Ljava/util/Stack;
    //   105: invokevirtual pop : ()Ljava/lang/Object;
    //   108: checkcast org/jgrapht/alg/BlockCutpointGraph$BCGEdge
    //   111: astore #5
    //   113: goto -> 40
    //   116: aload #4
    //   118: aload #5
    //   120: invokeinterface add : (Ljava/lang/Object;)Z
    //   125: pop
    //   126: aload_3
    //   127: aload #5
    //   129: invokevirtual getSource : ()Ljava/lang/Object;
    //   132: invokeinterface add : (Ljava/lang/Object;)Z
    //   137: pop
    //   138: aload_3
    //   139: aload #5
    //   141: invokevirtual getTarget : ()Ljava/lang/Object;
    //   144: invokeinterface add : (Ljava/lang/Object;)Z
    //   149: pop
    //   150: new org/jgrapht/alg/BlockCutpointGraph$VertexComponentForbiddenFunction
    //   153: dup
    //   154: aload_0
    //   155: aload_3
    //   156: invokespecial <init> : (Lorg/jgrapht/alg/BlockCutpointGraph;Ljava/util/Set;)V
    //   159: astore #6
    //   161: new org/jgrapht/graph/UndirectedMaskSubgraph
    //   164: dup
    //   165: aload_0
    //   166: getfield graph : Lorg/jgrapht/UndirectedGraph;
    //   169: aload #6
    //   171: invokespecial <init> : (Lorg/jgrapht/UndirectedGraph;Lorg/jgrapht/graph/MaskFunctor;)V
    //   174: astore #7
    //   176: aload_3
    //   177: invokeinterface iterator : ()Ljava/util/Iterator;
    //   182: astore #8
    //   184: aload #8
    //   186: invokeinterface hasNext : ()Z
    //   191: ifeq -> 234
    //   194: aload #8
    //   196: invokeinterface next : ()Ljava/lang/Object;
    //   201: astore #9
    //   203: aload_0
    //   204: getfield vertex2block : Ljava/util/Map;
    //   207: aload #9
    //   209: aload #7
    //   211: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   216: pop
    //   217: aload_0
    //   218: aload #9
    //   220: invokespecial getBiconnectedSubgraphs : (Ljava/lang/Object;)Ljava/util/Set;
    //   223: aload #7
    //   225: invokeinterface add : (Ljava/lang/Object;)Z
    //   230: pop
    //   231: goto -> 184
    //   234: aload_0
    //   235: aload #7
    //   237: invokevirtual addVertex : (Ljava/lang/Object;)Z
    //   240: pop
    //   241: return
  }
  
  private int dfsVisit(V paramV1, V paramV2) {
    int i = ++this.numOrder;
    setNumOrder(paramV1, this.numOrder);
    for (Object object : this.graph.edgesOf(paramV1)) {
      Object object1 = Graphs.getOppositeVertex((Graph)this.graph, object, paramV1);
      if (getNumOrder((V)object1) == 0) {
        this.dfsTree.addVertex(object1);
        BCGEdge bCGEdge = new BCGEdge(paramV1, (V)object1);
        this.dfsTree.addEdge(paramV1, object1, bCGEdge);
        this.stack.push(bCGEdge);
        int j = dfsVisit((V)object1, paramV1);
        i = Math.min(j, i);
        if (j >= getNumOrder(paramV1))
          biconnectedComponentFinished(paramV1, (V)object1); 
        continue;
      } 
      if (getNumOrder((V)object1) < getNumOrder(paramV1) && !object1.equals(paramV2)) {
        BCGEdge bCGEdge = new BCGEdge(paramV1, (V)object1);
        this.stack.push(bCGEdge);
        i = Math.min(getNumOrder((V)object1), i);
      } 
    } 
    return i;
  }
  
  private Set<UndirectedGraph<V, E>> getBiconnectedSubgraphs(V paramV) {
    Set<UndirectedGraph<V, E>> set = this.vertex2biconnectedSubgraphs.get(paramV);
    if (set == null) {
      set = new HashSet();
      this.vertex2biconnectedSubgraphs.put(paramV, set);
    } 
    return set;
  }
  
  private int getNumOrder(V paramV) {
    assert paramV != null;
    Integer integer = this.vertex2numOrder.get(paramV);
    return (integer == null) ? 0 : integer.intValue();
  }
  
  private void setNumOrder(V paramV, int paramInt) {
    this.vertex2numOrder.put(paramV, Integer.valueOf(paramInt));
  }
  
  private class VertexComponentForbiddenFunction implements MaskFunctor<V, E> {
    private Set<V> vertexComponent;
    
    public VertexComponentForbiddenFunction(Set<V> param1Set) {
      this.vertexComponent = param1Set;
    }
    
    public boolean isEdgeMasked(E param1E) {
      return false;
    }
    
    public boolean isVertexMasked(V param1V) {
      return !this.vertexComponent.contains(param1V);
    }
  }
  
  private class BCGEdge extends DefaultEdge {
    private static final long serialVersionUID = -5115006161815760059L;
    
    private V source;
    
    private V target;
    
    public BCGEdge(V param1V1, V param1V2) {
      this.source = param1V1;
      this.target = param1V2;
    }
    
    public V getSource() {
      return this.source;
    }
    
    public V getTarget() {
      return this.target;
    }
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/alg/BlockCutpointGraph.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */