package org.jgrapht.alg;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.jgrapht.Graph;
import org.jgrapht.Graphs;
import org.jgrapht.traverse.ClosestFirstIterator;

public final class DijkstraShortestPath<V, E> {
  private List<E> edgeList;
  
  private double pathLength;
  
  public DijkstraShortestPath(Graph<V, E> paramGraph, V paramV1, V paramV2) {
    this(paramGraph, paramV1, paramV2, Double.POSITIVE_INFINITY);
  }
  
  public DijkstraShortestPath(Graph<V, E> paramGraph, V paramV1, V paramV2, double paramDouble) {
    if (!paramGraph.containsVertex(paramV2))
      throw new IllegalArgumentException("graph must contain the end vertex"); 
    ClosestFirstIterator<V, E> closestFirstIterator = new ClosestFirstIterator(paramGraph, paramV1, paramDouble);
    while (closestFirstIterator.hasNext()) {
      Object object = closestFirstIterator.next();
      if (object.equals(paramV2)) {
        createEdgeList(paramGraph, closestFirstIterator, paramV2);
        this.pathLength = closestFirstIterator.getShortestPathLength(paramV2);
        return;
      } 
    } 
    this.edgeList = null;
    this.pathLength = Double.POSITIVE_INFINITY;
  }
  
  public List<E> getPathEdgeList() {
    return this.edgeList;
  }
  
  public double getPathLength() {
    return this.pathLength;
  }
  
  public static <V, E> List<E> findPathBetween(Graph<V, E> paramGraph, V paramV1, V paramV2) {
    DijkstraShortestPath<V, E> dijkstraShortestPath = new DijkstraShortestPath<V, E>(paramGraph, paramV1, paramV2);
    return dijkstraShortestPath.getPathEdgeList();
  }
  
  private void createEdgeList(Graph<V, E> paramGraph, ClosestFirstIterator<V, E> paramClosestFirstIterator, V paramV) {
    this.edgeList = new ArrayList<E>();
    while (true) {
      Object object = paramClosestFirstIterator.getSpanningTreeEdge(paramV);
      if (object == null) {
        Collections.reverse(this.edgeList);
        return;
      } 
      this.edgeList.add((E)object);
      paramV = (V)Graphs.getOppositeVertex(paramGraph, object, paramV);
    } 
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/alg/DijkstraShortestPath.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */