package org.jgrapht.alg;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Stack;
import java.util.Vector;
import org.jgrapht.DirectedGraph;
import org.jgrapht.Graphs;
import org.jgrapht.graph.DefaultDirectedGraph;
import org.jgrapht.graph.DirectedSubgraph;

public class StrongConnectivityInspector<V, E> {
  private final DirectedGraph<V, E> graph;
  
  private LinkedList<VertexData<V>> orderedVertices;
  
  private List<Set<V>> stronglyConnectedSets;
  
  private List<DirectedSubgraph<V, E>> stronglyConnectedSubgraphs;
  
  private Map<V, VertexData<V>> vertexToVertexData;
  
  public StrongConnectivityInspector(DirectedGraph<V, E> paramDirectedGraph) {
    if (paramDirectedGraph == null)
      throw new IllegalArgumentException("null not allowed for graph!"); 
    this.graph = paramDirectedGraph;
    this.vertexToVertexData = null;
    this.orderedVertices = null;
    this.stronglyConnectedSets = null;
    this.stronglyConnectedSubgraphs = null;
  }
  
  public DirectedGraph<V, E> getGraph() {
    return this.graph;
  }
  
  public boolean isStronglyConnected() {
    return (stronglyConnectedSets().size() == 1);
  }
  
  public List<Set<V>> stronglyConnectedSets() {
    if (this.stronglyConnectedSets == null) {
      this.orderedVertices = new LinkedList<VertexData<V>>();
      this.stronglyConnectedSets = new Vector<Set<V>>();
      createVertexData();
      for (VertexData<V> vertexData : this.vertexToVertexData.values()) {
        if (!vertexData.discovered)
          dfsVisit(this.graph, vertexData, null); 
      } 
      DefaultDirectedGraph defaultDirectedGraph = new DefaultDirectedGraph(this.graph.getEdgeFactory());
      Graphs.addGraphReversed((DirectedGraph)defaultDirectedGraph, this.graph);
      resetVertexData();
      for (VertexData<V> vertexData : this.orderedVertices) {
        if (!vertexData.discovered) {
          HashSet<V> hashSet = new HashSet();
          this.stronglyConnectedSets.add(hashSet);
          dfsVisit((DirectedGraph<V, E>)defaultDirectedGraph, vertexData, hashSet);
        } 
      } 
      this.orderedVertices = null;
      this.vertexToVertexData = null;
    } 
    return this.stronglyConnectedSets;
  }
  
  public List<DirectedSubgraph<V, E>> stronglyConnectedSubgraphs() {
    if (this.stronglyConnectedSubgraphs == null) {
      List<Set<V>> list = stronglyConnectedSets();
      this.stronglyConnectedSubgraphs = new Vector<DirectedSubgraph<V, E>>(list.size());
      Iterator<Set<V>> iterator = list.iterator();
      while (iterator.hasNext())
        this.stronglyConnectedSubgraphs.add(new DirectedSubgraph(this.graph, iterator.next(), null)); 
    } 
    return this.stronglyConnectedSubgraphs;
  }
  
  private void createVertexData() {
    this.vertexToVertexData = new HashMap<V, VertexData<V>>(this.graph.vertexSet().size());
    for (V v : this.graph.vertexSet())
      this.vertexToVertexData.put(v, new VertexData<V>(null, v, false, false)); 
  }
  
  private void dfsVisit(DirectedGraph<V, E> paramDirectedGraph, VertexData<V> paramVertexData, Set<V> paramSet) {
    Stack<VertexData<V>> stack = new Stack();
    stack.push(paramVertexData);
    while (!stack.isEmpty()) {
      VertexData vertexData = stack.pop();
      if (!vertexData.discovered) {
        vertexData.discovered = true;
        if (paramSet != null)
          paramSet.add(vertexData.vertex); 
        stack.push(new VertexData<V>(vertexData, null, true, true));
        for (Object object : paramDirectedGraph.outgoingEdgesOf(vertexData.vertex)) {
          VertexData<V> vertexData1 = this.vertexToVertexData.get(paramDirectedGraph.getEdgeTarget(object));
          if (!vertexData1.discovered)
            stack.push(vertexData1); 
        } 
        continue;
      } 
      if (vertexData.finished && paramSet == null)
        this.orderedVertices.addFirst(vertexData.finishedData); 
    } 
  }
  
  private void resetVertexData() {
    for (VertexData<V> vertexData : this.vertexToVertexData.values()) {
      vertexData.discovered = false;
      vertexData.finished = false;
    } 
  }
  
  private static final class VertexData<V> {
    private final VertexData<V> finishedData;
    
    private final V vertex;
    
    private boolean discovered;
    
    private boolean finished;
    
    private VertexData(VertexData<V> param1VertexData, V param1V, boolean param1Boolean1, boolean param1Boolean2) {
      this.finishedData = param1VertexData;
      this.vertex = param1V;
      this.discovered = param1Boolean1;
      this.finished = param1Boolean2;
    }
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/alg/StrongConnectivityInspector.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */