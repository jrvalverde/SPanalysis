package org.jgrapht.alg;

import org.jgrapht.Graph;

final class BellmanFordPathElement<V, E> extends AbstractPathElement<V, E> {
  private double cost = 0.0D;
  
  private double epsilon;
  
  protected BellmanFordPathElement(Graph<V, E> paramGraph, BellmanFordPathElement<V, E> paramBellmanFordPathElement, E paramE, double paramDouble1, double paramDouble2) {
    super(paramGraph, paramBellmanFordPathElement, paramE);
    this.cost = paramDouble1;
    this.epsilon = paramDouble2;
  }
  
  BellmanFordPathElement(BellmanFordPathElement<V, E> paramBellmanFordPathElement) {
    super(paramBellmanFordPathElement);
    this.cost = paramBellmanFordPathElement.cost;
    this.epsilon = paramBellmanFordPathElement.epsilon;
  }
  
  protected BellmanFordPathElement(V paramV, double paramDouble) {
    super(paramV);
    this.cost = 0.0D;
    this.epsilon = paramDouble;
  }
  
  public double getCost() {
    return this.cost;
  }
  
  protected boolean improve(BellmanFordPathElement<V, E> paramBellmanFordPathElement, E paramE, double paramDouble) {
    if (paramDouble < getCost() - this.epsilon) {
      this.prevPathElement = paramBellmanFordPathElement;
      this.prevEdge = paramE;
      this.cost = paramDouble;
      this.nHops = paramBellmanFordPathElement.getHopCount() + 1;
      return true;
    } 
    return false;
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/alg/BellmanFordPathElement.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */