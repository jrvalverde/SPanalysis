package org.jgrapht.alg;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.jgrapht.DirectedGraph;
import org.jgrapht.Graph;
import org.jgrapht.traverse.DepthFirstIterator;

public class CycleDetector<V, E> {
  DirectedGraph<V, E> graph;
  
  public CycleDetector(DirectedGraph<V, E> paramDirectedGraph) {
    this.graph = paramDirectedGraph;
  }
  
  public boolean detectCycles() {
    try {
      execute(null, null);
    } catch (CycleDetectedException cycleDetectedException) {
      return true;
    } 
    return false;
  }
  
  public boolean detectCyclesContainingVertex(V paramV) {
    try {
      execute(null, paramV);
    } catch (CycleDetectedException cycleDetectedException) {
      return true;
    } 
    return false;
  }
  
  public Set<V> findCycles() {
    StrongConnectivityInspector<V, E> strongConnectivityInspector = new StrongConnectivityInspector<V, E>(this.graph);
    List<Set<V>> list = strongConnectivityInspector.stronglyConnectedSets();
    HashSet<V> hashSet = new HashSet();
    for (Set<Object> set : list) {
      if (set.size() > 1) {
        hashSet.addAll(set);
        continue;
      } 
      Object object = set.iterator().next();
      if (this.graph.containsEdge(object, object))
        hashSet.add(object); 
    } 
    return hashSet;
  }
  
  public Set<V> findCyclesContainingVertex(V paramV) {
    HashSet<V> hashSet = new HashSet();
    execute(hashSet, paramV);
    return hashSet;
  }
  
  private void execute(Set<V> paramSet, V paramV) {
    ProbeIterator probeIterator = new ProbeIterator(paramSet, paramV);
    while (probeIterator.hasNext())
      probeIterator.next(); 
  }
  
  private class ProbeIterator extends DepthFirstIterator<V, E> {
    private List<V> path;
    
    private Set<V> cycleSet;
    
    private V root;
    
    ProbeIterator(Set<V> param1Set, V param1V) {
      super((Graph)CycleDetector.this.graph, param1V);
      this.root = param1V;
      this.cycleSet = param1Set;
      this.path = new ArrayList<V>();
    }
    
    protected void encounterVertexAgain(V param1V, E param1E) {
      int i;
      super.encounterVertexAgain(param1V, param1E);
      if (this.root != null) {
        if (param1V == this.root) {
          i = 0;
        } else if (this.cycleSet != null && this.cycleSet.contains(param1V)) {
          i = 0;
        } else {
          return;
        } 
      } else {
        i = this.path.indexOf(param1V);
      } 
      if (i > -1) {
        if (this.cycleSet == null)
          throw new CycleDetector.CycleDetectedException(); 
        while (i < this.path.size()) {
          this.cycleSet.add(this.path.get(i));
          i++;
        } 
      } 
    }
    
    protected V provideNextVertex() {
      Object object = super.provideNextVertex();
      for (int i = this.path.size() - 1; i >= 0 && !CycleDetector.this.graph.containsEdge(this.path.get(i), object); i--)
        this.path.remove(i); 
      this.path.add((V)object);
      return (V)object;
    }
  }
  
  private static class CycleDetectedException extends RuntimeException {
    private static final long serialVersionUID = 3834305137802950712L;
    
    private CycleDetectedException() {}
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/alg/CycleDetector.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */