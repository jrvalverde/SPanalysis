package org.jgrapht.alg;

import java.util.HashSet;
import java.util.Set;
import org.jgrapht.graph.SimpleDirectedGraph;

public class TransitiveClosure {
  public static final TransitiveClosure INSTANCE = new TransitiveClosure();
  
  public <V, E> void closeSimpleDirectedGraph(SimpleDirectedGraph<V, E> paramSimpleDirectedGraph) {
    Set set = paramSimpleDirectedGraph.vertexSet();
    HashSet<Object> hashSet = new HashSet();
    int i = computeBinaryLog(set.size());
    boolean bool = false;
    for (byte b = 0; !bool && b < i; b++) {
      bool = true;
      for (Object object : set) {
        hashSet.clear();
        for (Object object1 : paramSimpleDirectedGraph.outgoingEdgesOf(object)) {
          Object object2 = paramSimpleDirectedGraph.getEdgeTarget(object1);
          for (Object object3 : paramSimpleDirectedGraph.outgoingEdgesOf(object2)) {
            Object object4 = paramSimpleDirectedGraph.getEdgeTarget(object3);
            if (object.equals(object4) || paramSimpleDirectedGraph.getEdge(object, object4) != null)
              continue; 
            hashSet.add(object4);
            bool = false;
          } 
        } 
        for (Object object1 : hashSet)
          paramSimpleDirectedGraph.addEdge(object, object1); 
      } 
    } 
  }
  
  private int computeBinaryLog(int paramInt) {
    assert paramInt >= 0;
    byte b;
    for (b = 0; paramInt > 0; b++)
      paramInt >>= 1; 
    return b;
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/alg/TransitiveClosure.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */