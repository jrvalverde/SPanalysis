package org.jgrapht.alg;

import java.util.HashSet;
import java.util.Set;
import org.jgrapht.UndirectedGraph;

public class BiconnectivityInspector<V, E> {
  private BlockCutpointGraph<V, E> blockCutpointGraph;
  
  public BiconnectivityInspector(UndirectedGraph<V, E> paramUndirectedGraph) {
    this.blockCutpointGraph = new BlockCutpointGraph<V, E>(paramUndirectedGraph);
  }
  
  public Set<Set<V>> getBiconnectedVertexComponents() {
    HashSet<Set> hashSet = new HashSet();
    for (UndirectedGraph undirectedGraph : this.blockCutpointGraph.vertexSet()) {
      if (!undirectedGraph.edgeSet().isEmpty())
        hashSet.add(undirectedGraph.vertexSet()); 
    } 
    return (Set)hashSet;
  }
  
  public Set<Set<V>> getBiconnectedVertexComponents(V paramV) {
    HashSet<Set> hashSet = new HashSet();
    for (Set<V> set : getBiconnectedVertexComponents()) {
      if (set.contains(paramV))
        hashSet.add(set); 
    } 
    return (Set)hashSet;
  }
  
  public Set<V> getCutpoints() {
    return this.blockCutpointGraph.getCutpoints();
  }
  
  public boolean isBiconnected() {
    return (this.blockCutpointGraph.vertexSet().size() == 1);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/alg/BiconnectivityInspector.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */