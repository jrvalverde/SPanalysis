package org.jgrapht.alg;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import org.jgrapht.DirectedGraph;
import org.jgrapht.Graph;
import org.jgrapht.Graphs;

class KShortestPathsIterator<V, E> implements Iterator<Set<V>> {
  private V endVertex;
  
  private Graph<V, E> graph;
  
  private int k;
  
  private Set<V> prevImprovedVertices;
  
  private Map<V, RankingPathElementList<V, E>> prevSeenDataContainer;
  
  private Map<V, RankingPathElementList<V, E>> seenDataContainer;
  
  private V startVertex;
  
  private boolean startVertexEncountered;
  
  public KShortestPathsIterator(Graph<V, E> paramGraph, V paramV1, V paramV2, int paramInt) {
    assertKShortestPathsIterator(paramGraph, paramV1);
    this.graph = paramGraph;
    this.startVertex = paramV1;
    this.endVertex = paramV2;
    this.k = paramInt;
    this.seenDataContainer = new HashMap<V, RankingPathElementList<V, E>>();
    this.prevSeenDataContainer = new HashMap<V, RankingPathElementList<V, E>>();
    this.prevImprovedVertices = new HashSet<V>();
  }
  
  public boolean hasNext() {
    if (!this.startVertexEncountered)
      encounterStartVertex(); 
    return !this.prevImprovedVertices.isEmpty();
  }
  
  public Set<V> next() {
    // Byte code:
    //   0: aload_0
    //   1: getfield startVertexEncountered : Z
    //   4: ifne -> 11
    //   7: aload_0
    //   8: invokespecial encounterStartVertex : ()V
    //   11: aload_0
    //   12: invokevirtual hasNext : ()Z
    //   15: ifeq -> 79
    //   18: new java/util/HashSet
    //   21: dup
    //   22: invokespecial <init> : ()V
    //   25: astore_1
    //   26: aload_0
    //   27: getfield prevImprovedVertices : Ljava/util/Set;
    //   30: invokeinterface iterator : ()Ljava/util/Iterator;
    //   35: astore_2
    //   36: aload_2
    //   37: invokeinterface hasNext : ()Z
    //   42: ifeq -> 72
    //   45: aload_2
    //   46: invokeinterface next : ()Ljava/lang/Object;
    //   51: astore_3
    //   52: aload_3
    //   53: aload_0
    //   54: getfield endVertex : Ljava/lang/Object;
    //   57: invokevirtual equals : (Ljava/lang/Object;)Z
    //   60: ifne -> 69
    //   63: aload_0
    //   64: aload_3
    //   65: aload_1
    //   66: invokespecial updateOutgoingVertices : (Ljava/lang/Object;Ljava/util/Set;)V
    //   69: goto -> 36
    //   72: aload_0
    //   73: aload_1
    //   74: invokespecial savePassData : (Ljava/util/Set;)V
    //   77: aload_1
    //   78: areturn
    //   79: new java/util/NoSuchElementException
    //   82: dup
    //   83: invokespecial <init> : ()V
    //   86: athrow
  }
  
  public void remove() {
    throw new UnsupportedOperationException();
  }
  
  RankingPathElementList<V, E> getPathElements(V paramV) {
    return this.seenDataContainer.get(paramV);
  }
  
  private void addFirstPath(V paramV, E paramE) {
    RankingPathElementList<V, E> rankingPathElementList = createSeenData(paramV, paramE);
    this.seenDataContainer.put(paramV, rankingPathElementList);
  }
  
  private void assertKShortestPathsIterator(Graph<V, E> paramGraph, V paramV) {
    if (paramGraph == null)
      throw new NullPointerException("graph is null"); 
    if (paramV == null)
      throw new NullPointerException("startVertex is null"); 
  }
  
  private RankingPathElementList<V, E> createSeenData(V paramV, E paramE) {
    Object object = Graphs.getOppositeVertex(this.graph, paramE, paramV);
    RankingPathElementList<V, E> rankingPathElementList = this.prevSeenDataContainer.get(object);
    return new RankingPathElementList<V, E>(this.graph, this.k, rankingPathElementList, paramE);
  }
  
  private Set<E> edgesOf(V paramV) {
    return (this.graph instanceof DirectedGraph) ? ((DirectedGraph)this.graph).outgoingEdgesOf(paramV) : this.graph.edgesOf(paramV);
  }
  
  private void encounterStartVertex() {
    RankingPathElementList<V, E> rankingPathElementList = new RankingPathElementList<V, E>(this.graph, this.k, new RankingPathElement<V, E>(this.startVertex));
    this.seenDataContainer.put(this.startVertex, rankingPathElementList);
    this.prevSeenDataContainer.put(this.startVertex, rankingPathElementList);
    this.prevImprovedVertices.add(this.startVertex);
    this.startVertexEncountered = true;
  }
  
  private void savePassData(Set<V> paramSet) {
    // Byte code:
    //   0: aload_1
    //   1: invokeinterface iterator : ()Ljava/util/Iterator;
    //   6: astore_2
    //   7: aload_2
    //   8: invokeinterface hasNext : ()Z
    //   13: ifeq -> 61
    //   16: aload_2
    //   17: invokeinterface next : ()Ljava/lang/Object;
    //   22: astore_3
    //   23: new org/jgrapht/alg/RankingPathElementList
    //   26: dup
    //   27: aload_0
    //   28: getfield seenDataContainer : Ljava/util/Map;
    //   31: aload_3
    //   32: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   37: checkcast org/jgrapht/alg/RankingPathElementList
    //   40: invokespecial <init> : (Lorg/jgrapht/alg/RankingPathElementList;)V
    //   43: astore #4
    //   45: aload_0
    //   46: getfield prevSeenDataContainer : Ljava/util/Map;
    //   49: aload_3
    //   50: aload #4
    //   52: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   57: pop
    //   58: goto -> 7
    //   61: aload_0
    //   62: aload_1
    //   63: putfield prevImprovedVertices : Ljava/util/Set;
    //   66: return
  }
  
  private boolean tryToAddNewPaths(V paramV, E paramE) {
    RankingPathElementList rankingPathElementList1 = this.seenDataContainer.get(paramV);
    Object object = Graphs.getOppositeVertex(this.graph, paramE, paramV);
    RankingPathElementList rankingPathElementList2 = this.prevSeenDataContainer.get(object);
    return rankingPathElementList1.addPathElements(rankingPathElementList2, paramE);
  }
  
  private void updateOutgoingVertices(V paramV, Set<V> paramSet) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokespecial edgesOf : (Ljava/lang/Object;)Ljava/util/Set;
    //   5: invokeinterface iterator : ()Ljava/util/Iterator;
    //   10: astore_3
    //   11: aload_3
    //   12: invokeinterface hasNext : ()Z
    //   17: ifeq -> 110
    //   20: aload_3
    //   21: invokeinterface next : ()Ljava/lang/Object;
    //   26: astore #4
    //   28: aload_0
    //   29: getfield graph : Lorg/jgrapht/Graph;
    //   32: aload #4
    //   34: aload_1
    //   35: invokestatic getOppositeVertex : (Lorg/jgrapht/Graph;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   38: astore #5
    //   40: aload #5
    //   42: aload_0
    //   43: getfield startVertex : Ljava/lang/Object;
    //   46: if_acmpeq -> 107
    //   49: aload_0
    //   50: getfield seenDataContainer : Ljava/util/Map;
    //   53: aload #5
    //   55: invokeinterface containsKey : (Ljava/lang/Object;)Z
    //   60: ifeq -> 90
    //   63: aload_0
    //   64: aload #5
    //   66: aload #4
    //   68: invokespecial tryToAddNewPaths : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   71: istore #6
    //   73: iload #6
    //   75: ifeq -> 87
    //   78: aload_2
    //   79: aload #5
    //   81: invokeinterface add : (Ljava/lang/Object;)Z
    //   86: pop
    //   87: goto -> 107
    //   90: aload_0
    //   91: aload #5
    //   93: aload #4
    //   95: invokespecial addFirstPath : (Ljava/lang/Object;Ljava/lang/Object;)V
    //   98: aload_2
    //   99: aload #5
    //   101: invokeinterface add : (Ljava/lang/Object;)Z
    //   106: pop
    //   107: goto -> 11
    //   110: return
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/alg/KShortestPathsIterator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */