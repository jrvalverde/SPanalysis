package org.jgrapht.alg;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.jgrapht.Graph;
import org.jgrapht.Graphs;
import org.jgrapht.event.GraphEdgeChangeEvent;
import org.jgrapht.event.GraphListener;
import org.jgrapht.event.GraphVertexChangeEvent;
import org.jgrapht.util.ModifiableInteger;

public class NeighborIndex<V, E> implements GraphListener<V, E> {
  Map<V, Neighbors<V, E>> neighborMap = new HashMap<V, Neighbors<V, E>>();
  
  private Graph<V, E> graph;
  
  public NeighborIndex(Graph<V, E> paramGraph) {
    this.graph = paramGraph;
  }
  
  public Set<V> neighborsOf(V paramV) {
    return getNeighbors(paramV).getNeighbors();
  }
  
  public List<V> neighborListOf(V paramV) {
    return getNeighbors(paramV).getNeighborList();
  }
  
  public void edgeAdded(GraphEdgeChangeEvent<V, E> paramGraphEdgeChangeEvent) {
    Object object1 = paramGraphEdgeChangeEvent.getEdge();
    Object object2 = this.graph.getEdgeSource(object1);
    Object object3 = this.graph.getEdgeTarget(object1);
    if (this.neighborMap.containsKey(object2)) {
      getNeighbors((V)object2).addNeighbor((V)object3);
    } else {
      getNeighbors((V)object2);
    } 
    if (this.neighborMap.containsKey(object3)) {
      getNeighbors((V)object3).addNeighbor((V)object2);
    } else {
      getNeighbors((V)object3);
    } 
  }
  
  public void edgeRemoved(GraphEdgeChangeEvent<V, E> paramGraphEdgeChangeEvent) {
    Object object1 = paramGraphEdgeChangeEvent.getEdge();
    Object object2 = this.graph.getEdgeSource(object1);
    Object object3 = this.graph.getEdgeTarget(object1);
    if (this.neighborMap.containsKey(object2))
      ((Neighbors)this.neighborMap.get(object2)).removeNeighbor(object3); 
    if (this.neighborMap.containsKey(object3))
      ((Neighbors)this.neighborMap.get(object3)).removeNeighbor(object2); 
  }
  
  public void vertexAdded(GraphVertexChangeEvent<V> paramGraphVertexChangeEvent) {}
  
  public void vertexRemoved(GraphVertexChangeEvent<V> paramGraphVertexChangeEvent) {
    this.neighborMap.remove(paramGraphVertexChangeEvent.getVertex());
  }
  
  private Neighbors<V, E> getNeighbors(V paramV) {
    Neighbors<V, Object> neighbors = (Neighbors)this.neighborMap.get(paramV);
    if (neighbors == null) {
      neighbors = new Neighbors<V, Object>(paramV, Graphs.neighborListOf(this.graph, paramV));
      this.neighborMap.put(paramV, neighbors);
    } 
    return (Neighbors)neighbors;
  }
  
  static class Neighbors<V, E> {
    private Map<V, ModifiableInteger> neighborCounts;
    
    private Set<V> neighborSet;
    
    public Neighbors(V param1V, Collection<V> param1Collection) {
      // Byte code:
      //   0: aload_0
      //   1: invokespecial <init> : ()V
      //   4: aload_0
      //   5: new java/util/LinkedHashMap
      //   8: dup
      //   9: invokespecial <init> : ()V
      //   12: putfield neighborCounts : Ljava/util/Map;
      //   15: aload_0
      //   16: aload_0
      //   17: getfield neighborCounts : Ljava/util/Map;
      //   20: invokeinterface keySet : ()Ljava/util/Set;
      //   25: invokestatic unmodifiableSet : (Ljava/util/Set;)Ljava/util/Set;
      //   28: putfield neighborSet : Ljava/util/Set;
      //   31: aload_2
      //   32: invokeinterface iterator : ()Ljava/util/Iterator;
      //   37: astore_3
      //   38: aload_3
      //   39: invokeinterface hasNext : ()Z
      //   44: ifeq -> 64
      //   47: aload_3
      //   48: invokeinterface next : ()Ljava/lang/Object;
      //   53: astore #4
      //   55: aload_0
      //   56: aload #4
      //   58: invokevirtual addNeighbor : (Ljava/lang/Object;)V
      //   61: goto -> 38
      //   64: return
    }
    
    public void addNeighbor(V param1V) {
      ModifiableInteger modifiableInteger = this.neighborCounts.get(param1V);
      if (modifiableInteger == null) {
        modifiableInteger = new ModifiableInteger(1);
        this.neighborCounts.put(param1V, modifiableInteger);
      } else {
        modifiableInteger.increment();
      } 
    }
    
    public void removeNeighbor(V param1V) {
      ModifiableInteger modifiableInteger = this.neighborCounts.get(param1V);
      if (modifiableInteger == null)
        throw new IllegalArgumentException("Attempting to remove a neighbor that wasn't present"); 
      modifiableInteger.decrement();
      if (modifiableInteger.getValue() == 0)
        this.neighborCounts.remove(param1V); 
    }
    
    public Set<V> getNeighbors() {
      return this.neighborSet;
    }
    
    public List<V> getNeighborList() {
      ArrayList<Object> arrayList = new ArrayList();
      for (Map.Entry<V, ModifiableInteger> entry : this.neighborCounts.entrySet()) {
        Object object = entry.getKey();
        int i = ((ModifiableInteger)entry.getValue()).intValue();
        for (byte b = 0; b < i; b++)
          arrayList.add(object); 
      } 
      return arrayList;
    }
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/alg/NeighborIndex.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */