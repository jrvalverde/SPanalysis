package org.jgrapht.alg;

import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Set;
import org.jgrapht.Graph;
import org.jgrapht.UndirectedGraph;
import org.jgrapht.alg.util.VertexDegreeComparator;
import org.jgrapht.graph.Subgraph;
import org.jgrapht.graph.UndirectedSubgraph;

public abstract class VertexCovers {
  public static <V, E> Set<V> find2ApproximationCover(Graph<V, E> paramGraph) {
    HashSet<Object> hashSet = new HashSet();
    Subgraph subgraph = new Subgraph(paramGraph, null, null);
    while (subgraph.edgeSet().size() > 0) {
      Object object = subgraph.edgeSet().iterator().next();
      Object object1 = paramGraph.getEdgeSource(object);
      Object object2 = paramGraph.getEdgeTarget(object);
      hashSet.add(object1);
      hashSet.add(object2);
      subgraph.removeVertex(object1);
      subgraph.removeVertex(object2);
    } 
    return hashSet;
  }
  
  public static <V, E> Set<V> findGreedyCover(UndirectedGraph<V, E> paramUndirectedGraph) {
    HashSet<V> hashSet = new HashSet();
    UndirectedSubgraph undirectedSubgraph = new UndirectedSubgraph(paramUndirectedGraph, null, null);
    VertexDegreeComparator vertexDegreeComparator = new VertexDegreeComparator((UndirectedGraph)undirectedSubgraph);
    while (undirectedSubgraph.edgeSet().size() > 0) {
      Object object = Collections.max(undirectedSubgraph.vertexSet(), (Comparator<? super Object>)vertexDegreeComparator);
      hashSet.add(object);
      undirectedSubgraph.removeVertex(object);
    } 
    return hashSet;
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/alg/VertexCovers.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */