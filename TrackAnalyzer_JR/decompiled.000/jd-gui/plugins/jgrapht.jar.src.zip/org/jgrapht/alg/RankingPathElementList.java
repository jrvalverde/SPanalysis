package org.jgrapht.alg;

import java.util.List;
import org.jgrapht.Graph;
import org.jgrapht.Graphs;

final class RankingPathElementList<V, E> extends AbstractPathElementList<V, E, RankingPathElement<V, E>> {
  RankingPathElementList(Graph<V, E> paramGraph, int paramInt, RankingPathElement<V, E> paramRankingPathElement) {
    super(paramGraph, paramInt, paramRankingPathElement);
  }
  
  RankingPathElementList(Graph<V, E> paramGraph, int paramInt, RankingPathElementList<V, E> paramRankingPathElementList, E paramE) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: iload_2
    //   3: aload_3
    //   4: aload #4
    //   6: invokespecial <init> : (Lorg/jgrapht/Graph;ILorg/jgrapht/alg/AbstractPathElementList;Ljava/lang/Object;)V
    //   9: iconst_0
    //   10: istore #5
    //   12: iload #5
    //   14: aload_3
    //   15: invokevirtual size : ()I
    //   18: if_icmpge -> 93
    //   21: aload_3
    //   22: iload #5
    //   24: invokevirtual get : (I)Lorg/jgrapht/alg/AbstractPathElement;
    //   27: checkcast org/jgrapht/alg/RankingPathElement
    //   30: astore #6
    //   32: aload_0
    //   33: getfield pathElements : Ljava/util/ArrayList;
    //   36: invokevirtual size : ()I
    //   39: aload_0
    //   40: getfield maxSize : I
    //   43: iconst_1
    //   44: isub
    //   45: if_icmpgt -> 87
    //   48: aload_0
    //   49: aload #6
    //   51: aload #4
    //   53: invokespecial calculatePathWeight : (Lorg/jgrapht/alg/RankingPathElement;Ljava/lang/Object;)D
    //   56: dstore #7
    //   58: new org/jgrapht/alg/RankingPathElement
    //   61: dup
    //   62: aload_0
    //   63: getfield graph : Lorg/jgrapht/Graph;
    //   66: aload #6
    //   68: aload #4
    //   70: dload #7
    //   72: invokespecial <init> : (Lorg/jgrapht/Graph;Lorg/jgrapht/alg/RankingPathElement;Ljava/lang/Object;D)V
    //   75: astore #9
    //   77: aload_0
    //   78: getfield pathElements : Ljava/util/ArrayList;
    //   81: aload #9
    //   83: invokevirtual add : (Ljava/lang/Object;)Z
    //   86: pop
    //   87: iinc #5, 1
    //   90: goto -> 12
    //   93: getstatic org/jgrapht/alg/RankingPathElementList.$assertionsDisabled : Z
    //   96: ifne -> 117
    //   99: aload_0
    //   100: getfield pathElements : Ljava/util/ArrayList;
    //   103: invokevirtual isEmpty : ()Z
    //   106: ifeq -> 117
    //   109: new java/lang/AssertionError
    //   112: dup
    //   113: invokespecial <init> : ()V
    //   116: athrow
    //   117: return
  }
  
  protected RankingPathElementList(RankingPathElementList<V, E> paramRankingPathElementList) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokespecial <init> : (Lorg/jgrapht/alg/AbstractPathElementList;)V
    //   5: return
  }
  
  public boolean addPathElements(RankingPathElementList<V, E> paramRankingPathElementList, E paramE) {
    assert this.vertex.equals(Graphs.getOppositeVertex(this.graph, paramE, paramRankingPathElementList.getVertex()));
    boolean bool = false;
    byte b1 = 0;
    byte b2 = 0;
    while (b1 < paramRankingPathElementList.size()) {
      RankingPathElement<V, E> rankingPathElement = paramRankingPathElementList.get(b1);
      if (!isAlreadyImprovedByThisEdge(paramE, rankingPathElement) && !containsTargetPreviously(rankingPathElement)) {
        double d = calculatePathWeight(rankingPathElement, paramE);
        while (b2 < size()) {
          RankingPathElement<V, E> rankingPathElement1 = get(b2);
          RankingPathElement<V, E> rankingPathElement2 = new RankingPathElement<V, E>(this.graph, rankingPathElement, paramE, d);
          if (d < rankingPathElement1.getWeight()) {
            this.pathElements.add(b2, rankingPathElement2);
            if (size() > this.maxSize)
              this.pathElements.remove(this.maxSize); 
            bool = true;
            break;
          } 
          if (d == rankingPathElement1.getWeight()) {
            if (isAlreadyAdded(rankingPathElement2))
              break; 
            if (size() <= this.maxSize - 1) {
              this.pathElements.add(b2 + 1, rankingPathElement2);
              if (size() > this.maxSize)
                this.pathElements.remove(this.maxSize); 
              bool = true;
              break;
            } 
          } 
          if (d > rankingPathElement1.getWeight() && b2 == size() - 1 && size() <= this.maxSize - 1) {
            this.pathElements.add(rankingPathElement2);
            bool = true;
            break;
          } 
          b2++;
        } 
      } 
      b1++;
    } 
    return bool;
  }
  
  List<RankingPathElement<V, E>> getPathElements() {
    return this.pathElements;
  }
  
  private double calculatePathWeight(RankingPathElement<V, E> paramRankingPathElement, E paramE) {
    double d = this.graph.getEdgeWeight(paramE);
    if (paramRankingPathElement.getPrevEdge() != null)
      d += paramRankingPathElement.getWeight(); 
    return d;
  }
  
  private boolean containsTargetPreviously(RankingPathElement<V, E> paramRankingPathElement) {
    for (RankingPathElement<V, E> rankingPathElement = paramRankingPathElement; rankingPathElement.getPrevEdge() != null; rankingPathElement = rankingPathElement.getPrevPathElement()) {
      if (rankingPathElement.getVertex() == this.vertex)
        return true; 
    } 
    return false;
  }
  
  private boolean isAlreadyAdded(RankingPathElement<V, E> paramRankingPathElement) {
    for (byte b = 0; b <= size() - 1; b++) {
      RankingPathElement<V, E> rankingPathElement1 = get(b);
      RankingPathElement<V, E> rankingPathElement2 = paramRankingPathElement;
      if (!isDifferent(rankingPathElement1, rankingPathElement2))
        return true; 
    } 
    return false;
  }
  
  private boolean isAlreadyImprovedByThisEdge(E paramE, RankingPathElement<V, E> paramRankingPathElement) {
    for (RankingPathElement<V, E> rankingPathElement = paramRankingPathElement; rankingPathElement.getPrevEdge() != null; rankingPathElement = rankingPathElement.getPrevPathElement()) {
      if (rankingPathElement.getPrevEdge() == paramE)
        return true; 
    } 
    return false;
  }
  
  private boolean isDifferent(RankingPathElement<V, E> paramRankingPathElement1, RankingPathElement<V, E> paramRankingPathElement2) {
    while (true) {
      if (paramRankingPathElement1.getPrevEdge() != null || paramRankingPathElement2.getPrevEdge() != null) {
        if (paramRankingPathElement1.getPrevEdge() != paramRankingPathElement2.getPrevEdge())
          return true; 
        paramRankingPathElement1 = paramRankingPathElement1.getPrevPathElement();
        paramRankingPathElement2 = paramRankingPathElement2.getPrevPathElement();
        continue;
      } 
      return false;
    } 
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/alg/RankingPathElementList.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */