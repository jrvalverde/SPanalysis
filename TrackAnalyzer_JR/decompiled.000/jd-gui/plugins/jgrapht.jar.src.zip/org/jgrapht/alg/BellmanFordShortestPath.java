package org.jgrapht.alg;

import java.util.List;
import org.jgrapht.Graph;

public class BellmanFordShortestPath<V, E> {
  private static final double DEFAULT_EPSILON = 1.0E-9D;
  
  protected Graph<V, E> graph;
  
  protected V startVertex;
  
  private BellmanFordIterator<V, E> iter;
  
  private int nMaxHops;
  
  private int passNumber;
  
  private double epsilon;
  
  public BellmanFordShortestPath(Graph<V, E> paramGraph, V paramV) {
    this(paramGraph, paramV, paramGraph.vertexSet().size() - 1);
  }
  
  public BellmanFordShortestPath(Graph<V, E> paramGraph, V paramV, int paramInt) {
    this(paramGraph, paramV, paramInt, 1.0E-9D);
  }
  
  public BellmanFordShortestPath(Graph<V, E> paramGraph, V paramV, int paramInt, double paramDouble) {
    this.startVertex = paramV;
    this.nMaxHops = paramInt;
    this.graph = paramGraph;
    this.passNumber = 1;
    this.epsilon = paramDouble;
  }
  
  public double getCost(V paramV) {
    assertGetPath(paramV);
    lazyCalculate();
    BellmanFordPathElement<V, E> bellmanFordPathElement = this.iter.getPathElement(paramV);
    return (bellmanFordPathElement == null) ? Double.POSITIVE_INFINITY : bellmanFordPathElement.getCost();
  }
  
  public List<E> getPathEdgeList(V paramV) {
    assertGetPath(paramV);
    lazyCalculate();
    BellmanFordPathElement<V, E> bellmanFordPathElement = this.iter.getPathElement(paramV);
    return (bellmanFordPathElement == null) ? null : bellmanFordPathElement.createEdgeListPath();
  }
  
  private void assertGetPath(V paramV) {
    if (paramV.equals(this.startVertex))
      throw new IllegalArgumentException("The end vertex is the same as the start vertex!"); 
    if (!this.graph.containsVertex(paramV))
      throw new IllegalArgumentException("Graph must contain the end vertex!"); 
  }
  
  private void lazyCalculate() {
    if (this.iter == null)
      this.iter = new BellmanFordIterator<V, E>(this.graph, this.startVertex, this.epsilon); 
    while (this.passNumber <= this.nMaxHops && this.iter.hasNext()) {
      this.iter.next();
      this.passNumber++;
    } 
  }
  
  public static <V, E> List<E> findPathBetween(Graph<V, E> paramGraph, V paramV1, V paramV2) {
    BellmanFordShortestPath<V, E> bellmanFordShortestPath = new BellmanFordShortestPath<V, E>(paramGraph, paramV1);
    return bellmanFordShortestPath.getPathEdgeList(paramV2);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/alg/BellmanFordShortestPath.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */