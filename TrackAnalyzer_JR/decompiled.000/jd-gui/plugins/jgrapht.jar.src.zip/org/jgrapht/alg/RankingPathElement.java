package org.jgrapht.alg;

import org.jgrapht.Graph;

final class RankingPathElement<V, E> extends AbstractPathElement<V, E> {
  private double weight;
  
  RankingPathElement(Graph<V, E> paramGraph, RankingPathElement<V, E> paramRankingPathElement, E paramE, double paramDouble) {
    super(paramGraph, paramRankingPathElement, paramE);
    this.weight = paramDouble;
  }
  
  RankingPathElement(V paramV) {
    super(paramV);
    this.weight = 0.0D;
  }
  
  public double getWeight() {
    return this.weight;
  }
  
  public RankingPathElement<V, E> getPrevPathElement() {
    return (RankingPathElement<V, E>)super.getPrevPathElement();
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/alg/RankingPathElement.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */