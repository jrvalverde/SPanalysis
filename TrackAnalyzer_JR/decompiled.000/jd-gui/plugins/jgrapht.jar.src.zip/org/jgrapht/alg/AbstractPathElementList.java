package org.jgrapht.alg;

import java.util.AbstractList;
import java.util.ArrayList;
import org.jgrapht.Graph;
import org.jgrapht.Graphs;

abstract class AbstractPathElementList<V, E, T extends AbstractPathElement<V, E>> extends AbstractList<T> implements Cloneable {
  protected Graph<V, E> graph;
  
  protected int maxSize;
  
  protected ArrayList<T> pathElements = new ArrayList<T>();
  
  protected V vertex;
  
  protected AbstractPathElementList(Graph<V, E> paramGraph, int paramInt, T paramT) {
    if (paramInt <= 0)
      throw new IllegalArgumentException("maxSize is negative or 0"); 
    if (paramT == null)
      throw new NullPointerException("pathElement is null"); 
    this.graph = paramGraph;
    this.maxSize = paramInt;
    this.vertex = (V)paramT.getVertex();
    this.pathElements.add(paramT);
  }
  
  protected AbstractPathElementList(Graph<V, E> paramGraph, int paramInt, AbstractPathElementList<V, E, T> paramAbstractPathElementList, E paramE) {
    if (paramInt <= 0)
      throw new IllegalArgumentException("maxSize is negative or 0"); 
    if (paramAbstractPathElementList == null)
      throw new NullPointerException("elementList is null"); 
    if (paramE == null)
      throw new NullPointerException("edge is null"); 
    this.graph = paramGraph;
    this.maxSize = paramInt;
    this.vertex = (V)Graphs.getOppositeVertex(paramGraph, paramE, paramAbstractPathElementList.getVertex());
  }
  
  protected AbstractPathElementList(AbstractPathElementList<V, E, T> paramAbstractPathElementList) {
    this.graph = paramAbstractPathElementList.graph;
    this.maxSize = paramAbstractPathElementList.maxSize;
    this.pathElements.addAll(paramAbstractPathElementList.pathElements);
    this.vertex = paramAbstractPathElementList.vertex;
  }
  
  public T get(int paramInt) {
    return this.pathElements.get(paramInt);
  }
  
  public V getVertex() {
    return this.vertex;
  }
  
  public int size() {
    return this.pathElements.size();
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/alg/AbstractPathElementList.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */