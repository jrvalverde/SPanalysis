package org.jgrapht.alg;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import org.jgrapht.DirectedGraph;
import org.jgrapht.Graph;
import org.jgrapht.Graphs;

class BellmanFordIterator<V, E> implements Iterator<List<V>> {
  protected static final String NEGATIVE_UNDIRECTED_EDGE = "Negativeedge-weights are not allowed in an unidrected graph!";
  
  protected Graph<V, E> graph;
  
  protected V startVertex;
  
  private List<V> prevImprovedVertices = new ArrayList<V>();
  
  private Map<V, BellmanFordPathElement<V, E>> prevVertexData;
  
  private boolean startVertexEncountered = false;
  
  private Map<V, BellmanFordPathElement<V, E>> vertexData;
  
  private double epsilon;
  
  protected BellmanFordIterator(Graph<V, E> paramGraph, V paramV, double paramDouble) {
    assertBellmanFordIterator(paramGraph, paramV);
    this.graph = paramGraph;
    this.startVertex = paramV;
    this.epsilon = paramDouble;
  }
  
  public BellmanFordPathElement<V, E> getPathElement(V paramV) {
    return getSeenData(paramV);
  }
  
  public boolean hasNext() {
    if (!this.startVertexEncountered)
      encounterStartVertex(); 
    return !this.prevImprovedVertices.isEmpty();
  }
  
  public List<V> next() {
    if (!this.startVertexEncountered)
      encounterStartVertex(); 
    if (hasNext()) {
      ArrayList<Object> arrayList = new ArrayList();
      for (int i = this.prevImprovedVertices.size() - 1; i >= 0; i--) {
        V v = this.prevImprovedVertices.get(i);
        Iterator<E> iterator = edgesOfIterator(v);
        while (iterator.hasNext()) {
          E e = iterator.next();
          Object object = Graphs.getOppositeVertex(this.graph, e, v);
          if (getPathElement((V)object) != null) {
            boolean bool = relaxVertexAgain((V)object, e);
            if (bool)
              arrayList.add(object); 
            continue;
          } 
          relaxVertex((V)object, e);
          arrayList.add(object);
        } 
      } 
      savePassData(arrayList);
      return arrayList;
    } 
    throw new NoSuchElementException();
  }
  
  public void remove() {
    throw new UnsupportedOperationException();
  }
  
  protected void assertValidEdge(E paramE) {
    if (this.graph instanceof org.jgrapht.UndirectedGraph && this.graph.getEdgeWeight(paramE) < 0.0D)
      throw new IllegalArgumentException("Negativeedge-weights are not allowed in an unidrected graph!"); 
  }
  
  protected double calculatePathCost(V paramV, E paramE) {
    Object object = Graphs.getOppositeVertex(this.graph, paramE, paramV);
    BellmanFordPathElement<V, E> bellmanFordPathElement = getPrevSeenData((V)object);
    double d = this.graph.getEdgeWeight(paramE);
    if (!bellmanFordPathElement.getVertex().equals(this.startVertex))
      d += bellmanFordPathElement.getCost(); 
    return d;
  }
  
  protected Iterator<E> edgesOfIterator(V paramV) {
    return (this.graph instanceof DirectedGraph) ? ((DirectedGraph)this.graph).outgoingEdgesOf(paramV).iterator() : this.graph.edgesOf(paramV).iterator();
  }
  
  protected BellmanFordPathElement<V, E> getPrevSeenData(V paramV) {
    return this.prevVertexData.get(paramV);
  }
  
  protected BellmanFordPathElement<V, E> getSeenData(V paramV) {
    return this.vertexData.get(paramV);
  }
  
  protected boolean isSeenVertex(V paramV) {
    return this.vertexData.containsKey(paramV);
  }
  
  protected BellmanFordPathElement<V, E> putPrevSeenData(V paramV, BellmanFordPathElement<V, E> paramBellmanFordPathElement) {
    if (this.prevVertexData == null)
      this.prevVertexData = new HashMap<V, BellmanFordPathElement<V, E>>(); 
    return this.prevVertexData.put(paramV, paramBellmanFordPathElement);
  }
  
  protected BellmanFordPathElement<V, E> putSeenData(V paramV, BellmanFordPathElement<V, E> paramBellmanFordPathElement) {
    if (this.vertexData == null)
      this.vertexData = new HashMap<V, BellmanFordPathElement<V, E>>(); 
    return this.vertexData.put(paramV, paramBellmanFordPathElement);
  }
  
  private void assertBellmanFordIterator(Graph<V, E> paramGraph, V paramV) {
    if (!paramGraph.containsVertex(paramV))
      throw new IllegalArgumentException("Graph must contain the start vertex!"); 
  }
  
  private BellmanFordPathElement<V, E> createSeenData(V paramV, E paramE, double paramDouble) {
    BellmanFordPathElement<V, E> bellmanFordPathElement = getPrevSeenData((V)Graphs.getOppositeVertex(this.graph, paramE, paramV));
    return new BellmanFordPathElement<V, E>(this.graph, bellmanFordPathElement, paramE, paramDouble, this.epsilon);
  }
  
  private void encounterStartVertex() {
    BellmanFordPathElement<V, Object> bellmanFordPathElement = new BellmanFordPathElement<V, Object>(this.startVertex, this.epsilon);
    this.prevImprovedVertices.add(this.startVertex);
    putSeenData(this.startVertex, (BellmanFordPathElement)bellmanFordPathElement);
    putPrevSeenData(this.startVertex, (BellmanFordPathElement)bellmanFordPathElement);
    this.startVertexEncountered = true;
  }
  
  private void relaxVertex(V paramV, E paramE) {
    assertValidEdge(paramE);
    double d = calculatePathCost(paramV, paramE);
    BellmanFordPathElement<V, E> bellmanFordPathElement = createSeenData(paramV, paramE, d);
    putSeenData(paramV, bellmanFordPathElement);
  }
  
  private boolean relaxVertexAgain(V paramV, E paramE) {
    assertValidEdge(paramE);
    double d = calculatePathCost(paramV, paramE);
    BellmanFordPathElement<V, E> bellmanFordPathElement1 = getPrevSeenData((V)Graphs.getOppositeVertex(this.graph, paramE, paramV));
    BellmanFordPathElement<V, E> bellmanFordPathElement2 = getSeenData(paramV);
    return bellmanFordPathElement2.improve(bellmanFordPathElement1, paramE, d);
  }
  
  private void savePassData(List<V> paramList) {
    // Byte code:
    //   0: aload_1
    //   1: invokeinterface iterator : ()Ljava/util/Iterator;
    //   6: astore_2
    //   7: aload_2
    //   8: invokeinterface hasNext : ()Z
    //   13: ifeq -> 52
    //   16: aload_2
    //   17: invokeinterface next : ()Ljava/lang/Object;
    //   22: astore_3
    //   23: aload_0
    //   24: aload_3
    //   25: invokevirtual getSeenData : (Ljava/lang/Object;)Lorg/jgrapht/alg/BellmanFordPathElement;
    //   28: astore #4
    //   30: new org/jgrapht/alg/BellmanFordPathElement
    //   33: dup
    //   34: aload #4
    //   36: invokespecial <init> : (Lorg/jgrapht/alg/BellmanFordPathElement;)V
    //   39: astore #5
    //   41: aload_0
    //   42: aload_3
    //   43: aload #5
    //   45: invokevirtual putPrevSeenData : (Ljava/lang/Object;Lorg/jgrapht/alg/BellmanFordPathElement;)Lorg/jgrapht/alg/BellmanFordPathElement;
    //   48: pop
    //   49: goto -> 7
    //   52: aload_0
    //   53: aload_1
    //   54: putfield prevImprovedVertices : Ljava/util/List;
    //   57: return
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/alg/BellmanFordIterator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */