package org.jgrapht.alg.util;

import java.util.Comparator;
import org.jgrapht.UndirectedGraph;

public class VertexDegreeComparator<V, E> implements Comparator<V> {
  private UndirectedGraph<V, E> graph;
  
  private boolean ascendingOrder;
  
  public VertexDegreeComparator(UndirectedGraph<V, E> paramUndirectedGraph) {
    this(paramUndirectedGraph, true);
  }
  
  public VertexDegreeComparator(UndirectedGraph<V, E> paramUndirectedGraph, boolean paramBoolean) {
    this.graph = paramUndirectedGraph;
    this.ascendingOrder = paramBoolean;
  }
  
  public int compare(V paramV1, V paramV2) {
    int i = this.graph.degreeOf(paramV1);
    int j = this.graph.degreeOf(paramV2);
    return ((i < j && this.ascendingOrder) || (i > j && !this.ascendingOrder)) ? -1 : (((i > j && this.ascendingOrder) || (i < j && !this.ascendingOrder)) ? 1 : 0);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/alg/util/VertexDegreeComparator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */