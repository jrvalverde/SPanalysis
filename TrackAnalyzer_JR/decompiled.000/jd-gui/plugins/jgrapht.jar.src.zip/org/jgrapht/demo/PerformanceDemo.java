package org.jgrapht.demo;

import java.io.IOException;
import org.jgrapht.Graph;
import org.jgrapht.graph.DefaultEdge;
import org.jgrapht.graph.Pseudograph;
import org.jgrapht.traverse.BreadthFirstIterator;
import org.jgrapht.traverse.DepthFirstIterator;

public final class PerformanceDemo {
  public static void main(String[] paramArrayOfString) {
    long l = System.currentTimeMillis();
    reportPerformanceFor("starting at", l);
    Pseudograph pseudograph = new Pseudograph(DefaultEdge.class);
    Object object1 = new Object();
    Object object2 = object1;
    pseudograph.addVertex(object1);
    char c1 = '✐';
    char c2 = 'È';
    int i = c1 * (1 + c2);
    System.out.println("\nallocating graph with " + i + " elements (may take a few tens of seconds)...");
    for (byte b = 0; b < c1; b++) {
      object2 = new Object();
      pseudograph.addVertex(object2);
      for (byte b1 = 0; b1 < c2; b1++)
        pseudograph.addEdge(object1, object2); 
      object1 = object2;
    } 
    reportPerformanceFor("graph allocation", l);
    l = System.currentTimeMillis();
    BreadthFirstIterator breadthFirstIterator = new BreadthFirstIterator((Graph)pseudograph);
    while (breadthFirstIterator.hasNext())
      breadthFirstIterator.next(); 
    reportPerformanceFor("breadth traversal", l);
    l = System.currentTimeMillis();
    DepthFirstIterator depthFirstIterator = new DepthFirstIterator((Graph)pseudograph);
    while (depthFirstIterator.hasNext())
      depthFirstIterator.next(); 
    reportPerformanceFor("depth traversal", l);
    System.out.println("\nPaused: graph is still in memory (to check mem consumption).");
    System.out.print("press any key to free memory and finish...");
    try {
      System.in.read();
    } catch (IOException iOException) {
      iOException.printStackTrace();
    } 
    System.out.println("done.");
  }
  
  private static void reportPerformanceFor(String paramString, long paramLong) {
    double d1 = (System.currentTimeMillis() - paramLong) / 1000.0D;
    double d2 = usedMemory() / 1048576.0D;
    d2 = Math.round(d2 * 100.0D) / 100.0D;
    System.out.println(paramString + " (" + d1 + " sec, " + d2 + "MB)");
  }
  
  private static long usedMemory() {
    Runtime runtime = Runtime.getRuntime();
    return runtime.totalMemory() - runtime.freeMemory();
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/demo/PerformanceDemo.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */