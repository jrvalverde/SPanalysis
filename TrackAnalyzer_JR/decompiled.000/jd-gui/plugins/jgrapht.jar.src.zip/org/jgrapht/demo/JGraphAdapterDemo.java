package org.jgrapht.demo;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.geom.Rectangle2D;
import java.util.Map;
import javax.swing.JApplet;
import javax.swing.JFrame;
import org.jgraph.JGraph;
import org.jgraph.graph.AttributeMap;
import org.jgraph.graph.DefaultGraphCell;
import org.jgraph.graph.GraphConstants;
import org.jgraph.graph.GraphModel;
import org.jgrapht.DirectedGraph;
import org.jgrapht.Graph;
import org.jgrapht.ext.JGraphModelAdapter;
import org.jgrapht.graph.DefaultEdge;
import org.jgrapht.graph.DefaultListenableGraph;
import org.jgrapht.graph.DirectedMultigraph;

public class JGraphAdapterDemo extends JApplet {
  private static final long serialVersionUID = 3256444702936019250L;
  
  private static final Color DEFAULT_BG_COLOR = Color.decode("#FAFBFF");
  
  private static final Dimension DEFAULT_SIZE = new Dimension(530, 320);
  
  private JGraphModelAdapter jgAdapter;
  
  public static void main(String[] paramArrayOfString) {
    JGraphAdapterDemo jGraphAdapterDemo = new JGraphAdapterDemo();
    jGraphAdapterDemo.init();
    JFrame jFrame = new JFrame();
    jFrame.getContentPane().add(jGraphAdapterDemo);
    jFrame.setTitle("JGraphT Adapter to JGraph Demo");
    jFrame.setDefaultCloseOperation(3);
    jFrame.pack();
    jFrame.setVisible(true);
  }
  
  public void init() {
    ListenableDirectedMultigraph<Object, DefaultEdge> listenableDirectedMultigraph = new ListenableDirectedMultigraph<Object, DefaultEdge>(DefaultEdge.class);
    this.jgAdapter = new JGraphModelAdapter((Graph)listenableDirectedMultigraph);
    JGraph jGraph = new JGraph((GraphModel)this.jgAdapter);
    adjustDisplaySettings(jGraph);
    getContentPane().add((Component)jGraph);
    resize(DEFAULT_SIZE);
    String str1 = "v1";
    String str2 = "v2";
    String str3 = "v3";
    String str4 = "v4";
    listenableDirectedMultigraph.addVertex(str1);
    listenableDirectedMultigraph.addVertex(str2);
    listenableDirectedMultigraph.addVertex(str3);
    listenableDirectedMultigraph.addVertex(str4);
    listenableDirectedMultigraph.addEdge(str1, str2);
    listenableDirectedMultigraph.addEdge(str2, str3);
    listenableDirectedMultigraph.addEdge(str3, str1);
    listenableDirectedMultigraph.addEdge(str4, str3);
    positionVertexAt(str1, 130, 40);
    positionVertexAt(str2, 60, 200);
    positionVertexAt(str3, 310, 230);
    positionVertexAt(str4, 380, 70);
  }
  
  private void adjustDisplaySettings(JGraph paramJGraph) {
    paramJGraph.setPreferredSize(DEFAULT_SIZE);
    Color color = DEFAULT_BG_COLOR;
    String str = null;
    try {
      str = getParameter("bgcolor");
    } catch (Exception exception) {}
    if (str != null)
      color = Color.decode(str); 
    paramJGraph.setBackground(color);
  }
  
  private void positionVertexAt(Object paramObject, int paramInt1, int paramInt2) {
    DefaultGraphCell defaultGraphCell = this.jgAdapter.getVertexCell(paramObject);
    AttributeMap attributeMap1 = defaultGraphCell.getAttributes();
    Rectangle2D rectangle2D = GraphConstants.getBounds((Map)attributeMap1);
    Rectangle2D.Double double_ = new Rectangle2D.Double(paramInt1, paramInt2, rectangle2D.getWidth(), rectangle2D.getHeight());
    GraphConstants.setBounds((Map)attributeMap1, double_);
    AttributeMap attributeMap2 = new AttributeMap();
    attributeMap2.put(defaultGraphCell, attributeMap1);
    this.jgAdapter.edit((Map)attributeMap2, null, null, null);
  }
  
  private static class ListenableDirectedMultigraph<V, E> extends DefaultListenableGraph<V, E> implements DirectedGraph<V, E> {
    private static final long serialVersionUID = 1L;
    
    ListenableDirectedMultigraph(Class<E> param1Class) {
      super((Graph)new DirectedMultigraph(param1Class));
    }
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/demo/JGraphAdapterDemo.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */