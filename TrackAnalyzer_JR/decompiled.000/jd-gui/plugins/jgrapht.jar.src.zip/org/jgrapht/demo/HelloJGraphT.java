package org.jgrapht.demo;

import java.net.MalformedURLException;
import java.net.URL;
import org.jgrapht.DirectedGraph;
import org.jgrapht.UndirectedGraph;
import org.jgrapht.graph.DefaultDirectedGraph;
import org.jgrapht.graph.DefaultEdge;
import org.jgrapht.graph.SimpleGraph;

public final class HelloJGraphT {
  public static void main(String[] paramArrayOfString) {
    UndirectedGraph<String, DefaultEdge> undirectedGraph = createStringGraph();
    System.out.println(undirectedGraph.toString());
    DirectedGraph<URL, DefaultEdge> directedGraph = createHrefGraph();
    System.out.println(directedGraph.toString());
  }
  
  private static DirectedGraph<URL, DefaultEdge> createHrefGraph() {
    DefaultDirectedGraph defaultDirectedGraph = new DefaultDirectedGraph(DefaultEdge.class);
    try {
      URL uRL1 = new URL("http://www.amazon.com");
      URL uRL2 = new URL("http://www.yahoo.com");
      URL uRL3 = new URL("http://www.ebay.com");
      defaultDirectedGraph.addVertex(uRL1);
      defaultDirectedGraph.addVertex(uRL2);
      defaultDirectedGraph.addVertex(uRL3);
      defaultDirectedGraph.addEdge(uRL2, uRL1);
      defaultDirectedGraph.addEdge(uRL2, uRL3);
    } catch (MalformedURLException malformedURLException) {
      malformedURLException.printStackTrace();
    } 
    return (DirectedGraph<URL, DefaultEdge>)defaultDirectedGraph;
  }
  
  private static UndirectedGraph<String, DefaultEdge> createStringGraph() {
    SimpleGraph simpleGraph = new SimpleGraph(DefaultEdge.class);
    String str1 = "v1";
    String str2 = "v2";
    String str3 = "v3";
    String str4 = "v4";
    simpleGraph.addVertex(str1);
    simpleGraph.addVertex(str2);
    simpleGraph.addVertex(str3);
    simpleGraph.addVertex(str4);
    simpleGraph.addEdge(str1, str2);
    simpleGraph.addEdge(str2, str3);
    simpleGraph.addEdge(str3, str4);
    simpleGraph.addEdge(str4, str1);
    return (UndirectedGraph<String, DefaultEdge>)simpleGraph;
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/demo/HelloJGraphT.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */