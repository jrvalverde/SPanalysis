package org.jgrapht.ext;

import java.io.PrintWriter;
import java.io.Writer;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.sax.SAXTransformerFactory;
import javax.xml.transform.sax.TransformerHandler;
import javax.xml.transform.stream.StreamResult;
import org.jgrapht.Graph;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.AttributesImpl;

public class GraphMLExporter<V, E> {
  private VertexNameProvider<V> vertexIDProvider;
  
  private VertexNameProvider<V> vertexLabelProvider;
  
  private EdgeNameProvider<E> edgeIDProvider;
  
  private EdgeNameProvider<E> edgeLabelProvider;
  
  public GraphMLExporter() {
    this(new IntegerNameProvider<V>(), null, new IntegerEdgeNameProvider<E>(), null);
  }
  
  public GraphMLExporter(VertexNameProvider<V> paramVertexNameProvider1, VertexNameProvider<V> paramVertexNameProvider2, EdgeNameProvider<E> paramEdgeNameProvider1, EdgeNameProvider<E> paramEdgeNameProvider2) {
    this.vertexIDProvider = paramVertexNameProvider1;
    this.vertexLabelProvider = paramVertexNameProvider2;
    this.edgeIDProvider = paramEdgeNameProvider1;
    this.edgeLabelProvider = paramEdgeNameProvider2;
  }
  
  public void export(Writer paramWriter, Graph<V, E> paramGraph) throws SAXException, TransformerConfigurationException {
    PrintWriter printWriter = new PrintWriter(paramWriter);
    StreamResult streamResult = new StreamResult(printWriter);
    SAXTransformerFactory sAXTransformerFactory = (SAXTransformerFactory)SAXTransformerFactory.newInstance();
    TransformerHandler transformerHandler = sAXTransformerFactory.newTransformerHandler();
    Transformer transformer = transformerHandler.getTransformer();
    transformer.setOutputProperty("encoding", "UTF-8");
    transformer.setOutputProperty("indent", "yes");
    transformerHandler.setResult(streamResult);
    transformerHandler.startDocument();
    AttributesImpl attributesImpl = new AttributesImpl();
    transformerHandler.startPrefixMapping("xsi", "http://www.w3.org/2001/XMLSchema-instance");
    attributesImpl.addAttribute("", "", "xsi:schemaLocation", "CDATA", "http://graphml.graphdrawing.org/xmlns http://graphml.graphdrawing.org/xmlns/1.0/graphml.xsd");
    transformerHandler.startElement("http://graphml.graphdrawing.org/xmlns", "", "graphml", attributesImpl);
    transformerHandler.endPrefixMapping("xsi");
    if (this.vertexLabelProvider != null) {
      attributesImpl.clear();
      attributesImpl.addAttribute("", "", "id", "CDATA", "vertex_label");
      attributesImpl.addAttribute("", "", "for", "CDATA", "node");
      attributesImpl.addAttribute("", "", "attr.name", "CDATA", "Vertex Label");
      attributesImpl.addAttribute("", "", "attr.type", "CDATA", "string");
      transformerHandler.startElement("", "", "key", attributesImpl);
      transformerHandler.endElement("", "", "key");
    } 
    if (this.edgeLabelProvider != null) {
      attributesImpl.clear();
      attributesImpl.addAttribute("", "", "id", "CDATA", "edge_label");
      attributesImpl.addAttribute("", "", "for", "CDATA", "edge");
      attributesImpl.addAttribute("", "", "attr.name", "CDATA", "Edge Label");
      attributesImpl.addAttribute("", "", "attr.type", "CDATA", "string");
      transformerHandler.startElement("", "", "key", attributesImpl);
      transformerHandler.endElement("", "", "key");
    } 
    attributesImpl.clear();
    attributesImpl.addAttribute("", "", "edgedefault", "CDATA", (paramGraph instanceof org.jgrapht.DirectedGraph) ? "directed" : "undirected");
    transformerHandler.startElement("", "", "graph", attributesImpl);
    for (V v : paramGraph.vertexSet()) {
      attributesImpl.clear();
      attributesImpl.addAttribute("", "", "id", "CDATA", this.vertexIDProvider.getVertexName(v));
      transformerHandler.startElement("", "", "node", attributesImpl);
      if (this.vertexLabelProvider != null) {
        attributesImpl.clear();
        attributesImpl.addAttribute("", "", "key", "CDATA", "vertex_label");
        transformerHandler.startElement("", "", "data", attributesImpl);
        String str = this.vertexLabelProvider.getVertexName(v);
        transformerHandler.characters(str.toCharArray(), 0, str.length());
        transformerHandler.endElement("", "", "data");
      } 
      transformerHandler.endElement("", "", "node");
    } 
    for (E e : paramGraph.edgeSet()) {
      attributesImpl.clear();
      attributesImpl.addAttribute("", "", "id", "CDATA", this.edgeIDProvider.getEdgeName(e));
      attributesImpl.addAttribute("", "", "source", "CDATA", this.vertexIDProvider.getVertexName((V)paramGraph.getEdgeSource(e)));
      attributesImpl.addAttribute("", "", "target", "CDATA", this.vertexIDProvider.getVertexName((V)paramGraph.getEdgeTarget(e)));
      transformerHandler.startElement("", "", "edge", attributesImpl);
      if (this.edgeLabelProvider != null) {
        attributesImpl.clear();
        attributesImpl.addAttribute("", "", "key", "CDATA", "edge_label");
        transformerHandler.startElement("", "", "data", attributesImpl);
        String str = this.edgeLabelProvider.getEdgeName(e);
        transformerHandler.characters(str.toCharArray(), 0, str.length());
        transformerHandler.endElement("", "", "data");
      } 
      transformerHandler.endElement("", "", "edge");
    } 
    transformerHandler.endElement("", "", "graph");
    transformerHandler.endElement("", "", "graphml");
    transformerHandler.endDocument();
    printWriter.flush();
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/ext/GraphMLExporter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */