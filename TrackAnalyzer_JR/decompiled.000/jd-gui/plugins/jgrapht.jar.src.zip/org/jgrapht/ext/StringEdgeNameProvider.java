package org.jgrapht.ext;

public class StringEdgeNameProvider<E> implements EdgeNameProvider<E> {
  public String getEdgeName(E paramE) {
    return paramE.toString();
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/ext/StringEdgeNameProvider.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */