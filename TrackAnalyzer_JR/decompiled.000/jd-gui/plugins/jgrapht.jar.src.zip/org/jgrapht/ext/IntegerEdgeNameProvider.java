package org.jgrapht.ext;

import java.util.HashMap;
import java.util.Map;

public class IntegerEdgeNameProvider<E> implements EdgeNameProvider<E> {
  private int nextID = 1;
  
  private final Map<E, Integer> idMap = new HashMap<E, Integer>();
  
  public void clear() {
    this.nextID = 1;
    this.idMap.clear();
  }
  
  public String getEdgeName(E paramE) {
    Integer integer = this.idMap.get(paramE);
    if (integer == null) {
      integer = Integer.valueOf(this.nextID++);
      this.idMap.put(paramE, integer);
    } 
    return integer.toString();
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/ext/IntegerEdgeNameProvider.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */