package org.jgrapht.ext;

import java.io.PrintWriter;
import java.io.Writer;
import java.util.LinkedHashSet;
import java.util.List;
import org.jgrapht.DirectedGraph;
import org.jgrapht.Graph;
import org.jgrapht.Graphs;
import org.jgrapht.UndirectedGraph;

public class MatrixExporter<V, E> {
  private String delimiter = " ";
  
  private String prefix = "";
  
  private String suffix = "";
  
  private void println(PrintWriter paramPrintWriter, String paramString1, String paramString2, String paramString3) {
    paramPrintWriter.println(this.prefix + paramString1 + this.suffix + this.delimiter + this.prefix + paramString2 + this.suffix + this.delimiter + this.prefix + paramString3 + this.suffix);
  }
  
  public void exportAdjacencyMatrix(Writer paramWriter, UndirectedGraph<V, E> paramUndirectedGraph) {
    PrintWriter printWriter = new PrintWriter(paramWriter);
    IntegerNameProvider<V> integerNameProvider = new IntegerNameProvider();
    for (Object object : paramUndirectedGraph.vertexSet())
      integerNameProvider.getVertexName(object); 
    for (V v : paramUndirectedGraph.vertexSet())
      exportAdjacencyMatrixVertex(printWriter, integerNameProvider, v, Graphs.neighborListOf((Graph)paramUndirectedGraph, v)); 
    printWriter.flush();
  }
  
  public void exportAdjacencyMatrix(Writer paramWriter, DirectedGraph<V, E> paramDirectedGraph) {
    PrintWriter printWriter = new PrintWriter(paramWriter);
    IntegerNameProvider<V> integerNameProvider = new IntegerNameProvider();
    for (Object object : paramDirectedGraph.vertexSet())
      integerNameProvider.getVertexName(object); 
    for (V v : paramDirectedGraph.vertexSet())
      exportAdjacencyMatrixVertex(printWriter, integerNameProvider, v, Graphs.successorListOf(paramDirectedGraph, v)); 
    printWriter.flush();
  }
  
  private void exportAdjacencyMatrixVertex(PrintWriter paramPrintWriter, VertexNameProvider<V> paramVertexNameProvider, V paramV, List<V> paramList) {
    // Byte code:
    //   0: aload_2
    //   1: aload_3
    //   2: invokeinterface getVertexName : (Ljava/lang/Object;)Ljava/lang/String;
    //   7: astore #5
    //   9: new java/util/LinkedHashMap
    //   12: dup
    //   13: invokespecial <init> : ()V
    //   16: astore #6
    //   18: aload #4
    //   20: invokeinterface iterator : ()Ljava/util/Iterator;
    //   25: astore #7
    //   27: aload #7
    //   29: invokeinterface hasNext : ()Z
    //   34: ifeq -> 119
    //   37: aload #7
    //   39: invokeinterface next : ()Ljava/lang/Object;
    //   44: astore #8
    //   46: aload_2
    //   47: aload #8
    //   49: invokeinterface getVertexName : (Ljava/lang/Object;)Ljava/lang/String;
    //   54: astore #9
    //   56: aload #6
    //   58: aload #9
    //   60: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   65: checkcast org/jgrapht/util/ModifiableInteger
    //   68: astore #10
    //   70: aload #10
    //   72: ifnonnull -> 97
    //   75: new org/jgrapht/util/ModifiableInteger
    //   78: dup
    //   79: iconst_0
    //   80: invokespecial <init> : (I)V
    //   83: astore #10
    //   85: aload #6
    //   87: aload #9
    //   89: aload #10
    //   91: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   96: pop
    //   97: aload #10
    //   99: invokevirtual increment : ()V
    //   102: aload_3
    //   103: aload #8
    //   105: invokevirtual equals : (Ljava/lang/Object;)Z
    //   108: ifeq -> 116
    //   111: aload #10
    //   113: invokevirtual increment : ()V
    //   116: goto -> 27
    //   119: aload #6
    //   121: invokeinterface entrySet : ()Ljava/util/Set;
    //   126: invokeinterface iterator : ()Ljava/util/Iterator;
    //   131: astore #7
    //   133: aload #7
    //   135: invokeinterface hasNext : ()Z
    //   140: ifeq -> 196
    //   143: aload #7
    //   145: invokeinterface next : ()Ljava/lang/Object;
    //   150: checkcast java/util/Map$Entry
    //   153: astore #8
    //   155: aload #8
    //   157: invokeinterface getKey : ()Ljava/lang/Object;
    //   162: checkcast java/lang/String
    //   165: astore #9
    //   167: aload #8
    //   169: invokeinterface getValue : ()Ljava/lang/Object;
    //   174: checkcast org/jgrapht/util/ModifiableInteger
    //   177: astore #10
    //   179: aload_0
    //   180: aload_1
    //   181: aload #5
    //   183: aload #9
    //   185: aload #10
    //   187: invokevirtual toString : ()Ljava/lang/String;
    //   190: invokespecial println : (Ljava/io/PrintWriter;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    //   193: goto -> 133
    //   196: return
  }
  
  public void exportLaplacianMatrix(Writer paramWriter, UndirectedGraph<V, E> paramUndirectedGraph) {
    PrintWriter printWriter = new PrintWriter(paramWriter);
    IntegerNameProvider integerNameProvider = new IntegerNameProvider();
    for (Object object : paramUndirectedGraph.vertexSet())
      integerNameProvider.getVertexName(object); 
    for (Object object : paramUndirectedGraph.vertexSet()) {
      String str = integerNameProvider.getVertexName(object);
      List list = Graphs.neighborListOf((Graph)paramUndirectedGraph, object);
      println(printWriter, str, str, Integer.toString(list.size()));
      for (Object object1 : list) {
        String str1 = integerNameProvider.getVertexName(object1);
        println(printWriter, str, str1, "-1");
      } 
    } 
    printWriter.flush();
  }
  
  public void exportNormalizedLaplacianMatrix(Writer paramWriter, UndirectedGraph<V, E> paramUndirectedGraph) {
    PrintWriter printWriter = new PrintWriter(paramWriter);
    IntegerNameProvider integerNameProvider = new IntegerNameProvider();
    for (Object object : paramUndirectedGraph.vertexSet())
      integerNameProvider.getVertexName(object); 
    for (Object object : paramUndirectedGraph.vertexSet()) {
      String str = integerNameProvider.getVertexName(object);
      LinkedHashSet linkedHashSet = new LinkedHashSet(Graphs.neighborListOf((Graph)paramUndirectedGraph, object));
      if (linkedHashSet.isEmpty()) {
        println(printWriter, str, str, "0");
        continue;
      } 
      println(printWriter, str, str, "1");
      for (Object object1 : linkedHashSet) {
        String str1 = integerNameProvider.getVertexName(object1);
        double d = -1.0D / Math.sqrt((paramUndirectedGraph.degreeOf(object) * paramUndirectedGraph.degreeOf(object1)));
        println(printWriter, str, str1, Double.toString(d));
      } 
    } 
    printWriter.flush();
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/ext/MatrixExporter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */