package org.jgrapht.ext;

public interface EdgeNameProvider<E> {
  String getEdgeName(E paramE);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/ext/EdgeNameProvider.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */