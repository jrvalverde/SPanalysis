package org.jgrapht.ext;

import java.io.OutputStream;
import java.io.PrintStream;
import java.util.Iterator;
import org.jgrapht.Graph;

public class VisioExporter<V, E> {
  private VertexNameProvider<V> vertexNameProvider;
  
  public VisioExporter(VertexNameProvider<V> paramVertexNameProvider) {
    this.vertexNameProvider = paramVertexNameProvider;
  }
  
  public VisioExporter() {
    this(new StringNameProvider<V>());
  }
  
  public void export(OutputStream paramOutputStream, Graph<V, E> paramGraph) {
    PrintStream printStream = new PrintStream(paramOutputStream);
    Iterator<V> iterator = paramGraph.vertexSet().iterator();
    while (iterator.hasNext())
      exportVertex(printStream, iterator.next()); 
    iterator = paramGraph.edgeSet().iterator();
    while (iterator.hasNext())
      exportEdge(printStream, (E)iterator.next(), paramGraph); 
    printStream.flush();
  }
  
  private void exportEdge(PrintStream paramPrintStream, E paramE, Graph<V, E> paramGraph) {
    String str1 = this.vertexNameProvider.getVertexName((V)paramGraph.getEdgeSource(paramE));
    String str2 = this.vertexNameProvider.getVertexName((V)paramGraph.getEdgeTarget(paramE));
    paramPrintStream.print("Link,");
    paramPrintStream.print(str1);
    paramPrintStream.print("-->");
    paramPrintStream.print(str2);
    paramPrintStream.print(",,,");
    paramPrintStream.print(str1);
    paramPrintStream.print(",");
    paramPrintStream.print(str2);
    paramPrintStream.print("\n");
  }
  
  private void exportVertex(PrintStream paramPrintStream, V paramV) {
    String str = this.vertexNameProvider.getVertexName(paramV);
    paramPrintStream.print("Shape,");
    paramPrintStream.print(str);
    paramPrintStream.print(",,");
    paramPrintStream.print(str);
    paramPrintStream.print("\n");
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/ext/VisioExporter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */