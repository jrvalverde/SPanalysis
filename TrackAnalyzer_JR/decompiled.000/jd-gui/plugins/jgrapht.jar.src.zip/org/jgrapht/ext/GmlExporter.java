package org.jgrapht.ext;

import java.io.PrintWriter;
import java.io.Writer;
import org.jgrapht.DirectedGraph;
import org.jgrapht.Graph;
import org.jgrapht.UndirectedGraph;

public class GmlExporter<V, E> {
  private static final String creator = "JGraphT GML Exporter";
  
  private static final String version = "1";
  
  private static final String delim = " ";
  
  private static final String tab1 = "\t";
  
  private static final String tab2 = "\t\t";
  
  public static final Integer PRINT_NO_LABELS = Integer.valueOf(1);
  
  public static final Integer PRINT_EDGE_LABELS = Integer.valueOf(2);
  
  public static final Integer PRINT_EDGE_VERTEX_LABELS = Integer.valueOf(3);
  
  public static final Integer PRINT_VERTEX_LABELS = Integer.valueOf(4);
  
  private Integer printLabels = PRINT_NO_LABELS;
  
  private String quoted(String paramString) {
    return "\"" + paramString + "\"";
  }
  
  private void exportHeader(PrintWriter paramPrintWriter) {
    paramPrintWriter.println("Creator " + quoted("JGraphT GML Exporter"));
    paramPrintWriter.println("Version 1");
  }
  
  private void exportVertices(PrintWriter paramPrintWriter, VertexNameProvider<V> paramVertexNameProvider, Graph<V, E> paramGraph) {
    for (V v : paramGraph.vertexSet()) {
      paramPrintWriter.println("\tnode");
      paramPrintWriter.println("\t[");
      paramPrintWriter.println("\t\tid " + paramVertexNameProvider.getVertexName(v));
      if (this.printLabels == PRINT_VERTEX_LABELS || this.printLabels == PRINT_EDGE_VERTEX_LABELS)
        paramPrintWriter.println("\t\tlabel " + quoted(v.toString())); 
      paramPrintWriter.println("\t]");
    } 
  }
  
  private void exportEdges(PrintWriter paramPrintWriter, VertexNameProvider<V> paramVertexNameProvider, Graph<V, E> paramGraph) {
    for (Object object : paramGraph.edgeSet()) {
      paramPrintWriter.println("\tedge");
      paramPrintWriter.println("\t[");
      String str1 = paramVertexNameProvider.getVertexName((V)paramGraph.getEdgeSource(object));
      paramPrintWriter.println("\t\tsource " + str1);
      String str2 = paramVertexNameProvider.getVertexName((V)paramGraph.getEdgeTarget(object));
      paramPrintWriter.println("\t\ttarget " + str2);
      if (this.printLabels == PRINT_EDGE_LABELS || this.printLabels == PRINT_EDGE_VERTEX_LABELS)
        paramPrintWriter.println("\t\tlabel " + quoted(object.toString())); 
      paramPrintWriter.println("\t]");
    } 
  }
  
  private void export(Writer paramWriter, Graph<V, E> paramGraph, boolean paramBoolean) {
    PrintWriter printWriter = new PrintWriter(paramWriter);
    IntegerNameProvider<V> integerNameProvider = new IntegerNameProvider();
    for (Object object : paramGraph.vertexSet())
      integerNameProvider.getVertexName(object); 
    exportHeader(printWriter);
    printWriter.println("graph");
    printWriter.println("[");
    printWriter.println("\tlabel " + quoted(""));
    if (paramBoolean) {
      printWriter.println("\tdirected 1");
    } else {
      printWriter.println("\tdirected 0");
    } 
    exportVertices(printWriter, integerNameProvider, paramGraph);
    exportEdges(printWriter, integerNameProvider, paramGraph);
    printWriter.println("]");
    printWriter.flush();
  }
  
  public void export(Writer paramWriter, UndirectedGraph<V, E> paramUndirectedGraph) {
    export(paramWriter, (Graph<V, E>)paramUndirectedGraph, false);
  }
  
  public void export(Writer paramWriter, DirectedGraph<V, E> paramDirectedGraph) {
    export(paramWriter, (Graph<V, E>)paramDirectedGraph, true);
  }
  
  public void setPrintLabels(Integer paramInteger) {
    if (paramInteger != PRINT_NO_LABELS && paramInteger != PRINT_EDGE_LABELS && paramInteger != PRINT_EDGE_VERTEX_LABELS && paramInteger != PRINT_VERTEX_LABELS)
      throw new IllegalArgumentException("Non-supported parameter value: " + Integer.toString(paramInteger.intValue())); 
    this.printLabels = paramInteger;
  }
  
  public Integer getPrintLabels() {
    return this.printLabels;
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/ext/GmlExporter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */