package org.jgrapht.ext;

import java.awt.Color;
import java.awt.geom.Rectangle2D;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.swing.BorderFactory;
import javax.swing.tree.MutableTreeNode;
import org.jgraph.event.GraphModelEvent;
import org.jgraph.event.GraphModelListener;
import org.jgraph.graph.AttributeMap;
import org.jgraph.graph.ConnectionSet;
import org.jgraph.graph.DefaultEdge;
import org.jgraph.graph.DefaultGraphCell;
import org.jgraph.graph.DefaultGraphModel;
import org.jgraph.graph.DefaultPort;
import org.jgraph.graph.Edge;
import org.jgraph.graph.GraphCell;
import org.jgraph.graph.GraphConstants;
import org.jgraph.graph.GraphModel;
import org.jgrapht.EdgeFactory;
import org.jgrapht.Graph;
import org.jgrapht.ListenableGraph;
import org.jgrapht.event.GraphEdgeChangeEvent;
import org.jgrapht.event.GraphListener;
import org.jgrapht.event.GraphVertexChangeEvent;

public class JGraphModelAdapter<V, E> extends DefaultGraphModel {
  private static final long serialVersionUID = 3256722883706302515L;
  
  final Set<GraphCell> jCellsBeingAdded = new HashSet<GraphCell>();
  
  final Set<GraphCell> jCellsBeingRemoved = new HashSet<GraphCell>();
  
  final Set<Object> jtElementsBeingAdded = new HashSet();
  
  final Set<Object> jtElementsBeingRemoved = new HashSet();
  
  private final CellFactory<V, E> cellFactory;
  
  private final Map<Edge, E> cellToEdge = new HashMap<Edge, E>();
  
  private final Map<GraphCell, V> cellToVertex = new HashMap<GraphCell, V>();
  
  private AttributeMap defaultEdgeAttributes;
  
  private AttributeMap defaultVertexAttributes;
  
  private final Map<E, Edge> edgeToCell = new HashMap<E, Edge>();
  
  private final Map<V, GraphCell> vertexToCell = new HashMap<V, GraphCell>();
  
  private final ShieldedGraph jtGraph;
  
  public JGraphModelAdapter(Graph<V, E> paramGraph) {
    this(paramGraph, createDefaultVertexAttributes(), createDefaultEdgeAttributes(paramGraph));
  }
  
  public JGraphModelAdapter(Graph<V, E> paramGraph, AttributeMap paramAttributeMap1, AttributeMap paramAttributeMap2) {
    this(paramGraph, paramAttributeMap1, paramAttributeMap2, new DefaultCellFactory<V, E>());
  }
  
  public JGraphModelAdapter(Graph<V, E> paramGraph, AttributeMap paramAttributeMap1, AttributeMap paramAttributeMap2, CellFactory<V, E> paramCellFactory) {
    if (paramGraph == null || paramAttributeMap1 == null || paramAttributeMap2 == null || paramCellFactory == null)
      throw new IllegalArgumentException("null is NOT permitted"); 
    this.jtGraph = new ShieldedGraph(paramGraph);
    setDefaultVertexAttributes(paramAttributeMap1);
    setDefaultEdgeAttributes(paramAttributeMap2);
    this.cellFactory = paramCellFactory;
    if (paramGraph instanceof ListenableGraph) {
      ListenableGraph listenableGraph = (ListenableGraph)paramGraph;
      listenableGraph.addGraphListener(new JGraphTListener());
    } 
    Iterator<V> iterator = paramGraph.vertexSet().iterator();
    while (iterator.hasNext())
      handleJGraphTAddedVertex(iterator.next()); 
    iterator = paramGraph.edgeSet().iterator();
    while (iterator.hasNext())
      handleJGraphTAddedEdge((E)iterator.next()); 
    addGraphModelListener(new JGraphListener());
  }
  
  public static <V, E> AttributeMap createDefaultEdgeAttributes(Graph<V, E> paramGraph) {
    AttributeMap attributeMap = new AttributeMap();
    if (paramGraph instanceof org.jgrapht.DirectedGraph) {
      GraphConstants.setLineEnd((Map)attributeMap, 2);
      GraphConstants.setEndFill((Map)attributeMap, true);
      GraphConstants.setEndSize((Map)attributeMap, 10);
    } 
    GraphConstants.setForeground((Map)attributeMap, Color.decode("#25507C"));
    GraphConstants.setFont((Map)attributeMap, GraphConstants.DEFAULTFONT.deriveFont(1, 12.0F));
    GraphConstants.setLineColor((Map)attributeMap, Color.decode("#7AA1E6"));
    return attributeMap;
  }
  
  public static AttributeMap createDefaultVertexAttributes() {
    AttributeMap attributeMap = new AttributeMap();
    Color color = Color.decode("#FF9900");
    GraphConstants.setBounds((Map)attributeMap, new Rectangle2D.Double(50.0D, 50.0D, 90.0D, 30.0D));
    GraphConstants.setBorder((Map)attributeMap, BorderFactory.createRaisedBevelBorder());
    GraphConstants.setBackground((Map)attributeMap, color);
    GraphConstants.setForeground((Map)attributeMap, Color.white);
    GraphConstants.setFont((Map)attributeMap, GraphConstants.DEFAULTFONT.deriveFont(1, 12.0F));
    GraphConstants.setOpaque((Map)attributeMap, true);
    return attributeMap;
  }
  
  public CellFactory<V, E> getCellFactory() {
    return this.cellFactory;
  }
  
  public void setDefaultEdgeAttributes(AttributeMap paramAttributeMap) {
    this.defaultEdgeAttributes = paramAttributeMap;
  }
  
  public AttributeMap getDefaultEdgeAttributes() {
    return this.defaultEdgeAttributes;
  }
  
  public void setDefaultVertexAttributes(AttributeMap paramAttributeMap) {
    this.defaultVertexAttributes = paramAttributeMap;
  }
  
  public AttributeMap getDefaultVertexAttributes() {
    return this.defaultVertexAttributes;
  }
  
  public DefaultEdge getEdgeCell(E paramE) {
    return (DefaultEdge)this.edgeToCell.get(paramE);
  }
  
  public DefaultGraphCell getVertexCell(Object paramObject) {
    return (DefaultGraphCell)this.vertexToCell.get(paramObject);
  }
  
  public DefaultPort getVertexPort(Object paramObject) {
    DefaultGraphCell defaultGraphCell = getVertexCell(paramObject);
    return (defaultGraphCell == null) ? null : (DefaultPort)defaultGraphCell.getChildAt(0);
  }
  
  void handleJGraphChangedEdge(Edge paramEdge) {
    if (isDangling(paramEdge)) {
      if (this.cellToEdge.containsKey(paramEdge))
        handleJGraphRemovedEdge(paramEdge); 
    } else if (this.cellToEdge.containsKey(paramEdge)) {
      E e = this.cellToEdge.get(paramEdge);
      Object object1 = getSourceVertex((GraphModel)this, paramEdge);
      Object object2 = getTargetVertex((GraphModel)this, paramEdge);
      V v1 = this.cellToVertex.get(object1);
      V v2 = this.cellToVertex.get(object2);
      if (this.jtGraph.getEdgeSource(e) != v1 || this.jtGraph.getEdgeTarget(e) != v2) {
        handleJGraphRemovedEdge(paramEdge);
        handleJGraphInsertedEdge(paramEdge);
      } 
    } else {
      handleJGraphInsertedEdge(paramEdge);
    } 
  }
  
  void handleJGraphInsertedEdge(Edge paramEdge) {
    if (!isDangling(paramEdge)) {
      Object object1 = getSourceVertex((GraphModel)this, paramEdge);
      Object object2 = getTargetVertex((GraphModel)this, paramEdge);
      V v1 = this.cellToVertex.get(object1);
      V v2 = this.cellToVertex.get(object2);
      E e = this.jtGraph.addEdge(v1, v2);
      if (e != null) {
        this.cellToEdge.put(paramEdge, e);
        this.edgeToCell.put(e, paramEdge);
      } else {
        internalRemoveCell((GraphCell)paramEdge);
        System.err.println("Warning: an edge was deleted because the underlying JGraphT graph refused to create it. This situation can happen when a constraint of the underlying graph is violated, e.g., an attempt to add a parallel edge or a self-loop to a graph that forbids them. To avoid this message, make sure to use a suitable underlying JGraphT graph.");
      } 
    } 
  }
  
  void handleJGraphInsertedVertex(GraphCell paramGraphCell) {
    Object object;
    if (paramGraphCell instanceof DefaultGraphCell) {
      object = ((DefaultGraphCell)paramGraphCell).getUserObject();
    } else {
      object = paramGraphCell.toString();
    } 
    if (this.vertexToCell.containsKey(object)) {
      System.err.println("Warning: detected two JGraph vertices with the same JGraphT vertex as user object. It is an indication for a faulty situation that should NOT happen.Removing vertex: " + paramGraphCell);
      internalRemoveCell(paramGraphCell);
    } else {
      this.jtGraph.addVertex((V)object);
      this.cellToVertex.put(paramGraphCell, (V)object);
      this.vertexToCell.put((V)object, paramGraphCell);
    } 
  }
  
  void handleJGraphRemovedEdge(Edge paramEdge) {
    if (this.cellToEdge.containsKey(paramEdge)) {
      E e = this.cellToEdge.get(paramEdge);
      this.jtGraph.removeEdge(e);
      this.cellToEdge.remove(paramEdge);
      this.edgeToCell.remove(e);
    } 
  }
  
  void handleJGraphRemovedVertex(GraphCell paramGraphCell) {
    if (this.cellToVertex.containsKey(paramGraphCell)) {
      V v = this.cellToVertex.get(paramGraphCell);
      Set<E> set = this.jtGraph.edgesOf(v);
      if (!set.isEmpty())
        this.jtGraph.removeAllEdges(new ArrayList<E>(set)); 
      this.jtGraph.removeVertex(v);
      this.cellToVertex.remove(paramGraphCell);
      this.vertexToCell.remove(v);
    } 
  }
  
  void handleJGraphTAddedEdge(E paramE) {
    DefaultEdge defaultEdge = this.cellFactory.createEdgeCell(paramE);
    this.edgeToCell.put(paramE, defaultEdge);
    this.cellToEdge.put(defaultEdge, paramE);
    ConnectionSet connectionSet = new ConnectionSet();
    connectionSet.connect(defaultEdge, getVertexPort(this.jtGraph.getEdgeSource(paramE)), getVertexPort(this.jtGraph.getEdgeTarget(paramE)));
    internalInsertCell((GraphCell)defaultEdge, createEdgeAttributeMap(defaultEdge), connectionSet);
  }
  
  void handleJGraphTAddedVertex(V paramV) {
    DefaultGraphCell defaultGraphCell = this.cellFactory.createVertexCell(paramV);
    defaultGraphCell.add((MutableTreeNode)new DefaultPort());
    this.vertexToCell.put(paramV, defaultGraphCell);
    this.cellToVertex.put(defaultGraphCell, paramV);
    internalInsertCell((GraphCell)defaultGraphCell, createVertexAttributeMap((GraphCell)defaultGraphCell), (ConnectionSet)null);
  }
  
  void handleJGraphTRemoveVertex(Object paramObject) {
    DefaultGraphCell defaultGraphCell = (DefaultGraphCell)this.vertexToCell.remove(paramObject);
    this.cellToVertex.remove(defaultGraphCell);
    ArrayList arrayList = new ArrayList();
    for (Object object : defaultGraphCell.getChildren()) {
      if (isPort(object))
        arrayList.add(object); 
    } 
    remove(arrayList.toArray());
    internalRemoveCell((GraphCell)defaultGraphCell);
  }
  
  void handleJGraphTRemovedEdge(E paramE) {
    DefaultEdge defaultEdge = (DefaultEdge)this.edgeToCell.remove(paramE);
    this.cellToEdge.remove(defaultEdge);
    internalRemoveCell((GraphCell)defaultEdge);
  }
  
  private boolean isDangling(Edge paramEdge) {
    Object object1 = getSourceVertex((GraphModel)this, paramEdge);
    Object object2 = getTargetVertex((GraphModel)this, paramEdge);
    return (!this.cellToVertex.containsKey(object1) || !this.cellToVertex.containsKey(object2));
  }
  
  private AttributeMap createEdgeAttributeMap(DefaultEdge paramDefaultEdge) {
    AttributeMap attributeMap = new AttributeMap();
    attributeMap.put(paramDefaultEdge, getDefaultEdgeAttributes().clone());
    return attributeMap;
  }
  
  private AttributeMap createVertexAttributeMap(GraphCell paramGraphCell) {
    AttributeMap attributeMap = new AttributeMap();
    attributeMap.put(paramGraphCell, getDefaultVertexAttributes().clone());
    return attributeMap;
  }
  
  private void internalInsertCell(GraphCell paramGraphCell, AttributeMap paramAttributeMap, ConnectionSet paramConnectionSet) {
    this.jCellsBeingAdded.add(paramGraphCell);
    insert(new Object[] { paramGraphCell }, (Map)paramAttributeMap, paramConnectionSet, null, null);
    this.jCellsBeingAdded.remove(paramGraphCell);
  }
  
  private void internalRemoveCell(GraphCell paramGraphCell) {
    this.jCellsBeingRemoved.add(paramGraphCell);
    remove(new Object[] { paramGraphCell });
    this.jCellsBeingRemoved.remove(paramGraphCell);
  }
  
  private class ShieldedGraph {
    private final Graph<V, E> graph;
    
    ShieldedGraph(Graph<V, E> param1Graph) {
      this.graph = param1Graph;
    }
    
    EdgeFactory<V, E> getEdgeFactory() {
      return this.graph.getEdgeFactory();
    }
    
    E addEdge(V param1V1, V param1V2) {
      Object object = this.graph.getEdgeFactory().createEdge(param1V1, param1V2);
      JGraphModelAdapter.this.jtElementsBeingAdded.add(object);
      boolean bool = this.graph.addEdge(param1V1, param1V2, object);
      JGraphModelAdapter.this.jtElementsBeingAdded.remove(object);
      return bool ? (E)object : null;
    }
    
    V getEdgeSource(E param1E) {
      return (V)this.graph.getEdgeSource(param1E);
    }
    
    V getEdgeTarget(E param1E) {
      return (V)this.graph.getEdgeTarget(param1E);
    }
    
    void addVertex(V param1V) {
      JGraphModelAdapter.this.jtElementsBeingAdded.add(param1V);
      this.graph.addVertex(param1V);
      JGraphModelAdapter.this.jtElementsBeingAdded.remove(param1V);
    }
    
    Set<E> edgesOf(V param1V) {
      return this.graph.edgesOf(param1V);
    }
    
    boolean removeAllEdges(Collection<E> param1Collection) {
      return this.graph.removeAllEdges(param1Collection);
    }
    
    void removeEdge(E param1E) {
      JGraphModelAdapter.this.jtElementsBeingRemoved.add(param1E);
      this.graph.removeEdge(param1E);
      JGraphModelAdapter.this.jtElementsBeingRemoved.remove(param1E);
    }
    
    void removeVertex(V param1V) {
      JGraphModelAdapter.this.jtElementsBeingRemoved.add(param1V);
      this.graph.removeVertex(param1V);
      JGraphModelAdapter.this.jtElementsBeingRemoved.remove(param1V);
    }
  }
  
  private class JGraphTListener implements GraphListener<V, E>, Serializable {
    private static final long serialVersionUID = 3616724963609360440L;
    
    private JGraphTListener() {}
    
    public void edgeAdded(GraphEdgeChangeEvent<V, E> param1GraphEdgeChangeEvent) {
      Object object = param1GraphEdgeChangeEvent.getEdge();
      if (!JGraphModelAdapter.this.jtElementsBeingAdded.remove(object))
        JGraphModelAdapter.this.handleJGraphTAddedEdge(object); 
    }
    
    public void edgeRemoved(GraphEdgeChangeEvent<V, E> param1GraphEdgeChangeEvent) {
      Object object = param1GraphEdgeChangeEvent.getEdge();
      if (!JGraphModelAdapter.this.jtElementsBeingRemoved.remove(object))
        JGraphModelAdapter.this.handleJGraphTRemovedEdge(object); 
    }
    
    public void vertexAdded(GraphVertexChangeEvent<V> param1GraphVertexChangeEvent) {
      Object object = param1GraphVertexChangeEvent.getVertex();
      if (!JGraphModelAdapter.this.jtElementsBeingAdded.remove(object))
        JGraphModelAdapter.this.handleJGraphTAddedVertex(object); 
    }
    
    public void vertexRemoved(GraphVertexChangeEvent<V> param1GraphVertexChangeEvent) {
      Object object = param1GraphVertexChangeEvent.getVertex();
      if (!JGraphModelAdapter.this.jtElementsBeingRemoved.remove(object))
        JGraphModelAdapter.this.handleJGraphTRemoveVertex(object); 
    }
  }
  
  private class JGraphListener implements GraphModelListener, Serializable {
    private static final long serialVersionUID = 3544673988098865209L;
    
    private JGraphListener() {}
    
    public void graphChanged(GraphModelEvent param1GraphModelEvent) {
      GraphModelEvent.GraphModelChange graphModelChange = param1GraphModelEvent.getChange();
      Object[] arrayOfObject1 = graphModelChange.getRemoved();
      if (arrayOfObject1 != null) {
        handleRemovedEdges(filterEdges(arrayOfObject1));
        handleRemovedVertices(filterVertices(arrayOfObject1));
      } 
      Object[] arrayOfObject2 = graphModelChange.getInserted();
      if (arrayOfObject2 != null) {
        handleInsertedVertices(filterVertices(arrayOfObject2));
        handleInsertedEdges(filterEdges(arrayOfObject2));
      } 
      Object[] arrayOfObject3 = graphModelChange.getChanged();
      if (arrayOfObject3 != null)
        handleChangedEdges(filterEdges(arrayOfObject3)); 
    }
    
    private List<Object> filterEdges(Object[] param1ArrayOfObject) {
      ArrayList<Object> arrayList = new ArrayList();
      for (byte b = 0; b < param1ArrayOfObject.length; b++) {
        if (param1ArrayOfObject[b] instanceof Edge)
          arrayList.add(param1ArrayOfObject[b]); 
      } 
      return arrayList;
    }
    
    private List<Object> filterVertices(Object[] param1ArrayOfObject) {
      ArrayList<Object> arrayList = new ArrayList();
      for (byte b = 0; b < param1ArrayOfObject.length; b++) {
        Object object = param1ArrayOfObject[b];
        if (!(object instanceof Edge) && !(object instanceof org.jgraph.graph.Port))
          if (object instanceof DefaultGraphCell) {
            DefaultGraphCell defaultGraphCell = (DefaultGraphCell)object;
            if (defaultGraphCell.isLeaf() || defaultGraphCell.getFirstChild() instanceof org.jgraph.graph.Port)
              arrayList.add(object); 
          } else if (object instanceof GraphCell) {
            arrayList.add(object);
          }  
      } 
      return arrayList;
    }
    
    private void handleChangedEdges(List<Object> param1List) {
      for (Edge edge : param1List)
        JGraphModelAdapter.this.handleJGraphChangedEdge(edge); 
    }
    
    private void handleInsertedEdges(List<Object> param1List) {
      for (Edge edge : param1List) {
        if (!JGraphModelAdapter.this.jCellsBeingAdded.remove(edge))
          JGraphModelAdapter.this.handleJGraphInsertedEdge(edge); 
      } 
    }
    
    private void handleInsertedVertices(List<Object> param1List) {
      for (GraphCell graphCell : param1List) {
        if (!JGraphModelAdapter.this.jCellsBeingAdded.remove(graphCell))
          JGraphModelAdapter.this.handleJGraphInsertedVertex(graphCell); 
      } 
    }
    
    private void handleRemovedEdges(List<Object> param1List) {
      for (Edge edge : param1List) {
        if (!JGraphModelAdapter.this.jCellsBeingRemoved.remove(edge))
          JGraphModelAdapter.this.handleJGraphRemovedEdge(edge); 
      } 
    }
    
    private void handleRemovedVertices(List<Object> param1List) {
      for (GraphCell graphCell : param1List) {
        if (!JGraphModelAdapter.this.jCellsBeingRemoved.remove(graphCell))
          JGraphModelAdapter.this.handleJGraphRemovedVertex(graphCell); 
      } 
    }
  }
  
  public static class DefaultCellFactory<VV, EE> implements CellFactory<VV, EE>, Serializable {
    private static final long serialVersionUID = 3690194343461861173L;
    
    public DefaultEdge createEdgeCell(EE param1EE) {
      return new DefaultEdge(param1EE);
    }
    
    public DefaultGraphCell createVertexCell(VV param1VV) {
      return new DefaultGraphCell(param1VV);
    }
  }
  
  public static interface CellFactory<VV, EE> {
    DefaultEdge createEdgeCell(EE param1EE);
    
    DefaultGraphCell createVertexCell(VV param1VV);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/ext/JGraphModelAdapter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */