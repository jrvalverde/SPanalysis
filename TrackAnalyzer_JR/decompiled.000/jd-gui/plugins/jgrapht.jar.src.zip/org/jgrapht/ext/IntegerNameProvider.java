package org.jgrapht.ext;

import java.util.HashMap;
import java.util.Map;

public class IntegerNameProvider<V> implements VertexNameProvider<V> {
  private int nextID = 1;
  
  private final Map<V, Integer> idMap = new HashMap<V, Integer>();
  
  public void clear() {
    this.nextID = 1;
    this.idMap.clear();
  }
  
  public String getVertexName(V paramV) {
    Integer integer = this.idMap.get(paramV);
    if (integer == null) {
      integer = Integer.valueOf(this.nextID++);
      this.idMap.put(paramV, integer);
    } 
    return integer.toString();
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/ext/IntegerNameProvider.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */