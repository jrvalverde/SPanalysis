package org.jgrapht.ext;

import java.io.PrintWriter;
import java.io.Writer;
import org.jgrapht.Graph;

public class DOTExporter<V, E> {
  private VertexNameProvider<V> vertexIDProvider;
  
  private VertexNameProvider<V> vertexLabelProvider;
  
  private EdgeNameProvider<E> edgeLabelProvider;
  
  public DOTExporter() {
    this(new IntegerNameProvider<V>(), null, null);
  }
  
  public DOTExporter(VertexNameProvider<V> paramVertexNameProvider1, VertexNameProvider<V> paramVertexNameProvider2, EdgeNameProvider<E> paramEdgeNameProvider) {
    this.vertexIDProvider = paramVertexNameProvider1;
    this.vertexLabelProvider = paramVertexNameProvider2;
    this.edgeLabelProvider = paramEdgeNameProvider;
  }
  
  public void export(Writer paramWriter, Graph<V, E> paramGraph) {
    String str2;
    PrintWriter printWriter = new PrintWriter(paramWriter);
    String str1 = "  ";
    if (paramGraph instanceof org.jgrapht.DirectedGraph) {
      printWriter.println("digraph G {");
      str2 = " -> ";
    } else {
      printWriter.println("graph G {");
      str2 = " -- ";
    } 
    for (V v : paramGraph.vertexSet()) {
      printWriter.print(str1 + this.vertexIDProvider.getVertexName(v));
      if (this.vertexLabelProvider != null)
        printWriter.print(" [label = \"" + this.vertexLabelProvider.getVertexName(v) + "\"]"); 
      printWriter.println(";");
    } 
    for (E e : paramGraph.edgeSet()) {
      String str3 = this.vertexIDProvider.getVertexName((V)paramGraph.getEdgeSource(e));
      String str4 = this.vertexIDProvider.getVertexName((V)paramGraph.getEdgeTarget(e));
      printWriter.print(str1 + str3 + str2 + str4);
      if (this.edgeLabelProvider != null)
        printWriter.print(" [label = \"" + this.edgeLabelProvider.getEdgeName(e) + "\"]"); 
      printWriter.println(";");
    } 
    printWriter.println("}");
    printWriter.flush();
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/ext/DOTExporter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */