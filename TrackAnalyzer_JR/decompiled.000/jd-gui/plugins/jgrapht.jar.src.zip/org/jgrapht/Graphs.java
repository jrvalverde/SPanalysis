package org.jgrapht;

import java.util.Collection;
import java.util.List;
import org.jgrapht.graph.AsUndirectedGraph;

public abstract class Graphs {
  public static <V, E> E addEdge(Graph<V, E> paramGraph, V paramV1, V paramV2, double paramDouble) {
    EdgeFactory<V, E> edgeFactory = paramGraph.getEdgeFactory();
    E e = edgeFactory.createEdge(paramV1, paramV2);
    assert paramGraph instanceof WeightedGraph : paramGraph.getClass();
    ((WeightedGraph)paramGraph).setEdgeWeight(e, paramDouble);
    return paramGraph.addEdge(paramV1, paramV2, e) ? e : null;
  }
  
  public static <V, E> E addEdgeWithVertices(Graph<V, E> paramGraph, V paramV1, V paramV2) {
    paramGraph.addVertex(paramV1);
    paramGraph.addVertex(paramV2);
    return paramGraph.addEdge(paramV1, paramV2);
  }
  
  public static <V, E> boolean addEdgeWithVertices(Graph<V, E> paramGraph1, Graph<V, E> paramGraph2, E paramE) {
    V v1 = paramGraph2.getEdgeSource(paramE);
    V v2 = paramGraph2.getEdgeTarget(paramE);
    paramGraph1.addVertex(v1);
    paramGraph1.addVertex(v2);
    return paramGraph1.addEdge(v1, v2, paramE);
  }
  
  public static <V, E> E addEdgeWithVertices(Graph<V, E> paramGraph, V paramV1, V paramV2, double paramDouble) {
    paramGraph.addVertex(paramV1);
    paramGraph.addVertex(paramV2);
    return addEdge(paramGraph, paramV1, paramV2, paramDouble);
  }
  
  public static <V, E> boolean addGraph(Graph<? super V, ? super E> paramGraph, Graph<V, E> paramGraph1) {
    boolean bool = addAllVertices(paramGraph, paramGraph1.vertexSet());
    bool |= addAllEdges(paramGraph, paramGraph1, paramGraph1.edgeSet());
    return bool;
  }
  
  public static <V, E> void addGraphReversed(DirectedGraph<? super V, ? super E> paramDirectedGraph, DirectedGraph<V, E> paramDirectedGraph1) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokeinterface vertexSet : ()Ljava/util/Set;
    //   7: invokestatic addAllVertices : (Lorg/jgrapht/Graph;Ljava/util/Collection;)Z
    //   10: pop
    //   11: aload_1
    //   12: invokeinterface edgeSet : ()Ljava/util/Set;
    //   17: invokeinterface iterator : ()Ljava/util/Iterator;
    //   22: astore_2
    //   23: aload_2
    //   24: invokeinterface hasNext : ()Z
    //   29: ifeq -> 63
    //   32: aload_2
    //   33: invokeinterface next : ()Ljava/lang/Object;
    //   38: astore_3
    //   39: aload_0
    //   40: aload_1
    //   41: aload_3
    //   42: invokeinterface getEdgeTarget : (Ljava/lang/Object;)Ljava/lang/Object;
    //   47: aload_1
    //   48: aload_3
    //   49: invokeinterface getEdgeSource : (Ljava/lang/Object;)Ljava/lang/Object;
    //   54: invokeinterface addEdge : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   59: pop
    //   60: goto -> 23
    //   63: return
  }
  
  public static <V, E> boolean addAllEdges(Graph<? super V, ? super E> paramGraph, Graph<V, E> paramGraph1, Collection<? extends E> paramCollection) {
    // Byte code:
    //   0: iconst_0
    //   1: istore_3
    //   2: aload_2
    //   3: invokeinterface iterator : ()Ljava/util/Iterator;
    //   8: astore #4
    //   10: aload #4
    //   12: invokeinterface hasNext : ()Z
    //   17: ifeq -> 85
    //   20: aload #4
    //   22: invokeinterface next : ()Ljava/lang/Object;
    //   27: astore #5
    //   29: aload_1
    //   30: aload #5
    //   32: invokeinterface getEdgeSource : (Ljava/lang/Object;)Ljava/lang/Object;
    //   37: astore #6
    //   39: aload_1
    //   40: aload #5
    //   42: invokeinterface getEdgeTarget : (Ljava/lang/Object;)Ljava/lang/Object;
    //   47: astore #7
    //   49: aload_0
    //   50: aload #6
    //   52: invokeinterface addVertex : (Ljava/lang/Object;)Z
    //   57: pop
    //   58: aload_0
    //   59: aload #7
    //   61: invokeinterface addVertex : (Ljava/lang/Object;)Z
    //   66: pop
    //   67: iload_3
    //   68: aload_0
    //   69: aload #6
    //   71: aload #7
    //   73: aload #5
    //   75: invokeinterface addEdge : (Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Z
    //   80: ior
    //   81: istore_3
    //   82: goto -> 10
    //   85: iload_3
    //   86: ireturn
  }
  
  public static <V, E> boolean addAllVertices(Graph<? super V, ? super E> paramGraph, Collection<? extends V> paramCollection) {
    // Byte code:
    //   0: iconst_0
    //   1: istore_2
    //   2: aload_1
    //   3: invokeinterface iterator : ()Ljava/util/Iterator;
    //   8: astore_3
    //   9: aload_3
    //   10: invokeinterface hasNext : ()Z
    //   15: ifeq -> 40
    //   18: aload_3
    //   19: invokeinterface next : ()Ljava/lang/Object;
    //   24: astore #4
    //   26: iload_2
    //   27: aload_0
    //   28: aload #4
    //   30: invokeinterface addVertex : (Ljava/lang/Object;)Z
    //   35: ior
    //   36: istore_2
    //   37: goto -> 9
    //   40: iload_2
    //   41: ireturn
  }
  
  public static <V, E> List<V> neighborListOf(Graph<V, E> paramGraph, V paramV) {
    // Byte code:
    //   0: new java/util/ArrayList
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore_2
    //   8: aload_0
    //   9: aload_1
    //   10: invokeinterface edgesOf : (Ljava/lang/Object;)Ljava/util/Set;
    //   15: invokeinterface iterator : ()Ljava/util/Iterator;
    //   20: astore_3
    //   21: aload_3
    //   22: invokeinterface hasNext : ()Z
    //   27: ifeq -> 55
    //   30: aload_3
    //   31: invokeinterface next : ()Ljava/lang/Object;
    //   36: astore #4
    //   38: aload_2
    //   39: aload_0
    //   40: aload #4
    //   42: aload_1
    //   43: invokestatic getOppositeVertex : (Lorg/jgrapht/Graph;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   46: invokeinterface add : (Ljava/lang/Object;)Z
    //   51: pop
    //   52: goto -> 21
    //   55: aload_2
    //   56: areturn
  }
  
  public static <V, E> List<V> predecessorListOf(DirectedGraph<V, E> paramDirectedGraph, V paramV) {
    // Byte code:
    //   0: new java/util/ArrayList
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore_2
    //   8: aload_0
    //   9: aload_1
    //   10: invokeinterface incomingEdgesOf : (Ljava/lang/Object;)Ljava/util/Set;
    //   15: astore_3
    //   16: aload_3
    //   17: invokeinterface iterator : ()Ljava/util/Iterator;
    //   22: astore #4
    //   24: aload #4
    //   26: invokeinterface hasNext : ()Z
    //   31: ifeq -> 60
    //   34: aload #4
    //   36: invokeinterface next : ()Ljava/lang/Object;
    //   41: astore #5
    //   43: aload_2
    //   44: aload_0
    //   45: aload #5
    //   47: aload_1
    //   48: invokestatic getOppositeVertex : (Lorg/jgrapht/Graph;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   51: invokeinterface add : (Ljava/lang/Object;)Z
    //   56: pop
    //   57: goto -> 24
    //   60: aload_2
    //   61: areturn
  }
  
  public static <V, E> List<V> successorListOf(DirectedGraph<V, E> paramDirectedGraph, V paramV) {
    // Byte code:
    //   0: new java/util/ArrayList
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore_2
    //   8: aload_0
    //   9: aload_1
    //   10: invokeinterface outgoingEdgesOf : (Ljava/lang/Object;)Ljava/util/Set;
    //   15: astore_3
    //   16: aload_3
    //   17: invokeinterface iterator : ()Ljava/util/Iterator;
    //   22: astore #4
    //   24: aload #4
    //   26: invokeinterface hasNext : ()Z
    //   31: ifeq -> 60
    //   34: aload #4
    //   36: invokeinterface next : ()Ljava/lang/Object;
    //   41: astore #5
    //   43: aload_2
    //   44: aload_0
    //   45: aload #5
    //   47: aload_1
    //   48: invokestatic getOppositeVertex : (Lorg/jgrapht/Graph;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   51: invokeinterface add : (Ljava/lang/Object;)Z
    //   56: pop
    //   57: goto -> 24
    //   60: aload_2
    //   61: areturn
  }
  
  public static <V, E> UndirectedGraph<V, E> undirectedGraph(Graph<V, E> paramGraph) {
    if (paramGraph instanceof DirectedGraph)
      return (UndirectedGraph<V, E>)new AsUndirectedGraph((DirectedGraph)paramGraph); 
    if (paramGraph instanceof UndirectedGraph)
      return (UndirectedGraph<V, E>)paramGraph; 
    throw new IllegalArgumentException("Graph must be either DirectedGraph or UndirectedGraph");
  }
  
  public static <V, E> boolean testIncidence(Graph<V, E> paramGraph, E paramE, V paramV) {
    return (paramGraph.getEdgeSource(paramE).equals(paramV) || paramGraph.getEdgeTarget(paramE).equals(paramV));
  }
  
  public static <V, E> V getOppositeVertex(Graph<V, E> paramGraph, E paramE, V paramV) {
    V v1 = paramGraph.getEdgeSource(paramE);
    V v2 = paramGraph.getEdgeTarget(paramE);
    if (paramV.equals(v1))
      return v2; 
    if (paramV.equals(v2))
      return v1; 
    throw new IllegalArgumentException("no such vertex");
  }
  
  public static <V, E> List<V> getPathVertexList(GraphPath<V, E> paramGraphPath) {
    // Byte code:
    //   0: aload_0
    //   1: invokeinterface getGraph : ()Lorg/jgrapht/Graph;
    //   6: astore_1
    //   7: new java/util/ArrayList
    //   10: dup
    //   11: invokespecial <init> : ()V
    //   14: astore_2
    //   15: aload_0
    //   16: invokeinterface getStartVertex : ()Ljava/lang/Object;
    //   21: astore_3
    //   22: aload_2
    //   23: aload_3
    //   24: invokeinterface add : (Ljava/lang/Object;)Z
    //   29: pop
    //   30: aload_0
    //   31: invokeinterface getEdgeList : ()Ljava/util/List;
    //   36: invokeinterface iterator : ()Ljava/util/Iterator;
    //   41: astore #4
    //   43: aload #4
    //   45: invokeinterface hasNext : ()Z
    //   50: ifeq -> 81
    //   53: aload #4
    //   55: invokeinterface next : ()Ljava/lang/Object;
    //   60: astore #5
    //   62: aload_1
    //   63: aload #5
    //   65: aload_3
    //   66: invokestatic getOppositeVertex : (Lorg/jgrapht/Graph;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   69: astore_3
    //   70: aload_2
    //   71: aload_3
    //   72: invokeinterface add : (Ljava/lang/Object;)Z
    //   77: pop
    //   78: goto -> 43
    //   81: aload_2
    //   82: areturn
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/Graphs.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */