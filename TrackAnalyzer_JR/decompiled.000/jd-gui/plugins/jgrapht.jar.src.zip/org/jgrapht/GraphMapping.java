package org.jgrapht;

public interface GraphMapping<V, E> {
  V getVertexCorrespondence(V paramV, boolean paramBoolean);
  
  E getEdgeCorrespondence(E paramE, boolean paramBoolean);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/GraphMapping.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */