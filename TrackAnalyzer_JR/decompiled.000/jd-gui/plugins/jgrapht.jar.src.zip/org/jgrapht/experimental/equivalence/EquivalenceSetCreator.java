package org.jgrapht.experimental.equivalence;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;

public class EquivalenceSetCreator<E, C> {
  private static final EqGroupSizeComparator groupSizeComparator = new EqGroupSizeComparator();
  
  @Deprecated
  public static <EE, CC> EquivalenceSet[] createEqualityGroupOrderedArray(EE[] paramArrayOfEE, EquivalenceComparator<? super EE, ? super CC> paramEquivalenceComparator, CC paramCC) {
    return createEqualityGroupOrderedArray(Arrays.asList(paramArrayOfEE), paramEquivalenceComparator, paramCC);
  }
  
  public static <EE, CC> EquivalenceSet[] createEqualityGroupOrderedArray(Collection<EE> paramCollection, EquivalenceComparator<? super EE, ? super CC> paramEquivalenceComparator, CC paramCC) {
    ArrayList<EquivalenceSet> arrayList = new ArrayList();
    HashMap<Integer, List<EquivalenceSet<? super EE, ? super CC>>> hashMap = createEqualityGroupMap(paramCollection, paramEquivalenceComparator, paramCC);
    for (List<EquivalenceSet<? super EE, ? super CC>> list : hashMap.values()) {
      for (EquivalenceSet equivalenceSet : list)
        arrayList.add(equivalenceSet); 
    } 
    EquivalenceSet[] arrayOfEquivalenceSet = new EquivalenceSet[arrayList.size()];
    arrayList.toArray(arrayOfEquivalenceSet);
    Arrays.sort(arrayOfEquivalenceSet, groupSizeComparator);
    return arrayOfEquivalenceSet;
  }
  
  private static <EE, CC> HashMap<Integer, List<EquivalenceSet<? super EE, ? super CC>>> createEqualityGroupMap(Collection<EE> paramCollection, EquivalenceComparator<? super EE, ? super CC> paramEquivalenceComparator, CC paramCC) {
    // Byte code:
    //   0: new java/util/HashMap
    //   3: dup
    //   4: aload_0
    //   5: invokeinterface size : ()I
    //   10: invokespecial <init> : (I)V
    //   13: astore_3
    //   14: aload_0
    //   15: invokeinterface iterator : ()Ljava/util/Iterator;
    //   20: astore #4
    //   22: aload #4
    //   24: invokeinterface hasNext : ()Z
    //   29: ifeq -> 202
    //   32: aload #4
    //   34: invokeinterface next : ()Ljava/lang/Object;
    //   39: astore #5
    //   41: aload_1
    //   42: aload #5
    //   44: aload_2
    //   45: invokeinterface equivalenceHashcode : (Ljava/lang/Object;Ljava/lang/Object;)I
    //   50: istore #6
    //   52: aload_3
    //   53: iload #6
    //   55: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   58: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   61: checkcast java/util/List
    //   64: astore #7
    //   66: aload #7
    //   68: ifnonnull -> 114
    //   71: new java/util/LinkedList
    //   74: dup
    //   75: invokespecial <init> : ()V
    //   78: astore #7
    //   80: aload #7
    //   82: new org/jgrapht/experimental/equivalence/EquivalenceSet
    //   85: dup
    //   86: aload #5
    //   88: aload_1
    //   89: aload_2
    //   90: invokespecial <init> : (Ljava/lang/Object;Lorg/jgrapht/experimental/equivalence/EquivalenceComparator;Ljava/lang/Object;)V
    //   93: invokeinterface add : (Ljava/lang/Object;)Z
    //   98: pop
    //   99: aload_3
    //   100: iload #6
    //   102: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   105: aload #7
    //   107: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   110: pop
    //   111: goto -> 199
    //   114: iconst_0
    //   115: istore #8
    //   117: aload #7
    //   119: invokeinterface iterator : ()Ljava/util/Iterator;
    //   124: astore #9
    //   126: aload #9
    //   128: invokeinterface hasNext : ()Z
    //   133: ifeq -> 175
    //   136: aload #9
    //   138: invokeinterface next : ()Ljava/lang/Object;
    //   143: checkcast org/jgrapht/experimental/equivalence/EquivalenceSet
    //   146: astore #10
    //   148: aload #10
    //   150: aload #5
    //   152: aload_2
    //   153: invokevirtual equivalentTo : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   156: ifeq -> 172
    //   159: aload #10
    //   161: aload #5
    //   163: invokevirtual add : (Ljava/lang/Object;)V
    //   166: iconst_1
    //   167: istore #8
    //   169: goto -> 175
    //   172: goto -> 126
    //   175: iload #8
    //   177: ifne -> 199
    //   180: aload #7
    //   182: new org/jgrapht/experimental/equivalence/EquivalenceSet
    //   185: dup
    //   186: aload #5
    //   188: aload_1
    //   189: aload_2
    //   190: invokespecial <init> : (Ljava/lang/Object;Lorg/jgrapht/experimental/equivalence/EquivalenceComparator;Ljava/lang/Object;)V
    //   193: invokeinterface add : (Ljava/lang/Object;)Z
    //   198: pop
    //   199: goto -> 22
    //   202: aload_3
    //   203: areturn
  }
  
  private static class EqGroupSizeComparator implements Comparator<EquivalenceSet> {
    private EqGroupSizeComparator() {}
    
    public int compare(EquivalenceSet param1EquivalenceSet1, EquivalenceSet param1EquivalenceSet2) {
      int i = param1EquivalenceSet1.size();
      int j = param1EquivalenceSet2.size();
      if (i > j)
        return 1; 
      if (i < j)
        return -1; 
      int k = param1EquivalenceSet1.hashCode();
      int m = param1EquivalenceSet2.hashCode();
      return (k > m) ? 1 : ((k < m) ? -1 : 0);
    }
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/experimental/equivalence/EquivalenceSetCreator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */