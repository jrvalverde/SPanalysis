package org.jgrapht.experimental;

import java.util.Collection;
import java.util.List;
import java.util.Set;
import org.jgrapht.Graph;
import org.jgrapht.Graphs;
import org.jgrapht.ListenableGraph;
import org.jgrapht.event.GraphEdgeChangeEvent;
import org.jgrapht.event.GraphListener;
import org.jgrapht.event.GraphVertexChangeEvent;
import org.jgrapht.graph.AbstractBaseGraph;

public class GraphSquare<V, E> extends AbstractBaseGraph<V, E> {
  private static final long serialVersionUID = -2642034600395594304L;
  
  private static final String UNMODIFIABLE = "this graph is unmodifiable";
  
  public GraphSquare(final Graph<V, E> g, final boolean createLoops) {
    super(g.getEdgeFactory(), false, createLoops);
    Graphs.addAllVertices((Graph)this, g.vertexSet());
    addSquareEdges(g, createLoops);
    if (g instanceof ListenableGraph)
      ((ListenableGraph)g).addGraphListener(new GraphListener<V, E>() {
            public void edgeAdded(GraphEdgeChangeEvent<V, E> param1GraphEdgeChangeEvent) {
              Object object = param1GraphEdgeChangeEvent.getEdge();
              GraphSquare.this.addEdgesStartingAt(g, (V)g.getEdgeSource(object), (V)g.getEdgeTarget(object), createLoops);
              GraphSquare.this.addEdgesStartingAt(g, (V)g.getEdgeTarget(object), (V)g.getEdgeSource(object), createLoops);
            }
            
            public void edgeRemoved(GraphEdgeChangeEvent<V, E> param1GraphEdgeChangeEvent) {
              GraphSquare.this.removeAllEdges(GraphSquare.this.edgeSet());
              GraphSquare.this.addSquareEdges(g, createLoops);
            }
            
            public void vertexAdded(GraphVertexChangeEvent<V> param1GraphVertexChangeEvent) {}
            
            public void vertexRemoved(GraphVertexChangeEvent<V> param1GraphVertexChangeEvent) {}
          }); 
  }
  
  public E addEdge(V paramV1, V paramV2) {
    throw new UnsupportedOperationException("this graph is unmodifiable");
  }
  
  public boolean addEdge(V paramV1, V paramV2, E paramE) {
    throw new UnsupportedOperationException("this graph is unmodifiable");
  }
  
  public boolean addVertex(V paramV) {
    throw new UnsupportedOperationException("this graph is unmodifiable");
  }
  
  public boolean removeAllEdges(Collection<? extends E> paramCollection) {
    throw new UnsupportedOperationException("this graph is unmodifiable");
  }
  
  public Set<E> removeAllEdges(V paramV1, V paramV2) {
    throw new UnsupportedOperationException("this graph is unmodifiable");
  }
  
  public boolean removeAllVertices(Collection<? extends V> paramCollection) {
    throw new UnsupportedOperationException("this graph is unmodifiable");
  }
  
  public boolean removeEdge(E paramE) {
    throw new UnsupportedOperationException("this graph is unmodifiable");
  }
  
  public E removeEdge(V paramV1, V paramV2) {
    throw new UnsupportedOperationException("this graph is unmodifiable");
  }
  
  public boolean removeVertex(V paramV) {
    throw new UnsupportedOperationException("this graph is unmodifiable");
  }
  
  private void addEdgesStartingAt(Graph<V, E> paramGraph, V paramV1, V paramV2, boolean paramBoolean) {
    if (!paramGraph.containsEdge(paramV1, paramV2))
      return; 
    List<Object> list = Graphs.neighborListOf(paramGraph, paramV2);
    for (byte b = 0; b < list.size(); b++) {
      V v = (V)list.get(b);
      if (paramGraph.containsEdge(paramV2, v) && (paramV1 != v || paramBoolean))
        super.addEdge(paramV1, v); 
    } 
  }
  
  private void addSquareEdges(Graph<V, E> paramGraph, boolean paramBoolean) {
    for (V v : paramGraph.vertexSet()) {
      List<V> list = Graphs.neighborListOf(paramGraph, v);
      for (byte b = 0; b < list.size(); b++)
        addEdgesStartingAt(paramGraph, v, list.get(b), paramBoolean); 
    } 
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/experimental/GraphSquare.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */