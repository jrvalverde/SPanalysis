package org.jgrapht.experimental.equivalence;

public class UniformEquivalenceComparator<E, C> implements EquivalenceComparator<E, C> {
  public boolean equivalenceCompare(E paramE1, E paramE2, C paramC1, C paramC2) {
    return true;
  }
  
  public int equivalenceHashcode(E paramE, C paramC) {
    return 0;
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/experimental/equivalence/UniformEquivalenceComparator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */