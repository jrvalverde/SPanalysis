package org.jgrapht.experimental.isomorphism;

import java.util.Arrays;
import java.util.Set;
import org.jgrapht.Graph;
import org.jgrapht.experimental.equivalence.EquivalenceComparator;
import org.jgrapht.experimental.equivalence.EquivalenceSet;
import org.jgrapht.experimental.equivalence.EquivalenceSetCreator;
import org.jgrapht.experimental.permutation.ArrayPermutationsIter;
import org.jgrapht.experimental.permutation.CollectionPermutationIter;
import org.jgrapht.experimental.permutation.PermutationFactory;

class EquivalenceIsomorphismInspector<V, E> extends AbstractExhaustiveIsomorphismInspector<V, E> {
  public EquivalenceIsomorphismInspector(Graph<V, E> paramGraph1, Graph<V, E> paramGraph2, EquivalenceComparator<? super V, ? super Graph<? super V, ? super E>> paramEquivalenceComparator, EquivalenceComparator<? super E, ? super Graph<? super V, ? super E>> paramEquivalenceComparator1) {
    super(paramGraph1, paramGraph2, paramEquivalenceComparator, paramEquivalenceComparator1);
  }
  
  public EquivalenceIsomorphismInspector(Graph<V, E> paramGraph1, Graph<V, E> paramGraph2) {
    super(paramGraph1, paramGraph2);
  }
  
  protected CollectionPermutationIter<V> createPermutationIterator(Set<V> paramSet1, Set<V> paramSet2) {
    if (paramSet1.size() != paramSet2.size())
      return null; 
    EquivalenceSet[] arrayOfEquivalenceSet1 = EquivalenceSetCreator.createEqualityGroupOrderedArray(paramSet1, this.vertexComparator, this.graph1);
    EquivalenceSet[] arrayOfEquivalenceSet2 = EquivalenceSetCreator.createEqualityGroupOrderedArray(paramSet2, this.vertexComparator, this.graph2);
    boolean bool = reorderTargetArrayToMatchSourceOrder(arrayOfEquivalenceSet1, arrayOfEquivalenceSet2);
    if (!bool)
      return null; 
    Object[] arrayOfObject1 = new Object[paramSet1.size()];
    fillElementsflatArray(arrayOfEquivalenceSet1, arrayOfObject1);
    paramSet1.clear();
    paramSet1.addAll(Arrays.asList((V[])arrayOfObject1));
    Object[] arrayOfObject2 = new Object[paramSet2.size()];
    fillElementsflatArray(arrayOfEquivalenceSet2, arrayOfObject2);
    int[] arrayOfInt = new int[arrayOfEquivalenceSet1.length];
    for (byte b = 0; b < arrayOfEquivalenceSet2.length; b++)
      arrayOfInt[b] = arrayOfEquivalenceSet2[b].size(); 
    ArrayPermutationsIter arrayPermutationsIter = PermutationFactory.createByGroups(arrayOfInt);
    return new CollectionPermutationIter(Arrays.asList(arrayOfObject2), arrayPermutationsIter);
  }
  
  private boolean reorderTargetArrayToMatchSourceOrder(EquivalenceSet[] paramArrayOfEquivalenceSet1, EquivalenceSet[] paramArrayOfEquivalenceSet2) {
    boolean bool = true;
    for (byte b = 0; b < paramArrayOfEquivalenceSet1.length; b++) {
      byte b1 = b;
      EquivalenceSet equivalenceSet1 = paramArrayOfEquivalenceSet1[b];
      EquivalenceSet equivalenceSet2 = paramArrayOfEquivalenceSet2[b1];
      if (!equivalenceSet1.equals(equivalenceSet2)) {
        boolean bool1 = false;
        int i = equivalenceSet1.size();
        int j = equivalenceSet1.hashCode();
        while (equivalenceSet2.size() == i && equivalenceSet2.hashCode() == j && b1 < paramArrayOfEquivalenceSet2.length) {
          equivalenceSet2 = paramArrayOfEquivalenceSet2[++b1];
          if (equivalenceSet2.equals(equivalenceSet1)) {
            bool1 = true;
            paramArrayOfEquivalenceSet2[b1] = paramArrayOfEquivalenceSet2[b];
            paramArrayOfEquivalenceSet2[b] = equivalenceSet2;
          } 
        } 
        if (!bool1) {
          bool = false;
          break;
        } 
      } 
    } 
    return bool;
  }
  
  protected void fillElementsflatArray(EquivalenceSet[] paramArrayOfEquivalenceSet, Object[] paramArrayOfObject) {
    int i = 0;
    for (byte b = 0; b < paramArrayOfEquivalenceSet.length; b++) {
      Object[] arrayOfObject = paramArrayOfEquivalenceSet[b].toArray();
      System.arraycopy(arrayOfObject, 0, paramArrayOfObject, i, arrayOfObject.length);
      i += arrayOfObject.length;
    } 
  }
  
  protected boolean areVertexSetsOfTheSameEqualityGroup(Set paramSet1, Set paramSet2) {
    return true;
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/experimental/isomorphism/EquivalenceIsomorphismInspector.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */