package org.jgrapht.experimental.isomorphism;

import java.util.Iterator;

public interface GraphIsomorphismInspector<E> extends Iterator<E> {
  boolean isIsomorphic();
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/experimental/isomorphism/GraphIsomorphismInspector.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */