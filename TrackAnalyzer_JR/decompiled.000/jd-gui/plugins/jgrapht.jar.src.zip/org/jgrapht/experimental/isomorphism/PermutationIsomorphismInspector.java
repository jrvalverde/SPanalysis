package org.jgrapht.experimental.isomorphism;

import java.util.Set;
import org.jgrapht.Graph;
import org.jgrapht.experimental.equivalence.EquivalenceComparator;
import org.jgrapht.experimental.permutation.CollectionPermutationIter;

class PermutationIsomorphismInspector<V, E> extends AbstractExhaustiveIsomorphismInspector<V, E> {
  public PermutationIsomorphismInspector(Graph<V, E> paramGraph1, Graph<V, E> paramGraph2, EquivalenceComparator<? super V, ? super Graph<? super V, ? super E>> paramEquivalenceComparator, EquivalenceComparator<? super E, ? super Graph<? super V, ? super E>> paramEquivalenceComparator1) {
    super(paramGraph1, paramGraph2, paramEquivalenceComparator, paramEquivalenceComparator1);
  }
  
  public PermutationIsomorphismInspector(Graph<V, E> paramGraph1, Graph<V, E> paramGraph2) {
    super(paramGraph1, paramGraph2);
  }
  
  protected CollectionPermutationIter<V> createPermutationIterator(Set<V> paramSet1, Set<V> paramSet2) {
    return new CollectionPermutationIter(paramSet2);
  }
  
  protected boolean areVertexSetsOfTheSameEqualityGroup(Set<V> paramSet1, Set<V> paramSet2) {
    // Byte code:
    //   0: aload_1
    //   1: invokeinterface size : ()I
    //   6: aload_2
    //   7: invokeinterface size : ()I
    //   12: if_icmpeq -> 17
    //   15: iconst_0
    //   16: ireturn
    //   17: aload_2
    //   18: invokeinterface iterator : ()Ljava/util/Iterator;
    //   23: astore_3
    //   24: aload_1
    //   25: invokeinterface iterator : ()Ljava/util/Iterator;
    //   30: astore #4
    //   32: aload #4
    //   34: invokeinterface hasNext : ()Z
    //   39: ifeq -> 88
    //   42: aload #4
    //   44: invokeinterface next : ()Ljava/lang/Object;
    //   49: astore #5
    //   51: aload_3
    //   52: invokeinterface next : ()Ljava/lang/Object;
    //   57: astore #6
    //   59: aload_0
    //   60: getfield vertexComparator : Lorg/jgrapht/experimental/equivalence/EquivalenceComparator;
    //   63: aload #5
    //   65: aload #6
    //   67: aload_0
    //   68: getfield graph1 : Lorg/jgrapht/Graph;
    //   71: aload_0
    //   72: getfield graph2 : Lorg/jgrapht/Graph;
    //   75: invokeinterface equivalenceCompare : (Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Z
    //   80: ifne -> 85
    //   83: iconst_0
    //   84: ireturn
    //   85: goto -> 32
    //   88: iconst_1
    //   89: ireturn
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/experimental/isomorphism/PermutationIsomorphismInspector.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */