package org.jgrapht.experimental;

import java.util.Arrays;
import java.util.Map;
import org.jgrapht.Graph;
import org.jgrapht.VertexFactory;
import org.jgrapht.generate.GraphGenerator;

public class UniformRandomGraphGenerator implements GraphGenerator {
  private final int numEdges;
  
  private final int numVertices;
  
  public UniformRandomGraphGenerator(int paramInt1, int paramInt2) {
    if (paramInt1 < 0)
      throw new IllegalArgumentException("must be non-negative"); 
    if (paramInt2 < 0 || paramInt2 > paramInt1 * (paramInt1 - 1) / 2)
      throw new IllegalArgumentException("illegal number of edges"); 
    this.numVertices = paramInt1;
    this.numEdges = paramInt2;
  }
  
  public void generateGraph(Graph paramGraph, VertexFactory paramVertexFactory, Map paramMap) {
    Object[] arrayOfObject = RandomGraphHelper.addVertices(paramGraph, paramVertexFactory, this.numVertices);
    RandomGraphHelper.addEdges(paramGraph, Arrays.asList(arrayOfObject), Arrays.asList(arrayOfObject), this.numEdges);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/experimental/UniformRandomGraphGenerator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */