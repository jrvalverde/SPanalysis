package org.jgrapht.experimental.permutation;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class CollectionPermutationIter<E> {
  private ArrayPermutationsIter permOrder;
  
  private List<E> sourceArray;
  
  private int[] currPermutationArray;
  
  public CollectionPermutationIter(Set<E> paramSet) {
    this(new ArrayList<E>(paramSet), new IntegerPermutationIter(paramSet.size()));
  }
  
  public CollectionPermutationIter(List<E> paramList) {
    this(paramList, new IntegerPermutationIter(paramList.size()));
  }
  
  public CollectionPermutationIter(List<E> paramList, ArrayPermutationsIter paramArrayPermutationsIter) {
    this.permOrder = paramArrayPermutationsIter;
    this.sourceArray = paramList;
  }
  
  public boolean hasNext() {
    return this.permOrder.hasNextPermutaions();
  }
  
  public List<E> getNextArray() {
    List list;
    if (this.permOrder.hasNextPermutaions()) {
      this.currPermutationArray = this.permOrder.nextPermutation();
      list = applyPermutation();
    } else {
      list = null;
    } 
    return list;
  }
  
  private List<E> applyPermutation() {
    ArrayList<E> arrayList = new ArrayList<E>(this.sourceArray);
    for (byte b = 0; b < arrayList.size(); b++)
      arrayList.set(b, this.sourceArray.get(this.currPermutationArray[b])); 
    return arrayList;
  }
  
  public Set<E> getNextSet() {
    List<E> list = getNextArray();
    return (list == null) ? null : new LinkedHashSet<E>(list);
  }
  
  public int[] getCurrentPermutationArray() {
    return this.currPermutationArray;
  }
  
  public String toString() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("Permutation int[]=");
    stringBuffer.append(Arrays.toString(getCurrentPermutationArray()));
    List<E> list = applyPermutation();
    stringBuffer.append("\nPermutationSet Source Object[]=");
    stringBuffer.append(this.sourceArray.toString());
    stringBuffer.append("\nPermutationSet Result Object[]=");
    stringBuffer.append(list.toString());
    return stringBuffer.toString();
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/experimental/permutation/CollectionPermutationIter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */