package org.jgrapht.experimental.isomorphism;

import java.util.Map;
import java.util.Set;
import org.jgrapht.Graph;

public class GraphOrdering<V, E> {
  private Map<V, Integer> mapVertexToOrder;
  
  private Set<LabelsEdge> labelsEdgesSet;
  
  public GraphOrdering(Graph<V, E> paramGraph) {
    this(paramGraph, paramGraph.vertexSet(), paramGraph.edgeSet());
  }
  
  public GraphOrdering(Graph<V, E> paramGraph, Set<V> paramSet, Set<E> paramSet1) {
    init(paramGraph, paramSet, paramSet1);
  }
  
  private void init(Graph<V, E> paramGraph, Set<V> paramSet, Set<E> paramSet1) {
    // Byte code:
    //   0: aload_0
    //   1: new java/util/HashMap
    //   4: dup
    //   5: aload_2
    //   6: invokeinterface size : ()I
    //   11: invokespecial <init> : (I)V
    //   14: putfield mapVertexToOrder : Ljava/util/Map;
    //   17: iconst_0
    //   18: istore #4
    //   20: aload_2
    //   21: invokeinterface iterator : ()Ljava/util/Iterator;
    //   26: astore #5
    //   28: aload #5
    //   30: invokeinterface hasNext : ()Z
    //   35: ifeq -> 74
    //   38: aload #5
    //   40: invokeinterface next : ()Ljava/lang/Object;
    //   45: astore #6
    //   47: aload_0
    //   48: getfield mapVertexToOrder : Ljava/util/Map;
    //   51: aload #6
    //   53: new java/lang/Integer
    //   56: dup
    //   57: iload #4
    //   59: invokespecial <init> : (I)V
    //   62: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   67: pop
    //   68: iinc #4, 1
    //   71: goto -> 28
    //   74: aload_0
    //   75: new java/util/HashSet
    //   78: dup
    //   79: aload_3
    //   80: invokeinterface size : ()I
    //   85: invokespecial <init> : (I)V
    //   88: putfield labelsEdgesSet : Ljava/util/Set;
    //   91: aload_3
    //   92: invokeinterface iterator : ()Ljava/util/Iterator;
    //   97: astore #5
    //   99: aload #5
    //   101: invokeinterface hasNext : ()Z
    //   106: ifeq -> 238
    //   109: aload #5
    //   111: invokeinterface next : ()Ljava/lang/Object;
    //   116: astore #6
    //   118: aload_1
    //   119: aload #6
    //   121: invokeinterface getEdgeSource : (Ljava/lang/Object;)Ljava/lang/Object;
    //   126: astore #7
    //   128: aload_0
    //   129: getfield mapVertexToOrder : Ljava/util/Map;
    //   132: aload #7
    //   134: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   139: checkcast java/lang/Integer
    //   142: astore #8
    //   144: aload #8
    //   146: invokevirtual intValue : ()I
    //   149: istore #9
    //   151: aload_0
    //   152: getfield mapVertexToOrder : Ljava/util/Map;
    //   155: aload_1
    //   156: aload #6
    //   158: invokeinterface getEdgeTarget : (Ljava/lang/Object;)Ljava/lang/Object;
    //   163: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   168: checkcast java/lang/Integer
    //   171: invokevirtual intValue : ()I
    //   174: istore #10
    //   176: new org/jgrapht/experimental/isomorphism/GraphOrdering$LabelsEdge
    //   179: dup
    //   180: aload_0
    //   181: iload #9
    //   183: iload #10
    //   185: invokespecial <init> : (Lorg/jgrapht/experimental/isomorphism/GraphOrdering;II)V
    //   188: astore #11
    //   190: aload_0
    //   191: getfield labelsEdgesSet : Ljava/util/Set;
    //   194: aload #11
    //   196: invokeinterface add : (Ljava/lang/Object;)Z
    //   201: pop
    //   202: aload_1
    //   203: instanceof org/jgrapht/UndirectedGraph
    //   206: ifeq -> 235
    //   209: new org/jgrapht/experimental/isomorphism/GraphOrdering$LabelsEdge
    //   212: dup
    //   213: aload_0
    //   214: iload #10
    //   216: iload #9
    //   218: invokespecial <init> : (Lorg/jgrapht/experimental/isomorphism/GraphOrdering;II)V
    //   221: astore #12
    //   223: aload_0
    //   224: getfield labelsEdgesSet : Ljava/util/Set;
    //   227: aload #12
    //   229: invokeinterface add : (Ljava/lang/Object;)Z
    //   234: pop
    //   235: goto -> 99
    //   238: return
  }
  
  public boolean equalsByEdgeOrder(GraphOrdering paramGraphOrdering) {
    return getLabelsEdgesSet().equals(paramGraphOrdering.getLabelsEdgesSet());
  }
  
  public Set<LabelsEdge> getLabelsEdgesSet() {
    return this.labelsEdgesSet;
  }
  
  public String toString() {
    // Byte code:
    //   0: new java/lang/StringBuffer
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore_1
    //   8: aload_1
    //   9: ldc 'mapVertexToOrder='
    //   11: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   14: pop
    //   15: aload_0
    //   16: getfield mapVertexToOrder : Ljava/util/Map;
    //   19: invokeinterface size : ()I
    //   24: anewarray java/lang/Object
    //   27: astore_2
    //   28: aload_0
    //   29: getfield mapVertexToOrder : Ljava/util/Map;
    //   32: invokeinterface keySet : ()Ljava/util/Set;
    //   37: astore_3
    //   38: aload_3
    //   39: invokeinterface iterator : ()Ljava/util/Iterator;
    //   44: astore #4
    //   46: aload #4
    //   48: invokeinterface hasNext : ()Z
    //   53: ifeq -> 93
    //   56: aload #4
    //   58: invokeinterface next : ()Ljava/lang/Object;
    //   63: astore #5
    //   65: aload_0
    //   66: getfield mapVertexToOrder : Ljava/util/Map;
    //   69: aload #5
    //   71: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   76: checkcast java/lang/Integer
    //   79: astore #6
    //   81: aload_2
    //   82: aload #6
    //   84: invokevirtual intValue : ()I
    //   87: aload #5
    //   89: aastore
    //   90: goto -> 46
    //   93: aload_1
    //   94: aload_2
    //   95: invokestatic toString : ([Ljava/lang/Object;)Ljava/lang/String;
    //   98: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   101: pop
    //   102: aload_1
    //   103: ldc 'labelsOrder='
    //   105: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   108: aload_0
    //   109: getfield labelsEdgesSet : Ljava/util/Set;
    //   112: invokevirtual toString : ()Ljava/lang/String;
    //   115: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   118: pop
    //   119: aload_1
    //   120: invokevirtual toString : ()Ljava/lang/String;
    //   123: areturn
  }
  
  private class LabelsEdge {
    private int source;
    
    private int target;
    
    private int hashCode;
    
    public LabelsEdge(int param1Int1, int param1Int2) {
      this.source = param1Int1;
      this.target = param1Int2;
      this.hashCode = (new String(this.source + "" + this.target)).hashCode();
    }
    
    public boolean equals(Object param1Object) {
      LabelsEdge labelsEdge = (LabelsEdge)param1Object;
      return (this.source == labelsEdge.source && this.target == labelsEdge.target);
    }
    
    public int hashCode() {
      return this.hashCode;
    }
    
    public String toString() {
      return this.source + "->" + this.target;
    }
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/experimental/isomorphism/GraphOrdering.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */