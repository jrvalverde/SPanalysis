package org.jgrapht.experimental.permutation;

public class PermutationFactory {
  public static ArrayPermutationsIter createRegular(int[] paramArrayOfint) {
    return new IntegerPermutationIter(paramArrayOfint);
  }
  
  public static ArrayPermutationsIter createByGroups(int[] paramArrayOfint) {
    return new CompoundPermutationIter(paramArrayOfint);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/experimental/permutation/PermutationFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */