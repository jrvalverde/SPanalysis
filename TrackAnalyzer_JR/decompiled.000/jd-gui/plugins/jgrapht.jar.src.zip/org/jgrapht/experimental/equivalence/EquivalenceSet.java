package org.jgrapht.experimental.equivalence;

import java.util.HashSet;
import java.util.Set;

public class EquivalenceSet<E, C> {
  protected EquivalenceComparator<? super E, ? super C> eqComparator;
  
  protected C comparatorContext;
  
  protected Set<E> elementsSet;
  
  private EquivalenceSet() {}
  
  public EquivalenceSet(E paramE, EquivalenceComparator<? super E, ? super C> paramEquivalenceComparator, C paramC) {
    this.eqComparator = paramEquivalenceComparator;
    this.comparatorContext = paramC;
    this.elementsSet = new HashSet<E>();
    this.elementsSet.add(paramE);
  }
  
  public E getRepresentative() {
    return this.elementsSet.iterator().next();
  }
  
  public C getContext() {
    return this.comparatorContext;
  }
  
  public int size() {
    return this.elementsSet.size();
  }
  
  public void add(E paramE) {
    this.elementsSet.add(paramE);
  }
  
  public boolean equivalentTo(E paramE, C paramC) {
    return this.eqComparator.equivalenceCompare(getRepresentative(), paramE, this.comparatorContext, paramC);
  }
  
  public boolean equals(Object paramObject) {
    Object object1 = null;
    Object object2 = null;
    if (paramObject instanceof EquivalenceSet) {
      object1 = ((EquivalenceSet)paramObject).getRepresentative();
      object2 = ((EquivalenceSet)paramObject).getContext();
    } else {
      throw new ClassCastException("can check equal() only of EqualityGroup");
    } 
    return this.eqComparator.equivalenceCompare(getRepresentative(), (E)object1, this.comparatorContext, (C)object2);
  }
  
  public int hashCode() {
    return this.eqComparator.equivalenceHashcode(getRepresentative(), this.comparatorContext);
  }
  
  public String toString() {
    return "Eq.Group=" + this.elementsSet.toString();
  }
  
  public Object[] toArray() {
    return this.elementsSet.toArray();
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/experimental/equivalence/EquivalenceSet.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */