package org.jgrapht.experimental.alg;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.jgrapht.Graph;
import org.jgrapht.Graphs;

public abstract class IntArrayGraphAlgorithm<V, E> {
  protected final List<V> _vertices;
  
  protected final int[][] _neighbors;
  
  protected final Map<V, Integer> _vertexToPos;
  
  public IntArrayGraphAlgorithm(Graph<V, E> paramGraph) {
    int i = paramGraph.vertexSet().size();
    this._vertices = new ArrayList<V>(i);
    this._neighbors = new int[i][];
    this._vertexToPos = new HashMap<V, Integer>(i);
    byte b1 = 0;
    for (V v : paramGraph.vertexSet()) {
      this._vertices.add(v);
      this._neighbors[b1++] = new int[paramGraph.edgesOf(v).size()];
      this._vertexToPos.put(v, Integer.valueOf(b1));
    } 
    for (byte b2 = 0; b2 < i; b2++) {
      byte b = 0;
      V v = this._vertices.get(b2);
      for (Object object : paramGraph.edgesOf(v))
        this._neighbors[b2][b++] = ((Integer)this._vertexToPos.get(Graphs.getOppositeVertex(paramGraph, object, v))).intValue(); 
    } 
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/experimental/alg/IntArrayGraphAlgorithm.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */