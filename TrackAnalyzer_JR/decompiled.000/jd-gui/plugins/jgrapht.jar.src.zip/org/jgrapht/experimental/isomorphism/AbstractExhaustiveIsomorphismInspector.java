package org.jgrapht.experimental.isomorphism;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.NoSuchElementException;
import java.util.Set;
import org.jgrapht.Graph;
import org.jgrapht.experimental.equivalence.EquivalenceComparator;
import org.jgrapht.experimental.equivalence.UniformEquivalenceComparator;
import org.jgrapht.experimental.permutation.CollectionPermutationIter;
import org.jgrapht.util.PrefetchIterator;

abstract class AbstractExhaustiveIsomorphismInspector<V, E> implements GraphIsomorphismInspector<IsomorphismRelation> {
  public static EquivalenceComparator<Object, Object> edgeDefaultIsomorphismComparator = (EquivalenceComparator<Object, Object>)new UniformEquivalenceComparator();
  
  public static EquivalenceComparator<Object, Object> vertexDefaultIsomorphismComparator = (EquivalenceComparator<Object, Object>)new UniformEquivalenceComparator();
  
  protected EquivalenceComparator<? super E, ? super Graph<V, ? super E>> edgeComparator;
  
  protected EquivalenceComparator<? super V, ? super Graph<? super V, E>> vertexComparator;
  
  protected Graph<V, E> graph1;
  
  protected Graph<V, E> graph2;
  
  private PrefetchIterator<IsomorphismRelation> nextSupplier;
  
  private GraphOrdering lableGraph1;
  
  private LinkedHashSet<V> graph1VertexSet;
  
  private LinkedHashSet<E> graph2EdgeSet;
  
  private CollectionPermutationIter<V> vertexPermuteIter;
  
  private Set<V> currVertexPermutation;
  
  public AbstractExhaustiveIsomorphismInspector(Graph<V, E> paramGraph1, Graph<V, E> paramGraph2, EquivalenceComparator<? super V, ? super Graph<? super V, ? super E>> paramEquivalenceComparator, EquivalenceComparator<? super E, ? super Graph<? super V, ? super E>> paramEquivalenceComparator1) {
    this.graph1 = paramGraph1;
    this.graph2 = paramGraph2;
    if (paramEquivalenceComparator != null) {
      this.vertexComparator = (EquivalenceComparator)paramEquivalenceComparator;
    } else {
      this.vertexComparator = (EquivalenceComparator)vertexDefaultIsomorphismComparator;
    } 
    if (paramEquivalenceComparator1 != null)
      this.edgeComparator = (EquivalenceComparator)paramEquivalenceComparator1; 
    init();
  }
  
  public AbstractExhaustiveIsomorphismInspector(Graph<V, E> paramGraph1, Graph<V, E> paramGraph2) {
    this(paramGraph1, paramGraph2, (EquivalenceComparator)edgeDefaultIsomorphismComparator, (EquivalenceComparator)vertexDefaultIsomorphismComparator);
  }
  
  private void init() {
    this.nextSupplier = new PrefetchIterator(new NextFunctor());
    this.graph1VertexSet = new LinkedHashSet<V>(this.graph1.vertexSet());
    this.vertexPermuteIter = createPermutationIterator(this.graph1VertexSet, this.graph2.vertexSet());
    this.lableGraph1 = new GraphOrdering<V, E>(this.graph1, this.graph1VertexSet, this.graph1.edgeSet());
    this.graph2EdgeSet = new LinkedHashSet<E>(this.graph2.edgeSet());
  }
  
  protected abstract CollectionPermutationIter<V> createPermutationIterator(Set<V> paramSet1, Set<V> paramSet2);
  
  private IsomorphismRelation<V, E> findNextIsomorphicGraph() {
    boolean bool = false;
    IsomorphismRelation<V, E> isomorphismRelation = null;
    if (this.vertexPermuteIter != null)
      while (this.vertexPermuteIter.hasNext()) {
        this.currVertexPermutation = this.vertexPermuteIter.getNextSet();
        if (!areVertexSetsOfTheSameEqualityGroup(this.graph1VertexSet, this.currVertexPermutation))
          continue; 
        GraphOrdering<V, E> graphOrdering = new GraphOrdering<V, E>(this.graph2, this.currVertexPermutation, this.graph2EdgeSet);
        if (this.lableGraph1.equalsByEdgeOrder(graphOrdering)) {
          isomorphismRelation = new IsomorphismRelation<V, E>(new ArrayList<V>(this.graph1VertexSet), new ArrayList<V>(this.currVertexPermutation), this.graph1, this.graph2);
          boolean bool1 = areAllEdgesEquivalent(isomorphismRelation, (EquivalenceComparator)this.edgeComparator);
          if (bool1) {
            bool = true;
            break;
          } 
        } 
      }  
    return (bool == true) ? isomorphismRelation : null;
  }
  
  protected abstract boolean areVertexSetsOfTheSameEqualityGroup(Set<V> paramSet1, Set<V> paramSet2);
  
  protected boolean areAllEdgesEquivalent(IsomorphismRelation<V, E> paramIsomorphismRelation, EquivalenceComparator<? super E, ? super Graph<V, E>> paramEquivalenceComparator) {
    boolean bool = true;
    if (paramEquivalenceComparator == null)
      return true; 
    try {
      Set set = this.graph1.edgeSet();
      for (E e1 : set) {
        E e2 = paramIsomorphismRelation.getEdgeCorrespondence(e1, true);
        if (!paramEquivalenceComparator.equivalenceCompare(e1, e2, this.graph1, this.graph2)) {
          bool = false;
          break;
        } 
      } 
    } catch (IllegalArgumentException illegalArgumentException) {
      bool = false;
    } 
    return bool;
  }
  
  public IsomorphismRelation nextIsoRelation() {
    return next();
  }
  
  public boolean isIsomorphic() {
    return !this.nextSupplier.isEnumerationStartedEmpty();
  }
  
  public boolean hasNext() {
    return this.nextSupplier.hasMoreElements();
  }
  
  public IsomorphismRelation next() {
    return (IsomorphismRelation)this.nextSupplier.nextElement();
  }
  
  public void remove() {
    throw new UnsupportedOperationException("remove() method is not supported in AdaptiveIsomorphismInspectorFactory. There is no meaning to removing an isomorphism result.");
  }
  
  private class NextFunctor implements PrefetchIterator.NextElementFunctor<IsomorphismRelation> {
    private NextFunctor() {}
    
    public IsomorphismRelation nextElement() throws NoSuchElementException {
      IsomorphismRelation isomorphismRelation = AbstractExhaustiveIsomorphismInspector.this.findNextIsomorphicGraph();
      if (isomorphismRelation != null)
        return isomorphismRelation; 
      throw new NoSuchElementException("IsomorphismInspector does not have any more elements");
    }
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/experimental/isomorphism/AbstractExhaustiveIsomorphismInspector.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */