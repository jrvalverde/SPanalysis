package org.jgrapht.experimental.isomorphism;

import java.util.HashMap;
import java.util.List;
import org.jgrapht.Graph;
import org.jgrapht.GraphMapping;
import org.jgrapht.graph.DefaultGraphMapping;

public class IsomorphismRelation<V, E> implements GraphMapping<V, E> {
  private List<V> vertexList1;
  
  private List<V> vertexList2;
  
  private GraphMapping<V, E> graphMapping = null;
  
  private Graph<V, E> graph1;
  
  private Graph<V, E> graph2;
  
  public IsomorphismRelation(List<V> paramList1, List<V> paramList2, Graph<V, E> paramGraph1, Graph<V, E> paramGraph2) {
    this.vertexList1 = paramList1;
    this.vertexList2 = paramList2;
    this.graph1 = paramGraph1;
    this.graph2 = paramGraph2;
  }
  
  public String toString() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("vertexList1: ").append(this.vertexList1.toString());
    stringBuffer.append("\tvertexList2: ").append(this.vertexList2.toString());
    return stringBuffer.toString();
  }
  
  public V getVertexCorrespondence(V paramV, boolean paramBoolean) {
    if (this.graphMapping == null)
      initGraphMapping(); 
    return (V)this.graphMapping.getVertexCorrespondence(paramV, paramBoolean);
  }
  
  public E getEdgeCorrespondence(E paramE, boolean paramBoolean) {
    if (this.graphMapping == null)
      initGraphMapping(); 
    return (E)this.graphMapping.getEdgeCorrespondence(paramE, paramBoolean);
  }
  
  private void initGraphMapping() {
    int i = this.vertexList1.size();
    HashMap<Object, Object> hashMap1 = new HashMap<Object, Object>(i);
    HashMap<Object, Object> hashMap2 = new HashMap<Object, Object>(i);
    for (byte b = 0; b < i; b++) {
      V v1 = this.vertexList1.get(b);
      V v2 = this.vertexList2.get(b);
      hashMap1.put(v1, v2);
      hashMap2.put(v2, v1);
    } 
    this.graphMapping = (GraphMapping<V, E>)new DefaultGraphMapping(hashMap1, hashMap2, this.graph1, this.graph2);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/experimental/isomorphism/IsomorphismRelation.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */