package org.jgrapht.experimental;

import java.util.HashSet;
import java.util.LinkedList;
import org.jgrapht.Graph;
import org.jgrapht.Graphs;

public final class GraphTests<V, E> {
  public static <V, E> boolean isEmpty(Graph<V, E> paramGraph) {
    return paramGraph.edgeSet().isEmpty();
  }
  
  public static <V, E> boolean isComplete(Graph<V, E> paramGraph) {
    int i = paramGraph.vertexSet().size();
    return (paramGraph.edgeSet().size() == i * (i - 1) / 2);
  }
  
  public static <V, E> boolean isConnected(Graph<V, E> paramGraph) {
    int i = paramGraph.vertexSet().size();
    int j = paramGraph.edgeSet().size();
    if (j < i - 1)
      return false; 
    if (i < 2 || j > (i - 1) * (i - 2) / 2)
      return true; 
    HashSet hashSet = new HashSet();
    LinkedList<Object> linkedList = new LinkedList();
    object = paramGraph.vertexSet().iterator().next();
    linkedList.add(object);
    hashSet.add(object);
    while (!linkedList.isEmpty()) {
      object = linkedList.removeFirst();
      for (Object object : Graphs.neighborListOf(paramGraph, object)) {
        if (!hashSet.contains(object)) {
          hashSet.add(object);
          linkedList.add(object);
        } 
      } 
    } 
    return (hashSet.size() == i);
  }
  
  public static <V, E> boolean isTree(Graph<V, E> paramGraph) {
    return (isConnected(paramGraph) && paramGraph.edgeSet().size() == paramGraph.vertexSet().size() - 1);
  }
  
  public static <V, E> boolean isBipartite(Graph<V, E> paramGraph) {
    if (4 * paramGraph.edgeSet().size() > paramGraph.vertexSet().size() * paramGraph.vertexSet().size())
      return false; 
    if (isEmpty(paramGraph))
      return true; 
    HashSet<Object> hashSet = new HashSet(paramGraph.vertexSet());
    LinkedList<Object> linkedList = new LinkedList();
    Object object = hashSet.iterator().next();
    HashSet hashSet1 = new HashSet();
    linkedList.add(object);
    while (!hashSet.isEmpty()) {
      if (linkedList.isEmpty())
        linkedList.add(hashSet.iterator().next()); 
      object = linkedList.removeFirst();
      hashSet.remove(object);
      for (Object object1 : Graphs.neighborListOf(paramGraph, object)) {
        if (hashSet.contains(object1)) {
          linkedList.add(object1);
          if (!hashSet1.contains(object))
            hashSet1.add(object1); 
          continue;
        } 
        if ((hashSet1.contains(object) ^ hashSet1.contains(object1)) == 0)
          return false; 
      } 
    } 
    return true;
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/experimental/GraphTests.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */