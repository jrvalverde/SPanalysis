package org.jgrapht.experimental.permutation;

import java.util.Arrays;
import java.util.Iterator;
import org.jgrapht.util.MathUtil;

public class CompoundPermutationIter implements ArrayPermutationsIter, Iterator {
  IntegerPermutationIter[] permArray;
  
  private int totalPermArraySize;
  
  private int max;
  
  private int iterCounter = 0;
  
  public CompoundPermutationIter(int[] paramArrayOfint) {
    init(paramArrayOfint);
  }
  
  private void init(int[] paramArrayOfint) {
    this.permArray = new IntegerPermutationIter[paramArrayOfint.length];
    byte b1 = 0;
    this.max = 1;
    for (byte b2 = 0; b2 < paramArrayOfint.length; b2++) {
      int i = paramArrayOfint[b2];
      int[] arrayOfInt = new int[i];
      for (byte b = 0; b < i; b++) {
        arrayOfInt[b] = b1;
        b1++;
      } 
      this.permArray[b2] = new IntegerPermutationIter(arrayOfInt);
      this.permArray[b2].getNext();
      this.max = (int)(this.max * MathUtil.factorial(i));
    } 
    this.totalPermArraySize = b1;
  }
  
  public Object next() {
    return getNext();
  }
  
  public int[] getNext() {
    if (this.iterCounter == 0) {
      this.iterCounter++;
      return getPermAsArray();
    } 
    byte b = -1;
    byte b1 = 0;
    while (b == -1) {
      IntegerPermutationIter integerPermutationIter = this.permArray[b1];
      if (integerPermutationIter.hasNext()) {
        integerPermutationIter.getNext();
        for (byte b2 = 0; b2 < b1; b2++)
          restartPermutationGroup(b2); 
        b = b1;
      } 
      if (++b1 >= this.permArray.length)
        break; 
    } 
    this.iterCounter++;
    return (b == -1) ? null : getPermAsArray();
  }
  
  public int[] getPermAsArray() {
    int[] arrayOfInt = new int[this.totalPermArraySize];
    int i = 0;
    for (byte b = 0; b < this.permArray.length; b++) {
      int[] arrayOfInt1 = this.permArray[b].getCurrent();
      System.arraycopy(arrayOfInt1, 0, arrayOfInt, i, arrayOfInt1.length);
      i += arrayOfInt1.length;
    } 
    return arrayOfInt;
  }
  
  private void restartPermutationGroup(int paramInt) {
    int[] arrayOfInt = this.permArray[paramInt].getCurrent();
    Arrays.sort(arrayOfInt);
    this.permArray[paramInt] = new IntegerPermutationIter(arrayOfInt);
    this.permArray[paramInt].getNext();
  }
  
  public boolean hasNext() {
    boolean bool;
    if (this.iterCounter < this.max) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public int getMax() {
    return this.max;
  }
  
  public int[] nextPermutation() {
    return (int[])next();
  }
  
  public boolean hasNextPermutaions() {
    return hasNext();
  }
  
  public void remove() {
    throw new UnsupportedOperationException();
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/experimental/permutation/CompoundPermutationIter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */