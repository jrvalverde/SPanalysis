package org.jgrapht.experimental;

import java.util.Arrays;
import java.util.Map;
import org.jgrapht.Graph;
import org.jgrapht.VertexFactory;
import org.jgrapht.generate.GraphGenerator;

public class PartiteRandomGraphGenerator<V, E> implements GraphGenerator<V, E, Object[]> {
  private final int[] numVertices;
  
  private final int numEdges;
  
  public PartiteRandomGraphGenerator(int paramInt1, int paramInt2, int paramInt3) {
    if (paramInt1 < 0 || paramInt2 < 0)
      throw new IllegalArgumentException("must be non-negative"); 
    if (paramInt3 < 0 || paramInt3 > paramInt1 * paramInt2)
      throw new IllegalArgumentException("illegal number of edges"); 
    int[] arrayOfInt = { paramInt1, paramInt2 };
    this.numVertices = arrayOfInt;
    this.numEdges = paramInt3;
  }
  
  public PartiteRandomGraphGenerator(int[] paramArrayOfint, int paramInt) {
    if (paramInt < 0)
      throw new IllegalArgumentException("illegal number of edges"); 
    for (byte b = 0; b < paramArrayOfint.length; b++) {
      if (paramArrayOfint[b] < 0)
        throw new IllegalArgumentException("must be non-negative"); 
      for (byte b1 = 0; b1 < b; b1++) {
        if (paramInt > paramArrayOfint[b] * paramArrayOfint[b1])
          throw new IllegalArgumentException("illegal number of edges"); 
      } 
    } 
    this.numVertices = paramArrayOfint;
    this.numEdges = paramInt;
  }
  
  public void generateGraph(Graph<V, E> paramGraph, VertexFactory<V> paramVertexFactory, Map<String, Object[]> paramMap) {
    Object[][] arrayOfObject = new Object[this.numVertices.length][];
    for (byte b = 0; b < this.numVertices.length; b++) {
      arrayOfObject[b] = RandomGraphHelper.addVertices(paramGraph, paramVertexFactory, this.numVertices[b]);
      if (paramMap != null)
        paramMap.put(Integer.toString(b), arrayOfObject[b]); 
      for (byte b1 = 0; b1 < b; b1++)
        RandomGraphHelper.addEdges(paramGraph, Arrays.asList(arrayOfObject[b]), Arrays.asList(arrayOfObject[b1]), this.numEdges); 
    } 
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/experimental/PartiteRandomGraphGenerator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */