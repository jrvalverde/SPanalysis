package org.jgrapht.experimental.permutation;

import java.util.Arrays;
import java.util.Iterator;

public class IntegerPermutationIter implements Iterator, ArrayPermutationsIter {
  private int[] Value;
  
  private int N;
  
  private long permutationCounter;
  
  private boolean endWasReached = false;
  
  private boolean wasNextValueCalculatedAlready = false;
  
  private int[] currentValueBackup;
  
  public IntegerPermutationIter(int paramInt) {
    int[] arrayOfInt = new int[paramInt];
    for (byte b = 0; b < arrayOfInt.length; b++)
      arrayOfInt[b] = b; 
    init(arrayOfInt);
  }
  
  public IntegerPermutationIter(int[] paramArrayOfint) {
    int[] arrayOfInt = new int[paramArrayOfint.length];
    System.arraycopy(paramArrayOfint, 0, arrayOfInt, 0, paramArrayOfint.length);
    Arrays.sort(arrayOfInt);
    init(arrayOfInt);
  }
  
  private void init(int[] paramArrayOfint) {
    this.N = paramArrayOfint.length;
    this.Value = paramArrayOfint;
    this.currentValueBackup = this.Value;
    this.permutationCounter = 0L;
  }
  
  private void swap(int paramInt1, int paramInt2) {
    int i = this.Value[paramInt1];
    this.Value[paramInt1] = this.Value[paramInt2];
    this.Value[paramInt2] = i;
  }
  
  private int[] arrayClone(int[] paramArrayOfint) {
    int[] arrayOfInt = new int[paramArrayOfint.length];
    System.arraycopy(paramArrayOfint, 0, arrayOfInt, 0, paramArrayOfint.length);
    return arrayOfInt;
  }
  
  private int[] getNextStartingWith2() {
    this.permutationCounter++;
    int i = this.N - 1;
    if (i <= 0) {
      this.endWasReached = true;
      return null;
    } 
    while (this.Value[i - 1] >= this.Value[i]) {
      if (--i == 0) {
        this.endWasReached = true;
        return null;
      } 
    } 
    int j;
    for (j = this.N; this.Value[j - 1] <= this.Value[i - 1]; j--);
    swap(i - 1, j - 1);
    i++;
    for (j = this.N; i < j; j--) {
      swap(i - 1, j - 1);
      i++;
    } 
    return this.Value;
  }
  
  public boolean hasNext() {
    if (this.permutationCounter == 0L || this.wasNextValueCalculatedAlready)
      return true; 
    if (this.endWasReached)
      return false; 
    boolean bool = true;
    getNextStartingWith2();
    this.wasNextValueCalculatedAlready = true;
    return this.endWasReached ? false : bool;
  }
  
  public Object next() {
    return getNext();
  }
  
  public int[] getNext() {
    int[] arrayOfInt;
    if (!hasNext())
      throw new RuntimeException("IntegerPermutationIter exceeds the total number of permutaions. Suggestion: do a check with hasNext() , or count till getTotalNumberOfPermutations before using getNext()"); 
    if (this.permutationCounter == 0L) {
      this.permutationCounter++;
      arrayOfInt = this.Value;
    } else if (this.wasNextValueCalculatedAlready) {
      arrayOfInt = this.Value;
      this.wasNextValueCalculatedAlready = false;
    } else {
      arrayOfInt = getNextStartingWith2();
      if (this.endWasReached)
        return null; 
    } 
    this.currentValueBackup = arrayClone(arrayOfInt);
    return arrayClone(arrayOfInt);
  }
  
  public int[] getCurrent() {
    return arrayClone(this.currentValueBackup);
  }
  
  public String toString(int[] paramArrayOfint) {
    if (paramArrayOfint.length <= 0)
      return "[]"; 
    StringBuffer stringBuffer = new StringBuffer("[");
    for (byte b = 0; b < paramArrayOfint.length - 1; b++)
      stringBuffer.append(paramArrayOfint[b]).append(","); 
    stringBuffer.append(paramArrayOfint[paramArrayOfint.length - 1]).append("]");
    return stringBuffer.toString();
  }
  
  public void remove() {
    throw new UnsupportedOperationException();
  }
  
  public int[] nextPermutation() {
    return (int[])next();
  }
  
  public boolean hasNextPermutaions() {
    return hasNext();
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/experimental/permutation/IntegerPermutationIter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */