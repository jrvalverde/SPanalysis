package org.jgrapht.experimental.equivalence;

import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;

public class EquivalenceComparatorChainBase<E, C> implements EquivalenceComparatorChain<E, C> {
  private List<EquivalenceComparator<? super E, ? super C>> chain = new LinkedList<EquivalenceComparator<? super E, ? super C>>();
  
  public EquivalenceComparatorChainBase(EquivalenceComparator<E, C> paramEquivalenceComparator) {
    this.chain.add(paramEquivalenceComparator);
  }
  
  public void appendComparator(EquivalenceComparator<? super E, ? super C> paramEquivalenceComparator) {
    if (paramEquivalenceComparator != null)
      this.chain.add(paramEquivalenceComparator); 
  }
  
  public boolean equivalenceCompare(E paramE1, E paramE2, C paramC1, C paramC2) {
    for (EquivalenceComparator<E, C> equivalenceComparator : this.chain) {
      if (!equivalenceComparator.equivalenceCompare(paramE1, paramE2, paramC1, paramC2))
        return false; 
    } 
    return true;
  }
  
  public int equivalenceHashcode(E paramE, C paramC) {
    StringBuffer stringBuffer = new StringBuffer();
    ListIterator<EquivalenceComparator<? super E, ? super C>> listIterator = this.chain.listIterator();
    while (listIterator.hasNext()) {
      EquivalenceComparator<E, C> equivalenceComparator = (EquivalenceComparator)listIterator.next();
      int i = equivalenceComparator.equivalenceHashcode(paramE, paramC);
      stringBuffer.append(i);
      if (listIterator.hasNext())
        stringBuffer.append('+'); 
    } 
    return stringBuffer.toString().hashCode();
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/experimental/equivalence/EquivalenceComparatorChainBase.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */