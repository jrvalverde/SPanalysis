package org.jgrapht.experimental.alg.color;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.BitSet;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import org.jgrapht.Graph;
import org.jgrapht.experimental.alg.ApproximationAlgorithm;
import org.jgrapht.experimental.alg.IntArrayGraphAlgorithm;

public class GreedyColoring<V, E> extends IntArrayGraphAlgorithm<V, E> implements ApproximationAlgorithm<Integer, V> {
  public static final int BEST_ORDER = 0;
  
  public static final int NATURAL_ORDER = 1;
  
  public static final int SMALLEST_DEGREE_LAST_ORDER = 2;
  
  public static final int LARGEST_SATURATION_FIRST_ORDER = 3;
  
  private int _order = 0;
  
  public GreedyColoring(Graph<V, E> paramGraph) {
    this(paramGraph, 0);
  }
  
  public GreedyColoring(Graph<V, E> paramGraph, int paramInt) {
    super(paramGraph);
    this._order = paramInt;
  }
  
  int color(int[] paramArrayOfint) {
    int[] arrayOfInt = new int[this._neighbors.length];
    int i = 1;
    BitSet bitSet = new BitSet(this._neighbors.length);
    for (byte b = 0; b < this._neighbors.length; b++) {
      boolean bool = (paramArrayOfint == null) ? b : paramArrayOfint[b];
      bitSet.clear();
      for (byte b1 = 0; b1 < (this._neighbors[bool]).length; b1++) {
        int j = this._neighbors[bool][b1];
        if (arrayOfInt[j] > 0)
          bitSet.set(arrayOfInt[j]); 
      } 
      arrayOfInt[bool] = 1;
      while (bitSet.get(arrayOfInt[bool]))
        arrayOfInt[bool] = arrayOfInt[bool] + 1; 
      if (arrayOfInt[bool] > i)
        i = arrayOfInt[bool]; 
    } 
    return i;
  }
  
  int[] smallestDegreeLastOrder() {
    int[] arrayOfInt1 = new int[this._neighbors.length];
    int[] arrayOfInt2 = new int[this._neighbors.length];
    List[] arrayOfList = new List[this._neighbors.length];
    int i = this._neighbors.length - 1;
    int j;
    for (j = 0; j < this._neighbors.length; j++) {
      arrayOfList[j] = new ArrayList();
      arrayOfInt2[j] = (this._neighbors[j]).length;
    } 
    for (j = 0; j < this._neighbors.length; j++)
      arrayOfList[arrayOfInt2[j]].add(Integer.valueOf(j)); 
    for (j = 0; j < this._neighbors.length; j++) {
      while (arrayOfList[j].size() > 0) {
        int k = arrayOfList[j].size() - 1;
        int m = ((Integer)arrayOfList[j].get(k)).intValue();
        arrayOfList[j].remove(k);
        arrayOfInt2[m] = -1;
        arrayOfInt1[i--] = m;
        for (byte b = 0; b < (this._neighbors[m]).length; b++) {
          int n = this._neighbors[m][b];
          if (arrayOfInt2[n] >= 0) {
            arrayOfList[arrayOfInt2[n]].remove(new Integer(n));
            arrayOfInt2[n] = arrayOfInt2[n] - 1;
            arrayOfList[arrayOfInt2[n]].add(Integer.valueOf(n));
            if (arrayOfInt2[n] < j)
              j = arrayOfInt2[n]; 
          } 
        } 
      } 
    } 
    return arrayOfInt1;
  }
  
  int[] largestSaturationFirstOrder() {
    int[] arrayOfInt1 = new int[this._neighbors.length];
    int[] arrayOfInt2 = new int[this._neighbors.length];
    int[] arrayOfInt3 = new int[this._neighbors.length];
    int[] arrayOfInt4 = new int[this._neighbors.length];
    int[] arrayOfInt5 = new int[this._neighbors.length];
    byte b = 0;
    int i = 0;
    int j;
    for (j = 0; j < this._neighbors.length; j++) {
      arrayOfInt3[j] = j;
      arrayOfInt5[j] = j;
    } 
    arrayOfInt4[0] = this._neighbors.length;
    while (b < this._neighbors.length) {
      while (i && arrayOfInt4[i] == arrayOfInt4[i - 1])
        arrayOfInt4[i--] = 0; 
      j = arrayOfInt3[arrayOfInt4[i] - 1];
      arrayOfInt4[i] = arrayOfInt4[i] - 1;
      arrayOfInt2[j] = -1;
      arrayOfInt1[b++] = j;
      for (byte b1 = 0; b1 < (this._neighbors[j]).length; b1++) {
        int k = this._neighbors[j][b1];
        int m = arrayOfInt5[k];
        if (arrayOfInt2[k] >= 0) {
          if (m != arrayOfInt4[arrayOfInt2[k]] - 1) {
            arrayOfInt3[m] = arrayOfInt3[arrayOfInt4[arrayOfInt2[k]] - 1];
            arrayOfInt3[arrayOfInt4[arrayOfInt2[k]] - 1] = k;
            arrayOfInt5[k] = arrayOfInt4[arrayOfInt2[k]] - 1;
            arrayOfInt5[arrayOfInt3[m]] = m;
          } 
          arrayOfInt4[arrayOfInt2[k]] = arrayOfInt4[arrayOfInt2[k]] - 1;
          arrayOfInt2[k] = arrayOfInt2[k] + 1;
          if (arrayOfInt4[arrayOfInt2[k]] == 0)
            arrayOfInt4[arrayOfInt2[k]] = arrayOfInt4[arrayOfInt2[k] - 1] + 1; 
          if (arrayOfInt2[k] > i)
            i = arrayOfInt2[k]; 
        } 
      } 
    } 
    Collections.reverse(Arrays.asList((Object[])new int[][] { arrayOfInt3 }));
    return arrayOfInt3;
  }
  
  public Integer getLowerBound(Map<V, Object> paramMap) {
    return Integer.valueOf(0);
  }
  
  public Integer getUpperBound(Map<V, Object> paramMap) {
    switch (this._order) {
      case 0:
        return Integer.valueOf(Math.min(Math.min(color(null), color(smallestDegreeLastOrder())), color(largestSaturationFirstOrder())));
      case 1:
        return Integer.valueOf(color(null));
      case 2:
        return Integer.valueOf(color(smallestDegreeLastOrder()));
      case 3:
        return Integer.valueOf(color(largestSaturationFirstOrder()));
    } 
    return Integer.valueOf(this._neighbors.length);
  }
  
  public boolean isExact() {
    return false;
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/experimental/alg/color/GreedyColoring.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */