package org.jgrapht.experimental.touchgraph;

import com.touchgraph.graphlayout.GLPanel;
import com.touchgraph.graphlayout.Node;
import com.touchgraph.graphlayout.TGException;
import com.touchgraph.graphlayout.TGLensSet;
import com.touchgraph.graphlayout.TGPanel;
import com.touchgraph.graphlayout.interaction.HVScroll;
import com.touchgraph.graphlayout.interaction.HyperScroll;
import com.touchgraph.graphlayout.interaction.LocalityScroll;
import com.touchgraph.graphlayout.interaction.RotateScroll;
import com.touchgraph.graphlayout.interaction.ZoomScroll;
import java.awt.Color;
import java.util.Hashtable;
import org.jgrapht.Graph;

public class TouchgraphPanel<V, E> extends GLPanel {
  private static final long serialVersionUID = -7441058429719746032L;
  
  private Color defaultBackColor = new Color(1, 17, 68);
  
  private Color defaultBorderBackColor = new Color(2, 53, 129);
  
  private Color defaultForeColor = new Color(0.95F, 0.85F, 0.55F);
  
  Graph<V, E> graph;
  
  boolean selfReferencesAllowed = true;
  
  public TouchgraphPanel(Graph<V, E> paramGraph, boolean paramBoolean) {
    this.graph = paramGraph;
    this.selfReferencesAllowed = paramBoolean;
    preinitialize();
    initialize();
  }
  
  public void preinitialize() {
    setBackground(this.defaultBorderBackColor);
    setForeground(this.defaultForeColor);
    this.scrollBarHash = new Hashtable<Object, Object>();
    this.tgLensSet = new TGLensSet();
    this.tgPanel = new TGPanel();
    this.tgPanel.setBackColor(this.defaultBackColor);
    this.hvScroll = new HVScroll(this.tgPanel, this.tgLensSet);
    this.zoomScroll = new ZoomScroll(this.tgPanel);
    this.hyperScroll = new HyperScroll(this.tgPanel);
    this.rotateScroll = new RotateScroll(this.tgPanel);
    this.localityScroll = new LocalityScroll(this.tgPanel);
  }
  
  public void initialize() {
    buildPanel();
    buildLens();
    this.tgPanel.setLensSet(this.tgLensSet);
    addUIs();
    try {
      if (this.graph == null) {
        randomGraph();
      } else {
        TouchgraphConverter<Object, Object> touchgraphConverter = new TouchgraphConverter<Object, Object>();
        Node node = touchgraphConverter.convertToTouchGraph((Graph)this.graph, this.tgPanel, this.selfReferencesAllowed);
        getHVScroll().slowScrollToCenter(node);
        this.tgPanel.setLocale(node, 2147483647);
      } 
    } catch (TGException tGException) {
      System.err.println(tGException.getMessage());
      tGException.printStackTrace(System.err);
    } 
    setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/experimental/touchgraph/TouchgraphPanel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */