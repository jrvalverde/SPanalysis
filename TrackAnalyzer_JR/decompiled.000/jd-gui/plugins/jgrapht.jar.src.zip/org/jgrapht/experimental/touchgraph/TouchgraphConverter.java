package org.jgrapht.experimental.touchgraph;

import com.touchgraph.graphlayout.Edge;
import com.touchgraph.graphlayout.Node;
import com.touchgraph.graphlayout.TGException;
import com.touchgraph.graphlayout.TGPanel;
import java.util.ArrayList;
import org.jgrapht.Graph;

public class TouchgraphConverter<V, E> {
  public Node convertToTouchGraph(Graph<V, E> paramGraph, TGPanel paramTGPanel, boolean paramBoolean) throws TGException {
    ArrayList<Node> arrayList = new ArrayList(paramGraph.vertexSet());
    Node[] arrayOfNode = new Node[arrayList.size()];
    byte b;
    for (b = 0; b < arrayList.size(); b++) {
      Node node;
      if (arrayList.get(b) instanceof Node) {
        node = arrayList.get(b);
      } else {
        node = new Node(arrayList.get(b).toString());
      } 
      arrayOfNode[b] = node;
      paramTGPanel.addNode(node);
    } 
    for (b = 0; b < arrayOfNode.length; b++) {
      for (byte b1 = 0; b1 < arrayOfNode.length; b1++) {
        if ((b != b1 || paramBoolean) && paramGraph.getEdge(arrayList.get(b), arrayList.get(b1)) != null)
          paramTGPanel.addEdge(new Edge(arrayOfNode[b], arrayOfNode[b1])); 
      } 
    } 
    return arrayOfNode[0];
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/experimental/touchgraph/TouchgraphConverter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */