package org.jgrapht.experimental.equivalence;

public interface EquivalenceComparatorChain<E, C> extends EquivalenceComparator<E, C> {
  void appendComparator(EquivalenceComparator paramEquivalenceComparator);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/experimental/equivalence/EquivalenceComparatorChain.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */