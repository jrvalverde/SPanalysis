package org.jgrapht.experimental;

import java.util.List;
import java.util.Random;
import org.jgrapht.Graph;
import org.jgrapht.VertexFactory;

public final class RandomGraphHelper {
  private static final Random randSingleton = new Random();
  
  public static void addEdges(Graph paramGraph, List paramList1, List paramList2, int paramInt) {
    int i = paramList1.size();
    int j = paramList2.size();
    for (byte b = 0; b < paramInt; b++)
      while (paramGraph.addEdge(paramList1.get(randSingleton.nextInt(i)), paramList2.get(randSingleton.nextInt(j))) == null); 
  }
  
  public static Object[] addVertices(Graph paramGraph, VertexFactory paramVertexFactory, int paramInt) {
    Object[] arrayOfObject = new Object[paramInt];
    for (byte b = 0; b < paramInt; b++) {
      arrayOfObject[b] = paramVertexFactory.createVertex();
      paramGraph.addVertex(arrayOfObject[b]);
    } 
    return arrayOfObject;
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/experimental/RandomGraphHelper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */