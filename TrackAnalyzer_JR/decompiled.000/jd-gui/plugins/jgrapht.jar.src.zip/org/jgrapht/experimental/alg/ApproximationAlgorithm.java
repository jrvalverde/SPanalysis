package org.jgrapht.experimental.alg;

import java.util.Map;

public interface ApproximationAlgorithm<ResultType, V> {
  ResultType getUpperBound(Map<V, Object> paramMap);
  
  ResultType getLowerBound(Map<V, Object> paramMap);
  
  boolean isExact();
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/experimental/alg/ApproximationAlgorithm.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */