package org.jgrapht.experimental.touchgraph;

import java.applet.Applet;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import javax.swing.JFrame;
import org.jgrapht.Graph;
import org.jgrapht.graph.DefaultEdge;
import org.jgrapht.graph.SimpleGraph;

public class SimpleTouchgraphApplet extends Applet {
  private static final long serialVersionUID = 6213379835360007840L;
  
  public static Graph<String, DefaultEdge> createSamplegraph() {
    SimpleGraph simpleGraph = new SimpleGraph(DefaultEdge.class);
    String str1 = "v1";
    String str2 = "v2";
    String str3 = "v3";
    String str4 = "v4";
    simpleGraph.addVertex(str1);
    simpleGraph.addVertex(str2);
    simpleGraph.addVertex(str3);
    simpleGraph.addVertex(str4);
    simpleGraph.addEdge(str1, str2);
    simpleGraph.addEdge(str2, str3);
    simpleGraph.addEdge(str3, str4);
    simpleGraph.addEdge(str4, str1);
    return (Graph<String, DefaultEdge>)simpleGraph;
  }
  
  public void init() {
    Graph<String, DefaultEdge> graph = createSamplegraph();
    boolean bool = false;
    setLayout(new BorderLayout());
    setSize(800, 600);
    add((Component)new TouchgraphPanel<String, DefaultEdge>(graph, bool), "Center");
  }
  
  public static void main(String[] paramArrayOfString) {
    Graph<String, DefaultEdge> graph = createSamplegraph();
    boolean bool = false;
    JFrame jFrame = new JFrame();
    jFrame.getContentPane().add((Component)new TouchgraphPanel<String, DefaultEdge>(graph, bool));
    jFrame.setPreferredSize(new Dimension(800, 800));
    jFrame.setTitle("JGraphT to Touchgraph Converter Demo");
    jFrame.setDefaultCloseOperation(3);
    jFrame.pack();
    jFrame.setVisible(true);
    try {
      Thread.sleep(5000000L);
    } catch (InterruptedException interruptedException) {}
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/experimental/touchgraph/SimpleTouchgraphApplet.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */