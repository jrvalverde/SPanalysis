package org.jgrapht.experimental;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import org.jgrapht.Graph;
import org.jgrapht.VertexFactory;
import org.jgrapht.generate.GraphGenerator;
import org.jgrapht.graph.DefaultEdge;
import org.jgrapht.graph.SimpleGraph;

public class GraphReader<V, E> implements GraphGenerator<V, E, V> {
  private final BufferedReader _in;
  
  public GraphReader(String paramString) throws IOException {
    this._in = new BufferedReader(new FileReader(paramString));
  }
  
  private List<String> split(String paramString) {
    ArrayList<String> arrayList = new ArrayList();
    StringTokenizer stringTokenizer = new StringTokenizer(paramString);
    while (stringTokenizer.hasMoreTokens())
      arrayList.add(stringTokenizer.nextToken()); 
    return arrayList;
  }
  
  private List<String> skipComments() {
    try {
      if (this._in.ready()) {
        List<String> list = split(this._in.readLine());
        while (true) {
          if (list.isEmpty() || ((String)list.get(0)).equals("c") || ((String)list.get(0)).startsWith("%")) {
            list = split(this._in.readLine());
            continue;
          } 
          return list;
        } 
      } 
    } catch (IOException iOException) {}
    return null;
  }
  
  private int readNodeCount() {
    List<String> list = skipComments();
    return ((String)list.get(0)).equals("p") ? Integer.parseInt(list.get(1)) : -1;
  }
  
  public void generateGraph(Graph<V, E> paramGraph, VertexFactory<V> paramVertexFactory, Map<String, V> paramMap) {
    int i = readNodeCount();
    if (paramMap == null)
      paramMap = new HashMap<String, V>(); 
    for (byte b = 0; b < i; b++) {
      Object object = paramVertexFactory.createVertex();
      paramGraph.addVertex(object);
      paramMap.put(Integer.toString(b + 1), (V)object);
    } 
    for (List<String> list = skipComments(); list != null; list = skipComments()) {
      if (((String)list.get(0)).equals("e"))
        paramGraph.addEdge(paramMap.get(list.get(1)), paramMap.get(list.get(2))); 
    } 
  }
  
  public static void main(String[] paramArrayOfString) throws Exception {
    GraphReader<Object, Object> graphReader = new GraphReader<Object, Object>(paramArrayOfString[0]);
    SimpleGraph simpleGraph = new SimpleGraph(DefaultEdge.class);
    IntVertexFactory intVertexFactory = new IntVertexFactory();
    graphReader.generateGraph((Graph<Object, Object>)simpleGraph, intVertexFactory, null);
    System.out.println(simpleGraph);
  }
  
  private static final class IntVertexFactory implements VertexFactory<Integer> {
    int last = 0;
    
    private IntVertexFactory() {}
    
    public Integer createVertex() {
      return Integer.valueOf(this.last++);
    }
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/experimental/GraphReader.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */