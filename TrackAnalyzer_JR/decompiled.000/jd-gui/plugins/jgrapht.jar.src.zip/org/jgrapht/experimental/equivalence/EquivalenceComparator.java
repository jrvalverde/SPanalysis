package org.jgrapht.experimental.equivalence;

public interface EquivalenceComparator<E, C> {
  boolean equivalenceCompare(E paramE1, E paramE2, C paramC1, C paramC2);
  
  int equivalenceHashcode(E paramE, C paramC);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/experimental/equivalence/EquivalenceComparator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */