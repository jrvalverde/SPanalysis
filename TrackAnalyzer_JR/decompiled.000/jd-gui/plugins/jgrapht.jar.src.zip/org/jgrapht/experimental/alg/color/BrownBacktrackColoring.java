package org.jgrapht.experimental.alg.color;

import java.util.BitSet;
import java.util.Map;
import org.jgrapht.Graph;
import org.jgrapht.experimental.alg.ExactAlgorithm;
import org.jgrapht.experimental.alg.IntArrayGraphAlgorithm;

public class BrownBacktrackColoring<V, E> extends IntArrayGraphAlgorithm<V, E> implements ExactAlgorithm<Integer, V> {
  private int[] _color;
  
  private int[] _colorCount;
  
  private BitSet[] _allowedColors;
  
  private int _chi;
  
  public BrownBacktrackColoring(Graph<V, E> paramGraph) {
    super(paramGraph);
  }
  
  void recursiveColor(int paramInt) {
    this._colorCount[paramInt] = this._colorCount[paramInt - 1];
    this._allowedColors[paramInt].set(0, this._colorCount[paramInt] + 1);
    byte b;
    for (b = 0; b < (this._neighbors[paramInt]).length; b++) {
      int i = this._neighbors[paramInt][b];
      if (this._color[i] > 0)
        this._allowedColors[paramInt].clear(this._color[i]); 
    } 
    for (b = 1; b <= this._colorCount[paramInt] && this._colorCount[paramInt] < this._chi; b++) {
      if (this._allowedColors[paramInt].get(b)) {
        this._color[paramInt] = b;
        if (paramInt < this._neighbors.length - 1) {
          recursiveColor(paramInt + 1);
        } else {
          this._chi = this._colorCount[paramInt];
        } 
      } 
    } 
    if (this._colorCount[paramInt] + 1 < this._chi) {
      this._colorCount[paramInt] = this._colorCount[paramInt] + 1;
      this._color[paramInt] = this._colorCount[paramInt];
      if (paramInt < this._neighbors.length - 1) {
        recursiveColor(paramInt + 1);
      } else {
        this._chi = this._colorCount[paramInt];
      } 
    } 
    this._color[paramInt] = 0;
  }
  
  public Integer getResult(Map<V, Object> paramMap) {
    this._chi = this._neighbors.length;
    this._color = new int[this._neighbors.length];
    this._color[0] = 1;
    this._colorCount = new int[this._neighbors.length];
    this._colorCount[0] = 1;
    this._allowedColors = new BitSet[this._neighbors.length];
    byte b;
    for (b = 0; b < this._neighbors.length; b++)
      this._allowedColors[b] = new BitSet(1); 
    recursiveColor(1);
    for (b = 0; b < this._vertices.size(); b++)
      paramMap.put(this._vertices.get(b), Integer.valueOf(this._color[b])); 
    return Integer.valueOf(this._chi);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/experimental/alg/color/BrownBacktrackColoring.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */