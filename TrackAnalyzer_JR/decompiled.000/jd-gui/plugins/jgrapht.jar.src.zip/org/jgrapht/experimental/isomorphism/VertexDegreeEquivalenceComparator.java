package org.jgrapht.experimental.isomorphism;

import org.jgrapht.DirectedGraph;
import org.jgrapht.Graph;
import org.jgrapht.UndirectedGraph;
import org.jgrapht.experimental.equivalence.EquivalenceComparator;

public class VertexDegreeEquivalenceComparator<V, E> implements EquivalenceComparator<V, Graph<V, E>> {
  public boolean equivalenceCompare(V paramV1, V paramV2, Graph<V, E> paramGraph1, Graph<V, E> paramGraph2) {
    InOutDegrees inOutDegrees1 = getInOutDegrees(paramGraph1, paramV1);
    InOutDegrees inOutDegrees2 = getInOutDegrees(paramGraph2, paramV2);
    return inOutDegrees1.equals(inOutDegrees2);
  }
  
  public int equivalenceHashcode(V paramV, Graph<V, E> paramGraph) {
    InOutDegrees inOutDegrees = getInOutDegrees(paramGraph, paramV);
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append(String.valueOf(inOutDegrees.inDegree));
    stringBuffer.append("-");
    stringBuffer.append(String.valueOf(inOutDegrees.outDegree));
    return stringBuffer.toString().hashCode();
  }
  
  protected InOutDegrees getInOutDegrees(Graph<V, E> paramGraph, V paramV) {
    int i = 0;
    int j = 0;
    if (paramGraph instanceof UndirectedGraph) {
      UndirectedGraph undirectedGraph = (UndirectedGraph)paramGraph;
      i = undirectedGraph.degreeOf(paramV);
      j = i;
    } else if (paramGraph instanceof DirectedGraph) {
      DirectedGraph directedGraph = (DirectedGraph)paramGraph;
      i = directedGraph.inDegreeOf(paramV);
      j = directedGraph.outDegreeOf(paramV);
    } else {
      throw new RuntimeException("contextGraph is of unsupported type . It must be one of these two : UndirectedGraph or DirectedGraph");
    } 
    return new InOutDegrees(i, j);
  }
  
  protected class InOutDegrees {
    public int inDegree;
    
    public int outDegree;
    
    public InOutDegrees(int param1Int1, int param1Int2) {
      this.inDegree = param1Int1;
      this.outDegree = param1Int2;
    }
    
    public boolean equals(Object param1Object) {
      InOutDegrees inOutDegrees = (InOutDegrees)param1Object;
      return (this.inDegree == inOutDegrees.inDegree && this.outDegree == inOutDegrees.outDegree);
    }
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/experimental/isomorphism/VertexDegreeEquivalenceComparator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */