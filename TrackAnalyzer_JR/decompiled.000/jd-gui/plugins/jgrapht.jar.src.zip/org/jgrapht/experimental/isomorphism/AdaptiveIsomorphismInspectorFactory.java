package org.jgrapht.experimental.isomorphism;

import org.jgrapht.Graph;
import org.jgrapht.experimental.equivalence.EquivalenceComparator;
import org.jgrapht.experimental.equivalence.EquivalenceComparatorChainBase;

public class AdaptiveIsomorphismInspectorFactory {
  public static final int GRAPH_TYPE_ARBITRARY = 0;
  
  public static final int GRAPH_TYPE_PLANAR = 1;
  
  public static final int GRAPH_TYPE_TREE = 2;
  
  public static final int GRAPH_TYPE_MULTIGRAPH = 3;
  
  public static <V, E> GraphIsomorphismInspector createIsomorphismInspector(Graph<V, E> paramGraph1, Graph<V, E> paramGraph2, EquivalenceComparator<? super V, ? super Graph<V, E>> paramEquivalenceComparator, EquivalenceComparator<? super E, ? super Graph<V, E>> paramEquivalenceComparator1) {
    int i = checkGraphsType(paramGraph1, paramGraph2);
    return createAppropriateConcreteInspector(i, paramGraph1, paramGraph2, paramEquivalenceComparator, paramEquivalenceComparator1);
  }
  
  public static <V, E> GraphIsomorphismInspector createIsomorphismInspector(Graph<V, E> paramGraph1, Graph<V, E> paramGraph2) {
    return createIsomorphismInspector(paramGraph1, paramGraph2, null, null);
  }
  
  public static <V, E> GraphIsomorphismInspector createIsomorphismInspectorByType(int paramInt, Graph<V, E> paramGraph1, Graph<V, E> paramGraph2, EquivalenceComparator<? super V, ? super Graph<V, E>> paramEquivalenceComparator, EquivalenceComparator<? super E, ? super Graph<V, E>> paramEquivalenceComparator1) {
    return createAppropriateConcreteInspector(paramInt, paramGraph1, paramGraph2, paramEquivalenceComparator, paramEquivalenceComparator1);
  }
  
  public static <V, E> GraphIsomorphismInspector createIsomorphismInspectorByType(int paramInt, Graph<V, E> paramGraph1, Graph<V, E> paramGraph2) {
    return createAppropriateConcreteInspector(paramInt, paramGraph1, paramGraph2, null, null);
  }
  
  protected static <V, E> GraphIsomorphismInspector createAppropriateConcreteInspector(int paramInt, Graph<V, E> paramGraph1, Graph<V, E> paramGraph2, EquivalenceComparator<? super V, ? super Graph<V, E>> paramEquivalenceComparator, EquivalenceComparator<? super E, ? super Graph<V, E>> paramEquivalenceComparator1) {
    assertUnsupportedGraphTypes(paramGraph1);
    assertUnsupportedGraphTypes(paramGraph2);
    null = null;
    switch (paramInt) {
      case 0:
      case 1:
      case 2:
        return createTopologicalExhaustiveInspector(paramGraph1, paramGraph2, paramEquivalenceComparator, paramEquivalenceComparator1);
    } 
    throw new IllegalArgumentException("The type was not one of the supported types.");
  }
  
  protected static void assertUnsupportedGraphTypes(Graph paramGraph) throws IllegalArgumentException {
    if (paramGraph instanceof org.jgrapht.graph.Multigraph || paramGraph instanceof org.jgrapht.graph.DirectedMultigraph || paramGraph instanceof org.jgrapht.graph.Pseudograph)
      throw new IllegalArgumentException("graph type not supported for the graph" + paramGraph); 
  }
  
  protected static int checkGraphsType(Graph paramGraph1, Graph paramGraph2) {
    return 0;
  }
  
  protected static <V, E> GraphIsomorphismInspector createTopologicalExhaustiveInspector(Graph<V, E> paramGraph1, Graph<V, E> paramGraph2, EquivalenceComparator<? super V, ? super Graph<V, E>> paramEquivalenceComparator, EquivalenceComparator<? super E, ? super Graph<V, E>> paramEquivalenceComparator1) {
    VertexDegreeEquivalenceComparator<Object, Object> vertexDegreeEquivalenceComparator = new VertexDegreeEquivalenceComparator<Object, Object>();
    EquivalenceComparatorChainBase equivalenceComparatorChainBase = new EquivalenceComparatorChainBase(vertexDegreeEquivalenceComparator);
    equivalenceComparatorChainBase.appendComparator(paramEquivalenceComparator);
    return new EquivalenceIsomorphismInspector<V, E>(paramGraph1, paramGraph2, (EquivalenceComparator<? super V, ? super Graph<? super V, ? super E>>)equivalenceComparatorChainBase, paramEquivalenceComparator1);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/experimental/isomorphism/AdaptiveIsomorphismInspectorFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */