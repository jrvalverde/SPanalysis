package org.jgrapht.generate;

import java.util.HashMap;
import java.util.Map;
import org.jgrapht.Graph;
import org.jgrapht.VertexFactory;

public class RingGraphGenerator<V, E> implements GraphGenerator<V, E, V> {
  private int size;
  
  public RingGraphGenerator(int paramInt) {
    if (paramInt < 0)
      throw new IllegalArgumentException("must be non-negative"); 
    this.size = paramInt;
  }
  
  public void generateGraph(Graph<V, E> paramGraph, VertexFactory<V> paramVertexFactory, Map<String, V> paramMap) {
    if (this.size < 1)
      return; 
    LinearGraphGenerator<Object, Object> linearGraphGenerator = new LinearGraphGenerator<Object, Object>(this.size);
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    linearGraphGenerator.generateGraph((Graph)paramGraph, paramVertexFactory, (Map)hashMap);
    Object object1 = hashMap.get("Start Vertex");
    Object object2 = hashMap.get("End Vertex");
    paramGraph.addEdge(object2, object1);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/generate/RingGraphGenerator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */