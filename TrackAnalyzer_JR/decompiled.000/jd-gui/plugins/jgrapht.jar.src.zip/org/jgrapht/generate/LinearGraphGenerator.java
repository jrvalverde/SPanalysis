package org.jgrapht.generate;

import java.util.Map;
import org.jgrapht.Graph;
import org.jgrapht.VertexFactory;

public class LinearGraphGenerator<V, E> implements GraphGenerator<V, E, V> {
  public static final String START_VERTEX = "Start Vertex";
  
  public static final String END_VERTEX = "End Vertex";
  
  private int size;
  
  public LinearGraphGenerator(int paramInt) {
    if (paramInt < 0)
      throw new IllegalArgumentException("must be non-negative"); 
    this.size = paramInt;
  }
  
  public void generateGraph(Graph<V, E> paramGraph, VertexFactory<V> paramVertexFactory, Map<String, V> paramMap) {
    Object object = null;
    for (byte b = 0; b < this.size; b++) {
      Object object1 = paramVertexFactory.createVertex();
      paramGraph.addVertex(object1);
      if (object == null) {
        if (paramMap != null)
          paramMap.put("Start Vertex", (V)object1); 
      } else {
        paramGraph.addEdge(object, object1);
      } 
      object = object1;
    } 
    if (paramMap != null && object != null)
      paramMap.put("End Vertex", (V)object); 
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/generate/LinearGraphGenerator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */