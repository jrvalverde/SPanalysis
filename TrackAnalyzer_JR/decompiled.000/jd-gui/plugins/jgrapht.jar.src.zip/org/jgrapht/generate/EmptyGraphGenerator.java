package org.jgrapht.generate;

import java.util.Map;
import org.jgrapht.Graph;
import org.jgrapht.VertexFactory;

public class EmptyGraphGenerator<V, E> implements GraphGenerator<V, E, V> {
  private int size;
  
  public EmptyGraphGenerator(int paramInt) {
    if (paramInt < 0)
      throw new IllegalArgumentException("must be non-negative"); 
    this.size = paramInt;
  }
  
  public void generateGraph(Graph<V, E> paramGraph, VertexFactory<V> paramVertexFactory, Map<String, V> paramMap) {
    for (byte b = 0; b < this.size; b++)
      paramGraph.addVertex(paramVertexFactory.createVertex()); 
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/generate/EmptyGraphGenerator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */