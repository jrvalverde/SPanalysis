package org.jgrapht.generate;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;
import org.jgrapht.Graph;
import org.jgrapht.VertexFactory;

public class WheelGraphGenerator<V, E> implements GraphGenerator<V, E, V> {
  public static final String HUB_VERTEX = "Hub Vertex";
  
  private boolean inwardSpokes;
  
  private int size;
  
  public WheelGraphGenerator(int paramInt) {
    this(paramInt, true);
  }
  
  public WheelGraphGenerator(int paramInt, boolean paramBoolean) {
    if (paramInt < 0)
      throw new IllegalArgumentException("must be non-negative"); 
    this.size = paramInt;
    this.inwardSpokes = paramBoolean;
  }
  
  public void generateGraph(Graph<V, E> paramGraph, final VertexFactory<V> vertexFactory, Map<String, V> paramMap) {
    if (this.size < 1)
      return; 
    final ArrayList rim = new ArrayList();
    VertexFactory<V> vertexFactory = new VertexFactory<V>() {
        public V createVertex() {
          Object object = vertexFactory.createVertex();
          rim.add(object);
          return (V)object;
        }
      };
    RingGraphGenerator<Object, Object> ringGraphGenerator = new RingGraphGenerator<Object, Object>(this.size - 1);
    ringGraphGenerator.generateGraph((Graph)paramGraph, vertexFactory, (Map)paramMap);
    Object object = vertexFactory.createVertex();
    paramGraph.addVertex(object);
    if (paramMap != null)
      paramMap.put("Hub Vertex", (V)object); 
    for (Object object1 : arrayList) {
      if (this.inwardSpokes) {
        paramGraph.addEdge(object1, object);
        continue;
      } 
      paramGraph.addEdge(object, object1);
    } 
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/generate/WheelGraphGenerator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */