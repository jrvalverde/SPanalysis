package org.jgrapht.generate;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import org.jgrapht.Graph;
import org.jgrapht.VertexFactory;

public class RandomGraphGenerator<V, E> implements GraphGenerator<V, E, V> {
  private static long seedUniquifier = 8682522807148012L;
  
  protected int numOfVertexes;
  
  protected int numOfEdges;
  
  protected Random randomizer;
  
  private long randomizerSeed;
  
  public RandomGraphGenerator(int paramInt1, int paramInt2) {
    if (paramInt1 < 0 || paramInt2 < 0)
      throw new IllegalArgumentException("must be non-negative"); 
    this.numOfVertexes = paramInt1;
    this.numOfEdges = paramInt2;
    this.randomizerSeed = chooseRandomSeedOnce();
    this.randomizer = new Random(this.randomizerSeed);
  }
  
  private static synchronized long chooseRandomSeedOnce() {
    return ++seedUniquifier + System.nanoTime();
  }
  
  private void resetRandomSeed() {
    this.randomizer.setSeed(this.randomizerSeed);
  }
  
  public void generateGraph(Graph<V, E> paramGraph, VertexFactory<V> paramVertexFactory, Map<String, V> paramMap) {
    resetRandomSeed();
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>(this.numOfVertexes);
    for (byte b = 0; b < this.numOfVertexes; b++) {
      Object object = paramVertexFactory.createVertex();
      paramGraph.addVertex(object);
      hashMap.put(Integer.valueOf(b), object);
    } 
    EdgeTopologyFactory<V, E> edgeTopologyFactory = edgeTopologyFactoryChooser(paramGraph, this.numOfEdges);
    if (!edgeTopologyFactory.isNumberOfEdgesValid(paramGraph, this.numOfEdges))
      throw new IllegalArgumentException("numOfEdges is not valid for the graph type \n-> Invalid number Of Edges=" + this.numOfEdges + " for:" + " graph type=" + paramGraph.getClass() + " ,number Of Vertexes=" + this.numOfVertexes + "\n-> Advice: For the Max value , check the javadoc for" + " org.jgrapht.generate.RandomGraphGenerator.DefaultEdgeTopologyFactory"); 
    edgeTopologyFactory.createEdges(paramGraph, (Map)hashMap, this.numOfEdges, this.randomizer);
  }
  
  private EdgeTopologyFactory<V, E> edgeTopologyFactoryChooser(Graph<V, E> paramGraph, int paramInt) {
    return new DefaultEdgeTopologyFactory<V, E>();
  }
  
  public class DefaultEdgeTopologyFactory<VV, EE> implements EdgeTopologyFactory<VV, EE> {
    public void createEdges(Graph<VV, EE> param1Graph, Map<Integer, VV> param1Map, int param1Int, Random param1Random) {
      byte b1 = 0;
      byte b2 = 0;
      while (b2 < param1Int) {
        VV vV1 = param1Map.get(Integer.valueOf(param1Random.nextInt(RandomGraphGenerator.this.numOfVertexes)));
        VV vV2 = param1Map.get(Integer.valueOf(param1Random.nextInt(RandomGraphGenerator.this.numOfVertexes)));
        try {
          Object object = param1Graph.addEdge(vV1, vV2);
          if (object != null)
            b2++; 
        } catch (Exception exception) {}
        b1++;
      } 
    }
    
    public boolean isNumberOfEdgesValid(Graph<VV, EE> param1Graph, int param1Int) {
      boolean bool1;
      boolean bool2 = false;
      int i = getMaxEdgesForVertexNum(param1Graph);
      if (i == -1)
        bool2 = true; 
      if (true == bool2) {
        bool1 = true;
      } else if (param1Int <= i) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      return bool1;
    }
    
    public int getMaxEdgesForVertexNum(Graph<VV, EE> param1Graph) {
      int i = 0;
      if (param1Graph instanceof org.jgrapht.graph.SimpleGraph) {
        i = RandomGraphGenerator.this.numOfVertexes * (RandomGraphGenerator.this.numOfVertexes - 1) / 2;
      } else if (param1Graph instanceof org.jgrapht.graph.SimpleDirectedGraph) {
        i = RandomGraphGenerator.this.numOfVertexes * (RandomGraphGenerator.this.numOfVertexes - 1);
      } else if (param1Graph instanceof org.jgrapht.graph.DefaultDirectedGraph) {
        i = RandomGraphGenerator.this.numOfVertexes * RandomGraphGenerator.this.numOfVertexes;
      } else if (param1Graph instanceof org.jgrapht.graph.Multigraph || param1Graph instanceof org.jgrapht.graph.Pseudograph || param1Graph instanceof org.jgrapht.graph.DirectedMultigraph) {
        i = -1;
      } else {
        throw new ClassCastException("cannot find the appropriate graph type");
      } 
      return i;
    }
  }
  
  public static interface EdgeTopologyFactory<VV, EE> {
    void createEdges(Graph<VV, EE> param1Graph, Map<Integer, VV> param1Map, int param1Int, Random param1Random);
    
    boolean isNumberOfEdgesValid(Graph<VV, EE> param1Graph, int param1Int);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/generate/RandomGraphGenerator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */