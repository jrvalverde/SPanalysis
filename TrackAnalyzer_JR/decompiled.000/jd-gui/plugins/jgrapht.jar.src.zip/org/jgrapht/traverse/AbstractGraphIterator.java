package org.jgrapht.traverse;

import java.util.ArrayList;
import java.util.List;
import org.jgrapht.event.ConnectedComponentTraversalEvent;
import org.jgrapht.event.EdgeTraversalEvent;
import org.jgrapht.event.TraversalListener;
import org.jgrapht.event.VertexTraversalEvent;

public abstract class AbstractGraphIterator<V, E> implements GraphIterator<V, E> {
  private List<TraversalListener<V, E>> traversalListeners = new ArrayList<TraversalListener<V, E>>();
  
  private boolean crossComponentTraversal = true;
  
  private boolean reuseEvents = false;
  
  public void setCrossComponentTraversal(boolean paramBoolean) {
    this.crossComponentTraversal = paramBoolean;
  }
  
  public boolean isCrossComponentTraversal() {
    return this.crossComponentTraversal;
  }
  
  public void setReuseEvents(boolean paramBoolean) {
    this.reuseEvents = paramBoolean;
  }
  
  public boolean isReuseEvents() {
    return this.reuseEvents;
  }
  
  public void addTraversalListener(TraversalListener<V, E> paramTraversalListener) {
    if (!this.traversalListeners.contains(paramTraversalListener))
      this.traversalListeners.add(paramTraversalListener); 
  }
  
  public void remove() {
    throw new UnsupportedOperationException();
  }
  
  public void removeTraversalListener(TraversalListener<V, E> paramTraversalListener) {
    this.traversalListeners.remove(paramTraversalListener);
  }
  
  protected void fireConnectedComponentFinished(ConnectedComponentTraversalEvent paramConnectedComponentTraversalEvent) {
    int i = this.traversalListeners.size();
    for (byte b = 0; b < i; b++) {
      TraversalListener traversalListener = this.traversalListeners.get(b);
      traversalListener.connectedComponentFinished(paramConnectedComponentTraversalEvent);
    } 
  }
  
  protected void fireConnectedComponentStarted(ConnectedComponentTraversalEvent paramConnectedComponentTraversalEvent) {
    int i = this.traversalListeners.size();
    for (byte b = 0; b < i; b++) {
      TraversalListener traversalListener = this.traversalListeners.get(b);
      traversalListener.connectedComponentStarted(paramConnectedComponentTraversalEvent);
    } 
  }
  
  protected void fireEdgeTraversed(EdgeTraversalEvent<V, E> paramEdgeTraversalEvent) {
    int i = this.traversalListeners.size();
    for (byte b = 0; b < i; b++) {
      TraversalListener traversalListener = this.traversalListeners.get(b);
      traversalListener.edgeTraversed(paramEdgeTraversalEvent);
    } 
  }
  
  protected void fireVertexTraversed(VertexTraversalEvent<V> paramVertexTraversalEvent) {
    int i = this.traversalListeners.size();
    for (byte b = 0; b < i; b++) {
      TraversalListener traversalListener = this.traversalListeners.get(b);
      traversalListener.vertexTraversed(paramVertexTraversalEvent);
    } 
  }
  
  protected void fireVertexFinished(VertexTraversalEvent<V> paramVertexTraversalEvent) {
    int i = this.traversalListeners.size();
    for (byte b = 0; b < i; b++) {
      TraversalListener traversalListener = this.traversalListeners.get(b);
      traversalListener.vertexFinished(paramVertexTraversalEvent);
    } 
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/traverse/AbstractGraphIterator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */