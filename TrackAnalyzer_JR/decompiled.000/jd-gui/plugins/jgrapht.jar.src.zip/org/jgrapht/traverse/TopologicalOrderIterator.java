package org.jgrapht.traverse;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;
import org.jgrapht.DirectedGraph;
import org.jgrapht.Graph;
import org.jgrapht.util.ModifiableInteger;

public class TopologicalOrderIterator<V, E> extends CrossComponentIterator<V, E, Object> {
  private Queue<V> queue;
  
  private Map<V, ModifiableInteger> inDegreeMap;
  
  public TopologicalOrderIterator(DirectedGraph<V, E> paramDirectedGraph) {
    this(paramDirectedGraph, new LinkedListQueue<V>(null));
  }
  
  public TopologicalOrderIterator(DirectedGraph<V, E> paramDirectedGraph, Queue<V> paramQueue) {
    this(paramDirectedGraph, paramQueue, new HashMap<V, ModifiableInteger>());
  }
  
  private TopologicalOrderIterator(DirectedGraph<V, E> paramDirectedGraph, Queue<V> paramQueue, Map<V, ModifiableInteger> paramMap) {
    this(paramDirectedGraph, initialize(paramDirectedGraph, paramQueue, paramMap));
    this.queue = paramQueue;
    this.inDegreeMap = paramMap;
    assert !paramQueue.isEmpty();
  }
  
  private TopologicalOrderIterator(DirectedGraph<V, E> paramDirectedGraph, V paramV) {
    super((Graph<V, E>)paramDirectedGraph, paramV);
  }
  
  protected boolean isConnectedComponentExhausted() {
    return this.queue.isEmpty();
  }
  
  protected void encounterVertex(V paramV, E paramE) {
    putSeenData(paramV, null);
    decrementInDegree(paramV);
  }
  
  protected void encounterVertexAgain(V paramV, E paramE) {
    decrementInDegree(paramV);
  }
  
  protected V provideNextVertex() {
    return this.queue.remove();
  }
  
  private void decrementInDegree(V paramV) {
    ModifiableInteger modifiableInteger = this.inDegreeMap.get(paramV);
    if (modifiableInteger.value > 0) {
      modifiableInteger.value--;
      if (modifiableInteger.value == 0)
        this.queue.offer(paramV); 
    } 
  }
  
  private static <V, E> V initialize(DirectedGraph<V, E> paramDirectedGraph, Queue<V> paramQueue, Map<V, ModifiableInteger> paramMap) {
    for (V v : paramDirectedGraph.vertexSet()) {
      int i = paramDirectedGraph.inDegreeOf(v);
      paramMap.put(v, new ModifiableInteger(i));
      if (i == 0)
        paramQueue.offer(v); 
    } 
    return paramQueue.isEmpty() ? null : paramQueue.peek();
  }
  
  private static class LinkedListQueue<T> extends LinkedList<T> implements Queue<T> {
    private static final long serialVersionUID = 4217659843476891334L;
    
    private LinkedListQueue() {}
    
    public T element() {
      return getFirst();
    }
    
    public boolean offer(T param1T) {
      return add(param1T);
    }
    
    public T peek() {
      return isEmpty() ? null : getFirst();
    }
    
    public T poll() {
      return isEmpty() ? null : removeFirst();
    }
    
    public T remove() {
      return removeFirst();
    }
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/traverse/TopologicalOrderIterator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */