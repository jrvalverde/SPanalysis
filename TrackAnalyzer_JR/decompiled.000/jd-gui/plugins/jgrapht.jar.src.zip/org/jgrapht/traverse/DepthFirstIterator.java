package org.jgrapht.traverse;

import java.util.ArrayList;
import java.util.List;
import org.jgrapht.Graph;

public class DepthFirstIterator<V, E> extends CrossComponentIterator<V, E, CrossComponentIterator.VisitColor> {
  private List<V> stack = new ArrayList<V>();
  
  public DepthFirstIterator(Graph<V, E> paramGraph) {
    this(paramGraph, (V)null);
  }
  
  public DepthFirstIterator(Graph<V, E> paramGraph, V paramV) {
    super(paramGraph, paramV);
  }
  
  protected boolean isConnectedComponentExhausted() {
    while (true) {
      if (this.stack.isEmpty())
        return true; 
      if (peekStack() != null)
        return false; 
      popStack();
      recordFinish();
    } 
  }
  
  protected void encounterVertex(V paramV, E paramE) {
    putSeenData(paramV, CrossComponentIterator.VisitColor.WHITE);
    this.stack.add(paramV);
  }
  
  protected void encounterVertexAgain(V paramV, E paramE) {
    CrossComponentIterator.VisitColor visitColor = getSeenData(paramV);
    if (visitColor != CrossComponentIterator.VisitColor.WHITE)
      return; 
    int i = this.stack.indexOf(paramV);
    assert i > -1;
    this.stack.remove(i);
    this.stack.add(paramV);
  }
  
  protected V provideNextVertex() {
    while (true) {
      V v = popStack();
      if (v == null) {
        recordFinish();
        continue;
      } 
      this.stack.add(v);
      this.stack.add(null);
      putSeenData(v, CrossComponentIterator.VisitColor.GRAY);
      return v;
    } 
  }
  
  private V popStack() {
    return this.stack.remove(this.stack.size() - 1);
  }
  
  private V peekStack() {
    return this.stack.get(this.stack.size() - 1);
  }
  
  private void recordFinish() {
    V v = popStack();
    putSeenData(v, CrossComponentIterator.VisitColor.BLACK);
    finishVertex(v);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/traverse/DepthFirstIterator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */