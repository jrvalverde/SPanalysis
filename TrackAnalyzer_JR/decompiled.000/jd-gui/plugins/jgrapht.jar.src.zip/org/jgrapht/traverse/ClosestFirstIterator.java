package org.jgrapht.traverse;

import org.jgrapht.Graph;
import org.jgrapht.Graphs;
import org.jgrapht.util.FibonacciHeap;
import org.jgrapht.util.FibonacciHeapNode;

public class ClosestFirstIterator<V, E> extends CrossComponentIterator<V, E, FibonacciHeapNode<ClosestFirstIterator.QueueEntry<V, E>>> {
  private FibonacciHeap<QueueEntry<V, E>> heap = new FibonacciHeap();
  
  private double radius = Double.POSITIVE_INFINITY;
  
  private boolean initialized = false;
  
  public ClosestFirstIterator(Graph<V, E> paramGraph) {
    this(paramGraph, (V)null);
  }
  
  public ClosestFirstIterator(Graph<V, E> paramGraph, V paramV) {
    this(paramGraph, paramV, Double.POSITIVE_INFINITY);
  }
  
  public ClosestFirstIterator(Graph<V, E> paramGraph, V paramV, double paramDouble) {
    super(paramGraph, paramV);
    this.radius = paramDouble;
    checkRadiusTraversal(isCrossComponentTraversal());
    this.initialized = true;
  }
  
  public void setCrossComponentTraversal(boolean paramBoolean) {
    if (this.initialized)
      checkRadiusTraversal(paramBoolean); 
    super.setCrossComponentTraversal(paramBoolean);
  }
  
  public double getShortestPathLength(V paramV) {
    FibonacciHeapNode<QueueEntry<V, E>> fibonacciHeapNode = getSeenData(paramV);
    return (fibonacciHeapNode == null) ? Double.POSITIVE_INFINITY : fibonacciHeapNode.getKey();
  }
  
  public E getSpanningTreeEdge(V paramV) {
    FibonacciHeapNode<QueueEntry<V, E>> fibonacciHeapNode = getSeenData(paramV);
    return (fibonacciHeapNode == null) ? null : ((QueueEntry)fibonacciHeapNode.getData()).spanningTreeEdge;
  }
  
  protected boolean isConnectedComponentExhausted() {
    if (this.heap.size() == 0)
      return true; 
    if (this.heap.min().getKey() > this.radius) {
      this.heap.clear();
      return true;
    } 
    return false;
  }
  
  protected void encounterVertex(V paramV, E paramE) {
    FibonacciHeapNode<QueueEntry<V, E>> fibonacciHeapNode = createSeenData(paramV, paramE);
    putSeenData(paramV, fibonacciHeapNode);
    this.heap.insert(fibonacciHeapNode, fibonacciHeapNode.getKey());
  }
  
  protected void encounterVertexAgain(V paramV, E paramE) {
    FibonacciHeapNode<QueueEntry<V, E>> fibonacciHeapNode = getSeenData(paramV);
    if (((QueueEntry)fibonacciHeapNode.getData()).frozen)
      return; 
    double d = calculatePathLength(paramV, paramE);
    if (d < fibonacciHeapNode.getKey()) {
      ((QueueEntry)fibonacciHeapNode.getData()).spanningTreeEdge = paramE;
      this.heap.decreaseKey(fibonacciHeapNode, d);
    } 
  }
  
  protected V provideNextVertex() {
    FibonacciHeapNode fibonacciHeapNode = this.heap.removeMin();
    ((QueueEntry)fibonacciHeapNode.getData()).frozen = true;
    return ((QueueEntry)fibonacciHeapNode.getData()).vertex;
  }
  
  private void assertNonNegativeEdge(E paramE) {
    if (getGraph().getEdgeWeight(paramE) < 0.0D)
      throw new IllegalArgumentException("negative edge weights not allowed"); 
  }
  
  private double calculatePathLength(V paramV, E paramE) {
    assertNonNegativeEdge(paramE);
    Object object = Graphs.getOppositeVertex(getGraph(), paramE, paramV);
    FibonacciHeapNode<QueueEntry<V, E>> fibonacciHeapNode = getSeenData((V)object);
    return fibonacciHeapNode.getKey() + getGraph().getEdgeWeight(paramE);
  }
  
  private void checkRadiusTraversal(boolean paramBoolean) {
    if (paramBoolean && this.radius != Double.POSITIVE_INFINITY)
      throw new IllegalArgumentException("radius may not be specified for cross-component traversal"); 
  }
  
  private FibonacciHeapNode<QueueEntry<V, E>> createSeenData(V paramV, E paramE) {
    double d;
    if (paramE == null) {
      d = 0.0D;
    } else {
      d = calculatePathLength(paramV, paramE);
    } 
    QueueEntry<Object, Object> queueEntry = new QueueEntry<Object, Object>();
    queueEntry.vertex = paramV;
    queueEntry.spanningTreeEdge = paramE;
    return new FibonacciHeapNode(queueEntry, d);
  }
  
  static class QueueEntry<V, E> {
    E spanningTreeEdge;
    
    V vertex;
    
    boolean frozen;
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/traverse/ClosestFirstIterator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */