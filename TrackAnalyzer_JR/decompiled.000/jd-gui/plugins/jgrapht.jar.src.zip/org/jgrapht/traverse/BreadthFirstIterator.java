package org.jgrapht.traverse;

import java.util.LinkedList;
import org.jgrapht.Graph;

public class BreadthFirstIterator<V, E> extends CrossComponentIterator<V, E, Object> {
  private LinkedList<V> queue = new LinkedList<V>();
  
  public BreadthFirstIterator(Graph<V, E> paramGraph) {
    this(paramGraph, null);
  }
  
  public BreadthFirstIterator(Graph<V, E> paramGraph, V paramV) {
    super(paramGraph, paramV);
  }
  
  protected boolean isConnectedComponentExhausted() {
    return this.queue.isEmpty();
  }
  
  protected void encounterVertex(V paramV, E paramE) {
    putSeenData(paramV, null);
    this.queue.add(paramV);
  }
  
  protected void encounterVertexAgain(V paramV, E paramE) {}
  
  protected V provideNextVertex() {
    return this.queue.removeFirst();
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/traverse/BreadthFirstIterator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */