package org.jgrapht.traverse;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Set;
import org.jgrapht.DirectedGraph;
import org.jgrapht.Graph;
import org.jgrapht.event.ConnectedComponentTraversalEvent;
import org.jgrapht.event.EdgeTraversalEvent;
import org.jgrapht.event.VertexTraversalEvent;

public abstract class CrossComponentIterator<V, E, D> extends AbstractGraphIterator<V, E> {
  private static final int CCS_BEFORE_COMPONENT = 1;
  
  private static final int CCS_WITHIN_COMPONENT = 2;
  
  private static final int CCS_AFTER_COMPONENT = 3;
  
  private final ConnectedComponentTraversalEvent ccFinishedEvent = new ConnectedComponentTraversalEvent(this, 32);
  
  private final ConnectedComponentTraversalEvent ccStartedEvent = new ConnectedComponentTraversalEvent(this, 31);
  
  private FlyweightEdgeEvent<V, E> reusableEdgeEvent;
  
  private FlyweightVertexEvent<V> reusableVertexEvent;
  
  private Iterator<V> vertexIterator = null;
  
  private Map<V, D> seen = new HashMap<V, D>();
  
  private V startVertex;
  
  private Specifics<V, E> specifics;
  
  private final Graph<V, E> graph;
  
  private int state = 1;
  
  public CrossComponentIterator(Graph<V, E> paramGraph, V paramV) {
    if (paramGraph == null)
      throw new IllegalArgumentException("graph must not be null"); 
    this.graph = paramGraph;
    this.specifics = createGraphSpecifics(paramGraph);
    this.vertexIterator = paramGraph.vertexSet().iterator();
    setCrossComponentTraversal((paramV == null));
    this.reusableEdgeEvent = new FlyweightEdgeEvent<V, E>(this, null);
    this.reusableVertexEvent = new FlyweightVertexEvent<V>(this, null);
    if (paramV == null) {
      if (this.vertexIterator.hasNext()) {
        this.startVertex = this.vertexIterator.next();
      } else {
        this.startVertex = null;
      } 
    } else if (paramGraph.containsVertex(paramV)) {
      this.startVertex = paramV;
    } else {
      throw new IllegalArgumentException("graph must contain the start vertex");
    } 
  }
  
  public Graph<V, E> getGraph() {
    return this.graph;
  }
  
  public boolean hasNext() {
    if (this.startVertex != null)
      encounterStartVertex(); 
    if (isConnectedComponentExhausted()) {
      if (this.state == 2) {
        this.state = 3;
        fireConnectedComponentFinished(this.ccFinishedEvent);
      } 
      if (isCrossComponentTraversal()) {
        while (this.vertexIterator.hasNext()) {
          V v = this.vertexIterator.next();
          if (!isSeenVertex(v)) {
            encounterVertex(v, (E)null);
            this.state = 1;
            return true;
          } 
        } 
        return false;
      } 
      return false;
    } 
    return true;
  }
  
  public V next() {
    if (this.startVertex != null)
      encounterStartVertex(); 
    if (hasNext()) {
      if (this.state == 1) {
        this.state = 2;
        fireConnectedComponentStarted(this.ccStartedEvent);
      } 
      V v = provideNextVertex();
      fireVertexTraversed(createVertexTraversalEvent(v));
      addUnseenChildrenOf(v);
      return v;
    } 
    throw new NoSuchElementException();
  }
  
  protected abstract boolean isConnectedComponentExhausted();
  
  protected abstract void encounterVertex(V paramV, E paramE);
  
  protected abstract V provideNextVertex();
  
  protected D getSeenData(V paramV) {
    return this.seen.get(paramV);
  }
  
  protected boolean isSeenVertex(Object paramObject) {
    return this.seen.containsKey(paramObject);
  }
  
  protected abstract void encounterVertexAgain(V paramV, E paramE);
  
  protected D putSeenData(V paramV, D paramD) {
    return this.seen.put(paramV, paramD);
  }
  
  protected void finishVertex(V paramV) {
    fireVertexFinished(createVertexTraversalEvent(paramV));
  }
  
  static <V, E> Specifics<V, E> createGraphSpecifics(Graph<V, E> paramGraph) {
    return (Specifics<V, E>)((paramGraph instanceof DirectedGraph) ? new DirectedSpecifics<V, E>((DirectedGraph<V, E>)paramGraph) : new UndirectedSpecifics<V, E>(paramGraph));
  }
  
  private void addUnseenChildrenOf(V paramV) {
    // Byte code:
    //   0: aload_0
    //   1: getfield specifics : Lorg/jgrapht/traverse/CrossComponentIterator$Specifics;
    //   4: aload_1
    //   5: invokevirtual edgesOf : (Ljava/lang/Object;)Ljava/util/Set;
    //   8: invokeinterface iterator : ()Ljava/util/Iterator;
    //   13: astore_2
    //   14: aload_2
    //   15: invokeinterface hasNext : ()Z
    //   20: ifeq -> 79
    //   23: aload_2
    //   24: invokeinterface next : ()Ljava/lang/Object;
    //   29: astore_3
    //   30: aload_0
    //   31: aload_0
    //   32: aload_3
    //   33: invokespecial createEdgeTraversalEvent : (Ljava/lang/Object;)Lorg/jgrapht/event/EdgeTraversalEvent;
    //   36: invokevirtual fireEdgeTraversed : (Lorg/jgrapht/event/EdgeTraversalEvent;)V
    //   39: aload_0
    //   40: getfield graph : Lorg/jgrapht/Graph;
    //   43: aload_3
    //   44: aload_1
    //   45: invokestatic getOppositeVertex : (Lorg/jgrapht/Graph;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   48: astore #4
    //   50: aload_0
    //   51: aload #4
    //   53: invokevirtual isSeenVertex : (Ljava/lang/Object;)Z
    //   56: ifeq -> 69
    //   59: aload_0
    //   60: aload #4
    //   62: aload_3
    //   63: invokevirtual encounterVertexAgain : (Ljava/lang/Object;Ljava/lang/Object;)V
    //   66: goto -> 76
    //   69: aload_0
    //   70: aload #4
    //   72: aload_3
    //   73: invokevirtual encounterVertex : (Ljava/lang/Object;Ljava/lang/Object;)V
    //   76: goto -> 14
    //   79: return
  }
  
  private EdgeTraversalEvent<V, E> createEdgeTraversalEvent(E paramE) {
    if (isReuseEvents()) {
      this.reusableEdgeEvent.setEdge(paramE);
      return this.reusableEdgeEvent;
    } 
    return new EdgeTraversalEvent(this, paramE);
  }
  
  private VertexTraversalEvent<V> createVertexTraversalEvent(V paramV) {
    if (isReuseEvents()) {
      this.reusableVertexEvent.setVertex(paramV);
      return this.reusableVertexEvent;
    } 
    return new VertexTraversalEvent(this, paramV);
  }
  
  private void encounterStartVertex() {
    encounterVertex(this.startVertex, (E)null);
    this.startVertex = null;
  }
  
  private static class UndirectedSpecifics<VV, EE> extends Specifics<VV, EE> {
    private Graph<VV, EE> graph;
    
    public UndirectedSpecifics(Graph<VV, EE> param1Graph) {
      this.graph = param1Graph;
    }
    
    public Set<EE> edgesOf(VV param1VV) {
      return this.graph.edgesOf(param1VV);
    }
  }
  
  private static class DirectedSpecifics<VV, EE> extends Specifics<VV, EE> {
    private DirectedGraph<VV, EE> graph;
    
    public DirectedSpecifics(DirectedGraph<VV, EE> param1DirectedGraph) {
      this.graph = param1DirectedGraph;
    }
    
    public Set<? extends EE> edgesOf(VV param1VV) {
      return this.graph.outgoingEdgesOf(param1VV);
    }
  }
  
  static class FlyweightVertexEvent<VV> extends VertexTraversalEvent<VV> {
    private static final long serialVersionUID = 3834024753848399924L;
    
    public FlyweightVertexEvent(Object param1Object, VV param1VV) {
      super(param1Object, param1VV);
    }
    
    protected void setVertex(VV param1VV) {
      this.vertex = param1VV;
    }
  }
  
  static class FlyweightEdgeEvent<VV, localE> extends EdgeTraversalEvent<VV, localE> {
    private static final long serialVersionUID = 4051327833765000755L;
    
    public FlyweightEdgeEvent(Object param1Object, localE param1localE) {
      super(param1Object, param1localE);
    }
    
    protected void setEdge(localE param1localE) {
      this.edge = param1localE;
    }
  }
  
  static abstract class Specifics<VV, EE> {
    public abstract Set<? extends EE> edgesOf(VV param1VV);
  }
  
  static interface SimpleContainer<T> {
    boolean isEmpty();
    
    void add(T param1T);
    
    T remove();
  }
  
  protected enum VisitColor {
    WHITE, GRAY, BLACK;
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/traverse/CrossComponentIterator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */