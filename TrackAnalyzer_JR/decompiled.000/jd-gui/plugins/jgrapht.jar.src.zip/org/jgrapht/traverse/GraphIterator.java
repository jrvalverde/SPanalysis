package org.jgrapht.traverse;

import java.util.Iterator;
import org.jgrapht.event.TraversalListener;

public interface GraphIterator<V, E> extends Iterator<V> {
  boolean isCrossComponentTraversal();
  
  void setReuseEvents(boolean paramBoolean);
  
  boolean isReuseEvents();
  
  void addTraversalListener(TraversalListener<V, E> paramTraversalListener);
  
  void remove();
  
  void removeTraversalListener(TraversalListener<V, E> paramTraversalListener);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/traverse/GraphIterator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */