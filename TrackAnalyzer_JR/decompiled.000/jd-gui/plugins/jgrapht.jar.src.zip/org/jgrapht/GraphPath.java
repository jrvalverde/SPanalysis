package org.jgrapht;

import java.util.List;

public interface GraphPath<V, E> {
  Graph<V, E> getGraph();
  
  V getStartVertex();
  
  V getEndVertex();
  
  List<E> getEdgeList();
  
  double getWeight();
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/GraphPath.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */