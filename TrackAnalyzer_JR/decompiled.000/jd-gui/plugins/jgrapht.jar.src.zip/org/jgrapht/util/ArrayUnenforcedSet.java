package org.jgrapht.util;

import java.util.AbstractSet;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.Set;

public class ArrayUnenforcedSet<E> extends ArrayList<E> implements Set<E> {
  private static final long serialVersionUID = -7413250161201811238L;
  
  public ArrayUnenforcedSet() {}
  
  public ArrayUnenforcedSet(Collection<? extends E> paramCollection) {
    super(paramCollection);
  }
  
  public ArrayUnenforcedSet(int paramInt) {
    super(paramInt);
  }
  
  public boolean equals(Object paramObject) {
    return (new SetForEquality()).equals(paramObject);
  }
  
  public int hashCode() {
    return (new SetForEquality()).hashCode();
  }
  
  private class SetForEquality extends AbstractSet<E> {
    private SetForEquality() {}
    
    public Iterator<E> iterator() {
      return ArrayUnenforcedSet.this.iterator();
    }
    
    public int size() {
      return ArrayUnenforcedSet.this.size();
    }
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/util/ArrayUnenforcedSet.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */