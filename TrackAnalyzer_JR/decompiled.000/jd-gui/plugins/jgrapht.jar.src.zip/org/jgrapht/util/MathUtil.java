package org.jgrapht.util;

public class MathUtil {
  public static long factorial(int paramInt) {
    long l = 1L;
    for (byte b = 1; b <= paramInt; b++)
      l *= b; 
    return l;
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/util/MathUtil.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */