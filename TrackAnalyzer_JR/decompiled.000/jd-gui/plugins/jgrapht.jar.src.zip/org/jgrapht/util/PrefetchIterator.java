package org.jgrapht.util;

import java.util.Enumeration;
import java.util.Iterator;
import java.util.NoSuchElementException;

public class PrefetchIterator<E> implements Iterator<E>, Enumeration<E> {
  private NextElementFunctor<E> innerEnum;
  
  private E getNextLastResult;
  
  private boolean isGetNextLastResultUpToDate = false;
  
  private boolean endOfEnumerationReached = false;
  
  private boolean flagIsEnumerationStartedEmpty = true;
  
  private int innerFunctorUsageCounter = 0;
  
  public PrefetchIterator(NextElementFunctor<E> paramNextElementFunctor) {
    this.innerEnum = paramNextElementFunctor;
  }
  
  private E getNextElementFromInnerFunctor() {
    this.innerFunctorUsageCounter++;
    E e = this.innerEnum.nextElement();
    this.flagIsEnumerationStartedEmpty = false;
    return e;
  }
  
  public E nextElement() {
    E e = null;
    if (this.isGetNextLastResultUpToDate) {
      E e1 = this.getNextLastResult;
    } else {
      e = getNextElementFromInnerFunctor();
    } 
    this.isGetNextLastResultUpToDate = false;
    return e;
  }
  
  public boolean hasMoreElements() {
    if (this.endOfEnumerationReached)
      return false; 
    if (this.isGetNextLastResultUpToDate)
      return true; 
    try {
      this.getNextLastResult = getNextElementFromInnerFunctor();
      this.isGetNextLastResultUpToDate = true;
      return true;
    } catch (NoSuchElementException noSuchElementException) {
      this.endOfEnumerationReached = true;
      return false;
    } 
  }
  
  public boolean isEnumerationStartedEmpty() {
    return (this.innerFunctorUsageCounter == 0) ? (!hasMoreElements()) : this.flagIsEnumerationStartedEmpty;
  }
  
  public boolean hasNext() {
    return hasMoreElements();
  }
  
  public E next() {
    return nextElement();
  }
  
  public void remove() throws UnsupportedOperationException {
    throw new UnsupportedOperationException();
  }
  
  public static interface NextElementFunctor<EE> {
    EE nextElement() throws NoSuchElementException;
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/util/PrefetchIterator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */