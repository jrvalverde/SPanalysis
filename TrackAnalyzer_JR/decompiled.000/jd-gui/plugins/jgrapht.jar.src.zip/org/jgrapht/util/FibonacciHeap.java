package org.jgrapht.util;

import java.util.ArrayList;
import java.util.Stack;

public class FibonacciHeap<T> {
  private FibonacciHeapNode<T> minNode;
  
  private int nNodes;
  
  public boolean isEmpty() {
    return (this.minNode == null);
  }
  
  public void clear() {
    this.minNode = null;
    this.nNodes = 0;
  }
  
  public void decreaseKey(FibonacciHeapNode<T> paramFibonacciHeapNode, double paramDouble) {
    if (paramDouble > paramFibonacciHeapNode.key)
      throw new IllegalArgumentException("decreaseKey() got larger key value"); 
    paramFibonacciHeapNode.key = paramDouble;
    FibonacciHeapNode<T> fibonacciHeapNode = paramFibonacciHeapNode.parent;
    if (fibonacciHeapNode != null && paramFibonacciHeapNode.key < fibonacciHeapNode.key) {
      cut(paramFibonacciHeapNode, fibonacciHeapNode);
      cascadingCut(fibonacciHeapNode);
    } 
    if (paramFibonacciHeapNode.key < this.minNode.key)
      this.minNode = paramFibonacciHeapNode; 
  }
  
  public void delete(FibonacciHeapNode<T> paramFibonacciHeapNode) {
    decreaseKey(paramFibonacciHeapNode, Double.NEGATIVE_INFINITY);
    removeMin();
  }
  
  public void insert(FibonacciHeapNode<T> paramFibonacciHeapNode, double paramDouble) {
    paramFibonacciHeapNode.key = paramDouble;
    if (this.minNode != null) {
      paramFibonacciHeapNode.left = this.minNode;
      paramFibonacciHeapNode.right = this.minNode.right;
      this.minNode.right = paramFibonacciHeapNode;
      paramFibonacciHeapNode.right.left = paramFibonacciHeapNode;
      if (paramDouble < this.minNode.key)
        this.minNode = paramFibonacciHeapNode; 
    } else {
      this.minNode = paramFibonacciHeapNode;
    } 
    this.nNodes++;
  }
  
  public FibonacciHeapNode<T> min() {
    return this.minNode;
  }
  
  public FibonacciHeapNode<T> removeMin() {
    FibonacciHeapNode<T> fibonacciHeapNode = this.minNode;
    if (fibonacciHeapNode != null) {
      int i = fibonacciHeapNode.degree;
      FibonacciHeapNode<T> fibonacciHeapNode1 = fibonacciHeapNode.child;
      while (i > 0) {
        FibonacciHeapNode<T> fibonacciHeapNode2 = fibonacciHeapNode1.right;
        fibonacciHeapNode1.left.right = fibonacciHeapNode1.right;
        fibonacciHeapNode1.right.left = fibonacciHeapNode1.left;
        fibonacciHeapNode1.left = this.minNode;
        fibonacciHeapNode1.right = this.minNode.right;
        this.minNode.right = fibonacciHeapNode1;
        fibonacciHeapNode1.right.left = fibonacciHeapNode1;
        fibonacciHeapNode1.parent = null;
        fibonacciHeapNode1 = fibonacciHeapNode2;
        i--;
      } 
      fibonacciHeapNode.left.right = fibonacciHeapNode.right;
      fibonacciHeapNode.right.left = fibonacciHeapNode.left;
      if (fibonacciHeapNode == fibonacciHeapNode.right) {
        this.minNode = null;
      } else {
        this.minNode = fibonacciHeapNode.right;
        consolidate();
      } 
      this.nNodes--;
    } 
    return fibonacciHeapNode;
  }
  
  public int size() {
    return this.nNodes;
  }
  
  public static <T> FibonacciHeap<T> union(FibonacciHeap<T> paramFibonacciHeap1, FibonacciHeap<T> paramFibonacciHeap2) {
    FibonacciHeap<T> fibonacciHeap = new FibonacciHeap();
    if (paramFibonacciHeap1 != null && paramFibonacciHeap2 != null) {
      fibonacciHeap.minNode = paramFibonacciHeap1.minNode;
      if (fibonacciHeap.minNode != null) {
        if (paramFibonacciHeap2.minNode != null) {
          fibonacciHeap.minNode.right.left = paramFibonacciHeap2.minNode.left;
          paramFibonacciHeap2.minNode.left.right = fibonacciHeap.minNode.right;
          fibonacciHeap.minNode.right = paramFibonacciHeap2.minNode;
          paramFibonacciHeap2.minNode.left = fibonacciHeap.minNode;
          if (paramFibonacciHeap2.minNode.key < paramFibonacciHeap1.minNode.key)
            fibonacciHeap.minNode = paramFibonacciHeap2.minNode; 
        } 
      } else {
        fibonacciHeap.minNode = paramFibonacciHeap2.minNode;
      } 
      fibonacciHeap.nNodes = paramFibonacciHeap1.nNodes + paramFibonacciHeap2.nNodes;
    } 
    return fibonacciHeap;
  }
  
  public String toString() {
    if (this.minNode == null)
      return "FibonacciHeap=[]"; 
    Stack<FibonacciHeapNode<T>> stack = new Stack();
    stack.push(this.minNode);
    StringBuffer stringBuffer = new StringBuffer(512);
    stringBuffer.append("FibonacciHeap=[");
    while (!stack.empty()) {
      FibonacciHeapNode fibonacciHeapNode1 = stack.pop();
      stringBuffer.append(fibonacciHeapNode1);
      stringBuffer.append(", ");
      if (fibonacciHeapNode1.child != null)
        stack.push(fibonacciHeapNode1.child); 
      FibonacciHeapNode fibonacciHeapNode2 = fibonacciHeapNode1;
      for (fibonacciHeapNode1 = fibonacciHeapNode1.right; fibonacciHeapNode1 != fibonacciHeapNode2; fibonacciHeapNode1 = fibonacciHeapNode1.right) {
        stringBuffer.append(fibonacciHeapNode1);
        stringBuffer.append(", ");
        if (fibonacciHeapNode1.child != null)
          stack.push(fibonacciHeapNode1.child); 
      } 
    } 
    stringBuffer.append(']');
    return stringBuffer.toString();
  }
  
  protected void cascadingCut(FibonacciHeapNode<T> paramFibonacciHeapNode) {
    FibonacciHeapNode<T> fibonacciHeapNode = paramFibonacciHeapNode.parent;
    if (fibonacciHeapNode != null)
      if (!paramFibonacciHeapNode.mark) {
        paramFibonacciHeapNode.mark = true;
      } else {
        cut(paramFibonacciHeapNode, fibonacciHeapNode);
        cascadingCut(fibonacciHeapNode);
      }  
  }
  
  protected void consolidate() {
    int i = this.nNodes + 1;
    ArrayList<FibonacciHeapNode> arrayList = new ArrayList(i);
    byte b1;
    for (b1 = 0; b1 < i; b1++)
      arrayList.add(null); 
    b1 = 0;
    FibonacciHeapNode<T> fibonacciHeapNode = this.minNode;
    if (fibonacciHeapNode != null) {
      b1++;
      for (fibonacciHeapNode = fibonacciHeapNode.right; fibonacciHeapNode != this.minNode; fibonacciHeapNode = fibonacciHeapNode.right)
        b1++; 
    } 
    while (b1 > 0) {
      int j = fibonacciHeapNode.degree;
      FibonacciHeapNode<T> fibonacciHeapNode1 = fibonacciHeapNode.right;
      while (arrayList.get(j) != null) {
        FibonacciHeapNode<T> fibonacciHeapNode2 = arrayList.get(j);
        if (fibonacciHeapNode.key > fibonacciHeapNode2.key) {
          FibonacciHeapNode<T> fibonacciHeapNode3 = fibonacciHeapNode2;
          fibonacciHeapNode2 = fibonacciHeapNode;
          fibonacciHeapNode = fibonacciHeapNode3;
        } 
        link(fibonacciHeapNode2, fibonacciHeapNode);
        arrayList.set(j, null);
        j++;
      } 
      arrayList.set(j, fibonacciHeapNode);
      fibonacciHeapNode = fibonacciHeapNode1;
      b1--;
    } 
    this.minNode = null;
    for (byte b2 = 0; b2 < i; b2++) {
      if (arrayList.get(b2) != null)
        if (this.minNode != null) {
          ((FibonacciHeapNode)arrayList.get(b2)).left.right = ((FibonacciHeapNode)arrayList.get(b2)).right;
          ((FibonacciHeapNode)arrayList.get(b2)).right.left = ((FibonacciHeapNode)arrayList.get(b2)).left;
          ((FibonacciHeapNode)arrayList.get(b2)).left = this.minNode;
          ((FibonacciHeapNode)arrayList.get(b2)).right = this.minNode.right;
          this.minNode.right = arrayList.get(b2);
          ((FibonacciHeapNode)arrayList.get(b2)).right.left = arrayList.get(b2);
          if (((FibonacciHeapNode)arrayList.get(b2)).key < this.minNode.key)
            this.minNode = arrayList.get(b2); 
        } else {
          this.minNode = arrayList.get(b2);
        }  
    } 
  }
  
  protected void cut(FibonacciHeapNode<T> paramFibonacciHeapNode1, FibonacciHeapNode<T> paramFibonacciHeapNode2) {
    paramFibonacciHeapNode1.left.right = paramFibonacciHeapNode1.right;
    paramFibonacciHeapNode1.right.left = paramFibonacciHeapNode1.left;
    paramFibonacciHeapNode2.degree--;
    if (paramFibonacciHeapNode2.child == paramFibonacciHeapNode1)
      paramFibonacciHeapNode2.child = paramFibonacciHeapNode1.right; 
    if (paramFibonacciHeapNode2.degree == 0)
      paramFibonacciHeapNode2.child = null; 
    paramFibonacciHeapNode1.left = this.minNode;
    paramFibonacciHeapNode1.right = this.minNode.right;
    this.minNode.right = paramFibonacciHeapNode1;
    paramFibonacciHeapNode1.right.left = paramFibonacciHeapNode1;
    paramFibonacciHeapNode1.parent = null;
    paramFibonacciHeapNode1.mark = false;
  }
  
  protected void link(FibonacciHeapNode<T> paramFibonacciHeapNode1, FibonacciHeapNode<T> paramFibonacciHeapNode2) {
    paramFibonacciHeapNode1.left.right = paramFibonacciHeapNode1.right;
    paramFibonacciHeapNode1.right.left = paramFibonacciHeapNode1.left;
    paramFibonacciHeapNode1.parent = paramFibonacciHeapNode2;
    if (paramFibonacciHeapNode2.child == null) {
      paramFibonacciHeapNode2.child = paramFibonacciHeapNode1;
      paramFibonacciHeapNode1.right = paramFibonacciHeapNode1;
      paramFibonacciHeapNode1.left = paramFibonacciHeapNode1;
    } else {
      paramFibonacciHeapNode1.left = paramFibonacciHeapNode2.child;
      paramFibonacciHeapNode1.right = paramFibonacciHeapNode2.child.right;
      paramFibonacciHeapNode2.child.right = paramFibonacciHeapNode1;
      paramFibonacciHeapNode1.right.left = paramFibonacciHeapNode1;
    } 
    paramFibonacciHeapNode2.degree++;
    paramFibonacciHeapNode1.mark = false;
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/util/FibonacciHeap.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */