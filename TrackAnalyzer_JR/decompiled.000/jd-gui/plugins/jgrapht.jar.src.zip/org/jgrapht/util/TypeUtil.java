package org.jgrapht.util;

public class TypeUtil<T> {
  public static <T> T uncheckedCast(Object paramObject, TypeUtil<T> paramTypeUtil) {
    return (T)paramObject;
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/util/TypeUtil.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */