package org.jgrapht.util;

public class FibonacciHeapNode<T> {
  T data;
  
  FibonacciHeapNode<T> child;
  
  FibonacciHeapNode<T> left = this;
  
  FibonacciHeapNode<T> parent;
  
  FibonacciHeapNode<T> right = this;
  
  boolean mark;
  
  double key;
  
  int degree;
  
  public FibonacciHeapNode(T paramT, double paramDouble) {
    this.data = paramT;
    this.key = paramDouble;
  }
  
  public final double getKey() {
    return this.key;
  }
  
  public final T getData() {
    return this.data;
  }
  
  public String toString() {
    return Double.toString(this.key);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/util/FibonacciHeapNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */