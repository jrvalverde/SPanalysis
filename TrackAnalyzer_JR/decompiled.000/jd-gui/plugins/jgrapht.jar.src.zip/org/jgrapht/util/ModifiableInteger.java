package org.jgrapht.util;

public class ModifiableInteger extends Number implements Comparable {
  private static final long serialVersionUID = 3618698612851422261L;
  
  public int value;
  
  @Deprecated
  public ModifiableInteger() {}
  
  public ModifiableInteger(int paramInt) {
    this.value = paramInt;
  }
  
  public void setValue(int paramInt) {
    this.value = paramInt;
  }
  
  public int getValue() {
    return this.value;
  }
  
  public void increment() {
    this.value++;
  }
  
  public void decrement() {
    this.value--;
  }
  
  public int compareTo(ModifiableInteger paramModifiableInteger) {
    int i = this.value;
    int j = paramModifiableInteger.value;
    return (i < j) ? -1 : ((i == j) ? 0 : 1);
  }
  
  public int compareTo(Object paramObject) {
    return compareTo((ModifiableInteger)paramObject);
  }
  
  public double doubleValue() {
    return this.value;
  }
  
  public boolean equals(Object paramObject) {
    return (paramObject instanceof ModifiableInteger) ? ((this.value == ((ModifiableInteger)paramObject).value)) : false;
  }
  
  public float floatValue() {
    return this.value;
  }
  
  public int hashCode() {
    return this.value;
  }
  
  public int intValue() {
    return this.value;
  }
  
  public long longValue() {
    return this.value;
  }
  
  public Integer toInteger() {
    return Integer.valueOf(this.value);
  }
  
  public String toString() {
    return String.valueOf(this.value);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/util/ModifiableInteger.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */