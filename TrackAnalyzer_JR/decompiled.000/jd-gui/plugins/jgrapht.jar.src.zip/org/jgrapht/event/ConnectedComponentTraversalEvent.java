package org.jgrapht.event;

import java.util.EventObject;

public class ConnectedComponentTraversalEvent extends EventObject {
  private static final long serialVersionUID = 3834311717709822262L;
  
  public static final int CONNECTED_COMPONENT_STARTED = 31;
  
  public static final int CONNECTED_COMPONENT_FINISHED = 32;
  
  private int type;
  
  public ConnectedComponentTraversalEvent(Object paramObject, int paramInt) {
    super(paramObject);
    this.type = paramInt;
  }
  
  public int getType() {
    return this.type;
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/event/ConnectedComponentTraversalEvent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */