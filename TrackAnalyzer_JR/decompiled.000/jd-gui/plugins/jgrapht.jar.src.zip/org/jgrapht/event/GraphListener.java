package org.jgrapht.event;

public interface GraphListener<V, E> extends VertexSetListener<V> {
  void edgeAdded(GraphEdgeChangeEvent<V, E> paramGraphEdgeChangeEvent);
  
  void edgeRemoved(GraphEdgeChangeEvent<V, E> paramGraphEdgeChangeEvent);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/event/GraphListener.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */