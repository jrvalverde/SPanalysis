package org.jgrapht.event;

import java.util.EventObject;

public class EdgeTraversalEvent<V, E> extends EventObject {
  private static final long serialVersionUID = 4050768173789820979L;
  
  protected E edge;
  
  public EdgeTraversalEvent(Object paramObject, E paramE) {
    super(paramObject);
    this.edge = paramE;
  }
  
  public E getEdge() {
    return this.edge;
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/event/EdgeTraversalEvent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */