package org.jgrapht.event;

import java.util.EventListener;

public interface VertexSetListener<V> extends EventListener {
  void vertexAdded(GraphVertexChangeEvent<V> paramGraphVertexChangeEvent);
  
  void vertexRemoved(GraphVertexChangeEvent<V> paramGraphVertexChangeEvent);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/event/VertexSetListener.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */