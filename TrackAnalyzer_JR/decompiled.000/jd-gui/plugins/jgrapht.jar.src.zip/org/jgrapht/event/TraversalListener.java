package org.jgrapht.event;

public interface TraversalListener<V, E> {
  void connectedComponentFinished(ConnectedComponentTraversalEvent paramConnectedComponentTraversalEvent);
  
  void connectedComponentStarted(ConnectedComponentTraversalEvent paramConnectedComponentTraversalEvent);
  
  void edgeTraversed(EdgeTraversalEvent<V, E> paramEdgeTraversalEvent);
  
  void vertexTraversed(VertexTraversalEvent<V> paramVertexTraversalEvent);
  
  void vertexFinished(VertexTraversalEvent<V> paramVertexTraversalEvent);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/event/TraversalListener.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */