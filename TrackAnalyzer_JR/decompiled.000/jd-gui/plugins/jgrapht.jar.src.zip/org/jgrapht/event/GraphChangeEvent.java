package org.jgrapht.event;

import java.util.EventObject;

public class GraphChangeEvent extends EventObject {
  private static final long serialVersionUID = 3834592106026382391L;
  
  protected int type;
  
  public GraphChangeEvent(Object paramObject, int paramInt) {
    super(paramObject);
    this.type = paramInt;
  }
  
  public int getType() {
    return this.type;
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/event/GraphChangeEvent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */