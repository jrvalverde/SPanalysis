package org.jgrapht.event;

public class GraphEdgeChangeEvent<V, E> extends GraphChangeEvent {
  private static final long serialVersionUID = 3618134563335844662L;
  
  public static final int BEFORE_EDGE_ADDED = 21;
  
  public static final int BEFORE_EDGE_REMOVED = 22;
  
  public static final int EDGE_ADDED = 23;
  
  public static final int EDGE_REMOVED = 24;
  
  protected E edge;
  
  public GraphEdgeChangeEvent(Object paramObject, int paramInt, E paramE) {
    super(paramObject, paramInt);
    this.edge = paramE;
  }
  
  public E getEdge() {
    return this.edge;
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/event/GraphEdgeChangeEvent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */