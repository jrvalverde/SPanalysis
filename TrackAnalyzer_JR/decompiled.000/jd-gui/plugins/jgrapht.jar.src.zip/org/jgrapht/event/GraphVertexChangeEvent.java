package org.jgrapht.event;

public class GraphVertexChangeEvent<V> extends GraphChangeEvent {
  private static final long serialVersionUID = 3690189962679104053L;
  
  public static final int BEFORE_VERTEX_ADDED = 11;
  
  public static final int BEFORE_VERTEX_REMOVED = 12;
  
  public static final int VERTEX_ADDED = 13;
  
  public static final int VERTEX_REMOVED = 14;
  
  protected V vertex;
  
  public GraphVertexChangeEvent(Object paramObject, int paramInt, V paramV) {
    super(paramObject, paramInt);
    this.vertex = paramV;
  }
  
  public V getVertex() {
    return this.vertex;
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/event/GraphVertexChangeEvent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */