package org.jgrapht.event;

import java.util.EventObject;

public class VertexTraversalEvent<V> extends EventObject {
  private static final long serialVersionUID = 3688790267213918768L;
  
  protected V vertex;
  
  public VertexTraversalEvent(Object paramObject, V paramV) {
    super(paramObject);
    this.vertex = paramV;
  }
  
  public V getVertex() {
    return this.vertex;
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/event/VertexTraversalEvent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */