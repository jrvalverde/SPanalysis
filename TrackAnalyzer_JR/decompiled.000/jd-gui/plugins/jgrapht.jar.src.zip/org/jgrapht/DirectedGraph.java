package org.jgrapht;

import java.util.Set;

public interface DirectedGraph<V, E> extends Graph<V, E> {
  int inDegreeOf(V paramV);
  
  Set<E> incomingEdgesOf(V paramV);
  
  int outDegreeOf(V paramV);
  
  Set<E> outgoingEdgesOf(V paramV);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/DirectedGraph.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */