package org.jgrapht.graph;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import org.jgrapht.Graph;
import org.jgrapht.ListenableGraph;
import org.jgrapht.event.GraphEdgeChangeEvent;
import org.jgrapht.event.GraphListener;
import org.jgrapht.event.GraphVertexChangeEvent;
import org.jgrapht.event.VertexSetListener;
import org.jgrapht.util.TypeUtil;

public class DefaultListenableGraph<V, E> extends GraphDelegator<V, E> implements ListenableGraph<V, E>, Cloneable {
  private static final long serialVersionUID = 3977575900898471984L;
  
  private ArrayList<GraphListener<V, E>> graphListeners = new ArrayList<GraphListener<V, E>>();
  
  private ArrayList<VertexSetListener<V>> vertexSetListeners = new ArrayList<VertexSetListener<V>>();
  
  private FlyweightEdgeEvent<V, E> reuseableEdgeEvent;
  
  private FlyweightVertexEvent<V> reuseableVertexEvent;
  
  private boolean reuseEvents;
  
  public DefaultListenableGraph(Graph<V, E> paramGraph) {
    this(paramGraph, false);
  }
  
  public DefaultListenableGraph(Graph<V, E> paramGraph, boolean paramBoolean) {
    super(paramGraph);
    this.reuseEvents = paramBoolean;
    this.reuseableEdgeEvent = new FlyweightEdgeEvent<V, E>(this, -1, null);
    this.reuseableVertexEvent = new FlyweightVertexEvent<V>(this, -1, null);
    if (paramGraph instanceof ListenableGraph)
      throw new IllegalArgumentException("base graph cannot be listenable"); 
  }
  
  public void setReuseEvents(boolean paramBoolean) {
    this.reuseEvents = paramBoolean;
  }
  
  public boolean isReuseEvents() {
    return this.reuseEvents;
  }
  
  public E addEdge(V paramV1, V paramV2) {
    E e = super.addEdge(paramV1, paramV2);
    if (e != null)
      fireEdgeAdded(e); 
    return e;
  }
  
  public boolean addEdge(V paramV1, V paramV2, E paramE) {
    boolean bool = super.addEdge(paramV1, paramV2, paramE);
    if (bool)
      fireEdgeAdded(paramE); 
    return bool;
  }
  
  public void addGraphListener(GraphListener<V, E> paramGraphListener) {
    addToListenerList(this.graphListeners, paramGraphListener);
  }
  
  public boolean addVertex(V paramV) {
    boolean bool = super.addVertex(paramV);
    if (bool)
      fireVertexAdded(paramV); 
    return bool;
  }
  
  public void addVertexSetListener(VertexSetListener<V> paramVertexSetListener) {
    addToListenerList(this.vertexSetListeners, paramVertexSetListener);
  }
  
  public Object clone() {
    try {
      TypeUtil typeUtil = null;
      DefaultListenableGraph defaultListenableGraph = (DefaultListenableGraph)TypeUtil.uncheckedCast(super.clone(), typeUtil);
      defaultListenableGraph.graphListeners = new ArrayList<GraphListener<V, E>>();
      defaultListenableGraph.vertexSetListeners = new ArrayList<VertexSetListener<V>>();
      return defaultListenableGraph;
    } catch (CloneNotSupportedException cloneNotSupportedException) {
      cloneNotSupportedException.printStackTrace();
      throw new RuntimeException("internal error");
    } 
  }
  
  public E removeEdge(V paramV1, V paramV2) {
    E e = super.removeEdge(paramV1, paramV2);
    if (e != null)
      fireEdgeRemoved(e); 
    return e;
  }
  
  public boolean removeEdge(E paramE) {
    boolean bool = super.removeEdge(paramE);
    if (bool)
      fireEdgeRemoved(paramE); 
    return bool;
  }
  
  public void removeGraphListener(GraphListener<V, E> paramGraphListener) {
    this.graphListeners.remove(paramGraphListener);
  }
  
  public boolean removeVertex(V paramV) {
    if (containsVertex(paramV)) {
      Set<E> set = edgesOf(paramV);
      removeAllEdges(new ArrayList<E>(set));
      super.removeVertex(paramV);
      fireVertexRemoved(paramV);
      return true;
    } 
    return false;
  }
  
  public void removeVertexSetListener(VertexSetListener<V> paramVertexSetListener) {
    this.vertexSetListeners.remove(paramVertexSetListener);
  }
  
  protected void fireEdgeAdded(E paramE) {
    GraphEdgeChangeEvent<V, E> graphEdgeChangeEvent = createGraphEdgeChangeEvent(23, paramE);
    for (byte b = 0; b < this.graphListeners.size(); b++) {
      GraphListener graphListener = this.graphListeners.get(b);
      graphListener.edgeAdded(graphEdgeChangeEvent);
    } 
  }
  
  protected void fireEdgeRemoved(E paramE) {
    GraphEdgeChangeEvent<V, E> graphEdgeChangeEvent = createGraphEdgeChangeEvent(24, paramE);
    for (byte b = 0; b < this.graphListeners.size(); b++) {
      GraphListener graphListener = this.graphListeners.get(b);
      graphListener.edgeRemoved(graphEdgeChangeEvent);
    } 
  }
  
  protected void fireVertexAdded(V paramV) {
    GraphVertexChangeEvent<V> graphVertexChangeEvent = createGraphVertexChangeEvent(13, paramV);
    byte b;
    for (b = 0; b < this.vertexSetListeners.size(); b++) {
      VertexSetListener vertexSetListener = this.vertexSetListeners.get(b);
      vertexSetListener.vertexAdded(graphVertexChangeEvent);
    } 
    for (b = 0; b < this.graphListeners.size(); b++) {
      GraphListener graphListener = this.graphListeners.get(b);
      graphListener.vertexAdded(graphVertexChangeEvent);
    } 
  }
  
  protected void fireVertexRemoved(V paramV) {
    GraphVertexChangeEvent<V> graphVertexChangeEvent = createGraphVertexChangeEvent(14, paramV);
    byte b;
    for (b = 0; b < this.vertexSetListeners.size(); b++) {
      VertexSetListener vertexSetListener = this.vertexSetListeners.get(b);
      vertexSetListener.vertexRemoved(graphVertexChangeEvent);
    } 
    for (b = 0; b < this.graphListeners.size(); b++) {
      GraphListener graphListener = this.graphListeners.get(b);
      graphListener.vertexRemoved(graphVertexChangeEvent);
    } 
  }
  
  private static <L extends java.util.EventListener> void addToListenerList(List<L> paramList, L paramL) {
    if (!paramList.contains(paramL))
      paramList.add(paramL); 
  }
  
  private GraphEdgeChangeEvent<V, E> createGraphEdgeChangeEvent(int paramInt, E paramE) {
    if (this.reuseEvents) {
      this.reuseableEdgeEvent.setType(paramInt);
      this.reuseableEdgeEvent.setEdge(paramE);
      return this.reuseableEdgeEvent;
    } 
    return new GraphEdgeChangeEvent(this, paramInt, paramE);
  }
  
  private GraphVertexChangeEvent<V> createGraphVertexChangeEvent(int paramInt, V paramV) {
    if (this.reuseEvents) {
      this.reuseableVertexEvent.setType(paramInt);
      this.reuseableVertexEvent.setVertex(paramV);
      return this.reuseableVertexEvent;
    } 
    return new GraphVertexChangeEvent(this, paramInt, paramV);
  }
  
  private static class FlyweightVertexEvent<VV> extends GraphVertexChangeEvent<VV> {
    private static final long serialVersionUID = 3257848787857585716L;
    
    public FlyweightVertexEvent(Object param1Object, int param1Int, VV param1VV) {
      super(param1Object, param1Int, param1VV);
    }
    
    protected void setType(int param1Int) {
      this.type = param1Int;
    }
    
    protected void setVertex(VV param1VV) {
      this.vertex = param1VV;
    }
  }
  
  private static class FlyweightEdgeEvent<VV, EE> extends GraphEdgeChangeEvent<VV, EE> {
    private static final long serialVersionUID = 3907207152526636089L;
    
    public FlyweightEdgeEvent(Object param1Object, int param1Int, EE param1EE) {
      super(param1Object, param1Int, param1EE);
    }
    
    protected void setEdge(EE param1EE) {
      this.edge = param1EE;
    }
    
    protected void setType(int param1Int) {
      this.type = param1Int;
    }
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/graph/DefaultListenableGraph.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */