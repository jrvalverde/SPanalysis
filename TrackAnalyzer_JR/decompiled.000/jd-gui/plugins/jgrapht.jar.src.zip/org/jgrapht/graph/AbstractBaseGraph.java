package org.jgrapht.graph;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import org.jgrapht.EdgeFactory;
import org.jgrapht.Graph;
import org.jgrapht.Graphs;
import org.jgrapht.util.ArrayUnenforcedSet;
import org.jgrapht.util.TypeUtil;

public abstract class AbstractBaseGraph<V, E> extends AbstractGraph<V, E> implements Graph<V, E>, Cloneable, Serializable {
  private static final String LOOPS_NOT_ALLOWED = "loops not allowed";
  
  boolean allowingLoops;
  
  private EdgeFactory<V, E> edgeFactory;
  
  private EdgeSetFactory<V, E> edgeSetFactory;
  
  private Map<E, IntrusiveEdge> edgeMap;
  
  private transient Set<E> unmodifiableEdgeSet = null;
  
  private transient Set<V> unmodifiableVertexSet = null;
  
  private Specifics specifics;
  
  private boolean allowingMultipleEdges;
  
  private transient TypeUtil<V> vertexTypeDecl = null;
  
  public AbstractBaseGraph(EdgeFactory<V, E> paramEdgeFactory, boolean paramBoolean1, boolean paramBoolean2) {
    if (paramEdgeFactory == null)
      throw new NullPointerException(); 
    this.edgeMap = new LinkedHashMap<E, IntrusiveEdge>();
    this.edgeFactory = paramEdgeFactory;
    this.allowingLoops = paramBoolean2;
    this.allowingMultipleEdges = paramBoolean1;
    this.specifics = createSpecifics();
    this.edgeSetFactory = new ArrayListFactory<V, E>();
  }
  
  public Set<E> getAllEdges(V paramV1, V paramV2) {
    return this.specifics.getAllEdges(paramV1, paramV2);
  }
  
  public boolean isAllowingLoops() {
    return this.allowingLoops;
  }
  
  public boolean isAllowingMultipleEdges() {
    return this.allowingMultipleEdges;
  }
  
  public E getEdge(V paramV1, V paramV2) {
    return this.specifics.getEdge(paramV1, paramV2);
  }
  
  public EdgeFactory<V, E> getEdgeFactory() {
    return this.edgeFactory;
  }
  
  public void setEdgeSetFactory(EdgeSetFactory<V, E> paramEdgeSetFactory) {
    this.edgeSetFactory = paramEdgeSetFactory;
  }
  
  public E addEdge(V paramV1, V paramV2) {
    assertVertexExist(paramV1);
    assertVertexExist(paramV2);
    if (!this.allowingMultipleEdges && containsEdge(paramV1, paramV2))
      return null; 
    if (!this.allowingLoops && paramV1.equals(paramV2))
      throw new IllegalArgumentException("loops not allowed"); 
    Object object = this.edgeFactory.createEdge(paramV1, paramV2);
    if (containsEdge((E)object))
      return null; 
    IntrusiveEdge intrusiveEdge = createIntrusiveEdge((E)object, paramV1, paramV2);
    this.edgeMap.put((E)object, intrusiveEdge);
    this.specifics.addEdgeToTouchingVertices((E)object);
    return (E)object;
  }
  
  public boolean addEdge(V paramV1, V paramV2, E paramE) {
    if (paramE == null)
      throw new NullPointerException(); 
    if (containsEdge(paramE))
      return false; 
    assertVertexExist(paramV1);
    assertVertexExist(paramV2);
    if (!this.allowingMultipleEdges && containsEdge(paramV1, paramV2))
      return false; 
    if (!this.allowingLoops && paramV1.equals(paramV2))
      throw new IllegalArgumentException("loops not allowed"); 
    IntrusiveEdge intrusiveEdge = createIntrusiveEdge(paramE, paramV1, paramV2);
    this.edgeMap.put(paramE, intrusiveEdge);
    this.specifics.addEdgeToTouchingVertices(paramE);
    return true;
  }
  
  private IntrusiveEdge createIntrusiveEdge(E paramE, V paramV1, V paramV2) {
    IntrusiveEdge intrusiveEdge;
    if (paramE instanceof IntrusiveEdge) {
      intrusiveEdge = (IntrusiveEdge)paramE;
    } else {
      intrusiveEdge = new IntrusiveEdge();
    } 
    intrusiveEdge.source = paramV1;
    intrusiveEdge.target = paramV2;
    return intrusiveEdge;
  }
  
  public boolean addVertex(V paramV) {
    if (paramV == null)
      throw new NullPointerException(); 
    if (containsVertex(paramV))
      return false; 
    this.specifics.addVertex(paramV);
    return true;
  }
  
  public V getEdgeSource(E paramE) {
    return (V)TypeUtil.uncheckedCast((getIntrusiveEdge(paramE)).source, this.vertexTypeDecl);
  }
  
  public V getEdgeTarget(E paramE) {
    return (V)TypeUtil.uncheckedCast((getIntrusiveEdge(paramE)).target, this.vertexTypeDecl);
  }
  
  private IntrusiveEdge getIntrusiveEdge(E paramE) {
    return (paramE instanceof IntrusiveEdge) ? (IntrusiveEdge)paramE : this.edgeMap.get(paramE);
  }
  
  public Object clone() {
    try {
      TypeUtil typeUtil = null;
      AbstractBaseGraph abstractBaseGraph = (AbstractBaseGraph)TypeUtil.uncheckedCast(super.clone(), typeUtil);
      abstractBaseGraph.edgeMap = new LinkedHashMap<E, IntrusiveEdge>();
      abstractBaseGraph.edgeFactory = this.edgeFactory;
      abstractBaseGraph.unmodifiableEdgeSet = null;
      abstractBaseGraph.unmodifiableVertexSet = null;
      abstractBaseGraph.specifics = abstractBaseGraph.createSpecifics();
      Graphs.addGraph(abstractBaseGraph, this);
      return abstractBaseGraph;
    } catch (CloneNotSupportedException cloneNotSupportedException) {
      cloneNotSupportedException.printStackTrace();
      throw new RuntimeException();
    } 
  }
  
  public boolean containsEdge(E paramE) {
    return this.edgeMap.containsKey(paramE);
  }
  
  public boolean containsVertex(V paramV) {
    return this.specifics.getVertexSet().contains(paramV);
  }
  
  public int degreeOf(V paramV) {
    return this.specifics.degreeOf(paramV);
  }
  
  public Set<E> edgeSet() {
    if (this.unmodifiableEdgeSet == null)
      this.unmodifiableEdgeSet = Collections.unmodifiableSet(this.edgeMap.keySet()); 
    return this.unmodifiableEdgeSet;
  }
  
  public Set<E> edgesOf(V paramV) {
    return this.specifics.edgesOf(paramV);
  }
  
  public int inDegreeOf(V paramV) {
    return this.specifics.inDegreeOf(paramV);
  }
  
  public Set<E> incomingEdgesOf(V paramV) {
    return this.specifics.incomingEdgesOf(paramV);
  }
  
  public int outDegreeOf(V paramV) {
    return this.specifics.outDegreeOf(paramV);
  }
  
  public Set<E> outgoingEdgesOf(V paramV) {
    return this.specifics.outgoingEdgesOf(paramV);
  }
  
  public E removeEdge(V paramV1, V paramV2) {
    E e = getEdge(paramV1, paramV2);
    if (e != null) {
      this.specifics.removeEdgeFromTouchingVertices(e);
      this.edgeMap.remove(e);
    } 
    return e;
  }
  
  public boolean removeEdge(E paramE) {
    if (containsEdge(paramE)) {
      this.specifics.removeEdgeFromTouchingVertices(paramE);
      this.edgeMap.remove(paramE);
      return true;
    } 
    return false;
  }
  
  public boolean removeVertex(V paramV) {
    if (containsVertex(paramV)) {
      Set<E> set = edgesOf(paramV);
      removeAllEdges(new ArrayList<E>(set));
      this.specifics.getVertexSet().remove(paramV);
      return true;
    } 
    return false;
  }
  
  public Set<V> vertexSet() {
    if (this.unmodifiableVertexSet == null)
      this.unmodifiableVertexSet = Collections.unmodifiableSet(this.specifics.getVertexSet()); 
    return this.unmodifiableVertexSet;
  }
  
  public double getEdgeWeight(E paramE) {
    return (paramE instanceof DefaultWeightedEdge) ? ((DefaultWeightedEdge)paramE).weight : 1.0D;
  }
  
  public void setEdgeWeight(E paramE, double paramDouble) {
    assert paramE instanceof DefaultWeightedEdge : paramE.getClass();
    ((DefaultWeightedEdge)paramE).weight = paramDouble;
  }
  
  private Specifics createSpecifics() {
    if (this instanceof org.jgrapht.DirectedGraph)
      return new DirectedSpecifics(); 
    if (this instanceof org.jgrapht.UndirectedGraph)
      return new UndirectedSpecifics(); 
    throw new IllegalArgumentException("must be instance of either DirectedGraph or UndirectedGraph");
  }
  
  private class UndirectedSpecifics extends Specifics implements Serializable {
    private static final long serialVersionUID = 6494588405178655873L;
    
    private static final String NOT_IN_UNDIRECTED_GRAPH = "no such operation in an undirected graph";
    
    private Map<V, AbstractBaseGraph.UndirectedEdgeContainer<V, E>> vertexMapUndirected = new LinkedHashMap<V, AbstractBaseGraph.UndirectedEdgeContainer<V, E>>();
    
    private UndirectedSpecifics() {}
    
    public void addVertex(V param1V) {
      this.vertexMapUndirected.put(param1V, null);
    }
    
    public Set<V> getVertexSet() {
      return this.vertexMapUndirected.keySet();
    }
    
    public Set<E> getAllEdges(V param1V1, V param1V2) {
      // Byte code:
      //   0: aconst_null
      //   1: astore_3
      //   2: aload_0
      //   3: getfield this$0 : Lorg/jgrapht/graph/AbstractBaseGraph;
      //   6: aload_1
      //   7: invokevirtual containsVertex : (Ljava/lang/Object;)Z
      //   10: ifeq -> 166
      //   13: aload_0
      //   14: getfield this$0 : Lorg/jgrapht/graph/AbstractBaseGraph;
      //   17: aload_2
      //   18: invokevirtual containsVertex : (Ljava/lang/Object;)Z
      //   21: ifeq -> 166
      //   24: new org/jgrapht/util/ArrayUnenforcedSet
      //   27: dup
      //   28: invokespecial <init> : ()V
      //   31: astore_3
      //   32: aload_0
      //   33: aload_1
      //   34: invokespecial getEdgeContainer : (Ljava/lang/Object;)Lorg/jgrapht/graph/AbstractBaseGraph$UndirectedEdgeContainer;
      //   37: getfield vertexEdges : Ljava/util/Set;
      //   40: invokeinterface iterator : ()Ljava/util/Iterator;
      //   45: astore #4
      //   47: aload #4
      //   49: invokeinterface hasNext : ()Z
      //   54: ifeq -> 166
      //   57: aload #4
      //   59: invokeinterface next : ()Ljava/lang/Object;
      //   64: astore #5
      //   66: aload_1
      //   67: aload_0
      //   68: getfield this$0 : Lorg/jgrapht/graph/AbstractBaseGraph;
      //   71: aload #5
      //   73: invokevirtual getEdgeSource : (Ljava/lang/Object;)Ljava/lang/Object;
      //   76: invokevirtual equals : (Ljava/lang/Object;)Z
      //   79: ifeq -> 102
      //   82: aload_2
      //   83: aload_0
      //   84: getfield this$0 : Lorg/jgrapht/graph/AbstractBaseGraph;
      //   87: aload #5
      //   89: invokevirtual getEdgeTarget : (Ljava/lang/Object;)Ljava/lang/Object;
      //   92: invokevirtual equals : (Ljava/lang/Object;)Z
      //   95: ifeq -> 102
      //   98: iconst_1
      //   99: goto -> 103
      //   102: iconst_0
      //   103: istore #6
      //   105: aload_1
      //   106: aload_0
      //   107: getfield this$0 : Lorg/jgrapht/graph/AbstractBaseGraph;
      //   110: aload #5
      //   112: invokevirtual getEdgeTarget : (Ljava/lang/Object;)Ljava/lang/Object;
      //   115: invokevirtual equals : (Ljava/lang/Object;)Z
      //   118: ifeq -> 141
      //   121: aload_2
      //   122: aload_0
      //   123: getfield this$0 : Lorg/jgrapht/graph/AbstractBaseGraph;
      //   126: aload #5
      //   128: invokevirtual getEdgeSource : (Ljava/lang/Object;)Ljava/lang/Object;
      //   131: invokevirtual equals : (Ljava/lang/Object;)Z
      //   134: ifeq -> 141
      //   137: iconst_1
      //   138: goto -> 142
      //   141: iconst_0
      //   142: istore #7
      //   144: iload #6
      //   146: ifne -> 154
      //   149: iload #7
      //   151: ifeq -> 163
      //   154: aload_3
      //   155: aload #5
      //   157: invokeinterface add : (Ljava/lang/Object;)Z
      //   162: pop
      //   163: goto -> 47
      //   166: aload_3
      //   167: areturn
    }
    
    public E getEdge(V param1V1, V param1V2) {
      // Byte code:
      //   0: aload_0
      //   1: getfield this$0 : Lorg/jgrapht/graph/AbstractBaseGraph;
      //   4: aload_1
      //   5: invokevirtual containsVertex : (Ljava/lang/Object;)Z
      //   8: ifeq -> 147
      //   11: aload_0
      //   12: getfield this$0 : Lorg/jgrapht/graph/AbstractBaseGraph;
      //   15: aload_2
      //   16: invokevirtual containsVertex : (Ljava/lang/Object;)Z
      //   19: ifeq -> 147
      //   22: aload_0
      //   23: aload_1
      //   24: invokespecial getEdgeContainer : (Ljava/lang/Object;)Lorg/jgrapht/graph/AbstractBaseGraph$UndirectedEdgeContainer;
      //   27: getfield vertexEdges : Ljava/util/Set;
      //   30: invokeinterface iterator : ()Ljava/util/Iterator;
      //   35: astore_3
      //   36: aload_3
      //   37: invokeinterface hasNext : ()Z
      //   42: ifeq -> 147
      //   45: aload_3
      //   46: invokeinterface next : ()Ljava/lang/Object;
      //   51: astore #4
      //   53: aload_1
      //   54: aload_0
      //   55: getfield this$0 : Lorg/jgrapht/graph/AbstractBaseGraph;
      //   58: aload #4
      //   60: invokevirtual getEdgeSource : (Ljava/lang/Object;)Ljava/lang/Object;
      //   63: invokevirtual equals : (Ljava/lang/Object;)Z
      //   66: ifeq -> 89
      //   69: aload_2
      //   70: aload_0
      //   71: getfield this$0 : Lorg/jgrapht/graph/AbstractBaseGraph;
      //   74: aload #4
      //   76: invokevirtual getEdgeTarget : (Ljava/lang/Object;)Ljava/lang/Object;
      //   79: invokevirtual equals : (Ljava/lang/Object;)Z
      //   82: ifeq -> 89
      //   85: iconst_1
      //   86: goto -> 90
      //   89: iconst_0
      //   90: istore #5
      //   92: aload_1
      //   93: aload_0
      //   94: getfield this$0 : Lorg/jgrapht/graph/AbstractBaseGraph;
      //   97: aload #4
      //   99: invokevirtual getEdgeTarget : (Ljava/lang/Object;)Ljava/lang/Object;
      //   102: invokevirtual equals : (Ljava/lang/Object;)Z
      //   105: ifeq -> 128
      //   108: aload_2
      //   109: aload_0
      //   110: getfield this$0 : Lorg/jgrapht/graph/AbstractBaseGraph;
      //   113: aload #4
      //   115: invokevirtual getEdgeSource : (Ljava/lang/Object;)Ljava/lang/Object;
      //   118: invokevirtual equals : (Ljava/lang/Object;)Z
      //   121: ifeq -> 128
      //   124: iconst_1
      //   125: goto -> 129
      //   128: iconst_0
      //   129: istore #6
      //   131: iload #5
      //   133: ifne -> 141
      //   136: iload #6
      //   138: ifeq -> 144
      //   141: aload #4
      //   143: areturn
      //   144: goto -> 36
      //   147: aconst_null
      //   148: areturn
    }
    
    public void addEdgeToTouchingVertices(E param1E) {
      V v1 = (V)AbstractBaseGraph.this.getEdgeSource(param1E);
      V v2 = (V)AbstractBaseGraph.this.getEdgeTarget(param1E);
      getEdgeContainer(v1).addEdge(param1E);
      if (v1 != v2)
        getEdgeContainer(v2).addEdge(param1E); 
    }
    
    public int degreeOf(V param1V) {
      // Byte code:
      //   0: aload_0
      //   1: getfield this$0 : Lorg/jgrapht/graph/AbstractBaseGraph;
      //   4: getfield allowingLoops : Z
      //   7: ifeq -> 86
      //   10: iconst_0
      //   11: istore_2
      //   12: aload_0
      //   13: aload_1
      //   14: invokespecial getEdgeContainer : (Ljava/lang/Object;)Lorg/jgrapht/graph/AbstractBaseGraph$UndirectedEdgeContainer;
      //   17: getfield vertexEdges : Ljava/util/Set;
      //   20: astore_3
      //   21: aload_3
      //   22: invokeinterface iterator : ()Ljava/util/Iterator;
      //   27: astore #4
      //   29: aload #4
      //   31: invokeinterface hasNext : ()Z
      //   36: ifeq -> 84
      //   39: aload #4
      //   41: invokeinterface next : ()Ljava/lang/Object;
      //   46: astore #5
      //   48: aload_0
      //   49: getfield this$0 : Lorg/jgrapht/graph/AbstractBaseGraph;
      //   52: aload #5
      //   54: invokevirtual getEdgeSource : (Ljava/lang/Object;)Ljava/lang/Object;
      //   57: aload_0
      //   58: getfield this$0 : Lorg/jgrapht/graph/AbstractBaseGraph;
      //   61: aload #5
      //   63: invokevirtual getEdgeTarget : (Ljava/lang/Object;)Ljava/lang/Object;
      //   66: invokevirtual equals : (Ljava/lang/Object;)Z
      //   69: ifeq -> 78
      //   72: iinc #2, 2
      //   75: goto -> 81
      //   78: iinc #2, 1
      //   81: goto -> 29
      //   84: iload_2
      //   85: ireturn
      //   86: aload_0
      //   87: aload_1
      //   88: invokespecial getEdgeContainer : (Ljava/lang/Object;)Lorg/jgrapht/graph/AbstractBaseGraph$UndirectedEdgeContainer;
      //   91: invokevirtual edgeCount : ()I
      //   94: ireturn
    }
    
    public Set<E> edgesOf(V param1V) {
      return getEdgeContainer(param1V).getUnmodifiableVertexEdges();
    }
    
    public int inDegreeOf(V param1V) {
      throw new UnsupportedOperationException("no such operation in an undirected graph");
    }
    
    public Set<E> incomingEdgesOf(V param1V) {
      throw new UnsupportedOperationException("no such operation in an undirected graph");
    }
    
    public int outDegreeOf(V param1V) {
      throw new UnsupportedOperationException("no such operation in an undirected graph");
    }
    
    public Set<E> outgoingEdgesOf(V param1V) {
      throw new UnsupportedOperationException("no such operation in an undirected graph");
    }
    
    public void removeEdgeFromTouchingVertices(E param1E) {
      V v1 = (V)AbstractBaseGraph.this.getEdgeSource(param1E);
      V v2 = (V)AbstractBaseGraph.this.getEdgeTarget(param1E);
      getEdgeContainer(v1).removeEdge(param1E);
      if (v1 != v2)
        getEdgeContainer(v2).removeEdge(param1E); 
    }
    
    private AbstractBaseGraph.UndirectedEdgeContainer<V, E> getEdgeContainer(V param1V) {
      AbstractBaseGraph.this.assertVertexExist(param1V);
      AbstractBaseGraph.UndirectedEdgeContainer<V, Object> undirectedEdgeContainer = (AbstractBaseGraph.UndirectedEdgeContainer)this.vertexMapUndirected.get(param1V);
      if (undirectedEdgeContainer == null) {
        undirectedEdgeContainer = new AbstractBaseGraph.UndirectedEdgeContainer<V, Object>(AbstractBaseGraph.this.edgeSetFactory, param1V);
        this.vertexMapUndirected.put(param1V, undirectedEdgeContainer);
      } 
      return (AbstractBaseGraph.UndirectedEdgeContainer)undirectedEdgeContainer;
    }
  }
  
  private static class UndirectedEdgeContainer<VV, EE> implements Serializable {
    private static final long serialVersionUID = -6623207588411170010L;
    
    Set<EE> vertexEdges;
    
    private transient Set<EE> unmodifiableVertexEdges = null;
    
    UndirectedEdgeContainer(EdgeSetFactory<VV, EE> param1EdgeSetFactory, VV param1VV) {
      this.vertexEdges = param1EdgeSetFactory.createEdgeSet(param1VV);
    }
    
    public Set<EE> getUnmodifiableVertexEdges() {
      if (this.unmodifiableVertexEdges == null)
        this.unmodifiableVertexEdges = Collections.unmodifiableSet(this.vertexEdges); 
      return this.unmodifiableVertexEdges;
    }
    
    public void addEdge(EE param1EE) {
      this.vertexEdges.add(param1EE);
    }
    
    public int edgeCount() {
      return this.vertexEdges.size();
    }
    
    public void removeEdge(EE param1EE) {
      this.vertexEdges.remove(param1EE);
    }
  }
  
  private class DirectedSpecifics extends Specifics implements Serializable {
    private static final long serialVersionUID = 8971725103718958232L;
    
    private static final String NOT_IN_DIRECTED_GRAPH = "no such operation in a directed graph";
    
    private Map<V, AbstractBaseGraph.DirectedEdgeContainer<V, E>> vertexMapDirected = new LinkedHashMap<V, AbstractBaseGraph.DirectedEdgeContainer<V, E>>();
    
    private DirectedSpecifics() {}
    
    public void addVertex(V param1V) {
      this.vertexMapDirected.put(param1V, null);
    }
    
    public Set<V> getVertexSet() {
      return this.vertexMapDirected.keySet();
    }
    
    public Set<E> getAllEdges(V param1V1, V param1V2) {
      // Byte code:
      //   0: aconst_null
      //   1: astore_3
      //   2: aload_0
      //   3: getfield this$0 : Lorg/jgrapht/graph/AbstractBaseGraph;
      //   6: aload_1
      //   7: invokevirtual containsVertex : (Ljava/lang/Object;)Z
      //   10: ifeq -> 98
      //   13: aload_0
      //   14: getfield this$0 : Lorg/jgrapht/graph/AbstractBaseGraph;
      //   17: aload_2
      //   18: invokevirtual containsVertex : (Ljava/lang/Object;)Z
      //   21: ifeq -> 98
      //   24: new org/jgrapht/util/ArrayUnenforcedSet
      //   27: dup
      //   28: invokespecial <init> : ()V
      //   31: astore_3
      //   32: aload_0
      //   33: aload_1
      //   34: invokespecial getEdgeContainer : (Ljava/lang/Object;)Lorg/jgrapht/graph/AbstractBaseGraph$DirectedEdgeContainer;
      //   37: astore #4
      //   39: aload #4
      //   41: getfield outgoing : Ljava/util/Set;
      //   44: invokeinterface iterator : ()Ljava/util/Iterator;
      //   49: astore #5
      //   51: aload #5
      //   53: invokeinterface hasNext : ()Z
      //   58: ifeq -> 98
      //   61: aload #5
      //   63: invokeinterface next : ()Ljava/lang/Object;
      //   68: astore #6
      //   70: aload_0
      //   71: getfield this$0 : Lorg/jgrapht/graph/AbstractBaseGraph;
      //   74: aload #6
      //   76: invokevirtual getEdgeTarget : (Ljava/lang/Object;)Ljava/lang/Object;
      //   79: aload_2
      //   80: invokevirtual equals : (Ljava/lang/Object;)Z
      //   83: ifeq -> 95
      //   86: aload_3
      //   87: aload #6
      //   89: invokeinterface add : (Ljava/lang/Object;)Z
      //   94: pop
      //   95: goto -> 51
      //   98: aload_3
      //   99: areturn
    }
    
    public E getEdge(V param1V1, V param1V2) {
      // Byte code:
      //   0: aload_0
      //   1: getfield this$0 : Lorg/jgrapht/graph/AbstractBaseGraph;
      //   4: aload_1
      //   5: invokevirtual containsVertex : (Ljava/lang/Object;)Z
      //   8: ifeq -> 80
      //   11: aload_0
      //   12: getfield this$0 : Lorg/jgrapht/graph/AbstractBaseGraph;
      //   15: aload_2
      //   16: invokevirtual containsVertex : (Ljava/lang/Object;)Z
      //   19: ifeq -> 80
      //   22: aload_0
      //   23: aload_1
      //   24: invokespecial getEdgeContainer : (Ljava/lang/Object;)Lorg/jgrapht/graph/AbstractBaseGraph$DirectedEdgeContainer;
      //   27: astore_3
      //   28: aload_3
      //   29: getfield outgoing : Ljava/util/Set;
      //   32: invokeinterface iterator : ()Ljava/util/Iterator;
      //   37: astore #4
      //   39: aload #4
      //   41: invokeinterface hasNext : ()Z
      //   46: ifeq -> 80
      //   49: aload #4
      //   51: invokeinterface next : ()Ljava/lang/Object;
      //   56: astore #5
      //   58: aload_0
      //   59: getfield this$0 : Lorg/jgrapht/graph/AbstractBaseGraph;
      //   62: aload #5
      //   64: invokevirtual getEdgeTarget : (Ljava/lang/Object;)Ljava/lang/Object;
      //   67: aload_2
      //   68: invokevirtual equals : (Ljava/lang/Object;)Z
      //   71: ifeq -> 77
      //   74: aload #5
      //   76: areturn
      //   77: goto -> 39
      //   80: aconst_null
      //   81: areturn
    }
    
    public void addEdgeToTouchingVertices(E param1E) {
      V v1 = (V)AbstractBaseGraph.this.getEdgeSource(param1E);
      V v2 = (V)AbstractBaseGraph.this.getEdgeTarget(param1E);
      getEdgeContainer(v1).addOutgoingEdge(param1E);
      getEdgeContainer(v2).addIncomingEdge(param1E);
    }
    
    public int degreeOf(V param1V) {
      throw new UnsupportedOperationException("no such operation in a directed graph");
    }
    
    public Set<E> edgesOf(V param1V) {
      ArrayUnenforcedSet arrayUnenforcedSet = new ArrayUnenforcedSet((getEdgeContainer(param1V)).incoming);
      arrayUnenforcedSet.addAll((getEdgeContainer(param1V)).outgoing);
      if (AbstractBaseGraph.this.allowingLoops) {
        Set<E> set = getAllEdges(param1V, param1V);
        for (byte b = 0; b < arrayUnenforcedSet.size(); b++) {
          Object object = arrayUnenforcedSet.get(b);
          if (set.contains(object)) {
            arrayUnenforcedSet.remove(b);
            set.remove(object);
            continue;
          } 
        } 
      } 
      return Collections.unmodifiableSet((Set<? extends E>)arrayUnenforcedSet);
    }
    
    public int inDegreeOf(V param1V) {
      return (getEdgeContainer(param1V)).incoming.size();
    }
    
    public Set<E> incomingEdgesOf(V param1V) {
      return getEdgeContainer(param1V).getUnmodifiableIncomingEdges();
    }
    
    public int outDegreeOf(V param1V) {
      return (getEdgeContainer(param1V)).outgoing.size();
    }
    
    public Set<E> outgoingEdgesOf(V param1V) {
      return getEdgeContainer(param1V).getUnmodifiableOutgoingEdges();
    }
    
    public void removeEdgeFromTouchingVertices(E param1E) {
      V v1 = (V)AbstractBaseGraph.this.getEdgeSource(param1E);
      V v2 = (V)AbstractBaseGraph.this.getEdgeTarget(param1E);
      getEdgeContainer(v1).removeOutgoingEdge(param1E);
      getEdgeContainer(v2).removeIncomingEdge(param1E);
    }
    
    private AbstractBaseGraph.DirectedEdgeContainer<V, E> getEdgeContainer(V param1V) {
      AbstractBaseGraph.this.assertVertexExist(param1V);
      AbstractBaseGraph.DirectedEdgeContainer<V, Object> directedEdgeContainer = (AbstractBaseGraph.DirectedEdgeContainer)this.vertexMapDirected.get(param1V);
      if (directedEdgeContainer == null) {
        directedEdgeContainer = new AbstractBaseGraph.DirectedEdgeContainer<V, Object>(AbstractBaseGraph.this.edgeSetFactory, param1V);
        this.vertexMapDirected.put(param1V, directedEdgeContainer);
      } 
      return (AbstractBaseGraph.DirectedEdgeContainer)directedEdgeContainer;
    }
  }
  
  private static class DirectedEdgeContainer<VV, EE> implements Serializable {
    private static final long serialVersionUID = 7494242245729767106L;
    
    Set<EE> incoming;
    
    Set<EE> outgoing;
    
    private transient Set<EE> unmodifiableIncoming = null;
    
    private transient Set<EE> unmodifiableOutgoing = null;
    
    DirectedEdgeContainer(EdgeSetFactory<VV, EE> param1EdgeSetFactory, VV param1VV) {
      this.incoming = param1EdgeSetFactory.createEdgeSet(param1VV);
      this.outgoing = param1EdgeSetFactory.createEdgeSet(param1VV);
    }
    
    public Set<EE> getUnmodifiableIncomingEdges() {
      if (this.unmodifiableIncoming == null)
        this.unmodifiableIncoming = Collections.unmodifiableSet(this.incoming); 
      return this.unmodifiableIncoming;
    }
    
    public Set<EE> getUnmodifiableOutgoingEdges() {
      if (this.unmodifiableOutgoing == null)
        this.unmodifiableOutgoing = Collections.unmodifiableSet(this.outgoing); 
      return this.unmodifiableOutgoing;
    }
    
    public void addIncomingEdge(EE param1EE) {
      this.incoming.add(param1EE);
    }
    
    public void addOutgoingEdge(EE param1EE) {
      this.outgoing.add(param1EE);
    }
    
    public void removeIncomingEdge(EE param1EE) {
      this.incoming.remove(param1EE);
    }
    
    public void removeOutgoingEdge(EE param1EE) {
      this.outgoing.remove(param1EE);
    }
  }
  
  private static class ArrayListFactory<VV, EE> implements EdgeSetFactory<VV, EE>, Serializable {
    private static final long serialVersionUID = 5936902837403445985L;
    
    private ArrayListFactory() {}
    
    public Set<EE> createEdgeSet(VV param1VV) {
      return (Set<EE>)new ArrayUnenforcedSet(1);
    }
  }
  
  private abstract class Specifics implements Serializable {
    private Specifics() {}
    
    public abstract void addVertex(V param1V);
    
    public abstract Set<V> getVertexSet();
    
    public abstract Set<E> getAllEdges(V param1V1, V param1V2);
    
    public abstract E getEdge(V param1V1, V param1V2);
    
    public abstract void addEdgeToTouchingVertices(E param1E);
    
    public abstract int degreeOf(V param1V);
    
    public abstract Set<E> edgesOf(V param1V);
    
    public abstract int inDegreeOf(V param1V);
    
    public abstract Set<E> incomingEdgesOf(V param1V);
    
    public abstract int outDegreeOf(V param1V);
    
    public abstract Set<E> outgoingEdgesOf(V param1V);
    
    public abstract void removeEdgeFromTouchingVertices(E param1E);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/graph/AbstractBaseGraph.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */