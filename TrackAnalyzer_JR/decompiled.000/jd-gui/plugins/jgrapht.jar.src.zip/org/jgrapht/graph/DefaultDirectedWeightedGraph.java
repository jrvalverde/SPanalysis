package org.jgrapht.graph;

import org.jgrapht.EdgeFactory;
import org.jgrapht.WeightedGraph;

public class DefaultDirectedWeightedGraph<V, E> extends DefaultDirectedGraph<V, E> implements WeightedGraph<V, E> {
  private static final long serialVersionUID = 3761405317841171513L;
  
  public DefaultDirectedWeightedGraph(Class<? extends E> paramClass) {
    this(new ClassBasedEdgeFactory<V, E>(paramClass));
  }
  
  public DefaultDirectedWeightedGraph(EdgeFactory<V, E> paramEdgeFactory) {
    super(paramEdgeFactory);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/graph/DefaultDirectedWeightedGraph.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */