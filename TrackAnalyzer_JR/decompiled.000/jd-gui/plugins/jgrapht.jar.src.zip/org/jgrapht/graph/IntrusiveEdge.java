package org.jgrapht.graph;

import java.io.Serializable;

class IntrusiveEdge implements Cloneable, Serializable {
  private static final long serialVersionUID = 3258408452177932855L;
  
  Object source;
  
  Object target;
  
  public Object clone() {
    try {
      return super.clone();
    } catch (CloneNotSupportedException cloneNotSupportedException) {
      throw new InternalError();
    } 
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/graph/IntrusiveEdge.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */