package org.jgrapht.graph;

import java.util.Set;
import org.jgrapht.UndirectedGraph;

public class UndirectedSubgraph<V, E> extends Subgraph<V, E, UndirectedGraph<V, E>> implements UndirectedGraph<V, E> {
  private static final long serialVersionUID = 3256728359772631350L;
  
  public UndirectedSubgraph(UndirectedGraph<V, E> paramUndirectedGraph, Set<V> paramSet, Set<E> paramSet1) {
    super(paramUndirectedGraph, paramSet, paramSet1);
  }
  
  public int degreeOf(V paramV) {
    assertVertexExist(paramV);
    getBase().degreeOf(paramV);
    byte b = 0;
    for (E e : getBase().edgesOf(paramV)) {
      if (containsEdge(e)) {
        b++;
        if (getEdgeSource(e).equals(getEdgeTarget(e)))
          b++; 
      } 
    } 
    return b;
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/graph/UndirectedSubgraph.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */