package org.jgrapht.graph;

import org.jgrapht.DirectedGraph;
import org.jgrapht.Graph;

public class DirectedMaskSubgraph<V, E> extends MaskSubgraph<V, E> implements DirectedGraph<V, E> {
  public DirectedMaskSubgraph(DirectedGraph<V, E> paramDirectedGraph, MaskFunctor<V, E> paramMaskFunctor) {
    super((Graph<V, E>)paramDirectedGraph, paramMaskFunctor);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/graph/DirectedMaskSubgraph.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */