package org.jgrapht.graph;

import java.io.Serializable;
import java.util.Collection;
import java.util.Set;
import org.jgrapht.Graph;

public class UnmodifiableGraph<V, E> extends GraphDelegator<V, E> implements Serializable {
  private static final long serialVersionUID = 3544957670722713913L;
  
  private static final String UNMODIFIABLE = "this graph is unmodifiable";
  
  public UnmodifiableGraph(Graph<V, E> paramGraph) {
    super(paramGraph);
  }
  
  public E addEdge(V paramV1, V paramV2) {
    throw new UnsupportedOperationException("this graph is unmodifiable");
  }
  
  public boolean addEdge(V paramV1, V paramV2, E paramE) {
    throw new UnsupportedOperationException("this graph is unmodifiable");
  }
  
  public boolean addVertex(V paramV) {
    throw new UnsupportedOperationException("this graph is unmodifiable");
  }
  
  public boolean removeAllEdges(Collection<? extends E> paramCollection) {
    throw new UnsupportedOperationException("this graph is unmodifiable");
  }
  
  public Set<E> removeAllEdges(V paramV1, V paramV2) {
    throw new UnsupportedOperationException("this graph is unmodifiable");
  }
  
  public boolean removeAllVertices(Collection<? extends V> paramCollection) {
    throw new UnsupportedOperationException("this graph is unmodifiable");
  }
  
  public boolean removeEdge(E paramE) {
    throw new UnsupportedOperationException("this graph is unmodifiable");
  }
  
  public E removeEdge(V paramV1, V paramV2) {
    throw new UnsupportedOperationException("this graph is unmodifiable");
  }
  
  public boolean removeVertex(V paramV) {
    throw new UnsupportedOperationException("this graph is unmodifiable");
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/graph/UnmodifiableGraph.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */