package org.jgrapht.graph;

import java.util.Collection;
import java.util.Set;
import org.jgrapht.Graph;

public abstract class AbstractGraph<V, E> implements Graph<V, E> {
  public boolean containsEdge(V paramV1, V paramV2) {
    return (getEdge(paramV1, paramV2) != null);
  }
  
  public boolean removeAllEdges(Collection<? extends E> paramCollection) {
    // Byte code:
    //   0: iconst_0
    //   1: istore_2
    //   2: aload_1
    //   3: invokeinterface iterator : ()Ljava/util/Iterator;
    //   8: astore_3
    //   9: aload_3
    //   10: invokeinterface hasNext : ()Z
    //   15: ifeq -> 38
    //   18: aload_3
    //   19: invokeinterface next : ()Ljava/lang/Object;
    //   24: astore #4
    //   26: iload_2
    //   27: aload_0
    //   28: aload #4
    //   30: invokevirtual removeEdge : (Ljava/lang/Object;)Z
    //   33: ior
    //   34: istore_2
    //   35: goto -> 9
    //   38: iload_2
    //   39: ireturn
  }
  
  public Set<E> removeAllEdges(V paramV1, V paramV2) {
    Set<? extends E> set = getAllEdges(paramV1, paramV2);
    removeAllEdges(set);
    return (Set)set;
  }
  
  public boolean removeAllVertices(Collection<? extends V> paramCollection) {
    // Byte code:
    //   0: iconst_0
    //   1: istore_2
    //   2: aload_1
    //   3: invokeinterface iterator : ()Ljava/util/Iterator;
    //   8: astore_3
    //   9: aload_3
    //   10: invokeinterface hasNext : ()Z
    //   15: ifeq -> 38
    //   18: aload_3
    //   19: invokeinterface next : ()Ljava/lang/Object;
    //   24: astore #4
    //   26: iload_2
    //   27: aload_0
    //   28: aload #4
    //   30: invokevirtual removeVertex : (Ljava/lang/Object;)Z
    //   33: ior
    //   34: istore_2
    //   35: goto -> 9
    //   38: iload_2
    //   39: ireturn
  }
  
  public String toString() {
    return toStringFromSets(vertexSet(), edgeSet(), this instanceof org.jgrapht.DirectedGraph);
  }
  
  protected boolean assertVertexExist(V paramV) {
    if (containsVertex(paramV))
      return true; 
    if (paramV == null)
      throw new NullPointerException(); 
    throw new IllegalArgumentException("no such vertex in graph");
  }
  
  protected boolean removeAllEdges(E[] paramArrayOfE) {
    boolean bool = false;
    for (byte b = 0; b < paramArrayOfE.length; b++)
      bool |= removeEdge(paramArrayOfE[b]); 
    return bool;
  }
  
  protected String toStringFromSets(Collection<? extends V> paramCollection, Collection<? extends E> paramCollection1, boolean paramBoolean) {
    // Byte code:
    //   0: new java/util/ArrayList
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore #4
    //   9: new java/lang/StringBuffer
    //   12: dup
    //   13: invokespecial <init> : ()V
    //   16: astore #5
    //   18: aload_2
    //   19: invokeinterface iterator : ()Ljava/util/Iterator;
    //   24: astore #6
    //   26: aload #6
    //   28: invokeinterface hasNext : ()Z
    //   33: ifeq -> 186
    //   36: aload #6
    //   38: invokeinterface next : ()Ljava/lang/Object;
    //   43: astore #7
    //   45: aload #7
    //   47: invokevirtual getClass : ()Ljava/lang/Class;
    //   50: ldc_w org/jgrapht/graph/DefaultEdge
    //   53: if_acmpeq -> 86
    //   56: aload #7
    //   58: invokevirtual getClass : ()Ljava/lang/Class;
    //   61: ldc_w org/jgrapht/graph/DefaultWeightedEdge
    //   64: if_acmpeq -> 86
    //   67: aload #5
    //   69: aload #7
    //   71: invokevirtual toString : ()Ljava/lang/String;
    //   74: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   77: pop
    //   78: aload #5
    //   80: ldc '='
    //   82: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   85: pop
    //   86: iload_3
    //   87: ifeq -> 101
    //   90: aload #5
    //   92: ldc '('
    //   94: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   97: pop
    //   98: goto -> 109
    //   101: aload #5
    //   103: ldc '{'
    //   105: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   108: pop
    //   109: aload #5
    //   111: aload_0
    //   112: aload #7
    //   114: invokevirtual getEdgeSource : (Ljava/lang/Object;)Ljava/lang/Object;
    //   117: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuffer;
    //   120: pop
    //   121: aload #5
    //   123: ldc ','
    //   125: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   128: pop
    //   129: aload #5
    //   131: aload_0
    //   132: aload #7
    //   134: invokevirtual getEdgeTarget : (Ljava/lang/Object;)Ljava/lang/Object;
    //   137: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuffer;
    //   140: pop
    //   141: iload_3
    //   142: ifeq -> 156
    //   145: aload #5
    //   147: ldc ')'
    //   149: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   152: pop
    //   153: goto -> 164
    //   156: aload #5
    //   158: ldc '}'
    //   160: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   163: pop
    //   164: aload #4
    //   166: aload #5
    //   168: invokevirtual toString : ()Ljava/lang/String;
    //   171: invokeinterface add : (Ljava/lang/Object;)Z
    //   176: pop
    //   177: aload #5
    //   179: iconst_0
    //   180: invokevirtual setLength : (I)V
    //   183: goto -> 26
    //   186: new java/lang/StringBuilder
    //   189: dup
    //   190: invokespecial <init> : ()V
    //   193: ldc '('
    //   195: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   198: aload_1
    //   199: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   202: ldc ', '
    //   204: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   207: aload #4
    //   209: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   212: ldc ')'
    //   214: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   217: invokevirtual toString : ()Ljava/lang/String;
    //   220: areturn
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/graph/AbstractGraph.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */