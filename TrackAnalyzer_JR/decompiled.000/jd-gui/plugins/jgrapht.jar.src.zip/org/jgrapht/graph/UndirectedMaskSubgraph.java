package org.jgrapht.graph;

import org.jgrapht.Graph;
import org.jgrapht.UndirectedGraph;

public class UndirectedMaskSubgraph<V, E> extends MaskSubgraph<V, E> implements UndirectedGraph<V, E> {
  public UndirectedMaskSubgraph(UndirectedGraph<V, E> paramUndirectedGraph, MaskFunctor<V, E> paramMaskFunctor) {
    super((Graph<V, E>)paramUndirectedGraph, paramMaskFunctor);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/graph/UndirectedMaskSubgraph.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */