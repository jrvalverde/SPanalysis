package org.jgrapht.graph;

import java.io.Serializable;
import org.jgrapht.DirectedGraph;
import org.jgrapht.Graph;

public class AsUnweightedDirectedGraph<V, E> extends GraphDelegator<V, E> implements Serializable, DirectedGraph<V, E> {
  private static final long serialVersionUID = -4320818446777715312L;
  
  public AsUnweightedDirectedGraph(DirectedGraph<V, E> paramDirectedGraph) {
    super((Graph<V, E>)paramDirectedGraph);
  }
  
  public double getEdgeWeight(E paramE) {
    return 1.0D;
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/graph/AsUnweightedDirectedGraph.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */