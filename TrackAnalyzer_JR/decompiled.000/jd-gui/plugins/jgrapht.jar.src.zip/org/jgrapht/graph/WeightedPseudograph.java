package org.jgrapht.graph;

import org.jgrapht.EdgeFactory;
import org.jgrapht.WeightedGraph;

public class WeightedPseudograph<V, E> extends Pseudograph<V, E> implements WeightedGraph<V, E> {
  private static final long serialVersionUID = 3257290244524356152L;
  
  public WeightedPseudograph(EdgeFactory<V, E> paramEdgeFactory) {
    super(paramEdgeFactory);
  }
  
  public WeightedPseudograph(Class<? extends E> paramClass) {
    this(new ClassBasedEdgeFactory<V, E>(paramClass));
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/graph/WeightedPseudograph.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */