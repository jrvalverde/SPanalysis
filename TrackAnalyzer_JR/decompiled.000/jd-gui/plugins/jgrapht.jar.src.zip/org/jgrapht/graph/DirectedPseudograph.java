package org.jgrapht.graph;

import org.jgrapht.DirectedGraph;
import org.jgrapht.EdgeFactory;

public class DirectedPseudograph<V, E> extends AbstractBaseGraph<V, E> implements DirectedGraph<V, E> {
  private static final long serialVersionUID = -8300409752893486415L;
  
  public DirectedPseudograph(Class<? extends E> paramClass) {
    this(new ClassBasedEdgeFactory<V, E>(paramClass));
  }
  
  public DirectedPseudograph(EdgeFactory<V, E> paramEdgeFactory) {
    super(paramEdgeFactory, true, true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/graph/DirectedPseudograph.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */