package org.jgrapht.graph;

import java.util.Set;
import org.jgrapht.DirectedGraph;
import org.jgrapht.util.ArrayUnenforcedSet;

public class DirectedSubgraph<V, E> extends Subgraph<V, E, DirectedGraph<V, E>> implements DirectedGraph<V, E> {
  private static final long serialVersionUID = 3616445700507054133L;
  
  public DirectedSubgraph(DirectedGraph<V, E> paramDirectedGraph, Set<V> paramSet, Set<E> paramSet1) {
    super(paramDirectedGraph, paramSet, paramSet1);
  }
  
  public int inDegreeOf(V paramV) {
    assertVertexExist(paramV);
    byte b = 0;
    for (E e : getBase().incomingEdgesOf(paramV)) {
      if (containsEdge(e))
        b++; 
    } 
    return b;
  }
  
  public Set<E> incomingEdgesOf(V paramV) {
    assertVertexExist(paramV);
    ArrayUnenforcedSet<E> arrayUnenforcedSet = new ArrayUnenforcedSet();
    Set set = getBase().incomingEdgesOf(paramV);
    for (E e : set) {
      if (containsEdge(e))
        arrayUnenforcedSet.add(e); 
    } 
    return (Set<E>)arrayUnenforcedSet;
  }
  
  public int outDegreeOf(V paramV) {
    assertVertexExist(paramV);
    byte b = 0;
    for (E e : getBase().outgoingEdgesOf(paramV)) {
      if (containsEdge(e))
        b++; 
    } 
    return b;
  }
  
  public Set<E> outgoingEdgesOf(V paramV) {
    assertVertexExist(paramV);
    ArrayUnenforcedSet<E> arrayUnenforcedSet = new ArrayUnenforcedSet();
    Set set = getBase().outgoingEdgesOf(paramV);
    for (E e : set) {
      if (containsEdge(e))
        arrayUnenforcedSet.add(e); 
    } 
    return (Set<E>)arrayUnenforcedSet;
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/graph/DirectedSubgraph.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */