package org.jgrapht.graph;

import org.jgrapht.DirectedGraph;
import org.jgrapht.WeightedGraph;

public class ListenableDirectedWeightedGraph<V, E> extends ListenableDirectedGraph<V, E> implements WeightedGraph<V, E> {
  private static final long serialVersionUID = 3977582476627621938L;
  
  public ListenableDirectedWeightedGraph(Class<? extends E> paramClass) {
    this(new DefaultDirectedWeightedGraph<V, E>(paramClass));
  }
  
  public ListenableDirectedWeightedGraph(WeightedGraph<V, E> paramWeightedGraph) {
    super((DirectedGraph<V, E>)paramWeightedGraph);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/graph/ListenableDirectedWeightedGraph.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */