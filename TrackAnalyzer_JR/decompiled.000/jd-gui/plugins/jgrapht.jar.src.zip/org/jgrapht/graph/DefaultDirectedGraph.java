package org.jgrapht.graph;

import org.jgrapht.DirectedGraph;
import org.jgrapht.EdgeFactory;

public class DefaultDirectedGraph<V, E> extends AbstractBaseGraph<V, E> implements DirectedGraph<V, E> {
  private static final long serialVersionUID = 3544953246956466230L;
  
  public DefaultDirectedGraph(Class<? extends E> paramClass) {
    this(new ClassBasedEdgeFactory<V, E>(paramClass));
  }
  
  public DefaultDirectedGraph(EdgeFactory<V, E> paramEdgeFactory) {
    super(paramEdgeFactory, false, true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/graph/DefaultDirectedGraph.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */