package org.jgrapht.graph;

import org.jgrapht.DirectedGraph;
import org.jgrapht.Graph;

public class UnmodifiableDirectedGraph<V, E> extends UnmodifiableGraph<V, E> implements DirectedGraph<V, E> {
  private static final long serialVersionUID = 3978701783725913906L;
  
  public UnmodifiableDirectedGraph(DirectedGraph<V, E> paramDirectedGraph) {
    super((Graph<V, E>)paramDirectedGraph);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/graph/UnmodifiableDirectedGraph.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */