package org.jgrapht.graph;

import java.io.Serializable;
import java.util.Map;
import org.jgrapht.Graph;
import org.jgrapht.WeightedGraph;

public class AsWeightedGraph<V, E> extends GraphDelegator<V, E> implements Serializable, WeightedGraph<V, E> {
  private static final long serialVersionUID = -716810639338971372L;
  
  protected final Map<E, Double> weightMap;
  
  private final boolean isWeightedGraph;
  
  public AsWeightedGraph(Graph<V, E> paramGraph, Map<E, Double> paramMap) {
    super(paramGraph);
    assert paramMap != null;
    this.weightMap = paramMap;
    this.isWeightedGraph = paramGraph instanceof WeightedGraph;
  }
  
  public void setEdgeWeight(E paramE, double paramDouble) {
    if (this.isWeightedGraph)
      super.setEdgeWeight(paramE, paramDouble); 
    this.weightMap.put(paramE, Double.valueOf(paramDouble));
  }
  
  public double getEdgeWeight(E paramE) {
    double d;
    if (this.weightMap.containsKey(paramE)) {
      d = ((Double)this.weightMap.get(paramE)).doubleValue();
    } else {
      d = super.getEdgeWeight(paramE);
    } 
    return d;
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/graph/AsWeightedGraph.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */