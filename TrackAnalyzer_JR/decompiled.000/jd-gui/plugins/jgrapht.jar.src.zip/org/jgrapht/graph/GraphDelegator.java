package org.jgrapht.graph;

import java.io.Serializable;
import java.util.Set;
import org.jgrapht.DirectedGraph;
import org.jgrapht.EdgeFactory;
import org.jgrapht.Graph;
import org.jgrapht.UndirectedGraph;
import org.jgrapht.WeightedGraph;

public class GraphDelegator<V, E> extends AbstractGraph<V, E> implements Graph<V, E>, Serializable {
  private static final long serialVersionUID = 3257005445226181425L;
  
  private Graph<V, E> delegate;
  
  public GraphDelegator(Graph<V, E> paramGraph) {
    if (paramGraph == null)
      throw new IllegalArgumentException("g must not be null."); 
    this.delegate = paramGraph;
  }
  
  public Set<E> getAllEdges(V paramV1, V paramV2) {
    return this.delegate.getAllEdges(paramV1, paramV2);
  }
  
  public E getEdge(V paramV1, V paramV2) {
    return (E)this.delegate.getEdge(paramV1, paramV2);
  }
  
  public EdgeFactory<V, E> getEdgeFactory() {
    return this.delegate.getEdgeFactory();
  }
  
  public E addEdge(V paramV1, V paramV2) {
    return (E)this.delegate.addEdge(paramV1, paramV2);
  }
  
  public boolean addEdge(V paramV1, V paramV2, E paramE) {
    return this.delegate.addEdge(paramV1, paramV2, paramE);
  }
  
  public boolean addVertex(V paramV) {
    return this.delegate.addVertex(paramV);
  }
  
  public boolean containsEdge(E paramE) {
    return this.delegate.containsEdge(paramE);
  }
  
  public boolean containsVertex(V paramV) {
    return this.delegate.containsVertex(paramV);
  }
  
  public int degreeOf(V paramV) {
    return ((UndirectedGraph)this.delegate).degreeOf(paramV);
  }
  
  public Set<E> edgeSet() {
    return this.delegate.edgeSet();
  }
  
  public Set<E> edgesOf(V paramV) {
    return this.delegate.edgesOf(paramV);
  }
  
  public int inDegreeOf(V paramV) {
    return ((DirectedGraph)this.delegate).inDegreeOf(paramV);
  }
  
  public Set<E> incomingEdgesOf(V paramV) {
    return ((DirectedGraph)this.delegate).incomingEdgesOf(paramV);
  }
  
  public int outDegreeOf(V paramV) {
    return ((DirectedGraph)this.delegate).outDegreeOf(paramV);
  }
  
  public Set<E> outgoingEdgesOf(V paramV) {
    return ((DirectedGraph)this.delegate).outgoingEdgesOf(paramV);
  }
  
  public boolean removeEdge(E paramE) {
    return this.delegate.removeEdge(paramE);
  }
  
  public E removeEdge(V paramV1, V paramV2) {
    return (E)this.delegate.removeEdge(paramV1, paramV2);
  }
  
  public boolean removeVertex(V paramV) {
    return this.delegate.removeVertex(paramV);
  }
  
  public String toString() {
    return this.delegate.toString();
  }
  
  public Set<V> vertexSet() {
    return this.delegate.vertexSet();
  }
  
  public V getEdgeSource(E paramE) {
    return (V)this.delegate.getEdgeSource(paramE);
  }
  
  public V getEdgeTarget(E paramE) {
    return (V)this.delegate.getEdgeTarget(paramE);
  }
  
  public double getEdgeWeight(E paramE) {
    return this.delegate.getEdgeWeight(paramE);
  }
  
  public void setEdgeWeight(E paramE, double paramDouble) {
    ((WeightedGraph)this.delegate).setEdgeWeight(paramE, paramDouble);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/graph/GraphDelegator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */