package org.jgrapht.graph;

import java.io.Serializable;
import java.util.Set;
import org.jgrapht.DirectedGraph;
import org.jgrapht.Graph;
import org.jgrapht.UndirectedGraph;
import org.jgrapht.util.ArrayUnenforcedSet;

public class AsUndirectedGraph<V, E> extends GraphDelegator<V, E> implements Serializable, UndirectedGraph<V, E> {
  private static final long serialVersionUID = 3257845485078065462L;
  
  private static final String NO_EDGE_ADD = "this graph does not support edge addition";
  
  private static final String UNDIRECTED = "this graph only supports undirected operations";
  
  public AsUndirectedGraph(DirectedGraph<V, E> paramDirectedGraph) {
    super((Graph<V, E>)paramDirectedGraph);
  }
  
  public Set<E> getAllEdges(V paramV1, V paramV2) {
    Set<E> set1 = super.getAllEdges(paramV1, paramV2);
    if (paramV1.equals(paramV2))
      return set1; 
    Set<E> set2 = super.getAllEdges(paramV2, paramV1);
    ArrayUnenforcedSet<E> arrayUnenforcedSet = new ArrayUnenforcedSet(set1.size() + set2.size());
    arrayUnenforcedSet.addAll(set1);
    arrayUnenforcedSet.addAll(set2);
    return (Set<E>)arrayUnenforcedSet;
  }
  
  public E getEdge(V paramV1, V paramV2) {
    E e = super.getEdge(paramV1, paramV2);
    return (e != null) ? e : super.getEdge(paramV2, paramV1);
  }
  
  public E addEdge(V paramV1, V paramV2) {
    throw new UnsupportedOperationException("this graph does not support edge addition");
  }
  
  public boolean addEdge(V paramV1, V paramV2, E paramE) {
    throw new UnsupportedOperationException("this graph does not support edge addition");
  }
  
  public int degreeOf(V paramV) {
    return super.inDegreeOf(paramV) + super.outDegreeOf(paramV);
  }
  
  public int inDegreeOf(V paramV) {
    throw new UnsupportedOperationException("this graph only supports undirected operations");
  }
  
  public Set<E> incomingEdgesOf(V paramV) {
    throw new UnsupportedOperationException("this graph only supports undirected operations");
  }
  
  public int outDegreeOf(V paramV) {
    throw new UnsupportedOperationException("this graph only supports undirected operations");
  }
  
  public Set<E> outgoingEdgesOf(V paramV) {
    throw new UnsupportedOperationException("this graph only supports undirected operations");
  }
  
  public String toString() {
    return toStringFromSets(vertexSet(), edgeSet(), false);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/graph/AsUndirectedGraph.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */