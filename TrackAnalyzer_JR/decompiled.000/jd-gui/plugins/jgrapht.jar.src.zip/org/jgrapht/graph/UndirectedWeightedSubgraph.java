package org.jgrapht.graph;

import java.util.Set;
import org.jgrapht.UndirectedGraph;
import org.jgrapht.WeightedGraph;

public class UndirectedWeightedSubgraph<V, E> extends UndirectedSubgraph<V, E> implements WeightedGraph<V, E> {
  private static final long serialVersionUID = 3689346615735236409L;
  
  public UndirectedWeightedSubgraph(WeightedGraph<V, E> paramWeightedGraph, Set<V> paramSet, Set<E> paramSet1) {
    super((UndirectedGraph<V, E>)paramWeightedGraph, paramSet, paramSet1);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/graph/UndirectedWeightedSubgraph.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */