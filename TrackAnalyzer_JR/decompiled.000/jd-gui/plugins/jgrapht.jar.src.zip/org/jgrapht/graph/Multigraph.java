package org.jgrapht.graph;

import org.jgrapht.EdgeFactory;
import org.jgrapht.UndirectedGraph;

public class Multigraph<V, E> extends AbstractBaseGraph<V, E> implements UndirectedGraph<V, E> {
  private static final long serialVersionUID = 3257001055819871795L;
  
  public Multigraph(Class<? extends E> paramClass) {
    this(new ClassBasedEdgeFactory<V, E>(paramClass));
  }
  
  public Multigraph(EdgeFactory<V, E> paramEdgeFactory) {
    super(paramEdgeFactory, true, false);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/graph/Multigraph.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */