package org.jgrapht.graph;

import java.util.Set;
import org.jgrapht.Graph;

public class ParanoidGraph<V, E> extends GraphDelegator<V, E> {
  private static final long serialVersionUID = 5075284167422166539L;
  
  public ParanoidGraph(Graph<V, E> paramGraph) {
    super(paramGraph);
  }
  
  public boolean addEdge(V paramV1, V paramV2, E paramE) {
    verifyAdd(edgeSet(), paramE);
    return super.addEdge(paramV1, paramV2, paramE);
  }
  
  public boolean addVertex(V paramV) {
    verifyAdd(vertexSet(), paramV);
    return super.addVertex(paramV);
  }
  
  private static <T> void verifyAdd(Set<T> paramSet, T paramT) {
    // Byte code:
    //   0: aload_0
    //   1: invokeinterface iterator : ()Ljava/util/Iterator;
    //   6: astore_2
    //   7: aload_2
    //   8: invokeinterface hasNext : ()Z
    //   13: ifeq -> 105
    //   16: aload_2
    //   17: invokeinterface next : ()Ljava/lang/Object;
    //   22: astore_3
    //   23: aload_3
    //   24: aload_1
    //   25: if_acmpne -> 31
    //   28: goto -> 7
    //   31: aload_3
    //   32: aload_1
    //   33: invokevirtual equals : (Ljava/lang/Object;)Z
    //   36: ifeq -> 102
    //   39: aload_3
    //   40: invokevirtual hashCode : ()I
    //   43: aload_1
    //   44: invokevirtual hashCode : ()I
    //   47: if_icmpeq -> 102
    //   50: new java/lang/IllegalArgumentException
    //   53: dup
    //   54: new java/lang/StringBuilder
    //   57: dup
    //   58: invokespecial <init> : ()V
    //   61: ldc 'ParanoidGraph detected objects o1 (hashCode='
    //   63: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   66: aload_3
    //   67: invokevirtual hashCode : ()I
    //   70: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   73: ldc ') and o2 (hashCode='
    //   75: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   78: aload_1
    //   79: invokevirtual hashCode : ()I
    //   82: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   85: ldc ') where o1.equals(o2) '
    //   87: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   90: ldc 'but o1.hashCode() != o2.hashCode()'
    //   92: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   95: invokevirtual toString : ()Ljava/lang/String;
    //   98: invokespecial <init> : (Ljava/lang/String;)V
    //   101: athrow
    //   102: goto -> 7
    //   105: return
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/graph/ParanoidGraph.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */