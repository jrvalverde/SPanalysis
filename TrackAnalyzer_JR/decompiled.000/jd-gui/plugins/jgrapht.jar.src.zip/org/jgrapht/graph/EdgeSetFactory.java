package org.jgrapht.graph;

import java.util.Set;

public interface EdgeSetFactory<V, E> {
  Set<E> createEdgeSet(V paramV);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/graph/EdgeSetFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */