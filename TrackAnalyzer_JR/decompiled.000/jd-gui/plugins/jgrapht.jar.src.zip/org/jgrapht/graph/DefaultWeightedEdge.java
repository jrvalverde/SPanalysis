package org.jgrapht.graph;

public class DefaultWeightedEdge extends DefaultEdge {
  private static final long serialVersionUID = 229708706467350994L;
  
  double weight = 1.0D;
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/graph/DefaultWeightedEdge.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */