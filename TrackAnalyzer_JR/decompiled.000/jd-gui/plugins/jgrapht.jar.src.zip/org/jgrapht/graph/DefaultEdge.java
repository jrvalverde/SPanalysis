package org.jgrapht.graph;

public class DefaultEdge extends IntrusiveEdge {
  private static final long serialVersionUID = 3258408452177932855L;
  
  public String toString() {
    return "(" + this.source + " : " + this.target + ")";
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/graph/DefaultEdge.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */