package org.jgrapht.graph;

import java.io.Serializable;
import org.jgrapht.Graph;

public class AsUnweightedGraph<V, E> extends GraphDelegator<V, E> implements Serializable {
  private static final long serialVersionUID = 7175505077601824663L;
  
  public AsUnweightedGraph(Graph<V, E> paramGraph) {
    super(paramGraph);
  }
  
  public double getEdgeWeight(E paramE) {
    return 1.0D;
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/graph/AsUnweightedGraph.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */