package org.jgrapht.graph;

import java.io.Serializable;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Set;
import org.jgrapht.EdgeFactory;
import org.jgrapht.Graph;
import org.jgrapht.ListenableGraph;
import org.jgrapht.WeightedGraph;
import org.jgrapht.event.GraphEdgeChangeEvent;
import org.jgrapht.event.GraphListener;
import org.jgrapht.event.GraphVertexChangeEvent;
import org.jgrapht.util.ArrayUnenforcedSet;

public class Subgraph<V, E, G extends Graph<V, E>> extends AbstractGraph<V, E> implements Serializable {
  private static final long serialVersionUID = 3208313055169665387L;
  
  private static final String NO_SUCH_EDGE_IN_BASE = "no such edge in base graph";
  
  private static final String NO_SUCH_VERTEX_IN_BASE = "no such vertex in base graph";
  
  Set<E> edgeSet = new LinkedHashSet<E>();
  
  Set<V> vertexSet = new LinkedHashSet<V>();
  
  private transient Set<E> unmodifiableEdgeSet = null;
  
  private transient Set<V> unmodifiableVertexSet = null;
  
  private G base;
  
  private boolean isInduced = false;
  
  public Subgraph(G paramG, Set<V> paramSet, Set<E> paramSet1) {
    this.base = paramG;
    if (paramSet1 == null)
      this.isInduced = true; 
    if (paramG instanceof ListenableGraph)
      ((ListenableGraph)paramG).addGraphListener(new BaseGraphListener()); 
    addVerticesUsingFilter(paramG.vertexSet(), paramSet);
    addEdgesUsingFilter(paramG.edgeSet(), paramSet1);
  }
  
  public Subgraph(G paramG, Set<V> paramSet) {
    this(paramG, paramSet, (Set<E>)null);
  }
  
  public Set<E> getAllEdges(V paramV1, V paramV2) {
    ArrayUnenforcedSet arrayUnenforcedSet = null;
    if (containsVertex(paramV1) && containsVertex(paramV2)) {
      arrayUnenforcedSet = new ArrayUnenforcedSet();
      Set set = this.base.getAllEdges(paramV1, paramV2);
      for (Object object : set) {
        if (this.edgeSet.contains(object))
          arrayUnenforcedSet.add(object); 
      } 
    } 
    return (Set<E>)arrayUnenforcedSet;
  }
  
  public E getEdge(V paramV1, V paramV2) {
    Set<E> set = getAllEdges(paramV1, paramV2);
    return (set == null || set.isEmpty()) ? null : set.iterator().next();
  }
  
  public EdgeFactory<V, E> getEdgeFactory() {
    return this.base.getEdgeFactory();
  }
  
  public E addEdge(V paramV1, V paramV2) {
    assertVertexExist(paramV1);
    assertVertexExist(paramV2);
    if (!this.base.containsEdge(paramV1, paramV2))
      throw new IllegalArgumentException("no such edge in base graph"); 
    Set set = this.base.getAllEdges(paramV1, paramV2);
    for (E e : set) {
      if (!containsEdge(e)) {
        this.edgeSet.add(e);
        return e;
      } 
    } 
    return null;
  }
  
  public boolean addEdge(V paramV1, V paramV2, E paramE) {
    if (paramE == null)
      throw new NullPointerException(); 
    if (!this.base.containsEdge(paramE))
      throw new IllegalArgumentException("no such edge in base graph"); 
    assertVertexExist(paramV1);
    assertVertexExist(paramV2);
    assert this.base.getEdgeSource(paramE) == paramV1;
    assert this.base.getEdgeTarget(paramE) == paramV2;
    if (containsEdge(paramE))
      return false; 
    this.edgeSet.add(paramE);
    return true;
  }
  
  public boolean addVertex(V paramV) {
    if (paramV == null)
      throw new NullPointerException(); 
    if (!this.base.containsVertex(paramV))
      throw new IllegalArgumentException("no such vertex in base graph"); 
    if (containsVertex(paramV))
      return false; 
    this.vertexSet.add(paramV);
    return true;
  }
  
  public boolean containsEdge(E paramE) {
    return this.edgeSet.contains(paramE);
  }
  
  public boolean containsVertex(V paramV) {
    return this.vertexSet.contains(paramV);
  }
  
  public Set<E> edgeSet() {
    if (this.unmodifiableEdgeSet == null)
      this.unmodifiableEdgeSet = Collections.unmodifiableSet(this.edgeSet); 
    return this.unmodifiableEdgeSet;
  }
  
  public Set<E> edgesOf(V paramV) {
    assertVertexExist(paramV);
    ArrayUnenforcedSet<E> arrayUnenforcedSet = new ArrayUnenforcedSet();
    Set set = this.base.edgesOf(paramV);
    for (E e : set) {
      if (containsEdge(e))
        arrayUnenforcedSet.add(e); 
    } 
    return (Set<E>)arrayUnenforcedSet;
  }
  
  public boolean removeEdge(E paramE) {
    return this.edgeSet.remove(paramE);
  }
  
  public E removeEdge(V paramV1, V paramV2) {
    E e = getEdge(paramV1, paramV2);
    return this.edgeSet.remove(e) ? e : null;
  }
  
  public boolean removeVertex(V paramV) {
    if (containsVertex(paramV) && this.base.containsVertex(paramV))
      removeAllEdges(edgesOf(paramV)); 
    return this.vertexSet.remove(paramV);
  }
  
  public Set<V> vertexSet() {
    if (this.unmodifiableVertexSet == null)
      this.unmodifiableVertexSet = Collections.unmodifiableSet(this.vertexSet); 
    return this.unmodifiableVertexSet;
  }
  
  public V getEdgeSource(E paramE) {
    return (V)this.base.getEdgeSource(paramE);
  }
  
  public V getEdgeTarget(E paramE) {
    return (V)this.base.getEdgeTarget(paramE);
  }
  
  private void addEdgesUsingFilter(Set<E> paramSet1, Set<E> paramSet2) {
    // Byte code:
    //   0: aload_1
    //   1: invokeinterface iterator : ()Ljava/util/Iterator;
    //   6: astore #6
    //   8: aload #6
    //   10: invokeinterface hasNext : ()Z
    //   15: ifeq -> 119
    //   18: aload #6
    //   20: invokeinterface next : ()Ljava/lang/Object;
    //   25: astore_3
    //   26: aload_0
    //   27: getfield base : Lorg/jgrapht/Graph;
    //   30: aload_3
    //   31: invokeinterface getEdgeSource : (Ljava/lang/Object;)Ljava/lang/Object;
    //   36: astore #7
    //   38: aload_0
    //   39: getfield base : Lorg/jgrapht/Graph;
    //   42: aload_3
    //   43: invokeinterface getEdgeTarget : (Ljava/lang/Object;)Ljava/lang/Object;
    //   48: astore #8
    //   50: aload_0
    //   51: aload #7
    //   53: invokevirtual containsVertex : (Ljava/lang/Object;)Z
    //   56: ifeq -> 72
    //   59: aload_0
    //   60: aload #8
    //   62: invokevirtual containsVertex : (Ljava/lang/Object;)Z
    //   65: ifeq -> 72
    //   68: iconst_1
    //   69: goto -> 73
    //   72: iconst_0
    //   73: istore #4
    //   75: aload_2
    //   76: ifnull -> 89
    //   79: aload_2
    //   80: aload_3
    //   81: invokeinterface contains : (Ljava/lang/Object;)Z
    //   86: ifeq -> 93
    //   89: iconst_1
    //   90: goto -> 94
    //   93: iconst_0
    //   94: istore #5
    //   96: iload #4
    //   98: ifeq -> 116
    //   101: iload #5
    //   103: ifeq -> 116
    //   106: aload_0
    //   107: aload #7
    //   109: aload #8
    //   111: aload_3
    //   112: invokevirtual addEdge : (Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Z
    //   115: pop
    //   116: goto -> 8
    //   119: return
  }
  
  private void addVerticesUsingFilter(Set<V> paramSet1, Set<V> paramSet2) {
    // Byte code:
    //   0: aload_1
    //   1: invokeinterface iterator : ()Ljava/util/Iterator;
    //   6: astore #4
    //   8: aload #4
    //   10: invokeinterface hasNext : ()Z
    //   15: ifeq -> 49
    //   18: aload #4
    //   20: invokeinterface next : ()Ljava/lang/Object;
    //   25: astore_3
    //   26: aload_2
    //   27: ifnull -> 40
    //   30: aload_2
    //   31: aload_3
    //   32: invokeinterface contains : (Ljava/lang/Object;)Z
    //   37: ifeq -> 8
    //   40: aload_0
    //   41: aload_3
    //   42: invokevirtual addVertex : (Ljava/lang/Object;)Z
    //   45: pop
    //   46: goto -> 8
    //   49: return
  }
  
  public G getBase() {
    return this.base;
  }
  
  public double getEdgeWeight(E paramE) {
    return this.base.getEdgeWeight(paramE);
  }
  
  public void setEdgeWeight(E paramE, double paramDouble) {
    ((WeightedGraph)this.base).setEdgeWeight(paramE, paramDouble);
  }
  
  private class BaseGraphListener implements GraphListener<V, E>, Serializable {
    private static final long serialVersionUID = 4343535244243546391L;
    
    private BaseGraphListener() {}
    
    public void edgeAdded(GraphEdgeChangeEvent<V, E> param1GraphEdgeChangeEvent) {
      if (Subgraph.this.isInduced) {
        Object object = param1GraphEdgeChangeEvent.getEdge();
        Subgraph.this.addEdge(Subgraph.this.base.getEdgeSource(object), Subgraph.this.base.getEdgeTarget(object), object);
      } 
    }
    
    public void edgeRemoved(GraphEdgeChangeEvent<V, E> param1GraphEdgeChangeEvent) {
      Object object = param1GraphEdgeChangeEvent.getEdge();
      Subgraph.this.removeEdge(object);
    }
    
    public void vertexAdded(GraphVertexChangeEvent<V> param1GraphVertexChangeEvent) {}
    
    public void vertexRemoved(GraphVertexChangeEvent<V> param1GraphVertexChangeEvent) {
      Object object = param1GraphVertexChangeEvent.getVertex();
      Subgraph.this.removeVertex(object);
    }
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/graph/Subgraph.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */