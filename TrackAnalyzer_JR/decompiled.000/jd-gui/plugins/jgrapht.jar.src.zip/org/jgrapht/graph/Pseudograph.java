package org.jgrapht.graph;

import org.jgrapht.EdgeFactory;
import org.jgrapht.UndirectedGraph;

public class Pseudograph<V, E> extends AbstractBaseGraph<V, E> implements UndirectedGraph<V, E> {
  private static final long serialVersionUID = 3833183614484755253L;
  
  public Pseudograph(Class<? extends E> paramClass) {
    this(new ClassBasedEdgeFactory<V, E>(paramClass));
  }
  
  public Pseudograph(EdgeFactory<V, E> paramEdgeFactory) {
    super(paramEdgeFactory, true, true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/graph/Pseudograph.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */