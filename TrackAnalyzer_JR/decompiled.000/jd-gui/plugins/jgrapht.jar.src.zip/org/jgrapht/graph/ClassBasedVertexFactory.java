package org.jgrapht.graph;

import org.jgrapht.VertexFactory;

public class ClassBasedVertexFactory<V> implements VertexFactory<V> {
  private final Class<? extends V> vertexClass;
  
  public ClassBasedVertexFactory(Class<? extends V> paramClass) {
    this.vertexClass = paramClass;
  }
  
  public V createVertex() {
    try {
      return this.vertexClass.newInstance();
    } catch (Exception exception) {
      throw new RuntimeException("Vertex factory failed", exception);
    } 
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/graph/ClassBasedVertexFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */