package org.jgrapht.graph;

import org.jgrapht.Graph;
import org.jgrapht.UndirectedGraph;

public class ListenableUndirectedGraph<V, E> extends DefaultListenableGraph<V, E> implements UndirectedGraph<V, E> {
  private static final long serialVersionUID = 3256999969193145905L;
  
  public ListenableUndirectedGraph(Class<? extends E> paramClass) {
    this(new SimpleGraph<V, E>(paramClass));
  }
  
  public ListenableUndirectedGraph(UndirectedGraph<V, E> paramUndirectedGraph) {
    super((Graph<V, E>)paramUndirectedGraph);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/graph/ListenableUndirectedGraph.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */