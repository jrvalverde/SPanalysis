package org.jgrapht.graph;

import org.jgrapht.EdgeFactory;
import org.jgrapht.UndirectedGraph;

public class SimpleGraph<V, E> extends AbstractBaseGraph<V, E> implements UndirectedGraph<V, E> {
  private static final long serialVersionUID = 3545796589454112304L;
  
  public SimpleGraph(EdgeFactory<V, E> paramEdgeFactory) {
    super(paramEdgeFactory, false, false);
  }
  
  public SimpleGraph(Class<? extends E> paramClass) {
    this(new ClassBasedEdgeFactory<V, E>(paramClass));
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/graph/SimpleGraph.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */