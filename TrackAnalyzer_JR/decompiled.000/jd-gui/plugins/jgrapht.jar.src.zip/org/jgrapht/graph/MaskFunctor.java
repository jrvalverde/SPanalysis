package org.jgrapht.graph;

public interface MaskFunctor<V, E> {
  boolean isEdgeMasked(E paramE);
  
  boolean isVertexMasked(V paramV);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/graph/MaskFunctor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */