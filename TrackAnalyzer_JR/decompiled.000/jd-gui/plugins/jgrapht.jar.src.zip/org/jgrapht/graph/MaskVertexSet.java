package org.jgrapht.graph;

import java.util.AbstractSet;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Set;
import org.jgrapht.util.PrefetchIterator;
import org.jgrapht.util.TypeUtil;

class MaskVertexSet<V, E> extends AbstractSet<V> {
  private MaskFunctor<V, E> mask;
  
  private int size;
  
  private Set<V> vertexSet;
  
  private transient TypeUtil<V> vertexTypeDecl = null;
  
  public MaskVertexSet(Set<V> paramSet, MaskFunctor<V, E> paramMaskFunctor) {
    this.vertexSet = paramSet;
    this.mask = paramMaskFunctor;
    this.size = -1;
  }
  
  public boolean contains(Object paramObject) {
    return (!this.mask.isVertexMasked((V)TypeUtil.uncheckedCast(paramObject, this.vertexTypeDecl)) && this.vertexSet.contains(paramObject));
  }
  
  public Iterator<V> iterator() {
    return (Iterator<V>)new PrefetchIterator(new MaskVertexSetNextElementFunctor());
  }
  
  public int size() {
    if (this.size == -1) {
      this.size = 0;
      Iterator<V> iterator = iterator();
      while (iterator.hasNext()) {
        iterator.next();
        this.size++;
      } 
    } 
    return this.size;
  }
  
  private class MaskVertexSetNextElementFunctor implements PrefetchIterator.NextElementFunctor<V> {
    private Iterator<V> iter = MaskVertexSet.this.vertexSet.iterator();
    
    public V nextElement() throws NoSuchElementException {
      V v;
      for (v = this.iter.next(); MaskVertexSet.this.mask.isVertexMasked(v); v = this.iter.next());
      return v;
    }
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/graph/MaskVertexSet.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */