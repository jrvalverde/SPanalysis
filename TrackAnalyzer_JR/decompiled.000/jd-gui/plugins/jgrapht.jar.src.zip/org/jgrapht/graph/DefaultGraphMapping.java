package org.jgrapht.graph;

import java.util.Map;
import org.jgrapht.Graph;
import org.jgrapht.GraphMapping;

public class DefaultGraphMapping<V, E> implements GraphMapping<V, E> {
  private Map<V, V> graphMappingForward;
  
  private Map<V, V> graphMappingReverse;
  
  private Graph<V, E> graph1;
  
  private Graph<V, E> graph2;
  
  public DefaultGraphMapping(Map<V, V> paramMap1, Map<V, V> paramMap2, Graph<V, E> paramGraph1, Graph<V, E> paramGraph2) {
    this.graph1 = paramGraph1;
    this.graph2 = paramGraph2;
    this.graphMappingForward = paramMap1;
    this.graphMappingReverse = paramMap2;
  }
  
  public E getEdgeCorrespondence(E paramE, boolean paramBoolean) {
    Graph<V, E> graph1;
    Graph<V, E> graph2;
    if (paramBoolean) {
      graph1 = this.graph1;
      graph2 = this.graph2;
    } else {
      graph1 = this.graph2;
      graph2 = this.graph1;
    } 
    V v1 = getVertexCorrespondence((V)graph1.getEdgeSource(paramE), paramBoolean);
    V v2 = getVertexCorrespondence((V)graph1.getEdgeTarget(paramE), paramBoolean);
    return (E)((v1 == null || v2 == null) ? null : graph2.getEdge(v1, v2));
  }
  
  public V getVertexCorrespondence(V paramV, boolean paramBoolean) {
    Map<V, V> map;
    if (paramBoolean) {
      map = this.graphMappingForward;
    } else {
      map = this.graphMappingReverse;
    } 
    return map.get(paramV);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/graph/DefaultGraphMapping.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */