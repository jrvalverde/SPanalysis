package org.jgrapht.graph;

import java.util.Collection;
import java.util.Set;
import org.jgrapht.DirectedGraph;
import org.jgrapht.EdgeFactory;
import org.jgrapht.Graph;

public class MaskSubgraph<V, E> extends AbstractGraph<V, E> {
  private static final String UNMODIFIABLE = "this graph is unmodifiable";
  
  private Graph<V, E> base;
  
  private Set<E> edges;
  
  private MaskFunctor<V, E> mask;
  
  private Set<V> vertices;
  
  public MaskSubgraph(Graph<V, E> paramGraph, MaskFunctor<V, E> paramMaskFunctor) {
    this.base = paramGraph;
    this.mask = paramMaskFunctor;
    this.vertices = new MaskVertexSet<V, E>(paramGraph.vertexSet(), paramMaskFunctor);
    this.edges = new MaskEdgeSet<V, E>(paramGraph, paramGraph.edgeSet(), paramMaskFunctor);
  }
  
  public E addEdge(V paramV1, V paramV2) {
    throw new UnsupportedOperationException("this graph is unmodifiable");
  }
  
  public boolean addEdge(V paramV1, V paramV2, E paramE) {
    throw new UnsupportedOperationException("this graph is unmodifiable");
  }
  
  public boolean addVertex(V paramV) {
    throw new UnsupportedOperationException("this graph is unmodifiable");
  }
  
  public boolean containsEdge(E paramE) {
    return edgeSet().contains(paramE);
  }
  
  public boolean containsVertex(V paramV) {
    return (!this.mask.isVertexMasked(paramV) && this.base.containsVertex(paramV));
  }
  
  public int degreeOf(V paramV) {
    return edgesOf(paramV).size();
  }
  
  public Set<E> edgeSet() {
    return this.edges;
  }
  
  public Set<E> edgesOf(V paramV) {
    assertVertexExist(paramV);
    return new MaskEdgeSet<V, E>(this.base, this.base.edgesOf(paramV), this.mask);
  }
  
  public Set<E> getAllEdges(V paramV1, V paramV2) {
    Set set = null;
    return (containsVertex(paramV1) && containsVertex(paramV2)) ? new MaskEdgeSet<V, E>(this.base, this.base.getAllEdges(paramV1, paramV2), this.mask) : set;
  }
  
  public E getEdge(V paramV1, V paramV2) {
    Set<E> set = getAllEdges(paramV1, paramV2);
    return (set == null || set.isEmpty()) ? null : set.iterator().next();
  }
  
  public EdgeFactory<V, E> getEdgeFactory() {
    return this.base.getEdgeFactory();
  }
  
  public V getEdgeSource(E paramE) {
    assert edgeSet().contains(paramE);
    return (V)this.base.getEdgeSource(paramE);
  }
  
  public V getEdgeTarget(E paramE) {
    assert edgeSet().contains(paramE);
    return (V)this.base.getEdgeTarget(paramE);
  }
  
  public double getEdgeWeight(E paramE) {
    assert edgeSet().contains(paramE);
    return this.base.getEdgeWeight(paramE);
  }
  
  public Set<E> incomingEdgesOf(V paramV) {
    assertVertexExist(paramV);
    return new MaskEdgeSet<V, E>(this.base, ((DirectedGraph)this.base).incomingEdgesOf(paramV), this.mask);
  }
  
  public int inDegreeOf(V paramV) {
    return incomingEdgesOf(paramV).size();
  }
  
  public int outDegreeOf(V paramV) {
    return outgoingEdgesOf(paramV).size();
  }
  
  public Set<E> outgoingEdgesOf(V paramV) {
    assertVertexExist(paramV);
    return new MaskEdgeSet<V, E>(this.base, ((DirectedGraph)this.base).outgoingEdgesOf(paramV), this.mask);
  }
  
  public boolean removeAllEdges(Collection<? extends E> paramCollection) {
    throw new UnsupportedOperationException("this graph is unmodifiable");
  }
  
  public Set<E> removeAllEdges(V paramV1, V paramV2) {
    throw new UnsupportedOperationException("this graph is unmodifiable");
  }
  
  public boolean removeAllVertices(Collection<? extends V> paramCollection) {
    throw new UnsupportedOperationException("this graph is unmodifiable");
  }
  
  public boolean removeEdge(E paramE) {
    throw new UnsupportedOperationException("this graph is unmodifiable");
  }
  
  public E removeEdge(V paramV1, V paramV2) {
    throw new UnsupportedOperationException("this graph is unmodifiable");
  }
  
  public boolean removeVertex(V paramV) {
    throw new UnsupportedOperationException("this graph is unmodifiable");
  }
  
  public Set<V> vertexSet() {
    return this.vertices;
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/graph/MaskSubgraph.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */