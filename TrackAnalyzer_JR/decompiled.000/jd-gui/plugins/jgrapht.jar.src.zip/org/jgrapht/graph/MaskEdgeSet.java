package org.jgrapht.graph;

import java.util.AbstractSet;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Set;
import org.jgrapht.Graph;
import org.jgrapht.util.PrefetchIterator;
import org.jgrapht.util.TypeUtil;

class MaskEdgeSet<V, E> extends AbstractSet<E> {
  private Set<E> edgeSet;
  
  private Graph<V, E> graph;
  
  private MaskFunctor<V, E> mask;
  
  private transient TypeUtil<E> edgeTypeDecl = null;
  
  private int size;
  
  public MaskEdgeSet(Graph<V, E> paramGraph, Set<E> paramSet, MaskFunctor<V, E> paramMaskFunctor) {
    this.graph = paramGraph;
    this.edgeSet = paramSet;
    this.mask = paramMaskFunctor;
    this.size = -1;
  }
  
  public boolean contains(Object paramObject) {
    return (this.edgeSet.contains(paramObject) && !this.mask.isEdgeMasked((E)TypeUtil.uncheckedCast(paramObject, this.edgeTypeDecl)));
  }
  
  public Iterator<E> iterator() {
    return (Iterator<E>)new PrefetchIterator(new MaskEdgeSetNextElementFunctor());
  }
  
  public int size() {
    if (this.size == -1) {
      this.size = 0;
      Iterator<E> iterator = iterator();
      while (iterator.hasNext()) {
        iterator.next();
        this.size++;
      } 
    } 
    return this.size;
  }
  
  private class MaskEdgeSetNextElementFunctor implements PrefetchIterator.NextElementFunctor<E> {
    private Iterator<E> iter = MaskEdgeSet.this.edgeSet.iterator();
    
    public E nextElement() throws NoSuchElementException {
      E e;
      for (e = this.iter.next(); isMasked(e); e = this.iter.next());
      return e;
    }
    
    private boolean isMasked(E param1E) {
      return (MaskEdgeSet.this.mask.isEdgeMasked(param1E) || MaskEdgeSet.this.mask.isVertexMasked(MaskEdgeSet.this.graph.getEdgeSource(param1E)) || MaskEdgeSet.this.mask.isVertexMasked(MaskEdgeSet.this.graph.getEdgeTarget(param1E)));
    }
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/graph/MaskEdgeSet.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */