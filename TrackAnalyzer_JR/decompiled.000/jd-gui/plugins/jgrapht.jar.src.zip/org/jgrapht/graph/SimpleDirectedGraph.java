package org.jgrapht.graph;

import org.jgrapht.DirectedGraph;
import org.jgrapht.EdgeFactory;

public class SimpleDirectedGraph<V, E> extends AbstractBaseGraph<V, E> implements DirectedGraph<V, E> {
  private static final long serialVersionUID = 4049358608472879671L;
  
  public SimpleDirectedGraph(Class<? extends E> paramClass) {
    this(new ClassBasedEdgeFactory<V, E>(paramClass));
  }
  
  public SimpleDirectedGraph(EdgeFactory<V, E> paramEdgeFactory) {
    super(paramEdgeFactory, false, false);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/graph/SimpleDirectedGraph.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */