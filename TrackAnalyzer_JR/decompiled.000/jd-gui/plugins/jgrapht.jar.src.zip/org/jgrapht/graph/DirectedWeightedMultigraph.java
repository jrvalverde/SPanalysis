package org.jgrapht.graph;

import org.jgrapht.EdgeFactory;
import org.jgrapht.WeightedGraph;

public class DirectedWeightedMultigraph<V, E> extends DirectedMultigraph<V, E> implements WeightedGraph<V, E> {
  private static final long serialVersionUID = 4049071636005206066L;
  
  public DirectedWeightedMultigraph(Class<? extends E> paramClass) {
    this(new ClassBasedEdgeFactory<V, E>(paramClass));
  }
  
  public DirectedWeightedMultigraph(EdgeFactory<V, E> paramEdgeFactory) {
    super(paramEdgeFactory);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/graph/DirectedWeightedMultigraph.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */