package org.jgrapht.graph;

import java.util.Set;
import org.jgrapht.DirectedGraph;
import org.jgrapht.Graph;

public class EdgeReversedGraph<V, E> extends GraphDelegator<V, E> implements DirectedGraph<V, E> {
  private static final long serialVersionUID = 9091361782455418631L;
  
  public EdgeReversedGraph(DirectedGraph<V, E> paramDirectedGraph) {
    super((Graph<V, E>)paramDirectedGraph);
  }
  
  public E getEdge(V paramV1, V paramV2) {
    return super.getEdge(paramV2, paramV1);
  }
  
  public Set<E> getAllEdges(V paramV1, V paramV2) {
    return super.getAllEdges(paramV2, paramV1);
  }
  
  public E addEdge(V paramV1, V paramV2) {
    return super.addEdge(paramV2, paramV1);
  }
  
  public boolean addEdge(V paramV1, V paramV2, E paramE) {
    return super.addEdge(paramV2, paramV1, paramE);
  }
  
  public int inDegreeOf(V paramV) {
    return super.outDegreeOf(paramV);
  }
  
  public int outDegreeOf(V paramV) {
    return super.inDegreeOf(paramV);
  }
  
  public Set<E> incomingEdgesOf(V paramV) {
    return super.outgoingEdgesOf(paramV);
  }
  
  public Set<E> outgoingEdgesOf(V paramV) {
    return super.incomingEdgesOf(paramV);
  }
  
  public E removeEdge(V paramV1, V paramV2) {
    return super.removeEdge(paramV2, paramV1);
  }
  
  public V getEdgeSource(E paramE) {
    return super.getEdgeTarget(paramE);
  }
  
  public V getEdgeTarget(E paramE) {
    return super.getEdgeSource(paramE);
  }
  
  public String toString() {
    return toStringFromSets(vertexSet(), edgeSet(), true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/graph/EdgeReversedGraph.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */