package org.jgrapht.graph;

import java.io.Serializable;
import org.jgrapht.EdgeFactory;

public class ClassBasedEdgeFactory<V, E> implements EdgeFactory<V, E>, Serializable {
  private static final long serialVersionUID = 3618135658586388792L;
  
  private final Class<? extends E> edgeClass;
  
  public ClassBasedEdgeFactory(Class<? extends E> paramClass) {
    this.edgeClass = paramClass;
  }
  
  public E createEdge(V paramV1, V paramV2) {
    try {
      return this.edgeClass.newInstance();
    } catch (Exception exception) {
      throw new RuntimeException("Edge factory failed", exception);
    } 
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/graph/ClassBasedEdgeFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */