package org.jgrapht;

import java.util.Collection;
import java.util.Set;

public interface Graph<V, E> {
  Set<E> getAllEdges(V paramV1, V paramV2);
  
  E getEdge(V paramV1, V paramV2);
  
  EdgeFactory<V, E> getEdgeFactory();
  
  E addEdge(V paramV1, V paramV2);
  
  boolean addEdge(V paramV1, V paramV2, E paramE);
  
  boolean addVertex(V paramV);
  
  boolean containsEdge(V paramV1, V paramV2);
  
  boolean containsEdge(E paramE);
  
  boolean containsVertex(V paramV);
  
  Set<E> edgeSet();
  
  Set<E> edgesOf(V paramV);
  
  boolean removeAllEdges(Collection<? extends E> paramCollection);
  
  Set<E> removeAllEdges(V paramV1, V paramV2);
  
  boolean removeAllVertices(Collection<? extends V> paramCollection);
  
  E removeEdge(V paramV1, V paramV2);
  
  boolean removeEdge(E paramE);
  
  boolean removeVertex(V paramV);
  
  Set<V> vertexSet();
  
  V getEdgeSource(E paramE);
  
  V getEdgeTarget(E paramE);
  
  double getEdgeWeight(E paramE);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/Graph.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */