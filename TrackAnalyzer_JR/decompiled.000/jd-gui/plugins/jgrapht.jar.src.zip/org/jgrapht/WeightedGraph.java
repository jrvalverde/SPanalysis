package org.jgrapht;

public interface WeightedGraph<V, E> extends Graph<V, E> {
  public static final double DEFAULT_EDGE_WEIGHT = 1.0D;
  
  void setEdgeWeight(E paramE, double paramDouble);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jgrapht.jar!/org/jgrapht/WeightedGraph.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */