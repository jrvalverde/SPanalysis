/*
 * The MIT License (MIT)
 * Copyright (c) 2015-2016 Thorsten Wagner (wagner@biomedical-imaging.de)
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

package de.biomedical_imaging.traJ.features;

import de.biomedical_imaging.traJ.Trajectory;

/**
 * The ratio of the MSD perpendicular and parallel to a fitted spline.
 * For free diffusion it should be ~ 1.
 * For active << 1
 * @author Thorsten Wagner
 *
 */
public class SplineCurveDynamicsMSDRatioFeature extends AbstractTrajectoryFeature {
	private Trajectory t;
	private int timelag;
	public SplineCurveDynamicsMSDRatioFeature(Trajectory t, int timelag) {
		this.t = t;
		this.timelag = timelag;
	}
	
	@Override
	public double[] evaluate() {
		SplineCurveDynamicsFeature scdf = new SplineCurveDynamicsFeature(t,7,timelag);
		double[] res = scdf.evaluate();
		res[0] = res[0]/(2.0*timelag);
		res[1] = res[1]/(2.0*timelag);
		double v = Math.pow(res[0], 2)/Math.pow(res[1], 2);
		if(Double.isInfinite(v) || Double.isNaN(v)){
			v = Double.NaN;
		}
		result = new double[] {v};
		return result;
	}

	@Override
	public String getName() {
		return "Spline curve dynamics mean squared displacement ratio";
	}

	@Override
	public String getShortName() {
		return "SCDF-MSD-RATIO";
	}

	@Override
	public void setTrajectory(Trajectory t) {
		this.t = t;
		result = null;
	}

}
