package de.biomedical_imaging.traJ;

import ij.IJ;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.rosuda.REngine.REngineException;
import org.rosuda.REngine.Rserve.RConnection;
import org.rosuda.REngine.Rserve.RserveException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import rtools.StartRserve;
import de.biomedical_imaging.traJ.FeatureWorker.EVALTYPE;
import de.biomedical_imaging.traJ.features.Asymmetry2Feature;
import de.biomedical_imaging.traJ.features.Asymmetry3Feature;
import de.biomedical_imaging.traJ.features.AsymmetryFeature;
import de.biomedical_imaging.traJ.features.BoundednessFeature;
import de.biomedical_imaging.traJ.features.EfficiencyFeature;
import de.biomedical_imaging.traJ.features.ElongationFeature;
import de.biomedical_imaging.traJ.features.FractalDimensionFeature;
import de.biomedical_imaging.traJ.features.GaussianityFeauture;
import de.biomedical_imaging.traJ.features.KurtosisFeature;
import de.biomedical_imaging.traJ.features.MSDRatioFeature;
import de.biomedical_imaging.traJ.features.MeanSquaredDisplacmentCurvature;
import de.biomedical_imaging.traJ.features.PowerLawFeature;
import de.biomedical_imaging.traJ.features.SNRFeature;
import de.biomedical_imaging.traJ.features.ShortTimeLongTimeDiffusioncoefficentRatio;
import de.biomedical_imaging.traJ.features.SkewnessFeature;
import de.biomedical_imaging.traJ.features.SplineCurveDynamicsFeature;
import de.biomedical_imaging.traJ.features.StraightnessFeature;
import de.biomedical_imaging.traJ.features.TrappedProbabilityFeature;
import de.biomedical_imaging.traJ.simulation.AbstractSphereObstacle;
import de.biomedical_imaging.traJ.simulation.AnomalousDiffusionScene;
import de.biomedical_imaging.traJ.simulation.CentralRandomNumberGenerator;

public class ExportTools {

	public static void exportAnomalousSceneAsXML(AnomalousDiffusionScene s, String path){
		try {
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder;
		
			docBuilder = docFactory.newDocumentBuilder();
	
			Document doc = docBuilder.newDocument();
			Element rootElement = doc.createElement("AnomalousScene");
			rootElement.setAttribute("Seed", "" + CentralRandomNumberGenerator.getInstance().getSeed());
			doc.appendChild(rootElement);
			ArrayList<AbstractSphereObstacle> obstacles = s.getObstacles();
			rootElement.setAttribute("x-dimension", ""+s.getSize()[0]);
			rootElement.setAttribute("y-dimension", ""+s.getSize()[1]);
			
			for (AbstractSphereObstacle o : obstacles) {
				Element t = doc.createElement("obstacle");
				rootElement.appendChild(t);
				t.setAttribute("Radius", ""+o.getRadius());
				t.setAttribute("X", ""+o.getPosition()[0]);
				t.setAttribute("Y", ""+o.getPosition()[1]);
				t.setAttribute("type", o.getClass().getCanonicalName());
				if(o.getDimension()==3){
					t.setAttribute("Z", ""+o.getPosition()[2]);
				}
				t.setAttribute("Dimension", ""+o.getDimension());
			}
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			DOMSource source = new DOMSource(doc);
			StreamResult result = new StreamResult(new File(path));
			transformer.transform(source, result);
			
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		} catch (TransformerConfigurationException e) {
			e.printStackTrace();
		} catch (TransformerException e) {
			e.printStackTrace();
		}
		
	}
	
	public static AnomalousDiffusionScene importAnomalousScene(String path){
		//AnomalousDiffusionScene scene = new AnomalousDiffusionScene(size, dimension)
		return null;
	}

	
	public static ArrayList<Trajectory> importTrajectories(String path){
		
			ArrayList<Trajectory> trajectories = new ArrayList<Trajectory>();
			try {
				File fXmlFile = new File(path);
				DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
				DocumentBuilder dBuilder;
				dBuilder = dbFactory.newDocumentBuilder();
				Document doc = dBuilder.parse(fXmlFile);
				NodeList tracksList = doc.getElementsByTagName("Track");
				
				for(int i = 0; i < tracksList.getLength(); i++){
					
					Node track = tracksList.item(i);
					Element eTrack = (Element) track;
					int dimension = Integer.parseInt(eTrack.getAttribute("Dimension"));
					int id = Integer.parseInt(eTrack.getAttribute("ID"));
					String type = eTrack.getAttribute("Type");
					//IJ.log("int: " + eTrack.getAttribute("Start"));
					int start = Integer.parseInt(eTrack.getAttribute("Start"));
					
					Trajectory t = new Trajectory();
					t.setID(id);
					t.setDimension(dimension);
					t.setType(type);
					t.setRelativStartTimepoint(start);
					Node positionsNode = null;
					
					for(int j = 0; j < track.getChildNodes().getLength(); j++){
						if(track.getChildNodes().item(j).getNodeName()=="Positions"){
							positionsNode= track.getChildNodes().item(j);
						}
					}
					NodeList positions = positionsNode.getChildNodes();
					int lastTime=0;
					for(int j = 0; j < positions.getLength(); j++){
						Element pos = (Element)positions.item(j);
						int time = Integer.parseInt(pos.getAttribute("t"));
						double x = Double.parseDouble(pos.getAttribute("x")); 
						
						double y = Double.parseDouble(pos.getAttribute("y")); 
						double z = Double.parseDouble(pos.getAttribute("z")); 
						t.add(x, y, z);
						if(j>0){
							int dt = time - lastTime;
							for(int k = 1; k < dt; k++){
								t.add(null);
							}
						}
						lastTime = time;
					}
					trajectories.add(t);	
				}
			} catch (ParserConfigurationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SAXException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return trajectories;
	}
	
public static void exportTrajectoriesAsRData2(ArrayList<Trajectory> tracks, String path, double timelag){
		
		/*
		 * Generate Dataset
		 */
		
		int N = tracks.size();
		String[] types = new String[N];
		int[] lengths = new int[N];
		double[] elong = new double[N];
		double[] fd = new double[N];
		double[] power = new double[N];
		double[] asym1 = new double[N];
		double[] asym2 = new double[N];
		double[] asym3 = new double[N];
		double[] efficiency = new double[N];
		double[] trappedness = new double[N];
		double[] gaussianity = new double[N];
		double[] straightness = new double[N];
		double[] kurt = new double[N];
		double[] skew = new double[N];
		//"ELONG","STRAIGHTNESS","KURT","SKEW","ASYM1","ASYM3"
		
		for(int i = 0; i < tracks.size(); i++){
			System.out.println("i " + (100.0*i/tracks.size()));
			Trajectory t = tracks.get(i);

			
			types[i] = t.getType();
			lengths[i] = t.size();
			
			ElongationFeature elongF = new ElongationFeature(t);
			elong[i] = elongF.evaluate()[0];
			
			FractalDimensionFeature fdF = new FractalDimensionFeature(t);
			fd[i] = fdF.evaluate()[0];
		
			PowerLawFeature pwf = new PowerLawFeature(t, 1/timelag,1, t.size()-1);
			power[i] = pwf.evaluate()[0];
	
			AsymmetryFeature asymf1 = new AsymmetryFeature(t);
			asym1[i] = asymf1.evaluate()[0];
			
			Asymmetry2Feature asymf2 = new Asymmetry2Feature(t);
			asym2[i] = asymf2.evaluate()[0];
			
			Asymmetry3Feature asymf3 = new Asymmetry3Feature(t);
			asym3[i] = asymf3.evaluate()[0];
			
			EfficiencyFeature eff = new EfficiencyFeature(t);
			efficiency[i] = eff.evaluate()[0];
			
			TrappedProbabilityFeature trappf = new TrappedProbabilityFeature(t);
			trappedness[i] = trappf.evaluate()[0];
			
			GaussianityFeauture gaussf = new GaussianityFeauture(t, 1);
			gaussianity[i] = gaussf.evaluate()[0];
			
			StraightnessFeature straightf = new StraightnessFeature(t);
			straightness[i] = straightf.evaluate()[0];
			
			KurtosisFeature kurtf = new KurtosisFeature(t);
			kurt[i] = kurtf.evaluate()[0];
			
			SkewnessFeature skewf = new SkewnessFeature(t);
			skew[i] = skewf.evaluate()[0];
		}
		
	
		/*
		 * Save as RData
		 */
		StartRserve.launchRserve("R");
		RConnection c = StartRserve.c; 
		try {
			c.assign("types", types);
			c.assign("lengths", lengths);
			c.assign("fd",fd);
			c.assign("power", power);
			c.assign("elong",elong);
			c.assign("asymmetry1", asym1);
			c.assign("asymmetry2", asym2);
			c.assign("asymmetry3", asym3);
			c.assign("efficiency", efficiency);
			c.assign("trappedness", trappedness);
			c.assign("gaussianity", gaussianity);
			c.assign("straightness", straightness);
			c.assign("kurt", kurt);
			c.assign("skew", skew);
			c.voidEval("data<-data.frame(TYPES=types,LENGTHS=lengths,FD=fd,ELONG=elong,"
					+ "POWER=power,ASYM1=asymmetry1,ASYM2=asymmetry2,"
					+ "ASYM3=asymmetry3,EFFICENCY=efficiency,STRAIGHTNESS=straightness,"
					+ "TRAPPED=trappedness,GAUSS=gaussianity, KURT=kurt,SKEW=skew)");
			System.out.println("Commadn: " + "save(data,\""+path+"\")");
			c.voidEval("save(data,file=\""+path+"\")");
			
		} catch (RserveException e) {
			System.out.println("Message: " + e.getMessage());
			e.printStackTrace();
		} catch (REngineException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	}
	
	
	public static void exportTrajectoriesAsRData(ArrayList<Trajectory> tracks, String path, double timelag){
		
		/*
		 * Generate Dataset
		 */
		
		int N = tracks.size();
		String[] types = new String[N];
		int[] lengths = new int[N];
		double[] elong = new double[N];
		double[] fd = new double[N];
		double[] msdcurvature = new double[N];
		double[] power = new double[N];
		@SuppressWarnings("unused")
		double[] sdDir = new double[N]; 
		double[] dratio = new double[N]; 
		double[] ltStRatio = new double[N]; 
		double[] asym1 = new double[N]; 
		double[] asym2 = new double[N];
		double[] asym3 = new double[N];
		double[] efficiency = new double[N];
		double[] kurtosis = new double[N];
		double[] skewness = new double[N];
		double[] msdratio = new double[N];
		double[] msdratio2 = new double[N];
		double[] straightness = new double[N];
		double[] trappedness = new double[N];
		double[] gaussianity = new double[N];
		double[] boundness = new double[N];
		double[] snr = new double[N];
		
		int numberOfSegmentsSplineFit = 7;
		int numberOfPointsForShortTimeLongTimeRatio = 2;
		
		int cores = Runtime.getRuntime().availableProcessors();
		ExecutorService pool = Executors.newFixedThreadPool(cores);
		
		for(int i = 0; i < tracks.size(); i++){
			System.out.println("i " + (100.0*i/tracks.size()));
			Trajectory t = tracks.get(i);
			
			types[i] = t.getType();
			lengths[i] = t.size();
			
			ElongationFeature elongF = new ElongationFeature(t);
			pool.submit(new FeatureWorker(elong, i,elongF, EVALTYPE.FIRST));
			
			FractalDimensionFeature fdF = new FractalDimensionFeature(t);
			pool.submit(new FeatureWorker(fd, i,fdF, EVALTYPE.FIRST));
			
			MeanSquaredDisplacmentCurvature msdCurv = new MeanSquaredDisplacmentCurvature(t);
			pool.submit(new FeatureWorker(msdcurvature, i,msdCurv, EVALTYPE.FIRST));
			
			PowerLawFeature pwf = new PowerLawFeature(t, 1/timelag,1, t.size()/3);
			pool.submit(new FeatureWorker(power, i,pwf, EVALTYPE.FIRST));
			
			//StandardDeviationDirectionFeature sdf = new StandardDeviationDirectionFeature(t, timelagForDirectionDeviationLong);
			//sdDir[i] = sdf.evaluate()[0];
			
			SplineCurveDynamicsFeature scdf = new SplineCurveDynamicsFeature(t, numberOfSegmentsSplineFit, 1);
			pool.submit(new FeatureWorker(dratio, i,scdf, EVALTYPE.RATIO_01));
			
			ShortTimeLongTimeDiffusioncoefficentRatio stltdf = new ShortTimeLongTimeDiffusioncoefficentRatio(t, numberOfPointsForShortTimeLongTimeRatio);
			pool.submit(new FeatureWorker(ltStRatio, i,stltdf, EVALTYPE.FIRST));
			
			AsymmetryFeature asymf1 = new AsymmetryFeature(t);
			pool.submit(new FeatureWorker(asym1, i,asymf1, EVALTYPE.FIRST));
			
			Asymmetry2Feature asymf2 = new Asymmetry2Feature(t);
			pool.submit(new FeatureWorker(asym2, i,asymf2, EVALTYPE.FIRST));
			
			Asymmetry3Feature asymf3 = new Asymmetry3Feature(t);
			pool.submit(new FeatureWorker(asym3, i,asymf3, EVALTYPE.FIRST));
			
			EfficiencyFeature eff = new EfficiencyFeature(t);
			pool.submit(new FeatureWorker(efficiency, i,eff, EVALTYPE.FIRST));
			
			KurtosisFeature kurtf = new KurtosisFeature(t);
			pool.submit(new FeatureWorker(kurtosis, i,kurtf, EVALTYPE.FIRST));
			
			SkewnessFeature skew = new SkewnessFeature(t);
			pool.submit(new FeatureWorker(skewness, i,skew, EVALTYPE.FIRST));
			
			MSDRatioFeature msdr = new MSDRatioFeature(t, 1, 5);
			pool.submit(new FeatureWorker(msdratio, i,msdr, EVALTYPE.FIRST));
			
			MSDRatioFeature msdr2 = new MSDRatioFeature(t, 1, 10);
			pool.submit(new FeatureWorker(msdratio2, i,msdr2, EVALTYPE.FIRST));
			
			StraightnessFeature straight = new StraightnessFeature(t);
			pool.submit(new FeatureWorker(straightness, i,straight, EVALTYPE.FIRST));
			
			TrappedProbabilityFeature trappf = new TrappedProbabilityFeature(t);
			pool.submit(new FeatureWorker(trappedness, i,trappf, EVALTYPE.FIRST));
			
			GaussianityFeauture gaussf = new GaussianityFeauture(t, 1);
			pool.submit(new FeatureWorker(gaussianity, i,gaussf, EVALTYPE.FIRST));
			
			BoundednessFeature boundf = new BoundednessFeature(t, timelag);
			pool.submit(new FeatureWorker(boundness, i,boundf, EVALTYPE.FIRST));
			
			SNRFeature snrf = new SNRFeature(t, timelag);
			pool.submit(new FeatureWorker(snr, i,snrf, EVALTYPE.FIRST));

		}
		pool.shutdown();
		try {
			System.out.println("Wait for termination");
		
			pool.awaitTermination(Long.MAX_VALUE, TimeUnit.NANOSECONDS);
			} catch (InterruptedException e) {
			  e.printStackTrace();
			}
	
		/*
		 * Save as RData
		 */
		StartRserve.launchRserve("R");
		RConnection c = StartRserve.c; 
		try {
			c.assign("types", types);
			c.assign("lengths", lengths);
			c.assign("elong", elong);
			c.assign("fd",fd);
			c.assign("msdcurvature",msdcurvature);
			c.assign("power", power);
			//c.assign("sdDir", sdDir);
			c.assign("D.ratio", dratio);
			c.assign("LtStRatio", ltStRatio);
			c.assign("asymmetry1", asym1);
			c.assign("asymmetry2", asym2);
			c.assign("asymmetry3", asym3);
			c.assign("efficiency", efficiency);
			c.assign("kurtosis",kurtosis);
			c.assign("skewness", skewness);
			c.assign("msdratio", msdratio);
			c.assign("msdratio2", msdratio2);
			c.assign("straightness", straightness);
			c.assign("trappedness", trappedness);
			c.assign("gaussianity", gaussianity);
			c.assign("boundness", boundness);
			c.assign("snr", snr);
			c.voidEval("data<-data.frame(TYPES=types,LENGTHS=lengths,ELONG=elong,FD=fd,MSD.C=msdcurvature,"
					+ "POWER=power,SPLINE.RATIO=D.ratio,LTST.RATIO=LtStRatio,"
					+ "ASYM1=asymmetry1,ASYM2=asymmetry2,ASYM3=asymmetry3,EFFICENCY=efficiency, KURT=kurtosis,"
					+ "SKEW=skewness,MSD.R=msdratio,MSD.R2=msdratio2,STRAIGHTNESS=straightness, "
					+ "TRAPPED=trappedness,GAUSS=gaussianity,BOUND=boundness,SNR=snr)");
			System.out.println("Commadn: " + "save(data,\""+path+"\")");
			c.voidEval("save(data,file=\""+path+"\")");
			
		} catch (RserveException e) {
			System.out.println("Message: " + e.getMessage());
			e.printStackTrace();
		} catch (REngineException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	}
}
