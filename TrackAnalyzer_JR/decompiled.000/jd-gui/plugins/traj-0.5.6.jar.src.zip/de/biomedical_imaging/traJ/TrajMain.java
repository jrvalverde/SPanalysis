package de.biomedical_imaging.traJ;


import ij.IJ;

import java.awt.geom.Point2D;
import java.util.ArrayList;
import java.util.List;

import javax.vecmath.Point2d;
import javax.vecmath.Point3d;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.math3.stat.descriptive.moment.Mean;
import org.apache.commons.math3.stat.descriptive.moment.StandardDeviation;
import org.knowm.xchart.Chart;
import org.rosuda.REngine.REXP;
import org.rosuda.REngine.REXPMismatchException;
import org.rosuda.REngine.REngineException;
import org.rosuda.REngine.Rserve.RConnection;
import org.rosuda.REngine.Rserve.RserveException;

import com.sun.tools.javac.util.GraphUtils.TarjanNode;

import cg.RotatingCalipers;
import de.biomedical_imaging.traJ.DiffusionCoefficientEstimator.CovarianceDiffusionCoefficientEstimator;
import de.biomedical_imaging.traJ.DiffusionCoefficientEstimator.RegressionDiffusionCoefficientEstimator;
import de.biomedical_imaging.traJ.features.AbstractTrajectoryFeature;
import de.biomedical_imaging.traJ.features.AspectRatioFeature;
import de.biomedical_imaging.traJ.features.AsymmetryFeature;
import de.biomedical_imaging.traJ.features.BoundednessFeature;
import de.biomedical_imaging.traJ.features.ConfinedDiffusionParametersFeature;
import de.biomedical_imaging.traJ.features.ElongationFeature;
import de.biomedical_imaging.traJ.features.FractalDimensionFeature;
import de.biomedical_imaging.traJ.features.GaussianityFeauture;
import de.biomedical_imaging.traJ.features.KurtosisFeature;
import de.biomedical_imaging.traJ.features.MSDRatioFeature;
import de.biomedical_imaging.traJ.features.MaxDistanceBetweenTwoPositionsFeature;
import de.biomedical_imaging.traJ.features.MeanSpeedFeature;
import de.biomedical_imaging.traJ.features.MeanSquaredDisplacmentCurvature;
import de.biomedical_imaging.traJ.features.MeanSquaredDisplacmentFeature;
import de.biomedical_imaging.traJ.features.PowerLawFeature;
import de.biomedical_imaging.traJ.features.ShortTimeLongTimeDiffusioncoefficentRatio;
import de.biomedical_imaging.traJ.features.ShortTimeLongTimeSCDFFeature;
import de.biomedical_imaging.traJ.features.SkewnessFeature;
import de.biomedical_imaging.traJ.features.SplineCurveDynamicsFeature;
import de.biomedical_imaging.traJ.features.SplineCurveDynamicsMSDRatioFeature;
import de.biomedical_imaging.traJ.features.SplineCurveSpatialFeature;
import de.biomedical_imaging.traJ.features.StandardDeviationDirectionFeature;
import de.biomedical_imaging.traJ.features.TrappedProbabilityFeature;
import de.biomedical_imaging.traJ.simulation.AbstractSimulator;
import de.biomedical_imaging.traJ.simulation.AbstractSphereObstacle;
import de.biomedical_imaging.traJ.simulation.ActiveTransportSimulator;
import de.biomedical_imaging.traJ.simulation.AnomalousDiffusionScene;
import de.biomedical_imaging.traJ.simulation.AnomalousDiffusionSimulator;
import de.biomedical_imaging.traJ.simulation.AnomalousDiffusionWMSimulation;
import de.biomedical_imaging.traJ.simulation.CentralRandomNumberGenerator;
import de.biomedical_imaging.traJ.simulation.CombinedSimulator;
import de.biomedical_imaging.traJ.simulation.ConfinedDiffusionSimulator;
import de.biomedical_imaging.traJ.simulation.FreeDiffusionSimulator;
import de.biomedical_imaging.traJ.simulation.ImmobileSphereObstacle;
import de.biomedical_imaging.traJ.simulation.SimulationUtil;
import de.biomedical_imaging.traj.math.ActiveTransportMSDLineFit;
import de.biomedical_imaging.traj.math.MomentsCalculator;

public class TrajMain {
	static CentralRandomNumberGenerator r;
	public static void main(String[] args) {

		
		
		
	}
	
	public static void generateMSDCurveS(){
		CentralRandomNumberGenerator.getInstance().setSeed(10);
		double diffusioncoefficient = 1;
		double timelag = 1;
		int dimension = 2;
		int N = 100;
		int Nsteps = 300;
		double boundedness = 4;
		double R = 3;
		double radius = Math.sqrt(BoundednessFeature.a(Nsteps)*diffusioncoefficient*timelag/(4*boundedness));
		AbstractSimulator sim1 = new FreeDiffusionSimulator(diffusioncoefficient, timelag, dimension, Nsteps);
		double drift = Math.sqrt(R*4*diffusioncoefficient/Nsteps);
		AbstractSimulator sim2 = new ActiveTransportSimulator(drift, 0, timelag, dimension, Nsteps);
		AbstractSimulator sim = new ConfinedDiffusionSimulator(diffusioncoefficient, timelag, radius, dimension, Nsteps);
		
		ArrayList<Trajectory> tracks = new ArrayList<Trajectory>(N);
		for(int i = 0; i < N; i++){
			Trajectory t = sim.generateTrajectory();
			t = t.subList(0, Nsteps);
			tracks.add(t);
			System.out.println("Progress: " + 1.0*i/N*100);
		}
		double[] msds = new double[Nsteps/3];
		double[] sd_msds = new double[Nsteps/3];
		double[] timelags = new double[Nsteps/3];
		Mean mean = new Mean();
		StandardDeviation sd = new StandardDeviation();
		int i = 0;
		int k = 0;
		//radius = radius*0.86;
		while( i < Nsteps/3){
			timelags[k] = (i+1)*timelag;
			int j = 0;
			double[] values = new double[N];
			for (Trajectory t : tracks) {
				MeanSquaredDisplacmentFeature msd = new MeanSquaredDisplacmentFeature(t, (i+1));
				values[j] = msd.evaluate()[0];
				j++;
			}
			msds[k]=mean.evaluate(values);
			sd_msds[k] = sd.evaluate(values);
			double anomModel = 4*diffusioncoefficient*Math.pow((i+1)*timelag, 0.5);
			double A1=1;
			double A2=1;
			
			double confinedModel = radius*radius*(1-A1*Math.exp(-4*A2*diffusioncoefficient*(i+1)*timelag/(radius*radius)));
			System.out.println(timelags[k] + "\t" + msds[k] + "\t" + sd_msds[k] + " \t" + confinedModel);
			i+=3;
			k++;
		}
	}
	
	

}
