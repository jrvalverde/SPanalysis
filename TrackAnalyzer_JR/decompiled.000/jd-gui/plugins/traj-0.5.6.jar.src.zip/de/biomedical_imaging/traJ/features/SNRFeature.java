package de.biomedical_imaging.traJ.features;

import de.biomedical_imaging.traJ.Trajectory;
import de.biomedical_imaging.traJ.DiffusionCoefficientEstimator.CovarianceDiffusionCoefficientEstimator;
import de.biomedical_imaging.traJ.DiffusionCoefficientEstimator.RegressionDiffusionCoefficientEstimator;

public class SNRFeature extends AbstractTrajectoryFeature {

	private Trajectory t ;
	private double fps;
	private double timelag;
	
	public SNRFeature(Trajectory t, double timelag) {
		this.t = t;
		this.timelag = timelag;
		fps = 1/timelag;
	}
	
	@Override
	public double[] evaluate() {
		RegressionDiffusionCoefficientEstimator regest = new RegressionDiffusionCoefficientEstimator(t, fps, 1, 2);
		CovarianceDiffusionCoefficientEstimator covest = new CovarianceDiffusionCoefficientEstimator(t, fps);
		double D = regest.evaluate()[0];
		double locnoise = (covest.evaluate()[1]+covest.evaluate()[2])/2;
		result = new double[]{Math.sqrt(D*timelag)/locnoise};
		return 	result;
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return "Signal to noise ratio";
	}

	@Override
	public String getShortName() {
		// TODO Auto-generated method stub
		return "SNR";
	}

	@Override
	public void setTrajectory(Trajectory t) {
		this.t = t;
	}

}
