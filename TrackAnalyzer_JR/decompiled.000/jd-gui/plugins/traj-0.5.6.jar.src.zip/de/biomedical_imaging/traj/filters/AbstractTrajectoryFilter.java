package de.biomedical_imaging.traj.filters;

import de.biomedical_imaging.traJ.Trajectory;

public abstract class AbstractTrajectoryFilter {
	
	public abstract Trajectory apply();
	
	public abstract void setTrajectory(Trajectory t);

}
