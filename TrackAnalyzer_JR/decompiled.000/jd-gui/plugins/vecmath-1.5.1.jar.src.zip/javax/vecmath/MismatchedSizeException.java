/*    */ package javax.vecmath;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MismatchedSizeException
/*    */   extends RuntimeException
/*    */ {
/*    */   public MismatchedSizeException() {}
/*    */   
/*    */   public MismatchedSizeException(String paramString) {
/* 34 */     super(paramString);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/vecmath-1.5.1.jar!/javax/vecmath/MismatchedSizeException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */