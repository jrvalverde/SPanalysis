/*     */ package javax.vecmath;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Color3b
/*     */   extends Tuple3b
/*     */   implements Serializable
/*     */ {
/*     */   static final long serialVersionUID = 6632576088353444794L;
/*     */   
/*     */   public Color3b(byte paramByte1, byte paramByte2, byte paramByte3) {
/*  45 */     super(paramByte1, paramByte2, paramByte3);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Color3b(byte[] paramArrayOfbyte) {
/*  54 */     super(paramArrayOfbyte);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Color3b(Color3b paramColor3b) {
/*  63 */     super(paramColor3b);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Color3b(Tuple3b paramTuple3b) {
/*  72 */     super(paramTuple3b);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Color3b(Color paramColor) {
/*  88 */     super((byte)paramColor.getRed(), (byte)paramColor.getGreen(), (byte)paramColor.getBlue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Color3b() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void set(Color paramColor) {
/* 113 */     this.x = (byte)paramColor.getRed();
/* 114 */     this.y = (byte)paramColor.getGreen();
/* 115 */     this.z = (byte)paramColor.getBlue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Color get() {
/* 128 */     int i = this.x & 0xFF;
/* 129 */     int j = this.y & 0xFF;
/* 130 */     int k = this.z & 0xFF;
/*     */     
/* 132 */     return new Color(i, j, k);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/vecmath-1.5.1.jar!/javax/vecmath/Color3b.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */