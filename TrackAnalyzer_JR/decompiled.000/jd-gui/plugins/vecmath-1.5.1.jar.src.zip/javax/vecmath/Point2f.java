/*     */ package javax.vecmath;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Point2f
/*     */   extends Tuple2f
/*     */   implements Serializable
/*     */ {
/*     */   static final long serialVersionUID = -4801347926528714435L;
/*     */   
/*     */   public Point2f(float paramFloat1, float paramFloat2) {
/*  34 */     super(paramFloat1, paramFloat2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point2f(float[] paramArrayOffloat) {
/*  44 */     super(paramArrayOffloat);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point2f(Point2f paramPoint2f) {
/*  54 */     super(paramPoint2f);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point2f(Point2d paramPoint2d) {
/*  63 */     super(paramPoint2d);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point2f(Tuple2d paramTuple2d) {
/*  74 */     super(paramTuple2d);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point2f(Tuple2f paramTuple2f) {
/*  85 */     super(paramTuple2f);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point2f() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final float distanceSquared(Point2f paramPoint2f) {
/* 105 */     float f1 = this.x - paramPoint2f.x;
/* 106 */     float f2 = this.y - paramPoint2f.y;
/* 107 */     return f1 * f1 + f2 * f2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final float distance(Point2f paramPoint2f) {
/* 118 */     float f1 = this.x - paramPoint2f.x;
/* 119 */     float f2 = this.y - paramPoint2f.y;
/* 120 */     return (float)Math.sqrt((f1 * f1 + f2 * f2));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final float distanceL1(Point2f paramPoint2f) {
/* 131 */     return Math.abs(this.x - paramPoint2f.x) + Math.abs(this.y - paramPoint2f.y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final float distanceLinf(Point2f paramPoint2f) {
/* 142 */     return Math.max(Math.abs(this.x - paramPoint2f.x), Math.abs(this.y - paramPoint2f.y));
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/vecmath-1.5.1.jar!/javax/vecmath/Point2f.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */