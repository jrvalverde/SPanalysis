/*     */ package javax.vecmath;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Vector4d
/*     */   extends Tuple4d
/*     */   implements Serializable
/*     */ {
/*     */   static final long serialVersionUID = 3938123424117448700L;
/*     */   
/*     */   public Vector4d(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/*  36 */     super(paramDouble1, paramDouble2, paramDouble3, paramDouble4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector4d(double[] paramArrayOfdouble) {
/*  46 */     super(paramArrayOfdouble);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector4d(Vector4d paramVector4d) {
/*  55 */     super(paramVector4d);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector4d(Vector4f paramVector4f) {
/*  64 */     super(paramVector4f);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector4d(Tuple4f paramTuple4f) {
/*  73 */     super(paramTuple4f);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector4d(Tuple4d paramTuple4d) {
/*  82 */     super(paramTuple4d);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector4d(Tuple3d paramTuple3d) {
/*  96 */     super(paramTuple3d.x, paramTuple3d.y, paramTuple3d.z, 0.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector4d() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void set(Tuple3d paramTuple3d) {
/* 118 */     this.x = paramTuple3d.x;
/* 119 */     this.y = paramTuple3d.y;
/* 120 */     this.z = paramTuple3d.z;
/* 121 */     this.w = 0.0D;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final double length() {
/* 131 */     return Math.sqrt(this.x * this.x + this.y * this.y + this.z * this.z + this.w * this.w);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final double lengthSquared() {
/* 142 */     return this.x * this.x + this.y * this.y + this.z * this.z + this.w * this.w;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final double dot(Vector4d paramVector4d) {
/* 154 */     return this.x * paramVector4d.x + this.y * paramVector4d.y + this.z * paramVector4d.z + this.w * paramVector4d.w;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void normalize(Vector4d paramVector4d) {
/* 166 */     double d = 1.0D / Math.sqrt(paramVector4d.x * paramVector4d.x + paramVector4d.y * paramVector4d.y + paramVector4d.z * paramVector4d.z + paramVector4d.w * paramVector4d.w);
/* 167 */     paramVector4d.x *= d;
/* 168 */     paramVector4d.y *= d;
/* 169 */     paramVector4d.z *= d;
/* 170 */     paramVector4d.w *= d;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void normalize() {
/* 181 */     double d = 1.0D / Math.sqrt(this.x * this.x + this.y * this.y + this.z * this.z + this.w * this.w);
/*     */     
/* 183 */     this.x *= d;
/* 184 */     this.y *= d;
/* 185 */     this.z *= d;
/* 186 */     this.w *= d;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final double angle(Vector4d paramVector4d) {
/* 199 */     double d = dot(paramVector4d) / length() * paramVector4d.length();
/* 200 */     if (d < -1.0D) d = -1.0D; 
/* 201 */     if (d > 1.0D) d = 1.0D; 
/* 202 */     return Math.acos(d);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/vecmath-1.5.1.jar!/javax/vecmath/Vector4d.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */