/*     */ package javax.vecmath;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Vector4f
/*     */   extends Tuple4f
/*     */   implements Serializable
/*     */ {
/*     */   static final long serialVersionUID = 8749319902347760659L;
/*     */   
/*     */   public Vector4f(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/*  36 */     super(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector4f(float[] paramArrayOffloat) {
/*  46 */     super(paramArrayOffloat);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector4f(Vector4f paramVector4f) {
/*  56 */     super(paramVector4f);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector4f(Vector4d paramVector4d) {
/*  66 */     super(paramVector4d);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector4f(Tuple4f paramTuple4f) {
/*  76 */     super(paramTuple4f);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector4f(Tuple4d paramTuple4d) {
/*  86 */     super(paramTuple4d);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector4f(Tuple3f paramTuple3f) {
/* 100 */     super(paramTuple3f.x, paramTuple3f.y, paramTuple3f.z, 0.0F);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector4f() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void set(Tuple3f paramTuple3f) {
/* 122 */     this.x = paramTuple3f.x;
/* 123 */     this.y = paramTuple3f.y;
/* 124 */     this.z = paramTuple3f.z;
/* 125 */     this.w = 0.0F;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final float length() {
/* 135 */     return (float)Math.sqrt((this.x * this.x + this.y * this.y + this.z * this.z + this.w * this.w));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final float lengthSquared() {
/* 146 */     return this.x * this.x + this.y * this.y + this.z * this.z + this.w * this.w;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final float dot(Vector4f paramVector4f) {
/* 157 */     return this.x * paramVector4f.x + this.y * paramVector4f.y + this.z * paramVector4f.z + this.w * paramVector4f.w;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void normalize(Vector4f paramVector4f) {
/* 169 */     float f = (float)(1.0D / Math.sqrt((paramVector4f.x * paramVector4f.x + paramVector4f.y * paramVector4f.y + paramVector4f.z * paramVector4f.z + paramVector4f.w * paramVector4f.w)));
/*     */     
/* 171 */     paramVector4f.x *= f;
/* 172 */     paramVector4f.y *= f;
/* 173 */     paramVector4f.z *= f;
/* 174 */     paramVector4f.w *= f;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void normalize() {
/* 185 */     float f = (float)(1.0D / Math.sqrt((this.x * this.x + this.y * this.y + this.z * this.z + this.w * this.w)));
/*     */     
/* 187 */     this.x *= f;
/* 188 */     this.y *= f;
/* 189 */     this.z *= f;
/* 190 */     this.w *= f;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final float angle(Vector4f paramVector4f) {
/* 203 */     double d = (dot(paramVector4f) / length() * paramVector4f.length());
/* 204 */     if (d < -1.0D) d = -1.0D; 
/* 205 */     if (d > 1.0D) d = 1.0D; 
/* 206 */     return (float)Math.acos(d);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/vecmath-1.5.1.jar!/javax/vecmath/Vector4f.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */