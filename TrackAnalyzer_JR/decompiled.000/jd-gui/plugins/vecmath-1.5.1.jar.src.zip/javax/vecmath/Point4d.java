/*     */ package javax.vecmath;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Point4d
/*     */   extends Tuple4d
/*     */   implements Serializable
/*     */ {
/*     */   static final long serialVersionUID = 1733471895962736949L;
/*     */   
/*     */   public Point4d(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/*  37 */     super(paramDouble1, paramDouble2, paramDouble3, paramDouble4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point4d(double[] paramArrayOfdouble) {
/*  47 */     super(paramArrayOfdouble);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point4d(Point4d paramPoint4d) {
/*  57 */     super(paramPoint4d);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point4d(Point4f paramPoint4f) {
/*  67 */     super(paramPoint4f);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point4d(Tuple4f paramTuple4f) {
/*  77 */     super(paramTuple4f);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point4d(Tuple4d paramTuple4d) {
/*  87 */     super(paramTuple4d);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point4d(Tuple3d paramTuple3d) {
/* 101 */     super(paramTuple3d.x, paramTuple3d.y, paramTuple3d.z, 1.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point4d() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void set(Tuple3d paramTuple3d) {
/* 123 */     this.x = paramTuple3d.x;
/* 124 */     this.y = paramTuple3d.y;
/* 125 */     this.z = paramTuple3d.z;
/* 126 */     this.w = 1.0D;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final double distanceSquared(Point4d paramPoint4d) {
/* 139 */     double d1 = this.x - paramPoint4d.x;
/* 140 */     double d2 = this.y - paramPoint4d.y;
/* 141 */     double d3 = this.z - paramPoint4d.z;
/* 142 */     double d4 = this.w - paramPoint4d.w;
/* 143 */     return d1 * d1 + d2 * d2 + d3 * d3 + d4 * d4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final double distance(Point4d paramPoint4d) {
/* 156 */     double d1 = this.x - paramPoint4d.x;
/* 157 */     double d2 = this.y - paramPoint4d.y;
/* 158 */     double d3 = this.z - paramPoint4d.z;
/* 159 */     double d4 = this.w - paramPoint4d.w;
/* 160 */     return Math.sqrt(d1 * d1 + d2 * d2 + d3 * d3 + d4 * d4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final double distanceL1(Point4d paramPoint4d) {
/* 172 */     return Math.abs(this.x - paramPoint4d.x) + Math.abs(this.y - paramPoint4d.y) + Math.abs(this.z - paramPoint4d.z) + Math.abs(this.w - paramPoint4d.w);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final double distanceLinf(Point4d paramPoint4d) {
/* 185 */     double d1 = Math.max(Math.abs(this.x - paramPoint4d.x), Math.abs(this.y - paramPoint4d.y));
/* 186 */     double d2 = Math.max(Math.abs(this.z - paramPoint4d.z), Math.abs(this.w - paramPoint4d.w));
/*     */     
/* 188 */     return Math.max(d1, d2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void project(Point4d paramPoint4d) {
/* 201 */     double d = 1.0D / paramPoint4d.w;
/* 202 */     paramPoint4d.x *= d;
/* 203 */     paramPoint4d.y *= d;
/* 204 */     paramPoint4d.z *= d;
/* 205 */     this.w = 1.0D;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/vecmath-1.5.1.jar!/javax/vecmath/Point4d.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */