/*     */ package org.renjin.gcc;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.renjin.gcc.analysis.AddressableFinder;
/*     */ import org.renjin.gcc.analysis.AddressableSimplifier;
/*     */ import org.renjin.gcc.analysis.FunctionBodyTransformer;
/*     */ import org.renjin.gcc.analysis.FunctionCallPruner;
/*     */ import org.renjin.gcc.analysis.LocalVariableInitializer;
/*     */ import org.renjin.gcc.analysis.LocalVariablePruner;
/*     */ import org.renjin.gcc.analysis.PmfRewriter;
/*     */ import org.renjin.gcc.analysis.ResultDeclRewriter;
/*     */ import org.renjin.gcc.analysis.VoidPointerTypeDeducer;
/*     */ import org.renjin.gcc.annotations.GlobalVar;
/*     */ import org.renjin.gcc.codegen.CodeGenerationContext;
/*     */ import org.renjin.gcc.codegen.FunctionGenerator;
/*     */ import org.renjin.gcc.codegen.GlobalVarMerger;
/*     */ import org.renjin.gcc.codegen.GlobalVarTransformer;
/*     */ import org.renjin.gcc.codegen.ProvidedVarTransformer;
/*     */ import org.renjin.gcc.codegen.TrampolineClassGenerator;
/*     */ import org.renjin.gcc.codegen.UnitClassGenerator;
/*     */ import org.renjin.gcc.codegen.call.CallGenerator;
/*     */ import org.renjin.gcc.codegen.call.FunctionCallGenerator;
/*     */ import org.renjin.gcc.codegen.lib.SymbolLibrary;
/*     */ import org.renjin.gcc.codegen.type.TypeOracle;
/*     */ import org.renjin.gcc.gimple.GimpleCompilationUnit;
/*     */ import org.renjin.gcc.gimple.GimpleFunction;
/*     */ import org.renjin.gcc.gimple.GimpleParser;
/*     */ import org.renjin.gcc.link.LinkSymbol;
/*     */ import org.renjin.gcc.logging.LogManager;
/*     */ import org.renjin.gcc.runtime.Builtins;
/*     */ import org.renjin.gcc.runtime.Mathlib;
/*     */ import org.renjin.gcc.runtime.PosixThreads;
/*     */ import org.renjin.gcc.runtime.Std;
/*     */ import org.renjin.gcc.runtime.Stdlib;
/*     */ import org.renjin.gcc.runtime.Stdlib2;
/*     */ import org.renjin.gcc.symbols.GlobalSymbolTable;
/*     */ import org.renjin.gcc.symbols.SymbolTable;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ import org.renjin.repackaged.guava.annotations.VisibleForTesting;
/*     */ import org.renjin.repackaged.guava.base.Preconditions;
/*     */ import org.renjin.repackaged.guava.collect.Lists;
/*     */ import org.renjin.repackaged.guava.collect.Maps;
/*     */ import org.renjin.repackaged.guava.collect.Ordering;
/*     */ import org.renjin.repackaged.guava.collect.Sets;
/*     */ import org.renjin.repackaged.guava.io.Files;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GimpleCompiler
/*     */ {
/*     */   public static boolean TRACE = false;
/*     */   private File outputDirectory;
/*     */   private File javadocOutputDirectory;
/*     */   private String packageName;
/*     */   private boolean verbose;
/*     */   private GlobalSymbolTable globalSymbolTable;
/*  78 */   private List<FunctionBodyTransformer> functionBodyTransformers = Lists.newArrayList();
/*     */   
/*  80 */   private final TypeOracle typeOracle = new TypeOracle();
/*     */   
/*  82 */   private final Map<String, Type> providedRecordTypes = Maps.newHashMap();
/*  83 */   private final Map<String, ProvidedGlobalVar> providedVariables = Maps.newHashMap();
/*     */   
/*  85 */   private final List<GimpleCompilerPlugin> plugins = new ArrayList<>();
/*     */   
/*     */   private String trampolineClassName;
/*  88 */   private String recordClassPrefix = "record";
/*     */   
/*  90 */   private final LogManager logManager = new LogManager(System.err);
/*     */   
/*     */   public GimpleCompiler() {
/*  93 */     this.functionBodyTransformers.add(AddressableSimplifier.INSTANCE);
/*  94 */     this.functionBodyTransformers.add(FunctionCallPruner.INSTANCE);
/*  95 */     this.functionBodyTransformers.add(LocalVariablePruner.INSTANCE);
/*  96 */     this.functionBodyTransformers.add(VoidPointerTypeDeducer.INSTANCE);
/*  97 */     this.functionBodyTransformers.add(ResultDeclRewriter.INSTANCE);
/*  98 */     this.functionBodyTransformers.add(LocalVariableInitializer.INSTANCE);
/*  99 */     this.globalSymbolTable = new GlobalSymbolTable(this.typeOracle, this.providedVariables);
/* 100 */     this.globalSymbolTable.addDefaults();
/* 101 */     addReferenceClass(Builtins.class);
/* 102 */     addReferenceClass(Stdlib.class);
/* 103 */     addReferenceClass(Stdlib2.class);
/* 104 */     addReferenceClass(Mathlib.class);
/* 105 */     addReferenceClass(Std.class);
/* 106 */     addReferenceClass(PosixThreads.class);
/*     */   }
/*     */   
/*     */   public LogManager getLogManager() {
/* 110 */     return this.logManager;
/*     */   }
/*     */   
/*     */   public void setLoggingDirectory(File logDir) {
/* 114 */     this.logManager.setLoggingDirectory(logDir);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPackageName(String name) {
/* 123 */     this.packageName = name;
/*     */   }
/*     */   
/*     */   public String getPackageName() {
/* 127 */     return this.packageName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOutputDirectory(File directory) {
/* 135 */     this.outputDirectory = directory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setJavadocOutputDirectory(File javadocOutputDirectory) {
/* 146 */     this.javadocOutputDirectory = javadocOutputDirectory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setClassName(String className) {
/* 153 */     this.trampolineClassName = className;
/*     */   }
/*     */   
/*     */   public void addReferenceClass(Class<?> clazz) {
/* 157 */     this.globalSymbolTable.addMethods(clazz);
/*     */     
/* 159 */     for (Method method : clazz.getMethods()) {
/* 160 */       if (method.getAnnotation(GlobalVar.class) != null) {
/* 161 */         if ((method.getParameterTypes()).length != 0) {
/* 162 */           throw new IllegalStateException("Method " + method + " cannot be used as a @" + GlobalVar.class
/* 163 */               .getSimpleName() + ", it must have zero arguments");
/*     */         }
/* 165 */         this.providedVariables.put(method.getName(), new ProvidedGlobalVarGetter(method));
/*     */       } 
/*     */     } 
/*     */     
/* 169 */     for (Field field : clazz.getFields()) {
/* 170 */       if (Modifier.isStatic(field.getModifiers()) && Modifier.isPublic(field.getModifiers()) && field
/* 171 */         .getAnnotation(Deprecated.class) == null) {
/* 172 */         addVariable(field.getName(), field);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public void addMathLibrary() {
/* 178 */     this.globalSymbolTable.addMethod("log", Math.class);
/* 179 */     this.globalSymbolTable.addMethod("exp", Math.class);
/*     */   }
/*     */   
/*     */   public void addLibrary(SymbolLibrary lib) {
/* 183 */     this.globalSymbolTable.addLibrary(lib);
/*     */   }
/*     */   
/*     */   public void addTransformer(FunctionBodyTransformer transformer) {
/* 187 */     this.functionBodyTransformers.add(transformer);
/*     */   }
/*     */   
/*     */   public void addPlugin(GimpleCompilerPlugin plugin) {
/* 191 */     this.plugins.add(plugin);
/*     */   }
/*     */   
/*     */   public void addMethod(String functionName, Class declaringClass, String methodName) {
/* 195 */     this.globalSymbolTable.addMethod(functionName, declaringClass, methodName);
/*     */   }
/*     */   
/*     */   public void addRecordClass(String typeName, Class recordClass) {
/* 199 */     addRecordClass(typeName, Type.getType(recordClass));
/*     */   }
/*     */   
/*     */   public void addRecordClass(String typeName, Type recordClass) {
/* 203 */     this.providedRecordTypes.put(typeName, recordClass);
/*     */   }
/*     */   
/*     */   public void compileSources(List<File> sourceFiles) throws Exception {
/* 207 */     GimpleParser parser = new GimpleParser();
/*     */     
/* 209 */     List<GimpleCompilationUnit> units = new ArrayList<>();
/* 210 */     for (File sourceFile : sourceFiles) {
/*     */       try {
/* 212 */         units.add(parser.parse(sourceFile));
/* 213 */       } catch (Exception e) {
/* 214 */         throw new IOException("Exception parsing gimple file " + sourceFile.getName(), e);
/*     */       } 
/*     */     } 
/* 217 */     compile(units);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void compile(List<GimpleCompilationUnit> units) throws Exception {
/*     */     try {
/* 228 */       PmfRewriter.rewrite(units);
/* 229 */       GlobalVarMerger.merge(units);
/*     */       
/* 231 */       this.typeOracle.initRecords(units, this.providedRecordTypes);
/*     */ 
/*     */       
/* 234 */       transform(units);
/*     */ 
/*     */       
/* 237 */       AddressableFinder addressableFinder = new AddressableFinder(units);
/* 238 */       addressableFinder.mark();
/*     */ 
/*     */       
/* 241 */       List<GlobalVarTransformer> globalVarTransformers = new ArrayList<>();
/* 242 */       globalVarTransformers.add(new ProvidedVarTransformer(this.typeOracle, this.providedVariables));
/* 243 */       for (GimpleCompilerPlugin plugin : this.plugins) {
/* 244 */         globalVarTransformers.addAll(plugin.createGlobalVarTransformers());
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 250 */       List<UnitClassGenerator> unitClassGenerators = Lists.newArrayList();
/* 251 */       Map<GimpleCompilationUnit, String> unitNames = nameCompilationUnits(units);
/* 252 */       for (GimpleCompilationUnit unit : units) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 257 */         UnitClassGenerator generator = new UnitClassGenerator(this.typeOracle, this.globalSymbolTable, globalVarTransformers, unit, unitNames.get(unit));
/* 258 */         unitClassGenerators.add(generator);
/*     */       } 
/*     */ 
/*     */       
/* 262 */       Map<GimpleCompilationUnit, SymbolTable> symbolTableMap = new HashMap<>();
/* 263 */       for (UnitClassGenerator generator : unitClassGenerators) {
/* 264 */         generator.emit(this.logManager);
/* 265 */         writeClass(generator.getClassName(), generator.toByteArray());
/*     */         
/* 267 */         if (this.trampolineClassName == null && this.javadocOutputDirectory != null) {
/* 268 */           generator.emitJavaDoc(this.javadocOutputDirectory);
/*     */         }
/*     */         
/* 271 */         symbolTableMap.put(generator.getUnit(), generator.getSymbolTable());
/*     */       } 
/*     */ 
/*     */       
/* 275 */       writeLinkMetadata(unitClassGenerators);
/*     */ 
/*     */       
/* 278 */       if (this.trampolineClassName != null) {
/* 279 */         writeTrampolineClass();
/*     */       }
/*     */       
/* 282 */       writePluginClasses(this.globalSymbolTable, symbolTableMap);
/*     */     } finally {
/*     */       
/*     */       try {
/* 286 */         this.logManager.finish();
/* 287 */       } catch (Exception e) {
/* 288 */         System.out.println("Failed to write logs");
/* 289 */         e.printStackTrace();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private Map<GimpleCompilationUnit, String> nameCompilationUnits(List<GimpleCompilationUnit> units) {
/* 296 */     units.sort((Comparator<? super GimpleCompilationUnit>)Ordering.natural().onResultOf(u -> u.getSourceFile().getAbsolutePath()));
/*     */     
/* 298 */     Map<String, Integer> nameCounter = new HashMap<>();
/* 299 */     Map<GimpleCompilationUnit, String> nameMap = new HashMap<>();
/* 300 */     for (GimpleCompilationUnit unit : units) {
/* 301 */       String uniqueClassName, className = classNameForUnit(unit.getName());
/* 302 */       int duplicateIndex = ((Integer)nameCounter.getOrDefault(className, Integer.valueOf(0))).intValue();
/*     */       
/* 304 */       if (duplicateIndex == 0) {
/* 305 */         uniqueClassName = className;
/*     */       } else {
/* 307 */         uniqueClassName = className + "$" + duplicateIndex;
/*     */       } 
/* 309 */       nameMap.put(unit, uniqueClassName);
/* 310 */       nameCounter.put(className, Integer.valueOf(duplicateIndex + 1));
/*     */     } 
/*     */     
/* 313 */     return nameMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeLinkMetadata(List<UnitClassGenerator> unitClassGenerators) throws IOException {
/* 320 */     for (Map.Entry<String, CallGenerator> entry : (Iterable<Map.Entry<String, CallGenerator>>)this.globalSymbolTable.getFunctions()) {
/* 321 */       if (entry.getValue() instanceof FunctionCallGenerator) {
/* 322 */         FunctionCallGenerator functionCallGenerator = (FunctionCallGenerator)entry.getValue();
/* 323 */         if (functionCallGenerator.getStrategy() instanceof FunctionGenerator) {
/* 324 */           FunctionGenerator functionGenerator = (FunctionGenerator)functionCallGenerator.getStrategy();
/* 325 */           for (String mangledName : functionGenerator.getMangledNames()) {
/* 326 */             LinkSymbol symbol = LinkSymbol.forFunction(mangledName, functionGenerator.getMethodHandle());
/*     */             try {
/* 328 */               symbol.write(this.outputDirectory);
/* 329 */             } catch (FileNotFoundException e) {
/* 330 */               System.err.println("Exception writing link metadata for " + symbol.getName() + ": " + e.getMessage());
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 337 */     for (UnitClassGenerator unit : unitClassGenerators) {
/* 338 */       for (LinkSymbol symbol : unit.getGlobalVariableSymbols()) {
/* 339 */         symbol.write(this.outputDirectory);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String classNameForUnit(String className) {
/* 349 */     if (this.trampolineClassName != null) {
/* 350 */       return getInternalClassName(className) + "__";
/*     */     }
/* 352 */     return getInternalClassName(className);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getInternalClassName(String className) {
/* 360 */     return (this.packageName + "." + sanitize(className)).replace('.', '/');
/*     */   }
/*     */   
/*     */   @VisibleForTesting
/*     */   static String sanitize(String name) {
/* 365 */     Preconditions.checkArgument((name.length() >= 1));
/*     */     
/* 367 */     StringBuilder className = new StringBuilder();
/*     */     
/* 369 */     int i = 0;
/* 370 */     if (Character.isJavaIdentifierStart(name.charAt(0))) {
/* 371 */       className.append(name.charAt(0));
/* 372 */       i++;
/*     */     } else {
/* 374 */       className.append('_');
/*     */     } 
/*     */     
/* 377 */     for (; i < name.length(); i++) {
/* 378 */       char c = name.charAt(i);
/* 379 */       if (Character.isJavaIdentifierPart(c)) {
/* 380 */         className.append(c);
/*     */       } else {
/* 382 */         className.append("_");
/*     */       } 
/*     */     } 
/* 385 */     return className.toString();
/*     */   }
/*     */   
/*     */   public boolean isVerbose() {
/* 389 */     return this.verbose;
/*     */   }
/*     */   
/*     */   public void setVerbose(boolean verbose) {
/* 393 */     this.verbose = verbose;
/*     */   }
/*     */ 
/*     */   
/*     */   private void transform(List<GimpleCompilationUnit> units) {
/* 398 */     for (GimpleCompilationUnit unit : units) {
/* 399 */       if (TRACE) {
/* 400 */         System.out.println(unit);
/*     */       }
/* 402 */       for (GimpleFunction function : unit.getFunctions()) {
/* 403 */         if (!function.isEmpty()) {
/* 404 */           transformFunctionBody(this.logManager, unit, function);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void transformFunctionBody(LogManager logger, GimpleCompilationUnit unit, GimpleFunction function) {
/*     */     boolean updated;
/*     */     do {
/* 413 */       updated = false;
/* 414 */       for (FunctionBodyTransformer transformer : this.functionBodyTransformers) {
/* 415 */         if (transformer.transform(logger, unit, function)) {
/* 416 */           updated = true;
/*     */         }
/*     */       } 
/* 419 */     } while (updated);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeTrampolineClass() throws IOException {
/* 429 */     TrampolineClassGenerator classGenerator = new TrampolineClassGenerator(getInternalClassName(this.trampolineClassName));
/*     */     
/* 431 */     Set<String> names = Sets.newHashSet();
/*     */     
/* 433 */     for (Map.Entry<String, CallGenerator> entry : (Iterable<Map.Entry<String, CallGenerator>>)this.globalSymbolTable.getFunctions()) {
/* 434 */       if (entry.getValue() instanceof FunctionCallGenerator) {
/* 435 */         FunctionCallGenerator functionCallGenerator = (FunctionCallGenerator)entry.getValue();
/* 436 */         if (functionCallGenerator.getStrategy() instanceof FunctionGenerator) {
/* 437 */           FunctionGenerator functionGenerator = (FunctionGenerator)functionCallGenerator.getStrategy();
/* 438 */           if (!names.contains(functionGenerator.getMangledName())) {
/* 439 */             classGenerator.emitTrampolineMethod(this.plugins, functionGenerator);
/* 440 */             names.add(functionGenerator.getMangledName());
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 446 */     writeClass(getInternalClassName(this.trampolineClassName), classGenerator.generateClassFile());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void writePluginClasses(final GlobalSymbolTable globalSymbolTable, final Map<GimpleCompilationUnit, SymbolTable> symbolTableMap) throws IOException {
/* 452 */     CodeGenerationContext context = new CodeGenerationContext()
/*     */       {
/*     */         public TypeOracle getTypeOracle() {
/* 455 */           return GimpleCompiler.this.typeOracle;
/*     */         }
/*     */ 
/*     */         
/*     */         public GlobalSymbolTable getGlobalSymbolTable() {
/* 460 */           return globalSymbolTable;
/*     */         }
/*     */ 
/*     */         
/*     */         public SymbolTable getSymbolTable(GimpleCompilationUnit unit) {
/* 465 */           return (SymbolTable)symbolTableMap.get(unit);
/*     */         }
/*     */ 
/*     */         
/*     */         public void writeClassFile(Type className, byte[] bytes) throws IOException {
/* 470 */           GimpleCompiler.this.writeClass(className.getInternalName(), bytes);
/*     */         }
/*     */       };
/*     */     
/* 474 */     for (GimpleCompilerPlugin plugin : this.plugins) {
/* 475 */       plugin.writeClasses(context);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeClass(String internalName, byte[] classByteArray) throws IOException {
/* 482 */     File classFile = new File(this.outputDirectory.getAbsolutePath() + File.separator + internalName + ".class");
/* 483 */     if (!classFile.getParentFile().exists()) {
/* 484 */       boolean created = classFile.getParentFile().mkdirs();
/* 485 */       if (!created) {
/* 486 */         throw new IOException("Failed to create directory for class file: " + classFile.getParentFile());
/*     */       }
/*     */     } 
/* 489 */     Files.write(classByteArray, classFile);
/*     */   }
/*     */   
/*     */   public void addVariable(String globalVariableName, Class<?> declaringClass) {
/*     */     try {
/* 494 */       addVariable(globalVariableName, declaringClass.getField(globalVariableName));
/* 495 */     } catch (NoSuchFieldException e) {
/* 496 */       throw new InternalCompilerException("Cannot find field", e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void addVariable(String name, Field field) {
/* 501 */     this.providedVariables.put(name, new ProvidedGlobalVarField(field));
/*     */   }
/*     */ 
/*     */   
/*     */   public String getRecordClassPrefix() {
/* 506 */     return this.recordClassPrefix;
/*     */   }
/*     */   
/*     */   public void setRecordClassPrefix(String recordClassPrefix) {
/* 510 */     this.recordClassPrefix = recordClassPrefix;
/*     */   }
/*     */   
/*     */   public void setLinkClassLoader(ClassLoader linkClassLoader) {
/* 514 */     this.globalSymbolTable.setLinkClassLoader(linkClassLoader);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/GimpleCompiler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */