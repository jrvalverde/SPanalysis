/*    */ package org.renjin.gcc.logging;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.renjin.gcc.gimple.GimpleFunction;
/*    */ import org.renjin.gcc.symbols.SymbolTable;
/*    */ import org.renjin.repackaged.asm.tree.MethodNode;
/*    */ import org.renjin.repackaged.guava.base.Charsets;
/*    */ import org.renjin.repackaged.guava.io.Resources;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HtmlFunctionRenderer
/*    */ {
/*    */   private SymbolTable symbolTable;
/*    */   private GimpleFunction gimpleFunction;
/*    */   private MethodNode methodNode;
/*    */   
/*    */   public HtmlFunctionRenderer(SymbolTable symbolTable, GimpleFunction gimpleFunction, MethodNode methodNode) {
/* 36 */     this.symbolTable = symbolTable;
/* 37 */     this.gimpleFunction = gimpleFunction;
/* 38 */     this.methodNode = methodNode;
/*    */   }
/*    */   
/*    */   public String render() throws IOException {
/* 42 */     return Resources.toString(Resources.getResource(HtmlFunctionRenderer.class, "function.html"), Charsets.UTF_8)
/* 43 */       .replace("__INPUT_SOURCE__", renderInputSource())
/* 44 */       .replace("__GIMPLE__", renderGimple())
/* 45 */       .replace("__BYTECODE__", renderBytecode());
/*    */   }
/*    */ 
/*    */   
/*    */   private String renderInputSource() {
/* 50 */     StringBuilder html = new StringBuilder();
/* 51 */     for (InputSource source : InputSource.from(this.gimpleFunction)) {
/* 52 */       source.render(html);
/*    */     }
/* 54 */     return html.toString();
/*    */   }
/*    */ 
/*    */   
/*    */   private CharSequence renderGimple() {
/* 59 */     return (new GimpleRenderer(this.symbolTable, this.gimpleFunction.getUnit())).renderFunction(this.gimpleFunction);
/*    */   }
/*    */   
/*    */   private CharSequence renderBytecode() {
/* 63 */     return (new BytecodeRenderer(this.methodNode)).render();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/logging/HtmlFunctionRenderer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */