/*     */ package org.renjin.gcc.symbols;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import java.util.Set;
/*     */ import org.renjin.gcc.InternalCompilerException;
/*     */ import org.renjin.gcc.ProvidedGlobalVar;
/*     */ import org.renjin.gcc.ProvidedGlobalVarField;
/*     */ import org.renjin.gcc.annotations.GlobalVar;
/*     */ import org.renjin.gcc.annotations.Noop;
/*     */ import org.renjin.gcc.codegen.call.BuiltinAssumeAlignedGenerator;
/*     */ import org.renjin.gcc.codegen.call.BuiltinClzGenerator;
/*     */ import org.renjin.gcc.codegen.call.BuiltinConstantPredicate;
/*     */ import org.renjin.gcc.codegen.call.BuiltinExpectGenerator;
/*     */ import org.renjin.gcc.codegen.call.BuiltinObjectSize;
/*     */ import org.renjin.gcc.codegen.call.CallGenerator;
/*     */ import org.renjin.gcc.codegen.call.CallocGenerator;
/*     */ import org.renjin.gcc.codegen.call.FreeCallGenerator;
/*     */ import org.renjin.gcc.codegen.call.FunctionCallGenerator;
/*     */ import org.renjin.gcc.codegen.call.InvocationStrategy;
/*     */ import org.renjin.gcc.codegen.call.MallocCallGenerator;
/*     */ import org.renjin.gcc.codegen.call.MemCmpCallGenerator;
/*     */ import org.renjin.gcc.codegen.call.MemCopyCallGenerator;
/*     */ import org.renjin.gcc.codegen.call.MemSetGenerator;
/*     */ import org.renjin.gcc.codegen.call.MethodHandleGenerator;
/*     */ import org.renjin.gcc.codegen.call.NoopCallGenerator;
/*     */ import org.renjin.gcc.codegen.call.ReallocCallGenerator;
/*     */ import org.renjin.gcc.codegen.call.StaticMethodStrategy;
/*     */ import org.renjin.gcc.codegen.call.UnsatisfiedLinkCallGenerator;
/*     */ import org.renjin.gcc.codegen.call.VarArgsEndGenerator;
/*     */ import org.renjin.gcc.codegen.call.VarArgsStartGenerator;
/*     */ import org.renjin.gcc.codegen.cpp.BeginCatchCallGenerator;
/*     */ import org.renjin.gcc.codegen.cpp.EhPointerCallGenerator;
/*     */ import org.renjin.gcc.codegen.cpp.EndCatchGenerator;
/*     */ import org.renjin.gcc.codegen.cpp.RethrowGenerator;
/*     */ import org.renjin.gcc.codegen.cpp.ThrowCallGenerator;
/*     */ import org.renjin.gcc.codegen.expr.Expressions;
/*     */ import org.renjin.gcc.codegen.expr.GExpr;
/*     */ import org.renjin.gcc.codegen.expr.JExpr;
/*     */ import org.renjin.gcc.codegen.lib.SymbolFunction;
/*     */ import org.renjin.gcc.codegen.lib.SymbolLibrary;
/*     */ import org.renjin.gcc.codegen.lib.SymbolMethod;
/*     */ import org.renjin.gcc.codegen.type.TypeOracle;
/*     */ import org.renjin.gcc.codegen.vptr.VPtrStrategy;
/*     */ import org.renjin.gcc.gimple.GimpleVarDecl;
/*     */ import org.renjin.gcc.gimple.expr.GimpleFunctionRef;
/*     */ import org.renjin.gcc.gimple.expr.GimpleSymbolRef;
/*     */ import org.renjin.gcc.gimple.type.GimpleType;
/*     */ import org.renjin.gcc.gimple.type.GimpleVoidType;
/*     */ import org.renjin.gcc.link.LinkSymbol;
/*     */ import org.renjin.gcc.runtime.Builtins;
/*     */ import org.renjin.repackaged.guava.base.Preconditions;
/*     */ import org.renjin.repackaged.guava.collect.Maps;
/*     */ 
/*     */ 
/*     */ public class GlobalSymbolTable
/*     */   implements SymbolTable
/*     */ {
/*  63 */   private ClassLoader linkClassLoader = getClass().getClassLoader();
/*     */   private TypeOracle typeOracle;
/*  65 */   private Map<String, CallGenerator> functions = Maps.newHashMap();
/*     */   private final Map<String, ProvidedGlobalVar> providedVariables;
/*  67 */   private final Map<String, GExpr> globalVariables = Maps.newHashMap();
/*     */   
/*     */   public GlobalSymbolTable(TypeOracle typeOracle, Map<String, ProvidedGlobalVar> providedVariables) {
/*  70 */     this.typeOracle = typeOracle;
/*  71 */     this.providedVariables = providedVariables;
/*     */   }
/*     */   
/*     */   public void setLinkClassLoader(ClassLoader linkClassLoader) {
/*  75 */     this.linkClassLoader = linkClassLoader;
/*     */   }
/*     */   public CallGenerator findCallGenerator(GimpleFunctionRef ref) {
/*     */     FunctionCallGenerator functionCallGenerator;
/*     */     UnsatisfiedLinkCallGenerator unsatisfiedLinkCallGenerator;
/*  80 */     String mangledName = ref.getName();
/*     */     
/*  82 */     CallGenerator generator = this.functions.get(mangledName);
/*     */ 
/*     */     
/*  85 */     if (generator == null) {
/*  86 */       Optional<LinkSymbol> linkSymbol = findLinkSymbol(mangledName);
/*  87 */       if (linkSymbol.isPresent()) {
/*  88 */         Method method = ((LinkSymbol)linkSymbol.get()).loadMethod(this.linkClassLoader);
/*  89 */         functionCallGenerator = new FunctionCallGenerator((InvocationStrategy)new StaticMethodStrategy(this.typeOracle, method));
/*  90 */         this.functions.put(mangledName, functionCallGenerator);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/*  95 */     if (functionCallGenerator == null) {
/*  96 */       unsatisfiedLinkCallGenerator = new UnsatisfiedLinkCallGenerator(mangledName);
/*  97 */       this.functions.put(mangledName, unsatisfiedLinkCallGenerator);
/*     */       
/*  99 */       System.err.println("Warning: undefined function " + mangledName + "; may throw exception at runtime");
/*     */     } 
/*     */     
/* 102 */     return (CallGenerator)unsatisfiedLinkCallGenerator;
/*     */   }
/*     */ 
/*     */   
/*     */   public JExpr findHandle(GimpleFunctionRef ref) {
/* 107 */     CallGenerator callGenerator = findCallGenerator(ref);
/* 108 */     if (callGenerator instanceof MethodHandleGenerator) {
/* 109 */       return ((MethodHandleGenerator)callGenerator).getMethodHandle();
/*     */     }
/* 111 */     throw new UnsupportedOperationException("callGenerator: " + callGenerator);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void addDefaults() {
/* 117 */     addFunction("malloc", (CallGenerator)new MallocCallGenerator(this.typeOracle));
/* 118 */     addFunction("alloca", (CallGenerator)new MallocCallGenerator(this.typeOracle));
/* 119 */     addFunction("free", (CallGenerator)new FreeCallGenerator());
/* 120 */     addFunction("realloc", (CallGenerator)new ReallocCallGenerator(this.typeOracle));
/* 121 */     addFunction("calloc", (CallGenerator)new CallocGenerator(this.typeOracle));
/*     */     
/* 123 */     addFunction("_Znwj", (CallGenerator)new MallocCallGenerator(this.typeOracle));
/* 124 */     addFunction("_Znaj", (CallGenerator)new MallocCallGenerator(this.typeOracle));
/* 125 */     addFunction("_ZdlPv", (CallGenerator)new FreeCallGenerator());
/* 126 */     addFunction("_ZdaPv", (CallGenerator)new FreeCallGenerator());
/*     */ 
/*     */     
/* 129 */     addFunction("__builtin_malloc__", (CallGenerator)new MallocCallGenerator(this.typeOracle));
/* 130 */     addFunction("__builtin_free__", (CallGenerator)new MallocCallGenerator(this.typeOracle));
/* 131 */     addFunction("__builtin_memcpy", (CallGenerator)new MemCopyCallGenerator(false));
/* 132 */     addFunction("__builtin_memcpy__", (CallGenerator)new MemCopyCallGenerator(false));
/* 133 */     addFunction("__builtin_memset__", (CallGenerator)new MemSetGenerator(this.typeOracle));
/* 134 */     addFunction("__memset_chk", (CallGenerator)new MemSetGenerator(this.typeOracle));
/*     */     
/* 136 */     addFunction("__builtin_va_start", (CallGenerator)new VarArgsStartGenerator());
/* 137 */     addFunction("__builtin_va_end", (CallGenerator)new VarArgsEndGenerator());
/*     */     
/* 139 */     addFunction("__builtin_constant_p", (CallGenerator)new BuiltinConstantPredicate());
/* 140 */     addFunction("__builtin_object_size", (CallGenerator)new BuiltinObjectSize());
/* 141 */     addFunction("__builtin_assume_aligned", (CallGenerator)new BuiltinAssumeAlignedGenerator());
/*     */     
/* 143 */     addFunction("__builtin_expect", (CallGenerator)new BuiltinExpectGenerator());
/* 144 */     addFunction("__builtin_clz", (CallGenerator)new BuiltinClzGenerator());
/*     */     
/* 146 */     addFunction("__cxa_allocate_exception", (CallGenerator)new MallocCallGenerator(this.typeOracle));
/* 147 */     addFunction("__builtin_eh_pointer", (CallGenerator)new EhPointerCallGenerator());
/* 148 */     addFunction("__cxa_throw", (CallGenerator)new ThrowCallGenerator());
/* 149 */     addFunction("__cxa_begin_catch", (CallGenerator)new BeginCatchCallGenerator());
/* 150 */     addFunction("__cxa_end_catch", (CallGenerator)new EndCatchGenerator());
/* 151 */     addFunction("__cxa_rethrow", (CallGenerator)new RethrowGenerator());
/*     */     
/*     */     try {
/* 154 */       addVariable("__dso_handle", (new VPtrStrategy((GimpleType)new GimpleVoidType())).providedGlobalVariable(new GimpleVarDecl(), 
/* 155 */             (JExpr)Expressions.staticField(Builtins.class.getField("__dso_handle")), false));
/* 156 */     } catch (NoSuchFieldException e) {
/* 157 */       throw new Error(e);
/*     */     } 
/*     */     
/* 160 */     addMethod("__builtin_log10__", Math.class, "log10");
/*     */     
/* 162 */     addFunction("memcpy", (CallGenerator)new MemCopyCallGenerator(false));
/* 163 */     addFunction("memmove", (CallGenerator)new MemCopyCallGenerator(true));
/* 164 */     addFunction("memcmp", (CallGenerator)new MemCmpCallGenerator(this.typeOracle));
/* 165 */     addFunction("memset", (CallGenerator)new MemSetGenerator(this.typeOracle));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void addLibrary(SymbolLibrary lib) {
/* 171 */     for (SymbolFunction f : lib.getFunctions(this.typeOracle)) {
/* 172 */       addFunction(f.getAlias(), f.getCall());
/*     */     }
/* 174 */     for (SymbolMethod m : lib.getMethods()) {
/* 175 */       addMethod(m.getAlias(), m.getTargetClass(), m.getMethodName());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void addMethod(String functionName, Class<?> declaringClass) {
/* 181 */     addFunction(functionName, findMethod(declaringClass, functionName));
/*     */   }
/*     */   
/*     */   public void addMethod(String functionName, Class<?> declaringClass, String methodName) {
/* 185 */     addFunction(functionName, findMethod(declaringClass, methodName));
/*     */   }
/*     */   
/*     */   public void addFunction(String name, CallGenerator callGenerator) {
/* 189 */     this.functions.put(name, callGenerator);
/*     */   }
/*     */   
/*     */   public void addFunction(String functionName, Method method) {
/* 193 */     Preconditions.checkArgument(Modifier.isStatic(method.getModifiers()), "Method '%s' must be static", new Object[] { method });
/*     */     
/* 195 */     FunctionCallGenerator callGenerator = new FunctionCallGenerator((InvocationStrategy)new StaticMethodStrategy(this.typeOracle, method));
/* 196 */     if (method.isAnnotationPresent((Class)Noop.class)) {
/* 197 */       if (!method.getReturnType().equals(void.class)) {
/* 198 */         throw new IllegalStateException("Method " + method + " is annotated with @" + Noop.class.getSimpleName() + " but does not have a void return type.");
/*     */       }
/*     */       
/* 201 */       this.functions.put(functionName, new NoopCallGenerator(callGenerator));
/*     */     } else {
/* 203 */       this.functions.put(functionName, callGenerator);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void addMethods(Class<?> clazz) {
/* 208 */     for (Method method : clazz.getMethods()) {
/* 209 */       if (Modifier.isPublic(method.getModifiers()) && Modifier.isStatic(method.getModifiers()))
/*     */       {
/*     */         
/* 212 */         if (method.getAnnotation(Deprecated.class) == null)
/*     */         {
/*     */ 
/*     */ 
/*     */           
/* 217 */           if (method.getAnnotation(GlobalVar.class) == null)
/*     */           {
/*     */ 
/*     */             
/* 221 */             addFunction(method.getName(), method); }  } 
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private Method findMethod(Class<?> declaringClass, String methodName) {
/* 227 */     for (Method method : declaringClass.getMethods()) {
/* 228 */       if (method.getName().equals(methodName)) {
/* 229 */         return method;
/*     */       }
/*     */     } 
/* 232 */     throw new IllegalArgumentException(String.format("No method named '%s' in %s", new Object[] { methodName, declaringClass.getName() }));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public GExpr getVariable(GimpleSymbolRef ref) {
/* 238 */     if (ref.getName() == null) {
/* 239 */       return null;
/*     */     }
/* 241 */     GExpr expr = this.globalVariables.get(ref.getMangledName());
/* 242 */     if (expr != null) {
/* 243 */       return expr;
/*     */     }
/*     */     
/* 246 */     expr = tryLoadGlobalVariable(ref);
/* 247 */     if (expr != null) {
/* 248 */       this.globalVariables.put(ref.getMangledName(), expr);
/* 249 */       return expr;
/*     */     } 
/* 251 */     throw new InternalCompilerException("No such variable: " + ref);
/*     */   }
/*     */ 
/*     */   
/*     */   private GExpr tryLoadGlobalVariable(GimpleSymbolRef ref) {
/* 256 */     ProvidedGlobalVar providedVar = this.providedVariables.get(ref.getMangledName());
/* 257 */     if (providedVar != null) {
/* 258 */       GimpleVarDecl decl = new GimpleVarDecl();
/* 259 */       decl.setId(ref.getId());
/* 260 */       decl.setName(ref.getName());
/* 261 */       decl.setMangledName(ref.getMangledName());
/* 262 */       decl.setType(ref.getType());
/* 263 */       return providedVar.createExpr(decl, this.typeOracle);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 268 */     Optional<LinkSymbol> linkSymbol = findLinkSymbol(ref.getMangledName());
/* 269 */     if (linkSymbol.isPresent()) {
/* 270 */       Field field = ((LinkSymbol)linkSymbol.get()).loadField(this.linkClassLoader);
/* 271 */       ProvidedGlobalVarField globalField = new ProvidedGlobalVarField(field);
/* 272 */       GimpleVarDecl varDecl = new GimpleVarDecl();
/* 273 */       varDecl.setName(ref.getName());
/* 274 */       varDecl.setMangledName(ref.getMangledName());
/* 275 */       varDecl.setType(ref.getType());
/* 276 */       return globalField.createExpr(varDecl, this.typeOracle);
/*     */     } 
/* 278 */     return null;
/*     */   }
/*     */   
/*     */   public void addVariable(String name, GExpr expr) {
/* 282 */     this.globalVariables.put(name, expr);
/*     */   }
/*     */   
/*     */   public Set<Map.Entry<String, CallGenerator>> getFunctions() {
/* 286 */     return this.functions.entrySet();
/*     */   }
/*     */ 
/*     */   
/*     */   private Optional<LinkSymbol> findLinkSymbol(String mangledName) {
/* 291 */     Optional<LinkSymbol> linkSymbol = null;
/*     */     try {
/* 293 */       linkSymbol = LinkSymbol.lookup(this.linkClassLoader, mangledName);
/* 294 */     } catch (IOException e) {
/* 295 */       throw new InternalCompilerException("Exception loading link symbol " + mangledName, e);
/*     */     } 
/* 297 */     return linkSymbol;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/symbols/GlobalSymbolTable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */