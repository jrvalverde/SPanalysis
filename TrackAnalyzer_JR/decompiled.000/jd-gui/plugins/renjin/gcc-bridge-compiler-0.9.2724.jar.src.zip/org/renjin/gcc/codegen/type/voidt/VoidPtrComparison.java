/*    */ package org.renjin.gcc.codegen.type.voidt;
/*    */ 
/*    */ import org.renjin.gcc.codegen.MethodGenerator;
/*    */ import org.renjin.gcc.codegen.condition.ConditionGenerator;
/*    */ import org.renjin.gcc.codegen.expr.JExpr;
/*    */ import org.renjin.gcc.gimple.GimpleOp;
/*    */ import org.renjin.gcc.runtime.VoidPtr;
/*    */ import org.renjin.repackaged.asm.Label;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VoidPtrComparison
/*    */   implements ConditionGenerator
/*    */ {
/*    */   private final GimpleOp op;
/*    */   private final JExpr x;
/*    */   private final JExpr y;
/*    */   
/*    */   public VoidPtrComparison(GimpleOp op, JExpr x, JExpr y) {
/* 38 */     this.op = op;
/* 39 */     this.x = x;
/* 40 */     this.y = y;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void emitJump(MethodGenerator mv, Label trueLabel, Label falseLabel) {
/* 51 */     this.x.load(mv);
/* 52 */     this.y.load(mv);
/*    */     
/* 54 */     mv.invokestatic(VoidPtr.class, "compare", 
/* 55 */         Type.getMethodDescriptor(Type.INT_TYPE, new Type[] { Type.getType(Object.class), Type.getType(Object.class) }));
/*    */ 
/*    */     
/* 58 */     switch (this.op) {
/*    */       case LT_EXPR:
/* 60 */         mv.iflt(trueLabel);
/*    */         break;
/*    */       case LE_EXPR:
/* 63 */         mv.ifle(trueLabel);
/*    */         break;
/*    */       case EQ_EXPR:
/* 66 */         mv.ifeq(trueLabel);
/*    */         break;
/*    */       case NE_EXPR:
/* 69 */         mv.ifne(trueLabel);
/*    */         break;
/*    */       case GT_EXPR:
/* 72 */         mv.ifgt(trueLabel);
/*    */         break;
/*    */       case GE_EXPR:
/* 75 */         mv.ifge(trueLabel);
/*    */         break;
/*    */       
/*    */       default:
/* 79 */         throw new UnsupportedOperationException("op: " + this.op);
/*    */     } 
/* 81 */     mv.goTo(falseLabel);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/type/voidt/VoidPtrComparison.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */