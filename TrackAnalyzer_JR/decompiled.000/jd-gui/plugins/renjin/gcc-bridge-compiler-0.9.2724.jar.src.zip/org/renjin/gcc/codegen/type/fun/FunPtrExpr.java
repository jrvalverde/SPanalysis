/*     */ package org.renjin.gcc.codegen.type.fun;
/*     */ 
/*     */ import java.lang.invoke.MethodHandle;
/*     */ import org.renjin.gcc.InternalCompilerException;
/*     */ import org.renjin.gcc.codegen.MethodGenerator;
/*     */ import org.renjin.gcc.codegen.array.FatArrayExpr;
/*     */ import org.renjin.gcc.codegen.condition.ConditionGenerator;
/*     */ import org.renjin.gcc.codegen.expr.Expressions;
/*     */ import org.renjin.gcc.codegen.expr.GExpr;
/*     */ import org.renjin.gcc.codegen.expr.JExpr;
/*     */ import org.renjin.gcc.codegen.expr.JLValue;
/*     */ import org.renjin.gcc.codegen.expr.PtrExpr;
/*     */ import org.renjin.gcc.codegen.expr.RefPtrExpr;
/*     */ import org.renjin.gcc.codegen.fatptr.FatPtr;
/*     */ import org.renjin.gcc.codegen.fatptr.ValueFunction;
/*     */ import org.renjin.gcc.codegen.type.NumericExpr;
/*     */ import org.renjin.gcc.codegen.type.UnsupportedCastException;
/*     */ import org.renjin.gcc.codegen.type.primitive.PrimitiveExpr;
/*     */ import org.renjin.gcc.codegen.type.record.ProvidedPtrExpr;
/*     */ import org.renjin.gcc.codegen.type.record.ReferenceConditions;
/*     */ import org.renjin.gcc.codegen.type.voidt.VoidPtrExpr;
/*     */ import org.renjin.gcc.codegen.vptr.VArrayExpr;
/*     */ import org.renjin.gcc.codegen.vptr.VPtrExpr;
/*     */ import org.renjin.gcc.codegen.vptr.VPtrRecordExpr;
/*     */ import org.renjin.gcc.gimple.GimpleOp;
/*     */ import org.renjin.gcc.gimple.type.GimpleArrayType;
/*     */ import org.renjin.gcc.gimple.type.GimpleRecordType;
/*     */ import org.renjin.gcc.gimple.type.GimpleType;
/*     */ import org.renjin.gcc.runtime.FunctionPtr1;
/*     */ import org.renjin.gcc.runtime.Ptr;
/*     */ import org.renjin.repackaged.asm.Label;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FunPtrExpr
/*     */   implements RefPtrExpr
/*     */ {
/*  51 */   public static final FunPtrExpr NULL_PTR = new FunPtrExpr();
/*     */   
/*     */   private JExpr methodHandleExpr;
/*     */   private FatPtr address;
/*     */   
/*     */   private FunPtrExpr() {
/*  57 */     this.methodHandleExpr = Expressions.nullRef(Type.getType(MethodHandle.class));
/*     */   }
/*     */   
/*     */   public FunPtrExpr(JExpr methodHandleExpr) {
/*  61 */     this.methodHandleExpr = methodHandleExpr;
/*  62 */     this.address = null;
/*     */   }
/*     */   
/*     */   public FunPtrExpr(JExpr methodHandleExpr, FatPtr address) {
/*  66 */     this.methodHandleExpr = methodHandleExpr;
/*  67 */     this.address = address;
/*     */   }
/*     */   
/*     */   public JExpr jexpr() {
/*  71 */     return this.methodHandleExpr;
/*     */   }
/*     */ 
/*     */   
/*     */   public void store(MethodGenerator mv, GExpr rhs) {
/*  76 */     ((JLValue)this.methodHandleExpr).store(mv, (rhs.toFunPtr()).methodHandleExpr);
/*     */   }
/*     */ 
/*     */   
/*     */   public PtrExpr addressOf() {
/*  81 */     if (this.address == null) {
/*  82 */       throw new InternalCompilerException("Not addressable");
/*     */     }
/*  84 */     return (PtrExpr)this.address;
/*     */   }
/*     */ 
/*     */   
/*     */   public FunPtrExpr toFunPtr() {
/*  89 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public FatArrayExpr toArrayExpr() throws UnsupportedCastException {
/*  94 */     throw new UnsupportedCastException();
/*     */   }
/*     */ 
/*     */   
/*     */   public PrimitiveExpr toPrimitiveExpr() throws UnsupportedCastException {
/*  99 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public VoidPtrExpr toVoidPtrExpr() throws UnsupportedCastException {
/* 104 */     return new VoidPtrExpr(this.methodHandleExpr, this.address);
/*     */   }
/*     */ 
/*     */   
/*     */   public VPtrExpr toVPtrExpr() throws UnsupportedCastException {
/* 109 */     return new VPtrExpr(Expressions.staticMethodCall(FunctionPtr1.class, "malloc", 
/* 110 */           Type.getMethodDescriptor(Type.getType(Ptr.class), new Type[] { Type.getType(MethodHandle.class) }), new JExpr[] { this.methodHandleExpr }), (PtrExpr)this.address);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ProvidedPtrExpr toProvidedPtrExpr(Type jvmType) {
/* 116 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public FatPtr toFatPtrExpr(ValueFunction valueFunction) {
/* 121 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public VPtrRecordExpr toVPtrRecord(GimpleRecordType recordType) {
/* 126 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public VArrayExpr toVArray(GimpleArrayType arrayType) {
/* 131 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public NumericExpr toNumericExpr() {
/* 136 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void jumpIfNull(MethodGenerator mv, Label label) {
/* 141 */     this.methodHandleExpr.load(mv);
/* 142 */     mv.ifnull(label);
/*     */   }
/*     */ 
/*     */   
/*     */   public JExpr memoryCompare(MethodGenerator mv, PtrExpr otherPointer, JExpr n) {
/* 147 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void memorySet(MethodGenerator mv, JExpr byteValue, JExpr length) {
/* 152 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void memoryCopy(MethodGenerator mv, PtrExpr source, JExpr length, boolean buffer) {
/* 157 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public PtrExpr realloc(MethodGenerator mv, JExpr newSizeInBytes) {
/* 162 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public PtrExpr pointerPlus(MethodGenerator mv, JExpr offsetInBytes) {
/* 167 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public GExpr valueOf(GimpleType expectedType) {
/* 172 */     return (GExpr)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public ConditionGenerator comparePointer(MethodGenerator mv, GimpleOp op, GExpr otherPointer) {
/* 177 */     return ReferenceConditions.compare(op, jexpr(), otherPointer.toFunPtr().jexpr());
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/type/fun/FunPtrExpr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */