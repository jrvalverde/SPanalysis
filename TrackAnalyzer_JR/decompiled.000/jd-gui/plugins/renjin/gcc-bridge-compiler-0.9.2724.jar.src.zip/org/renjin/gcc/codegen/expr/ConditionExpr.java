/*    */ package org.renjin.gcc.codegen.expr;
/*    */ 
/*    */ import javax.annotation.Nonnull;
/*    */ import org.renjin.gcc.codegen.MethodGenerator;
/*    */ import org.renjin.gcc.codegen.condition.ConditionGenerator;
/*    */ import org.renjin.repackaged.asm.Label;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConditionExpr
/*    */   implements JExpr
/*    */ {
/*    */   private ConditionGenerator condition;
/*    */   
/*    */   public ConditionExpr(ConditionGenerator condition) {
/* 36 */     this.condition = condition;
/*    */   }
/*    */ 
/*    */   
/*    */   @Nonnull
/*    */   public Type getType() {
/* 42 */     return Type.BOOLEAN_TYPE;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void load(@Nonnull MethodGenerator mv) {
/* 50 */     Label trueLabel = new Label();
/* 51 */     Label falseLabel = new Label();
/* 52 */     Label exitLabel = new Label();
/*    */     
/* 54 */     this.condition.emitJump(mv, trueLabel, falseLabel);
/*    */ 
/*    */     
/* 57 */     mv.mark(falseLabel);
/* 58 */     mv.iconst(0);
/* 59 */     mv.goTo(exitLabel);
/*    */ 
/*    */     
/* 62 */     mv.mark(trueLabel);
/* 63 */     mv.iconst(1);
/*    */ 
/*    */     
/* 66 */     mv.mark(exitLabel);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/expr/ConditionExpr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */