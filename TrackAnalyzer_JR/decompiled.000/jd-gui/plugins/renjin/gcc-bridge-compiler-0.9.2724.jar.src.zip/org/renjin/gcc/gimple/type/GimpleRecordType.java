/*    */ package org.renjin.gcc.gimple.type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GimpleRecordType
/*    */   extends AbstractGimpleType
/*    */ {
/*    */   private String name;
/*    */   private String id;
/*    */   
/*    */   public GimpleRecordType() {}
/*    */   
/*    */   public GimpleRecordType(GimpleRecordTypeDef typeDef) {
/* 29 */     this.id = typeDef.getId();
/* 30 */     setSize(typeDef.getSize());
/* 31 */     setName(typeDef.getName());
/*    */   }
/*    */   
/*    */   public GimpleRecordType(String id) {
/* 35 */     this.id = id;
/*    */   }
/*    */   
/*    */   public String getId() {
/* 39 */     return this.id;
/*    */   }
/*    */   
/*    */   public void setId(String id) {
/* 43 */     this.id = id;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 47 */     if (this.name == null) {
/* 48 */       return "anonymous_" + this.id;
/*    */     }
/* 50 */     return this.name;
/*    */   }
/*    */   
/*    */   public void setName(String name) {
/* 54 */     this.name = name;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 59 */     return "struct " + getName();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int sizeOf() {
/* 65 */     return getSize() / 8;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 70 */     if (this == o) {
/* 71 */       return true;
/*    */     }
/* 73 */     if (o == null || getClass() != o.getClass()) {
/* 74 */       return false;
/*    */     }
/*    */     
/* 77 */     GimpleRecordType that = (GimpleRecordType)o;
/*    */     
/* 79 */     return this.id.equals(that.id);
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 84 */     return this.id.hashCode();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/gimple/type/GimpleRecordType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */