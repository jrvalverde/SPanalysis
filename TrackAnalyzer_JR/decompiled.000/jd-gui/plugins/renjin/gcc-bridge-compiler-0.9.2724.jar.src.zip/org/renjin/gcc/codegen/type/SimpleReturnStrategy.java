/*    */ package org.renjin.gcc.codegen.type;
/*    */ 
/*    */ import org.renjin.gcc.InternalCompilerException;
/*    */ import org.renjin.gcc.codegen.MethodGenerator;
/*    */ import org.renjin.gcc.codegen.expr.Expressions;
/*    */ import org.renjin.gcc.codegen.expr.GExpr;
/*    */ import org.renjin.gcc.codegen.expr.GSimpleExpr;
/*    */ import org.renjin.gcc.codegen.expr.JExpr;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SimpleReturnStrategy
/*    */   implements ReturnStrategy
/*    */ {
/*    */   private final SimpleTypeStrategy strategy;
/*    */   private Type type;
/*    */   
/*    */   public SimpleReturnStrategy(SimpleTypeStrategy strategy) {
/* 38 */     this.type = strategy.getJvmType();
/* 39 */     this.strategy = strategy;
/*    */   }
/*    */ 
/*    */   
/*    */   public Type getType() {
/* 44 */     return this.type;
/*    */   }
/*    */ 
/*    */   
/*    */   public JExpr marshall(GExpr expr) {
/* 49 */     return ((GSimpleExpr)expr).jexpr();
/*    */   }
/*    */ 
/*    */   
/*    */   public GExpr unmarshall(MethodGenerator mv, JExpr callExpr, TypeStrategy<GExpr> lhsTypeStrategy) {
/* 54 */     GExpr result = this.strategy.wrap(Expressions.cast(callExpr, this.type));
/*    */     try {
/* 56 */       return lhsTypeStrategy.cast(mv, result);
/* 57 */     } catch (UnsupportedCastException e) {
/* 58 */       throw new InternalCompilerException("Cannot cast from " + this.strategy + " to " + lhsTypeStrategy, e);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public JExpr getDefaultReturnValue() {
/* 64 */     switch (this.type.getSort()) {
/*    */       case 9:
/*    */       case 10:
/*    */       case 11:
/* 68 */         return Expressions.nullRef(this.type);
/*    */     } 
/*    */     
/* 71 */     return Expressions.zero(this.type);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/type/SimpleReturnStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */