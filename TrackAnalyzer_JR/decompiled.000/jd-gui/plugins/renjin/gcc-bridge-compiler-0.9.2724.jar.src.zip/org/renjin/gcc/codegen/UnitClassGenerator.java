/*     */ package org.renjin.gcc.codegen;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.renjin.gcc.GimpleCompiler;
/*     */ import org.renjin.gcc.InternalCompilerException;
/*     */ import org.renjin.gcc.codegen.expr.ExprFactory;
/*     */ import org.renjin.gcc.codegen.expr.GExpr;
/*     */ import org.renjin.gcc.codegen.type.ParamStrategy;
/*     */ import org.renjin.gcc.codegen.type.TypeOracle;
/*     */ import org.renjin.gcc.codegen.type.TypeStrategy;
/*     */ import org.renjin.gcc.codegen.var.GlobalVarAllocator;
/*     */ import org.renjin.gcc.codegen.var.VarAllocator;
/*     */ import org.renjin.gcc.gimple.GimpleAlias;
/*     */ import org.renjin.gcc.gimple.GimpleCompilationUnit;
/*     */ import org.renjin.gcc.gimple.GimpleFunction;
/*     */ import org.renjin.gcc.gimple.GimpleParameter;
/*     */ import org.renjin.gcc.gimple.GimpleVarDecl;
/*     */ import org.renjin.gcc.gimple.expr.GimpleExpr;
/*     */ import org.renjin.gcc.gimple.type.GimpleComplexType;
/*     */ import org.renjin.gcc.gimple.type.GimpleIndirectType;
/*     */ import org.renjin.gcc.gimple.type.GimplePrimitiveType;
/*     */ import org.renjin.gcc.gimple.type.GimpleType;
/*     */ import org.renjin.gcc.link.LinkSymbol;
/*     */ import org.renjin.gcc.logging.LogManager;
/*     */ import org.renjin.gcc.symbols.GlobalSymbolTable;
/*     */ import org.renjin.gcc.symbols.SymbolTable;
/*     */ import org.renjin.gcc.symbols.UnitSymbolTable;
/*     */ import org.renjin.repackaged.asm.ClassVisitor;
/*     */ import org.renjin.repackaged.asm.ClassWriter;
/*     */ import org.renjin.repackaged.asm.MethodVisitor;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ import org.renjin.repackaged.asm.util.TraceClassVisitor;
/*     */ import org.renjin.repackaged.guava.collect.Lists;
/*     */ import org.renjin.repackaged.guava.collect.Sets;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UnitClassGenerator
/*     */ {
/*     */   private static final boolean INVOKE_CXX_INITIALIZERS = false;
/*     */   private final GimpleCompilationUnit unit;
/*     */   private final String className;
/*     */   private final UnitSymbolTable symbolTable;
/*     */   private final TypeOracle typeOracle;
/*     */   private final GlobalVarAllocator globalVarAllocator;
/*  73 */   private final List<GimpleVarDecl> varToGenerate = Lists.newArrayList();
/*     */   
/*  75 */   private final List<LinkSymbol> globalVariableSymbols = new ArrayList<>();
/*     */   
/*     */   private ClassWriter cw;
/*     */   
/*     */   private ClassVisitor cv;
/*     */   
/*     */   private StringWriter sw;
/*     */   
/*     */   private PrintWriter pw;
/*     */ 
/*     */   
/*     */   public UnitClassGenerator(TypeOracle typeOracle, GlobalSymbolTable globalSymbolTable, List<GlobalVarTransformer> globalVarTransformers, GimpleCompilationUnit unit, String className) {
/*  87 */     this.unit = unit;
/*  88 */     this.className = className;
/*  89 */     this.typeOracle = typeOracle;
/*  90 */     this.globalVarAllocator = new GlobalVarAllocator(className);
/*  91 */     this.symbolTable = new UnitSymbolTable(globalSymbolTable, unit);
/*     */ 
/*     */     
/*  94 */     Set<String> visited = new HashSet<>();
/*  95 */     for (GimpleVarDecl decl : unit.getGlobalVariables()) {
/*  96 */       if (decl.isExtern()) {
/*     */         continue;
/*     */       }
/*  99 */       if (!visited.add(decl.getMangledName())) {
/*     */         continue;
/*     */       }
/* 102 */       this.symbolTable.addGlobalVariable(decl, 
/* 103 */           generatorForGlobalVar(globalVarTransformers, decl));
/*     */     } 
/*     */     
/* 106 */     for (GimpleFunction function : unit.getFunctions()) {
/* 107 */       if (!isExcluded(function)) {
/*     */         try {
/* 109 */           this.symbolTable.addFunction(function, new FunctionGenerator(className, function, typeOracle, this.globalVarAllocator, this.symbolTable));
/*     */         }
/* 111 */         catch (Exception e) {
/* 112 */           throw new InternalCompilerException(String.format("Exception creating %s for %s in %s: %s", new Object[] { FunctionGenerator.class
/* 113 */                   .getSimpleName(), function
/* 114 */                   .getName(), unit
/* 115 */                   .getSourceName(), e
/* 116 */                   .getMessage() }), e);
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 121 */     for (GimpleAlias alias : unit.getAliases()) {
/* 122 */       this.symbolTable.addAlias(alias);
/*     */     }
/*     */   }
/*     */   
/*     */   public UnitSymbolTable getSymbolTable() {
/* 127 */     return this.symbolTable;
/*     */   }
/*     */   
/*     */   public GimpleCompilationUnit getUnit() {
/* 131 */     return this.unit;
/*     */   }
/*     */ 
/*     */   
/*     */   private GExpr generatorForGlobalVar(List<GlobalVarTransformer> globalVarTransformers, GimpleVarDecl decl) {
/*     */     GExpr varGenerator;
/* 137 */     for (GlobalVarTransformer transformer : globalVarTransformers) {
/* 138 */       if (transformer.accept(decl)) {
/* 139 */         return transformer.generator(this.typeOracle, this.unit, decl);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 145 */       TypeStrategy typeStrategy = this.typeOracle.forType(decl.getType());
/* 146 */       varGenerator = typeStrategy.globalVariable(decl, this.globalVarAllocator);
/*     */     }
/* 148 */     catch (Exception e) {
/* 149 */       throw new InternalCompilerException("Global variable " + decl.getName() + " in " + this.unit.getSourceName(), e);
/*     */     } 
/* 151 */     this.varToGenerate.add(decl);
/*     */     
/* 153 */     if (!decl.isStatic()) {
/* 154 */       this.globalVariableSymbols.add(LinkSymbol.forGlobalVariable(decl.getMangledName(), Type.getType(this.className)));
/*     */     }
/* 156 */     return varGenerator;
/*     */   }
/*     */   
/*     */   public List<LinkSymbol> getGlobalVariableSymbols() {
/* 160 */     return this.globalVariableSymbols;
/*     */   }
/*     */   
/*     */   private boolean isExcluded(GimpleFunction function) {
/* 164 */     if (function.getMangledName().equals("printf")) {
/* 165 */       return true;
/*     */     }
/*     */     
/* 168 */     return false;
/*     */   }
/*     */   
/*     */   public String getClassName() {
/* 172 */     return this.className;
/*     */   }
/*     */ 
/*     */   
/*     */   public void emit(LogManager parentLogger) {
/* 177 */     parentLogger.logRecords(this.unit, this.symbolTable);
/*     */     
/* 179 */     this.sw = new StringWriter();
/* 180 */     this.pw = new PrintWriter(this.sw);
/* 181 */     this.cw = new ClassWriter(3)
/*     */       {
/*     */         protected String getCommonSuperClass(String type1, String type2) {
/*     */           try {
/* 185 */             return super.getCommonSuperClass(type1, type2);
/* 186 */           } catch (Exception e) {
/* 187 */             return Type.getInternalName(Object.class);
/*     */           } 
/*     */         }
/*     */       };
/*     */ 
/*     */     
/* 193 */     if (GimpleCompiler.TRACE) {
/* 194 */       this.cv = (ClassVisitor)new TraceClassVisitor((ClassVisitor)this.cw, new PrintWriter(System.out));
/*     */     } else {
/* 196 */       this.cv = (ClassVisitor)this.cw;
/*     */     } 
/* 198 */     this.cv.visit(51, 33, this.className, null, "java/lang/Object", new String[0]);
/* 199 */     this.cv.visitSource(this.unit.getSourceName(), null);
/* 200 */     emitDefaultConstructor();
/* 201 */     emitFunctions(parentLogger, this.unit);
/* 202 */     emitGlobalVariables();
/* 203 */     this.cv.visitEnd();
/*     */   }
/*     */   
/*     */   private void emitDefaultConstructor() {
/* 207 */     MethodVisitor mv = this.cv.visitMethod(2, "<init>", "()V", null, null);
/* 208 */     mv.visitCode();
/* 209 */     mv.visitVarInsn(25, 0);
/* 210 */     mv.visitMethodInsn(183, "java/lang/Object", "<init>", "()V", false);
/* 211 */     mv.visitInsn(177);
/* 212 */     mv.visitMaxs(1, 1);
/* 213 */     mv.visitEnd();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void emitGlobalVariables() {
/* 219 */     this.globalVarAllocator.writeFields(this.cv);
/*     */ 
/*     */     
/* 222 */     MethodGenerator mv = new MethodGenerator(this.className, this.cv.visitMethod(8, "<clinit>", "()V", null, null));
/* 223 */     mv.visitCode();
/*     */     
/* 225 */     ExprFactory exprFactory = new ExprFactory(this.typeOracle, (SymbolTable)this.symbolTable, mv);
/*     */     
/* 227 */     this.globalVarAllocator.writeFieldInitialization(mv);
/*     */     
/* 229 */     for (GimpleVarDecl decl : this.varToGenerate) {
/*     */       try {
/* 231 */         GExpr varGenerator = this.symbolTable.getGlobalVariable(decl);
/* 232 */         GimpleExpr initialValue = decl.getValue();
/* 233 */         if (initialValue == null) {
/* 234 */           initialValue = zeroValue(decl.getType());
/*     */         }
/* 236 */         if (initialValue != null)
/*     */         {
/* 238 */           if (initialValue instanceof org.renjin.gcc.gimple.expr.GimpleConstructor) {
/* 239 */             writeInitMethodCall(mv, decl, varGenerator, initialValue); continue;
/*     */           } 
/* 241 */           tryWriteInitCode(mv, exprFactory, decl, varGenerator, initialValue);
/*     */         }
/*     */       
/* 244 */       } catch (Exception e) {
/* 245 */         throw new InternalCompilerException(
/* 246 */             String.format("Exception writing static variable initializer %s %s = %s defined in %s", new Object[] {
/* 247 */                 decl.getType(), decl
/* 248 */                 .getName(), decl
/* 249 */                 .getValue(), this.unit
/* 250 */                 .getSourceName()
/*     */               }), e);
/*     */       } 
/*     */     } 
/* 254 */     for (FunctionGenerator function : this.symbolTable.getFunctions()) {
/* 255 */       function.emitLocalStaticVarInitialization(mv);
/*     */     }
/*     */     
/* 258 */     emitCppStaticInitialization(mv);
/*     */     
/* 260 */     mv.visitInsn(177);
/* 261 */     mv.visitMaxs(1, 1);
/* 262 */     mv.visitEnd();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void emitCppStaticInitialization(MethodGenerator mv) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeInitMethodCall(MethodGenerator mv, GimpleVarDecl decl, GExpr varGenerator, GimpleExpr initialValue) {
/* 304 */     String initMethodName = writeInitMethod(decl, varGenerator, initialValue);
/* 305 */     mv.invokestatic(this.className, initMethodName, "()V", false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String writeInitMethod(GimpleVarDecl decl, GExpr varGenerator, GimpleExpr initialValue) {
/* 312 */     String initMethodName = VarAllocator.toJavaSafeName(decl.getMangledName()) + "$$clinit";
/* 313 */     MethodGenerator mv = new MethodGenerator(this.className, this.cv.visitMethod(8, initMethodName, "()V", null, null));
/* 314 */     ExprFactory exprFactory = new ExprFactory(this.typeOracle, (SymbolTable)this.symbolTable, mv);
/* 315 */     mv.visitCode();
/* 316 */     tryWriteInitCode(mv, exprFactory, decl, varGenerator, initialValue);
/* 317 */     mv.visitInsn(177);
/* 318 */     mv.visitMaxs(1, 1);
/* 319 */     mv.visitEnd();
/*     */     
/* 321 */     return initMethodName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void tryWriteInitCode(MethodGenerator mv, ExprFactory exprFactory, GimpleVarDecl decl, GExpr varGenerator, GimpleExpr initialValue) {
/*     */     try {
/* 332 */       varGenerator.store(mv, exprFactory.findGenerator(initialValue));
/* 333 */     } catch (Exception e) {
/* 334 */       System.err.println("Warning: could not generate code for global variable " + decl.getMangledName() + ": " + e
/* 335 */           .getMessage());
/*     */     } 
/*     */   }
/*     */   
/*     */   private GimpleExpr zeroValue(GimpleType type) {
/* 340 */     if (type instanceof GimplePrimitiveType)
/* 341 */       return (GimpleExpr)((GimplePrimitiveType)type).zero(); 
/* 342 */     if (type instanceof GimpleComplexType)
/* 343 */       return (GimpleExpr)((GimpleComplexType)type).zero(); 
/* 344 */     if (type instanceof GimpleIndirectType) {
/* 345 */       return (GimpleExpr)((GimpleIndirectType)type).nullValue();
/*     */     }
/* 347 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void emitFunctions(LogManager parentLogger, GimpleCompilationUnit unit) {
/* 353 */     Set<String> names = Sets.newHashSet();
/* 354 */     for (FunctionGenerator functionGenerator : this.symbolTable.getFunctions()) {
/* 355 */       if (names.contains(functionGenerator.getSafeMangledName())) {
/* 356 */         throw new InternalCompilerException("Duplicate function names " + functionGenerator.getSafeMangledName());
/*     */       }
/* 358 */       names.add(functionGenerator.getSafeMangledName());
/*     */     } 
/*     */ 
/*     */     
/* 362 */     for (FunctionGenerator functionGenerator : this.symbolTable.getFunctions()) {
/*     */       try {
/* 364 */         functionGenerator.emit(parentLogger, this.cv);
/* 365 */       } catch (Exception e) {
/* 366 */         throw new InternalCompilerException(functionGenerator, e);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public byte[] toByteArray() {
/* 372 */     this.cv.visitEnd();
/*     */     try {
/* 374 */       return this.cw.toByteArray();
/* 375 */     } catch (Exception e) {
/* 376 */       throw new InternalCompilerException("Failed to write class " + getClassName() + ": " + e.getMessage());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void emitJavaDoc(File outputDir) throws IOException {
/* 387 */     File sourceFile = new File(outputDir.getAbsolutePath() + File.separator + this.className + ".java");
/* 388 */     if (!sourceFile.getParentFile().exists()) {
/* 389 */       boolean created = sourceFile.getParentFile().mkdirs();
/* 390 */       if (!created) {
/* 391 */         throw new IOException("Failed to create directory for java source file: " + sourceFile.getParentFile());
/*     */       }
/*     */     } 
/*     */     
/* 395 */     String[] javaNames = getJavaNames();
/*     */     
/* 397 */     PrintWriter s = new PrintWriter(sourceFile);
/* 398 */     s.println("package " + javaNames[0] + ";");
/* 399 */     s.println();
/* 400 */     s.println("public class " + javaNames[1] + " {");
/* 401 */     s.println();
/*     */     
/* 403 */     for (FunctionGenerator functionGenerator : this.symbolTable.getFunctions()) {
/* 404 */       s.print("  public static ");
/* 405 */       s.print(javaName(functionGenerator.getReturnStrategy().getType()));
/* 406 */       s.print(" ");
/* 407 */       s.print(functionGenerator.getMangledName());
/* 408 */       s.print("(");
/*     */       
/* 410 */       boolean needsComma = false;
/*     */       
/* 412 */       List<GimpleParameter> params = functionGenerator.getFunction().getParameters();
/* 413 */       for (int i = 0; i < params.size(); i++) {
/* 414 */         GimpleParameter param = params.get(i);
/* 415 */         ParamStrategy paramStrategy = functionGenerator.getParamStrategies().get(i);
/*     */         
/* 417 */         List<Type> types = paramStrategy.getParameterTypes();
/* 418 */         List<String> names = paramStrategy.getParameterNames(param.getName());
/* 419 */         if (types.size() != names.size()) {
/* 420 */           throw new IllegalStateException("strategy: " + paramStrategy);
/*     */         }
/*     */         
/* 423 */         for (int j = 0; j < types.size(); j++) {
/* 424 */           if (needsComma) {
/* 425 */             s.print(", ");
/*     */           }
/* 427 */           s.print(javaName(types.get(j)));
/* 428 */           s.print(" ");
/* 429 */           s.print(names.get(j));
/* 430 */           needsComma = true;
/*     */         } 
/*     */       } 
/* 433 */       s.println(") { throw new UnsupportedOperationException(); }");
/*     */     } 
/*     */     
/* 436 */     s.println("}");
/* 437 */     s.close();
/*     */   }
/*     */ 
/*     */   
/*     */   private String[] getJavaNames() {
/* 442 */     int packageEnd = this.className.lastIndexOf('/');
/* 443 */     if (packageEnd == -1) {
/* 444 */       throw new IllegalStateException("className: " + this.className);
/*     */     }
/*     */     
/* 447 */     return new String[] { this.className
/* 448 */         .substring(0, packageEnd).replace('/', '.'), this.className
/* 449 */         .substring(packageEnd + 1) };
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private String javaName(Type type) {
/* 455 */     switch (type.getSort()) {
/*     */       case 0:
/* 457 */         return "void";
/*     */       case 1:
/* 459 */         return "boolean";
/*     */       case 3:
/* 461 */         return "byte";
/*     */       case 4:
/* 463 */         return "short";
/*     */       case 2:
/* 465 */         return "char";
/*     */       case 5:
/* 467 */         return "int";
/*     */       case 7:
/* 469 */         return "long";
/*     */       case 6:
/* 471 */         return "float";
/*     */       case 8:
/* 473 */         return "double";
/*     */       
/*     */       case 10:
/* 476 */         return type.getInternalName().replace('/', '.');
/*     */       
/*     */       case 9:
/* 479 */         return javaName(type.getElementType()) + "[]";
/*     */     } 
/*     */     
/* 482 */     throw new IllegalArgumentException("type: " + type);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/UnitClassGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */