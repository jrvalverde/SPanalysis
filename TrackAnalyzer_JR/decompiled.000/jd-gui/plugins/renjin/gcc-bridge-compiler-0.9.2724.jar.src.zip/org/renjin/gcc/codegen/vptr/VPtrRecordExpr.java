/*     */ package org.renjin.gcc.codegen.vptr;
/*     */ 
/*     */ import org.renjin.gcc.codegen.MethodGenerator;
/*     */ import org.renjin.gcc.codegen.array.FatArrayExpr;
/*     */ import org.renjin.gcc.codegen.expr.Expressions;
/*     */ import org.renjin.gcc.codegen.expr.GExpr;
/*     */ import org.renjin.gcc.codegen.expr.JExpr;
/*     */ import org.renjin.gcc.codegen.expr.PtrExpr;
/*     */ import org.renjin.gcc.codegen.fatptr.FatPtr;
/*     */ import org.renjin.gcc.codegen.fatptr.ValueFunction;
/*     */ import org.renjin.gcc.codegen.type.NumericExpr;
/*     */ import org.renjin.gcc.codegen.type.UnsupportedCastException;
/*     */ import org.renjin.gcc.codegen.type.fun.FunPtrExpr;
/*     */ import org.renjin.gcc.codegen.type.primitive.BitFieldExpr;
/*     */ import org.renjin.gcc.codegen.type.primitive.PrimitiveExpr;
/*     */ import org.renjin.gcc.codegen.type.primitive.PrimitiveType;
/*     */ import org.renjin.gcc.codegen.type.record.ProvidedPtrExpr;
/*     */ import org.renjin.gcc.codegen.type.record.RecordExpr;
/*     */ import org.renjin.gcc.codegen.type.voidt.VoidPtrExpr;
/*     */ import org.renjin.gcc.gimple.type.GimpleArrayType;
/*     */ import org.renjin.gcc.gimple.type.GimpleIntegerType;
/*     */ import org.renjin.gcc.gimple.type.GimplePrimitiveType;
/*     */ import org.renjin.gcc.gimple.type.GimpleRecordType;
/*     */ import org.renjin.gcc.gimple.type.GimpleType;
/*     */ import org.renjin.gcc.runtime.Ptr;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VPtrRecordExpr
/*     */   implements RecordExpr
/*     */ {
/*     */   private GimpleRecordType recordType;
/*     */   private VPtrExpr pointer;
/*     */   
/*     */   public VPtrRecordExpr(GimpleRecordType recordType, VPtrExpr pointer) {
/*  51 */     this.recordType = recordType;
/*  52 */     this.pointer = pointer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void store(MethodGenerator mv, GExpr rhs) {
/*  59 */     this.pointer.getRef().load(mv);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  64 */     if (rhs instanceof PtrExpr) {
/*  65 */       rhs.toVPtrExpr().getRef().load(mv);
/*     */     } else {
/*  67 */       rhs.toVPtrRecord(this.recordType).getRef().load(mv);
/*     */     } 
/*     */     
/*  70 */     mv.iconst(this.recordType.sizeOf());
/*     */     
/*  72 */     mv.invokeinterface(Ptr.class, "memcpy", Type.VOID_TYPE, new Type[] { Type.getType(Ptr.class), Type.INT_TYPE });
/*     */   }
/*     */ 
/*     */   
/*     */   public PtrExpr addressOf() {
/*  77 */     return this.pointer;
/*     */   }
/*     */ 
/*     */   
/*     */   public FunPtrExpr toFunPtr() throws UnsupportedCastException {
/*  82 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public FatArrayExpr toArrayExpr() throws UnsupportedCastException {
/*  87 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public PrimitiveExpr toPrimitiveExpr() throws UnsupportedCastException {
/*  92 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public VoidPtrExpr toVoidPtrExpr() throws UnsupportedCastException {
/*  97 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public VPtrExpr toVPtrExpr() throws UnsupportedCastException {
/* 102 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public VPtrRecordExpr toVPtrRecord(GimpleRecordType recordType) {
/* 107 */     return new VPtrRecordExpr(recordType, this.pointer);
/*     */   }
/*     */ 
/*     */   
/*     */   public VArrayExpr toVArray(GimpleArrayType arrayType) {
/* 112 */     return new VArrayExpr(arrayType, this.pointer);
/*     */   }
/*     */ 
/*     */   
/*     */   public NumericExpr toNumericExpr() {
/* 117 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public ProvidedPtrExpr toProvidedPtrExpr(Type jvmType) {
/* 122 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public FatPtr toFatPtrExpr(ValueFunction valueFunction) {
/* 127 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public GExpr memberOf(MethodGenerator mv, int fieldOffsetBits, int size, GimpleType type) {
/* 133 */     if (fieldOffsetBits % 8 == 0) {
/* 134 */       return this.pointer.valueOf(type, Expressions.constantInt(fieldOffsetBits / 8));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 139 */     if (type.equals(GimpleIntegerType.signed(8)) || type
/* 140 */       .equals(GimpleIntegerType.unsigned(8))) {
/*     */ 
/*     */ 
/*     */       
/* 144 */       DerefExpr byteValue = new DerefExpr(this.pointer.getRef(), Expressions.constantInt(fieldOffsetBits / 8), PointerType.BYTE);
/*     */ 
/*     */       
/* 147 */       BitFieldExpr bitFieldExpr = new BitFieldExpr(byteValue, fieldOffsetBits % 8, size);
/* 148 */       GimplePrimitiveType gimplePrimitiveType = (GimplePrimitiveType)type;
/* 149 */       PrimitiveType primitiveType = PrimitiveType.of(gimplePrimitiveType);
/*     */       
/* 151 */       return (GExpr)primitiveType.fromStackValue((JExpr)bitFieldExpr);
/*     */     } 
/*     */     
/* 154 */     throw new UnsupportedOperationException("TODO: bitfield, expectedType = " + type);
/*     */   }
/*     */   
/*     */   public JExpr getRef() {
/* 158 */     return this.pointer.getRef();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/vptr/VPtrRecordExpr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */