/*    */ package org.renjin.gcc.codegen.type.primitive;
/*    */ 
/*    */ import javax.annotation.Nonnull;
/*    */ import org.renjin.gcc.codegen.MethodGenerator;
/*    */ import org.renjin.gcc.codegen.expr.JExpr;
/*    */ import org.renjin.gcc.codegen.expr.JLValue;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FieldValue
/*    */   implements JLValue
/*    */ {
/*    */   private JExpr instance;
/*    */   private String fieldName;
/*    */   private Type fieldType;
/*    */   
/*    */   public FieldValue(JExpr instance, String fieldName, Type fieldType) {
/* 36 */     this.instance = instance;
/* 37 */     this.fieldName = fieldName;
/* 38 */     this.fieldType = fieldType;
/*    */   }
/*    */ 
/*    */   
/*    */   @Nonnull
/*    */   public Type getType() {
/* 44 */     return this.fieldType;
/*    */   }
/*    */ 
/*    */   
/*    */   public void load(@Nonnull MethodGenerator mv) {
/* 49 */     this.instance.load(mv);
/* 50 */     mv.getfield(this.instance.getType().getInternalName(), this.fieldName, this.fieldType.getDescriptor());
/*    */   }
/*    */ 
/*    */   
/*    */   public void store(MethodGenerator mv, JExpr value) {
/* 55 */     this.instance.load(mv);
/* 56 */     value.load(mv);
/* 57 */     mv.putfield(this.instance.getType().getInternalName(), this.fieldName, this.fieldType.getDescriptor());
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/type/primitive/FieldValue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */