/*     */ package org.renjin.gcc.codegen.vptr;
/*     */ 
/*     */ import java.util.Optional;
/*     */ import org.renjin.gcc.codegen.MethodGenerator;
/*     */ import org.renjin.gcc.codegen.expr.ExprFactory;
/*     */ import org.renjin.gcc.codegen.expr.Expressions;
/*     */ import org.renjin.gcc.codegen.expr.GExpr;
/*     */ import org.renjin.gcc.codegen.expr.JExpr;
/*     */ import org.renjin.gcc.codegen.expr.JLValue;
/*     */ import org.renjin.gcc.codegen.fatptr.FatPtrPair;
/*     */ import org.renjin.gcc.codegen.fatptr.ValueFunction;
/*     */ import org.renjin.gcc.codegen.type.FieldStrategy;
/*     */ import org.renjin.gcc.codegen.type.ParamStrategy;
/*     */ import org.renjin.gcc.codegen.type.PointerTypeStrategy;
/*     */ import org.renjin.gcc.codegen.type.ReturnStrategy;
/*     */ import org.renjin.gcc.codegen.type.TypeStrategy;
/*     */ import org.renjin.gcc.codegen.type.UnsupportedCastException;
/*     */ import org.renjin.gcc.codegen.var.GlobalVarAllocator;
/*     */ import org.renjin.gcc.codegen.var.VarAllocator;
/*     */ import org.renjin.gcc.gimple.GimpleVarDecl;
/*     */ import org.renjin.gcc.gimple.expr.GimpleConstructor;
/*     */ import org.renjin.gcc.gimple.type.GimpleArrayType;
/*     */ import org.renjin.gcc.gimple.type.GimplePointerType;
/*     */ import org.renjin.gcc.gimple.type.GimplePrimitiveType;
/*     */ import org.renjin.gcc.gimple.type.GimpleType;
/*     */ import org.renjin.gcc.runtime.MixedPtr;
/*     */ import org.renjin.gcc.runtime.PointerPtr;
/*     */ import org.renjin.gcc.runtime.Ptr;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VPtrStrategy
/*     */   implements PointerTypeStrategy
/*     */ {
/*  43 */   private static final Type POINTER_INTERFACE_TYPE = Type.getType(Ptr.class);
/*     */   
/*     */   private GimpleType baseType;
/*     */   private PointerType pointerType;
/*     */   
/*     */   public VPtrStrategy(GimpleType baseType) {
/*  49 */     this.baseType = baseType;
/*  50 */     this.pointerType = PointerType.ofType(baseType);
/*     */   }
/*     */ 
/*     */   
/*     */   public VPtrExpr malloc(MethodGenerator mv, JExpr sizeInBytes) {
/*  55 */     return malloc(this.baseType, sizeInBytes);
/*     */   }
/*     */ 
/*     */   
/*     */   public static VPtrExpr malloc(GimpleType baseType, JExpr sizeInBytes) {
/*  60 */     Type implType = choosePtrImplType(baseType);
/*     */     
/*  62 */     return malloc(implType, sizeInBytes);
/*     */   }
/*     */   
/*     */   static VPtrExpr malloc(Type implType, JExpr sizeInBytes) {
/*  66 */     String mallocDescriptor = Type.getMethodDescriptor(implType, new Type[] { Type.INT_TYPE });
/*  67 */     JExpr pointer = Expressions.staticMethodCall(implType, "malloc", mallocDescriptor, new JExpr[] { sizeInBytes });
/*     */     
/*  69 */     return new VPtrExpr(pointer);
/*     */   }
/*     */   
/*     */   private static Type choosePtrImplType(GimpleType baseType) {
/*  73 */     if (baseType instanceof GimplePrimitiveType) {
/*  74 */       return PointerType.ofPrimitiveType((GimplePrimitiveType)baseType).alignedImpl();
/*     */     }
/*  76 */     if (baseType instanceof GimpleArrayType) {
/*  77 */       return choosePtrImplType(((GimpleArrayType)baseType).getComponentType());
/*     */     }
/*  79 */     if (baseType instanceof org.renjin.gcc.gimple.type.GimpleIndirectType) {
/*  80 */       return Type.getType(PointerPtr.class);
/*     */     }
/*  82 */     if (baseType instanceof org.renjin.gcc.gimple.type.GimpleRecordType) {
/*  83 */       return Type.getType(MixedPtr.class);
/*     */     }
/*  85 */     if (baseType instanceof org.renjin.gcc.gimple.type.GimpleVoidType) {
/*  86 */       return Type.getType(MixedPtr.class);
/*     */     }
/*  88 */     throw new UnsupportedOperationException("TODO: " + baseType);
/*     */   }
/*     */ 
/*     */   
/*     */   public GExpr nullPointer() {
/*  93 */     JLValue jLValue = Expressions.staticField(this.pointerType.alignedImpl(), "NULL", this.pointerType.alignedImpl());
/*     */     
/*  95 */     return (GExpr)new VPtrExpr((JExpr)jLValue);
/*     */   }
/*     */ 
/*     */   
/*     */   public ParamStrategy getParamStrategy() {
/* 100 */     return new VPtrParamStrategy();
/*     */   }
/*     */ 
/*     */   
/*     */   public ReturnStrategy getReturnStrategy() {
/* 105 */     return new VPtrReturnStrategy();
/*     */   }
/*     */ 
/*     */   
/*     */   public ValueFunction getValueFunction() {
/* 110 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public GExpr variable(GimpleVarDecl decl, VarAllocator allocator) {
/* 115 */     if (decl.isAddressable()) {
/* 116 */       GimplePointerType pointerType = this.baseType.pointerTo();
/* 117 */       JLValue unitArray = allocator.reserveUnitArray(decl.getNameIfPresent(), POINTER_INTERFACE_TYPE, Optional.empty());
/* 118 */       return addressableExprFromUnitArray(pointerType, unitArray);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 124 */     JLValue pointer = allocator.reserve(decl.getNameIfPresent(), POINTER_INTERFACE_TYPE);
/* 125 */     JLValue offset = allocator.reserveOffsetInt(decl.getNameIfPresent());
/*     */     
/* 127 */     return (GExpr)new VPtrExpr((JExpr)pointer, (JExpr)offset);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public GExpr globalVariable(GimpleVarDecl decl, GlobalVarAllocator allocator) {
/* 133 */     GlobalVarAllocator.StaticField field = allocator.reserve(decl.getNameIfPresent(), POINTER_INTERFACE_TYPE);
/* 134 */     VPtrExpr addressExpr = new VPtrExpr(staticFieldPtr(field.getDeclaringClass(), field.getName()));
/* 135 */     return (GExpr)new VPtrExpr((JExpr)field, addressExpr);
/*     */   }
/*     */   
/*     */   private JExpr staticFieldPtr(Type declaringType, String fieldName) {
/* 139 */     Type ptrClassName = Type.getType("Lorg/renjin/gcc/runtime/PointerFieldPtr;");
/* 140 */     String addressOfDescriptor = Type.getMethodDescriptor(Type.getType(Ptr.class), new Type[] { Type.getType(Class.class), Type.getType(String.class) });
/* 141 */     return Expressions.staticMethodCall(ptrClassName, "addressOf", addressOfDescriptor, new JExpr[] {
/* 142 */           Expressions.constantClass(declaringType), Expressions.constantString(fieldName)
/*     */         });
/*     */   }
/*     */   
/*     */   public GExpr providedGlobalVariable(GimpleVarDecl decl, JExpr expr, boolean readOnly) {
/* 147 */     if (expr.getType().equals(POINTER_INTERFACE_TYPE)) {
/* 148 */       return (GExpr)new VPtrExpr(expr);
/*     */     }
/* 150 */     if (expr.getType().getSort() == 9 && expr
/* 151 */       .getType().getElementType().equals(POINTER_INTERFACE_TYPE))
/*     */     {
/* 153 */       return addressableExprFromUnitArray((GimplePointerType)decl.getType(), (JLValue)expr);
/*     */     }
/*     */     
/* 156 */     throw new UnsupportedOperationException("Cannot create expression for provided global variable " + decl + " with JVM type " + expr
/* 157 */         .getType());
/*     */   }
/*     */ 
/*     */   
/*     */   private GExpr addressableExprFromUnitArray(GimplePointerType pointerType, JLValue unitArray) {
/* 162 */     VPtrValueFunction valueFunction = new VPtrValueFunction((GimpleType)pointerType);
/* 163 */     FatPtrPair address = new FatPtrPair(valueFunction, (JExpr)unitArray, Expressions.constantInt(0));
/* 164 */     return address.valueOf((GimpleType)pointerType);
/*     */   }
/*     */ 
/*     */   
/*     */   public GExpr constructorExpr(ExprFactory exprFactory, MethodGenerator mv, GimpleConstructor value) {
/* 169 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public FieldStrategy fieldGenerator(Type className, String fieldName) {
/* 174 */     return (FieldStrategy)new VPtrFieldStrategy(className, fieldName);
/*     */   }
/*     */ 
/*     */   
/*     */   public FieldStrategy addressableFieldGenerator(Type className, String fieldName) {
/* 179 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public PointerTypeStrategy pointerTo() {
/* 184 */     return new VPtrStrategy((GimpleType)this.baseType.pointerTo().pointerTo());
/*     */   }
/*     */ 
/*     */   
/*     */   public VArrayStrategy arrayOf(GimpleArrayType arrayType) {
/* 189 */     return new VArrayStrategy(arrayType);
/*     */   }
/*     */ 
/*     */   
/*     */   public GExpr cast(MethodGenerator mv, GExpr value) throws UnsupportedCastException {
/* 194 */     return (GExpr)value.toVPtrExpr();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 199 */     return obj instanceof VPtrStrategy;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 204 */     return 1;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/vptr/VPtrStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */