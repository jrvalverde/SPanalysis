/*    */ package org.renjin.gcc.logging;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.renjin.repackaged.asm.Label;
/*    */ import org.renjin.repackaged.asm.MethodVisitor;
/*    */ import org.renjin.repackaged.guava.collect.HashMultimap;
/*    */ import org.renjin.repackaged.guava.collect.Multimap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BytecodeMap
/*    */   extends MethodVisitor
/*    */ {
/*    */   public static class Var
/*    */   {
/*    */     private String name;
/*    */     private String desc;
/*    */     private int index;
/*    */     
/*    */     public Var(String name, String desc, int index) {
/* 38 */       this.name = name;
/* 39 */       this.desc = desc;
/* 40 */       this.index = index;
/*    */     }
/*    */     
/*    */     public String getName() {
/* 44 */       return this.name;
/*    */     }
/*    */     
/*    */     public String getDesc() {
/* 48 */       return this.desc;
/*    */     }
/*    */     
/*    */     public int getIndex() {
/* 52 */       return this.index;
/*    */     }
/*    */   }
/*    */   
/* 56 */   private final Multimap<Label, Var> varMap = (Multimap<Label, Var>)HashMultimap.create();
/* 57 */   private final Map<Label, Integer> lineMap = new HashMap<>();
/*    */   
/* 59 */   private final Map<Integer, Var> currentVars = new HashMap<>();
/* 60 */   private int currentLine = -1;
/*    */   
/*    */   public BytecodeMap() {
/* 63 */     super(327680);
/*    */   }
/*    */ 
/*    */   
/*    */   public void visitLineNumber(int line, Label start) {
/* 68 */     this.lineMap.put(start, Integer.valueOf(line));
/*    */   }
/*    */ 
/*    */   
/*    */   public void visitLocalVariable(String name, String desc, String signature, Label start, Label end, int index) {
/* 73 */     this.varMap.put(start, new Var(name, desc, index));
/*    */   }
/*    */   
/*    */   public boolean isStarted() {
/* 77 */     return (this.currentLine != -1);
/*    */   }
/*    */   
/*    */   public int getCurrentLine() {
/* 81 */     return this.currentLine;
/*    */   }
/*    */   
/*    */   public Var getCurrentVar(int index) {
/* 85 */     return this.currentVars.get(Integer.valueOf(index));
/*    */   }
/*    */   
/*    */   public void onLabel(Label label) {
/* 89 */     Integer line = this.lineMap.get(label);
/* 90 */     if (line != null) {
/* 91 */       this.currentLine = line.intValue();
/*    */     }
/*    */     
/* 94 */     for (Var var : this.varMap.get(label))
/* 95 */       this.currentVars.put(Integer.valueOf(var.index), var); 
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/logging/BytecodeMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */