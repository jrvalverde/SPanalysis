/*     */ package org.renjin.gcc.peephole;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.renjin.repackaged.asm.Label;
/*     */ import org.renjin.repackaged.asm.MethodVisitor;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ import org.renjin.repackaged.asm.tree.AbstractInsnNode;
/*     */ import org.renjin.repackaged.asm.tree.IincInsnNode;
/*     */ import org.renjin.repackaged.asm.tree.JumpInsnNode;
/*     */ import org.renjin.repackaged.asm.tree.MethodNode;
/*     */ import org.renjin.repackaged.asm.tree.VarInsnNode;
/*     */ import org.renjin.repackaged.asm.util.Printer;
/*     */ import org.renjin.repackaged.asm.util.Textifier;
/*     */ import org.renjin.repackaged.asm.util.TraceMethodVisitor;
/*     */ import org.renjin.repackaged.guava.collect.Lists;
/*     */ import org.renjin.repackaged.guava.collect.Sets;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PeepholeOptimizer
/*     */ {
/*  39 */   public static PeepholeOptimizer INSTANCE = new PeepholeOptimizer();
/*     */   
/*  41 */   private List<PeepholeOptimization> optimizations = Lists.newArrayList();
/*     */   
/*     */   public PeepholeOptimizer() {
/*  44 */     this.optimizations.add(new StoreLoad());
/*  45 */     this.optimizations.add(new LoadLoad());
/*  46 */     this.optimizations.add(new IntegerIncrement());
/*  47 */     this.optimizations.add(new ConstantMath());
/*  48 */     this.optimizations.add(new ZeroComparison());
/*  49 */     this.optimizations.add(new ZeroAdd());
/*  50 */     this.optimizations.add(new ConstantBranch());
/*  51 */     this.optimizations.add(new PointerPlus());
/*  52 */     this.optimizations.add(new PointerAccess());
/*     */   }
/*     */   
/*     */   public void optimize(MethodNode methodNode) {
/*     */     boolean changing;
/*  57 */     methodNode.accept((MethodVisitor)new TraceMethodVisitor((Printer)new Textifier()));
/*     */     
/*  59 */     Set<Label> jumpTargets = findJumpTargets(methodNode);
/*     */ 
/*     */     
/*     */     do {
/*  63 */       NodeIt it = new NodeIt(methodNode.instructions, jumpTargets);
/*  64 */       changing = false;
/*     */       do {
/*  66 */         for (PeepholeOptimization optimization : this.optimizations) {
/*  67 */           if (optimization.apply(it)) {
/*  68 */             changing = true;
/*     */           }
/*     */         } 
/*  71 */       } while (it.next());
/*     */       
/*  73 */       if (!propagateConstants(methodNode, jumpTargets))
/*  74 */         continue;  changing = true;
/*     */     }
/*  76 */     while (changing);
/*     */   }
/*     */ 
/*     */   
/*     */   private Set<Label> findJumpTargets(MethodNode methodNode) {
/*  81 */     Set<Label> targets = Sets.newHashSet();
/*  82 */     ListIterator<AbstractInsnNode> it = methodNode.instructions.iterator();
/*  83 */     while (it.hasNext()) {
/*  84 */       AbstractInsnNode node = it.next();
/*  85 */       if (node instanceof JumpInsnNode) {
/*  86 */         JumpInsnNode jumpNode = (JumpInsnNode)node;
/*  87 */         targets.add(jumpNode.label.getLabel());
/*     */       } 
/*     */     } 
/*  90 */     return targets;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean propagateConstants(MethodNode methodNode, Set<Label> jumpTargets) {
/*  97 */     Set<Integer> stores = new HashSet<>();
/*  98 */     Set<Integer> multipleStores = new HashSet<>();
/*     */ 
/*     */     
/* 101 */     int parameterIndex = 0;
/* 102 */     for (Type parameterType : Type.getArgumentTypes(methodNode.desc)) {
/* 103 */       for (int i = 0; i < parameterType.getSize(); i++) {
/* 104 */         multipleStores.add(Integer.valueOf(parameterIndex++));
/*     */       }
/*     */     } 
/* 107 */     NodeIt it = new NodeIt(methodNode.instructions, jumpTargets);
/*     */     do {
/* 109 */       if (it.matches(new Pattern[] { Pattern.ISTORE })) {
/* 110 */         VarInsnNode store = it.<VarInsnNode>get(0);
/* 111 */         if (!stores.add(Integer.valueOf(store.var))) {
/* 112 */           multipleStores.add(Integer.valueOf(store.var));
/*     */         }
/* 114 */       } else if (it.matches(new Pattern[] { Pattern.IINC })) {
/* 115 */         IincInsnNode iinc = it.<IincInsnNode>get(0);
/* 116 */         multipleStores.add(Integer.valueOf(iinc.var));
/*     */       } 
/* 118 */     } while (it.next());
/*     */     
/* 120 */     Sets.SetView setView = Sets.difference(stores, multipleStores);
/*     */ 
/*     */     
/* 123 */     Map<Integer, Integer> constantStores = new HashMap<>();
/* 124 */     it.reset();
/*     */     do {
/* 126 */       if (!it.matches(new Pattern[] { Pattern.ICONST, Pattern.ISTORE }))
/* 127 */         continue;  VarInsnNode store = it.<VarInsnNode>get(1);
/* 128 */       if (!setView.contains(Integer.valueOf(store.var)))
/* 129 */         continue;  int constantValue = Instructions.getInteger(it.get(0));
/* 130 */       constantStores.put(Integer.valueOf(store.var), Integer.valueOf(constantValue));
/*     */     
/*     */     }
/* 133 */     while (it.next());
/*     */ 
/*     */ 
/*     */     
/* 137 */     boolean changed = false;
/* 138 */     it.reset();
/*     */     do {
/* 140 */       if (it.matches(new Pattern[] { Pattern.ICONST, Pattern.ISTORE })) {
/* 141 */         VarInsnNode store = it.<VarInsnNode>get(1);
/* 142 */         if (constantStores.containsKey(Integer.valueOf(store.var))) {
/* 143 */           it.remove(2);
/*     */         }
/* 145 */       } else if (it.matches(new Pattern[] { Pattern.ILOAD })) {
/* 146 */         VarInsnNode load = it.<VarInsnNode>get(0);
/* 147 */         Integer constantValue = constantStores.get(Integer.valueOf(load.var));
/* 148 */         if (constantValue != null) {
/* 149 */           it.remove(1);
/* 150 */           it.insert(new AbstractInsnNode[] { Instructions.constantNode(constantValue.intValue()) });
/* 151 */           changed = true;
/*     */         } 
/*     */       } 
/* 154 */     } while (it.next());
/*     */     
/* 156 */     return changed;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/peephole/PeepholeOptimizer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */