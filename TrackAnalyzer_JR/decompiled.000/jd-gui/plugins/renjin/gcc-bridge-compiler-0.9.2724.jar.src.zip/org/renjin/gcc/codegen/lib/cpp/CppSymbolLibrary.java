/*    */ package org.renjin.gcc.codegen.lib.cpp;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import org.renjin.gcc.codegen.call.CallGenerator;
/*    */ import org.renjin.gcc.codegen.call.FreeCallGenerator;
/*    */ import org.renjin.gcc.codegen.call.MallocCallGenerator;
/*    */ import org.renjin.gcc.codegen.lib.SymbolFunction;
/*    */ import org.renjin.gcc.codegen.lib.SymbolLibrary;
/*    */ import org.renjin.gcc.codegen.lib.SymbolMethod;
/*    */ import org.renjin.gcc.codegen.type.TypeOracle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CppSymbolLibrary
/*    */   implements SymbolLibrary
/*    */ {
/*    */   public List<SymbolFunction> getFunctions(TypeOracle typeOracle) {
/* 37 */     List<SymbolFunction> functions = new ArrayList<>();
/* 38 */     functions.add(new SymbolFunction("_Znwj", (CallGenerator)new MallocCallGenerator(typeOracle)));
/* 39 */     functions.add(new SymbolFunction("operator delete", (CallGenerator)new FreeCallGenerator()));
/* 40 */     functions.add(new SymbolFunction("__comp_ctor ", new CtorCallGenerator()));
/* 41 */     functions.add(new SymbolFunction("__comp_dtor ", new DtorCallGenerator()));
/* 42 */     return functions;
/*    */   }
/*    */ 
/*    */   
/*    */   public List<SymbolMethod> getMethods() {
/* 47 */     return Collections.emptyList();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/lib/cpp/CppSymbolLibrary.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */