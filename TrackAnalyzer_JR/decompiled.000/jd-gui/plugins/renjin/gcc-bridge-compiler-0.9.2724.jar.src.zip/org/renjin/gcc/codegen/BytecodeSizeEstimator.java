/*     */ package org.renjin.gcc.codegen;
/*     */ 
/*     */ import org.renjin.repackaged.asm.Handle;
/*     */ import org.renjin.repackaged.asm.Label;
/*     */ import org.renjin.repackaged.asm.MethodVisitor;
/*     */ import org.renjin.repackaged.asm.tree.MethodNode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BytecodeSizeEstimator
/*     */   extends MethodVisitor
/*     */ {
/*  32 */   private int bytes = 0;
/*     */   
/*     */   public BytecodeSizeEstimator(int api) {
/*  35 */     super(api);
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitInsn(int opcode) {
/*  40 */     this.bytes++;
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitIntInsn(int opcode, int operand) {
/*  45 */     this.bytes++;
/*  46 */     switch (opcode) {
/*     */       case 17:
/*  48 */         this.bytes += 2;
/*     */         return;
/*     */     } 
/*  51 */     this.bytes++;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void visitVarInsn(int opcode, int var) {
/*  59 */     if (var <= 3) {
/*     */       
/*  61 */       this.bytes++;
/*  62 */     } else if (var < 255) {
/*     */ 
/*     */       
/*  65 */       this.bytes += 2;
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/*  72 */       this.bytes += 4;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void visitFieldInsn(int opcode, String owner, String name, String desc) {
/*  81 */     this.bytes += 3;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void visitLdcInsn(Object cst) {
/*  94 */     this.bytes += 2;
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitIincInsn(int var, int increment) {
/*  99 */     if (var < 255) {
/*     */ 
/*     */ 
/*     */       
/* 103 */       this.bytes += 3;
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */ 
/*     */       
/* 111 */       this.bytes += 6;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void visitMethodInsn(int opcode, String owner, String name, String desc, boolean itf) {
/* 121 */     this.bytes += 3;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void visitJumpInsn(int opcode, Label label) {
/* 129 */     this.bytes += 3;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void visitInvokeDynamicInsn(String name, String desc, Handle bsm, Object... bsmArgs) {
/* 138 */     this.bytes += 4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void visitTableSwitchInsn(int min, int max, Label dflt, Label... labels) {
/* 158 */     this.bytes += 16 + labels.length * 2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void visitMultiANewArrayInsn(String desc, int dims) {
/* 168 */     this.bytes += 4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void visitTypeInsn(int opcode, String type) {
/* 176 */     this.bytes += 3;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void visitLookupSwitchInsn(Label dflt, int[] keys, Label[] labels) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int estimateSize(MethodNode methodNode) {
/* 195 */     BytecodeSizeEstimator estimator = new BytecodeSizeEstimator(327680);
/* 196 */     methodNode.accept(estimator);
/* 197 */     return estimator.bytes;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/BytecodeSizeEstimator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */