/*     */ package org.renjin.gcc.gimple.type;
/*     */ 
/*     */ import org.renjin.gcc.gimple.expr.GimpleExpr;
/*     */ import org.renjin.gcc.gimple.expr.GimpleFieldRef;
/*     */ import org.renjin.repackaged.guava.base.Strings;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GimpleField
/*     */ {
/*     */   private long id;
/*     */   private int offset;
/*     */   private int size;
/*     */   private String name;
/*     */   private GimpleType type;
/*     */   private boolean addressed;
/*     */   private boolean referenced;
/*     */   
/*     */   public GimpleField() {}
/*     */   
/*     */   public GimpleField(String name, GimpleType type) {
/*  38 */     this.name = name;
/*  39 */     this.type = type;
/*     */   }
/*     */   
/*     */   public GimpleField(String name, GimpleType type, int offset) {
/*  43 */     this.offset = offset;
/*  44 */     this.size = type.getSize();
/*  45 */     this.name = name;
/*  46 */     this.type = type;
/*     */   }
/*     */   
/*     */   public boolean isAddressed() {
/*  50 */     return this.addressed;
/*     */   }
/*     */   
/*     */   public void setAddressed(boolean addressed) {
/*  54 */     this.addressed = addressed;
/*     */   }
/*     */   
/*     */   public boolean isReferenced() {
/*  58 */     return this.referenced;
/*     */   }
/*     */   
/*     */   public void setReferenced(boolean referenced) {
/*  62 */     this.referenced = referenced;
/*     */   }
/*     */   
/*     */   public String getName() {
/*  66 */     return Strings.nullToEmpty(this.name);
/*     */   }
/*     */   public void setName(String name) {
/*  69 */     this.name = name;
/*     */   }
/*     */   public GimpleType getType() {
/*  72 */     return this.type;
/*     */   }
/*     */   public void setType(GimpleType type) {
/*  75 */     this.type = type;
/*     */   }
/*     */ 
/*     */   
/*     */   public long getId() {
/*  80 */     return this.id;
/*     */   }
/*     */   
/*     */   public void setId(long id) {
/*  84 */     this.id = id;
/*     */   }
/*     */   
/*     */   public int getOffset() {
/*  88 */     return this.offset;
/*     */   }
/*     */   
/*     */   public void setOffset(int offset) {
/*  92 */     this.offset = offset;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getSize() {
/*  97 */     return this.size;
/*     */   }
/*     */   
/*     */   public void setSize(int size) {
/* 101 */     this.size = size;
/*     */   }
/*     */   
/*     */   public boolean hasName() {
/* 105 */     return (this.name != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 110 */     return "GimpleField[" + (this.addressed ? "&" : "") + this.name + ":" + this.type + "]";
/*     */   }
/*     */   
/*     */   public GimpleExpr refTo() {
/* 114 */     return (GimpleExpr)new GimpleFieldRef(this.name, this.offset, this.type);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/gimple/type/GimpleField.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */