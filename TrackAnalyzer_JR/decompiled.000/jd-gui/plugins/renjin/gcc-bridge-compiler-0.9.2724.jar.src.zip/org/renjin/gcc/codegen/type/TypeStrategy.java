/*    */ package org.renjin.gcc.codegen.type;
/*    */ 
/*    */ import org.renjin.gcc.codegen.MethodGenerator;
/*    */ import org.renjin.gcc.codegen.expr.ExprFactory;
/*    */ import org.renjin.gcc.codegen.expr.GExpr;
/*    */ import org.renjin.gcc.codegen.expr.JExpr;
/*    */ import org.renjin.gcc.codegen.fatptr.ValueFunction;
/*    */ import org.renjin.gcc.codegen.var.GlobalVarAllocator;
/*    */ import org.renjin.gcc.codegen.var.VarAllocator;
/*    */ import org.renjin.gcc.gimple.GimpleVarDecl;
/*    */ import org.renjin.gcc.gimple.expr.GimpleConstructor;
/*    */ import org.renjin.gcc.gimple.type.GimpleArrayType;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface TypeStrategy<ExprT extends GExpr>
/*    */ {
/*    */   ParamStrategy getParamStrategy();
/*    */   
/*    */   ReturnStrategy getReturnStrategy();
/*    */   
/*    */   ValueFunction getValueFunction();
/*    */   
/*    */   ExprT variable(GimpleVarDecl paramGimpleVarDecl, VarAllocator paramVarAllocator);
/*    */   
/*    */   default ExprT globalVariable(GimpleVarDecl decl, GlobalVarAllocator allocator) {
/* 58 */     return variable(decl, (VarAllocator)allocator);
/*    */   }
/*    */   
/*    */   ExprT providedGlobalVariable(GimpleVarDecl paramGimpleVarDecl, JExpr paramJExpr, boolean paramBoolean);
/*    */   
/*    */   ExprT constructorExpr(ExprFactory paramExprFactory, MethodGenerator paramMethodGenerator, GimpleConstructor paramGimpleConstructor);
/*    */   
/*    */   FieldStrategy fieldGenerator(Type paramType, String paramString);
/*    */   
/*    */   FieldStrategy addressableFieldGenerator(Type paramType, String paramString);
/*    */   
/*    */   PointerTypeStrategy pointerTo();
/*    */   
/*    */   TypeStrategy arrayOf(GimpleArrayType paramGimpleArrayType);
/*    */   
/*    */   ExprT cast(MethodGenerator paramMethodGenerator, GExpr paramGExpr) throws UnsupportedCastException;
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/type/TypeStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */