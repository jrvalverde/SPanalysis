/*     */ package org.renjin.gcc.codegen.type.primitive;
/*     */ 
/*     */ import javax.annotation.Nullable;
/*     */ import org.renjin.gcc.codegen.MethodGenerator;
/*     */ import org.renjin.gcc.codegen.condition.ConditionGenerator;
/*     */ import org.renjin.gcc.codegen.condition.IntegerComparison;
/*     */ import org.renjin.gcc.codegen.expr.Expressions;
/*     */ import org.renjin.gcc.codegen.expr.GExpr;
/*     */ import org.renjin.gcc.codegen.expr.JExpr;
/*     */ import org.renjin.gcc.codegen.expr.JLValue;
/*     */ import org.renjin.gcc.codegen.expr.PtrExpr;
/*     */ import org.renjin.gcc.codegen.type.NumericExpr;
/*     */ import org.renjin.gcc.gimple.GimpleOp;
/*     */ import org.renjin.gcc.gimple.type.GimpleIntegerType;
/*     */ import org.renjin.gcc.gimple.type.GimplePrimitiveType;
/*     */ import org.renjin.gcc.gimple.type.GimpleRealType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SignedIntExpr
/*     */   extends AbstractIntExpr
/*     */ {
/*     */   public SignedIntExpr(JExpr expr, @Nullable PtrExpr address) {
/*  42 */     super(expr, address);
/*     */   }
/*     */   
/*     */   public SignedIntExpr(JExpr expr) {
/*  46 */     this(expr, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void store(MethodGenerator mv, GExpr rhs) {
/*  51 */     ((JLValue)jexpr()).store(mv, jexpr(rhs));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public SignedIntExpr plus(GExpr operand) {
/*  57 */     return lift(Expressions.sum(jexpr(), jexpr(operand)));
/*     */   }
/*     */ 
/*     */   
/*     */   public SignedIntExpr minus(GExpr operand) {
/*  62 */     return lift(Expressions.difference(jexpr(), jexpr(operand)));
/*     */   }
/*     */ 
/*     */   
/*     */   public SignedIntExpr multiply(GExpr operand) {
/*  67 */     return lift(Expressions.product(jexpr(), jexpr(operand)));
/*     */   }
/*     */ 
/*     */   
/*     */   public SignedIntExpr divide(GExpr operand) {
/*  72 */     return lift(Expressions.divide(jexpr(), jexpr(operand)));
/*     */   }
/*     */ 
/*     */   
/*     */   public SignedIntExpr negative() {
/*  77 */     return lift(Expressions.negative(jexpr()));
/*     */   }
/*     */ 
/*     */   
/*     */   public SignedIntExpr min(GExpr operand) {
/*  82 */     return lift(Expressions.staticMethodCall(Math.class, "min", "(II)I", new JExpr[] { jexpr(), jexpr(operand) }));
/*     */   }
/*     */ 
/*     */   
/*     */   public SignedIntExpr max(GExpr operand) {
/*  87 */     return lift(Expressions.staticMethodCall(Math.class, "max", "(II)I", new JExpr[] { jexpr(), jexpr(operand) }));
/*     */   }
/*     */ 
/*     */   
/*     */   public SignedIntExpr absoluteValue() {
/*  92 */     return lift(Expressions.staticMethodCall(Math.class, "abs", "(I)I", new JExpr[] { jexpr() }));
/*     */   }
/*     */ 
/*     */   
/*     */   public SignedIntExpr remainder(GExpr operand) {
/*  97 */     return lift(Expressions.remainder(jexpr(), jexpr(operand)));
/*     */   }
/*     */ 
/*     */   
/*     */   public ConditionGenerator compareTo(GimpleOp op, GExpr operand) {
/* 102 */     return (ConditionGenerator)new IntegerComparison(op, jexpr(), jexpr(operand));
/*     */   }
/*     */ 
/*     */   
/*     */   public NumericIntExpr bitwiseXor(GExpr operand) {
/* 107 */     return lift(Expressions.bitwiseXor(jexpr(), jexpr(operand)));
/*     */   }
/*     */ 
/*     */   
/*     */   public NumericIntExpr bitwiseNot() {
/* 112 */     return lift(Expressions.bitwiseXor(jexpr(), Expressions.constantInt(-1)));
/*     */   }
/*     */ 
/*     */   
/*     */   public NumericIntExpr bitwiseAnd(GExpr operand) {
/* 117 */     return lift(Expressions.bitwiseAnd(jexpr(), jexpr(operand)));
/*     */   }
/*     */ 
/*     */   
/*     */   public NumericIntExpr bitwiseOr(GExpr operand) {
/* 122 */     return lift(Expressions.bitwiseOr(jexpr(), jexpr(operand)));
/*     */   }
/*     */ 
/*     */   
/*     */   public IntExpr shiftLeft(GExpr operand) {
/* 127 */     return lift(Expressions.shiftLeft(jexpr(), jexpr(operand)));
/*     */   }
/*     */ 
/*     */   
/*     */   public IntExpr shiftRight(GExpr operand) {
/* 132 */     return lift(Expressions.shiftRight(jexpr(), jexpr(operand)));
/*     */   }
/*     */ 
/*     */   
/*     */   public IntExpr rotateLeft(GExpr operand) {
/* 137 */     return lift(Expressions.staticMethodCall(Integer.class, "rotateLeft", "(II)I", new JExpr[] { jexpr(), jexpr(operand) }));
/*     */   }
/*     */ 
/*     */   
/*     */   public GimplePrimitiveType getType() {
/* 142 */     return (GimplePrimitiveType)new GimpleIntegerType(32);
/*     */   }
/*     */ 
/*     */   
/*     */   public RealExpr toRealExpr() {
/* 147 */     return toReal(32);
/*     */   }
/*     */ 
/*     */   
/*     */   public IntExpr toSignedInt(int precision) {
/* 152 */     switch (precision) {
/*     */       case 8:
/* 154 */         return new SignedByteExpr(Expressions.i2b(jexpr()));
/*     */       case 16:
/* 156 */         return new ShortExpr(Expressions.i2s(jexpr()));
/*     */       case 32:
/* 158 */         return this;
/*     */       case 64:
/* 160 */         return new SignedLongExpr(Expressions.i2l(jexpr()));
/*     */     } 
/* 162 */     throw new IllegalArgumentException("precision" + precision);
/*     */   }
/*     */ 
/*     */   
/*     */   public IntExpr toUnsignedInt(int precision) {
/* 167 */     switch (precision) {
/*     */       case 8:
/* 169 */         return new UnsignedSmallIntExpr(8, Expressions.bitwiseAnd(jexpr(), 255));
/*     */       case 16:
/* 171 */         return new UnsignedSmallIntExpr(16, Expressions.i2c(jexpr()));
/*     */       case 32:
/* 173 */         return new UnsignedIntExpr(jexpr());
/*     */       case 64:
/* 175 */         return new SignedLongExpr(Expressions.i2l(jexpr()));
/*     */     } 
/* 177 */     throw new UnsupportedOperationException("unsigned" + precision);
/*     */   }
/*     */ 
/*     */   
/*     */   public RealExpr toReal(int precision) {
/* 182 */     switch (precision) {
/*     */       case 32:
/* 184 */         return new RealExpr(new GimpleRealType(32), Expressions.i2f(jexpr()));
/*     */       case 64:
/*     */       case 96:
/* 187 */         return new RealExpr(new GimpleRealType(precision), Expressions.i2d(jexpr()));
/*     */     } 
/*     */     
/* 190 */     throw new UnsupportedOperationException("real" + precision);
/*     */   }
/*     */   
/*     */   private JExpr jexpr(GExpr operand) {
/* 194 */     return operand.toPrimitiveExpr().toSignedInt(32).jexpr();
/*     */   }
/*     */   
/*     */   private SignedIntExpr lift(JExpr expr) {
/* 198 */     return new SignedIntExpr(expr);
/*     */   }
/*     */ 
/*     */   
/*     */   public BooleanExpr toBooleanExpr() {
/* 203 */     return BooleanExpr.fromInt(jexpr());
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/type/primitive/SignedIntExpr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */