/*    */ package org.renjin.gcc;
/*    */ 
/*    */ import org.renjin.gcc.codegen.FunctionGenerator;
/*    */ import org.renjin.gcc.gimple.GimpleFunction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InternalCompilerException
/*    */   extends RuntimeException
/*    */ {
/*    */   public InternalCompilerException() {}
/*    */   
/*    */   public InternalCompilerException(String message) {
/* 34 */     super(message);
/*    */   }
/*    */   
/*    */   public InternalCompilerException(String message, Throwable cause) {
/* 38 */     super(message, cause);
/*    */   }
/*    */ 
/*    */   
/*    */   public InternalCompilerException(GimpleFunction function, Exception e) {
/* 43 */     super(String.format("Exception compiling function %s [%s] in unit %s", new Object[] { function
/* 44 */             .getName(), function
/* 45 */             .getMangledName(), function
/* 46 */             .getUnit().getSourceFile().getName() }), e);
/*    */   }
/*    */   
/*    */   public InternalCompilerException(FunctionGenerator functionGenerator, Exception e) {
/* 50 */     this(functionGenerator.getFunction(), e);
/*    */   }
/*    */   
/*    */   public InternalCompilerException(Exception e) {
/* 54 */     super(e);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/InternalCompilerException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */