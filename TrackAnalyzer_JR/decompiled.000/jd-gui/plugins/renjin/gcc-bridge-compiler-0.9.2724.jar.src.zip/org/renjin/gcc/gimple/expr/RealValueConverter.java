/*    */ package org.renjin.gcc.gimple.expr;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.JavaType;
/*    */ import com.fasterxml.jackson.databind.type.TypeFactory;
/*    */ import com.fasterxml.jackson.databind.util.Converter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RealValueConverter
/*    */   implements Converter<Object, Double>
/*    */ {
/*    */   public Double convert(Object value) {
/* 31 */     if (value instanceof Number)
/* 32 */       return Double.valueOf(((Number)value).doubleValue()); 
/* 33 */     if (value instanceof String) {
/* 34 */       return Double.valueOf(parseString((String)value));
/*    */     }
/* 36 */     throw new RuntimeException("invalid value: " + value);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public JavaType getInputType(TypeFactory typeFactory) {
/* 42 */     return typeFactory.constructType(String.class);
/*    */   }
/*    */ 
/*    */   
/*    */   public JavaType getOutputType(TypeFactory typeFactory) {
/* 47 */     return typeFactory.constructType(Double.class);
/*    */   }
/*    */   
/*    */   private double parseString(String stringValue) {
/* 51 */     if (stringValue.equals("Inf"))
/* 52 */       return Double.POSITIVE_INFINITY; 
/* 53 */     if (stringValue.equals("-Inf")) {
/* 54 */       return Double.NEGATIVE_INFINITY;
/*    */     }
/* 56 */     return Double.parseDouble(stringValue);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/gimple/expr/RealValueConverter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */