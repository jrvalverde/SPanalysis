/*     */ package org.renjin.gcc.codegen.type.record;
/*     */ 
/*     */ import javax.annotation.Nonnull;
/*     */ import org.renjin.gcc.codegen.MethodGenerator;
/*     */ import org.renjin.gcc.codegen.array.FatArrayExpr;
/*     */ import org.renjin.gcc.codegen.condition.ConditionGenerator;
/*     */ import org.renjin.gcc.codegen.expr.Expressions;
/*     */ import org.renjin.gcc.codegen.expr.GExpr;
/*     */ import org.renjin.gcc.codegen.expr.JExpr;
/*     */ import org.renjin.gcc.codegen.expr.JLValue;
/*     */ import org.renjin.gcc.codegen.expr.NotAddressableException;
/*     */ import org.renjin.gcc.codegen.expr.PtrExpr;
/*     */ import org.renjin.gcc.codegen.expr.RefPtrExpr;
/*     */ import org.renjin.gcc.codegen.fatptr.FatPtr;
/*     */ import org.renjin.gcc.codegen.fatptr.ValueFunction;
/*     */ import org.renjin.gcc.codegen.type.NumericExpr;
/*     */ import org.renjin.gcc.codegen.type.UnsupportedCastException;
/*     */ import org.renjin.gcc.codegen.type.fun.FunPtrExpr;
/*     */ import org.renjin.gcc.codegen.type.primitive.PrimitiveExpr;
/*     */ import org.renjin.gcc.codegen.type.primitive.PrimitiveType;
/*     */ import org.renjin.gcc.codegen.type.voidt.VoidPtrExpr;
/*     */ import org.renjin.gcc.codegen.vptr.VArrayExpr;
/*     */ import org.renjin.gcc.codegen.vptr.VPtrExpr;
/*     */ import org.renjin.gcc.codegen.vptr.VPtrRecordExpr;
/*     */ import org.renjin.gcc.gimple.GimpleOp;
/*     */ import org.renjin.gcc.gimple.type.GimpleArrayType;
/*     */ import org.renjin.gcc.gimple.type.GimpleRecordType;
/*     */ import org.renjin.gcc.gimple.type.GimpleType;
/*     */ import org.renjin.gcc.runtime.RecordUnitPtr;
/*     */ import org.renjin.repackaged.asm.Label;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProvidedPtrExpr
/*     */   implements RefPtrExpr
/*     */ {
/*     */   private JExpr ref;
/*     */   private FatPtr address;
/*     */   
/*     */   public ProvidedPtrExpr(JExpr ref) {
/*  52 */     this.ref = ref;
/*     */   }
/*     */   
/*     */   public ProvidedPtrExpr(JExpr ref, FatPtr address) {
/*  56 */     this.ref = ref;
/*  57 */     this.address = address;
/*     */   }
/*     */   
/*     */   public Type getJvmType() {
/*  61 */     return this.ref.getType();
/*     */   }
/*     */ 
/*     */   
/*     */   public void store(MethodGenerator mv, GExpr rhs) {
/*  66 */     ((JLValue)this.ref).store(mv, rhs.toProvidedPtrExpr(this.ref.getType()).jexpr());
/*     */   }
/*     */ 
/*     */   
/*     */   public PtrExpr addressOf() {
/*  71 */     if (this.address == null) {
/*  72 */       throw new NotAddressableException();
/*     */     }
/*  74 */     return (PtrExpr)this.address;
/*     */   }
/*     */   
/*     */   public JExpr jexpr() {
/*  78 */     return this.ref;
/*     */   }
/*     */ 
/*     */   
/*     */   public void jumpIfNull(MethodGenerator mv, Label label) {
/*  83 */     this.ref.load(mv);
/*  84 */     mv.ifnull(label);
/*     */   }
/*     */ 
/*     */   
/*     */   public JExpr memoryCompare(MethodGenerator mv, PtrExpr otherPointer, JExpr n) {
/*  89 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void memorySet(MethodGenerator mv, JExpr byteValue, JExpr length) {
/*  94 */     jexpr().load(mv);
/*  95 */     byteValue.load(mv);
/*  96 */     length.load(mv);
/*  97 */     mv.invokevirtual(getJvmType(), "memset", 
/*  98 */         Type.getMethodDescriptor(Type.VOID_TYPE, new Type[] { Type.INT_TYPE, Type.INT_TYPE }), false);
/*     */   }
/*     */ 
/*     */   
/*     */   public PtrExpr realloc(MethodGenerator mv, JExpr newSizeInBytes) {
/* 103 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PtrExpr pointerPlus(MethodGenerator mv, final JExpr offsetInBytes) {
/* 111 */     JExpr expr = new JExpr()
/*     */       {
/*     */         @Nonnull
/*     */         public Type getType() {
/* 115 */           return ProvidedPtrExpr.this.getJvmType();
/*     */         }
/*     */ 
/*     */         
/*     */         public void load(@Nonnull MethodGenerator mv) {
/* 120 */           Label zero = new Label();
/* 121 */           offsetInBytes.load(mv);
/* 122 */           mv.ifeq(zero);
/* 123 */           mv.anew(Type.getType(ArrayIndexOutOfBoundsException.class));
/* 124 */           mv.dup();
/* 125 */           mv.invokeconstructor(Type.getType(ArrayIndexOutOfBoundsException.class), new Type[0]);
/* 126 */           mv.athrow();
/* 127 */           mv.mark(zero);
/* 128 */           ProvidedPtrExpr.this.ref.load(mv);
/*     */         }
/*     */       };
/*     */     
/* 132 */     return (PtrExpr)new ProvidedPtrExpr(expr);
/*     */   }
/*     */ 
/*     */   
/*     */   public GExpr valueOf(GimpleType expectedType) {
/* 137 */     throw new UnsupportedOperationException(
/* 138 */         String.format("Provided type '%s' is opaque and may not be dereferenced.", new Object[] { getJvmType() }));
/*     */   }
/*     */ 
/*     */   
/*     */   public ConditionGenerator comparePointer(MethodGenerator mv, GimpleOp op, GExpr otherPointer) {
/* 143 */     return ReferenceConditions.compare(op, jexpr(), otherPointer.toProvidedPtrExpr(getJvmType()).jexpr());
/*     */   }
/*     */ 
/*     */   
/*     */   public FunPtrExpr toFunPtr() {
/* 148 */     return FunPtrExpr.NULL_PTR;
/*     */   }
/*     */ 
/*     */   
/*     */   public FatArrayExpr toArrayExpr() throws UnsupportedCastException {
/* 153 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public PrimitiveExpr toPrimitiveExpr() throws UnsupportedCastException {
/* 158 */     return PrimitiveType.UINT32.fromStackValue(Expressions.identityHash(this.ref));
/*     */   }
/*     */ 
/*     */   
/*     */   public VoidPtrExpr toVoidPtrExpr() throws UnsupportedCastException {
/* 163 */     return new VoidPtrExpr(this.ref);
/*     */   }
/*     */ 
/*     */   
/*     */   public VPtrExpr toVPtrExpr() throws UnsupportedCastException {
/* 168 */     return new VPtrExpr(Expressions.newObject(RecordUnitPtr.class, 
/* 169 */           Type.getMethodDescriptor(Type.VOID_TYPE, new Type[] { Type.getType(Object.class) }), new JExpr[] { this.ref }));
/*     */   }
/*     */ 
/*     */   
/*     */   public ProvidedPtrExpr toProvidedPtrExpr(Type jvmType) {
/* 174 */     return new ProvidedPtrExpr(Expressions.cast(jexpr(), jvmType));
/*     */   }
/*     */ 
/*     */   
/*     */   public FatPtr toFatPtrExpr(ValueFunction valueFunction) {
/* 179 */     throw new UnsupportedCastException();
/*     */   }
/*     */ 
/*     */   
/*     */   public VPtrRecordExpr toVPtrRecord(GimpleRecordType recordType) {
/* 184 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public VArrayExpr toVArray(GimpleArrayType arrayType) {
/* 189 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public NumericExpr toNumericExpr() {
/* 194 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void memoryCopy(MethodGenerator mv, PtrExpr source, JExpr length, boolean buffer) {
/* 199 */     this.ref.load(mv);
/* 200 */     source.toProvidedPtrExpr(getJvmType()).jexpr().load(mv);
/* 201 */     mv.invokevirtual(getJvmType(), "set", Type.getMethodDescriptor(Type.VOID_TYPE, new Type[] { getJvmType() }), false);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/type/record/ProvidedPtrExpr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */