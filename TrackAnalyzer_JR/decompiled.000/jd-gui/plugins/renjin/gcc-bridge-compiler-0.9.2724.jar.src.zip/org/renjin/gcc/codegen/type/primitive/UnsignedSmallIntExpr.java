/*     */ package org.renjin.gcc.codegen.type.primitive;
/*     */ 
/*     */ import org.renjin.gcc.codegen.MethodGenerator;
/*     */ import org.renjin.gcc.codegen.condition.ConditionGenerator;
/*     */ import org.renjin.gcc.codegen.condition.IntegerComparison;
/*     */ import org.renjin.gcc.codegen.expr.Expressions;
/*     */ import org.renjin.gcc.codegen.expr.GExpr;
/*     */ import org.renjin.gcc.codegen.expr.JExpr;
/*     */ import org.renjin.gcc.codegen.expr.JLValue;
/*     */ import org.renjin.gcc.codegen.expr.PtrExpr;
/*     */ import org.renjin.gcc.codegen.type.NumericExpr;
/*     */ import org.renjin.gcc.gimple.GimpleOp;
/*     */ import org.renjin.gcc.gimple.type.GimpleIntegerType;
/*     */ import org.renjin.gcc.gimple.type.GimplePrimitiveType;
/*     */ import org.renjin.gcc.gimple.type.GimpleRealType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UnsignedSmallIntExpr
/*     */   extends AbstractIntExpr
/*     */ {
/*     */   private final int precision;
/*     */   
/*     */   public UnsignedSmallIntExpr(int precision, JExpr expr, PtrExpr address) {
/*  40 */     super(expr, address);
/*  41 */     this.precision = precision;
/*     */   }
/*     */   
/*     */   public UnsignedSmallIntExpr(int precision, JExpr expr) {
/*  45 */     this(precision, expr, null);
/*     */   }
/*     */   
/*     */   private UnsignedSmallIntExpr lift(JExpr expr) {
/*  49 */     return new UnsignedSmallIntExpr(this.precision, expr);
/*     */   }
/*     */   
/*     */   private JExpr truncate(JExpr expr) {
/*  53 */     switch (this.precision) {
/*     */       case 8:
/*  55 */         return Expressions.bitwiseAnd(expr, 255);
/*     */       case 16:
/*  57 */         return Expressions.i2c(expr);
/*     */     } 
/*  59 */     return expr;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public UnsignedSmallIntExpr plus(GExpr operand) {
/*  65 */     return lift(truncate(Expressions.sum(jexpr(), jexpr(operand))));
/*     */   }
/*     */ 
/*     */   
/*     */   public UnsignedSmallIntExpr minus(GExpr operand) {
/*  70 */     return lift(truncate(Expressions.difference(jexpr(), jexpr(operand))));
/*     */   }
/*     */ 
/*     */   
/*     */   public UnsignedSmallIntExpr multiply(GExpr operand) {
/*  75 */     return lift(truncate(Expressions.product(jexpr(), jexpr(operand))));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public NumericExpr divide(GExpr operand) {
/*  81 */     return lift(truncate(Expressions.divide(jexpr(), jexpr(operand))));
/*     */   }
/*     */ 
/*     */   
/*     */   public NumericExpr negative() {
/*  86 */     return lift(truncate(Expressions.negative(jexpr())));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public UnsignedSmallIntExpr min(GExpr operand) {
/*  92 */     return lift(Expressions.staticMethodCall(Math.class, "min", "(II)I", new JExpr[] { jexpr(), jexpr(operand) }));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public UnsignedSmallIntExpr max(GExpr operand) {
/*  98 */     return lift(Expressions.staticMethodCall(Math.class, "max", "(II)I", new JExpr[] { jexpr(), jexpr(operand) }));
/*     */   }
/*     */ 
/*     */   
/*     */   public UnsignedSmallIntExpr absoluteValue() {
/* 103 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public UnsignedSmallIntExpr remainder(GExpr operand) {
/* 108 */     return lift(truncate(Expressions.remainder(jexpr(), jexpr(operand))));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public UnsignedSmallIntExpr bitwiseXor(GExpr operand) {
/* 114 */     return lift(Expressions.bitwiseXor(jexpr(), jexpr(operand)));
/*     */   }
/*     */ 
/*     */   
/*     */   public UnsignedSmallIntExpr bitwiseNot() {
/* 119 */     switch (this.precision) {
/*     */       case 8:
/* 121 */         return lift(Expressions.bitwiseXor(jexpr(), 255));
/*     */       case 16:
/* 123 */         return lift(Expressions.bitwiseXor(jexpr(), 1048575));
/*     */     } 
/* 125 */     throw new IllegalStateException();
/*     */   }
/*     */ 
/*     */   
/*     */   public UnsignedSmallIntExpr bitwiseAnd(GExpr operand) {
/* 130 */     return lift(Expressions.bitwiseAnd(jexpr(), jexpr(operand)));
/*     */   }
/*     */ 
/*     */   
/*     */   public UnsignedSmallIntExpr bitwiseOr(GExpr operand) {
/* 135 */     return lift(Expressions.bitwiseOr(jexpr(), jexpr(operand)));
/*     */   }
/*     */ 
/*     */   
/*     */   public UnsignedSmallIntExpr shiftLeft(GExpr operand) {
/* 140 */     return lift(truncate(Expressions.shiftLeft(jexpr(), operand.toPrimitiveExpr().toSignedInt(32).jexpr())));
/*     */   }
/*     */ 
/*     */   
/*     */   public UnsignedSmallIntExpr shiftRight(GExpr operand) {
/* 145 */     return lift(truncate(Expressions.shiftRight(jexpr(), operand.toPrimitiveExpr().toSignedInt(32).jexpr())));
/*     */   }
/*     */ 
/*     */   
/*     */   public UnsignedSmallIntExpr rotateLeft(GExpr operand) {
/* 150 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public GimplePrimitiveType getType() {
/* 155 */     return (GimplePrimitiveType)GimpleIntegerType.unsigned(this.precision);
/*     */   }
/*     */ 
/*     */   
/*     */   public RealExpr toRealExpr() {
/* 160 */     return toReal(this.precision);
/*     */   }
/*     */ 
/*     */   
/*     */   public BooleanExpr toBooleanExpr() {
/* 165 */     return BooleanExpr.fromInt(jexpr());
/*     */   }
/*     */ 
/*     */   
/*     */   public IntExpr toSignedInt(int precision) {
/* 170 */     if (precision == 64) {
/* 171 */       return new SignedLongExpr(Expressions.i2l(jexpr()));
/*     */     }
/* 173 */     return (new SignedIntExpr(jexpr())).toSignedInt(precision);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IntExpr toUnsignedInt(int precision) {
/* 179 */     if (this.precision == precision) {
/* 180 */       return this;
/*     */     }
/* 182 */     return (new UnsignedIntExpr(jexpr())).toUnsignedInt(precision);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public RealExpr toReal(int precision) {
/* 188 */     switch (precision) {
/*     */       case 32:
/* 190 */         return new RealExpr(new GimpleRealType(32), Expressions.i2f(jexpr()));
/*     */       case 64:
/*     */       case 96:
/* 193 */         return new RealExpr(new GimpleRealType(precision), Expressions.i2d(jexpr()));
/*     */     } 
/* 195 */     throw new UnsupportedOperationException("precision: " + precision);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConditionGenerator compareTo(GimpleOp op, GExpr operand) {
/* 202 */     return (ConditionGenerator)new IntegerComparison(op, jexpr(), jexpr(operand));
/*     */   }
/*     */ 
/*     */   
/*     */   public void store(MethodGenerator mv, GExpr rhs) {
/* 207 */     ((JLValue)jexpr()).store(mv, jexpr(rhs));
/*     */   }
/*     */   
/*     */   private JExpr jexpr(GExpr operand) {
/* 211 */     return operand.toPrimitiveExpr().toUnsignedInt(this.precision).jexpr();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/type/primitive/UnsignedSmallIntExpr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */