/*    */ package org.renjin.gcc;
/*    */ 
/*    */ import io.airlift.command.Cli;
/*    */ import io.airlift.command.Help;
/*    */ import io.airlift.command.ParseException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Main
/*    */ {
/*    */   public static void main(String[] args) {
/* 37 */     Cli.CliBuilder<Runnable> builder = Cli.buildCli("gcc-bridge", Runnable.class).withDescription("C/Fortran compiler targeting the JVM with help from GCC").withDefaultCommand(CompileCommand.class).withCommands(Help.class, new Class[] { CompileCommand.class });
/*    */ 
/*    */     
/* 40 */     Cli<Runnable> gitParser = builder.build();
/*    */     
/*    */     try {
/* 43 */       ((Runnable)gitParser.parse(args)).run();
/* 44 */     } catch (ParseException e) {
/* 45 */       System.err.println(e.getMessage());
/* 46 */       System.exit(-1);
/* 47 */     } catch (GccException e) {
/* 48 */       System.err.println(e.getMessage());
/* 49 */       System.exit(-1);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/Main.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */