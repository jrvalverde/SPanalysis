/*     */ package org.renjin.gcc.codegen;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.renjin.gcc.gimple.type.GimplePointerType;
/*     */ import org.renjin.gcc.gimple.type.GimplePrimitiveType;
/*     */ import org.renjin.gcc.gimple.type.GimpleType;
/*     */ import org.renjin.gcc.runtime.BooleanPtr;
/*     */ import org.renjin.gcc.runtime.BytePtr;
/*     */ import org.renjin.gcc.runtime.CharPtr;
/*     */ import org.renjin.gcc.runtime.DoublePtr;
/*     */ import org.renjin.gcc.runtime.FloatPtr;
/*     */ import org.renjin.gcc.runtime.IntPtr;
/*     */ import org.renjin.gcc.runtime.LongPtr;
/*     */ import org.renjin.gcc.runtime.ObjectPtr;
/*     */ import org.renjin.gcc.runtime.Ptr;
/*     */ import org.renjin.gcc.runtime.ShortPtr;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ import org.renjin.repackaged.guava.collect.ImmutableList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WrapperType
/*     */ {
/*  33 */   public static final WrapperType OBJECT_PTR = new WrapperType((Class)ObjectPtr.class);
/*     */   
/*  35 */   private static final List<WrapperType> TYPES = (List<WrapperType>)ImmutableList.of(new WrapperType((Class)BytePtr.class), new WrapperType((Class)IntPtr.class), new WrapperType((Class)ShortPtr.class), new WrapperType((Class)LongPtr.class), new WrapperType((Class)BooleanPtr.class), new WrapperType((Class)CharPtr.class), new WrapperType((Class)DoublePtr.class), new WrapperType((Class)FloatPtr.class), new WrapperType((Class)ObjectPtr.class));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Type wrapperType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Type arrayType;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Type baseType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WrapperType(Class<? extends Ptr> wrapperClass) {
/*     */     try {
/*  60 */       Class<?> arrayClass = wrapperClass.getField("array").getType();
/*     */       
/*  62 */       this.wrapperType = Type.getType(wrapperClass);
/*  63 */       this.arrayType = Type.getType(arrayClass);
/*  64 */       this.baseType = Type.getType(arrayClass.getComponentType());
/*     */     }
/*  66 */     catch (Exception e) {
/*  67 */       throw new IllegalArgumentException(wrapperClass.getName());
/*     */     } 
/*     */   }
/*     */   
/*     */   public Type getWrapperType() {
/*  72 */     return this.wrapperType;
/*     */   }
/*     */   
/*     */   public Type getArrayType() {
/*  76 */     return this.arrayType;
/*     */   }
/*     */   
/*     */   public Type getBaseType() {
/*  80 */     return this.baseType;
/*     */   }
/*     */ 
/*     */   
/*     */   public GimpleType getGimpleType() {
/*  85 */     return (GimpleType)new GimplePointerType((GimpleType)GimplePrimitiveType.fromJvmType(this.baseType));
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean is(Type type) {
/*  90 */     for (WrapperType wrapperType : TYPES) {
/*  91 */       if (wrapperType.getWrapperType().equals(type)) {
/*  92 */         return true;
/*     */       }
/*     */     } 
/*  95 */     return false;
/*     */   }
/*     */   
/*     */   public static boolean is(Class<?> aClass) {
/*  99 */     return is(Type.getType(aClass));
/*     */   }
/*     */   
/*     */   public static WrapperType valueOf(Type type) {
/* 103 */     for (WrapperType wrapperType : TYPES) {
/* 104 */       if (wrapperType.getWrapperType().equals(type)) {
/* 105 */         return wrapperType;
/*     */       }
/*     */     } 
/* 108 */     throw new IllegalArgumentException(type.toString());
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 113 */     return this.wrapperType.getInternalName();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 118 */     if (this == o) {
/* 119 */       return true;
/*     */     }
/* 121 */     if (o == null || getClass() != o.getClass()) {
/* 122 */       return false;
/*     */     }
/*     */     
/* 125 */     WrapperType that = (WrapperType)o;
/*     */     
/* 127 */     return this.wrapperType.equals(that.wrapperType);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 132 */     return this.wrapperType.hashCode();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/WrapperType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */