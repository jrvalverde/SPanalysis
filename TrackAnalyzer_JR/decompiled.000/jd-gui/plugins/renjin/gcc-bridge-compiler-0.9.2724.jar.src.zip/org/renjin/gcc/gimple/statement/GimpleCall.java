/*     */ package org.renjin.gcc.gimple.statement;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import java.util.List;
/*     */ import java.util.function.Predicate;
/*     */ import org.renjin.gcc.gimple.GimpleExprVisitor;
/*     */ import org.renjin.gcc.gimple.GimpleVisitor;
/*     */ import org.renjin.gcc.gimple.expr.GimpleAddressOf;
/*     */ import org.renjin.gcc.gimple.expr.GimpleExpr;
/*     */ import org.renjin.gcc.gimple.expr.GimpleFunctionRef;
/*     */ import org.renjin.gcc.gimple.expr.GimpleLValue;
/*     */ import org.renjin.repackaged.guava.base.Joiner;
/*     */ import org.renjin.repackaged.guava.collect.Lists;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GimpleCall
/*     */   extends GimpleStatement
/*     */ {
/*     */   private GimpleExpr function;
/*  34 */   private List<GimpleExpr> operands = Lists.newArrayList();
/*     */   private GimpleLValue lhs;
/*     */   
/*     */   public GimpleExpr getFunction() {
/*  38 */     return this.function;
/*     */   }
/*     */   
/*     */   @JsonProperty("arguments")
/*     */   public List<GimpleExpr> getOperands() {
/*  43 */     return this.operands;
/*     */   }
/*     */ 
/*     */   
/*     */   public GimpleExpr getOperand(int i) {
/*  48 */     return this.operands.get(i);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setOperand(int i, GimpleExpr op) {
/*  53 */     this.operands.set(i, op);
/*     */   }
/*     */   
/*     */   public GimpleLValue getLhs() {
/*  57 */     return this.lhs;
/*     */   }
/*     */   
/*     */   public void setFunction(GimpleExpr function) {
/*  61 */     this.function = function;
/*     */   }
/*     */   
/*     */   public void setLhs(GimpleLValue lhs) {
/*  65 */     this.lhs = lhs;
/*     */   }
/*     */   
/*     */   public boolean isFunctionNamed(String name) {
/*  69 */     return name.equals(getFunctionName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFunctionName() {
/*  76 */     if (this.function instanceof GimpleAddressOf) {
/*  77 */       GimpleExpr value = ((GimpleAddressOf)this.function).getValue();
/*  78 */       if (value instanceof GimpleFunctionRef) {
/*  79 */         GimpleFunctionRef ref = (GimpleFunctionRef)value;
/*  80 */         return ref.getName();
/*     */       } 
/*     */     } 
/*  83 */     return "";
/*     */   }
/*     */ 
/*     */   
/*     */   protected void findUses(Predicate<? super GimpleExpr> predicate, List<GimpleExpr> results) {
/*  88 */     this.function.findOrDescend(predicate, results);
/*  89 */     for (GimpleExpr argument : this.operands) {
/*  90 */       argument.findOrDescend(predicate, results);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  99 */     if (this.lhs != null && !(this.lhs instanceof org.renjin.gcc.gimple.expr.GimpleSymbolRef)) {
/* 100 */       this.lhs.find(predicate, results);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 106 */     StringBuilder sb = new StringBuilder();
/* 107 */     sb.append(this.lhs);
/* 108 */     sb.append(" = ");
/* 109 */     sb.append(this.function).append("(");
/* 110 */     Joiner.on(", ").appendTo(sb, this.operands);
/* 111 */     sb.append(")");
/* 112 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public void visit(GimpleVisitor visitor) {
/* 117 */     visitor.visitCall(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean lhsMatches(Predicate<? super GimpleLValue> predicate) {
/* 122 */     if (this.lhs != null) {
/* 123 */       return predicate.test(this.lhs);
/*     */     }
/* 125 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void replaceAll(Predicate<? super GimpleExpr> predicate, GimpleExpr newExpr) {
/* 131 */     if (this.lhs != null) {
/* 132 */       if (predicate.test(this.lhs)) {
/* 133 */         this.lhs = (GimpleLValue)newExpr;
/*     */       } else {
/* 135 */         this.lhs.replaceAll(predicate, newExpr);
/*     */       } 
/*     */     }
/* 138 */     if (predicate.test(this.function)) {
/* 139 */       this.function = newExpr;
/*     */     } else {
/* 141 */       this.function.replaceAll(predicate, newExpr);
/*     */     } 
/* 143 */     replaceAll(predicate, this.operands, newExpr);
/*     */   }
/*     */ 
/*     */   
/*     */   public void accept(GimpleExprVisitor visitor) {
/* 148 */     if (this.lhs != null) {
/* 149 */       this.lhs.accept(visitor);
/*     */     }
/* 151 */     this.function.accept(visitor);
/* 152 */     for (GimpleExpr operand : this.operands)
/* 153 */       operand.accept(visitor); 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/gimple/statement/GimpleCall.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */