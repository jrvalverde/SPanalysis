/*     */ package org.renjin.gcc.analysis;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.renjin.gcc.gimple.GimpleBasicBlock;
/*     */ import org.renjin.gcc.gimple.GimpleCompilationUnit;
/*     */ import org.renjin.gcc.gimple.GimpleFunction;
/*     */ import org.renjin.gcc.gimple.GimpleOp;
/*     */ import org.renjin.gcc.gimple.expr.GimpleAddressOf;
/*     */ import org.renjin.gcc.gimple.expr.GimpleExpr;
/*     */ import org.renjin.gcc.gimple.expr.GimpleMemRef;
/*     */ import org.renjin.gcc.gimple.expr.GimplePointerPlus;
/*     */ import org.renjin.gcc.gimple.statement.GimpleAssignment;
/*     */ import org.renjin.gcc.gimple.statement.GimpleCall;
/*     */ import org.renjin.gcc.gimple.statement.GimpleStatement;
/*     */ import org.renjin.gcc.gimple.type.GimpleArrayType;
/*     */ import org.renjin.gcc.gimple.type.GimpleIndirectType;
/*     */ import org.renjin.gcc.gimple.type.GimpleIntegerType;
/*     */ import org.renjin.gcc.gimple.type.GimpleType;
/*     */ import org.renjin.gcc.logging.LogManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AddressableSimplifier
/*     */   implements FunctionBodyTransformer
/*     */ {
/*  45 */   public static final AddressableSimplifier INSTANCE = new AddressableSimplifier();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean transform(LogManager logManager, GimpleCompilationUnit unit, GimpleFunction fn) {
/*  53 */     boolean updated = false;
/*     */     
/*  55 */     for (GimpleBasicBlock basicBlock : fn.getBasicBlocks()) {
/*  56 */       for (GimpleStatement statement : basicBlock.getStatements()) {
/*  57 */         if (statement instanceof GimpleAssignment) {
/*  58 */           if (fixAssignment((GimpleAssignment)statement))
/*  59 */             updated = true;  continue;
/*     */         } 
/*  61 */         if (statement instanceof GimpleCall && 
/*  62 */           fixCallArguments((GimpleCall)statement)) {
/*  63 */           updated = true;
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/*  68 */     return updated;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean fixAssignment(GimpleAssignment assignment) {
/*  73 */     boolean updated = false;
/*     */ 
/*     */ 
/*     */     
/*  77 */     if (assignment.getOperator() == GimpleOp.ADDR_EXPR) {
/*  78 */       GimpleAddressOf addressOf = assignment.getOperands().get(0);
/*  79 */       if (addressOf.getValue() instanceof GimpleMemRef) {
/*  80 */         GimpleMemRef memRef = (GimpleMemRef)addressOf.getValue();
/*     */         
/*  82 */         if (memRef.isOffsetZero()) {
/*     */           
/*  84 */           assignment.setOperator(GimpleOp.NOP_EXPR);
/*  85 */           assignment.getOperands().set(0, memRef.getPointer());
/*     */         } else {
/*     */           
/*  88 */           GimpleExpr offset = memRef.getOffset();
/*  89 */           offset.setType(memRef.getPointer().getType());
/*     */           
/*  91 */           assignment.setOperator(GimpleOp.POINTER_PLUS_EXPR);
/*  92 */           assignment.getOperands().set(0, memRef.getPointer());
/*  93 */           assignment.getOperands().add(offset);
/*     */         } 
/*  95 */         updated = true;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 101 */     if (assignment.getLHS() instanceof GimpleMemRef && assignment
/* 102 */       .getOperator() == GimpleOp.MEM_REF) {
/*     */       
/* 104 */       GimpleMemRef lhs = (GimpleMemRef)assignment.getLHS();
/* 105 */       GimpleMemRef rhs = assignment.getOperands().get(0);
/*     */       
/* 107 */       if (isByteArray(lhs.getType()) && 
/* 108 */         isByteArray(rhs.getType()))
/*     */       {
/* 110 */         if (lhs.isOffsetZero() && rhs.isOffsetZero()) {
/* 111 */           GimpleIndirectType lhsType = (GimpleIndirectType)lhs.getPointer().getType();
/* 112 */           GimpleIndirectType rhsType = (GimpleIndirectType)rhs.getPointer().getType();
/*     */           
/* 114 */           lhs.setType(lhsType.getBaseType());
/* 115 */           rhs.setType(rhsType.getBaseType());
/*     */         } 
/*     */       }
/*     */     } 
/* 119 */     return updated;
/*     */   }
/*     */   
/*     */   private boolean fixCallArguments(GimpleCall statement) {
/* 123 */     boolean updated = false;
/* 124 */     List<GimpleExpr> operands = statement.getOperands();
/* 125 */     for (int i = 0; i < operands.size(); i++) {
/* 126 */       GimpleExpr op = operands.get(i);
/* 127 */       if (op instanceof GimpleAddressOf) {
/* 128 */         GimpleAddressOf addressOf = (GimpleAddressOf)op;
/* 129 */         if (addressOf.getValue() instanceof GimpleMemRef) {
/* 130 */           GimpleMemRef memRef = (GimpleMemRef)addressOf.getValue();
/* 131 */           if (memRef.isOffsetZero()) {
/* 132 */             statement.setOperand(i, memRef.getPointer());
/*     */           } else {
/* 134 */             statement.setOperand(i, (GimpleExpr)new GimplePointerPlus(memRef.getPointer(), memRef.getOffset()));
/*     */           } 
/* 136 */           updated = true;
/*     */         } 
/*     */       } 
/*     */     } 
/* 140 */     return updated;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isByteArray(GimpleType type) {
/* 145 */     if (type instanceof GimpleArrayType) {
/* 146 */       GimpleArrayType arrayType = (GimpleArrayType)type;
/* 147 */       if (arrayType.getComponentType() instanceof GimpleIntegerType) {
/* 148 */         GimpleIntegerType integerType = (GimpleIntegerType)arrayType.getComponentType();
/* 149 */         if (integerType.getPrecision() == 8) {
/* 150 */           return true;
/*     */         }
/*     */       } 
/*     */     } 
/* 154 */     return false;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/analysis/AddressableSimplifier.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */