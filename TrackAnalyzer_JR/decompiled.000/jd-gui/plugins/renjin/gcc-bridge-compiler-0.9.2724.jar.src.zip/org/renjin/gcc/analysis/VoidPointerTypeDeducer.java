/*     */ package org.renjin.gcc.analysis;
/*     */ 
/*     */ import java.util.Set;
/*     */ import org.renjin.gcc.GimpleCompiler;
/*     */ import org.renjin.gcc.gimple.GimpleBasicBlock;
/*     */ import org.renjin.gcc.gimple.GimpleCompilationUnit;
/*     */ import org.renjin.gcc.gimple.GimpleExprVisitor;
/*     */ import org.renjin.gcc.gimple.GimpleFunction;
/*     */ import org.renjin.gcc.gimple.GimpleOp;
/*     */ import org.renjin.gcc.gimple.GimpleVarDecl;
/*     */ import org.renjin.gcc.gimple.GimpleVisitor;
/*     */ import org.renjin.gcc.gimple.expr.GimpleAddressOf;
/*     */ import org.renjin.gcc.gimple.expr.GimpleConstant;
/*     */ import org.renjin.gcc.gimple.expr.GimpleExpr;
/*     */ import org.renjin.gcc.gimple.expr.GimpleFunctionRef;
/*     */ import org.renjin.gcc.gimple.expr.GimpleMemRef;
/*     */ import org.renjin.gcc.gimple.expr.GimpleVariableRef;
/*     */ import org.renjin.gcc.gimple.statement.GimpleAssignment;
/*     */ import org.renjin.gcc.gimple.statement.GimpleCall;
/*     */ import org.renjin.gcc.gimple.statement.GimpleConditional;
/*     */ import org.renjin.gcc.gimple.statement.GimpleStatement;
/*     */ import org.renjin.gcc.gimple.type.GimplePointerType;
/*     */ import org.renjin.gcc.gimple.type.GimpleType;
/*     */ import org.renjin.gcc.gimple.type.GimpleVoidType;
/*     */ import org.renjin.gcc.logging.LogManager;
/*     */ import org.renjin.gcc.logging.Logger;
/*     */ import org.renjin.repackaged.guava.collect.Sets;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VoidPointerTypeDeducer
/*     */   implements FunctionBodyTransformer
/*     */ {
/*  44 */   public static final VoidPointerTypeDeducer INSTANCE = new VoidPointerTypeDeducer();
/*     */   
/*  46 */   public static final GimplePointerType UNKNOWN_TYPE = (new GimpleVoidType()).pointerTo();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean transform(LogManager logManager, GimpleCompilationUnit unit, GimpleFunction fn) {
/*  54 */     boolean updated = false;
/*     */     
/*  56 */     Logger logger = logManager.getLogger(fn, "void-deducer");
/*     */     
/*  58 */     for (GimpleVarDecl decl : fn.getVariableDeclarations()) {
/*  59 */       if (isVoidPtr(decl.getType()) && 
/*  60 */         tryToDeduceType(logger, fn, decl)) {
/*  61 */         updated = true;
/*     */       }
/*     */     } 
/*     */     
/*  65 */     return updated;
/*     */   }
/*     */   
/*     */   private boolean isVoidPtr(GimpleType type) {
/*  69 */     return (type instanceof GimplePointerType && type
/*  70 */       .getBaseType() instanceof GimpleVoidType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean tryToDeduceType(Logger logger, GimpleFunction fn, GimpleVarDecl decl) {
/*  78 */     Set<GimpleType> possibleTypes = Sets.newHashSet();
/*  79 */     fn.accept(new AssignmentFinder(decl, possibleTypes));
/*  80 */     fn.accept(new MemRefVisitor(decl, possibleTypes));
/*     */     
/*  82 */     logger.log("Possible type set of " + decl + " = " + possibleTypes);
/*     */     
/*  84 */     if (possibleTypes.size() == 1 && !possibleTypes.contains(UNKNOWN_TYPE)) {
/*  85 */       GimpleType deducedType = possibleTypes.iterator().next();
/*  86 */       if (GimpleCompiler.TRACE) {
/*  87 */         logger.log("...resolved to " + deducedType);
/*     */       }
/*  89 */       decl.setType(deducedType);
/*  90 */       fn.accept(new VarRefTypeUpdater(decl));
/*  91 */       updatePointerComparisons(fn, decl);
/*  92 */       return true;
/*     */     } 
/*  94 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void updatePointerComparisons(GimpleFunction fn, GimpleVarDecl decl) {
/* 104 */     GimpleVariableRef ref = decl.newRef();
/*     */     
/* 106 */     for (GimpleBasicBlock basicBlock : fn.getBasicBlocks()) {
/* 107 */       for (GimpleStatement statement : basicBlock.getStatements()) {
/* 108 */         if (statement instanceof GimpleConditional) {
/* 109 */           GimpleConditional conditional = (GimpleConditional)statement;
/* 110 */           if (conditional.getOperator() == GimpleOp.NE_EXPR || conditional
/* 111 */             .getOperator() == GimpleOp.EQ_EXPR) {
/*     */             
/* 113 */             if (conditional.getOperand(0).equals(ref) && isNull(conditional.getOperand(1))) {
/* 114 */               conditional.getOperand(1).setType(decl.getType()); continue;
/*     */             } 
/* 116 */             if (conditional.getOperand(1).equals(ref) && isNull(conditional.getOperand(0))) {
/* 117 */               conditional.getOperand(0).setType(decl.getType());
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean isNull(GimpleExpr operand) {
/* 126 */     return (operand instanceof GimpleConstant && ((GimpleConstant)operand)
/* 127 */       .isNull());
/*     */   }
/*     */ 
/*     */   
/*     */   private class AssignmentFinder
/*     */     extends GimpleVisitor
/*     */   {
/*     */     private final GimpleVarDecl decl;
/*     */     
/*     */     private final Set<GimpleType> possibleTypes;
/*     */     
/*     */     public AssignmentFinder(GimpleVarDecl decl, Set<GimpleType> possibleTypes) {
/* 139 */       this.decl = decl;
/* 140 */       this.possibleTypes = possibleTypes;
/*     */     }
/*     */     
/*     */     public void visitAssignment(GimpleAssignment assignment) {
/*     */       GimpleExpr rhs;
/*     */       GimpleExpr pointer;
/* 146 */       switch (assignment.getOperator()) {
/*     */         
/*     */         case VAR_DECL:
/*     */         case PARM_DECL:
/*     */         case NOP_EXPR:
/*     */         case ADDR_EXPR:
/* 152 */           rhs = assignment.getOperands().get(0);
/* 153 */           if (isReference(rhs)) {
/* 154 */             inferPossibleTypes((GimpleExpr)assignment.getLHS()); break;
/*     */           } 
/* 156 */           if (isReference((GimpleExpr)assignment.getLHS())) {
/* 157 */             inferPossibleTypes(rhs);
/*     */           }
/*     */           break;
/*     */         
/*     */         case POINTER_PLUS_EXPR:
/* 162 */           pointer = assignment.getOperands().get(0);
/* 163 */           if (isReference(pointer)) {
/* 164 */             inferPossibleTypes((GimpleExpr)assignment.getLHS());
/*     */           }
/*     */           break;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void visitCall(GimpleCall gimpleCall) {
/* 173 */       String functionName = findFunctionName(gimpleCall);
/*     */       
/* 175 */       if (!isMalloc(functionName) && isReference((GimpleExpr)gimpleCall.getLhs())) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 182 */         this.possibleTypes.add(VoidPointerTypeDeducer.UNKNOWN_TYPE);
/*     */       } else {
/*     */         
/* 185 */         switch (functionName) {
/*     */           case "memcpy":
/*     */           case "__builtin_memcpy":
/* 188 */             inferFromMemCopy(gimpleCall);
/*     */             break;
/*     */           
/*     */           case "memcmp":
/*     */           case "__builtin_memcmp":
/* 193 */             inferFromMemCmp(gimpleCall);
/*     */             break;
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*     */     private boolean isMalloc(String functionName) {
/* 200 */       switch (functionName) {
/*     */         case "malloc":
/*     */         case "calloc":
/*     */         case "alloca":
/*     */         case "realloc":
/*     */         case "__builtin_malloc__":
/*     */         case "_Znwj":
/*     */         case "_Znaj":
/* 208 */           return true;
/*     */       } 
/* 210 */       return false;
/*     */     }
/*     */     
/*     */     private String findFunctionName(GimpleCall call) {
/* 214 */       if (call.getFunction() instanceof GimpleAddressOf) {
/* 215 */         GimpleAddressOf functionAddress = (GimpleAddressOf)call.getFunction();
/* 216 */         if (functionAddress.getValue() instanceof GimpleFunctionRef) {
/* 217 */           GimpleFunctionRef function = (GimpleFunctionRef)functionAddress.getValue();
/* 218 */           return function.getName();
/*     */         } 
/*     */       } 
/* 221 */       return "";
/*     */     }
/*     */     
/*     */     private void inferFromMemCmp(GimpleCall gimpleCall) {
/* 225 */       GimpleExpr x = gimpleCall.getOperand(0);
/* 226 */       GimpleExpr y = gimpleCall.getOperand(1);
/*     */       
/* 228 */       if (isReference(x)) {
/* 229 */         inferPossibleTypes(y);
/* 230 */       } else if (isReference(y)) {
/* 231 */         inferPossibleTypes(x);
/*     */       } 
/*     */     }
/*     */     
/*     */     private void inferFromMemCopy(GimpleCall gimpleCall) {
/* 236 */       GimpleExpr destination = gimpleCall.getOperand(0);
/* 237 */       GimpleExpr source = gimpleCall.getOperand(1);
/*     */       
/* 239 */       if (isReference(destination)) {
/* 240 */         inferPossibleTypes(source);
/* 241 */       } else if (isReference(source)) {
/* 242 */         inferPossibleTypes(destination);
/*     */       } 
/*     */       
/* 245 */       if ((isReference(destination) || isReference(source)) && 
/* 246 */         gimpleCall.getLhs() != null) {
/* 247 */         inferPossibleTypes((GimpleExpr)gimpleCall.getLhs());
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     private void inferPossibleTypes(GimpleExpr expr) {
/* 253 */       if (expr.getType() != null && !VoidPointerTypeDeducer.this.isVoidPtr(expr.getType())) {
/* 254 */         this.possibleTypes.add(expr.getType());
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean isReference(GimpleExpr expr) {
/* 262 */       return (expr instanceof GimpleVariableRef && ((GimpleVariableRef)expr)
/* 263 */         .getId() == this.decl.getId());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private class MemRefVisitor
/*     */     extends GimpleExprVisitor
/*     */   {
/*     */     private GimpleVarDecl decl;
/*     */     
/*     */     private final Set<GimpleType> possibleTypes;
/*     */ 
/*     */     
/*     */     public MemRefVisitor(GimpleVarDecl decl, Set<GimpleType> possibleTypes) {
/* 277 */       this.decl = decl;
/* 278 */       this.possibleTypes = possibleTypes;
/*     */     }
/*     */ 
/*     */     
/*     */     public void visitMemRef(GimpleMemRef memRef) {
/* 283 */       if (memRef.getPointer() instanceof GimpleVariableRef) {
/* 284 */         GimpleVariableRef ref = (GimpleVariableRef)memRef.getPointer();
/* 285 */         if (ref.getId() == this.decl.getId()) {
/*     */           
/* 287 */           GimpleType valueType = memRef.getType();
/* 288 */           this.possibleTypes.add(new GimplePointerType(valueType));
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private class VarRefTypeUpdater
/*     */     extends GimpleExprVisitor
/*     */   {
/*     */     private GimpleVarDecl decl;
/*     */ 
/*     */     
/*     */     public VarRefTypeUpdater(GimpleVarDecl decl) {
/* 302 */       this.decl = decl;
/*     */     }
/*     */ 
/*     */     
/*     */     public void visitVariableRef(GimpleVariableRef variableRef) {
/* 307 */       if (variableRef.getId() == this.decl.getId())
/* 308 */         variableRef.setType(this.decl.getType()); 
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/analysis/VoidPointerTypeDeducer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */