/*     */ package org.renjin.gcc;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.logging.Logger;
/*     */ import org.renjin.gcc.gimple.GimpleCompilationUnit;
/*     */ import org.renjin.gcc.gimple.GimpleParser;
/*     */ import org.renjin.repackaged.guava.base.Joiner;
/*     */ import org.renjin.repackaged.guava.base.Preconditions;
/*     */ import org.renjin.repackaged.guava.base.Strings;
/*     */ import org.renjin.repackaged.guava.collect.Lists;
/*     */ import org.renjin.repackaged.guava.io.ByteStreams;
/*     */ import org.renjin.repackaged.guava.io.Files;
/*     */ import org.renjin.repackaged.guava.io.Resources;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Gcc
/*     */ {
/*     */   private File workingDirectory;
/*     */   private File pluginLibrary;
/*     */   private boolean trace = false;
/*  49 */   private List<File> includeDirectories = Lists.newArrayList();
/*     */   
/*  51 */   private static final Logger LOGGER = Logger.getLogger(Gcc.class.getName());
/*     */   
/*     */   private boolean debug;
/*     */   
/*     */   private File gimpleOutputDir;
/*     */   
/*     */   private boolean link = false;
/*  58 */   private List<String> cFlags = Lists.newArrayList();
/*     */   
/*  60 */   private List<String> cxxFlags = Lists.newArrayList();
/*     */   
/*     */   public Gcc() {
/*  63 */     this.workingDirectory = Files.createTempDir();
/*  64 */     this.gimpleOutputDir = this.workingDirectory;
/*     */   }
/*     */   
/*     */   public Gcc(File workingDirectory) {
/*  68 */     this.workingDirectory = workingDirectory;
/*  69 */     this.gimpleOutputDir = workingDirectory;
/*     */   }
/*     */   
/*     */   public void setPluginLibrary(File pluginLibrary) {
/*  73 */     this.pluginLibrary = pluginLibrary;
/*     */   }
/*     */   
/*     */   public void setDebug(boolean debug) {
/*  77 */     this.debug = debug;
/*     */   }
/*     */   
/*     */   public void setTrace(boolean trace) {
/*  81 */     this.trace = trace;
/*     */   }
/*     */   
/*     */   public void setGimpleOutputDir(File gimpleOutputDir) {
/*  85 */     this.gimpleOutputDir = gimpleOutputDir;
/*  86 */     this.gimpleOutputDir.mkdirs();
/*     */   }
/*     */   
/*     */   public void addCFlags(List<String> flags) {
/*  90 */     this.cFlags.addAll(flags);
/*     */   }
/*     */   
/*     */   public void addCxxFlags(List<String> flags) {
/*  94 */     this.cxxFlags.addAll(flags);
/*     */   }
/*     */   
/*     */   public File getGimpleOutputDir() {
/*  98 */     return this.gimpleOutputDir;
/*     */   }
/*     */ 
/*     */   
/*     */   public GimpleCompilationUnit compileToGimple(File source, String... compilerFlags) throws IOException {
/* 103 */     checkEnvironment();
/*     */     
/* 105 */     List<String> arguments = Lists.newArrayList();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 110 */     arguments.add("-m32");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 116 */     arguments.add("-D");
/* 117 */     arguments.add("_GCC_BRIDGE");
/* 118 */     arguments.add("-D");
/* 119 */     arguments.add("_RENJIN");
/*     */     
/* 121 */     if (!this.link) {
/* 122 */       arguments.add("-c");
/* 123 */       arguments.add("-S");
/*     */     } 
/* 125 */     arguments.addAll(Arrays.asList(compilerFlags));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 130 */     arguments.add("-fplugin=" + this.pluginLibrary.getAbsolutePath());
/*     */     
/* 132 */     File gimpleFile = new File(this.gimpleOutputDir, source.getName() + ".gimple");
/* 133 */     arguments.add("-fplugin-arg-bridge-json-output-file=" + gimpleFile
/* 134 */         .getAbsolutePath());
/*     */     
/* 136 */     for (File includeDir : this.includeDirectories) {
/* 137 */       arguments.add("-I");
/* 138 */       arguments.add(includeDir.getAbsolutePath());
/*     */     } 
/*     */     
/* 141 */     if (source.getName().toLowerCase().endsWith(".c")) {
/* 142 */       arguments.addAll(this.cFlags);
/*     */     }
/*     */     
/* 145 */     if (source.getName().toLowerCase().endsWith(".cc") || source
/* 146 */       .getName().toLowerCase().endsWith(".cpp")) {
/* 147 */       arguments.addAll(this.cxxFlags);
/*     */     }
/*     */     
/* 150 */     arguments.add(source.getAbsolutePath());
/*     */     
/* 152 */     LOGGER.info("Executing " + Joiner.on(" ").join(arguments));
/*     */     
/* 154 */     callGcc(arguments);
/*     */     
/* 156 */     GimpleParser parser = new GimpleParser();
/* 157 */     GimpleCompilationUnit unit = parser.parse(gimpleFile);
/* 158 */     unit.setSourceFile(gimpleFile);
/* 159 */     return unit;
/*     */   }
/*     */   
/*     */   public boolean isLink() {
/* 163 */     return this.link;
/*     */   }
/*     */   
/*     */   public void setLink(boolean link) {
/* 167 */     this.link = link;
/*     */   }
/*     */   
/*     */   private String callGcc(String... arguments) throws IOException {
/* 171 */     return callGcc(Arrays.asList(arguments));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String callGcc(List<String> arguments) throws IOException {
/* 182 */     List<String> command = Lists.newArrayList();
/* 183 */     command.add("gcc-4.7");
/* 184 */     command.addAll(arguments);
/*     */     
/* 186 */     System.err.println("EXECUTING: " + Joiner.on(" ").join(arguments));
/*     */     
/* 188 */     Process gcc = (new ProcessBuilder(new String[0])).command(command).directory(this.workingDirectory).redirectErrorStream(true).start();
/*     */     
/* 190 */     OutputCollector outputCollector = new OutputCollector(gcc);
/* 191 */     Thread collectorThread = new Thread(outputCollector);
/* 192 */     collectorThread.start();
/*     */     
/*     */     try {
/* 195 */       gcc.waitFor();
/* 196 */       collectorThread.join();
/* 197 */     } catch (InterruptedException e) {
/* 198 */       throw new GccException("Compiler interrupted");
/*     */     } 
/*     */     
/* 201 */     if (gcc.exitValue() != 0) {
/*     */       
/* 203 */       if (outputCollector.getOutput().contains("error trying to exec 'f951': execvp: No such file or directory")) {
/* 204 */         throw new GccException("Compilation failed: Fortran compiler is missing:\n" + outputCollector.getOutput());
/*     */       }
/*     */       
/* 207 */       throw new GccException("Compilation failed:\n" + outputCollector.getOutput());
/*     */     } 
/* 209 */     return outputCollector.getOutput();
/*     */   }
/*     */   
/*     */   private void checkEnvironment() {
/* 213 */     if (PlatformUtils.OS == PlatformUtils.OSType.WINDOWS) {
/* 214 */       throw new GccException("Sorry, gcc-bridge does not work on Windows/Cygwin because of problems building \nand linking the required gcc plugin. You can still compile on a *NIX platform and use the resulting pure-Java class files on any platform.");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void addIncludeDirectory(File path) {
/* 221 */     this.includeDirectories.add(path);
/*     */   }
/*     */ 
/*     */   
/*     */   public void extractPlugin() throws IOException {
/* 226 */     if (!Strings.isNullOrEmpty(System.getProperty("gcc.bridge.plugin"))) {
/* 227 */       this.pluginLibrary = new File(System.getProperty("gcc.bridge.plugin"));
/* 228 */       if (this.pluginLibrary.exists()) {
/* 229 */         System.err.println("Using bridge.so at " + this.pluginLibrary.getAbsolutePath());
/*     */         return;
/*     */       } 
/* 232 */       System.err.println("bridge.so does not exist at " + this.pluginLibrary.getAbsolutePath());
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 237 */     this.pluginLibrary = new File(this.workingDirectory, "bridge.so");
/*     */     
/* 239 */     compilePlugin(this.pluginLibrary, this.trace);
/*     */     
/* 241 */     this.pluginLibrary.deleteOnExit();
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public static synchronized void extractPluginTo(File pluginLibrary) throws IOException {
/* 246 */     compilePlugin(pluginLibrary, false);
/*     */   }
/*     */   
/*     */   public static synchronized void compilePlugin(File pluginLibrary) throws IOException {
/* 250 */     compilePlugin(pluginLibrary, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public static synchronized void compilePlugin(File pluginLibrary, boolean trace) throws IOException {
/* 255 */     Preconditions.checkArgument(pluginLibrary.getName().endsWith(".so"), "plugin name must end in .so");
/*     */     
/* 257 */     if (pluginLibrary.exists()) {
/*     */       return;
/*     */     }
/*     */     
/* 261 */     if (!pluginLibrary.getParentFile().exists()) {
/* 262 */       boolean created = pluginLibrary.getParentFile().mkdirs();
/* 263 */       if (!created) {
/* 264 */         throw new IOException("Could not create directory " + pluginLibrary.getParentFile());
/*     */       }
/*     */     } 
/*     */     
/* 268 */     File workingDir = Files.createTempDir();
/* 269 */     Gcc gcc = new Gcc(workingDir);
/*     */ 
/*     */     
/* 272 */     File sourceFile = new File(workingDir, "plugin.c");
/* 273 */     Resources.asByteSource(Resources.getResource(Gcc.class, "plugin.c")).copyTo(Files.asByteSink(sourceFile, new org.renjin.repackaged.guava.io.FileWriteMode[0]));
/*     */ 
/*     */     
/* 276 */     String pluginDir = gcc.callGcc(new String[] { "-print-file-name=plugin" }).trim();
/*     */ 
/*     */     
/* 279 */     List<String> args = new ArrayList<>();
/* 280 */     args.add("-shared");
/* 281 */     args.add("-xc++");
/* 282 */     args.add("-I" + pluginDir + "/include");
/* 283 */     if (trace) {
/* 284 */       args.add("-DTRACE_GCC_BRIDGE");
/*     */     }
/* 286 */     args.add("-fPIC");
/* 287 */     args.add("-fno-rtti");
/* 288 */     args.add("-O2");
/* 289 */     args.add("plugin.c");
/* 290 */     args.add("-lstdc++");
/* 291 */     args.add("-shared-libgcc");
/* 292 */     args.addAll(Arrays.asList(new String[] { "-o", pluginLibrary.getAbsolutePath() }));
/*     */ 
/*     */     
/* 295 */     gcc.callGcc(args);
/*     */   }
/*     */ 
/*     */   
/*     */   public void checkVersion() {
/*     */     try {
/* 301 */       String versionOutput = callGcc(Arrays.asList(new String[] { "--version" }));
/* 302 */       if (!versionOutput.contains("4.7.4")) {
/* 303 */         System.err.println("WARNING: gcc-bridge has been tested against 4.7.4, other versions may not work correctly.");
/*     */       }
/* 305 */     } catch (IOException e) {
/* 306 */       throw new GccException("Failed to start GCC: " + e.getMessage() + ".\nMake sure gcc 4.7.4 is installed.");
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static class OutputCollector
/*     */     implements Runnable
/*     */   {
/*     */     private Process process;
/*     */     
/*     */     private String output;
/*     */     
/*     */     private OutputCollector(Process process) {
/* 319 */       this.process = process;
/*     */     }
/*     */ 
/*     */     
/*     */     public void run() {
/*     */       try {
/* 325 */         this.output = new String(ByteStreams.toByteArray(this.process.getInputStream()));
/* 326 */       } catch (IOException iOException) {}
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private String getOutput() {
/* 332 */       return this.output;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/Gcc.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */