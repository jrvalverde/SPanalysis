/*     */ package org.renjin.gcc.codegen.type.complex;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Optional;
/*     */ import org.renjin.gcc.codegen.MethodGenerator;
/*     */ import org.renjin.gcc.codegen.expr.ArrayElement;
/*     */ import org.renjin.gcc.codegen.expr.Expressions;
/*     */ import org.renjin.gcc.codegen.expr.GExpr;
/*     */ import org.renjin.gcc.codegen.expr.JExpr;
/*     */ import org.renjin.gcc.codegen.expr.PtrExpr;
/*     */ import org.renjin.gcc.codegen.fatptr.FatPtr;
/*     */ import org.renjin.gcc.codegen.fatptr.FatPtrPair;
/*     */ import org.renjin.gcc.codegen.fatptr.Memset;
/*     */ import org.renjin.gcc.codegen.fatptr.ValueFunction;
/*     */ import org.renjin.gcc.codegen.fatptr.WrappedFatPtrExpr;
/*     */ import org.renjin.gcc.codegen.vptr.VPtrExpr;
/*     */ import org.renjin.gcc.gimple.type.GimpleComplexType;
/*     */ import org.renjin.gcc.gimple.type.GimpleType;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ import org.renjin.repackaged.guava.collect.Lists;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ComplexValueFunction
/*     */   implements ValueFunction
/*     */ {
/*     */   private final GimpleComplexType valueType;
/*     */   
/*     */   public ComplexValueFunction(GimpleComplexType valueType) {
/*  40 */     this.valueType = valueType;
/*     */   }
/*     */ 
/*     */   
/*     */   public Type getValueType() {
/*  45 */     return this.valueType.getJvmPartType();
/*     */   }
/*     */ 
/*     */   
/*     */   public GimpleType getGimpleValueType() {
/*  50 */     return (GimpleType)this.valueType;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getElementLength() {
/*  55 */     return 2;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getArrayElementBytes() {
/*  60 */     return this.valueType.sizeOf() / 2;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public GExpr dereference(JExpr array, JExpr offset) {
/*  66 */     FatPtrPair address = new FatPtrPair(this, array, offset);
/*  67 */     return dereference(array, offset, (FatPtr)address);
/*     */   }
/*     */ 
/*     */   
/*     */   public GExpr dereference(WrappedFatPtrExpr wrapperInstance) {
/*  72 */     return dereference(wrapperInstance.getArray(), wrapperInstance.getOffset(), (FatPtr)wrapperInstance);
/*     */   }
/*     */ 
/*     */   
/*     */   private GExpr dereference(JExpr array, JExpr offset, FatPtr address) {
/*  77 */     JExpr realOffset = offset;
/*     */     
/*  79 */     JExpr imaginaryOffset = Expressions.sum(realOffset, Expressions.constantInt(1));
/*     */     
/*  81 */     ArrayElement arrayElement1 = Expressions.elementAt(array, realOffset);
/*  82 */     ArrayElement arrayElement2 = Expressions.elementAt(array, imaginaryOffset);
/*     */     
/*  84 */     return (GExpr)new ComplexExpr((PtrExpr)address, (JExpr)arrayElement1, (JExpr)arrayElement2);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<JExpr> toArrayValues(GExpr expr) {
/*  90 */     ComplexExpr value = (ComplexExpr)expr;
/*  91 */     return Lists.newArrayList((Object[])new JExpr[] { value.getRealJExpr(), value.getImaginaryJExpr() });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void memoryCopy(MethodGenerator mv, JExpr destinationArray, JExpr destinationOffset, JExpr sourceArray, JExpr sourceOffset, JExpr valueCount) {
/* 100 */     mv.arrayCopy(sourceArray, sourceOffset, destinationArray, destinationOffset, 
/* 101 */         Expressions.product(valueCount, 2));
/*     */   }
/*     */ 
/*     */   
/*     */   public void memorySet(MethodGenerator mv, JExpr array, JExpr offset, JExpr byteValue, JExpr length) {
/* 106 */     Memset.primitiveMemset(mv, this.valueType.getJvmPartType(), array, offset, byteValue, length);
/*     */   }
/*     */ 
/*     */   
/*     */   public Optional<JExpr> getValueConstructor() {
/* 111 */     return Optional.empty();
/*     */   }
/*     */ 
/*     */   
/*     */   public VPtrExpr toVPtr(JExpr array, JExpr offset) {
/* 116 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 122 */     return "Complex[" + this.valueType + "]";
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/type/complex/ComplexValueFunction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */