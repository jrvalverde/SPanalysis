/*     */ package org.renjin.gcc.logging;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.renjin.repackaged.asm.AnnotationVisitor;
/*     */ import org.renjin.repackaged.asm.Attribute;
/*     */ import org.renjin.repackaged.asm.Handle;
/*     */ import org.renjin.repackaged.asm.Label;
/*     */ import org.renjin.repackaged.asm.MethodVisitor;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ import org.renjin.repackaged.asm.TypePath;
/*     */ import org.renjin.repackaged.asm.tree.AbstractInsnNode;
/*     */ import org.renjin.repackaged.asm.tree.MethodNode;
/*     */ import org.renjin.repackaged.asm.util.Printer;
/*     */ import org.renjin.repackaged.guava.escape.Escaper;
/*     */ import org.renjin.repackaged.guava.html.HtmlEscapers;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BytecodeRenderer
/*     */ {
/*  33 */   public static final Escaper ESCAPER = HtmlEscapers.htmlEscaper();
/*  34 */   private StringBuilder html = new StringBuilder();
/*     */   
/*     */   private MethodNode methodNode;
/*  37 */   private final BytecodeMap bytecodeMap = new BytecodeMap();
/*  38 */   private final Map<Label, Integer> labelMap = new HashMap<>();
/*     */   
/*     */   public BytecodeRenderer(MethodNode methodNode) {
/*  41 */     this.methodNode = methodNode;
/*  42 */     this.methodNode.accept(this.bytecodeMap);
/*     */   }
/*     */   
/*     */   private void startIns() {
/*  46 */     this.html.append("<div class=\"bcins");
/*  47 */     if (this.bytecodeMap.isStarted()) {
/*  48 */       this.html.append(" SL SL").append(this.bytecodeMap.getCurrentLine());
/*     */     }
/*  50 */     this.html.append("\">");
/*     */   }
/*     */   
/*     */   private void opcode(int opcode) {
/*  54 */     opcode(Printer.OPCODES[opcode]);
/*     */   }
/*     */   
/*     */   private void opcode(String opcode) {
/*  58 */     this.html.append(String.format("<span class=\"opcode\">%s</span>", new Object[] { opcode }));
/*     */   }
/*     */   
/*     */   private void operand(int operand) {
/*  62 */     this.html.append(" ");
/*  63 */     this.html.append("<span class=\"bcldc\">");
/*  64 */     this.html.append(operand);
/*  65 */     this.html.append("</span>");
/*     */   }
/*     */   
/*     */   private void variable(int index) {
/*  69 */     this.html.append(" ");
/*  70 */     this.html.append("<span class=\"bcvar\">");
/*  71 */     BytecodeMap.Var currentVar = this.bytecodeMap.getCurrentVar(index);
/*  72 */     if (currentVar == null) {
/*  73 */       this.html.append(index);
/*     */     } else {
/*  75 */       this.html.append(ESCAPER.escape(currentVar.getName()));
/*     */     } 
/*  77 */     this.html.append("</span>");
/*     */     
/*  79 */     if (currentVar != null) {
/*  80 */       this.html.append(" ");
/*  81 */       description(currentVar.getDesc());
/*     */     } 
/*     */   }
/*     */   
/*     */   private void label(Label label) {
/*  86 */     this.html.append(" ");
/*  87 */     this.html.append(String.format("<span class=\"bclabel\">%s</span>", new Object[] { friendly(label) }));
/*     */   }
/*     */ 
/*     */   
/*     */   private String friendly(Label label) {
/*  92 */     Integer number = this.labelMap.get(label);
/*  93 */     if (number == null) {
/*  94 */       number = Integer.valueOf(this.labelMap.size() + 1);
/*  95 */       this.labelMap.put(label, number);
/*     */     } 
/*  97 */     return "L" + number;
/*     */   }
/*     */   
/*     */   private void typeOperand(String type) {
/* 101 */     this.html.append(" ");
/* 102 */     type(type);
/*     */   }
/*     */   
/*     */   private void type(String type) {
/* 106 */     String shortName = shortNameOfType(type);
/*     */     
/* 108 */     this.html.append(String.format("<span class=\"bctype\" title=\"%s\">%s</span>", new Object[] { ESCAPER
/* 109 */             .escape(type), ESCAPER
/* 110 */             .escape(shortName) }));
/*     */   }
/*     */   
/*     */   private void type(Type type) {
/* 114 */     if (type.getSort() == 10) {
/* 115 */       type(type.getInternalName());
/* 116 */     } else if (type.getSort() == 9) {
/* 117 */       this.html.append("[");
/* 118 */       type(type.getElementType());
/*     */     } else {
/* 120 */       this.html.append(type.toString());
/*     */     } 
/*     */   }
/*     */   
/*     */   private String shortNameOfType(String type) {
/* 125 */     int lastSlash = type.lastIndexOf('/');
/* 126 */     return type.substring(lastSlash + 1);
/*     */   }
/*     */ 
/*     */   
/*     */   private void signature(String owner, String name, String desc) {
/* 131 */     this.html.append(" ");
/* 132 */     typeOperand(owner);
/* 133 */     this.html.append(String.format(".<span class\"bcmember\">%s</span>", new Object[] { ESCAPER.escape(name) }));
/* 134 */     description(desc);
/*     */   }
/*     */   
/*     */   private void description(String desc) {
/* 138 */     int i = 0;
/*     */     
/* 140 */     while (i < desc.length()) {
/* 141 */       if (desc.charAt(i) == 'L') {
/* 142 */         int endOfType = desc.indexOf(';', i);
/* 143 */         type(desc.substring(i + 1, endOfType));
/* 144 */         i = endOfType + 1; continue;
/*     */       } 
/* 146 */       this.html.append(desc.charAt(i));
/* 147 */       i++;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void endIns() {
/* 153 */     this.html.append("</div>");
/*     */   }
/*     */ 
/*     */   
/*     */   public String render() {
/* 158 */     this.html.append("<div class=\"bcmethod\">");
/* 159 */     type(Type.getReturnType(this.methodNode.desc));
/* 160 */     this.html.append(" ");
/* 161 */     this.html.append(this.methodNode.name);
/* 162 */     this.html.append("(");
/* 163 */     Type[] argumentTypes = Type.getArgumentTypes(this.methodNode.desc); int i;
/* 164 */     for (i = 0; i < argumentTypes.length; i++) {
/* 165 */       if (i > 0) {
/* 166 */         this.html.append(", ");
/*     */       }
/* 168 */       type(argumentTypes[i]);
/*     */     } 
/* 170 */     this.html.append(")");
/* 171 */     this.html.append("</div>");
/*     */     
/* 173 */     for (i = 0; i < this.methodNode.instructions.size(); i++) {
/* 174 */       AbstractInsnNode node = this.methodNode.instructions.get(i);
/* 175 */       node.accept(new MethodVisitor(327680)
/*     */           {
/*     */             public void visitParameter(String name, int access) {}
/*     */ 
/*     */ 
/*     */             
/*     */             public AnnotationVisitor visitAnnotationDefault() {
/* 182 */               return null;
/*     */             }
/*     */ 
/*     */             
/*     */             public AnnotationVisitor visitAnnotation(String desc, boolean visible) {
/* 187 */               return null;
/*     */             }
/*     */ 
/*     */             
/*     */             public AnnotationVisitor visitTypeAnnotation(int typeRef, TypePath typePath, String desc, boolean visible) {
/* 192 */               return null;
/*     */             }
/*     */ 
/*     */             
/*     */             public AnnotationVisitor visitParameterAnnotation(int parameter, String desc, boolean visible) {
/* 197 */               return null;
/*     */             }
/*     */ 
/*     */ 
/*     */             
/*     */             public void visitAttribute(Attribute attr) {}
/*     */ 
/*     */             
/*     */             public void visitCode() {
/* 206 */               super.visitCode();
/*     */             }
/*     */ 
/*     */ 
/*     */             
/*     */             public void visitFrame(int type, int nLocal, Object[] local, int nStack, Object[] stack) {}
/*     */ 
/*     */             
/*     */             public void visitInsn(int opcode) {
/* 215 */               BytecodeRenderer.this.startIns();
/* 216 */               BytecodeRenderer.this.opcode(opcode);
/* 217 */               BytecodeRenderer.this.endIns();
/*     */             }
/*     */ 
/*     */             
/*     */             public void visitIntInsn(int opcode, int operand) {
/* 222 */               BytecodeRenderer.this.startIns();
/* 223 */               BytecodeRenderer.this.opcode(opcode);
/* 224 */               BytecodeRenderer.this.operand(operand);
/* 225 */               BytecodeRenderer.this.endIns();
/*     */             }
/*     */ 
/*     */             
/*     */             public void visitVarInsn(int opcode, int var) {
/* 230 */               BytecodeRenderer.this.startIns();
/* 231 */               BytecodeRenderer.this.opcode(opcode);
/* 232 */               BytecodeRenderer.this.variable(var);
/* 233 */               BytecodeRenderer.this.endIns();
/*     */             }
/*     */ 
/*     */             
/*     */             public void visitTypeInsn(int opcode, String type) {
/* 238 */               BytecodeRenderer.this.startIns();
/* 239 */               BytecodeRenderer.this.opcode(opcode);
/* 240 */               BytecodeRenderer.this.typeOperand(type);
/* 241 */               BytecodeRenderer.this.endIns();
/*     */             }
/*     */ 
/*     */             
/*     */             public void visitFieldInsn(int opcode, String owner, String name, String desc) {
/* 246 */               BytecodeRenderer.this.startIns();
/* 247 */               BytecodeRenderer.this.opcode(opcode);
/* 248 */               BytecodeRenderer.this.signature(owner, name, desc);
/* 249 */               BytecodeRenderer.this.endIns();
/*     */             }
/*     */ 
/*     */             
/*     */             public void visitMethodInsn(int opcode, String owner, String name, String desc) {
/* 254 */               BytecodeRenderer.this.startIns();
/* 255 */               BytecodeRenderer.this.opcode(opcode);
/* 256 */               BytecodeRenderer.this.signature(owner, name, desc);
/* 257 */               BytecodeRenderer.this.endIns();
/*     */             }
/*     */ 
/*     */             
/*     */             public void visitMethodInsn(int opcode, String owner, String name, String desc, boolean itf) {
/* 262 */               BytecodeRenderer.this.startIns();
/* 263 */               BytecodeRenderer.this.opcode(opcode);
/* 264 */               BytecodeRenderer.this.signature(owner, name, desc);
/* 265 */               BytecodeRenderer.this.endIns();
/*     */             }
/*     */ 
/*     */             
/*     */             public void visitInvokeDynamicInsn(String name, String desc, Handle bsm, Object... bsmArgs) {
/* 270 */               BytecodeRenderer.this.startIns();
/* 271 */               BytecodeRenderer.this.opcode("INVOKEDYN");
/* 272 */               BytecodeRenderer.this.endIns();
/*     */             }
/*     */ 
/*     */ 
/*     */             
/*     */             public void visitJumpInsn(int opcode, Label label) {
/* 278 */               BytecodeRenderer.this.startIns();
/* 279 */               BytecodeRenderer.this.opcode(opcode);
/* 280 */               BytecodeRenderer.this.label(label);
/* 281 */               BytecodeRenderer.this.endIns();
/*     */             }
/*     */ 
/*     */             
/*     */             public void visitLabel(Label label) {
/* 286 */               BytecodeRenderer.this.bytecodeMap.onLabel(label);
/* 287 */               BytecodeRenderer.this.html.append(String.format("<div class=\"bclabel\">%s:</div>", new Object[] { BytecodeRenderer.access$1000(this.this$0, label) }));
/*     */             }
/*     */ 
/*     */             
/*     */             public void visitLdcInsn(Object cst) {
/* 292 */               BytecodeRenderer.this.startIns();
/* 293 */               BytecodeRenderer.this.opcode("LDC");
/* 294 */               BytecodeRenderer.this.html.append(" ");
/* 295 */               BytecodeRenderer.this.html.append("<span class=\"bcldc\">");
/* 296 */               if (cst instanceof String) {
/* 297 */                 BytecodeRenderer.this.html.append(BytecodeRenderer.ESCAPER.escape(GimpleRenderer.stringLiteral((String)cst)));
/*     */               } else {
/* 299 */                 BytecodeRenderer.this.html.append(cst.toString());
/*     */               } 
/* 301 */               BytecodeRenderer.this.html.append("</span>");
/* 302 */               BytecodeRenderer.this.endIns();
/*     */             }
/*     */ 
/*     */             
/*     */             public void visitIincInsn(int var, int increment) {
/* 307 */               BytecodeRenderer.this.startIns();
/* 308 */               BytecodeRenderer.this.opcode("IINC");
/* 309 */               BytecodeRenderer.this.variable(var);
/* 310 */               BytecodeRenderer.this.operand(increment);
/* 311 */               BytecodeRenderer.this.endIns();
/*     */             }
/*     */ 
/*     */             
/*     */             public void visitTableSwitchInsn(int min, int max, Label dflt, Label... labels) {
/* 316 */               BytecodeRenderer.this.startIns();
/* 317 */               BytecodeRenderer.this.opcode("TABLESWITCH");
/* 318 */               BytecodeRenderer.this.endIns();
/*     */             }
/*     */ 
/*     */             
/*     */             public void visitLookupSwitchInsn(Label dflt, int[] keys, Label[] labels) {
/* 323 */               BytecodeRenderer.this.startIns();
/* 324 */               BytecodeRenderer.this.opcode("LOOKUPSWITCH");
/* 325 */               BytecodeRenderer.this.endIns();
/*     */             }
/*     */ 
/*     */             
/*     */             public void visitMultiANewArrayInsn(String desc, int dims) {
/* 330 */               BytecodeRenderer.this.startIns();
/* 331 */               BytecodeRenderer.this.opcode("ANEWMULTI");
/* 332 */               BytecodeRenderer.this.typeOperand(desc);
/* 333 */               BytecodeRenderer.this.operand(dims);
/* 334 */               BytecodeRenderer.this.endIns();
/*     */             }
/*     */ 
/*     */             
/*     */             public AnnotationVisitor visitInsnAnnotation(int typeRef, TypePath typePath, String desc, boolean visible) {
/* 339 */               return super.visitInsnAnnotation(typeRef, typePath, desc, visible);
/*     */             }
/*     */ 
/*     */ 
/*     */             
/*     */             public void visitTryCatchBlock(Label start, Label end, Label handler, String type) {}
/*     */ 
/*     */             
/*     */             public AnnotationVisitor visitTryCatchAnnotation(int typeRef, TypePath typePath, String desc, boolean visible) {
/* 348 */               return null;
/*     */             }
/*     */ 
/*     */ 
/*     */             
/*     */             public void visitLocalVariable(String name, String desc, String signature, Label start, Label end, int index) {}
/*     */ 
/*     */             
/*     */             public AnnotationVisitor visitLocalVariableAnnotation(int typeRef, TypePath typePath, Label[] start, Label[] end, int[] index, String desc, boolean visible) {
/* 357 */               return null;
/*     */             }
/*     */ 
/*     */ 
/*     */             
/*     */             public void visitLineNumber(int line, Label start) {}
/*     */ 
/*     */ 
/*     */             
/*     */             public void visitMaxs(int maxStack, int maxLocals) {}
/*     */ 
/*     */ 
/*     */             
/*     */             public void visitEnd() {}
/*     */           });
/*     */     } 
/* 373 */     return this.html.toString();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/logging/BytecodeRenderer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */