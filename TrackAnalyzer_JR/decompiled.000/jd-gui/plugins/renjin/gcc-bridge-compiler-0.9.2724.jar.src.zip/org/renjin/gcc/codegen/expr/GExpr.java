package org.renjin.gcc.codegen.expr;

import org.renjin.gcc.codegen.MethodGenerator;
import org.renjin.gcc.codegen.array.FatArrayExpr;
import org.renjin.gcc.codegen.fatptr.FatPtr;
import org.renjin.gcc.codegen.fatptr.ValueFunction;
import org.renjin.gcc.codegen.type.NumericExpr;
import org.renjin.gcc.codegen.type.UnsupportedCastException;
import org.renjin.gcc.codegen.type.fun.FunPtrExpr;
import org.renjin.gcc.codegen.type.primitive.PrimitiveExpr;
import org.renjin.gcc.codegen.type.record.ProvidedPtrExpr;
import org.renjin.gcc.codegen.type.voidt.VoidPtrExpr;
import org.renjin.gcc.codegen.vptr.VArrayExpr;
import org.renjin.gcc.codegen.vptr.VPtrExpr;
import org.renjin.gcc.codegen.vptr.VPtrRecordExpr;
import org.renjin.gcc.gimple.type.GimpleArrayType;
import org.renjin.gcc.gimple.type.GimpleRecordType;
import org.renjin.repackaged.asm.Type;

public interface GExpr {
  void store(MethodGenerator paramMethodGenerator, GExpr paramGExpr);
  
  PtrExpr addressOf();
  
  FunPtrExpr toFunPtr() throws UnsupportedCastException;
  
  FatArrayExpr toArrayExpr() throws UnsupportedCastException;
  
  PrimitiveExpr toPrimitiveExpr() throws UnsupportedCastException;
  
  VoidPtrExpr toVoidPtrExpr() throws UnsupportedCastException;
  
  VPtrExpr toVPtrExpr() throws UnsupportedCastException;
  
  ProvidedPtrExpr toProvidedPtrExpr(Type paramType);
  
  FatPtr toFatPtrExpr(ValueFunction paramValueFunction);
  
  VPtrRecordExpr toVPtrRecord(GimpleRecordType paramGimpleRecordType);
  
  VArrayExpr toVArray(GimpleArrayType paramGimpleArrayType);
  
  NumericExpr toNumericExpr();
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/expr/GExpr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */