/*    */ package org.renjin.gcc.codegen.type.primitive;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import java.util.Optional;
/*    */ import org.renjin.gcc.codegen.MethodGenerator;
/*    */ import org.renjin.gcc.codegen.expr.ArrayElement;
/*    */ import org.renjin.gcc.codegen.expr.ConstantValue;
/*    */ import org.renjin.gcc.codegen.expr.Expressions;
/*    */ import org.renjin.gcc.codegen.expr.GExpr;
/*    */ import org.renjin.gcc.codegen.expr.JExpr;
/*    */ import org.renjin.gcc.codegen.expr.JLValue;
/*    */ import org.renjin.gcc.codegen.expr.PtrExpr;
/*    */ import org.renjin.gcc.codegen.fatptr.FatPtrPair;
/*    */ import org.renjin.gcc.codegen.type.ParamStrategy;
/*    */ import org.renjin.gcc.codegen.var.VarAllocator;
/*    */ import org.renjin.gcc.gimple.GimpleParameter;
/*    */ import org.renjin.gcc.gimple.type.GimplePrimitiveType;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PrimitiveParamStrategy
/*    */   implements ParamStrategy
/*    */ {
/*    */   private PrimitiveType type;
/*    */   
/*    */   public PrimitiveParamStrategy(PrimitiveType type) {
/* 42 */     this.type = type;
/*    */   }
/*    */   
/*    */   public PrimitiveParamStrategy(GimplePrimitiveType primitiveType) {
/* 46 */     this(PrimitiveType.of(primitiveType));
/*    */   }
/*    */ 
/*    */   
/*    */   public List<Type> getParameterTypes() {
/* 51 */     return Collections.singletonList(this.type.jvmType());
/*    */   }
/*    */ 
/*    */   
/*    */   public List<String> getParameterNames(String name) {
/* 56 */     return Collections.singletonList(name);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public GExpr emitInitialization(MethodGenerator mv, GimpleParameter parameter, List<JLValue> paramVars, VarAllocator localVars) {
/* 65 */     JExpr paramValue = (JExpr)paramVars.get(0);
/*    */     
/* 67 */     if (parameter.isAddressable()) {
/*    */ 
/*    */       
/* 70 */       JLValue unitArray = localVars.reserveUnitArray(parameter.getName(), this.type.jvmType(), Optional.of(paramValue));
/* 71 */       FatPtrPair address = new FatPtrPair(new PrimitiveValueFunction(this.type), (JExpr)unitArray);
/* 72 */       ArrayElement arrayElement = Expressions.elementAt(address.getArray(), 0);
/* 73 */       return this.type.fromNonStackValue((JExpr)arrayElement, (PtrExpr)address);
/*    */     } 
/*    */ 
/*    */     
/* 77 */     return this.type.fromNonStackValue(paramValue);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void loadParameter(MethodGenerator mv, Optional<GExpr> argument) {
/* 83 */     if (argument.isPresent()) {
/* 84 */       this.type.cast(((GExpr)argument.get()).toPrimitiveExpr()).jexpr().load(mv);
/*    */     } else {
/* 86 */       (new ConstantValue(this.type.jvmType(), Integer.valueOf(0))).load(mv);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/type/primitive/PrimitiveParamStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */