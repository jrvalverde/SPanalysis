/*    */ package org.renjin.gcc.codegen.call;
/*    */ 
/*    */ import org.renjin.gcc.InternalCompilerException;
/*    */ import org.renjin.gcc.codegen.MethodGenerator;
/*    */ import org.renjin.gcc.codegen.expr.ExprFactory;
/*    */ import org.renjin.gcc.codegen.expr.Expressions;
/*    */ import org.renjin.gcc.codegen.expr.GExpr;
/*    */ import org.renjin.gcc.codegen.type.primitive.PrimitiveExpr;
/*    */ import org.renjin.gcc.codegen.type.primitive.PrimitiveType;
/*    */ import org.renjin.gcc.gimple.expr.GimpleExpr;
/*    */ import org.renjin.gcc.gimple.statement.GimpleCall;
/*    */ import org.renjin.repackaged.guava.base.Preconditions;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BuiltinClzGenerator
/*    */   implements CallGenerator
/*    */ {
/*    */   public static final String NAME = "__builtin_clz";
/*    */   
/*    */   public void emitCall(MethodGenerator mv, ExprFactory exprFactory, GimpleCall call) {
/* 41 */     Preconditions.checkArgument((call.getOperands().size() == 1), "Expected 1 argument");
/*    */ 
/*    */     
/* 44 */     if (call.getLhs() == null) {
/*    */       return;
/*    */     }
/* 47 */     GExpr lhs = exprFactory.findGenerator((GimpleExpr)call.getLhs());
/*    */ 
/*    */     
/* 50 */     GExpr value = exprFactory.findGenerator(call.getOperand(0));
/* 51 */     if (!(value instanceof PrimitiveExpr)) {
/* 52 */       throw new InternalCompilerException("Expected primitive operand: " + value);
/*    */     }
/*    */     
/* 55 */     PrimitiveExpr argument = (PrimitiveExpr)value;
/* 56 */     PrimitiveExpr result = PrimitiveType.INT32.fromStackValue(Expressions.numberOfLeadingZeros(argument.jexpr()));
/*    */     
/* 58 */     lhs.store(mv, (GExpr)result);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/call/BuiltinClzGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */