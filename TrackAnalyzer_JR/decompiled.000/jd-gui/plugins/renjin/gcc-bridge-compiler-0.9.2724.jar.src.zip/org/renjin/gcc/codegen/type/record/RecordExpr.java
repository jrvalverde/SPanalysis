package org.renjin.gcc.codegen.type.record;

import org.renjin.gcc.codegen.MethodGenerator;
import org.renjin.gcc.codegen.expr.GExpr;
import org.renjin.gcc.gimple.type.GimpleType;

public interface RecordExpr extends GExpr {
  GExpr memberOf(MethodGenerator paramMethodGenerator, int paramInt1, int paramInt2, GimpleType paramGimpleType);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/type/record/RecordExpr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */