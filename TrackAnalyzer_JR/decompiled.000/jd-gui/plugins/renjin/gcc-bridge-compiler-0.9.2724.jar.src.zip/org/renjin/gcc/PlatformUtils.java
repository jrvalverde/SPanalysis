/*     */ package org.renjin.gcc;
/*     */ 
/*     */ import java.io.File;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PlatformUtils
/*     */ {
/*     */   public enum ARCHType
/*     */   {
/*  44 */     PPC, PPC_64, SPARC, UNKNOWN, X86, X86_64;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public enum OSType
/*     */   {
/*  51 */     APPLE, LINUX, SUN, UNKNOWN, WINDOWS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  57 */   public static final ARCHType ARCH = calculateArch();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  62 */   public static final OSType OS = calculateOS();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getPortableLibraryName(String name) {
/*  99 */     if (name == null) {
/* 100 */       throw new NullPointerException();
/*     */     }
/*     */     
/* 103 */     if (name.length() == 0 || name.contains(File.separator) || name
/* 104 */       .contains("/")) {
/* 105 */       throw new IllegalArgumentException("Directory separator should not appear in library name: " + name);
/*     */     }
/*     */ 
/*     */     
/* 109 */     return name.toLowerCase() + getSuffix() + getExtension();
/*     */   }
/*     */   
/*     */   public static String getExtension() {
/* 113 */     switch (OS) {
/*     */       case APPLE:
/* 115 */         return ".so";
/*     */       case WINDOWS:
/* 117 */         return ".dll";
/*     */     } 
/*     */     
/* 120 */     return ".so";
/*     */   }
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {
/* 125 */     System.out.println(OS + ", " + ARCH + ", " + 
/* 126 */         getPortableLibraryName("NAME"));
/*     */   }
/*     */   
/*     */   private static ARCHType calculateArch() {
/* 130 */     String osArch = System.getProperty("os.arch").toLowerCase();
/* 131 */     assert osArch != null;
/* 132 */     if (osArch.equals("i386")) {
/* 133 */       return ARCHType.X86;
/*     */     }
/* 135 */     if (osArch.startsWith("amd64") || osArch.startsWith("x86_64")) {
/* 136 */       return ARCHType.X86_64;
/*     */     }
/* 138 */     if (osArch.equals("ppc")) {
/* 139 */       return ARCHType.PPC;
/*     */     }
/* 141 */     if (osArch.startsWith("ppc")) {
/* 142 */       return ARCHType.PPC_64;
/*     */     }
/* 144 */     if (osArch.startsWith("sparc")) {
/* 145 */       return ARCHType.SPARC;
/*     */     }
/* 147 */     return ARCHType.UNKNOWN;
/*     */   }
/*     */   
/*     */   private static OSType calculateOS() {
/* 151 */     String osName = System.getProperty("os.name").toLowerCase();
/* 152 */     assert osName != null;
/* 153 */     if (osName.startsWith("mac os x")) {
/* 154 */       return OSType.APPLE;
/*     */     }
/* 156 */     if (osName.startsWith("windows")) {
/* 157 */       return OSType.WINDOWS;
/*     */     }
/* 159 */     if (osName.startsWith("linux")) {
/* 160 */       return OSType.LINUX;
/*     */     }
/* 162 */     if (osName.startsWith("sun")) {
/* 163 */       return OSType.SUN;
/*     */     }
/* 165 */     return OSType.UNKNOWN;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static String getSuffix() {
/* 171 */     String prefix = "-" + OS.toString().toLowerCase() + "-" + ARCH.toString().toLowerCase();
/*     */     
/* 173 */     return prefix;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/PlatformUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */