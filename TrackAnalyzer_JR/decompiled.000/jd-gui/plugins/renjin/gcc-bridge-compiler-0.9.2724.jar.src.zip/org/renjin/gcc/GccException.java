/*    */ package org.renjin.gcc;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GccException
/*    */   extends RuntimeException
/*    */ {
/*    */   public GccException(String message) {
/* 27 */     super(message);
/*    */   }
/*    */   
/*    */   public GccException(String message, Exception e) {
/* 31 */     super(message, e);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/GccException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */