/*    */ package org.renjin.gcc.gimple.type;
/*    */ 
/*    */ import org.renjin.gcc.gimple.expr.GimpleConstant;
/*    */ import org.renjin.gcc.gimple.expr.GimpleIntegerConstant;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GimpleOffsetType
/*    */   extends AbstractGimpleType
/*    */   implements GimpleIndirectType
/*    */ {
/*    */   private GimpleType baseType;
/*    */   private GimpleType offsetBaseType;
/*    */   
/*    */   public GimpleConstant nullValue() {
/* 36 */     return (GimpleConstant)GimpleIntegerConstant.nullValue(this);
/*    */   }
/*    */ 
/*    */   
/*    */   public <X extends GimpleType> X getBaseType() {
/* 41 */     return (X)this.baseType;
/*    */   }
/*    */   
/*    */   public void setBaseType(GimpleType baseType) {
/* 45 */     this.baseType = baseType;
/*    */   }
/*    */   
/*    */   public GimpleType getOffsetBaseType() {
/* 49 */     return this.offsetBaseType;
/*    */   }
/*    */   
/*    */   public void setOffsetBaseType(GimpleType offsetBaseType) {
/* 53 */     this.offsetBaseType = offsetBaseType;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int sizeOf() {
/* 59 */     return 4;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 64 */     if (this == o) {
/* 65 */       return true;
/*    */     }
/* 67 */     if (o == null || getClass() != o.getClass()) {
/* 68 */       return false;
/*    */     }
/*    */     
/* 71 */     GimpleOffsetType that = (GimpleOffsetType)o;
/*    */     
/* 73 */     return (this.baseType.equals(that.baseType) && this.offsetBaseType
/* 74 */       .equals(that.offsetBaseType));
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 79 */     int result = this.baseType.hashCode();
/* 80 */     result = 31 * result + this.offsetBaseType.hashCode();
/* 81 */     return result;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/gimple/type/GimpleOffsetType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */