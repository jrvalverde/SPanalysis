/*     */ package org.renjin.gcc.codegen.fatptr;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Optional;
/*     */ import org.renjin.gcc.codegen.MethodGenerator;
/*     */ import org.renjin.gcc.codegen.expr.Expressions;
/*     */ import org.renjin.gcc.codegen.expr.GExpr;
/*     */ import org.renjin.gcc.codegen.expr.JExpr;
/*     */ import org.renjin.gcc.codegen.expr.JLValue;
/*     */ import org.renjin.gcc.codegen.vptr.VPtrExpr;
/*     */ import org.renjin.gcc.gimple.type.GimpleType;
/*     */ import org.renjin.gcc.runtime.PointerPtr;
/*     */ import org.renjin.gcc.runtime.Ptr;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FatPtrValueFunction
/*     */   implements ValueFunction
/*     */ {
/*     */   private final ValueFunction baseValueFunction;
/*     */   private final Type arrayType;
/*     */   
/*     */   public FatPtrValueFunction(ValueFunction baseValueFunction) {
/*  49 */     this.baseValueFunction = baseValueFunction;
/*  50 */     this.arrayType = Wrappers.valueArrayType(baseValueFunction.getValueType());
/*     */   }
/*     */ 
/*     */   
/*     */   public Type getValueType() {
/*  55 */     return Wrappers.wrapperType(this.baseValueFunction.getValueType());
/*     */   }
/*     */ 
/*     */   
/*     */   public GimpleType getGimpleValueType() {
/*  60 */     return (GimpleType)this.baseValueFunction.getGimpleValueType().pointerTo();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getElementLength() {
/*  65 */     return 1;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getArrayElementBytes() {
/*  70 */     return 4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GExpr dereference(JExpr array, JExpr offset) {
/*  81 */     return (GExpr)new DereferencedFatPtr(array, offset, this.baseValueFunction);
/*     */   }
/*     */ 
/*     */   
/*     */   public GExpr dereference(WrappedFatPtrExpr wrapperInstance) {
/*  86 */     return (GExpr)new DereferencedWrappedFatPtr(this.baseValueFunction, wrapperInstance);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<JExpr> toArrayValues(GExpr expr) {
/*  91 */     FatPtrPair fatPtrExpr = (FatPtrPair)expr;
/*  92 */     return Collections.singletonList(fatPtrExpr.wrap());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void memoryCopy(MethodGenerator mv, JExpr destinationArray, JExpr destinationOffset, JExpr sourceArray, JExpr sourceOffset, JExpr valueCount) {
/* 100 */     mv.arrayCopy(sourceArray, sourceOffset, destinationArray, destinationOffset, valueCount);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void memorySet(MethodGenerator mv, JExpr array, JExpr offset, JExpr byteValue, JExpr length) {
/* 113 */     JExpr toIndex = Expressions.sum(offset, Expressions.divide(length, Expressions.constantInt(4)));
/* 114 */     JLValue nullInstance = Expressions.staticField(getValueType(), "NULL", getValueType());
/*     */     
/* 116 */     mv.fillArray(array, offset, toIndex, (JExpr)nullInstance);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<JExpr> getValueConstructor() {
/* 122 */     return Optional.of(FatPtrPair.nullPtr(this.baseValueFunction).wrap());
/*     */   }
/*     */ 
/*     */   
/*     */   public VPtrExpr toVPtr(JExpr array, JExpr offset) {
/* 127 */     return new VPtrExpr(Expressions.staticMethodCall(PointerPtr.class, "wrap", 
/* 128 */           Type.getMethodDescriptor(Type.getType(PointerPtr.class), new Type[] { Type.getType(Ptr[].class), Type.INT_TYPE }), new JExpr[] { array, offset }));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 134 */     return "FatPtr[" + this.baseValueFunction + "]";
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/fatptr/FatPtrValueFunction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */