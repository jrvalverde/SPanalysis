/*    */ package org.renjin.gcc.codegen.type.voidt;
/*    */ 
/*    */ import javax.annotation.Nonnull;
/*    */ import org.renjin.gcc.codegen.MethodGenerator;
/*    */ import org.renjin.gcc.codegen.expr.JExpr;
/*    */ import org.renjin.gcc.runtime.VoidPtr;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VoidPtrMemCmp
/*    */   implements JExpr
/*    */ {
/*    */   private JExpr x;
/*    */   private JExpr y;
/*    */   private JExpr n;
/*    */   
/*    */   public VoidPtrMemCmp(JExpr x, JExpr y, JExpr n) {
/* 40 */     this.x = x;
/* 41 */     this.y = y;
/* 42 */     this.n = n;
/*    */   }
/*    */ 
/*    */   
/*    */   @Nonnull
/*    */   public Type getType() {
/* 48 */     return Type.INT_TYPE;
/*    */   }
/*    */ 
/*    */   
/*    */   public void load(@Nonnull MethodGenerator mv) {
/* 53 */     this.x.load(mv);
/* 54 */     this.y.load(mv);
/* 55 */     this.n.load(mv);
/* 56 */     mv.invokestatic(VoidPtr.class, "memcmp", 
/* 57 */         Type.getMethodDescriptor(Type.INT_TYPE, new Type[] {
/* 58 */             Type.getType(Object.class), Type.getType(Object.class), Type.INT_TYPE
/*    */           }));
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/type/voidt/VoidPtrMemCmp.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */