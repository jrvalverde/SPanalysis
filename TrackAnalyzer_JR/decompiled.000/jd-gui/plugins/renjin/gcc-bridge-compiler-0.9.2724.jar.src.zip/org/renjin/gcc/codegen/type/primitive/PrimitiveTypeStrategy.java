/*     */ package org.renjin.gcc.codegen.type.primitive;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.Optional;
/*     */ import org.renjin.gcc.codegen.MethodGenerator;
/*     */ import org.renjin.gcc.codegen.array.ArrayTypeStrategies;
/*     */ import org.renjin.gcc.codegen.array.ArrayTypeStrategy;
/*     */ import org.renjin.gcc.codegen.expr.ArrayElement;
/*     */ import org.renjin.gcc.codegen.expr.ConstantValue;
/*     */ import org.renjin.gcc.codegen.expr.ExprFactory;
/*     */ import org.renjin.gcc.codegen.expr.Expressions;
/*     */ import org.renjin.gcc.codegen.expr.GExpr;
/*     */ import org.renjin.gcc.codegen.expr.JExpr;
/*     */ import org.renjin.gcc.codegen.expr.JLValue;
/*     */ import org.renjin.gcc.codegen.expr.PtrExpr;
/*     */ import org.renjin.gcc.codegen.fatptr.AddressableField;
/*     */ import org.renjin.gcc.codegen.fatptr.FatPtrPair;
/*     */ import org.renjin.gcc.codegen.fatptr.ValueFunction;
/*     */ import org.renjin.gcc.codegen.type.FieldStrategy;
/*     */ import org.renjin.gcc.codegen.type.ParamStrategy;
/*     */ import org.renjin.gcc.codegen.type.PointerTypeStrategy;
/*     */ import org.renjin.gcc.codegen.type.ReturnStrategy;
/*     */ import org.renjin.gcc.codegen.type.TypeStrategy;
/*     */ import org.renjin.gcc.codegen.type.UnsupportedCastException;
/*     */ import org.renjin.gcc.codegen.var.GlobalVarAllocator;
/*     */ import org.renjin.gcc.codegen.var.VarAllocator;
/*     */ import org.renjin.gcc.codegen.vptr.VPtrExpr;
/*     */ import org.renjin.gcc.codegen.vptr.VPtrStrategy;
/*     */ import org.renjin.gcc.gimple.GimpleVarDecl;
/*     */ import org.renjin.gcc.gimple.expr.GimpleConstructor;
/*     */ import org.renjin.gcc.gimple.type.GimpleArrayType;
/*     */ import org.renjin.gcc.gimple.type.GimplePrimitiveType;
/*     */ import org.renjin.gcc.gimple.type.GimpleType;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PrimitiveTypeStrategy
/*     */   implements TypeStrategy<PrimitiveExpr>
/*     */ {
/*     */   private PrimitiveType type;
/*     */   
/*     */   public PrimitiveTypeStrategy(GimplePrimitiveType type) {
/*  53 */     this.type = PrimitiveType.of(type);
/*     */   }
/*     */   
/*     */   public GimplePrimitiveType getType() {
/*  57 */     return this.type.gimpleType();
/*     */   }
/*     */ 
/*     */   
/*     */   public ParamStrategy getParamStrategy() {
/*  62 */     return new PrimitiveParamStrategy(this.type);
/*     */   }
/*     */ 
/*     */   
/*     */   public ReturnStrategy getReturnStrategy() {
/*  67 */     return new PrimitiveReturnStrategy(this.type);
/*     */   }
/*     */   
/*     */   public ValueFunction getValueFunction() {
/*  71 */     return valueFunction();
/*     */   }
/*     */ 
/*     */   
/*     */   public FieldStrategy addressableFieldGenerator(Type className, String fieldName) {
/*  76 */     return (FieldStrategy)new AddressableField(className, fieldName, valueFunction());
/*     */   }
/*     */ 
/*     */   
/*     */   public FieldStrategy fieldGenerator(Type className, String fieldName) {
/*  81 */     return (FieldStrategy)new PrimitiveFieldStrategy(className, fieldName, this.type);
/*     */   }
/*     */ 
/*     */   
/*     */   public PrimitiveExpr variable(GimpleVarDecl decl, VarAllocator allocator) {
/*  86 */     if (decl.isAddressable()) {
/*  87 */       JLValue unitArray = allocator.reserveUnitArray(decl.getNameIfPresent(), this.type.localVariableType(), Optional.empty());
/*  88 */       FatPtrPair address = new FatPtrPair(valueFunction(), (JExpr)unitArray);
/*  89 */       ArrayElement arrayElement = Expressions.elementAt(address.getArray(), 0);
/*  90 */       return this.type.fromStackValue((JExpr)arrayElement, (PtrExpr)address);
/*     */     } 
/*     */     
/*  93 */     return this.type.fromStackValue((JExpr)allocator.reserve(decl.getNameIfPresent(), this.type.localVariableType()));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public PrimitiveExpr globalVariable(GimpleVarDecl decl, GlobalVarAllocator allocator) {
/*  99 */     GlobalVarAllocator.StaticField field = allocator.reserve(decl.getNameIfPresent(), this.type.localVariableType());
/* 100 */     JExpr ptrExpr = this.type.fieldPointer(field.getDeclaringClass(), field.getName());
/* 101 */     VPtrExpr vPtrExpr = new VPtrExpr(ptrExpr);
/*     */     
/* 103 */     return this.type.fromStackValue((JExpr)field, (PtrExpr)vPtrExpr);
/*     */   }
/*     */   
/*     */   public PrimitiveExpr providedGlobalVariable(GimpleVarDecl decl, JExpr expr, boolean readOnly) {
/*     */     FatPtrPair fatPtrPair;
/* 108 */     Type javaType = expr.getType();
/* 109 */     if (!javaType.equals(this.type.jvmType())) {
/* 110 */       throw new UnsupportedOperationException("Cannot map global variable " + decl + " to JVM field of type " + expr + ". Expected static field of type " + this.type
/* 111 */           .jvmType());
/*     */     }
/*     */     
/* 114 */     PtrExpr address = null;
/* 115 */     if (readOnly) {
/* 116 */       fatPtrPair = new FatPtrPair(valueFunction(), Expressions.newArray(this.type.jvmType(), Collections.singletonList(expr)));
/*     */     }
/* 118 */     return this.type.fromStackValue(expr, (PtrExpr)fatPtrPair);
/*     */   }
/*     */ 
/*     */   
/*     */   public PrimitiveExpr constructorExpr(ExprFactory exprFactory, MethodGenerator mv, GimpleConstructor value) {
/* 123 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public PointerTypeStrategy pointerTo() {
/* 128 */     return (PointerTypeStrategy)new VPtrStrategy((GimpleType)this.type.gimpleType());
/*     */   }
/*     */ 
/*     */   
/*     */   public ArrayTypeStrategy arrayOf(GimpleArrayType arrayType) {
/* 133 */     return ArrayTypeStrategies.of(arrayType, valueFunction());
/*     */   }
/*     */ 
/*     */   
/*     */   public PrimitiveExpr cast(MethodGenerator mv, GExpr value) throws UnsupportedCastException {
/* 138 */     return value.toPrimitiveExpr();
/*     */   }
/*     */   
/*     */   public PrimitiveExpr zero() {
/* 142 */     return this.type.fromStackValue((JExpr)new ConstantValue(this.type.jvmType(), Integer.valueOf(0)));
/*     */   }
/*     */   
/*     */   private PrimitiveValueFunction valueFunction() {
/* 146 */     return new PrimitiveValueFunction(this.type);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 151 */     return "PrimitiveTypeStrategy[" + this.type + "]";
/*     */   }
/*     */   
/*     */   public Type getJvmType() {
/* 155 */     return this.type.jvmType();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/type/primitive/PrimitiveTypeStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */