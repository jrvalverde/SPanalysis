/*     */ package org.renjin.gcc.gimple.statement;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.function.Predicate;
/*     */ import org.renjin.gcc.gimple.GimpleExprVisitor;
/*     */ import org.renjin.gcc.gimple.GimpleVisitor;
/*     */ import org.renjin.gcc.gimple.expr.GimpleExpr;
/*     */ import org.renjin.repackaged.guava.base.Joiner;
/*     */ import org.renjin.repackaged.guava.base.Preconditions;
/*     */ import org.renjin.repackaged.guava.collect.Lists;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GimpleSwitch
/*     */   extends GimpleStatement
/*     */ {
/*     */   private GimpleExpr value;
/*     */   
/*     */   public static class Case
/*     */   {
/*     */     private int low;
/*     */     private int high;
/*     */     private int basicBlockIndex;
/*     */     
/*     */     public int getLow() {
/*  47 */       return this.low;
/*     */     }
/*     */     
/*     */     public void setLow(int low) {
/*  51 */       this.low = low;
/*     */     }
/*     */     
/*     */     public int getHigh() {
/*  55 */       return this.high;
/*     */     }
/*     */     
/*     */     public void setHigh(int high) {
/*  59 */       this.high = high;
/*     */     }
/*     */     
/*     */     public int getBasicBlockIndex() {
/*  63 */       return this.basicBlockIndex;
/*     */     }
/*     */     
/*     */     public void setBasicBlockIndex(int basicBlockIndex) {
/*  67 */       this.basicBlockIndex = basicBlockIndex;
/*     */     }
/*     */     
/*     */     public String toString() {
/*  71 */       StringBuilder s = new StringBuilder();
/*  72 */       s.append("case ");
/*  73 */       if (this.low == this.high) {
/*  74 */         s.append(this.low);
/*     */       } else {
/*  76 */         s.append(this.low).append("-").append(this.high);
/*     */       } 
/*  78 */       s.append(": goto ");
/*  79 */       s.append(this.basicBlockIndex);
/*  80 */       return s.toString();
/*     */     }
/*     */     
/*     */     public int getRange() {
/*  84 */       Preconditions.checkState((this.low <= this.high));
/*  85 */       return this.high - this.low + 1;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*  90 */   private List<Case> cases = Lists.newArrayList();
/*     */ 
/*     */   
/*     */   private Case defaultCase;
/*     */ 
/*     */   
/*     */   public List<Case> getCases() {
/*  97 */     return this.cases;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getCaseCount() {
/* 108 */     int count = 0;
/* 109 */     for (Case aCase : this.cases) {
/* 110 */       count += aCase.getRange();
/*     */     }
/* 112 */     return count;
/*     */   }
/*     */   
/*     */   public Case getDefaultCase() {
/* 116 */     return this.defaultCase;
/*     */   }
/*     */   
/*     */   public void setDefaultCase(Case defaultCase) {
/* 120 */     this.defaultCase = defaultCase;
/*     */   }
/*     */   
/*     */   public void setValue(GimpleExpr value) {
/* 124 */     this.value = value;
/*     */   }
/*     */   
/*     */   public List<GimpleExpr> getOperands() {
/* 128 */     return Collections.singletonList(this.value);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void findUses(Predicate<? super GimpleExpr> predicate, List<GimpleExpr> results) {
/* 133 */     this.value.findOrDescend(predicate, results);
/*     */   }
/*     */ 
/*     */   
/*     */   public void replaceAll(Predicate<? super GimpleExpr> predicate, GimpleExpr newExpr) {
/* 138 */     if (predicate.test(this.value)) {
/* 139 */       this.value = newExpr;
/*     */     } else {
/* 141 */       this.value.replaceAll(predicate, newExpr);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void accept(GimpleExprVisitor visitor) {
/* 147 */     this.value.accept(visitor);
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<Integer> getJumpTargets() {
/* 152 */     Set<Integer> targets = new HashSet<>();
/* 153 */     for (Case aCase : this.cases) {
/* 154 */       targets.add(Integer.valueOf(aCase.getBasicBlockIndex()));
/*     */     }
/* 156 */     if (this.defaultCase != null) {
/* 157 */       targets.add(Integer.valueOf(this.defaultCase.getBasicBlockIndex()));
/*     */     }
/* 159 */     return targets;
/*     */   }
/*     */   
/*     */   public GimpleExpr getValue() {
/* 163 */     return this.value;
/*     */   }
/*     */ 
/*     */   
/*     */   public void visit(GimpleVisitor visitor) {
/* 168 */     visitor.visitSwitch(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 173 */     StringBuilder sb = new StringBuilder();
/* 174 */     sb.append("switch(").append(this.value).append(") {");
/* 175 */     Joiner.on("\n").appendTo(sb, this.cases);
/* 176 */     if (this.defaultCase != null) {
/* 177 */       sb.append(String.format("\ndefault: goto %d", new Object[] { Integer.valueOf(Case.access$000(this.defaultCase)) }));
/*     */     }
/* 179 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/gimple/statement/GimpleSwitch.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */