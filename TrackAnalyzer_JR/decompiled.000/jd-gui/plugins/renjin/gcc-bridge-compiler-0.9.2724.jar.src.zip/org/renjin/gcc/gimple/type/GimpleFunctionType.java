/*    */ package org.renjin.gcc.gimple.type;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.Objects;
/*    */ import org.renjin.repackaged.guava.base.Joiner;
/*    */ import org.renjin.repackaged.guava.collect.Lists;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GimpleFunctionType
/*    */   extends AbstractGimpleType
/*    */ {
/*    */   private GimpleType returnType;
/* 29 */   private List<GimpleType> argumentTypes = Lists.newArrayList();
/*    */   private boolean variableArguments;
/*    */   
/*    */   public GimpleFunctionType() {
/* 33 */     this.returnType = new GimpleVoidType();
/*    */   }
/*    */   
/*    */   public GimpleType getReturnType() {
/* 37 */     return this.returnType;
/*    */   }
/*    */   
/*    */   public void setReturnType(GimpleType returnType) {
/* 41 */     this.returnType = returnType;
/*    */   }
/*    */   
/*    */   public List<GimpleType> getArgumentTypes() {
/* 45 */     return this.argumentTypes;
/*    */   }
/*    */   
/*    */   public boolean isVariableArguments() {
/* 49 */     return this.variableArguments;
/*    */   }
/*    */   
/*    */   public void setVariableArguments(boolean variableArguments) {
/* 53 */     this.variableArguments = variableArguments;
/*    */   }
/*    */ 
/*    */   
/*    */   public int sizeOf() {
/* 58 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 63 */     return this.returnType + " (*functionPtr)(" + Joiner.on(", ").join(this.argumentTypes) + ")";
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 68 */     if (this == o) {
/* 69 */       return true;
/*    */     }
/* 71 */     if (o == null || getClass() != o.getClass()) {
/* 72 */       return false;
/*    */     }
/*    */     
/* 75 */     GimpleFunctionType that = (GimpleFunctionType)o;
/* 76 */     return (Objects.equals(Boolean.valueOf(this.variableArguments), Boolean.valueOf(that.variableArguments)) && 
/* 77 */       Objects.equals(this.returnType, that.returnType) && 
/* 78 */       Objects.equals(this.argumentTypes, that.argumentTypes));
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 83 */     int result = (this.returnType != null) ? this.returnType.hashCode() : 0;
/* 84 */     result = 31 * result + ((this.argumentTypes != null) ? this.argumentTypes.hashCode() : 0);
/* 85 */     result = 31 * result + (this.variableArguments ? 1 : 0);
/* 86 */     return result;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/gimple/type/GimpleFunctionType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */