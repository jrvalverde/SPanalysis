/*     */ package org.renjin.gcc.codegen.fatptr;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.renjin.gcc.codegen.MethodGenerator;
/*     */ import org.renjin.gcc.codegen.expr.ConstantValue;
/*     */ import org.renjin.gcc.codegen.expr.Expressions;
/*     */ import org.renjin.gcc.codegen.expr.JExpr;
/*     */ import org.renjin.gcc.codegen.var.LocalVarAllocator;
/*     */ import org.renjin.repackaged.asm.Label;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ import org.renjin.repackaged.guava.collect.Lists;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FatPtrMalloc
/*     */ {
/*     */   private static final int MAX_UNROLL_COUNT = 5;
/*     */   
/*     */   public static FatPtrPair alloc(MethodGenerator mv, ValueFunction valueFunction, JExpr length) {
/*  42 */     return new FatPtrPair(valueFunction, allocArray(mv, valueFunction, length));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JExpr allocArray(MethodGenerator mv, ValueFunction valueFunction, JExpr length) {
/*  51 */     if (!valueFunction.getValueConstructor().isPresent()) {
/*  52 */       return Expressions.newArray(valueFunction.getValueType(), length);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  58 */     if (length instanceof ConstantValue) {
/*  59 */       ConstantValue constantLength = (ConstantValue)length;
/*     */       
/*  61 */       if (constantLength.getIntValue() <= 5) {
/*  62 */         List<JExpr> arrayValues = Lists.newArrayList();
/*  63 */         for (int i = 0; i < constantLength.getIntValue(); i++) {
/*  64 */           arrayValues.add(valueFunction.getValueConstructor().get());
/*     */         }
/*  66 */         return Expressions.newArray(valueFunction.getValueType(), arrayValues);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  73 */     Type arrayType = Wrappers.valueArrayType(valueFunction.getValueType());
/*  74 */     LocalVarAllocator.LocalVar array = mv.getLocalVarAllocator().reserve(arrayType);
/*  75 */     LocalVarAllocator.LocalVar counter = mv.getLocalVarAllocator().reserve(Type.INT_TYPE);
/*     */ 
/*     */ 
/*     */     
/*  79 */     length.load(mv);
/*  80 */     mv.newarray(valueFunction.getValueType());
/*  81 */     mv.store(array.getIndex(), arrayType);
/*     */ 
/*     */     
/*  84 */     mv.iconst(0);
/*  85 */     mv.store(counter.getIndex(), Type.INT_TYPE);
/*     */ 
/*     */     
/*  88 */     Label loopHead = new Label();
/*  89 */     Label loopCheck = new Label();
/*     */     
/*  91 */     mv.goTo(loopCheck);
/*     */ 
/*     */     
/*  94 */     mv.mark(loopHead);
/*  95 */     array.load(mv);
/*  96 */     counter.load(mv);
/*  97 */     ((JExpr)valueFunction.getValueConstructor().get()).load(mv);
/*  98 */     mv.astore(valueFunction.getValueType());
/*  99 */     mv.iinc(counter.getIndex(), 1);
/*     */ 
/*     */     
/* 102 */     mv.mark(loopCheck);
/* 103 */     mv.load(counter.getIndex(), Type.INT_TYPE);
/* 104 */     length.load(mv);
/* 105 */     mv.ificmplt(loopHead);
/*     */ 
/*     */     
/* 108 */     return (JExpr)array;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/fatptr/FatPtrMalloc.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */