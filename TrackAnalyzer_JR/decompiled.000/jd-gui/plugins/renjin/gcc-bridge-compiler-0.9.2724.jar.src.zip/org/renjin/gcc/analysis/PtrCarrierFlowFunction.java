/*     */ package org.renjin.gcc.analysis;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.renjin.gcc.gimple.GimpleOp;
/*     */ import org.renjin.gcc.gimple.expr.GimpleExpr;
/*     */ import org.renjin.gcc.gimple.expr.GimpleLValue;
/*     */ import org.renjin.gcc.gimple.expr.GimpleVariableRef;
/*     */ import org.renjin.gcc.gimple.statement.GimpleAssignment;
/*     */ import org.renjin.gcc.gimple.statement.GimpleStatement;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PtrCarrierFlowFunction
/*     */   implements FlowFunction<VarSet>
/*     */ {
/*     */   public VarSet initialState() {
/*  45 */     return new VarSet();
/*     */   }
/*     */ 
/*     */   
/*     */   public VarSet transfer(VarSet entryState, Iterable<GimpleStatement> basicBlock) {
/*  50 */     VarSet pointerCarriers = new VarSet(entryState);
/*  51 */     for (GimpleStatement statement : basicBlock) {
/*  52 */       if (statement instanceof GimpleAssignment) {
/*  53 */         GimpleAssignment assignment = (GimpleAssignment)statement;
/*  54 */         if (isLhsIntegerVariable(assignment)) {
/*  55 */           GimpleVariableRef lhs = (GimpleVariableRef)assignment.getLHS();
/*  56 */           if (isRhsPointer(assignment)) {
/*  57 */             pointerCarriers.add(lhs);
/*     */           }
/*  59 */           if (isRhsPointerCarryingIntegerOperation(pointerCarriers, assignment)) {
/*  60 */             pointerCarriers.add(lhs);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/*  66 */     return pointerCarriers;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isLhsIntegerVariable(GimpleAssignment assignment) {
/*  72 */     GimpleLValue lhs = assignment.getLHS();
/*  73 */     return (lhs instanceof GimpleVariableRef && lhs
/*     */       
/*  75 */       .getType() instanceof org.renjin.gcc.gimple.type.GimpleIntegerType);
/*     */   }
/*     */   
/*     */   private boolean isRhsPointer(GimpleAssignment assignment) {
/*  79 */     switch (assignment.getOperator()) {
/*     */       case POINTER_PLUS_EXPR:
/*  81 */         return true;
/*     */       case VAR_DECL:
/*     */       case PARM_DECL:
/*     */       case NOP_EXPR:
/*  85 */         return ((GimpleExpr)assignment.getOperands().get(0)).getType() instanceof org.renjin.gcc.gimple.type.GimplePointerType;
/*     */     } 
/*     */     
/*  88 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isRhsPointerCarryingIntegerOperation(VarSet pointerCarriers, GimpleAssignment assignment) {
/*  93 */     return (isOffsetManipulationOperation(assignment) && 
/*  94 */       isAnyOperandCarryingAPointer(pointerCarriers, assignment));
/*     */   }
/*     */   
/*     */   private boolean isAnyOperandCarryingAPointer(VarSet pointerCarriers, GimpleAssignment assignment) {
/*  98 */     for (GimpleExpr operand : assignment.getOperands()) {
/*  99 */       if (pointerCarriers.contains(operand)) {
/* 100 */         return true;
/*     */       }
/*     */     } 
/* 103 */     return false;
/*     */   }
/*     */   
/*     */   private boolean isOffsetManipulationOperation(GimpleAssignment assignment) {
/* 107 */     switch (assignment.getOperator()) {
/*     */ 
/*     */       
/*     */       case PLUS_EXPR:
/*     */       case MINUS_EXPR:
/* 112 */         return true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case BIT_IOR_EXPR:
/*     */       case BIT_AND_EXPR:
/*     */       case BIT_XOR_EXPR:
/* 123 */         return true;
/*     */     } 
/* 125 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public VarSet join(List<VarSet> inputs) {
/* 131 */     return VarSet.unionAll(inputs);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/analysis/PtrCarrierFlowFunction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */