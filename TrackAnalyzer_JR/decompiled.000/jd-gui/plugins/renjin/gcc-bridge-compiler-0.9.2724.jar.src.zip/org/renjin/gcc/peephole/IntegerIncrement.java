/*    */ package org.renjin.gcc.peephole;
/*    */ 
/*    */ import org.renjin.repackaged.asm.tree.AbstractInsnNode;
/*    */ import org.renjin.repackaged.asm.tree.IincInsnNode;
/*    */ import org.renjin.repackaged.asm.tree.VarInsnNode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IntegerIncrement
/*    */   implements PeepholeOptimization
/*    */ {
/*    */   public boolean apply(NodeIt it) {
/* 32 */     if (it.matches(new Pattern[] { Pattern.ILOAD, Pattern.ICONST, Pattern.IADD, Pattern.ISTORE })) {
/* 33 */       VarInsnNode load = it.<VarInsnNode>get(0);
/* 34 */       int increment = Instructions.getInteger(it.get(1));
/* 35 */       VarInsnNode store = it.<VarInsnNode>get(3);
/*    */       
/* 37 */       if (load.var == store.var) {
/* 38 */         it.remove(4);
/* 39 */         if (increment != 0) {
/* 40 */           it.insert(new AbstractInsnNode[] { (AbstractInsnNode)new IincInsnNode(load.var, increment) });
/*    */         }
/* 42 */         return true;
/*    */       } 
/*    */     } 
/* 45 */     return false;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/peephole/IntegerIncrement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */