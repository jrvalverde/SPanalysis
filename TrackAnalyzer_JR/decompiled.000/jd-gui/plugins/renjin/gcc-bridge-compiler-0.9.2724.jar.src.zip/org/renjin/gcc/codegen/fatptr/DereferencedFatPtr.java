/*     */ package org.renjin.gcc.codegen.fatptr;
/*     */ 
/*     */ import org.renjin.gcc.codegen.MethodGenerator;
/*     */ import org.renjin.gcc.codegen.array.FatArrayExpr;
/*     */ import org.renjin.gcc.codegen.condition.ConditionGenerator;
/*     */ import org.renjin.gcc.codegen.expr.ArrayElement;
/*     */ import org.renjin.gcc.codegen.expr.Expressions;
/*     */ import org.renjin.gcc.codegen.expr.GExpr;
/*     */ import org.renjin.gcc.codegen.expr.JExpr;
/*     */ import org.renjin.gcc.codegen.expr.PtrExpr;
/*     */ import org.renjin.gcc.codegen.expr.RefPtrExpr;
/*     */ import org.renjin.gcc.codegen.type.NumericExpr;
/*     */ import org.renjin.gcc.codegen.type.UnsupportedCastException;
/*     */ import org.renjin.gcc.codegen.type.fun.FunPtrExpr;
/*     */ import org.renjin.gcc.codegen.type.primitive.PrimitiveExpr;
/*     */ import org.renjin.gcc.codegen.type.record.ProvidedPtrExpr;
/*     */ import org.renjin.gcc.codegen.type.voidt.VoidPtrExpr;
/*     */ import org.renjin.gcc.codegen.vptr.VArrayExpr;
/*     */ import org.renjin.gcc.codegen.vptr.VPtrExpr;
/*     */ import org.renjin.gcc.codegen.vptr.VPtrRecordExpr;
/*     */ import org.renjin.gcc.gimple.GimpleOp;
/*     */ import org.renjin.gcc.gimple.type.GimpleArrayType;
/*     */ import org.renjin.gcc.gimple.type.GimpleRecordType;
/*     */ import org.renjin.gcc.gimple.type.GimpleType;
/*     */ import org.renjin.repackaged.asm.Label;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DereferencedFatPtr
/*     */   implements RefPtrExpr, FatPtr
/*     */ {
/*     */   private final ValueFunction valueFunction;
/*     */   private JExpr array;
/*     */   private JExpr offset;
/*     */   private Type wrapperType;
/*     */   
/*     */   public DereferencedFatPtr(JExpr array, JExpr offset, ValueFunction valueFunction) {
/*  49 */     this.array = array;
/*  50 */     this.offset = offset;
/*  51 */     this.valueFunction = valueFunction;
/*  52 */     this.wrapperType = Wrappers.wrapperType(valueFunction.getValueType());
/*     */   }
/*     */   
/*     */   private ArrayElement element() {
/*  56 */     return Expressions.elementAt(this.array, this.offset);
/*     */   }
/*     */   
/*     */   private JExpr castedElement() {
/*  60 */     return Expressions.cast((JExpr)element(), this.wrapperType);
/*     */   }
/*     */ 
/*     */   
/*     */   public JExpr jexpr() {
/*  65 */     return (JExpr)element();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void store(MethodGenerator mv, GExpr rhs) {
/*  71 */     if (rhs instanceof FatPtr) {
/*  72 */       element().store(mv, ((FatPtr)rhs).wrap());
/*     */     } else {
/*     */       
/*  75 */       throw new UnsupportedOperationException("TODO: " + rhs.getClass().getName());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public PtrExpr addressOf() {
/*  81 */     return new FatPtrPair(this.valueFunction, this.array, this.offset);
/*     */   }
/*     */ 
/*     */   
/*     */   public FunPtrExpr toFunPtr() throws UnsupportedCastException {
/*  86 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public FatArrayExpr toArrayExpr() throws UnsupportedCastException {
/*  91 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public PrimitiveExpr toPrimitiveExpr() throws UnsupportedCastException {
/*  96 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public VoidPtrExpr toVoidPtrExpr() throws UnsupportedCastException {
/* 101 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public VPtrExpr toVPtrExpr() throws UnsupportedCastException {
/* 106 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public ProvidedPtrExpr toProvidedPtrExpr(Type jvmType) {
/* 111 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public FatPtr toFatPtrExpr(ValueFunction valueFunction) {
/* 116 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public VPtrRecordExpr toVPtrRecord(GimpleRecordType recordType) {
/* 121 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public VArrayExpr toVArray(GimpleArrayType arrayType) {
/* 126 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public NumericExpr toNumericExpr() {
/* 131 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public Type getValueType() {
/* 136 */     return this.valueFunction.getValueType();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isAddressable() {
/* 141 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public JExpr wrap() {
/* 146 */     return (JExpr)element();
/*     */   }
/*     */ 
/*     */   
/*     */   public FatPtrPair toPair(MethodGenerator mv) {
/* 151 */     return Wrappers.toPair(mv, this.valueFunction, castedElement());
/*     */   }
/*     */ 
/*     */   
/*     */   public void jumpIfNull(MethodGenerator mv, Label label) {
/* 156 */     element().load(mv);
/* 157 */     mv.ifnull(label);
/*     */   }
/*     */ 
/*     */   
/*     */   public JExpr memoryCompare(MethodGenerator mv, PtrExpr otherPointer, JExpr n) {
/* 162 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void memorySet(MethodGenerator mv, JExpr byteValue, JExpr length) {
/* 167 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void memoryCopy(MethodGenerator mv, PtrExpr source, JExpr length, boolean buffer) {
/* 172 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public PtrExpr realloc(MethodGenerator mv, JExpr newSizeInBytes) {
/* 177 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public PtrExpr pointerPlus(MethodGenerator mv, JExpr offsetInBytes) {
/* 182 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public GExpr valueOf(GimpleType expectedType) {
/* 187 */     return this.valueFunction.dereference(this.array, this.offset);
/*     */   }
/*     */ 
/*     */   
/*     */   public ConditionGenerator comparePointer(MethodGenerator mv, GimpleOp op, GExpr otherPointer) {
/* 192 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/fatptr/DereferencedFatPtr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */