/*     */ package org.renjin.gcc.codegen.type.fun;
/*     */ 
/*     */ import java.lang.invoke.MethodHandle;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Optional;
/*     */ import org.renjin.gcc.codegen.MethodGenerator;
/*     */ import org.renjin.gcc.codegen.expr.Expressions;
/*     */ import org.renjin.gcc.codegen.expr.GExpr;
/*     */ import org.renjin.gcc.codegen.expr.JExpr;
/*     */ import org.renjin.gcc.codegen.fatptr.FatPtr;
/*     */ import org.renjin.gcc.codegen.fatptr.FatPtrPair;
/*     */ import org.renjin.gcc.codegen.fatptr.Memset;
/*     */ import org.renjin.gcc.codegen.fatptr.ValueFunction;
/*     */ import org.renjin.gcc.codegen.fatptr.WrappedFatPtrExpr;
/*     */ import org.renjin.gcc.codegen.vptr.VPtrExpr;
/*     */ import org.renjin.gcc.gimple.type.GimpleFunctionType;
/*     */ import org.renjin.gcc.gimple.type.GimpleType;
/*     */ import org.renjin.gcc.runtime.FunctionPtr;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FunPtrValueFunction
/*     */   implements ValueFunction
/*     */ {
/*     */   private final int pointerSize;
/*     */   
/*     */   public FunPtrValueFunction(int pointerSize) {
/*  50 */     this.pointerSize = pointerSize;
/*     */   }
/*     */ 
/*     */   
/*     */   public Type getValueType() {
/*  55 */     return Type.getType(MethodHandle.class);
/*     */   }
/*     */ 
/*     */   
/*     */   public GimpleType getGimpleValueType() {
/*  60 */     return (GimpleType)new GimpleFunctionType();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getElementLength() {
/*  65 */     return 1;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getArrayElementBytes() {
/*  70 */     return this.pointerSize;
/*     */   }
/*     */ 
/*     */   
/*     */   public GExpr dereference(JExpr array, JExpr offset) {
/*  75 */     JExpr ptr = Expressions.cast((JExpr)Expressions.elementAt(array, offset), Type.getType(MethodHandle.class));
/*  76 */     FatPtrPair address = new FatPtrPair(this, array, offset);
/*  77 */     return (GExpr)new FunPtrExpr(ptr, (FatPtr)address);
/*     */   }
/*     */ 
/*     */   
/*     */   public GExpr dereference(WrappedFatPtrExpr wrapperInstance) {
/*  82 */     return (GExpr)new FunPtrExpr((JExpr)wrapperInstance.valueExpr(), (FatPtr)wrapperInstance);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<JExpr> toArrayValues(GExpr expr) {
/*  87 */     return Collections.singletonList(((FunPtrExpr)expr).jexpr());
/*     */   }
/*     */ 
/*     */   
/*     */   public void memoryCopy(MethodGenerator mv, JExpr destinationArray, JExpr destinationOffset, JExpr sourceArray, JExpr sourceOffset, JExpr valueCount) {
/*  92 */     mv.arrayCopy(sourceArray, sourceOffset, destinationArray, destinationOffset, valueCount);
/*     */   }
/*     */ 
/*     */   
/*     */   public void memorySet(MethodGenerator mv, JExpr array, JExpr offset, JExpr byteValue, JExpr length) {
/*  97 */     Memset.zeroOutRefArray(mv, array, offset, length);
/*     */   }
/*     */ 
/*     */   
/*     */   public Optional<JExpr> getValueConstructor() {
/* 102 */     return Optional.empty();
/*     */   }
/*     */ 
/*     */   
/*     */   public VPtrExpr toVPtr(JExpr array, JExpr offset) {
/* 107 */     return new VPtrExpr(Expressions.newObject(Type.getType(FunctionPtr.class), new JExpr[] { array, offset }));
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 112 */     return "FunPtr";
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/type/fun/FunPtrValueFunction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */