/*    */ package org.renjin.gcc.codegen.type.complex;
/*    */ 
/*    */ import org.renjin.gcc.codegen.MethodGenerator;
/*    */ import org.renjin.gcc.codegen.condition.ConditionGenerator;
/*    */ import org.renjin.gcc.gimple.GimpleOp;
/*    */ import org.renjin.repackaged.asm.Label;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ComplexCmpGenerator
/*    */   implements ConditionGenerator
/*    */ {
/*    */   private GimpleOp op;
/*    */   private ComplexExpr x;
/*    */   private ComplexExpr y;
/*    */   private Type type;
/*    */   
/*    */   public ComplexCmpGenerator(GimpleOp op, ComplexExpr x, ComplexExpr y) {
/* 39 */     this.op = op;
/* 40 */     this.x = x;
/* 41 */     this.y = y;
/* 42 */     this.type = x.getComponentType();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void emitJump(MethodGenerator mv, Label trueLabel, Label falseLabel) {
/* 48 */     switch (this.op) {
/*    */       case EQ_EXPR:
/* 50 */         emitJumpIfEqual(mv, trueLabel, falseLabel);
/*    */         return;
/*    */       case NE_EXPR:
/* 53 */         emitJumpIfEqual(mv, falseLabel, trueLabel);
/*    */         return;
/*    */     } 
/* 56 */     throw new UnsupportedOperationException("Unsupported comparison " + this.op + " between complex values");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private void emitJumpIfEqual(MethodGenerator mv, Label equalLabel, Label notEqualLabel) {
/* 63 */     this.x.getRealJExpr().load(mv);
/* 64 */     this.y.getRealJExpr().load(mv);
/*    */ 
/*    */ 
/*    */     
/* 68 */     mv.cmpg(this.type);
/*    */ 
/*    */ 
/*    */     
/* 72 */     mv.ifne(notEqualLabel);
/*    */ 
/*    */     
/* 75 */     this.x.getImaginaryJExpr().load(mv);
/* 76 */     this.y.getImaginaryJExpr().load(mv);
/*    */ 
/*    */ 
/*    */     
/* 80 */     mv.cmpg(this.type);
/*    */ 
/*    */ 
/*    */     
/* 84 */     mv.ifne(notEqualLabel);
/*    */ 
/*    */     
/* 87 */     mv.goTo(equalLabel);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/type/complex/ComplexCmpGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */