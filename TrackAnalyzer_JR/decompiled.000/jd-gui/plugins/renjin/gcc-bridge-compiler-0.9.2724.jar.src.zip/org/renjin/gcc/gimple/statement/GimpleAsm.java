/*    */ package org.renjin.gcc.gimple.statement;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
/*    */ import org.renjin.gcc.gimple.GimpleExprVisitor;
/*    */ import org.renjin.gcc.gimple.GimpleVisitor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @JsonIgnoreProperties(ignoreUnknown = true)
/*    */ public class GimpleAsm
/*    */   extends GimpleStatement
/*    */ {
/*    */   public void visit(GimpleVisitor visitor) {
/* 29 */     visitor.visitAsm(this);
/*    */   }
/*    */   
/*    */   public void accept(GimpleExprVisitor visitor) {}
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/gimple/statement/GimpleAsm.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */