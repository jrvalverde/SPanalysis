/*    */ package org.renjin.gcc.peephole;
/*    */ 
/*    */ import org.renjin.repackaged.asm.tree.JumpInsnNode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ZeroComparison
/*    */   implements PeepholeOptimization
/*    */ {
/*    */   public boolean apply(NodeIt it) {
/* 31 */     if (it.matches(new Pattern[] { Pattern.ZERO, Pattern.INT_COMPARISON })) {
/*    */ 
/*    */       
/* 34 */       it.remove(1);
/*    */ 
/*    */       
/* 37 */       JumpInsnNode jumpNode = it.<JumpInsnNode>get(1);
/* 38 */       switch (jumpNode.getOpcode()) {
/*    */         case 159:
/* 40 */           jumpNode.setOpcode(153);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */           
/* 66 */           return true;case 160: jumpNode.setOpcode(154); return true;case 161: jumpNode.setOpcode(155); return true;case 162: jumpNode.setOpcode(156); return true;case 163: jumpNode.setOpcode(157); return true;case 164: jumpNode.setOpcode(158); return true;
/*    */       }  throw new IllegalStateException("opcode: " + jumpNode.getOpcode());
/*    */     } 
/* 69 */     return false;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/peephole/ZeroComparison.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */