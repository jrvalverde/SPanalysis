/*    */ package org.renjin.gcc.peephole;
/*    */ 
/*    */ import org.renjin.repackaged.asm.tree.AbstractInsnNode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConstantMath
/*    */   implements PeepholeOptimization
/*    */ {
/*    */   public boolean apply(NodeIt it) {
/* 32 */     if (it.matches(new Pattern[] { Pattern.ICONST, Pattern.ICONST, Pattern.I_ARITHMETIC })) {
/*    */       
/* 34 */       int x = Instructions.getInteger(it.get(0));
/* 35 */       int y = Instructions.getInteger(it.get(1));
/* 36 */       int op = it.<AbstractInsnNode>get(2).getOpcode();
/*    */       
/* 38 */       it.remove(3);
/* 39 */       it.insert(new AbstractInsnNode[] { Instructions.constantNode(compute(op, x, y)) });
/* 40 */       return true;
/*    */     } 
/* 42 */     return false;
/*    */   }
/*    */   
/*    */   private int compute(int op, int x, int y) {
/* 46 */     switch (op) {
/*    */       case 96:
/* 48 */         return x + y;
/*    */       case 100:
/* 50 */         return x - y;
/*    */       case 108:
/* 52 */         return x / y;
/*    */       case 104:
/* 54 */         return x * y;
/*    */     } 
/* 56 */     throw new IllegalArgumentException("opcode: " + op);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/peephole/ConstantMath.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */