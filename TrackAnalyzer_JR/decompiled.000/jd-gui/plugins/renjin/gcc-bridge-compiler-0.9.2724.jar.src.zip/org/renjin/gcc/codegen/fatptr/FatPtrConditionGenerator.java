/*     */ package org.renjin.gcc.codegen.fatptr;
/*     */ 
/*     */ import org.renjin.gcc.codegen.MethodGenerator;
/*     */ import org.renjin.gcc.codegen.condition.ConditionGenerator;
/*     */ import org.renjin.gcc.gimple.GimpleOp;
/*     */ import org.renjin.repackaged.asm.Label;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FatPtrConditionGenerator
/*     */   implements ConditionGenerator
/*     */ {
/*     */   private GimpleOp op;
/*     */   private FatPtrPair x;
/*     */   private FatPtrPair y;
/*     */   
/*     */   public FatPtrConditionGenerator(GimpleOp op, FatPtrPair x, FatPtrPair y) {
/*  35 */     this.op = op;
/*  36 */     this.x = x;
/*  37 */     this.y = y;
/*     */   }
/*     */ 
/*     */   
/*     */   public void emitJump(MethodGenerator mv, Label trueLabel, Label falseLabel) {
/*  42 */     switch (this.op) {
/*     */       case EQ_EXPR:
/*  44 */         jumpOnEqual(mv, trueLabel, falseLabel);
/*     */         return;
/*     */       case NE_EXPR:
/*  47 */         jumpOnEqual(mv, falseLabel, trueLabel);
/*     */         return;
/*     */     } 
/*  50 */     jumpOnComparison(mv, trueLabel, falseLabel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void jumpOnEqual(MethodGenerator mv, Label equalLabel, Label notEqualLabel) {
/*  59 */     this.x.getArray().load(mv);
/*  60 */     this.y.getArray().load(mv);
/*  61 */     mv.ifacmpne(notEqualLabel);
/*     */ 
/*     */ 
/*     */     
/*  65 */     this.x.getOffset().load(mv);
/*  66 */     this.y.getOffset().load(mv);
/*  67 */     mv.ificmpne(notEqualLabel);
/*     */ 
/*     */     
/*  70 */     mv.goTo(equalLabel);
/*     */   }
/*     */ 
/*     */   
/*     */   private void jumpOnComparison(MethodGenerator mv, Label trueLabel, Label falseLabel) {
/*  75 */     Label arraysEqual = new Label();
/*     */ 
/*     */ 
/*     */     
/*  79 */     this.x.getArray().load(mv);
/*  80 */     this.y.getArray().load(mv);
/*  81 */     mv.ifacmpeq(arraysEqual);
/*     */ 
/*     */     
/*  84 */     this.x.getArray().load(mv);
/*  85 */     mv.invokeIdentityHashCode();
/*  86 */     this.y.getArray().load(mv);
/*  87 */     mv.invokeIdentityHashCode();
/*  88 */     switch (this.op) {
/*     */       case LT_EXPR:
/*     */       case LE_EXPR:
/*  91 */         mv.ificmplt(trueLabel);
/*     */         break;
/*     */       case GT_EXPR:
/*     */       case GE_EXPR:
/*  95 */         mv.ificmpgt(trueLabel);
/*     */         break;
/*     */       default:
/*  98 */         throw new UnsupportedOperationException("op: " + this.op);
/*     */     } 
/* 100 */     mv.goTo(falseLabel);
/*     */ 
/*     */     
/* 103 */     mv.mark(arraysEqual);
/* 104 */     this.x.getOffset().load(mv);
/* 105 */     this.y.getOffset().load(mv);
/*     */     
/* 107 */     switch (this.op) {
/*     */       case LT_EXPR:
/* 109 */         mv.ificmplt(trueLabel);
/*     */         break;
/*     */       case LE_EXPR:
/* 112 */         mv.ificmple(trueLabel);
/*     */         break;
/*     */       case GT_EXPR:
/* 115 */         mv.ificmpgt(trueLabel);
/*     */         break;
/*     */       case GE_EXPR:
/* 118 */         mv.ificmpge(trueLabel);
/*     */         break;
/*     */       
/*     */       default:
/* 122 */         throw new UnsupportedOperationException("op: " + this.op);
/*     */     } 
/*     */     
/* 125 */     mv.goTo(falseLabel);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/fatptr/FatPtrConditionGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */