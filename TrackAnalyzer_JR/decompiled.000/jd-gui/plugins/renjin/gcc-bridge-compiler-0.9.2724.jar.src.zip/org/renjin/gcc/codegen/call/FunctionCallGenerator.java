/*     */ package org.renjin.gcc.codegen.call;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Optional;
/*     */ import javax.annotation.Nonnull;
/*     */ import org.renjin.gcc.codegen.MethodGenerator;
/*     */ import org.renjin.gcc.codegen.expr.ExprFactory;
/*     */ import org.renjin.gcc.codegen.expr.GExpr;
/*     */ import org.renjin.gcc.codegen.expr.JExpr;
/*     */ import org.renjin.gcc.codegen.type.ParamStrategy;
/*     */ import org.renjin.gcc.codegen.type.TypeStrategy;
/*     */ import org.renjin.gcc.codegen.type.fun.FunctionRefGenerator;
/*     */ import org.renjin.gcc.gimple.expr.GimpleExpr;
/*     */ import org.renjin.gcc.gimple.statement.GimpleCall;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ import org.renjin.repackaged.guava.collect.Lists;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FunctionCallGenerator
/*     */   implements CallGenerator, MethodHandleGenerator
/*     */ {
/*     */   private final InvocationStrategy strategy;
/*     */   
/*     */   public FunctionCallGenerator(InvocationStrategy invocationStrategy) {
/*  46 */     this.strategy = invocationStrategy;
/*     */   }
/*     */   
/*     */   public InvocationStrategy getStrategy() {
/*  50 */     return this.strategy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void emitCall(MethodGenerator mv, ExprFactory exprFactory, GimpleCall call) {
/*  59 */     int fixedArgCount = this.strategy.getParamStrategies().size();
/*     */ 
/*     */     
/*  62 */     List<GExpr> argumentExpressions = Lists.newArrayList();
/*  63 */     for (int i = 0; i < fixedArgCount; i++) {
/*  64 */       if (i < call.getOperands().size()) {
/*  65 */         argumentExpressions.add(exprFactory.findGenerator(call.getOperand(i)));
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  71 */     List<GimpleExpr> additionalArgs = extraArguments(call, fixedArgCount);
/*  72 */     List<JExpr> varArgsExprs = this.strategy.getVariadicStrategy().marshallVarArgs(mv, exprFactory, additionalArgs);
/*     */ 
/*     */     
/*  75 */     CallExpr callExpr = new CallExpr(argumentExpressions, varArgsExprs);
/*     */ 
/*     */     
/*  78 */     if (call.getLhs() == null) {
/*  79 */       callExpr.load(mv);
/*  80 */       mv.pop(callExpr.getType());
/*     */     }
/*     */     else {
/*     */       
/*  84 */       GExpr lhs = exprFactory.findGenerator((GimpleExpr)call.getLhs());
/*  85 */       TypeStrategy lhsTypeStrategy = exprFactory.strategyFor(call.getLhs().getType());
/*  86 */       GExpr rhs = this.strategy.getReturnStrategy().unmarshall(mv, callExpr, lhsTypeStrategy);
/*     */       
/*  88 */       lhs.store(mv, rhs);
/*     */     } 
/*     */   }
/*     */   
/*     */   private List<GimpleExpr> extraArguments(GimpleCall call, int fixedArgCount) {
/*  93 */     if (call.getOperands().size() <= fixedArgCount) {
/*  94 */       return Collections.emptyList();
/*     */     }
/*  96 */     return call.getOperands().subList(fixedArgCount, call.getOperands().size());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JExpr getMethodHandle() {
/* 103 */     return (JExpr)new FunctionRefGenerator(this.strategy.getMethodHandle());
/*     */   }
/*     */   
/*     */   private class CallExpr
/*     */     implements JExpr {
/*     */     private List<GExpr> arguments;
/*     */     private List<JExpr> varArgs;
/*     */     
/*     */     public CallExpr(List<GExpr> arguments, List<JExpr> varArgs) {
/* 112 */       this.arguments = arguments;
/* 113 */       this.varArgs = varArgs;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nonnull
/*     */     public Type getType() {
/* 119 */       return FunctionCallGenerator.this.strategy.getReturnStrategy().getType();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void load(@Nonnull MethodGenerator mv) {
/* 125 */       List<ParamStrategy> paramStrategies = FunctionCallGenerator.this.strategy.getParamStrategies();
/* 126 */       for (int i = 0; i < paramStrategies.size(); i++) {
/* 127 */         ParamStrategy paramStrategy = paramStrategies.get(i);
/* 128 */         if (i < this.arguments.size()) {
/* 129 */           paramStrategy.loadParameter(mv, Optional.of(this.arguments.get(i)));
/*     */         } else {
/* 131 */           paramStrategy.loadParameter(mv, Optional.empty());
/*     */         } 
/*     */       } 
/* 134 */       for (JExpr varArg : this.varArgs) {
/* 135 */         varArg.load(mv);
/*     */       }
/*     */ 
/*     */       
/* 139 */       FunctionCallGenerator.this.strategy.invoke(mv);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/call/FunctionCallGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */