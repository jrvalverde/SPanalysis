/*    */ package org.renjin.gcc.peephole;
/*    */ 
/*    */ import org.renjin.gcc.runtime.Ptr;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ import org.renjin.repackaged.asm.tree.AbstractInsnNode;
/*    */ import org.renjin.repackaged.asm.tree.MethodInsnNode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PointerAccess
/*    */   implements PeepholeOptimization
/*    */ {
/*    */   public boolean apply(NodeIt it) {
/* 32 */     if (it.matches(new Pattern[] { Pattern.ZERO, Pattern.POINTER_ACCESS_AT })) {
/* 33 */       MethodInsnNode accessNode = it.<MethodInsnNode>get(1);
/* 34 */       Type accessType = Type.getReturnType(accessNode.desc);
/*    */       
/* 36 */       it.remove(2);
/* 37 */       it.insert(new AbstractInsnNode[] { (AbstractInsnNode)new MethodInsnNode(185, 
/* 38 */               Type.getInternalName(Ptr.class), accessNode.name, 
/*    */               
/* 40 */               Type.getMethodDescriptor(accessType, new Type[0]), true) });
/*    */       
/* 42 */       return true;
/*    */     } 
/*    */     
/* 45 */     if (it.matches(new Pattern[] { Pattern.EIGHT, Pattern.IMUL, Pattern.POINTER_ACCESS_AT })) {
/* 46 */       MethodInsnNode accessNode = it.<MethodInsnNode>get(2);
/* 47 */       if (accessNode.name.equals("getDouble")) {
/* 48 */         it.remove(3);
/* 49 */         it.insert(new AbstractInsnNode[] { (AbstractInsnNode)new MethodInsnNode(185, 
/* 50 */                 Type.getInternalName(Ptr.class), "getAlignedDouble", 
/*    */                 
/* 52 */                 Type.getMethodDescriptor(Type.DOUBLE_TYPE, new Type[] { Type.INT_TYPE }), true) });
/*    */       } 
/*    */     } 
/*    */ 
/*    */     
/* 57 */     return false;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/peephole/PointerAccess.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */