package org.renjin.gcc.codegen.type;

import org.renjin.gcc.codegen.expr.GExpr;
import org.renjin.gcc.codegen.type.complex.ComplexExpr;
import org.renjin.gcc.codegen.type.primitive.RealExpr;

public interface NumericExpr extends GExpr {
  NumericExpr plus(GExpr paramGExpr);
  
  NumericExpr minus(GExpr paramGExpr);
  
  NumericExpr multiply(GExpr paramGExpr);
  
  NumericExpr divide(GExpr paramGExpr);
  
  NumericExpr remainder(GExpr paramGExpr);
  
  NumericExpr negative();
  
  NumericExpr min(GExpr paramGExpr);
  
  NumericExpr max(GExpr paramGExpr);
  
  NumericExpr absoluteValue();
  
  ComplexExpr toComplexExpr();
  
  RealExpr toRealExpr();
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/type/NumericExpr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */