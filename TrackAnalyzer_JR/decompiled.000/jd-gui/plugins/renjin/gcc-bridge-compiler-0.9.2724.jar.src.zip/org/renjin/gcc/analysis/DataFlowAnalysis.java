/*     */ package org.renjin.gcc.analysis;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.renjin.gcc.gimple.GimpleBasicBlock;
/*     */ import org.renjin.gcc.gimple.statement.GimpleStatement;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataFlowAnalysis<T>
/*     */ {
/*     */   private ControlFlowGraph cfg;
/*     */   private FlowFunction<T> flowFunction;
/*     */   private Map<ControlFlowGraph.Node, T> entryState;
/*     */   private Map<ControlFlowGraph.Node, T> exitState;
/*     */   
/*     */   public DataFlowAnalysis(ControlFlowGraph cfg, FlowFunction<T> flowFunction) {
/*     */     boolean changed;
/*  34 */     this.entryState = new HashMap<>();
/*  35 */     this.exitState = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  41 */     this.cfg = cfg;
/*  42 */     this.flowFunction = flowFunction;
/*     */ 
/*     */     
/*  45 */     T initialState = flowFunction.initialState();
/*     */     
/*  47 */     for (ControlFlowGraph.Node node : cfg.getNodes()) {
/*  48 */       this.entryState.put(node, initialState);
/*  49 */       this.exitState.put(node, flowFunction.transfer(initialState, node.getStatements()));
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*     */     do {
/*  55 */       changed = false;
/*     */       
/*  57 */       for (ControlFlowGraph.Node node : cfg.getBasicBlockNodes()) {
/*     */         
/*  59 */         T currentEntryState = this.entryState.get(node);
/*  60 */         T updatedEntryState = applyJoin(node);
/*     */         
/*  62 */         if (!updatedEntryState.equals(currentEntryState)) {
/*  63 */           this.entryState.put(node, updatedEntryState);
/*     */           
/*  65 */           T currentExitState = this.exitState.get(node);
/*  66 */           T updatedExitState = flowFunction.transfer(updatedEntryState, node.getBasicBlock().getStatements());
/*  67 */           if (!currentExitState.equals(updatedExitState)) {
/*  68 */             changed = true;
/*  69 */             this.exitState.put(node, updatedExitState);
/*     */           } 
/*     */         } 
/*     */       } 
/*  73 */     } while (changed);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private T applyJoin(ControlFlowGraph.Node node) {
/*  81 */     List<T> inputs = new ArrayList<>();
/*  82 */     for (ControlFlowGraph.Node incoming : node.getIncoming()) {
/*  83 */       inputs.add(this.exitState.get(incoming));
/*     */     }
/*     */     
/*  86 */     return this.flowFunction.join(inputs);
/*     */   }
/*     */   
/*     */   public T getEntryState(ControlFlowGraph.Node node) {
/*  90 */     T state = this.entryState.get(node);
/*  91 */     if (state == null) {
/*  92 */       throw new IllegalArgumentException("Node: " + node);
/*     */     }
/*  94 */     return state;
/*     */   }
/*     */   
/*     */   public Iterable<T> getExitStates() {
/*  98 */     return this.exitState.values();
/*     */   }
/*     */   
/*     */   public T getState(GimpleBasicBlock block, GimpleStatement statement) {
/* 102 */     T entryState = getEntryState(this.cfg.getNode(block));
/* 103 */     int statementIndex = block.getStatements().indexOf(statement);
/*     */     
/* 105 */     if (statementIndex == -1) {
/* 106 */       throw new IllegalArgumentException("Statement does not belong to basic block");
/*     */     }
/*     */     
/* 109 */     return this.flowFunction.transfer(entryState, block.getStatements().subList(0, statementIndex));
/*     */   }
/*     */   
/*     */   public void dump() {
/* 113 */     for (ControlFlowGraph.Node node : this.cfg.getBasicBlockNodes())
/* 114 */       System.out.println(node.getId() + ": " + this.entryState
/* 115 */           .get(node) + " -> " + this.exitState
/* 116 */           .get(node)); 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/analysis/DataFlowAnalysis.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */