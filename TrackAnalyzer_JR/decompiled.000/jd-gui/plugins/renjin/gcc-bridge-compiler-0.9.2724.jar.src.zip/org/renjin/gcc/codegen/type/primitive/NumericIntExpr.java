package org.renjin.gcc.codegen.type.primitive;

import org.renjin.gcc.codegen.expr.GExpr;
import org.renjin.gcc.codegen.type.NumericExpr;

public interface NumericIntExpr extends IntExpr, NumericExpr {
  NumericIntExpr plus(GExpr paramGExpr);
  
  NumericIntExpr minus(GExpr paramGExpr);
  
  NumericIntExpr multiply(GExpr paramGExpr);
  
  NumericIntExpr absoluteValue();
  
  NumericIntExpr bitwiseXor(GExpr paramGExpr);
  
  NumericIntExpr bitwiseNot();
  
  NumericIntExpr bitwiseAnd(GExpr paramGExpr);
  
  NumericIntExpr bitwiseOr(GExpr paramGExpr);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/type/primitive/NumericIntExpr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */