/*     */ package org.renjin.gcc.codegen.type.record;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Optional;
/*     */ import org.renjin.gcc.codegen.MethodGenerator;
/*     */ import org.renjin.gcc.codegen.expr.ArrayElement;
/*     */ import org.renjin.gcc.codegen.expr.Expressions;
/*     */ import org.renjin.gcc.codegen.expr.GExpr;
/*     */ import org.renjin.gcc.codegen.expr.JExpr;
/*     */ import org.renjin.gcc.codegen.fatptr.FatPtr;
/*     */ import org.renjin.gcc.codegen.fatptr.FatPtrPair;
/*     */ import org.renjin.gcc.codegen.fatptr.Memset;
/*     */ import org.renjin.gcc.codegen.fatptr.ValueFunction;
/*     */ import org.renjin.gcc.codegen.fatptr.WrappedFatPtrExpr;
/*     */ import org.renjin.gcc.codegen.vptr.VPtrExpr;
/*     */ import org.renjin.gcc.gimple.type.GimpleRecordType;
/*     */ import org.renjin.gcc.gimple.type.GimpleType;
/*     */ import org.renjin.gcc.runtime.RecordUnitPtrPtr;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProvidedPtrValueFunction
/*     */   implements ValueFunction
/*     */ {
/*     */   private GimpleRecordType gimpleType;
/*     */   private Type jvmType;
/*     */   
/*     */   public ProvidedPtrValueFunction(ProvidedTypeStrategy strategy) {
/*  46 */     this.gimpleType = strategy.getGimpleType();
/*  47 */     this.jvmType = strategy.getJvmType();
/*     */   }
/*     */ 
/*     */   
/*     */   public Type getValueType() {
/*  52 */     return this.jvmType;
/*     */   }
/*     */ 
/*     */   
/*     */   public GimpleType getGimpleValueType() {
/*  57 */     return (GimpleType)this.gimpleType;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getElementLength() {
/*  62 */     return 1;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getArrayElementBytes() {
/*  67 */     return 4;
/*     */   }
/*     */ 
/*     */   
/*     */   public Optional<JExpr> getValueConstructor() {
/*  72 */     return Optional.empty();
/*     */   }
/*     */ 
/*     */   
/*     */   public VPtrExpr toVPtr(JExpr array, JExpr offset) {
/*  77 */     return new VPtrExpr(Expressions.newObject(Type.getType(RecordUnitPtrPtr.class), 
/*  78 */           Type.getMethodDescriptor(Type.VOID_TYPE, new Type[] { Type.getType(Object[].class), Type.INT_TYPE }), new JExpr[] { array, offset }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GExpr dereference(JExpr array, JExpr offset) {
/*  85 */     ArrayElement arrayElement = Expressions.elementAt(array, offset);
/*  86 */     JExpr castedPointerValue = Expressions.cast((JExpr)arrayElement, this.jvmType);
/*  87 */     FatPtrPair pointerAddress = new FatPtrPair(this, array, offset);
/*     */     
/*  89 */     return (GExpr)new ProvidedPtrExpr(castedPointerValue, (FatPtr)pointerAddress);
/*     */   }
/*     */ 
/*     */   
/*     */   public GExpr dereference(WrappedFatPtrExpr wrapperInstance) {
/*  94 */     return (GExpr)new ProvidedPtrExpr((JExpr)wrapperInstance.valueExpr(), (FatPtr)wrapperInstance);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<JExpr> toArrayValues(GExpr expr) {
/*  99 */     return Collections.singletonList((JExpr)expr);
/*     */   }
/*     */ 
/*     */   
/*     */   public void memoryCopy(MethodGenerator mv, JExpr destinationArray, JExpr destinationOffset, JExpr sourceArray, JExpr sourceOffset, JExpr valueCount) {
/* 104 */     mv.arrayCopy(sourceArray, sourceOffset, destinationArray, destinationOffset, valueCount);
/*     */   }
/*     */ 
/*     */   
/*     */   public void memorySet(MethodGenerator mv, JExpr array, JExpr offset, JExpr byteValue, JExpr length) {
/* 109 */     Memset.zeroOutRefArray(mv, array, offset, length);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 114 */     return "RecordUnitPtr[" + this.jvmType + "]";
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/type/record/ProvidedPtrValueFunction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */