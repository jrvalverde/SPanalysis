/*     */ package org.renjin.gcc.gimple.statement;
/*     */ 
/*     */ import org.renjin.gcc.gimple.GimpleLabel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GimpleEdge
/*     */ {
/*     */   public static final int EDGE_FALLTHRU = 1;
/*     */   public static final int EDGE_ABNORMAL = 2;
/*     */   public static final int EDGE_ABNORMAL_CALL = 4;
/*     */   public static final int EDGE_EH = 8;
/*     */   public static final int EDGE_FAKE = 16;
/*     */   public static final int EDGE_DFS_BACK = 32;
/*     */   public static final int EDGE_CAN_FALLTHRU = 64;
/*     */   public static final int EDGE_IRREDUCIBLE_LOOP = 128;
/*     */   public static final int EDGE_SIBCALL = 256;
/*     */   public static final int EDGE_LOOP_EXIT = 512;
/*     */   public static final int EDGE_TRUE_VALUE = 1024;
/*     */   public static final int EDGE_FALSE_VALUE = 2048;
/*     */   public static final int EDGE_EXECUTABLE = 4096;
/*     */   public static final int EDGE_CROSSING = 8192;
/*     */   public static final int EDGE_ALL_FLAGS = 16383;
/*     */   public static final int EDGE_COMPLEX = 14;
/*     */   private int flags;
/*     */   private int source;
/*     */   private int target;
/*     */   
/*     */   public int getFlags() {
/*  47 */     return this.flags;
/*     */   }
/*     */   public void setFlags(int flags) {
/*  50 */     this.flags = flags;
/*     */   }
/*     */   public int getSource() {
/*  53 */     return this.source;
/*     */   }
/*     */   public void setSource(int source) {
/*  56 */     this.source = source;
/*     */   }
/*     */   public int getTarget() {
/*  59 */     return this.target;
/*     */   }
/*     */   public void setTarget(int target) {
/*  62 */     this.target = target;
/*     */   }
/*     */   
/*     */   public GimpleLabel getSourceLabel() {
/*  66 */     return new GimpleLabel("bb" + this.source);
/*     */   }
/*     */   
/*     */   public GimpleLabel getTargetLabel() {
/*  70 */     return new GimpleLabel("bb" + this.target);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  75 */     return "edge <" + getEdgeTypeName() + ">(" + getSourceLabel() + "," + getTargetLabel() + ")";
/*     */   }
/*     */   
/*     */   public boolean isFake() {
/*  79 */     return ((this.flags & 0x10) != 0);
/*     */   }
/*     */   
/*     */   public boolean isExceptionThrow() {
/*  83 */     return ((this.flags & 0x8) != 0);
/*     */   }
/*     */   
/*     */   private String getEdgeTypeName() {
/*  87 */     StringBuilder sb = new StringBuilder();
/*  88 */     String[] names = { "EDGE_FALLTHRU", "EDGE_ABNORMAL", "EDGE_ABNORMAL_CALL", "EDGE_EH", "EDGE_FAKE", "EDGE_DFS_BACK", "EDGE_CAN_FALLTHRU", "EDGE_IRREDUCIBLE_LOOP", "EDGE_SIBCALL", "EDGE_LOOP_EXIT", "EDGE_TRUE_VALUE", "EDGE_FALSE_VALUE", "EDGE_EXECUTABLE", "EDGE_CROSSING" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 104 */     boolean needsComma = false;
/* 105 */     for (int i = 0; i < 15; i++) {
/* 106 */       if ((this.flags & 1 << i) != 0) {
/* 107 */         if (needsComma) {
/* 108 */           sb.append(",");
/*     */         } else {
/* 110 */           needsComma = true;
/*     */         } 
/* 112 */         sb.append(names[i]);
/*     */       } 
/*     */     } 
/* 115 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/gimple/statement/GimpleEdge.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */