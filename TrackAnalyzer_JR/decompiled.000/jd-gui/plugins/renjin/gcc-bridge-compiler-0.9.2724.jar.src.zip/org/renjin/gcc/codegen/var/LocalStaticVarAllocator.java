/*    */ package org.renjin.gcc.codegen.var;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.renjin.gcc.codegen.expr.JExpr;
/*    */ import org.renjin.gcc.codegen.expr.JLValue;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LocalStaticVarAllocator
/*    */   extends VarAllocator
/*    */ {
/*    */   private String prefix;
/*    */   private GlobalVarAllocator globalVarAllocator;
/* 33 */   private Map<String, Integer> nextIndex = new HashMap<>();
/*    */   
/*    */   public LocalStaticVarAllocator(String prefix, GlobalVarAllocator globalVarAllocator) {
/* 36 */     this.prefix = prefix;
/* 37 */     this.globalVarAllocator = globalVarAllocator;
/*    */   }
/*    */ 
/*    */   
/*    */   public JLValue reserve(String name, Type type) {
/* 42 */     return this.globalVarAllocator.reserve(uniqueName(name), type);
/*    */   }
/*    */ 
/*    */   
/*    */   public JLValue reserve(String name, Type type, JExpr initialValue) {
/* 47 */     return this.globalVarAllocator.reserve(uniqueName(name), type, initialValue);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   private String uniqueName(String name) {
/* 53 */     String fieldName = this.prefix + name;
/* 54 */     Integer index = this.nextIndex.get(fieldName);
/* 55 */     if (index == null) {
/*    */       
/* 57 */       this.nextIndex.put(fieldName, Integer.valueOf(2));
/* 58 */       return fieldName;
/*    */     } 
/*    */     
/* 61 */     this.nextIndex.put(fieldName, Integer.valueOf(index.intValue() + 1));
/* 62 */     return fieldName + "$" + index;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/var/LocalStaticVarAllocator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */