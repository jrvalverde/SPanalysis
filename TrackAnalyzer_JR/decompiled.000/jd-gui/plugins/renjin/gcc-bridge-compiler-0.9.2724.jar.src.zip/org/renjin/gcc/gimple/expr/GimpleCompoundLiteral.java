/*    */ package org.renjin.gcc.gimple.expr;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.function.Predicate;
/*    */ import org.renjin.gcc.gimple.GimpleExprVisitor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GimpleCompoundLiteral
/*    */   extends GimpleLValue
/*    */ {
/*    */   private GimpleVariableRef decl;
/*    */   
/*    */   public GimpleVariableRef getDecl() {
/* 44 */     return this.decl;
/*    */   }
/*    */   
/*    */   public void setDecl(GimpleVariableRef decl) {
/* 48 */     this.decl = decl;
/*    */   }
/*    */ 
/*    */   
/*    */   public void find(Predicate<? super GimpleExpr> predicate, List<GimpleExpr> results) {
/* 53 */     this.decl.find(predicate, results);
/*    */   }
/*    */ 
/*    */   
/*    */   public void replaceAll(Predicate<? super GimpleExpr> predicate, GimpleExpr newExpr) {
/* 58 */     this.decl = (GimpleVariableRef)replaceOrDescend(this.decl, predicate, newExpr);
/*    */   }
/*    */ 
/*    */   
/*    */   public void accept(GimpleExprVisitor visitor) {
/* 63 */     visitor.visitCompoundLiteral(this);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 68 */     return "GimpleCompoundLiteral{decl=" + this.decl + '}';
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/gimple/expr/GimpleCompoundLiteral.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */