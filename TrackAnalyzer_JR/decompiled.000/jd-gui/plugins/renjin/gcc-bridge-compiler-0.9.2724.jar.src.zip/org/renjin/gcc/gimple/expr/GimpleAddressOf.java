/*    */ package org.renjin.gcc.gimple.expr;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.function.Predicate;
/*    */ import org.renjin.gcc.gimple.GimpleExprVisitor;
/*    */ import org.renjin.gcc.gimple.type.GimplePointerType;
/*    */ import org.renjin.gcc.gimple.type.GimpleType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GimpleAddressOf
/*    */   extends GimpleExpr
/*    */ {
/*    */   public GimpleExpr value;
/*    */   
/*    */   public GimpleAddressOf() {}
/*    */   
/*    */   public GimpleAddressOf(GimpleExpr value) {
/* 35 */     this.value = value;
/* 36 */     setType((GimpleType)new GimplePointerType(value.getType()));
/*    */   }
/*    */   
/*    */   public GimpleExpr getValue() {
/* 40 */     return this.value;
/*    */   }
/*    */   
/*    */   public void setValue(GimpleExpr value) {
/* 44 */     this.value = value;
/*    */   }
/*    */ 
/*    */   
/*    */   public void find(Predicate<? super GimpleExpr> predicate, List<GimpleExpr> results) {
/* 49 */     findOrDescend(this.value, predicate, results);
/*    */   }
/*    */ 
/*    */   
/*    */   public void replaceAll(Predicate<? super GimpleExpr> predicate, GimpleExpr newExpr) {
/* 54 */     this.value = replaceOrDescend(this.value, predicate, newExpr);
/*    */   }
/*    */ 
/*    */   
/*    */   public void accept(GimpleExprVisitor visitor) {
/* 59 */     visitor.visitAddressOf(this);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 64 */     if (this.value instanceof GimpleComponentRef) {
/* 65 */       return "&(" + this.value + ")";
/*    */     }
/* 67 */     return "&" + this.value;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/gimple/expr/GimpleAddressOf.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */