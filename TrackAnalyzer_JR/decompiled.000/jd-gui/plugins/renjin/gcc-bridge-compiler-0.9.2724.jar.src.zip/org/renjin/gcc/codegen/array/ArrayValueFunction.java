/*     */ package org.renjin.gcc.codegen.array;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Optional;
/*     */ import org.renjin.gcc.codegen.MethodGenerator;
/*     */ import org.renjin.gcc.codegen.expr.GExpr;
/*     */ import org.renjin.gcc.codegen.expr.JExpr;
/*     */ import org.renjin.gcc.codegen.fatptr.ValueFunction;
/*     */ import org.renjin.gcc.codegen.fatptr.WrappedFatPtrExpr;
/*     */ import org.renjin.gcc.codegen.vptr.VPtrExpr;
/*     */ import org.renjin.gcc.gimple.type.GimpleArrayType;
/*     */ import org.renjin.gcc.gimple.type.GimpleType;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ArrayValueFunction
/*     */   implements ValueFunction
/*     */ {
/*     */   private final GimpleArrayType arrayType;
/*     */   private final ValueFunction elementValueFunction;
/*     */   
/*     */   public ArrayValueFunction(GimpleArrayType arrayType, ValueFunction elementValueFunction) {
/*  41 */     this.arrayType = arrayType;
/*  42 */     this.elementValueFunction = elementValueFunction;
/*     */   }
/*     */ 
/*     */   
/*     */   public Type getValueType() {
/*  47 */     return this.elementValueFunction.getValueType();
/*     */   }
/*     */ 
/*     */   
/*     */   public GimpleType getGimpleValueType() {
/*  52 */     return (GimpleType)this.arrayType;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getElementLength() {
/*  57 */     return this.elementValueFunction.getElementLength() * this.arrayType.getElementCount();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getArrayElementBytes() {
/*  62 */     return this.elementValueFunction.getArrayElementBytes();
/*     */   }
/*     */ 
/*     */   
/*     */   public GExpr dereference(JExpr array, JExpr offset) {
/*  67 */     return (GExpr)new FatArrayExpr(this.arrayType, this.elementValueFunction, this.arrayType.getElementCount(), array, offset);
/*     */   }
/*     */ 
/*     */   
/*     */   public GExpr dereference(WrappedFatPtrExpr wrapperInstance) {
/*  72 */     return (GExpr)new FatArrayExpr(this.arrayType, this.elementValueFunction, this.arrayType.getElementCount(), wrapperInstance
/*  73 */         .getArray(), wrapperInstance
/*  74 */         .getOffset());
/*     */   }
/*     */ 
/*     */   
/*     */   public List<JExpr> toArrayValues(GExpr expr) {
/*  79 */     return this.elementValueFunction.toArrayValues(expr);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void memoryCopy(MethodGenerator mv, JExpr destinationArray, JExpr destinationOffset, JExpr sourceArray, JExpr sourceOffset, JExpr valueCount) {
/*  88 */     mv.arrayCopy(sourceArray, sourceOffset, destinationArray, destinationOffset, valueCount);
/*     */   }
/*     */ 
/*     */   
/*     */   public void memorySet(MethodGenerator mv, JExpr array, JExpr offset, JExpr byteValue, JExpr length) {
/*  93 */     this.elementValueFunction.memorySet(mv, array, offset, byteValue, length);
/*     */   }
/*     */ 
/*     */   
/*     */   public Optional<JExpr> getValueConstructor() {
/*  98 */     return this.elementValueFunction.getValueConstructor();
/*     */   }
/*     */ 
/*     */   
/*     */   public VPtrExpr toVPtr(JExpr array, JExpr offset) {
/* 103 */     return this.elementValueFunction.toVPtr(array, offset);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 108 */     return "Array[" + this.elementValueFunction + "]";
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/array/ArrayValueFunction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */