/*     */ package org.renjin.gcc.codegen.type.fun;
/*     */ 
/*     */ import java.lang.invoke.MethodHandle;
/*     */ import java.util.Optional;
/*     */ import org.renjin.gcc.InternalCompilerException;
/*     */ import org.renjin.gcc.codegen.MethodGenerator;
/*     */ import org.renjin.gcc.codegen.array.ArrayTypeStrategies;
/*     */ import org.renjin.gcc.codegen.array.ArrayTypeStrategy;
/*     */ import org.renjin.gcc.codegen.expr.ArrayElement;
/*     */ import org.renjin.gcc.codegen.expr.ExprFactory;
/*     */ import org.renjin.gcc.codegen.expr.Expressions;
/*     */ import org.renjin.gcc.codegen.expr.GExpr;
/*     */ import org.renjin.gcc.codegen.expr.JExpr;
/*     */ import org.renjin.gcc.codegen.expr.JLValue;
/*     */ import org.renjin.gcc.codegen.fatptr.AddressableField;
/*     */ import org.renjin.gcc.codegen.fatptr.FatPtr;
/*     */ import org.renjin.gcc.codegen.fatptr.FatPtrPair;
/*     */ import org.renjin.gcc.codegen.fatptr.ValueFunction;
/*     */ import org.renjin.gcc.codegen.type.FieldStrategy;
/*     */ import org.renjin.gcc.codegen.type.ParamStrategy;
/*     */ import org.renjin.gcc.codegen.type.PointerTypeStrategy;
/*     */ import org.renjin.gcc.codegen.type.ReturnStrategy;
/*     */ import org.renjin.gcc.codegen.type.TypeStrategy;
/*     */ import org.renjin.gcc.codegen.type.UnsupportedCastException;
/*     */ import org.renjin.gcc.codegen.var.VarAllocator;
/*     */ import org.renjin.gcc.codegen.vptr.VPtrStrategy;
/*     */ import org.renjin.gcc.gimple.GimpleVarDecl;
/*     */ import org.renjin.gcc.gimple.expr.GimpleConstructor;
/*     */ import org.renjin.gcc.gimple.type.GimpleArrayType;
/*     */ import org.renjin.gcc.gimple.type.GimpleFunctionType;
/*     */ import org.renjin.gcc.gimple.type.GimpleType;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FunPtrStrategy
/*     */   implements PointerTypeStrategy<FunPtrExpr>
/*     */ {
/*  46 */   public static final Type METHOD_HANDLE_TYPE = Type.getType(MethodHandle.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParamStrategy getParamStrategy() {
/*  53 */     return new FunPtrParamStrategy();
/*     */   }
/*     */ 
/*     */   
/*     */   public FunPtrExpr variable(GimpleVarDecl decl, VarAllocator allocator) {
/*  58 */     if (decl.isAddressable()) {
/*  59 */       JLValue unitArray = allocator.reserveUnitArray(decl.getNameIfPresent(), Type.getType(MethodHandle.class), Optional.empty());
/*  60 */       FatPtrPair address = new FatPtrPair(new FunPtrValueFunction(4), (JExpr)unitArray);
/*  61 */       ArrayElement arrayElement = Expressions.elementAt(address.getArray(), 0);
/*  62 */       return new FunPtrExpr((JExpr)arrayElement, (FatPtr)address);
/*     */     } 
/*  64 */     return new FunPtrExpr((JExpr)allocator.reserve(decl.getNameIfPresent(), Type.getType(MethodHandle.class)));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public FunPtrExpr providedGlobalVariable(GimpleVarDecl decl, JExpr expr, boolean readOnly) {
/*  70 */     if (expr.getType().equals(METHOD_HANDLE_TYPE)) {
/*  71 */       return new FunPtrExpr(expr);
/*     */     }
/*  73 */     throw new InternalCompilerException("Cannot map global variable " + decl + " to " + expr + ". Field of type " + MethodHandle.class
/*  74 */         .getName() + " is required");
/*     */   }
/*     */ 
/*     */   
/*     */   public FieldStrategy fieldGenerator(Type className, String fieldName) {
/*  79 */     return (FieldStrategy)new FunPtrField(className, fieldName);
/*     */   }
/*     */ 
/*     */   
/*     */   public FunPtrExpr constructorExpr(ExprFactory exprFactory, MethodGenerator mv, GimpleConstructor value) {
/*  84 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public FieldStrategy addressableFieldGenerator(Type className, String fieldName) {
/*  89 */     return (FieldStrategy)new AddressableField(METHOD_HANDLE_TYPE, fieldName, getValueFunction());
/*     */   }
/*     */ 
/*     */   
/*     */   public ReturnStrategy getReturnStrategy() {
/*  94 */     return new FunPtrReturnStrategy();
/*     */   }
/*     */ 
/*     */   
/*     */   public ValueFunction getValueFunction() {
/*  99 */     return new FunPtrValueFunction(4);
/*     */   }
/*     */ 
/*     */   
/*     */   public VPtrStrategy pointerTo() {
/* 104 */     return new VPtrStrategy((GimpleType)(new GimpleFunctionType()).pointerTo());
/*     */   }
/*     */ 
/*     */   
/*     */   public ArrayTypeStrategy arrayOf(GimpleArrayType arrayType) {
/* 109 */     return ArrayTypeStrategies.of(arrayType, new FunPtrValueFunction(4));
/*     */   }
/*     */ 
/*     */   
/*     */   public FunPtrExpr cast(MethodGenerator mv, GExpr value) throws UnsupportedCastException {
/* 114 */     return value.toFunPtr();
/*     */   }
/*     */ 
/*     */   
/*     */   public FunPtrExpr nullPointer() {
/* 119 */     return FunPtrExpr.NULL_PTR;
/*     */   }
/*     */ 
/*     */   
/*     */   public FunPtrExpr malloc(MethodGenerator mv, JExpr sizeInBytes) {
/* 124 */     throw new UnsupportedOperationException("Cannot malloc function pointers");
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 129 */     return "FunPtrStrategy";
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/type/fun/FunPtrStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */