/*    */ package org.renjin.gcc.codegen.var;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.Optional;
/*    */ import org.renjin.gcc.codegen.expr.Expressions;
/*    */ import org.renjin.gcc.codegen.expr.JExpr;
/*    */ import org.renjin.gcc.codegen.expr.JLValue;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class VarAllocator
/*    */ {
/*    */   public abstract JLValue reserve(String paramString, Type paramType);
/*    */   
/*    */   public abstract JLValue reserve(String paramString, Type paramType, JExpr paramJExpr);
/*    */   
/*    */   public final JLValue reserve(String name, Class type) {
/* 43 */     return reserve(name, Type.getType(type));
/*    */   }
/*    */   
/*    */   public final JLValue reserveArrayRef(String name, Type componentType) {
/* 47 */     return reserve(name, Type.getType("[" + componentType.getDescriptor()));
/*    */   }
/*    */ 
/*    */   
/*    */   public final JLValue reserveUnitArray(String name, Type componentType, Optional<JExpr> initialValue) {
/*    */     JExpr newArray;
/* 53 */     if (initialValue.isPresent()) {
/* 54 */       newArray = Expressions.newArray(componentType, Collections.singletonList(initialValue.get()));
/*    */     } else {
/* 56 */       newArray = Expressions.newArray(componentType, 1);
/*    */     } 
/* 58 */     return reserve(name, Type.getType("[" + componentType.getDescriptor()), newArray);
/*    */   }
/*    */   
/*    */   public final JLValue reserveInt(String name) {
/* 62 */     return reserve(name, Type.INT_TYPE);
/*    */   }
/*    */   
/*    */   public final JLValue reserveOffsetInt(String name) {
/* 66 */     if (name == null) {
/* 67 */       return reserve((String)null, Type.INT_TYPE);
/*    */     }
/* 69 */     return reserve(name + "$offset", Type.INT_TYPE);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static String toJavaSafeName(String name) {
/* 75 */     if (name.equals("this")) {
/* 76 */       return "_this";
/*    */     }
/* 78 */     return name.replace('.', '$');
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/var/VarAllocator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */