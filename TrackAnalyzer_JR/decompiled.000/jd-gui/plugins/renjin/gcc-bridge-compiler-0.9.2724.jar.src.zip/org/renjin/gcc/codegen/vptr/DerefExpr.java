/*     */ package org.renjin.gcc.codegen.vptr;
/*     */ 
/*     */ import javax.annotation.Nonnull;
/*     */ import org.renjin.gcc.codegen.MethodGenerator;
/*     */ import org.renjin.gcc.codegen.expr.BinaryOpExpr;
/*     */ import org.renjin.gcc.codegen.expr.ConstantValue;
/*     */ import org.renjin.gcc.codegen.expr.Expressions;
/*     */ import org.renjin.gcc.codegen.expr.JExpr;
/*     */ import org.renjin.gcc.codegen.expr.JLValue;
/*     */ import org.renjin.gcc.runtime.Ptr;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DerefExpr
/*     */   implements JLValue
/*     */ {
/*     */   private final JExpr pointer;
/*     */   private final JExpr offsetBytes;
/*     */   private final PointerType pointerType;
/*     */   
/*     */   public DerefExpr(JExpr pointer, JExpr offsetBytes, PointerType pointerType) {
/*  36 */     this.pointer = pointer;
/*  37 */     this.offsetBytes = offsetBytes;
/*  38 */     this.pointerType = pointerType;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nonnull
/*     */   public Type getType() {
/*  44 */     return this.pointerType.getJvmType();
/*     */   }
/*     */ 
/*     */   
/*     */   public void load(@Nonnull MethodGenerator mv) {
/*  49 */     this.pointer.load(mv);
/*     */     
/*  51 */     if (isConstantEqualTo(this.offsetBytes, 0)) {
/*  52 */       mv.invokeinterface(Type.getInternalName(Ptr.class), "get" + this.pointerType.titleCasedName(), 
/*  53 */           Type.getMethodDescriptor(this.pointerType.getJvmType(), new Type[0]));
/*     */     } else {
/*  55 */       JExpr index = isAligned();
/*  56 */       if (index != null) {
/*  57 */         index.load(mv);
/*  58 */         mv.invokeinterface(Type.getInternalName(Ptr.class), "getAligned" + this.pointerType.titleCasedName(), 
/*  59 */             Type.getMethodDescriptor(this.pointerType.getJvmType(), new Type[] { Type.INT_TYPE }));
/*     */       } else {
/*  61 */         this.offsetBytes.load(mv);
/*  62 */         mv.invokeinterface(Type.getInternalName(Ptr.class), "get" + this.pointerType.titleCasedName(), 
/*  63 */             Type.getMethodDescriptor(this.pointerType.getJvmType(), new Type[] { Type.INT_TYPE }));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void store(MethodGenerator mv, JExpr expr) {
/*  70 */     this.pointer.load(mv);
/*  71 */     if (isConstantEqualTo(this.offsetBytes, 0)) {
/*     */       
/*  73 */       expr.load(mv);
/*  74 */       mv.invokeinterface(Type.getInternalName(Ptr.class), "set" + this.pointerType.titleCasedName(), 
/*  75 */           Type.getMethodDescriptor(Type.VOID_TYPE, new Type[] { this.pointerType.getJvmType() }));
/*     */     } else {
/*     */       
/*  78 */       JExpr index = isAligned();
/*  79 */       if (index != null) {
/*  80 */         index.load(mv);
/*  81 */         expr.load(mv);
/*  82 */         mv.invokeinterface(Type.getInternalName(Ptr.class), "setAligned" + this.pointerType.titleCasedName(), 
/*  83 */             Type.getMethodDescriptor(Type.VOID_TYPE, new Type[] { Type.INT_TYPE, this.pointerType.getJvmType() }));
/*     */       } else {
/*     */         
/*  86 */         this.offsetBytes.load(mv);
/*  87 */         expr.load(mv);
/*  88 */         mv.invokeinterface(Type.getInternalName(Ptr.class), "set" + this.pointerType.titleCasedName(), 
/*  89 */             Type.getMethodDescriptor(Type.VOID_TYPE, new Type[] { Type.INT_TYPE, this.pointerType.getJvmType() }));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private JExpr isAligned() {
/*  96 */     if (this.pointerType.getSize() < 2) {
/*  97 */       return null;
/*     */     }
/*     */     
/* 100 */     if (this.offsetBytes instanceof ConstantValue) {
/* 101 */       int constantOffsetBytes = ((ConstantValue)this.offsetBytes).getIntValue();
/* 102 */       if (constantOffsetBytes % this.pointerType.getSize() == 0) {
/* 103 */         return Expressions.constantInt(constantOffsetBytes / this.pointerType.getSize());
/*     */       }
/*     */     } 
/*     */     
/* 107 */     if (this.offsetBytes instanceof BinaryOpExpr) {
/* 108 */       BinaryOpExpr op = (BinaryOpExpr)this.offsetBytes;
/* 109 */       if (op.getOpcode() == 104) {
/*     */         
/* 111 */         if (isConstantEqualTo(op.getX(), this.pointerType.getSize())) {
/* 112 */           return op.getY();
/*     */         }
/* 114 */         if (isConstantEqualTo(op.getY(), this.pointerType.getSize())) {
/* 115 */           return op.getX();
/*     */         }
/*     */       } 
/*     */     } 
/* 119 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isConstantEqualTo(JExpr expr, int value) {
/* 124 */     return (expr instanceof ConstantValue && ((ConstantValue)expr).getIntValue() == value);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/vptr/DerefExpr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */