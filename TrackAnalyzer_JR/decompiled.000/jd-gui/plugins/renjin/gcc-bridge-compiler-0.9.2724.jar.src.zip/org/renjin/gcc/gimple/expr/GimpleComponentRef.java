/*    */ package org.renjin.gcc.gimple.expr;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.function.Predicate;
/*    */ import org.renjin.gcc.gimple.GimpleExprVisitor;
/*    */ import org.renjin.repackaged.guava.base.Strings;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GimpleComponentRef
/*    */   extends GimpleLValue
/*    */ {
/*    */   private GimpleExpr value;
/*    */   private GimpleExpr member;
/*    */   
/*    */   public GimpleComponentRef() {}
/*    */   
/*    */   public GimpleComponentRef(GimpleExpr value, GimpleExpr member) {
/* 36 */     this.value = value;
/* 37 */     this.member = member;
/* 38 */     setType(member.getType());
/*    */   }
/*    */   
/*    */   public GimpleExpr getValue() {
/* 42 */     return this.value;
/*    */   }
/*    */   
/*    */   public void setMember(GimpleExpr member) {
/* 46 */     this.member = member;
/*    */   }
/*    */   
/*    */   public GimpleFieldRef getMember() {
/* 50 */     return (GimpleFieldRef)this.member;
/*    */   }
/*    */   
/*    */   public String memberName() {
/* 54 */     if (this.member instanceof GimpleFieldRef) {
/* 55 */       return Strings.nullToEmpty(((GimpleFieldRef)this.member).getName());
/*    */     }
/* 57 */     throw new UnsupportedOperationException(this.member.getClass().getSimpleName());
/*    */   }
/*    */ 
/*    */   
/*    */   public void find(Predicate<? super GimpleExpr> predicate, List<GimpleExpr> results) {
/* 62 */     findOrDescend(this.value, predicate, results);
/* 63 */     findOrDescend(this.member, predicate, results);
/*    */   }
/*    */ 
/*    */   
/*    */   public void replaceAll(Predicate<? super GimpleExpr> predicate, GimpleExpr newExpr) {
/* 68 */     this.value = replaceOrDescend(this.value, predicate, newExpr);
/* 69 */     this.member = replaceOrDescend(this.member, predicate, newExpr);
/*    */   }
/*    */ 
/*    */   
/*    */   public void accept(GimpleExprVisitor visitor) {
/* 74 */     visitor.visitComponentRef(this);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 79 */     if (this.member instanceof GimpleFieldRef) {
/* 80 */       GimpleFieldRef memberField = (GimpleFieldRef)this.member;
/* 81 */       if (memberField.getName() == null) {
/* 82 */         return this.value + "@" + memberField.getOffset();
/*    */       }
/*    */     } 
/* 85 */     return this.value + "." + this.member;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/gimple/expr/GimpleComponentRef.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */