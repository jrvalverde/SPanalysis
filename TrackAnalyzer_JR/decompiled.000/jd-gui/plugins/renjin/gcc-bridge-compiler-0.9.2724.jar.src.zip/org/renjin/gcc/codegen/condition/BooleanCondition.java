/*    */ package org.renjin.gcc.codegen.condition;
/*    */ 
/*    */ import org.renjin.gcc.codegen.MethodGenerator;
/*    */ import org.renjin.gcc.codegen.expr.JExpr;
/*    */ import org.renjin.repackaged.asm.Label;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BooleanCondition
/*    */   implements ConditionGenerator
/*    */ {
/*    */   private JExpr booleanValue;
/*    */   
/*    */   public BooleanCondition(JExpr booleanValue) {
/* 31 */     this.booleanValue = booleanValue;
/*    */   }
/*    */ 
/*    */   
/*    */   public void emitJump(MethodGenerator mv, Label trueLabel, Label falseLabel) {
/* 36 */     this.booleanValue.load(mv);
/* 37 */     mv.visitJumpInsn(154, trueLabel);
/* 38 */     mv.goTo(falseLabel);
/*    */   }
/*    */   
/*    */   public ConditionGenerator inverse() {
/* 42 */     return new InverseConditionGenerator(this);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/condition/BooleanCondition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */