/*    */ package org.renjin.gcc.codegen.fatptr;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import org.renjin.gcc.codegen.MethodGenerator;
/*    */ import org.renjin.gcc.codegen.expr.Expressions;
/*    */ import org.renjin.gcc.codegen.expr.JExpr;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Memset
/*    */ {
/*    */   public static void primitiveMemset(MethodGenerator mv, Type valueType, JExpr array, JExpr offset, JExpr byteValue, JExpr length) {
/* 42 */     Type wrapperType = Wrappers.wrapperType(valueType);
/* 43 */     Type arrayType = Wrappers.valueArrayType(valueType);
/*    */     
/* 45 */     String methodDescriptor = Type.getMethodDescriptor(Type.VOID_TYPE, new Type[] { arrayType, Type.INT_TYPE, Type.INT_TYPE, Type.INT_TYPE });
/*    */ 
/*    */     
/* 48 */     array.load(mv);
/* 49 */     offset.load(mv);
/* 50 */     byteValue.load(mv);
/* 51 */     length.load(mv);
/*    */     
/* 53 */     mv.invokestatic(wrapperType, "memset", methodDescriptor);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void zeroOutRefArray(MethodGenerator mv, JExpr array, JExpr offset, JExpr length) {
/* 60 */     JExpr elementCount = Expressions.divide(length, 4);
/* 61 */     JExpr toIndex = Expressions.sum(offset, elementCount);
/*    */ 
/*    */     
/* 64 */     array.load(mv);
/* 65 */     offset.load(mv);
/* 66 */     toIndex.load(mv);
/* 67 */     mv.aconst(null);
/* 68 */     mv.invokestatic(Arrays.class, "fill", Type.getMethodDescriptor(Type.VOID_TYPE, new Type[] {
/* 69 */             Type.getType(Object[].class), Type.INT_TYPE, Type.INT_TYPE, 
/*    */ 
/*    */             
/* 72 */             Type.getType(Object.class)
/*    */           }));
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/fatptr/Memset.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */