/*     */ package org.renjin.gcc.codegen.type.primitive;
/*     */ 
/*     */ import javax.annotation.Nullable;
/*     */ import org.renjin.gcc.codegen.MethodGenerator;
/*     */ import org.renjin.gcc.codegen.condition.Comparison;
/*     */ import org.renjin.gcc.codegen.condition.ConditionGenerator;
/*     */ import org.renjin.gcc.codegen.expr.Expressions;
/*     */ import org.renjin.gcc.codegen.expr.GExpr;
/*     */ import org.renjin.gcc.codegen.expr.JExpr;
/*     */ import org.renjin.gcc.codegen.expr.JLValue;
/*     */ import org.renjin.gcc.codegen.expr.PtrExpr;
/*     */ import org.renjin.gcc.codegen.type.NumericExpr;
/*     */ import org.renjin.gcc.gimple.GimpleOp;
/*     */ import org.renjin.gcc.gimple.type.GimpleIntegerType;
/*     */ import org.renjin.gcc.gimple.type.GimplePrimitiveType;
/*     */ import org.renjin.gcc.gimple.type.GimpleRealType;
/*     */ import org.renjin.gcc.runtime.LongPtr;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UnsignedLongExpr
/*     */   extends AbstractIntExpr
/*     */ {
/*     */   public UnsignedLongExpr(JExpr jexpr, @Nullable PtrExpr address) {
/*  37 */     super(jexpr, address);
/*     */   }
/*     */   
/*     */   public UnsignedLongExpr(JExpr jExpr) {
/*  41 */     this(jExpr, (PtrExpr)null);
/*     */   }
/*     */   
/*     */   private UnsignedLongExpr lift(JExpr jExpr) {
/*  45 */     assert jExpr.getType().equals(Type.LONG_TYPE);
/*  46 */     return new UnsignedLongExpr(jExpr);
/*     */   }
/*     */   
/*     */   private JExpr jexpr(GExpr operand) {
/*  50 */     return operand.toPrimitiveExpr().toUnsignedInt(64).jexpr();
/*     */   }
/*     */ 
/*     */   
/*     */   public UnsignedLongExpr plus(GExpr operand) {
/*  55 */     return lift(Expressions.sum(jexpr(), jexpr(operand)));
/*     */   }
/*     */ 
/*     */   
/*     */   public UnsignedLongExpr minus(GExpr operand) {
/*  60 */     return lift(Expressions.difference(jexpr(), jexpr(operand)));
/*     */   }
/*     */ 
/*     */   
/*     */   public UnsignedLongExpr multiply(GExpr operand) {
/*  65 */     return lift(Expressions.product(jexpr(), jexpr(operand)));
/*     */   }
/*     */ 
/*     */   
/*     */   public UnsignedLongExpr divide(GExpr operand) {
/*  70 */     return lift(Expressions.staticMethodCall(Long.class, "divideUnsigned", "(JJ)J", new JExpr[] { jexpr(), jexpr(operand) }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UnsignedLongExpr negative() {
/*  77 */     return lift(Expressions.negative(jexpr()));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public UnsignedLongExpr min(GExpr operand) {
/*  83 */     return lift(Expressions.staticMethodCall(LongPtr.class, "unsignedMin", "(JJ)J", new JExpr[] { jexpr(), jexpr(operand) }));
/*     */   }
/*     */ 
/*     */   
/*     */   public UnsignedLongExpr max(GExpr operand) {
/*  88 */     return lift(Expressions.staticMethodCall(LongPtr.class, "unsignedMax", "(JJ)J", new JExpr[] { jexpr(), jexpr(operand) }));
/*     */   }
/*     */ 
/*     */   
/*     */   public UnsignedLongExpr absoluteValue() {
/*  93 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public UnsignedLongExpr remainder(GExpr operand) {
/*  98 */     return lift(Expressions.staticMethodCall(Long.class, "remainderUnsigned", "(JJ)J", new JExpr[] { jexpr(), jexpr(operand) }));
/*     */   }
/*     */ 
/*     */   
/*     */   public UnsignedLongExpr bitwiseXor(GExpr operand) {
/* 103 */     return lift(Expressions.bitwiseXor(jexpr(), jexpr(operand)));
/*     */   }
/*     */ 
/*     */   
/*     */   public UnsignedLongExpr bitwiseNot() {
/* 108 */     return lift(Expressions.bitwiseXor(jexpr(), Expressions.constantLong(-1L)));
/*     */   }
/*     */ 
/*     */   
/*     */   public UnsignedLongExpr bitwiseAnd(GExpr operand) {
/* 113 */     return lift(Expressions.bitwiseAnd(jexpr(), jexpr(operand)));
/*     */   }
/*     */ 
/*     */   
/*     */   public UnsignedLongExpr bitwiseOr(GExpr operand) {
/* 118 */     return lift(Expressions.bitwiseOr(jexpr(), jexpr(operand)));
/*     */   }
/*     */ 
/*     */   
/*     */   public UnsignedLongExpr shiftLeft(GExpr operand) {
/* 123 */     return lift(Expressions.shiftLeft(jexpr(), bits(operand)));
/*     */   }
/*     */ 
/*     */   
/*     */   public UnsignedLongExpr shiftRight(GExpr operand) {
/* 128 */     return lift(Expressions.unsignedShiftRight(jexpr(), bits(operand)));
/*     */   }
/*     */ 
/*     */   
/*     */   public UnsignedLongExpr rotateLeft(GExpr operand) {
/* 133 */     return lift(Expressions.staticMethodCall(Long.class, "rotateLeft", "(JI)J", new JExpr[] { jexpr(), bits(operand) }));
/*     */   }
/*     */ 
/*     */   
/*     */   public IntExpr toSignedInt(int precision) {
/* 138 */     switch (precision) {
/*     */       case 64:
/* 140 */         return new SignedLongExpr(jexpr());
/*     */       case 8:
/*     */       case 16:
/*     */       case 32:
/* 144 */         return (new SignedIntExpr(Expressions.l2i(jexpr()))).toSignedInt(precision);
/*     */     } 
/* 146 */     throw new UnsupportedOperationException("precision: " + precision);
/*     */   }
/*     */ 
/*     */   
/*     */   public IntExpr toUnsignedInt(int precision) {
/* 151 */     switch (precision) {
/*     */       case 64:
/* 153 */         return this;
/*     */       case 8:
/*     */       case 16:
/*     */       case 32:
/* 157 */         return (new UnsignedIntExpr(Expressions.l2i(jexpr()))).toUnsignedInt(precision);
/*     */     } 
/* 159 */     throw new UnsupportedOperationException("precision: " + precision);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public GimplePrimitiveType getType() {
/* 165 */     return (GimplePrimitiveType)GimpleIntegerType.unsigned(64);
/*     */   }
/*     */ 
/*     */   
/*     */   public RealExpr toRealExpr() {
/* 170 */     return new RealExpr(new GimpleRealType(64), 
/* 171 */         Expressions.staticMethodCall(LongPtr.class, "unsignedInt64ToReal64", "(J)D", new JExpr[] { jexpr() }));
/*     */   }
/*     */ 
/*     */   
/*     */   public RealExpr toReal(int precision) {
/* 176 */     return toRealExpr().toReal(precision);
/*     */   }
/*     */ 
/*     */   
/*     */   public ConditionGenerator compareTo(GimpleOp op, GExpr operand) {
/* 181 */     switch (op) {
/*     */       case EQ_EXPR:
/*     */       case NE_EXPR:
/* 184 */         return (ConditionGenerator)new Comparison(op, Expressions.lcmp(jexpr(), jexpr(operand)));
/*     */     } 
/* 186 */     return (ConditionGenerator)new Comparison(op, Expressions.staticMethodCall(Long.class, "compareUnsigned", "(JJ)I", new JExpr[] {
/* 187 */             jexpr(), jexpr(operand)
/*     */           }));
/*     */   }
/*     */ 
/*     */   
/*     */   public void store(MethodGenerator mv, GExpr rhs) {
/* 193 */     ((JLValue)jexpr()).store(mv, jexpr(rhs));
/*     */   }
/*     */ 
/*     */   
/*     */   public BooleanExpr toBooleanExpr() {
/* 198 */     return toUnsignedInt(32).toBooleanExpr();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/type/primitive/UnsignedLongExpr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */