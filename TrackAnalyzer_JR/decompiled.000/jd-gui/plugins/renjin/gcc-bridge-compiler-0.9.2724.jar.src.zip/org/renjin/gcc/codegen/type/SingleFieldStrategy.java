/*    */ package org.renjin.gcc.codegen.type;
/*    */ 
/*    */ import org.renjin.gcc.codegen.MethodGenerator;
/*    */ import org.renjin.gcc.codegen.expr.JExpr;
/*    */ import org.renjin.gcc.codegen.type.primitive.FieldValue;
/*    */ import org.renjin.repackaged.asm.ClassVisitor;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ import org.renjin.repackaged.guava.base.Preconditions;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class SingleFieldStrategy
/*    */   extends FieldStrategy
/*    */ {
/*    */   protected final Type ownerClass;
/*    */   protected final String fieldName;
/*    */   protected final Type fieldType;
/*    */   
/*    */   public SingleFieldStrategy(Type ownerClass, String fieldName, Type fieldType) {
/* 36 */     this.ownerClass = ownerClass;
/* 37 */     this.fieldName = fieldName;
/* 38 */     this.fieldType = fieldType;
/* 39 */     Preconditions.checkNotNull(fieldName);
/* 40 */     Preconditions.checkArgument(!fieldName.isEmpty(), "fieldName cannot be empty");
/*    */   }
/*    */ 
/*    */   
/*    */   public final void writeFields(ClassVisitor cv) {
/* 45 */     cv.visitField(1, this.fieldName, this.fieldType.getDescriptor(), null, null);
/*    */   }
/*    */   
/*    */   protected final void memsetReference(MethodGenerator mv, JExpr instance, JExpr byteValue, JExpr count) {
/* 49 */     instance.load(mv);
/* 50 */     mv.aconst(null);
/* 51 */     mv.putfield(this.ownerClass, this.fieldName, this.fieldType);
/*    */   }
/*    */ 
/*    */   
/*    */   public void copy(MethodGenerator mv, JExpr source, JExpr dest) {
/* 56 */     FieldValue sourceExpr = new FieldValue(source, this.fieldName, this.fieldType);
/* 57 */     FieldValue destExpr = new FieldValue(dest, this.fieldName, this.fieldType);
/* 58 */     destExpr.store(mv, (JExpr)sourceExpr);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/type/SingleFieldStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */