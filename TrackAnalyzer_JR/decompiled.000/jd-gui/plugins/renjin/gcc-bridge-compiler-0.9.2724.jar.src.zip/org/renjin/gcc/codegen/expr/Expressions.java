/*      */ package org.renjin.gcc.codegen.expr;
/*      */ 
/*      */ import java.lang.reflect.Field;
/*      */ import java.lang.reflect.Modifier;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.List;
/*      */ import java.util.Optional;
/*      */ import javax.annotation.Nonnull;
/*      */ import org.renjin.gcc.codegen.MethodGenerator;
/*      */ import org.renjin.gcc.codegen.WrapperType;
/*      */ import org.renjin.repackaged.asm.Type;
/*      */ import org.renjin.repackaged.guava.base.Preconditions;
/*      */ import org.renjin.repackaged.guava.collect.Lists;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Expressions
/*      */ {
/*      */   public static JExpr newArray(Type componentType, int length) {
/*   43 */     Preconditions.checkArgument((length >= 0));
/*   44 */     return newArray(componentType, constantInt(length));
/*      */   }
/*      */   
/*      */   public static JExpr newArray(WrapperType componentType, int length) {
/*   48 */     return newArray(componentType.getWrapperType(), length);
/*      */   }
/*      */   
/*      */   public static JExpr newArray(Class<?> componentClass, int length) {
/*   52 */     return newArray(Type.getType(componentClass), length);
/*      */   }
/*      */   
/*      */   public static JExpr newArray(final Type componentType, final JExpr length) {
/*   56 */     checkType("length", length, 5);
/*   57 */     return new JExpr()
/*      */       {
/*      */         @Nonnull
/*      */         public Type getType() {
/*   61 */           return Type.getType("[" + componentType.getDescriptor());
/*      */         }
/*      */ 
/*      */         
/*      */         public void load(@Nonnull MethodGenerator mv) {
/*   66 */           length.load(mv);
/*   67 */           mv.newarray(componentType);
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */   
/*      */   public static JExpr newArray(JExpr value, JExpr... moreValues) {
/*   74 */     List<JExpr> values = new ArrayList<>();
/*   75 */     values.add(value);
/*   76 */     values.addAll(Arrays.asList(moreValues));
/*      */     
/*   78 */     return newArray(value.getType(), values);
/*      */   }
/*      */   
/*      */   public static JExpr newArray(Type componentType, List<JExpr> values) {
/*   82 */     return newArray(componentType, values.size(), values);
/*      */   }
/*      */ 
/*      */   
/*      */   public static JExpr newArray(Type valueType, int elementLength, Optional<JExpr> firstValue) {
/*   87 */     List<JExpr> initialValues = Lists.newArrayList();
/*   88 */     if (firstValue.isPresent()) {
/*   89 */       initialValues.add(firstValue.get());
/*      */     }
/*   91 */     return newArray(valueType, elementLength, initialValues);
/*      */   }
/*      */   
/*      */   public static JExpr newArray(final Type componentType, final int arrayLength, final List<JExpr> values) {
/*   95 */     Preconditions.checkNotNull(componentType, "componentType");
/*      */     
/*   97 */     if (values.size() > arrayLength)
/*   98 */       throw new IllegalArgumentException(
/*   99 */           String.format("Number of initial values supplied (%d) is greater than array length (%d)", new Object[] {
/*  100 */               Integer.valueOf(values.size()), 
/*  101 */               Integer.valueOf(arrayLength)
/*      */             })); 
/*  103 */     final Type arrayType = Type.getType("[" + componentType.getDescriptor());
/*      */ 
/*      */     
/*  106 */     for (int i = 0; i < values.size(); i++) {
/*  107 */       Type elementType = ((JExpr)values.get(i)).getType();
/*  108 */       if (promoteSmallInts(elementType).getSort() != promoteSmallInts(componentType).getSort()) {
/*  109 */         throw new IllegalArgumentException(String.format("Invalid type at element %d: %s, expected %s", new Object[] {
/*  110 */                 Integer.valueOf(i), elementType, componentType
/*      */               }));
/*      */       }
/*      */     } 
/*  114 */     return new JExpr()
/*      */       {
/*      */         @Nonnull
/*      */         public Type getType() {
/*  118 */           return arrayType;
/*      */         }
/*      */ 
/*      */         
/*      */         public void load(@Nonnull MethodGenerator mv) {
/*  123 */           mv.iconst(arrayLength);
/*  124 */           mv.newarray(componentType);
/*  125 */           for (int i = 0; i < values.size(); i++) {
/*  126 */             mv.dup();
/*  127 */             mv.iconst(i);
/*  128 */             ((JExpr)values.get(i)).load(mv);
/*  129 */             mv.astore(componentType);
/*      */           } 
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */   
/*      */   public static ArrayElement elementAt(JExpr array, int offset) {
/*  137 */     return elementAt(array, constantInt(offset));
/*      */   }
/*      */   
/*      */   public static ArrayElement elementAt(JExpr array, JExpr offset) {
/*  141 */     checkType("array", array, 9);
/*  142 */     checkType("offset", offset, Type.INT_TYPE);
/*      */     
/*  144 */     return new ArrayElement(array, offset);
/*      */   }
/*      */   
/*      */   public static JExpr nullRef(final Type type) {
/*  148 */     return new JExpr()
/*      */       {
/*      */         @Nonnull
/*      */         public Type getType() {
/*  152 */           return type;
/*      */         }
/*      */ 
/*      */         
/*      */         public void load(@Nonnull MethodGenerator mv) {
/*  157 */           mv.aconst(null);
/*      */         }
/*      */       };
/*      */   }
/*      */   
/*      */   public static JExpr constantInt(int value) {
/*  163 */     return new ConstantValue(Type.INT_TYPE, Integer.valueOf(value));
/*      */   }
/*      */   
/*      */   public static JExpr constantBoolean(boolean value) {
/*  167 */     return new ConstantValue(Type.BOOLEAN_TYPE, Integer.valueOf(value ? 1 : 0));
/*      */   }
/*      */   
/*      */   public static JExpr constantLong(final long value) {
/*  171 */     return new JExpr()
/*      */       {
/*      */         @Nonnull
/*      */         public Type getType() {
/*  175 */           return Type.LONG_TYPE;
/*      */         }
/*      */ 
/*      */         
/*      */         public void load(@Nonnull MethodGenerator mv) {
/*  180 */           mv.visitLdcInsn(Long.valueOf(value));
/*      */         }
/*      */       };
/*      */   }
/*      */   
/*      */   public static JExpr zero() {
/*  186 */     return constantInt(0);
/*      */   }
/*      */   
/*      */   public static JExpr zero(Type type) {
/*  190 */     return new ConstantValue(promoteSmallInts(type), Integer.valueOf(0));
/*      */   }
/*      */   
/*      */   private static JExpr binary(int opcode, JExpr x, JExpr y, Type resultType) {
/*  194 */     return new BinaryOpExpr(opcode, resultType, x, y);
/*      */   }
/*      */   
/*      */   private static Type promoteSmallInts(Type type) {
/*  198 */     switch (type.getSort()) {
/*      */       case 1:
/*      */       case 2:
/*      */       case 3:
/*      */       case 4:
/*      */       case 5:
/*  204 */         return Type.INT_TYPE;
/*      */     } 
/*  206 */     return type;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static JExpr sum(JExpr x, int y) {
/*  212 */     if (y == 0) {
/*  213 */       return x;
/*      */     }
/*  215 */     return sum(x, constantInt(y));
/*      */   }
/*      */ 
/*      */   
/*      */   public static JExpr sum(JExpr x, JExpr y) {
/*  220 */     if (ConstantValue.isZero(x)) {
/*  221 */       return y;
/*      */     }
/*  223 */     if (ConstantValue.isZero(y)) {
/*  224 */       return x;
/*      */     }
/*  226 */     if (x instanceof ConstantValue && y instanceof ConstantValue) {
/*  227 */       ConstantValue cx = (ConstantValue)x;
/*  228 */       ConstantValue cy = (ConstantValue)y;
/*  229 */       if (x.getType().getSort() == 5)
/*  230 */         return new ConstantValue(Type.INT_TYPE, Integer.valueOf(cx.getIntValue() + cy.getIntValue())); 
/*  231 */       if (x.getType().getSort() == 7) {
/*  232 */         return new ConstantValue(Type.LONG_TYPE, Long.valueOf(cx.getValue().longValue() + cy.getValue().longValue()));
/*      */       }
/*      */     } 
/*  235 */     return binary(96, x, y, promoteSmallInts(x.getType()));
/*      */   }
/*      */ 
/*      */   
/*      */   public static JExpr difference(JExpr x, JExpr y) {
/*  240 */     return binary(100, x, y, promoteSmallInts(x.getType()));
/*      */   }
/*      */   
/*      */   public static JExpr difference(JExpr x, int y) {
/*  244 */     if (y == 0) {
/*  245 */       return x;
/*      */     }
/*  247 */     return difference(x, constantInt(y));
/*      */   }
/*      */ 
/*      */   
/*      */   public static JExpr product(JExpr x, JExpr y) {
/*  252 */     if (x instanceof ConstantValue && y instanceof ConstantValue) {
/*  253 */       return constantInt(((ConstantValue)x)
/*  254 */           .getIntValue() * ((ConstantValue)y)
/*  255 */           .getIntValue());
/*      */     }
/*  257 */     return binary(104, x, y, promoteSmallInts(x.getType()));
/*      */   }
/*      */ 
/*      */   
/*      */   public static JExpr product(JExpr x, int y) {
/*  262 */     if (y == 0)
/*  263 */       return zero(x.getType()); 
/*  264 */     if (y == 1) {
/*  265 */       return x;
/*      */     }
/*  267 */     return product(x, new ConstantValue(x.getType(), Integer.valueOf(y)));
/*      */   }
/*      */ 
/*      */   
/*      */   public static JExpr divide(JExpr x, JExpr y) {
/*  272 */     return binary(108, x, y, promoteSmallInts(x.getType()));
/*      */   }
/*      */   
/*      */   public static JExpr divide(JExpr size, int divisor) {
/*  276 */     Preconditions.checkArgument(size.getType().equals(Type.INT_TYPE));
/*      */     
/*  278 */     if (size instanceof ConstantValue) {
/*  279 */       return new ConstantValue(Type.INT_TYPE, Integer.valueOf(((ConstantValue)size).getIntValue() / divisor));
/*      */     }
/*      */     
/*  282 */     return divide(size, constantInt(divisor));
/*      */   }
/*      */   
/*      */   public static JLValue field(final JExpr instance, final Type fieldType, final String fieldName) {
/*  286 */     checkType("instance", instance, 10);
/*      */     
/*  288 */     return new JLValue()
/*      */       {
/*      */         @Nonnull
/*      */         public Type getType() {
/*  292 */           return fieldType;
/*      */         }
/*      */ 
/*      */         
/*      */         public void load(@Nonnull MethodGenerator mv) {
/*  297 */           instance.load(mv);
/*  298 */           mv.getfield(instance.getType().getInternalName(), fieldName, fieldType.getDescriptor());
/*      */         }
/*      */ 
/*      */         
/*      */         public void store(MethodGenerator mv, JExpr value) {
/*  303 */           instance.load(mv);
/*  304 */           value.load(mv);
/*  305 */           mv.putfield(instance.getType().getInternalName(), fieldName, fieldType.getDescriptor());
/*      */         }
/*      */       };
/*      */   }
/*      */   
/*      */   private static void checkType(String argName, JExpr value, int expectedSort) {
/*  311 */     if (value.getType().getSort() != expectedSort)
/*  312 */       throw new IllegalArgumentException(String.format("Illegal type for %s: %s", new Object[] { argName, value.getType() })); 
/*      */   }
/*      */   
/*      */   private static void checkType(String argName, JExpr value, Type expectedType) {
/*  316 */     if (!value.getType().equals(expectedType)) {
/*  317 */       throw new IllegalArgumentException(String.format("Illegal type %s for %s: Expected %s", new Object[] { value
/*  318 */               .getType(), argName, expectedType }));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static JExpr cast(JExpr object, Type type) {
/*  325 */     if (object.getType().equals(type) || type.equals(Type.getType(Object.class))) {
/*  326 */       return object;
/*      */     }
/*      */ 
/*      */     
/*  330 */     if (object.getType().getSort() == 9 && type.equals(Type.getType("[Ljava/lang/Object;"))) {
/*  331 */       return object;
/*      */     }
/*      */ 
/*      */     
/*  335 */     checkCast(object.getType(), type);
/*      */     
/*  337 */     return uncheckedCast(object, type);
/*      */   }
/*      */   
/*      */   public static JExpr uncheckedCast(final JExpr object, final Type type) {
/*  341 */     return new JLValue()
/*      */       {
/*      */         @Nonnull
/*      */         public Type getType()
/*      */         {
/*  346 */           return type;
/*      */         }
/*      */ 
/*      */         
/*      */         public void load(@Nonnull MethodGenerator mv) {
/*  351 */           object.load(mv);
/*  352 */           mv.checkcast(type);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*      */         public void store(MethodGenerator mv, JExpr value) {
/*  358 */           if (!(object instanceof JLValue)) {
/*  359 */             throw new UnsupportedOperationException();
/*      */           }
/*  361 */           ((JLValue)object).store(mv, value);
/*      */         }
/*      */       };
/*      */   }
/*      */   
/*      */   public static JExpr castPrimitive(final JExpr expr, final Type type) {
/*  367 */     return new JExpr()
/*      */       {
/*      */         @Nonnull
/*      */         public Type getType() {
/*  371 */           return type;
/*      */         }
/*      */ 
/*      */         
/*      */         public void load(@Nonnull MethodGenerator mv) {
/*  376 */           expr.load(mv);
/*  377 */           mv.cast(expr.getType(), type);
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */   
/*      */   private static void checkCast(Type fromType, Type toType) {
/*  384 */     if (fromType.equals(toType)) {
/*      */       return;
/*      */     }
/*      */     
/*  388 */     if (toType.getSort() != 10 && toType
/*  389 */       .getSort() != 9) {
/*  390 */       throw new IllegalArgumentException("Cannot cast from " + fromType + " to " + toType);
/*      */     }
/*  392 */     int fromSort = fromType.getSort();
/*  393 */     int toSort = toType.getSort();
/*      */     
/*  395 */     if (fromSort == 9 && 
/*  396 */       toSort == 9) {
/*  397 */       checkCast(fromType.getElementType(), toType.getElementType());
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public static JExpr voidValue() {
/*  403 */     return new JExpr()
/*      */       {
/*      */         @Nonnull
/*      */         public Type getType() {
/*  407 */           return Type.VOID_TYPE;
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*      */         public void load(@Nonnull MethodGenerator mv) {}
/*      */       };
/*      */   }
/*      */ 
/*      */   
/*      */   public static JExpr thisValue(final Type type) {
/*  418 */     return new JExpr()
/*      */       {
/*      */         @Nonnull
/*      */         public Type getType()
/*      */         {
/*  423 */           return type;
/*      */         }
/*      */ 
/*      */         
/*      */         public void load(@Nonnull MethodGenerator mv) {
/*  428 */           mv.load(0, type);
/*      */         }
/*      */       };
/*      */   }
/*      */   
/*      */   public static boolean isPrimitive(JExpr simpleExpr) {
/*  434 */     return isPrimitive(simpleExpr.getType());
/*      */   }
/*      */   
/*      */   public static boolean isPrimitive(Type type) {
/*  438 */     switch (type.getSort()) {
/*      */       case 1:
/*      */       case 2:
/*      */       case 3:
/*      */       case 4:
/*      */       case 5:
/*      */       case 6:
/*      */       case 7:
/*      */       case 8:
/*  447 */         return true;
/*      */       
/*      */       case 9:
/*      */       case 10:
/*      */       case 11:
/*  452 */         return false;
/*      */     } 
/*      */     
/*  455 */     throw new IllegalArgumentException("type: " + type);
/*      */   }
/*      */ 
/*      */   
/*      */   public static JExpr box(final JExpr simpleExpr) {
/*  460 */     Preconditions.checkArgument(isPrimitive(simpleExpr), "simpleExpr must be a primitive");
/*      */     
/*  462 */     Type primitiveType = simpleExpr.getType();
/*  463 */     final Type boxedType = boxedType(primitiveType);
/*  464 */     final String valueOfDescriptor = Type.getMethodDescriptor(boxedType, new Type[] { primitiveType });
/*      */     
/*  466 */     return new JExpr()
/*      */       {
/*      */         @Nonnull
/*      */         public Type getType() {
/*  470 */           return boxedType;
/*      */         }
/*      */ 
/*      */         
/*      */         public void load(@Nonnull MethodGenerator mv) {
/*  475 */           simpleExpr.load(mv);
/*  476 */           mv.invokestatic(boxedType.getInternalName(), "valueOf", valueOfDescriptor, false);
/*      */         }
/*      */       };
/*      */   }
/*      */   
/*      */   public static Type boxedType(Type type) {
/*  482 */     switch (type.getSort()) {
/*      */       case 1:
/*  484 */         return Type.getType(Boolean.class);
/*      */       case 3:
/*  486 */         return Type.getType(Byte.class);
/*      */       case 4:
/*  488 */         return Type.getType(Short.class);
/*      */       case 2:
/*  490 */         return Type.getType(Character.class);
/*      */       case 5:
/*  492 */         return Type.getType(Integer.class);
/*      */       case 7:
/*  494 */         return Type.getType(Long.class);
/*      */       case 6:
/*  496 */         return Type.getType(Float.class);
/*      */       case 8:
/*  498 */         return Type.getType(Double.class);
/*      */     } 
/*      */     
/*  501 */     throw new IllegalArgumentException("type: " + type);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static JExpr copyOfArrayRange(final JExpr array, final JExpr from, final JExpr to) {
/*  507 */     final Type arrayType = array.getType();
/*      */     
/*  509 */     return new JExpr()
/*      */       {
/*      */         @Nonnull
/*      */         public Type getType() {
/*  513 */           return arrayType;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void load(@Nonnull MethodGenerator mv) {
/*  520 */           array.load(mv);
/*  521 */           from.load(mv);
/*  522 */           to.load(mv);
/*  523 */           mv.invokestatic(Arrays.class, "copyOfRange", 
/*  524 */               Type.getMethodDescriptor(arrayType, new Type[] { this.val$arrayType, Type.INT_TYPE, Type.INT_TYPE }));
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */   
/*      */   public static JExpr copyOfArray(final JExpr array) {
/*  531 */     final Type arrayType = array.getType();
/*      */     
/*  533 */     return new JExpr()
/*      */       {
/*      */         @Nonnull
/*      */         public Type getType() {
/*  537 */           return arrayType;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void load(@Nonnull MethodGenerator mv) {
/*  544 */           array.load(mv);
/*  545 */           mv.dup();
/*  546 */           mv.arraylength();
/*  547 */           mv.invokestatic(Arrays.class, "copyOf", 
/*  548 */               Type.getMethodDescriptor(arrayType, new Type[] { this.val$arrayType, Type.INT_TYPE }));
/*      */         }
/*      */       };
/*      */   }
/*      */   public static JExpr newObject(Class<?> classType, JExpr... constructorArguments) {
/*  553 */     return newObject(Type.getType(classType), constructorArguments);
/*      */   }
/*      */ 
/*      */   
/*      */   public static JExpr newObject(final Type classType, JExpr... constructorArguments) {
/*  558 */     final Type[] argumentTypes = new Type[constructorArguments.length];
/*  559 */     for (int i = 0; i < constructorArguments.length; i++) {
/*  560 */       argumentTypes[i] = constructorArguments[i].getType();
/*      */     }
/*      */     
/*  563 */     return new JExpr()
/*      */       {
/*      */         @Nonnull
/*      */         public Type getType() {
/*  567 */           return classType;
/*      */         }
/*      */ 
/*      */         
/*      */         public void load(@Nonnull MethodGenerator mv) {
/*  572 */           mv.anew(classType);
/*  573 */           mv.dup();
/*      */           
/*  575 */           for (JExpr constructorArgument : constructorArguments) {
/*  576 */             constructorArgument.load(mv);
/*      */           }
/*      */           
/*  579 */           mv.invokeconstructor(classType, argumentTypes);
/*      */         }
/*      */       };
/*      */   }
/*      */   public static JExpr newObject(Class classType, String constructorDescriptor, JExpr... constructorArguments) {
/*  584 */     return newObject(Type.getType(classType), constructorDescriptor, constructorArguments);
/*      */   }
/*      */   
/*      */   public static JExpr newObject(final Type classType, final String constructorDescriptor, JExpr... constructorArguments) {
/*  588 */     return new JExpr()
/*      */       {
/*      */         @Nonnull
/*      */         public Type getType() {
/*  592 */           return classType;
/*      */         }
/*      */ 
/*      */         
/*      */         public void load(@Nonnull MethodGenerator mv) {
/*  597 */           mv.anew(classType);
/*  598 */           mv.dup();
/*      */           
/*  600 */           for (JExpr constructorArgument : constructorArguments) {
/*  601 */             constructorArgument.load(mv);
/*      */           }
/*      */           
/*  604 */           mv.invokespecial(classType.getInternalName(), "<init>", constructorDescriptor, false);
/*      */         }
/*      */       };
/*      */   }
/*      */   
/*      */   public static JExpr shiftRight(JExpr x, int bits) {
/*  610 */     if (bits == 0) {
/*  611 */       return x;
/*      */     }
/*  613 */     return shiftRight(x, constantInt(bits));
/*      */   }
/*      */   
/*      */   public static JExpr shiftRight(JExpr x, JExpr bits) {
/*  617 */     return binary(122, x, bits, promoteSmallInts(x.getType()));
/*      */   }
/*      */   
/*      */   public static JExpr shiftLeft(JExpr x, JExpr bits) {
/*  621 */     return binary(120, x, bits, promoteSmallInts(x.getType()));
/*      */   }
/*      */   
/*      */   public static JExpr unsignedShiftRight(JExpr jexpr, JExpr bits) {
/*  625 */     return binary(124, jexpr, bits, promoteSmallInts(jexpr.getType()));
/*      */   }
/*      */   
/*      */   public static JLValue localVariable(final Type type, final int index) {
/*  629 */     return new JLValue()
/*      */       {
/*      */         @Nonnull
/*      */         public Type getType()
/*      */         {
/*  634 */           return type;
/*      */         }
/*      */ 
/*      */         
/*      */         public void load(@Nonnull MethodGenerator mv) {
/*  639 */           mv.load(index, type);
/*      */         }
/*      */ 
/*      */         
/*      */         public void store(MethodGenerator mv, JExpr rhs) {
/*  644 */           rhs.load(mv);
/*  645 */           mv.store(index, type);
/*      */         }
/*      */       };
/*      */   }
/*      */   
/*      */   public static JExpr identityHash(JExpr value) {
/*  651 */     if (value.getType().getSort() != 10 && value
/*  652 */       .getType().getSort() != 9) {
/*  653 */       throw new IllegalArgumentException("value must have a reference type: " + value.getType());
/*      */     }
/*      */     
/*  656 */     return staticMethodCall(System.class, "identityHashCode", 
/*  657 */         Type.getMethodDescriptor(Type.INT_TYPE, new Type[] { Type.getType(Object.class) }), new JExpr[] { value });
/*      */   }
/*      */   
/*      */   public static JExpr numberOfLeadingZeros(JExpr value) {
/*  661 */     checkType("value", value, Type.INT_TYPE);
/*      */     
/*  663 */     return staticMethodCall(Type.getType(Integer.class), "numberOfLeadingZeros", 
/*  664 */         Type.getMethodDescriptor(Type.INT_TYPE, new Type[] { Type.INT_TYPE }), new JExpr[] { value });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static JExpr methodCall(final JExpr instance, final Class declaringType, final String methodName, final String descriptor, JExpr... arguments) {
/*  673 */     return new JExpr()
/*      */       {
/*      */         @Nonnull
/*      */         public Type getType() {
/*  677 */           return Type.getReturnType(descriptor);
/*      */         }
/*      */ 
/*      */         
/*      */         public void load(@Nonnull MethodGenerator mv) {
/*  682 */           instance.load(mv);
/*  683 */           for (JExpr argument : arguments) {
/*  684 */             argument.load(mv);
/*      */           }
/*  686 */           if (declaringType.isInterface()) {
/*  687 */             mv.invokeinterface(Type.getInternalName(declaringType), methodName, descriptor);
/*      */           } else {
/*  689 */             mv.invokevirtual(Type.getType(declaringType), methodName, descriptor, false);
/*      */           } 
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */   
/*      */   public static JExpr staticMethodCall(Class declaringType, String methodName, String descriptor, JExpr... arguments) {
/*  697 */     return staticMethodCall(Type.getType(declaringType), methodName, descriptor, arguments);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static JExpr staticMethodCall(final Type declaringType, final String methodName, final String descriptor, JExpr... arguments) {
/*  705 */     if ((Type.getArgumentTypes(descriptor)).length != arguments.length) {
/*  706 */       throw new IllegalArgumentException(String.format("Call to %s.%s(%s) with incorrect number of arguments [%d]", new Object[] { declaringType
/*  707 */               .getInternalName(), methodName, 
/*      */               
/*  709 */               Arrays.toString(Type.getArgumentTypes(descriptor)), 
/*  710 */               Integer.valueOf(arguments.length) }));
/*      */     }
/*      */     
/*  713 */     return new JExpr()
/*      */       {
/*      */         @Nonnull
/*      */         public Type getType() {
/*  717 */           return Type.getReturnType(descriptor);
/*      */         }
/*      */ 
/*      */         
/*      */         public void load(@Nonnull MethodGenerator mv) {
/*  722 */           for (JExpr argument : arguments) {
/*  723 */             argument.load(mv);
/*      */           }
/*  725 */           mv.invokestatic(declaringType, methodName, descriptor);
/*      */         }
/*      */       };
/*      */   }
/*      */   
/*      */   public static JLValue staticField(Field field) {
/*  731 */     if (!Modifier.isStatic(field.getModifiers())) {
/*  732 */       throw new IllegalArgumentException(field + " must be static");
/*      */     }
/*  734 */     Type declaringType = Type.getType(field.getDeclaringClass());
/*  735 */     Type fieldType = Type.getType(field.getType());
/*  736 */     String fieldName = field.getName();
/*      */     
/*  738 */     return staticField(declaringType, fieldName, fieldType);
/*      */   }
/*      */ 
/*      */   
/*      */   public static JLValue staticField(final Type declaringType, final String fieldName, final Type fieldType) {
/*  743 */     if (declaringType.getSort() != 10) {
/*  744 */       throw new IllegalArgumentException(declaringType + " is not a class");
/*      */     }
/*      */     
/*  747 */     return new JLValue()
/*      */       {
/*      */         @Nonnull
/*      */         public Type getType()
/*      */         {
/*  752 */           return fieldType;
/*      */         }
/*      */ 
/*      */         
/*      */         public void load(@Nonnull MethodGenerator mv) {
/*  757 */           mv.getstatic(declaringType.getInternalName(), fieldName, fieldType.getDescriptor());
/*      */         }
/*      */ 
/*      */         
/*      */         public void store(MethodGenerator mv, JExpr expr) {
/*  762 */           expr.load(mv);
/*  763 */           mv.putstatic(declaringType.getInternalName(), fieldName, fieldType.getDescriptor());
/*      */         }
/*      */       };
/*      */   }
/*      */   
/*      */   public static JExpr bitwiseXor(JExpr x, int y) {
/*  769 */     return bitwiseXor(x, constantInt(y));
/*      */   }
/*      */   
/*      */   public static JExpr bitwiseXor(JExpr x, JExpr y) {
/*  773 */     return new BinaryOpExpr(130, x, y);
/*      */   }
/*      */   
/*      */   public static JExpr flip(JExpr value) {
/*  777 */     switch (value.getType().getSort()) {
/*      */       case 3:
/*  779 */         return bitwiseXor(value, constantInt(-128));
/*      */       case 4:
/*  781 */         return bitwiseXor(value, constantInt(-32768));
/*      */       case 5:
/*  783 */         return bitwiseXor(value, constantInt(-2147483648));
/*      */       case 7:
/*  785 */         return bitwiseXor(value, constantLong(Long.MIN_VALUE));
/*      */     } 
/*  787 */     throw new UnsupportedOperationException("type: " + value.getType());
/*      */   }
/*      */ 
/*      */   
/*      */   public static JExpr constantClass(final Type valueType) {
/*  792 */     Preconditions.checkArgument((valueType.getSort() == 10 || valueType.getSort() == 9), "Expected valueType to be an OBJECT or ARRAY sort");
/*      */ 
/*      */     
/*  795 */     return new JExpr()
/*      */       {
/*      */         @Nonnull
/*      */         public Type getType() {
/*  799 */           return Type.getType(Class.class);
/*      */         }
/*      */ 
/*      */         
/*      */         public void load(@Nonnull MethodGenerator mv) {
/*  804 */           mv.aconst(valueType);
/*      */         }
/*      */       };
/*      */   }
/*      */   
/*      */   public static JExpr max(final JExpr x, final JExpr y) {
/*  810 */     final Type type = x.getType();
/*  811 */     if (!type.equals(y.getType())) {
/*  812 */       throw new IllegalArgumentException(type + " != " + y.getType());
/*      */     }
/*  814 */     if (x instanceof ConstantValue && y instanceof ConstantValue && 
/*  815 */       type.equals(Type.INT_TYPE)) {
/*  816 */       return new ConstantValue(type, Integer.valueOf(Math.max(((ConstantValue)x).getIntValue(), ((ConstantValue)y).getIntValue())));
/*      */     }
/*      */ 
/*      */     
/*  820 */     return new JExpr()
/*      */       {
/*      */         @Nonnull
/*      */         public Type getType() {
/*  824 */           return type;
/*      */         }
/*      */ 
/*      */         
/*      */         public void load(@Nonnull MethodGenerator mv) {
/*  829 */           x.load(mv);
/*  830 */           y.load(mv);
/*  831 */           mv.invokestatic(Math.class, "max", Type.getMethodDescriptor(type, new Type[] { this.val$type, this.val$type }));
/*      */         }
/*      */       };
/*      */   }
/*      */   
/*      */   public static boolean requiresCast(Type fromType, Type toType) {
/*  837 */     if (fromType.equals(toType)) {
/*  838 */       return false;
/*      */     }
/*      */     
/*  841 */     if (promoteSmallInts(fromType).equals(promoteSmallInts(toType))) {
/*  842 */       return false;
/*      */     }
/*      */     
/*  845 */     if (toType.equals(Type.getType(Object.class)) && (
/*  846 */       fromType.getSort() == 9 || fromType.getSort() == 10)) {
/*  847 */       return false;
/*      */     }
/*      */ 
/*      */     
/*  851 */     if (fromType.getSort() == 10 && toType.getSort() == 10) {
/*  852 */       return !isDefinitelySubclass(fromType, toType);
/*      */     }
/*      */     
/*  855 */     if (fromType.getSort() == 9 && toType.getSort() == 9) {
/*  856 */       return true;
/*      */     }
/*      */     
/*  859 */     throw new IllegalStateException(fromType + " will never be assignable to " + toType);
/*      */   }
/*      */   private static boolean isDefinitelySubclass(Type fromType, Type toType) {
/*      */     Class<?> fromClass;
/*      */     Class<?> toClass;
/*      */     try {
/*  865 */       fromClass = Class.forName(fromType.getClassName());
/*  866 */     } catch (ClassNotFoundException e) {
/*  867 */       return false;
/*      */     } 
/*      */ 
/*      */     
/*      */     try {
/*  872 */       toClass = Class.forName(toType.getClassName());
/*  873 */     } catch (ClassNotFoundException e) {
/*  874 */       return false;
/*      */     } 
/*      */     
/*  877 */     return toClass.isAssignableFrom(fromClass);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static JExpr i2b(JExpr expr) {
/*  884 */     return unaryOp(expr, Type.INT_TYPE, 145, Type.BYTE_TYPE);
/*      */   }
/*      */   
/*      */   public static JExpr i2c(JExpr jexpr) {
/*  888 */     return unaryOp(jexpr, Type.INT_TYPE, 146, Type.CHAR_TYPE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static JExpr i2s(JExpr expr) {
/*  896 */     return unaryOp(expr, Type.INT_TYPE, 147, Type.SHORT_TYPE);
/*      */   }
/*      */   
/*      */   public static JExpr f2d(JExpr expr) {
/*  900 */     return unaryOp(expr, Type.FLOAT_TYPE, 141, Type.DOUBLE_TYPE);
/*      */   }
/*      */   
/*      */   public static JExpr d2f(JExpr expr) {
/*  904 */     return unaryOp(expr, Type.DOUBLE_TYPE, 144, Type.FLOAT_TYPE);
/*      */   }
/*      */   
/*      */   public static JExpr d2i(JExpr expr) {
/*  908 */     return unaryOp(expr, Type.DOUBLE_TYPE, 142, Type.INT_TYPE);
/*      */   }
/*      */   
/*      */   public static JExpr d2l(JExpr expr) {
/*  912 */     return unaryOp(expr, Type.DOUBLE_TYPE, 143, Type.LONG_TYPE);
/*      */   }
/*      */   
/*      */   public static JExpr f2i(JExpr expr) {
/*  916 */     return unaryOp(expr, Type.FLOAT_TYPE, 139, Type.INT_TYPE);
/*      */   }
/*      */   public static JExpr f2l(JExpr expr) {
/*  919 */     return unaryOp(expr, Type.FLOAT_TYPE, 140, Type.LONG_TYPE);
/*      */   }
/*      */ 
/*      */   
/*      */   public static JExpr l2d(JExpr jexpr) {
/*  924 */     return unaryOp(jexpr, Type.LONG_TYPE, 138, Type.DOUBLE_TYPE);
/*      */   }
/*      */   public static JExpr l2f(JExpr jexpr) {
/*  927 */     return unaryOp(jexpr, Type.LONG_TYPE, 137, Type.FLOAT_TYPE);
/*      */   }
/*      */   
/*      */   public static JExpr l2i(JExpr jexpr) {
/*  931 */     return unaryOp(jexpr, Type.LONG_TYPE, 136, Type.INT_TYPE);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static JExpr unaryOp(final JExpr expr, Type expectedArgumentType, final int opcode, final Type resultType) {
/*  937 */     assert promoteSmallInts(expr.getType()).equals(expectedArgumentType) : "Expected " + expectedArgumentType + ", found: " + expr
/*  938 */       .getType();
/*  939 */     return new JExpr()
/*      */       {
/*      */         @Nonnull
/*      */         public Type getType() {
/*  943 */           return resultType;
/*      */         }
/*      */ 
/*      */         
/*      */         public void load(@Nonnull MethodGenerator mv) {
/*  948 */           expr.load(mv);
/*  949 */           mv.visitInsn(opcode);
/*      */         }
/*      */       };
/*      */   }
/*      */   
/*      */   public static JExpr remainder(JExpr x, JExpr y) {
/*  955 */     return binary(112, x, y, promoteSmallInts(x.getType()));
/*      */   }
/*      */ 
/*      */   
/*      */   public static JExpr negative(final JExpr jexpr) {
/*  960 */     return new JExpr()
/*      */       {
/*      */         @Nonnull
/*      */         public Type getType() {
/*  964 */           return Expressions.promoteSmallInts(jexpr.getType());
/*      */         }
/*      */ 
/*      */         
/*      */         public void load(@Nonnull MethodGenerator mv) {
/*  969 */           jexpr.load(mv);
/*  970 */           mv.visitInsn(jexpr.getType().getOpcode(116));
/*      */         }
/*      */       };
/*      */   }
/*      */   
/*      */   public static JExpr i2f(JExpr jexpr) {
/*  976 */     return unaryOp(jexpr, Type.INT_TYPE, 134, Type.FLOAT_TYPE);
/*      */   }
/*      */   
/*      */   public static JExpr i2l(JExpr jexpr) {
/*  980 */     return unaryOp(jexpr, Type.INT_TYPE, 133, Type.LONG_TYPE);
/*      */   }
/*      */   
/*      */   public static JExpr i2d(JExpr jexpr) {
/*  984 */     return unaryOp(jexpr, Type.INT_TYPE, 135, Type.DOUBLE_TYPE);
/*      */   }
/*      */ 
/*      */   
/*      */   public static JExpr bitwiseAnd(JExpr expr, int mask) {
/*  989 */     return bitwiseAnd(expr, constantInt(mask));
/*      */   }
/*      */   
/*      */   public static JExpr bitwiseOr(JExpr x, JExpr y) {
/*  993 */     return bitwiseOp(128, x, y);
/*      */   }
/*      */   
/*      */   public static JExpr bitwiseAnd(JExpr x, JExpr y) {
/*  997 */     if (x instanceof ConstantValue && y instanceof ConstantValue) {
/*  998 */       ConstantValue cx = (ConstantValue)x;
/*  999 */       ConstantValue cy = (ConstantValue)y;
/* 1000 */       if (x.getType().equals(Type.INT_TYPE)) {
/* 1001 */         return constantInt(cx.getIntValue() & cy.getIntValue());
/*      */       }
/*      */     } 
/* 1004 */     return bitwiseOp(126, x, y);
/*      */   }
/*      */ 
/*      */   
/*      */   private static JExpr bitwiseOp(final int opcode, final JExpr x, final JExpr y) {
/* 1009 */     return new JExpr()
/*      */       {
/*      */         @Nonnull
/*      */         public Type getType() {
/* 1013 */           return Expressions.promoteSmallInts(x.getType());
/*      */         }
/*      */ 
/*      */         
/*      */         public void load(@Nonnull MethodGenerator mv) {
/* 1018 */           x.load(mv);
/* 1019 */           y.load(mv);
/* 1020 */           mv.visitInsn(Expressions.promoteSmallInts(x.getType()).getOpcode(opcode));
/*      */         }
/*      */       };
/*      */   }
/*      */   
/*      */   public static JExpr lcmp(final JExpr x, final JExpr y) {
/* 1026 */     assert x.getType().equals(Type.LONG_TYPE);
/* 1027 */     assert y.getType().equals(Type.LONG_TYPE);
/*      */     
/* 1029 */     return new JExpr()
/*      */       {
/*      */         @Nonnull
/*      */         public Type getType() {
/* 1033 */           return Type.INT_TYPE;
/*      */         }
/*      */ 
/*      */         
/*      */         public void load(@Nonnull MethodGenerator mv) {
/* 1038 */           x.load(mv);
/* 1039 */           y.load(mv);
/* 1040 */           mv.visitInsn(148);
/*      */         }
/*      */       };
/*      */   }
/*      */   
/*      */   public static JExpr cmpg(JExpr x, JExpr y) {
/* 1046 */     assert x.getType().equals(y.getType());
/* 1047 */     switch (x.getType().getSort()) {
/*      */       case 6:
/* 1049 */         return floatingPointComparison(150, x, y);
/*      */       case 8:
/* 1051 */         return floatingPointComparison(152, x, y);
/*      */     } 
/* 1053 */     throw new UnsupportedOperationException("type: " + x.getType());
/*      */   }
/*      */ 
/*      */   
/*      */   public static JExpr cmpl(JExpr x, JExpr y) {
/* 1058 */     assert x.getType().equals(y.getType());
/* 1059 */     switch (x.getType().getSort()) {
/*      */       case 6:
/* 1061 */         return floatingPointComparison(149, x, y);
/*      */       case 8:
/* 1063 */         return floatingPointComparison(151, x, y);
/*      */     } 
/* 1065 */     throw new UnsupportedOperationException("type: " + x.getType());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static JExpr floatingPointComparison(final int opcode, final JExpr x, final JExpr y) {
/* 1073 */     return new JExpr()
/*      */       {
/*      */         @Nonnull
/*      */         public Type getType() {
/* 1077 */           return Type.INT_TYPE;
/*      */         }
/*      */ 
/*      */         
/*      */         public void load(@Nonnull MethodGenerator mv) {
/* 1082 */           x.load(mv);
/* 1083 */           y.load(mv);
/* 1084 */           mv.visitInsn(opcode);
/*      */         }
/*      */       };
/*      */   }
/*      */   
/*      */   public static JExpr compareTo(JExpr x, JExpr y) {
/* 1090 */     return methodCall(x, Comparable.class, "compareTo", 
/* 1091 */         Type.getMethodDescriptor(Type.INT_TYPE, new Type[] { Type.getType(Object.class) }), new JExpr[] { y });
/*      */   }
/*      */   
/*      */   public static JExpr objectEquals(JExpr x, JExpr y) {
/* 1095 */     return methodCall(x, Object.class, "equals", 
/* 1096 */         Type.getMethodDescriptor(Type.BOOLEAN_TYPE, new Type[] { Type.getType(Object.class) }), new JExpr[] { y });
/*      */   }
/*      */   
/*      */   public static JExpr constantFloat(final float v) {
/* 1100 */     return new JExpr()
/*      */       {
/*      */         @Nonnull
/*      */         public Type getType() {
/* 1104 */           return Type.FLOAT_TYPE;
/*      */         }
/*      */ 
/*      */         
/*      */         public void load(@Nonnull MethodGenerator mv) {
/* 1109 */           mv.fconst(v);
/*      */         }
/*      */       };
/*      */   }
/*      */   
/*      */   public static JExpr constantDouble(final double v) {
/* 1115 */     return new JExpr()
/*      */       {
/*      */         @Nonnull
/*      */         public Type getType() {
/* 1119 */           return Type.DOUBLE_TYPE;
/*      */         }
/*      */ 
/*      */         
/*      */         public void load(@Nonnull MethodGenerator mv) {
/* 1124 */           mv.dconst(v);
/*      */         }
/*      */       };
/*      */   }
/*      */   
/*      */   public static JExpr constantString(final String string) {
/* 1130 */     return new JExpr()
/*      */       {
/*      */         @Nonnull
/*      */         public Type getType() {
/* 1134 */           return Type.getType(String.class);
/*      */         }
/*      */ 
/*      */         
/*      */         public void load(@Nonnull MethodGenerator mv) {
/* 1139 */           mv.aconst(string);
/*      */         }
/*      */       };
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/expr/Expressions.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */