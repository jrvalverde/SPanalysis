/*    */ package org.renjin.gcc.gimple.type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractGimpleType
/*    */   implements GimpleType
/*    */ {
/*    */   private int size;
/*    */   
/*    */   public final int getSize() {
/* 30 */     return this.size;
/*    */   }
/*    */   
/*    */   public void setSize(long size) {
/* 34 */     if (size > 2147483647L) {
/*    */ 
/*    */       
/* 37 */       this.size = Integer.MAX_VALUE;
/*    */     } else {
/* 39 */       this.size = (int)size;
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isPointerTo(Class<? extends GimpleType> clazz) {
/* 45 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public <X extends GimpleType> X getBaseType() {
/* 50 */     throw new UnsupportedOperationException("this is not pointer type (" + getClass().getSimpleName() + ")");
/*    */   }
/*    */ 
/*    */   
/*    */   public GimplePointerType pointerTo() {
/* 55 */     return new GimplePointerType(this);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/gimple/type/AbstractGimpleType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */