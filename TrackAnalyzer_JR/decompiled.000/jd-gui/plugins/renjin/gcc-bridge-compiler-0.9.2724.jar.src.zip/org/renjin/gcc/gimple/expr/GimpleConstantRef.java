/*    */ package org.renjin.gcc.gimple.expr;
/*    */ 
/*    */ import java.util.function.Predicate;
/*    */ import org.renjin.gcc.gimple.GimpleExprVisitor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GimpleConstantRef
/*    */   extends GimpleExpr
/*    */ {
/*    */   private GimpleConstant value;
/*    */   
/*    */   public GimpleConstant getValue() {
/* 28 */     return this.value;
/*    */   }
/*    */   
/*    */   public void setValue(GimpleConstant value) {
/* 32 */     this.value = value;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 37 */     return this.value.toString();
/*    */   }
/*    */ 
/*    */   
/*    */   public void replaceAll(Predicate<? super GimpleExpr> predicate, GimpleExpr newExpr) {
/* 42 */     this.value = (GimpleConstant)replaceOrDescend(this.value, predicate, newExpr);
/*    */   }
/*    */ 
/*    */   
/*    */   public void accept(GimpleExprVisitor visitor) {
/* 47 */     visitor.visitConstantRef(this);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/gimple/expr/GimpleConstantRef.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */