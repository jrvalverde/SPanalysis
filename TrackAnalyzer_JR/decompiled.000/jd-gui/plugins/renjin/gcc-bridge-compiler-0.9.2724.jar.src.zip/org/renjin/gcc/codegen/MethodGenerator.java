/*     */ package org.renjin.gcc.codegen;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import org.renjin.gcc.codegen.expr.JExpr;
/*     */ import org.renjin.gcc.codegen.var.LocalVarAllocator;
/*     */ import org.renjin.repackaged.asm.MethodVisitor;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ import org.renjin.repackaged.asm.commons.InstructionAdapter;
/*     */ import org.renjin.repackaged.guava.base.Preconditions;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MethodGenerator
/*     */   extends InstructionAdapter
/*     */ {
/*  34 */   private final LocalVarAllocator localVarAllocator = new LocalVarAllocator();
/*     */   private final Type ownerClass;
/*     */   
/*     */   public MethodGenerator(Type ownerClass, MethodVisitor mv) {
/*  38 */     super(327680, mv);
/*  39 */     this.ownerClass = ownerClass;
/*     */   }
/*     */   
/*     */   public MethodGenerator(String className, MethodVisitor mv) {
/*  43 */     this(Type.getType("L" + className + ";"), mv);
/*     */   }
/*     */   
/*     */   public Type getOwnerClass() {
/*  47 */     return this.ownerClass;
/*     */   }
/*     */   
/*     */   public LocalVarAllocator getLocalVarAllocator() {
/*  51 */     return this.localVarAllocator;
/*     */   }
/*     */   
/*     */   public void invokestatic(Class<?> ownerClass, String methodName, String descriptor) {
/*  55 */     invokestatic(Type.getInternalName(ownerClass), methodName, descriptor, false);
/*     */   }
/*     */   
/*     */   public void invokestatic(Type ownerClass, String methodName, String descriptor) {
/*  59 */     invokestatic(ownerClass.getInternalName(), methodName, descriptor, false);
/*     */   }
/*     */   
/*     */   public void invokeconstructor(Type ownerClass, Type... argumentTypes) {
/*  63 */     invokespecial(ownerClass.getInternalName(), "<init>", Type.getMethodDescriptor(Type.VOID_TYPE, argumentTypes), false);
/*     */   }
/*     */   
/*     */   public void invokevirtual(Type declaringType, String methodName, String descriptor, boolean interfaceMethod) {
/*  67 */     invokevirtual(declaringType.getInternalName(), methodName, descriptor, interfaceMethod);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void invokevirtual(Class<?> declaringClass, String methodName, Type returnType, Type... argumentTypes) {
/*  74 */     invokevirtual(Type.getType(declaringClass).getInternalName(), methodName, 
/*     */         
/*  76 */         Type.getMethodDescriptor(returnType, argumentTypes), declaringClass
/*  77 */         .isInterface());
/*     */   }
/*     */   
/*     */   public void invokeinterface(Class<?> declaringClass, String methodName, Type returnType, Type... argumentTypes) {
/*  81 */     invokeinterface(Type.getType(declaringClass).getInternalName(), methodName, 
/*     */         
/*  83 */         Type.getMethodDescriptor(returnType, argumentTypes));
/*     */   }
/*     */   
/*     */   public void invokeIdentityHashCode() {
/*  87 */     invokestatic(System.class, "identityHashCode", "(Ljava/lang/Object;)I");
/*     */   }
/*     */   
/*     */   public void putfield(Type declaringClass, String name, Type fieldType) {
/*  91 */     putfield(declaringClass.getInternalName(), name, fieldType.getDescriptor());
/*     */   }
/*     */   
/*     */   public void getfield(Type ownerClass, String fieldName, Type fieldType) {
/*  95 */     getfield(ownerClass.getInternalName(), fieldName, fieldType.getDescriptor());
/*     */   }
/*     */   
/*     */   public void pop(Type type) {
/*  99 */     switch (type.getSort()) {
/*     */       case 0:
/*     */         return;
/*     */ 
/*     */       
/*     */       case 7:
/*     */       case 8:
/* 106 */         pop2();
/*     */     } 
/*     */ 
/*     */     
/* 110 */     pop();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void arrayCopy(JExpr src, JExpr srcPos, JExpr dest, JExpr destPos, JExpr length) {
/* 125 */     Preconditions.checkArgument(srcPos.getType().equals(Type.INT_TYPE), "srcPos must have type int");
/* 126 */     Preconditions.checkArgument(destPos.getType().equals(Type.INT_TYPE), "destPos must have type int");
/* 127 */     Preconditions.checkArgument(length.getType().equals(Type.INT_TYPE), "length must have type int");
/*     */     
/* 129 */     src.load(this);
/* 130 */     srcPos.load(this);
/* 131 */     dest.load(this);
/* 132 */     destPos.load(this);
/* 133 */     length.load(this);
/*     */     
/* 135 */     invokestatic(System.class, "arraycopy", Type.getMethodDescriptor(Type.VOID_TYPE, new Type[] {
/* 136 */             Type.getType(Object.class), Type.INT_TYPE, 
/* 137 */             Type.getType(Object.class), Type.INT_TYPE, Type.INT_TYPE
/*     */           }));
/*     */   }
/*     */ 
/*     */   
/*     */   public void fillArray(JExpr array, JExpr fromIndex, JExpr toIndex, JExpr value) {
/* 143 */     Preconditions.checkArgument((array.getType().getSort() == 9), "array must have sort ARRAY");
/* 144 */     Preconditions.checkArgument((fromIndex.getType().getSort() == 5), "fromIndex must have type int");
/* 145 */     Preconditions.checkArgument((toIndex.getType().getSort() == 5), "toIndex must have type int");
/*     */     
/* 147 */     int elementSort = array.getType().getElementType().getSort();
/*     */     
/* 149 */     array.load(this);
/* 150 */     fromIndex.load(this);
/* 151 */     toIndex.load(this);
/* 152 */     value.load(this);
/*     */     
/* 154 */     if (elementSort == 10 || elementSort == 9) {
/*     */       
/* 156 */       invokestatic(Arrays.class, "fill", Type.getMethodDescriptor(Type.VOID_TYPE, new Type[] {
/* 157 */               Type.getType(Object[].class), Type.INT_TYPE, Type.INT_TYPE, 
/*     */ 
/*     */               
/* 160 */               Type.getType(Object.class)
/*     */             }));
/*     */     } else {
/* 163 */       throw new UnsupportedOperationException("TODO");
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/MethodGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */