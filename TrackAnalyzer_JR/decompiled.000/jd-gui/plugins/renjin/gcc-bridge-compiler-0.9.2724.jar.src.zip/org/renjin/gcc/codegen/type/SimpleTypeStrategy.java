package org.renjin.gcc.codegen.type;

import org.renjin.gcc.codegen.expr.JExpr;
import org.renjin.repackaged.asm.Type;

public interface SimpleTypeStrategy<ExprT extends org.renjin.gcc.codegen.expr.GExpr> extends TypeStrategy<ExprT> {
  Type getJvmType();
  
  ExprT wrap(JExpr paramJExpr);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/type/SimpleTypeStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */