/*    */ package org.renjin.gcc.codegen.call;
/*    */ 
/*    */ import org.renjin.gcc.codegen.MethodGenerator;
/*    */ import org.renjin.gcc.codegen.expr.ExprFactory;
/*    */ import org.renjin.gcc.codegen.expr.GExpr;
/*    */ import org.renjin.gcc.codegen.expr.JExpr;
/*    */ import org.renjin.gcc.codegen.expr.PtrExpr;
/*    */ import org.renjin.gcc.codegen.type.TypeOracle;
/*    */ import org.renjin.gcc.codegen.type.fun.FunctionRefGenerator;
/*    */ import org.renjin.gcc.gimple.expr.GimpleExpr;
/*    */ import org.renjin.gcc.gimple.statement.GimpleCall;
/*    */ import org.renjin.gcc.gimple.type.GimpleType;
/*    */ import org.renjin.gcc.runtime.Realloc;
/*    */ import org.renjin.repackaged.asm.Handle;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReallocCallGenerator
/*    */   implements CallGenerator, MethodHandleGenerator
/*    */ {
/*    */   private TypeOracle typeOracle;
/*    */   
/*    */   public ReallocCallGenerator(TypeOracle typeOracle) {
/* 46 */     this.typeOracle = typeOracle;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void emitCall(MethodGenerator mv, ExprFactory exprFactory, GimpleCall call) {
/* 53 */     if (call.getLhs() == null) {
/*    */       return;
/*    */     }
/*    */ 
/*    */     
/* 58 */     GimpleType pointerType = call.getLhs().getType();
/*    */ 
/*    */     
/* 61 */     PtrExpr pointer = (PtrExpr)exprFactory.findGenerator(call.getOperand(0));
/* 62 */     JExpr size = exprFactory.findPrimitiveGenerator(call.getOperand(1));
/*    */     
/* 64 */     PtrExpr ptrExpr1 = pointer.realloc(mv, size);
/*    */     
/* 66 */     GExpr lhs = exprFactory.findGenerator((GimpleExpr)call.getLhs());
/* 67 */     lhs.store(mv, (GExpr)ptrExpr1);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public JExpr getMethodHandle() {
/* 73 */     return (JExpr)new FunctionRefGenerator(new Handle(6, 
/* 74 */           Type.getInternalName(Realloc.class), "realloc", 
/* 75 */           Type.getMethodDescriptor(Type.getType(Object.class), new Type[] { Type.getType(Object.class), Type.INT_TYPE })));
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/call/ReallocCallGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */