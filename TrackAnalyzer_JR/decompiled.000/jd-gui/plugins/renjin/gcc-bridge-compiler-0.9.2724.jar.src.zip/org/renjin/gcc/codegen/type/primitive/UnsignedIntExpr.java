/*     */ package org.renjin.gcc.codegen.type.primitive;
/*     */ 
/*     */ import javax.annotation.Nullable;
/*     */ import org.renjin.gcc.codegen.MethodGenerator;
/*     */ import org.renjin.gcc.codegen.condition.Comparison;
/*     */ import org.renjin.gcc.codegen.condition.ConditionGenerator;
/*     */ import org.renjin.gcc.codegen.condition.IntegerComparison;
/*     */ import org.renjin.gcc.codegen.expr.Expressions;
/*     */ import org.renjin.gcc.codegen.expr.GExpr;
/*     */ import org.renjin.gcc.codegen.expr.JExpr;
/*     */ import org.renjin.gcc.codegen.expr.JLValue;
/*     */ import org.renjin.gcc.codegen.expr.PtrExpr;
/*     */ import org.renjin.gcc.codegen.type.NumericExpr;
/*     */ import org.renjin.gcc.gimple.GimpleOp;
/*     */ import org.renjin.gcc.gimple.type.GimpleIntegerType;
/*     */ import org.renjin.gcc.gimple.type.GimplePrimitiveType;
/*     */ import org.renjin.gcc.runtime.IntPtr;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UnsignedIntExpr
/*     */   extends AbstractIntExpr
/*     */ {
/*     */   public UnsignedIntExpr(JExpr jexpr, @Nullable PtrExpr address) {
/*  39 */     super(jexpr, address);
/*     */   }
/*     */   
/*     */   public UnsignedIntExpr(JExpr jexpr) {
/*  43 */     this(jexpr, (PtrExpr)null);
/*     */   }
/*     */   
/*     */   private UnsignedIntExpr lift(JExpr expr) {
/*  47 */     return new UnsignedIntExpr(expr);
/*     */   }
/*     */ 
/*     */   
/*     */   public UnsignedIntExpr plus(GExpr operand) {
/*  52 */     return lift(Expressions.sum(jexpr(), jexpr(operand)));
/*     */   }
/*     */   
/*     */   private JExpr jexpr(GExpr operand) {
/*  56 */     return operand.toPrimitiveExpr().toUnsignedInt(32).jexpr();
/*     */   }
/*     */   
/*     */   private JExpr jlongExpr() {
/*  60 */     return Expressions.staticMethodCall(Integer.class, "toUnsignedLong", "(I)J", new JExpr[] { jexpr() });
/*     */   }
/*     */ 
/*     */   
/*     */   public UnsignedIntExpr minus(GExpr operand) {
/*  65 */     return lift(Expressions.difference(jexpr(), jexpr(operand)));
/*     */   }
/*     */ 
/*     */   
/*     */   public UnsignedIntExpr multiply(GExpr operand) {
/*  70 */     return lift(Expressions.product(jexpr(), jexpr(operand)));
/*     */   }
/*     */ 
/*     */   
/*     */   public UnsignedIntExpr divide(GExpr operand) {
/*  75 */     return lift(Expressions.staticMethodCall(Integer.class, "divideUnsigned", "(II)I", new JExpr[] { jexpr(), jexpr(operand) }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UnsignedIntExpr negative() {
/*  82 */     return lift(Expressions.negative(jexpr()));
/*     */   }
/*     */ 
/*     */   
/*     */   public UnsignedIntExpr min(GExpr operand) {
/*  87 */     return lift(Expressions.staticMethodCall(IntPtr.class, "unsignedMin", "(II)I", new JExpr[] { jexpr(), jexpr(operand) }));
/*     */   }
/*     */ 
/*     */   
/*     */   public UnsignedIntExpr max(GExpr operand) {
/*  92 */     return lift(Expressions.staticMethodCall(IntPtr.class, "unsignedMax", "(II)I", new JExpr[] { jexpr(), jexpr(operand) }));
/*     */   }
/*     */ 
/*     */   
/*     */   public UnsignedIntExpr absoluteValue() {
/*  97 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public UnsignedIntExpr remainder(GExpr operand) {
/* 102 */     return lift(Expressions.staticMethodCall(Integer.class, "remainderUnsigned", "(II)I", new JExpr[] { jexpr(), jexpr(operand) }));
/*     */   }
/*     */ 
/*     */   
/*     */   public UnsignedIntExpr bitwiseXor(GExpr operand) {
/* 107 */     return lift(Expressions.bitwiseXor(jexpr(), jexpr(operand)));
/*     */   }
/*     */ 
/*     */   
/*     */   public UnsignedIntExpr bitwiseNot() {
/* 112 */     return lift(Expressions.bitwiseXor(jexpr(), -1));
/*     */   }
/*     */ 
/*     */   
/*     */   public UnsignedIntExpr bitwiseAnd(GExpr operand) {
/* 117 */     return lift(Expressions.bitwiseAnd(jexpr(), jexpr(operand)));
/*     */   }
/*     */ 
/*     */   
/*     */   public UnsignedIntExpr bitwiseOr(GExpr operand) {
/* 122 */     return lift(Expressions.bitwiseOr(jexpr(), jexpr(operand)));
/*     */   }
/*     */ 
/*     */   
/*     */   public UnsignedIntExpr shiftLeft(GExpr operand) {
/* 127 */     return lift(Expressions.shiftLeft(jexpr(), jexpr(operand)));
/*     */   }
/*     */ 
/*     */   
/*     */   public UnsignedIntExpr shiftRight(GExpr operand) {
/* 132 */     return lift(Expressions.unsignedShiftRight(jexpr(), jexpr(operand)));
/*     */   }
/*     */ 
/*     */   
/*     */   public UnsignedIntExpr rotateLeft(GExpr operand) {
/* 137 */     return lift(Expressions.staticMethodCall(Integer.class, "rotateLeft", "(II)I", new JExpr[] { jexpr(), bits(operand) }));
/*     */   }
/*     */ 
/*     */   
/*     */   public GimplePrimitiveType getType() {
/* 142 */     return (GimplePrimitiveType)GimpleIntegerType.unsigned(32);
/*     */   }
/*     */ 
/*     */   
/*     */   public RealExpr toRealExpr() {
/* 147 */     return toReal(32);
/*     */   }
/*     */ 
/*     */   
/*     */   public BooleanExpr toBooleanExpr() {
/* 152 */     return BooleanExpr.fromInt(jexpr());
/*     */   }
/*     */ 
/*     */   
/*     */   public IntExpr toSignedInt(int precision) {
/* 157 */     switch (precision) {
/*     */       case 8:
/* 159 */         return new SignedIntExpr(Expressions.i2b(jexpr()));
/*     */       case 16:
/* 161 */         return new SignedIntExpr(Expressions.i2s(jexpr()));
/*     */       case 32:
/* 163 */         return this;
/*     */       case 64:
/* 165 */         return new SignedLongExpr(jlongExpr());
/*     */     } 
/* 167 */     throw new UnsupportedOperationException("32 => " + precision);
/*     */   }
/*     */ 
/*     */   
/*     */   public IntExpr toUnsignedInt(int precision) {
/* 172 */     switch (precision) {
/*     */       case 8:
/* 174 */         return new UnsignedSmallIntExpr(8, Expressions.bitwiseAnd(jexpr(), 255));
/*     */       case 16:
/* 176 */         return new UnsignedSmallIntExpr(16, Expressions.i2c(jexpr()));
/*     */       case 32:
/* 178 */         return this;
/*     */       case 64:
/* 180 */         return new UnsignedLongExpr(jlongExpr());
/*     */     } 
/* 182 */     throw new IllegalArgumentException("precision: " + precision);
/*     */   }
/*     */ 
/*     */   
/*     */   public RealExpr toReal(int precision) {
/* 187 */     return toSignedInt(64).toReal(precision);
/*     */   }
/*     */ 
/*     */   
/*     */   public ConditionGenerator compareTo(GimpleOp op, GExpr operand) {
/* 192 */     switch (op) {
/*     */       case EQ_EXPR:
/*     */       case NE_EXPR:
/* 195 */         return (ConditionGenerator)new IntegerComparison(op, jexpr(), jexpr(operand));
/*     */     } 
/*     */     
/* 198 */     return (ConditionGenerator)new Comparison(op, Expressions.staticMethodCall(Integer.class, "compareUnsigned", "(II)I", new JExpr[] {
/* 199 */             jexpr(), jexpr(operand)
/*     */           }));
/*     */   }
/*     */ 
/*     */   
/*     */   public void store(MethodGenerator mv, GExpr rhs) {
/* 205 */     ((JLValue)jexpr()).store(mv, jexpr(rhs));
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/type/primitive/UnsignedIntExpr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */