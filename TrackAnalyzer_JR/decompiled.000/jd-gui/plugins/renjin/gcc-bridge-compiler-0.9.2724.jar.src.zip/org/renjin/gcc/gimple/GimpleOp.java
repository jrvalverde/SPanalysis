/*     */ package org.renjin.gcc.gimple;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.renjin.gcc.gimple.expr.GimpleExpr;
/*     */ import org.renjin.repackaged.guava.base.Joiner;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum GimpleOp
/*     */ {
/*  31 */   NOP_EXPR
/*     */   {
/*     */     public String format(List<GimpleExpr> operands) {
/*  34 */       return ((GimpleExpr)operands.get(0)).toString();
/*     */     }
/*     */   },
/*     */   
/*  38 */   MULT_EXPR
/*     */   {
/*     */     public String format(List<GimpleExpr> operands) {
/*  41 */       return infix("*", operands);
/*     */     }
/*     */   },
/*     */   
/*  45 */   RDIV_EXPR
/*     */   {
/*     */     public String format(List<GimpleExpr> operands) {
/*  48 */       return infix("/", operands);
/*     */     }
/*     */   },
/*     */   
/*  52 */   ABS_EXPR,
/*     */   
/*  54 */   MIN_EXPR,
/*  55 */   MAX_EXPR,
/*     */   
/*  57 */   ADDR_EXPR
/*     */   {
/*     */     public String format(List<GimpleExpr> operands) {
/*  60 */       assert operands.get(0) instanceof org.renjin.gcc.gimple.expr.GimpleAddressOf;
/*  61 */       return ((GimpleExpr)operands.get(0)).toString();
/*     */     }
/*     */   },
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  68 */   FLOAT_EXPR
/*     */   {
/*     */     public String format(List<GimpleExpr> operands) {
/*  71 */       return "(float)" + operands.get(0);
/*     */     }
/*     */   },
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  78 */   FIX_TRUNC_EXPR
/*     */   {
/*     */     public String format(List<GimpleExpr> operands) {
/*  81 */       return call("trunc", operands);
/*     */     }
/*     */   },
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  91 */   EXACT_DIV_EXPR
/*     */   {
/*     */     public String format(List<GimpleExpr> operands) {
/*  94 */       return infix("/", operands);
/*     */     }
/*     */   },
/*     */   
/*  98 */   TRUNC_DIV_EXPR
/*     */   {
/*     */     public String format(List<GimpleExpr> operands) {
/* 101 */       return infix("/", operands);
/*     */     }
/*     */   },
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 108 */   REAL_CST
/*     */   {
/*     */     public String format(List<GimpleExpr> operands) {
/* 111 */       return "(real)" + operands.get(0);
/*     */     }
/*     */   },
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 118 */   INTEGER_CST
/*     */   {
/*     */     public String format(List<GimpleExpr> operands) {
/* 121 */       return "(int)" + operands.get(0);
/*     */     }
/*     */   },
/*     */   
/* 125 */   STRING_CST
/*     */   {
/*     */     public String format(List<GimpleExpr> operands) {
/* 128 */       return "(string)" + operands.get(0);
/*     */     }
/*     */   },
/*     */   
/* 132 */   NE_EXPR
/*     */   {
/*     */     public String format(List<GimpleExpr> operands) {
/* 135 */       return infix("!=", operands);
/*     */     }
/*     */   },
/*     */   
/* 139 */   EQ_EXPR
/*     */   {
/*     */     public String format(List<GimpleExpr> operands) {
/* 142 */       return infix("==", operands);
/*     */     }
/*     */   },
/* 145 */   LT_EXPR
/*     */   {
/*     */     public String format(List<GimpleExpr> operands) {
/* 148 */       return infix("<", operands);
/*     */     }
/*     */   },
/*     */   
/* 152 */   GT_EXPR
/*     */   {
/*     */     public String format(List<GimpleExpr> operands) {
/* 155 */       return infix(">", operands);
/*     */     }
/*     */   },
/*     */   
/* 159 */   LE_EXPR
/*     */   {
/*     */     public String format(List<GimpleExpr> operands) {
/* 162 */       return infix("<=", operands);
/*     */     }
/*     */   },
/*     */   
/* 166 */   GE_EXPR
/*     */   {
/*     */     public String format(List<GimpleExpr> operands) {
/* 169 */       return infix(">=", operands);
/*     */     }
/*     */   },
/*     */   
/* 173 */   TRUTH_NOT_EXPR
/*     */   {
/*     */     public String format(List<GimpleExpr> operands) {
/* 176 */       return "!" + operands.get(0);
/*     */     }
/*     */   },
/* 179 */   TRUTH_XOR_EXPR
/*     */   {
/*     */     public String format(List<GimpleExpr> operands) {
/* 182 */       return infix("^", operands);
/*     */     }
/*     */   },
/* 185 */   TRUTH_OR_EXPR
/*     */   {
/*     */     public String format(List<GimpleExpr> operands) {
/* 188 */       return infix("||", operands);
/*     */     }
/*     */   },
/* 191 */   TRUTH_AND_EXPR
/*     */   {
/*     */     public String format(List<GimpleExpr> operands) {
/* 194 */       return infix("&&", operands);
/*     */     }
/*     */   },
/*     */   
/* 198 */   POINTER_PLUS_EXPR
/*     */   {
/*     */     public String format(List<GimpleExpr> operands) {
/* 201 */       return infix("+", operands);
/*     */     }
/*     */   },
/*     */   
/* 205 */   INDIRECT_REF,
/*     */ 
/*     */   
/* 208 */   PLUS_EXPR
/*     */   {
/*     */     public String format(List<GimpleExpr> operands) {
/* 211 */       return infix("+", operands);
/*     */     }
/*     */   },
/*     */   
/* 215 */   MINUS_EXPR
/*     */   {
/*     */     public String format(List<GimpleExpr> operands) {
/* 218 */       return infix("-", operands);
/*     */     }
/*     */   },
/*     */   
/* 222 */   SSA_NAME
/*     */   {
/*     */     public String format(List<GimpleExpr> operands) {
/* 225 */       return ((GimpleExpr)operands.get(0)).toString();
/*     */     }
/*     */   },
/*     */   
/* 229 */   PARM_DECL
/*     */   {
/*     */     public String format(List<GimpleExpr> operands) {
/* 232 */       return ((GimpleExpr)operands.get(0)).toString();
/*     */     }
/*     */   },
/*     */   
/* 236 */   VAR_DECL
/*     */   {
/*     */     public String format(List<GimpleExpr> operands) {
/* 239 */       return ((GimpleExpr)operands.get(0)).toString();
/*     */     }
/*     */   },
/*     */   
/* 243 */   COMPONENT_REF
/*     */   {
/*     */     public String format(List<GimpleExpr> operands) {
/* 246 */       assert operands.size() == 1;
/* 247 */       return ((GimpleExpr)operands.get(0)).toString();
/*     */     }
/*     */   },
/*     */   
/* 251 */   ARRAY_REF
/*     */   {
/*     */     public String format(List<GimpleExpr> operands) {
/* 254 */       assert operands.size() == 1;
/* 255 */       return ((GimpleExpr)operands.get(0)).toString();
/*     */     }
/*     */   },
/*     */   
/* 259 */   MEM_REF
/*     */   {
/*     */     public String format(List<GimpleExpr> operands) {
/* 262 */       assert operands.size() == 1;
/* 263 */       return ((GimpleExpr)operands.get(0)).toString();
/*     */     }
/*     */   },
/*     */   
/* 267 */   BIT_NOT_EXPR
/*     */   {
/*     */     public String format(List<GimpleExpr> operands) {
/* 270 */       return "~" + operands.get(0);
/*     */     }
/*     */   },
/* 273 */   BIT_AND_EXPR
/*     */   {
/*     */     public String format(List<GimpleExpr> operands) {
/* 276 */       return infix("&", operands);
/*     */     }
/*     */   },
/*     */   
/* 280 */   BIT_IOR_EXPR
/*     */   {
/*     */     public String format(List<GimpleExpr> operands) {
/* 283 */       return infix("|", operands);
/*     */     }
/*     */   },
/* 286 */   BIT_XOR_EXPR
/*     */   {
/*     */     public String format(List<GimpleExpr> operands) {
/* 289 */       return infix("^^", operands);
/*     */     }
/*     */   },
/* 292 */   LSHIFT_EXPR
/*     */   {
/*     */     public String format(List<GimpleExpr> operands) {
/* 295 */       return infix("<<", operands);
/*     */     }
/*     */   },
/* 298 */   RSHIFT_EXPR
/*     */   {
/*     */     public String format(List<GimpleExpr> operands) {
/* 301 */       return infix(">>", operands);
/*     */     }
/*     */   },
/* 304 */   LROTATE_EXPR,
/*     */   
/* 306 */   NEGATE_EXPR
/*     */   {
/*     */     public String format(List<GimpleExpr> operands) {
/* 309 */       return "-" + operands.get(0);
/*     */     }
/*     */   },
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 317 */   PAREN_EXPR,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 323 */   ORDERED_EXPR,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 329 */   UNORDERED_EXPR,
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 334 */   UNLT_EXPR,
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 339 */   UNLE_EXPR,
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 344 */   UNGT_EXPR,
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 349 */   UNGE_EXPR,
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 354 */   UNEQ_EXPR,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 360 */   LTGT_EXPR,
/*     */ 
/*     */   
/* 363 */   CONVERT_EXPR,
/*     */   
/* 365 */   TRUNC_MOD_EXPR,
/*     */   
/* 367 */   CONSTRUCTOR,
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 372 */   REALPART_EXPR
/*     */   {
/*     */     public String format(List<GimpleExpr> operands) {
/* 375 */       return call("Re", operands);
/*     */     }
/*     */   },
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 382 */   IMAGPART_EXPR
/*     */   {
/*     */     public String format(List<GimpleExpr> operands) {
/* 385 */       return call("Im", operands);
/*     */     }
/*     */   },
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 393 */   COMPLEX_CST,
/*     */   
/* 395 */   COMPLEX_EXPR,
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 400 */   CONJ_EXPR,
/*     */   
/* 402 */   BIT_FIELD_REF
/*     */   {
/*     */     public String format(List<GimpleExpr> operands) {
/* 405 */       return ((GimpleExpr)operands.get(0)).toString();
/*     */     }
/*     */   };
/*     */   
/*     */   public String format(List<GimpleExpr> operands) {
/* 410 */     return call(name().replace("_EXPR", "").toLowerCase(), operands);
/*     */   }
/*     */   
/*     */   private static String infix(String op, List<GimpleExpr> operands) {
/* 414 */     return (new StringBuilder()).append(operands.get(0)).append(" ").append(op).append(" ").append(operands.get(1)).toString();
/*     */   }
/*     */   
/*     */   private static String call(String name, List<GimpleExpr> operands) {
/* 418 */     return name + "(" + Joiner.on(", ").join(operands) + ")";
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/gimple/GimpleOp.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */