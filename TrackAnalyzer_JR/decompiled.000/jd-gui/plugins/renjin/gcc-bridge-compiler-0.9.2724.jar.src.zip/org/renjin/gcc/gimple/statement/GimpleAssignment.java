/*     */ package org.renjin.gcc.gimple.statement;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.function.Predicate;
/*     */ import org.renjin.gcc.gimple.GimpleExprVisitor;
/*     */ import org.renjin.gcc.gimple.GimpleOp;
/*     */ import org.renjin.gcc.gimple.GimpleVisitor;
/*     */ import org.renjin.gcc.gimple.expr.GimpleExpr;
/*     */ import org.renjin.gcc.gimple.expr.GimpleLValue;
/*     */ import org.renjin.repackaged.guava.collect.Lists;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GimpleAssignment
/*     */   extends GimpleStatement
/*     */ {
/*     */   private GimpleOp operator;
/*     */   private GimpleLValue lhs;
/*  36 */   private List<GimpleExpr> operands = Lists.newArrayList();
/*     */ 
/*     */   
/*     */   public GimpleAssignment() {}
/*     */   
/*     */   public GimpleAssignment(GimpleOp op, GimpleLValue lhs, GimpleExpr... arguments) {
/*  42 */     this.operator = op;
/*  43 */     this.lhs = lhs;
/*  44 */     this.operands.addAll(Arrays.asList(arguments));
/*     */   }
/*     */   
/*     */   public GimpleOp getOperator() {
/*  48 */     return this.operator;
/*     */   }
/*     */   
/*     */   public void setOperator(GimpleOp op) {
/*  52 */     this.operator = op;
/*     */   }
/*     */   
/*     */   public GimpleLValue getLHS() {
/*  56 */     return this.lhs;
/*     */   }
/*     */   
/*     */   public List<GimpleExpr> getOperands() {
/*  60 */     return this.operands;
/*     */   }
/*     */   
/*     */   public void setLhs(GimpleLValue lhs) {
/*  64 */     this.lhs = lhs;
/*     */   }
/*     */   
/*     */   public String toString() {
/*  68 */     StringBuilder sb = new StringBuilder();
/*  69 */     sb.append(this.lhs).append(" = ").append(this.operator.format(this.operands));
/*  70 */     if (getLineNumber() != null) {
/*  71 */       sb.append("\t\t\t#").append(getLineNumber());
/*  72 */       if (getSourceFile() != null) {
/*  73 */         sb.append(" (").append(getSourceFile()).append(")");
/*     */       }
/*     */     } 
/*     */     
/*  77 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public void visit(GimpleVisitor visitor) {
/*  82 */     visitor.visitAssignment(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean lhsMatches(Predicate<? super GimpleLValue> predicate) {
/*  87 */     return predicate.test(this.lhs);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void findUses(Predicate<? super GimpleExpr> predicate, List<GimpleExpr> results) {
/*  93 */     findUses(this.operands, predicate, results);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 102 */     if (!(this.lhs instanceof org.renjin.gcc.gimple.expr.GimpleSymbolRef)) {
/* 103 */       this.lhs.find(predicate, results);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void replaceAll(Predicate<? super GimpleExpr> predicate, GimpleExpr newExpr) {
/* 110 */     if (predicate.test(this.lhs)) {
/* 111 */       this.lhs = (GimpleLValue)newExpr;
/*     */     } else {
/* 113 */       this.lhs.replaceAll(predicate, newExpr);
/*     */     } 
/* 115 */     replaceAll(predicate, this.operands, newExpr);
/*     */   }
/*     */ 
/*     */   
/*     */   public void accept(GimpleExprVisitor visitor) {
/* 120 */     this.lhs.accept(visitor);
/* 121 */     for (GimpleExpr operand : this.operands)
/* 122 */       operand.accept(visitor); 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/gimple/statement/GimpleAssignment.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */