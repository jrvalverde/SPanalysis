/*    */ package org.renjin.gcc.codegen.condition;
/*    */ 
/*    */ import org.renjin.gcc.codegen.MethodGenerator;
/*    */ import org.renjin.gcc.codegen.expr.PtrExpr;
/*    */ import org.renjin.gcc.gimple.GimpleOp;
/*    */ import org.renjin.repackaged.asm.Label;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NullCheckGenerator
/*    */   implements ConditionGenerator
/*    */ {
/*    */   private final GimpleOp op;
/*    */   private final PtrExpr ptrExpr;
/*    */   
/*    */   public NullCheckGenerator(GimpleOp op, PtrExpr ptrExpr) {
/* 33 */     this.op = op;
/* 34 */     this.ptrExpr = ptrExpr;
/*    */   }
/*    */ 
/*    */   
/*    */   public final void emitJump(MethodGenerator mv, Label trueLabel, Label falseLabel) {
/* 39 */     switch (this.op) {
/*    */       
/*    */       case EQ_EXPR:
/* 42 */         this.ptrExpr.jumpIfNull(mv, trueLabel);
/* 43 */         mv.goTo(falseLabel);
/*    */         return;
/*    */       
/*    */       case NE_EXPR:
/* 47 */         this.ptrExpr.jumpIfNull(mv, falseLabel);
/* 48 */         mv.goTo(trueLabel);
/*    */         return;
/*    */     } 
/*    */     
/* 52 */     throw new UnsupportedOperationException("op: " + this.op);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/condition/NullCheckGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */