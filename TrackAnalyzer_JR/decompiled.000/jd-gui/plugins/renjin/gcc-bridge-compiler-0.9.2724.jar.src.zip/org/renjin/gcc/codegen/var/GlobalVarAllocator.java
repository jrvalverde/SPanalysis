/*     */ package org.renjin.gcc.codegen.var;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Optional;
/*     */ import java.util.Set;
/*     */ import javax.annotation.Nonnull;
/*     */ import org.renjin.gcc.InternalCompilerException;
/*     */ import org.renjin.gcc.codegen.MethodGenerator;
/*     */ import org.renjin.gcc.codegen.expr.JExpr;
/*     */ import org.renjin.gcc.codegen.expr.JLValue;
/*     */ import org.renjin.repackaged.asm.ClassVisitor;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ import org.renjin.repackaged.guava.collect.Lists;
/*     */ import org.renjin.repackaged.guava.collect.Sets;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GlobalVarAllocator
/*     */   extends VarAllocator
/*     */ {
/*     */   private final Type declaringClass;
/*     */   
/*     */   public class StaticField
/*     */     implements JLValue
/*     */   {
/*     */     private String name;
/*     */     private Type type;
/*     */     private Optional<JExpr> initialValue;
/*     */     
/*     */     public StaticField(String name, Type type, Optional<JExpr> initialValue) {
/*  48 */       this.name = name;
/*  49 */       this.type = type;
/*  50 */       this.initialValue = initialValue;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nonnull
/*     */     public Type getType() {
/*  56 */       return this.type;
/*     */     }
/*     */     
/*     */     public Type getDeclaringClass() {
/*  60 */       return GlobalVarAllocator.this.declaringClass;
/*     */     }
/*     */     
/*     */     public String getName() {
/*  64 */       return this.name;
/*     */     }
/*     */ 
/*     */     
/*     */     public void load(@Nonnull MethodGenerator mv) {
/*  69 */       mv.visitFieldInsn(178, GlobalVarAllocator.this.declaringClass.getInternalName(), this.name, this.type.getDescriptor());
/*     */     }
/*     */ 
/*     */     
/*     */     public void store(MethodGenerator mv, JExpr value) {
/*  74 */       value.load(mv);
/*  75 */       mv.visitFieldInsn(179, GlobalVarAllocator.this.declaringClass.getInternalName(), this.name, this.type.getDescriptor());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*  80 */   private final List<StaticField> fields = Lists.newArrayList();
/*  81 */   private final Set<String> fieldNames = Sets.newHashSet();
/*     */   
/*     */   public GlobalVarAllocator(String declaringClass) {
/*  84 */     this.declaringClass = Type.getType("L" + declaringClass + ";");
/*  85 */     assert this.declaringClass.getSort() == 10;
/*     */   }
/*     */ 
/*     */   
/*     */   public StaticField reserve(String name, Type type) {
/*  90 */     return reserve(name, type, Optional.empty());
/*     */   }
/*     */   
/*     */   public StaticField reserve(String name, Type type, Optional<JExpr> initialValue) {
/*  94 */     String fieldName = toJavaSafeName(name);
/*  95 */     if (this.fieldNames.contains(fieldName)) {
/*  96 */       throw new InternalCompilerException("Duplicate field name generated '" + name + "' [" + fieldName + "]");
/*     */     }
/*  98 */     this.fieldNames.add(fieldName);
/*  99 */     StaticField field = new StaticField(fieldName, type, initialValue);
/* 100 */     this.fields.add(field);
/* 101 */     return field;
/*     */   }
/*     */ 
/*     */   
/*     */   public StaticField reserve(String name, Type type, JExpr initialValue) {
/* 106 */     return reserve(name, type, Optional.of(initialValue));
/*     */   }
/*     */   
/*     */   public void writeFields(ClassVisitor cv) {
/* 110 */     for (StaticField field : this.fields) {
/* 111 */       cv.visitField(9, field.name, field.type.getDescriptor(), null, null);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean needsStaticInitializer() {
/* 116 */     for (StaticField field : this.fields) {
/* 117 */       if (field.initialValue.isPresent()) {
/* 118 */         return true;
/*     */       }
/*     */     } 
/* 121 */     return false;
/*     */   }
/*     */   
/*     */   public void writeFieldInitialization(MethodGenerator mv) {
/* 125 */     for (StaticField field : this.fields) {
/* 126 */       if (field.initialValue.isPresent()) {
/* 127 */         JExpr initialValue = field.initialValue.get();
/* 128 */         initialValue.load(mv);
/* 129 */         mv.putstatic(this.declaringClass.getInternalName(), field.name, field.type.getDescriptor());
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/var/GlobalVarAllocator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */