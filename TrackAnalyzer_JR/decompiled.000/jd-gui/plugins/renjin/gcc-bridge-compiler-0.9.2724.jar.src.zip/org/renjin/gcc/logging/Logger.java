/*    */ package org.renjin.gcc.logging;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.FileNotFoundException;
/*    */ import java.io.PrintWriter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Logger
/*    */ {
/* 30 */   public static final Logger NULL = new Logger();
/*    */   
/* 32 */   private File file = null;
/*    */   
/* 34 */   private PrintWriter printWriter = null;
/*    */   
/*    */   private Logger() {
/* 37 */     this.file = null;
/*    */   }
/*    */   
/*    */   Logger(File file) {
/* 41 */     this.file = file;
/*    */   }
/*    */   
/*    */   public void log(String message) {
/* 45 */     if (this.file == null) {
/*    */       return;
/*    */     }
/* 48 */     if (this.printWriter == null) {
/*    */       try {
/* 50 */         this.printWriter = new PrintWriter(this.file);
/* 51 */       } catch (FileNotFoundException e) {
/* 52 */         System.err.println("Could not open log at " + this.file + ": " + e.getMessage());
/* 53 */         this.file = null;
/*    */         
/*    */         return;
/*    */       } 
/*    */     }
/* 58 */     this.printWriter.println(message);
/*    */   }
/*    */   
/*    */   void close() {
/* 62 */     if (this.printWriter != null) {
/* 63 */       this.printWriter.close();
/* 64 */       this.printWriter = null;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/logging/Logger.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */