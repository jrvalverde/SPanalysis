/*     */ package org.renjin.gcc.gimple.type;
/*     */ 
/*     */ import org.renjin.gcc.gimple.expr.GimpleIntegerConstant;
/*     */ import org.renjin.gcc.gimple.expr.GimplePrimitiveConstant;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GimpleIntegerType
/*     */   extends GimplePrimitiveType
/*     */ {
/*     */   private boolean unsigned;
/*     */   
/*     */   public GimpleIntegerType() {}
/*     */   
/*     */   public GimpleIntegerType(int precision) {
/*  32 */     setSize(precision);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPrecision() {
/*  42 */     return getSize();
/*     */   }
/*     */   
/*     */   public boolean isUnsigned() {
/*  46 */     return this.unsigned;
/*     */   }
/*     */   
/*     */   public void setUnsigned(boolean unsigned) {
/*  50 */     this.unsigned = unsigned;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  55 */     StringBuilder s = new StringBuilder();
/*  56 */     if (this.unsigned) {
/*  57 */       s.append("unsigned ");
/*     */     }
/*  59 */     s.append("int" + getPrecision());
/*  60 */     return s.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  65 */     int prime = 31;
/*  66 */     int result = 1;
/*  67 */     result = 31 * result + getSize();
/*  68 */     result = 31 * result + (this.unsigned ? 1231 : 1237);
/*  69 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/*  74 */     if (this == obj) {
/*  75 */       return true;
/*     */     }
/*  77 */     if (obj == null) {
/*  78 */       return false;
/*     */     }
/*  80 */     if (getClass() != obj.getClass()) {
/*  81 */       return false;
/*     */     }
/*  83 */     GimpleIntegerType other = (GimpleIntegerType)obj;
/*  84 */     if (getPrecision() != other.getPrecision()) {
/*  85 */       return false;
/*     */     }
/*  87 */     if (this.unsigned != other.unsigned) {
/*  88 */       return false;
/*     */     }
/*  90 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int localVariableSlots() {
/*  95 */     if (getPrecision() > 32) {
/*  96 */       return 2;
/*     */     }
/*  98 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Type jvmType() {
/* 104 */     if (getPrecision() == 64) {
/* 105 */       return Type.LONG_TYPE;
/*     */     }
/* 107 */     if (getPrecision() == 8) {
/* 108 */       return Type.BYTE_TYPE;
/*     */     }
/* 110 */     if (getPrecision() == 16) {
/* 111 */       if (this.unsigned) {
/* 112 */         return Type.CHAR_TYPE;
/*     */       }
/* 114 */       return Type.SHORT_TYPE;
/*     */     } 
/*     */ 
/*     */     
/* 118 */     return Type.INT_TYPE;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int sizeOf() {
/* 124 */     return Math.max(1, getSize() / 8);
/*     */   }
/*     */ 
/*     */   
/*     */   public GimpleIntegerConstant zero() {
/* 129 */     return new GimpleIntegerConstant(this, 0L);
/*     */   }
/*     */   
/*     */   public static GimpleIntegerType unsigned(int bits) {
/* 133 */     GimpleIntegerType type = new GimpleIntegerType(bits);
/* 134 */     type.unsigned = true;
/* 135 */     return type;
/*     */   }
/*     */ 
/*     */   
/*     */   public static GimpleIntegerType signed(int bits) {
/* 140 */     return new GimpleIntegerType(bits);
/*     */   }
/*     */   
/*     */   public boolean isSigned() {
/* 144 */     return !isUnsigned();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/gimple/type/GimpleIntegerType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */