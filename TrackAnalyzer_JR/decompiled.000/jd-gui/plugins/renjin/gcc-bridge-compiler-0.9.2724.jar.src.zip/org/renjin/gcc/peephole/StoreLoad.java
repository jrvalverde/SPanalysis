/*    */ package org.renjin.gcc.peephole;
/*    */ 
/*    */ import java.util.ListIterator;
/*    */ import org.renjin.repackaged.asm.tree.AbstractInsnNode;
/*    */ import org.renjin.repackaged.asm.tree.IincInsnNode;
/*    */ import org.renjin.repackaged.asm.tree.InsnList;
/*    */ import org.renjin.repackaged.asm.tree.VarInsnNode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StoreLoad
/*    */   implements PeepholeOptimization
/*    */ {
/*    */   public boolean apply(NodeIt it) {
/* 37 */     if (it.matches(new Pattern[] { Pattern.STORE, Pattern.LOAD })) {
/* 38 */       VarInsnNode store = it.<VarInsnNode>get(0);
/* 39 */       VarInsnNode load = it.<VarInsnNode>get(1);
/*    */       
/* 41 */       if (store.var == load.var)
/*    */       {
/*    */         
/* 44 */         if (countLoads(it.getList(), store.var) == 1) {
/* 45 */           it.remove(2);
/* 46 */           return true;
/*    */         } 
/*    */       }
/*    */     } 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 54 */     return false;
/*    */   }
/*    */   
/*    */   private int countLoads(InsnList list, int var) {
/* 58 */     int count = 0;
/* 59 */     ListIterator<AbstractInsnNode> it = list.iterator();
/* 60 */     while (it.hasNext()) {
/* 61 */       AbstractInsnNode node = it.next();
/* 62 */       if (Pattern.LOAD.match(node)) {
/* 63 */         VarInsnNode load = (VarInsnNode)node;
/* 64 */         if (load.var == var)
/* 65 */           count++;  continue;
/*    */       } 
/* 67 */       if (node.getOpcode() == 132) {
/* 68 */         IincInsnNode inc = (IincInsnNode)node;
/* 69 */         if (inc.var == var) {
/* 70 */           count++;
/*    */         }
/*    */       } 
/*    */     } 
/* 74 */     return count;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/peephole/StoreLoad.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */