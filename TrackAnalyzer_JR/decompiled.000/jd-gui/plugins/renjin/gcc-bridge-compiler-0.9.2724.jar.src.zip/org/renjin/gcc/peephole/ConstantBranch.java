/*    */ package org.renjin.gcc.peephole;
/*    */ 
/*    */ import org.renjin.repackaged.asm.tree.AbstractInsnNode;
/*    */ import org.renjin.repackaged.asm.tree.JumpInsnNode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConstantBranch
/*    */   implements PeepholeOptimization
/*    */ {
/*    */   public boolean apply(NodeIt it) {
/* 32 */     if (it.matches(new Pattern[] { Pattern.ICONST, Pattern.ICONST, Pattern.INT_COMPARISON })) {
/* 33 */       int x = Instructions.getInteger(it.get(0));
/* 34 */       int y = Instructions.getInteger(it.get(1));
/* 35 */       JumpInsnNode branchNode = it.<JumpInsnNode>get(2);
/*    */       
/* 37 */       boolean branch = evaluate(branchNode.getOpcode(), x, y);
/*    */       
/* 39 */       if (branch) {
/*    */         
/* 41 */         it.remove(3);
/* 42 */         it.insert(new AbstractInsnNode[] { (AbstractInsnNode)new JumpInsnNode(167, branchNode.label) });
/*    */       }
/*    */       else {
/*    */         
/* 46 */         it.remove(3);
/*    */       } 
/* 48 */       return true;
/*    */     } 
/* 50 */     return false;
/*    */   }
/*    */   
/*    */   private boolean evaluate(int opcode, int x, int y) {
/* 54 */     switch (opcode) {
/*    */       case 159:
/* 56 */         return (x == y);
/*    */       
/*    */       case 160:
/* 59 */         return (x != y);
/*    */       
/*    */       case 161:
/* 62 */         return (x < y);
/*    */       
/*    */       case 162:
/* 65 */         return (x >= y);
/*    */       
/*    */       case 163:
/* 68 */         return (x > y);
/*    */       
/*    */       case 164:
/* 71 */         return (x <= y);
/*    */     } 
/*    */     
/* 74 */     throw new IllegalArgumentException("opcode: " + opcode);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/peephole/ConstantBranch.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */