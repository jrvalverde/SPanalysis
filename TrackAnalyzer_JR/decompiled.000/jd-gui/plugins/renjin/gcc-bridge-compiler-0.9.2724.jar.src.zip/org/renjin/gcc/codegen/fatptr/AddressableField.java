/*    */ package org.renjin.gcc.codegen.fatptr;
/*    */ 
/*    */ import java.util.Optional;
/*    */ import org.renjin.gcc.codegen.MethodGenerator;
/*    */ import org.renjin.gcc.codegen.expr.Expressions;
/*    */ import org.renjin.gcc.codegen.expr.GExpr;
/*    */ import org.renjin.gcc.codegen.expr.JExpr;
/*    */ import org.renjin.gcc.codegen.expr.JLValue;
/*    */ import org.renjin.gcc.codegen.type.FieldStrategy;
/*    */ import org.renjin.gcc.gimple.type.GimpleType;
/*    */ import org.renjin.repackaged.asm.ClassVisitor;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AddressableField
/*    */   extends FieldStrategy
/*    */ {
/*    */   private final Type recordType;
/*    */   private final String arrayField;
/*    */   private final Type arrayType;
/*    */   private ValueFunction valueFunction;
/*    */   
/*    */   public AddressableField(Type recordType, String fieldName, ValueFunction valueFunction) {
/* 44 */     this.recordType = recordType;
/* 45 */     this.arrayField = fieldName;
/* 46 */     this.arrayType = Type.getType("[" + valueFunction.getValueType().getDescriptor());
/* 47 */     this.valueFunction = valueFunction;
/*    */   }
/*    */ 
/*    */   
/*    */   public void writeFields(ClassVisitor cv) {
/* 52 */     cv.visitField(1, this.arrayField, this.arrayType.getDescriptor(), null, null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void emitInstanceInit(MethodGenerator mv) {
/* 60 */     Optional<JExpr> initialValues = this.valueFunction.getValueConstructor();
/*    */ 
/*    */ 
/*    */     
/* 64 */     JExpr unitArray = Expressions.newArray(this.valueFunction.getValueType(), this.valueFunction.getElementLength(), initialValues);
/*    */ 
/*    */     
/* 67 */     mv.visitVarInsn(25, 0);
/* 68 */     unitArray.load(mv);
/* 69 */     mv.putfield(this.recordType, this.arrayField, this.arrayType);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public GExpr memberExpr(MethodGenerator mv, JExpr instance, int offset, int size, GimpleType expectedType) {
/* 75 */     if (offset != 0) {
/* 76 */       throw new UnsupportedOperationException("TODO: offset = " + offset);
/*    */     }
/*    */     
/* 79 */     return dereference(instance);
/*    */   }
/*    */   
/*    */   private GExpr dereference(JExpr instance) {
/* 83 */     JLValue jLValue = Expressions.field(instance, this.arrayType, this.arrayField);
/*    */     
/* 85 */     return this.valueFunction.dereference((JExpr)jLValue, Expressions.zero());
/*    */   }
/*    */ 
/*    */   
/*    */   public void copy(MethodGenerator mv, JExpr source, JExpr dest) {
/* 90 */     GExpr sourceExpr = dereference(source);
/* 91 */     GExpr destExpr = dereference(dest);
/* 92 */     destExpr.store(mv, sourceExpr);
/*    */   }
/*    */ 
/*    */   
/*    */   public void memset(MethodGenerator mv, JExpr instance, JExpr byteValue, JExpr byteCount) {
/* 97 */     JLValue arrayField = Expressions.field(instance, this.arrayType, this.arrayField);
/* 98 */     this.valueFunction.memorySet(mv, (JExpr)arrayField, Expressions.zero(), byteValue, byteCount);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/fatptr/AddressableField.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */