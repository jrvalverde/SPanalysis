package org.renjin.gcc.codegen.fatptr;

import java.util.List;
import java.util.Optional;
import org.renjin.gcc.codegen.MethodGenerator;
import org.renjin.gcc.codegen.expr.GExpr;
import org.renjin.gcc.codegen.expr.JExpr;
import org.renjin.gcc.codegen.vptr.VPtrExpr;
import org.renjin.gcc.gimple.type.GimpleType;
import org.renjin.repackaged.asm.Type;

public interface ValueFunction {
  Type getValueType();
  
  GimpleType getGimpleValueType();
  
  int getElementLength();
  
  int getArrayElementBytes();
  
  Optional<JExpr> getValueConstructor();
  
  VPtrExpr toVPtr(JExpr paramJExpr1, JExpr paramJExpr2);
  
  GExpr dereference(JExpr paramJExpr1, JExpr paramJExpr2);
  
  GExpr dereference(WrappedFatPtrExpr paramWrappedFatPtrExpr);
  
  List<JExpr> toArrayValues(GExpr paramGExpr);
  
  void memoryCopy(MethodGenerator paramMethodGenerator, JExpr paramJExpr1, JExpr paramJExpr2, JExpr paramJExpr3, JExpr paramJExpr4, JExpr paramJExpr5);
  
  void memorySet(MethodGenerator paramMethodGenerator, JExpr paramJExpr1, JExpr paramJExpr2, JExpr paramJExpr3, JExpr paramJExpr4);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/fatptr/ValueFunction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */