/*    */ package org.renjin.gcc.codegen.vptr;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import java.util.Optional;
/*    */ import org.renjin.gcc.codegen.MethodGenerator;
/*    */ import org.renjin.gcc.codegen.expr.Expressions;
/*    */ import org.renjin.gcc.codegen.expr.GExpr;
/*    */ import org.renjin.gcc.codegen.expr.JExpr;
/*    */ import org.renjin.gcc.codegen.expr.JLValue;
/*    */ import org.renjin.gcc.codegen.type.ParamStrategy;
/*    */ import org.renjin.gcc.codegen.var.VarAllocator;
/*    */ import org.renjin.gcc.gimple.GimpleParameter;
/*    */ import org.renjin.gcc.runtime.PointerPtr;
/*    */ import org.renjin.gcc.runtime.Ptr;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VPtrParamStrategy
/*    */   implements ParamStrategy
/*    */ {
/*    */   private Type paramType;
/*    */   
/*    */   public VPtrParamStrategy(Type paramType) {
/* 42 */     this.paramType = paramType;
/*    */   }
/*    */   
/*    */   public VPtrParamStrategy() {
/* 46 */     this(Type.getType(Ptr.class));
/*    */   }
/*    */ 
/*    */   
/*    */   public List<Type> getParameterTypes() {
/* 51 */     return Collections.singletonList(Type.getType(Ptr.class));
/*    */   }
/*    */ 
/*    */   
/*    */   public List<String> getParameterNames(String name) {
/* 56 */     return Collections.singletonList(name);
/*    */   }
/*    */ 
/*    */   
/*    */   public GExpr emitInitialization(MethodGenerator methodVisitor, GimpleParameter parameter, List<JLValue> paramVars, VarAllocator localVars) {
/* 61 */     if (parameter.isAddressable()) {
/* 62 */       JLValue pointerPtr = localVars.reserve(parameter.getName() + "$address", Type.getType(PointerPtr.class), 
/* 63 */           Expressions.staticMethodCall(PointerPtr.class, "malloc", 
/* 64 */             Type.getMethodDescriptor(Type.getType(PointerPtr.class), new Type[] { Type.getType(Ptr.class) }), new JExpr[] { (JExpr)paramVars.get(0) }));
/*    */       
/* 66 */       VPtrExpr address = new VPtrExpr((JExpr)pointerPtr);
/* 67 */       return address.valueOf(parameter.getType());
/*    */     } 
/* 69 */     return (GExpr)new VPtrExpr((JExpr)paramVars.get(0));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void loadParameter(MethodGenerator mv, Optional<GExpr> argument) {
/* 75 */     if (argument.isPresent()) {
/* 76 */       JExpr ref = ((GExpr)argument.get()).toVPtrExpr().getRef();
/* 77 */       JExpr castedRef = Expressions.cast(ref, this.paramType);
/* 78 */       castedRef.load(mv);
/*    */     } else {
/* 80 */       mv.aconst(null);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/vptr/VPtrParamStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */