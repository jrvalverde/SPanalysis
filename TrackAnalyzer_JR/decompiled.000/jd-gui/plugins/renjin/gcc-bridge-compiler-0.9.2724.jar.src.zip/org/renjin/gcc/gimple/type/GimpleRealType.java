/*    */ package org.renjin.gcc.gimple.type;
/*    */ 
/*    */ import org.renjin.gcc.gimple.expr.GimplePrimitiveConstant;
/*    */ import org.renjin.gcc.gimple.expr.GimpleRealConstant;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ import org.renjin.repackaged.guava.base.Preconditions;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GimpleRealType
/*    */   extends GimplePrimitiveType
/*    */ {
/*    */   public GimpleRealType() {}
/*    */   
/*    */   public GimpleRealType(int precision) {
/* 31 */     setSize(precision);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getPrecision() {
/* 39 */     return getSize();
/*    */   }
/*    */   
/*    */   public void setPrecision(int precision) {
/* 43 */     Preconditions.checkArgument((precision > 0));
/* 44 */     setSize(precision);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 49 */     return "real" + getPrecision();
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 54 */     return getSize();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 59 */     if (this == obj) {
/* 60 */       return true;
/*    */     }
/* 62 */     if (obj == null) {
/* 63 */       return false;
/*    */     }
/* 65 */     if (getClass() != obj.getClass()) {
/* 66 */       return false;
/*    */     }
/* 68 */     GimpleRealType other = (GimpleRealType)obj;
/* 69 */     return (getSize() == other.getSize());
/*    */   }
/*    */ 
/*    */   
/*    */   public int localVariableSlots() {
/* 74 */     return jvmType().getSize();
/*    */   }
/*    */ 
/*    */   
/*    */   public Type jvmType() {
/* 79 */     if (getPrecision() <= 32) {
/* 80 */       return Type.FLOAT_TYPE;
/*    */     }
/* 82 */     return Type.DOUBLE_TYPE;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int sizeOf() {
/* 88 */     return getSize() / 8;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public GimpleRealConstant zero() {
/* 94 */     return new GimpleRealConstant(this, 0.0D);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/gimple/type/GimpleRealType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */