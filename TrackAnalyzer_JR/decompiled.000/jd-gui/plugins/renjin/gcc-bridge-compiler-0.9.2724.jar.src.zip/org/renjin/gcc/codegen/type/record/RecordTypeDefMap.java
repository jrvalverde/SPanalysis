/*    */ package org.renjin.gcc.codegen.type.record;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import org.renjin.gcc.codegen.type.PointerTypeStrategy;
/*    */ import org.renjin.gcc.codegen.vptr.VPtrRecordTypeStrategy;
/*    */ import org.renjin.gcc.gimple.GimpleCompilationUnit;
/*    */ import org.renjin.gcc.gimple.type.GimpleRecordType;
/*    */ import org.renjin.gcc.gimple.type.GimpleRecordTypeDef;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ import org.renjin.repackaged.guava.base.Preconditions;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RecordTypeDefMap
/*    */ {
/* 35 */   private Map<String, GimpleRecordTypeDef> typeDefMap = new HashMap<>();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 40 */   private Map<String, ProvidedTypeStrategy> recordNameMap = new HashMap<>();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 45 */   private Map<Type, ProvidedTypeStrategy> providedTypeMap = new HashMap<>();
/*    */   
/*    */   public void init(List<GimpleCompilationUnit> units, Map<String, Type> providedRecordTypes) {
/* 48 */     for (GimpleCompilationUnit unit : units) {
/* 49 */       for (GimpleRecordTypeDef recordTypeDef : unit.getRecordTypes()) {
/* 50 */         this.typeDefMap.put(recordTypeDef.getId(), recordTypeDef);
/*    */         
/* 52 */         if (providedRecordTypes.containsKey(recordTypeDef.getName())) {
/* 53 */           Type jvmClass = providedRecordTypes.get(recordTypeDef.getName());
/* 54 */           ProvidedTypeStrategy strategy = new ProvidedTypeStrategy(recordTypeDef, jvmClass);
/*    */           
/* 56 */           this.recordNameMap.put(recordTypeDef.getName(), strategy);
/* 57 */           this.providedTypeMap.put(jvmClass, strategy);
/*    */         } 
/*    */       } 
/*    */     } 
/*    */   }
/*    */   
/*    */   public GimpleRecordTypeDef getRecordTypeDef(GimpleRecordType type) {
/* 64 */     return getRecordTypeDef(type.getId());
/*    */   }
/*    */ 
/*    */   
/*    */   public RecordTypeStrategy get(String recordTypeId) {
/* 69 */     GimpleRecordTypeDef def = getRecordTypeDef(recordTypeId);
/*    */     
/* 71 */     if (this.recordNameMap.containsKey(def.getName())) {
/* 72 */       return this.recordNameMap.get(def.getName());
/*    */     }
/*    */     
/* 75 */     return (RecordTypeStrategy)new VPtrRecordTypeStrategy(def);
/*    */   }
/*    */   
/*    */   private GimpleRecordTypeDef getRecordTypeDef(String recordTypeId) {
/* 79 */     GimpleRecordTypeDef def = this.typeDefMap.get(recordTypeId);
/* 80 */     if (def == null) {
/* 81 */       throw new IllegalStateException("Cannot find type def for " + recordTypeId);
/*    */     }
/* 83 */     return def;
/*    */   }
/*    */   
/*    */   public boolean isMappedToRecordType(Class<?> type) {
/* 87 */     return this.providedTypeMap.containsKey(Type.getType(type));
/*    */   }
/*    */   
/*    */   public PointerTypeStrategy getPointerStrategyFor(Class<?> type) {
/* 91 */     RecordTypeStrategy strategy = getStrategyFor(type);
/* 92 */     return strategy.pointerTo();
/*    */   }
/*    */   
/*    */   public RecordTypeStrategy getStrategyFor(Class<?> type) {
/* 96 */     RecordTypeStrategy strategy = this.providedTypeMap.get(Type.getType(type));
/* 97 */     Preconditions.checkNotNull(strategy, "No strategy for class " + type);
/* 98 */     return strategy;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/type/record/RecordTypeDefMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */