/*     */ package org.renjin.gcc.codegen.expr;
/*     */ 
/*     */ import javax.annotation.Nonnull;
/*     */ import org.renjin.gcc.codegen.MethodGenerator;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ import org.renjin.repackaged.guava.base.Preconditions;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConstantValue
/*     */   implements JExpr
/*     */ {
/*     */   private Number value;
/*     */   private Type type;
/*     */   
/*     */   public ConstantValue(Type type, Number value) {
/*  33 */     this.type = type;
/*  34 */     this.value = value;
/*     */   }
/*     */   
/*     */   public Number getValue() {
/*  38 */     return this.value;
/*     */   }
/*     */   
/*     */   public int getIntValue() {
/*  42 */     Preconditions.checkState(this.type.equals(Type.INT_TYPE));
/*     */     
/*  44 */     return this.value.intValue();
/*     */   }
/*     */ 
/*     */   
/*     */   @Nonnull
/*     */   public Type getType() {
/*  50 */     return this.type;
/*     */   }
/*     */ 
/*     */   
/*     */   public void load(@Nonnull MethodGenerator mv) {
/*  55 */     switch (this.type.getSort()) {
/*     */       case 6:
/*  57 */         mv.fconst(this.value.floatValue());
/*     */         return;
/*     */       case 8:
/*  60 */         mv.dconst(this.value.doubleValue());
/*     */         return;
/*     */       case 7:
/*  63 */         mv.lconst(this.value.longValue());
/*     */         return;
/*     */       case 1:
/*     */       case 2:
/*     */       case 3:
/*     */       case 4:
/*     */       case 5:
/*  70 */         mv.iconst(this.value.intValue());
/*     */         return;
/*     */     } 
/*  73 */     throw new UnsupportedOperationException("type: " + this.type);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/*  79 */     if (this == o) {
/*  80 */       return true;
/*     */     }
/*  82 */     if (o == null || getClass() != o.getClass()) {
/*  83 */       return false;
/*     */     }
/*     */     
/*  86 */     ConstantValue that = (ConstantValue)o;
/*     */     
/*  88 */     if (!this.value.equals(that.value)) {
/*  89 */       return false;
/*     */     }
/*  91 */     return this.type.equals(that.type);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  97 */     int result = this.value.hashCode();
/*  98 */     result = 31 * result + this.type.hashCode();
/*  99 */     return result;
/*     */   }
/*     */   
/*     */   public static boolean isZero(JExpr expr) {
/* 103 */     if (expr instanceof ConstantValue) {
/* 104 */       ConstantValue constantValue = (ConstantValue)expr;
/* 105 */       if (constantValue.getIntValue() == 0) {
/* 106 */         return true;
/*     */       }
/*     */     } 
/* 109 */     return false;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/expr/ConstantValue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */