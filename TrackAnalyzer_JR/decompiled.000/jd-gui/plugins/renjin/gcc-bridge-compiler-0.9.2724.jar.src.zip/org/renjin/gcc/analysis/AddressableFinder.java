/*     */ package org.renjin.gcc.analysis;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import org.renjin.gcc.gimple.GimpleCompilationUnit;
/*     */ import org.renjin.gcc.gimple.GimpleExprVisitor;
/*     */ import org.renjin.gcc.gimple.GimpleFunction;
/*     */ import org.renjin.gcc.gimple.GimpleParameter;
/*     */ import org.renjin.gcc.gimple.GimpleSymbolTable;
/*     */ import org.renjin.gcc.gimple.GimpleVarDecl;
/*     */ import org.renjin.gcc.gimple.expr.GimpleAddressOf;
/*     */ import org.renjin.gcc.gimple.expr.GimpleComponentRef;
/*     */ import org.renjin.gcc.gimple.expr.GimpleExpr;
/*     */ import org.renjin.gcc.gimple.expr.GimpleFieldRef;
/*     */ import org.renjin.gcc.gimple.expr.GimpleParamRef;
/*     */ import org.renjin.gcc.gimple.expr.GimpleVariableRef;
/*     */ import org.renjin.gcc.gimple.type.GimpleField;
/*     */ import org.renjin.gcc.gimple.type.GimpleRecordType;
/*     */ import org.renjin.gcc.gimple.type.GimpleRecordTypeDef;
/*     */ import org.renjin.repackaged.guava.collect.Maps;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AddressableFinder
/*     */ {
/*     */   private GimpleSymbolTable symbolTable;
/*  39 */   private final Map<String, GimpleRecordTypeDef> recordTypeDefs = Maps.newHashMap();
/*     */   private Collection<GimpleCompilationUnit> units;
/*     */   
/*     */   public AddressableFinder(Collection<GimpleCompilationUnit> units) {
/*  43 */     this.units = units;
/*  44 */     this.symbolTable = new GimpleSymbolTable(units);
/*  45 */     for (GimpleCompilationUnit unit : units) {
/*  46 */       for (GimpleRecordTypeDef unitRecordType : unit.getRecordTypes()) {
/*  47 */         this.recordTypeDefs.put(unitRecordType.getId(), unitRecordType);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public void mark() {
/*  53 */     for (GimpleCompilationUnit unit : this.units) {
/*  54 */       for (GimpleFunction fn : unit.getFunctions())
/*  55 */         fn.accept(new MarkingVisitor(this.symbolTable.scope(fn))); 
/*     */     } 
/*     */   }
/*     */   
/*     */   private class MarkingVisitor
/*     */     extends GimpleExprVisitor
/*     */   {
/*     */     private GimpleSymbolTable.Scope scope;
/*     */     
/*     */     public MarkingVisitor(GimpleSymbolTable.Scope scope) {
/*  65 */       this.scope = scope;
/*     */     }
/*     */ 
/*     */     
/*     */     public void visitAddressOf(GimpleAddressOf addressOf) {
/*  70 */       super.visitAddressOf(addressOf);
/*     */       
/*  72 */       markExpr(addressOf.getValue());
/*     */     }
/*     */     
/*     */     private void markExpr(GimpleExpr expr) {
/*  76 */       if (expr instanceof GimpleVariableRef) {
/*  77 */         Optional<GimpleVarDecl> decl = this.scope.lookupVariable((GimpleVariableRef)expr);
/*  78 */         if (decl.isPresent()) {
/*  79 */           ((GimpleVarDecl)decl.get()).setAddressable(true);
/*     */         }
/*  81 */       } else if (expr instanceof GimpleParamRef) {
/*  82 */         GimpleParameter param = this.scope.lookupParameter((GimpleParamRef)expr);
/*  83 */         param.setAddressable(true);
/*     */       }
/*  85 */       else if (expr instanceof GimpleComponentRef) {
/*  86 */         GimpleComponentRef ref = (GimpleComponentRef)expr;
/*  87 */         GimpleRecordType recordType = (GimpleRecordType)ref.getValue().getType();
/*  88 */         GimpleRecordTypeDef recordTypeDef = (GimpleRecordTypeDef)AddressableFinder.this.recordTypeDefs.get(recordType.getId());
/*  89 */         if (recordTypeDef == null) {
/*  90 */           throw new IllegalStateException("Record def not found: " + recordType);
/*     */         }
/*     */         
/*  93 */         if (recordTypeDef.isUnion() && ref.getMember().getType() instanceof GimpleRecordType) {
/*  94 */           markExpr(ref.getValue());
/*     */         } else {
/*  96 */           AddressableFinder.this.markField(recordTypeDef, ref.getMember());
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   private void markField(GimpleRecordTypeDef recordTypeDef, GimpleFieldRef member) {
/* 103 */     GimpleField field = recordTypeDef.findField(member);
/*     */     
/* 105 */     if (field.getType() instanceof org.renjin.gcc.gimple.type.GimpleArrayType) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 110 */     field.setAddressed(true);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/analysis/AddressableFinder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */