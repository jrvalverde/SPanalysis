/*    */ package org.renjin.gcc.peephole;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ZeroAdd
/*    */   implements PeepholeOptimization
/*    */ {
/*    */   public boolean apply(NodeIt it) {
/* 27 */     if (it.matches(new Pattern[] { Pattern.ZERO, Pattern.IADD })) {
/* 28 */       it.remove(2);
/* 29 */       return true;
/*    */     } 
/*    */     
/* 32 */     return false;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/peephole/ZeroAdd.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */