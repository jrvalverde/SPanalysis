/*    */ package org.renjin.gcc.codegen.call;
/*    */ 
/*    */ import org.renjin.gcc.codegen.MethodGenerator;
/*    */ import org.renjin.gcc.codegen.expr.ExprFactory;
/*    */ import org.renjin.gcc.codegen.expr.Expressions;
/*    */ import org.renjin.gcc.codegen.expr.GExpr;
/*    */ import org.renjin.gcc.codegen.expr.JExpr;
/*    */ import org.renjin.gcc.codegen.type.TypeOracle;
/*    */ import org.renjin.gcc.codegen.type.fun.FunctionRefGenerator;
/*    */ import org.renjin.gcc.gimple.expr.GimpleExpr;
/*    */ import org.renjin.gcc.gimple.statement.GimpleCall;
/*    */ import org.renjin.gcc.gimple.type.GimpleType;
/*    */ import org.renjin.gcc.runtime.MallocThunk;
/*    */ import org.renjin.repackaged.asm.Handle;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CallocGenerator
/*    */   implements CallGenerator, MethodHandleGenerator
/*    */ {
/*    */   private TypeOracle typeOracle;
/*    */   
/*    */   public CallocGenerator(TypeOracle typeOracle) {
/* 44 */     this.typeOracle = typeOracle;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void emitCall(MethodGenerator mv, ExprFactory exprFactory, GimpleCall call) {
/* 50 */     if (call.getLhs() == null) {
/*    */       return;
/*    */     }
/*    */ 
/*    */     
/* 55 */     GimpleType pointerType = call.getLhs().getType();
/*    */ 
/*    */     
/* 58 */     JExpr elements = exprFactory.findPrimitiveGenerator(call.getOperands().get(0));
/* 59 */     JExpr elementSize = exprFactory.findPrimitiveGenerator(call.getOperands().get(1));
/* 60 */     JExpr totalBytes = Expressions.product(elements, elementSize);
/*    */     
/* 62 */     GExpr mallocGenerator = this.typeOracle.forPointerType(pointerType).malloc(mv, totalBytes);
/* 63 */     GExpr lhs = exprFactory.findGenerator((GimpleExpr)call.getLhs());
/* 64 */     lhs.store(mv, mallocGenerator);
/*    */   }
/*    */ 
/*    */   
/*    */   public JExpr getMethodHandle() {
/* 69 */     return (JExpr)new FunctionRefGenerator(new Handle(6, 
/* 70 */           Type.getInternalName(MallocThunk.class), "calloc", 
/* 71 */           Type.getMethodDescriptor(Type.getType(Object.class), new Type[] { Type.INT_TYPE, Type.INT_TYPE })));
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/call/CallocGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */