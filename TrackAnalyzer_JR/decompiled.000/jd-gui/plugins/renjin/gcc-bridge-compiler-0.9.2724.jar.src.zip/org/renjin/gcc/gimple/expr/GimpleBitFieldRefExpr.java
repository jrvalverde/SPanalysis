/*    */ package org.renjin.gcc.gimple.expr;
/*    */ 
/*    */ import java.util.function.Predicate;
/*    */ import org.renjin.gcc.gimple.GimpleExprVisitor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GimpleBitFieldRefExpr
/*    */   extends GimpleExpr
/*    */ {
/*    */   private GimpleExpr value;
/*    */   private int size;
/*    */   private int offset;
/*    */   
/*    */   public GimpleExpr getValue() {
/* 33 */     return this.value;
/*    */   }
/*    */   
/*    */   public void setValue(GimpleExpr value) {
/* 37 */     this.value = value;
/*    */   }
/*    */   
/*    */   public int getSize() {
/* 41 */     return this.size;
/*    */   }
/*    */   
/*    */   public void setSize(int size) {
/* 45 */     this.size = size;
/*    */   }
/*    */   
/*    */   public int getOffset() {
/* 49 */     return this.offset;
/*    */   }
/*    */   
/*    */   public void setOffset(int offset) {
/* 53 */     this.offset = offset;
/*    */   }
/*    */ 
/*    */   
/*    */   public void replaceAll(Predicate<? super GimpleExpr> predicate, GimpleExpr newExpr) {
/* 58 */     throw new UnsupportedOperationException("TODO");
/*    */   }
/*    */ 
/*    */   
/*    */   public void accept(GimpleExprVisitor visitor) {
/* 63 */     visitor.visitBitFieldRef(this);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 68 */     return this.value + "[" + this.offset + ":" + this.size + "]";
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/gimple/expr/GimpleBitFieldRefExpr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */