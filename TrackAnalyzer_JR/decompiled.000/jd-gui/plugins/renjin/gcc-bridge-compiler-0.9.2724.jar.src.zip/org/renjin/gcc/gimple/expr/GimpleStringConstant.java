/*    */ package org.renjin.gcc.gimple.expr;
/*    */ 
/*    */ import java.util.function.Predicate;
/*    */ import org.renjin.gcc.gimple.GimpleExprVisitor;
/*    */ import org.renjin.gcc.gimple.type.GimpleArrayType;
/*    */ import org.renjin.gcc.gimple.type.GimpleType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GimpleStringConstant
/*    */   extends GimpleConstant
/*    */ {
/*    */   private String value;
/*    */   
/*    */   public void setValue(String value) {
/* 31 */     this.value = value;
/*    */   }
/*    */   
/*    */   public String getValue() {
/* 35 */     return this.value;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setType(GimpleType type) {
/* 40 */     if (!(type instanceof GimpleArrayType)) {
/* 41 */       throw new RuntimeException("Expected array type for StringConstant, got: " + type);
/*    */     }
/* 43 */     super.setType(type);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void replaceAll(Predicate<? super GimpleExpr> predicate, GimpleExpr newExpr) {}
/*    */ 
/*    */ 
/*    */   
/*    */   public void accept(GimpleExprVisitor visitor) {
/* 53 */     visitor.visitStringConstant(this);
/*    */   }
/*    */ 
/*    */   
/*    */   public GimpleArrayType getType() {
/* 58 */     return (GimpleArrayType)super.getType();
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 63 */     return "\"" + this.value.replace("\000", "<NULL>") + "\"";
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/gimple/expr/GimpleStringConstant.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */