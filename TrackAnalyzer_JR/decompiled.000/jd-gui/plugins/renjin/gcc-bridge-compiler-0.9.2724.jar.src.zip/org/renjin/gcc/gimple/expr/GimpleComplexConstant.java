/*    */ package org.renjin.gcc.gimple.expr;
/*    */ 
/*    */ import java.util.function.Predicate;
/*    */ import org.renjin.gcc.gimple.GimpleExprVisitor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GimpleComplexConstant
/*    */   extends GimpleConstant
/*    */ {
/*    */   private GimpleRealConstant real;
/*    */   private GimpleRealConstant im;
/*    */   
/*    */   public GimpleComplexConstant() {}
/*    */   
/*    */   public GimpleComplexConstant(GimpleRealConstant real, GimpleRealConstant im) {
/* 34 */     this.real = real;
/* 35 */     this.im = im;
/*    */   }
/*    */   
/*    */   public GimpleRealConstant getReal() {
/* 39 */     return this.real;
/*    */   }
/*    */   
/*    */   public void setReal(GimpleRealConstant real) {
/* 43 */     this.real = real;
/*    */   }
/*    */   
/*    */   public GimpleRealConstant getIm() {
/* 47 */     return this.im;
/*    */   }
/*    */   
/*    */   public void setIm(GimpleRealConstant im) {
/* 51 */     this.im = im;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 56 */     return this.real + "+" + this.im + "i";
/*    */   }
/*    */ 
/*    */   
/*    */   public void replaceAll(Predicate<? super GimpleExpr> predicate, GimpleExpr newExpr) {
/* 61 */     this.real = (GimpleRealConstant)replaceOrDescend(this.real, predicate, newExpr);
/* 62 */     this.im = (GimpleRealConstant)replaceOrDescend(this.im, predicate, newExpr);
/*    */   }
/*    */ 
/*    */   
/*    */   public void accept(GimpleExprVisitor visitor) {
/* 67 */     visitor.visitComplexConstant(this);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/gimple/expr/GimpleComplexConstant.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */