/*    */ package org.renjin.gcc.gimple.expr;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.function.Predicate;
/*    */ import org.renjin.gcc.gimple.GimpleExprVisitor;
/*    */ import org.renjin.gcc.gimple.type.GimpleArrayType;
/*    */ import org.renjin.gcc.gimple.type.GimpleIntegerType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GimpleArrayRef
/*    */   extends GimpleLValue
/*    */ {
/*    */   private GimpleExpr array;
/*    */   private GimpleExpr index;
/*    */   
/*    */   public GimpleArrayRef() {}
/*    */   
/*    */   public GimpleArrayRef(GimpleExpr array, int index) {
/* 36 */     this.array = array;
/* 37 */     this.index = new GimpleIntegerConstant(GimpleIntegerType.unsigned(32), index);
/* 38 */     setType(((GimpleArrayType)array.getType()).getComponentType());
/*    */   }
/*    */   
/*    */   public GimpleArrayRef(GimpleExpr array, GimpleExpr index) {
/* 42 */     this.array = array;
/* 43 */     this.index = index;
/*    */   }
/*    */   
/*    */   public GimpleExpr getArray() {
/* 47 */     return this.array;
/*    */   }
/*    */   
/*    */   public void setValue(GimpleExpr value) {
/* 51 */     this.array = value;
/*    */   }
/*    */   
/*    */   public void setIndex(GimpleExpr index) {
/* 55 */     this.index = index;
/*    */   }
/*    */   
/*    */   public GimpleExpr getIndex() {
/* 59 */     return this.index;
/*    */   }
/*    */ 
/*    */   
/*    */   public void find(Predicate<? super GimpleExpr> predicate, List<GimpleExpr> results) {
/* 64 */     findOrDescend(this.array, predicate, results);
/* 65 */     findOrDescend(this.index, predicate, results);
/*    */   }
/*    */ 
/*    */   
/*    */   public void accept(GimpleExprVisitor visitor) {
/* 70 */     visitor.visitArrayRef(this);
/*    */   }
/*    */ 
/*    */   
/*    */   public void replaceAll(Predicate<? super GimpleExpr> predicate, GimpleExpr newExpr) {
/* 75 */     this.array = replaceOrDescend(this.array, predicate, newExpr);
/* 76 */     this.index = replaceOrDescend(this.index, predicate, newExpr);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 81 */     return this.array + "[" + this.index + "]";
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/gimple/expr/GimpleArrayRef.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */