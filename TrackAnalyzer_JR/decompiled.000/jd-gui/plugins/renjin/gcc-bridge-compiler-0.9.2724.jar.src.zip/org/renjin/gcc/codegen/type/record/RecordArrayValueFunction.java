/*     */ package org.renjin.gcc.codegen.type.record;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Optional;
/*     */ import org.renjin.gcc.codegen.MethodGenerator;
/*     */ import org.renjin.gcc.codegen.expr.Expressions;
/*     */ import org.renjin.gcc.codegen.expr.GExpr;
/*     */ import org.renjin.gcc.codegen.expr.JExpr;
/*     */ import org.renjin.gcc.codegen.fatptr.Memset;
/*     */ import org.renjin.gcc.codegen.fatptr.ValueFunction;
/*     */ import org.renjin.gcc.codegen.fatptr.WrappedFatPtrExpr;
/*     */ import org.renjin.gcc.codegen.vptr.PointerType;
/*     */ import org.renjin.gcc.codegen.vptr.VPtrExpr;
/*     */ import org.renjin.gcc.gimple.type.GimplePrimitiveType;
/*     */ import org.renjin.gcc.gimple.type.GimpleRecordType;
/*     */ import org.renjin.gcc.gimple.type.GimpleType;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RecordArrayValueFunction
/*     */   implements ValueFunction
/*     */ {
/*     */   private Type fieldType;
/*     */   private int arrayLength;
/*     */   private GimpleRecordType gimpleRecordType;
/*     */   
/*     */   public RecordArrayValueFunction(Type fieldType, int fieldCount, GimpleRecordType gimpleRecordType) {
/*  49 */     this.fieldType = fieldType;
/*  50 */     this.arrayLength = fieldCount;
/*  51 */     this.gimpleRecordType = gimpleRecordType;
/*     */   }
/*     */ 
/*     */   
/*     */   public Type getValueType() {
/*  56 */     return this.fieldType;
/*     */   }
/*     */ 
/*     */   
/*     */   public GimpleType getGimpleValueType() {
/*  61 */     return (GimpleType)this.gimpleRecordType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getElementLength() {
/*  78 */     return this.arrayLength;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getArrayElementBytes() {
/*  83 */     return GimplePrimitiveType.fromJvmType(this.fieldType).sizeOf();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<JExpr> getValueConstructor() {
/*  90 */     return Optional.empty();
/*     */   }
/*     */ 
/*     */   
/*     */   public VPtrExpr toVPtr(JExpr array, JExpr offset) {
/*  95 */     PointerType pointerType = PointerType.ofType(getValueType());
/*  96 */     JExpr newWrapper = Expressions.newObject(pointerType.alignedImpl(), new JExpr[] { array, offset });
/*     */     
/*  98 */     return new VPtrExpr(newWrapper);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public GExpr dereference(JExpr array, JExpr offset) {
/* 104 */     return new RecordArrayExpr(this, array, offset, this.arrayLength);
/*     */   }
/*     */ 
/*     */   
/*     */   public GExpr dereference(WrappedFatPtrExpr wrapperInstance) {
/* 109 */     return dereference(wrapperInstance.getArray(), wrapperInstance.getOffset());
/*     */   }
/*     */ 
/*     */   
/*     */   public List<JExpr> toArrayValues(GExpr expr) {
/* 114 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void memoryCopy(MethodGenerator mv, JExpr destinationArray, JExpr destinationOffset, JExpr sourceArray, JExpr sourceOffset, JExpr valueCount) {
/* 119 */     mv.arrayCopy(sourceArray, sourceOffset, destinationArray, destinationOffset, 
/* 120 */         Expressions.product(valueCount, this.arrayLength));
/*     */   }
/*     */ 
/*     */   
/*     */   public void memorySet(MethodGenerator mv, JExpr array, JExpr offset, JExpr byteValue, JExpr length) {
/* 125 */     Memset.primitiveMemset(mv, this.fieldType, array, offset, byteValue, length);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 130 */     return "RecordArray[" + this.fieldType + "]";
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/type/record/RecordArrayValueFunction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */