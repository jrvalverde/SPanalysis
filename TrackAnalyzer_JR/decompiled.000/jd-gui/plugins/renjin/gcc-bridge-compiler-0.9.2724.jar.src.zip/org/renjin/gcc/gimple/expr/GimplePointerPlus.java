/*    */ package org.renjin.gcc.gimple.expr;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.Objects;
/*    */ import java.util.function.Predicate;
/*    */ import org.renjin.gcc.gimple.GimpleExprVisitor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GimplePointerPlus
/*    */   extends GimpleExpr
/*    */ {
/*    */   private GimpleExpr pointer;
/*    */   private GimpleExpr offset;
/*    */   
/*    */   public GimplePointerPlus() {}
/*    */   
/*    */   public GimplePointerPlus(GimpleExpr pointer, GimpleExpr offset) {
/* 36 */     this.pointer = pointer;
/* 37 */     this.offset = offset;
/* 38 */     setType(pointer.getType());
/*    */   }
/*    */   
/*    */   public GimpleExpr getPointer() {
/* 42 */     return this.pointer;
/*    */   }
/*    */   
/*    */   public void setPointer(GimpleExpr pointer) {
/* 46 */     this.pointer = pointer;
/*    */   }
/*    */   
/*    */   public GimpleExpr getOffset() {
/* 50 */     return this.offset;
/*    */   }
/*    */   
/*    */   public void setOffset(GimpleExpr offset) {
/* 54 */     this.offset = offset;
/*    */   }
/*    */ 
/*    */   
/*    */   public void find(Predicate<? super GimpleExpr> predicate, List<GimpleExpr> results) {
/* 59 */     this.pointer.find(predicate, results);
/* 60 */     this.offset.find(predicate, results);
/*    */   }
/*    */ 
/*    */   
/*    */   public void replaceAll(Predicate<? super GimpleExpr> predicate, GimpleExpr newExpr) {
/* 65 */     this.pointer = replaceOrDescend(this.pointer, predicate, newExpr);
/* 66 */     this.offset = replaceOrDescend(this.offset, predicate, newExpr);
/*    */   }
/*    */ 
/*    */   
/*    */   public void accept(GimpleExprVisitor visitor) {
/* 71 */     visitor.visitPointerPlus(this);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 76 */     if (this == o) {
/* 77 */       return true;
/*    */     }
/* 79 */     if (o == null || getClass() != o.getClass()) {
/* 80 */       return false;
/*    */     }
/*    */     
/* 83 */     GimplePointerPlus that = (GimplePointerPlus)o;
/*    */     
/* 85 */     return (Objects.equals(this.pointer, that.pointer) && 
/* 86 */       Objects.equals(this.offset, that.offset));
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 91 */     int result = (this.pointer != null) ? this.pointer.hashCode() : 0;
/* 92 */     result = 31 * result + ((this.offset != null) ? this.offset.hashCode() : 0);
/* 93 */     return result;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 98 */     return this.pointer + "+" + this.offset;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/gimple/expr/GimplePointerPlus.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */