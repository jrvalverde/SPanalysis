/*     */ package org.renjin.gcc.logging;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.renjin.gcc.InternalCompilerException;
/*     */ import org.renjin.gcc.gimple.GimpleCompilationUnit;
/*     */ import org.renjin.gcc.gimple.GimpleFunction;
/*     */ import org.renjin.gcc.symbols.SymbolTable;
/*     */ import org.renjin.gcc.symbols.UnitSymbolTable;
/*     */ import org.renjin.repackaged.asm.tree.MethodNode;
/*     */ import org.renjin.repackaged.guava.base.Charsets;
/*     */ import org.renjin.repackaged.guava.io.Files;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LogManager
/*     */ {
/*     */   private File loggingDirectory;
/*  49 */   private final Map<String, Logger> openLoggers = new HashMap<>();
/*     */   
/*     */   private final PrintStream warningStream;
/*     */   
/*     */   public LogManager(PrintStream stream) {
/*  54 */     this.warningStream = stream;
/*     */   }
/*     */   
/*     */   public File getLoggingDirectory() {
/*  58 */     return this.loggingDirectory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLoggingDirectory(File loggingDirectory) {
/*  65 */     this.loggingDirectory = loggingDirectory;
/*     */   }
/*     */   
/*     */   public boolean isEnabled() {
/*  69 */     return (this.loggingDirectory != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Logger getLogger(String name) {
/*  78 */     if (!isEnabled()) {
/*  79 */       return Logger.NULL;
/*     */     }
/*     */     
/*  82 */     File logFile = new File(this.loggingDirectory, name + ".log");
/*  83 */     if (!logFile.getParentFile().exists()) {
/*  84 */       logFile.getParentFile().mkdirs();
/*     */     }
/*     */     
/*  87 */     return getLogger(logFile);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Logger getLogger(GimpleFunction gimpleFunction, String logName) {
/*  96 */     if (!isEnabled()) {
/*  97 */       return Logger.NULL;
/*     */     }
/*     */     
/* 100 */     return getLogger(logFile(gimpleFunction, logName + "log"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void log(GimpleFunction function, String logType, Object object) {
/* 111 */     if (!isEnabled()) {
/*     */       return;
/*     */     }
/*     */     
/* 115 */     File logFile = logFile(function, logType);
/*     */     
/*     */     try {
/* 118 */       Files.write(object.toString(), logFile, Charsets.UTF_8);
/* 119 */     } catch (IOException e) {
/* 120 */       warning("Exception dumping to " + logFile.getAbsolutePath());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void logTriView(GimpleFunction function, SymbolTable symbolTable, MethodNode methodNode) {
/* 129 */     if (!isEnabled()) {
/*     */       return;
/*     */     }
/*     */     
/*     */     try {
/* 134 */       log(function, "html", (new HtmlFunctionRenderer(symbolTable, function, methodNode))
/* 135 */           .render());
/* 136 */     } catch (Exception e) {
/* 137 */       throw new InternalCompilerException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void logRecords(GimpleCompilationUnit unit, UnitSymbolTable symbolTable) {
/* 143 */     if (!isEnabled()) {
/*     */       return;
/*     */     }
/* 146 */     File logFile = logFile(unit.getSourceName(), "records", "html");
/*     */     try {
/* 148 */       Files.write((new HtmlRecordRenderer((SymbolTable)symbolTable, unit)).render(), logFile, Charsets.UTF_8);
/* 149 */     } catch (Exception e) {
/* 150 */       throw new InternalCompilerException(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   private File logFile(GimpleFunction gimpleFunction, String suffix) {
/* 155 */     return logFile(gimpleFunction.getUnit().getSourceName(), gimpleFunction.getSafeMangledName(), suffix);
/*     */   }
/*     */   
/*     */   private File logFile(String dir, String file, String ext) {
/* 159 */     File dumpDir = new File(this.loggingDirectory.getAbsolutePath() + File.separator + dir);
/* 160 */     if (!dumpDir.exists()) {
/* 161 */       dumpDir.mkdirs();
/*     */     }
/* 163 */     return new File(dumpDir, file + "." + ext);
/*     */   }
/*     */   
/*     */   private Logger getLogger(File logFile) {
/* 167 */     Logger logger = this.openLoggers.get(logFile.getAbsolutePath());
/* 168 */     if (logger == null) {
/* 169 */       logger = new Logger(logFile);
/* 170 */       this.openLoggers.put(logFile.getAbsolutePath(), logger);
/*     */     } 
/* 172 */     return logger;
/*     */   }
/*     */   
/*     */   public void finish() throws IOException {
/* 176 */     for (Logger logger : this.openLoggers.values()) {
/* 177 */       logger.close();
/*     */     }
/* 179 */     this.openLoggers.clear();
/*     */   }
/*     */   
/*     */   public void warning(String message) {
/* 183 */     this.warningStream.println("WARNING: " + message);
/*     */   }
/*     */   
/*     */   public void note(String message) {
/* 187 */     this.warningStream.print("NOTE: " + message);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/logging/LogManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */