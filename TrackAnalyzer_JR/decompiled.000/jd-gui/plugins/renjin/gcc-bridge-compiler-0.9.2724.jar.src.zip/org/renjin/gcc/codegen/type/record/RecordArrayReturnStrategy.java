/*    */ package org.renjin.gcc.codegen.type.record;
/*    */ 
/*    */ import org.renjin.gcc.codegen.MethodGenerator;
/*    */ import org.renjin.gcc.codegen.expr.Expressions;
/*    */ import org.renjin.gcc.codegen.expr.GExpr;
/*    */ import org.renjin.gcc.codegen.expr.JExpr;
/*    */ import org.renjin.gcc.codegen.type.ReturnStrategy;
/*    */ import org.renjin.gcc.codegen.type.TypeStrategy;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ import org.renjin.repackaged.guava.base.Preconditions;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RecordArrayReturnStrategy
/*    */   implements ReturnStrategy
/*    */ {
/*    */   private RecordArrayValueFunction valueFunction;
/*    */   private Type arrayType;
/*    */   private int arrayLength;
/*    */   
/*    */   public RecordArrayReturnStrategy(RecordArrayValueFunction valueFunction, Type arrayType, int arrayLength) {
/* 43 */     this.valueFunction = valueFunction;
/* 44 */     Preconditions.checkArgument((arrayType.getSort() == 9), "Not an array type: " + arrayType);
/* 45 */     this.arrayType = arrayType;
/* 46 */     this.arrayLength = arrayLength;
/*    */   }
/*    */ 
/*    */   
/*    */   public Type getType() {
/* 51 */     return this.arrayType;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Type getArrayComponentType() {
/* 57 */     String descriptor = this.arrayType.getDescriptor();
/* 58 */     return Type.getType(descriptor.substring(1));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public JExpr marshall(GExpr value) {
/* 67 */     RecordArrayExpr arrayValue = (RecordArrayExpr)value;
/* 68 */     return arrayValue.copyArray();
/*    */   }
/*    */ 
/*    */   
/*    */   public GExpr unmarshall(MethodGenerator mv, JExpr callExpr, TypeStrategy lhsTypeStrategy) {
/* 73 */     return new RecordArrayExpr(this.valueFunction, callExpr, this.arrayLength);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public JExpr getDefaultReturnValue() {
/* 79 */     return Expressions.newArray(getArrayComponentType(), this.arrayLength);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/type/record/RecordArrayReturnStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */