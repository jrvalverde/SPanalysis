/*    */ package org.renjin.gcc.codegen.fatptr;
/*    */ 
/*    */ import org.renjin.gcc.codegen.MethodGenerator;
/*    */ import org.renjin.gcc.codegen.expr.Expressions;
/*    */ import org.renjin.gcc.codegen.expr.GExpr;
/*    */ import org.renjin.gcc.codegen.expr.JExpr;
/*    */ import org.renjin.gcc.codegen.expr.JLValue;
/*    */ import org.renjin.gcc.codegen.type.FieldStrategy;
/*    */ import org.renjin.gcc.gimple.type.GimpleType;
/*    */ import org.renjin.repackaged.asm.ClassVisitor;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FatPtrFieldStrategy
/*    */   extends FieldStrategy
/*    */ {
/*    */   private Type ownerClass;
/*    */   private ValueFunction valueFunction;
/*    */   private String arrayField;
/*    */   private String offsetField;
/*    */   private Type arrayType;
/*    */   
/*    */   public FatPtrFieldStrategy(Type ownerClass, ValueFunction valueFunction, String name, Type arrayType) {
/* 40 */     this.ownerClass = ownerClass;
/* 41 */     this.valueFunction = valueFunction;
/* 42 */     this.arrayField = name;
/* 43 */     this.offsetField = name + "$offset";
/* 44 */     this.arrayType = arrayType;
/*    */   }
/*    */ 
/*    */   
/*    */   public void writeFields(ClassVisitor cv) {
/* 49 */     cv.visitField(1, this.arrayField, this.arrayType.getDescriptor(), null, null);
/* 50 */     cv.visitField(1, this.offsetField, "I", null, null);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public FatPtrPair memberExpr(MethodGenerator mv, JExpr instance, int offset, int size, GimpleType expectedType) {
/* 56 */     if (offset != 0) {
/* 57 */       throw new IllegalStateException("offset = " + offset);
/*    */     }
/* 59 */     return memberExpr(instance);
/*    */   }
/*    */   
/*    */   private FatPtrPair memberExpr(JExpr instance) {
/* 63 */     JLValue jLValue1 = Expressions.field(instance, this.arrayType, this.arrayField);
/* 64 */     JLValue jLValue2 = Expressions.field(instance, Type.INT_TYPE, this.offsetField);
/* 65 */     return new FatPtrPair(this.valueFunction, (JExpr)jLValue1, (JExpr)jLValue2);
/*    */   }
/*    */ 
/*    */   
/*    */   public void copy(MethodGenerator mv, JExpr source, JExpr dest) {
/* 70 */     FatPtrPair sourceExpr = memberExpr(source);
/* 71 */     FatPtrPair destExpr = memberExpr(dest);
/* 72 */     destExpr.store(mv, (GExpr)sourceExpr);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void memset(MethodGenerator mv, JExpr instance, JExpr byteValue, JExpr byteCount) {
/* 79 */     instance.load(mv);
/* 80 */     mv.aconst(null);
/* 81 */     mv.putfield(this.ownerClass, this.arrayField, this.arrayType);
/*    */     
/* 83 */     instance.load(mv);
/* 84 */     byteValue.load(mv);
/* 85 */     mv.putfield(this.ownerClass, this.offsetField, Type.INT_TYPE);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/fatptr/FatPtrFieldStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */