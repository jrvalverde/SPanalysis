/*     */ package org.renjin.gcc.codegen.vptr;
/*     */ 
/*     */ import java.lang.invoke.MethodHandle;
/*     */ import java.util.Optional;
/*     */ import org.renjin.gcc.codegen.MethodGenerator;
/*     */ import org.renjin.gcc.codegen.array.FatArrayExpr;
/*     */ import org.renjin.gcc.codegen.condition.BooleanCondition;
/*     */ import org.renjin.gcc.codegen.condition.Comparison;
/*     */ import org.renjin.gcc.codegen.condition.ConditionGenerator;
/*     */ import org.renjin.gcc.codegen.expr.Expressions;
/*     */ import org.renjin.gcc.codegen.expr.GExpr;
/*     */ import org.renjin.gcc.codegen.expr.JExpr;
/*     */ import org.renjin.gcc.codegen.expr.JLValue;
/*     */ import org.renjin.gcc.codegen.expr.NotAddressableException;
/*     */ import org.renjin.gcc.codegen.expr.PtrExpr;
/*     */ import org.renjin.gcc.codegen.fatptr.FatPtr;
/*     */ import org.renjin.gcc.codegen.fatptr.ValueFunction;
/*     */ import org.renjin.gcc.codegen.type.NumericExpr;
/*     */ import org.renjin.gcc.codegen.type.UnsupportedCastException;
/*     */ import org.renjin.gcc.codegen.type.complex.ComplexExpr;
/*     */ import org.renjin.gcc.codegen.type.fun.FunPtrExpr;
/*     */ import org.renjin.gcc.codegen.type.primitive.NumericIntExpr;
/*     */ import org.renjin.gcc.codegen.type.primitive.PrimitiveExpr;
/*     */ import org.renjin.gcc.codegen.type.primitive.PrimitiveType;
/*     */ import org.renjin.gcc.codegen.type.primitive.PtrCarryingExpr;
/*     */ import org.renjin.gcc.codegen.type.record.ProvidedPtrExpr;
/*     */ import org.renjin.gcc.codegen.type.voidt.VoidPtrExpr;
/*     */ import org.renjin.gcc.gimple.GimpleOp;
/*     */ import org.renjin.gcc.gimple.type.GimpleArrayType;
/*     */ import org.renjin.gcc.gimple.type.GimpleComplexType;
/*     */ import org.renjin.gcc.gimple.type.GimplePrimitiveType;
/*     */ import org.renjin.gcc.gimple.type.GimpleRecordType;
/*     */ import org.renjin.gcc.gimple.type.GimpleType;
/*     */ import org.renjin.gcc.runtime.Ptr;
/*     */ import org.renjin.repackaged.asm.Label;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VPtrExpr
/*     */   implements PtrExpr
/*     */ {
/*     */   private JExpr baseRef;
/*     */   private final PtrExpr address;
/*     */   private final Optional<JExpr> offset;
/*     */   
/*     */   public VPtrExpr(JExpr ref) {
/*  68 */     this.baseRef = ref;
/*  69 */     this.address = null;
/*  70 */     this.offset = Optional.empty();
/*     */   }
/*     */   
/*     */   public VPtrExpr(JExpr baseRef, JExpr offset) {
/*  74 */     this.baseRef = baseRef;
/*  75 */     this.offset = Optional.of(offset);
/*  76 */     this.address = null;
/*     */   }
/*     */   
/*     */   public VPtrExpr(JExpr ptr, PtrExpr address) {
/*  80 */     this.baseRef = ptr;
/*  81 */     this.address = address;
/*  82 */     this.offset = Optional.empty();
/*     */   }
/*     */ 
/*     */   
/*     */   public void store(MethodGenerator mv, GExpr rhs) {
/*  87 */     VPtrExpr rhsVPtr = rhs.toVPtrExpr();
/*  88 */     if (this.offset.isPresent()) {
/*  89 */       ((JLValue)this.baseRef).store(mv, rhsVPtr.baseRef);
/*  90 */       ((JLValue)this.offset.get()).store(mv, rhsVPtr.getOffset());
/*     */     } else {
/*  92 */       ((JLValue)this.baseRef).store(mv, rhsVPtr.getRef());
/*     */     } 
/*     */   }
/*     */   
/*     */   public JExpr getBaseRef() {
/*  97 */     return this.baseRef;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JExpr getRef() {
/* 106 */     if (this.offset.isPresent() && !((JExpr)this.offset.get()).equals(Expressions.zero())) {
/* 107 */       String plusMethod = Type.getMethodDescriptor(Type.getType(Ptr.class), new Type[] { Type.INT_TYPE });
/* 108 */       return Expressions.methodCall(this.baseRef, Ptr.class, "pointerPlus", plusMethod, new JExpr[] {
/* 109 */             getOffset()
/*     */           });
/*     */     } 
/* 112 */     return this.baseRef;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JExpr getOffset() {
/* 121 */     return this.offset.orElse(Expressions.zero());
/*     */   }
/*     */ 
/*     */   
/*     */   public PtrExpr addressOf() {
/* 126 */     if (this.address == null) {
/* 127 */       throw new NotAddressableException();
/*     */     }
/* 129 */     return this.address;
/*     */   }
/*     */ 
/*     */   
/*     */   public FunPtrExpr toFunPtr() throws UnsupportedCastException {
/* 134 */     JExpr funPtr = Expressions.methodCall(getRef(), Ptr.class, "toMethodHandle", 
/* 135 */         Type.getMethodDescriptor(Type.getType(MethodHandle.class), new Type[0]), new JExpr[0]);
/*     */     
/* 137 */     return new FunPtrExpr(funPtr);
/*     */   }
/*     */ 
/*     */   
/*     */   public FatArrayExpr toArrayExpr() throws UnsupportedCastException {
/* 142 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public PrimitiveExpr toPrimitiveExpr() throws UnsupportedCastException {
/* 147 */     JExpr pointerExpr = getRef();
/* 148 */     NumericIntExpr integerValue = (NumericIntExpr)PrimitiveType.UINT32.fromStackValue(
/* 149 */         Expressions.methodCall(pointerExpr, Ptr.class, "getOffsetInBytes", 
/* 150 */           Type.getMethodDescriptor(Type.INT_TYPE, new Type[0]), new JExpr[0]));
/*     */     
/* 152 */     return (PrimitiveExpr)new PtrCarryingExpr(integerValue, this.baseRef);
/*     */   }
/*     */ 
/*     */   
/*     */   public VoidPtrExpr toVoidPtrExpr() throws UnsupportedCastException {
/* 157 */     return new VoidPtrExpr(getRef());
/*     */   }
/*     */ 
/*     */   
/*     */   public VPtrExpr toVPtrExpr() {
/* 162 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ProvidedPtrExpr toProvidedPtrExpr(Type jvmType) {
/* 168 */     JExpr arrayObject = Expressions.methodCall(getRef(), Ptr.class, "getArray", 
/* 169 */         Type.getMethodDescriptor(Type.getType(Object.class), new Type[0]), new JExpr[0]);
/*     */     
/* 171 */     JExpr recordUnitPtr = Expressions.cast(arrayObject, jvmType);
/*     */     
/* 173 */     return new ProvidedPtrExpr(recordUnitPtr);
/*     */   }
/*     */ 
/*     */   
/*     */   public FatPtr toFatPtrExpr(ValueFunction valueFunction) {
/* 178 */     throw new UnsupportedCastException();
/*     */   }
/*     */ 
/*     */   
/*     */   public VPtrRecordExpr toVPtrRecord(GimpleRecordType recordType) {
/* 183 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public VArrayExpr toVArray(GimpleArrayType arrayType) {
/* 188 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public NumericExpr toNumericExpr() {
/* 193 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void jumpIfNull(MethodGenerator mv, Label label) {
/* 198 */     getRef().load(mv);
/* 199 */     mv.invokeinterface(Ptr.class, "isNull", Type.BOOLEAN_TYPE, new Type[0]);
/* 200 */     mv.ifne(label);
/*     */   }
/*     */ 
/*     */   
/*     */   public JExpr memoryCompare(MethodGenerator mv, PtrExpr otherPointer, JExpr n) {
/* 205 */     return Expressions.methodCall(getRef(), Ptr.class, "memcmp", 
/* 206 */         Type.getMethodDescriptor(Type.INT_TYPE, new Type[] { Type.getType(Ptr.class), Type.INT_TYPE }), new JExpr[] { otherPointer
/* 207 */           .toVPtrExpr().getRef(), n });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void memorySet(MethodGenerator mv, JExpr byteValue, JExpr length) {
/* 214 */     getRef().load(mv);
/* 215 */     byteValue.load(mv);
/* 216 */     length.load(mv);
/*     */     
/* 218 */     mv.invokeinterface(Ptr.class, "memset", Type.VOID_TYPE, new Type[] { Type.INT_TYPE, Type.INT_TYPE });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void memoryCopy(MethodGenerator mv, PtrExpr source, JExpr length, boolean buffer) {
/* 224 */     getRef().load(mv);
/* 225 */     source.toVPtrExpr().getRef().load(mv);
/* 226 */     length.load(mv);
/*     */     
/* 228 */     mv.invokeinterface(Ptr.class, buffer ? "memmove" : "memcpy", Type.VOID_TYPE, new Type[] { Type.getType(Ptr.class), Type.INT_TYPE });
/*     */   }
/*     */ 
/*     */   
/*     */   public PtrExpr realloc(MethodGenerator mv, JExpr newSizeInBytes) {
/* 233 */     JExpr jExpr = Expressions.methodCall(getRef(), Ptr.class, "realloc", 
/* 234 */         Type.getMethodDescriptor(Type.getType(Ptr.class), new Type[] { Type.INT_TYPE }), new JExpr[] { newSizeInBytes });
/*     */ 
/*     */     
/* 237 */     return new VPtrExpr(jExpr);
/*     */   }
/*     */ 
/*     */   
/*     */   public PtrExpr pointerPlus(MethodGenerator mv, JExpr offsetInBytes) {
/* 242 */     return pointerPlus(offsetInBytes);
/*     */   }
/*     */   
/*     */   private PtrExpr pointerPlus(JExpr offsetInBytes) {
/* 246 */     return new VPtrExpr(this.baseRef, Expressions.sum(getOffset(), offsetInBytes));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public GExpr valueOf(GimpleType expectedType) {
/* 252 */     if (expectedType instanceof GimpleArrayType) {
/* 253 */       return (GExpr)new VArrayExpr((GimpleArrayType)expectedType, this);
/*     */     }
/*     */     
/* 256 */     if (expectedType instanceof GimpleRecordType) {
/* 257 */       return (GExpr)new VPtrRecordExpr((GimpleRecordType)expectedType, this);
/*     */     }
/*     */     
/* 260 */     if (expectedType instanceof GimplePrimitiveType) {
/* 261 */       PointerType pointerType = PointerType.ofType(expectedType);
/* 262 */       DerefExpr derefExpr = new DerefExpr(this.baseRef, getOffset(), pointerType);
/* 263 */       PrimitiveType primitiveType = PrimitiveType.of((GimplePrimitiveType)expectedType);
/*     */       
/* 265 */       return (GExpr)primitiveType.fromNonStackValue((JExpr)derefExpr, this);
/*     */     } 
/*     */     
/* 268 */     if (expectedType instanceof GimpleComplexType) {
/* 269 */       GimpleComplexType complexType = (GimpleComplexType)expectedType;
/* 270 */       PointerType pointerType = PointerType.ofType((GimpleType)complexType.getPartType());
/*     */       
/* 272 */       JExpr realOffset = getOffset();
/* 273 */       JExpr complexOffset = Expressions.sum(realOffset, complexType.getPartType().sizeOf());
/*     */       
/* 275 */       DerefExpr realExpr = new DerefExpr(this.baseRef, realOffset, pointerType);
/* 276 */       DerefExpr imaginaryExpr = new DerefExpr(this.baseRef, complexOffset, pointerType);
/*     */       
/* 278 */       return (GExpr)new ComplexExpr(this, (JExpr)realExpr, (JExpr)imaginaryExpr);
/*     */     } 
/*     */     
/* 281 */     if (expectedType instanceof org.renjin.gcc.gimple.type.GimpleIndirectType) {
/* 282 */       DerefExpr derefExpr = new DerefExpr(this.baseRef, getOffset(), PointerType.POINTER);
/* 283 */       return (GExpr)new VPtrExpr((JExpr)derefExpr, this);
/*     */     } 
/*     */     
/* 286 */     throw new UnsupportedOperationException("type: " + expectedType);
/*     */   }
/*     */   
/*     */   public GExpr valueOf(GimpleType expectedType, JExpr offset) {
/* 290 */     return pointerPlus(offset).valueOf(expectedType);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ConditionGenerator comparePointer(MethodGenerator mv, GimpleOp op, GExpr otherPointer) {
/* 296 */     if (op == GimpleOp.EQ_EXPR || op == GimpleOp.NE_EXPR) {
/* 297 */       BooleanCondition equalCondition = new BooleanCondition(Expressions.objectEquals(
/* 298 */             getRef(), otherPointer
/* 299 */             .toVPtrExpr().getRef()));
/* 300 */       if (op == GimpleOp.EQ_EXPR) {
/* 301 */         return (ConditionGenerator)equalCondition;
/*     */       }
/* 303 */       return equalCondition.inverse();
/*     */     } 
/*     */ 
/*     */     
/* 307 */     return (ConditionGenerator)new Comparison(op, Expressions.compareTo(getRef(), otherPointer.toVPtrExpr().getRef()));
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/vptr/VPtrExpr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */