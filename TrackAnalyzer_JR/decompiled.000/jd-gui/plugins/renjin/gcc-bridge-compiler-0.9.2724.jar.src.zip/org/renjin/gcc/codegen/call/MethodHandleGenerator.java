package org.renjin.gcc.codegen.call;

import org.renjin.gcc.codegen.expr.JExpr;

public interface MethodHandleGenerator {
  JExpr getMethodHandle();
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/call/MethodHandleGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */