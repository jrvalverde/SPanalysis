/*    */ package org.renjin.gcc.symbols;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.renjin.gcc.codegen.call.CallGenerator;
/*    */ import org.renjin.gcc.codegen.expr.GExpr;
/*    */ import org.renjin.gcc.codegen.expr.JExpr;
/*    */ import org.renjin.gcc.gimple.GimpleVarDecl;
/*    */ import org.renjin.gcc.gimple.expr.GimpleFunctionRef;
/*    */ import org.renjin.gcc.gimple.expr.GimpleSymbolRef;
/*    */ import org.renjin.repackaged.guava.base.Preconditions;
/*    */ import org.renjin.repackaged.guava.collect.Maps;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LocalVariableTable
/*    */   implements SymbolTable
/*    */ {
/*    */   private final UnitSymbolTable parent;
/* 35 */   private Map<Long, GExpr> variableMap = Maps.newHashMap();
/*    */   
/*    */   public LocalVariableTable(UnitSymbolTable parent) {
/* 38 */     this.parent = parent;
/*    */   }
/*    */   
/*    */   public boolean isRegistered(Long gimpleId) {
/* 42 */     return this.variableMap.containsKey(gimpleId);
/*    */   }
/*    */   
/*    */   public void addVariable(Long gimpleId, GExpr variable) {
/* 46 */     Preconditions.checkNotNull(variable);
/* 47 */     Preconditions.checkState(!this.variableMap.containsKey(gimpleId), "variable already registered with id " + gimpleId);
/*    */     
/* 49 */     this.variableMap.put(gimpleId, variable);
/*    */   }
/*    */ 
/*    */   
/*    */   public GExpr getVariable(GimpleSymbolRef ref) {
/* 54 */     GExpr variable = this.variableMap.get(Long.valueOf(ref.getId()));
/* 55 */     if (variable == null) {
/* 56 */       if (this.parent == null) {
/* 57 */         throw new IllegalStateException("No variable with " + ref.getName() + " [id=" + ref.getId() + "]");
/*    */       }
/* 59 */       return this.parent.getVariable(ref);
/*    */     } 
/*    */     
/* 62 */     return variable;
/*    */   }
/*    */   
/*    */   public GExpr getVariable(GimpleVarDecl decl) {
/* 66 */     GExpr varGenerator = this.variableMap.get(Long.valueOf(decl.getId()));
/* 67 */     if (varGenerator == null) {
/* 68 */       throw new IllegalStateException("No variable named " + decl.getName() + " [id=" + decl.getId() + "]");
/*    */     }
/* 70 */     return varGenerator;
/*    */   }
/*    */   
/*    */   public JExpr findHandle(GimpleFunctionRef functionRef) {
/* 74 */     return this.parent.findHandle(functionRef);
/*    */   }
/*    */ 
/*    */   
/*    */   public CallGenerator findCallGenerator(GimpleFunctionRef ref) {
/* 79 */     return this.parent.findCallGenerator(ref);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/symbols/LocalVariableTable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */