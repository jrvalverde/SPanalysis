/*    */ package org.renjin.gcc.codegen.array;
/*    */ 
/*    */ import javax.annotation.Nonnull;
/*    */ import org.renjin.gcc.codegen.MethodGenerator;
/*    */ import org.renjin.gcc.codegen.expr.ConstantValue;
/*    */ import org.renjin.gcc.codegen.expr.Expressions;
/*    */ import org.renjin.gcc.codegen.expr.JExpr;
/*    */ import org.renjin.gcc.codegen.fatptr.ValueFunction;
/*    */ import org.renjin.gcc.codegen.fatptr.Wrappers;
/*    */ import org.renjin.gcc.codegen.var.LocalVarAllocator;
/*    */ import org.renjin.repackaged.asm.Label;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ArrayInitLoop
/*    */   implements JExpr
/*    */ {
/*    */   private ValueFunction valueFunction;
/*    */   private int arrayLength;
/*    */   private Type arrayType;
/*    */   
/*    */   public ArrayInitLoop(ValueFunction valueFunction, int arrayLength) {
/* 44 */     this.valueFunction = valueFunction;
/* 45 */     this.arrayLength = arrayLength;
/* 46 */     this.arrayType = Wrappers.valueArrayType(valueFunction.getValueType());
/*    */   }
/*    */ 
/*    */   
/*    */   @Nonnull
/*    */   public Type getType() {
/* 52 */     return this.arrayType;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void load(@Nonnull MethodGenerator mv) {
/* 58 */     LocalVarAllocator.LocalVar localVar1 = mv.getLocalVarAllocator().reserve(this.arrayType);
/* 59 */     localVar1.store(mv, Expressions.newArray(this.valueFunction.getValueType(), this.arrayLength));
/*    */     
/* 61 */     LocalVarAllocator.LocalVar counter = (LocalVarAllocator.LocalVar)mv.getLocalVarAllocator().reserveInt("$counter");
/* 62 */     Label loopHead = new Label();
/* 63 */     Label loopBody = new Label();
/*    */ 
/*    */     
/* 66 */     counter.store(mv, (JExpr)new ConstantValue(Type.INT_TYPE, Integer.valueOf(0)));
/* 67 */     mv.goTo(loopHead);
/*    */ 
/*    */     
/* 70 */     mv.visitLabel(loopBody);
/*    */ 
/*    */     
/* 73 */     localVar1.load(mv);
/* 74 */     counter.load(mv);
/* 75 */     ((JExpr)this.valueFunction.getValueConstructor().get()).load(mv);
/* 76 */     mv.astore(this.valueFunction.getValueType());
/*    */     
/* 78 */     mv.iinc(counter.getIndex(), 1);
/*    */ 
/*    */     
/* 81 */     mv.visitLabel(loopHead);
/* 82 */     counter.load(mv);
/* 83 */     mv.iconst(this.arrayLength);
/* 84 */     mv.ificmplt(loopBody);
/*    */     
/* 86 */     localVar1.load(mv);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/array/ArrayInitLoop.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */