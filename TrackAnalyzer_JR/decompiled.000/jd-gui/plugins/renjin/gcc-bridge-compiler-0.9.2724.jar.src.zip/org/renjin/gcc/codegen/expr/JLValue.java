package org.renjin.gcc.codegen.expr;

import org.renjin.gcc.codegen.MethodGenerator;

public interface JLValue extends JExpr {
  void store(MethodGenerator paramMethodGenerator, JExpr paramJExpr);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/expr/JLValue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */