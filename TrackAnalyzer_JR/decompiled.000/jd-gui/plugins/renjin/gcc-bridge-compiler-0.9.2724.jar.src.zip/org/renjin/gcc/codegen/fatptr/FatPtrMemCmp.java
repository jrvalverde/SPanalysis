/*    */ package org.renjin.gcc.codegen.fatptr;
/*    */ 
/*    */ import javax.annotation.Nonnull;
/*    */ import org.renjin.gcc.codegen.MethodGenerator;
/*    */ import org.renjin.gcc.codegen.expr.JExpr;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FatPtrMemCmp
/*    */   implements JExpr
/*    */ {
/*    */   private FatPtrPair p1;
/*    */   private FatPtrPair p2;
/*    */   private JExpr n;
/*    */   
/*    */   public FatPtrMemCmp(FatPtrPair p1, FatPtrPair p2, JExpr n) {
/* 39 */     this.p1 = p1;
/* 40 */     this.p2 = p2;
/* 41 */     this.n = n;
/*    */   }
/*    */ 
/*    */   
/*    */   @Nonnull
/*    */   public Type getType() {
/* 47 */     return Type.INT_TYPE;
/*    */   }
/*    */ 
/*    */   
/*    */   public void load(@Nonnull MethodGenerator mv) {
/* 52 */     this.p1.getArray().load(mv);
/* 53 */     this.p1.getOffset().load(mv);
/* 54 */     this.p2.getArray().load(mv);
/* 55 */     this.p2.getOffset().load(mv);
/* 56 */     this.n.load(mv);
/*    */     
/* 58 */     Type valueType = this.p1.getValueType();
/* 59 */     Type arrayType = Wrappers.valueArrayType(valueType);
/* 60 */     Type wrapperType = Wrappers.wrapperType(valueType);
/*    */ 
/*    */ 
/*    */     
/* 64 */     String signature = Type.getMethodDescriptor(Type.INT_TYPE, new Type[] { arrayType, Type.INT_TYPE, arrayType, Type.INT_TYPE, Type.INT_TYPE });
/*    */     
/* 66 */     mv.invokestatic(wrapperType.getInternalName(), "memcmp", signature, false);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/fatptr/FatPtrMemCmp.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */