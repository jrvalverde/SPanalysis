package org.renjin.gcc.gimple;

import org.renjin.gcc.gimple.statement.GimpleAsm;
import org.renjin.gcc.gimple.statement.GimpleAssignment;
import org.renjin.gcc.gimple.statement.GimpleCall;
import org.renjin.gcc.gimple.statement.GimpleConditional;
import org.renjin.gcc.gimple.statement.GimpleGoto;
import org.renjin.gcc.gimple.statement.GimpleReturn;
import org.renjin.gcc.gimple.statement.GimpleSwitch;

public class GimpleVisitor {
  public void visitAssignment(GimpleAssignment assignment) {}
  
  public void visitCall(GimpleCall gimpleCall) {}
  
  public void visitConditional(GimpleConditional gimpleConditional) {}
  
  public void visitReturn(GimpleReturn gimpleReturn) {}
  
  public void blockStart(GimpleBasicBlock bb) {}
  
  public void visitGoto(GimpleGoto gotoIns) {}
  
  public void visitSwitch(GimpleSwitch gimpleSwitch) {}
  
  public void visitAsm(GimpleAsm gimpleAsm) {}
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/gimple/GimpleVisitor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */