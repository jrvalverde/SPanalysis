/*     */ package org.renjin.gcc.codegen.vptr;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.renjin.gcc.annotations.VarArgs;
/*     */ import org.renjin.gcc.codegen.MethodGenerator;
/*     */ import org.renjin.gcc.codegen.expr.ExprFactory;
/*     */ import org.renjin.gcc.codegen.expr.Expressions;
/*     */ import org.renjin.gcc.codegen.expr.GExpr;
/*     */ import org.renjin.gcc.codegen.expr.JExpr;
/*     */ import org.renjin.gcc.codegen.type.VariadicStrategy;
/*     */ import org.renjin.gcc.gimple.expr.GimpleExpr;
/*     */ import org.renjin.gcc.gimple.type.GimpleType;
/*     */ import org.renjin.gcc.gimple.type.GimpleVoidType;
/*     */ import org.renjin.gcc.runtime.Ptr;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ import org.renjin.repackaged.asm.tree.AnnotationNode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VPtrVariadicStrategy
/*     */   implements VariadicStrategy
/*     */ {
/*     */   public List<Type> getParameterTypes() {
/*  57 */     return Collections.singletonList(Type.getType(Ptr.class));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<JExpr> marshallVarArgs(MethodGenerator mv, ExprFactory exprFactory, List<GimpleExpr> extraArgs) {
/*  64 */     int varArgsSize = 0;
/*  65 */     for (GimpleExpr argExpr : extraArgs) {
/*  66 */       varArgsSize += argExpr.getType().sizeOf();
/*     */     }
/*     */ 
/*     */     
/*  70 */     VPtrExpr vptr = new VPtrExpr((JExpr)mv.getLocalVarAllocator().reserve(Type.getType(Ptr.class)));
/*  71 */     VPtrStrategy vptrStrategy = new VPtrStrategy((GimpleType)new GimpleVoidType());
/*  72 */     vptr.store(mv, (GExpr)vptrStrategy.malloc(mv, Expressions.constantInt(varArgsSize)));
/*     */ 
/*     */     
/*  75 */     int offset = 0;
/*  76 */     for (GimpleExpr argExpr : extraArgs) {
/*  77 */       GExpr gexpr = exprFactory.findGenerator(argExpr);
/*  78 */       vptr.valueOf(argExpr.getType(), Expressions.constantInt(offset)).store(mv, gexpr);
/*  79 */       offset += argExpr.getType().sizeOf();
/*     */     } 
/*  81 */     return Collections.singletonList(vptr.getBaseRef());
/*     */   }
/*     */ 
/*     */   
/*     */   public List<AnnotationNode> getParameterAnnotations() {
/*  86 */     AnnotationNode node = new AnnotationNode(Type.getDescriptor(VarArgs.class));
/*  87 */     return Collections.singletonList(node);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isVarArgsPtr(Method method, int index) {
/*  95 */     if (!method.getParameterTypes()[index].equals(Ptr.class)) {
/*  96 */       return false;
/*     */     }
/*  98 */     Annotation[] annotations = method.getParameterAnnotations()[index];
/*  99 */     if (annotations != null) {
/* 100 */       for (Annotation annotation : annotations) {
/* 101 */         if (annotation.getClass().equals(VarArgs.class)) {
/* 102 */           return true;
/*     */         }
/*     */       } 
/*     */     }
/* 106 */     return false;
/*     */   }
/*     */   
/*     */   public static boolean hasVarArgsPtr(Method method) {
/* 110 */     return ((method.getParameterTypes()).length != 0 && 
/* 111 */       isVarArgsPtr(method, (method.getParameterTypes()).length - 1));
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/vptr/VPtrVariadicStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */