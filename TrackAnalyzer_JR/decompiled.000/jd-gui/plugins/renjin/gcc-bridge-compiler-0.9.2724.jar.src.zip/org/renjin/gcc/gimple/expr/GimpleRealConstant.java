/*    */ package org.renjin.gcc.gimple.expr;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import org.renjin.gcc.gimple.type.GimpleRealType;
/*    */ import org.renjin.gcc.gimple.type.GimpleType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GimpleRealConstant
/*    */   extends GimplePrimitiveConstant
/*    */ {
/*    */   @JsonDeserialize(converter = RealValueConverter.class)
/*    */   private double value;
/*    */   
/*    */   public GimpleRealConstant() {}
/*    */   
/*    */   public GimpleRealConstant(GimpleRealType type, double value) {
/* 33 */     setType((GimpleType)type);
/* 34 */     this.value = value;
/*    */   }
/*    */ 
/*    */   
/*    */   public Double getValue() {
/* 39 */     return Double.valueOf(this.value);
/*    */   }
/*    */   
/*    */   public void setValue(double value) {
/* 43 */     this.value = value;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/gimple/expr/GimpleRealConstant.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */