/*    */ package org.renjin.gcc.codegen.vptr;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import java.util.Optional;
/*    */ import org.renjin.gcc.codegen.MethodGenerator;
/*    */ import org.renjin.gcc.codegen.expr.GExpr;
/*    */ import org.renjin.gcc.codegen.expr.JExpr;
/*    */ import org.renjin.gcc.codegen.expr.JLValue;
/*    */ import org.renjin.gcc.codegen.type.ParamStrategy;
/*    */ import org.renjin.gcc.codegen.var.VarAllocator;
/*    */ import org.renjin.gcc.gimple.GimpleParameter;
/*    */ import org.renjin.gcc.gimple.type.GimpleRecordType;
/*    */ import org.renjin.gcc.runtime.Ptr;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VPtrRecordParamStrategy
/*    */   implements ParamStrategy
/*    */ {
/*    */   private GimpleRecordType recordType;
/*    */   
/*    */   public VPtrRecordParamStrategy(GimpleRecordType recordType) {
/* 40 */     this.recordType = recordType;
/*    */   }
/*    */ 
/*    */   
/*    */   public List<Type> getParameterTypes() {
/* 45 */     return Collections.singletonList(Type.getType(Ptr.class));
/*    */   }
/*    */ 
/*    */   
/*    */   public List<String> getParameterNames(String name) {
/* 50 */     return Collections.singletonList(name);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public GExpr emitInitialization(MethodGenerator methodVisitor, GimpleParameter parameter, List<JLValue> paramVars, VarAllocator localVars) {
/* 57 */     return (GExpr)new VPtrRecordExpr(this.recordType, new VPtrExpr((JExpr)paramVars.get(0)));
/*    */   }
/*    */ 
/*    */   
/*    */   public void loadParameter(MethodGenerator mv, Optional<GExpr> argument) {
/* 62 */     if (argument.isPresent()) {
/* 63 */       VPtrRecordExpr record = (VPtrRecordExpr)argument.get();
/* 64 */       record.getRef().load(mv);
/* 65 */       mv.iconst(this.recordType.sizeOf());
/* 66 */       mv.invokeinterface(Ptr.class, "copyOf", Type.getType(Ptr.class), new Type[] { Type.INT_TYPE });
/*    */     } else {
/* 68 */       throw new UnsupportedOperationException("TODO");
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/vptr/VPtrRecordParamStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */