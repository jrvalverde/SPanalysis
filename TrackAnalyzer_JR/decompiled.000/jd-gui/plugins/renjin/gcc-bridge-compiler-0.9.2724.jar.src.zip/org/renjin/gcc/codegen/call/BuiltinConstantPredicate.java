/*    */ package org.renjin.gcc.codegen.call;
/*    */ 
/*    */ import org.renjin.gcc.codegen.MethodGenerator;
/*    */ import org.renjin.gcc.codegen.expr.ExprFactory;
/*    */ import org.renjin.gcc.codegen.expr.GExpr;
/*    */ import org.renjin.gcc.gimple.expr.GimpleExpr;
/*    */ import org.renjin.gcc.gimple.expr.GimpleIntegerConstant;
/*    */ import org.renjin.gcc.gimple.statement.GimpleCall;
/*    */ import org.renjin.gcc.gimple.type.GimpleIntegerType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BuiltinConstantPredicate
/*    */   implements CallGenerator
/*    */ {
/*    */   public static final String NAME = "__builtin_constant_p";
/*    */   
/*    */   public void emitCall(MethodGenerator mv, ExprFactory exprFactory, GimpleCall call) {
/* 44 */     if (call.getLhs() != null) {
/* 45 */       int resultValue; GExpr lhs = exprFactory.findGenerator((GimpleExpr)call.getLhs());
/* 46 */       GimpleExpr argument = call.getOperand(0);
/*    */       
/* 48 */       if (argument instanceof org.renjin.gcc.gimple.expr.GimpleConstant) {
/* 49 */         resultValue = 1;
/*    */       } else {
/* 51 */         resultValue = 0;
/*    */       } 
/* 53 */       lhs.store(mv, exprFactory.findGenerator((GimpleExpr)new GimpleIntegerConstant(new GimpleIntegerType(32), resultValue)));
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/call/BuiltinConstantPredicate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */