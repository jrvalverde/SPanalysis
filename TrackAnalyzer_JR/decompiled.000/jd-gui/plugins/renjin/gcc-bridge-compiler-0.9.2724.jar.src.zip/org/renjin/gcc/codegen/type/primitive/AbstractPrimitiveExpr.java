/*     */ package org.renjin.gcc.codegen.type.primitive;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import org.renjin.gcc.codegen.array.FatArrayExpr;
/*     */ import org.renjin.gcc.codegen.expr.ConstantValue;
/*     */ import org.renjin.gcc.codegen.expr.Expressions;
/*     */ import org.renjin.gcc.codegen.expr.JExpr;
/*     */ import org.renjin.gcc.codegen.expr.PtrExpr;
/*     */ import org.renjin.gcc.codegen.fatptr.FatPtr;
/*     */ import org.renjin.gcc.codegen.fatptr.FatPtrPair;
/*     */ import org.renjin.gcc.codegen.fatptr.ValueFunction;
/*     */ import org.renjin.gcc.codegen.type.UnsupportedCastException;
/*     */ import org.renjin.gcc.codegen.type.fun.FunPtrExpr;
/*     */ import org.renjin.gcc.codegen.type.record.ProvidedPtrExpr;
/*     */ import org.renjin.gcc.codegen.type.voidt.VoidPtrExpr;
/*     */ import org.renjin.gcc.codegen.vptr.VArrayExpr;
/*     */ import org.renjin.gcc.codegen.vptr.VPtrExpr;
/*     */ import org.renjin.gcc.codegen.vptr.VPtrRecordExpr;
/*     */ import org.renjin.gcc.gimple.type.GimpleArrayType;
/*     */ import org.renjin.gcc.gimple.type.GimpleRecordType;
/*     */ import org.renjin.gcc.runtime.IntPtr;
/*     */ import org.renjin.gcc.runtime.Ptr;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractPrimitiveExpr
/*     */   implements PrimitiveExpr
/*     */ {
/*     */   private final JExpr expr;
/*     */   private final PtrExpr address;
/*     */   
/*     */   protected AbstractPrimitiveExpr(JExpr expr, PtrExpr address) {
/*  50 */     this.expr = expr;
/*  51 */     this.address = address;
/*     */   }
/*     */ 
/*     */   
/*     */   public JExpr jexpr() {
/*  56 */     return this.expr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PtrExpr addressOfReadOnly() {
/*  63 */     if (this.address != null) {
/*  64 */       return this.address;
/*     */     }
/*     */     
/*  67 */     PrimitiveType type = PrimitiveType.of(getType());
/*  68 */     JExpr tempArray = Expressions.newArray(type.jvmType(), Collections.singletonList(jexpr()));
/*  69 */     return (PtrExpr)new FatPtrPair(new PrimitiveValueFunction(type), tempArray);
/*     */   }
/*     */ 
/*     */   
/*     */   public final PtrExpr addressOf() {
/*  74 */     if (this.address == null) {
/*  75 */       throw new UnsupportedOperationException("Not addressable");
/*     */     }
/*  77 */     return this.address;
/*     */   }
/*     */ 
/*     */   
/*     */   public FunPtrExpr toFunPtr() throws UnsupportedCastException {
/*  82 */     if (ConstantValue.isZero(jexpr())) {
/*  83 */       return FunPtrExpr.NULL_PTR;
/*     */     }
/*     */     
/*  86 */     return FunPtrExpr.NULL_PTR;
/*     */   }
/*     */ 
/*     */   
/*     */   public FatArrayExpr toArrayExpr() throws UnsupportedCastException {
/*  91 */     throw new UnsupportedCastException();
/*     */   }
/*     */ 
/*     */   
/*     */   public VoidPtrExpr toVoidPtrExpr() throws UnsupportedCastException {
/*  96 */     throw new UnsupportedCastException();
/*     */   }
/*     */ 
/*     */   
/*     */   public VPtrExpr toVPtrExpr() throws UnsupportedCastException {
/* 101 */     return new VPtrExpr(Expressions.staticMethodCall(IntPtr.class, "toPtr", 
/* 102 */           Type.getMethodDescriptor(Type.getType(Ptr.class), new Type[] { Type.INT_TYPE }), new JExpr[] {
/* 103 */             toUnsignedInt(32).jexpr()
/*     */           }));
/*     */   }
/*     */   
/*     */   public ProvidedPtrExpr toProvidedPtrExpr(Type jvmType) {
/* 108 */     throw new UnsupportedCastException();
/*     */   }
/*     */ 
/*     */   
/*     */   public FatPtr toFatPtrExpr(ValueFunction valueFunction) {
/* 113 */     throw new UnsupportedCastException();
/*     */   }
/*     */ 
/*     */   
/*     */   public VPtrRecordExpr toVPtrRecord(GimpleRecordType recordType) {
/* 118 */     throw new UnsupportedCastException();
/*     */   }
/*     */ 
/*     */   
/*     */   public VArrayExpr toVArray(GimpleArrayType arrayType) {
/* 123 */     throw new UnsupportedCastException();
/*     */   }
/*     */ 
/*     */   
/*     */   public final PrimitiveExpr toPrimitiveExpr() throws UnsupportedCastException {
/* 128 */     return this;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/type/primitive/AbstractPrimitiveExpr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */