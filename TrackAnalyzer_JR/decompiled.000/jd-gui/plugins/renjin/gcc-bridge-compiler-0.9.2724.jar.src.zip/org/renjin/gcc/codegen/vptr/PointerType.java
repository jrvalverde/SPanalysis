/*     */ package org.renjin.gcc.codegen.vptr;
/*     */ 
/*     */ import java.lang.invoke.MethodHandle;
/*     */ import org.renjin.gcc.gimple.type.GimpleArrayType;
/*     */ import org.renjin.gcc.gimple.type.GimpleComplexType;
/*     */ import org.renjin.gcc.gimple.type.GimplePrimitiveType;
/*     */ import org.renjin.gcc.gimple.type.GimpleRealType;
/*     */ import org.renjin.gcc.gimple.type.GimpleType;
/*     */ import org.renjin.gcc.runtime.IntPtr;
/*     */ import org.renjin.gcc.runtime.Ptr;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum PointerType
/*     */ {
/*  33 */   BOOLEAN(Type.BOOLEAN_TYPE, PointerKind.INTEGRAL, 1),
/*  34 */   BYTE(Type.BYTE_TYPE, PointerKind.INTEGRAL, 1),
/*  35 */   SHORT(Type.SHORT_TYPE, PointerKind.INTEGRAL, 2),
/*  36 */   CHAR(Type.CHAR_TYPE, PointerKind.INTEGRAL, 2),
/*  37 */   INT(Type.INT_TYPE, PointerKind.INTEGRAL, 4),
/*  38 */   LONG(Type.LONG_TYPE, PointerKind.INTEGRAL, 8),
/*  39 */   FLOAT(Type.FLOAT_TYPE, PointerKind.FLOAT, 4),
/*  40 */   DOUBLE(Type.DOUBLE_TYPE, PointerKind.FLOAT, 8),
/*  41 */   REAL96(Type.DOUBLE_TYPE, PointerKind.INTEGRAL, 12)
/*     */   {
/*     */     public Type alignedImpl() {
/*  44 */       return Type.getType(IntPtr.class);
/*     */     }
/*     */   },
/*  47 */   POINTER(Type.getType(Ptr.class), PointerKind.POINTER, 4),
/*  48 */   FUNCTION(Type.getType(MethodHandle.class), PointerKind.FUNCTION, 4);
/*     */ 
/*     */   
/*     */   public static final String PACKAGE = "org.renjin.gcc.runtime";
/*     */   private Type jvmType;
/*     */   private PointerKind kind;
/*     */   private int size;
/*     */   
/*     */   PointerType(Type jvmType, PointerKind kind, int size) {
/*  57 */     this.jvmType = jvmType;
/*  58 */     this.kind = kind;
/*  59 */     this.size = size;
/*     */   }
/*     */   
/*     */   public int getSize() {
/*  63 */     return this.size;
/*     */   }
/*     */   
/*     */   public Type getJvmType() {
/*  67 */     return this.jvmType;
/*     */   }
/*     */   
/*     */   public String titleCasedName() {
/*  71 */     return name().substring(0, 1) + name().substring(1).toLowerCase();
/*     */   }
/*     */   
/*     */   public Type alignedImpl() {
/*  75 */     return Type.getType("L" + "org.renjin.gcc.runtime".replace('.', '/') + "/" + titleCasedName() + "Ptr;");
/*     */   }
/*     */   
/*     */   public static PointerType ofPrimitiveType(GimplePrimitiveType primitiveType) {
/*  79 */     if (primitiveType.equals(new GimpleRealType(96)))
/*  80 */       return REAL96; 
/*  81 */     if (primitiveType.equals(new GimpleRealType(64))) {
/*  82 */       return DOUBLE;
/*     */     }
/*  84 */     for (PointerType pointerType : values()) {
/*  85 */       if (pointerType.getJvmType().equals(primitiveType.jvmType())) {
/*  86 */         return pointerType;
/*     */       }
/*     */     } 
/*  89 */     throw new IllegalArgumentException("type: " + primitiveType);
/*     */   }
/*     */   
/*     */   public static PointerType ofType(GimpleType type) {
/*  93 */     if (type instanceof org.renjin.gcc.gimple.type.GimpleVoidType)
/*  94 */       return BYTE; 
/*  95 */     if (type instanceof GimplePrimitiveType)
/*  96 */       return ofPrimitiveType((GimplePrimitiveType)type); 
/*  97 */     if (type instanceof GimpleComplexType)
/*  98 */       return ofPrimitiveType((GimplePrimitiveType)((GimpleComplexType)type).getPartType()); 
/*  99 */     if (type instanceof org.renjin.gcc.gimple.type.GimpleRecordType)
/* 100 */       return BYTE; 
/* 101 */     if (type instanceof org.renjin.gcc.gimple.type.GimpleIndirectType)
/* 102 */       return POINTER; 
/* 103 */     if (type instanceof GimpleArrayType)
/* 104 */       return ofType(((GimpleArrayType)type).getComponentType()); 
/* 105 */     if (type instanceof org.renjin.gcc.gimple.type.GimpleFunctionType) {
/* 106 */       return FUNCTION;
/*     */     }
/* 108 */     throw new UnsupportedOperationException("type: " + type);
/*     */   }
/*     */ 
/*     */   
/*     */   public PointerKind getKind() {
/* 113 */     return this.kind;
/*     */   }
/*     */   
/*     */   public static PointerType ofType(Type valueType) {
/* 117 */     for (PointerType pointerType : values()) {
/* 118 */       if (pointerType.getJvmType().equals(valueType)) {
/* 119 */         return pointerType;
/*     */       }
/*     */     } 
/* 122 */     throw new UnsupportedOperationException("valueType: " + valueType);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/vptr/PointerType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */