package org.renjin.gcc.codegen.type.primitive;

import org.renjin.gcc.codegen.expr.GExpr;
import org.renjin.gcc.codegen.expr.JExpr;

public interface IntExpr extends PrimitiveExpr {
  JExpr jexpr();
  
  GExpr bitwiseXor(GExpr paramGExpr);
  
  GExpr bitwiseNot();
  
  GExpr bitwiseAnd(GExpr paramGExpr);
  
  GExpr bitwiseOr(GExpr paramGExpr);
  
  GExpr shiftLeft(GExpr paramGExpr);
  
  GExpr shiftRight(GExpr paramGExpr);
  
  GExpr rotateLeft(GExpr paramGExpr);
  
  IntExpr toSignedInt(int paramInt);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/type/primitive/IntExpr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */