/*     */ package org.renjin.gcc.gimple;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import org.renjin.gcc.gimple.expr.GimpleFunctionRef;
/*     */ import org.renjin.gcc.gimple.expr.GimpleParamRef;
/*     */ import org.renjin.gcc.gimple.expr.GimpleVariableRef;
/*     */ import org.renjin.repackaged.guava.base.Preconditions;
/*     */ import org.renjin.repackaged.guava.collect.Maps;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GimpleSymbolTable
/*     */ {
/*     */   private class UnitTable
/*     */   {
/*     */     private UnitTable() {}
/*     */     
/*  37 */     private final Map<String, GimpleFunction> functionMap = Maps.newHashMap();
/*  38 */     private final Map<Long, GimpleVarDecl> globalVariables = Maps.newHashMap(); }
/*     */   
/*     */   private class LocalTable {
/*     */     private LocalTable() {}
/*     */     
/*  43 */     private final Map<Long, GimpleVarDecl> localVariables = Maps.newHashMap();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  56 */   private Map<GimpleCompilationUnit, UnitTable> unitMap = Maps.newHashMap();
/*  57 */   private Map<GimpleFunction, LocalTable> localMap = Maps.newHashMap();
/*     */   
/*  59 */   private Map<String, GimpleFunction> globalFunctions = Maps.newHashMap();
/*  60 */   private Map<String, GimpleVarDecl> globalVariables = Maps.newHashMap();
/*     */ 
/*     */   
/*     */   public GimpleSymbolTable(Collection<GimpleCompilationUnit> units) {
/*  64 */     for (GimpleCompilationUnit unit : units) {
/*  65 */       UnitTable unitTable = new UnitTable();
/*     */       
/*  67 */       for (GimpleVarDecl varDecl : unit.getGlobalVariables()) {
/*  68 */         if (!varDecl.isExtern()) {
/*  69 */           unitTable.globalVariables.put(Long.valueOf(varDecl.getId()), varDecl);
/*  70 */           if (varDecl.isPublic()) {
/*  71 */             this.globalVariables.put(varDecl.getName(), varDecl);
/*     */           }
/*     */         } 
/*     */       } 
/*     */       
/*  76 */       for (GimpleFunction function : unit.getFunctions()) {
/*     */         
/*  78 */         unitTable.functionMap.put(function.getMangledName(), function);
/*  79 */         if (function.isPublic()) {
/*  80 */           this.globalFunctions.put(function.getMangledName(), function);
/*     */         }
/*     */ 
/*     */         
/*  84 */         LocalTable localTable = new LocalTable();
/*  85 */         for (GimpleVarDecl varDecl : function.getVariableDeclarations()) {
/*  86 */           localTable.localVariables.put(Long.valueOf(varDecl.getId()), varDecl);
/*     */         }
/*  88 */         this.localMap.put(function, localTable);
/*     */       } 
/*     */       
/*  91 */       for (GimpleAlias alias : unit.getAliases()) {
/*     */         
/*  93 */         GimpleFunction definition = (GimpleFunction)unitTable.functionMap.get(alias.getDefinition());
/*  94 */         unitTable.functionMap.put(alias.getAlias(), definition);
/*  95 */         if (alias.isPublic()) {
/*  96 */           this.globalFunctions.put(alias.getAlias(), definition);
/*     */         }
/*     */       } 
/*     */       
/* 100 */       this.unitMap.put(unit, unitTable);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Scope scope(final GimpleFunction function) {
/* 106 */     final Map<Long, GimpleParameter> paramMap = Maps.newHashMap();
/* 107 */     for (GimpleParameter param : function.getParameters()) {
/* 108 */       paramMap.put(Long.valueOf(param.getId()), param);
/*     */     }
/*     */     
/* 111 */     final Map<Long, GimpleVarDecl> localVarMap = Maps.newHashMap();
/* 112 */     for (GimpleVarDecl varDecl : function.getVariableDeclarations()) {
/* 113 */       localVarMap.put(Long.valueOf(varDecl.getId()), varDecl);
/*     */     }
/*     */     
/* 116 */     return new Scope()
/*     */       {
/*     */         public Optional<GimpleFunction> lookupFunction(GimpleFunctionRef ref) {
/* 119 */           return GimpleSymbolTable.this.lookupFunction(function.getUnit(), ref.getName());
/*     */         }
/*     */ 
/*     */         
/*     */         public Optional<GimpleVarDecl> lookupVariable(GimpleVariableRef ref) {
/* 124 */           if (localVarMap.containsKey(Long.valueOf(ref.getId()))) {
/* 125 */             return Optional.of((GimpleVarDecl)localVarMap.get(Long.valueOf(ref.getId())));
/*     */           }
/* 127 */           return GimpleSymbolTable.this.lookupGlobalVariable(function, ref);
/*     */         }
/*     */ 
/*     */         
/*     */         public GimpleParameter lookupParameter(GimpleParamRef ref) {
/* 132 */           GimpleParameter param = (GimpleParameter)paramMap.get(Long.valueOf(ref.getId()));
/* 133 */           if (param == null) {
/* 134 */             throw new IllegalStateException("Cannot resolve ParamRef " + ref);
/*     */           }
/* 136 */           return param;
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */   
/*     */   public Scope scope(final GimpleCompilationUnit unit) {
/* 143 */     Preconditions.checkNotNull(unit, "unit");
/*     */     
/* 145 */     final UnitTable unitTable = this.unitMap.get(unit);
/*     */     
/* 147 */     return new Scope()
/*     */       {
/*     */         public Optional<GimpleFunction> lookupFunction(GimpleFunctionRef ref) {
/* 150 */           return GimpleSymbolTable.this.lookupFunction(unit, ref.getName());
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         public Optional<GimpleVarDecl> lookupVariable(GimpleVariableRef ref) {
/* 156 */           if (unitTable.globalVariables.containsKey(Long.valueOf(ref.getId()))) {
/* 157 */             return Optional.of((GimpleVarDecl)unitTable.globalVariables.get(Long.valueOf(ref.getId())));
/*     */           }
/*     */           
/* 160 */           if (GimpleSymbolTable.this.globalVariables.containsKey(ref.getName())) {
/* 161 */             return Optional.of((GimpleVarDecl)GimpleSymbolTable.this.globalVariables.get(ref.getName()));
/*     */           }
/*     */           
/* 164 */           return Optional.empty();
/*     */         }
/*     */ 
/*     */         
/*     */         public GimpleParameter lookupParameter(GimpleParamRef ref) {
/* 169 */           throw new UnsupportedOperationException();
/*     */         }
/*     */       };
/*     */   }
/*     */   
/*     */   public Optional<GimpleFunction> lookupFunction(GimpleCompilationUnit unit, String name) {
/* 175 */     UnitTable unitTable = this.unitMap.get(unit);
/* 176 */     if (unitTable != null && 
/* 177 */       unitTable.functionMap.containsKey(name)) {
/* 178 */       return Optional.of((GimpleFunction)unitTable.functionMap.get(name));
/*     */     }
/*     */ 
/*     */     
/* 182 */     if (this.globalFunctions.containsKey(name)) {
/* 183 */       return Optional.of(this.globalFunctions.get(name));
/*     */     }
/*     */     
/* 186 */     return Optional.empty();
/*     */   }
/*     */   
/*     */   public Optional<GimpleVarDecl> lookupGlobalVariable(GimpleFunction function, GimpleVariableRef ref) {
/* 190 */     UnitTable unitTable = this.unitMap.get(function.getUnit());
/* 191 */     if (unitTable == null) {
/* 192 */       return Optional.empty();
/*     */     }
/*     */     
/* 195 */     LocalTable localTable = this.localMap.get(function);
/* 196 */     if (localTable == null) {
/* 197 */       return Optional.empty();
/*     */     }
/*     */ 
/*     */     
/* 201 */     if (localTable.localVariables.containsKey(Long.valueOf(ref.getId()))) {
/* 202 */       return Optional.empty();
/*     */     }
/*     */     
/* 205 */     if (unitTable.globalVariables.containsKey(Long.valueOf(ref.getId()))) {
/* 206 */       return Optional.of((GimpleVarDecl)unitTable.globalVariables.get(Long.valueOf(ref.getId())));
/*     */     }
/*     */     
/* 209 */     if (this.globalVariables.containsKey(ref.getName())) {
/* 210 */       return Optional.of(this.globalVariables.get(ref.getName()));
/*     */     }
/*     */     
/* 213 */     return Optional.empty();
/*     */   }
/*     */   
/*     */   public static interface Scope {
/*     */     Optional<GimpleFunction> lookupFunction(GimpleFunctionRef param1GimpleFunctionRef);
/*     */     
/*     */     Optional<GimpleVarDecl> lookupVariable(GimpleVariableRef param1GimpleVariableRef);
/*     */     
/*     */     GimpleParameter lookupParameter(GimpleParamRef param1GimpleParamRef);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/gimple/GimpleSymbolTable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */