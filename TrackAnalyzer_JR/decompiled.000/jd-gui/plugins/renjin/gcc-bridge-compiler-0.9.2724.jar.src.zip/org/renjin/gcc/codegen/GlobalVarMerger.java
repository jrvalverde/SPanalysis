/*    */ package org.renjin.gcc.codegen;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import org.renjin.gcc.gimple.GimpleCompilationUnit;
/*    */ import org.renjin.gcc.gimple.GimpleVarDecl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class GlobalVarMerger
/*    */ {
/*    */   public static void merge(List<GimpleCompilationUnit> units) {
/* 39 */     Map<String, GimpleVarDecl> canonical = new HashMap<>();
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 44 */     findDeclarationsWithInitializers(units, canonical);
/*    */ 
/*    */ 
/*    */     
/* 48 */     markFirstDeclarationAsCanonical(units, canonical);
/*    */ 
/*    */ 
/*    */     
/* 52 */     markNonCanonical(units, canonical);
/*    */   }
/*    */   
/*    */   private static void markNonCanonical(List<GimpleCompilationUnit> units, Map<String, GimpleVarDecl> canonical) {
/* 56 */     for (GimpleCompilationUnit unit : units) {
/* 57 */       for (GimpleVarDecl varDecl : unit.getGlobalVariables()) {
/* 58 */         if (varDecl.isPublic() && !varDecl.isExtern() && canonical
/* 59 */           .get(varDecl.getMangledName()) != varDecl) {
/* 60 */           varDecl.setExtern(true);
/*    */         }
/*    */       } 
/*    */     } 
/*    */   }
/*    */   
/*    */   private static void markFirstDeclarationAsCanonical(List<GimpleCompilationUnit> units, Map<String, GimpleVarDecl> canonical) {
/* 67 */     for (GimpleCompilationUnit unit : units) {
/* 68 */       for (GimpleVarDecl varDecl : unit.getGlobalVariables()) {
/* 69 */         if (varDecl.isPublic() && !varDecl.isExtern() && 
/* 70 */           !canonical.containsKey(varDecl.getMangledName())) {
/* 71 */           canonical.put(varDecl.getMangledName(), varDecl);
/*    */         }
/*    */       } 
/*    */     } 
/*    */   }
/*    */   
/*    */   private static void findDeclarationsWithInitializers(List<GimpleCompilationUnit> units, Map<String, GimpleVarDecl> canonical) {
/* 78 */     for (GimpleCompilationUnit unit : units) {
/* 79 */       for (GimpleVarDecl varDecl : unit.getGlobalVariables()) {
/* 80 */         if (varDecl.isPublic() && !varDecl.isExtern() && varDecl.getValue() != null)
/* 81 */           canonical.put(varDecl.getMangledName(), varDecl); 
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/GlobalVarMerger.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */