/*    */ package org.renjin.gcc.peephole;
/*    */ 
/*    */ import org.renjin.repackaged.asm.tree.AbstractInsnNode;
/*    */ import org.renjin.repackaged.asm.tree.InsnNode;
/*    */ import org.renjin.repackaged.asm.tree.IntInsnNode;
/*    */ import org.renjin.repackaged.asm.tree.LdcInsnNode;
/*    */ import org.renjin.repackaged.asm.util.Textifier;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Instructions
/*    */ {
/*    */   public static int getInteger(AbstractInsnNode node) {
/* 34 */     switch (node.getOpcode()) {
/*    */       case 2:
/* 36 */         return -1;
/*    */       case 3:
/* 38 */         return 0;
/*    */       case 4:
/* 40 */         return 1;
/*    */       case 5:
/* 42 */         return 2;
/*    */       case 6:
/* 44 */         return 3;
/*    */       case 7:
/* 46 */         return 4;
/*    */       case 8:
/* 48 */         return 5;
/*    */       case 16:
/*    */       case 17:
/* 51 */         return ((IntInsnNode)node).operand;
/*    */     } 
/* 53 */     throw new IllegalArgumentException("node: " + Textifier.OPCODES[node.getOpcode()]);
/*    */   }
/*    */   
/*    */   public static AbstractInsnNode constantNode(int cst) {
/* 57 */     if (cst >= -1 && cst <= 5) {
/* 58 */       return (AbstractInsnNode)new InsnNode(3 + cst);
/*    */     }
/* 60 */     if (cst >= -128 && cst <= 127) {
/* 61 */       return (AbstractInsnNode)new IntInsnNode(16, cst);
/*    */     }
/* 63 */     if (cst >= -32768 && cst <= 32767) {
/* 64 */       return (AbstractInsnNode)new IntInsnNode(17, cst);
/*    */     }
/*    */     
/* 67 */     return (AbstractInsnNode)new LdcInsnNode(Integer.valueOf(cst));
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/peephole/Instructions.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */