package org.renjin.gcc.codegen.type;

import org.renjin.gcc.codegen.MethodGenerator;
import org.renjin.gcc.codegen.expr.JExpr;

public interface PointerTypeStrategy<ExprT extends org.renjin.gcc.codegen.expr.GExpr> extends TypeStrategy<ExprT> {
  ExprT malloc(MethodGenerator paramMethodGenerator, JExpr paramJExpr);
  
  ExprT nullPointer();
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/type/PointerTypeStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */