/*     */ package org.renjin.gcc.codegen.vptr;
/*     */ 
/*     */ import org.renjin.gcc.codegen.MethodGenerator;
/*     */ import org.renjin.gcc.codegen.expr.ExprFactory;
/*     */ import org.renjin.gcc.codegen.expr.Expressions;
/*     */ import org.renjin.gcc.codegen.expr.GExpr;
/*     */ import org.renjin.gcc.codegen.expr.JExpr;
/*     */ import org.renjin.gcc.codegen.expr.JLValue;
/*     */ import org.renjin.gcc.codegen.fatptr.ValueFunction;
/*     */ import org.renjin.gcc.codegen.type.FieldStrategy;
/*     */ import org.renjin.gcc.codegen.type.ParamStrategy;
/*     */ import org.renjin.gcc.codegen.type.PointerTypeStrategy;
/*     */ import org.renjin.gcc.codegen.type.ReturnStrategy;
/*     */ import org.renjin.gcc.codegen.type.TypeStrategy;
/*     */ import org.renjin.gcc.codegen.type.UnsupportedCastException;
/*     */ import org.renjin.gcc.codegen.type.record.RecordTypeStrategy;
/*     */ import org.renjin.gcc.codegen.var.VarAllocator;
/*     */ import org.renjin.gcc.gimple.GimpleVarDecl;
/*     */ import org.renjin.gcc.gimple.expr.GimpleConstructor;
/*     */ import org.renjin.gcc.gimple.expr.GimpleFieldRef;
/*     */ import org.renjin.gcc.gimple.type.GimpleArrayType;
/*     */ import org.renjin.gcc.gimple.type.GimpleRecordType;
/*     */ import org.renjin.gcc.gimple.type.GimpleRecordTypeDef;
/*     */ import org.renjin.gcc.gimple.type.GimpleType;
/*     */ import org.renjin.gcc.runtime.MixedPtr;
/*     */ import org.renjin.gcc.runtime.Ptr;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VPtrRecordTypeStrategy
/*     */   extends RecordTypeStrategy<VPtrRecordExpr>
/*     */ {
/*     */   public VPtrRecordTypeStrategy(GimpleRecordTypeDef recordTypeDef) {
/*  44 */     super(recordTypeDef);
/*     */   }
/*     */ 
/*     */   
/*     */   public ParamStrategy getParamStrategy() {
/*  49 */     return new VPtrRecordParamStrategy(getRecordType());
/*     */   }
/*     */ 
/*     */   
/*     */   public ReturnStrategy getReturnStrategy() {
/*  54 */     return new VPtrRecordReturnStrategy(getRecordType());
/*     */   }
/*     */ 
/*     */   
/*     */   public ValueFunction getValueFunction() {
/*  59 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public VPtrRecordExpr variable(GimpleVarDecl decl, VarAllocator allocator) {
/*  66 */     JExpr malloc = Expressions.staticMethodCall(MixedPtr.class, "malloc", 
/*  67 */         Type.getMethodDescriptor(Type.getType(MixedPtr.class), new Type[] { Type.INT_TYPE }), new JExpr[] {
/*  68 */           Expressions.constantInt(getRecordType().sizeOf())
/*     */         });
/*  70 */     JLValue pointer = allocator.reserve(decl.getNameIfPresent(), Type.getType(Ptr.class), malloc);
/*     */     
/*  72 */     return new VPtrRecordExpr(this.recordType, new VPtrExpr((JExpr)pointer));
/*     */   }
/*     */ 
/*     */   
/*     */   public VPtrRecordExpr providedGlobalVariable(GimpleVarDecl decl, JExpr expr, boolean readOnly) {
/*  77 */     assert expr.getType().equals(Type.getType(Ptr.class));
/*  78 */     return new VPtrRecordExpr((GimpleRecordType)decl.getType(), new VPtrExpr(expr));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public VPtrRecordExpr constructorExpr(ExprFactory exprFactory, MethodGenerator mv, GimpleConstructor value) {
/*  84 */     Type pointerType = Type.getType(MixedPtr.class);
/*  85 */     VPtrExpr malloc = VPtrStrategy.malloc(pointerType, Expressions.constantInt(getRecordType().sizeOf()));
/*  86 */     VPtrExpr tempVar = new VPtrExpr((JExpr)mv.getLocalVarAllocator().reserve(pointerType));
/*  87 */     tempVar.store(mv, (GExpr)malloc);
/*     */     
/*  89 */     int offset = 0;
/*  90 */     for (GimpleConstructor.Element fieldCtor : value.getElements()) {
/*  91 */       GimpleFieldRef field = (GimpleFieldRef)fieldCtor.getField();
/*  92 */       GExpr fieldExpr = exprFactory.findGenerator(fieldCtor.getValue(), field.getType());
/*     */       
/*  94 */       tempVar.valueOf(field.getType(), Expressions.constantInt(offset + field.getOffsetBytes()))
/*  95 */         .store(mv, fieldExpr);
/*     */     } 
/*     */     
/*  98 */     return new VPtrRecordExpr(this.recordType, tempVar);
/*     */   }
/*     */ 
/*     */   
/*     */   public FieldStrategy fieldGenerator(Type className, String fieldName) {
/* 103 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public FieldStrategy addressableFieldGenerator(Type className, String fieldName) {
/* 108 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public PointerTypeStrategy pointerTo() {
/* 113 */     return new VPtrStrategy((GimpleType)getGimpleType());
/*     */   }
/*     */ 
/*     */   
/*     */   public VArrayStrategy arrayOf(GimpleArrayType arrayType) {
/* 118 */     return new VArrayStrategy(arrayType);
/*     */   }
/*     */ 
/*     */   
/*     */   public VPtrRecordExpr cast(MethodGenerator mv, GExpr value) throws UnsupportedCastException {
/* 123 */     return value.toVPtrRecord(getRecordType());
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/vptr/VPtrRecordTypeStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */