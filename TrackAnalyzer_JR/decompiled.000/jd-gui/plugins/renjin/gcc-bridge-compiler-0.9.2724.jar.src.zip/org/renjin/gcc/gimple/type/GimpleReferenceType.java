/*    */ package org.renjin.gcc.gimple.type;
/*    */ 
/*    */ import org.renjin.gcc.gimple.expr.GimpleConstant;
/*    */ import org.renjin.gcc.gimple.expr.GimpleIntegerConstant;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GimpleReferenceType
/*    */   extends AbstractGimpleType
/*    */   implements GimpleIndirectType
/*    */ {
/*    */   private GimpleType baseType;
/*    */   
/*    */   public GimpleType getBaseType() {
/* 28 */     return this.baseType;
/*    */   }
/*    */   
/*    */   public void setBaseType(GimpleType baseType) {
/* 32 */     this.baseType = baseType;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isPointerTo(Class<? extends GimpleType> clazz) {
/* 37 */     return clazz.isAssignableFrom(this.baseType.getClass());
/*    */   }
/*    */ 
/*    */   
/*    */   public int sizeOf() {
/* 42 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   
/*    */   public GimpleConstant nullValue() {
/* 47 */     return (GimpleConstant)GimpleIntegerConstant.nullValue(this);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 52 */     return this.baseType + "&";
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 57 */     if (this == o) {
/* 58 */       return true;
/*    */     }
/* 60 */     if (o == null || getClass() != o.getClass()) {
/* 61 */       return false;
/*    */     }
/*    */     
/* 64 */     GimpleReferenceType that = (GimpleReferenceType)o;
/*    */     
/* 66 */     return this.baseType.equals(that.baseType);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 72 */     return this.baseType.hashCode();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/gimple/type/GimpleReferenceType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */