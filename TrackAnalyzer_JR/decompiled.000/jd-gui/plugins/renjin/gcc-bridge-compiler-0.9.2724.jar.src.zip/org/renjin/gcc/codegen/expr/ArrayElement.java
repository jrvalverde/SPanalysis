/*    */ package org.renjin.gcc.codegen.expr;
/*    */ 
/*    */ import javax.annotation.Nonnull;
/*    */ import org.renjin.gcc.codegen.MethodGenerator;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ArrayElement
/*    */   implements JLValue
/*    */ {
/*    */   private JExpr array;
/*    */   private JExpr offset;
/*    */   
/*    */   public ArrayElement(JExpr array, JExpr offset) {
/* 34 */     this.array = array;
/* 35 */     this.offset = offset;
/*    */   }
/*    */ 
/*    */   
/*    */   public void load(@Nonnull MethodGenerator mv) {
/* 40 */     this.array.load(mv);
/* 41 */     this.offset.load(mv);
/* 42 */     mv.aload(getType());
/*    */   }
/*    */ 
/*    */   
/*    */   public void store(MethodGenerator mv, JExpr value) {
/* 47 */     this.array.load(mv);
/* 48 */     this.offset.load(mv);
/* 49 */     value.load(mv);
/* 50 */     mv.astore(getType());
/*    */   }
/*    */ 
/*    */   
/*    */   @Nonnull
/*    */   public Type getType() {
/* 56 */     return this.array.getType().getElementType();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/expr/ArrayElement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */