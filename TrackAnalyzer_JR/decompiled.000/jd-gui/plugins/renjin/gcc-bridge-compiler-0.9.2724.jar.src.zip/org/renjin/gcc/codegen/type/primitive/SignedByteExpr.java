/*     */ package org.renjin.gcc.codegen.type.primitive;
/*     */ 
/*     */ import javax.annotation.Nullable;
/*     */ import org.renjin.gcc.codegen.MethodGenerator;
/*     */ import org.renjin.gcc.codegen.condition.ConditionGenerator;
/*     */ import org.renjin.gcc.codegen.condition.IntegerComparison;
/*     */ import org.renjin.gcc.codegen.expr.Expressions;
/*     */ import org.renjin.gcc.codegen.expr.GExpr;
/*     */ import org.renjin.gcc.codegen.expr.JExpr;
/*     */ import org.renjin.gcc.codegen.expr.JLValue;
/*     */ import org.renjin.gcc.codegen.expr.PtrExpr;
/*     */ import org.renjin.gcc.codegen.type.NumericExpr;
/*     */ import org.renjin.gcc.gimple.GimpleOp;
/*     */ import org.renjin.gcc.gimple.type.GimpleIntegerType;
/*     */ import org.renjin.gcc.gimple.type.GimplePrimitiveType;
/*     */ import org.renjin.gcc.gimple.type.GimpleRealType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SignedByteExpr
/*     */   extends AbstractIntExpr
/*     */   implements IntExpr
/*     */ {
/*     */   public SignedByteExpr(JExpr expr, @Nullable PtrExpr address) {
/*  41 */     super(expr, address);
/*     */   }
/*     */   
/*     */   public SignedByteExpr(JExpr expr) {
/*  45 */     this(expr, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void store(MethodGenerator mv, GExpr rhs) {
/*  50 */     ((JLValue)jexpr()).store(mv, jexpr(rhs));
/*     */   }
/*     */ 
/*     */   
/*     */   public SignedByteExpr plus(GExpr operand) {
/*  55 */     return lift(Expressions.i2b(Expressions.sum(jexpr(), jexpr(operand))));
/*     */   }
/*     */ 
/*     */   
/*     */   public SignedByteExpr minus(GExpr operand) {
/*  60 */     return lift(Expressions.i2b(Expressions.difference(jexpr(), jexpr(operand))));
/*     */   }
/*     */ 
/*     */   
/*     */   public SignedByteExpr multiply(GExpr operand) {
/*  65 */     return lift(Expressions.i2b(Expressions.product(jexpr(), jexpr(operand))));
/*     */   }
/*     */ 
/*     */   
/*     */   public SignedByteExpr divide(GExpr operand) {
/*  70 */     return lift(Expressions.i2b(Expressions.divide(jexpr(), jexpr(operand))));
/*     */   }
/*     */ 
/*     */   
/*     */   public SignedByteExpr negative() {
/*  75 */     return lift(Expressions.i2b(Expressions.negative(jexpr())));
/*     */   }
/*     */ 
/*     */   
/*     */   public SignedByteExpr min(GExpr operand) {
/*  80 */     return lift(Expressions.staticMethodCall(Math.class, "min", "(II)I", new JExpr[0]));
/*     */   }
/*     */ 
/*     */   
/*     */   public SignedByteExpr max(GExpr operand) {
/*  85 */     return lift(Expressions.staticMethodCall(Math.class, "max", "(II)I", new JExpr[0]));
/*     */   }
/*     */ 
/*     */   
/*     */   public SignedByteExpr absoluteValue() {
/*  90 */     return lift(Expressions.staticMethodCall(Math.class, "abs", "(I)I", new JExpr[0]));
/*     */   }
/*     */ 
/*     */   
/*     */   public SignedByteExpr remainder(GExpr operand) {
/*  95 */     return lift(Expressions.i2b(Expressions.remainder(jexpr(), jexpr(operand))));
/*     */   }
/*     */ 
/*     */   
/*     */   public ConditionGenerator compareTo(GimpleOp op, GExpr operand) {
/* 100 */     return (ConditionGenerator)new IntegerComparison(op, jexpr(), jexpr(operand));
/*     */   }
/*     */ 
/*     */   
/*     */   public SignedByteExpr bitwiseXor(GExpr operand) {
/* 105 */     return lift(Expressions.i2b(Expressions.bitwiseXor(jexpr(), jexpr(operand))));
/*     */   }
/*     */ 
/*     */   
/*     */   public SignedByteExpr bitwiseNot() {
/* 110 */     return lift(Expressions.i2b(Expressions.bitwiseXor(jexpr(), 255)));
/*     */   }
/*     */ 
/*     */   
/*     */   public SignedByteExpr bitwiseAnd(GExpr operand) {
/* 115 */     return lift(Expressions.i2b(Expressions.bitwiseAnd(jexpr(), jexpr(operand))));
/*     */   }
/*     */ 
/*     */   
/*     */   public SignedByteExpr bitwiseOr(GExpr operand) {
/* 120 */     return lift(Expressions.i2b(Expressions.bitwiseOr(jexpr(), jexpr(operand))));
/*     */   }
/*     */ 
/*     */   
/*     */   public SignedByteExpr shiftLeft(GExpr operand) {
/* 125 */     return lift(Expressions.i2b(Expressions.shiftLeft(jexpr(), jexpr(operand))));
/*     */   }
/*     */ 
/*     */   
/*     */   public SignedByteExpr shiftRight(GExpr operand) {
/* 130 */     return lift(Expressions.i2b(Expressions.shiftRight(jexpr(), jexpr(operand))));
/*     */   }
/*     */ 
/*     */   
/*     */   public SignedByteExpr rotateLeft(GExpr operand) {
/* 135 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public GimplePrimitiveType getType() {
/* 141 */     return (GimplePrimitiveType)new GimpleIntegerType(8);
/*     */   }
/*     */ 
/*     */   
/*     */   public RealExpr toRealExpr() {
/* 146 */     return toReal(32);
/*     */   }
/*     */ 
/*     */   
/*     */   public IntExpr toSignedInt(int precision) {
/* 151 */     switch (precision) {
/*     */       case 8:
/* 153 */         return this;
/*     */       case 16:
/* 155 */         return new ShortExpr(jexpr());
/*     */       case 32:
/* 157 */         return new SignedIntExpr(jexpr());
/*     */       case 64:
/* 159 */         return new SignedLongExpr(Expressions.i2l(jexpr()));
/*     */     } 
/* 161 */     throw new IllegalArgumentException("signed" + precision);
/*     */   }
/*     */ 
/*     */   
/*     */   public IntExpr toUnsignedInt(int precision) {
/* 166 */     switch (precision) {
/*     */       case 8:
/* 168 */         return new UnsignedSmallIntExpr(8, Expressions.bitwiseAnd(jexpr(), 255));
/*     */       case 16:
/* 170 */         return new UnsignedSmallIntExpr(16, Expressions.i2c(jexpr()));
/*     */       case 32:
/* 172 */         return new UnsignedIntExpr(jexpr());
/*     */       case 64:
/* 174 */         return new UnsignedLongExpr(Expressions.i2l(jexpr()));
/*     */     } 
/* 176 */     throw new UnsupportedOperationException("unsigned" + precision);
/*     */   }
/*     */ 
/*     */   
/*     */   public RealExpr toReal(int precision) {
/* 181 */     return (new RealExpr(new GimpleRealType(32), Expressions.i2f(jexpr()))).toReal(precision);
/*     */   }
/*     */   
/*     */   private JExpr jexpr(GExpr operand) {
/* 185 */     return operand.toPrimitiveExpr().toSignedInt(8).jexpr();
/*     */   }
/*     */   
/*     */   private SignedByteExpr lift(JExpr expr) {
/* 189 */     return new SignedByteExpr(expr);
/*     */   }
/*     */ 
/*     */   
/*     */   public BooleanExpr toBooleanExpr() {
/* 194 */     return BooleanExpr.fromInt(jexpr());
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/type/primitive/SignedByteExpr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */