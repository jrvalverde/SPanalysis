/*     */ package org.renjin.gcc.codegen.type.primitive;
/*     */ 
/*     */ import javax.annotation.Nullable;
/*     */ import org.renjin.gcc.codegen.MethodGenerator;
/*     */ import org.renjin.gcc.codegen.condition.Comparison;
/*     */ import org.renjin.gcc.codegen.condition.ConditionGenerator;
/*     */ import org.renjin.gcc.codegen.condition.InverseConditionGenerator;
/*     */ import org.renjin.gcc.codegen.expr.Expressions;
/*     */ import org.renjin.gcc.codegen.expr.GExpr;
/*     */ import org.renjin.gcc.codegen.expr.JExpr;
/*     */ import org.renjin.gcc.codegen.expr.JLValue;
/*     */ import org.renjin.gcc.codegen.expr.PtrExpr;
/*     */ import org.renjin.gcc.codegen.type.NumericExpr;
/*     */ import org.renjin.gcc.codegen.type.complex.ComplexExpr;
/*     */ import org.renjin.gcc.gimple.GimpleOp;
/*     */ import org.renjin.gcc.gimple.type.GimplePrimitiveType;
/*     */ import org.renjin.gcc.gimple.type.GimpleRealType;
/*     */ import org.renjin.repackaged.asm.Label;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RealExpr
/*     */   extends AbstractPrimitiveExpr
/*     */   implements NumericExpr
/*     */ {
/*     */   private GimpleRealType realType;
/*     */   private Type jvmType;
/*     */   
/*     */   public RealExpr(GimpleRealType realType, JExpr expr, @Nullable PtrExpr address) {
/*  48 */     super(expr, address);
/*  49 */     this.realType = realType;
/*  50 */     this.jvmType = realType.jvmType();
/*     */   }
/*     */   
/*     */   public RealExpr(GimpleRealType realType, JExpr expr) {
/*  54 */     this(realType, expr, null);
/*     */   }
/*     */   
/*     */   public int getPrecision() {
/*  58 */     return this.realType.getPrecision();
/*     */   }
/*     */ 
/*     */   
/*     */   public RealExpr plus(GExpr operand) {
/*  63 */     return lift(Expressions.sum(jexpr(), jexpr(operand)));
/*     */   }
/*     */ 
/*     */   
/*     */   public RealExpr minus(GExpr operand) {
/*  68 */     return lift(Expressions.difference(jexpr(), jexpr(operand)));
/*     */   }
/*     */ 
/*     */   
/*     */   public RealExpr multiply(GExpr operand) {
/*  73 */     return lift(Expressions.product(jexpr(), jexpr(operand)));
/*     */   }
/*     */ 
/*     */   
/*     */   public RealExpr divide(GExpr operand) {
/*  78 */     return lift(Expressions.divide(jexpr(), jexpr(operand)));
/*     */   }
/*     */ 
/*     */   
/*     */   public NumericExpr remainder(GExpr operand) {
/*  83 */     return lift(Expressions.remainder(jexpr(), jexpr()));
/*     */   }
/*     */ 
/*     */   
/*     */   public RealExpr negative() {
/*  88 */     return lift(Expressions.negative(jexpr()));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public RealExpr min(GExpr operand) {
/*  94 */     return lift(Expressions.staticMethodCall(Math.class, "min", minMaxSignature(), new JExpr[] { jexpr(), jexpr(operand) }));
/*     */   }
/*     */   
/*     */   public RealExpr max(GExpr operand) {
/*  98 */     return lift(Expressions.staticMethodCall(Math.class, "max", minMaxSignature(), new JExpr[] { jexpr(), jexpr(operand) }));
/*     */   }
/*     */ 
/*     */   
/*     */   public RealExpr absoluteValue() {
/* 103 */     return lift(Expressions.staticMethodCall(Math.class, "abs", absSignature(), new JExpr[] { jexpr() }));
/*     */   }
/*     */   
/*     */   private String absSignature() {
/* 107 */     return Type.getMethodDescriptor(this.jvmType, new Type[] { this.jvmType });
/*     */   }
/*     */   
/*     */   private String minMaxSignature() {
/* 111 */     return Type.getMethodDescriptor(this.jvmType, new Type[] { this.jvmType, this.jvmType });
/*     */   }
/*     */   
/*     */   private JExpr jexpr(GExpr operand) {
/* 115 */     return operand.toPrimitiveExpr().toReal(getPrecision()).jexpr();
/*     */   }
/*     */ 
/*     */   
/*     */   public ConditionGenerator ordered(GExpr operand) {
/* 120 */     final JExpr x = jexpr();
/* 121 */     final JExpr y = jexpr(operand);
/*     */     
/* 123 */     return new ConditionGenerator()
/*     */       {
/*     */         public void emitJump(MethodGenerator mv, Label trueLabel, Label falseLabel) {
/* 126 */           x.load(mv);
/* 127 */           mv.invokestatic(Double.class, "isNaN", Type.getMethodDescriptor(Type.BOOLEAN_TYPE, new Type[] { this.val$x.getType() }));
/* 128 */           mv.ifne(falseLabel);
/* 129 */           y.load(mv);
/* 130 */           mv.invokestatic(Double.class, "isNaN", Type.getMethodDescriptor(Type.BOOLEAN_TYPE, new Type[] { this.val$y.getType() }));
/* 131 */           mv.ifne(falseLabel);
/* 132 */           mv.goTo(trueLabel);
/*     */         }
/*     */       };
/*     */   }
/*     */   
/*     */   public ConditionGenerator unordered(GExpr operand) {
/* 138 */     return (ConditionGenerator)new InverseConditionGenerator(ordered(operand));
/*     */   }
/*     */   
/*     */   private RealExpr lift(JExpr expr) {
/* 142 */     return new RealExpr(this.realType, expr);
/*     */   }
/*     */   
/*     */   public IntExpr toSignedInt() {
/* 146 */     switch (getPrecision()) {
/*     */       case 32:
/* 148 */         return new SignedIntExpr(Expressions.f2i(jexpr()));
/*     */       case 64:
/* 150 */         return new SignedLongExpr(Expressions.d2l(jexpr()));
/*     */     } 
/* 152 */     throw new IllegalStateException("precision: " + getPrecision());
/*     */   }
/*     */ 
/*     */   
/*     */   public GimplePrimitiveType getType() {
/* 157 */     return (GimplePrimitiveType)this.realType;
/*     */   }
/*     */ 
/*     */   
/*     */   public IntExpr toIntExpr() {
/* 162 */     return toSignedInt();
/*     */   }
/*     */ 
/*     */   
/*     */   public RealExpr toRealExpr() {
/* 167 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public BooleanExpr toBooleanExpr() {
/* 172 */     return toIntExpr().toBooleanExpr();
/*     */   }
/*     */ 
/*     */   
/*     */   public IntExpr toSignedInt(int precision) {
/* 177 */     boolean isDouble = this.jvmType.equals(Type.DOUBLE_TYPE);
/* 178 */     switch (precision) {
/*     */       case 64:
/* 180 */         return new SignedLongExpr(isDouble ? Expressions.d2l(jexpr()) : Expressions.f2l(jexpr()));
/*     */       case 8:
/*     */       case 16:
/*     */       case 32:
/* 184 */         return (new SignedIntExpr(isDouble ? Expressions.d2i(jexpr()) : Expressions.f2i(jexpr()))).toSignedInt(precision);
/*     */     } 
/*     */     
/* 187 */     return toSignedInt().toSignedInt(precision);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IntExpr toUnsignedInt(int precision) {
/* 194 */     if (this.jvmType.equals(Type.FLOAT_TYPE)) {
/* 195 */       return (new UnsignedLongExpr(Expressions.f2l(jexpr()))).toUnsignedInt(precision);
/*     */     }
/* 197 */     return (new UnsignedLongExpr(Expressions.d2l(jexpr()))).toUnsignedInt(precision);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public RealExpr toReal(int precision) {
/* 203 */     if (getPrecision() == precision) {
/* 204 */       return this;
/*     */     }
/* 206 */     return new RealExpr(new GimpleRealType(precision), jexpr(precision));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConditionGenerator compareTo(GimpleOp op, GExpr operand) {
/* 230 */     switch (op) {
/*     */       case ORDERED_EXPR:
/* 232 */         return ordered(operand);
/*     */       case UNORDERED_EXPR:
/* 234 */         return unordered(operand);
/*     */       case UNGT_EXPR:
/*     */       case LT_EXPR:
/*     */       case LE_EXPR:
/* 238 */         return (ConditionGenerator)new Comparison(op, Expressions.cmpg(jexpr(), jexpr(operand)));
/*     */     } 
/* 240 */     return (ConditionGenerator)new Comparison(op, Expressions.cmpl(jexpr(), jexpr(operand)));
/*     */   }
/*     */ 
/*     */   
/*     */   private JExpr jexpr(int targetPrecision) {
/* 245 */     if (getPrecision() == targetPrecision || (
/* 246 */       getPrecision() == 64 && targetPrecision == 96) || (
/* 247 */       getPrecision() == 96 && targetPrecision == 64))
/* 248 */       return jexpr(); 
/* 249 */     if (getPrecision() == 32 && (targetPrecision == 64 || targetPrecision == 96))
/* 250 */       return Expressions.f2d(jexpr()); 
/* 251 */     if ((getPrecision() == 64 || getPrecision() == 96) && targetPrecision == 32) {
/* 252 */       return Expressions.d2f(jexpr());
/*     */     }
/* 254 */     throw new IllegalArgumentException(getPrecision() + "=>" + targetPrecision);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void store(MethodGenerator mv, GExpr rhs) {
/* 260 */     ((JLValue)jexpr()).store(mv, jexpr(rhs));
/*     */   }
/*     */ 
/*     */   
/*     */   public NumericExpr toNumericExpr() {
/* 265 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public ComplexExpr toComplexExpr() {
/* 270 */     return new ComplexExpr(jexpr(), Expressions.zero(jexpr().getType()));
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/type/primitive/RealExpr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */