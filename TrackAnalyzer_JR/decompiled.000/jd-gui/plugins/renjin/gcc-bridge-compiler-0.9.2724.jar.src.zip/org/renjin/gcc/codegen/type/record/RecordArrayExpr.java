/*     */ package org.renjin.gcc.codegen.type.record;
/*     */ 
/*     */ import org.renjin.gcc.InternalCompilerException;
/*     */ import org.renjin.gcc.codegen.MethodGenerator;
/*     */ import org.renjin.gcc.codegen.array.FatArrayExpr;
/*     */ import org.renjin.gcc.codegen.expr.ArrayElement;
/*     */ import org.renjin.gcc.codegen.expr.Expressions;
/*     */ import org.renjin.gcc.codegen.expr.GExpr;
/*     */ import org.renjin.gcc.codegen.expr.JExpr;
/*     */ import org.renjin.gcc.codegen.expr.PtrExpr;
/*     */ import org.renjin.gcc.codegen.fatptr.FatPtr;
/*     */ import org.renjin.gcc.codegen.fatptr.FatPtrPair;
/*     */ import org.renjin.gcc.codegen.fatptr.ValueFunction;
/*     */ import org.renjin.gcc.codegen.type.NumericExpr;
/*     */ import org.renjin.gcc.codegen.type.UnsupportedCastException;
/*     */ import org.renjin.gcc.codegen.type.fun.FunPtrExpr;
/*     */ import org.renjin.gcc.codegen.type.primitive.PrimitiveExpr;
/*     */ import org.renjin.gcc.codegen.type.primitive.PrimitiveType;
/*     */ import org.renjin.gcc.codegen.type.primitive.PrimitiveValueFunction;
/*     */ import org.renjin.gcc.codegen.type.voidt.VoidPtrExpr;
/*     */ import org.renjin.gcc.codegen.vptr.VArrayExpr;
/*     */ import org.renjin.gcc.codegen.vptr.VPtrExpr;
/*     */ import org.renjin.gcc.codegen.vptr.VPtrRecordExpr;
/*     */ import org.renjin.gcc.gimple.type.GimpleArrayType;
/*     */ import org.renjin.gcc.gimple.type.GimplePrimitiveType;
/*     */ import org.renjin.gcc.gimple.type.GimpleRecordType;
/*     */ import org.renjin.gcc.gimple.type.GimpleType;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class RecordArrayExpr
/*     */   implements RecordExpr
/*     */ {
/*     */   private RecordArrayValueFunction valueFunction;
/*     */   private JExpr array;
/*     */   private JExpr offset;
/*     */   private int arrayLength;
/*     */   
/*     */   public RecordArrayExpr(RecordArrayValueFunction valueFunction, JExpr array, JExpr offset, int arrayLength) {
/*  60 */     this.valueFunction = valueFunction;
/*  61 */     this.array = array;
/*  62 */     this.offset = offset;
/*  63 */     this.arrayLength = arrayLength;
/*     */   }
/*     */   
/*     */   public RecordArrayExpr(RecordArrayValueFunction valueFunction, JExpr array, int arrayLength) {
/*  67 */     this(valueFunction, array, Expressions.zero(), arrayLength);
/*     */   }
/*     */ 
/*     */   
/*     */   public PtrExpr addressOf() {
/*  72 */     return (PtrExpr)new FatPtrPair(this.valueFunction, this.array, this.offset);
/*     */   }
/*     */ 
/*     */   
/*     */   public FunPtrExpr toFunPtr() throws UnsupportedCastException {
/*  77 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public FatArrayExpr toArrayExpr() throws UnsupportedCastException {
/*  82 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public PrimitiveExpr toPrimitiveExpr() throws UnsupportedCastException {
/*  87 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public VoidPtrExpr toVoidPtrExpr() throws UnsupportedCastException {
/*  92 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public VPtrExpr toVPtrExpr() throws UnsupportedCastException {
/*  97 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public ProvidedPtrExpr toProvidedPtrExpr(Type jvmType) {
/* 102 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public FatPtr toFatPtrExpr(ValueFunction valueFunction) {
/* 107 */     if (valueFunction.getValueType().equals(valueFunction.getValueType())) {
/* 108 */       return (FatPtr)new FatPtrPair(valueFunction, this.array, this.offset);
/*     */     }
/* 110 */     throw new UnsupportedCastException();
/*     */   }
/*     */ 
/*     */   
/*     */   public VPtrRecordExpr toVPtrRecord(GimpleRecordType recordType) {
/* 115 */     VPtrExpr pointer = (new FatPtrPair(this.valueFunction, this.array, this.offset)).toVPtrExpr();
/* 116 */     return new VPtrRecordExpr(recordType, pointer);
/*     */   }
/*     */ 
/*     */   
/*     */   public VArrayExpr toVArray(GimpleArrayType arrayType) {
/* 121 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public NumericExpr toNumericExpr() {
/* 126 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void store(MethodGenerator mv, GExpr rhs) {
/* 133 */     if (rhs instanceof FatPtrPair) {
/* 134 */       FatPtrPair fatPtrExpr = (FatPtrPair)rhs;
/* 135 */       mv.arrayCopy(fatPtrExpr.getArray(), fatPtrExpr.getOffset(), this.array, this.offset, Expressions.constantInt(this.arrayLength));
/* 136 */     } else if (rhs instanceof RecordArrayExpr) {
/* 137 */       RecordArrayExpr arrayRhs = (RecordArrayExpr)rhs;
/* 138 */       mv.arrayCopy(arrayRhs.getArray(), arrayRhs.getOffset(), this.array, this.offset, Expressions.constantInt(this.arrayLength));
/*     */     } else {
/* 140 */       throw new InternalCompilerException("Cannot assign " + rhs + " to " + this);
/*     */     } 
/*     */   }
/*     */   
/*     */   public JExpr getArray() {
/* 145 */     return this.array;
/*     */   }
/*     */   
/*     */   public JExpr getOffset() {
/* 149 */     return this.offset;
/*     */   }
/*     */   
/*     */   public JExpr copyArray() {
/* 153 */     return Expressions.copyOfArrayRange(this.array, this.offset, Expressions.sum(this.offset, this.arrayLength));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GExpr memberOf(MethodGenerator mv, int fieldOffsetBits, int size, GimpleType memberType) {
/* 162 */     JExpr fieldOffset = Expressions.constantInt(fieldOffsetBits / 8 / this.valueFunction.getArrayElementBytes());
/* 163 */     JExpr offset = Expressions.sum(this.offset, fieldOffset);
/*     */ 
/*     */     
/* 166 */     FatPtrPair address = new FatPtrPair(this.valueFunction, this.array, offset);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 171 */     Type fieldType = this.valueFunction.getValueType();
/*     */     
/* 173 */     if (memberType instanceof GimplePrimitiveType) {
/* 174 */       PrimitiveType expectedType = PrimitiveType.of((GimplePrimitiveType)memberType);
/*     */ 
/*     */       
/* 177 */       if (expectedType.jvmType().equals(fieldType)) {
/* 178 */         ArrayElement arrayElement = Expressions.elementAt(this.array, offset);
/* 179 */         return (GExpr)expectedType.fromStackValue((JExpr)arrayElement, (PtrExpr)address);
/*     */       } 
/*     */       
/* 182 */       throw new UnsupportedOperationException("TODO: " + fieldType + " -> " + expectedType);
/*     */     } 
/*     */     
/* 185 */     if (memberType instanceof GimpleArrayType) {
/* 186 */       GimpleArrayType arrayType = (GimpleArrayType)memberType;
/* 187 */       GimplePrimitiveType componentType = (GimplePrimitiveType)arrayType.getComponentType();
/*     */       
/* 189 */       return (GExpr)new FatArrayExpr(arrayType, (ValueFunction)new PrimitiveValueFunction(componentType), arrayType
/* 190 */           .getElementCount(), this.array, offset);
/*     */     } 
/*     */     
/* 193 */     if (memberType instanceof GimpleRecordType) {
/* 194 */       return new RecordArrayExpr(this.valueFunction, this.array, fieldOffset, memberType
/* 195 */           .sizeOf() / this.valueFunction.getArrayElementBytes());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 200 */     return (GExpr)new FatPtrPair(this.valueFunction, (PtrExpr)address, this.array, offset);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/type/record/RecordArrayExpr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */