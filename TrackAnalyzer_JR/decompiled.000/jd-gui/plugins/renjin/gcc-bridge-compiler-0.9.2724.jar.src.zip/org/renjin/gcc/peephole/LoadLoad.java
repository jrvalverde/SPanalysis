/*    */ package org.renjin.gcc.peephole;
/*    */ 
/*    */ import org.renjin.repackaged.asm.tree.AbstractInsnNode;
/*    */ import org.renjin.repackaged.asm.tree.InsnNode;
/*    */ import org.renjin.repackaged.asm.tree.VarInsnNode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LoadLoad
/*    */   implements PeepholeOptimization
/*    */ {
/*    */   public boolean apply(NodeIt it) {
/* 33 */     if (it.matches(new Pattern[] { Pattern.LOAD, Pattern.LOAD })) {
/* 34 */       VarInsnNode load1 = it.<VarInsnNode>get(0);
/* 35 */       VarInsnNode load2 = it.<VarInsnNode>get(1);
/* 36 */       if (load1.var == load2.var) {
/* 37 */         it.getList().set((AbstractInsnNode)load2, dup(load2));
/* 38 */         return true;
/*    */       } 
/*    */     } 
/* 41 */     return false;
/*    */   }
/*    */   
/*    */   private AbstractInsnNode dup(VarInsnNode load) {
/* 45 */     switch (load.getOpcode()) {
/*    */       case 22:
/*    */       case 24:
/* 48 */         return (AbstractInsnNode)new InsnNode(92);
/*    */     } 
/* 50 */     return (AbstractInsnNode)new InsnNode(89);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/peephole/LoadLoad.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */