/*    */ package org.renjin.gcc.gimple.expr;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.function.Predicate;
/*    */ import org.renjin.gcc.gimple.GimpleExprVisitor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GimpleObjectTypeRef
/*    */   extends GimpleExpr
/*    */ {
/*    */   private GimpleExpr expr;
/*    */   private GimpleExpr object;
/*    */   private GimpleExpr token;
/*    */   
/*    */   public GimpleExpr getExpr() {
/* 36 */     return this.expr;
/*    */   }
/*    */   
/*    */   public void setExpr(GimpleExpr expr) {
/* 40 */     this.expr = expr;
/*    */   }
/*    */   
/*    */   public GimpleExpr getObject() {
/* 44 */     return this.object;
/*    */   }
/*    */   
/*    */   public void setObject(GimpleExpr object) {
/* 48 */     this.object = object;
/*    */   }
/*    */   
/*    */   public GimpleExpr getToken() {
/* 52 */     return this.token;
/*    */   }
/*    */   
/*    */   public void setToken(GimpleExpr token) {
/* 56 */     this.token = token;
/*    */   }
/*    */ 
/*    */   
/*    */   public void find(Predicate<? super GimpleExpr> predicate, List<GimpleExpr> results) {
/* 61 */     this.expr.find(predicate, results);
/* 62 */     this.object.find(predicate, results);
/* 63 */     this.token.find(predicate, results);
/*    */   }
/*    */ 
/*    */   
/*    */   public void replaceAll(Predicate<? super GimpleExpr> predicate, GimpleExpr newExpr) {
/* 68 */     this.expr = replaceOrDescend(this.expr, predicate, newExpr);
/* 69 */     this.object = replaceOrDescend(this.object, predicate, newExpr);
/* 70 */     this.token = replaceOrDescend(this.token, predicate, newExpr);
/*    */   }
/*    */ 
/*    */   
/*    */   public void accept(GimpleExprVisitor visitor) {
/* 75 */     visitor.visitObjectTypeRef(this);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 80 */     return "ObjectTypeRef{" + this.expr + ", " + this.object + ", " + this.token + "}";
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/gimple/expr/GimpleObjectTypeRef.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */