/*    */ package org.renjin.gcc.gimple.expr;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.function.Predicate;
/*    */ import org.renjin.gcc.gimple.GimpleExprVisitor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class GimpleComplexPartExpr
/*    */   extends GimpleLValue
/*    */ {
/*    */   private GimpleExpr complexValue;
/*    */   
/*    */   public GimpleExpr getComplexValue() {
/* 32 */     return this.complexValue;
/*    */   }
/*    */   
/*    */   public void setComplexValue(GimpleExpr complexValue) {
/* 36 */     this.complexValue = complexValue;
/*    */   }
/*    */ 
/*    */   
/*    */   public void find(Predicate<? super GimpleExpr> predicate, List<GimpleExpr> results) {
/* 41 */     findOrDescend(this.complexValue, predicate, results);
/*    */   }
/*    */ 
/*    */   
/*    */   public void replaceAll(Predicate<? super GimpleExpr> predicate, GimpleExpr newExpr) {
/* 46 */     this.complexValue = replaceOrDescend(this.complexValue, predicate, newExpr);
/*    */   }
/*    */ 
/*    */   
/*    */   public void accept(GimpleExprVisitor visitor) {
/* 51 */     visitor.visitComplexPart(this);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/gimple/expr/GimpleComplexPartExpr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */