/*    */ package org.renjin.gcc.codegen.type.fun;
/*    */ 
/*    */ import java.lang.invoke.MethodHandle;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import java.util.Optional;
/*    */ import org.renjin.gcc.codegen.MethodGenerator;
/*    */ import org.renjin.gcc.codegen.expr.GExpr;
/*    */ import org.renjin.gcc.codegen.expr.JExpr;
/*    */ import org.renjin.gcc.codegen.expr.JLValue;
/*    */ import org.renjin.gcc.codegen.type.ParamStrategy;
/*    */ import org.renjin.gcc.codegen.type.voidt.VoidPtrExpr;
/*    */ import org.renjin.gcc.codegen.var.VarAllocator;
/*    */ import org.renjin.gcc.gimple.GimpleParameter;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FunPtrParamStrategy
/*    */   implements ParamStrategy
/*    */ {
/*    */   public List<Type> getParameterTypes() {
/* 38 */     return Collections.singletonList(Type.getType(MethodHandle.class));
/*    */   }
/*    */ 
/*    */   
/*    */   public List<String> getParameterNames(String name) {
/* 43 */     return Collections.singletonList(name);
/*    */   }
/*    */ 
/*    */   
/*    */   public GExpr emitInitialization(MethodGenerator methodVisitor, GimpleParameter parameter, List<JLValue> paramVars, VarAllocator localVars) {
/* 48 */     return (GExpr)new VoidPtrExpr((JExpr)paramVars.get(0));
/*    */   }
/*    */ 
/*    */   
/*    */   public void loadParameter(MethodGenerator mv, Optional<GExpr> argument) {
/* 53 */     if (!argument.isPresent()) {
/* 54 */       mv.aconst(null);
/*    */     } else {
/* 56 */       ((GExpr)argument.get()).toFunPtr().jexpr().load(mv);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/type/fun/FunPtrParamStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */