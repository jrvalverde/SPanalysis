/*     */ package org.renjin.gcc.codegen.var;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Optional;
/*     */ import javax.annotation.Nonnull;
/*     */ import org.renjin.gcc.codegen.MethodGenerator;
/*     */ import org.renjin.gcc.codegen.expr.Expressions;
/*     */ import org.renjin.gcc.codegen.expr.JExpr;
/*     */ import org.renjin.gcc.codegen.expr.JLValue;
/*     */ import org.renjin.repackaged.asm.Label;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ import org.renjin.repackaged.guava.collect.Lists;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocalVarAllocator
/*     */   extends VarAllocator
/*     */ {
/*     */   public static class LocalVar
/*     */     implements JLValue
/*     */   {
/*     */     private String name;
/*     */     private int index;
/*     */     private Type type;
/*     */     private Optional<JExpr> initialValue;
/*     */     
/*     */     public LocalVar(String name, int index, Type type, Optional<JExpr> value) {
/*  48 */       this.name = name;
/*  49 */       this.index = index;
/*  50 */       this.type = type;
/*  51 */       this.initialValue = value;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nonnull
/*     */     public Type getType() {
/*  57 */       return this.type;
/*     */     }
/*     */ 
/*     */     
/*     */     public void load(@Nonnull MethodGenerator mv) {
/*  62 */       mv.visitVarInsn(this.type.getOpcode(21), this.index);
/*     */     }
/*     */     
/*     */     public int getIndex() {
/*  66 */       return this.index;
/*     */     }
/*     */ 
/*     */     
/*     */     public void store(MethodGenerator mv, JExpr value) {
/*  71 */       value.load(mv);
/*  72 */       if (Expressions.requiresCast(value.getType(), this.type)) {
/*  73 */         mv.checkcast(this.type);
/*     */       }
/*  75 */       store(mv);
/*     */     }
/*     */     
/*     */     public void store(MethodGenerator mv) {
/*  79 */       mv.visitVarInsn(this.type.getOpcode(54), this.index);
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/*  84 */       return "LocalVar[" + this.name + ":" + this.type + "]";
/*     */     }
/*     */   }
/*     */   
/*  88 */   private int slots = 0;
/*  89 */   private List<LocalVar> names = Lists.newArrayList();
/*     */ 
/*     */   
/*     */   public LocalVar reserve(String name, Type type) {
/*  93 */     return reserve(name, type, Optional.empty());
/*     */   }
/*     */ 
/*     */   
/*     */   public LocalVar reserve(String name, Type type, JExpr initialValue) {
/*  98 */     return reserve(name, type, Optional.of(initialValue));
/*     */   }
/*     */   
/*     */   public LocalVar reserve(Type type) {
/* 102 */     return reserve((String)null, type);
/*     */   }
/*     */   
/*     */   private LocalVar reserve(String name, Type type, Optional<JExpr> initialValue) {
/* 106 */     int index = this.slots;
/* 107 */     this.slots += type.getSize();
/* 108 */     LocalVar var = new LocalVar(name, index, type, initialValue);
/* 109 */     this.names.add(var);
/* 110 */     return var;
/*     */   }
/*     */   
/*     */   public void initializeVariables(MethodGenerator mv) {
/* 114 */     List<LocalVar> toInitialize = Lists.newArrayList(this.names);
/* 115 */     for (LocalVar name : toInitialize) {
/* 116 */       if (name.initialValue.isPresent()) {
/* 117 */         name.store(mv, name.initialValue.get());
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void emitDebugging(MethodGenerator mv, Label start, Label end) {
/* 124 */     for (LocalVar entry : this.names) {
/* 125 */       if (entry.name != null) {
/* 126 */         mv.visitLocalVariable(toJavaSafeName(entry.name), entry.type.getDescriptor(), null, start, end, entry.index);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public LocalVar tempIfNeeded(MethodGenerator mv, JExpr expr) {
/* 133 */     if (expr instanceof LocalVar) {
/* 134 */       return (LocalVar)expr;
/*     */     }
/* 136 */     LocalVar instanceVar = mv.getLocalVarAllocator().reserve(expr.getType());
/* 137 */     instanceVar.store(mv, expr);
/* 138 */     return instanceVar;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/var/LocalVarAllocator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */