/*    */ package org.renjin.gcc.codegen.call;
/*    */ 
/*    */ import org.renjin.gcc.codegen.MethodGenerator;
/*    */ import org.renjin.gcc.codegen.expr.ExprFactory;
/*    */ import org.renjin.gcc.codegen.expr.GExpr;
/*    */ import org.renjin.gcc.codegen.expr.JExpr;
/*    */ import org.renjin.gcc.codegen.expr.PtrExpr;
/*    */ import org.renjin.gcc.codegen.type.TypeOracle;
/*    */ import org.renjin.gcc.gimple.expr.GimpleExpr;
/*    */ import org.renjin.gcc.gimple.statement.GimpleCall;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MemSetGenerator
/*    */   implements CallGenerator
/*    */ {
/*    */   public static final String MEMSET_CHECK_BUILTIN = "__memset_chk";
/*    */   private final TypeOracle typeOracle;
/*    */   
/*    */   public MemSetGenerator(TypeOracle typeOracle) {
/* 43 */     this.typeOracle = typeOracle;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void emitCall(MethodGenerator mv, ExprFactory exprFactory, GimpleCall call) {
/* 50 */     PtrExpr pointer = (PtrExpr)exprFactory.findGenerator(call.getOperand(0));
/* 51 */     JExpr byteValue = exprFactory.findPrimitiveGenerator(call.getOperand(1));
/* 52 */     JExpr length = exprFactory.findPrimitiveGenerator(call.getOperand(2));
/*    */     
/* 54 */     pointer.memorySet(mv, byteValue, length);
/*    */     
/* 56 */     if (call.getLhs() != null) {
/* 57 */       GExpr lhs = exprFactory.findGenerator((GimpleExpr)call.getLhs());
/* 58 */       lhs.store(mv, (GExpr)pointer);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/call/MemSetGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */