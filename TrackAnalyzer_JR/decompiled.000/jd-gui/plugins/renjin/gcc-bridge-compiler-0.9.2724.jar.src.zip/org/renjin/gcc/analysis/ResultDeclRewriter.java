/*    */ package org.renjin.gcc.analysis;
/*    */ 
/*    */ import org.renjin.gcc.gimple.GimpleCompilationUnit;
/*    */ import org.renjin.gcc.gimple.GimpleExprVisitor;
/*    */ import org.renjin.gcc.gimple.GimpleFunction;
/*    */ import org.renjin.gcc.gimple.GimpleVarDecl;
/*    */ import org.renjin.gcc.gimple.expr.GimpleAddressOf;
/*    */ import org.renjin.gcc.gimple.expr.GimpleExpr;
/*    */ import org.renjin.gcc.gimple.expr.GimpleResultDecl;
/*    */ import org.renjin.gcc.gimple.expr.GimpleVariableRef;
/*    */ import org.renjin.gcc.logging.LogManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ResultDeclRewriter
/*    */   implements FunctionBodyTransformer
/*    */ {
/* 39 */   public static final ResultDeclRewriter INSTANCE = new ResultDeclRewriter();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean transform(LogManager logManager, GimpleCompilationUnit unit, GimpleFunction fn) {
/* 45 */     ResultDeclMatcher matcher = new ResultDeclMatcher();
/* 46 */     fn.accept(matcher);
/*    */     
/* 48 */     if (matcher.present) {
/*    */       GimpleVariableRef gimpleVariableRef;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 56 */       if (fn
/* 57 */         .getReturnType() instanceof org.renjin.gcc.gimple.type.GimpleReferenceType && fn
/* 58 */         .getReturnType().getBaseType() instanceof org.renjin.gcc.gimple.type.GimpleRecordType) {
/*    */         
/* 60 */         GimpleVarDecl returnVar = fn.addVarDecl(fn.getReturnType().getBaseType());
/* 61 */         GimpleAddressOf gimpleAddressOf = new GimpleAddressOf((GimpleExpr)new GimpleVariableRef(returnVar.getId(), returnVar.getType()));
/*    */       } else {
/*    */         
/* 64 */         GimpleVarDecl returnVar = fn.addVarDecl(fn.getReturnType());
/* 65 */         gimpleVariableRef = new GimpleVariableRef(returnVar.getId(), fn.getReturnType());
/*    */       } 
/*    */       
/* 68 */       fn.replaceAll(expr -> expr instanceof GimpleResultDecl, (GimpleExpr)gimpleVariableRef);
/*    */       
/* 70 */       assertResultDeclsAreReplaced(fn);
/*    */       
/* 72 */       return true;
/*    */     } 
/*    */     
/* 75 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   private void assertResultDeclsAreReplaced(GimpleFunction fn) {
/* 80 */     ResultDeclMatcher matcher = new ResultDeclMatcher();
/* 81 */     fn.accept(matcher);
/* 82 */     if (matcher.present) {
/* 83 */       throw new AssertionError("ResultDecls remain in:\n" + fn);
/*    */     }
/*    */   }
/*    */   
/*    */   private class ResultDeclMatcher
/*    */     extends GimpleExprVisitor
/*    */   {
/*    */     private boolean present = false;
/*    */     
/*    */     public void visitResultDecl(GimpleResultDecl resultDecl) {
/* 93 */       this.present = true;
/*    */     }
/*    */     
/*    */     private ResultDeclMatcher() {}
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/analysis/ResultDeclRewriter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */