package org.renjin.gcc.codegen.type;

import java.util.List;
import java.util.Optional;
import org.renjin.gcc.codegen.MethodGenerator;
import org.renjin.gcc.codegen.expr.GExpr;
import org.renjin.gcc.codegen.expr.JLValue;
import org.renjin.gcc.codegen.var.VarAllocator;
import org.renjin.gcc.gimple.GimpleParameter;
import org.renjin.repackaged.asm.Type;

public interface ParamStrategy {
  List<Type> getParameterTypes();
  
  List<String> getParameterNames(String paramString);
  
  GExpr emitInitialization(MethodGenerator paramMethodGenerator, GimpleParameter paramGimpleParameter, List<JLValue> paramList, VarAllocator paramVarAllocator);
  
  void loadParameter(MethodGenerator paramMethodGenerator, Optional<GExpr> paramOptional);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/type/ParamStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */