/*    */ package org.renjin.gcc.codegen.type.voidt;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import java.util.Optional;
/*    */ import org.renjin.gcc.codegen.MethodGenerator;
/*    */ import org.renjin.gcc.codegen.expr.GExpr;
/*    */ import org.renjin.gcc.codegen.expr.JExpr;
/*    */ import org.renjin.gcc.codegen.fatptr.FatPtrPair;
/*    */ import org.renjin.gcc.codegen.fatptr.Memset;
/*    */ import org.renjin.gcc.codegen.fatptr.ValueFunction;
/*    */ import org.renjin.gcc.codegen.fatptr.WrappedFatPtrExpr;
/*    */ import org.renjin.gcc.codegen.vptr.VPtrExpr;
/*    */ import org.renjin.gcc.gimple.type.GimpleType;
/*    */ import org.renjin.gcc.gimple.type.GimpleVoidType;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VoidPtrValueFunction
/*    */   implements ValueFunction
/*    */ {
/*    */   public Type getValueType() {
/* 41 */     return Type.getType(Object.class);
/*    */   }
/*    */ 
/*    */   
/*    */   public GimpleType getGimpleValueType() {
/* 46 */     return (GimpleType)(new GimpleVoidType()).pointerTo();
/*    */   }
/*    */ 
/*    */   
/*    */   public int getElementLength() {
/* 51 */     return 1;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getArrayElementBytes() {
/* 56 */     return 4;
/*    */   }
/*    */ 
/*    */   
/*    */   public Optional<JExpr> getValueConstructor() {
/* 61 */     return Optional.empty();
/*    */   }
/*    */ 
/*    */   
/*    */   public VPtrExpr toVPtr(JExpr array, JExpr offset) {
/* 66 */     throw new UnsupportedOperationException("TODO");
/*    */   }
/*    */ 
/*    */   
/*    */   public GExpr dereference(JExpr array, JExpr offset) {
/* 71 */     return (GExpr)new DereferencedVoidPtr(array, offset);
/*    */   }
/*    */ 
/*    */   
/*    */   public GExpr dereference(WrappedFatPtrExpr wrapperInstance) {
/* 76 */     return (GExpr)new DereferencedWrappedVoidPtr(wrapperInstance);
/*    */   }
/*    */ 
/*    */   
/*    */   public List<JExpr> toArrayValues(GExpr expr) {
/* 81 */     FatPtrPair fatPtrExpr = (FatPtrPair)expr;
/* 82 */     return Collections.singletonList(fatPtrExpr.wrap());
/*    */   }
/*    */ 
/*    */   
/*    */   public void memoryCopy(MethodGenerator mv, JExpr destinationArray, JExpr destinationOffset, JExpr sourceArray, JExpr sourceOffset, JExpr valueCount) {
/* 87 */     mv.arrayCopy(sourceArray, sourceOffset, destinationArray, destinationOffset, valueCount);
/*    */   }
/*    */ 
/*    */   
/*    */   public void memorySet(MethodGenerator mv, JExpr array, JExpr offset, JExpr byteValue, JExpr length) {
/* 92 */     Memset.zeroOutRefArray(mv, array, offset, length);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 97 */     return "VoidPtr";
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/type/voidt/VoidPtrValueFunction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */