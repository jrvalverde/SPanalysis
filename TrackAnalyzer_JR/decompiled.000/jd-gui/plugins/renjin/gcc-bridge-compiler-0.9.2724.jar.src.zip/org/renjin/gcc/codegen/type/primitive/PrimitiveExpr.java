package org.renjin.gcc.codegen.type.primitive;

import org.renjin.gcc.codegen.condition.ConditionGenerator;
import org.renjin.gcc.codegen.expr.GExpr;
import org.renjin.gcc.codegen.expr.JExpr;
import org.renjin.gcc.codegen.expr.PtrExpr;
import org.renjin.gcc.gimple.GimpleOp;
import org.renjin.gcc.gimple.type.GimplePrimitiveType;

public interface PrimitiveExpr extends GExpr {
  GimplePrimitiveType getType();
  
  IntExpr toIntExpr();
  
  RealExpr toRealExpr();
  
  BooleanExpr toBooleanExpr();
  
  IntExpr toSignedInt(int paramInt);
  
  IntExpr toUnsignedInt(int paramInt);
  
  RealExpr toReal(int paramInt);
  
  JExpr jexpr();
  
  ConditionGenerator compareTo(GimpleOp paramGimpleOp, GExpr paramGExpr);
  
  PtrExpr addressOfReadOnly();
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/type/primitive/PrimitiveExpr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */