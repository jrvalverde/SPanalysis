/*    */ package org.renjin.gcc.analysis;
/*    */ 
/*    */ import org.renjin.gcc.codegen.expr.GExpr;
/*    */ import org.renjin.gcc.codegen.expr.JExpr;
/*    */ import org.renjin.gcc.codegen.expr.JLValue;
/*    */ import org.renjin.gcc.codegen.type.TypeOracle;
/*    */ import org.renjin.gcc.codegen.type.primitive.NumericIntExpr;
/*    */ import org.renjin.gcc.codegen.type.primitive.PrimitiveTypeStrategy;
/*    */ import org.renjin.gcc.codegen.type.primitive.PtrCarryingExpr;
/*    */ import org.renjin.gcc.codegen.var.VarAllocator;
/*    */ import org.renjin.gcc.gimple.GimpleFunction;
/*    */ import org.renjin.gcc.gimple.GimpleVarDecl;
/*    */ import org.renjin.gcc.gimple.type.GimplePrimitiveType;
/*    */ import org.renjin.gcc.runtime.Ptr;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FunctionOracle
/*    */ {
/*    */   private final TypeOracle typeOracle;
/*    */   private final VarSet pointerCarryingIntegerVariables;
/*    */   
/*    */   public FunctionOracle(TypeOracle typeOracle, GimpleFunction function) {
/* 44 */     this.typeOracle = typeOracle;
/*    */     
/* 46 */     ControlFlowGraph cfg = new ControlFlowGraph(function);
/*    */ 
/*    */     
/* 49 */     DataFlowAnalysis<VarSet> pointerCarrierAnalysis = new DataFlowAnalysis<>(cfg, new PtrCarrierFlowFunction());
/* 50 */     this.pointerCarryingIntegerVariables = VarSet.unionAll(pointerCarrierAnalysis.getExitStates());
/*    */   }
/*    */ 
/*    */   
/*    */   public GExpr variable(GimpleVarDecl varDecl, VarAllocator allocator) {
/* 55 */     if (this.pointerCarryingIntegerVariables.contains(varDecl)) {
/* 56 */       PrimitiveTypeStrategy primitiveTypeStrategy = new PrimitiveTypeStrategy((GimplePrimitiveType)varDecl.getType());
/* 57 */       NumericIntExpr integerExpr = (NumericIntExpr)primitiveTypeStrategy.variable(varDecl, allocator);
/* 58 */       JLValue jLValue = allocator.reserve(varDecl.getNameIfPresent("ptr"), Type.getType(Ptr.class));
/*    */       
/* 60 */       return (GExpr)new PtrCarryingExpr(integerExpr, (JExpr)jLValue);
/*    */     } 
/*    */     
/* 63 */     return this.typeOracle.forType(varDecl.getType()).variable(varDecl, allocator);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/analysis/FunctionOracle.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */