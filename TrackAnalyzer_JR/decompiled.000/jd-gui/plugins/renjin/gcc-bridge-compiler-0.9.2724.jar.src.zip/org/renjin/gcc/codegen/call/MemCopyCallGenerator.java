/*    */ package org.renjin.gcc.codegen.call;
/*    */ 
/*    */ import org.renjin.gcc.InternalCompilerException;
/*    */ import org.renjin.gcc.codegen.MethodGenerator;
/*    */ import org.renjin.gcc.codegen.expr.ExprFactory;
/*    */ import org.renjin.gcc.codegen.expr.GExpr;
/*    */ import org.renjin.gcc.codegen.expr.JExpr;
/*    */ import org.renjin.gcc.codegen.expr.PtrExpr;
/*    */ import org.renjin.gcc.gimple.expr.GimpleExpr;
/*    */ import org.renjin.gcc.gimple.statement.GimpleCall;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MemCopyCallGenerator
/*    */   implements CallGenerator
/*    */ {
/*    */   public static final String BUILTIN_MEMCPY = "__builtin_memcpy";
/*    */   public static final String MEMMOVE = "memmove";
/*    */   private final boolean buffer;
/*    */   
/*    */   public MemCopyCallGenerator(boolean buffer) {
/* 42 */     this.buffer = buffer;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void emitCall(MethodGenerator mv, ExprFactory exprFactory, GimpleCall call) {
/* 48 */     if (call.getOperands().size() != 3) {
/* 49 */       throw new InternalCompilerException("memcpy() expects 3 args.");
/*    */     }
/*    */     
/* 52 */     GimpleExpr destination = call.getOperand(0);
/* 53 */     GimpleExpr source = call.getOperand(1);
/*    */     
/* 55 */     PtrExpr sourcePtr = (PtrExpr)exprFactory.findGenerator(source);
/* 56 */     PtrExpr destinationPtr = (PtrExpr)exprFactory.findGenerator(destination);
/* 57 */     JExpr length = exprFactory.findPrimitiveGenerator(call.getOperand(2));
/*    */     
/* 59 */     destinationPtr.memoryCopy(mv, sourcePtr, length, this.buffer);
/*    */     
/* 61 */     if (call.getLhs() != null) {
/*    */       
/* 63 */       GExpr lhs = exprFactory.findGenerator((GimpleExpr)call.getLhs());
/*    */       
/* 65 */       lhs.store(mv, (GExpr)destinationPtr);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/call/MemCopyCallGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */