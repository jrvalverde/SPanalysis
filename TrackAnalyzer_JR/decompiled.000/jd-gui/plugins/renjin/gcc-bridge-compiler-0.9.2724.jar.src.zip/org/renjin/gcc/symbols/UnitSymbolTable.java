/*     */ package org.renjin.gcc.symbols;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.renjin.gcc.codegen.FunctionGenerator;
/*     */ import org.renjin.gcc.codegen.call.CallGenerator;
/*     */ import org.renjin.gcc.codegen.call.FunctionCallGenerator;
/*     */ import org.renjin.gcc.codegen.call.InvocationStrategy;
/*     */ import org.renjin.gcc.codegen.expr.GExpr;
/*     */ import org.renjin.gcc.codegen.expr.JExpr;
/*     */ import org.renjin.gcc.codegen.type.fun.FunctionRefGenerator;
/*     */ import org.renjin.gcc.gimple.GimpleAlias;
/*     */ import org.renjin.gcc.gimple.GimpleCompilationUnit;
/*     */ import org.renjin.gcc.gimple.GimpleFunction;
/*     */ import org.renjin.gcc.gimple.GimpleVarDecl;
/*     */ import org.renjin.gcc.gimple.expr.GimpleFunctionRef;
/*     */ import org.renjin.gcc.gimple.expr.GimpleSymbolRef;
/*     */ import org.renjin.gcc.gimple.expr.GimpleVariableRef;
/*     */ import org.renjin.repackaged.guava.collect.Lists;
/*     */ import org.renjin.repackaged.guava.collect.Maps;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UnitSymbolTable
/*     */   implements SymbolTable
/*     */ {
/*     */   private final GlobalSymbolTable globalSymbolTable;
/*  50 */   private final Map<Long, GExpr> variableMap = Maps.newHashMap();
/*  51 */   private final List<FunctionGenerator> functions = Lists.newArrayList();
/*  52 */   private final Map<String, FunctionGenerator> functionNameMap = Maps.newHashMap();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  57 */   private final Map<Long, String> mangledNameMap = new HashMap<>();
/*     */   
/*     */   public UnitSymbolTable(GlobalSymbolTable globalSymbolTable, GimpleCompilationUnit unit) {
/*  60 */     this.globalSymbolTable = globalSymbolTable;
/*     */     
/*  62 */     for (GimpleVarDecl globalDecl : unit.getGlobalVariables()) {
/*  63 */       this.mangledNameMap.put(Long.valueOf(globalDecl.getId()), globalDecl.getMangledName());
/*     */     }
/*     */   }
/*     */   
/*     */   public GExpr getVariable(GimpleSymbolRef ref) {
/*  68 */     GExpr expr = this.variableMap.get(Long.valueOf(ref.getId()));
/*  69 */     if (expr != null) {
/*  70 */       return expr;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  78 */     GimpleVariableRef fixedUp = new GimpleVariableRef();
/*  79 */     fixedUp.setName(ref.getName());
/*  80 */     fixedUp.setMangledName(this.mangledNameMap.get(Long.valueOf(ref.getId())));
/*  81 */     fixedUp.setType(ref.getType());
/*     */     
/*  83 */     return this.globalSymbolTable.getVariable((GimpleSymbolRef)fixedUp);
/*     */   }
/*     */   
/*     */   public GExpr getGlobalVariable(GimpleVarDecl decl) {
/*  87 */     GExpr expr = this.variableMap.get(Long.valueOf(decl.getId()));
/*  88 */     if (expr == null) {
/*  89 */       throw new IllegalArgumentException("decl: " + decl);
/*     */     }
/*  91 */     return expr;
/*     */   }
/*     */   
/*     */   public void addGlobalVariable(GimpleVarDecl decl, GExpr globalVar) {
/*  95 */     this.variableMap.put(Long.valueOf(decl.getId()), globalVar);
/*  96 */     if (decl.isPublic()) {
/*  97 */       this.globalSymbolTable.addVariable(decl.getMangledName(), globalVar);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void addFunction(GimpleFunction function, FunctionGenerator functionGenerator) {
/* 103 */     this.functions.add(functionGenerator);
/*     */     
/* 105 */     for (String name : functionGenerator.getMangledNames()) {
/* 106 */       this.functionNameMap.put(name, functionGenerator);
/* 107 */       if (function.isPublic()) {
/* 108 */         this.globalSymbolTable.addFunction(name, (CallGenerator)new FunctionCallGenerator((InvocationStrategy)functionGenerator));
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public void addAlias(GimpleAlias alias) {
/* 114 */     FunctionGenerator generator = this.functionNameMap.get(alias.getDefinition());
/*     */ 
/*     */     
/* 117 */     if (generator != null) {
/* 118 */       generator.addAlias(alias.getAlias());
/* 119 */       if (alias.isPublic()) {
/* 120 */         this.globalSymbolTable.addFunction(alias.getAlias(), (CallGenerator)new FunctionCallGenerator((InvocationStrategy)generator));
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public Collection<FunctionGenerator> getFunctions() {
/* 126 */     return this.functions;
/*     */   }
/*     */   
/*     */   public JExpr findHandle(GimpleFunctionRef functionRef) {
/* 130 */     if (this.functionNameMap.containsKey(functionRef.getName())) {
/* 131 */       return (JExpr)new FunctionRefGenerator(((FunctionGenerator)this.functionNameMap.get(functionRef.getName())).getMethodHandle());
/*     */     }
/* 133 */     return this.globalSymbolTable.findHandle(functionRef);
/*     */   }
/*     */   
/*     */   public CallGenerator findCallGenerator(GimpleFunctionRef ref) {
/* 137 */     if (this.functionNameMap.containsKey(ref.getName())) {
/* 138 */       return (CallGenerator)new FunctionCallGenerator((InvocationStrategy)this.functionNameMap.get(ref.getName()));
/*     */     }
/*     */     
/* 141 */     return this.globalSymbolTable.findCallGenerator(ref);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/symbols/UnitSymbolTable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */