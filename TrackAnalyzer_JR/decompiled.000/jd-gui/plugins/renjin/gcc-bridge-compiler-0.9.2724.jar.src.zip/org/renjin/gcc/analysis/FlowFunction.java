package org.renjin.gcc.analysis;

import java.util.List;
import org.renjin.gcc.gimple.statement.GimpleStatement;

public interface FlowFunction<T> {
  T initialState();
  
  T transfer(T paramT, Iterable<GimpleStatement> paramIterable);
  
  T join(List<T> paramList);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/analysis/FlowFunction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */