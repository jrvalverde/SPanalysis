/*     */ package org.renjin.gcc.gimple;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.renjin.gcc.gimple.type.GimpleRecordTypeDef;
/*     */ import org.renjin.repackaged.guava.collect.Iterables;
/*     */ import org.renjin.repackaged.guava.collect.Lists;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GimpleCompilationUnit
/*     */ {
/*     */   private File sourceFile;
/*     */   private String mainInputFilename;
/*  33 */   private final List<GimpleFunction> functions = Lists.newArrayList();
/*  34 */   private final List<GimpleRecordTypeDef> recordTypes = Lists.newArrayList();
/*  35 */   private final List<GimpleVarDecl> globalVariables = Lists.newArrayList();
/*  36 */   private final List<GimpleAlias> aliases = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/*  45 */     if (this.sourceFile == null) {
/*  46 */       throw new IllegalStateException("sourceFile property is null");
/*     */     }
/*     */     
/*  49 */     String filename = this.sourceFile.getName();
/*     */ 
/*     */     
/*  52 */     if (!filename.endsWith(".gimple")) {
/*  53 */       throw new IllegalStateException("Expected file name ending in .gimple");
/*     */     }
/*  55 */     filename = filename.substring(0, filename.length() - ".gimple".length());
/*     */ 
/*     */     
/*  58 */     int firstDot = filename.indexOf('.');
/*  59 */     if (firstDot != -1) {
/*  60 */       filename = filename.substring(0, firstDot);
/*     */     }
/*  62 */     return filename;
/*     */   }
/*     */   
/*     */   public String getSourceName() {
/*  66 */     int nameStart = this.mainInputFilename.lastIndexOf('/');
/*  67 */     return this.mainInputFilename.substring(nameStart + 1);
/*     */   }
/*     */   
/*     */   public String getMainInputFilename() {
/*  71 */     return this.mainInputFilename;
/*     */   }
/*     */   
/*     */   public void setMainInputFilename(String mainInputFilename) {
/*  75 */     this.mainInputFilename = mainInputFilename;
/*     */   }
/*     */   
/*     */   public List<GimpleFunction> getFunctions() {
/*  79 */     return this.functions;
/*     */   }
/*     */   
/*     */   public List<GimpleRecordTypeDef> getRecordTypes() {
/*  83 */     return this.recordTypes;
/*     */   }
/*     */   
/*     */   public List<GimpleVarDecl> getGlobalVariables() {
/*  87 */     return this.globalVariables;
/*     */   }
/*     */   
/*     */   public Iterable<GimpleDecl> getDeclarations() {
/*  91 */     return Iterables.concat(this.functions, this.globalVariables);
/*     */   }
/*     */   
/*     */   public File getSourceFile() {
/*  95 */     return this.sourceFile;
/*     */   }
/*     */   
/*     */   public void setSourceFile(File sourceFile) {
/*  99 */     this.sourceFile = sourceFile;
/*     */   }
/*     */   
/*     */   public List<GimpleAlias> getAliases() {
/* 103 */     return this.aliases;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 108 */     return "GimpleCompilationUnit{" + getSourceName() + "}";
/*     */   }
/*     */   
/*     */   public void accept(GimpleExprVisitor visitor) {
/* 112 */     for (GimpleVarDecl globalVariable : this.globalVariables) {
/* 113 */       globalVariable.accept(visitor);
/*     */     }
/* 115 */     for (GimpleFunction function : this.functions) {
/* 116 */       function.accept(visitor);
/*     */     }
/*     */   }
/*     */   
/*     */   public GimpleFunction getFunction(String mangledName) {
/* 121 */     for (GimpleFunction function : this.functions) {
/* 122 */       if (function.getMangledName().equals(mangledName)) {
/* 123 */         return function;
/*     */       }
/*     */     } 
/* 126 */     throw new IllegalArgumentException("No such function: " + mangledName);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/gimple/GimpleCompilationUnit.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */