/*     */ package org.renjin.gcc.codegen.type.primitive;
/*     */ 
/*     */ import javax.annotation.Nullable;
/*     */ import org.renjin.gcc.codegen.MethodGenerator;
/*     */ import org.renjin.gcc.codegen.condition.ConditionGenerator;
/*     */ import org.renjin.gcc.codegen.condition.IntegerComparison;
/*     */ import org.renjin.gcc.codegen.expr.Expressions;
/*     */ import org.renjin.gcc.codegen.expr.GExpr;
/*     */ import org.renjin.gcc.codegen.expr.JExpr;
/*     */ import org.renjin.gcc.codegen.expr.JLValue;
/*     */ import org.renjin.gcc.codegen.expr.PtrExpr;
/*     */ import org.renjin.gcc.codegen.type.NumericExpr;
/*     */ import org.renjin.gcc.gimple.GimpleOp;
/*     */ import org.renjin.gcc.gimple.type.GimpleIntegerType;
/*     */ import org.renjin.gcc.gimple.type.GimplePrimitiveType;
/*     */ import org.renjin.gcc.gimple.type.GimpleRealType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ShortExpr
/*     */   extends AbstractIntExpr
/*     */   implements IntExpr
/*     */ {
/*     */   public ShortExpr(JExpr expr, @Nullable PtrExpr address) {
/*  41 */     super(expr, address);
/*     */   }
/*     */   
/*     */   public ShortExpr(JExpr expr) {
/*  45 */     this(expr, (PtrExpr)null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void store(MethodGenerator mv, GExpr rhs) {
/*  50 */     ((JLValue)jexpr()).store(mv, jexpr(rhs));
/*     */   }
/*     */ 
/*     */   
/*     */   public ShortExpr plus(GExpr operand) {
/*  55 */     return lift(Expressions.i2s(Expressions.sum(jexpr(), jexpr(operand))));
/*     */   }
/*     */ 
/*     */   
/*     */   public ShortExpr minus(GExpr operand) {
/*  60 */     return lift(Expressions.i2s(Expressions.difference(jexpr(), jexpr(operand))));
/*     */   }
/*     */ 
/*     */   
/*     */   public ShortExpr multiply(GExpr operand) {
/*  65 */     return lift(Expressions.i2s(Expressions.product(jexpr(), jexpr(operand))));
/*     */   }
/*     */ 
/*     */   
/*     */   public ShortExpr divide(GExpr operand) {
/*  70 */     return lift(Expressions.i2s(Expressions.divide(jexpr(), jexpr(operand))));
/*     */   }
/*     */ 
/*     */   
/*     */   public ShortExpr negative() {
/*  75 */     return lift(Expressions.i2s(Expressions.negative(jexpr())));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ShortExpr min(GExpr operand) {
/*  81 */     return lift(Expressions.staticMethodCall(Math.class, "min", "(II)I", new JExpr[] { jexpr(), jexpr(operand) }));
/*     */   }
/*     */ 
/*     */   
/*     */   public ShortExpr max(GExpr operand) {
/*  86 */     return lift(Expressions.staticMethodCall(Math.class, "max", "(II)I", new JExpr[] { jexpr(), jexpr(operand) }));
/*     */   }
/*     */ 
/*     */   
/*     */   public ShortExpr absoluteValue() {
/*  91 */     return lift(Expressions.staticMethodCall(Math.class, "abs", "(I)I", new JExpr[] { jexpr() }));
/*     */   }
/*     */ 
/*     */   
/*     */   public ShortExpr remainder(GExpr operand) {
/*  96 */     return lift(Expressions.i2s(Expressions.remainder(jexpr(), jexpr(operand))));
/*     */   }
/*     */ 
/*     */   
/*     */   public ConditionGenerator compareTo(GimpleOp op, GExpr operand) {
/* 101 */     return (ConditionGenerator)new IntegerComparison(op, jexpr(), jexpr(operand));
/*     */   }
/*     */ 
/*     */   
/*     */   public ShortExpr bitwiseNot() {
/* 106 */     return lift(Expressions.i2s(Expressions.bitwiseXor(jexpr(), 65535)));
/*     */   }
/*     */ 
/*     */   
/*     */   public ShortExpr bitwiseAnd(GExpr operand) {
/* 111 */     return lift(Expressions.i2s(Expressions.bitwiseAnd(jexpr(), jexpr(operand))));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ShortExpr bitwiseOr(GExpr operand) {
/* 117 */     return lift(Expressions.i2s(Expressions.bitwiseOr(jexpr(), jexpr(operand))));
/*     */   }
/*     */ 
/*     */   
/*     */   public ShortExpr bitwiseXor(GExpr operand) {
/* 122 */     return lift(Expressions.i2s(Expressions.bitwiseXor(jexpr(), jexpr(operand))));
/*     */   }
/*     */ 
/*     */   
/*     */   public ShortExpr shiftLeft(GExpr operand) {
/* 127 */     return lift(Expressions.i2s(Expressions.shiftLeft(jexpr(), bits(operand))));
/*     */   }
/*     */ 
/*     */   
/*     */   public ShortExpr shiftRight(GExpr operand) {
/* 132 */     return lift(Expressions.i2s(Expressions.shiftRight(jexpr(), bits(operand))));
/*     */   }
/*     */ 
/*     */   
/*     */   public ShortExpr rotateLeft(GExpr operand) {
/* 137 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public GimplePrimitiveType getType() {
/* 142 */     return (GimplePrimitiveType)new GimpleIntegerType(16);
/*     */   }
/*     */ 
/*     */   
/*     */   public RealExpr toRealExpr() {
/* 147 */     return toReal(32);
/*     */   }
/*     */ 
/*     */   
/*     */   public BooleanExpr toBooleanExpr() {
/* 152 */     return BooleanExpr.fromInt(jexpr());
/*     */   }
/*     */ 
/*     */   
/*     */   public IntExpr toSignedInt(int precision) {
/* 157 */     switch (precision) {
/*     */       case 8:
/* 159 */         return new SignedByteExpr(Expressions.i2b(jexpr()));
/*     */       case 16:
/* 161 */         return this;
/*     */       case 32:
/* 163 */         return new SignedIntExpr(jexpr());
/*     */     } 
/* 165 */     throw new IllegalArgumentException("precision: " + precision);
/*     */   }
/*     */ 
/*     */   
/*     */   public IntExpr toUnsignedInt(int precision) {
/* 170 */     switch (precision) {
/*     */       case 8:
/* 172 */         return new UnsignedIntExpr(Expressions.bitwiseAnd(jexpr(), 255));
/*     */       case 16:
/* 174 */         return new UnsignedSmallIntExpr(16, Expressions.i2c(jexpr()));
/*     */       case 32:
/* 176 */         return new UnsignedIntExpr(jexpr());
/*     */       case 64:
/* 178 */         return new UnsignedLongExpr(Expressions.i2l(jexpr()));
/*     */     } 
/* 180 */     throw new UnsupportedOperationException("unsigned" + precision);
/*     */   }
/*     */ 
/*     */   
/*     */   public RealExpr toReal(int precision) {
/* 185 */     return (new RealExpr(new GimpleRealType(32), Expressions.i2f(jexpr()))).toReal(precision);
/*     */   }
/*     */   
/*     */   private JExpr jexpr(GExpr operand) {
/* 189 */     return operand.toPrimitiveExpr().toSignedInt(16).jexpr();
/*     */   }
/*     */   
/*     */   private ShortExpr lift(JExpr expr) {
/* 193 */     return new ShortExpr(expr);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/type/primitive/ShortExpr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */