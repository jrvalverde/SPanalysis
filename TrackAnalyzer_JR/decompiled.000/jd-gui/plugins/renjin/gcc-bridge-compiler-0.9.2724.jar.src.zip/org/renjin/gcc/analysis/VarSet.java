/*    */ package org.renjin.gcc.analysis;
/*    */ 
/*    */ import java.util.HashSet;
/*    */ import java.util.Set;
/*    */ import org.renjin.gcc.gimple.GimpleVarDecl;
/*    */ import org.renjin.gcc.gimple.expr.GimpleExpr;
/*    */ import org.renjin.gcc.gimple.expr.GimpleVariableRef;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VarSet
/*    */ {
/* 34 */   private final Set<Long> ids = new HashSet<>();
/*    */ 
/*    */   
/*    */   public VarSet() {}
/*    */   
/*    */   public VarSet(VarSet toCopy) {
/* 40 */     this.ids.addAll(toCopy.ids);
/*    */   }
/*    */   
/*    */   public void add(GimpleVariableRef ref) {
/* 44 */     this.ids.add(Long.valueOf(ref.getId()));
/*    */   }
/*    */   
/*    */   public boolean contains(GimpleVariableRef ref) {
/* 48 */     return this.ids.contains(Long.valueOf(ref.getId()));
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 53 */     if (this == o) {
/* 54 */       return true;
/*    */     }
/* 56 */     if (o == null || getClass() != o.getClass()) {
/* 57 */       return false;
/*    */     }
/*    */     
/* 60 */     VarSet varSet = (VarSet)o;
/*    */     
/* 62 */     return this.ids.equals(varSet.ids);
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 67 */     return this.ids.hashCode();
/*    */   }
/*    */   
/*    */   public static VarSet unionAll(Iterable<VarSet> inputs) {
/* 71 */     VarSet union = new VarSet();
/* 72 */     for (VarSet input : inputs) {
/* 73 */       union.ids.addAll(input.ids);
/*    */     }
/* 75 */     return union;
/*    */   }
/*    */   
/*    */   public boolean contains(GimpleExpr expr) {
/* 79 */     if (expr instanceof GimpleVariableRef) {
/* 80 */       return contains((GimpleVariableRef)expr);
/*    */     }
/* 82 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean contains(GimpleVarDecl varDecl) {
/* 87 */     return this.ids.contains(Long.valueOf(varDecl.getId()));
/*    */   }
/*    */   
/*    */   public boolean isEmpty() {
/* 91 */     return this.ids.isEmpty();
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 96 */     return this.ids.toString();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/analysis/VarSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */