/*     */ package org.renjin.gcc.analysis;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.renjin.gcc.gimple.GimpleBasicBlock;
/*     */ import org.renjin.gcc.gimple.GimpleCompilationUnit;
/*     */ import org.renjin.gcc.gimple.GimpleFunction;
/*     */ import org.renjin.gcc.gimple.expr.GimpleAddressOf;
/*     */ import org.renjin.gcc.gimple.expr.GimpleExpr;
/*     */ import org.renjin.gcc.gimple.expr.GimpleFunctionRef;
/*     */ import org.renjin.gcc.gimple.statement.GimpleCall;
/*     */ import org.renjin.gcc.gimple.statement.GimpleStatement;
/*     */ import org.renjin.repackaged.guava.collect.Lists;
/*     */ import org.renjin.repackaged.guava.collect.Maps;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CallGraph
/*     */ {
/*     */   public class FunctionNode
/*     */   {
/*     */     private final GimpleCompilationUnit unit;
/*     */     private final GimpleFunction function;
/*  44 */     private final List<CallGraph.CallSite> callSites = Lists.newArrayList();
/*     */     
/*     */     public FunctionNode(GimpleCompilationUnit unit, GimpleFunction function) {
/*  47 */       this.unit = unit;
/*  48 */       this.function = function;
/*     */     }
/*     */     
/*     */     public GimpleFunction getFunction() {
/*  52 */       return this.function;
/*     */     }
/*     */     
/*     */     public List<CallGraph.CallSite> getCallSites() {
/*  56 */       return this.callSites;
/*     */     }
/*     */   }
/*     */   
/*     */   public class CallSite {
/*     */     private final CallGraph.FunctionNode callingFunction;
/*     */     private final GimpleBasicBlock basicBlock;
/*     */     private final GimpleCall statement;
/*     */     
/*     */     public CallSite(CallGraph.FunctionNode callingFunction, GimpleBasicBlock basicBlock, GimpleCall statement) {
/*  66 */       this.callingFunction = callingFunction;
/*  67 */       this.basicBlock = basicBlock;
/*  68 */       this.statement = statement;
/*     */     }
/*     */     
/*     */     public GimpleCall getStatement() {
/*  72 */       return this.statement;
/*     */     }
/*     */     
/*     */     public CallGraph.FunctionNode getCallingFunction() {
/*  76 */       return this.callingFunction;
/*     */     }
/*     */     
/*     */     public void insertBefore(GimpleStatement newStatement) {
/*  80 */       int callIndex = this.basicBlock.getStatements().indexOf(this.statement);
/*  81 */       this.basicBlock.getStatements().add(callIndex, newStatement);
/*     */     }
/*     */   }
/*     */   
/*  85 */   private List<FunctionNode> functionNodes = Lists.newArrayList();
/*  86 */   private List<CallSite> callSites = Lists.newArrayList();
/*     */ 
/*     */ 
/*     */   
/*     */   public CallGraph(Collection<GimpleCompilationUnit> units) {
/*  91 */     Map<String, FunctionNode> globalScope = Maps.newHashMap();
/*  92 */     Map<GimpleCompilationUnit, Map<String, FunctionNode>> unitScopes = Maps.newHashMap();
/*     */ 
/*     */ 
/*     */     
/*  96 */     for (GimpleCompilationUnit unit : units) {
/*     */       
/*  98 */       Map<String, FunctionNode> unitScope = Maps.newHashMap();
/*     */       
/* 100 */       for (GimpleFunction function : unit.getFunctions()) {
/* 101 */         FunctionNode node = new FunctionNode(unit, function);
/* 102 */         unitScope.put(function.getName(), node);
/* 103 */         if (function.isPublic()) {
/* 104 */           globalScope.put(function.getName(), node);
/*     */         }
/* 106 */         this.functionNodes.add(node);
/*     */       } 
/*     */       
/* 109 */       unitScopes.put(unit, unitScope);
/*     */     } 
/*     */ 
/*     */     
/* 113 */     for (FunctionNode callingNode : this.functionNodes) {
/* 114 */       Map<String, FunctionNode> unitScope = unitScopes.get(callingNode.unit);
/*     */       
/* 116 */       for (GimpleBasicBlock basicBlock : callingNode.getFunction().getBasicBlocks()) {
/* 117 */         for (GimpleStatement statement : basicBlock.getStatements()) {
/* 118 */           if (statement instanceof GimpleCall) {
/* 119 */             CallSite callSite = new CallSite(callingNode, basicBlock, (GimpleCall)statement);
/* 120 */             FunctionNode functionNode = findFunction((GimpleCall)statement, unitScope, globalScope);
/* 121 */             if (functionNode != null) {
/* 122 */               functionNode.callSites.add(callSite);
/*     */             }
/* 124 */             this.callSites.add(callSite);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public List<FunctionNode> getFunctionNodes() {
/* 132 */     return this.functionNodes;
/*     */   }
/*     */   
/*     */   public List<CallSite> getCallSites() {
/* 136 */     return this.callSites;
/*     */   }
/*     */   
/*     */   private FunctionNode findFunction(GimpleCall statement, Map<String, FunctionNode> unitScope, Map<String, FunctionNode> globalScope) {
/* 140 */     GimpleExpr functionExpr = statement.getFunction();
/* 141 */     if (functionExpr instanceof GimpleAddressOf) {
/* 142 */       GimpleAddressOf functionPtr = (GimpleAddressOf)functionExpr;
/* 143 */       if (functionPtr.getValue() instanceof GimpleFunctionRef) {
/* 144 */         GimpleFunctionRef ref = (GimpleFunctionRef)functionPtr.getValue();
/* 145 */         FunctionNode node = unitScope.get(ref.getName());
/* 146 */         if (node == null) {
/* 147 */           return globalScope.get(ref.getName());
/*     */         }
/* 149 */         return node;
/*     */       } 
/*     */     } 
/* 152 */     return null;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/analysis/CallGraph.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */