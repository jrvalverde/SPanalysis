/*    */ package org.renjin.gcc;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import javax.annotation.Nonnull;
/*    */ import org.renjin.gcc.codegen.CodeGenerationContext;
/*    */ import org.renjin.gcc.codegen.FunctionGenerator;
/*    */ import org.renjin.gcc.codegen.GlobalVarTransformer;
/*    */ import org.renjin.repackaged.asm.MethodVisitor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class GimpleCompilerPlugin
/*    */ {
/*    */   @Nonnull
/*    */   public List<GlobalVarTransformer> createGlobalVarTransformers() {
/* 39 */     return Collections.emptyList();
/*    */   }
/*    */   
/*    */   public void writeClasses(CodeGenerationContext generationContext) throws IOException {}
/*    */   
/*    */   public void writeTrampolinePrelude(MethodVisitor mv, FunctionGenerator functionGenerator) {}
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/GimpleCompilerPlugin.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */