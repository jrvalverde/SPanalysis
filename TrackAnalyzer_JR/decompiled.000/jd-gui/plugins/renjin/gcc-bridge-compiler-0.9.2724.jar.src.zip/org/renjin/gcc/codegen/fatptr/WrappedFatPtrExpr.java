/*     */ package org.renjin.gcc.codegen.fatptr;
/*     */ 
/*     */ import javax.annotation.Nonnull;
/*     */ import org.renjin.gcc.codegen.MethodGenerator;
/*     */ import org.renjin.gcc.codegen.array.FatArrayExpr;
/*     */ import org.renjin.gcc.codegen.condition.ConditionGenerator;
/*     */ import org.renjin.gcc.codegen.expr.GExpr;
/*     */ import org.renjin.gcc.codegen.expr.JExpr;
/*     */ import org.renjin.gcc.codegen.expr.JLValue;
/*     */ import org.renjin.gcc.codegen.expr.NotAddressableException;
/*     */ import org.renjin.gcc.codegen.expr.PtrExpr;
/*     */ import org.renjin.gcc.codegen.type.NumericExpr;
/*     */ import org.renjin.gcc.codegen.type.UnsupportedCastException;
/*     */ import org.renjin.gcc.codegen.type.fun.FunPtrExpr;
/*     */ import org.renjin.gcc.codegen.type.primitive.PrimitiveExpr;
/*     */ import org.renjin.gcc.codegen.type.record.ProvidedPtrExpr;
/*     */ import org.renjin.gcc.codegen.type.voidt.VoidPtrExpr;
/*     */ import org.renjin.gcc.codegen.vptr.VArrayExpr;
/*     */ import org.renjin.gcc.codegen.vptr.VPtrExpr;
/*     */ import org.renjin.gcc.codegen.vptr.VPtrRecordExpr;
/*     */ import org.renjin.gcc.gimple.GimpleOp;
/*     */ import org.renjin.gcc.gimple.type.GimpleArrayType;
/*     */ import org.renjin.gcc.gimple.type.GimpleRecordType;
/*     */ import org.renjin.gcc.gimple.type.GimpleType;
/*     */ import org.renjin.gcc.runtime.ObjectPtr;
/*     */ import org.renjin.repackaged.asm.Label;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WrappedFatPtrExpr
/*     */   implements FatPtr
/*     */ {
/*     */   private ValueFunction valueFunction;
/*     */   private JLValue ref;
/*     */   
/*     */   public WrappedFatPtrExpr(ValueFunction valueFunction, JLValue paramExpr) {
/*  53 */     this.valueFunction = valueFunction;
/*  54 */     this.ref = paramExpr;
/*     */   }
/*     */ 
/*     */   
/*     */   public JExpr getArray() {
/*  59 */     return Wrappers.arrayField((JExpr)this.ref);
/*     */   }
/*     */   
/*     */   public JExpr getOffset() {
/*  63 */     return Wrappers.offsetField((JExpr)this.ref);
/*     */   }
/*     */ 
/*     */   
/*     */   public Type getValueType() {
/*  68 */     return this.valueFunction.getValueType();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isAddressable() {
/*  73 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public JExpr wrap() {
/*  78 */     return (JExpr)this.ref;
/*     */   }
/*     */ 
/*     */   
/*     */   public FatPtrPair toPair(MethodGenerator mv) {
/*  83 */     return Wrappers.toPair(mv, this.valueFunction, (JExpr)this.ref);
/*     */   }
/*     */ 
/*     */   
/*     */   public void store(MethodGenerator mv, GExpr rhs) {
/*  88 */     if (rhs instanceof FatPtr) {
/*  89 */       this.ref.store(mv, ((FatPtr)rhs).wrap());
/*     */     } else {
/*     */       
/*  92 */       throw new UnsupportedOperationException("TODO: rhs = " + rhs.getClass().getName());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public PtrExpr addressOf() {
/*  98 */     throw new NotAddressableException();
/*     */   }
/*     */ 
/*     */   
/*     */   public FunPtrExpr toFunPtr() throws UnsupportedCastException {
/* 103 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public FatArrayExpr toArrayExpr() throws UnsupportedCastException {
/* 108 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public PrimitiveExpr toPrimitiveExpr() throws UnsupportedCastException {
/* 113 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public VoidPtrExpr toVoidPtrExpr() throws UnsupportedCastException {
/* 118 */     return new VoidPtrExpr((JExpr)this.ref);
/*     */   }
/*     */ 
/*     */   
/*     */   public VPtrExpr toVPtrExpr() {
/* 123 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public ProvidedPtrExpr toProvidedPtrExpr(Type jvmType) {
/* 128 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public FatPtr toFatPtrExpr(ValueFunction valueFunction) {
/* 133 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public VPtrRecordExpr toVPtrRecord(GimpleRecordType recordType) {
/* 138 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public VArrayExpr toVArray(GimpleArrayType arrayType) {
/* 143 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public NumericExpr toNumericExpr() {
/* 148 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void jumpIfNull(MethodGenerator mv, Label label) {
/* 153 */     getArray().load(mv);
/* 154 */     mv.ifnull(label);
/*     */   }
/*     */ 
/*     */   
/*     */   public JExpr memoryCompare(MethodGenerator mv, PtrExpr otherPointer, JExpr n) {
/* 159 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void memorySet(MethodGenerator mv, JExpr byteValue, JExpr length) {
/* 164 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void memoryCopy(MethodGenerator mv, PtrExpr source, JExpr length, boolean buffer) {
/* 169 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public PtrExpr realloc(MethodGenerator mv, JExpr newSizeInBytes) {
/* 174 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public PtrExpr pointerPlus(MethodGenerator mv, JExpr offsetInBytes) {
/* 179 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public GExpr valueOf(GimpleType expectedType) {
/* 184 */     return this.valueFunction.dereference(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public ConditionGenerator comparePointer(MethodGenerator mv, GimpleOp op, GExpr otherPointer) {
/* 189 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */   
/*     */   public JLValue valueExpr() {
/* 193 */     return new JLValue()
/*     */       {
/*     */         @Nonnull
/*     */         public Type getType() {
/* 197 */           return WrappedFatPtrExpr.this.valueFunction.getValueType();
/*     */         }
/*     */ 
/*     */         
/*     */         public void load(@Nonnull MethodGenerator mv) {
/* 202 */           WrappedFatPtrExpr.this.ref.load(mv);
/* 203 */           if (WrappedFatPtrExpr.this.ref.getType().equals(Type.getType(ObjectPtr.class))) {
/* 204 */             mv.invokevirtual(WrappedFatPtrExpr.this.ref.getType(), "get", Type.getMethodDescriptor(Type.getType(Object.class), new Type[0]), false);
/* 205 */             mv.checkcast(WrappedFatPtrExpr.this.valueFunction.getValueType());
/*     */           } else {
/*     */             
/* 208 */             mv.invokevirtual(WrappedFatPtrExpr.this.ref.getType(), "get", Type.getMethodDescriptor(WrappedFatPtrExpr.this.valueFunction.getValueType(), new Type[0]), false);
/*     */           } 
/*     */         }
/*     */ 
/*     */         
/*     */         public void store(MethodGenerator mv, JExpr expr) {
/* 214 */           WrappedFatPtrExpr.this.ref.load(mv);
/* 215 */           expr.load(mv);
/* 216 */           if (WrappedFatPtrExpr.this.ref.getType().equals(Type.getType(ObjectPtr.class))) {
/* 217 */             mv.invokevirtual(WrappedFatPtrExpr.this.ref.getType(), "set", Type.getMethodDescriptor(Type.VOID_TYPE, new Type[] { Type.getType(Object.class) }), false);
/*     */           } else {
/* 219 */             mv.invokevirtual(WrappedFatPtrExpr.this.ref.getType(), "set", Type.getMethodDescriptor(Type.VOID_TYPE, new Type[] { WrappedFatPtrExpr.access$000(this.this$0).getValueType() }), false);
/*     */           } 
/*     */         }
/*     */       };
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/fatptr/WrappedFatPtrExpr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */