/*    */ package org.renjin.gcc.codegen.call;
/*    */ 
/*    */ import org.renjin.gcc.codegen.MethodGenerator;
/*    */ import org.renjin.gcc.codegen.expr.ExprFactory;
/*    */ import org.renjin.gcc.codegen.expr.GExpr;
/*    */ import org.renjin.gcc.codegen.expr.JExpr;
/*    */ import org.renjin.gcc.codegen.type.TypeOracle;
/*    */ import org.renjin.gcc.codegen.type.fun.FunctionRefGenerator;
/*    */ import org.renjin.gcc.gimple.expr.GimpleExpr;
/*    */ import org.renjin.gcc.gimple.statement.GimpleCall;
/*    */ import org.renjin.gcc.gimple.type.GimpleType;
/*    */ import org.renjin.gcc.runtime.MixedPtr;
/*    */ import org.renjin.repackaged.asm.Handle;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MallocCallGenerator
/*    */   implements CallGenerator, MethodHandleGenerator
/*    */ {
/*    */   private TypeOracle typeOracle;
/*    */   
/*    */   public MallocCallGenerator(TypeOracle typeOracle) {
/* 42 */     this.typeOracle = typeOracle;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void emitCall(MethodGenerator mv, ExprFactory exprFactory, GimpleCall call) {
/* 48 */     if (call.getLhs() == null) {
/*    */       return;
/*    */     }
/*    */ 
/*    */     
/* 53 */     GimpleType pointerType = call.getLhs().getType();
/*    */ 
/*    */     
/* 56 */     JExpr size = exprFactory.findPrimitiveGenerator(call.getOperands().get(0));
/*    */     
/* 58 */     GExpr mallocGenerator = this.typeOracle.forPointerType(pointerType).malloc(mv, size);
/* 59 */     GExpr lhs = exprFactory.findGenerator((GimpleExpr)call.getLhs());
/* 60 */     lhs.store(mv, mallocGenerator);
/*    */   }
/*    */ 
/*    */   
/*    */   public JExpr getMethodHandle() {
/* 65 */     return (JExpr)new FunctionRefGenerator(new Handle(6, 
/* 66 */           Type.getInternalName(MixedPtr.class), "malloc", 
/* 67 */           Type.getMethodDescriptor(Type.getType(MixedPtr.class), new Type[] { Type.INT_TYPE })));
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/call/MallocCallGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */