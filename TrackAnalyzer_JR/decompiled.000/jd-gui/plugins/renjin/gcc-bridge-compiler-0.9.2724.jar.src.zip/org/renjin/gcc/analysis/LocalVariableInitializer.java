/*     */ package org.renjin.gcc.analysis;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Optional;
/*     */ import java.util.Set;
/*     */ import org.renjin.gcc.GimpleCompiler;
/*     */ import org.renjin.gcc.gimple.GimpleCompilationUnit;
/*     */ import org.renjin.gcc.gimple.GimpleFunction;
/*     */ import org.renjin.gcc.gimple.GimpleVarDecl;
/*     */ import org.renjin.gcc.gimple.expr.GimpleAddressOf;
/*     */ import org.renjin.gcc.gimple.expr.GimpleComplexConstant;
/*     */ import org.renjin.gcc.gimple.expr.GimpleComponentRef;
/*     */ import org.renjin.gcc.gimple.expr.GimpleExpr;
/*     */ import org.renjin.gcc.gimple.expr.GimpleIntegerConstant;
/*     */ import org.renjin.gcc.gimple.expr.GimpleMemRef;
/*     */ import org.renjin.gcc.gimple.expr.GimpleRealConstant;
/*     */ import org.renjin.gcc.gimple.expr.GimpleSymbolRef;
/*     */ import org.renjin.gcc.gimple.expr.GimpleVariableRef;
/*     */ import org.renjin.gcc.gimple.statement.GimpleAssignment;
/*     */ import org.renjin.gcc.gimple.statement.GimpleCall;
/*     */ import org.renjin.gcc.gimple.statement.GimpleStatement;
/*     */ import org.renjin.gcc.gimple.type.GimpleComplexType;
/*     */ import org.renjin.gcc.gimple.type.GimpleIndirectType;
/*     */ import org.renjin.gcc.gimple.type.GimpleIntegerType;
/*     */ import org.renjin.gcc.gimple.type.GimpleRealType;
/*     */ import org.renjin.gcc.gimple.type.GimpleType;
/*     */ import org.renjin.gcc.logging.LogManager;
/*     */ import org.renjin.repackaged.guava.collect.Sets;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocalVariableInitializer
/*     */   implements FunctionBodyTransformer
/*     */ {
/*  43 */   public static final LocalVariableInitializer INSTANCE = new LocalVariableInitializer();
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean transform(LogManager logManager, GimpleCompilationUnit unit, GimpleFunction fn) {
/*  48 */     Set<Long> toInitialize = findVariablesUsedWithoutInitialization(fn);
/*     */     
/*  50 */     for (GimpleVarDecl gimpleVarDecl : fn.getVariableDeclarations()) {
/*  51 */       if (toInitialize.contains(Long.valueOf(gimpleVarDecl.getId()))) {
/*  52 */         gimpleVarDecl.setValue(defaultValue(gimpleVarDecl.getType()));
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  57 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<Long> findVariablesUsedWithoutInitialization(GimpleFunction fn) {
/*  68 */     ControlFlowGraph cfg = new ControlFlowGraph(fn);
/*  69 */     InitFlowFunction flowFunction = new InitFlowFunction(fn);
/*  70 */     DataFlowAnalysis<Set<Long>> flowAnalysis = new DataFlowAnalysis<>(cfg, flowFunction);
/*  71 */     if (GimpleCompiler.TRACE) {
/*  72 */       flowAnalysis.dump();
/*     */     }
/*     */     
/*  75 */     Set<Long> toInitialize = new HashSet<>();
/*     */     
/*  77 */     for (ControlFlowGraph.Node node : cfg.getBasicBlockNodes()) {
/*     */       
/*  79 */       Set<Long> initialized = new HashSet<>(flowAnalysis.getEntryState(node));
/*     */ 
/*     */ 
/*     */       
/*  83 */       for (GimpleStatement statement : node.getBasicBlock().getStatements()) {
/*     */ 
/*     */         
/*  86 */         for (GimpleSymbolRef symbolRef : statement.findVariableUses()) {
/*  87 */           if (!initialized.contains(Long.valueOf(symbolRef.getId()))) {
/*  88 */             toInitialize.add(Long.valueOf(symbolRef.getId()));
/*     */           }
/*     */         } 
/*     */         
/*  92 */         updateInitializedSet(statement, initialized);
/*     */       } 
/*     */     } 
/*  95 */     return toInitialize;
/*     */   }
/*     */   
/*     */   private GimpleExpr defaultValue(GimpleType type) {
/*  99 */     if (type instanceof GimpleIntegerType) {
/* 100 */       return (GimpleExpr)new GimpleIntegerConstant((GimpleIntegerType)type, 0L);
/*     */     }
/* 102 */     if (type instanceof GimpleRealType) {
/* 103 */       return (GimpleExpr)new GimpleRealConstant((GimpleRealType)type, 0.0D);
/*     */     }
/* 105 */     if (type instanceof GimpleIndirectType) {
/* 106 */       return (GimpleExpr)GimpleIntegerConstant.nullValue((GimpleIndirectType)type);
/*     */     }
/* 108 */     if (type instanceof org.renjin.gcc.gimple.type.GimpleBooleanType) {
/* 109 */       GimpleIntegerConstant defaultValue = new GimpleIntegerConstant();
/* 110 */       defaultValue.setValue(0L);
/* 111 */       defaultValue.setType(type);
/* 112 */       return (GimpleExpr)defaultValue;
/*     */     } 
/* 114 */     if (type instanceof GimpleComplexType) {
/* 115 */       GimpleComplexConstant zero = new GimpleComplexConstant();
/* 116 */       GimpleRealType partType = ((GimpleComplexType)type).getPartType();
/* 117 */       zero.setType(type);
/* 118 */       zero.setIm(new GimpleRealConstant(partType, 0.0D));
/* 119 */       zero.setReal(new GimpleRealConstant(partType, 0.0D));
/* 120 */       return (GimpleExpr)zero;
/*     */     } 
/*     */     
/* 123 */     throw new UnsupportedOperationException("Don't know how to create default value for " + type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void updateInitializedSet(GimpleStatement statement, Set<Long> initializedVariables) {
/* 134 */     Optional<Long> variableRef = Optional.empty();
/* 135 */     if (statement instanceof GimpleAssignment) {
/* 136 */       variableRef = findVariableRef((GimpleExpr)((GimpleAssignment)statement).getLHS());
/* 137 */     } else if (statement instanceof GimpleCall) {
/* 138 */       variableRef = findVariableRef((GimpleExpr)((GimpleCall)statement).getLhs());
/*     */     } 
/* 140 */     if (variableRef.isPresent()) {
/* 141 */       initializedVariables.add(variableRef.get());
/*     */     }
/*     */   }
/*     */   
/*     */   private static Optional<Long> findVariableRef(GimpleExpr lhs) {
/* 146 */     if (lhs instanceof GimpleVariableRef) {
/* 147 */       GimpleVariableRef ref = (GimpleVariableRef)lhs;
/*     */ 
/*     */       
/* 150 */       return Optional.of(Long.valueOf(ref.getId()));
/*     */     } 
/* 152 */     if (lhs instanceof GimpleMemRef)
/* 153 */       return findVariableRef(((GimpleMemRef)lhs).getPointer()); 
/* 154 */     if (lhs instanceof GimpleAddressOf)
/* 155 */       return findVariableRef(((GimpleAddressOf)lhs).getValue()); 
/* 156 */     if (lhs instanceof GimpleComponentRef) {
/* 157 */       return findVariableRef(((GimpleComponentRef)lhs).getValue());
/*     */     }
/* 159 */     return Optional.empty();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class InitFlowFunction
/*     */     implements FlowFunction<Set<Long>>
/*     */   {
/*     */     private GimpleFunction function;
/*     */ 
/*     */ 
/*     */     
/*     */     public InitFlowFunction(GimpleFunction function) {
/* 172 */       this.function = function;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Set<Long> initialState() {
/* 180 */       Set<Long> initialState = new HashSet<>();
/* 181 */       for (GimpleVarDecl decl : this.function.getVariableDeclarations()) {
/* 182 */         if (decl.getValue() != null) {
/* 183 */           initialState.add(Long.valueOf(decl.getId()));
/*     */         }
/*     */ 
/*     */         
/* 187 */         if (decl.getType() instanceof org.renjin.gcc.gimple.type.GimpleArrayType || decl
/* 188 */           .getType() instanceof org.renjin.gcc.gimple.type.GimpleRecordType)
/*     */         {
/* 190 */           initialState.add(Long.valueOf(decl.getId()));
/*     */         }
/*     */       } 
/* 193 */       return initialState;
/*     */     }
/*     */ 
/*     */     
/*     */     public Set<Long> join(List<Set<Long>> inputs) {
/*     */       Sets.SetView setView;
/* 199 */       if (inputs.isEmpty()) {
/* 200 */         return Collections.emptySet();
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 205 */       Iterator<Set<Long>> incomingIt = inputs.iterator();
/*     */       
/* 207 */       Set<Long> state = new HashSet<>(incomingIt.next());
/*     */       
/* 209 */       while (incomingIt.hasNext()) {
/* 210 */         setView = Sets.intersection(state, incomingIt.next());
/*     */       }
/* 212 */       return (Set<Long>)setView;
/*     */     }
/*     */ 
/*     */     
/*     */     public Set<Long> transfer(Set<Long> entryState, Iterable<GimpleStatement> basicBlock) {
/* 217 */       Set<Long> exitState = new HashSet<>(entryState);
/* 218 */       for (GimpleStatement ins : basicBlock) {
/* 219 */         LocalVariableInitializer.updateInitializedSet(ins, exitState);
/*     */       }
/* 221 */       return exitState;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/analysis/LocalVariableInitializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */