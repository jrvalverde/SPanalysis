/*    */ package org.renjin.gcc.gimple.statement;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import java.util.function.Predicate;
/*    */ import org.renjin.gcc.gimple.GimpleExprVisitor;
/*    */ import org.renjin.gcc.gimple.GimpleVisitor;
/*    */ import org.renjin.gcc.gimple.expr.GimpleExpr;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GimpleReturn
/*    */   extends GimpleStatement
/*    */ {
/*    */   private GimpleExpr value;
/*    */   
/*    */   public GimpleReturn() {}
/*    */   
/*    */   public GimpleReturn(GimpleExpr value) {
/* 36 */     this.value = value;
/*    */   }
/*    */   
/*    */   public void setValue(GimpleExpr value) {
/* 40 */     this.value = value;
/*    */   }
/*    */   
/*    */   public GimpleExpr getValue() {
/* 44 */     return this.value;
/*    */   }
/*    */   
/*    */   public List<GimpleExpr> getOperands() {
/* 48 */     if (this.value == null) {
/* 49 */       return Collections.emptyList();
/*    */     }
/* 51 */     return Collections.singletonList(this.value);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 57 */     return "gimple_return <" + this.value + ">";
/*    */   }
/*    */ 
/*    */   
/*    */   public void visit(GimpleVisitor visitor) {
/* 62 */     visitor.visitReturn(this);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void findUses(Predicate<? super GimpleExpr> predicate, List<GimpleExpr> results) {
/* 67 */     if (this.value != null) {
/* 68 */       this.value.findOrDescend(predicate, results);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public void replaceAll(Predicate<? super GimpleExpr> predicate, GimpleExpr newExpr) {
/* 74 */     if (predicate.test(this.value)) {
/* 75 */       this.value = newExpr;
/*    */     } else {
/* 77 */       this.value.replaceAll(predicate, newExpr);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void accept(GimpleExprVisitor visitor) {
/* 83 */     if (this.value != null)
/* 84 */       this.value.accept(visitor); 
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/gimple/statement/GimpleReturn.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */