/*     */ package org.renjin.gcc.codegen.fatptr;
/*     */ 
/*     */ import javax.annotation.Nonnull;
/*     */ import javax.annotation.Nullable;
/*     */ import org.renjin.gcc.InternalCompilerException;
/*     */ import org.renjin.gcc.codegen.MethodGenerator;
/*     */ import org.renjin.gcc.codegen.array.FatArrayExpr;
/*     */ import org.renjin.gcc.codegen.condition.ConditionGenerator;
/*     */ import org.renjin.gcc.codegen.expr.ConstantValue;
/*     */ import org.renjin.gcc.codegen.expr.Expressions;
/*     */ import org.renjin.gcc.codegen.expr.GExpr;
/*     */ import org.renjin.gcc.codegen.expr.JExpr;
/*     */ import org.renjin.gcc.codegen.expr.JLValue;
/*     */ import org.renjin.gcc.codegen.expr.PtrExpr;
/*     */ import org.renjin.gcc.codegen.type.NumericExpr;
/*     */ import org.renjin.gcc.codegen.type.UnsupportedCastException;
/*     */ import org.renjin.gcc.codegen.type.fun.FunPtrExpr;
/*     */ import org.renjin.gcc.codegen.type.primitive.PrimitiveExpr;
/*     */ import org.renjin.gcc.codegen.type.primitive.UnsignedIntExpr;
/*     */ import org.renjin.gcc.codegen.type.record.ProvidedPtrExpr;
/*     */ import org.renjin.gcc.codegen.type.voidt.VoidPtrExpr;
/*     */ import org.renjin.gcc.codegen.var.LocalVarAllocator;
/*     */ import org.renjin.gcc.codegen.vptr.VArrayExpr;
/*     */ import org.renjin.gcc.codegen.vptr.VPtrExpr;
/*     */ import org.renjin.gcc.codegen.vptr.VPtrRecordExpr;
/*     */ import org.renjin.gcc.gimple.GimpleOp;
/*     */ import org.renjin.gcc.gimple.type.GimpleArrayType;
/*     */ import org.renjin.gcc.gimple.type.GimpleRecordType;
/*     */ import org.renjin.gcc.gimple.type.GimpleType;
/*     */ import org.renjin.gcc.runtime.ObjectPtr;
/*     */ import org.renjin.repackaged.asm.Label;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ import org.renjin.repackaged.guava.base.Preconditions;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FatPtrPair
/*     */   implements FatPtr, PtrExpr
/*     */ {
/*     */   private ValueFunction valueFunction;
/*     */   private JExpr array;
/*     */   private JExpr offset;
/*     */   private PtrExpr address;
/*     */   
/*     */   public FatPtrPair(ValueFunction valueFunction, @Nullable PtrExpr address, @Nonnull JExpr array, @Nonnull JExpr offset) {
/*  60 */     this.valueFunction = valueFunction;
/*  61 */     Preconditions.checkNotNull(array, "array");
/*  62 */     Preconditions.checkNotNull(offset, "offset");
/*     */     
/*  64 */     this.address = address;
/*  65 */     this.array = array;
/*  66 */     this.offset = offset;
/*     */   }
/*     */   
/*     */   public FatPtrPair(ValueFunction valueFunction, @Nonnull JExpr array, @Nonnull JExpr offset) {
/*  70 */     this(valueFunction, null, array, offset);
/*     */   }
/*     */   
/*     */   public FatPtrPair(ValueFunction valueFunction, JExpr array) {
/*  74 */     this(valueFunction, array, Expressions.zero());
/*     */   }
/*     */   
/*     */   @Nonnull
/*     */   public JExpr getArray() {
/*  79 */     return this.array;
/*     */   }
/*     */   
/*     */   @Nonnull
/*     */   public JExpr getOffset() {
/*  84 */     return this.offset;
/*     */   }
/*     */ 
/*     */   
/*     */   public Type getValueType() {
/*  89 */     String arrayDescriptor = this.array.getType().getDescriptor();
/*  90 */     Preconditions.checkState(arrayDescriptor.startsWith("["));
/*  91 */     return Type.getType(arrayDescriptor.substring(1));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void store(MethodGenerator mv, GExpr rhsExpr) {
/*  98 */     if (rhsExpr instanceof VoidPtrExpr) {
/*  99 */       VoidPtrExpr ptr = (VoidPtrExpr)rhsExpr;
/* 100 */       Type wrapperType = Wrappers.wrapperType(getValueType());
/*     */ 
/*     */ 
/*     */       
/* 104 */       ptr.jexpr().load(mv);
/* 105 */       mv.invokestatic(wrapperType, "cast", Type.getMethodDescriptor(wrapperType, new Type[] { Type.getType(Object.class) }));
/*     */       
/* 107 */       LocalVarAllocator.LocalVar tempVar = mv.getLocalVarAllocator().reserve(wrapperType);
/* 108 */       tempVar.store(mv);
/*     */       
/* 110 */       JExpr arrayField = Wrappers.arrayField((JExpr)tempVar, getValueType());
/* 111 */       JExpr offsetField = Wrappers.offsetField((JExpr)tempVar);
/*     */       
/* 113 */       store(mv, arrayField, offsetField);
/*     */     }
/* 115 */     else if (rhsExpr instanceof WrappedFatPtrExpr) {
/*     */       
/* 117 */       Label nullLabel = new Label();
/* 118 */       Label exitLabel = new Label();
/*     */ 
/*     */       
/* 121 */       ((WrappedFatPtrExpr)rhsExpr).wrap().load(mv);
/* 122 */       mv.ifnull(nullLabel);
/*     */ 
/*     */       
/* 125 */       FatPtrPair pair = ((WrappedFatPtrExpr)rhsExpr).toPair(mv);
/* 126 */       store(mv, pair.getArray(), pair.getOffset());
/* 127 */       mv.goTo(exitLabel);
/*     */ 
/*     */       
/* 130 */       mv.mark(nullLabel);
/* 131 */       store(mv, Expressions.nullRef(this.array.getType()), Expressions.constantInt(0));
/*     */ 
/*     */       
/* 134 */       mv.mark(exitLabel);
/*     */     
/*     */     }
/* 137 */     else if (rhsExpr instanceof FatPtr) {
/* 138 */       FatPtrPair pair = ((FatPtr)rhsExpr).toPair(mv);
/* 139 */       store(mv, pair.getArray(), pair.getOffset());
/*     */     } else {
/*     */       
/* 142 */       throw new UnsupportedOperationException("rhs: " + rhsExpr);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public GExpr valueOf(GimpleType expectedType) {
/* 148 */     return this.valueFunction.dereference(this.array, this.offset);
/*     */   }
/*     */ 
/*     */   
/*     */   public ConditionGenerator comparePointer(MethodGenerator mv, GimpleOp op, GExpr otherPointer) {
/* 153 */     if (otherPointer instanceof VPtrExpr) {
/* 154 */       return toVPtrExpr().comparePointer(mv, op, otherPointer);
/*     */     }
/*     */     
/* 157 */     return new FatPtrConditionGenerator(op, this, otherPointer.toFatPtrExpr(this.valueFunction).toPair(mv));
/*     */   }
/*     */   
/*     */   private void store(MethodGenerator mv, JExpr arrayRhs, JExpr offsetRhs) {
/* 161 */     if (!(this.array instanceof JLValue)) {
/* 162 */       throw new InternalCompilerException(this.array + " is not an LValue");
/*     */     }
/* 164 */     ((JLValue)this.array).store(mv, Expressions.cast(arrayRhs, this.array.getType()));
/*     */ 
/*     */ 
/*     */     
/* 168 */     if (this.offset instanceof ConstantValue && this.offset
/* 169 */       .equals(offsetRhs)) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 175 */     if (!(this.offset instanceof JLValue)) {
/* 176 */       throw new InternalCompilerException(this.offset + " offset is not an Lvalue");
/*     */     }
/* 178 */     ((JLValue)this.offset).store(mv, offsetRhs);
/*     */   }
/*     */ 
/*     */   
/*     */   public VPtrExpr toVPtrExpr() {
/* 183 */     return this.valueFunction.toVPtr(this.array, this.offset);
/*     */   }
/*     */ 
/*     */   
/*     */   public ProvidedPtrExpr toProvidedPtrExpr(Type jvmType) {
/* 188 */     throw new UnsupportedOperationException("Unsupported cast");
/*     */   }
/*     */ 
/*     */   
/*     */   public FatPtr toFatPtrExpr(ValueFunction valueFunction) {
/* 193 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public VPtrRecordExpr toVPtrRecord(GimpleRecordType recordType) {
/* 198 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public VArrayExpr toVArray(GimpleArrayType arrayType) {
/* 203 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public NumericExpr toNumericExpr() {
/* 208 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */   
/*     */   public JExpr wrap() {
/* 212 */     final Type wrapperType = Wrappers.wrapperType(getValueType());
/*     */     
/* 214 */     return new JExpr()
/*     */       {
/*     */         @Nonnull
/*     */         public Type getType() {
/* 218 */           return wrapperType;
/*     */         }
/*     */ 
/*     */         
/*     */         public void load(@Nonnull MethodGenerator mv) {
/* 223 */           mv.anew(wrapperType);
/* 224 */           mv.dup();
/*     */           
/* 226 */           if (wrapperType.equals(Type.getType(ObjectPtr.class))) {
/* 227 */             if (FatPtrPair.this.valueFunction.getValueType().getSort() == 10) {
/* 228 */               mv.aconst(FatPtrPair.this.valueFunction.getValueType());
/*     */             } else {
/* 230 */               mv.aconst(null);
/*     */             } 
/* 232 */             FatPtrPair.this.array.load(mv);
/* 233 */             FatPtrPair.this.offset.load(mv);
/* 234 */             mv.invokeconstructor(wrapperType, new Type[] {
/* 235 */                   Type.getType(Class.class), 
/* 236 */                   Wrappers.fieldArrayType(this.val$wrapperType), 
/* 237 */                   FatPtrPair.access$200(this.this$0).getType()
/*     */                 });
/*     */           } else {
/*     */             
/* 241 */             FatPtrPair.this.array.load(mv);
/* 242 */             FatPtrPair.this.offset.load(mv);
/* 243 */             mv.invokeconstructor(wrapperType, new Type[] { Wrappers.fieldArrayType(this.val$wrapperType), FatPtrPair.access$200(this.this$0).getType() });
/*     */           } 
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */   
/*     */   public FatPtrPair toPair(MethodGenerator mv) {
/* 251 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isAddressable() {
/* 256 */     return (this.address != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public PtrExpr addressOf() {
/* 261 */     if (this.address == null) {
/* 262 */       throw new UnsupportedOperationException("Not addressable");
/*     */     }
/* 264 */     return this.address;
/*     */   }
/*     */ 
/*     */   
/*     */   public FunPtrExpr toFunPtr() throws UnsupportedCastException {
/* 269 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public FatArrayExpr toArrayExpr() throws UnsupportedCastException {
/* 274 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PrimitiveExpr toPrimitiveExpr() throws UnsupportedCastException {
/* 285 */     JExpr offsetInBytes = Expressions.product(this.offset, this.valueFunction.getArrayElementBytes());
/*     */     
/* 287 */     UnsignedIntExpr unsignedIntExpr = new UnsignedIntExpr(offsetInBytes);
/*     */     
/* 289 */     return unsignedIntExpr.toPrimitiveExpr();
/*     */   }
/*     */ 
/*     */   
/*     */   public VoidPtrExpr toVoidPtrExpr() throws UnsupportedCastException {
/* 294 */     return new VoidPtrExpr(wrap());
/*     */   }
/*     */   
/*     */   public JExpr at(int i) {
/* 298 */     return (JExpr)Expressions.elementAt(this.array, Expressions.sum(this.offset, i));
/*     */   }
/*     */ 
/*     */   
/*     */   public void jumpIfNull(MethodGenerator mv, Label label) {
/* 303 */     this.array.load(mv);
/* 304 */     mv.ifnull(label);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JExpr memoryCompare(MethodGenerator mv, PtrExpr otherPointer, JExpr n) {
/* 310 */     if (otherPointer instanceof VPtrExpr) {
/* 311 */       return toVPtrExpr().memoryCompare(mv, otherPointer, n);
/*     */     }
/*     */     
/* 314 */     return new FatPtrMemCmp(this, otherPointer.toFatPtrExpr(this.valueFunction).toPair(mv), n);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void memorySet(MethodGenerator mv, JExpr byteValue, JExpr length) {
/* 320 */     this.valueFunction.memorySet(mv, this.array, this.offset, byteValue, length);
/*     */   }
/*     */ 
/*     */   
/*     */   public PtrExpr realloc(MethodGenerator mv, JExpr newSizeInBytes) {
/* 325 */     JExpr sizeInElements = Expressions.divide(newSizeInBytes, this.valueFunction.getArrayElementBytes());
/* 326 */     JExpr array = new FatPtrRealloc(this, sizeInElements);
/* 327 */     JExpr offset = Expressions.zero();
/*     */     
/* 329 */     return new FatPtrPair(this.valueFunction, array, offset);
/*     */   }
/*     */ 
/*     */   
/*     */   public PtrExpr pointerPlus(MethodGenerator mv, JExpr offsetInBytes) {
/* 334 */     JExpr offsetInArrayElements = Expressions.divide(offsetInBytes, this.valueFunction.getArrayElementBytes());
/* 335 */     JExpr newOffset = Expressions.sum(this.offset, offsetInArrayElements);
/* 336 */     return new FatPtrPair(this.valueFunction, this.array, newOffset);
/*     */   }
/*     */   
/*     */   public static FatPtr nullPtr(ValueFunction valueFunction) {
/* 340 */     Type arrayType = Wrappers.valueArrayType(valueFunction.getValueType());
/* 341 */     JExpr nullArray = Expressions.nullRef(arrayType);
/* 342 */     return new FatPtrPair(valueFunction, nullArray);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void memoryCopy(MethodGenerator mv, PtrExpr source, JExpr lengthBytes, boolean buffer) {
/* 354 */     if (source instanceof VPtrExpr) {
/* 355 */       toVPtrExpr().memoryCopy(mv, source, lengthBytes, buffer);
/*     */     } else {
/*     */       
/* 358 */       FatPtrPair sourcePair = source.toFatPtrExpr(this.valueFunction).toPair(mv);
/*     */ 
/*     */       
/* 361 */       JExpr valueCount = computeElementsToCopy(lengthBytes);
/*     */       
/* 363 */       this.valueFunction.memoryCopy(mv, this.array, this.offset, sourcePair
/*     */           
/* 365 */           .getArray(), sourcePair.getOffset(), valueCount);
/*     */     } 
/*     */   }
/*     */   
/*     */   private JExpr computeElementsToCopy(JExpr lengthBytes) {
/* 370 */     if (lengthBytes instanceof ConstantValue) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 382 */       int numBytes = ((ConstantValue)lengthBytes).getIntValue();
/* 383 */       if (numBytes < this.valueFunction.getArrayElementBytes()) {
/* 384 */         return Expressions.constantInt(1);
/*     */       }
/*     */     } 
/*     */     
/* 388 */     return Expressions.divide(lengthBytes, this.valueFunction.getArrayElementBytes());
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/fatptr/FatPtrPair.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */