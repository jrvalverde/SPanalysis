/*    */ package org.renjin.gcc.codegen;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.renjin.gcc.ProvidedGlobalVar;
/*    */ import org.renjin.gcc.codegen.expr.GExpr;
/*    */ import org.renjin.gcc.codegen.type.TypeOracle;
/*    */ import org.renjin.gcc.gimple.GimpleCompilationUnit;
/*    */ import org.renjin.gcc.gimple.GimpleVarDecl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ProvidedVarTransformer
/*    */   implements GlobalVarTransformer
/*    */ {
/*    */   private final TypeOracle typeOracle;
/*    */   private final Map<String, ProvidedGlobalVar> providedVariables;
/*    */   
/*    */   public ProvidedVarTransformer(TypeOracle typeOracle, Map<String, ProvidedGlobalVar> providedVariables) {
/* 35 */     this.typeOracle = typeOracle;
/* 36 */     this.providedVariables = providedVariables;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean accept(GimpleVarDecl decl) {
/* 41 */     return (decl.isPublic() && this.providedVariables.containsKey(decl.getName()));
/*    */   }
/*    */ 
/*    */   
/*    */   public GExpr generator(TypeOracle typeOracle, GimpleCompilationUnit unit, GimpleVarDecl decl) {
/* 46 */     return ((ProvidedGlobalVar)this.providedVariables.get(decl.getName())).createExpr(decl, this.typeOracle);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/ProvidedVarTransformer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */