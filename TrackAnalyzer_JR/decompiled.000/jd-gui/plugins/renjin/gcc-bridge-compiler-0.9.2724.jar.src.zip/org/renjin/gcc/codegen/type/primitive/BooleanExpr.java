/*     */ package org.renjin.gcc.codegen.type.primitive;
/*     */ 
/*     */ import javax.annotation.Nullable;
/*     */ import org.renjin.gcc.codegen.MethodGenerator;
/*     */ import org.renjin.gcc.codegen.condition.ConditionGenerator;
/*     */ import org.renjin.gcc.codegen.condition.IntegerComparison;
/*     */ import org.renjin.gcc.codegen.expr.Expressions;
/*     */ import org.renjin.gcc.codegen.expr.GExpr;
/*     */ import org.renjin.gcc.codegen.expr.JExpr;
/*     */ import org.renjin.gcc.codegen.expr.JLValue;
/*     */ import org.renjin.gcc.codegen.expr.PtrExpr;
/*     */ import org.renjin.gcc.codegen.type.NumericExpr;
/*     */ import org.renjin.gcc.gimple.GimpleOp;
/*     */ import org.renjin.gcc.gimple.type.GimpleBooleanType;
/*     */ import org.renjin.gcc.gimple.type.GimplePrimitiveType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BooleanExpr
/*     */   extends AbstractPrimitiveExpr
/*     */   implements IntExpr
/*     */ {
/*     */   public BooleanExpr(JExpr expr, @Nullable PtrExpr address) {
/*  40 */     super(expr, address);
/*     */   }
/*     */   
/*     */   public BooleanExpr(JExpr jexpr) {
/*  44 */     this(jexpr, null);
/*     */   }
/*     */   
/*     */   public static BooleanExpr fromInt(JExpr expr) {
/*  48 */     return new BooleanExpr(Expressions.bitwiseAnd(expr, 1));
/*     */   }
/*     */ 
/*     */   
/*     */   public GimplePrimitiveType getType() {
/*  53 */     return (GimplePrimitiveType)new GimpleBooleanType();
/*     */   }
/*     */ 
/*     */   
/*     */   public IntExpr toIntExpr() {
/*  58 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public RealExpr toRealExpr() {
/*  63 */     return toNumericExpr().toRealExpr();
/*     */   }
/*     */ 
/*     */   
/*     */   public BooleanExpr toBooleanExpr() {
/*  68 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public GExpr bitwiseXor(GExpr operand) {
/*  73 */     return lift(Expressions.bitwiseXor(jexpr(), jexpr(operand)));
/*     */   }
/*     */ 
/*     */   
/*     */   public GExpr bitwiseNot() {
/*  78 */     return lift(Expressions.bitwiseXor(jexpr(), 1));
/*     */   }
/*     */ 
/*     */   
/*     */   public GExpr bitwiseAnd(GExpr operand) {
/*  83 */     return lift(Expressions.bitwiseAnd(jexpr(), jexpr(operand)));
/*     */   }
/*     */ 
/*     */   
/*     */   public GExpr bitwiseOr(GExpr operand) {
/*  88 */     return lift(Expressions.bitwiseOr(jexpr(), jexpr(operand)));
/*     */   }
/*     */ 
/*     */   
/*     */   public GExpr shiftLeft(GExpr operand) {
/*  93 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public GExpr shiftRight(GExpr operand) {
/*  98 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public GExpr rotateLeft(GExpr operand) {
/* 103 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public UnsignedSmallIntExpr toUnsignedByteExpr() {
/* 107 */     return new UnsignedSmallIntExpr(8, jexpr());
/*     */   }
/*     */ 
/*     */   
/*     */   public IntExpr toSignedInt(int precision) {
/* 112 */     return toUnsignedByteExpr().toSignedInt(precision);
/*     */   }
/*     */ 
/*     */   
/*     */   public IntExpr toUnsignedInt(int precision) {
/* 117 */     return toUnsignedByteExpr().toSignedInt(precision);
/*     */   }
/*     */ 
/*     */   
/*     */   public RealExpr toReal(int precision) {
/* 122 */     return toUnsignedByteExpr().toReal(precision);
/*     */   }
/*     */ 
/*     */   
/*     */   public ConditionGenerator compareTo(GimpleOp op, GExpr operand) {
/* 127 */     return (ConditionGenerator)new IntegerComparison(op, jexpr(), jexpr(operand));
/*     */   }
/*     */   
/*     */   private JExpr jexpr(GExpr operand) {
/* 131 */     return operand.toPrimitiveExpr().toBooleanExpr().jexpr();
/*     */   }
/*     */ 
/*     */   
/*     */   public void store(MethodGenerator mv, GExpr rhs) {
/* 136 */     ((JLValue)jexpr()).store(mv, jexpr(rhs));
/*     */   }
/*     */ 
/*     */   
/*     */   public NumericExpr toNumericExpr() {
/* 141 */     return new SignedIntExpr(jexpr());
/*     */   }
/*     */ 
/*     */   
/*     */   private BooleanExpr lift(JExpr jExpr) {
/* 146 */     return new BooleanExpr(jExpr);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/type/primitive/BooleanExpr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */