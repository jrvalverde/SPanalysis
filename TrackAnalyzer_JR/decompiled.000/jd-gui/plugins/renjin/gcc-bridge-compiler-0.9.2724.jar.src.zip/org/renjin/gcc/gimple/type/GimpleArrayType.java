/*     */ package org.renjin.gcc.gimple.type;
/*     */ 
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GimpleArrayType
/*     */   extends AbstractGimpleType
/*     */ {
/*     */   private GimpleType componentType;
/*     */   private int lbound;
/*     */   private Integer ubound;
/*     */   
/*     */   public GimpleArrayType() {}
/*     */   
/*     */   public GimpleArrayType(GimpleType componentType) {
/*  32 */     this.componentType = componentType;
/*     */   }
/*     */   
/*     */   public GimpleArrayType(GimpleType componentType, int ubound) {
/*  36 */     this.componentType = componentType;
/*  37 */     this.lbound = 0;
/*  38 */     this.ubound = Integer.valueOf(ubound);
/*  39 */     setSize(Math.multiplyExact(componentType.getSize(), ubound));
/*     */   }
/*     */ 
/*     */   
/*     */   public GimpleType getComponentType() {
/*  44 */     return this.componentType;
/*     */   }
/*     */   
/*     */   public void setComponentType(GimpleType componentType) {
/*  48 */     this.componentType = componentType;
/*     */   }
/*     */   
/*     */   public int getLbound() {
/*  52 */     return this.lbound;
/*     */   }
/*     */   
/*     */   public void setLbound(int lbound) {
/*  56 */     this.lbound = lbound;
/*     */   }
/*     */   
/*     */   public Integer getUbound() {
/*  60 */     return this.ubound;
/*     */   }
/*     */   
/*     */   public void setUbound(Integer ubound) {
/*  64 */     this.ubound = ubound;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  69 */     StringBuilder s = new StringBuilder(this.componentType.toString());
/*  70 */     s.append("[");
/*  71 */     if (this.lbound != 0) {
/*  72 */       s.append(this.lbound).append(":");
/*     */     }
/*  74 */     if (this.ubound != null) {
/*  75 */       s.append(this.ubound);
/*     */     }
/*  77 */     s.append("]");
/*  78 */     return s.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getElementCount() {
/*  83 */     return getSize() / this.componentType.getSize();
/*     */   }
/*     */   
/*     */   public boolean isStatic() {
/*  87 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int sizeOf() {
/*  93 */     return getSize() / 8;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/*  98 */     if (this == o) {
/*  99 */       return true;
/*     */     }
/* 101 */     if (o == null || getClass() != o.getClass()) {
/* 102 */       return false;
/*     */     }
/*     */     
/* 105 */     GimpleArrayType other = (GimpleArrayType)o;
/*     */     
/* 107 */     if (this.lbound != other.lbound) {
/* 108 */       return false;
/*     */     }
/* 110 */     if (!Objects.equals(this.componentType, other.componentType)) {
/* 111 */       return false;
/*     */     }
/* 113 */     if (!Objects.equals(this.ubound, other.ubound)) {
/* 114 */       return false;
/*     */     }
/* 116 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 121 */     int result = this.componentType.hashCode();
/* 122 */     result = 31 * result + this.lbound;
/* 123 */     result = 31 * result + ((this.ubound != null) ? this.ubound.hashCode() : 0);
/* 124 */     return result;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/gimple/type/GimpleArrayType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */