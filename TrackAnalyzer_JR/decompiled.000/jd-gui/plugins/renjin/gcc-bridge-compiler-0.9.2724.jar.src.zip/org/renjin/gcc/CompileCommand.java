/*     */ package org.renjin.gcc;
/*     */ 
/*     */ import io.airlift.command.Arguments;
/*     */ import io.airlift.command.Command;
/*     */ import io.airlift.command.Option;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ import org.renjin.gcc.gimple.GimpleCompilationUnit;
/*     */ import org.renjin.repackaged.guava.collect.Lists;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Command(name = "compile", description = "Compile C/Fortran files to a JVM class file")
/*     */ public class CompileCommand
/*     */   implements Runnable
/*     */ {
/*     */   @Option(name = {"-o"}, description = "Output directory for class files", required = true)
/*     */   public File outputDirectory;
/*     */   @Option(name = {"--class-name"}, description = "The class name of the output class", required = true)
/*     */   public String className;
/*     */   @Option(name = {"--package-name"}, description = "The package name of the output class", required = true)
/*     */   public String packageName;
/*     */   @Option(name = {"--plugin-path"}, description = "Path to the gcc-bridge.so binary")
/*     */   public File pluginPath;
/*     */   @Option(name = {"-v"}, description = "Verbose mode")
/*     */   public boolean verbose;
/*     */   @Option(name = {"-I"}, description = "Add include directory for GCC")
/*  55 */   public List<String> includeDirs = Lists.newArrayList();
/*     */   
/*     */   @Option(name = {"-d"}, description = "Compile all sources in the given directory")
/*  58 */   public List<String> directories = Lists.newArrayList();
/*     */   
/*     */   @Arguments(description = "Sources files to compile")
/*  61 */   public List<String> sourceFiles = Lists.newArrayList();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run() {
/*  68 */     List<GimpleCompilationUnit> units = compileToGimple();
/*     */     
/*  70 */     if (units.isEmpty()) {
/*  71 */       System.err.println("Nothing to compile");
/*     */       
/*     */       return;
/*     */     } 
/*  75 */     GimpleCompiler compiler = new GimpleCompiler();
/*  76 */     compiler.setOutputDirectory(this.outputDirectory);
/*  77 */     compiler.setVerbose(this.verbose);
/*  78 */     compiler.setPackageName(this.packageName);
/*  79 */     compiler.setClassName(this.className);
/*     */     
/*     */     try {
/*  82 */       compiler.compile(units);
/*  83 */     } catch (Exception e) {
/*  84 */       throw new RuntimeException("Failed to translate or compile gimple", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private List<GimpleCompilationUnit> compileToGimple() {
/*  90 */     List<GimpleCompilationUnit> units = Lists.newArrayList();
/*     */     
/*     */     try {
/*  93 */       Gcc gcc = new Gcc();
/*     */       
/*  95 */       gcc.checkVersion();
/*     */       
/*  97 */       if (this.pluginPath == null) {
/*  98 */         gcc.extractPlugin();
/*     */       } else {
/* 100 */         if (!this.pluginPath.exists()) {
/* 101 */           throw new GccException("Plugin binary not found at: " + this.pluginPath.getAbsolutePath());
/*     */         }
/* 103 */         gcc.setPluginLibrary(this.pluginPath);
/*     */       } 
/*     */       
/* 106 */       for (String includeDir : this.includeDirs) {
/* 107 */         gcc.addIncludeDirectory(new File(includeDir));
/*     */       }
/*     */       
/* 110 */       for (String sourceFile : this.sourceFiles) {
/* 111 */         if (this.verbose) {
/* 112 */           System.out.println("Compiling " + sourceFile + " to gimple...");
/*     */         }
/* 114 */         units.add(gcc.compileToGimple(new File(sourceFile), new String[0]));
/*     */       } 
/*     */       
/* 117 */       for (String dirName : this.directories) {
/* 118 */         if (this.verbose) {
/* 119 */           System.out.println("Looking for sources in " + dirName);
/*     */         }
/* 121 */         File dir = new File(dirName);
/* 122 */         if (dir.exists() && dir.listFiles() != null) {
/* 123 */           for (File file : dir.listFiles()) {
/* 124 */             if (file.getName().toLowerCase().endsWith(".f") || file.getName().toLowerCase().endsWith(".f77") || file
/* 125 */               .getName().toLowerCase().endsWith(".f90") || file.getName().toLowerCase().endsWith(".f95") || file
/* 126 */               .getName().toLowerCase().endsWith(".f03") || file.getName().toLowerCase().endsWith(".for") || file
/* 127 */               .getName().endsWith(".c"))
/*     */             {
/* 129 */               if (this.verbose) {
/* 130 */                 System.out.println("Compiling " + file.getAbsolutePath() + " to gimple...");
/*     */               }
/* 132 */               units.add(gcc.compileToGimple(file, new String[0]));
/*     */             }
/*     */           
/*     */           } 
/*     */         }
/*     */       } 
/* 138 */     } catch (GccException e) {
/* 139 */       System.err.println("GCC Compilation FAILED:");
/* 140 */       System.err.println(e.getMessage());
/* 141 */       System.exit(-1);
/* 142 */     } catch (IOException e) {
/* 143 */       throw new RuntimeException(e);
/*     */     } 
/* 145 */     return units;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/CompileCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */