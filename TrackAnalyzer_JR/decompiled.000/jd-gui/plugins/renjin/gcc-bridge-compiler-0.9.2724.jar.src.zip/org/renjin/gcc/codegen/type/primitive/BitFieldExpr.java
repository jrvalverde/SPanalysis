/*     */ package org.renjin.gcc.codegen.type.primitive;
/*     */ 
/*     */ import javax.annotation.Nonnull;
/*     */ import org.renjin.gcc.codegen.MethodGenerator;
/*     */ import org.renjin.gcc.codegen.expr.Expressions;
/*     */ import org.renjin.gcc.codegen.expr.JExpr;
/*     */ import org.renjin.gcc.codegen.expr.JLValue;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ import org.renjin.repackaged.guava.base.Preconditions;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BitFieldExpr
/*     */   implements JLValue
/*     */ {
/*     */   private JLValue byteValue;
/*     */   private int offset;
/*     */   private int size;
/*     */   
/*     */   public BitFieldExpr(Type ownerClass, JExpr instance, String fieldName, int offset, int size) {
/*  38 */     assert instance.getType().equals(ownerClass);
/*  39 */     this.byteValue = Expressions.field(instance, Type.BYTE_TYPE, fieldName);
/*  40 */     this.offset = offset;
/*  41 */     this.size = size;
/*     */   }
/*     */   
/*     */   public BitFieldExpr(JLValue byteValue, int offset, int size) {
/*  45 */     this.byteValue = byteValue;
/*  46 */     this.offset = offset;
/*  47 */     this.size = size;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nonnull
/*     */   public Type getType() {
/*  53 */     return Type.BYTE_TYPE;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void load(@Nonnull MethodGenerator mv) {
/*  59 */     this.byteValue.load(mv);
/*     */ 
/*     */     
/*  62 */     if (this.offset != 0) {
/*  63 */       mv.iconst(this.offset);
/*  64 */       mv.ushr(Type.BYTE_TYPE);
/*     */     } 
/*     */ 
/*     */     
/*  68 */     mv.iconst((1 << this.size) - 1);
/*  69 */     mv.and(Type.BYTE_TYPE);
/*     */   }
/*     */ 
/*     */   
/*     */   public void store(MethodGenerator mv, final JExpr rhs) {
/*  74 */     Preconditions.checkArgument((rhs.getType().equals(Type.BYTE_TYPE) || rhs
/*  75 */         .getType().equals(Type.INT_TYPE)));
/*     */ 
/*     */     
/*  78 */     this.byteValue.store(mv, new JExpr()
/*     */         {
/*     */           @Nonnull
/*     */           public Type getType() {
/*  82 */             return Type.BYTE_TYPE;
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public void load(@Nonnull MethodGenerator mv) {
/*  97 */             BitFieldExpr.this.byteValue.load(mv);
/*     */ 
/*     */             
/* 100 */             rhs.load(mv);
/*     */ 
/*     */             
/* 103 */             mv.iconst((1 << BitFieldExpr.this.size) - 1);
/* 104 */             mv.and(Type.BYTE_TYPE);
/*     */ 
/*     */             
/* 107 */             if (BitFieldExpr.this.offset != 0) {
/* 108 */               mv.iconst(BitFieldExpr.this.offset);
/* 109 */               mv.shl(Type.BYTE_TYPE);
/*     */             } 
/*     */ 
/*     */             
/* 113 */             mv.or(Type.BYTE_TYPE);
/*     */           }
/*     */         });
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/type/primitive/BitFieldExpr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */