/*     */ package org.renjin.gcc.codegen.type.voidt;
/*     */ 
/*     */ import java.lang.invoke.MethodHandle;
/*     */ import javax.annotation.Nonnull;
/*     */ import org.renjin.gcc.codegen.MethodGenerator;
/*     */ import org.renjin.gcc.codegen.array.FatArrayExpr;
/*     */ import org.renjin.gcc.codegen.condition.ConditionGenerator;
/*     */ import org.renjin.gcc.codegen.expr.Expressions;
/*     */ import org.renjin.gcc.codegen.expr.GExpr;
/*     */ import org.renjin.gcc.codegen.expr.JExpr;
/*     */ import org.renjin.gcc.codegen.expr.JLValue;
/*     */ import org.renjin.gcc.codegen.expr.NotAddressableException;
/*     */ import org.renjin.gcc.codegen.expr.PtrExpr;
/*     */ import org.renjin.gcc.codegen.expr.RefPtrExpr;
/*     */ import org.renjin.gcc.codegen.fatptr.FatPtr;
/*     */ import org.renjin.gcc.codegen.fatptr.FatPtrPair;
/*     */ import org.renjin.gcc.codegen.fatptr.ValueFunction;
/*     */ import org.renjin.gcc.codegen.fatptr.Wrappers;
/*     */ import org.renjin.gcc.codegen.type.NumericExpr;
/*     */ import org.renjin.gcc.codegen.type.UnsupportedCastException;
/*     */ import org.renjin.gcc.codegen.type.fun.FunPtrExpr;
/*     */ import org.renjin.gcc.codegen.type.primitive.PrimitiveExpr;
/*     */ import org.renjin.gcc.codegen.type.record.ProvidedPtrExpr;
/*     */ import org.renjin.gcc.codegen.vptr.VArrayExpr;
/*     */ import org.renjin.gcc.codegen.vptr.VPtrExpr;
/*     */ import org.renjin.gcc.codegen.vptr.VPtrRecordExpr;
/*     */ import org.renjin.gcc.gimple.GimpleOp;
/*     */ import org.renjin.gcc.gimple.type.GimpleArrayType;
/*     */ import org.renjin.gcc.gimple.type.GimpleRecordType;
/*     */ import org.renjin.gcc.gimple.type.GimpleType;
/*     */ import org.renjin.gcc.runtime.Ptr;
/*     */ import org.renjin.gcc.runtime.VoidPtr;
/*     */ import org.renjin.repackaged.asm.Label;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VoidPtrExpr
/*     */   implements RefPtrExpr
/*     */ {
/*     */   private JExpr objectRef;
/*     */   private FatPtr address;
/*     */   
/*     */   public VoidPtrExpr(JExpr objectRef, FatPtr address) {
/*  56 */     this.objectRef = objectRef;
/*  57 */     this.address = address;
/*     */   }
/*     */   
/*     */   public VoidPtrExpr(JExpr objectRef) {
/*  61 */     this.objectRef = objectRef;
/*  62 */     this.address = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void store(MethodGenerator mv, GExpr rhs) {
/*  67 */     JLValue lhs = (JLValue)this.objectRef;
/*  68 */     lhs.store(mv, rhs.toVoidPtrExpr().jexpr());
/*     */   }
/*     */ 
/*     */   
/*     */   public PtrExpr addressOf() {
/*  73 */     if (this.address == null) {
/*  74 */       throw new NotAddressableException();
/*     */     }
/*  76 */     return (PtrExpr)this.address;
/*     */   }
/*     */ 
/*     */   
/*     */   public FunPtrExpr toFunPtr() {
/*  81 */     return new FunPtrExpr(Expressions.cast(this.objectRef, Type.getType(MethodHandle.class)));
/*     */   }
/*     */ 
/*     */   
/*     */   public FatArrayExpr toArrayExpr() throws UnsupportedCastException {
/*  86 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public PrimitiveExpr toPrimitiveExpr() throws UnsupportedCastException {
/*  91 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public JExpr jexpr() {
/*  96 */     return this.objectRef;
/*     */   }
/*     */ 
/*     */   
/*     */   public void jumpIfNull(MethodGenerator mv, Label label) {
/* 101 */     this.objectRef.load(mv);
/* 102 */     mv.ifnull(label);
/*     */   }
/*     */ 
/*     */   
/*     */   public JExpr memoryCompare(MethodGenerator mv, PtrExpr otherPointer, JExpr n) {
/* 107 */     return new VoidPtrMemCmp(jexpr(), otherPointer.toVoidPtrExpr().jexpr(), n);
/*     */   }
/*     */ 
/*     */   
/*     */   public void memorySet(MethodGenerator mv, JExpr byteValue, JExpr length) {
/* 112 */     this.objectRef.load(mv);
/* 113 */     byteValue.load(mv);
/* 114 */     length.load(mv);
/*     */     
/* 116 */     mv.invokestatic(VoidPtr.class, "memset", 
/* 117 */         Type.getMethodDescriptor(Type.VOID_TYPE, new Type[] {
/* 118 */             Type.getType(Object.class), Type.INT_TYPE, Type.INT_TYPE
/*     */           }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void memoryCopy(MethodGenerator mv, PtrExpr source, JExpr length, boolean buffer) {
/* 126 */     jexpr().load(mv);
/* 127 */     source.toVoidPtrExpr().jexpr().load(mv);
/* 128 */     length.load(mv);
/*     */     
/* 130 */     mv.invokestatic(VoidPtr.class, "memcpy", 
/* 131 */         Type.getMethodDescriptor(Type.VOID_TYPE, new Type[] {
/* 132 */             Type.getType(Object.class), Type.getType(Object.class), Type.INT_TYPE
/*     */           }));
/*     */   }
/*     */   
/*     */   public PtrExpr realloc(MethodGenerator mv, JExpr newSizeInBytes) {
/* 137 */     return (PtrExpr)new VoidPtrExpr(new VoidPtrRealloc(jexpr(), newSizeInBytes));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PtrExpr pointerPlus(MethodGenerator mv, final JExpr offsetInBytes) {
/* 144 */     return (PtrExpr)new VoidPtrExpr(new JExpr()
/*     */         {
/*     */           @Nonnull
/*     */           public Type getType()
/*     */           {
/* 149 */             return Type.getType(Object.class);
/*     */           }
/*     */ 
/*     */           
/*     */           public void load(@Nonnull MethodGenerator mv) {
/* 154 */             VoidPtrExpr.this.objectRef.load(mv);
/* 155 */             offsetInBytes.load(mv);
/* 156 */             mv.invokestatic(VoidPtr.class, "pointerPlus", 
/* 157 */                 Type.getMethodDescriptor(Type.getType(Object.class), new Type[] {
/* 158 */                     Type.getType(Object.class), Type.INT_TYPE
/*     */                   }));
/*     */           }
/*     */         });
/*     */   }
/*     */   
/*     */   public GExpr valueOf(GimpleType expectedType) {
/* 165 */     throw new UnsupportedOperationException("void pointers cannot be dereferenced.");
/*     */   }
/*     */ 
/*     */   
/*     */   public ConditionGenerator comparePointer(MethodGenerator mv, GimpleOp op, GExpr otherPointer) {
/* 170 */     return new VoidPtrComparison(op, jexpr(), otherPointer.toVoidPtrExpr().jexpr());
/*     */   }
/*     */ 
/*     */   
/*     */   public VoidPtrExpr toVoidPtrExpr() throws UnsupportedCastException {
/* 175 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public VPtrExpr toVPtrExpr() throws UnsupportedCastException {
/* 180 */     return new VPtrExpr(Expressions.staticMethodCall(VoidPtr.class, "toPtr", 
/* 181 */           Type.getMethodDescriptor(Type.getType(Ptr.class), new Type[] { Type.getType(Object.class) }), new JExpr[] { this.objectRef }));
/*     */   }
/*     */ 
/*     */   
/*     */   public ProvidedPtrExpr toProvidedPtrExpr(Type jvmType) {
/* 186 */     return new ProvidedPtrExpr(Expressions.cast(jexpr(), jvmType));
/*     */   }
/*     */ 
/*     */   
/*     */   public FatPtr toFatPtrExpr(ValueFunction valueFunction) {
/* 191 */     JExpr wrapperInstance = Wrappers.cast(valueFunction.getValueType(), this.objectRef);
/* 192 */     JExpr arrayField = Wrappers.arrayField(wrapperInstance);
/* 193 */     JExpr offsetField = Wrappers.offsetField(wrapperInstance);
/*     */     
/* 195 */     return (FatPtr)new FatPtrPair(valueFunction, arrayField, offsetField);
/*     */   }
/*     */ 
/*     */   
/*     */   public VPtrRecordExpr toVPtrRecord(GimpleRecordType recordType) {
/* 200 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public VArrayExpr toVArray(GimpleArrayType arrayType) {
/* 205 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public NumericExpr toNumericExpr() {
/* 210 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/type/voidt/VoidPtrExpr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */