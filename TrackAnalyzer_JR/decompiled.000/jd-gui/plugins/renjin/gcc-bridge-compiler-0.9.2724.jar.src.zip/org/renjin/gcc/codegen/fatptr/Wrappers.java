/*     */ package org.renjin.gcc.codegen.fatptr;
/*     */ 
/*     */ import javax.annotation.Nonnull;
/*     */ import org.renjin.gcc.codegen.MethodGenerator;
/*     */ import org.renjin.gcc.codegen.WrapperType;
/*     */ import org.renjin.gcc.codegen.expr.Expressions;
/*     */ import org.renjin.gcc.codegen.expr.JExpr;
/*     */ import org.renjin.gcc.codegen.var.LocalVarAllocator;
/*     */ import org.renjin.gcc.runtime.BooleanPtr;
/*     */ import org.renjin.gcc.runtime.BytePtr;
/*     */ import org.renjin.gcc.runtime.CharPtr;
/*     */ import org.renjin.gcc.runtime.DoublePtr;
/*     */ import org.renjin.gcc.runtime.FloatPtr;
/*     */ import org.renjin.gcc.runtime.IntPtr;
/*     */ import org.renjin.gcc.runtime.LongPtr;
/*     */ import org.renjin.gcc.runtime.ObjectPtr;
/*     */ import org.renjin.gcc.runtime.PointerPtr;
/*     */ import org.renjin.gcc.runtime.Ptr;
/*     */ import org.renjin.gcc.runtime.ShortPtr;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ import org.renjin.repackaged.guava.base.Preconditions;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Wrappers
/*     */ {
/*     */   public static Type valueType(Class<?> wrapperClass) {
/*  39 */     return valueType(Type.getType(wrapperClass));
/*     */   }
/*     */ 
/*     */   
/*     */   public static Type valueType(Type wrapperType) {
/*  44 */     if (wrapperType.equals(Type.getType(BooleanPtr.class)))
/*  45 */       return Type.BOOLEAN_TYPE; 
/*  46 */     if (wrapperType.equals(Type.getType(BytePtr.class)))
/*  47 */       return Type.BYTE_TYPE; 
/*  48 */     if (wrapperType.equals(Type.getType(ShortPtr.class)))
/*  49 */       return Type.SHORT_TYPE; 
/*  50 */     if (wrapperType.equals(Type.getType(CharPtr.class)))
/*  51 */       return Type.CHAR_TYPE; 
/*  52 */     if (wrapperType.equals(Type.getType(IntPtr.class)))
/*  53 */       return Type.INT_TYPE; 
/*  54 */     if (wrapperType.equals(Type.getType(LongPtr.class)))
/*  55 */       return Type.LONG_TYPE; 
/*  56 */     if (wrapperType.equals(Type.getType(FloatPtr.class)))
/*  57 */       return Type.FLOAT_TYPE; 
/*  58 */     if (wrapperType.equals(Type.getType(DoublePtr.class)))
/*  59 */       return Type.DOUBLE_TYPE; 
/*  60 */     if (wrapperType.equals(Type.getType(ObjectPtr.class)))
/*  61 */       return Type.getType(Object.class); 
/*  62 */     if (wrapperType.equals(Type.getType(PointerPtr.class))) {
/*  63 */       return Type.getType(Ptr.class);
/*     */     }
/*  65 */     throw new IllegalArgumentException("not a wrapper type: " + wrapperType);
/*     */   }
/*     */   
/*     */   public static Type fieldArrayType(Type wrapperType) {
/*  69 */     if (wrapperType.equals(Type.getType(ObjectPtr.class))) {
/*  70 */       return Type.getType("[Ljava/lang/Object;");
/*     */     }
/*  72 */     Type valueType = valueType(wrapperType);
/*  73 */     Type arrayType = Type.getType("[" + valueType.getDescriptor());
/*  74 */     return arrayType;
/*     */   }
/*     */   
/*     */   public static Type valueArrayType(Type valueType) {
/*  78 */     return Type.getType("[" + valueType.getDescriptor());
/*     */   }
/*     */   
/*     */   public static JExpr arrayField(JExpr wrapperInstance) {
/*  82 */     return (JExpr)Expressions.field(wrapperInstance, fieldArrayType(wrapperInstance.getType()), "array");
/*     */   }
/*     */   
/*     */   public static JExpr arrayField(JExpr instance, Type valueType) {
/*  86 */     JExpr array = arrayField(instance);
/*  87 */     Type arrayType = arrayType(valueType);
/*  88 */     if (!array.getType().equals(arrayType)) {
/*  89 */       array = Expressions.cast(array, arrayType);
/*     */     }
/*  91 */     return array;
/*     */   }
/*     */ 
/*     */   
/*     */   private static Type arrayType(Type valueType) {
/*  96 */     return Type.getType("[" + valueType.getDescriptor());
/*     */   }
/*     */   
/*     */   public static JExpr offsetField(JExpr wrapperInstance) {
/* 100 */     return (JExpr)Expressions.field(wrapperInstance, Type.INT_TYPE, "offset");
/*     */   }
/*     */ 
/*     */   
/*     */   public static Type wrapperType(Type valueType) {
/* 105 */     switch (valueType.getSort()) {
/*     */       case 1:
/* 107 */         return Type.getType(BooleanPtr.class);
/*     */       case 4:
/* 109 */         return Type.getType(ShortPtr.class);
/*     */       case 3:
/* 111 */         return Type.getType(BytePtr.class);
/*     */       case 2:
/* 113 */         return Type.getType(CharPtr.class);
/*     */       case 5:
/* 115 */         return Type.getType(IntPtr.class);
/*     */       case 7:
/* 117 */         return Type.getType(LongPtr.class);
/*     */       case 6:
/* 119 */         return Type.getType(FloatPtr.class);
/*     */       case 8:
/* 121 */         return Type.getType(DoublePtr.class);
/*     */       case 10:
/* 123 */         return Type.getType(PointerPtr.class);
/*     */     } 
/* 125 */     throw new UnsupportedOperationException("No wrapper for type: " + valueType);
/*     */   }
/*     */   
/*     */   public static WrapperType valueOf(Class<?> wrapperClass) {
/* 129 */     return WrapperType.valueOf(Type.getType(wrapperClass));
/*     */   }
/*     */   
/*     */   public static JExpr cast(final Type valueType, final JExpr pointer) {
/* 133 */     final Type wrapperType = wrapperType(valueType);
/*     */     
/* 135 */     return new JExpr()
/*     */       {
/*     */         @Nonnull
/*     */         public Type getType() {
/* 139 */           return wrapperType;
/*     */         }
/*     */ 
/*     */         
/*     */         public void load(@Nonnull MethodGenerator mv) {
/* 144 */           pointer.load(mv);
/* 145 */           if (wrapperType.equals(Type.getType(ObjectPtr.class))) {
/*     */             
/* 147 */             mv.visitLdcInsn(valueType);
/* 148 */             mv.invokestatic(wrapperType, "cast", Type.getMethodDescriptor(wrapperType, new Type[] {
/* 149 */                     Type.getType(Object.class), Type.getType(Class.class)
/*     */                   }));
/*     */           } else {
/* 152 */             mv.invokestatic(wrapperType, "cast", Type.getMethodDescriptor(wrapperType, new Type[] { Type.getType(Object.class) }));
/*     */           } 
/*     */         }
/*     */       };
/*     */   }
/*     */   
/*     */   public static Type componentType(Type arrayType) {
/* 159 */     Preconditions.checkArgument((arrayType.getSort() == 9), "arrayType: " + arrayType);
/*     */     
/* 161 */     String arrayDescriptor = arrayType.getDescriptor();
/* 162 */     assert arrayDescriptor.startsWith("[");
/*     */     
/* 164 */     String componentDescriptor = arrayDescriptor.substring(1);
/* 165 */     return Type.getType(componentDescriptor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static FatPtrPair toPair(MethodGenerator mv, ValueFunction valueFunction, JExpr wrapper) {
/* 173 */     LocalVarAllocator.LocalVar tempVar = mv.getLocalVarAllocator().reserve(wrapper.getType());
/* 174 */     tempVar.store(mv, wrapper);
/*     */     
/* 176 */     JExpr array = arrayField((JExpr)tempVar, valueType(wrapper.getType()));
/* 177 */     if (wrapper.getType().equals(Type.getType(ObjectPtr.class))) {
/* 178 */       array = Expressions.cast(array, arrayType(valueFunction.getValueType()));
/*     */     }
/* 180 */     JExpr offset = offsetField((JExpr)tempVar);
/*     */     
/* 182 */     return new FatPtrPair(valueFunction, array, offset);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/fatptr/Wrappers.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */