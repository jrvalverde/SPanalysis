/*     */ package org.renjin.gcc.codegen.array;
/*     */ 
/*     */ import org.renjin.gcc.InternalCompilerException;
/*     */ import org.renjin.gcc.codegen.MethodGenerator;
/*     */ import org.renjin.gcc.codegen.expr.Expressions;
/*     */ import org.renjin.gcc.codegen.expr.GExpr;
/*     */ import org.renjin.gcc.codegen.expr.JExpr;
/*     */ import org.renjin.gcc.codegen.expr.JLValue;
/*     */ import org.renjin.gcc.codegen.fatptr.FatPtrMalloc;
/*     */ import org.renjin.gcc.codegen.fatptr.ValueFunction;
/*     */ import org.renjin.gcc.codegen.fatptr.Wrappers;
/*     */ import org.renjin.gcc.codegen.type.SingleFieldStrategy;
/*     */ import org.renjin.gcc.codegen.type.primitive.PrimitiveTypeStrategy;
/*     */ import org.renjin.gcc.gimple.type.GimpleArrayType;
/*     */ import org.renjin.gcc.gimple.type.GimpleType;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ArrayField
/*     */   extends SingleFieldStrategy
/*     */ {
/*     */   private GimpleArrayType arrayType;
/*     */   private int arrayLength;
/*     */   private final ValueFunction valueFunction;
/*     */   
/*     */   public ArrayField(Type declaringClass, String name, int arrayLength, GimpleArrayType arrayType, ValueFunction valueFunction) {
/*  48 */     super(declaringClass, name, Wrappers.valueArrayType(valueFunction.getValueType()));
/*  49 */     this.arrayLength = arrayLength;
/*  50 */     this.arrayType = arrayType;
/*  51 */     this.valueFunction = valueFunction;
/*     */   }
/*     */ 
/*     */   
/*     */   public void emitInstanceInit(MethodGenerator mv) {
/*  56 */     JExpr newArray = FatPtrMalloc.allocArray(mv, this.valueFunction, 
/*  57 */         Expressions.constantInt(this.arrayLength * this.valueFunction.getElementLength()));
/*  58 */     JLValue arrayField = Expressions.field(Expressions.thisValue(this.ownerClass), this.fieldType, this.fieldName);
/*     */     
/*  60 */     arrayField.store(mv, newArray);
/*     */   }
/*     */ 
/*     */   
/*     */   public GExpr memberExpr(MethodGenerator mv, JExpr instance, int offset, int size, GimpleType expectedType) {
/*  65 */     JLValue jLValue = Expressions.field(instance, this.fieldType, this.fieldName);
/*  66 */     JExpr offsetExpr = Expressions.constantInt(offset / 8 / this.valueFunction.getArrayElementBytes());
/*     */     
/*  68 */     if (expectedType instanceof PrimitiveTypeStrategy) {
/*  69 */       PrimitiveTypeStrategy primitiveTypeStrategy = (PrimitiveTypeStrategy)expectedType;
/*  70 */       if (!primitiveTypeStrategy.getJvmType().equals(this.valueFunction.getValueType())) {
/*  71 */         throw new InternalCompilerException("TODO: " + this.valueFunction.getValueType() + "[] => " + primitiveTypeStrategy
/*  72 */             .getType());
/*     */       }
/*     */       
/*  75 */       return primitiveTypeStrategy.getValueFunction().dereference((JExpr)jLValue, offsetExpr);
/*     */     } 
/*  77 */     if (expectedType instanceof ArrayTypeStrategy) {
/*  78 */       return (GExpr)new FatArrayExpr(this.arrayType, this.valueFunction, this.arrayLength, (JExpr)jLValue, offsetExpr);
/*     */     }
/*     */     
/*  81 */     throw new UnsupportedOperationException("expectedType: " + expectedType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void copy(MethodGenerator mv, JExpr source, JExpr dest) {
/*  88 */     JLValue jLValue1 = Expressions.field(source, this.fieldType, this.fieldName);
/*  89 */     JLValue jLValue2 = Expressions.field(dest, this.fieldType, this.fieldName);
/*     */     
/*  91 */     this.valueFunction.memoryCopy(mv, (JExpr)jLValue2, 
/*  92 */         Expressions.constantInt(0), (JExpr)jLValue1, 
/*  93 */         Expressions.constantInt(0), 
/*  94 */         Expressions.constantInt(this.arrayLength));
/*     */   }
/*     */ 
/*     */   
/*     */   public void memset(MethodGenerator mv, JExpr instance, JExpr byteValue, JExpr byteCount) {
/*  99 */     JLValue arrayFieldExpr = Expressions.field(instance, this.fieldType, this.fieldName);
/* 100 */     this.valueFunction.memorySet(mv, (JExpr)arrayFieldExpr, Expressions.zero(), byteValue, byteCount);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/array/ArrayField.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */