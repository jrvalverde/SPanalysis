/*     */ package org.renjin.gcc.gimple;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.function.Predicate;
/*     */ import org.renjin.gcc.gimple.expr.GimpleExpr;
/*     */ import org.renjin.gcc.gimple.statement.GimpleEdge;
/*     */ import org.renjin.gcc.gimple.statement.GimpleStatement;
/*     */ import org.renjin.repackaged.guava.collect.Lists;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GimpleBasicBlock
/*     */ {
/*     */   private int index;
/*  39 */   private List<GimpleStatement> statements = Lists.newArrayList();
/*  40 */   private List<GimpleEdge> edges = Lists.newArrayList();
/*     */ 
/*     */   
/*     */   public GimpleBasicBlock() {}
/*     */   
/*     */   public GimpleBasicBlock(GimpleStatement... statements) {
/*  46 */     this.statements.addAll(Arrays.asList(statements));
/*     */   }
/*     */   
/*     */   public int getIndex() {
/*  50 */     return this.index;
/*     */   }
/*     */   
/*     */   public void setIndex(int index) {
/*  54 */     this.index = index;
/*     */   }
/*     */   
/*     */   public String getName() {
/*  58 */     return "" + this.index;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  63 */     StringBuilder sb = new StringBuilder();
/*  64 */     sb.append("<").append(this.index).append(">:\n");
/*  65 */     for (GimpleStatement ins : this.statements) {
/*  66 */       sb.append("  ").append(ins).append("\n");
/*     */     }
/*  68 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<GimpleStatement> getStatements() {
/*  76 */     return this.statements;
/*     */   }
/*     */   
/*     */   public void setStatements(List<GimpleStatement> statements) {
/*  80 */     this.statements = statements;
/*     */   }
/*     */   
/*     */   public List<GimpleEdge> getEdges() {
/*  84 */     return this.edges;
/*     */   }
/*     */   
/*     */   public void setEdges(List<GimpleEdge> edges) {
/*  88 */     this.edges = edges;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void replaceAll(Predicate<? super GimpleExpr> predicate, GimpleExpr newExpr) {
/*  96 */     for (GimpleStatement instruction : this.statements) {
/*  97 */       instruction.replaceAll(predicate, newExpr);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GimpleStatement getLast() {
/* 106 */     return this.statements.get(this.statements.size() - 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isReturning() {
/* 114 */     if (this.statements.isEmpty()) {
/* 115 */       return false;
/*     */     }
/* 117 */     return getLast() instanceof org.renjin.gcc.gimple.statement.GimpleReturn;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<GimpleEdge> getJumps() {
/* 122 */     if (this.edges.isEmpty()) {
/* 123 */       return Collections.emptyList();
/*     */     }
/* 125 */     return this.edges;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 134 */     return this.statements.isEmpty();
/*     */   }
/*     */   
/*     */   public boolean fallsThrough() {
/* 138 */     if (this.statements.isEmpty()) {
/* 139 */       return true;
/*     */     }
/* 141 */     GimpleStatement lastStatement = this.statements.get(this.statements.size() - 1);
/* 142 */     if (lastStatement instanceof org.renjin.gcc.gimple.statement.GimpleReturn || lastStatement instanceof org.renjin.gcc.gimple.statement.GimpleConditional || lastStatement instanceof org.renjin.gcc.gimple.statement.GimpleGoto)
/*     */     {
/*     */       
/* 145 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 149 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void accept(GimpleExprVisitor visitor) {
/* 154 */     for (GimpleStatement statement : this.statements)
/* 155 */       statement.accept(visitor); 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/gimple/GimpleBasicBlock.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */