/*    */ package org.renjin.gcc.gimple;
/*    */ 
/*    */ import com.fasterxml.jackson.core.Version;
/*    */ import com.fasterxml.jackson.databind.Module;
/*    */ import com.fasterxml.jackson.databind.ObjectMapper;
/*    */ import com.fasterxml.jackson.databind.module.SimpleModule;
/*    */ import java.io.File;
/*    */ import java.io.FileReader;
/*    */ import java.io.IOException;
/*    */ import java.io.Reader;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GimpleParser
/*    */ {
/*    */   private final ObjectMapper mapper;
/*    */   
/*    */   public GimpleParser() {
/* 40 */     SimpleModule gimpleModule = (new SimpleModule("Gimple", Version.unknownVersion())).addDeserializer(GimpleOp.class, new GimpleOpDeserializer());
/*    */ 
/*    */     
/* 43 */     this.mapper = new ObjectMapper();
/* 44 */     this.mapper.registerModule((Module)gimpleModule);
/*    */   }
/*    */   
/*    */   private GimpleCompilationUnit parse(Reader reader) throws IOException {
/* 48 */     GimpleCompilationUnit unit = (GimpleCompilationUnit)this.mapper.readValue(reader, GimpleCompilationUnit.class);
/* 49 */     for (GimpleFunction function : unit.getFunctions()) {
/* 50 */       function.setUnit(unit);
/*    */     }
/* 52 */     for (GimpleVarDecl varDecl : unit.getGlobalVariables()) {
/* 53 */       varDecl.setUnit(unit);
/* 54 */       varDecl.setGlobal(true);
/*    */     } 
/* 56 */     return unit;
/*    */   }
/*    */   
/*    */   public GimpleCompilationUnit parse(File file) throws IOException {
/* 60 */     FileReader reader = new FileReader(file);
/*    */     try {
/* 62 */       GimpleCompilationUnit unit = parse(reader);
/* 63 */       unit.setSourceFile(file);
/* 64 */       return unit;
/*    */     } finally {
/* 66 */       reader.close();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/gimple/GimpleParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */