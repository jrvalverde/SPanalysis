/*     */ package org.renjin.gcc.codegen.vptr;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.renjin.gcc.codegen.MethodGenerator;
/*     */ import org.renjin.gcc.codegen.expr.ExprFactory;
/*     */ import org.renjin.gcc.codegen.expr.Expressions;
/*     */ import org.renjin.gcc.codegen.expr.GExpr;
/*     */ import org.renjin.gcc.codegen.expr.JExpr;
/*     */ import org.renjin.gcc.codegen.expr.JLValue;
/*     */ import org.renjin.gcc.codegen.fatptr.ValueFunction;
/*     */ import org.renjin.gcc.codegen.type.FieldStrategy;
/*     */ import org.renjin.gcc.codegen.type.ParamStrategy;
/*     */ import org.renjin.gcc.codegen.type.PointerTypeStrategy;
/*     */ import org.renjin.gcc.codegen.type.ReturnStrategy;
/*     */ import org.renjin.gcc.codegen.type.TypeStrategy;
/*     */ import org.renjin.gcc.codegen.type.UnsupportedCastException;
/*     */ import org.renjin.gcc.codegen.var.VarAllocator;
/*     */ import org.renjin.gcc.gimple.GimpleVarDecl;
/*     */ import org.renjin.gcc.gimple.expr.GimpleConstructor;
/*     */ import org.renjin.gcc.gimple.expr.GimpleFieldRef;
/*     */ import org.renjin.gcc.gimple.type.GimpleArrayType;
/*     */ import org.renjin.gcc.gimple.type.GimpleType;
/*     */ import org.renjin.gcc.runtime.MixedPtr;
/*     */ import org.renjin.gcc.runtime.PointerPtr;
/*     */ import org.renjin.gcc.runtime.Ptr;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VArrayStrategy
/*     */   implements TypeStrategy<VArrayExpr>
/*     */ {
/*     */   private GimpleArrayType arrayType;
/*     */   
/*     */   public VArrayStrategy(GimpleArrayType arrayType) {
/*  45 */     this.arrayType = arrayType;
/*     */   }
/*     */ 
/*     */   
/*     */   public ParamStrategy getParamStrategy() {
/*  50 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public ReturnStrategy getReturnStrategy() {
/*  55 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public ValueFunction getValueFunction() {
/*  60 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public VArrayExpr variable(GimpleVarDecl decl, VarAllocator allocator) {
/*  65 */     JExpr malloc = VPtrStrategy.malloc((GimpleType)this.arrayType, Expressions.constantInt(this.arrayType.sizeOf())).getRef();
/*  66 */     JLValue var = allocator.reserve(decl.getNameIfPresent(), Type.getType(Ptr.class), malloc);
/*     */     
/*  68 */     return new VArrayExpr(this.arrayType, new VPtrExpr((JExpr)var));
/*     */   }
/*     */ 
/*     */   
/*     */   public VArrayExpr providedGlobalVariable(GimpleVarDecl decl, JExpr expr, boolean readOnly) {
/*  73 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public VArrayExpr constructorExpr(ExprFactory exprFactory, MethodGenerator mv, GimpleConstructor value) {
/*  79 */     if (this.arrayType.getComponentType() instanceof org.renjin.gcc.gimple.type.GimpleIndirectType) {
/*  80 */       return pointerArrayConstructorExpr(exprFactory, mv, value);
/*     */     }
/*  82 */     if (this.arrayType.getComponentType() instanceof org.renjin.gcc.gimple.type.GimpleRecordType) {
/*  83 */       return mixedRecordArrayConstructor(exprFactory, mv, value);
/*     */     }
/*     */     
/*  86 */     throw new UnsupportedOperationException("TODO: " + this.arrayType);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private VArrayExpr mixedRecordArrayConstructor(ExprFactory exprFactory, MethodGenerator mv, GimpleConstructor value) {
/*  92 */     Type pointerType = Type.getType(MixedPtr.class);
/*  93 */     VPtrExpr malloc = VPtrStrategy.malloc(pointerType, Expressions.constantInt(this.arrayType.sizeOf()));
/*  94 */     VPtrExpr tempVar = new VPtrExpr((JExpr)mv.getLocalVarAllocator().reserve(pointerType));
/*  95 */     tempVar.store(mv, (GExpr)malloc);
/*     */     
/*  97 */     int offset = 0;
/*  98 */     for (GimpleConstructor.Element element : value.getElements()) {
/*  99 */       GimpleConstructor recordCtor = (GimpleConstructor)element.getValue();
/* 100 */       for (GimpleConstructor.Element fieldCtor : recordCtor.getElements()) {
/* 101 */         GimpleFieldRef field = (GimpleFieldRef)fieldCtor.getField();
/* 102 */         GExpr fieldExpr = exprFactory.findGenerator(fieldCtor.getValue(), field.getType());
/*     */         
/* 104 */         tempVar.valueOf(field.getType(), Expressions.constantInt(offset + field.getOffsetBytes()))
/* 105 */           .store(mv, fieldExpr);
/*     */       } 
/* 107 */       offset += this.arrayType.getComponentType().sizeOf();
/*     */     } 
/*     */     
/* 110 */     return new VArrayExpr(this.arrayType, tempVar);
/*     */   }
/*     */ 
/*     */   
/*     */   private VArrayExpr pointerArrayConstructorExpr(ExprFactory exprFactory, MethodGenerator mv, GimpleConstructor value) {
/* 115 */     List<JExpr> pointers = new ArrayList<>();
/* 116 */     for (GimpleConstructor.Element element : value.getElements()) {
/* 117 */       GExpr ptrExpr = exprFactory.findGenerator(element.getValue(), this.arrayType.getComponentType());
/* 118 */       pointers.add(ptrExpr.toVPtrExpr().getRef());
/*     */     } 
/*     */     
/* 121 */     JExpr array = Expressions.newArray(Type.getType(Ptr.class), this.arrayType.getElementCount(), pointers);
/*     */     
/* 123 */     VPtrExpr pointer = new VPtrExpr(Expressions.newObject(Type.getType(PointerPtr.class), new JExpr[] { array }));
/* 124 */     VArrayExpr arrayExpr = new VArrayExpr(this.arrayType, pointer);
/*     */     
/* 126 */     return arrayExpr;
/*     */   }
/*     */ 
/*     */   
/*     */   public FieldStrategy fieldGenerator(Type className, String fieldName) {
/* 131 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public FieldStrategy addressableFieldGenerator(Type className, String fieldName) {
/* 136 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public PointerTypeStrategy pointerTo() {
/* 141 */     return new VPtrStrategy((GimpleType)this.arrayType);
/*     */   }
/*     */ 
/*     */   
/*     */   public VArrayStrategy arrayOf(GimpleArrayType arrayType) {
/* 146 */     return new VArrayStrategy(arrayType);
/*     */   }
/*     */ 
/*     */   
/*     */   public VArrayExpr cast(MethodGenerator mv, GExpr value) throws UnsupportedCastException {
/* 151 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/vptr/VArrayStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */