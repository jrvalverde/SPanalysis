/*    */ package org.renjin.gcc.codegen.vptr;
/*    */ 
/*    */ import javax.annotation.Nonnull;
/*    */ import org.renjin.gcc.codegen.MethodGenerator;
/*    */ import org.renjin.gcc.codegen.expr.Expressions;
/*    */ import org.renjin.gcc.codegen.expr.GExpr;
/*    */ import org.renjin.gcc.codegen.expr.JExpr;
/*    */ import org.renjin.gcc.codegen.type.ReturnStrategy;
/*    */ import org.renjin.gcc.codegen.type.TypeStrategy;
/*    */ import org.renjin.gcc.gimple.type.GimpleRecordType;
/*    */ import org.renjin.gcc.gimple.type.GimpleType;
/*    */ import org.renjin.gcc.runtime.Ptr;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VPtrRecordReturnStrategy
/*    */   implements ReturnStrategy
/*    */ {
/*    */   private GimpleRecordType recordType;
/*    */   
/*    */   public VPtrRecordReturnStrategy(GimpleRecordType recordType) {
/* 38 */     this.recordType = recordType;
/*    */   }
/*    */ 
/*    */   
/*    */   public Type getType() {
/* 43 */     return Type.getType(Ptr.class);
/*    */   }
/*    */ 
/*    */   
/*    */   public JExpr marshall(GExpr expr) {
/* 48 */     return ((VPtrRecordExpr)expr).getRef();
/*    */   }
/*    */ 
/*    */   
/*    */   public GExpr unmarshall(MethodGenerator mv, JExpr callExpr, TypeStrategy lhsTypeStrategy) {
/* 53 */     return (GExpr)new VPtrRecordExpr(this.recordType, new VPtrExpr(callExpr));
/*    */   }
/*    */ 
/*    */   
/*    */   public JExpr getDefaultReturnValue() {
/* 58 */     final VPtrStrategy strategy = new VPtrStrategy((GimpleType)this.recordType);
/* 59 */     return new JExpr()
/*    */       {
/*    */         @Nonnull
/*    */         public Type getType() {
/* 63 */           return Type.getType(Ptr.class);
/*    */         }
/*    */ 
/*    */         
/*    */         public void load(@Nonnull MethodGenerator mv) {
/* 68 */           strategy.malloc(mv, Expressions.constantInt(VPtrRecordReturnStrategy.this.recordType.sizeOf())).getRef().load(mv);
/*    */         }
/*    */       };
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/vptr/VPtrRecordReturnStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */