/*    */ package org.renjin.gcc.codegen.type.fun;
/*    */ 
/*    */ import org.renjin.gcc.codegen.MethodGenerator;
/*    */ import org.renjin.gcc.codegen.expr.Expressions;
/*    */ import org.renjin.gcc.codegen.expr.GExpr;
/*    */ import org.renjin.gcc.codegen.expr.JExpr;
/*    */ import org.renjin.gcc.codegen.type.SingleFieldStrategy;
/*    */ import org.renjin.gcc.gimple.type.GimpleType;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FunPtrField
/*    */   extends SingleFieldStrategy
/*    */ {
/*    */   public FunPtrField(Type ownerClass, String fieldName) {
/* 32 */     super(ownerClass, fieldName, FunPtrStrategy.METHOD_HANDLE_TYPE);
/*    */   }
/*    */ 
/*    */   
/*    */   public GExpr memberExpr(MethodGenerator mv, JExpr instance, int offset, int size, GimpleType expectedType) {
/* 37 */     if (offset != 0) {
/* 38 */       throw new IllegalStateException("offset = " + offset);
/*    */     }
/* 40 */     return (GExpr)new FunPtrExpr((JExpr)Expressions.field(instance, FunPtrStrategy.METHOD_HANDLE_TYPE, this.fieldName));
/*    */   }
/*    */ 
/*    */   
/*    */   public void memset(MethodGenerator mv, JExpr instance, JExpr byteValue, JExpr byteCount) {
/* 45 */     memsetReference(mv, instance, byteValue, byteCount);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/type/fun/FunPtrField.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */