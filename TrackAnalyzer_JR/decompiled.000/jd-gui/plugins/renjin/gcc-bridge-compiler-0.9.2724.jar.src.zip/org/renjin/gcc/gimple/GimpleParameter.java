/*    */ package org.renjin.gcc.gimple;
/*    */ 
/*    */ import org.renjin.gcc.gimple.type.GimpleType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GimpleParameter
/*    */ {
/*    */   private GimpleType type;
/*    */   private String name;
/*    */   private long id;
/*    */   private boolean addressable;
/*    */   
/*    */   public long getId() {
/* 36 */     return this.id;
/*    */   }
/*    */   
/*    */   public void setId(long id) {
/* 40 */     this.id = id;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public GimpleType getType() {
/* 47 */     return this.type;
/*    */   }
/*    */   
/*    */   public void setType(GimpleType type) {
/* 51 */     this.type = type;
/*    */   }
/*    */   
/*    */   public void setName(String name) {
/* 55 */     this.name = name;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getName() {
/* 63 */     return this.name;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isAddressable() {
/* 72 */     return this.addressable;
/*    */   }
/*    */   
/*    */   public void setAddressable(boolean addressable) {
/* 76 */     this.addressable = addressable;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 81 */     return this.type + " " + this.name;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/gimple/GimpleParameter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */