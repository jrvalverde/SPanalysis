/*    */ package org.renjin.gcc;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ImportException
/*    */   extends RuntimeException
/*    */ {
/*    */   public ImportException() {}
/*    */   
/*    */   public ImportException(String message) {
/* 30 */     super(message);
/*    */   }
/*    */   
/*    */   public ImportException(String message, Throwable cause) {
/* 34 */     super(message, cause);
/*    */   }
/*    */   
/*    */   public ImportException(Throwable cause) {
/* 38 */     super(cause);
/*    */   }
/*    */   
/*    */   public ImportException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
/* 42 */     super(message, cause, enableSuppression, writableStackTrace);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/ImportException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */