/*     */ package org.renjin.gcc.gimple.statement;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.annotation.JsonSubTypes;
/*     */ import com.fasterxml.jackson.annotation.JsonSubTypes.Type;
/*     */ import com.fasterxml.jackson.annotation.JsonTypeInfo;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.function.Predicate;
/*     */ import org.renjin.gcc.gimple.GimpleExprVisitor;
/*     */ import org.renjin.gcc.gimple.GimpleVisitor;
/*     */ import org.renjin.gcc.gimple.expr.GimpleExpr;
/*     */ import org.renjin.gcc.gimple.expr.GimpleLValue;
/*     */ import org.renjin.gcc.gimple.expr.GimpleSymbolRef;
/*     */ import org.renjin.gcc.gimple.expr.GimpleVariableRef;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @JsonTypeInfo(use = JsonTypeInfo.Id.NAME, include = JsonTypeInfo.As.PROPERTY, property = "type")
/*     */ @JsonSubTypes({@Type(value = GimpleAssignment.class, name = "assign"), @Type(value = GimpleCall.class, name = "call"), @Type(value = GimpleConditional.class, name = "conditional"), @Type(value = GimpleReturn.class, name = "return"), @Type(value = GimpleGoto.class, name = "goto"), @Type(value = GimpleSwitch.class, name = "switch"), @Type(value = GimpleBlock.class, name = "block"), @Type(value = GimpleAsm.class, name = "gimple_asm")})
/*     */ public abstract class GimpleStatement
/*     */ {
/*     */   @JsonProperty("line")
/*     */   private Integer lineNumber;
/*     */   @JsonProperty("file")
/*     */   private String sourceFile;
/*     */   
/*     */   public boolean lhsMatches(Predicate<? super GimpleLValue> predicate) {
/*  66 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterable<? extends GimpleSymbolRef> getUsedExpressions() {
/*  74 */     return Collections.emptySet();
/*     */   }
/*     */   
/*     */   public final List<GimpleExpr> findUses(Predicate<? super GimpleExpr> predicate) {
/*  78 */     List<GimpleExpr> set = new ArrayList<>();
/*  79 */     findUses(predicate, set);
/*  80 */     return set;
/*     */   }
/*     */ 
/*     */   
/*     */   public final <T extends GimpleExpr> List<T> findUses(Class<T> exprClass) {
/*  85 */     return (List)findUses(use -> exprClass.isInstance(use));
/*     */   }
/*     */   
/*     */   public final List<GimpleVariableRef> findVariableUses() {
/*  89 */     return findUses(GimpleVariableRef.class);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void findUses(Predicate<? super GimpleExpr> predicate, List<GimpleExpr> results) {}
/*     */ 
/*     */   
/*     */   protected final void findUses(List<GimpleExpr> operands, Predicate<? super GimpleExpr> predicate, List<GimpleExpr> results) {
/*  97 */     for (GimpleExpr operand : operands) {
/*  98 */       operand.findOrDescend(predicate, results);
/*     */     }
/*     */   }
/*     */   
/*     */   public final Integer getLineNumber() {
/* 103 */     return this.lineNumber;
/*     */   }
/*     */   
/*     */   public void setLineNumber(Integer lineNumber) {
/* 107 */     this.lineNumber = lineNumber;
/*     */   }
/*     */   
/*     */   public void setSourceFile(String sourceFile) {
/* 111 */     this.sourceFile = sourceFile;
/*     */   }
/*     */   
/*     */   protected final void replaceAll(Predicate<? super GimpleExpr> predicate, List<GimpleExpr> operands, GimpleExpr newExpr) {
/* 115 */     for (int i = 0; i < operands.size(); i++) {
/* 116 */       if (predicate.test(operands.get(i))) {
/* 117 */         operands.set(i, newExpr);
/*     */       } else {
/* 119 */         ((GimpleExpr)operands.get(i)).replaceAll(predicate, newExpr);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void replaceAll(Predicate<? super GimpleExpr> predicate, GimpleExpr newExpr) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<Integer> getJumpTargets() {
/* 135 */     return Collections.emptySet();
/*     */   }
/*     */   
/*     */   public String getSourceFile() {
/* 139 */     return this.sourceFile;
/*     */   }
/*     */   
/*     */   public abstract void visit(GimpleVisitor paramGimpleVisitor);
/*     */   
/*     */   public abstract void accept(GimpleExprVisitor paramGimpleExprVisitor);
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/gimple/statement/GimpleStatement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */