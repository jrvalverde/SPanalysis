/*    */ package org.renjin.gcc.gimple.expr;
/*    */ 
/*    */ import org.renjin.gcc.gimple.type.GimpleBooleanType;
/*    */ import org.renjin.gcc.gimple.type.GimpleIndirectType;
/*    */ import org.renjin.gcc.gimple.type.GimpleIntegerType;
/*    */ import org.renjin.gcc.gimple.type.GimpleType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GimpleIntegerConstant
/*    */   extends GimplePrimitiveConstant
/*    */ {
/*    */   private long value;
/*    */   
/*    */   public GimpleIntegerConstant() {}
/*    */   
/*    */   public GimpleIntegerConstant(GimpleIntegerType type, long value) {
/* 32 */     setType((GimpleType)type);
/* 33 */     this.value = value;
/*    */   }
/*    */   
/*    */   public GimpleIntegerConstant(GimpleBooleanType type, boolean value) {
/* 37 */     setType((GimpleType)type);
/* 38 */     this.value = value ? 1L : 0L;
/*    */   }
/*    */   
/*    */   public Long getValue() {
/* 42 */     return Long.valueOf(this.value);
/*    */   }
/*    */   
/*    */   public void setValue(long value) {
/* 46 */     this.value = value;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isNull() {
/* 51 */     return (getType() instanceof GimpleIndirectType && this.value == 0L);
/*    */   }
/*    */   
/*    */   public static GimpleIntegerConstant nullValue(GimpleIndirectType type) {
/* 55 */     GimpleIntegerConstant constant = new GimpleIntegerConstant();
/* 56 */     constant.setValue(0L);
/* 57 */     constant.setType((GimpleType)type);
/* 58 */     return constant;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/gimple/expr/GimpleIntegerConstant.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */