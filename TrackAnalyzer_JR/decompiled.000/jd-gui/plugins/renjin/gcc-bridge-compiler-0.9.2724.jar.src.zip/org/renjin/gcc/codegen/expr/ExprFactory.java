/*     */ package org.renjin.gcc.codegen.expr;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Optional;
/*     */ import org.renjin.gcc.InternalCompilerException;
/*     */ import org.renjin.gcc.codegen.MethodGenerator;
/*     */ import org.renjin.gcc.codegen.call.CallGenerator;
/*     */ import org.renjin.gcc.codegen.condition.ConditionGenerator;
/*     */ import org.renjin.gcc.codegen.condition.ConstConditionGenerator;
/*     */ import org.renjin.gcc.codegen.condition.NullCheckGenerator;
/*     */ import org.renjin.gcc.codegen.fatptr.FatPtrPair;
/*     */ import org.renjin.gcc.codegen.fatptr.ValueFunction;
/*     */ import org.renjin.gcc.codegen.type.TypeOracle;
/*     */ import org.renjin.gcc.codegen.type.TypeStrategy;
/*     */ import org.renjin.gcc.codegen.type.UnsupportedCastException;
/*     */ import org.renjin.gcc.codegen.type.complex.ComplexExpr;
/*     */ import org.renjin.gcc.codegen.type.fun.FunPtrExpr;
/*     */ import org.renjin.gcc.codegen.type.primitive.BooleanExpr;
/*     */ import org.renjin.gcc.codegen.type.primitive.NumericIntExpr;
/*     */ import org.renjin.gcc.codegen.type.primitive.PrimitiveExpr;
/*     */ import org.renjin.gcc.codegen.type.primitive.PrimitiveType;
/*     */ import org.renjin.gcc.codegen.type.primitive.PrimitiveValueFunction;
/*     */ import org.renjin.gcc.codegen.type.primitive.PtrCarryingExpr;
/*     */ import org.renjin.gcc.codegen.type.primitive.StringConstant;
/*     */ import org.renjin.gcc.codegen.type.record.RecordExpr;
/*     */ import org.renjin.gcc.codegen.vptr.VPtrExpr;
/*     */ import org.renjin.gcc.codegen.vptr.VPtrRecordExpr;
/*     */ import org.renjin.gcc.gimple.GimpleOp;
/*     */ import org.renjin.gcc.gimple.expr.GimpleAddressOf;
/*     */ import org.renjin.gcc.gimple.expr.GimpleArrayRef;
/*     */ import org.renjin.gcc.gimple.expr.GimpleBitFieldRefExpr;
/*     */ import org.renjin.gcc.gimple.expr.GimpleComplexConstant;
/*     */ import org.renjin.gcc.gimple.expr.GimpleComplexPartExpr;
/*     */ import org.renjin.gcc.gimple.expr.GimpleComponentRef;
/*     */ import org.renjin.gcc.gimple.expr.GimpleCompoundLiteral;
/*     */ import org.renjin.gcc.gimple.expr.GimpleConstant;
/*     */ import org.renjin.gcc.gimple.expr.GimpleConstantRef;
/*     */ import org.renjin.gcc.gimple.expr.GimpleConstructor;
/*     */ import org.renjin.gcc.gimple.expr.GimpleExpr;
/*     */ import org.renjin.gcc.gimple.expr.GimpleFunctionRef;
/*     */ import org.renjin.gcc.gimple.expr.GimpleIntegerConstant;
/*     */ import org.renjin.gcc.gimple.expr.GimpleMemRef;
/*     */ import org.renjin.gcc.gimple.expr.GimpleObjectTypeRef;
/*     */ import org.renjin.gcc.gimple.expr.GimplePointerPlus;
/*     */ import org.renjin.gcc.gimple.expr.GimplePrimitiveConstant;
/*     */ import org.renjin.gcc.gimple.expr.GimpleStringConstant;
/*     */ import org.renjin.gcc.gimple.type.GimpleIndirectType;
/*     */ import org.renjin.gcc.gimple.type.GimplePointerType;
/*     */ import org.renjin.gcc.gimple.type.GimplePrimitiveType;
/*     */ import org.renjin.gcc.gimple.type.GimpleRecordType;
/*     */ import org.renjin.gcc.gimple.type.GimpleType;
/*     */ import org.renjin.gcc.runtime.BytePtr;
/*     */ import org.renjin.gcc.runtime.Ptr;
/*     */ import org.renjin.gcc.symbols.SymbolTable;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ 
/*     */ public class ExprFactory {
/*     */   private final TypeOracle typeOracle;
/*     */   private final SymbolTable symbolTable;
/*     */   
/*     */   public ExprFactory(TypeOracle typeOracle, SymbolTable symbolTable, MethodGenerator mv, Optional<VPtrExpr> varArgsPtr) {
/*  62 */     this.typeOracle = typeOracle;
/*  63 */     this.symbolTable = symbolTable;
/*  64 */     this.mv = mv;
/*  65 */     this.varArgsPtr = varArgsPtr;
/*     */   }
/*     */   private MethodGenerator mv; private Optional<VPtrExpr> varArgsPtr;
/*     */   public ExprFactory(TypeOracle typeOracle, SymbolTable symbolTable, MethodGenerator mv) {
/*  69 */     this(typeOracle, symbolTable, mv, Optional.empty());
/*     */   }
/*     */   
/*     */   public Optional<VPtrExpr> getVarArgsPtr() {
/*  73 */     return this.varArgsPtr;
/*     */   }
/*     */   
/*     */   public GExpr findGenerator(GimpleExpr expr, GimpleType expectedType) {
/*  77 */     return maybeCast(findGenerator(expr), expectedType, expr.getType());
/*     */   }
/*     */ 
/*     */   
/*     */   public GExpr maybeCast(GExpr rhs, GimpleType lhsType, GimpleType rhsType) {
/*  82 */     if (lhsType.equals(rhsType)) {
/*  83 */       return rhs;
/*     */     }
/*     */     
/*  86 */     TypeStrategy leftStrategy = this.typeOracle.forType(lhsType);
/*  87 */     TypeStrategy rightStrategy = this.typeOracle.forType(rhsType);
/*     */     
/*     */     try {
/*  90 */       return leftStrategy.cast(this.mv, rhs);
/*  91 */     } catch (UnsupportedCastException e) {
/*  92 */       throw new InternalCompilerException(String.format("Unsupported cast to %s [%s] from %s [%s]", new Object[] { lhsType, leftStrategy
/*  93 */               .getClass().getSimpleName(), rhsType, rightStrategy
/*  94 */               .getClass().getSimpleName() }), e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public GExpr findGenerator(GimpleExpr expr) {
/*  99 */     if (expr instanceof GimpleSymbolRef) {
/* 100 */       GExpr variable = this.symbolTable.getVariable((GimpleSymbolRef)expr);
/* 101 */       if (variable == null) {
/* 102 */         throw new InternalCompilerException("No such variable: " + expr);
/*     */       }
/* 104 */       return variable;
/*     */     } 
/* 106 */     if (expr instanceof GimpleConstant) {
/* 107 */       return forConstant((GimpleConstant)expr);
/*     */     }
/* 109 */     if (expr instanceof GimpleConstructor) {
/* 110 */       return forConstructor((GimpleConstructor)expr);
/*     */     }
/* 112 */     if (expr instanceof GimpleNopExpr) {
/* 113 */       return findGenerator(((GimpleNopExpr)expr).getValue(), expr.getType());
/*     */     }
/* 115 */     if (expr instanceof GimpleAddressOf) {
/* 116 */       GimpleAddressOf addressOf = (GimpleAddressOf)expr;
/* 117 */       if (addressOf.getValue() instanceof GimpleFunctionRef) {
/* 118 */         GimpleFunctionRef functionRef = (GimpleFunctionRef)addressOf.getValue();
/* 119 */         return (GExpr)new FunPtrExpr(this.symbolTable.findHandle(functionRef));
/*     */       } 
/* 121 */       if (addressOf.getValue() instanceof GimplePrimitiveConstant) {
/*     */ 
/*     */ 
/*     */         
/* 125 */         JExpr jExpr = findPrimitiveGenerator(addressOf.getValue());
/* 126 */         PrimitiveType primitiveType = PrimitiveType.of((GimplePrimitiveType)addressOf.getValue().getType());
/* 127 */         return (GExpr)new FatPtrPair((ValueFunction)new PrimitiveValueFunction(primitiveType), 
/* 128 */             Expressions.newArray(primitiveType.jvmType(), Collections.singletonList(jExpr)));
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 133 */       if (addressOf.getValue() instanceof GimpleMemRef) {
/* 134 */         GimpleMemRef memRef = (GimpleMemRef)addressOf.getValue();
/* 135 */         if (memRef.isOffsetZero()) {
/* 136 */           return findGenerator(memRef.getPointer());
/*     */         }
/* 138 */         return pointerPlus(memRef.getPointer(), memRef.getOffset(), memRef.getPointer().getType());
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 143 */       GExpr value = findGenerator(addressOf.getValue());
/*     */       try {
/* 145 */         return value.addressOf();
/* 146 */       } catch (ClassCastException|UnsupportedOperationException ignored) {
/* 147 */         throw new InternalCompilerException(addressOf.getValue() + " [" + value.getClass().getName() + "] is not addressable");
/*     */       } 
/*     */     } 
/*     */     
/* 151 */     if (expr instanceof GimpleMemRef) {
/* 152 */       GimpleMemRef memRefExpr = (GimpleMemRef)expr;
/* 153 */       return memRef(memRefExpr, memRefExpr.getType());
/*     */     } 
/* 155 */     if (expr instanceof GimpleArrayRef) {
/* 156 */       GimpleArrayRef arrayRef = (GimpleArrayRef)expr;
/* 157 */       ArrayExpr array = (ArrayExpr)findGenerator(arrayRef.getArray());
/* 158 */       GExpr index = findGenerator(arrayRef.getIndex());
/* 159 */       JExpr jvmIndex = index.toPrimitiveExpr().toSignedInt(32).jexpr();
/*     */       
/* 161 */       return array.elementAt(expr.getType(), jvmIndex);
/*     */     } 
/* 163 */     if (expr instanceof GimpleConstantRef) {
/* 164 */       GimpleConstant constant = ((GimpleConstantRef)expr).getValue();
/* 165 */       JExpr constantValue = findPrimitiveGenerator((GimpleExpr)constant);
/* 166 */       PrimitiveType primitiveType = PrimitiveType.of((GimplePrimitiveType)constant.getType());
/*     */ 
/*     */       
/* 169 */       FatPtrPair address = new FatPtrPair((ValueFunction)new PrimitiveValueFunction(primitiveType), Expressions.newArray(primitiveType.jvmType(), Collections.singletonList(constantValue)));
/*     */       
/* 171 */       return (GExpr)PrimitiveType.of((GimplePrimitiveType)expr.getType()).fromStackValue(constantValue, (PtrExpr)address);
/*     */     } 
/* 173 */     if (expr instanceof GimpleComplexPartExpr) {
/* 174 */       GimpleExpr complexExpr = ((GimpleComplexPartExpr)expr).getComplexValue();
/* 175 */       ComplexExpr complexGenerator = (ComplexExpr)findGenerator(complexExpr);
/* 176 */       if (expr instanceof org.renjin.gcc.gimple.expr.GimpleRealPartExpr) {
/* 177 */         return (GExpr)complexGenerator.getRealGExpr();
/*     */       }
/* 179 */       return (GExpr)complexGenerator.getImaginaryGExpr();
/*     */     } 
/* 181 */     if (expr instanceof GimpleComponentRef) {
/* 182 */       GimpleComponentRef ref = (GimpleComponentRef)expr;
/*     */       
/* 184 */       VPtrRecordExpr vPtrRecordExpr = findGenerator(((GimpleComponentRef)expr).getValue()).toVPtrRecord((GimpleRecordType)ref.getValue().getType());
/*     */       
/* 186 */       return vPtrRecordExpr.memberOf(this.mv, ref.getMember().getOffset(), ref.getMember().getSize(), expr.getType());
/*     */     } 
/* 188 */     if (expr instanceof GimpleBitFieldRefExpr) {
/* 189 */       GimpleBitFieldRefExpr ref = (GimpleBitFieldRefExpr)expr;
/* 190 */       RecordExpr record = (RecordExpr)findGenerator(ref.getValue());
/*     */       
/* 192 */       return record.memberOf(this.mv, ref.getOffset(), ref.getSize(), expr.getType());
/*     */     } 
/* 194 */     if (expr instanceof GimpleCompoundLiteral) {
/* 195 */       return findGenerator((GimpleExpr)((GimpleCompoundLiteral)expr).getDecl());
/*     */     }
/* 197 */     if (expr instanceof GimpleObjectTypeRef) {
/* 198 */       GimpleObjectTypeRef typeRef = (GimpleObjectTypeRef)expr;
/*     */       
/* 200 */       return findGenerator(typeRef.getExpr());
/*     */     } 
/* 202 */     if (expr instanceof GimplePointerPlus) {
/* 203 */       GimplePointerPlus pointerPlus = (GimplePointerPlus)expr;
/* 204 */       return pointerPlus(pointerPlus.getPointer(), pointerPlus.getOffset(), pointerPlus.getType());
/*     */     } 
/*     */     
/* 207 */     throw new UnsupportedOperationException(expr + " [" + expr.getClass().getSimpleName() + "]");
/*     */   }
/*     */   
/*     */   private GExpr forConstructor(GimpleConstructor expr) {
/* 211 */     return this.typeOracle.forType(expr.getType()).constructorExpr(this, this.mv, expr);
/*     */   }
/*     */   
/*     */   public CallGenerator findCallGenerator(GimpleExpr functionExpr) {
/* 215 */     if (functionExpr instanceof GimpleAddressOf) {
/* 216 */       GimpleAddressOf addressOf = (GimpleAddressOf)functionExpr;
/* 217 */       if (addressOf.getValue() instanceof GimpleFunctionRef) {
/* 218 */         GimpleFunctionRef ref = (GimpleFunctionRef)addressOf.getValue();
/* 219 */         return this.symbolTable.findCallGenerator(ref);
/*     */       } 
/* 221 */       GimpleAddressOf address = (GimpleAddressOf)functionExpr;
/* 222 */       throw new UnsupportedOperationException("function ref: " + address.getValue() + " [" + address
/* 223 */           .getValue().getClass().getSimpleName() + "]");
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 228 */     FunPtrExpr expr = findGenerator(functionExpr).toFunPtr();
/* 229 */     return (CallGenerator)new FunPtrCallGenerator(this.typeOracle, (GimpleFunctionType)functionExpr.getType().getBaseType(), expr.jexpr());
/*     */   }
/*     */   
/*     */   public ConditionGenerator findConditionGenerator(GimpleOp op, List<GimpleExpr> operands) {
/* 233 */     if (operands.size() == 2) {
/* 234 */       return findComparisonGenerator(op, operands.get(0), operands.get(1));
/*     */     }
/* 236 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private ConditionGenerator findComparisonGenerator(GimpleOp op, GimpleExpr x, GimpleExpr y) {
/* 242 */     if (x.getType() instanceof org.renjin.gcc.gimple.type.GimpleComplexType) {
/* 243 */       return (ConditionGenerator)new ComplexCmpGenerator(op, findComplexGenerator(x), findComplexGenerator(y));
/*     */     }
/* 245 */     if (x.getType() instanceof GimplePrimitiveType) {
/* 246 */       return findGenerator(x).toPrimitiveExpr().compareTo(op, findGenerator(y));
/*     */     }
/* 248 */     if (x.getType() instanceof GimpleIndirectType) {
/* 249 */       return comparePointers(op, x, y);
/*     */     }
/*     */     
/* 252 */     throw new UnsupportedOperationException("Unsupported comparison " + op + " between types " + x
/* 253 */         .getType() + " and " + y.getType());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private ConditionGenerator comparePointers(GimpleOp op, GimpleExpr x, GimpleExpr y) {
/*     */     GimpleType commonType;
/* 260 */     if (isNull(x) && isNull(y)) {
/* 261 */       switch (op) {
/*     */         case EQ_EXPR:
/*     */         case GE_EXPR:
/*     */         case LE_EXPR:
/* 265 */           return (ConditionGenerator)new ConstConditionGenerator(true);
/*     */         case NE_EXPR:
/*     */         case LT_EXPR:
/*     */         case GT_EXPR:
/* 269 */           return (ConditionGenerator)new ConstConditionGenerator(false);
/*     */       } 
/* 271 */       throw new UnsupportedOperationException("op: " + op);
/*     */     } 
/* 273 */     if (isNull(x))
/* 274 */       return (ConditionGenerator)new NullCheckGenerator(op, (PtrExpr)findGenerator(y)); 
/* 275 */     if (isNull(y)) {
/* 276 */       return (ConditionGenerator)new NullCheckGenerator(op, (PtrExpr)findGenerator(x));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 283 */     if (x.getType().isPointerTo(GimpleVoidType.class)) {
/* 284 */       commonType = y.getType();
/*     */     } else {
/* 286 */       commonType = x.getType();
/*     */     } 
/*     */     
/* 289 */     PtrExpr ptrX = (PtrExpr)findGenerator(x, commonType);
/* 290 */     PtrExpr ptrY = (PtrExpr)findGenerator(y, commonType);
/*     */     
/* 292 */     return ptrX.comparePointer(this.mv, op, ptrY);
/*     */   }
/*     */   
/*     */   private boolean isNull(GimpleExpr expr) {
/* 296 */     return (expr instanceof GimpleConstant && ((GimpleConstant)expr).isNull());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public GExpr findGenerator(GimpleOp op, List<GimpleExpr> operands, GimpleType expectedType) {
/* 302 */     switch (op) {
/*     */       
/*     */       case NEGATE_EXPR:
/* 305 */         return (GExpr)findGenerator(operands.get(0)).toNumericExpr().negative();
/*     */       
/*     */       case BIT_NOT_EXPR:
/* 308 */         return findGenerator(operands.get(0)).toPrimitiveExpr().toIntExpr().bitwiseNot();
/*     */       
/*     */       case COMPLEX_EXPR:
/* 311 */         return (GExpr)new ComplexExpr(findPrimitiveGenerator(operands.get(0)));
/*     */       
/*     */       case PLUS_EXPR:
/*     */       case MINUS_EXPR:
/*     */       case MULT_EXPR:
/*     */       case RDIV_EXPR:
/*     */       case TRUNC_DIV_EXPR:
/*     */       case EXACT_DIV_EXPR:
/*     */       case TRUNC_MOD_EXPR:
/*     */       case BIT_IOR_EXPR:
/*     */       case BIT_XOR_EXPR:
/*     */       case BIT_AND_EXPR:
/*     */       case LSHIFT_EXPR:
/*     */       case RSHIFT_EXPR:
/*     */       case LROTATE_EXPR:
/* 326 */         return findBinaryGenerator(op, operands);
/*     */       
/*     */       case POINTER_PLUS_EXPR:
/* 329 */         return pointerPlus(operands.get(0), operands.get(1), expectedType);
/*     */ 
/*     */       
/*     */       case MEM_REF:
/* 333 */         return memRef((GimpleMemRef)operands.get(0), expectedType);
/*     */       
/*     */       case CONSTRUCTOR:
/*     */       case CONVERT_EXPR:
/*     */       case FIX_TRUNC_EXPR:
/*     */       case FLOAT_EXPR:
/*     */       case PAREN_EXPR:
/*     */       case VAR_DECL:
/*     */       case PARM_DECL:
/*     */       case NOP_EXPR:
/*     */       case INTEGER_CST:
/*     */       case REAL_CST:
/*     */       case STRING_CST:
/*     */       case COMPLEX_CST:
/*     */       case ADDR_EXPR:
/*     */       case ARRAY_REF:
/*     */       case COMPONENT_REF:
/*     */       case BIT_FIELD_REF:
/*     */       case REALPART_EXPR:
/*     */       case IMAGPART_EXPR:
/* 353 */         return maybeCast(findGenerator(operands.get(0)), expectedType, ((GimpleExpr)operands.get(0)).getType());
/*     */       
/*     */       case TRUTH_NOT_EXPR:
/* 356 */         return findGenerator(operands.get(0)).toPrimitiveExpr().toBooleanExpr().bitwiseNot();
/*     */       
/*     */       case TRUTH_AND_EXPR:
/* 359 */         return findGenerator(operands.get(0)).toPrimitiveExpr().toBooleanExpr().bitwiseAnd(findGenerator(operands.get(1)));
/*     */       
/*     */       case TRUTH_OR_EXPR:
/* 362 */         return findGenerator(operands.get(0)).toPrimitiveExpr().toBooleanExpr().bitwiseOr(findGenerator(operands.get(1)));
/*     */       
/*     */       case TRUTH_XOR_EXPR:
/* 365 */         return findGenerator(operands.get(0)).toPrimitiveExpr().toBooleanExpr().bitwiseXor(findGenerator(operands.get(1)));
/*     */       
/*     */       case EQ_EXPR:
/*     */       case GE_EXPR:
/*     */       case LE_EXPR:
/*     */       case NE_EXPR:
/*     */       case LT_EXPR:
/*     */       case GT_EXPR:
/*     */       case ORDERED_EXPR:
/*     */       case UNORDERED_EXPR:
/*     */       case UNEQ_EXPR:
/*     */       case UNLT_EXPR:
/*     */       case UNLE_EXPR:
/*     */       case UNGT_EXPR:
/*     */       case UNGE_EXPR:
/* 380 */         return booleanValue(findComparisonGenerator(op, operands.get(0), operands.get(1)));
/*     */       
/*     */       case MAX_EXPR:
/* 383 */         return (GExpr)findGenerator(operands.get(0)).toNumericExpr().max(findGenerator(operands.get(1)));
/*     */       
/*     */       case MIN_EXPR:
/* 386 */         return (GExpr)findGenerator(operands.get(0)).toNumericExpr().min(findGenerator(operands.get(1)));
/*     */ 
/*     */       
/*     */       case ABS_EXPR:
/* 390 */         return (GExpr)findGenerator(operands.get(0)).toNumericExpr().absoluteValue();
/*     */ 
/*     */       
/*     */       case CONJ_EXPR:
/* 394 */         return (GExpr)findComplexGenerator(operands.get(0)).conjugate();
/*     */     } 
/*     */ 
/*     */     
/* 398 */     throw new UnsupportedOperationException("op: " + op);
/*     */   }
/*     */   
/*     */   private GExpr findBinaryGenerator(GimpleOp op, List<GimpleExpr> operands) {
/*     */     PtrCarryingExpr ptrCarryingExpr;
/* 403 */     GExpr x = findGenerator(operands.get(0));
/* 404 */     GExpr y = findGenerator(operands.get(1));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 410 */     if (y instanceof PtrCarryingExpr && !(x instanceof PtrCarryingExpr) && x instanceof NumericIntExpr)
/*     */     {
/*     */ 
/*     */       
/* 414 */       ptrCarryingExpr = new PtrCarryingExpr((NumericIntExpr)x, ((PtrCarryingExpr)y).getPointerExpr());
/*     */     }
/*     */     
/* 417 */     switch (op) {
/*     */       case PLUS_EXPR:
/* 419 */         return (GExpr)ptrCarryingExpr.toNumericExpr().plus(y);
/*     */       
/*     */       case MINUS_EXPR:
/* 422 */         return (GExpr)ptrCarryingExpr.toNumericExpr().minus(y);
/*     */       
/*     */       case MULT_EXPR:
/* 425 */         return (GExpr)ptrCarryingExpr.toNumericExpr().multiply(y);
/*     */       
/*     */       case RDIV_EXPR:
/*     */       case TRUNC_DIV_EXPR:
/*     */       case EXACT_DIV_EXPR:
/* 430 */         return (GExpr)ptrCarryingExpr.toNumericExpr().divide(y);
/*     */       
/*     */       case TRUNC_MOD_EXPR:
/* 433 */         return (GExpr)ptrCarryingExpr.toPrimitiveExpr().toNumericExpr().remainder(y);
/*     */       
/*     */       case BIT_IOR_EXPR:
/* 436 */         return ptrCarryingExpr.toPrimitiveExpr().toIntExpr().bitwiseOr(y);
/*     */       
/*     */       case BIT_XOR_EXPR:
/* 439 */         return ptrCarryingExpr.toPrimitiveExpr().toIntExpr().bitwiseXor(y);
/*     */       
/*     */       case BIT_AND_EXPR:
/* 442 */         return ptrCarryingExpr.toPrimitiveExpr().toIntExpr().bitwiseAnd(y);
/*     */       
/*     */       case LSHIFT_EXPR:
/* 445 */         return ptrCarryingExpr.toPrimitiveExpr().toIntExpr().shiftLeft(y);
/*     */       
/*     */       case RSHIFT_EXPR:
/* 448 */         return ptrCarryingExpr.toPrimitiveExpr().toIntExpr().shiftRight(y);
/*     */       
/*     */       case LROTATE_EXPR:
/* 451 */         return ptrCarryingExpr.toPrimitiveExpr().toIntExpr().rotateLeft(y);
/*     */     } 
/*     */     
/* 454 */     return null;
/*     */   }
/*     */   
/*     */   private GExpr booleanValue(ConditionGenerator condition) {
/* 458 */     return (GExpr)new BooleanExpr(new ConditionExpr(condition));
/*     */   }
/*     */   
/*     */   private GExpr memRef(GimpleMemRef gimpleExpr, GimpleType expectedType) {
/* 462 */     GimpleExpr pointer = gimpleExpr.getPointer();
/*     */ 
/*     */     
/* 465 */     if (pointer instanceof GimpleAddressOf && gimpleExpr.isOffsetZero()) {
/* 466 */       GimpleAddressOf addressOf = (GimpleAddressOf)pointer;
/* 467 */       return findGenerator(addressOf.getValue());
/*     */     } 
/*     */     
/* 470 */     GimpleIndirectType pointerType = (GimpleIndirectType)pointer.getType();
/*     */     
/* 472 */     if (pointerType.getBaseType() instanceof GimpleVoidType)
/*     */     {
/* 474 */       return castThenDereference(gimpleExpr, expectedType);
/*     */     }
/*     */     
/* 477 */     return dereferenceThenCast(gimpleExpr, expectedType);
/*     */   }
/*     */ 
/*     */   
/*     */   private GExpr castThenDereference(GimpleMemRef gimpleExpr, GimpleType expectedType) {
/* 482 */     GimpleExpr pointer = gimpleExpr.getPointer();
/* 483 */     GimpleIndirectType pointerType = (GimpleIndirectType)pointer.getType();
/* 484 */     GimplePointerType gimplePointerType = expectedType.pointerTo();
/*     */ 
/*     */     
/* 487 */     PtrExpr ptrExpr = (PtrExpr)maybeCast(findGenerator(pointer), (GimpleType)gimplePointerType, (GimpleType)pointerType);
/*     */     
/* 489 */     if (!gimpleExpr.isOffsetZero()) {
/* 490 */       JExpr offsetInBytes = findPrimitiveGenerator(gimpleExpr.getOffset());
/*     */       
/* 492 */       ptrExpr = ptrExpr.pointerPlus(this.mv, offsetInBytes);
/*     */     } 
/*     */     
/* 495 */     return ptrExpr.valueOf(expectedType);
/*     */   }
/*     */   
/*     */   private GExpr dereferenceThenCast(GimpleMemRef gimpleExpr, GimpleType expectedType) {
/* 499 */     GimpleExpr pointer = gimpleExpr.getPointer();
/* 500 */     PtrExpr ptrExpr = (PtrExpr)findGenerator(pointer);
/*     */     
/* 502 */     if (!gimpleExpr.isOffsetZero()) {
/* 503 */       JExpr offsetInBytes = findPrimitiveGenerator(gimpleExpr.getOffset());
/* 504 */       ptrExpr = ptrExpr.pointerPlus(this.mv, offsetInBytes);
/*     */     } 
/*     */     
/* 507 */     return ptrExpr.valueOf(expectedType);
/*     */   }
/*     */   
/*     */   private GExpr pointerPlus(GimpleExpr pointerExpr, GimpleExpr offsetExpr, GimpleType expectedType) {
/* 511 */     PtrExpr pointer = (PtrExpr)findGenerator(pointerExpr);
/* 512 */     JExpr offsetInBytes = findPrimitiveGenerator(offsetExpr);
/*     */     
/* 514 */     GimpleType pointerType = pointerExpr.getType();
/* 515 */     GExpr result = pointer.pointerPlus(this.mv, offsetInBytes);
/*     */     
/* 517 */     return maybeCast(result, expectedType, pointerType);
/*     */   }
/*     */   
/*     */   private <T extends GExpr> T findGenerator(GimpleExpr gimpleExpr, Class<T> exprClass) {
/* 521 */     GExpr expr = findGenerator(gimpleExpr);
/* 522 */     if (exprClass.isAssignableFrom(expr.getClass())) {
/* 523 */       return exprClass.cast(expr);
/*     */     }
/* 525 */     throw new InternalCompilerException(String.format("Expected %s for expr %s, found: %s", new Object[] { exprClass
/* 526 */             .getSimpleName(), gimpleExpr, expr
/*     */             
/* 528 */             .getClass().getName() }));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JExpr findPrimitiveGenerator(GimpleExpr gimpleExpr) {
/* 534 */     if (gimpleExpr instanceof GimplePrimitiveConstant && gimpleExpr.getType() instanceof GimpleIndirectType) {
/* 535 */       return Expressions.constantInt(((GimplePrimitiveConstant)gimpleExpr).getValue().intValue());
/*     */     }
/* 537 */     PrimitiveExpr primitive = findGenerator(gimpleExpr, PrimitiveExpr.class);
/* 538 */     return primitive.jexpr();
/*     */   }
/*     */ 
/*     */   
/*     */   private ComplexExpr findComplexGenerator(GimpleExpr gimpleExpr) {
/* 543 */     return findGenerator(gimpleExpr, ComplexExpr.class);
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeStrategy strategyFor(GimpleType type) {
/* 548 */     return this.typeOracle.forType(type);
/*     */   }
/*     */ 
/*     */   
/*     */   public GExpr forConstant(GimpleConstant constant) {
/* 553 */     if (constant.getType() instanceof GimpleIndirectType) {
/* 554 */       JExpr pointer = Expressions.staticMethodCall(Type.getType(BytePtr.class), "of", 
/* 555 */           Type.getMethodDescriptor(Type.getType(Ptr.class), new Type[] { Type.INT_TYPE }), new JExpr[] {
/* 556 */             Expressions.constantInt(((GimpleIntegerConstant)constant).getValue().intValue())
/*     */           });
/* 558 */       return (GExpr)new VPtrExpr(pointer);
/*     */     } 
/*     */     
/* 561 */     if (constant instanceof GimplePrimitiveConstant) {
/*     */       
/* 563 */       GimplePrimitiveType gimplePrimitiveType = (GimplePrimitiveType)constant.getType();
/* 564 */       PrimitiveType primitiveType = PrimitiveType.of(gimplePrimitiveType);
/* 565 */       return primitiveType.constantExpr(constant);
/*     */     } 
/* 567 */     if (constant instanceof GimpleComplexConstant) {
/* 568 */       GimpleComplexConstant complexConstant = (GimpleComplexConstant)constant;
/* 569 */       return (GExpr)new ComplexExpr(
/* 570 */           forConstant((GimpleConstant)complexConstant.getReal()), 
/* 571 */           forConstant((GimpleConstant)complexConstant.getIm()));
/*     */     } 
/* 573 */     if (constant instanceof GimpleStringConstant) {
/* 574 */       StringConstant array = new StringConstant(((GimpleStringConstant)constant).getValue());
/* 575 */       return (GExpr)new FatArrayExpr((GimpleArrayType)constant
/* 576 */           .getType(), (ValueFunction)new PrimitiveValueFunction(PrimitiveType.UINT8), array
/*     */           
/* 578 */           .getLength(), (JExpr)array);
/*     */     } 
/*     */ 
/*     */     
/* 582 */     throw new UnsupportedOperationException("constant: " + constant);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/expr/ExprFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */