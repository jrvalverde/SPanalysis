package org.renjin.gcc.codegen.expr;

import org.renjin.gcc.codegen.MethodGenerator;
import org.renjin.gcc.codegen.condition.ConditionGenerator;
import org.renjin.gcc.gimple.GimpleOp;
import org.renjin.gcc.gimple.type.GimpleType;
import org.renjin.repackaged.asm.Label;

public interface PtrExpr extends GExpr {
  void jumpIfNull(MethodGenerator paramMethodGenerator, Label paramLabel);
  
  JExpr memoryCompare(MethodGenerator paramMethodGenerator, PtrExpr paramPtrExpr, JExpr paramJExpr);
  
  void memorySet(MethodGenerator paramMethodGenerator, JExpr paramJExpr1, JExpr paramJExpr2);
  
  void memoryCopy(MethodGenerator paramMethodGenerator, PtrExpr paramPtrExpr, JExpr paramJExpr, boolean paramBoolean);
  
  PtrExpr realloc(MethodGenerator paramMethodGenerator, JExpr paramJExpr);
  
  PtrExpr pointerPlus(MethodGenerator paramMethodGenerator, JExpr paramJExpr);
  
  GExpr valueOf(GimpleType paramGimpleType);
  
  ConditionGenerator comparePointer(MethodGenerator paramMethodGenerator, GimpleOp paramGimpleOp, GExpr paramGExpr);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/expr/PtrExpr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */