/*    */ package org.renjin.gcc.gimple.expr;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.function.Predicate;
/*    */ import org.renjin.gcc.gimple.GimpleExprVisitor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GimpleNopExpr
/*    */   extends GimpleExpr
/*    */ {
/*    */   private GimpleExpr value;
/*    */   
/*    */   public GimpleExpr getValue() {
/* 33 */     return this.value;
/*    */   }
/*    */   
/*    */   public void setValue(GimpleExpr value) {
/* 37 */     this.value = value;
/*    */   }
/*    */ 
/*    */   
/*    */   public void find(Predicate<? super GimpleExpr> predicate, List<GimpleExpr> results) {
/* 42 */     findOrDescend(this.value, predicate, results);
/*    */   }
/*    */ 
/*    */   
/*    */   public void replaceAll(Predicate<? super GimpleExpr> predicate, GimpleExpr newExpr) {
/* 47 */     this.value = replaceOrDescend(this.value, predicate, newExpr);
/*    */   }
/*    */ 
/*    */   
/*    */   public void accept(GimpleExprVisitor visitor) {
/* 52 */     visitor.visitNop(this);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 57 */     return this.value.toString();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/gimple/expr/GimpleNopExpr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */