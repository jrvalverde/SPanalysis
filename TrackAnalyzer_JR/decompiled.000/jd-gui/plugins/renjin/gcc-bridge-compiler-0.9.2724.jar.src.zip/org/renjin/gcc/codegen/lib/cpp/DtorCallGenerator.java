/*    */ package org.renjin.gcc.codegen.lib.cpp;
/*    */ 
/*    */ import org.renjin.gcc.codegen.MethodGenerator;
/*    */ import org.renjin.gcc.codegen.call.CallGenerator;
/*    */ import org.renjin.gcc.codegen.expr.ExprFactory;
/*    */ import org.renjin.gcc.gimple.expr.GimpleAddressOf;
/*    */ import org.renjin.gcc.gimple.expr.GimpleExpr;
/*    */ import org.renjin.gcc.gimple.expr.GimpleFunctionRef;
/*    */ import org.renjin.gcc.gimple.statement.GimpleCall;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DtorCallGenerator
/*    */   implements CallGenerator
/*    */ {
/*    */   public void emitCall(MethodGenerator mv, ExprFactory exprFactory, GimpleCall call) {
/* 40 */     GimpleFunctionRef baseConstructor = new GimpleFunctionRef();
/* 41 */     baseConstructor.setName("__base_dtor ");
/* 42 */     GimpleAddressOf functionExpr = new GimpleAddressOf();
/* 43 */     functionExpr.setValue((GimpleExpr)baseConstructor);
/* 44 */     CallGenerator baseCtorCallGenerator = exprFactory.findCallGenerator((GimpleExpr)functionExpr);
/* 45 */     baseCtorCallGenerator.emitCall(mv, exprFactory, call);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/lib/cpp/DtorCallGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */