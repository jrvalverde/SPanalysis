package org.renjin.gcc.codegen;

import java.io.IOException;
import org.renjin.gcc.codegen.type.TypeOracle;
import org.renjin.gcc.gimple.GimpleCompilationUnit;
import org.renjin.gcc.symbols.GlobalSymbolTable;
import org.renjin.gcc.symbols.SymbolTable;
import org.renjin.repackaged.asm.Type;

public interface CodeGenerationContext {
  TypeOracle getTypeOracle();
  
  GlobalSymbolTable getGlobalSymbolTable();
  
  SymbolTable getSymbolTable(GimpleCompilationUnit paramGimpleCompilationUnit);
  
  void writeClassFile(Type paramType, byte[] paramArrayOfbyte) throws IOException;
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/CodeGenerationContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */