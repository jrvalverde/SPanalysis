/*    */ package org.renjin.gcc.codegen.fatptr;
/*    */ 
/*    */ import javax.annotation.Nonnull;
/*    */ import org.renjin.gcc.codegen.MethodGenerator;
/*    */ import org.renjin.gcc.codegen.expr.JExpr;
/*    */ import org.renjin.gcc.runtime.Realloc;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FatPtrRealloc
/*    */   implements JExpr
/*    */ {
/*    */   private FatPtrPair pointer;
/*    */   private JExpr newLength;
/*    */   private Type arrayType;
/*    */   
/*    */   public FatPtrRealloc(FatPtrPair pointer, JExpr newLength) {
/* 38 */     this.pointer = pointer;
/* 39 */     this.newLength = newLength;
/* 40 */     this.arrayType = pointer.getArray().getType();
/*    */   }
/*    */ 
/*    */   
/*    */   @Nonnull
/*    */   public Type getType() {
/* 46 */     return this.arrayType;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void load(@Nonnull MethodGenerator mv) {
/* 52 */     this.pointer.getArray().load(mv);
/* 53 */     this.pointer.getOffset().load(mv);
/* 54 */     this.newLength.load(mv);
/*    */     
/* 56 */     mv.invokestatic(Realloc.class, "realloc", Type.getMethodDescriptor(this.arrayType, new Type[] { this.arrayType, Type.INT_TYPE, Type.INT_TYPE }));
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/fatptr/FatPtrRealloc.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */