/*     */ package org.renjin.gcc.codegen.type.primitive;
/*     */ 
/*     */ import org.renjin.gcc.codegen.MethodGenerator;
/*     */ import org.renjin.gcc.codegen.array.FatArrayExpr;
/*     */ import org.renjin.gcc.codegen.condition.ConditionGenerator;
/*     */ import org.renjin.gcc.codegen.expr.Expressions;
/*     */ import org.renjin.gcc.codegen.expr.GExpr;
/*     */ import org.renjin.gcc.codegen.expr.JExpr;
/*     */ import org.renjin.gcc.codegen.expr.JLValue;
/*     */ import org.renjin.gcc.codegen.expr.PtrExpr;
/*     */ import org.renjin.gcc.codegen.fatptr.FatPtr;
/*     */ import org.renjin.gcc.codegen.fatptr.ValueFunction;
/*     */ import org.renjin.gcc.codegen.type.NumericExpr;
/*     */ import org.renjin.gcc.codegen.type.UnsupportedCastException;
/*     */ import org.renjin.gcc.codegen.type.complex.ComplexExpr;
/*     */ import org.renjin.gcc.codegen.type.fun.FunPtrExpr;
/*     */ import org.renjin.gcc.codegen.type.record.ProvidedPtrExpr;
/*     */ import org.renjin.gcc.codegen.type.voidt.VoidPtrExpr;
/*     */ import org.renjin.gcc.codegen.vptr.VArrayExpr;
/*     */ import org.renjin.gcc.codegen.vptr.VPtrExpr;
/*     */ import org.renjin.gcc.codegen.vptr.VPtrRecordExpr;
/*     */ import org.renjin.gcc.gimple.GimpleOp;
/*     */ import org.renjin.gcc.gimple.type.GimpleArrayType;
/*     */ import org.renjin.gcc.gimple.type.GimplePrimitiveType;
/*     */ import org.renjin.gcc.gimple.type.GimpleRecordType;
/*     */ import org.renjin.gcc.runtime.Ptr;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PtrCarryingExpr
/*     */   implements NumericIntExpr
/*     */ {
/*     */   private NumericIntExpr primitive;
/*     */   private final JExpr pointerExpr;
/*     */   
/*     */   public PtrCarryingExpr(NumericIntExpr primitive, JExpr pointerExpr) {
/*  49 */     this.primitive = primitive;
/*  50 */     this.pointerExpr = pointerExpr;
/*     */   }
/*     */   
/*     */   public JExpr getPointerExpr() {
/*  54 */     return this.pointerExpr;
/*     */   }
/*     */ 
/*     */   
/*     */   public GimplePrimitiveType getType() {
/*  59 */     return this.primitive.getType();
/*     */   }
/*     */ 
/*     */   
/*     */   public IntExpr toIntExpr() {
/*  64 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public PtrCarryingExpr plus(GExpr operand) {
/*  69 */     return new PtrCarryingExpr(this.primitive.plus(operand), this.pointerExpr);
/*     */   }
/*     */ 
/*     */   
/*     */   public PtrCarryingExpr minus(GExpr operand) {
/*  74 */     return new PtrCarryingExpr(this.primitive.minus(operand), this.pointerExpr);
/*     */   }
/*     */ 
/*     */   
/*     */   public PtrCarryingExpr multiply(GExpr operand) {
/*  79 */     return new PtrCarryingExpr(this.primitive.multiply(operand), this.pointerExpr);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public NumericExpr divide(GExpr operand) {
/*  85 */     return this.primitive.divide(operand);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public NumericExpr remainder(GExpr operand) {
/*  91 */     return this.primitive.remainder(operand);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public NumericExpr negative() {
/*  97 */     return this.primitive.negative();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NumericExpr min(GExpr operand) {
/* 105 */     return this.primitive.min(operand);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NumericExpr max(GExpr operand) {
/* 113 */     return this.primitive.max(operand);
/*     */   }
/*     */ 
/*     */   
/*     */   public NumericIntExpr absoluteValue() {
/* 118 */     return new PtrCarryingExpr(this.primitive.absoluteValue(), this.pointerExpr);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ComplexExpr toComplexExpr() {
/* 124 */     return this.primitive.toComplexExpr();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public RealExpr toRealExpr() {
/* 130 */     return this.primitive.toRealExpr();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public BooleanExpr toBooleanExpr() {
/* 136 */     return this.primitive.toBooleanExpr();
/*     */   }
/*     */ 
/*     */   
/*     */   public JExpr jexpr() {
/* 141 */     return this.primitive.jexpr();
/*     */   }
/*     */ 
/*     */   
/*     */   public ConditionGenerator compareTo(GimpleOp op, GExpr generator) {
/* 146 */     return this.primitive.compareTo(op, generator);
/*     */   }
/*     */ 
/*     */   
/*     */   public PtrExpr addressOfReadOnly() {
/* 151 */     return this.primitive.addressOfReadOnly();
/*     */   }
/*     */ 
/*     */   
/*     */   public NumericIntExpr bitwiseXor(GExpr operand) {
/* 156 */     return new PtrCarryingExpr(this.primitive.bitwiseXor(operand), this.pointerExpr);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public NumericIntExpr bitwiseNot() {
/* 162 */     return this.primitive.bitwiseNot();
/*     */   }
/*     */ 
/*     */   
/*     */   public NumericIntExpr bitwiseAnd(GExpr operand) {
/* 167 */     return new PtrCarryingExpr(this.primitive.bitwiseAnd(operand), this.pointerExpr);
/*     */   }
/*     */ 
/*     */   
/*     */   public NumericIntExpr bitwiseOr(GExpr operand) {
/* 172 */     return new PtrCarryingExpr(this.primitive.bitwiseOr(operand), this.pointerExpr);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public GExpr shiftLeft(GExpr operand) {
/* 178 */     return this.primitive.shiftLeft(operand);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public GExpr shiftRight(GExpr operand) {
/* 184 */     return this.primitive.shiftRight(operand);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public GExpr rotateLeft(GExpr operand) {
/* 190 */     return this.primitive.rotateLeft(operand);
/*     */   }
/*     */ 
/*     */   
/*     */   public IntExpr toSignedInt(int precision) {
/* 195 */     if (precision < 32)
/*     */     {
/* 197 */       return this.primitive.toSignedInt(precision);
/*     */     }
/* 199 */     return new PtrCarryingExpr((NumericIntExpr)this.primitive.toSignedInt(precision), this.pointerExpr);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IntExpr toUnsignedInt(int precision) {
/* 205 */     if (precision < 32)
/*     */     {
/* 207 */       return this.primitive.toSignedInt(precision);
/*     */     }
/* 209 */     return new PtrCarryingExpr((NumericIntExpr)this.primitive.toSignedInt(precision), this.pointerExpr);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RealExpr toReal(int precision) {
/* 216 */     return this.primitive.toReal(precision);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void store(MethodGenerator mv, GExpr rhs) {
/* 222 */     PrimitiveExpr primitiveRhs = rhs.toPrimitiveExpr();
/* 223 */     if (primitiveRhs instanceof PtrCarryingExpr) {
/*     */ 
/*     */       
/* 226 */       PtrCarryingExpr ptrCarryingRhs = (PtrCarryingExpr)primitiveRhs;
/* 227 */       this.primitive.store(mv, ptrCarryingRhs.primitive);
/* 228 */       ((JLValue)this.pointerExpr).store(mv, ptrCarryingRhs.pointerExpr);
/*     */     }
/*     */     else {
/*     */       
/* 232 */       this.primitive.store(mv, primitiveRhs);
/* 233 */       ((JLValue)this.pointerExpr).store(mv, Expressions.nullRef(Type.getType(Ptr.class)));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public PtrExpr addressOf() {
/* 240 */     return this.primitive.addressOf();
/*     */   }
/*     */ 
/*     */   
/*     */   public FunPtrExpr toFunPtr() throws UnsupportedCastException {
/* 245 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public FatArrayExpr toArrayExpr() throws UnsupportedCastException {
/* 250 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public PrimitiveExpr toPrimitiveExpr() throws UnsupportedCastException {
/* 255 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public VoidPtrExpr toVoidPtrExpr() throws UnsupportedCastException {
/* 260 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public VPtrExpr toVPtrExpr() throws UnsupportedCastException {
/* 265 */     return new VPtrExpr(Expressions.methodCall(this.pointerExpr, Ptr.class, "withOffset", 
/* 266 */           Type.getMethodDescriptor(Type.getType(Ptr.class), new Type[] { Type.INT_TYPE }), new JExpr[] { this.primitive.toUnsignedInt(32).jexpr() }));
/*     */   }
/*     */ 
/*     */   
/*     */   public ProvidedPtrExpr toProvidedPtrExpr(Type jvmType) {
/* 271 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public FatPtr toFatPtrExpr(ValueFunction valueFunction) {
/* 276 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public VPtrRecordExpr toVPtrRecord(GimpleRecordType recordType) {
/* 281 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public VArrayExpr toVArray(GimpleArrayType arrayType) {
/* 286 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public NumericExpr toNumericExpr() {
/* 291 */     return this;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/type/primitive/PtrCarryingExpr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */