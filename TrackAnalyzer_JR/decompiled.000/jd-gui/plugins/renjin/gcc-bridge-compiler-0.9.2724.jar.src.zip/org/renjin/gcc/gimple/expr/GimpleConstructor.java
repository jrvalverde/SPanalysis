/*     */ package org.renjin.gcc.gimple.expr;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.function.Predicate;
/*     */ import org.renjin.gcc.gimple.GimpleExprVisitor;
/*     */ import org.renjin.repackaged.guava.base.Joiner;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GimpleConstructor
/*     */   extends GimpleExpr
/*     */ {
/*     */   public static class Element
/*     */   {
/*     */     private GimpleExpr field;
/*     */     private GimpleExpr value;
/*     */     
/*     */     public GimpleExpr getField() {
/*  40 */       return this.field;
/*     */     }
/*     */     
/*     */     public String getFieldName() {
/*  44 */       return ((GimpleFieldRef)this.field).getName();
/*     */     }
/*     */     
/*     */     public void setField(GimpleExpr field) {
/*  48 */       this.field = field;
/*     */     }
/*     */     
/*     */     public GimpleExpr getValue() {
/*  52 */       return this.value;
/*     */     }
/*     */     
/*     */     public void setValue(GimpleExpr value) {
/*  56 */       this.value = value;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/*  61 */       if (this.field == null) {
/*  62 */         return this.value.toString();
/*     */       }
/*  64 */       return this.field + " = " + this.value;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*  69 */   private List<Element> elements = new ArrayList<>();
/*     */   private boolean clobber;
/*     */   
/*     */   public List<Element> getElements() {
/*  73 */     return this.elements;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isClobber() {
/*  78 */     return this.clobber;
/*     */   }
/*     */   
/*     */   public void setClobber(boolean clobber) {
/*  82 */     this.clobber = clobber;
/*     */   }
/*     */   
/*     */   public <X extends GimpleExpr> X getElement(int i) {
/*  86 */     return (X)((Element)this.elements.get(i)).getValue();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void replaceAll(Predicate<? super GimpleExpr> predicate, GimpleExpr newExpr) {
/*  92 */     for (Element element : this.elements) {
/*  93 */       element.value = replaceOrDescend(element.value, predicate, newExpr);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void accept(GimpleExprVisitor visitor) {
/*  99 */     visitor.visitConstructor(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 104 */     return "{" + Joiner.on(", ").join(this.elements) + "}";
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/gimple/expr/GimpleConstructor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */