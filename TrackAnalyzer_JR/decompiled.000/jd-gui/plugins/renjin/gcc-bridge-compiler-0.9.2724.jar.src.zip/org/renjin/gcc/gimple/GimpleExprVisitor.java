/*     */ package org.renjin.gcc.gimple;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.renjin.gcc.gimple.expr.GimpleAddressOf;
/*     */ import org.renjin.gcc.gimple.expr.GimpleArrayRef;
/*     */ import org.renjin.gcc.gimple.expr.GimpleBitFieldRefExpr;
/*     */ import org.renjin.gcc.gimple.expr.GimpleComplexConstant;
/*     */ import org.renjin.gcc.gimple.expr.GimpleComplexPartExpr;
/*     */ import org.renjin.gcc.gimple.expr.GimpleComponentRef;
/*     */ import org.renjin.gcc.gimple.expr.GimpleCompoundLiteral;
/*     */ import org.renjin.gcc.gimple.expr.GimpleConstantRef;
/*     */ import org.renjin.gcc.gimple.expr.GimpleConstructor;
/*     */ import org.renjin.gcc.gimple.expr.GimpleExpr;
/*     */ import org.renjin.gcc.gimple.expr.GimpleFieldRef;
/*     */ import org.renjin.gcc.gimple.expr.GimpleFunctionRef;
/*     */ import org.renjin.gcc.gimple.expr.GimpleMemRef;
/*     */ import org.renjin.gcc.gimple.expr.GimpleNopExpr;
/*     */ import org.renjin.gcc.gimple.expr.GimpleObjectTypeRef;
/*     */ import org.renjin.gcc.gimple.expr.GimpleParamRef;
/*     */ import org.renjin.gcc.gimple.expr.GimplePointerPlus;
/*     */ import org.renjin.gcc.gimple.expr.GimplePrimitiveConstant;
/*     */ import org.renjin.gcc.gimple.expr.GimpleResultDecl;
/*     */ import org.renjin.gcc.gimple.expr.GimpleSsaName;
/*     */ import org.renjin.gcc.gimple.expr.GimpleStringConstant;
/*     */ import org.renjin.gcc.gimple.expr.GimpleVariableRef;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GimpleExprVisitor
/*     */ {
/*     */   public void visit(GimpleExpr expr) {}
/*     */   
/*     */   public void visitAddressOf(GimpleAddressOf addressOf) {
/*  35 */     visit((GimpleExpr)addressOf);
/*  36 */     addressOf.getValue().accept(this);
/*     */   }
/*     */   
/*     */   public void visitArrayRef(GimpleArrayRef arrayRef) {
/*  40 */     visit((GimpleExpr)arrayRef);
/*  41 */     arrayRef.getArray().accept(this);
/*  42 */     arrayRef.getIndex().accept(this);
/*     */   }
/*     */   
/*     */   public void visitBitFieldRef(GimpleBitFieldRefExpr bitFieldRef) {
/*  46 */     visit((GimpleExpr)bitFieldRef);
/*     */   }
/*     */   
/*     */   public void visitComplexConstant(GimpleComplexConstant constant) {
/*  50 */     visit((GimpleExpr)constant);
/*  51 */     constant.getReal().accept(this);
/*  52 */     constant.getIm().accept(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitComplexPart(GimpleComplexPartExpr complexPart) {
/*  57 */     visit((GimpleExpr)complexPart);
/*  58 */     complexPart.getComplexValue().accept(this);
/*     */   }
/*     */   
/*     */   public void visitComponentRef(GimpleComponentRef componentRef) {
/*  62 */     visit((GimpleExpr)componentRef);
/*  63 */     componentRef.getValue().accept(this);
/*  64 */     componentRef.getMember().accept(this);
/*     */   }
/*     */   
/*     */   public void visitCompoundLiteral(GimpleCompoundLiteral compoundLiteral) {
/*  68 */     visit((GimpleExpr)compoundLiteral);
/*  69 */     compoundLiteral.getDecl().accept(this);
/*     */   }
/*     */   
/*     */   public void visitConstantRef(GimpleConstantRef constantRef) {
/*  73 */     visit((GimpleExpr)constantRef);
/*  74 */     constantRef.getValue().accept(this);
/*     */   }
/*     */   
/*     */   public void visitConstructor(GimpleConstructor constructor) {
/*  78 */     visit((GimpleExpr)constructor);
/*  79 */     for (GimpleConstructor.Element element : constructor.getElements()) {
/*  80 */       element.getValue().accept(this);
/*     */     }
/*     */   }
/*     */   
/*     */   public void visitFieldRef(GimpleFieldRef fieldRef) {
/*  85 */     visit((GimpleExpr)fieldRef);
/*     */   }
/*     */   
/*     */   public void visitFunctionRef(GimpleFunctionRef functionRef) {
/*  89 */     visit((GimpleExpr)functionRef);
/*     */   }
/*     */   
/*     */   public void visitPrimitiveConstant(GimplePrimitiveConstant constant) {
/*  93 */     visit((GimpleExpr)constant);
/*     */   }
/*     */   
/*     */   public void visitMemRef(GimpleMemRef memRef) {
/*  97 */     memRef.getPointer().accept(this);
/*  98 */     if (memRef.getOffset() != null) {
/*  99 */       memRef.getOffset().accept(this);
/*     */     }
/*     */   }
/*     */   
/*     */   public void visitNop(GimpleNopExpr expr) {
/* 104 */     expr.getValue().accept(this);
/*     */   }
/*     */   
/*     */   public void visitObjectTypeRef(GimpleObjectTypeRef objectTypeRef) {
/* 108 */     objectTypeRef.getExpr().accept(this);
/* 109 */     objectTypeRef.getObject().accept(this);
/* 110 */     objectTypeRef.getToken().accept(this);
/*     */   }
/*     */   
/*     */   public void visitParamRef(GimpleParamRef paramRef) {
/* 114 */     visit((GimpleExpr)paramRef);
/*     */   }
/*     */   
/*     */   public void visitPointerPlus(GimplePointerPlus pointerPlus) {
/* 118 */     visit((GimpleExpr)pointerPlus);
/* 119 */     pointerPlus.getPointer().accept(this);
/* 120 */     pointerPlus.getOffset().accept(this);
/*     */   }
/*     */   
/*     */   public void visitResultDecl(GimpleResultDecl resultDecl) {
/* 124 */     visit((GimpleExpr)resultDecl);
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitSsaName(GimpleSsaName ssaName) {
/* 129 */     visit((GimpleExpr)ssaName);
/*     */   }
/*     */   
/*     */   public void visitStringConstant(GimpleStringConstant stringConstant) {
/* 133 */     visit((GimpleExpr)stringConstant);
/*     */   }
/*     */   
/*     */   public void visitVariableRef(GimpleVariableRef variableRef) {
/* 137 */     visit((GimpleExpr)variableRef);
/*     */   }
/*     */   
/*     */   public void visit(List<GimpleCompilationUnit> units) {
/* 141 */     for (GimpleCompilationUnit unit : units)
/* 142 */       unit.accept(this); 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/gimple/GimpleExprVisitor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */