/*    */ package org.renjin.gcc.codegen.type.primitive;
/*    */ 
/*    */ import org.renjin.gcc.codegen.expr.GExpr;
/*    */ import org.renjin.gcc.codegen.expr.JExpr;
/*    */ import org.renjin.gcc.codegen.expr.PtrExpr;
/*    */ import org.renjin.gcc.codegen.type.NumericExpr;
/*    */ import org.renjin.gcc.codegen.type.complex.ComplexExpr;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractIntExpr
/*    */   extends AbstractPrimitiveExpr
/*    */   implements NumericIntExpr
/*    */ {
/*    */   protected AbstractIntExpr(JExpr expr, PtrExpr address) {
/* 31 */     super(expr, address);
/*    */   }
/*    */ 
/*    */   
/*    */   public final NumericExpr toNumericExpr() {
/* 36 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public final IntExpr toIntExpr() {
/* 41 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public final ComplexExpr toComplexExpr() {
/* 46 */     return toRealExpr().toComplexExpr();
/*    */   }
/*    */ 
/*    */   
/*    */   protected static JExpr bits(GExpr operand) {
/* 51 */     return operand.toPrimitiveExpr().toSignedInt(32).jexpr();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/type/primitive/AbstractIntExpr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */