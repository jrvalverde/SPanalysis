/*     */ package org.renjin.gcc.gimple.type;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.renjin.gcc.gimple.expr.GimpleFieldRef;
/*     */ import org.renjin.repackaged.guava.collect.Lists;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GimpleRecordTypeDef
/*     */ {
/*     */   private String id;
/*     */   private String name;
/*     */   private boolean union;
/*     */   private int size;
/*  33 */   private List<GimpleField> fields = Lists.newArrayList();
/*     */ 
/*     */   
/*     */   public String getId() {
/*  37 */     return this.id;
/*     */   }
/*     */   
/*     */   public void setId(String id) {
/*  41 */     this.id = id;
/*     */   }
/*     */   
/*     */   public void setName(String name) {
/*  45 */     this.name = name;
/*     */   }
/*     */   
/*     */   public String getName() {
/*  49 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isUnion() {
/*  57 */     return this.union;
/*     */   }
/*     */   
/*     */   public void setUnion(boolean union) {
/*  61 */     this.union = union;
/*     */   }
/*     */   
/*     */   public List<GimpleField> getFields() {
/*  65 */     return this.fields;
/*     */   }
/*     */   
/*     */   public int getSize() {
/*  69 */     return this.size;
/*     */   }
/*     */   
/*     */   public void setSize(int size) {
/*  73 */     this.size = size;
/*     */   }
/*     */   
/*     */   public String debugName() {
/*  77 */     StringBuilder s = new StringBuilder();
/*  78 */     if (this.name == null) {
/*  79 */       s.append("ANONYMOUS");
/*     */     } else {
/*  81 */       s.append(this.name);
/*     */     } 
/*  83 */     s.append(" ").append("[").append(this.id).append("]");
/*  84 */     return s.toString();
/*     */   }
/*     */   
/*     */   public String toString() {
/*  88 */     StringBuilder out = new StringBuilder();
/*  89 */     out.append("struct ").append(this.name).append("[").append(this.id).append("]").append(" {\n");
/*  90 */     for (GimpleField field : this.fields) {
/*  91 */       out.append(String.format("    %2d: %s %s\n", new Object[] { Integer.valueOf(field.getOffset()), field.getType(), field.getName() }));
/*     */     } 
/*  93 */     out.append("}");
/*  94 */     return out.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public GimpleField findField(GimpleFieldRef fieldRef) {
/* 100 */     for (GimpleField field : this.fields) {
/* 101 */       if (field.hasName() && field.getName().equals(fieldRef.getName())) {
/* 102 */         return field;
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 108 */     for (GimpleField field : this.fields) {
/* 109 */       int fieldStart = field.getOffset();
/* 110 */       int fieldEnd = fieldStart + field.getType().getSize();
/* 111 */       if (fieldRef.getOffset() >= fieldStart && fieldRef
/* 112 */         .getOffset() < fieldEnd) {
/* 113 */         return field;
/*     */       }
/*     */     } 
/*     */     
/* 117 */     throw new IllegalArgumentException("No such field: " + fieldRef.getName());
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/gimple/type/GimpleRecordTypeDef.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */