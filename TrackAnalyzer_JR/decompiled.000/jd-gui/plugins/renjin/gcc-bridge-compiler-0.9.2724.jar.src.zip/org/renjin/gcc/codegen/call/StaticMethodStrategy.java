/*    */ package org.renjin.gcc.codegen.call;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.List;
/*    */ import org.renjin.gcc.codegen.MethodGenerator;
/*    */ import org.renjin.gcc.codegen.type.JvmVarArgsStrategy;
/*    */ import org.renjin.gcc.codegen.type.NullVariadicStrategy;
/*    */ import org.renjin.gcc.codegen.type.ParamStrategy;
/*    */ import org.renjin.gcc.codegen.type.ReturnStrategy;
/*    */ import org.renjin.gcc.codegen.type.TypeOracle;
/*    */ import org.renjin.gcc.codegen.type.VariadicStrategy;
/*    */ import org.renjin.gcc.codegen.vptr.VPtrVariadicStrategy;
/*    */ import org.renjin.repackaged.asm.Handle;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StaticMethodStrategy
/*    */   implements InvocationStrategy
/*    */ {
/*    */   private final TypeOracle typeOracle;
/*    */   private Method method;
/*    */   private List<ParamStrategy> paramStrategies;
/*    */   private ReturnStrategy returnStrategy;
/*    */   
/*    */   public StaticMethodStrategy(TypeOracle typeOracle, Method method) {
/* 50 */     this.typeOracle = typeOracle;
/* 51 */     this.method = method;
/*    */   }
/*    */ 
/*    */   
/*    */   public Handle getMethodHandle() {
/* 56 */     return new Handle(6, Type.getInternalName(this.method.getDeclaringClass()), this.method
/* 57 */         .getName(), Type.getMethodDescriptor(this.method));
/*    */   }
/*    */ 
/*    */   
/*    */   public List<ParamStrategy> getParamStrategies() {
/* 62 */     if (this.paramStrategies == null) {
/* 63 */       this.paramStrategies = this.typeOracle.forParameterTypesOf(this.method);
/*    */     }
/* 65 */     return this.paramStrategies;
/*    */   }
/*    */ 
/*    */   
/*    */   public VariadicStrategy getVariadicStrategy() {
/* 70 */     if (this.method.isVarArgs())
/* 71 */       return (VariadicStrategy)new JvmVarArgsStrategy(); 
/* 72 */     if (VPtrVariadicStrategy.hasVarArgsPtr(this.method)) {
/* 73 */       return (VariadicStrategy)new VPtrVariadicStrategy();
/*    */     }
/* 75 */     return (VariadicStrategy)new NullVariadicStrategy();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ReturnStrategy getReturnStrategy() {
/* 82 */     if (this.returnStrategy == null) {
/* 83 */       this.returnStrategy = this.typeOracle.forReturnValue(this.method);
/*    */     }
/* 85 */     return this.returnStrategy;
/*    */   }
/*    */ 
/*    */   
/*    */   public void invoke(MethodGenerator mv) {
/* 90 */     mv.invokestatic(this.method.getDeclaringClass(), this.method.getName(), Type.getMethodDescriptor(this.method));
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/call/StaticMethodStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */