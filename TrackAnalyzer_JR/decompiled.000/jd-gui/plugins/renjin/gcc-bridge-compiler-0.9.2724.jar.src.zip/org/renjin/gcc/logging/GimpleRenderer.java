/*     */ package org.renjin.gcc.logging;
/*     */ import java.util.List;
/*     */ import org.renjin.gcc.codegen.FunctionGenerator;
/*     */ import org.renjin.gcc.codegen.call.CallGenerator;
/*     */ import org.renjin.gcc.codegen.call.FunctionCallGenerator;
/*     */ import org.renjin.gcc.gimple.GimpleFunction;
/*     */ import org.renjin.gcc.gimple.GimpleOp;
/*     */ import org.renjin.gcc.gimple.GimpleParameter;
/*     */ import org.renjin.gcc.gimple.GimpleVarDecl;
/*     */ import org.renjin.gcc.gimple.expr.GimpleArrayRef;
/*     */ import org.renjin.gcc.gimple.expr.GimpleBitFieldRefExpr;
/*     */ import org.renjin.gcc.gimple.expr.GimpleComplexConstant;
/*     */ import org.renjin.gcc.gimple.expr.GimpleComponentRef;
/*     */ import org.renjin.gcc.gimple.expr.GimpleCompoundLiteral;
/*     */ import org.renjin.gcc.gimple.expr.GimpleConstantRef;
/*     */ import org.renjin.gcc.gimple.expr.GimpleConstructor;
/*     */ import org.renjin.gcc.gimple.expr.GimpleExpr;
/*     */ import org.renjin.gcc.gimple.expr.GimpleFunctionRef;
/*     */ import org.renjin.gcc.gimple.expr.GimpleMemRef;
/*     */ import org.renjin.gcc.gimple.expr.GimpleNopExpr;
/*     */ import org.renjin.gcc.gimple.expr.GimplePointerPlus;
/*     */ import org.renjin.gcc.gimple.expr.GimplePrimitiveConstant;
/*     */ import org.renjin.gcc.gimple.expr.GimpleSsaName;
/*     */ import org.renjin.gcc.gimple.expr.GimpleStringConstant;
/*     */ import org.renjin.gcc.gimple.statement.GimpleAssignment;
/*     */ import org.renjin.gcc.gimple.statement.GimpleCall;
/*     */ import org.renjin.gcc.gimple.statement.GimpleConditional;
/*     */ import org.renjin.gcc.gimple.statement.GimpleReturn;
/*     */ import org.renjin.gcc.gimple.statement.GimpleStatement;
/*     */ import org.renjin.gcc.gimple.type.GimpleArrayType;
/*     */ import org.renjin.gcc.gimple.type.GimpleField;
/*     */ import org.renjin.gcc.gimple.type.GimpleRecordType;
/*     */ import org.renjin.gcc.gimple.type.GimpleRecordTypeDef;
/*     */ import org.renjin.gcc.gimple.type.GimpleType;
/*     */ import org.renjin.repackaged.guava.html.HtmlEscapers;
/*     */ 
/*     */ public class GimpleRenderer {
/*  38 */   private final StringBuilder html = new StringBuilder();
/*     */   private SymbolTable symbolTable;
/*     */   private final Map<String, GimpleRecordTypeDef> typedefMap;
/*  41 */   private final Map<String, String> recordNameMap = new HashMap<>();
/*     */   
/*     */   public GimpleRenderer(SymbolTable symbolTable, GimpleCompilationUnit unit) {
/*  44 */     this.symbolTable = symbolTable;
/*     */     
/*  46 */     this.typedefMap = new HashMap<>();
/*  47 */     for (GimpleRecordTypeDef recordTypeDef : unit.getRecordTypes()) {
/*  48 */       this.typedefMap.put(recordTypeDef.getId(), recordTypeDef);
/*     */     }
/*     */     
/*  51 */     abbreviateIds();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void abbreviateIds() {
/*  57 */     for (GimpleRecordTypeDef typeDef : this.typedefMap.values()) {
/*  58 */       if (typeDef.getName() != null) {
/*  59 */         this.recordNameMap.put(typeDef.getId(), typeDef.getName()); continue;
/*     */       } 
/*  61 */       int abbrLength = 4;
/*  62 */       while (!uniqueEnough(typeDef.getId(), abbrLength)) {
/*  63 */         abbrLength++;
/*     */       }
/*     */       
/*  66 */       this.recordNameMap.put(typeDef.getId(), "anonymous_" + typeDef
/*  67 */           .getId().substring(typeDef.getId().length() - abbrLength));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean uniqueEnough(String id, int length) {
/*  74 */     if (id.length() <= length) {
/*  75 */       return true;
/*     */     }
/*     */     
/*  78 */     String abbr = id.substring(id.length() - length);
/*     */     
/*  80 */     for (String otherId : this.typedefMap.keySet()) {
/*  81 */       if (!id.equals(otherId) && otherId.endsWith(abbr)) {
/*  82 */         return false;
/*     */       }
/*     */     } 
/*  85 */     return true;
/*     */   }
/*     */   
/*     */   private void appendEscaped(String text) {
/*  89 */     this.html.append(HtmlEscapers.htmlEscaper().escape(text));
/*     */   }
/*     */   
/*     */   private void appendHtml(String html) {
/*  93 */     this.html.append(html);
/*     */   }
/*     */   
/*     */   public String renderFunction(GimpleFunction function) {
/*  97 */     appendHtml("<div>\n");
/*     */     
/*  99 */     appendHtml("<div class=\"funcdecl\">");
/* 100 */     appendEscaped(function.getReturnType().toString());
/* 101 */     appendHtml(" ");
/* 102 */     appendHtml(String.format("<span title=\"%s\">%s</span>", new Object[] { function
/* 103 */             .getMangledName(), function
/* 104 */             .getName() }));
/* 105 */     symbol("(");
/* 106 */     for (int i = 0; i < function.getParameters().size(); i++) {
/* 107 */       if (i > 0) {
/* 108 */         symbol(", ");
/*     */       }
/* 110 */       GimpleParameter param = function.getParameters().get(i);
/* 111 */       appendHtml(renderType(param.getType(), false));
/* 112 */       appendHtml(" ");
/* 113 */       if (param.getName() == null) {
/* 114 */         appendEscaped("P" + param.getId());
/*     */       } else {
/* 116 */         appendEscaped(param.getName());
/*     */       } 
/*     */     } 
/* 119 */     symbol(")");
/* 120 */     appendHtml("</div>");
/*     */     
/* 122 */     for (GimpleVarDecl gimpleVarDecl : function.getVariableDeclarations()) {
/* 123 */       if (gimpleVarDecl.getValue() != null) {
/* 124 */         this.html.append("<div class=\"vardecl\">");
/* 125 */         this.html.append(gimpleVarDecl.getName());
/* 126 */         this.html.append(" = ");
/* 127 */         expr(gimpleVarDecl.getValue());
/* 128 */         this.html.append("</div>");
/*     */       } 
/*     */     } 
/*     */     
/* 132 */     for (GimpleBasicBlock basicBlock : function.getBasicBlocks()) {
/* 133 */       this.html.append("<div class=\"bb\">\n");
/* 134 */       this.html.append("<div class=\"bblabel\">");
/* 135 */       this.html.append(basicBlock.getName() + ":");
/* 136 */       this.html.append("</div>\n");
/* 137 */       for (GimpleStatement statement : basicBlock.getStatements()) {
/* 138 */         renderStatement(statement);
/*     */       }
/* 140 */       this.html.append("</div>");
/*     */     } 
/* 142 */     this.html.append("</div>");
/* 143 */     return this.html.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public String renderRecords() {
/* 148 */     for (GimpleRecordTypeDef typeDef : this.typedefMap.values()) {
/* 149 */       this.html.append("<h2 id=\"").append(typeDef.getId()).append("\">");
/* 150 */       this.html.append(recordName(typeDef));
/* 151 */       this.html.append("</h2>");
/*     */       
/* 153 */       this.html.append("<table>");
/* 154 */       this.html.append("<thead>");
/* 155 */       startRow();
/* 156 */       appendTableHeader("Bit", "offset");
/* 157 */       appendTableHeader("Byte", "offset");
/* 158 */       appendTableHeader("Word", "offset");
/* 159 */       appendTableHeader("Type", "field-type");
/* 160 */       appendTableHeader("Name", "field-name");
/* 161 */       appendTableHeader("Size", "field-size");
/* 162 */       endRow();
/* 163 */       this.html.append("</thead>");
/* 164 */       this.html.append("<tbody>");
/*     */       
/* 166 */       for (GimpleField field : typeDef.getFields()) {
/*     */         
/* 168 */         startRow();
/*     */         
/* 170 */         offsetCell(field, 1);
/* 171 */         offsetCell(field, 8);
/* 172 */         offsetCell(field, 32);
/*     */         
/* 174 */         startCell("field-type");
/* 175 */         appendHtml(renderType(field.getType(), false));
/* 176 */         endCell();
/* 177 */         startCell("field-name");
/* 178 */         appendEscaped(field.getName());
/* 179 */         endCell();
/* 180 */         startCell("field-size");
/* 181 */         endCell();
/* 182 */         endRow();
/*     */       } 
/*     */       
/* 185 */       this.html.append("</tbody>");
/* 186 */       this.html.append("</table>");
/*     */     } 
/*     */     
/* 189 */     return this.html.toString();
/*     */   }
/*     */   
/*     */   private void offsetCell(GimpleField field, int multiple) {
/* 193 */     startCell("offset");
/* 194 */     if (field.getOffset() % multiple == 0) {
/* 195 */       this.html.append(field.getOffset() / multiple);
/*     */     }
/* 197 */     endCell();
/*     */   }
/*     */   
/*     */   private void startRow() {
/* 201 */     this.html.append("<tr>");
/*     */   }
/*     */   
/*     */   private StringBuilder startCell(String className) {
/* 205 */     return this.html.append("<td class=\"").append(className).append("\">");
/*     */   }
/*     */   
/*     */   private StringBuilder endCell() {
/* 209 */     return this.html.append("</td>");
/*     */   }
/*     */   
/*     */   private void endRow() {
/* 213 */     this.html.append("</tr>");
/*     */   }
/*     */ 
/*     */   
/*     */   private StringBuilder appendTableHeader(String text, String className) {
/* 218 */     return this.html.append("<th class=\"").append(className).append("\">").append(text).append("</th>");
/*     */   }
/*     */   
/*     */   private void renderStatement(GimpleStatement statement) {
/* 222 */     this.html.append("<div class=\"gstatement");
/* 223 */     if (statement.getLineNumber() != null) {
/* 224 */       this.html.append(String.format(" SL SL%d", new Object[] { statement.getLineNumber() }));
/*     */     }
/* 226 */     this.html.append("\">");
/* 227 */     if (statement instanceof GimpleAssignment) {
/* 228 */       renderAssignment((GimpleAssignment)statement);
/* 229 */     } else if (statement instanceof GimpleGoto) {
/* 230 */       renderGoto((GimpleGoto)statement);
/* 231 */     } else if (statement instanceof GimpleReturn) {
/* 232 */       renderReturn((GimpleReturn)statement);
/* 233 */     } else if (statement instanceof GimpleCall) {
/* 234 */       renderCall((GimpleCall)statement);
/* 235 */     } else if (statement instanceof GimpleConditional) {
/* 236 */       conditional((GimpleConditional)statement);
/*     */     } 
/* 238 */     this.html.append("</div>\n");
/*     */   }
/*     */ 
/*     */   
/*     */   private void renderCall(GimpleCall statement) {
/* 243 */     if (statement.getLhs() != null) {
/* 244 */       renderLhsType(statement.getLhs());
/* 245 */       expr((GimpleExpr)statement.getLhs());
/* 246 */       this.html.append(" ");
/* 247 */       symbol("=");
/* 248 */       this.html.append(" ");
/*     */     } 
/* 250 */     expr(statement.getFunction());
/* 251 */     argumentList(statement.getOperands());
/*     */   }
/*     */ 
/*     */   
/*     */   private void renderReturn(GimpleReturn statement) {
/* 256 */     this.html.append("RETURN ");
/* 257 */     if (statement.getValue() != null) {
/* 258 */       expr(statement.getValue());
/*     */     }
/*     */   }
/*     */   
/*     */   private void conditional(GimpleConditional statement) {
/* 263 */     symbol("IF");
/* 264 */     this.html.append(" ");
/* 265 */     renderOperation(statement.getOperator(), statement.getOperands());
/* 266 */     this.html.append(" GOTO ");
/* 267 */     this.html.append("BB").append(statement.getTrueLabel());
/* 268 */     this.html.append(" ELSE ");
/* 269 */     this.html.append("BB").append(statement.getFalseLabel());
/*     */   }
/*     */   
/*     */   private void renderGoto(GimpleGoto statement) {
/* 273 */     this.html.append("GOTO ").append(statement.getTarget());
/*     */   }
/*     */   
/*     */   private void renderAssignment(GimpleAssignment statement) {
/* 277 */     renderLhsType(statement.getLHS());
/* 278 */     expr((GimpleExpr)statement.getLHS());
/* 279 */     this.html.append(" = ");
/* 280 */     renderOperation(statement.getOperator(), statement.getOperands());
/*     */   }
/*     */   
/*     */   private void renderLhsType(GimpleLValue lhs) {
/* 284 */     appendHtml("<span class=\"lhs-type\">");
/* 285 */     appendHtml(renderType(lhs.getType(), false));
/* 286 */     appendHtml("</span> ");
/*     */   }
/*     */   
/*     */   private void renderOperation(GimpleOp operator, List<GimpleExpr> operands) {
/* 290 */     switch (operator) {
/*     */       case REAL_CST:
/*     */       case INTEGER_CST:
/*     */       case STRING_CST:
/*     */       case NOP_EXPR:
/*     */       case SSA_NAME:
/*     */       case PARM_DECL:
/*     */       case VAR_DECL:
/*     */       case COMPONENT_REF:
/*     */       case ARRAY_REF:
/*     */       case COMPLEX_CST:
/*     */       case MEM_REF:
/*     */       case ADDR_EXPR:
/*     */       case CONSTRUCTOR:
/* 304 */         assert operands.size() == 1;
/* 305 */         expr(operands.get(0));
/*     */       
/*     */       case MULT_EXPR:
/* 308 */         operator("*", operands);
/*     */       
/*     */       case RDIV_EXPR:
/* 311 */         operator("/", operands);
/*     */       
/*     */       case ABS_EXPR:
/* 314 */         renderFunction("ABS", operands);
/*     */       
/*     */       case MIN_EXPR:
/* 317 */         renderFunction("MIN", operands);
/*     */       
/*     */       case MAX_EXPR:
/* 320 */         renderFunction("MAX", operands);
/*     */       
/*     */       case FLOAT_EXPR:
/* 323 */         renderFunction("FLOAT", operands);
/*     */       
/*     */       case FIX_TRUNC_EXPR:
/* 326 */         renderFunction("FIX_TRUNC", operands);
/*     */       
/*     */       case EXACT_DIV_EXPR:
/* 329 */         renderFunction("EXACT_DIV", operands);
/*     */       
/*     */       case TRUNC_DIV_EXPR:
/* 332 */         renderFunction("TRUNC_DIV", operands);
/*     */       
/*     */       case NE_EXPR:
/* 335 */         operator("!=", operands);
/*     */       
/*     */       case EQ_EXPR:
/* 338 */         operator("==", operands);
/*     */       
/*     */       case LT_EXPR:
/* 341 */         operator("<", operands);
/*     */       
/*     */       case GT_EXPR:
/* 344 */         operator(">", operands);
/*     */       
/*     */       case LE_EXPR:
/* 347 */         operator("<=", operands);
/*     */       
/*     */       case GE_EXPR:
/* 350 */         operator(">=", operands);
/*     */       
/*     */       case TRUTH_NOT_EXPR:
/* 353 */         operator("!", operands);
/*     */       
/*     */       case TRUTH_XOR_EXPR:
/* 356 */         operator("XOR", operands);
/*     */       
/*     */       case TRUTH_OR_EXPR:
/* 359 */         operator("||", operands);
/*     */       
/*     */       case TRUTH_AND_EXPR:
/* 362 */         operator("&&", operands);
/*     */       
/*     */       case POINTER_PLUS_EXPR:
/* 365 */         operator("+", operands);
/*     */       
/*     */       case INDIRECT_REF:
/*     */         return;
/*     */       case PLUS_EXPR:
/* 370 */         operator("+", operands);
/*     */       
/*     */       case MINUS_EXPR:
/* 373 */         operator("-", operands);
/*     */       
/*     */       case BIT_NOT_EXPR:
/* 376 */         operator("~", operands);
/*     */       
/*     */       case BIT_AND_EXPR:
/* 379 */         operator("&", operands);
/*     */       
/*     */       case BIT_IOR_EXPR:
/* 382 */         operator("|", operands);
/*     */       
/*     */       case BIT_XOR_EXPR:
/* 385 */         operator("^^", operands);
/*     */       
/*     */       case LSHIFT_EXPR:
/* 388 */         operator("<<", operands);
/*     */       
/*     */       case RSHIFT_EXPR:
/* 391 */         operator(">>", operands);
/*     */       
/*     */       case LROTATE_EXPR:
/* 394 */         renderFunction("LROTATE", operands);
/*     */       
/*     */       case NEGATE_EXPR:
/* 397 */         operator("~", operands);
/*     */       
/*     */       case PAREN_EXPR:
/* 400 */         operator("", operands);
/*     */     } 
/*     */     
/* 403 */     renderFunction(operator.name(), operands);
/*     */   }
/*     */ 
/*     */   
/*     */   private void renderFunction(String functionName, List<GimpleExpr> operands) {
/* 408 */     this.html.append(functionName);
/* 409 */     argumentList(operands);
/*     */   }
/*     */   
/*     */   private void argumentList(List<GimpleExpr> operands) {
/* 413 */     this.html.append("(");
/* 414 */     for (int i = 0; i < operands.size(); i++) {
/* 415 */       if (i > 0) {
/* 416 */         this.html.append(", ");
/*     */       }
/* 418 */       expr(operands.get(i));
/*     */     } 
/* 420 */     this.html.append(")");
/*     */   }
/*     */   
/*     */   private void operator(String operator, List<GimpleExpr> operands) {
/* 424 */     if (operands.size() == 1) {
/* 425 */       this.html.append(HtmlEscapers.htmlEscaper().escape(operator));
/* 426 */       expr(operands.get(0));
/* 427 */     } else if (operands.size() == 2) {
/* 428 */       expr(operands.get(0));
/* 429 */       this.html.append(" ");
/* 430 */       this.html.append(HtmlEscapers.htmlEscaper().escape(operator));
/* 431 */       this.html.append(" ");
/* 432 */       expr(operands.get(1));
/*     */     } else {
/* 434 */       throw new IllegalArgumentException("arity: " + operands.size());
/*     */     } 
/*     */   }
/*     */   
/*     */   private void symbol(String symbol) {
/* 439 */     this.html.append("<span class=\"symbol\">").append(HtmlEscapers.htmlEscaper().escape(symbol))
/* 440 */       .append("</span>");
/*     */   }
/*     */   
/*     */   private void exprMaybeGrouped(GimpleExpr value) {
/* 444 */     if (isSimple(value)) {
/* 445 */       expr(value);
/*     */     } else {
/* 447 */       symbol("(");
/* 448 */       expr(value);
/* 449 */       symbol(")");
/*     */     } 
/*     */   }
/*     */   
/*     */   private void expr(GimpleExpr expr) {
/* 454 */     this.html.append(String.format("<span class=\"gexpr %s\" title=\"%s\">", new Object[] { expr
/* 455 */             .getClass().getSimpleName(), renderType(expr.getType(), true) }));
/*     */     
/* 457 */     expr.accept(new GimpleExprVisitor()
/*     */         {
/*     */           
/*     */           public void visitAddressOf(GimpleAddressOf addressOf)
/*     */           {
/* 462 */             GimpleRenderer.this.symbol("&");
/* 463 */             GimpleRenderer.this.expr(addressOf.getValue());
/*     */           }
/*     */ 
/*     */           
/*     */           public void visitArrayRef(GimpleArrayRef arrayRef) {
/* 468 */             GimpleRenderer.this.expr(arrayRef.getArray());
/* 469 */             GimpleRenderer.this.symbol("[");
/* 470 */             GimpleRenderer.this.expr(arrayRef.getIndex());
/* 471 */             GimpleRenderer.this.symbol("]");
/*     */           }
/*     */ 
/*     */           
/*     */           public void visitBitFieldRef(GimpleBitFieldRefExpr bitFieldRef) {
/* 476 */             GimpleRenderer.this.expr(bitFieldRef.getValue());
/* 477 */             GimpleRenderer.this.symbol("[");
/* 478 */             GimpleRenderer.this.html.append(bitFieldRef.getOffset() + ":" + bitFieldRef.getSize());
/* 479 */             GimpleRenderer.this.symbol("]");
/*     */           }
/*     */ 
/*     */           
/*     */           public void visitComplexConstant(GimpleComplexConstant constant) {
/* 484 */             GimpleRenderer.this.expr((GimpleExpr)constant.getReal());
/* 485 */             GimpleRenderer.this.symbol("+");
/* 486 */             GimpleRenderer.this.expr((GimpleExpr)constant.getIm());
/* 487 */             GimpleRenderer.this.symbol("i");
/*     */           }
/*     */ 
/*     */           
/*     */           public void visitComponentRef(GimpleComponentRef componentRef) {
/* 492 */             GimpleRenderer.this.exprMaybeGrouped(componentRef.getValue());
/* 493 */             GimpleRenderer.this.symbol(".");
/* 494 */             GimpleRenderer.this.expr((GimpleExpr)componentRef.getMember());
/*     */           }
/*     */ 
/*     */           
/*     */           public void visitCompoundLiteral(GimpleCompoundLiteral compoundLiteral) {
/* 499 */             GimpleRenderer.this.expr((GimpleExpr)compoundLiteral.getDecl());
/*     */           }
/*     */ 
/*     */           
/*     */           public void visitConstantRef(GimpleConstantRef constantRef) {
/* 504 */             GimpleRenderer.this.expr((GimpleExpr)constantRef.getValue());
/*     */           }
/*     */ 
/*     */           
/*     */           public void visitConstructor(GimpleConstructor constructor) {
/* 509 */             GimpleRenderer.this.symbol("{");
/* 510 */             boolean needsComma = false;
/* 511 */             for (GimpleConstructor.Element element : constructor.getElements()) {
/* 512 */               if (needsComma) {
/* 513 */                 GimpleRenderer.this.symbol(", ");
/*     */               }
/* 515 */               if (element.getField() != null) {
/* 516 */                 GimpleRenderer.this.html.append(element.getFieldName()).append(": ");
/*     */               }
/* 518 */               GimpleRenderer.this.expr(element.getValue());
/* 519 */               needsComma = true;
/*     */             } 
/* 521 */             GimpleRenderer.this.symbol("}");
/*     */           }
/*     */ 
/*     */           
/*     */           public void visitFieldRef(GimpleFieldRef fieldRef) {
/* 526 */             GimpleRenderer.this.html.append(HtmlEscapers.htmlEscaper().escape(fieldRef.toString()));
/*     */           }
/*     */           
/*     */           private FunctionGenerator resolveGimpleFunction(GimpleFunctionRef ref) {
/* 530 */             CallGenerator callGenerator = GimpleRenderer.this.symbolTable.findCallGenerator(ref);
/* 531 */             if (callGenerator instanceof FunctionCallGenerator) {
/* 532 */               FunctionCallGenerator fcg = (FunctionCallGenerator)callGenerator;
/* 533 */               if (fcg.getStrategy() instanceof FunctionGenerator) {
/* 534 */                 return (FunctionGenerator)fcg.getStrategy();
/*     */               }
/*     */             } 
/* 537 */             return null;
/*     */           }
/*     */ 
/*     */ 
/*     */           
/*     */           public void visitFunctionRef(GimpleFunctionRef functionRef) {
/* 543 */             FunctionGenerator gimpleFunction = resolveGimpleFunction(functionRef);
/* 544 */             if (gimpleFunction != null) {
/* 545 */               GimpleRenderer.this.html.append(String.format("<a href=\"../%s/%s.html\" title=\"%s\">%s</a>", new Object[] { gimpleFunction
/* 546 */                       .getCompilationUnit().getSourceName(), gimpleFunction
/* 547 */                       .getMangledName(), gimpleFunction
/* 548 */                       .getMangledName(), gimpleFunction
/* 549 */                       .getFunction().getName() }));
/*     */             } else {
/* 551 */               GimpleRenderer.this.html.append(functionRef.getName());
/*     */             } 
/*     */           }
/*     */ 
/*     */           
/*     */           public void visitPrimitiveConstant(GimplePrimitiveConstant constant) {
/* 557 */             GimpleRenderer.this.html.append(constant.getNumberValue());
/*     */           }
/*     */ 
/*     */           
/*     */           public void visitMemRef(GimpleMemRef memRef) {
/* 562 */             GimpleRenderer.this.symbol("*");
/* 563 */             if (memRef.isOffsetZero()) {
/* 564 */               GimpleRenderer.this.exprMaybeGrouped(memRef.getPointer());
/*     */             } else {
/* 566 */               GimpleRenderer.this.symbol("(");
/* 567 */               GimpleRenderer.this.expr(memRef.getPointer());
/* 568 */               GimpleRenderer.this.symbol("+");
/* 569 */               GimpleRenderer.this.expr(memRef.getOffset());
/* 570 */               GimpleRenderer.this.symbol(")");
/*     */             } 
/*     */           }
/*     */ 
/*     */           
/*     */           public void visitNop(GimpleNopExpr expr) {
/* 576 */             GimpleRenderer.this.expr(expr.getValue());
/*     */           }
/*     */ 
/*     */           
/*     */           public void visitParamRef(GimpleParamRef paramRef) {
/* 581 */             GimpleRenderer.this.html.append(paramRef.getName());
/*     */           }
/*     */ 
/*     */           
/*     */           public void visitPointerPlus(GimplePointerPlus pointerPlus) {
/* 586 */             GimpleRenderer.this.exprMaybeGrouped(pointerPlus.getPointer());
/* 587 */             GimpleRenderer.this.symbol("+");
/* 588 */             GimpleRenderer.this.expr(pointerPlus.getOffset());
/*     */           }
/*     */ 
/*     */           
/*     */           public void visitResultDecl(GimpleResultDecl resultDecl) {
/* 593 */             GimpleRenderer.this.html.append("__RESULT");
/*     */           }
/*     */ 
/*     */           
/*     */           public void visitSsaName(GimpleSsaName ssaName) {
/* 598 */             GimpleRenderer.this.expr(ssaName.getVar());
/*     */           }
/*     */ 
/*     */           
/*     */           public void visitStringConstant(GimpleStringConstant stringConstant) {
/* 603 */             GimpleRenderer.this.html.append(HtmlEscapers.htmlEscaper().escape(GimpleRenderer.stringLiteral(stringConstant.getValue())));
/*     */           }
/*     */ 
/*     */           
/*     */           public void visitVariableRef(GimpleVariableRef variableRef) {
/* 608 */             GimpleRenderer.this.html.append(HtmlEscapers.htmlEscaper().escape(variableRef.toString()));
/*     */           }
/*     */         });
/*     */     
/* 612 */     this.html.append("</span>");
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isSimple(GimpleExpr expr) {
/* 617 */     return (expr instanceof org.renjin.gcc.gimple.expr.GimpleConstant || expr instanceof GimpleConstantRef || expr instanceof GimpleVariableRef || expr instanceof GimpleParamRef);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String renderType(GimpleType type, boolean tooltip) {
/* 624 */     if (type instanceof GimpleRecordType) {
/*     */       
/* 626 */       GimpleRecordType recordType = (GimpleRecordType)type;
/* 627 */       if (tooltip) {
/* 628 */         return recordName(recordType.getId());
/*     */       }
/* 630 */       return "<a href=\"records.html#" + recordType.getId() + "\">" + 
/* 631 */         HtmlEscapers.htmlEscaper().escape(recordName(recordType.getId())) + "</a>";
/*     */     } 
/*     */     
/* 634 */     if (type instanceof org.renjin.gcc.gimple.type.GimpleIndirectType) {
/* 635 */       return renderType(type.getBaseType(), tooltip) + "*";
/*     */     }
/* 637 */     if (type instanceof org.renjin.gcc.gimple.type.GimpleFunctionType) {
/* 638 */       return "FUN";
/*     */     }
/* 640 */     if (type instanceof GimpleArrayType) {
/* 641 */       GimpleArrayType arrayType = (GimpleArrayType)type;
/* 642 */       StringBuilder sb = new StringBuilder();
/* 643 */       sb.append(renderType(arrayType.getComponentType(), tooltip));
/* 644 */       sb.append("[");
/* 645 */       if (arrayType.getUbound() != null) {
/* 646 */         if (arrayType.getLbound() != 0) {
/* 647 */           sb.append(arrayType.getLbound());
/* 648 */           sb.append(":");
/* 649 */           sb.append(arrayType.getUbound());
/*     */         } else {
/* 651 */           sb.append(arrayType.getElementCount());
/*     */         } 
/*     */       }
/* 654 */       sb.append("]");
/* 655 */       return sb.toString();
/*     */     } 
/*     */     
/* 658 */     return HtmlEscapers.htmlEscaper().escape(type.toString());
/*     */   }
/*     */ 
/*     */   
/*     */   private String recordName(String id) {
/* 663 */     String name = this.recordNameMap.get(id);
/* 664 */     if (name != null) {
/* 665 */       return name;
/*     */     }
/* 667 */     return "undef_" + id.replace("0x", "");
/*     */   }
/*     */   
/*     */   private String recordName(GimpleRecordTypeDef typeDef) {
/* 671 */     return recordName(typeDef.getId());
/*     */   }
/*     */   
/*     */   public static String stringLiteral(String string) {
/* 675 */     StringBuilder lit = new StringBuilder();
/* 676 */     lit.append("\"");
/* 677 */     for (int i = 0; i < string.length(); i++) {
/* 678 */       char c = string.charAt(i);
/* 679 */       if (c == '\n') {
/* 680 */         lit.append("\\n");
/* 681 */       } else if (c == '\r') {
/* 682 */         lit.append("\\r");
/* 683 */       } else if (c == '\t') {
/* 684 */         lit.append("\\t");
/* 685 */       } else if (c == '"') {
/* 686 */         lit.append("\\\"");
/* 687 */       } else if (c >= ' ' && c < '') {
/* 688 */         lit.append(c);
/*     */       } else {
/* 690 */         lit.append("\\" + Integer.toHexString(c));
/*     */       } 
/*     */     } 
/* 693 */     lit.append("\"");
/* 694 */     return lit.toString();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/logging/GimpleRenderer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */