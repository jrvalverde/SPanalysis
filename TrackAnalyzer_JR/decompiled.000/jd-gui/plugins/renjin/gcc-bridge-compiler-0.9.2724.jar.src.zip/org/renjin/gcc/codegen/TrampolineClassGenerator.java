/*     */ package org.renjin.gcc.codegen;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.List;
/*     */ import org.renjin.gcc.GimpleCompiler;
/*     */ import org.renjin.gcc.GimpleCompilerPlugin;
/*     */ import org.renjin.gcc.codegen.type.ParamStrategy;
/*     */ import org.renjin.repackaged.asm.ClassVisitor;
/*     */ import org.renjin.repackaged.asm.ClassWriter;
/*     */ import org.renjin.repackaged.asm.MethodVisitor;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ import org.renjin.repackaged.asm.util.TraceClassVisitor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TrampolineClassGenerator
/*     */ {
/*  44 */   private ClassWriter cw = new ClassWriter(3);
/*  45 */   private ClassVisitor cv = (ClassVisitor)new TraceClassVisitor((ClassVisitor)this.cw, new PrintWriter(System.out)); public TrampolineClassGenerator(String className) {
/*  46 */     if (GimpleCompiler.TRACE) {
/*  47 */       this.cv = (ClassVisitor)new TraceClassVisitor((ClassVisitor)this.cw, new PrintWriter(System.out));
/*     */     } else {
/*  49 */       this.cv = (ClassVisitor)this.cw;
/*     */     } 
/*  51 */     this.cv.visit(50, 33, className, null, "java/lang/Object", new String[0]);
/*     */     
/*  53 */     emitDefaultConstructor();
/*     */   }
/*     */   
/*     */   private void emitDefaultConstructor() {
/*  57 */     MethodVisitor mv = this.cv.visitMethod(1, "<init>", "()V", null, null);
/*  58 */     mv.visitCode();
/*  59 */     mv.visitVarInsn(25, 0);
/*  60 */     mv.visitMethodInsn(183, "java/lang/Object", "<init>", "()V", false);
/*  61 */     mv.visitInsn(177);
/*  62 */     mv.visitMaxs(1, 1);
/*  63 */     mv.visitEnd();
/*     */   }
/*     */   
/*     */   public void emitTrampolineMethod(List<GimpleCompilerPlugin> plugins, FunctionGenerator functionGenerator) {
/*  67 */     MethodVisitor mv = this.cv.visitMethod(9, functionGenerator
/*  68 */         .getSafeMangledName(), functionGenerator
/*  69 */         .getFunctionDescriptor(), null, null);
/*     */ 
/*     */     
/*  72 */     mv.visitCode();
/*     */     
/*  74 */     for (GimpleCompilerPlugin plugin : plugins) {
/*  75 */       plugin.writeTrampolinePrelude(mv, functionGenerator);
/*     */     }
/*     */     
/*  78 */     int varIndex = 0;
/*  79 */     for (ParamStrategy generator : functionGenerator.getParamStrategies()) {
/*  80 */       for (Type type : generator.getParameterTypes()) {
/*  81 */         mv.visitVarInsn(type.getOpcode(21), varIndex);
/*  82 */         varIndex += type.getSize();
/*     */       } 
/*     */     } 
/*     */     
/*  86 */     for (Type type : functionGenerator.getVariadicStrategy().getParameterTypes()) {
/*  87 */       mv.visitVarInsn(type.getOpcode(21), varIndex);
/*  88 */       varIndex += type.getSize();
/*     */     } 
/*     */     
/*  91 */     mv.visitMethodInsn(184, functionGenerator.getClassName(), functionGenerator
/*  92 */         .getSafeMangledName(), functionGenerator
/*  93 */         .getFunctionDescriptor(), false);
/*     */ 
/*     */     
/*  96 */     Type returnType = functionGenerator.getReturnStrategy().getType();
/*     */     
/*  98 */     if (returnType.equals(Type.VOID_TYPE)) {
/*  99 */       mv.visitInsn(177);
/*     */     } else {
/* 101 */       mv.visitInsn(returnType.getOpcode(172));
/*     */     } 
/*     */     
/* 104 */     mv.visitMaxs(1, 1);
/* 105 */     mv.visitEnd();
/*     */   }
/*     */   
/*     */   public byte[] generateClassFile() throws IOException {
/* 109 */     this.cv.visitEnd();
/* 110 */     return this.cw.toByteArray();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/TrampolineClassGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */