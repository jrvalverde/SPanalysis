/*     */ package org.renjin.gcc.peephole;
/*     */ 
/*     */ import org.renjin.gcc.runtime.Ptr;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ import org.renjin.repackaged.asm.tree.AbstractInsnNode;
/*     */ import org.renjin.repackaged.asm.tree.IntInsnNode;
/*     */ import org.renjin.repackaged.asm.tree.MethodInsnNode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum Pattern
/*     */ {
/*  34 */   LOAD
/*     */   {
/*     */     public boolean match(AbstractInsnNode node) {
/*  37 */       switch (node.getOpcode()) {
/*     */         case 21:
/*     */         case 22:
/*     */         case 23:
/*     */         case 24:
/*     */         case 25:
/*  43 */           return true;
/*     */       } 
/*  45 */       return false;
/*     */     }
/*     */   },
/*     */ 
/*     */   
/*  50 */   ILOAD
/*     */   {
/*     */     public boolean match(AbstractInsnNode node) {
/*  53 */       return (node.getOpcode() == 21);
/*     */     }
/*     */   },
/*     */   
/*  57 */   STORE
/*     */   {
/*     */     public boolean match(AbstractInsnNode node) {
/*  60 */       switch (node.getOpcode()) {
/*     */         case 54:
/*     */         case 55:
/*     */         case 56:
/*     */         case 57:
/*     */         case 58:
/*  66 */           return true;
/*     */       } 
/*  68 */       return false;
/*     */     }
/*     */   },
/*     */ 
/*     */   
/*  73 */   ISTORE
/*     */   {
/*     */     public boolean match(AbstractInsnNode node) {
/*  76 */       return (node.getOpcode() == 54);
/*     */     }
/*     */   },
/*     */   
/*  80 */   ICONST
/*     */   {
/*     */     public boolean match(AbstractInsnNode node) {
/*  83 */       switch (node.getOpcode()) {
/*     */         case 2:
/*     */         case 3:
/*     */         case 4:
/*     */         case 5:
/*     */         case 6:
/*     */         case 7:
/*     */         case 8:
/*     */         case 16:
/*     */         case 17:
/*  93 */           return true;
/*     */       } 
/*     */       
/*  96 */       return false;
/*     */     }
/*     */   },
/*     */ 
/*     */   
/* 101 */   I_ARITHMETIC
/*     */   {
/*     */     public boolean match(AbstractInsnNode node) {
/* 104 */       switch (node.getOpcode()) {
/*     */         case 96:
/*     */         case 100:
/*     */         case 104:
/*     */         case 108:
/* 109 */           return true;
/*     */       } 
/*     */       
/* 112 */       return false;
/*     */     }
/*     */   },
/*     */ 
/*     */ 
/*     */   
/* 118 */   IADD
/*     */   {
/*     */     public boolean match(AbstractInsnNode node) {
/* 121 */       return (node.getOpcode() == 96);
/*     */     }
/*     */   },
/*     */   
/* 125 */   IMUL
/*     */   {
/*     */     public boolean match(AbstractInsnNode node) {
/* 128 */       return (node.getOpcode() == 104);
/*     */     }
/*     */   },
/*     */   
/* 132 */   ZERO
/*     */   {
/*     */     public boolean match(AbstractInsnNode node) {
/* 135 */       return (node.getOpcode() == 3);
/*     */     }
/*     */   },
/*     */   
/* 139 */   EIGHT
/*     */   {
/*     */     public boolean match(AbstractInsnNode node) {
/* 142 */       if (node instanceof IntInsnNode) {
/* 143 */         IntInsnNode intNode = (IntInsnNode)node;
/* 144 */         if (intNode.getOpcode() == 16 && intNode.operand == 8)
/*     */         {
/* 146 */           return true;
/*     */         }
/*     */       } 
/* 149 */       return false;
/*     */     }
/*     */   },
/*     */   
/* 153 */   INT_COMPARISON
/*     */   {
/*     */     public boolean match(AbstractInsnNode node)
/*     */     {
/* 157 */       switch (node.getOpcode()) {
/*     */         case 159:
/*     */         case 160:
/*     */         case 161:
/*     */         case 162:
/*     */         case 163:
/*     */         case 164:
/* 164 */           return true;
/*     */       } 
/* 166 */       return false;
/*     */     }
/*     */   },
/*     */   
/* 170 */   ZERO_COMPARISON
/*     */   {
/*     */     public boolean match(AbstractInsnNode node)
/*     */     {
/* 174 */       switch (node.getOpcode()) {
/*     */         case 153:
/*     */         case 154:
/*     */         case 155:
/*     */         case 156:
/*     */         case 157:
/*     */         case 158:
/* 181 */           return true;
/*     */       } 
/* 183 */       return false;
/*     */     }
/*     */   },
/*     */ 
/*     */   
/* 188 */   POINTER_PLUS
/*     */   {
/*     */     public boolean match(AbstractInsnNode node) {
/* 191 */       if (node instanceof MethodInsnNode) {
/* 192 */         MethodInsnNode methodInsnNode = (MethodInsnNode)node;
/* 193 */         return (methodInsnNode.owner.equals(Type.getType(Ptr.class).getInternalName()) && methodInsnNode.name
/* 194 */           .equals("pointerPlus"));
/*     */       } 
/* 196 */       return false;
/*     */     }
/*     */   },
/*     */   
/* 200 */   POINTER_ACCESS_AT
/*     */   {
/*     */     public boolean match(AbstractInsnNode node) {
/* 203 */       if (node instanceof MethodInsnNode) {
/* 204 */         MethodInsnNode methodInsnNode = (MethodInsnNode)node;
/* 205 */         return (methodInsnNode.owner.equals(Type.getType(Ptr.class).getInternalName()) && methodInsnNode.name
/* 206 */           .startsWith("get") && methodInsnNode.desc
/* 207 */           .startsWith("(I)"));
/*     */       } 
/* 209 */       return false;
/*     */     }
/*     */   },
/*     */   
/* 213 */   IINC
/*     */   {
/*     */     public boolean match(AbstractInsnNode node) {
/* 216 */       return node instanceof org.renjin.repackaged.asm.tree.IincInsnNode;
/*     */     }
/*     */   };
/*     */   
/*     */   public abstract boolean match(AbstractInsnNode paramAbstractInsnNode);
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/peephole/Pattern.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */