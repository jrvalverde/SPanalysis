/*     */ package org.renjin.gcc.codegen.type.complex;
/*     */ 
/*     */ import org.renjin.gcc.codegen.MethodGenerator;
/*     */ import org.renjin.gcc.codegen.array.ArrayTypeStrategy;
/*     */ import org.renjin.gcc.codegen.expr.ExprFactory;
/*     */ import org.renjin.gcc.codegen.expr.GExpr;
/*     */ import org.renjin.gcc.codegen.expr.JExpr;
/*     */ import org.renjin.gcc.codegen.fatptr.ValueFunction;
/*     */ import org.renjin.gcc.codegen.type.FieldStrategy;
/*     */ import org.renjin.gcc.codegen.type.ParamStrategy;
/*     */ import org.renjin.gcc.codegen.type.PointerTypeStrategy;
/*     */ import org.renjin.gcc.codegen.type.ReturnStrategy;
/*     */ import org.renjin.gcc.codegen.type.TypeStrategy;
/*     */ import org.renjin.gcc.codegen.type.UnsupportedCastException;
/*     */ import org.renjin.gcc.codegen.var.VarAllocator;
/*     */ import org.renjin.gcc.codegen.vptr.VPtrStrategy;
/*     */ import org.renjin.gcc.gimple.GimpleVarDecl;
/*     */ import org.renjin.gcc.gimple.expr.GimpleConstructor;
/*     */ import org.renjin.gcc.gimple.type.GimpleArrayType;
/*     */ import org.renjin.gcc.gimple.type.GimpleComplexType;
/*     */ import org.renjin.gcc.gimple.type.GimpleType;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ComplexTypeStrategy
/*     */   implements TypeStrategy<ComplexExpr>
/*     */ {
/*     */   private GimpleComplexType type;
/*     */   
/*     */   public ComplexTypeStrategy(GimpleComplexType type) {
/*  58 */     this.type = type;
/*     */   }
/*     */ 
/*     */   
/*     */   public ComplexExpr variable(GimpleVarDecl decl, VarAllocator allocator) {
/*  63 */     if (decl.isAddressable())
/*     */     {
/*     */       
/*  66 */       throw new UnsupportedOperationException("TODO");
/*     */     }
/*  68 */     return new ComplexExpr((JExpr)allocator
/*  69 */         .reserve(decl.getName() + "$real", this.type.getJvmPartType()), (JExpr)allocator
/*  70 */         .reserve(decl.getName() + "$im", this.type.getJvmPartType()));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ComplexExpr providedGlobalVariable(GimpleVarDecl decl, JExpr expr, boolean readOnly) {
/*  76 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public ComplexExpr constructorExpr(ExprFactory exprFactory, MethodGenerator mv, GimpleConstructor value) {
/*  81 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public FieldStrategy fieldGenerator(Type className, String fieldName) {
/*  86 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public FieldStrategy addressableFieldGenerator(Type className, String fieldName) {
/*  91 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public ParamStrategy getParamStrategy() {
/*  96 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public ReturnStrategy getReturnStrategy() {
/* 101 */     return new ComplexReturnStrategy(this.type);
/*     */   }
/*     */ 
/*     */   
/*     */   public ValueFunction getValueFunction() {
/* 106 */     return new ComplexValueFunction(this.type);
/*     */   }
/*     */ 
/*     */   
/*     */   public PointerTypeStrategy pointerTo() {
/* 111 */     return (PointerTypeStrategy)new VPtrStrategy((GimpleType)this.type);
/*     */   }
/*     */ 
/*     */   
/*     */   public ArrayTypeStrategy arrayOf(GimpleArrayType arrayType) {
/* 116 */     return (new ArrayTypeStrategy(arrayType, new ComplexValueFunction(this.type)))
/* 117 */       .setParameterWrapped(false);
/*     */   }
/*     */ 
/*     */   
/*     */   public ComplexExpr cast(MethodGenerator mv, GExpr value) throws UnsupportedCastException {
/* 122 */     throw new UnsupportedCastException();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/type/complex/ComplexTypeStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */