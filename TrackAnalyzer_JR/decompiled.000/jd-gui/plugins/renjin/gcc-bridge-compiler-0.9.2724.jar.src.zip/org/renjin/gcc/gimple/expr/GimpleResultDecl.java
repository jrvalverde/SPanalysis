/*    */ package org.renjin.gcc.gimple.expr;
/*    */ 
/*    */ import java.util.function.Predicate;
/*    */ import org.renjin.gcc.gimple.GimpleExprVisitor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GimpleResultDecl
/*    */   extends GimpleLValue
/*    */ {
/*    */   public String toString() {
/* 35 */     return "result_decl";
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void replaceAll(Predicate<? super GimpleExpr> predicate, GimpleExpr newExpr) {}
/*    */ 
/*    */ 
/*    */   
/*    */   public void accept(GimpleExprVisitor visitor) {
/* 45 */     visitor.visitResultDecl(this);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/gimple/expr/GimpleResultDecl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */