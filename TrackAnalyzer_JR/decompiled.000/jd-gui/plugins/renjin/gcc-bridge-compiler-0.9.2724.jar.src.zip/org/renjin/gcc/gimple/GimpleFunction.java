/*     */ package org.renjin.gcc.gimple;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.annotation.JsonSetter;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.function.Predicate;
/*     */ import org.renjin.gcc.InternalCompilerException;
/*     */ import org.renjin.gcc.gimple.expr.GimpleExpr;
/*     */ import org.renjin.gcc.gimple.expr.GimpleLValue;
/*     */ import org.renjin.gcc.gimple.expr.GimpleVariableRef;
/*     */ import org.renjin.gcc.gimple.statement.GimpleCall;
/*     */ import org.renjin.gcc.gimple.statement.GimpleStatement;
/*     */ import org.renjin.gcc.gimple.type.GimpleType;
/*     */ import org.renjin.repackaged.guava.base.Joiner;
/*     */ import org.renjin.repackaged.guava.collect.Lists;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GimpleFunction
/*     */   implements GimpleDecl
/*     */ {
/*     */   private long id;
/*     */   private String name;
/*     */   private String mangledName;
/*     */   private GimpleType returnType;
/*     */   private GimpleCompilationUnit unit;
/*  45 */   private List<GimpleBasicBlock> basicBlocks = Lists.newArrayList();
/*  46 */   private List<GimpleParameter> parameters = Lists.newArrayList();
/*  47 */   private List<GimpleVarDecl> variableDeclarations = Lists.newArrayList();
/*     */ 
/*     */   
/*     */   @JsonProperty("public")
/*     */   private boolean _public;
/*     */ 
/*     */   
/*     */   private boolean weak;
/*     */ 
/*     */   
/*     */   private boolean inline;
/*     */ 
/*     */   
/*     */   public long getId() {
/*  61 */     return this.id;
/*     */   }
/*     */   
/*     */   public void setId(long id) {
/*  65 */     this.id = id;
/*     */   }
/*     */   
/*     */   public String getName() {
/*  69 */     return this.name;
/*     */   }
/*     */   
/*     */   public void setMangledName(String mangledName) {
/*  73 */     this.mangledName = mangledName;
/*     */   }
/*     */   
/*     */   public String getMangledName() {
/*  77 */     if (this.mangledName == null) {
/*  78 */       throw new IllegalStateException("Mangled name is null");
/*     */     }
/*  80 */     return this.mangledName;
/*     */   }
/*     */   
/*     */   public String getSafeMangledName() {
/*  84 */     return getMangledName().replace('.', '$');
/*     */   }
/*     */   
/*     */   public void setName(String name) {
/*  88 */     this.name = name;
/*     */   }
/*     */   
/*     */   public List<GimpleVarDecl> getVariableDeclarations() {
/*  92 */     return this.variableDeclarations;
/*     */   }
/*     */   
/*     */   public GimpleCompilationUnit getUnit() {
/*  96 */     return this.unit;
/*     */   }
/*     */   
/*     */   public void setUnit(GimpleCompilationUnit unit) {
/* 100 */     this.unit = unit;
/*     */   }
/*     */   
/*     */   public boolean isWeak() {
/* 104 */     return this.weak;
/*     */   }
/*     */   
/*     */   public void setWeak(boolean weak) {
/* 108 */     this.weak = weak;
/*     */   }
/*     */   
/*     */   public boolean isInline() {
/* 112 */     return this.inline;
/*     */   }
/*     */   
/*     */   public void setInline(boolean inline) {
/* 116 */     this.inline = inline;
/*     */   }
/*     */ 
/*     */   
/*     */   public GimpleVarDecl addVarDecl(GimpleType type) {
/* 121 */     Set<Long> usedIds = usedIds();
/* 122 */     long newId = 1000L;
/* 123 */     while (usedIds.contains(Long.valueOf(newId))) {
/* 124 */       newId++;
/*     */     }
/*     */     
/* 127 */     GimpleVarDecl decl = new GimpleVarDecl();
/* 128 */     decl.setId(this.id);
/* 129 */     decl.setType(type);
/* 130 */     this.variableDeclarations.add(decl);
/*     */     
/* 132 */     return decl;
/*     */   }
/*     */   
/*     */   private Set<Long> usedIds() {
/* 136 */     Set<Long> set = new HashSet<>();
/* 137 */     for (GimpleVarDecl variableDeclaration : this.variableDeclarations) {
/* 138 */       set.add(Long.valueOf(variableDeclaration.getId()));
/*     */     }
/* 140 */     for (GimpleParameter parameter : this.parameters) {
/* 141 */       set.add(Long.valueOf(parameter.getId()));
/*     */     }
/* 143 */     return set;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isPublic() {
/* 153 */     return this._public;
/*     */   }
/*     */   
/*     */   public void setPublic(boolean _public) {
/* 157 */     this._public = _public;
/*     */   }
/*     */   
/*     */   public List<GimpleParameter> getParameters() {
/* 161 */     return this.parameters;
/*     */   }
/*     */   
/*     */   @JsonSetter
/*     */   public void setBasicBlocks(List<GimpleBasicBlock> basicBlocks) {
/* 166 */     this.basicBlocks = basicBlocks;
/*     */   }
/*     */   
/*     */   public void setBasicBlocks(GimpleBasicBlock... blocks) {
/* 170 */     setBasicBlocks(Arrays.asList(blocks));
/*     */   }
/*     */   
/*     */   public void setParameters(List<GimpleParameter> parameters) {
/* 174 */     this.parameters = parameters;
/*     */   }
/*     */   
/*     */   public void accept(GimpleVisitor visitor) {
/* 178 */     for (GimpleBasicBlock bb : this.basicBlocks) {
/* 179 */       visitor.blockStart(bb);
/* 180 */       for (GimpleStatement ins : bb.getStatements()) {
/* 181 */         ins.visit(visitor);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public List<GimpleBasicBlock> getBasicBlocks() {
/* 188 */     return this.basicBlocks;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 193 */     StringBuilder sb = new StringBuilder();
/* 194 */     if (!this.mangledName.equals(this.name)) {
/* 195 */       sb.append(this.mangledName).append(": ");
/*     */     }
/* 197 */     sb.append(this.returnType);
/* 198 */     sb.append(" ");
/* 199 */     sb.append(this.name).append(" (");
/* 200 */     Joiner.on(", ").appendTo(sb, this.parameters);
/* 201 */     sb.append(")\n");
/* 202 */     sb.append("{\n");
/* 203 */     for (GimpleVarDecl decl : this.variableDeclarations) {
/* 204 */       sb.append(decl).append("\n");
/*     */     }
/* 206 */     for (GimpleBasicBlock bb : this.basicBlocks) {
/* 207 */       sb.append(bb.toString());
/*     */     }
/* 209 */     sb.append("}\n");
/* 210 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public GimpleType getReturnType() {
/* 214 */     return this.returnType;
/*     */   }
/*     */   
/*     */   public void setReturnType(GimpleType returnType) {
/* 218 */     this.returnType = returnType;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean lhsMatches(Predicate<? super GimpleLValue> predicate) {
/* 223 */     for (GimpleBasicBlock basicBlock : this.basicBlocks) {
/* 224 */       for (GimpleStatement ins : basicBlock.getStatements()) {
/* 225 */         if (ins.lhsMatches(predicate)) {
/* 226 */           return true;
/*     */         }
/*     */       } 
/*     */     } 
/* 230 */     return false;
/*     */   }
/*     */   
/*     */   public void replaceAll(Predicate<? super GimpleExpr> predicate, GimpleExpr newExpr) {
/* 234 */     for (GimpleBasicBlock basicBlock : this.basicBlocks) {
/* 235 */       basicBlock.replaceAll(predicate, newExpr);
/*     */     }
/*     */   }
/*     */   
/*     */   public void removeVariable(GimpleVariableRef ref) {
/* 240 */     Iterator<GimpleVarDecl> it = this.variableDeclarations.iterator();
/* 241 */     while (it.hasNext()) {
/* 242 */       if (((GimpleVarDecl)it.next()).getId() == ref.getId()) {
/* 243 */         it.remove();
/*     */         return;
/*     */       } 
/*     */     } 
/* 247 */     throw new InternalCompilerException("No such variable: " + ref);
/*     */   }
/*     */   
/*     */   public GimpleBasicBlock getLastBasicBlock() {
/* 251 */     return this.basicBlocks.get(this.basicBlocks.size() - 1);
/*     */   }
/*     */   
/*     */   public boolean isVariadic() {
/* 255 */     for (GimpleBasicBlock basicBlock : this.basicBlocks) {
/* 256 */       for (GimpleStatement statement : basicBlock.getStatements()) {
/* 257 */         if (statement instanceof GimpleCall) {
/* 258 */           GimpleCall call = (GimpleCall)statement;
/* 259 */           if (call.isFunctionNamed("__builtin_va_start")) {
/* 260 */             return true;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 265 */     return false;
/*     */   }
/*     */   
/*     */   public void accept(GimpleExprVisitor visitor) {
/* 269 */     for (GimpleVarDecl decl : this.variableDeclarations) {
/* 270 */       if (decl.getValue() != null) {
/* 271 */         decl.getValue().accept(visitor);
/*     */       }
/*     */     } 
/* 274 */     for (GimpleBasicBlock basicBlock : this.basicBlocks) {
/* 275 */       basicBlock.accept(visitor);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isEmpty() {
/* 280 */     return this.basicBlocks.isEmpty();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/gimple/GimpleFunction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */