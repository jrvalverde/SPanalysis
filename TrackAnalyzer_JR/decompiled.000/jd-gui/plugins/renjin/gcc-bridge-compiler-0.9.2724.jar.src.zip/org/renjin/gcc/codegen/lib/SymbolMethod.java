/*    */ package org.renjin.gcc.codegen.lib;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SymbolMethod
/*    */ {
/*    */   private String alias;
/*    */   private Class<?> targetClass;
/*    */   private String methodName;
/*    */   
/*    */   public SymbolMethod(String alias, Class<?> targetClass, String methodName) {
/* 29 */     this.alias = alias;
/* 30 */     this.targetClass = targetClass;
/* 31 */     this.methodName = methodName;
/*    */   }
/*    */   
/*    */   public String getAlias() {
/* 35 */     return this.alias;
/*    */   }
/*    */   public Class<?> getTargetClass() {
/* 38 */     return this.targetClass;
/*    */   }
/*    */   public String getMethodName() {
/* 41 */     return this.methodName;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/lib/SymbolMethod.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */