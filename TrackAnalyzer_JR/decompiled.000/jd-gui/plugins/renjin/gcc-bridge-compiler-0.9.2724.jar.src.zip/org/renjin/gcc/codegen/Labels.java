/*    */ package org.renjin.gcc.codegen;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.renjin.gcc.gimple.GimpleBasicBlock;
/*    */ import org.renjin.repackaged.asm.Label;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Labels
/*    */ {
/* 32 */   private Map<Integer, Label> map = new HashMap<>();
/*    */   
/*    */   public Label of(GimpleBasicBlock block) {
/* 35 */     return of(block.getIndex());
/*    */   }
/*    */   
/*    */   public Label of(int index) {
/* 39 */     Label label = this.map.get(Integer.valueOf(index));
/* 40 */     if (label == null) {
/* 41 */       label = new Label();
/* 42 */       this.map.put(Integer.valueOf(index), label);
/*    */     } 
/* 44 */     return label;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/Labels.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */