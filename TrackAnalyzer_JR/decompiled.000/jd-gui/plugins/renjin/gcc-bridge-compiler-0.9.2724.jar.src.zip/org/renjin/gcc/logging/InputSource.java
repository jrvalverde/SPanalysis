/*     */ package org.renjin.gcc.logging;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.renjin.gcc.gimple.GimpleBasicBlock;
/*     */ import org.renjin.gcc.gimple.GimpleFunction;
/*     */ import org.renjin.gcc.gimple.statement.GimpleStatement;
/*     */ import org.renjin.repackaged.guava.base.Charsets;
/*     */ import org.renjin.repackaged.guava.html.HtmlEscapers;
/*     */ import org.renjin.repackaged.guava.io.Files;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InputSource
/*     */ {
/*     */   private List<String> lines;
/*     */   private String sourceFile;
/*  36 */   private Set<Integer> compiledLines = new HashSet<>();
/*  37 */   private int minLine = Integer.MAX_VALUE;
/*  38 */   private int maxLine = Integer.MIN_VALUE;
/*     */   
/*     */   public InputSource(GimpleFunction gimpleFunction, File sourceFile, String sourcePath) {
/*  41 */     this.lines = loadLines(sourceFile);
/*  42 */     this.sourceFile = sourcePath;
/*     */ 
/*     */     
/*  45 */     for (GimpleBasicBlock basicBlock : gimpleFunction.getBasicBlocks()) {
/*  46 */       for (GimpleStatement statement : basicBlock.getStatements()) {
/*  47 */         if (sourcePath.equals(statement.getSourceFile()) && 
/*  48 */           statement.getLineNumber() != null) {
/*  49 */           int lineNumber = statement.getLineNumber().intValue();
/*  50 */           this.compiledLines.add(Integer.valueOf(lineNumber));
/*  51 */           if (lineNumber < this.minLine) {
/*  52 */             this.minLine = lineNumber;
/*     */           }
/*  54 */           if (lineNumber > this.maxLine) {
/*  55 */             this.maxLine = lineNumber;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  63 */     this.minLine = Math.max(1, this.minLine - 5);
/*  64 */     this.maxLine += 5;
/*     */   }
/*     */   
/*     */   public static List<InputSource> from(GimpleFunction function) {
/*  68 */     Set<String> sourceFiles = findSources(function);
/*  69 */     List<InputSource> sources = new ArrayList<>();
/*  70 */     for (String sourceFile : sourceFiles) {
/*  71 */       sources.add(new InputSource(function, resolveSourceFile(function, sourceFile), sourceFile));
/*     */     }
/*     */     
/*  74 */     return sources;
/*     */   }
/*     */   
/*     */   private static File resolveSourceFile(GimpleFunction function, String sourceFile) {
/*  78 */     if (sourceFile.startsWith("..")) {
/*  79 */       return new File(function.getUnit().getSourceFile().getParentFile(), sourceFile);
/*     */     }
/*  81 */     return new File(sourceFile);
/*     */   }
/*     */ 
/*     */   
/*     */   private static List<String> loadLines(File file) {
/*  86 */     if (file.exists()) {
/*     */       try {
/*  88 */         return Files.readLines(file, Charsets.UTF_8);
/*  89 */       } catch (IOException iOException) {}
/*     */     }
/*     */ 
/*     */     
/*  93 */     return Collections.emptyList();
/*     */   }
/*     */ 
/*     */   
/*     */   private static Set<String> findSources(GimpleFunction function) {
/*  98 */     Set<String> sources = new HashSet<>();
/*  99 */     for (GimpleBasicBlock basicBlock : function.getBasicBlocks()) {
/* 100 */       for (GimpleStatement statement : basicBlock.getStatements()) {
/* 101 */         if (statement.getSourceFile() != null) {
/* 102 */           sources.add(statement.getSourceFile());
/*     */         }
/*     */       } 
/*     */     } 
/* 106 */     return sources;
/*     */   }
/*     */   
/*     */   public void render(StringBuilder html) {
/* 110 */     html.append("<div class=\"sourceFilename\">");
/* 111 */     html.append(HtmlEscapers.htmlEscaper().escape(this.sourceFile));
/* 112 */     html.append("</div>");
/* 113 */     html.append("<table>\n");
/* 114 */     for (int i = this.minLine; i < this.maxLine + 3; i++) {
/* 115 */       line(html, i, lineAt(i - 1));
/*     */     }
/* 117 */     html.append("</table>");
/*     */   }
/*     */   
/*     */   public void line(StringBuilder html, int lineNumber, String line) {
/* 121 */     html.append("<tr");
/* 122 */     if (this.compiledLines.contains(Integer.valueOf(lineNumber))) {
/* 123 */       html.append(String.format(" class=\"SL SL%d\"", new Object[] { Integer.valueOf(lineNumber) }));
/*     */     }
/* 125 */     html.append(">");
/* 126 */     html.append("<td class=\"lnum\">").append(lineNumber).append("</td>");
/* 127 */     html.append("<td class=\"line");
/* 128 */     html.append("\">").append(HtmlEscapers.htmlEscaper().escape(line)).append("</td></tr>\n");
/*     */   }
/*     */   
/*     */   private String lineAt(int i) {
/* 132 */     if (i < this.lines.size()) {
/* 133 */       return this.lines.get(i);
/*     */     }
/* 135 */     return "";
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/logging/InputSource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */