/*    */ package org.renjin.gcc.gimple.expr;
/*    */ 
/*    */ import java.util.function.Predicate;
/*    */ import org.renjin.gcc.gimple.GimpleExprVisitor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class GimplePrimitiveConstant
/*    */   extends GimpleConstant
/*    */ {
/*    */   public abstract Number getValue();
/*    */   
/*    */   public Number getNumberValue() {
/* 32 */     return getValue();
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 37 */     return getValue().toString();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void accept(GimpleExprVisitor visitor) {
/* 43 */     visitor.visitPrimitiveConstant(this);
/*    */   }
/*    */   
/*    */   public void replaceAll(Predicate<? super GimpleExpr> predicate, GimpleExpr newExpr) {}
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/gimple/expr/GimplePrimitiveConstant.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */