/*    */ package org.renjin.gcc.gimple.expr;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.function.Predicate;
/*    */ import org.renjin.gcc.gimple.GimpleExprVisitor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GimpleMemRef
/*    */   extends GimpleLValue
/*    */ {
/*    */   private GimpleExpr pointer;
/*    */   private GimpleExpr offset;
/*    */   
/*    */   public GimpleMemRef() {}
/*    */   
/*    */   public GimpleMemRef(GimpleExpr pointer) {
/* 35 */     this.pointer = pointer;
/* 36 */     this.offset = new GimpleIntegerConstant();
/* 37 */     this.offset.setType(pointer.getType());
/* 38 */     setType(pointer.getType().getBaseType());
/*    */   }
/*    */   
/*    */   public GimpleExpr getPointer() {
/* 42 */     return this.pointer;
/*    */   }
/*    */   
/*    */   public void setPointer(GimpleExpr pointer) {
/* 46 */     this.pointer = pointer;
/*    */   }
/*    */   
/*    */   public GimpleExpr getOffset() {
/* 50 */     return this.offset;
/*    */   }
/*    */   
/*    */   public void setOffset(GimpleExpr offset) {
/* 54 */     this.offset = offset;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 58 */     if (isOffsetZero()) {
/* 59 */       return "*" + this.pointer;
/*    */     }
/* 61 */     return "*(" + this.pointer + "+" + this.offset + ")";
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void find(Predicate<? super GimpleExpr> predicate, List<GimpleExpr> results) {
/* 67 */     findOrDescend(this.pointer, predicate, results);
/* 68 */     findOrDescend(this.offset, predicate, results);
/*    */   }
/*    */ 
/*    */   
/*    */   public void accept(GimpleExprVisitor visitor) {
/* 73 */     visitor.visitMemRef(this);
/*    */   }
/*    */ 
/*    */   
/*    */   public void replaceAll(Predicate<? super GimpleExpr> predicate, GimpleExpr newExpr) {
/* 78 */     this.pointer = replaceOrDescend(this.pointer, predicate, newExpr);
/* 79 */     this.offset = replaceOrDescend(this.offset, predicate, newExpr);
/*    */   }
/*    */   
/*    */   public boolean isOffsetZero() {
/* 83 */     return (this.offset instanceof GimpleIntegerConstant && ((GimpleIntegerConstant)this.offset)
/* 84 */       .getNumberValue().intValue() == 0);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/gimple/expr/GimpleMemRef.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */