/*    */ package org.renjin.gcc.codegen.type.record;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import java.util.Optional;
/*    */ import org.renjin.gcc.codegen.MethodGenerator;
/*    */ import org.renjin.gcc.codegen.expr.ArrayElement;
/*    */ import org.renjin.gcc.codegen.expr.Expressions;
/*    */ import org.renjin.gcc.codegen.expr.GExpr;
/*    */ import org.renjin.gcc.codegen.expr.JExpr;
/*    */ import org.renjin.gcc.codegen.expr.JLValue;
/*    */ import org.renjin.gcc.codegen.fatptr.FatPtr;
/*    */ import org.renjin.gcc.codegen.fatptr.FatPtrPair;
/*    */ import org.renjin.gcc.codegen.type.ParamStrategy;
/*    */ import org.renjin.gcc.codegen.var.VarAllocator;
/*    */ import org.renjin.gcc.gimple.GimpleParameter;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ProvidedPtrParamStrategy
/*    */   implements ParamStrategy
/*    */ {
/*    */   private ProvidedPtrStrategy strategy;
/*    */   
/*    */   public ProvidedPtrParamStrategy(ProvidedPtrStrategy strategy) {
/* 43 */     this.strategy = strategy;
/*    */   }
/*    */ 
/*    */   
/*    */   public List<Type> getParameterTypes() {
/* 48 */     return Collections.singletonList(this.strategy.getJvmType());
/*    */   }
/*    */ 
/*    */   
/*    */   public List<String> getParameterNames(String name) {
/* 53 */     return Collections.singletonList(name);
/*    */   }
/*    */ 
/*    */   
/*    */   public GExpr emitInitialization(MethodGenerator methodVisitor, GimpleParameter parameter, List<JLValue> paramVars, VarAllocator localVars) {
/* 58 */     JLValue unitPtr = paramVars.get(0);
/* 59 */     if (parameter.isAddressable()) {
/*    */       
/* 61 */       JLValue unitArray = localVars.reserveUnitArray(parameter.getName() + "$address", unitPtr
/* 62 */           .getType(), Optional.of(unitPtr));
/* 63 */       FatPtrPair address = new FatPtrPair(this.strategy.getValueFunction(), (JExpr)unitArray);
/*    */       
/* 65 */       ArrayElement arrayElement = Expressions.elementAt(address.getArray(), 0);
/*    */       
/* 67 */       return (GExpr)new ProvidedPtrExpr((JExpr)arrayElement, (FatPtr)address);
/*    */     } 
/* 69 */     return (GExpr)new ProvidedPtrExpr((JExpr)unitPtr);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void loadParameter(MethodGenerator mv, Optional<GExpr> argument) {
/* 75 */     if (!argument.isPresent()) {
/* 76 */       mv.visitInsn(1);
/*    */       
/*    */       return;
/*    */     } 
/* 80 */     ProvidedPtrExpr unitPtrExpr = ((GExpr)argument.get()).toProvidedPtrExpr(this.strategy.getJvmType());
/*    */     
/* 82 */     unitPtrExpr.jexpr().load(mv);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/type/record/ProvidedPtrParamStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */