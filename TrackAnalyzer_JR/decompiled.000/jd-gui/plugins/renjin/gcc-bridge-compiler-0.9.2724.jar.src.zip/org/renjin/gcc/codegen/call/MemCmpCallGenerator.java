/*    */ package org.renjin.gcc.codegen.call;
/*    */ 
/*    */ import org.renjin.gcc.codegen.MethodGenerator;
/*    */ import org.renjin.gcc.codegen.expr.ExprFactory;
/*    */ import org.renjin.gcc.codegen.expr.GExpr;
/*    */ import org.renjin.gcc.codegen.expr.JExpr;
/*    */ import org.renjin.gcc.codegen.expr.PtrExpr;
/*    */ import org.renjin.gcc.codegen.type.TypeOracle;
/*    */ import org.renjin.gcc.codegen.type.primitive.PrimitiveType;
/*    */ import org.renjin.gcc.gimple.expr.GimpleExpr;
/*    */ import org.renjin.gcc.gimple.statement.GimpleCall;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MemCmpCallGenerator
/*    */   implements CallGenerator
/*    */ {
/*    */   private final TypeOracle typeOracle;
/*    */   
/*    */   public MemCmpCallGenerator(TypeOracle typeOracle) {
/* 39 */     this.typeOracle = typeOracle;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void emitCall(MethodGenerator mv, ExprFactory exprFactory, GimpleCall call) {
/* 45 */     if (call.getLhs() != null) {
/* 46 */       PtrExpr p1 = (PtrExpr)exprFactory.findGenerator(call.getOperand(0));
/* 47 */       PtrExpr p2 = (PtrExpr)exprFactory.findGenerator(call.getOperand(1));
/* 48 */       JExpr n = exprFactory.findPrimitiveGenerator(call.getOperand(2));
/*    */       
/* 50 */       JExpr result = p1.memoryCompare(mv, p2, n);
/*    */       
/* 52 */       GExpr lhs = exprFactory.findGenerator((GimpleExpr)call.getLhs());
/* 53 */       lhs.store(mv, (GExpr)PrimitiveType.INT32.fromStackValue(result));
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/call/MemCmpCallGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */