/*    */ package org.renjin.gcc;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import org.renjin.gcc.codegen.expr.Expressions;
/*    */ import org.renjin.gcc.codegen.expr.GExpr;
/*    */ import org.renjin.gcc.codegen.expr.JExpr;
/*    */ import org.renjin.gcc.codegen.type.PointerTypeStrategy;
/*    */ import org.renjin.gcc.codegen.type.TypeOracle;
/*    */ import org.renjin.gcc.gimple.GimpleVarDecl;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ProvidedGlobalVarGetter
/*    */   implements ProvidedGlobalVar
/*    */ {
/*    */   private Method getterMethod;
/*    */   
/*    */   public ProvidedGlobalVarGetter(Method getterMethod) {
/* 36 */     this.getterMethod = getterMethod;
/*    */   }
/*    */ 
/*    */   
/*    */   public GExpr createExpr(GimpleVarDecl decl, TypeOracle typeOracle) {
/*    */     PointerTypeStrategy pointerTypeStrategy;
/* 42 */     JExpr jexpr = Expressions.staticMethodCall(this.getterMethod.getDeclaringClass(), this.getterMethod.getName(), 
/* 43 */         Type.getMethodDescriptor(this.getterMethod), new JExpr[0]);
/*    */ 
/*    */     
/* 46 */     if (typeOracle.getRecordTypes().isMappedToRecordType(this.getterMethod.getReturnType())) {
/* 47 */       pointerTypeStrategy = typeOracle.getRecordTypes().getPointerStrategyFor(this.getterMethod.getReturnType());
/*    */     } else {
/* 49 */       throw new UnsupportedOperationException("TODO: " + this.getterMethod.getReturnType());
/*    */     } 
/*    */     
/* 52 */     return pointerTypeStrategy.providedGlobalVariable(decl, jexpr, true);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/ProvidedGlobalVarGetter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */