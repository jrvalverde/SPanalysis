/*     */ package org.renjin.gcc.codegen.type.fun;
/*     */ 
/*     */ import org.renjin.gcc.codegen.MethodGenerator;
/*     */ import org.renjin.gcc.codegen.array.ArrayTypeStrategy;
/*     */ import org.renjin.gcc.codegen.expr.ExprFactory;
/*     */ import org.renjin.gcc.codegen.expr.GExpr;
/*     */ import org.renjin.gcc.codegen.expr.JExpr;
/*     */ import org.renjin.gcc.codegen.fatptr.ValueFunction;
/*     */ import org.renjin.gcc.codegen.type.FieldStrategy;
/*     */ import org.renjin.gcc.codegen.type.ParamStrategy;
/*     */ import org.renjin.gcc.codegen.type.PointerTypeStrategy;
/*     */ import org.renjin.gcc.codegen.type.ReturnStrategy;
/*     */ import org.renjin.gcc.codegen.type.TypeStrategy;
/*     */ import org.renjin.gcc.codegen.type.UnsupportedCastException;
/*     */ import org.renjin.gcc.codegen.var.VarAllocator;
/*     */ import org.renjin.gcc.gimple.GimpleVarDecl;
/*     */ import org.renjin.gcc.gimple.expr.GimpleConstructor;
/*     */ import org.renjin.gcc.gimple.type.GimpleArrayType;
/*     */ import org.renjin.gcc.gimple.type.GimpleFunctionType;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FunTypeStrategy
/*     */   implements TypeStrategy<FunExpr>
/*     */ {
/*     */   private GimpleFunctionType type;
/*     */   
/*     */   public FunTypeStrategy(GimpleFunctionType type) {
/*  47 */     this.type = type;
/*     */   }
/*     */ 
/*     */   
/*     */   public ParamStrategy getParamStrategy() {
/*  52 */     throw newInvalidOperation();
/*     */   }
/*     */ 
/*     */   
/*     */   public ReturnStrategy getReturnStrategy() {
/*  57 */     throw newInvalidOperation();
/*     */   }
/*     */ 
/*     */   
/*     */   public ValueFunction getValueFunction() {
/*  62 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public FunExpr variable(GimpleVarDecl decl, VarAllocator allocator) {
/*  67 */     throw newInvalidOperation();
/*     */   }
/*     */ 
/*     */   
/*     */   public FunExpr providedGlobalVariable(GimpleVarDecl decl, JExpr expr, boolean readOnly) {
/*  72 */     throw newInvalidOperation();
/*     */   }
/*     */ 
/*     */   
/*     */   public FunExpr constructorExpr(ExprFactory exprFactory, MethodGenerator mv, GimpleConstructor value) {
/*  77 */     throw newInvalidOperation();
/*     */   }
/*     */ 
/*     */   
/*     */   public FieldStrategy fieldGenerator(Type className, String fieldName) {
/*  82 */     throw newInvalidOperation();
/*     */   }
/*     */ 
/*     */   
/*     */   public FieldStrategy addressableFieldGenerator(Type className, String fieldName) {
/*  87 */     throw newInvalidOperation();
/*     */   }
/*     */ 
/*     */   
/*     */   public PointerTypeStrategy pointerTo() {
/*  92 */     return new FunPtrStrategy();
/*     */   }
/*     */ 
/*     */   
/*     */   public ArrayTypeStrategy arrayOf(GimpleArrayType arrayType) {
/*  97 */     throw newInvalidOperation();
/*     */   }
/*     */ 
/*     */   
/*     */   public FunExpr cast(MethodGenerator mv, GExpr value) throws UnsupportedCastException {
/* 102 */     throw new UnsupportedCastException();
/*     */   }
/*     */   
/*     */   private UnsupportedOperationException newInvalidOperation() {
/* 106 */     return new UnsupportedOperationException("Invalid operation for function value type. (Should this be a function *pointer* instead?");
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/type/fun/FunTypeStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */