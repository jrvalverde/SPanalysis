/*    */ package org.renjin.gcc.codegen.type;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import org.renjin.gcc.codegen.MethodGenerator;
/*    */ import org.renjin.gcc.codegen.expr.ExprFactory;
/*    */ import org.renjin.gcc.codegen.expr.Expressions;
/*    */ import org.renjin.gcc.codegen.expr.GExpr;
/*    */ import org.renjin.gcc.codegen.expr.GSimpleExpr;
/*    */ import org.renjin.gcc.codegen.expr.JExpr;
/*    */ import org.renjin.gcc.codegen.type.primitive.PrimitiveExpr;
/*    */ import org.renjin.gcc.gimple.expr.GimpleExpr;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ import org.renjin.repackaged.asm.tree.AnnotationNode;
/*    */ import org.renjin.repackaged.guava.collect.Lists;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JvmVarArgsStrategy
/*    */   implements VariadicStrategy
/*    */ {
/*    */   public List<Type> getParameterTypes() {
/* 43 */     return Collections.singletonList(Type.getType(Object[].class));
/*    */   }
/*    */ 
/*    */   
/*    */   public List<JExpr> marshallVarArgs(MethodGenerator mv, ExprFactory exprFactory, List<GimpleExpr> extraArgs) {
/* 48 */     List<JExpr> varArgValues = Lists.newArrayList();
/* 49 */     for (GimpleExpr arg : extraArgs) {
/* 50 */       GExpr varArgExpr = exprFactory.findGenerator(arg);
/* 51 */       varArgValues.add(wrapVarArg(varArgExpr));
/*    */     } 
/* 53 */     return Collections.singletonList(Expressions.newArray(Type.getType(Object.class), varArgValues));
/*    */   }
/*    */ 
/*    */   
/*    */   public List<AnnotationNode> getParameterAnnotations() {
/* 58 */     return Collections.singletonList(null);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   private JExpr wrapVarArg(GExpr varArgExpr) {
/* 64 */     if (varArgExpr instanceof PrimitiveExpr) {
/* 65 */       return Expressions.box(((PrimitiveExpr)varArgExpr).jexpr());
/*    */     }
/* 67 */     if (varArgExpr instanceof GSimpleExpr) {
/* 68 */       return ((GSimpleExpr)varArgExpr).jexpr();
/*    */     }
/* 70 */     if (varArgExpr instanceof org.renjin.gcc.codegen.expr.PtrExpr) {
/* 71 */       return varArgExpr.toVPtrExpr().getRef();
/*    */     }
/*    */     
/* 74 */     throw new UnsupportedOperationException("varArgExpr: " + varArgExpr);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/type/JvmVarArgsStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */