/*     */ package org.renjin.gcc.codegen.type.primitive;
/*     */ 
/*     */ import javax.annotation.Nullable;
/*     */ import org.renjin.gcc.codegen.MethodGenerator;
/*     */ import org.renjin.gcc.codegen.condition.Comparison;
/*     */ import org.renjin.gcc.codegen.condition.ConditionGenerator;
/*     */ import org.renjin.gcc.codegen.expr.Expressions;
/*     */ import org.renjin.gcc.codegen.expr.GExpr;
/*     */ import org.renjin.gcc.codegen.expr.JExpr;
/*     */ import org.renjin.gcc.codegen.expr.JLValue;
/*     */ import org.renjin.gcc.codegen.expr.PtrExpr;
/*     */ import org.renjin.gcc.codegen.type.NumericExpr;
/*     */ import org.renjin.gcc.gimple.GimpleOp;
/*     */ import org.renjin.gcc.gimple.type.GimpleIntegerType;
/*     */ import org.renjin.gcc.gimple.type.GimplePrimitiveType;
/*     */ import org.renjin.gcc.gimple.type.GimpleRealType;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SignedLongExpr
/*     */   extends AbstractIntExpr
/*     */ {
/*     */   public SignedLongExpr(JExpr expr, @Nullable PtrExpr address) {
/*  39 */     super(expr, address);
/*  40 */     assert expr.getType().equals(Type.LONG_TYPE);
/*     */   }
/*     */   
/*     */   public SignedLongExpr(JExpr expr) {
/*  44 */     this(expr, (PtrExpr)null);
/*     */   }
/*     */ 
/*     */   
/*     */   public SignedLongExpr plus(GExpr operand) {
/*  49 */     return lift(Expressions.sum(jexpr(), jexpr(operand)));
/*     */   }
/*     */ 
/*     */   
/*     */   public SignedLongExpr minus(GExpr operand) {
/*  54 */     return lift(Expressions.difference(jexpr(), jexpr(operand)));
/*     */   }
/*     */ 
/*     */   
/*     */   public SignedLongExpr multiply(GExpr operand) {
/*  59 */     return lift(Expressions.product(jexpr(), jexpr(operand)));
/*     */   }
/*     */ 
/*     */   
/*     */   public SignedLongExpr divide(GExpr operand) {
/*  64 */     return lift(Expressions.divide(jexpr(), jexpr(operand)));
/*     */   }
/*     */ 
/*     */   
/*     */   public SignedLongExpr negative() {
/*  69 */     return lift(Expressions.negative(jexpr()));
/*     */   }
/*     */ 
/*     */   
/*     */   public SignedLongExpr min(GExpr operand) {
/*  74 */     return lift(Expressions.staticMethodCall(Math.class, "min", "(JJ)J", new JExpr[] { jexpr(), jexpr(operand) }));
/*     */   }
/*     */ 
/*     */   
/*     */   public SignedLongExpr max(GExpr operand) {
/*  79 */     return lift(Expressions.staticMethodCall(Math.class, "max", "(JJ)J", new JExpr[] { jexpr(), jexpr(operand) }));
/*     */   }
/*     */ 
/*     */   
/*     */   public SignedLongExpr absoluteValue() {
/*  84 */     return lift(Expressions.staticMethodCall(Math.class, "abs", "(J)J", new JExpr[] { jexpr() }));
/*     */   }
/*     */ 
/*     */   
/*     */   public SignedLongExpr remainder(GExpr operand) {
/*  89 */     return lift(Expressions.remainder(jexpr(), jexpr(operand)));
/*     */   }
/*     */ 
/*     */   
/*     */   public SignedLongExpr bitwiseXor(GExpr operand) {
/*  94 */     return lift(Expressions.bitwiseXor(jexpr(), jexpr(operand)));
/*     */   }
/*     */ 
/*     */   
/*     */   public SignedLongExpr bitwiseNot() {
/*  99 */     return lift(Expressions.bitwiseXor(jexpr(), Expressions.constantLong(-1L)));
/*     */   }
/*     */ 
/*     */   
/*     */   public SignedLongExpr bitwiseAnd(GExpr operand) {
/* 104 */     return lift(Expressions.bitwiseAnd(jexpr(), jexpr(operand)));
/*     */   }
/*     */ 
/*     */   
/*     */   public SignedLongExpr bitwiseOr(GExpr operand) {
/* 109 */     return lift(Expressions.bitwiseOr(jexpr(), jexpr(operand)));
/*     */   }
/*     */ 
/*     */   
/*     */   public SignedLongExpr shiftLeft(GExpr operand) {
/* 114 */     return lift(Expressions.shiftLeft(jexpr(), bits(operand)));
/*     */   }
/*     */ 
/*     */   
/*     */   public SignedLongExpr shiftRight(GExpr operand) {
/* 119 */     return lift(Expressions.shiftRight(jexpr(), bits(operand)));
/*     */   }
/*     */ 
/*     */   
/*     */   public SignedLongExpr rotateLeft(GExpr operand) {
/* 124 */     return lift(Expressions.staticMethodCall(Long.class, "rotateLeft", "(JI)J", new JExpr[] { jexpr(), bits(operand) }));
/*     */   }
/*     */   
/*     */   public IntExpr toSignedInt32() {
/* 128 */     return new SignedIntExpr(Expressions.l2i(jexpr()));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public GimplePrimitiveType getType() {
/* 134 */     return (GimplePrimitiveType)new GimpleIntegerType(64);
/*     */   }
/*     */ 
/*     */   
/*     */   public RealExpr toRealExpr() {
/* 139 */     return toReal(64);
/*     */   }
/*     */ 
/*     */   
/*     */   public IntExpr toSignedInt(int precision) {
/* 144 */     if (precision == 64) {
/* 145 */       return this;
/*     */     }
/* 147 */     return toSignedInt32().toSignedInt(precision);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IntExpr toUnsignedInt(int precision) {
/* 153 */     if (precision == 64)
/* 154 */       return this; 
/* 155 */     if (precision <= 32) {
/* 156 */       return (new UnsignedIntExpr(Expressions.l2i(jexpr()))).toUnsignedInt(precision);
/*     */     }
/* 158 */     throw new UnsupportedOperationException("precision: " + precision);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public RealExpr toReal(int precision) {
/* 164 */     switch (precision) {
/*     */       case 32:
/* 166 */         return new RealExpr(new GimpleRealType(32), Expressions.l2f(jexpr()));
/*     */       case 64:
/*     */       case 96:
/* 169 */         return new RealExpr(new GimpleRealType(precision), Expressions.l2d(jexpr()));
/*     */     } 
/* 171 */     throw new IllegalArgumentException("precision: " + precision);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ConditionGenerator compareTo(GimpleOp op, GExpr operand) {
/* 177 */     return (ConditionGenerator)new Comparison(op, Expressions.lcmp(jexpr(), jexpr(operand)));
/*     */   }
/*     */ 
/*     */   
/*     */   public void store(MethodGenerator mv, GExpr rhs) {
/* 182 */     ((JLValue)jexpr()).store(mv, jexpr(rhs));
/*     */   }
/*     */   
/*     */   private JExpr jexpr(GExpr rhs) {
/* 186 */     return rhs.toPrimitiveExpr().toSignedInt(64).jexpr();
/*     */   }
/*     */ 
/*     */   
/*     */   private SignedLongExpr lift(JExpr expr) {
/* 191 */     return new SignedLongExpr(expr);
/*     */   }
/*     */ 
/*     */   
/*     */   public BooleanExpr toBooleanExpr() {
/* 196 */     return toSignedInt32().toBooleanExpr();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/type/primitive/SignedLongExpr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */