/*     */ package org.renjin.gcc.analysis;
/*     */ 
/*     */ import java.util.ListIterator;
/*     */ import org.renjin.gcc.gimple.GimpleBasicBlock;
/*     */ import org.renjin.gcc.gimple.GimpleCompilationUnit;
/*     */ import org.renjin.gcc.gimple.GimpleFunction;
/*     */ import org.renjin.gcc.gimple.GimpleOp;
/*     */ import org.renjin.gcc.gimple.expr.GimpleAddressOf;
/*     */ import org.renjin.gcc.gimple.expr.GimpleComponentRef;
/*     */ import org.renjin.gcc.gimple.expr.GimpleExpr;
/*     */ import org.renjin.gcc.gimple.expr.GimpleIntegerConstant;
/*     */ import org.renjin.gcc.gimple.expr.GimpleLValue;
/*     */ import org.renjin.gcc.gimple.expr.GimpleVariableRef;
/*     */ import org.renjin.gcc.gimple.statement.GimpleAssignment;
/*     */ import org.renjin.gcc.gimple.statement.GimpleStatement;
/*     */ import org.renjin.gcc.gimple.type.GimpleField;
/*     */ import org.renjin.gcc.gimple.type.GimpleFunctionType;
/*     */ import org.renjin.gcc.gimple.type.GimpleIntegerType;
/*     */ import org.renjin.gcc.gimple.type.GimpleRecordTypeDef;
/*     */ import org.renjin.gcc.gimple.type.GimpleType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PmfRewriter
/*     */ {
/*  48 */   private static final GimpleField FLAG_FIELD = new GimpleField("__pfn$flag", (GimpleType)new GimpleIntegerType(32), 64);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void rewrite(Iterable<GimpleCompilationUnit> units) {
/*  87 */     for (GimpleCompilationUnit unit : units) {
/*  88 */       rewrite(unit);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static void rewrite(GimpleCompilationUnit unit) {
/*  94 */     boolean pmfUsed = false;
/*     */ 
/*     */     
/*  97 */     for (GimpleRecordTypeDef recordTypeDef : unit.getRecordTypes()) {
/*  98 */       if (isPmfRecord(recordTypeDef)) {
/*  99 */         recordTypeDef.getFields().add(FLAG_FIELD);
/* 100 */         recordTypeDef.setSize(recordTypeDef.getSize() + FLAG_FIELD.getSize());
/* 101 */         pmfUsed = true;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 106 */     if (pmfUsed) {
/* 107 */       for (GimpleFunction function : unit.getFunctions()) {
/* 108 */         rewriteFunction(function);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static void rewriteFunction(GimpleFunction function) {
/* 116 */     for (GimpleBasicBlock basicBlock : function.getBasicBlocks()) {
/* 117 */       ListIterator<GimpleStatement> it = basicBlock.getStatements().listIterator();
/* 118 */       while (it.hasNext()) {
/* 119 */         GimpleStatement statement = it.next();
/* 120 */         if (statement instanceof GimpleAssignment) {
/* 121 */           GimpleAssignment assignment = (GimpleAssignment)statement;
/*     */ 
/*     */           
/* 124 */           if (isPfnRef((GimpleExpr)assignment.getLHS())) {
/* 125 */             rewriteAssignment(it, assignment);
/*     */           }
/*     */ 
/*     */           
/* 129 */           if (assignment.getOperator() == GimpleOp.COMPONENT_REF && 
/* 130 */             isPfnRef(assignment.getOperands().get(0))) {
/* 131 */             rewriteInvocation(it, assignment);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void rewriteAssignment(ListIterator<GimpleStatement> it, GimpleAssignment assignment) {
/* 147 */     if (isFunctionPointerAssignment(assignment)) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 157 */       GimpleComponentRef pointerRef = (GimpleComponentRef)assignment.getLHS();
/*     */       
/* 159 */       GimpleAssignment flagAssignment = new GimpleAssignment(GimpleOp.INTEGER_CST, (GimpleLValue)new GimpleComponentRef(pointerRef.getValue(), FLAG_FIELD.refTo()), new GimpleExpr[] { (GimpleExpr)new GimpleIntegerConstant(new GimpleIntegerType(32), 0L) });
/*     */ 
/*     */       
/* 162 */       it.add(flagAssignment);
/*     */     }
/* 164 */     else if (assignment.getOperator() == GimpleOp.INTEGER_CST) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 174 */       GimpleComponentRef lhs = (GimpleComponentRef)assignment.getLHS();
/* 175 */       lhs.setMember(FLAG_FIELD.refTo());
/* 176 */       lhs.setType((GimpleType)new GimpleIntegerType(32));
/*     */       
/* 178 */       GimpleIntegerConstant constant = assignment.getOperands().get(0);
/* 179 */       constant.setType((GimpleType)new GimpleIntegerType(32));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void rewriteInvocation(ListIterator<GimpleStatement> it, GimpleAssignment s0) {
/* 199 */     if (!(s0.getLHS() instanceof GimpleVariableRef)) {
/*     */       return;
/*     */     }
/* 202 */     GimpleVariableRef temp1 = (GimpleVariableRef)s0.getLHS();
/*     */     
/* 204 */     if (!it.hasNext()) {
/*     */       return;
/*     */     }
/* 207 */     GimpleStatement s1 = it.next();
/* 208 */     if (!(s1 instanceof GimpleAssignment)) {
/*     */       return;
/*     */     }
/* 211 */     GimpleAssignment a1 = (GimpleAssignment)s1;
/* 212 */     if (a1.getOperator() != GimpleOp.NOP_EXPR || 
/* 213 */       !(a1.getLHS() instanceof GimpleVariableRef) || 
/* 214 */       !((GimpleExpr)a1.getOperands().get(0)).equals(temp1)) {
/*     */       return;
/*     */     }
/*     */     
/* 218 */     GimpleVariableRef temp2 = (GimpleVariableRef)a1.getLHS();
/* 219 */     if (!temp2.getType().equals(new GimpleIntegerType(32))) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 231 */     GimpleComponentRef componentRef = s0.getOperands().get(0);
/* 232 */     componentRef.setMember(FLAG_FIELD.refTo());
/* 233 */     componentRef.setType(FLAG_FIELD.getType());
/*     */     
/* 235 */     s0.setLhs((GimpleLValue)temp2);
/* 236 */     it.remove();
/*     */   }
/*     */   
/*     */   private static boolean isFunctionPointerAssignment(GimpleAssignment assignment) {
/* 240 */     return (assignment.getOperator() == GimpleOp.ADDR_EXPR && assignment
/* 241 */       .getOperands().get(0) instanceof GimpleAddressOf && ((GimpleAddressOf)assignment
/* 242 */       .getOperands().get(0)).getValue() instanceof org.renjin.gcc.gimple.expr.GimpleFunctionRef);
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean isPfnRef(GimpleExpr value) {
/* 247 */     if (!(value instanceof GimpleComponentRef)) {
/* 248 */       return false;
/*     */     }
/*     */     
/* 251 */     GimpleComponentRef componentRef = (GimpleComponentRef)value;
/*     */     
/* 253 */     return ("__pfn".equals(componentRef.getMember().getName()) && componentRef
/* 254 */       .getType().isPointerTo(GimpleFunctionType.class));
/*     */   }
/*     */   
/*     */   private static boolean isPmfRecord(GimpleRecordTypeDef recordTypeDef) {
/* 258 */     if (recordTypeDef.getFields().size() != 2) {
/* 259 */       return false;
/*     */     }
/*     */     
/* 262 */     GimpleField pfn = recordTypeDef.getFields().get(0);
/* 263 */     GimpleField delta = recordTypeDef.getFields().get(1);
/*     */     
/* 265 */     return (pfn.getName().equals("__pfn") && pfn
/* 266 */       .getType().isPointerTo(GimpleFunctionType.class) && delta
/* 267 */       .getName().equals("__delta") && delta
/* 268 */       .getType().equals(new GimpleIntegerType(32)));
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/analysis/PmfRewriter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */