/*    */ package org.renjin.gcc.gimple.expr;
/*    */ 
/*    */ import java.util.function.Predicate;
/*    */ import org.renjin.gcc.gimple.GimpleExprVisitor;
/*    */ import org.renjin.gcc.gimple.GimpleParameter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GimpleParamRef
/*    */   extends GimpleLValue
/*    */   implements GimpleSymbolRef
/*    */ {
/*    */   private long id;
/*    */   private String name;
/*    */   
/*    */   public GimpleParamRef() {}
/*    */   
/*    */   public GimpleParamRef(long id, String name) {
/* 34 */     this.id = id;
/* 35 */     this.name = name;
/*    */   }
/*    */   
/*    */   public GimpleParamRef(GimpleParameter parameter) {
/* 39 */     this.id = parameter.getId();
/* 40 */     this.name = parameter.getName();
/* 41 */     setType(parameter.getType());
/*    */   }
/*    */   
/*    */   public String getName() {
/* 45 */     return this.name;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getMangledName() {
/* 50 */     return this.name;
/*    */   }
/*    */   
/*    */   public void setName(String name) {
/* 54 */     this.name = name;
/*    */   }
/*    */   
/*    */   public long getId() {
/* 58 */     return this.id;
/*    */   }
/*    */   
/*    */   public void setId(long id) {
/* 62 */     this.id = id;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 67 */     return this.name;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void replaceAll(Predicate<? super GimpleExpr> predicate, GimpleExpr newExpr) {}
/*    */ 
/*    */ 
/*    */   
/*    */   public void accept(GimpleExprVisitor visitor) {
/* 77 */     visitor.visitParamRef(this);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/gimple/expr/GimpleParamRef.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */