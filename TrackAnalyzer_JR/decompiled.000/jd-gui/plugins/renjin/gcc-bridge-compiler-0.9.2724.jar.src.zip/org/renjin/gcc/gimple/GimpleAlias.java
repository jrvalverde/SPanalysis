/*    */ package org.renjin.gcc.gimple;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GimpleAlias
/*    */ {
/*    */   private String alias;
/*    */   private String definition;
/*    */   private boolean _public;
/*    */   
/*    */   public String getAlias() {
/* 31 */     return this.alias;
/*    */   }
/*    */   
/*    */   public void setAlias(String alias) {
/* 35 */     this.alias = alias;
/*    */   }
/*    */   
/*    */   public String getDefinition() {
/* 39 */     return this.definition;
/*    */   }
/*    */   
/*    */   public void setDefinition(String definition) {
/* 43 */     this.definition = definition;
/*    */   }
/*    */   
/*    */   public boolean isPublic() {
/* 47 */     return this._public;
/*    */   }
/*    */   
/*    */   public void setPublic(boolean _public) {
/* 51 */     this._public = _public;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/gimple/GimpleAlias.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */