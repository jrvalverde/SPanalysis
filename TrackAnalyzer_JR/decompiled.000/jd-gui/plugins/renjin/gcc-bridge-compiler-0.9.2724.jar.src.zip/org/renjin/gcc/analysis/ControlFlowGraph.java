/*     */ package org.renjin.gcc.analysis;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileWriter;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.renjin.gcc.gimple.GimpleBasicBlock;
/*     */ import org.renjin.gcc.gimple.GimpleFunction;
/*     */ import org.renjin.gcc.gimple.statement.GimpleEdge;
/*     */ import org.renjin.gcc.gimple.statement.GimpleStatement;
/*     */ import org.renjin.repackaged.guava.collect.Iterators;
/*     */ import org.renjin.repackaged.guava.collect.Lists;
/*     */ import org.renjin.repackaged.guava.collect.Maps;
/*     */ import org.renjin.repackaged.guava.collect.PeekingIterator;
/*     */ import org.renjin.repackaged.guava.escape.Escaper;
/*     */ import org.renjin.repackaged.guava.escape.Escapers;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ControlFlowGraph
/*     */ {
/*     */   public class Node
/*     */   {
/*     */     private String id;
/*     */     private GimpleBasicBlock basicBlock;
/*  51 */     private List<Node> incoming = Lists.newArrayList();
/*  52 */     private List<Node> outgoing = Lists.newArrayList();
/*     */     
/*     */     public Node(String id) {
/*  55 */       this.id = id;
/*     */     }
/*     */     
/*     */     public Node(GimpleBasicBlock basicBlock) {
/*  59 */       this.basicBlock = basicBlock;
/*  60 */       this.id = "BB" + basicBlock.getIndex();
/*     */     }
/*     */     
/*     */     public String getId() {
/*  64 */       return this.id;
/*     */     }
/*     */     
/*     */     public GimpleBasicBlock getBasicBlock() {
/*  68 */       return this.basicBlock;
/*     */     }
/*     */     
/*     */     public List<Node> getIncoming() {
/*  72 */       return this.incoming;
/*     */     }
/*     */     
/*     */     public List<Node> getOutgoing() {
/*  76 */       return this.outgoing;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/*  81 */       return "<" + this.id + ">";
/*     */     }
/*     */     
/*     */     public Iterable<GimpleStatement> getStatements() {
/*  85 */       if (this.basicBlock == null) {
/*  86 */         return Collections.emptySet();
/*     */       }
/*  88 */       return this.basicBlock.getStatements();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*  93 */   private Node entryNode = new Node("Entry");
/*  94 */   private Node exitNode = new Node("Exit");
/*     */   
/*  96 */   private Map<Integer, Node> nodes = Maps.newHashMap();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ControlFlowGraph(GimpleFunction function) {
/* 104 */     for (GimpleBasicBlock basicBlock : function.getBasicBlocks()) {
/* 105 */       this.nodes.put(Integer.valueOf(basicBlock.getIndex()), new Node(basicBlock));
/*     */     }
/*     */ 
/*     */     
/* 109 */     addEdge(this.entryNode, getNode(function.getBasicBlocks().get(0)));
/*     */ 
/*     */     
/* 112 */     PeekingIterator<GimpleBasicBlock> it = Iterators.peekingIterator(function.getBasicBlocks().iterator());
/* 113 */     while (it.hasNext()) {
/* 114 */       GimpleBasicBlock sourceBlock = (GimpleBasicBlock)it.next();
/* 115 */       Node sourceNode = this.nodes.get(Integer.valueOf(sourceBlock.getIndex()));
/*     */ 
/*     */ 
/*     */       
/* 119 */       boolean fallsThrough = true;
/* 120 */       for (GimpleEdge jump : sourceBlock.getJumps()) {
/*     */         Node targetNode;
/* 122 */         if (!jump.isExceptionThrow()) {
/* 123 */           fallsThrough = false;
/*     */         }
/* 125 */         sourceNode = this.nodes.get(Integer.valueOf(jump.getSource()));
/* 126 */         if (jump.getTarget() == 1) {
/* 127 */           targetNode = this.exitNode;
/*     */         } else {
/* 129 */           targetNode = this.nodes.get(Integer.valueOf(jump.getTarget()));
/*     */         } 
/* 131 */         addEdge(sourceNode, targetNode);
/*     */       } 
/* 133 */       if (fallsThrough && 
/* 134 */         it.hasNext()) {
/* 135 */         addEdge(sourceNode, getNode((GimpleBasicBlock)it.peek()));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterable<Node> getNodes() {
/* 147 */     Set<Node> nodes = new HashSet<>();
/* 148 */     nodes.add(this.entryNode);
/* 149 */     nodes.add(this.exitNode);
/* 150 */     nodes.addAll(this.nodes.values());
/* 151 */     return nodes;
/*     */   }
/*     */   
/*     */   public Node getNode(GimpleBasicBlock bb) {
/* 155 */     return this.nodes.get(Integer.valueOf(bb.getIndex()));
/*     */   }
/*     */   
/*     */   private void addEdge(Node from, Node to) {
/* 159 */     from.outgoing.add(to);
/* 160 */     to.incoming.add(from);
/*     */   }
/*     */   
/*     */   public void dumpGraph(File file) throws IOException {
/* 164 */     try (PrintWriter writer = new PrintWriter(new FileWriter(file))) {
/* 165 */       dumpGraph(writer);
/*     */     } 
/*     */   }
/*     */   
/*     */   public Collection<Node> getBasicBlockNodes() {
/* 170 */     return this.nodes.values();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dumpGraph(PrintWriter writer) {
/* 178 */     Escaper escaper = Escapers.builder().addEscape('"', "\\\"").addEscape('\n', "\\n").build();
/*     */     
/* 180 */     writer.println("digraph {");
/*     */     
/* 182 */     writer.println(String.format("%s[label=\"Entry\"]", new Object[] { Node.access$200(this.entryNode) }));
/* 183 */     writer.println(String.format("%s[label=\"Exit\"]", new Object[] { Node.access$200(this.exitNode) }));
/*     */ 
/*     */     
/* 186 */     for (Node node : this.nodes.values()) {
/* 187 */       writer.println(String.format("%s[label=\"%s\", shape=\"rect\"]", new Object[] { Node.access$200(node), escaper.escape(Node.access$300(node).toString()) }));
/*     */     } 
/*     */     
/* 190 */     for (Node node : getNodes()) {
/* 191 */       for (Node out : node.outgoing) {
/* 192 */         writer.println(node.id + " -> " + out.id);
/*     */       }
/*     */     } 
/*     */     
/* 196 */     writer.println("}");
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/analysis/ControlFlowGraph.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */