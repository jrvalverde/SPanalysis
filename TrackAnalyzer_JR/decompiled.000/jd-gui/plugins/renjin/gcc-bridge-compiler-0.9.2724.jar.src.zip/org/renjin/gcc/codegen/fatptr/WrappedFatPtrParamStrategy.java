/*     */ package org.renjin.gcc.codegen.fatptr;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Optional;
/*     */ import org.renjin.gcc.codegen.MethodGenerator;
/*     */ import org.renjin.gcc.codegen.expr.Expressions;
/*     */ import org.renjin.gcc.codegen.expr.GExpr;
/*     */ import org.renjin.gcc.codegen.expr.JExpr;
/*     */ import org.renjin.gcc.codegen.expr.JLValue;
/*     */ import org.renjin.gcc.codegen.type.ParamStrategy;
/*     */ import org.renjin.gcc.codegen.var.VarAllocator;
/*     */ import org.renjin.gcc.gimple.GimpleParameter;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ import org.renjin.repackaged.guava.collect.Lists;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WrappedFatPtrParamStrategy
/*     */   implements ParamStrategy
/*     */ {
/*     */   private ValueFunction valueFunction;
/*     */   
/*     */   public WrappedFatPtrParamStrategy(ValueFunction valueFunction) {
/*  44 */     this.valueFunction = valueFunction;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<Type> getParameterTypes() {
/*  49 */     return Lists.newArrayList((Object[])new Type[] { Wrappers.wrapperType(this.valueFunction.getValueType()) });
/*     */   }
/*     */ 
/*     */   
/*     */   public List<String> getParameterNames(String name) {
/*  54 */     return Collections.singletonList(name);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public GExpr emitInitialization(MethodGenerator mv, GimpleParameter parameter, List<JLValue> paramVars, VarAllocator localVars) {
/*  60 */     JLValue wrapper = paramVars.get(0);
/*     */     
/*  62 */     if (parameter.isAddressable()) {
/*     */ 
/*     */       
/*  65 */       JLValue unitArray = localVars.reserveUnitArray(parameter.getName() + "$address", wrapper
/*  66 */           .getType(), Optional.of(wrapper));
/*     */       
/*  68 */       return (new DereferencedFatPtr((JExpr)unitArray, Expressions.constantInt(0), new FatPtrValueFunction(this.valueFunction)))
/*     */         
/*  70 */         .valueOf(this.valueFunction.getGimpleValueType());
/*     */     } 
/*  72 */     if (this.valueFunction.getValueType().getSort() == 10) {
/*  73 */       return (GExpr)new WrappedFatPtrExpr(this.valueFunction, wrapper);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  79 */     JLValue array = localVars.reserve(parameter.getName() + "$array", Wrappers.valueArrayType(this.valueFunction.getValueType()));
/*  80 */     JLValue offset = localVars.reserveInt(parameter.getName() + "$offset");
/*     */     
/*  82 */     JExpr arrayField = Wrappers.arrayField((JExpr)wrapper, this.valueFunction.getValueType());
/*  83 */     JExpr offsetField = Wrappers.offsetField((JExpr)wrapper);
/*     */     
/*  85 */     array.store(mv, arrayField);
/*  86 */     offset.store(mv, offsetField);
/*     */     
/*  88 */     return (GExpr)new FatPtrPair(this.valueFunction, (JExpr)array, (JExpr)offset);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void loadParameter(MethodGenerator mv, Optional<GExpr> argument) {
/*  95 */     if (!argument.isPresent()) {
/*  96 */       mv.aconst(null);
/*     */       
/*     */       return;
/*     */     } 
/* 100 */     ((GExpr)argument.get()).toFatPtrExpr(this.valueFunction).wrap().load(mv);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/fatptr/WrappedFatPtrParamStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */