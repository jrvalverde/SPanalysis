/*    */ package org.renjin.gcc.gimple.statement;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.Set;
/*    */ import org.renjin.gcc.gimple.GimpleExprVisitor;
/*    */ import org.renjin.gcc.gimple.GimpleLabel;
/*    */ import org.renjin.gcc.gimple.GimpleVisitor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GimpleGoto
/*    */   extends GimpleStatement
/*    */ {
/*    */   private int target;
/*    */   
/*    */   public GimpleLabel getTargetLabel() {
/* 32 */     return new GimpleLabel("bb" + this.target);
/*    */   }
/*    */   
/*    */   public int getTarget() {
/* 36 */     return this.target;
/*    */   }
/*    */   
/*    */   public void setTarget(int target) {
/* 40 */     this.target = target;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 45 */     return "goto " + getTargetLabel();
/*    */   }
/*    */ 
/*    */   
/*    */   public void visit(GimpleVisitor visitor) {
/* 50 */     visitor.visitGoto(this);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void accept(GimpleExprVisitor visitor) {}
/*    */ 
/*    */ 
/*    */   
/*    */   public Set<Integer> getJumpTargets() {
/* 61 */     return Collections.singleton(Integer.valueOf(this.target));
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/gimple/statement/GimpleGoto.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */