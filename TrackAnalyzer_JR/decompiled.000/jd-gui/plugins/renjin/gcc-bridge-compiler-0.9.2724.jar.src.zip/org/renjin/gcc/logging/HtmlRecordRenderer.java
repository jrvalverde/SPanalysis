/*    */ package org.renjin.gcc.logging;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.renjin.gcc.gimple.GimpleCompilationUnit;
/*    */ import org.renjin.gcc.symbols.SymbolTable;
/*    */ import org.renjin.repackaged.guava.base.Charsets;
/*    */ import org.renjin.repackaged.guava.io.Resources;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HtmlRecordRenderer
/*    */ {
/*    */   private final GimpleCompilationUnit unit;
/*    */   private final SymbolTable symbolTable;
/*    */   
/*    */   public HtmlRecordRenderer(SymbolTable symbolTable, GimpleCompilationUnit unit) {
/* 35 */     this.unit = unit;
/* 36 */     this.symbolTable = symbolTable;
/*    */   }
/*    */ 
/*    */   
/*    */   public String render() throws IOException {
/* 41 */     return Resources.toString(Resources.getResource(HtmlFunctionRenderer.class, "records.html"), Charsets.UTF_8)
/* 42 */       .replace("__RECORDS__", renderRecords());
/*    */   }
/*    */   
/*    */   private CharSequence renderRecords() {
/* 46 */     return (new GimpleRenderer(this.symbolTable, this.unit)).renderRecords();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/logging/HtmlRecordRenderer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */