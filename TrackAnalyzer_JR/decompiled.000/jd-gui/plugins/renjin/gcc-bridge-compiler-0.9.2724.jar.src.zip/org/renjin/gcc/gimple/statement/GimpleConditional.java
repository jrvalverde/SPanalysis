/*     */ package org.renjin.gcc.gimple.statement;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.function.Predicate;
/*     */ import org.renjin.gcc.gimple.GimpleExprVisitor;
/*     */ import org.renjin.gcc.gimple.GimpleOp;
/*     */ import org.renjin.gcc.gimple.GimpleVisitor;
/*     */ import org.renjin.gcc.gimple.expr.GimpleExpr;
/*     */ import org.renjin.repackaged.guava.collect.Sets;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GimpleConditional
/*     */   extends GimpleStatement
/*     */ {
/*     */   private GimpleOp operator;
/*     */   private List<GimpleExpr> operands;
/*     */   private int trueLabel;
/*     */   private int falseLabel;
/*     */   
/*     */   void setOperator(GimpleOp op) {
/*  46 */     this.operator = op;
/*     */   }
/*     */   
/*     */   void setOperands(List<GimpleExpr> operands) {
/*  50 */     this.operands = operands;
/*     */   }
/*     */   
/*     */   public GimpleOp getOperator() {
/*  54 */     return this.operator;
/*     */   }
/*     */   
/*     */   public List<GimpleExpr> getOperands() {
/*  58 */     return this.operands;
/*     */   }
/*     */   
/*     */   public int getTrueLabel() {
/*  62 */     return this.trueLabel;
/*     */   }
/*     */   
/*     */   public void setTrueLabel(int trueLabel) {
/*  66 */     this.trueLabel = trueLabel;
/*     */   }
/*     */   
/*     */   public int getFalseLabel() {
/*  70 */     return this.falseLabel;
/*     */   }
/*     */   
/*     */   public void setFalseLabel(int falseLabel) {
/*  74 */     this.falseLabel = falseLabel;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void findUses(Predicate<? super GimpleExpr> predicate, List<GimpleExpr> results) {
/*  79 */     findUses(this.operands, predicate, results);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  84 */     StringBuilder sb = new StringBuilder();
/*  85 */     sb.append("if(").append(this.operator.format(this.operands)).append(") then ");
/*  86 */     sb.append(this.trueLabel);
/*  87 */     sb.append("else ").append(this.falseLabel);
/*  88 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<Integer> getJumpTargets() {
/*  93 */     return Sets.newHashSet((Object[])new Integer[] { Integer.valueOf(this.trueLabel), Integer.valueOf(this.falseLabel) });
/*     */   }
/*     */ 
/*     */   
/*     */   public void visit(GimpleVisitor visitor) {
/*  98 */     visitor.visitConditional(this);
/*     */   }
/*     */   
/*     */   public GimpleExpr getOperand(int index) {
/* 102 */     return this.operands.get(index);
/*     */   }
/*     */ 
/*     */   
/*     */   public void replaceAll(Predicate<? super GimpleExpr> predicate, GimpleExpr newExpr) {
/* 107 */     replaceAll(predicate, this.operands, newExpr);
/*     */   }
/*     */ 
/*     */   
/*     */   public void accept(GimpleExprVisitor visitor) {
/* 112 */     for (GimpleExpr operand : this.operands)
/* 113 */       operand.accept(visitor); 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/gimple/statement/GimpleConditional.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */