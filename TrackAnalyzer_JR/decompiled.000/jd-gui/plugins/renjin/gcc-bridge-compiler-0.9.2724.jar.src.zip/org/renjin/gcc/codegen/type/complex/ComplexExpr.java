/*     */ package org.renjin.gcc.codegen.type.complex;
/*     */ 
/*     */ import org.renjin.gcc.codegen.MethodGenerator;
/*     */ import org.renjin.gcc.codegen.array.FatArrayExpr;
/*     */ import org.renjin.gcc.codegen.expr.Expressions;
/*     */ import org.renjin.gcc.codegen.expr.GExpr;
/*     */ import org.renjin.gcc.codegen.expr.JExpr;
/*     */ import org.renjin.gcc.codegen.expr.JLValue;
/*     */ import org.renjin.gcc.codegen.expr.PtrExpr;
/*     */ import org.renjin.gcc.codegen.fatptr.FatPtr;
/*     */ import org.renjin.gcc.codegen.fatptr.ValueFunction;
/*     */ import org.renjin.gcc.codegen.type.NumericExpr;
/*     */ import org.renjin.gcc.codegen.type.UnsupportedCastException;
/*     */ import org.renjin.gcc.codegen.type.fun.FunPtrExpr;
/*     */ import org.renjin.gcc.codegen.type.primitive.PrimitiveExpr;
/*     */ import org.renjin.gcc.codegen.type.primitive.RealExpr;
/*     */ import org.renjin.gcc.codegen.type.record.ProvidedPtrExpr;
/*     */ import org.renjin.gcc.codegen.type.voidt.VoidPtrExpr;
/*     */ import org.renjin.gcc.codegen.vptr.VArrayExpr;
/*     */ import org.renjin.gcc.codegen.vptr.VPtrExpr;
/*     */ import org.renjin.gcc.codegen.vptr.VPtrRecordExpr;
/*     */ import org.renjin.gcc.gimple.type.GimpleArrayType;
/*     */ import org.renjin.gcc.gimple.type.GimplePrimitiveType;
/*     */ import org.renjin.gcc.gimple.type.GimpleRealType;
/*     */ import org.renjin.gcc.gimple.type.GimpleRecordType;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ComplexExpr
/*     */   implements NumericExpr
/*     */ {
/*     */   private PtrExpr address;
/*     */   private JExpr realValue;
/*     */   private JExpr imaginaryValue;
/*     */   private Type componentType;
/*     */   
/*     */   public ComplexExpr(PtrExpr address, JExpr realValue, JExpr imaginaryValue) {
/*  55 */     this.address = address;
/*  56 */     this.realValue = realValue;
/*  57 */     this.imaginaryValue = imaginaryValue;
/*     */     
/*  59 */     if (!realValue.getType().equals(imaginaryValue.getType())) {
/*  60 */       throw new IllegalArgumentException(String.format("Part types do not match: %s != %s", new Object[] { realValue
/*  61 */               .getType(), imaginaryValue.getType() }));
/*     */     }
/*  63 */     this.componentType = realValue.getType();
/*     */   }
/*     */   
/*     */   public GimpleRealType getGimpleComponentType() {
/*  67 */     return (GimpleRealType)GimplePrimitiveType.fromJvmType(this.componentType);
/*     */   }
/*     */   
/*     */   public ComplexExpr(JExpr realValue, JExpr imaginaryValue) {
/*  71 */     this(null, realValue, imaginaryValue);
/*     */   }
/*     */   
/*     */   public ComplexExpr(GExpr realValue, GExpr imaginaryValue) {
/*  75 */     this(null, ((PrimitiveExpr)realValue).jexpr(), ((PrimitiveExpr)imaginaryValue).jexpr());
/*     */   }
/*     */   
/*     */   public ComplexExpr(JExpr realValue) {
/*  79 */     this.realValue = realValue;
/*  80 */     this.imaginaryValue = Expressions.zero(realValue.getType());
/*     */   }
/*     */   
/*     */   public Type getComponentType() {
/*  84 */     return this.componentType;
/*     */   }
/*     */   
/*     */   public JExpr getRealJExpr() {
/*  88 */     return this.realValue;
/*     */   }
/*     */   
/*     */   public RealExpr getRealGExpr() {
/*  92 */     return new RealExpr(getGimpleComponentType(), this.realValue);
/*     */   }
/*     */   
/*     */   public JExpr getImaginaryJExpr() {
/*  96 */     return this.imaginaryValue;
/*     */   }
/*     */   
/*     */   public RealExpr getImaginaryGExpr() {
/* 100 */     return new RealExpr(getGimpleComponentType(), this.imaginaryValue);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void store(MethodGenerator mv, GExpr rhs) {
/* 106 */     ComplexExpr complexRhs = (ComplexExpr)rhs;
/*     */     
/* 108 */     ((JLValue)this.realValue).store(mv, complexRhs.getRealJExpr());
/* 109 */     ((JLValue)this.imaginaryValue).store(mv, complexRhs.getImaginaryJExpr());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ComplexExpr conjugate() {
/* 119 */     return new ComplexExpr(this.address, this.realValue, Expressions.negative(this.imaginaryValue));
/*     */   }
/*     */ 
/*     */   
/*     */   public PtrExpr addressOf() {
/* 124 */     if (this.address == null) {
/* 125 */       throw new UnsupportedOperationException("not addressable");
/*     */     }
/* 127 */     return this.address;
/*     */   }
/*     */ 
/*     */   
/*     */   public FunPtrExpr toFunPtr() throws UnsupportedCastException {
/* 132 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public FatArrayExpr toArrayExpr() throws UnsupportedCastException {
/* 137 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public PrimitiveExpr toPrimitiveExpr() throws UnsupportedCastException {
/* 142 */     return getRealGExpr().toPrimitiveExpr();
/*     */   }
/*     */ 
/*     */   
/*     */   public VoidPtrExpr toVoidPtrExpr() throws UnsupportedCastException {
/* 147 */     throw new UnsupportedCastException();
/*     */   }
/*     */ 
/*     */   
/*     */   public VPtrExpr toVPtrExpr() throws UnsupportedCastException {
/* 152 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public ProvidedPtrExpr toProvidedPtrExpr(Type jvmType) {
/* 157 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public FatPtr toFatPtrExpr(ValueFunction valueFunction) {
/* 162 */     throw new UnsupportedCastException();
/*     */   }
/*     */ 
/*     */   
/*     */   public VPtrRecordExpr toVPtrRecord(GimpleRecordType recordType) {
/* 167 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public VArrayExpr toVArray(GimpleArrayType arrayType) {
/* 172 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public NumericExpr toNumericExpr() {
/* 177 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public NumericExpr plus(GExpr operand) {
/* 182 */     JExpr real = Expressions.sum(this.realValue, operand.toNumericExpr().toComplexExpr().getRealJExpr());
/* 183 */     JExpr im = Expressions.sum(this.imaginaryValue, operand.toNumericExpr().toComplexExpr().getImaginaryJExpr());
/* 184 */     return new ComplexExpr(real, im);
/*     */   }
/*     */ 
/*     */   
/*     */   public NumericExpr minus(GExpr operand) {
/* 189 */     JExpr real = Expressions.difference(this.realValue, operand.toNumericExpr().toComplexExpr().getRealJExpr());
/* 190 */     JExpr im = Expressions.difference(this.imaginaryValue, operand.toNumericExpr().toComplexExpr().getImaginaryJExpr());
/* 191 */     return new ComplexExpr(real, im);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public NumericExpr multiply(GExpr operand) {
/* 197 */     ComplexExpr x = this;
/* 198 */     ComplexExpr y = operand.toNumericExpr().toComplexExpr();
/*     */     
/* 200 */     JExpr a = x.realValue;
/* 201 */     JExpr b = x.imaginaryValue;
/* 202 */     JExpr c = y.realValue;
/* 203 */     JExpr d = y.imaginaryValue;
/*     */     
/* 205 */     JExpr real = Expressions.difference(Expressions.product(a, c), Expressions.product(b, d));
/* 206 */     JExpr im = Expressions.sum(Expressions.product(b, c), Expressions.product(a, d));
/*     */     
/* 208 */     return new ComplexExpr(real, im);
/*     */   }
/*     */ 
/*     */   
/*     */   public NumericExpr divide(GExpr operand) {
/* 213 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public NumericExpr remainder(GExpr operand) {
/* 218 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public NumericExpr negative() {
/* 223 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public NumericExpr min(GExpr operand) {
/* 228 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public NumericExpr max(GExpr operand) {
/* 233 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public NumericExpr absoluteValue() {
/* 238 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public ComplexExpr toComplexExpr() {
/* 243 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public RealExpr toRealExpr() {
/* 248 */     return new RealExpr(getGimpleComponentType(), getRealJExpr());
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/type/complex/ComplexExpr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */