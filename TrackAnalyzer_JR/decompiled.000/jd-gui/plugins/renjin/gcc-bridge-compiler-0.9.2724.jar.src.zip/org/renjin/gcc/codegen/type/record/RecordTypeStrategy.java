/*    */ package org.renjin.gcc.codegen.type.record;
/*    */ 
/*    */ import org.renjin.gcc.codegen.expr.GExpr;
/*    */ import org.renjin.gcc.codegen.type.TypeStrategy;
/*    */ import org.renjin.gcc.gimple.type.GimpleField;
/*    */ import org.renjin.gcc.gimple.type.GimpleRecordType;
/*    */ import org.renjin.gcc.gimple.type.GimpleRecordTypeDef;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class RecordTypeStrategy<ExprT extends GExpr>
/*    */   implements TypeStrategy<ExprT>
/*    */ {
/*    */   protected final GimpleRecordTypeDef recordTypeDef;
/*    */   protected final GimpleRecordType recordType;
/*    */   
/*    */   public RecordTypeStrategy(GimpleRecordTypeDef recordTypeDef) {
/* 35 */     this.recordType = new GimpleRecordType(recordTypeDef);
/* 36 */     this.recordTypeDef = recordTypeDef;
/*    */   }
/*    */   
/*    */   public GimpleRecordType getRecordType() {
/* 40 */     return this.recordType;
/*    */   }
/*    */   
/*    */   public GimpleRecordTypeDef getRecordTypeDef() {
/* 44 */     return this.recordTypeDef;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static boolean isCircularField(GimpleRecordTypeDef typeDef, GimpleField gimpleField) {
/* 50 */     if (gimpleField.getType() instanceof GimpleRecordType) {
/* 51 */       GimpleRecordType recordType = (GimpleRecordType)gimpleField.getType();
/* 52 */       if (recordType.getId().equals(typeDef.getId())) {
/* 53 */         return true;
/*    */       }
/*    */     } 
/* 56 */     return false;
/*    */   }
/*    */   
/*    */   public final GimpleRecordType getGimpleType() {
/* 60 */     return this.recordType;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/type/record/RecordTypeStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */