/*     */ package org.renjin.gcc.gimple;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import org.renjin.gcc.gimple.expr.GimpleExpr;
/*     */ import org.renjin.gcc.gimple.expr.GimpleVariableRef;
/*     */ import org.renjin.gcc.gimple.type.GimpleType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GimpleVarDecl
/*     */   implements GimpleDecl
/*     */ {
/*     */   private long id;
/*     */   private GimpleType type;
/*     */   private String name;
/*     */   private String mangledName;
/*     */   private GimpleExpr value;
/*     */   private GimpleCompilationUnit unit;
/*     */   private boolean global;
/*     */   @JsonProperty("const")
/*     */   private boolean constant;
/*     */   private boolean extern;
/*     */   private boolean weak;
/*     */   @JsonProperty("static")
/*     */   private boolean _static;
/*     */   @JsonProperty("public")
/*     */   private boolean _public;
/*     */   private boolean addressable;
/*     */   
/*     */   public long getId() {
/*  62 */     return this.id;
/*     */   }
/*     */   
/*     */   public void setId(long id) {
/*  66 */     this.id = id;
/*     */   }
/*     */   
/*     */   public GimpleType getType() {
/*  70 */     return this.type;
/*     */   }
/*     */   
/*     */   public void setType(GimpleType type) {
/*  74 */     this.type = type;
/*     */   }
/*     */   
/*     */   public String getName() {
/*  78 */     if (this.name != null) {
/*  79 */       return this.name;
/*     */     }
/*  81 */     return "T" + Math.abs(this.id);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getNameIfPresent() {
/*  86 */     if (this.mangledName != null) {
/*  87 */       return this.mangledName;
/*     */     }
/*  89 */     return this.name;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getNameIfPresent(String suffix) {
/*  94 */     if (this.mangledName != null)
/*  95 */       return this.mangledName + "$" + suffix; 
/*  96 */     if (this.name != null) {
/*  97 */       return this.name + "$" + suffix;
/*     */     }
/*  99 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getMangledName() {
/* 104 */     if (this.mangledName == null) {
/* 105 */       return this.name;
/*     */     }
/* 107 */     return this.mangledName;
/*     */   }
/*     */   
/*     */   public void setMangledName(String mangledName) {
/* 111 */     this.mangledName = mangledName;
/*     */   }
/*     */   
/*     */   public boolean isNamed() {
/* 115 */     return (this.name != null);
/*     */   }
/*     */   
/*     */   public boolean isConstant() {
/* 119 */     return this.constant;
/*     */   }
/*     */   
/*     */   public void setConstant(boolean constant) {
/* 123 */     this.constant = constant;
/*     */   }
/*     */   
/*     */   public void setName(String name) {
/* 127 */     this.name = name;
/*     */   }
/*     */   
/*     */   public GimpleExpr getValue() {
/* 131 */     return this.value;
/*     */   }
/*     */   
/*     */   public void setValue(GimpleExpr value) {
/* 135 */     this.value = value;
/*     */   }
/*     */   
/*     */   public boolean isAddressable() {
/* 139 */     return this.addressable;
/*     */   }
/*     */   
/*     */   public void setAddressable(boolean addressable) {
/* 143 */     this.addressable = addressable;
/*     */   }
/*     */   
/*     */   public GimpleCompilationUnit getUnit() {
/* 147 */     return this.unit;
/*     */   }
/*     */   
/*     */   public void setUnit(GimpleCompilationUnit unit) {
/* 151 */     this.unit = unit;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isPublic() {
/* 159 */     return this._public;
/*     */   }
/*     */   
/*     */   public void setPublic(boolean _public) {
/* 163 */     this._public = _public;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 168 */     StringBuilder s = (new StringBuilder()).append(this.type).append(" ").append(getName());
/* 169 */     if (this.value != null) {
/* 170 */       s.append(" = ").append(this.value);
/*     */     }
/* 172 */     return s.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isExtern() {
/* 180 */     return this.extern;
/*     */   }
/*     */   
/*     */   public void setExtern(boolean extern) {
/* 184 */     this.extern = extern;
/*     */   }
/*     */   
/*     */   public boolean isWeak() {
/* 188 */     return this.weak;
/*     */   }
/*     */   
/*     */   public void setWeak(boolean weak) {
/* 192 */     this.weak = weak;
/*     */   }
/*     */   
/*     */   public boolean isStatic() {
/* 196 */     return this._static;
/*     */   }
/*     */   
/*     */   public void setStatic(boolean _static) {
/* 200 */     this._static = _static;
/*     */   }
/*     */   
/*     */   public GimpleVariableRef newRef() {
/* 204 */     return new GimpleVariableRef(this.id, this.type);
/*     */   }
/*     */ 
/*     */   
/*     */   public void accept(GimpleExprVisitor visitor) {
/* 209 */     if (this.value != null) {
/* 210 */       this.value.accept(visitor);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isGlobal() {
/* 215 */     return this.global;
/*     */   }
/*     */   
/*     */   public void setGlobal(boolean global) {
/* 219 */     this.global = global;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/gimple/GimpleVarDecl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */