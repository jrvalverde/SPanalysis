/*    */ package org.renjin.gcc.codegen.condition;
/*    */ 
/*    */ import org.renjin.gcc.codegen.MethodGenerator;
/*    */ import org.renjin.gcc.codegen.expr.JExpr;
/*    */ import org.renjin.gcc.gimple.GimpleOp;
/*    */ import org.renjin.repackaged.asm.Label;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Comparison
/*    */   implements ConditionGenerator
/*    */ {
/*    */   private final GimpleOp op;
/*    */   private final JExpr flag;
/*    */   
/*    */   public Comparison(GimpleOp op, JExpr flag) {
/* 37 */     this.op = op;
/* 38 */     this.flag = flag;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void emitJump(MethodGenerator mv, Label trueLabel, Label falseLabel) {
/* 44 */     this.flag.load(mv);
/*    */     
/* 46 */     switch (this.op) {
/*    */       
/*    */       case LT_EXPR:
/* 49 */         mv.visitJumpInsn(155, trueLabel);
/*    */         break;
/*    */ 
/*    */       
/*    */       case LE_EXPR:
/* 54 */         mv.visitJumpInsn(158, trueLabel);
/*    */         break;
/*    */       
/*    */       case EQ_EXPR:
/* 58 */         mv.visitJumpInsn(153, trueLabel);
/*    */         break;
/*    */       
/*    */       case NE_EXPR:
/* 62 */         mv.visitJumpInsn(154, trueLabel);
/*    */         break;
/*    */       
/*    */       case UNGT_EXPR:
/*    */       case GT_EXPR:
/* 67 */         mv.visitJumpInsn(157, trueLabel);
/*    */         break;
/*    */       
/*    */       case GE_EXPR:
/* 71 */         mv.visitJumpInsn(156, trueLabel);
/*    */         break;
/*    */       
/*    */       default:
/* 75 */         throw new UnsupportedOperationException("op: " + this.op);
/*    */     } 
/*    */     
/* 78 */     mv.goTo(falseLabel);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/condition/Comparison.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */