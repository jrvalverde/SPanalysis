/*    */ package org.renjin.gcc.codegen.condition;
/*    */ 
/*    */ import org.renjin.gcc.codegen.MethodGenerator;
/*    */ import org.renjin.gcc.codegen.expr.JExpr;
/*    */ import org.renjin.repackaged.asm.Label;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ObjectIsCondition
/*    */   implements ConditionGenerator
/*    */ {
/*    */   private JExpr x;
/*    */   private JExpr y;
/*    */   
/*    */   public ObjectIsCondition(JExpr x, JExpr y) {
/* 35 */     this.x = x;
/* 36 */     this.y = y;
/*    */   }
/*    */ 
/*    */   
/*    */   public void emitJump(MethodGenerator mv, Label trueLabel, Label falseLabel) {
/* 41 */     this.x.load(mv);
/* 42 */     this.y.load(mv);
/* 43 */     mv.visitJumpInsn(165, trueLabel);
/* 44 */     mv.goTo(falseLabel);
/*    */   }
/*    */   
/*    */   public ConditionGenerator inverse() {
/* 48 */     return new InverseConditionGenerator(this);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/condition/ObjectIsCondition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */