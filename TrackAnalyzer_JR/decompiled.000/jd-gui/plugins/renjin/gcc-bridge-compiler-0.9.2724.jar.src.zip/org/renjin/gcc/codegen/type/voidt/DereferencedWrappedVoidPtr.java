/*    */ package org.renjin.gcc.codegen.type.voidt;
/*    */ 
/*    */ import org.renjin.gcc.codegen.MethodGenerator;
/*    */ import org.renjin.gcc.codegen.condition.ConditionGenerator;
/*    */ import org.renjin.gcc.codegen.expr.GExpr;
/*    */ import org.renjin.gcc.codegen.expr.JExpr;
/*    */ import org.renjin.gcc.codegen.expr.PtrExpr;
/*    */ import org.renjin.gcc.codegen.fatptr.FatPtr;
/*    */ import org.renjin.gcc.codegen.fatptr.WrappedFatPtrExpr;
/*    */ import org.renjin.gcc.codegen.type.NumericExpr;
/*    */ import org.renjin.gcc.codegen.type.UnsupportedCastException;
/*    */ import org.renjin.gcc.codegen.vptr.VArrayExpr;
/*    */ import org.renjin.gcc.codegen.vptr.VPtrExpr;
/*    */ import org.renjin.gcc.codegen.vptr.VPtrRecordExpr;
/*    */ import org.renjin.gcc.gimple.GimpleOp;
/*    */ import org.renjin.gcc.gimple.type.GimpleArrayType;
/*    */ import org.renjin.gcc.gimple.type.GimpleRecordType;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DereferencedWrappedVoidPtr
/*    */   extends VoidPtrExpr
/*    */ {
/*    */   private WrappedFatPtrExpr wrapperInstance;
/*    */   
/*    */   public DereferencedWrappedVoidPtr(WrappedFatPtrExpr wrapperInstance) {
/* 42 */     super((JExpr)wrapperInstance.valueExpr(), (FatPtr)wrapperInstance);
/* 43 */     this.wrapperInstance = wrapperInstance;
/*    */   }
/*    */ 
/*    */   
/*    */   public void store(MethodGenerator mv, GExpr rhs) {
/* 48 */     if (rhs instanceof VoidPtrExpr) {
/* 49 */       this.wrapperInstance.wrap().load(mv);
/* 50 */       ((VoidPtrExpr)rhs).jexpr().load(mv);
/* 51 */       mv.invokevirtual(this.wrapperInstance.wrap().getType(), "set", 
/* 52 */           Type.getMethodDescriptor(Type.VOID_TYPE, new Type[] { Type.getType(Object.class) }), false);
/*    */     } else {
/*    */       
/* 55 */       throw new UnsupportedOperationException("TODO: rhs = " + rhs.getClass().getName());
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public VPtrExpr toVPtrExpr() throws UnsupportedCastException {
/* 62 */     throw new UnsupportedOperationException("TODO");
/*    */   }
/*    */ 
/*    */   
/*    */   public VPtrRecordExpr toVPtrRecord(GimpleRecordType recordType) {
/* 67 */     throw new UnsupportedOperationException("TODO");
/*    */   }
/*    */ 
/*    */   
/*    */   public VArrayExpr toVArray(GimpleArrayType arrayType) {
/* 72 */     throw new UnsupportedOperationException("TODO");
/*    */   }
/*    */ 
/*    */   
/*    */   public NumericExpr toNumericExpr() {
/* 77 */     throw new UnsupportedOperationException("TODO");
/*    */   }
/*    */ 
/*    */   
/*    */   public void memorySet(MethodGenerator mv, JExpr byteValue, JExpr length) {
/* 82 */     throw new UnsupportedOperationException("TODO");
/*    */   }
/*    */ 
/*    */   
/*    */   public PtrExpr realloc(MethodGenerator mv, JExpr newSizeInBytes) {
/* 87 */     throw new UnsupportedOperationException("TODO");
/*    */   }
/*    */ 
/*    */   
/*    */   public PtrExpr pointerPlus(MethodGenerator mv, JExpr offsetInBytes) {
/* 92 */     throw new UnsupportedOperationException("TODO");
/*    */   }
/*    */ 
/*    */   
/*    */   public ConditionGenerator comparePointer(MethodGenerator mv, GimpleOp op, GExpr otherPointer) {
/* 97 */     throw new UnsupportedOperationException("TODO");
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/type/voidt/DereferencedWrappedVoidPtr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */