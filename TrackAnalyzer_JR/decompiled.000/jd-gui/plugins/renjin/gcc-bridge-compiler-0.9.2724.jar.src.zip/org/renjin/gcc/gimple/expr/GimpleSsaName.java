/*    */ package org.renjin.gcc.gimple.expr;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.function.Predicate;
/*    */ import org.renjin.gcc.gimple.GimpleExprVisitor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GimpleSsaName
/*    */   extends GimpleLValue
/*    */ {
/*    */   private GimpleExpr var;
/*    */   private int version;
/*    */   private boolean defaultDefinition;
/*    */   private boolean occursInAbnormalPhi;
/*    */   
/*    */   public GimpleExpr getVar() {
/* 36 */     return this.var;
/*    */   }
/*    */   
/*    */   public void setVar(GimpleExpr var) {
/* 40 */     this.var = var;
/*    */   }
/*    */   
/*    */   public int getVersion() {
/* 44 */     return this.version;
/*    */   }
/*    */   
/*    */   public void setVersion(int version) {
/* 48 */     this.version = version;
/*    */   }
/*    */   
/*    */   public boolean isDefaultDefinition() {
/* 52 */     return this.defaultDefinition;
/*    */   }
/*    */   
/*    */   public void setDefaultDefinition(boolean defaultDefinition) {
/* 56 */     this.defaultDefinition = defaultDefinition;
/*    */   }
/*    */   
/*    */   public boolean isOccursInAbnormalPhi() {
/* 60 */     return this.occursInAbnormalPhi;
/*    */   }
/*    */   
/*    */   public void setOccursInAbnormalPhi(boolean occursInAbnormalPhi) {
/* 64 */     this.occursInAbnormalPhi = occursInAbnormalPhi;
/*    */   }
/*    */ 
/*    */   
/*    */   public void find(Predicate<? super GimpleExpr> predicate, List<GimpleExpr> results) {
/* 69 */     findOrDescend(this.var, predicate, results);
/*    */   }
/*    */ 
/*    */   
/*    */   public void replaceAll(Predicate<? super GimpleExpr> predicate, GimpleExpr newExpr) {
/* 74 */     this.var = replaceOrDescend(this.var, predicate, newExpr);
/*    */   }
/*    */ 
/*    */   
/*    */   public void accept(GimpleExprVisitor visitor) {
/* 79 */     visitor.visitSsaName(this);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 84 */     if (this.defaultDefinition) {
/* 85 */       return this.var + toSubscript(0);
/*    */     }
/* 87 */     return this.var + toSubscript(this.version);
/*    */   }
/*    */ 
/*    */   
/*    */   private String toSubscript(int version) {
/* 92 */     String digits = Integer.toString(version);
/* 93 */     StringBuilder sb = new StringBuilder(digits.length());
/* 94 */     for (int i = 0; i != digits.length(); i++) {
/* 95 */       int digit = digits.charAt(i) - 48;
/* 96 */       sb.appendCodePoint(8320 + digit);
/*    */     } 
/* 98 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/gimple/expr/GimpleSsaName.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */