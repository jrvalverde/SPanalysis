/*     */ package org.renjin.gcc.gimple.expr;
/*     */ 
/*     */ import java.util.function.Predicate;
/*     */ import org.renjin.gcc.gimple.GimpleExprVisitor;
/*     */ import org.renjin.gcc.gimple.type.GimpleType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GimpleVariableRef
/*     */   extends GimpleLValue
/*     */   implements GimpleSymbolRef
/*     */ {
/*     */   private long id;
/*     */   private String name;
/*     */   private String mangledName;
/*     */   
/*     */   public GimpleVariableRef() {}
/*     */   
/*     */   public GimpleVariableRef(long id, GimpleType type) {
/*  35 */     this.id = id;
/*  36 */     setType(type);
/*     */   }
/*     */   
/*     */   public long getId() {
/*  40 */     return this.id;
/*     */   }
/*     */   
/*     */   public void setId(long id) {
/*  44 */     this.id = id;
/*     */   }
/*     */   
/*     */   public void setName(String name) {
/*  48 */     this.name = name;
/*     */   }
/*     */   
/*     */   public String getName() {
/*  52 */     return this.name;
/*     */   }
/*     */   
/*     */   public String getMangledName() {
/*  56 */     if (this.mangledName != null) {
/*  57 */       return this.mangledName;
/*     */     }
/*  59 */     return this.name;
/*     */   }
/*     */   
/*     */   public void setMangledName(String mangledName) {
/*  63 */     this.mangledName = mangledName;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/*  68 */     if (this == o) {
/*  69 */       return true;
/*     */     }
/*  71 */     if (o == null || getClass() != o.getClass()) {
/*  72 */       return false;
/*     */     }
/*     */     
/*  75 */     GimpleVariableRef that = (GimpleVariableRef)o;
/*     */     
/*  77 */     if (this.id != that.id) {
/*  78 */       return false;
/*     */     }
/*  80 */     if ((this.name != null) ? !this.name.equals(that.name) : (that.name != null)) return false;
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  86 */     int result = (int)(this.id ^ this.id >>> 32L);
/*  87 */     result = 31 * result + ((this.name != null) ? this.name.hashCode() : 0);
/*  88 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  93 */     if (this.name != null) {
/*  94 */       return this.name;
/*     */     }
/*  96 */     return "T" + Math.abs(this.id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void replaceAll(Predicate<? super GimpleExpr> predicate, GimpleExpr newExpr) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void accept(GimpleExprVisitor visitor) {
/* 107 */     visitor.visitVariableRef(this);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/gimple/expr/GimpleVariableRef.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */