/*    */ package org.renjin.gcc.codegen.type.record;
/*    */ 
/*    */ import org.renjin.gcc.codegen.condition.ConditionGenerator;
/*    */ import org.renjin.gcc.codegen.condition.IntegerComparison;
/*    */ import org.renjin.gcc.codegen.condition.ObjectIsCondition;
/*    */ import org.renjin.gcc.codegen.expr.Expressions;
/*    */ import org.renjin.gcc.codegen.expr.JExpr;
/*    */ import org.renjin.gcc.gimple.GimpleOp;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReferenceConditions
/*    */ {
/*    */   public static ConditionGenerator compare(GimpleOp op, JExpr x, JExpr y) {
/* 41 */     switch (op) {
/*    */       case EQ_EXPR:
/* 43 */         return (ConditionGenerator)new ObjectIsCondition(x, y);
/*    */       case NE_EXPR:
/* 45 */         return (new ObjectIsCondition(x, y)).inverse();
/*    */     } 
/* 47 */     return (ConditionGenerator)new IntegerComparison(op, Expressions.identityHash(x), Expressions.identityHash(y));
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/type/record/ReferenceConditions.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */