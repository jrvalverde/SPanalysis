/*    */ package org.renjin.gcc.codegen.lib;
/*    */ 
/*    */ import org.renjin.gcc.codegen.call.CallGenerator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SymbolFunction
/*    */ {
/*    */   private String alias;
/*    */   private CallGenerator call;
/*    */   
/*    */   public SymbolFunction(String alias, CallGenerator call) {
/* 30 */     this.alias = alias;
/* 31 */     this.call = call;
/*    */   }
/*    */   
/*    */   public String getAlias() {
/* 35 */     return this.alias;
/*    */   }
/*    */   
/*    */   public CallGenerator getCall() {
/* 39 */     return this.call;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/lib/SymbolFunction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */