/*     */ package org.renjin.gcc;
/*     */ 
/*     */ import java.lang.invoke.MethodHandle;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Modifier;
/*     */ import org.renjin.gcc.codegen.array.ArrayTypeStrategy;
/*     */ import org.renjin.gcc.codegen.expr.Expressions;
/*     */ import org.renjin.gcc.codegen.expr.GExpr;
/*     */ import org.renjin.gcc.codegen.expr.JExpr;
/*     */ import org.renjin.gcc.codegen.fatptr.FatPtrPair;
/*     */ import org.renjin.gcc.codegen.fatptr.ValueFunction;
/*     */ import org.renjin.gcc.codegen.type.PointerTypeStrategy;
/*     */ import org.renjin.gcc.codegen.type.TypeOracle;
/*     */ import org.renjin.gcc.codegen.type.TypeStrategy;
/*     */ import org.renjin.gcc.codegen.type.fun.FunPtrStrategy;
/*     */ import org.renjin.gcc.codegen.type.primitive.PrimitiveTypeStrategy;
/*     */ import org.renjin.gcc.codegen.type.primitive.PrimitiveValueFunction;
/*     */ import org.renjin.gcc.codegen.vptr.VPtrExpr;
/*     */ import org.renjin.gcc.codegen.vptr.VPtrRecordTypeStrategy;
/*     */ import org.renjin.gcc.codegen.vptr.VPtrStrategy;
/*     */ import org.renjin.gcc.gimple.GimpleVarDecl;
/*     */ import org.renjin.gcc.gimple.type.GimpleArrayType;
/*     */ import org.renjin.gcc.gimple.type.GimplePrimitiveType;
/*     */ import org.renjin.gcc.gimple.type.GimpleRecordType;
/*     */ import org.renjin.gcc.runtime.Ptr;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProvidedGlobalVarField
/*     */   implements ProvidedGlobalVar
/*     */ {
/*     */   private Field field;
/*     */   
/*     */   public ProvidedGlobalVarField(Field field) {
/*  51 */     this.field = field;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GExpr createExpr(GimpleVarDecl decl, TypeOracle typeOracle) {
/*     */     TypeStrategy strategy;
/*  63 */     if (typeOracle.getRecordTypes().isMappedToRecordType(this.field.getType()))
/*     */     
/*  65 */     { PointerTypeStrategy pointerTypeStrategy = typeOracle.getRecordTypes().getPointerStrategyFor(this.field.getType()); }
/*     */     
/*  67 */     else if (this.field.getType().isPrimitive())
/*  68 */     { PrimitiveTypeStrategy primitiveTypeStrategy = new PrimitiveTypeStrategy((GimplePrimitiveType)decl.getType()); }
/*     */     
/*  70 */     else if (this.field.getType().equals(MethodHandle[].class) && decl.getType() instanceof GimpleArrayType)
/*  71 */     { GimpleArrayType arrayType = (GimpleArrayType)decl.getType();
/*  72 */       ArrayTypeStrategy arrayTypeStrategy = (new FunPtrStrategy()).arrayOf(arrayType); }
/*     */     
/*  74 */     else if (Ptr.class.isAssignableFrom(this.field.getType()))
/*  75 */     { if (decl.getType() instanceof GimpleRecordType) {
/*  76 */         VPtrRecordTypeStrategy vPtrRecordTypeStrategy = new VPtrRecordTypeStrategy(typeOracle.getRecordTypeDef((GimpleRecordType)decl.getType()));
/*     */       } else {
/*  78 */         VPtrStrategy vPtrStrategy = new VPtrStrategy(decl.getType().getBaseType());
/*     */       }  }
/*  80 */     else { if (decl.getType() instanceof GimpleRecordType && this.field.getType().isArray()) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  87 */         Class<?> componentType = this.field.getType().getComponentType();
/*  88 */         GimplePrimitiveType primitiveComponentType = GimplePrimitiveType.fromJvmType(Type.getType(componentType));
/*  89 */         FatPtrPair fatPtr = new FatPtrPair((ValueFunction)new PrimitiveValueFunction(primitiveComponentType), (JExpr)Expressions.staticField(this.field));
/*  90 */         VPtrExpr vptr = fatPtr.toVPtrExpr();
/*  91 */         return vptr.valueOf(decl.getType());
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/*  96 */       strategy = typeOracle.forType(decl.getType()); }
/*     */ 
/*     */     
/*  99 */     boolean readOnly = Modifier.isFinal(this.field.getModifiers());
/*     */     
/* 101 */     return strategy.providedGlobalVariable(decl, (JExpr)Expressions.staticField(this.field), readOnly);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/ProvidedGlobalVarField.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */