package org.renjin.gcc.codegen.expr;

public interface GSimpleExpr extends GExpr {
  JExpr jexpr();
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/expr/GSimpleExpr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */