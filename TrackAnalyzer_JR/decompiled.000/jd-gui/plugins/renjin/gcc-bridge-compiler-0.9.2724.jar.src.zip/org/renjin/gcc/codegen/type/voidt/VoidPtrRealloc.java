/*    */ package org.renjin.gcc.codegen.type.voidt;
/*    */ 
/*    */ import javax.annotation.Nonnull;
/*    */ import org.renjin.gcc.codegen.MethodGenerator;
/*    */ import org.renjin.gcc.codegen.expr.Expressions;
/*    */ import org.renjin.gcc.codegen.expr.JExpr;
/*    */ import org.renjin.gcc.runtime.Ptr;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VoidPtrRealloc
/*    */   implements JExpr
/*    */ {
/*    */   private final JExpr pointer;
/*    */   private final JExpr newSizeInBytes;
/*    */   
/*    */   public VoidPtrRealloc(JExpr pointer, JExpr newSizeInBytes) {
/* 38 */     this.pointer = pointer;
/* 39 */     this.newSizeInBytes = newSizeInBytes;
/*    */   }
/*    */ 
/*    */   
/*    */   @Nonnull
/*    */   public Type getType() {
/* 45 */     return Type.getType(Object.class);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void load(@Nonnull MethodGenerator mv) {
/* 54 */     JExpr ptr = Expressions.cast(this.pointer, Type.getType(Ptr.class));
/* 55 */     ptr.load(mv);
/*    */     
/* 57 */     this.newSizeInBytes.load(mv);
/*    */     
/* 59 */     mv.invokeinterface(Ptr.class, "realloc", Type.getType(Ptr.class), new Type[] { Type.INT_TYPE });
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/type/voidt/VoidPtrRealloc.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */