/*    */ package org.renjin.gcc.codegen.type.primitive;
/*    */ 
/*    */ import javax.annotation.Nonnull;
/*    */ import org.renjin.gcc.codegen.MethodGenerator;
/*    */ import org.renjin.gcc.codegen.expr.JExpr;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StringConstant
/*    */   implements JExpr
/*    */ {
/*    */   private String constant;
/*    */   
/*    */   public StringConstant(String constant) {
/* 35 */     this.constant = constant;
/*    */   }
/*    */   
/*    */   public int getLength() {
/* 39 */     return this.constant.length();
/*    */   }
/*    */ 
/*    */   
/*    */   @Nonnull
/*    */   public Type getType() {
/* 45 */     return Type.getType("[B");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void load(@Nonnull MethodGenerator mv) {
/* 52 */     mv.aconst(this.constant);
/* 53 */     mv.invokevirtual(String.class, "getBytes", getType(), new Type[0]);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/type/primitive/StringConstant.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */