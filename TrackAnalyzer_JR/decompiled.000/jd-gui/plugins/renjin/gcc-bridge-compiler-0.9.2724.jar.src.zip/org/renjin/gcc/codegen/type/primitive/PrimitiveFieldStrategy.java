/*    */ package org.renjin.gcc.codegen.type.primitive;
/*    */ 
/*    */ import org.renjin.gcc.codegen.MethodGenerator;
/*    */ import org.renjin.gcc.codegen.expr.Expressions;
/*    */ import org.renjin.gcc.codegen.expr.GExpr;
/*    */ import org.renjin.gcc.codegen.expr.JExpr;
/*    */ import org.renjin.gcc.codegen.expr.JLValue;
/*    */ import org.renjin.gcc.codegen.fatptr.Wrappers;
/*    */ import org.renjin.gcc.codegen.type.SingleFieldStrategy;
/*    */ import org.renjin.gcc.gimple.type.GimplePrimitiveType;
/*    */ import org.renjin.gcc.gimple.type.GimpleType;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PrimitiveFieldStrategy
/*    */   extends SingleFieldStrategy
/*    */ {
/*    */   private PrimitiveType type;
/*    */   
/*    */   public PrimitiveFieldStrategy(Type ownerClass, String fieldName, PrimitiveType fieldType) {
/* 37 */     super(ownerClass, fieldName, fieldType.jvmType());
/* 38 */     this.type = fieldType;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public GExpr memberExpr(MethodGenerator mv, JExpr instance, int offset, int size, GimpleType expectedType) {
/* 44 */     JLValue fieldExpr = Expressions.field(instance, this.fieldType, this.fieldName);
/*    */     
/* 46 */     if (expectedType instanceof GimplePrimitiveType) {
/* 47 */       GimplePrimitiveType primitiveType = (GimplePrimitiveType)expectedType;
/* 48 */       if (!fieldExpr.getType().equals(primitiveType.jvmType())) {
/* 49 */         throw new UnsupportedOperationException("TODO: expectedType = " + expectedType);
/*    */       }
/*    */       
/* 52 */       if (size != 0 && (offset != 0 || size != this.type.gimpleType().getSize())) {
/* 53 */         if (!primitiveType.jvmType().equals(Type.BYTE_TYPE))
/* 54 */           throw new UnsupportedOperationException(
/* 55 */               String.format("Unsupported bitfield: expected type = %s, offset = %d, size = %d", new Object[] {
/* 56 */                   expectedType, Integer.valueOf(offset), Integer.valueOf(size)
/*    */                 })); 
/* 58 */         fieldExpr = new BitFieldExpr(this.ownerClass, instance, this.fieldName, offset, size);
/*    */       } 
/* 60 */       return this.type.fromStackValue((JExpr)fieldExpr);
/*    */     } 
/*    */     
/* 63 */     throw new UnsupportedOperationException("expectedType: " + expectedType);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void memset(MethodGenerator mv, JExpr instance, JExpr byteValue, JExpr byteCount) {
/* 69 */     instance.load(mv);
/* 70 */     byteValue.load(mv);
/* 71 */     mv.invokestatic(Wrappers.wrapperType(this.fieldType), "memset", Type.getMethodDescriptor(this.fieldType, new Type[] { Type.INT_TYPE }));
/* 72 */     mv.putfield(this.ownerClass, this.fieldName, this.fieldType);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/type/primitive/PrimitiveFieldStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */