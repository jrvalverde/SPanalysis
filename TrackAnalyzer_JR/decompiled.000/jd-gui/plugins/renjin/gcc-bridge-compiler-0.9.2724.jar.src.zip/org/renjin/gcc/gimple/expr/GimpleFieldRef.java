/*     */ package org.renjin.gcc.gimple.expr;
/*     */ 
/*     */ import java.util.function.Predicate;
/*     */ import org.renjin.gcc.gimple.GimpleExprVisitor;
/*     */ import org.renjin.gcc.gimple.type.GimpleType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GimpleFieldRef
/*     */   extends GimpleExpr
/*     */ {
/*     */   private long id;
/*     */   private int offset;
/*     */   private int size;
/*     */   private String name;
/*     */   
/*     */   public GimpleFieldRef() {}
/*     */   
/*     */   public GimpleFieldRef(String name, int offset, GimpleType type) {
/*  38 */     this.offset = offset;
/*  39 */     setType(type);
/*  40 */     this.size = type.getSize();
/*  41 */     this.name = name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getOffset() {
/*  49 */     return this.offset;
/*     */   }
/*     */   
/*     */   public int getOffsetBytes() {
/*  53 */     return this.offset / 8;
/*     */   }
/*     */   
/*     */   public void setOffset(int offset) {
/*  57 */     this.offset = offset;
/*     */   }
/*     */   
/*     */   public int getSize() {
/*  61 */     return this.size;
/*     */   }
/*     */   
/*     */   public void setSize(int size) {
/*  65 */     this.size = size;
/*     */   }
/*     */   
/*     */   public String getName() {
/*  69 */     return this.name;
/*     */   }
/*     */   
/*     */   public void setName(String name) {
/*  73 */     this.name = name;
/*     */   }
/*     */   
/*     */   public long getId() {
/*  77 */     return this.id;
/*     */   }
/*     */   
/*     */   public void setId(long id) {
/*  81 */     this.id = id;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  86 */     if (this.name == null) {
/*  87 */       return "field@" + this.offset;
/*     */     }
/*  89 */     if (this.name.contains(".")) {
/*  90 */       return "[" + this.name + "]";
/*     */     }
/*  92 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void replaceAll(Predicate<? super GimpleExpr> predicate, GimpleExpr newExpr) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void accept(GimpleExprVisitor visitor) {
/* 102 */     visitor.visitFieldRef(this);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/gimple/expr/GimpleFieldRef.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */