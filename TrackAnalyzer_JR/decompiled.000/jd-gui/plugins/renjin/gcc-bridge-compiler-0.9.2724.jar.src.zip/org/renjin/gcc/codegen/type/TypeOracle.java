/*     */ package org.renjin.gcc.codegen.type;
/*     */ 
/*     */ import java.lang.invoke.MethodHandle;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.renjin.gcc.InternalCompilerException;
/*     */ import org.renjin.gcc.annotations.Struct;
/*     */ import org.renjin.gcc.codegen.array.ArrayTypeStrategy;
/*     */ import org.renjin.gcc.codegen.fatptr.FatPtrValueFunction;
/*     */ import org.renjin.gcc.codegen.fatptr.ValueFunction;
/*     */ import org.renjin.gcc.codegen.fatptr.WrappedFatPtrParamStrategy;
/*     */ import org.renjin.gcc.codegen.type.complex.ComplexTypeStrategy;
/*     */ import org.renjin.gcc.codegen.type.fun.FunPtrStrategy;
/*     */ import org.renjin.gcc.codegen.type.fun.FunTypeStrategy;
/*     */ import org.renjin.gcc.codegen.type.primitive.PrimitiveParamStrategy;
/*     */ import org.renjin.gcc.codegen.type.primitive.PrimitiveTypeStrategy;
/*     */ import org.renjin.gcc.codegen.type.primitive.PrimitiveValueFunction;
/*     */ import org.renjin.gcc.codegen.type.primitive.StringParamStrategy;
/*     */ import org.renjin.gcc.codegen.type.record.RecordArrayReturnStrategy;
/*     */ import org.renjin.gcc.codegen.type.record.RecordArrayValueFunction;
/*     */ import org.renjin.gcc.codegen.type.record.RecordTypeDefMap;
/*     */ import org.renjin.gcc.codegen.type.record.RecordTypeStrategy;
/*     */ import org.renjin.gcc.codegen.type.voidt.VoidPtrParamStrategy;
/*     */ import org.renjin.gcc.codegen.type.voidt.VoidPtrReturnStrategy;
/*     */ import org.renjin.gcc.codegen.type.voidt.VoidReturnStrategy;
/*     */ import org.renjin.gcc.codegen.type.voidt.VoidTypeStrategy;
/*     */ import org.renjin.gcc.codegen.vptr.VPtrParamStrategy;
/*     */ import org.renjin.gcc.codegen.vptr.VPtrReturnStrategy;
/*     */ import org.renjin.gcc.codegen.vptr.VPtrVariadicStrategy;
/*     */ import org.renjin.gcc.gimple.GimpleCompilationUnit;
/*     */ import org.renjin.gcc.gimple.GimpleParameter;
/*     */ import org.renjin.gcc.gimple.type.GimpleArrayType;
/*     */ import org.renjin.gcc.gimple.type.GimpleComplexType;
/*     */ import org.renjin.gcc.gimple.type.GimpleField;
/*     */ import org.renjin.gcc.gimple.type.GimpleFunctionType;
/*     */ import org.renjin.gcc.gimple.type.GimpleIntegerType;
/*     */ import org.renjin.gcc.gimple.type.GimplePrimitiveType;
/*     */ import org.renjin.gcc.gimple.type.GimpleRecordType;
/*     */ import org.renjin.gcc.gimple.type.GimpleRecordTypeDef;
/*     */ import org.renjin.gcc.gimple.type.GimpleType;
/*     */ import org.renjin.gcc.runtime.BytePtr;
/*     */ import org.renjin.gcc.runtime.ObjectPtr;
/*     */ import org.renjin.gcc.runtime.Ptr;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ import org.renjin.repackaged.guava.base.Preconditions;
/*     */ import org.renjin.repackaged.guava.base.Strings;
/*     */ import org.renjin.repackaged.guava.collect.Lists;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypeOracle
/*     */ {
/*  72 */   private final RecordTypeDefMap recordTypes = new RecordTypeDefMap();
/*     */   
/*     */   public RecordTypeDefMap getRecordTypes() {
/*  75 */     return this.recordTypes;
/*     */   }
/*     */ 
/*     */   
/*     */   public void initRecords(List<GimpleCompilationUnit> units, Map<String, Type> providedRecordTypes) {
/*  80 */     this.recordTypes.init(units, providedRecordTypes);
/*     */   }
/*     */   
/*     */   public GimpleRecordTypeDef getRecordTypeDef(GimpleRecordType recordType) {
/*  84 */     return this.recordTypes.getRecordTypeDef(recordType);
/*     */   }
/*     */   
/*     */   public PointerTypeStrategy forPointerType(GimpleType type) {
/*  88 */     if (!(type instanceof org.renjin.gcc.gimple.type.GimpleIndirectType)) {
/*  89 */       throw new IllegalArgumentException("not a pointer type: " + type);
/*     */     }
/*     */     
/*  92 */     return forType(type.getBaseType()).pointerTo();
/*     */   }
/*     */   
/*     */   public ArrayTypeStrategy forArrayType(GimpleType type) {
/*  96 */     if (!(type instanceof GimpleArrayType)) {
/*  97 */       throw new IllegalArgumentException("not an array type: " + type);
/*     */     }
/*  99 */     return (ArrayTypeStrategy)forType(type);
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeStrategy forType(GimpleType type) {
/* 104 */     if (type instanceof GimplePrimitiveType) {
/* 105 */       return (TypeStrategy)new PrimitiveTypeStrategy((GimplePrimitiveType)type);
/*     */     }
/* 107 */     if (type instanceof GimpleComplexType) {
/* 108 */       return (TypeStrategy)new ComplexTypeStrategy((GimpleComplexType)type);
/*     */     }
/* 110 */     if (type instanceof GimpleFunctionType) {
/* 111 */       return (TypeStrategy)new FunTypeStrategy((GimpleFunctionType)type);
/*     */     }
/* 113 */     if (type instanceof org.renjin.gcc.gimple.type.GimpleVoidType) {
/* 114 */       return (TypeStrategy)new VoidTypeStrategy();
/*     */     }
/* 116 */     if (type instanceof GimpleRecordType) {
/* 117 */       GimpleRecordType recordType = (GimpleRecordType)type;
/* 118 */       return (TypeStrategy)forRecordType(recordType);
/*     */     } 
/* 120 */     if (type instanceof org.renjin.gcc.gimple.type.GimpleIndirectType) {
/* 121 */       return forType(type.getBaseType()).pointerTo();
/*     */     }
/* 123 */     if (type instanceof GimpleArrayType) {
/* 124 */       GimpleArrayType arrayType = (GimpleArrayType)type;
/* 125 */       return forType(arrayType.getComponentType()).arrayOf(arrayType);
/*     */     } 
/*     */     
/* 128 */     throw new UnsupportedOperationException("Unsupported type: " + type);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private RecordTypeStrategy forRecordType(GimpleRecordType recordType) {
/* 134 */     RecordTypeStrategy recordTypeStrategy = this.recordTypes.get(recordType.getId());
/* 135 */     if (recordTypeStrategy == null) {
/* 136 */       throw new InternalCompilerException(String.format("No record type for GimpleRecordType[name: %s, id: %s]", new Object[] { recordType
/* 137 */               .getName(), recordType.getId() }));
/*     */     }
/* 139 */     return recordTypeStrategy;
/*     */   }
/*     */ 
/*     */   
/*     */   public ParamStrategy forParameter(GimpleType parameterType) {
/* 144 */     return forType(parameterType).getParamStrategy();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FieldStrategy forField(Type className, GimpleField field) {
/* 155 */     String fieldName = field.getName();
/* 156 */     if (Strings.isNullOrEmpty(fieldName)) {
/* 157 */       fieldName = "$$field" + field.getOffset();
/*     */     }
/* 159 */     fieldName = fieldName.replace('.', '$');
/*     */     
/* 161 */     TypeStrategy type = forType(field.getType());
/* 162 */     if (field.isAddressed()) {
/* 163 */       return type.addressableFieldGenerator(className, fieldName);
/*     */     }
/* 165 */     return type.fieldGenerator(className, fieldName);
/*     */   }
/*     */ 
/*     */   
/*     */   public ReturnStrategy returnStrategyFor(GimpleType returnType) {
/* 170 */     return forType(returnType).getReturnStrategy();
/*     */   }
/*     */   
/*     */   public ReturnStrategy forReturnValue(Method method) {
/* 174 */     Class<?> returnType = method.getReturnType();
/* 175 */     if (returnType.equals(void.class)) {
/* 176 */       return (ReturnStrategy)new VoidReturnStrategy();
/*     */     }
/* 178 */     if (returnType.isPrimitive()) {
/* 179 */       return (new PrimitiveTypeStrategy(GimplePrimitiveType.fromJvmType(Type.getType(returnType)))).getReturnStrategy();
/*     */     }
/* 181 */     if (Ptr.class.isAssignableFrom(returnType)) {
/* 182 */       return (ReturnStrategy)new VPtrReturnStrategy();
/*     */     }
/* 184 */     if (this.recordTypes.isMappedToRecordType(returnType)) {
/* 185 */       return this.recordTypes.getPointerStrategyFor(returnType).getReturnStrategy();
/*     */     }
/* 187 */     if (returnType.equals(Object.class)) {
/* 188 */       return (ReturnStrategy)new VoidPtrReturnStrategy();
/*     */     }
/* 190 */     if (method.isAnnotationPresent((Class)Struct.class)) {
/* 191 */       Type arrayType = Type.getReturnType(method);
/* 192 */       Type componentType = Type.getType(arrayType.getDescriptor().substring(1));
/* 193 */       return (ReturnStrategy)new RecordArrayReturnStrategy(new RecordArrayValueFunction(componentType, 0, null), arrayType, 0);
/*     */     } 
/* 195 */     if (returnType.equals(MethodHandle.class)) {
/* 196 */       return (new FunPtrStrategy()).getReturnStrategy();
/*     */     }
/*     */     
/* 199 */     throw new UnsupportedOperationException(String.format("Unsupported return type %s in method %s.%s", new Object[] { returnType
/*     */             
/* 201 */             .getName(), method
/* 202 */             .getDeclaringClass().getName(), method.getName() }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<ParamStrategy> forParameterTypesOf(Method method) {
/*     */     int numParams;
/* 215 */     List<ParamStrategy> strategies = new ArrayList<>();
/*     */ 
/*     */     
/* 218 */     if (method.isVarArgs()) {
/* 219 */       numParams = (method.getParameterTypes()).length - 1;
/*     */     } else {
/* 221 */       numParams = (method.getParameterTypes()).length;
/*     */     } 
/*     */     
/* 224 */     int index = 0;
/* 225 */     while (index < numParams) {
/*     */       
/* 227 */       if (VPtrVariadicStrategy.isVarArgsPtr(method, index)) {
/*     */         break;
/*     */       }
/*     */       
/* 231 */       Class<?> paramClass = method.getParameterTypes()[index];
/* 232 */       if (paramClass.equals(ObjectPtr.class)) {
/* 233 */         strategies.add(forObjectPtrParam(method.getGenericParameterTypes()[index]));
/* 234 */         index++; continue;
/*     */       } 
/* 236 */       if (Ptr.class.isAssignableFrom(paramClass)) {
/* 237 */         strategies.add(new VPtrParamStrategy(Type.getType(paramClass)));
/* 238 */         index++; continue;
/*     */       } 
/* 240 */       if (paramClass.isPrimitive()) {
/* 241 */         strategies.add(new PrimitiveParamStrategy(GimplePrimitiveType.fromJvmType(Type.getType(paramClass))));
/* 242 */         index++; continue;
/*     */       } 
/* 244 */       if (paramClass.equals(String.class)) {
/* 245 */         strategies.add(new StringParamStrategy());
/* 246 */         index++; continue;
/*     */       } 
/* 248 */       if (this.recordTypes.isMappedToRecordType(paramClass)) {
/* 249 */         strategies.add(this.recordTypes.getPointerStrategyFor(paramClass).getParamStrategy());
/* 250 */         index++; continue;
/*     */       } 
/* 252 */       if (paramClass.equals(MethodHandle.class)) {
/* 253 */         strategies.add((new FunPtrStrategy()).getParamStrategy());
/* 254 */         index++; continue;
/*     */       } 
/* 256 */       if (paramClass.equals(Object.class)) {
/* 257 */         strategies.add(new VoidPtrParamStrategy());
/* 258 */         index++;
/*     */         continue;
/*     */       } 
/* 261 */       throw new UnsupportedOperationException(String.format("Unsupported parameter %d of type %s", new Object[] {
/*     */               
/* 263 */               Integer.valueOf(index), paramClass
/* 264 */               .getName()
/*     */             }));
/*     */     } 
/* 267 */     return strategies;
/*     */   }
/*     */ 
/*     */   
/*     */   private Class objectPtrBaseType(Type type) {
/* 272 */     if (!(type instanceof ParameterizedType)) {
/* 273 */       throw new InternalCompilerException(ObjectPtr.class.getSimpleName() + " parameters must be parameterized");
/*     */     }
/* 275 */     ParameterizedType parameterizedType = (ParameterizedType)type;
/* 276 */     return (Class)parameterizedType.getActualTypeArguments()[0];
/*     */   }
/*     */   
/*     */   private ParamStrategy forObjectPtrParam(Type type) {
/* 280 */     Class baseType = objectPtrBaseType(type);
/* 281 */     if (baseType.equals(BytePtr.class)) {
/* 282 */       return (ParamStrategy)new WrappedFatPtrParamStrategy((ValueFunction)new FatPtrValueFunction((ValueFunction)new PrimitiveValueFunction((GimplePrimitiveType)new GimpleIntegerType(8))));
/*     */     }
/* 284 */     if (this.recordTypes.isMappedToRecordType(baseType)) {
/* 285 */       RecordTypeStrategy recordTypeStrategy = this.recordTypes.getStrategyFor(baseType);
/* 286 */       return (ParamStrategy)new WrappedFatPtrParamStrategy(recordTypeStrategy.getValueFunction());
/*     */     } 
/*     */     
/* 289 */     throw new UnsupportedOperationException("TODO: baseType = " + baseType);
/*     */   }
/*     */   
/*     */   public Map<GimpleParameter, ParamStrategy> forParameters(List<GimpleParameter> parameters) {
/* 293 */     Map<GimpleParameter, ParamStrategy> map = new HashMap<>();
/* 294 */     for (GimpleParameter parameter : parameters) {
/*     */       try {
/* 296 */         map.put(parameter, forParameter(parameter.getType()));
/* 297 */       } catch (Exception e) {
/* 298 */         throw new InternalCompilerException(String.format("Exception for parameter %s of type %s", new Object[] { parameter
/* 299 */                 .getName(), parameter.getType() }), e);
/*     */       } 
/*     */     } 
/* 302 */     return map;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getMethodDescriptor(ReturnStrategy returnStrategy, List<ParamStrategy> paramStrategies, VariadicStrategy variadicStrategy) {
/* 310 */     Preconditions.checkNotNull(returnStrategy, "returnStrategy is null");
/* 311 */     List<Type> types = Lists.newArrayList();
/* 312 */     for (ParamStrategy paramStrategy : paramStrategies) {
/* 313 */       types.addAll(paramStrategy.getParameterTypes());
/*     */     }
/* 315 */     types.addAll(variadicStrategy.getParameterTypes());
/*     */     
/* 317 */     Type[] typesArray = types.<Type>toArray(new Type[types.size()]);
/*     */     
/* 319 */     return Type.getMethodDescriptor(returnStrategy.getType(), typesArray);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/type/TypeOracle.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */