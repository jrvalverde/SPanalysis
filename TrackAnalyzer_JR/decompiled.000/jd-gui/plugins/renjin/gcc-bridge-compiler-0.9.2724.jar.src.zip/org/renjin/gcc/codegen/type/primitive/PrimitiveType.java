/*     */ package org.renjin.gcc.codegen.type.primitive;
/*     */ 
/*     */ import javax.annotation.Nullable;
/*     */ import org.renjin.gcc.codegen.expr.Expressions;
/*     */ import org.renjin.gcc.codegen.expr.GExpr;
/*     */ import org.renjin.gcc.codegen.expr.JExpr;
/*     */ import org.renjin.gcc.codegen.expr.PtrExpr;
/*     */ import org.renjin.gcc.gimple.expr.GimpleConstant;
/*     */ import org.renjin.gcc.gimple.expr.GimpleIntegerConstant;
/*     */ import org.renjin.gcc.gimple.expr.GimpleRealConstant;
/*     */ import org.renjin.gcc.gimple.type.GimpleBooleanType;
/*     */ import org.renjin.gcc.gimple.type.GimpleIntegerType;
/*     */ import org.renjin.gcc.gimple.type.GimplePrimitiveType;
/*     */ import org.renjin.gcc.gimple.type.GimpleRealType;
/*     */ import org.renjin.gcc.runtime.Ptr;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum PrimitiveType
/*     */ {
/*  42 */   REAL32
/*     */   {
/*     */     public GimpleRealType gimpleType() {
/*  45 */       return new GimpleRealType(32);
/*     */     }
/*     */ 
/*     */     
/*     */     public Type jvmType() {
/*  50 */       return Type.FLOAT_TYPE;
/*     */     }
/*     */ 
/*     */     
/*     */     public String javaTypeName() {
/*  55 */       return "float";
/*     */     }
/*     */ 
/*     */     
/*     */     public PrimitiveExpr cast(PrimitiveExpr x) {
/*  60 */       return x.toReal(32);
/*     */     }
/*     */ 
/*     */     
/*     */     public PrimitiveExpr fromStackValue(JExpr jExpr, @Nullable PtrExpr address) {
/*  65 */       return new RealExpr(gimpleType(), jExpr, address);
/*     */     }
/*     */ 
/*     */     
/*     */     public GExpr constantExpr(GimpleConstant expr) {
/*  70 */       return new RealExpr(gimpleType(), Expressions.constantFloat(((GimpleRealConstant)expr).getValue().floatValue()));
/*     */     }
/*     */   },
/*  73 */   REAL64
/*     */   {
/*     */     public GimpleRealType gimpleType()
/*     */     {
/*  77 */       return new GimpleRealType(64);
/*     */     }
/*     */ 
/*     */     
/*     */     public Type jvmType() {
/*  82 */       return Type.DOUBLE_TYPE;
/*     */     }
/*     */ 
/*     */     
/*     */     public String javaTypeName() {
/*  87 */       return "double";
/*     */     }
/*     */ 
/*     */     
/*     */     public PrimitiveExpr cast(PrimitiveExpr x) {
/*  92 */       return x.toReal(64);
/*     */     }
/*     */ 
/*     */     
/*     */     public PrimitiveExpr fromStackValue(JExpr jExpr, @Nullable PtrExpr address) {
/*  97 */       return new RealExpr(gimpleType(), jExpr, address);
/*     */     }
/*     */ 
/*     */     
/*     */     public GExpr constantExpr(GimpleConstant expr) {
/* 102 */       return new RealExpr(gimpleType(), Expressions.constantDouble(((GimpleRealConstant)expr).getValue().doubleValue()));
/*     */     }
/*     */   },
/* 105 */   REAL96
/*     */   {
/*     */     public GimpleRealType gimpleType()
/*     */     {
/* 109 */       return new GimpleRealType(96);
/*     */     }
/*     */ 
/*     */     
/*     */     public Type jvmType() {
/* 114 */       return Type.DOUBLE_TYPE;
/*     */     }
/*     */ 
/*     */     
/*     */     public String javaTypeName() {
/* 119 */       return "double";
/*     */     }
/*     */ 
/*     */     
/*     */     public PrimitiveExpr cast(PrimitiveExpr x) {
/* 124 */       return x.toReal(96);
/*     */     }
/*     */ 
/*     */     
/*     */     public PrimitiveExpr fromStackValue(JExpr jExpr, @Nullable PtrExpr address) {
/* 129 */       return new RealExpr(gimpleType(), jExpr, address);
/*     */     }
/*     */ 
/*     */     
/*     */     public GExpr constantExpr(GimpleConstant expr) {
/* 134 */       return new RealExpr(gimpleType(), Expressions.constantDouble(((GimpleRealConstant)expr).getValue().doubleValue()));
/*     */     }
/*     */   },
/* 137 */   BOOL
/*     */   {
/*     */     public GimplePrimitiveType gimpleType() {
/* 140 */       return (GimplePrimitiveType)new GimpleBooleanType();
/*     */     }
/*     */ 
/*     */     
/*     */     public Type jvmType() {
/* 145 */       return Type.BOOLEAN_TYPE;
/*     */     }
/*     */ 
/*     */     
/*     */     public String javaTypeName() {
/* 150 */       return "boolean";
/*     */     }
/*     */ 
/*     */     
/*     */     public PrimitiveExpr cast(PrimitiveExpr x) {
/* 155 */       return x.toBooleanExpr();
/*     */     }
/*     */ 
/*     */     
/*     */     public PrimitiveExpr fromStackValue(JExpr jExpr, @Nullable PtrExpr address) {
/* 160 */       return new BooleanExpr(jExpr, address);
/*     */     }
/*     */ 
/*     */     
/*     */     public GExpr constantExpr(GimpleConstant expr) {
/* 165 */       GimpleIntegerConstant constantInt = (GimpleIntegerConstant)expr;
/* 166 */       return new BooleanExpr(Expressions.constantInt(constantInt.getNumberValue().intValue()));
/*     */     }
/*     */   },
/* 169 */   INT8
/*     */   {
/*     */     public GimpleIntegerType gimpleType() {
/* 172 */       return GimpleIntegerType.signed(8);
/*     */     }
/*     */ 
/*     */     
/*     */     public Type jvmType() {
/* 177 */       return Type.BYTE_TYPE;
/*     */     }
/*     */ 
/*     */     
/*     */     public String javaTypeName() {
/* 182 */       return "byte";
/*     */     }
/*     */ 
/*     */     
/*     */     public PrimitiveExpr cast(PrimitiveExpr x) {
/* 187 */       return x.toSignedInt(8);
/*     */     }
/*     */ 
/*     */     
/*     */     public PrimitiveExpr fromStackValue(JExpr jExpr, @Nullable PtrExpr address) {
/* 192 */       return new SignedByteExpr(jExpr, address);
/*     */     }
/*     */ 
/*     */     
/*     */     public GExpr constantExpr(GimpleConstant expr) {
/* 197 */       return new SignedByteExpr(Expressions.i2b(Expressions.constantInt((int)longValue(expr))));
/*     */     }
/*     */   },
/*     */   
/* 201 */   INT16
/*     */   {
/*     */     public GimpleIntegerType gimpleType() {
/* 204 */       return GimpleIntegerType.signed(16);
/*     */     }
/*     */ 
/*     */     
/*     */     public Type jvmType() {
/* 209 */       return Type.SHORT_TYPE;
/*     */     }
/*     */ 
/*     */     
/*     */     public String javaTypeName() {
/* 214 */       return "short";
/*     */     }
/*     */ 
/*     */     
/*     */     public PrimitiveExpr cast(PrimitiveExpr x) {
/* 219 */       return x.toSignedInt(16);
/*     */     }
/*     */ 
/*     */     
/*     */     public PrimitiveExpr fromStackValue(JExpr jExpr, @Nullable PtrExpr address) {
/* 224 */       return new ShortExpr(jExpr, address);
/*     */     }
/*     */ 
/*     */     
/*     */     public GExpr constantExpr(GimpleConstant expr) {
/* 229 */       long longValue = longValue(expr);
/* 230 */       return new ShortExpr(Expressions.i2s(Expressions.constantInt((int)longValue)));
/*     */     }
/*     */   },
/*     */   
/* 234 */   INT32
/*     */   {
/*     */     public GimpleIntegerType gimpleType()
/*     */     {
/* 238 */       return GimpleIntegerType.signed(32);
/*     */     }
/*     */ 
/*     */     
/*     */     public Type jvmType() {
/* 243 */       return Type.INT_TYPE;
/*     */     }
/*     */ 
/*     */     
/*     */     public String javaTypeName() {
/* 248 */       return "int";
/*     */     }
/*     */ 
/*     */     
/*     */     public PrimitiveExpr cast(PrimitiveExpr x) {
/* 253 */       return x.toSignedInt(32);
/*     */     }
/*     */ 
/*     */     
/*     */     public PrimitiveExpr fromStackValue(JExpr jExpr, @Nullable PtrExpr address) {
/* 258 */       return new SignedIntExpr(jExpr, address);
/*     */     }
/*     */ 
/*     */     
/*     */     public GExpr constantExpr(GimpleConstant expr) {
/* 263 */       int intValue = ((GimpleIntegerConstant)expr).getNumberValue().intValue();
/* 264 */       return new SignedIntExpr(Expressions.constantInt(intValue));
/*     */     }
/*     */   },
/* 267 */   INT64
/*     */   {
/*     */     public GimpleIntegerType gimpleType() {
/* 270 */       return GimpleIntegerType.signed(64);
/*     */     }
/*     */ 
/*     */     
/*     */     public Type jvmType() {
/* 275 */       return Type.LONG_TYPE;
/*     */     }
/*     */ 
/*     */     
/*     */     public String javaTypeName() {
/* 280 */       return "long";
/*     */     }
/*     */ 
/*     */     
/*     */     public PrimitiveExpr cast(PrimitiveExpr x) {
/* 285 */       return x.toSignedInt(64);
/*     */     }
/*     */ 
/*     */     
/*     */     public PrimitiveExpr fromStackValue(JExpr jExpr, @Nullable PtrExpr address) {
/* 290 */       return new SignedLongExpr(jExpr, address);
/*     */     }
/*     */ 
/*     */     
/*     */     public GExpr constantExpr(GimpleConstant expr) {
/* 295 */       return new SignedLongExpr(Expressions.constantLong(((GimpleIntegerConstant)expr).getNumberValue().longValue()));
/*     */     }
/*     */   },
/*     */   
/* 299 */   UINT8
/*     */   {
/*     */     public GimpleIntegerType gimpleType() {
/* 302 */       return GimpleIntegerType.unsigned(8);
/*     */     }
/*     */ 
/*     */     
/*     */     public Type jvmType() {
/* 307 */       return Type.BYTE_TYPE;
/*     */     }
/*     */ 
/*     */     
/*     */     public String javaTypeName() {
/* 312 */       return "byte";
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public PrimitiveExpr cast(PrimitiveExpr x) {
/* 318 */       return x.toUnsignedInt(8);
/*     */     }
/*     */ 
/*     */     
/*     */     public PrimitiveExpr fromStackValue(JExpr jExpr, @Nullable PtrExpr address) {
/* 323 */       return new UnsignedSmallIntExpr(8, jExpr, address);
/*     */     }
/*     */ 
/*     */     
/*     */     public PrimitiveExpr fromNonStackValue(JExpr jExpr, @Nullable PtrExpr address) {
/* 328 */       return fromStackValue((JExpr)new TruncatedByteExpr(jExpr), address);
/*     */     }
/*     */ 
/*     */     
/*     */     public Type localVariableType() {
/* 333 */       return Type.INT_TYPE;
/*     */     }
/*     */ 
/*     */     
/*     */     public GExpr constantExpr(GimpleConstant expr) {
/* 338 */       return new UnsignedSmallIntExpr(8, Expressions.constantInt((int)longValue(expr)));
/*     */     }
/*     */   },
/* 341 */   UINT16
/*     */   {
/*     */     public GimpleIntegerType gimpleType()
/*     */     {
/* 345 */       return GimpleIntegerType.unsigned(16);
/*     */     }
/*     */ 
/*     */     
/*     */     public Type jvmType() {
/* 350 */       return Type.CHAR_TYPE;
/*     */     }
/*     */ 
/*     */     
/*     */     public String javaTypeName() {
/* 355 */       return "char";
/*     */     }
/*     */ 
/*     */     
/*     */     public PrimitiveExpr cast(PrimitiveExpr x) {
/* 360 */       return x.toUnsignedInt(16);
/*     */     }
/*     */ 
/*     */     
/*     */     public PrimitiveExpr fromStackValue(JExpr jExpr, @Nullable PtrExpr address) {
/* 365 */       return new UnsignedSmallIntExpr(16, jExpr, address);
/*     */     }
/*     */ 
/*     */     
/*     */     public GExpr constantExpr(GimpleConstant expr) {
/* 370 */       return new UnsignedSmallIntExpr(8, Expressions.constantInt((int)longValue(expr)));
/*     */     }
/*     */   },
/* 373 */   UINT32
/*     */   {
/*     */     public GimpleIntegerType gimpleType()
/*     */     {
/* 377 */       return GimpleIntegerType.unsigned(32);
/*     */     }
/*     */ 
/*     */     
/*     */     public Type jvmType() {
/* 382 */       return Type.INT_TYPE;
/*     */     }
/*     */ 
/*     */     
/*     */     public String javaTypeName() {
/* 387 */       return "int";
/*     */     }
/*     */ 
/*     */     
/*     */     public PrimitiveExpr cast(PrimitiveExpr x) {
/* 392 */       return x.toUnsignedInt(32);
/*     */     }
/*     */ 
/*     */     
/*     */     public PrimitiveExpr fromStackValue(JExpr jExpr, @Nullable PtrExpr address) {
/* 397 */       return new UnsignedIntExpr(jExpr, address);
/*     */     }
/*     */ 
/*     */     
/*     */     public GExpr constantExpr(GimpleConstant expr) {
/* 402 */       return new UnsignedIntExpr(Expressions.constantInt((int)longValue(expr)));
/*     */     }
/*     */   },
/* 405 */   UINT64
/*     */   {
/*     */     public GimpleIntegerType gimpleType()
/*     */     {
/* 409 */       return GimpleIntegerType.unsigned(64);
/*     */     }
/*     */ 
/*     */     
/*     */     public Type jvmType() {
/* 414 */       return Type.LONG_TYPE;
/*     */     }
/*     */ 
/*     */     
/*     */     public String javaTypeName() {
/* 419 */       return "long";
/*     */     }
/*     */ 
/*     */     
/*     */     public PrimitiveExpr cast(PrimitiveExpr x) {
/* 424 */       return x.toUnsignedInt(64);
/*     */     }
/*     */ 
/*     */     
/*     */     public PrimitiveExpr fromStackValue(JExpr jExpr, @Nullable PtrExpr address) {
/* 429 */       return new UnsignedLongExpr(jExpr, address);
/*     */     }
/*     */ 
/*     */     
/*     */     public GExpr constantExpr(GimpleConstant expr) {
/* 434 */       return new SignedLongExpr(Expressions.constantLong(((GimpleIntegerConstant)expr).getNumberValue().longValue()));
/*     */     }
/*     */   };
/*     */   
/*     */   private static long longValue(GimpleConstant expr) {
/* 439 */     GimpleIntegerConstant integerConstant = (GimpleIntegerConstant)expr;
/* 440 */     return integerConstant.getValue().longValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Type localVariableType() {
/* 452 */     return jvmType();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final PrimitiveExpr fromStackValue(JExpr jExpr) {
/* 458 */     return fromStackValue(jExpr, null);
/*     */   }
/*     */   
/*     */   public PrimitiveExpr fromNonStackValue(JExpr jExpr, PtrExpr address) {
/* 462 */     return fromStackValue(jExpr, address);
/*     */   }
/*     */   
/*     */   public final PrimitiveExpr fromNonStackValue(JExpr jExpr) {
/* 466 */     return fromNonStackValue(jExpr, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public JExpr fieldPointer(Type declaringType, String fieldName) {
/* 471 */     String capitalizedJavaTypeName = javaTypeName().substring(0, 1).toUpperCase() + javaTypeName().substring(1);
/* 472 */     Type ptrClassName = Type.getType("Lorg/renjin/gcc/runtime/" + capitalizedJavaTypeName + "FieldPtr;");
/* 473 */     String addressOfDescriptor = Type.getMethodDescriptor(Type.getType(Ptr.class), new Type[] { Type.getType(Class.class), Type.getType(String.class) });
/* 474 */     return Expressions.staticMethodCall(ptrClassName, "addressOf", addressOfDescriptor, new JExpr[] {
/* 475 */           Expressions.constantClass(declaringType), Expressions.constantString(fieldName) });
/*     */   }
/*     */   
/*     */   public static PrimitiveType of(GimplePrimitiveType type) {
/* 479 */     if (type instanceof GimpleRealType) {
/* 480 */       switch (((GimpleRealType)type).getPrecision()) {
/*     */         case 32:
/* 482 */           return REAL32;
/*     */         case 64:
/* 484 */           return REAL64;
/*     */         case 96:
/* 486 */           return REAL96;
/*     */       } 
/* 488 */     } else if (type instanceof GimpleIntegerType) {
/* 489 */       GimpleIntegerType integerType = (GimpleIntegerType)type;
/* 490 */       if (integerType.isUnsigned()) {
/* 491 */         switch (integerType.getPrecision()) {
/*     */           case 8:
/* 493 */             return UINT8;
/*     */           case 16:
/* 495 */             return UINT16;
/*     */           case 32:
/* 497 */             return UINT32;
/*     */           case 64:
/* 499 */             return UINT64;
/*     */         } 
/*     */       } else {
/* 502 */         switch (integerType.getPrecision()) {
/*     */           case 8:
/* 504 */             return INT8;
/*     */           case 16:
/* 506 */             return INT16;
/*     */           case 32:
/* 508 */             return INT32;
/*     */           case 64:
/* 510 */             return INT64;
/*     */         } 
/*     */       } 
/* 513 */     } else if (type instanceof GimpleBooleanType) {
/* 514 */       return BOOL;
/*     */     } 
/* 516 */     throw new UnsupportedOperationException("type: " + type);
/*     */   }
/*     */   
/*     */   public abstract GimplePrimitiveType gimpleType();
/*     */   
/*     */   public abstract Type jvmType();
/*     */   
/*     */   public abstract String javaTypeName();
/*     */   
/*     */   public abstract PrimitiveExpr cast(PrimitiveExpr paramPrimitiveExpr);
/*     */   
/*     */   public abstract PrimitiveExpr fromStackValue(JExpr paramJExpr, @Nullable PtrExpr paramPtrExpr);
/*     */   
/*     */   public abstract GExpr constantExpr(GimpleConstant paramGimpleConstant);
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/type/primitive/PrimitiveType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */