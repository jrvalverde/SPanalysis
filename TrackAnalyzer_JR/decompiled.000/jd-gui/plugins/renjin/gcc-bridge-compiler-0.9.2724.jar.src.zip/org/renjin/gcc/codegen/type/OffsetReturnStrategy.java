/*    */ package org.renjin.gcc.codegen.type;
/*    */ 
/*    */ import org.renjin.gcc.codegen.MethodGenerator;
/*    */ import org.renjin.gcc.codegen.expr.GExpr;
/*    */ import org.renjin.gcc.codegen.expr.JExpr;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OffsetReturnStrategy
/*    */   implements ReturnStrategy
/*    */ {
/*    */   public Type getType() {
/* 29 */     return Type.getType(Object.class);
/*    */   }
/*    */ 
/*    */   
/*    */   public JExpr marshall(GExpr expr) {
/* 34 */     throw new UnsupportedOperationException("TODO");
/*    */   }
/*    */ 
/*    */   
/*    */   public GExpr unmarshall(MethodGenerator mv, JExpr callExpr, TypeStrategy lhsTypeStrategy) {
/* 39 */     throw new UnsupportedOperationException("TODO");
/*    */   }
/*    */ 
/*    */   
/*    */   public JExpr getDefaultReturnValue() {
/* 44 */     throw new UnsupportedOperationException("TODO");
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/type/OffsetReturnStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */