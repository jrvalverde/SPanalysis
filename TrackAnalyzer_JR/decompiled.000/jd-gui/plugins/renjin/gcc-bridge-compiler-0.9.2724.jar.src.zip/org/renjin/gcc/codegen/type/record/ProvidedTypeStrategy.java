/*     */ package org.renjin.gcc.codegen.type.record;
/*     */ 
/*     */ import org.renjin.gcc.codegen.MethodGenerator;
/*     */ import org.renjin.gcc.codegen.expr.ExprFactory;
/*     */ import org.renjin.gcc.codegen.expr.GExpr;
/*     */ import org.renjin.gcc.codegen.expr.JExpr;
/*     */ import org.renjin.gcc.codegen.fatptr.ValueFunction;
/*     */ import org.renjin.gcc.codegen.type.FieldStrategy;
/*     */ import org.renjin.gcc.codegen.type.ParamStrategy;
/*     */ import org.renjin.gcc.codegen.type.PointerTypeStrategy;
/*     */ import org.renjin.gcc.codegen.type.ReturnStrategy;
/*     */ import org.renjin.gcc.codegen.type.TypeStrategy;
/*     */ import org.renjin.gcc.codegen.type.UnsupportedCastException;
/*     */ import org.renjin.gcc.codegen.var.VarAllocator;
/*     */ import org.renjin.gcc.gimple.GimpleVarDecl;
/*     */ import org.renjin.gcc.gimple.expr.GimpleConstructor;
/*     */ import org.renjin.gcc.gimple.type.GimpleArrayType;
/*     */ import org.renjin.gcc.gimple.type.GimpleRecordTypeDef;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProvidedTypeStrategy
/*     */   extends RecordTypeStrategy<GExpr>
/*     */ {
/*     */   private final Type jvmType;
/*     */   
/*     */   public ProvidedTypeStrategy(GimpleRecordTypeDef gimpleType, Type jvmType) {
/*  39 */     super(gimpleType);
/*  40 */     this.jvmType = jvmType;
/*     */   }
/*     */ 
/*     */   
/*     */   public Type getJvmType() {
/*  45 */     return this.jvmType;
/*     */   }
/*     */ 
/*     */   
/*     */   public ParamStrategy getParamStrategy() {
/*  50 */     throw new UnsupportedOperationException(unsupportedMessage());
/*     */   }
/*     */   
/*     */   private String unsupportedMessage() {
/*  54 */     return "Provided type '" + this.jvmType.getInternalName() + "' can only be used as a pointer";
/*     */   }
/*     */ 
/*     */   
/*     */   public ReturnStrategy getReturnStrategy() {
/*  59 */     throw new UnsupportedOperationException(unsupportedMessage());
/*     */   }
/*     */ 
/*     */   
/*     */   public ValueFunction getValueFunction() {
/*  64 */     throw new UnsupportedOperationException(unsupportedMessage());
/*     */   }
/*     */ 
/*     */   
/*     */   public GExpr variable(GimpleVarDecl decl, VarAllocator allocator) {
/*  69 */     throw new UnsupportedOperationException(unsupportedMessage());
/*     */   }
/*     */ 
/*     */   
/*     */   public GExpr providedGlobalVariable(GimpleVarDecl decl, JExpr expr, boolean readOnly) {
/*  74 */     throw new UnsupportedOperationException(unsupportedMessage());
/*     */   }
/*     */ 
/*     */   
/*     */   public GExpr constructorExpr(ExprFactory exprFactory, MethodGenerator mv, GimpleConstructor value) {
/*  79 */     throw new UnsupportedOperationException(unsupportedMessage());
/*     */   }
/*     */ 
/*     */   
/*     */   public FieldStrategy fieldGenerator(Type className, String fieldName) {
/*  84 */     throw new UnsupportedOperationException(unsupportedMessage());
/*     */   }
/*     */ 
/*     */   
/*     */   public FieldStrategy addressableFieldGenerator(Type className, String fieldName) {
/*  89 */     throw new UnsupportedOperationException(unsupportedMessage());
/*     */   }
/*     */ 
/*     */   
/*     */   public PointerTypeStrategy pointerTo() {
/*  94 */     return new ProvidedPtrStrategy(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeStrategy arrayOf(GimpleArrayType arrayType) {
/*  99 */     throw new UnsupportedOperationException(unsupportedMessage());
/*     */   }
/*     */ 
/*     */   
/*     */   public GExpr cast(MethodGenerator mv, GExpr value) throws UnsupportedCastException {
/* 104 */     throw new UnsupportedOperationException(unsupportedMessage());
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/type/record/ProvidedTypeStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */