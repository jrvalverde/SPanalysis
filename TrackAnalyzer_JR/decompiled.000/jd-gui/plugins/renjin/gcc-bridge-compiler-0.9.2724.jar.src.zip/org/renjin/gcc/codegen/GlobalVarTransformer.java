package org.renjin.gcc.codegen;

import org.renjin.gcc.codegen.expr.GExpr;
import org.renjin.gcc.codegen.type.TypeOracle;
import org.renjin.gcc.gimple.GimpleCompilationUnit;
import org.renjin.gcc.gimple.GimpleVarDecl;

public interface GlobalVarTransformer {
  boolean accept(GimpleVarDecl paramGimpleVarDecl);
  
  GExpr generator(TypeOracle paramTypeOracle, GimpleCompilationUnit paramGimpleCompilationUnit, GimpleVarDecl paramGimpleVarDecl);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/GlobalVarTransformer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */