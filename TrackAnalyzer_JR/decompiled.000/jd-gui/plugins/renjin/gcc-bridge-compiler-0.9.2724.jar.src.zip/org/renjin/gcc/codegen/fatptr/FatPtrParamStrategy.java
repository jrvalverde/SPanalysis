/*    */ package org.renjin.gcc.codegen.fatptr;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import java.util.Optional;
/*    */ import org.renjin.gcc.codegen.MethodGenerator;
/*    */ import org.renjin.gcc.codegen.expr.GExpr;
/*    */ import org.renjin.gcc.codegen.expr.JExpr;
/*    */ import org.renjin.gcc.codegen.expr.JLValue;
/*    */ import org.renjin.gcc.codegen.type.ParamStrategy;
/*    */ import org.renjin.gcc.codegen.var.VarAllocator;
/*    */ import org.renjin.gcc.gimple.GimpleParameter;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FatPtrParamStrategy
/*    */   implements ParamStrategy
/*    */ {
/*    */   private ValueFunction valueFunction;
/*    */   
/*    */   public FatPtrParamStrategy(ValueFunction valueFunction) {
/* 41 */     this.valueFunction = valueFunction;
/*    */   }
/*    */ 
/*    */   
/*    */   public List<Type> getParameterTypes() {
/* 46 */     Type arrayType = Type.getType("[" + this.valueFunction.getValueType().getDescriptor());
/* 47 */     Type offsetType = Type.INT_TYPE;
/*    */     
/* 49 */     return Arrays.asList(new Type[] { arrayType, offsetType });
/*    */   }
/*    */ 
/*    */   
/*    */   public List<String> getParameterNames(String name) {
/* 54 */     return Arrays.asList(new String[] { name, name + "_offset" });
/*    */   }
/*    */ 
/*    */   
/*    */   public GExpr emitInitialization(MethodGenerator methodVisitor, GimpleParameter parameter, List<JLValue> paramVars, VarAllocator localVars) {
/* 59 */     if (parameter.isAddressable()) {
/* 60 */       throw new UnsupportedOperationException("TODO: Addressable parameters");
/*    */     }
/*    */     
/* 63 */     return (GExpr)new FatPtrPair(this.valueFunction, (JExpr)paramVars.get(0), (JExpr)paramVars.get(1));
/*    */   }
/*    */ 
/*    */   
/*    */   public void loadParameter(MethodGenerator mv, Optional<GExpr> argument) {
/* 68 */     if (argument.isPresent()) {
/* 69 */       FatPtrPair expr = (FatPtrPair)argument.get();
/* 70 */       expr.getArray().load(mv);
/* 71 */       expr.getOffset().load(mv);
/*    */     } else {
/* 73 */       mv.aconst(null);
/* 74 */       mv.iconst(0);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/fatptr/FatPtrParamStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */