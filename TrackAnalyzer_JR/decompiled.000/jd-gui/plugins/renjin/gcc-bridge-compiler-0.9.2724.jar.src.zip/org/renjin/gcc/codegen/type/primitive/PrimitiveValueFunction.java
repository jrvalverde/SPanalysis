/*     */ package org.renjin.gcc.codegen.type.primitive;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Optional;
/*     */ import org.renjin.gcc.codegen.MethodGenerator;
/*     */ import org.renjin.gcc.codegen.expr.ArrayElement;
/*     */ import org.renjin.gcc.codegen.expr.Expressions;
/*     */ import org.renjin.gcc.codegen.expr.GExpr;
/*     */ import org.renjin.gcc.codegen.expr.JExpr;
/*     */ import org.renjin.gcc.codegen.expr.PtrExpr;
/*     */ import org.renjin.gcc.codegen.fatptr.FatPtrPair;
/*     */ import org.renjin.gcc.codegen.fatptr.Memset;
/*     */ import org.renjin.gcc.codegen.fatptr.ValueFunction;
/*     */ import org.renjin.gcc.codegen.fatptr.WrappedFatPtrExpr;
/*     */ import org.renjin.gcc.codegen.vptr.PointerType;
/*     */ import org.renjin.gcc.codegen.vptr.VPtrExpr;
/*     */ import org.renjin.gcc.gimple.type.GimplePrimitiveType;
/*     */ import org.renjin.gcc.gimple.type.GimpleType;
/*     */ import org.renjin.gcc.runtime.Double96Ptr;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PrimitiveValueFunction
/*     */   implements ValueFunction
/*     */ {
/*     */   private PrimitiveType type;
/*     */   private int byteSize;
/*     */   
/*     */   public PrimitiveValueFunction(PrimitiveType type) {
/*  47 */     this.type = type;
/*  48 */     this.byteSize = type.gimpleType().sizeOf();
/*     */   }
/*     */   
/*     */   public PrimitiveValueFunction(GimplePrimitiveType primitiveType) {
/*  52 */     this(PrimitiveType.of(primitiveType));
/*     */   }
/*     */ 
/*     */   
/*     */   public Type getValueType() {
/*  57 */     return this.type.jvmType();
/*     */   }
/*     */ 
/*     */   
/*     */   public GimpleType getGimpleValueType() {
/*  62 */     return (GimpleType)this.type.gimpleType();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getElementLength() {
/*  67 */     return 1;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getArrayElementBytes() {
/*  72 */     return this.byteSize;
/*     */   }
/*     */ 
/*     */   
/*     */   public GExpr dereference(JExpr array, JExpr offset) {
/*  77 */     FatPtrPair address = new FatPtrPair(this, array, offset);
/*  78 */     ArrayElement arrayElement = Expressions.elementAt(array, offset);
/*     */     
/*  80 */     return this.type.fromNonStackValue((JExpr)arrayElement, (PtrExpr)address);
/*     */   }
/*     */ 
/*     */   
/*     */   public GExpr dereference(WrappedFatPtrExpr wrapperInstance) {
/*  85 */     return this.type.fromNonStackValue((JExpr)wrapperInstance.valueExpr(), (PtrExpr)wrapperInstance);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<JExpr> toArrayValues(GExpr expr) {
/*  90 */     PrimitiveExpr primitiveExpr = (PrimitiveExpr)expr;
/*  91 */     return Collections.singletonList(primitiveExpr.jexpr());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void memoryCopy(MethodGenerator mv, JExpr destinationArray, JExpr destinationOffset, JExpr sourceArray, JExpr sourceOffset, JExpr valueCount) {
/*  99 */     mv.arrayCopy(sourceArray, sourceOffset, destinationArray, destinationOffset, valueCount);
/*     */   }
/*     */ 
/*     */   
/*     */   public void memorySet(MethodGenerator mv, JExpr array, JExpr offset, JExpr byteValue, JExpr length) {
/* 104 */     Memset.primitiveMemset(mv, this.type.jvmType(), array, offset, byteValue, length);
/*     */   }
/*     */ 
/*     */   
/*     */   public Optional<JExpr> getValueConstructor() {
/* 109 */     return Optional.empty();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public VPtrExpr toVPtr(JExpr array, JExpr offset) {
/* 115 */     PointerType pointerType = PointerType.ofPrimitiveType(this.type.gimpleType());
/*     */ 
/*     */     
/* 118 */     if (pointerType == PointerType.REAL96 && array.getType().getElementType().equals(Type.DOUBLE_TYPE)) {
/* 119 */       JExpr jExpr = Expressions.newObject(Type.getType(Double96Ptr.class), new JExpr[] { array, offset });
/* 120 */       return new VPtrExpr(jExpr);
/*     */     } 
/*     */     
/* 123 */     JExpr newWrapper = Expressions.newObject(pointerType.alignedImpl(), new JExpr[] { array, offset });
/* 124 */     return new VPtrExpr(newWrapper);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 129 */     return "Primitive[" + this.type + "]";
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/type/primitive/PrimitiveValueFunction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */