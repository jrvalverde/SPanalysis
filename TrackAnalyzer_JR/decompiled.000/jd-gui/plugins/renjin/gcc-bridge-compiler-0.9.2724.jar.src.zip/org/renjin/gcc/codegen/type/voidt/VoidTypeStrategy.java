/*    */ package org.renjin.gcc.codegen.type.voidt;
/*    */ 
/*    */ import org.renjin.gcc.codegen.MethodGenerator;
/*    */ import org.renjin.gcc.codegen.array.ArrayTypeStrategy;
/*    */ import org.renjin.gcc.codegen.expr.ExprFactory;
/*    */ import org.renjin.gcc.codegen.expr.GExpr;
/*    */ import org.renjin.gcc.codegen.expr.JExpr;
/*    */ import org.renjin.gcc.codegen.fatptr.ValueFunction;
/*    */ import org.renjin.gcc.codegen.type.FieldStrategy;
/*    */ import org.renjin.gcc.codegen.type.ParamStrategy;
/*    */ import org.renjin.gcc.codegen.type.PointerTypeStrategy;
/*    */ import org.renjin.gcc.codegen.type.ReturnStrategy;
/*    */ import org.renjin.gcc.codegen.type.TypeStrategy;
/*    */ import org.renjin.gcc.codegen.type.UnsupportedCastException;
/*    */ import org.renjin.gcc.codegen.var.VarAllocator;
/*    */ import org.renjin.gcc.codegen.vptr.VPtrStrategy;
/*    */ import org.renjin.gcc.gimple.GimpleVarDecl;
/*    */ import org.renjin.gcc.gimple.expr.GimpleConstructor;
/*    */ import org.renjin.gcc.gimple.type.GimpleArrayType;
/*    */ import org.renjin.gcc.gimple.type.GimpleType;
/*    */ import org.renjin.gcc.gimple.type.GimpleVoidType;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VoidTypeStrategy
/*    */   implements TypeStrategy<GExpr>
/*    */ {
/*    */   public ReturnStrategy getReturnStrategy() {
/* 43 */     return new VoidReturnStrategy();
/*    */   }
/*    */ 
/*    */   
/*    */   public ValueFunction getValueFunction() {
/* 48 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   
/*    */   public ParamStrategy getParamStrategy() {
/* 53 */     throw new UnsupportedOperationException("parameters cannot have 'void' type");
/*    */   }
/*    */ 
/*    */   
/*    */   public GExpr variable(GimpleVarDecl decl, VarAllocator allocator) {
/* 58 */     throw new UnsupportedOperationException("variables cannot have 'void' type");
/*    */   }
/*    */ 
/*    */   
/*    */   public GExpr providedGlobalVariable(GimpleVarDecl decl, JExpr expr, boolean readOnly) {
/* 63 */     throw new UnsupportedOperationException("variables cannot have 'void' type");
/*    */   }
/*    */ 
/*    */   
/*    */   public GExpr constructorExpr(ExprFactory exprFactory, MethodGenerator mv, GimpleConstructor value) {
/* 68 */     throw new UnsupportedOperationException("constructors cannot have 'void' type");
/*    */   }
/*    */ 
/*    */   
/*    */   public FieldStrategy fieldGenerator(Type className, String fieldName) {
/* 73 */     throw new UnsupportedOperationException("fields cannot have 'void' type");
/*    */   }
/*    */ 
/*    */   
/*    */   public FieldStrategy addressableFieldGenerator(Type className, String fieldName) {
/* 78 */     throw new UnsupportedOperationException("fields cannot have 'void' type");
/*    */   }
/*    */ 
/*    */   
/*    */   public PointerTypeStrategy pointerTo() {
/* 83 */     return (PointerTypeStrategy)new VPtrStrategy((GimpleType)new GimpleVoidType());
/*    */   }
/*    */ 
/*    */   
/*    */   public ArrayTypeStrategy arrayOf(GimpleArrayType arrayType) {
/* 88 */     throw new UnsupportedOperationException("arrays cannot have component type of 'void'");
/*    */   }
/*    */ 
/*    */   
/*    */   public GExpr cast(MethodGenerator mv, GExpr value) throws UnsupportedCastException {
/* 93 */     throw new UnsupportedCastException();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/type/voidt/VoidTypeStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */