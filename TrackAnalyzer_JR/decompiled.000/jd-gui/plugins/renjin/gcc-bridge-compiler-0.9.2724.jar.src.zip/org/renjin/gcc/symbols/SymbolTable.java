package org.renjin.gcc.symbols;

import org.renjin.gcc.codegen.call.CallGenerator;
import org.renjin.gcc.codegen.expr.GExpr;
import org.renjin.gcc.codegen.expr.JExpr;
import org.renjin.gcc.gimple.expr.GimpleFunctionRef;
import org.renjin.gcc.gimple.expr.GimpleSymbolRef;

public interface SymbolTable {
  JExpr findHandle(GimpleFunctionRef paramGimpleFunctionRef);
  
  CallGenerator findCallGenerator(GimpleFunctionRef paramGimpleFunctionRef);
  
  GExpr getVariable(GimpleSymbolRef paramGimpleSymbolRef);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/symbols/SymbolTable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */