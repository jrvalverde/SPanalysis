package org.renjin.gcc;

import org.renjin.gcc.codegen.expr.GExpr;
import org.renjin.gcc.codegen.type.TypeOracle;
import org.renjin.gcc.gimple.GimpleVarDecl;

public interface ProvidedGlobalVar {
  GExpr createExpr(GimpleVarDecl paramGimpleVarDecl, TypeOracle paramTypeOracle);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/ProvidedGlobalVar.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */