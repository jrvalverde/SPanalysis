/*    */ package org.renjin.gcc.codegen.vptr;
/*    */ 
/*    */ import org.renjin.gcc.codegen.MethodGenerator;
/*    */ import org.renjin.gcc.codegen.expr.Expressions;
/*    */ import org.renjin.gcc.codegen.expr.GExpr;
/*    */ import org.renjin.gcc.codegen.expr.JExpr;
/*    */ import org.renjin.gcc.codegen.type.ReturnStrategy;
/*    */ import org.renjin.gcc.codegen.type.TypeStrategy;
/*    */ import org.renjin.gcc.runtime.Ptr;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VPtrReturnStrategy
/*    */   implements ReturnStrategy
/*    */ {
/*    */   public Type getType() {
/* 34 */     return Type.getType(Ptr.class);
/*    */   }
/*    */ 
/*    */   
/*    */   public JExpr marshall(GExpr expr) {
/* 39 */     return expr.toVPtrExpr().getRef();
/*    */   }
/*    */ 
/*    */   
/*    */   public GExpr unmarshall(MethodGenerator mv, JExpr callExpr, TypeStrategy lhsTypeStrategy) {
/* 44 */     return (GExpr)new VPtrExpr(callExpr);
/*    */   }
/*    */ 
/*    */   
/*    */   public JExpr getDefaultReturnValue() {
/* 49 */     return Expressions.nullRef(Type.getType(Ptr.class));
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/vptr/VPtrReturnStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */