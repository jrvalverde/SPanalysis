/*     */ package org.renjin.gcc.codegen.call;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Optional;
/*     */ import javax.annotation.Nonnull;
/*     */ import org.renjin.gcc.codegen.MethodGenerator;
/*     */ import org.renjin.gcc.codegen.expr.ExprFactory;
/*     */ import org.renjin.gcc.codegen.expr.GExpr;
/*     */ import org.renjin.gcc.codegen.expr.JExpr;
/*     */ import org.renjin.gcc.codegen.type.NullVariadicStrategy;
/*     */ import org.renjin.gcc.codegen.type.ParamStrategy;
/*     */ import org.renjin.gcc.codegen.type.ReturnStrategy;
/*     */ import org.renjin.gcc.codegen.type.TypeOracle;
/*     */ import org.renjin.gcc.codegen.type.VariadicStrategy;
/*     */ import org.renjin.gcc.codegen.type.voidt.VoidReturnStrategy;
/*     */ import org.renjin.gcc.gimple.expr.GimpleExpr;
/*     */ import org.renjin.gcc.gimple.statement.GimpleCall;
/*     */ import org.renjin.gcc.gimple.type.GimpleFunctionType;
/*     */ import org.renjin.gcc.gimple.type.GimpleType;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ import org.renjin.repackaged.guava.collect.Lists;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FunPtrCallGenerator
/*     */   implements CallGenerator
/*     */ {
/*     */   private TypeOracle typeOracle;
/*     */   private JExpr methodHandle;
/*     */   private final ReturnStrategy returnStrategy;
/*     */   private final GimpleFunctionType functionType;
/*     */   
/*     */   public FunPtrCallGenerator(TypeOracle typeOracle, GimpleFunctionType type, JExpr methodHandle) {
/*  53 */     this.typeOracle = typeOracle;
/*  54 */     this.methodHandle = methodHandle;
/*  55 */     this.functionType = type;
/*  56 */     this.returnStrategy = typeOracle.returnStrategyFor(this.functionType.getReturnType());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void emitCall(MethodGenerator mv, final ExprFactory exprFactory, final GimpleCall call) {
/*     */     final ReturnStrategy returnStrategy;
/*  74 */     final List<ParamStrategy> paramStrategies = Lists.newArrayList();
/*     */     
/*  76 */     for (GimpleExpr argumentExpr : call.getOperands()) {
/*  77 */       paramStrategies.add(this.typeOracle.forParameter(argumentExpr.getType()));
/*     */     }
/*     */ 
/*     */     
/*  81 */     if (call.getLhs() == null) {
/*  82 */       VoidReturnStrategy voidReturnStrategy = new VoidReturnStrategy();
/*     */     } else {
/*  84 */       returnStrategy = this.typeOracle.returnStrategyFor(call.getLhs().getType());
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  90 */     final String signature = TypeOracle.getMethodDescriptor(returnStrategy, paramStrategies, (VariadicStrategy)new NullVariadicStrategy());
/*     */ 
/*     */ 
/*     */     
/*  94 */     JExpr callValue = new JExpr()
/*     */       {
/*     */         @Nonnull
/*     */         public Type getType() {
/*  98 */           return returnStrategy.getType();
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         public void load(@Nonnull MethodGenerator mv) {
/* 104 */           FunPtrCallGenerator.this.methodHandle.load(mv);
/*     */ 
/*     */           
/* 107 */           for (int i = 0; i < call.getOperands().size(); i++) {
/* 108 */             ((ParamStrategy)paramStrategies.get(i)).loadParameter(mv, Optional.of(exprFactory.findGenerator(call.getOperand(i))));
/*     */           }
/*     */           
/* 111 */           mv.visitMethodInsn(182, "java/lang/invoke/MethodHandle", "invoke", signature, false);
/*     */         }
/*     */       };
/*     */     
/* 115 */     if (call.getLhs() == null) {
/*     */       
/* 117 */       callValue.load(mv);
/*     */     }
/*     */     else {
/*     */       
/* 121 */       GExpr lhs = exprFactory.findGenerator((GimpleExpr)call.getLhs());
/* 122 */       GimpleType lhsType = call.getLhs().getType();
/* 123 */       GExpr rhs = returnStrategy.unmarshall(mv, callValue, exprFactory.strategyFor(lhsType));
/*     */       
/* 125 */       lhs.store(mv, rhs);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/call/FunPtrCallGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */