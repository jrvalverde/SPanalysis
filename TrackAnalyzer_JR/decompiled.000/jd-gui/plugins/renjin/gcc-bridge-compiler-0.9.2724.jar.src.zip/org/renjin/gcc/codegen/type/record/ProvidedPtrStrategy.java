/*     */ package org.renjin.gcc.codegen.type.record;
/*     */ 
/*     */ import java.util.Optional;
/*     */ import org.renjin.gcc.codegen.MethodGenerator;
/*     */ import org.renjin.gcc.codegen.array.ArrayTypeStrategies;
/*     */ import org.renjin.gcc.codegen.array.ArrayTypeStrategy;
/*     */ import org.renjin.gcc.codegen.expr.ArrayElement;
/*     */ import org.renjin.gcc.codegen.expr.ExprFactory;
/*     */ import org.renjin.gcc.codegen.expr.Expressions;
/*     */ import org.renjin.gcc.codegen.expr.GExpr;
/*     */ import org.renjin.gcc.codegen.expr.JExpr;
/*     */ import org.renjin.gcc.codegen.expr.JLValue;
/*     */ import org.renjin.gcc.codegen.fatptr.AddressableField;
/*     */ import org.renjin.gcc.codegen.fatptr.FatPtr;
/*     */ import org.renjin.gcc.codegen.fatptr.FatPtrPair;
/*     */ import org.renjin.gcc.codegen.fatptr.ValueFunction;
/*     */ import org.renjin.gcc.codegen.type.FieldStrategy;
/*     */ import org.renjin.gcc.codegen.type.ParamStrategy;
/*     */ import org.renjin.gcc.codegen.type.PointerTypeStrategy;
/*     */ import org.renjin.gcc.codegen.type.ReturnStrategy;
/*     */ import org.renjin.gcc.codegen.type.TypeStrategy;
/*     */ import org.renjin.gcc.codegen.type.UnsupportedCastException;
/*     */ import org.renjin.gcc.codegen.var.VarAllocator;
/*     */ import org.renjin.gcc.codegen.vptr.VPtrStrategy;
/*     */ import org.renjin.gcc.gimple.GimpleVarDecl;
/*     */ import org.renjin.gcc.gimple.expr.GimpleConstructor;
/*     */ import org.renjin.gcc.gimple.type.GimpleArrayType;
/*     */ import org.renjin.gcc.gimple.type.GimpleRecordType;
/*     */ import org.renjin.gcc.gimple.type.GimpleType;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProvidedPtrStrategy
/*     */   implements PointerTypeStrategy<ProvidedPtrExpr>
/*     */ {
/*     */   private ProvidedTypeStrategy strategy;
/*     */   private ProvidedPtrValueFunction valueFunction;
/*     */   
/*     */   public ProvidedPtrStrategy(ProvidedTypeStrategy strategy) {
/*  46 */     this.strategy = strategy;
/*  47 */     this.valueFunction = new ProvidedPtrValueFunction(strategy);
/*     */   }
/*     */   
/*     */   public boolean isEmpty() {
/*  51 */     return this.strategy.getJvmType().equals(Type.getType(Object.class));
/*     */   }
/*     */ 
/*     */   
/*     */   public ParamStrategy getParamStrategy() {
/*  56 */     return new ProvidedPtrParamStrategy(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public FieldStrategy fieldGenerator(Type className, String fieldName) {
/*  61 */     return (FieldStrategy)new ProvidedPtrField(className, fieldName, this.strategy.getJvmType());
/*     */   }
/*     */ 
/*     */   
/*     */   public ProvidedPtrExpr constructorExpr(ExprFactory exprFactory, MethodGenerator mv, GimpleConstructor value) {
/*  66 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public FieldStrategy addressableFieldGenerator(Type className, String fieldName) {
/*  71 */     return (FieldStrategy)new AddressableField(className, fieldName, this.valueFunction);
/*     */   }
/*     */ 
/*     */   
/*     */   public VPtrStrategy pointerTo() {
/*  76 */     return new VPtrStrategy((GimpleType)getGimpleType());
/*     */   }
/*     */ 
/*     */   
/*     */   public ArrayTypeStrategy arrayOf(GimpleArrayType arrayType) {
/*  81 */     return ArrayTypeStrategies.of(arrayType, this.valueFunction);
/*     */   }
/*     */ 
/*     */   
/*     */   public ProvidedPtrExpr cast(MethodGenerator mv, GExpr value) throws UnsupportedCastException {
/*  86 */     return value.toProvidedPtrExpr(getJvmType());
/*     */   }
/*     */ 
/*     */   
/*     */   public ReturnStrategy getReturnStrategy() {
/*  91 */     return new ProvidedPtrReturnStrategy(this.strategy.getJvmType());
/*     */   }
/*     */ 
/*     */   
/*     */   public ValueFunction getValueFunction() {
/*  96 */     return this.valueFunction;
/*     */   }
/*     */ 
/*     */   
/*     */   public ProvidedPtrExpr variable(GimpleVarDecl decl, VarAllocator allocator) {
/* 101 */     if (decl.isAddressable()) {
/*     */ 
/*     */       
/* 104 */       JLValue jLValue = allocator.reserveUnitArray(decl.getName(), this.strategy.getJvmType(), Optional.empty());
/*     */       
/* 106 */       FatPtrPair address = new FatPtrPair(this.valueFunction, (JExpr)jLValue);
/* 107 */       ArrayElement instance = Expressions.elementAt((JExpr)jLValue, 0);
/*     */       
/* 109 */       return new ProvidedPtrExpr((JExpr)instance, (FatPtr)address);
/*     */     } 
/*     */     
/* 112 */     return new ProvidedPtrExpr((JExpr)allocator.reserve(decl.getNameIfPresent(), this.strategy.getJvmType()));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ProvidedPtrExpr providedGlobalVariable(GimpleVarDecl decl, JExpr expr, boolean readOnly) {
/* 118 */     Type javaFieldType = expr.getType();
/* 119 */     if (!javaFieldType.equals(this.strategy.getJvmType())) {
/* 120 */       throw new UnsupportedOperationException("Cannot map global variable " + decl + " to existing field " + expr + ". Expected field of type " + this.strategy
/* 121 */           .getJvmType());
/*     */     }
/*     */     
/* 124 */     if (readOnly) {
/*     */ 
/*     */       
/* 127 */       FatPtrPair fakeAddress = new FatPtrPair(this.valueFunction, Expressions.newArray(expr, new JExpr[0]));
/* 128 */       return new ProvidedPtrExpr(expr, (FatPtr)fakeAddress);
/*     */     } 
/*     */     
/* 131 */     return new ProvidedPtrExpr(expr);
/*     */   }
/*     */ 
/*     */   
/*     */   public ProvidedPtrExpr malloc(MethodGenerator mv, JExpr sizeInBytes) {
/* 136 */     throw new UnsupportedOperationException(
/* 137 */         String.format("Type '%s' is provided and may not be allocated by compiled code.", new Object[] { getJvmType() }));
/*     */   }
/*     */ 
/*     */   
/*     */   public ProvidedPtrExpr nullPointer() {
/* 142 */     return new ProvidedPtrExpr(Expressions.nullRef(this.strategy.getJvmType()));
/*     */   }
/*     */   
/*     */   public Type getJvmType() {
/* 146 */     return this.strategy.getJvmType();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 151 */     return "RecordUnitPtrStrategy[" + this.strategy.getRecordTypeDef().getName() + "]";
/*     */   }
/*     */   
/*     */   public GimpleRecordType getGimpleType() {
/* 155 */     return this.strategy.getRecordType();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/type/record/ProvidedPtrStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */