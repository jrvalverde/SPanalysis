/*    */ package org.renjin.gcc.gimple.type;
/*    */ 
/*    */ import org.renjin.gcc.gimple.expr.GimpleConstant;
/*    */ import org.renjin.gcc.gimple.expr.GimpleIntegerConstant;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GimplePointerType
/*    */   extends AbstractGimpleType
/*    */   implements GimpleIndirectType
/*    */ {
/*    */   public static final int SIZE = 32;
/*    */   private GimpleType baseType;
/*    */   
/*    */   public GimplePointerType() {}
/*    */   
/*    */   public GimplePointerType(GimpleType baseType) {
/* 35 */     this.baseType = baseType;
/*    */   }
/*    */ 
/*    */   
/*    */   public <X extends GimpleType> X getBaseType() {
/* 40 */     return (X)this.baseType;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int sizeOf() {
/* 46 */     return 4;
/*    */   }
/*    */ 
/*    */   
/*    */   public GimpleConstant nullValue() {
/* 51 */     return (GimpleConstant)GimpleIntegerConstant.nullValue(this);
/*    */   }
/*    */   
/*    */   public void setBaseType(GimpleType baseType) {
/* 55 */     this.baseType = baseType;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 60 */     return this.baseType.toString() + "*";
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isPointerTo(Class<? extends GimpleType> clazz) {
/* 65 */     return clazz.isAssignableFrom(this.baseType.getClass());
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 70 */     if (this == o) {
/* 71 */       return true;
/*    */     }
/* 73 */     if (o == null || getClass() != o.getClass()) {
/* 74 */       return false;
/*    */     }
/*    */     
/* 77 */     GimplePointerType that = (GimplePointerType)o;
/*    */     
/* 79 */     return this.baseType.equals(that.baseType);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 85 */     return this.baseType.hashCode();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/gimple/type/GimplePointerType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */