/*    */ package org.renjin.gcc.codegen.condition;
/*    */ 
/*    */ import org.renjin.gcc.codegen.MethodGenerator;
/*    */ import org.renjin.gcc.codegen.expr.JExpr;
/*    */ import org.renjin.gcc.gimple.GimpleOp;
/*    */ import org.renjin.repackaged.asm.Label;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IntegerComparison
/*    */   implements ConditionGenerator
/*    */ {
/*    */   private final GimpleOp op;
/*    */   private final JExpr x;
/*    */   private final JExpr y;
/*    */   
/*    */   public IntegerComparison(GimpleOp op, JExpr x, JExpr y) {
/* 38 */     this.op = op;
/* 39 */     this.x = x;
/* 40 */     this.y = y;
/*    */   }
/*    */ 
/*    */   
/*    */   public void emitJump(MethodGenerator mv, Label trueLabel, Label falseLabel) {
/* 45 */     this.x.load(mv);
/* 46 */     this.y.load(mv);
/*    */     
/* 48 */     switch (this.op) {
/*    */       case LT_EXPR:
/* 50 */         mv.visitJumpInsn(161, trueLabel);
/*    */         break;
/*    */       
/*    */       case LE_EXPR:
/* 54 */         mv.visitJumpInsn(164, trueLabel);
/*    */         break;
/*    */       
/*    */       case EQ_EXPR:
/* 58 */         mv.visitJumpInsn(159, trueLabel);
/*    */         break;
/*    */       
/*    */       case NE_EXPR:
/* 62 */         mv.visitJumpInsn(160, trueLabel);
/*    */         break;
/*    */       
/*    */       case GT_EXPR:
/* 66 */         mv.visitJumpInsn(163, trueLabel);
/*    */         break;
/*    */       
/*    */       case GE_EXPR:
/* 70 */         mv.visitJumpInsn(162, trueLabel);
/*    */         break;
/*    */     } 
/*    */     
/* 74 */     mv.goTo(falseLabel);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/condition/IntegerComparison.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */