/*    */ package org.renjin.gcc.codegen.expr;
/*    */ 
/*    */ import javax.annotation.Nonnull;
/*    */ import org.renjin.gcc.codegen.MethodGenerator;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BinaryOpExpr
/*    */   implements JExpr
/*    */ {
/*    */   private int opcode;
/*    */   private Type resultType;
/*    */   private JExpr x;
/*    */   private JExpr y;
/*    */   
/*    */   public BinaryOpExpr(int opcode, JExpr x, JExpr y) {
/* 35 */     this.opcode = opcode;
/* 36 */     this.resultType = x.getType();
/* 37 */     this.x = x;
/* 38 */     this.y = y;
/*    */   }
/*    */   
/*    */   public BinaryOpExpr(int opcode, Type resultType, JExpr x, JExpr y) {
/* 42 */     this.opcode = opcode;
/* 43 */     this.resultType = resultType;
/* 44 */     this.x = x;
/* 45 */     this.y = y;
/*    */   }
/*    */   
/*    */   public int getOpcode() {
/* 49 */     return this.opcode;
/*    */   }
/*    */   
/*    */   public JExpr getX() {
/* 53 */     return this.x;
/*    */   }
/*    */   
/*    */   public JExpr getY() {
/* 57 */     return this.y;
/*    */   }
/*    */ 
/*    */   
/*    */   @Nonnull
/*    */   public Type getType() {
/* 63 */     return this.resultType;
/*    */   }
/*    */ 
/*    */   
/*    */   public void load(@Nonnull MethodGenerator mv) {
/* 68 */     this.x.load(mv);
/* 69 */     this.y.load(mv);
/* 70 */     mv.visitInsn(this.x.getType().getOpcode(this.opcode));
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/expr/BinaryOpExpr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */