/*    */ package org.renjin.gcc.gimple.type;
/*    */ 
/*    */ import org.renjin.gcc.gimple.expr.GimplePrimitiveConstant;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class GimplePrimitiveType
/*    */   extends AbstractGimpleType
/*    */ {
/*    */   public abstract int localVariableSlots();
/*    */   
/*    */   public abstract Type jvmType();
/*    */   
/*    */   public static GimplePrimitiveType fromJvmType(Type type) {
/* 40 */     if (type.equals(Type.BOOLEAN_TYPE)) {
/* 41 */       return new GimpleBooleanType();
/*    */     }
/* 43 */     if (type.equals(Type.DOUBLE_TYPE)) {
/* 44 */       return new GimpleRealType(64);
/*    */     }
/* 46 */     if (type.equals(Type.FLOAT_TYPE)) {
/* 47 */       return new GimpleRealType(32);
/*    */     }
/* 49 */     if (type.equals(Type.INT_TYPE)) {
/* 50 */       return new GimpleIntegerType(32);
/*    */     }
/* 52 */     if (type.equals(Type.LONG_TYPE)) {
/* 53 */       return new GimpleIntegerType(64);
/*    */     }
/* 55 */     if (type.equals(Type.CHAR_TYPE)) {
/* 56 */       return GimpleIntegerType.unsigned(16);
/*    */     }
/* 58 */     if (type.equals(Type.SHORT_TYPE)) {
/* 59 */       return new GimpleIntegerType(16);
/*    */     }
/* 61 */     if (type.equals(Type.BYTE_TYPE)) {
/* 62 */       return new GimpleIntegerType(8);
/*    */     }
/*    */     
/* 65 */     throw new UnsupportedOperationException("type: " + type);
/*    */   }
/*    */   
/*    */   public abstract GimplePrimitiveConstant zero();
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/gimple/type/GimplePrimitiveType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */