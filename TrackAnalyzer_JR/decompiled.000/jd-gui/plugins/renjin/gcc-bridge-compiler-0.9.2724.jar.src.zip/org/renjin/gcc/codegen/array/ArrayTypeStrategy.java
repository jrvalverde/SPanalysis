/*     */ package org.renjin.gcc.codegen.array;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.renjin.gcc.codegen.MethodGenerator;
/*     */ import org.renjin.gcc.codegen.expr.ExprFactory;
/*     */ import org.renjin.gcc.codegen.expr.Expressions;
/*     */ import org.renjin.gcc.codegen.expr.GExpr;
/*     */ import org.renjin.gcc.codegen.expr.JExpr;
/*     */ import org.renjin.gcc.codegen.expr.JLValue;
/*     */ import org.renjin.gcc.codegen.fatptr.ValueFunction;
/*     */ import org.renjin.gcc.codegen.fatptr.Wrappers;
/*     */ import org.renjin.gcc.codegen.type.FieldStrategy;
/*     */ import org.renjin.gcc.codegen.type.ParamStrategy;
/*     */ import org.renjin.gcc.codegen.type.PointerTypeStrategy;
/*     */ import org.renjin.gcc.codegen.type.ReturnStrategy;
/*     */ import org.renjin.gcc.codegen.type.TypeStrategy;
/*     */ import org.renjin.gcc.codegen.type.UnsupportedCastException;
/*     */ import org.renjin.gcc.codegen.var.VarAllocator;
/*     */ import org.renjin.gcc.codegen.vptr.VPtrStrategy;
/*     */ import org.renjin.gcc.gimple.GimpleVarDecl;
/*     */ import org.renjin.gcc.gimple.expr.GimpleConstructor;
/*     */ import org.renjin.gcc.gimple.type.GimpleArrayType;
/*     */ import org.renjin.gcc.gimple.type.GimpleType;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ import org.renjin.repackaged.guava.base.Preconditions;
/*     */ import org.renjin.repackaged.guava.collect.Lists;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ArrayTypeStrategy
/*     */   implements TypeStrategy<FatArrayExpr>
/*     */ {
/*     */   private static final int MAX_UNROLL = 5;
/*     */   private final int arrayLength;
/*     */   private boolean parameterWrapped = true;
/*     */   private GimpleArrayType arrayType;
/*     */   private ValueFunction elementValueFunction;
/*     */   private ValueFunction arrayValueFunction;
/*     */   
/*     */   public ArrayTypeStrategy(GimpleArrayType arrayType, ValueFunction elementValueFunction) {
/*  54 */     this(arrayType, arrayType.getElementCount(), elementValueFunction);
/*     */   }
/*     */   
/*     */   public ArrayTypeStrategy(GimpleArrayType arrayType, int totalArrayLength, ValueFunction elementValueFunction) {
/*  58 */     this.arrayType = arrayType;
/*  59 */     this.elementValueFunction = elementValueFunction;
/*  60 */     this.arrayLength = totalArrayLength;
/*  61 */     this.arrayValueFunction = new ArrayValueFunction(arrayType, elementValueFunction);
/*     */   }
/*     */   
/*     */   public int getArrayLength() {
/*  65 */     return this.arrayLength;
/*     */   }
/*     */   
/*     */   public Type getElementType() {
/*  69 */     return this.elementValueFunction.getValueType();
/*     */   }
/*     */   
/*     */   public boolean isParameterWrapped() {
/*  73 */     return this.parameterWrapped;
/*     */   }
/*     */   
/*     */   public ArrayTypeStrategy setParameterWrapped(boolean parameterWrapped) {
/*  77 */     this.parameterWrapped = parameterWrapped;
/*  78 */     return this;
/*     */   }
/*     */   
/*     */   public ValueFunction getValueFunction() {
/*  82 */     return this.arrayValueFunction;
/*     */   }
/*     */ 
/*     */   
/*     */   public VPtrStrategy pointerTo() {
/*  87 */     return new VPtrStrategy((GimpleType)this.arrayType);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayTypeStrategy arrayOf(GimpleArrayType arrayType) {
/*  93 */     if (arrayType.isStatic()) {
/*  94 */       return new ArrayTypeStrategy(arrayType, this.arrayLength * arrayType.getElementCount(), this.arrayValueFunction);
/*     */     }
/*     */     
/*  97 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public FatArrayExpr cast(MethodGenerator mv, GExpr value) throws UnsupportedCastException {
/* 103 */     return value.toArrayExpr();
/*     */   }
/*     */ 
/*     */   
/*     */   public FieldStrategy addressableFieldGenerator(Type className, String fieldName) {
/* 108 */     return fieldGenerator(className, fieldName);
/*     */   }
/*     */ 
/*     */   
/*     */   public FatArrayExpr variable(GimpleVarDecl decl, VarAllocator allocator) {
/* 113 */     Type arrayType = Wrappers.valueArrayType(this.elementValueFunction.getValueType());
/*     */     
/* 115 */     JLValue jLValue = allocator.reserve(decl.getNameIfPresent(), arrayType, allocArray(this.arrayLength));
/* 116 */     JExpr offset = Expressions.zero();
/*     */     
/* 118 */     return new FatArrayExpr(this.arrayType, this.elementValueFunction, this.arrayLength, (JExpr)jLValue, offset);
/*     */   }
/*     */ 
/*     */   
/*     */   public FatArrayExpr providedGlobalVariable(GimpleVarDecl decl, JExpr expr, boolean readOnly) {
/* 123 */     return new FatArrayExpr(this.arrayType, this.elementValueFunction, this.arrayLength, expr, Expressions.zero());
/*     */   }
/*     */   
/*     */   private JExpr allocArray(int arrayLength) {
/* 127 */     Preconditions.checkArgument((arrayLength >= 0));
/*     */     
/* 129 */     if (this.elementValueFunction.getValueConstructor().isPresent()) {
/*     */ 
/*     */       
/* 132 */       if (arrayLength < 5) {
/*     */         
/* 134 */         List<JExpr> valueConstructors = Lists.newArrayList();
/* 135 */         for (int i = 0; i < arrayLength; i++) {
/* 136 */           valueConstructors.add(this.elementValueFunction.getValueConstructor().get());
/*     */         }
/* 138 */         return Expressions.newArray(this.elementValueFunction.getValueType(), valueConstructors);
/*     */       } 
/*     */       
/* 141 */       return new ArrayInitLoop(this.elementValueFunction, arrayLength);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 146 */     return Expressions.newArray(this.elementValueFunction.getValueType(), arrayLength);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ParamStrategy getParamStrategy() {
/* 152 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public ReturnStrategy getReturnStrategy() {
/* 157 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public FatArrayExpr constructorExpr(ExprFactory exprFactory, MethodGenerator mv, GimpleConstructor constructor) {
/* 163 */     List<JExpr> values = Lists.newArrayList();
/* 164 */     addElementConstructors(values, exprFactory, constructor);
/*     */     
/* 166 */     JExpr array = Expressions.newArray(this.elementValueFunction.getValueType(), this.arrayLength, values);
/* 167 */     JExpr offset = Expressions.zero();
/*     */     
/* 169 */     return new FatArrayExpr(this.arrayType, this.elementValueFunction, this.arrayLength, array, offset);
/*     */   }
/*     */   
/*     */   private void addElementConstructors(List<JExpr> values, ExprFactory exprFactory, GimpleConstructor constructor) {
/* 173 */     for (GimpleConstructor.Element element : constructor.getElements()) {
/* 174 */       if (element.getValue() instanceof GimpleConstructor && element
/* 175 */         .getValue().getType() instanceof GimpleArrayType) {
/* 176 */         GimpleConstructor elementConstructor = (GimpleConstructor)element.getValue();
/*     */         
/* 178 */         addElementConstructors(values, exprFactory, elementConstructor);
/*     */         continue;
/*     */       } 
/* 181 */       GExpr elementExpr = exprFactory.findGenerator(element.getValue());
/* 182 */       List<JExpr> arrayValues = this.elementValueFunction.toArrayValues(elementExpr);
/* 183 */       values.addAll(arrayValues);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public FieldStrategy fieldGenerator(Type className, String fieldName) {
/* 190 */     return (FieldStrategy)new ArrayField(className, fieldName, this.arrayLength, this.arrayType, this.elementValueFunction);
/*     */   }
/*     */   
/*     */   public GimpleArrayType getGimpleType() {
/* 194 */     return this.arrayType;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/array/ArrayTypeStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */