/*    */ package org.renjin.gcc.codegen.call;
/*    */ 
/*    */ import org.renjin.gcc.codegen.MethodGenerator;
/*    */ import org.renjin.gcc.codegen.expr.ExprFactory;
/*    */ import org.renjin.gcc.codegen.expr.JExpr;
/*    */ import org.renjin.gcc.gimple.statement.GimpleCall;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NoopCallGenerator
/*    */   implements CallGenerator, MethodHandleGenerator
/*    */ {
/*    */   private final FunctionCallGenerator functionCallGenerator;
/*    */   
/*    */   public NoopCallGenerator(FunctionCallGenerator functionCallGenerator) {
/* 31 */     this.functionCallGenerator = functionCallGenerator;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void emitCall(MethodGenerator mv, ExprFactory exprFactory, GimpleCall call) {}
/*    */ 
/*    */ 
/*    */   
/*    */   public JExpr getMethodHandle() {
/* 41 */     return this.functionCallGenerator.getMethodHandle();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/call/NoopCallGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */