/*    */ package org.renjin.gcc.gimple.type;
/*    */ 
/*    */ import org.renjin.gcc.gimple.expr.GimpleComplexConstant;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GimpleComplexType
/*    */   extends AbstractGimpleType
/*    */ {
/*    */   public GimpleComplexType() {}
/*    */   
/*    */   public GimpleComplexType(GimpleRealType partType) {
/* 33 */     setSize(Math.multiplyExact(partType.getSize(), 2));
/*    */   }
/*    */ 
/*    */   
/*    */   public int sizeOf() {
/* 38 */     return getSize() / 8;
/*    */   }
/*    */   
/*    */   public GimpleComplexConstant zero() {
/* 42 */     return new GimpleComplexConstant(getPartType().zero(), getPartType().zero());
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 47 */     return "complex";
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Type getJvmPartType() {
/* 56 */     return getPartType().jvmType();
/*    */   }
/*    */   
/*    */   public Type getJvmPartArrayType() {
/* 60 */     return Type.getType("[" + getJvmPartType().getDescriptor());
/*    */   }
/*    */   
/*    */   public GimpleRealType getPartType() {
/* 64 */     return new GimpleRealType(getSize() / 2);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object other) {
/* 69 */     if (!(other instanceof GimpleComplexType)) {
/* 70 */       return false;
/*    */     }
/* 72 */     GimpleComplexType otherType = (GimpleComplexType)other;
/*    */     
/* 74 */     return (getSize() == otherType.getSize());
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 79 */     return getSize();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/gimple/type/GimpleComplexType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */