/*    */ package org.renjin.gcc.codegen.type.primitive;
/*    */ 
/*    */ import javax.annotation.Nonnull;
/*    */ import org.renjin.gcc.codegen.MethodGenerator;
/*    */ import org.renjin.gcc.codegen.expr.JExpr;
/*    */ import org.renjin.gcc.codegen.expr.JLValue;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TruncatedByteExpr
/*    */   implements JLValue
/*    */ {
/*    */   private JExpr expr;
/*    */   
/*    */   public TruncatedByteExpr(JExpr expr) {
/* 34 */     this.expr = expr;
/*    */   }
/*    */ 
/*    */   
/*    */   public void store(MethodGenerator mv, JExpr expr) {
/* 39 */     ((JLValue)this.expr).store(mv, expr);
/*    */   }
/*    */ 
/*    */   
/*    */   @Nonnull
/*    */   public Type getType() {
/* 45 */     return Type.BYTE_TYPE;
/*    */   }
/*    */ 
/*    */   
/*    */   public void load(@Nonnull MethodGenerator mv) {
/* 50 */     this.expr.load(mv);
/* 51 */     mv.iconst(255);
/* 52 */     mv.visitInsn(126);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/type/primitive/TruncatedByteExpr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */