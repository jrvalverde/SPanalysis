/*     */ package org.renjin.gcc.peephole;
/*     */ 
/*     */ import java.util.Set;
/*     */ import org.renjin.repackaged.asm.Label;
/*     */ import org.renjin.repackaged.asm.tree.AbstractInsnNode;
/*     */ import org.renjin.repackaged.asm.tree.InsnList;
/*     */ import org.renjin.repackaged.asm.tree.LabelNode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NodeIt
/*     */ {
/*     */   private InsnList list;
/*     */   private Set<Label> jumpTargets;
/*     */   private AbstractInsnNode current;
/*     */   
/*     */   public NodeIt(InsnList list, Set<Label> jumpTargets) {
/*  39 */     this.list = list;
/*  40 */     this.jumpTargets = jumpTargets;
/*  41 */     this.current = list.getFirst();
/*     */     
/*  43 */     if (this.current == null) {
/*  44 */       throw new IllegalStateException("Empty instruction list");
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean matches(Pattern... patterns) {
/*  50 */     AbstractInsnNode node = this.current;
/*  51 */     for (Pattern pattern : patterns) {
/*  52 */       if (node == null) {
/*  53 */         return false;
/*     */       }
/*  55 */       if (!pattern.match(node)) {
/*  56 */         return false;
/*     */       }
/*  58 */       node = nextIgnoringLabels(node);
/*     */     } 
/*  60 */     return true;
/*     */   }
/*     */   
/*     */   public InsnList getList() {
/*  64 */     return this.list;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <X extends AbstractInsnNode> X get(int offset) {
/*  72 */     AbstractInsnNode node = this.current;
/*  73 */     while (offset > 0) {
/*  74 */       node = nextIgnoringLabels(node);
/*  75 */       offset--;
/*     */     } 
/*  77 */     return (X)node;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void remove(int count) {
/*  89 */     if (count < 0) {
/*  90 */       throw new IllegalArgumentException("count: " + count);
/*     */     }
/*  92 */     if (count == 0) {
/*     */       return;
/*     */     }
/*  95 */     AbstractInsnNode deleting = this.current;
/*  96 */     this.current = this.current.getPrevious();
/*     */     
/*  98 */     while (count > 0) {
/*  99 */       AbstractInsnNode next = deleting.getNext();
/* 100 */       if (!ignored(deleting)) {
/* 101 */         this.list.remove(deleting);
/* 102 */         count--;
/*     */       } 
/* 104 */       deleting = next;
/*     */     } 
/*     */     
/* 107 */     if (this.current == null) {
/* 108 */       this.current = this.list.getFirst();
/*     */     }
/*     */   }
/*     */   
/*     */   public void replace(int offset, AbstractInsnNode node) {
/* 113 */     this.list.set(get(offset), node);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void insert(AbstractInsnNode... nodes) {
/* 124 */     InsnList newList = new InsnList();
/* 125 */     for (AbstractInsnNode node : nodes) {
/* 126 */       newList.add(node);
/*     */     }
/* 128 */     this.list.insert(this.current, newList);
/*     */   }
/*     */   
/*     */   public boolean next() {
/* 132 */     this.current = nextIgnoringLabels(this.current);
/*     */     
/* 134 */     return (this.current != null);
/*     */   }
/*     */ 
/*     */   
/*     */   private AbstractInsnNode nextIgnoringLabels(AbstractInsnNode node) {
/* 139 */     AbstractInsnNode next = node.getNext();
/* 140 */     if (next == null) {
/* 141 */       return null;
/*     */     }
/* 143 */     if (ignored(next)) {
/* 144 */       return nextIgnoringLabels(next);
/*     */     }
/* 146 */     return next;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean ignored(AbstractInsnNode node) {
/* 152 */     if (node instanceof LabelNode) {
/*     */ 
/*     */       
/* 155 */       LabelNode labelNode = (LabelNode)node;
/* 156 */       return !this.jumpTargets.contains(labelNode.getLabel());
/*     */     } 
/* 158 */     if (node instanceof org.renjin.repackaged.asm.tree.LineNumberNode) {
/* 159 */       return true;
/*     */     }
/*     */     
/* 162 */     return false;
/*     */   }
/*     */   
/*     */   public void reset() {
/* 166 */     this.current = this.list.getFirst();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/peephole/NodeIt.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */