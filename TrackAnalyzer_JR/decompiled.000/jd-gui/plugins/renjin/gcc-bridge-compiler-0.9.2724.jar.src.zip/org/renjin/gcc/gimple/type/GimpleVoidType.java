/*    */ package org.renjin.gcc.gimple.type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GimpleVoidType
/*    */   extends AbstractGimpleType
/*    */ {
/*    */   public String toString() {
/* 25 */     return "void";
/*    */   }
/*    */ 
/*    */   
/*    */   public int sizeOf() {
/* 30 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 35 */     return obj instanceof GimpleVoidType;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 40 */     return 0;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/gimple/type/GimpleVoidType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */