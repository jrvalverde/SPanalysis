/*    */ package org.renjin.gcc.codegen.type.record;
/*    */ 
/*    */ import org.renjin.gcc.codegen.MethodGenerator;
/*    */ import org.renjin.gcc.codegen.expr.Expressions;
/*    */ import org.renjin.gcc.codegen.expr.GExpr;
/*    */ import org.renjin.gcc.codegen.expr.JExpr;
/*    */ import org.renjin.gcc.codegen.type.SingleFieldStrategy;
/*    */ import org.renjin.gcc.gimple.type.GimpleType;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ProvidedPtrField
/*    */   extends SingleFieldStrategy
/*    */ {
/*    */   public ProvidedPtrField(Type ownerClass, String fieldName, Type jvmType) {
/* 33 */     super(ownerClass, fieldName, jvmType);
/*    */   }
/*    */ 
/*    */   
/*    */   public GExpr memberExpr(MethodGenerator mv, JExpr instance, int offset, int size, GimpleType expectedType) {
/* 38 */     if (offset != 0) {
/* 39 */       throw new IllegalStateException("offset = " + offset);
/*    */     }
/* 41 */     return (GExpr)new ProvidedPtrExpr((JExpr)Expressions.field(instance, this.fieldType, this.fieldName));
/*    */   }
/*    */ 
/*    */   
/*    */   public void memset(MethodGenerator mv, JExpr instance, JExpr byteValue, JExpr byteCount) {
/* 46 */     memsetReference(mv, instance, byteValue, byteCount);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/type/record/ProvidedPtrField.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */