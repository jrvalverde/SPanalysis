/*    */ package org.renjin.gcc.codegen.vptr;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.Optional;
/*    */ import org.renjin.gcc.codegen.MethodGenerator;
/*    */ import org.renjin.gcc.codegen.expr.ArrayElement;
/*    */ import org.renjin.gcc.codegen.expr.Expressions;
/*    */ import org.renjin.gcc.codegen.expr.GExpr;
/*    */ import org.renjin.gcc.codegen.expr.JExpr;
/*    */ import org.renjin.gcc.codegen.expr.PtrExpr;
/*    */ import org.renjin.gcc.codegen.fatptr.FatPtrPair;
/*    */ import org.renjin.gcc.codegen.fatptr.ValueFunction;
/*    */ import org.renjin.gcc.codegen.fatptr.WrappedFatPtrExpr;
/*    */ import org.renjin.gcc.gimple.type.GimpleType;
/*    */ import org.renjin.gcc.runtime.PointerPtr;
/*    */ import org.renjin.gcc.runtime.Ptr;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VPtrValueFunction
/*    */   implements ValueFunction
/*    */ {
/*    */   private GimpleType baseType;
/*    */   
/*    */   public VPtrValueFunction(GimpleType baseType) {
/* 41 */     this.baseType = baseType;
/*    */   }
/*    */ 
/*    */   
/*    */   public Type getValueType() {
/* 46 */     return Type.getType(Ptr.class);
/*    */   }
/*    */ 
/*    */   
/*    */   public GimpleType getGimpleValueType() {
/* 51 */     return this.baseType;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getElementLength() {
/* 56 */     return 1;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getArrayElementBytes() {
/* 61 */     return 4;
/*    */   }
/*    */ 
/*    */   
/*    */   public Optional<JExpr> getValueConstructor() {
/* 66 */     return Optional.empty();
/*    */   }
/*    */ 
/*    */   
/*    */   public VPtrExpr toVPtr(JExpr array, JExpr offset) {
/* 71 */     return new VPtrExpr(Expressions.newObject(PointerPtr.class, new JExpr[] { array, offset }));
/*    */   }
/*    */ 
/*    */   
/*    */   public GExpr dereference(JExpr array, JExpr offset) {
/* 76 */     ArrayElement arrayElement = Expressions.elementAt(array, offset);
/* 77 */     return (GExpr)new VPtrExpr((JExpr)arrayElement, (PtrExpr)new FatPtrPair(this, array, offset));
/*    */   }
/*    */ 
/*    */   
/*    */   public GExpr dereference(WrappedFatPtrExpr wrapperInstance) {
/* 82 */     throw new UnsupportedOperationException("TODO");
/*    */   }
/*    */ 
/*    */   
/*    */   public List<JExpr> toArrayValues(GExpr expr) {
/* 87 */     throw new UnsupportedOperationException("TODO");
/*    */   }
/*    */ 
/*    */   
/*    */   public void memoryCopy(MethodGenerator mv, JExpr destinationArray, JExpr destinationOffset, JExpr sourceArray, JExpr sourceOffset, JExpr valueCount) {
/* 92 */     throw new UnsupportedOperationException("TODO");
/*    */   }
/*    */ 
/*    */   
/*    */   public void memorySet(MethodGenerator mv, JExpr array, JExpr offset, JExpr byteValue, JExpr length) {
/* 97 */     throw new UnsupportedOperationException("TODO");
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/vptr/VPtrValueFunction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */