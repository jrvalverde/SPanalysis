/*    */ package org.renjin.gcc.analysis;
/*    */ 
/*    */ import java.util.ListIterator;
/*    */ import java.util.Set;
/*    */ import org.renjin.gcc.gimple.GimpleBasicBlock;
/*    */ import org.renjin.gcc.gimple.GimpleCompilationUnit;
/*    */ import org.renjin.gcc.gimple.GimpleFunction;
/*    */ import org.renjin.gcc.gimple.expr.GimpleAddressOf;
/*    */ import org.renjin.gcc.gimple.expr.GimpleFunctionRef;
/*    */ import org.renjin.gcc.gimple.statement.GimpleCall;
/*    */ import org.renjin.gcc.gimple.statement.GimpleStatement;
/*    */ import org.renjin.gcc.logging.LogManager;
/*    */ import org.renjin.repackaged.guava.collect.Sets;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FunctionCallPruner
/*    */   implements FunctionBodyTransformer
/*    */ {
/* 39 */   public static final FunctionCallPruner INSTANCE = new FunctionCallPruner();
/*    */   
/* 41 */   private Set<String> noops = Sets.newHashSet();
/*    */   
/*    */   public FunctionCallPruner() {
/* 44 */     this.noops.add("__builtin_stack_save");
/* 45 */     this.noops.add("__builtin_stack_restore");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean transform(LogManager logManager, GimpleCompilationUnit unit, GimpleFunction fn) {
/* 51 */     boolean updated = false;
/*    */     
/* 53 */     for (GimpleBasicBlock basicBlock : fn.getBasicBlocks()) {
/* 54 */       ListIterator<GimpleStatement> it = basicBlock.getStatements().listIterator();
/* 55 */       while (it.hasNext()) {
/* 56 */         GimpleStatement statement = it.next();
/* 57 */         if (isNoop(statement)) {
/* 58 */           it.remove();
/* 59 */           updated = true;
/*    */         } 
/*    */       } 
/*    */     } 
/*    */     
/* 64 */     return updated;
/*    */   }
/*    */   
/*    */   private boolean isNoop(GimpleStatement statement) {
/* 68 */     if (statement instanceof GimpleCall) {
/* 69 */       GimpleCall call = (GimpleCall)statement;
/* 70 */       if (call.getFunction() instanceof GimpleAddressOf) {
/* 71 */         GimpleAddressOf addressOf = (GimpleAddressOf)call.getFunction();
/* 72 */         if (addressOf.getValue() instanceof GimpleFunctionRef) {
/* 73 */           GimpleFunctionRef ref = (GimpleFunctionRef)addressOf.getValue();
/* 74 */           return this.noops.contains(ref.getName());
/*    */         } 
/*    */       } 
/*    */     } 
/* 78 */     return false;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/analysis/FunctionCallPruner.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */