/*    */ package org.renjin.gcc.gimple.type;
/*    */ 
/*    */ import org.renjin.gcc.gimple.expr.GimpleIntegerConstant;
/*    */ import org.renjin.gcc.gimple.expr.GimplePrimitiveConstant;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GimpleBooleanType
/*    */   extends GimplePrimitiveType
/*    */ {
/*    */   public GimpleBooleanType() {
/* 28 */     setSize(8L);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 33 */     return "bool";
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 38 */     return obj instanceof GimpleBooleanType;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 43 */     return 1;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int localVariableSlots() {
/* 49 */     return 1;
/*    */   }
/*    */ 
/*    */   
/*    */   public Type jvmType() {
/* 54 */     return Type.BOOLEAN_TYPE;
/*    */   }
/*    */ 
/*    */   
/*    */   public int sizeOf() {
/* 59 */     return 1;
/*    */   }
/*    */ 
/*    */   
/*    */   public GimplePrimitiveConstant zero() {
/* 64 */     return (GimplePrimitiveConstant)new GimpleIntegerConstant(this, false);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/gimple/type/GimpleBooleanType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */