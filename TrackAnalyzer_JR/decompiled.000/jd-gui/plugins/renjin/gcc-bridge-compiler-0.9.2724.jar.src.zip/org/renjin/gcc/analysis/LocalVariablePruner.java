/*    */ package org.renjin.gcc.analysis;
/*    */ 
/*    */ import java.util.ListIterator;
/*    */ import java.util.Set;
/*    */ import org.renjin.gcc.gimple.GimpleCompilationUnit;
/*    */ import org.renjin.gcc.gimple.GimpleExprVisitor;
/*    */ import org.renjin.gcc.gimple.GimpleFunction;
/*    */ import org.renjin.gcc.gimple.GimpleVarDecl;
/*    */ import org.renjin.gcc.gimple.expr.GimpleVariableRef;
/*    */ import org.renjin.gcc.logging.LogManager;
/*    */ import org.renjin.repackaged.guava.collect.Sets;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LocalVariablePruner
/*    */   implements FunctionBodyTransformer
/*    */ {
/* 39 */   public static final LocalVariablePruner INSTANCE = new LocalVariablePruner();
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean transform(LogManager logManager, GimpleCompilationUnit unit, GimpleFunction fn) {
/* 44 */     VariableRefFinder refFinder = new VariableRefFinder();
/* 45 */     fn.accept(refFinder);
/*    */     
/* 47 */     ListIterator<GimpleVarDecl> it = fn.getVariableDeclarations().listIterator();
/* 48 */     boolean updated = false;
/* 49 */     while (it.hasNext()) {
/* 50 */       GimpleVarDecl decl = it.next();
/* 51 */       if (!refFinder.used.contains(Long.valueOf(decl.getId()))) {
/* 52 */         it.remove();
/* 53 */         updated = true;
/*    */       } 
/*    */     } 
/* 56 */     return updated;
/*    */   }
/*    */   
/*    */   private class VariableRefFinder
/*    */     extends GimpleExprVisitor {
/* 61 */     private Set<Long> used = Sets.newHashSet();
/*    */ 
/*    */     
/*    */     public void visitVariableRef(GimpleVariableRef variableRef) {
/* 65 */       this.used.add(Long.valueOf(variableRef.getId()));
/*    */     }
/*    */     
/*    */     private VariableRefFinder() {}
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/analysis/LocalVariablePruner.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */