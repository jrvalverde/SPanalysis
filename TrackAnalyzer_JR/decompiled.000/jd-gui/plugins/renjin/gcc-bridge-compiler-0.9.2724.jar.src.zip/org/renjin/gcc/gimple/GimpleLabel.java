/*    */ package org.renjin.gcc.gimple;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GimpleLabel
/*    */ {
/*    */   private String name;
/*    */   
/*    */   public GimpleLabel(String name) {
/* 26 */     this.name = name.replace(" ", "");
/*    */   }
/*    */   
/*    */   public String getName() {
/* 30 */     return this.name;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 35 */     return this.name;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/gimple/GimpleLabel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */