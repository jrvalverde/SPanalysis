/*    */ package org.renjin.gcc.gimple.expr;
/*    */ 
/*    */ import java.util.function.Predicate;
/*    */ import org.renjin.gcc.gimple.GimpleExprVisitor;
/*    */ import org.renjin.gcc.gimple.type.GimpleFunctionType;
/*    */ import org.renjin.gcc.gimple.type.GimpleType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GimpleFunctionRef
/*    */   extends GimpleExpr
/*    */ {
/*    */   private long id;
/*    */   private String name;
/*    */   
/*    */   public long getId() {
/* 30 */     return this.id;
/*    */   }
/*    */   
/*    */   public void setId(long id) {
/* 34 */     this.id = id;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 38 */     return this.name;
/*    */   }
/*    */   
/*    */   public void setName(String name) {
/* 42 */     this.name = name;
/*    */   }
/*    */ 
/*    */   
/*    */   public GimpleFunctionRef() {}
/*    */   
/*    */   public GimpleFunctionRef(String name) {
/* 49 */     this.name = name;
/* 50 */     setType((GimpleType)new GimpleFunctionType());
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 55 */     if (this.name != null) {
/* 56 */       return this.name;
/*    */     }
/* 58 */     return "T" + Math.abs(this.id);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void replaceAll(Predicate<? super GimpleExpr> predicate, GimpleExpr newExpr) {}
/*    */ 
/*    */ 
/*    */   
/*    */   public void accept(GimpleExprVisitor visitor) {
/* 69 */     visitor.visitFunctionRef(this);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/gimple/expr/GimpleFunctionRef.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */