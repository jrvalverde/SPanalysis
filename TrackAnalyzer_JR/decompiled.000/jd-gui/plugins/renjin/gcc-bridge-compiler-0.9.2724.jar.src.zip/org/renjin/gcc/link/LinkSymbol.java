/*     */ package org.renjin.gcc.link;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.Writer;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Optional;
/*     */ import java.util.Properties;
/*     */ import org.renjin.gcc.InternalCompilerException;
/*     */ import org.renjin.repackaged.asm.Handle;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ import org.renjin.repackaged.guava.base.Charsets;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LinkSymbol
/*     */ {
/*     */   private String name;
/*     */   private SymbolType type;
/*     */   private String className;
/*     */   private String memberName;
/*     */   private String descriptor;
/*     */   
/*     */   public enum SymbolType
/*     */   {
/*  56 */     FIELD,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  61 */     METHOD,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  66 */     CALL_GENERATOR;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LinkSymbol forFunction(String name, Handle methodHandle) {
/*  79 */     LinkSymbol symbol = new LinkSymbol();
/*  80 */     symbol.type = SymbolType.METHOD;
/*  81 */     symbol.name = name;
/*  82 */     symbol.className = methodHandle.getOwner();
/*  83 */     symbol.memberName = methodHandle.getName();
/*  84 */     symbol.descriptor = methodHandle.getDesc();
/*  85 */     return symbol;
/*     */   }
/*     */   
/*     */   public static LinkSymbol forGlobalVariable(String name, Type declaringClass) {
/*  89 */     LinkSymbol symbol = new LinkSymbol();
/*  90 */     symbol.type = SymbolType.FIELD;
/*  91 */     symbol.name = name;
/*  92 */     symbol.className = declaringClass.getInternalName();
/*  93 */     symbol.memberName = name;
/*  94 */     return symbol;
/*     */   }
/*     */   
/*     */   public String getName() {
/*  98 */     return this.name;
/*     */   }
/*     */   
/*     */   public SymbolType getType() {
/* 102 */     return this.type;
/*     */   }
/*     */   
/*     */   public String getClassName() {
/* 106 */     return this.className;
/*     */   }
/*     */   
/*     */   public String getMemberName() {
/* 110 */     return this.memberName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Method loadMethod(ClassLoader classLoader) {
/* 122 */     if (this.type != SymbolType.METHOD) {
/* 123 */       throw new IllegalStateException(
/* 124 */           String.format("Invalid link: Tried to link name '%s' to function, found symbol of type %s", new Object[] { this.name, this.type }));
/*     */     }
/*     */     
/* 127 */     Class<?> owner = loadClass(classLoader);
/*     */     
/* 129 */     for (Method method : owner.getMethods()) {
/* 130 */       if (method.getName().equals(this.memberName) && 
/* 131 */         Type.getMethodDescriptor(method).equals(this.descriptor)) {
/*     */         
/* 133 */         assertPublicStatic(method.getModifiers(), "method " + method.toString());
/*     */         
/* 135 */         return method;
/*     */       } 
/*     */     } 
/*     */     
/* 139 */     throw new InternalCompilerException(String.format("Symbol '%s' references non-existant method %s.%s (%s)", new Object[] { this.name, this.className, this.memberName, this.descriptor }));
/*     */   }
/*     */ 
/*     */   
/*     */   public Field loadField(ClassLoader linkClassLoader) {
/*     */     Field field;
/* 145 */     if (this.type != SymbolType.FIELD) {
/* 146 */       throw new IllegalStateException(
/* 147 */           String.format("Invalid link: Tried to link name '%s' to field, found symbol of type %s", new Object[] { this.name, this.type }));
/*     */     }
/*     */     
/* 150 */     Class<?> owner = loadClass(linkClassLoader);
/*     */ 
/*     */     
/*     */     try {
/* 154 */       field = owner.getField(this.memberName);
/* 155 */     } catch (NoSuchFieldException e) {
/* 156 */       throw new InternalCompilerException(String.format("Symbol '%s' references non-existant field %s.%s", new Object[] { this.name, this.className, this.memberName }));
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 161 */     assertPublicStatic(field.getModifiers(), "field " + field);
/*     */     
/* 163 */     return field;
/*     */   }
/*     */   
/*     */   private Class<?> loadClass(ClassLoader classLoader) {
/*     */     Class<?> owner;
/*     */     try {
/* 169 */       owner = classLoader.loadClass(this.className.replace("/", "."));
/* 170 */     } catch (ClassNotFoundException e) {
/* 171 */       throw new InternalCompilerException(String.format("Could not load class %s referenced by symbol '%s'", new Object[] { this.className, this.type }));
/*     */     } 
/*     */     
/* 174 */     return owner;
/*     */   }
/*     */ 
/*     */   
/*     */   private void assertPublicStatic(int modifiers, String memberName) {
/* 179 */     if (!Modifier.isPublic(modifiers)) {
/* 180 */       throw new InternalCompilerException(
/* 181 */           String.format("Symbol '%s' references non-public %s", new Object[] { this.name, memberName }));
/*     */     }
/*     */     
/* 184 */     if (!Modifier.isStatic(modifiers)) {
/* 185 */       throw new InternalCompilerException(
/* 186 */           String.format("Symbol '%s' references non-static %s", new Object[] { this.name, memberName }));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(File outputDir) throws IOException {
/* 200 */     File metaInfDir = new File(outputDir, "META-INF");
/* 201 */     File symbolsDir = new File(metaInfDir, "org.renjin.gcc.symbols");
/* 202 */     File symbolFile = new File(symbolsDir, this.name);
/*     */     
/* 204 */     if (!symbolsDir.exists()) {
/* 205 */       boolean created = symbolsDir.mkdirs();
/* 206 */       if (!created) {
/* 207 */         throw new IOException("Failed to create directory " + symbolsDir.getAbsolutePath());
/*     */       }
/*     */     } 
/*     */     
/* 211 */     Properties properties = new Properties();
/* 212 */     properties.setProperty("type", this.type.name());
/* 213 */     properties.setProperty("class", this.className);
/*     */     
/* 215 */     if (this.type == SymbolType.FIELD || this.type == SymbolType.METHOD) {
/* 216 */       properties.setProperty("member", this.memberName);
/*     */     }
/*     */     
/* 219 */     if (this.type == SymbolType.METHOD) {
/* 220 */       properties.setProperty("descriptor", this.descriptor);
/*     */     }
/*     */     
/* 223 */     try (Writer out = new OutputStreamWriter(new FileOutputStream(symbolFile), Charsets.UTF_8)) {
/* 224 */       properties.store(out, this.name);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static LinkSymbol fromDescriptor(String symbolName, Properties properties) {
/* 230 */     LinkSymbol symbol = new LinkSymbol();
/* 231 */     symbol.name = symbolName;
/* 232 */     symbol.type = SymbolType.valueOf(properties.getProperty("type"));
/* 233 */     symbol.className = properties.getProperty("class");
/*     */     
/* 235 */     if (symbol.type == SymbolType.FIELD || symbol.type == SymbolType.METHOD) {
/* 236 */       symbol.memberName = properties.getProperty("member");
/* 237 */       symbol.descriptor = properties.getProperty("descriptor");
/*     */     } 
/*     */     
/* 240 */     if (symbol.type == SymbolType.METHOD) {
/* 241 */       symbol.descriptor = properties.getProperty("descriptor");
/*     */     }
/*     */ 
/*     */     
/* 245 */     return symbol;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Optional<LinkSymbol> lookup(ClassLoader classLoader, String name) throws IOException {
/* 252 */     InputStream in = classLoader.getResourceAsStream("META-INF/org.renjin.gcc.symbols/" + name);
/* 253 */     if (in == null) {
/* 254 */       return Optional.empty();
/*     */     }
/* 256 */     try (InputStreamReader reader = new InputStreamReader(in, Charsets.UTF_8)) {
/* 257 */       Properties properties = new Properties();
/* 258 */       properties.load(reader);
/*     */       
/* 260 */       return Optional.of(fromDescriptor(name, properties));
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/link/LinkSymbol.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */