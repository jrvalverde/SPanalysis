/*     */ package org.renjin.gcc.codegen;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import org.renjin.gcc.GimpleCompiler;
/*     */ import org.renjin.gcc.InternalCompilerException;
/*     */ import org.renjin.gcc.analysis.FunctionOracle;
/*     */ import org.renjin.gcc.codegen.call.CallGenerator;
/*     */ import org.renjin.gcc.codegen.call.InvocationStrategy;
/*     */ import org.renjin.gcc.codegen.condition.ConditionGenerator;
/*     */ import org.renjin.gcc.codegen.expr.ExprFactory;
/*     */ import org.renjin.gcc.codegen.expr.Expressions;
/*     */ import org.renjin.gcc.codegen.expr.GExpr;
/*     */ import org.renjin.gcc.codegen.expr.JExpr;
/*     */ import org.renjin.gcc.codegen.expr.JLValue;
/*     */ import org.renjin.gcc.codegen.type.NullVariadicStrategy;
/*     */ import org.renjin.gcc.codegen.type.ParamStrategy;
/*     */ import org.renjin.gcc.codegen.type.ReturnStrategy;
/*     */ import org.renjin.gcc.codegen.type.TypeOracle;
/*     */ import org.renjin.gcc.codegen.type.VariadicStrategy;
/*     */ import org.renjin.gcc.codegen.var.GlobalVarAllocator;
/*     */ import org.renjin.gcc.codegen.var.LocalStaticVarAllocator;
/*     */ import org.renjin.gcc.codegen.var.VarAllocator;
/*     */ import org.renjin.gcc.codegen.vptr.VPtrExpr;
/*     */ import org.renjin.gcc.codegen.vptr.VPtrVariadicStrategy;
/*     */ import org.renjin.gcc.gimple.GimpleBasicBlock;
/*     */ import org.renjin.gcc.gimple.GimpleCompilationUnit;
/*     */ import org.renjin.gcc.gimple.GimpleFunction;
/*     */ import org.renjin.gcc.gimple.GimpleOp;
/*     */ import org.renjin.gcc.gimple.GimpleParameter;
/*     */ import org.renjin.gcc.gimple.GimpleVarDecl;
/*     */ import org.renjin.gcc.gimple.expr.GimpleConstructor;
/*     */ import org.renjin.gcc.gimple.expr.GimpleExpr;
/*     */ import org.renjin.gcc.gimple.statement.GimpleAssignment;
/*     */ import org.renjin.gcc.gimple.statement.GimpleCall;
/*     */ import org.renjin.gcc.gimple.statement.GimpleConditional;
/*     */ import org.renjin.gcc.gimple.statement.GimpleGoto;
/*     */ import org.renjin.gcc.gimple.statement.GimpleReturn;
/*     */ import org.renjin.gcc.gimple.statement.GimpleStatement;
/*     */ import org.renjin.gcc.gimple.statement.GimpleSwitch;
/*     */ import org.renjin.gcc.logging.LogManager;
/*     */ import org.renjin.gcc.peephole.PeepholeOptimizer;
/*     */ import org.renjin.gcc.runtime.Ptr;
/*     */ import org.renjin.gcc.symbols.LocalVariableTable;
/*     */ import org.renjin.gcc.symbols.SymbolTable;
/*     */ import org.renjin.gcc.symbols.UnitSymbolTable;
/*     */ import org.renjin.repackaged.asm.ClassVisitor;
/*     */ import org.renjin.repackaged.asm.Handle;
/*     */ import org.renjin.repackaged.asm.Label;
/*     */ import org.renjin.repackaged.asm.MethodVisitor;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ import org.renjin.repackaged.asm.tree.AnnotationNode;
/*     */ import org.renjin.repackaged.asm.tree.MethodNode;
/*     */ import org.renjin.repackaged.asm.util.Textifier;
/*     */ import org.renjin.repackaged.asm.util.TraceMethodVisitor;
/*     */ import org.renjin.repackaged.guava.base.Throwables;
/*     */ import org.renjin.repackaged.guava.collect.Lists;
/*     */ import org.renjin.repackaged.guava.collect.Maps;
/*     */ 
/*     */ public class FunctionGenerator implements InvocationStrategy {
/*  65 */   private final List<String> aliases = new ArrayList<>(); private String className;
/*     */   private GimpleFunction function;
/*     */   private boolean variadic;
/*     */   private VariadicStrategy variadicStrategy;
/*  69 */   private Map<GimpleParameter, ParamStrategy> params = Maps.newHashMap();
/*     */   
/*     */   private ReturnStrategy returnStrategy;
/*  72 */   private Labels labels = new Labels();
/*     */   
/*     */   private TypeOracle typeOracle;
/*     */   private FunctionOracle functionOracle;
/*     */   private ExprFactory exprFactory;
/*     */   private LocalStaticVarAllocator staticVarAllocator;
/*     */   private LocalVariableTable localSymbolTable;
/*     */   private LocalVariableTable localStaticSymbolTable;
/*  80 */   private Label beginLabel = new Label();
/*  81 */   private Label endLabel = new Label();
/*     */   
/*     */   private MethodGenerator mv;
/*     */   
/*     */   private boolean compilationFailed = false;
/*     */ 
/*     */   
/*     */   public FunctionGenerator(String className, GimpleFunction function, TypeOracle typeOracle, GlobalVarAllocator globalVarAllocator, UnitSymbolTable symbolTable) {
/*  89 */     this.className = className;
/*  90 */     this.function = function;
/*  91 */     this.typeOracle = typeOracle;
/*  92 */     this.functionOracle = new FunctionOracle(typeOracle, function);
/*  93 */     this.params = this.typeOracle.forParameters(function.getParameters());
/*     */     
/*  95 */     if (function.isVariadic()) {
/*  96 */       this.variadic = true;
/*  97 */       this.variadicStrategy = (VariadicStrategy)new VPtrVariadicStrategy();
/*     */     } else {
/*  99 */       this.variadicStrategy = (VariadicStrategy)new NullVariadicStrategy();
/*     */     } 
/*     */     
/* 102 */     this.returnStrategy = this.typeOracle.returnStrategyFor(function.getReturnType());
/* 103 */     this.staticVarAllocator = new LocalStaticVarAllocator("$" + function.getSafeMangledName() + "$", globalVarAllocator);
/* 104 */     this.localSymbolTable = new LocalVariableTable(symbolTable);
/* 105 */     this.localStaticSymbolTable = new LocalVariableTable(symbolTable);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getMangledName() {
/* 110 */     return this.function.getMangledName();
/*     */   }
/*     */   
/*     */   public String getSafeMangledName() {
/* 114 */     return this.function.getSafeMangledName();
/*     */   }
/*     */   
/*     */   public List<String> getMangledNames() {
/* 118 */     List<String> names = Lists.newArrayList();
/* 119 */     names.add(this.function.getMangledName());
/* 120 */     names.addAll(this.aliases);
/* 121 */     return names;
/*     */   }
/*     */   
/*     */   public void addAlias(String alias) {
/* 125 */     this.aliases.add(alias);
/*     */   }
/*     */   
/*     */   public GimpleFunction getFunction() {
/* 129 */     return this.function;
/*     */   }
/*     */   
/*     */   public void emit(LogManager logger, ClassVisitor cw) {
/*     */     try {
/*     */       Optional<VPtrExpr> varArgsPtr;
/* 135 */       logger.log(this.function, "gimple", this.function);
/*     */       
/* 137 */       if (GimpleCompiler.TRACE) {
/* 138 */         System.out.println(this.function);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 143 */       MethodNode methodNode = new MethodNode(9, this.function.getSafeMangledName(), getFunctionDescriptor(), null, null);
/*     */       
/* 145 */       methodNode.visibleParameterAnnotations = (List[])parameterAnnotations();
/*     */ 
/*     */       
/* 148 */       if (this.variadic) {
/* 149 */         int varArgIndex = getVarArgIndex();
/* 150 */         varArgsPtr = Optional.of(new VPtrExpr((JExpr)Expressions.localVariable(Type.getType(Ptr.class), varArgIndex)));
/*     */       } else {
/* 152 */         varArgsPtr = Optional.empty();
/*     */       } 
/*     */ 
/*     */       
/* 156 */       this.mv = new MethodGenerator(this.className, (MethodVisitor)methodNode);
/* 157 */       this.exprFactory = new ExprFactory(this.typeOracle, (SymbolTable)this.localSymbolTable, this.mv, varArgsPtr);
/*     */       
/* 159 */       this.mv.visitCode();
/* 160 */       this.mv.visitLabel(this.beginLabel);
/*     */       
/* 162 */       emitParamInitialization();
/* 163 */       scheduleLocalVariables();
/*     */       
/* 165 */       emitLocalVarInitialization();
/*     */       
/* 167 */       for (GimpleBasicBlock basicBlock : this.function.getBasicBlocks()) {
/* 168 */         emitBasicBlock(basicBlock);
/*     */       }
/*     */ 
/*     */       
/* 172 */       if (this.function.isEmpty() || this.function.getLastBasicBlock().fallsThrough()) {
/* 173 */         JExpr defaultReturnValue = this.returnStrategy.getDefaultReturnValue();
/* 174 */         defaultReturnValue.load(this.mv);
/* 175 */         this.mv.areturn(defaultReturnValue.getType());
/*     */       } 
/*     */       
/* 178 */       this.mv.visitLabel(this.endLabel);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 185 */       this.mv.getLocalVarAllocator().emitDebugging(this.mv, this.beginLabel, this.endLabel);
/*     */       
/* 187 */       this.mv.visitMaxs(1, 1);
/* 188 */       this.mv.visitEnd();
/*     */       
/* 190 */       logger.log(this.function, "j", toString(methodNode));
/*     */ 
/*     */       
/* 193 */       PeepholeOptimizer.INSTANCE.optimize(methodNode);
/*     */       
/* 195 */       int estimatedSize = BytecodeSizeEstimator.estimateSize(methodNode);
/* 196 */       if (estimatedSize > 40000) {
/* 197 */         System.err.println("WARNING: Method size of " + this.className + "." + this.function.getMangledName() + " may be exceeded. (Estimate: " + estimatedSize + ")");
/*     */       }
/*     */ 
/*     */       
/* 201 */       logger.log(this.function, "opt.j", toString(methodNode));
/* 202 */       logger.logTriView(this.function, (SymbolTable)this.localSymbolTable, methodNode);
/*     */       
/*     */       try {
/* 205 */         methodNode.accept(cw);
/*     */       }
/* 207 */       catch (Exception e) {
/*     */ 
/*     */ 
/*     */         
/* 211 */         throw new InternalCompilerException("Error in generated byte code for " + this.function.getName() + "\nOffending bytecode:\n" + 
/* 212 */             toString(methodNode), e);
/*     */       } 
/* 214 */     } catch (Exception e) {
/* 215 */       System.err.println("COMPILATION FAILED: " + getMangledName() + " in " + 
/* 216 */           getCompilationUnit().getSourceName());
/* 217 */       e.printStackTrace(System.err);
/*     */       
/* 219 */       logger.log(this.function, "error", Throwables.getStackTraceAsString(e));
/*     */       
/* 221 */       writeRuntimeStub(cw);
/*     */       
/* 223 */       this.compilationFailed = true;
/*     */     } 
/*     */   }
/*     */   
/*     */   private List<AnnotationNode>[] parameterAnnotations() {
/* 228 */     List[] arrayOfList = new List[countJvmParameters()];
/* 229 */     int i = 0;
/* 230 */     for (ParamStrategy paramStrategy : getParamStrategies()) {
/* 231 */       for (Type type : paramStrategy.getParameterTypes()) {
/* 232 */         i++;
/*     */       }
/*     */     } 
/* 235 */     for (AnnotationNode annotationNode : this.variadicStrategy.getParameterAnnotations()) {
/* 236 */       if (annotationNode != null) {
/* 237 */         arrayOfList[i] = Collections.singletonList(annotationNode);
/*     */       }
/* 239 */       i++;
/*     */     } 
/* 241 */     return (List<AnnotationNode>[])arrayOfList;
/*     */   }
/*     */   
/*     */   private int countJvmParameters() {
/* 245 */     int count = 0;
/* 246 */     for (ParamStrategy paramStrategy : getParamStrategies()) {
/* 247 */       count += paramStrategy.getParameterTypes().size();
/*     */     }
/* 249 */     count += this.variadicStrategy.getParameterTypes().size();
/* 250 */     return count;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeRuntimeStub(ClassVisitor cw) {
/* 257 */     MethodNode methodNode = new MethodNode(9, this.function.getSafeMangledName(), getFunctionDescriptor(), null, null);
/*     */     
/* 259 */     this.mv = new MethodGenerator(this.className, (MethodVisitor)methodNode);
/* 260 */     this.exprFactory = new ExprFactory(this.typeOracle, (SymbolTable)this.localSymbolTable, this.mv);
/*     */     
/* 262 */     this.mv.visitCode();
/* 263 */     this.mv.anew(Type.getType(RuntimeException.class));
/* 264 */     this.mv.dup();
/* 265 */     this.mv.aconst("Compilation of " + getMangledName() + " in " + getCompilationUnit().getSourceName() + " failed at build time. Please review build logs for more details.");
/*     */     
/* 267 */     this.mv.invokeconstructor(Type.getType(RuntimeException.class), new Type[] { Type.getType(String.class) });
/* 268 */     this.mv.athrow();
/* 269 */     this.mv.visitMaxs(1, 1);
/* 270 */     this.mv.visitEnd();
/*     */     
/* 272 */     methodNode.accept(cw);
/*     */   }
/*     */   
/*     */   private String toString(MethodNode methodNode) {
/*     */     try {
/* 277 */       Textifier p = new Textifier();
/* 278 */       methodNode.accept((MethodVisitor)new TraceMethodVisitor((Printer)p));
/* 279 */       StringWriter sw = new StringWriter();
/* 280 */       try (PrintWriter pw = new PrintWriter(sw)) {
/* 281 */         p.print(pw);
/*     */       } 
/* 283 */       return sw.toString();
/* 284 */     } catch (Exception e) {
/* 285 */       return "<Exception generating bytecode: " + e.getClass().getName() + ": " + e.getMessage() + ">";
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void emitParamInitialization() {
/* 291 */     int numParameters = this.function.getParameters().size();
/* 292 */     List<List<JLValue>> paramIndexes = new ArrayList<>();
/*     */     int i;
/* 294 */     for (i = 0; i < numParameters; i++) {
/* 295 */       List<JLValue> paramVars = new ArrayList<>();
/* 296 */       GimpleParameter param = this.function.getParameters().get(i);
/* 297 */       ParamStrategy paramStrategy = this.params.get(param);
/* 298 */       List<Type> parameterTypes = paramStrategy.getParameterTypes();
/* 299 */       if (parameterTypes.size() == 1) {
/* 300 */         paramVars.add(this.mv.getLocalVarAllocator().reserve(param.getName(), parameterTypes.get(0)));
/*     */       } else {
/* 302 */         for (int typeIndex = 0; typeIndex < parameterTypes.size(); typeIndex++) {
/* 303 */           String name = param.getName() + "$" + typeIndex;
/* 304 */           paramVars.add(this.mv.getLocalVarAllocator().reserve(name, parameterTypes.get(typeIndex)));
/*     */         } 
/*     */       } 
/* 307 */       paramIndexes.add(paramVars);
/*     */     } 
/*     */     
/* 310 */     if (this.variadic) {
/* 311 */       this.mv.getLocalVarAllocator().reserve(Type.getType(Ptr.class));
/*     */     }
/*     */ 
/*     */     
/* 315 */     for (i = 0; i < numParameters; i++) {
/* 316 */       GimpleParameter param = this.function.getParameters().get(i);
/* 317 */       ParamStrategy generator = this.params.get(param);
/* 318 */       GExpr expr = generator.emitInitialization(this.mv, param, paramIndexes.get(i), (VarAllocator)this.mv.getLocalVarAllocator());
/* 319 */       this.localSymbolTable.addVariable(Long.valueOf(param.getId()), expr);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void emitLocalVarInitialization() {
/* 325 */     this.mv.getLocalVarAllocator().initializeVariables(this.mv);
/*     */     
/* 327 */     for (GimpleVarDecl decl : this.function.getVariableDeclarations()) {
/* 328 */       if (!decl.isStatic()) {
/* 329 */         GExpr lhs = this.localSymbolTable.getVariable(decl);
/* 330 */         if (decl.getValue() != null) {
/* 331 */           lhs.store(this.mv, this.exprFactory.findGenerator(decl.getValue()));
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void emitLocalStaticVarInitialization(MethodGenerator mv) {
/* 339 */     if (this.compilationFailed) {
/*     */       return;
/*     */     }
/*     */     
/* 343 */     ExprFactory exprFactory = new ExprFactory(this.typeOracle, (SymbolTable)this.localStaticSymbolTable, mv);
/*     */     
/* 345 */     for (GimpleVarDecl decl : this.function.getVariableDeclarations()) {
/* 346 */       if (decl.isStatic()) {
/* 347 */         GExpr lhs = this.localSymbolTable.getVariable(decl);
/* 348 */         if (decl.getValue() != null) {
/*     */           try {
/* 350 */             lhs.store(mv, exprFactory.findGenerator(decl.getValue()));
/* 351 */           } catch (Exception e) {
/* 352 */             throw new InternalCompilerException(String.format("static variable: %s in %s", new Object[] { decl
/* 353 */                     .getName(), this.function
/* 354 */                     .getMangledName() }), e);
/*     */           } 
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void scheduleLocalVariables() {
/* 367 */     for (GimpleVarDecl varDecl : this.function.getVariableDeclarations()) {
/*     */       
/* 369 */       if (this.localSymbolTable.isRegistered(Long.valueOf(varDecl.getId()))) {
/* 370 */         System.err.printf("WARNING: In function %s, variable %s [%d] is duplicated.%n", new Object[] {
/* 371 */               getFunction().getMangledName(), varDecl
/* 372 */               .getName(), 
/* 373 */               Long.valueOf(varDecl.getId())
/*     */             });
/*     */         continue;
/*     */       } 
/*     */       try {
/* 378 */         GExpr generator = this.functionOracle.variable(varDecl, 
/* 379 */             varDecl.isStatic() ? (VarAllocator)this.staticVarAllocator : (VarAllocator)this.mv
/*     */             
/* 381 */             .getLocalVarAllocator());
/*     */         
/* 383 */         this.localSymbolTable.addVariable(Long.valueOf(varDecl.getId()), generator);
/*     */         
/* 385 */         if (varDecl.isStatic()) {
/* 386 */           this.localStaticSymbolTable.addVariable(Long.valueOf(varDecl.getId()), generator);
/*     */         }
/*     */       }
/* 389 */       catch (Exception e) {
/* 390 */         throw new InternalCompilerException("Exception generating local variable " + varDecl, e);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void emitBasicBlock(GimpleBasicBlock basicBlock) {
/* 396 */     this.mv.visitLabel(this.labels.of(basicBlock));
/*     */     
/* 398 */     Integer currentLineNumber = null;
/*     */     
/* 400 */     for (GimpleStatement ins : basicBlock.getStatements()) {
/* 401 */       Label insLabel = new Label();
/* 402 */       this.mv.visitLabel(insLabel);
/*     */       
/*     */       try {
/* 405 */         if (ins instanceof GimpleAssignment) {
/* 406 */           emitAssignment((GimpleAssignment)ins);
/* 407 */         } else if (ins instanceof GimpleReturn) {
/* 408 */           emitReturn((GimpleReturn)ins);
/* 409 */         } else if (ins instanceof GimpleGoto) {
/* 410 */           emitGoto((GimpleGoto)ins);
/* 411 */         } else if (ins instanceof GimpleConditional) {
/* 412 */           emitConditional((GimpleConditional)ins);
/* 413 */         } else if (ins instanceof GimpleCall) {
/* 414 */           emitCall((GimpleCall)ins);
/* 415 */         } else if (ins instanceof GimpleSwitch) {
/* 416 */           emitSwitch((GimpleSwitch)ins);
/*     */         } else {
/* 418 */           emitAsm(ins);
/*     */         } 
/* 420 */       } catch (Exception e) {
/* 421 */         throw new InternalCompilerException("Exception compiling instruction " + ins, e);
/*     */       } 
/*     */       
/* 424 */       if (ins.getLineNumber() != null && !Objects.equals(ins.getLineNumber(), currentLineNumber)) {
/* 425 */         this.mv.visitLineNumber(ins.getLineNumber().intValue(), insLabel);
/* 426 */         currentLineNumber = ins.getLineNumber();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void emitAsm(GimpleStatement ins) {
/* 432 */     this.mv.invokestatic(Stdlib.class, "inlineAssembly", "()V");
/*     */   }
/*     */   
/*     */   private void emitSwitch(GimpleSwitch ins) {
/* 436 */     JExpr switchValue = this.exprFactory.findPrimitiveGenerator(ins.getValue());
/* 437 */     if (switchValue.getType() == Type.INT_TYPE) {
/* 438 */       switchValue.load(this.mv);
/* 439 */     } else if (switchValue.getType() == Type.LONG_TYPE) {
/* 440 */       switchValue.load(this.mv);
/* 441 */       this.mv.visitInsn(136);
/*     */     } else {
/* 443 */       throw new InternalCompilerException("Invalid type for switch: " + switchValue.getType());
/*     */     } 
/*     */     
/* 446 */     Label defaultLabel = this.labels.of(ins.getDefaultCase().getBasicBlockIndex());
/*     */     
/* 448 */     int numCases = ins.getCaseCount();
/* 449 */     Label[] caseLabels = new Label[numCases];
/* 450 */     int[] caseValues = new int[numCases];
/*     */     
/* 452 */     int i = 0;
/* 453 */     for (GimpleSwitch.Case aCase : ins.getCases()) {
/* 454 */       for (int value = aCase.getLow(); value <= aCase.getHigh(); value++) {
/* 455 */         caseLabels[i] = this.labels.of(aCase.getBasicBlockIndex());
/* 456 */         caseValues[i] = value;
/* 457 */         i++;
/*     */       } 
/*     */     } 
/* 460 */     this.mv.visitLookupSwitchInsn(defaultLabel, caseValues, caseLabels);
/*     */   }
/*     */ 
/*     */   
/*     */   private void emitAssignment(GimpleAssignment ins) {
/* 465 */     if (isClobber(ins)) {
/*     */       return;
/*     */     }
/*     */     
/*     */     try {
/* 470 */       GExpr lhs = this.exprFactory.findGenerator((GimpleExpr)ins.getLHS());
/* 471 */       GExpr rhs = this.exprFactory.findGenerator(ins.getOperator(), ins.getOperands(), ins.getLHS().getType());
/*     */       
/* 473 */       lhs.store(this.mv, rhs);
/*     */     }
/* 475 */     catch (Exception e) {
/* 476 */       throw new RuntimeException("Exception compiling assignment to " + ins, e);
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean isClobber(GimpleAssignment ins) {
/* 481 */     return (ins.getOperator() == GimpleOp.CONSTRUCTOR && ins
/* 482 */       .getOperands().get(0) instanceof GimpleConstructor && ((GimpleConstructor)ins
/* 483 */       .getOperands().get(0)).isClobber());
/*     */   }
/*     */   
/*     */   private void emitGoto(GimpleGoto ins) {
/* 487 */     this.mv.visitJumpInsn(167, this.labels.of(ins.getTarget()));
/*     */   }
/*     */   
/*     */   private void emitConditional(GimpleConditional ins) {
/* 491 */     ConditionGenerator generator = this.exprFactory.findConditionGenerator(ins.getOperator(), ins.getOperands());
/*     */     
/* 493 */     generator.emitJump(this.mv, this.labels.of(ins.getTrueLabel()), this.labels.of(ins.getFalseLabel()));
/*     */   }
/*     */ 
/*     */   
/*     */   private void emitCall(GimpleCall ins) {
/* 498 */     CallGenerator callGenerator = this.exprFactory.findCallGenerator(ins.getFunction());
/* 499 */     callGenerator.emitCall(this.mv, this.exprFactory, ins);
/*     */   }
/*     */   
/*     */   private void emitReturn(GimpleReturn ins) {
/* 503 */     if (this.function.getReturnType() instanceof org.renjin.gcc.gimple.type.GimpleVoidType) {
/* 504 */       this.mv.areturn(Type.VOID_TYPE);
/*     */     } else {
/*     */       JExpr returnValue;
/* 507 */       if (ins.getValue() == null) {
/* 508 */         returnValue = this.returnStrategy.getDefaultReturnValue();
/*     */       } else {
/* 510 */         GExpr returnExpr = this.exprFactory.findGenerator(ins.getValue(), this.function.getReturnType());
/* 511 */         returnValue = this.returnStrategy.marshall(returnExpr);
/*     */       } 
/* 513 */       returnValue.load(this.mv);
/* 514 */       this.mv.areturn(returnValue.getType());
/*     */     } 
/*     */   }
/*     */   
/*     */   public String getFunctionDescriptor() {
/* 519 */     return TypeOracle.getMethodDescriptor(this.returnStrategy, getParamStrategies(), getVariadicStrategy());
/*     */   }
/*     */   
/*     */   private int getVarArgIndex() {
/* 523 */     int fixedArgCount = 0;
/* 524 */     for (ParamStrategy paramStrategy : getParamStrategies()) {
/* 525 */       fixedArgCount += paramStrategy.getParameterTypes().size();
/*     */     }
/* 527 */     return fixedArgCount;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<ParamStrategy> getParamStrategies() {
/* 532 */     List<ParamStrategy> parameterTypes = new ArrayList<>();
/* 533 */     for (GimpleParameter parameter : this.function.getParameters()) {
/* 534 */       ParamStrategy generator = this.params.get(parameter);
/* 535 */       parameterTypes.add(generator);
/*     */     } 
/* 537 */     return parameterTypes;
/*     */   }
/*     */ 
/*     */   
/*     */   public VariadicStrategy getVariadicStrategy() {
/* 542 */     return this.variadicStrategy;
/*     */   }
/*     */   
/*     */   public Type returnType() {
/* 546 */     return this.returnStrategy.getType();
/*     */   }
/*     */   
/*     */   public ReturnStrategy getReturnStrategy() {
/* 550 */     return this.returnStrategy;
/*     */   }
/*     */ 
/*     */   
/*     */   public void invoke(MethodGenerator mv) {
/* 555 */     mv.invokestatic(getClassName(), this.function.getSafeMangledName(), getFunctionDescriptor(), false);
/*     */   }
/*     */   
/*     */   public GimpleCompilationUnit getCompilationUnit() {
/* 559 */     return this.function.getUnit();
/*     */   }
/*     */ 
/*     */   
/*     */   public Handle getMethodHandle() {
/* 564 */     return new Handle(6, this.className, this.function.getSafeMangledName(), getFunctionDescriptor());
/*     */   }
/*     */   
/*     */   public String getClassName() {
/* 568 */     return this.className;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 573 */     return this.className + "." + getMangledName() + "()";
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-bridge-compiler-0.9.2724.jar!/org/renjin/gcc/codegen/FunctionGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */