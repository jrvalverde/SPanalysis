/*    */ package org.renjin.compiler.builtins;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.renjin.compiler.ir.ValueBounds;
/*    */ import org.renjin.compiler.ir.tac.RuntimeState;
/*    */ import org.renjin.sexp.Null;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GenericBuiltinGuard
/*    */   implements Specializer
/*    */ {
/*    */   private final BuiltinSpecializer specializer;
/*    */   
/*    */   public GenericBuiltinGuard(BuiltinSpecializer specializer) {
/* 37 */     this.specializer = specializer;
/*    */   }
/*    */ 
/*    */   
/*    */   public Specialization trySpecialize(RuntimeState runtimeState, List<ArgumentBounds> arguments) {
/* 42 */     ValueBounds object = ((ArgumentBounds)arguments.get(0)).getBounds();
/* 43 */     if (object.isClassAttributeConstant()) {
/*    */       
/* 45 */       if (object.getTypeSet() == 8192) {
/* 46 */         return S4Specialization.trySpecialize(this.specializer.getName(), runtimeState, object, arguments);
/*    */       }
/*    */ 
/*    */ 
/*    */       
/* 51 */       if (object.getConstantClassAttribute() != Null.INSTANCE) {
/* 52 */         return S3Specialization.trySpecialize(this.specializer.getName(), runtimeState, object, arguments);
/*    */       }
/*    */       
/* 55 */       return this.specializer.trySpecialize(runtimeState, arguments);
/*    */     } 
/*    */ 
/*    */     
/* 59 */     return UnspecializedCall.INSTANCE;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/builtins/GenericBuiltinGuard.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */