/*    */ package org.renjin.compiler.builtins;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.renjin.compiler.codegen.EmitContext;
/*    */ import org.renjin.compiler.ir.ValueBounds;
/*    */ import org.renjin.compiler.ir.tac.IRArgument;
/*    */ import org.renjin.compiler.ir.tac.expressions.Expression;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ import org.renjin.repackaged.asm.commons.InstructionAdapter;
/*    */ import org.renjin.sexp.ListVector;
/*    */ import org.renjin.sexp.SEXP;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GetListElement
/*    */   implements Specialization
/*    */ {
/*    */   private ValueBounds source;
/*    */   private ValueBounds index;
/*    */   private ValueBounds element;
/*    */   
/*    */   public GetListElement(ValueBounds source, ValueBounds index) {
/* 44 */     this.source = source;
/* 45 */     this.index = index;
/* 46 */     this.element = source.getElementBounds();
/*    */   }
/*    */ 
/*    */   
/*    */   public Type getType() {
/* 51 */     return Type.getType(SEXP.class);
/*    */   }
/*    */ 
/*    */   
/*    */   public ValueBounds getResultBounds() {
/* 56 */     return this.element;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void load(EmitContext emitContext, InstructionAdapter mv, List<IRArgument> arguments) {
/* 62 */     Expression sourceArgument = ((IRArgument)arguments.get(0)).getExpression();
/* 63 */     sourceArgument.load(emitContext, mv);
/* 64 */     emitContext.convert(mv, sourceArgument.getType(), Type.getType(ListVector.class));
/*    */ 
/*    */     
/* 67 */     Expression indexArgument = ((IRArgument)arguments.get(0)).getExpression();
/* 68 */     indexArgument.load(emitContext, mv);
/* 69 */     emitContext.convert(mv, indexArgument.getType(), Type.INT_TYPE);
/*    */     
/* 71 */     mv.invokeinterface(Type.getInternalName(SEXP.class), "getElementAsSEXP", 
/* 72 */         Type.getMethodDescriptor(Type.getType(SEXP.class), new Type[] { Type.INT_TYPE }));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isPure() {
/* 78 */     return true;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/builtins/GetListElement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */