/*    */ package org.renjin.eval.vfs;
/*    */ 
/*    */ import java.io.InputStream;
/*    */ import org.apache.commons.vfs2.FileSystemException;
/*    */ import org.apache.commons.vfs2.FileType;
/*    */ import org.apache.commons.vfs2.provider.AbstractFileName;
/*    */ import org.apache.commons.vfs2.provider.AbstractFileObject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FastJarRootFileObject
/*    */   extends AbstractFileObject
/*    */ {
/*    */   private FastJarFileSystem fs;
/*    */   
/*    */   protected FastJarRootFileObject(AbstractFileName name, FastJarFileSystem fs) {
/* 34 */     super(name, fs);
/* 35 */     this.fs = fs;
/*    */   }
/*    */ 
/*    */   
/*    */   protected FileType doGetType() throws Exception {
/* 40 */     return FileType.FOLDER;
/*    */   }
/*    */ 
/*    */   
/*    */   protected String[] doListChildren() throws Exception {
/* 45 */     return this.fs.getRootItems();
/*    */   }
/*    */ 
/*    */   
/*    */   protected long doGetContentSize() throws Exception {
/* 50 */     return 0L;
/*    */   }
/*    */ 
/*    */   
/*    */   protected InputStream doGetInputStream() throws Exception {
/* 55 */     throw new FileSystemException("can't open directory!");
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/eval/vfs/FastJarRootFileObject.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */