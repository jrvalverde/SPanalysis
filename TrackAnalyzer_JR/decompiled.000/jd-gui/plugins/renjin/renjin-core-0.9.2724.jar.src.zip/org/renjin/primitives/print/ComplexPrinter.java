/*    */ package org.renjin.primitives.print;
/*    */ 
/*    */ import java.text.DecimalFormat;
/*    */ import org.apache.commons.math.complex.Complex;
/*    */ import org.renjin.repackaged.guava.base.Function;
/*    */ import org.renjin.sexp.DoubleVector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ComplexPrinter
/*    */   implements Function<Complex, String>
/*    */ {
/* 30 */   private DecimalFormat format = new DecimalFormat("0.000000");
/*    */ 
/*    */   
/*    */   public String apply(Complex input) {
/* 34 */     if (DoubleVector.isNA(input.getReal())) {
/* 35 */       return "NA";
/*    */     }
/* 37 */     return this.format.format(input.getReal()) + "+" + this.format.format(input.getImaginary()) + "i";
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/print/ComplexPrinter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */