/*     */ package org.renjin.compiler.codegen;
/*     */ 
/*     */ import java.util.Map;
/*     */ import org.renjin.compiler.TypeSolver;
/*     */ import org.renjin.compiler.cfg.BasicBlock;
/*     */ import org.renjin.compiler.cfg.ControlFlowGraph;
/*     */ import org.renjin.compiler.ir.tac.IRLabel;
/*     */ import org.renjin.compiler.ir.tac.expressions.Expression;
/*     */ import org.renjin.compiler.ir.tac.expressions.LValue;
/*     */ import org.renjin.compiler.ir.tac.statements.Assignment;
/*     */ import org.renjin.compiler.ir.tac.statements.Statement;
/*     */ import org.renjin.repackaged.asm.Label;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ import org.renjin.repackaged.asm.commons.InstructionAdapter;
/*     */ import org.renjin.repackaged.guava.collect.HashMultimap;
/*     */ import org.renjin.repackaged.guava.collect.Maps;
/*     */ import org.renjin.repackaged.guava.collect.Multimap;
/*     */ import org.renjin.sexp.AtomicVector;
/*     */ import org.renjin.sexp.DoubleArrayVector;
/*     */ import org.renjin.sexp.DoubleVector;
/*     */ import org.renjin.sexp.IntVector;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.Symbol;
/*     */ import org.renjin.sexp.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EmitContext
/*     */ {
/*  42 */   private Map<IRLabel, Label> labels = Maps.newHashMap();
/*  43 */   private Multimap<LValue, Expression> definitionMap = (Multimap<LValue, Expression>)HashMultimap.create();
/*     */   
/*     */   private int paramSize;
/*     */   
/*     */   private VariableSlots variableSlots;
/*     */   private int loopVectorIndex;
/*     */   private int loopIterationIndex;
/*     */   private int maxInlineVariables;
/*     */   
/*     */   public EmitContext(ControlFlowGraph cfg, int paramSize, VariableSlots variableSlots) {
/*  53 */     this.paramSize = paramSize;
/*  54 */     this.variableSlots = variableSlots;
/*  55 */     buildDefinitionMap(cfg);
/*     */   }
/*     */   
/*     */   public int getContextVarIndex() {
/*  59 */     return 1;
/*     */   }
/*     */   public int getEnvironmentVarIndex() {
/*  62 */     return 2;
/*     */   }
/*     */   
/*     */   private void buildDefinitionMap(ControlFlowGraph cfg) {
/*  66 */     for (BasicBlock bb : cfg.getBasicBlocks()) {
/*  67 */       for (Statement stmt : bb.getStatements()) {
/*  68 */         if (stmt instanceof Assignment) {
/*  69 */           Assignment assignment = (Assignment)stmt;
/*  70 */           this.definitionMap.put(assignment.getLHS(), assignment.getRHS());
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public Label getAsmLabel(IRLabel irLabel) {
/*  77 */     Label asmLabel = this.labels.get(irLabel);
/*  78 */     if (asmLabel == null) {
/*  79 */       asmLabel = new Label();
/*  80 */       this.labels.put(irLabel, asmLabel);
/*     */     } 
/*  82 */     return asmLabel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InlineEmitContext inlineContext(ControlFlowGraph cfg, TypeSolver types) {
/*  91 */     VariableSlots childSlots = new VariableSlots(this.paramSize + this.variableSlots.getNumLocals(), types);
/*  92 */     if (childSlots.getNumLocals() > this.maxInlineVariables) {
/*  93 */       this.maxInlineVariables = childSlots.getNumLocals();
/*     */     }
/*  95 */     return new InlineEmitContext(cfg, this.paramSize + this.variableSlots
/*     */         
/*  97 */         .getNumLocals(), childSlots);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getLoopVectorIndex() {
/* 102 */     return this.loopVectorIndex;
/*     */   }
/*     */   
/*     */   public void setLoopVectorIndex(int loopVectorIndex) {
/* 106 */     this.loopVectorIndex = loopVectorIndex;
/*     */   }
/*     */   
/*     */   public int getLoopIterationIndex() {
/* 110 */     return this.loopIterationIndex;
/*     */   }
/*     */   
/*     */   public void setLoopIterationIndex(int loopIterationIndex) {
/* 114 */     this.loopIterationIndex = loopIterationIndex;
/*     */   }
/*     */   
/*     */   public int getRegister(LValue lValue) {
/* 118 */     return this.variableSlots.getSlot(lValue);
/*     */   }
/*     */ 
/*     */   
/*     */   public int convert(InstructionAdapter mv, Type fromType, Type toType) {
/* 123 */     if (fromType.equals(Type.getType(DoubleArrayVector.class))) {
/* 124 */       fromType = Type.getType(DoubleVector.class);
/*     */     }
/*     */     
/* 127 */     if (fromType.equals(toType))
/*     */     {
/* 129 */       return 0;
/*     */     }
/*     */     
/* 132 */     if (fromType.getSort() != 10 && toType.getSort() != 10) {
/*     */       
/* 134 */       mv.cast(fromType, toType);
/* 135 */       return 0;
/*     */     } 
/* 137 */     if (fromType.equals(Type.getType(SEXP.class)) || fromType.equals(Type.getType(DoubleVector.class))) {
/*     */       
/* 139 */       if (toType.getSort() == 10) {
/* 140 */         mv.checkcast(toType);
/* 141 */         return 0;
/*     */       } 
/* 143 */       if (toType.equals(Type.DOUBLE_TYPE)) {
/* 144 */         mv.invokeinterface(Type.getInternalName(SEXP.class), "asReal", 
/* 145 */             Type.getMethodDescriptor(Type.DOUBLE_TYPE, new Type[0]));
/* 146 */         return 0;
/*     */       } 
/* 148 */       if (toType.equals(Type.INT_TYPE)) {
/* 149 */         mv.checkcast(Type.getType(Vector.class));
/* 150 */         mv.iconst(0);
/* 151 */         mv.invokeinterface(Type.getInternalName(Vector.class), "getElementAsInt", 
/* 152 */             Type.getMethodDescriptor(Type.INT_TYPE, new Type[] { Type.INT_TYPE }));
/* 153 */         return 1;
/*     */       }
/*     */     
/*     */     }
/* 157 */     else if (toType.equals(Type.getType(AtomicVector.class))) {
/*     */ 
/*     */       
/* 160 */       if (fromType.equals(Type.getType(DoubleVector.class)))
/*     */       {
/* 162 */         return 0;
/*     */       }
/*     */     }
/* 165 */     else if (toType.equals(Type.getType(SEXP.class))) {
/*     */ 
/*     */       
/* 168 */       if (fromType.getSort() == 10)
/*     */       {
/* 170 */         return 0;
/*     */       }
/*     */       
/* 173 */       switch (fromType.getSort()) {
/*     */         case 5:
/* 175 */           return box(mv, IntVector.class, Type.INT_TYPE);
/*     */         
/*     */         case 8:
/* 178 */           return box(mv, DoubleVector.class, Type.DOUBLE_TYPE);
/*     */       } 
/*     */ 
/*     */     
/*     */     } 
/* 183 */     throw new UnsupportedOperationException("Unsupported conversion: " + fromType + " -> " + toType);
/*     */   }
/*     */   
/*     */   private int box(InstructionAdapter mv, Class vectorClass, Type primitiveType) {
/* 187 */     mv.invokestatic(Type.getInternalName(vectorClass), "valueOf", 
/* 188 */         Type.getMethodDescriptor(Type.getType(vectorClass), new Type[] { primitiveType }), false);
/* 189 */     return 0;
/*     */   }
/*     */   
/*     */   public VariableStorage getVariableStorage(LValue lhs) {
/* 193 */     return this.variableSlots.getStorage(lhs);
/*     */   }
/*     */   
/*     */   public int getLocalVariableCount() {
/* 197 */     return this.paramSize + this.variableSlots.getNumLocals();
/*     */   }
/*     */   
/*     */   public void writeReturn(InstructionAdapter mv, Type returnType) {
/* 201 */     mv.areturn(returnType);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeDone(InstructionAdapter mv) {}
/*     */ 
/*     */   
/*     */   public void loadParam(InstructionAdapter mv, Symbol param) {
/* 209 */     throw new IllegalStateException();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/codegen/EmitContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */