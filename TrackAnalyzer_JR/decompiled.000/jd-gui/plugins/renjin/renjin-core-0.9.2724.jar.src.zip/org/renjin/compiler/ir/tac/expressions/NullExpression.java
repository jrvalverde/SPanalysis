/*    */ package org.renjin.compiler.ir.tac.expressions;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.renjin.compiler.codegen.EmitContext;
/*    */ import org.renjin.compiler.ir.ValueBounds;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ import org.renjin.repackaged.asm.commons.InstructionAdapter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NullExpression
/*    */   implements Expression
/*    */ {
/* 36 */   public static final NullExpression INSTANCE = new NullExpression();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isPure() {
/* 42 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public int load(EmitContext emitContext, InstructionAdapter mv) {
/* 47 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   
/*    */   public Type getType() {
/* 52 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   
/*    */   public ValueBounds updateTypeBounds(Map<Expression, ValueBounds> typeMap) {
/* 57 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   
/*    */   public ValueBounds getValueBounds() {
/* 62 */     return ValueBounds.UNBOUNDED;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setChild(int i, Expression expr) {
/* 67 */     throw new IllegalArgumentException();
/*    */   }
/*    */ 
/*    */   
/*    */   public int getChildCount() {
/* 72 */     return 0;
/*    */   }
/*    */ 
/*    */   
/*    */   public Expression childAt(int index) {
/* 77 */     throw new IllegalArgumentException();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/ir/tac/expressions/NullExpression.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */