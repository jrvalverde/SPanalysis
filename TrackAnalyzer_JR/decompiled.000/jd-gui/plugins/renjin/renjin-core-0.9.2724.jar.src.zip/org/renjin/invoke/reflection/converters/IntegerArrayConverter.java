/*    */ package org.renjin.invoke.reflection.converters;
/*    */ 
/*    */ import java.lang.reflect.Array;
/*    */ import org.renjin.eval.EvalException;
/*    */ import org.renjin.sexp.IntArrayVector;
/*    */ import org.renjin.sexp.IntVector;
/*    */ import org.renjin.sexp.SEXP;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IntegerArrayConverter
/*    */   implements Converter<Object>
/*    */ {
/* 35 */   public static final IntegerArrayConverter INSTANCE = new IntegerArrayConverter();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SEXP convertToR(Object value) {
/* 42 */     if (value == null) {
/* 43 */       return (SEXP)new IntArrayVector(new int[] { Integer.MIN_VALUE });
/*    */     }
/* 45 */     int[] iArray = new int[Array.getLength(value)];
/* 46 */     for (int i = 0; i < Array.getLength(value); i++) {
/* 47 */       iArray[i] = ((Number)Array.get(value, i)).intValue();
/*    */     }
/* 49 */     return (SEXP)new IntArrayVector(iArray);
/*    */   }
/*    */ 
/*    */   
/*    */   public static boolean accept(Class clazz) {
/* 54 */     Class<?> iclazz = clazz.getComponentType();
/* 55 */     return (clazz.isArray() && (iclazz == int.class || iclazz == Integer.class || iclazz == short.class || iclazz == Short.class));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean acceptsSEXP(SEXP exp) {
/* 62 */     return exp instanceof IntVector;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int getSpecificity() {
/* 68 */     return 2;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object convertToJava(SEXP value) {
/* 73 */     if (!(value instanceof org.renjin.sexp.AtomicVector))
/* 74 */       throw new EvalException("It's not an AtomicVector", new Object[] { value.getTypeName() }); 
/* 75 */     if (value.length() < 1)
/*    */     {
/* 77 */       return new Integer[0];
/*    */     }
/* 79 */     IntVector lv = (IntVector)value;
/* 80 */     int length = lv.length();
/* 81 */     Integer[] values = new Integer[length];
/* 82 */     for (int i = 0; i < length; i++) {
/* 83 */       values[i] = lv.getElementAsObject(i);
/*    */     }
/* 85 */     return values;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/reflection/converters/IntegerArrayConverter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */