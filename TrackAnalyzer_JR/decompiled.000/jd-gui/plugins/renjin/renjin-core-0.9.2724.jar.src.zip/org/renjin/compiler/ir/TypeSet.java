/*     */ package org.renjin.compiler.ir;
/*     */ 
/*     */ import org.apache.commons.math.complex.Complex;
/*     */ import org.renjin.sexp.AtomicVector;
/*     */ import org.renjin.sexp.ComplexVector;
/*     */ import org.renjin.sexp.DoubleVector;
/*     */ import org.renjin.sexp.IntVector;
/*     */ import org.renjin.sexp.ListVector;
/*     */ import org.renjin.sexp.Logical;
/*     */ import org.renjin.sexp.RawVector;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.StringVector;
/*     */ import org.renjin.sexp.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypeSet
/*     */ {
/*     */   public static final int LIST = 2;
/*     */   public static final int NULL = 4;
/*     */   public static final int LOGICAL = 8;
/*     */   public static final int INT = 16;
/*     */   public static final int DOUBLE = 32;
/*     */   public static final int STRING = 64;
/*     */   public static final int COMPLEX = 128;
/*     */   public static final int RAW = 256;
/*     */   public static final int SYMBOL = 512;
/*     */   public static final int FUNCTION = 1024;
/*     */   public static final int ENVIRONMENT = 2048;
/*     */   public static final int PAIRLIST = 4096;
/*     */   public static final int S4 = 8192;
/*     */   public static final int ANY_ATOMIC_VECTOR = 508;
/*     */   public static final int ANY_VECTOR = 510;
/*     */   public static final int ANY_TYPE = 8190;
/*     */   public static final int NUMERIC = 48;
/*     */   
/*     */   public static int of(SEXP constant) {
/*  49 */     if (constant instanceof ListVector)
/*  50 */       return 2; 
/*  51 */     if (constant instanceof org.renjin.sexp.Null)
/*  52 */       return 4; 
/*  53 */     if (constant instanceof org.renjin.sexp.LogicalVector)
/*  54 */       return 8; 
/*  55 */     if (constant instanceof RawVector)
/*  56 */       return 256; 
/*  57 */     if (constant instanceof IntVector)
/*  58 */       return 16; 
/*  59 */     if (constant instanceof DoubleVector)
/*  60 */       return 32; 
/*  61 */     if (constant instanceof ComplexVector)
/*  62 */       return 128; 
/*  63 */     if (constant instanceof StringVector)
/*  64 */       return 64; 
/*  65 */     if (constant instanceof org.renjin.sexp.Symbol)
/*  66 */       return 512; 
/*  67 */     if (constant instanceof org.renjin.sexp.Environment)
/*  68 */       return 2048; 
/*  69 */     if (constant instanceof org.renjin.sexp.PairList)
/*  70 */       return 4096; 
/*  71 */     if (constant instanceof org.renjin.sexp.Function)
/*  72 */       return 1024; 
/*  73 */     if (constant instanceof org.renjin.sexp.S4Object) {
/*  74 */       return 8192;
/*     */     }
/*  76 */     throw new UnsupportedOperationException("TODO: " + constant.getClass().getName());
/*     */   }
/*     */ 
/*     */   
/*     */   public static int of(Class type) {
/*  81 */     if (type.equals(int.class)) {
/*  82 */       return 16;
/*     */     }
/*  84 */     if (type.equals(double.class)) {
/*  85 */       return 32;
/*     */     }
/*  87 */     if (type.equals(boolean.class) || type.equals(Logical.class)) {
/*  88 */       return 8;
/*     */     }
/*  90 */     if (type.equals(String.class)) {
/*  91 */       return 64;
/*     */     }
/*  93 */     if (type.equals(Complex.class)) {
/*  94 */       return 128;
/*     */     }
/*  96 */     if (type.equals(IntVector.class)) {
/*  97 */       return 16;
/*     */     }
/*  99 */     if (type.equals(ListVector.class)) {
/* 100 */       return 2;
/*     */     }
/* 102 */     if (type.equals(AtomicVector.class)) {
/* 103 */       return 508;
/*     */     }
/* 105 */     if (type.equals(SEXP.class)) {
/* 106 */       return 8190;
/*     */     }
/*     */     
/* 109 */     throw new UnsupportedOperationException("type: " + type);
/*     */   }
/*     */ 
/*     */   
/*     */   public static int accepts(Class type) {
/* 114 */     if (type.equals(int.class)) {
/* 115 */       return 24;
/*     */     }
/* 117 */     if (type.equals(double.class)) {
/* 118 */       return 56;
/*     */     }
/* 120 */     if (type.equals(boolean.class)) {
/* 121 */       return 8;
/*     */     }
/* 123 */     if (type.equals(byte.class)) {
/* 124 */       return 256;
/*     */     }
/* 126 */     if (type.equals(String.class)) {
/* 127 */       return 64;
/*     */     }
/* 129 */     if (type.equals(Complex.class)) {
/* 130 */       return 128;
/*     */     }
/* 132 */     if (type.equals(StringVector.class)) {
/* 133 */       return 64;
/*     */     }
/* 135 */     if (type.equals(IntVector.class)) {
/* 136 */       return 16;
/*     */     }
/* 138 */     if (type.equals(DoubleVector.class)) {
/* 139 */       return 32;
/*     */     }
/* 141 */     if (type.equals(ComplexVector.class)) {
/* 142 */       return 128;
/*     */     }
/* 144 */     if (type.equals(RawVector.class)) {
/* 145 */       return 256;
/*     */     }
/* 147 */     if (type.equals(Vector.class)) {
/* 148 */       return 510;
/*     */     }
/* 150 */     if (type.equals(AtomicVector.class)) {
/* 151 */       return 508;
/*     */     }
/* 153 */     if (type.equals(SEXP.class)) {
/* 154 */       return 8190;
/*     */     }
/*     */     
/* 157 */     throw new UnsupportedOperationException("type: " + type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String implicitClass(int typeSet) {
/* 166 */     switch (typeSet) {
/*     */       case 2:
/* 168 */         return "list";
/*     */       case 4:
/* 170 */         return "NULL";
/*     */       case 16:
/* 172 */         return "integer";
/*     */       case 32:
/* 174 */         return "double";
/*     */       case 8:
/* 176 */         return "logical";
/*     */       case 64:
/* 178 */         return "character";
/*     */       case 128:
/* 180 */         return "complex";
/*     */       case 256:
/* 182 */         return "raw";
/*     */       case 512:
/* 184 */         return "name";
/*     */       case 1024:
/* 186 */         return "function";
/*     */       case 2048:
/* 188 */         return "environment";
/*     */       case 4096:
/* 190 */         return "pairlist";
/*     */     } 
/* 192 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean matches(Class clazz, int typeSet) {
/* 198 */     int mask = accepts(clazz);
/*     */ 
/*     */     
/* 201 */     int inverseMask = mask ^ 0x1FFE;
/*     */ 
/*     */     
/* 204 */     return ((typeSet & inverseMask) == 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public static String toString(int mask) {
/* 209 */     if (mask == 8190) {
/* 210 */       return "*";
/*     */     }
/*     */     
/* 213 */     StringBuilder s = new StringBuilder();
/* 214 */     appendType(s, "list", mask, 2);
/* 215 */     appendType(s, "null", mask, 4);
/* 216 */     appendType(s, "int", mask, 16);
/* 217 */     appendType(s, "double", mask, 32);
/* 218 */     appendType(s, "logical", mask, 8);
/* 219 */     appendType(s, "character", mask, 64);
/* 220 */     appendType(s, "complex", mask, 128);
/* 221 */     appendType(s, "raw", mask, 256);
/* 222 */     appendType(s, "symbol", mask, 512);
/* 223 */     appendType(s, "function", mask, 1024);
/* 224 */     appendType(s, "environment", mask, 2048);
/* 225 */     appendType(s, "pairlist", mask, 4096);
/* 226 */     appendType(s, "S4", mask, 8192);
/* 227 */     return s.toString();
/*     */   }
/*     */   
/*     */   private static void appendType(StringBuilder sb, String name, int mask, int bit) {
/* 231 */     if ((mask & bit) != 0) {
/* 232 */       if (sb.length() > 1) {
/* 233 */         sb.append("|");
/*     */       }
/* 235 */       sb.append(name);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isDefinitelyNumeric(ValueBounds subscript) {
/* 241 */     return isDefinitelyNumeric(subscript.getTypeSet());
/*     */   }
/*     */   
/*     */   public static boolean isDefinitelyNumeric(int typeSet) {
/* 245 */     return ((typeSet & 0x30) != 0 && (typeSet & 0xFFFFFFCF) == 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public static int widestVectorType(int x, int y) {
/* 250 */     return Math.max(x, y);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static int elementOf(int typeSet) {
/* 256 */     if ((typeSet & 0xFFFFFE03) != 0) {
/* 257 */       return 8190;
/*     */     }
/*     */ 
/*     */     
/* 261 */     return typeSet;
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isDefinitelyAtomic(int typeSet) {
/* 266 */     return ((typeSet & 0x1FC) != 0 && (typeSet & 0xFFFFFE03) == 0);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/ir/TypeSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */