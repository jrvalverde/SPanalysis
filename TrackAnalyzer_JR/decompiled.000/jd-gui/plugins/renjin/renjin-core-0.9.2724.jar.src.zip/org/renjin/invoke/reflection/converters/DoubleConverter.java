/*    */ package org.renjin.invoke.reflection.converters;
/*    */ 
/*    */ import org.renjin.sexp.DoubleArrayVector;
/*    */ import org.renjin.sexp.DoubleVector;
/*    */ import org.renjin.sexp.SEXP;
/*    */ import org.renjin.sexp.Vector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DoubleConverter
/*    */   extends PrimitiveScalarConverter<Number>
/*    */ {
/* 28 */   public static final Converter INSTANCE = new DoubleConverter();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SEXP convertToR(Number value) {
/* 35 */     if (value == null) {
/* 36 */       return (SEXP)new DoubleArrayVector(new double[] { DoubleVector.NA });
/*    */     }
/* 38 */     return (SEXP)new DoubleArrayVector(new double[] { value.doubleValue() });
/*    */   }
/*    */ 
/*    */   
/*    */   public static boolean accept(Class<double> clazz) {
/* 43 */     return (clazz == double.class || clazz == Double.class || clazz == float.class || clazz == Float.class || clazz == long.class || clazz == Long.class);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Vector.Type getVectorType() {
/* 51 */     return (Vector.Type)DoubleVector.VECTOR_TYPE;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Object getFirstElement(Vector value) {
/* 56 */     return Double.valueOf(value.getElementAsDouble(0));
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean acceptsSEXP(SEXP exp) {
/* 61 */     return (exp instanceof DoubleVector || exp instanceof org.renjin.sexp.IntVector || exp instanceof org.renjin.sexp.LogicalVector);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int getSpecificity() {
/* 67 */     return 3;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/reflection/converters/DoubleConverter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */