/*    */ package org.renjin.primitives.print;
/*    */ 
/*    */ import org.renjin.repackaged.guava.base.Function;
/*    */ import org.renjin.sexp.Logical;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LogicalPrinter
/*    */   implements Function<Logical, String>
/*    */ {
/*    */   public String apply(Logical logical) {
/* 28 */     return logical.toString();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/print/LogicalPrinter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */