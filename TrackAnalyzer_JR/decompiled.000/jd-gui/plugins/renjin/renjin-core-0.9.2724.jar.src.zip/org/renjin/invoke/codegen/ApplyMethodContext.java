package org.renjin.invoke.codegen;

import com.sun.codemodel.JClass;
import com.sun.codemodel.JCodeModel;
import com.sun.codemodel.JExpression;

public interface ApplyMethodContext {
  JExpression getContext();
  
  JExpression getEnvironment();
  
  JClass classRef(Class<?> paramClass);
  
  JCodeModel getCodeModel();
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/codegen/ApplyMethodContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */