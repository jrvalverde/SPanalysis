/*     */ package org.renjin.primitives.match;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import org.renjin.eval.ClosureDispatcher;
/*     */ import org.renjin.eval.Context;
/*     */ import org.renjin.eval.EvalException;
/*     */ import org.renjin.invoke.annotations.Current;
/*     */ import org.renjin.invoke.annotations.Internal;
/*     */ import org.renjin.primitives.Contexts;
/*     */ import org.renjin.primitives.sequence.IntSequence;
/*     */ import org.renjin.primitives.vector.ConvertingStringVector;
/*     */ import org.renjin.sexp.AtomicVector;
/*     */ import org.renjin.sexp.AttributeMap;
/*     */ import org.renjin.sexp.Closure;
/*     */ import org.renjin.sexp.Environment;
/*     */ import org.renjin.sexp.FunctionCall;
/*     */ import org.renjin.sexp.IntArrayVector;
/*     */ import org.renjin.sexp.IntVector;
/*     */ import org.renjin.sexp.LogicalVector;
/*     */ import org.renjin.sexp.Null;
/*     */ import org.renjin.sexp.PairList;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.StringVector;
/*     */ import org.renjin.sexp.Symbol;
/*     */ import org.renjin.sexp.Symbols;
/*     */ import org.renjin.sexp.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Match
/*     */ {
/*     */   private static final int UNMATCHED = -1;
/*     */   private static final int MULTIPLE_MATCH = -2;
/*     */   
/*     */   @Internal
/*     */   public static IntVector match(Vector search, Vector table, int noMatch, AtomicVector incomparables) {
/*     */     FactorString factorString1, factorString2;
/*     */     Null null;
/*  56 */     if (incomparables.equals(LogicalVector.FALSE)) {
/*  57 */       null = Null.INSTANCE;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  63 */     if (search instanceof StringVector || table instanceof StringVector) {
/*  64 */       if (search.inherits("factor")) {
/*  65 */         factorString1 = new FactorString(search);
/*     */       }
/*  67 */       if (table.inherits("factor")) {
/*  68 */         factorString2 = new FactorString(table);
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  76 */     IntSequence sequence = isStringSequence((Vector)factorString2);
/*  77 */     if (sequence != null && sequence.getBy() == 1 && null.length() == 0) {
/*  78 */       return matchAgainstStringSequence((Vector)factorString1, sequence, noMatch);
/*     */     }
/*     */     
/*  81 */     Vector.Type commonType = Vector.Type.widest(factorString1.getVectorType(), factorString2.getVectorType());
/*  82 */     Vector vector1 = commonType.to((Vector)factorString1);
/*  83 */     Vector vector2 = commonType.to((Vector)factorString2);
/*     */     
/*  85 */     int[] matches = new int[vector1.length()];
/*  86 */     for (int i = 0; i != vector1.length(); i++) {
/*  87 */       if (null.contains(vector1, i)) {
/*  88 */         matches[i] = noMatch;
/*     */       } else {
/*     */         int pos;
/*  91 */         if (vector1.isElementNA(i)) {
/*  92 */           pos = indexOfNA(vector2);
/*     */         } else {
/*  94 */           pos = vector2.indexOf(vector1, i, 0);
/*     */         } 
/*  96 */         matches[i] = (pos >= 0) ? (pos + 1) : noMatch;
/*     */       } 
/*     */     } 
/*  99 */     return (IntVector)IntArrayVector.unsafe(matches);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static IntVector matchAgainstStringSequence(Vector search, IntSequence sequence, int noMatch) {
/* 106 */     assert sequence.getBy() == 1;
/*     */     
/* 108 */     int from = sequence.getFrom();
/* 109 */     int length = sequence.length();
/*     */     
/* 111 */     int[] matches = new int[search.length()];
/*     */ 
/*     */ 
/*     */     
/* 115 */     boolean identity = (search.length() == sequence.length());
/*     */     
/* 117 */     for (int i = 0; i != search.length(); i++) {
/* 118 */       String toMatch = search.getElementAsString(i);
/* 119 */       if (toMatch == null) {
/* 120 */         matches[i] = noMatch;
/* 121 */         identity = false;
/*     */       } else {
/*     */         try {
/* 124 */           int index = Integer.parseInt(toMatch) - from + 1;
/* 125 */           if (index > length) {
/* 126 */             matches[i] = noMatch;
/* 127 */             identity = false;
/*     */           } else {
/* 129 */             matches[i] = index;
/* 130 */             if (index != i + 1) {
/* 131 */               identity = false;
/*     */             }
/*     */           } 
/* 134 */         } catch (NumberFormatException ignored) {
/* 135 */           matches[i] = noMatch;
/* 136 */           identity = false;
/*     */         } 
/*     */       } 
/*     */     } 
/* 140 */     if (identity) {
/* 141 */       return (IntVector)new IntSequence(1, 1, search.length());
/*     */     }
/*     */     
/* 144 */     return (IntVector)IntArrayVector.unsafe(matches);
/*     */   }
/*     */   
/*     */   private static IntSequence isStringSequence(Vector table) {
/* 148 */     if (table instanceof ConvertingStringVector) {
/* 149 */       ConvertingStringVector wrapper = (ConvertingStringVector)table;
/* 150 */       if (wrapper.getOperand() instanceof IntSequence) {
/* 151 */         return (IntSequence)wrapper.getOperand();
/*     */       }
/*     */     } 
/* 154 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static IntVector matchUsingStringHash(Vector search, Vector table, int noMatch, AtomicVector incomparables) {
/* 161 */     HashMap<String, Integer> lookup = new HashMap<>(); int i;
/* 162 */     for (i = 0; i < table.length(); i++) {
/* 163 */       String tableElement = table.getElementAsString(i);
/* 164 */       if (!lookup.containsKey(tableElement)) {
/* 165 */         lookup.put(tableElement, Integer.valueOf(i));
/*     */       }
/*     */     } 
/*     */     
/* 169 */     for (i = 0; i < incomparables.length(); i++) {
/* 170 */       lookup.put(incomparables.getElementAsString(i), Integer.valueOf(noMatch));
/*     */     }
/*     */     
/* 173 */     int[] match = new int[search.length()];
/* 174 */     for (int j = 0; j < search.length(); j++) {
/* 175 */       String toMatch = search.getElementAsString(j);
/* 176 */       Integer index = lookup.get(toMatch);
/* 177 */       if (index == null) {
/* 178 */         match[j] = noMatch;
/*     */       } else {
/* 180 */         match[j] = index.intValue();
/*     */       } 
/*     */     } 
/*     */     
/* 184 */     return (IntVector)new IntArrayVector(match);
/*     */   }
/*     */   
/*     */   private static int indexOfNA(Vector table) {
/* 188 */     for (int i = 0; i != table.length(); i++) {
/* 189 */       if (table.isElementNA(i)) {
/* 190 */         return i;
/*     */       }
/*     */     } 
/* 193 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Internal
/*     */   public static IntVector pmatch(StringVector x, StringVector table, int noMatch, boolean duplicatesOk) {
/* 223 */     return commonStringMatch(x, table, noMatch, noMatch, duplicatesOk);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Internal
/*     */   public static IntVector charmatch(StringVector x, StringVector table, int noMatch) {
/* 233 */     return commonStringMatch(x, table, noMatch, 0, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static IntVector commonStringMatch(StringVector x, StringVector table, int unmatchedCode, int duplicatePartialsCode, boolean duplicatesOk) {
/* 247 */     IntArrayVector.Builder result = new IntArrayVector.Builder(x.length());
/* 248 */     boolean[] matchedTable = new boolean[table.length()];
/* 249 */     boolean[] matchedSearch = new boolean[x.length()];
/*     */     
/*     */     int i;
/* 252 */     for (i = 0; i != x.length(); i++) {
/* 253 */       String toMatch = pmatchElementAt(x, i);
/* 254 */       int match = exactMatch(toMatch, table);
/* 255 */       if (match != -1 && (duplicatesOk || !matchedTable[match])) {
/* 256 */         result.set(i, match + 1);
/* 257 */         matchedTable[match] = true;
/* 258 */         matchedSearch[i] = true;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 263 */     for (i = 0; i != x.length(); i++) {
/* 264 */       if (!matchedSearch[i]) {
/* 265 */         String toMatch = pmatchElementAt(x, i);
/* 266 */         int match = uniquePartialMatch(toMatch, table);
/* 267 */         if (match == -1) {
/* 268 */           result.set(i, unmatchedCode);
/* 269 */         } else if (match == -2) {
/* 270 */           result.set(i, duplicatePartialsCode);
/* 271 */         } else if (duplicatesOk || !matchedTable[match]) {
/* 272 */           result.set(i, match + 1);
/* 273 */           matchedTable[match] = true;
/*     */         } 
/*     */       } 
/*     */     } 
/* 277 */     return result.build();
/*     */   }
/*     */   
/*     */   private static int exactMatch(String toMatch, StringVector table) {
/* 281 */     for (int i = 0; i != table.length(); i++) {
/* 282 */       String t = pmatchElementAt(table, i);
/* 283 */       if (toMatch.equals(t)) {
/* 284 */         return i;
/*     */       }
/*     */     } 
/* 287 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int uniquePartialMatch(String toMatch, StringVector table) {
/* 298 */     int partialMatch = -1;
/* 299 */     for (int i = 0; i != table.length(); i++) {
/* 300 */       String t = pmatchElementAt(table, i);
/* 301 */       if (t.startsWith(toMatch)) {
/*     */         
/* 303 */         if (partialMatch != -1) {
/* 304 */           return -2;
/*     */         }
/* 306 */         partialMatch = i;
/*     */       } 
/*     */     } 
/* 309 */     return partialMatch;
/*     */   }
/*     */ 
/*     */   
/*     */   private static String pmatchElementAt(StringVector vector, int i) {
/* 314 */     return vector.isElementNA(i) ? "NA" : vector.getElementAsString(i);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Internal("match.call")
/*     */   public static SEXP matchCall(@Current Context context, @Current Environment rho, SEXP definition, FunctionCall call, boolean expandDots, SEXP environment) {
/* 321 */     Closure closure = null;
/* 322 */     if (definition instanceof Closure) {
/* 323 */       closure = (Closure)definition;
/* 324 */     } else if (definition == Null.INSTANCE) {
/*     */ 
/*     */ 
/*     */       
/* 328 */       Context parentContext = Contexts.findCallingContext(context);
/* 329 */       if (parentContext.getFunction() instanceof Closure) {
/* 330 */         closure = (Closure)parentContext.getFunction();
/*     */       }
/* 332 */       if (closure == null) {
/* 333 */         throw new EvalException("match.call() was called from outside a function", new Object[0]);
/*     */       }
/*     */     } else {
/* 336 */       throw new EvalException("match.call cannot use definition of type '%s'", new Object[] { definition.getTypeName() });
/*     */     } 
/*     */     
/* 339 */     PairList matched = ClosureDispatcher.matchArguments(closure.getFormals(), call.getArguments(), true);
/*     */     
/* 341 */     PairList.Builder expandedArgs = new PairList.Builder();
/* 342 */     for (PairList.Node node : matched.nodes()) {
/* 343 */       if (node.getValue() != Symbol.MISSING_ARG) {
/* 344 */         if (expandDots && node.getTag() == Symbols.ELLIPSES) {
/* 345 */           for (PairList.Node elipseNode : ((PairList)node.getValue()).nodes())
/* 346 */             expandedArgs.add(elipseNode.getRawTag(), elipseNode.getValue()); 
/*     */           continue;
/*     */         } 
/* 349 */         expandedArgs.add(node.getTag(), node.getValue());
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 354 */     return (SEXP)new FunctionCall(call.getFunction(), expandedArgs.build());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Internal
/*     */   public static IntVector which(Vector x) {
/* 366 */     IntArrayVector.Builder indices = new IntArrayVector.Builder();
/*     */     
/* 368 */     AtomicVector atomicVector = x.getNames();
/* 369 */     StringVector.Builder names = null;
/* 370 */     if (atomicVector != Null.INSTANCE) {
/* 371 */       names = new StringVector.Builder();
/*     */     }
/*     */     
/* 374 */     for (int i = 0; i != x.length(); i++) {
/* 375 */       if (x.isElementTrue(i)) {
/* 376 */         indices.add(i + 1);
/* 377 */         if (names != null) {
/* 378 */           names.add(atomicVector.getElementAsString(i));
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 383 */     if (names != null) {
/* 384 */       indices.setAttribute(Symbols.NAMES, (SEXP)names.build());
/*     */     }
/*     */     
/* 387 */     return indices.build();
/*     */   }
/*     */   
/*     */   private static class FactorString
/*     */     extends StringVector {
/*     */     private final Vector factor;
/*     */     private final Vector levels;
/*     */     
/*     */     private FactorString(Vector factor) {
/* 396 */       super(AttributeMap.EMPTY);
/* 397 */       this.factor = factor;
/* 398 */       this.levels = (Vector)factor.getAttribute(Symbols.LEVELS);
/*     */     }
/*     */ 
/*     */     
/*     */     public int length() {
/* 403 */       return this.factor.length();
/*     */     }
/*     */ 
/*     */     
/*     */     protected StringVector cloneWithNewAttributes(AttributeMap attributes) {
/* 408 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public String getElementAsString(int index) {
/* 413 */       if (this.factor.isElementNA(index)) {
/* 414 */         return StringVector.NA;
/*     */       }
/* 416 */       int level = this.factor.getElementAsInt(index);
/* 417 */       return this.levels.getElementAsString(level - 1);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isConstantAccessTime() {
/* 423 */       return true;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/match/Match.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */