/*    */ package org.renjin.primitives.combine.view;
/*    */ 
/*    */ import org.renjin.primitives.combine.CombinedNames;
/*    */ import org.renjin.sexp.AtomicVector;
/*    */ import org.renjin.sexp.AttributeMap;
/*    */ import org.renjin.sexp.Null;
/*    */ import org.renjin.sexp.SEXP;
/*    */ import org.renjin.sexp.StringVector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PrefixedNameVector
/*    */   extends StringVector
/*    */ {
/*    */   private String prefix;
/*    */   private AtomicVector namesVector;
/*    */   private int length;
/*    */   private boolean numberUnnamedElements;
/*    */   
/*    */   public PrefixedNameVector(String prefix, AtomicVector namesVector, boolean numberUnnamedElements, AttributeMap attributes) {
/* 36 */     super(attributes);
/* 37 */     this.numberUnnamedElements = numberUnnamedElements;
/* 38 */     this.prefix = prefix;
/* 39 */     this.namesVector = namesVector;
/*    */   }
/*    */ 
/*    */   
/*    */   public int length() {
/* 44 */     return this.namesVector.length();
/*    */   }
/*    */ 
/*    */   
/*    */   protected StringVector cloneWithNewAttributes(AttributeMap attributes) {
/* 49 */     return new PrefixedNameVector(this.prefix, this.namesVector, this.numberUnnamedElements, attributes);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getElementAsString(int index) {
/* 54 */     String name = "";
/* 55 */     if (this.namesVector != Null.INSTANCE) {
/* 56 */       name = this.namesVector.getElementAsString(index);
/*    */     }
/* 58 */     if (CombinedNames.isPresent(name))
/* 59 */       return CombinedNames.toString(this.prefix) + "." + CombinedNames.toString(name); 
/* 60 */     if (this.numberUnnamedElements) {
/* 61 */       return CombinedNames.toString(this.prefix) + Integer.toString(index + 1);
/*    */     }
/* 63 */     return this.prefix;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isConstantAccessTime() {
/* 69 */     return true;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/combine/view/PrefixedNameVector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */