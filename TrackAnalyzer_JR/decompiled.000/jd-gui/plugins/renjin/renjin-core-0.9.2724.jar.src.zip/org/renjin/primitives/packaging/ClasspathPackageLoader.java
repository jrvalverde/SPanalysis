/*    */ package org.renjin.primitives.packaging;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.net.URL;
/*    */ import java.util.Optional;
/*    */ import org.renjin.repackaged.guava.base.Charsets;
/*    */ import org.renjin.repackaged.guava.base.Strings;
/*    */ import org.renjin.repackaged.guava.io.Resources;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClasspathPackageLoader
/*    */   implements PackageLoader
/*    */ {
/*    */   private ClassLoader classLoader;
/*    */   
/*    */   public ClasspathPackageLoader() {
/* 37 */     this.classLoader = getClass().getClassLoader();
/*    */   }
/*    */   
/*    */   public ClasspathPackageLoader(ClassLoader loader) {
/* 41 */     this.classLoader = loader;
/*    */   }
/*    */   
/*    */   public ClassLoader getClassLoader() {
/* 45 */     return this.classLoader;
/*    */   }
/*    */ 
/*    */   
/*    */   public Optional<Package> load(FqPackageName name) {
/* 50 */     ClasspathPackage pkg = new ClasspathPackage(this.classLoader, name);
/* 51 */     if (pkg.resourceExists("environment")) {
/* 52 */       return Optional.of(pkg);
/*    */     }
/* 54 */     return Optional.empty();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Optional<Package> load(String packageName) {
/* 62 */     Optional<Package> pkg = tryLoadFromMetaInf(packageName);
/* 63 */     if (pkg.isPresent()) {
/* 64 */       return pkg;
/*    */     }
/*    */ 
/*    */     
/* 68 */     pkg = load(new FqPackageName("org.renjin.cran", packageName));
/* 69 */     if (pkg.isPresent()) {
/* 70 */       return pkg;
/*    */     }
/* 72 */     pkg = load(new FqPackageName("org.renjin.bioconductor", packageName));
/* 73 */     if (pkg.isPresent()) {
/* 74 */       return pkg;
/*    */     }
/*    */     
/* 77 */     return Optional.empty();
/*    */   }
/*    */   
/*    */   private Optional<Package> tryLoadFromMetaInf(String packageName) {
/* 81 */     URL resource = this.classLoader.getResource("/META-INF/org.renjin.package/" + packageName);
/* 82 */     if (resource != null) {
/*    */       try {
/* 84 */         String fullyQualifiedName = Resources.toString(resource, Charsets.UTF_8);
/* 85 */         if (!Strings.isNullOrEmpty(fullyQualifiedName)) {
/* 86 */           String[] lines = fullyQualifiedName.split("\n");
/* 87 */           String[] parts = lines[0].split(":");
/* 88 */           if (parts.length == 2) {
/* 89 */             return load(new FqPackageName(parts[0], parts[1]));
/*    */           }
/*    */         } 
/* 92 */       } catch (IOException iOException) {}
/*    */     }
/*    */     
/* 95 */     return Optional.empty();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/packaging/ClasspathPackageLoader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */