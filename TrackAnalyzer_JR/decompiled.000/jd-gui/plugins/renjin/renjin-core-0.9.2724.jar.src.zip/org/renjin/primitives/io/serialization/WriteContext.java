package org.renjin.primitives.io.serialization;

import org.renjin.sexp.Environment;

public interface WriteContext {
  boolean isBaseEnvironment(Environment paramEnvironment);
  
  boolean isNamespaceEnvironment(Environment paramEnvironment);
  
  boolean isBaseNamespaceEnvironment(Environment paramEnvironment);
  
  boolean isGlobalEnvironment(Environment paramEnvironment);
  
  String getNamespaceName(Environment paramEnvironment);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/io/serialization/WriteContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */