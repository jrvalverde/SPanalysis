/*    */ package org.renjin.invoke.reflection;
/*    */ 
/*    */ import org.renjin.eval.EvalException;
/*    */ import org.renjin.invoke.ClassBinding;
/*    */ import org.renjin.sexp.Symbol;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClassDefinitionBinding
/*    */   implements ClassBinding
/*    */ {
/* 35 */   private static final Symbol NEW = Symbol.get("new");
/*    */   
/*    */   private Class classInstance;
/*    */   private final ClassBindingImpl classBinding;
/*    */   private final ClassBindingImpl javaLangClassBinding;
/*    */   
/*    */   public ClassDefinitionBinding(Class classInstance, ClassBindingImpl classBinding) {
/* 42 */     this.classInstance = classInstance;
/* 43 */     this.classBinding = classBinding;
/* 44 */     this.javaLangClassBinding = ClassBindingImpl.get(Class.class);
/*    */   }
/*    */ 
/*    */   
/*    */   public MemberBinding getMemberBinding(Symbol name) {
/* 49 */     if (name == NEW) {
/* 50 */       return this.classBinding.getConstructorBinding();
/*    */     }
/*    */ 
/*    */ 
/*    */     
/* 55 */     MemberBinding staticMember = this.classBinding.getStaticMember(name);
/* 56 */     if (staticMember != null) {
/* 57 */       return staticMember;
/*    */     }
/*    */     
/* 60 */     MemberBinding instanceMember = this.javaLangClassBinding.getMemberBinding(name);
/* 61 */     if (instanceMember != null) {
/* 62 */       return instanceMember;
/*    */     }
/*    */     
/* 65 */     throw new EvalException("Class %s has no static member named '%s', nor does java.lang.Class have an instance member named '%s'", new Object[] { this.classBinding
/*    */           
/* 67 */           .getBoundClass().getName(), name, name });
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/reflection/ClassDefinitionBinding.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */