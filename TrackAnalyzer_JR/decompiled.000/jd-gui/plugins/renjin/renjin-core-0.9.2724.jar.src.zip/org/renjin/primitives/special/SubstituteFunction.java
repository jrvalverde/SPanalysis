/*     */ package org.renjin.primitives.special;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.renjin.eval.ClosureDispatcher;
/*     */ import org.renjin.eval.Context;
/*     */ import org.renjin.eval.EvalException;
/*     */ import org.renjin.repackaged.guava.collect.Lists;
/*     */ import org.renjin.sexp.Environment;
/*     */ import org.renjin.sexp.ExpressionVector;
/*     */ import org.renjin.sexp.FunctionCall;
/*     */ import org.renjin.sexp.ListVector;
/*     */ import org.renjin.sexp.Null;
/*     */ import org.renjin.sexp.PairList;
/*     */ import org.renjin.sexp.Promise;
/*     */ import org.renjin.sexp.PromisePairList;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.SexpVisitor;
/*     */ import org.renjin.sexp.SpecialFunction;
/*     */ import org.renjin.sexp.Symbol;
/*     */ import org.renjin.sexp.Symbols;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SubstituteFunction
/*     */   extends SpecialFunction
/*     */ {
/*  31 */   private static final Symbol EXPR_ARGUMENT = Symbol.get("expr");
/*  32 */   private static final Symbol ENV_ARGUMENT = Symbol.get("env");
/*     */   
/*     */   private final PairList formals;
/*     */   
/*     */   public SubstituteFunction() {
/*  37 */     super("substitute");
/*     */     
/*  39 */     this
/*     */ 
/*     */       
/*  42 */       .formals = (new PairList.Builder()).add(EXPR_ARGUMENT, (SEXP)Symbol.MISSING_ARG).add(ENV_ARGUMENT, (SEXP)Symbol.MISSING_ARG).build();
/*     */   }
/*     */ 
/*     */   
/*     */   public SEXP apply(Context context, Environment rho, FunctionCall call, PairList args) {
/*     */     SEXP expr;
/*  48 */     PairList matchedArguments = ClosureDispatcher.matchArguments(this.formals, args);
/*     */     
/*  50 */     SEXP exprArgument = matchedArguments.findByTag(EXPR_ARGUMENT);
/*  51 */     SEXP envArgument = matchedArguments.findByTag(ENV_ARGUMENT);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  57 */     if (exprArgument == Symbols.ELLIPSES) {
/*     */       
/*  59 */       SEXP ellipses = rho.getEllipsesVariable();
/*  60 */       if (ellipses == Null.INSTANCE) {
/*  61 */         Null null = Null.INSTANCE;
/*     */       } else {
/*  63 */         PromisePairList.Node promisePairList = (PromisePairList.Node)ellipses;
/*  64 */         Promise promisedArg = (Promise)promisePairList.getValue();
/*  65 */         expr = promisedArg.getExpression();
/*     */       } 
/*     */     } else {
/*  68 */       expr = exprArgument;
/*     */     } 
/*     */     
/*  71 */     return substitute(expr, buildContext(context, rho, envArgument));
/*     */   }
/*     */   
/*     */   private static SubstituteContext buildContext(Context context, Environment rho, SEXP argument) {
/*  75 */     if (argument == Symbol.MISSING_ARG) {
/*  76 */       return buildContext(context, (SEXP)rho);
/*     */     }
/*     */     
/*  79 */     SEXP env = context.evaluate(argument, rho);
/*     */     
/*  81 */     return buildContext(context, env);
/*     */   }
/*     */   
/*     */   private static SubstituteContext buildContext(Context context, SEXP evaluatedEnv) {
/*  85 */     if (evaluatedEnv instanceof Environment) {
/*  86 */       if (context.getGlobalEnvironment() == evaluatedEnv) {
/*  87 */         return new GlobalEnvironmentContext();
/*     */       }
/*  89 */       return new EnvironmentContext(context, (Environment)evaluatedEnv);
/*     */     } 
/*  91 */     if (evaluatedEnv instanceof ListVector)
/*  92 */       return new ListContext((ListVector)evaluatedEnv); 
/*  93 */     if (evaluatedEnv instanceof PairList) {
/*  94 */       return new PairListContext((PairList)evaluatedEnv);
/*     */     }
/*     */     
/*  97 */     throw new EvalException("Cannot substitute using environment of type %s: expected list, pairlist, or environment", new Object[] { evaluatedEnv
/*  98 */           .getTypeName() });
/*     */   }
/*     */ 
/*     */   
/*     */   public static SEXP substitute(Context context, SEXP exp, SEXP environment) {
/* 103 */     return substitute(exp, buildContext(context, environment));
/*     */   }
/*     */   
/*     */   private static SEXP substitute(SEXP exp, SubstituteContext context) {
/* 107 */     SubstitutingVisitor visitor = new SubstitutingVisitor(context);
/* 108 */     exp.accept(visitor);
/* 109 */     return visitor.getResult();
/*     */   }
/*     */   
/*     */   public static class SubstitutingVisitor extends SexpVisitor<SEXP> {
/*     */     private final SubstituteFunction.SubstituteContext context;
/*     */     private SEXP result;
/*     */     
/*     */     public SubstitutingVisitor(SubstituteFunction.SubstituteContext context) {
/* 117 */       this.context = context;
/*     */     }
/*     */ 
/*     */     
/*     */     public void visit(FunctionCall call) {
/* 122 */       this
/*     */ 
/*     */         
/* 125 */         .result = (SEXP)new FunctionCall(substitute(call.getFunction()), substituteArgumentList(call.getArguments()), call.getAttributes());
/*     */     }
/*     */ 
/*     */     
/*     */     private PairList substituteArgumentList(PairList arguments) {
/* 130 */       PairList.Builder builder = PairList.Node.newBuilder();
/* 131 */       for (PairList.Node node : arguments.nodes()) {
/* 132 */         if (node.getValue().equals(Symbols.ELLIPSES)) {
/* 133 */           SEXP extraArguments = this.context.getVariable(Symbols.ELLIPSES);
/* 134 */           if (extraArguments != Symbol.UNBOUND_VALUE) {
/* 135 */             builder.addAll(unpackPromiseList((PromisePairList)extraArguments)); continue;
/*     */           } 
/* 137 */           builder.add((SEXP)Symbols.ELLIPSES);
/*     */           continue;
/*     */         } 
/* 140 */         builder.add(node.getRawTag(), substitute(node.getValue()));
/*     */       } 
/*     */       
/* 143 */       return builder.build();
/*     */     }
/*     */ 
/*     */     
/*     */     public void visit(PairList.Node pairList) {
/* 148 */       PairList.Builder builder = PairList.Node.newBuilder();
/* 149 */       for (PairList.Node node : pairList.nodes()) {
/* 150 */         builder.add(node.getRawTag(), substitute(node.getValue()));
/*     */       }
/* 152 */       this.result = (SEXP)builder.build();
/*     */     }
/*     */ 
/*     */     
/*     */     public void visit(ListVector list) {
/* 157 */       ListVector.Builder builder = ListVector.newBuilder();
/* 158 */       for (SEXP exp : list) {
/* 159 */         builder.add(substitute(exp));
/*     */       }
/* 161 */       builder.copyAttributesFrom((SEXP)list);
/* 162 */       this.result = (SEXP)builder.build();
/*     */     }
/*     */ 
/*     */     
/*     */     public void visit(ExpressionVector vector) {
/* 167 */       List<SEXP> list = Lists.newArrayList();
/* 168 */       for (SEXP exp : vector) {
/* 169 */         list.add(substitute(exp));
/*     */       }
/* 171 */       this.result = (SEXP)new ExpressionVector(list, vector.getAttributes());
/*     */     }
/*     */ 
/*     */     
/*     */     public void visit(Symbol symbol) {
/* 176 */       if (this.context.hasVariable(symbol)) {
/* 177 */         this.result = unpromise(this.context.getVariable(symbol));
/*     */       } else {
/* 179 */         this.result = (SEXP)symbol;
/*     */       } 
/*     */     }
/*     */     
/*     */     private PairList unpackPromiseList(PromisePairList dotExp) {
/* 184 */       PairList.Builder unpacked = new PairList.Builder();
/* 185 */       for (PairList.Node node : dotExp.nodes()) {
/* 186 */         unpacked.add(node.getRawTag(), unpromise(node.getValue()));
/*     */       }
/* 188 */       return unpacked.build();
/*     */     }
/*     */     
/*     */     private SEXP unpromise(SEXP value) {
/* 192 */       while (value instanceof Promise) {
/* 193 */         value = ((Promise)value).getExpression();
/*     */       }
/* 195 */       return value;
/*     */     }
/*     */ 
/*     */     
/*     */     public void visit(PromisePairList dotExp) {
/* 200 */       super.visit(dotExp);
/*     */     }
/*     */ 
/*     */     
/*     */     protected void unhandled(SEXP exp) {
/* 205 */       this.result = exp;
/*     */     }
/*     */ 
/*     */     
/*     */     public SEXP getResult() {
/* 210 */       return this.result;
/*     */     }
/*     */     
/*     */     private SEXP substitute(SEXP exp) {
/* 214 */       return SubstituteFunction.substitute(exp, this.context);
/*     */     }
/*     */   }
/*     */   
/*     */   private static interface SubstituteContext {
/*     */     SEXP getVariable(Symbol param1Symbol);
/*     */     
/*     */     boolean hasVariable(Symbol param1Symbol);
/*     */   }
/*     */   
/*     */   private static class EnvironmentContext implements SubstituteContext {
/*     */     private final Environment rho;
/*     */     private Context context;
/*     */     
/*     */     public EnvironmentContext(Context context, Environment rho) {
/* 229 */       this.rho = rho;
/* 230 */       this.context = context;
/*     */     }
/*     */ 
/*     */     
/*     */     public SEXP getVariable(Symbol name) {
/* 235 */       return this.rho.getVariable(this.context, name);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasVariable(Symbol name) {
/* 240 */       return this.rho.hasVariable(name);
/*     */     }
/*     */   }
/*     */   
/*     */   private static class GlobalEnvironmentContext
/*     */     implements SubstituteContext {
/*     */     private GlobalEnvironmentContext() {}
/*     */     
/*     */     public SEXP getVariable(Symbol name) {
/* 249 */       return (SEXP)Symbol.UNBOUND_VALUE;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasVariable(Symbol name) {
/* 254 */       return false;
/*     */     }
/*     */   }
/*     */   
/*     */   private static class ListContext implements SubstituteContext {
/*     */     private ListVector list;
/*     */     
/*     */     public ListContext(ListVector list) {
/* 262 */       this.list = list;
/*     */     }
/*     */ 
/*     */     
/*     */     public SEXP getVariable(Symbol name) {
/* 267 */       int index = this.list.getIndexByName(name.getPrintName());
/* 268 */       if (index == -1) {
/* 269 */         return (SEXP)Symbol.UNBOUND_VALUE;
/*     */       }
/* 271 */       return this.list.getElementAsSEXP(index);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean hasVariable(Symbol name) {
/* 277 */       return (this.list.getIndexByName(name.getPrintName()) != -1);
/*     */     }
/*     */   }
/*     */   
/*     */   private static class PairListContext
/*     */     implements SubstituteContext {
/*     */     private PairList list;
/*     */     
/*     */     public PairListContext(PairList list) {
/* 286 */       this.list = list;
/*     */     }
/*     */ 
/*     */     
/*     */     public SEXP getVariable(Symbol name) {
/* 291 */       for (PairList.Node node : this.list.nodes()) {
/* 292 */         if (node.getTag() == name) {
/* 293 */           return node.getValue();
/*     */         }
/*     */       } 
/* 296 */       return (SEXP)Symbol.UNBOUND_VALUE;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasVariable(Symbol name) {
/* 301 */       return (getVariable(name) != Symbol.UNBOUND_VALUE);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/special/SubstituteFunction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */