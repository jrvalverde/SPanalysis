/*    */ package org.renjin.compiler.cfg;
/*    */ 
/*    */ import org.renjin.compiler.ir.ssa.PhiFunction;
/*    */ import org.renjin.compiler.ir.tac.expressions.Expression;
/*    */ import org.renjin.compiler.ir.tac.statements.Assignment;
/*    */ import org.renjin.compiler.ir.tac.statements.Statement;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SsaEdge
/*    */ {
/*    */   private Assignment definition;
/*    */   private Statement destinationStatement;
/*    */   private BasicBlock destinationNode;
/*    */   
/*    */   public SsaEdge(Assignment definition, BasicBlock usageNode, Statement statement) {
/* 37 */     this.definition = definition;
/* 38 */     this.destinationNode = usageNode;
/* 39 */     this.destinationStatement = statement;
/*    */   }
/*    */   
/*    */   public Assignment getDefinition() {
/* 43 */     return this.definition;
/*    */   }
/*    */   
/*    */   public BasicBlock getDestinationNode() {
/* 47 */     return this.destinationNode;
/*    */   }
/*    */   
/*    */   public Statement getDestinationStatement() {
/* 51 */     return this.destinationStatement;
/*    */   }
/*    */   
/*    */   public Expression getDestination() {
/* 55 */     return this.destinationStatement.getRHS();
/*    */   }
/*    */   
/*    */   public boolean isPhiFunction() {
/* 59 */     return this.destinationStatement.getRHS() instanceof PhiFunction;
/*    */   }
/*    */   
/*    */   public PhiFunction getPhiFunction() {
/* 63 */     return (PhiFunction)getDestination();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/cfg/SsaEdge.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */