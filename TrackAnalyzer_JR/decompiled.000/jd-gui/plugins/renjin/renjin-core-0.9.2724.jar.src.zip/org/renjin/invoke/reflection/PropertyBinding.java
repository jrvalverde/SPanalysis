/*     */ package org.renjin.invoke.reflection;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import org.renjin.eval.EvalException;
/*     */ import org.renjin.invoke.reflection.converters.Converter;
/*     */ import org.renjin.invoke.reflection.converters.Converters;
/*     */ import org.renjin.repackaged.guava.collect.Lists;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.Symbol;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PropertyBinding
/*     */   implements MemberBinding
/*     */ {
/*     */   private Symbol name;
/*     */   private Method getter;
/*     */   private Converter getterConverter;
/*     */   private List<Setter> setters;
/*     */   
/*     */   public PropertyBinding(Symbol name, Method getter, Collection<Method> setters) {
/*  47 */     this.name = name;
/*  48 */     this.getter = getter;
/*  49 */     this.getterConverter = Converters.get(getter.getReturnType());
/*     */     
/*  51 */     this.setters = Lists.newArrayList();
/*  52 */     for (Method setter : setters) {
/*  53 */       this.setters.add(new Setter(setter));
/*     */     }
/*     */   }
/*     */   
/*     */   public Symbol getName() {
/*  58 */     return this.name;
/*     */   }
/*     */   
/*     */   public Converter getConverter() {
/*  62 */     return this.getterConverter;
/*     */   }
/*     */   
/*     */   public SEXP getValue(Object instance) {
/*     */     try {
/*  67 */       return this.getterConverter.convertToR(this.getter.invoke(instance, new Object[0]));
/*  68 */     } catch (Exception e) {
/*  69 */       throw new EvalException("Exception thrown while invoking getter '%s' on instance of class '%s'", new Object[] { this.getter
/*  70 */             .getName(), this.getter.getDeclaringClass().getName() });
/*     */     } 
/*     */   }
/*     */   
/*     */   public Object getRawValue(Object instance) {
/*     */     try {
/*  76 */       return this.getter.invoke(instance, new Object[0]);
/*  77 */     } catch (IllegalAccessException e) {
/*  78 */       throw new IllegalStateException("IllegalAccessException thrown while accessing public member " + this.name, e);
/*  79 */     } catch (InvocationTargetException e) {
/*  80 */       throw new RuntimeException(e.getCause());
/*     */     } 
/*     */   }
/*     */   
/*     */   private static class Setter {
/*     */     private Method method;
/*     */     private Converter converter;
/*     */     
/*     */     public Setter(Method method) {
/*  89 */       this.method = method;
/*  90 */       this.converter = Converters.get(method.getParameterTypes()[0]);
/*     */     }
/*     */     
/*     */     public void setValue(Object instance, SEXP value) {
/*  94 */       Object convertedValue = this.converter.convertToJava(value);
/*     */       try {
/*  96 */         this.method.invoke(instance, new Object[] { convertedValue });
/*  97 */       } catch (InvocationTargetException e) {
/*  98 */         throw new EvalException(e.getTargetException().getMessage(), e.getTargetException());
/*     */       }
/* 100 */       catch (Exception e) {
/* 101 */         throw new EvalException("Exception thrown while calling setter '%s' on instance of class '%s': %s", new Object[] { this.method
/* 102 */               .getName(), this.method.getDeclaringClass().getName(), e.getMessage(), e });
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void setValue(Object instance, SEXP value) {
/* 109 */     if (this.setters.size() == 0)
/* 110 */       throw new EvalException("The property '%s' on class '%s' is read-only", new Object[] { this.name, this.getter
/* 111 */             .getDeclaringClass().getName() }); 
/* 112 */     if (this.setters.size() > 1) {
/* 113 */       throw new EvalException("Overloaded setters are not yet implemented", new Object[0]);
/*     */     }
/*     */     
/* 116 */     ((Setter)this.setters.get(0)).setValue(instance, value);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/reflection/PropertyBinding.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */