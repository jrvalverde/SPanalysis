/*     */ package org.renjin.eval.vfs;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.Collection;
/*     */ import java.util.Enumeration;
/*     */ import java.util.List;
/*     */ import java.util.jar.JarEntry;
/*     */ import java.util.jar.JarFile;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.commons.vfs2.Capability;
/*     */ import org.apache.commons.vfs2.FileName;
/*     */ import org.apache.commons.vfs2.FileObject;
/*     */ import org.apache.commons.vfs2.FileSystem;
/*     */ import org.apache.commons.vfs2.FileSystemException;
/*     */ import org.apache.commons.vfs2.FileSystemOptions;
/*     */ import org.apache.commons.vfs2.Selectors;
/*     */ import org.apache.commons.vfs2.VfsLog;
/*     */ import org.apache.commons.vfs2.provider.AbstractFileName;
/*     */ import org.apache.commons.vfs2.provider.AbstractFileSystem;
/*     */ import org.apache.commons.vfs2.provider.zip.ZipFileSystem;
/*     */ import org.renjin.repackaged.guava.collect.Lists;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FastJarFileSystem
/*     */   extends AbstractFileSystem
/*     */   implements FileSystem
/*     */ {
/*  41 */   private static final Log log = LogFactory.getLog(ZipFileSystem.class);
/*     */   
/*     */   private final File file;
/*     */   
/*     */   private boolean exists;
/*     */   
/*     */   private JarFile jarFile;
/*     */   
/*     */   private NonExistentJarFileObject nonExistentJarFileObject;
/*     */   
/*     */   public FastJarFileSystem(FileName rootName, FileObject parentLayer, FileSystemOptions fileSystemOptions) throws FileSystemException {
/*  52 */     super(rootName, parentLayer, fileSystemOptions);
/*     */ 
/*     */     
/*  55 */     this.file = parentLayer.getFileSystem().replicateFile(parentLayer, Selectors.SELECT_SELF);
/*     */ 
/*     */     
/*  58 */     this.exists = this.file.exists();
/*  59 */     if (this.file.exists()) {
/*     */       try {
/*  61 */         this.jarFile = new JarFile(this.file);
/*  62 */       } catch (IOException e) {
/*  63 */         throw new FileSystemException(e);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void doCloseCommunicationLink() {
/*     */     try {
/*  74 */       if (this.jarFile != null)
/*     */       {
/*  76 */         this.jarFile.close();
/*  77 */         this.jarFile = null;
/*     */       }
/*     */     
/*  80 */     } catch (IOException e) {
/*     */ 
/*     */       
/*  83 */       VfsLog.warn(getLogger(), log, "vfs.provider.zip/close-zip-file.error :" + this.file, e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void addCapabilities(Collection<Capability> caps) {
/*  91 */     caps.addAll(FastJarFileProvider.capabilities);
/*     */   }
/*     */   
/*     */   private JarFile getJarFile() {
/*  95 */     return this.jarFile;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected FileObject createFile(AbstractFileName name) throws FileSystemException {
/* 102 */     if (!this.exists) {
/* 103 */       return (FileObject)new NonExistentJarFileObject(name, this);
/*     */     }
/* 105 */     String entryName = getRootName().getRelativeName((FileName)name);
/* 106 */     if (entryName.equals(".")) {
/* 107 */       return (FileObject)new FastJarRootFileObject(name, this);
/*     */     }
/*     */     
/* 110 */     JarEntry entry = getJarFile().getJarEntry(entryName + "/");
/* 111 */     if (entry != null) {
/* 112 */       return new FastJarFileObject(name, entry, this);
/*     */     }
/* 114 */     entry = getJarFile().getJarEntry(entryName);
/* 115 */     if (entry == null) {
/* 116 */       return (FileObject)new NonExistentJarFileObject(name, this);
/*     */     }
/* 118 */     return new FastJarFileObject(name, entry, this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getRootItems() {
/* 125 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public InputStream getInputStream(JarEntry entry) throws FileSystemException {
/*     */     try {
/* 131 */       return getJarFile().getInputStream(entry);
/* 132 */     } catch (IOException e) {
/* 133 */       throw new FileSystemException(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public String[] listChildren(String name) {
/* 138 */     JarFile jarFile = getJarFile();
/* 139 */     List<String> children = Lists.newArrayList();
/*     */     
/* 141 */     Enumeration<JarEntry> entries = jarFile.entries();
/* 142 */     while (entries.hasMoreElements()) {
/* 143 */       JarEntry entry = entries.nextElement();
/* 144 */       if (!entry.getName().equals(name) && entry.getName().startsWith(name)) {
/* 145 */         String childName = entry.getName().substring(name.length());
/* 146 */         int slash = childName.indexOf('/');
/* 147 */         if (slash == -1) {
/* 148 */           children.add(childName); continue;
/* 149 */         }  if (slash == childName.length() - 1) {
/* 150 */           children.add(childName.substring(0, childName.length() - 1));
/*     */         }
/*     */       } 
/*     */     } 
/* 154 */     return children.<String>toArray(new String[children.size()]);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/eval/vfs/FastJarFileSystem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */