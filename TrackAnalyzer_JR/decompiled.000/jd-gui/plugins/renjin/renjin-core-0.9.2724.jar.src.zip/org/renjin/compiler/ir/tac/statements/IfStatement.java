/*     */ package org.renjin.compiler.ir.tac.statements;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import org.renjin.compiler.codegen.EmitContext;
/*     */ import org.renjin.compiler.codegen.VariableStorage;
/*     */ import org.renjin.compiler.ir.tac.IRLabel;
/*     */ import org.renjin.compiler.ir.tac.expressions.CmpGE;
/*     */ import org.renjin.compiler.ir.tac.expressions.Expression;
/*     */ import org.renjin.compiler.ir.tac.expressions.LValue;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ import org.renjin.repackaged.asm.commons.InstructionAdapter;
/*     */ import org.renjin.sexp.Logical;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IfStatement
/*     */   implements Statement, BasicBlockEndingStatement
/*     */ {
/*     */   private Expression condition;
/*     */   private IRLabel trueTarget;
/*     */   private IRLabel falseTarget;
/*     */   private IRLabel naTarget;
/*     */   private Logical constantValue;
/*     */   
/*     */   public IfStatement(Expression condition, IRLabel trueTarget, IRLabel falseTarget, IRLabel naTarget) {
/*  47 */     this.condition = condition;
/*  48 */     this.trueTarget = trueTarget;
/*  49 */     this.falseTarget = falseTarget;
/*  50 */     this.naTarget = naTarget;
/*     */   }
/*     */   
/*     */   public IfStatement(Expression condition, IRLabel trueTarget, IRLabel falseTarget) {
/*  54 */     this.condition = condition;
/*  55 */     this.trueTarget = trueTarget;
/*  56 */     this.falseTarget = falseTarget;
/*  57 */     this.naTarget = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Expression getCondition() {
/*  62 */     return this.condition;
/*     */   }
/*     */ 
/*     */   
/*     */   public Expression getRHS() {
/*  67 */     return this.condition;
/*     */   }
/*     */   
/*     */   public IRLabel getTrueTarget() {
/*  71 */     return this.trueTarget;
/*     */   }
/*     */   
/*     */   public IRLabel getFalseTarget() {
/*  75 */     return this.falseTarget;
/*     */   }
/*     */   
/*     */   public IfStatement setTrueTarget(IRLabel label) {
/*  79 */     return new IfStatement(this.condition, label, this.falseTarget, this.naTarget);
/*     */   }
/*     */   
/*     */   public IfStatement setFalseTarget(IRLabel label) {
/*  83 */     return new IfStatement(this.condition, this.trueTarget, label, this.naTarget);
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterable<IRLabel> possibleTargets() {
/*  88 */     if (this.naTarget == null) {
/*  89 */       return Arrays.asList(new IRLabel[] { this.trueTarget, this.falseTarget });
/*     */     }
/*  91 */     return Arrays.asList(new IRLabel[] { this.trueTarget, this.falseTarget, this.naTarget });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRHS(Expression newRHS) {
/*  97 */     this.condition = newRHS;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 102 */     return "if " + this.condition + " => TRUE:" + this.trueTarget + ", FALSE:" + this.falseTarget + ", NA:" + ((this.naTarget == null) ? "ERROR" : (String)this.naTarget);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setChild(int childIndex, Expression child) {
/* 108 */     if (childIndex == 0) {
/* 109 */       this.condition = child;
/*     */     } else {
/* 111 */       throw new IllegalArgumentException();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int getChildCount() {
/* 117 */     return 1;
/*     */   }
/*     */ 
/*     */   
/*     */   public Expression childAt(int index) {
/* 122 */     if (index == 0) {
/* 123 */       return this.condition;
/*     */     }
/* 125 */     throw new IllegalArgumentException();
/*     */   }
/*     */ 
/*     */   
/*     */   public Logical getConstantValue() {
/* 130 */     return this.constantValue;
/*     */   }
/*     */   
/*     */   public void setConstantValue(Logical constantValue) {
/* 134 */     this.constantValue = constantValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public void accept(StatementVisitor visitor) {
/* 139 */     visitor.visitIf(this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int emit(EmitContext emitContext, InstructionAdapter mv) {
/* 145 */     if (this.constantValue == Logical.TRUE) {
/* 146 */       mv.visitJumpInsn(167, emitContext.getAsmLabel(this.trueTarget));
/*     */     }
/* 148 */     if (this.constantValue == Logical.FALSE) {
/* 149 */       mv.visitJumpInsn(167, emitContext.getAsmLabel(this.falseTarget));
/*     */     }
/*     */     
/* 152 */     int stackSizeIncrease = 0;
/*     */     
/* 154 */     if (this.condition instanceof CmpGE) {
/*     */       
/* 156 */       CmpGE cmp = (CmpGE)getCondition();
/*     */ 
/*     */       
/* 159 */       stackSizeIncrease = cmp.childAt(0).load(emitContext, mv) + cmp.childAt(1).load(emitContext, mv);
/*     */       
/* 161 */       mv.visitJumpInsn(161, emitContext.getAsmLabel(this.falseTarget));
/* 162 */       mv.visitJumpInsn(167, emitContext.getAsmLabel(this.trueTarget));
/*     */     }
/* 164 */     else if (this.condition instanceof LValue) {
/* 165 */       VariableStorage storage = emitContext.getVariableStorage((LValue)this.condition);
/* 166 */       if (storage.getType().equals(Type.BOOLEAN_TYPE) || storage
/* 167 */         .getType().equals(Type.INT_TYPE)) {
/* 168 */         mv.visitVarInsn(21, storage.getSlotIndex());
/* 169 */         mv.visitJumpInsn(153, emitContext.getAsmLabel(this.falseTarget));
/* 170 */         mv.visitJumpInsn(167, emitContext.getAsmLabel(this.trueTarget));
/*     */       } else {
/* 172 */         throw new UnsupportedOperationException("TODO: " + storage.getType());
/*     */       } 
/*     */     } 
/*     */     
/* 176 */     return stackSizeIncrease;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPure() {
/* 181 */     return this.condition.isPure();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/ir/tac/statements/IfStatement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */