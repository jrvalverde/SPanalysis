/*      */ package org.renjin.parser;
/*      */ 
/*      */ import java.util.Arrays;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class FDBigInteger
/*      */ {
/*   71 */   static final int[] SMALL_5_POW = new int[] { 1, 5, 25, 125, 625, 3125, 15625, 78125, 390625, 1953125, 9765625, 48828125, 244140625, 1220703125 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   88 */   static final long[] LONG_5_POW = new long[] { 1L, 5L, 25L, 125L, 625L, 3125L, 15625L, 78125L, 390625L, 1953125L, 9765625L, 48828125L, 244140625L, 1220703125L, 6103515625L, 30517578125L, 152587890625L, 762939453125L, 3814697265625L, 19073486328125L, 95367431640625L, 476837158203125L, 2384185791015625L, 11920928955078125L, 59604644775390625L, 298023223876953125L, 1490116119384765625L };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int MAX_FIVE_POW = 340;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  126 */   private static final FDBigInteger[] POW_5_CACHE = new FDBigInteger[340]; static {
/*  127 */     int i = 0;
/*  128 */     while (i < SMALL_5_POW.length) {
/*  129 */       FDBigInteger pow5 = new FDBigInteger(new int[] { SMALL_5_POW[i] }, 0);
/*  130 */       pow5.makeImmutable();
/*  131 */       POW_5_CACHE[i] = pow5;
/*  132 */       i++;
/*      */     } 
/*  134 */     FDBigInteger prev = POW_5_CACHE[i - 1];
/*  135 */     while (i < 340) {
/*  136 */       POW_5_CACHE[i] = prev = prev.mult(5);
/*  137 */       prev.makeImmutable();
/*  138 */       i++;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*  143 */   public static final FDBigInteger ZERO = new FDBigInteger(new int[0], 0); private static final long LONG_MASK = 4294967295L;
/*      */   private int[] data;
/*      */   
/*      */   static {
/*  147 */     ZERO.makeImmutable();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int offset;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int nWords;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isImmutable = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private FDBigInteger(int[] data, int offset) {
/*  190 */     this.data = data;
/*  191 */     this.offset = offset;
/*  192 */     this.nWords = data.length;
/*  193 */     trimLeadingZeros();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   FDBigInteger(long lValue, char[] digits, int kDigits, int nDigits) {
/*  212 */     int n = Math.max((nDigits + 8) / 9, 2);
/*  213 */     this.data = new int[n];
/*  214 */     this.data[0] = (int)lValue;
/*  215 */     this.data[1] = (int)(lValue >>> 32L);
/*  216 */     this.offset = 0;
/*  217 */     this.nWords = 2;
/*  218 */     int i = kDigits;
/*  219 */     int limit = nDigits - 5;
/*      */     
/*  221 */     while (i < limit) {
/*  222 */       int ilim = i + 5;
/*  223 */       int j = digits[i++] - 48;
/*  224 */       while (i < ilim) {
/*  225 */         j = 10 * j + digits[i++] - 48;
/*      */       }
/*  227 */       multAddMe(100000, j);
/*      */     } 
/*  229 */     int factor = 1;
/*  230 */     int v = 0;
/*  231 */     while (i < nDigits) {
/*  232 */       v = 10 * v + digits[i++] - 48;
/*  233 */       factor *= 10;
/*      */     } 
/*  235 */     if (factor != 1) {
/*  236 */       multAddMe(factor, v);
/*      */     }
/*  238 */     trimLeadingZeros();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static FDBigInteger valueOfPow52(int p5, int p2) {
/*  255 */     if (p5 != 0) {
/*  256 */       if (p2 == 0)
/*  257 */         return big5pow(p5); 
/*  258 */       if (p5 < SMALL_5_POW.length) {
/*  259 */         int pow5 = SMALL_5_POW[p5];
/*  260 */         int wordcount = p2 >> 5;
/*  261 */         int bitcount = p2 & 0x1F;
/*  262 */         if (bitcount == 0) {
/*  263 */           return new FDBigInteger(new int[] { pow5 }, wordcount);
/*      */         }
/*  265 */         return new FDBigInteger(new int[] { pow5 << bitcount, pow5 >>> 32 - bitcount }, wordcount);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  271 */       return big5pow(p5).leftShift(p2);
/*      */     } 
/*      */     
/*  274 */     return valueOfPow2(p2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static FDBigInteger valueOfMulPow52(long value, int p5, int p2) {
/*  293 */     assert p5 >= 0 : p5;
/*  294 */     assert p2 >= 0 : p2;
/*  295 */     int v0 = (int)value;
/*  296 */     int v1 = (int)(value >>> 32L);
/*  297 */     int wordcount = p2 >> 5;
/*  298 */     int bitcount = p2 & 0x1F;
/*  299 */     if (p5 != 0) {
/*  300 */       int[] r; if (p5 < SMALL_5_POW.length) {
/*  301 */         long l1 = SMALL_5_POW[p5] & 0xFFFFFFFFL;
/*  302 */         long carry = (v0 & 0xFFFFFFFFL) * l1;
/*  303 */         v0 = (int)carry;
/*  304 */         carry >>>= 32L;
/*  305 */         carry = (v1 & 0xFFFFFFFFL) * l1 + carry;
/*  306 */         v1 = (int)carry;
/*  307 */         int v2 = (int)(carry >>> 32L);
/*  308 */         if (bitcount == 0) {
/*  309 */           return new FDBigInteger(new int[] { v0, v1, v2 }, wordcount);
/*      */         }
/*  311 */         return new FDBigInteger(new int[] { v0 << bitcount, v1 << bitcount | v0 >>> 32 - bitcount, v2 << bitcount | v1 >>> 32 - bitcount, v2 >>> 32 - bitcount }, wordcount);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  319 */       FDBigInteger pow5 = big5pow(p5);
/*      */       
/*  321 */       if (v1 == 0) {
/*  322 */         r = new int[pow5.nWords + 1 + ((p2 != 0) ? 1 : 0)];
/*  323 */         mult(pow5.data, pow5.nWords, v0, r);
/*      */       } else {
/*  325 */         r = new int[pow5.nWords + 2 + ((p2 != 0) ? 1 : 0)];
/*  326 */         mult(pow5.data, pow5.nWords, v0, v1, r);
/*      */       } 
/*  328 */       return (new FDBigInteger(r, pow5.offset)).leftShift(p2);
/*      */     } 
/*  330 */     if (p2 != 0) {
/*  331 */       if (bitcount == 0) {
/*  332 */         return new FDBigInteger(new int[] { v0, v1 }, wordcount);
/*      */       }
/*  334 */       return new FDBigInteger(new int[] { v0 << bitcount, v1 << bitcount | v0 >>> 32 - bitcount, v1 >>> 32 - bitcount }, wordcount);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  341 */     return new FDBigInteger(new int[] { v0, v1 }, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static FDBigInteger valueOfPow2(int p2) {
/*  357 */     int wordcount = p2 >> 5;
/*  358 */     int bitcount = p2 & 0x1F;
/*  359 */     return new FDBigInteger(new int[] { 1 << bitcount }, wordcount);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void trimLeadingZeros() {
/*  374 */     int i = this.nWords;
/*  375 */     if (i > 0 && this.data[--i] == 0) {
/*      */       
/*  377 */       while (i > 0 && this.data[i - 1] == 0) {
/*  378 */         i--;
/*      */       }
/*  380 */       this.nWords = i;
/*  381 */       if (i == 0) {
/*  382 */         this.offset = 0;
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getNormalizationBias() {
/*  400 */     if (this.nWords == 0) {
/*  401 */       throw new IllegalArgumentException("Zero value cannot be normalized");
/*      */     }
/*  403 */     int zeros = Integer.numberOfLeadingZeros(this.data[this.nWords - 1]);
/*  404 */     return (zeros < 4) ? (28 + zeros) : (zeros - 4);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void leftShift(int[] src, int idx, int[] result, int bitcount, int anticount, int prev) {
/*  425 */     for (; idx > 0; idx--) {
/*  426 */       int i = prev << bitcount;
/*  427 */       prev = src[idx - 1];
/*  428 */       i |= prev >>> anticount;
/*  429 */       result[idx] = i;
/*      */     } 
/*  431 */     int v = prev << bitcount;
/*  432 */     result[0] = v;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public FDBigInteger leftShift(int shift) {
/*  462 */     if (shift == 0 || this.nWords == 0) {
/*  463 */       return this;
/*      */     }
/*  465 */     int wordcount = shift >> 5;
/*  466 */     int bitcount = shift & 0x1F;
/*  467 */     if (this.isImmutable) {
/*  468 */       int[] result; if (bitcount == 0) {
/*  469 */         return new FDBigInteger(Arrays.copyOf(this.data, this.nWords), this.offset + wordcount);
/*      */       }
/*  471 */       int anticount = 32 - bitcount;
/*  472 */       int idx = this.nWords - 1;
/*  473 */       int prev = this.data[idx];
/*  474 */       int hi = prev >>> anticount;
/*      */       
/*  476 */       if (hi != 0) {
/*  477 */         result = new int[this.nWords + 1];
/*  478 */         result[this.nWords] = hi;
/*      */       } else {
/*  480 */         result = new int[this.nWords];
/*      */       } 
/*  482 */       leftShift(this.data, idx, result, bitcount, anticount, prev);
/*  483 */       return new FDBigInteger(result, this.offset + wordcount);
/*      */     } 
/*      */     
/*  486 */     if (bitcount != 0) {
/*  487 */       int anticount = 32 - bitcount;
/*  488 */       if (this.data[0] << bitcount == 0) {
/*  489 */         int idx = 0;
/*  490 */         int prev = this.data[idx];
/*  491 */         for (; idx < this.nWords - 1; idx++) {
/*  492 */           int i = prev >>> anticount;
/*  493 */           prev = this.data[idx + 1];
/*  494 */           i |= prev << bitcount;
/*  495 */           this.data[idx] = i;
/*      */         } 
/*  497 */         int v = prev >>> anticount;
/*  498 */         this.data[idx] = v;
/*  499 */         if (v == 0) {
/*  500 */           this.nWords--;
/*      */         }
/*  502 */         this.offset++;
/*      */       } else {
/*  504 */         int idx = this.nWords - 1;
/*  505 */         int prev = this.data[idx];
/*  506 */         int hi = prev >>> anticount;
/*  507 */         int[] result = this.data;
/*  508 */         int[] src = this.data;
/*  509 */         if (hi != 0) {
/*  510 */           if (this.nWords == this.data.length) {
/*  511 */             this.data = result = new int[this.nWords + 1];
/*      */           }
/*  513 */           result[this.nWords++] = hi;
/*      */         } 
/*  515 */         leftShift(src, idx, result, bitcount, anticount, prev);
/*      */       } 
/*      */     } 
/*  518 */     this.offset += wordcount;
/*  519 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int size() {
/*  538 */     return this.nWords + this.offset;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int quoRemIteration(FDBigInteger S) throws IllegalArgumentException {
/*  568 */     assert !this.isImmutable : "cannot modify immutable value";
/*      */ 
/*      */ 
/*      */     
/*  572 */     int thSize = size();
/*  573 */     int sSize = S.size();
/*  574 */     if (thSize < sSize) {
/*      */ 
/*      */       
/*  577 */       int i = multAndCarryBy10(this.data, this.nWords, this.data);
/*  578 */       if (i != 0) {
/*  579 */         this.data[this.nWords++] = i;
/*      */       } else {
/*  581 */         trimLeadingZeros();
/*      */       } 
/*  583 */       return 0;
/*  584 */     }  if (thSize > sSize) {
/*  585 */       throw new IllegalArgumentException("disparate values");
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  590 */     long q = (this.data[this.nWords - 1] & 0xFFFFFFFFL) / (S.data[S.nWords - 1] & 0xFFFFFFFFL);
/*  591 */     long diff = multDiffMe(q, S);
/*  592 */     if (diff != 0L) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  600 */       long sum = 0L;
/*  601 */       int tStart = S.offset - this.offset;
/*      */       
/*  603 */       int[] sd = S.data;
/*  604 */       int[] td = this.data;
/*  605 */       while (sum == 0L) {
/*  606 */         for (int sIndex = 0, tIndex = tStart; tIndex < this.nWords; sIndex++, tIndex++) {
/*  607 */           sum += (td[tIndex] & 0xFFFFFFFFL) + (sd[sIndex] & 0xFFFFFFFFL);
/*  608 */           td[tIndex] = (int)sum;
/*  609 */           sum >>>= 32L;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  619 */         assert sum == 0L || sum == 1L : sum;
/*  620 */         q--;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  626 */     int p = multAndCarryBy10(this.data, this.nWords, this.data);
/*  627 */     assert p == 0 : p;
/*  628 */     trimLeadingZeros();
/*  629 */     return (int)q;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public FDBigInteger multBy10() {
/*  658 */     if (this.nWords == 0) {
/*  659 */       return this;
/*      */     }
/*  661 */     if (this.isImmutable) {
/*  662 */       int[] res = new int[this.nWords + 1];
/*  663 */       res[this.nWords] = multAndCarryBy10(this.data, this.nWords, res);
/*  664 */       return new FDBigInteger(res, this.offset);
/*      */     } 
/*  666 */     int p = multAndCarryBy10(this.data, this.nWords, this.data);
/*  667 */     if (p != 0) {
/*  668 */       if (this.nWords == this.data.length) {
/*  669 */         if (this.data[0] == 0) {
/*  670 */           System.arraycopy(this.data, 1, this.data, 0, --this.nWords);
/*  671 */           this.offset++;
/*      */         } else {
/*  673 */           this.data = Arrays.copyOf(this.data, this.data.length + 1);
/*      */         } 
/*      */       }
/*  676 */       this.data[this.nWords++] = p;
/*      */     } else {
/*  678 */       trimLeadingZeros();
/*      */     } 
/*  680 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public FDBigInteger multByPow52(int p5, int p2) {
/*  713 */     if (this.nWords == 0) {
/*  714 */       return this;
/*      */     }
/*  716 */     FDBigInteger res = this;
/*  717 */     if (p5 != 0) {
/*      */       
/*  719 */       int extraSize = (p2 != 0) ? 1 : 0;
/*  720 */       if (p5 < SMALL_5_POW.length) {
/*  721 */         int[] r = new int[this.nWords + 1 + extraSize];
/*  722 */         mult(this.data, this.nWords, SMALL_5_POW[p5], r);
/*  723 */         res = new FDBigInteger(r, this.offset);
/*      */       } else {
/*  725 */         FDBigInteger pow5 = big5pow(p5);
/*  726 */         int[] r = new int[this.nWords + pow5.size() + extraSize];
/*  727 */         mult(this.data, this.nWords, pow5.data, pow5.nWords, r);
/*  728 */         res = new FDBigInteger(r, this.offset + pow5.offset);
/*      */       } 
/*      */     } 
/*  731 */     return res.leftShift(p2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void mult(int[] s1, int s1Len, int[] s2, int s2Len, int[] dst) {
/*  750 */     for (int i = 0; i < s1Len; i++) {
/*  751 */       long v = s1[i] & 0xFFFFFFFFL;
/*  752 */       long p = 0L;
/*  753 */       for (int j = 0; j < s2Len; j++) {
/*  754 */         p += (dst[i + j] & 0xFFFFFFFFL) + v * (s2[j] & 0xFFFFFFFFL);
/*  755 */         dst[i + j] = (int)p;
/*  756 */         p >>>= 32L;
/*      */       } 
/*  758 */       dst[i + s2Len] = (int)p;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public FDBigInteger leftInplaceSub(FDBigInteger subtrahend) {
/*      */     FDBigInteger minuend;
/*  786 */     assert size() >= subtrahend.size() : "result should be positive";
/*      */     
/*  788 */     if (this.isImmutable) {
/*  789 */       minuend = new FDBigInteger((int[])this.data.clone(), this.offset);
/*      */     } else {
/*  791 */       minuend = this;
/*      */     } 
/*  793 */     int offsetDiff = subtrahend.offset - minuend.offset;
/*  794 */     int[] sData = subtrahend.data;
/*  795 */     int[] mData = minuend.data;
/*  796 */     int subLen = subtrahend.nWords;
/*  797 */     int minLen = minuend.nWords;
/*  798 */     if (offsetDiff < 0) {
/*      */       
/*  800 */       int rLen = minLen - offsetDiff;
/*  801 */       if (rLen < mData.length) {
/*  802 */         System.arraycopy(mData, 0, mData, -offsetDiff, minLen);
/*  803 */         Arrays.fill(mData, 0, -offsetDiff, 0);
/*      */       } else {
/*  805 */         int[] r = new int[rLen];
/*  806 */         System.arraycopy(mData, 0, r, -offsetDiff, minLen);
/*  807 */         minuend.data = mData = r;
/*      */       } 
/*  809 */       minuend.offset = subtrahend.offset;
/*  810 */       minuend.nWords = minLen = rLen;
/*  811 */       offsetDiff = 0;
/*      */     } 
/*  813 */     long borrow = 0L;
/*  814 */     int mIndex = offsetDiff;
/*  815 */     for (int sIndex = 0; sIndex < subLen && mIndex < minLen; sIndex++, mIndex++) {
/*  816 */       long diff = (mData[mIndex] & 0xFFFFFFFFL) - (sData[sIndex] & 0xFFFFFFFFL) + borrow;
/*  817 */       mData[mIndex] = (int)diff;
/*  818 */       borrow = diff >> 32L;
/*      */     } 
/*  820 */     for (; borrow != 0L && mIndex < minLen; mIndex++) {
/*  821 */       long diff = (mData[mIndex] & 0xFFFFFFFFL) + borrow;
/*  822 */       mData[mIndex] = (int)diff;
/*  823 */       borrow = diff >> 32L;
/*      */     } 
/*  825 */     assert borrow == 0L : borrow;
/*      */     
/*  827 */     minuend.trimLeadingZeros();
/*  828 */     return minuend;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public FDBigInteger rightInplaceSub(FDBigInteger subtrahend) {
/*  855 */     assert size() >= subtrahend.size() : "result should be positive";
/*  856 */     FDBigInteger minuend = this;
/*  857 */     if (subtrahend.isImmutable) {
/*  858 */       subtrahend = new FDBigInteger((int[])subtrahend.data.clone(), subtrahend.offset);
/*      */     }
/*  860 */     int offsetDiff = minuend.offset - subtrahend.offset;
/*  861 */     int[] sData = subtrahend.data;
/*  862 */     int[] mData = minuend.data;
/*  863 */     int subLen = subtrahend.nWords;
/*  864 */     int minLen = minuend.nWords;
/*  865 */     if (offsetDiff < 0) {
/*  866 */       int rLen = minLen;
/*  867 */       if (rLen < sData.length) {
/*  868 */         System.arraycopy(sData, 0, sData, -offsetDiff, subLen);
/*  869 */         Arrays.fill(sData, 0, -offsetDiff, 0);
/*      */       } else {
/*  871 */         int[] r = new int[rLen];
/*  872 */         System.arraycopy(sData, 0, r, -offsetDiff, subLen);
/*  873 */         subtrahend.data = sData = r;
/*      */       } 
/*  875 */       subtrahend.offset = minuend.offset;
/*  876 */       subLen -= offsetDiff;
/*  877 */       offsetDiff = 0;
/*      */     } else {
/*  879 */       int rLen = minLen + offsetDiff;
/*  880 */       if (rLen >= sData.length) {
/*  881 */         subtrahend.data = sData = Arrays.copyOf(sData, rLen);
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  892 */     int sIndex = 0;
/*  893 */     long borrow = 0L;
/*  894 */     for (; sIndex < offsetDiff; sIndex++) {
/*  895 */       long diff = 0L - (sData[sIndex] & 0xFFFFFFFFL) + borrow;
/*  896 */       sData[sIndex] = (int)diff;
/*  897 */       borrow = diff >> 32L;
/*      */     } 
/*      */     
/*  900 */     for (int mIndex = 0; mIndex < minLen; sIndex++, mIndex++) {
/*      */       
/*  902 */       long diff = (mData[mIndex] & 0xFFFFFFFFL) - (sData[sIndex] & 0xFFFFFFFFL) + borrow;
/*  903 */       sData[sIndex] = (int)diff;
/*  904 */       borrow = diff >> 32L;
/*      */     } 
/*  906 */     assert borrow == 0L : borrow;
/*      */     
/*  908 */     subtrahend.nWords = sIndex;
/*  909 */     subtrahend.trimLeadingZeros();
/*  910 */     return subtrahend;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int checkZeroTail(int[] a, int from) {
/*  927 */     while (from > 0) {
/*  928 */       if (a[--from] != 0) {
/*  929 */         return 1;
/*      */       }
/*      */     } 
/*  932 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int cmp(FDBigInteger other) {
/*  952 */     int aSize = this.nWords + this.offset;
/*  953 */     int bSize = other.nWords + other.offset;
/*  954 */     if (aSize > bSize)
/*  955 */       return 1; 
/*  956 */     if (aSize < bSize) {
/*  957 */       return -1;
/*      */     }
/*  959 */     int aLen = this.nWords;
/*  960 */     int bLen = other.nWords;
/*  961 */     while (aLen > 0 && bLen > 0) {
/*  962 */       int a = this.data[--aLen];
/*  963 */       int b = other.data[--bLen];
/*  964 */       if (a != b) {
/*  965 */         return ((a & 0xFFFFFFFFL) < (b & 0xFFFFFFFFL)) ? -1 : 1;
/*      */       }
/*      */     } 
/*  968 */     if (aLen > 0) {
/*  969 */       return checkZeroTail(this.data, aLen);
/*      */     }
/*  971 */     if (bLen > 0) {
/*  972 */       return -checkZeroTail(other.data, bLen);
/*      */     }
/*  974 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int cmpPow52(int p5, int p2) {
/*  996 */     if (p5 == 0) {
/*  997 */       int wordcount = p2 >> 5;
/*  998 */       int bitcount = p2 & 0x1F;
/*  999 */       int size = this.nWords + this.offset;
/* 1000 */       if (size > wordcount + 1)
/* 1001 */         return 1; 
/* 1002 */       if (size < wordcount + 1) {
/* 1003 */         return -1;
/*      */       }
/* 1005 */       int a = this.data[this.nWords - 1];
/* 1006 */       int b = 1 << bitcount;
/* 1007 */       if (a != b) {
/* 1008 */         return ((a & 0xFFFFFFFFL) < (b & 0xFFFFFFFFL)) ? -1 : 1;
/*      */       }
/* 1010 */       return checkZeroTail(this.data, this.nWords - 1);
/*      */     } 
/* 1012 */     return cmp(big5pow(p5).leftShift(p2));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int addAndCmp(FDBigInteger x, FDBigInteger y) {
/*      */     FDBigInteger big, small;
/* 1033 */     int bSize, sSize, xSize = x.size();
/* 1034 */     int ySize = y.size();
/*      */ 
/*      */     
/* 1037 */     if (xSize >= ySize) {
/* 1038 */       big = x;
/* 1039 */       small = y;
/* 1040 */       bSize = xSize;
/* 1041 */       sSize = ySize;
/*      */     } else {
/* 1043 */       big = y;
/* 1044 */       small = x;
/* 1045 */       bSize = ySize;
/* 1046 */       sSize = xSize;
/*      */     } 
/* 1048 */     int thSize = size();
/* 1049 */     if (bSize == 0) {
/* 1050 */       return (thSize == 0) ? 0 : 1;
/*      */     }
/* 1052 */     if (sSize == 0) {
/* 1053 */       return cmp(big);
/*      */     }
/* 1055 */     if (bSize > thSize) {
/* 1056 */       return -1;
/*      */     }
/* 1058 */     if (bSize + 1 < thSize) {
/* 1059 */       return 1;
/*      */     }
/* 1061 */     long top = big.data[big.nWords - 1] & 0xFFFFFFFFL;
/* 1062 */     if (sSize == bSize) {
/* 1063 */       top += small.data[small.nWords - 1] & 0xFFFFFFFFL;
/*      */     }
/* 1065 */     if (top >>> 32L == 0L) {
/* 1066 */       if (top + 1L >>> 32L == 0L) {
/*      */         
/* 1068 */         if (bSize < thSize) {
/* 1069 */           return 1;
/*      */         }
/*      */         
/* 1072 */         long v = this.data[this.nWords - 1] & 0xFFFFFFFFL;
/* 1073 */         if (v < top) {
/* 1074 */           return -1;
/*      */         }
/* 1076 */         if (v > top + 1L) {
/* 1077 */           return 1;
/*      */         }
/*      */       } 
/*      */     } else {
/* 1081 */       if (bSize + 1 > thSize) {
/* 1082 */         return -1;
/*      */       }
/*      */       
/* 1085 */       top >>>= 32L;
/* 1086 */       long v = this.data[this.nWords - 1] & 0xFFFFFFFFL;
/* 1087 */       if (v < top) {
/* 1088 */         return -1;
/*      */       }
/* 1090 */       if (v > top + 1L) {
/* 1091 */         return 1;
/*      */       }
/*      */     } 
/* 1094 */     return cmp(big.add(small));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void makeImmutable() {
/* 1105 */     this.isImmutable = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private FDBigInteger mult(int i) {
/* 1126 */     if (this.nWords == 0) {
/* 1127 */       return this;
/*      */     }
/* 1129 */     int[] r = new int[this.nWords + 1];
/* 1130 */     mult(this.data, this.nWords, i, r);
/* 1131 */     return new FDBigInteger(r, this.offset);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private FDBigInteger mult(FDBigInteger other) {
/* 1158 */     if (this.nWords == 0) {
/* 1159 */       return this;
/*      */     }
/* 1161 */     if (size() == 1) {
/* 1162 */       return other.mult(this.data[0]);
/*      */     }
/* 1164 */     if (other.nWords == 0) {
/* 1165 */       return other;
/*      */     }
/* 1167 */     if (other.size() == 1) {
/* 1168 */       return mult(other.data[0]);
/*      */     }
/* 1170 */     int[] r = new int[this.nWords + other.nWords];
/* 1171 */     mult(this.data, this.nWords, other.data, other.nWords, r);
/* 1172 */     return new FDBigInteger(r, this.offset + other.offset);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private FDBigInteger add(FDBigInteger other) {
/*      */     FDBigInteger big, small;
/* 1188 */     int bigLen, smallLen, tSize = size();
/* 1189 */     int oSize = other.size();
/* 1190 */     if (tSize >= oSize) {
/* 1191 */       big = this;
/* 1192 */       bigLen = tSize;
/* 1193 */       small = other;
/* 1194 */       smallLen = oSize;
/*      */     } else {
/* 1196 */       big = other;
/* 1197 */       bigLen = oSize;
/* 1198 */       small = this;
/* 1199 */       smallLen = tSize;
/*      */     } 
/* 1201 */     int[] r = new int[bigLen + 1];
/* 1202 */     int i = 0;
/* 1203 */     long carry = 0L;
/* 1204 */     for (; i < smallLen; i++) {
/* 1205 */       carry += ((i < big.offset) ? 0L : (big.data[i - big.offset] & 0xFFFFFFFFL)) + ((i < small.offset) ? 0L : (small.data[i - small.offset] & 0xFFFFFFFFL));
/*      */       
/* 1207 */       r[i] = (int)carry;
/* 1208 */       carry >>= 32L;
/*      */     } 
/* 1210 */     for (; i < bigLen; i++) {
/* 1211 */       carry += (i < big.offset) ? 0L : (big.data[i - big.offset] & 0xFFFFFFFFL);
/* 1212 */       r[i] = (int)carry;
/* 1213 */       carry >>= 32L;
/*      */     } 
/* 1215 */     r[bigLen] = (int)carry;
/* 1216 */     return new FDBigInteger(r, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void multAddMe(int iv, int addend) {
/* 1238 */     long v = iv & 0xFFFFFFFFL;
/*      */     
/* 1240 */     long p = v * (this.data[0] & 0xFFFFFFFFL) + (addend & 0xFFFFFFFFL);
/* 1241 */     this.data[0] = (int)p;
/* 1242 */     p >>>= 32L;
/* 1243 */     for (int i = 1; i < this.nWords; i++) {
/* 1244 */       p += v * (this.data[i] & 0xFFFFFFFFL);
/* 1245 */       this.data[i] = (int)p;
/* 1246 */       p >>>= 32L;
/*      */     } 
/* 1248 */     if (p != 0L) {
/* 1249 */       this.data[this.nWords++] = (int)p;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private long multDiffMe(long q, FDBigInteger S) {
/* 1294 */     long diff = 0L;
/* 1295 */     if (q != 0L) {
/* 1296 */       int deltaSize = S.offset - this.offset;
/* 1297 */       if (deltaSize >= 0) {
/* 1298 */         int[] sd = S.data;
/* 1299 */         int[] td = this.data;
/* 1300 */         for (int sIndex = 0, tIndex = deltaSize; sIndex < S.nWords; sIndex++, tIndex++) {
/* 1301 */           diff += (td[tIndex] & 0xFFFFFFFFL) - q * (sd[sIndex] & 0xFFFFFFFFL);
/* 1302 */           td[tIndex] = (int)diff;
/* 1303 */           diff >>= 32L;
/*      */         } 
/*      */       } else {
/* 1306 */         deltaSize = -deltaSize;
/* 1307 */         int[] rd = new int[this.nWords + deltaSize];
/* 1308 */         int sIndex = 0;
/* 1309 */         int rIndex = 0;
/* 1310 */         int[] sd = S.data;
/* 1311 */         for (; rIndex < deltaSize && sIndex < S.nWords; sIndex++, rIndex++) {
/* 1312 */           diff -= q * (sd[sIndex] & 0xFFFFFFFFL);
/* 1313 */           rd[rIndex] = (int)diff;
/* 1314 */           diff >>= 32L;
/*      */         } 
/* 1316 */         int tIndex = 0;
/* 1317 */         int[] td = this.data;
/* 1318 */         for (; sIndex < S.nWords; sIndex++, tIndex++, rIndex++) {
/* 1319 */           diff += (td[tIndex] & 0xFFFFFFFFL) - q * (sd[sIndex] & 0xFFFFFFFFL);
/* 1320 */           rd[rIndex] = (int)diff;
/* 1321 */           diff >>= 32L;
/*      */         } 
/* 1323 */         this.nWords += deltaSize;
/* 1324 */         this.offset -= deltaSize;
/* 1325 */         this.data = rd;
/*      */       } 
/*      */     } 
/* 1328 */     return diff;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int multAndCarryBy10(int[] src, int srcLen, int[] dst) {
/* 1348 */     long carry = 0L;
/* 1349 */     for (int i = 0; i < srcLen; i++) {
/* 1350 */       long product = (src[i] & 0xFFFFFFFFL) * 10L + carry;
/* 1351 */       dst[i] = (int)product;
/* 1352 */       carry = product >>> 32L;
/*      */     } 
/* 1354 */     return (int)carry;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void mult(int[] src, int srcLen, int value, int[] dst) {
/* 1372 */     long val = value & 0xFFFFFFFFL;
/* 1373 */     long carry = 0L;
/* 1374 */     for (int i = 0; i < srcLen; i++) {
/* 1375 */       long product = (src[i] & 0xFFFFFFFFL) * val + carry;
/* 1376 */       dst[i] = (int)product;
/* 1377 */       carry = product >>> 32L;
/*      */     } 
/* 1379 */     dst[srcLen] = (int)carry;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void mult(int[] src, int srcLen, int v0, int v1, int[] dst) {
/* 1399 */     long v = v0 & 0xFFFFFFFFL;
/* 1400 */     long carry = 0L; int j;
/* 1401 */     for (j = 0; j < srcLen; j++) {
/* 1402 */       long product = v * (src[j] & 0xFFFFFFFFL) + carry;
/* 1403 */       dst[j] = (int)product;
/* 1404 */       carry = product >>> 32L;
/*      */     } 
/* 1406 */     dst[srcLen] = (int)carry;
/* 1407 */     v = v1 & 0xFFFFFFFFL;
/* 1408 */     carry = 0L;
/* 1409 */     for (j = 0; j < srcLen; j++) {
/* 1410 */       long product = (dst[j + 1] & 0xFFFFFFFFL) + v * (src[j] & 0xFFFFFFFFL) + carry;
/* 1411 */       dst[j + 1] = (int)product;
/* 1412 */       carry = product >>> 32L;
/*      */     } 
/* 1414 */     dst[srcLen + 1] = (int)carry;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static FDBigInteger big5pow(int p) {
/* 1425 */     assert p >= 0 : p;
/* 1426 */     if (p < 340) {
/* 1427 */       return POW_5_CACHE[p];
/*      */     }
/* 1429 */     return big5powRec(p);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static FDBigInteger big5powRec(int p) {
/* 1440 */     if (p < 340) {
/* 1441 */       return POW_5_CACHE[p];
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1450 */     int q = p >> 1;
/* 1451 */     int r = p - q;
/* 1452 */     FDBigInteger bigq = big5powRec(q);
/* 1453 */     if (r < SMALL_5_POW.length) {
/* 1454 */       return bigq.mult(SMALL_5_POW[r]);
/*      */     }
/* 1456 */     return bigq.mult(big5powRec(r));
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/parser/FDBigInteger.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */