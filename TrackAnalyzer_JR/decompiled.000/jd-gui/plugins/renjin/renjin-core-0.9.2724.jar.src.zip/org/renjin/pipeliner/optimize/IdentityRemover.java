/*     */ package org.renjin.pipeliner.optimize;
/*     */ 
/*     */ import org.renjin.pipeliner.DeferredGraph;
/*     */ import org.renjin.pipeliner.node.DeferredNode;
/*     */ import org.renjin.pipeliner.node.FunctionNode;
/*     */ import org.renjin.primitives.vector.DeferredComputation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IdentityRemover
/*     */   implements Optimizer
/*     */ {
/*     */   private static boolean DEBUG = false;
/*     */   
/*     */   public boolean optimize(DeferredGraph graph, FunctionNode node) {
/*  34 */     DeferredNode replacementValue = trySimplify(node);
/*  35 */     if (replacementValue != null) {
/*  36 */       graph.replaceNode((DeferredNode)node, replacementValue);
/*  37 */       return true;
/*     */     } 
/*  39 */     return false;
/*     */   }
/*     */   
/*     */   private DeferredNode trySimplify(FunctionNode node) {
/*  43 */     String op = node.getComputationName();
/*     */ 
/*     */     
/*  46 */     if (node.getOperands().size() == 2) {
/*     */       
/*  48 */       if ("^".equals(op) && 
/*  49 */         node.getOperand(1).hasValue(1.0D)) {
/*  50 */         if (DEBUG) {
/*  51 */           System.out.println("Killed ^1");
/*     */         }
/*  53 */         return node.getOperand(0);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/*  58 */       if ("*".equals(op)) {
/*  59 */         if (node.getOperand(0).hasValue(1.0D)) {
/*  60 */           if (DEBUG) {
/*  61 */             System.out.println("Killed 1*x");
/*     */           }
/*  63 */           return node.getOperand(1);
/*     */         } 
/*     */         
/*  66 */         if (node.getOperand(1).hasValue(1.0D)) {
/*  67 */           if (DEBUG) {
/*  68 */             System.out.println("Killed x*1");
/*     */           }
/*  70 */           return node.getOperand(0);
/*     */         } 
/*  72 */         if (node.getOperand(0).hasValue(0.0D) || node.getOperand(1).hasValue(0.0D));
/*     */       } 
/*     */ 
/*     */       
/*  76 */       if ("+".equals(op) || "-".equals(op)) {
/*  77 */         if (node.getOperand(0).hasValue(0.0D)) {
/*  78 */           if (DEBUG) {
/*  79 */             System.out.println("Killed 0+-x");
/*     */           }
/*  81 */           return node.getOperand(1);
/*     */         } 
/*  83 */         if (node.getOperand(1).hasValue(0.0D)) {
/*  84 */           if (DEBUG) {
/*  85 */             System.out.println("Killed x+-0");
/*     */           }
/*  87 */           return node.getOperand(0);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/*  92 */     if (("mean".equals(op) || "min".equals(op) || "max".equals(op)) && 
/*  93 */       node.getOperand(0) instanceof DeferredComputation && ((DeferredComputation)node
/*  94 */       .getOperand(0).getVector()).getComputationName().equals("rep")) {
/*  95 */       if (DEBUG) {
/*  96 */         System.out.println("Killed mean/max/min(rep(x))");
/*     */       }
/*  98 */       return node.getOperand(0).getOperand(0);
/*     */     } 
/*     */ 
/*     */     
/* 102 */     return null;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/pipeliner/optimize/IdentityRemover.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */