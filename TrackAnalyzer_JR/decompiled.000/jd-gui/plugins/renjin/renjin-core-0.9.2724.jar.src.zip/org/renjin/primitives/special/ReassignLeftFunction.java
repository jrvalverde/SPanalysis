/*    */ package org.renjin.primitives.special;
/*    */ 
/*    */ import org.renjin.eval.Context;
/*    */ import org.renjin.sexp.Environment;
/*    */ import org.renjin.sexp.SEXP;
/*    */ import org.renjin.sexp.Symbol;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReassignLeftFunction
/*    */   extends AssignLeftFunction
/*    */ {
/*    */   public ReassignLeftFunction() {
/* 29 */     super("<<-");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void assignResult(Context context, Environment rho, Symbol lhs, SEXP rhs) {
/* 35 */     for (Environment env : rho.parents()) {
/* 36 */       if (env.hasVariable(lhs)) {
/* 37 */         env.setVariable(context, lhs, rhs);
/*    */         
/*    */         return;
/*    */       } 
/*    */     } 
/*    */     
/* 43 */     context.getGlobalEnvironment().setVariable(context, lhs, rhs);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/special/ReassignLeftFunction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */