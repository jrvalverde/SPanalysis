/*    */ package org.renjin.compiler.cfg;
/*    */ 
/*    */ import org.renjin.compiler.ir.tac.expressions.Variable;
/*    */ import org.renjin.compiler.ir.tac.statements.Assignment;
/*    */ import org.renjin.compiler.ir.tac.statements.Statement;
/*    */ import org.renjin.repackaged.guava.base.Predicate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CfgPredicates
/*    */ {
/*    */   public static Predicate<BasicBlock> containsAssignmentTo(Variable variable) {
/* 31 */     return input -> {
/*    */         for (Statement stmt : input.getStatements()) {
/*    */           if (stmt instanceof Assignment) {
/*    */             Assignment assignment = (Assignment)stmt;
/*    */             if (assignment.getLHS().equals(variable)) {
/*    */               return true;
/*    */             }
/*    */           } 
/*    */         } 
/*    */         return false;
/*    */       };
/*    */   }
/*    */   
/*    */   public static Predicate<Statement> isPhiAssignment() {
/* 45 */     return input -> {
/*    */         if (!(input instanceof Assignment))
/*    */           return false; 
/*    */         Assignment assignment = (Assignment)input;
/*    */         return assignment.getRHS() instanceof org.renjin.compiler.ir.ssa.PhiFunction;
/*    */       };
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/cfg/CfgPredicates.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */