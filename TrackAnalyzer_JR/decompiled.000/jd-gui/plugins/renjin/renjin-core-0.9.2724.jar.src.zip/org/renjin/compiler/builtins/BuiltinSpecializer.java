package org.renjin.compiler.builtins;

public interface BuiltinSpecializer extends Specializer {
  String getName();
  
  String getGroup();
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/builtins/BuiltinSpecializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */