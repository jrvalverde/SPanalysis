/*    */ package org.renjin.primitives.combine;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.renjin.eval.Context;
/*    */ import org.renjin.sexp.AtomicVector;
/*    */ import org.renjin.sexp.Null;
/*    */ import org.renjin.sexp.SEXP;
/*    */ import org.renjin.sexp.Vector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RowBindFunction
/*    */   extends AbstractBindFunction
/*    */ {
/*    */   public RowBindFunction() {
/* 35 */     super("rbind", MatrixDim.ROW);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected SEXP apply(Context context, List<BindArgument> bindArguments) {
/* 43 */     int columns = computeColumnCount(context, bindArguments);
/*    */ 
/*    */ 
/*    */     
/* 47 */     if (columns > 0) {
/* 48 */       bindArguments = excludeZeroLengthVectors(bindArguments);
/*    */     }
/*    */     
/* 51 */     int rows = countRowOrCols(bindArguments, MatrixDim.ROW);
/*    */ 
/*    */     
/* 54 */     Vector.Builder vectorBuilder = builderForCommonType(bindArguments);
/* 55 */     Matrix2dBuilder builder = new Matrix2dBuilder(vectorBuilder, rows, columns);
/* 56 */     for (int j = 0; j != columns; j++) {
/* 57 */       for (BindArgument argument : bindArguments) {
/* 58 */         for (int i = 0; i != argument.getRows(); i++) {
/* 59 */           builder.addFrom(argument, i, j);
/*    */         }
/*    */       } 
/*    */     } 
/*    */     
/* 64 */     AtomicVector rowNames = combineDimNames(bindArguments, MatrixDim.ROW);
/* 65 */     AtomicVector colNames = dimNamesFromLongest(bindArguments, MatrixDim.COL, columns);
/*    */     
/* 67 */     if (allZeroLengthVectors(bindArguments)) {
/*    */ 
/*    */       
/* 70 */       builder.setDimNames((AtomicVector)Null.INSTANCE, (AtomicVector)Null.INSTANCE);
/*    */     }
/* 72 */     else if (rowNames != Null.INSTANCE || colNames != Null.INSTANCE) {
/* 73 */       builder.setDimNames(rowNames, colNames);
/*    */     } 
/*    */     
/* 76 */     return (SEXP)builder.build();
/*    */   }
/*    */   
/*    */   private int computeColumnCount(Context context, List<BindArgument> bindArguments) {
/* 80 */     int columns = findCommonMatrixDimLength(bindArguments, MatrixDim.COL);
/*    */ 
/*    */ 
/*    */     
/* 84 */     if (columns == -1) {
/* 85 */       columns = findMaxLength(bindArguments);
/*    */     }
/*    */ 
/*    */     
/* 89 */     warnIfVectorLengthsAreNotMultiple(context, bindArguments, columns);
/* 90 */     return columns;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/combine/RowBindFunction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */