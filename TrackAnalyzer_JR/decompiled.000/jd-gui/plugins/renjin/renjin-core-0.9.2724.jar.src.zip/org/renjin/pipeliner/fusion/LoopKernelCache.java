/*    */ package org.renjin.pipeliner.fusion;
/*    */ 
/*    */ import java.util.concurrent.ExecutorService;
/*    */ import java.util.concurrent.Future;
/*    */ import org.renjin.pipeliner.fusion.kernel.CompiledKernel;
/*    */ import org.renjin.pipeliner.fusion.kernel.LoopKernel;
/*    */ import org.renjin.pipeliner.fusion.node.LoopNode;
/*    */ import org.renjin.repackaged.guava.cache.Cache;
/*    */ import org.renjin.repackaged.guava.cache.CacheBuilder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LoopKernelCache
/*    */ {
/*    */   private final Cache<String, Future<CompiledKernel>> cache;
/*    */   private ExecutorService executorService;
/*    */   
/*    */   public LoopKernelCache(ExecutorService executorService) {
/* 40 */     this.executorService = executorService;
/*    */     
/* 42 */     this
/*    */ 
/*    */       
/* 45 */       .cache = CacheBuilder.newBuilder().softValues().maximumSize(100L).build();
/*    */   }
/*    */ 
/*    */   
/*    */   public Future<CompiledKernel> get(LoopKernel kernel, LoopNode[] kernelOperands) {
/* 50 */     String key = kernelKey(kernel, kernelOperands);
/*    */     
/* 52 */     Future<CompiledKernel> compiledKernel = (Future<CompiledKernel>)this.cache.getIfPresent(key);
/*    */     
/* 54 */     if (compiledKernel == null) {
/*    */       
/* 56 */       LoopKernelCompiler compiler = new LoopKernelCompiler(kernel, kernelOperands);
/* 57 */       compiledKernel = this.executorService.submit(compiler);
/*    */       
/* 59 */       this.cache.put(key, compiledKernel);
/*    */     } 
/*    */     
/* 62 */     return compiledKernel;
/*    */   }
/*    */   
/*    */   private String kernelKey(LoopKernel kernel, LoopNode[] kernelOperands) {
/* 66 */     StringBuilder key = new StringBuilder();
/* 67 */     kernel.appendToKey(key);
/* 68 */     key.append(':');
/* 69 */     for (LoopNode kernelOperand : kernelOperands) {
/* 70 */       kernelOperand.appendToKey(key);
/*    */     }
/* 72 */     return key.toString();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/pipeliner/fusion/LoopKernelCache.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */