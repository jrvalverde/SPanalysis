/*    */ package org.renjin.eval;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.renjin.sexp.StringVector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SessionController
/*    */ {
/*    */   public enum SaveMode
/*    */   {
/* 36 */     NO,
/* 37 */     YES,
/* 38 */     ASK,
/* 39 */     DEFAULT;
/*    */   }
/*    */ 
/*    */   
/*    */   public void quit(Context context, SaveMode saveMode, int exitCode, boolean runLast) {}
/*    */ 
/*    */   
/*    */   public boolean isInteractive() {
/* 47 */     return false;
/*    */   }
/*    */   
/*    */   public boolean isCommandLineEditingAvailable() {
/* 51 */     return isInteractive();
/*    */   }
/*    */   
/*    */   public int menu(StringVector choices) throws IOException {
/* 55 */     throw new EvalException("menu() is not available", new Object[0]);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isTerminal() {
/* 64 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public String readLine(String prompt) {
/* 69 */     return "";
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/eval/SessionController.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */