/*    */ package org.renjin.invoke.reflection.converters;
/*    */ 
/*    */ import org.renjin.sexp.AtomicVector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FloatArrayConverter
/*    */   extends DoubleArrayConverter
/*    */ {
/* 25 */   public static final FloatArrayConverter FLOAT_ARRAY = new FloatArrayConverter();
/*    */   
/*    */   private FloatArrayConverter() {
/* 28 */     super(float.class);
/*    */   }
/*    */ 
/*    */   
/*    */   protected Object convertToJavaArray(AtomicVector vector) {
/* 33 */     float[] array = new float[vector.length()];
/* 34 */     for (int i = 0; i < array.length; i++) {
/* 35 */       array[i] = (float)vector.getElementAsDouble(i);
/*    */     }
/* 37 */     return array;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/reflection/converters/FloatArrayConverter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */