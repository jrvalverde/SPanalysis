/*    */ package org.renjin.primitives.matrix;
/*    */ 
/*    */ import org.renjin.primitives.vector.DeferredComputation;
/*    */ import org.renjin.sexp.AttributeMap;
/*    */ import org.renjin.sexp.DoubleVector;
/*    */ import org.renjin.sexp.IntArrayVector;
/*    */ import org.renjin.sexp.IntVector;
/*    */ import org.renjin.sexp.SEXP;
/*    */ import org.renjin.sexp.Symbols;
/*    */ import org.renjin.sexp.Vector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TransposingMatrix
/*    */   extends DoubleVector
/*    */   implements DeferredComputation
/*    */ {
/*    */   public static final int LENGTH_THRESHOLD = 0;
/*    */   private final Vector source;
/*    */   private int[] sourceDim;
/*    */   private int sourceRowCount;
/*    */   private int sourceColCount;
/*    */   
/*    */   public TransposingMatrix(Vector source, AttributeMap attributes) {
/* 35 */     super(attributes);
/* 36 */     this.source = source;
/* 37 */     this.sourceDim = ((IntVector)source.getAttribute(Symbols.DIM)).toIntArray();
/* 38 */     this.sourceRowCount = this.sourceDim[0];
/* 39 */     this.sourceColCount = this.sourceDim[1];
/*    */   }
/*    */ 
/*    */   
/*    */   protected SEXP cloneWithNewAttributes(AttributeMap attributes) {
/* 44 */     return (SEXP)new TransposingMatrix(this.source, attributes);
/*    */   }
/*    */ 
/*    */   
/*    */   public double getElementAsDouble(int vectorIndex) {
/* 49 */     int row = vectorIndex % this.sourceColCount;
/* 50 */     vectorIndex = (vectorIndex - row) / this.sourceColCount;
/* 51 */     int col = vectorIndex % this.sourceRowCount;
/*    */     
/* 53 */     return this.source.getElementAsDouble(col + row * this.sourceRowCount);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isConstantAccessTime() {
/* 58 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isDeferred() {
/* 63 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public int length() {
/* 68 */     return this.source.length();
/*    */   }
/*    */ 
/*    */   
/*    */   public Vector[] getOperands() {
/* 73 */     return new Vector[] { this.source, (Vector)new IntArrayVector(new int[] { this.sourceRowCount }) };
/*    */   }
/*    */ 
/*    */   
/*    */   public String getComputationName() {
/* 78 */     return "t";
/*    */   }
/*    */ 
/*    */   
/*    */   public int getComputationDepth() {
/* 83 */     return this.source.getComputationDepth() + 1;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/matrix/TransposingMatrix.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */