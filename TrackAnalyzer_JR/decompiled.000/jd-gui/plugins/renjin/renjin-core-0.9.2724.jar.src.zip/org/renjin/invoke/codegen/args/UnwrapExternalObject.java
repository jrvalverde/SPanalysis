/*    */ package org.renjin.invoke.codegen.args;
/*    */ 
/*    */ import com.sun.codemodel.JClass;
/*    */ import com.sun.codemodel.JCodeModel;
/*    */ import com.sun.codemodel.JExpr;
/*    */ import com.sun.codemodel.JExpression;
/*    */ import com.sun.codemodel.JType;
/*    */ import com.sun.codemodel.JVar;
/*    */ import org.renjin.invoke.codegen.ApplyMethodContext;
/*    */ import org.renjin.invoke.model.JvmMethod;
/*    */ import org.renjin.sexp.ExternalPtr;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UnwrapExternalObject
/*    */   extends ArgConverterStrategy
/*    */ {
/*    */   public UnwrapExternalObject(JvmMethod.Argument formal) {
/* 36 */     super(formal);
/*    */   }
/*    */   
/*    */   public static boolean accept(JvmMethod.Argument formal) {
/* 40 */     return !formal.getClazz().isPrimitive();
/*    */   }
/*    */ 
/*    */   
/*    */   public JExpression getTestExpr(JCodeModel codeModel, JVar sexp) {
/* 45 */     JClass externalClass = codeModel.ref(ExternalPtr.class);
/* 46 */     return sexp._instanceof((JType)externalClass)
/* 47 */       .cand(JExpr.invoke((JExpression)JExpr.cast((JType)externalClass, (JExpression)sexp), "getInstance")._instanceof((JType)codeModel.ref(this.formal.getClazz())));
/*    */   }
/*    */ 
/*    */   
/*    */   public JExpression convertArgument(ApplyMethodContext method, JExpression sexp) {
/* 52 */     JClass externalClass = method.classRef(ExternalPtr.class);
/* 53 */     JClass formalClass = method.classRef(this.formal.getClazz());
/* 54 */     return (JExpression)JExpr.cast((JType)formalClass, (JExpression)JExpr.invoke((JExpression)JExpr.cast((JType)externalClass, sexp), "getInstance"));
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/codegen/args/UnwrapExternalObject.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */