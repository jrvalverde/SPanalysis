/*    */ package org.renjin.invoke.codegen;
/*    */ 
/*    */ import com.sun.codemodel.JBlock;
/*    */ import com.sun.codemodel.JCodeModel;
/*    */ import com.sun.codemodel.JDefinedClass;
/*    */ import com.sun.codemodel.JExpr;
/*    */ import com.sun.codemodel.JExpression;
/*    */ import com.sun.codemodel.JInvocation;
/*    */ import com.sun.codemodel.JType;
/*    */ import com.sun.codemodel.JVar;
/*    */ import java.util.List;
/*    */ import org.renjin.eval.EvalException;
/*    */ import org.renjin.invoke.model.JvmMethod;
/*    */ import org.renjin.invoke.model.PrimitiveModel;
/*    */ import org.renjin.repackaged.guava.collect.Lists;
/*    */ import org.renjin.sexp.SEXP;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FixedArityApplyBuilder
/*    */   extends ApplyMethodBuilder
/*    */ {
/*    */   public FixedArityApplyBuilder(JCodeModel codeModel, JDefinedClass invoker, PrimitiveModel primitive) {
/* 40 */     super(codeModel, invoker, primitive);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void apply(JBlock parent) {
/* 46 */     List<JExpression> arguments = Lists.newArrayList();
/*    */     
/* 48 */     for (int i = 0; i < this.primitive.maxPositionalArgs(); i++) {
/*    */       
/* 50 */       List<JvmMethod> overloads = this.primitive.overloadsWithPosArgCountOf(i);
/* 51 */       if (!overloads.isEmpty())
/*    */       {
/*    */ 
/*    */         
/* 55 */         arityMatches(parent._if(lastArgument())._then(), arguments);
/*    */       }
/*    */       
/* 58 */       JVar argument = parent.decl((JType)classRef(SEXP.class), "s" + i, nextArgAsSexp(this.primitive.isEvaluated(i)));
/* 59 */       arguments.add(argument);
/*    */       
/* 61 */       if (i == 0) {
/* 62 */         this.genericDispatchStrategy.afterFirstArgIsEvaluated(this, (JExpression)this.call, (JExpression)this.args, parent, (JExpression)argument);
/*    */       }
/*    */     } 
/*    */     
/* 66 */     arityMatches(parent._if(lastArgument())._then(), arguments);
/*    */ 
/*    */     
/* 69 */     parent._throw((JExpression)JExpr._new(classRef(EvalException.class)).arg(invalidArityMessage()));
/*    */   }
/*    */   
/*    */   private JExpression invalidArityMessage() {
/* 73 */     return JExpr.lit(this.primitive.getName() + ": too many arguments, expected at most " + this.primitive.getMaxArity() + ".");
/*    */   }
/*    */   
/*    */   private void arityMatches(JBlock parent, List<JExpression> arguments) {
/* 77 */     this.genericDispatchStrategy.beforeTypeMatching(this, (JExpression)this.call, arguments, parent);
/* 78 */     parent._return(invokeWrapper(arguments));
/*    */   }
/*    */   
/*    */   private JExpression invokeWrapper(List<JExpression> arguments) {
/* 82 */     JInvocation invocation = JExpr.invoke(JExpr._this(), "doApply");
/* 83 */     invocation.arg((JExpression)this.context);
/* 84 */     invocation.arg((JExpression)this.environment);
/* 85 */     for (JExpression argument : arguments) {
/* 86 */       invocation.arg(argument);
/*    */     }
/* 88 */     return (JExpression)invocation;
/*    */   }
/*    */   
/*    */   private JExpression lastArgument() {
/* 92 */     return JExpr.invoke((JExpression)this.argumentIterator, "hasNext").not();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/codegen/FixedArityApplyBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */