/*    */ package org.renjin.primitives.special;
/*    */ 
/*    */ import org.renjin.eval.Context;
/*    */ import org.renjin.eval.EvalException;
/*    */ import org.renjin.sexp.Closure;
/*    */ import org.renjin.sexp.Environment;
/*    */ import org.renjin.sexp.FunctionCall;
/*    */ import org.renjin.sexp.PairList;
/*    */ import org.renjin.sexp.SEXP;
/*    */ import org.renjin.sexp.SpecialFunction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClosureFunction
/*    */   extends SpecialFunction
/*    */ {
/*    */   public ClosureFunction() {
/* 32 */     super("function");
/*    */   }
/*    */ 
/*    */   
/*    */   public SEXP apply(Context context, Environment rho, FunctionCall call, PairList args) {
/* 37 */     if (args.length() < 2) {
/* 38 */       throw new EvalException("incorrect number of arguments to \"function\"", new Object[0]);
/*    */     }
/* 40 */     SEXP formals = call.getArgument(0);
/* 41 */     if (!(formals instanceof PairList) || formals instanceof FunctionCall) {
/* 42 */       throw new EvalException("invalid formal argument list for \"function\"", new Object[0]);
/*    */     }
/*    */     
/* 45 */     SEXP body = call.getArgument(1);
/*    */     
/* 47 */     return (SEXP)new Closure(rho, (PairList)formals, body);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/special/ClosureFunction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */