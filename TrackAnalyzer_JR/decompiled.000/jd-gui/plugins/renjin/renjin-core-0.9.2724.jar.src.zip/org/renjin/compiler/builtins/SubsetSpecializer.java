/*    */ package org.renjin.compiler.builtins;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.renjin.compiler.ir.ValueBounds;
/*    */ import org.renjin.compiler.ir.tac.RuntimeState;
/*    */ import org.renjin.sexp.Symbol;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SubsetSpecializer
/*    */   implements Specializer, BuiltinSpecializer
/*    */ {
/*    */   public String getName() {
/* 35 */     return "[";
/*    */   }
/*    */ 
/*    */   
/*    */   public String getGroup() {
/* 40 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Specialization trySpecialize(RuntimeState runtimeState, List<ArgumentBounds> arguments) {
/* 46 */     ValueBounds source = ((ArgumentBounds)arguments.get(0)).getBounds();
/* 47 */     List<ValueBounds> subscripts = ArgumentBounds.withoutNames(arguments.subList(1, arguments.size()));
/*    */     
/* 49 */     if (subscripts.size() == 0) {
/* 50 */       return new CompleteSubset(source);
/*    */     }
/*    */ 
/*    */ 
/*    */     
/* 55 */     if (subscripts.size() > 1)
/*    */     {
/* 57 */       return UnspecializedCall.INSTANCE;
/*    */     }
/*    */     
/* 60 */     ValueBounds subscript = subscripts.get(0);
/*    */     
/* 62 */     if (subscript.isConstant() && subscript.getConstantValue() == Symbol.MISSING_ARG) {
/* 63 */       return new CompleteSubset(source);
/*    */     }
/*    */     
/* 66 */     if (GetAtomicElement.accept(source, subscript)) {
/* 67 */       return new GetAtomicElement(source, subscript);
/*    */     }
/*    */     
/* 70 */     return UnspecializedCall.INSTANCE;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/builtins/SubsetSpecializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */