/*    */ package org.renjin.primitives.packaging;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.apache.commons.vfs2.FileObject;
/*    */ import org.apache.commons.vfs2.FileSystemException;
/*    */ import org.apache.commons.vfs2.FileSystemManager;
/*    */ import org.renjin.eval.Context;
/*    */ import org.renjin.sexp.NamedValue;
/*    */ import org.renjin.util.NamedByteSource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BasePackage
/*    */   extends Package
/*    */ {
/*    */   protected BasePackage() {
/* 33 */     super(FqPackageName.BASE);
/*    */   }
/*    */ 
/*    */   
/*    */   public Iterable<NamedValue> loadSymbols(Context context) throws IOException {
/* 38 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   
/*    */   public NamedByteSource getResource(String name) throws IOException {
/* 43 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   
/*    */   public Class loadClass(String name) {
/* 48 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   
/*    */   public FileObject resolvePackageRoot(FileSystemManager fileSystemManager) throws FileSystemException {
/* 53 */     return fileSystemManager.resolveFile("res:org/renjin/base/DESCRIPTION").getParent();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/packaging/BasePackage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */