/*    */ package org.renjin.compiler.builtins;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.renjin.compiler.ir.ValueBounds;
/*    */ import org.renjin.compiler.ir.exception.InvalidSyntaxException;
/*    */ import org.renjin.compiler.ir.tac.RuntimeState;
/*    */ import org.renjin.invoke.model.JvmMethod;
/*    */ import org.renjin.primitives.Types;
/*    */ import org.renjin.repackaged.guava.collect.Iterables;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IsArraySpecializer
/*    */   implements BuiltinSpecializer
/*    */ {
/* 38 */   private JvmMethod method = (JvmMethod)Iterables.getOnlyElement(JvmMethod.findOverloads(Types.class, "is.array", null));
/*    */ 
/*    */ 
/*    */   
/*    */   public String getName() {
/* 43 */     return "is.array";
/*    */   }
/*    */ 
/*    */   
/*    */   public String getGroup() {
/* 48 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public Specialization trySpecialize(RuntimeState runtimeState, List<ArgumentBounds> arguments) {
/* 53 */     if (arguments.size() != 1) {
/* 54 */       throw new InvalidSyntaxException("is.array() takes one argument.");
/*    */     }
/*    */     
/* 57 */     ValueBounds argumentBounds = ((ArgumentBounds)arguments.get(0)).getBounds();
/* 58 */     if (argumentBounds.isDimCountConstant()) {
/* 59 */       return new ConstantCall(Boolean.valueOf((argumentBounds.getConstantDimCount() > 0)));
/*    */     }
/*    */     
/* 62 */     return new StaticMethodCall(this.method);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/builtins/IsArraySpecializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */