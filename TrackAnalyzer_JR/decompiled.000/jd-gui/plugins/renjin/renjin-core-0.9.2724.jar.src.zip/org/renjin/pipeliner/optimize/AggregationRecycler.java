/*    */ package org.renjin.pipeliner.optimize;
/*    */ 
/*    */ import org.renjin.pipeliner.DeferredGraph;
/*    */ import org.renjin.pipeliner.node.DeferredNode;
/*    */ import org.renjin.pipeliner.node.FunctionNode;
/*    */ import org.renjin.repackaged.guava.cache.Cache;
/*    */ import org.renjin.repackaged.guava.cache.CacheBuilder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AggregationRecycler
/*    */   implements Optimizer
/*    */ {
/* 33 */   private static Cache<String, DeferredNode> aggrCache = CacheBuilder.newBuilder()
/* 34 */     .maximumSize(1000L)
/* 35 */     .build();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean optimize(DeferredGraph graph, FunctionNode node) {
/* 66 */     return false;
/*    */   }
/*    */   
/*    */   public static boolean isCached(String repr) {
/* 70 */     return (aggrCache.getIfPresent(repr) != null);
/*    */   }
/*    */   
/*    */   public static void clear() {
/* 74 */     aggrCache.invalidateAll();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/pipeliner/optimize/AggregationRecycler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */