/*     */ package org.renjin.primitives.combine.view;
/*     */ 
/*     */ import org.renjin.primitives.vector.DeferredComputation;
/*     */ import org.renjin.sexp.AttributeMap;
/*     */ import org.renjin.sexp.DoubleVector;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CombinedDoubleVector
/*     */   extends DoubleVector
/*     */   implements DeferredComputation
/*     */ {
/*     */   private final Vector[] vectors;
/*     */   private final int[] endIndex;
/*     */   private final int totalLength;
/*     */   
/*     */   public static DoubleVector combine(Vector[] vectors, AttributeMap attributeMap) {
/*  35 */     if (vectors.length == 1) {
/*  36 */       return (DoubleVector)vectors[0].setAttributes(attributeMap);
/*     */     }
/*  38 */     return new CombinedDoubleVector(vectors, attributeMap);
/*     */   }
/*     */ 
/*     */   
/*     */   private CombinedDoubleVector(Vector[] vectors, AttributeMap attributeMap) {
/*  43 */     super(attributeMap);
/*     */     
/*  45 */     this.vectors = vectors;
/*  46 */     this.endIndex = new int[vectors.length];
/*     */     
/*  48 */     int totalLength = 0;
/*  49 */     for (int i = 0; i != vectors.length; i++) {
/*  50 */       totalLength += vectors[i].length();
/*  51 */       this.endIndex[i] = totalLength;
/*     */     } 
/*  53 */     this.totalLength = totalLength;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector[] getOperands() {
/*  59 */     return this.vectors;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getComputationName() {
/*  64 */     return "c";
/*     */   }
/*     */ 
/*     */   
/*     */   protected SEXP cloneWithNewAttributes(AttributeMap attributes) {
/*  69 */     return (SEXP)new CombinedDoubleVector(this.vectors, attributes);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDeferred() {
/*  74 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public double getElementAsDouble(int index) {
/*  79 */     if (index < this.endIndex[0]) {
/*  80 */       return this.vectors[0].getElementAsDouble(index);
/*     */     }
/*  82 */     if (index < this.endIndex[1]) {
/*  83 */       return this.vectors[1].getElementAsDouble(index - this.endIndex[0]);
/*     */     }
/*  85 */     if (index < this.endIndex[2]) {
/*  86 */       return this.vectors[2].getElementAsDouble(index - this.endIndex[1]);
/*     */     }
/*  88 */     if (index < this.endIndex[3]) {
/*  89 */       return this.vectors[3].getElementAsDouble(index - this.endIndex[2]);
/*     */     }
/*  91 */     for (int i = 4; i < this.vectors.length; i++) {
/*  92 */       if (index < this.endIndex[i]) {
/*  93 */         return this.vectors[i].getElementAsDouble(index - this.endIndex[i - 1]);
/*     */       }
/*     */     } 
/*  96 */     throw new IllegalArgumentException("index: " + index);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isConstantAccessTime() {
/* 101 */     for (int i = 0; i < this.vectors.length; i++) {
/* 102 */       if (!this.vectors[i].isConstantAccessTime()) {
/* 103 */         return false;
/*     */       }
/*     */     } 
/* 106 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int length() {
/* 111 */     return this.totalLength;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/combine/view/CombinedDoubleVector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */