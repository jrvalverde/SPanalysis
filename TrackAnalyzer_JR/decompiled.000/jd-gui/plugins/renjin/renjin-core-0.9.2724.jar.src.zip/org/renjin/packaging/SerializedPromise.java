/*    */ package org.renjin.packaging;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.util.regex.Matcher;
/*    */ import org.renjin.eval.Context;
/*    */ import org.renjin.eval.EvalException;
/*    */ import org.renjin.primitives.io.serialization.RDataReader;
/*    */ import org.renjin.repackaged.guava.base.Function;
/*    */ import org.renjin.sexp.Environment;
/*    */ import org.renjin.sexp.Null;
/*    */ import org.renjin.sexp.Promise;
/*    */ import org.renjin.sexp.SEXP;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SerializedPromise
/*    */   extends Promise
/*    */ {
/*    */   private Function<String, InputStream> resourceProvider;
/*    */   private String name;
/*    */   
/*    */   public SerializedPromise(Function<String, InputStream> resourceProvider, String name) {
/* 41 */     super((Environment)Environment.EMPTY, (SEXP)Null.INSTANCE);
/* 42 */     this.resourceProvider = resourceProvider;
/* 43 */     this.name = name;
/*    */   }
/*    */ 
/*    */   
/*    */   protected SEXP doEval(Context context, boolean allowMissing) {
/* 48 */     try (RDataReader reader = new RDataReader(context, (InputStream)this.resourceProvider.apply(resourceName(this.name)))) {
/* 49 */       return reader.readFile();
/* 50 */     } catch (IOException e) {
/* 51 */       throw new EvalException(e);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static String resourceName(String symbolName) {
/* 70 */     if (symbolName.startsWith("._")) {
/* 71 */       symbolName = "$$" + symbolName;
/*    */     }
/*    */ 
/*    */     
/* 75 */     symbolName = symbolName.replaceAll("/", Matcher.quoteReplacement("$$div$$"));
/*    */ 
/*    */     
/* 78 */     return symbolName + ".RData";
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/packaging/SerializedPromise.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */