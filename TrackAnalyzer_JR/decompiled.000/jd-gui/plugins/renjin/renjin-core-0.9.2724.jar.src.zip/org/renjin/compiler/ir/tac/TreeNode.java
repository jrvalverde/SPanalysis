package org.renjin.compiler.ir.tac;

import org.renjin.compiler.ir.tac.expressions.Expression;

public interface TreeNode {
  void setChild(int paramInt, Expression paramExpression);
  
  int getChildCount();
  
  Expression childAt(int paramInt);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/ir/tac/TreeNode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */