package org.renjin.compiler.ir.tac.functions;

import org.renjin.sexp.PairList;

public interface TranslationContext {
  PairList getEllipsesArguments();
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/ir/tac/functions/TranslationContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */