/*    */ package org.renjin.parser;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RLexException
/*    */   extends RuntimeException
/*    */ {
/*    */   public RLexException() {}
/*    */   
/*    */   public RLexException(String message) {
/* 27 */     super(message);
/*    */   }
/*    */   
/*    */   public RLexException(String message, Throwable cause) {
/* 31 */     super(message, cause);
/*    */   }
/*    */   
/*    */   public RLexException(Throwable cause) {
/* 35 */     super(cause);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/parser/RLexException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */