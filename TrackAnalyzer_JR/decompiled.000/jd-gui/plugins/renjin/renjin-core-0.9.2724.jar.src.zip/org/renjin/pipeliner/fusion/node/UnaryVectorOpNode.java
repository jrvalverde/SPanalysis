/*     */ package org.renjin.pipeliner.fusion.node;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Optional;
/*     */ import org.renjin.pipeliner.ComputeMethod;
/*     */ import org.renjin.repackaged.asm.Label;
/*     */ import org.renjin.repackaged.asm.MethodVisitor;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ import org.renjin.sexp.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UnaryVectorOpNode
/*     */   extends LoopNode
/*     */ {
/*     */   private String operatorName;
/*     */   private LoopNode operand;
/*     */   private final Class<?> operandType;
/*     */   private Method applyMethod;
/*     */   private Class<?> returnType;
/*     */   
/*     */   public UnaryVectorOpNode(String name, Method operator, LoopNode operand) {
/*  42 */     this.operatorName = name;
/*     */     
/*  44 */     this.applyMethod = operator;
/*  45 */     assert this.applyMethod != null;
/*     */     
/*  47 */     this.operandType = this.applyMethod.getParameterTypes()[0];
/*  48 */     this.operand = operand;
/*     */     
/*  50 */     this.returnType = this.applyMethod.getReturnType();
/*     */   }
/*     */ 
/*     */   
/*     */   public static Method findMethod(Vector vector) {
/*  55 */     for (Method method : vector.getClass().getMethods()) {
/*  56 */       if (method.getName().equals("compute") && 
/*  57 */         Modifier.isPublic(method.getModifiers()) && 
/*  58 */         Modifier.isStatic(method.getModifiers()) && (method
/*  59 */         .getParameterTypes()).length == 1)
/*     */       {
/*  61 */         if (supportedType(method.getReturnType()) && 
/*  62 */           supportedType(method.getParameterTypes()[0])) {
/*  63 */           return method;
/*     */         }
/*     */       }
/*     */     } 
/*  67 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void init(ComputeMethod method) {
/*  72 */     this.operand.init(method);
/*     */   }
/*     */ 
/*     */   
/*     */   public void pushLength(ComputeMethod method) {
/*  77 */     this.operand.pushLength(method);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean mustCheckForIntegerNAs() {
/*  82 */     return this.operand.mustCheckForIntegerNAs();
/*     */   }
/*     */ 
/*     */   
/*     */   public void appendToKey(StringBuilder key) {
/*  87 */     key.append(this.operatorName);
/*  88 */     key.append('(');
/*  89 */     this.operand.appendToKey(key);
/*  90 */     key.append(')');
/*     */   }
/*     */   
/*     */   private void pushResult(ComputeMethod method, Optional<Label> integerNaLabel) {
/*  94 */     if (this.operandType.equals(double.class)) {
/*  95 */       this.operand.pushElementAsDouble(method, integerNaLabel);
/*     */     }
/*  97 */     else if (this.operandType.equals(int.class)) {
/*  98 */       this.operand.pushElementAsInt(method, integerNaLabel);
/*     */     } else {
/*     */       
/* 101 */       throw new UnsupportedOperationException("operandType: " + this.operandType);
/*     */     } 
/*     */     
/* 104 */     MethodVisitor mv = method.getVisitor();
/* 105 */     mv.visitMethodInsn(184, 
/* 106 */         Type.getInternalName(this.applyMethod.getDeclaringClass()), this.applyMethod
/* 107 */         .getName(), 
/* 108 */         Type.getMethodDescriptor(this.applyMethod), false);
/*     */   }
/*     */ 
/*     */   
/*     */   public void pushElementAsDouble(ComputeMethod method, Optional<Label> integerNaLabel) {
/* 113 */     pushResult(method, integerNaLabel);
/* 114 */     cast(method.getVisitor(), this.returnType, double.class);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void pushElementAsInt(ComputeMethod method, Optional<Label> naLabel) {
/* 120 */     pushResult(method, naLabel);
/* 121 */     cast(method.getVisitor(), this.returnType, int.class);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 126 */     return this.operatorName + "(" + this.operand + ")";
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/pipeliner/fusion/node/UnaryVectorOpNode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */