/*     */ package org.renjin.eval;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.IdentityHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import org.renjin.repackaged.guava.base.Function;
/*     */ import org.renjin.repackaged.guava.base.Predicate;
/*     */ import org.renjin.repackaged.guava.collect.Iterables;
/*     */ import org.renjin.repackaged.guava.collect.Lists;
/*     */ import org.renjin.repackaged.guava.collect.Ordering;
/*     */ import org.renjin.sexp.Function;
/*     */ import org.renjin.sexp.FunctionCall;
/*     */ import org.renjin.sexp.Symbol;
/*     */ import org.renjin.sexp.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Profiler
/*     */ {
/*  41 */   public static boolean ENABLED = Boolean.getBoolean("renjin.profile");
/*     */   
/*  43 */   private static final long MIN_LOOP_TIME_RECORD = TimeUnit.MILLISECONDS.toNanos(500L);
/*     */   
/*  45 */   private static long MATERIALIZATION_TIME = 0L;
/*  46 */   private static long MATERIALIZATION_COUNT = 0L;
/*     */   
/*     */   private static class FunctionProfile
/*     */   {
/*     */     private Symbol symbol;
/*     */     private long count;
/*     */     private long time;
/*     */     private long ownTime;
/*     */     private long bytesAllocated;
/*     */     private char type;
/*     */     
/*     */     private FunctionProfile() {}
/*     */   }
/*     */   
/*     */   private static class CallTiming {
/*     */     private Symbol symbol;
/*     */     private char type;
/*     */     private CallTiming parent;
/*     */     private long startTime;
/*     */     private long childTime;
/*     */     private long bytesAllocated;
/*     */     private long materializationTime;
/*     */     private long materializeCount;
/*     */     
/*     */     private CallTiming() {}
/*     */   }
/*     */   
/*     */   private static class LoopProfile {
/*     */     private FunctionCall call;
/*     */     private long time;
/*     */     private long iterations;
/*     */   }
/*     */   
/*     */   private static class LoopTiming {
/*     */     private FunctionCall call;
/*     */     private long startTime;
/*     */     private long time;
/*     */     private LoopTiming parent;
/*     */     private long expectedIterations;
/*     */     private long actualIterations;
/*     */     public Profiler.CallTiming parentCall;
/*     */     
/*     */     private LoopTiming() {}
/*     */   }
/*  90 */   private static Map<Symbol, FunctionProfile> FUNCTION_PROFILES = new IdentityHashMap<>();
/*     */   
/*  92 */   private static Map<Symbol, FunctionProfile> TOP_LEVEL_PROFILES = new IdentityHashMap<>();
/*     */   
/*  94 */   private static List<LoopTiming> LOOP_TIMINGS = new ArrayList<>();
/*     */   
/*  96 */   private static CallTiming CURRENT = null;
/*     */   
/*     */   private static LoopTiming CURRENT_LOOP;
/*  99 */   private static long LOOP_TIME = 0L;
/*     */   
/* 101 */   private static long startTime = System.nanoTime();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void reset() {
/* 108 */     FUNCTION_PROFILES.clear();
/* 109 */     startTime = System.nanoTime();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void functionStart(Symbol functionName, char type) {
/* 117 */     CallTiming timing = new CallTiming();
/* 118 */     timing.symbol = functionName;
/* 119 */     timing.parent = CURRENT;
/* 120 */     timing.startTime = System.nanoTime();
/* 121 */     timing.type = type;
/*     */     
/* 123 */     CURRENT = timing;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void functionStart(Symbol functionName, Function functionExpr) {
/* 128 */     if (functionExpr instanceof org.renjin.sexp.Closure) {
/* 129 */       functionStart(functionName, 'R');
/*     */     } else {
/* 131 */       functionStart(functionName, 'B');
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void loopStart(FunctionCall call, Vector elements) {
/* 136 */     LoopTiming timing = new LoopTiming();
/* 137 */     timing.call = call;
/* 138 */     timing.parentCall = CURRENT;
/* 139 */     timing.parent = CURRENT_LOOP;
/* 140 */     timing.startTime = System.nanoTime();
/* 141 */     timing.expectedIterations = elements.length();
/*     */     
/* 143 */     CURRENT_LOOP = timing;
/*     */   }
/*     */   
/*     */   public static void materialized(long time) {
/* 147 */     MATERIALIZATION_TIME += time;
/* 148 */     MATERIALIZATION_COUNT++;
/*     */     
/* 150 */     if (CURRENT != null) {
/* 151 */       CallTiming callTiming = CURRENT; callTiming.materializationTime = callTiming.materializationTime + time;
/* 152 */       CURRENT.materializeCount++;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void functionEnd() {
/* 160 */     long endTime = System.nanoTime();
/* 161 */     long time = endTime - CURRENT.startTime;
/*     */ 
/*     */ 
/*     */     
/* 165 */     updateMap(FUNCTION_PROFILES, time);
/*     */ 
/*     */     
/* 168 */     if (CURRENT.parent == null) {
/* 169 */       updateMap(TOP_LEVEL_PROFILES, time);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 175 */     CURRENT = CURRENT.parent;
/* 176 */     if (CURRENT != null) {
/* 177 */       CallTiming callTiming = CURRENT; callTiming.childTime = callTiming.childTime + time;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void updateMap(Map<Symbol, FunctionProfile> map, long time) {
/* 182 */     FunctionProfile profile = map.get(CURRENT.symbol);
/* 183 */     if (profile == null) {
/* 184 */       profile = new FunctionProfile();
/* 185 */       profile.symbol = CURRENT.symbol;
/* 186 */       profile.type = CURRENT.type;
/* 187 */       map.put(profile.symbol, profile);
/*     */     } 
/* 189 */     FunctionProfile functionProfile1 = profile; functionProfile1.time = functionProfile1.time + time;
/* 190 */     functionProfile1 = profile; functionProfile1.ownTime = functionProfile1.ownTime + time - CURRENT.childTime;
/* 191 */     profile.count++;
/* 192 */     functionProfile1 = profile; functionProfile1.bytesAllocated = functionProfile1.bytesAllocated + CURRENT.bytesAllocated;
/*     */   }
/*     */   
/*     */   public static void loopEnd(int iterations) {
/* 196 */     long endTime = System.nanoTime();
/* 197 */     long time = endTime - CURRENT_LOOP.startTime;
/*     */     
/* 199 */     LOOP_TIME += time;
/*     */     
/* 201 */     if (time > MIN_LOOP_TIME_RECORD) {
/* 202 */       CURRENT_LOOP.time = time;
/* 203 */       CURRENT_LOOP.actualIterations = iterations;
/* 204 */       LOOP_TIMINGS.add(CURRENT_LOOP);
/*     */     } 
/*     */     
/* 207 */     CURRENT_LOOP = CURRENT_LOOP.parent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void memoryAllocated(int size, int length) {
/* 217 */     if (CURRENT != null) {
/* 218 */       CallTiming callTiming = CURRENT; callTiming.bytesAllocated = callTiming.bytesAllocated + (length * size / 8);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void dumpTotalRunningTime() {
/* 223 */     long totalRunningTime = System.nanoTime() - startTime;
/*     */     
/* 225 */     double seconds = TimeUnit.NANOSECONDS.toSeconds(totalRunningTime);
/* 226 */     double minutes = seconds / 60.0D;
/*     */     
/* 228 */     System.out.println("Completed in " + minutes + " minutes");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void dump(PrintStream out) {
/* 237 */     long totalRunningTime = System.nanoTime() - startTime;
/*     */     
/* 239 */     printTopFunctions(out, totalRunningTime);
/* 240 */     printFunctionTimings(out, totalRunningTime);
/* 241 */     printLoopTimings(out);
/* 242 */     printMaterializationStats(out);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static void printTopFunctions(PrintStream out, final double totalRunningTime) {
/* 248 */     List<FunctionProfile> profiles = Lists.newArrayList(TOP_LEVEL_PROFILES.values());
/* 249 */     Collections.sort(profiles, (Comparator<? super FunctionProfile>)Ordering.natural().onResultOf(new Function<FunctionProfile, Long>()
/*     */           {
/*     */             public Long apply(Profiler.FunctionProfile input) {
/* 252 */               return Long.valueOf(input.time);
/*     */             }
/* 254 */           }).reverse());
/* 255 */     Iterables.filter(profiles, new Predicate<FunctionProfile>()
/*     */         {
/*     */           public boolean apply(Profiler.FunctionProfile input) {
/* 258 */             return (input.time / totalRunningTime > 0.01D);
/*     */           }
/*     */         });
/*     */     
/* 262 */     out.println();
/* 263 */     out.println("TOP-LEVEL FUNCTION CALLS");
/* 264 */     out.println("==================");
/* 265 */     out.println();
/* 266 */     out.println(String.format("  %-25s%10s%10s%10s%4s%10s", new Object[] { "Function", "Count", "Time", "Own Time", "%", "kb Alloc" }));
/*     */     
/* 268 */     printProfiles(out, totalRunningTime, Iterables.limit(profiles, 10));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static void printFunctionTimings(PrintStream out, double totalRunningTime) {
/* 274 */     List<FunctionProfile> profiles = Lists.newArrayList(FUNCTION_PROFILES.values());
/* 275 */     Collections.sort(profiles, (Comparator<? super FunctionProfile>)Ordering.natural().onResultOf(new Function<FunctionProfile, Long>()
/*     */           {
/*     */             public Long apply(Profiler.FunctionProfile input) {
/* 278 */               return Long.valueOf(input.ownTime);
/*     */             }
/* 280 */           }).reverse());
/*     */ 
/*     */     
/* 283 */     out.println();
/* 284 */     out.println("FUNCTION CALLS BY OWN TIME");
/* 285 */     out.println("==========================");
/* 286 */     out.println();
/* 287 */     out.println(String.format("  %-25s%10s%10s%10s%4s%10s", new Object[] { "Function", "Count", "Time", "Own Time", "%", "kb Alloc" }));
/*     */     
/* 289 */     printProfiles(out, totalRunningTime, profiles);
/*     */   }
/*     */   
/*     */   private static void printProfiles(PrintStream out, double totalRunningTime, Iterable<FunctionProfile> profiles) {
/* 293 */     for (FunctionProfile profile : profiles) {
/* 294 */       out.println(String.format("%c %-25s%10d%10d%10d%3.0f%%%10s", new Object[] {
/* 295 */               Character.valueOf(FunctionProfile.access$1500(profile)), 
/* 296 */               FunctionProfile.access$1400(profile).getPrintName(), 
/* 297 */               Long.valueOf(FunctionProfile.access$1800(profile)), 
/* 298 */               Long.valueOf(TimeUnit.NANOSECONDS.toMillis(FunctionProfile.access$1600(profile))), 
/* 299 */               Long.valueOf(TimeUnit.NANOSECONDS.toMillis(FunctionProfile.access$1700(profile))), 
/* 300 */               Double.valueOf(FunctionProfile.access$1700(profile) / totalRunningTime * 100.0D), 
/* 301 */               formatAlloc(FunctionProfile.access$1900(profile)) }));
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void printLoopTimings(PrintStream out) {
/* 306 */     out.println();
/* 307 */     out.println("LONG RUNNING LOOPS");
/* 308 */     out.println("==================");
/*     */     
/* 310 */     List<LoopTiming> loops = Lists.newArrayList(LOOP_TIMINGS);
/* 311 */     Collections.sort(loops, (Comparator<? super LoopTiming>)Ordering.natural().onResultOf(new Function<LoopTiming, Long>()
/*     */           {
/*     */             public Long apply(Profiler.LoopTiming input) {
/* 314 */               return Long.valueOf(input.time);
/*     */             }
/*     */           }));
/*     */ 
/*     */     
/* 319 */     out.println(String.format("%-25s%10s%10s", new Object[] { "Function", "Iterations", "Time" }));
/*     */     
/* 321 */     for (LoopTiming loop : loops) {
/* 322 */       out.println(String.format("%-25s%10d%10d", new Object[] {
/* 323 */               CallTiming.access$100(loop.parentCall).getPrintName(), 
/* 324 */               Long.valueOf(LoopTiming.access$2200(loop)), 
/* 325 */               Long.valueOf(TimeUnit.NANOSECONDS.toMillis(LoopTiming.access$2100(loop))) }));
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void printMaterializationStats(PrintStream out) {
/* 330 */     out.println();
/* 331 */     out.println("VECTOR PIPELINER");
/* 332 */     out.println("================");
/*     */     
/* 334 */     System.out.println("Materialization count: " + MATERIALIZATION_COUNT);
/* 335 */     System.out.println("Materialization time (ms): " + TimeUnit.NANOSECONDS.toMillis(MATERIALIZATION_TIME));
/*     */   }
/*     */ 
/*     */   
/*     */   private static String formatAlloc(long bytes) {
/* 340 */     if (bytes < 1024L) {
/* 341 */       return "";
/*     */     }
/* 343 */     double kb = bytes / 1024.0D;
/* 344 */     if (kb < 1024.0D) {
/* 345 */       return String.format("%.1f kb", new Object[] { Double.valueOf(kb) });
/*     */     }
/* 347 */     double mb = kb / 1024.0D;
/* 348 */     if (mb < 1024.0D) {
/* 349 */       return String.format("%.1f mb", new Object[] { Double.valueOf(mb) });
/*     */     }
/* 351 */     double gb = mb / 1024.0D;
/* 352 */     return String.format("%.1f gb", new Object[] { Double.valueOf(gb) });
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/eval/Profiler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */