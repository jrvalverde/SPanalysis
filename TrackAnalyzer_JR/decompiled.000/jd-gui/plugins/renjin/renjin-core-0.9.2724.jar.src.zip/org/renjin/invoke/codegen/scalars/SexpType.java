/*    */ package org.renjin.invoke.codegen.scalars;
/*    */ 
/*    */ import com.sun.codemodel.JCodeModel;
/*    */ import com.sun.codemodel.JExpression;
/*    */ import org.renjin.sexp.ListVector;
/*    */ import org.renjin.sexp.SEXP;
/*    */ import org.renjin.sexp.Vector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SexpType
/*    */   extends ScalarType
/*    */ {
/*    */   public Class getScalarType() {
/* 31 */     return SEXP.class;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getConversionMethod() {
/* 36 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   
/*    */   public String getAccessorMethod() {
/* 41 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   
/*    */   public Class getVectorType() {
/* 46 */     return ListVector.class;
/*    */   }
/*    */ 
/*    */   
/*    */   public Class<? extends Vector.Builder<?>> getBuilderClass() {
/* 51 */     return (Class)ListVector.Builder.class;
/*    */   }
/*    */ 
/*    */   
/*    */   public Class getBuilderArrayElementClass() {
/* 56 */     return SEXP.class;
/*    */   }
/*    */ 
/*    */   
/*    */   public Class getArrayVectorClass() {
/* 61 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   
/*    */   public JExpression naLiteral(JCodeModel codeModel) {
/* 66 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/codegen/scalars/SexpType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */