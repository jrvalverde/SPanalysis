/*    */ package org.renjin.primitives.match;
/*    */ 
/*    */ import org.renjin.sexp.Vector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ interface DuplicateSearchAlgorithm<ResultType>
/*    */ {
/*    */   void init(Vector paramVector);
/*    */   
/*    */   void onUnique(int paramInt);
/*    */   
/*    */   Action onDuplicate(int paramInt1, int paramInt2);
/*    */   
/*    */   ResultType getResult();
/*    */   
/*    */   public enum Action
/*    */   {
/* 26 */     STOP,
/* 27 */     CONTINUE;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/match/DuplicateSearchAlgorithm.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */