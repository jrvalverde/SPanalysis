/*    */ package org.renjin.compiler.builtins;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.renjin.compiler.ir.ValueBounds;
/*    */ import org.renjin.compiler.ir.exception.InvalidSyntaxException;
/*    */ import org.renjin.compiler.ir.tac.RuntimeState;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LengthSpecializer
/*    */   implements Specializer, BuiltinSpecializer
/*    */ {
/*    */   public String getName() {
/* 33 */     return "length";
/*    */   }
/*    */ 
/*    */   
/*    */   public String getGroup() {
/* 38 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public Specialization trySpecialize(RuntimeState runtimeState, List<ArgumentBounds> arguments) {
/* 43 */     if (arguments.size() != 1) {
/* 44 */       throw new InvalidSyntaxException("length() takes one argument.");
/*    */     }
/*    */     
/* 47 */     ValueBounds argumentBounds = ((ArgumentBounds)arguments.get(0)).getBounds();
/* 48 */     if (argumentBounds.isLengthConstant()) {
/* 49 */       return new ConstantCall(Integer.valueOf(argumentBounds.getLength()));
/*    */     }
/*    */     
/* 52 */     return new LengthCall();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/builtins/LengthSpecializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */