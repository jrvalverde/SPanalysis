/*    */ package org.renjin.compiler.ir.tac.expressions;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.renjin.compiler.codegen.EmitContext;
/*    */ import org.renjin.compiler.ir.ValueBounds;
/*    */ import org.renjin.eval.Context;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ import org.renjin.repackaged.asm.commons.InstructionAdapter;
/*    */ import org.renjin.sexp.Environment;
/*    */ import org.renjin.sexp.SEXP;
/*    */ import org.renjin.sexp.Symbol;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReadEnvironment
/*    */   implements Expression
/*    */ {
/*    */   private Symbol name;
/*    */   private ValueBounds valueBounds;
/*    */   
/*    */   public ReadEnvironment(Symbol name, ValueBounds valueBounds) {
/* 42 */     this.name = name;
/* 43 */     this.valueBounds = valueBounds;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isPure() {
/* 48 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public int load(EmitContext emitContext, InstructionAdapter mv) {
/* 53 */     mv.visitVarInsn(25, emitContext.getEnvironmentVarIndex());
/* 54 */     mv.visitLdcInsn(this.name.getPrintName());
/* 55 */     mv.visitMethodInsn(184, Type.getInternalName(Symbol.class), "get", 
/* 56 */         Type.getMethodDescriptor(Type.getType(Symbol.class), new Type[] { Type.getType(String.class) }), false);
/* 57 */     mv.visitMethodInsn(182, Type.getInternalName(Environment.class), "findVariableUnsafe", 
/* 58 */         Type.getMethodDescriptor(Type.getType(SEXP.class), new Type[] { Type.getType(Symbol.class) }), false);
/* 59 */     mv.visitVarInsn(25, emitContext.getContextVarIndex());
/* 60 */     mv.visitMethodInsn(185, Type.getInternalName(SEXP.class), "force", 
/* 61 */         Type.getMethodDescriptor(Type.getType(SEXP.class), new Type[] { Type.getType(Context.class) }), true);
/* 62 */     return 2;
/*    */   }
/*    */ 
/*    */   
/*    */   public Type getType() {
/* 67 */     return Type.getType(SEXP.class);
/*    */   }
/*    */ 
/*    */   
/*    */   public ValueBounds updateTypeBounds(Map<Expression, ValueBounds> typeMap) {
/* 72 */     return this.valueBounds;
/*    */   }
/*    */ 
/*    */   
/*    */   public ValueBounds getValueBounds() {
/* 77 */     return this.valueBounds;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setChild(int childIndex, Expression child) {
/* 82 */     throw new IllegalArgumentException();
/*    */   }
/*    */ 
/*    */   
/*    */   public int getChildCount() {
/* 87 */     return 0;
/*    */   }
/*    */ 
/*    */   
/*    */   public Expression childAt(int index) {
/* 92 */     throw new IllegalArgumentException();
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 97 */     return "read(" + this.name + " = " + this.valueBounds + ")";
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/ir/tac/expressions/ReadEnvironment.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */