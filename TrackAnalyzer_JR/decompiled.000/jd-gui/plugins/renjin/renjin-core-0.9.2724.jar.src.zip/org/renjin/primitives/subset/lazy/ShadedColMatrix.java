/*     */ package org.renjin.primitives.subset.lazy;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.renjin.primitives.vector.MemoizedComputation;
/*     */ import org.renjin.repackaged.guava.primitives.Ints;
/*     */ import org.renjin.sexp.AttributeMap;
/*     */ import org.renjin.sexp.DoubleArrayVector;
/*     */ import org.renjin.sexp.DoubleVector;
/*     */ import org.renjin.sexp.IntArrayVector;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.Symbols;
/*     */ import org.renjin.sexp.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ShadedColMatrix
/*     */   extends DoubleVector
/*     */   implements MemoizedComputation
/*     */ {
/*  32 */   private DoubleVector base = null;
/*  33 */   private int colheight = 1;
/*  34 */   private Map<Integer, DoubleVector> columnMap = new HashMap<>();
/*     */   
/*     */   private double[] result;
/*     */   
/*     */   public ShadedColMatrix(DoubleVector source) {
/*  39 */     super(source.getAttributes());
/*  40 */     this.base = source;
/*  41 */     SEXP dimr = this.base.getAttribute(Symbols.DIM);
/*  42 */     if (!(dimr instanceof IntArrayVector)) {
/*  43 */       throw new RuntimeException("non-integer dimensions? weird!");
/*     */     }
/*  45 */     this.colheight = ((IntArrayVector)dimr).getElementAsInt(0);
/*     */   }
/*     */   
/*     */   public ShadedColMatrix withShadedCol(int col, DoubleVector elements) {
/*  49 */     return cloneWithNewAttributes(getAttributes()).setShadedCol(col, elements);
/*     */   }
/*     */   
/*     */   public ShadedColMatrix setShadedCol(int col, DoubleVector elements) {
/*  53 */     this.columnMap.put(Integer.valueOf(col), elements);
/*  54 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isConstantAccessTime() {
/*  59 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   protected ShadedColMatrix cloneWithNewAttributes(AttributeMap attributes) {
/*  64 */     ShadedColMatrix clone = new ShadedColMatrix(this.base);
/*  65 */     clone.columnMap = new HashMap<>(this.columnMap);
/*  66 */     return clone;
/*     */   }
/*     */ 
/*     */   
/*     */   public double getElementAsDouble(int index) {
/*  71 */     int col = index / this.colheight + 1;
/*  72 */     int row = index % this.colheight;
/*  73 */     if (this.columnMap.containsKey(Integer.valueOf(col))) {
/*  74 */       return ((DoubleVector)this.columnMap.get(Integer.valueOf(col))).get(row);
/*     */     }
/*  76 */     return this.base.get(index);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int length() {
/*  82 */     return this.base.length();
/*     */   }
/*     */ 
/*     */   
/*     */   public Vector[] getOperands() {
/*  87 */     List<Vector> ops = new ArrayList<>();
/*  88 */     ops.add(this.base);
/*  89 */     ops.add(new IntArrayVector(Ints.toArray(this.columnMap.keySet())));
/*  90 */     ops.addAll((Collection)this.columnMap.values());
/*  91 */     return ops.<Vector>toArray(new Vector[ops.size()]);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getComputationName() {
/*  96 */     return "ShadedColMatrix";
/*     */   }
/*     */ 
/*     */   
/*     */   public Vector forceResult() {
/* 101 */     int numColumns = length() / this.colheight;
/*     */     
/* 103 */     double[] matrix = this.base.toDoubleArray();
/* 104 */     int index = 0;
/* 105 */     for (int col = 0; col < numColumns; col++) {
/* 106 */       DoubleVector column = this.columnMap.get(Integer.valueOf(col + 1));
/* 107 */       if (column == null) {
/*     */         
/* 109 */         index += this.colheight;
/*     */       }
/*     */       else {
/*     */         
/* 113 */         for (int row = 0; row < this.colheight; row++) {
/* 114 */           matrix[index++] = column.getElementAsDouble(row);
/*     */         }
/*     */       } 
/*     */     } 
/* 118 */     this.result = matrix;
/*     */     
/* 120 */     return (Vector)DoubleArrayVector.unsafe(this.result, getAttributes());
/*     */   }
/*     */ 
/*     */   
/*     */   public void setResult(Vector result) {
/* 125 */     this.result = ((DoubleArrayVector)result).toDoubleArrayUnsafe();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isCalculated() {
/* 130 */     return (this.result != null);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/subset/lazy/ShadedColMatrix.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */