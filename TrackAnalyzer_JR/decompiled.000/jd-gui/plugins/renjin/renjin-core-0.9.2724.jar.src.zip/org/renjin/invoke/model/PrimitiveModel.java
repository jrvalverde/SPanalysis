/*     */ package org.renjin.invoke.model;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.renjin.invoke.annotations.ArgumentList;
/*     */ import org.renjin.invoke.codegen.GeneratorDefinitionException;
/*     */ import org.renjin.invoke.codegen.WrapperGenerator2;
/*     */ import org.renjin.primitives.Primitives;
/*     */ import org.renjin.repackaged.guava.collect.Lists;
/*     */ import org.renjin.repackaged.guava.collect.Sets;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PrimitiveModel
/*     */ {
/*     */   private final Primitives.Entry entry;
/*     */   private final List<JvmMethod> overloads;
/*     */   
/*     */   public PrimitiveModel(Primitives.Entry entry, List<JvmMethod> overloads) {
/*  42 */     this.entry = entry;
/*  43 */     this.overloads = overloads;
/*     */   }
/*     */   
/*     */   public String argumentErrorMessage() {
/*  47 */     StringBuilder message = new StringBuilder();
/*  48 */     message.append("Invalid argument: %s. Expected:");
/*  49 */     for (JvmMethod method : this.overloads) {
/*  50 */       message.append("\n\t");
/*  51 */       method.appendFriendlySignatureTo(this.entry.name, message);
/*     */     } 
/*  53 */     return message.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int maxPositionalArgs() {
/*  63 */     int max = 0;
/*  64 */     for (JvmMethod overload : this.overloads) {
/*  65 */       int count = overload.countPositionalFormals();
/*  66 */       if (count > max) {
/*  67 */         max = count;
/*     */       }
/*     */     } 
/*  70 */     return max;
/*     */   }
/*     */   
/*     */   public List<JvmMethod> overloadsWithPosArgCountOf(int i) {
/*  74 */     List<JvmMethod> matching = Lists.newArrayList();
/*  75 */     for (JvmMethod overload : this.overloads) {
/*  76 */       if (overload.countPositionalFormals() == i) {
/*  77 */         matching.add(overload);
/*     */       }
/*     */     } 
/*  80 */     Collections.sort(matching);
/*  81 */     return matching;
/*     */   }
/*     */   
/*     */   public boolean isEvaluated(int argumentIndex) {
/*  85 */     boolean evaluated = false;
/*  86 */     boolean unevaluated = false;
/*  87 */     for (JvmMethod overload : this.overloads) {
/*  88 */       if (argumentIndex < overload.getFormals().size()) {
/*  89 */         if (((JvmMethod.Argument)overload.getFormals().get(argumentIndex)).isEvaluated()) {
/*  90 */           evaluated = true; continue;
/*     */         } 
/*  92 */         unevaluated = true;
/*     */       } 
/*     */     } 
/*     */     
/*  96 */     if (evaluated && unevaluated) {
/*  97 */       throw new GeneratorDefinitionException("Mixing evaluated and unevaluated arguments at the same position is not yet supported");
/*     */     }
/*     */     
/* 100 */     return evaluated;
/*     */   }
/*     */   
/*     */   public String getName() {
/* 104 */     return this.entry.name;
/*     */   }
/*     */   
/*     */   public String getJavaName() {
/* 108 */     return WrapperGenerator2.toJavaName(getName());
/*     */   }
/*     */   
/*     */   public String getClassName() {
/* 112 */     return "R$primitive$" + getJavaName();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSpecial() {
/* 117 */     return this.entry.isSpecial();
/*     */   }
/*     */   
/*     */   public List<Integer> getArity() {
/* 121 */     Set<Integer> arity = Sets.newHashSet();
/*     */     
/* 123 */     for (JvmMethod overload : this.overloads) {
/* 124 */       arity.add(Integer.valueOf(overload.countPositionalFormals()));
/*     */     }
/*     */     
/* 127 */     List<Integer> list = Lists.newArrayList(arity);
/* 128 */     Collections.sort(list);
/*     */     
/* 130 */     return list;
/*     */   }
/*     */   
/*     */   public int getMaxArity() {
/* 134 */     int max = 0;
/* 135 */     for (JvmMethod overload : this.overloads) {
/* 136 */       if (overload.countPositionalFormals() > max) {
/* 137 */         max = overload.countPositionalFormals();
/*     */       }
/*     */     } 
/* 140 */     return max;
/*     */   }
/*     */   
/*     */   public boolean hasVargs() {
/* 144 */     for (JvmMethod overload : this.overloads) {
/* 145 */       for (JvmMethod.Argument argument : overload.getFormals()) {
/* 146 */         if (argument.isAnnotatedWith((Class)ArgumentList.class)) {
/* 147 */           return true;
/*     */         }
/*     */       } 
/*     */     } 
/* 151 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isMissingAllowedInVarArgs() {
/* 155 */     for (JvmMethod overload : this.overloads) {
/* 156 */       for (JvmMethod.Argument argument : overload.getFormals()) {
/* 157 */         if (argument.isAnnotatedWith((Class)ArgumentList.class)) {
/* 158 */           return ((ArgumentList)argument.<ArgumentList>getAnnotation(ArgumentList.class)).allowMissing();
/*     */         }
/*     */       } 
/*     */     } 
/* 162 */     return false;
/*     */   }
/*     */   
/*     */   public List<JvmMethod> getOverloads() {
/* 166 */     return this.overloads;
/*     */   }
/*     */   
/*     */   public boolean isRelationalOperator() {
/* 170 */     if (getName().equals("==") || getName().equals("!=") || 
/* 171 */       getName().equals(">=") || getName().equals("<=") || 
/* 172 */       getName().equals(">") || getName().equals("<")) {
/* 173 */       return true;
/*     */     }
/* 175 */     return false;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/model/PrimitiveModel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */