/*     */ package org.renjin.primitives.packaging;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import java.util.Set;
/*     */ import org.renjin.eval.Context;
/*     */ import org.renjin.eval.EvalException;
/*     */ import org.renjin.invoke.annotations.SessionScoped;
/*     */ import org.renjin.repackaged.guava.base.Charsets;
/*     */ import org.renjin.repackaged.guava.collect.Maps;
/*     */ import org.renjin.repackaged.guava.collect.Sets;
/*     */ import org.renjin.repackaged.guava.io.CharSource;
/*     */ import org.renjin.sexp.Environment;
/*     */ import org.renjin.sexp.FunctionCall;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.StringVector;
/*     */ import org.renjin.sexp.Symbol;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @SessionScoped
/*     */ public class NamespaceRegistry
/*     */ {
/*  45 */   private static final Symbol BASE = Symbol.get("base");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  51 */   public static final Set<String> CORE_PACKAGES = Sets.newHashSet((Object[])new String[] { "datasets", "graphics", "grDevices", "hamcrest", "methods", "splines", "stats", "stats4", "utils", "grid", "parallel", "tools", "tcltk", "compiler" });
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private PackageLoader loader;
/*     */ 
/*     */ 
/*     */   
/*  60 */   private Map<Symbol, Namespace> localNameMap = new HashMap<>();
/*  61 */   private Map<FqPackageName, Namespace> namespaceMap = Maps.newHashMap();
/*     */   
/*  63 */   private Map<Environment, Namespace> envirMap = Maps.newIdentityHashMap();
/*     */   
/*     */   private final Namespace baseNamespace;
/*     */   
/*     */   public NamespaceRegistry(PackageLoader loader, Environment baseNamespaceEnv) {
/*  68 */     this.loader = loader;
/*     */     
/*  70 */     this.baseNamespace = new BaseNamespace(baseNamespaceEnv);
/*  71 */     this.localNameMap.put(BASE, this.baseNamespace);
/*  72 */     this.envirMap.put(baseNamespaceEnv, this.baseNamespace);
/*     */   }
/*     */   
/*     */   public Namespace getBaseNamespace() {
/*  76 */     return this.baseNamespace;
/*     */   }
/*     */   
/*     */   public Environment getBaseNamespaceEnv() {
/*  80 */     return getBaseNamespace().getNamespaceEnvironment();
/*     */   }
/*     */   
/*     */   public Namespace getNamespace(Environment envir) {
/*  84 */     Namespace ns = this.envirMap.get(envir);
/*  85 */     if (ns == null) {
/*  86 */       throw new IllegalArgumentException();
/*     */     }
/*  88 */     return ns;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterable<Symbol> getLoadedNamespaceNames() {
/*  98 */     return this.localNameMap.keySet();
/*     */   }
/*     */   
/*     */   public Iterable<Namespace> getLoadedNamespaces() {
/* 102 */     return this.namespaceMap.values();
/*     */   }
/*     */   
/*     */   public Optional<Namespace> getNamespaceIfPresent(Symbol name) {
/* 106 */     return Optional.ofNullable(this.localNameMap.get(name));
/*     */   }
/*     */   
/*     */   public Namespace getNamespace(Context context, String name) {
/* 110 */     return getNamespace(context, Symbol.get(name));
/*     */   }
/*     */ 
/*     */   
/*     */   public Namespace getNamespace(Context context, Symbol symbol) {
/* 115 */     Namespace localMatch = this.localNameMap.get(symbol);
/* 116 */     if (localMatch != null) {
/* 117 */       return localMatch;
/*     */     }
/*     */ 
/*     */     
/* 121 */     if (CORE_PACKAGES.contains(symbol.getPrintName()))
/*     */     {
/*     */ 
/*     */ 
/*     */       
/* 126 */       return getNamespace(context, FqPackageName.corePackage(symbol));
/*     */     }
/* 128 */     if (FqPackageName.isQualified(symbol))
/*     */     {
/*     */       
/* 131 */       return getNamespace(context, FqPackageName.fromSymbol(symbol));
/*     */     }
/*     */ 
/*     */     
/* 135 */     Optional<Package> pkg = this.loader.load(symbol.getPrintName());
/* 136 */     if (!pkg.isPresent()) {
/* 137 */       throw new EvalException("Could not find package '" + symbol + "'", new Object[0]);
/*     */     }
/* 139 */     return load(context, pkg.get());
/*     */   }
/*     */ 
/*     */   
/*     */   private Namespace getNamespace(Context context, FqPackageName fqPackageName) {
/* 144 */     Namespace namespace = this.namespaceMap.get(fqPackageName);
/* 145 */     if (namespace != null) {
/* 146 */       return namespace;
/*     */     }
/* 148 */     Optional<Package> pkg = this.loader.load(fqPackageName);
/* 149 */     if (!pkg.isPresent()) {
/* 150 */       throw new EvalException("Could not load package " + fqPackageName, new Object[0]);
/*     */     }
/* 152 */     return load(context, pkg.get());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Namespace load(Context context, Package pkg) {
/*     */     try {
/* 159 */       Namespace namespace = createNamespace(pkg);
/*     */       
/* 161 */       CharSource namespaceSource = pkg.getResource("NAMESPACE").asCharSource(Charsets.UTF_8);
/* 162 */       NamespaceFile namespaceFile = NamespaceFile.parseFile(context, namespaceSource);
/*     */ 
/*     */       
/* 165 */       namespace.populateNamespace(context);
/* 166 */       namespace.initExports(namespaceFile);
/*     */       
/* 168 */       context.getSession().getS4Cache().invalidate();
/*     */ 
/*     */       
/* 171 */       namespace.initImports(context, this, namespaceFile);
/*     */ 
/*     */ 
/*     */       
/* 175 */       if (namespace.getNamespaceEnvironment().hasVariable(Symbol.get(".onLoad"))) {
/* 176 */         StringVector nameArgument = StringVector.valueOf(pkg.getName().getPackageName());
/* 177 */         context.evaluate((SEXP)FunctionCall.newCall((SEXP)Symbol.get(".onLoad"), new SEXP[] { (SEXP)nameArgument, (SEXP)nameArgument }), namespace
/* 178 */             .getNamespaceEnvironment());
/*     */       } 
/*     */       
/* 181 */       namespace.registerS3Methods(context, namespaceFile);
/* 182 */       namespace.loaded = true;
/*     */       
/* 184 */       return namespace;
/*     */     }
/* 186 */     catch (Exception e) {
/* 187 */       throw new EvalException("IOException while loading package " + pkg.getName() + ": " + e.getMessage(), e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean isRegistered(Symbol name) {
/* 192 */     return this.localNameMap.containsKey(name);
/*     */   }
/*     */   
/*     */   public Namespace getBase() {
/* 196 */     return this.baseNamespace;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Namespace createNamespace(Package pkg) {
/* 208 */     Environment imports = Environment.createNamedEnvironment(getBaseNamespaceEnv(), "imports:" + pkg.getName().toString('.')).build();
/*     */     
/* 210 */     Environment namespaceEnv = Environment.createNamespaceEnvironment(imports, pkg.getName().getPackageName()).build();
/* 211 */     Namespace namespace = new Namespace(pkg, namespaceEnv);
/* 212 */     this.localNameMap.put(pkg.getName().getPackageSymbol(), namespace);
/* 213 */     this.namespaceMap.put(pkg.getName(), namespace);
/*     */     
/* 215 */     this.envirMap.put(namespaceEnv, namespace);
/*     */ 
/*     */     
/* 218 */     namespaceEnv.setVariableUnsafe(".packageName", (SEXP)StringVector.valueOf(pkg.getName().getPackageName()));
/* 219 */     return namespace;
/*     */   }
/*     */   
/*     */   public boolean isNamespaceEnv(Environment envir) {
/* 223 */     return this.envirMap.containsKey(envir);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/packaging/NamespaceRegistry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */