/*    */ package org.renjin.primitives.matrix;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import org.renjin.parser.NumericLiterals;
/*    */ import org.renjin.sexp.DoubleVector;
/*    */ import org.renjin.sexp.IntVector;
/*    */ import org.renjin.sexp.StringVector;
/*    */ import org.renjin.sexp.Vector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StringMatrixBuilder
/*    */   extends AbstractMatrixBuilder<StringVector.Builder, StringVector>
/*    */   implements MatrixBuilder
/*    */ {
/*    */   public StringMatrixBuilder(int nrows, int ncols) {
/* 31 */     super(StringVector.VECTOR_TYPE, nrows, ncols);
/*    */   }
/*    */ 
/*    */   
/*    */   public void setValue(int row, int col, double value) {
/* 36 */     if (DoubleVector.isNA(value)) {
/* 37 */       setValue(row, col, StringVector.NA);
/*    */     } else {
/* 39 */       setValue(row, col, NumericLiterals.toString(value));
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void setValue(int row, int col, int value) {
/* 45 */     if (IntVector.isNA(value)) {
/* 46 */       setValue(row, col, StringVector.NA);
/*    */     } else {
/* 48 */       setValue(row, col, NumericLiterals.format(value));
/*    */     } 
/*    */   }
/*    */   
/*    */   public void setValue(int row, int col, String value) {
/* 53 */     this.builder.set(computeIndex(row, col), value);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/matrix/StringMatrixBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */