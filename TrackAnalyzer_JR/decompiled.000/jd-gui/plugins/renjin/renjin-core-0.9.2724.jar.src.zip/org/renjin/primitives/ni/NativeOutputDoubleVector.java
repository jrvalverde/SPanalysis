/*    */ package org.renjin.primitives.ni;
/*    */ 
/*    */ import org.renjin.sexp.AttributeMap;
/*    */ import org.renjin.sexp.DoubleVector;
/*    */ import org.renjin.sexp.SEXP;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NativeOutputDoubleVector
/*    */   extends DoubleVector
/*    */   implements NativeOutputVector
/*    */ {
/*    */   private final DeferredNativeCall call;
/*    */   private final int outputIndex;
/*    */   private final int length;
/*    */   private double[] array;
/*    */   
/*    */   public NativeOutputDoubleVector(DeferredNativeCall call, int outputIndex, int length, AttributeMap attributes) {
/* 34 */     super(attributes);
/* 35 */     this.call = call;
/* 36 */     this.outputIndex = outputIndex;
/* 37 */     this.length = length;
/*    */   }
/*    */ 
/*    */   
/*    */   protected SEXP cloneWithNewAttributes(AttributeMap attributes) {
/* 42 */     return (SEXP)new NativeOutputDoubleVector(this.call, this.outputIndex, this.length, attributes);
/*    */   }
/*    */ 
/*    */   
/*    */   public int length() {
/* 47 */     return this.length;
/*    */   }
/*    */ 
/*    */   
/*    */   public double getElementAsDouble(int index) {
/* 52 */     if (this.array == null) {
/* 53 */       this.array = (double[])this.call.output(this.outputIndex);
/*    */     }
/* 55 */     return this.array[index];
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isConstantAccessTime() {
/* 60 */     return this.call.isEvaluated();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isDeferred() {
/* 65 */     return !this.call.isEvaluated();
/*    */   }
/*    */ 
/*    */   
/*    */   public DeferredNativeCall getCall() {
/* 70 */     return this.call;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getOutputIndex() {
/* 75 */     return this.outputIndex;
/*    */   }
/*    */   
/*    */   public double[] toDoubleArrayUnsafe() {
/* 79 */     if (this.array == null) {
/* 80 */       this.array = (double[])this.call.output(this.outputIndex);
/*    */     }
/* 82 */     return this.array;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/ni/NativeOutputDoubleVector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */