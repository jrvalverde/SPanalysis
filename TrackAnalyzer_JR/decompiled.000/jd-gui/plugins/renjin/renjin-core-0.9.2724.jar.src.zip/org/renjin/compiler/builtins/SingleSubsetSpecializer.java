/*    */ package org.renjin.compiler.builtins;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.renjin.compiler.ir.TypeSet;
/*    */ import org.renjin.compiler.ir.ValueBounds;
/*    */ import org.renjin.compiler.ir.tac.RuntimeState;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SingleSubsetSpecializer
/*    */   implements BuiltinSpecializer
/*    */ {
/*    */   public String getName() {
/* 34 */     return "[[";
/*    */   }
/*    */ 
/*    */   
/*    */   public String getGroup() {
/* 39 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Specialization trySpecialize(RuntimeState runtimeState, List<ArgumentBounds> arguments) {
/* 47 */     if (arguments.size() == 2) {
/*    */       
/* 49 */       ValueBounds source = ((ArgumentBounds)arguments.get(0)).getBounds();
/* 50 */       ValueBounds index = ((ArgumentBounds)arguments.get(1)).getBounds();
/*    */       
/* 52 */       if (TypeSet.isDefinitelyNumeric(index) && index
/* 53 */         .isLengthConstant() && index
/* 54 */         .getLength() == 1) {
/*    */         
/* 56 */         if (source.getTypeSet() == 2) {
/* 57 */           return new GetListElement(source, index);
/*    */         }
/* 59 */         if (TypeSet.isDefinitelyAtomic(source.getTypeSet())) {
/* 60 */           return new GetAtomicElement(source, index);
/*    */         }
/*    */       } 
/*    */ 
/*    */       
/* 65 */       throw new UnsupportedOperationException("TODO");
/*    */     } 
/*    */     
/* 68 */     return UnspecializedCall.INSTANCE;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/builtins/SingleSubsetSpecializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */