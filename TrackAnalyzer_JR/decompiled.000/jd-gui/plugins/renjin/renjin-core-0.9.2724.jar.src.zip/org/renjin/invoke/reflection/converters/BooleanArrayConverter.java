/*    */ package org.renjin.invoke.reflection.converters;
/*    */ 
/*    */ import org.renjin.eval.EvalException;
/*    */ import org.renjin.sexp.LogicalArrayVector;
/*    */ import org.renjin.sexp.LogicalVector;
/*    */ import org.renjin.sexp.SEXP;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BooleanArrayConverter
/*    */   implements Converter<Boolean[]>
/*    */ {
/* 33 */   public static final BooleanArrayConverter INSTANCE = new BooleanArrayConverter();
/*    */   
/*    */   public static boolean accept(Class clazz) {
/* 36 */     return (clazz.isArray() && (clazz.getComponentType() == Boolean.class || clazz.getComponentType() == boolean.class));
/*    */   }
/*    */ 
/*    */   
/*    */   public LogicalVector convertToR(Boolean[] value) {
/* 41 */     if (value == null) {
/* 42 */       return (LogicalVector)new LogicalArrayVector(new int[] { LogicalVector.NA });
/*    */     }
/* 44 */     return (LogicalVector)new LogicalArrayVector(value);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Object convertToJava(SEXP value) {
/* 50 */     if (!(value instanceof org.renjin.sexp.AtomicVector))
/* 51 */       throw new EvalException("It's not an AtomicVector", new Object[] { value.getTypeName() }); 
/* 52 */     if (value.length() < 1)
/*    */     {
/* 54 */       return new Boolean[0];
/*    */     }
/* 56 */     LogicalVector lv = (LogicalVector)value;
/* 57 */     int length = lv.length();
/* 58 */     Boolean[] values = new Boolean[length];
/* 59 */     for (int i = 0; i < length; i++) {
/* 60 */       values[i] = lv.getElementAsObject(i);
/*    */     }
/* 62 */     return values;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean acceptsSEXP(SEXP exp) {
/* 67 */     return (exp instanceof LogicalVector && exp.length() >= 1);
/*    */   }
/*    */ 
/*    */   
/*    */   public int getSpecificity() {
/* 72 */     return 10;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/reflection/converters/BooleanArrayConverter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */