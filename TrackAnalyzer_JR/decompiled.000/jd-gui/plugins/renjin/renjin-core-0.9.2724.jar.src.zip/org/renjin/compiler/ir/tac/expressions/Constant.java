/*     */ package org.renjin.compiler.ir.tac.expressions;
/*     */ 
/*     */ import java.util.Map;
/*     */ import org.renjin.compiler.codegen.EmitContext;
/*     */ import org.renjin.compiler.ir.ValueBounds;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ import org.renjin.repackaged.asm.commons.InstructionAdapter;
/*     */ import org.renjin.sexp.AtomicVector;
/*     */ import org.renjin.sexp.IntVector;
/*     */ import org.renjin.sexp.Logical;
/*     */ import org.renjin.sexp.LogicalVector;
/*     */ import org.renjin.sexp.Null;
/*     */ import org.renjin.sexp.SEXP;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Constant
/*     */   implements SimpleExpression
/*     */ {
/*  35 */   public static final Constant NULL = new Constant((SEXP)Null.INSTANCE);
/*  36 */   public static final Constant TRUE = new Constant(Logical.TRUE);
/*  37 */   public static final Constant FALSE = new Constant(Logical.FALSE);
/*  38 */   public static final Constant NA = new Constant(Logical.NA);
/*     */   
/*     */   private SEXP value;
/*     */   private ValueBounds valueBounds;
/*     */   private Type type;
/*     */   
/*     */   public Constant(SEXP value) {
/*  45 */     this.value = value;
/*  46 */     this.valueBounds = ValueBounds.of(value);
/*  47 */     this.type = this.valueBounds.storageType();
/*     */   }
/*     */   
/*     */   public Constant(int value) {
/*  51 */     this((SEXP)IntVector.valueOf(value));
/*     */   }
/*     */   
/*     */   public Constant(Logical value) {
/*  55 */     this(LogicalVector.valueOf(value));
/*     */   }
/*     */   
/*     */   public SEXP getValue() {
/*  59 */     return this.value;
/*     */   }
/*     */ 
/*     */   
/*     */   public final int getChildCount() {
/*  64 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public final Expression childAt(int index) {
/*  69 */     throw new IllegalArgumentException();
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean isPure() {
/*  74 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int load(EmitContext emitContext, InstructionAdapter mv) {
/*  79 */     if (this.type.equals(Type.INT_TYPE)) {
/*  80 */       mv.iconst(((AtomicVector)this.value).getElementAsInt(0));
/*     */     }
/*  82 */     else if (this.type.equals(Type.DOUBLE_TYPE)) {
/*  83 */       mv.dconst(((AtomicVector)this.value).getElementAsDouble(0));
/*     */     }
/*  85 */     else if (this.type.equals(Type.getType(String.class))) {
/*  86 */       mv.aconst(((AtomicVector)this.value).getElementAsString(0));
/*     */     }
/*  88 */     else if (this.type.equals(Type.getType(SEXP.class))) {
/*  89 */       if (this.value == Null.INSTANCE) {
/*  90 */         mv.getstatic(Type.getInternalName(Null.class), "INSTANCE", Type.getDescriptor(Null.class));
/*     */       } else {
/*  92 */         throw new UnsupportedOperationException("const sexp: " + this.value.getClass().getName());
/*     */       } 
/*     */     } else {
/*  95 */       throw new UnsupportedOperationException("type: " + this.type);
/*     */     } 
/*  97 */     return 1;
/*     */   }
/*     */ 
/*     */   
/*     */   public Type getType() {
/* 102 */     return this.type;
/*     */   }
/*     */ 
/*     */   
/*     */   public final void setChild(int i, Expression expr) {
/* 107 */     throw new IllegalArgumentException();
/*     */   }
/*     */ 
/*     */   
/*     */   public ValueBounds updateTypeBounds(Map<Expression, ValueBounds> typeMap) {
/* 112 */     return this.valueBounds;
/*     */   }
/*     */ 
/*     */   
/*     */   public ValueBounds getValueBounds() {
/* 117 */     return this.valueBounds;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 122 */     return this.value.toString();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/ir/tac/expressions/Constant.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */