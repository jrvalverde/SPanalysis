/*    */ package org.renjin.compiler.codegen;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.renjin.compiler.TypeSolver;
/*    */ import org.renjin.compiler.ir.ValueBounds;
/*    */ import org.renjin.compiler.ir.tac.expressions.LValue;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VariableSlots
/*    */ {
/* 33 */   private final Map<LValue, VariableStorage> storage = new HashMap<>();
/*    */   private final int firstSlot;
/* 35 */   private int nextSlot = 0;
/*    */ 
/*    */   
/*    */   public VariableSlots(int parameterSize, TypeSolver types) {
/* 39 */     this.firstSlot = parameterSize;
/*    */     
/* 41 */     for (Map.Entry<LValue, ValueBounds> entry : (Iterable<Map.Entry<LValue, ValueBounds>>)types.getVariables().entrySet()) {
/* 42 */       LValue variable = entry.getKey();
/* 43 */       ValueBounds bounds = entry.getValue();
/*    */ 
/*    */       
/* 46 */       if (bounds != null) {
/* 47 */         this.storage.put(variable, new VariableStorage(this.firstSlot + this.nextSlot, bounds.storageType()));
/* 48 */         this.nextSlot += variable.getType().getSize();
/*    */       } 
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 55 */     StringBuilder s = new StringBuilder();
/* 56 */     for (Map.Entry<LValue, VariableStorage> entry : this.storage.entrySet()) {
/* 57 */       s.append(entry.getKey()).append(" => ").append(entry.getValue()).append("\n");
/*    */     }
/* 59 */     return s.toString();
/*    */   }
/*    */   
/*    */   public int getNumLocals() {
/* 63 */     return this.nextSlot;
/*    */   }
/*    */   
/*    */   public int getSlot(LValue lValue) {
/* 67 */     return ((VariableStorage)this.storage.get(lValue)).getSlotIndex();
/*    */   }
/*    */   
/*    */   public VariableStorage getStorage(LValue lhs) {
/* 71 */     return this.storage.get(lhs);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/codegen/VariableSlots.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */