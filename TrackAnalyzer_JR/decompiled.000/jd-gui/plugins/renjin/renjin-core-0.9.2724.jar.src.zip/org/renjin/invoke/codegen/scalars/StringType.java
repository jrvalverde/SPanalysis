/*    */ package org.renjin.invoke.codegen.scalars;
/*    */ 
/*    */ import com.sun.codemodel.JCodeModel;
/*    */ import com.sun.codemodel.JExpr;
/*    */ import com.sun.codemodel.JExpression;
/*    */ import com.sun.codemodel.JVar;
/*    */ import org.renjin.invoke.model.JvmMethod;
/*    */ import org.renjin.sexp.StringArrayVector;
/*    */ import org.renjin.sexp.StringVector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StringType
/*    */   extends ScalarType
/*    */ {
/*    */   public Class getScalarType() {
/* 33 */     return String.class;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getConversionMethod() {
/* 38 */     return "convertToString";
/*    */   }
/*    */ 
/*    */   
/*    */   public String getAccessorMethod() {
/* 43 */     return "getElementAsString";
/*    */   }
/*    */ 
/*    */   
/*    */   public Class getVectorType() {
/* 48 */     return StringVector.class;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public JExpression testExpr(JCodeModel codeModel, JVar sexpVariable, JvmMethod.Argument formal) {
/* 54 */     JExpression vectorTest = super.testExpr(codeModel, sexpVariable, formal);
/* 55 */     return vectorTest;
/*    */   }
/*    */ 
/*    */   
/*    */   public JExpression naLiteral(JCodeModel codeModel) {
/* 60 */     return JExpr._null();
/*    */   }
/*    */ 
/*    */   
/*    */   public Class<StringVector.Builder> getBuilderClass() {
/* 65 */     return StringVector.Builder.class;
/*    */   }
/*    */ 
/*    */   
/*    */   public Class getBuilderArrayElementClass() {
/* 70 */     return String.class;
/*    */   }
/*    */ 
/*    */   
/*    */   public Class getArrayVectorClass() {
/* 75 */     return StringArrayVector.class;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/codegen/scalars/StringType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */