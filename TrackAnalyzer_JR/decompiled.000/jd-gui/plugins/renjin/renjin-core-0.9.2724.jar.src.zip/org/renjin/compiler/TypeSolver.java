/*     */ package org.renjin.compiler;
/*     */ 
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import org.renjin.compiler.cfg.BasicBlock;
/*     */ import org.renjin.compiler.cfg.ControlFlowGraph;
/*     */ import org.renjin.compiler.cfg.FlowEdge;
/*     */ import org.renjin.compiler.cfg.SsaEdge;
/*     */ import org.renjin.compiler.cfg.UseDefMap;
/*     */ import org.renjin.compiler.ir.ValueBounds;
/*     */ import org.renjin.compiler.ir.exception.InvalidSyntaxException;
/*     */ import org.renjin.compiler.ir.ssa.PhiFunction;
/*     */ import org.renjin.compiler.ir.ssa.SsaVariable;
/*     */ import org.renjin.compiler.ir.tac.RuntimeState;
/*     */ import org.renjin.compiler.ir.tac.expressions.EnvironmentVariable;
/*     */ import org.renjin.compiler.ir.tac.expressions.Expression;
/*     */ import org.renjin.compiler.ir.tac.expressions.LValue;
/*     */ import org.renjin.compiler.ir.tac.expressions.NullExpression;
/*     */ import org.renjin.compiler.ir.tac.expressions.Variable;
/*     */ import org.renjin.compiler.ir.tac.statements.Assignment;
/*     */ import org.renjin.compiler.ir.tac.statements.IfStatement;
/*     */ import org.renjin.compiler.ir.tac.statements.Statement;
/*     */ import org.renjin.repackaged.guava.collect.Maps;
/*     */ import org.renjin.repackaged.guava.collect.Sets;
/*     */ import org.renjin.sexp.Function;
/*     */ import org.renjin.sexp.Logical;
/*     */ import org.renjin.sexp.Symbol;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypeSolver
/*     */ {
/*     */   private final ControlFlowGraph cfg;
/*     */   private UseDefMap useDefMap;
/*  64 */   private final ArrayDeque<FlowEdge> flowWorkList = new ArrayDeque<>();
/*  65 */   private final ArrayDeque<SsaEdge> ssaWorkList = new ArrayDeque<>();
/*     */   
/*  67 */   private static final ValueBounds TOP = null;
/*     */   
/*  69 */   private final Map<Expression, ValueBounds> variableBounds = Maps.newHashMap();
/*     */   
/*  71 */   private final Map<IfStatement, ValueBounds> conditionalBounds = Maps.newHashMap();
/*     */   
/*  73 */   private final Set<FlowEdge> executable = Sets.newHashSet();
/*     */   
/*     */   public TypeSolver(ControlFlowGraph cfg, UseDefMap useDefMap) {
/*  76 */     this.cfg = cfg;
/*  77 */     this.useDefMap = useDefMap;
/*     */   }
/*     */   
/*     */   public boolean isDefined(LValue variable) {
/*  81 */     return this.useDefMap.isDefined(variable);
/*     */   }
/*     */   
/*     */   public boolean isUsed(Assignment assignment) {
/*  85 */     return isUsed(assignment.getLHS());
/*     */   }
/*     */   
/*     */   public boolean isUsed(LValue variable) {
/*  89 */     return this.useDefMap.isUsed(variable);
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<LValue, ValueBounds> getVariables() {
/*  94 */     Map<LValue, ValueBounds> map = new HashMap<>();
/*  95 */     for (LValue variable : this.useDefMap.getUsedVariables()) {
/*  96 */       map.put(variable, this.variableBounds.get(variable));
/*     */     }
/*  98 */     return map;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void execute() {
/* 104 */     this.executable.clear();
/* 105 */     for (BasicBlock basicBlock : this.cfg.getBasicBlocks()) {
/* 106 */       basicBlock.setLive(false);
/*     */     }
/* 108 */     this.conditionalBounds.clear();
/* 109 */     this.flowWorkList.clear();
/* 110 */     this.ssaWorkList.clear();
/*     */ 
/*     */ 
/*     */     
/* 114 */     for (FlowEdge flowEdge : this.cfg.getEntry().getOutgoing()) {
/* 115 */       if (flowEdge.getSuccessor() != this.cfg.getExit()) {
/* 116 */         this.flowWorkList.add(flowEdge);
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 123 */     while (!this.flowWorkList.isEmpty() || !this.ssaWorkList.isEmpty()) {
/*     */ 
/*     */       
/* 126 */       while (!this.flowWorkList.isEmpty()) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 132 */         FlowEdge edge = this.flowWorkList.pop();
/* 133 */         if (!this.executable.contains(edge)) {
/* 134 */           BasicBlock node = edge.getSuccessor();
/* 135 */           node.setLive(true);
/*     */ 
/*     */           
/* 138 */           this.executable.add(edge);
/*     */ 
/*     */ 
/*     */           
/* 142 */           for (Assignment phiAssignment : node.phiAssignments()) {
/* 143 */             visitPhi(phiAssignment);
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 151 */           if (countIncomingExecutableEdges(node) == 1) {
/* 152 */             for (Statement statement : node.getStatements()) {
/* 153 */               if (statement.getRHS() != NullExpression.INSTANCE && 
/* 154 */                 !(statement.getRHS() instanceof PhiFunction)) {
/* 155 */                 visitExpression(node, statement);
/*     */               }
/*     */             } 
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 163 */           if (node.getOutgoing().size() == 1) {
/* 164 */             this.flowWorkList.addAll(node.getOutgoing());
/*     */           }
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 170 */       while (!this.ssaWorkList.isEmpty()) {
/*     */         
/* 172 */         SsaEdge edge = this.ssaWorkList.pop();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 182 */         if (edge.isPhiFunction()) {
/* 183 */           visitPhi((Assignment)edge.getDestinationStatement()); continue;
/*     */         } 
/* 185 */         if (countIncomingExecutableEdges(edge.getDestinationNode()) > 0) {
/* 186 */           visitExpression(edge.getDestinationNode(), edge.getDestinationStatement());
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void visitPhi(Assignment assignment) {
/* 194 */     PhiFunction phiFunction = (PhiFunction)assignment.getRHS();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 204 */     List<ValueBounds> boundSet = new ArrayList<>();
/* 205 */     for (int i = 0; i < phiFunction.getIncomingEdges().size(); i++) {
/* 206 */       FlowEdge incomingEdge = phiFunction.getIncomingEdges().get(i);
/* 207 */       if (this.executable.contains(incomingEdge)) {
/* 208 */         Variable ssaVariable = phiFunction.getArgument(i);
/* 209 */         ValueBounds value = this.variableBounds.get(ssaVariable);
/* 210 */         if (value != TOP) {
/* 211 */           boundSet.add(value);
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 216 */     if (!boundSet.isEmpty()) {
/* 217 */       maybeUpdateLhs(assignment, ValueBounds.union(boundSet));
/*     */     }
/*     */   }
/*     */   
/*     */   public void dumpBounds() {
/* 222 */     for (Expression expression : this.variableBounds.keySet()) {
/* 223 */       if (expression instanceof LValue) {
/* 224 */         System.out.println(expression + " => " + this.variableBounds.get(expression));
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean isPure() {
/* 230 */     Set<BasicBlock> checked = Sets.newHashSet();
/* 231 */     for (FlowEdge flowEdge : this.executable) {
/* 232 */       BasicBlock basicBlock = flowEdge.getSuccessor();
/* 233 */       if (checked.add(basicBlock) && 
/* 234 */         !basicBlock.isPure()) {
/* 235 */         return false;
/*     */       }
/*     */     } 
/*     */     
/* 239 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void visitExpression(BasicBlock block, Statement statement) {
/* 249 */     Expression expression = statement.getRHS();
/* 250 */     ValueBounds newBounds = expression.updateTypeBounds(this.variableBounds);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 257 */     if (statement instanceof Assignment) {
/* 258 */       maybeUpdateLhs((Assignment)statement, newBounds);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 267 */     if (statement instanceof IfStatement) {
/* 268 */       IfStatement conditional = (IfStatement)statement;
/* 269 */       ValueBounds oldBounds = this.conditionalBounds.get(conditional);
/*     */       
/* 271 */       if (!Objects.equals(oldBounds, newBounds)) {
/*     */         
/* 273 */         this.conditionalBounds.put(conditional, newBounds);
/*     */         
/* 275 */         if (newBounds.isConstant()) {
/*     */           
/* 277 */           Logical conditionValue = newBounds.getConstantValue().asLogical();
/* 278 */           if (conditionValue == Logical.NA) {
/* 279 */             throw new InvalidSyntaxException("missing value where TRUE/FALSE needed");
/*     */           }
/*     */           
/* 282 */           conditional.setConstantValue(conditionValue);
/* 283 */           if (conditionValue == Logical.TRUE) {
/* 284 */             this.flowWorkList.add(block.getOutgoing(conditional.getTrueTarget()));
/*     */           } else {
/* 286 */             this.flowWorkList.add(block.getOutgoing(conditional.getFalseTarget()));
/*     */           }
/*     */         
/*     */         } else {
/*     */           
/* 291 */           conditional.setConstantValue(null);
/* 292 */           this.flowWorkList.add(block.getOutgoing(conditional.getTrueTarget()));
/* 293 */           this.flowWorkList.add(block.getOutgoing(conditional.getFalseTarget()));
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void maybeUpdateLhs(Assignment assignment, ValueBounds newBounds) {
/* 301 */     ValueBounds oldBounds = this.variableBounds.put(assignment.getLHS(), newBounds);
/*     */     
/* 303 */     if (!Objects.equals(oldBounds, newBounds)) {
/* 304 */       assignment.getLHS().update(newBounds);
/* 305 */       this.variableBounds.put(assignment.getLHS(), newBounds);
/*     */       
/* 307 */       Collection<SsaEdge> outgoingEdges = this.useDefMap.getSsaEdges(assignment.getLHS());
/*     */       
/* 309 */       this.ssaWorkList.addAll(outgoingEdges);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int countIncomingExecutableEdges(BasicBlock block) {
/* 315 */     int count = 0;
/* 316 */     for (FlowEdge flowEdge : block.getIncoming()) {
/* 317 */       if (this.executable.contains(flowEdge)) {
/* 318 */         count++;
/*     */       }
/*     */     } 
/* 321 */     return count;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void verifyFunctionAssumptions(RuntimeState runtimeState) {
/* 331 */     Map<Symbol, Function> resolvedFunctions = runtimeState.getResolvedFunctions();
/*     */     
/* 333 */     for (Map.Entry<Expression, ValueBounds> entry : this.variableBounds.entrySet()) {
/* 334 */       if (entry.getKey() instanceof SsaVariable) {
/* 335 */         SsaVariable lhs = (SsaVariable)entry.getKey();
/* 336 */         if (lhs.getInner() instanceof EnvironmentVariable) {
/* 337 */           EnvironmentVariable variable = (EnvironmentVariable)lhs.getInner();
/* 338 */           if (resolvedFunctions.containsKey(variable.getName())) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 346 */             Function resolvedFunction = resolvedFunctions.get(variable.getName());
/* 347 */             checkPotentialFunctionAssignment(variable, entry.getValue(), resolvedFunction);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkPotentialFunctionAssignment(EnvironmentVariable variable, ValueBounds bounds, Function resolvedFunction) {
/* 371 */     if ((bounds.getTypeSet() & 0x400) == 0) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 378 */     if (bounds.isConstant() && 
/* 379 */       bounds.getConstantValue() == resolvedFunction) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 386 */     throw new NotCompilableException(variable.getName(), "change to function definition");
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/TypeSolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */