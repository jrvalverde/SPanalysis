/*    */ package org.renjin.invoke.codegen.generic;
/*    */ 
/*    */ import com.sun.codemodel.JBlock;
/*    */ import com.sun.codemodel.JCodeModel;
/*    */ import com.sun.codemodel.JExpr;
/*    */ import com.sun.codemodel.JExpression;
/*    */ import com.sun.codemodel.JInvocation;
/*    */ import com.sun.codemodel.JType;
/*    */ import com.sun.codemodel.JVar;
/*    */ import java.util.List;
/*    */ import org.renjin.invoke.codegen.ApplyMethodContext;
/*    */ import org.renjin.primitives.Types;
/*    */ import org.renjin.s4.S4;
/*    */ import org.renjin.sexp.SEXP;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MatrixMultDispatchStrategy
/*    */   extends GenericDispatchStrategy
/*    */ {
/*    */   public MatrixMultDispatchStrategy(JCodeModel codeModel) {
/* 35 */     super(codeModel);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void beforeTypeMatching(ApplyMethodContext context, JExpression functionCall, List<JExpression> arguments, JBlock parent) {
/* 54 */     JInvocation dispatchInvocation = this.codeModel.ref(S4.class).staticInvoke("tryS4DispatchFromPrimitive").arg(context.getContext()).arg(arguments.get(0)).arg((JExpression)functionCall.invoke("getArguments")).arg(context.getEnvironment()).arg(JExpr._null()).arg(JExpr.lit("%*%"));
/*    */ 
/*    */     
/* 57 */     JBlock ifObjects = parent._if(anyS4(arguments))._then();
/* 58 */     JVar dispatchResult = ifObjects.decl((JType)this.codeModel.ref(SEXP.class), "genericResult", (JExpression)dispatchInvocation);
/* 59 */     ifObjects._if(dispatchResult.ne(JExpr._null()))._then()._return((JExpression)dispatchResult);
/*    */   }
/*    */   
/*    */   private JExpression anyS4(List<JExpression> arguments) {
/* 63 */     if (arguments.size() == 1)
/* 64 */       return (JExpression)isS4(arguments.get(0)); 
/* 65 */     if (arguments.size() == 2) {
/* 66 */       return isS4(arguments.get(0)).cor((JExpression)isS4(arguments.get(1)));
/*    */     }
/* 68 */     throw new UnsupportedOperationException("n arguments = " + arguments.size());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected JInvocation isS4(JExpression argument) {
/* 75 */     return this.codeModel.ref(Types.class).staticInvoke("isS4").arg(argument);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/codegen/generic/MatrixMultDispatchStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */