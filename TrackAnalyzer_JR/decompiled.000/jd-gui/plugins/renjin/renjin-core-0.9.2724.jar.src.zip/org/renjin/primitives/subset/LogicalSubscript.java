/*     */ package org.renjin.primitives.subset;
/*     */ 
/*     */ import org.renjin.eval.EvalException;
/*     */ import org.renjin.sexp.IntVector;
/*     */ import org.renjin.sexp.LogicalVector;
/*     */ import org.renjin.sexp.SEXP;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class LogicalSubscript
/*     */   implements Subscript
/*     */ {
/*     */   private LogicalVector subscript;
/*     */   private int resultLength;
/*     */   
/*     */   public LogicalSubscript(LogicalVector subscript, int sourceLength) {
/*  34 */     this.subscript = subscript;
/*  35 */     this.resultLength = Math.max(sourceLength, subscript.length());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int computeUniqueIndex() {
/*  41 */     SubsetAssertions.checkUnitLength((SEXP)this.subscript);
/*     */     
/*  43 */     int oneBasedIndex = this.subscript.getElementAsInt(0);
/*  44 */     if (IntVector.isNA(oneBasedIndex)) {
/*  45 */       throw new EvalException("subscript out of bounds", new Object[0]);
/*     */     }
/*  47 */     if (oneBasedIndex == 0) {
/*  48 */       throw new EvalException("attempt to select less than one element", new Object[0]);
/*     */     }
/*     */     
/*  51 */     return oneBasedIndex - 1;
/*     */   }
/*     */ 
/*     */   
/*     */   public IndexIterator computeIndexes() {
/*  56 */     if (this.subscript.length() == 0) {
/*  57 */       return EmptyIndexIterator.INSTANCE;
/*     */     }
/*  59 */     return new Iterator();
/*     */   }
/*     */ 
/*     */   
/*     */   public IndexPredicate computeIndexPredicate() {
/*  64 */     return new LogicalPredicate(this.subscript);
/*     */   }
/*     */ 
/*     */   
/*     */   public int computeCount() {
/*  69 */     if (this.subscript.length() == 0) {
/*  70 */       return 0;
/*     */     }
/*  72 */     if (this.subscript.length() < this.resultLength && this.resultLength % this.subscript
/*  73 */       .length() == 0) {
/*     */       
/*  75 */       int i = countSelected();
/*  76 */       int recycledCount = i * this.resultLength / this.subscript.length();
/*  77 */       return recycledCount;
/*     */     } 
/*     */     
/*  80 */     int count = 0;
/*  81 */     IndexIterator it = computeIndexes();
/*  82 */     while (it.next() != -1) {
/*  83 */       count++;
/*     */     }
/*  85 */     return count;
/*     */   }
/*     */   
/*     */   private int countSelected() {
/*  89 */     int count = 0;
/*  90 */     for (int i = 0; i < this.subscript.length(); i++) {
/*  91 */       int value = this.subscript.getElementAsRawLogical(i);
/*  92 */       if (value != 0) {
/*  93 */         count++;
/*     */       }
/*     */     } 
/*  96 */     return count;
/*     */   }
/*     */   
/*     */   private class Iterator
/*     */     implements IndexIterator {
/* 101 */     int nextIndex = 0;
/*     */ 
/*     */     
/*     */     public int next() {
/*     */       while (true) {
/* 106 */         if (this.nextIndex >= LogicalSubscript.this.resultLength) {
/* 107 */           return -1;
/*     */         }
/* 109 */         int sourceIndex = this.nextIndex++;
/* 110 */         int subscriptValue = LogicalSubscript.this.subscript.getElementAsRawLogical(sourceIndex % LogicalSubscript.this.subscript.length());
/* 111 */         if (subscriptValue == 1) {
/* 112 */           return sourceIndex;
/*     */         }
/* 114 */         if (IntVector.isNA(subscriptValue)) {
/* 115 */           return Integer.MIN_VALUE;
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void restart() {
/* 122 */       this.nextIndex = 0;
/*     */     }
/*     */     
/*     */     private Iterator() {}
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/subset/LogicalSubscript.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */