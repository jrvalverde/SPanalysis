package org.renjin.primitives.matrix;

import java.util.Collection;
import org.renjin.sexp.Vector;

public interface MatrixBuilder {
  void setRowNames(Vector paramVector);
  
  void setRowNames(Collection<String> paramCollection);
  
  void setColNames(Vector paramVector);
  
  void setColNames(Collection<String> paramCollection);
  
  int getRows();
  
  int getCols();
  
  void setValue(int paramInt1, int paramInt2, double paramDouble);
  
  void setValue(int paramInt1, int paramInt2, int paramInt3);
  
  Vector build();
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/matrix/MatrixBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */