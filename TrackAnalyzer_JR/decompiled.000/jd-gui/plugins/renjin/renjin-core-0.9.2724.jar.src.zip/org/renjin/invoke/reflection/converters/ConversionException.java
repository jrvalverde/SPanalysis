package org.renjin.invoke.reflection.converters;

public class ConversionException extends RuntimeException {}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/reflection/converters/ConversionException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */