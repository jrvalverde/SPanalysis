/*    */ package org.renjin.invoke.codegen.scalars;
/*    */ 
/*    */ import com.sun.codemodel.JCodeModel;
/*    */ import com.sun.codemodel.JExpr;
/*    */ import com.sun.codemodel.JExpression;
/*    */ import com.sun.codemodel.JOp;
/*    */ import com.sun.codemodel.JType;
/*    */ import com.sun.codemodel.JVar;
/*    */ import org.renjin.invoke.model.JvmMethod;
/*    */ import org.renjin.sexp.IntVector;
/*    */ import org.renjin.sexp.LogicalArrayVector;
/*    */ import org.renjin.sexp.LogicalVector;
/*    */ import org.renjin.sexp.Vector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BooleanType
/*    */   extends ScalarType
/*    */ {
/*    */   public Class getScalarType() {
/* 32 */     return boolean.class;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getConversionMethod() {
/* 37 */     return "convertToBooleanPrimitive";
/*    */   }
/*    */ 
/*    */   
/*    */   public String getAccessorMethod() {
/* 42 */     return "getElementAsRawLogical";
/*    */   }
/*    */ 
/*    */   
/*    */   public Class getVectorType() {
/* 47 */     return LogicalVector.class;
/*    */   }
/*    */ 
/*    */   
/*    */   public Class<LogicalArrayVector.Builder> getBuilderClass() {
/* 52 */     return LogicalArrayVector.Builder.class;
/*    */   }
/*    */ 
/*    */   
/*    */   public Class getBuilderArrayElementClass() {
/* 57 */     return int.class;
/*    */   }
/*    */ 
/*    */   
/*    */   public Class getArrayVectorClass() {
/* 62 */     return LogicalArrayVector.class;
/*    */   }
/*    */ 
/*    */   
/*    */   public JExpression toBuildArrayElementType(JExpression resultValue) {
/* 67 */     return JOp.cond(resultValue, JExpr.lit(1), JExpr.lit(0));
/*    */   }
/*    */ 
/*    */   
/*    */   public JExpression testExpr(JCodeModel codeModel, JVar sexpVariable, JvmMethod.Argument formal) {
/* 72 */     return sexpVariable._instanceof((JType)codeModel.ref(Vector.class));
/*    */   }
/*    */ 
/*    */   
/*    */   public JExpression naLiteral(JCodeModel codeModel) {
/* 77 */     return (JExpression)codeModel.ref(IntVector.class).staticRef("NA");
/*    */   }
/*    */ 
/*    */   
/*    */   public Class<?> getElementStorageType() {
/* 82 */     return int.class;
/*    */   }
/*    */ 
/*    */   
/*    */   public JExpression fromElementStorageType(JExpression expression) {
/* 87 */     return expression.ne(JExpr.lit(0));
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/codegen/scalars/BooleanType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */