/*     */ package org.renjin.compiler.ir.tac.statements;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import org.renjin.compiler.codegen.EmitContext;
/*     */ import org.renjin.compiler.codegen.VariableStorage;
/*     */ import org.renjin.compiler.ir.tac.IRLabel;
/*     */ import org.renjin.compiler.ir.tac.expressions.Expression;
/*     */ import org.renjin.compiler.ir.tac.expressions.LValue;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ import org.renjin.repackaged.asm.commons.InstructionAdapter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Assignment
/*     */   implements Statement
/*     */ {
/*     */   private LValue lhs;
/*     */   private Expression rhs;
/*     */   
/*     */   public Assignment(LValue lhs, Expression rhs) {
/*  39 */     this.lhs = lhs;
/*  40 */     this.rhs = rhs;
/*     */   }
/*     */   
/*     */   public LValue getLHS() {
/*  44 */     return this.lhs;
/*     */   }
/*     */ 
/*     */   
/*     */   public Expression getRHS() {
/*  49 */     return this.rhs;
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterable<IRLabel> possibleTargets() {
/*  54 */     return Collections.emptySet();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRHS(Expression newRHS) {
/*  60 */     this.rhs = newRHS;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  65 */     return getLHS() + " " + "←" + " " + this.rhs;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getChildCount() {
/*  70 */     return 1;
/*     */   }
/*     */ 
/*     */   
/*     */   public Expression childAt(int index) {
/*  75 */     if (index == 0) {
/*  76 */       return this.rhs;
/*     */     }
/*  78 */     throw new IllegalArgumentException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setChild(int childIndex, Expression child) {
/*  84 */     if (childIndex == 0) {
/*  85 */       this.rhs = child;
/*     */     } else {
/*  87 */       throw new IllegalArgumentException("childIndex=" + childIndex);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void accept(StatementVisitor visitor) {
/*  93 */     visitor.visitAssignment(this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int emit(EmitContext emitContext, InstructionAdapter mv) {
/*     */     Type rhsType;
/* 100 */     VariableStorage storage = emitContext.getVariableStorage(this.lhs);
/* 101 */     if (storage == null)
/*     */     {
/* 103 */       return 0;
/*     */     }
/*     */ 
/*     */     
/* 107 */     if (this.rhs instanceof LValue) {
/* 108 */       rhsType = emitContext.getVariableStorage((LValue)this.rhs).getType();
/*     */     } else {
/* 110 */       rhsType = this.rhs.getType();
/*     */     } 
/*     */     
/* 113 */     int stackIncrease = this.rhs.load(emitContext, mv);
/* 114 */     emitContext.convert(mv, rhsType, storage.getType());
/* 115 */     mv.visitVarInsn(storage.getType().getOpcode(54), storage.getSlotIndex());
/* 116 */     return stackIncrease;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPure() {
/* 121 */     return this.rhs.isPure();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setLHS(LValue lhs) {
/* 126 */     this.lhs = lhs;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/ir/tac/statements/Assignment.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */