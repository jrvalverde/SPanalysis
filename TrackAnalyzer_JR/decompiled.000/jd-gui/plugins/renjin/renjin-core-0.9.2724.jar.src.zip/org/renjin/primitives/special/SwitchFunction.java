/*     */ package org.renjin.primitives.special;
/*     */ 
/*     */ import org.renjin.eval.Context;
/*     */ import org.renjin.eval.EvalException;
/*     */ import org.renjin.invoke.codegen.ArgumentIterator;
/*     */ import org.renjin.sexp.AtomicVector;
/*     */ import org.renjin.sexp.Environment;
/*     */ import org.renjin.sexp.FunctionCall;
/*     */ import org.renjin.sexp.IntVector;
/*     */ import org.renjin.sexp.Null;
/*     */ import org.renjin.sexp.PairList;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.SpecialFunction;
/*     */ import org.renjin.sexp.StringVector;
/*     */ import org.renjin.sexp.Symbol;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SwitchFunction
/*     */   extends SpecialFunction
/*     */ {
/*     */   public SwitchFunction() {
/*  29 */     super("switch");
/*     */   }
/*     */ 
/*     */   
/*     */   public SEXP apply(Context context, Environment rho, FunctionCall call, PairList args) {
/*  34 */     return doApply(context, rho, call, args);
/*     */   }
/*     */ 
/*     */   
/*     */   private static SEXP doApply(Context context, Environment rho, FunctionCall call, PairList args) {
/*  39 */     ArgumentIterator argIt = new ArgumentIterator(context, rho, args);
/*  40 */     if (!argIt.hasNext()) {
/*  41 */       throw new EvalException("argument \"EXPR\" is missing", new Object[0]);
/*     */     }
/*     */     
/*  44 */     PairList.Node exprNode = argIt.nextNode();
/*  45 */     if (exprNode.hasTag() && !"EXPR".startsWith(exprNode.getTag().getPrintName())) {
/*  46 */       throw new EvalException("supplied argument name '%s' does not match 'EXPR'", new Object[] { exprNode.getTag().getPrintName() });
/*     */     }
/*     */     
/*  49 */     SEXP expr = context.evaluate(exprNode.getValue(), rho);
/*     */     
/*  51 */     if (expr.length() == 1) {
/*  52 */       if (expr instanceof StringVector)
/*  53 */         return matchByName(context, rho, expr, argIt); 
/*  54 */       if (expr instanceof AtomicVector) {
/*  55 */         return matchByPosition(context, rho, expr, argIt);
/*     */       }
/*     */     } 
/*  58 */     throw new EvalException("EXPR must be a length 1 vector", new Object[0]);
/*     */   }
/*     */   
/*     */   private static SEXP matchByName(Context context, Environment rho, SEXP expr, ArgumentIterator argIt) {
/*  62 */     String name = expr.asString();
/*  63 */     if (StringVector.isNA(name)) {
/*  64 */       name = "NA";
/*     */     }
/*     */     
/*  67 */     while (argIt.hasNext()) {
/*  68 */       PairList.Node argNode = argIt.nextNode();
/*     */ 
/*     */       
/*  71 */       if (argNode.hasTag() && argNode.getTag().getPrintName().equals(name)) {
/*     */ 
/*     */ 
/*     */         
/*  75 */         while (argNode.getValue() == Symbol.MISSING_ARG && argIt.hasNext()) {
/*  76 */           argNode = argIt.nextNode();
/*     */         }
/*     */ 
/*     */         
/*  80 */         return context.evaluate(argNode.getValue(), rho);
/*     */       } 
/*     */ 
/*     */       
/*  84 */       if (!argNode.hasTag() && !argIt.hasNext()) {
/*  85 */         return context.evaluate(argNode.getValue(), rho);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  90 */     return (SEXP)Null.INSTANCE;
/*     */   }
/*     */ 
/*     */   
/*     */   private static SEXP matchByPosition(Context context, Environment rho, SEXP expr, ArgumentIterator argIt) {
/*  95 */     int pos = ((AtomicVector)expr).getElementAsInt(0);
/*     */     
/*  97 */     if (!IntVector.isNA(pos) && pos > 0) {
/*  98 */       int argIndex = 1;
/*  99 */       while (argIt.hasNext()) {
/* 100 */         PairList.Node argNode = argIt.nextNode();
/* 101 */         if (argIndex == pos) {
/* 102 */           return context.evaluate(argNode.getValue(), rho);
/*     */         }
/* 104 */         argIndex++;
/*     */       } 
/*     */     } 
/*     */     
/* 108 */     return (SEXP)Null.INSTANCE;
/*     */   }
/*     */   
/*     */   public static SEXP matchAndApply(Context context, Environment rho, FunctionCall call, String[] argumentNames, SEXP[] arguments) {
/* 112 */     PairList.Builder args = new PairList.Builder();
/* 113 */     for (int i = 0; i != arguments.length; i++) {
/* 114 */       args.add(argumentNames[i], arguments[i]);
/*     */     }
/* 116 */     return doApply(context, rho, call, args.build());
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/special/SwitchFunction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */