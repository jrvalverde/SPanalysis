/*     */ package org.renjin.compiler.ir.tac;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.renjin.compiler.NotCompilableException;
/*     */ import org.renjin.compiler.ir.ValueBounds;
/*     */ import org.renjin.compiler.ir.exception.InvalidSyntaxException;
/*     */ import org.renjin.compiler.ir.tac.expressions.Constant;
/*     */ import org.renjin.compiler.ir.tac.expressions.EnvironmentVariable;
/*     */ import org.renjin.compiler.ir.tac.expressions.Expression;
/*     */ import org.renjin.compiler.ir.tac.expressions.LValue;
/*     */ import org.renjin.compiler.ir.tac.expressions.LocalVariable;
/*     */ import org.renjin.compiler.ir.tac.expressions.ReadEnvironment;
/*     */ import org.renjin.compiler.ir.tac.expressions.ReadLoopIt;
/*     */ import org.renjin.compiler.ir.tac.expressions.ReadParam;
/*     */ import org.renjin.compiler.ir.tac.expressions.SimpleExpression;
/*     */ import org.renjin.compiler.ir.tac.expressions.Temp;
/*     */ import org.renjin.compiler.ir.tac.functions.ForTranslator;
/*     */ import org.renjin.compiler.ir.tac.functions.FunctionCallTranslator;
/*     */ import org.renjin.compiler.ir.tac.functions.FunctionCallTranslators;
/*     */ import org.renjin.compiler.ir.tac.functions.LoopBodyContext;
/*     */ import org.renjin.compiler.ir.tac.functions.TranslationContext;
/*     */ import org.renjin.compiler.ir.tac.statements.Assignment;
/*     */ import org.renjin.compiler.ir.tac.statements.ExprStatement;
/*     */ import org.renjin.compiler.ir.tac.statements.GotoStatement;
/*     */ import org.renjin.compiler.ir.tac.statements.IfStatement;
/*     */ import org.renjin.compiler.ir.tac.statements.ReturnStatement;
/*     */ import org.renjin.compiler.ir.tac.statements.Statement;
/*     */ import org.renjin.repackaged.guava.collect.Lists;
/*     */ import org.renjin.repackaged.guava.collect.Maps;
/*     */ import org.renjin.sexp.Closure;
/*     */ import org.renjin.sexp.ExpressionVector;
/*     */ import org.renjin.sexp.Function;
/*     */ import org.renjin.sexp.FunctionCall;
/*     */ import org.renjin.sexp.Null;
/*     */ import org.renjin.sexp.PairList;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.Symbol;
/*     */ import org.renjin.sexp.Symbols;
/*     */ 
/*     */ public class IRBodyBuilder {
/*  44 */   private int nextTemp = 0;
/*  45 */   private int nextLabel = 0;
/*     */   
/*  47 */   private FunctionCallTranslators builders = new FunctionCallTranslators();
/*     */   
/*     */   private List<Statement> statements;
/*     */   private IRLabel currentLabel;
/*     */   private Map<IRLabel, Integer> labels;
/*  52 */   private Map<Symbol, EnvironmentVariable> variables = Maps.newHashMap();
/*     */   
/*     */   private RuntimeState runtimeContext;
/*     */   
/*  56 */   private Map<String, Integer> localVariableNames = Maps.newHashMap();
/*  57 */   private Set<Symbol> paramSet = new HashSet<>();
/*     */   
/*     */   public IRBodyBuilder(RuntimeState runtimeState) {
/*  60 */     this.runtimeContext = runtimeState;
/*     */   }
/*     */   
/*     */   public RuntimeState getRuntimeState() {
/*  64 */     return this.runtimeContext;
/*     */   }
/*     */ 
/*     */   
/*     */   public IRBody build(SEXP exp) {
/*  69 */     this.statements = Lists.newArrayList();
/*  70 */     this.labels = Maps.newHashMap();
/*     */     
/*  72 */     TranslationContext context = new TopLevelContext();
/*  73 */     Expression returnValue = translateExpression(context, exp);
/*     */     
/*  75 */     addStatement((Statement)new ReturnStatement(returnValue));
/*     */     
/*  77 */     removeRedundantJumps();
/*  78 */     insertVariableInitializations();
/*  79 */     updateVariableReturn();
/*     */     
/*  81 */     return new IRBody(this.statements, this.labels);
/*     */   }
/*     */   
/*     */   public IRBody buildLoopBody(FunctionCall call, SEXP sequence) {
/*  85 */     this.statements = Lists.newArrayList();
/*  86 */     this.labels = Maps.newHashMap();
/*     */     
/*  88 */     LocalVariable vector = newLocalVariable("elements");
/*  89 */     LocalVariable counter = newLocalVariable("i");
/*     */     
/*  91 */     this.statements.add(new Assignment((LValue)vector, (Expression)new ReadLoopVector(sequence)));
/*  92 */     this.statements.add(new Assignment((LValue)counter, (Expression)new ReadLoopIt()));
/*     */     
/*  94 */     LoopBodyContext bodyContext = new LoopBodyContext(this.runtimeContext);
/*     */     
/*  96 */     ForTranslator.buildLoop((TranslationContext)bodyContext, this, call, (Expression)vector, (LValue)counter);
/*     */     
/*  98 */     addStatement((Statement)new ReturnStatement((Expression)new Constant((SEXP)Null.INSTANCE)));
/*     */     
/* 100 */     removeRedundantJumps();
/* 101 */     insertVariableInitializations();
/* 102 */     updateVariableReturn();
/*     */     
/* 104 */     return new IRBody(this.statements, this.labels);
/*     */   }
/*     */ 
/*     */   
/*     */   public IRBody buildFunctionBody(Closure closure, Set<Symbol> suppliedArguments) {
/* 109 */     this.statements = Lists.newArrayList();
/* 110 */     this.labels = Maps.newHashMap();
/*     */ 
/*     */     
/* 113 */     for (PairList.Node node : closure.getFormals().nodes()) {
/* 114 */       this.paramSet.add(node.getTag());
/*     */     }
/*     */ 
/*     */     
/* 118 */     List<ReadParam> params = Lists.newArrayList();
/* 119 */     for (PairList.Node formal : closure.getFormals().nodes()) {
/* 120 */       if (suppliedArguments.contains(formal.getTag())) {
/* 121 */         ReadParam paramExpr = new ReadParam(formal.getTag());
/* 122 */         this.statements.add(new Assignment((LValue)new EnvironmentVariable(formal.getTag()), (Expression)paramExpr));
/* 123 */         params.add(paramExpr);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 130 */     for (PairList.Node formal : closure.getFormals().nodes()) {
/* 131 */       if (formal.getRawTag() != Symbols.ELLIPSES && 
/* 132 */         !suppliedArguments.contains(formal.getTag())) {
/* 133 */         SEXP defaultValue = formal.getValue();
/* 134 */         if (defaultValue == Symbol.MISSING_ARG) {
/* 135 */           throw new InvalidSyntaxException("argument '" + formal.getTag() + "' is missing, with no default");
/*     */         }
/* 137 */         if (!isConstant(defaultValue)) {
/* 138 */           throw new NotCompilableException(defaultValue, "argument '" + formal.getName() + "' has not been provided and has a default value with (potential) side effects.");
/*     */         }
/*     */         
/* 141 */         this.statements.add(new Assignment((LValue)new EnvironmentVariable(formal.getTag()), (Expression)new Constant(formal.getValue())));
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 147 */     TranslationContext context = new InlinedContext(closure.getFormals());
/* 148 */     Expression returnValue = translateExpression(context, closure.getBody());
/* 149 */     addStatement((Statement)new ReturnStatement(returnValue));
/*     */     
/* 151 */     removeRedundantJumps();
/* 152 */     insertVariableInitializations();
/*     */     
/* 154 */     IRBody body = new IRBody(this.statements, this.labels);
/* 155 */     body.setParams(params);
/* 156 */     return body;
/*     */   }
/*     */   
/*     */   private boolean isConstant(SEXP defaultValue) {
/* 160 */     return (!(defaultValue instanceof Symbol) && !(defaultValue instanceof ExpressionVector) && !(defaultValue instanceof FunctionCall));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateVariableReturn() {
/* 168 */     for (Statement statement : this.statements) {
/* 169 */       if (statement instanceof ReturnStatement) {
/* 170 */         ((ReturnStatement)statement).addEnvironmentVariables(this.variables.values());
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void insertVariableInitializations() {
/* 180 */     List<Assignment> initializations = new ArrayList<>();
/*     */     
/* 182 */     for (EnvironmentVariable environmentVariable : this.variables.values()) {
/* 183 */       if (!this.paramSet.contains(environmentVariable.getName())) {
/* 184 */         SEXP value = this.runtimeContext.findVariable(environmentVariable.getName());
/*     */         
/* 186 */         if (value != Symbol.UNBOUND_VALUE) {
/* 187 */           initializations.add(new Assignment((LValue)environmentVariable, (Expression)new ReadEnvironment(environmentVariable
/* 188 */                   .getName(), ValueBounds.of(value))));
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 194 */     this.statements.addAll(0, initializations);
/* 195 */     for (IRLabel label : this.labels.keySet()) {
/* 196 */       this.labels.put(label, Integer.valueOf(((Integer)this.labels.get(label)).intValue() + initializations.size()));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void dump(SEXP exp) {
/* 202 */     System.out.println(build(exp).toString());
/*     */   }
/*     */   
/*     */   public Expression translateExpression(TranslationContext context, SEXP exp) {
/* 206 */     if (exp instanceof ExpressionVector)
/* 207 */       return translateExpressionList(context, (ExpressionVector)exp); 
/* 208 */     if (exp instanceof Symbol) {
/* 209 */       if (exp == Symbol.MISSING_ARG) {
/* 210 */         return (Expression)new Constant(exp);
/*     */       }
/* 212 */       return (Expression)getEnvironmentVariable((Symbol)exp);
/*     */     } 
/* 214 */     if (exp instanceof FunctionCall) {
/* 215 */       return translateCallExpression(context, (FunctionCall)exp);
/*     */     }
/*     */     
/* 218 */     return (Expression)new Constant(exp);
/*     */   }
/*     */ 
/*     */   
/*     */   public EnvironmentVariable getEnvironmentVariable(Symbol name) {
/* 223 */     EnvironmentVariable var = this.variables.get(name);
/* 224 */     if (var == null) {
/* 225 */       var = new EnvironmentVariable(name);
/* 226 */       this.variables.put(name, var);
/*     */     } 
/* 228 */     return var;
/*     */   }
/*     */   
/*     */   public void translateStatements(TranslationContext context, SEXP sexp) {
/* 232 */     if (sexp instanceof FunctionCall) {
/* 233 */       FunctionCall call = (FunctionCall)sexp;
/* 234 */       Function function = resolveFunction(call.getFunction());
/* 235 */       this.builders.get(function).addStatement(this, context, function, call);
/*     */     } else {
/* 237 */       Expression expr = translateExpression(context, sexp);
/* 238 */       if (!(expr instanceof Constant)) {
/* 239 */         addStatement((Statement)new ExprStatement(expr));
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public Expression translateSetterCall(TranslationContext context, FunctionCall getterCall, Expression rhs) {
/* 245 */     Symbol getter = (Symbol)getterCall.getFunction();
/* 246 */     Function setter = resolveFunction((SEXP)Symbol.get(getter.getPrintName() + "<-"));
/*     */     
/* 248 */     FunctionCallTranslator translator = this.builders.get(setter);
/* 249 */     return translator.translateToSetterExpression(this, context, setter, getterCall, rhs);
/*     */   }
/*     */   
/*     */   public Expression translateCallExpression(TranslationContext context, FunctionCall call) {
/* 253 */     SEXP functionName = call.getFunction();
/* 254 */     Function function = resolveFunction(functionName);
/*     */     
/* 256 */     FunctionCallTranslator translator = this.builders.get(function);
/* 257 */     return translator.translateToExpression(this, context, function, call);
/*     */   }
/*     */   
/*     */   private Function resolveFunction(SEXP functionName) {
/* 261 */     if (functionName instanceof org.renjin.sexp.PrimitiveFunction)
/* 262 */       return (Function)functionName; 
/* 263 */     if (functionName instanceof Symbol) {
/* 264 */       return this.runtimeContext.findFunction((Symbol)functionName);
/*     */     }
/* 266 */     throw new NotCompilableException(functionName);
/*     */   }
/*     */   
/*     */   public List<IRArgument> translateArgumentList(TranslationContext context, PairList argumentSexps) {
/* 270 */     List<IRArgument> arguments = Lists.newArrayList();
/* 271 */     for (PairList.Node argNode : argumentSexps.nodes()) {
/* 272 */       if (argNode.getValue() == Symbols.ELLIPSES) {
/* 273 */         for (PairList.Node extraArgument : context.getEllipsesArguments().nodes()) {
/* 274 */           SimpleExpression expression = simplify(translateExpression(context, (SEXP)extraArgument));
/* 275 */           arguments.add(new IRArgument(extraArgument.getRawTag(), expression));
/*     */         }  continue;
/*     */       } 
/* 278 */       SimpleExpression argExpression = simplify(translateExpression(context, argNode.getValue()));
/* 279 */       arguments.add(new IRArgument(argNode.getRawTag(), argExpression));
/*     */     } 
/*     */     
/* 282 */     return arguments;
/*     */   }
/*     */   
/*     */   public SimpleExpression simplify(Expression rvalue) {
/* 286 */     if (rvalue instanceof SimpleExpression) {
/* 287 */       return (SimpleExpression)rvalue;
/*     */     }
/* 289 */     Temp temp = newTemp();
/* 290 */     addStatement((Statement)new Assignment((LValue)temp, rvalue));
/* 291 */     return (SimpleExpression)temp;
/*     */   }
/*     */ 
/*     */   
/*     */   public SimpleExpression translateSimpleExpression(TranslationContext context, SEXP exp) {
/* 296 */     return simplify(translateExpression(context, exp));
/*     */   }
/*     */   
/*     */   private Expression translateExpressionList(TranslationContext context, ExpressionVector vector) {
/* 300 */     if (vector.length() == 0) {
/* 301 */       return (Expression)new Constant((SEXP)Null.INSTANCE);
/*     */     }
/* 303 */     for (int i = 0; i + 1 < vector.length(); i++) {
/* 304 */       translateStatements(context, vector.getElementAsSEXP(i));
/*     */     }
/* 306 */     return translateExpression(context, vector.getElementAsSEXP(vector.length() - 1));
/*     */   }
/*     */ 
/*     */   
/*     */   public Temp newTemp() {
/* 311 */     return new Temp(this.nextTemp++);
/*     */   }
/*     */   
/*     */   public LocalVariable newLocalVariable(String debugName) {
/*     */     int index;
/*     */     String name;
/* 317 */     if (this.localVariableNames.containsKey(debugName)) {
/* 318 */       index = ((Integer)this.localVariableNames.get(debugName)).intValue() + 1;
/* 319 */       name = debugName + index;
/*     */     } else {
/* 321 */       index = 1;
/* 322 */       name = debugName;
/*     */     } 
/* 324 */     this.localVariableNames.put(debugName, Integer.valueOf(index));
/* 325 */     return new LocalVariable("_" + name);
/*     */   }
/*     */   
/*     */   public IRLabel newLabel() {
/* 329 */     return new IRLabel(this.nextLabel++);
/*     */   }
/*     */   
/*     */   public void addStatement(Statement statement) {
/* 333 */     this.statements.add(statement);
/* 334 */     this.currentLabel = null;
/*     */   }
/*     */   
/*     */   public IRLabel addLabel() {
/* 338 */     if (this.currentLabel != null) {
/* 339 */       return this.currentLabel;
/*     */     }
/* 341 */     IRLabel newLabel = newLabel();
/* 342 */     addLabel(newLabel);
/* 343 */     return newLabel;
/*     */   }
/*     */ 
/*     */   
/*     */   public void addLabel(IRLabel label) {
/* 348 */     this.labels.put(label, Integer.valueOf(this.statements.size()));
/* 349 */     this.currentLabel = label;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void removeRedundantJumps() {
/*     */     boolean changed;
/*     */     do {
/* 359 */       changed = false;
/* 360 */       for (int i = 0; i != this.statements.size(); i++) {
/* 361 */         Statement stmt = this.statements.get(i);
/* 362 */         if (stmt instanceof IfStatement) {
/* 363 */           IfStatement ifStmt = (IfStatement)stmt;
/*     */           
/* 365 */           IRLabel newTrueTarget = ultimateTarget(ifStmt.getTrueTarget());
/* 366 */           if (newTrueTarget != null) {
/* 367 */             this.statements.set(i, ifStmt.setTrueTarget(newTrueTarget));
/* 368 */             changed = true;
/*     */           } 
/*     */           
/* 371 */           IRLabel newFalseTarget = ultimateTarget(ifStmt.getFalseTarget());
/* 372 */           if (newFalseTarget != null) {
/* 373 */             this.statements.set(i, ifStmt.setFalseTarget(newFalseTarget));
/* 374 */             changed = true;
/*     */           } 
/*     */         } 
/*     */       } 
/* 378 */     } while (changed);
/*     */   }
/*     */   
/*     */   private IRLabel ultimateTarget(IRLabel label) {
/* 382 */     Statement targetStmt = this.statements.get(((Integer)this.labels.get(label)).intValue());
/* 383 */     if (targetStmt instanceof GotoStatement) {
/* 384 */       return ((GotoStatement)targetStmt).getTarget();
/*     */     }
/* 386 */     return null;
/*     */   }
/*     */   
/*     */   private static class TopLevelContext implements TranslationContext {
/*     */     private TopLevelContext() {}
/*     */     
/*     */     public PairList getEllipsesArguments() {
/* 393 */       throw new InvalidSyntaxException("'...' used outside of a function");
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/ir/tac/IRBodyBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */