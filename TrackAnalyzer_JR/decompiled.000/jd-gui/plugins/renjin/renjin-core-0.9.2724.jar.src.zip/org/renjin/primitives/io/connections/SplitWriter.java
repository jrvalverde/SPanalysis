/*    */ package org.renjin.primitives.io.connections;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.Writer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SplitWriter
/*    */   extends Writer
/*    */ {
/*    */   private Writer writer1;
/*    */   private Writer writer2;
/*    */   
/*    */   public SplitWriter(Writer writer1, Writer writer2) {
/* 33 */     this.writer1 = writer1;
/* 34 */     this.writer2 = writer2;
/*    */   }
/*    */ 
/*    */   
/*    */   public void write(char[] chars, int off, int len) throws IOException {
/* 39 */     this.writer1.write(chars, off, len);
/* 40 */     this.writer2.write(chars, off, len);
/*    */   }
/*    */ 
/*    */   
/*    */   public void flush() throws IOException {
/* 45 */     this.writer1.flush();
/* 46 */     this.writer2.flush();
/*    */   }
/*    */ 
/*    */   
/*    */   public void close() throws IOException {
/* 51 */     this.writer1.close();
/* 52 */     this.writer2.close();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/io/connections/SplitWriter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */