/*     */ package org.renjin.pipeliner;
/*     */ 
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import org.renjin.eval.Profiler;
/*     */ import org.renjin.pipeliner.fusion.LoopKernelCache;
/*     */ import org.renjin.primitives.ni.DeferredNativeCall;
/*     */ import org.renjin.primitives.vector.DeferredComputation;
/*     */ import org.renjin.repackaged.guava.util.concurrent.ListeningExecutorService;
/*     */ import org.renjin.repackaged.guava.util.concurrent.MoreExecutors;
/*     */ import org.renjin.sexp.DoubleArrayVector;
/*     */ import org.renjin.sexp.DoubleVector;
/*     */ import org.renjin.sexp.ListVector;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VectorPipeliner
/*     */ {
/*  35 */   public static boolean DEBUG = "true".equals(System.getProperty("renjin.vp.debug"));
/*  36 */   public static int MAX_DEPTH = 25;
/*     */   
/*     */   private final ListeningExecutorService executorService;
/*     */   
/*     */   private final LoopKernelCache loopKernelCache;
/*     */   
/*     */   public VectorPipeliner(ExecutorService executorService) {
/*  43 */     this.executorService = MoreExecutors.listeningDecorator(executorService);
/*  44 */     this.loopKernelCache = new LoopKernelCache(executorService);
/*     */   }
/*     */ 
/*     */   
/*     */   public void materialize(DeferredNativeCall call) {
/*  49 */     DeferredGraph graph = new DeferredGraph(call);
/*  50 */     graph.optimize(this.loopKernelCache);
/*  51 */     graph.dumpGraph();
/*  52 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public Vector materialize(Vector root) {
/*  57 */     DeferredGraph graph = new DeferredGraph(root);
/*     */     
/*  59 */     materializeGraph(graph);
/*     */     
/*  61 */     return graph.getRootResult(0);
/*     */   }
/*     */ 
/*     */   
/*     */   public ListVector materialize(ListVector listVector) {
/*  66 */     DeferredGraph graph = new DeferredGraph();
/*     */ 
/*     */     
/*  69 */     Vector[] vectors = new Vector[listVector.length()];
/*  70 */     for (int i = 0; i < listVector.length(); i++) {
/*  71 */       SEXP element = listVector.getElementAsSEXP(i);
/*  72 */       if (element instanceof Vector && ((Vector)element).isDeferred()) {
/*  73 */         Vector vector = (Vector)element;
/*  74 */         vectors[i] = vector;
/*  75 */         graph.addRoot(vector);
/*     */       } 
/*     */     } 
/*     */     
/*  79 */     materializeGraph(graph);
/*     */ 
/*     */     
/*  82 */     ListVector.Builder newList = new ListVector.Builder(0, listVector.length());
/*  83 */     newList.copyAttributesFrom((SEXP)listVector);
/*     */     
/*  85 */     int vectorIndex = 0;
/*  86 */     for (int j = 0; j < listVector.length(); j++) {
/*  87 */       if (vectors[j] == null) {
/*  88 */         newList.add(listVector.getElementAsSEXP(j));
/*     */       } else {
/*  90 */         newList.add((SEXP)graph.getRootResult(vectorIndex));
/*  91 */         vectorIndex++;
/*     */       } 
/*     */     } 
/*     */     
/*  95 */     return newList.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void materializeGraph(DeferredGraph graph) {
/* 102 */     long start = System.nanoTime();
/*     */     
/* 104 */     if (DEBUG) {
/* 105 */       System.out.print("unopt");
/* 106 */       graph.dumpGraph();
/*     */     } 
/*     */     
/* 109 */     graph.optimize(this.loopKernelCache);
/*     */     
/* 111 */     if (DEBUG) {
/* 112 */       graph.dumpGraph();
/*     */     }
/*     */ 
/*     */     
/* 116 */     evaluate(graph);
/*     */     
/* 118 */     if (Profiler.ENABLED) {
/* 119 */       long time = System.nanoTime() - start;
/* 120 */       Profiler.materialized(time);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Vector simplify(DeferredComputation root) {
/* 126 */     DeferredGraph graph = new DeferredGraph((Vector)root);
/*     */     
/* 128 */     if (DEBUG) {
/* 129 */       System.err.println("simplify");
/* 130 */       graph.dumpGraph();
/*     */     } 
/*     */     
/* 133 */     Vector vector = materialize((Vector)root);
/* 134 */     if (vector instanceof org.renjin.primitives.vector.MemoizedDoubleVector)
/* 135 */       return vector; 
/* 136 */     if (vector.isDeferred() && vector instanceof DoubleVector) {
/* 137 */       return (Vector)DoubleArrayVector.unsafe(((DoubleVector)vector).toDoubleArray(), vector.getAttributes());
/*     */     }
/* 139 */     return vector;
/*     */   }
/*     */ 
/*     */   
/*     */   public void evaluate(DeferredGraph graph) {
/* 144 */     DeferredGraphEval eval = new DeferredGraphEval(graph, (ExecutorService)this.executorService);
/* 145 */     eval.execute();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/pipeliner/VectorPipeliner.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */