/*     */ package org.renjin.primitives.special;
/*     */ 
/*     */ import org.renjin.eval.Context;
/*     */ import org.renjin.eval.EvalException;
/*     */ import org.renjin.sexp.Environment;
/*     */ import org.renjin.sexp.FunctionCall;
/*     */ import org.renjin.sexp.PairList;
/*     */ import org.renjin.sexp.Promise;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.SpecialFunction;
/*     */ import org.renjin.sexp.StringVector;
/*     */ import org.renjin.sexp.Symbol;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AssignLeftFunction
/*     */   extends SpecialFunction
/*     */ {
/*     */   public AssignLeftFunction() {
/*  29 */     super("<-");
/*     */   }
/*     */   
/*     */   protected AssignLeftFunction(String name) {
/*  33 */     super(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public SEXP apply(Context context, Environment rho, FunctionCall call, PairList args) {
/*  38 */     SEXP lhs = call.getArgument(0);
/*  39 */     SEXP rhs = call.getArgument(1);
/*     */     
/*  41 */     return assignLeft(context, rho, lhs, rhs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SEXP assignLeft(Context context, Environment rho, SEXP lhs, SEXP value) {
/*     */     SEXP sEXP1;
/*     */     Symbol target;
/*  57 */     SEXP evaluatedValue = context.evaluate(value, rho);
/*  58 */     Promise promise = new Promise(value, evaluatedValue);
/*     */     
/*  60 */     while (lhs instanceof FunctionCall) {
/*  61 */       FunctionCall call = (FunctionCall)lhs;
/*  62 */       SEXP getter = call.getFunction();
/*  63 */       SEXP setter = setterFromGetter(getter);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  68 */       PairList setterArgs = PairList.Node.newBuilder().addAll(call.getArguments()).add("value", (SEXP)promise).build();
/*     */       
/*  70 */       FunctionCall setterCall = new FunctionCall(setter, setterArgs);
/*     */       
/*  72 */       promise = Promise.repromise(context.evaluate((SEXP)setterCall, rho));
/*     */       
/*  74 */       lhs = call.getArgument(0);
/*     */     } 
/*     */ 
/*     */     
/*  78 */     if (lhs instanceof Symbol) {
/*  79 */       target = (Symbol)lhs;
/*  80 */     } else if (lhs instanceof StringVector) {
/*  81 */       target = Symbol.get(((StringVector)lhs).getElementAsString(0));
/*     */     } else {
/*  83 */       throw new EvalException("cannot assign to value '" + lhs + " (of type " + lhs.getTypeName() + ")", new Object[0]);
/*     */     } 
/*     */ 
/*     */     
/*  87 */     if (promise instanceof Promise) {
/*  88 */       sEXP1 = promise.force(context);
/*     */     }
/*  90 */     assignResult(context, rho, target, sEXP1);
/*     */     
/*  92 */     context.setInvisibleFlag();
/*     */     
/*  94 */     return evaluatedValue;
/*     */   }
/*     */   
/*     */   private SEXP setterFromGetter(SEXP getter) {
/*  98 */     if (getter instanceof Symbol) {
/*  99 */       return (SEXP)Symbol.get(((Symbol)getter).getPrintName() + "<-");
/*     */     }
/*     */     
/* 102 */     if (getter instanceof FunctionCall) {
/* 103 */       FunctionCall call = (FunctionCall)getter;
/* 104 */       if (call.getArguments().length() == 2 && (call
/* 105 */         .getFunction() == Symbol.get("::") || call
/* 106 */         .getFunction() == Symbol.get(":::"))) {
/* 107 */         SEXP namespace = call.getArgument(0);
/* 108 */         SEXP namespacedGetter = call.getArgument(1);
/* 109 */         SEXP setter = setterFromGetter(namespacedGetter);
/* 110 */         return (SEXP)FunctionCall.newCall(call.getFunction(), new SEXP[] { namespace, setter });
/*     */       } 
/*     */     } 
/* 113 */     throw new EvalException("invalid function in complex assignment", new Object[0]);
/*     */   }
/*     */   
/*     */   protected void assignResult(Context context, Environment rho, Symbol target, SEXP rhs) {
/* 117 */     if (target.isReservedWord() && rhs instanceof org.renjin.sexp.Function) {
/* 118 */       context.warn("Renjin does not honor redefinition of '" + target.getPrintName() + "' function");
/*     */     }
/* 120 */     rho.setVariable(context, target, rhs);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/special/AssignLeftFunction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */