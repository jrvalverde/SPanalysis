/*    */ package org.renjin.primitives.io.serialization;
/*    */ 
/*    */ import org.renjin.sexp.Environment;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum HeadlessWriteContext
/*    */   implements WriteContext
/*    */ {
/* 29 */   INSTANCE;
/*    */ 
/*    */   
/*    */   public boolean isBaseEnvironment(Environment exp) {
/* 33 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isNamespaceEnvironment(Environment exp) {
/* 38 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isBaseNamespaceEnvironment(Environment ns) {
/* 43 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isGlobalEnvironment(Environment env) {
/* 48 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getNamespaceName(Environment ns) {
/* 53 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/io/serialization/HeadlessWriteContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */