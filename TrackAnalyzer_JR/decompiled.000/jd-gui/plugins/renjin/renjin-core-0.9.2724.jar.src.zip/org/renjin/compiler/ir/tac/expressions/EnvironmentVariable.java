/*    */ package org.renjin.compiler.ir.tac.expressions;
/*    */ 
/*    */ import org.renjin.sexp.Symbol;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EnvironmentVariable
/*    */   extends Variable
/*    */ {
/*    */   private final Symbol name;
/*    */   
/*    */   public EnvironmentVariable(Symbol name) {
/* 32 */     this.name = name;
/*    */   }
/*    */   
/*    */   public EnvironmentVariable(String name) {
/* 36 */     this(Symbol.get(name));
/*    */   }
/*    */   
/*    */   public Symbol getName() {
/* 40 */     return this.name;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 45 */     return this.name.toString();
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 50 */     return this.name.hashCode();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 55 */     if (this == obj) {
/* 56 */       return true;
/*    */     }
/* 58 */     if (obj == null) {
/* 59 */       return false;
/*    */     }
/* 61 */     if (getClass() != obj.getClass()) {
/* 62 */       return false;
/*    */     }
/* 64 */     EnvironmentVariable other = (EnvironmentVariable)obj;
/* 65 */     return (this.name == other.name);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isPure() {
/* 70 */     return false;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/ir/tac/expressions/EnvironmentVariable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */