/*    */ package org.renjin.primitives.packaging;
/*    */ 
/*    */ import java.util.Optional;
/*    */ import java.util.Set;
/*    */ import org.renjin.eval.Context;
/*    */ import org.renjin.eval.EvalException;
/*    */ import org.renjin.repackaged.guava.collect.ImmutableSet;
/*    */ import org.renjin.sexp.Frame;
/*    */ import org.renjin.sexp.Function;
/*    */ import org.renjin.sexp.SEXP;
/*    */ import org.renjin.sexp.Symbol;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NamespaceFrame
/*    */   implements Frame
/*    */ {
/*    */   private final NamespaceRegistry registry;
/*    */   
/*    */   public NamespaceFrame(NamespaceRegistry registry) {
/* 38 */     this.registry = registry;
/*    */   }
/*    */ 
/*    */   
/*    */   public Set<Symbol> getSymbols() {
/* 43 */     return (Set<Symbol>)ImmutableSet.copyOf(this.registry.getLoadedNamespaceNames());
/*    */   }
/*    */ 
/*    */   
/*    */   public SEXP getVariable(Symbol name) {
/* 48 */     Optional<Namespace> namespace = this.registry.getNamespaceIfPresent(name);
/* 49 */     if (namespace.isPresent()) {
/* 50 */       return (SEXP)((Namespace)namespace.get()).getNamespaceEnvironment();
/*    */     }
/* 52 */     return (SEXP)Symbol.UNBOUND_VALUE;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Function getFunction(Context context, Symbol name) {
/* 58 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isMissingArgument(Symbol name) {
/* 63 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setVariable(Symbol name, SEXP value) {
/* 68 */     throw new EvalException("Cannot modify the namespace registry", new Object[0]);
/*    */   }
/*    */ 
/*    */   
/*    */   public void clear() {
/* 73 */     throw new EvalException("Cannot modify the namespace registry", new Object[0]);
/*    */   }
/*    */ 
/*    */   
/*    */   public void remove(Symbol name) {
/* 78 */     throw new EvalException("Cannot modify the namespace registry", new Object[0]);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/packaging/NamespaceFrame.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */