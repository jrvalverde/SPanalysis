/*     */ package org.renjin.pipeliner.node;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ import org.renjin.repackaged.guava.base.Joiner;
/*     */ import org.renjin.repackaged.guava.collect.Lists;
/*     */ import org.renjin.repackaged.guava.collect.Sets;
/*     */ import org.renjin.sexp.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class DeferredNode
/*     */ {
/*  32 */   private List<DeferredNode> operands = Lists.newArrayList();
/*  33 */   private Set<DeferredNode> uses = Sets.newIdentityHashSet();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int addInput(DeferredNode node) {
/*  40 */     this.operands.add(node);
/*     */ 
/*     */ 
/*     */     
/*  44 */     return this.operands.size() - 1;
/*     */   }
/*     */ 
/*     */   
/*     */   public void addInputs(DeferredNode[] array) {
/*  49 */     for (int i = 0; i < array.length; i++) {
/*  50 */       DeferredNode input = array[i];
/*  51 */       this.operands.add(input);
/*  52 */       input.uses.add(this);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void addOutput(DeferredNode node) {
/*  58 */     this.uses.add(node);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract String getDebugLabel();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<DeferredNode> getOperands() {
/*  70 */     return this.operands;
/*     */   }
/*     */   
/*     */   public void replaceOperands(DeferredNode... operands) {
/*  74 */     this.operands = Lists.newArrayList((Object[])operands);
/*     */   }
/*     */   
/*     */   public String getDebugId() {
/*  78 */     return "N" + Integer.toHexString(System.identityHashCode(this));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract NodeShape getShape();
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  89 */     if (this.operands.isEmpty()) {
/*  90 */       return getDebugLabel();
/*     */     }
/*  92 */     return getDebugLabel() + "(" + Joiner.on(", ").join(this.operands) + ")";
/*     */   }
/*     */ 
/*     */   
/*     */   public abstract Type getResultVectorType();
/*     */   
/*     */   public boolean hasValue(double x) {
/*  99 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DeferredNode getOperand(int index) {
/* 113 */     return getOperands().get(index);
/*     */   }
/*     */   
/*     */   public void replaceOperand(DeferredNode toReplace, DeferredNode replacementValue) {
/* 117 */     for (int i = 0; i != this.operands.size(); i++) {
/* 118 */       if (this.operands.get(i) == toReplace) {
/* 119 */         this.operands.set(i, replacementValue);
/* 120 */         replacementValue.addOutput(this);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void removeUse(DeferredNode node) {
/* 126 */     this.uses.remove(node);
/*     */   }
/*     */   
/*     */   public void replaceUse(DeferredNode node, DeferredNode replacementValue) {
/* 130 */     if (this.uses.remove(node)) {
/* 131 */       this.uses.add(replacementValue);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isUsed() {
/* 136 */     return !this.uses.isEmpty();
/*     */   }
/*     */   
/*     */   public Vector getVector() {
/* 140 */     throw new UnsupportedOperationException("getVector(): " + getClass().getName());
/*     */   }
/*     */   
/*     */   public void setResult(Vector result) {
/* 144 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<DeferredNode> getUses() {
/* 149 */     return this.uses;
/*     */   }
/*     */   
/*     */   public final boolean isLeaf() {
/* 153 */     return this.operands.isEmpty();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/pipeliner/node/DeferredNode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */