/*     */ package org.renjin.pipeliner.node;
/*     */ 
/*     */ import org.renjin.primitives.vector.MemoizedComputation;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ import org.renjin.sexp.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataNode
/*     */   extends DeferredNode
/*     */ {
/*     */   private Vector vector;
/*     */   
/*     */   public DataNode(Vector vector) {
/*  38 */     if (vector instanceof MemoizedComputation) {
/*  39 */       this.vector = ((MemoizedComputation)vector).forceResult();
/*     */     } else {
/*  41 */       this.vector = vector;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDebugLabel() {
/*  47 */     if (this.vector.length() == 1) {
/*  48 */       if (this.vector.isElementNA(0)) {
/*  49 */         return "NA";
/*     */       }
/*  51 */       if (this.vector instanceof org.renjin.sexp.IntVector) {
/*  52 */         return this.vector.getElementAsInt(0) + "L";
/*     */       }
/*  54 */       if (this.vector instanceof org.renjin.sexp.DoubleVector) {
/*  55 */         return Double.toString(this.vector.getElementAsDouble(0));
/*     */       }
/*  57 */       if (this.vector instanceof org.renjin.sexp.LogicalVector) {
/*  58 */         return (this.vector.getElementAsRawLogical(0) == 0) ? "F" : "T";
/*     */       }
/*     */     } 
/*  61 */     return "[" + this.vector.length() + "]";
/*     */   }
/*     */ 
/*     */   
/*     */   public Vector getVector() {
/*  66 */     return this.vector;
/*     */   }
/*     */ 
/*     */   
/*     */   public NodeShape getShape() {
/*  71 */     return NodeShape.BOX;
/*     */   }
/*     */ 
/*     */   
/*     */   public Type getResultVectorType() {
/*  76 */     return Type.getType(this.vector.getClass());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasValue(double x) {
/*  81 */     return (this.vector.length() == 1 && this.vector.getElementAsDouble(0) == x);
/*     */   }
/*     */   
/*     */   public boolean equivalent(DeferredNode other) {
/*  85 */     if (!(other instanceof DataNode)) {
/*  86 */       return false;
/*     */     }
/*  88 */     DataNode otherData = (DataNode)other;
/*  89 */     Vector.Type vectorType = getVector().getVectorType();
/*  90 */     if (!vectorType.equals(otherData.vector.getVectorType())) {
/*  91 */       return false;
/*     */     }
/*  93 */     if (this.vector.length() > 10 || this.vector.length() != otherData.vector.length()) {
/*  94 */       return false;
/*     */     }
/*  96 */     for (int i = 0; i < this.vector.length(); i++) {
/*  97 */       if (vectorType.compareElements(this.vector, i, otherData.vector, i) != 0) {
/*  98 */         return false;
/*     */       }
/*     */     } 
/* 101 */     return true;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/pipeliner/node/DataNode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */