/*    */ package org.renjin.pipeliner.optimize;
/*    */ 
/*    */ import org.renjin.pipeliner.DeferredGraph;
/*    */ import org.renjin.pipeliner.node.DeferredNode;
/*    */ import org.renjin.pipeliner.node.FunctionNode;
/*    */ import org.renjin.primitives.vector.DeferredComputation;
/*    */ import org.renjin.sexp.AttributeMap;
/*    */ import org.renjin.sexp.DoubleVector;
/*    */ import org.renjin.sexp.SEXP;
/*    */ import org.renjin.sexp.Vector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SquareOptimizer
/*    */   implements Optimizer
/*    */ {
/*    */   public boolean optimize(DeferredGraph graph, FunctionNode node) {
/* 38 */     if (isEligible(node)) {
/*    */       
/* 40 */       DeferredNode operand = node.getOperand(0);
/* 41 */       node.replaceVector(new Square(operand.getVector(), operand.getVector().getAttributes()));
/* 42 */       node.replaceOperands(new DeferredNode[] { operand });
/* 43 */       return true;
/*    */     } 
/* 45 */     return false;
/*    */   }
/*    */   
/*    */   private boolean isEligible(FunctionNode node) {
/* 49 */     return (node.getComputationName().equals("*") && node
/* 50 */       .getOperand(0) == node.getOperand(1));
/*    */   }
/*    */   
/*    */   public static class Square extends DoubleVector implements DeferredComputation {
/*    */     private Vector vector;
/*    */     
/*    */     protected Square(Vector vector, AttributeMap attributes) {
/* 57 */       super(attributes);
/* 58 */       this.vector = vector;
/*    */     }
/*    */ 
/*    */     
/*    */     public Vector[] getOperands() {
/* 63 */       return new Vector[] { this.vector };
/*    */     }
/*    */ 
/*    */     
/*    */     public String getComputationName() {
/* 68 */       return "sqr";
/*    */     }
/*    */ 
/*    */     
/*    */     protected SEXP cloneWithNewAttributes(AttributeMap attributes) {
/* 73 */       return (SEXP)new Square(this.vector, attributes);
/*    */     }
/*    */ 
/*    */     
/*    */     public double getElementAsDouble(int index) {
/* 78 */       return compute(this.vector.getElementAsDouble(index));
/*    */     }
/*    */ 
/*    */     
/*    */     public boolean isConstantAccessTime() {
/* 83 */       return true;
/*    */     }
/*    */ 
/*    */     
/*    */     public int length() {
/* 88 */       return this.vector.length();
/*    */     }
/*    */     
/*    */     public static double compute(double x) {
/* 92 */       return x * x;
/*    */     }
/*    */ 
/*    */     
/*    */     public boolean isDeferred() {
/* 97 */       return true;
/*    */     }
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/pipeliner/optimize/SquareOptimizer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */