/*     */ package org.renjin.base;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import org.renjin.eval.Context;
/*     */ import org.renjin.eval.EvalException;
/*     */ import org.renjin.invoke.annotations.Current;
/*     */ import org.renjin.methods.Methods;
/*     */ import org.renjin.primitives.Types;
/*     */ import org.renjin.primitives.io.serialization.Serialization;
/*     */ import org.renjin.primitives.matrix.Matrix;
/*     */ import org.renjin.primitives.matrix.MatrixBuilder;
/*     */ import org.renjin.sexp.AtomicVector;
/*     */ import org.renjin.sexp.AttributeMap;
/*     */ import org.renjin.sexp.Environment;
/*     */ import org.renjin.sexp.IntArrayVector;
/*     */ import org.renjin.sexp.IntVector;
/*     */ import org.renjin.sexp.ListVector;
/*     */ import org.renjin.sexp.LogicalArrayVector;
/*     */ import org.renjin.sexp.Null;
/*     */ import org.renjin.sexp.PairList;
/*     */ import org.renjin.sexp.S4Object;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.StringVector;
/*     */ import org.renjin.sexp.Symbol;
/*     */ import org.renjin.sexp.Symbols;
/*     */ import org.renjin.sexp.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Base
/*     */ {
/*     */   public static ListVector R_getSymbolInfo(String sname, SEXP spackage, boolean withRegistrationInfo) {
/*  54 */     ListVector.Builder result = new ListVector.Builder();
/*  55 */     result.setAttribute(Symbols.CLASS, (SEXP)StringVector.valueOf("CRoutine"));
/*     */     
/*  57 */     return result.build();
/*     */   }
/*     */ 
/*     */   
/*     */   public static ListVector R_getRegisteredRoutines(String dll) {
/*  62 */     ListVector.Builder builder = new ListVector.Builder();
/*  63 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SEXP R_shortRowNames(SEXP vector, int type) {
/*     */     IntArrayVector intArrayVector;
/*  75 */     SEXP s = vector.getAttribute(Symbols.ROW_NAMES);
/*  76 */     SEXP ans = s;
/*     */     
/*  78 */     if (type < 0 || type > 2) {
/*  79 */       throw new EvalException("invalid 'type' argument", new Object[0]);
/*     */     }
/*     */     
/*  82 */     if (type >= 1) {
/*     */       int n;
/*  84 */       if (s instanceof IntVector && s.length() == 2 && ((IntVector)s).isElementNA(0)) {
/*  85 */         n = ((IntVector)s).getElementAsInt(1);
/*     */       }
/*  87 */       else if (s == Null.INSTANCE) {
/*  88 */         n = 0;
/*     */       } else {
/*  90 */         n = s.length();
/*     */       } 
/*     */       
/*  93 */       if (type == 1) {
/*  94 */         intArrayVector = new IntArrayVector(new int[] { n });
/*     */       } else {
/*  96 */         intArrayVector = new IntArrayVector(new int[] { Math.abs(n) });
/*     */       } 
/*     */     } 
/*  99 */     return (SEXP)intArrayVector;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PairList R_tabulate(IntVector bin, int length, int nbins, SEXP ans) {
/* 117 */     int[] counts = new int[nbins];
/* 118 */     for (int i = 0; i != length; i++) {
/* 119 */       if (!bin.isElementNA(i)) {
/* 120 */         int value = bin.getElementAsInt(i);
/* 121 */         if (value >= 1 && value <= nbins) {
/* 122 */           counts[value - 1] = counts[value - 1] + 1;
/*     */         }
/*     */       } 
/*     */     } 
/* 126 */     return (PairList)PairList.Node.singleton("ans", (SEXP)new IntArrayVector(counts));
/*     */   }
/*     */   
/*     */   public static SEXP Rrowsum_df(ListVector x, int ncol, Vector group, SEXP ugroup, boolean naRm) {
/* 130 */     throw new EvalException("nyi", new Object[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Vector Rrowsum_matrix(Vector x, int ncol, AtomicVector groups, AtomicVector ugroup, boolean naRm) {
/* 135 */     int numGroups = ugroup.length();
/*     */     
/* 137 */     Matrix source = new Matrix(x, ncol);
/* 138 */     MatrixBuilder result = source.newBuilder(numGroups, ncol);
/*     */     
/* 140 */     for (int col = 0; col != ncol; col++) {
/*     */ 
/*     */ 
/*     */       
/* 144 */       double[] groupSums = new double[numGroups];
/* 145 */       for (int row = 0; row != source.getNumRows(); row++) {
/* 146 */         int i = ugroup.indexOf(groups, row, 0);
/* 147 */         groupSums[i] = groupSums[i] + source.getElementAsDouble(row, col);
/*     */       } 
/*     */ 
/*     */       
/* 151 */       for (int group = 0; group != ugroup.length(); group++) {
/* 152 */         result.setValue(group, col, groupSums[group]);
/*     */       }
/*     */     } 
/*     */     
/* 156 */     return result.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SEXP R_copyDFattr(SEXP in, SEXP out) {
/*     */     ListVector attributesToCopy;
/* 167 */     if (in.hasAttributes()) {
/* 168 */       attributesToCopy = in.getAttributes().toVector();
/*     */     } else {
/* 170 */       attributesToCopy = new ListVector(new SEXP[0]);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 175 */     return out.setAttributes(AttributeMap.fromListVector(attributesToCopy));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SEXP R_getVarsFromFrame(@Current Context context, StringVector vars, Environment env, boolean force) {
/* 185 */     ListVector.NamedBuilder val = new ListVector.NamedBuilder();
/* 186 */     for (String var : vars) {
/* 187 */       SEXP boundValue = env.getVariable(context, var);
/* 188 */       if (boundValue == Symbol.UNBOUND_VALUE) {
/* 189 */         throw new EvalException("object %s not found", new Object[] { boundValue });
/*     */       }
/* 191 */       if (force) {
/* 192 */         boundValue = boundValue.force(context);
/*     */       }
/* 194 */       val.add(var, boundValue);
/*     */     } 
/* 196 */     return (SEXP)val.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ListVector str_signif(Vector x, int n, String type, int width, int digits, String format, String flag, StringVector resultVector) {
/* 203 */     ListVector.NamedBuilder result = new ListVector.NamedBuilder();
/* 204 */     result.add("result", (SEXP)StrSignIf.str_signif(x, width, digits, format, flag));
/* 205 */     return result.build();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static SEXP R_serialize(@Current Context context, SEXP object, SEXP connection, boolean ascii, SEXP version, SEXP refhook) throws IOException {
/* 211 */     return Serialization.serialize(context, object, connection, ascii, version, refhook);
/*     */   }
/*     */   
/*     */   public static SEXP R_unserialize(@Current Context context, SEXP connection, SEXP refhook) throws IOException {
/* 215 */     return Serialization.unserialize(context, connection, refhook);
/*     */   }
/*     */   
/*     */   public static String crc64ToString(String value) {
/* 219 */     return Crc64.getCrc64(value);
/*     */   }
/*     */   
/*     */   public static SEXP R_isS4Object(SEXP exp) {
/* 223 */     return LogicalArrayVector.valueOf(Types.isS4(exp));
/*     */   }
/*     */   
/*     */   public static SEXP R_do_new_object(S4Object classRepresentation) {
/* 227 */     return Methods.R_do_new_object(classRepresentation);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/base/Base.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */