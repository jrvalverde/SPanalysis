/*     */ package org.renjin.compiler.ir.tac.expressions;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.renjin.compiler.NotCompilableException;
/*     */ import org.renjin.compiler.builtins.ArgumentBounds;
/*     */ import org.renjin.compiler.cfg.InlinedFunction;
/*     */ import org.renjin.compiler.codegen.EmitContext;
/*     */ import org.renjin.compiler.ir.ValueBounds;
/*     */ import org.renjin.compiler.ir.tac.IRArgument;
/*     */ import org.renjin.compiler.ir.tac.RuntimeState;
/*     */ import org.renjin.eval.MatchedArgumentPositions;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ import org.renjin.repackaged.asm.commons.InstructionAdapter;
/*     */ import org.renjin.repackaged.guava.base.Joiner;
/*     */ import org.renjin.sexp.Closure;
/*     */ import org.renjin.sexp.FunctionCall;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClosureCall
/*     */   implements Expression
/*     */ {
/*     */   private final RuntimeState runtimeState;
/*     */   private final FunctionCall call;
/*     */   private final List<IRArgument> arguments;
/*     */   private final Closure closure;
/*     */   private final String debugName;
/*     */   private MatchedArgumentPositions matching;
/*     */   private InlinedFunction inlinedFunction;
/*     */   private ValueBounds returnBounds;
/*     */   private Type type;
/*     */   
/*     */   public ClosureCall(RuntimeState runtimeState, FunctionCall call, Closure closure, String closureDebugName, List<IRArgument> arguments) {
/*  55 */     this.runtimeState = runtimeState;
/*  56 */     this.call = call;
/*  57 */     this.closure = closure;
/*  58 */     this.arguments = arguments;
/*  59 */     this.debugName = closureDebugName;
/*     */     
/*  61 */     this.matching = MatchedArgumentPositions.matchIRArguments(closure, arguments);
/*  62 */     this.returnBounds = ValueBounds.UNBOUNDED;
/*  63 */     this.type = this.returnBounds.storageType();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isPure() {
/*  69 */     if (this.inlinedFunction == null) {
/*  70 */       return false;
/*     */     }
/*  72 */     return this.inlinedFunction.isPure();
/*     */   }
/*     */ 
/*     */   
/*     */   public Type getType() {
/*  77 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ValueBounds updateTypeBounds(Map<Expression, ValueBounds> typeMap) {
/*  83 */     if (this.inlinedFunction == null) {
/*     */       try {
/*  85 */         this.inlinedFunction = new InlinedFunction(this.runtimeState, this.closure, this.matching.getSuppliedFormals());
/*  86 */       } catch (NotCompilableException e) {
/*  87 */         throw new NotCompilableException(this.call, e);
/*     */       } 
/*     */     }
/*     */     
/*  91 */     if (this.matching.hasExtraArguments()) {
/*  92 */       throw new NotCompilableException(this.call, "Extra arguments not supported");
/*     */     }
/*     */     
/*  95 */     this.returnBounds = this.inlinedFunction.updateBounds(ArgumentBounds.create(this.arguments, typeMap));
/*  96 */     this.type = this.returnBounds.storageType();
/*     */     
/*  98 */     return this.returnBounds;
/*     */   }
/*     */ 
/*     */   
/*     */   public ValueBounds getValueBounds() {
/* 103 */     return this.returnBounds;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int load(EmitContext emitContext, InstructionAdapter mv) {
/* 110 */     if (this.matching.hasExtraArguments()) {
/* 111 */       throw new NotCompilableException(this.call, "Extra arguments not supported");
/*     */     }
/*     */     
/* 114 */     this.inlinedFunction.writeInline(emitContext, mv, this.matching, this.arguments);
/*     */     
/* 116 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setChild(int childIndex, Expression child) {
/* 122 */     ((IRArgument)this.arguments.get(childIndex)).setExpression(child);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getChildCount() {
/* 127 */     return this.arguments.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public Expression childAt(int index) {
/* 132 */     return ((IRArgument)this.arguments.get(index)).getExpression();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 138 */     return this.debugName + "(" + Joiner.on(", ").join(this.arguments) + ")";
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/ir/tac/expressions/ClosureCall.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */