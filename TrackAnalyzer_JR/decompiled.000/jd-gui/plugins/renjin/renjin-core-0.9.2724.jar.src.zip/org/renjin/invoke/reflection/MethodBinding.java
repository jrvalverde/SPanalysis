/*    */ package org.renjin.invoke.reflection;
/*    */ 
/*    */ import org.renjin.eval.EvalException;
/*    */ import org.renjin.sexp.SEXP;
/*    */ import org.renjin.sexp.Symbol;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MethodBinding
/*    */   implements MemberBinding
/*    */ {
/*    */   private Symbol name;
/*    */   private FunctionBinding binding;
/*    */   
/*    */   public MethodBinding(Symbol name, FunctionBinding functionBinding) {
/* 32 */     this.name = name;
/* 33 */     this.binding = functionBinding;
/*    */   }
/*    */ 
/*    */   
/*    */   public SEXP getValue(Object instance) {
/* 38 */     return (SEXP)new MethodFunction(instance, this.binding);
/*    */   }
/*    */ 
/*    */   
/*    */   public void setValue(Object instance, SEXP value) {
/* 43 */     throw new EvalException("Cannot replace a method on an instance of a JVM object", new Object[0]);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/reflection/MethodBinding.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */