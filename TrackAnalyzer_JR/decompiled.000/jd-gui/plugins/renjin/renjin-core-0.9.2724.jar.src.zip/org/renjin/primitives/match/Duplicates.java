/*     */ package org.renjin.primitives.match;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import org.renjin.invoke.annotations.Internal;
/*     */ import org.renjin.repackaged.guava.collect.Maps;
/*     */ import org.renjin.sexp.AtomicVector;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Duplicates
/*     */ {
/*     */   @Internal
/*     */   public static Vector unique(Vector x, Vector incomparables, boolean fromLast) {
/*  49 */     return search(x, incomparables, fromLast, new UniqueAlgorithm());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Internal
/*     */   public static Vector duplicated(Vector x, AtomicVector incomparables, boolean fromLast) {
/*  57 */     return search(x, (Vector)incomparables, fromLast, new DuplicatedAlgorithm());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Internal
/*     */   public static int anyDuplicated(Vector x, AtomicVector incomparables, boolean fromLast) {
/*  76 */     return ((Integer)search(x, (Vector)incomparables, fromLast, new AnyDuplicateAlgorithm())).intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static <ResultType> ResultType search(Vector x, Vector incomparables, boolean fromLast, DuplicateSearchAlgorithm<ResultType> algorithm) {
/*  87 */     algorithm.init(x);
/*     */ 
/*     */     
/*  90 */     HashMap<SEXP, Integer> seen = Maps.newHashMap();
/*     */     
/*  92 */     for (Integer index : new IndexSequence(x, fromLast)) {
/*     */       
/*  94 */       SEXP element = x.getElementAsSEXP(index.intValue());
/*     */       
/*  96 */       Integer originalIndex = seen.get(element);
/*     */       
/*  98 */       if (originalIndex == null) {
/*  99 */         algorithm.onUnique(index.intValue());
/* 100 */         seen.put(element, index);
/*     */         continue;
/*     */       } 
/* 103 */       if (algorithm.onDuplicate(index.intValue(), originalIndex.intValue()) == DuplicateSearchAlgorithm.Action.STOP) {
/* 104 */         return algorithm.getResult();
/*     */       }
/*     */     } 
/*     */     
/* 108 */     return algorithm.getResult();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/match/Duplicates.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */