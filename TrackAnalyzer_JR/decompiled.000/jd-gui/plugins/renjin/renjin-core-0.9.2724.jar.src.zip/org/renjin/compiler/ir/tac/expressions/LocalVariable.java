/*    */ package org.renjin.compiler.ir.tac.expressions;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LocalVariable
/*    */   extends Variable
/*    */ {
/*    */   private final String name;
/*    */   
/*    */   public LocalVariable(String name) {
/* 33 */     this.name = name;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isPure() {
/* 38 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 43 */     int prime = 31;
/* 44 */     int result = 1;
/* 45 */     result = 31 * result + ((this.name == null) ? 0 : this.name.hashCode());
/* 46 */     return result;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 51 */     if (this == obj) {
/* 52 */       return true;
/*    */     }
/* 54 */     if (obj == null) {
/* 55 */       return false;
/*    */     }
/* 57 */     if (getClass() != obj.getClass()) {
/* 58 */       return false;
/*    */     }
/* 60 */     LocalVariable other = (LocalVariable)obj;
/*    */     
/* 62 */     return this.name.equals(other.name);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 67 */     return this.name;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/ir/tac/expressions/LocalVariable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */