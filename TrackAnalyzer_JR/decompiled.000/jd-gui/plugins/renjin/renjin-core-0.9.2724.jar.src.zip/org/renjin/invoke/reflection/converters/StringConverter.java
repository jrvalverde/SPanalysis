/*    */ package org.renjin.invoke.reflection.converters;
/*    */ 
/*    */ import org.renjin.sexp.SEXP;
/*    */ import org.renjin.sexp.StringVector;
/*    */ import org.renjin.sexp.Vector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StringConverter
/*    */   extends BoxedScalarConverter<String>
/*    */ {
/* 30 */   public static final StringConverter INSTANCE = new StringConverter();
/*    */ 
/*    */ 
/*    */   
/*    */   public static boolean accept(Class<String> clazz) {
/* 35 */     if (clazz.isArray()) {
/* 36 */       return false;
/*    */     }
/* 38 */     return (clazz == String.class);
/*    */   }
/*    */ 
/*    */   
/*    */   public SEXP convertToR(String value) {
/* 43 */     return (SEXP)StringVector.valueOf(value);
/*    */   }
/*    */ 
/*    */   
/*    */   protected Object getFirstElement(Vector value) {
/* 48 */     return value.getElementAsString(0);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean acceptsSEXP(SEXP exp) {
/* 53 */     return (exp instanceof Vector && ((Vector)exp).length() == 1);
/*    */   }
/*    */ 
/*    */   
/*    */   public int getSpecificity() {
/* 58 */     return 4;
/*    */   }
/*    */ 
/*    */   
/*    */   public Vector.Type getVectorType() {
/* 63 */     return StringVector.VECTOR_TYPE;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/reflection/converters/StringConverter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */