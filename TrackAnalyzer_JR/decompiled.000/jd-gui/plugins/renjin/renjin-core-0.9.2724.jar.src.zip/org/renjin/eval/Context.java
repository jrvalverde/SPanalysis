/*     */ package org.renjin.eval;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.vfs2.FileObject;
/*     */ import org.apache.commons.vfs2.FileSystemException;
/*     */ import org.apache.commons.vfs2.FileSystemManager;
/*     */ import org.renjin.base.BaseFrame;
/*     */ import org.renjin.pipeliner.VectorPipeliner;
/*     */ import org.renjin.primitives.Primitives;
/*     */ import org.renjin.primitives.Warning;
/*     */ import org.renjin.primitives.packaging.NamespaceRegistry;
/*     */ import org.renjin.primitives.vector.DeferredComputation;
/*     */ import org.renjin.primitives.vector.MemoizedComputation;
/*     */ import org.renjin.repackaged.guava.collect.Lists;
/*     */ import org.renjin.repackaged.guava.collect.Maps;
/*     */ import org.renjin.sexp.Closure;
/*     */ import org.renjin.sexp.Environment;
/*     */ import org.renjin.sexp.ExpressionVector;
/*     */ import org.renjin.sexp.Function;
/*     */ import org.renjin.sexp.FunctionCall;
/*     */ import org.renjin.sexp.ListVector;
/*     */ import org.renjin.sexp.Null;
/*     */ import org.renjin.sexp.PairList;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.Symbol;
/*     */ import org.renjin.sexp.Symbols;
/*     */ import org.renjin.sexp.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Context
/*     */ {
/*     */   public enum Type
/*     */   {
/*  54 */     TOP_LEVEL,
/*     */ 
/*     */     
/*  57 */     NEXT,
/*     */ 
/*     */     
/*  60 */     BREAK,
/*     */ 
/*     */     
/*  63 */     LOOP,
/*     */ 
/*     */     
/*  66 */     FUNCTION,
/*     */ 
/*     */     
/*  69 */     CCODE,
/*     */ 
/*     */     
/*  72 */     RETURN,
/*     */ 
/*     */     
/*  75 */     BROWSER,
/*     */ 
/*     */     
/*  78 */     GENERIC,
/*     */ 
/*     */     
/*  81 */     RESTART,
/*     */ 
/*     */     
/*  84 */     BUILTIN;
/*     */   }
/*     */   
/*  87 */   private List<SEXP> onExit = Lists.newArrayList();
/*  88 */   private List<SEXP> restarts = null;
/*     */   
/*     */   private Context parent;
/*     */   
/*     */   private int evaluationDepth;
/*     */   
/*     */   private Type type;
/*     */   
/*     */   private Environment environment;
/*     */   
/*     */   private Session session;
/*     */   
/*     */   private FunctionCall call;
/*     */   private SEXP function;
/*     */   private Environment callingEnvironment;
/* 103 */   private PairList arguments = (PairList)Null.INSTANCE;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 110 */   private Map<String, ConditionHandler> conditionHandlers = null;
/*     */   
/* 112 */   private Map<Class, Object> stateMap = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Context() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Context newTopLevelContext() {
/* 126 */     return SessionBuilder.buildDefault().getTopLevelContext();
/*     */   }
/*     */ 
/*     */   
/*     */   Context(Session session) {
/* 131 */     this.session = session;
/* 132 */     this.type = Type.TOP_LEVEL;
/* 133 */     this.environment = session.getGlobalEnvironment();
/* 134 */     this.function = (SEXP)Null.INSTANCE;
/*     */   }
/*     */   
/*     */   public Context beginFunction(Environment rho, FunctionCall call, Closure closure, PairList arguments) {
/* 138 */     assert rho != null : "callingEnvironment cannot be null.";
/* 139 */     Context context = new Context();
/* 140 */     context.type = Type.FUNCTION;
/* 141 */     context.parent = this;
/* 142 */     this.evaluationDepth++;
/* 143 */     context.function = (SEXP)closure;
/* 144 */     context.environment = Environment.createChildEnvironment(closure.getEnclosingEnvironment()).build();
/* 145 */     context.session = this.session;
/* 146 */     context.arguments = arguments;
/* 147 */     context.call = call;
/* 148 */     context.callingEnvironment = rho;
/* 149 */     return context;
/*     */   }
/*     */   
/*     */   public Context beginEvalContext(Environment environment) {
/* 153 */     Context context = new Context();
/* 154 */     context.type = Type.RETURN;
/* 155 */     context.parent = this;
/* 156 */     this.evaluationDepth++;
/* 157 */     context.environment = environment;
/* 158 */     context.session = this.session;
/* 159 */     context.function = (SEXP)Primitives.getInternal(Symbol.get("eval"));
/*     */ 
/*     */     
/* 162 */     context.call = this.call;
/*     */     
/* 164 */     return context;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Context getConditionStack() {
/* 172 */     Context stack = this.session.conditionStack;
/* 173 */     if (stack == null) {
/* 174 */       stack = this;
/*     */     }
/* 176 */     return stack;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SEXP evaluateCallingHandler(Context definitionContext, SEXP handlerCall) {
/* 190 */     this.session.conditionStack = definitionContext.getParent();
/*     */     try {
/* 192 */       return evaluate(handlerCall);
/*     */     } finally {
/* 194 */       this.session.conditionStack = null;
/*     */     } 
/*     */   }
/*     */   public SEXP evaluate(SEXP expression) {
/* 198 */     SEXP result = evaluate(expression, this.environment);
/* 199 */     if (result == null) {
/* 200 */       throw new IllegalStateException("Evaluated to null");
/*     */     }
/* 202 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SEXP materialize(SEXP sexp) {
/* 212 */     if (sexp instanceof Vector) {
/* 213 */       Vector vector = (Vector)sexp;
/* 214 */       if (vector.isDeferred() && !vector.isConstantAccessTime()) {
/* 215 */         return (SEXP)this.session.getVectorEngine().materialize(vector);
/*     */       }
/*     */     } 
/* 218 */     return sexp;
/*     */   }
/*     */   
/*     */   public ListVector materialize(ListVector listVector) {
/* 222 */     if (!anyDeferred(listVector)) {
/* 223 */       return listVector;
/*     */     }
/*     */     
/* 226 */     return this.session.getVectorEngine().materialize(listVector);
/*     */   }
/*     */   
/*     */   private boolean anyDeferred(ListVector listVector) {
/* 230 */     for (int i = 0; i < listVector.length(); i++) {
/* 231 */       SEXP element = listVector.getElementAsSEXP(i);
/* 232 */       if (element instanceof Vector) {
/* 233 */         Vector vector = (Vector)element;
/* 234 */         if (vector.isDeferred() && !vector.isConstantAccessTime()) {
/* 235 */           return true;
/*     */         }
/*     */       } 
/*     */     } 
/* 239 */     return false;
/*     */   }
/*     */   
/*     */   public Vector materialize(Vector sexp) {
/* 243 */     if (sexp.isDeferred() && !sexp.isConstantAccessTime()) {
/* 244 */       return this.session.getVectorEngine().materialize(sexp);
/*     */     }
/* 246 */     return sexp;
/*     */   }
/*     */ 
/*     */   
/*     */   public SEXP simplify(SEXP sexp) {
/* 251 */     if (sexp instanceof MemoizedComputation && ((MemoizedComputation)sexp).isCalculated()) {
/* 252 */       return sexp;
/*     */     }
/*     */     
/* 255 */     if (sexp instanceof DeferredComputation && ((DeferredComputation)sexp)
/* 256 */       .getComputationDepth() > VectorPipeliner.MAX_DEPTH) {
/* 257 */       return (SEXP)this.session.getVectorEngine().simplify((DeferredComputation)sexp);
/*     */     }
/* 259 */     return sexp;
/*     */   }
/*     */ 
/*     */   
/*     */   public SEXP evaluate(SEXP expression, Environment rho) {
/* 264 */     return evaluate(expression, rho, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SEXP evaluate(SEXP expression, Environment rho, boolean allowMissing) {
/* 277 */     if (expression instanceof Symbol)
/* 278 */       return evaluateSymbol((Symbol)expression, rho, allowMissing); 
/* 279 */     if (expression instanceof ExpressionVector)
/* 280 */       return evaluateExpressionVector((ExpressionVector)expression, rho); 
/* 281 */     if (expression instanceof FunctionCall)
/* 282 */       return evaluateCall((FunctionCall)expression, rho); 
/* 283 */     if (expression instanceof org.renjin.sexp.Promise)
/* 284 */       return expression.force(this); 
/* 285 */     if (expression != Null.INSTANCE && expression instanceof org.renjin.sexp.PromisePairList) {
/* 286 */       throw new EvalException("'...' used in an incorrect context", new Object[0]);
/*     */     }
/* 288 */     clearInvisibleFlag();
/* 289 */     return expression;
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T getState(Class<T> clazz) {
/* 294 */     if (this.stateMap != null) {
/* 295 */       return (T)this.stateMap.get(clazz);
/*     */     }
/* 297 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void clearState(Class<?> stateType) {
/* 302 */     this.stateMap.remove(stateType);
/*     */   }
/*     */   
/*     */   public <T> T getSingleton(Class<T> clazz) {
/* 306 */     return this.session.getSingleton(clazz);
/*     */   }
/*     */   
/*     */   public <T> void setState(T instance) {
/* 310 */     setState(instance.getClass(), instance);
/*     */   }
/*     */   
/*     */   public <T> void setState(Class<T> clazz, T instance) {
/* 314 */     if (this.stateMap == null) {
/* 315 */       this.stateMap = Maps.newHashMap();
/*     */     }
/* 317 */     this.stateMap.put(clazz, instance);
/*     */   }
/*     */   
/*     */   private SEXP evaluateSymbol(Symbol symbol, Environment rho, boolean allowMissing) {
/* 321 */     clearInvisibleFlag();
/*     */     
/* 323 */     if (symbol == Symbol.MISSING_ARG) {
/* 324 */       return (SEXP)symbol;
/*     */     }
/*     */     
/* 327 */     if (allowMissing && symbol.isVarArgReference() && 
/* 328 */       rho.findVariable(this, Symbols.ELLIPSES) == Null.INSTANCE) {
/* 329 */       return (SEXP)Symbol.MISSING_ARG;
/*     */     }
/*     */ 
/*     */     
/* 333 */     SEXP value = rho.findVariable(this, symbol);
/* 334 */     if (value == Symbol.UNBOUND_VALUE) {
/* 335 */       throw new EvalException(String.format("object '%s' not found", new Object[] { symbol.getPrintName() }), new Object[0]);
/*     */     }
/*     */     
/* 338 */     if (!allowMissing && 
/* 339 */       value == Symbol.MISSING_ARG) {
/* 340 */       throw new EvalException("argument '%s' is missing, with no default", new Object[] { symbol.getPrintName() });
/*     */     }
/*     */ 
/*     */     
/* 344 */     if (value instanceof org.renjin.sexp.Promise) {
/* 345 */       value = value.force(this, allowMissing);
/*     */     }
/*     */     
/* 348 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addRestart(SEXP restartObject) {
/* 355 */     if (this.restarts == null) {
/* 356 */       this.restarts = new ArrayList<>();
/*     */     }
/* 358 */     this.restarts.add(restartObject);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SEXP getRestart(int index) {
/* 369 */     Context context = this;
/* 370 */     while (!context.isTopLevel()) {
/* 371 */       if (context.restarts != null) {
/* 372 */         for (int i = 0; i < context.restarts.size(); i++, index--) {
/* 373 */           if (index == 0) {
/* 374 */             return context.restarts.get(i);
/*     */           }
/*     */         } 
/*     */       }
/* 378 */       context = context.getParent();
/*     */     } 
/* 380 */     return (SEXP)Null.INSTANCE;
/*     */   }
/*     */   private SEXP evaluateExpressionVector(ExpressionVector expressionVector, Environment rho) {
/*     */     SEXP sEXP;
/* 384 */     if (expressionVector.length() == 0) {
/* 385 */       setInvisibleFlag();
/* 386 */       return (SEXP)Null.INSTANCE;
/*     */     } 
/* 388 */     Null null = Null.INSTANCE;
/* 389 */     for (SEXP sexp : expressionVector) {
/* 390 */       sEXP = evaluate(sexp, rho);
/*     */     }
/* 392 */     return sEXP;
/*     */   }
/*     */ 
/*     */   
/*     */   private SEXP evaluateCall(FunctionCall call, Environment rho) {
/* 397 */     clearInvisibleFlag();
/*     */     
/* 399 */     SEXP fn = call.getFunction();
/* 400 */     Function functionExpr = evaluateFunction(fn, rho);
/*     */     
/* 402 */     boolean profiling = (Profiler.ENABLED && fn instanceof Symbol && !((Symbol)fn).isReservedWord());
/* 403 */     if (Profiler.ENABLED && profiling) {
/* 404 */       Profiler.functionStart((Symbol)fn, functionExpr);
/*     */     }
/*     */     try {
/* 407 */       return functionExpr.apply(this, rho, call, call.getArguments());
/* 408 */     } catch (EvalException|org.renjin.primitives.special.ControlFlowException|ConditionException|Error e) {
/* 409 */       throw e;
/*     */     }
/* 411 */     catch (Exception e) {
/* 412 */       String message = e.getMessage();
/* 413 */       if (message == null) {
/* 414 */         message = e.getClass().getName();
/*     */       }
/* 416 */       throw new EvalException(message, e);
/*     */     } finally {
/*     */       
/* 419 */       if (Profiler.ENABLED && profiling) {
/* 420 */         Profiler.functionEnd();
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private Function evaluateFunction(SEXP functionExp, Environment rho) {
/* 426 */     if (functionExp instanceof Symbol) {
/* 427 */       Symbol symbol = (Symbol)functionExp;
/* 428 */       if (symbol.isReservedWord()) {
/* 429 */         return (Function)Primitives.getReservedBuiltin(symbol);
/*     */       }
/* 431 */       Function fn = rho.findFunction(this, symbol);
/* 432 */       if (fn == null) {
/* 433 */         throw new EvalException("could not find function '%s'", new Object[] { symbol.getPrintName() });
/*     */       }
/* 435 */       return fn;
/*     */     } 
/* 437 */     SEXP evaluated = evaluate(functionExp, rho).force(this);
/* 438 */     if (!(evaluated instanceof Function)) {
/* 439 */       throw new EvalException("'function' of lang expression is of unsupported type '%s'", new Object[] { evaluated.getTypeName() });
/*     */     }
/* 441 */     return (Function)evaluated;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FileSystemManager getFileSystemManager() {
/* 451 */     return this.session.getFileSystemManager();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FileObject resolveFile(String uri) throws FileSystemException {
/* 459 */     return this.session.resolveFile(uri);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Environment getEnvironment() {
/* 467 */     return this.environment;
/*     */   }
/*     */   
/*     */   public Environment getGlobalEnvironment() {
/* 471 */     return this.session.getGlobalEnvironment();
/*     */   }
/*     */   
/*     */   public SEXP getFunction() {
/* 475 */     return this.function;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PairList getArguments() {
/* 487 */     if (this.type != Type.FUNCTION) {
/* 488 */       throw new IllegalStateException("Only Contexts of type FUNCTION contain a FunctionCall");
/*     */     }
/* 490 */     return this.arguments;
/*     */   }
/*     */   
/*     */   public SEXP getFunctionName() {
/* 494 */     return this.call.getFunction();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FunctionCall getCall() {
/* 502 */     return this.call;
/*     */   }
/*     */   
/*     */   public int getEvaluationDepth() {
/* 506 */     return this.evaluationDepth;
/*     */   }
/*     */   
/*     */   public int getFrameDepth() {
/* 510 */     int nframe = 0;
/* 511 */     Context cptr = this;
/* 512 */     while (!cptr.isTopLevel()) {
/* 513 */       if (cptr.getType() == Type.FUNCTION) {
/* 514 */         nframe++;
/*     */       }
/* 516 */       cptr = cptr.getParent();
/*     */     } 
/* 518 */     return nframe;
/*     */   }
/*     */   
/*     */   public Context getParent() {
/* 522 */     return this.parent;
/*     */   }
/*     */   
/*     */   public Session getSession() {
/* 526 */     return this.session;
/*     */   }
/*     */   
/*     */   public Type getType() {
/* 530 */     return this.type;
/*     */   }
/*     */   
/*     */   public boolean isTopLevel() {
/* 534 */     return (this.parent == null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOnExit(SEXP exp) {
/* 546 */     this.onExit = Lists.newArrayList((Object[])new SEXP[] { exp });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addOnExit(SEXP exp) {
/* 557 */     this.onExit.add(exp);
/*     */   }
/*     */ 
/*     */   
/*     */   public void warn(String message) {
/* 562 */     Warning.warning(this, (SEXP)Null.INSTANCE, false, message);
/*     */   }
/*     */   
/*     */   public void warn(FunctionCall call, String message) {
/* 566 */     Warning.warning(this, (SEXP)call, false, message);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clearOnExits() {
/* 573 */     this.onExit = Lists.newArrayList();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void exit() {
/* 580 */     for (SEXP exp : this.onExit) {
/* 581 */       evaluate(exp, this.environment);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConditionHandler(String conditionClass, SEXP function, boolean calling) {
/* 597 */     if (this.conditionHandlers == null) {
/* 598 */       this.conditionHandlers = new HashMap<>();
/*     */     }
/* 600 */     this.conditionHandlers.put(conditionClass, new ConditionHandler(function, calling));
/*     */   }
/*     */   
/*     */   public ConditionHandler getConditionHandler(String conditionClass) {
/* 604 */     if (this.conditionHandlers == null) {
/* 605 */       return null;
/*     */     }
/* 607 */     return this.conditionHandlers.get(conditionClass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void init() throws IOException {
/* 621 */     BaseFrame baseFrame = (BaseFrame)this.session.getBaseEnvironment().getFrame();
/* 622 */     baseFrame.load(this);
/*     */     
/* 624 */     evaluate((SEXP)FunctionCall.newCall((SEXP)Symbol.get(".onLoad"), new SEXP[0]), this.session.getBaseNamespaceEnv());
/*     */   }
/*     */   
/*     */   public void setInvisibleFlag() {
/* 628 */     this.session.invisible = true;
/*     */   }
/*     */   
/*     */   public void clearInvisibleFlag() {
/* 632 */     this.session.invisible = false;
/*     */   }
/*     */   
/*     */   public Environment getCallingEnvironment() {
/* 636 */     return this.callingEnvironment;
/*     */   }
/*     */   
/*     */   public Environment getBaseEnvironment() {
/* 640 */     return this.session.getBaseEnvironment();
/*     */   }
/*     */   
/*     */   public NamespaceRegistry getNamespaceRegistry() {
/* 644 */     return this.session.getNamespaceRegistry();
/*     */   }
/*     */   
/*     */   public void setGlobalVariable(Context context, Symbol symbol, Object value) {
/* 648 */     context.getGlobalEnvironment().setVariable(context, symbol, (SEXP)value);
/*     */   }
/*     */   
/*     */   public void setGlobalVariable(Context context, String name, Object value) {
/* 652 */     setGlobalVariable(context, Symbol.get(name), value);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/eval/Context.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */