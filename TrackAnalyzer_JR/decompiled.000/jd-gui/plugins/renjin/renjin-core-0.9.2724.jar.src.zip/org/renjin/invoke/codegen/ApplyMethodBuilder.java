/*     */ package org.renjin.invoke.codegen;
/*     */ 
/*     */ import com.sun.codemodel.JBlock;
/*     */ import com.sun.codemodel.JCatchBlock;
/*     */ import com.sun.codemodel.JClass;
/*     */ import com.sun.codemodel.JCodeModel;
/*     */ import com.sun.codemodel.JDefinedClass;
/*     */ import com.sun.codemodel.JExpr;
/*     */ import com.sun.codemodel.JExpression;
/*     */ import com.sun.codemodel.JMethod;
/*     */ import com.sun.codemodel.JType;
/*     */ import com.sun.codemodel.JVar;
/*     */ import org.renjin.eval.Context;
/*     */ import org.renjin.eval.EvalException;
/*     */ import org.renjin.invoke.codegen.generic.GenericDispatchStrategy;
/*     */ import org.renjin.invoke.codegen.generic.GroupDispatchStrategy;
/*     */ import org.renjin.invoke.codegen.generic.MatrixMultDispatchStrategy;
/*     */ import org.renjin.invoke.codegen.generic.OpsGroupGenericDispatchStrategy;
/*     */ import org.renjin.invoke.codegen.generic.SimpleDispatchStrategy;
/*     */ import org.renjin.invoke.codegen.generic.SummaryGroupGenericStrategy;
/*     */ import org.renjin.invoke.model.JvmMethod;
/*     */ import org.renjin.invoke.model.PrimitiveModel;
/*     */ import org.renjin.sexp.Environment;
/*     */ import org.renjin.sexp.FunctionCall;
/*     */ import org.renjin.sexp.PairList;
/*     */ import org.renjin.sexp.SEXP;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ApplyMethodBuilder
/*     */   implements ApplyMethodContext
/*     */ {
/*     */   protected JCodeModel codeModel;
/*     */   protected JDefinedClass invoker;
/*     */   protected JVar context;
/*     */   protected JVar environment;
/*     */   protected JVar call;
/*     */   protected JVar args;
/*     */   protected PrimitiveModel primitive;
/*     */   protected JMethod method;
/*     */   protected JVar argumentIterator;
/*     */   protected GenericDispatchStrategy genericDispatchStrategy;
/*     */   
/*     */   public ApplyMethodBuilder(JCodeModel codeModel, JDefinedClass invoker, PrimitiveModel primitive) {
/*  52 */     this.codeModel = codeModel;
/*  53 */     this.invoker = invoker;
/*  54 */     this.primitive = primitive;
/*  55 */     this.genericDispatchStrategy = genericDispatchStrategy(primitive);
/*     */   }
/*     */   
/*     */   public void build() {
/*  59 */     declareMethod();
/*     */     
/*  61 */     ExceptionWrapper mainTryBlock = new ExceptionWrapper(this.codeModel, this.method.body(), (JExpression)this.context);
/*  62 */     catchArgumentExceptions(mainTryBlock);
/*  63 */     mainTryBlock.catchEvalExceptions();
/*  64 */     mainTryBlock.catchRuntimeExceptions();
/*  65 */     mainTryBlock.catchExceptions();
/*     */     
/*  67 */     this.argumentIterator = mainTryBlock.body().decl((JType)classRef(ArgumentIterator.class), "argIt", 
/*  68 */         (JExpression)JExpr._new(classRef(ArgumentIterator.class))
/*  69 */         .arg((JExpression)this.context)
/*  70 */         .arg((JExpression)this.environment)
/*  71 */         .arg((JExpression)this.args));
/*     */ 
/*     */     
/*  74 */     apply(mainTryBlock.body());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JClass classRef(Class<?> clazz) {
/*  80 */     return this.codeModel.ref(clazz);
/*     */   }
/*     */ 
/*     */   
/*     */   public JCodeModel getCodeModel() {
/*  85 */     return this.codeModel;
/*     */   }
/*     */   
/*     */   protected void declareMethod() {
/*  89 */     this.method = this.invoker.method(1, SEXP.class, "apply");
/*  90 */     this.context = this.method.param(Context.class, "context");
/*  91 */     this.environment = this.method.param(Environment.class, "environment");
/*  92 */     this.call = this.method.param(FunctionCall.class, "call");
/*  93 */     this.args = this.method.param(PairList.class, "args");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void apply(JBlock parent) {}
/*     */ 
/*     */ 
/*     */   
/*     */   protected JExpression nextArgAsSexp(boolean evaluated) {
/* 104 */     if (evaluated) {
/* 105 */       return (JExpression)JExpr.invoke((JExpression)this.argumentIterator, "evalNext");
/*     */     }
/* 107 */     return (JExpression)JExpr.invoke((JExpression)this.argumentIterator, "next");
/*     */   }
/*     */ 
/*     */   
/*     */   public void catchArgumentExceptions(ExceptionWrapper mainTryBlock) {
/* 112 */     JCatchBlock catchBlock = mainTryBlock._catch((JClass)this.codeModel._ref(ArgumentException.class));
/* 113 */     JVar e = catchBlock.param("e");
/* 114 */     catchBlock.body()
/* 115 */       ._throw((JExpression)JExpr._new(this.codeModel._ref(EvalException.class))
/* 116 */         .arg((JExpression)this.context)
/* 117 */         .arg(JExpr.lit(this.primitive.argumentErrorMessage()))
/* 118 */         .arg((JExpression)e.invoke("getMessage")));
/*     */   }
/*     */   
/*     */   private GenericDispatchStrategy genericDispatchStrategy(PrimitiveModel primitive) {
/* 122 */     JvmMethod overload = primitive.getOverloads().get(0);
/* 123 */     if (primitive.getName().equals("%*%"))
/* 124 */       return (GenericDispatchStrategy)new MatrixMultDispatchStrategy(this.codeModel); 
/* 125 */     if (overload.isGroupGeneric()) {
/* 126 */       if (overload.getGenericGroup().equals("Ops"))
/* 127 */         return (GenericDispatchStrategy)new OpsGroupGenericDispatchStrategy(this.codeModel, primitive.getName()); 
/* 128 */       if (overload.getGenericGroup().equals("Summary")) {
/* 129 */         return (GenericDispatchStrategy)new SummaryGroupGenericStrategy(this.codeModel, primitive.getName());
/*     */       }
/* 131 */       return (GenericDispatchStrategy)new GroupDispatchStrategy(this.codeModel, overload.getGenericGroup(), primitive.getName());
/*     */     } 
/* 133 */     if (overload.isGeneric()) {
/* 134 */       return (GenericDispatchStrategy)new SimpleDispatchStrategy(this.codeModel, primitive.getName());
/*     */     }
/* 136 */     return new GenericDispatchStrategy(this.codeModel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JExpression getContext() {
/* 143 */     return (JExpression)this.context;
/*     */   }
/*     */ 
/*     */   
/*     */   public JExpression getEnvironment() {
/* 148 */     return (JExpression)this.environment;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/codegen/ApplyMethodBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */