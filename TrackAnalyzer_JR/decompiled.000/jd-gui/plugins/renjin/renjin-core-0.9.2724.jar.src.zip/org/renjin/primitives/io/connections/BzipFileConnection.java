/*    */ package org.renjin.primitives.io.connections;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ import java.nio.charset.Charset;
/*    */ import org.apache.commons.compress.compressors.bzip2.BZip2CompressorOutputStream;
/*    */ import org.apache.commons.vfs2.FileObject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BzipFileConnection
/*    */   extends FileConnection
/*    */ {
/*    */   public BzipFileConnection(FileObject file, Charset charset) throws IOException {
/* 34 */     super(file, charset);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected OutputStream doOpenForOutput() throws IOException {
/* 40 */     return (OutputStream)new BZip2CompressorOutputStream(super.doOpenForOutput());
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/io/connections/BzipFileConnection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */