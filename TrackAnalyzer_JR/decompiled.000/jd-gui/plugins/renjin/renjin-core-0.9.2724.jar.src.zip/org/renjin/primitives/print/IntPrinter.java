/*    */ package org.renjin.primitives.print;
/*    */ 
/*    */ import org.renjin.parser.NumericLiterals;
/*    */ import org.renjin.repackaged.guava.base.Function;
/*    */ import org.renjin.sexp.IntVector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IntPrinter
/*    */   implements Function<Integer, String>
/*    */ {
/*    */   public String apply(Integer integer) {
/* 29 */     if (IntVector.isNA(integer.intValue())) {
/* 30 */       return "NA";
/*    */     }
/* 32 */     return NumericLiterals.format(integer.intValue());
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/print/IntPrinter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */