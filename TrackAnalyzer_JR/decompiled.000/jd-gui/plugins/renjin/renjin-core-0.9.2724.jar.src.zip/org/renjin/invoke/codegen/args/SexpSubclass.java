/*    */ package org.renjin.invoke.codegen.args;
/*    */ 
/*    */ import com.sun.codemodel.JCodeModel;
/*    */ import com.sun.codemodel.JExpr;
/*    */ import com.sun.codemodel.JExpression;
/*    */ import com.sun.codemodel.JType;
/*    */ import com.sun.codemodel.JVar;
/*    */ import org.renjin.invoke.codegen.ApplyMethodContext;
/*    */ import org.renjin.invoke.model.JvmMethod;
/*    */ import org.renjin.sexp.SEXP;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SexpSubclass
/*    */   extends ArgConverterStrategy
/*    */ {
/*    */   public SexpSubclass(JvmMethod.Argument formal) {
/* 38 */     super(formal);
/*    */   }
/*    */   
/*    */   public static boolean accept(JvmMethod.Argument formal) {
/* 42 */     return SEXP.class.isAssignableFrom(formal.getClazz());
/*    */   }
/*    */ 
/*    */   
/*    */   public JExpression convertArgument(ApplyMethodContext parent, JExpression sexp) {
/* 47 */     return (JExpression)JExpr.cast((JType)parent.classRef(this.formal.getClazz()), sexp);
/*    */   }
/*    */ 
/*    */   
/*    */   public JExpression getTestExpr(JCodeModel codeModel, JVar sexpVariable) {
/* 52 */     return sexpVariable._instanceof(codeModel._ref(this.formal.getClazz()));
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/codegen/args/SexpSubclass.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */