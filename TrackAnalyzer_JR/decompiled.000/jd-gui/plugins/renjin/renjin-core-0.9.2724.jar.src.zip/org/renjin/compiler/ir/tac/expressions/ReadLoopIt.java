/*    */ package org.renjin.compiler.ir.tac.expressions;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.renjin.compiler.codegen.EmitContext;
/*    */ import org.renjin.compiler.ir.ValueBounds;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ import org.renjin.repackaged.asm.commons.InstructionAdapter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReadLoopIt
/*    */   implements Expression
/*    */ {
/*    */   public boolean isPure() {
/* 32 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public int load(EmitContext emitContext, InstructionAdapter mv) {
/* 37 */     mv.load(emitContext.getLoopIterationIndex(), Type.INT_TYPE);
/* 38 */     return 1;
/*    */   }
/*    */ 
/*    */   
/*    */   public Type getType() {
/* 43 */     return Type.INT_TYPE;
/*    */   }
/*    */ 
/*    */   
/*    */   public ValueBounds updateTypeBounds(Map<Expression, ValueBounds> typeMap) {
/* 48 */     return ValueBounds.INT_PRIMITIVE;
/*    */   }
/*    */ 
/*    */   
/*    */   public ValueBounds getValueBounds() {
/* 53 */     return ValueBounds.INT_PRIMITIVE;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setChild(int childIndex, Expression child) {
/* 58 */     throw new IllegalArgumentException("no children");
/*    */   }
/*    */ 
/*    */   
/*    */   public int getChildCount() {
/* 63 */     return 0;
/*    */   }
/*    */ 
/*    */   
/*    */   public Expression childAt(int index) {
/* 68 */     throw new IllegalArgumentException("no children");
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 73 */     return "currentLoopIteration()";
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/ir/tac/expressions/ReadLoopIt.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */