/*    */ package org.renjin.primitives.special;
/*    */ 
/*    */ import org.renjin.eval.Context;
/*    */ import org.renjin.eval.EvalException;
/*    */ import org.renjin.sexp.Environment;
/*    */ import org.renjin.sexp.FunctionCall;
/*    */ import org.renjin.sexp.Null;
/*    */ import org.renjin.sexp.PairList;
/*    */ import org.renjin.sexp.SEXP;
/*    */ import org.renjin.sexp.SpecialFunction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OnExitFunction
/*    */   extends SpecialFunction
/*    */ {
/*    */   public OnExitFunction() {
/* 28 */     super("on.exit");
/*    */   }
/*    */ 
/*    */   
/*    */   public SEXP apply(Context context, Environment rho, FunctionCall call, PairList args) {
/* 33 */     EvalException.check((call.getArguments().length() <= 2), "invalid number of arguments", new Object[0]);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 39 */     Context exitContext = findMatchingContext(context, rho);
/*    */     
/* 41 */     if (call.getArguments().length() == 0) {
/*    */       
/* 43 */       exitContext.clearOnExits();
/*    */     }
/*    */     else {
/*    */       
/* 47 */       SEXP value = call.getArgument(0);
/* 48 */       boolean add = false;
/* 49 */       if (call.getArguments().length() == 2) {
/* 50 */         add = (context.evaluate(call.getArgument(1), rho).asReal() != 0.0D);
/*    */       }
/*    */       
/* 53 */       if (add) {
/* 54 */         exitContext.addOnExit(value);
/*    */       } else {
/* 56 */         exitContext.setOnExit(value);
/*    */       } 
/*    */     } 
/*    */ 
/*    */     
/* 61 */     context.setInvisibleFlag();
/* 62 */     return (SEXP)Null.INSTANCE;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private Context findMatchingContext(Context context, Environment rho) {
/*    */     while (true) {
/* 70 */       if (context.getEnvironment() == rho) {
/* 71 */         return context;
/*    */       }
/* 73 */       if (context.getType() == Context.Type.TOP_LEVEL) {
/* 74 */         return context;
/*    */       }
/* 76 */       context = context.getParent();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/special/OnExitFunction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */