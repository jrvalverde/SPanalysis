/*     */ package org.renjin.primitives.packaging;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.renjin.eval.Context;
/*     */ import org.renjin.eval.EvalException;
/*     */ import org.renjin.parser.RParser;
/*     */ import org.renjin.repackaged.guava.collect.Iterables;
/*     */ import org.renjin.repackaged.guava.collect.Lists;
/*     */ import org.renjin.repackaged.guava.collect.Maps;
/*     */ import org.renjin.repackaged.guava.collect.Sets;
/*     */ import org.renjin.repackaged.guava.io.CharSource;
/*     */ import org.renjin.sexp.ExpressionVector;
/*     */ import org.renjin.sexp.FunctionCall;
/*     */ import org.renjin.sexp.Logical;
/*     */ import org.renjin.sexp.LogicalVector;
/*     */ import org.renjin.sexp.Null;
/*     */ import org.renjin.sexp.PairList;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.StringVector;
/*     */ import org.renjin.sexp.Symbol;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NamespaceFile
/*     */ {
/*     */   public static class DynLibEntry
/*     */   {
/*     */     private String libraryName;
/*  47 */     private String prefix = "";
/*     */     
/*     */     private boolean registration;
/*  50 */     private List<NamespaceFile.DynLibSymbol> symbols = new ArrayList<>();
/*     */     
/*     */     public String getLibraryName() {
/*  53 */       return this.libraryName;
/*     */     }
/*     */     
/*     */     public String getPrefix() {
/*  57 */       return this.prefix;
/*     */     }
/*     */     
/*     */     public boolean isRegistration() {
/*  61 */       return this.registration;
/*     */     }
/*     */     
/*     */     public List<NamespaceFile.DynLibSymbol> getSymbols() {
/*  65 */       return this.symbols;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class DynLibSymbol {
/*     */     private String alias;
/*     */     private String symbolName;
/*     */     private String fixes;
/*     */     
/*     */     private DynLibSymbol(String alias, String symbolName) {
/*  75 */       this.alias = alias;
/*  76 */       this.symbolName = symbolName;
/*     */     }
/*     */     
/*     */     private DynLibSymbol(String symbolName) {
/*  80 */       this.symbolName = symbolName;
/*  81 */       this.alias = symbolName;
/*     */     }
/*     */     
/*     */     public String getAlias() {
/*  85 */       return this.alias;
/*     */     }
/*     */     
/*     */     public String getSymbolName() {
/*  89 */       return this.symbolName;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class PackageImportEntry {
/*     */     private String packageName;
/*     */     private boolean allSymbols;
/*  96 */     private List<Symbol> symbols = Lists.newArrayList();
/*  97 */     private List<String> classes = Lists.newArrayList();
/*  98 */     private List<String> methods = Lists.newArrayList();
/*     */     
/*     */     public PackageImportEntry(String packageName) {
/* 101 */       this.packageName = packageName;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getPackageName() {
/* 108 */       return this.packageName;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isAllSymbols() {
/* 116 */       return this.allSymbols;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public List<Symbol> getSymbols() {
/* 124 */       return this.symbols;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public List<String> getClasses() {
/* 132 */       return this.classes;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public List<String> getMethods() {
/* 140 */       return this.methods;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class JvmClassImportEntry {
/*     */     private String className;
/*     */     private boolean classImported;
/* 147 */     private Set<String> methods = new HashSet<>();
/*     */     
/*     */     public JvmClassImportEntry(String className) {
/* 150 */       this.className = className;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getClassName() {
/* 157 */       return this.className;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isClassImported() {
/* 165 */       return this.classImported;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Set<String> getMethods() {
/* 173 */       return this.methods;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class S3MethodEntry {
/*     */     private String genericMethod;
/*     */     private String className;
/*     */     private String functionName;
/*     */     
/*     */     private S3MethodEntry(String genericMethod, String className) {
/* 183 */       this.genericMethod = genericMethod;
/* 184 */       this.className = className;
/* 185 */       this.functionName = genericMethod + "." + className;
/*     */     }
/*     */     
/*     */     private S3MethodEntry(String genericMethod, String className, String functionName) {
/* 189 */       this.genericMethod = genericMethod;
/* 190 */       this.className = className;
/* 191 */       this.functionName = functionName;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getGenericMethod() {
/* 199 */       return this.genericMethod;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getClassName() {
/* 207 */       return this.className;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getFunctionName() {
/* 214 */       return this.functionName;
/*     */     }
/*     */   }
/*     */   
/* 218 */   private Map<String, PackageImportEntry> packageImports = Maps.newHashMap();
/* 219 */   private Map<String, JvmClassImportEntry> jvmImports = Maps.newHashMap();
/* 220 */   private List<DynLibEntry> dynLibEntries = Lists.newArrayList();
/*     */   
/* 222 */   private Set<String> exportedPatterns = Sets.newHashSet();
/* 223 */   private Set<Symbol> exportedSymbols = Sets.newHashSet();
/* 224 */   private List<S3MethodEntry> exportedS3Methods = Lists.newArrayList();
/* 225 */   private List<String> exportedS4Methods = Lists.newArrayList();
/* 226 */   private Set<String> exportedClasses = Sets.newHashSet();
/* 227 */   private Set<String> exportedClassPatterns = Sets.newHashSet();
/*     */   
/*     */   public static NamespaceFile parseFile(Context context, CharSource charSource) throws IOException {
/* 230 */     ExpressionVector source = parseSexp(charSource);
/* 231 */     return parseFile(context, source);
/*     */   }
/*     */   
/*     */   public static NamespaceFile parseFile(Context context, ExpressionVector source) {
/* 235 */     NamespaceFile file = new NamespaceFile();
/* 236 */     file.parse(context, source);
/* 237 */     return file;
/*     */   }
/*     */   
/*     */   public static ExpressionVector parseSexp(CharSource charSource) throws IOException {
/*     */     ExpressionVector source;
/* 242 */     try (Reader reader = charSource.openStream()) {
/* 243 */       source = RParser.parseAllSource(reader);
/*     */     } 
/* 245 */     return source;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private PackageImportEntry packageImport(String packageName) {
/* 252 */     PackageImportEntry entry = this.packageImports.get(packageName);
/* 253 */     if (entry == null) {
/* 254 */       entry = new PackageImportEntry(packageName);
/* 255 */       this.packageImports.put(packageName, entry);
/*     */     } 
/* 257 */     return entry;
/*     */   }
/*     */   
/*     */   private PackageImportEntry packageImport(SEXP argument) {
/* 261 */     return packageImport(parseStringArgument(argument));
/*     */   }
/*     */   
/*     */   private JvmClassImportEntry classImport(String className) {
/* 265 */     JvmClassImportEntry entry = this.jvmImports.get(className);
/* 266 */     if (entry == null) {
/* 267 */       entry = new JvmClassImportEntry(className);
/* 268 */       this.jvmImports.put(className, entry);
/*     */     } 
/* 270 */     return entry;
/*     */   }
/*     */   
/*     */   private void parse(Context context, ExpressionVector source) {
/* 274 */     for (SEXP exp : source) {
/* 275 */       parse(context, exp);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void parse(Context context, SEXP exp) {
/* 281 */     if (exp instanceof ExpressionVector) {
/* 282 */       parse(context, (ExpressionVector)exp);
/*     */     }
/* 284 */     else if (exp instanceof FunctionCall) {
/* 285 */       FunctionCall call = (FunctionCall)exp;
/* 286 */       parseCall(context, call);
/*     */     } else {
/*     */       
/* 289 */       throw new EvalException("Unknown NAMESPACE directive: " + exp.toString(), new Object[0]);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void parseCall(Context context, FunctionCall call) {
/* 294 */     String directiveName = parseDirectiveName(call);
/* 295 */     if (directiveName.equals("import")) {
/* 296 */       parseImport(call);
/* 297 */     } else if (directiveName.equals("importClass") || directiveName
/* 298 */       .equals("importClasses")) {
/* 299 */       parseImportClass(call);
/* 300 */     } else if (directiveName.equals("importFrom")) {
/* 301 */       parseImportFrom(call);
/* 302 */     } else if (directiveName.equals("importFromClass")) {
/* 303 */       parseImportFromClass(call);
/* 304 */     } else if (directiveName
/* 305 */       .equals("importClassFrom") || directiveName
/* 306 */       .equals("importClassesFrom")) {
/* 307 */       parseImportS4ClassesFrom(call);
/* 308 */     } else if (directiveName.equals("importMethodsFrom")) {
/* 309 */       parseImportS4MethodsFrom(call);
/* 310 */     } else if (directiveName.equals("S3method")) {
/* 311 */       parseS3Export(call);
/* 312 */     } else if (directiveName.equals("export") || directiveName
/* 313 */       .equals("exports")) {
/* 314 */       parseExport(call);
/* 315 */     } else if (directiveName.equals("exportPattern") || directiveName
/* 316 */       .equals("exportPatterns")) {
/* 317 */       parseExportPattern(call);
/* 318 */     } else if (directiveName.equals("useDynLib")) {
/* 319 */       parseDynlib(call);
/* 320 */     } else if (directiveName.equals("exportClasses") || directiveName
/* 321 */       .equals("exportClass")) {
/* 322 */       parseExportClasses(call);
/* 323 */     } else if (directiveName.equals("exportClassPattern") || directiveName
/* 324 */       .equals("exportClassPatterns")) {
/* 325 */       parseExportClassPatterns(call);
/* 326 */     } else if (directiveName.equals("exportMethods") || directiveName
/* 327 */       .equals("exportMethod")) {
/* 328 */       parseExportMethods(call);
/* 329 */     } else if (directiveName.equals("if")) {
/* 330 */       parseIf(context, call);
/*     */     }
/* 332 */     else if (directiveName.equals("{")) {
/* 333 */       for (SEXP sexp : call.getArguments().values()) {
/* 334 */         parse(context, sexp);
/*     */       }
/*     */     } else {
/* 337 */       throw new EvalException("Unknown NAMESPACE directive '" + directiveName + "'", new Object[0]);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void parseIf(Context context, FunctionCall call) {
/* 343 */     SEXP condition = call.getArgument(0);
/*     */     
/* 345 */     SEXP evaluatedCondition = context.evaluate(condition, context.getBaseEnvironment());
/*     */     
/* 347 */     if (isTruthy(evaluatedCondition)) {
/* 348 */       parse(context, call.getArgument(1));
/*     */     }
/* 350 */     else if (call.getArguments().length() == 3) {
/* 351 */       parse(context, call.getArgument(2));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isTruthy(SEXP s) {
/* 357 */     if (s.length() == 0) {
/* 358 */       throw new EvalException("argument is of length zero", new Object[0]);
/*     */     }
/*     */     
/* 361 */     Logical logical = s.asLogical();
/* 362 */     if (logical == Logical.NA) {
/* 363 */       throw new EvalException("missing value where TRUE/FALSE needed", new Object[0]);
/*     */     }
/*     */     
/* 366 */     return (logical == Logical.TRUE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void parseExportPattern(FunctionCall call) {
/* 376 */     this.exportedPatterns.addAll(parseNameArguments(call));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void parseExport(FunctionCall call) {
/* 384 */     for (SEXP argument : call.getArguments().values()) {
/* 385 */       this.exportedSymbols.add(parseSymbolArgument(argument));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void parseImport(FunctionCall call) {
/* 395 */     for (String packageName : parseNameArguments(call)) {
/* 396 */       (packageImport(packageName)).allSymbols = true;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void parseImportFrom(FunctionCall call) {
/* 407 */     if (call.getArguments().length() < 1) {
/* 408 */       throw new EvalException("Expected at least one arguments to importFrom directive", new Object[0]);
/*     */     }
/* 410 */     PackageImportEntry packageImport = packageImport(call.getArgument(0));
/*     */     
/* 412 */     for (int i = 1; i < call.getArguments().length(); i++) {
/* 413 */       packageImport.symbols.add(parseSymbolArgument(call.getArgument(i)));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void parseImportS4ClassesFrom(FunctionCall call) {
/* 423 */     if (call.getArguments().length() < 2) {
/* 424 */       throw new EvalException("Expected at least two arguments to importClassesFrom directive", new Object[0]);
/*     */     }
/*     */     
/* 427 */     PackageImportEntry packageImport = packageImport(call.getArgument(0));
/*     */     
/* 429 */     for (int i = 1; i < call.getArguments().length(); i++) {
/* 430 */       packageImport.classes.add(parseStringArgument(call.getArgument(i)));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void parseImportS4MethodsFrom(FunctionCall call) {
/* 440 */     if (call.getArguments().length() < 2) {
/* 441 */       throw new EvalException("Expected at least two arguments to importMethodsFrom directive", new Object[0]);
/*     */     }
/*     */     
/* 444 */     PackageImportEntry packageImport = packageImport(call.getArgument(0));
/*     */     
/* 446 */     for (int i = 1; i < call.getArguments().length(); i++) {
/* 447 */       packageImport.methods.add(parseStringArgument(call.getArgument(i)));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void parseImportClass(FunctionCall call) {
/* 459 */     for (String className : parseNameArguments(call)) {
/* 460 */       (classImport(className)).classImported = true;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void parseImportFromClass(FunctionCall call) {
/* 472 */     if (call.getArguments().length() < 2) {
/* 473 */       throw new EvalException("Expected at least two arguments to importFromClass directive", new Object[0]);
/*     */     }
/* 475 */     String className = parseStringArgument(call.getArgument(0));
/* 476 */     JvmClassImportEntry entry = classImport(className);
/* 477 */     for (int i = 1; i < call.getArguments().length(); i++) {
/* 478 */       String methodName = parseStringArgument(call.getArgument(i));
/* 479 */       entry.methods.add(methodName);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static List<String> parseNameArguments(FunctionCall call) {
/* 484 */     List<String> names = Lists.newArrayList();
/* 485 */     for (SEXP argument : call.getArguments().values()) {
/* 486 */       names.add(parseStringArgument(argument));
/*     */     }
/* 488 */     return names;
/*     */   }
/*     */ 
/*     */   
/*     */   private static Symbol parseSymbolArgument(SEXP argument) {
/* 493 */     if (argument instanceof Symbol)
/* 494 */       return (Symbol)argument; 
/* 495 */     if (argument instanceof StringVector && argument.length() == 1) {
/* 496 */       return Symbol.get(((StringVector)argument).getElementAsString(0));
/*     */     }
/* 498 */     throw new EvalException("Can't parse directive argument '" + argument + "' as symbol", new Object[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   private static String parseStringArgument(SEXP argument) {
/* 503 */     if (argument instanceof StringVector && argument.length() == 1)
/* 504 */       return ((StringVector)argument).getElementAsString(0); 
/* 505 */     if (argument instanceof Symbol) {
/* 506 */       return ((Symbol)argument).getPrintName();
/*     */     }
/* 508 */     throw new EvalException("Can't parse directive argument '" + argument + "' as string", new Object[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   private static String parseDirectiveName(FunctionCall call) {
/* 513 */     if (call.getFunction() instanceof Symbol) {
/* 514 */       return ((Symbol)call.getFunction()).getPrintName();
/*     */     }
/* 516 */     throw new EvalException("Unknown NAMESPACE directive: " + call, new Object[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   private void parseS3Export(FunctionCall call) {
/* 521 */     if (call.getArguments().length() == 2) {
/* 522 */       if (call.getArgument(1) == Null.INSTANCE) {
/*     */ 
/*     */         
/* 525 */         this.exportedSymbols.add(parseSymbolArgument(call.getArgument(0)));
/*     */       }
/*     */       else {
/*     */         
/* 529 */         this.exportedS3Methods.add(new S3MethodEntry(
/* 530 */               parseStringArgument(call.getArgument(0)), 
/* 531 */               parseStringArgument(call.getArgument(1))));
/*     */       } 
/* 533 */     } else if (call.getArguments().length() == 3) {
/* 534 */       this.exportedS3Methods.add(new S3MethodEntry(
/* 535 */             parseStringArgument(call.getArgument(0)), 
/* 536 */             parseStringArgument(call.getArgument(1)), 
/* 537 */             parseStringArgument(call.getArgument(2))));
/*     */     } else {
/* 539 */       throw new UnsupportedOperationException("Expected 2 or 3 arguments to S3Method directive");
/*     */     } 
/*     */   }
/*     */   
/*     */   private void parseExportClasses(FunctionCall call) {
/* 544 */     this.exportedClasses.addAll(parseNameArguments(call));
/*     */   }
/*     */   
/*     */   private void parseExportClassPatterns(FunctionCall call) {
/* 548 */     this.exportedClassPatterns.addAll(parseNameArguments(call));
/*     */   }
/*     */ 
/*     */   
/*     */   private void parseExportMethods(FunctionCall call) {
/* 553 */     this.exportedS4Methods.addAll(parseNameArguments(call));
/*     */   }
/*     */ 
/*     */   
/*     */   private void parseDynlib(FunctionCall call) {
/* 558 */     if (call.getArguments().length() < 1) {
/* 559 */       throw new EvalException("Expected at least one argument to useDynlib", new Object[0]);
/*     */     }
/*     */     
/* 562 */     DynLibEntry entry = new DynLibEntry();
/* 563 */     entry.libraryName = parseStringArgument(call.getArgument(0));
/*     */     
/* 565 */     for (PairList.Node node : Iterables.skip(call.getArguments().nodes(), 1)) {
/* 566 */       if (node.hasTag()) {
/*     */         
/* 568 */         if (node.getTag().getPrintName().equals(".registration")) {
/* 569 */           entry.registration = parseLogical(node.getValue()); continue;
/* 570 */         }  if (node.getTag().getPrintName().equals(".fixes")) {
/* 571 */           entry.prefix = parseStringArgument(node.getValue());
/*     */           continue;
/*     */         } 
/* 574 */         entry.symbols.add(new DynLibSymbol(
/* 575 */               parseStringArgument((SEXP)node.getTag()), 
/* 576 */               parseStringArgument(node.getValue())));
/*     */         
/*     */         continue;
/*     */       } 
/* 580 */       entry.symbols.add(new DynLibSymbol(
/* 581 */             parseStringArgument(node.getValue())));
/*     */     } 
/*     */     
/* 584 */     this.dynLibEntries.add(entry);
/*     */   }
/*     */   
/*     */   private static boolean parseLogical(SEXP value) {
/* 588 */     if (value instanceof LogicalVector && value.length() == 1) {
/* 589 */       return (((LogicalVector)value).getElementAsRawLogical(0) == 1);
/*     */     }
/* 591 */     throw new EvalException("Expected TRUE or FALSE", new Object[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<PackageImportEntry> getPackageImports() {
/* 600 */     return this.packageImports.values();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<JvmClassImportEntry> getJvmImports() {
/* 608 */     return this.jvmImports.values();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<DynLibEntry> getDynLibEntries() {
/* 622 */     return this.dynLibEntries;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getExportedPatterns() {
/* 630 */     return this.exportedPatterns;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<Symbol> getExportedSymbols() {
/* 638 */     return this.exportedSymbols;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<S3MethodEntry> getExportedS3Methods() {
/* 647 */     return this.exportedS3Methods;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getExportedClasses() {
/* 655 */     return this.exportedClasses;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getExportedClassPatterns() {
/* 664 */     return this.exportedClassPatterns;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getExportedS4Methods() {
/* 672 */     return this.exportedS4Methods;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/packaging/NamespaceFile.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */