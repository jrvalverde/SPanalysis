/*    */ package org.renjin.parser;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Position
/*    */ {
/*    */   private int line;
/*    */   private int column;
/*    */   private int charIndex;
/*    */   
/*    */   public Position() {}
/*    */   
/*    */   public Position(int line, int column, int charIndex) {
/* 37 */     this.line = line;
/* 38 */     this.column = column;
/* 39 */     this.charIndex = charIndex;
/*    */   }
/*    */ 
/*    */   
/*    */   public Position clone() {
/* 44 */     return new Position(getLine(), getColumn(), getCharIndex());
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 49 */     if (this == o) {
/* 50 */       return true;
/*    */     }
/* 52 */     if (o == null || getClass() != o.getClass()) {
/* 53 */       return false;
/*    */     }
/*    */     
/* 56 */     Position position = (Position)o;
/*    */     
/* 58 */     if (getCharIndex() != position.getCharIndex()) {
/* 59 */       return false;
/*    */     }
/* 61 */     if (getColumn() != position.getColumn()) {
/* 62 */       return false;
/*    */     }
/* 64 */     if (getLine() != position.getLine()) {
/* 65 */       return false;
/*    */     }
/*    */     
/* 68 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 73 */     int result = getLine();
/* 74 */     result = 31 * result + getColumn();
/* 75 */     result = 31 * result + getCharIndex();
/* 76 */     return result;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 81 */     return "line " + (getLine() + 1) + " byte " + (getCharIndex() + 1) + " col " + (getColumn() + 1);
/*    */   }
/*    */   
/*    */   public int getLine() {
/* 85 */     return this.line;
/*    */   }
/*    */   
/*    */   public int getColumn() {
/* 89 */     return this.column;
/*    */   }
/*    */   
/*    */   public int getCharIndex() {
/* 93 */     return this.charIndex;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/parser/Position.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */