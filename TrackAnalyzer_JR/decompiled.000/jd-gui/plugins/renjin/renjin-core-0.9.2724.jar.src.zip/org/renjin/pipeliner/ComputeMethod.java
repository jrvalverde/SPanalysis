/*    */ package org.renjin.pipeliner;
/*    */ 
/*    */ import org.renjin.repackaged.asm.MethodVisitor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ComputeMethod
/*    */ {
/* 27 */   private int localCount = 2;
/*    */   
/*    */   private MethodVisitor visitor;
/* 30 */   private int maxStackSize = 0;
/* 31 */   private int currentStack = 0;
/*    */   
/*    */   public ComputeMethod(MethodVisitor visitor) {
/* 34 */     this.visitor = visitor;
/*    */   }
/*    */   
/*    */   public MethodVisitor getVisitor() {
/* 38 */     return this.visitor;
/*    */   }
/*    */   
/*    */   public int reserveLocal(int size) {
/* 42 */     int pos = this.localCount;
/* 43 */     this.localCount += size;
/* 44 */     return pos;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int declareCounter() {
/* 54 */     int localVar = reserveLocal(1);
/* 55 */     this.visitor.visitInsn(3);
/* 56 */     this.visitor.visitVarInsn(54, localVar);
/* 57 */     return localVar;
/*    */   }
/*    */   
/*    */   public void stack(int change) {
/* 61 */     this.currentStack += change;
/* 62 */     if (this.currentStack > this.maxStackSize) {
/* 63 */       this.maxStackSize = this.currentStack;
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getOperandsLocalIndex() {
/* 72 */     return 1;
/*    */   }
/*    */   
/*    */   public int getMaxLocals() {
/* 76 */     return this.localCount;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/pipeliner/ComputeMethod.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */