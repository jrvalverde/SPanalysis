/*     */ package org.renjin.primitives.combine;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.renjin.primitives.combine.view.CombinedDoubleVector;
/*     */ import org.renjin.primitives.combine.view.CombinedIntVector;
/*     */ import org.renjin.primitives.combine.view.CombinedStringVector;
/*     */ import org.renjin.repackaged.guava.collect.Lists;
/*     */ import org.renjin.sexp.AttributeMap;
/*     */ import org.renjin.sexp.DoubleVector;
/*     */ import org.renjin.sexp.IntVector;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.StringVector;
/*     */ import org.renjin.sexp.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LazyBuilder
/*     */   implements CombinedBuilder
/*     */ {
/*     */   private final Vector.Type vectorType;
/*     */   private int elementCount;
/*     */   private boolean useNames;
/*     */   private List<Vector> vectors;
/*     */   private List<Vector> nameVectors;
/*     */   private boolean hasNames = false;
/*     */   
/*     */   public LazyBuilder(Vector.Type vectorType, int elementCount) {
/*  40 */     this.vectorType = vectorType;
/*  41 */     this.elementCount = elementCount;
/*  42 */     this.vectors = Lists.newArrayListWithCapacity(elementCount);
/*     */   }
/*     */ 
/*     */   
/*     */   public CombinedBuilder useNames(boolean useNames) {
/*  47 */     if (useNames) {
/*  48 */       this.useNames = true;
/*  49 */       this.nameVectors = Lists.newArrayListWithCapacity(this.elementCount);
/*     */     } 
/*  51 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public void add(String prefix, SEXP sexp) {
/*  56 */     throw new UnsupportedOperationException("LazyCombiner can only handle Vector inputs");
/*     */   }
/*     */ 
/*     */   
/*     */   public void addElements(String prefix, Vector vectorElement) {
/*  61 */     this.vectors.add(vectorElement);
/*     */     
/*  63 */     if (this.useNames) {
/*  64 */       this.nameVectors.add(CombinedNames.combine(prefix, vectorElement));
/*  65 */       if (CombinedNames.hasNames(prefix, vectorElement)) {
/*  66 */         this.hasNames = true;
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public static boolean resultTypeSupported(Vector.Type vectorType) {
/*  72 */     return (vectorType == IntVector.VECTOR_TYPE || vectorType == DoubleVector.VECTOR_TYPE || vectorType == StringVector.VECTOR_TYPE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector build() {
/*  80 */     Vector[] vectors = toArray(this.vectors);
/*  81 */     if (this.vectorType == IntVector.VECTOR_TYPE) {
/*  82 */       return (Vector)CombinedIntVector.combine(vectors, buildAttributes());
/*     */     }
/*  84 */     if (this.vectorType == DoubleVector.VECTOR_TYPE) {
/*  85 */       return (Vector)CombinedDoubleVector.combine(vectors, buildAttributes());
/*     */     }
/*  87 */     if (this.vectorType == StringVector.VECTOR_TYPE) {
/*  88 */       return (Vector)CombinedStringVector.combine(vectors, buildAttributes());
/*     */     }
/*     */ 
/*     */     
/*  92 */     throw new UnsupportedOperationException("vector type: " + this.vectorType);
/*     */   }
/*     */ 
/*     */   
/*     */   private AttributeMap buildAttributes() {
/*  97 */     if (this.hasNames) {
/*  98 */       return (new AttributeMap.Builder())
/*  99 */         .setNames(CombinedStringVector.combine(this.nameVectors, AttributeMap.EMPTY))
/* 100 */         .build();
/*     */     }
/* 102 */     return AttributeMap.EMPTY;
/*     */   }
/*     */ 
/*     */   
/*     */   private Vector[] toArray(List<Vector> list) {
/* 107 */     return list.<Vector>toArray(new Vector[list.size()]);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/combine/LazyBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */