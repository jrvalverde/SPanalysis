/*    */ package org.renjin.compiler.builtins;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import org.renjin.compiler.codegen.EmitContext;
/*    */ import org.renjin.compiler.ir.ValueBounds;
/*    */ import org.renjin.compiler.ir.tac.IRArgument;
/*    */ import org.renjin.compiler.ir.tac.expressions.Expression;
/*    */ import org.renjin.invoke.model.JvmMethod;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ import org.renjin.repackaged.asm.commons.InstructionAdapter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DataParallelScalarCall
/*    */   implements Specialization
/*    */ {
/*    */   private final JvmMethod method;
/*    */   private final ValueBounds valueBounds;
/*    */   private final boolean constant;
/*    */   
/*    */   public DataParallelScalarCall(JvmMethod method, List<ValueBounds> argumentBounds, ValueBounds resultBounds) {
/* 42 */     this.method = method;
/* 43 */     this.valueBounds = resultBounds;
/* 44 */     this.constant = ValueBounds.allConstant(argumentBounds);
/*    */   }
/*    */   
/*    */   public Specialization trySpecializeFurther() {
/* 48 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public Type getType() {
/* 53 */     return Type.getType(this.method.getReturnType());
/*    */   }
/*    */   
/*    */   public ValueBounds getResultBounds() {
/* 57 */     return this.valueBounds;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void load(EmitContext emitContext, InstructionAdapter mv, List<IRArgument> arguments) {
/* 63 */     Iterator<IRArgument> argumentIt = arguments.iterator();
/*    */     
/* 65 */     for (JvmMethod.Argument formal : this.method.getAllArguments()) {
/* 66 */       if (formal.isContextual()) {
/* 67 */         throw new UnsupportedOperationException("TODO");
/*    */       }
/* 69 */       if (formal.isRecycle()) {
/* 70 */         Expression argument = ((IRArgument)argumentIt.next()).getExpression();
/* 71 */         argument.load(emitContext, mv);
/* 72 */         emitContext.convert(mv, argument.getType(), Type.getType(formal.getClazz()));
/*    */       } 
/*    */     } 
/*    */     
/* 76 */     mv.invokestatic(Type.getInternalName(this.method.getDeclaringClass()), this.method.getName(), 
/* 77 */         Type.getMethodDescriptor(this.method.getMethod()), false);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isPure() {
/* 82 */     return this.method.isPure();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/builtins/DataParallelScalarCall.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */