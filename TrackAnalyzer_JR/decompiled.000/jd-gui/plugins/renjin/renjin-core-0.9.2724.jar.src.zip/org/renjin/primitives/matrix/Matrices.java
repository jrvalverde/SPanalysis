/*     */ package org.renjin.primitives.matrix;
/*     */ 
/*     */ import org.renjin.eval.Context;
/*     */ import org.renjin.eval.EvalException;
/*     */ import org.renjin.invoke.annotations.Builtin;
/*     */ import org.renjin.invoke.annotations.Current;
/*     */ import org.renjin.invoke.annotations.Generic;
/*     */ import org.renjin.invoke.annotations.Internal;
/*     */ import org.renjin.primitives.Indexes;
/*     */ import org.renjin.primitives.sequence.RepDoubleVector;
/*     */ import org.renjin.primitives.sequence.RepLogicalVector;
/*     */ import org.renjin.primitives.vector.ComputingIntVector;
/*     */ import org.renjin.sexp.AtomicVector;
/*     */ import org.renjin.sexp.AttributeMap;
/*     */ import org.renjin.sexp.DoubleArrayVector;
/*     */ import org.renjin.sexp.DoubleVector;
/*     */ import org.renjin.sexp.IntArrayVector;
/*     */ import org.renjin.sexp.IntVector;
/*     */ import org.renjin.sexp.ListVector;
/*     */ import org.renjin.sexp.Null;
/*     */ import org.renjin.sexp.PairList;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.StringArrayVector;
/*     */ import org.renjin.sexp.StringVector;
/*     */ import org.renjin.sexp.Symbol;
/*     */ import org.renjin.sexp.Symbols;
/*     */ import org.renjin.sexp.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Matrices
/*     */ {
/*     */   @Internal("t.default")
/*     */   public static Vector transpose(Vector x) {
/*  43 */     Vector dimensions = x.getAttributes().getDim();
/*     */     
/*  45 */     if (dimensions.length() == 0) {
/*  46 */       return transposeVector(x);
/*     */     }
/*  48 */     if (dimensions.length() == 1) {
/*  49 */       return transposeArray(x);
/*     */     }
/*  51 */     if (dimensions.length() == 2) {
/*  52 */       int nrows = dimensions.getElementAsInt(0);
/*  53 */       int ncols = dimensions.getElementAsInt(1);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  58 */       AttributeMap.Builder attributes = new AttributeMap.Builder();
/*  59 */       attributes.setDim(ncols, nrows);
/*  60 */       attributes.set(Symbols.DIMNAMES, transposeDimNames(x));
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  65 */       if (x instanceof DoubleVector && x.length() > 0)
/*     */       {
/*  67 */         return (Vector)new TransposingMatrix(x, attributes.build());
/*     */       }
/*     */ 
/*     */       
/*  71 */       Vector.Builder builder = x.newBuilderWithInitialSize(x.length());
/*     */       
/*  73 */       for (int i = 0; i < nrows; i++) {
/*  74 */         for (int j = 0; j < ncols; j++) {
/*  75 */           builder.setFrom(Indexes.matrixIndexToVectorIndex(j, i, ncols, nrows), (SEXP)x, 
/*  76 */               Indexes.matrixIndexToVectorIndex(i, j, nrows, ncols));
/*     */         }
/*     */       } 
/*  79 */       return (Vector)builder.build().setAttributes(attributes.build());
/*     */     } 
/*     */     
/*  82 */     throw new EvalException("argument is not a matrix", new Object[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Vector transposeVector(Vector x) {
/*  91 */     AttributeMap.Builder matrixDims = AttributeMap.builder();
/*  92 */     matrixDims.setDim(1, x.length());
/*     */ 
/*     */     
/*  95 */     if (x.getNames() != Null.INSTANCE) {
/*  96 */       matrixDims.setDimNames((SEXP)new ListVector(new SEXP[] { (SEXP)Null.INSTANCE, (SEXP)x.getNames() }));
/*     */     }
/*     */ 
/*     */     
/* 100 */     for (Symbol attribute : x.getAttributes().names()) {
/* 101 */       if (attribute != Symbols.NAMES && attribute != Symbols.DIM && attribute != Symbols.DIMNAMES)
/*     */       {
/*     */         
/* 104 */         matrixDims.set(attribute, x.getAttribute(attribute));
/*     */       }
/*     */     } 
/* 107 */     return (Vector)x.setAttributes(matrixDims);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Vector transposeArray(Vector x) {
/* 115 */     AttributeMap.Builder matrixDims = AttributeMap.builder();
/* 116 */     matrixDims.setDim(1, x.length());
/*     */     
/* 118 */     Vector dimNameList = x.getAttributes().getDimNames();
/* 119 */     if (dimNameList != Null.INSTANCE) {
/* 120 */       AttributeMap.Builder dimNameAttributes = AttributeMap.builder();
/* 121 */       Null null = Null.INSTANCE;
/* 122 */       Vector colNames = (Vector)dimNameList.getElementAsSEXP(0);
/*     */       
/* 124 */       if (dimNameList.getNames() != Null.INSTANCE) {
/* 125 */         String name = dimNameList.getNames().getElementAsString(0);
/* 126 */         dimNameAttributes.setNames((StringVector)new StringArrayVector(new String[] { "", name }));
/*     */       } 
/* 128 */       matrixDims.setDimNames((SEXP)new ListVector(new SEXP[] { (SEXP)null, (SEXP)colNames }, dimNameAttributes.build()));
/*     */     } 
/*     */ 
/*     */     
/* 132 */     for (Symbol attribute : x.getAttributes().names()) {
/* 133 */       if (attribute != Symbols.NAMES && attribute != Symbols.DIM && attribute != Symbols.DIMNAMES)
/*     */       {
/*     */         
/* 136 */         matrixDims.set(attribute, x.getAttribute(attribute));
/*     */       }
/*     */     } 
/* 139 */     return (Vector)x.setAttributes(matrixDims);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static SEXP transposeDimNames(Vector x) {
/* 147 */     Vector dimNames = x.getAttributes().getDimNames();
/* 148 */     if (dimNames == Null.INSTANCE) {
/* 149 */       return (SEXP)Null.INSTANCE;
/*     */     }
/*     */     
/* 152 */     ListVector dimNameList = (ListVector)dimNames;
/* 153 */     SEXP rowNames = dimNameList.getElementAsSEXP(0);
/* 154 */     SEXP colNames = dimNameList.getElementAsSEXP(1);
/*     */ 
/*     */     
/* 157 */     AttributeMap.Builder transposedAttributes = AttributeMap.builder();
/* 158 */     if (dimNameList.getNames() != Null.INSTANCE) {
/* 159 */       transposedAttributes.setNames((StringVector)new StringArrayVector(new String[] { dimNameList.getName(1), dimNameList.getName(0) }));
/*     */     }
/* 161 */     return (SEXP)new ListVector(new SEXP[] { colNames, rowNames }, transposedAttributes.build());
/*     */   }
/*     */ 
/*     */   
/*     */   @Builtin("%*%")
/*     */   @Generic(S3 = false, S4 = true)
/*     */   public static SEXP matrixproduct(AtomicVector x, AtomicVector y) {
/* 168 */     return (SEXP)(new MatrixProduct(0, x, y)).compute();
/*     */   }
/*     */   
/*     */   @Internal("crossprod")
/*     */   public static SEXP crossprod(AtomicVector x, AtomicVector y) {
/* 173 */     return (SEXP)(new MatrixProduct(1, x, y)).compute();
/*     */   }
/*     */   
/*     */   @Internal("tcrossprod")
/*     */   public static SEXP tcrossprod(AtomicVector x, AtomicVector y) {
/* 178 */     return (SEXP)(new MatrixProduct(2, x, y)).compute();
/*     */   }
/*     */   
/*     */   @Internal
/*     */   public static DoubleVector rowSums(AtomicVector x, int numRows, int rowLength, boolean naRm) {
/* 183 */     double[] sums = new double[numRows];
/* 184 */     int sourceIndex = 0;
/* 185 */     for (int col = 0; col < rowLength; col++) {
/* 186 */       for (int row = 0; row < numRows; row++) {
/* 187 */         double value = x.getElementAsDouble(sourceIndex++);
/* 188 */         if (!naRm) {
/* 189 */           sums[row] = sums[row] + value;
/* 190 */         } else if (!Double.isNaN(value)) {
/* 191 */           sums[row] = sums[row] + value;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 196 */     return (DoubleVector)DoubleArrayVector.unsafe(sums);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Internal
/*     */   public static DoubleVector rowMeans(AtomicVector x, int numRows, int rowLength, boolean naRm) {
/* 204 */     if (!naRm && x.isDeferred()) {
/* 205 */       return new DeferredRowMeans(x, numRows, AttributeMap.EMPTY);
/*     */     }
/*     */     
/* 208 */     double[] sums = new double[numRows];
/* 209 */     int[] counts = new int[numRows];
/* 210 */     int sourceIndex = 0;
/* 211 */     for (int col = 0; col < rowLength; col++) {
/* 212 */       for (int i = 0; i < numRows; i++) {
/* 213 */         double value = x.getElementAsDouble(sourceIndex++);
/* 214 */         if (!naRm) {
/* 215 */           sums[i] = sums[i] + value;
/* 216 */           counts[i] = counts[i] + 1;
/* 217 */         } else if (!Double.isNaN(value)) {
/* 218 */           sums[i] = sums[i] + value;
/* 219 */           counts[i] = counts[i] + 1;
/*     */         } 
/*     */       } 
/*     */     } 
/* 223 */     for (int row = 0; row < numRows; row++) {
/* 224 */       sums[row] = sums[row] / counts[row];
/*     */     }
/* 226 */     return (DoubleVector)DoubleArrayVector.unsafe(sums);
/*     */   }
/*     */   
/*     */   @Internal
/*     */   public static DoubleVector colSums(AtomicVector x, int columnLength, int numColumns, boolean naRm) {
/* 231 */     DeferredColSums dcs = new DeferredColSums(x, numColumns, naRm, AttributeMap.EMPTY);
/* 232 */     if (System.getProperty("renjin.disable.colsums") != null) {
/* 233 */       return (DoubleVector)dcs.forceResult();
/*     */     }
/* 235 */     return dcs;
/*     */   }
/*     */   
/*     */   @Internal
/*     */   public static DoubleVector colMeans(AtomicVector x, int columnLength, int numColumns, boolean naRm) {
/* 240 */     double[] sums = new double[numColumns];
/* 241 */     int[] counts = new int[numColumns];
/*     */     
/* 243 */     for (int column = 0; column < numColumns; column++) {
/* 244 */       int sourceIndex = columnLength * column;
/*     */       
/* 246 */       double sum = 0.0D;
/* 247 */       int count = 0;
/* 248 */       for (int row = 0; row < columnLength; row++) {
/* 249 */         double cellValue = x.getElementAsDouble(sourceIndex++);
/* 250 */         if (Double.isNaN(cellValue)) {
/* 251 */           if (!naRm) {
/* 252 */             sum = DoubleVector.NA;
/*     */             break;
/*     */           } 
/*     */         } else {
/* 256 */           sum += cellValue;
/* 257 */           count++;
/*     */         } 
/*     */       } 
/* 260 */       sums[column] = sum;
/* 261 */       counts[column] = count;
/*     */     } 
/*     */     
/* 264 */     for (int i = 0; i != sums.length; i++) {
/* 265 */       sums[i] = sums[i] / counts[i];
/*     */     }
/*     */     
/* 268 */     return (DoubleVector)new DoubleArrayVector(sums);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Internal
/*     */   public static SEXP aperm(Vector source, AtomicVector permutationVector, boolean resize) {
/* 285 */     if (!resize) {
/* 286 */       throw new UnsupportedOperationException("resize=TRUE not yet implemented");
/*     */     }
/*     */     
/* 289 */     Vector vector = source.getAttributes().getDim();
/* 290 */     EvalException.check(vector instanceof IntVector, "invalid first argument, must be an array", new Object[0]);
/* 291 */     int[] permutation = toPermutationArray((Vector)permutationVector);
/*     */     
/* 293 */     if (isIdentityPermutation(permutation))
/*     */     {
/*     */ 
/*     */       
/* 297 */       return (SEXP)source;
/*     */     }
/* 299 */     if (source instanceof DoubleVector && isMatrixTransposition(permutation) && source
/* 300 */       .length() > 0)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 306 */       return (SEXP)transpose(source);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 313 */     int[] dim = ((IntVector)vector).toIntArray();
/* 314 */     int[] permutedDims = Indexes.permute(dim, permutation);
/*     */     
/* 316 */     Vector.Builder newVector = source.newBuilderWithInitialSize(source.length());
/* 317 */     int[] index = new int[dim.length];
/* 318 */     for (int i = 0; i != newVector.length(); i++) {
/* 319 */       Indexes.vectorIndexToArrayIndex(i, index, dim);
/* 320 */       index = Indexes.permute(index, permutation);
/* 321 */       int newIndex = Indexes.arrayIndexToVectorIndex(index, permutedDims);
/* 322 */       newVector.setFrom(newIndex, (SEXP)source, i);
/*     */     } 
/*     */     
/* 325 */     newVector.setAttribute(Symbols.DIM, (SEXP)new IntArrayVector(permutedDims));
/*     */     
/* 327 */     for (PairList.Node node : source.getAttributes().nodes()) {
/* 328 */       if (node.getTag().equals(Symbols.DIM))
/*     */         continue; 
/* 330 */       if (node.getTag().equals(Symbols.DIMNAMES)) {
/* 331 */         newVector.setAttribute(node.getName(), (SEXP)Indexes.permute((Vector)node.getValue(), permutation)); continue;
/*     */       } 
/* 333 */       newVector.setAttribute(node.getName(), node.getValue());
/*     */     } 
/*     */     
/* 336 */     return (SEXP)newVector.build();
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isMatrixTransposition(int[] permutation) {
/* 341 */     return (permutation.length == 2 && permutation[0] == 1 && permutation[1] == 0);
/*     */   }
/*     */   
/*     */   public static boolean isIdentityPermutation(int[] permutation) {
/* 345 */     for (int i = 0; i != permutation.length; i++) {
/* 346 */       if (permutation[i] != i) {
/* 347 */         return false;
/*     */       }
/*     */     } 
/* 350 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int[] toPermutationArray(Vector vector) {
/* 359 */     int[] values = new int[vector.length()];
/* 360 */     for (int i = 0; i != values.length; i++) {
/* 361 */       values[i] = vector.getElementAsInt(i) - 1;
/*     */     }
/* 363 */     return values;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Internal
/*     */   public static Vector matrix(@Current Context context, Vector data, int nrow, int ncol, boolean byRow, Vector dimnames, boolean nrowMissing, boolean ncolMissing) {
/* 383 */     if (data == Null.INSTANCE) {
/* 384 */       throw new EvalException("'data' must be of vector type, was 'NULL'", new Object[0]);
/*     */     }
/*     */     
/* 387 */     int dataLength = data.length();
/*     */ 
/*     */ 
/*     */     
/* 391 */     if (nrow != 1) {
/* 392 */       nrowMissing = false;
/*     */     }
/* 394 */     if (ncol != 1) {
/* 395 */       ncolMissing = false;
/*     */     }
/*     */ 
/*     */     
/* 399 */     if (nrowMissing && ncolMissing) {
/* 400 */       nrow = dataLength;
/* 401 */     } else if (nrowMissing) {
/* 402 */       nrow = (int)Math.ceil(dataLength / ncol);
/* 403 */     } else if (ncolMissing) {
/* 404 */       ncol = (int)Math.ceil(dataLength / nrow);
/*     */     } 
/*     */     
/* 407 */     if (dataLength > 0) {
/* 408 */       if (dataLength > 1 && nrow * ncol % dataLength != 0) {
/* 409 */         if ((dataLength > nrow && dataLength / nrow * nrow != dataLength) || (dataLength < nrow && nrow / dataLength * dataLength != nrow)) {
/*     */ 
/*     */           
/* 412 */           context.warn(String.format("data length [%d] is not a sub-multiple or multiple of the number of rows [%d]", new Object[] {
/*     */                   
/* 414 */                   Integer.valueOf(dataLength), Integer.valueOf(nrow)
/*     */                 }));
/* 416 */         } else if ((dataLength > ncol && dataLength / ncol * ncol != dataLength) || (dataLength < ncol && ncol / dataLength * dataLength != ncol)) {
/*     */ 
/*     */           
/* 419 */           context.warn(String.format("data length [%d] is not a sub-multiple or multiple of the number of columns [%d]", new Object[] {
/*     */                   
/* 421 */                   Integer.valueOf(dataLength), Integer.valueOf(ncol) }));
/*     */         } 
/* 423 */       } else if (dataLength > 1 && nrow * ncol == 0) {
/* 424 */         context.warn("data length exceeds size of matrix");
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 432 */     AttributeMap attributes = AttributeMap.builder().setDim(nrow, ncol).set(Symbols.DIMNAMES, (SEXP)dimnames).build();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 437 */     int resultLength = nrow * ncol;
/* 438 */     if (!byRow && data instanceof AtomicVector && resultLength == data.length()) {
/* 439 */       return (Vector)data.setAttributes(attributes);
/*     */     }
/* 441 */     if (!byRow && resultLength > 500 && 
/* 442 */       data instanceof DoubleVector) {
/* 443 */       return (Vector)new RepDoubleVector(data, resultLength, 1, attributes);
/*     */     }
/*     */     
/* 446 */     return allocMatrix(data, nrow, ncol, byRow, dimnames);
/*     */   }
/*     */   
/*     */   private static Vector allocMatrix(Vector data, int nrow, int ncol, boolean byRow, Vector dimnames) {
/* 450 */     Vector.Builder result = null;
/* 451 */     int dataLength = data.length();
/* 452 */     int outLength = nrow * ncol;
/*     */     
/* 454 */     if (dataLength == 1 && outLength > 0 && data instanceof org.renjin.sexp.LogicalVector) {
/*     */ 
/*     */       
/* 457 */       RepLogicalVector.Builder builder = RepLogicalVector.newConstantBuilder(data.getElementAsLogical(0), outLength);
/*     */     } else {
/* 459 */       result = data.newBuilderWithInitialSize(nrow * ncol);
/* 460 */       if (dataLength > 0) {
/* 461 */         int i = 0;
/* 462 */         if (!byRow) {
/* 463 */           for (int col = 0; col < ncol; col++) {
/* 464 */             for (int row = 0; row < nrow; row++) {
/* 465 */               int sourceIndex = Indexes.matrixIndexToVectorIndex(row, col, nrow, ncol) % dataLength;
/* 466 */               result.setFrom(i++, (SEXP)data, sourceIndex);
/*     */             } 
/*     */           } 
/*     */         } else {
/* 470 */           for (int row = 0; row < nrow; row++) {
/* 471 */             for (int col = 0; col < ncol; col++) {
/* 472 */               result.setFrom(row + col * nrow, (SEXP)data, i % dataLength);
/* 473 */               i++;
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 480 */     result.setDim(nrow, ncol);
/* 481 */     result.setAttribute(Symbols.DIMNAMES, (SEXP)dimnames);
/* 482 */     return result.build();
/*     */   }
/*     */   
/*     */   @Internal
/*     */   public static IntVector row(IntVector dims) {
/* 487 */     if (dims.length() != 2) {
/* 488 */       throw new EvalException("a matrix-like object is required as argument to 'row/col'", new Object[0]);
/*     */     }
/* 490 */     final int rows = dims.getElementAsInt(0);
/* 491 */     int cols = dims.getElementAsInt(1);
/*     */     
/* 493 */     ComputingIntVector.Functor fn = new ComputingIntVector.Functor()
/*     */       {
/*     */         public int apply(int index) {
/* 496 */           return index % rows + 1;
/*     */         }
/*     */       };
/*     */     
/* 500 */     return (IntVector)new ComputingIntVector(fn, rows * cols, AttributeMap.dim(rows, cols));
/*     */   }
/*     */   
/*     */   @Internal
/*     */   public static IntVector col(IntVector dims) {
/* 505 */     if (dims.length() != 2) {
/* 506 */       throw new EvalException("a matrix-like object is required as argument to 'row/col'", new Object[0]);
/*     */     }
/* 508 */     final int rows = dims.getElementAsInt(0);
/* 509 */     int cols = dims.getElementAsInt(1);
/*     */     
/* 511 */     ComputingIntVector.Functor fn = new ComputingIntVector.Functor()
/*     */       {
/*     */         public int apply(int index) {
/* 514 */           return index / rows + 1;
/*     */         }
/*     */       };
/* 517 */     return (IntVector)new ComputingIntVector(fn, rows * cols, AttributeMap.dim(rows, cols));
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/matrix/Matrices.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */