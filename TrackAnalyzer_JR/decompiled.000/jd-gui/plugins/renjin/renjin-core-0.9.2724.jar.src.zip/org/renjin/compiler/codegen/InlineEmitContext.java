/*    */ package org.renjin.compiler.codegen;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.renjin.compiler.cfg.ControlFlowGraph;
/*    */ import org.renjin.repackaged.asm.Label;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ import org.renjin.repackaged.asm.commons.InstructionAdapter;
/*    */ import org.renjin.repackaged.guava.collect.Maps;
/*    */ import org.renjin.sexp.Symbol;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InlineEmitContext
/*    */   extends EmitContext
/*    */ {
/* 33 */   private Map<Symbol, InlineParamExpr> inlinedParameters = Maps.newHashMap();
/*    */   
/*    */   private final Label exitLabel;
/*    */   
/*    */   public InlineEmitContext(ControlFlowGraph cfg, int paramCount, VariableSlots childSlots) {
/* 38 */     super(cfg, paramCount, childSlots);
/* 39 */     this.exitLabel = new Label();
/*    */   }
/*    */   
/*    */   public InlineParamExpr getInlineParameter(Symbol param) {
/* 43 */     InlineParamExpr paramExpr = this.inlinedParameters.get(param);
/* 44 */     if (paramExpr == null) {
/* 45 */       throw new IllegalStateException("No expression set for parameter " + param);
/*    */     }
/* 47 */     return paramExpr;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setInlineParameter(Symbol parameterName, InlineParamExpr value) {
/* 52 */     this.inlinedParameters.put(parameterName, value);
/*    */   }
/*    */ 
/*    */   
/*    */   public void loadParam(InstructionAdapter mv, Symbol param) {
/* 57 */     InlineParamExpr value = this.inlinedParameters.get(param);
/* 58 */     value.load(mv);
/*    */   }
/*    */ 
/*    */   
/*    */   public void writeReturn(InstructionAdapter mv, Type returnType) {
/* 63 */     mv.goTo(this.exitLabel);
/*    */   }
/*    */ 
/*    */   
/*    */   public void writeDone(InstructionAdapter mv) {
/* 68 */     super.writeDone(mv);
/* 69 */     mv.mark(this.exitLabel);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/codegen/InlineEmitContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */