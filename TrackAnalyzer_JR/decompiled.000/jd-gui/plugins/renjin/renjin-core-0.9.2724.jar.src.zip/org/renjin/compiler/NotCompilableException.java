/*    */ package org.renjin.compiler;
/*    */ 
/*    */ import org.renjin.eval.Context;
/*    */ import org.renjin.primitives.Deparse;
/*    */ import org.renjin.sexp.FunctionCall;
/*    */ import org.renjin.sexp.SEXP;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NotCompilableException
/*    */   extends RuntimeException
/*    */ {
/*    */   private SEXP sexp;
/*    */   
/*    */   public NotCompilableException(SEXP sexp) {
/* 31 */     super("unsupported expression");
/* 32 */     this.sexp = sexp;
/*    */   }
/*    */   
/*    */   public NotCompilableException(SEXP sexp, String message) {
/* 36 */     super(message);
/* 37 */     this.sexp = sexp;
/*    */   }
/*    */   
/*    */   public NotCompilableException(FunctionCall call, NotCompilableException cause) {
/* 41 */     super(" in " + call.getFunction(), cause);
/*    */   }
/*    */   
/*    */   public SEXP getSexp() {
/* 45 */     return this.sexp;
/*    */   }
/*    */   
/*    */   public NotCompilableException getCause() {
/* 49 */     return (NotCompilableException)super.getCause();
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString(Context context) {
/* 54 */     NotCompilableException e = this;
/* 55 */     StringBuilder s = new StringBuilder();
/* 56 */     while (e != null) {
/* 57 */       if (s.length() > 0) {
/* 58 */         s.append(" > ");
/*    */       }
/* 60 */       if (e.getSexp() != null) {
/* 61 */         s.append(Deparse.deparseExp(context, e.getSexp()));
/*    */       }
/* 63 */       if (e.getMessage() != null) {
/* 64 */         s.append(": ").append(e.getMessage());
/*    */       }
/* 66 */       e = e.getCause();
/*    */     } 
/* 68 */     return s.toString();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/NotCompilableException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */