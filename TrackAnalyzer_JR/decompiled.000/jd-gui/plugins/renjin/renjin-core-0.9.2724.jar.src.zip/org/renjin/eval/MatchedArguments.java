/*     */ package org.renjin.eval;
/*     */ 
/*     */ import org.renjin.sexp.PromisePairList;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.Symbol;
/*     */ import org.renjin.sexp.Symbols;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MatchedArguments
/*     */ {
/*     */   private SEXP[] actualTags;
/*     */   private final SEXP[] actualValues;
/*     */   private final MatchedArgumentPositions matchedPositions;
/*     */   
/*     */   public MatchedArguments(MatchedArgumentPositions matchedPositions, SEXP[] actualTags, SEXP[] actualValues) {
/*  36 */     this.actualTags = actualTags;
/*  37 */     this.actualValues = actualValues;
/*  38 */     this.matchedPositions = matchedPositions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFormalCount() {
/*  46 */     return this.matchedPositions.getFormalCount();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isFormalEllipses(int formalIndex) {
/*  53 */     return (this.matchedPositions.getFormalName(formalIndex) == Symbols.ELLIPSES);
/*     */   }
/*     */   
/*     */   public Symbol getFormalName(int formalIndex) {
/*  57 */     return this.matchedPositions.getFormalName(formalIndex);
/*     */   }
/*     */   
/*     */   public PromisePairList buildExtraArgumentList() {
/*  61 */     PromisePairList.Builder promises = new PromisePairList.Builder();
/*  62 */     for (int actualIndex = 0; actualIndex < this.actualValues.length; actualIndex++) {
/*  63 */       if (this.matchedPositions.isExtraArgument(actualIndex)) {
/*  64 */         promises.add(this.actualTags[actualIndex], this.actualValues[actualIndex]);
/*     */       }
/*     */     } 
/*  67 */     return promises.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getActualIndex(int formalIndex) {
/*  75 */     return this.matchedPositions.getActualIndex(formalIndex);
/*     */   }
/*     */   
/*     */   public SEXP getActualValue(int actualIndex) {
/*  79 */     return this.actualValues[actualIndex];
/*     */   }
/*     */   
/*     */   public boolean areAllFormalsMatched() {
/*  83 */     return this.matchedPositions.allFormalsMatched();
/*     */   }
/*     */   
/*     */   public SEXP getActualForFormal(int formalIndex, SEXP defaultValue) {
/*  87 */     int actualIndex = getActualIndex(formalIndex);
/*  88 */     if (actualIndex == -1) {
/*  89 */       return defaultValue;
/*     */     }
/*  91 */     return this.actualValues[actualIndex];
/*     */   }
/*     */ 
/*     */   
/*     */   public SEXP getActualForFormal(int formalIndex) {
/*  96 */     int actualIndex = getActualIndex(formalIndex);
/*  97 */     if (actualIndex == -1) {
/*  98 */       throw new EvalException("Arugment \"" + getFormalName(formalIndex).getPrintName() + "\" is missing, with no default", new Object[0]);
/*     */     }
/* 100 */     return this.actualValues[actualIndex];
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/eval/MatchedArguments.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */