/*     */ package org.renjin.packaging;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.function.Predicate;
/*     */ import org.renjin.eval.Context;
/*     */ import org.renjin.primitives.io.serialization.RDataWriter;
/*     */ import org.renjin.repackaged.guava.io.Files;
/*     */ import org.renjin.sexp.Environment;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.Symbol;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LazyLoadFrameBuilder
/*     */ {
/*     */   private static final int VERSION_1 = 1;
/*     */   private static final int VERSION_2 = 2;
/*     */   private File outputDir;
/*     */   private Context context;
/*     */   private Predicate<SEXP> filter = x -> true;
/*  45 */   private Set<String> excludedSymbols = Collections.emptySet();
/*     */ 
/*     */   
/*     */   public LazyLoadFrameBuilder(Context context) {
/*  49 */     this.context = context;
/*     */   }
/*     */   
/*     */   public LazyLoadFrameBuilder outputTo(File dir) {
/*  53 */     this.outputDir = dir;
/*  54 */     return this;
/*     */   }
/*     */   
/*     */   public LazyLoadFrameBuilder filter(Predicate<SEXP> filter) {
/*  58 */     this.filter = filter;
/*  59 */     return this;
/*     */   }
/*     */   
/*     */   public LazyLoadFrameBuilder excludeSymbols(Set<String> excludedSymbols) {
/*  63 */     this.excludedSymbols = excludedSymbols;
/*  64 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void build(Environment env) throws IOException {
/*  71 */     File indexFile = new File(this.outputDir, "environment");
/*  72 */     try (DataOutputStream indexOut = new DataOutputStream(new FileOutputStream(indexFile))) {
/*     */ 
/*     */       
/*  75 */       indexOut.writeInt(2);
/*     */ 
/*     */       
/*  78 */       List<Symbol> symbols = new ArrayList<>();
/*  79 */       for (Symbol symbol : env.getFrame().getSymbols()) {
/*  80 */         if (!this.excludedSymbols.contains(symbol.getPrintName())) {
/*  81 */           SEXP value = env.getFrame().getVariable(symbol);
/*  82 */           if (this.filter.test(value)) {
/*  83 */             symbols.add(symbol);
/*     */           }
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/*  90 */       indexOut.writeInt(symbols.size());
/*     */       
/*  92 */       for (Symbol symbol : symbols) {
/*  93 */         SEXP variable = env.getFrame().getVariable(symbol);
/*     */         
/*  95 */         indexOut.writeUTF(symbol.getPrintName());
/*  96 */         byte[] bytes = serializeSymbol(variable);
/*     */         
/*  98 */         if (bytes.length > 1024) {
/*  99 */           indexOut.writeInt(-1);
/* 100 */           Files.write(bytes, new File(this.outputDir, SerializedPromise.resourceName(symbol.getPrintName()))); continue;
/*     */         } 
/* 102 */         indexOut.writeInt(bytes.length);
/* 103 */         indexOut.write(bytes);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private byte[] serializeSymbol(SEXP value) throws IOException {
/* 110 */     ByteArrayOutputStream baos = new ByteArrayOutputStream();
/* 111 */     RDataWriter writer = new RDataWriter(this.context, baos);
/* 112 */     writer.serialize(value);
/* 113 */     baos.close();
/* 114 */     return baos.toByteArray();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/packaging/LazyLoadFrameBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */