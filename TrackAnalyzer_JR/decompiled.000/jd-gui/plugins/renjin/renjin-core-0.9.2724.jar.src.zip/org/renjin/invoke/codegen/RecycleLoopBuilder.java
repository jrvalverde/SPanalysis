/*     */ package org.renjin.invoke.codegen;
/*     */ 
/*     */ import com.sun.codemodel.JArrayCompRef;
/*     */ import com.sun.codemodel.JAssignmentTarget;
/*     */ import com.sun.codemodel.JBlock;
/*     */ import com.sun.codemodel.JClass;
/*     */ import com.sun.codemodel.JCodeModel;
/*     */ import com.sun.codemodel.JConditional;
/*     */ import com.sun.codemodel.JExpr;
/*     */ import com.sun.codemodel.JExpression;
/*     */ import com.sun.codemodel.JForLoop;
/*     */ import com.sun.codemodel.JInvocation;
/*     */ import com.sun.codemodel.JStatement;
/*     */ import com.sun.codemodel.JType;
/*     */ import com.sun.codemodel.JVar;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.renjin.invoke.annotations.AllowNull;
/*     */ import org.renjin.invoke.annotations.PreserveAttributeStyle;
/*     */ import org.renjin.invoke.codegen.scalars.ScalarType;
/*     */ import org.renjin.invoke.codegen.scalars.ScalarTypes;
/*     */ import org.renjin.invoke.model.JvmMethod;
/*     */ import org.renjin.invoke.model.PrimitiveModel;
/*     */ import org.renjin.repackaged.guava.collect.Lists;
/*     */ import org.renjin.repackaged.guava.collect.Maps;
/*     */ import org.renjin.sexp.AttributeMap;
/*     */ import org.renjin.sexp.Null;
/*     */ import org.renjin.sexp.Symbols;
/*     */ import org.renjin.sexp.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RecycleLoopBuilder
/*     */ {
/*     */   private JCodeModel codeModel;
/*     */   private JBlock parent;
/*     */   private PrimitiveModel primitive;
/*     */   private JvmMethod overload;
/*     */   private final JExpression contextVar;
/*     */   
/*     */   private class RecycledArgument
/*     */   {
/*     */     private JvmMethod.Argument formal;
/*     */     private ScalarType scalarType;
/*     */     private JExpression sexp;
/*     */     private JVar vector;
/*     */     private JVar length;
/*     */     private JVar currentElementIndex;
/*     */     private JVar currentElement;
/*     */     
/*     */     public RecycledArgument(JvmMethod.Argument argument, JExpression parameter) {
/*  59 */       this.formal = argument;
/*  60 */       this.scalarType = ScalarTypes.get(this.formal.getClazz());
/*  61 */       this.sexp = parameter;
/*  62 */       this.vector = RecycleLoopBuilder.this.parent.decl((JType)RecycleLoopBuilder.this.codeModel.ref(Vector.class), "vector" + this.formal.getIndex(), 
/*  63 */           (JExpression)JExpr.cast((JType)RecycleLoopBuilder.this.codeModel.ref(Vector.class), this.sexp));
/*  64 */       this.length = RecycleLoopBuilder.this.parent.decl(RecycleLoopBuilder.this.codeModel._ref(int.class), "length" + this.formal.getIndex(), (JExpression)this.vector
/*  65 */           .invoke("length"));
/*  66 */       this.currentElementIndex = RecycleLoopBuilder.this.parent.decl(RecycleLoopBuilder.this.codeModel._ref(int.class), "currentElementIndex" + this.formal.getIndex(), JExpr.lit(0));
/*  67 */       this.currentElement = RecycleLoopBuilder.this.parent.decl(RecycleLoopBuilder.this.codeModel._ref(this.scalarType.getElementStorageType()), "s" + this.formal.getIndex());
/*     */     }
/*     */     
/*     */     public JType getVectorType() {
/*  71 */       return (JType)RecycleLoopBuilder.this.codeModel.ref(this.scalarType.getVectorType());
/*     */     }
/*     */     
/*     */     public JExpression isCurrentElementNA() {
/*  75 */       return this.scalarType.testNaExpr(RecycleLoopBuilder.this.codeModel, this.currentElement);
/*     */     }
/*     */     
/*     */     public JExpression getCurrentElement() {
/*  79 */       return (JExpression)this.vector.invoke(this.scalarType.getAccessorMethod()).arg((JExpression)this.currentElementIndex);
/*     */     }
/*     */     
/*     */     public JExpression getCurrentElementInScalarType() {
/*  83 */       return this.scalarType.fromElementStorageType((JExpression)this.currentElement);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  97 */   private List<RecycledArgument> recycledArguments = Lists.newArrayList();
/*  98 */   private Map<JvmMethod.Argument, JExpression> argumentMap = Maps.newHashMap();
/*     */ 
/*     */   
/*     */   private JVar cycleCount;
/*     */ 
/*     */   
/*     */   private JVar cycleIndex;
/*     */ 
/*     */   
/*     */   private ScalarType resultType;
/*     */   
/*     */   private boolean useArray;
/*     */   
/*     */   private JVar builder;
/*     */ 
/*     */   
/*     */   public RecycleLoopBuilder(JCodeModel codeModel, JBlock parent, JExpression contextVar, PrimitiveModel primitive, JvmMethod overload, Map<JvmMethod.Argument, JExpression> argumentMap) {
/* 115 */     this.codeModel = codeModel;
/* 116 */     this.parent = parent;
/* 117 */     this.contextVar = contextVar;
/* 118 */     this.primitive = primitive;
/* 119 */     this.overload = overload;
/* 120 */     this.resultType = ScalarTypes.get(overload.getReturnType());
/*     */     
/* 122 */     for (JvmMethod.Argument argument : overload.getAllArguments()) {
/* 123 */       if (argument.isRecycle()) {
/* 124 */         RecycledArgument recycledArgument = new RecycledArgument(argument, argumentMap.get(argument));
/* 125 */         this.recycledArguments.add(recycledArgument);
/* 126 */         this.argumentMap.put(argument, recycledArgument.getCurrentElementInScalarType()); continue;
/*     */       } 
/* 128 */       this.argumentMap.put(argument, argumentMap.get(argument));
/*     */     } 
/*     */ 
/*     */     
/* 132 */     this.useArray = (this.recycledArguments.size() <= 2 && (this.resultType instanceof org.renjin.invoke.codegen.scalars.DoubleType || this.resultType instanceof org.renjin.invoke.codegen.scalars.IntegerType || this.resultType instanceof org.renjin.invoke.codegen.scalars.BooleanType));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void build() {
/* 140 */     computeResultLength();
/* 141 */     initializeBuilder();
/* 142 */     loop();
/* 143 */     if (!this.useArray) {
/* 144 */       copyAttributesUsingBuilder();
/*     */     }
/* 146 */     this.parent._return(buildResult());
/*     */   }
/*     */   
/*     */   private void computeResultLength() {
/* 150 */     this.cycleCount = this.parent.decl(this.codeModel._ref(int.class), "cycles");
/*     */     
/* 152 */     if (this.recycledArguments.size() == 1) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 157 */       if ((this.recycledArguments.get(0)).formal.getAnnotation(AllowNull.class) == null) {
/* 158 */         this.parent._if((this.recycledArguments.get(0)).sexp.eq((JExpression)this.codeModel.ref(Null.class).staticRef("INSTANCE")))
/* 159 */           ._then()
/* 160 */           ._throw((JExpression)JExpr._new(this.codeModel.ref(ArgumentException.class)).arg(JExpr.lit("invalid NULL argument to unary function")));
/*     */       }
/*     */       
/* 163 */       this.parent.assign((JAssignmentTarget)this.cycleCount, (JExpression)(this.recycledArguments.get(0)).length);
/*     */     } else {
/*     */       
/* 166 */       JConditional zeroLength = this.parent._if(anyZeroLength());
/* 167 */       zeroLength._then().assign((JAssignmentTarget)this.cycleCount, JExpr.lit(0));
/* 168 */       findLongestArgument(zeroLength._else());
/*     */     } 
/*     */     
/* 171 */     if (this.overload.isDeferrable()) {
/* 172 */       DeferredVectorBuilder deferred = new DeferredVectorBuilder(this.codeModel, this.contextVar, this.primitive, this.overload);
/* 173 */       deferred.buildClass();
/* 174 */       deferred.maybeReturn(this.parent, (JExpression)this.cycleCount, deferredArgumentList(), copyAttributesFast());
/*     */     } 
/*     */   }
/*     */   
/*     */   private void findLongestArgument(JBlock parent) {
/* 179 */     parent.assign((JAssignmentTarget)this.cycleCount, JExpr.lit(0));
/* 180 */     for (RecycledArgument arg : this.recycledArguments) {
/* 181 */       parent._if(arg.length.gt((JExpression)this.cycleCount))._then().assign((JAssignmentTarget)this.cycleCount, (JExpression)arg.length);
/*     */     }
/*     */   }
/*     */   
/*     */   private JExpression anyZeroLength() {
/* 186 */     Iterator<RecycledArgument> iterator = this.recycledArguments.iterator();
/* 187 */     JExpression expr = (iterator.next()).length.eq(JExpr.lit(0));
/* 188 */     while (iterator.hasNext()) {
/* 189 */       expr = expr.cor((iterator.next()).length.eq(JExpr.lit(0)));
/*     */     }
/* 191 */     return expr;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private List<JExpression> deferredArgumentList() {
/* 197 */     for (JvmMethod.Argument arg : this.overload.getAllArguments()) {
/* 198 */       if (!arg.isRecycle()) {
/* 199 */         throw new UnsupportedOperationException("All arguments of a deferred vector must be @Recycle");
/*     */       }
/*     */     } 
/*     */     
/* 203 */     List<JExpression> list = Lists.newArrayList();
/* 204 */     for (RecycledArgument arg : this.recycledArguments) {
/* 205 */       list.add(arg.vector);
/*     */     }
/* 207 */     return list;
/*     */   }
/*     */   
/*     */   private JExpression emptyResult() {
/* 211 */     return (JExpression)this.codeModel.ref(this.resultType.getVectorType()).staticRef("EMPTY");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void initializeBuilder() {
/* 217 */     if (this.useArray) {
/*     */       
/* 219 */       JType arrayElementType = this.codeModel._ref(this.resultType.getBuilderArrayElementClass());
/* 220 */       JClass arrayClass = arrayElementType.array();
/* 221 */       this.builder = this.parent.decl((JType)arrayElementType.array(), "array", (JExpression)JExpr.newArray(arrayElementType, (JExpression)this.cycleCount));
/*     */     }
/*     */     else {
/*     */       
/* 225 */       JClass builderClass = this.codeModel.ref(this.resultType.getBuilderClass());
/* 226 */       this.builder = this.parent.decl((JType)builderClass, "builder", (JExpression)JExpr._new(builderClass).arg((JExpression)this.cycleCount));
/*     */     } 
/*     */   }
/*     */   
/*     */   private void loop() {
/* 231 */     JForLoop loop = this.parent._for();
/* 232 */     this.cycleIndex = loop.init((JType)this.codeModel.INT, "i", JExpr.lit(0));
/* 233 */     loop.test(this.cycleIndex.ne((JExpression)this.cycleCount));
/* 234 */     loop.update(this.cycleIndex.incr());
/*     */     
/* 236 */     calculateResult(loop.body());
/* 237 */     incrementCounters(loop.body());
/*     */   }
/*     */ 
/*     */   
/*     */   private void calculateResult(JBlock loopBody) {
/* 242 */     for (RecycledArgument recycledArgument : this.recycledArguments) {
/* 243 */       loopBody.assign((JAssignmentTarget)recycledArgument.currentElement, recycledArgument.getCurrentElement());
/*     */     }
/* 245 */     if (!this.overload.isPassNA()) {
/*     */ 
/*     */       
/* 248 */       JConditional ifNA = loopBody._if(isCurrentElementMissing());
/* 249 */       assignNA(ifNA._then());
/* 250 */       assignCycleResult(ifNA._else());
/*     */     }
/*     */     else {
/*     */       
/* 254 */       assignCycleResult(loopBody);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void incrementCounters(JBlock loopBody) {
/* 259 */     for (RecycledArgument arg : this.recycledArguments) {
/* 260 */       loopBody.assignPlus((JAssignmentTarget)arg.currentElementIndex, JExpr.lit(1));
/* 261 */       if (this.recycledArguments.size() > 1) {
/* 262 */         loopBody._if(arg.currentElementIndex.eq((JExpression)arg.length))._then().assign((JAssignmentTarget)arg.currentElementIndex, JExpr.lit(0));
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private JExpression isCurrentElementMissing() {
/* 268 */     if (this.recycledArguments.isEmpty()) {
/* 269 */       throw new IllegalStateException(this.overload.getName() + " is marked as @DataParallel, but has no parallel arguments");
/*     */     }
/*     */     
/* 272 */     JExpression condition = null;
/* 273 */     for (RecycledArgument arg : this.recycledArguments) {
/* 274 */       if (condition == null) {
/* 275 */         condition = arg.isCurrentElementNA(); continue;
/*     */       } 
/* 277 */       condition = condition.cor(arg.isCurrentElementNA());
/*     */     } 
/*     */     
/* 280 */     return condition;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void assignCycleResult(JBlock block) {
/* 288 */     if (this.useArray) {
/* 289 */       JArrayCompRef jArrayCompRef = this.builder.component((JExpression)this.cycleIndex);
/* 290 */       block.assign((JAssignmentTarget)jArrayCompRef, computeCycleResult());
/*     */     } else {
/* 292 */       block.add((JStatement)this.builder.invoke("set").arg((JExpression)this.cycleIndex).arg(computeCycleResult()));
/*     */     } 
/*     */   }
/*     */   
/*     */   private void assignNA(JBlock body) {
/* 297 */     if (this.useArray) {
/* 298 */       body.assign((JAssignmentTarget)this.builder.component((JExpression)this.cycleIndex), this.resultType.naLiteral(this.codeModel));
/*     */     } else {
/* 300 */       body.add((JStatement)this.builder.invoke("setNA").arg((JExpression)this.cycleIndex));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private JExpression computeCycleResult() {
/* 306 */     JInvocation invocation = this.codeModel.ref(this.overload.getDeclaringClass()).staticInvoke(this.overload.getName());
/*     */     
/* 308 */     for (JvmMethod.Argument arg : this.overload.getAllArguments()) {
/* 309 */       if (!this.argumentMap.containsKey(arg)) {
/* 310 */         throw new AssertionError(arg.getName() + " not present in argumentMap");
/*     */       }
/* 312 */       invocation.arg(this.argumentMap.get(arg));
/*     */     } 
/*     */     
/* 315 */     if (this.useArray) {
/* 316 */       return this.resultType.toBuildArrayElementType((JExpression)invocation);
/*     */     }
/* 318 */     return (JExpression)invocation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void copyAttributesUsingBuilder() {
/* 325 */     if (this.overload.getPreserveAttributesStyle() != PreserveAttributeStyle.NONE)
/*     */     {
/*     */       
/* 328 */       for (RecycledArgument arg : this.recycledArguments) {
/* 329 */         this.parent._if(arg.length.eq((JExpression)this.cycleCount))._then().add(copyAttributesFrom(arg));
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private JExpression copyAttributesFast() {
/* 336 */     if (this.overload.getPreserveAttributesStyle() == PreserveAttributeStyle.NONE) {
/* 337 */       return (JExpression)this.codeModel.ref(AttributeMap.class).staticRef("EMPTY");
/*     */     }
/* 339 */     if (this.recycledArguments.size() == 1)
/* 340 */       return copyAttributes((JExpression)(this.recycledArguments.get(0)).vector); 
/* 341 */     if (this.recycledArguments.size() == 2) {
/* 342 */       return copyAttributes((JExpression)(this.recycledArguments.get(0)).vector, (JExpression)(this.recycledArguments.get(1)).vector);
/*     */     }
/* 344 */     throw new UnsupportedOperationException("arity = " + this.recycledArguments.size());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private JStatement copyAttributesFrom(RecycledArgument arg) {
/* 350 */     switch (this.overload.getPreserveAttributesStyle()) {
/*     */       case ALL:
/* 352 */         return (JStatement)this.builder.invoke("combineAttributesFrom").arg((JExpression)arg.vector);
/*     */       case STRUCTURAL:
/* 354 */         return (JStatement)this.builder.invoke("combineStructuralAttributesFrom").arg((JExpression)arg.vector);
/*     */     } 
/* 356 */     throw new IllegalArgumentException("preserve attribute style: " + this.overload.getPreserveAttributesStyle());
/*     */   }
/*     */ 
/*     */   
/*     */   private JExpression copyAttributes(JExpression arg0, JExpression arg1) {
/*     */     String combineMethod;
/* 362 */     switch (this.overload.getPreserveAttributesStyle()) {
/*     */       case ALL:
/* 364 */         combineMethod = "combineAttributes";
/*     */         break;
/*     */       case STRUCTURAL:
/* 367 */         combineMethod = "combineStructuralAttributes";
/*     */         break;
/*     */       default:
/* 370 */         throw new UnsupportedOperationException();
/*     */     } 
/*     */     
/* 373 */     return (JExpression)this.codeModel.ref(AttributeMap.class).staticInvoke(combineMethod)
/* 374 */       .arg(arg0)
/* 375 */       .arg(arg1);
/*     */   }
/*     */   
/*     */   private JExpression copyAttributes(JExpression arg) {
/* 379 */     if (this.overload.getPreserveAttributesStyle() == PreserveAttributeStyle.ALL)
/* 380 */       return (JExpression)arg.invoke("getAttributes"); 
/* 381 */     if (this.overload.getPreserveAttributesStyle() == PreserveAttributeStyle.STRUCTURAL) {
/* 382 */       return (JExpression)arg.invoke("getAttributes").invoke("copyStructural");
/*     */     }
/* 384 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private JExpression symbol(String name) {
/* 390 */     return (JExpression)this.codeModel.ref(Symbols.class).staticRef(name);
/*     */   }
/*     */ 
/*     */   
/*     */   private JExpression buildResult() {
/* 395 */     if (this.useArray) {
/* 396 */       return (JExpression)JExpr._new(this.codeModel.ref(this.resultType.getArrayVectorClass()))
/* 397 */         .arg((JExpression)this.builder)
/* 398 */         .arg(copyAttributesFast());
/*     */     }
/* 400 */     return (JExpression)this.builder.invoke("build");
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/codegen/RecycleLoopBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */