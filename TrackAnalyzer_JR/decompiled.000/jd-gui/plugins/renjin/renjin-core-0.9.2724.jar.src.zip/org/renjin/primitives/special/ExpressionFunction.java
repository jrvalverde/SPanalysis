/*    */ package org.renjin.primitives.special;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.renjin.eval.Context;
/*    */ import org.renjin.repackaged.guava.collect.Lists;
/*    */ import org.renjin.sexp.AttributeMap;
/*    */ import org.renjin.sexp.Environment;
/*    */ import org.renjin.sexp.ExpressionVector;
/*    */ import org.renjin.sexp.FunctionCall;
/*    */ import org.renjin.sexp.PairList;
/*    */ import org.renjin.sexp.SEXP;
/*    */ import org.renjin.sexp.SpecialFunction;
/*    */ import org.renjin.sexp.StringVector;
/*    */ import org.renjin.util.NamesBuilder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExpressionFunction
/*    */   extends SpecialFunction
/*    */ {
/*    */   public ExpressionFunction() {
/* 35 */     super("expression");
/*    */   }
/*    */ 
/*    */   
/*    */   public SEXP apply(Context context, Environment rho, FunctionCall call, PairList args) {
/* 40 */     NamesBuilder names = NamesBuilder.withInitialLength(0);
/* 41 */     List<SEXP> expressions = Lists.newArrayList();
/* 42 */     for (PairList.Node node : args.nodes()) {
/* 43 */       if (node.hasName()) {
/* 44 */         names.add(node.getName());
/*    */       } else {
/* 46 */         names.addBlank();
/*    */       } 
/* 48 */       expressions.add(node.getValue());
/*    */     } 
/* 50 */     AttributeMap.Builder attributes = AttributeMap.builder();
/* 51 */     if (names.haveNames()) {
/* 52 */       attributes.setNames((StringVector)names.build());
/*    */     }
/* 54 */     return (SEXP)new ExpressionVector(expressions, attributes.build());
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/special/ExpressionFunction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */