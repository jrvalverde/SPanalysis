/*     */ package org.renjin.invoke.reflection;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.util.List;
/*     */ import org.renjin.eval.Context;
/*     */ import org.renjin.eval.EvalException;
/*     */ import org.renjin.repackaged.guava.collect.Lists;
/*     */ import org.renjin.sexp.SEXP;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConstructorBinding
/*     */   implements MemberBinding
/*     */ {
/*  33 */   private List<Overload> overloads = Lists.newArrayList();
/*     */   private int maxArgCount;
/*     */   
/*     */   public ConstructorBinding(Constructor[] overloads) {
/*  37 */     for (Constructor constructor : overloads) {
/*  38 */       if ((constructor.getModifiers() & 0x1) != 0) {
/*  39 */         Overload overload = new Overload(constructor);
/*  40 */         if (overload.getArgCount() > this.maxArgCount) {
/*  41 */           this.maxArgCount = overload.getArgCount();
/*     */         }
/*  43 */         this.overloads.add(overload);
/*     */       } 
/*     */     } 
/*  46 */     AbstractOverload.sortOverloads((List)this.overloads);
/*     */   }
/*     */   
/*     */   public boolean isEmpty() {
/*  50 */     return this.overloads.isEmpty();
/*     */   }
/*     */ 
/*     */   
/*     */   public SEXP getValue(Object instance) {
/*  55 */     return (SEXP)new ConstructorFunction(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setValue(Object instance, SEXP value) {
/*  60 */     throw new EvalException("The constructor of JVM classes cannot be changed", new Object[0]);
/*     */   }
/*     */   
/*     */   public static class Overload
/*     */     extends AbstractOverload {
/*     */     private Constructor constructor;
/*     */     
/*     */     public Overload(Constructor constructor) {
/*  68 */       super(constructor.getParameterTypes(), constructor
/*  69 */           .getParameterAnnotations(), constructor.isVarArgs());
/*  70 */       this.constructor = constructor;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object newInstance(Context context, List<SEXP> args) {
/*     */       try {
/*  76 */         return this.constructor.newInstance(convertArguments(context, args));
/*  77 */       } catch (IllegalArgumentException e) {
/*  78 */         throw new RuntimeException(e);
/*  79 */       } catch (InstantiationException e) {
/*  80 */         throw new RuntimeException(e);
/*  81 */       } catch (IllegalAccessException e) {
/*  82 */         throw new RuntimeException(e);
/*  83 */       } catch (InvocationTargetException e) {
/*  84 */         throw new RuntimeException(e);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/*  90 */       return this.constructor.toString();
/*     */     }
/*     */   }
/*     */   
/*     */   public Object newInstance(Context context, List<SEXP> arguments) {
/*  95 */     for (Overload overload : this.overloads) {
/*  96 */       if (overload.accept(arguments))
/*     */       {
/*  98 */         return overload.newInstance(context, arguments);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 103 */     throw new EvalException("Cannot match arguments (%s) to any of the constructors:\n%s", new Object[] {
/* 104 */           ExceptionUtil.toString(arguments), ExceptionUtil.overloadListToString(this.overloads)
/*     */         });
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/reflection/ConstructorBinding.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */