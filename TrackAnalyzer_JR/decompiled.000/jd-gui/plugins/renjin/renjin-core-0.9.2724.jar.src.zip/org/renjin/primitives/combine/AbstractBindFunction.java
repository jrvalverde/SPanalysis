/*     */ package org.renjin.primitives.combine;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.renjin.eval.Context;
/*     */ import org.renjin.eval.EvalException;
/*     */ import org.renjin.invoke.codegen.ArgumentIterator;
/*     */ import org.renjin.primitives.S3;
/*     */ import org.renjin.repackaged.guava.collect.Lists;
/*     */ import org.renjin.sexp.AtomicVector;
/*     */ import org.renjin.sexp.Environment;
/*     */ import org.renjin.sexp.Function;
/*     */ import org.renjin.sexp.FunctionCall;
/*     */ import org.renjin.sexp.IntArrayVector;
/*     */ import org.renjin.sexp.Null;
/*     */ import org.renjin.sexp.PairList;
/*     */ import org.renjin.sexp.Promise;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.SpecialFunction;
/*     */ import org.renjin.sexp.StringVector;
/*     */ import org.renjin.sexp.Symbol;
/*     */ import org.renjin.sexp.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractBindFunction
/*     */   extends SpecialFunction
/*     */ {
/*     */   private MatrixDim bindDim;
/*     */   
/*     */   protected AbstractBindFunction(String name, MatrixDim bindDim) {
/*  39 */     super(name);
/*  40 */     this.bindDim = bindDim;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final SEXP apply(Context context, Environment rho, FunctionCall call, PairList arguments) {
/*  46 */     ArgumentIterator argumentItr = new ArgumentIterator(context, rho, arguments);
/*  47 */     int deparseLevel = ((Vector)argumentItr.evalNext()).getElementAsInt(0);
/*     */     
/*  49 */     List<BindArgument> bindArguments = Lists.newArrayList();
/*  50 */     while (argumentItr.hasNext()) {
/*  51 */       PairList.Node currentNode = argumentItr.nextNode();
/*  52 */       SEXP evaluated = context.evaluate(currentNode.getValue(), rho);
/*  53 */       bindArguments.add(new BindArgument(currentNode.getName(), (Vector)evaluated, this.bindDim, currentNode
/*  54 */             .getValue(), deparseLevel, context));
/*     */     } 
/*     */     
/*  57 */     SEXP genericResult = tryBindDispatch(context, rho, getName(), deparseLevel, bindArguments);
/*  58 */     if (genericResult != null) {
/*  59 */       return genericResult;
/*     */     }
/*     */     
/*  62 */     if (onlyNullArguments(bindArguments)) {
/*  63 */       return (SEXP)Null.INSTANCE;
/*     */     }
/*  65 */     return apply(context, bindArguments);
/*     */   }
/*     */ 
/*     */   
/*     */   protected abstract SEXP apply(Context paramContext, List<BindArgument> paramList);
/*     */ 
/*     */   
/*     */   protected static boolean allZeroLengthVectors(List<BindArgument> bindArguments) {
/*  73 */     for (BindArgument bindArgument : bindArguments) {
/*  74 */       if (!bindArgument.isZeroLengthVector()) {
/*  75 */         return false;
/*     */       }
/*     */     } 
/*  78 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SEXP tryBindDispatch(Context context, Environment rho, String bindFunctionName, int deparseLevel, List<BindArgument> arguments) {
/* 106 */     Symbol foundMethod = null;
/* 107 */     Function foundFunction = null;
/*     */ 
/*     */     
/* 110 */     Environment methodsTable = S3.findMethodTable(context, context.getBaseEnvironment());
/*     */     
/* 112 */     for (BindArgument argument : arguments) {
/* 113 */       Vector classes = argument.getClasses();
/* 114 */       for (int i = 0; i != classes.length(); i++) {
/* 115 */         Symbol methodName = Symbol.get(bindFunctionName + "." + classes.getElementAsString(i));
/* 116 */         Function function = rho.findFunction(context, methodName);
/* 117 */         if (function == null) {
/* 118 */           function = methodsTable.findFunction(context, methodName);
/*     */         }
/* 120 */         if (function != null) {
/* 121 */           if (foundMethod != null && methodName != foundMethod)
/*     */           {
/*     */             
/* 124 */             return null;
/*     */           }
/* 126 */           foundMethod = methodName;
/* 127 */           foundFunction = function;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 132 */     if (foundFunction == null)
/*     */     {
/* 134 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 138 */     PairList.Builder args = new PairList.Builder();
/* 139 */     args.add("deparse.level", (SEXP)new Promise((SEXP)Symbol.get("deparse.level"), (SEXP)new IntArrayVector(new int[] { deparseLevel })));
/*     */     
/* 141 */     for (BindArgument argument : arguments) {
/* 142 */       args.add(argument.getArgName(), (SEXP)argument.repromise());
/*     */     }
/*     */     
/* 145 */     PairList buildArgs = args.build();
/*     */     
/* 147 */     FunctionCall call = new FunctionCall((SEXP)Symbol.get(bindFunctionName), buildArgs);
/* 148 */     return foundFunction.apply(context, rho, call, buildArgs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean onlyNullArguments(List<BindArgument> bindArguments) {
/* 155 */     for (BindArgument bindArgument : bindArguments) {
/* 156 */       if (!bindArgument.isNull()) {
/* 157 */         return false;
/*     */       }
/*     */     } 
/* 160 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int findCommonMatrixDimLength(List<BindArgument> bindArguments, MatrixDim dim) {
/* 169 */     int length = -1;
/* 170 */     for (BindArgument argument : bindArguments) {
/* 171 */       if (argument.isMatrix()) {
/* 172 */         if (length == -1) {
/* 173 */           length = argument.getDimLength(dim); continue;
/* 174 */         }  if (length != argument.getDimLength(dim)) {
/* 175 */           throw new EvalException("number of %s of matrices must match", new Object[] { dim.name().toLowerCase() + "s" });
/*     */         }
/*     */       } 
/*     */     } 
/* 179 */     return length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static int findMaxLength(List<BindArgument> bindArguments) {
/* 186 */     int length = 0;
/* 187 */     for (BindArgument argument : bindArguments) {
/* 188 */       if (argument.getVector().length() > length) {
/* 189 */         length = argument.getVector().length();
/*     */       }
/*     */     } 
/* 192 */     return length;
/*     */   }
/*     */   
/*     */   protected void warnIfVectorLengthsAreNotMultiple(Context context, List<BindArgument> bindArguments, int expectedLength) {
/* 196 */     for (BindArgument argument : bindArguments) {
/* 197 */       if (!argument.isMatrix() && 
/* 198 */         !argument.isZeroLength() && expectedLength % argument.getVector().length() != 0) {
/* 199 */         context.warn("number of " + ((this.bindDim == MatrixDim.COL) ? "rows" : "cols") + " of result is not a multiple of vector length");
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Vector.Builder builderForCommonType(List<BindArgument> bindArguments) {
/* 207 */     Inspector inspector = new Inspector(false);
/* 208 */     for (BindArgument bindArgument : bindArguments) {
/* 209 */       if (bindArgument.getVector() != Null.INSTANCE) {
/* 210 */         bindArgument.getVector().accept(inspector);
/*     */       }
/*     */     } 
/* 213 */     return inspector.getResult().newBuilder();
/*     */   }
/*     */   
/*     */   protected List<BindArgument> excludeZeroLengthVectors(List<BindArgument> bindArguments) {
/* 217 */     List<BindArgument> retained = new ArrayList<>(bindArguments.size());
/* 218 */     for (BindArgument bindArgument : bindArguments) {
/* 219 */       if (!bindArgument.isZeroLengthVector()) {
/* 220 */         retained.add(bindArgument);
/*     */       }
/*     */     } 
/* 223 */     return retained;
/*     */   }
/*     */   
/*     */   protected int countRowOrCols(List<BindArgument> bindArguments, MatrixDim dim) {
/* 227 */     int count = 0;
/* 228 */     for (BindArgument bindArgument : bindArguments) {
/* 229 */       count += bindArgument.getDimLength(dim);
/*     */     }
/* 231 */     return count;
/*     */   }
/*     */   
/*     */   protected AtomicVector combineDimNames(List<BindArgument> bindArguments, MatrixDim dim) {
/* 235 */     boolean hasNames = false;
/* 236 */     StringVector.Builder resultNames = new StringVector.Builder();
/*     */     
/* 238 */     for (BindArgument argument : bindArguments) {
/* 239 */       AtomicVector argumentNames = argument.getNames(dim);
/* 240 */       if (argumentNames != Null.INSTANCE) {
/* 241 */         hasNames = true;
/* 242 */         for (int j = 0; j != argumentNames.length(); j++)
/* 243 */           resultNames.add(argumentNames.getElementAsString(j)); 
/*     */         continue;
/*     */       } 
/* 246 */       if (!argument.hasNoName() && !argument.isMatrix()) {
/* 247 */         resultNames.add(argument.getName());
/* 248 */         hasNames = true;
/*     */         continue;
/*     */       } 
/* 251 */       for (int i = 0; i != argument.getDimLength(dim); i++) {
/* 252 */         resultNames.add("");
/*     */       }
/*     */     } 
/*     */     
/* 256 */     if (hasNames) {
/* 257 */       return (AtomicVector)resultNames.build();
/*     */     }
/* 259 */     return (AtomicVector)Null.INSTANCE;
/*     */   }
/*     */ 
/*     */   
/*     */   protected AtomicVector dimNamesFromLongest(List<BindArgument> bindArguments, MatrixDim dim, int dimLength) {
/* 264 */     for (BindArgument argument : bindArguments) {
/* 265 */       if (argument.getDimLength(dim) == dimLength) {
/* 266 */         AtomicVector argumentNames = argument.getNames(dim);
/* 267 */         if (argumentNames != Null.INSTANCE) {
/* 268 */           return argumentNames;
/*     */         }
/*     */       } 
/*     */     } 
/* 272 */     return (AtomicVector)Null.INSTANCE;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/combine/AbstractBindFunction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */