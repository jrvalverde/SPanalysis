/*     */ package org.renjin.primitives.io.serialization;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import org.renjin.eval.Context;
/*     */ import org.renjin.eval.EvalException;
/*     */ import org.renjin.invoke.annotations.Current;
/*     */ import org.renjin.invoke.annotations.DotCall;
/*     */ import org.renjin.invoke.annotations.Internal;
/*     */ import org.renjin.primitives.io.connections.Connection;
/*     */ import org.renjin.primitives.io.connections.Connections;
/*     */ import org.renjin.primitives.io.connections.OpenSpec;
/*     */ import org.renjin.sexp.Environment;
/*     */ import org.renjin.sexp.FunctionCall;
/*     */ import org.renjin.sexp.HasNamedValues;
/*     */ import org.renjin.sexp.NamedValue;
/*     */ import org.renjin.sexp.Null;
/*     */ import org.renjin.sexp.PairList;
/*     */ import org.renjin.sexp.Promise;
/*     */ import org.renjin.sexp.RawVector;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.StringVector;
/*     */ import org.renjin.sexp.Symbol;
/*     */ import org.renjin.sexp.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Serialization
/*     */ {
/*     */   private static final int DEFAULT_SERIALIZATION_VERSION = 0;
/*     */   
/*     */   public enum SerializationType
/*     */   {
/*  45 */     ASCII, XDR, BINARY;
/*     */   }
/*     */ 
/*     */   
/*     */   @Internal
/*     */   public static SEXP unserializeFromConn(@Current Context context, SEXP conn, Environment rho) throws IOException {
/*  51 */     RDataReader reader = new RDataReader(context, Connections.getConnection(context, conn).getInputStream());
/*  52 */     return reader.readFile();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Internal
/*     */   public static SEXP unserializeFromConn(@Current Context context, SEXP conn, Null nz) throws IOException {
/*  60 */     RDataReader reader = new RDataReader(context, Connections.getConnection(context, conn).getInputStream());
/*  61 */     return reader.readFile();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Internal
/*     */   public static void serializeToConn(@Current Context context, SEXP object, SEXP con, boolean ascii, SEXP versionSexp, SEXP refhook) throws IOException {
/*  87 */     if (ascii) {
/*  88 */       throw new EvalException("ascii format serialization not implemented", new Object[0]);
/*     */     }
/*     */     
/*  91 */     int version = 0;
/*  92 */     if (versionSexp instanceof Vector && versionSexp.length() == 1) {
/*  93 */       version = ((Vector)versionSexp).getElementAsInt(0);
/*     */     }
/*     */ 
/*     */     
/*  97 */     RDataWriter writer = new RDataWriter(context, createHook(context, refhook), Connections.getConnection(context, con).getOutputStream());
/*  98 */     writer.serialize(object);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Internal
/*     */   public static void saveToConn(@Current Context context, StringVector names, SEXP connHandle, boolean ascii, SEXP version, Environment envir, boolean evalPromises) throws IOException {
/* 124 */     Connection con = Connections.getConnection(context, connHandle);
/* 125 */     boolean wasOpen = con.isOpen();
/* 126 */     if (!wasOpen) {
/* 127 */       con.open(new OpenSpec("wb"));
/*     */     }
/*     */     
/* 130 */     if (!con.canWrite()) {
/* 131 */       throw new EvalException("connection not open for writing", new Object[0]);
/*     */     }
/* 133 */     if (ascii) {
/* 134 */       throw new EvalException("ascii serialization not implemented", new Object[0]);
/*     */     }
/* 136 */     PairList.Builder list = new PairList.Builder();
/* 137 */     for (String name : names) {
/* 138 */       SEXP value = envir.getVariable(context, name);
/* 139 */       if (value == Symbol.UNBOUND_VALUE) {
/* 140 */         throw new EvalException("object '%s' not found", new Object[] { name });
/*     */       }
/* 142 */       if (evalPromises) {
/* 143 */         value = value.force(context);
/*     */       }
/* 145 */       list.add(name, value);
/*     */     } 
/*     */     
/* 148 */     RDataWriter writer = new RDataWriter(context, con.getOutputStream());
/* 149 */     writer.save((SEXP)list.build());
/*     */     
/* 151 */     if (!wasOpen) {
/* 152 */       Connections.close(context, connHandle);
/*     */     }
/*     */   }
/*     */   
/*     */   @Internal
/*     */   public static void save(SEXP list, SEXP file, SEXP ascii, SEXP version, SEXP environment, SEXP evalPromises) {
/* 158 */     throw new EvalException("Serialization version 1 not supported.", new Object[0]);
/*     */   }
/*     */   
/*     */   private static RDataWriter.PersistenceHook createHook(final Context context, final SEXP hookExp) {
/* 162 */     if (hookExp == Null.INSTANCE) {
/* 163 */       return null;
/*     */     }
/* 165 */     if (!(hookExp instanceof org.renjin.sexp.Closure)) {
/* 166 */       throw new EvalException("Illegal type for refhook", new Object[0]);
/*     */     }
/* 168 */     return new RDataWriter.PersistenceHook()
/*     */       {
/*     */ 
/*     */         
/*     */         public Vector apply(SEXP exp)
/*     */         {
/* 174 */           Promise promisedExp = Promise.repromise(exp);
/*     */           
/* 176 */           FunctionCall hookCall = FunctionCall.newCall(hookExp, new SEXP[] { (SEXP)promisedExp });
/* 177 */           SEXP result = context.evaluate((SEXP)hookCall);
/* 178 */           if (result == Null.INSTANCE)
/* 179 */             return (Vector)Null.INSTANCE; 
/* 180 */           if (result instanceof StringVector) {
/* 181 */             return (Vector)result;
/*     */           }
/* 183 */           throw new EvalException("Unexpected result from hook function: " + result, new Object[0]);
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Internal
/*     */   public static SEXP loadFromConn2(@Current Context context, SEXP conn, Environment env) throws IOException {
/* 207 */     InputStream inputStream = Connections.getConnection(context, conn).getInputStream();
/* 208 */     return load(context, env, inputStream);
/*     */   }
/*     */   
/*     */   public static SEXP load(@Current Context context, Environment env, InputStream inputStream) throws IOException {
/* 212 */     RDataReader reader = new RDataReader(context, inputStream);
/* 213 */     HasNamedValues data = (HasNamedValues)EvalException.checkedCast(reader.readFile());
/*     */     
/* 215 */     StringVector.Builder names = new StringVector.Builder();
/*     */     
/* 217 */     for (NamedValue pair : data.namedValues()) {
/* 218 */       env.setVariable(context, Symbol.get(pair.getName()), pair.getValue());
/* 219 */       names.add(pair.getName());
/*     */     } 
/*     */     
/* 222 */     return (SEXP)names.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @DotCall("R_serialize")
/*     */   public static SEXP serialize(@Current Context context, SEXP object, SEXP connection, boolean ascii, SEXP version, SEXP refhook) throws IOException {
/* 245 */     EvalException.check((refhook == Null.INSTANCE), "refHook != NULL has not been implemented yet.", new Object[0]);
/* 246 */     EvalException.check((connection == Null.INSTANCE), "Only connection = NULL has been implemented so far.", new Object[0]);
/*     */     
/* 248 */     ByteArrayOutputStream baos = new ByteArrayOutputStream();
/* 249 */     RDataWriter writer = new RDataWriter(context, baos, ascii ? SerializationType.ASCII : SerializationType.XDR);
/*     */     
/* 251 */     writer.serialize(object);
/*     */     
/* 253 */     return (SEXP)new RawVector(baos.toByteArray());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @DotCall("R_unserialize")
/*     */   public static SEXP unserialize(@Current Context context, SEXP connection, SEXP refhook) throws IOException {
/* 265 */     EvalException.check((refhook == Null.INSTANCE), "refHook != NULL has not been implemented yet.", new Object[0]);
/*     */     
/* 267 */     if (connection instanceof StringVector)
/* 268 */       throw new EvalException("character vectors are no longer accepted by unserialize()", new Object[0]); 
/* 269 */     if (connection instanceof RawVector) {
/*     */       
/* 271 */       RDataReader reader = new RDataReader(context, new ByteArrayInputStream(((RawVector)connection).toByteArray()));
/* 272 */       return reader.readFile();
/*     */     } 
/* 274 */     return unserializeFromConn(context, connection, Null.INSTANCE);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/io/serialization/Serialization.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */