/*    */ package org.renjin.invoke.codegen.args;
/*    */ 
/*    */ import com.sun.codemodel.JCodeModel;
/*    */ import com.sun.codemodel.JExpr;
/*    */ import com.sun.codemodel.JExpression;
/*    */ import com.sun.codemodel.JVar;
/*    */ import org.renjin.invoke.annotations.InvokeAsCharacter;
/*    */ import org.renjin.invoke.codegen.ApplyMethodContext;
/*    */ import org.renjin.invoke.codegen.WrapperRuntime;
/*    */ import org.renjin.invoke.model.JvmMethod;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UsingAsCharacter
/*    */   extends ArgConverterStrategy
/*    */ {
/*    */   public UsingAsCharacter(JvmMethod.Argument formal) {
/* 34 */     super(formal);
/*    */   }
/*    */   
/*    */   public static boolean accept(JvmMethod.Argument formal) {
/* 38 */     return formal.isAnnotatedWith(InvokeAsCharacter.class);
/*    */   }
/*    */ 
/*    */   
/*    */   public JExpression convertArgument(ApplyMethodContext parent, JExpression sexp) {
/* 43 */     return (JExpression)parent.classRef(WrapperRuntime.class).staticInvoke("invokeAsCharacter")
/* 44 */       .arg(parent.getContext())
/* 45 */       .arg(parent.getEnvironment())
/* 46 */       .arg(sexp);
/*    */   }
/*    */ 
/*    */   
/*    */   public JExpression getTestExpr(JCodeModel codeModel, JVar sexpVariable) {
/* 51 */     return JExpr.TRUE;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/codegen/args/UsingAsCharacter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */