/*     */ package org.renjin.primitives.io.connections;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PushbackInputStream;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.Arrays;
/*     */ import java.util.zip.GZIPInputStream;
/*     */ import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream;
/*     */ import org.apache.commons.vfs2.FileNotFoundException;
/*     */ import org.apache.commons.vfs2.FileObject;
/*     */ import org.apache.commons.vfs2.FileSystemException;
/*     */ import org.renjin.eval.EvalException;
/*     */ import org.tukaani.xz.XZInputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FileConnection
/*     */   extends AbstractConnection
/*     */ {
/*     */   private InputStream in;
/*     */   private OutputStream out;
/*     */   private FileObject file;
/*  45 */   private OpenSpec openSpec = null;
/*     */   
/*     */   public FileConnection(FileObject file, Charset charset) throws IOException {
/*  48 */     super(charset);
/*  49 */     this.file = file;
/*     */   }
/*     */ 
/*     */   
/*     */   public void open(OpenSpec spec) throws IOException {
/*  54 */     this.openSpec = spec;
/*  55 */     if (spec.forReading() && spec.forWriting()) {
/*  56 */       throw new EvalException("Read/write file connections not yet implemented", new Object[0]);
/*     */     }
/*  58 */     if (spec.forReading()) {
/*  59 */       if (spec.isBinary()) {
/*  60 */         assureOpenForInput();
/*     */       } else {
/*  62 */         getReader();
/*     */       } 
/*  64 */     } else if (spec.forWriting()) {
/*  65 */       if (spec.isBinary()) {
/*  66 */         assureOpenForOutput();
/*     */       } else {
/*  68 */         getPrintWriter();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private final InputStream assureOpenForInput() throws IOException {
/*  74 */     if (this.out != null) {
/*  75 */       throw new EvalException("connection is already opened for output, cannot open for input", new Object[0]);
/*     */     }
/*  77 */     if (this.in == null) {
/*  78 */       this.in = doOpenForInput();
/*     */     }
/*  80 */     return this.in;
/*     */   }
/*     */   
/*     */   protected InputStream doOpenForInput() throws IOException {
/*     */     PushbackInputStream in;
/*  85 */     int[] header = new int[6];
/*  86 */     int pushBackBufferSize = header.length;
/*     */     
/*     */     try {
/*  89 */       in = new PushbackInputStream(this.file.getContent().getInputStream(), pushBackBufferSize);
/*  90 */     } catch (FileNotFoundException e) {
/*  91 */       throw new EvalException(e.getMessage(), new Object[0]);
/*     */     } 
/*     */     int i;
/*  94 */     for (i = 0; i < header.length; i++) {
/*  95 */       header[i] = in.read();
/*     */     }
/*  97 */     for (i = header.length - 1; i >= 0; i--) {
/*  98 */       if (header[i] != -1) {
/*  99 */         in.unread(header[i]);
/*     */       }
/*     */     } 
/* 102 */     if (header[0] == 31 && header[1] == 139) {
/* 103 */       return new GZIPInputStream(in);
/*     */     }
/* 105 */     if (header[0] == 66 && header[1] == 90) {
/* 106 */       return (InputStream)new BZip2CompressorInputStream(in);
/*     */     }
/*     */     
/* 109 */     if (Arrays.equals(header, XzFileConnection.XZ_MAGIC_BYTES)) {
/* 110 */       return (InputStream)new XZInputStream(in);
/*     */     }
/*     */     
/* 113 */     return in;
/*     */   }
/*     */   
/*     */   private OutputStream assureOpenForOutput() throws IOException {
/* 117 */     if (this.in != null) {
/* 118 */       throw new EvalException("connection is already opened for input, cannot open for output", new Object[0]);
/*     */     }
/* 120 */     if (this.out == null) {
/* 121 */       this.out = doOpenForOutput();
/*     */     }
/* 123 */     return this.out;
/*     */   }
/*     */   
/*     */   protected OutputStream doOpenForOutput() throws FileSystemException, IOException {
/* 127 */     boolean append = (this.openSpec != null && this.openSpec.isAppend());
/* 128 */     return this.file.getContent().getOutputStream(append);
/*     */   }
/*     */ 
/*     */   
/*     */   public final InputStream getInputStream() throws IOException {
/* 133 */     return assureOpenForInput();
/*     */   }
/*     */ 
/*     */   
/*     */   public final OutputStream getOutputStream() throws IOException {
/* 138 */     return assureOpenForOutput();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void closeInputIfOpen() throws IOException {
/* 143 */     if (this.in != null) {
/* 144 */       this.in.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected void closeOutputIfOpen() throws IOException {
/* 150 */     if (this.out != null) {
/* 151 */       this.out.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isOpen() {
/* 157 */     return (this.in != null || this.out != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void flush() throws IOException {
/* 162 */     if (this.out != null) {
/* 163 */       this.out.flush();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public String getClassName() {
/* 169 */     return "file";
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDescription() {
/* 174 */     return this.file.getName().getPath();
/*     */   }
/*     */ 
/*     */   
/*     */   public Connection.Type getType() {
/* 179 */     if (this.openSpec == null) {
/* 180 */       return Connection.Type.TEXT;
/*     */     }
/* 182 */     return this.openSpec.getType();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMode() {
/* 188 */     if (this.openSpec == null) {
/* 189 */       return "r";
/*     */     }
/* 191 */     return this.openSpec.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canRead() {
/* 197 */     return (!isOpen() || this.openSpec == null || this.openSpec.forReading());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canWrite() {
/* 202 */     return (!isOpen() || this.openSpec == null || this.openSpec.forWriting());
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/io/connections/FileConnection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */