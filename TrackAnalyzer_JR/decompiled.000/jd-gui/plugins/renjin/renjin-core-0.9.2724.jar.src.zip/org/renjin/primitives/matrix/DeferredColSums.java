/*     */ package org.renjin.primitives.matrix;
/*     */ 
/*     */ import org.renjin.primitives.vector.MemoizedComputation;
/*     */ import org.renjin.sexp.AtomicVector;
/*     */ import org.renjin.sexp.AttributeMap;
/*     */ import org.renjin.sexp.DoubleArrayVector;
/*     */ import org.renjin.sexp.DoubleVector;
/*     */ import org.renjin.sexp.IntArrayVector;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DeferredColSums
/*     */   extends DoubleVector
/*     */   implements MemoizedComputation
/*     */ {
/*     */   private final AtomicVector vector;
/*     */   private int numColumns;
/*     */   private boolean naRm;
/*  29 */   private double[] sums = null;
/*     */   
/*     */   public DeferredColSums(AtomicVector vector, int numColumns, boolean naRm, AttributeMap attributes) {
/*  32 */     super(attributes);
/*  33 */     this.vector = vector;
/*  34 */     this.numColumns = numColumns;
/*  35 */     this.naRm = naRm;
/*     */   }
/*     */ 
/*     */   
/*     */   public Vector[] getOperands() {
/*  40 */     return new Vector[] { (Vector)this.vector, (Vector)new IntArrayVector(new int[] { this.numColumns }) };
/*     */   }
/*     */ 
/*     */   
/*     */   public String getComputationName() {
/*  45 */     if (this.naRm) {
/*  46 */       return "colSumsNaRm";
/*     */     }
/*  48 */     return "colSums";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected SEXP cloneWithNewAttributes(AttributeMap attributes) {
/*  54 */     return (SEXP)new DeferredColSums(this.vector, this.numColumns, this.naRm, attributes);
/*     */   }
/*     */ 
/*     */   
/*     */   public double getElementAsDouble(int index) {
/*  59 */     if (this.sums == null) {
/*  60 */       System.err.println("EEK! colSums.computeMeans() called through getElementAsDouble()");
/*  61 */       computeMeans();
/*     */     } 
/*  63 */     return this.sums[index];
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isConstantAccessTime() {
/*  68 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int length() {
/*  73 */     return this.numColumns;
/*     */   }
/*     */   
/*     */   private void computeMeans() {
/*  77 */     double[] sums = new double[this.numColumns];
/*  78 */     int sourceIndex = 0;
/*  79 */     double sum = 0.0D;
/*     */     
/*  81 */     int numRows = this.vector.length() / this.numColumns;
/*  82 */     int colIndex = 0;
/*  83 */     int rowIndex = 0;
/*     */     
/*  85 */     while (colIndex < this.numColumns) {
/*  86 */       double cellValue = this.vector.getElementAsDouble(sourceIndex++);
/*  87 */       if (!this.naRm || !Double.isNaN(cellValue)) {
/*  88 */         sum += cellValue;
/*     */       }
/*  90 */       rowIndex++;
/*  91 */       if (rowIndex == numRows) {
/*  92 */         rowIndex = 0;
/*  93 */         sums[colIndex] = sum;
/*  94 */         sum = 0.0D;
/*  95 */         colIndex++;
/*     */       } 
/*     */     } 
/*     */     
/*  99 */     this.sums = sums;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isCalculated() {
/* 104 */     return (this.sums != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDeferred() {
/* 109 */     return !isCalculated();
/*     */   }
/*     */ 
/*     */   
/*     */   public Vector forceResult() {
/* 114 */     if (this.sums == null) {
/* 115 */       computeMeans();
/*     */     }
/* 117 */     return (Vector)DoubleArrayVector.unsafe(this.sums, getAttributes());
/*     */   }
/*     */ 
/*     */   
/*     */   public void setResult(Vector result) {
/* 122 */     this.sums = ((DoubleArrayVector)result).toDoubleArrayUnsafe();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/matrix/DeferredColSums.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */