/*    */ package org.renjin.primitives.print;
/*    */ 
/*    */ import org.renjin.parser.NumericLiterals;
/*    */ import org.renjin.repackaged.guava.base.Function;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RealPrinter
/*    */   implements Function<Double, String>
/*    */ {
/*    */   public String apply(Double input) {
/* 27 */     return NumericLiterals.format(input.doubleValue(), "NA");
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/print/RealPrinter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */