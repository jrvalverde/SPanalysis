/*     */ package org.renjin.primitives.io.connections;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintWriter;
/*     */ 
/*     */ public interface Connection {
/*     */   void open(OpenSpec paramOpenSpec) throws IOException;
/*     */   
/*     */   InputStream getInputStream() throws IOException;
/*     */   
/*     */   PushbackBufferedReader getReader() throws IOException;
/*     */   
/*     */   OutputStream getOutputStream() throws IOException;
/*     */   
/*     */   PrintWriter getPrintWriter() throws IOException;
/*     */   
/*     */   PrintWriter getOpenPrintWriter();
/*     */   
/*     */   void close() throws IOException;
/*     */   
/*     */   boolean isOpen();
/*     */   
/*     */   void flush() throws IOException;
/*     */   
/*     */   String getClassName();
/*     */   
/*     */   String getDescription();
/*     */   
/*     */   String getMode();
/*     */   
/*     */   boolean canRead();
/*     */   
/*     */   boolean canWrite();
/*     */   
/*     */   Type getType();
/*     */   
/*     */   public enum Type {
/*  38 */     TEXT,
/*  39 */     BINARY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default boolean isIncomplete() {
/* 130 */     return false;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/io/connections/Connection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */