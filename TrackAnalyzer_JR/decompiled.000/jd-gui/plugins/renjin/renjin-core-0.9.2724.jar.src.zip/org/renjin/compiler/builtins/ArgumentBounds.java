/*    */ package org.renjin.compiler.builtins;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import org.renjin.compiler.ir.ValueBounds;
/*    */ import org.renjin.compiler.ir.tac.IRArgument;
/*    */ import org.renjin.compiler.ir.tac.expressions.Expression;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ArgumentBounds
/*    */ {
/*    */   private String name;
/*    */   private ValueBounds bounds;
/*    */   
/*    */   public ArgumentBounds(String name, ValueBounds bounds) {
/* 35 */     this.name = name;
/* 36 */     this.bounds = bounds;
/*    */   }
/*    */   
/*    */   public ArgumentBounds(ValueBounds valueBounds) {
/* 40 */     this.name = null;
/* 41 */     this.bounds = valueBounds;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 45 */     return this.name;
/*    */   }
/*    */   
/*    */   public ValueBounds getBounds() {
/* 49 */     return this.bounds;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static List<ArgumentBounds> create(List<IRArgument> arguments, Map<Expression, ValueBounds> typeMap) {
/* 58 */     List<ArgumentBounds> result = new ArrayList<>();
/* 59 */     for (int i = 0; i < arguments.size(); i++) {
/* 60 */       ValueBounds argumentBounds; IRArgument symbolArgument = arguments.get(i);
/*    */       
/* 62 */       Expression argumentExpr = symbolArgument.getExpression();
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 67 */       if (argumentExpr instanceof org.renjin.compiler.ir.tac.expressions.Constant) {
/* 68 */         argumentBounds = argumentExpr.getValueBounds();
/*    */       } else {
/* 70 */         argumentBounds = typeMap.get(argumentExpr);
/*    */       } 
/* 72 */       assert argumentBounds != null : "No argument bounds for " + symbolArgument.getName();
/*    */       
/* 74 */       result.add(new ArgumentBounds(symbolArgument.getName(), argumentBounds));
/*    */     } 
/* 76 */     return result;
/*    */   }
/*    */   
/*    */   public static List<ValueBounds> withoutNames(List<ArgumentBounds> argumentBounds) {
/* 80 */     List<ValueBounds> values = new ArrayList<>();
/* 81 */     for (ArgumentBounds argumentBound : argumentBounds) {
/* 82 */       values.add(argumentBound.getBounds());
/*    */     }
/* 84 */     return values;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/builtins/ArgumentBounds.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */