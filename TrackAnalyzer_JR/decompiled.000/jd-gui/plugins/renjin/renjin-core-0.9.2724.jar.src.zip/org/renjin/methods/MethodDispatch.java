/*     */ package org.renjin.methods;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import org.renjin.eval.Calls;
/*     */ import org.renjin.eval.Context;
/*     */ import org.renjin.eval.EvalException;
/*     */ import org.renjin.invoke.annotations.SessionScoped;
/*     */ import org.renjin.primitives.Evaluation;
/*     */ import org.renjin.repackaged.guava.base.Preconditions;
/*     */ import org.renjin.repackaged.guava.collect.Maps;
/*     */ import org.renjin.sexp.Closure;
/*     */ import org.renjin.sexp.Environment;
/*     */ import org.renjin.sexp.Function;
/*     */ import org.renjin.sexp.FunctionCall;
/*     */ import org.renjin.sexp.Null;
/*     */ import org.renjin.sexp.PairList;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.StringArrayVector;
/*     */ import org.renjin.sexp.StringVector;
/*     */ import org.renjin.sexp.Symbol;
/*     */ import org.renjin.sexp.Symbols;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @SessionScoped
/*     */ public class MethodDispatch
/*     */ {
/*  36 */   public static final Symbol DOT_METHOD = Symbol.get(".Method");
/*  37 */   public static final Symbol DOT_METHODS = Symbol.get(".Methods");
/*  38 */   public static final Symbol DOT_DEFINED = Symbol.get(".defined");
/*  39 */   public static final Symbol DOT_TARGET = Symbol.get(".target");
/*     */ 
/*     */   
/*  42 */   public static final Symbol DOT_GENERIC = Symbol.get(".Generic");
/*  43 */   public static final Symbol GENERIC = Symbol.get("generic");
/*     */ 
/*     */   
/*  46 */   public static final Symbol R_target = Symbol.get("target");
/*  47 */   public static final Symbol R_defined = Symbol.get("defined");
/*  48 */   public static final Symbol R_nextMethod = Symbol.get("nextMethod");
/*  49 */   public static final Symbol R_loadMethod_name = Symbol.get("loadMethod");
/*  50 */   public static final Symbol R_dot_target = Symbol.get(".target");
/*  51 */   public static final Symbol R_dot_defined = Symbol.get(".defined");
/*  52 */   public static final Symbol R_dot_nextMethod = Symbol.get(".nextMethod");
/*  53 */   public static final Symbol R_dot_Method = Symbol.get(".Method");
/*     */   
/*  55 */   public static final Symbol s_dot_Methods = Symbol.get(".Methods");
/*  56 */   public static final Symbol s_skeleton = Symbol.get("skeleton");
/*  57 */   public static final Symbol s_expression = Symbol.get("expression");
/*  58 */   public static final Symbol s_function = Symbol.get("function");
/*  59 */   public static final Symbol s_getAllMethods = Symbol.get("getAllMethods");
/*  60 */   public static final Symbol s_objectsEnv = Symbol.get("objectsEnv");
/*  61 */   public static final Symbol s_MethodsListSelect = Symbol.get("MethodsListSelect");
/*  62 */   public static final Symbol s_sys_dot_frame = Symbol.get("sys.frame");
/*  63 */   public static final Symbol s_sys_dot_call = Symbol.get("sys.call");
/*  64 */   public static final Symbol s_sys_dot_function = Symbol.get("sys.function");
/*  65 */   public static final Symbol s_generic = Symbol.get("generic");
/*  66 */   public static final Symbol s_generic_dot_skeleton = Symbol.get("generic.skeleton");
/*  67 */   public static final Symbol s_subset_gets = Symbol.get("[<-");
/*  68 */   public static final Symbol s_element_gets = Symbol.get("[[<-");
/*  69 */   public static final Symbol s_argument = Symbol.get("argument");
/*  70 */   public static final Symbol s_allMethods = Symbol.get("allMethods");
/*  71 */   public static final Symbol s_dot_Data = Symbol.get(".Data");
/*  72 */   public static final Symbol s_dot_S3Class = Symbol.get(".S3Class");
/*  73 */   public static final Symbol s_getDataPart = Symbol.get("getDataPart");
/*  74 */   public static final Symbol s_setDataPart = Symbol.get("setDataPart");
/*     */   
/*  76 */   public static final Symbol s_xData = Symbol.get(".xData");
/*  77 */   public static final Symbol s_dotData = Symbol.get(".Data");
/*     */   
/*  79 */   public static final Symbol R_mtable = Symbol.get(".MTable");
/*  80 */   public static final Symbol R_allmtable = Symbol.get(".AllMTable");
/*  81 */   public static final Symbol R_sigargs = Symbol.get(".SigArgs");
/*  82 */   public static final Symbol R_siglength = Symbol.get(".SigLength");
/*     */   
/*  84 */   public static final StringVector s_missing = StringVector.valueOf("missing");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  93 */   public static final Symbol pseudo_NULL = Symbol.get("\001NULL\001");
/*     */ 
/*     */   
/*     */   private boolean enabled = false;
/*     */   
/*  98 */   private HashMap<String, SEXP> extendsTable = Maps.newHashMap();
/*     */   
/*     */   private Environment methodsNamespace;
/*     */   
/*     */   private boolean tableDispatchEnabled = true;
/*     */   
/*     */   public void init(Environment environment) {
/* 105 */     this.methodsNamespace = environment;
/*     */   }
/*     */   
/*     */   public boolean isEnabled() {
/* 109 */     return this.enabled;
/*     */   }
/*     */   
/*     */   public void setEnabled(boolean enabled) {
/* 113 */     this.enabled = enabled;
/*     */   }
/*     */   
/*     */   public SEXP getExtends(String className) {
/* 117 */     SEXP value = this.extendsTable.get(className);
/* 118 */     if (value == null) {
/* 119 */       return (SEXP)Null.INSTANCE;
/*     */     }
/* 121 */     return value;
/*     */   }
/*     */ 
/*     */   
/*     */   public void putExtends(String className, SEXP klass) {
/* 126 */     this.extendsTable.put(className, klass);
/*     */   }
/*     */   
/*     */   public Environment getMethodsNamespace() {
/* 130 */     Preconditions.checkState((this.methodsNamespace != null), "methods namespace is not loaded.");
/* 131 */     return this.methodsNamespace;
/*     */   }
/*     */ 
/*     */   
/*     */   public SEXP standardGeneric(Context context, Symbol fname, Environment ev, SEXP fdef) {
/* 136 */     if (this.tableDispatchEnabled) {
/* 137 */       return R_dispatchGeneric(context, fname, ev, fdef);
/*     */     }
/* 139 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public SEXP R_dispatchGeneric(Context context, Symbol fname, Environment ev, SEXP fdef) {
/* 144 */     throw new UnsupportedOperationException("TO REMOVE");
/*     */   }
/*     */ 
/*     */   
/*     */   public SEXP R_standardGeneric(Context context, Symbol fsym, Environment ev, SEXP fdef) {
/*     */     Null null2;
/*     */     SEXP f;
/* 151 */     String fname = fsym.getPrintName();
/* 152 */     Environment f_env = context.getBaseEnvironment();
/* 153 */     Null null1 = Null.INSTANCE;
/*     */     
/* 155 */     Null null3 = Null.INSTANCE;
/* 156 */     int nprotect = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 161 */     if (fdef instanceof Closure) {
/* 162 */       f_env = ((Closure)fdef).getEnclosingEnvironment();
/* 163 */       SEXP sEXP = f_env.getVariable(context, ".Methods");
/* 164 */       if (sEXP == Symbol.UNBOUND_VALUE)
/* 165 */         null1 = Null.INSTANCE; 
/*     */     } else {
/* 167 */       if (fdef instanceof org.renjin.sexp.PrimitiveFunction) {
/* 168 */         f_env = context.getBaseEnvironment();
/*     */         
/* 170 */         throw new UnsupportedOperationException();
/*     */       } 
/* 172 */       throw new EvalException("invalid generic function object for method selection for function '%s': expected a function or a primitive, got an object of class \"%s\"", new Object[] { fsym
/* 173 */             .getPrintName(), fdef.getAttributes().getClassVector() });
/*     */     } 
/* 175 */     if (null1 instanceof Null || null1 instanceof Closure || null1 instanceof org.renjin.sexp.PrimitiveFunction) {
/* 176 */       null2 = null1;
/*     */     } else {
/*     */       
/* 179 */       throw new UnsupportedOperationException();
/*     */     } 
/* 181 */     if (null2 == Null.INSTANCE) {
/* 182 */       SEXP value = R_S_MethodsListSelect(context, (SEXP)StringArrayVector.valueOf(fname), (SEXP)ev, (SEXP)null1, (SEXP)f_env);
/* 183 */       if (value == Null.INSTANCE) {
/* 184 */         throw new EvalException("no direct or inherited method for function '%s' for this call", new Object[] { fname });
/*     */       }
/*     */       
/* 187 */       SEXP sEXP1 = value;
/*     */ 
/*     */       
/* 190 */       f = do_dispatch(context, fname, (SEXP)ev, sEXP1, false, true);
/*     */     } 
/*     */     
/* 193 */     if (f.isObject()) {
/* 194 */       f = R_loadMethod(context, f, fsym.getPrintName(), ev);
/*     */     }
/* 196 */     if (f instanceof Closure)
/* 197 */       return R_execMethod(context, (Closure)f, ev); 
/* 198 */     if (f instanceof org.renjin.sexp.PrimitiveFunction)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 204 */       throw new UnsupportedOperationException();
/*     */     }
/* 206 */     throw new EvalException("invalid object (non-function) used as method", new Object[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private SEXP R_S_MethodsListSelect(Context context, SEXP fname, SEXP ev, SEXP mlist, SEXP f_env) {
/* 212 */     PairList.Builder args = new PairList.Builder();
/* 213 */     args.add(fname);
/* 214 */     args.add(ev);
/* 215 */     args.add(mlist);
/* 216 */     if (f_env != Null.INSTANCE) {
/* 217 */       args.add(f_env);
/*     */     }
/*     */     
/*     */     try {
/* 221 */       return context.evaluate((SEXP)new FunctionCall((SEXP)s_MethodsListSelect, args.build()), this.methodsNamespace);
/* 222 */     } catch (EvalException e) {
/* 223 */       throw new EvalException(String.format("S language method selection got an error when called from internal dispatch for function '%s'", new Object[] { fname }), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static SEXP R_loadMethod(Context context, SEXP def, String fname, Environment ev) {
/* 236 */     int found = 1;
/*     */     
/* 238 */     PairList attrib = def.getAttributes().asPairList();
/* 239 */     for (PairList.Node s : attrib.nodes()) {
/* 240 */       Symbol symbol = s.getTag();
/* 241 */       if (symbol == R_target) {
/* 242 */         ev.setVariable(context, R_dot_target, s.getValue());
/* 243 */         found++; continue;
/*     */       } 
/* 245 */       if (symbol == R_defined) {
/* 246 */         ev.setVariable(context, R_dot_defined, s.getValue());
/* 247 */         found++; continue;
/*     */       } 
/* 249 */       if (symbol == R_nextMethod) {
/* 250 */         ev.setVariable(context, R_dot_nextMethod, s.getValue());
/* 251 */         found++; continue;
/*     */       } 
/* 253 */       if (symbol == Symbols.SOURCE) {
/* 254 */         found++;
/*     */       }
/*     */     } 
/* 257 */     ev.setVariable(context, R_dot_Method, def);
/*     */ 
/*     */ 
/*     */     
/* 261 */     if (fname.equals("loadMethod")) {
/* 262 */       return def;
/*     */     }
/* 264 */     if (found < attrib.length()) {
/* 265 */       FunctionCall call = FunctionCall.newCall((SEXP)R_loadMethod_name, new SEXP[] { def, (SEXP)StringArrayVector.valueOf(fname), (SEXP)ev });
/* 266 */       return context.evaluate((SEXP)call, ev);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 277 */     return def;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private SEXP do_dispatch(Context context, String fname, SEXP ev, SEXP mlist, boolean firstTry, boolean evalArgs) {
/*     */     String klass;
/*     */     Symbol arg_sym;
/* 286 */     Null null = Null.INSTANCE;
/* 287 */     int nprotect = 0;
/*     */     
/* 289 */     if (mlist instanceof Function) {
/* 290 */       return mlist;
/*     */     }
/* 292 */     SEXP arg_slot = Methods.R_do_slot(context, mlist, (SEXP)s_argument);
/* 293 */     if (arg_slot == Null.INSTANCE) {
/* 294 */       throw new EvalException("object of class \"%s\" used as methods list for function '%s' ( no 'argument' slot)", new Object[] { mlist
/*     */             
/* 296 */             .toString(), fname });
/*     */     }
/* 298 */     if (arg_slot instanceof Symbol) {
/* 299 */       arg_sym = (Symbol)arg_slot;
/*     */     }
/*     */     else {
/*     */       
/* 303 */       arg_sym = Symbol.get(arg_slot.asString());
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 315 */     if (evalArgs) {
/* 316 */       if (is_missing_arg(context, arg_sym, (Environment)ev)) {
/* 317 */         klass = "missing";
/*     */       } else {
/*     */         SEXP arg;
/*     */         
/*     */         try {
/* 322 */           arg = context.evaluate((SEXP)arg_sym, (Environment)ev);
/* 323 */         } catch (EvalException e) {
/* 324 */           throw new EvalException(String.format("error in evaluating the argument '%s' in selecting a method for function '%s'", new Object[] { arg_sym
/* 325 */                   .getPrintName(), fname }), e);
/*     */         } 
/*     */         
/* 328 */         StringVector stringVector = Methods.R_data_class(arg, true);
/* 329 */         klass = stringVector.asString();
/*     */       } 
/*     */     } else {
/*     */       SEXP arg;
/*     */       
/*     */       try {
/* 335 */         arg = context.evaluate((SEXP)arg_sym, (Environment)ev);
/* 336 */       } catch (Exception e) {
/* 337 */         throw new EvalException(String.format("error in evaluating the argument '%s' in selecting a method for function '%s'", new Object[] { arg_sym
/* 338 */                 .getPrintName(), fname }), new Object[0]);
/*     */       } 
/* 340 */       klass = arg.asString();
/*     */     } 
/* 342 */     SEXP method = R_find_method(mlist, klass, fname);
/* 343 */     if (method == Null.INSTANCE && 
/* 344 */       !firstTry) {
/* 345 */       throw new EvalException("no matching method for function '%s' (argument '%s', with class \"%s\")", new Object[] { fname, arg_sym
/* 346 */             .getPrintName(), klass });
/*     */     }
/*     */     
/* 349 */     if (null == Symbol.MISSING_ARG)
/*     */     {
/* 351 */       throw new EvalException("recursive use of function '%s' in method selection, with no default method", new Object[] { fname });
/*     */     }
/*     */     
/* 354 */     if (!(method instanceof Function))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 360 */       method = do_dispatch(context, null, ev, method, firstTry, evalArgs);
/*     */     }
/* 362 */     return method;
/*     */   }
/*     */ 
/*     */   
/*     */   private SEXP R_find_method(SEXP mlist, String klass, String fname) {
/* 367 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean is_missing_arg(Context context, Symbol arg_sym, Environment ev) {
/* 372 */     return Evaluation.missing(context, ev, arg_sym);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SEXP R_execMethod(Context context, Closure op, Environment rho) {
/* 380 */     Environment.Builder newrho = Environment.createChildEnvironment(op.getEnclosingEnvironment());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 388 */     for (PairList.Node next : op.getFormals().nodes()) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 399 */       if (!next.hasTag()) {
/* 400 */         throw new EvalException("closure formal has no tag! op = " + op, new Object[0]);
/*     */       }
/*     */       
/* 403 */       Symbol symbol = next.getTag();
/* 404 */       SEXP sEXP = rho.findVariable(context, symbol);
/* 405 */       if (sEXP == Symbol.UNBOUND_VALUE) {
/* 406 */         throw new EvalException("could not find symbol \"%s\" in the environment of the generic function", new Object[] { symbol.getPrintName() });
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 412 */       newrho.setVariable(symbol, sEXP);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 435 */     newrho.setVariable(DOT_DEFINED, rho.findVariableOrThrow(context, DOT_DEFINED));
/* 436 */     newrho.setVariable(DOT_METHOD, rho.findVariableOrThrow(context, DOT_METHOD));
/* 437 */     newrho.setVariable(DOT_TARGET, rho.findVariableOrThrow(context, DOT_TARGET));
/*     */ 
/*     */ 
/*     */     
/* 441 */     newrho.setVariable(DOT_GENERIC, rho.findVariableOrThrow(context, DOT_GENERIC));
/* 442 */     newrho.setVariable(DOT_METHODS, rho.findVariableOrThrow(context, DOT_METHODS));
/*     */ 
/*     */ 
/*     */     
/* 446 */     Context cptr = context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 454 */     Environment callerenv = cptr.getCallingEnvironment();
/*     */ 
/*     */ 
/*     */     
/* 458 */     FunctionCall call = cptr.getCall();
/* 459 */     PairList arglist = cptr.getArguments();
/* 460 */     SEXP val = R_execClosure(context, call, op, arglist, callerenv, newrho.build());
/* 461 */     return val;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static SEXP R_execClosure(Context context, FunctionCall call, Closure op, PairList arglist, Environment callerenv, Environment newrho) {
/* 467 */     return Calls.applyClosure(op, context, callerenv, call, arglist, newrho.getFrame());
/*     */   }
/*     */ 
/*     */   
/*     */   private SEXP do_inherited_table(Context context, SEXP class_objs, SEXP fdef, SEXP mtable, Environment ev) {
/* 472 */     Function function = this.methodsNamespace.findFunction(context, Symbol.get(".InheritForDispatch"));
/*     */     
/* 474 */     return context.evaluate((SEXP)FunctionCall.newCall((SEXP)function, new SEXP[] { class_objs, fdef, mtable }), ev);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/methods/MethodDispatch.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */