/*    */ package org.renjin.compiler.cfg;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Edge
/*    */ {
/*    */   private BasicBlock predecessor;
/*    */   private BasicBlock successor;
/*    */   
/*    */   public Edge(BasicBlock predecessor, BasicBlock successor) {
/* 29 */     this.predecessor = predecessor;
/* 30 */     this.successor = successor;
/*    */   }
/*    */   
/*    */   public BasicBlock getPredecessor() {
/* 34 */     return this.predecessor;
/*    */   }
/*    */   
/*    */   public BasicBlock getSuccessor() {
/* 38 */     return this.successor;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/cfg/Edge.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */