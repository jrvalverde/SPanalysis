/*    */ package org.renjin.primitives.ni;
/*    */ 
/*    */ import org.renjin.sexp.AttributeMap;
/*    */ import org.renjin.sexp.IntVector;
/*    */ import org.renjin.sexp.SEXP;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NativeOutputIntVector
/*    */   extends IntVector
/*    */   implements NativeOutputVector
/*    */ {
/*    */   private DeferredNativeCall call;
/*    */   private final int outputIndex;
/*    */   private int length;
/*    */   private int[] array;
/*    */   
/*    */   public NativeOutputIntVector(DeferredNativeCall call, int outputIndex, int length, AttributeMap attributes) {
/* 35 */     super(attributes);
/* 36 */     this.call = call;
/* 37 */     this.outputIndex = outputIndex;
/* 38 */     this.length = length;
/*    */   }
/*    */ 
/*    */   
/*    */   public int length() {
/* 43 */     return this.length;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected SEXP cloneWithNewAttributes(AttributeMap attributes) {
/* 49 */     return (SEXP)new NativeOutputIntVector(this.call, this.outputIndex, this.length, attributes);
/*    */   }
/*    */ 
/*    */   
/*    */   public int getElementAsInt(int i) {
/* 54 */     if (this.array == null) {
/* 55 */       this.array = (int[])this.call.output(this.outputIndex);
/*    */     }
/* 57 */     return this.array[i];
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isConstantAccessTime() {
/* 63 */     return this.call.isEvaluated();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isDeferred() {
/* 68 */     return !this.call.isEvaluated();
/*    */   }
/*    */ 
/*    */   
/*    */   public DeferredNativeCall getCall() {
/* 73 */     return this.call;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getOutputIndex() {
/* 78 */     return this.outputIndex;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/ni/NativeOutputIntVector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */