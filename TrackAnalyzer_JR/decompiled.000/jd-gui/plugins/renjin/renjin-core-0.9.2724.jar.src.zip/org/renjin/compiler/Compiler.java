/*    */ package org.renjin.compiler;
/*    */ 
/*    */ import org.renjin.compiler.cfg.ControlFlowGraph;
/*    */ import org.renjin.compiler.cfg.DominanceTree;
/*    */ import org.renjin.compiler.cfg.UseDefMap;
/*    */ import org.renjin.compiler.codegen.ByteCodeEmitter;
/*    */ import org.renjin.compiler.ir.exception.InvalidSyntaxException;
/*    */ import org.renjin.compiler.ir.ssa.SsaTransformer;
/*    */ import org.renjin.compiler.ir.tac.IRBody;
/*    */ import org.renjin.compiler.ir.tac.IRBodyBuilder;
/*    */ import org.renjin.compiler.ir.tac.RuntimeState;
/*    */ import org.renjin.eval.Context;
/*    */ import org.renjin.eval.EvalException;
/*    */ import org.renjin.sexp.Environment;
/*    */ import org.renjin.sexp.SEXP;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Compiler
/*    */ {
/*    */   public static CompiledBody tryCompile(Context context, Environment rho, SEXP expression) {
/*    */     try {
/* 43 */       RuntimeState runtimeState = new RuntimeState(context, rho);
/* 44 */       IRBodyBuilder builder = new IRBodyBuilder(runtimeState);
/* 45 */       IRBody body = builder.build(expression);
/*    */       
/* 47 */       ControlFlowGraph cfg = new ControlFlowGraph(body);
/*    */ 
/*    */       
/* 50 */       DominanceTree dTree = new DominanceTree(cfg);
/* 51 */       SsaTransformer ssaTransformer = new SsaTransformer(cfg, dTree);
/* 52 */       ssaTransformer.transform();
/*    */       
/* 54 */       System.out.println(cfg);
/*    */       
/* 56 */       UseDefMap useDefMap = new UseDefMap(cfg);
/* 57 */       TypeSolver types = new TypeSolver(cfg, useDefMap);
/* 58 */       types.execute();
/*    */       
/* 60 */       types.dumpBounds();
/*    */ 
/*    */       
/* 63 */       types.verifyFunctionAssumptions(runtimeState);
/*    */       
/* 65 */       ssaTransformer.removePhiFunctions(types);
/*    */       
/* 67 */       System.out.println(cfg);
/*    */       
/* 69 */       ByteCodeEmitter emitter = new ByteCodeEmitter(cfg, types);
/* 70 */       return emitter.compile().newInstance();
/*    */     }
/* 72 */     catch (NotCompilableException e) {
/* 73 */       System.out.println(e.toString());
/* 74 */       context.warn("Could not compile loop: " + e.toString(context));
/* 75 */       return null;
/*    */     }
/* 77 */     catch (InvalidSyntaxException e) {
/* 78 */       e.printStackTrace();
/* 79 */       throw new EvalException(e.getMessage(), new Object[0]);
/*    */     }
/* 81 */     catch (Exception e) {
/* 82 */       throw new EvalException("Exception compiling loop: " + e.getMessage(), e);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public static boolean tryCompileAndRun(Context context, Environment rho, SEXP expression) {
/* 88 */     CompiledBody body = tryCompile(context, rho, expression);
/* 89 */     if (body == null) {
/* 90 */       return false;
/*    */     }
/*    */     
/* 93 */     body.evaluate(context, rho);
/*    */     
/* 95 */     return true;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/Compiler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */