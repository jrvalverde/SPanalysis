/*    */ package org.renjin.invoke.reflection.converters;
/*    */ 
/*    */ import org.renjin.sexp.SEXP;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Converters
/*    */ {
/*    */   public static Converter get(Class clazz) {
/* 33 */     if (StringConverter.accept(clazz)) {
/* 34 */       return StringConverter.INSTANCE;
/*    */     }
/* 36 */     if (BooleanConverter.accept(clazz)) {
/* 37 */       return BooleanConverter.INSTANCE;
/*    */     }
/* 39 */     if (IntegerConverter.accept(clazz)) {
/* 40 */       return IntegerConverter.INSTANCE;
/*    */     }
/* 42 */     if (LongConverter.accept(clazz)) {
/* 43 */       return LongConverter.INSTANCE;
/*    */     }
/* 45 */     if (FloatConverter.accept(clazz)) {
/* 46 */       return FloatConverter.INSTANCE;
/*    */     }
/* 48 */     if (DoubleConverter.accept(clazz)) {
/* 49 */       return DoubleConverter.INSTANCE;
/*    */     }
/* 51 */     if (SexpConverter.acceptsJava(clazz)) {
/* 52 */       return new SexpConverter(clazz);
/*    */     }
/* 54 */     if (EnumConverter.accept(clazz)) {
/* 55 */       return new EnumConverter(clazz);
/*    */     }
/* 57 */     if (CollectionConverter.accept(clazz)) {
/* 58 */       return new CollectionConverter();
/*    */     }
/* 60 */     if (StringArrayConverter.accept(clazz)) {
/* 61 */       return StringArrayConverter.INSTANCE;
/*    */     }
/* 63 */     if (BooleanArrayConverter.accept(clazz)) {
/* 64 */       return BooleanArrayConverter.INSTANCE;
/*    */     }
/* 66 */     if (IntegerArrayConverter.accept(clazz)) {
/* 67 */       return IntegerArrayConverter.INSTANCE;
/*    */     }
/* 69 */     if (LongArrayConverter.LONG_ARRAY.accept(clazz)) {
/* 70 */       return LongArrayConverter.LONG_ARRAY;
/*    */     }
/* 72 */     if (FloatArrayConverter.FLOAT_ARRAY.accept(clazz)) {
/* 73 */       return FloatArrayConverter.FLOAT_ARRAY;
/*    */     }
/* 75 */     if (DoubleArrayConverter.DOUBLE_ARRAY.accept(clazz)) {
/* 76 */       return DoubleArrayConverter.DOUBLE_ARRAY;
/*    */     }
/* 78 */     if (BoxedDoubleArrayConverter.BOXED_DOUBLE_ARRAY.accept(clazz)) {
/* 79 */       return BoxedDoubleArrayConverter.BOXED_DOUBLE_ARRAY;
/*    */     }
/* 81 */     if (BoxedFloatArrayConverter.BOXED_FLOAT_ARRAY.accept(clazz)) {
/* 82 */       return BoxedFloatArrayConverter.BOXED_FLOAT_ARRAY;
/*    */     }
/* 84 */     if (ObjectConverter.accept(clazz)) {
/* 85 */       return ObjectConverter.INSTANCE;
/*    */     }
/*    */     
/* 88 */     return new ObjectOfASpecificClassConverter(clazz);
/*    */   }
/*    */ 
/*    */   
/*    */   public static SEXP fromJava(Object obj) {
/* 93 */     return get(obj.getClass()).convertToR(obj);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/reflection/converters/Converters.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */