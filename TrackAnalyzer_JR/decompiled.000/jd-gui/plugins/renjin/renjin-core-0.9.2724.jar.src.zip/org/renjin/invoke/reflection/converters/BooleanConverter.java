/*    */ package org.renjin.invoke.reflection.converters;
/*    */ 
/*    */ import org.renjin.sexp.Logical;
/*    */ import org.renjin.sexp.LogicalArrayVector;
/*    */ import org.renjin.sexp.LogicalVector;
/*    */ import org.renjin.sexp.SEXP;
/*    */ import org.renjin.sexp.Vector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BooleanConverter
/*    */   extends PrimitiveScalarConverter<Boolean>
/*    */ {
/* 28 */   public static final BooleanConverter INSTANCE = new BooleanConverter();
/*    */   
/*    */   public static boolean accept(Class<boolean> clazz) {
/* 31 */     return (clazz == boolean.class || clazz == Boolean.class);
/*    */   }
/*    */ 
/*    */   
/*    */   public LogicalVector convertToR(Boolean value) {
/* 36 */     if (value == null) {
/* 37 */       return (LogicalVector)new LogicalArrayVector(new int[] { LogicalVector.NA });
/*    */     }
/* 39 */     return (LogicalVector)new LogicalArrayVector(new boolean[] { value.booleanValue() });
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Vector.Type getVectorType() {
/* 45 */     return LogicalVector.VECTOR_TYPE;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Object getFirstElement(Vector vector) {
/* 50 */     return Boolean.valueOf((vector.getElementAsLogical(0) != Logical.FALSE));
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean acceptsSEXP(SEXP exp) {
/* 55 */     return exp instanceof LogicalVector;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getSpecificity() {
/* 60 */     return 1;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/reflection/converters/BooleanConverter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */