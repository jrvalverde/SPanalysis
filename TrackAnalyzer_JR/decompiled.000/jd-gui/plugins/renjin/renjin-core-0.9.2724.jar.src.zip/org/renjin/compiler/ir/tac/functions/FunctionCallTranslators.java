/*    */ package org.renjin.compiler.ir.tac.functions;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.renjin.compiler.NotCompilableException;
/*    */ import org.renjin.repackaged.guava.collect.Maps;
/*    */ import org.renjin.sexp.Closure;
/*    */ import org.renjin.sexp.Function;
/*    */ import org.renjin.sexp.PrimitiveFunction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FunctionCallTranslators
/*    */ {
/* 31 */   private Map<String, FunctionCallTranslator> specials = Maps.newHashMap();
/* 32 */   private Map<String, FunctionCallTranslator> builtins = Maps.newHashMap();
/*    */   
/*    */   public FunctionCallTranslators() {
/* 35 */     this.specials.put("if", new IfTranslator());
/* 36 */     this.specials.put("{", new BracketTranslator());
/* 37 */     this.specials.put("(", new ParenTranslator());
/* 38 */     this.specials.put("<-", new AssignLeftTranslator());
/* 39 */     this.specials.put("<<-", new ReassignLeftTranslator());
/* 40 */     this.specials.put("=", new AssignTranslator());
/* 41 */     this.specials.put("for", new ForTranslator());
/* 42 */     this.specials.put("repeat", new RepeatTranslator());
/* 43 */     this.specials.put("while", new WhileTranslator());
/* 44 */     this.specials.put("next", new NextTranslator());
/* 45 */     this.specials.put("break", new BreakTranslator());
/* 46 */     this.specials.put("function", new ClosureTranslator());
/* 47 */     this.specials.put("$", new DollarTranslator());
/* 48 */     this.specials.put("$<-", new DollarAssignTranslator());
/* 49 */     this.specials.put(".Internal", new InternalCallTranslator());
/* 50 */     this.specials.put("&&", new AndTranslator());
/* 51 */     this.specials.put("||", new OrTranslator());
/* 52 */     this.specials.put("switch", new SwitchTranslator());
/* 53 */     this.specials.put("quote", new QuoteTranslator());
/* 54 */     this.specials.put("return", new ReturnTranslator());
/* 55 */     this.specials.put(":", new SequenceTranslator());
/* 56 */     this.specials.put("UseMethod", new UseMethodTranslator());
/* 57 */     this.specials.put("@", new SlotTranslator());
/*    */   }
/*    */   
/*    */   public FunctionCallTranslator get(Function function) {
/* 61 */     if (function instanceof PrimitiveFunction) {
/* 62 */       PrimitiveFunction primitiveFunction = (PrimitiveFunction)function;
/* 63 */       if (this.specials.containsKey(primitiveFunction.getName())) {
/* 64 */         return this.specials.get(primitiveFunction.getName());
/*    */       }
/* 66 */       return BuiltinTranslator.INSTANCE;
/*    */     } 
/*    */ 
/*    */     
/* 70 */     if (function instanceof Closure) {
/* 71 */       return new ClosureCallTranslator((Closure)function);
/*    */     }
/*    */     
/* 74 */     throw new NotCompilableException(function, "Can't handle functions of class " + function.getClass().getName());
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/ir/tac/functions/FunctionCallTranslators.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */