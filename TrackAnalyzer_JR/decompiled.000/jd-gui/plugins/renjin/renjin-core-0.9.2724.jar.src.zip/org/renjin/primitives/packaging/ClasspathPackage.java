/*     */ package org.renjin.primitives.packaging;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.URL;
/*     */ import org.apache.commons.vfs2.FileObject;
/*     */ import org.apache.commons.vfs2.FileSystemException;
/*     */ import org.apache.commons.vfs2.FileSystemManager;
/*     */ import org.renjin.repackaged.guava.io.Resources;
/*     */ import org.renjin.util.NamedByteSource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClasspathPackage
/*     */   extends FileBasedPackage
/*     */ {
/*     */   private ClassLoader classLoader;
/*     */   
/*     */   public ClasspathPackage(ClassLoader classLoader, FqPackageName name) {
/*  38 */     super(name);
/*  39 */     this.classLoader = classLoader;
/*     */   }
/*     */   
/*     */   public ClasspathPackage(FqPackageName name) {
/*  43 */     this(ClasspathPackage.class.getClassLoader(), name);
/*     */   }
/*     */   
/*     */   public boolean exists() {
/*  47 */     return resourceExists("environment");
/*     */   }
/*     */ 
/*     */   
/*     */   public NamedByteSource getResource(String name) throws IOException {
/*  52 */     String qualifiedName = qualifyResourceName(name);
/*  53 */     URL url = this.classLoader.getResource(qualifiedName);
/*  54 */     if (url == null) {
/*  55 */       throw new IOException(String.format("Could not find %s (%s)", new Object[] { name, qualifiedName }));
/*     */     }
/*     */     try {
/*  58 */       return new NamedByteSource(name, Resources.asByteSource(url));
/*  59 */     } catch (Exception e) {
/*  60 */       throw new IOException(String.format("Could not load %s (%s)", new Object[] { name, url.toString() }), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Class loadClass(String name) throws ClassNotFoundException {
/*  66 */     return this.classLoader.loadClass(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public FileObject resolvePackageRoot(FileSystemManager fileSystemManager) throws FileSystemException {
/*     */     FileObject environmentFileObject;
/*  72 */     String qualifiedName = qualifyResourceName("environment");
/*  73 */     String uri = "res:" + qualifiedName;
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*  78 */       environmentFileObject = fileSystemManager.resolveFile(uri);
/*  79 */     } catch (FileSystemException e) {
/*  80 */       throw new FileSystemException("Exception locating package resource '" + uri + "' using the provided VirtualFileSystem, check your Renjin Session configuration.", e);
/*     */     } 
/*     */ 
/*     */     
/*  84 */     if (!environmentFileObject.exists()) {
/*  85 */       throw new FileSystemException("Could not locate resource '" + uri + "' using the provided VirtualFileSystem, check your Renjin Session configuration.");
/*     */     }
/*     */ 
/*     */     
/*  89 */     return environmentFileObject.getParent();
/*     */   }
/*     */ 
/*     */   
/*     */   private String qualifyResourceName(String name) {
/*  94 */     return 
/*  95 */       getName().getGroupId().replace('.', '/') + "/" + 
/*     */       
/*  97 */       getName().getPackageName() + "/" + name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean resourceExists(String name) {
/* 104 */     URL url = this.classLoader.getResource(qualifyResourceName(name));
/* 105 */     return (url != null);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/packaging/ClasspathPackage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */