/*     */ package org.renjin.primitives.packaging;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import org.renjin.eval.Context;
/*     */ import org.renjin.packaging.LazyLoadFrame;
/*     */ import org.renjin.primitives.io.serialization.RDataReader;
/*     */ import org.renjin.repackaged.guava.base.Charsets;
/*     */ import org.renjin.repackaged.guava.base.Function;
/*     */ import org.renjin.repackaged.guava.base.Strings;
/*     */ import org.renjin.repackaged.guava.collect.ImmutableList;
/*     */ import org.renjin.repackaged.guava.collect.Lists;
/*     */ import org.renjin.repackaged.guava.collect.UnmodifiableIterator;
/*     */ import org.renjin.sexp.NamedValue;
/*     */ import org.renjin.sexp.SEXP;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class FileBasedPackage
/*     */   extends Package
/*     */ {
/*     */   protected FileBasedPackage(FqPackageName name) {
/*  44 */     super(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterable<NamedValue> loadSymbols(Context context) throws IOException {
/*  49 */     return LazyLoadFrame.load(context, new Function<String, InputStream>()
/*     */         {
/*     */           public InputStream apply(String name)
/*     */           {
/*     */             try {
/*  54 */               return FileBasedPackage.this.getResource(name).openStream();
/*  55 */             } catch (IOException e) {
/*  56 */               throw new RuntimeException(e);
/*     */             } 
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   public abstract boolean resourceExists(String paramString);
/*     */   
/*     */   private Properties readDatasetIndex() throws IOException {
/*  66 */     Properties datasets = new Properties();
/*  67 */     if (resourceExists("datasets")) {
/*  68 */       try (InputStream in = getResource("datasets").openStream()) {
/*  69 */         datasets.load(in);
/*     */       } 
/*     */     }
/*  72 */     return datasets;
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<String> getPackageDependencies() throws IOException {
/*  77 */     if (resourceExists("requires")) {
/*  78 */       ImmutableList<String> lines = getResource("requires").asCharSource(Charsets.UTF_8).readLines();
/*  79 */       List<String> dependencies = Lists.newArrayList();
/*  80 */       for (UnmodifiableIterator<String> unmodifiableIterator = lines.iterator(); unmodifiableIterator.hasNext(); ) { String line = unmodifiableIterator.next();
/*  81 */         if (!Strings.isNullOrEmpty(line)) {
/*  82 */           dependencies.add(line);
/*     */         } }
/*     */       
/*  85 */       return dependencies;
/*     */     } 
/*     */     
/*  88 */     return Collections.emptyList();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Dataset> getDatasets() {
/*     */     try {
/*  95 */       Properties index = readDatasetIndex();
/*  96 */       List<Dataset> datasets = Lists.newArrayList();
/*  97 */       for (String logicalDatasetName : index.stringPropertyNames()) {
/*  98 */         datasets.add(new FileBasedDataset(logicalDatasetName, index
/*  99 */               .getProperty(logicalDatasetName).split("\\s*,\\s*")));
/*     */       }
/* 101 */       return datasets;
/* 102 */     } catch (IOException e) {
/* 103 */       throw new RuntimeException(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   private class FileBasedDataset
/*     */     extends Dataset
/*     */   {
/*     */     private String datasetName;
/* 111 */     private Map<String, String> objectNameMap = new HashMap<>();
/*     */     
/*     */     public FileBasedDataset(String name, String[] objectNames) {
/* 114 */       this.datasetName = name;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 130 */       for (String objectName : objectNames) {
/* 131 */         if (objectName.contains("/")) {
/*     */ 
/*     */           
/* 134 */           String[] parts = objectName.split("/");
/* 135 */           String member = parts[1];
/* 136 */           this.objectNameMap.put(member, objectName);
/*     */         } else {
/*     */           
/* 139 */           this.objectNameMap.put(objectName, objectName);
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public String getName() {
/* 146 */       return this.datasetName;
/*     */     }
/*     */ 
/*     */     
/*     */     public Collection<String> getObjectNames() {
/* 151 */       return this.objectNameMap.keySet();
/*     */     }
/*     */ 
/*     */     
/*     */     public SEXP loadObject(String name) throws IOException {
/* 156 */       if (!this.objectNameMap.containsKey(name)) {
/* 157 */         throw new IllegalArgumentException(name);
/*     */       }
/* 159 */       try (InputStream in = FileBasedPackage.this.getResource("data/" + (String)this.objectNameMap.get(name)).openStream()) {
/* 160 */         RDataReader reader = new RDataReader(in);
/* 161 */         return reader.readFile();
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/packaging/FileBasedPackage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */