/*     */ package org.renjin.invoke.codegen;
/*     */ 
/*     */ import com.sun.codemodel.JAssignmentTarget;
/*     */ import com.sun.codemodel.JBlock;
/*     */ import com.sun.codemodel.JClass;
/*     */ import com.sun.codemodel.JExpr;
/*     */ import com.sun.codemodel.JExpression;
/*     */ import com.sun.codemodel.JType;
/*     */ import com.sun.codemodel.JVar;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.renjin.eval.Context;
/*     */ import org.renjin.eval.Session;
/*     */ import org.renjin.invoke.model.JvmMethod;
/*     */ import org.renjin.repackaged.guava.collect.Lists;
/*     */ import org.renjin.repackaged.guava.collect.Maps;
/*     */ import org.renjin.sexp.Environment;
/*     */ import org.renjin.sexp.ListVector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VarArgParser
/*     */ {
/*     */   private ApplyMethodContext methodContext;
/*     */   private JBlock parent;
/*     */   private JvmMethod overload;
/*     */   private JVar varArgBuilder;
/*     */   private JVar varArgList;
/*     */   
/*     */   public static class PositionalArg
/*     */   {
/*     */     private final JvmMethod.Argument formal;
/*     */     private final JVar variable;
/*     */     
/*     */     public PositionalArg(JvmMethod.Argument formal, JVar variable) {
/*  45 */       this.formal = formal;
/*  46 */       this.variable = variable;
/*     */     }
/*     */     
/*     */     public JvmMethod.Argument getFormal() {
/*  50 */       return this.formal;
/*     */     }
/*     */     
/*     */     public JVar getVariable() {
/*  54 */       return this.variable;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  64 */   private List<JExpression> arguments = Lists.newArrayList();
/*  65 */   private List<PositionalArg> positionalArguments = Lists.newArrayList();
/*  66 */   private Map<JvmMethod.Argument, JVar> namedFlags = Maps.newHashMap();
/*     */   
/*     */   private JBlock argumentProcessingBlock;
/*     */   
/*     */   public VarArgParser(ApplyMethodContext methodContext, JBlock parent, JvmMethod overload) {
/*  71 */     this.methodContext = methodContext;
/*  72 */     this.parent = parent;
/*  73 */     this.overload = overload;
/*     */     
/*  75 */     boolean varArgsSeen = false;
/*     */     
/*  77 */     this.varArgBuilder = parent.decl((JType)classRef(ListVector.NamedBuilder.class), "varArgs", 
/*  78 */         (JExpression)JExpr._new(classRef(ListVector.NamedBuilder.class)));
/*     */     
/*  80 */     this.varArgList = parent.decl((JType)classRef(ListVector.class), "varArgList");
/*     */     
/*  82 */     for (JvmMethod.Argument formal : this.overload.getAllArguments()) {
/*  83 */       if (formal.isContextual()) {
/*     */ 
/*     */         
/*  86 */         this.arguments.add(contextualExpression(formal)); continue;
/*     */       } 
/*  88 */       if (formal.isVarArg()) {
/*     */         
/*  90 */         this.arguments.add(this.varArgList);
/*  91 */         varArgsSeen = true; continue;
/*     */       } 
/*  93 */       if (formal.isNamedFlag()) {
/*     */ 
/*     */         
/*  96 */         JVar flag = parent.decl(argumentType(formal), nextFlagName(), defaultValueExpression(formal));
/*  97 */         this.namedFlags.put(formal, flag);
/*  98 */         this.arguments.add(flag);
/*     */         
/*     */         continue;
/*     */       } 
/* 102 */       if (varArgsSeen) {
/* 103 */         throw new GeneratorDefinitionException("Any argument following a @ArgumentList must be annotated with @NamedFlag");
/*     */       }
/*     */ 
/*     */       
/* 107 */       JVar arg = parent.decl(argumentType(formal), nextPosName(formal));
/* 108 */       this.arguments.add(arg);
/* 109 */       this.positionalArguments.add(new PositionalArg(formal, arg));
/*     */     } 
/*     */     
/* 112 */     this.argumentProcessingBlock = parent.block();
/*     */     
/* 114 */     parent.block().assign((JAssignmentTarget)this.varArgList, (JExpression)this.varArgBuilder.invoke("build"));
/*     */   }
/*     */   
/*     */   private JExpression contextualExpression(JvmMethod.Argument formal) {
/* 118 */     if (formal.getClazz().equals(Context.class))
/* 119 */       return this.methodContext.getContext(); 
/* 120 */     if (formal.getClazz().equals(Environment.class))
/* 121 */       return this.methodContext.getEnvironment(); 
/* 122 */     if (formal.getClazz().equals(Session.class)) {
/* 123 */       return (JExpression)this.methodContext.getContext().invoke("getSession");
/*     */     }
/* 125 */     throw new RuntimeException("Invalid contextual argument type: " + formal.getClazz());
/*     */   }
/*     */ 
/*     */   
/*     */   private JClass classRef(Class<?> clazz) {
/* 130 */     return this.methodContext.classRef(clazz);
/*     */   }
/*     */   
/*     */   private JExpression defaultValueExpression(JvmMethod.Argument argument) {
/* 134 */     if (argument.getClazz().equals(boolean.class))
/* 135 */       return argument.getDefaultValue() ? JExpr.TRUE : JExpr.FALSE; 
/* 136 */     if (!argument.getClazz().isPrimitive()) {
/* 137 */       return JExpr._null();
/*     */     }
/* 139 */     throw new UnsupportedOperationException("Don't know how to define default value for " + argument);
/*     */   }
/*     */ 
/*     */   
/*     */   private JType argumentType(JvmMethod.Argument argument) {
/* 144 */     return this.methodContext.getCodeModel()._ref(argument.getClazz());
/*     */   }
/*     */   
/*     */   private String nextPosName(JvmMethod.Argument argument) {
/* 148 */     return "pos" + argument.getIndex();
/*     */   }
/*     */   
/*     */   private String nextFlagName() {
/* 152 */     return "flag" + this.namedFlags.size();
/*     */   }
/*     */   
/*     */   public List<PositionalArg> getPositionalArguments() {
/* 156 */     return this.positionalArguments;
/*     */   }
/*     */   
/*     */   public List<JExpression> getArguments() {
/* 160 */     return this.arguments;
/*     */   }
/*     */   
/*     */   public JVar getVarArgBuilder() {
/* 164 */     return this.varArgBuilder;
/*     */   }
/*     */   
/*     */   public JExpression getVarArgList() {
/* 168 */     return (JExpression)this.varArgList;
/*     */   }
/*     */   
/*     */   public Map<JvmMethod.Argument, JVar> getNamedFlags() {
/* 172 */     return this.namedFlags;
/*     */   }
/*     */ 
/*     */   
/*     */   public JExpression getNamedFlagJExp(String name) {
/* 177 */     for (Map.Entry<JvmMethod.Argument, JVar> flag : this.namedFlags.entrySet()) {
/* 178 */       if (((JvmMethod.Argument)flag.getKey()).getName().equals(name)) {
/* 179 */         return (JExpression)flag.getValue();
/*     */       }
/*     */     } 
/* 182 */     throw new UnsupportedOperationException("not such named flag: " + name);
/*     */   }
/*     */   
/*     */   public JBlock getArgumentProcessingBlock() {
/* 186 */     return this.argumentProcessingBlock;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/codegen/VarArgParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */