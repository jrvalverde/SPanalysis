/*    */ package org.renjin.primitives.packaging;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Collection;
/*    */ import org.renjin.sexp.PairList;
/*    */ import org.renjin.sexp.SEXP;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Dataset
/*    */ {
/*    */   public abstract String getName();
/*    */   
/*    */   public abstract Collection<String> getObjectNames();
/*    */   
/*    */   public abstract SEXP loadObject(String paramString) throws IOException;
/*    */   
/*    */   public PairList loadAll() throws IOException {
/* 59 */     PairList.Builder pairList = new PairList.Builder();
/* 60 */     for (String objectName : getObjectNames()) {
/* 61 */       pairList.add(objectName, loadObject(objectName));
/*    */     }
/* 63 */     return pairList.build();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/packaging/Dataset.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */