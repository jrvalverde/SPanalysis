/*     */ package org.renjin.compiler.ir.tac.statements;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import org.renjin.compiler.codegen.EmitContext;
/*     */ import org.renjin.compiler.ir.tac.IRLabel;
/*     */ import org.renjin.compiler.ir.tac.expressions.Expression;
/*     */ import org.renjin.repackaged.asm.commons.InstructionAdapter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExprStatement
/*     */   implements Statement
/*     */ {
/*     */   private Expression operand;
/*     */   
/*     */   public ExprStatement(Expression operand) {
/*  39 */     this.operand = operand;
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterable<IRLabel> possibleTargets() {
/*  44 */     return Collections.emptySet();
/*     */   }
/*     */ 
/*     */   
/*     */   public Expression getRHS() {
/*  49 */     return this.operand;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  54 */     return this.operand.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setRHS(Expression newRHS) {
/*  59 */     this.operand = newRHS;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getChildCount() {
/*  64 */     return 1;
/*     */   }
/*     */ 
/*     */   
/*     */   public Expression childAt(int index) {
/*  69 */     if (index == 0) {
/*  70 */       return this.operand;
/*     */     }
/*  72 */     throw new IllegalArgumentException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setChild(int childIndex, Expression child) {
/*  78 */     if (childIndex == 0) {
/*  79 */       this.operand = child;
/*     */     } else {
/*  81 */       throw new IllegalArgumentException();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void accept(StatementVisitor visitor) {
/*  87 */     visitor.visitExprStatement(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public int emit(EmitContext emitContext, InstructionAdapter mv) {
/*  92 */     if (!this.operand.isPure()) {
/*  93 */       int stackSizeIncrease = this.operand.load(emitContext, mv);
/*  94 */       mv.visitInsn(87);
/*  95 */       return stackSizeIncrease;
/*     */     } 
/*  97 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isPure() {
/* 103 */     return getRHS().isPure();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/ir/tac/statements/ExprStatement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */