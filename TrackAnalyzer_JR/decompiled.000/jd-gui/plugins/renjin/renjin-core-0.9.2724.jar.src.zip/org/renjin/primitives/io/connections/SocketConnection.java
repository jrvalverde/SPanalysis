/*     */ package org.renjin.primitives.io.connections;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.net.Socket;
/*     */ import java.net.UnknownHostException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SocketConnection
/*     */   implements Connection
/*     */ {
/*     */   private final Socket socket;
/*     */   private PushbackBufferedReader reader;
/*     */   private PrintWriter writer;
/*     */   private String description;
/*  32 */   private OpenSpec openSpec = new OpenSpec("rw");
/*     */   
/*     */   public SocketConnection(String host, int port) throws UnknownHostException, IOException {
/*  35 */     this.socket = new Socket(host, port);
/*  36 */     this.description = host + ":" + port;
/*     */   }
/*     */ 
/*     */   
/*     */   public OutputStream getOutputStream() throws IOException {
/*  41 */     return this.socket.getOutputStream();
/*     */   }
/*     */ 
/*     */   
/*     */   public InputStream getInputStream() throws IOException {
/*  46 */     return this.socket.getInputStream();
/*     */   }
/*     */ 
/*     */   
/*     */   public PushbackBufferedReader getReader() throws IOException {
/*  51 */     if (this.reader == null) {
/*  52 */       this
/*  53 */         .reader = new PushbackBufferedReader(new InputStreamReader(getInputStream()));
/*     */     }
/*  55 */     return this.reader;
/*     */   }
/*     */ 
/*     */   
/*     */   public PrintWriter getPrintWriter() throws IOException {
/*  60 */     if (this.writer == null) {
/*  61 */       this.writer = new PrintWriter(getOutputStream());
/*     */     }
/*  63 */     return this.writer;
/*     */   }
/*     */ 
/*     */   
/*     */   public PrintWriter getOpenPrintWriter() {
/*  68 */     if (this.writer == null) {
/*  69 */       throw new IllegalStateException("not open");
/*     */     }
/*  71 */     return this.writer;
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/*  76 */     if (this.writer != null) {
/*  77 */       this.writer.flush();
/*     */     }
/*  79 */     this.socket.close();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isOpen() {
/*  84 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void flush() throws IOException {
/*  89 */     if (this.writer != null) {
/*  90 */       this.writer.flush();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void open(OpenSpec spec) throws IOException {
/*  96 */     this.openSpec = spec;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getClassName() {
/* 101 */     return "socket";
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDescription() {
/* 106 */     return this.description;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getMode() {
/* 111 */     return "rw";
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canRead() {
/* 116 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canWrite() {
/* 121 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public Connection.Type getType() {
/* 126 */     return this.openSpec.getType();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/io/connections/SocketConnection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */