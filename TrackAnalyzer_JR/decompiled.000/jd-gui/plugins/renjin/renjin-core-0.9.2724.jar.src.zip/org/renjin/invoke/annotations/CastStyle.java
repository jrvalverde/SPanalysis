/*    */ package org.renjin.invoke.annotations;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum CastStyle
/*    */ {
/* 22 */   IMPLICIT,
/* 23 */   EXPLICIT;
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/annotations/CastStyle.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */