/*    */ package org.renjin.invoke.reflection.converters;
/*    */ 
/*    */ import org.renjin.sexp.SEXP;
/*    */ import org.renjin.sexp.StringVector;
/*    */ import org.renjin.sexp.Vector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EnumConverter
/*    */   extends PrimitiveScalarConverter<Enum>
/*    */ {
/*    */   private Class enumType;
/*    */   
/*    */   public EnumConverter(Class enumType) {
/* 34 */     this.enumType = enumType;
/*    */   }
/*    */ 
/*    */   
/*    */   public SEXP convertToR(Enum value) {
/* 39 */     return (SEXP)StringVector.valueOf(value.name());
/*    */   }
/*    */ 
/*    */   
/*    */   public Vector.Type getVectorType() {
/* 44 */     return StringVector.VECTOR_TYPE;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Object getFirstElement(Vector value) {
/* 49 */     return Enum.valueOf(this.enumType, value.getElementAsString(0));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static boolean accept(Class<?> clazz) {
/* 58 */     return Enum.class.isAssignableFrom(clazz);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean acceptsSEXP(SEXP exp) {
/* 63 */     return exp instanceof StringVector;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getSpecificity() {
/* 68 */     return 300;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/reflection/converters/EnumConverter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */