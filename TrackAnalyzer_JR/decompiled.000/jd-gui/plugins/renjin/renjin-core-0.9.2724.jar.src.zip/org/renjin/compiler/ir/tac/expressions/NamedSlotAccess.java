/*     */ package org.renjin.compiler.ir.tac.expressions;
/*     */ 
/*     */ import java.util.Map;
/*     */ import org.renjin.compiler.codegen.EmitContext;
/*     */ import org.renjin.compiler.ir.ValueBounds;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ import org.renjin.repackaged.asm.commons.InstructionAdapter;
/*     */ import org.renjin.sexp.Symbol;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NamedSlotAccess
/*     */   implements Expression
/*     */ {
/*     */   private Expression expression;
/*     */   private Symbol slot;
/*     */   private ValueBounds valueBounds;
/*     */   
/*     */   public NamedSlotAccess(Expression expression, String slot) {
/*  40 */     this.expression = expression;
/*  41 */     this.slot = Symbol.get(slot);
/*     */     
/*  43 */     this.valueBounds = ValueBounds.UNBOUNDED;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPure() {
/*  48 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int load(EmitContext emitContext, InstructionAdapter mv) {
/*  53 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ValueBounds updateTypeBounds(Map<Expression, ValueBounds> typeMap) {
/*  59 */     ValueBounds object = typeMap.get(this.expression);
/*     */     
/*  61 */     if (object.isAttributeConstant(this.slot)) {
/*  62 */       this.valueBounds = ValueBounds.of(object.getAttributeIfConstant(this.slot));
/*     */     } else {
/*  64 */       throw new UnsupportedOperationException("TODO: ");
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  69 */     return this.valueBounds;
/*     */   }
/*     */ 
/*     */   
/*     */   public Type getType() {
/*  74 */     return this.valueBounds.storageType();
/*     */   }
/*     */ 
/*     */   
/*     */   public ValueBounds getValueBounds() {
/*  79 */     return this.valueBounds;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setChild(int childIndex, Expression child) {
/*  85 */     if (childIndex != 0) {
/*  86 */       throw new IllegalArgumentException("childIndex:" + childIndex);
/*     */     }
/*  88 */     this.expression = child;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getChildCount() {
/*  93 */     return 1;
/*     */   }
/*     */ 
/*     */   
/*     */   public Expression childAt(int index) {
/*  98 */     return this.expression;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 104 */     return this.expression + "@" + this.slot;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/ir/tac/expressions/NamedSlotAccess.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */