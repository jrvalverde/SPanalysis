/*    */ package org.renjin.parser;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class FunctionSourceBuffer
/*    */ {
/*    */   private static final int MAX_NEST = 256;
/*    */   private static final int MAXFUNSIZE = 131072;
/*    */   private boolean overflow = false;
/* 30 */   private StringBuffer source = new StringBuffer();
/*    */   
/* 32 */   private int level = 0;
/*    */   
/* 34 */   private ArrayList<Integer> startIndices = new ArrayList<>();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void descend() {
/* 40 */     if (this.level >= 256) {
/* 41 */       throw new RLexException("functions nested too deeply in source code at line %d");
/*    */     }
/* 43 */     if (this.level++ == 0) {
/* 44 */       this.source.setLength(0);
/* 45 */       this.source.append("function");
/*    */     } 
/* 47 */     this.startIndices.add(Integer.valueOf(this.source.length() - 8));
/*    */   }
/*    */   
/*    */   public void maybeAppendSourceCodePoint(int c) {
/* 51 */     if (this.level > 0 && 
/* 52 */       this.source.length() > 131072)
/*    */     {
/* 54 */       throw new RLexException("function is too long to keep source");
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void ascend() {
/* 61 */     this.level--;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/parser/FunctionSourceBuffer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */