/*    */ package org.renjin.compiler.ir.tac.functions;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.renjin.compiler.ir.exception.InvalidSyntaxException;
/*    */ import org.renjin.compiler.ir.tac.IRArgument;
/*    */ import org.renjin.compiler.ir.tac.IRBodyBuilder;
/*    */ import org.renjin.compiler.ir.tac.expressions.BuiltinCall;
/*    */ import org.renjin.compiler.ir.tac.expressions.Expression;
/*    */ import org.renjin.compiler.ir.tac.statements.ExprStatement;
/*    */ import org.renjin.compiler.ir.tac.statements.Statement;
/*    */ import org.renjin.primitives.Primitives;
/*    */ import org.renjin.sexp.Function;
/*    */ import org.renjin.sexp.FunctionCall;
/*    */ import org.renjin.sexp.SEXP;
/*    */ import org.renjin.sexp.Symbol;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InternalCallTranslator
/*    */   extends FunctionCallTranslator
/*    */ {
/*    */   public Expression translateToExpression(IRBodyBuilder builder, TranslationContext context, Function resolvedFunction, FunctionCall call) {
/* 41 */     SEXP argument = call.getArgument(0);
/* 42 */     if (!(argument instanceof FunctionCall)) {
/* 43 */       throw new InvalidSyntaxException(".Internal() expects a language object as its only argument");
/*    */     }
/*    */     
/* 46 */     FunctionCall primitiveCall = (FunctionCall)argument;
/* 47 */     if (!(primitiveCall.getFunction() instanceof Symbol)) {
/* 48 */       throw new InvalidSyntaxException("Invalid .Internal() argument");
/*    */     }
/*    */     
/* 51 */     Symbol internalName = (Symbol)primitiveCall.getFunction();
/* 52 */     Primitives.Entry entry = Primitives.getInternalEntry(internalName);
/* 53 */     if (entry == null) {
/* 54 */       throw new InvalidSyntaxException("No such .Internal function '" + internalName + "'");
/*    */     }
/*    */     
/* 57 */     List<IRArgument> internalArguments = builder.translateArgumentList(context, primitiveCall.getArguments());
/*    */     
/* 59 */     return (Expression)new BuiltinCall(builder.getRuntimeState(), call, internalName.getPrintName(), internalArguments);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void addStatement(IRBodyBuilder builder, TranslationContext context, Function resolvedFunction, FunctionCall call) {
/* 65 */     builder.addStatement((Statement)new ExprStatement(
/* 66 */           translateToExpression(builder, context, resolvedFunction, call)));
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/ir/tac/functions/InternalCallTranslator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */