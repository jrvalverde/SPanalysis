/*    */ package org.renjin.compiler.ir.ssa;
/*    */ 
/*    */ import org.renjin.compiler.ir.IRFormatting;
/*    */ import org.renjin.compiler.ir.tac.expressions.Variable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SsaVariable
/*    */   extends Variable
/*    */ {
/*    */   private final Variable inner;
/*    */   private final int version;
/*    */   
/*    */   public SsaVariable(Variable inner, int version) {
/* 31 */     if (inner instanceof SsaVariable) {
/* 32 */       throw new IllegalArgumentException("SSA variables should not be nested");
/*    */     }
/* 34 */     this.inner = inner;
/* 35 */     this.version = version;
/*    */   }
/*    */   
/*    */   public Variable getInner() {
/* 39 */     return this.inner;
/*    */   }
/*    */   
/*    */   public int getVersion() {
/* 43 */     return this.version;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isPure() {
/* 48 */     if (this.version == 0)
/*    */     {
/*    */       
/* 51 */       return false;
/*    */     }
/*    */     
/* 54 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 61 */     StringBuilder sb = new StringBuilder();
/* 62 */     sb.append(this.inner.toString());
/*    */     
/* 64 */     IRFormatting.appendSubscript(sb, this.version);
/*    */     
/* 66 */     return sb.toString();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 72 */     int prime = 31;
/* 73 */     int result = 1;
/* 74 */     result = 31 * result + this.inner.hashCode();
/* 75 */     result = 31 * result + this.version;
/* 76 */     return result;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 81 */     if (this == obj) {
/* 82 */       return true;
/*    */     }
/* 84 */     if (obj == null) {
/* 85 */       return false;
/*    */     }
/* 87 */     if (getClass() != obj.getClass()) {
/* 88 */       return false;
/*    */     }
/* 90 */     SsaVariable other = (SsaVariable)obj;
/* 91 */     return (this.inner.equals(other.inner) && this.version == other.version);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/ir/ssa/SsaVariable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */