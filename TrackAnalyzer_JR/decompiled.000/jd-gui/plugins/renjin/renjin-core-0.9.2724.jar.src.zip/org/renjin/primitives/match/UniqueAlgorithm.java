/*    */ package org.renjin.primitives.match;
/*    */ 
/*    */ import org.renjin.sexp.SEXP;
/*    */ import org.renjin.sexp.Vector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UniqueAlgorithm
/*    */   implements DuplicateSearchAlgorithm<Vector>
/*    */ {
/*    */   private Vector source;
/*    */   private boolean[] unique;
/*    */   private int uniqueCount;
/*    */   
/*    */   public void init(Vector source) {
/* 31 */     this.source = source;
/* 32 */     this.unique = new boolean[source.length()];
/*    */   }
/*    */ 
/*    */   
/*    */   public void onUnique(int index) {
/* 37 */     this.unique[index] = true;
/* 38 */     this.uniqueCount++;
/*    */   }
/*    */ 
/*    */   
/*    */   public DuplicateSearchAlgorithm.Action onDuplicate(int duplicateIndex, int originalIndex) {
/* 43 */     return DuplicateSearchAlgorithm.Action.CONTINUE;
/*    */   }
/*    */ 
/*    */   
/*    */   public Vector getResult() {
/* 48 */     Vector.Builder result = this.source.newBuilderWithInitialCapacity(this.uniqueCount);
/* 49 */     for (int i = 0; i != this.unique.length; i++) {
/* 50 */       if (this.unique[i]) {
/* 51 */         result.addFrom((SEXP)this.source, i);
/*    */       }
/*    */     } 
/*    */     
/* 55 */     return result.build();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/match/UniqueAlgorithm.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */