package org.renjin.compiler.ir.tac.expressions;

import java.util.Map;
import org.renjin.compiler.codegen.EmitContext;
import org.renjin.compiler.ir.ValueBounds;
import org.renjin.compiler.ir.tac.TreeNode;
import org.renjin.repackaged.asm.Type;
import org.renjin.repackaged.asm.commons.InstructionAdapter;

public interface Expression extends TreeNode {
  boolean isPure();
  
  int load(EmitContext paramEmitContext, InstructionAdapter paramInstructionAdapter);
  
  Type getType();
  
  ValueBounds updateTypeBounds(Map<Expression, ValueBounds> paramMap);
  
  ValueBounds getValueBounds();
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/ir/tac/expressions/Expression.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */