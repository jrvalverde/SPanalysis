/*     */ package org.renjin.eval;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.renjin.compiler.builtins.ArgumentBounds;
/*     */ import org.renjin.compiler.ir.tac.IRArgument;
/*     */ import org.renjin.sexp.Closure;
/*     */ import org.renjin.sexp.Symbol;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MatchedArgumentPositions
/*     */ {
/*     */   private final boolean[] matchedActuals;
/*     */   private String[] formalNames;
/*     */   private final int formalEllipses;
/*     */   private final int[] formalMatches;
/*     */   private int extraArgumentCount;
/*     */   
/*     */   MatchedArgumentPositions(String[] formalNames, int[] formalMatches, boolean[] matchedActuals, int formalEllipses) {
/*  46 */     this.formalNames = formalNames;
/*  47 */     this.formalMatches = formalMatches;
/*     */     
/*  49 */     this.matchedActuals = matchedActuals;
/*  50 */     this.formalEllipses = formalEllipses;
/*  51 */     this.extraArgumentCount = 0;
/*  52 */     for (int i = 0; i < matchedActuals.length; i++) {
/*  53 */       if (!matchedActuals[i]) {
/*  54 */         this.extraArgumentCount++;
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public static MatchedArgumentPositions matchIRArguments(Closure closure, List<IRArgument> arguments) {
/*  60 */     String[] names = new String[arguments.size()];
/*  61 */     for (int i = 0; i < names.length; i++) {
/*  62 */       names[i] = ((IRArgument)arguments.get(i)).getName();
/*     */     }
/*  64 */     return (new ArgumentMatcher(closure)).match(names);
/*     */   }
/*     */   
/*     */   public static MatchedArgumentPositions matchArgumentBounds(Closure closure, List<ArgumentBounds> arguments) {
/*  68 */     String[] names = new String[arguments.size()];
/*  69 */     for (int i = 0; i < names.length; i++) {
/*  70 */       names[i] = ((ArgumentBounds)arguments.get(i)).getName();
/*     */     }
/*  72 */     return (new ArgumentMatcher(closure)).match(names);
/*     */   }
/*     */   
/*     */   public Set<Symbol> getSuppliedFormals() {
/*  76 */     return getMatchedFormals().keySet();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getActualIndex(int formalIndex) {
/*  84 */     return this.formalMatches[formalIndex];
/*     */   }
/*     */   
/*     */   public Map<Symbol, Integer> getMatchedFormals() {
/*  88 */     HashMap<Symbol, Integer> map = new HashMap<>();
/*  89 */     for (int i = 0; i < this.formalMatches.length; i++) {
/*  90 */       if (this.formalMatches[i] != -1) {
/*  91 */         map.put(Symbol.get(this.formalNames[i]), Integer.valueOf(this.formalMatches[i]));
/*     */       }
/*     */     } 
/*  94 */     return map;
/*     */   }
/*     */   
/*     */   public boolean hasExtraArguments() {
/*  98 */     return (this.extraArgumentCount > 0);
/*     */   }
/*     */   
/*     */   public int getExtraArgumentCount() {
/* 102 */     return this.extraArgumentCount;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isExtraArgument(int actualIndex) {
/* 107 */     return !this.matchedActuals[actualIndex];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Symbol getFormalName(int i) {
/* 114 */     return Symbol.get(this.formalNames[i]);
/*     */   }
/*     */   
/*     */   public int getFormalCount() {
/* 118 */     return this.formalNames.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean allFormalsMatched() {
/* 126 */     for (int i = 0; i < this.formalMatches.length; i++) {
/* 127 */       if (i != this.formalEllipses && this.formalMatches[i] == -1) {
/* 128 */         return false;
/*     */       }
/*     */     } 
/* 131 */     return true;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/eval/MatchedArgumentPositions.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */