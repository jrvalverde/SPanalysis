/*     */ package org.renjin.primitives.subset;
/*     */ 
/*     */ import org.renjin.eval.Context;
/*     */ import org.renjin.eval.EvalException;
/*     */ import org.renjin.primitives.Vectors;
/*     */ import org.renjin.primitives.sequence.RepDoubleVector;
/*     */ import org.renjin.primitives.sequence.RepIntVector;
/*     */ import org.renjin.primitives.sequence.RepLogicalVector;
/*     */ import org.renjin.primitives.sequence.RepStringVector;
/*     */ import org.renjin.sexp.AtomicVector;
/*     */ import org.renjin.sexp.AttributeMap;
/*     */ import org.renjin.sexp.ListVector;
/*     */ import org.renjin.sexp.Null;
/*     */ import org.renjin.sexp.PairList;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.Symbol;
/*     */ import org.renjin.sexp.Symbols;
/*     */ import org.renjin.sexp.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class CompleteSelection
/*     */   implements SelectionStrategy
/*     */ {
/*     */   public SEXP getVectorSubset(Context context, Vector source, boolean drop) {
/*  39 */     return (SEXP)source;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public SEXP getSingleListElement(ListVector source, boolean exact) {
/*  45 */     throw new EvalException("[[ operator requires a subscript", new Object[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public AtomicVector getSingleAtomicVectorElement(AtomicVector source, boolean exact) {
/*  51 */     throw new EvalException("[[ operator requires a subscript", new Object[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector replaceAtomicVectorElements(Context context, AtomicVector source, Vector replacements) {
/*     */     AtomicVector atomicVector;
/*  59 */     Vector result = recycle(replacements, source.length());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  67 */     if (source.getVectorType().isWiderThan(replacements.getVectorType())) {
/*  68 */       atomicVector = Vectors.toType((AtomicVector)result, source.getVectorType());
/*     */     }
/*     */ 
/*     */     
/*  72 */     return (Vector)atomicVector.setAttributes(source.getAttributes());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Vector recycle(Vector x, int length) {
/*  78 */     if (x.length() == length) {
/*  79 */       return x;
/*     */     }
/*     */ 
/*     */     
/*  83 */     if (x.isDeferred() || length > 100) {
/*     */       
/*  85 */       if (x instanceof org.renjin.sexp.DoubleVector)
/*  86 */         return (Vector)new RepDoubleVector(x, length, 1, AttributeMap.EMPTY); 
/*  87 */       if (x instanceof org.renjin.sexp.IntVector)
/*  88 */         return (Vector)new RepIntVector(x, length, 1, AttributeMap.EMPTY); 
/*  89 */       if (x instanceof org.renjin.sexp.StringVector)
/*  90 */         return (Vector)new RepStringVector(x, length, 1, AttributeMap.EMPTY); 
/*  91 */       if (x instanceof org.renjin.sexp.LogicalVector) {
/*  92 */         return (Vector)new RepLogicalVector(x, length, 1, AttributeMap.EMPTY);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  97 */     Vector.Builder builder = x.newBuilderWithInitialCapacity(length);
/*  98 */     for (int i = 0; i < length; i++) {
/*  99 */       builder.setFrom(i, (SEXP)x, i % x.length());
/*     */     }
/*     */     
/* 102 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ListVector replaceListElements(Context context, ListVector source, Vector replacement) {
/* 108 */     if (replacement == Null.INSTANCE) {
/* 109 */       return clearList(source);
/*     */     }
/*     */     
/* 112 */     if (replacement.length() == 0) {
/* 113 */       throw new EvalException("replacement has length zero", new Object[0]);
/*     */     }
/*     */     
/* 116 */     ListVector.Builder result = new ListVector.Builder();
/* 117 */     result.copyAttributesFrom((SEXP)source);
/*     */     
/* 119 */     int replacementIndex = 0;
/* 120 */     for (int i = 0; i < source.length(); i++) {
/* 121 */       result.setFrom(i, (SEXP)replacement, replacementIndex++);
/* 122 */       if (replacementIndex >= replacement.length()) {
/* 123 */         replacementIndex = 0;
/*     */       }
/*     */     } 
/*     */     
/* 127 */     return result.build();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private ListVector clearList(ListVector list) {
/* 133 */     AttributeMap.Builder builder = new AttributeMap.Builder();
/* 134 */     for (Symbol attribute : list.getAttributes().names()) {
/* 135 */       if (attribute != Symbols.NAMES && attribute != Symbols.DIM && attribute != Symbols.DIMNAMES)
/*     */       {
/*     */ 
/*     */         
/* 139 */         builder.set(attribute, list.getAttribute(attribute));
/*     */       }
/*     */     } 
/*     */     
/* 143 */     return new ListVector(new SEXP[0], builder.validateAndBuildForVectorOfLength(0));
/*     */   }
/*     */   
/*     */   private void checkReplacementLength(Vector source, SEXP replacements) {
/* 147 */     if (source.length() % replacements.length() != 0) {
/* 148 */       throw new EvalException("number of items to replace is not a multiple of replacement length", new Object[0]);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public Vector replaceSingleElement(Context context, AtomicVector source, Vector replacement) {
/* 154 */     throw new EvalException("[[ ]] with missing subscript", new Object[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ListVector replaceSingleListElement(ListVector list, SEXP replacement) {
/* 160 */     throw new EvalException("[[ ]] with missing subscript", new Object[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   public SEXP replaceSinglePairListElement(PairList.Node list, SEXP replacement) {
/* 165 */     throw new EvalException("[[ ]] with missing subscript", new Object[0]);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/subset/CompleteSelection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */