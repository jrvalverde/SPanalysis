/*    */ package org.renjin.primitives.special;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NextException
/*    */   extends ControlFlowException
/*    */ {
/* 24 */   public static final NextException INSTANCE = new NextException();
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/special/NextException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */