/*     */ package org.renjin.primitives.subset;
/*     */ 
/*     */ import org.renjin.eval.EvalException;
/*     */ import org.renjin.primitives.Indexes;
/*     */ import org.renjin.sexp.AtomicVector;
/*     */ import org.renjin.sexp.IntVector;
/*     */ import org.renjin.sexp.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class CoordinateMatrixIterator
/*     */   implements IndexIterator
/*     */ {
/*     */   private AtomicVector coordinateMatrix;
/*     */   private int coordinateRows;
/*     */   private int coordinateColumns;
/*     */   private int[] sourceDim;
/*  67 */   private int nextRow = 0;
/*     */ 
/*     */   
/*     */   private int[] coordRow;
/*     */ 
/*     */ 
/*     */   
/*     */   public CoordinateMatrixIterator(Vector source, AtomicVector coordinateMatrix) {
/*  75 */     this.coordinateMatrix = coordinateMatrix;
/*  76 */     this.sourceDim = source.getAttributes().getDimArray();
/*     */     
/*  78 */     int[] coordinateMatrixDims = coordinateMatrix.getAttributes().getDimArray();
/*  79 */     this.coordinateRows = coordinateMatrixDims[0];
/*  80 */     this.coordinateColumns = coordinateMatrixDims[1];
/*     */     
/*  82 */     this.coordRow = new int[this.sourceDim.length];
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  87 */     assert this.coordinateColumns == this.sourceDim.length : "coordinate matrix shape does not match source array dimensions";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int next() {
/*     */     label19: while (true) {
/*  98 */       if (this.nextRow >= this.coordinateRows) {
/*  99 */         return -1;
/*     */       }
/*     */       
/* 102 */       int coordRow = this.nextRow++;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 107 */       for (int i = 0; i != this.coordRow.length; i++) {
/* 108 */         int coord = this.coordinateMatrix.getElementAsInt(
/* 109 */             Indexes.matrixIndexToVectorIndex(coordRow, i, this.coordinateRows, this.coordinateColumns));
/*     */ 
/*     */         
/* 112 */         if (coord == 0) {
/*     */           continue label19;
/*     */         }
/* 115 */         if (IntVector.isNA(coord)) {
/* 116 */           return Integer.MIN_VALUE;
/*     */         }
/* 118 */         if (coord < 0) {
/* 119 */           throw new EvalException("negative values are not allowed in a matrix subscript", new Object[0]);
/*     */         }
/*     */ 
/*     */         
/* 123 */         this.coordRow[i] = coord - 1;
/*     */       } 
/*     */       
/*     */       break;
/*     */     } 
/* 128 */     return Indexes.arrayIndexToVectorIndex(this.coordRow, this.sourceDim);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void restart() {
/* 134 */     this.nextRow = 0;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/subset/CoordinateMatrixIterator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */