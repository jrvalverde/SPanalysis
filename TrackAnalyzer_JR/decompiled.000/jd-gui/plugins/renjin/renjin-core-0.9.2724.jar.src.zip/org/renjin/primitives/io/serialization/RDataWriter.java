/*     */ package org.renjin.primitives.io.serialization;
/*     */ 
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.math.complex.Complex;
/*     */ import org.renjin.eval.Context;
/*     */ import org.renjin.repackaged.guava.base.Charsets;
/*     */ import org.renjin.repackaged.guava.collect.Maps;
/*     */ import org.renjin.sexp.CHARSEXP;
/*     */ import org.renjin.sexp.Closure;
/*     */ import org.renjin.sexp.ComplexVector;
/*     */ import org.renjin.sexp.DoubleVector;
/*     */ import org.renjin.sexp.Environment;
/*     */ import org.renjin.sexp.ExternalPtr;
/*     */ import org.renjin.sexp.FunctionCall;
/*     */ import org.renjin.sexp.IntVector;
/*     */ import org.renjin.sexp.ListVector;
/*     */ import org.renjin.sexp.LogicalVector;
/*     */ import org.renjin.sexp.Null;
/*     */ import org.renjin.sexp.PairList;
/*     */ import org.renjin.sexp.PrimitiveFunction;
/*     */ import org.renjin.sexp.Promise;
/*     */ import org.renjin.sexp.RawVector;
/*     */ import org.renjin.sexp.S4Object;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.StringVector;
/*     */ import org.renjin.sexp.Symbol;
/*     */ import org.renjin.sexp.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RDataWriter
/*     */   implements AutoCloseable
/*     */ {
/*     */   private WriteContext context;
/*     */   private PersistenceHook hook;
/*     */   private DataOutputStream conn;
/*     */   private StreamWriter out;
/*     */   private Serialization.SerializationType serializationType;
/*  60 */   private Map<SEXP, Integer> references = Maps.newIdentityHashMap();
/*     */ 
/*     */   
/*     */   public RDataWriter(WriteContext context, PersistenceHook hook, OutputStream out, Serialization.SerializationType type) {
/*  64 */     this.context = context;
/*  65 */     this.hook = hook;
/*  66 */     this.conn = new DataOutputStream(out);
/*  67 */     this.serializationType = type;
/*  68 */     switch (this.serializationType) { case ASCII:
/*  69 */         this.out = new AsciiWriter(this.conn); return; }
/*  70 */      this.out = new XdrWriter(this.conn);
/*     */   }
/*     */ 
/*     */   
/*     */   public RDataWriter(Context context, PersistenceHook hook, OutputStream out) throws IOException {
/*  75 */     this(new SessionWriteContext(context), hook, out, Serialization.SerializationType.XDR);
/*     */   }
/*     */   
/*     */   public RDataWriter(Context context, OutputStream out, Serialization.SerializationType st) throws IOException {
/*  79 */     this(new SessionWriteContext(context), null, out, st);
/*     */   }
/*     */   
/*     */   public RDataWriter(Context context, OutputStream out) throws IOException {
/*  83 */     this(context, (PersistenceHook)null, out);
/*     */   }
/*     */   
/*     */   public RDataWriter(WriteContext writeContext, OutputStream os) {
/*  87 */     this(writeContext, null, os, Serialization.SerializationType.XDR);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void writeFile(SEXP sexp) throws IOException {
/*  98 */     save(sexp);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void save(SEXP sexp) throws IOException {
/* 107 */     if (this.serializationType == Serialization.SerializationType.ASCII) {
/* 108 */       this.conn.writeBytes("RDA2\n");
/*     */     } else {
/* 110 */       this.conn.writeBytes("RDX2\n");
/*     */     } 
/*     */     
/* 113 */     serialize(sexp);
/*     */   }
/*     */   
/*     */   public void serialize(SEXP exp) throws IOException {
/* 117 */     if (this.serializationType == Serialization.SerializationType.ASCII) {
/* 118 */       this.conn.writeByte(65);
/*     */     } else {
/* 120 */       this.conn.writeByte(88);
/*     */     } 
/*     */     
/* 123 */     this.conn.writeByte(10);
/* 124 */     writeVersion();
/* 125 */     writeExp(exp);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 131 */     this.out.close();
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeVersion() throws IOException {
/* 136 */     this.out.writeInt(2);
/* 137 */     this.out.writeInt(Version.CURRENT.asPacked());
/* 138 */     this.out.writeInt((new Version(2, 3, 0)).asPacked());
/*     */   }
/*     */   
/*     */   private void writeExp(SEXP exp) throws IOException {
/* 142 */     if (tryWriteRef(exp)) {
/*     */       return;
/*     */     }
/*     */     
/* 146 */     if (tryWritePersistent(exp)) {
/*     */       return;
/*     */     }
/*     */     
/* 150 */     if (exp instanceof Null) {
/* 151 */       writeNull();
/* 152 */     } else if (exp instanceof LogicalVector) {
/* 153 */       writeLogical((LogicalVector)exp);
/* 154 */     } else if (exp instanceof IntVector) {
/* 155 */       writeIntVector((IntVector)exp);
/* 156 */     } else if (exp instanceof DoubleVector) {
/* 157 */       writeDoubleVector((DoubleVector)exp);
/* 158 */     } else if (exp instanceof StringVector) {
/* 159 */       writeStringVector((StringVector)exp);
/* 160 */     } else if (exp instanceof ComplexVector) {
/* 161 */       writeComplexVector((ComplexVector)exp);
/* 162 */     } else if (exp instanceof Promise) {
/* 163 */       writePromise((Promise)exp);
/* 164 */     } else if (exp instanceof ListVector) {
/* 165 */       writeList((ListVector)exp);
/* 166 */     } else if (exp instanceof FunctionCall) {
/* 167 */       writeFunctionCall((FunctionCall)exp);
/* 168 */     } else if (exp instanceof PairList.Node) {
/* 169 */       writePairList((PairList.Node)exp);
/* 170 */     } else if (exp instanceof Symbol) {
/* 171 */       writeSymbol((Symbol)exp);
/* 172 */     } else if (exp instanceof Closure) {
/* 173 */       writeClosure((Closure)exp);
/* 174 */     } else if (exp instanceof RawVector) {
/* 175 */       writeRawVector((RawVector)exp);
/* 176 */     } else if (exp instanceof Environment) {
/* 177 */       writeEnvironment((Environment)exp);
/* 178 */     } else if (exp instanceof PrimitiveFunction) {
/* 179 */       writePrimitive((PrimitiveFunction)exp);
/* 180 */     } else if (exp instanceof S4Object) {
/* 181 */       writeS4((S4Object)exp);
/* 182 */     } else if (exp instanceof ExternalPtr) {
/* 183 */       writeExternalPtr((ExternalPtr)exp);
/* 184 */     } else if (exp instanceof CHARSEXP) {
/* 185 */       writeCharExp(((CHARSEXP)exp).getValue());
/*     */     } else {
/* 187 */       throw new UnsupportedOperationException("serialization of " + exp.getClass().getName() + " not implemented: [" + exp
/* 188 */           .toString() + "]");
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean tryWritePersistent(SEXP exp) throws IOException {
/* 194 */     if (this.hook == null) {
/* 195 */       return false;
/*     */     }
/* 197 */     if (exp == Null.INSTANCE || isSpecialEnvironment(exp)) {
/* 198 */       return false;
/*     */     }
/* 200 */     Vector name = this.hook.apply(exp);
/* 201 */     if (name == Null.INSTANCE) {
/* 202 */       return false;
/*     */     }
/*     */     
/* 205 */     this.out.writeInt(247);
/* 206 */     writePersistentNameVector((StringVector)name);
/* 207 */     addRef(exp);
/* 208 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   private void writePersistentNameVector(StringVector name) throws IOException {
/* 213 */     this.out.writeInt(0);
/* 214 */     this.out.writeInt(name.length());
/* 215 */     for (int i = 0; i != name.length(); i++) {
/* 216 */       writeCharExp(name.getElementAsString(i));
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean isSpecialEnvironment(SEXP exp) {
/* 221 */     if (!(exp instanceof Environment)) {
/* 222 */       return false;
/*     */     }
/* 224 */     if (exp == Environment.EMPTY) {
/* 225 */       return true;
/*     */     }
/* 227 */     if (this.context.isBaseEnvironment((Environment)exp)) {
/* 228 */       return true;
/*     */     }
/* 230 */     if (this.context.isNamespaceEnvironment((Environment)exp)) {
/* 231 */       return true;
/*     */     }
/* 233 */     if (isPackageEnvironment(exp)) {
/* 234 */       return true;
/*     */     }
/* 236 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isPackageEnvironment(SEXP exp) {
/* 241 */     return false;
/*     */   }
/*     */   
/*     */   private void writeNull() throws IOException {
/* 245 */     this.out.writeInt(254);
/*     */   }
/*     */   
/*     */   private void writeLogical(LogicalVector vector) throws IOException {
/* 249 */     writeFlags(10, (SEXP)vector);
/* 250 */     this.out.writeInt(vector.length());
/* 251 */     for (int i = 0; i != vector.length(); i++) {
/* 252 */       this.out.writeInt(vector.getElementAsRawLogical(i));
/*     */     }
/* 254 */     writeAttributes((SEXP)vector);
/*     */   }
/*     */   
/*     */   private void writeIntVector(IntVector vector) throws IOException {
/* 258 */     writeFlags(13, (SEXP)vector);
/* 259 */     this.out.writeInt(vector.length());
/* 260 */     if (this.serializationType == Serialization.SerializationType.ASCII) {
/* 261 */       for (int i = 0; i != vector.length(); i++) {
/* 262 */         if (vector.isElementNA(i)) {
/* 263 */           this.conn.writeBytes("NA\n");
/*     */         } else {
/* 265 */           this.out.writeInt(vector.getElementAsInt(i));
/*     */         } 
/*     */       } 
/*     */     } else {
/* 269 */       for (int i = 0; i != vector.length(); i++) {
/* 270 */         this.out.writeInt(vector.getElementAsInt(i));
/*     */       }
/*     */     } 
/*     */     
/* 274 */     writeAttributes((SEXP)vector);
/*     */   }
/*     */   
/*     */   private void writeDoubleVector(DoubleVector vector) throws IOException {
/* 278 */     writeFlags(14, (SEXP)vector);
/* 279 */     this.out.writeInt(vector.length());
/* 280 */     if (this.serializationType == Serialization.SerializationType.ASCII) {
/* 281 */       for (int i = 0; i != vector.length(); i++) {
/* 282 */         double d = vector.getElementAsDouble(i);
/* 283 */         if (!DoubleVector.isFinite(d)) {
/* 284 */           if (DoubleVector.isNaN(d)) {
/* 285 */             this.conn.writeBytes("NA\n");
/* 286 */           } else if (d < 0.0D) {
/* 287 */             this.conn.writeBytes("-Inf\n");
/*     */           } else {
/* 289 */             this.conn.writeBytes("Inf\n");
/*     */           } 
/*     */         } else {
/* 292 */           this.out.writeDouble(vector.getElementAsDouble(i));
/*     */         } 
/*     */       } 
/*     */     } else {
/* 296 */       for (int i = 0; i != vector.length(); i++) {
/* 297 */         if (vector.isElementNA(i)) {
/* 298 */           this.out.writeLong(9218868437227407266L);
/*     */         } else {
/* 300 */           this.out.writeDouble(vector.getElementAsDouble(i));
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 305 */     writeAttributes((SEXP)vector);
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeS4(S4Object exp) throws IOException {
/* 310 */     writeFlags(25, (SEXP)exp);
/* 311 */     writeAttributes((SEXP)exp);
/*     */   }
/*     */   
/*     */   private void writeExternalPtr(ExternalPtr exp) throws IOException {
/* 315 */     addRef((SEXP)exp);
/* 316 */     writeFlags(22, (SEXP)exp);
/* 317 */     writeExp((SEXP)Null.INSTANCE);
/* 318 */     writeExp((SEXP)Null.INSTANCE);
/* 319 */     writeAttributes((SEXP)exp);
/*     */   }
/*     */   
/*     */   private void writeComplexVector(ComplexVector vector) throws IOException {
/* 323 */     writeFlags(15, (SEXP)vector);
/* 324 */     this.out.writeInt(vector.length());
/* 325 */     for (int i = 0; i != vector.length(); i++) {
/* 326 */       Complex value = vector.getElementAsComplex(i);
/* 327 */       this.out.writeDouble(value.getReal());
/* 328 */       this.out.writeDouble(value.getImaginary());
/*     */     } 
/* 330 */     writeAttributes((SEXP)vector);
/*     */   }
/*     */   
/*     */   private void writeRawVector(RawVector vector) throws IOException {
/* 334 */     writeFlags(24, (SEXP)vector);
/* 335 */     this.out.writeInt(vector.length());
/* 336 */     if (this.serializationType == Serialization.SerializationType.ASCII) {
/* 337 */       byte[] bytes = vector.toByteArray();
/* 338 */       for (int i = 0; i != vector.length(); i++) {
/* 339 */         this.conn.writeBytes(String.format("%02x\n", new Object[] { Byte.valueOf(bytes[i]) }));
/*     */       } 
/*     */     } else {
/* 342 */       this.out.writeString(vector.toByteArray());
/*     */     } 
/* 344 */     writeAttributes((SEXP)vector);
/*     */   }
/*     */   
/*     */   private void writeStringVector(StringVector vector) throws IOException {
/* 348 */     writeFlags(16, (SEXP)vector);
/* 349 */     this.out.writeInt(vector.length());
/* 350 */     for (int i = 0; i != vector.length(); i++) {
/* 351 */       writeCharExp(vector.getElementAsString(i));
/*     */     }
/* 353 */     writeAttributes((SEXP)vector);
/*     */   }
/*     */   
/*     */   private void writeList(ListVector vector) throws IOException {
/* 357 */     writeFlags(19, (SEXP)vector);
/* 358 */     this.out.writeInt(vector.length());
/* 359 */     for (SEXP element : vector) {
/* 360 */       writeExp(element);
/*     */     }
/* 362 */     writeAttributes((SEXP)vector);
/*     */   }
/*     */   
/*     */   private void writePromise(Promise exp) throws IOException {
/* 366 */     this.out.writeInt(Flags.computePromiseFlags(exp));
/* 367 */     writeAttributes((SEXP)exp);
/* 368 */     if (exp.getEnvironment() != null) {
/* 369 */       writeExp((SEXP)exp.getEnvironment());
/*     */     }
/* 371 */     writeExp((exp.getValue() == null) ? (SEXP)Null.INSTANCE : exp.getValue());
/* 372 */     writeExp(exp.getExpression());
/*     */   }
/*     */ 
/*     */   
/*     */   private void writePairList(PairList.Node node) throws IOException {
/*     */     while (true) {
/* 378 */       writeFlags(2, (SEXP)node);
/* 379 */       writeAttributes((SEXP)node);
/* 380 */       writeTag(node);
/* 381 */       writeExp(node.getValue());
/*     */       
/* 383 */       if (node.getNext() == Null.INSTANCE) {
/* 384 */         writeNull();
/*     */         break;
/*     */       } 
/* 387 */       node = node.getNextNode();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void writeFunctionCall(FunctionCall exp) throws IOException {
/* 392 */     writeFlags(6, (SEXP)exp);
/* 393 */     writeAttributes((SEXP)exp);
/* 394 */     writeTag((PairList.Node)exp);
/* 395 */     writeExp(exp.getValue());
/* 396 */     if (exp.hasNextNode()) {
/* 397 */       writeExp((SEXP)exp.getNextNode());
/*     */     } else {
/* 399 */       writeNull();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void writeClosure(Closure exp) throws IOException {
/* 404 */     writeFlags(3, (SEXP)exp);
/* 405 */     writeAttributes((SEXP)exp);
/* 406 */     writeExp((SEXP)exp.getEnclosingEnvironment());
/* 407 */     writeExp((SEXP)exp.getFormals());
/* 408 */     writeExp(exp.getBody());
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeEnvironment(Environment env) throws IOException {
/* 413 */     if (this.context.isGlobalEnvironment(env)) {
/* 414 */       this.out.writeInt(253);
/* 415 */     } else if (this.context.isBaseEnvironment(env)) {
/* 416 */       this.out.writeInt(241);
/* 417 */     } else if (env == Environment.EMPTY) {
/* 418 */       this.out.writeInt(242);
/*     */     }
/* 420 */     else if (this.context.isNamespaceEnvironment(env)) {
/* 421 */       writeNamespace(env);
/*     */     } else {
/* 423 */       addRef((SEXP)env);
/* 424 */       writeFlags(4, (SEXP)env);
/* 425 */       this.out.writeInt(env.isLocked() ? 1 : 0);
/* 426 */       writeExp((SEXP)env.getParent());
/* 427 */       writeFrame(env);
/* 428 */       writeExp((SEXP)Null.INSTANCE);
/*     */ 
/*     */ 
/*     */       
/* 432 */       writeExp((SEXP)env.getAttributes().asPairList());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeFrame(Environment exp) throws IOException {
/* 438 */     for (Symbol name : exp.getSymbolNames()) {
/* 439 */       if (exp.isActiveBinding(name)) {
/* 440 */         this.out.writeInt(Flags.computeBindingFlag(true));
/* 441 */         writeExp((SEXP)name);
/* 442 */         writeExp((SEXP)exp.getActiveBinding(name)); continue;
/*     */       } 
/* 444 */       this.out.writeInt(Flags.computeBindingFlag(false));
/* 445 */       writeExp((SEXP)name);
/* 446 */       writeExp(exp.getVariableUnsafe(name));
/*     */     } 
/*     */     
/* 449 */     writeNull();
/*     */   }
/*     */   
/*     */   private void writeNamespace(Environment ns) throws IOException {
/* 453 */     if (this.context.isBaseNamespaceEnvironment(ns)) {
/* 454 */       this.out.writeInt(250);
/*     */     } else {
/* 456 */       addRef((SEXP)ns);
/* 457 */       writeFlags(249, (SEXP)ns);
/* 458 */       writePersistentNameVector(getNamespaceName(ns));
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean tryWriteRef(SEXP exp) throws IOException {
/* 463 */     if (this.references.containsKey(exp)) {
/* 464 */       writeRefIndex(((Integer)this.references.get(exp)).intValue());
/* 465 */       return true;
/*     */     } 
/* 467 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeRefIndex(int index) throws IOException {
/* 472 */     if (index > 8388607) {
/* 473 */       this.out.writeInt(255);
/* 474 */       this.out.writeInt(index);
/*     */     } else {
/* 476 */       this.out.writeInt(0xFF | index << 8);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void addRef(SEXP exp) {
/* 481 */     this.references.put(exp, Integer.valueOf(this.references.size() + 1));
/*     */   }
/*     */   
/*     */   private StringVector getNamespaceName(Environment ns) {
/* 485 */     return StringVector.valueOf(this.context.getNamespaceName(ns));
/*     */   }
/*     */   
/*     */   private void writeSymbol(Symbol symbol) throws IOException {
/* 489 */     if (symbol == Symbol.UNBOUND_VALUE) {
/* 490 */       this.out.writeInt(252);
/* 491 */     } else if (symbol == Symbol.MISSING_ARG) {
/* 492 */       this.out.writeInt(251);
/*     */     } else {
/* 494 */       addRef((SEXP)symbol);
/* 495 */       writeFlags(1, (SEXP)symbol);
/* 496 */       writeCharExp(symbol.getPrintName());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeCharExp(String string) throws IOException {
/* 502 */     if (StringVector.isNA(string)) {
/* 503 */       this.out.writeInt(Flags.computeCharSexpFlags(64));
/* 504 */       this.out.writeInt(-1);
/*     */     }
/*     */     else {
/*     */       
/* 508 */       byte[] bytes = string.getBytes(Charsets.UTF_8);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 515 */       int encoding = (string.length() == bytes.length) ? 64 : 8;
/*     */       
/* 517 */       this.out.writeInt(Flags.computeCharSexpFlags(encoding));
/* 518 */       this.out.writeInt(bytes.length);
/* 519 */       this.out.writeString(bytes);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeAttributes(SEXP exp) throws IOException {
/* 525 */     PairList.Builder pairList = exp.getAttributes().asPairListBuilder();
/*     */     
/* 527 */     if (exp.getAttributes().isS4()) {
/* 528 */       pairList.add(Flags.OLD_S4_BIT, (SEXP)LogicalVector.TRUE);
/*     */     }
/*     */ 
/*     */     
/* 532 */     PairList attributes = pairList.build();
/*     */     
/* 534 */     if (attributes != Null.INSTANCE) {
/* 535 */       if (!(attributes instanceof PairList.Node)) {
/* 536 */         throw new AssertionError(attributes.getClass());
/*     */       }
/* 538 */       writeExp((SEXP)attributes);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void writeTag(PairList.Node node) throws IOException {
/* 543 */     if (node.hasTag()) {
/* 544 */       writeExp((SEXP)node.getTag());
/*     */     }
/*     */   }
/*     */   
/*     */   private void writePrimitive(PrimitiveFunction exp) throws IOException {
/* 549 */     if (exp instanceof org.renjin.sexp.BuiltinFunction) {
/* 550 */       this.out.writeInt(8);
/*     */     } else {
/* 552 */       this.out.writeInt(7);
/*     */     } 
/* 554 */     this.out.writeInt(exp.getName().length());
/* 555 */     this.conn.writeBytes(exp.getName());
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeFlags(int type, SEXP exp) throws IOException {
/* 560 */     this.out.writeInt(Flags.computeFlags(exp, type));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class AsciiWriter
/*     */     implements StreamWriter
/*     */   {
/*     */     private DataOutputStream out;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private AsciiWriter(DataOutputStream out) {
/* 577 */       this.out = out;
/*     */     }
/*     */     
/*     */     public void writeInt(int v) throws IOException {
/* 581 */       this.out.writeBytes(v + "\n");
/*     */     }
/*     */     
/*     */     public void writeDouble(double d) throws IOException {
/* 585 */       this.out.writeBytes(d + "\n");
/*     */     }
/*     */     
/*     */     public void writeLong(long l) throws IOException {
/* 589 */       this.out.writeBytes(l + "\n");
/*     */     }
/*     */     
/*     */     public void writeString(byte[] bytes) throws IOException {
/* 593 */       for (int i = 0; i < bytes.length; i++) {
/*     */         String s;
/* 595 */         switch (bytes[i]) { case 10:
/* 596 */             s = "\\n"; break;
/* 597 */           case 9: s = "\\t"; break;
/* 598 */           case 11: s = "\\v"; break;
/* 599 */           case 8: s = "\\b"; break;
/* 600 */           case 13: s = "\\r"; break;
/* 601 */           case 12: s = "\\f"; break;
/* 602 */           case 7: s = "\\a"; break;
/* 603 */           case 92: s = "\\\\"; break;
/* 604 */           case 127: s = "\\?"; break;
/* 605 */           case 39: s = "\\'"; break;
/* 606 */           case 34: s = "\\\"";
/*     */             break;
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           default:
/* 613 */             if (bytes[i] <= 32 || bytes[i] > 126) {
/* 614 */               s = String.format("\\%03o", new Object[] { Byte.valueOf(bytes[i]) }); break;
/*     */             } 
/* 616 */             s = new String(new byte[] { bytes[i] });
/*     */             break; }
/*     */         
/* 619 */         this.out.writeBytes(s);
/*     */       } 
/* 621 */       this.out.writeBytes("\n");
/*     */     }
/*     */ 
/*     */     
/*     */     public void close() throws IOException {
/* 626 */       this.out.close();
/*     */     }
/*     */   }
/*     */   
/*     */   private static class XdrWriter implements StreamWriter {
/*     */     private DataOutputStream out;
/*     */     
/*     */     private XdrWriter(DataOutputStream out) {
/* 634 */       this.out = out;
/*     */     }
/*     */     
/*     */     public void writeInt(int v) throws IOException {
/* 638 */       this.out.writeInt(v);
/*     */     }
/*     */     
/*     */     public void writeDouble(double d) throws IOException {
/* 642 */       this.out.writeDouble(d);
/*     */     }
/*     */     
/*     */     public void writeLong(long l) throws IOException {
/* 646 */       this.out.writeLong(l);
/*     */     }
/*     */     
/*     */     public void writeString(byte[] bytes) throws IOException {
/* 650 */       this.out.write(bytes);
/*     */     }
/*     */ 
/*     */     
/*     */     public void close() throws IOException {
/* 655 */       this.out.close();
/*     */     }
/*     */   }
/*     */   
/*     */   private static interface StreamWriter extends AutoCloseable {
/*     */     void writeInt(int param1Int) throws IOException;
/*     */     
/*     */     void writeString(byte[] param1ArrayOfbyte) throws IOException;
/*     */     
/*     */     void writeLong(long param1Long) throws IOException;
/*     */     
/*     */     void writeDouble(double param1Double) throws IOException;
/*     */     
/*     */     void close() throws IOException;
/*     */   }
/*     */   
/*     */   public static interface PersistenceHook {
/*     */     Vector apply(SEXP param1SEXP);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/io/serialization/RDataWriter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */