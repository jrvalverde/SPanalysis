/*    */ package org.renjin.primitives.combine;
/*    */ 
/*    */ import org.renjin.sexp.AtomicVector;
/*    */ import org.renjin.sexp.IntArrayVector;
/*    */ import org.renjin.sexp.ListVector;
/*    */ import org.renjin.sexp.SEXP;
/*    */ import org.renjin.sexp.Symbols;
/*    */ import org.renjin.sexp.Vector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class Matrix2dBuilder
/*    */ {
/*    */   private final Vector.Builder builder;
/*    */   private final int rows;
/*    */   private final int cols;
/* 30 */   private int count = 0;
/*    */   
/*    */   public Matrix2dBuilder(Vector.Builder builder, int rows, int cols) {
/* 33 */     this.builder = builder;
/* 34 */     this.rows = rows;
/* 35 */     this.cols = cols;
/*    */   }
/*    */   
/*    */   public void addFrom(BindArgument argument, int rowIndex, int colIndex) {
/* 39 */     int recycledColIndex = colIndex % argument.getCols();
/* 40 */     int recycledRowIndex = rowIndex % argument.getRows();
/* 41 */     this.builder.setFrom(this.count, (SEXP)argument.getVector(), recycledColIndex * argument.getRows() + recycledRowIndex);
/* 42 */     this.count++;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setDimNames(AtomicVector rowNames, AtomicVector colNames) {
/* 47 */     this.builder.setAttribute(Symbols.DIMNAMES, (SEXP)new ListVector(new SEXP[] { (SEXP)rowNames, (SEXP)colNames }));
/*    */   }
/*    */   
/*    */   public Vector build() {
/* 51 */     return this.builder.setAttribute(Symbols.DIM, (SEXP)new IntArrayVector(new int[] { this.rows, this.cols })).build();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/combine/Matrix2dBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */