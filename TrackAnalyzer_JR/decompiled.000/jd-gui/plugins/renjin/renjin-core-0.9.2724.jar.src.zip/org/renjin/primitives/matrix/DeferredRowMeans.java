/*     */ package org.renjin.primitives.matrix;
/*     */ 
/*     */ import org.renjin.primitives.vector.MemoizedComputation;
/*     */ import org.renjin.sexp.AtomicVector;
/*     */ import org.renjin.sexp.AttributeMap;
/*     */ import org.renjin.sexp.DoubleArrayVector;
/*     */ import org.renjin.sexp.DoubleVector;
/*     */ import org.renjin.sexp.IntArrayVector;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DeferredRowMeans
/*     */   extends DoubleVector
/*     */   implements MemoizedComputation
/*     */ {
/*     */   private final AtomicVector vector;
/*     */   private int numRows;
/*     */   private int numCols;
/*     */   private double[] means;
/*     */   
/*     */   public DeferredRowMeans(AtomicVector vector, int numRows, AttributeMap attributes) {
/*  32 */     super(attributes);
/*  33 */     this.vector = vector;
/*  34 */     this.numRows = numRows;
/*  35 */     this.numCols = vector.length() / numRows;
/*     */   }
/*     */ 
/*     */   
/*     */   public Vector[] getOperands() {
/*  40 */     return new Vector[] { (Vector)this.vector, (Vector)new IntArrayVector(new int[] { this.numRows }) };
/*     */   }
/*     */ 
/*     */   
/*     */   public String getComputationName() {
/*  45 */     return "rowMeans";
/*     */   }
/*     */ 
/*     */   
/*     */   protected SEXP cloneWithNewAttributes(AttributeMap attributes) {
/*  50 */     return (SEXP)new DeferredRowMeans(this.vector, this.numRows, attributes);
/*     */   }
/*     */ 
/*     */   
/*     */   public double getElementAsDouble(int index) {
/*  55 */     if (this.means == null) {
/*  56 */       computeMeans();
/*     */     }
/*  58 */     return this.means[index];
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isConstantAccessTime() {
/*  63 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int length() {
/*  68 */     return this.numRows;
/*     */   }
/*     */   
/*     */   private void computeMeans() {
/*  72 */     System.err.println("EEK! rowMeans.calculate() called directly");
/*     */     
/*  74 */     double[] means = new double[this.numRows];
/*  75 */     int row = 0; int i;
/*  76 */     for (i = 0; i != this.vector.length(); i++) {
/*  77 */       means[row] = means[row] + this.vector.getElementAsDouble(i);
/*  78 */       row++;
/*  79 */       if (row == this.numRows) {
/*  80 */         row = 0;
/*     */       }
/*     */     } 
/*  83 */     for (i = 0; i != this.numRows; i++) {
/*  84 */       means[i] = means[i] / this.numCols;
/*     */     }
/*  86 */     this.means = means;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isCalculated() {
/*  91 */     return (this.means != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDeferred() {
/*  96 */     return !isCalculated();
/*     */   }
/*     */ 
/*     */   
/*     */   public Vector forceResult() {
/* 101 */     if (this.means == null) {
/* 102 */       computeMeans();
/*     */     }
/* 104 */     return (Vector)DoubleArrayVector.unsafe(this.means, getAttributes());
/*     */   }
/*     */ 
/*     */   
/*     */   public void setResult(Vector result) {
/* 109 */     this.means = ((DoubleArrayVector)result).toDoubleArrayUnsafe();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/matrix/DeferredRowMeans.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */