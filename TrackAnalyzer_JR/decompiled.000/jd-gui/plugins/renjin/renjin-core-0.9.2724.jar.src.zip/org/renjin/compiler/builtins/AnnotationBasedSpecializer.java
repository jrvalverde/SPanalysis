/*     */ package org.renjin.compiler.builtins;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import org.renjin.compiler.ir.TypeSet;
/*     */ import org.renjin.compiler.ir.ValueBounds;
/*     */ import org.renjin.compiler.ir.tac.RuntimeState;
/*     */ import org.renjin.invoke.codegen.OverloadComparator;
/*     */ import org.renjin.invoke.model.JvmMethod;
/*     */ import org.renjin.primitives.Primitives;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnnotationBasedSpecializer
/*     */   implements BuiltinSpecializer
/*     */ {
/*     */   private final Primitives.Entry primitive;
/*     */   private final String genericGroup;
/*     */   private final List<JvmMethod> methods;
/*     */   
/*     */   public AnnotationBasedSpecializer(Primitives.Entry primitive) {
/*  41 */     this.primitive = primitive;
/*  42 */     this.methods = JvmMethod.findOverloads(this.primitive.functionClass, this.primitive.name, this.primitive.methodName);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  47 */     this.genericGroup = findGenericGroup(this.methods);
/*     */     
/*  49 */     Collections.sort(this.methods, (Comparator<? super JvmMethod>)new OverloadComparator());
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/*  54 */     return this.primitive.name;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getGroup() {
/*  59 */     return this.genericGroup;
/*     */   }
/*     */   
/*     */   private static String findGenericGroup(List<JvmMethod> methods) {
/*  63 */     for (JvmMethod method : methods) {
/*  64 */       if (method.isGroupGeneric()) {
/*  65 */         return method.getGenericGroup();
/*     */       }
/*     */     } 
/*  68 */     return null;
/*     */   }
/*     */   
/*     */   public boolean isGeneric() {
/*  72 */     for (JvmMethod method : this.methods) {
/*  73 */       if (method.isGeneric()) {
/*  74 */         return true;
/*     */       }
/*     */     } 
/*  77 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public Specialization trySpecialize(RuntimeState runtimeState, List<ArgumentBounds> namedArguments) {
/*  82 */     List<ValueBounds> arguments = ArgumentBounds.withoutNames(namedArguments);
/*  83 */     JvmMethod method = selectOverload(arguments);
/*  84 */     if (method == null) {
/*  85 */       return UnspecializedCall.INSTANCE;
/*     */     }
/*     */     
/*  88 */     if (method.isDataParallel()) {
/*  89 */       return (new DataParallelCall(this.primitive, method, arguments)).specializeFurther();
/*     */     }
/*  91 */     if (StaticMethodCall.isEligible(method)) {
/*  92 */       return (new StaticMethodCall(method)).furtherSpecialize(arguments);
/*     */     }
/*  94 */     return UnspecializedCall.INSTANCE;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private JvmMethod selectOverload(List<ValueBounds> argumentTypes) {
/* 100 */     for (JvmMethod method : this.methods) {
/* 101 */       if (matches(method, argumentTypes)) {
/* 102 */         return method;
/*     */       }
/*     */     } 
/* 105 */     return null;
/*     */   }
/*     */   
/*     */   private boolean matches(JvmMethod method, List<ValueBounds> argumentTypes) {
/* 109 */     if (!arityMatches(method, argumentTypes)) {
/* 110 */       return false;
/*     */     }
/* 112 */     for (int i = 0; i < method.getPositionalFormals().size(); i++) {
/* 113 */       JvmMethod.Argument formal = method.getPositionalFormals().get(i);
/* 114 */       ValueBounds actualType = argumentTypes.get(i);
/*     */       
/* 116 */       if (!TypeSet.matches(formal.getClazz(), actualType.getTypeSet())) {
/* 117 */         return false;
/*     */       }
/*     */     } 
/* 120 */     return true;
/*     */   }
/*     */   
/*     */   private boolean arityMatches(JvmMethod method, List<ValueBounds> argumentTypes) {
/* 124 */     int numPosArgs = method.getPositionalFormals().size();
/* 125 */     return (argumentTypes.size() == numPosArgs || (method
/* 126 */       .acceptsArgumentList() && argumentTypes.size() >= numPosArgs));
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/builtins/AnnotationBasedSpecializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */