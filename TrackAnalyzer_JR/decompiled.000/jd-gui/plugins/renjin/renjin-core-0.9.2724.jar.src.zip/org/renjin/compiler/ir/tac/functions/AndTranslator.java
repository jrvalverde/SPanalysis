/*     */ package org.renjin.compiler.ir.tac.functions;
/*     */ 
/*     */ import org.renjin.compiler.ir.tac.IRBodyBuilder;
/*     */ import org.renjin.compiler.ir.tac.IRLabel;
/*     */ import org.renjin.compiler.ir.tac.expressions.Constant;
/*     */ import org.renjin.compiler.ir.tac.expressions.Expression;
/*     */ import org.renjin.compiler.ir.tac.expressions.LValue;
/*     */ import org.renjin.compiler.ir.tac.expressions.SimpleExpression;
/*     */ import org.renjin.compiler.ir.tac.expressions.Temp;
/*     */ import org.renjin.compiler.ir.tac.statements.Assignment;
/*     */ import org.renjin.compiler.ir.tac.statements.ExprStatement;
/*     */ import org.renjin.compiler.ir.tac.statements.GotoStatement;
/*     */ import org.renjin.compiler.ir.tac.statements.IfStatement;
/*     */ import org.renjin.compiler.ir.tac.statements.Statement;
/*     */ import org.renjin.sexp.Function;
/*     */ import org.renjin.sexp.FunctionCall;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AndTranslator
/*     */   extends FunctionCallTranslator
/*     */ {
/*     */   public Expression translateToExpression(IRBodyBuilder builder, TranslationContext context, Function resolvedFunction, FunctionCall call) {
/*  41 */     Temp result = builder.newTemp();
/*  42 */     IRLabel firstTrue = builder.newLabel();
/*  43 */     IRLabel firstNA = builder.newLabel();
/*     */     
/*  45 */     IRLabel test2Label = builder.newLabel();
/*     */     
/*  47 */     IRLabel falseLabel = builder.newLabel();
/*  48 */     IRLabel naLabel = builder.newLabel();
/*  49 */     IRLabel finishLabel = builder.newLabel();
/*     */ 
/*     */     
/*  52 */     SimpleExpression condition1 = builder.translateSimpleExpression(context, call.getArgument(0));
/*  53 */     builder.addStatement((Statement)new IfStatement((Expression)condition1, firstTrue, falseLabel, firstNA));
/*     */ 
/*     */ 
/*     */     
/*  57 */     builder.addLabel(firstTrue);
/*  58 */     builder.addStatement((Statement)new Assignment((LValue)result, (Expression)Constant.TRUE));
/*  59 */     builder.addStatement((Statement)new GotoStatement(test2Label));
/*     */ 
/*     */ 
/*     */     
/*  63 */     builder.addLabel(firstNA);
/*  64 */     builder.addStatement((Statement)new Assignment((LValue)result, (Expression)Constant.NA));
/*  65 */     builder.addStatement((Statement)new GotoStatement(test2Label));
/*     */ 
/*     */     
/*  68 */     builder.addLabel(test2Label);
/*  69 */     SimpleExpression condition2 = builder.translateSimpleExpression(context, call.getArgument(1));
/*  70 */     builder.addStatement((Statement)new IfStatement((Expression)condition2, finishLabel, falseLabel, naLabel));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  75 */     builder.addLabel(falseLabel);
/*  76 */     builder.addStatement((Statement)new Assignment((LValue)result, (Expression)Constant.FALSE));
/*  77 */     builder.addStatement((Statement)new GotoStatement(finishLabel));
/*     */     
/*  79 */     builder.addLabel(naLabel);
/*  80 */     builder.addStatement((Statement)new Assignment((LValue)result, (Expression)Constant.NA));
/*     */     
/*  82 */     builder.addLabel(finishLabel);
/*     */     
/*  84 */     return (Expression)result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addStatement(IRBodyBuilder builder, TranslationContext context, Function resolvedFunction, FunctionCall call) {
/*  91 */     IRLabel test2Label = builder.newLabel();
/*  92 */     IRLabel finishLabel = builder.newLabel();
/*     */ 
/*     */     
/*  95 */     SimpleExpression condition1 = builder.translateSimpleExpression(context, call.getArgument(0));
/*  96 */     builder.addStatement((Statement)new IfStatement((Expression)condition1, test2Label, finishLabel, test2Label));
/*     */ 
/*     */     
/*  99 */     builder.addLabel(test2Label);
/* 100 */     builder.addStatement((Statement)new ExprStatement(builder.translateExpression(context, call.getArgument(1))));
/*     */     
/* 102 */     builder.addLabel(finishLabel);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/ir/tac/functions/AndTranslator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */