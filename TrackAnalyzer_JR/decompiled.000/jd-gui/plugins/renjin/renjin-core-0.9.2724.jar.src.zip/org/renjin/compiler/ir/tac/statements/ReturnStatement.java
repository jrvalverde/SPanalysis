/*     */ package org.renjin.compiler.ir.tac.statements;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.renjin.compiler.codegen.ConstantBytecode;
/*     */ import org.renjin.compiler.codegen.EmitContext;
/*     */ import org.renjin.compiler.codegen.VariableStorage;
/*     */ import org.renjin.compiler.ir.ValueBounds;
/*     */ import org.renjin.compiler.ir.tac.IRLabel;
/*     */ import org.renjin.compiler.ir.tac.expressions.EnvironmentVariable;
/*     */ import org.renjin.compiler.ir.tac.expressions.Expression;
/*     */ import org.renjin.compiler.ir.tac.expressions.LValue;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ import org.renjin.repackaged.asm.commons.InstructionAdapter;
/*     */ import org.renjin.repackaged.guava.collect.Lists;
/*     */ import org.renjin.sexp.AttributeMap;
/*     */ import org.renjin.sexp.Environment;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.Symbol;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReturnStatement
/*     */   implements Statement, BasicBlockEndingStatement
/*     */ {
/*     */   private Expression returnValue;
/*  45 */   private List<Symbol> environmentVariableNames = Lists.newArrayList();
/*  46 */   private List<Expression> environmentVariables = Lists.newArrayList();
/*     */ 
/*     */   
/*     */   public ReturnStatement(Expression returnValue) {
/*  50 */     this.returnValue = returnValue;
/*     */   }
/*     */   
/*     */   public Expression getReturnValue() {
/*  54 */     return this.returnValue;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Expression getRHS() {
/*  60 */     return this.returnValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setRHS(Expression newRHS) {
/*  65 */     this.returnValue = newRHS;
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterable<IRLabel> possibleTargets() {
/*  70 */     return Collections.emptySet();
/*     */   }
/*     */   
/*     */   public void addEnvironmentVariables(Iterable<EnvironmentVariable> variables) {
/*  74 */     for (EnvironmentVariable variable : variables) {
/*  75 */       addEnvironmentVariable(variable.getName(), (LValue)variable);
/*     */     }
/*     */   }
/*     */   
/*     */   public void addEnvironmentVariable(Symbol symbol, LValue lValue) {
/*  80 */     this.environmentVariableNames.add(symbol);
/*  81 */     this.environmentVariables.add(lValue);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getChildCount() {
/*  86 */     return 1 + this.environmentVariableNames.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public Expression childAt(int index) {
/*  91 */     if (index == 0) {
/*  92 */       return this.returnValue;
/*     */     }
/*  94 */     return this.environmentVariables.get(index - 1);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setChild(int childIndex, Expression child) {
/* 100 */     if (childIndex == 0) {
/* 101 */       this.returnValue = child;
/*     */     } else {
/* 103 */       this.environmentVariables.set(childIndex - 1, child);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void accept(StatementVisitor visitor) {
/* 109 */     visitor.visitReturn(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int emit(EmitContext emitContext, InstructionAdapter mv) {
/* 116 */     for (int i = 0; i < this.environmentVariableNames.size(); i++) {
/*     */       
/* 118 */       VariableStorage variableStorage = emitContext.getVariableStorage((LValue)this.environmentVariables.get(i));
/* 119 */       if (variableStorage != null) {
/*     */         
/* 121 */         mv.load(emitContext.getEnvironmentVarIndex(), Type.getType(Environment.class));
/* 122 */         mv.aconst(((Symbol)this.environmentVariableNames.get(i)).getPrintName());
/*     */         
/* 124 */         mv.load(variableStorage.getSlotIndex(), variableStorage.getType());
/* 125 */         emitContext.convert(mv, variableStorage.getType(), Type.getType(SEXP.class));
/*     */         
/* 127 */         if (variableStorage.getType().getSort() != 10) {
/* 128 */           ValueBounds bounds = ((Expression)this.environmentVariables.get(i)).getValueBounds();
/* 129 */           if (bounds.isAttributeConstant()) {
/* 130 */             AttributeMap attributes = bounds.getConstantAttributes();
/* 131 */             if (attributes != AttributeMap.EMPTY) {
/* 132 */               ConstantBytecode.generateAttributes(mv, attributes);
/*     */             }
/*     */           } else {
/* 135 */             throw new UnsupportedOperationException("Lost attributes");
/*     */           } 
/*     */         } 
/*     */         
/* 139 */         mv.invokevirtual(Type.getInternalName(Environment.class), "setVariableUnsafe", 
/* 140 */             Type.getMethodDescriptor(Type.VOID_TYPE, new Type[] { Type.getType(String.class), Type.getType(SEXP.class) }), false);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 145 */     this.returnValue.load(emitContext, mv);
/* 146 */     emitContext.writeReturn(mv, this.returnValue.getType());
/* 147 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPure() {
/* 152 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 158 */     StringBuilder s = new StringBuilder();
/* 159 */     s.append("return ");
/* 160 */     s.append(this.returnValue);
/* 161 */     for (int i = 0; i < this.environmentVariableNames.size(); i++) {
/* 162 */       s.append(", ");
/* 163 */       s.append(this.environmentVariableNames.get(i));
/* 164 */       s.append(" = ");
/* 165 */       s.append(this.environmentVariables.get(i));
/*     */     } 
/* 167 */     return s.toString();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/ir/tac/statements/ReturnStatement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */