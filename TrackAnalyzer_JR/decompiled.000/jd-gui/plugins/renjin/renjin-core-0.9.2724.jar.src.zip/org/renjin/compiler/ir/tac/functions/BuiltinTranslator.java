/*    */ package org.renjin.compiler.ir.tac.functions;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.renjin.compiler.ir.tac.IRArgument;
/*    */ import org.renjin.compiler.ir.tac.IRBodyBuilder;
/*    */ import org.renjin.compiler.ir.tac.expressions.BuiltinCall;
/*    */ import org.renjin.compiler.ir.tac.expressions.Expression;
/*    */ import org.renjin.compiler.ir.tac.statements.ExprStatement;
/*    */ import org.renjin.compiler.ir.tac.statements.Statement;
/*    */ import org.renjin.sexp.Function;
/*    */ import org.renjin.sexp.FunctionCall;
/*    */ import org.renjin.sexp.PrimitiveFunction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class BuiltinTranslator
/*    */   extends FunctionCallTranslator
/*    */ {
/* 35 */   public static final BuiltinTranslator INSTANCE = new BuiltinTranslator();
/*    */ 
/*    */   
/*    */   public Expression translateToExpression(IRBodyBuilder builder, TranslationContext context, Function resolvedFunction, FunctionCall call) {
/* 39 */     String functionName = ((PrimitiveFunction)resolvedFunction).getName();
/*    */     
/* 41 */     List<IRArgument> arguments = builder.translateArgumentList(context, call.getArguments());
/*    */     
/* 43 */     return (Expression)new BuiltinCall(builder.getRuntimeState(), call, functionName, arguments);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Expression translateToSetterExpression(IRBodyBuilder builder, TranslationContext context, Function resolvedFunction, FunctionCall getterCall, Expression rhs) {
/* 51 */     String functionName = ((PrimitiveFunction)resolvedFunction).getName();
/*    */     
/* 53 */     List<IRArgument> arguments = builder.translateArgumentList(context, getterCall.getArguments());
/* 54 */     arguments.add(new IRArgument("value", rhs));
/*    */     
/* 56 */     return (Expression)new BuiltinCall(builder.getRuntimeState(), getterCall, functionName, arguments);
/*    */   }
/*    */ 
/*    */   
/*    */   public void addStatement(IRBodyBuilder builder, TranslationContext context, Function resolvedFunction, FunctionCall call) {
/* 61 */     builder.addStatement((Statement)new ExprStatement(translateToExpression(builder, context, resolvedFunction, call)));
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/ir/tac/functions/BuiltinTranslator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */