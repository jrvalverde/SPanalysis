/*    */ package org.renjin.compiler.ir.tac.expressions;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.renjin.compiler.codegen.EmitContext;
/*    */ import org.renjin.compiler.ir.ValueBounds;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ import org.renjin.repackaged.asm.commons.InstructionAdapter;
/*    */ import org.renjin.sexp.SEXP;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReadLoopVector
/*    */   implements Expression
/*    */ {
/*    */   private ValueBounds bounds;
/*    */   
/*    */   public ReadLoopVector(ValueBounds bounds) {
/* 35 */     this.bounds = bounds;
/*    */   }
/*    */   
/*    */   public ReadLoopVector(SEXP elements) {
/* 39 */     this.bounds = ValueBounds.of(elements).withVaryingValues();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isPure() {
/* 44 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public int load(EmitContext emitContext, InstructionAdapter mv) {
/* 49 */     mv.load(emitContext.getLoopVectorIndex(), Type.getType(SEXP.class));
/* 50 */     return 1;
/*    */   }
/*    */ 
/*    */   
/*    */   public Type getType() {
/* 55 */     return Type.getType(SEXP.class);
/*    */   }
/*    */ 
/*    */   
/*    */   public ValueBounds updateTypeBounds(Map<Expression, ValueBounds> typeMap) {
/* 60 */     return this.bounds;
/*    */   }
/*    */ 
/*    */   
/*    */   public ValueBounds getValueBounds() {
/* 65 */     return this.bounds;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setChild(int childIndex, Expression child) {
/* 70 */     throw new IllegalArgumentException("no children");
/*    */   }
/*    */ 
/*    */   
/*    */   public int getChildCount() {
/* 75 */     return 0;
/*    */   }
/*    */ 
/*    */   
/*    */   public Expression childAt(int index) {
/* 80 */     throw new IllegalArgumentException("no children");
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 85 */     return "readLoopVector()";
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/ir/tac/expressions/ReadLoopVector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */