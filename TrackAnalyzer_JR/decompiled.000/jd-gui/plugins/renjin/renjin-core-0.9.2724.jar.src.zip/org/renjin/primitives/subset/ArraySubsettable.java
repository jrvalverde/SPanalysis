package org.renjin.primitives.subset;

import org.renjin.eval.Context;
import org.renjin.sexp.Vector;

public interface ArraySubsettable extends Vector {
  Vector subscript(Context paramContext, int[] paramArrayOfint, Subscript[] paramArrayOfSubscript);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/subset/ArraySubsettable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */