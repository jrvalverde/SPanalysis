/*    */ package org.renjin.primitives.sequence;
/*    */ 
/*    */ import org.renjin.sexp.AtomicVector;
/*    */ import org.renjin.sexp.AttributeMap;
/*    */ import org.renjin.sexp.IntVector;
/*    */ import org.renjin.sexp.SEXP;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IntSequence
/*    */   extends IntVector
/*    */ {
/*    */   private int from;
/*    */   private int by;
/*    */   private int length;
/*    */   
/*    */   public IntSequence(int from, int by, int length) {
/* 34 */     this.from = from;
/* 35 */     this.by = by;
/* 36 */     this.length = length;
/*    */   }
/*    */   
/*    */   public IntSequence(AttributeMap attributes, int from, int by, int length) {
/* 40 */     super(attributes);
/* 41 */     this.from = from;
/* 42 */     this.by = by;
/* 43 */     this.length = length;
/*    */   }
/*    */   
/*    */   public int getFrom() {
/* 47 */     return this.from;
/*    */   }
/*    */   
/*    */   public int getBy() {
/* 51 */     return this.by;
/*    */   }
/*    */   
/*    */   public int getLength() {
/* 55 */     return this.length;
/*    */   }
/*    */ 
/*    */   
/*    */   public int length() {
/* 60 */     return this.length;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getElementAsInt(int i) {
/* 65 */     return this.from + i * this.by;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isElementNA(int index) {
/* 70 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isConstantAccessTime() {
/* 75 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   protected SEXP cloneWithNewAttributes(AttributeMap attributes) {
/* 80 */     return (SEXP)new IntSequence(attributes, this.from, this.by, this.length);
/*    */   }
/*    */   
/*    */   public static AtomicVector fromTo(int n1, int n2) {
/* 84 */     if (n1 <= n2) {
/* 85 */       return (AtomicVector)new IntSequence(n1, 1, n2 - n1 + 1);
/*    */     }
/* 87 */     return (AtomicVector)new IntSequence(n1, -1, n1 - n2 + 1);
/*    */   }
/*    */ 
/*    */   
/*    */   public static AtomicVector fromTo(double n1, double n2) {
/* 92 */     return fromTo((int)n1, (int)n2);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/sequence/IntSequence.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */