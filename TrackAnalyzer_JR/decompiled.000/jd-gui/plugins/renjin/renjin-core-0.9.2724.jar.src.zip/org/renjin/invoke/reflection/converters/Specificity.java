package org.renjin.invoke.reflection.converters;

public class Specificity {
  public static final int BOOLEAN = 1;
  
  public static final int INTEGER = 2;
  
  public static final int DOUBLE = 3;
  
  public static final int ENUM = 4;
  
  public static final int STRING = 4;
  
  public static final int SEXP = 9;
  
  public static final int COLLECTION = 10;
  
  public static final int SPECIFIC_OBJECT = 10;
  
  public static final int OBJECT = 100;
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/reflection/converters/Specificity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */