/*     */ package org.renjin.invoke.codegen;
/*     */ 
/*     */ import com.sun.codemodel.JArray;
/*     */ import com.sun.codemodel.JAssignmentTarget;
/*     */ import com.sun.codemodel.JBlock;
/*     */ import com.sun.codemodel.JClass;
/*     */ import com.sun.codemodel.JClassAlreadyExistsException;
/*     */ import com.sun.codemodel.JCodeModel;
/*     */ import com.sun.codemodel.JConditional;
/*     */ import com.sun.codemodel.JDefinedClass;
/*     */ import com.sun.codemodel.JExpr;
/*     */ import com.sun.codemodel.JExpression;
/*     */ import com.sun.codemodel.JFieldVar;
/*     */ import com.sun.codemodel.JInvocation;
/*     */ import com.sun.codemodel.JMethod;
/*     */ import com.sun.codemodel.JType;
/*     */ import com.sun.codemodel.JVar;
/*     */ import java.util.List;
/*     */ import org.apache.commons.math.complex.Complex;
/*     */ import org.renjin.invoke.model.JvmMethod;
/*     */ import org.renjin.invoke.model.PrimitiveModel;
/*     */ import org.renjin.primitives.vector.DeferredComputation;
/*     */ import org.renjin.repackaged.guava.collect.Lists;
/*     */ import org.renjin.sexp.AttributeMap;
/*     */ import org.renjin.sexp.ComplexArrayVector;
/*     */ import org.renjin.sexp.ComplexVector;
/*     */ import org.renjin.sexp.DoubleVector;
/*     */ import org.renjin.sexp.IntVector;
/*     */ import org.renjin.sexp.Logical;
/*     */ import org.renjin.sexp.LogicalVector;
/*     */ import org.renjin.sexp.RawVector;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.StringVector;
/*     */ import org.renjin.sexp.Vector;
/*     */ 
/*     */ public class DeferredVectorBuilder {
/*     */   public static final int LENGTH_THRESHOLD = 300;
/*     */   private final JExpression contextArgument;
/*     */   private JCodeModel codeModel;
/*     */   private PrimitiveModel primitive;
/*     */   private JvmMethod overload;
/*     */   private int arity;
/*     */   private JDefinedClass vectorClass;
/*     */   private VectorType type;
/*  45 */   private List<DeferredArgument> arguments = Lists.newArrayList();
/*     */   private JFieldVar lengthField;
/*     */   
/*     */   public DeferredVectorBuilder(JCodeModel codeModel, JExpression contextArgument, PrimitiveModel primitive, JvmMethod overload) {
/*  49 */     this.codeModel = codeModel;
/*  50 */     this.primitive = primitive;
/*  51 */     this.overload = overload;
/*  52 */     this.arity = overload.getPositionalFormals().size();
/*  53 */     this.contextArgument = contextArgument;
/*     */     
/*  55 */     if (overload.getReturnType().equals(double.class)) {
/*  56 */       this.type = VectorType.DOUBLE;
/*  57 */     } else if (overload.getReturnType().equals(boolean.class)) {
/*  58 */       this.type = VectorType.LOGICAL;
/*  59 */     } else if (overload.getReturnType().equals(Logical.class)) {
/*  60 */       this.type = VectorType.LOGICAL;
/*  61 */     } else if (overload.getReturnType().equals(int.class)) {
/*  62 */       this.type = VectorType.INTEGER;
/*  63 */     } else if (overload.getReturnType().equals(Complex.class)) {
/*  64 */       this.type = VectorType.COMPLEX;
/*  65 */     } else if (overload.getReturnType().equals(byte.class)) {
/*  66 */       this.type = VectorType.RAW;
/*     */     } else {
/*  68 */       throw new UnsupportedOperationException(overload.getReturnType().toString());
/*     */     } 
/*     */   }
/*     */   
/*     */   public void buildClass() {
/*     */     try {
/*  74 */       this.vectorClass = this.codeModel._class(WrapperGenerator2.toFullJavaName(this.primitive.getName()) + "$deferred_" + typeSuffix());
/*  75 */     } catch (JClassAlreadyExistsException e) {
/*  76 */       throw new RuntimeException(e);
/*     */     } 
/*  78 */     this.vectorClass._extends(this.type.baseClass);
/*  79 */     this.vectorClass._implements(DeferredComputation.class);
/*     */     
/*  81 */     for (int i = 0; i != this.arity; i++) {
/*  82 */       this.arguments.add(new DeferredArgument(this.overload.getPositionalFormals().get(i), i));
/*     */     }
/*     */     
/*  85 */     this.lengthField = this.vectorClass.field(4, this.codeModel._ref(int.class), "length");
/*  86 */     writeConstructor();
/*  87 */     implementAccessor();
/*  88 */     implementLength();
/*  89 */     implementAttributeSetter();
/*  90 */     implementGetOperands();
/*  91 */     implementGetComputationName();
/*  92 */     implementStaticApply();
/*  93 */     implementIsConstantAccess();
/*  94 */     implementIsDeferred();
/*  95 */     implementGetComputationDepth();
/*     */     
/*  97 */     if (this.overload.isPassNA() && this.overload.getReturnType().equals(boolean.class)) {
/*  98 */       overrideIsNaWithConstantValue();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void implementIsConstantAccess() {
/* 104 */     JMethod method = this.vectorClass.method(1, boolean.class, "isConstantAccessTime");
/* 105 */     JExpression jExpression = null;
/* 106 */     for (DeferredArgument arg : this.arguments) {
/* 107 */       JInvocation jInvocation1, jInvocation2 = arg.valueField.invoke("isConstantAccessTime");
/* 108 */       if (jExpression == null) {
/* 109 */         jInvocation1 = jInvocation2; continue;
/*     */       } 
/* 111 */       jExpression = jInvocation1.cand((JExpression)jInvocation2);
/*     */     } 
/*     */     
/* 114 */     method.body()._return(jExpression);
/*     */   }
/*     */ 
/*     */   
/*     */   private void implementIsDeferred() {
/* 119 */     JMethod method = this.vectorClass.method(1, boolean.class, "isDeferred");
/* 120 */     method.body()._return(JExpr.TRUE);
/*     */   }
/*     */   
/*     */   private void implementGetComputationDepth() {
/* 124 */     JMethod method = this.vectorClass.method(1, int.class, "getComputationDepth");
/* 125 */     JVar depth = method.body().decl(this.codeModel._ref(int.class), "depth", 
/* 126 */         (JExpression)(this.arguments.get(0)).valueField.invoke("getComputationDepth"));
/*     */     
/* 128 */     for (int i = 1; i < this.arguments.size(); i++) {
/* 129 */       method.body().assign((JAssignmentTarget)depth, (JExpression)this.codeModel.ref(Math.class).staticInvoke("max")
/* 130 */           .arg((JExpression)depth)
/* 131 */           .arg((JExpression)(this.arguments.get(1)).valueField.invoke("getComputationDepth")));
/*     */     }
/*     */     
/* 134 */     method.body()._return(depth.plus(JExpr.lit(1)));
/*     */   }
/*     */   
/*     */   private void implementGetOperands() {
/* 138 */     JMethod method = this.vectorClass.method(1, Vector[].class, "getOperands");
/* 139 */     JArray array = JExpr.newArray((JType)this.codeModel.ref(Vector.class));
/* 140 */     for (DeferredArgument arg : this.arguments) {
/* 141 */       array.add((JExpression)arg.valueField);
/*     */     }
/* 143 */     method.body()._return((JExpression)array);
/*     */   }
/*     */ 
/*     */   
/*     */   private void implementGetComputationName() {
/* 148 */     JMethod method = this.vectorClass.method(1, String.class, "getComputationName");
/* 149 */     method.body()._return(JExpr.lit(this.primitive.getName()));
/*     */   }
/*     */   
/*     */   private String typeSuffix() {
/* 153 */     StringBuilder suffix = new StringBuilder();
/* 154 */     for (JvmMethod.Argument formal : this.overload.getPositionalFormals()) {
/* 155 */       suffix.append(abbrev(formal.getClazz()));
/*     */     }
/* 157 */     return suffix.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   private String abbrev(Class clazz) {
/* 162 */     if (clazz.equals(double.class))
/* 163 */       return "d"; 
/* 164 */     if (clazz.equals(boolean.class))
/* 165 */       return "b"; 
/* 166 */     if (clazz.equals(String.class))
/* 167 */       return "s"; 
/* 168 */     if (clazz.equals(int.class))
/* 169 */       return "i"; 
/* 170 */     if (clazz.equals(Complex.class))
/* 171 */       return "z"; 
/* 172 */     if (clazz.equals(byte.class)) {
/* 173 */       return "r";
/*     */     }
/* 175 */     throw new UnsupportedOperationException(clazz.toString());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void maybeReturn(JBlock parent, JExpression cycleCount, List<JExpression> arguments, JExpression attributes) {
/* 183 */     JExpression condition = cycleCount.gt(JExpr.lit(300));
/* 184 */     for (JExpression arg : arguments) {
/* 185 */       condition = condition.cor((JExpression)arg.invoke("isDeferred"));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 190 */     condition = condition.cand(cycleCount.ne(JExpr.lit(0)));
/*     */ 
/*     */     
/* 193 */     JBlock ifBig = parent._if(condition)._then();
/*     */     
/* 195 */     JInvocation newInvocation = JExpr._new((JClass)this.vectorClass);
/* 196 */     for (JExpression arg : arguments) {
/* 197 */       newInvocation.arg(arg);
/*     */     }
/* 199 */     newInvocation.arg(attributes);
/*     */     
/* 201 */     ifBig._return((JExpression)this.contextArgument.invoke("simplify").arg((JExpression)newInvocation));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeConstructor() {
/* 215 */     JMethod ctor = this.vectorClass.constructor(1);
/* 216 */     List<JVar> argParams = Lists.newArrayList(); int i;
/* 217 */     for (i = 0; i != this.arity; i++) {
/* 218 */       argParams.add(ctor.param(Vector.class, "arg" + i));
/*     */     }
/* 220 */     ctor.param(AttributeMap.class, "attributes");
/* 221 */     ctor.body().directStatement("super(attributes);");
/* 222 */     ctor.body().assign((JAssignmentTarget)this.lengthField, JExpr.lit(0));
/* 223 */     for (i = 0; i != this.arity; i++) {
/* 224 */       ctor.body().assign((JAssignmentTarget)JExpr._this().ref((JVar)(arg(i)).valueField), (JExpression)argParams.get(i));
/* 225 */       ctor.body().assign((JAssignmentTarget)(arg(i)).lengthField, (JExpression)(arg(i)).valueField.invoke("length"));
/*     */     } 
/* 227 */     if (this.arity == 1) {
/* 228 */       ctor.body().assign((JAssignmentTarget)this.lengthField, (JExpression)(arg(0)).lengthField);
/* 229 */     } else if (this.arity == 2) {
/* 230 */       ctor.body().assign((JAssignmentTarget)this.lengthField, (JExpression)this.codeModel.ref(Math.class).staticInvoke("max")
/* 231 */           .arg((JExpression)(arg(0)).lengthField)
/* 232 */           .arg((JExpression)(arg(1)).lengthField));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private DeferredArgument arg(int i) {
/* 238 */     return this.arguments.get(i);
/*     */   }
/*     */   
/*     */   private void implementLength() {
/* 242 */     JMethod method = this.vectorClass.method(1, int.class, "length");
/* 243 */     method.body()._return((JExpression)this.lengthField);
/*     */   }
/*     */ 
/*     */   
/*     */   private void implementStaticApply() {
/* 248 */     JMethod method = this.vectorClass.method(17, this.type.accessorType, "compute");
/* 249 */     List<JExpression> params = Lists.newArrayList();
/* 250 */     for (DeferredArgument argument : this.arguments) {
/* 251 */       JVar param = method.param(argument.accessorType(), "p" + argument.index);
/* 252 */       params.add(argument.convert((JExpression)param));
/*     */     } 
/* 254 */     returnValue(method.body(), (JExpression)buildInvocation(params));
/*     */   }
/*     */   
/*     */   private void implementAccessor() {
/* 258 */     JMethod method = this.vectorClass.method(1, this.type.accessorType, this.type.accessorName);
/* 259 */     JVar index = method.param(int.class, "index");
/*     */ 
/*     */     
/* 262 */     List<JExpression> argValues = Lists.newArrayList();
/* 263 */     for (DeferredArgument arg : this.arguments) {
/*     */       JVar jVar1;
/*     */       
/* 266 */       if (this.arity == 1) {
/* 267 */         jVar1 = index;
/*     */       } else {
/*     */         
/* 270 */         JVar indexVar = method.body().decl(this.codeModel._ref(int.class), "i" + arg.index);
/* 271 */         JConditional ifLessThan = method.body()._if(index.lt((JExpression)arg.lengthField));
/* 272 */         ifLessThan._then().assign((JAssignmentTarget)indexVar, (JExpression)index);
/* 273 */         ifLessThan._else().assign((JAssignmentTarget)indexVar, index.mod((JExpression)arg.lengthField));
/* 274 */         jVar1 = indexVar;
/*     */       } 
/*     */       
/* 277 */       JVar argValue = method.body().decl(arg.accessorType(), "arg" + arg.index + "_i", arg.invokeAccessor((JExpression)jVar1));
/* 278 */       argValues.add(arg.convert((JExpression)argValue));
/*     */       
/* 280 */       if (!this.overload.isPassNA() && arg.type != ArgumentType.BYTE) {
/* 281 */         method.body()._if(arg.isNA((JExpression)argValue))._then()._return(na());
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 286 */     returnValue(method.body(), (JExpression)buildInvocation(argValues));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private JInvocation buildInvocation(List<JExpression> argValues) {
/* 292 */     JInvocation invocation = this.codeModel.ref(this.overload.getDeclaringClass()).staticInvoke(this.overload.getName());
/* 293 */     for (JExpression argValue : argValues) {
/* 294 */       invocation.arg(argValue);
/*     */     }
/* 296 */     return invocation;
/*     */   }
/*     */   
/*     */   private JExpression na() {
/* 300 */     switch (this.type) {
/*     */       case DOUBLE:
/* 302 */         return (JExpression)this.codeModel.ref(DoubleVector.class).staticRef("NA");
/*     */       
/*     */       case LOGICAL:
/*     */       case INTEGER:
/* 306 */         return (JExpression)this.codeModel.ref(IntVector.class).staticRef("NA");
/*     */       
/*     */       case COMPLEX:
/* 309 */         return (JExpression)this.codeModel.ref(ComplexArrayVector.class).staticRef("NA");
/*     */     } 
/* 311 */     throw new UnsupportedOperationException(this.type.toString());
/*     */   }
/*     */   
/*     */   private void returnValue(JBlock parent, JExpression retVal) {
/* 315 */     if (this.overload.getReturnType().equals(boolean.class)) {
/* 316 */       JConditional ifTrue = parent._if(retVal);
/* 317 */       ifTrue._then()._return(JExpr.lit(1));
/* 318 */       ifTrue._else()._return(JExpr.lit(0));
/* 319 */     } else if (this.overload.getReturnType().equals(Logical.class)) {
/* 320 */       parent._return((JExpression)retVal.invoke("getInternalValue"));
/*     */     } else {
/* 322 */       parent._return(retVal);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void overrideIsNaWithConstantValue() {
/* 327 */     JMethod method = this.vectorClass.method(1, boolean.class, "isElementNA");
/* 328 */     method.param(int.class, "index");
/* 329 */     method.body()._return(JExpr.FALSE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void implementAttributeSetter() {
/* 338 */     JMethod method = this.vectorClass.method(1, SEXP.class, "cloneWithNewAttributes");
/* 339 */     JVar attributes = method.param(AttributeMap.class, "attributes");
/*     */     
/* 341 */     JInvocation newInvocation = JExpr._new((JClass)this.vectorClass);
/* 342 */     for (DeferredArgument arg : this.arguments) {
/* 343 */       newInvocation.arg((JExpression)arg.valueField);
/*     */     }
/* 345 */     newInvocation.arg((JExpression)attributes);
/* 346 */     method.body()._return((JExpression)newInvocation);
/*     */   }
/*     */   
/*     */   private class DeferredArgument {
/*     */     private JvmMethod.Argument model;
/*     */     private int index;
/*     */     private JFieldVar valueField;
/*     */     private JFieldVar lengthField;
/*     */     private DeferredVectorBuilder.ArgumentType type;
/*     */     
/*     */     private DeferredArgument(JvmMethod.Argument model, int index) {
/* 357 */       this.model = model;
/* 358 */       this.index = index;
/* 359 */       this.valueField = DeferredVectorBuilder.this.vectorClass.field(12, Vector.class, "arg" + index);
/* 360 */       this.lengthField = DeferredVectorBuilder.this.vectorClass.field(12, int.class, "argLength" + index);
/*     */       
/* 362 */       if (model.getClazz().equals(double.class)) {
/* 363 */         this.type = DeferredVectorBuilder.ArgumentType.DOUBLE;
/* 364 */       } else if (model.getClazz().equals(boolean.class)) {
/* 365 */         this.type = DeferredVectorBuilder.ArgumentType.BOOLEAN;
/* 366 */       } else if (model.getClazz().equals(int.class)) {
/* 367 */         this.type = DeferredVectorBuilder.ArgumentType.INTEGER;
/* 368 */       } else if (model.getClazz().equals(String.class)) {
/* 369 */         this.type = DeferredVectorBuilder.ArgumentType.STRING;
/* 370 */       } else if (model.getClazz().equals(Complex.class)) {
/* 371 */         this.type = DeferredVectorBuilder.ArgumentType.COMPLEX;
/* 372 */       } else if (model.getClazz().equals(byte.class)) {
/* 373 */         this.type = DeferredVectorBuilder.ArgumentType.BYTE;
/*     */       } else {
/* 375 */         throw new UnsupportedOperationException(model.getClazz().toString());
/*     */       } 
/*     */     }
/*     */     
/*     */     public JType type() {
/* 380 */       return DeferredVectorBuilder.this.codeModel._ref(this.model.getClazz());
/*     */     }
/*     */     
/*     */     public JExpression invokeAccessor(JExpression elementIndex) {
/* 384 */       return (JExpression)this.valueField.invoke(this.type.accessorName).arg(elementIndex);
/*     */     }
/*     */     
/*     */     public JType accessorType() {
/* 388 */       return DeferredVectorBuilder.this.codeModel._ref(this.type.accessorType());
/*     */     }
/*     */     
/*     */     public JExpression isNA(JExpression expr) {
/* 392 */       return this.type.isNa(DeferredVectorBuilder.this.codeModel, expr);
/*     */     }
/*     */     
/*     */     public JExpression convert(JExpression argValue) {
/* 396 */       return this.type.convertToArg(argValue);
/*     */     }
/*     */   }
/*     */   
/*     */   private enum VectorType
/*     */   {
/* 402 */     DOUBLE((String)DoubleVector.class, "getElementAsDouble", double.class),
/* 403 */     LOGICAL((String)LogicalVector.class, "getElementAsRawLogical", int.class),
/* 404 */     INTEGER((String)IntVector.class, "getElementAsInt", int.class),
/* 405 */     COMPLEX((String)ComplexVector.class, "getElementAsComplex", Complex.class),
/* 406 */     RAW((String)RawVector.class, "getElementAsByte", byte.class);
/*     */     
/*     */     private Class baseClass;
/*     */     private String accessorName;
/*     */     private Class accessorType;
/*     */     
/*     */     VectorType(Class baseClass, String accessorName, Class accessorType) {
/* 413 */       this.baseClass = baseClass;
/* 414 */       this.accessorName = accessorName;
/* 415 */       this.accessorType = accessorType;
/*     */     }
/*     */   }
/*     */   
/*     */   private enum ArgumentType
/*     */   {
/* 421 */     DOUBLE((String)double.class, "getElementAsDouble")
/*     */     {
/*     */       public JExpression isNa(JCodeModel codeModel, JExpression expr) {
/* 424 */         return (JExpression)codeModel.ref(DoubleVector.class).staticInvoke("isNA").arg(expr);
/*     */       }
/*     */     },
/* 427 */     INTEGER((String)int.class, "getElementAsInt")
/*     */     {
/*     */       public JExpression isNa(JCodeModel codeModel, JExpression expr) {
/* 430 */         return (JExpression)codeModel.ref(IntVector.class).staticInvoke("isNA").arg(expr);
/*     */       }
/*     */     },
/* 433 */     BOOLEAN((String)boolean.class, "getElementAsRawLogical")
/*     */     {
/*     */       public JExpression convertToArg(JExpression expr) {
/* 436 */         return expr.ne(JExpr.lit(0));
/*     */       }
/*     */ 
/*     */       
/*     */       public Class accessorType() {
/* 441 */         return int.class;
/*     */       }
/*     */ 
/*     */       
/*     */       public JExpression isNa(JCodeModel codeModel, JExpression expr) {
/* 446 */         return (JExpression)codeModel.ref(IntVector.class).staticInvoke("isNA").arg(expr);
/*     */       }
/*     */     },
/* 449 */     STRING((String)String.class, "getElementAsString")
/*     */     {
/*     */       public JExpression isNa(JCodeModel codeModel, JExpression expr) {
/* 452 */         return (JExpression)codeModel.ref(StringVector.class).staticInvoke("isNA").arg(expr);
/*     */       }
/*     */     },
/* 455 */     COMPLEX((String)Complex.class, "getElementAsComplex")
/*     */     {
/*     */       public JExpression isNa(JCodeModel codeModel, JExpression expr) {
/* 458 */         return (JExpression)codeModel.ref(ComplexVector.class).staticInvoke("isNA").arg(expr);
/*     */       } },
/* 460 */     BYTE((String)byte.class, "getElementAsByte")
/*     */     {
/*     */       public JExpression isNa(JCodeModel codeModel, JExpression expr) {
/* 463 */         return JExpr.lit(false);
/*     */       }
/*     */     };
/*     */ 
/*     */     
/*     */     private Class clazz;
/*     */     private String accessorName;
/*     */     
/*     */     ArgumentType(Class clazz, String accessorName) {
/* 472 */       this.clazz = clazz;
/* 473 */       this.accessorName = accessorName;
/*     */     }
/*     */     
/*     */     public JExpression convertToArg(JExpression expr) {
/* 477 */       return expr;
/*     */     }
/*     */     
/*     */     public Class accessorType() {
/* 481 */       return this.clazz;
/*     */     }
/*     */     
/*     */     public abstract JExpression isNa(JCodeModel param1JCodeModel, JExpression param1JExpression);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/codegen/DeferredVectorBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */