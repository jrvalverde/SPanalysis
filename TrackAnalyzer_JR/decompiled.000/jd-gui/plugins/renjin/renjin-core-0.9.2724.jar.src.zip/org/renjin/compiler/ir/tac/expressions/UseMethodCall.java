/*     */ package org.renjin.compiler.ir.tac.expressions;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.renjin.compiler.builtins.ArgumentBounds;
/*     */ import org.renjin.compiler.builtins.S3Specialization;
/*     */ import org.renjin.compiler.builtins.Specialization;
/*     */ import org.renjin.compiler.builtins.UnspecializedCall;
/*     */ import org.renjin.compiler.codegen.EmitContext;
/*     */ import org.renjin.compiler.ir.ValueBounds;
/*     */ import org.renjin.compiler.ir.tac.IRArgument;
/*     */ import org.renjin.compiler.ir.tac.RuntimeState;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ import org.renjin.repackaged.asm.commons.InstructionAdapter;
/*     */ import org.renjin.repackaged.guava.base.Joiner;
/*     */ import org.renjin.sexp.FunctionCall;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UseMethodCall
/*     */   implements Expression
/*     */ {
/*     */   private RuntimeState runtimeState;
/*     */   private FunctionCall call;
/*     */   private final String generic;
/*     */   private final List<IRArgument> arguments;
/*     */   private Expression objectExpr;
/*  57 */   private Specialization specialization = (Specialization)UnspecializedCall.INSTANCE;
/*     */   
/*     */   public UseMethodCall(RuntimeState runtimeState, FunctionCall call, String generic, Expression objectExpr) {
/*  60 */     this.runtimeState = runtimeState;
/*  61 */     this.call = call;
/*  62 */     this.generic = generic;
/*  63 */     this.objectExpr = objectExpr;
/*     */ 
/*     */     
/*  66 */     this.arguments = Collections.singletonList(new IRArgument(objectExpr));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPure() {
/*  71 */     return this.specialization.isPure();
/*     */   }
/*     */ 
/*     */   
/*     */   public int load(EmitContext emitContext, InstructionAdapter mv) {
/*  76 */     this.specialization.load(emitContext, mv, this.arguments);
/*  77 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public Type getType() {
/*  82 */     return this.specialization.getType();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ValueBounds updateTypeBounds(Map<Expression, ValueBounds> typeMap) {
/*  88 */     ValueBounds objectBounds = typeMap.get(this.objectExpr);
/*     */ 
/*     */     
/*  91 */     this.specialization = S3Specialization.trySpecialize(this.generic, this.runtimeState, objectBounds, ArgumentBounds.create(this.arguments, typeMap));
/*  92 */     return this.specialization.getResultBounds();
/*     */   }
/*     */ 
/*     */   
/*     */   public ValueBounds getValueBounds() {
/*  97 */     return this.specialization.getResultBounds();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setChild(int childIndex, Expression child) {
/* 102 */     if (childIndex == 0) {
/* 103 */       this.objectExpr = child;
/*     */     } else {
/* 105 */       ((IRArgument)this.arguments.get(childIndex - 1)).setExpression(child);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int getChildCount() {
/* 111 */     return 1 + this.arguments.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public Expression childAt(int index) {
/* 116 */     if (index == 0) {
/* 117 */       return this.objectExpr;
/*     */     }
/* 119 */     return ((IRArgument)this.arguments.get(index - 1)).getExpression();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 125 */     return "UseMethod(" + this.generic + ", " + this.objectExpr + ", " + Joiner.on(", ").join(this.arguments) + ")";
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/ir/tac/expressions/UseMethodCall.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */