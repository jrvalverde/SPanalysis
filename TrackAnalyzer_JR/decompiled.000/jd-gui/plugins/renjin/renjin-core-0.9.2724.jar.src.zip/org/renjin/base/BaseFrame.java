/*     */ package org.renjin.base;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.IdentityHashMap;
/*     */ import java.util.Set;
/*     */ import org.renjin.RenjinVersion;
/*     */ import org.renjin.eval.Context;
/*     */ import org.renjin.eval.Session;
/*     */ import org.renjin.packaging.LazyLoadFrame;
/*     */ import org.renjin.primitives.Primitives;
/*     */ import org.renjin.repackaged.guava.base.Function;
/*     */ import org.renjin.repackaged.guava.collect.Sets;
/*     */ import org.renjin.sexp.Frame;
/*     */ import org.renjin.sexp.Function;
/*     */ import org.renjin.sexp.ListVector;
/*     */ import org.renjin.sexp.NamedValue;
/*     */ import org.renjin.sexp.PrimitiveFunction;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.StringVector;
/*     */ import org.renjin.sexp.Symbol;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BaseFrame
/*     */   implements Frame
/*     */ {
/*  46 */   private final IdentityHashMap<Symbol, SEXP> loaded = new IdentityHashMap<>(1100);
/*     */ 
/*     */   
/*     */   public Set<Symbol> getSymbols() {
/*  50 */     return (Set<Symbol>)Sets.union(Primitives.getBuiltinSymbols(), this.loaded.keySet());
/*     */   }
/*     */ 
/*     */   
/*     */   public SEXP getVariable(Symbol name) {
/*  55 */     PrimitiveFunction primitiveFunction = Primitives.getBuiltin(name);
/*  56 */     if (primitiveFunction != null) {
/*  57 */       return (SEXP)primitiveFunction;
/*     */     }
/*  59 */     SEXP sEXP = this.loaded.get(name);
/*  60 */     if (sEXP != null) {
/*  61 */       return sEXP;
/*     */     }
/*  63 */     return (SEXP)Symbol.UNBOUND_VALUE;
/*     */   }
/*     */   
/*     */   public Function getFunction(Context context, Symbol name) {
/*     */     SEXP sEXP;
/*  68 */     PrimitiveFunction primitiveFunction = Primitives.getBuiltin(name);
/*  69 */     if (primitiveFunction == null) {
/*  70 */       sEXP = this.loaded.get(name);
/*     */     }
/*  72 */     if (sEXP == null) {
/*  73 */       return null;
/*     */     }
/*  75 */     if (sEXP instanceof org.renjin.sexp.Promise) {
/*  76 */       sEXP = sEXP.force(context);
/*     */     }
/*  78 */     if (sEXP instanceof Function) {
/*  79 */       return (Function)sEXP;
/*     */     }
/*  81 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVariable(Symbol name, SEXP value) {
/*  87 */     this.loaded.put(name, value);
/*     */   }
/*     */   
/*     */   public BaseFrame(Session session) {
/*  91 */     installPlatform(session);
/*  92 */     installMachine();
/*  93 */     this.loaded.put(Symbol.get("R.version.string"), 
/*  94 */         StringVector.valueOf("Renjin version " + RenjinVersion.getVersionName()));
/*     */   }
/*     */   
/*     */   private void installPlatform(Session session) {
/*  98 */     this.loaded.put(Symbol.get(".Library"), StringVector.valueOf(session.getHomeDirectory() + "/library"));
/*  99 */     this.loaded.put(Symbol.get(".Library.site"), StringVector.EMPTY);
/*     */     
/* 101 */     this.loaded.put(Symbol.get(".Platform"), ListVector.newNamedBuilder()
/* 102 */         .add("OS.type", resolveOsName())
/* 103 */         .add("file.sep", "/")
/* 104 */         .add("GUI", "unknown")
/* 105 */         .add("endian", "big")
/* 106 */         .add("pkgType", "source")
/* 107 */         .add("r_arch", "")
/* 108 */         .add("dynlib.ext", dynlibExt())
/* 109 */         .build());
/*     */   }
/*     */   
/*     */   protected String dynlibExt() {
/* 113 */     String os = System.getProperty("os.name").toLowerCase();
/* 114 */     if (os.contains("win"))
/* 115 */       return ".dll"; 
/* 116 */     if (os.contains("mac")) {
/* 117 */       return ".dylib";
/*     */     }
/* 119 */     return ".so";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void remove(Symbol name) {
/* 127 */     this.loaded.remove(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void installMachine() {
/* 138 */     this.loaded.put(Symbol.get(".Machine"), ListVector.newNamedBuilder()
/* 139 */         .add("double.eps", 2.220446E-16D)
/* 140 */         .add("double.neg.eps", 1.110223E-16D)
/* 141 */         .add("double.xmin", 2.225074E-308D)
/* 142 */         .add("double.xmax", 1.797693E308D)
/* 143 */         .add("double.base", 2)
/* 144 */         .add("double.digits", 53)
/* 145 */         .add("double.rounding", 5)
/* 146 */         .add("double.guard", 0)
/* 147 */         .add("double.ulp.digits", -52)
/* 148 */         .add("double.neg.ulp.digits", -53)
/* 149 */         .add("double.exponent", 11)
/* 150 */         .add("double.min.exp", -1022)
/* 151 */         .add("double.max.exp", 1023)
/* 152 */         .add("integer.max", 2147483647)
/* 153 */         .add("sizeof.long", 4)
/* 154 */         .add("sizeof.longlong", 8)
/* 155 */         .add("sizeof.longdouble", 12)
/* 156 */         .add("sizeof.pointer", 4)
/* 157 */         .build());
/*     */   }
/*     */ 
/*     */   
/*     */   private String resolveOsName() {
/* 162 */     return System.getProperty("os.name").contains("windows") ? "windows" : "unix";
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear() {
/* 167 */     throw new UnsupportedOperationException("The base frame cannot be cleared");
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isMissingArgument(Symbol name) {
/* 172 */     return false;
/*     */   }
/*     */   
/*     */   public void load(Context context) throws IOException {
/* 176 */     Iterable<NamedValue> frame = LazyLoadFrame.load(context, new Function<String, InputStream>()
/*     */         {
/*     */           public InputStream apply(String name)
/*     */           {
/* 180 */             String resourcePath = "/org/renjin/base/" + name;
/* 181 */             InputStream in = getClass().getResourceAsStream(resourcePath);
/* 182 */             if (in == null) {
/* 183 */               throw new RuntimeException("Could not open resource " + resourcePath);
/*     */             }
/* 185 */             return in;
/*     */           }
/*     */         });
/* 188 */     for (NamedValue name : frame) {
/* 189 */       this.loaded.put(Symbol.get(name.getName()), name.getValue());
/*     */     }
/*     */ 
/*     */     
/* 193 */     addPrimitiveAlias("as.double", "as.numeric");
/* 194 */     addPrimitiveAlias("as.double", "as.real");
/* 195 */     addPrimitiveAlias("is.symbol", "is.name");
/*     */   }
/*     */ 
/*     */   
/*     */   private void addPrimitiveAlias(String primitiveName, String alias) {
/* 200 */     this.loaded.put(Symbol.get(alias), Primitives.getBuiltin(primitiveName));
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/base/BaseFrame.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */