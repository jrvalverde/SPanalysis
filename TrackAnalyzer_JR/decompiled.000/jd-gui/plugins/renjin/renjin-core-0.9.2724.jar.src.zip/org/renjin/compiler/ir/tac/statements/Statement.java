package org.renjin.compiler.ir.tac.statements;

import org.renjin.compiler.codegen.EmitContext;
import org.renjin.compiler.ir.tac.IRLabel;
import org.renjin.compiler.ir.tac.TreeNode;
import org.renjin.compiler.ir.tac.expressions.Expression;
import org.renjin.repackaged.asm.commons.InstructionAdapter;

public interface Statement extends TreeNode {
  Iterable<IRLabel> possibleTargets();
  
  Expression getRHS();
  
  void setRHS(Expression paramExpression);
  
  void accept(StatementVisitor paramStatementVisitor);
  
  int emit(EmitContext paramEmitContext, InstructionAdapter paramInstructionAdapter);
  
  boolean isPure();
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/ir/tac/statements/Statement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */