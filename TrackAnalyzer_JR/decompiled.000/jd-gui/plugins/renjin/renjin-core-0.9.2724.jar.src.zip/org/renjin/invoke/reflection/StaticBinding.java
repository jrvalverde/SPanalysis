/*    */ package org.renjin.invoke.reflection;
/*    */ 
/*    */ import org.renjin.sexp.SEXP;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StaticBinding
/*    */   implements MemberBinding
/*    */ {
/*    */   private MemberBinding binding;
/*    */   
/*    */   public StaticBinding(MemberBinding binding) {
/* 28 */     this.binding = binding;
/*    */   }
/*    */ 
/*    */   
/*    */   public SEXP getValue(Object instance) {
/* 33 */     return getValue();
/*    */   }
/*    */   
/*    */   public SEXP getValue() {
/* 37 */     return this.binding.getValue(null);
/*    */   }
/*    */ 
/*    */   
/*    */   public void setValue(Object instance, SEXP value) {
/* 42 */     setValue(null, value);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/reflection/StaticBinding.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */