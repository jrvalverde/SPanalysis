/*     */ package org.renjin.pipeliner.fusion;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.concurrent.Future;
/*     */ import org.renjin.eval.EvalException;
/*     */ import org.renjin.pipeliner.fusion.kernel.CompiledKernel;
/*     */ import org.renjin.pipeliner.fusion.kernel.LoopKernel;
/*     */ import org.renjin.pipeliner.fusion.node.BinaryVectorOpNode;
/*     */ import org.renjin.pipeliner.fusion.node.DistanceMatrixNode;
/*     */ import org.renjin.pipeliner.fusion.node.DoubleArrayNode;
/*     */ import org.renjin.pipeliner.fusion.node.IntArrayNode;
/*     */ import org.renjin.pipeliner.fusion.node.IntBufferNode;
/*     */ import org.renjin.pipeliner.fusion.node.IntSeqNode;
/*     */ import org.renjin.pipeliner.fusion.node.LoopNode;
/*     */ import org.renjin.pipeliner.fusion.node.RepeatingNode;
/*     */ import org.renjin.pipeliner.fusion.node.TransposeNode;
/*     */ import org.renjin.pipeliner.fusion.node.UnaryVectorOpNode;
/*     */ import org.renjin.pipeliner.fusion.node.VirtualVectorNode;
/*     */ import org.renjin.pipeliner.node.DeferredNode;
/*     */ import org.renjin.pipeliner.node.FunctionNode;
/*     */ import org.renjin.pipeliner.node.NodeShape;
/*     */ import org.renjin.primitives.vector.MemoizedComputation;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ import org.renjin.sexp.DoubleArrayVector;
/*     */ import org.renjin.sexp.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FusedNode
/*     */   extends DeferredNode
/*     */   implements Runnable
/*     */ {
/*     */   private LoopKernel kernel;
/*     */   private LoopNode[] kernelOperands;
/*     */   private MemoizedComputation memoizedComputation;
/*     */   private DoubleArrayVector resultVector;
/*     */   private Future<CompiledKernel> compiledKernel;
/*     */   
/*     */   public FusedNode(FunctionNode node) {
/*  53 */     this.kernel = LoopKernels.INSTANCE.get(node);
/*  54 */     this.kernelOperands = new LoopNode[node.getOperands().size()];
/*  55 */     this.memoizedComputation = (MemoizedComputation)node.getVector();
/*     */     
/*  57 */     for (int i = 0; i < this.kernelOperands.length; i++) {
/*  58 */       this.kernelOperands[i] = addLoopNode(node.getOperand(i));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private LoopNode addLoopNode(DeferredNode node) {
/*  68 */     if (node instanceof FusedNode) {
/*  69 */       int inputIndex = addInput(node);
/*  70 */       node.addOutput(this);
/*     */       
/*  72 */       return (LoopNode)new DoubleArrayNode(inputIndex, Type.getType(DoubleArrayVector.class));
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  78 */     if (node instanceof FunctionNode) {
/*     */       
/*  80 */       FunctionNode computation = (FunctionNode)node;
/*  81 */       String name = computation.getComputationName();
/*     */       
/*  83 */       if (name.equals("dist")) {
/*  84 */         return (LoopNode)new DistanceMatrixNode(addLoopNode(computation.getOperand(0)));
/*     */       }
/*     */       
/*  87 */       if (name.equals("rep")) {
/*  88 */         return (LoopNode)new RepeatingNode(
/*  89 */             addLoopNode(node.getOperand(0)), 
/*  90 */             addLoopNode(node.getOperand(1)));
/*     */       }
/*     */       
/*  93 */       if (name.equals("t")) {
/*  94 */         return (LoopNode)new TransposeNode(
/*  95 */             addLoopNode(node.getOperand(0)), 
/*  96 */             addLoopNode(node.getOperand(1)));
/*     */       }
/*     */       
/*  99 */       int arity = node.getOperands().size();
/*     */       
/* 101 */       if (arity == 1) {
/* 102 */         Method unaryOperator = UnaryVectorOpNode.findMethod(node.getVector());
/* 103 */         if (unaryOperator != null) {
/* 104 */           return (LoopNode)new UnaryVectorOpNode(name, unaryOperator, 
/*     */               
/* 106 */               addLoopNode(node.getOperand(0)));
/*     */         }
/*     */       } 
/*     */       
/* 110 */       if (arity == 2) {
/* 111 */         Method binaryOperator = BinaryVectorOpNode.findMethod(node.getVector());
/* 112 */         if (binaryOperator != null) {
/* 113 */           return (LoopNode)new BinaryVectorOpNode(name, binaryOperator, 
/*     */ 
/*     */               
/* 116 */               addLoopNode(node.getOperand(0)), 
/* 117 */               addLoopNode(node.getOperand(1)));
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 126 */     return addLoopInput(node);
/*     */   }
/*     */ 
/*     */   
/*     */   private LoopNode addLoopInput(DeferredNode node) {
/* 131 */     int inputIndex = addInput(node);
/* 132 */     node.addOutput(this);
/*     */     
/* 134 */     if (node.getVector() instanceof org.renjin.sexp.IntBufferVector) {
/* 135 */       return (LoopNode)new IntBufferNode(inputIndex);
/*     */     }
/*     */     
/* 138 */     if (node.getVector() instanceof org.renjin.primitives.sequence.IntSequence) {
/* 139 */       return (LoopNode)new IntSeqNode(inputIndex);
/*     */     }
/*     */     
/* 142 */     if (node.getVector() instanceof DoubleArrayVector) {
/* 143 */       return (LoopNode)new DoubleArrayNode(inputIndex, node.getResultVectorType());
/*     */     }
/*     */     
/* 146 */     if (node.getVector() instanceof org.renjin.sexp.IntArrayVector) {
/* 147 */       return (LoopNode)new IntArrayNode(inputIndex, node.getResultVectorType());
/*     */     }
/*     */     
/* 150 */     if (node.getVector() instanceof org.renjin.sexp.LogicalArrayVector) {
/* 151 */       return (LoopNode)new IntArrayNode(inputIndex, node.getResultVectorType());
/*     */     }
/*     */     
/* 154 */     return (LoopNode)new VirtualVectorNode(inputIndex, node.getVector());
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDebugLabel() {
/* 159 */     return this.kernel.debugLabel(this.kernelOperands);
/*     */   }
/*     */ 
/*     */   
/*     */   public NodeShape getShape() {
/* 164 */     return NodeShape.ELLIPSE;
/*     */   }
/*     */ 
/*     */   
/*     */   public Type getResultVectorType() {
/* 169 */     return Type.getType(DoubleArrayVector.class);
/*     */   }
/*     */   
/*     */   public void startCompilation(LoopKernelCache loopKernelCache) {
/* 173 */     this.compiledKernel = loopKernelCache.get(this.kernel, this.kernelOperands);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void run() {
/*     */     CompiledKernel kernel;
/*     */     try {
/* 181 */       kernel = this.compiledKernel.get();
/* 182 */     } catch (InterruptedException|java.util.concurrent.ExecutionException e) {
/* 183 */       throw new EvalException("Exception compiling kernel", e);
/*     */     } 
/*     */     
/* 186 */     Vector[] vectorOperands = new Vector[getOperands().size()];
/* 187 */     for (int i = 0; i < vectorOperands.length; i++) {
/* 188 */       vectorOperands[i] = getOperand(i).getVector();
/*     */     }
/*     */     
/* 191 */     double[] result = kernel.compute(vectorOperands);
/*     */     
/* 193 */     this.resultVector = DoubleArrayVector.unsafe(result, this.memoizedComputation.getAttributes());
/*     */     
/* 195 */     this.memoizedComputation.setResult((Vector)this.resultVector);
/*     */   }
/*     */   
/*     */   public DoubleArrayVector getVector() {
/* 199 */     if (this.resultVector == null) {
/* 200 */       throw new IllegalStateException("Not computed yet.");
/*     */     }
/* 202 */     return this.resultVector;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/pipeliner/fusion/FusedNode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */