package org.renjin.invoke.annotations;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Documented
@Retention(RetentionPolicy.RUNTIME)
public @interface Generic {
  boolean S3() default true;
  
  boolean S4() default true;
  
  boolean dispatchOnAllArguments() default false;
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/annotations/Generic.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */