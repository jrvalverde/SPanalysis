/*     */ package org.renjin.pipeliner.fusion.node;
/*     */ 
/*     */ import java.util.Optional;
/*     */ import org.renjin.pipeliner.ComputeMethod;
/*     */ import org.renjin.repackaged.asm.Label;
/*     */ import org.renjin.repackaged.asm.MethodVisitor;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class LoopNode
/*     */ {
/*     */   public abstract void init(ComputeMethod paramComputeMethod);
/*     */   
/*     */   public final void pushElementAsDouble(ComputeMethod method) {
/*  41 */     pushElementAsDouble(method, Optional.empty());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void pushElementAsDouble(ComputeMethod paramComputeMethod, Optional<Label> paramOptional);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void pushLength(ComputeMethod paramComputeMethod);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void pushIntConstant(MethodVisitor mv, int value) {
/*  59 */     if (value == 0) {
/*  60 */       mv.visitInsn(3);
/*  61 */     } else if (value == 1) {
/*  62 */       mv.visitInsn(4);
/*  63 */     } else if (value == 2) {
/*  64 */       mv.visitInsn(5);
/*  65 */     } else if (value == 3) {
/*  66 */       mv.visitInsn(6);
/*  67 */     } else if (value == 4) {
/*  68 */       mv.visitInsn(7);
/*  69 */     } else if (value == 5) {
/*  70 */       mv.visitInsn(8);
/*  71 */     } else if (value < 127) {
/*  72 */       mv.visitIntInsn(16, value);
/*     */     } else {
/*  74 */       mv.visitLdcInsn(Integer.valueOf(value));
/*     */     } 
/*     */   }
/*     */   
/*     */   protected final void cast(MethodVisitor mv, Type fromType, Type toType) {
/*  79 */     if (fromType.equals(toType)) {
/*     */       return;
/*     */     }
/*  82 */     if (fromType.getSort() == 5 && 
/*  83 */       toType.getSort() == 8) {
/*  84 */       mv.visitInsn(135);
/*     */       
/*     */       return;
/*     */     } 
/*  88 */     if (fromType.getSort() == 8 && 
/*  89 */       toType.getSort() == 5) {
/*  90 */       mv.visitInsn(142);
/*     */       
/*     */       return;
/*     */     } 
/*  94 */     throw new UnsupportedOperationException("Cast from " + fromType + " to " + toType);
/*     */   }
/*     */ 
/*     */   
/*     */   protected final void cast(MethodVisitor mv, Class<?> fromType, Class<?> toType) {
/*  99 */     if (fromType.equals(toType)) {
/*     */       return;
/*     */     }
/* 102 */     if (fromType.equals(int.class) && 
/* 103 */       toType.equals(double.class)) {
/* 104 */       mv.visitInsn(135);
/*     */       
/*     */       return;
/*     */     } 
/* 108 */     if (fromType.equals(double.class) && 
/* 109 */       toType.equals(int.class)) {
/* 110 */       mv.visitInsn(142);
/*     */       
/*     */       return;
/*     */     } 
/* 114 */     throw new UnsupportedOperationException("Cast from " + fromType + " to " + toType);
/*     */   }
/*     */ 
/*     */   
/*     */   protected static boolean supportedType(Class<?> type) {
/* 119 */     return (type.equals(double.class) || type
/* 120 */       .equals(int.class));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void pushElementAsInt(ComputeMethod method, int index) {
/* 130 */     MethodVisitor mv = method.getVisitor();
/* 131 */     pushIntConstant(mv, index);
/* 132 */     pushElementAsInt(method, Optional.empty());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void pushElementAsInt(ComputeMethod method, Optional<Label> naLabel) {
/* 143 */     pushElementAsDouble(method);
/* 144 */     method.getVisitor().visitInsn(142);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void doIntegerNaCheck(MethodVisitor mv, Optional<Label> naLabel) {
/* 152 */     if (naLabel.isPresent()) {
/*     */       
/* 154 */       mv.visitInsn(89);
/*     */       
/* 156 */       mv.visitFieldInsn(178, "org/renjin/sexp/IntVector", "NA", "I");
/*     */       
/* 158 */       mv.visitJumpInsn(159, naLabel.get());
/*     */     } 
/*     */   }
/*     */   
/*     */   public abstract boolean mustCheckForIntegerNAs();
/*     */   
/*     */   public abstract void appendToKey(StringBuilder paramStringBuilder);
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/pipeliner/fusion/node/LoopNode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */