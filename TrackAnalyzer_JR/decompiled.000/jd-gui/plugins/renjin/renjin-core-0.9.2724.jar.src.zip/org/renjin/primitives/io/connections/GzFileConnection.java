/*    */ package org.renjin.primitives.io.connections;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ import java.nio.charset.Charset;
/*    */ import java.util.zip.GZIPOutputStream;
/*    */ import org.apache.commons.vfs2.FileObject;
/*    */ import org.renjin.repackaged.guava.base.Charsets;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GzFileConnection
/*    */   extends FileConnection
/*    */ {
/*    */   public static final int GZIP_MAGIC_BYTE1 = 31;
/*    */   public static final int GZIP_MAGIC_BYTE2 = 139;
/*    */   
/*    */   public GzFileConnection(FileObject file, Charset charset) throws IOException {
/* 44 */     super(file, charset);
/*    */   }
/*    */   
/*    */   public GzFileConnection(FileObject file) throws IOException {
/* 48 */     this(file, Charsets.UTF_8);
/*    */   }
/*    */ 
/*    */   
/*    */   protected OutputStream doOpenForOutput() throws IOException {
/* 53 */     return new GZIPOutputStream(super.doOpenForOutput());
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/io/connections/GzFileConnection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */