/*    */ package org.renjin.compiler.ir.tac.expressions;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.renjin.compiler.codegen.EmitContext;
/*    */ import org.renjin.compiler.ir.ValueBounds;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ import org.renjin.repackaged.asm.commons.InstructionAdapter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CmpGE
/*    */   extends SpecializedCallExpression
/*    */ {
/*    */   public CmpGE(Expression op1, Expression op2) {
/* 35 */     super(new Expression[] { op1, op2 });
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 40 */     return this.arguments[0] + " >= " + this.arguments[1];
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isFunctionDefinitelyPure() {
/* 45 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isPure() {
/* 50 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public int load(EmitContext emitContext, InstructionAdapter mv) {
/* 55 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   
/*    */   public Type getType() {
/* 60 */     return Type.BOOLEAN_TYPE;
/*    */   }
/*    */ 
/*    */   
/*    */   public ValueBounds updateTypeBounds(Map<Expression, ValueBounds> typeMap) {
/* 65 */     return getValueBounds();
/*    */   }
/*    */ 
/*    */   
/*    */   public ValueBounds getValueBounds() {
/* 70 */     return ValueBounds.LOGICAL_PRIMITIVE;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/ir/tac/expressions/CmpGE.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */