/*     */ package org.renjin.primitives.packaging;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.apache.commons.vfs2.FileObject;
/*     */ import org.apache.commons.vfs2.FileSystemException;
/*     */ import org.apache.commons.vfs2.FileSystemManager;
/*     */ import org.renjin.eval.Context;
/*     */ import org.renjin.eval.EvalException;
/*     */ import org.renjin.sexp.NamedValue;
/*     */ import org.renjin.sexp.Null;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.util.NamedByteSource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Package
/*     */ {
/*     */   private final FqPackageName name;
/*     */   
/*     */   protected Package(FqPackageName name) {
/*  41 */     this.name = name;
/*     */   }
/*     */   
/*     */   public final FqPackageName getName() {
/*  45 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterable<NamedValue> loadSymbols(Context context) throws IOException {
/*  56 */     return Collections.emptySet();
/*     */   }
/*     */ 
/*     */   
/*     */   public NamedByteSource getResource(String name) throws IOException {
/*  61 */     throw new IOException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Dataset> getDatasets() {
/*  68 */     return Collections.emptyList();
/*     */   }
/*     */   
/*     */   public SEXP getDataset(String datasetName) throws IOException {
/*  72 */     for (Dataset dataset : getDatasets()) {
/*  73 */       if (dataset.getName().equals(datasetName)) {
/*  74 */         return (SEXP)dataset.loadAll();
/*     */       }
/*     */     } 
/*  77 */     return (SEXP)Null.INSTANCE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract Class loadClass(String paramString) throws ClassNotFoundException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<String> getPackageDependencies() throws IOException {
/*  96 */     return Collections.emptyList();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FileObject resolvePackageRoot(FileSystemManager fileSystemManager) throws FileSystemException {
/* 104 */     throw new EvalException("Cannot access package root", new Object[0]);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/packaging/Package.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */