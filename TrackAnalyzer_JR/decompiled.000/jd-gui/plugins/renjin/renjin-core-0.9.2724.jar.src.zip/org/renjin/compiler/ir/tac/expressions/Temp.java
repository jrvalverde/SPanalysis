/*    */ package org.renjin.compiler.ir.tac.expressions;
/*    */ 
/*    */ import org.renjin.compiler.ir.IRFormatting;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Temp
/*    */   extends LValue
/*    */ {
/*    */   private static final String TAO = "τ";
/*    */   private final int index;
/*    */   
/*    */   public Temp(int index) {
/* 36 */     this.index = index;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 41 */     StringBuilder sb = new StringBuilder("τ");
/* 42 */     IRFormatting.appendSubscript(sb, this.index + 1);
/* 43 */     return sb.toString();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isPure() {
/* 48 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 53 */     return this.index;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 58 */     if (this == obj) {
/* 59 */       return true;
/*    */     }
/* 61 */     if (obj == null) {
/* 62 */       return false;
/*    */     }
/* 64 */     if (getClass() != obj.getClass()) {
/* 65 */       return false;
/*    */     }
/* 67 */     Temp other = (Temp)obj;
/* 68 */     return (this.index == other.index);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/ir/tac/expressions/Temp.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */