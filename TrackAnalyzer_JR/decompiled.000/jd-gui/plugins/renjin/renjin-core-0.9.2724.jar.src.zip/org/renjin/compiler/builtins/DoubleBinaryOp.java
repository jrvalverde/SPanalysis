/*    */ package org.renjin.compiler.builtins;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.renjin.compiler.codegen.EmitContext;
/*    */ import org.renjin.compiler.ir.ValueBounds;
/*    */ import org.renjin.compiler.ir.tac.IRArgument;
/*    */ import org.renjin.compiler.ir.tac.expressions.Expression;
/*    */ import org.renjin.invoke.model.JvmMethod;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ import org.renjin.repackaged.asm.commons.InstructionAdapter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DoubleBinaryOp
/*    */   implements Specialization
/*    */ {
/*    */   private int opcode;
/*    */   private ValueBounds valueBounds;
/*    */   
/*    */   public DoubleBinaryOp(int opcode, ValueBounds valueBounds) {
/* 42 */     this.opcode = opcode;
/* 43 */     this.valueBounds = valueBounds;
/*    */   }
/*    */ 
/*    */   
/*    */   public Type getType() {
/* 48 */     return Type.DOUBLE_TYPE;
/*    */   }
/*    */   
/*    */   public ValueBounds getResultBounds() {
/* 52 */     return this.valueBounds;
/*    */   }
/*    */ 
/*    */   
/*    */   public void load(EmitContext emitContext, InstructionAdapter mv, List<IRArgument> arguments) {
/* 57 */     assert arguments.size() == 2;
/* 58 */     Expression x = ((IRArgument)arguments.get(0)).getExpression();
/* 59 */     Expression y = ((IRArgument)arguments.get(1)).getExpression();
/*    */     
/* 61 */     x.load(emitContext, mv);
/* 62 */     emitContext.convert(mv, x.getType(), Type.DOUBLE_TYPE);
/*    */     
/* 64 */     y.load(emitContext, mv);
/* 65 */     emitContext.convert(mv, y.getType(), Type.DOUBLE_TYPE);
/*    */     
/* 67 */     mv.visitInsn(this.opcode);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isPure() {
/* 72 */     return true;
/*    */   }
/*    */   
/*    */   public static DoubleBinaryOp trySpecialize(String name, JvmMethod overload, ValueBounds resultBounds) {
/* 76 */     List<JvmMethod.Argument> formals = overload.getPositionalFormals();
/* 77 */     if (formals.size() == 2 && ((JvmMethod.Argument)formals
/* 78 */       .get(0)).getClazz().equals(double.class) && ((JvmMethod.Argument)formals
/* 79 */       .get(1)).getClazz().equals(double.class))
/*    */     {
/* 81 */       switch (name) {
/*    */         case "+":
/* 83 */           return new DoubleBinaryOp(99, resultBounds);
/*    */         case "-":
/* 85 */           return new DoubleBinaryOp(103, resultBounds);
/*    */         case "*":
/* 87 */           return new DoubleBinaryOp(107, resultBounds);
/*    */         case "/":
/* 89 */           return new DoubleBinaryOp(111, resultBounds);
/*    */       } 
/*    */     }
/* 92 */     return null;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/builtins/DoubleBinaryOp.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */