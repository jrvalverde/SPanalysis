/*     */ package org.renjin.compiler.builtins;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.renjin.compiler.codegen.ConstantBytecode;
/*     */ import org.renjin.compiler.codegen.EmitContext;
/*     */ import org.renjin.compiler.ir.ValueBounds;
/*     */ import org.renjin.compiler.ir.tac.IRArgument;
/*     */ import org.renjin.invoke.model.JvmMethod;
/*     */ import org.renjin.invoke.reflection.converters.Converters;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ import org.renjin.repackaged.asm.commons.InstructionAdapter;
/*     */ import org.renjin.sexp.DoubleVector;
/*     */ import org.renjin.sexp.IntVector;
/*     */ import org.renjin.sexp.ListVector;
/*     */ import org.renjin.sexp.LogicalVector;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.StringVector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConstantCall
/*     */   implements Specialization
/*     */ {
/*     */   private Object constantValue;
/*     */   private Type type;
/*     */   private ValueBounds valueBounds;
/*     */   
/*     */   public ConstantCall(Object constantValue) {
/*  45 */     this.constantValue = constantValue;
/*     */     
/*  47 */     if (constantValue instanceof Integer) {
/*  48 */       this.type = Type.INT_TYPE;
/*  49 */       this.valueBounds = ValueBounds.of((SEXP)IntVector.valueOf(((Integer)constantValue).intValue()));
/*     */     }
/*  51 */     else if (constantValue instanceof Double) {
/*  52 */       this.type = Type.DOUBLE_TYPE;
/*  53 */       this.valueBounds = ValueBounds.of((SEXP)DoubleVector.valueOf(((Double)constantValue).doubleValue()));
/*     */     }
/*  55 */     else if (constantValue instanceof Boolean) {
/*  56 */       this.type = Type.BOOLEAN_TYPE;
/*  57 */       this.valueBounds = ValueBounds.of(LogicalVector.valueOf(((Boolean)constantValue).booleanValue()));
/*     */     }
/*  59 */     else if (constantValue instanceof String) {
/*  60 */       this.type = Type.getType(String.class);
/*  61 */       this.valueBounds = ValueBounds.of((SEXP)StringVector.valueOf((String)constantValue));
/*     */     }
/*  63 */     else if (constantValue instanceof SEXP) {
/*  64 */       this.type = Type.getType(constantValue.getClass());
/*  65 */       this.valueBounds = ValueBounds.of((SEXP)constantValue);
/*     */     } else {
/*     */       
/*  68 */       throw new UnsupportedOperationException("constantValue: " + constantValue);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Type getType() {
/*  74 */     return this.type;
/*     */   }
/*     */   
/*     */   public ValueBounds getResultBounds() {
/*  78 */     return this.valueBounds;
/*     */   }
/*     */ 
/*     */   
/*     */   public void load(EmitContext emitContext, InstructionAdapter mv, List<IRArgument> arguments) {
/*  83 */     if (this.constantValue instanceof Integer) {
/*  84 */       mv.iconst(((Integer)this.constantValue).intValue());
/*  85 */     } else if (this.constantValue instanceof Double) {
/*  86 */       mv.dconst(((Double)this.constantValue).doubleValue());
/*  87 */     } else if (this.constantValue instanceof Boolean) {
/*  88 */       mv.iconst((this.constantValue == Boolean.TRUE) ? 1 : 0);
/*  89 */     } else if (this.constantValue instanceof SEXP) {
/*  90 */       ConstantBytecode.pushConstant(mv, (SEXP)this.constantValue);
/*     */     } else {
/*  92 */       throw new UnsupportedOperationException("constantValue: " + this.constantValue.getClass());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPure() {
/*  98 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public static ConstantCall evaluate(JvmMethod method, List<ValueBounds> arguments) {
/*     */     Object constantValue;
/* 104 */     ListVector.Builder varArgs = null;
/* 105 */     Map<String, Object> namedFlags = null;
/*     */     
/* 107 */     if (method.acceptsArgumentList()) {
/* 108 */       namedFlags = new HashMap<>();
/* 109 */       varArgs = ListVector.newBuilder();
/* 110 */       for (JvmMethod.Argument formal : method.getFormals()) {
/* 111 */         if (formal.isNamedFlag()) {
/* 112 */           namedFlags.put(formal.getName(), Boolean.valueOf(formal.getDefaultValue()));
/*     */         }
/*     */       } 
/* 115 */       for (ValueBounds argument : arguments) {
/* 116 */         varArgs.add(argument.getConstantValue());
/*     */       }
/*     */     } 
/*     */     
/* 120 */     List<JvmMethod.Argument> formals = method.getAllArguments();
/* 121 */     Object[] args = new Object[formals.size()];
/* 122 */     Iterator<ValueBounds> it = arguments.iterator();
/* 123 */     int argI = 0;
/* 124 */     for (JvmMethod.Argument formal : formals) {
/* 125 */       if (formal.isVarArg()) {
/* 126 */         args[argI++] = varArgs.build(); continue;
/* 127 */       }  if (formal.isNamedFlag()) {
/* 128 */         args[argI++] = namedFlags.get(formal.getName()); continue;
/* 129 */       }  if (formal.isContextual()) {
/* 130 */         throw new UnsupportedOperationException("in " + method + ", formal: " + formal);
/*     */       }
/* 132 */       ValueBounds argument = it.next();
/* 133 */       Class formalType = formal.getClazz();
/* 134 */       args[argI++] = convert(argument.getConstantValue(), formalType);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 140 */       constantValue = method.getMethod().invoke(null, args);
/* 141 */     } catch (Exception e) {
/* 142 */       throw new RuntimeException(e);
/*     */     } 
/*     */     
/* 145 */     return new ConstantCall(constantValue);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Object convert(SEXP constantValue, Class formalType) {
/* 150 */     return Converters.get(formalType).convertToJava(constantValue);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/builtins/ConstantCall.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */