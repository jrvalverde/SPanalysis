/*    */ package org.renjin.primitives.sequence;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import org.renjin.primitives.vector.DeferredComputation;
/*    */ import org.renjin.sexp.AttributeMap;
/*    */ import org.renjin.sexp.DoubleArrayVector;
/*    */ import org.renjin.sexp.DoubleVector;
/*    */ import org.renjin.sexp.IntArrayVector;
/*    */ import org.renjin.sexp.SEXP;
/*    */ import org.renjin.sexp.Vector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RepDoubleVector
/*    */   extends DoubleVector
/*    */   implements DeferredComputation
/*    */ {
/*    */   public static final int LENGTH_THRESHOLD = 100;
/*    */   private final Vector source;
/*    */   private int length;
/*    */   private int each;
/*    */   
/*    */   public RepDoubleVector(Vector source, int length, int each, AttributeMap attributes) {
/* 36 */     super(attributes);
/* 37 */     this.source = source;
/* 38 */     this.length = length;
/* 39 */     this.each = each;
/* 40 */     if (this.length <= 0) {
/* 41 */       throw new IllegalArgumentException("length: " + length);
/*    */     }
/*    */   }
/*    */   
/*    */   private RepDoubleVector(double constant, int length) {
/* 46 */     super(AttributeMap.EMPTY);
/* 47 */     this.source = (Vector)DoubleVector.valueOf(constant);
/* 48 */     this.length = length;
/* 49 */     this.each = 1;
/*    */   }
/*    */   
/*    */   public static DoubleVector createConstantVector(double constant, int length) {
/* 53 */     if (length <= 0) {
/* 54 */       return (DoubleVector)DoubleArrayVector.EMPTY;
/*    */     }
/* 56 */     if (length < 100) {
/* 57 */       double[] array = new double[length];
/* 58 */       Arrays.fill(array, constant);
/* 59 */       return (DoubleVector)new DoubleArrayVector(array);
/*    */     } 
/*    */     
/* 62 */     return new RepDoubleVector(constant, length);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected SEXP cloneWithNewAttributes(AttributeMap attributes) {
/* 68 */     return (SEXP)new RepDoubleVector(this.source, this.length, this.each, attributes);
/*    */   }
/*    */ 
/*    */   
/*    */   public double getElementAsDouble(int index) {
/* 73 */     return this.source.getElementAsDouble(index / this.each % this.source.length());
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isConstantAccessTime() {
/* 78 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isDeferred() {
/* 83 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public int length() {
/* 88 */     return this.length;
/*    */   }
/*    */ 
/*    */   
/*    */   public Vector[] getOperands() {
/* 93 */     return new Vector[] { this.source, (Vector)new IntArrayVector(new int[] { this.length / this.each / this.source.length() }), (Vector)new IntArrayVector(new int[] { this.each }) };
/*    */   }
/*    */ 
/*    */   
/*    */   public String getComputationName() {
/* 98 */     return "rep";
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/sequence/RepDoubleVector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */