/*    */ package org.renjin.primitives.special;
/*    */ 
/*    */ import org.renjin.eval.Context;
/*    */ import org.renjin.sexp.Environment;
/*    */ import org.renjin.sexp.FunctionCall;
/*    */ import org.renjin.sexp.Null;
/*    */ import org.renjin.sexp.PairList;
/*    */ import org.renjin.sexp.SEXP;
/*    */ import org.renjin.sexp.SpecialFunction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IfFunction
/*    */   extends SpecialFunction
/*    */ {
/*    */   public IfFunction() {
/* 27 */     super("if");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public SEXP apply(Context context, Environment rho, FunctionCall call, PairList args) {
/* 33 */     SEXP condition = context.materialize(context
/* 34 */         .evaluate(call.getArguments().getElementAsSEXP(0), rho));
/*    */ 
/*    */     
/* 37 */     condition = context.materialize(condition);
/*    */     
/* 39 */     if (asLogicalNoNA(context, call, condition)) {
/* 40 */       return context.evaluate(call.getArguments().getElementAsSEXP(1), rho);
/*    */     }
/*    */     
/* 43 */     if (call.getArguments().length() == 3) {
/* 44 */       return context.evaluate(call.getArguments().getElementAsSEXP(2), rho);
/*    */     }
/* 46 */     context.setInvisibleFlag();
/* 47 */     return (SEXP)Null.INSTANCE;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/special/IfFunction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */