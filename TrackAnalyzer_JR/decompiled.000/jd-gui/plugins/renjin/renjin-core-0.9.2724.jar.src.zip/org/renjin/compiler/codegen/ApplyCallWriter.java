/*     */ package org.renjin.compiler.codegen;
/*     */ 
/*     */ import java.io.PrintWriter;
/*     */ import org.renjin.compiler.CompiledLoopBody;
/*     */ import org.renjin.compiler.JitClassLoader;
/*     */ import org.renjin.compiler.cfg.InlinedFunction;
/*     */ import org.renjin.compiler.ir.ValueBounds;
/*     */ import org.renjin.primitives.vector.DeferredComputation;
/*     */ import org.renjin.primitives.vector.MemoizedComputation;
/*     */ import org.renjin.repackaged.asm.ClassVisitor;
/*     */ import org.renjin.repackaged.asm.ClassWriter;
/*     */ import org.renjin.repackaged.asm.MethodVisitor;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ import org.renjin.repackaged.asm.commons.InstructionAdapter;
/*     */ import org.renjin.repackaged.asm.util.TraceClassVisitor;
/*     */ import org.renjin.sexp.AttributeMap;
/*     */ import org.renjin.sexp.DoubleVector;
/*     */ import org.renjin.sexp.Symbol;
/*     */ import org.renjin.sexp.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ApplyCallWriter
/*     */ {
/*  45 */   private static final Type ATTRIBUTE_MAP_TYPE = Type.getType(AttributeMap.class);
/*  46 */   private static final Type VECTOR_TYPE = Type.getType(Vector.class);
/*     */   
/*     */   private ClassWriter cw;
/*     */   
/*     */   private ClassVisitor cv;
/*     */   private Type thisClass;
/*     */   private Type superClass;
/*     */   private InlinedFunction function;
/*     */   private Symbol elementFormalName;
/*     */   private ValueBounds elementBounds;
/*     */   private ValueBounds resultBounds;
/*     */   private final int uniqueId;
/*     */   
/*     */   public ApplyCallWriter(InlinedFunction function, Symbol elementFormalName, ValueBounds elementBounds, ValueBounds resultBounds) {
/*  60 */     this.function = function;
/*  61 */     this.elementFormalName = elementFormalName;
/*  62 */     this.elementBounds = elementBounds;
/*  63 */     this.resultBounds = resultBounds;
/*     */     
/*  65 */     this.uniqueId = System.identityHashCode(this);
/*  66 */     this.thisClass = Type.getType("org/renjin/DeferredApply" + this.uniqueId);
/*  67 */     this.superClass = Type.getType(DoubleVector.class);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> build() {
/*  73 */     startClass();
/*  74 */     writeVectorField();
/*  75 */     writeConstructor();
/*     */     
/*  77 */     writeApplyImpl();
/*  78 */     writeGetElementImpl();
/*  79 */     writeLengthImpl();
/*  80 */     writeIsConstantAccessTimeImpl();
/*  81 */     writeGetOperandsImpl();
/*  82 */     writeGetComputationNameImpl();
/*     */     
/*  84 */     writeClassEnd();
/*     */     
/*  86 */     return JitClassLoader.defineClass(CompiledLoopBody.class, this.thisClass.getInternalName().replace('/', '.'), this.cw.toByteArray());
/*     */   }
/*     */ 
/*     */   
/*     */   private void startClass() {
/*  91 */     this.cw = new ClassWriter(2);
/*  92 */     this.cv = (ClassVisitor)new TraceClassVisitor((ClassVisitor)this.cw, new PrintWriter(System.out));
/*  93 */     this.cv.visit(50, 33, this.thisClass.getInternalName(), null, this.superClass
/*  94 */         .getInternalName(), new String[] { Type.getInternalName(MemoizedComputation.class) });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeVectorField() {
/* 102 */     this.cv.visitField(2, "vector", Type.getDescriptor(Vector.class), null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeConstructor() {
/* 110 */     MethodVisitor mv = this.cv.visitMethod(1, "<init>", 
/* 111 */         Type.getMethodDescriptor(Type.VOID_TYPE, new Type[] { VECTOR_TYPE, ATTRIBUTE_MAP_TYPE }), null, null);
/* 112 */     mv.visitCode();
/* 113 */     mv.visitVarInsn(25, 0);
/* 114 */     mv.visitVarInsn(25, 2);
/* 115 */     mv.visitMethodInsn(183, this.superClass.getInternalName(), "<init>", 
/* 116 */         Type.getMethodDescriptor(Type.VOID_TYPE, new Type[] { ATTRIBUTE_MAP_TYPE }), false);
/*     */ 
/*     */     
/* 119 */     mv.visitVarInsn(25, 0);
/* 120 */     mv.visitVarInsn(25, 1);
/* 121 */     mv.visitFieldInsn(181, this.thisClass.getInternalName(), "vector", VECTOR_TYPE.getDescriptor());
/*     */     
/* 123 */     mv.visitInsn(177);
/* 124 */     mv.visitMaxs(2, 3);
/* 125 */     mv.visitEnd();
/*     */   }
/*     */   
/*     */   private void writeGetOperandsImpl() {
/* 129 */     MethodVisitor mv = this.cv.visitMethod(1, "getOperands", "()[Lorg/renjin/sexp/Vector;", null, null);
/* 130 */     mv.visitCode();
/* 131 */     mv.visitInsn(4);
/* 132 */     mv.visitTypeInsn(189, Type.getInternalName(Vector.class));
/* 133 */     mv.visitInsn(89);
/* 134 */     mv.visitInsn(3);
/* 135 */     mv.visitVarInsn(25, 0);
/* 136 */     mv.visitFieldInsn(180, this.thisClass.getInternalName(), "vector", VECTOR_TYPE.getDescriptor());
/* 137 */     mv.visitInsn(83);
/* 138 */     mv.visitInsn(176);
/* 139 */     mv.visitMaxs(3, 1);
/* 140 */     mv.visitEnd();
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeLengthImpl() {
/* 145 */     MethodVisitor mv = this.cv.visitMethod(1, "length", "()I", null, null);
/* 146 */     mv.visitCode();
/* 147 */     mv.visitVarInsn(25, 0);
/* 148 */     mv.visitFieldInsn(180, this.thisClass.getInternalName(), "vector", VECTOR_TYPE.getDescriptor());
/* 149 */     mv.visitMethodInsn(185, "org/renjin/sexp/SEXP", "length", "()I", true);
/* 150 */     mv.visitInsn(172);
/* 151 */     mv.visitMaxs(3, 1);
/* 152 */     mv.visitEnd();
/*     */   }
/*     */   
/*     */   private void writeApplyImpl() {
/* 156 */     MethodVisitor mv = this.cv.visitMethod(9, "apply", applySignature(), null, null);
/* 157 */     mv.visitCode();
/*     */     
/* 159 */     VariableSlots slots = new VariableSlots(this.elementBounds.storageType().getSize(), this.function.getTypes());
/* 160 */     ApplyMethodContext emitContext = new ApplyMethodContext(this.function.getCfg(), this.elementFormalName, this.elementBounds.storageType(), slots);
/*     */     
/* 162 */     this.function.write(emitContext, new InstructionAdapter(mv));
/*     */     
/* 164 */     mv.visitMaxs(3, 1);
/* 165 */     mv.visitEnd();
/*     */   }
/*     */   
/*     */   private String applySignature() {
/* 169 */     return Type.getMethodDescriptor(this.resultBounds.storageType(), new Type[] { this.elementBounds.storageType() });
/*     */   }
/*     */   
/*     */   private void writeGetElementImpl() {
/* 173 */     MethodVisitor mv = this.cv.visitMethod(1, "getElementAsDouble", "(I)D", null, null);
/* 174 */     mv.visitCode();
/* 175 */     mv.visitVarInsn(25, 0);
/* 176 */     mv.visitFieldInsn(180, this.thisClass.getInternalName(), "vector", VECTOR_TYPE.getDescriptor());
/* 177 */     mv.visitVarInsn(21, 1);
/* 178 */     mv.visitMethodInsn(185, VECTOR_TYPE.getInternalName(), "getElementAsInt", "(I)I", true);
/* 179 */     mv.visitMethodInsn(184, this.thisClass.getInternalName(), "apply", applySignature(), false);
/* 180 */     mv.visitInsn(175);
/* 181 */     mv.visitMaxs(4, 2);
/*     */   }
/*     */   
/*     */   private void writeIsConstantAccessTimeImpl() {
/* 185 */     MethodVisitor mv = this.cv.visitMethod(1, "isConstantAccessTime", "()Z", null, null);
/* 186 */     mv.visitCode();
/* 187 */     mv.visitVarInsn(25, 0);
/* 188 */     mv.visitFieldInsn(180, this.thisClass.getInternalName(), "vector", VECTOR_TYPE.getDescriptor());
/* 189 */     mv.visitMethodInsn(185, Type.getInternalName(DeferredComputation.class), "isConstantAccessTime", "()Z", true);
/* 190 */     mv.visitInsn(172);
/* 191 */     mv.visitMaxs(3, 1);
/* 192 */     mv.visitEnd();
/*     */   }
/*     */   
/*     */   private void writeGetComputationNameImpl() {
/* 196 */     MethodVisitor mv = this.cv.visitMethod(1, "getComputationName", "()Ljava/lang/String;", null, null);
/* 197 */     mv.visitCode();
/* 198 */     mv.visitLdcInsn("apply" + this.uniqueId);
/* 199 */     mv.visitInsn(176);
/* 200 */     mv.visitMaxs(1, 1);
/* 201 */     mv.visitEnd();
/*     */   }
/*     */   
/*     */   private void writeClassEnd() {
/* 205 */     this.cv.visitEnd();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/codegen/ApplyCallWriter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */