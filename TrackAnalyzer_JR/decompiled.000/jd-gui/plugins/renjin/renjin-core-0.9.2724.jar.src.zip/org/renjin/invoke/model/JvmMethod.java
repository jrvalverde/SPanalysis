/*     */ package org.renjin.invoke.model;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.List;
/*     */ import java.util.stream.Collectors;
/*     */ import org.apache.commons.math.complex.Complex;
/*     */ import org.apache.commons.math.special.Gamma;
/*     */ import org.renjin.eval.EvalException;
/*     */ import org.renjin.invoke.annotations.ArgumentList;
/*     */ import org.renjin.invoke.annotations.Builtin;
/*     */ import org.renjin.invoke.annotations.Cast;
/*     */ import org.renjin.invoke.annotations.CastStyle;
/*     */ import org.renjin.invoke.annotations.DataParallel;
/*     */ import org.renjin.invoke.annotations.DefaultValue;
/*     */ import org.renjin.invoke.annotations.Deferrable;
/*     */ import org.renjin.invoke.annotations.Generic;
/*     */ import org.renjin.invoke.annotations.GroupGeneric;
/*     */ import org.renjin.invoke.annotations.Internal;
/*     */ import org.renjin.invoke.annotations.Invisible;
/*     */ import org.renjin.invoke.annotations.NamedFlag;
/*     */ import org.renjin.invoke.annotations.PreserveAttributeStyle;
/*     */ import org.renjin.invoke.annotations.Recycle;
/*     */ import org.renjin.repackaged.guava.collect.ImmutableList;
/*     */ import org.renjin.repackaged.guava.collect.Lists;
/*     */ import org.renjin.sexp.Logical;
/*     */ import org.renjin.sexp.Symbol;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JvmMethod
/*     */   implements Comparable<JvmMethod>
/*     */ {
/*     */   private Method method;
/*     */   private List<Argument> arguments;
/*     */   private List<Argument> formals;
/*     */   private boolean dataParallel;
/*     */   private boolean passNA;
/*  52 */   private static final Class[] ATOMIC_TYPES = new Class[] { boolean.class, Boolean.class, Logical.class, int.class, Integer.class, double.class, Double.class, Complex.class, String.class, Byte.class, byte.class };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JvmMethod(Method method) {
/*  66 */     this.method = method;
/*     */     
/*  68 */     ImmutableList.Builder<Argument> argumentsBuilder = ImmutableList.builder();
/*  69 */     for (int i = 0; i != (method.getParameterTypes()).length; i++) {
/*  70 */       argumentsBuilder.add(new Argument(method, i));
/*     */     }
/*  72 */     this.arguments = (List<Argument>)argumentsBuilder.build();
/*  73 */     this.formals = (List<Argument>)this.arguments.stream().filter(arg -> !arg.isContextual()).collect(Collectors.toList());
/*     */     
/*  75 */     DataParallel dpAnnotation = method.<DataParallel>getAnnotation(DataParallel.class);
/*     */ 
/*     */ 
/*     */     
/*  79 */     this
/*     */       
/*  81 */       .dataParallel = (dpAnnotation != null || method.getDeclaringClass().equals(Math.class) || method.getDeclaringClass().equals(Gamma.class));
/*     */     
/*  83 */     if (this.dataParallel) {
/*  84 */       this.passNA = (dpAnnotation != null && dpAnnotation.passNA());
/*     */ 
/*     */ 
/*     */       
/*  88 */       boolean implicitRecycling = isArgumentRecyclingImplicit();
/*  89 */       for (Argument arg : this.formals) {
/*  90 */         Recycle recycleAnnotation = arg.<Recycle>getAnnotation(Recycle.class);
/*  91 */         arg
/*  92 */           .recycle = (arg.isAtomicElementType() && (implicitRecycling || recycleAnnotation == null || recycleAnnotation.value()));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isArgumentRecyclingImplicit() {
/* 103 */     for (Argument formal : this.formals) {
/* 104 */       if (formal.getAnnotation(Recycle.class) != null) {
/* 105 */         return false;
/*     */       }
/*     */     } 
/* 108 */     return true;
/*     */   }
/*     */   
/*     */   public static List<JvmMethod> findOverloads(Class clazz, String name, String alias) {
/* 112 */     List<JvmMethod> methods = Lists.newArrayList();
/* 113 */     if (clazz != null) {
/* 114 */       for (Method method : clazz.getMethods()) {
/*     */         
/* 116 */         if (Modifier.isPublic(method.getModifiers()) && 
/* 117 */           Modifier.isStatic(method.getModifiers()) && (method
/* 118 */           .getName().equals(alias) || method
/* 119 */           .getName().equals(name) || 
/* 120 */           alias(method).equals(name)))
/*     */         {
/* 122 */           methods.add(new JvmMethod(method));
/*     */         }
/*     */       } 
/*     */     }
/* 126 */     validate(methods);
/* 127 */     return methods;
/*     */   }
/*     */   
/*     */   public static String alias(Method method) {
/* 131 */     Builtin builtin = method.<Builtin>getAnnotation(Builtin.class);
/* 132 */     if (builtin != null) {
/* 133 */       return builtin.value();
/*     */     }
/* 135 */     Internal internal = method.<Internal>getAnnotation(Internal.class);
/* 136 */     if (internal != null) {
/* 137 */       return internal.value();
/*     */     }
/* 139 */     return "";
/*     */   }
/*     */   
/*     */   public boolean acceptsArgumentList() {
/* 143 */     for (Argument formal : this.formals) {
/* 144 */       if (formal.isAnnotatedWith((Class)ArgumentList.class)) {
/* 145 */         return true;
/*     */       }
/*     */     } 
/* 148 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isDataParallel() {
/* 152 */     return this.dataParallel;
/*     */   }
/*     */   
/*     */   public boolean isStrict() {
/* 156 */     for (Argument formal : getFormals()) {
/* 157 */       if (!formal.isEvaluated() && !formal.isSymbol()) {
/* 158 */         return false;
/*     */       }
/*     */     } 
/* 161 */     return true;
/*     */   }
/*     */   
/*     */   public boolean isGeneric() {
/* 165 */     return (this.method.getAnnotation(Generic.class) != null || this.method
/* 166 */       .getDeclaringClass().getAnnotation(GroupGeneric.class) != null);
/*     */   }
/*     */   
/*     */   public boolean isGroupGeneric() {
/* 170 */     return (this.method.getDeclaringClass().getAnnotation(GroupGeneric.class) != null || this.method
/* 171 */       .getAnnotation(GroupGeneric.class) != null);
/*     */   }
/*     */   
/*     */   public String getGenericGroup() {
/* 175 */     GroupGeneric annotation = this.method.<GroupGeneric>getAnnotation(GroupGeneric.class);
/* 176 */     if (annotation == null) {
/* 177 */       annotation = this.method.getDeclaringClass().<GroupGeneric>getAnnotation(GroupGeneric.class);
/*     */     }
/* 179 */     if (annotation == null) {
/* 180 */       throw new IllegalStateException(getName() + " is not a @GroupGeneric");
/*     */     }
/* 182 */     if (!annotation.value().isEmpty()) {
/* 183 */       return annotation.value();
/*     */     }
/* 185 */     return this.method.getDeclaringClass().getSimpleName();
/*     */   }
/*     */ 
/*     */   
/*     */   public PreserveAttributeStyle getPreserveAttributesStyle() {
/* 190 */     DataParallel annotation = this.method.<DataParallel>getAnnotation(DataParallel.class);
/* 191 */     return (annotation == null) ? PreserveAttributeStyle.STRUCTURAL : annotation.value();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getGenericName() {
/* 198 */     Builtin primitive = this.method.<Builtin>getAnnotation(Builtin.class);
/* 199 */     if (primitive != null && primitive.value() != null) {
/* 200 */       return primitive.value();
/*     */     }
/* 202 */     return this.method.getName();
/*     */   }
/*     */   
/*     */   public List<Argument> getAllArguments() {
/* 206 */     return this.arguments;
/*     */   }
/*     */   
/*     */   public Method getMethod() {
/* 210 */     return this.method;
/*     */   }
/*     */   
/*     */   public Class getDeclaringClass() {
/* 214 */     return this.method.getDeclaringClass();
/*     */   }
/*     */   
/*     */   public Class getReturnType() {
/* 218 */     return this.method.getReturnType();
/*     */   }
/*     */   
/*     */   public boolean returnsVoid() {
/* 222 */     return (this.method.getReturnType() == Void.class || this.method.getReturnType() == void.class);
/*     */   }
/*     */   
/*     */   public String getName() {
/* 226 */     return this.method.getName();
/*     */   }
/*     */   
/*     */   public int countPositionalFormals() {
/* 230 */     return getPositionalFormals().size();
/*     */   }
/*     */   
/*     */   public List<Argument> getPositionalFormals() {
/* 234 */     List<Argument> list = Lists.newArrayList();
/* 235 */     for (Argument formal : getFormals()) {
/* 236 */       if (formal.isAnnotatedWith((Class)ArgumentList.class) || formal
/* 237 */         .isAnnotatedWith((Class)NamedFlag.class)) {
/*     */         break;
/*     */       }
/* 240 */       list.add(formal);
/*     */     } 
/* 242 */     return list;
/*     */   }
/*     */   
/*     */   public void appendFriendlySignatureTo(StringBuilder sb) {
/* 246 */     appendFriendlySignatureTo(this.method.getName(), sb);
/*     */   }
/*     */ 
/*     */   
/*     */   public void appendFriendlySignatureTo(String name, StringBuilder sb) {
/* 251 */     sb.append(name).append("(");
/* 252 */     boolean needsComma = false;
/* 253 */     for (Argument argument : this.arguments) {
/* 254 */       if (!argument.isContextual()) {
/* 255 */         if (needsComma) {
/* 256 */           sb.append(", ");
/*     */         } else {
/* 258 */           needsComma = true;
/*     */         } 
/* 260 */         if (argument.isAnnotatedWith((Class)ArgumentList.class)) {
/* 261 */           sb.append("..."); continue;
/*     */         } 
/* 263 */         sb.append(FriendlyTypesNames.get().format(argument.getClazz()));
/* 264 */         if (!argument.isRecycle() && argument.isAtomicElementType()) {
/* 265 */           sb.append("(1)");
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 270 */     sb.append(")");
/*     */   }
/*     */   
/*     */   public List<Argument> getFormals() {
/* 274 */     return this.formals;
/*     */   }
/*     */   
/*     */   public boolean isHiddenBy(JvmMethod other) {
/* 278 */     if (this.formals.size() != other.getFormals().size()) {
/* 279 */       return false;
/*     */     }
/* 281 */     for (int i = 0; i != this.formals.size(); i++) {
/* 282 */       if (!((Argument)this.formals.get(i)).getClazz().isAssignableFrom(((Argument)other.getFormals().get(i)).getClazz())) {
/* 283 */         return false;
/*     */       }
/*     */     } 
/* 286 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int compareTo(JvmMethod o) {
/* 291 */     if (this.formals.size() != o.getFormals().size()) {
/* 292 */       return this.formals.size() - o.getFormals().size();
/*     */     }
/* 294 */     if (isHiddenBy(o))
/* 295 */       return -1; 
/* 296 */     if (o.isHiddenBy(this)) {
/* 297 */       return 1;
/*     */     }
/* 299 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 304 */     return this.method.toString();
/*     */   }
/*     */   
/*     */   public boolean isAnnotatedWith(Class<? extends Annotation> annotationClass) {
/* 308 */     return this.method.isAnnotationPresent(annotationClass);
/*     */   }
/*     */   
/*     */   public boolean isDeferrable() {
/* 312 */     return (isAnnotatedWith((Class)Deferrable.class) || this.method.getDeclaringClass().equals(Math.class));
/*     */   }
/*     */   public boolean isPassNA() {
/* 315 */     return this.passNA;
/*     */   }
/*     */   
/*     */   public boolean isInvisible() {
/* 319 */     return isAnnotatedWith((Class)Invisible.class);
/*     */   }
/*     */   
/*     */   public boolean isPure() {
/* 323 */     for (Argument argument : getAllArguments()) {
/* 324 */       if (argument.isContextual()) {
/* 325 */         return false;
/*     */       }
/*     */     } 
/* 328 */     return true;
/*     */   }
/*     */   
/*     */   public class Argument {
/*     */     private int index;
/*     */     private Class clazz;
/*     */     private boolean contextual = false;
/*     */     private boolean evaluated = true;
/*     */     private boolean symbol;
/*     */     private String name;
/*     */     public boolean recycle;
/*     */     public boolean atomicType;
/*     */     public boolean defaultValue;
/*     */     
/*     */     public Argument(Method method, int index) {
/* 343 */       this.clazz = method.getParameterTypes()[index];
/* 344 */       this.index = index;
/*     */       
/* 346 */       for (Annotation annotation : method.getParameterAnnotations()[index]) {
/* 347 */         if (annotation instanceof org.renjin.invoke.annotations.Current) {
/* 348 */           this.contextual = true;
/*     */         }
/* 350 */         else if (annotation instanceof org.renjin.invoke.annotations.Unevaluated) {
/* 351 */           this.evaluated = false;
/*     */         }
/* 353 */         else if (annotation instanceof NamedFlag) {
/* 354 */           this.name = ((NamedFlag)annotation).value();
/*     */         }
/* 356 */         else if (annotation instanceof DefaultValue) {
/* 357 */           this.defaultValue = ((DefaultValue)annotation).value();
/*     */         }
/* 359 */         else if (annotation instanceof org.renjin.invoke.annotations.InvokeAsCharacter) {
/* 360 */           this.evaluated = true;
/*     */         } 
/*     */       } 
/*     */       
/* 364 */       this.symbol = (this.clazz == Symbol.class);
/* 365 */       this.atomicType = JvmMethod.this.isAtomic(this.clazz);
/*     */     }
/*     */     
/*     */     public boolean isAnnotatedWith(Class<? extends Annotation> annotationClass) {
/* 369 */       for (Annotation annotation : JvmMethod.this.method.getParameterAnnotations()[this.index]) {
/* 370 */         if (annotation.annotationType() == annotationClass) {
/* 371 */           return true;
/*     */         }
/*     */       } 
/* 374 */       return false;
/*     */     }
/*     */     
/*     */     public <T extends Annotation> T getAnnotation(Class<T> annotationClass) {
/* 378 */       for (Annotation annotation : JvmMethod.this.method.getParameterAnnotations()[this.index]) {
/* 379 */         if (annotation.annotationType() == annotationClass) {
/* 380 */           return (T)annotation;
/*     */         }
/*     */       } 
/* 383 */       return null;
/*     */     }
/*     */     
/*     */     public Class getClazz() {
/* 387 */       return this.clazz;
/*     */     }
/*     */     
/*     */     public boolean isContextual() {
/* 391 */       return this.contextual;
/*     */     }
/*     */     
/*     */     public boolean isEvaluated() {
/* 395 */       return this.evaluated;
/*     */     }
/*     */     
/*     */     public boolean isSymbol() {
/* 399 */       return this.symbol;
/*     */     }
/*     */     
/*     */     public boolean isAtomicElementType() {
/* 403 */       return this.atomicType;
/*     */     }
/*     */     
/*     */     public boolean isRecycle() {
/* 407 */       return this.recycle;
/*     */     }
/*     */     
/*     */     public boolean hasName() {
/* 411 */       return (this.name != null);
/*     */     }
/*     */     
/*     */     public String getName() {
/* 415 */       return this.name;
/*     */     }
/*     */     
/*     */     public boolean getDefaultValue() {
/* 419 */       return this.defaultValue;
/*     */     }
/*     */     
/*     */     public int getIndex() {
/* 423 */       return this.index;
/*     */     }
/*     */     
/*     */     public boolean isVarArg() {
/* 427 */       return isAnnotatedWith((Class)ArgumentList.class);
/*     */     }
/*     */     
/*     */     public boolean isNamedFlag() {
/* 431 */       return isAnnotatedWith((Class)NamedFlag.class);
/*     */     }
/*     */     
/*     */     public CastStyle getCastStyle() {
/* 435 */       Cast cast = getAnnotation(Cast.class);
/* 436 */       if (cast == null) {
/* 437 */         return CastStyle.IMPLICIT;
/*     */       }
/* 439 */       return cast.value();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static void validate(List<JvmMethod> methods) {
/* 445 */     for (int i = 0; i != methods.size(); i++) {
/* 446 */       for (int j = 0; j != methods.size(); j++) {
/* 447 */         if (i != j) {
/* 448 */           JvmMethod x = methods.get(i);
/* 449 */           JvmMethod y = methods.get(j);
/*     */           
/* 451 */           if (x.isHiddenBy(y)) {
/* 452 */             throw new EvalException(formatHiddenMethod(x, y), new Object[0]);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private static String formatHiddenMethod(JvmMethod x, JvmMethod y) {
/* 460 */     StringBuilder sb = new StringBuilder();
/* 461 */     sb.append("Primitive method\n\t");
/* 462 */     x.appendFriendlySignatureTo(sb);
/* 463 */     sb.append("\nis hidden by\n\t");
/* 464 */     y.appendFriendlySignatureTo(sb);
/* 465 */     return sb.append("\n").toString();
/*     */   }
/*     */   
/*     */   private boolean isAtomic(Class clazz) {
/* 469 */     for (int i = 0; i != ATOMIC_TYPES.length; i++) {
/* 470 */       if (clazz.equals(ATOMIC_TYPES[i])) {
/* 471 */         return true;
/*     */       }
/*     */     } 
/* 474 */     return false;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/model/JvmMethod.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */