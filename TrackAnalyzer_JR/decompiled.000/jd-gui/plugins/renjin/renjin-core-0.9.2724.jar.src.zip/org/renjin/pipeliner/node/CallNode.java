/*    */ package org.renjin.pipeliner.node;
/*    */ 
/*    */ import org.renjin.primitives.ni.DeferredNativeCall;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ import org.renjin.sexp.Vector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CallNode
/*    */   extends DeferredNode
/*    */   implements Runnable
/*    */ {
/*    */   private DeferredNativeCall call;
/*    */   
/*    */   public CallNode(DeferredNativeCall call) {
/* 34 */     this.call = call;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getDebugLabel() {
/* 39 */     return this.call.getDebugName();
/*    */   }
/*    */ 
/*    */   
/*    */   public NodeShape getShape() {
/* 44 */     return NodeShape.ELLIPSE;
/*    */   }
/*    */ 
/*    */   
/*    */   public Type getResultVectorType() {
/* 49 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void run() {
/* 55 */     Vector[] inputs = new Vector[getOperands().size()];
/* 56 */     for (int i = 0; i < inputs.length; i++) {
/* 57 */       inputs[i] = getOperand(i).getVector();
/*    */     }
/*    */     
/* 60 */     this.call.evaluate(inputs);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/pipeliner/node/CallNode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */