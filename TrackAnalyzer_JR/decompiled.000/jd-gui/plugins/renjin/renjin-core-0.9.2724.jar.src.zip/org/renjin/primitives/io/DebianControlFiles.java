/*     */ package org.renjin.primitives.io;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.renjin.eval.Context;
/*     */ import org.renjin.eval.EvalException;
/*     */ import org.renjin.invoke.annotations.Current;
/*     */ import org.renjin.invoke.annotations.Internal;
/*     */ import org.renjin.primitives.io.connections.Connections;
/*     */ import org.renjin.primitives.io.connections.PushbackBufferedReader;
/*     */ import org.renjin.primitives.matrix.StringMatrixBuilder;
/*     */ import org.renjin.repackaged.guava.collect.Iterables;
/*     */ import org.renjin.repackaged.guava.collect.Lists;
/*     */ import org.renjin.repackaged.guava.collect.Maps;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DebianControlFiles
/*     */ {
/*     */   private static class Cell
/*     */   {
/*     */     private int row;
/*     */     private String field;
/*     */     
/*     */     public Cell(int row, String column) {
/*  53 */       this.row = row;
/*  54 */       this.field = column;
/*     */     }
/*     */     
/*     */     public int hashCode() {
/*  58 */       int prime = 31;
/*  59 */       int result = 1;
/*  60 */       result = 31 * result + this.field.hashCode();
/*  61 */       result = 31 * result + this.row;
/*  62 */       return result;
/*     */     }
/*     */     
/*     */     public boolean equals(Object obj) {
/*  66 */       if (this == obj) {
/*  67 */         return true;
/*     */       }
/*  69 */       if (obj == null) {
/*  70 */         return false;
/*     */       }
/*  72 */       if (getClass() != obj.getClass()) {
/*  73 */         return false;
/*     */       }
/*  75 */       Cell other = (Cell)obj;
/*  76 */       return (this.row == other.row && this.field.equals(other.field));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Internal
/*     */   public static SEXP readDCF(@Current Context context, SEXP conn, Vector requestedFields, boolean keepWhiteSpace) throws IOException {
/*  92 */     Map<Cell, String> cells = Maps.newHashMap();
/*  93 */     List<String> fields = Lists.newArrayList();
/*     */ 
/*     */ 
/*     */     
/*  97 */     boolean allFields = true;
/*  98 */     if (requestedFields instanceof org.renjin.sexp.StringVector) {
/*  99 */       Iterables.addAll(fields, (Iterable)requestedFields);
/* 100 */       allFields = false;
/*     */     } 
/*     */     
/* 103 */     int rowIndex = 0;
/* 104 */     boolean lastLineWasBlank = false;
/*     */     
/* 106 */     PushbackBufferedReader reader = Connections.getConnection(context, conn).getReader();
/* 107 */     Cell lastCell = null; String line;
/* 108 */     while ((line = reader.readLine()) != null) {
/* 109 */       boolean lineIsBlank = (line.trim().length() == 0);
/* 110 */       if (lineIsBlank) {
/* 111 */         if (!lastLineWasBlank) {
/* 112 */           rowIndex++;
/*     */         }
/* 114 */         lastCell = null;
/*     */       }
/* 116 */       else if (isContinuation(line)) {
/* 117 */         if (lastCell == null) {
/* 118 */           throw new EvalException("Malformed DCF exception '%s'", new Object[] { line });
/*     */         }
/* 120 */         StringBuilder value = new StringBuilder();
/* 121 */         value.append(cells.get(lastCell));
/* 122 */         value.append(" ");
/* 123 */         value.append(line.trim());
/* 124 */         cells.put(lastCell, value.toString());
/*     */       } else {
/*     */         
/* 127 */         String[] fieldValue = parseLine(line);
/* 128 */         String fieldName = fieldValue[0];
/*     */         
/* 130 */         boolean includeValue = false;
/* 131 */         if (fields.contains(fieldName)) {
/* 132 */           includeValue = true;
/* 133 */         } else if (allFields) {
/* 134 */           fields.add(fieldName);
/* 135 */           includeValue = true;
/*     */         } 
/* 137 */         Cell cell = new Cell(rowIndex, fieldName);
/* 138 */         if (includeValue) {
/* 139 */           cells.put(cell, fieldValue[1]);
/*     */         }
/* 141 */         lastCell = cell;
/*     */       } 
/* 143 */       lastLineWasBlank = lineIsBlank;
/*     */     } 
/* 145 */     int numRows = rowIndex;
/* 146 */     if (!lastLineWasBlank) {
/* 147 */       numRows++;
/*     */     }
/* 149 */     return constructMatrix(numRows, cells, fields);
/*     */   }
/*     */ 
/*     */   
/*     */   protected static SEXP constructMatrix(int numRows, Map<Cell, String> cells, List<String> fields) {
/* 154 */     StringMatrixBuilder matrix = new StringMatrixBuilder(numRows, fields.size());
/* 155 */     for (int row = 0; row != numRows; row++) {
/* 156 */       for (int col = 0; col != fields.size(); col++) {
/* 157 */         String value = cells.get(new Cell(row, fields.get(col)));
/* 158 */         matrix.setValue(row, col, value);
/*     */       } 
/*     */     } 
/* 161 */     matrix.setColNames(fields);
/* 162 */     return (SEXP)matrix.build();
/*     */   }
/*     */   
/*     */   private static boolean isContinuation(String line) {
/* 166 */     return Character.isWhitespace(line.charAt(0));
/*     */   }
/*     */   
/*     */   private static String[] parseLine(String line) {
/* 170 */     int colon = line.indexOf(':');
/* 171 */     if (colon == -1) {
/* 172 */       throw new EvalException("Malformed DCF line: '" + line + "'", new Object[0]);
/*     */     }
/* 174 */     String fieldName = line.substring(0, colon).trim();
/* 175 */     String value = line.substring(colon + 1).trim();
/* 176 */     return new String[] { fieldName, value };
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/io/DebianControlFiles.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */