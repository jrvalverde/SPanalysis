/*     */ package org.renjin.primitives.packaging;
/*     */ 
/*     */ import org.renjin.sexp.Symbol;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FqPackageName
/*     */ {
/*     */   public static final String CRAN_GROUP_ID = "org.renjin.cran";
/*     */   public static final String CORE_GROUP_ID = "org.renjin";
/*  34 */   public static final FqPackageName BASE = new FqPackageName("org.renjin", "base");
/*     */   
/*     */   private final String groupId;
/*     */   
/*     */   private final String packageName;
/*     */   
/*     */   public FqPackageName(String groupId, String packageName) {
/*  41 */     this.groupId = groupId;
/*  42 */     this.packageName = packageName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static FqPackageName fromSymbol(Symbol symbol) {
/*  50 */     String name = symbol.getPrintName();
/*  51 */     int sep = name.lastIndexOf(':');
/*  52 */     if (sep == -1) {
/*  53 */       sep = name.lastIndexOf(".");
/*     */     }
/*  55 */     return new FqPackageName(name
/*  56 */         .substring(0, sep), name
/*  57 */         .substring(sep + 1));
/*     */   }
/*     */   
/*     */   public static FqPackageName cranPackage(Symbol name) {
/*  61 */     return new FqPackageName("org.renjin.cran", name.getPrintName());
/*     */   }
/*     */   
/*     */   public static FqPackageName cranPackage(String name) {
/*  65 */     return new FqPackageName("org.renjin.cran", name);
/*     */   }
/*     */   
/*     */   public static FqPackageName corePackage(Symbol name) {
/*  69 */     return new FqPackageName("org.renjin", name.getPrintName());
/*     */   }
/*     */   
/*     */   public static FqPackageName corePackage(String name) {
/*  73 */     return new FqPackageName("org.renjin", name);
/*     */   }
/*     */   
/*     */   public String getGroupId() {
/*  77 */     return this.groupId;
/*     */   }
/*     */   
/*     */   public String getPackageName() {
/*  81 */     return this.packageName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Symbol getPackageSymbol() {
/*  89 */     return Symbol.get(this.packageName);
/*     */   }
/*     */   
/*     */   public String toString(char separator) {
/*  93 */     return this.groupId + separator + this.packageName;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/*  98 */     if (this == o) {
/*  99 */       return true;
/*     */     }
/* 101 */     if (o == null || getClass() != o.getClass()) {
/* 102 */       return false;
/*     */     }
/*     */     
/* 105 */     FqPackageName that = (FqPackageName)o;
/*     */     
/* 107 */     if (!this.groupId.equals(that.groupId)) {
/* 108 */       return false;
/*     */     }
/* 110 */     if (!this.packageName.equals(that.packageName)) {
/* 111 */       return false;
/*     */     }
/*     */     
/* 114 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 119 */     int result = this.groupId.hashCode();
/* 120 */     result = 31 * result + this.packageName.hashCode();
/* 121 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 126 */     return toString(':');
/*     */   }
/*     */   
/*     */   public static boolean isQualified(Symbol symbol) {
/* 130 */     return symbol.getPrintName().contains(":");
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/packaging/FqPackageName.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */