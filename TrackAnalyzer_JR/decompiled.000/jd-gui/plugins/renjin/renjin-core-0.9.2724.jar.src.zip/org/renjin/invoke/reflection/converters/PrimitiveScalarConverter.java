/*    */ package org.renjin.invoke.reflection.converters;
/*    */ 
/*    */ import org.renjin.eval.EvalException;
/*    */ import org.renjin.sexp.SEXP;
/*    */ import org.renjin.sexp.Vector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class PrimitiveScalarConverter<T>
/*    */   implements Converter<T>, AtomicVectorConverter
/*    */ {
/*    */   public final Object convertToJava(SEXP value) {
/* 35 */     if (!(value instanceof org.renjin.sexp.AtomicVector))
/* 36 */       throw new EvalException("Cannot convert '%s' to boolean", new Object[] { value.getTypeName() }); 
/* 37 */     if (value.length() < 1) {
/* 38 */       throw new EvalException("Cannot pass empty vector to boolean argument", new Object[0]);
/*    */     }
/* 40 */     return getFirstElement((Vector)value);
/*    */   }
/*    */   
/*    */   protected abstract Object getFirstElement(Vector paramVector);
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/reflection/converters/PrimitiveScalarConverter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */