/*    */ package org.renjin.pipeliner.node;
/*    */ 
/*    */ import org.renjin.primitives.vector.DeferredComputation;
/*    */ import org.renjin.primitives.vector.MemoizedComputation;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ import org.renjin.sexp.DoubleArrayVector;
/*    */ import org.renjin.sexp.IntArrayVector;
/*    */ import org.renjin.sexp.LogicalArrayVector;
/*    */ import org.renjin.sexp.Vector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FunctionNode
/*    */   extends DeferredNode
/*    */   implements Runnable
/*    */ {
/*    */   private DeferredComputation vector;
/*    */   private Vector result;
/*    */   
/*    */   public FunctionNode(DeferredComputation vector) {
/* 36 */     this.vector = vector;
/*    */   }
/*    */   
/*    */   public void replaceVector(DeferredComputation vector) {
/* 40 */     this.vector = vector;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getDebugLabel() {
/* 45 */     return this.vector.getComputationName();
/*    */   }
/*    */ 
/*    */   
/*    */   public Vector getVector() {
/* 50 */     return (Vector)this.vector;
/*    */   }
/*    */ 
/*    */   
/*    */   public NodeShape getShape() {
/* 55 */     if (this.vector instanceof MemoizedComputation) {
/* 56 */       return NodeShape.ELLIPSE;
/*    */     }
/* 58 */     return NodeShape.PARALLELOGRAM;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Type getResultVectorType() {
/* 64 */     if (this.vector instanceof org.renjin.sexp.DoubleVector)
/* 65 */       return Type.getType(DoubleArrayVector.class); 
/* 66 */     if (this.vector instanceof IntArrayVector)
/* 67 */       return Type.getType(IntArrayVector.class); 
/* 68 */     if (this.vector instanceof org.renjin.sexp.LogicalVector) {
/* 69 */       return Type.getType(LogicalArrayVector.class);
/*    */     }
/* 71 */     throw new UnsupportedOperationException("TODO: " + this.vector.getClass().getName());
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getComputationName() {
/* 77 */     return this.vector.getComputationName();
/*    */   }
/*    */ 
/*    */   
/*    */   public void run() {
/* 82 */     if (this.vector instanceof MemoizedComputation) {
/* 83 */       this.result = ((MemoizedComputation)this.vector).forceResult();
/*    */     } else {
/* 85 */       this.result = (Vector)this.vector;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/pipeliner/node/FunctionNode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */