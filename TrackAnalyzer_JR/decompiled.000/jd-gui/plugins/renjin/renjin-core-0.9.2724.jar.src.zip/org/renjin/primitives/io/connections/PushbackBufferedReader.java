/*     */ package org.renjin.primitives.io.connections;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import org.renjin.repackaged.guava.base.Strings;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PushbackBufferedReader
/*     */   extends Reader
/*     */ {
/*     */   private BufferedReader reader;
/*  37 */   private StringBuilder pushbackStack = new StringBuilder();
/*     */ 
/*     */   
/*     */   public PushbackBufferedReader(Reader reader) {
/*  41 */     this.reader = new BufferedReader(reader);
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/*  46 */     this.reader.close();
/*     */   }
/*     */ 
/*     */   
/*     */   public int read(char[] cbuf, int off, int len) throws IOException {
/*  51 */     if (this.pushbackStack.length() == 0) {
/*  52 */       return this.reader.read(cbuf, off, len);
/*     */     }
/*  54 */     int toRead = Math.min(this.pushbackStack.length(), len);
/*  55 */     this.pushbackStack.getChars(0, toRead, cbuf, off);
/*  56 */     this.pushbackStack.delete(0, toRead);
/*  57 */     return toRead;
/*     */   }
/*     */ 
/*     */   
/*     */   public void pushBack(String string) {
/*  62 */     this.pushbackStack.insert(0, string);
/*     */   }
/*     */   
/*     */   public String readLine() throws IOException {
/*  66 */     if (this.pushbackStack.length() == 0) {
/*  67 */       return this.reader.readLine();
/*     */     }
/*  69 */     int newLine = nextNewline(this.pushbackStack);
/*  70 */     if (newLine == -1) {
/*  71 */       return popStack() + Strings.nullToEmpty(this.reader.readLine());
/*     */     }
/*  73 */     return popStack(newLine);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private int nextNewline(StringBuilder stack) {
/*  79 */     for (int i = 0; i != stack.length(); i++) {
/*  80 */       if (stack.charAt(i) == '\n') {
/*  81 */         return i;
/*     */       }
/*     */     } 
/*  84 */     return -1;
/*     */   }
/*     */   
/*     */   private String popStack() {
/*  88 */     String line = this.pushbackStack.toString();
/*  89 */     this.pushbackStack.setLength(0);
/*  90 */     return line;
/*     */   }
/*     */   
/*     */   private String popStack(int newLinePos) {
/*  94 */     int eol = newLinePos;
/*  95 */     if (newLinePos != 0 && this.pushbackStack.charAt(newLinePos - 1) == '\r') {
/*  96 */       eol--;
/*     */     }
/*  98 */     String line = this.pushbackStack.substring(0, eol);
/*  99 */     this.pushbackStack.delete(0, newLinePos + 1);
/* 100 */     return line;
/*     */   }
/*     */   
/*     */   public int countLinesPushedBack() {
/* 104 */     int count = 0;
/* 105 */     for (int i = 0; i != this.pushbackStack.length(); i++) {
/* 106 */       if (this.pushbackStack.charAt(i) == '\n') {
/* 107 */         count++;
/*     */       }
/*     */     } 
/* 110 */     if (count == 0 && this.pushbackStack.length() > 0) {
/* 111 */       return 1;
/*     */     }
/* 113 */     return count;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/io/connections/PushbackBufferedReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */