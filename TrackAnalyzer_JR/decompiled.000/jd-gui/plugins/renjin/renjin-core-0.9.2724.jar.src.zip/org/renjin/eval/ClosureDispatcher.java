/*     */ package org.renjin.eval;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import org.renjin.primitives.special.ReturnException;
/*     */ import org.renjin.sexp.Closure;
/*     */ import org.renjin.sexp.Environment;
/*     */ import org.renjin.sexp.FunctionCall;
/*     */ import org.renjin.sexp.ListVector;
/*     */ import org.renjin.sexp.Null;
/*     */ import org.renjin.sexp.PairList;
/*     */ import org.renjin.sexp.Promise;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.Symbol;
/*     */ import org.renjin.sexp.Symbols;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClosureDispatcher
/*     */ {
/*     */   private final FunctionCall call;
/*     */   private final Environment callingEnvironment;
/*     */   private final Context callingContext;
/*     */   private DispatchChain dispatchChain;
/*     */   
/*     */   public ClosureDispatcher(Context callingContext, Environment callingEnvironment, FunctionCall call) {
/*  37 */     this.call = call;
/*  38 */     this.callingEnvironment = callingEnvironment;
/*  39 */     this.callingContext = callingContext;
/*     */   }
/*     */ 
/*     */   
/*     */   public SEXP apply(DispatchChain chain, PairList arguments) {
/*  44 */     this.dispatchChain = chain;
/*  45 */     return apply(this.callingContext, this.callingEnvironment, this.call, chain.getClosure(), arguments, this.dispatchChain.createMetadata());
/*     */   }
/*     */   
/*     */   public SEXP applyClosure(Closure closure, PairList args) {
/*  49 */     PairList promisedArgs = Calls.promiseArgs(args, this.callingContext, this.callingEnvironment);
/*  50 */     return apply(this.callingContext, this.callingEnvironment, this.call, closure, promisedArgs, Collections.emptyMap());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SEXP apply(Context callingContext, Environment callingEnvironment, FunctionCall call, Closure closure, PairList promisedArgs, Map<Symbol, SEXP> metadata) {
/*  67 */     Context functionContext = callingContext.beginFunction(callingEnvironment, call, closure, promisedArgs);
/*  68 */     Environment functionEnvironment = functionContext.getEnvironment();
/*     */     
/*     */     try {
/*  71 */       matchArgumentsInto(closure.getFormals(), promisedArgs, functionEnvironment);
/*     */       
/*  73 */       if (!metadata.isEmpty()) {
/*  74 */         for (Map.Entry<Symbol, SEXP> entry : metadata.entrySet()) {
/*  75 */           functionEnvironment.setVariableUnsafe(entry.getKey(), entry.getValue());
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         }
/*     */ 
/*     */ 
/*     */       
/*     */       }
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*  89 */     catch (ReturnException e) {
/*  90 */       if (e.getEnvironment() != functionEnvironment) {
/*  91 */         throw e;
/*     */       }
/*  93 */       return e.getValue();
/*     */     }
/*  95 */     catch (ConditionException e) {
/*  96 */       if (e.getHandlerContext() == functionContext) {
/*  97 */         return (SEXP)new ListVector(new SEXP[] { e.getCondition(), (SEXP)Null.INSTANCE, e.getHandler() });
/*     */       }
/*  99 */       throw e;
/*     */     
/*     */     }
/* 102 */     catch (RestartException e) {
/* 103 */       if (e.getExitEnvironment() == functionContext.getEnvironment())
/*     */       {
/* 105 */         return (SEXP)e.getArguments();
/*     */       }
/* 107 */       throw e;
/*     */     }
/*     */     finally {
/*     */       
/* 111 */       functionContext.exit();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void matchArgumentsInto(PairList formals, PairList actuals, Environment functionEnv) {
/* 128 */     ArgumentMatcher matcher = new ArgumentMatcher(formals);
/* 129 */     MatchedArguments matching = matcher.match(actuals);
/*     */     
/* 131 */     for (int formalIndex = 0; formalIndex < matching.getFormalCount(); formalIndex++) {
/* 132 */       if (matching.isFormalEllipses(formalIndex)) {
/* 133 */         functionEnv.setVariableUnsafe(Symbols.ELLIPSES, (SEXP)matching.buildExtraArgumentList());
/*     */       } else {
/*     */         
/* 136 */         Symbol formalName = matching.getFormalName(formalIndex);
/* 137 */         int actualIndex = matching.getActualIndex(formalIndex);
/*     */         
/* 139 */         if (actualIndex == -1) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 146 */           SEXP defaultValue = matcher.getDefaultValue(formalIndex);
/*     */           
/* 148 */           functionEnv.setMissingArgument(formalName, 
/* 149 */               promiseDefaultValue(functionEnv, defaultValue));
/*     */         
/*     */         }
/*     */         else {
/*     */ 
/*     */           
/* 155 */           SEXP actualValue = matching.getActualValue(actualIndex);
/* 156 */           if (actualValue == Symbol.MISSING_ARG) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 163 */             SEXP defaultValue = matcher.getDefaultValue(formalIndex);
/*     */             
/* 165 */             functionEnv.setMissingArgument(formalName, 
/* 166 */                 promiseDefaultValue(functionEnv, defaultValue));
/*     */           } else {
/*     */             
/* 169 */             functionEnv.setArgument(formalName, actualValue);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   private static SEXP promiseDefaultValue(Environment functionEnv, SEXP defaultValue) {
/*     */     Promise promise;
/* 177 */     if (defaultValue != Symbol.MISSING_ARG)
/*     */     {
/*     */       
/* 180 */       promise = Promise.repromise(functionEnv, defaultValue);
/*     */     }
/* 182 */     return (SEXP)promise;
/*     */   }
/*     */   
/*     */   public static PairList matchArguments(PairList formals, PairList actuals) {
/* 186 */     return matchArguments(formals, actuals, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PairList matchArguments(PairList formals, PairList actuals, boolean populateMissing) {
/* 198 */     ArgumentMatcher matcher = new ArgumentMatcher(formals);
/* 199 */     MatchedArguments matching = matcher.match(actuals);
/*     */     
/* 201 */     PairList.Builder result = new PairList.Builder();
/* 202 */     for (int formalIndex = 0; formalIndex < matching.getFormalCount(); formalIndex++) {
/*     */       
/* 204 */       if (matching.isFormalEllipses(formalIndex)) {
/* 205 */         result.add(Symbols.ELLIPSES, (SEXP)matching.buildExtraArgumentList());
/*     */       } else {
/*     */         
/* 208 */         int actualIndex = matching.getActualIndex(formalIndex);
/* 209 */         if (actualIndex == -1) {
/* 210 */           if (populateMissing) {
/* 211 */             result.add(matching.getFormalName(formalIndex), (SEXP)Symbol.MISSING_ARG);
/*     */           }
/*     */         } else {
/* 214 */           result.add(matching.getFormalName(formalIndex), matching.getActualValue(actualIndex));
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 219 */     return result.build();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/eval/ClosureDispatcher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */