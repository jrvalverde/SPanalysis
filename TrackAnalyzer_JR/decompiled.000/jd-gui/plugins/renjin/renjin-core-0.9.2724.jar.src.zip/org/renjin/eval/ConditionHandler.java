/*    */ package org.renjin.eval;
/*    */ 
/*    */ import org.renjin.sexp.SEXP;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConditionHandler
/*    */ {
/*    */   private SEXP handler;
/*    */   private boolean calling;
/*    */   
/*    */   public ConditionHandler(SEXP handler, boolean calling) {
/* 42 */     this.handler = handler;
/* 43 */     this.calling = calling;
/*    */   }
/*    */   
/*    */   public SEXP getFunction() {
/* 47 */     return this.handler;
/*    */   }
/*    */   
/*    */   public boolean isCalling() {
/* 51 */     return this.calling;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/eval/ConditionHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */