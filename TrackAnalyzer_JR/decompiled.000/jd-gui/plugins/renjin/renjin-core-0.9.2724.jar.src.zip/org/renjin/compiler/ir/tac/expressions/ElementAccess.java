/*     */ package org.renjin.compiler.ir.tac.expressions;
/*     */ 
/*     */ import java.util.Map;
/*     */ import org.renjin.compiler.codegen.EmitContext;
/*     */ import org.renjin.compiler.ir.ValueBounds;
/*     */ import org.renjin.primitives.sequence.IntSequence;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ import org.renjin.repackaged.asm.commons.InstructionAdapter;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ElementAccess
/*     */   extends SpecializedCallExpression
/*     */ {
/*  40 */   private ValueBounds valueBounds = ValueBounds.UNBOUNDED;
/*     */   
/*     */   public ElementAccess(Expression vector, Expression index) {
/*  43 */     super(new Expression[] { vector, index });
/*     */   }
/*     */   
/*     */   public Expression getVector() {
/*  47 */     return this.arguments[0];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Expression getIndex() {
/*  55 */     return this.arguments[1];
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  60 */     return getVector() + "[" + getIndex() + "]";
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isFunctionDefinitelyPure() {
/*  65 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int load(EmitContext emitContext, InstructionAdapter mv) {
/*  73 */     Expression vector = getVector();
/*  74 */     Type resultType = this.valueBounds.storageType();
/*     */     
/*  76 */     ValueBounds vectorBounds = vector.getValueBounds();
/*  77 */     if (vectorBounds.isConstant() && 
/*  78 */       vectorBounds.getConstantValue() instanceof IntSequence) {
/*  79 */       IntSequence sequence = (IntSequence)vectorBounds.getConstantValue();
/*  80 */       getIndex().load(emitContext, mv);
/*  81 */       if (sequence.getBy() != 1) {
/*  82 */         mv.iconst(sequence.getBy());
/*  83 */         mv.mul(Type.INT_TYPE);
/*     */       } 
/*  85 */       if (sequence.getFrom() != 0) {
/*  86 */         mv.iconst(sequence.getFrom());
/*  87 */         mv.add(Type.INT_TYPE);
/*     */       } 
/*  89 */       return 2;
/*     */     } 
/*     */ 
/*     */     
/*  93 */     if (vector.getType().getSort() == 10) {
/*  94 */       int stackHeight = vector.load(emitContext, mv);
/*     */       
/*  96 */       if (vector.getType().equals(Type.getType(SEXP.class))) {
/*  97 */         mv.checkcast(Type.getType(Vector.class));
/*     */       }
/*     */       
/* 100 */       getIndex().load(emitContext, mv);
/*     */       
/* 102 */       if (resultType.equals(Type.INT_TYPE)) {
/* 103 */         mv.invokeinterface(Type.getInternalName(Vector.class), "getElementAsInt", 
/* 104 */             Type.getMethodDescriptor(Type.INT_TYPE, new Type[] { Type.INT_TYPE }));
/* 105 */       } else if (resultType.equals(Type.DOUBLE_TYPE)) {
/* 106 */         mv.invokeinterface(Type.getInternalName(Vector.class), "getElementAsDouble", 
/* 107 */             Type.getMethodDescriptor(Type.DOUBLE_TYPE, new Type[] { Type.INT_TYPE }));
/*     */       } else {
/* 109 */         throw new UnsupportedOperationException("resultType: " + resultType);
/*     */       } 
/*     */       
/* 112 */       return stackHeight + 1;
/*     */     } 
/*     */     
/* 115 */     throw new UnsupportedOperationException("vectorType: " + vector.getType());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Type getType() {
/* 121 */     return this.valueBounds.storageType();
/*     */   }
/*     */ 
/*     */   
/*     */   public ValueBounds updateTypeBounds(Map<Expression, ValueBounds> typeMap) {
/* 126 */     int typeSet = getVector().updateTypeBounds(typeMap).getTypeSet();
/*     */     
/* 128 */     this.valueBounds = ValueBounds.primitive(typeSet);
/*     */     
/* 130 */     return this.valueBounds;
/*     */   }
/*     */ 
/*     */   
/*     */   public ValueBounds getValueBounds() {
/* 135 */     return this.valueBounds;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/ir/tac/expressions/ElementAccess.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */