/*     */ package org.renjin.pipeliner.fusion.node;
/*     */ 
/*     */ import java.util.Optional;
/*     */ import org.renjin.pipeliner.ComputeMethod;
/*     */ import org.renjin.repackaged.asm.Label;
/*     */ import org.renjin.repackaged.asm.MethodVisitor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TransposeNode
/*     */   extends LoopNode
/*     */ {
/*     */   private final LoopNode operand;
/*     */   private final LoopNode sourceRowCount;
/*     */   private int sourceRowCountLocal;
/*     */   private int sourceColCountLocal;
/*     */   
/*     */   public TransposeNode(LoopNode operand, LoopNode sourceRowCount) {
/*  37 */     this.operand = operand;
/*  38 */     this.sourceRowCount = sourceRowCount;
/*     */   }
/*     */ 
/*     */   
/*     */   public void init(ComputeMethod method) {
/*  43 */     this.operand.init(method);
/*  44 */     this.sourceRowCount.init(method);
/*     */     
/*  46 */     this.sourceRowCountLocal = method.reserveLocal(1);
/*  47 */     this.sourceColCountLocal = method.reserveLocal(1);
/*     */ 
/*     */ 
/*     */     
/*  51 */     MethodVisitor mv = method.getVisitor();
/*  52 */     this.operand.pushLength(method);
/*  53 */     mv.visitInsn(3);
/*     */     
/*  55 */     this.sourceRowCount.pushElementAsInt(method, Optional.empty());
/*     */     
/*  57 */     mv.visitInsn(89);
/*     */     
/*  59 */     mv.visitVarInsn(54, this.sourceRowCountLocal);
/*     */     
/*  61 */     mv.visitInsn(108);
/*     */     
/*  63 */     mv.visitVarInsn(54, this.sourceColCountLocal);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void pushElementAsDouble(ComputeMethod method, Optional<Label> integerNaLabel) {
/*  69 */     MethodVisitor mv = method.getVisitor();
/*  70 */     mv.visitInsn(89);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  82 */     mv.visitVarInsn(21, this.sourceColCountLocal);
/*     */     
/*  84 */     mv.visitInsn(108);
/*     */     
/*  86 */     mv.visitInsn(95);
/*     */     
/*  88 */     mv.visitVarInsn(21, this.sourceColCountLocal);
/*     */     
/*  90 */     mv.visitInsn(112);
/*     */     
/*  92 */     mv.visitVarInsn(21, this.sourceRowCountLocal);
/*     */     
/*  94 */     mv.visitInsn(104);
/*     */     
/*  96 */     mv.visitInsn(96);
/*     */     
/*  98 */     this.operand.pushElementAsDouble(method, integerNaLabel);
/*     */   }
/*     */ 
/*     */   
/*     */   public void pushLength(ComputeMethod method) {
/* 103 */     this.operand.pushLength(method);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean mustCheckForIntegerNAs() {
/* 108 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void appendToKey(StringBuilder key) {
/* 113 */     key.append("t(");
/* 114 */     this.operand.appendToKey(key);
/* 115 */     key.append(';');
/* 116 */     this.sourceRowCount.appendToKey(key);
/* 117 */     key.append(')');
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 122 */     return "t(" + this.operand + ")";
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/pipeliner/fusion/node/TransposeNode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */