/*     */ package org.renjin.invoke.codegen;
/*     */ 
/*     */ import com.sun.codemodel.CodeWriter;
/*     */ import com.sun.codemodel.JCodeModel;
/*     */ import com.sun.codemodel.JPackage;
/*     */ import java.io.File;
/*     */ import java.io.FileWriter;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.Writer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import javax.tools.Diagnostic;
/*     */ import javax.tools.DiagnosticCollector;
/*     */ import javax.tools.JavaCompiler;
/*     */ import javax.tools.JavaFileObject;
/*     */ import javax.tools.SimpleJavaFileObject;
/*     */ import javax.tools.StandardJavaFileManager;
/*     */ import javax.tools.StandardLocation;
/*     */ import javax.tools.ToolProvider;
/*     */ import org.renjin.invoke.annotations.CastStyle;
/*     */ import org.renjin.invoke.model.JvmMethod;
/*     */ import org.renjin.invoke.model.PrimitiveModel;
/*     */ import org.renjin.primitives.Primitives;
/*     */ import org.renjin.repackaged.guava.base.Charsets;
/*     */ import org.renjin.repackaged.guava.io.Files;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WrapperGenerator2
/*     */ {
/*     */   private File sourcesDir;
/*     */   private File outputDir;
/*     */   private String singleFunction;
/*     */   
/*     */   public static void main(String[] args) throws IOException {
/*  49 */     File baseDir = new File("");
/*     */     
/*  51 */     WrapperGenerator2 generator = new WrapperGenerator2(baseDir);
/*     */     
/*  53 */     if (args.length > 0) {
/*  54 */       generator.setSingleFunction(args[0]);
/*     */     }
/*  56 */     generator.generate();
/*  57 */     System.exit(generator.isSuccessful() ? 0 : 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean encounteredError = false;
/*     */ 
/*     */   
/*  66 */   private List<JavaFileObject> compilationUnits = new ArrayList<>();
/*     */   
/*     */   public WrapperGenerator2(File baseDir) {
/*  69 */     this.sourcesDir = new File(baseDir.getAbsoluteFile() + File.separator + "target" + File.separator + "generated-sources" + File.separator + "r-wrappers" + File.separator);
/*     */     
/*  71 */     this.sourcesDir.mkdirs();
/*     */     
/*  73 */     this.outputDir = new File(baseDir.getAbsoluteFile() + File.separator + "target" + File.separator + "classes");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setSingleFunction(String name) {
/*  78 */     this.singleFunction = name;
/*     */   }
/*     */   
/*     */   public void generate() throws IOException {
/*  82 */     generateSources();
/*  83 */     compile();
/*     */   }
/*     */   
/*     */   public boolean isSuccessful() {
/*  87 */     return !this.encounteredError;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void generateSources() throws IOException {
/*  93 */     int implementedCount = 0;
/*     */     
/*  95 */     JCodeModel codeModel = new JCodeModel();
/*     */     
/*  97 */     List<Primitives.Entry> entries = Primitives.getEntries();
/*  98 */     for (Primitives.Entry entry : entries) {
/*  99 */       if (this.singleFunction == null || this.singleFunction.equals(entry.name)) {
/* 100 */         List<JvmMethod> overloads = JvmMethod.findOverloads(entry.functionClass, entry.name, entry.methodName);
/*     */         
/* 102 */         if (overloads.isEmpty() && entry.functionClass != null) {
/* 103 */           System.err.println("WARNING: Can't find " + entry.functionClass.getName() + "." + ((entry.methodName == null) ? entry.name : entry.methodName));
/*     */         }
/*     */ 
/*     */         
/* 107 */         if (!overloads.isEmpty()) {
/* 108 */           generate(codeModel, new PrimitiveModel(entry, overloads));
/* 109 */           implementedCount++;
/*     */         } 
/*     */         
/* 112 */         for (JvmMethod method : overloads) {
/* 113 */           if (implicitIntCasting(method)) {
/* 114 */             System.out.println("IMPLICIT INT CASTING: " + method);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 120 */     codeModel.build(new CodeWriter()
/*     */         {
/*     */           public Writer openSource(JPackage pkg, String fileName) throws IOException {
/* 123 */             File pkgDir = new File(WrapperGenerator2.this.sourcesDir, pkg.name().replace('.', '/'));
/* 124 */             pkgDir.mkdirs();
/*     */             
/* 126 */             File sourceFile = new File(pkgDir, fileName);
/* 127 */             WrapperGenerator2.this.compilationUnits.add(new WrapperGenerator2.WrapperSource(sourceFile));
/* 128 */             return new FileWriter(sourceFile);
/*     */           }
/*     */ 
/*     */           
/*     */           public OutputStream openBinary(JPackage jPackage, String s) throws IOException {
/* 133 */             throw new UnsupportedOperationException();
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public void close() throws IOException {}
/*     */         });
/* 141 */     System.out.println("Total primitives: " + entries.size());
/* 142 */     System.out.println("   % Implemented: " + (implementedCount / entries.size() * 100.0D) + "%");
/*     */   }
/*     */   
/*     */   private boolean implicitIntCasting(JvmMethod method) {
/* 146 */     for (JvmMethod.Argument arg : method.getFormals()) {
/* 147 */       if (arg.getClazz().equals(int.class) && arg.getCastStyle() == CastStyle.IMPLICIT) {
/* 148 */         return true;
/*     */       }
/*     */     } 
/* 151 */     return false;
/*     */   }
/*     */   
/*     */   private void generate(JCodeModel codeModel, PrimitiveModel primitive) throws IOException {
/*     */     try {
/* 156 */       InvokerGenerator generator = new InvokerGenerator(codeModel);
/* 157 */       generator.generate(primitive);
/*     */     }
/* 159 */     catch (Exception e) {
/* 160 */       System.err.println("Error generating wrapper for '" + primitive.getName() + "': " + e.getMessage());
/* 161 */       System.err.println("Overloads defined:");
/* 162 */       for (JvmMethod method : primitive.getOverloads()) {
/* 163 */         System.err.println("  " + method.toString());
/*     */       }
/* 165 */       this.encounteredError = true;
/* 166 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   private static class WrapperSource
/*     */     extends SimpleJavaFileObject {
/*     */     private File file;
/*     */     
/*     */     public WrapperSource(File file) {
/* 175 */       super(file.toURI(), JavaFileObject.Kind.SOURCE);
/* 176 */       this.file = file;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public CharSequence getCharContent(boolean ignoreEncodingErrors) throws IOException {
/* 182 */       return Files.toString(this.file, Charsets.UTF_8);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void compile() throws IOException {
/* 188 */     JavaCompiler compiler = ToolProvider.getSystemJavaCompiler();
/* 189 */     DiagnosticCollector<JavaFileObject> diagnostics = new DiagnosticCollector<>();
/* 190 */     StandardJavaFileManager jfm = compiler.getStandardFileManager(diagnostics, null, null);
/* 191 */     jfm.setLocation(StandardLocation.CLASS_OUTPUT, Collections.singleton(this.outputDir));
/* 192 */     JavaCompiler.CompilationTask task = compiler.getTask(null, jfm, diagnostics, 
/*     */ 
/*     */ 
/*     */         
/* 196 */         Arrays.asList(new String[] { "-g", "-source", "1.6", "-target", "1.6" }, ), null, this.compilationUnits);
/*     */ 
/*     */ 
/*     */     
/* 200 */     boolean success = task.call().booleanValue();
/*     */     
/* 202 */     if (!success) {
/* 203 */       System.err.println("Compilation failed: ");
/* 204 */       for (Diagnostic<? extends JavaFileObject> d : diagnostics.getDiagnostics()) {
/* 205 */         System.err.println(d.toString());
/*     */       }
/* 207 */       this.encounteredError = true;
/*     */     } 
/*     */     
/* 210 */     jfm.close();
/*     */   }
/*     */   
/*     */   public static String toJavaName(String rName) {
/* 214 */     return toJavaName("R$primitive$", rName);
/*     */   }
/*     */   
/*     */   public static String toJavaName(String prefix, String rName) {
/* 218 */     StringBuilder sb = new StringBuilder();
/* 219 */     sb.append(prefix);
/*     */     
/* 221 */     rName = rName.replace('.', '$');
/* 222 */     rName = rName.replace("<-", "$assign");
/*     */ 
/*     */     
/* 225 */     for (int i = 0; i != rName.length(); i++) {
/* 226 */       int cp = rName.codePointAt(i);
/* 227 */       if (Character.isJavaIdentifierPart(cp)) {
/* 228 */         sb.appendCodePoint(cp);
/* 229 */       } else if (cp == 61) {
/* 230 */         sb.append("$eq");
/* 231 */       } else if (cp == 62) {
/* 232 */         sb.append("$greater");
/* 233 */       } else if (cp == 60) {
/* 234 */         sb.append("$less");
/* 235 */       } else if (cp == 43) {
/* 236 */         sb.append("$plus");
/* 237 */       } else if (cp == 45) {
/* 238 */         sb.append("$minus");
/* 239 */       } else if (cp == 42) {
/* 240 */         sb.append("$times");
/* 241 */       } else if (cp == 47) {
/* 242 */         sb.append("$div");
/* 243 */       } else if (cp == 33) {
/* 244 */         sb.append("$bang");
/* 245 */       } else if (cp == 64) {
/* 246 */         sb.append("$at");
/* 247 */       } else if (cp == 35) {
/* 248 */         sb.append("$hash");
/* 249 */       } else if (cp == 37) {
/* 250 */         sb.append("$percent");
/* 251 */       } else if (cp == 94) {
/* 252 */         sb.append("$up");
/* 253 */       } else if (cp == 38) {
/* 254 */         sb.append("$amp");
/* 255 */       } else if (cp == 126) {
/* 256 */         sb.append("$tilde");
/* 257 */       } else if (cp == 63) {
/* 258 */         sb.append("$qmark");
/* 259 */       } else if (cp == 124) {
/* 260 */         sb.append("$bar");
/* 261 */       } else if (cp == 92) {
/* 262 */         sb.append("$bslash");
/* 263 */       } else if (cp == 58) {
/* 264 */         sb.append("$colon");
/* 265 */       } else if (cp == 40) {
/* 266 */         sb.append("$paren");
/* 267 */       } else if (cp == 91) {
/* 268 */         sb.append("$bracket");
/*     */       } else {
/* 270 */         sb.append("_$" + cp + "$_");
/*     */       } 
/*     */     } 
/* 273 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public static String toFullJavaName(String rName) {
/* 277 */     return "org.renjin.primitives." + toJavaName(rName);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/codegen/WrapperGenerator2.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */