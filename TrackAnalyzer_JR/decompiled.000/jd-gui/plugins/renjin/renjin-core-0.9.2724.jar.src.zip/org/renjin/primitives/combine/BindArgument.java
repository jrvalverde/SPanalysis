/*     */ package org.renjin.primitives.combine;
/*     */ 
/*     */ import org.renjin.eval.Context;
/*     */ import org.renjin.primitives.Deparse;
/*     */ import org.renjin.sexp.AtomicVector;
/*     */ import org.renjin.sexp.Null;
/*     */ import org.renjin.sexp.Promise;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.Symbols;
/*     */ import org.renjin.sexp.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BindArgument
/*     */ {
/*     */   private final SEXP uneval;
/*     */   private final Vector vector;
/*     */   private final int rows;
/*     */   private final int cols;
/*     */   private final int deparseLevel;
/*     */   Context context;
/*     */   private SEXP expression;
/*  37 */   private AtomicVector rowNames = (AtomicVector)Null.INSTANCE;
/*  38 */   private AtomicVector colNames = (AtomicVector)Null.INSTANCE;
/*     */   
/*     */   private final boolean matrix;
/*     */   
/*     */   private String argName;
/*     */   
/*     */   private String computedName;
/*     */ 
/*     */   
/*     */   public BindArgument(String argName, Vector vector, MatrixDim bindDim, SEXP uneval, int deparseLevel, Context context) {
/*  48 */     this.argName = argName;
/*  49 */     this.uneval = uneval;
/*  50 */     this.deparseLevel = deparseLevel;
/*  51 */     Vector vector1 = vector.getAttributes().getDim();
/*  52 */     this.vector = vector;
/*  53 */     this.expression = (uneval instanceof Promise) ? ((Promise)uneval).getExpression() : uneval;
/*  54 */     if (vector1 == Null.INSTANCE || vector1.length() != 2) {
/*  55 */       if (bindDim == MatrixDim.ROW) {
/*  56 */         this.rows = 1;
/*  57 */         this.cols = vector.length();
/*  58 */         this.colNames = vector.getNames();
/*     */       } else {
/*  60 */         this.cols = 1;
/*  61 */         this.rows = vector.length();
/*  62 */         this.rowNames = vector.getNames();
/*     */       } 
/*  64 */       this.matrix = false;
/*     */     } else {
/*     */       
/*  67 */       AtomicVector dimVector = (AtomicVector)vector1;
/*  68 */       this.rows = dimVector.getElementAsInt(0);
/*  69 */       this.cols = dimVector.getElementAsInt(1);
/*  70 */       Vector dimNames = (Vector)this.vector.getAttribute(Symbols.DIMNAMES);
/*  71 */       if (dimNames instanceof org.renjin.sexp.ListVector && dimNames.length() == 2) {
/*  72 */         this.rowNames = (AtomicVector)dimNames.getElementAsSEXP(0);
/*  73 */         this.colNames = (AtomicVector)dimNames.getElementAsSEXP(1);
/*     */       } 
/*     */       
/*  76 */       this.matrix = true;
/*     */     } 
/*     */     
/*  79 */     if (this.argName != null && this.argName.length() > 0) {
/*  80 */       this.computedName = this.argName;
/*  81 */     } else if (this.deparseLevel == 1 && this.expression instanceof org.renjin.sexp.Symbol) {
/*  82 */       this.computedName = this.expression.asString();
/*  83 */     } else if (this.deparseLevel == 2) {
/*  84 */       this.computedName = Deparse.deparse(context, this.expression, 0, false, 0, 0);
/*  85 */       if (this.computedName.length() > 10) {
/*  86 */         this.computedName = this.computedName.substring(0, 10) + "...";
/*     */       }
/*     */     } else {
/*  89 */       this.computedName = "";
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Vector getClasses() {
/*  95 */     return (Vector)this.vector.getAttribute(Symbols.CLASS);
/*     */   }
/*     */   
/*     */   public String getArgName() {
/*  99 */     return this.argName;
/*     */   }
/*     */   
/*     */   public String getName() {
/* 103 */     return this.computedName;
/*     */   }
/*     */   
/*     */   public boolean hasNoName() {
/* 107 */     return this.computedName.isEmpty();
/*     */   }
/*     */   
/*     */   public Promise repromise() {
/* 111 */     return new Promise(this.expression, (SEXP)this.vector);
/*     */   }
/*     */   
/*     */   public Vector getVector() {
/* 115 */     return this.vector;
/*     */   }
/*     */   
/*     */   public SEXP getExpression() {
/* 119 */     return this.expression;
/*     */   }
/*     */   
/*     */   public int getRows() {
/* 123 */     return this.rows;
/*     */   }
/*     */   
/*     */   public int getCols() {
/* 127 */     return this.cols;
/*     */   }
/*     */   
/*     */   public AtomicVector getRowNames() {
/* 131 */     return this.rowNames;
/*     */   }
/*     */   
/*     */   public AtomicVector getColNames() {
/* 135 */     return this.colNames;
/*     */   }
/*     */   
/*     */   public boolean isMatrix() {
/* 139 */     return this.matrix;
/*     */   }
/*     */   
/*     */   public SEXP getUneval() {
/* 143 */     return this.uneval;
/*     */   }
/*     */   
/*     */   public boolean isZeroLength() {
/* 147 */     return (this.vector.length() == 0);
/*     */   }
/*     */   
/*     */   public boolean isZeroLengthVector() {
/* 151 */     return (!this.matrix && this.vector.length() == 0);
/*     */   }
/*     */   
/*     */   public boolean isNull() {
/* 155 */     return (this.vector == Null.INSTANCE);
/*     */   }
/*     */   
/*     */   public int getDimLength(MatrixDim dim) {
/* 159 */     if (dim == MatrixDim.ROW) {
/* 160 */       return this.rows;
/*     */     }
/* 162 */     return this.cols;
/*     */   }
/*     */ 
/*     */   
/*     */   public AtomicVector getNames(MatrixDim dim) {
/* 167 */     if (dim == MatrixDim.ROW) {
/* 168 */       return this.rowNames;
/*     */     }
/* 170 */     return this.colNames;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/combine/BindArgument.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */