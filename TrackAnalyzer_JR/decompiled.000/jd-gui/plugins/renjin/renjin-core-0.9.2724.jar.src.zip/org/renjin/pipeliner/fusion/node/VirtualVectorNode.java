/*     */ package org.renjin.pipeliner.fusion.node;
/*     */ 
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Optional;
/*     */ import java.util.logging.Logger;
/*     */ import org.renjin.pipeliner.ComputeMethod;
/*     */ import org.renjin.pipeliner.VectorPipeliner;
/*     */ import org.renjin.repackaged.asm.Label;
/*     */ import org.renjin.repackaged.asm.MethodVisitor;
/*     */ import org.renjin.sexp.IntVector;
/*     */ import org.renjin.sexp.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VirtualVectorNode
/*     */   extends LoopNode
/*     */ {
/*  36 */   private static final Logger LOGGER = Logger.getLogger(VirtualVectorNode.class.getName());
/*     */   
/*     */   private int ptrLocalIndex;
/*     */   
/*     */   private String vectorClass;
/*     */   
/*     */   private int operandIndex;
/*     */   
/*     */   private Vector.Type vectorType;
/*     */ 
/*     */   
/*     */   public VirtualVectorNode(int operandIndex, Vector vector) {
/*  48 */     if (VectorPipeliner.DEBUG) {
/*  49 */       System.out.println("VirtualAccessor for " + vector.getClass().getName());
/*     */     }
/*  51 */     this.vectorType = vector.getVectorType();
/*     */ 
/*     */     
/*  54 */     if (!Modifier.isPublic(vector.getClass().getModifiers())) {
/*  55 */       LOGGER.warning("Vector class " + vector.getClass().getName() + " is not public: member access may not be fully inlined by JVM.");
/*     */     }
/*  57 */     this.vectorClass = findFirstPublicSuperClass(vector.getClass()).getName().replace('.', '/');
/*  58 */     this.operandIndex = operandIndex;
/*     */   }
/*     */ 
/*     */   
/*     */   private Class findFirstPublicSuperClass(Class clazz) {
/*  63 */     while (!Modifier.isPublic(clazz.getModifiers())) {
/*  64 */       clazz = clazz.getSuperclass();
/*     */     }
/*  66 */     return clazz;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void init(ComputeMethod method) {
/*  72 */     this.ptrLocalIndex = method.reserveLocal(1);
/*     */     
/*  74 */     MethodVisitor mv = method.getVisitor();
/*  75 */     mv.visitVarInsn(25, method.getOperandsLocalIndex());
/*  76 */     pushIntConstant(mv, this.operandIndex);
/*  77 */     mv.visitInsn(50);
/*  78 */     mv.visitTypeInsn(192, this.vectorClass);
/*  79 */     mv.visitVarInsn(58, this.ptrLocalIndex);
/*     */   }
/*     */ 
/*     */   
/*     */   public void pushLength(ComputeMethod method) {
/*  84 */     MethodVisitor mv = method.getVisitor();
/*  85 */     mv.visitVarInsn(25, this.ptrLocalIndex);
/*  86 */     mv.visitMethodInsn(182, this.vectorClass, "length", "()I");
/*     */   }
/*     */ 
/*     */   
/*     */   public void pushElementAsDouble(ComputeMethod method, Optional<Label> integerNaLabel) {
/*  91 */     MethodVisitor mv = method.getVisitor();
/*  92 */     mv.visitVarInsn(25, this.ptrLocalIndex);
/*  93 */     mv.visitInsn(95);
/*  94 */     mv.visitMethodInsn(182, this.vectorClass, "getElementAsDouble", "(I)D");
/*     */   }
/*     */ 
/*     */   
/*     */   public void pushElementAsInt(ComputeMethod method, Optional<Label> naLabel) {
/*  99 */     MethodVisitor mv = method.getVisitor();
/* 100 */     mv.visitVarInsn(25, this.ptrLocalIndex);
/* 101 */     mv.visitInsn(95);
/* 102 */     mv.visitMethodInsn(182, this.vectorClass, "getElementAsInt", "(I)I");
/*     */     
/* 104 */     doIntegerNaCheck(mv, naLabel);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean mustCheckForIntegerNAs() {
/* 109 */     return (this.vectorType == IntVector.VECTOR_TYPE);
/*     */   }
/*     */ 
/*     */   
/*     */   public void appendToKey(StringBuilder key) {
/* 114 */     key.append(this.vectorClass);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/pipeliner/fusion/node/VirtualVectorNode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */