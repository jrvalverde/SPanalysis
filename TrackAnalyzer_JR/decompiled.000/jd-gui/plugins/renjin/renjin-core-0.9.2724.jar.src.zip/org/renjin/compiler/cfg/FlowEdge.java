/*    */ package org.renjin.compiler.cfg;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FlowEdge
/*    */ {
/*    */   private final BasicBlock predecessor;
/*    */   private final BasicBlock successor;
/*    */   
/*    */   public FlowEdge(BasicBlock predecessor, BasicBlock successor) {
/* 29 */     this.predecessor = predecessor;
/* 30 */     this.successor = successor;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 35 */     if (this == o) {
/* 36 */       return true;
/*    */     }
/* 38 */     if (o == null || getClass() != o.getClass()) {
/* 39 */       return false;
/*    */     }
/*    */     
/* 42 */     FlowEdge flowEdge = (FlowEdge)o;
/* 43 */     return (flowEdge.predecessor == this.predecessor && flowEdge.successor == this.successor);
/*    */   }
/*    */ 
/*    */   
/*    */   public BasicBlock getPredecessor() {
/* 48 */     return this.predecessor;
/*    */   }
/*    */   
/*    */   public BasicBlock getSuccessor() {
/* 52 */     return this.successor;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 58 */     int result = this.predecessor.hashCode();
/* 59 */     result = 31 * result + this.successor.hashCode();
/* 60 */     return result;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 65 */     return getPredecessor().getDebugId() + " -> " + getSuccessor().getDebugId();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/cfg/FlowEdge.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */