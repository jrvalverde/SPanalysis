/*     */ package org.renjin.primitives.combine;
/*     */ 
/*     */ import org.renjin.sexp.ComplexVector;
/*     */ import org.renjin.sexp.DoubleVector;
/*     */ import org.renjin.sexp.IntVector;
/*     */ import org.renjin.sexp.ListVector;
/*     */ import org.renjin.sexp.LogicalVector;
/*     */ import org.renjin.sexp.Null;
/*     */ import org.renjin.sexp.RawVector;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.SexpVisitor;
/*     */ import org.renjin.sexp.StringVector;
/*     */ import org.renjin.sexp.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Inspector
/*     */   extends SexpVisitor<Vector.Type>
/*     */ {
/*     */   public static final int DEFERRED_THRESHOLD = 2000;
/*     */   public static final int DEFERRED_ARGUMENT_LIMIT = 200;
/*     */   private boolean recursive = false;
/*  37 */   private int vectorCount = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  42 */   private int elementCount = 0;
/*  43 */   private Vector.Type resultType = Null.VECTOR_TYPE;
/*     */ 
/*     */   
/*     */   private boolean deferredElements = false;
/*     */ 
/*     */ 
/*     */   
/*     */   Inspector(boolean recursive) {
/*  51 */     this.recursive = recursive;
/*     */   }
/*     */ 
/*     */   
/*     */   public void visit(DoubleVector vector) {
/*  56 */     this.resultType = Vector.Type.widest(this.resultType, (Vector)vector);
/*  57 */     this.elementCount += vector.length();
/*  58 */     this.deferredElements = (this.deferredElements || vector.isDeferred());
/*  59 */     this.vectorCount++;
/*     */   }
/*     */ 
/*     */   
/*     */   public void visit(IntVector vector) {
/*  64 */     this.resultType = Vector.Type.widest(this.resultType, (Vector)vector);
/*  65 */     this.elementCount += vector.length();
/*  66 */     this.deferredElements = (this.deferredElements || vector.isDeferred());
/*  67 */     this.vectorCount++;
/*     */   }
/*     */ 
/*     */   
/*     */   public void visit(LogicalVector vector) {
/*  72 */     this.resultType = Vector.Type.widest(this.resultType, (Vector)vector);
/*  73 */     this.elementCount += vector.length();
/*  74 */     this.deferredElements = (this.deferredElements || vector.isDeferred());
/*  75 */     this.vectorCount++;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void visit(Null nullExpression) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void visit(StringVector vector) {
/*  85 */     this.resultType = Vector.Type.widest(this.resultType, (Vector)vector);
/*  86 */     this.elementCount += vector.length();
/*  87 */     this.deferredElements = (this.deferredElements || vector.isDeferred());
/*  88 */     this.vectorCount++;
/*     */   }
/*     */ 
/*     */   
/*     */   public void visit(ComplexVector vector) {
/*  93 */     this.resultType = Vector.Type.widest(this.resultType, (Vector)vector);
/*  94 */     this.elementCount += vector.length();
/*  95 */     this.deferredElements = (this.deferredElements || vector.isDeferred());
/*  96 */     this.vectorCount++;
/*     */   }
/*     */ 
/*     */   
/*     */   public void visit(RawVector vector) {
/* 101 */     this.resultType = Vector.Type.widest(this.resultType, (Vector)vector);
/* 102 */     this.elementCount += vector.length();
/* 103 */     this.deferredElements = (this.deferredElements || vector.isDeferred());
/* 104 */     this.vectorCount++;
/*     */   }
/*     */ 
/*     */   
/*     */   public void visit(ListVector list) {
/* 109 */     if (this.recursive) {
/* 110 */       acceptAll((Iterable)list);
/*     */     } else {
/* 112 */       this.resultType = Vector.Type.widest(this.resultType, (Vector)list);
/* 113 */       this.elementCount += list.length();
/* 114 */       this.vectorCount++;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void unhandled(SEXP exp) {
/* 120 */     this.resultType = Vector.Type.widest(this.resultType, ListVector.VECTOR_TYPE);
/* 121 */     this.elementCount++;
/* 122 */     this.vectorCount++;
/*     */   }
/*     */   
/*     */   public CombinedBuilder newBuilder() {
/* 126 */     if (LazyBuilder.resultTypeSupported(this.resultType) && (
/* 127 */       this.deferredElements || (this.elementCount > 2000 && this.vectorCount <= 200)))
/*     */     {
/*     */ 
/*     */       
/* 131 */       return new LazyBuilder(this.resultType, this.vectorCount);
/*     */     }
/*     */ 
/*     */     
/* 135 */     return new MaterializedBuilder(this.resultType);
/*     */   }
/*     */ 
/*     */   
/*     */   public Vector.Type getResult() {
/* 140 */     return this.resultType;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/combine/Inspector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */