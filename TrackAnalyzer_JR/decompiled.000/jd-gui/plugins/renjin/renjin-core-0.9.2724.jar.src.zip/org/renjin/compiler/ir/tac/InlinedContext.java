/*    */ package org.renjin.compiler.ir.tac;
/*    */ 
/*    */ import org.renjin.compiler.ir.tac.functions.TranslationContext;
/*    */ import org.renjin.sexp.Null;
/*    */ import org.renjin.sexp.PairList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InlinedContext
/*    */   implements TranslationContext
/*    */ {
/*    */   private PairList formals;
/*    */   
/*    */   public InlinedContext(PairList formals) {
/* 31 */     this.formals = formals;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public PairList getEllipsesArguments() {
/* 37 */     return (PairList)Null.INSTANCE;
/*    */   }
/*    */   
/*    */   public PairList getFormals() {
/* 41 */     return this.formals;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/ir/tac/InlinedContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */