/*    */ package org.renjin.compiler.ir.tac.expressions;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.renjin.compiler.codegen.EmitContext;
/*    */ import org.renjin.compiler.ir.ValueBounds;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ import org.renjin.repackaged.asm.commons.InstructionAdapter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Length
/*    */   extends SpecializedCallExpression
/*    */   implements SimpleExpression
/*    */ {
/*    */   public Length(Expression vector) {
/* 41 */     super(new Expression[] { vector });
/*    */   }
/*    */   
/*    */   public Expression getVector() {
/* 45 */     return this.arguments[0];
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isFunctionDefinitelyPure() {
/* 50 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public int load(EmitContext emitContext, InstructionAdapter mv) {
/* 55 */     int stackSizeIncrease = getVector().load(emitContext, mv);
/* 56 */     mv.visitMethodInsn(185, "org/renjin/sexp/SEXP", "length", "()I", true);
/* 57 */     return stackSizeIncrease;
/*    */   }
/*    */ 
/*    */   
/*    */   public Type getType() {
/* 62 */     return Type.INT_TYPE;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 67 */     return "length(" + getVector() + ")";
/*    */   }
/*    */ 
/*    */   
/*    */   public ValueBounds updateTypeBounds(Map<Expression, ValueBounds> typeMap) {
/* 72 */     return ValueBounds.INT_PRIMITIVE;
/*    */   }
/*    */ 
/*    */   
/*    */   public ValueBounds getValueBounds() {
/* 77 */     return ValueBounds.INT_PRIMITIVE;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/ir/tac/expressions/Length.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */