/*    */ package org.renjin.compiler.ir.tac.expressions;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.renjin.compiler.ir.ValueBounds;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class SpecializedCallExpression
/*    */   implements Expression
/*    */ {
/*    */   protected final Expression[] arguments;
/*    */   
/*    */   public SpecializedCallExpression(Expression... arguments) {
/* 29 */     this.arguments = arguments;
/*    */   }
/*    */ 
/*    */   
/*    */   public final void setChild(int childIndex, Expression child) {
/* 34 */     this.arguments[childIndex] = child;
/*    */   }
/*    */ 
/*    */   
/*    */   public final int getChildCount() {
/* 39 */     return this.arguments.length;
/*    */   }
/*    */ 
/*    */   
/*    */   public final Expression childAt(int index) {
/* 44 */     return this.arguments[index];
/*    */   }
/*    */ 
/*    */   
/*    */   public abstract boolean isFunctionDefinitelyPure();
/*    */   
/*    */   public boolean isPure() {
/* 51 */     if (!isFunctionDefinitelyPure()) {
/* 52 */       return false;
/*    */     }
/* 54 */     for (int i = 0; i != this.arguments.length; i++) {
/* 55 */       if (!this.arguments[i].isPure()) {
/* 56 */         return false;
/*    */       }
/*    */     } 
/* 59 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public ValueBounds updateTypeBounds(Map<Expression, ValueBounds> typeMap) {
/* 64 */     return ValueBounds.UNBOUNDED;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/ir/tac/expressions/SpecializedCallExpression.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */