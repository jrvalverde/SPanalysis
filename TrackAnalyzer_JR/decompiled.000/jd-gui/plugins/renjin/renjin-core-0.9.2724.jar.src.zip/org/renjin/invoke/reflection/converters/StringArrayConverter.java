/*    */ package org.renjin.invoke.reflection.converters;
/*    */ 
/*    */ import org.renjin.sexp.AtomicVector;
/*    */ import org.renjin.sexp.SEXP;
/*    */ import org.renjin.sexp.StringArrayVector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StringArrayConverter
/*    */   implements Converter<String[]>
/*    */ {
/* 31 */   public static final Converter INSTANCE = new StringArrayConverter();
/*    */ 
/*    */ 
/*    */   
/*    */   public static boolean accept(Class clazz) {
/* 36 */     return (clazz.isArray() && clazz.getComponentType() == String.class);
/*    */   }
/*    */ 
/*    */   
/*    */   public SEXP convertToR(String[] value) {
/* 41 */     return (SEXP)new StringArrayVector(value);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean acceptsSEXP(SEXP exp) {
/* 46 */     return exp instanceof org.renjin.sexp.StringVector;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object convertToJava(SEXP value) {
/* 51 */     AtomicVector vector = (AtomicVector)value;
/* 52 */     String[] array = new String[value.length()];
/* 53 */     for (int i = 0; i != value.length(); i++) {
/* 54 */       array[i] = vector.getElementAsString(i);
/*    */     }
/* 56 */     return array;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getSpecificity() {
/* 61 */     return 10;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/reflection/converters/StringArrayConverter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */