/*     */ package org.renjin.primitives.io.connections;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import org.renjin.eval.EvalException;
/*     */ import org.renjin.repackaged.guava.base.Charsets;
/*     */ import org.renjin.repackaged.guava.io.ByteStreams;
/*     */ import org.renjin.sexp.ComplexArrayVector;
/*     */ import org.renjin.sexp.DoubleArrayVector;
/*     */ import org.renjin.sexp.IntArrayVector;
/*     */ import org.renjin.sexp.IntVector;
/*     */ import org.renjin.sexp.RawVector;
/*     */ import org.renjin.sexp.StringVector;
/*     */ import org.renjin.sexp.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BinaryReader
/*     */ {
/*     */   private InputStream in;
/*     */   
/*     */   public BinaryReader(RawVector rawVector) {
/*  36 */     this(new ByteArrayInputStream(rawVector.toByteArrayUnsafe()));
/*     */   }
/*     */   
/*     */   public BinaryReader(InputStream inputStream) {
/*  40 */     this.in = inputStream;
/*     */   }
/*     */   
/*     */   public Vector readIntVector(int n, int size, boolean signed, boolean swap) throws IOException {
/*  44 */     if (IntVector.isNA(size)) {
/*  45 */       size = 4;
/*     */     }
/*     */     
/*  48 */     if (size != 4) {
/*  49 */       throw new EvalException("TODO: size = " + size, new Object[0]);
/*     */     }
/*     */     
/*  52 */     if (!signed) {
/*  53 */       throw new EvalException("TODO: signed = false", new Object[0]);
/*     */     }
/*     */     
/*  56 */     if (swap) {
/*  57 */       throw new EvalException("TODO: swap = TRUE", new Object[0]);
/*     */     }
/*     */     
/*  60 */     int[] vector = new int[n];
/*  61 */     byte[] buffer = new byte[size];
/*     */     
/*  63 */     for (int i = 0; i < n; i++) {
/*  64 */       ByteStreams.readFully(this.in, buffer);
/*  65 */       vector[i] = buffer[3] << 24 | (buffer[2] & 0xFF) << 16 | (buffer[1] & 0xFF) << 8 | buffer[0] & 0xFF;
/*     */     } 
/*     */     
/*  68 */     return (Vector)IntArrayVector.unsafe(vector);
/*     */   }
/*     */   public Vector readDoubleVector(int n, int size, boolean swap) throws IOException {
/*     */     double[] values;
/*  72 */     if (IntVector.isNA(size)) {
/*  73 */       size = 8;
/*     */     }
/*     */     
/*  76 */     switch (size) {
/*     */       case 4:
/*  78 */         values = readBinFloatArray(n, swap);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  87 */         return (Vector)DoubleArrayVector.unsafe(values);case 8: values = readBinDoubleArray(n, swap); return (Vector)DoubleArrayVector.unsafe(values);
/*     */     } 
/*     */     throw new EvalException("Unsupported size = " + size + " for numeric vector", new Object[0]);
/*     */   } public Vector readComplexVector(int n, int size, boolean swap) throws IOException {
/*     */     double[] values;
/*  92 */     if (IntVector.isNA(size)) {
/*  93 */       size = 16;
/*     */     }
/*     */     
/*  96 */     switch (size) {
/*     */       case 8:
/*  98 */         values = readBinFloatArray(n * 2, swap);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 107 */         return (Vector)ComplexArrayVector.unsafe(values);case 16: values = readBinDoubleArray(n * 2, swap); return (Vector)ComplexArrayVector.unsafe(values);
/*     */     } 
/*     */     throw new EvalException("Unsupported size = " + size + " for complex vector", new Object[0]);
/*     */   }
/*     */   private double[] readBinDoubleArray(int n, boolean swap) throws IOException {
/* 112 */     double[] vector = new double[n];
/* 113 */     byte[] buffer = new byte[8];
/*     */     
/* 115 */     for (int i = 0; i < n; i++) {
/* 116 */       long longValue; ByteStreams.readFully(this.in, buffer);
/*     */       
/* 118 */       if (swap) {
/* 119 */         longValue = (buffer[0] << 56L) + ((buffer[1] & 0xFF) << 48L) + ((buffer[2] & 0xFF) << 40L) + ((buffer[3] & 0xFF) << 32L) + ((buffer[4] & 0xFF) << 24L) + ((buffer[5] & 0xFF) << 16) + ((buffer[6] & 0xFF) << 8) + ((buffer[7] & 0xFF) << 0);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       }
/*     */       else {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 130 */         longValue = (buffer[7] << 56L) + ((buffer[6] & 0xFF) << 48L) + ((buffer[5] & 0xFF) << 40L) + ((buffer[4] & 0xFF) << 32L) + ((buffer[3] & 0xFF) << 24L) + ((buffer[2] & 0xFF) << 16) + ((buffer[1] & 0xFF) << 8) + ((buffer[0] & 0xFF) << 0);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 139 */       vector[i] = Double.longBitsToDouble(longValue);
/*     */     } 
/* 141 */     return vector;
/*     */   }
/*     */ 
/*     */   
/*     */   private double[] readBinFloatArray(int n, boolean swap) throws IOException {
/* 146 */     double[] vector = new double[n];
/* 147 */     byte[] buffer = new byte[4];
/*     */     
/* 149 */     for (int i = 0; i < n; i++) {
/* 150 */       int intValue; ByteStreams.readFully(this.in, buffer);
/*     */       
/* 152 */       if (swap) {
/* 153 */         intValue = buffer[0] << 24 | (buffer[1] & 0xFF) << 16 | (buffer[2] & 0xFF) << 8 | buffer[3] & 0xFF;
/*     */       } else {
/* 155 */         intValue = buffer[3] << 24 | (buffer[2] & 0xFF) << 16 | (buffer[1] & 0xFF) << 8 | buffer[0] & 0xFF;
/*     */       } 
/* 157 */       vector[i] = Float.intBitsToFloat(intValue);
/*     */     } 
/* 159 */     return vector;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector readCharacterVector(int n, int size, boolean swap) throws IOException {
/* 165 */     StringVector.Builder vector = new StringVector.Builder(0, n);
/* 166 */     ByteArrayOutputStream buffer = new ByteArrayOutputStream();
/*     */     
/* 168 */     for (int i = 0; i < n; i++) {
/* 169 */       buffer.reset();
/*     */       while (true) {
/* 171 */         int b = this.in.read();
/* 172 */         if (b <= 0) {
/*     */           break;
/*     */         }
/* 175 */         buffer.write(b);
/*     */       } 
/* 177 */       vector.add(buffer.toString(Charsets.UTF_8.name()));
/*     */     } 
/* 179 */     return (Vector)vector.build();
/*     */   }
/*     */   
/*     */   public Vector readRaw(int n, int size) throws IOException {
/* 183 */     int byteCount = n;
/* 184 */     byte[] buffer = new byte[byteCount];
/*     */     
/* 186 */     int offset = 0;
/* 187 */     while (byteCount > 0) {
/* 188 */       int bytesRead = this.in.read(buffer, offset, byteCount);
/* 189 */       byteCount -= bytesRead;
/* 190 */       offset += bytesRead;
/*     */     } 
/* 192 */     return (Vector)RawVector.unsafe(buffer);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/io/connections/BinaryReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */