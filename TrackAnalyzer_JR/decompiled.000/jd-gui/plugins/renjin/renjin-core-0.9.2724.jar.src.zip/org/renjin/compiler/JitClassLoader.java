/*    */ package org.renjin.compiler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JitClassLoader
/*    */ {
/*    */   public static <T> Class<T> defineClass(Class<T> classType, String className, byte[] bytes) {
/* 27 */     MyClassLoader myClassLoader = new MyClassLoader(JitClassLoader.class.getClassLoader());
/* 28 */     return myClassLoader.defineClass(className, bytes);
/*    */   }
/*    */   
/*    */   private static class MyClassLoader extends ClassLoader {
/*    */     MyClassLoader(ClassLoader parent) {
/* 33 */       super(parent);
/*    */     }
/*    */     
/*    */     Class defineClass(String name, byte[] b) {
/* 37 */       return defineClass(name, b, 0, b.length);
/*    */     }
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/JitClassLoader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */