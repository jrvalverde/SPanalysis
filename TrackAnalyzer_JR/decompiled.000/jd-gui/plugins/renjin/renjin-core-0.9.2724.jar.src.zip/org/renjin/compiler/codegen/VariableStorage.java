/*    */ package org.renjin.compiler.codegen;
/*    */ 
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VariableStorage
/*    */ {
/*    */   private int slotIndex;
/*    */   private Type type;
/*    */   
/*    */   public VariableStorage(int slotIndex, Type type) {
/* 28 */     this.slotIndex = slotIndex;
/* 29 */     this.type = type;
/*    */   }
/*    */   
/*    */   public int getSlotIndex() {
/* 33 */     return this.slotIndex;
/*    */   }
/*    */   
/*    */   public Type getType() {
/* 37 */     return this.type;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 42 */     return "VariableStorage{slotIndex=" + this.slotIndex + ", type=" + this.type + '}';
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/codegen/VariableStorage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */