/*    */ package org.renjin.eval;
/*    */ 
/*    */ import org.renjin.sexp.Closure;
/*    */ import org.renjin.sexp.FunctionCall;
/*    */ import org.renjin.sexp.PairList;
/*    */ import org.renjin.sexp.SEXP;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FinalizationClosure
/*    */   implements FinalizationHandler
/*    */ {
/*    */   private Closure function;
/*    */   
/*    */   public FinalizationClosure(Closure function) {
/* 30 */     this.function = function;
/*    */   }
/*    */ 
/*    */   
/*    */   public void finalizeSexp(Context context, SEXP sexp) {
/* 35 */     context.evaluate((SEXP)new FunctionCall((SEXP)this.function, (PairList)PairList.Node.singleton(sexp)));
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/eval/FinalizationClosure.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */