package org.renjin.compiler.ir.tac.statements;

public interface StatementVisitor {
  void visitAssignment(Assignment paramAssignment);
  
  void visitExprStatement(ExprStatement paramExprStatement);
  
  void visitGoto(GotoStatement paramGotoStatement);
  
  void visitIf(IfStatement paramIfStatement);
  
  void visitReturn(ReturnStatement paramReturnStatement);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/ir/tac/statements/StatementVisitor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */