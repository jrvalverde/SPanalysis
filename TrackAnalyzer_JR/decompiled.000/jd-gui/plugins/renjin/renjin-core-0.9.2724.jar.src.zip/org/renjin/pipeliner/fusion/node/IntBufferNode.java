/*     */ package org.renjin.pipeliner.fusion.node;
/*     */ 
/*     */ import java.util.Optional;
/*     */ import org.renjin.pipeliner.ComputeMethod;
/*     */ import org.renjin.repackaged.asm.Label;
/*     */ import org.renjin.repackaged.asm.MethodVisitor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IntBufferNode
/*     */   extends LoopNode
/*     */ {
/*     */   private int operandIndex;
/*     */   private int bufferLocal;
/*     */   private int bufferLengthLocal;
/*     */   
/*     */   public IntBufferNode(int operandIndex) {
/*  46 */     this.operandIndex = operandIndex;
/*     */   }
/*     */ 
/*     */   
/*     */   public void init(ComputeMethod method) {
/*  51 */     this.bufferLocal = method.reserveLocal(1);
/*  52 */     this.bufferLengthLocal = method.reserveLocal(1);
/*     */     
/*  54 */     MethodVisitor mv = method.getVisitor();
/*  55 */     mv.visitVarInsn(25, method.getOperandsLocalIndex());
/*  56 */     pushIntConstant(mv, this.operandIndex);
/*  57 */     mv.visitInsn(50);
/*  58 */     mv.visitTypeInsn(192, "org/renjin/sexp/IntBufferVector");
/*  59 */     mv.visitMethodInsn(182, "org/renjin/sexp/IntBufferVector", "toIntBufferUnsafe", "()Ljava/nio/IntBuffer;", false);
/*  60 */     mv.visitInsn(89);
/*  61 */     mv.visitVarInsn(58, this.bufferLocal);
/*  62 */     mv.visitMethodInsn(182, "java/nio/IntBuffer", "remaining", "()I", false);
/*  63 */     mv.visitVarInsn(54, this.bufferLengthLocal);
/*     */   }
/*     */ 
/*     */   
/*     */   public void pushLength(ComputeMethod method) {
/*  68 */     MethodVisitor mv = method.getVisitor();
/*  69 */     mv.visitVarInsn(21, this.bufferLengthLocal);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void pushElementAsDouble(ComputeMethod method, Optional<Label> integerNaLabel) {
/*  75 */     pushElementAsInt(method, integerNaLabel);
/*     */     
/*  77 */     MethodVisitor mv = method.getVisitor();
/*  78 */     mv.visitInsn(135);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void pushElementAsInt(ComputeMethod method, Optional<Label> naLabel) {
/*  84 */     MethodVisitor mv = method.getVisitor();
/*     */     
/*  86 */     mv.visitVarInsn(25, this.bufferLocal);
/*     */     
/*  88 */     mv.visitInsn(95);
/*     */     
/*  90 */     mv.visitMethodInsn(182, "java/nio/IntBuffer", "get", "(I)I", false);
/*     */ 
/*     */     
/*  93 */     doIntegerNaCheck(mv, naLabel);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean mustCheckForIntegerNAs() {
/*  98 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void appendToKey(StringBuilder key) {
/* 103 */     key.append("IBN");
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 108 */     return "x" + this.operandIndex;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/pipeliner/fusion/node/IntBufferNode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */