/*    */ package org.renjin.compiler.ir.tac.functions;
/*    */ 
/*    */ import org.renjin.compiler.ir.tac.IRBodyBuilder;
/*    */ import org.renjin.compiler.ir.tac.expressions.Constant;
/*    */ import org.renjin.compiler.ir.tac.expressions.Expression;
/*    */ import org.renjin.sexp.Function;
/*    */ import org.renjin.sexp.FunctionCall;
/*    */ import org.renjin.sexp.Null;
/*    */ import org.renjin.sexp.PairList;
/*    */ import org.renjin.sexp.SEXP;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BracketTranslator
/*    */   extends FunctionCallTranslator
/*    */ {
/*    */   public Expression translateToExpression(IRBodyBuilder builder, TranslationContext context, Function resolvedFunction, FunctionCall call) {
/* 32 */     if (call.getArguments().length() == 0) {
/* 33 */       return (Expression)Constant.NULL;
/*    */     }
/* 35 */     for (PairList.Node arg : call.getArguments().nodes()) {
/* 36 */       if (arg.hasNextNode()) {
/* 37 */         builder.translateStatements(context, arg.getValue()); continue;
/*    */       } 
/* 39 */       return builder.translateExpression(context, arg.getValue());
/*    */     } 
/*    */     
/* 42 */     throw new Error("unreachable");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void addStatement(IRBodyBuilder builder, TranslationContext context, Function resolvedFunction, FunctionCall call) {
/* 48 */     if (call.getArguments() != Null.INSTANCE)
/* 49 */       for (SEXP arg : call.getArguments().values())
/* 50 */         builder.translateStatements(context, arg);  
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/ir/tac/functions/BracketTranslator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */