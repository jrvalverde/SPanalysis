/*    */ package org.renjin.invoke.codegen;
/*    */ 
/*    */ import com.sun.codemodel.JBlock;
/*    */ import com.sun.codemodel.JCatchBlock;
/*    */ import com.sun.codemodel.JClass;
/*    */ import com.sun.codemodel.JCodeModel;
/*    */ import com.sun.codemodel.JExpr;
/*    */ import com.sun.codemodel.JExpression;
/*    */ import com.sun.codemodel.JTryBlock;
/*    */ import com.sun.codemodel.JVar;
/*    */ import org.renjin.eval.EvalException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExceptionWrapper
/*    */ {
/*    */   private JTryBlock tryBlock;
/*    */   private JCodeModel codeModel;
/*    */   private JExpression context;
/*    */   
/*    */   public ExceptionWrapper(JCodeModel codeModel, JBlock parent, JExpression context) {
/* 33 */     this.codeModel = codeModel;
/* 34 */     this.context = context;
/* 35 */     this.tryBlock = parent._try();
/*    */   }
/*    */   
/*    */   public JBlock body() {
/* 39 */     return this.tryBlock.body();
/*    */   }
/*    */   
/*    */   public void catchEvalExceptions() {
/* 43 */     JCatchBlock catchBlock = this.tryBlock._catch(this.codeModel.ref(EvalException.class));
/* 44 */     JVar e = catchBlock.param("e");
/* 45 */     catchBlock.body().invoke((JExpression)e, "initContext").arg(this.context);
/* 46 */     catchBlock.body()._throw((JExpression)e);
/*    */   }
/*    */   
/*    */   public void catchRuntimeExceptions() {
/* 50 */     JCatchBlock catchBlock = this.tryBlock._catch(this.codeModel.ref(RuntimeException.class));
/* 51 */     JVar e = catchBlock.param("e");
/* 52 */     catchBlock.body()._throw((JExpression)e);
/*    */   }
/*    */   
/*    */   public void catchExceptions() {
/* 56 */     JCatchBlock catchBlock = this.tryBlock._catch(this.codeModel.ref(Exception.class));
/* 57 */     JVar e = catchBlock.param("e");
/* 58 */     catchBlock.body()._throw((JExpression)JExpr._new(this.codeModel.ref(EvalException.class)).arg((JExpression)e));
/*    */   }
/*    */   
/*    */   public JCatchBlock _catch(JClass jClass) {
/* 62 */     return this.tryBlock._catch(jClass);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/codegen/ExceptionWrapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */