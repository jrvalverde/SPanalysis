/*    */ package org.renjin.primitives.special;
/*    */ 
/*    */ import org.renjin.eval.Context;
/*    */ import org.renjin.sexp.AttributeMap;
/*    */ import org.renjin.sexp.Environment;
/*    */ import org.renjin.sexp.FunctionCall;
/*    */ import org.renjin.sexp.PairList;
/*    */ import org.renjin.sexp.SEXP;
/*    */ import org.renjin.sexp.SpecialFunction;
/*    */ import org.renjin.sexp.Symbols;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TildeFunction
/*    */   extends SpecialFunction
/*    */ {
/*    */   public TildeFunction() {
/* 27 */     super("~");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public FunctionCall apply(Context context, Environment rho, FunctionCall call, PairList args) {
/* 34 */     return new FunctionCall(call.getFunction(), call.getArguments(), 
/* 35 */         AttributeMap.builder()
/* 36 */         .setClass(new String[] { "formula"
/* 37 */           }).set(Symbols.DOT_ENVIRONMENT, (SEXP)rho)
/* 38 */         .build());
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/special/TildeFunction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */