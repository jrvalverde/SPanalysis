/*    */ package org.renjin.base.internals;
/*    */ 
/*    */ import java.util.Set;
/*    */ import org.renjin.invoke.annotations.Internal;
/*    */ import org.renjin.repackaged.guava.collect.Sets;
/*    */ import org.renjin.sexp.ExpressionVector;
/*    */ import org.renjin.sexp.FunctionCall;
/*    */ import org.renjin.sexp.SEXP;
/*    */ import org.renjin.sexp.SexpVisitor;
/*    */ import org.renjin.sexp.StringArrayVector;
/*    */ import org.renjin.sexp.StringVector;
/*    */ import org.renjin.sexp.Symbol;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AllNamesVisitor
/*    */   extends SexpVisitor<StringVector>
/*    */ {
/* 29 */   private StringVector.Builder names = StringVector.newBuilder();
/* 30 */   private Set<Symbol> set = Sets.newIdentityHashSet();
/*    */   
/*    */   private boolean includeFunctionNames;
/*    */   private int maxNames;
/*    */   private boolean unique;
/*    */   
/*    */   public void visit(ExpressionVector vector) {
/* 37 */     for (SEXP expr : vector) {
/* 38 */       expr.accept(this);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public void visit(FunctionCall call) {
/* 44 */     if (this.includeFunctionNames) {
/* 45 */       call.getFunction().accept(this);
/*    */     }
/* 47 */     for (SEXP expr : call.getArguments().values()) {
/* 48 */       expr.accept(this);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public void visit(Symbol name) {
/* 54 */     if ((!this.unique || !this.set.contains(name)) && (
/* 55 */       this.maxNames == -1 || this.names.length() < this.maxNames)) {
/* 56 */       this.names.add((SEXP)StringArrayVector.valueOf(name.getPrintName()));
/* 57 */       this.set.add(name);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   @Internal("all.names")
/*    */   public static StringVector allNames(SEXP expr, boolean function, int maxNames, boolean unique) {
/* 64 */     AllNamesVisitor visitor = new AllNamesVisitor();
/* 65 */     visitor.includeFunctionNames = function;
/* 66 */     visitor.maxNames = maxNames;
/* 67 */     visitor.unique = unique;
/* 68 */     expr.accept(visitor);
/* 69 */     return (StringVector)visitor.names.build();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/base/internals/AllNamesVisitor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */