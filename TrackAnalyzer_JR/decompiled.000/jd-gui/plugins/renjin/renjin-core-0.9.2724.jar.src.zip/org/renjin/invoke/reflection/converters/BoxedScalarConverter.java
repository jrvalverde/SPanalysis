/*    */ package org.renjin.invoke.reflection.converters;
/*    */ 
/*    */ import org.renjin.eval.EvalException;
/*    */ import org.renjin.sexp.Null;
/*    */ import org.renjin.sexp.SEXP;
/*    */ import org.renjin.sexp.Vector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class BoxedScalarConverter<T>
/*    */   implements Converter<T>, AtomicVectorConverter
/*    */ {
/*    */   public final Object convertToJava(SEXP value) {
/* 32 */     if (!(value instanceof org.renjin.sexp.AtomicVector)) {
/* 33 */       throw new EvalException("Cannot convert '%s' to boolean", new Object[] { value.getTypeName() });
/*    */     }
/* 35 */     Vector vector = (Vector)value;
/* 36 */     if (vector == Null.INSTANCE || vector.isElementNA(0)) {
/* 37 */       return null;
/*    */     }
/* 39 */     return getFirstElement((Vector)value);
/*    */   }
/*    */   
/*    */   protected abstract Object getFirstElement(Vector paramVector);
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/reflection/converters/BoxedScalarConverter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */