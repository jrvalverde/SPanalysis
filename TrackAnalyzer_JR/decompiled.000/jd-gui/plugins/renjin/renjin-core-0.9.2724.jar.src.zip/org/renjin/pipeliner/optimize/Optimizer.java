package org.renjin.pipeliner.optimize;

import org.renjin.pipeliner.DeferredGraph;
import org.renjin.pipeliner.node.FunctionNode;

public interface Optimizer {
  boolean optimize(DeferredGraph paramDeferredGraph, FunctionNode paramFunctionNode);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/pipeliner/optimize/Optimizer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */