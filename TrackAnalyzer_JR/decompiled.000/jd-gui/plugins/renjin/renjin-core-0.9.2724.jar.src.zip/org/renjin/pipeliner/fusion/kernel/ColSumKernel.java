/*     */ package org.renjin.pipeliner.fusion.kernel;
/*     */ 
/*     */ import java.util.Optional;
/*     */ import org.renjin.pipeliner.ComputeMethod;
/*     */ import org.renjin.pipeliner.fusion.node.LoopNode;
/*     */ import org.renjin.repackaged.asm.Label;
/*     */ import org.renjin.repackaged.asm.MethodVisitor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ColSumKernel
/*     */   implements LoopKernel
/*     */ {
/*     */   public void compute(ComputeMethod method, LoopNode[] operands) {
/*     */     Optional<Label> integerNaLabel;
/*  36 */     MethodVisitor mv = method.getVisitor();
/*     */     
/*  38 */     LoopNode matrix = operands[0];
/*  39 */     matrix.init(method);
/*     */     
/*  41 */     LoopNode numColumnsAccessor = operands[1];
/*  42 */     numColumnsAccessor.init(method);
/*     */     
/*  44 */     int numColumns = method.reserveLocal(1);
/*     */ 
/*     */     
/*  47 */     int resultArray = method.reserveLocal(1);
/*  48 */     numColumnsAccessor.pushElementAsInt(method, 0);
/*  49 */     mv.visitInsn(89);
/*  50 */     mv.visitVarInsn(54, numColumns);
/*  51 */     mv.visitIntInsn(188, 7);
/*  52 */     mv.visitVarInsn(58, resultArray);
/*     */ 
/*     */     
/*  55 */     int numRows = method.reserveLocal(1);
/*  56 */     matrix.pushLength(method);
/*  57 */     mv.visitVarInsn(21, numColumns);
/*  58 */     mv.visitInsn(108);
/*  59 */     mv.visitVarInsn(54, numRows);
/*     */ 
/*     */     
/*  62 */     int colIndex = method.declareCounter();
/*  63 */     int rowIndex = method.declareCounter();
/*  64 */     int sourceIndex = method.declareCounter();
/*     */     
/*  66 */     int sum = method.reserveLocal(2);
/*  67 */     mv.visitInsn(14);
/*  68 */     mv.visitVarInsn(57, sum);
/*     */     
/*  70 */     Label loopHead = new Label();
/*  71 */     Label nextElement = new Label();
/*     */ 
/*     */     
/*  74 */     if (matrix.mustCheckForIntegerNAs()) {
/*  75 */       integerNaLabel = Optional.of(new Label());
/*     */     } else {
/*  77 */       integerNaLabel = Optional.empty();
/*     */     } 
/*     */ 
/*     */     
/*  81 */     mv.visitLabel(loopHead);
/*     */ 
/*     */     
/*  84 */     mv.visitVarInsn(21, sourceIndex);
/*  85 */     matrix.pushElementAsDouble(method, integerNaLabel);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  90 */     mv.visitVarInsn(24, sum);
/*  91 */     mv.visitInsn(99);
/*  92 */     mv.visitVarInsn(57, sum);
/*     */     
/*  94 */     mv.visitJumpInsn(167, nextElement);
/*     */ 
/*     */     
/*  97 */     if (integerNaLabel.isPresent()) {
/*  98 */       mv.visitLabel(integerNaLabel.get());
/*     */       
/* 100 */       mv.visitInsn(87);
/*     */     } 
/*     */ 
/*     */     
/* 104 */     mv.visitLabel(nextElement);
/*     */ 
/*     */     
/* 107 */     mv.visitIincInsn(sourceIndex, 1);
/* 108 */     mv.visitIincInsn(rowIndex, 1);
/*     */ 
/*     */ 
/*     */     
/* 112 */     mv.visitVarInsn(21, rowIndex);
/* 113 */     mv.visitVarInsn(21, numRows);
/* 114 */     mv.visitJumpInsn(160, loopHead);
/*     */ 
/*     */ 
/*     */     
/* 118 */     mv.visitVarInsn(25, resultArray);
/* 119 */     mv.visitVarInsn(21, colIndex);
/* 120 */     mv.visitVarInsn(24, sum);
/* 121 */     mv.visitInsn(82);
/*     */ 
/*     */     
/* 124 */     mv.visitInsn(3);
/* 125 */     mv.visitVarInsn(54, rowIndex);
/*     */ 
/*     */     
/* 128 */     mv.visitInsn(14);
/* 129 */     mv.visitVarInsn(57, sum);
/*     */ 
/*     */     
/* 132 */     mv.visitIincInsn(colIndex, 1);
/*     */ 
/*     */     
/* 135 */     mv.visitVarInsn(21, colIndex);
/* 136 */     mv.visitVarInsn(21, numColumns);
/*     */     
/* 138 */     mv.visitJumpInsn(160, loopHead);
/*     */ 
/*     */     
/* 141 */     mv.visitVarInsn(25, resultArray);
/* 142 */     mv.visitInsn(176);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String debugLabel(LoopNode[] operands) {
/* 148 */     return "colSums(" + operands[0] + ")";
/*     */   }
/*     */ 
/*     */   
/*     */   public void appendToKey(StringBuilder key) {
/* 153 */     key.append("colSums");
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/pipeliner/fusion/kernel/ColSumKernel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */