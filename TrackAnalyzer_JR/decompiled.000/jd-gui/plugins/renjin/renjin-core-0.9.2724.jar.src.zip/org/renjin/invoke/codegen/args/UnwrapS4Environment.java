/*    */ package org.renjin.invoke.codegen.args;
/*    */ 
/*    */ import com.sun.codemodel.JCodeModel;
/*    */ import com.sun.codemodel.JExpression;
/*    */ import com.sun.codemodel.JVar;
/*    */ import org.renjin.invoke.codegen.ApplyMethodContext;
/*    */ import org.renjin.invoke.codegen.WrapperRuntime;
/*    */ import org.renjin.invoke.model.JvmMethod;
/*    */ import org.renjin.sexp.Environment;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UnwrapS4Environment
/*    */   extends ArgConverterStrategy
/*    */ {
/*    */   public UnwrapS4Environment(JvmMethod.Argument formal) {
/* 39 */     super(formal);
/*    */   }
/*    */   
/*    */   public static boolean accept(JvmMethod.Argument formal) {
/* 43 */     return formal.getClazz().equals(Environment.class);
/*    */   }
/*    */ 
/*    */   
/*    */   public JExpression getTestExpr(JCodeModel codeModel, JVar sexp) {
/* 48 */     return (JExpression)codeModel
/* 49 */       .ref(WrapperRuntime.class)
/* 50 */       .staticInvoke("isEnvironmentOrEnvironmentSubclass")
/* 51 */       .arg((JExpression)sexp);
/*    */   }
/*    */ 
/*    */   
/*    */   public JExpression convertArgument(ApplyMethodContext method, JExpression sexp) {
/* 56 */     return (JExpression)method.getCodeModel()
/* 57 */       .ref(WrapperRuntime.class)
/* 58 */       .staticInvoke("unwrapEnvironmentSuperClass")
/* 59 */       .arg(sexp);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/codegen/args/UnwrapS4Environment.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */