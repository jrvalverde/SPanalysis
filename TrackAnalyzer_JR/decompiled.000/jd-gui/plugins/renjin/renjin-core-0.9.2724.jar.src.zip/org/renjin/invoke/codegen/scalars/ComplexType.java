/*    */ package org.renjin.invoke.codegen.scalars;
/*    */ 
/*    */ import com.sun.codemodel.JCodeModel;
/*    */ import com.sun.codemodel.JExpression;
/*    */ import com.sun.codemodel.JVar;
/*    */ import org.apache.commons.math.complex.Complex;
/*    */ import org.renjin.sexp.ComplexArrayVector;
/*    */ import org.renjin.sexp.ComplexVector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ComplexType
/*    */   extends ScalarType
/*    */ {
/*    */   public Class<?> getScalarType() {
/* 34 */     return Complex.class;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getConversionMethod() {
/* 39 */     return "convertToComplexPrimitive";
/*    */   }
/*    */ 
/*    */   
/*    */   public String getAccessorMethod() {
/* 44 */     return "getElementAsComplex";
/*    */   }
/*    */ 
/*    */   
/*    */   public Class getVectorType() {
/* 49 */     return ComplexVector.class;
/*    */   }
/*    */ 
/*    */   
/*    */   public Class<ComplexArrayVector.Builder> getBuilderClass() {
/* 54 */     return ComplexArrayVector.Builder.class;
/*    */   }
/*    */ 
/*    */   
/*    */   public Class getBuilderArrayElementClass() {
/* 59 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   
/*    */   public Class getArrayVectorClass() {
/* 64 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   
/*    */   public JExpression naLiteral(JCodeModel codeModel) {
/* 69 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   
/*    */   public JExpression testNaExpr(JCodeModel codeModel, JVar scalarVariable) {
/* 74 */     return (JExpression)codeModel.ref(ComplexVector.class).staticInvoke("isNaN").arg((JExpression)scalarVariable);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/codegen/scalars/ComplexType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */