/*    */ package org.renjin.compiler.ir.tac.expressions;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.renjin.compiler.codegen.EmitContext;
/*    */ import org.renjin.compiler.codegen.VariableStorage;
/*    */ import org.renjin.compiler.ir.ValueBounds;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ import org.renjin.repackaged.asm.commons.InstructionAdapter;
/*    */ import org.renjin.sexp.SEXP;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class LValue
/*    */   implements SimpleExpression
/*    */ {
/* 35 */   private ValueBounds valueBounds = ValueBounds.UNBOUNDED;
/* 36 */   private Type type = Type.getType(SEXP.class);
/*    */ 
/*    */   
/*    */   public final int getChildCount() {
/* 40 */     return 0;
/*    */   }
/*    */ 
/*    */   
/*    */   public final Expression childAt(int index) {
/* 45 */     throw new IllegalArgumentException();
/*    */   }
/*    */ 
/*    */   
/*    */   public final void setChild(int i, Expression expr) {
/* 50 */     throw new IllegalArgumentException();
/*    */   }
/*    */ 
/*    */   
/*    */   public final int load(EmitContext emitContext, InstructionAdapter mv) {
/* 55 */     VariableStorage storage = emitContext.getVariableStorage(this);
/* 56 */     if (storage == null) {
/* 57 */       throw new IllegalStateException("No storage defined for " + this);
/*    */     }
/* 59 */     mv.load(storage.getSlotIndex(), storage.getType());
/* 60 */     return storage.getType().getSize();
/*    */   }
/*    */   
/*    */   public void update(ValueBounds valueBounds) {
/* 64 */     this.valueBounds = valueBounds;
/* 65 */     this.type = valueBounds.storageType();
/*    */   }
/*    */ 
/*    */   
/*    */   public final ValueBounds updateTypeBounds(Map<Expression, ValueBounds> typeMap) {
/* 70 */     ValueBounds type = typeMap.get(this);
/* 71 */     if (type == null) {
/* 72 */       this.valueBounds = ValueBounds.UNBOUNDED;
/*    */     } else {
/* 74 */       this.valueBounds = type;
/*    */     } 
/* 76 */     this.type = this.valueBounds.storageType();
/* 77 */     return this.valueBounds;
/*    */   }
/*    */ 
/*    */   
/*    */   public final ValueBounds getValueBounds() {
/* 82 */     return this.valueBounds;
/*    */   }
/*    */ 
/*    */   
/*    */   public Type getType() {
/* 87 */     return this.type;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/ir/tac/expressions/LValue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */