/*    */ package org.renjin.compiler.ir.tac.expressions;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.renjin.compiler.ir.ssa.SsaVariable;
/*    */ import org.renjin.repackaged.guava.collect.Maps;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Variable
/*    */   extends LValue
/*    */ {
/* 29 */   private Map<Integer, SsaVariable> versions = Maps.newHashMap();
/*    */   
/*    */   public SsaVariable getVersion(int versionNumber) {
/* 32 */     SsaVariable ssa = this.versions.get(Integer.valueOf(versionNumber));
/* 33 */     if (ssa == null) {
/* 34 */       ssa = new SsaVariable(this, versionNumber);
/* 35 */       this.versions.put(Integer.valueOf(versionNumber), ssa);
/*    */     } 
/* 37 */     return ssa;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/ir/tac/expressions/Variable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */