/*    */ package org.renjin.primitives.matrix;
/*    */ 
/*    */ import org.renjin.primitives.vector.MemoizedDoubleVector;
/*    */ import org.renjin.sexp.AttributeMap;
/*    */ import org.renjin.sexp.SEXP;
/*    */ import org.renjin.sexp.Vector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DeferredMatrixProduct
/*    */   extends MemoizedDoubleVector
/*    */ {
/*    */   private MatrixProduct product;
/*    */   
/*    */   public DeferredMatrixProduct(MatrixProduct product) {
/* 31 */     super(product.getOperands(), product.computeLength(), product.computeAttributes());
/* 32 */     this.product = product;
/*    */   }
/*    */   
/*    */   public DeferredMatrixProduct(MatrixProduct product, AttributeMap attributes) {
/* 36 */     super(product.getOperands(), product.computeLength(), attributes);
/* 37 */     this.product = product;
/*    */   }
/*    */ 
/*    */   
/*    */   protected SEXP cloneWithNewAttributes(AttributeMap attributes) {
/* 42 */     return (SEXP)new DeferredMatrixProduct(this.product, attributes);
/*    */   }
/*    */ 
/*    */   
/*    */   public Vector computeResult() {
/* 47 */     return this.product.computeResultVector(getAttributes());
/*    */   }
/*    */ 
/*    */   
/*    */   public String getComputationName() {
/* 52 */     return this.product.getName();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isConstantAccessTime() {
/* 57 */     return false;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/matrix/DeferredMatrixProduct.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */