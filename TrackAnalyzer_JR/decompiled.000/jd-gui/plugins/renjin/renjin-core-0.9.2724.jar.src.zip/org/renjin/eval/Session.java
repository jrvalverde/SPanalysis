/*     */ package org.renjin.eval;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.Reader;
/*     */ import java.lang.invoke.MethodHandle;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import org.apache.commons.vfs2.FileObject;
/*     */ import org.apache.commons.vfs2.FileSystemException;
/*     */ import org.apache.commons.vfs2.FileSystemManager;
/*     */ import org.renjin.pipeliner.VectorPipeliner;
/*     */ import org.renjin.primitives.Warning;
/*     */ import org.renjin.primitives.io.connections.ConnectionTable;
/*     */ import org.renjin.primitives.packaging.DllInfo;
/*     */ import org.renjin.primitives.packaging.NamespaceRegistry;
/*     */ import org.renjin.primitives.packaging.PackageLoader;
/*     */ import org.renjin.repackaged.guava.collect.ImmutableList;
/*     */ import org.renjin.repackaged.guava.collect.Lists;
/*     */ import org.renjin.repackaged.guava.collect.Maps;
/*     */ import org.renjin.s4.S4Cache;
/*     */ import org.renjin.sexp.Environment;
/*     */ import org.renjin.sexp.Frame;
/*     */ import org.renjin.sexp.FunctionCall;
/*     */ import org.renjin.sexp.IntVector;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.StringArrayVector;
/*     */ import org.renjin.sexp.StringVector;
/*     */ import org.renjin.sexp.Symbol;
/*     */ import org.renjin.stats.internals.distributions.RNG;
/*     */ import org.renjin.util.FileSystemUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Session
/*     */ {
/*  56 */   public static final List<String> DEFAULT_PACKAGES = (List<String>)ImmutableList.of("stats", "graphics", "grDevices", "utils", "datasets", "methods");
/*     */ 
/*     */   
/*     */   private final Context topLevelContext;
/*     */   
/*  61 */   private S4Cache s4Cache = new S4Cache();
/*     */   
/*  63 */   private FinalizerRegistry finalizers = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Map<String, String> systemEnvironment;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final NamespaceRegistry namespaceRegistry;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String homeDirectory;
/*     */ 
/*     */ 
/*     */   
/*     */   private final Environment baseEnvironment;
/*     */ 
/*     */ 
/*     */   
/*     */   private final Environment globalEnvironment;
/*     */ 
/*     */ 
/*     */   
/*     */   private final Environment baseNamespaceEnv;
/*     */ 
/*     */ 
/*     */   
/*     */   private final FileSystemManager fileSystemManager;
/*     */ 
/*     */ 
/*     */   
/*     */   private SecurityManager securityManager;
/*     */ 
/*     */ 
/*     */   
/* 102 */   private Map<Class, Object> singletons = Maps.newHashMap();
/*     */   
/* 104 */   private final ConnectionTable connectionTable = new ConnectionTable();
/*     */   
/*     */   private FileObject workingDirectory;
/*     */   
/* 108 */   private StringVector commandLineArguments = StringVector.valueOf("renjin");
/*     */   
/* 110 */   public RNG rng = new RNG(this);
/*     */   
/* 112 */   private SessionController sessionController = new SessionController();
/*     */ 
/*     */   
/*     */   private VectorPipeliner vectorPipeliner;
/*     */ 
/*     */   
/*     */   private ClassLoader classLoader;
/*     */ 
/*     */   
/* 121 */   private List<DllInfo> loadedLibraries = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean invisible;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 135 */   Context conditionStack = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Session(FileSystemManager fileSystemManager, ClassLoader classLoader, PackageLoader packageLoader, ExecutorService executorService, Frame globalFrame) {
/* 141 */     this.fileSystemManager = fileSystemManager;
/* 142 */     this.classLoader = classLoader;
/* 143 */     this.homeDirectory = FileSystemUtils.homeDirectoryInCoreJar(fileSystemManager);
/* 144 */     this.workingDirectory = FileSystemUtils.workingDirectory(fileSystemManager);
/* 145 */     this.systemEnvironment = Maps.newHashMap(System.getenv());
/* 146 */     this.baseEnvironment = Environment.createBaseEnvironment(this);
/* 147 */     this.globalEnvironment = Environment.createGlobalEnvironment(this.baseEnvironment, globalFrame);
/* 148 */     this.baseNamespaceEnv = Environment.createBaseNamespaceEnvironment(this.globalEnvironment, this.baseEnvironment).build();
/* 149 */     this.topLevelContext = new Context(this);
/* 150 */     this.baseNamespaceEnv.setVariableUnsafe(Symbol.get(".BaseNamespaceEnv"), (SEXP)this.baseNamespaceEnv);
/*     */     
/* 152 */     this.namespaceRegistry = new NamespaceRegistry(packageLoader, this.baseNamespaceEnv);
/* 153 */     this.securityManager = new SecurityManager();
/*     */     
/* 155 */     this.vectorPipeliner = new VectorPipeliner(executorService);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 161 */     this.globalEnvironment.setVariable(this.topLevelContext, ".Random.seed", (SEXP)IntVector.valueOf(1));
/*     */   }
/*     */ 
/*     */   
/*     */   public void setStdOut(PrintWriter writer) {
/* 166 */     this.connectionTable.getStdout().setStream(writer);
/*     */   }
/*     */   
/*     */   public void setStdIn(Reader reader) {
/* 170 */     this.connectionTable.getStdin().setReader(reader);
/*     */   }
/*     */   
/*     */   public void setStdErr(PrintWriter writer) {
/* 174 */     this.connectionTable.getStderr().setStream(writer);
/*     */   }
/*     */   
/*     */   public SessionController getSessionController() {
/* 178 */     return this.sessionController;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <X> X getSingleton(Class<X> clazz) {
/* 187 */     if (clazz == NamespaceRegistry.class) {
/* 188 */       return (X)this.namespaceRegistry;
/*     */     }
/* 190 */     X instance = (X)this.singletons.get(clazz);
/* 191 */     if (instance == null) {
/*     */       try {
/* 193 */         instance = clazz.newInstance();
/* 194 */       } catch (Exception e) {
/* 195 */         throw new RuntimeException("Can instantiate singleton " + clazz.getName() + ": the class must have a public default constructor", e);
/*     */       } 
/*     */       
/* 198 */       this.singletons.put(clazz, instance);
/*     */     } 
/* 200 */     return instance;
/*     */   }
/*     */ 
/*     */   
/*     */   public Options getOptions() {
/* 205 */     return getSingleton(Options.class);
/*     */   }
/*     */   
/*     */   public void setSessionController(SessionController sessionController) {
/* 209 */     this.sessionController = sessionController;
/*     */   }
/*     */   
/*     */   public RNG getRNG() {
/* 213 */     return this.rng;
/*     */   }
/*     */   
/*     */   public Environment getGlobalEnvironment() {
/* 217 */     return this.globalEnvironment;
/*     */   }
/*     */   
/*     */   public ConnectionTable getConnectionTable() {
/* 221 */     return this.connectionTable;
/*     */   }
/*     */   
/*     */   public void setWorkingDirectory(FileObject dir) {
/* 225 */     this.workingDirectory = dir;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setWorkingDirectory(File dir) throws FileSystemException {
/* 230 */     this.workingDirectory = this.fileSystemManager.resolveFile(dir.getAbsolutePath());
/*     */   }
/*     */   
/*     */   public FileObject getWorkingDirectory() {
/* 234 */     return this.workingDirectory;
/*     */   }
/*     */   
/*     */   public VectorPipeliner getVectorEngine() {
/* 238 */     return this.vectorPipeliner;
/*     */   }
/*     */   
/*     */   public void setCommandLineArguments(String executableName, String... arguments) {
/* 242 */     this.commandLineArguments = (StringVector)new StringArrayVector(Lists.asList(executableName, (Object[])arguments));
/*     */   }
/*     */   
/*     */   public void setCommandLineArguments(String executableName, List<String> arguments) {
/* 246 */     List<String> commandLine = Lists.newArrayList();
/* 247 */     commandLine.add(executableName);
/* 248 */     commandLine.addAll(arguments);
/* 249 */     this.commandLineArguments = (StringVector)new StringArrayVector(commandLine);
/*     */   }
/*     */   
/*     */   public StringVector getCommandLineArguments() {
/* 253 */     return this.commandLineArguments;
/*     */   }
/*     */   
/*     */   public boolean isInvisible() {
/* 257 */     return this.invisible;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PrintWriter getStdOut() {
/* 266 */     return this.connectionTable.getStdout().getStream();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PrintWriter getEffectiveStdOut() {
/* 274 */     return this.connectionTable.getStdout().getOpenPrintWriter();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PrintWriter getStdErr() {
/* 283 */     return this.connectionTable.getStderr().getStream();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PrintWriter getEffectiveStdErr() {
/* 290 */     return this.connectionTable.getStderr().getOpenPrintWriter();
/*     */   }
/*     */   
/*     */   public Reader getStdIn() {
/* 294 */     return (Reader)this.connectionTable.getStdin().getReader();
/*     */   }
/*     */   
/*     */   public NamespaceRegistry getNamespaceRegistry() {
/* 298 */     return this.namespaceRegistry;
/*     */   }
/*     */   
/*     */   public Context getTopLevelContext() {
/* 302 */     return this.topLevelContext;
/*     */   }
/*     */   
/*     */   public FileSystemManager getFileSystemManager() {
/* 306 */     return this.fileSystemManager;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FileObject resolveFile(String uri) throws FileSystemException {
/* 323 */     return this.fileSystemManager.resolveFile(this.workingDirectory, uri);
/*     */   }
/*     */   
/*     */   public Environment getBaseEnvironment() {
/* 327 */     return this.baseEnvironment;
/*     */   }
/*     */   
/*     */   public Environment getBaseNamespaceEnv() {
/* 331 */     return this.baseNamespaceEnv;
/*     */   }
/*     */   
/*     */   public String getHomeDirectory() {
/* 335 */     return this.homeDirectory;
/*     */   }
/*     */   
/*     */   public Map<String, String> getSystemEnvironment() {
/* 339 */     return this.systemEnvironment;
/*     */   }
/*     */   
/*     */   public SecurityManager getSecurityManager() {
/* 343 */     return this.securityManager;
/*     */   }
/*     */   
/*     */   public void setSecurityManager(SecurityManager securityManager) {
/* 347 */     this.securityManager = securityManager;
/*     */   }
/*     */   
/*     */   public ClassLoader getClassLoader() {
/* 351 */     return this.classLoader;
/*     */   }
/*     */   
/*     */   public S4Cache getS4Cache() {
/* 355 */     return this.s4Cache;
/*     */   }
/*     */   
/*     */   public void registerFinalizer(SEXP sexp, FinalizationHandler handler, boolean onExit) {
/* 359 */     if (this.finalizers == null) {
/* 360 */       this.finalizers = new FinalizerRegistry();
/*     */     }
/* 362 */     this.finalizers.register(sexp, handler, onExit);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void runFinalizers() {
/* 372 */     if (this.finalizers != null) {
/* 373 */       this.finalizers.finalizeDisposedEnvironments(this.topLevelContext);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() {
/* 383 */     this.topLevelContext.exit();
/* 384 */     if (this.finalizers != null) {
/* 385 */       this.finalizers.finalizeOnExit(this.topLevelContext);
/*     */     }
/*     */   }
/*     */   
/*     */   public MethodHandle getRngMethod() {
/* 390 */     return this.rng.getMethodHandle();
/*     */   }
/*     */   
/*     */   public void loadLibrary(DllInfo library) {
/* 394 */     this.loadedLibraries.add(library);
/*     */   }
/*     */   
/*     */   public Iterable<DllInfo> getLoadedLibraries() {
/* 398 */     return this.loadedLibraries;
/*     */   }
/*     */ 
/*     */   
/*     */   public void printWarnings() {
/* 403 */     SEXP warnings = this.baseEnvironment.getVariable(this.topLevelContext, Warning.LAST_WARNING);
/* 404 */     if (warnings != Symbol.UNBOUND_VALUE) {
/* 405 */       this.topLevelContext.evaluate((SEXP)FunctionCall.newCall((SEXP)Symbol.get("print.warnings"), new SEXP[] { warnings }), this.topLevelContext
/* 406 */           .getBaseEnvironment());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void clearWarnings() {
/* 412 */     this.baseEnvironment.remove(Warning.LAST_WARNING);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/eval/Session.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */