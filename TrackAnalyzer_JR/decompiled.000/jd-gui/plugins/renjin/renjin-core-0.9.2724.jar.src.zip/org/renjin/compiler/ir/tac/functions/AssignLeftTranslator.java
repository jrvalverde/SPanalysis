/*    */ package org.renjin.compiler.ir.tac.functions;
/*    */ 
/*    */ import org.renjin.compiler.ir.tac.IRBodyBuilder;
/*    */ import org.renjin.compiler.ir.tac.expressions.EnvironmentVariable;
/*    */ import org.renjin.compiler.ir.tac.expressions.Expression;
/*    */ import org.renjin.compiler.ir.tac.expressions.LValue;
/*    */ import org.renjin.compiler.ir.tac.expressions.Temp;
/*    */ import org.renjin.compiler.ir.tac.statements.Assignment;
/*    */ import org.renjin.compiler.ir.tac.statements.Statement;
/*    */ import org.renjin.eval.EvalException;
/*    */ import org.renjin.sexp.Function;
/*    */ import org.renjin.sexp.FunctionCall;
/*    */ import org.renjin.sexp.SEXP;
/*    */ import org.renjin.sexp.StringVector;
/*    */ import org.renjin.sexp.Symbol;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AssignLeftTranslator
/*    */   extends FunctionCallTranslator
/*    */ {
/*    */   public Expression translateToExpression(IRBodyBuilder builder, TranslationContext context, Function resolvedFunction, FunctionCall call) {
/*    */     Temp temp;
/* 38 */     Expression rhs = builder.translateExpression(context, call.getArgument(1));
/*    */ 
/*    */ 
/*    */     
/* 42 */     if (!(rhs instanceof org.renjin.compiler.ir.tac.expressions.Constant)) {
/*    */       
/* 44 */       Temp temp1 = builder.newTemp();
/* 45 */       builder.addStatement((Statement)new Assignment((LValue)temp1, rhs));
/* 46 */       temp = temp1;
/*    */     } 
/*    */     
/* 49 */     addAssignment(builder, context, call, (Expression)temp);
/* 50 */     return (Expression)temp;
/*    */   }
/*    */ 
/*    */   
/*    */   public void addStatement(IRBodyBuilder builder, TranslationContext context, Function resolvedFunction, FunctionCall assignment) {
/* 55 */     Expression rhs = builder.translateExpression(context, assignment.getArgument(1));
/*    */     
/* 57 */     addAssignment(builder, context, assignment, rhs);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private void addAssignment(IRBodyBuilder builder, TranslationContext context, FunctionCall assignment, Expression rhs) {
/*    */     EnvironmentVariable environmentVariable;
/* 67 */     SEXP lhs = assignment.getArgument(0);
/*    */     
/* 69 */     while (lhs instanceof FunctionCall) {
/* 70 */       FunctionCall call = (FunctionCall)lhs;
/*    */       
/* 72 */       rhs = builder.translateSetterCall(context, call, rhs);
/* 73 */       lhs = call.getArgument(0);
/*    */     } 
/*    */ 
/*    */     
/* 77 */     if (lhs instanceof Symbol) {
/* 78 */       environmentVariable = builder.getEnvironmentVariable((Symbol)lhs);
/* 79 */     } else if (lhs instanceof StringVector) {
/* 80 */       environmentVariable = builder.getEnvironmentVariable(Symbol.get(((StringVector)lhs).getElementAsString(0)));
/*    */     } else {
/* 82 */       throw new EvalException("cannot assign to value of type " + lhs.getTypeName(), new Object[0]);
/*    */     } 
/*    */     
/* 85 */     doAssignment(builder, (LValue)environmentVariable, rhs);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void doAssignment(IRBodyBuilder builder, LValue target, Expression rhs) {
/* 91 */     builder.addStatement((Statement)new Assignment(target, rhs));
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/ir/tac/functions/AssignLeftTranslator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */