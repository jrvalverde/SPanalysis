/*    */ package org.renjin.pipeliner.fusion;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.renjin.pipeliner.fusion.kernel.ColSumKernel;
/*    */ import org.renjin.pipeliner.fusion.kernel.LoopKernel;
/*    */ import org.renjin.pipeliner.fusion.kernel.RowMeanKernel;
/*    */ import org.renjin.pipeliner.fusion.kernel.SumMeanKernel;
/*    */ import org.renjin.pipeliner.node.DeferredNode;
/*    */ import org.renjin.pipeliner.node.FunctionNode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum LoopKernels
/*    */ {
/* 34 */   INSTANCE;
/*    */   
/*    */   private Map<String, LoopKernel> map;
/*    */   
/*    */   LoopKernels() {
/* 39 */     this.map = new HashMap<>();
/* 40 */     if (System.getProperty("renjin.vp.disablejit") == null) {
/* 41 */       this.map.put("mean", SumMeanKernel.mean());
/* 42 */       this.map.put("sum", SumMeanKernel.sum());
/* 43 */       this.map.put("rowMeans", new RowMeanKernel());
/* 44 */       this.map.put("colSums", new ColSumKernel());
/*    */     } else {
/* 46 */       System.err.println("Specializers are disabled");
/*    */     } 
/*    */   }
/*    */   
/*    */   public boolean supports(DeferredNode node) {
/* 51 */     if (node instanceof FunctionNode) {
/* 52 */       return this.map.containsKey(((FunctionNode)node).getComputationName());
/*    */     }
/* 54 */     return false;
/*    */   }
/*    */   
/*    */   public LoopKernel get(FunctionNode node) {
/* 58 */     return this.map.get(node.getComputationName());
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/pipeliner/fusion/LoopKernels.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */