/*     */ package org.renjin.invoke.codegen;
/*     */ 
/*     */ import com.sun.codemodel.JAssignmentTarget;
/*     */ import com.sun.codemodel.JBlock;
/*     */ import com.sun.codemodel.JClass;
/*     */ import com.sun.codemodel.JCodeModel;
/*     */ import com.sun.codemodel.JDefinedClass;
/*     */ import com.sun.codemodel.JExpr;
/*     */ import com.sun.codemodel.JExpression;
/*     */ import com.sun.codemodel.JInvocation;
/*     */ import com.sun.codemodel.JMethod;
/*     */ import com.sun.codemodel.JType;
/*     */ import com.sun.codemodel.JVar;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.renjin.eval.Context;
/*     */ import org.renjin.eval.EvalException;
/*     */ import org.renjin.eval.Session;
/*     */ import org.renjin.invoke.annotations.Materialize;
/*     */ import org.renjin.invoke.annotations.SessionScoped;
/*     */ import org.renjin.invoke.codegen.args.ArgConverterStrategies;
/*     */ import org.renjin.invoke.codegen.args.ArgConverterStrategy;
/*     */ import org.renjin.invoke.codegen.scalars.ScalarType;
/*     */ import org.renjin.invoke.codegen.scalars.ScalarTypes;
/*     */ import org.renjin.invoke.model.JvmMethod;
/*     */ import org.renjin.invoke.model.PrimitiveModel;
/*     */ import org.renjin.repackaged.guava.collect.Lists;
/*     */ import org.renjin.repackaged.guava.collect.Maps;
/*     */ import org.renjin.sexp.Environment;
/*     */ import org.renjin.sexp.LogicalVector;
/*     */ import org.renjin.sexp.SEXP;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OverloadWrapperBuilder
/*     */   implements ApplyMethodContext
/*     */ {
/*     */   protected JCodeModel codeModel;
/*     */   protected JDefinedClass invoker;
/*     */   private PrimitiveModel primitive;
/*     */   private int arity;
/*  53 */   private List<JVar> arguments = Lists.newArrayList();
/*     */   private JVar context;
/*     */   private JVar environment;
/*     */   
/*     */   public OverloadWrapperBuilder(JCodeModel codeModel, JDefinedClass invoker, PrimitiveModel primitive, int arity) {
/*  58 */     this.codeModel = codeModel;
/*  59 */     this.invoker = invoker;
/*  60 */     this.primitive = primitive;
/*  61 */     this.arity = arity;
/*     */   }
/*     */ 
/*     */   
/*     */   public void build() {
/*  66 */     JMethod method = this.invoker.method(17, (JType)this.codeModel.ref(SEXP.class), "doApply")._throws(Exception.class);
/*     */     
/*  68 */     this.context = method.param(Context.class, "context");
/*  69 */     this.environment = method.param(Environment.class, "environment");
/*  70 */     for (int i = 0; i != this.arity; i++) {
/*  71 */       JVar argument = method.param(SEXP.class, "arg" + i);
/*  72 */       this.arguments.add(argument);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  78 */     IfElseBuilder matchSequence = new IfElseBuilder(method.body());
/*  79 */     List<JvmMethod> overloads = Lists.newArrayList(this.primitive.overloadsWithPosArgCountOf(this.arity));
/*     */     
/*  81 */     if (this.primitive.isRelationalOperator()) {
/*  82 */       JVar arg0 = this.arguments.get(0);
/*  83 */       JVar arg1 = this.arguments.get(1);
/*  84 */       Collections.sort(overloads, new OverloadComparator());
/*  85 */       Collections.reverse(overloads);
/*     */       
/*  87 */       method.body()._if(this.codeModel.ref(WrapperRuntime.class).staticInvoke("isEmptyOrNull").arg((JExpression)arg0).cor((JExpression)this.codeModel.ref(WrapperRuntime.class).staticInvoke("isEmptyOrNull").arg((JExpression)arg1)))._then()._return((JExpression)this.codeModel.ref(LogicalVector.class).staticRef("EMPTY"));
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  92 */       method.body().assign((JAssignmentTarget)JExpr.ref("arg0"), (JExpression)this.codeModel.ref(WrapperRuntime.class).staticInvoke("maybeConvertToStringVector").arg((JExpression)this.context).arg((JExpression)arg0));
/*  93 */       method.body().assign((JAssignmentTarget)JExpr.ref("arg1"), (JExpression)this.codeModel.ref(WrapperRuntime.class).staticInvoke("maybeConvertToStringVector").arg((JExpression)this.context).arg((JExpression)arg1));
/*     */       
/*  95 */       for (JvmMethod overload : overloads) {
/*  96 */         ScalarType scalarType = ScalarTypes.get(((JvmMethod.Argument)overload.getFormals().get(0)).getClazz());
/*  97 */         JClass vectorType = this.codeModel.ref(scalarType.getVectorType());
/*     */         
/*  99 */         JBlock stringBlock = matchSequence._if(arg0._instanceof((JType)vectorType)
/* 100 */             .cor(arg1._instanceof((JType)vectorType)));
/* 101 */         invokeOverload(overload, stringBlock);
/*     */       
/*     */       }
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 109 */       Collections.sort(overloads, new OverloadComparator());
/* 110 */       for (JvmMethod overload : overloads)
/*     */       {
/*     */ 
/*     */         
/* 114 */         invokeOverload(overload, matchSequence._if(argumentsMatch(overload)));
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 121 */     matchSequence._else()._throw((JExpression)JExpr._new(this.codeModel.ref(EvalException.class))
/* 122 */         .arg(typeMismatchErrorMessage(this.arguments)));
/*     */   }
/*     */   
/*     */   private JExpression typeMismatchErrorMessage(List<JVar> arguments) {
/* 126 */     JInvocation format = this.codeModel.ref(String.class).staticInvoke("format");
/* 127 */     format.arg(JExpr.lit(typeMessageErrorFormat(arguments.size())));
/* 128 */     for (JVar arg : arguments) {
/* 129 */       format.arg((JExpression)arg.invoke("getTypeName"));
/*     */     }
/* 131 */     return (JExpression)format;
/*     */   }
/*     */ 
/*     */   
/*     */   private String typeMessageErrorFormat(int nargs) {
/* 136 */     String escapedFunctionName = this.primitive.getName().replaceAll("%", "%%");
/*     */     
/* 138 */     StringBuilder message = new StringBuilder();
/* 139 */     message.append("Invalid argument:\n");
/* 140 */     message.append("\t").append(escapedFunctionName).append("(");
/*     */     
/* 142 */     for (int i = 0; i < nargs; i++) {
/* 143 */       if (i > 0) {
/* 144 */         message.append(", ");
/*     */       }
/* 146 */       message.append("%s");
/*     */     } 
/* 148 */     message.append(")\n");
/* 149 */     message.append("\tExpected:");
/* 150 */     for (JvmMethod method : this.primitive.getOverloads()) {
/* 151 */       message.append("\n\t");
/* 152 */       method.appendFriendlySignatureTo(escapedFunctionName, message);
/*     */     } 
/* 154 */     return message.toString();
/*     */   }
/*     */   
/*     */   private Map<JvmMethod.Argument, JExpression> mapArguments(JvmMethod overload) {
/* 158 */     Map<JvmMethod.Argument, JExpression> argumentMap = Maps.newHashMap();
/*     */     
/* 160 */     int argumentPos = 0;
/* 161 */     for (JvmMethod.Argument argument : overload.getAllArguments()) {
/* 162 */       if (argument.isContextual()) {
/* 163 */         if (argument.getClazz().equals(Context.class)) {
/* 164 */           argumentMap.put(argument, this.context); continue;
/* 165 */         }  if (argument.getClazz().equals(Environment.class)) {
/* 166 */           argumentMap.put(argument, this.environment); continue;
/* 167 */         }  if (argument.getClazz().equals(Session.class)) {
/* 168 */           argumentMap.put(argument, this.context.invoke("getSession")); continue;
/* 169 */         }  if (argument.getClazz().getAnnotation(SessionScoped.class) != null) {
/* 170 */           argumentMap.put(argument, this.context.invoke("getSingleton").arg(JExpr.dotclass(this.codeModel.ref(argument.getClazz())))); continue;
/*     */         } 
/* 172 */         throw new UnsupportedOperationException(argument.getClazz().getName());
/*     */       } 
/*     */       
/* 175 */       argumentMap.put(argument, convert(argument, materialize(overload, argument, this.arguments.get(argumentPos++))));
/*     */     } 
/*     */     
/* 178 */     return argumentMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private JExpression materialize(JvmMethod overload, JvmMethod.Argument formal, JVar argumentVar) {
/* 186 */     if (overload.isAnnotatedWith(Materialize.class)) {
/* 187 */       return (JExpression)this.context.invoke("materialize").arg((JExpression)argumentVar);
/*     */     }
/* 189 */     return (JExpression)argumentVar;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void invokeOverload(JvmMethod overload, JBlock block) {
/* 195 */     if (overload.isDataParallel()) {
/* 196 */       (new RecycleLoopBuilder(this.codeModel, block, (JExpression)this.context, this.primitive, overload, mapArguments(overload)))
/* 197 */         .build();
/*     */     } else {
/* 199 */       invokeSimpleMethod(overload, block);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void invokeSimpleMethod(JvmMethod overload, JBlock block) {
/* 209 */     JInvocation invocation = this.codeModel.ref(overload.getDeclaringClass()).staticInvoke(overload.getName());
/*     */     
/* 211 */     Map<JvmMethod.Argument, JExpression> argumentMap = mapArguments(overload);
/*     */     
/* 213 */     for (JvmMethod.Argument argument : overload.getAllArguments()) {
/* 214 */       invocation.arg(argumentMap.get(argument));
/*     */     }
/* 216 */     CodeModelUtils.returnSexp(this.context, this.codeModel, block, overload, invocation);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private JExpression convert(JvmMethod.Argument argument, JExpression sexp) {
/* 226 */     return ArgConverterStrategies.findArgConverterStrategy(argument)
/* 227 */       .convertArgument(this, sexp);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private JExpression argumentsMatch(JvmMethod overload) {
/* 235 */     JExpression condition = JExpr.TRUE;
/* 236 */     List<JvmMethod.Argument> posFormals = overload.getPositionalFormals();
/* 237 */     for (int i = 0; i != posFormals.size(); i++) {
/*     */ 
/*     */       
/* 240 */       ArgConverterStrategy strategy = ArgConverterStrategies.findArgConverterStrategy(posFormals.get(i));
/*     */       
/* 242 */       JExpression argCondition = strategy.getTestExpr(this.codeModel, this.arguments.get(i));
/* 243 */       if (condition == null) {
/* 244 */         condition = argCondition;
/*     */       } else {
/* 246 */         condition = condition.cand(argCondition);
/*     */       } 
/*     */     } 
/* 249 */     return condition;
/*     */   }
/*     */ 
/*     */   
/*     */   public JExpression getContext() {
/* 254 */     return (JExpression)this.context;
/*     */   }
/*     */ 
/*     */   
/*     */   public JExpression getEnvironment() {
/* 259 */     return (JExpression)this.environment;
/*     */   }
/*     */ 
/*     */   
/*     */   public JClass classRef(Class<?> clazz) {
/* 264 */     return this.codeModel.ref(clazz);
/*     */   }
/*     */ 
/*     */   
/*     */   public JCodeModel getCodeModel() {
/* 269 */     return this.codeModel;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/codegen/OverloadWrapperBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */