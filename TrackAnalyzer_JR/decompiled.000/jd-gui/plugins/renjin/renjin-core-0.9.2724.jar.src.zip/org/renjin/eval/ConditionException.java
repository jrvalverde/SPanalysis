/*    */ package org.renjin.eval;
/*    */ 
/*    */ import org.renjin.sexp.SEXP;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConditionException
/*    */   extends RuntimeException
/*    */ {
/*    */   private SEXP condition;
/*    */   private Context handlerContext;
/*    */   private SEXP handler;
/*    */   
/*    */   public ConditionException(SEXP condition, Context handlerContext, SEXP handler) {
/* 33 */     this.condition = condition;
/* 34 */     this.handlerContext = handlerContext;
/* 35 */     this.handler = handler;
/*    */   }
/*    */   
/*    */   public SEXP getCondition() {
/* 39 */     return this.condition;
/*    */   }
/*    */   
/*    */   public Context getHandlerContext() {
/* 43 */     return this.handlerContext;
/*    */   }
/*    */   
/*    */   public SEXP getHandler() {
/* 47 */     return this.handler;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/eval/ConditionException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */