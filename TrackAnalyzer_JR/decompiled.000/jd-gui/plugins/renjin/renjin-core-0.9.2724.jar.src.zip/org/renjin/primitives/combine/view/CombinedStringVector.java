/*     */ package org.renjin.primitives.combine.view;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.renjin.primitives.vector.DeferredComputation;
/*     */ import org.renjin.sexp.AttributeMap;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.StringVector;
/*     */ import org.renjin.sexp.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CombinedStringVector
/*     */   extends StringVector
/*     */   implements DeferredComputation
/*     */ {
/*     */   private final Vector[] vectors;
/*     */   private final int[] endIndex;
/*     */   private final int totalLength;
/*     */   
/*     */   public static StringVector combine(Vector[] vectors, AttributeMap attributeMap) {
/*  37 */     if (vectors.length == 1) {
/*  38 */       return (StringVector)vectors[0].setAttributes(attributeMap);
/*     */     }
/*  40 */     return new CombinedStringVector(vectors, attributeMap);
/*     */   }
/*     */ 
/*     */   
/*     */   public static StringVector combine(List<Vector> vectors, AttributeMap attributeMap) {
/*  45 */     if (vectors.size() == 1) {
/*  46 */       return (StringVector)((Vector)vectors.get(0)).setAttributes(attributeMap);
/*     */     }
/*  48 */     return new CombinedStringVector(vectors.<Vector>toArray(new Vector[vectors.size()]), attributeMap);
/*     */   }
/*     */ 
/*     */   
/*     */   private CombinedStringVector(Vector[] vectors, AttributeMap attributeMap) {
/*  53 */     super(attributeMap);
/*     */     
/*  55 */     this.vectors = vectors;
/*  56 */     this.endIndex = new int[vectors.length];
/*     */     
/*  58 */     int totalLength = 0;
/*  59 */     for (int i = 0; i != vectors.length; i++) {
/*  60 */       totalLength += vectors[i].length();
/*  61 */       this.endIndex[i] = totalLength;
/*     */     } 
/*  63 */     this.totalLength = totalLength;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector[] getOperands() {
/*  69 */     return this.vectors;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getComputationName() {
/*  74 */     return "c";
/*     */   }
/*     */ 
/*     */   
/*     */   protected StringVector cloneWithNewAttributes(AttributeMap attributes) {
/*  79 */     return new CombinedStringVector(this.vectors, attributes);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getElementAsString(int index) {
/*  84 */     if (index < this.endIndex[0]) {
/*  85 */       return this.vectors[0].getElementAsString(index);
/*     */     }
/*  87 */     if (index < this.endIndex[1]) {
/*  88 */       return this.vectors[1].getElementAsString(index - this.endIndex[0]);
/*     */     }
/*  90 */     if (index < this.endIndex[2]) {
/*  91 */       return this.vectors[2].getElementAsString(index - this.endIndex[1]);
/*     */     }
/*  93 */     if (index < this.endIndex[3]) {
/*  94 */       return this.vectors[3].getElementAsString(index - this.endIndex[2]);
/*     */     }
/*  96 */     for (int i = 4; i < this.vectors.length; i++) {
/*  97 */       if (index < this.endIndex[i]) {
/*  98 */         return this.vectors[i].getElementAsString(index - this.endIndex[i - 1]);
/*     */       }
/*     */     } 
/* 101 */     throw new IllegalArgumentException("index: " + index);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isConstantAccessTime() {
/* 106 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDeferred() {
/* 111 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int length() {
/* 116 */     return this.totalLength;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/combine/view/CombinedStringVector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */