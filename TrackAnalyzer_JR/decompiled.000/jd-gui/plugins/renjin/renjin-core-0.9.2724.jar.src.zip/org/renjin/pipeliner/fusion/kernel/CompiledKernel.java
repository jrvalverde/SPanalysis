package org.renjin.pipeliner.fusion.kernel;

import org.renjin.sexp.Vector;

public interface CompiledKernel {
  double[] compute(Vector[] paramArrayOfVector);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/pipeliner/fusion/kernel/CompiledKernel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */