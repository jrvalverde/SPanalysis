/*    */ package org.renjin.primitives.io.serialization;
/*    */ 
/*    */ import org.renjin.sexp.Environment;
/*    */ import org.renjin.sexp.Null;
/*    */ import org.renjin.sexp.Promise;
/*    */ import org.renjin.sexp.SEXP;
/*    */ import org.renjin.sexp.Symbol;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NullReadContext
/*    */   implements ReadContext
/*    */ {
/*    */   public Environment getBaseEnvironment() {
/* 35 */     return (Environment)Environment.EMPTY;
/*    */   }
/*    */ 
/*    */   
/*    */   public Promise createPromise(SEXP expr, Environment environment) {
/* 40 */     return Promise.repromise((SEXP)Null.INSTANCE);
/*    */   }
/*    */ 
/*    */   
/*    */   public Environment findNamespace(Symbol symbol) {
/* 45 */     return (Environment)Environment.EMPTY;
/*    */   }
/*    */ 
/*    */   
/*    */   public Environment getBaseNamespaceEnvironment() {
/* 50 */     return (Environment)Environment.EMPTY;
/*    */   }
/*    */ 
/*    */   
/*    */   public Environment getGlobalEnvironment() {
/* 55 */     return (Environment)Environment.EMPTY;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/io/serialization/NullReadContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */