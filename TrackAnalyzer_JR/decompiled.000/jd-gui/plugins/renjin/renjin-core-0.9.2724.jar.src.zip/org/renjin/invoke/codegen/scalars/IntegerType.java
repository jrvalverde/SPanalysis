/*    */ package org.renjin.invoke.codegen.scalars;
/*    */ 
/*    */ import com.sun.codemodel.JCodeModel;
/*    */ import com.sun.codemodel.JExpression;
/*    */ import com.sun.codemodel.JType;
/*    */ import com.sun.codemodel.JVar;
/*    */ import org.renjin.invoke.annotations.CastStyle;
/*    */ import org.renjin.invoke.model.JvmMethod;
/*    */ import org.renjin.sexp.DoubleVector;
/*    */ import org.renjin.sexp.IntArrayVector;
/*    */ import org.renjin.sexp.IntVector;
/*    */ import org.renjin.sexp.LogicalVector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IntegerType
/*    */   extends ScalarType
/*    */ {
/*    */   public Class getScalarType() {
/* 35 */     return int.class;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getConversionMethod() {
/* 40 */     return "convertToInt";
/*    */   }
/*    */ 
/*    */   
/*    */   public String getAccessorMethod() {
/* 45 */     return "getElementAsInt";
/*    */   }
/*    */ 
/*    */   
/*    */   public Class getVectorType() {
/* 50 */     return IntVector.class;
/*    */   }
/*    */ 
/*    */   
/*    */   public Class<IntArrayVector.Builder> getBuilderClass() {
/* 55 */     return IntArrayVector.Builder.class;
/*    */   }
/*    */ 
/*    */   
/*    */   public Class getBuilderArrayElementClass() {
/* 60 */     return int.class;
/*    */   }
/*    */ 
/*    */   
/*    */   public Class getArrayVectorClass() {
/* 65 */     return IntArrayVector.class;
/*    */   }
/*    */ 
/*    */   
/*    */   public JExpression testExpr(JCodeModel codeModel, JVar sexpVariable, JvmMethod.Argument formal) {
/* 70 */     if (formal.getCastStyle() == CastStyle.IMPLICIT) {
/* 71 */       return sexpVariable._instanceof((JType)codeModel.ref(IntVector.class))
/* 72 */         .cor(sexpVariable._instanceof((JType)codeModel.ref(DoubleVector.class)))
/* 73 */         .cor(sexpVariable._instanceof((JType)codeModel.ref(LogicalVector.class)));
/*    */     }
/* 75 */     return sexpVariable._instanceof((JType)codeModel.ref(IntVector.class))
/* 76 */       .cor(sexpVariable._instanceof((JType)codeModel.ref(LogicalVector.class)));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public JExpression naLiteral(JCodeModel codeModel) {
/* 82 */     return (JExpression)codeModel.ref(IntVector.class).staticRef("NA");
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/codegen/scalars/IntegerType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */