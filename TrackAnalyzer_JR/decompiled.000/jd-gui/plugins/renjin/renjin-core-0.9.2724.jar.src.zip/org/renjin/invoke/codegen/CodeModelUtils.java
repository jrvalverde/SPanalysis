/*    */ package org.renjin.invoke.codegen;
/*    */ 
/*    */ import com.sun.codemodel.JBlock;
/*    */ import com.sun.codemodel.JCodeModel;
/*    */ import com.sun.codemodel.JExpression;
/*    */ import com.sun.codemodel.JInvocation;
/*    */ import com.sun.codemodel.JStatement;
/*    */ import com.sun.codemodel.JVar;
/*    */ import org.renjin.invoke.model.JvmMethod;
/*    */ import org.renjin.sexp.Null;
/*    */ import org.renjin.sexp.SEXP;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CodeModelUtils
/*    */ {
/*    */   static void returnSexp(JVar context, JCodeModel codeModel, JBlock parent, JvmMethod overload, JInvocation invocation) {
/* 32 */     if (overload.getReturnType().equals(void.class)) {
/* 33 */       parent.add((JStatement)invocation);
/* 34 */       parent.add((JStatement)context.invoke("setInvisibleFlag"));
/* 35 */       parent._return((JExpression)codeModel.ref(Null.class).staticRef("INSTANCE"));
/*    */     } else {
/* 37 */       JVar result = parent.decl(codeModel._ref(SEXP.class), "__return", convertResult(codeModel, overload, invocation));
/*    */       
/* 39 */       if (overload.isInvisible()) {
/* 40 */         parent.add((JStatement)context.invoke("setInvisibleFlag"));
/*    */       }
/* 42 */       parent._return((JExpression)result);
/*    */     } 
/*    */   }
/*    */   
/*    */   static JExpression convertResult(JCodeModel codeModel, JvmMethod overload, JInvocation invocation) {
/* 47 */     if (SEXP.class.isAssignableFrom(overload.getReturnType())) {
/* 48 */       return (JExpression)invocation;
/*    */     }
/* 50 */     return (JExpression)codeModel.ref(WrapperRuntime.class).staticInvoke("wrapResult").arg((JExpression)invocation);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/codegen/CodeModelUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */