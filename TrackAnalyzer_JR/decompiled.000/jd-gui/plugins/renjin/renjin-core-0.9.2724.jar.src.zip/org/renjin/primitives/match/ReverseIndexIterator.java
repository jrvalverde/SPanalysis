/*    */ package org.renjin.primitives.match;
/*    */ 
/*    */ import org.renjin.repackaged.guava.collect.UnmodifiableIterator;
/*    */ import org.renjin.sexp.Vector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ReverseIndexIterator
/*    */   extends UnmodifiableIterator<Integer>
/*    */ {
/*    */   private int index;
/*    */   
/*    */   public ReverseIndexIterator(Vector vector) {
/* 32 */     this.index = vector.length() - 1;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean hasNext() {
/* 37 */     return (this.index >= 0);
/*    */   }
/*    */ 
/*    */   
/*    */   public Integer next() {
/* 42 */     return Integer.valueOf(this.index--);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/match/ReverseIndexIterator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */