/*    */ package org.renjin.invoke.reflection.converters;
/*    */ 
/*    */ import org.renjin.sexp.AtomicVector;
/*    */ import org.renjin.sexp.ExternalPtr;
/*    */ import org.renjin.sexp.LongArrayVector;
/*    */ import org.renjin.sexp.Null;
/*    */ import org.renjin.sexp.SEXP;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ObjectConverter
/*    */   implements Converter<Object>
/*    */ {
/* 29 */   public static final Converter INSTANCE = new ObjectConverter();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SEXP convertToR(Object value) {
/* 37 */     if (value == null) {
/* 38 */       return (SEXP)Null.INSTANCE;
/*    */     }
/* 40 */     Converter<Object> converter = Converters.get(value.getClass());
/* 41 */     return converter.convertToR(value);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean acceptsSEXP(SEXP exp) {
/*    */     try {
/* 48 */       convertToJava(exp);
/* 49 */       return true;
/*    */     }
/* 51 */     catch (ConversionException e) {
/* 52 */       return false;
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public Object convertToJava(SEXP exp) {
/* 58 */     if (exp == Null.INSTANCE) {
/* 59 */       return null;
/*    */     }
/*    */ 
/*    */     
/* 63 */     if (exp instanceof ExternalPtr) {
/* 64 */       ExternalPtr ptr = (ExternalPtr)exp;
/* 65 */       return ptr.getInstance();
/*    */     } 
/*    */ 
/*    */     
/* 69 */     if (exp instanceof LongArrayVector && exp.length() == 1) {
/* 70 */       return Long.valueOf(((LongArrayVector)exp).getElementAsLong(0));
/*    */     }
/*    */ 
/*    */     
/* 74 */     if (exp instanceof AtomicVector && exp.length() == 1) {
/* 75 */       AtomicVector vector = (AtomicVector)exp;
/* 76 */       if (!vector.isElementNA(0)) {
/* 77 */         return vector.getElementAsObject(0);
/*    */       }
/*    */     } 
/*    */ 
/*    */     
/* 82 */     return exp;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getSpecificity() {
/* 87 */     return 100;
/*    */   }
/*    */   
/*    */   public static boolean accept(Class clazz) {
/* 91 */     return clazz.equals(Object.class);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/reflection/converters/ObjectConverter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */