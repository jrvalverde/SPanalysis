/*     */ package org.renjin.primitives.sequence;
/*     */ 
/*     */ import org.renjin.eval.ClosureDispatcher;
/*     */ import org.renjin.eval.Context;
/*     */ import org.renjin.eval.EvalException;
/*     */ import org.renjin.invoke.codegen.ArgumentIterator;
/*     */ import org.renjin.primitives.S3;
/*     */ import org.renjin.sexp.AtomicVector;
/*     */ import org.renjin.sexp.AttributeMap;
/*     */ import org.renjin.sexp.Environment;
/*     */ import org.renjin.sexp.FunctionCall;
/*     */ import org.renjin.sexp.IntArrayVector;
/*     */ import org.renjin.sexp.IntVector;
/*     */ import org.renjin.sexp.Null;
/*     */ import org.renjin.sexp.PairList;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.SpecialFunction;
/*     */ import org.renjin.sexp.StringVector;
/*     */ import org.renjin.sexp.Symbol;
/*     */ import org.renjin.sexp.Symbols;
/*     */ import org.renjin.sexp.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RepFunction
/*     */   extends SpecialFunction
/*     */ {
/*     */   public RepFunction() {
/*  31 */     super("rep");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SEXP apply(Context context, Environment rho, FunctionCall call, PairList arguments) {
/*  44 */     if (arguments == Null.INSTANCE) {
/*  45 */       context.setInvisibleFlag();
/*  46 */       return (SEXP)Null.INSTANCE;
/*     */     } 
/*     */ 
/*     */     
/*  50 */     ArgumentIterator argIt = new ArgumentIterator(context, rho, arguments);
/*  51 */     PairList.Node firstArgNode = argIt.nextNode();
/*  52 */     SEXP firstArg = context.evaluate(firstArgNode.getValue(), rho);
/*  53 */     if (firstArg.isObject()) {
/*  54 */       SEXP result = S3.tryDispatchFromPrimitive(context, rho, call, "rep", firstArg, arguments);
/*  55 */       if (result != null) {
/*  56 */         return result;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  61 */     PairList.Builder evaled = new PairList.Builder();
/*  62 */     evaled.add(firstArgNode.getRawTag(), firstArg);
/*  63 */     while (argIt.hasNext()) {
/*  64 */       PairList.Node node = argIt.nextNode();
/*  65 */       evaled.add(node.getRawTag(), context.evaluate(node.getValue(), rho));
/*     */     } 
/*     */ 
/*     */     
/*  69 */     PairList.Builder formals = new PairList.Builder();
/*  70 */     formals.add("x", (SEXP)Symbol.MISSING_ARG);
/*  71 */     formals.add("times", (SEXP)Symbol.MISSING_ARG);
/*  72 */     formals.add("length.out", (SEXP)Symbol.MISSING_ARG);
/*  73 */     formals.add("each", (SEXP)Symbol.MISSING_ARG);
/*  74 */     formals.add(Symbols.ELLIPSES, (SEXP)Symbol.MISSING_ARG);
/*     */     
/*  76 */     PairList matched = ClosureDispatcher.matchArguments(formals.build(), evaled.build(), true);
/*     */     
/*  78 */     SEXP x = matched.findByTag(Symbol.get("x"));
/*  79 */     SEXP times = matched.findByTag(Symbol.get("times"));
/*  80 */     SEXP lengthOut = matched.findByTag(Symbol.get("length.out"));
/*  81 */     SEXP each = matched.findByTag(Symbol.get("each"));
/*     */     
/*  83 */     return (SEXP)rep((Vector)x, (times == Symbol.MISSING_ARG) ? (Vector)new IntArrayVector(new int[] { 1 }, ) : (Vector)times, (lengthOut == Symbol.MISSING_ARG) ? Integer.MIN_VALUE : ((Vector)lengthOut)
/*     */ 
/*     */         
/*  86 */         .getElementAsInt(0), (each == Symbol.MISSING_ARG) ? Integer.MIN_VALUE : ((Vector)each)
/*  87 */         .getElementAsInt(0));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static Vector rep(Vector x, Vector times, int lengthOut, int each) {
/*     */     int resultLength;
/*  94 */     if (x == Null.INSTANCE) {
/*  95 */       return (Vector)Null.INSTANCE;
/*     */     }
/*     */     
/*  98 */     if (x.length() == 0) {
/*  99 */       x = x.getVectorType().newBuilderWithInitialCapacity(1).addNA().build();
/*     */     }
/*     */     
/* 102 */     if (times.length() == 1) {
/* 103 */       resultLength = x.length() * times.getElementAsInt(0);
/*     */     } else {
/* 105 */       resultLength = 0;
/* 106 */       for (int i = 0; i != x.length(); i++) {
/* 107 */         resultLength += times.getElementAsInt(i);
/*     */       }
/*     */     } 
/* 110 */     if (!IntVector.isNA(each)) {
/* 111 */       resultLength *= each;
/*     */     } else {
/* 113 */       each = 1;
/*     */     } 
/* 115 */     if (!IntVector.isNA(lengthOut)) {
/* 116 */       if (lengthOut < 0) {
/* 117 */         throw new EvalException("invalid 'length.out' argument", new Object[0]);
/*     */       }
/* 119 */       resultLength = lengthOut;
/*     */     } 
/*     */     
/* 122 */     if (times.length() > 1 && each > 1) {
/* 123 */       throw new EvalException("invalid 'times' argument", new Object[0]);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 132 */     if (x instanceof org.renjin.sexp.DoubleVector && times
/* 133 */       .length() == 1 && lengthOut != 0 && (x
/*     */       
/* 135 */       .isDeferred() || resultLength > 100))
/*     */     {
/* 137 */       return (Vector)new RepDoubleVector(x, resultLength, each, repeatAttributes(x, resultLength, each));
/*     */     }
/* 139 */     if (x instanceof IntVector && times
/* 140 */       .length() == 1 && lengthOut != 0 && (x
/*     */       
/* 142 */       .isDeferred() || resultLength > 100))
/*     */     {
/* 144 */       return (Vector)new RepIntVector(x, resultLength, each, repeatAttributes(x, resultLength, each));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 150 */     Vector.Builder result = x.newBuilderWithInitialCapacity(resultLength);
/* 151 */     AtomicVector names = x.getNames();
/* 152 */     StringVector.Builder resultNames = null;
/* 153 */     if (names != Null.INSTANCE) {
/* 154 */       resultNames = new StringVector.Builder(0, resultLength);
/*     */     }
/* 156 */     int result_i = 0;
/*     */     
/* 158 */     if (times.length() == 1) {
/* 159 */       for (int i = 0; i != resultLength; i++) {
/* 160 */         int x_i = i / each % x.length();
/* 161 */         result.setFrom(result_i++, (SEXP)x, x_i);
/* 162 */         if (resultNames != null) {
/* 163 */           resultNames.add(names.getElementAsString(x_i));
/*     */         }
/*     */       } 
/*     */     } else {
/* 167 */       for (int x_i = 0; x_i != x.length(); x_i++) {
/* 168 */         for (int j = 0; j < times.getElementAsInt(x_i); j++) {
/* 169 */           result.setFrom(result_i++, (SEXP)x, x_i);
/* 170 */           if (resultNames != null) {
/* 171 */             resultNames.add(names.getElementAsString(x_i));
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 176 */     if (resultNames != null) {
/* 177 */       result.setAttribute(Symbols.NAMES, (SEXP)resultNames.build());
/*     */     }
/*     */     
/* 180 */     return result.build();
/*     */   }
/*     */ 
/*     */   
/*     */   private static AttributeMap repeatAttributes(Vector source, int length, int each) {
/* 185 */     AtomicVector names = source.getNames();
/* 186 */     if (names != Null.INSTANCE) {
/* 187 */       AttributeMap.Builder repeated = AttributeMap.newBuilder();
/* 188 */       repeated.setNames(new RepStringVector((Vector)names, length, each, AttributeMap.EMPTY));
/* 189 */       return repeated.build();
/*     */     } 
/*     */     
/* 192 */     return AttributeMap.EMPTY;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/sequence/RepFunction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */