package org.renjin.packaging;

import java.io.InputStream;
import org.renjin.sexp.Closure;
import org.renjin.sexp.SEXP;
import org.renjin.sexp.Symbol;

public interface Loader {
  void addValue(Symbol paramSymbol, SEXP paramSEXP);
  
  void addActiveBinding(Symbol paramSymbol, Closure paramClosure);
  
  InputStream openResource(String paramString);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/packaging/Loader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */