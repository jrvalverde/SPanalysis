/*    */ package org.renjin.invoke.reflection.converters;
/*    */ 
/*    */ import org.renjin.sexp.ExternalPtr;
/*    */ import org.renjin.sexp.Null;
/*    */ import org.renjin.sexp.SEXP;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ObjectOfASpecificClassConverter
/*    */   implements Converter<Object>
/*    */ {
/*    */   private Class clazz;
/*    */   
/*    */   public ObjectOfASpecificClassConverter(Class clazz) {
/* 35 */     this.clazz = clazz;
/*    */   }
/*    */ 
/*    */   
/*    */   public SEXP convertToR(Object value) {
/* 40 */     if (value == null) {
/* 41 */       return (SEXP)Null.INSTANCE;
/*    */     }
/* 43 */     return (SEXP)new ExternalPtr(value);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Object convertToJava(SEXP exp) {
/* 50 */     if (exp instanceof ExternalPtr) {
/* 51 */       ExternalPtr ptr = (ExternalPtr)exp;
/* 52 */       if (this.clazz.isAssignableFrom(ptr.getInstance().getClass())) {
/* 53 */         return ptr.getInstance();
/*    */       }
/*    */     } 
/* 56 */     throw new ConversionException();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean acceptsSEXP(SEXP exp) {
/*    */     try {
/* 62 */       convertToJava(exp);
/* 63 */       return true;
/*    */     }
/* 65 */     catch (ConversionException e) {
/* 66 */       return false;
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public int getSpecificity() {
/* 72 */     return 10;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/reflection/converters/ObjectOfASpecificClassConverter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */