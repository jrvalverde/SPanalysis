/*    */ package org.renjin.compiler;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import java.util.Set;
/*    */ import org.renjin.compiler.builtins.ArgumentBounds;
/*    */ import org.renjin.compiler.cfg.InlinedFunction;
/*    */ import org.renjin.compiler.codegen.ApplyCallWriter;
/*    */ import org.renjin.compiler.ir.ValueBounds;
/*    */ import org.renjin.compiler.ir.tac.RuntimeState;
/*    */ import org.renjin.eval.Context;
/*    */ import org.renjin.eval.EvalException;
/*    */ import org.renjin.repackaged.guava.collect.Lists;
/*    */ import org.renjin.sexp.Closure;
/*    */ import org.renjin.sexp.Environment;
/*    */ import org.renjin.sexp.Null;
/*    */ import org.renjin.sexp.PairList;
/*    */ import org.renjin.sexp.SEXP;
/*    */ import org.renjin.sexp.Symbol;
/*    */ import org.renjin.sexp.Vector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ApplyCallCompiler
/*    */ {
/*    */   private final RuntimeState runtimeState;
/*    */   private final Closure closure;
/*    */   private final Vector vector;
/*    */   private InlinedFunction inlinedFunction;
/*    */   private ValueBounds functionBounds;
/*    */   private boolean pure;
/*    */   
/*    */   public ApplyCallCompiler(Context context, Environment rho, Closure closure, Vector vector) {
/* 48 */     this.closure = closure;
/* 49 */     this.vector = vector;
/* 50 */     this.runtimeState = new RuntimeState(context, rho);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void tryCompile() {
/* 60 */     Set<Symbol> suppliedFormals = Collections.singleton(findElementFormal(this.closure));
/* 61 */     List<ArgumentBounds> arguments = Lists.newArrayList((Object[])new ArgumentBounds[] { new ArgumentBounds(computeElementBounds()) });
/*    */ 
/*    */     
/* 64 */     this.inlinedFunction = new InlinedFunction(this.runtimeState, this.closure, suppliedFormals);
/* 65 */     this.functionBounds = this.inlinedFunction.updateBounds(arguments);
/* 66 */     this.pure = this.inlinedFunction.isPure();
/* 67 */     System.out.println("F = " + this.functionBounds);
/*    */   }
/*    */   
/*    */   private ValueBounds computeElementBounds() {
/* 71 */     return ValueBounds.of((SEXP)this.vector).getElementBounds();
/*    */   }
/*    */   
/*    */   private Symbol findElementFormal(Closure closure) {
/* 75 */     PairList formals = closure.getFormals();
/* 76 */     if (formals == Null.INSTANCE) {
/* 77 */       throw new EvalException("unused argument X[[i]]", new Object[0]);
/*    */     }
/* 79 */     return formals.getTag();
/*    */   }
/*    */   
/*    */   public ValueBounds getFunctionBounds() {
/* 83 */     return this.functionBounds;
/*    */   }
/*    */   
/*    */   public boolean isPure() {
/* 87 */     return this.pure;
/*    */   }
/*    */   
/*    */   public Class<?> compile() {
/* 91 */     ApplyCallWriter writer = new ApplyCallWriter(this.inlinedFunction, this.closure.getFormals().getTag(), computeElementBounds(), this.functionBounds);
/* 92 */     return writer.build();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/ApplyCallCompiler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */