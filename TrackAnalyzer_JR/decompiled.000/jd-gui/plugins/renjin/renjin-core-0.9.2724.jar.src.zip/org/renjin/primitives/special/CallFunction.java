/*    */ package org.renjin.primitives.special;
/*    */ 
/*    */ import org.renjin.eval.Context;
/*    */ import org.renjin.eval.EvalException;
/*    */ import org.renjin.sexp.Environment;
/*    */ import org.renjin.sexp.FunctionCall;
/*    */ import org.renjin.sexp.Null;
/*    */ import org.renjin.sexp.PairList;
/*    */ import org.renjin.sexp.SEXP;
/*    */ import org.renjin.sexp.SpecialFunction;
/*    */ import org.renjin.sexp.StringVector;
/*    */ import org.renjin.sexp.Symbol;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CallFunction
/*    */   extends SpecialFunction
/*    */ {
/*    */   public CallFunction() {
/* 29 */     super("call");
/*    */   }
/*    */ 
/*    */   
/*    */   public SEXP apply(Context context, Environment rho, FunctionCall call, PairList args) {
/* 34 */     if (call.length() < 1) {
/* 35 */       throw new EvalException("first argument must be character string", new Object[0]);
/*    */     }
/* 37 */     PairList.Node arg = (PairList.Node)args;
/* 38 */     SEXP name = context.evaluate(arg.getValue(), rho);
/* 39 */     if (!(name instanceof StringVector) || name.length() != 1) {
/* 40 */       throw new EvalException("first argument must be character string", new Object[0]);
/*    */     }
/*    */     
/* 43 */     Symbol function = Symbol.get(((StringVector)name).getElementAsString(0));
/*    */ 
/*    */     
/* 46 */     PairList.Builder evaluatedArguments = new PairList.Builder();
/* 47 */     PairList callArg = arg.getNext();
/* 48 */     while (callArg != Null.INSTANCE) {
/* 49 */       PairList.Node callArgNode = (PairList.Node)callArg;
/* 50 */       evaluatedArguments.add(callArgNode.getRawTag(), context.evaluate(callArgNode.getValue(), rho));
/* 51 */       callArg = callArgNode.getNext();
/*    */     } 
/*    */     
/* 54 */     return (SEXP)new FunctionCall((SEXP)function, evaluatedArguments.build());
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/special/CallFunction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */