package org.renjin.compiler;

import org.renjin.eval.Context;
import org.renjin.sexp.Environment;
import org.renjin.sexp.SEXP;

public interface CompiledLoopBody {
  SEXP run(Context paramContext, Environment paramEnvironment, SEXP paramSEXP, int paramInt);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/CompiledLoopBody.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */