/*    */ package org.renjin.compiler.builtins;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.renjin.compiler.codegen.EmitContext;
/*    */ import org.renjin.compiler.ir.ValueBounds;
/*    */ import org.renjin.compiler.ir.tac.IRArgument;
/*    */ import org.renjin.compiler.ir.tac.expressions.Expression;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ import org.renjin.repackaged.asm.commons.InstructionAdapter;
/*    */ import org.renjin.sexp.SEXP;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LengthCall
/*    */   implements Specialization
/*    */ {
/*    */   public Type getType() {
/* 35 */     return Type.INT_TYPE;
/*    */   }
/*    */   
/*    */   public ValueBounds getResultBounds() {
/* 39 */     return ValueBounds.INT_PRIMITIVE;
/*    */   }
/*    */ 
/*    */   
/*    */   public void load(EmitContext emitContext, InstructionAdapter mv, List<IRArgument> arguments) {
/* 44 */     Expression argument = ((IRArgument)arguments.get(0)).getExpression();
/* 45 */     argument.load(emitContext, mv);
/* 46 */     emitContext.convert(mv, argument.getType(), Type.getType(SEXP.class));
/*    */     
/* 48 */     mv.invokeinterface(Type.getInternalName(SEXP.class), "length", 
/* 49 */         Type.getMethodDescriptor(Type.INT_TYPE, new Type[] { Type.getType(SEXP.class) }));
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isPure() {
/* 54 */     return true;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/builtins/LengthCall.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */