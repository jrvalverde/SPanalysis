/*    */ package org.renjin.compiler.ir.tac.functions;
/*    */ 
/*    */ import org.renjin.compiler.NotCompilableException;
/*    */ import org.renjin.compiler.ir.exception.InvalidSyntaxException;
/*    */ import org.renjin.compiler.ir.tac.IRBodyBuilder;
/*    */ import org.renjin.compiler.ir.tac.InlinedContext;
/*    */ import org.renjin.compiler.ir.tac.expressions.Constant;
/*    */ import org.renjin.compiler.ir.tac.expressions.EnvironmentVariable;
/*    */ import org.renjin.compiler.ir.tac.expressions.Expression;
/*    */ import org.renjin.compiler.ir.tac.expressions.UseMethodCall;
/*    */ import org.renjin.sexp.Function;
/*    */ import org.renjin.sexp.FunctionCall;
/*    */ import org.renjin.sexp.Null;
/*    */ import org.renjin.sexp.PairList;
/*    */ import org.renjin.sexp.SEXP;
/*    */ import org.renjin.sexp.StringVector;
/*    */ import org.renjin.sexp.Symbol;
/*    */ import org.renjin.sexp.Symbols;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UseMethodTranslator
/*    */   extends FunctionCallTranslator
/*    */ {
/*    */   public Expression translateToExpression(IRBodyBuilder builder, TranslationContext context, Function resolvedFunction, FunctionCall call) {
/*    */     EnvironmentVariable environmentVariable;
/* 41 */     if (!(context instanceof InlinedContext)) {
/* 42 */       throw new InvalidSyntaxException("'UseMethod' used in an inappropriate fashion.");
/*    */     }
/*    */     
/* 45 */     InlinedContext inlinedContext = (InlinedContext)context;
/*    */     
/* 47 */     int arity = call.getArguments().length();
/*    */ 
/*    */     
/* 50 */     if (arity < 1) {
/* 51 */       throw new InvalidSyntaxException("There must be a 'generic' argument");
/*    */     }
/*    */     
/* 54 */     SEXP genericSexp = call.getArgument(0);
/* 55 */     if (!(genericSexp instanceof StringVector) || genericSexp.length() != 1) {
/* 56 */       throw new InvalidSyntaxException("'generic' must be a character string");
/*    */     }
/* 58 */     String generic = ((StringVector)genericSexp).getElementAsString(0);
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 63 */     if (arity == 1) {
/* 64 */       PairList formals = inlinedContext.getFormals();
/* 65 */       if (formals == Null.INSTANCE) {
/* 66 */         Constant constant = new Constant((SEXP)Null.INSTANCE);
/*    */       } else {
/* 68 */         Symbol formalName = formals.getTag();
/* 69 */         if (formalName == Symbols.ELLIPSES) {
/* 70 */           throw new NotCompilableException(call, "UseMethod() not supported when first argument to function is '...'");
/*    */         }
/* 72 */         environmentVariable = new EnvironmentVariable(formalName);
/*    */       } 
/*    */     } else {
/*    */       
/* 76 */       throw new NotCompilableException(call);
/*    */     } 
/*    */     
/* 79 */     assertUnaryFunction(call, inlinedContext.getFormals());
/*    */     
/* 81 */     return (Expression)new UseMethodCall(builder.getRuntimeState(), call, generic, (Expression)environmentVariable);
/*    */   }
/*    */   
/*    */   private void assertUnaryFunction(FunctionCall call, PairList formals) {
/* 85 */     PairList second = ((PairList.Node)formals).getNext();
/* 86 */     if (second == Null.INSTANCE) {
/*    */       return;
/*    */     }
/*    */     
/* 90 */     PairList.Node secondNode = (PairList.Node)second;
/* 91 */     if (secondNode.getRawTag() != Symbols.ELLIPSES || secondNode.getNext() != Null.INSTANCE) {
/* 92 */       throw new NotCompilableException(call, "UseMethod() not yet supported when more than one argument is present.");
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public void addStatement(IRBodyBuilder builder, TranslationContext context, Function resolvedFunction, FunctionCall call) {
/* 98 */     throw new NotCompilableException(call);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/ir/tac/functions/UseMethodTranslator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */