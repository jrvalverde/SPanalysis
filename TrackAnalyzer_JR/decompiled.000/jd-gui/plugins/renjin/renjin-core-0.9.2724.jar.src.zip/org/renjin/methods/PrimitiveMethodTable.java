/*    */ package org.renjin.methods;
/*    */ 
/*    */ import java.util.concurrent.ExecutionException;
/*    */ import org.renjin.repackaged.guava.cache.CacheBuilder;
/*    */ import org.renjin.repackaged.guava.cache.CacheLoader;
/*    */ import org.renjin.repackaged.guava.cache.LoadingCache;
/*    */ import org.renjin.sexp.Closure;
/*    */ import org.renjin.sexp.Null;
/*    */ import org.renjin.sexp.PrimitiveFunction;
/*    */ import org.renjin.sexp.SEXP;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PrimitiveMethodTable
/*    */ {
/*    */   private LoadingCache<PrimitiveFunction, Entry> map;
/*    */   
/*    */   public enum prim_methods_t
/*    */   {
/* 33 */     NO_METHODS, NEEDS_RESET, HAS_METHODS, SUPPRESSED;
/*    */   }
/*    */   
/*    */   public static class Entry {
/*    */     private PrimitiveMethodTable.prim_methods_t methods;
/*    */     private Closure generic;
/* 39 */     private SEXP methodList = (SEXP)Null.INSTANCE;
/*    */     
/*    */     public void setMethods(PrimitiveMethodTable.prim_methods_t code) {
/* 42 */       this.methods = code;
/*    */     }
/*    */ 
/*    */     
/*    */     public void setGeneric(Closure fundef) {
/* 47 */       this.generic = fundef;
/*    */     }
/*    */     
/*    */     public void setMethodList(SEXP methodList) {
/* 51 */       this.methodList = methodList;
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   private boolean primitiveMethodsAllowed = false;
/*    */ 
/*    */   
/*    */   public PrimitiveMethodTable() {
/* 60 */     this
/* 61 */       .map = CacheBuilder.newBuilder().build(new CacheLoader<PrimitiveFunction, Entry>()
/*    */         {
/*    */           public PrimitiveMethodTable.Entry load(PrimitiveFunction key) throws Exception
/*    */           {
/* 65 */             return new PrimitiveMethodTable.Entry();
/*    */           }
/*    */         });
/*    */   }
/*    */   
/*    */   public Entry get(PrimitiveFunction fn) {
/*    */     try {
/* 72 */       return (Entry)this.map.get(fn);
/* 73 */     } catch (ExecutionException e) {
/* 74 */       throw new RuntimeException(e);
/*    */     } 
/*    */   }
/*    */   
/*    */   public boolean isPrimitiveMethodsAllowed() {
/* 79 */     return this.primitiveMethodsAllowed;
/*    */   }
/*    */   
/*    */   public void setPrimitiveMethodsAllowed(boolean primitiveMethodsAllowed) {
/* 83 */     this.primitiveMethodsAllowed = primitiveMethodsAllowed;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/methods/PrimitiveMethodTable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */