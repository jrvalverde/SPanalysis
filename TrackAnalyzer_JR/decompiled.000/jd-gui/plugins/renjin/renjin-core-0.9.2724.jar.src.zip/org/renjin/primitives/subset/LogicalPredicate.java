/*    */ package org.renjin.primitives.subset;
/*    */ 
/*    */ import org.renjin.sexp.LogicalVector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class LogicalPredicate
/*    */   implements IndexPredicate
/*    */ {
/*    */   private LogicalVector subscript;
/*    */   
/*    */   public LogicalPredicate(LogicalVector subscript) {
/* 30 */     assert subscript.length() != 0;
/* 31 */     this.subscript = subscript;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean apply(int index) {
/* 36 */     int mask = this.subscript.getElementAsRawLogical(index % this.subscript.length());
/* 37 */     return (mask == 1);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/subset/LogicalPredicate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */