package org.renjin.invoke;

import org.renjin.invoke.reflection.MemberBinding;
import org.renjin.sexp.Symbol;

public interface ClassBinding {
  MemberBinding getMemberBinding(Symbol paramSymbol);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/ClassBinding.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */