/*    */ package org.renjin.invoke.reflection.converters;
/*    */ 
/*    */ import org.renjin.sexp.DoubleArrayVector;
/*    */ import org.renjin.sexp.DoubleVector;
/*    */ import org.renjin.sexp.LongArrayVector;
/*    */ import org.renjin.sexp.SEXP;
/*    */ import org.renjin.sexp.Vector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LongConverter
/*    */   extends PrimitiveScalarConverter<Number>
/*    */ {
/* 33 */   public static final Converter INSTANCE = new LongConverter();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SEXP convertToR(Number value) {
/* 40 */     if (value == null) {
/* 41 */       return (SEXP)new DoubleArrayVector(new double[] { DoubleVector.NA });
/*    */     }
/* 43 */     return (SEXP)new LongArrayVector(value.longValue());
/*    */   }
/*    */ 
/*    */   
/*    */   public static boolean accept(Class<long> clazz) {
/* 48 */     return (clazz == long.class || clazz == Long.class);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Vector.Type getVectorType() {
/* 54 */     return (Vector.Type)DoubleVector.VECTOR_TYPE;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Object getFirstElement(Vector value) {
/* 59 */     if (value instanceof LongArrayVector) {
/* 60 */       return Long.valueOf(((LongArrayVector)value).getElementAsLong(0));
/*    */     }
/* 62 */     return Long.valueOf((long)value.getElementAsDouble(0));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean acceptsSEXP(SEXP exp) {
/* 68 */     return (exp instanceof DoubleVector || exp instanceof org.renjin.sexp.IntVector || exp instanceof org.renjin.sexp.LogicalVector);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int getSpecificity() {
/* 74 */     return 3;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/reflection/converters/LongConverter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */