/*    */ package org.renjin.invoke.model;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.renjin.sexp.DoubleArrayVector;
/*    */ import org.renjin.sexp.IntArrayVector;
/*    */ import org.renjin.sexp.ListVector;
/*    */ import org.renjin.sexp.Logical;
/*    */ import org.renjin.sexp.LogicalArrayVector;
/*    */ import org.renjin.sexp.PairList;
/*    */ import org.renjin.sexp.SEXP;
/*    */ import org.renjin.sexp.StringVector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class FriendlyTypesNames
/*    */ {
/* 31 */   private static FriendlyTypesNames INSTANCE = null;
/*    */   
/*    */   private Map<Class, String> names;
/*    */   
/*    */   private FriendlyTypesNames() {
/* 36 */     this.names = (Map)new HashMap<>();
/* 37 */     this.names.put(SEXP[].class, "...");
/* 38 */     this.names.put(SEXP.class, "any");
/* 39 */     this.names.put(LogicalArrayVector.class, "logical");
/* 40 */     this.names.put(Logical.class, "logical");
/* 41 */     this.names.put(Boolean.class, "logical");
/* 42 */     this.names.put(boolean.class, "logical");
/* 43 */     this.names.put(IntArrayVector.class, "integer");
/* 44 */     this.names.put(Integer.class, "integer");
/* 45 */     this.names.put(int.class, "integer");
/* 46 */     this.names.put(DoubleArrayVector.class, "double");
/* 47 */     this.names.put(Double.class, "double");
/* 48 */     this.names.put(double.class, "double");
/* 49 */     this.names.put(String.class, "character");
/* 50 */     this.names.put(StringVector.class, "character");
/* 51 */     this.names.put(ListVector.class, "list");
/* 52 */     this.names.put(PairList.Node.class, "pairlist");
/*    */   }
/*    */   
/*    */   public static FriendlyTypesNames get() {
/* 56 */     if (INSTANCE == null) {
/* 57 */       INSTANCE = new FriendlyTypesNames();
/*    */     }
/* 59 */     return INSTANCE;
/*    */   }
/*    */   
/*    */   public String format(Class clazz) {
/* 63 */     if (this.names.containsKey(clazz)) {
/* 64 */       return this.names.get(clazz);
/*    */     }
/* 66 */     return clazz.getSimpleName();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/model/FriendlyTypesNames.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */