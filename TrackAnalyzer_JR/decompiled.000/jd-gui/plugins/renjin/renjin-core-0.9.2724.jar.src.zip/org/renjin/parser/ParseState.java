/*    */ package org.renjin.parser;
/*    */ 
/*    */ import org.renjin.sexp.Null;
/*    */ import org.renjin.sexp.SEXP;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ParseState
/*    */ {
/*    */   public static final int MAXNEST = 256;
/*    */   boolean eatLines = false;
/*    */   boolean keepSrcRefs = false;
/* 43 */   SEXP srcFile = (SEXP)Null.INSTANCE;
/*    */ 
/*    */ 
/*    */   
/*    */   int srcFileProt;
/*    */ 
/*    */   
/* 50 */   private FunctionSourceBuffer functionSource = new FunctionSourceBuffer();
/*    */   
/*    */   public FunctionSourceBuffer getFunctionSource() {
/* 53 */     return this.functionSource;
/*    */   }
/*    */   
/*    */   public void setEatLines(boolean eatLines) {
/* 57 */     this.eatLines = eatLines;
/*    */   }
/*    */   
/*    */   public boolean getEatLines() {
/* 61 */     return this.eatLines;
/*    */   }
/*    */   
/*    */   public SEXP getSrcFile() {
/* 65 */     return this.srcFile;
/*    */   }
/*    */   
/*    */   public void setSrcFile(SEXP srcFile) {
/* 69 */     this.srcFile = srcFile;
/*    */   }
/*    */   
/*    */   public void setKeepSrcRefs(boolean keepSrcRefs) {
/* 73 */     this.keepSrcRefs = keepSrcRefs;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/parser/ParseState.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */