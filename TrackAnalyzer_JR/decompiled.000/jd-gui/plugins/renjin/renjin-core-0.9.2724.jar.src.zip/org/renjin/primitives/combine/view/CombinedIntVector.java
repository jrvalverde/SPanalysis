/*     */ package org.renjin.primitives.combine.view;
/*     */ 
/*     */ import org.renjin.primitives.vector.DeferredComputation;
/*     */ import org.renjin.sexp.AttributeMap;
/*     */ import org.renjin.sexp.IntVector;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CombinedIntVector
/*     */   extends IntVector
/*     */   implements DeferredComputation
/*     */ {
/*     */   private final Vector[] vectors;
/*     */   private final int[] endIndex;
/*     */   private final int totalLength;
/*     */   
/*     */   public static IntVector combine(Vector[] vectors, AttributeMap attributeMap) {
/*  34 */     if (vectors.length == 1)
/*  35 */       return (IntVector)vectors[0].setAttributes(attributeMap); 
/*  36 */     if (equalLength(vectors)) {
/*  37 */       return new CompositeIntColumnMatrix(vectors, attributeMap);
/*     */     }
/*  39 */     return new CombinedIntVector(vectors, attributeMap);
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean equalLength(Vector[] vectors) {
/*  44 */     int length = vectors[0].length();
/*  45 */     for (int i = 1; i < vectors.length; i++) {
/*  46 */       if (vectors[i].length() != length) {
/*  47 */         return false;
/*     */       }
/*     */     } 
/*  50 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   private CombinedIntVector(Vector[] vectors, AttributeMap attributeMap) {
/*  55 */     super(attributeMap);
/*     */     
/*  57 */     this.vectors = vectors;
/*  58 */     this.endIndex = new int[vectors.length];
/*     */     
/*  60 */     int totalLength = 0;
/*  61 */     for (int i = 0; i != vectors.length; i++) {
/*  62 */       totalLength += vectors[i].length();
/*  63 */       this.endIndex[i] = totalLength;
/*     */     } 
/*  65 */     this.totalLength = totalLength;
/*     */   }
/*     */ 
/*     */   
/*     */   public Vector[] getOperands() {
/*  70 */     return this.vectors;
/*     */   }
/*     */   
/*     */   public int[] getEndIndices() {
/*  74 */     return this.endIndex;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getComputationName() {
/*  79 */     return "c";
/*     */   }
/*     */ 
/*     */   
/*     */   protected SEXP cloneWithNewAttributes(AttributeMap attributes) {
/*  84 */     return (SEXP)new CombinedIntVector(this.vectors, attributes);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getElementAsInt(int index) {
/*  89 */     if (index < this.endIndex[0]) {
/*  90 */       return this.vectors[0].getElementAsInt(index);
/*     */     }
/*  92 */     if (index < this.endIndex[1]) {
/*  93 */       return this.vectors[1].getElementAsInt(index - this.endIndex[0]);
/*     */     }
/*  95 */     if (index < this.endIndex[2]) {
/*  96 */       return this.vectors[2].getElementAsInt(index - this.endIndex[1]);
/*     */     }
/*  98 */     if (index < this.endIndex[3]) {
/*  99 */       return this.vectors[3].getElementAsInt(index - this.endIndex[2]);
/*     */     }
/* 101 */     for (int i = 4; i < this.vectors.length; i++) {
/* 102 */       if (index < this.endIndex[i]) {
/* 103 */         return this.vectors[i].getElementAsInt(index - this.endIndex[i - 1]);
/*     */       }
/*     */     } 
/* 106 */     throw new IllegalArgumentException("index: " + index);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isConstantAccessTime() {
/* 111 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDeferred() {
/* 116 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int length() {
/* 121 */     return this.totalLength;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/combine/view/CombinedIntVector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */