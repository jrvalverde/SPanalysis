/*    */ package org.renjin.parser;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ParseOptions
/*    */ {
/*    */   private boolean generateCode = true;
/*    */   private boolean keepSource = true;
/*    */   private boolean warnEscapes = true;
/*    */   
/*    */   public boolean isGenerateCode() {
/* 30 */     return this.generateCode;
/*    */   }
/*    */   
/*    */   public void setGenerateCode(boolean generateCode) {
/* 34 */     this.generateCode = generateCode;
/*    */   }
/*    */   
/*    */   public boolean isKeepSource() {
/* 38 */     return this.keepSource;
/*    */   }
/*    */   
/*    */   public void setKeepSource(boolean keepSource) {
/* 42 */     this.keepSource = keepSource;
/*    */   }
/*    */   
/*    */   public boolean isWarnEscapes() {
/* 46 */     return this.warnEscapes;
/*    */   }
/*    */   
/*    */   public void setWarnEscapes(boolean warnEscapes) {
/* 50 */     this.warnEscapes = warnEscapes;
/*    */   }
/*    */   
/*    */   public static ParseOptions defaults() {
/* 54 */     return new ParseOptions();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/parser/ParseOptions.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */