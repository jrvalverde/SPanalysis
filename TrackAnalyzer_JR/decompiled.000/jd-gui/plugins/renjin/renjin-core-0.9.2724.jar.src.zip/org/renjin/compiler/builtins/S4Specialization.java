/*     */ package org.renjin.compiler.builtins;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.renjin.compiler.cfg.InlinedFunction;
/*     */ import org.renjin.compiler.codegen.EmitContext;
/*     */ import org.renjin.compiler.ir.ValueBounds;
/*     */ import org.renjin.compiler.ir.tac.IRArgument;
/*     */ import org.renjin.compiler.ir.tac.RuntimeState;
/*     */ import org.renjin.compiler.ir.tac.expressions.Expression;
/*     */ import org.renjin.eval.MatchedArgumentPositions;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ import org.renjin.repackaged.asm.commons.InstructionAdapter;
/*     */ import org.renjin.sexp.Closure;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class S4Specialization
/*     */   implements Specialization
/*     */ {
/*     */   private RuntimeState runtimeState;
/*     */   private Closure closure;
/*  45 */   private InlinedFunction inlinedMethod = null;
/*     */   
/*     */   private MatchedArgumentPositions matchedArguments;
/*     */   private Type type;
/*     */   private ValueBounds returnBounds;
/*     */   
/*     */   public S4Specialization(RuntimeState runtimeState, Closure closure, List<ArgumentBounds> arguments) {
/*  52 */     this.runtimeState = runtimeState;
/*  53 */     this.closure = closure;
/*     */     
/*  55 */     updateTypeBounds(closure, arguments);
/*     */   }
/*     */   
/*     */   public S4Specialization(RuntimeState runtimeState, Closure closure, Map<Expression, ValueBounds> typeMap, List<IRArgument> arguments) {
/*  59 */     this(runtimeState, closure, ArgumentBounds.create(arguments, typeMap));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateTypeBounds(Closure function, List<ArgumentBounds> arguments) {
/*  66 */     if (this.inlinedMethod == null || this.inlinedMethod.getClosure() != function) {
/*  67 */       this.matchedArguments = MatchedArgumentPositions.matchArgumentBounds(this.closure, arguments);
/*  68 */       this.inlinedMethod = new InlinedFunction(this.runtimeState, this.closure, this.matchedArguments.getSuppliedFormals());
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  75 */     this.returnBounds = this.inlinedMethod.updateBounds(arguments);
/*  76 */     this.type = this.returnBounds.storageType();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static Specialization trySpecialize(String generic, RuntimeState runtimeState, ValueBounds objectExpr, List<ArgumentBounds> arguments) {
/*  82 */     return UnspecializedCall.INSTANCE;
/*     */   }
/*     */ 
/*     */   
/*     */   public Type getType() {
/*  87 */     return this.type;
/*     */   }
/*     */ 
/*     */   
/*     */   public ValueBounds getResultBounds() {
/*  92 */     return this.returnBounds;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void load(EmitContext emitContext, InstructionAdapter mv, List<IRArgument> arguments) {
/*  98 */     if (this.inlinedMethod == null) {
/*  99 */       throw new FailedToSpecializeException("Could not resolve S4 method");
/*     */     }
/*     */     
/* 102 */     if (this.matchedArguments.hasExtraArguments()) {
/* 103 */       throw new FailedToSpecializeException("Extra arguments not supported");
/*     */     }
/*     */     
/* 106 */     this.inlinedMethod.writeInline(emitContext, mv, this.matchedArguments, arguments);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isPure() {
/* 112 */     if (this.inlinedMethod == null) {
/* 113 */       return false;
/*     */     }
/* 115 */     return this.inlinedMethod.isPure();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/builtins/S4Specialization.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */