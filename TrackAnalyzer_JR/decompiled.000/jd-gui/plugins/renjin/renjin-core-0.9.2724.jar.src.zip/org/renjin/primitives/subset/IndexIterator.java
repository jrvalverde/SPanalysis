package org.renjin.primitives.subset;

public interface IndexIterator {
  public static final int EOF = -1;
  
  int next();
  
  void restart();
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/subset/IndexIterator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */