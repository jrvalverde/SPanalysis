/*    */ package org.renjin.compiler.builtins;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.renjin.compiler.codegen.EmitContext;
/*    */ import org.renjin.compiler.ir.ValueBounds;
/*    */ import org.renjin.compiler.ir.tac.IRArgument;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ import org.renjin.repackaged.asm.commons.InstructionAdapter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UpdateElementCall
/*    */   implements Specialization
/*    */ {
/*    */   private ValueBounds inputVector;
/*    */   private ValueBounds subscript;
/*    */   private ValueBounds replacement;
/*    */   
/*    */   public UpdateElementCall(ValueBounds inputVector, ValueBounds subscript, ValueBounds replacement) {
/* 39 */     this.inputVector = inputVector;
/* 40 */     this.subscript = subscript;
/* 41 */     this.replacement = replacement;
/*    */   }
/*    */ 
/*    */   
/*    */   public Type getType() {
/* 46 */     return this.inputVector.storageType();
/*    */   }
/*    */   
/*    */   public ValueBounds getResultBounds() {
/* 50 */     return this.inputVector.withVaryingValues();
/*    */   }
/*    */ 
/*    */   
/*    */   public void load(EmitContext emitContext, InstructionAdapter mv, List<IRArgument> arguments) {
/* 55 */     throw new FailedToSpecializeException("TODO");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isPure() {
/* 62 */     return true;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/builtins/UpdateElementCall.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */