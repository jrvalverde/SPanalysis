/*     */ package org.renjin.primitives.io.serialization;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.CharsetDecoder;
/*     */ import java.util.Arrays;
/*     */ import org.renjin.sexp.AttributeMap;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.StringVector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StringByteArrayVector
/*     */   extends StringVector
/*     */ {
/*     */   private static final int MAX_ARRAY_SIZE = 2147483639;
/*     */   private final byte[] buffer;
/*     */   private final Charset charset;
/*     */   private final CharsetDecoder decoder;
/*     */   private int[] offsets;
/*     */   private int length;
/*     */   
/*     */   private StringByteArrayVector(int[] offsets, byte[] buffer, Charset charset, AttributeMap attributeMap) {
/*  62 */     super(attributeMap);
/*  63 */     this.offsets = offsets;
/*  64 */     this.buffer = buffer;
/*  65 */     this.charset = charset;
/*  66 */     this.decoder = charset.newDecoder();
/*  67 */     this.length = offsets.length - 1;
/*     */   }
/*     */ 
/*     */   
/*     */   public int length() {
/*  72 */     return this.length;
/*     */   }
/*     */ 
/*     */   
/*     */   protected StringVector cloneWithNewAttributes(AttributeMap attributes) {
/*  77 */     return new StringByteArrayVector(this.offsets, this.buffer, this.charset, attributes);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getElementAsString(int index) {
/*  82 */     int offset = this.offsets[index];
/*  83 */     if (offset < 0) {
/*  84 */       return null;
/*     */     }
/*  86 */     int endPos = this.offsets[index + 1];
/*     */ 
/*     */     
/*  89 */     if (endPos < 0) {
/*  90 */       endPos = -endPos;
/*     */     }
/*  92 */     int length = endPos - offset;
/*  93 */     return new String(this.buffer, offset, length, this.charset);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isElementNA(int index) {
/*  99 */     return (this.offsets[index] < 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isConstantAccessTime() {
/* 104 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 109 */     StringBuilder sb = new StringBuilder("StringByteArrayVector{");
/* 110 */     for (int i = 0; i < Math.min(10, length()); i++) {
/* 111 */       if (i != 0) {
/* 112 */         sb.append(", ");
/*     */       }
/* 114 */       if (isElementNA(i)) {
/* 115 */         sb.append("NA");
/*     */       } else {
/* 117 */         sb.append("'").append(getElementAsString(i)).append("'");
/*     */       } 
/*     */     } 
/* 120 */     if (length() > 10) {
/* 121 */       sb.append(",... ").append(length()).append(" elements in total");
/*     */     }
/* 123 */     sb.append("}");
/* 124 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public static class Builder
/*     */   {
/*     */     private int[] offsets;
/*     */     private byte[] buffer;
/* 132 */     private int currentOffset = 0;
/* 133 */     private int currentIndex = 0;
/*     */     
/* 135 */     private Charset charset = Charset.defaultCharset();
/*     */     
/*     */     public Builder(int numElements) {
/* 138 */       this.offsets = new int[numElements + 1];
/* 139 */       this.buffer = new byte[1024];
/*     */     }
/*     */     
/*     */     public void addNA() {
/* 143 */       this.offsets[this.currentIndex++] = -1;
/*     */     }
/*     */     
/*     */     public void readFrom(RDataReader.StreamReader in, int length) throws IOException {
/* 147 */       if (length < 0) {
/* 148 */         this.offsets[this.currentIndex] = -this.currentOffset;
/*     */       } else {
/* 150 */         int minimumCapacity = this.currentOffset + length;
/* 151 */         if (minimumCapacity > this.buffer.length) {
/* 152 */           grow(minimumCapacity);
/*     */         }
/* 154 */         this.offsets[this.currentIndex] = this.currentOffset;
/* 155 */         in.readFully(this.buffer, this.currentOffset, length);
/* 156 */         this.currentOffset += length;
/*     */       } 
/* 158 */       this.currentIndex++;
/*     */     }
/*     */     
/*     */     public void setCharset(Charset charset) {
/* 162 */       this.charset = charset;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void grow(int minCapacity) {
/* 173 */       int newCapacity, oldCapacity = this.buffer.length;
/*     */       
/* 175 */       double averageElementSize = this.currentOffset / this.currentIndex;
/* 176 */       int expectedCapacity = (int)(averageElementSize * this.offsets.length);
/*     */ 
/*     */       
/* 179 */       if (expectedCapacity > minCapacity) {
/* 180 */         newCapacity = expectedCapacity;
/*     */       } else {
/* 182 */         newCapacity = oldCapacity << 1;
/*     */       } 
/* 184 */       if (newCapacity - minCapacity < 0) {
/* 185 */         newCapacity = minCapacity;
/*     */       }
/* 187 */       if (newCapacity - 2147483639 > 0) {
/* 188 */         newCapacity = hugeCapacity(minCapacity);
/*     */       }
/* 190 */       this.buffer = Arrays.copyOf(this.buffer, newCapacity);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private static int hugeCapacity(int minCapacity) {
/* 197 */       if (minCapacity < 0)
/*     */       {
/* 199 */         throw new OutOfMemoryError();
/*     */       }
/* 201 */       return (minCapacity > 2147483639) ? Integer.MAX_VALUE : 2147483639;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public SEXP build(AttributeMap attributeMap) {
/* 207 */       if (this.currentIndex != this.offsets.length - 1) {
/* 208 */         throw new IllegalStateException("Expected " + (this.offsets.length - 1) + " elements, but only " + this.currentIndex + " added.");
/*     */       }
/*     */ 
/*     */       
/* 212 */       this.offsets[this.currentIndex] = this.currentOffset;
/*     */       
/* 214 */       int excessCapacity = this.buffer.length - this.currentOffset;
/* 215 */       if (excessCapacity > 10240)
/*     */       {
/*     */         
/* 218 */         this.buffer = Arrays.copyOf(this.buffer, this.currentOffset);
/*     */       }
/*     */       
/* 221 */       return (SEXP)new StringByteArrayVector(this.offsets, this.buffer, this.charset, attributeMap);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/io/serialization/StringByteArrayVector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */