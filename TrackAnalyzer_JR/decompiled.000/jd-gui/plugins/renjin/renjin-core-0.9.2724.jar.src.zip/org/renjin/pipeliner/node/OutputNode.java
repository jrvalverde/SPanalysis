/*    */ package org.renjin.pipeliner.node;
/*    */ 
/*    */ import org.renjin.primitives.ni.NativeOutputVector;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ import org.renjin.sexp.Vector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OutputNode
/*    */   extends DeferredNode
/*    */ {
/*    */   private NativeOutputVector vector;
/*    */   
/*    */   public OutputNode(NativeOutputVector vector) {
/* 34 */     this.vector = vector;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getDebugLabel() {
/* 39 */     return this.vector.getCall().getOutputName(this.vector.getOutputIndex());
/*    */   }
/*    */ 
/*    */   
/*    */   public NodeShape getShape() {
/* 44 */     return NodeShape.BOX;
/*    */   }
/*    */ 
/*    */   
/*    */   public Type getResultVectorType() {
/* 49 */     return Type.getType(this.vector.getClass());
/*    */   }
/*    */ 
/*    */   
/*    */   public Vector getVector() {
/* 54 */     return (Vector)this.vector;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/pipeliner/node/OutputNode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */