/*    */ package org.renjin.pipeliner.optimize;
/*    */ 
/*    */ import org.renjin.pipeliner.DeferredGraph;
/*    */ import org.renjin.pipeliner.node.FunctionNode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RepeatRaiser
/*    */   implements Optimizer
/*    */ {
/*    */   public boolean optimize(DeferredGraph graph, FunctionNode node) {
/* 30 */     return false;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/pipeliner/optimize/RepeatRaiser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */