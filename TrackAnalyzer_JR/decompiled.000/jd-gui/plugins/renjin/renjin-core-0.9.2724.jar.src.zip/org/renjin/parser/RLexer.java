/*      */ package org.renjin.parser;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.Reader;
/*      */ import java.util.logging.Logger;
/*      */ import org.apache.commons.math.complex.Complex;
/*      */ import org.renjin.sexp.AttributeMap;
/*      */ import org.renjin.sexp.ComplexArrayVector;
/*      */ import org.renjin.sexp.DoubleArrayVector;
/*      */ import org.renjin.sexp.DoubleVector;
/*      */ import org.renjin.sexp.Environment;
/*      */ import org.renjin.sexp.IntArrayVector;
/*      */ import org.renjin.sexp.Logical;
/*      */ import org.renjin.sexp.LogicalArrayVector;
/*      */ import org.renjin.sexp.Null;
/*      */ import org.renjin.sexp.SEXP;
/*      */ import org.renjin.sexp.StringVector;
/*      */ import org.renjin.sexp.Symbol;
/*      */ import org.renjin.util.CDefines;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class RLexer
/*      */   implements RParser.Lexer
/*      */ {
/*   40 */   public static int R_ParseContextLine = 0;
/*      */   
/*   42 */   private static Logger logger = Logger.getLogger("R.Lexer");
/*      */   
/*      */   private int savedToken;
/*      */   private SEXP savedLVal;
/*   46 */   private Position savedTokenPos = null;
/*      */   
/*      */   private SEXP yylval;
/*      */   
/*      */   private final ParseState parseState;
/*      */   
/*      */   private final ParseOptions parseOptions;
/*      */   
/*   54 */   private Position tokenBegin = new Position();
/*   55 */   private Position tokenEnd = new Position();
/*      */   
/*      */   private RLexerReader reader;
/*      */   
/*   59 */   private final LexerContextStack contextStack = new LexerContextStack();
/*      */   
/*      */   private static class Keyword
/*      */   {
/*      */     public String name;
/*      */     public int token;
/*      */     
/*      */     public Keyword(String name, int token) {
/*   67 */       this.name = name;
/*   68 */       this.token = token;
/*      */     }
/*      */   }
/*      */   
/*   72 */   private Keyword[] keywords = new Keyword[] { new Keyword("NULL", 262), new Keyword("NA", 261), new Keyword("TRUE", 261), new Keyword("FALSE", 261), new Keyword("Inf", 261), new Keyword("NaN", 261), new Keyword("NA_integer_", 261), new Keyword("NA_real_", 261), new Keyword("NA_character_", 261), new Keyword("NA_complex_", 261), new Keyword("function", 264), new Keyword("while", 273), new Keyword("repeat", 276), new Keyword("for", 269), new Keyword("if", 271), new Keyword("in", 270), new Keyword("else", 272), new Keyword("next", 274), new Keyword("break", 275), new Keyword("...", 263) };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private RParser.Location errorLocation;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String errorMessage;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RLexer(ParseOptions options, ParseState state, Reader reader) {
/*  100 */     this.reader = new RLexerReader(reader);
/*  101 */     this.parseOptions = options;
/*  102 */     this.parseState = state;
/*      */   }
/*      */ 
/*      */   
/*      */   public Position getStartPos() {
/*  107 */     return this.tokenBegin;
/*      */   }
/*      */   
/*      */   public Position getEndPos() {
/*  111 */     return this.tokenEnd;
/*      */   }
/*      */   
/*      */   public SEXP getLVal() {
/*  115 */     return this.yylval;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int yylex() {
/*      */     int token;
/*      */     while (true) {
/*  124 */       token = consumeNextToken();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  131 */       if (token == 10) {
/*      */         
/*  133 */         if (this.parseState.getEatLines() || this.contextStack.peek() == '[' || this.contextStack
/*  134 */           .peek() == '(') {
/*      */           continue;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  143 */         if (this.contextStack.peek() == 'i') {
/*      */ 
/*      */ 
/*      */           
/*  147 */           while (token == 10) {
/*  148 */             token = consumeNextToken();
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  157 */           if (token == 125 || token == 41 || token == 93) {
/*  158 */             while (this.contextStack.peek() == 'i') {
/*  159 */               this.contextStack.ifPop();
/*      */             }
/*  161 */             this.contextStack.pop();
/*  162 */             setlastloc();
/*  163 */             return token;
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  171 */           if (token == 44) {
/*  172 */             this.contextStack.ifPop();
/*  173 */             setlastloc();
/*  174 */             return token;
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  186 */           if (token == 272) {
/*  187 */             this.parseState.setEatLines(true);
/*  188 */             this.contextStack.ifPop();
/*  189 */             setlastloc();
/*  190 */             return 272;
/*      */           } 
/*  192 */           this.contextStack.ifPop();
/*  193 */           this.savedToken = token;
/*  194 */           this.savedTokenPos = this.tokenBegin;
/*  195 */           this.savedLVal = this.yylval;
/*  196 */           setlastloc();
/*  197 */           return 10;
/*      */         } 
/*      */         
/*  200 */         setlastloc();
/*  201 */         return 10;
/*      */       } 
/*      */ 
/*      */       
/*      */       break;
/*      */     } 
/*      */ 
/*      */     
/*  209 */     switch (token) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 33:
/*      */       case 36:
/*      */       case 42:
/*      */       case 43:
/*      */       case 45:
/*      */       case 47:
/*      */       case 58:
/*      */       case 61:
/*      */       case 63:
/*      */       case 64:
/*      */       case 94:
/*      */       case 126:
/*      */       case 264:
/*      */       case 265:
/*      */       case 266:
/*      */       case 267:
/*      */       case 269:
/*      */       case 270:
/*      */       case 273:
/*      */       case 276:
/*      */       case 277:
/*      */       case 278:
/*      */       case 279:
/*      */       case 280:
/*      */       case 281:
/*      */       case 282:
/*      */       case 283:
/*      */       case 284:
/*      */       case 285:
/*      */       case 286:
/*      */       case 293:
/*  246 */         this.parseState.setEatLines(true);
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 271:
/*  253 */         this.contextStack.ifPush();
/*  254 */         this.parseState.setEatLines(false);
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 272:
/*  262 */         this.contextStack.ifPop();
/*  263 */         this.parseState.setEatLines(true);
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 44:
/*      */       case 59:
/*  271 */         this.contextStack.ifPop();
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 260:
/*      */       case 261:
/*      */       case 262:
/*      */       case 263:
/*      */       case 274:
/*      */       case 275:
/*  283 */         this.parseState.setEatLines(false);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 268:
/*  289 */         this.contextStack.push('[');
/*  290 */         this.contextStack.push('[');
/*      */         break;
/*      */       
/*      */       case 91:
/*  294 */         this.contextStack.push((char)token);
/*      */         break;
/*      */       
/*      */       case 123:
/*  298 */         this.contextStack.push(token);
/*  299 */         this.parseState.setEatLines(true);
/*      */         break;
/*      */       
/*      */       case 40:
/*  303 */         this.contextStack.push(token);
/*      */         break;
/*      */       
/*      */       case 93:
/*  307 */         while (this.contextStack.peek() == 'i') {
/*  308 */           this.contextStack.ifPop();
/*      */         }
/*  310 */         this.contextStack.pop();
/*      */         
/*  312 */         this.parseState.setEatLines(false);
/*      */         break;
/*      */       
/*      */       case 125:
/*  316 */         while (this.contextStack.peek() == 'i') {
/*  317 */           this.contextStack.ifPop();
/*      */         }
/*  319 */         this.contextStack.pop();
/*      */         break;
/*      */       
/*      */       case 41:
/*  323 */         while (this.contextStack.peek() == 'i') {
/*  324 */           this.contextStack.ifPop();
/*      */         }
/*  326 */         this.contextStack.pop();
/*  327 */         this.parseState.setEatLines(false);
/*      */         break;
/*      */     } 
/*      */     
/*  331 */     setlastloc();
/*  332 */     return token;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int consumeNextToken() {
/*  342 */     if (this.savedToken != 0) {
/*  343 */       int i = this.savedToken;
/*  344 */       this.yylval = this.savedLVal;
/*  345 */       this.savedLVal = (SEXP)Null.INSTANCE;
/*  346 */       this.savedToken = 0;
/*  347 */       this.tokenBegin = this.savedTokenPos;
/*  348 */       return i;
/*      */     } 
/*      */ 
/*      */     
/*  352 */     int c = skipSpace();
/*      */     
/*  354 */     if (c == 35) {
/*  355 */       c = skipComment();
/*      */     }
/*      */     
/*  358 */     this.tokenBegin = this.reader.getPosition();
/*      */     
/*  360 */     if (c == -1) {
/*  361 */       return 258;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  368 */     if (c == 46 && typeofnext() >= 2) {
/*  369 */       return consumeSymbolValue(c);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  374 */     if (c == 46) {
/*  375 */       return consumeNumericValue(c);
/*      */     }
/*      */     
/*  378 */     if (Character.isDigit(c)) {
/*  379 */       return consumeNumericValue(c);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  384 */     if (c == 34 || c == 39) {
/*  385 */       return consumeStringValue(c, false);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  390 */     if (c == 37) {
/*  391 */       return consumeSpecialValue(c);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  396 */     if (c == 96) {
/*  397 */       return consumeStringValue(c, true);
/*      */     }
/*      */     
/*  400 */     if (Character.isLetter(c)) {
/*  401 */       return consumeSymbolValue(c);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  406 */     switch (c) {
/*      */       case 60:
/*  408 */         if (isNextChar(61)) {
/*  409 */           this.yylval = (SEXP)Symbol.get("<=");
/*  410 */           return 280;
/*      */         } 
/*  412 */         if (isNextChar(45)) {
/*  413 */           this.yylval = (SEXP)Symbol.get("<-");
/*  414 */           return 265;
/*      */         } 
/*  416 */         if (isNextChar(60)) {
/*  417 */           if (isNextChar(45)) {
/*  418 */             this.yylval = (SEXP)Symbol.get("<<-");
/*  419 */             return 265;
/*      */           } 
/*  421 */           return 259;
/*      */         } 
/*      */         
/*  424 */         this.yylval = (SEXP)Symbol.get("<");
/*  425 */         return 279;
/*      */       case 45:
/*  427 */         if (isNextChar(62)) {
/*  428 */           if (isNextChar(62)) {
/*  429 */             this.yylval = (SEXP)Symbol.get("<<-");
/*  430 */             return 267;
/*      */           } 
/*  432 */           this.yylval = (SEXP)Symbol.get("<-");
/*  433 */           return 267;
/*      */         } 
/*      */         
/*  436 */         this.yylval = (SEXP)Symbol.get("-");
/*  437 */         return 45;
/*      */       case 62:
/*  439 */         if (isNextChar(61)) {
/*  440 */           this.yylval = (SEXP)Symbol.get(">=");
/*  441 */           return 278;
/*      */         } 
/*  443 */         this.yylval = (SEXP)Symbol.get(">");
/*  444 */         return 277;
/*      */       case 33:
/*  446 */         if (isNextChar(61)) {
/*  447 */           this.yylval = (SEXP)Symbol.get("!=");
/*  448 */           return 282;
/*      */         } 
/*  450 */         this.yylval = (SEXP)Symbol.get("!");
/*  451 */         return 33;
/*      */       case 61:
/*  453 */         if (isNextChar(61)) {
/*  454 */           this.yylval = (SEXP)Symbol.get("==");
/*  455 */           return 281;
/*      */         } 
/*  457 */         this.yylval = (SEXP)Symbol.get("=");
/*  458 */         return 266;
/*      */       case 58:
/*  460 */         if (isNextChar(58)) {
/*  461 */           if (isNextChar(58)) {
/*  462 */             this.yylval = (SEXP)Symbol.get(":::");
/*  463 */             return 288;
/*      */           } 
/*  465 */           this.yylval = (SEXP)Symbol.get("::");
/*  466 */           return 287;
/*      */         } 
/*      */         
/*  469 */         if (isNextChar(61)) {
/*  470 */           this.yylval = (SEXP)Symbol.get(":=");
/*  471 */           return 265;
/*      */         } 
/*  473 */         this.yylval = (SEXP)Symbol.get(":");
/*  474 */         return 58;
/*      */       case 38:
/*  476 */         if (isNextChar(38)) {
/*  477 */           this.yylval = (SEXP)Symbol.get("&&");
/*  478 */           return 285;
/*      */         } 
/*  480 */         this.yylval = (SEXP)Symbol.get("&");
/*  481 */         return 283;
/*      */       case 124:
/*  483 */         if (isNextChar(124)) {
/*  484 */           this.yylval = (SEXP)Symbol.get("||");
/*  485 */           return 286;
/*      */         } 
/*  487 */         this.yylval = (SEXP)Symbol.get("|");
/*  488 */         return 284;
/*      */       case 123:
/*  490 */         this.yylval = (SEXP)Symbol.get("{");
/*  491 */         return c;
/*      */       case 125:
/*  493 */         return c;
/*      */       case 40:
/*  495 */         this.yylval = (SEXP)Symbol.get("(");
/*  496 */         return c;
/*      */       case 41:
/*  498 */         return c;
/*      */       case 91:
/*  500 */         if (isNextChar(91)) {
/*  501 */           this.yylval = (SEXP)Symbol.get("[[");
/*  502 */           return 268;
/*      */         } 
/*  504 */         this.yylval = (SEXP)Symbol.get("[");
/*  505 */         return c;
/*      */       case 93:
/*  507 */         return c;
/*      */       case 63:
/*  509 */         this.yylval = (SEXP)Symbol.get("?");
/*  510 */         return c;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 42:
/*  517 */         if (isNextChar(42)) {
/*  518 */           c = 94;
/*      */         }
/*  520 */         this.yylval = (SEXP)Symbol.get(codePointToString(c));
/*  521 */         return c;
/*      */       case 36:
/*      */       case 43:
/*      */       case 47:
/*      */       case 64:
/*      */       case 94:
/*      */       case 126:
/*  528 */         this.yylval = (SEXP)Symbol.get(codePointToString(c));
/*  529 */         return c;
/*      */     } 
/*  531 */     return c;
/*      */   }
/*      */ 
/*      */   
/*      */   private String codePointToString(int c) {
/*  536 */     return new String(new int[] { c }, 0, 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int typeofnext() {
/*  546 */     int k, c = xxgetc();
/*  547 */     if (Character.isDigit(c)) {
/*  548 */       k = 1;
/*      */     } else {
/*  550 */       k = 2;
/*      */     } 
/*  552 */     xxungetc(c);
/*  553 */     return k;
/*      */   }
/*      */   
/*      */   private boolean isNextChar(int expect) {
/*  557 */     int c = xxgetc();
/*  558 */     if (c == expect) {
/*  559 */       return true;
/*      */     }
/*  561 */     xxungetc(c);
/*  562 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public void yyerror(RParser.Location loc, String s) {
/*  567 */     this.errorLocation = loc;
/*  568 */     this.errorMessage = s;
/*      */   }
/*      */   
/*      */   public boolean errorEncountered() {
/*  572 */     return (this.errorLocation != null);
/*      */   }
/*      */   
/*      */   public RParser.Location getErrorLocation() {
/*  576 */     return this.errorLocation;
/*      */   }
/*      */   
/*      */   public String getErrorMessage() {
/*  580 */     return this.errorMessage;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void setlastloc() {
/*  594 */     this.tokenEnd = this.reader.getPosition();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int skipComment() {
/*  605 */     int c = 35;
/*  606 */     boolean maybeLine = (this.reader.getColumnNumber() == 1);
/*  607 */     if (maybeLine) {
/*  608 */       String lineDirective = "#line";
/*  609 */       for (int i = 1; i < 5; i++) {
/*  610 */         c = xxgetc();
/*  611 */         if (c != lineDirective.charAt(i)) {
/*  612 */           maybeLine = false;
/*      */           break;
/*      */         } 
/*      */       } 
/*  616 */       if (maybeLine) {
/*  617 */         c = processLineDirective();
/*      */       }
/*      */     } 
/*  620 */     while (c != 10 && c != -1) {
/*  621 */       c = xxgetc();
/*      */     }
/*  623 */     return c;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private int xxgetc() {
/*      */     int c;
/*      */     try {
/*  631 */       c = this.reader.read();
/*  632 */       if (c == 13) {
/*  633 */         c = this.reader.read();
/*  634 */         if (c != 10) {
/*  635 */           this.reader.unread(c);
/*  636 */           c = 10;
/*      */         } 
/*      */       } 
/*  639 */     } catch (IOException e) {
/*  640 */       throw new RLexException(e);
/*      */     } 
/*      */     
/*  643 */     if (c == -1) {
/*  644 */       return -1;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  649 */     R_ParseContextLine = this.reader.getLineNumber();
/*      */     
/*  651 */     if (this.parseOptions.isKeepSource() && this.parseOptions.isGenerateCode()) {
/*  652 */       this.parseState.getFunctionSource().maybeAppendSourceCodePoint(c);
/*      */     }
/*      */     
/*  655 */     return c;
/*      */   }
/*      */ 
/*      */   
/*      */   private int processLineDirective() {
/*  660 */     int linenumber, c = skipSpace();
/*  661 */     if (!Character.isDigit(c)) {
/*  662 */       return c;
/*      */     }
/*  664 */     int tok = consumeNumericValue(c);
/*  665 */     if (this.parseOptions.isGenerateCode()) {
/*      */       
/*  667 */       linenumber = (int)this.yylval.asReal();
/*      */     } else {
/*      */       
/*  670 */       linenumber = 0;
/*      */     } 
/*  672 */     c = skipSpace();
/*  673 */     if (c == 34) {
/*  674 */       tok = consumeStringValue(c, false);
/*      */     }
/*  676 */     if (tok == 260) {
/*  677 */       setParseFilename(this.yylval);
/*      */     }
/*      */     do {
/*  680 */       c = xxgetc();
/*  681 */     } while (c != 10 && c != -1);
/*  682 */     this.reader.setLineNumber(linenumber);
/*      */     
/*  684 */     return c;
/*      */   }
/*      */   
/*      */   private int xxungetc(int c) {
/*  688 */     return this.reader.unread(c);
/*      */   }
/*      */   
/*      */   private void setParseFilename(SEXP newname) {
/*  692 */     if (CDefines.isEnvironment(this.parseState.srcFile)) {
/*  693 */       Environment env = (Environment)this.parseState.srcFile;
/*  694 */       SEXP oldname = env.findVariableUnsafe(Symbol.get("filename"));
/*  695 */       if (CDefines.isString(oldname) && oldname.length() > 0 && oldname
/*  696 */         .asString().equals(newname.asString())) {
/*      */         return;
/*      */       }
/*  699 */       CDefines.REPROTECT(this.parseState
/*      */           
/*  701 */           .srcFile = (SEXP)new Environment(AttributeMap.newBuilder().set(CDefines.R_ClassSymbol, (SEXP)CDefines.mkString("srcfile")).build()), this.parseState.srcFileProt);
/*      */ 
/*      */       
/*  704 */       env.setVariableUnsafe(Symbol.get("filename"), newname);
/*  705 */       env.setVariableUnsafe(Symbol.get("original"), oldname);
/*      */     } else {
/*  707 */       CDefines.REPROTECT(this.parseState.srcFile = newname, this.parseState.srcFileProt);
/*      */     } 
/*  709 */     CDefines.UNPROTECT_PTR(newname);
/*      */   }
/*      */   
/*      */   private int consumeNumericValue(int c) {
/*  713 */     StringBuilder buffer = new StringBuilder();
/*  714 */     buffer.appendCodePoint(c);
/*      */     
/*  716 */     int seendot = (c == 46) ? 1 : 0;
/*  717 */     boolean seenexp = false;
/*  718 */     int last = c;
/*  719 */     int nd = 0;
/*  720 */     int asNumeric = 0;
/*      */ 
/*      */     
/*  723 */     while (Character.isDigit(c = xxgetc()) || c == 46 || c == 101 || c == 69 || c == 120 || c == 88 || c == 76) {
/*      */       
/*  725 */       if (c == 76) {
/*      */         break;
/*      */       }
/*      */       
/*  729 */       if (c == 120 || c == 88) {
/*  730 */         if (last != 48) {
/*      */           break;
/*      */         }
/*  733 */         buffer.appendCodePoint(c);
/*  734 */         while (Character.isDigit(c = xxgetc()) || (97 <= c && c <= 102) || (65 <= c && c <= 70) || c == 46) {
/*      */           
/*  736 */           buffer.appendCodePoint(c);
/*  737 */           nd++;
/*      */         } 
/*  739 */         if (nd == 0) {
/*  740 */           return 259;
/*      */         }
/*  742 */         if (c == 112 || c == 80) {
/*  743 */           buffer.appendCodePoint(c);
/*  744 */           c = xxgetc();
/*  745 */           if (!Character.isDigit(c) && c != 43 && c != 45) {
/*  746 */             return 259;
/*      */           }
/*  748 */           if (c == 43 || c == 45) {
/*  749 */             buffer.appendCodePoint(c);
/*  750 */             c = xxgetc();
/*      */           } 
/*  752 */           for (nd = 0; Character.isDigit(c); c = xxgetc(), nd++) {
/*  753 */             buffer.appendCodePoint(c);
/*      */           }
/*  755 */           if (nd == 0) {
/*  756 */             return 259;
/*      */           }
/*      */         } 
/*      */         break;
/*      */       } 
/*  761 */       if (c == 69 || c == 101) {
/*  762 */         if (seenexp) {
/*      */           break;
/*      */         }
/*  765 */         seenexp = true;
/*  766 */         seendot = (seendot == 1) ? seendot : 2;
/*  767 */         buffer.appendCodePoint(c);
/*  768 */         c = xxgetc();
/*  769 */         if (!Character.isDigit(c) && c != 43 && c != 45) {
/*  770 */           return 259;
/*      */         }
/*  772 */         if (c == 43 || c == 45) {
/*  773 */           buffer.appendCodePoint(c);
/*  774 */           c = xxgetc();
/*  775 */           if (!Character.isDigit(c)) {
/*  776 */             return 259;
/*      */           }
/*      */         } 
/*      */       } 
/*  780 */       if (c == 46) {
/*  781 */         if (seendot != 0) {
/*      */           break;
/*      */         }
/*  784 */         seendot = 1;
/*      */       } 
/*  786 */       buffer.appendCodePoint(c);
/*  787 */       last = c;
/*      */     } 
/*      */ 
/*      */     
/*  791 */     if (c == 76) {
/*  792 */       double a = NumericLiterals.parseDouble(buffer.toString());
/*  793 */       int b = (int)a;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  798 */       if (a != b) {
/*  799 */         if (this.parseOptions.isGenerateCode()) {
/*  800 */           if (seendot == 1 && !seenexp) {
/*  801 */             logger.warning(String.format("integer literal %sL contains decimal; using numeric value", new Object[] { buffer.toString() }));
/*      */           } else {
/*  803 */             logger.warning(String.format("non-integer value %s qualified with L; using numeric value", new Object[] { buffer }));
/*      */           } 
/*      */         }
/*  806 */         asNumeric = 1;
/*  807 */         seenexp = true;
/*      */       } 
/*      */     } 
/*      */     
/*  811 */     if (c == 105) {
/*  812 */       this.yylval = this.parseOptions.isGenerateCode() ? mkComplex(buffer.toString()) : (SEXP)Null.INSTANCE;
/*      */     }
/*  814 */     else if (c == 76 && asNumeric == 0) {
/*  815 */       if (this.parseOptions.isGenerateCode() && seendot == 1 && !seenexp) {
/*  816 */         logger.warning(String.format("integer literal %sL contains unnecessary decimal point", new Object[] { buffer.toString() }));
/*      */       }
/*  818 */       double a = NumericLiterals.parseDouble(buffer);
/*  819 */       int b = (int)a;
/*  820 */       this.yylval = this.parseOptions.isGenerateCode() ? (SEXP)new IntArrayVector(new int[] { b }) : (SEXP)Null.INSTANCE;
/*      */     } else {
/*      */       
/*  823 */       if (c != 76) {
/*  824 */         xxungetc(c);
/*      */       }
/*  826 */       this
/*  827 */         .yylval = this.parseOptions.isGenerateCode() ? (SEXP)new DoubleArrayVector(new double[] { NumericLiterals.parseDouble(buffer) }) : (SEXP)Null.INSTANCE;
/*      */     } 
/*      */     
/*  830 */     return 261;
/*      */   }
/*      */ 
/*      */   
/*      */   private int skipSpace() {
/*      */     while (true) {
/*  836 */       int c = xxgetc();
/*  837 */       if (c != 32 && c != 9 && c != 12 && c != 160)
/*  838 */         return c; 
/*      */     } 
/*      */   } private SEXP mkComplex(String s) {
/*      */     ComplexArrayVector complexArrayVector;
/*  842 */     Null null = Null.INSTANCE;
/*  843 */     double f = NumericLiterals.parseDouble(s);
/*      */     
/*  845 */     if (this.parseOptions.isGenerateCode()) {
/*  846 */       complexArrayVector = new ComplexArrayVector(new Complex[] { new Complex(0.0D, f) });
/*      */     }
/*      */     
/*  849 */     return (SEXP)complexArrayVector;
/*      */   }
/*      */   
/*      */   private static class CTEXT
/*      */   {
/*  854 */     private StringBuffer buffer = new StringBuffer();
/*      */     
/*      */     public void push(int c) {
/*  857 */       this.buffer.appendCodePoint(c);
/*      */     }
/*      */     
/*      */     public void pop() {
/*  861 */       this.buffer.setLength(this.buffer.length() - 1);
/*      */     }
/*      */     
/*      */     public String toString() {
/*  865 */       return this.buffer.toString();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private CTEXT() {}
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private int consumeStringValue(int c, boolean forSymbol) {
/*  876 */     int quote = c;
/*  877 */     int have_warned = 0;
/*  878 */     CTEXT ctext = new CTEXT();
/*  879 */     StringBuffer stext = new StringBuffer();
/*      */     
/*  881 */     while ((c = xxgetc()) != -1 && c != quote) {
/*  882 */       ctext.push(c);
/*  883 */       if (c == 10) {
/*  884 */         xxungetc(c);
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  889 */         c = 92;
/*      */       } 
/*  891 */       if (c == 92) {
/*  892 */         c = xxgetc();
/*  893 */         ctext.push(c);
/*  894 */         if (48 <= c && c <= 56)
/*  895 */         { int octal = c - 48;
/*  896 */           if (48 <= (c = xxgetc()) && c <= 56) {
/*  897 */             ctext.push(c);
/*  898 */             octal = 8 * octal + c - 48;
/*  899 */             if (48 <= (c = xxgetc()) && c <= 56) {
/*  900 */               ctext.push(c);
/*  901 */               octal = 8 * octal + c - 48;
/*      */             } else {
/*  903 */               xxungetc(c);
/*  904 */               ctext.pop();
/*      */             } 
/*      */           } else {
/*  907 */             xxungetc(c);
/*  908 */             ctext.pop();
/*      */           } 
/*  910 */           c = octal; }
/*  911 */         else if (c == 120)
/*  912 */         { int val = 0;
/*      */ 
/*      */           
/*  915 */           for (int i = 0; i < 2; i++) {
/*  916 */             int ext; c = xxgetc();
/*  917 */             ctext.push(c);
/*  918 */             if (c >= 48 && c <= 57) {
/*  919 */               ext = c - 48;
/*  920 */             } else if (c >= 65 && c <= 70) {
/*  921 */               ext = c - 65 + 10;
/*  922 */             } else if (c >= 97 && c <= 102) {
/*  923 */               ext = c - 97 + 10;
/*      */             } else {
/*  925 */               xxungetc(c);
/*  926 */               ctext.pop();
/*  927 */               if (i == 0) {
/*  928 */                 if (this.parseOptions.isGenerateCode() && this.parseOptions.isWarnEscapes()) {
/*  929 */                   have_warned++;
/*  930 */                   logger.warning("'\\x' used without hex digits");
/*      */                 } 
/*  932 */                 val = 120;
/*      */               } 
/*      */               break;
/*      */             } 
/*  936 */             val = 16 * val + ext;
/*      */           } 
/*  938 */           c = val; }
/*  939 */         else { if (c == 117) {
/*  940 */             int val = 0;
/*      */ 
/*      */             
/*  943 */             boolean delim = false;
/*      */             
/*  945 */             if (forSymbol) {
/*  946 */               throw new RLexException(String.format("\\uxxxx sequences not supported inside backticks (line %d)", new Object[] { Integer.valueOf(this.reader.getColumnNumber()) }));
/*      */             }
/*  948 */             if ((c = xxgetc()) == 123) {
/*  949 */               delim = true;
/*  950 */               ctext.push(c);
/*      */             } else {
/*  952 */               xxungetc(c);
/*      */             } 
/*  954 */             for (int i = 0; i < 4; i++) {
/*  955 */               int ext; c = xxgetc();
/*  956 */               ctext.push(c);
/*  957 */               if (c >= 48 && c <= 57) {
/*  958 */                 ext = c - 48;
/*  959 */               } else if (c >= 65 && c <= 70) {
/*  960 */                 ext = c - 65 + 10;
/*  961 */               } else if (c >= 97 && c <= 102) {
/*  962 */                 ext = c - 97 + 10;
/*      */               } else {
/*  964 */                 xxungetc(c);
/*  965 */                 ctext.pop();
/*  966 */                 if (i == 0) {
/*  967 */                   if (this.parseOptions.isGenerateCode() && this.parseOptions.isWarnEscapes()) {
/*  968 */                     have_warned++;
/*  969 */                     logger.warning("\\u used without hex digits");
/*      */                   } 
/*  971 */                   val = 117;
/*      */                 } 
/*      */                 break;
/*      */               } 
/*  975 */               val = 16 * val + ext;
/*      */             } 
/*  977 */             if (delim) {
/*  978 */               if ((c = xxgetc()) != 125)
/*  979 */                 throw new RLexException(String.format("invalid \\u{xxxx} sequence (line %d)", new Object[] {
/*  980 */                         Integer.valueOf(this.reader.getLineNumber())
/*      */                       })); 
/*  982 */               ctext.push(c);
/*      */             } 
/*      */             
/*  985 */             stext.appendCodePoint(val);
/*      */             
/*      */             continue;
/*      */           } 
/*  989 */           if (c == 85) {
/*  990 */             int val = 0;
/*      */ 
/*      */             
/*  993 */             boolean delim = false;
/*  994 */             if (forSymbol) {
/*  995 */               throw new RLexException(String.format("\\Uxxxxxxxx sequences not supported inside backticks (line %d)", new Object[] { Integer.valueOf(this.reader.getLineNumber()) }));
/*      */             }
/*  997 */             if ((c = xxgetc()) == 123) {
/*  998 */               delim = true;
/*  999 */               ctext.push(c);
/*      */             } else {
/* 1001 */               xxungetc(c);
/*      */             } 
/* 1003 */             for (int i = 0; i < 8; i++) {
/* 1004 */               int ext; c = xxgetc();
/* 1005 */               ctext.push(c);
/* 1006 */               if (c >= 48 && c <= 57) {
/* 1007 */                 ext = c - 48;
/* 1008 */               } else if (c >= 65 && c <= 70) {
/* 1009 */                 ext = c - 65 + 10;
/* 1010 */               } else if (c >= 97 && c <= 102) {
/* 1011 */                 ext = c - 97 + 10;
/*      */               } else {
/* 1013 */                 xxungetc(c);
/* 1014 */                 ctext.pop();
/* 1015 */                 if (i == 0) {
/* 1016 */                   if (this.parseOptions.isGenerateCode() && this.parseOptions.isWarnEscapes()) {
/* 1017 */                     have_warned++;
/* 1018 */                     logger.warning("\\U used without hex digits");
/*      */                   } 
/* 1020 */                   val = 85;
/*      */                 } 
/*      */                 break;
/*      */               } 
/* 1024 */               val = 16 * val + ext;
/*      */             } 
/* 1026 */             if (delim) {
/* 1027 */               if ((c = xxgetc()) != 125) {
/* 1028 */                 logger.severe(String.format("invalid \\U{xxxxxxxx} sequence (line %d)", new Object[] { Integer.valueOf(this.reader.getLineNumber()) }));
/*      */               } else {
/* 1030 */                 ctext.push(c);
/*      */               } 
/*      */             }
/* 1033 */             ctext.push(val);
/*      */             continue;
/*      */           } 
/* 1036 */           switch (c) {
/*      */             case 97:
/* 1038 */               c = 7;
/*      */               break;
/*      */             case 98:
/* 1041 */               c = 8;
/*      */               break;
/*      */             case 102:
/* 1044 */               c = 12;
/*      */               break;
/*      */             case 110:
/* 1047 */               c = 10;
/*      */               break;
/*      */             case 114:
/* 1050 */               c = 13;
/*      */               break;
/*      */             case 116:
/* 1053 */               c = 9;
/*      */               break;
/*      */             case 118:
/* 1056 */               c = 11;
/*      */               break;
/*      */             case 92:
/* 1059 */               c = 92;
/*      */               break;
/*      */             case 10:
/*      */             case 32:
/*      */             case 34:
/*      */             case 39:
/*      */               break;
/*      */             default:
/* 1067 */               if (this.parseOptions.isGenerateCode() && this.parseOptions.isWarnEscapes()) {
/* 1068 */                 have_warned++;
/* 1069 */                 logger.warning(String.format("'\\%c' is an unrecognized escape in a character string", new Object[] { Character.valueOf((char)c) }));
/*      */               } 
/*      */               break;
/*      */           }  }
/*      */       
/*      */       } 
/* 1075 */       stext.appendCodePoint(c);
/*      */     } 
/*      */     
/* 1078 */     if (forSymbol) {
/* 1079 */       this.yylval = (SEXP)Symbol.get(stext.toString());
/* 1080 */       return 263;
/*      */     } 
/* 1082 */     this.yylval = (SEXP)StringVector.valueOf(stext.toString());
/*      */     
/* 1084 */     if (have_warned != 0) {
/* 1085 */       logger.warning(String.format("unrecognized escape(s) removed from \"%s\"", new Object[] { ctext }));
/*      */     }
/* 1087 */     return 260;
/*      */   }
/*      */   
/*      */   private int consumeSpecialValue(int c) {
/* 1091 */     StringBuffer buffer = new StringBuffer();
/* 1092 */     buffer.appendCodePoint(c);
/* 1093 */     while ((c = xxgetc()) != -1 && c != 37) {
/* 1094 */       if (c == 10) {
/* 1095 */         xxungetc(c);
/* 1096 */         return 259;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1103 */       buffer.appendCodePoint(c);
/*      */     } 
/* 1105 */     if (c == 37) {
/* 1106 */       buffer.appendCodePoint(c);
/*      */     }
/* 1108 */     this.yylval = (SEXP)Symbol.get(buffer.toString());
/* 1109 */     return 293;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private int consumeSymbolValue(int c) {
/* 1115 */     StringBuffer buffer = new StringBuffer();
/*      */     
/*      */     do {
/* 1118 */       buffer.appendCodePoint(c);
/* 1119 */     } while ((c = xxgetc()) != -1 && (
/* 1120 */       Character.isLetterOrDigit(c) || c == 46 || c == 95));
/*      */     
/* 1122 */     xxungetc(c);
/*      */     
/*      */     int keyword;
/* 1125 */     if ((keyword = lookupKeyword(buffer.toString())) != 0) {
/* 1126 */       if (keyword == 264) {
/* 1127 */         this.parseState.getFunctionSource().descend();
/*      */       }
/* 1129 */       return keyword;
/*      */     } 
/* 1131 */     this.yylval = (SEXP)Symbol.get(buffer.toString());
/* 1132 */     return 263;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int lookupKeyword(String s) {
/* 1140 */     for (int i = 0; i != this.keywords.length; i++) {
/* 1141 */       if ((this.keywords[i]).name.equals(s)) {
/* 1142 */         switch ((this.keywords[i]).token) {
/*      */           case 262:
/* 1144 */             this.yylval = (SEXP)Null.INSTANCE;
/*      */             break;
/*      */           case 261:
/* 1147 */             if (this.parseOptions.isGenerateCode()) {
/* 1148 */               switch (i) {
/*      */                 case 1:
/* 1150 */                   this.yylval = (SEXP)new LogicalArrayVector(new Logical[] { Logical.NA });
/*      */                   break;
/*      */                 case 2:
/* 1153 */                   this.yylval = (SEXP)new LogicalArrayVector(new boolean[] { true });
/*      */                   break;
/*      */                 case 3:
/* 1156 */                   this.yylval = (SEXP)new LogicalArrayVector(new boolean[] { false });
/*      */                   break;
/*      */                 case 4:
/* 1159 */                   this.yylval = (SEXP)new DoubleArrayVector(new double[] { Double.POSITIVE_INFINITY });
/*      */                   break;
/*      */                 case 5:
/* 1162 */                   this.yylval = (SEXP)new DoubleArrayVector(new double[] { Double.NaN });
/*      */                   break;
/*      */                 case 6:
/* 1165 */                   this.yylval = (SEXP)new IntArrayVector(new int[] { Integer.MIN_VALUE });
/*      */                   break;
/*      */                 case 7:
/* 1168 */                   this.yylval = (SEXP)new DoubleArrayVector(new double[] { DoubleVector.NA });
/*      */                   break;
/*      */                 case 8:
/* 1171 */                   this.yylval = (SEXP)StringVector.valueOf(StringVector.NA);
/*      */                   break;
/*      */                 case 9:
/* 1174 */                   this.yylval = (SEXP)new ComplexArrayVector(new Complex[] { new Complex(DoubleVector.NA, DoubleVector.NA) }); break;
/*      */               } 
/*      */               break;
/*      */             } 
/* 1178 */             this.yylval = (SEXP)Null.INSTANCE;
/*      */             break;
/*      */           
/*      */           case 264:
/*      */           case 269:
/*      */           case 271:
/*      */           case 273:
/*      */           case 274:
/*      */           case 275:
/*      */           case 276:
/* 1188 */             this.yylval = (SEXP)Symbol.get(s);
/*      */             break;
/*      */ 
/*      */ 
/*      */           
/*      */           case 263:
/* 1194 */             this.yylval = (SEXP)Symbol.get(s);
/*      */             break;
/*      */         } 
/* 1197 */         return (this.keywords[i]).token;
/*      */       } 
/*      */     } 
/* 1200 */     return 0;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isEof() {
/* 1205 */     int c = xxgetc();
/* 1206 */     xxungetc(c);
/* 1207 */     return (c == -1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getCharacterPos() {
/* 1215 */     return this.reader.getCharacterIndex();
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/parser/RLexer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */