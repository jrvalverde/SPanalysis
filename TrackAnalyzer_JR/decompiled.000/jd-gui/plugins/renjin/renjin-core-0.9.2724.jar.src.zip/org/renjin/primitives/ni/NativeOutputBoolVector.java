/*    */ package org.renjin.primitives.ni;
/*    */ 
/*    */ import org.renjin.sexp.AttributeMap;
/*    */ import org.renjin.sexp.LogicalVector;
/*    */ import org.renjin.sexp.SEXP;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NativeOutputBoolVector
/*    */   extends LogicalVector
/*    */   implements NativeOutputVector
/*    */ {
/*    */   private final DeferredNativeCall call;
/*    */   private final int outputIndex;
/*    */   private final int length;
/*    */   private boolean[] array;
/*    */   
/*    */   public NativeOutputBoolVector(DeferredNativeCall call, int outputIndex, int length, AttributeMap attributes) {
/* 35 */     super(attributes);
/* 36 */     this.call = call;
/* 37 */     this.outputIndex = outputIndex;
/* 38 */     this.length = length;
/*    */   }
/*    */ 
/*    */   
/*    */   protected SEXP cloneWithNewAttributes(AttributeMap attributes) {
/* 43 */     return (SEXP)new NativeOutputBoolVector(this.call, this.outputIndex, this.length, attributes);
/*    */   }
/*    */ 
/*    */   
/*    */   public int length() {
/* 48 */     return this.length;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getElementAsRawLogical(int index) {
/* 53 */     if (this.array == null) {
/* 54 */       this.array = (boolean[])this.call.output(this.outputIndex);
/*    */     }
/* 56 */     return this.array[index] ? 1 : 0;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isConstantAccessTime() {
/* 61 */     return this.call.isEvaluated();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isDeferred() {
/* 66 */     return !this.call.isEvaluated();
/*    */   }
/*    */ 
/*    */   
/*    */   public DeferredNativeCall getCall() {
/* 71 */     return this.call;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getOutputIndex() {
/* 76 */     return this.outputIndex;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/ni/NativeOutputBoolVector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */