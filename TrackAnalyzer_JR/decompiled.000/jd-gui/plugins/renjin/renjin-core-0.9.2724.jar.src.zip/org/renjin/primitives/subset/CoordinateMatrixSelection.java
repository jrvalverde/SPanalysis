/*     */ package org.renjin.primitives.subset;
/*     */ 
/*     */ import org.renjin.eval.Context;
/*     */ import org.renjin.eval.EvalException;
/*     */ import org.renjin.sexp.AtomicVector;
/*     */ import org.renjin.sexp.IntVector;
/*     */ import org.renjin.sexp.ListVector;
/*     */ import org.renjin.sexp.PairList;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.Symbols;
/*     */ import org.renjin.sexp.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class CoordinateMatrixSelection
/*     */   implements SelectionStrategy
/*     */ {
/*     */   private final int numCoordinates;
/*     */   private AtomicVector matrix;
/*     */   private int[] matrixDims;
/*     */   
/*     */   public static boolean isCoordinateMatrix(SEXP source, SEXP subscript) {
/*  61 */     if (!(subscript instanceof IntVector) && !(subscript instanceof org.renjin.sexp.DoubleVector))
/*     */     {
/*  63 */       return false;
/*     */     }
/*     */     
/*  66 */     Vector subscriptDim = subscript.getAttributes().getDim();
/*  67 */     if (subscriptDim.length() != 2) {
/*  68 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  74 */     SEXP sourceDim = source.getAttribute(Symbols.DIM);
/*  75 */     return (sourceDim.length() == subscriptDim.getElementAsInt(1));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CoordinateMatrixSelection(AtomicVector matrix) {
/*  83 */     this.matrix = matrix;
/*  84 */     this.matrixDims = matrix.getAttributes().getDimArray();
/*     */     
/*  86 */     this.numCoordinates = this.matrixDims[0];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public SEXP getVectorSubset(Context context, Vector source, boolean drop) {
/*  92 */     CoordinateMatrixIterator it = new CoordinateMatrixIterator(source, this.matrix);
/*     */     
/*  94 */     Vector.Builder result = source.getVectorType().newBuilderWithInitialCapacity(this.numCoordinates);
/*     */ 
/*     */     
/*  97 */     int sourceLength = source.length();
/*     */     
/*  99 */     Vector vector = context.materialize(source);
/*     */     int index;
/* 101 */     while ((index = it.next()) != -1) {
/*     */       
/* 103 */       if (IntVector.isNA(index)) {
/* 104 */         result.addNA();
/*     */         continue;
/*     */       } 
/* 107 */       if (index >= sourceLength) {
/* 108 */         throw new EvalException("subscript out of bounds", new Object[0]);
/*     */       }
/*     */       
/* 111 */       result.addFrom((SEXP)vector, index);
/*     */     } 
/*     */ 
/*     */     
/* 115 */     return (SEXP)result.build();
/*     */   }
/*     */ 
/*     */   
/*     */   public ListVector replaceListElements(Context context, ListVector source, Vector replacement) {
/* 120 */     return (ListVector)replaceElements((Vector)source, replacement);
/*     */   }
/*     */ 
/*     */   
/*     */   public Vector replaceAtomicVectorElements(Context context, AtomicVector source, Vector replacements) {
/* 125 */     return replaceElements((Vector)source, replacements);
/*     */   }
/*     */   
/*     */   private Vector replaceElements(Vector source, Vector replacements) {
/* 129 */     CoordinateMatrixIterator it = new CoordinateMatrixIterator(source, this.matrix);
/*     */     
/* 131 */     Vector.Builder result = source.newCopyBuilder(replacements.getVectorType());
/*     */     
/* 133 */     int replacementIndex = 0;
/*     */     
/*     */     int index;
/* 136 */     while ((index = it.next()) != -1) {
/*     */       
/* 138 */       if (IntVector.isNA(index)) {
/* 139 */         throw new EvalException("NAs are not allowed in subscripted assignments", new Object[0]);
/*     */       }
/* 141 */       if (index >= source.length()) {
/* 142 */         throw new EvalException("subscript out of bounds", new Object[0]);
/*     */       }
/*     */       
/* 145 */       if (replacements.length() == 0) {
/* 146 */         throw new EvalException("replacement has zero length", new Object[0]);
/*     */       }
/* 148 */       result.setFrom(index, (SEXP)replacements, replacementIndex++);
/* 149 */       if (replacementIndex >= replacements.length()) {
/* 150 */         replacementIndex = 0;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 155 */     if (replacementIndex != 0) {
/* 156 */       throw new EvalException("number of items to replace is not a multiple of replacement length", new Object[0]);
/*     */     }
/*     */     
/* 159 */     return result.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SEXP getSingleListElement(ListVector source, boolean exact) {
/* 170 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public AtomicVector getSingleAtomicVectorElement(AtomicVector source, boolean exact) {
/* 175 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public ListVector replaceSingleListElement(ListVector list, SEXP replacement) {
/* 180 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public SEXP replaceSinglePairListElement(PairList.Node list, SEXP replacement) {
/* 185 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public Vector replaceSingleElement(Context context, AtomicVector source, Vector replacement) {
/* 190 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/subset/CoordinateMatrixSelection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */