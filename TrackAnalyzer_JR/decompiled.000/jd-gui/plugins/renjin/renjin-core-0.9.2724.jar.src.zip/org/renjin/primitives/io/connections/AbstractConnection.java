/*     */ package org.renjin.primitives.io.connections;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.PrintWriter;
/*     */ import java.nio.charset.Charset;
/*     */ import org.renjin.repackaged.guava.base.Charsets;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractConnection
/*     */   implements Connection
/*     */ {
/*     */   private PushbackBufferedReader reader;
/*     */   private PrintWriter writer;
/*     */   private Charset charset;
/*     */   
/*     */   protected AbstractConnection(Charset charset) {
/*  36 */     this.charset = charset;
/*     */   }
/*     */   
/*     */   public AbstractConnection() {
/*  40 */     this(Charsets.UTF_8);
/*     */   }
/*     */ 
/*     */   
/*     */   public final PushbackBufferedReader getReader() throws IOException {
/*  45 */     if (this.reader == null) {
/*  46 */       this
/*     */         
/*  48 */         .reader = new PushbackBufferedReader(new InputStreamReader(getInputStream(), this.charset));
/*     */     }
/*  50 */     return this.reader;
/*     */   }
/*     */ 
/*     */   
/*     */   public final PrintWriter getPrintWriter() throws IOException {
/*  55 */     if (this.writer == null) {
/*  56 */       this.writer = new PrintWriter(new OutputStreamWriter(getOutputStream(), this.charset));
/*     */     }
/*  58 */     return this.writer;
/*     */   }
/*     */ 
/*     */   
/*     */   public PrintWriter getOpenPrintWriter() {
/*  63 */     if (this.writer == null) {
/*  64 */       throw new IllegalStateException();
/*     */     }
/*  66 */     return this.writer;
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/*  71 */     if (this.reader != null) {
/*  72 */       this.reader.close();
/*     */     } else {
/*  74 */       closeInputIfOpen();
/*     */     } 
/*  76 */     if (this.writer != null) {
/*  77 */       this.writer.close();
/*     */     } else {
/*  79 */       closeOutputIfOpen();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void flush() throws IOException {
/*  85 */     if (this.writer != null) {
/*  86 */       this.writer.flush();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public String getMode() {
/*  92 */     return "r";
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canRead() {
/*  97 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canWrite() {
/* 102 */     return true;
/*     */   }
/*     */   
/*     */   protected abstract void closeInputIfOpen() throws IOException;
/*     */   
/*     */   protected abstract void closeOutputIfOpen() throws IOException;
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/io/connections/AbstractConnection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */