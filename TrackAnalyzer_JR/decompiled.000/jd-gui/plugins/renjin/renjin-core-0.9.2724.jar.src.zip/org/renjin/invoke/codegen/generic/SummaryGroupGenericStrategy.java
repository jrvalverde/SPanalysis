/*    */ package org.renjin.invoke.codegen.generic;
/*    */ 
/*    */ import com.sun.codemodel.JBlock;
/*    */ import com.sun.codemodel.JCodeModel;
/*    */ import com.sun.codemodel.JExpr;
/*    */ import com.sun.codemodel.JExpression;
/*    */ import com.sun.codemodel.JType;
/*    */ import com.sun.codemodel.JVar;
/*    */ import org.renjin.invoke.codegen.ApplyMethodContext;
/*    */ import org.renjin.invoke.codegen.VarArgParser;
/*    */ import org.renjin.primitives.S3;
/*    */ import org.renjin.sexp.SEXP;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SummaryGroupGenericStrategy
/*    */   extends GenericDispatchStrategy
/*    */ {
/*    */   private final String name;
/*    */   
/*    */   public SummaryGroupGenericStrategy(JCodeModel codeModel, String name) {
/* 34 */     super(codeModel);
/* 35 */     this.name = name;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void beforePrimitiveCalled(JBlock parent, VarArgParser args, ApplyMethodContext context, JExpression call) {
/* 42 */     JBlock isObject = parent._if(args.getVarArgBuilder().invoke("length").gt(JExpr.lit(0)).cand((JExpression)fastIsObject((JExpression)args.getVarArgList().invoke("getElementAsSEXP").arg(JExpr.lit(0)))))._then();
/* 43 */     JVar genericResult = isObject.decl((JType)this.codeModel.ref(SEXP.class), "genericResult", (JExpression)this.codeModel
/* 44 */         .ref(S3.class)
/* 45 */         .staticInvoke("tryDispatchSummaryFromPrimitive")
/* 46 */         .arg(context.getContext())
/* 47 */         .arg(context.getEnvironment())
/* 48 */         .arg(call)
/* 49 */         .arg(JExpr.lit(this.name))
/* 50 */         .arg(args.getVarArgList())
/* 51 */         .arg(args.getNamedFlagJExp("na.rm")));
/* 52 */     isObject._if(genericResult.ne(JExpr._null()))
/* 53 */       ._then()
/* 54 */       ._return((JExpression)genericResult);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/codegen/generic/SummaryGroupGenericStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */