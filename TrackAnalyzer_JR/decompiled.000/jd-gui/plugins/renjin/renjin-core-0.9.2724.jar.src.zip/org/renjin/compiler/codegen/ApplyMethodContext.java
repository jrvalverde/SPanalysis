/*    */ package org.renjin.compiler.codegen;
/*    */ 
/*    */ import org.renjin.compiler.cfg.ControlFlowGraph;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ import org.renjin.repackaged.asm.commons.InstructionAdapter;
/*    */ import org.renjin.sexp.Symbol;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ApplyMethodContext
/*    */   extends EmitContext
/*    */ {
/*    */   private Symbol argumentName;
/*    */   private Type argumentType;
/*    */   
/*    */   public ApplyMethodContext(ControlFlowGraph cfg, Symbol argumentName, Type argumentType, VariableSlots variableSlots) {
/* 32 */     super(cfg, argumentType.getSize(), variableSlots);
/* 33 */     this.argumentName = argumentName;
/* 34 */     this.argumentType = argumentType;
/*    */   }
/*    */ 
/*    */   
/*    */   public void loadParam(InstructionAdapter mv, Symbol param) {
/* 39 */     if (param.equals(this.argumentName)) {
/* 40 */       mv.load(0, this.argumentType);
/*    */     } else {
/* 42 */       throw new IllegalStateException("argument: " + param);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/codegen/ApplyMethodContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */