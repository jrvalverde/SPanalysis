/*    */ package org.renjin.invoke.reflection.converters;
/*    */ 
/*    */ import org.renjin.sexp.DoubleArrayVector;
/*    */ import org.renjin.sexp.DoubleVector;
/*    */ import org.renjin.sexp.SEXP;
/*    */ import org.renjin.sexp.Vector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FloatConverter
/*    */   extends PrimitiveScalarConverter<Number>
/*    */ {
/* 28 */   public static final Converter INSTANCE = new FloatConverter();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SEXP convertToR(Number value) {
/* 35 */     if (value == null) {
/* 36 */       return (SEXP)new DoubleArrayVector(new double[] { DoubleVector.NA });
/*    */     }
/* 38 */     return (SEXP)new DoubleArrayVector(new double[] { value.doubleValue() });
/*    */   }
/*    */ 
/*    */   
/*    */   public static boolean accept(Class<float> clazz) {
/* 43 */     return (clazz == float.class || clazz == Float.class);
/*    */   }
/*    */ 
/*    */   
/*    */   public Vector.Type getVectorType() {
/* 48 */     return (Vector.Type)DoubleVector.VECTOR_TYPE;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Object getFirstElement(Vector value) {
/* 53 */     return Float.valueOf((float)value.getElementAsDouble(0));
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean acceptsSEXP(SEXP exp) {
/* 58 */     return (exp instanceof DoubleVector || exp instanceof org.renjin.sexp.IntVector || exp instanceof org.renjin.sexp.LogicalVector);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int getSpecificity() {
/* 64 */     return 3;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/reflection/converters/FloatConverter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */