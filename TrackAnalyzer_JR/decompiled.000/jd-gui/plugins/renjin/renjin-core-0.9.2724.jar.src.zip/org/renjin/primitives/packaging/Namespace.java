/*     */ package org.renjin.primitives.packaging;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Optional;
/*     */ import org.renjin.eval.Context;
/*     */ import org.renjin.eval.EvalException;
/*     */ import org.renjin.invoke.reflection.ClassBindingImpl;
/*     */ import org.renjin.primitives.text.regex.RE;
/*     */ import org.renjin.primitives.text.regex.REFactory;
/*     */ import org.renjin.repackaged.guava.collect.Lists;
/*     */ import org.renjin.s4.S4;
/*     */ import org.renjin.sexp.Environment;
/*     */ import org.renjin.sexp.ExternalPtr;
/*     */ import org.renjin.sexp.Function;
/*     */ import org.renjin.sexp.NamedValue;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.Symbol;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Namespace
/*     */ {
/*     */   private final Package pkg;
/*     */   private final Environment namespaceEnvironment;
/*     */   private final Environment importsEnvironment;
/*  43 */   private final List<Symbol> exports = Lists.newArrayList();
/*     */   
/*     */   private boolean exportsInitialized = false;
/*     */   
/*  47 */   protected final List<DllInfo> libraries = new ArrayList<>(0);
/*     */ 
/*     */   
/*     */   boolean loaded;
/*     */ 
/*     */ 
/*     */   
/*     */   public Namespace(Package pkg, Environment namespaceEnvironment) {
/*  55 */     this.pkg = pkg;
/*  56 */     this.namespaceEnvironment = namespaceEnvironment;
/*  57 */     this.importsEnvironment = namespaceEnvironment.getParent();
/*     */   }
/*     */   
/*     */   public String getName() {
/*  61 */     return this.pkg.getName().getPackageName();
/*     */   }
/*     */   
/*     */   public FqPackageName getFullyQualifiedName() {
/*  65 */     return this.pkg.getName();
/*     */   }
/*     */   
/*     */   public String getCompatibleName() {
/*  69 */     if (this.pkg.getName().getGroupId().equals("org.renjin")) {
/*  70 */       return this.pkg.getName().getPackageName();
/*     */     }
/*  72 */     return this.pkg.getName().toString(':');
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<Symbol> getExports() {
/*  81 */     if (FqPackageName.BASE.equals(this.pkg.getName()))
/*     */     {
/*  83 */       return this.namespaceEnvironment.getSymbolNames();
/*     */     }
/*     */     
/*  86 */     return Collections.unmodifiableCollection(this.exports);
/*     */   }
/*     */ 
/*     */   
/*     */   public SEXP getEntry(Symbol entry) {
/*  91 */     SEXP value = this.namespaceEnvironment.getVariableUnsafe(entry);
/*  92 */     if (value == Symbol.UNBOUND_VALUE) {
/*  93 */       throw new EvalException("Namespace " + this.pkg.getName() + " has no symbol named '" + entry + "'", new Object[0]);
/*     */     }
/*  95 */     return value;
/*     */   }
/*     */   
/*     */   public SEXP getExport(Symbol entry) {
/*  99 */     SEXP value = getExportIfExists(entry);
/* 100 */     if (value == Symbol.UNBOUND_VALUE) {
/* 101 */       throw new EvalException("Namespace " + this.pkg.getName() + " has no exported symbol named '" + entry.getPrintName() + "'", new Object[0]);
/*     */     }
/* 103 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SEXP getExportIfExists(Symbol entry) {
/* 110 */     if (FqPackageName.BASE.equals(this.pkg.getName())) {
/* 111 */       return this.namespaceEnvironment.getVariableUnsafe(entry);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 116 */     if (!this.exportsInitialized) {
/* 117 */       return this.namespaceEnvironment.findVariableUnsafe(entry);
/*     */     }
/*     */     
/* 120 */     if (this.exports.contains(entry)) {
/* 121 */       return this.namespaceEnvironment.findVariableUnsafe(entry);
/*     */     }
/* 123 */     return (SEXP)Symbol.UNBOUND_VALUE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Environment getImportsEnvironment() {
/* 131 */     return this.importsEnvironment;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Environment getNamespaceEnvironment() {
/* 139 */     return this.namespaceEnvironment;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<DllInfo> getLibraries() {
/* 144 */     return this.libraries;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void copyExportsTo(Context context, Environment packageEnv) {
/* 153 */     for (Symbol name : this.exports) {
/* 154 */       if (this.namespaceEnvironment.isActiveBinding(name)) {
/* 155 */         packageEnv.makeActiveBinding(name, this.namespaceEnvironment.getActiveBinding(name)); continue;
/*     */       } 
/* 157 */       SEXP exportValue = this.namespaceEnvironment.findVariableUnsafe(name);
/* 158 */       if (exportValue == Symbol.UNBOUND_VALUE) {
/*     */         continue;
/*     */       }
/* 161 */       packageEnv.setVariableUnsafe(name, exportValue);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void populateNamespace(Context context) throws IOException {
/* 174 */     for (NamedValue value : this.pkg.loadSymbols(context)) {
/* 175 */       this.namespaceEnvironment.setVariable(context, Symbol.get(value.getName()), value.getValue());
/*     */     }
/*     */     
/* 178 */     for (Dataset dataset : this.pkg.getDatasets()) {
/* 179 */       for (String objectName : dataset.getObjectNames()) {
/* 180 */         this.namespaceEnvironment.setVariable(context, objectName, (SEXP)new DatasetObjectPromise(dataset, objectName));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void addExport(Symbol export) {
/* 188 */     this.exports.add(export);
/*     */   }
/*     */   
/*     */   public Package getPackage() {
/* 192 */     return this.pkg;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String sanitizePackageNameForClassFiles(String packageName) {
/* 204 */     return packageName.replace('.', '$');
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void initImports(Context context, NamespaceRegistry registry, NamespaceFile file) {
/* 210 */     for (NamespaceFile.PackageImportEntry entry : file.getPackageImports()) {
/* 211 */       Namespace importedNamespace = registry.getNamespace(context, entry.getPackageName());
/* 212 */       if (entry.isAllSymbols()) {
/* 213 */         importedNamespace.copyExportsTo(context, this.importsEnvironment); continue;
/*     */       } 
/* 215 */       for (Symbol symbol : entry.getSymbols()) {
/* 216 */         SEXP export = importedNamespace.getExportIfExists(symbol);
/* 217 */         if (export == Symbol.UNBOUND_VALUE) {
/*     */           continue;
/*     */         }
/*     */ 
/*     */         
/* 222 */         this.importsEnvironment.setVariableUnsafe(symbol, export);
/*     */       } 
/*     */ 
/*     */       
/* 226 */       for (String methodName : entry.getMethods()) {
/* 227 */         SEXP export = importedNamespace.getExportIfExists(Symbol.get(methodName));
/* 228 */         if (export == Symbol.UNBOUND_VALUE) {
/* 229 */           context.warn(String.format("Method '%s' not exported from namespace '%s'", new Object[] { methodName, importedNamespace
/*     */                   
/* 231 */                   .getName() })); continue;
/*     */         } 
/* 233 */         this.importsEnvironment.setVariableUnsafe(methodName, export);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 238 */       for (String className : entry.getClasses()) {
/* 239 */         Symbol symbol = S4.classNameMetadata(className);
/* 240 */         SEXP export = importedNamespace.getExportIfExists(symbol);
/* 241 */         if (export == Symbol.UNBOUND_VALUE) {
/* 242 */           context.warn(String.format("Class '%s' is not exported from namespace '%s'", new Object[] { className, importedNamespace
/*     */                   
/* 244 */                   .getName() })); continue;
/*     */         } 
/* 246 */         this.importsEnvironment.setVariableUnsafe(symbol, export);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 253 */     for (NamespaceFile.JvmClassImportEntry entry : file.getJvmImports()) {
/* 254 */       Class importedClass = null;
/*     */       try {
/* 256 */         importedClass = this.pkg.loadClass(entry.getClassName());
/* 257 */       } catch (ClassNotFoundException e) {
/* 258 */         throw new EvalException("Could not load JVM class '%s' from package '%s'", new Object[] { entry.getClassName(), this.pkg.getName() });
/*     */       } 
/*     */       
/* 261 */       if (entry.isClassImported()) {
/* 262 */         this.importsEnvironment.setVariableUnsafe(importedClass.getSimpleName(), (SEXP)new ExternalPtr(importedClass));
/*     */       }
/* 264 */       if (!entry.getMethods().isEmpty()) {
/* 265 */         ClassBindingImpl importedClassBinding = ClassBindingImpl.get(importedClass);
/* 266 */         for (String method : entry.getMethods()) {
/* 267 */           this.importsEnvironment.setVariableUnsafe(method, importedClassBinding.getStaticMember(method).getValue());
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 273 */     for (NamespaceFile.DynLibEntry library : file.getDynLibEntries()) {
/* 274 */       importDynamicLibrary(context, library);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void importDynamicLibrary(Context context, NamespaceFile.DynLibEntry entry) {
/*     */     DllInfo library;
/*     */     try {
/* 296 */       library = loadDynamicLibrary(context, entry.getLibraryName());
/* 297 */     } catch (Exception e) {
/*     */       
/* 299 */       if (!isClassSimplyNotFound(e)) {
/* 300 */         e.printStackTrace();
/*     */       }
/* 302 */       context.warn("Could not load compiled Fortran/C/C++ sources class for package " + this.pkg.getName() + ".\nThis is most likely because Renjin's compiler is not yet able to handle the sources for this\nparticular package. As a result, some functions may not work.\n");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 320 */     for (NamespaceFile.DynLibSymbol declaredSymbol : entry.getSymbols()) {
/* 321 */       Optional<DllSymbol> symbol = library.findMethod(DllSymbol.Convention.C, declaredSymbol.getSymbolName());
/* 322 */       if (symbol.isPresent()) {
/* 323 */         this.namespaceEnvironment.setVariableUnsafe(entry.getPrefix() + declaredSymbol.getAlias(), (SEXP)((DllSymbol)symbol.get()).buildNativeSymbolInfoSexp());
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 333 */     if (entry.isRegistration())
/*     */     {
/* 335 */       for (DllSymbol symbol : library.getRegisteredSymbols()) {
/* 336 */         this.namespaceEnvironment.setVariableUnsafe(entry.getPrefix() + symbol.getName(), (SEXP)symbol.buildNativeSymbolInfoSexp());
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isClassSimplyNotFound(Exception e) {
/* 349 */     return (e instanceof ClassNotFoundException && e.getCause() == null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DllInfo loadDynamicLibrary(Context context, String libraryName) throws ClassNotFoundException {
/* 374 */     FqPackageName packageName = this.pkg.getName();
/*     */ 
/*     */     
/* 377 */     String className = packageName.getGroupId() + "." + sanitizePackageNameForClassFiles(packageName.getPackageName()) + "." + sanitizePackageNameForClassFiles(libraryName);
/*     */     
/* 379 */     Class libraryClass = this.pkg.loadClass(className);
/*     */ 
/*     */     
/* 382 */     DllInfo library = new DllInfo(libraryName, libraryClass);
/* 383 */     library.initialize(context);
/*     */ 
/*     */     
/* 386 */     context.getSession().loadLibrary(library);
/*     */ 
/*     */     
/* 389 */     this.libraries.add(library);
/*     */     
/* 391 */     return library;
/*     */   }
/*     */   
/*     */   public Optional<DllSymbol> lookupSymbol(DllSymbol.Convention convention, String name) {
/* 395 */     for (DllInfo library : this.libraries) {
/* 396 */       Optional<DllSymbol> symbol = library.lookup(convention, name);
/* 397 */       if (symbol.isPresent()) {
/* 398 */         return symbol;
/*     */       }
/*     */     } 
/* 401 */     return Optional.empty();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void initExports(NamespaceFile file) {
/* 407 */     for (String pattern : file.getExportedPatterns()) {
/* 408 */       RE re = REFactory.compile(pattern, false, false, false, false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 414 */       for (Symbol symbol : this.namespaceEnvironment.getSymbolNames()) {
/* 415 */         if (re.match(symbol.getPrintName())) {
/* 416 */           this.exports.add(symbol);
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 422 */     for (Symbol symbol : file.getExportedSymbols()) {
/* 423 */       this.exports.add(symbol);
/*     */     }
/*     */ 
/*     */     
/* 427 */     for (String className : file.getExportedClasses()) {
/* 428 */       this.exports.add(S4.classNameMetadata(className));
/*     */     }
/*     */ 
/*     */     
/* 432 */     for (String methodName : file.getExportedS4Methods()) {
/* 433 */       this.exports.add(Symbol.get(methodName));
/*     */     }
/*     */ 
/*     */     
/* 437 */     for (Dataset dataset : this.pkg.getDatasets()) {
/* 438 */       for (String objectName : dataset.getObjectNames()) {
/* 439 */         this.exports.add(Symbol.get(objectName));
/*     */       }
/*     */     } 
/*     */     
/* 443 */     this.exportsInitialized = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerS3Methods(Context context, NamespaceFile file) {
/* 453 */     for (NamespaceFile.S3MethodEntry entry : file.getExportedS3Methods()) {
/* 454 */       registerS3Method(context, entry);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void registerS3Method(Context context, NamespaceFile.S3MethodEntry entry) {
/* 460 */     Function method = resolveFunction(context, entry.getFunctionName());
/*     */ 
/*     */     
/* 463 */     Optional<Environment> definitionEnv = Namespaces.resolveGenericFunctionNamespace(context, entry.getGenericMethod(), this.namespaceEnvironment);
/* 464 */     if (!definitionEnv.isPresent()) {
/* 465 */       context.warn(String.format("Cannot resolve namespace environment from generic function '%s'", new Object[] { entry
/* 466 */               .getGenericMethod() }));
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 471 */     Namespaces.registerS3Method(context, entry.getGenericMethod(), entry.getClassName(), method, definitionEnv.get());
/*     */   }
/*     */   
/*     */   private Function resolveFunction(Context context, String functionName) {
/* 475 */     SEXP methodExp = this.namespaceEnvironment.getVariableUnsafe(functionName).force(context);
/* 476 */     if (methodExp == Symbol.UNBOUND_VALUE) {
/* 477 */       throw new EvalException("Missing export: " + functionName + " not found in " + getName(), new Object[0]);
/*     */     }
/* 479 */     if (!(methodExp instanceof Function)) {
/* 480 */       throw new EvalException(functionName + ": expected function but was " + methodExp.getTypeName(), new Object[0]);
/*     */     }
/* 482 */     return (Function)methodExp;
/*     */   }
/*     */   
/*     */   public boolean isLoaded() {
/* 486 */     return this.loaded;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/packaging/Namespace.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */