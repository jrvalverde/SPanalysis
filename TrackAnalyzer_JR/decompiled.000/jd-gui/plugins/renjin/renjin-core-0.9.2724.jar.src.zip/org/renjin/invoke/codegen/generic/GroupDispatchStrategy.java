/*    */ package org.renjin.invoke.codegen.generic;
/*    */ 
/*    */ import com.sun.codemodel.JBlock;
/*    */ import com.sun.codemodel.JCodeModel;
/*    */ import com.sun.codemodel.JExpr;
/*    */ import com.sun.codemodel.JExpression;
/*    */ import com.sun.codemodel.JType;
/*    */ import com.sun.codemodel.JVar;
/*    */ import org.renjin.invoke.codegen.ApplyMethodContext;
/*    */ import org.renjin.primitives.S3;
/*    */ import org.renjin.sexp.SEXP;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GroupDispatchStrategy
/*    */   extends GenericDispatchStrategy
/*    */ {
/*    */   private String groupName;
/*    */   private final String methodName;
/*    */   
/*    */   public GroupDispatchStrategy(JCodeModel codeModel, String groupName, String methodName) {
/* 40 */     super(codeModel);
/* 41 */     this.groupName = groupName;
/* 42 */     this.methodName = methodName;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void afterFirstArgIsEvaluated(ApplyMethodContext context, JExpression functionCall, JExpression arguments, JBlock parent, JExpression argument) {
/* 49 */     JBlock ifObject = parent._if((JExpression)fastIsObject(argument))._then();
/* 50 */     JVar jVar = ifObject.decl((JType)this.codeModel.ref(SEXP.class), "genericResult", (JExpression)this.codeModel
/* 51 */         .ref(S3.class).staticInvoke("tryDispatchGroupFromPrimitive")
/* 52 */         .arg(context.getContext())
/* 53 */         .arg(context.getEnvironment())
/* 54 */         .arg(functionCall)
/* 55 */         .arg(JExpr.lit(this.groupName))
/* 56 */         .arg(JExpr.lit(this.methodName))
/* 57 */         .arg(argument)
/* 58 */         .arg(arguments));
/* 59 */     ifObject._if(jVar.ne(JExpr._null()))._then()._return((JExpression)jVar);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/codegen/generic/GroupDispatchStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */