/*    */ package org.renjin.base;
/*    */ 
/*    */ import java.text.DecimalFormat;
/*    */ import java.text.NumberFormat;
/*    */ import org.renjin.sexp.StringVector;
/*    */ import org.renjin.sexp.Vector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StrSignIf
/*    */ {
/*    */   public static StringVector str_signif(Vector x, int width, int digits, String format, String flag) {
/* 59 */     NumberFormat formatter = buildFormat(digits, format, flag);
/*    */     
/* 61 */     StringVector.Builder result = new StringVector.Builder();
/* 62 */     for (int i = 0; i != x.length(); i++) {
/* 63 */       result.add(formatter.format(x.getElementAsDouble(i)));
/*    */     }
/* 65 */     return (StringVector)result.build();
/*    */   }
/*    */   private static NumberFormat buildFormat(int digits, String format, String flag) {
/*    */     DecimalFormat formatter;
/* 69 */     if (format.equals("d")) {
/* 70 */       return NumberFormat.getIntegerInstance();
/*    */     }
/*    */ 
/*    */     
/* 74 */     if (format.equals("e")) {
/* 75 */       formatter = new DecimalFormat("0.00e0");
/* 76 */     } else if (format.equals("E")) {
/* 77 */       formatter = new DecimalFormat("0.00E0");
/*    */     } else {
/* 79 */       formatter = new DecimalFormat();
/*    */     } 
/* 81 */     if (digits < 0) {
/* 82 */       digits = 6;
/*    */     }
/* 84 */     formatter.setMaximumFractionDigits(digits);
/* 85 */     formatter.setMinimumFractionDigits(digits);
/* 86 */     return formatter;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/base/StrSignIf.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */