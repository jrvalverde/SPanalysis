/*    */ package org.renjin.primitives.combine;
/*    */ 
/*    */ import org.renjin.sexp.SEXP;
/*    */ import org.renjin.sexp.StringVector;
/*    */ import org.renjin.sexp.Symbols;
/*    */ import org.renjin.sexp.Vector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class MaterializedBuilder
/*    */   implements CombinedBuilder
/*    */ {
/*    */   private Vector.Builder vector;
/* 30 */   private StringVector.Builder names = new StringVector.Builder();
/*    */   private boolean haveNames = false;
/*    */   private boolean useNames = false;
/*    */   
/*    */   MaterializedBuilder(Vector.Type resultType) {
/* 35 */     this.vector = resultType.newBuilder();
/*    */   }
/*    */ 
/*    */   
/*    */   public CombinedBuilder useNames(boolean useNames) {
/* 40 */     this.useNames = useNames;
/* 41 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public void add(String prefix, SEXP sexp) {
/* 46 */     this.vector.add(sexp);
/* 47 */     addName(prefix);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void addElements(String prefix, Vector value) {
/* 53 */     StringVector elementNames = CombinedNames.combine(prefix, value);
/* 54 */     if (this.useNames && 
/* 55 */       CombinedNames.hasNames(prefix, value)) {
/* 56 */       this.haveNames = true;
/*    */     }
/*    */ 
/*    */     
/* 60 */     for (int i = 0; i != value.length(); i++) {
/* 61 */       this.vector.addFrom((SEXP)value, i);
/* 62 */       if (this.useNames) {
/* 63 */         this.names.add(elementNames.getElementAsString(i));
/*    */       }
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Vector build() {
/* 71 */     if (this.haveNames) {
/* 72 */       this.vector.setAttribute(Symbols.NAMES, (SEXP)this.names.build());
/*    */     }
/* 74 */     return this.vector.build();
/*    */   }
/*    */   
/*    */   private void addName(String name) {
/* 78 */     if (StringVector.isNA(name) || name.length() > 0) {
/* 79 */       this.haveNames = true;
/*    */     }
/*    */     
/* 82 */     this.names.add(name);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/combine/MaterializedBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */