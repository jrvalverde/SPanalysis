/*     */ package org.renjin.compiler.ir.tac.expressions;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.renjin.compiler.NotCompilableException;
/*     */ import org.renjin.compiler.builtins.ArgumentBounds;
/*     */ import org.renjin.compiler.builtins.BuiltinSpecializers;
/*     */ import org.renjin.compiler.builtins.FailedToSpecializeException;
/*     */ import org.renjin.compiler.builtins.Specialization;
/*     */ import org.renjin.compiler.builtins.Specializer;
/*     */ import org.renjin.compiler.builtins.UnspecializedCall;
/*     */ import org.renjin.compiler.codegen.EmitContext;
/*     */ import org.renjin.compiler.ir.ValueBounds;
/*     */ import org.renjin.compiler.ir.tac.IRArgument;
/*     */ import org.renjin.compiler.ir.tac.RuntimeState;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ import org.renjin.repackaged.asm.commons.InstructionAdapter;
/*     */ import org.renjin.repackaged.guava.base.Joiner;
/*     */ import org.renjin.sexp.FunctionCall;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BuiltinCall
/*     */   implements CallExpression
/*     */ {
/*     */   private final RuntimeState runtimeState;
/*     */   private FunctionCall call;
/*     */   private String primitiveName;
/*     */   private final List<IRArgument> arguments;
/*     */   private final Specializer specializer;
/*  48 */   private Specialization specialization = (Specialization)UnspecializedCall.INSTANCE;
/*     */   
/*     */   public BuiltinCall(RuntimeState runtimeState, FunctionCall call, String primitiveName, List<IRArgument> arguments) {
/*  51 */     this.runtimeState = runtimeState;
/*  52 */     this.call = call;
/*  53 */     this.primitiveName = primitiveName;
/*  54 */     this.arguments = arguments;
/*  55 */     this.specializer = BuiltinSpecializers.INSTANCE.get(primitiveName);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getChildCount() {
/*  60 */     return this.arguments.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public Expression childAt(int index) {
/*  65 */     return ((IRArgument)this.arguments.get(index)).getExpression();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setChild(int childIndex, Expression child) {
/*  70 */     ((IRArgument)this.arguments.get(childIndex)).setExpression(child);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPure() {
/*  75 */     return this.specialization.isPure();
/*     */   }
/*     */ 
/*     */   
/*     */   public int load(EmitContext emitContext, InstructionAdapter mv) {
/*     */     try {
/*  81 */       this.specialization.load(emitContext, mv, this.arguments);
/*     */     }
/*  83 */     catch (FailedToSpecializeException e) {
/*  84 */       throw new NotCompilableException(this.call, "Failed to specialize .Primitive(" + this.primitiveName + ")");
/*     */     } 
/*  86 */     return 1;
/*     */   }
/*     */ 
/*     */   
/*     */   public ValueBounds updateTypeBounds(Map<Expression, ValueBounds> typeMap) {
/*  91 */     List<ArgumentBounds> argumentTypes = new ArrayList<>();
/*  92 */     for (IRArgument argument : this.arguments) {
/*  93 */       argumentTypes.add(new ArgumentBounds(argument.getName(), argument.getExpression().updateTypeBounds(typeMap)));
/*     */     }
/*  95 */     this.specialization = this.specializer.trySpecialize(this.runtimeState, argumentTypes);
/*     */     
/*  97 */     return this.specialization.getResultBounds();
/*     */   }
/*     */ 
/*     */   
/*     */   public Type getType() {
/* 102 */     return this.specialization.getType();
/*     */   }
/*     */ 
/*     */   
/*     */   public ValueBounds getValueBounds() {
/* 107 */     return this.specialization.getResultBounds();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 112 */     return "(" + this.primitiveName + " " + Joiner.on(" ").join(this.arguments) + ")";
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/ir/tac/expressions/BuiltinCall.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */