/*    */ package org.renjin.invoke.codegen.scalars;
/*    */ 
/*    */ import com.sun.codemodel.JCodeModel;
/*    */ import com.sun.codemodel.JExpr;
/*    */ import com.sun.codemodel.JExpression;
/*    */ import com.sun.codemodel.JVar;
/*    */ import org.renjin.sexp.RawVector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ByteType
/*    */   extends ScalarType
/*    */ {
/*    */   public Class getScalarType() {
/* 31 */     return byte.class;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getConversionMethod() {
/* 36 */     return "convertToRawPrimitive";
/*    */   }
/*    */ 
/*    */   
/*    */   public String getAccessorMethod() {
/* 41 */     return "getElementAsByte";
/*    */   }
/*    */ 
/*    */   
/*    */   public Class getVectorType() {
/* 46 */     return RawVector.class;
/*    */   }
/*    */ 
/*    */   
/*    */   public Class<RawVector.Builder> getBuilderClass() {
/* 51 */     return RawVector.Builder.class;
/*    */   }
/*    */ 
/*    */   
/*    */   public Class getBuilderArrayElementClass() {
/* 56 */     return byte.class;
/*    */   }
/*    */ 
/*    */   
/*    */   public Class getArrayVectorClass() {
/* 61 */     return RawVector.class;
/*    */   }
/*    */ 
/*    */   
/*    */   public JExpression naLiteral(JCodeModel codeModel) {
/* 66 */     return JExpr.lit(0);
/*    */   }
/*    */ 
/*    */   
/*    */   public JExpression testNaExpr(JCodeModel codeModel, JVar scalarVariable) {
/* 71 */     return JExpr.FALSE;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/codegen/scalars/ByteType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */