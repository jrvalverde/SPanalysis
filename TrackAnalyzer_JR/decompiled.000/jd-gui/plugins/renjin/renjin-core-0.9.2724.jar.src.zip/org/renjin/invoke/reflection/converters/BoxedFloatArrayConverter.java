/*    */ package org.renjin.invoke.reflection.converters;
/*    */ 
/*    */ import org.renjin.sexp.AtomicVector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BoxedFloatArrayConverter
/*    */   extends DoubleArrayConverter
/*    */ {
/* 25 */   public static final BoxedFloatArrayConverter BOXED_FLOAT_ARRAY = new BoxedFloatArrayConverter();
/*    */   
/*    */   private BoxedFloatArrayConverter() {
/* 28 */     super(Float.class);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected Object convertToJavaArray(AtomicVector vector) {
/* 34 */     Float[] array = new Float[vector.length()];
/* 35 */     for (int i = 0; i < vector.length(); i++) {
/* 36 */       array[i] = Float.valueOf((float)vector.getElementAsDouble(i));
/*    */     }
/* 38 */     return array;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/reflection/converters/BoxedFloatArrayConverter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */