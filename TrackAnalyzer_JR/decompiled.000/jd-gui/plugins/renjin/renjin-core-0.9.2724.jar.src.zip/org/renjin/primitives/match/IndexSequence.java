/*    */ package org.renjin.primitives.match;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import org.renjin.sexp.Vector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class IndexSequence
/*    */   implements Iterable<Integer>
/*    */ {
/*    */   private Vector vector;
/*    */   private boolean fromLast;
/*    */   
/*    */   public IndexSequence(Vector vector, boolean fromLast) {
/* 33 */     this.vector = vector;
/* 34 */     this.fromLast = fromLast;
/*    */   }
/*    */ 
/*    */   
/*    */   public Iterator<Integer> iterator() {
/* 39 */     if (this.fromLast) {
/* 40 */       return (Iterator<Integer>)new ReverseIndexIterator(this.vector);
/*    */     }
/* 42 */     return (Iterator<Integer>)new ForwardIndexIterator(this.vector);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/match/IndexSequence.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */