/*     */ package org.renjin.primitives.packaging;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import java.util.function.Predicate;
/*     */ import org.renjin.eval.Context;
/*     */ import org.renjin.eval.EvalException;
/*     */ import org.renjin.primitives.Native;
/*     */ import org.renjin.sexp.ExternalPtr;
/*     */ import org.renjin.sexp.ListVector;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.StringVector;
/*     */ import org.renjin.sexp.Symbols;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DllInfo
/*     */ {
/*     */   private final String libraryName;
/*     */   private final Class libraryClass;
/*  52 */   private final Map<String, DllSymbol> registeredSymbols = new HashMap<>();
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean useDynamicSymbols = true;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean forceSymbols = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DllInfo(String libraryName, Class clazz) {
/*  66 */     this.libraryName = libraryName;
/*  67 */     this.libraryClass = clazz;
/*     */   }
/*     */   
/*     */   public String getLibraryName() {
/*  71 */     return this.libraryName;
/*     */   }
/*     */   
/*     */   public void register(DllSymbol symbol) {
/*  75 */     this.registeredSymbols.put(symbol.getName(), symbol);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean setUseDynamicSymbols(boolean use) {
/*  84 */     boolean oldValue = this.useDynamicSymbols;
/*  85 */     this.useDynamicSymbols = use;
/*  86 */     return oldValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean forceSymbols(boolean value) {
/*  94 */     boolean oldValue = this.forceSymbols;
/*  95 */     this.forceSymbols = value;
/*  96 */     return oldValue;
/*     */   }
/*     */   
/*     */   public Optional<DllSymbol> getRegisteredSymbol(String name) {
/* 100 */     return Optional.ofNullable(this.registeredSymbols.get(name));
/*     */   }
/*     */ 
/*     */   
/*     */   public Optional<DllSymbol> getSymbol(String name) {
/* 105 */     DllSymbol symbol = this.registeredSymbols.get(name);
/* 106 */     if (symbol != null) {
/* 107 */       return Optional.of(symbol);
/*     */     }
/*     */     
/* 110 */     if (this.useDynamicSymbols) {
/* 111 */       return lookupWithReflection(DllSymbol.Convention.C, name);
/*     */     }
/* 113 */     return Optional.empty();
/*     */   }
/*     */   
/*     */   public Iterable<DllSymbol> getRegisteredSymbols() {
/* 117 */     return this.registeredSymbols.values();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initialize(Context context) {
/* 129 */     Optional<Method> initMethod = findInitRoutine();
/* 130 */     if (initMethod.isPresent()) {
/* 131 */       Context previousContext = Native.CURRENT_CONTEXT.get();
/* 132 */       Native.CURRENT_CONTEXT.set(context);
/*     */       try {
/* 134 */         if ((((Method)initMethod.get()).getParameterTypes()).length == 0) {
/* 135 */           ((Method)initMethod.get()).invoke(null, new Object[0]);
/*     */         } else {
/* 137 */           ((Method)initMethod.get()).invoke(null, new Object[] { this });
/*     */         }
/*     */       
/* 140 */       } catch (InvocationTargetException|IllegalAccessException e) {
/* 141 */         throw new EvalException("Exception initializing compiled GNU R library " + this.libraryClass, e.getCause());
/*     */       } finally {
/* 143 */         Native.CURRENT_CONTEXT.set(previousContext);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Optional<Method> findInitRoutine() {
/* 153 */     String initName = "R_init_" + sanitizeLibraryName(this.libraryName);
/* 154 */     Class[] expectedParameterTypes = { DllInfo.class };
/*     */     
/* 156 */     for (Method method : this.libraryClass.getMethods()) {
/* 157 */       if (method.getName().equals(initName)) {
/* 158 */         if ((method.getParameterTypes()).length != 0 && 
/* 159 */           !Arrays.equals((Object[])method.getParameterTypes(), (Object[])expectedParameterTypes)) {
/* 160 */           throw new EvalException(String.format("%s.%s has invalid signature: %s. Expected %s(DllInfo info)", new Object[] { this.libraryClass
/* 161 */                   .getName(), initName, method
/*     */                   
/* 163 */                   .toString(), initName }), new Object[0]);
/*     */         }
/*     */         
/* 166 */         return Optional.of(method);
/*     */       } 
/*     */     } 
/* 169 */     return Optional.empty();
/*     */   }
/*     */   
/*     */   private String sanitizeLibraryName(String libraryName) {
/* 173 */     return libraryName.replace('.', '_');
/*     */   }
/*     */   
/*     */   private boolean isPublicStatic(Method method) {
/* 177 */     return (Modifier.isStatic(method.getModifiers()) && Modifier.isPublic(method.getModifiers()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<DllSymbol> lookup(DllSymbol.Convention convention, String symbolName) {
/* 185 */     if (this.forceSymbols) {
/* 186 */       return Optional.empty();
/*     */     }
/* 188 */     return findMethod(convention, symbolName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<DllSymbol> findMethod(DllSymbol.Convention convention, String symbolName) {
/* 198 */     Optional<DllSymbol> registeredSymbol = lookupRegisteredSymbol(convention, symbolName);
/* 199 */     if (registeredSymbol.isPresent()) {
/* 200 */       return registeredSymbol;
/*     */     }
/*     */     
/* 203 */     if (this.useDynamicSymbols) {
/* 204 */       return lookupWithReflection(convention, symbolName);
/*     */     }
/*     */     
/* 207 */     return Optional.empty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Optional<DllSymbol> lookupRegisteredSymbol(DllSymbol.Convention convention, String symbolName) {
/* 214 */     if (convention == DllSymbol.Convention.FORTRAN) {
/* 215 */       symbolName = symbolName.toLowerCase();
/*     */     }
/*     */     
/* 218 */     return Optional.ofNullable(this.registeredSymbols.get(symbolName));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Optional<DllSymbol> lookupWithReflection(DllSymbol.Convention convention, String symbolName) {
/* 225 */     if (convention == DllSymbol.Convention.FORTRAN) {
/* 226 */       symbolName = symbolName.toLowerCase() + "_";
/*     */     }
/*     */     
/* 229 */     for (Method method : this.libraryClass.getMethods()) {
/* 230 */       if (method.getName().equals(symbolName) && isPublicStatic(method)) {
/* 231 */         return Optional.of(new DllSymbol(Optional.empty(), method));
/*     */       }
/*     */     } 
/* 234 */     return Optional.empty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SEXP buildDllInfoSexp() {
/* 241 */     ListVector.NamedBuilder object = ListVector.newNamedBuilder();
/* 242 */     object.setAttribute(Symbols.CLASS, (SEXP)StringVector.valueOf("DLLInfo"));
/* 243 */     object.add("name", this.libraryName);
/* 244 */     object.add("path", this.libraryClass.getName());
/* 245 */     object.add("dynamicLookup", this.useDynamicSymbols);
/* 246 */     object.add("info", (SEXP)new ExternalPtr(this));
/* 247 */     return (SEXP)object.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ListVector buildRegisteredRoutinesSexp() {
/* 255 */     ListVector.NamedBuilder object = new ListVector.NamedBuilder();
/* 256 */     object.setAttribute(Symbols.CLASS, (SEXP)StringVector.valueOf("DLLRegisteredRoutines"));
/* 257 */     object.add(".C", (SEXP)buildNativeRoutineList(DllSymbol.Convention.C));
/* 258 */     object.add(".Call", (SEXP)buildNativeRoutineList(DllSymbol.Convention.CALL));
/* 259 */     object.add(".Fortran", (SEXP)buildNativeRoutineList(DllSymbol.Convention.FORTRAN));
/* 260 */     object.add(".External", (SEXP)buildNativeRoutineList(DllSymbol.Convention.EXTERNAL));
/* 261 */     return object.build();
/*     */   }
/*     */   
/*     */   private ListVector buildNativeRoutineList(DllSymbol.Convention convention) {
/* 265 */     ListVector.NamedBuilder object = new ListVector.NamedBuilder();
/* 266 */     object.setAttribute(Symbols.CLASS, (SEXP)StringVector.valueOf("NativeRoutineList"));
/*     */     
/* 268 */     for (DllSymbol symbol : this.registeredSymbols.values()) {
/* 269 */       if (symbol.getConvention() == convention) {
/* 270 */         object.add(symbol.getName(), (SEXP)symbol.buildNativeSymbolInfoSexp());
/*     */       }
/*     */     } 
/* 273 */     return object.build();
/*     */   }
/*     */   
/*     */   public boolean isLoaded(String name, Predicate<DllSymbol> predicate) {
/* 277 */     if (this.registeredSymbols.containsKey(name)) {
/* 278 */       DllSymbol symbol = this.registeredSymbols.get(name);
/* 279 */       if (predicate.test(symbol)) {
/* 280 */         return true;
/*     */       }
/*     */     } 
/* 283 */     return false;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/packaging/DllInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */