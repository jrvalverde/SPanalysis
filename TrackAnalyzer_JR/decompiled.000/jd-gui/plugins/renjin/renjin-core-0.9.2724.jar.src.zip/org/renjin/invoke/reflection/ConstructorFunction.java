/*    */ package org.renjin.invoke.reflection;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import org.renjin.eval.Context;
/*    */ import org.renjin.invoke.codegen.ArgumentIterator;
/*    */ import org.renjin.repackaged.guava.collect.Lists;
/*    */ import org.renjin.repackaged.guava.collect.Maps;
/*    */ import org.renjin.sexp.AbstractSEXP;
/*    */ import org.renjin.sexp.Environment;
/*    */ import org.renjin.sexp.ExternalPtr;
/*    */ import org.renjin.sexp.Function;
/*    */ import org.renjin.sexp.FunctionCall;
/*    */ import org.renjin.sexp.PairList;
/*    */ import org.renjin.sexp.SEXP;
/*    */ import org.renjin.sexp.SexpVisitor;
/*    */ import org.renjin.sexp.Symbol;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConstructorFunction
/*    */   extends AbstractSEXP
/*    */   implements Function
/*    */ {
/*    */   private final ConstructorBinding binding;
/*    */   
/*    */   public ConstructorFunction(ConstructorBinding binding) {
/* 36 */     this.binding = binding;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getTypeName() {
/* 41 */     return "constructor";
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void accept(SexpVisitor visitor) {}
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SEXP apply(Context context, Environment rho, FunctionCall call, PairList args) {
/* 53 */     List<SEXP> constructorArgs = Lists.newArrayList();
/* 54 */     Map<Symbol, SEXP> propertyValues = Maps.newHashMap();
/*    */     
/* 56 */     ArgumentIterator argIt = new ArgumentIterator(context, rho, args);
/* 57 */     while (argIt.hasNext()) {
/* 58 */       PairList.Node node = argIt.nextNode();
/* 59 */       SEXP evaled = context.evaluate(node.getValue(), rho);
/*    */       
/* 61 */       if (node.hasTag()) {
/* 62 */         propertyValues.put(node.getTag(), evaled); continue;
/*    */       } 
/* 64 */       constructorArgs.add(evaled);
/*    */     } 
/*    */ 
/*    */     
/* 68 */     Object instance = this.binding.newInstance(context, constructorArgs);
/* 69 */     if (instance instanceof SEXP) {
/* 70 */       return (SEXP)instance;
/*    */     }
/* 72 */     ExternalPtr externalPtr = new ExternalPtr(instance);
/* 73 */     for (Symbol propertyName : propertyValues.keySet()) {
/* 74 */       externalPtr.setMember(propertyName, propertyValues.get(propertyName));
/*    */     }
/* 76 */     return (SEXP)externalPtr;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/reflection/ConstructorFunction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */