package org.renjin.invoke.reflection;

import org.renjin.sexp.SEXP;

public interface MemberBinding {
  SEXP getValue(Object paramObject);
  
  void setValue(Object paramObject, SEXP paramSEXP);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/reflection/MemberBinding.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */