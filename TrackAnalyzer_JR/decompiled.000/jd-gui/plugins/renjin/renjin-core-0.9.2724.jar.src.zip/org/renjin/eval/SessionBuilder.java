/*     */ package org.renjin.eval;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import org.apache.commons.vfs2.FileSystemManager;
/*     */ import org.renjin.primitives.packaging.ClasspathPackageLoader;
/*     */ import org.renjin.primitives.packaging.PackageLoader;
/*     */ import org.renjin.repackaged.guava.collect.Lists;
/*     */ import org.renjin.repackaged.guava.util.concurrent.MoreExecutors;
/*     */ import org.renjin.sexp.Frame;
/*     */ import org.renjin.sexp.FunctionCall;
/*     */ import org.renjin.sexp.HashFrame;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.Symbol;
/*     */ import org.renjin.util.FileSystemUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SessionBuilder
/*     */ {
/*     */   private boolean loadBasePackage = true;
/*  38 */   private List<String> packagesToLoad = Lists.newArrayList();
/*     */   
/*     */   private FileSystemManager fileSystemManager;
/*     */   private PackageLoader packageLoader;
/*     */   private ClassLoader classLoader;
/*  43 */   private ExecutorService executorService = null;
/*     */   
/*  45 */   private Frame globalFrame = (Frame)new HashFrame();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public SessionBuilder withFileSystemManager(FileSystemManager fsm) {
/*  59 */     return setFileSystemManager(fsm);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SessionBuilder withoutBasePackage() {
/*  68 */     this.loadBasePackage = false;
/*  69 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SessionBuilder withDefaultPackages() {
/*  76 */     this.packagesToLoad = Session.DEFAULT_PACKAGES;
/*  77 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SessionBuilder setFileSystemManager(FileSystemManager fileSystemManager) {
/*  90 */     this.fileSystemManager = fileSystemManager;
/*  91 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SessionBuilder setPackageLoader(PackageLoader packageLoader) {
/* 105 */     this.packageLoader = packageLoader;
/* 106 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SessionBuilder setExecutorService(ExecutorService executorService) {
/* 120 */     this.executorService = executorService;
/* 121 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SessionBuilder setClassLoader(ClassLoader classLoader) {
/* 129 */     this.classLoader = classLoader;
/* 130 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SessionBuilder setGlobalFrame(Frame globalFrame) {
/* 137 */     this.globalFrame = globalFrame;
/* 138 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public <T> SessionBuilder bind(Class<T> clazz, T instance) {
/* 147 */     if (clazz.equals(FileSystemManager.class)) {
/* 148 */       setFileSystemManager((FileSystemManager)instance);
/* 149 */     } else if (clazz.equals(PackageLoader.class)) {
/* 150 */       setPackageLoader((PackageLoader)instance);
/* 151 */     } else if (clazz.equals(ClassLoader.class)) {
/* 152 */       setClassLoader((ClassLoader)instance);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 157 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Session build() {
/*     */     try {
/* 163 */       if (this.classLoader == null) {
/* 164 */         this.classLoader = getClass().getClassLoader();
/*     */       }
/*     */       
/* 167 */       if (this.fileSystemManager == null) {
/* 168 */         this.fileSystemManager = FileSystemUtils.getMinimalFileSystemManager(this.classLoader);
/*     */       }
/*     */       
/* 171 */       if (this.packageLoader == null) {
/* 172 */         this.packageLoader = (PackageLoader)new ClasspathPackageLoader(this.classLoader);
/*     */       }
/*     */       
/* 175 */       if (this.executorService == null) {
/* 176 */         this.executorService = (ExecutorService)MoreExecutors.sameThreadExecutor();
/*     */       }
/*     */       
/* 179 */       Session session = new Session(this.fileSystemManager, this.classLoader, this.packageLoader, this.executorService, this.globalFrame);
/*     */       
/* 181 */       if (this.loadBasePackage) {
/* 182 */         session.getTopLevelContext().init();
/*     */       }
/*     */       
/* 185 */       for (int i = this.packagesToLoad.size() - 1; i >= 0; i--) {
/* 186 */         session.getTopLevelContext().evaluate((SEXP)FunctionCall.newCall((SEXP)Symbol.get("library"), new SEXP[] {
/* 187 */                 (SEXP)Symbol.get(this.packagesToLoad.get(i)) }));
/*     */       } 
/* 189 */       return session;
/* 190 */     } catch (Exception e) {
/* 191 */       throw new RuntimeException(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static Session buildDefault() {
/* 196 */     return (new SessionBuilder()).build();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/eval/SessionBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */