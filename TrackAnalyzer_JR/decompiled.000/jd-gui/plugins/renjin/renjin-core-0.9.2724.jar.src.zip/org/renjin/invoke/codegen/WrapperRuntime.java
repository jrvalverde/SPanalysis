/*     */ package org.renjin.invoke.codegen;
/*     */ 
/*     */ import org.renjin.eval.Context;
/*     */ import org.renjin.primitives.Deparse;
/*     */ import org.renjin.sexp.DoubleArrayVector;
/*     */ import org.renjin.sexp.Environment;
/*     */ import org.renjin.sexp.ExternalPtr;
/*     */ import org.renjin.sexp.FunctionCall;
/*     */ import org.renjin.sexp.IntArrayVector;
/*     */ import org.renjin.sexp.Logical;
/*     */ import org.renjin.sexp.LogicalArrayVector;
/*     */ import org.renjin.sexp.Null;
/*     */ import org.renjin.sexp.PairList;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.StringArrayVector;
/*     */ import org.renjin.sexp.StringVector;
/*     */ import org.renjin.sexp.Symbol;
/*     */ import org.renjin.sexp.Symbols;
/*     */ import org.renjin.sexp.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WrapperRuntime
/*     */ {
/*     */   public static String convertToString(SEXP exp) {
/*  36 */     if (exp == Null.INSTANCE) {
/*  37 */       return null;
/*     */     }
/*  39 */     Vector vector = checkedSubClassAndAssertScalar(exp);
/*  40 */     return vector.getElementAsString(0);
/*     */   }
/*     */   
/*     */   public static int convertToInt(SEXP exp) {
/*  44 */     if (exp instanceof org.renjin.sexp.DoubleVector || exp instanceof org.renjin.sexp.IntVector || exp instanceof org.renjin.sexp.LogicalVector) {
/*  45 */       return ((Vector)exp).getElementAsInt(0);
/*     */     }
/*  47 */     throw new ArgumentException("expected int");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SEXP argumentValue(PairList args) {
/*  57 */     if (!(args instanceof PairList.Node)) {
/*  58 */       throw new ArgumentException("too few arguments");
/*     */     }
/*  60 */     return ((PairList.Node)args).getValue();
/*     */   }
/*     */ 
/*     */   
/*     */   private Integer convertToInteger(SEXP exp) {
/*  65 */     if (exp == Null.INSTANCE) {
/*  66 */       return null;
/*     */     }
/*  68 */     Vector vector = checkedSubClassAndAssertScalar(exp);
/*  69 */     if (vector.isElementNA(0)) {
/*  70 */       return null;
/*     */     }
/*  72 */     return Integer.valueOf(vector.getElementAsInt(0));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static Vector invokeAsCharacter(Context context, Environment rho, SEXP provided) {
/*  78 */     if (provided == Null.INSTANCE) {
/*  79 */       return (Vector)Null.INSTANCE;
/*     */     }
/*  81 */     provided = provided.force(context);
/*  82 */     return (Vector)context.evaluate(
/*  83 */         (SEXP)FunctionCall.newCall((SEXP)Symbols.AS_CHARACTER, new SEXP[] { provided }), rho);
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean convertToBooleanPrimitive(SEXP exp) {
/*  88 */     if (exp.length() == 0) {
/*  89 */       return false;
/*     */     }
/*  91 */     return (exp.asLogical() == Logical.TRUE);
/*     */   }
/*     */   
/*     */   public static Vector convertToVector(SEXP exp) {
/*  95 */     if (exp instanceof Vector)
/*  96 */       return (Vector)exp; 
/*  97 */     if (exp instanceof Symbol)
/*  98 */       return (Vector)new StringArrayVector(new String[] { ((Symbol)exp).getPrintName() }); 
/*  99 */     if (exp instanceof FunctionCall) {
/* 100 */       return (Vector)new StringArrayVector(new String[] { Deparse.deparseExp(null, exp) });
/*     */     }
/* 102 */     throw new ArgumentException("expected vector");
/*     */   }
/*     */ 
/*     */   
/*     */   public static double convertToDoublePrimitive(SEXP exp) {
/* 107 */     Vector vector = checkedSubClassAndAssertScalar(exp);
/* 108 */     return vector.getElementAsDouble(0);
/*     */   }
/*     */   
/*     */   public static double convertToRawPrimitive(SEXP exp) {
/* 112 */     Vector vector = checkedSubClassAndAssertScalar(exp);
/* 113 */     return vector.getElementAsByte(0);
/*     */   }
/*     */   
/*     */   public static float convertToFloatPrimitive(SEXP exp) {
/* 117 */     Vector vector = checkedSubClassAndAssertScalar(exp);
/* 118 */     return (float)vector.getElementAsDouble(0);
/*     */   }
/*     */   
/*     */   private static Vector checkedSubClassAndAssertScalar(SEXP exp) {
/* 122 */     if (exp.length() != 1) {
/* 123 */       throw new ArgumentException("expected vector of length 1");
/*     */     }
/* 125 */     if (!(exp instanceof Vector)) {
/* 126 */       throw new ArgumentException("expected vector of length 1");
/*     */     }
/* 128 */     return (Vector)exp;
/*     */   }
/*     */   
/*     */   public static <T> T unwrapExternal(SEXP exp) {
/*     */     try {
/* 133 */       ExternalPtr<T> external = (ExternalPtr<T>)exp;
/* 134 */       return (T)external.getInstance();
/* 135 */     } catch (ClassCastException e) {
/* 136 */       throw new ArgumentException("expected external object");
/*     */     } 
/*     */   }
/*     */   
/*     */   public static SEXP wrapResult(int i) {
/* 141 */     return (SEXP)new IntArrayVector(new int[] { i });
/*     */   }
/*     */   
/*     */   public static SEXP wrapResult(Integer i) {
/* 145 */     return (SEXP)new IntArrayVector(new int[] { (i == null) ? Integer.MIN_VALUE : i.intValue() });
/*     */   }
/*     */   
/*     */   public static SEXP wrapResult(String s) {
/* 149 */     return (SEXP)StringVector.valueOf(s);
/*     */   }
/*     */   
/*     */   public static SEXP wrapResult(boolean b) {
/* 153 */     return (SEXP)new LogicalArrayVector(new boolean[] { b });
/*     */   }
/*     */   
/*     */   public static SEXP wrapResult(float f) {
/* 157 */     return (SEXP)new DoubleArrayVector(new double[] { f });
/*     */   }
/*     */   
/*     */   public static SEXP wrapResult(double d) {
/* 161 */     return (SEXP)new DoubleArrayVector(new double[] { d });
/*     */   }
/*     */   
/*     */   public static SEXP wrapResult(long result) {
/* 165 */     return (SEXP)new DoubleArrayVector(new double[] { result });
/*     */   }
/*     */   
/*     */   public static SEXP wrapResult(int[] result) {
/* 169 */     return (SEXP)new IntArrayVector(result);
/*     */   }
/*     */   
/*     */   public static SEXP wrapResult(Logical result) {
/* 173 */     return (SEXP)new LogicalArrayVector(new Logical[] { result });
/*     */   }
/*     */   
/*     */   public static SEXP maybeConvertToStringVector(Context context, SEXP vector) {
/* 177 */     if (vector instanceof Symbol)
/* 178 */       return (SEXP)StringVector.valueOf(((Symbol)vector).getPrintName()); 
/* 179 */     if (vector instanceof FunctionCall) {
/* 180 */       return (SEXP)StringVector.valueOf(Deparse.deparseExp(context, vector));
/*     */     }
/* 182 */     return vector;
/*     */   }
/*     */   
/*     */   public static boolean isEmptyOrNull(SEXP vector) {
/* 186 */     if (vector instanceof Vector) {
/* 187 */       return (((Vector)vector).length() == 0);
/*     */     }
/* 189 */     return false;
/*     */   }
/*     */   
/*     */   public static boolean isEnvironmentOrEnvironmentSubclass(SEXP object) {
/* 193 */     if (object instanceof Environment) {
/* 194 */       return true;
/*     */     }
/* 196 */     if (object instanceof org.renjin.sexp.S4Object) {
/* 197 */       return object.getAttribute(Symbols.DOT_XDATA) instanceof Environment;
/*     */     }
/* 199 */     return false;
/*     */   }
/*     */   
/*     */   public static Environment unwrapEnvironmentSuperClass(SEXP object) {
/* 203 */     if (object instanceof Environment) {
/* 204 */       return (Environment)object;
/*     */     }
/* 206 */     if (object instanceof org.renjin.sexp.S4Object) {
/* 207 */       return (Environment)object.getAttribute(Symbols.DOT_XDATA);
/*     */     }
/* 209 */     throw new IllegalArgumentException();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/codegen/WrapperRuntime.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */