/*     */ package org.renjin.compiler.ir.tac.expressions;
/*     */ 
/*     */ import java.util.Map;
/*     */ import org.renjin.compiler.codegen.EmitContext;
/*     */ import org.renjin.compiler.ir.ValueBounds;
/*     */ import org.renjin.primitives.special.DollarFunction;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ import org.renjin.repackaged.asm.commons.InstructionAdapter;
/*     */ import org.renjin.sexp.ListVector;
/*     */ import org.renjin.sexp.PairList;
/*     */ import org.renjin.sexp.SEXP;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NamedElementAccess
/*     */   implements Expression
/*     */ {
/*     */   private Expression expression;
/*     */   private String memberName;
/*     */   private ValueBounds valueBounds;
/*     */   
/*     */   public NamedElementAccess(Expression expression, String memberName) {
/*  43 */     this.expression = expression;
/*  44 */     this.memberName = memberName;
/*     */     
/*  46 */     this.valueBounds = ValueBounds.UNBOUNDED;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPure() {
/*  51 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int load(EmitContext emitContext, InstructionAdapter mv) {
/*  56 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ValueBounds updateTypeBounds(Map<Expression, ValueBounds> typeMap) {
/*  62 */     ValueBounds argumentBounds = typeMap.get(this.expression);
/*  63 */     if (argumentBounds.isConstant()) {
/*     */ 
/*     */ 
/*     */       
/*  67 */       SEXP object = argumentBounds.getConstantValue();
/*  68 */       if (object instanceof ListVector) {
/*  69 */         this.valueBounds = ValueBounds.of(DollarFunction.fromList((ListVector)object, this.memberName));
/*  70 */       } else if (object instanceof PairList) {
/*  71 */         this.valueBounds = ValueBounds.of(DollarFunction.fromPairList((PairList)object, this.memberName));
/*     */       } 
/*     */     } 
/*     */     
/*  75 */     return this.valueBounds;
/*     */   }
/*     */ 
/*     */   
/*     */   public Type getType() {
/*  80 */     return this.valueBounds.storageType();
/*     */   }
/*     */ 
/*     */   
/*     */   public ValueBounds getValueBounds() {
/*  85 */     return this.valueBounds;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setChild(int childIndex, Expression child) {
/*  91 */     if (childIndex != 0) {
/*  92 */       throw new IllegalArgumentException("childIndex:" + childIndex);
/*     */     }
/*  94 */     this.expression = child;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getChildCount() {
/*  99 */     return 1;
/*     */   }
/*     */ 
/*     */   
/*     */   public Expression childAt(int index) {
/* 104 */     return this.expression;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 110 */     return this.expression + "$" + this.memberName;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/ir/tac/expressions/NamedElementAccess.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */