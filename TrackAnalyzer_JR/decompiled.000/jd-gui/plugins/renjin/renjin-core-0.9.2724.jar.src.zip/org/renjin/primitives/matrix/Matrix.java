/*     */ package org.renjin.primitives.matrix;
/*     */ 
/*     */ import org.renjin.primitives.Indexes;
/*     */ import org.renjin.sexp.Null;
/*     */ import org.renjin.sexp.Symbols;
/*     */ import org.renjin.sexp.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Matrix
/*     */ {
/*     */   private final Vector vector;
/*     */   private final int nrows;
/*     */   private final int ncols;
/*     */   
/*     */   public Matrix(Vector vector) {
/*  36 */     Vector dim = (Vector)vector.getAttribute(Symbols.DIM);
/*  37 */     if (dim.length() != 2) {
/*  38 */       throw new IllegalArgumentException("vector is not a matrix");
/*     */     }
/*  40 */     this.vector = vector;
/*  41 */     this.nrows = dim.getElementAsInt(0);
/*  42 */     this.ncols = dim.getElementAsInt(1);
/*     */   }
/*     */   
/*     */   public Matrix(Vector vector, int ncols) {
/*  46 */     this.vector = vector;
/*  47 */     this.ncols = ncols;
/*  48 */     this.nrows = vector.length() / ncols;
/*     */   }
/*     */   
/*     */   public Vector getVector() {
/*  52 */     return this.vector;
/*     */   }
/*     */   
/*     */   public int getNumRows() {
/*  56 */     return this.nrows;
/*     */   }
/*     */   
/*     */   public int getNumCols() {
/*  60 */     return this.ncols;
/*     */   }
/*     */   
/*     */   public Vector getRowNames() {
/*  64 */     return getDimNames(0);
/*     */   }
/*     */   
/*     */   public Vector getColNames() {
/*  68 */     return getDimNames(1);
/*     */   }
/*     */   
/*     */   public String getRowName(int rowIndex) {
/*  72 */     Vector rowNames = getRowNames();
/*  73 */     if (rowNames == Null.INSTANCE) {
/*  74 */       return null;
/*     */     }
/*  76 */     return rowNames.getElementAsString(rowIndex);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getColName(int colIndex) {
/*  81 */     Vector rowNames = getColNames();
/*  82 */     if (rowNames == Null.INSTANCE) {
/*  83 */       return null;
/*     */     }
/*  85 */     return rowNames.getElementAsString(colIndex);
/*     */   }
/*     */ 
/*     */   
/*     */   private Vector getDimNames(int dimensionIndex) {
/*  90 */     Vector dimNames = (Vector)this.vector.getAttribute(Symbols.DIMNAMES);
/*  91 */     if (dimNames.length() != 2) {
/*  92 */       return (Vector)Null.INSTANCE;
/*     */     }
/*  94 */     return (Vector)dimNames.getElementAsSEXP(dimensionIndex);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private int computeIndex(int row, int col) {
/* 100 */     return Indexes.matrixIndexToVectorIndex(row, col, this.nrows, this.ncols);
/*     */   }
/*     */   
/*     */   public int getElementAsInt(int row, int col) {
/* 104 */     return this.vector.getElementAsInt(computeIndex(row, col));
/*     */   }
/*     */   
/*     */   public double getElementAsDouble(int row, int col) {
/* 108 */     return this.vector.getElementAsDouble(computeIndex(row, col));
/*     */   }
/*     */   
/*     */   public MatrixBuilder newBuilder(int rows, int cols) {
/* 112 */     if (this.vector instanceof org.renjin.sexp.IntVector)
/* 113 */       return new IntMatrixBuilder(rows, cols); 
/* 114 */     if (this.vector instanceof org.renjin.sexp.DoubleVector) {
/* 115 */       return new DoubleMatrixBuilder(rows, cols);
/*     */     }
/* 117 */     throw new UnsupportedOperationException("unimplemented type " + this.vector.getTypeName());
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/matrix/Matrix.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */