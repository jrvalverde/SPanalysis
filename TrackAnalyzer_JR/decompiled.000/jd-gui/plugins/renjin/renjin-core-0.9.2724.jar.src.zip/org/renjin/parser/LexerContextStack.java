/*    */ package org.renjin.parser;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LexerContextStack
/*    */ {
/*    */   private static final int SIZE = 50;
/*    */   public static final char IF_BLOCK = 'i';
/*    */   
/*    */   public static class OverflowException
/*    */     extends RuntimeException {}
/*    */   
/* 30 */   private char[] stack = new char[50];
/*    */   
/*    */   private int currentIndex;
/*    */   
/*    */   void push(int i) {
/* 35 */     push((char)i);
/*    */   }
/*    */   
/*    */   void push(char c) {
/* 39 */     if (this.currentIndex >= 50) {
/* 40 */       throw new OverflowException();
/*    */     }
/* 42 */     this.currentIndex++;
/* 43 */     this.stack[this.currentIndex] = c;
/*    */   }
/*    */   
/*    */   void pop() {
/* 47 */     this.stack[this.currentIndex] = Character.MIN_VALUE;
/* 48 */     this.currentIndex--;
/*    */   }
/*    */   
/*    */   char peek() {
/* 52 */     return this.stack[this.currentIndex];
/*    */   }
/*    */   
/*    */   void ifPush() {
/* 56 */     if (peek() == '{' || 
/* 57 */       peek() == '[' || 
/* 58 */       peek() == '(' || 
/* 59 */       peek() == 'i') {
/* 60 */       push('i');
/*    */     }
/*    */   }
/*    */   
/*    */   void ifPop() {
/* 65 */     if (peek() == 'i') {
/* 66 */       this.stack[this.currentIndex] = Character.MIN_VALUE;
/* 67 */       this.currentIndex--;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/parser/LexerContextStack.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */