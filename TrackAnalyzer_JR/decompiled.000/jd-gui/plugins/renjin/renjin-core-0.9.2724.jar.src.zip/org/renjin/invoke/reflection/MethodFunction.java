/*    */ package org.renjin.invoke.reflection;
/*    */ 
/*    */ import org.renjin.eval.Context;
/*    */ import org.renjin.sexp.AbstractSEXP;
/*    */ import org.renjin.sexp.Environment;
/*    */ import org.renjin.sexp.Function;
/*    */ import org.renjin.sexp.FunctionCall;
/*    */ import org.renjin.sexp.PairList;
/*    */ import org.renjin.sexp.SEXP;
/*    */ import org.renjin.sexp.SexpVisitor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MethodFunction
/*    */   extends AbstractSEXP
/*    */   implements Function
/*    */ {
/*    */   private final String name;
/*    */   private final Object instance;
/*    */   private final FunctionBinding functionBinding;
/*    */   
/*    */   public MethodFunction(Object instance, FunctionBinding functionBinding) {
/* 36 */     this.instance = instance;
/* 37 */     this.functionBinding = functionBinding;
/* 38 */     this.name = functionBinding.getName();
/*    */   }
/*    */   
/*    */   public String getName() {
/* 42 */     return this.name;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getTypeName() {
/* 47 */     return "method";
/*    */   }
/*    */ 
/*    */   
/*    */   public void accept(SexpVisitor visitor) {
/* 52 */     throw new UnsupportedOperationException("nyi");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public SEXP apply(Context context, Environment rho, FunctionCall call, PairList args) {
/* 58 */     return this.functionBinding.evaluateArgsAndInvoke(this.instance, context, rho, args);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Object getInstance() {
/* 67 */     return this.instance;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isStatic() {
/* 75 */     return (this.instance == null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public FunctionBinding getFunctionBinding() {
/* 82 */     return this.functionBinding;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 87 */     return this.functionBinding.getDeclaringClass().getName() + ":" + this.functionBinding.toString();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/reflection/MethodFunction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */