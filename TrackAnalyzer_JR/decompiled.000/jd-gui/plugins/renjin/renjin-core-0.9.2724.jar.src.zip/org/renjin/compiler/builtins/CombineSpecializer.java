/*     */ package org.renjin.compiler.builtins;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.renjin.compiler.codegen.EmitContext;
/*     */ import org.renjin.compiler.codegen.VectorGen;
/*     */ import org.renjin.compiler.ir.ValueBounds;
/*     */ import org.renjin.compiler.ir.tac.IRArgument;
/*     */ import org.renjin.compiler.ir.tac.RuntimeState;
/*     */ import org.renjin.compiler.ir.tac.expressions.Expression;
/*     */ import org.renjin.primitives.combine.Combine;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ import org.renjin.repackaged.asm.commons.InstructionAdapter;
/*     */ import org.renjin.sexp.ListVector;
/*     */ import org.renjin.sexp.SEXP;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CombineSpecializer
/*     */   implements Specializer, BuiltinSpecializer
/*     */ {
/*     */   public String getName() {
/*  44 */     return "c";
/*     */   }
/*     */ 
/*     */   
/*     */   public String getGroup() {
/*  49 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Specialization trySpecialize(RuntimeState runtimeState, List<ArgumentBounds> arguments) {
/*  55 */     SEXP constantResult = tryCombine(arguments);
/*  56 */     if (constantResult != null) {
/*  57 */       return new ConstantCall(constantResult);
/*     */     }
/*     */     
/*  60 */     if (allArgumentsArePrimitives(arguments)) {
/*  61 */       return new CombinePrimitives(arguments);
/*     */     }
/*     */     
/*  64 */     return UnspecializedCall.PURE;
/*     */   }
/*     */   
/*     */   private SEXP tryCombine(List<ArgumentBounds> arguments) {
/*  68 */     ListVector.NamedBuilder constants = ListVector.newNamedBuilder();
/*  69 */     for (ArgumentBounds argument : arguments) {
/*  70 */       if (argument.getBounds().isConstant()) {
/*  71 */         constants.add(argument.getName(), argument.getBounds().getConstantValue()); continue;
/*     */       } 
/*  73 */       return null;
/*     */     } 
/*     */ 
/*     */     
/*  77 */     return Combine.c(constants.build(), false);
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean allArgumentsArePrimitives(List<ArgumentBounds> arguments) {
/*  82 */     for (ArgumentBounds argument : arguments) {
/*  83 */       if (argument.getName() != null) {
/*  84 */         return false;
/*     */       }
/*  86 */       if ((argument.getBounds().getTypeSet() & 0xFFFFFE03) != 0) {
/*  87 */         return false;
/*     */       }
/*     */     } 
/*  90 */     return true;
/*     */   }
/*     */   
/*     */   private boolean allAreConstant(List<ValueBounds> argumentBounds) {
/*  94 */     for (ValueBounds argumentBound : argumentBounds) {
/*  95 */       if (!argumentBound.isConstant()) {
/*  96 */         return false;
/*     */       }
/*     */     } 
/*  99 */     return true;
/*     */   }
/*     */   
/*     */   private static class CombinePrimitives
/*     */     implements Specialization {
/*     */     private final ValueBounds bounds;
/*     */     
/*     */     public CombinePrimitives(List<ArgumentBounds> argumentBounds) {
/* 107 */       int length = 0;
/* 108 */       int typeSet = 4;
/* 109 */       for (ArgumentBounds argumentBound : argumentBounds) {
/* 110 */         typeSet = Math.max(typeSet, argumentBound.getBounds().getTypeSet());
/* 111 */         length++;
/*     */       } 
/* 113 */       this
/*     */ 
/*     */ 
/*     */         
/* 117 */         .bounds = ValueBounds.builder().setLength(length).setTypeSet(typeSet).setEmptyAttributes().build();
/*     */     }
/*     */ 
/*     */     
/*     */     public Type getType() {
/* 122 */       return this.bounds.storageType();
/*     */     }
/*     */ 
/*     */     
/*     */     public ValueBounds getResultBounds() {
/* 127 */       return this.bounds;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void load(EmitContext emitContext, InstructionAdapter mv, List<IRArgument> arguments) {
/* 133 */       VectorGen vectorType = VectorGen.forType(this.bounds.getTypeSet());
/*     */       
/* 135 */       int length = this.bounds.getLength();
/*     */       
/* 137 */       mv.iconst(length);
/* 138 */       mv.newarray(vectorType.getElementType());
/* 139 */       mv.dup();
/*     */       
/* 141 */       for (int i = 0; i < length; i++) {
/* 142 */         mv.iconst(i);
/* 143 */         Expression expression = ((IRArgument)arguments.get(0)).getExpression();
/* 144 */         expression.load(emitContext, mv);
/* 145 */         emitContext.convert(mv, expression.getType(), vectorType.getElementType());
/* 146 */         mv.astore(vectorType.getElementType());
/*     */       } 
/*     */       
/* 149 */       mv.invokestatic(vectorType.getVectorArrayType().getInternalName(), "unsafe", 
/* 150 */           Type.getMethodDescriptor(vectorType.getVectorArrayType(), new Type[] { vectorType.getArrayType() }), false);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isPure() {
/* 157 */       return true;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/builtins/CombineSpecializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */