/*     */ package org.renjin.primitives.io.connections;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.Deque;
/*     */ import org.renjin.eval.EvalException;
/*     */ import org.renjin.repackaged.guava.base.Preconditions;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StdOutConnection
/*     */   implements Connection
/*     */ {
/*     */   private PrintWriter stream;
/*  45 */   private Deque<Sink> sinkStack = new ArrayDeque<>();
/*     */ 
/*     */   
/*     */   public StdOutConnection() {
/*  49 */     this.stream = new PrintWriter(System.out);
/*     */   }
/*     */   
/*     */   public void setStream(PrintWriter stream) {
/*  53 */     this.stream = stream;
/*     */   }
/*     */   
/*     */   public PrintWriter getStream() {
/*  57 */     return this.stream;
/*     */   }
/*     */ 
/*     */   
/*     */   public InputStream getInputStream() throws IOException {
/*  62 */     throw new EvalException("cannot read from stdout", new Object[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   public PushbackBufferedReader getReader() throws IOException {
/*  67 */     throw new EvalException("cannot read from stdout", new Object[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PrintWriter getPrintWriter() {
/*  77 */     return getOpenPrintWriter();
/*     */   }
/*     */ 
/*     */   
/*     */   public PrintWriter getOpenPrintWriter() {
/*  82 */     if (this.sinkStack.isEmpty()) {
/*  83 */       return this.stream;
/*     */     }
/*  85 */     return ((Sink)this.sinkStack.peek()).getPrintWriter(this.stream);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {}
/*     */ 
/*     */ 
/*     */   
/*     */   public OutputStream getOutputStream() throws IOException {
/*  96 */     throw new EvalException("Cannot open stdout for binary output, only text (todo?)", new Object[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isOpen() {
/* 101 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void open(OpenSpec spec) throws IOException {}
/*     */ 
/*     */   
/*     */   public void flush() throws IOException {
/* 110 */     this.stream.flush();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSinkStackHeight() {
/* 117 */     return this.sinkStack.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getClassName() {
/* 122 */     return "terminal";
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDescription() {
/* 127 */     return "stdout";
/*     */   }
/*     */ 
/*     */   
/*     */   public String getMode() {
/* 132 */     return "w";
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canRead() {
/* 137 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canWrite() {
/* 142 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public Connection.Type getType() {
/* 147 */     return Connection.Type.TEXT;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void sink(Sink sink) throws IOException {
/* 155 */     Preconditions.checkNotNull(sink, "sink");
/* 156 */     this.sinkStack.push(sink);
/*     */   }
/*     */   
/*     */   Sink clearSink() throws IOException {
/* 160 */     if (!this.sinkStack.isEmpty()) {
/* 161 */       return this.sinkStack.pop();
/*     */     }
/* 163 */     return null;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/io/connections/StdOutConnection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */