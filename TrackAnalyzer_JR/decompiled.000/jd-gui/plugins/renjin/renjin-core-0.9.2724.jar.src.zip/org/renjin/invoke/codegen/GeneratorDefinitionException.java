/*    */ package org.renjin.invoke.codegen;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GeneratorDefinitionException
/*    */   extends RuntimeException
/*    */ {
/*    */   public GeneratorDefinitionException() {}
/*    */   
/*    */   public GeneratorDefinitionException(String message, Throwable cause) {
/* 35 */     super(message, cause);
/*    */   }
/*    */   
/*    */   public GeneratorDefinitionException(String message) {
/* 39 */     super(message);
/*    */   }
/*    */   
/*    */   public GeneratorDefinitionException(Throwable cause) {
/* 43 */     super(cause);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/codegen/GeneratorDefinitionException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */