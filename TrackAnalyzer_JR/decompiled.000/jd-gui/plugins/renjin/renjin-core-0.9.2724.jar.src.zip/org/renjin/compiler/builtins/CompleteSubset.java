/*    */ package org.renjin.compiler.builtins;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.renjin.compiler.codegen.EmitContext;
/*    */ import org.renjin.compiler.ir.ValueBounds;
/*    */ import org.renjin.compiler.ir.tac.IRArgument;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ import org.renjin.repackaged.asm.commons.InstructionAdapter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompleteSubset
/*    */   implements Specialization
/*    */ {
/*    */   private ValueBounds sourceBounds;
/*    */   
/*    */   public CompleteSubset(ValueBounds sourceBounds) {
/* 34 */     this.sourceBounds = sourceBounds;
/*    */   }
/*    */ 
/*    */   
/*    */   public Type getType() {
/* 39 */     return this.sourceBounds.storageType();
/*    */   }
/*    */   
/*    */   public ValueBounds getResultBounds() {
/* 43 */     return this.sourceBounds;
/*    */   }
/*    */ 
/*    */   
/*    */   public void load(EmitContext emitContext, InstructionAdapter mv, List<IRArgument> arguments) {
/* 48 */     ((IRArgument)arguments.get(0)).getExpression().load(emitContext, mv);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isPure() {
/* 53 */     return true;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/builtins/CompleteSubset.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */