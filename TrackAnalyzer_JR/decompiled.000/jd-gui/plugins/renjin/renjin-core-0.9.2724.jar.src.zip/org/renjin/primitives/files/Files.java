/*     */ package org.renjin.primitives.files;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import java.util.function.Predicate;
/*     */ import java.util.zip.ZipEntry;
/*     */ import java.util.zip.ZipInputStream;
/*     */ import org.apache.commons.vfs2.AllFileSelector;
/*     */ import org.apache.commons.vfs2.FileObject;
/*     */ import org.apache.commons.vfs2.FileSelectInfo;
/*     */ import org.apache.commons.vfs2.FileSelector;
/*     */ import org.apache.commons.vfs2.FileSystemException;
/*     */ import org.apache.commons.vfs2.FileType;
/*     */ import org.renjin.eval.Context;
/*     */ import org.renjin.eval.EvalException;
/*     */ import org.renjin.invoke.annotations.Current;
/*     */ import org.renjin.invoke.annotations.DataParallel;
/*     */ import org.renjin.invoke.annotations.Internal;
/*     */ import org.renjin.invoke.annotations.Invisible;
/*     */ import org.renjin.invoke.annotations.PreserveAttributeStyle;
/*     */ import org.renjin.invoke.annotations.Recycle;
/*     */ import org.renjin.primitives.text.regex.ExtendedRE;
/*     */ import org.renjin.primitives.text.regex.REFactory;
/*     */ import org.renjin.primitives.text.regex.RESyntaxException;
/*     */ import org.renjin.repackaged.guava.base.Strings;
/*     */ import org.renjin.repackaged.guava.collect.Lists;
/*     */ import org.renjin.repackaged.guava.io.ByteStreams;
/*     */ import org.renjin.sexp.AtomicVector;
/*     */ import org.renjin.sexp.AttributeMap;
/*     */ import org.renjin.sexp.DoubleArrayVector;
/*     */ import org.renjin.sexp.IntArrayVector;
/*     */ import org.renjin.sexp.IntVector;
/*     */ import org.renjin.sexp.ListVector;
/*     */ import org.renjin.sexp.LogicalArrayVector;
/*     */ import org.renjin.sexp.LogicalVector;
/*     */ import org.renjin.sexp.Null;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.StringArrayVector;
/*     */ import org.renjin.sexp.StringVector;
/*     */ import org.renjin.sexp.Symbols;
/*     */ import org.renjin.sexp.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Files
/*     */ {
/*     */   public static final int CHECK_ACCESS_EXISTENCE = 0;
/*     */   public static final int CHECK_ACCESS_EXECUTE = 1;
/*     */   public static final int CHECK_ACCESS_WRITE = 2;
/*     */   public static final int CHECK_ACCESS_READ = 3;
/*     */   
/*     */   @DataParallel
/*     */   @Internal("path.expand")
/*     */   public static String pathExpand(String path) {
/*  66 */     if (path.length() < 2 || path.charAt(0) != '~' || Character.isAlphabetic(path.charAt(1))) {
/*  67 */       return path;
/*     */     }
/*  69 */     String home = System.getenv("R_USER");
/*  70 */     if (home == null) {
/*  71 */       home = System.getProperty("user.home");
/*     */     }
/*  73 */     if (home == null) {
/*  74 */       return path;
/*     */     }
/*  76 */     return home + path.substring(1);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Internal("file.access")
/*     */   public static IntVector fileAccess(@Current Context context, StringVector names, int mode) throws FileSystemException {
/*  83 */     IntArrayVector.Builder result = new IntArrayVector.Builder();
/*  84 */     for (String name : names) {
/*  85 */       FileObject file = context.resolveFile(pathExpand(name));
/*  86 */       result.add(checkAccess(file, mode));
/*     */     } 
/*  88 */     result.setAttribute(Symbols.NAMES, (SEXP)new StringArrayVector(names.toArray()));
/*  89 */     return result.build();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static int checkAccess(FileObject file, int mode) throws FileSystemException {
/*  95 */     boolean ok = true;
/*  96 */     if ((mode & 0x0) != 0 && !file.exists()) {
/*  97 */       ok = false;
/*     */     }
/*     */     
/* 100 */     if ((mode & 0x3) != 0 && !file.isReadable()) {
/* 101 */       ok = false;
/*     */     }
/*     */     
/* 104 */     if (((((mode & 0x2) != 0) ? 1 : 0) & (!file.isWriteable() ? 1 : 0)) != 0) {
/* 105 */       ok = false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 111 */     return ok ? 0 : -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Internal("file.info")
/*     */   public static ListVector fileInfo(@Current Context context, StringVector paths) throws FileSystemException {
/* 125 */     DoubleArrayVector.Builder size = new DoubleArrayVector.Builder();
/* 126 */     LogicalArrayVector.Builder isdir = new LogicalArrayVector.Builder();
/*     */     
/* 128 */     IntArrayVector.Builder mode = (new IntArrayVector.Builder()).setAttribute(Symbols.CLASS, (SEXP)StringVector.valueOf("octmode"));
/* 129 */     DoubleArrayVector.Builder mtime = new DoubleArrayVector.Builder();
/* 130 */     StringVector.Builder exe = new StringVector.Builder();
/*     */     
/* 132 */     for (String path : paths) {
/* 133 */       if (StringVector.isNA(path)) {
/* 134 */         throw new EvalException("invalid filename argument", new Object[0]);
/*     */       }
/* 136 */       FileObject file = context.resolveFile(path);
/* 137 */       if (file.exists()) {
/* 138 */         if (file.getType() == FileType.FILE) {
/* 139 */           size.add((int)file.getContent().getSize());
/*     */         } else {
/* 141 */           size.add(0.0D);
/*     */         } 
/* 143 */         isdir.add((file.getType() == FileType.FOLDER));
/* 144 */         mode.add(mode(file));
/*     */         try {
/* 146 */           mtime.add(file.getContent().getLastModifiedTime());
/* 147 */         } catch (Exception e) {
/* 148 */           mtime.add(0.0D);
/*     */         } 
/* 150 */         exe.add(file.getName().getBaseName().endsWith(".exe") ? "yes" : "no"); continue;
/*     */       } 
/* 152 */       size.addNA();
/* 153 */       isdir.addNA();
/* 154 */       mode.addNA();
/* 155 */       mtime.addNA();
/* 156 */       exe.addNA();
/*     */     } 
/*     */ 
/*     */     
/* 160 */     return ListVector.newNamedBuilder()
/* 161 */       .add("size", (Vector.Builder)size)
/* 162 */       .add("isdir", (Vector.Builder)isdir)
/* 163 */       .add("mode", (Vector.Builder)mode)
/* 164 */       .add("mtime", (Vector.Builder)mtime)
/* 165 */       .add("ctime", (Vector.Builder)mtime)
/* 166 */       .add("atime", (Vector.Builder)mtime)
/* 167 */       .add("exe", (Vector.Builder)exe)
/* 168 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Internal
/*     */   @DataParallel
/*     */   public static String normalizePath(@Current Context context, @Recycle String path, String winSlash, SEXP mustWork) {
/* 184 */     boolean errorIfInvalid = false;
/* 185 */     boolean warningIfInvalid = false;
/*     */     
/* 187 */     if (mustWork instanceof AtomicVector && mustWork.length() >= 1) {
/* 188 */       errorIfInvalid = ((AtomicVector)mustWork).isElementTrue(0);
/* 189 */       warningIfInvalid = ((AtomicVector)mustWork).isElementNA(0);
/*     */     } 
/*     */     
/*     */     try {
/* 193 */       return friendlyFileName(context.resolveFile(path));
/* 194 */     } catch (FileSystemException e) {
/* 195 */       if (errorIfInvalid) {
/* 196 */         throw new EvalException(e.getMessage(), new Object[0]);
/*     */       }
/* 198 */       if (warningIfInvalid) {
/* 199 */         context.warn(e.getMessage());
/*     */       }
/* 201 */       return path;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int mode(FileObject file) throws FileSystemException {
/* 211 */     int access = 0;
/* 212 */     if (file.isReadable()) {
/* 213 */       access += 4;
/*     */     }
/*     */     
/* 216 */     if (file.isWriteable()) {
/* 217 */       access += 2;
/*     */     }
/* 219 */     if (file.getType() == FileType.FOLDER) {
/* 220 */       access++;
/*     */     }
/*     */ 
/*     */     
/* 224 */     String digit = Integer.toString(access);
/* 225 */     String octalString = digit + digit + digit;
/*     */     
/* 227 */     return Integer.parseInt(octalString, 8);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Internal("file.exists")
/*     */   @DataParallel(value = PreserveAttributeStyle.NONE, passNA = true)
/*     */   public static boolean fileExists(@Current Context context, String path) throws FileSystemException {
/* 241 */     if (path == null) {
/* 242 */       return false;
/*     */     }
/* 244 */     return context.resolveFile(path).exists();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Internal
/*     */   @DataParallel
/*     */   public static String basename(String path) {
/* 261 */     for (int i = path.length() - 1; i >= 0; i--) {
/* 262 */       if (path.charAt(i) == '\\' || path.charAt(i) == '/') {
/* 263 */         return path.substring(i + 1);
/*     */       }
/*     */     } 
/* 266 */     return path;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Internal("Sys.glob")
/*     */   public static StringVector glob(@Current Context context, StringVector paths, boolean markDirectories) {
/* 284 */     List<String> matching = Lists.newArrayList();
/* 285 */     for (String path : paths) {
/* 286 */       if (path != null) {
/* 287 */         if (path.indexOf('*') == -1) {
/* 288 */           matching.add(path); continue;
/*     */         } 
/* 290 */         matching.addAll(FileScanner.scan(context, path, markDirectories));
/*     */       } 
/*     */     } 
/*     */     
/* 294 */     return (StringVector)new StringArrayVector(matching);
/*     */   }
/*     */   
/*     */   private static boolean isWindows() {
/* 298 */     String operatingSystem = Strings.nullToEmpty(System.getProperty("os.name")).toLowerCase();
/* 299 */     return operatingSystem.contains("win");
/*     */   }
/*     */ 
/*     */   
/*     */   @Internal("Sys.which")
/*     */   public static StringVector sysWhich(@Current Context context, StringVector names) {
/* 305 */     if (isWindows()) {
/* 306 */       throw new EvalException("Sys.which() not implemented for Windows", new Object[0]);
/*     */     }
/*     */     
/* 309 */     String[] path = Strings.nullToEmpty(System.getenv("PATH")).split(File.pathSeparator);
/*     */     
/* 311 */     StringVector.Builder result = new StringVector.Builder(0, names.length());
/* 312 */     result.setAttribute(Symbols.NAMES, names.setAttributes(AttributeMap.EMPTY));
/*     */     
/* 314 */     for (String name : names) {
/* 315 */       result.add(findExecutable(context, path, name));
/*     */     }
/*     */     
/* 318 */     return (StringVector)result.build();
/*     */   }
/*     */   
/*     */   private static String findExecutable(Context context, String[] paths, String name) {
/* 322 */     if (isAbsolutePath(name)) {
/* 323 */       return executablePath(context, name);
/*     */     }
/* 325 */     for (String path : paths) {
/* 326 */       String executablePath = executablePath(context, path + File.separator + name);
/* 327 */       if (!executablePath.isEmpty()) {
/* 328 */         return executablePath;
/*     */       }
/*     */     } 
/*     */     
/* 332 */     return "";
/*     */   }
/*     */   
/*     */   private static String executablePath(Context context, String name) {
/*     */     try {
/* 337 */       FileObject fileObject = context.resolveFile(name);
/* 338 */       if (fileObject.exists()) {
/* 339 */         return friendlyFileName(fileObject);
/*     */       }
/* 341 */       return "";
/*     */     }
/* 343 */     catch (FileSystemException e) {
/* 344 */       return "";
/*     */     } 
/*     */   }
/*     */   
/*     */   private static boolean isAbsolutePath(String name) {
/* 349 */     File file = new File(name);
/* 350 */     return file.isAbsolute();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Internal
/*     */   @DataParallel
/*     */   public static String dirname(String path) {
/* 364 */     for (int i = path.length() - 1; i >= 0; i--) {
/* 365 */       if (path.charAt(i) == '\\' || path.charAt(i) == '/') {
/* 366 */         return path.substring(0, i);
/*     */       }
/*     */     } 
/* 369 */     return ".";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Internal("dir.create")
/*     */   public static SEXP dirCreate(@Current Context context, String path, boolean showWarnings, boolean recursive, int mode) throws FileSystemException {
/* 389 */     FileObject dir = context.resolveFile(path);
/* 390 */     dir.createFolder();
/*     */ 
/*     */ 
/*     */     
/* 394 */     context.setInvisibleFlag();
/* 395 */     return (SEXP)new LogicalArrayVector(new boolean[] { true });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @DataParallel(value = PreserveAttributeStyle.NONE, passNA = true)
/*     */   @Internal("dir.exists")
/*     */   public static boolean dirExists(@Current Context context, String uri) throws FileSystemException {
/* 412 */     if (uri == null) {
/* 413 */       return false;
/*     */     }
/*     */     
/* 416 */     FileObject fileObject = context.resolveFile(uri);
/* 417 */     return (fileObject.exists() && fileObject.getType() == FileType.FOLDER);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Internal("list.files")
/*     */   public static StringVector listFiles(@Current final Context context, final StringVector paths, final String pattern, final boolean allFiles, final boolean fullNames, final boolean recursive, final boolean ignoreCase, final boolean includeDirs) throws IOException {
/* 449 */     return (new Object()
/*     */       {
/* 451 */         private final List<String> result = new ArrayList<>();
/*     */         
/*     */         private Predicate<String> nameFilter;
/*     */ 
/*     */         
/*     */         public StringVector list() throws IOException {
/* 457 */           if (pattern == null) {
/* 458 */             this.nameFilter = (x -> true);
/*     */           } else {
/*     */             try {
/* 461 */               this.nameFilter = REFactory.asPredicate((new ExtendedRE(pattern)).ignoreCase(ignoreCase));
/* 462 */             } catch (RESyntaxException e) {
/* 463 */               throw new EvalException("Invalid pattern '%s': %s", new Object[] { this.val$pattern, e.getMessage() });
/*     */             } 
/*     */           } 
/*     */           
/* 467 */           for (String path : paths) {
/* 468 */             FileObject folder = context.resolveFile(path);
/* 469 */             if (folder.getType() == FileType.FOLDER) {
/*     */               String rootPrefix;
/* 471 */               if (fullNames) {
/* 472 */                 rootPrefix = folder.getName().getPath();
/*     */               } else {
/* 474 */                 rootPrefix = "";
/*     */               } 
/* 476 */               list(rootPrefix, folder);
/*     */             } 
/*     */           } 
/* 479 */           Collections.sort(this.result);
/* 480 */           return (StringVector)new StringArrayVector(this.result);
/*     */         }
/*     */         
/*     */         private void list(String path, FileObject folder) throws FileSystemException {
/* 484 */           if (allFiles && !recursive) {
/* 485 */             if (this.nameFilter.test(".")) {
/* 486 */               add(path, ".");
/*     */             }
/* 488 */             if (this.nameFilter.test("..")) {
/* 489 */               add(path, "..");
/*     */             }
/*     */           } 
/* 492 */           for (FileObject child : folder.getChildren()) {
/* 493 */             if (filter(child)) {
/* 494 */               add(path, child);
/*     */             }
/* 496 */             if (recursive && child.getType() == FileType.FOLDER) {
/* 497 */               list(qualify(path, child.getName().getBaseName()), child);
/*     */             }
/*     */           } 
/*     */         }
/*     */         
/*     */         void add(String path, FileObject file) throws FileSystemException {
/* 503 */           add(path, file.getName().getBaseName());
/*     */         }
/*     */         
/*     */         void add(String path, String name) throws FileSystemException {
/* 507 */           this.result.add(qualify(path, name));
/*     */         }
/*     */         
/*     */         private String qualify(String path, String filename) {
/* 511 */           if (path.length() > 0) {
/* 512 */             return path + "/" + filename;
/*     */           }
/* 514 */           return filename;
/*     */         }
/*     */ 
/*     */         
/*     */         boolean filter(FileObject child) throws FileSystemException {
/* 519 */           if (!allFiles && isHidden(child)) {
/* 520 */             return false;
/*     */           }
/* 522 */           if (recursive && !includeDirs && child.getType() == FileType.FOLDER) {
/* 523 */             return false;
/*     */           }
/* 525 */           if (!this.nameFilter.test(child.getName().getBaseName())) {
/* 526 */             return false;
/*     */           }
/* 528 */           return true;
/*     */         }
/*     */         
/*     */         private boolean isHidden(FileObject file) throws FileSystemException {
/* 532 */           return (file.isHidden() || file.getName().getBaseName().startsWith("."));
/*     */         }
/* 534 */       }).list();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Internal
/*     */   public static String tempdir() {
/* 551 */     return System.getProperty("java.io.tmpdir");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Internal
/*     */   @DataParallel
/*     */   public static String tempfile(String pattern, String tempdir, String fileExt) {
/* 574 */     return tempdir + "/" + pattern + createRandomHexString(10) + fileExt;
/*     */   }
/*     */ 
/*     */   
/*     */   private static String createRandomHexString(int length) {
/* 579 */     Random randomService = new Random();
/* 580 */     String sb = "";
/* 581 */     while (sb.length() < length) {
/* 582 */       sb = sb + Integer.toHexString(randomService.nextInt());
/*     */     }
/* 584 */     return sb;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Internal
/*     */   public static String getwd(@Current Context context) {
/* 600 */     return friendlyFileName(context.getSession().getWorkingDirectory());
/*     */   }
/*     */   
/*     */   @Invisible
/*     */   @Internal
/*     */   public static String setwd(@Current Context context, String workingDirectoryName) throws FileSystemException {
/* 606 */     FileObject newWorkingDirectory = context.resolveFile(workingDirectoryName);
/* 607 */     if (!newWorkingDirectory.exists() || newWorkingDirectory
/* 608 */       .getType() != FileType.FOLDER) {
/* 609 */       throw new EvalException("cannot change working directory", new Object[0]);
/*     */     }
/*     */     
/* 612 */     String previous = friendlyFileName(context.getSession().getWorkingDirectory());
/*     */     
/* 614 */     context.getSession().setWorkingDirectory(newWorkingDirectory);
/* 615 */     return previous;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Internal
/*     */   public static IntVector unlink(@Current Context context, StringVector paths, boolean recursive, boolean force) throws FileSystemException {
/* 630 */     IntArrayVector.Builder result = new IntArrayVector.Builder();
/* 631 */     for (String path : paths) {
/* 632 */       if (StringVector.isNA(path)) {
/* 633 */         result.add(0); continue;
/*     */       } 
/* 635 */       FileObject file = context.resolveFile(path);
/* 636 */       delete(file, recursive);
/* 637 */       result.add(1);
/*     */     } 
/*     */     
/* 640 */     return result.build();
/*     */   }
/*     */   
/*     */   @Internal("local.file")
/*     */   public static StringVector localFile(@Current Context context, StringVector uris) throws IOException {
/* 645 */     StringVector.Builder localFiles = new StringVector.Builder(0, uris.length());
/*     */     
/* 647 */     for (String uri : uris) {
/* 648 */       FileObject fileObject = context.resolveFile(uri);
/* 649 */       File localFile = fileObject.getFileSystem().replicateFile(fileObject, (FileSelector)new AllFileSelector());
/*     */       
/* 651 */       localFiles.add(localFile.getAbsolutePath());
/*     */     } 
/*     */     
/* 654 */     return (StringVector)localFiles.build();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static void delete(FileObject file, boolean recursive) throws FileSystemException {
/* 660 */     if (file.exists()) {
/* 661 */       if (file.getType() == FileType.FILE) {
/* 662 */         file.delete();
/* 663 */       } else if (file.getType() == FileType.FOLDER) {
/* 664 */         if ((file.getChildren()).length == 0) {
/* 665 */           file.delete();
/* 666 */         } else if (recursive) {
/* 667 */           file.delete((FileSelector)new AllFileSelector());
/* 668 */           file.delete();
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   @Internal("file.copy")
/*     */   public static LogicalVector fileCopy(@Current Context context, StringVector fromFiles, String to, boolean overwrite, final boolean recursive) throws FileSystemException {
/* 676 */     LogicalArrayVector.Builder result = new LogicalArrayVector.Builder();
/* 677 */     FileObject toFile = context.resolveFile(to);
/* 678 */     for (String from : fromFiles) {
/*     */       try {
/* 680 */         toFile.copyFrom(context.resolveFile(from), new FileSelector()
/*     */             {
/*     */               public boolean traverseDescendents(FileSelectInfo fileInfo) throws Exception
/*     */               {
/* 684 */                 return true;
/*     */               }
/*     */ 
/*     */               
/*     */               public boolean includeFile(FileSelectInfo fileInfo) throws Exception {
/* 689 */                 return recursive;
/*     */               }
/*     */             });
/* 692 */         result.add(true);
/* 693 */       } catch (FileSystemException e) {
/* 694 */         result.add(false);
/*     */       } 
/*     */     } 
/* 697 */     return result.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Internal("file.rename")
/*     */   public static LogicalVector fileRename(@Current Context context, StringVector fromFiles, StringVector toFiles) throws FileSystemException {
/* 705 */     if (toFiles.length() != fromFiles.length()) {
/* 706 */       throw new EvalException("'from' and 'to' are of different lengths", new Object[0]);
/*     */     }
/*     */     
/* 709 */     LogicalArrayVector.Builder result = new LogicalArrayVector.Builder();
/*     */     
/* 711 */     for (int i = 0; i < fromFiles.length(); i++) {
/* 712 */       boolean succeeded = renameFile(context, fromFiles.getElementAsString(i), toFiles.getElementAsString(i));
/* 713 */       result.add(succeeded);
/*     */     } 
/* 715 */     return result.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean renameFile(@Current Context context, String fromUri, String toUri) {
/*     */     try {
/* 724 */       FileObject from = context.resolveFile(fromUri);
/* 725 */       if (!from.exists()) {
/* 726 */         throw new FileSystemException("No such file or directory");
/*     */       }
/*     */       
/* 729 */       FileObject to = context.resolveFile(toUri);
/*     */       
/* 731 */       if (!from.canRenameTo(to)) {
/* 732 */         throw new FileSystemException("rename not supported");
/*     */       }
/*     */ 
/*     */       
/* 736 */       from.moveTo(to);
/*     */       
/* 738 */       return true;
/*     */     }
/* 740 */     catch (FileSystemException e) {
/* 741 */       context.warn(String.format("cannot rename file '%s' to '%s', reason: '%s'", new Object[] { fromUri, toUri, e.getMessage() }));
/* 742 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Internal("file.remove")
/*     */   public static LogicalVector fileRemove(@Current Context context, StringVector files) throws FileSystemException {
/* 751 */     LogicalArrayVector.Builder result = new LogicalArrayVector.Builder();
/*     */     
/* 753 */     for (int i = 0; i < files.length(); i++) {
/* 754 */       boolean succeeded = removeFile(context, files.getElementAsString(i));
/* 755 */       result.add(succeeded);
/*     */     } 
/* 757 */     return result.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean removeFile(@Current Context context, String file) {
/*     */     try {
/* 765 */       FileObject fileObject = context.resolveFile(file);
/* 766 */       if (!fileObject.exists()) {
/* 767 */         throw new FileSystemException("No such file or directory");
/*     */       }
/*     */       
/* 770 */       return fileObject.delete();
/* 771 */     } catch (FileSystemException e) {
/* 772 */       context.warn(String.format("cannot remove file '%s', reason: '%s'", new Object[] { file, e.getMessage() }));
/* 773 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Internal
/*     */   public static SEXP unzip(@Current Context context, String zipFile, Vector files, String exdirUri, boolean list, boolean overwrite, boolean junkpaths) throws IOException {
/* 797 */     ZipInputStream zin = new ZipInputStream(context.resolveFile(pathExpand(zipFile)).getContent().getInputStream());
/*     */     try {
/* 799 */       FileObject exdir = context.resolveFile(exdirUri);
/*     */       
/* 801 */       if (list) {
/* 802 */         throw new EvalException("unzip(list=true) not yet implemented", new Object[0]);
/*     */       }
/*     */       
/*     */       ZipEntry entry;
/* 806 */       while ((entry = zin.getNextEntry()) != null) {
/* 807 */         if (unzipMatches(entry, files)) {
/* 808 */           unzipExtract(zin, entry, exdir, junkpaths, overwrite);
/*     */         }
/*     */       } 
/* 811 */       context.setInvisibleFlag();
/*     */       
/* 813 */       return (SEXP)new IntArrayVector(new int[] { 0 });
/*     */     } finally {
/* 815 */       zin.close();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void unzipExtract(ZipInputStream zin, ZipEntry entry, FileObject exdir, boolean junkpaths, boolean overwrite) throws IOException {
/* 824 */     if (junkpaths) {
/* 825 */       throw new EvalException("unzip(junpaths=false) not yet implemented", new Object[0]);
/*     */     }
/*     */     
/* 828 */     FileObject exfile = exdir.resolveFile(entry.getName());
/* 829 */     if (exfile.exists() && !overwrite) {
/* 830 */       throw new EvalException("file to be extracted '%s' already exists", new Object[] { friendlyFileName(exfile) });
/*     */     }
/* 832 */     OutputStream out = exfile.getContent().getOutputStream();
/*     */     
/*     */     try {
/* 835 */       byte[] buffer = new byte[65536];
/*     */       int bytesRead;
/* 837 */       while ((bytesRead = zin.read(buffer)) != -1) {
/* 838 */         out.write(buffer, 0, bytesRead);
/*     */       }
/*     */     } finally {
/* 841 */       out.close();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String friendlyFileName(FileObject file) {
/* 849 */     String uri = file.getName().getURI();
/* 850 */     if (uri.startsWith("file://")) {
/* 851 */       return uri.substring("file://".length());
/*     */     }
/* 853 */     return uri;
/*     */   }
/*     */   
/*     */   private static boolean unzipMatches(ZipEntry entry, Vector files) {
/* 857 */     if (files == Null.INSTANCE) {
/* 858 */       return true;
/*     */     }
/* 860 */     for (int i = 0; i != files.length(); i++) {
/* 861 */       if (entry.getName().equals(files.getElementAsString(i))) {
/* 862 */         return true;
/*     */       }
/*     */     } 
/* 865 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   @Internal("file.create")
/*     */   @DataParallel
/*     */   public static boolean fileCreate(@Current Context context, @Recycle String fileName, @Recycle(false) boolean showWarnings) throws IOException {
/*     */     try {
/* 873 */       FileObject file = context.resolveFile(fileName);
/*     */ 
/*     */       
/* 876 */       if (!file.getParent().exists()) {
/* 877 */         throw new IOException("No such file or directory");
/*     */       }
/* 879 */       file.getContent().getOutputStream().close();
/* 880 */       return true;
/*     */     }
/* 882 */     catch (Exception e) {
/* 883 */       if (showWarnings) {
/* 884 */         context.warn(String.format("cannot create file '%s', reason '%s'", new Object[] { fileName, e.getMessage() }));
/*     */       }
/* 886 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Internal("file.append")
/*     */   @DataParallel
/*     */   public static boolean fileAppend(@Current Context context, String destFileName, String sourceFileName) {
/*     */     try {
/* 899 */       FileObject sourceFile = context.resolveFile(sourceFileName);
/* 900 */       if (!sourceFile.exists()) {
/* 901 */         return false;
/*     */       }
/* 903 */       FileObject destFile = context.resolveFile(destFileName);
/* 904 */       OutputStream out = destFile.getContent().getOutputStream(true);
/*     */       
/* 906 */       try { InputStream in = sourceFile.getContent().getInputStream();
/*     */         
/* 908 */         try { ByteStreams.copy(in, out); }
/*     */         finally { 
/* 910 */           try { in.close(); } catch (Exception exception) {} }
/*     */          }
/*     */       finally { 
/* 913 */         try { out.close(); } catch (Exception exception) {} }
/*     */       
/* 915 */       return true;
/* 916 */     } catch (Exception e) {
/* 917 */       return false;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/files/Files.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */