/*     */ package org.renjin.primitives.io.connections;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.Reader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StdInConnection
/*     */   implements Connection
/*     */ {
/*  31 */   private PushbackBufferedReader stream = new PushbackBufferedReader(new InputStreamReader(System.in));
/*     */ 
/*     */   
/*     */   public InputStream getInputStream() throws IOException {
/*  35 */     throw new UnsupportedOperationException("Cannot read bytes from stdin");
/*     */   }
/*     */ 
/*     */   
/*     */   public PrintWriter getPrintWriter() throws IOException {
/*  40 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public PrintWriter getOpenPrintWriter() {
/*  45 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {}
/*     */ 
/*     */ 
/*     */   
/*     */   public OutputStream getOutputStream() throws IOException {
/*  55 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public PushbackBufferedReader getReader() {
/*  60 */     return this.stream;
/*     */   }
/*     */   
/*     */   public void setReader(Reader reader) {
/*  64 */     this.stream = new PushbackBufferedReader(reader);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isOpen() {
/*  69 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void flush() throws IOException {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void open(OpenSpec spec) throws IOException {}
/*     */ 
/*     */ 
/*     */   
/*     */   public String getClassName() {
/*  84 */     return "terminal";
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDescription() {
/*  89 */     return "stdin";
/*     */   }
/*     */ 
/*     */   
/*     */   public String getMode() {
/*  94 */     return "r";
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canRead() {
/*  99 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canWrite() {
/* 104 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public Connection.Type getType() {
/* 109 */     return Connection.Type.TEXT;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/io/connections/StdInConnection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */