/*    */ package org.renjin.compiler.builtins;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.renjin.compiler.codegen.EmitContext;
/*    */ import org.renjin.compiler.ir.ValueBounds;
/*    */ import org.renjin.compiler.ir.tac.IRArgument;
/*    */ import org.renjin.primitives.subset.MatrixSelection;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ import org.renjin.repackaged.asm.commons.InstructionAdapter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MatrixSubset
/*    */   implements Specialization
/*    */ {
/*    */   private final ValueBounds source;
/*    */   private final List<ValueBounds> subscripts;
/*    */   private ValueBounds result;
/*    */   private boolean drop = true;
/*    */   
/*    */   public MatrixSubset(ValueBounds source, List<ValueBounds> subscripts) {
/* 41 */     this.source = source;
/* 42 */     this.subscripts = subscripts;
/* 43 */     this.result = MatrixSelection.computeResultBounds(source, subscripts, true);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Specialization tryFurtherSpecialize() {
/* 51 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public Type getType() {
/* 56 */     return this.result.storageType();
/*    */   }
/*    */   
/*    */   public ValueBounds getResultBounds() {
/* 60 */     return this.result;
/*    */   }
/*    */ 
/*    */   
/*    */   public void load(EmitContext emitContext, InstructionAdapter mv, List<IRArgument> arguments) {
/* 65 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isPure() {
/* 70 */     return true;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/builtins/MatrixSubset.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */