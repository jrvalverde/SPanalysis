/*    */ package org.renjin.compiler.ir.tac.functions;
/*    */ 
/*    */ import org.renjin.compiler.NotCompilableException;
/*    */ import org.renjin.compiler.ir.tac.IRBodyBuilder;
/*    */ import org.renjin.compiler.ir.tac.expressions.Expression;
/*    */ import org.renjin.eval.EvalException;
/*    */ import org.renjin.sexp.Function;
/*    */ import org.renjin.sexp.FunctionCall;
/*    */ import org.renjin.sexp.PairList;
/*    */ import org.renjin.sexp.SEXP;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClosureTranslator
/*    */   extends FunctionCallTranslator
/*    */ {
/*    */   public Expression translateToExpression(IRBodyBuilder builder, TranslationContext context, Function resolvedFunction, FunctionCall call) {
/* 40 */     PairList formals = (PairList)EvalException.checkedCast(call.getArgument(0));
/* 41 */     SEXP body = call.getArgument(1);
/* 42 */     SEXP source = call.getArgument(2);
/*    */     
/* 44 */     throw new NotCompilableException(call);
/*    */   }
/*    */   
/*    */   public void addStatement(IRBodyBuilder builder, TranslationContext context, Function resolvedFunction, FunctionCall call) {}
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/ir/tac/functions/ClosureTranslator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */