/*    */ package org.renjin.base;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.FileReader;
/*    */ import java.io.IOException;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import java.util.Set;
/*    */ import org.renjin.eval.Context;
/*    */ import org.renjin.eval.Session;
/*    */ import org.renjin.eval.SessionBuilder;
/*    */ import org.renjin.packaging.LazyLoadFrameBuilder;
/*    */ import org.renjin.parser.RParser;
/*    */ import org.renjin.repackaged.guava.collect.Lists;
/*    */ import org.renjin.repackaged.guava.collect.Sets;
/*    */ import org.renjin.sexp.Environment;
/*    */ import org.renjin.sexp.ExpressionVector;
/*    */ import org.renjin.sexp.FunctionCall;
/*    */ import org.renjin.sexp.SEXP;
/*    */ import org.renjin.sexp.Symbol;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BasePackageCompiler
/*    */ {
/*    */   public static void main(String[] args) throws IOException {
/* 49 */     Session session = (new SessionBuilder()).withoutBasePackage().build();
/*    */     
/* 51 */     Context context = session.getTopLevelContext();
/* 52 */     Environment baseNamespaceEnv = context.getNamespaceRegistry().getBase().getNamespaceEnvironment();
/* 53 */     Context evalContext = context.beginEvalContext(baseNamespaceEnv);
/*    */     
/* 55 */     File baseSourceRoot = new File("src/main/R/base");
/* 56 */     evalSources(evalContext, baseSourceRoot);
/*    */     
/* 58 */     evalContext.evaluate((SEXP)FunctionCall.newCall((SEXP)Symbol.get(".onLoad"), new SEXP[0]));
/*    */ 
/*    */ 
/*    */     
/* 62 */     Set<String> omit = Sets.newHashSet((Object[])new String[] { ".Last.value", ".AutoloadEnv", ".BaseNamespaceEnv", ".Device", ".Devices", ".Machine", ".Options", ".Platform" });
/*    */ 
/*    */ 
/*    */     
/* 66 */     (new LazyLoadFrameBuilder(context))
/* 67 */       .outputTo(new File("target/classes/org/renjin/base"))
/* 68 */       .excludeSymbols(omit)
/* 69 */       .filter(x -> !(x instanceof org.renjin.sexp.PrimitiveFunction))
/* 70 */       .build(baseNamespaceEnv);
/*    */   }
/*    */   
/*    */   private static void evalSources(Context evalContext, File dir) throws IOException {
/* 74 */     List<File> sources = Lists.newArrayList();
/* 75 */     for (File sourceFile : dir.listFiles()) {
/* 76 */       if (sourceFile.getName().endsWith(".R")) {
/* 77 */         sources.add(sourceFile);
/*    */       }
/*    */     } 
/* 80 */     Collections.sort(sources);
/*    */     
/* 82 */     for (File source : sources) {
/* 83 */       FileReader reader = new FileReader(source);
/*    */       try {
/* 85 */         ExpressionVector expressionVector = RParser.parseAllSource(reader);
/* 86 */         evalContext.evaluate((SEXP)expressionVector);
/* 87 */       } catch (Exception e) {
/* 88 */         throw new RuntimeException("Error evaluating " + source.getName() + ": " + e.getMessage(), e);
/*    */       } finally {
/* 90 */         reader.close();
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/base/BasePackageCompiler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */