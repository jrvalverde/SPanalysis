/*    */ package org.renjin.primitives.subset;
/*    */ 
/*    */ import org.renjin.sexp.ListVector;
/*    */ import org.renjin.sexp.Symbol;
/*    */ import org.renjin.sexp.Symbols;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ListSubsetting
/*    */ {
/*    */   public static ListVector removeListElements(ListVector list, IndexPredicate predicate) {
/* 29 */     boolean anyRemoved = false;
/* 30 */     ListVector.NamedBuilder result = new ListVector.NamedBuilder(0, list.length());
/*    */     
/* 32 */     for (int i = 0; i < list.length(); i++) {
/* 33 */       if (predicate.apply(i)) {
/* 34 */         anyRemoved = true;
/*    */       } else {
/* 36 */         result.add(list.getName(i), list.getElementAsSEXP(i));
/*    */       } 
/*    */     } 
/*    */ 
/*    */     
/* 41 */     if (!anyRemoved) {
/* 42 */       return list;
/*    */     }
/*    */ 
/*    */     
/* 46 */     for (Symbol attribute : list.getAttributes().names()) {
/* 47 */       if (attribute != Symbols.NAMES && attribute != Symbols.DIM && attribute != Symbols.DIMNAMES)
/*    */       {
/*    */ 
/*    */         
/* 51 */         result.setAttribute(attribute, list.getAttribute(attribute));
/*    */       }
/*    */     } 
/*    */     
/* 55 */     return result.build();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/subset/ListSubsetting.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */