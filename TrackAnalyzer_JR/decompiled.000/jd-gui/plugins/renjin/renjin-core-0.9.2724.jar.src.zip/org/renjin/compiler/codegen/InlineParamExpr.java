/*    */ package org.renjin.compiler.codegen;
/*    */ 
/*    */ import org.renjin.compiler.ir.tac.expressions.Expression;
/*    */ import org.renjin.repackaged.asm.commons.InstructionAdapter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InlineParamExpr
/*    */ {
/*    */   private EmitContext context;
/*    */   private Expression expression;
/*    */   
/*    */   public InlineParamExpr(EmitContext context, Expression expression) {
/* 31 */     this.context = context;
/* 32 */     this.expression = expression;
/*    */   }
/*    */   
/*    */   public void load(InstructionAdapter mv) {
/* 36 */     this.expression.load(this.context, mv);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/codegen/InlineParamExpr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */