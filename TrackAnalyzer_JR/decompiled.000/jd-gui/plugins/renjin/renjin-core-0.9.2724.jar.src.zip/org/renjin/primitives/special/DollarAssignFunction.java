/*    */ package org.renjin.primitives.special;
/*    */ 
/*    */ import org.renjin.eval.Context;
/*    */ import org.renjin.eval.EvalException;
/*    */ import org.renjin.primitives.S3;
/*    */ import org.renjin.primitives.subset.Subsetting;
/*    */ import org.renjin.sexp.AtomicVector;
/*    */ import org.renjin.sexp.Environment;
/*    */ import org.renjin.sexp.ExternalPtr;
/*    */ import org.renjin.sexp.FunctionCall;
/*    */ import org.renjin.sexp.ListVector;
/*    */ import org.renjin.sexp.Null;
/*    */ import org.renjin.sexp.PairList;
/*    */ import org.renjin.sexp.S4Object;
/*    */ import org.renjin.sexp.SEXP;
/*    */ import org.renjin.sexp.SpecialFunction;
/*    */ import org.renjin.sexp.StringVector;
/*    */ import org.renjin.sexp.Symbol;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DollarAssignFunction
/*    */   extends SpecialFunction
/*    */ {
/*    */   public DollarAssignFunction() {
/* 31 */     super("$<-");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SEXP apply(Context context, Environment rho, FunctionCall call, PairList args) {
/* 38 */     if (args.length() != 3) {
/* 39 */       throw new EvalException(String.format("%d argument(s) passed to '$<-' which requires 3", new Object[] { Integer.valueOf(args.length()) }), new Object[0]);
/*    */     }
/*    */     
/* 42 */     SEXP object = context.evaluate(args.getElementAsSEXP(0), rho);
/* 43 */     StringVector nameArgument = DollarFunction.evaluateName(args.getElementAsSEXP(1));
/* 44 */     SEXP value = context.evaluate(args.getElementAsSEXP(2), rho);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 50 */     PairList.Node repackagedArgs = new PairList.Node(object, (PairList)new PairList.Node((SEXP)nameArgument, (PairList)new PairList.Node((SEXP)Symbol.get("value"), value, (PairList)Null.INSTANCE)));
/*    */ 
/*    */     
/* 53 */     SEXP genericResult = S3.tryDispatchFromPrimitive(context, rho, call, "$<-", object, (PairList)repackagedArgs);
/* 54 */     if (genericResult != null) {
/* 55 */       return genericResult;
/*    */     }
/*    */ 
/*    */     
/* 59 */     String name = nameArgument.getElementAsString(0);
/* 60 */     if (object instanceof PairList.Node) {
/* 61 */       return Subsetting.setElementByName((PairList.Node)object, name, value);
/*    */     }
/* 63 */     if (object instanceof Environment) {
/* 64 */       return Subsetting.setElementByName(context, (Environment)object, name, value);
/*    */     }
/* 66 */     if (object instanceof ListVector) {
/* 67 */       return Subsetting.setElementByName((ListVector)object, name, value);
/*    */     }
/* 69 */     if (object instanceof ExternalPtr) {
/* 70 */       return Subsetting.setElementByName((ExternalPtr)object, name, value);
/*    */     }
/* 72 */     if (object instanceof AtomicVector) {
/* 73 */       return Subsetting.setElementByName((AtomicVector)object, name, value);
/*    */     }
/* 75 */     if (object instanceof S4Object) {
/* 76 */       return Subsetting.setElementByName(context, (S4Object)object, name, value);
/*    */     }
/* 78 */     throw new EvalException("object of type '%s' is not subsettable", new Object[] { object.getTypeName() });
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/special/DollarAssignFunction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */