/*    */ package org.renjin.compiler.ir.tac.functions;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.renjin.compiler.ir.tac.IRArgument;
/*    */ import org.renjin.compiler.ir.tac.IRBodyBuilder;
/*    */ import org.renjin.compiler.ir.tac.expressions.ClosureCall;
/*    */ import org.renjin.compiler.ir.tac.expressions.Expression;
/*    */ import org.renjin.compiler.ir.tac.statements.ExprStatement;
/*    */ import org.renjin.compiler.ir.tac.statements.Statement;
/*    */ import org.renjin.sexp.Closure;
/*    */ import org.renjin.sexp.Function;
/*    */ import org.renjin.sexp.FunctionCall;
/*    */ import org.renjin.sexp.Symbol;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClosureCallTranslator
/*    */   extends FunctionCallTranslator
/*    */ {
/*    */   private final Closure function;
/*    */   
/*    */   public ClosureCallTranslator(Closure function) {
/* 42 */     this.function = function;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Expression translateToExpression(IRBodyBuilder builder, TranslationContext context, Function resolvedFunction, FunctionCall call) {
/* 51 */     List<IRArgument> arguments = builder.translateArgumentList(context, call.getArguments());
/*    */     
/* 53 */     return (Expression)new ClosureCall(builder.getRuntimeState(), call, this.function, functionName(call), arguments);
/*    */   }
/*    */ 
/*    */   
/*    */   public void addStatement(IRBodyBuilder builder, TranslationContext context, Function resolvedFunction, FunctionCall call) {
/* 58 */     builder.addStatement((Statement)new ExprStatement(translateToExpression(builder, context, resolvedFunction, call)));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Expression translateToSetterExpression(IRBodyBuilder builder, TranslationContext context, Function resolvedFunction, FunctionCall getterCall, Expression rhs) {
/* 64 */     List<IRArgument> setterArguments = new ArrayList<>();
/* 65 */     setterArguments.addAll(builder.translateArgumentList(context, getterCall.getArguments()));
/* 66 */     setterArguments.add(new IRArgument("value", rhs));
/*    */     
/* 68 */     String functionName = functionName(getterCall) + "<-";
/* 69 */     return (Expression)new ClosureCall(builder.getRuntimeState(), getterCall, (Closure)resolvedFunction, functionName, setterArguments);
/*    */   }
/*    */ 
/*    */   
/*    */   private String functionName(FunctionCall call) {
/* 74 */     if (call.getFunction() instanceof Symbol) {
/* 75 */       return ((Symbol)call.getFunction()).getPrintName();
/*    */     }
/* 77 */     return "fn";
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/ir/tac/functions/ClosureCallTranslator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */