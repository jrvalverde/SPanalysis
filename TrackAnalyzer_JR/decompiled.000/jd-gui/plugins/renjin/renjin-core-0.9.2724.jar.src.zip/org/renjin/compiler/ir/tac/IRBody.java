/*     */ package org.renjin.compiler.ir.tac;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.renjin.compiler.ir.tac.expressions.ReadParam;
/*     */ import org.renjin.compiler.ir.tac.statements.Statement;
/*     */ import org.renjin.repackaged.guava.base.Strings;
/*     */ import org.renjin.repackaged.guava.collect.Lists;
/*     */ import org.renjin.repackaged.guava.collect.Sets;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IRBody
/*     */ {
/*     */   private Statement[] statements;
/*     */   private int[] labels;
/*  35 */   private List<ReadParam> params = Collections.emptyList();
/*     */   
/*     */   public IRBody(List<Statement> statements, Map<IRLabel, Integer> labels) {
/*  38 */     this.statements = statements.<Statement>toArray(new Statement[statements.size()]);
/*  39 */     this.labels = new int[labels.size()];
/*     */     
/*  41 */     Arrays.fill(this.labels, -1);
/*     */     
/*  43 */     for (Map.Entry<IRLabel, Integer> label : labels.entrySet()) {
/*  44 */       this.labels[((IRLabel)label.getKey()).getIndex()] = ((Integer)label.getValue()).intValue();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public List<ReadParam> getParams() {
/*  50 */     return this.params;
/*     */   }
/*     */   
/*     */   public void setParams(List<ReadParam> params) {
/*  54 */     this.params = params;
/*     */   }
/*     */   
/*     */   public List<Statement> getStatements() {
/*  58 */     return Lists.newArrayList((Object[])this.statements);
/*     */   }
/*     */   
/*     */   public int getLabelInstructionIndex(IRLabel label) {
/*  62 */     return this.labels[label.getIndex()];
/*     */   }
/*     */   
/*     */   public Set<IRLabel> getIntructionLabels(int instructionIndex) {
/*  66 */     Set<IRLabel> set = Sets.newHashSet();
/*  67 */     for (int i = 0; i != this.labels.length; i++) {
/*  68 */       if (this.labels[i] == instructionIndex) {
/*  69 */         set.add(new IRLabel(i));
/*     */       }
/*     */     } 
/*  72 */     return set;
/*     */   }
/*     */   
/*     */   public boolean isLabeled(int instructionIndex) {
/*  76 */     for (int i = 0; i != this.labels.length; i++) {
/*  77 */       if (this.labels[i] == instructionIndex) {
/*  78 */         return true;
/*     */       }
/*     */     } 
/*  81 */     return false;
/*     */   }
/*     */   
/*     */   private String labelAt(int instructionIndex) {
/*  85 */     Set<IRLabel> labels = getIntructionLabels(instructionIndex);
/*     */     
/*  87 */     return labels.isEmpty() ? Strings.repeat(" ", 5) : 
/*  88 */       Strings.padEnd(((IRLabel)labels.iterator().next()).toString(), 5, ' ');
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  93 */     StringBuilder sb = new StringBuilder();
/*  94 */     for (int i = 0; i != this.statements.length; i++) {
/*  95 */       appendLineTo(sb, i);
/*     */     }
/*  97 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public void appendLineTo(StringBuilder sb, int i) {
/* 101 */     sb.append(labelAt(i))
/* 102 */       .append(Strings.padEnd(i + ":", 4, ' '))
/* 103 */       .append(this.statements[i])
/* 104 */       .append("\n");
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/ir/tac/IRBody.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */