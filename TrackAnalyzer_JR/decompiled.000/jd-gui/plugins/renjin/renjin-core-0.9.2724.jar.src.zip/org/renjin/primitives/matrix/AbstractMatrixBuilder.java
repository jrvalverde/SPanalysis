/*    */ package org.renjin.primitives.matrix;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import org.renjin.primitives.Indexes;
/*    */ import org.renjin.sexp.IntArrayVector;
/*    */ import org.renjin.sexp.ListVector;
/*    */ import org.renjin.sexp.Null;
/*    */ import org.renjin.sexp.SEXP;
/*    */ import org.renjin.sexp.StringArrayVector;
/*    */ import org.renjin.sexp.Symbols;
/*    */ import org.renjin.sexp.Vector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class AbstractMatrixBuilder<B extends Vector.Builder, V extends Vector>
/*    */ {
/*    */   protected final B builder;
/*    */   private final int nrows;
/*    */   private final int ncols;
/* 33 */   private Vector rowNames = (Vector)Null.INSTANCE;
/* 34 */   private Vector colNames = (Vector)Null.INSTANCE;
/*    */   
/*    */   public AbstractMatrixBuilder(Vector.Type vectorType, int nrows, int ncols) {
/* 37 */     this.nrows = nrows;
/* 38 */     this.ncols = ncols;
/* 39 */     this.builder = (B)vectorType.newBuilderWithInitialSize(nrows * ncols);
/* 40 */     this.builder.setAttribute(Symbols.DIM, (SEXP)new IntArrayVector(new int[] { nrows, ncols }));
/*    */   }
/*    */   
/*    */   public void setRowNames(Vector names) {
/* 44 */     this.rowNames = names;
/*    */   }
/*    */   
/*    */   public void setRowNames(Collection<String> names) {
/* 48 */     this.rowNames = (Vector)new StringArrayVector(names);
/*    */   }
/*    */   
/*    */   public void setColNames(Vector names) {
/* 52 */     this.colNames = names;
/*    */   }
/*    */   
/*    */   public void setColNames(Collection<String> names) {
/* 56 */     this.colNames = (Vector)new StringArrayVector(names);
/*    */   }
/*    */   
/*    */   public int getRows() {
/* 60 */     return this.nrows;
/*    */   }
/*    */   
/*    */   public int getCols() {
/* 64 */     return this.ncols;
/*    */   }
/*    */   
/*    */   protected final int computeIndex(int row, int col) {
/* 68 */     return Indexes.matrixIndexToVectorIndex(row, col, this.nrows, this.ncols);
/*    */   }
/*    */   
/*    */   public V build() {
/* 72 */     if (this.rowNames != Null.INSTANCE || this.colNames != Null.INSTANCE) {
/* 73 */       this.builder.setAttribute(Symbols.DIMNAMES, (SEXP)new ListVector(new SEXP[] { (SEXP)this.rowNames, (SEXP)this.colNames }));
/*    */     }
/* 75 */     return (V)this.builder.build();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/matrix/AbstractMatrixBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */