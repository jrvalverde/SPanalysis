/*     */ package org.renjin.invoke.reflection;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.List;
/*     */ import org.renjin.eval.Context;
/*     */ import org.renjin.eval.EvalException;
/*     */ import org.renjin.invoke.codegen.ArgumentIterator;
/*     */ import org.renjin.invoke.reflection.converters.Converter;
/*     */ import org.renjin.invoke.reflection.converters.Converters;
/*     */ import org.renjin.repackaged.guava.collect.Iterables;
/*     */ import org.renjin.repackaged.guava.collect.Lists;
/*     */ import org.renjin.sexp.Environment;
/*     */ import org.renjin.sexp.ListVector;
/*     */ import org.renjin.sexp.PairList;
/*     */ import org.renjin.sexp.SEXP;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FunctionBinding
/*     */ {
/*  44 */   private List<Overload> overloads = Lists.newArrayList();
/*     */   private int maxArgCount;
/*     */   
/*     */   public FunctionBinding(Iterable<Method> overloads) {
/*  48 */     for (Method method : overloads) {
/*  49 */       addOverload(method);
/*     */     }
/*  51 */     AbstractOverload.sortOverloads((List)this.overloads);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class getDeclaringClass() {
/*  59 */     return ((Overload)Iterables.get(this.overloads, 0)).getDeclaringClass();
/*     */   }
/*     */   
/*     */   public List<Overload> getOverloads() {
/*  63 */     return this.overloads;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/*  70 */     return ((Overload)Iterables.get(this.overloads, 0)).getName();
/*     */   }
/*     */   
/*     */   private void addOverload(Method method) {
/*  74 */     Overload overload = new Overload(method);
/*  75 */     if (overload.getArgCount() > this.maxArgCount) {
/*  76 */       this.maxArgCount = overload.getArgCount();
/*     */     }
/*  78 */     this.overloads.add(overload);
/*     */   }
/*     */   
/*     */   public static class Overload extends AbstractOverload {
/*     */     private Method method;
/*     */     private Converter returnValueConverter;
/*     */     
/*     */     public Overload(Method method) {
/*  86 */       super(method.getParameterTypes(), method
/*  87 */           .getParameterAnnotations(), method
/*  88 */           .isVarArgs());
/*  89 */       this.method = method;
/*  90 */       this.returnValueConverter = Converters.get(method.getReturnType());
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  95 */       if (!Modifier.isPublic(method.getDeclaringClass().getModifiers())) {
/*     */         try {
/*  97 */           this.method.setAccessible(true);
/*  98 */         } catch (SecurityException securityException) {}
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Class getDeclaringClass() {
/* 107 */       return this.method.getDeclaringClass();
/*     */     }
/*     */     
/*     */     public String getName() {
/* 111 */       return this.method.getName();
/*     */     }
/*     */     
/*     */     public SEXP invoke(Context context, Object instance, List<SEXP> args) {
/* 115 */       Object[] converted = convertArguments(context, args);
/*     */       try {
/* 117 */         Object result = this.method.invoke(instance, converted);
/* 118 */         return this.returnValueConverter.convertToR(result);
/*     */       }
/* 120 */       catch (IllegalArgumentException e) {
/* 121 */         throw new RuntimeException(e);
/* 122 */       } catch (IllegalAccessException e) {
/* 123 */         throw new RuntimeException("Exception invoking " + this.method, e);
/* 124 */       } catch (InvocationTargetException e) {
/* 125 */         throw new EvalException(e.getCause().getMessage(), e.getCause());
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 131 */       return this.method.toString();
/*     */     }
/*     */     
/*     */     public Method getMethod() {
/* 135 */       return this.method;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SEXP evaluateArgsAndInvoke(Object instance, Context context, Environment rho, PairList arguments) {
/* 149 */     List<SEXP> args = Lists.newArrayListWithCapacity(this.maxArgCount);
/* 150 */     ArgumentIterator it = new ArgumentIterator(context, rho, arguments);
/* 151 */     while (it.hasNext()) {
/* 152 */       args.add(context.evaluate(it.next(), rho));
/*     */     }
/* 154 */     return invoke(instance, context, args);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SEXP invoke(Object instance, Context context, ListVector evaluatedArguments) {
/* 164 */     List<SEXP> args = Lists.newArrayList((Iterable)evaluatedArguments);
/* 165 */     return invoke(instance, context, args);
/*     */   }
/*     */ 
/*     */   
/*     */   private SEXP invoke(Object instance, Context context, List<SEXP> args) {
/* 170 */     for (Overload overload : this.overloads) {
/* 171 */       if (overload.accept(args)) {
/* 172 */         return overload.invoke(context, instance, args);
/*     */       }
/*     */     } 
/* 175 */     throw new EvalException("Cannot match arguments (%s) to any JVM method overload:\n%s", new Object[] {
/* 176 */           ExceptionUtil.toString(args), ExceptionUtil.overloadListToString(this.overloads)
/*     */         });
/*     */   }
/*     */   
/*     */   public String toString() {
/* 181 */     return getName();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/reflection/FunctionBinding.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */