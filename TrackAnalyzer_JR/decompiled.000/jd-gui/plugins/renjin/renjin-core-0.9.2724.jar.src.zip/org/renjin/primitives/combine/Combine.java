/*    */ package org.renjin.primitives.combine;
/*    */ 
/*    */ import org.renjin.invoke.annotations.ArgumentList;
/*    */ import org.renjin.invoke.annotations.Builtin;
/*    */ import org.renjin.invoke.annotations.Generic;
/*    */ import org.renjin.invoke.annotations.Internal;
/*    */ import org.renjin.invoke.annotations.NamedFlag;
/*    */ import org.renjin.repackaged.guava.base.Function;
/*    */ import org.renjin.repackaged.guava.collect.Iterables;
/*    */ import org.renjin.sexp.ListVector;
/*    */ import org.renjin.sexp.NamedValue;
/*    */ import org.renjin.sexp.Null;
/*    */ import org.renjin.sexp.PairList;
/*    */ import org.renjin.sexp.SEXP;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Combine
/*    */ {
/*    */   @Generic
/*    */   @Builtin
/*    */   public static SEXP c(@ArgumentList ListVector arguments, @NamedFlag("recursive") boolean recursive) {
/* 44 */     Inspector inspector = new Inspector(recursive);
/* 45 */     inspector.acceptAll(Iterables.transform(arguments.namedValues(), VALUE_OF));
/*    */     
/* 47 */     if (inspector.getResult() == Null.VECTOR_TYPE) {
/* 48 */       return (SEXP)Null.INSTANCE;
/*    */     }
/*    */     
/* 51 */     CombinedBuilder builder = inspector.newBuilder().useNames(true);
/*    */ 
/*    */     
/* 54 */     return (SEXP)(new Combiner(recursive, builder))
/* 55 */       .add(arguments)
/* 56 */       .build();
/*    */   }
/*    */   
/*    */   @Generic
/*    */   @Internal
/*    */   public static SEXP unlist(SEXP sexp, boolean recursive, boolean useNames) {
/*    */     ListVector listVector1;
/* 63 */     if (sexp instanceof org.renjin.sexp.FunctionCall) {
/* 64 */       return sexp;
/*    */     }
/*    */     
/* 67 */     if (sexp instanceof PairList.Node) {
/* 68 */       listVector1 = ((PairList.Node)sexp).toVector();
/*    */     }
/*    */     
/* 71 */     if (!(listVector1 instanceof ListVector)) {
/* 72 */       return (SEXP)listVector1;
/*    */     }
/*    */     
/* 75 */     ListVector vector = listVector1;
/*    */ 
/*    */ 
/*    */     
/* 79 */     Inspector inspector = new Inspector(recursive);
/* 80 */     inspector.acceptAll((Iterable)vector);
/*    */     
/* 82 */     if (inspector.getResult() == Null.VECTOR_TYPE) {
/* 83 */       return (SEXP)Null.INSTANCE;
/*    */     }
/*    */     
/* 86 */     CombinedBuilder builder = inspector.newBuilder().useNames(useNames);
/*    */     
/* 88 */     return (SEXP)(new Combiner(recursive, builder))
/* 89 */       .add(vector)
/* 90 */       .build();
/*    */   }
/*    */ 
/*    */   
/* 94 */   private static final Function<NamedValue, SEXP> VALUE_OF = new Function<NamedValue, SEXP>()
/*    */     {
/*    */       public SEXP apply(NamedValue input)
/*    */       {
/* 98 */         return input.getValue();
/*    */       }
/*    */     };
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/combine/Combine.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */