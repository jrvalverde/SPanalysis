/*    */ package org.renjin.pipeliner.fusion.node;
/*    */ 
/*    */ import java.util.Optional;
/*    */ import org.renjin.pipeliner.ComputeMethod;
/*    */ import org.renjin.pipeliner.node.DeferredNode;
/*    */ import org.renjin.repackaged.asm.Label;
/*    */ import org.renjin.repackaged.asm.MethodVisitor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RepeatingNode
/*    */   extends LoopNode
/*    */ {
/*    */   private LoopNode sourceNode;
/*    */   private LoopNode timesNode;
/*    */   private int sourceLengthLocal;
/*    */   
/*    */   public RepeatingNode(LoopNode sourceNode, LoopNode timesNode) {
/* 37 */     this.sourceNode = sourceNode;
/* 38 */     this.timesNode = timesNode;
/*    */   }
/*    */   
/*    */   public static boolean accept(DeferredNode node) {
/* 42 */     return (node.getVector() instanceof org.renjin.primitives.sequence.RepDoubleVector && node
/* 43 */       .getOperand(2).hasValue(1.0D));
/*    */   }
/*    */ 
/*    */   
/*    */   public void init(ComputeMethod method) {
/* 48 */     MethodVisitor mv = method.getVisitor();
/* 49 */     this.sourceNode.init(method);
/* 50 */     this.timesNode.init(method);
/* 51 */     this.sourceLengthLocal = method.reserveLocal(1);
/* 52 */     this.sourceNode.pushLength(method);
/* 53 */     mv.visitVarInsn(54, this.sourceLengthLocal);
/*    */   }
/*    */ 
/*    */   
/*    */   public void pushLength(ComputeMethod method) {
/* 58 */     MethodVisitor mv = method.getVisitor();
/* 59 */     mv.visitVarInsn(21, this.sourceLengthLocal);
/* 60 */     this.timesNode.pushElementAsInt(method, 0);
/* 61 */     mv.visitInsn(104);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean mustCheckForIntegerNAs() {
/* 66 */     return this.sourceNode.mustCheckForIntegerNAs();
/*    */   }
/*    */ 
/*    */   
/*    */   public void appendToKey(StringBuilder key) {
/* 71 */     key.append("rep(");
/* 72 */     this.sourceNode.appendToKey(key);
/* 73 */     key.append(',');
/* 74 */     this.timesNode.appendToKey(key);
/* 75 */     key.append(')');
/*    */   }
/*    */ 
/*    */   
/*    */   public void pushElementAsDouble(ComputeMethod method, Optional<Label> integerNaLabel) {
/* 80 */     MethodVisitor mv = method.getVisitor();
/* 81 */     mv.visitVarInsn(21, this.sourceLengthLocal);
/* 82 */     mv.visitInsn(112);
/* 83 */     this.sourceNode.pushElementAsDouble(method);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 88 */     return "rep(" + this.sourceNode + ", " + this.timesNode + ")";
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/pipeliner/fusion/node/RepeatingNode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */