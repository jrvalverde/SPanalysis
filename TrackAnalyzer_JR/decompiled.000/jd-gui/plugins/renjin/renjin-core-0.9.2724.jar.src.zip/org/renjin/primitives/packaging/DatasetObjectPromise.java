/*    */ package org.renjin.primitives.packaging;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.renjin.eval.Context;
/*    */ import org.renjin.eval.EvalException;
/*    */ import org.renjin.sexp.Environment;
/*    */ import org.renjin.sexp.Null;
/*    */ import org.renjin.sexp.Promise;
/*    */ import org.renjin.sexp.SEXP;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DatasetObjectPromise
/*    */   extends Promise
/*    */ {
/*    */   private Dataset dataset;
/*    */   private String objectName;
/*    */   
/*    */   protected DatasetObjectPromise(Dataset dataset, String name) {
/* 41 */     super((Environment)Environment.EMPTY, (SEXP)Null.INSTANCE);
/* 42 */     this.dataset = dataset;
/* 43 */     this.objectName = name;
/*    */   }
/*    */ 
/*    */   
/*    */   protected SEXP doEval(Context context, boolean allowMissing) {
/*    */     try {
/* 49 */       return this.dataset.loadObject(this.objectName);
/* 50 */     } catch (IOException e) {
/* 51 */       throw new EvalException("Exception loading '%s' from dataset '%s'", new Object[] { this.objectName, this.dataset.getName() });
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/packaging/DatasetObjectPromise.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */