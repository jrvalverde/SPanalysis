/*    */ package org.renjin.compiler.ir.tac.functions;
/*    */ 
/*    */ import org.renjin.compiler.ir.tac.IRLabel;
/*    */ import org.renjin.sexp.PairList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LoopContext
/*    */   implements TranslationContext
/*    */ {
/*    */   private TranslationContext parentContext;
/*    */   private final IRLabel startLabel;
/*    */   private final IRLabel exitLabel;
/*    */   
/*    */   public LoopContext(TranslationContext parentContext, IRLabel startLabel, IRLabel exitLabel) {
/* 32 */     this.parentContext = parentContext;
/* 33 */     this.startLabel = startLabel;
/* 34 */     this.exitLabel = exitLabel;
/*    */   }
/*    */   
/*    */   public IRLabel getStartLabel() {
/* 38 */     return this.startLabel;
/*    */   }
/*    */   
/*    */   public IRLabel getExitLabel() {
/* 42 */     return this.exitLabel;
/*    */   }
/*    */ 
/*    */   
/*    */   public PairList getEllipsesArguments() {
/* 47 */     return this.parentContext.getEllipsesArguments();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/ir/tac/functions/LoopContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */