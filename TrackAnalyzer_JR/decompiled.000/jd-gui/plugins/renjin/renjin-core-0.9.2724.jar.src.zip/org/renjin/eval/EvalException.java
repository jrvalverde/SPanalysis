/*     */ package org.renjin.eval;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.io.PrintWriter;
/*     */ import org.renjin.primitives.Conditions;
/*     */ import org.renjin.sexp.ListVector;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.StringArrayVector;
/*     */ import org.renjin.sexp.Symbols;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EvalException
/*     */   extends RuntimeException
/*     */ {
/*     */   private SEXP condition;
/*     */   private Context context;
/*     */   
/*     */   public EvalException(String message, Throwable t) {
/*  37 */     super(message, t);
/*  38 */     ListVector.NamedBuilder condition = ListVector.newNamedBuilder();
/*  39 */     condition.add("message", getMessage());
/*  40 */     condition.setAttribute(Symbols.CLASS, (SEXP)new StringArrayVector(new String[] { "simpleError", "error", "condition" }));
/*  41 */     this.condition = (SEXP)condition.build();
/*     */   }
/*     */   
/*     */   public EvalException(String message, Object... args) {
/*  45 */     this((args.length == 0) ? message : String.format(message, args), (Throwable)null);
/*     */   }
/*     */ 
/*     */   
/*     */   public EvalException(Context context, String message, Object... args) {
/*  50 */     this((args.length == 0) ? message : String.format(message, args), (Throwable)null);
/*  51 */     initContext(context);
/*     */   }
/*     */ 
/*     */   
/*     */   public EvalException(Throwable cause) {
/*  56 */     super(cause.getMessage(), cause);
/*     */   }
/*     */   
/*     */   public Context getContext() {
/*  60 */     return this.context;
/*     */   }
/*     */   
/*     */   public void initContext(Context context) {
/*  64 */     if (this.context == null) {
/*  65 */       this.context = context;
/*  66 */       Conditions.signalCondition(context, this.condition, null, null);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void printRStackTrace(PrintWriter writer) {
/*  72 */     if (this.context != null) {
/*  73 */       Context context = this.context;
/*     */       
/*  75 */       while (!context.isTopLevel()) {
/*  76 */         if (context.getType() == Context.Type.FUNCTION) {
/*  77 */           writer.append("  at ").append(context.getFunctionName().toString()).append("()");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*  89 */           writer.append("\n");
/*     */         } 
/*  91 */         context = context.getParent();
/*     */       } 
/*     */       
/*  94 */       if (getCause() != null) {
/*  95 */         writer.append("Caused by:");
/*  96 */         Throwable excause = getCause();
/*  97 */         if (excause instanceof EvalException) {
/*  98 */           ((EvalException)excause).printRStackTrace(writer);
/*     */         } else {
/* 100 */           excause.printStackTrace(writer);
/*     */         } 
/*     */       } 
/*     */     } else {
/*     */       
/* 105 */       printStackTrace(writer);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void printRStackTrace(PrintStream stream) {
/* 111 */     PrintWriter writer = new PrintWriter(stream);
/* 112 */     printRStackTrace(writer);
/* 113 */     writer.flush();
/*     */   }
/*     */   
/*     */   public static void check(boolean condition, String errorMessage, Object... args) {
/* 117 */     if (!condition) {
/* 118 */       throw new EvalException(errorMessage, args);
/*     */     }
/*     */   }
/*     */   
/*     */   public static <S extends SEXP> S checkedCast(SEXP argument) {
/*     */     try {
/* 124 */       return (S)argument;
/* 125 */     } catch (ClassCastException e) {
/* 126 */       throw new EvalException("invalid 'type' (%s) of argument", new Object[] { argument.getTypeName() });
/*     */     } 
/*     */   }
/*     */   
/*     */   public SEXP getCondition() {
/* 131 */     return this.condition;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/eval/EvalException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */