/*     */ package org.renjin.pipeliner;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ExecutionException;
/*     */ import java.util.concurrent.ExecutorCompletionService;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Future;
/*     */ import org.renjin.eval.EvalException;
/*     */ import org.renjin.pipeliner.node.DeferredNode;
/*     */ import org.renjin.repackaged.guava.collect.Maps;
/*     */ import org.renjin.repackaged.guava.collect.Sets;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DeferredGraphEval
/*     */ {
/*     */   private DeferredGraph graph;
/*     */   private ExecutorCompletionService<DeferredNode> service;
/*  42 */   private Set<DeferredNode> scheduled = Sets.newIdentityHashSet();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  47 */   private Map<DeferredNode, Future<DeferredNode>> submitted = Maps.newIdentityHashMap();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  52 */   private int pendingCount = 0;
/*     */   
/*     */   public DeferredGraphEval(DeferredGraph graph, ExecutorService service) {
/*  55 */     this.graph = graph;
/*  56 */     this.service = new ExecutorCompletionService<>(service);
/*     */   }
/*     */   
/*     */   public void execute() {
/*  60 */     scheduleRoots();
/*  61 */     while (this.pendingCount > 0) {
/*  62 */       DeferredNode completed = nextCompleted();
/*  63 */       submitDependents(completed);
/*     */     } 
/*     */   }
/*     */   
/*     */   private DeferredNode nextCompleted() {
/*     */     DeferredNode completed;
/*     */     try {
/*  70 */       completed = this.service.take().get();
/*  71 */       this.pendingCount--;
/*  72 */     } catch (InterruptedException e) {
/*  73 */       throw new EvalException("Deferred vector execution interrupted.", new Object[0]);
/*  74 */     } catch (ExecutionException e) {
/*  75 */       throw new EvalException(e.getCause());
/*     */     } 
/*  77 */     return completed;
/*     */   }
/*     */   
/*     */   private void submitDependents(DeferredNode completed) {
/*  81 */     for (DeferredNode dependentNode : completed.getUses()) {
/*  82 */       if (!this.submitted.containsKey(dependentNode) && 
/*  83 */         inputsComplete(dependentNode)) {
/*     */         
/*  85 */         if (dependentNode instanceof Runnable) {
/*  86 */           submit(dependentNode); continue;
/*     */         } 
/*  88 */         submitDependents(dependentNode);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void scheduleRoots() {
/*  95 */     for (DeferredNode node : this.graph.getRoots()) {
/*  96 */       if (node instanceof Runnable) {
/*  97 */         schedule(node);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void schedule(DeferredNode node) {
/* 104 */     boolean ready = true;
/*     */     
/* 106 */     for (DeferredNode input : node.getOperands()) {
/* 107 */       if (needsComputing(input)) {
/* 108 */         schedule(input);
/* 109 */         ready = false;
/*     */       } 
/*     */     } 
/*     */     
/* 113 */     if (ready) {
/* 114 */       submit(node);
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean needsComputing(DeferredNode input) {
/* 119 */     return !(input instanceof org.renjin.pipeliner.node.DataNode);
/*     */   }
/*     */   
/*     */   private boolean inputsComplete(DeferredNode node) {
/* 123 */     for (DeferredNode input : node.getOperands()) {
/* 124 */       if (input instanceof Runnable) {
/* 125 */         Future<DeferredNode> future = this.submitted.get(input);
/* 126 */         if (future == null || !future.isDone()) {
/* 127 */           return false;
/*     */         }
/*     */       } 
/*     */     } 
/* 131 */     return true;
/*     */   }
/*     */   
/*     */   private void submit(DeferredNode node) {
/* 135 */     Future<DeferredNode> future = this.service.submit((Runnable)node, node);
/* 136 */     this.submitted.put(node, future);
/* 137 */     this.pendingCount++;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/pipeliner/DeferredGraphEval.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */