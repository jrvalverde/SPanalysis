/*    */ package org.renjin.invoke.codegen;
/*    */ 
/*    */ import com.sun.codemodel.JBlock;
/*    */ import com.sun.codemodel.JConditional;
/*    */ import com.sun.codemodel.JExpression;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IfElseBuilder
/*    */ {
/*    */   private final JBlock block;
/*    */   private JConditional conditional;
/*    */   
/*    */   public IfElseBuilder(JBlock block) {
/* 31 */     this.block = block;
/*    */   }
/*    */   
/*    */   public JBlock _if(JExpression expr) {
/* 35 */     if (this.conditional == null) {
/* 36 */       this.conditional = this.block._if(expr);
/*    */     } else {
/* 38 */       this.conditional = this.conditional._elseif(expr);
/*    */     } 
/* 40 */     return this.conditional._then();
/*    */   }
/*    */   
/*    */   public JBlock _else() {
/* 44 */     if (this.conditional == null) {
/* 45 */       return this.block;
/*    */     }
/* 47 */     return this.conditional._else();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/codegen/IfElseBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */