/*     */ package org.renjin.compiler.builtins;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.renjin.compiler.codegen.EmitContext;
/*     */ import org.renjin.compiler.ir.ValueBounds;
/*     */ import org.renjin.compiler.ir.tac.IRArgument;
/*     */ import org.renjin.invoke.annotations.PreserveAttributeStyle;
/*     */ import org.renjin.invoke.model.JvmMethod;
/*     */ import org.renjin.primitives.Primitives;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ import org.renjin.repackaged.asm.commons.InstructionAdapter;
/*     */ import org.renjin.repackaged.guava.collect.Lists;
/*     */ import org.renjin.sexp.Null;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.Symbol;
/*     */ import org.renjin.sexp.Symbols;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataParallelCall
/*     */   implements Specialization
/*     */ {
/*     */   private final String name;
/*     */   private final JvmMethod method;
/*     */   private List<ValueBounds> argumentBounds;
/*     */   private final ValueBounds resultBounds;
/*     */   private final Type type;
/*     */   
/*     */   public DataParallelCall(Primitives.Entry primitive, JvmMethod method, List<ValueBounds> argumentBounds) {
/*  52 */     this.name = primitive.name;
/*  53 */     this.method = method;
/*  54 */     this.argumentBounds = argumentBounds;
/*  55 */     this.resultBounds = computeBounds(argumentBounds);
/*  56 */     this.type = this.resultBounds.storageType();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private ValueBounds computeBounds(List<ValueBounds> argumentBounds) {
/*  62 */     List<ValueBounds> recycledArguments = recycledArgumentBounds(argumentBounds);
/*     */     
/*  64 */     int resultLength = computeResultLength(this.argumentBounds);
/*     */     
/*  66 */     ValueBounds.Builder bounds = new ValueBounds.Builder();
/*  67 */     bounds.setType(this.method.getReturnType());
/*  68 */     bounds.setNA(anyNAs(argumentBounds));
/*  69 */     bounds.setLength(resultLength);
/*     */     
/*  71 */     switch (this.method.getPreserveAttributesStyle()) {
/*     */       case NONE:
/*  73 */         bounds.setEmptyAttributes();
/*     */         break;
/*     */       case STRUCTURAL:
/*  76 */         buildStructuralBounds(bounds, recycledArguments, resultLength);
/*     */         break;
/*     */       case ALL:
/*  79 */         buildAllBounds(bounds, recycledArguments, resultLength);
/*     */         break;
/*     */     } 
/*     */     
/*  83 */     return bounds.build();
/*     */   }
/*     */   
/*     */   private int anyNAs(List<ValueBounds> argumentBounds) {
/*  87 */     for (ValueBounds argumentBound : argumentBounds) {
/*  88 */       if (argumentBound.getNA() == 0) {
/*  89 */         return 0;
/*     */       }
/*     */     } 
/*  92 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private List<ValueBounds> recycledArgumentBounds(List<ValueBounds> argumentBounds) {
/*  99 */     List<ValueBounds> list = Lists.newArrayList();
/* 100 */     Iterator<ValueBounds> argumentIt = argumentBounds.iterator();
/* 101 */     for (JvmMethod.Argument formal : this.method.getFormals()) {
/* 102 */       if (formal.isRecycle()) {
/* 103 */         list.add(argumentIt.next());
/*     */       }
/*     */     } 
/* 106 */     return list;
/*     */   }
/*     */   
/*     */   private int computeResultLength(List<ValueBounds> argumentBounds) {
/* 110 */     Iterator<ValueBounds> it = argumentBounds.iterator();
/* 111 */     int resultLength = 0;
/*     */     
/* 113 */     while (it.hasNext()) {
/* 114 */       int argumentLength = ((ValueBounds)it.next()).getLength();
/* 115 */       if (argumentLength == -1) {
/* 116 */         return -1;
/*     */       }
/* 118 */       if (argumentLength == 0) {
/* 119 */         return 0;
/*     */       }
/* 121 */       resultLength = Math.max(resultLength, argumentLength);
/*     */     } 
/*     */     
/* 124 */     return resultLength;
/*     */   }
/*     */ 
/*     */   
/*     */   private void buildStructuralBounds(ValueBounds.Builder bounds, List<ValueBounds> argumentBounds, int resultLength) {
/* 129 */     Map<Symbol, SEXP> attributes = new HashMap<>();
/* 130 */     attributes.put(Symbols.DIM, combineAttribute(Symbols.DIM, argumentBounds, resultLength));
/* 131 */     attributes.put(Symbols.DIMNAMES, combineAttribute(Symbols.DIM, argumentBounds, resultLength));
/* 132 */     attributes.put(Symbols.NAMES, combineAttribute(Symbols.DIM, argumentBounds, resultLength));
/* 133 */     bounds.setClosedAttributes(attributes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private SEXP combineAttribute(Symbol symbol, List<ValueBounds> argumentBounds, int resultLength) {
/* 141 */     if (resultLength == -1 && argumentBounds.size() > 1) {
/* 142 */       return null;
/*     */     }
/*     */     
/* 145 */     for (ValueBounds argumentBound : argumentBounds) {
/* 146 */       if (argumentBound.getLength() == resultLength) {
/*     */         
/* 148 */         SEXP value = argumentBound.getAttributeIfConstant(symbol);
/* 149 */         if (value != Null.INSTANCE) {
/* 150 */           return value;
/*     */         }
/*     */       } 
/*     */     } 
/* 154 */     return (SEXP)Null.INSTANCE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void buildAllBounds(ValueBounds.Builder bounds, List<ValueBounds> argumentBounds, int resultLength) {
/* 163 */     if (resultLength == -1 && argumentBounds.size() > 1) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 169 */     Map<Symbol, SEXP> attributes = new HashMap<>();
/*     */     
/* 171 */     boolean open = false;
/*     */     
/* 173 */     for (ValueBounds argumentBound : argumentBounds) {
/* 174 */       if (argumentBound.getLength() == resultLength) {
/*     */         
/* 176 */         if (argumentBound.isAttributeSetOpen()) {
/* 177 */           open = true;
/*     */         }
/*     */         
/* 180 */         for (Map.Entry<Symbol, SEXP> entry : (Iterable<Map.Entry<Symbol, SEXP>>)argumentBound.getAttributeBounds().entrySet()) {
/* 181 */           if (!attributes.containsKey(entry.getKey())) {
/* 182 */             attributes.put(entry.getKey(), entry.getValue());
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 187 */     bounds.setAttributeBounds(attributes);
/* 188 */     bounds.setAttributeSetOpen(open);
/*     */   }
/*     */ 
/*     */   
/*     */   public Specialization specializeFurther() {
/* 193 */     if (this.resultBounds.getLength() == 1) {
/*     */       
/* 195 */       if (ValueBounds.allConstant(this.argumentBounds)) {
/* 196 */         return evaluateConstant();
/*     */       }
/*     */       
/* 199 */       DoubleBinaryOp op = DoubleBinaryOp.trySpecialize(this.name, this.method, this.resultBounds);
/* 200 */       if (op != null) {
/* 201 */         return op;
/*     */       }
/* 203 */       if (this.resultBounds.getNA() == 1) {
/* 204 */         return (new DataParallelScalarCall(this.method, this.argumentBounds, this.resultBounds)).trySpecializeFurther();
/*     */       }
/*     */     } 
/* 207 */     return this;
/*     */   }
/*     */   
/*     */   private Specialization evaluateConstant() {
/*     */     Object constantValue;
/* 212 */     assert !this.method.acceptsArgumentList();
/*     */     
/* 214 */     List<JvmMethod.Argument> formals = this.method.getAllArguments();
/* 215 */     Object[] args = new Object[formals.size()];
/* 216 */     Iterator<ValueBounds> it = this.argumentBounds.iterator();
/* 217 */     int argIndex = 0;
/* 218 */     for (JvmMethod.Argument formal : formals) {
/* 219 */       if (formal.isContextual()) {
/* 220 */         throw new UnsupportedOperationException("in " + this.method + ", formal: " + formal);
/*     */       }
/* 222 */       ValueBounds argument = it.next();
/* 223 */       args[argIndex++] = ConstantCall.convert(argument.getConstantValue(), formal.getClazz());
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 229 */       constantValue = this.method.getMethod().invoke(null, args);
/* 230 */     } catch (Exception e) {
/* 231 */       throw new RuntimeException(e);
/*     */     } 
/*     */     
/* 234 */     return new ConstantCall(constantValue);
/*     */   }
/*     */ 
/*     */   
/*     */   public Type getType() {
/* 239 */     return this.type;
/*     */   }
/*     */   
/*     */   public ValueBounds getResultBounds() {
/* 243 */     return this.resultBounds;
/*     */   }
/*     */ 
/*     */   
/*     */   public void load(EmitContext emitContext, InstructionAdapter mv, List<IRArgument> arguments) {
/* 248 */     throw new FailedToSpecializeException();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPure() {
/* 253 */     return this.method.isPure();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/builtins/DataParallelCall.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */