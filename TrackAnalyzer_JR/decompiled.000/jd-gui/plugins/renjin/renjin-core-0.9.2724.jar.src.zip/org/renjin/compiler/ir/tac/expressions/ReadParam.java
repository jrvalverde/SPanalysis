/*    */ package org.renjin.compiler.ir.tac.expressions;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.renjin.compiler.codegen.EmitContext;
/*    */ import org.renjin.compiler.ir.ValueBounds;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ import org.renjin.repackaged.asm.commons.InstructionAdapter;
/*    */ import org.renjin.sexp.Symbol;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReadParam
/*    */   implements Expression
/*    */ {
/*    */   private final Symbol param;
/*    */   private ValueBounds valueBounds;
/*    */   private Type type;
/*    */   
/*    */   public ReadParam(Symbol param) {
/* 37 */     this.param = param;
/* 38 */     this.valueBounds = ValueBounds.UNBOUNDED;
/* 39 */     this.type = this.valueBounds.storageType();
/*    */   }
/*    */   
/*    */   public Symbol getParam() {
/* 43 */     return this.param;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isPure() {
/* 48 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public int load(EmitContext emitContext, InstructionAdapter mv) {
/* 53 */     emitContext.loadParam(mv, this.param);
/* 54 */     return 0;
/*    */   }
/*    */ 
/*    */   
/*    */   public Type getType() {
/* 59 */     return this.type.getReturnType();
/*    */   }
/*    */   
/*    */   public void updateBounds(ValueBounds argumentBounds) {
/* 63 */     this.valueBounds = argumentBounds;
/* 64 */     this.type = argumentBounds.storageType();
/*    */   }
/*    */ 
/*    */   
/*    */   public ValueBounds updateTypeBounds(Map<Expression, ValueBounds> typeMap) {
/* 69 */     return this.valueBounds;
/*    */   }
/*    */ 
/*    */   
/*    */   public ValueBounds getValueBounds() {
/* 74 */     return this.valueBounds;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setChild(int childIndex, Expression child) {
/* 79 */     throw new IllegalArgumentException("no children");
/*    */   }
/*    */ 
/*    */   
/*    */   public int getChildCount() {
/* 84 */     return 0;
/*    */   }
/*    */ 
/*    */   
/*    */   public Expression childAt(int index) {
/* 89 */     throw new IllegalArgumentException("no children");
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 94 */     return "param(" + this.param + ")";
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/ir/tac/expressions/ReadParam.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */