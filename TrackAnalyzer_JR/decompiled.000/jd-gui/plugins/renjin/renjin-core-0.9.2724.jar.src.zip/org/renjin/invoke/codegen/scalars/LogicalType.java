/*    */ package org.renjin.invoke.codegen.scalars;
/*    */ 
/*    */ import com.sun.codemodel.JCodeModel;
/*    */ import com.sun.codemodel.JExpression;
/*    */ import org.renjin.sexp.IntVector;
/*    */ import org.renjin.sexp.Logical;
/*    */ import org.renjin.sexp.LogicalArrayVector;
/*    */ import org.renjin.sexp.LogicalVector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LogicalType
/*    */   extends ScalarType
/*    */ {
/*    */   public Class getScalarType() {
/* 33 */     return Logical.class;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getConversionMethod() {
/* 38 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   
/*    */   public String getAccessorMethod() {
/* 43 */     return "getElementAsLogical";
/*    */   }
/*    */ 
/*    */   
/*    */   public Class getVectorType() {
/* 48 */     return LogicalVector.class;
/*    */   }
/*    */ 
/*    */   
/*    */   public Class<LogicalArrayVector.Builder> getBuilderClass() {
/* 53 */     return LogicalArrayVector.Builder.class;
/*    */   }
/*    */ 
/*    */   
/*    */   public Class getBuilderArrayElementClass() {
/* 58 */     return int.class;
/*    */   }
/*    */ 
/*    */   
/*    */   public Class getArrayVectorClass() {
/* 63 */     return LogicalArrayVector.class;
/*    */   }
/*    */ 
/*    */   
/*    */   public JExpression naLiteral(JCodeModel codeModel) {
/* 68 */     return (JExpression)codeModel.ref(IntVector.class).staticRef("NA");
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/codegen/scalars/LogicalType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */