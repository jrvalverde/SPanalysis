/*     */ package org.renjin.primitives.subset;
/*     */ 
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import org.renjin.eval.EvalException;
/*     */ import org.renjin.sexp.AtomicVector;
/*     */ import org.renjin.sexp.IntVector;
/*     */ import org.renjin.sexp.SEXP;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class IndexSubscript
/*     */   implements Subscript
/*     */ {
/*     */   private AtomicVector subscript;
/*     */   private int sourceLength;
/*     */   
/*     */   public IndexSubscript(AtomicVector subscript, int sourceLength) {
/*  34 */     this.subscript = subscript;
/*  35 */     this.sourceLength = sourceLength;
/*     */   }
/*     */ 
/*     */   
/*     */   public int computeUniqueIndex() {
/*  40 */     SubsetAssertions.checkUnitLength((SEXP)this.subscript);
/*     */     
/*  42 */     int index = this.subscript.getElementAsInt(0);
/*  43 */     if (index == 0) {
/*  44 */       throw new EvalException("attempt to select less than one element", new Object[0]);
/*     */     }
/*     */     
/*  47 */     if (index > 0)
/*     */     {
/*  49 */       return index - 1;
/*     */     }
/*     */     
/*  52 */     if (index < 0) {
/*     */       
/*  54 */       int excludedIndex = -index - 1;
/*  55 */       if (this.sourceLength == 1 && excludedIndex != 0)
/*     */       {
/*  57 */         return 0;
/*     */       }
/*  59 */       if (this.sourceLength == 2) {
/*  60 */         if (excludedIndex == 0)
/*  61 */           return 1; 
/*  62 */         if (excludedIndex == 1) {
/*  63 */           return 0;
/*     */         }
/*     */       } 
/*     */     } 
/*  67 */     throw new EvalException("attempt to select more than one element", new Object[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   public IndexIterator computeIndexes() {
/*  72 */     int sign = computeIndexSign();
/*     */     
/*  74 */     if (sign == -1) {
/*  75 */       return new HashedNegativeIndexIterator();
/*     */     }
/*  77 */     if (sign == 1) {
/*  78 */       return new PositiveIndexIterator();
/*     */     }
/*     */     
/*  81 */     return EmptyIndexIterator.INSTANCE;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IndexPredicate computeIndexPredicate() {
/*  87 */     int sign = computeIndexSign();
/*     */     
/*  89 */     if (sign == -1) {
/*  90 */       return new HashedNegativeIndexPredicate();
/*     */     }
/*     */     
/*  93 */     return new PositiveHashPredicate();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int computeCount() {
/*  99 */     int count = 0;
/* 100 */     IndexIterator it = computeIndexes();
/* 101 */     while (it.next() != -1) {
/* 102 */       count++;
/*     */     }
/* 104 */     return count;
/*     */   }
/*     */   
/*     */   private int computeIndexSign() {
/* 108 */     for (int i = 0; i < this.subscript.length(); i++) {
/* 109 */       int index = this.subscript.getElementAsInt(i);
/* 110 */       if (IntVector.isNA(index)) {
/* 111 */         return 1;
/*     */       }
/* 113 */       if (index != 0) {
/*     */ 
/*     */         
/* 116 */         if (index < 0) {
/* 117 */           return -1;
/*     */         }
/* 119 */         if (index > 0)
/* 120 */           return 1; 
/*     */       } 
/*     */     } 
/* 123 */     return 0;
/*     */   }
/*     */   
/*     */   private Set<Integer> buildExcludedSet() {
/* 127 */     Set<Integer> excludedSet = new HashSet<>();
/* 128 */     for (int i = 0; i < this.subscript.length(); i++) {
/* 129 */       int subscript = this.subscript.getElementAsInt(i);
/* 130 */       if (subscript < 0) {
/* 131 */         int excludedIndex = -subscript - 1;
/* 132 */         excludedSet.add(Integer.valueOf(excludedIndex));
/* 133 */       } else if (subscript != 0) {
/* 134 */         throw new EvalException("only 0's may be mixed with negative subscripts", new Object[0]);
/*     */       } 
/*     */     } 
/* 137 */     return excludedSet;
/*     */   }
/*     */   
/*     */   private class HashedNegativeIndexIterator
/*     */     implements IndexIterator {
/* 142 */     private int nextIndex = 0;
/* 143 */     private Set<Integer> excludeSet = IndexSubscript.this.buildExcludedSet();
/*     */ 
/*     */     
/*     */     public int next() {
/*     */       while (true) {
/* 148 */         if (this.nextIndex >= IndexSubscript.this.sourceLength) {
/* 149 */           return -1;
/*     */         }
/* 151 */         if (!this.excludeSet.contains(Integer.valueOf(this.nextIndex))) {
/* 152 */           return this.nextIndex++;
/*     */         }
/* 154 */         this.nextIndex++;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void restart() {
/* 160 */       this.nextIndex = 0;
/*     */     }
/*     */     
/*     */     private HashedNegativeIndexIterator() {} }
/*     */   
/*     */   private class HashedNegativeIndexPredicate implements IndexPredicate {
/* 166 */     private Set<Integer> excludeSet = IndexSubscript.this.buildExcludedSet();
/*     */     private HashedNegativeIndexPredicate() {}
/*     */     
/*     */     public boolean apply(int index) {
/* 170 */       return this.excludeSet.contains(Integer.valueOf(index));
/*     */     }
/*     */   }
/*     */   
/*     */   private class PositiveIndexIterator
/*     */     implements IndexIterator {
/* 176 */     private int nextSubscriptIndex = 0;
/*     */ 
/*     */     
/*     */     public int next() {
/*     */       while (true) {
/* 181 */         if (this.nextSubscriptIndex >= IndexSubscript.this.subscript.length()) {
/* 182 */           return -1;
/*     */         }
/* 184 */         int nextSubscript = IndexSubscript.this.subscript.getElementAsInt(this.nextSubscriptIndex++);
/* 185 */         if (IntVector.isNA(nextSubscript)) {
/* 186 */           return nextSubscript;
/*     */         }
/* 188 */         if (nextSubscript > 0)
/*     */         {
/* 190 */           return nextSubscript - 1;
/*     */         }
/* 192 */         if (nextSubscript < 0) {
/* 193 */           throw new EvalException("only 0's may be mixed with negative subscripts", new Object[0]);
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void restart() {
/* 200 */       this.nextSubscriptIndex = 0;
/*     */     }
/*     */     
/*     */     private PositiveIndexIterator() {} }
/*     */   
/*     */   private class PositiveHashPredicate implements IndexPredicate {
/* 206 */     private Set<Integer> includeSet = new HashSet<>();
/*     */     
/*     */     public PositiveHashPredicate() {
/* 209 */       for (int i = 0; i < IndexSubscript.this.subscript.length(); i++) {
/* 210 */         int index = IndexSubscript.this.subscript.getElementAsInt(i);
/* 211 */         if (!IntVector.isNA(index) && index > 0) {
/* 212 */           this.includeSet.add(Integer.valueOf(index - 1));
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean apply(int index) {
/* 219 */       return this.includeSet.contains(Integer.valueOf(index));
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/subset/IndexSubscript.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */