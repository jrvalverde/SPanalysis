/*    */ package org.renjin.pipeliner.optimize;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.renjin.pipeliner.DeferredGraph;
/*    */ import org.renjin.pipeliner.node.DeferredNode;
/*    */ import org.renjin.pipeliner.node.FunctionNode;
/*    */ import org.renjin.repackaged.guava.collect.Lists;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Optimizers
/*    */ {
/* 29 */   List<Optimizer> optimizers = Lists.newArrayList();
/*    */   
/*    */   public Optimizers() {
/* 32 */     if (System.getProperty("renjin.vp.disableopt") == null) {
/* 33 */       this.optimizers.add(new SquareOptimizer());
/* 34 */       this.optimizers.add(new IdentityRemover());
/* 35 */       this.optimizers.add(new AggregationRecycler());
/*    */     } else {
/* 37 */       System.err.println("Optimizers are disabled");
/*    */     } 
/*    */   }
/*    */   
/*    */   public void optimize(DeferredGraph graph) {
/*    */     boolean changed;
/*    */     do {
/* 44 */       changed = false;
/* 45 */       List<DeferredNode> nodes = Lists.newArrayList(graph.getNodes());
/* 46 */       for (DeferredNode node : nodes) {
/* 47 */         if (node instanceof FunctionNode) {
/* 48 */           FunctionNode computationNode = (FunctionNode)node;
/* 49 */           for (Optimizer optimizer : this.optimizers) {
/* 50 */             changed |= optimizer.optimize(graph, computationNode);
/*    */           }
/*    */         } 
/*    */       } 
/* 54 */     } while (changed);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/pipeliner/optimize/Optimizers.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */