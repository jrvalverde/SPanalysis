/*     */ package org.renjin.primitives.io.connections;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.Reader;
/*     */ import java.net.URL;
/*     */ import org.apache.commons.vfs2.FileSystemException;
/*     */ import org.renjin.eval.Context;
/*     */ import org.renjin.eval.EvalException;
/*     */ import org.renjin.invoke.annotations.Current;
/*     */ import org.renjin.invoke.annotations.Internal;
/*     */ import org.renjin.invoke.annotations.Recycle;
/*     */ import org.renjin.primitives.Identical;
/*     */ import org.renjin.primitives.text.RCharsets;
/*     */ import org.renjin.repackaged.guava.base.Charsets;
/*     */ import org.renjin.repackaged.guava.base.Joiner;
/*     */ import org.renjin.repackaged.guava.base.Strings;
/*     */ import org.renjin.sexp.AttributeMap;
/*     */ import org.renjin.sexp.Environment;
/*     */ import org.renjin.sexp.IntArrayVector;
/*     */ import org.renjin.sexp.IntVector;
/*     */ import org.renjin.sexp.ListVector;
/*     */ import org.renjin.sexp.RawVector;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.StringVector;
/*     */ import org.renjin.sexp.Symbol;
/*     */ import org.renjin.sexp.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Connections
/*     */ {
/*     */   private static final String STD_OUT = "stdout";
/*     */   private static final String STD_IN = "stdin";
/*     */   private static final String STD_ERR = "stderr";
/*     */   
/*     */   @Internal
/*     */   public static IntVector gzfile(@Current Context context, String path, String open, String encoding, double compressionLevel) throws IOException {
/*  77 */     return newConnection(context, open, new GzFileConnection(context.resolveFile(path), RCharsets.getByName(encoding)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Internal
/*     */   public static IntVector xzfile(@Current Context context, String path, String open, String encoding, double compressionLevel) throws IOException {
/*  85 */     return newConnection(context, open, new XzFileConnection(context.resolveFile(path), RCharsets.getByName(encoding)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Internal
/*     */   public static IntVector bzfile(@Current Context context, String path, String open, String encoding, double compressionLevel) throws IOException {
/*  94 */     return newConnection(context, open, new BzipFileConnection(context.resolveFile(path), RCharsets.getByName(encoding)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Internal
/*     */   public static IntVector file(@Current Context context, String path, String open, boolean blocking, String encoding, boolean raw) throws IOException {
/* 125 */     if (path.isEmpty())
/* 126 */       return newConnection(context, open, new SingleThreadedFifoConnection()); 
/* 127 */     if ("stdout".equals(path))
/* 128 */       return stdout(context); 
/* 129 */     if ("stdin".equals(path))
/* 130 */       return stdin(context); 
/* 131 */     if ("stderr".equals(path))
/* 132 */       return stderr(context); 
/* 133 */     if (path.startsWith("http://") || path.startsWith("https://")) {
/* 134 */       return url(context, path, open, blocking, encoding);
/*     */     }
/* 136 */     return newConnection(context, open, new FileConnection(context.resolveFile(path), RCharsets.getByName(encoding)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Internal
/*     */   public static IntVector url(@Current Context context, String description, String open, boolean blocking, String encoding) throws IOException {
/* 144 */     return newConnection(context, open, new UrlConnection(new URL(description), RCharsets.getByName(encoding)));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Internal
/*     */   public static IntVector textConnection(@Current Context context, String objectName, StringVector object, String open, Environment env, String type) throws IOException {
/* 151 */     OpenSpec openSpec = new OpenSpec(open);
/* 152 */     if (openSpec.forWriting()) {
/* 153 */       return newConnection(context, open, new WriteTextConnection(Symbol.get(object.asString()), env));
/*     */     }
/* 155 */     return newConnection(context, open, new ReadTextConnection(objectName, Joiner.on('\n').join((Iterable)object)));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Internal
/*     */   public static IntVector stdin(@Current Context context) {
/* 162 */     return terminal(0);
/*     */   }
/*     */   
/*     */   @Internal
/*     */   public static IntVector stdout(@Current Context context) {
/* 167 */     return terminal(1);
/*     */   }
/*     */   
/*     */   @Internal
/*     */   public static IntVector stderr(@Current Context context) {
/* 172 */     return terminal(2);
/*     */   }
/*     */   
/*     */   @Internal
/*     */   public static boolean isatty(@Current Context context, SEXP connHandle) {
/* 177 */     int connectionIndex = getConnectionIndex(connHandle);
/*     */     
/* 179 */     return ((connectionIndex == 0 || connectionIndex == 2 || connectionIndex == 1) && context
/*     */ 
/*     */       
/* 182 */       .getSession().getSessionController().isTerminal());
/*     */   }
/*     */   
/*     */   private static IntVector terminal(int index) {
/* 186 */     return (IntVector)new IntArrayVector(new int[] { index
/* 187 */         }, AttributeMap.builder()
/* 188 */         .setClass(new String[] { "connection", "terminal"
/* 189 */           }).build());
/*     */   }
/*     */ 
/*     */   
/*     */   @Internal("summary.connection")
/*     */   public static ListVector summaryConnection(@Current Context context, SEXP connHandle) {
/* 195 */     ListVector.NamedBuilder result = new ListVector.NamedBuilder();
/* 196 */     Connection connection = getConnection(context, connHandle);
/* 197 */     result.add("description", connection.getDescription());
/* 198 */     result.add("class", connection.getClassName());
/* 199 */     result.add("mode", connection.getMode());
/* 200 */     result.add("text", (connection.getType() == Connection.Type.TEXT) ? "text" : "binary");
/* 201 */     result.add("opened", connection.isOpen() ? "opened" : "closed");
/* 202 */     result.add("can read", connection.canRead() ? "yes" : "no");
/* 203 */     result.add("can write", connection.canWrite() ? "yes" : "no");
/* 204 */     return result.build();
/*     */   }
/*     */   
/*     */   @Internal
/*     */   public static void close(@Current Context context, SEXP conn, String type) throws IOException {
/* 209 */     close(context, conn);
/*     */   }
/*     */   
/*     */   public static void close(@Current Context context, SEXP conn) throws IOException {
/* 213 */     int connIndex = getConnectionIndex(conn);
/* 214 */     context.getSession().getConnectionTable().close(connIndex);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Internal
/*     */   public static String readChar(@Current Context context, SEXP connIndex, int nchars, @Recycle(false) boolean useBytes) throws IOException {
/* 221 */     Connection conn = getConnection(context, connIndex);
/*     */     
/* 223 */     if (useBytes) {
/* 224 */       byte[] bytes = new byte[nchars];
/* 225 */       DataInputStream dis = new DataInputStream(conn.getInputStream());
/* 226 */       dis.readFully(bytes);
/* 227 */       return new String(bytes, Charsets.UTF_8);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 232 */     Reader in = conn.getReader();
/* 233 */     StringBuilder result = new StringBuilder();
/* 234 */     for (int i = 0; i != nchars; i++) {
/* 235 */       result.appendCodePoint(in.read());
/*     */     }
/* 237 */     return result.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Internal("readLines")
/*     */   public static StringVector readLines(@Current Context context, SEXP connection, int numLines, boolean ok, boolean warn, String encoding) throws IOException {
/* 245 */     PushbackBufferedReader reader = getConnection(context, connection).getReader();
/* 246 */     StringVector.Builder lines = new StringVector.Builder();
/*     */     String line;
/* 248 */     while ((line = reader.readLine()) != null) {
/* 249 */       lines.add(line);
/* 250 */       if (numLines > 0 && lines.length() == numLines) {
/*     */         break;
/*     */       }
/*     */     } 
/*     */     
/* 255 */     if (numLines > 0 && lines
/* 256 */       .length() < numLines && !ok)
/*     */     {
/*     */       
/* 259 */       throw new EvalException("too few lines read in readLines", new Object[0]);
/*     */     }
/*     */     
/* 262 */     return (StringVector)lines.build();
/*     */   }
/*     */   
/*     */   @Internal
/*     */   public static Vector readBin(@Current Context context, SEXP connIndex, SEXP what, int n, int size, boolean signed, boolean swap) throws IOException {
/*     */     BinaryReader reader;
/* 268 */     if (connIndex instanceof RawVector) {
/* 269 */       reader = new BinaryReader((RawVector)connIndex);
/*     */     } else {
/* 271 */       Connection connection = getConnection(context, connIndex);
/* 272 */       InputStream inputStream = connection.getInputStream();
/* 273 */       reader = new BinaryReader(inputStream);
/*     */     } 
/*     */     
/* 276 */     String typeName = what.asString();
/* 277 */     switch (typeName) {
/*     */       case "integer":
/* 279 */         return reader.readIntVector(n, size, signed, swap);
/*     */       case "double":
/* 281 */         return reader.readDoubleVector(n, size, swap);
/*     */       case "complex":
/* 283 */         return reader.readComplexVector(n, size, swap);
/*     */       case "character":
/* 285 */         return reader.readCharacterVector(n, size, swap);
/*     */       case "raw":
/* 287 */         return reader.readRaw(n, size);
/*     */     } 
/* 289 */     throw new EvalException("Unsupported/unimplemented type: " + typeName, new Object[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   @Internal
/*     */   public static void writeBin(@Current Context context, SEXP object, SEXP con, int size, boolean swap, boolean useBytes) throws IOException {
/* 295 */     if (con instanceof IntVector) {
/* 296 */       Connection connection = getConnection(context, con);
/* 297 */       if (object instanceof RawVector) {
/* 298 */         connection.getOutputStream().write(((RawVector)object).toByteArrayUnsafe());
/*     */       } else {
/* 300 */         throw new UnsupportedOperationException("TODO: typeof(object) = %s" + object.getTypeName());
/*     */       } 
/*     */     } else {
/* 303 */       throw new EvalException("TODO: typeof(con) = %s" + con.getTypeName(), new Object[0]);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @Internal("writeLines")
/*     */   public static void writeLines(@Current Context context, StringVector x, SEXP connIndex, String seperator, boolean useBytes) throws IOException {
/* 310 */     PrintWriter writer = getConnection(context, connIndex).getPrintWriter();
/* 311 */     for (String line : x) {
/* 312 */       writer.print(line);
/* 313 */       writer.print(seperator);
/*     */     } 
/* 315 */     writer.flush();
/*     */   }
/*     */ 
/*     */   
/*     */   @Internal("socketConnection")
/*     */   public static IntVector socketConnection(@Current Context context, String host, double port) throws IOException {
/* 321 */     return newConnection(context, "", new SocketConnection(host, (int)port));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Internal
/*     */   public static void sink(@Current Context context, SEXP connection, boolean closeOnExit, boolean messages, boolean split) throws IOException {
/*     */     StdOutConnection source;
/* 330 */     ConnectionTable table = context.getSession().getConnectionTable();
/*     */ 
/*     */     
/* 333 */     if (messages) {
/* 334 */       source = table.getStderr();
/*     */     } else {
/* 336 */       source = table.getStdout();
/*     */     } 
/*     */     
/* 339 */     if (Identical.identical(connection, (SEXP)new IntArrayVector(new int[] { -1 }))) {
/* 340 */       Sink sink = source.clearSink();
/* 341 */       if (sink != null && sink.isCloseOnExit()) {
/* 342 */         context.getSession().getConnectionTable().close(sink.getConnection());
/*     */       }
/*     */     } else {
/* 345 */       Connection sinkConnection = getConnection(context, connection);
/* 346 */       source.sink(new Sink(sinkConnection, split, closeOnExit));
/*     */     } 
/*     */   }
/*     */   
/*     */   @Internal("sink.number")
/*     */   public static int sinkNumber(@Current Context context, boolean output) {
/*     */     StdOutConnection source;
/* 353 */     if (output) {
/* 354 */       source = context.getSession().getConnectionTable().getStdout();
/*     */     } else {
/* 356 */       source = context.getSession().getConnectionTable().getStderr();
/*     */     } 
/* 358 */     return source.getSinkStackHeight();
/*     */   }
/*     */   
/*     */   @Internal
/*     */   public static void open(@Current Context context, SEXP conn, String open, boolean blocking) throws IOException {
/* 363 */     getConnection(context, conn).open(new OpenSpec(open));
/*     */   }
/*     */ 
/*     */   
/*     */   @Internal
/*     */   public static boolean isOpen(@Current Context context, SEXP conn, String rw) {
/* 369 */     return getConnection(context, conn).isOpen();
/*     */   }
/*     */   
/*     */   @Internal
/*     */   public static void pushBack(@Current Context context, Vector data, SEXP connection, boolean newLine) throws IOException {
/* 374 */     PushbackBufferedReader reader = getConnection(context, connection).getReader();
/* 375 */     String suffix = newLine ? "\n" : "";
/* 376 */     for (int i = data.length() - 1; i >= 0; i--) {
/* 377 */       if (data.isElementNA(i)) {
/* 378 */         reader.pushBack("NA" + suffix);
/*     */       } else {
/* 380 */         reader.pushBack(data.getElementAsString(i) + suffix);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   @Internal
/*     */   public static void flush(@Current Context context, SEXP connection) throws IOException {
/* 387 */     getConnection(context, connection).flush();
/*     */   }
/*     */   
/*     */   @Internal
/*     */   public static int pushBackLength(@Current Context context, SEXP connection) throws IOException {
/* 392 */     PushbackBufferedReader reader = getConnection(context, connection).getReader();
/* 393 */     return reader.countLinesPushedBack();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Connection getConnection(Context context, SEXP conn) {
/* 405 */     int connIndex = getConnectionIndex(conn);
/* 406 */     return context.getSession().getConnectionTable().getConnection(connIndex);
/*     */   }
/*     */   
/*     */   private static int getConnectionIndex(SEXP conn) {
/* 410 */     if (!conn.inherits("connection") || !(conn instanceof Vector) || conn.length() != 1) {
/* 411 */       throw new EvalException("'con' is not a connection", new Object[0]);
/*     */     }
/* 413 */     return ((Vector)conn).getElementAsInt(0);
/*     */   }
/*     */   
/*     */   private static IntVector newConnection(Context context, String open, Connection conn) throws IOException, FileSystemException {
/* 417 */     if (!Strings.isNullOrEmpty(open)) {
/* 418 */       conn.open(new OpenSpec(open));
/*     */     }
/* 420 */     return context.getSession().getConnectionTable().newConnection(conn);
/*     */   }
/*     */ 
/*     */   
/*     */   @Internal
/*     */   public static boolean isIncomplete(@Current Context context, SEXP conn) throws IOException {
/* 426 */     Connection con = getConnection(context, conn);
/*     */     
/* 428 */     return con.isIncomplete();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/io/connections/Connections.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */