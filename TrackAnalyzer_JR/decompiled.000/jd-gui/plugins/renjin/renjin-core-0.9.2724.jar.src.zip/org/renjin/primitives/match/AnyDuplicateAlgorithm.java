/*    */ package org.renjin.primitives.match;
/*    */ 
/*    */ import org.renjin.sexp.Vector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AnyDuplicateAlgorithm
/*    */   implements DuplicateSearchAlgorithm<Integer>
/*    */ {
/*    */   public int firstDuplicatedIndex;
/*    */   
/*    */   public void init(Vector source) {
/* 29 */     this.firstDuplicatedIndex = 0;
/*    */   }
/*    */ 
/*    */   
/*    */   public void onUnique(int index) {}
/*    */ 
/*    */   
/*    */   public DuplicateSearchAlgorithm.Action onDuplicate(int duplicateIndex, int originalIndex) {
/* 37 */     this.firstDuplicatedIndex = duplicateIndex + 1;
/* 38 */     return DuplicateSearchAlgorithm.Action.STOP;
/*    */   }
/*    */ 
/*    */   
/*    */   public Integer getResult() {
/* 43 */     return Integer.valueOf(this.firstDuplicatedIndex);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/match/AnyDuplicateAlgorithm.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */