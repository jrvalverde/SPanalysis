/*     */ package org.renjin.primitives.io.serialization;
/*     */ 
/*     */ import org.renjin.sexp.AttributeMap;
/*     */ import org.renjin.sexp.Null;
/*     */ import org.renjin.sexp.PairList;
/*     */ import org.renjin.sexp.Promise;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.Symbol;
/*     */ import org.renjin.sexp.Symbols;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Flags
/*     */ {
/*     */   public static final int MAX_PACKED_INDEX = 8388607;
/*  29 */   static final Symbol OLD_S4_BIT = Symbol.get("__S4_BIT");
/*     */ 
/*     */   
/*     */   static final boolean WRITE_OLD_S4_ATTRIBUTE = true;
/*     */ 
/*     */   
/*     */   private static final int IS_OBJECT_BIT_MASK = 256;
/*     */   
/*     */   private static final int HAS_ATTR_BIT_MASK = 512;
/*     */   
/*     */   private static final int HAS_TAG_BIT_MASK = 1024;
/*     */   
/*     */   private static final int S4_BIT_MASK = 65536;
/*     */   
/*     */   private static final int ACTIVE_BINDING_MASK = 134217728;
/*     */ 
/*     */   
/*     */   public static int getType(int flags) {
/*  47 */     return flags & 0xFF;
/*     */   }
/*     */   
/*     */   public static int getLevels(int flags) {
/*  51 */     return flags >> 12;
/*     */   }
/*     */   
/*     */   public static boolean hasAttributes(int flags) {
/*  55 */     return ((flags & 0x200) == 512);
/*     */   }
/*     */   
/*     */   public static boolean hasTag(int flags) {
/*  59 */     return ((flags & 0x400) == 1024);
/*     */   }
/*     */   
/*     */   public static boolean isActiveBinding(int flags) {
/*  63 */     return ((flags & 0x8000000) == 134217728);
/*     */   }
/*     */   
/*     */   public static boolean isS4(int flags) {
/*  67 */     return ((flags & 0x10000) == 65536);
/*     */   }
/*     */   
/*     */   public static boolean isUTF8Encoded(int flags) {
/*  71 */     return ((getLevels(flags) & 0x8) == 8);
/*     */   }
/*     */   
/*     */   public static boolean isLatin1Encoded(int flags) {
/*  75 */     return ((getLevels(flags) & 0x4) == 4);
/*     */   }
/*     */   
/*     */   public static int unpackRefIndex(int flags) {
/*  79 */     return flags >> 8;
/*     */   }
/*     */   
/*     */   public static int computeBindingFlag(boolean activeBinding) {
/*  83 */     int flags = 2;
/*  84 */     flags |= 0x400;
/*  85 */     if (activeBinding) {
/*  86 */       flags |= 0x8000000;
/*     */     }
/*  88 */     return flags;
/*     */   }
/*     */   
/*     */   public static int computeFlags(SEXP exp, int type) {
/*  92 */     int flags = type;
/*     */     
/*  94 */     if (exp.getAttribute(Symbols.CLASS) != Null.INSTANCE) {
/*  95 */       flags |= 0x100;
/*     */     }
/*  97 */     if (hasAttributesToWrite(exp)) {
/*  98 */       flags |= 0x200;
/*     */     }
/* 100 */     if (exp instanceof PairList.Node && ((PairList.Node)exp).hasTag()) {
/* 101 */       flags |= 0x400;
/*     */     }
/* 103 */     if ((exp instanceof org.renjin.sexp.Closure | exp instanceof org.renjin.sexp.Environment) != 0) {
/* 104 */       flags |= 0x400;
/*     */     }
/* 106 */     if (exp.getAttributes().isS4()) {
/* 107 */       flags |= 0x10000;
/*     */     }
/* 109 */     return flags;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean hasAttributesToWrite(SEXP exp) {
/* 120 */     return (exp.getAttributes() != AttributeMap.EMPTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int computePromiseFlags(Promise promise) {
/* 127 */     int flags = 5;
/*     */     
/* 129 */     if (promise.getAttributes() != AttributeMap.EMPTY) {
/* 130 */       flags |= 0x200;
/*     */     }
/* 132 */     if (promise.getEnvironment() != null) {
/* 133 */       flags |= 0x400;
/*     */     }
/* 135 */     return flags;
/*     */   }
/*     */   
/*     */   public static int computeCharSexpFlags(int encodingFlag) {
/* 139 */     return 0x9 | encodeLevels(encodingFlag);
/*     */   }
/*     */   
/*     */   private static int encodeLevels(int value) {
/* 143 */     return value << 12;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/io/serialization/Flags.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */