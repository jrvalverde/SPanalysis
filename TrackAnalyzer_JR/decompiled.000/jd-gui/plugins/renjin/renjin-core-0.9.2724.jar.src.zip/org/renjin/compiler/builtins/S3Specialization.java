/*     */ package org.renjin.compiler.builtins;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.renjin.compiler.cfg.InlinedFunction;
/*     */ import org.renjin.compiler.codegen.EmitContext;
/*     */ import org.renjin.compiler.ir.ValueBounds;
/*     */ import org.renjin.compiler.ir.tac.IRArgument;
/*     */ import org.renjin.compiler.ir.tac.RuntimeState;
/*     */ import org.renjin.compiler.ir.tac.expressions.Expression;
/*     */ import org.renjin.eval.MatchedArgumentPositions;
/*     */ import org.renjin.primitives.S3;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ import org.renjin.repackaged.asm.commons.InstructionAdapter;
/*     */ import org.renjin.sexp.Closure;
/*     */ import org.renjin.sexp.Function;
/*     */ import org.renjin.sexp.StringVector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class S3Specialization
/*     */   implements Specialization
/*     */ {
/*     */   private RuntimeState runtimeState;
/*     */   private Closure closure;
/*  44 */   private InlinedFunction inlinedMethod = null;
/*     */   
/*     */   private MatchedArgumentPositions matchedArguments;
/*     */   private Type type;
/*     */   private ValueBounds returnBounds;
/*     */   
/*     */   public S3Specialization(RuntimeState runtimeState, Closure closure, List<ArgumentBounds> arguments) {
/*  51 */     this.runtimeState = runtimeState;
/*  52 */     this.closure = closure;
/*     */     
/*  54 */     updateTypeBounds(closure, arguments);
/*     */   }
/*     */   
/*     */   public S3Specialization(RuntimeState runtimeState, Closure closure, Map<Expression, ValueBounds> typeMap, List<IRArgument> arguments) {
/*  58 */     this(runtimeState, closure, ArgumentBounds.create(arguments, typeMap));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateTypeBounds(Closure function, List<ArgumentBounds> arguments) {
/*  64 */     if (this.inlinedMethod == null || this.inlinedMethod.getClosure() != function) {
/*  65 */       this.matchedArguments = MatchedArgumentPositions.matchArgumentBounds(this.closure, arguments);
/*  66 */       this.inlinedMethod = new InlinedFunction(this.runtimeState, this.closure, this.matchedArguments.getSuppliedFormals());
/*     */     } 
/*     */     
/*  69 */     if (this.matchedArguments.hasExtraArguments()) {
/*  70 */       throw new FailedToSpecializeException("Extra arguments not supported");
/*     */     }
/*     */     
/*  73 */     this.returnBounds = this.inlinedMethod.updateBounds(arguments);
/*  74 */     this.type = this.returnBounds.storageType();
/*     */   }
/*     */   
/*     */   public static Specialization trySpecialize(String generic, RuntimeState runtimeState, ValueBounds objectExpr, List<ArgumentBounds> arguments) {
/*  78 */     StringVector objectClass = S3.computeDataClasses(objectExpr);
/*     */     
/*  80 */     if (objectClass == null)
/*     */     {
/*  82 */       return UnspecializedCall.INSTANCE;
/*     */     }
/*     */ 
/*     */     
/*  86 */     Function function = runtimeState.findMethod(generic, null, objectClass);
/*  87 */     if (function instanceof Closure) {
/*  88 */       return new S3Specialization(runtimeState, (Closure)function, arguments);
/*     */     }
/*     */     
/*  91 */     return UnspecializedCall.INSTANCE;
/*     */   }
/*     */ 
/*     */   
/*     */   public Type getType() {
/*  96 */     return this.type;
/*     */   }
/*     */ 
/*     */   
/*     */   public ValueBounds getResultBounds() {
/* 101 */     return this.returnBounds;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void load(EmitContext emitContext, InstructionAdapter mv, List<IRArgument> arguments) {
/* 107 */     if (this.inlinedMethod == null) {
/* 108 */       throw new FailedToSpecializeException("Could not resolve S3 method");
/*     */     }
/*     */     
/* 111 */     if (this.matchedArguments.hasExtraArguments()) {
/* 112 */       throw new FailedToSpecializeException("Extra arguments not supported");
/*     */     }
/*     */     
/* 115 */     this.inlinedMethod.writeInline(emitContext, mv, this.matchedArguments, arguments);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isPure() {
/* 121 */     if (this.inlinedMethod == null) {
/* 122 */       return false;
/*     */     }
/* 124 */     return this.inlinedMethod.isPure();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/builtins/S3Specialization.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */