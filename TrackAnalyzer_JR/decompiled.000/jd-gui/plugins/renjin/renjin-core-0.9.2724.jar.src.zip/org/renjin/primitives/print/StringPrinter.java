/*    */ package org.renjin.primitives.print;
/*    */ 
/*    */ import org.renjin.parser.StringLiterals;
/*    */ import org.renjin.repackaged.guava.base.Function;
/*    */ import org.renjin.sexp.StringVector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StringPrinter
/*    */   implements Function<String, String>
/*    */ {
/* 26 */   private char quote = Character.MIN_VALUE;
/* 27 */   private String naString = "NA";
/* 28 */   private int width = -1;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public StringPrinter setQuotes(boolean quote) {
/* 35 */     if (quote) {
/* 36 */       this.quote = '"';
/*    */     } else {
/* 38 */       this.quote = Character.MIN_VALUE;
/*    */     } 
/* 40 */     return this;
/*    */   }
/*    */   
/*    */   public StringPrinter setNaString(String naString) {
/* 44 */     this.naString = naString;
/* 45 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public String apply(String s) {
/* 50 */     StringBuilder sb = new StringBuilder();
/* 51 */     if (StringVector.isNA(s)) {
/* 52 */       return this.naString;
/*    */     }
/* 54 */     if (this.quote != '\000') {
/* 55 */       sb.append(this.quote);
/*    */     }
/* 57 */     StringLiterals.appendEscaped(sb, s);
/* 58 */     if (this.quote != '\000') {
/* 59 */       sb.append(this.quote);
/*    */     }
/* 61 */     return sb.toString();
/*    */   }
/*    */   
/*    */   public void setQuote(char quote) {
/* 65 */     this.quote = quote;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/print/StringPrinter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */