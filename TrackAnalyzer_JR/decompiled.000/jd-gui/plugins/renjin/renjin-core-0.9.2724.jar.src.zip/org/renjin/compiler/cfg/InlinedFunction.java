/*     */ package org.renjin.compiler.cfg;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.renjin.compiler.TypeSolver;
/*     */ import org.renjin.compiler.builtins.ArgumentBounds;
/*     */ import org.renjin.compiler.codegen.ByteCodeEmitter;
/*     */ import org.renjin.compiler.codegen.EmitContext;
/*     */ import org.renjin.compiler.codegen.InlineEmitContext;
/*     */ import org.renjin.compiler.codegen.InlineParamExpr;
/*     */ import org.renjin.compiler.ir.ValueBounds;
/*     */ import org.renjin.compiler.ir.ssa.SsaTransformer;
/*     */ import org.renjin.compiler.ir.tac.IRArgument;
/*     */ import org.renjin.compiler.ir.tac.IRBody;
/*     */ import org.renjin.compiler.ir.tac.IRBodyBuilder;
/*     */ import org.renjin.compiler.ir.tac.RuntimeState;
/*     */ import org.renjin.compiler.ir.tac.expressions.ReadParam;
/*     */ import org.renjin.compiler.ir.tac.statements.ReturnStatement;
/*     */ import org.renjin.compiler.ir.tac.statements.Statement;
/*     */ import org.renjin.eval.MatchedArgumentPositions;
/*     */ import org.renjin.repackaged.asm.MethodVisitor;
/*     */ import org.renjin.repackaged.asm.commons.InstructionAdapter;
/*     */ import org.renjin.repackaged.guava.collect.Lists;
/*     */ import org.renjin.sexp.Closure;
/*     */ import org.renjin.sexp.Function;
/*     */ import org.renjin.sexp.Symbol;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InlinedFunction
/*     */ {
/*     */   private final RuntimeState runtimeState;
/*     */   private final SsaTransformer ssaTransformer;
/*     */   private final DominanceTree dTree;
/*     */   private final ControlFlowGraph cfg;
/*     */   private final UseDefMap useDefMap;
/*     */   private final TypeSolver types;
/*     */   private final List<ReadParam> params;
/*  60 */   private List<ReturnStatement> returnStatements = Lists.newArrayList();
/*     */ 
/*     */   
/*     */   private Closure closure;
/*     */ 
/*     */ 
/*     */   
/*     */   public InlinedFunction(RuntimeState parentState, Closure closure, Set<Symbol> arguments) {
/*  68 */     this.closure = closure;
/*     */     
/*  70 */     this.runtimeState = new RuntimeState(parentState, closure.getEnclosingEnvironment());
/*     */     
/*  72 */     IRBodyBuilder builder = new IRBodyBuilder(this.runtimeState);
/*  73 */     IRBody body = builder.buildFunctionBody(closure, arguments);
/*     */     
/*  75 */     this.cfg = new ControlFlowGraph(body);
/*  76 */     this.dTree = new DominanceTree(this.cfg);
/*  77 */     this.ssaTransformer = new SsaTransformer(this.cfg, this.dTree);
/*  78 */     this.ssaTransformer.transform();
/*  79 */     this.useDefMap = new UseDefMap(this.cfg);
/*  80 */     this.types = new TypeSolver(this.cfg, this.useDefMap);
/*  81 */     this.params = body.getParams();
/*     */     
/*  83 */     for (Statement statement : body.getStatements()) {
/*  84 */       if (statement instanceof ReturnStatement) {
/*  85 */         this.returnStatements.add((ReturnStatement)statement);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public ControlFlowGraph getCfg() {
/*  92 */     return this.cfg;
/*     */   }
/*     */   
/*     */   public SsaTransformer getSsaTransformer() {
/*  96 */     return this.ssaTransformer;
/*     */   }
/*     */   
/*     */   public List<ReadParam> getParams() {
/* 100 */     return this.params;
/*     */   }
/*     */ 
/*     */   
/*     */   public void updateParam(int i, ValueBounds argumentBounds) {
/* 105 */     ((ReadParam)this.params.get(i)).updateBounds(argumentBounds);
/*     */   }
/*     */   
/*     */   public ValueBounds updateBounds(List<ArgumentBounds> arguments) {
/* 109 */     for (int i = 0; i < arguments.size(); i++) {
/* 110 */       updateParam(i, ((ArgumentBounds)arguments.get(i)).getBounds());
/*     */     }
/* 112 */     return computeBounds();
/*     */   }
/*     */ 
/*     */   
/*     */   public ValueBounds computeBounds() {
/* 117 */     this.types.execute();
/*     */     
/* 119 */     List<ValueBounds> returnBounds = new ArrayList<>();
/* 120 */     for (ReturnStatement returnStatement : this.returnStatements) {
/* 121 */       returnBounds.add(returnStatement.getRHS().getValueBounds());
/*     */     }
/* 123 */     return ValueBounds.union(returnBounds);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isPure() {
/* 131 */     return this.types.isPure();
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeInline(EmitContext emitContext, InstructionAdapter mv, MatchedArgumentPositions matching, List<IRArgument> arguments) {
/* 136 */     InlineEmitContext inlineContext = emitContext.inlineContext(this.cfg, this.types);
/*     */     
/* 138 */     for (Map.Entry<Symbol, Integer> formal : (Iterable<Map.Entry<Symbol, Integer>>)matching.getMatchedFormals().entrySet()) {
/* 139 */       inlineContext.setInlineParameter(formal.getKey(), new InlineParamExpr(emitContext, ((IRArgument)arguments
/* 140 */             .get(((Integer)formal.getValue()).intValue())).getExpression()));
/*     */     }
/*     */ 
/*     */     
/* 144 */     this.types.verifyFunctionAssumptions(this.runtimeState);
/*     */     
/* 146 */     ByteCodeEmitter.writeBody((EmitContext)inlineContext, (MethodVisitor)mv, this.cfg);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(EmitContext emitContext, InstructionAdapter mv) {
/* 153 */     this.types.verifyFunctionAssumptions(this.runtimeState);
/*     */     
/* 155 */     ByteCodeEmitter.writeBody(emitContext, (MethodVisitor)mv, this.cfg);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 162 */     return this.cfg.toString();
/*     */   }
/*     */   
/*     */   public TypeSolver getTypes() {
/* 166 */     return this.types;
/*     */   }
/*     */   
/*     */   public Function getClosure() {
/* 170 */     return (Function)this.closure;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/cfg/InlinedFunction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */