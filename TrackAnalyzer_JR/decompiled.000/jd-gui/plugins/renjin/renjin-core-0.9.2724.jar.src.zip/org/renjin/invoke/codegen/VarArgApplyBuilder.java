/*     */ package org.renjin.invoke.codegen;
/*     */ 
/*     */ import com.sun.codemodel.JAssignmentTarget;
/*     */ import com.sun.codemodel.JBlock;
/*     */ import com.sun.codemodel.JCodeModel;
/*     */ import com.sun.codemodel.JDefinedClass;
/*     */ import com.sun.codemodel.JExpr;
/*     */ import com.sun.codemodel.JExpression;
/*     */ import com.sun.codemodel.JInvocation;
/*     */ import com.sun.codemodel.JType;
/*     */ import com.sun.codemodel.JVar;
/*     */ import com.sun.codemodel.JWhileLoop;
/*     */ import org.renjin.invoke.codegen.args.ArgConverterStrategies;
/*     */ import org.renjin.invoke.model.JvmMethod;
/*     */ import org.renjin.invoke.model.PrimitiveModel;
/*     */ import org.renjin.sexp.SEXP;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VarArgApplyBuilder
/*     */   extends ApplyMethodBuilder
/*     */ {
/*     */   private VarArgParser parser;
/*     */   
/*     */   public VarArgApplyBuilder(JCodeModel codeModel, JDefinedClass invoker, PrimitiveModel primitive) {
/*  35 */     super(codeModel, invoker, primitive);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void apply(JBlock parent) {
/*  40 */     JvmMethod overload = this.primitive.getOverloads().get(0);
/*     */     
/*  42 */     this.parser = new VarArgParser(this, parent, overload);
/*     */     
/*  44 */     convertArgs(this.parser.getArgumentProcessingBlock());
/*     */ 
/*     */     
/*  47 */     this.genericDispatchStrategy.beforePrimitiveCalled(parent, this.parser, this, (JExpression)this.call);
/*     */ 
/*     */     
/*  50 */     JInvocation invocation = classRef(overload.getDeclaringClass()).staticInvoke(overload.getName());
/*  51 */     for (JExpression argument : this.parser.getArguments()) {
/*  52 */       invocation.arg(argument);
/*     */     }
/*     */     
/*  55 */     CodeModelUtils.returnSexp(this.context, this.codeModel, parent, overload, invocation);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void convertArgs(JBlock parent) {
/*  62 */     int posIndex = 0;
/*  63 */     for (VarArgParser.PositionalArg posArgument : this.parser.getPositionalArguments()) {
/*  64 */       parent.assign((JAssignmentTarget)posArgument.getVariable(), convert(posArgument.getFormal(), nextArgAsSexp(posArgument.getFormal().isEvaluated())));
/*  65 */       if (posIndex == 0) {
/*  66 */         this.genericDispatchStrategy.afterFirstArgIsEvaluated(this, (JExpression)this.call, (JExpression)this.args, parent, (JExpression)posArgument.getVariable());
/*     */       }
/*  68 */       posIndex++;
/*     */     } 
/*     */     
/*  71 */     JVar firstArgVar = parent.decl((JType)this.codeModel.BOOLEAN, "firstArg", JExpr.TRUE);
/*     */ 
/*     */     
/*  74 */     JWhileLoop loop = parent._while(hasMoreArguments());
/*  75 */     matchVarArg(firstArgVar, loop.body());
/*     */   }
/*     */ 
/*     */   
/*     */   private void matchVarArg(JVar firstArgVar, JBlock block) {
/*     */     JInvocation jInvocation;
/*  81 */     if (this.primitive.isMissingAllowedInVarArgs()) {
/*  82 */       jInvocation = this.argumentIterator.invoke("evalNextOrMissing");
/*     */     } else {
/*  84 */       jInvocation = this.argumentIterator.invoke("evalNext");
/*     */     } 
/*     */     
/*  87 */     JVar evaluated = block.decl((JType)classRef(SEXP.class), "evaluated", (JExpression)jInvocation);
/*     */ 
/*     */ 
/*     */     
/*  91 */     if (this.parser.getPositionalArguments().isEmpty()) {
/*  92 */       JBlock firstArgBlock = block._if((JExpression)firstArgVar)._then();
/*  93 */       this.genericDispatchStrategy.afterFirstArgIsEvaluated(this, (JExpression)this.call, (JExpression)this.args, firstArgBlock, (JExpression)evaluated);
/*  94 */       block.assign((JAssignmentTarget)firstArgVar, JExpr.FALSE);
/*     */     } 
/*     */     
/*  97 */     JVar name = block.decl((JType)classRef(String.class), "name", (JExpression)this.argumentIterator.invoke("getCurrentName"));
/*     */ 
/*     */     
/* 100 */     IfElseBuilder matchSequence = new IfElseBuilder(block);
/* 101 */     for (JvmMethod.Argument namedFlag : this.parser.getNamedFlags().keySet()) {
/* 102 */       matchSequence._if((JExpression)JExpr.lit(namedFlag.getName()).invoke("equals").arg((JExpression)name))
/* 103 */         .assign((JAssignmentTarget)this.parser.getNamedFlags().get(namedFlag), convert(namedFlag, (JExpression)evaluated));
/*     */     }
/*     */     
/* 106 */     matchSequence._else().invoke((JExpression)this.parser.getVarArgBuilder(), "add").arg((JExpression)name).arg((JExpression)evaluated);
/*     */   }
/*     */   
/*     */   private JExpression hasMoreArguments() {
/* 110 */     return (JExpression)this.argumentIterator.invoke("hasNext");
/*     */   }
/*     */   
/*     */   private JExpression convert(JvmMethod.Argument formal, JExpression sexp) {
/* 114 */     return ArgConverterStrategies.findArgConverterStrategy(formal).convertArgument(this, sexp);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/codegen/VarArgApplyBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */