/*     */ package org.renjin.primitives.special;
/*     */ 
/*     */ import org.renjin.eval.Context;
/*     */ import org.renjin.eval.EvalException;
/*     */ import org.renjin.invoke.annotations.Current;
/*     */ import org.renjin.primitives.S3;
/*     */ import org.renjin.primitives.Types;
/*     */ import org.renjin.sexp.Environment;
/*     */ import org.renjin.sexp.ExternalPtr;
/*     */ import org.renjin.sexp.FunctionCall;
/*     */ import org.renjin.sexp.ListVector;
/*     */ import org.renjin.sexp.Null;
/*     */ import org.renjin.sexp.PairList;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.SpecialFunction;
/*     */ import org.renjin.sexp.StringArrayVector;
/*     */ import org.renjin.sexp.StringVector;
/*     */ import org.renjin.sexp.Symbol;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DollarFunction
/*     */   extends SpecialFunction
/*     */ {
/*     */   public DollarFunction() {
/*  36 */     super("$");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SEXP apply(Context context, Environment rho, FunctionCall call, PairList args) {
/*  44 */     if (args.length() != 2) {
/*  45 */       throw new EvalException(String.format("%d argument(s) passed to '$' which requires 2", new Object[] { Integer.valueOf(args.length()) }), new Object[0]);
/*     */     }
/*     */     
/*  48 */     SEXP object = context.evaluate(args.getElementAsSEXP(0), rho);
/*  49 */     StringVector nameArgument = evaluateName(args.getElementAsSEXP(1));
/*     */ 
/*     */ 
/*     */     
/*  53 */     PairList.Node repackagedArgs = new PairList.Node(object, (PairList)new PairList.Node((SEXP)nameArgument, (PairList)Null.INSTANCE));
/*     */     
/*  55 */     SEXP genericResult = S3.tryDispatchFromPrimitive(context, rho, call, "$", object, (PairList)repackagedArgs);
/*  56 */     if (genericResult != null) {
/*  57 */       return genericResult;
/*     */     }
/*     */ 
/*     */     
/*  61 */     object = Types.unwrapS4Object(object);
/*     */ 
/*     */     
/*  64 */     String name = nameArgument.getElementAsString(0);
/*     */     
/*  66 */     return apply(context, object, name);
/*     */   }
/*     */   
/*     */   public static SEXP apply(Context context, SEXP object, String name) {
/*  70 */     if (object instanceof PairList) {
/*  71 */       return fromPairList((PairList)object, name);
/*     */     }
/*  73 */     if (object instanceof Environment) {
/*  74 */       return fromEnvironment(context, (Environment)object, name);
/*     */     }
/*  76 */     if (object instanceof ListVector) {
/*  77 */       return fromList((ListVector)object, name);
/*     */     }
/*  79 */     if (object instanceof ExternalPtr) {
/*  80 */       return fromExternalPtr((ExternalPtr)object, name);
/*     */     }
/*  82 */     if (object instanceof org.renjin.sexp.AtomicVector) {
/*  83 */       throw new EvalException("$ operator is invalid for atomic vectors", new Object[0]);
/*     */     }
/*     */     
/*  86 */     throw new EvalException("object of type '%s' is not subsettable", new Object[] { object.getTypeName() });
/*     */   }
/*     */ 
/*     */   
/*     */   static StringVector evaluateName(SEXP name) {
/*  91 */     if (name instanceof Symbol)
/*  92 */       return (StringVector)new StringArrayVector(new String[] { ((Symbol)name).getPrintName() }); 
/*  93 */     if (name instanceof StringVector) {
/*  94 */       return (StringVector)name;
/*     */     }
/*  96 */     throw new EvalException("invalid subscript type '%s'", new Object[] { name.getTypeName() });
/*     */   }
/*     */ 
/*     */   
/*     */   public static SEXP fromPairList(PairList list, String name) {
/* 101 */     SEXP match = null;
/* 102 */     int matchCount = 0;
/*     */     
/* 104 */     for (PairList.Node node : list.nodes()) {
/* 105 */       if (node.hasTag() && 
/* 106 */         node.getTag().getPrintName().startsWith(name)) {
/* 107 */         match = node.getValue();
/* 108 */         matchCount++;
/*     */       } 
/*     */     } 
/*     */     
/* 112 */     return (matchCount == 1) ? match : (SEXP)Null.INSTANCE;
/*     */   }
/*     */   
/*     */   public static SEXP fromEnvironment(@Current Context context, Environment env, String name) {
/* 116 */     SEXP value = env.getVariable(context, name);
/* 117 */     if (value == Symbol.UNBOUND_VALUE) {
/* 118 */       return (SEXP)Null.INSTANCE;
/*     */     }
/* 120 */     return value.force(context);
/*     */   }
/*     */   
/*     */   public static SEXP fromExternalPtr(ExternalPtr<?> externalPtr, String name) {
/* 124 */     return externalPtr.getMember(Symbol.get(name));
/*     */   }
/*     */   
/*     */   public static SEXP fromList(ListVector list, String name) {
/* 128 */     SEXP match = null;
/* 129 */     int matchCount = 0;
/*     */     
/* 131 */     for (int i = 0; i != list.length(); i++) {
/* 132 */       String elementName = list.getName(i);
/* 133 */       if (!StringVector.isNA(elementName)) {
/* 134 */         if (elementName.equals(name))
/* 135 */           return list.getElementAsSEXP(i); 
/* 136 */         if (elementName.startsWith(name)) {
/* 137 */           match = list.get(i);
/* 138 */           matchCount++;
/*     */         } 
/*     */       } 
/*     */     } 
/* 142 */     return (matchCount == 1) ? match : (SEXP)Null.INSTANCE;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/special/DollarFunction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */