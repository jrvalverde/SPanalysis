/*     */ package org.renjin.primitives.io.connections;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.Writer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.renjin.sexp.Environment;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.StringArrayVector;
/*     */ import org.renjin.sexp.StringVector;
/*     */ import org.renjin.sexp.Symbol;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WriteTextConnection
/*     */   implements Connection
/*     */ {
/*     */   private Symbol objectName;
/*     */   private Environment environment;
/*     */   private boolean open = true;
/*  32 */   private StringBuilder buffer = new StringBuilder();
/*     */   
/*     */   private PrintWriter printWriter;
/*     */   
/*     */   public WriteTextConnection(Symbol objectName, Environment environment) {
/*  37 */     this.objectName = objectName;
/*  38 */     this.environment = environment;
/*  39 */     this.printWriter = new PrintWriter(new Writer()
/*     */         {
/*  41 */           private List<String> lines = new ArrayList<>();
/*     */ 
/*     */ 
/*     */           
/*     */           public void write(char[] cbuf, int off, int len) throws IOException {
/*  46 */             int pos = off;
/*  47 */             int remaining = len;
/*  48 */             while (remaining > 0) {
/*  49 */               if (cbuf[pos] == '\n') {
/*  50 */                 this.lines.add(WriteTextConnection.this.buffer.toString());
/*  51 */                 WriteTextConnection.this.buffer.setLength(0);
/*     */               } else {
/*  53 */                 WriteTextConnection.this.buffer.append(cbuf[pos]);
/*     */               } 
/*  55 */               pos++;
/*  56 */               remaining--;
/*     */             } 
/*     */           }
/*     */ 
/*     */ 
/*     */           
/*     */           public void flush() throws IOException {
/*  63 */             if (WriteTextConnection.this.buffer.length() > 0) {
/*  64 */               this.lines.add(WriteTextConnection.this.buffer.toString());
/*  65 */               WriteTextConnection.this.buffer.setLength(0);
/*     */             } 
/*  67 */             if (this.lines.size() > 0) {
/*  68 */               WriteTextConnection.this.appendLines(this.lines);
/*  69 */               this.lines.clear();
/*     */             } 
/*     */           }
/*     */ 
/*     */           
/*     */           public void close() throws IOException {}
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   private void appendLines(List<String> lines) {
/*     */     StringArrayVector stringArrayVector;
/*  81 */     SEXP output = this.environment.getVariableUnsafe(this.objectName);
/*  82 */     if (output == Symbol.UNBOUND_VALUE) {
/*  83 */       stringArrayVector = new StringArrayVector(lines);
/*  84 */     } else if (stringArrayVector instanceof StringVector) {
/*  85 */       StringVector.Builder builder = ((StringVector)stringArrayVector).newCopyBuilder();
/*  86 */       builder.addAll(lines);
/*  87 */       stringArrayVector = builder.build();
/*     */     } else {
/*  89 */       throw new UnsupportedOperationException();
/*     */     } 
/*     */     
/*  92 */     this.environment.setVariableUnsafe(this.objectName, (SEXP)stringArrayVector);
/*     */   }
/*     */ 
/*     */   
/*     */   public void open(OpenSpec spec) throws IOException {
/*  97 */     this.environment.setVariableUnsafe(this.objectName, (SEXP)StringVector.EMPTY);
/*  98 */     this.environment.lockBinding(this.objectName);
/*     */   }
/*     */ 
/*     */   
/*     */   public InputStream getInputStream() throws IOException {
/* 103 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public PushbackBufferedReader getReader() throws IOException {
/* 108 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public OutputStream getOutputStream() throws IOException {
/* 113 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isIncomplete() {
/* 118 */     return (this.buffer.length() > 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public PrintWriter getPrintWriter() throws IOException {
/* 123 */     return this.printWriter;
/*     */   }
/*     */ 
/*     */   
/*     */   public PrintWriter getOpenPrintWriter() {
/* 128 */     return this.printWriter;
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 133 */     this.open = false;
/* 134 */     this.environment.unlockBinding(this.objectName);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isOpen() {
/* 139 */     return this.open;
/*     */   }
/*     */ 
/*     */   
/*     */   public void flush() throws IOException {
/* 144 */     this.printWriter.flush();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getClassName() {
/* 149 */     return "textConnection";
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDescription() {
/* 154 */     return this.objectName.getPrintName();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getMode() {
/* 159 */     return "w";
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canRead() {
/* 164 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canWrite() {
/* 169 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public Connection.Type getType() {
/* 174 */     return Connection.Type.TEXT;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/io/connections/WriteTextConnection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */