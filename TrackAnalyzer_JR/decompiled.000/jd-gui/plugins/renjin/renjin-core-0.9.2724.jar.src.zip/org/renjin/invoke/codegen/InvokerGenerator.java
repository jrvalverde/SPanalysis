/*    */ package org.renjin.invoke.codegen;
/*    */ 
/*    */ import com.sun.codemodel.JClassAlreadyExistsException;
/*    */ import com.sun.codemodel.JCodeModel;
/*    */ import com.sun.codemodel.JDefinedClass;
/*    */ import com.sun.codemodel.JExpr;
/*    */ import com.sun.codemodel.JExpression;
/*    */ import com.sun.codemodel.JMethod;
/*    */ import com.sun.codemodel.JVar;
/*    */ import java.io.IOException;
/*    */ import org.renjin.eval.Context;
/*    */ import org.renjin.invoke.model.PrimitiveModel;
/*    */ import org.renjin.sexp.BuiltinFunction;
/*    */ import org.renjin.sexp.Environment;
/*    */ import org.renjin.sexp.FunctionCall;
/*    */ import org.renjin.sexp.SEXP;
/*    */ import org.renjin.sexp.SpecialFunction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InvokerGenerator
/*    */ {
/*    */   private final JCodeModel codeModel;
/*    */   
/*    */   public InvokerGenerator(JCodeModel codeModel) {
/* 34 */     this.codeModel = codeModel;
/*    */   }
/*    */   
/*    */   public final void generate(PrimitiveModel model) throws JClassAlreadyExistsException, IOException {
/* 38 */     JDefinedClass invoker = this.codeModel._class(WrapperGenerator2.toFullJavaName(model.getName()));
/* 39 */     if (model.isSpecial()) {
/* 40 */       invoker._extends(SpecialFunction.class);
/*    */     } else {
/* 42 */       invoker._extends(BuiltinFunction.class);
/*    */     } 
/*    */     
/* 45 */     JMethod defaultConstructor = invoker.constructor(1);
/* 46 */     defaultConstructor.body().invoke("super").arg(JExpr.lit(model.getName()));
/*    */     
/* 48 */     if (model.hasVargs() && model.getOverloads().size() > 1) {
/* 49 */       throw new GeneratorDefinitionException(model.getName() + ": If var args are used, multiple overloads cannot be used");
/*    */     }
/*    */     
/* 52 */     if (model.hasVargs()) {
/* 53 */       VarArgApplyBuilder apply = new VarArgApplyBuilder(this.codeModel, invoker, model);
/* 54 */       apply.build();
/*    */       
/* 56 */       ApplyArrayArgsMethodBuilder applyWithArray = new ApplyArrayArgsMethodBuilder(this.codeModel, invoker, model);
/* 57 */       applyWithArray.buildVarArgs();
/* 58 */       addArrayApplyOverload(invoker);
/*    */     } else {
/*    */       
/* 61 */       FixedArityApplyBuilder apply = new FixedArityApplyBuilder(this.codeModel, invoker, model);
/* 62 */       apply.build();
/*    */       
/* 64 */       ApplyArrayArgsMethodBuilder applyWithArray = new ApplyArrayArgsMethodBuilder(this.codeModel, invoker, model);
/* 65 */       applyWithArray.build();
/* 66 */       addArrayApplyOverload(invoker);
/*    */       
/* 68 */       for (Integer arity : model.getArity()) {
/* 69 */         OverloadWrapperBuilder doApply = new OverloadWrapperBuilder(this.codeModel, invoker, model, arity.intValue());
/* 70 */         doApply.build();
/*    */       } 
/*    */     } 
/*    */   }
/*    */   
/*    */   private void addArrayApplyOverload(JDefinedClass invoker) {
/* 76 */     JMethod method = invoker.method(1, SEXP.class, "apply");
/* 77 */     JVar context = method.param(Context.class, "context");
/* 78 */     JVar environment = method.param(Environment.class, "environment");
/* 79 */     JVar call = method.param(FunctionCall.class, "call");
/* 80 */     JVar argNames = method.param(String[].class, "argNames");
/* 81 */     JVar args = method.param(SEXP[].class, "args");
/*    */     
/* 83 */     method.body()._return((JExpression)invoker.staticInvoke("doApply")
/* 84 */         .arg((JExpression)context)
/* 85 */         .arg((JExpression)environment)
/* 86 */         .arg((JExpression)call)
/* 87 */         .arg((JExpression)argNames)
/* 88 */         .arg((JExpression)args));
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/codegen/InvokerGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */