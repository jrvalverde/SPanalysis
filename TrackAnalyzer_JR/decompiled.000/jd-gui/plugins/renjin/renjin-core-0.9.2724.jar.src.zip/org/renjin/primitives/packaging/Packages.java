/*    */ package org.renjin.primitives.packaging;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.renjin.eval.Context;
/*    */ import org.renjin.invoke.annotations.Current;
/*    */ import org.renjin.invoke.annotations.Internal;
/*    */ import org.renjin.invoke.annotations.Invisible;
/*    */ import org.renjin.sexp.Environment;
/*    */ import org.renjin.sexp.Frame;
/*    */ import org.renjin.sexp.HashFrame;
/*    */ import org.renjin.sexp.SEXP;
/*    */ import org.renjin.sexp.StringVector;
/*    */ import org.renjin.sexp.Symbols;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Packages
/*    */ {
/* 31 */   public static final FqPackageName METHODS_NAMESPACE = new FqPackageName("org.renjin", "methods");
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Internal
/*    */   public static void library(@Current Context context, @Current NamespaceRegistry namespaceRegistry, String packageName) throws IOException {
/* 39 */     Namespace namespace = namespaceRegistry.getNamespace(context, packageName);
/*    */ 
/*    */     
/* 42 */     if (isAttached(context, namespace)) {
/*    */       return;
/*    */     }
/*    */ 
/*    */ 
/*    */     
/* 48 */     for (String dependencyName : namespace.getPackage().getPackageDependencies()) {
/* 49 */       context.getSession().getStdOut().println("Loading required package: " + dependencyName);
/* 50 */       library(context, namespaceRegistry, dependencyName);
/*    */     } 
/*    */ 
/*    */     
/* 54 */     Environment packageEnv = context.getGlobalEnvironment().insertAbove((Frame)new HashFrame());
/* 55 */     packageEnv.setAttribute(Symbols.NAME, (SEXP)StringVector.valueOf("package:" + namespace.getFullyQualifiedName().getPackageName()));
/* 56 */     packageEnv.setAttribute(Symbols.FQNAME, (SEXP)StringVector.valueOf("package:" + namespace.getFullyQualifiedName().toString()));
/*    */ 
/*    */     
/* 59 */     namespace.copyExportsTo(context, packageEnv);
/*    */     
/* 61 */     context.setInvisibleFlag();
/*    */   }
/*    */ 
/*    */   
/*    */   private static boolean isAttached(Context context, Namespace namespace) {
/* 66 */     String expected = "package:" + namespace.getFullyQualifiedName().toString();
/*    */     
/* 68 */     Environment env = context.getGlobalEnvironment();
/* 69 */     while (env != Environment.EMPTY) {
/* 70 */       SEXP fqNameSexp = env.getAttribute(Symbols.FQNAME);
/* 71 */       if (fqNameSexp instanceof StringVector && fqNameSexp.length() == 1) {
/* 72 */         String fqName = ((StringVector)fqNameSexp).getElementAsString(0);
/* 73 */         if (expected.equals(fqName)) {
/* 74 */           return true;
/*    */         }
/*    */       } 
/* 77 */       env = env.getParent();
/*    */     } 
/* 79 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Internal
/*    */   @Invisible
/*    */   public static boolean require(@Current Context context, @Current NamespaceRegistry registry, String packageName) {
/*    */     try {
/* 89 */       library(context, registry, packageName);
/* 90 */       return true;
/* 91 */     } catch (Exception e) {
/* 92 */       return false;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/packaging/Packages.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */