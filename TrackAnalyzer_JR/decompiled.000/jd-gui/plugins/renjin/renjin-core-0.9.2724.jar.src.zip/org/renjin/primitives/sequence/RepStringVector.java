/*    */ package org.renjin.primitives.sequence;
/*    */ 
/*    */ import org.renjin.sexp.AttributeMap;
/*    */ import org.renjin.sexp.SEXP;
/*    */ import org.renjin.sexp.StringVector;
/*    */ import org.renjin.sexp.Vector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RepStringVector
/*    */   extends StringVector
/*    */ {
/*    */   public Vector source;
/*    */   private int sourceLength;
/*    */   private int length;
/*    */   private int each;
/*    */   
/*    */   public RepStringVector(Vector source, int length, int each, AttributeMap attributes) {
/* 34 */     super(attributes);
/* 35 */     this.source = source;
/* 36 */     this.sourceLength = source.length();
/* 37 */     this.length = length;
/* 38 */     this.each = each;
/*    */   }
/*    */   
/*    */   private RepStringVector(String constant, int length) {
/* 42 */     super(AttributeMap.EMPTY);
/* 43 */     this.source = (Vector)StringVector.valueOf(constant);
/* 44 */     this.sourceLength = this.source.length();
/* 45 */     this.length = length;
/* 46 */     this.each = 1;
/*    */   }
/*    */ 
/*    */   
/*    */   public int length() {
/* 51 */     return this.length;
/*    */   }
/*    */ 
/*    */   
/*    */   protected StringVector cloneWithNewAttributes(AttributeMap attributes) {
/* 56 */     return new RepStringVector(this.source, this.length, this.each, attributes);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getElementAsString(int index) {
/* 61 */     this.sourceLength = this.source.length();
/* 62 */     return this.source.getElementAsString(index / this.each % this.sourceLength);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isConstantAccessTime() {
/* 67 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public static StringVector createConstantVector(String constant, int length) {
/* 72 */     if (length <= 0) {
/* 73 */       return StringVector.EMPTY;
/*    */     }
/* 75 */     return new RepStringVector(constant, length);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/sequence/RepStringVector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */