package org.renjin.primitives.io.serialization;

class SerializationFormat {
  public static final String ASCII_MAGIC_HEADER = "RDA2\n";
  
  public static final String BINARY_MAGIC_HEADER = "RDB2\n";
  
  public static final String XDR_MAGIC_HEADER = "RDX2\n";
  
  public static final byte ASCII_FORMAT = 65;
  
  public static final byte BINARY_FORMAT = 66;
  
  public static final byte XDR_FORMAT = 88;
  
  public static final int WEAKREFSXP = 23;
  
  public static final int NILVALUE_SXP = 254;
  
  public static final int GLOBALENV_SXP = 253;
  
  public static final int UNBOUNDVALUE_SXP = 252;
  
  public static final int MISSINGARG_SXP = 251;
  
  public static final int BASENAMESPACE_SXP = 250;
  
  public static final int NAMESPACESXP = 249;
  
  public static final int PACKAGESXP = 248;
  
  public static final int PERSISTSXP = 247;
  
  public static final int CLASSREFSXP = 246;
  
  public static final int GENERICREFSXP = 245;
  
  public static final int EMPTYENV_SXP = 242;
  
  public static final int BASEENV_SXP = 241;
  
  public static final int BCREPDEF = 244;
  
  public static final int BCREPREF = 243;
  
  public static final int ATTRLANGSXP = 240;
  
  public static final int ATTRLISTSXP = 239;
  
  static final int LATIN1_MASK = 4;
  
  static final int UTF8_MASK = 8;
  
  static final int ASCII_MASK = 64;
  
  public static final int VERSION2 = 2;
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/io/serialization/SerializationFormat.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */