/*     */ package org.renjin.pipeliner.fusion.node;
/*     */ 
/*     */ import java.util.Optional;
/*     */ import org.renjin.pipeliner.ComputeMethod;
/*     */ import org.renjin.primitives.sequence.IntSequence;
/*     */ import org.renjin.repackaged.asm.Label;
/*     */ import org.renjin.repackaged.asm.MethodVisitor;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IntSeqNode
/*     */   extends LoopNode
/*     */ {
/*  34 */   private static final String SEQUENCE_CLASS = Type.getInternalName(IntSequence.class);
/*     */   
/*     */   private int operandIndex;
/*     */   private int fromVar;
/*     */   private int byVar;
/*     */   private int lengthVar;
/*     */   
/*     */   public IntSeqNode(int operandIndex) {
/*  42 */     this.operandIndex = operandIndex;
/*     */   }
/*     */ 
/*     */   
/*     */   public void init(ComputeMethod method) {
/*  47 */     this.fromVar = method.reserveLocal(1);
/*  48 */     this.byVar = method.reserveLocal(1);
/*  49 */     this.lengthVar = method.reserveLocal(1);
/*     */     
/*  51 */     MethodVisitor mv = method.getVisitor();
/*  52 */     mv.visitVarInsn(25, method.getOperandsLocalIndex());
/*  53 */     pushIntConstant(mv, this.operandIndex);
/*  54 */     mv.visitInsn(50);
/*  55 */     mv.visitTypeInsn(192, SEQUENCE_CLASS);
/*     */     
/*  57 */     mv.visitInsn(89);
/*  58 */     mv.visitMethodInsn(182, SEQUENCE_CLASS, "getFrom", "()I", false);
/*  59 */     mv.visitVarInsn(54, this.fromVar);
/*     */     
/*  61 */     mv.visitInsn(89);
/*  62 */     mv.visitMethodInsn(182, SEQUENCE_CLASS, "getBy", "()I", false);
/*  63 */     mv.visitVarInsn(54, this.byVar);
/*     */     
/*  65 */     mv.visitMethodInsn(182, SEQUENCE_CLASS, "length", "()I", false);
/*  66 */     mv.visitVarInsn(54, this.lengthVar);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void pushElementAsInt(ComputeMethod method, Optional<Label> naLabel) {
/*  74 */     MethodVisitor mv = method.getVisitor();
/*  75 */     mv.visitVarInsn(21, this.byVar);
/*  76 */     mv.visitInsn(104);
/*  77 */     mv.visitVarInsn(21, this.fromVar);
/*  78 */     mv.visitInsn(96);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean mustCheckForIntegerNAs() {
/*  83 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void appendToKey(StringBuilder key) {
/*  88 */     key.append("ISN");
/*     */   }
/*     */ 
/*     */   
/*     */   public void pushElementAsDouble(ComputeMethod method, Optional<Label> integerNaLabel) {
/*  93 */     pushElementAsInt(method, integerNaLabel);
/*  94 */     method.getVisitor().visitInsn(135);
/*     */   }
/*     */ 
/*     */   
/*     */   public void pushLength(ComputeMethod method) {
/*  99 */     method.getVisitor().visitVarInsn(21, this.lengthVar);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 105 */     return "x" + this.operandIndex;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/pipeliner/fusion/node/IntSeqNode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */