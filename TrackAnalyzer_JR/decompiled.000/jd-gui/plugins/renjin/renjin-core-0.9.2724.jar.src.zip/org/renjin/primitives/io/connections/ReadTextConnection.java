/*     */ package org.renjin.primitives.io.connections;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringReader;
/*     */ import org.renjin.eval.EvalException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReadTextConnection
/*     */   implements Connection
/*     */ {
/*     */   private String objectName;
/*     */   private PushbackBufferedReader reader;
/*     */   
/*     */   public ReadTextConnection(String objectName, String text) {
/*  36 */     this.reader = new PushbackBufferedReader(new StringReader(text));
/*  37 */     this.objectName = objectName;
/*     */   }
/*     */ 
/*     */   
/*     */   public void open(OpenSpec spec) throws IOException {
/*  42 */     if (!spec.forReading()) {
/*  43 */       throw new EvalException("Only read support for text connections is implemented, sorry!", new Object[0]);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public InputStream getInputStream() throws IOException {
/*  49 */     throw new EvalException("reading bytes from TextConnections is not supported", new Object[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   public OutputStream getOutputStream() throws IOException {
/*  54 */     throw new EvalException("Writing to textConnections is not currently implemented", new Object[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isOpen() {
/*  59 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void flush() throws IOException {}
/*     */ 
/*     */ 
/*     */   
/*     */   public String getClassName() {
/*  69 */     return "textConnection";
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDescription() {
/*  74 */     return this.objectName;
/*     */   }
/*     */ 
/*     */   
/*     */   public Connection.Type getType() {
/*  79 */     return Connection.Type.TEXT;
/*     */   }
/*     */ 
/*     */   
/*     */   public PushbackBufferedReader getReader() throws IOException {
/*  84 */     return this.reader;
/*     */   }
/*     */ 
/*     */   
/*     */   public PrintWriter getPrintWriter() throws IOException {
/*  89 */     return getOpenPrintWriter();
/*     */   }
/*     */ 
/*     */   
/*     */   public PrintWriter getOpenPrintWriter() {
/*  94 */     throw new EvalException("reading bytes from TextConnections is not supported", new Object[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {}
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMode() {
/* 104 */     return "r";
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canRead() {
/* 109 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canWrite() {
/* 114 */     return false;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/io/connections/ReadTextConnection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */