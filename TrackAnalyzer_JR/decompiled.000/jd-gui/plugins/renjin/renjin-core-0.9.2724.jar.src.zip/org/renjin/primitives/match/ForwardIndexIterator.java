/*    */ package org.renjin.primitives.match;
/*    */ 
/*    */ import org.renjin.repackaged.guava.collect.UnmodifiableIterator;
/*    */ import org.renjin.sexp.Vector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ForwardIndexIterator
/*    */   extends UnmodifiableIterator<Integer>
/*    */ {
/*    */   private int index;
/*    */   private int size;
/*    */   
/*    */   public ForwardIndexIterator(Vector vector) {
/* 34 */     this.index = 0;
/* 35 */     this.size = vector.length();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean hasNext() {
/* 40 */     return (this.index < this.size);
/*    */   }
/*    */ 
/*    */   
/*    */   public Integer next() {
/* 45 */     return Integer.valueOf(this.index++);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/match/ForwardIndexIterator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */