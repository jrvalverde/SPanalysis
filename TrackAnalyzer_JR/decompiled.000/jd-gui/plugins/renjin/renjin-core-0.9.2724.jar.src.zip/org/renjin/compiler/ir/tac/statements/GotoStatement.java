/*    */ package org.renjin.compiler.ir.tac.statements;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import org.renjin.compiler.codegen.EmitContext;
/*    */ import org.renjin.compiler.ir.tac.IRLabel;
/*    */ import org.renjin.compiler.ir.tac.expressions.Expression;
/*    */ import org.renjin.compiler.ir.tac.expressions.NullExpression;
/*    */ import org.renjin.repackaged.asm.commons.InstructionAdapter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GotoStatement
/*    */   implements Statement, BasicBlockEndingStatement
/*    */ {
/*    */   private final IRLabel target;
/*    */   
/*    */   public GotoStatement(IRLabel target) {
/* 36 */     this.target = target;
/*    */   }
/*    */   
/*    */   public IRLabel getTarget() {
/* 40 */     return this.target;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Iterable<IRLabel> possibleTargets() {
/* 46 */     return Arrays.asList(new IRLabel[] { this.target });
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 51 */     return "goto " + this.target;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Expression getRHS() {
/* 57 */     return (Expression)NullExpression.INSTANCE;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setRHS(Expression newRHS) {
/* 62 */     if (newRHS != NullExpression.INSTANCE) {
/* 63 */       throw new IllegalArgumentException();
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setChild(int childIndex, Expression child) {
/* 70 */     throw new IllegalArgumentException();
/*    */   }
/*    */ 
/*    */   
/*    */   public int getChildCount() {
/* 75 */     return 0;
/*    */   }
/*    */ 
/*    */   
/*    */   public Expression childAt(int index) {
/* 80 */     throw new IllegalArgumentException();
/*    */   }
/*    */ 
/*    */   
/*    */   public void accept(StatementVisitor visitor) {
/* 85 */     visitor.visitGoto(this);
/*    */   }
/*    */ 
/*    */   
/*    */   public int emit(EmitContext emitContext, InstructionAdapter mv) {
/* 90 */     mv.visitJumpInsn(167, emitContext.getAsmLabel(this.target));
/* 91 */     return 0;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isPure() {
/* 96 */     return true;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/ir/tac/statements/GotoStatement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */