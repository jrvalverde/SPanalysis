/*     */ package org.renjin.compiler.cfg;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.renjin.repackaged.guava.base.Joiner;
/*     */ import org.renjin.repackaged.guava.base.Predicates;
/*     */ import org.renjin.repackaged.guava.collect.HashMultimap;
/*     */ import org.renjin.repackaged.guava.collect.Iterables;
/*     */ import org.renjin.repackaged.guava.collect.Multimap;
/*     */ import org.renjin.repackaged.guava.collect.Sets;
/*     */ import org.renjin.util.DebugGraph;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DominanceTree
/*     */ {
/*     */   private final ControlFlowGraph cfg;
/*  37 */   private final HashMultimap<BasicBlock, BasicBlock> Dom = HashMultimap.create();
/*  38 */   private final Multimap<BasicBlock, BasicBlock> dominanceFrontier = (Multimap<BasicBlock, BasicBlock>)HashMultimap.create();
/*     */   
/*     */   public DominanceTree(ControlFlowGraph cfg) {
/*  41 */     this.cfg = cfg;
/*  42 */     computeDominators();
/*  43 */     buildTree();
/*  44 */     calculateDominanceFrontiers();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void computeDominators() {
/*     */     boolean changes;
/*  52 */     this.Dom.put(this.cfg.getEntry(), this.cfg.getEntry());
/*     */ 
/*     */     
/*  55 */     for (BasicBlock n : Iterables.filter(this.cfg.getLiveBasicBlocks(), Predicates.not(Predicates.equalTo(this.cfg.getEntry())))) {
/*  56 */       this.Dom.putAll(n, this.cfg.getLiveBasicBlocks());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     do {
/*  62 */       changes = false;
/*  63 */       for (BasicBlock n : Iterables.filter(this.cfg.getLiveBasicBlocks(), Predicates.not(Predicates.equalTo(this.cfg.getEntry())))) {
/*     */         
/*  65 */         Set<BasicBlock> newDom = computeNewDominance(n);
/*  66 */         Set<BasicBlock> original = this.Dom.get(n);
/*     */         
/*  68 */         if (!original.equals(newDom)) {
/*     */           
/*  70 */           this.Dom.replaceValues(n, newDom);
/*  71 */           changes = true;
/*     */         } 
/*     */       } 
/*  74 */     } while (changes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Set<BasicBlock> computeNewDominance(BasicBlock n) {
/*  82 */     List<BasicBlock> predecessors = n.getFlowPredecessors();
/*     */     
/*  84 */     Set<BasicBlock> set = new HashSet<>();
/*  85 */     boolean first = true;
/*  86 */     for (BasicBlock predecessor : predecessors) {
/*  87 */       Set<BasicBlock> frontier = this.Dom.get(predecessor);
/*  88 */       if (first) {
/*  89 */         set.addAll(frontier);
/*     */       } else {
/*  91 */         set.retainAll(frontier);
/*     */       } 
/*  93 */       first = false;
/*     */     } 
/*     */     
/*  96 */     set.add(n);
/*     */     
/*  98 */     return set;
/*     */   }
/*     */   
/*     */   private String toString(Set<BasicBlock> newDom) {
/* 102 */     List<String> strings = new ArrayList<>();
/* 103 */     for (BasicBlock basicBlock : newDom) {
/* 104 */       strings.add(basicBlock.getDebugId());
/*     */     }
/* 106 */     Collections.sort(strings);
/* 107 */     return "{" + Joiner.on(", ").join(strings) + "}";
/*     */   }
/*     */   
/*     */   private void buildTree() {
/* 111 */     for (BasicBlock n : this.cfg.getBasicBlocks()) {
/* 112 */       BasicBlock d = calculateImmediateDominator(n);
/* 113 */       if (d != null) {
/* 114 */         d.addDominanceSuccessor(n);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private BasicBlock calculateImmediateDominator(BasicBlock n) {
/* 120 */     for (BasicBlock d : strictDominators(n)) {
/* 121 */       if (dominatesImmediately(d, n)) {
/* 122 */         return d;
/*     */       }
/*     */     } 
/* 125 */     return null;
/*     */   }
/*     */   
/*     */   public BasicBlock getImmediateDominator(BasicBlock n) {
/* 129 */     Collection<BasicBlock> parent = n.getDominancePredecessors();
/* 130 */     if (parent.size() != 1) {
/* 131 */       throw new IllegalArgumentException(n.toString());
/*     */     }
/* 133 */     return parent.iterator().next();
/*     */   }
/*     */   
/*     */   public boolean dominatesImmediately(BasicBlock d, BasicBlock n) {
/* 137 */     for (BasicBlock otherDominator : strictDominators(n)) {
/* 138 */       if (strictlyDominates(d, otherDominator)) {
/* 139 */         return false;
/*     */       }
/*     */     } 
/* 142 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean strictlyDominates(BasicBlock d, BasicBlock n) {
/* 149 */     return (!d.equals(n) && dominates(d, n));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean dominates(BasicBlock d, BasicBlock n) {
/* 158 */     if (d == n) {
/* 159 */       return true;
/*     */     }
/* 161 */     return this.Dom.containsEntry(n, d);
/*     */   }
/*     */ 
/*     */   
/*     */   private Iterable<BasicBlock> strictDominators(BasicBlock n) {
/* 166 */     return (Iterable<BasicBlock>)Sets.difference(this.Dom.get(n), Collections.singleton(n));
/*     */   }
/*     */   
/*     */   private void calculateDominanceFrontiers() {
/* 170 */     calculateDominanceFrontier(this.cfg.getEntry());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void calculateDominanceFrontier(BasicBlock X) {
/* 196 */     for (BasicBlock child : X.getDominanceSuccessors()) {
/* 197 */       calculateDominanceFrontier(child);
/*     */     }
/*     */ 
/*     */     
/* 201 */     for (BasicBlock Y : this.cfg.getSuccessors(X)) {
/* 202 */       if (getImmediateDominator(Y) != X) {
/* 203 */         this.dominanceFrontier.put(X, Y);
/*     */       }
/*     */     } 
/*     */     
/* 207 */     for (BasicBlock Z : X.getDominanceSuccessors()) {
/* 208 */       for (BasicBlock Y : this.dominanceFrontier.get(Z)) {
/* 209 */         if (getImmediateDominator(Y) != X) {
/* 210 */           this.dominanceFrontier.put(X, Y);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public Collection<BasicBlock> getFrontier(BasicBlock bb) {
/* 217 */     return this.dominanceFrontier.get(bb);
/*     */   }
/*     */   
/*     */   public Collection<BasicBlock> getChildren(BasicBlock x) {
/* 221 */     return x.getDominanceSuccessors();
/*     */   }
/*     */ 
/*     */   
/*     */   public void dumpGraph() {
/* 226 */     DebugGraph dump = new DebugGraph("dominance");
/* 227 */     for (BasicBlock basicBlock : this.cfg.getBasicBlocks()) {
/* 228 */       for (BasicBlock dominated : basicBlock.getDominanceSuccessors()) {
/* 229 */         dump.printEdge(basicBlock.getDebugId(), dominated.getDebugId());
/*     */       }
/*     */     } 
/* 232 */     dump.close();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/cfg/DominanceTree.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */