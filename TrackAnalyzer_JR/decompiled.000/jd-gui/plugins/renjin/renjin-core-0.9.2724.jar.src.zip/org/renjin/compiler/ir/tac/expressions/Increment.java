/*    */ package org.renjin.compiler.ir.tac.expressions;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.renjin.compiler.codegen.EmitContext;
/*    */ import org.renjin.compiler.ir.ValueBounds;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ import org.renjin.repackaged.asm.commons.InstructionAdapter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Increment
/*    */   extends SpecializedCallExpression
/*    */ {
/*    */   public Increment(LValue counter) {
/* 38 */     super(new Expression[] { counter });
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 43 */     return "increment counter " + this.arguments[0];
/*    */   }
/*    */   
/*    */   public Expression getCounter() {
/* 47 */     return this.arguments[0];
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isFunctionDefinitelyPure() {
/* 52 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isPure() {
/* 57 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public int load(EmitContext emitContext, InstructionAdapter mv) {
/* 62 */     getCounter().load(emitContext, mv);
/* 63 */     mv.visitInsn(4);
/* 64 */     mv.visitInsn(96);
/* 65 */     return 2;
/*    */   }
/*    */ 
/*    */   
/*    */   public Type getType() {
/* 70 */     return Type.INT_TYPE;
/*    */   }
/*    */ 
/*    */   
/*    */   public ValueBounds updateTypeBounds(Map<Expression, ValueBounds> typeMap) {
/* 75 */     return getValueBounds();
/*    */   }
/*    */ 
/*    */   
/*    */   public ValueBounds getValueBounds() {
/* 80 */     return ValueBounds.INT_PRIMITIVE;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/ir/tac/expressions/Increment.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */