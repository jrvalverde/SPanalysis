/*      */ package org.renjin.parser;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.PrintStream;
/*      */ import java.io.Reader;
/*      */ import java.io.StringReader;
/*      */ import java.util.Arrays;
/*      */ import java.util.List;
/*      */ import org.renjin.repackaged.guava.collect.Lists;
/*      */ import org.renjin.repackaged.guava.io.CharSource;
/*      */ import org.renjin.repackaged.guava.io.CharStreams;
/*      */ import org.renjin.sexp.AbstractSEXP;
/*      */ import org.renjin.sexp.AttributeMap;
/*      */ import org.renjin.sexp.CHARSEXP;
/*      */ import org.renjin.sexp.ExpressionVector;
/*      */ import org.renjin.sexp.FunctionCall;
/*      */ import org.renjin.sexp.IntArrayVector;
/*      */ import org.renjin.sexp.Null;
/*      */ import org.renjin.sexp.PairList;
/*      */ import org.renjin.sexp.SEXP;
/*      */ import org.renjin.sexp.StringArrayVector;
/*      */ import org.renjin.sexp.StringVector;
/*      */ import org.renjin.sexp.Symbol;
/*      */ import org.renjin.sexp.Symbols;
/*      */ import org.renjin.sexp.Vector;
/*      */ import org.renjin.util.CDefines;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class RParser
/*      */ {
/*      */   private ParseState state;
/*      */   private ParseOptions options;
/*      */   public static final String bisonVersion = "2.4.2";
/*      */   public static final String bisonSkeleton = "lalr1.java";
/*      */   
/*      */   public static ExpressionVector parseSource(Reader reader, SEXP srcFile) throws IOException {
/*   63 */     ParseState parseState = new ParseState();
/*   64 */     parseState.srcFile = srcFile;
/*   65 */     parseState.setKeepSrcRefs(srcFile instanceof org.renjin.sexp.Environment);
/*   66 */     ParseOptions parseOptions = ParseOptions.defaults();
/*   67 */     RLexer lexer = new RLexer(parseOptions, parseState, reader);
/*   68 */     RParser parser = new RParser(parseOptions, parseState, lexer);
/*   69 */     return parser.parseAll();
/*      */   }
/*      */   
/*      */   public static ExpressionVector parseWithSrcref(String source) throws IOException {
/*   73 */     if (!source.endsWith("\n")) {
/*   74 */       source = source + "\n";
/*      */     }
/*   76 */     Reader reader = new StringReader(source);
/*   77 */     ParseState parseState = new ParseState();
/*   78 */     ParseOptions parseOptions = ParseOptions.defaults();
/*   79 */     parseState.setKeepSrcRefs(true);
/*   80 */     RLexer lexer = new RLexer(parseOptions, parseState, reader);
/*   81 */     RParser parser = new RParser(parseOptions, parseState, lexer);
/*   82 */     return parser.parseAll();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ExpressionVector parseAllSource(Reader reader, SEXP srcFile) throws IOException {
/*   89 */     String source = CharStreams.toString(reader);
/*   90 */     if (!source.endsWith("\n")) {
/*   91 */       source = source + "\n";
/*      */     }
/*   93 */     return parseSource(source, srcFile);
/*      */   }
/*      */   
/*      */   public static ExpressionVector parseAllSource(Reader reader) throws IOException {
/*   97 */     return parseAllSource(reader, (SEXP)Null.INSTANCE);
/*      */   }
/*      */ 
/*      */   
/*      */   public static ExpressionVector parseSource(Reader reader) throws IOException {
/*  102 */     return parseAllSource(reader);
/*      */   }
/*      */ 
/*      */   
/*      */   public static ExpressionVector parseSource(CharSource source, SEXP srcFile) throws IOException {
/*  107 */     try (Reader reader = source.openStream()) {
/*  108 */       return parseAllSource(reader, srcFile);
/*      */     } 
/*      */   }
/*      */   
/*      */   public static ExpressionVector parseSource(String source) {
/*      */     try {
/*  114 */       return parseAllSource(new StringReader(source));
/*  115 */     } catch (IOException e) {
/*  116 */       throw new RuntimeException(e);
/*      */     } 
/*      */   }
/*      */   
/*      */   public static ExpressionVector parseSource(String source, SEXP srcFile) {
/*      */     try {
/*  122 */       return parseSource(new StringReader(source), srcFile);
/*  123 */     } catch (IOException e) {
/*  124 */       throw new RuntimeException(e);
/*      */     } 
/*      */   }
/*      */   
/*      */   public static ExpressionVector parseSource(String source, String srcFile) {
/*  129 */     return parseSource(source, (SEXP)new CHARSEXP(srcFile));
/*      */   }
/*      */ 
/*      */   
/*      */   private ExpressionVector parseAll() throws IOException {
/*  134 */     List<SEXP> exprList = Lists.newArrayList();
/*      */ 
/*      */ 
/*      */     
/*      */     while (true)
/*  139 */     { if (this.yylexer.isEof()) {
/*  140 */         return attachSrcrefs(new ExpressionVector(exprList), this.state.srcFile);
/*      */       }
/*      */       
/*  143 */       if (!parse() && 
/*  144 */         this.yylexer.errorEncountered()) {
/*  145 */         throw new ParseException("Syntax error at " + this.yylexer
/*  146 */             .getErrorLocation() + ": " + this.yylexer.getErrorMessage() + "\n");
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  151 */       StatusResult status = getResultStatus();
/*  152 */       switch (status)
/*      */       
/*      */       { 
/*      */         case INCOMPLETE:
/*      */         case OK:
/*  157 */           exprList.add(getResult());
/*      */         
/*      */         case ERROR:
/*  160 */           throw new ParseException(getResultStatus().toString());
/*      */         case EOF:
/*  162 */           break; }  }  return attachSrcrefs(new ExpressionVector(exprList), this.state.srcFile);
/*      */   }
/*      */ 
/*      */   
/*      */   public enum StatusResult
/*      */   {
/*  168 */     EMPTY,
/*  169 */     OK,
/*  170 */     INCOMPLETE,
/*  171 */     ERROR,
/*  172 */     EOF;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean errorVerbose = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private StatusResult extendedParseResult;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private SEXP result;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  204 */   private SEXP srcRefs = NewList();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  209 */   private int srindex = 0; public static final int EOF = 0; public static final int END_OF_INPUT = 258; public static final int ERROR = 259; public static final int STR_CONST = 260; public static final int NUM_CONST = 261; public static final int NULL_CONST = 262; public static final int SYMBOL = 263; public static final int FUNCTION = 264; public static final int LEFT_ASSIGN = 265; public static final int EQ_ASSIGN = 266; public static final int RIGHT_ASSIGN = 267; public static final int LBB = 268; public static final int FOR = 269; public static final int IN = 270; public static final int IF = 271; public static final int ELSE = 272; public static final int WHILE = 273; public static final int NEXT = 274; public static final int BREAK = 275; public static final int REPEAT = 276; public static final int GT = 277; public static final int GE = 278; public static final int LT = 279; public static final int LE = 280; public static final int EQ = 281; public static final int NE = 282; public static final int AND = 283; public static final int OR = 284; public static final int AND2 = 285; public static final int OR2 = 286; public static final int NS_GET = 287; public static final int NS_GET_INT = 288; public static final int LOW = 289; public static final int TILDE = 290; public static final int NOT = 291; public static final int UNOT = 292; public static final int SPECIAL = 293; public static final int UPLUS = 294;
/*      */   public static final int UMINUS = 295;
/*      */   private RLexer yylexer;
/*      */   private PrintStream yyDebugStream;
/*      */   private int yydebug;
/*      */   public static final int YYACCEPT = 0;
/*      */   public static final int YYABORT = 1;
/*      */   public static final int YYERROR = 2;
/*      */   public static final int YYFAIL = 3;
/*      */   private static final int YYNEWSTATE = 4;
/*      */   private static final int YYDEFAULT = 5;
/*      */   private static final int YYREDUCE = 6;
/*      */   private static final int YYERRLAB1 = 7;
/*      */   private static final int YYRETURN = 8;
/*      */   private int yyerrstatus_;
/*      */   private static final short yypact_ninf_ = -53;
/*      */   
/*      */   public class Location { private Position begin;
/*      */     private Position end;
/*      */     
/*      */     public Location(Position loc) {
/*  230 */       this.begin = loc; this.end = loc;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Location(Position begin, Position end) {
/*  240 */       this.begin = begin;
/*  241 */       this.end = end;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String toString() {
/*  251 */       if (getBegin() == null && getEnd() == null) {
/*  252 */         return toString(getBegin());
/*      */       }
/*  254 */       return "" + (
/*  255 */         getBegin().getLine() + 1) + " " + (
/*  256 */         getBegin().getCharIndex() + 1) + " " + (
/*  257 */         getEnd().getLine() + 1) + " " + (
/*  258 */         getEnd().getCharIndex() + 1) + " " + (
/*  259 */         getBegin().getColumn() + 1) + " " + (
/*  260 */         getEnd().getColumn() + 1);
/*      */     }
/*      */ 
/*      */     
/*      */     private String toString(Position p) {
/*  265 */       return (p == null) ? "NULL" : p.toString();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Position getBegin() {
/*  272 */       return this.begin;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Position getEnd() {
/*  279 */       return this.end;
/*      */     } }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Location yylloc(YYStack rhs, int n) {
/*  446 */     if (n > 0) {
/*  447 */       return new Location(rhs.locationAt(n - 1).getBegin(), rhs.locationAt(0).getEnd());
/*      */     }
/*  449 */     return new Location(rhs.locationAt(0).getEnd());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RParser(ParseOptions options, ParseState state, RLexer yylexer)
/*      */   {
/*  524 */     this.yyDebugStream = System.err;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  543 */     this.yydebug = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  687 */     this.yyerrstatus_ = 0; this.yylexer = yylexer; this.options = options; this.state = state; } public RParser(Reader reader) { this.yyDebugStream = System.err; this.yydebug = 0; this.yyerrstatus_ = 0;
/*      */     this.state = new ParseState();
/*      */     this.options = new ParseOptions();
/*      */     this.yylexer = new RLexer(this.options, this.state, reader); }
/*      */   public final PrintStream getDebugStream() { return this.yyDebugStream; }
/*      */   public final void setDebugStream(PrintStream s) { this.yyDebugStream = s; }
/*      */   public final int getDebugLevel() { return this.yydebug; }
/*      */   public final void setDebugLevel(int level) { this.yydebug = level; }
/*  695 */   private final int yylex() throws IOException { return this.yylexer.yylex(); } public final boolean recovering() { return (this.yyerrstatus_ == 0); }
/*      */   protected final void yyerror(Location loc, String s) { this.yylexer.yyerror(loc, s); }
/*      */   protected final void yyerror(String s) { this.yylexer.yyerror((Location)null, s); }
/*      */   protected final void yyerror(Position loc, String s) { this.yylexer.yyerror(new Location(loc), s); }
/*      */   protected final void yycdebug(String s) { if (this.yydebug > 0) this.yyDebugStream.println(s);  } private final class YYStack {
/*  700 */     private int[] stateStack = new int[16]; private RParser.Location[] locStack = new RParser.Location[16]; private Object[] valueStack = new Object[16]; public int size = 16; public int height = -1; public final void push(int state, Object value, RParser.Location loc) { this.height++; if (this.size == this.height) { int[] newStateStack = new int[this.size * 2]; System.arraycopy(this.stateStack, 0, newStateStack, 0, this.height); this.stateStack = newStateStack; RParser.Location[] newLocStack = new RParser.Location[this.size * 2]; System.arraycopy(this.locStack, 0, newLocStack, 0, this.height); this.locStack = newLocStack; Object[] newValueStack = new Object[this.size * 2]; System.arraycopy(this.valueStack, 0, newValueStack, 0, this.height); this.valueStack = newValueStack; this.size *= 2; }  this.stateStack[this.height] = state; this.locStack[this.height] = loc; this.valueStack[this.height] = value; } public final void pop() { this.height--; } public final void pop(int num) { if (num > 0) { Arrays.fill(this.valueStack, this.height - num + 1, this.height, (Object)null); Arrays.fill((Object[])this.locStack, this.height - num + 1, this.height, (Object)null); }  this.height -= num; } public final int stateAt(int i) { return this.stateStack[this.height - i]; } public final RParser.Location locationAt(int i) { return this.locStack[this.height - i]; } public final SEXP valueAt(int i) { return (SEXP)this.valueStack[this.height - i]; } public void print(PrintStream out) { out.print("Stack now"); for (int i = 0; i < this.height; i++) { out.print(' '); out.print(this.stateStack[i]); out.print("(" + this.locStack[i] + ")"); }  out.println(); } private YYStack() {} } private int yyaction(int yyn, YYStack yystack, int yylen) { Object object; Location yyloc = yylloc(yystack, yylen);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  708 */     if (yylen > 0) {
/*  709 */       object = yystack.valueAt(yylen - 1);
/*      */     } else {
/*  711 */       object = yystack.valueAt(0);
/*      */     } 
/*      */     
/*  714 */     yy_reduce_print(yyn, yystack);
/*      */     
/*  716 */     switch (yyn) {
/*      */       case 2:
/*  718 */         if (yyn == 2)
/*      */         {
/*      */ 
/*      */           
/*  722 */           return 3;
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 3:
/*  729 */         if (yyn == 3)
/*      */         {
/*      */ 
/*      */           
/*  733 */           return xxvalue(null, StatusResult.EMPTY, null);
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 4:
/*  740 */         if (yyn == 4)
/*      */         {
/*      */ 
/*      */           
/*  744 */           return xxvalue(yystack.valueAt(1), StatusResult.INCOMPLETE, yystack.locationAt(1));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 5:
/*  751 */         if (yyn == 5)
/*      */         {
/*      */ 
/*      */           
/*  755 */           return xxvalue(yystack.valueAt(1), StatusResult.OK, yystack.locationAt(1));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 6:
/*  762 */         if (yyn == 6)
/*      */         {
/*      */ 
/*      */           
/*  766 */           return 1;
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 7:
/*  773 */         if (yyn == 7)
/*      */         {
/*      */ 
/*      */           
/*  777 */           object = yystack.valueAt(0);
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 8:
/*  784 */         if (yyn == 8)
/*      */         {
/*      */ 
/*      */           
/*  788 */           object = yystack.valueAt(0);
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 9:
/*  795 */         if (yyn == 9)
/*      */         {
/*      */ 
/*      */           
/*  799 */           object = xxbinary(yystack.valueAt(1), yystack.valueAt(2), yystack.valueAt(0));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 10:
/*  806 */         if (yyn == 10)
/*      */         {
/*      */ 
/*      */           
/*  810 */           object = yystack.valueAt(0);
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 11:
/*  817 */         if (yyn == 11)
/*      */         {
/*      */ 
/*      */           
/*  821 */           object = yystack.valueAt(0);
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 12:
/*  828 */         if (yyn == 12)
/*      */         {
/*      */ 
/*      */           
/*  832 */           object = yystack.valueAt(0);
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 13:
/*  839 */         if (yyn == 13)
/*      */         {
/*      */ 
/*      */           
/*  843 */           object = yystack.valueAt(0);
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 14:
/*  850 */         if (yyn == 14)
/*      */         {
/*      */ 
/*      */           
/*  854 */           object = xxexprlist(yystack.valueAt(2), yystack.locationAt(2), yystack.valueAt(1));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 15:
/*  861 */         if (yyn == 15)
/*      */         {
/*      */ 
/*      */           
/*  865 */           object = xxparen(yystack.valueAt(2), yystack.valueAt(1));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 16:
/*  872 */         if (yyn == 16)
/*      */         {
/*      */ 
/*      */           
/*  876 */           object = xxunary(yystack.valueAt(1), yystack.valueAt(0));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 17:
/*  883 */         if (yyn == 17)
/*      */         {
/*      */ 
/*      */           
/*  887 */           object = xxunary(yystack.valueAt(1), yystack.valueAt(0));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 18:
/*  894 */         if (yyn == 18)
/*      */         {
/*      */ 
/*      */           
/*  898 */           object = xxunary(yystack.valueAt(1), yystack.valueAt(0));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 19:
/*  905 */         if (yyn == 19)
/*      */         {
/*      */ 
/*      */           
/*  909 */           object = xxunary(yystack.valueAt(1), yystack.valueAt(0));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 20:
/*  916 */         if (yyn == 20)
/*      */         {
/*      */ 
/*      */           
/*  920 */           object = xxunary(yystack.valueAt(1), yystack.valueAt(0));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 21:
/*  927 */         if (yyn == 21)
/*      */         {
/*      */ 
/*      */           
/*  931 */           object = xxbinary(yystack.valueAt(1), yystack.valueAt(2), yystack.valueAt(0));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 22:
/*  938 */         if (yyn == 22)
/*      */         {
/*      */ 
/*      */           
/*  942 */           object = xxbinary(yystack.valueAt(1), yystack.valueAt(2), yystack.valueAt(0));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 23:
/*  949 */         if (yyn == 23)
/*      */         {
/*      */ 
/*      */           
/*  953 */           object = xxbinary(yystack.valueAt(1), yystack.valueAt(2), yystack.valueAt(0));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 24:
/*  960 */         if (yyn == 24)
/*      */         {
/*      */ 
/*      */           
/*  964 */           object = xxbinary(yystack.valueAt(1), yystack.valueAt(2), yystack.valueAt(0));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 25:
/*  971 */         if (yyn == 25)
/*      */         {
/*      */ 
/*      */           
/*  975 */           object = xxbinary(yystack.valueAt(1), yystack.valueAt(2), yystack.valueAt(0));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 26:
/*  982 */         if (yyn == 26)
/*      */         {
/*      */ 
/*      */           
/*  986 */           object = xxbinary(yystack.valueAt(1), yystack.valueAt(2), yystack.valueAt(0));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 27:
/*  993 */         if (yyn == 27)
/*      */         {
/*      */ 
/*      */           
/*  997 */           object = xxbinary(yystack.valueAt(1), yystack.valueAt(2), yystack.valueAt(0));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 28:
/* 1004 */         if (yyn == 28)
/*      */         {
/*      */ 
/*      */           
/* 1008 */           object = xxbinary(yystack.valueAt(1), yystack.valueAt(2), yystack.valueAt(0));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 29:
/* 1015 */         if (yyn == 29)
/*      */         {
/*      */ 
/*      */           
/* 1019 */           object = xxbinary(yystack.valueAt(1), yystack.valueAt(2), yystack.valueAt(0));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 30:
/* 1026 */         if (yyn == 30)
/*      */         {
/*      */ 
/*      */           
/* 1030 */           object = xxbinary(yystack.valueAt(1), yystack.valueAt(2), yystack.valueAt(0));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 31:
/* 1037 */         if (yyn == 31)
/*      */         {
/*      */ 
/*      */           
/* 1041 */           object = xxbinary(yystack.valueAt(1), yystack.valueAt(2), yystack.valueAt(0));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 32:
/* 1048 */         if (yyn == 32)
/*      */         {
/*      */ 
/*      */           
/* 1052 */           object = xxbinary(yystack.valueAt(1), yystack.valueAt(2), yystack.valueAt(0));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 33:
/* 1059 */         if (yyn == 33)
/*      */         {
/*      */ 
/*      */           
/* 1063 */           object = xxbinary(yystack.valueAt(1), yystack.valueAt(2), yystack.valueAt(0));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 34:
/* 1070 */         if (yyn == 34)
/*      */         {
/*      */ 
/*      */           
/* 1074 */           object = xxbinary(yystack.valueAt(1), yystack.valueAt(2), yystack.valueAt(0));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 35:
/* 1081 */         if (yyn == 35)
/*      */         {
/*      */ 
/*      */           
/* 1085 */           object = xxbinary(yystack.valueAt(1), yystack.valueAt(2), yystack.valueAt(0));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 36:
/* 1092 */         if (yyn == 36)
/*      */         {
/*      */ 
/*      */           
/* 1096 */           object = xxbinary(yystack.valueAt(1), yystack.valueAt(2), yystack.valueAt(0));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 37:
/* 1103 */         if (yyn == 37)
/*      */         {
/*      */ 
/*      */           
/* 1107 */           object = xxbinary(yystack.valueAt(1), yystack.valueAt(2), yystack.valueAt(0));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 38:
/* 1114 */         if (yyn == 38)
/*      */         {
/*      */ 
/*      */           
/* 1118 */           object = xxbinary(yystack.valueAt(1), yystack.valueAt(2), yystack.valueAt(0));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 39:
/* 1125 */         if (yyn == 39)
/*      */         {
/*      */ 
/*      */           
/* 1129 */           object = xxbinary(yystack.valueAt(1), yystack.valueAt(2), yystack.valueAt(0));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 40:
/* 1136 */         if (yyn == 40)
/*      */         {
/*      */ 
/*      */           
/* 1140 */           object = xxbinary(yystack.valueAt(1), yystack.valueAt(2), yystack.valueAt(0));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 41:
/* 1147 */         if (yyn == 41)
/*      */         {
/*      */ 
/*      */           
/* 1151 */           object = xxbinary(yystack.valueAt(1), yystack.valueAt(2), yystack.valueAt(0));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 42:
/* 1158 */         if (yyn == 42)
/*      */         {
/*      */ 
/*      */           
/* 1162 */           object = xxbinary(yystack.valueAt(1), yystack.valueAt(0), yystack.valueAt(2));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 43:
/* 1169 */         if (yyn == 43)
/*      */         {
/*      */ 
/*      */           
/* 1173 */           object = xxdefun(yystack.valueAt(5), yystack.valueAt(3), yystack.valueAt(0), yystack.locationAt(0));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 44:
/* 1180 */         if (yyn == 44)
/*      */         {
/*      */ 
/*      */           
/* 1184 */           object = xxfuncall(yystack.valueAt(3), yystack.valueAt(1));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 45:
/* 1191 */         if (yyn == 45)
/*      */         {
/*      */ 
/*      */           
/* 1195 */           object = xxif(yystack.valueAt(2), yystack.valueAt(1), yystack.valueAt(0));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 46:
/* 1202 */         if (yyn == 46)
/*      */         {
/*      */ 
/*      */           
/* 1206 */           object = xxifelse(yystack.valueAt(4), yystack.valueAt(3), yystack.valueAt(2), yystack.valueAt(0));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 47:
/* 1213 */         if (yyn == 47)
/*      */         {
/*      */ 
/*      */           
/* 1217 */           object = xxfor(yystack.valueAt(2), yystack.valueAt(1), yystack.valueAt(0));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 48:
/* 1224 */         if (yyn == 48)
/*      */         {
/*      */ 
/*      */           
/* 1228 */           object = xxwhile(yystack.valueAt(2), yystack.valueAt(1), yystack.valueAt(0));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 49:
/* 1235 */         if (yyn == 49)
/*      */         {
/*      */ 
/*      */           
/* 1239 */           object = xxrepeat(yystack.valueAt(1), yystack.valueAt(0));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 50:
/* 1246 */         if (yyn == 50)
/*      */         {
/*      */ 
/*      */           
/* 1250 */           object = xxsubscript(yystack.valueAt(4), yystack.valueAt(3), yystack.valueAt(2));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 51:
/* 1257 */         if (yyn == 51)
/*      */         {
/*      */ 
/*      */           
/* 1261 */           object = xxsubscript(yystack.valueAt(3), yystack.valueAt(2), yystack.valueAt(1));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 52:
/* 1268 */         if (yyn == 52)
/*      */         {
/*      */ 
/*      */           
/* 1272 */           object = xxbinary(yystack.valueAt(1), yystack.valueAt(2), yystack.valueAt(0));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 53:
/* 1279 */         if (yyn == 53)
/*      */         {
/*      */ 
/*      */           
/* 1283 */           object = xxbinary(yystack.valueAt(1), yystack.valueAt(2), yystack.valueAt(0));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 54:
/* 1290 */         if (yyn == 54)
/*      */         {
/*      */ 
/*      */           
/* 1294 */           object = xxbinary(yystack.valueAt(1), yystack.valueAt(2), yystack.valueAt(0));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 55:
/* 1301 */         if (yyn == 55)
/*      */         {
/*      */ 
/*      */           
/* 1305 */           object = xxbinary(yystack.valueAt(1), yystack.valueAt(2), yystack.valueAt(0));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 56:
/* 1312 */         if (yyn == 56)
/*      */         {
/*      */ 
/*      */           
/* 1316 */           object = xxbinary(yystack.valueAt(1), yystack.valueAt(2), yystack.valueAt(0));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 57:
/* 1323 */         if (yyn == 57)
/*      */         {
/*      */ 
/*      */           
/* 1327 */           object = xxbinary(yystack.valueAt(1), yystack.valueAt(2), yystack.valueAt(0));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 58:
/* 1334 */         if (yyn == 58)
/*      */         {
/*      */ 
/*      */           
/* 1338 */           object = xxbinary(yystack.valueAt(1), yystack.valueAt(2), yystack.valueAt(0));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 59:
/* 1345 */         if (yyn == 59)
/*      */         {
/*      */ 
/*      */           
/* 1349 */           object = xxbinary(yystack.valueAt(1), yystack.valueAt(2), yystack.valueAt(0));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 60:
/* 1356 */         if (yyn == 60)
/*      */         {
/*      */ 
/*      */           
/* 1360 */           object = xxbinary(yystack.valueAt(1), yystack.valueAt(2), yystack.valueAt(0));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 61:
/* 1367 */         if (yyn == 61)
/*      */         {
/*      */ 
/*      */           
/* 1371 */           object = xxbinary(yystack.valueAt(1), yystack.valueAt(2), yystack.valueAt(0));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 62:
/* 1378 */         if (yyn == 62)
/*      */         {
/*      */ 
/*      */           
/* 1382 */           object = xxbinary(yystack.valueAt(1), yystack.valueAt(2), yystack.valueAt(0));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 63:
/* 1389 */         if (yyn == 63)
/*      */         {
/*      */ 
/*      */           
/* 1393 */           object = xxbinary(yystack.valueAt(1), yystack.valueAt(2), yystack.valueAt(0));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 64:
/* 1400 */         if (yyn == 64)
/*      */         {
/*      */ 
/*      */           
/* 1404 */           object = xxnxtbrk(yystack.valueAt(0));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 65:
/* 1411 */         if (yyn == 65)
/*      */         {
/*      */ 
/*      */           
/* 1415 */           object = xxnxtbrk(yystack.valueAt(0));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 66:
/* 1422 */         if (yyn == 66)
/*      */         {
/*      */ 
/*      */           
/* 1426 */           object = xxcond(yystack.valueAt(1));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 67:
/* 1433 */         if (yyn == 67)
/*      */         {
/*      */ 
/*      */           
/* 1437 */           object = xxifcond(yystack.valueAt(1));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 68:
/* 1444 */         if (yyn == 68)
/*      */         {
/*      */ 
/*      */           
/* 1448 */           object = xxforcond(yystack.valueAt(3), yystack.valueAt(1));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 69:
/* 1455 */         if (yyn == 69)
/*      */         {
/*      */ 
/*      */           
/* 1459 */           object = xxexprlist0();
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 70:
/* 1466 */         if (yyn == 70)
/*      */         {
/*      */ 
/*      */           
/* 1470 */           object = xxexprlist1(yystack.valueAt(0), yystack.locationAt(0));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 71:
/* 1477 */         if (yyn == 71)
/*      */         {
/*      */ 
/*      */           
/* 1481 */           object = xxexprlist2(yystack.valueAt(2), yystack.valueAt(0), yystack.locationAt(0));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 72:
/* 1488 */         if (yyn == 72)
/*      */         {
/*      */ 
/*      */           
/* 1492 */           object = yystack.valueAt(1);
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 73:
/* 1499 */         if (yyn == 73)
/*      */         {
/*      */ 
/*      */           
/* 1503 */           object = xxexprlist2(yystack.valueAt(2), yystack.valueAt(0), yystack.locationAt(0));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 74:
/* 1510 */         if (yyn == 74)
/*      */         {
/*      */ 
/*      */           
/* 1514 */           object = yystack.valueAt(1);
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 75:
/* 1521 */         if (yyn == 75)
/*      */         {
/*      */ 
/*      */           
/* 1525 */           object = xxsublist1(yystack.valueAt(0));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 76:
/* 1532 */         if (yyn == 76)
/*      */         {
/*      */ 
/*      */           
/* 1536 */           object = xxsublist2(yystack.valueAt(3), yystack.valueAt(0));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 77:
/* 1543 */         if (yyn == 77)
/*      */         {
/*      */ 
/*      */           
/* 1547 */           object = xxsub0();
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 78:
/* 1554 */         if (yyn == 78)
/*      */         {
/*      */ 
/*      */           
/* 1558 */           object = xxsub1(yystack.valueAt(0), yystack.locationAt(0));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 79:
/* 1565 */         if (yyn == 79)
/*      */         {
/*      */ 
/*      */           
/* 1569 */           object = xxsymsub0(yystack.valueAt(1), yystack.locationAt(1));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 80:
/* 1576 */         if (yyn == 80)
/*      */         {
/*      */ 
/*      */           
/* 1580 */           object = xxsymsub1(yystack.valueAt(2), yystack.valueAt(0), yystack.locationAt(2));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 81:
/* 1587 */         if (yyn == 81)
/*      */         {
/*      */ 
/*      */           
/* 1591 */           object = xxsymsub0(yystack.valueAt(1), yystack.locationAt(1));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 82:
/* 1598 */         if (yyn == 82)
/*      */         {
/*      */ 
/*      */           
/* 1602 */           object = xxsymsub1(yystack.valueAt(2), yystack.valueAt(0), yystack.locationAt(2));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 83:
/* 1609 */         if (yyn == 83)
/*      */         {
/*      */ 
/*      */           
/* 1613 */           object = xxnullsub0(yystack.locationAt(1));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 84:
/* 1620 */         if (yyn == 84)
/*      */         {
/*      */ 
/*      */           
/* 1624 */           object = xxnullsub1(yystack.valueAt(0), yystack.locationAt(2));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 85:
/* 1631 */         if (yyn == 85)
/*      */         {
/*      */ 
/*      */           
/* 1635 */           object = xxnullformal();
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 86:
/* 1642 */         if (yyn == 86)
/*      */         {
/*      */ 
/*      */           
/* 1646 */           object = xxfirstformal0(yystack.valueAt(0));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 87:
/* 1653 */         if (yyn == 87)
/*      */         {
/*      */ 
/*      */           
/* 1657 */           object = xxfirstformal1(yystack.valueAt(2), yystack.valueAt(0));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 88:
/* 1664 */         if (yyn == 88)
/*      */         {
/*      */ 
/*      */           
/* 1668 */           object = xxaddformal0(yystack.valueAt(2), yystack.valueAt(0), yystack.locationAt(0));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 89:
/* 1675 */         if (yyn == 89)
/*      */         {
/*      */ 
/*      */           
/* 1679 */           object = xxaddformal1(yystack.valueAt(4), yystack.valueAt(2), yystack.valueAt(0), yystack.locationAt(2));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 90:
/* 1686 */         if (yyn == 90)
/*      */         {
/*      */ 
/*      */           
/* 1690 */           this.state.setEatLines(true);
/*      */         }
/*      */         break;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1702 */     yy_symbol_print("-> $$ =", yyr1_[yyn], object, yyloc);
/*      */     
/* 1704 */     yystack.pop(yylen);
/* 1705 */     yylen = 0;
/*      */ 
/*      */     
/* 1708 */     yyn = yyr1_[yyn];
/* 1709 */     int yystate = yypgoto_[yyn - 62] + yystack.stateAt(0);
/* 1710 */     if (0 <= yystate && yystate <= 709 && yycheck_[yystate] == yystack
/* 1711 */       .stateAt(0)) {
/* 1712 */       yystate = yytable_[yystate];
/*      */     } else {
/* 1714 */       yystate = yydefgoto_[yyn - 62];
/*      */     } 
/*      */     
/* 1717 */     yystack.push(yystate, object, yyloc);
/* 1718 */     return 4; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final String yytnamerr_(String yystr) {
/* 1728 */     if (yystr.charAt(0) == '"') {
/* 1729 */       StringBuffer yyr = new StringBuffer();
/*      */       
/* 1731 */       for (int i = 1; i < yystr.length(); i++) {
/* 1732 */         switch (yystr.charAt(i)) {
/*      */           case '\'':
/*      */           case ',':
/*      */             break;
/*      */           
/*      */           case '\\':
/* 1738 */             if (yystr.charAt(++i) != '\\') {
/*      */               break;
/*      */             }
/*      */           
/*      */           default:
/* 1743 */             yyr.append(yystr.charAt(i));
/*      */             break;
/*      */           
/*      */           case '"':
/* 1747 */             return yyr.toString();
/*      */         } 
/*      */       } 
/* 1750 */     } else if (yystr.equals("$end")) {
/* 1751 */       return "end of input";
/*      */     } 
/*      */     
/* 1754 */     return yystr;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void yy_symbol_print(String s, int yytype, Object yyvaluep, Object yylocationp) {
/* 1763 */     if (this.yydebug > 0) {
/* 1764 */       yycdebug(s + ((yytype < 62) ? " token " : " nterm ") + yytname_[yytype] + " (" + yylocationp + ": " + ((yyvaluep == null) ? "(null)" : yyvaluep
/*      */ 
/*      */           
/* 1767 */           .toString()) + ")");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean parse() throws IOException {
/* 1780 */     int yychar = -2;
/* 1781 */     int yytoken = 0;
/*      */ 
/*      */     
/* 1784 */     int yyn = 0;
/* 1785 */     int yylen = 0;
/* 1786 */     int yystate = 0;
/*      */     
/* 1788 */     YYStack yystack = new YYStack();
/*      */ 
/*      */     
/* 1791 */     int yynerrs_ = 0;
/*      */     
/* 1793 */     Location yyerrloc = null;
/*      */ 
/*      */     
/* 1796 */     Location yylloc = new Location(new Position());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1802 */     Object yylval = null;
/*      */ 
/*      */ 
/*      */     
/* 1806 */     yycdebug("Starting parse\n");
/* 1807 */     this.yyerrstatus_ = 0;
/*      */ 
/*      */ 
/*      */     
/* 1811 */     yystack.push(yystate, yylval, yylloc);
/*      */     
/* 1813 */     int label = 4; while (true) {
/*      */       Location yyloc;
/* 1815 */       switch (label) {
/*      */ 
/*      */         
/*      */         case 4:
/* 1819 */           yycdebug("Entering state " + yystate + "\n");
/* 1820 */           if (this.yydebug > 0) {
/* 1821 */             yystack.print(this.yyDebugStream);
/*      */           }
/*      */ 
/*      */           
/* 1825 */           if (yystate == 46) {
/* 1826 */             return true;
/*      */           }
/*      */ 
/*      */           
/* 1830 */           yyn = yypact_[yystate];
/* 1831 */           if (yyn == -53) {
/* 1832 */             label = 5;
/*      */             
/*      */             continue;
/*      */           } 
/*      */           
/* 1837 */           if (yychar == -2) {
/* 1838 */             yycdebug("Reading a token: ");
/* 1839 */             yychar = yylex();
/*      */ 
/*      */             
/* 1842 */             yylloc = new Location(this.yylexer.getStartPos(), this.yylexer.getEndPos());
/* 1843 */             yylval = this.yylexer.getLVal();
/*      */           } 
/*      */ 
/*      */           
/* 1847 */           if (yychar <= 0) {
/* 1848 */             yychar = yytoken = 0;
/* 1849 */             yycdebug("Now at end of input.\n");
/*      */           } else {
/* 1851 */             yytoken = yytranslate_(yychar);
/* 1852 */             yy_symbol_print("Next token is", yytoken, yylval, yylloc);
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1858 */           yyn += yytoken;
/* 1859 */           if (yyn < 0 || 709 < yyn || yycheck_[yyn] != yytoken) {
/* 1860 */             label = 5; continue;
/* 1861 */           }  if ((yyn = yytable_[yyn]) <= 0) {
/* 1862 */             if (yyn == 0 || yyn == -1) {
/* 1863 */               label = 3; continue;
/*      */             } 
/* 1865 */             yyn = -yyn;
/* 1866 */             label = 6;
/*      */             
/*      */             continue;
/*      */           } 
/* 1870 */           yy_symbol_print("Shifting", yytoken, yylval, yylloc);
/*      */ 
/*      */ 
/*      */           
/* 1874 */           yychar = -2;
/*      */ 
/*      */ 
/*      */           
/* 1878 */           if (this.yyerrstatus_ > 0) {
/* 1879 */             this.yyerrstatus_--;
/*      */           }
/*      */           
/* 1882 */           yystate = yyn;
/* 1883 */           yystack.push(yystate, yylval, yylloc);
/* 1884 */           label = 4;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 5:
/* 1892 */           yyn = yydefact_[yystate];
/* 1893 */           if (yyn == 0) {
/* 1894 */             label = 3; continue;
/*      */           } 
/* 1896 */           label = 6;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 6:
/* 1904 */           yylen = yyr2_[yyn];
/* 1905 */           label = yyaction(yyn, yystack, yylen);
/* 1906 */           yystate = yystack.stateAt(0);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 3:
/* 1914 */           if (this.yyerrstatus_ == 0) {
/* 1915 */             yynerrs_++;
/* 1916 */             yyerror(yylloc, yysyntax_error(yystate, yytoken));
/*      */           } 
/*      */           
/* 1919 */           yyerrloc = yylloc;
/* 1920 */           if (this.yyerrstatus_ == 3)
/*      */           {
/*      */ 
/*      */             
/* 1924 */             if (yychar <= 0) {
/*      */               
/* 1926 */               if (yychar == 0) {
/* 1927 */                 return false;
/*      */               }
/*      */             } else {
/* 1930 */               yychar = -2;
/*      */             } 
/*      */           }
/*      */ 
/*      */ 
/*      */           
/* 1936 */           label = 7;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 2:
/* 1944 */           yyerrloc = yystack.locationAt(yylen - 1);
/*      */ 
/*      */           
/* 1947 */           yystack.pop(yylen);
/* 1948 */           yylen = 0;
/* 1949 */           yystate = yystack.stateAt(0);
/* 1950 */           label = 7;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 7:
/* 1957 */           this.yyerrstatus_ = 3;
/*      */           
/*      */           while (true) {
/* 1960 */             yyn = yypact_[yystate];
/* 1961 */             if (yyn != -53) {
/* 1962 */               yyn++;
/* 1963 */               if (0 <= yyn && yyn <= 709 && yycheck_[yyn] == 1) {
/* 1964 */                 yyn = yytable_[yyn];
/* 1965 */                 if (0 < yyn) {
/*      */                   break;
/*      */                 }
/*      */               } 
/*      */             } 
/*      */ 
/*      */             
/* 1972 */             if (yystack.height == 1) {
/* 1973 */               return false;
/*      */             }
/*      */             
/* 1976 */             yyerrloc = yystack.locationAt(0);
/* 1977 */             yystack.pop();
/* 1978 */             yystate = yystack.stateAt(0);
/* 1979 */             if (this.yydebug > 0) {
/* 1980 */               yystack.print(this.yyDebugStream);
/*      */             }
/*      */           } 
/*      */ 
/*      */ 
/*      */           
/* 1986 */           yystack.push(0, null, yylloc);
/* 1987 */           yystack.push(0, null, yyerrloc);
/* 1988 */           yyloc = yylloc(yystack, 2);
/* 1989 */           yystack.pop(2);
/*      */ 
/*      */           
/* 1992 */           yy_symbol_print("Shifting", yystos_[yyn], yylval, yyloc);
/*      */ 
/*      */           
/* 1995 */           yystate = yyn;
/* 1996 */           yystack.push(yyn, yylval, yyloc);
/* 1997 */           label = 4;
/*      */ 
/*      */ 
/*      */         
/*      */         case 0:
/* 2002 */           return true;
/*      */         case 1:
/*      */           break;
/*      */       } 
/* 2006 */     }  return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String yysyntax_error(int yystate, int tok) {
/* 2014 */     if (this.errorVerbose) {
/* 2015 */       int yyn = yypact_[yystate];
/* 2016 */       if (-53 < yyn && yyn <= 709) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2021 */         int yyxbegin = (yyn < 0) ? -yyn : 0;
/*      */ 
/*      */         
/* 2024 */         int yychecklim = 709 - yyn + 1;
/* 2025 */         int yyxend = (yychecklim < 62) ? yychecklim : 62;
/* 2026 */         int count = 0; int x;
/* 2027 */         for (x = yyxbegin; x < yyxend; x++) {
/* 2028 */           if (yycheck_[x + yyn] == x && x != 1) {
/* 2029 */             count++;
/*      */           }
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 2035 */         StringBuffer res = new StringBuffer("syntax error, unexpected ");
/* 2036 */         res.append(yytnamerr_(yytname_[tok]));
/* 2037 */         if (count < 5) {
/* 2038 */           count = 0;
/* 2039 */           for (x = yyxbegin; x < yyxend; x++) {
/* 2040 */             if (yycheck_[x + yyn] == x && x != 1) {
/* 2041 */               res.append((count++ == 0) ? ", expecting " : " or ");
/* 2042 */               res.append(yytnamerr_(yytname_[x]));
/*      */             } 
/*      */           } 
/*      */         } 
/* 2046 */         return res.toString();
/*      */       } 
/*      */     } 
/*      */     
/* 2050 */     return "syntax error";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2057 */   private static final short[] yypact_ = new short[] { 83, -53, -53, 37, -53, -53, 61, -35, -33, -29, -27, -53, -53, 144, 144, 144, 144, 144, 144, -53, 144, 144, 8, 56, -53, 235, 7, 9, 15, 24, 58, 70, 144, 144, 144, 144, 144, -53, 450, 530, 141, 141, 2, -53, -43, 610, -53, -53, -53, 144, 144, 144, 198, 144, 144, 144, 144, 144, 144, 144, 144, 144, 144, 144, 144, 144, 144, 144, 144, 144, 144, 144, 25, 26, 198, 198, 144, -53, -53, -53, -53, -53, -53, -53, -53, 53, -52, 65, -53, 278, 66, 321, -53, -53, 144, 144, -53, 450, -53, 490, -7, 74, -5, 407, 27, -53, 650, 650, 650, 650, 650, 650, 610, 570, 610, 570, 450, 530, 63, 63, 23, 23, 122, 141, 141, -53, -53, -53, -53, 39, 38, 407, 144, -53, 92, 144, -53, 144, -53, -53, -53, 144, 144, 144, 60, 55, -53, -53, 407, 144, 119, 364, -53, 407, 407, 407, -53, 198, -53, 144, -53, -53, 407 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2081 */   private static final byte[] yydefact_ = new byte[] { 0, 6, 2, 11, 10, 12, 13, 0, 0, 0, 0, 64, 65, 0, 0, 0, 0, 0, 0, 3, 69, 0, 0, 0, 8, 7, 0, 0, 0, 0, 85, 0, 0, 0, 0, 0, 0, 49, 20, 19, 17, 16, 0, 70, 0, 18, 1, 4, 5, 0, 0, 0, 77, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 77, 77, 0, 55, 54, 59, 58, 53, 52, 57, 56, 86, 0, 0, 47, 0, 45, 0, 48, 15, 74, 72, 14, 41, 9, 42, 11, 12, 13, 78, 90, 75, 36, 35, 31, 32, 33, 34, 37, 38, 39, 40, 30, 29, 22, 23, 24, 25, 27, 21, 26, 61, 60, 63, 62, 90, 90, 28, 0, 90, 0, 0, 67, 0, 66, 73, 71, 81, 83, 79, 0, 0, 44, 51, 87, 0, 88, 0, 46, 82, 84, 80, 50, 77, 43, 0, 68, 76, 89 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2103 */   private static final byte[] yypgoto_ = new byte[] { -53, -53, 45, -53, -14, -53, -53, -53, -53, 51, -26, -53, -1 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2111 */   private static final short[] yydefgoto_ = new short[] { -1, 22, 23, 24, 25, 36, 34, 32, 44, 104, 105, 86, 145 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final short yytable_ninf_ = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2122 */   private static final short[] yytable_ = new short[] { 38, 39, 40, 41, 141, 133, 143, 45, 46, 134, 94, 95, 77, 96, 79, 78, 30, 80, 31, 89, 81, 91, 33, 82, 35, 26, 27, 28, 29, 83, 125, 127, 84, 126, 128, 97, 52, 99, 103, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 37, 93, 103, 103, 131, 42, 132, 43, 85, 69, 70, 26, 27, 71, 72, 73, 74, 75, 52, 88, 87, 90, 135, 92, 76, 137, 1, 142, 2, 144, 3, 4, 5, 6, 7, 28, 29, 98, 146, 8, 147, 9, 150, 10, 11, 12, 13, 67, 68, 69, 70, 47, 48, 71, 72, 73, 74, 75, 157, 14, 148, 15, 156, 151, 76, 16, 17, 129, 130, 153, 154, 155, 159, 161, 149, 0, 18, 52, 19, 0, 20, 139, 140, 21, 0, 103, 0, 162, 0, 0, 0, 3, 4, 5, 6, 7, 52, 0, 0, 0, 8, 0, 9, 0, 10, 11, 12, 13, 0, 70, 0, 0, 71, 72, 73, 74, 75, 0, 0, 0, 14, 0, 15, 76, 152, 0, 16, 17, 0, 0, 0, 71, 72, 73, 74, 75, 158, 18, 0, 0, 0, 20, 76, 0, 21, 100, 4, 101, 102, 7, 0, 0, 0, 0, 8, 0, 9, 0, 10, 11, 12, 13, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 14, 0, 15, 0, 0, 0, 16, 17, 0, 0, 0, 0, 0, 49, 50, 51, 52, 18, 0, 0, 0, 20, 0, 0, 21, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 0, 0, 63, 0, 64, 0, 0, 0, 65, 66, 67, 68, 69, 70, 0, 0, 71, 72, 73, 74, 75, 49, 0, 51, 52, 0, 0, 76, 0, 0, 0, 0, 0, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 0, 0, 63, 0, 64, 0, 0, 0, 65, 66, 67, 68, 69, 70, 0, 0, 71, 72, 73, 74, 75, 49, 0, 51, 52, 136, 0, 76, 0, 0, 0, 0, 0, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 0, 0, 63, 0, 64, 0, 0, 0, 65, 66, 67, 68, 69, 70, 0, 0, 71, 72, 73, 74, 75, 49, 0, 51, 52, 138, 0, 76, 0, 0, 0, 0, 0, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 0, 0, 63, 0, 64, 0, 0, 0, 65, 66, 67, 68, 69, 70, 0, 0, 71, 72, 73, 74, 75, 49, 0, 51, 52, 160, 0, 76, 0, 0, 0, 0, 0, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 0, 0, 63, 0, 64, 0, 0, 0, 65, 66, 67, 68, 69, 70, 0, 0, 71, 72, 73, 74, 75, 49, 0, 51, 52, 0, 0, 76, 0, 0, 0, 0, 0, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 0, 0, 0, 0, 64, 0, 0, 0, 65, 66, 67, 68, 69, 70, 0, 0, 71, 72, 73, 74, 75, 52, 0, 0, 0, 0, 0, 76, 0, 0, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 0, 0, 0, 0, 64, 0, 0, 0, 65, 66, 67, 68, 69, 70, 0, 0, 71, 72, 73, 74, 75, 52, 0, 0, 0, 0, 0, 76, 0, 0, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 0, 0, 0, 0, 0, 0, 0, 0, 65, 66, 67, 68, 69, 70, 0, 0, 71, 72, 73, 74, 75, 52, 0, 0, 0, 0, 0, 76, 0, 0, 53, 54, 55, 56, 57, 58, 59, 0, 61, 0, 0, 0, 0, 0, 0, 0, 0, 0, 65, 66, 67, 68, 69, 70, 0, 0, 71, 72, 73, 74, 75, 52, 0, 0, 0, 0, 0, 76, 0, 0, 53, 54, 55, 56, 57, 58, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 65, 66, 67, 68, 69, 70, 0, 0, 71, 72, 73, 74, 75, 52, 0, 0, 0, 0, 0, 76, 0, 0, -1, -1, -1, -1, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 65, 66, 67, 68, 69, 70, 0, 0, 71, 72, 73, 74, 75, 0, 0, 0, 0, 0, 0, 76 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2199 */   private static final short[] yycheck_ = new short[] { 14, 15, 16, 17, 11, 57, 11, 21, 0, 61, 53, 54, 5, 56, 5, 8, 51, 8, 51, 33, 5, 35, 51, 8, 51, 32, 33, 32, 33, 5, 5, 5, 8, 8, 8, 49, 13, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 13, 57, 74, 75, 76, 18, 11, 20, 8, 44, 45, 32, 33, 48, 49, 50, 51, 52, 13, 32, 8, 34, 15, 36, 59, 17, 1, 11, 3, 60, 5, 6, 7, 8, 9, 32, 33, 50, 57, 14, 60, 16, 8, 18, 19, 20, 21, 42, 43, 44, 45, 53, 54, 48, 49, 50, 51, 52, 61, 34, 132, 36, 60, 135, 59, 40, 41, 74, 75, 141, 142, 143, 11, 157, 133, -1, 51, 13, 53, -1, 55, 94, 95, 58, -1, 157, -1, 159, -1, -1, -1, 5, 6, 7, 8, 9, 13, -1, -1, -1, 14, -1, 16, -1, 18, 19, 20, 21, -1, 45, -1, -1, 48, 49, 50, 51, 52, -1, -1, -1, 34, -1, 36, 59, 137, -1, 40, 41, -1, -1, -1, 48, 49, 50, 51, 52, 149, 51, -1, -1, -1, 55, 59, -1, 58, 5, 6, 7, 8, 9, -1, -1, -1, -1, 14, -1, 16, -1, 18, 19, 20, 21, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 34, -1, 36, -1, -1, -1, 40, 41, -1, -1, -1, -1, -1, 10, 11, 12, 13, 51, -1, -1, -1, 55, -1, -1, 58, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, -1, -1, 34, -1, 36, -1, -1, -1, 40, 41, 42, 43, 44, 45, -1, -1, 48, 49, 50, 51, 52, 10, -1, 12, 13, -1, -1, 59, -1, -1, -1, -1, -1, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, -1, -1, 34, -1, 36, -1, -1, -1, 40, 41, 42, 43, 44, 45, -1, -1, 48, 49, 50, 51, 52, 10, -1, 12, 13, 57, -1, 59, -1, -1, -1, -1, -1, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, -1, -1, 34, -1, 36, -1, -1, -1, 40, 41, 42, 43, 44, 45, -1, -1, 48, 49, 50, 51, 52, 10, -1, 12, 13, 57, -1, 59, -1, -1, -1, -1, -1, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, -1, -1, 34, -1, 36, -1, -1, -1, 40, 41, 42, 43, 44, 45, -1, -1, 48, 49, 50, 51, 52, 10, -1, 12, 13, 57, -1, 59, -1, -1, -1, -1, -1, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, -1, -1, 34, -1, 36, -1, -1, -1, 40, 41, 42, 43, 44, 45, -1, -1, 48, 49, 50, 51, 52, 10, -1, 12, 13, -1, -1, 59, -1, -1, -1, -1, -1, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, -1, -1, -1, -1, 36, -1, -1, -1, 40, 41, 42, 43, 44, 45, -1, -1, 48, 49, 50, 51, 52, 13, -1, -1, -1, -1, -1, 59, -1, -1, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, -1, -1, -1, -1, 36, -1, -1, -1, 40, 41, 42, 43, 44, 45, -1, -1, 48, 49, 50, 51, 52, 13, -1, -1, -1, -1, -1, 59, -1, -1, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, -1, -1, -1, -1, -1, -1, -1, -1, 40, 41, 42, 43, 44, 45, -1, -1, 48, 49, 50, 51, 52, 13, -1, -1, -1, -1, -1, 59, -1, -1, 22, 23, 24, 25, 26, 27, 28, -1, 30, -1, -1, -1, -1, -1, -1, -1, -1, -1, 40, 41, 42, 43, 44, 45, -1, -1, 48, 49, 50, 51, 52, 13, -1, -1, -1, -1, -1, 59, -1, -1, 22, 23, 24, 25, 26, 27, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 40, 41, 42, 43, 44, 45, -1, -1, 48, 49, 50, 51, 52, 13, -1, -1, -1, -1, -1, 59, -1, -1, 22, 23, 24, 25, 26, 27, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 40, 41, 42, 43, 44, 45, -1, -1, 48, 49, 50, 51, 52, -1, -1, -1, -1, -1, -1, 59 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2277 */   private static final byte[] yystos_ = new byte[] { 0, 1, 3, 5, 6, 7, 8, 9, 14, 16, 18, 19, 20, 21, 34, 36, 40, 41, 51, 53, 55, 58, 63, 64, 65, 66, 32, 33, 32, 33, 51, 51, 69, 51, 68, 51, 67, 64, 66, 66, 66, 66, 64, 64, 70, 66, 0, 53, 54, 10, 11, 12, 13, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 34, 36, 40, 41, 42, 43, 44, 45, 48, 49, 50, 51, 52, 59, 5, 8, 5, 8, 5, 8, 5, 8, 8, 73, 8, 64, 66, 64, 66, 64, 57, 53, 54, 56, 66, 64, 66, 5, 7, 8, 66, 71, 72, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 5, 8, 5, 8, 71, 71, 66, 11, 57, 61, 15, 57, 17, 57, 64, 64, 11, 11, 11, 60, 74, 57, 60, 66, 74, 8, 66, 64, 66, 66, 66, 60, 61, 64, 11, 57, 72, 66 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2301 */   private static final short[] yytoken_number_ = new short[] { 0, 256, 257, 258, 259, 260, 261, 262, 263, 264, 265, 266, 267, 268, 269, 270, 271, 272, 273, 274, 275, 276, 277, 278, 279, 280, 281, 282, 283, 284, 285, 286, 287, 288, 63, 289, 126, 290, 291, 292, 43, 45, 42, 47, 293, 58, 294, 295, 94, 36, 64, 40, 91, 10, 59, 123, 125, 41, 33, 37, 93, 44 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2314 */   private static final byte[] yyr1_ = new byte[] { 0, 62, 63, 63, 63, 63, 63, 64, 64, 65, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 67, 68, 69, 70, 70, 70, 70, 70, 70, 71, 71, 72, 72, 72, 72, 72, 72, 72, 72, 73, 73, 73, 73, 73, 74 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2330 */   private static final byte[] yyr2_ = new byte[] { 0, 2, 1, 1, 2, 2, 1, 1, 1, 3, 1, 1, 1, 1, 3, 3, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 6, 4, 3, 5, 3, 3, 2, 5, 4, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 1, 1, 3, 3, 5, 0, 1, 3, 2, 3, 2, 1, 4, 0, 1, 2, 3, 2, 3, 2, 3, 0, 1, 3, 3, 5, 0 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2346 */   private static final String[] yytname_ = new String[] { "$end", "error", "$undefined", "END_OF_INPUT", "ERROR", "STR_CONST", "NUM_CONST", "NULL_CONST", "SYMBOL", "FUNCTION", "LEFT_ASSIGN", "EQ_ASSIGN", "RIGHT_ASSIGN", "LBB", "FOR", "IN", "IF", "ELSE", "WHILE", "NEXT", "BREAK", "REPEAT", "GT", "GE", "LT", "LE", "EQ", "NE", "AND", "OR", "AND2", "OR2", "NS_GET", "NS_GET_INT", "'?'", "LOW", "'~'", "TILDE", "NOT", "UNOT", "'+'", "'-'", "'*'", "'/'", "SPECIAL", "':'", "UPLUS", "UMINUS", "'^'", "'$'", "'@'", "'('", "'['", "'\\n'", "';'", "'{'", "'}'", "')'", "'!'", "'%'", "']'", "','", "$accept", "prog", "expr_or_assign", "equal_assign", "expr", "cond", "ifcond", "forcond", "exprlist", "sublist", "sub", "formlist", "cr", null };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2361 */   private static final byte[] yyrhs_ = new byte[] { 63, 0, -1, 3, -1, 53, -1, 64, 53, -1, 64, 54, -1, 1, -1, 66, -1, 65, -1, 66, 11, 64, -1, 6, -1, 5, -1, 7, -1, 8, -1, 55, 70, 56, -1, 51, 64, 57, -1, 41, 66, -1, 40, 66, -1, 58, 66, -1, 36, 66, -1, 34, 66, -1, 66, 45, 66, -1, 66, 40, 66, -1, 66, 41, 66, -1, 66, 42, 66, -1, 66, 43, 66, -1, 66, 48, 66, -1, 66, 44, 66, -1, 66, 59, 66, -1, 66, 36, 66, -1, 66, 34, 66, -1, 66, 24, 66, -1, 66, 25, 66, -1, 66, 26, 66, -1, 66, 27, 66, -1, 66, 23, 66, -1, 66, 22, 66, -1, 66, 28, 66, -1, 66, 29, 66, -1, 66, 30, 66, -1, 66, 31, 66, -1, 66, 10, 66, -1, 66, 12, 66, -1, 9, 51, 73, 57, 74, 64, -1, 66, 51, 71, 57, -1, 16, 68, 64, -1, 16, 68, 64, 17, 64, -1, 14, 69, 64, -1, 18, 67, 64, -1, 21, 64, -1, 66, 13, 71, 60, 60, -1, 66, 52, 71, 60, -1, 8, 32, 8, -1, 8, 32, 5, -1, 5, 32, 8, -1, 5, 32, 5, -1, 8, 33, 8, -1, 8, 33, 5, -1, 5, 33, 8, -1, 5, 33, 5, -1, 66, 49, 8, -1, 66, 49, 5, -1, 66, 50, 8, -1, 66, 50, 5, -1, 19, -1, 20, -1, 51, 66, 57, -1, 51, 66, 57, -1, 51, 8, 15, 66, 57, -1, -1, 64, -1, 70, 54, 64, -1, 70, 54, -1, 70, 53, 64, -1, 70, 53, -1, 72, -1, 71, 74, 61, 72, -1, -1, 66, -1, 8, 11, -1, 8, 11, 66, -1, 5, 11, -1, 5, 11, 66, -1, 7, 11, -1, 7, 11, 66, -1, -1, 8, -1, 8, 11, 66, -1, 73, 61, 8, -1, 73, 61, 8, 11, 66, -1, -1 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2399 */   private static final short[] yyprhs_ = new short[] { 0, 0, 3, 5, 7, 10, 13, 15, 17, 19, 23, 25, 27, 29, 31, 35, 39, 42, 45, 48, 51, 54, 58, 62, 66, 70, 74, 78, 82, 86, 90, 94, 98, 102, 106, 110, 114, 118, 122, 126, 130, 134, 138, 142, 149, 154, 158, 164, 168, 172, 175, 181, 186, 190, 194, 198, 202, 206, 210, 214, 218, 222, 226, 230, 234, 236, 238, 242, 246, 252, 253, 255, 259, 262, 266, 269, 271, 276, 277, 279, 282, 286, 289, 293, 296, 300, 301, 303, 307, 311, 317 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2414 */   private static final short[] yyrline_ = new short[] { 0, 248, 248, 249, 250, 251, 252, 255, 256, 259, 262, 263, 264, 265, 267, 268, 270, 271, 272, 273, 274, 276, 277, 278, 279, 280, 281, 282, 283, 284, 285, 286, 287, 288, 289, 290, 291, 292, 293, 294, 295, 297, 298, 299, 301, 302, 303, 304, 305, 306, 307, 308, 309, 310, 311, 312, 313, 314, 315, 316, 317, 318, 319, 320, 321, 322, 326, 329, 332, 336, 337, 338, 339, 340, 341, 344, 345, 348, 349, 350, 351, 352, 353, 354, 355, 358, 359, 360, 361, 362, 365 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void yy_reduce_print(int yyrule, YYStack yystack) {
/* 2431 */     if (this.yydebug == 0) {
/*      */       return;
/*      */     }
/*      */     
/* 2435 */     int yylno = yyrline_[yyrule];
/* 2436 */     int yynrhs = yyr2_[yyrule];
/*      */     
/* 2438 */     yycdebug("Reducing stack by rule " + (yyrule - 1) + " (line " + yylno + "), ");
/*      */ 
/*      */ 
/*      */     
/* 2442 */     for (int yyi = 0; yyi < yynrhs; yyi++) {
/* 2443 */       yy_symbol_print("   $" + (yyi + 1) + " =", yyrhs_[yyprhs_[yyrule] + yyi], yystack
/*      */           
/* 2445 */           .valueAt(yynrhs - yyi + 1), yystack
/* 2446 */           .locationAt(yynrhs - yyi + 1));
/*      */     }
/*      */   }
/*      */ 
/*      */   
/* 2451 */   private static final byte[] yytranslate_table_ = new byte[] { 0, 2, 2, 2, 2, 2, 2, 2, 2, 2, 53, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 58, 2, 2, 49, 59, 2, 2, 51, 57, 42, 40, 61, 41, 2, 43, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 45, 54, 2, 2, 2, 34, 50, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 52, 2, 60, 48, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 55, 2, 56, 36, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 35, 37, 38, 39, 44, 46, 47 };
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int yylast_ = 709;
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int yynnts_ = 13;
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int yyempty_ = -2;
/*      */ 
/*      */   
/*      */   private static final int yyfinal_ = 46;
/*      */ 
/*      */   
/*      */   private static final int yyterror_ = 1;
/*      */ 
/*      */   
/*      */   private static final int yyerrcode_ = 256;
/*      */ 
/*      */   
/*      */   private static final int yyntokens_ = 62;
/*      */ 
/*      */   
/*      */   private static final int yyuser_token_number_max_ = 295;
/*      */ 
/*      */   
/*      */   private static final int yyundef_token_ = 2;
/*      */ 
/*      */ 
/*      */   
/*      */   private static final byte yytranslate_(int t) {
/* 2486 */     if (t >= 0 && t <= 295) {
/* 2487 */       return yytranslate_table_[t];
/*      */     }
/* 2489 */     return 2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SEXP getResult() {
/* 2517 */     return this.result;
/*      */   }
/*      */   
/*      */   public StatusResult getResultStatus() {
/* 2521 */     return this.extendedParseResult;
/*      */   }
/*      */   
/*      */   static SEXP makeSrcref(Location lloc, SEXP srcfile) {
/*      */     Null null;
/* 2526 */     int[] values = new int[6];
/* 2527 */     values[0] = lloc.getBegin().getLine() + 1;
/* 2528 */     values[1] = lloc.getBegin().getCharIndex() + 1;
/* 2529 */     values[2] = lloc.getEnd().getLine() + 1;
/* 2530 */     values[3] = lloc.getEnd().getCharIndex() + 1;
/* 2531 */     values[4] = lloc.getBegin().getColumn() + 1;
/* 2532 */     values[5] = lloc.getEnd().getColumn() + 1;
/*      */     
/* 2534 */     if (srcfile == null) {
/* 2535 */       null = Null.INSTANCE;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2541 */     PairList attributes = PairList.Node.newBuilder().add(Symbols.SRC_FILE, (SEXP)null).add(Symbols.CLASS, (SEXP)new StringArrayVector(new String[] { "srcref" })).build();
/*      */     
/* 2543 */     return (SEXP)new IntArrayVector(values, AttributeMap.fromPairList(attributes));
/*      */   }
/*      */   
/*      */   <T extends AbstractSEXP> T attachSrcrefs(T val, SEXP srcfile) {
/* 2547 */     if (this.state.keepSrcRefs) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2552 */       SEXP t = CDefines.CDR(this.srcRefs);
/* 2553 */       int tlen = CDefines.length(t);
/* 2554 */       Vector.Builder srval = CDefines.allocVector(CDefines.VECSXP, tlen);
/* 2555 */       for (int n = 0; n < tlen; n++, t = CDefines.CDR(t)) {
/* 2556 */         srval.set(n, CDefines.CAR(t));
/*      */       }
/*      */       
/* 2559 */       val.unsafeSetAttributes(
/* 2560 */           AttributeMap.newBuilder()
/* 2561 */           .set(CDefines.R_SrcrefSymbol, (SEXP)srval.build())
/* 2562 */           .set(CDefines.R_SrcfileSymbol, srcfile)
/* 2563 */           .build());
/*      */       
/* 2565 */       this.srcRefs = NewList();
/*      */     } 
/* 2567 */     return val;
/*      */   }
/*      */   private int xxvalue(SEXP v, StatusResult result, Location lloc) {
/*      */     StringArrayVector stringArrayVector;
/* 2571 */     if (result != StatusResult.EMPTY && result != StatusResult.OK && 
/* 2572 */       this.state.keepSrcRefs) {
/* 2573 */       if (v == Null.INSTANCE) {
/* 2574 */         StringVector.Builder sexp = new StringVector.Builder();
/* 2575 */         stringArrayVector = sexp.build();
/*      */       } 
/* 2577 */       if (lloc == null) {
/* 2578 */         lloc = new Location(this.yylexer.getStartPos(), this.yylexer.getEndPos());
/*      */       }
/* 2580 */       SEXP srcRef = makeSrcref(lloc, this.state.srcFile);
/* 2581 */       CDefines.REPROTECT(this.srcRefs = GrowList(this.srcRefs, srcRef), this.srindex);
/*      */     } 
/*      */     
/* 2584 */     this.result = (SEXP)stringArrayVector;
/* 2585 */     this.extendedParseResult = result;
/* 2586 */     return 0;
/*      */   }
/*      */   
/*      */   private SEXP xxnullformal() {
/*      */     Null null;
/* 2591 */     CDefines.PROTECT(null = CDefines.R_NilValue);
/* 2592 */     return (SEXP)null;
/*      */   }
/*      */   
/*      */   private SEXP xxfirstformal0(SEXP sym) {
/*      */     Null null;
/* 2597 */     CDefines.UNPROTECT_PTR(sym);
/* 2598 */     if (this.options.isGenerateCode()) {
/* 2599 */       SEXP ans; CDefines.PROTECT(ans = FirstArg((SEXP)CDefines.R_MissingArg, sym));
/*      */     } else {
/* 2601 */       CDefines.PROTECT(null = CDefines.R_NilValue);
/*      */     } 
/* 2603 */     return (SEXP)null;
/*      */   }
/*      */   
/*      */   private SEXP xxfirstformal1(SEXP sym, SEXP expr) {
/*      */     Null null;
/* 2608 */     if (this.options.isGenerateCode()) {
/* 2609 */       SEXP ans; CDefines.PROTECT(ans = FirstArg(expr, sym));
/*      */     } else {
/* 2611 */       CDefines.PROTECT(null = CDefines.R_NilValue);
/*      */     } 
/* 2613 */     CDefines.UNPROTECT_PTR(expr);
/* 2614 */     CDefines.UNPROTECT_PTR(sym);
/* 2615 */     return (SEXP)null;
/*      */   }
/*      */   
/*      */   private SEXP xxaddformal0(SEXP formlist, SEXP sym, Location lloc) {
/*      */     Null null;
/* 2620 */     if (this.options.isGenerateCode()) {
/* 2621 */       CheckFormalArgs(formlist, sym, lloc); SEXP ans;
/* 2622 */       CDefines.PROTECT(ans = NextArg(formlist, (SEXP)CDefines.R_MissingArg, sym));
/*      */     } else {
/* 2624 */       CDefines.PROTECT(null = CDefines.R_NilValue);
/*      */     } 
/* 2626 */     CDefines.UNPROTECT_PTR(sym);
/* 2627 */     CDefines.UNPROTECT_PTR(formlist);
/* 2628 */     return (SEXP)null;
/*      */   }
/*      */   
/*      */   private SEXP xxaddformal1(SEXP formlist, SEXP sym, SEXP expr, Location lloc) {
/*      */     Null null;
/* 2633 */     if (this.options.isGenerateCode()) {
/* 2634 */       CheckFormalArgs(formlist, sym, lloc); SEXP ans;
/* 2635 */       CDefines.PROTECT(ans = NextArg(formlist, expr, sym));
/*      */     } else {
/* 2637 */       CDefines.PROTECT(null = CDefines.R_NilValue);
/*      */     } 
/* 2639 */     CDefines.UNPROTECT_PTR(expr);
/* 2640 */     CDefines.UNPROTECT_PTR(sym);
/* 2641 */     CDefines.UNPROTECT_PTR(formlist);
/* 2642 */     return (SEXP)null;
/*      */   }
/*      */   
/*      */   private SEXP xxexprlist0() {
/*      */     Null null;
/* 2647 */     if (this.options.isGenerateCode()) {
/* 2648 */       if (this.state.keepSrcRefs) {
/*      */         SEXP ans;
/* 2650 */         CDefines.PROTECT(ans = NewList(
/* 2651 */               AttributeMap.newBuilder().set(CDefines.R_SrcrefSymbol, this.srcRefs).build()));
/*      */         
/* 2653 */         CDefines.REPROTECT(this.srcRefs = NewList(), this.srindex);
/*      */       } else {
/* 2655 */         SEXP ans; CDefines.PROTECT(ans = NewList());
/*      */       } 
/*      */     } else {
/* 2658 */       CDefines.PROTECT(null = CDefines.R_NilValue);
/*      */     } 
/* 2660 */     return (SEXP)null;
/*      */   }
/*      */   
/*      */   private SEXP xxexprlist1(SEXP expr, Location lloc) {
/*      */     Null null;
/* 2665 */     if (this.options.isGenerateCode()) {
/* 2666 */       AttributeMap attrs = AttributeMap.EMPTY;
/* 2667 */       if (this.state.keepSrcRefs) {
/* 2668 */         attrs = AttributeMap.newBuilder().set(CDefines.R_SrcrefSymbol, this.srcRefs).build();
/* 2669 */         CDefines.REPROTECT(this.srcRefs = NewList(), this.srindex);
/* 2670 */         CDefines.REPROTECT(this.srcRefs = GrowList(this.srcRefs, makeSrcref(lloc, this.state.srcFile)), this.srindex);
/*      */       }  SEXP tmp;
/* 2672 */       CDefines.PROTECT(tmp = NewList(attrs)); SEXP ans;
/* 2673 */       CDefines.PROTECT(ans = GrowList(tmp, expr));
/* 2674 */       CDefines.UNPROTECT_PTR(tmp);
/*      */     } else {
/* 2676 */       CDefines.PROTECT(null = CDefines.R_NilValue);
/*      */     } 
/* 2678 */     CDefines.UNPROTECT_PTR(expr);
/* 2679 */     return (SEXP)null;
/*      */   }
/*      */   
/*      */   private SEXP xxexprlist2(SEXP exprlist, SEXP expr, Location lloc) {
/*      */     Null null;
/* 2684 */     if (this.options.isGenerateCode()) {
/* 2685 */       if (this.state.keepSrcRefs)
/* 2686 */         CDefines.REPROTECT(this.srcRefs = GrowList(this.srcRefs, makeSrcref(lloc, this.state.srcFile)), this.srindex); 
/*      */       SEXP ans;
/* 2688 */       CDefines.PROTECT(ans = GrowList(exprlist, expr));
/*      */     } else {
/* 2690 */       CDefines.PROTECT(null = CDefines.R_NilValue);
/*      */     } 
/* 2692 */     CDefines.UNPROTECT_PTR(expr);
/* 2693 */     CDefines.UNPROTECT_PTR(exprlist);
/* 2694 */     return (SEXP)null;
/*      */   }
/*      */   
/*      */   private SEXP xxsub0() {
/*      */     Null null;
/* 2699 */     if (this.options.isGenerateCode()) {
/* 2700 */       FunctionCall functionCall; CDefines.PROTECT(functionCall = CDefines.lang2((SEXP)CDefines.R_MissingArg, (SEXP)CDefines.R_NilValue));
/*      */     } else {
/* 2702 */       CDefines.PROTECT(null = CDefines.R_NilValue);
/*      */     } 
/* 2704 */     return (SEXP)null;
/*      */   }
/*      */   
/*      */   private SEXP xxsub1(SEXP expr, Location lloc) {
/*      */     Null null;
/* 2709 */     if (this.options.isGenerateCode()) {
/* 2710 */       SEXP ans; CDefines.PROTECT(ans = TagArg(expr, (SEXP)CDefines.R_NilValue, lloc));
/*      */     } else {
/* 2712 */       CDefines.PROTECT(null = CDefines.R_NilValue);
/*      */     } 
/* 2714 */     CDefines.UNPROTECT_PTR(expr);
/* 2715 */     return (SEXP)null;
/*      */   }
/*      */   
/*      */   private SEXP xxsymsub0(SEXP sym, Location lloc) {
/*      */     Null null;
/* 2720 */     if (this.options.isGenerateCode()) {
/* 2721 */       SEXP ans; CDefines.PROTECT(ans = TagArg((SEXP)CDefines.R_MissingArg, sym, lloc));
/*      */     } else {
/* 2723 */       CDefines.PROTECT(null = CDefines.R_NilValue);
/*      */     } 
/* 2725 */     CDefines.UNPROTECT_PTR(sym);
/* 2726 */     return (SEXP)null;
/*      */   }
/*      */   
/*      */   private SEXP xxsymsub1(SEXP sym, SEXP expr, Location lloc) {
/*      */     Null null;
/* 2731 */     if (this.options.isGenerateCode()) {
/* 2732 */       SEXP ans; CDefines.PROTECT(ans = TagArg(expr, sym, lloc));
/*      */     } else {
/* 2734 */       CDefines.PROTECT(null = CDefines.R_NilValue);
/*      */     } 
/* 2736 */     CDefines.UNPROTECT_PTR(expr);
/* 2737 */     CDefines.UNPROTECT_PTR(sym);
/* 2738 */     return (SEXP)null;
/*      */   }
/*      */   
/*      */   private SEXP xxnullsub0(Location lloc) {
/*      */     Null null;
/* 2743 */     CDefines.UNPROTECT_PTR((SEXP)CDefines.R_NilValue);
/* 2744 */     if (this.options.isGenerateCode()) {
/* 2745 */       SEXP ans; CDefines.PROTECT(ans = TagArg((SEXP)CDefines.R_MissingArg, (SEXP)Symbol.get("NULL"), lloc));
/*      */     } else {
/* 2747 */       CDefines.PROTECT(null = CDefines.R_NilValue);
/*      */     } 
/* 2749 */     return (SEXP)null;
/*      */   }
/*      */   private SEXP xxnullsub1(SEXP expr, Location lloc) {
/*      */     Null null;
/* 2753 */     Symbol symbol = Symbol.get("NULL");
/* 2754 */     CDefines.UNPROTECT_PTR((SEXP)CDefines.R_NilValue);
/* 2755 */     if (this.options.isGenerateCode()) {
/* 2756 */       SEXP sEXP; CDefines.PROTECT(sEXP = TagArg(expr, (SEXP)symbol, lloc));
/*      */     } else {
/* 2758 */       CDefines.PROTECT(null = CDefines.R_NilValue);
/*      */     } 
/* 2760 */     CDefines.UNPROTECT_PTR(expr);
/* 2761 */     return (SEXP)null;
/*      */   }
/*      */ 
/*      */   
/*      */   private SEXP xxsublist1(SEXP sub) {
/*      */     Null null;
/* 2767 */     if (this.options.isGenerateCode()) {
/* 2768 */       SEXP ans; CDefines.PROTECT(ans = FirstArg(CDefines.CAR(sub), CDefines.CADR(sub)));
/*      */     } else {
/* 2770 */       CDefines.PROTECT(null = CDefines.R_NilValue);
/*      */     } 
/* 2772 */     CDefines.UNPROTECT_PTR(sub);
/* 2773 */     return (SEXP)null;
/*      */   }
/*      */   
/*      */   private SEXP xxsublist2(SEXP sublist, SEXP sub) {
/*      */     Null null;
/* 2778 */     if (this.options.isGenerateCode()) {
/* 2779 */       SEXP ans; CDefines.PROTECT(ans = NextArg(sublist, CDefines.CAR(sub), CDefines.CADR(sub)));
/*      */     } else {
/* 2781 */       CDefines.PROTECT(null = CDefines.R_NilValue);
/*      */     } 
/* 2783 */     CDefines.UNPROTECT_PTR(sub);
/* 2784 */     CDefines.UNPROTECT_PTR(sublist);
/* 2785 */     return (SEXP)null;
/*      */   }
/*      */   
/*      */   private SEXP xxcond(SEXP expr) {
/* 2789 */     this.state.setEatLines(true);
/* 2790 */     return expr;
/*      */   }
/*      */   
/*      */   private SEXP xxifcond(SEXP expr) {
/* 2794 */     this.state.setEatLines(true);
/* 2795 */     return expr;
/*      */   }
/*      */   
/*      */   private SEXP xxif(SEXP ifsym, SEXP cond, SEXP expr) {
/*      */     Null null;
/* 2800 */     if (this.options.isGenerateCode()) {
/* 2801 */       FunctionCall functionCall; CDefines.PROTECT(functionCall = CDefines.lang3(ifsym, cond, expr));
/*      */     } else {
/* 2803 */       CDefines.PROTECT(null = CDefines.R_NilValue);
/*      */     } 
/* 2805 */     CDefines.UNPROTECT_PTR(expr);
/* 2806 */     CDefines.UNPROTECT_PTR(cond);
/* 2807 */     return (SEXP)null;
/*      */   }
/*      */   
/*      */   private SEXP xxifelse(SEXP ifsym, SEXP cond, SEXP ifexpr, SEXP elseexpr) {
/*      */     Null null;
/* 2812 */     if (this.options.isGenerateCode()) {
/* 2813 */       FunctionCall functionCall; CDefines.PROTECT(functionCall = CDefines.lang4(ifsym, cond, ifexpr, elseexpr));
/*      */     } else {
/* 2815 */       CDefines.PROTECT(null = CDefines.R_NilValue);
/*      */     } 
/* 2817 */     CDefines.UNPROTECT_PTR(elseexpr);
/* 2818 */     CDefines.UNPROTECT_PTR(ifexpr);
/* 2819 */     CDefines.UNPROTECT_PTR(cond);
/* 2820 */     return (SEXP)null;
/*      */   }
/*      */   
/*      */   private SEXP xxforcond(SEXP sym, SEXP expr) {
/*      */     Null null;
/* 2825 */     this.state.setEatLines(true);
/* 2826 */     if (this.options.isGenerateCode()) {
/* 2827 */       FunctionCall functionCall; CDefines.PROTECT(functionCall = CDefines.lang2(sym, expr));
/*      */     } else {
/* 2829 */       CDefines.PROTECT(null = CDefines.R_NilValue);
/*      */     } 
/* 2831 */     CDefines.UNPROTECT_PTR(expr);
/* 2832 */     CDefines.UNPROTECT_PTR(sym);
/* 2833 */     return (SEXP)null;
/*      */   }
/*      */   
/*      */   private SEXP xxfor(SEXP forsym, SEXP forcond, SEXP body) {
/*      */     Null null;
/* 2838 */     if (this.options.isGenerateCode()) {
/* 2839 */       FunctionCall functionCall; CDefines.PROTECT(functionCall = CDefines.lang4(forsym, CDefines.CAR(forcond), CDefines.CAR(CDefines.CDR(forcond)), body));
/*      */     } else {
/* 2841 */       CDefines.PROTECT(null = CDefines.R_NilValue);
/*      */     } 
/* 2843 */     CDefines.UNPROTECT_PTR(body);
/* 2844 */     CDefines.UNPROTECT_PTR(forcond);
/* 2845 */     return (SEXP)null;
/*      */   }
/*      */   
/*      */   private SEXP xxwhile(SEXP whilesym, SEXP cond, SEXP body) {
/*      */     Null null;
/* 2850 */     if (this.options.isGenerateCode()) {
/* 2851 */       FunctionCall functionCall; CDefines.PROTECT(functionCall = CDefines.lang3(whilesym, cond, body));
/*      */     } else {
/* 2853 */       CDefines.PROTECT(null = CDefines.R_NilValue);
/*      */     } 
/* 2855 */     CDefines.UNPROTECT_PTR(body);
/* 2856 */     CDefines.UNPROTECT_PTR(cond);
/* 2857 */     return (SEXP)null;
/*      */   }
/*      */   
/*      */   private SEXP xxrepeat(SEXP repeatsym, SEXP body) {
/*      */     Null null;
/* 2862 */     if (this.options.isGenerateCode()) {
/* 2863 */       FunctionCall functionCall; CDefines.PROTECT(functionCall = CDefines.lang2(repeatsym, body));
/*      */     } else {
/* 2865 */       CDefines.PROTECT(null = CDefines.R_NilValue);
/*      */     } 
/* 2867 */     CDefines.UNPROTECT_PTR(body);
/* 2868 */     return (SEXP)null;
/*      */   }
/*      */   private SEXP xxnxtbrk(SEXP keyword) {
/*      */     Null null;
/* 2872 */     if (this.options.isGenerateCode()) {
/* 2873 */       PairList.Node node; CDefines.PROTECT(node = CDefines.lang1(keyword));
/*      */     } else {
/* 2875 */       CDefines.PROTECT(null = CDefines.R_NilValue);
/*      */     } 
/* 2877 */     return (SEXP)null;
/*      */   }
/*      */   private SEXP xxfuncall(SEXP expr, SEXP args) {
/*      */     Null null;
/* 2881 */     SEXP sav_expr = expr;
/* 2882 */     if (this.options.isGenerateCode()) {
/* 2883 */       Symbol symbol; FunctionCall functionCall; if (CDefines.isString(expr)) {
/* 2884 */         symbol = Symbol.get(CDefines.CHAR(CDefines.STRING_ELT(expr, 0)));
/*      */       }
/* 2886 */       CDefines.PROTECT(symbol);
/* 2887 */       if (CDefines.length(CDefines.CDR(args)) == 1 && CDefines.CADR(args) == CDefines.R_MissingArg && CDefines.TAG(CDefines.CDR(args)) == CDefines.R_NilValue) {
/* 2888 */         PairList.Node node = CDefines.lang1((SEXP)symbol);
/*      */       } else {
/* 2890 */         functionCall = CDefines.LCONS((SEXP)symbol, CDefines.CDR(args));
/*      */       } 
/* 2892 */       CDefines.UNPROTECT(1);
/* 2893 */       CDefines.PROTECT(functionCall);
/*      */     } else {
/* 2895 */       CDefines.PROTECT(null = CDefines.R_NilValue);
/*      */     } 
/* 2897 */     CDefines.UNPROTECT_PTR(args);
/* 2898 */     CDefines.UNPROTECT_PTR(sav_expr);
/* 2899 */     return (SEXP)null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private SEXP xxdefun(SEXP fname, SEXP formals, SEXP body, Location loc) {
/*      */     Null null;
/* 2908 */     if (this.options.isGenerateCode()) {
/* 2909 */       SEXP source; if (!this.state.keepSrcRefs) {
/* 2910 */         Null null1; CDefines.PROTECT(null1 = CDefines.R_NilValue);
/*      */       } else {
/* 2912 */         source = makeSrcref(loc, this.state.srcFile);
/*      */       } 
/* 2914 */       if (formals == Null.INSTANCE) {
/* 2915 */         FunctionCall functionCall = CDefines.lang4(fname, (SEXP)Null.INSTANCE, body, source);
/*      */       } else {
/* 2917 */         FunctionCall functionCall; CDefines.PROTECT(functionCall = CDefines.lang4(fname, CDefines.CDR(formals), body, source));
/*      */       } 
/* 2919 */       CDefines.UNPROTECT_PTR(source);
/*      */     } else {
/* 2921 */       CDefines.PROTECT(null = CDefines.R_NilValue);
/*      */     } 
/* 2923 */     CDefines.UNPROTECT_PTR(body);
/* 2924 */     CDefines.UNPROTECT_PTR(formals);
/* 2925 */     this.state.getFunctionSource().ascend();
/* 2926 */     return (SEXP)null;
/*      */   }
/*      */   
/*      */   private SEXP xxunary(SEXP op, SEXP arg) {
/*      */     Null null;
/* 2931 */     if (this.options.isGenerateCode()) {
/* 2932 */       FunctionCall functionCall; CDefines.PROTECT(functionCall = CDefines.lang2(op, arg));
/*      */     } else {
/* 2934 */       CDefines.PROTECT(null = CDefines.R_NilValue);
/*      */     } 
/* 2936 */     CDefines.UNPROTECT_PTR(arg);
/* 2937 */     return (SEXP)null;
/*      */   }
/*      */   
/*      */   private SEXP xxbinary(SEXP n1, SEXP n2, SEXP n3) {
/*      */     Null null;
/* 2942 */     if (this.options.isGenerateCode()) {
/* 2943 */       FunctionCall functionCall; CDefines.PROTECT(functionCall = CDefines.lang3(n1, n2, n3));
/*      */     } else {
/* 2945 */       CDefines.PROTECT(null = CDefines.R_NilValue);
/*      */     } 
/* 2947 */     CDefines.UNPROTECT_PTR(n2);
/* 2948 */     CDefines.UNPROTECT_PTR(n3);
/* 2949 */     return (SEXP)null;
/*      */   }
/*      */   
/*      */   private SEXP xxparen(SEXP n1, SEXP n2) {
/*      */     Null null;
/* 2954 */     if (this.options.isGenerateCode()) {
/* 2955 */       FunctionCall functionCall; CDefines.PROTECT(functionCall = CDefines.lang2(n1, n2));
/*      */     } else {
/* 2957 */       CDefines.PROTECT(null = CDefines.R_NilValue);
/*      */     } 
/* 2959 */     CDefines.UNPROTECT_PTR(n2);
/* 2960 */     return (SEXP)null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private SEXP xxsubscript(SEXP a1, SEXP a2, SEXP a3) {
/*      */     Null null;
/* 2970 */     if (this.options.isGenerateCode()) {
/* 2971 */       FunctionCall functionCall; CDefines.PROTECT(functionCall = CDefines.LCONS(a2, (SEXP)CDefines.CONS(a1, CDefines.CDR(a3))));
/*      */     } else {
/* 2973 */       CDefines.PROTECT(null = CDefines.R_NilValue);
/*      */     } 
/* 2975 */     CDefines.UNPROTECT_PTR(a3);
/* 2976 */     CDefines.UNPROTECT_PTR(a1);
/* 2977 */     return (SEXP)null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private SEXP xxexprlist(SEXP a1, Location lloc, SEXP a2) {
/*      */     Null null;
/* 2984 */     this.state.setEatLines(false);
/* 2985 */     if (this.options.isGenerateCode()) {
/* 2986 */       SEXP prevA2 = a2;
/* 2987 */       a2 = FunctionCall.fromListExp((PairList.Node)a2);
/* 2988 */       CDefines.SETCAR(a2, a1);
/* 2989 */       if (this.state.keepSrcRefs) {
/* 2990 */         SEXP prevSrcrefs; CDefines.PROTECT(prevSrcrefs = CDefines.getAttrib(prevA2, CDefines.R_SrcrefSymbol));
/* 2991 */         CDefines.REPROTECT(this.srcRefs = Insert(this.srcRefs, makeSrcref(lloc, this.state.srcFile)), this.srindex); SEXP ans;
/* 2992 */         CDefines.PROTECT(ans = attachSrcrefs(a2, this.state.srcFile));
/* 2993 */         if (CDefines.isNull(prevSrcrefs)) {
/* 2994 */           prevSrcrefs = NewList();
/*      */         }
/* 2996 */         CDefines.REPROTECT(this.srcRefs = prevSrcrefs, this.srindex);
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3001 */         CDefines.UNPROTECT_PTR(prevSrcrefs);
/*      */       } else {
/*      */         SEXP ans;
/* 3004 */         CDefines.PROTECT(ans = a2);
/*      */       } 
/*      */     } else {
/* 3007 */       CDefines.PROTECT(null = CDefines.R_NilValue);
/*      */     } 
/* 3009 */     CDefines.UNPROTECT_PTR(a2);
/* 3010 */     return (SEXP)null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private SEXP TagArg(SEXP arg, SEXP tag, Location lloc) {
/*      */     Symbol symbol;
/* 3017 */     if (tag instanceof StringVector) {
/* 3018 */       symbol = Symbol.get(CDefines.translateChar((SEXP)CDefines.STRING_ELT(tag, 0)));
/*      */     }
/*      */     
/* 3021 */     if (symbol instanceof Symbol || symbol instanceof Null) {
/* 3022 */       return (SEXP)CDefines.lang2(arg, (SEXP)symbol);
/*      */     }
/* 3024 */     CDefines.error(CDefines._("incorrect tag type at line %d"), new Object[] { Integer.valueOf(lloc.getBegin().getLine()) });
/* 3025 */     return (SEXP)CDefines.R_NilValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static SEXP NewList() {
/* 3040 */     return NewList(AttributeMap.EMPTY);
/*      */   }
/*      */   
/*      */   static SEXP NewList(AttributeMap attributes) {
/* 3044 */     PairList.Node node = CDefines.CONS((SEXP)CDefines.R_NilValue, (SEXP)CDefines.R_NilValue, attributes);
/* 3045 */     CDefines.SETCAR((SEXP)node, (SEXP)node);
/* 3046 */     return (SEXP)node;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static SEXP GrowList(SEXP l, SEXP s) {
/* 3053 */     CDefines.PROTECT(s);
/* 3054 */     PairList.Node node = CDefines.CONS(s, (SEXP)CDefines.R_NilValue);
/* 3055 */     CDefines.UNPROTECT(1);
/* 3056 */     CDefines.SETCDR(CDefines.CAR(l), (SEXP)node);
/* 3057 */     CDefines.SETCAR(l, (SEXP)node);
/* 3058 */     return l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static SEXP Insert(SEXP l, SEXP s) {
/* 3065 */     CDefines.PROTECT(s);
/* 3066 */     PairList.Node node = CDefines.CONS(s, CDefines.CDR(l));
/* 3067 */     CDefines.UNPROTECT(1);
/* 3068 */     CDefines.SETCDR(l, (SEXP)node);
/* 3069 */     return l;
/*      */   }
/*      */ 
/*      */   
/*      */   static SEXP FirstArg(SEXP s, SEXP tag) {
/* 3074 */     CDefines.PROTECT(s);
/* 3075 */     CDefines.PROTECT(tag); SEXP tmp;
/* 3076 */     CDefines.PROTECT(tmp = NewList());
/* 3077 */     tmp = GrowList(tmp, s);
/* 3078 */     CDefines.SET_TAG(CDefines.CAR(tmp), tag);
/* 3079 */     CDefines.UNPROTECT(3);
/* 3080 */     return tmp;
/*      */   }
/*      */   
/*      */   static SEXP NextArg(SEXP l, SEXP s, SEXP tag) {
/* 3084 */     CDefines.PROTECT(tag);
/* 3085 */     CDefines.PROTECT(l);
/* 3086 */     l = GrowList(l, s);
/* 3087 */     CDefines.SET_TAG(CDefines.CAR(l), tag);
/* 3088 */     CDefines.UNPROTECT(2);
/* 3089 */     return l;
/*      */   }
/*      */   
/*      */   private void CheckFormalArgs(SEXP formlist, SEXP _new, Location lloc) {
/* 3093 */     while (formlist != CDefines.R_NilValue) {
/* 3094 */       if (CDefines.TAG(formlist) == _new) {
/* 3095 */         CDefines.error(CDefines._("Repeated formal argument '%s' on line %d"), new Object[] { CDefines.CHAR(CDefines.PRINTNAME(_new)), 
/* 3096 */               Integer.valueOf(lloc.getBegin().getLine()) });
/*      */       }
/* 3098 */       formlist = CDefines.CDR(formlist);
/*      */     } 
/*      */   }
/*      */   
/*      */   public static interface Lexer {
/*      */     Position getStartPos();
/*      */     
/*      */     Position getEndPos();
/*      */     
/*      */     Object getLVal();
/*      */     
/*      */     int yylex() throws IOException;
/*      */     
/*      */     void yyerror(RParser.Location param1Location, String param1String);
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/parser/RParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */