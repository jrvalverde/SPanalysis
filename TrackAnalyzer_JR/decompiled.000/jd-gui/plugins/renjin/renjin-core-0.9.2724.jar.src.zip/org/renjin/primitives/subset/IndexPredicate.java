package org.renjin.primitives.subset;

interface IndexPredicate {
  boolean apply(int paramInt);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/subset/IndexPredicate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */