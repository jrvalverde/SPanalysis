/*    */ package org.renjin.primitives.matrix;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import org.renjin.sexp.DoubleArrayVector;
/*    */ import org.renjin.sexp.DoubleVector;
/*    */ import org.renjin.sexp.Vector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DoubleMatrixBuilder
/*    */   extends AbstractMatrixBuilder<DoubleArrayVector.Builder, DoubleVector>
/*    */   implements MatrixBuilder
/*    */ {
/*    */   public DoubleMatrixBuilder(int nrows, int ncols) {
/* 28 */     super((Vector.Type)DoubleVector.VECTOR_TYPE, nrows, ncols);
/*    */   }
/*    */   
/*    */   public void set(int row, int col, double value) {
/* 32 */     this.builder.set(computeIndex(row, col), value);
/*    */   }
/*    */ 
/*    */   
/*    */   public void setValue(int row, int col, double value) {
/* 37 */     this.builder.set(computeIndex(row, col), value);
/*    */   }
/*    */ 
/*    */   
/*    */   public void setValue(int row, int col, int value) {
/* 42 */     this.builder.set(computeIndex(row, col), value);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/matrix/DoubleMatrixBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */