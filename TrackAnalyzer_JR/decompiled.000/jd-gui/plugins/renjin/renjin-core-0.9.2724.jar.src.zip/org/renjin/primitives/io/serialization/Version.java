/*    */ package org.renjin.primitives.io.serialization;
/*    */ 
/*    */ import org.renjin.RVersion;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class Version
/*    */ {
/* 25 */   public static final Version CURRENT = new Version(RVersion.MAJOR, RVersion.MINOR_1, RVersion.MINOR_2);
/*    */   
/*    */   private int v;
/*    */   
/*    */   private int p;
/*    */   private int s;
/*    */   private int packed;
/*    */   
/*    */   Version(int packed) {
/* 34 */     this.packed = packed;
/* 35 */     this.v = this.packed / 65536; packed %= 65536;
/* 36 */     this.p = packed / 256; packed %= 256;
/* 37 */     this.s = packed;
/*    */   }
/*    */   
/*    */   Version(int v, int p, int s) {
/* 41 */     this.v = v;
/* 42 */     this.p = p;
/* 43 */     this.s = s;
/* 44 */     this.packed = s + p * 256 + v * 65536;
/*    */   }
/*    */   
/*    */   public boolean isExperimental() {
/* 48 */     return (this.packed < 0);
/*    */   }
/*    */   
/*    */   public int asPacked() {
/* 52 */     return this.packed;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 57 */     return String.format("%d.%d.%d", new Object[] { Integer.valueOf(this.v), Integer.valueOf(this.p), Integer.valueOf(this.s) });
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/io/serialization/Version.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */