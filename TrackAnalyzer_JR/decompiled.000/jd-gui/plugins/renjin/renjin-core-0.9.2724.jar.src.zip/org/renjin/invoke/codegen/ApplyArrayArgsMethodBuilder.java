/*     */ package org.renjin.invoke.codegen;
/*     */ 
/*     */ import com.sun.codemodel.JAssignmentTarget;
/*     */ import com.sun.codemodel.JBlock;
/*     */ import com.sun.codemodel.JClass;
/*     */ import com.sun.codemodel.JCodeModel;
/*     */ import com.sun.codemodel.JDefinedClass;
/*     */ import com.sun.codemodel.JExpr;
/*     */ import com.sun.codemodel.JExpression;
/*     */ import com.sun.codemodel.JForLoop;
/*     */ import com.sun.codemodel.JInvocation;
/*     */ import com.sun.codemodel.JMethod;
/*     */ import com.sun.codemodel.JVar;
/*     */ import org.renjin.eval.Context;
/*     */ import org.renjin.eval.EvalException;
/*     */ import org.renjin.invoke.codegen.args.ArgConverterStrategies;
/*     */ import org.renjin.invoke.model.JvmMethod;
/*     */ import org.renjin.invoke.model.PrimitiveModel;
/*     */ import org.renjin.sexp.Environment;
/*     */ import org.renjin.sexp.FunctionCall;
/*     */ import org.renjin.sexp.SEXP;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ApplyArrayArgsMethodBuilder
/*     */   implements ApplyMethodContext
/*     */ {
/*     */   private JCodeModel codeModel;
/*     */   private JDefinedClass invoker;
/*     */   private PrimitiveModel primitive;
/*     */   private JMethod method;
/*     */   private JVar context;
/*     */   private JVar environment;
/*     */   private JVar argNames;
/*     */   private JVar args;
/*     */   private JVar call;
/*     */   
/*     */   public ApplyArrayArgsMethodBuilder(JCodeModel codeModel, JDefinedClass invoker, PrimitiveModel primitive) {
/*  47 */     this.codeModel = codeModel;
/*  48 */     this.invoker = invoker;
/*  49 */     this.primitive = primitive;
/*     */   }
/*     */   
/*     */   public void build() {
/*  53 */     declareMethod();
/*     */     
/*  55 */     ExceptionWrapper mainTryBlock = new ExceptionWrapper(this.codeModel, this.method.body(), (JExpression)this.context);
/*  56 */     for (Integer arity : this.primitive.getArity()) {
/*     */ 
/*     */       
/*  59 */       JInvocation invocation = JExpr.invoke("doApply").arg((JExpression)this.context).arg((JExpression)this.environment);
/*     */       
/*  61 */       for (int i = 0; i < arity.intValue(); i++) {
/*  62 */         invocation.arg((JExpression)this.args.component(JExpr.lit(i)));
/*     */       }
/*  64 */       mainTryBlock.body()._if(JExpr.direct("args.length").eq(JExpr.lit(arity.intValue())))
/*  65 */         ._then()._return((JExpression)invocation);
/*     */     } 
/*     */     
/*  68 */     mainTryBlock.catchEvalExceptions();
/*  69 */     mainTryBlock.catchRuntimeExceptions();
/*  70 */     mainTryBlock.catchExceptions();
/*     */ 
/*     */     
/*  73 */     this.method.body()._throw(
/*  74 */         (JExpression)JExpr._new(this.codeModel.ref(EvalException.class))
/*  75 */         .arg(JExpr.lit(this.primitive.getName() + ": max arity is " + this.primitive.getMaxArity())));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void buildVarArgs() {
/*  83 */     declareMethod();
/*     */     
/*  85 */     ExceptionWrapper mainTryBlock = new ExceptionWrapper(this.codeModel, this.method.body(), (JExpression)this.context);
/*     */     
/*  87 */     JvmMethod overload = this.primitive.getOverloads().get(0);
/*  88 */     VarArgParser parser = new VarArgParser(this, mainTryBlock.body(), overload);
/*     */ 
/*     */     
/*  91 */     convertArguments(parser.getArgumentProcessingBlock(), parser);
/*     */ 
/*     */     
/*  94 */     JInvocation invocation = classRef(overload.getDeclaringClass()).staticInvoke(overload.getName());
/*  95 */     for (JExpression argument : parser.getArguments()) {
/*  96 */       invocation.arg(argument);
/*     */     }
/*     */     
/*  99 */     CodeModelUtils.returnSexp(this.context, this.codeModel, mainTryBlock.body(), overload, invocation);
/*     */ 
/*     */     
/* 102 */     mainTryBlock.catchEvalExceptions();
/* 103 */     mainTryBlock.catchRuntimeExceptions();
/* 104 */     mainTryBlock.catchExceptions();
/*     */   }
/*     */   
/*     */   private void declareMethod() {
/* 108 */     this.method = this.invoker.method(17, SEXP.class, "doApply");
/* 109 */     this.context = this.method.param(Context.class, "context");
/* 110 */     this.environment = this.method.param(Environment.class, "environment");
/* 111 */     this.call = this.method.param(FunctionCall.class, "call");
/* 112 */     this.argNames = this.method.param(String[].class, "argNames");
/* 113 */     this.args = this.method.param(SEXP[].class, "args");
/*     */   }
/*     */   
/*     */   private void convertArguments(JBlock parent, VarArgParser parser) {
/* 117 */     int index = 0;
/* 118 */     for (VarArgParser.PositionalArg posArg : parser.getPositionalArguments()) {
/* 119 */       parent.assign((JAssignmentTarget)posArg.getVariable(), 
/* 120 */           convert(posArg.getFormal(), (JExpression)this.args.component(JExpr.lit(index++))));
/*     */     }
/*     */     
/* 123 */     JForLoop forLoop = parent._for();
/* 124 */     JVar loopCounter = forLoop.init(this.codeModel._ref(int.class), "i", JExpr.lit(parser.getPositionalArguments().size()));
/* 125 */     forLoop.test(loopCounter.lt(JExpr.direct("args.length")));
/* 126 */     forLoop.update(loopCounter.incr());
/*     */     
/* 128 */     forLoop.body().invoke((JExpression)parser.getVarArgBuilder(), "add")
/* 129 */       .arg((JExpression)this.argNames.component((JExpression)loopCounter))
/* 130 */       .arg((JExpression)this.args.component((JExpression)loopCounter));
/*     */   }
/*     */   
/*     */   private JExpression convert(JvmMethod.Argument formal, JExpression sexp) {
/* 134 */     return ArgConverterStrategies.findArgConverterStrategy(formal).convertArgument(this, sexp);
/*     */   }
/*     */ 
/*     */   
/*     */   public JExpression getContext() {
/* 139 */     return (JExpression)this.context;
/*     */   }
/*     */ 
/*     */   
/*     */   public JExpression getEnvironment() {
/* 144 */     return (JExpression)this.environment;
/*     */   }
/*     */ 
/*     */   
/*     */   public JClass classRef(Class<?> clazz) {
/* 149 */     return this.codeModel.ref(clazz);
/*     */   }
/*     */ 
/*     */   
/*     */   public JCodeModel getCodeModel() {
/* 154 */     return this.codeModel;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/codegen/ApplyArrayArgsMethodBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */