/*     */ package org.renjin.primitives.files;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FilenameFilter;
/*     */ import java.util.List;
/*     */ import java.util.regex.Pattern;
/*     */ import org.renjin.eval.Context;
/*     */ import org.renjin.repackaged.guava.collect.Lists;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FileScanner
/*     */ {
/*  34 */   private List<String> matches = Lists.newArrayList();
/*     */   private String[] parts;
/*     */   private boolean markDirectories;
/*     */   
/*     */   public static List<String> scan(Context context, String path, boolean markDirectories) {
/*  39 */     FileScanner scanner = new FileScanner(path, markDirectories);
/*  40 */     scanner.matchRoots();
/*  41 */     return scanner.matches;
/*     */   }
/*     */   
/*     */   FileScanner(String path, boolean markDirectories) {
/*  45 */     this.parts = path.split("[\\\\//]");
/*  46 */     this.markDirectories = markDirectories;
/*     */   }
/*     */   
/*     */   private void matchRoots() {
/*  50 */     for (File root : File.listRoots()) {
/*  51 */       String rootName = root.getPath();
/*  52 */       rootName = rootName.substring(0, rootName.length() - 1);
/*     */       
/*  54 */       if (rootName.equalsIgnoreCase(this.parts[0])) {
/*  55 */         match(root, 1);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private void match(File dir, int partIndex) {
/*  61 */     File[] matchingFiles = dir.listFiles(new WildcardFilter(this.parts[partIndex]));
/*  62 */     if (matchingFiles != null) {
/*  63 */       for (File match : matchingFiles) {
/*  64 */         if (partIndex == this.parts.length - 1) {
/*  65 */           if (match.isDirectory() && this.markDirectories) {
/*  66 */             this.matches.add(match.getAbsolutePath() + File.separator);
/*     */           } else {
/*  68 */             this.matches.add(match.getAbsolutePath());
/*     */           } 
/*  70 */         } else if (match.isDirectory()) {
/*  71 */           match(match, partIndex + 1);
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   private static String wildcardPattern(String pattern) {
/*  78 */     StringBuilder sb = new StringBuilder();
/*  79 */     for (int i = 0; i != pattern.length(); i++) {
/*  80 */       switch (pattern.charAt(i)) {
/*     */         case '.':
/*  82 */           sb.append("\\.");
/*     */           break;
/*     */         case '?':
/*  85 */           sb.append(".?");
/*     */           break;
/*     */         case '*':
/*  88 */           sb.append(".*");
/*     */           break;
/*     */         default:
/*  91 */           sb.appendCodePoint(pattern.codePointAt(i)); break;
/*     */       } 
/*     */     } 
/*  94 */     return sb.toString();
/*     */   }
/*     */   
/*     */   private static class WildcardFilter implements FilenameFilter {
/*     */     private final boolean explicitDot;
/*     */     private final Pattern regex;
/*     */     
/*     */     private WildcardFilter(String wildcard) {
/* 102 */       this.regex = Pattern.compile(FileScanner.wildcardPattern(wildcard));
/* 103 */       this.explicitDot = wildcard.startsWith(".");
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean accept(File dir, String name) {
/* 108 */       if (name.startsWith(".") && !this.explicitDot) {
/* 109 */         return false;
/*     */       }
/* 111 */       return this.regex.matcher(name).matches();
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/files/FileScanner.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */