/*    */ package org.renjin.eval;
/*    */ 
/*    */ import org.renjin.primitives.special.ControlFlowException;
/*    */ import org.renjin.sexp.Environment;
/*    */ import org.renjin.sexp.Function;
/*    */ import org.renjin.sexp.ListVector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RestartException
/*    */   extends ControlFlowException
/*    */ {
/*    */   private Environment exitEnvironment;
/*    */   private Function handler;
/*    */   private ListVector arguments;
/*    */   
/*    */   public RestartException(Environment exitEnvironment, Function handler, ListVector arguments) {
/* 36 */     this.exitEnvironment = exitEnvironment;
/* 37 */     this.handler = handler;
/* 38 */     this.arguments = arguments;
/*    */   }
/*    */   
/*    */   public Environment getExitEnvironment() {
/* 42 */     return this.exitEnvironment;
/*    */   }
/*    */   
/*    */   public Function getHandler() {
/* 46 */     return this.handler;
/*    */   }
/*    */   
/*    */   public ListVector getArguments() {
/* 50 */     return this.arguments;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/eval/RestartException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */