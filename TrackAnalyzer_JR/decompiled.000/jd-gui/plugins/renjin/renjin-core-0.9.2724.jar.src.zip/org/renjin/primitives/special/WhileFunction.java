/*    */ package org.renjin.primitives.special;
/*    */ 
/*    */ import org.renjin.compiler.Compiler;
/*    */ import org.renjin.eval.Context;
/*    */ import org.renjin.sexp.Environment;
/*    */ import org.renjin.sexp.FunctionCall;
/*    */ import org.renjin.sexp.Null;
/*    */ import org.renjin.sexp.PairList;
/*    */ import org.renjin.sexp.SEXP;
/*    */ import org.renjin.sexp.SpecialFunction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WhileFunction
/*    */   extends SpecialFunction
/*    */ {
/*    */   public WhileFunction() {
/* 28 */     super("while");
/*    */   }
/*    */ 
/*    */   
/*    */   public SEXP apply(Context context, Environment rho, FunctionCall call, PairList args) {
/* 33 */     SEXP condition = args.getElementAsSEXP(0);
/* 34 */     SEXP statement = args.getElementAsSEXP(1);
/*    */     
/* 36 */     int iterationCount = 0;
/* 37 */     boolean compilationFailed = false;
/*    */     
/* 39 */     while (asLogicalNoNA(context, call, context.evaluate(condition, rho))) {
/*    */       
/*    */       try {
/* 42 */         iterationCount++;
/*    */         
/* 44 */         if (ForFunction.COMPILE_LOOPS && iterationCount > 50 && !compilationFailed) {
/* 45 */           if (Compiler.tryCompileAndRun(context, rho, (SEXP)call)) {
/*    */             break;
/*    */           }
/* 48 */           compilationFailed = true;
/*    */         } 
/*    */ 
/*    */         
/* 52 */         context.evaluate(statement, rho);
/*    */       }
/* 54 */       catch (BreakException e) {
/*    */         break;
/* 56 */       } catch (NextException nextException) {}
/*    */     } 
/*    */ 
/*    */     
/* 60 */     context.setInvisibleFlag();
/* 61 */     return (SEXP)Null.INSTANCE;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/special/WhileFunction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */