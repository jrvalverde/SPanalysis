/*    */ package org.renjin.primitives.io.connections;
/*    */ 
/*    */ import java.io.PrintWriter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class Sink
/*    */ {
/*    */   private Connection connection;
/*    */   private boolean split;
/*    */   private boolean closeOnExit;
/*    */   
/*    */   public Sink(Connection connection, boolean split, boolean closeOnExit) {
/* 48 */     this.connection = connection;
/* 49 */     this.split = split;
/* 50 */     this.closeOnExit = closeOnExit;
/*    */   }
/*    */   
/*    */   public PrintWriter getPrintWriter(PrintWriter originalStream) {
/* 54 */     PrintWriter sinkWriter = this.connection.getOpenPrintWriter();
/* 55 */     if (this.split) {
/* 56 */       return new PrintWriter(new SplitWriter(originalStream, sinkWriter));
/*    */     }
/* 58 */     return sinkWriter;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isCloseOnExit() {
/* 63 */     return this.closeOnExit;
/*    */   }
/*    */   
/*    */   public Connection getConnection() {
/* 67 */     return this.connection;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/io/connections/Sink.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */