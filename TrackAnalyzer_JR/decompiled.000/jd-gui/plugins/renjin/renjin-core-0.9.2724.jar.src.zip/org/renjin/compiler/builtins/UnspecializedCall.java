/*    */ package org.renjin.compiler.builtins;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.renjin.compiler.codegen.EmitContext;
/*    */ import org.renjin.compiler.ir.ValueBounds;
/*    */ import org.renjin.compiler.ir.tac.IRArgument;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ import org.renjin.repackaged.asm.commons.InstructionAdapter;
/*    */ import org.renjin.sexp.SEXP;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UnspecializedCall
/*    */   implements Specialization
/*    */ {
/* 33 */   public static final UnspecializedCall INSTANCE = new UnspecializedCall(false);
/*    */   
/* 35 */   public static final UnspecializedCall PURE = new UnspecializedCall(true);
/*    */   
/*    */   private final boolean pure;
/*    */   
/*    */   private UnspecializedCall(boolean pure) {
/* 40 */     this.pure = pure;
/*    */   }
/*    */ 
/*    */   
/*    */   public Type getType() {
/* 45 */     return Type.getType(SEXP.class);
/*    */   }
/*    */   
/*    */   public ValueBounds getResultBounds() {
/* 49 */     return ValueBounds.UNBOUNDED;
/*    */   }
/*    */ 
/*    */   
/*    */   public void load(EmitContext emitContext, InstructionAdapter mv, List<IRArgument> arguments) {
/* 54 */     throw new FailedToSpecializeException("failed to specialize");
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isPure() {
/* 59 */     return false;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/builtins/UnspecializedCall.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */