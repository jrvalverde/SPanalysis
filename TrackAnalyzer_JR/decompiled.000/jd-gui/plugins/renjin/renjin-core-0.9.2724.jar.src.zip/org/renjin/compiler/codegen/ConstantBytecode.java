/*     */ package org.renjin.compiler.codegen;
/*     */ 
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ import org.renjin.repackaged.asm.commons.InstructionAdapter;
/*     */ import org.renjin.sexp.AttributeMap;
/*     */ import org.renjin.sexp.DoubleArrayVector;
/*     */ import org.renjin.sexp.DoubleVector;
/*     */ import org.renjin.sexp.Null;
/*     */ import org.renjin.sexp.PairList;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.StringVector;
/*     */ import org.renjin.sexp.Symbols;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConstantBytecode
/*     */ {
/*     */   public static void generateAttributes(InstructionAdapter mv, AttributeMap constantAttributes) {
/*  37 */     Type builderType = pushAttributeBuilder(mv, constantAttributes);
/*     */ 
/*     */     
/*  40 */     mv.invokeinterface(Type.getInternalName(SEXP.class), "setAttributes", 
/*  41 */         Type.getMethodDescriptor(Type.getType(SEXP.class), new Type[] { builderType }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Type pushAttributeBuilder(InstructionAdapter mv, AttributeMap constantAttributes) {
/*  49 */     Type builderType = Type.getType(AttributeMap.Builder.class);
/*  50 */     mv.invokestatic(Type.getInternalName(AttributeMap.class), "newBuilder", 
/*  51 */         Type.getMethodDescriptor(builderType, new Type[0]), false);
/*     */ 
/*     */     
/*  54 */     for (PairList.Node node : constantAttributes.nodes()) {
/*  55 */       if (node.getTag() == Symbols.CLASS) {
/*  56 */         pushConstant(mv, node.getValue());
/*  57 */         mv.invokevirtual(builderType.getInternalName(), "setClass", 
/*  58 */             Type.getMethodDescriptor(builderType, new Type[] { Type.getType(SEXP.class) }), false); continue;
/*     */       } 
/*  60 */       if (node.getTag() == Symbols.NAMES) {
/*  61 */         pushConstant(mv, node.getValue());
/*  62 */         mv.invokevirtual(builderType.getInternalName(), "setNames", 
/*  63 */             Type.getMethodDescriptor(builderType, new Type[] { Type.getType(SEXP.class) }), false); continue;
/*     */       } 
/*  65 */       if (node.getTag() == Symbols.DIM) {
/*  66 */         pushConstant(mv, node.getValue());
/*  67 */         mv.invokevirtual(builderType.getInternalName(), "setDim", 
/*  68 */             Type.getMethodDescriptor(builderType, new Type[] { Type.getType(SEXP.class) }), false); continue;
/*     */       } 
/*  70 */       if (node.getTag() == Symbols.DIMNAMES) {
/*  71 */         pushConstant(mv, node.getValue());
/*  72 */         mv.invokevirtual(builderType.getInternalName(), "setDimNames", 
/*  73 */             Type.getMethodDescriptor(builderType, new Type[] { Type.getType(SEXP.class) }), false);
/*     */         continue;
/*     */       } 
/*  76 */       mv.aconst(node.getTag().getPrintName());
/*  77 */       pushConstant(mv, node.getValue());
/*  78 */       mv.invokevirtual(builderType.getInternalName(), "set", 
/*  79 */           Type.getMethodDescriptor(builderType, new Type[] { Type.getType(String.class), Type.getType(SEXP.class) }), false);
/*     */     } 
/*     */     
/*  82 */     return builderType;
/*     */   }
/*     */   
/*     */   public static void pushAttributes(InstructionAdapter mv, AttributeMap constantAttributes) {
/*  86 */     pushAttributeBuilder(mv, constantAttributes);
/*  87 */     mv.invokevirtual(Type.getInternalName(AttributeMap.Builder.class), "build", 
/*  88 */         Type.getMethodDescriptor(Type.getType(AttributeMap.class), new Type[0]), false);
/*     */   }
/*     */   
/*     */   public static void pushConstant(InstructionAdapter mv, SEXP value) {
/*  92 */     if (value == Null.INSTANCE) {
/*  93 */       mv.visitFieldInsn(178, Type.getInternalName(Null.class), "INSTANCE", Type.getDescriptor(Null.class));
/*     */       return;
/*     */     } 
/*  96 */     if (value instanceof StringVector) {
/*  97 */       if (value.length() == 1 && value.getAttributes().isEmpty()) {
/*  98 */         mv.visitLdcInsn(((StringVector)value).getElementAsString(0));
/*  99 */         mv.invokestatic(Type.getInternalName(StringVector.class), "valueOf", 
/* 100 */             Type.getMethodDescriptor(Type.getType(StringVector.class), new Type[] { Type.getType(String.class) }), false);
/*     */         return;
/*     */       } 
/* 103 */     } else if (value instanceof DoubleVector && 
/* 104 */       value.length() == 1) {
/* 105 */       mv.anew(Type.getType(DoubleArrayVector.class));
/* 106 */       mv.dup();
/* 107 */       mv.dconst(((DoubleVector)value).getElementAsDouble(0));
/* 108 */       pushAttributes(mv, value.getAttributes());
/*     */       
/* 110 */       mv.invokespecial(Type.getInternalName(DoubleArrayVector.class), "<init>", 
/* 111 */           Type.getMethodDescriptor(Type.VOID_TYPE, new Type[] { Type.DOUBLE_TYPE, Type.getType(AttributeMap.class) }), false);
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 117 */     throw new UnsupportedOperationException("TODO: constant = " + value);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/codegen/ConstantBytecode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */