/*     */ package org.renjin.primitives.special;
/*     */ 
/*     */ import org.renjin.compiler.CompiledLoopBody;
/*     */ import org.renjin.compiler.NotCompilableException;
/*     */ import org.renjin.compiler.TypeSolver;
/*     */ import org.renjin.compiler.cfg.ControlFlowGraph;
/*     */ import org.renjin.compiler.cfg.DominanceTree;
/*     */ import org.renjin.compiler.cfg.UseDefMap;
/*     */ import org.renjin.compiler.codegen.ByteCodeEmitter;
/*     */ import org.renjin.compiler.ir.exception.InvalidSyntaxException;
/*     */ import org.renjin.compiler.ir.ssa.SsaTransformer;
/*     */ import org.renjin.compiler.ir.tac.IRBody;
/*     */ import org.renjin.compiler.ir.tac.IRBodyBuilder;
/*     */ import org.renjin.compiler.ir.tac.RuntimeState;
/*     */ import org.renjin.eval.Context;
/*     */ import org.renjin.eval.EvalException;
/*     */ import org.renjin.eval.Profiler;
/*     */ import org.renjin.sexp.Environment;
/*     */ import org.renjin.sexp.FunctionCall;
/*     */ import org.renjin.sexp.Null;
/*     */ import org.renjin.sexp.PairList;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.SpecialFunction;
/*     */ import org.renjin.sexp.Symbol;
/*     */ import org.renjin.sexp.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ForFunction
/*     */   extends SpecialFunction
/*     */ {
/*  41 */   public static boolean COMPILE_LOOPS = Boolean.getBoolean("renjin.compile.loops");
/*     */   
/*     */   public static boolean FAIL_ON_COMPILATION_ERROR = false;
/*     */   
/*     */   private static final int COMPILE_THRESHOLD = 200;
/*     */   private static final int WARMUP_ITERATIONS = 5;
/*     */   
/*     */   public ForFunction() {
/*  49 */     super("for");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SEXP apply(Context context, Environment rho, FunctionCall call, PairList _args_unused) {
/*  56 */     PairList args = call.getArguments();
/*  57 */     Symbol symbol = (Symbol)args.getElementAsSEXP(0);
/*  58 */     SEXP elementsExp = context.evaluate(args.getElementAsSEXP(1), rho);
/*  59 */     if (!(elementsExp instanceof Vector)) {
/*  60 */       throw new EvalException("invalid for() loop sequence", new Object[0]);
/*     */     }
/*  62 */     Vector elements = (Vector)elementsExp;
/*  63 */     SEXP statement = args.getElementAsSEXP(2);
/*     */     
/*  65 */     boolean profiling = (Profiler.ENABLED && elements.length() > 200);
/*  66 */     if (profiling) {
/*  67 */       Profiler.loopStart(call, elements);
/*     */     }
/*     */     
/*  70 */     int i = 0;
/*     */ 
/*     */     
/*     */     try {
/*  74 */       boolean compilationFailed = false;
/*  75 */       for (i = 0; i != elements.length(); i++)
/*     */       {
/*     */         try {
/*  78 */           if (COMPILE_LOOPS && i >= 5 && elements.length() > 200 && !compilationFailed) {
/*     */ 
/*     */             
/*  81 */             if (tryCompileAndRun(context, rho, call, elements, i)) {
/*     */               break;
/*     */             }
/*  84 */             compilationFailed = true;
/*     */           } 
/*     */ 
/*     */           
/*  88 */           rho.setVariable(context, symbol, elements.getElementAsSEXP(i));
/*  89 */           context.evaluate(statement, rho);
/*  90 */         } catch (BreakException e) {
/*     */           break;
/*  92 */         } catch (NextException nextException) {}
/*     */       }
/*     */     
/*     */     } finally {
/*     */       
/*  97 */       if (profiling) {
/*  98 */         Profiler.loopEnd(i);
/*     */       }
/*     */     } 
/*     */     
/* 102 */     context.setInvisibleFlag();
/* 103 */     return (SEXP)Null.INSTANCE;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean tryCompileAndRun(Context context, Environment rho, FunctionCall call, Vector elements, int i) {
/* 108 */     CompiledLoopBody compiledBody = null;
/*     */ 
/*     */     
/*     */     try {
/* 112 */       RuntimeState runtimeState = new RuntimeState(context, rho);
/* 113 */       IRBodyBuilder builder = new IRBodyBuilder(runtimeState);
/* 114 */       IRBody body = builder.buildLoopBody(call, (SEXP)elements);
/*     */       
/* 116 */       ControlFlowGraph cfg = new ControlFlowGraph(body);
/*     */       
/* 118 */       DominanceTree dTree = new DominanceTree(cfg);
/* 119 */       SsaTransformer ssaTransformer = new SsaTransformer(cfg, dTree);
/* 120 */       ssaTransformer.transform();
/*     */ 
/*     */       
/* 123 */       UseDefMap useDefMap = new UseDefMap(cfg);
/* 124 */       TypeSolver types = new TypeSolver(cfg, useDefMap);
/* 125 */       types.execute();
/*     */       
/* 127 */       types.verifyFunctionAssumptions(runtimeState);
/*     */       
/* 129 */       ssaTransformer.removePhiFunctions(types);
/*     */ 
/*     */       
/* 132 */       ByteCodeEmitter emitter = new ByteCodeEmitter(cfg, types);
/* 133 */       compiledBody = emitter.compileLoopBody().newInstance();
/*     */     }
/* 135 */     catch (NotCompilableException e) {
/* 136 */       if (FAIL_ON_COMPILATION_ERROR) {
/* 137 */         throw new AssertionError("Loop compilation failed: " + e.toString(context));
/*     */       }
/* 139 */       context.warn("Could not compile loop because: " + e.toString(context));
/* 140 */       return false;
/*     */     }
/* 142 */     catch (InvalidSyntaxException e) {
/* 143 */       throw new EvalException(e.getMessage(), new Object[0]);
/*     */     }
/* 145 */     catch (Exception e) {
/* 146 */       throw new EvalException("Exception compiling loop: " + e.getMessage(), e);
/*     */     } 
/*     */     
/* 149 */     compiledBody.run(context, rho, (SEXP)elements, i);
/*     */     
/* 151 */     return true;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/special/ForFunction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */