package org.renjin.pipeliner.fusion.kernel;

import org.renjin.pipeliner.ComputeMethod;
import org.renjin.pipeliner.fusion.node.LoopNode;

public interface LoopKernel {
  void compute(ComputeMethod paramComputeMethod, LoopNode[] paramArrayOfLoopNode);
  
  String debugLabel(LoopNode[] paramArrayOfLoopNode);
  
  void appendToKey(StringBuilder paramStringBuilder);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/pipeliner/fusion/kernel/LoopKernel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */