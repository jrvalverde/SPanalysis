/*    */ package org.renjin.packaging;
/*    */ 
/*    */ import java.io.ByteArrayInputStream;
/*    */ import java.io.IOException;
/*    */ import java.util.zip.GZIPInputStream;
/*    */ import org.renjin.eval.Context;
/*    */ import org.renjin.eval.EvalException;
/*    */ import org.renjin.primitives.io.serialization.RDataReader;
/*    */ import org.renjin.sexp.Environment;
/*    */ import org.renjin.sexp.Null;
/*    */ import org.renjin.sexp.Promise;
/*    */ import org.renjin.sexp.SEXP;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SerializedPromise1
/*    */   extends Promise
/*    */ {
/*    */   private byte[] bytes;
/*    */   
/*    */   public SerializedPromise1(byte[] bytes) {
/* 39 */     super((Environment)Environment.EMPTY, (SEXP)Null.INSTANCE);
/* 40 */     this.bytes = bytes;
/*    */   }
/*    */ 
/*    */   
/*    */   protected SEXP doEval(Context context, boolean allowMissing) {
/* 45 */     try (RDataReader reader = new RDataReader(context, new GZIPInputStream(new ByteArrayInputStream(this.bytes)))) {
/*    */ 
/*    */       
/* 48 */       return reader.readFile();
/* 49 */     } catch (IOException e) {
/* 50 */       throw new EvalException(e);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/packaging/SerializedPromise1.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */