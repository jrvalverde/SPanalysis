/*    */ package org.renjin.primitives.io.connections;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ import java.nio.charset.Charset;
/*    */ import org.apache.commons.compress.compressors.xz.XZCompressorOutputStream;
/*    */ import org.apache.commons.vfs2.FileObject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XzFileConnection
/*    */   extends FileConnection
/*    */ {
/* 29 */   public static final int[] XZ_MAGIC_BYTES = new int[] { 253, 55, 122, 88, 90, 0 };
/*    */   
/*    */   public XzFileConnection(FileObject file, Charset charset) throws IOException {
/* 32 */     super(file, charset);
/*    */   }
/*    */ 
/*    */   
/*    */   protected OutputStream doOpenForOutput() throws IOException {
/* 37 */     return (OutputStream)new XZCompressorOutputStream(super.doOpenForOutput());
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/io/connections/XzFileConnection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */