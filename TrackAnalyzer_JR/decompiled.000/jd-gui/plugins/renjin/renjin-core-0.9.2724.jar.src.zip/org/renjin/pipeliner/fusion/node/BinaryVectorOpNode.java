/*     */ package org.renjin.pipeliner.fusion.node;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Optional;
/*     */ import org.renjin.pipeliner.ComputeMethod;
/*     */ import org.renjin.repackaged.asm.Label;
/*     */ import org.renjin.repackaged.asm.MethodVisitor;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ import org.renjin.sexp.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BinaryVectorOpNode
/*     */   extends LoopNode
/*     */ {
/*     */   private String operatorName;
/*  36 */   private LoopNode[] operands = new LoopNode[2];
/*     */   private int lengthLocal1;
/*     */   private int lengthLocal2;
/*     */   private int lengthLocal;
/*     */   private Method applyMethod;
/*     */   private Class argumentType;
/*     */   
/*     */   public BinaryVectorOpNode(String operatorName, Method operator, LoopNode x, LoopNode y) {
/*  44 */     this.operatorName = operatorName;
/*  45 */     this.operands[0] = x;
/*  46 */     this.operands[1] = y;
/*  47 */     this.applyMethod = operator;
/*  48 */     assert this.applyMethod != null;
/*  49 */     this.argumentType = this.applyMethod.getParameterTypes()[0];
/*     */   }
/*     */   
/*     */   public static Method findMethod(Vector vector) {
/*  53 */     for (Method method : vector.getClass().getMethods()) {
/*  54 */       if (method.getName().equals("compute") && 
/*  55 */         Modifier.isPublic(method.getModifiers()) && 
/*  56 */         Modifier.isStatic(method.getModifiers()) && (method
/*  57 */         .getParameterTypes()).length == 2)
/*     */       {
/*  59 */         if (supportedType(method.getReturnType()) && 
/*  60 */           supportedType(method.getParameterTypes()[0]) && 
/*  61 */           supportedType(method.getParameterTypes()[1])) {
/*  62 */           return method;
/*     */         }
/*     */       }
/*     */     } 
/*  66 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void init(ComputeMethod method) {
/*  71 */     MethodVisitor mv = method.getVisitor();
/*  72 */     this.operands[0].init(method);
/*  73 */     this.operands[1].init(method);
/*  74 */     this.lengthLocal1 = method.reserveLocal(1);
/*  75 */     this.lengthLocal2 = method.reserveLocal(1);
/*  76 */     this.lengthLocal = method.reserveLocal(1);
/*  77 */     this.operands[0].pushLength(method);
/*  78 */     mv.visitInsn(89);
/*  79 */     mv.visitVarInsn(54, this.lengthLocal1);
/*  80 */     this.operands[1].pushLength(method);
/*  81 */     mv.visitInsn(89);
/*  82 */     mv.visitVarInsn(54, this.lengthLocal2);
/*  83 */     method.getVisitor().visitMethodInsn(184, "java/lang/Math", "max", "(II)I", false);
/*  84 */     mv.visitVarInsn(54, this.lengthLocal);
/*     */   }
/*     */ 
/*     */   
/*     */   public void pushLength(ComputeMethod method) {
/*  89 */     method.getVisitor().visitVarInsn(21, this.lengthLocal);
/*     */   }
/*     */ 
/*     */   
/*     */   public void pushElementAsInt(ComputeMethod method, Optional<Label> integerNaLabel) {
/*  94 */     if (this.argumentType.equals(double.class)) {
/*  95 */       computeDouble(method, integerNaLabel);
/*  96 */     } else if (this.argumentType.equals(int.class)) {
/*  97 */       computeInt(method, integerNaLabel);
/*     */     } else {
/*  99 */       throw new UnsupportedOperationException();
/*     */     } 
/* 101 */     cast(method.getVisitor(), this.applyMethod.getReturnType(), int.class);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean mustCheckForIntegerNAs() {
/* 106 */     return (this.operands[0].mustCheckForIntegerNAs() || this.operands[1].mustCheckForIntegerNAs());
/*     */   }
/*     */ 
/*     */   
/*     */   public void appendToKey(StringBuilder key) {
/* 111 */     key.append(this.operatorName);
/* 112 */     key.append('(');
/* 113 */     for (LoopNode operandAccessor : this.operands) {
/* 114 */       operandAccessor.appendToKey(key);
/* 115 */       key.append(';');
/*     */     } 
/* 117 */     key.append(')');
/*     */   }
/*     */ 
/*     */   
/*     */   public void pushElementAsDouble(ComputeMethod method, Optional<Label> naIntegerLabel) {
/* 122 */     if (this.argumentType.equals(double.class)) {
/* 123 */       computeDouble(method, naIntegerLabel);
/* 124 */     } else if (this.argumentType.equals(int.class)) {
/* 125 */       computeInt(method, naIntegerLabel);
/*     */     } else {
/* 127 */       throw new UnsupportedOperationException(this.argumentType.getName());
/*     */     } 
/* 129 */     cast(method.getVisitor(), this.applyMethod.getReturnType(), double.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void computeInt(ComputeMethod method, Optional<Label> naLabel) {
/* 142 */     Optional<Label> argNaLabel = Optional.empty();
/* 143 */     if (naLabel.isPresent() && (this.operands[0]
/* 144 */       .mustCheckForIntegerNAs() || this.operands[1].mustCheckForIntegerNAs())) {
/* 145 */       argNaLabel = Optional.of(new Label());
/*     */     }
/*     */     
/* 148 */     Optional<Label> done = Optional.empty();
/* 149 */     if (argNaLabel.isPresent()) {
/* 150 */       done = Optional.of(new Label());
/*     */     }
/*     */     
/* 153 */     MethodVisitor mv = method.getVisitor();
/* 154 */     mv.visitInsn(89);
/* 155 */     mv.visitVarInsn(21, this.lengthLocal1);
/*     */     
/* 157 */     mv.visitInsn(112);
/*     */ 
/*     */     
/* 160 */     this.operands[0].pushElementAsInt(method, argNaLabel);
/*     */ 
/*     */     
/* 163 */     mv.visitInsn(95);
/*     */     
/* 165 */     mv.visitVarInsn(21, this.lengthLocal2);
/*     */     
/* 167 */     mv.visitInsn(112);
/*     */ 
/*     */     
/* 170 */     this.operands[1].pushElementAsInt(method, argNaLabel);
/*     */ 
/*     */     
/* 173 */     mv.visitMethodInsn(184, 
/* 174 */         Type.getInternalName(this.applyMethod.getDeclaringClass()), this.applyMethod
/* 175 */         .getName(), 
/* 176 */         Type.getMethodDescriptor(this.applyMethod), false);
/*     */     
/* 178 */     if (done.isPresent()) {
/* 179 */       mv.visitJumpInsn(167, done.get());
/*     */     }
/*     */     
/* 182 */     if (argNaLabel.isPresent()) {
/* 183 */       mv.visitLabel(argNaLabel.get());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 190 */       mv.visitInsn(87);
/* 191 */       mv.visitJumpInsn(167, naLabel.get());
/*     */     } 
/*     */     
/* 194 */     if (done.isPresent()) {
/* 195 */       mv.visitLabel(done.get());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void computeDouble(ComputeMethod method, Optional<Label> integerNaLabel) {
/* 208 */     Optional<Label> argNaLabel1 = Optional.empty();
/* 209 */     if (integerNaLabel.isPresent() && this.operands[0].mustCheckForIntegerNAs()) {
/* 210 */       argNaLabel1 = Optional.of(new Label());
/*     */     }
/*     */     
/* 213 */     Optional<Label> argNaLabel2 = Optional.empty();
/* 214 */     if (integerNaLabel.isPresent() && this.operands[1].mustCheckForIntegerNAs()) {
/* 215 */       argNaLabel2 = Optional.of(new Label());
/*     */     }
/*     */     
/* 218 */     Optional<Label> done = Optional.empty();
/* 219 */     if (argNaLabel1.isPresent() || argNaLabel2.isPresent()) {
/* 220 */       done = Optional.of(new Label());
/*     */     }
/*     */ 
/*     */     
/* 224 */     MethodVisitor mv = method.getVisitor();
/* 225 */     mv.visitInsn(89);
/* 226 */     mv.visitVarInsn(21, this.lengthLocal1);
/*     */     
/* 228 */     mv.visitInsn(112);
/*     */ 
/*     */     
/* 231 */     this.operands[0].pushElementAsDouble(method, argNaLabel1);
/*     */ 
/*     */     
/* 234 */     mv.visitInsn(93);
/* 235 */     mv.visitInsn(88);
/*     */     
/* 237 */     mv.visitVarInsn(21, this.lengthLocal2);
/*     */     
/* 239 */     mv.visitInsn(112);
/*     */     
/* 241 */     this.operands[1].pushElementAsDouble(method, argNaLabel2);
/*     */ 
/*     */ 
/*     */     
/* 245 */     mv.visitMethodInsn(184, 
/* 246 */         Type.getInternalName(this.applyMethod.getDeclaringClass()), this.applyMethod
/* 247 */         .getName(), 
/* 248 */         Type.getMethodDescriptor(this.applyMethod), false);
/*     */     
/* 250 */     if (done.isPresent()) {
/* 251 */       mv.visitJumpInsn(167, done.get());
/*     */     }
/*     */     
/* 254 */     if (argNaLabel1.isPresent()) {
/* 255 */       mv.visitLabel(argNaLabel1.get());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 261 */       mv.visitInsn(87);
/* 262 */       mv.visitJumpInsn(167, integerNaLabel.get());
/*     */     } 
/*     */     
/* 265 */     if (argNaLabel2.isPresent()) {
/* 266 */       mv.visitLabel(argNaLabel2.get());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 272 */       mv.visitInsn(87);
/* 273 */       mv.visitInsn(88);
/* 274 */       mv.visitInsn(3);
/* 275 */       mv.visitJumpInsn(167, integerNaLabel.get());
/*     */     } 
/*     */ 
/*     */     
/* 279 */     if (done.isPresent()) {
/* 280 */       mv.visitLabel(done.get());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 286 */     return "(" + this.operands[0] + this.operatorName + this.operands[1] + ")";
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/pipeliner/fusion/node/BinaryVectorOpNode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */