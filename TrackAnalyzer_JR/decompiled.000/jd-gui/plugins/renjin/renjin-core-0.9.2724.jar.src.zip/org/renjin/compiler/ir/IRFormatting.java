/*    */ package org.renjin.compiler.ir;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IRFormatting
/*    */ {
/*    */   public static final String LEFT_ARROW = "←";
/*    */   public static final String LEFT_DOUBLE_ARROW = "⇐";
/*    */   
/*    */   public static void appendSubscript(StringBuilder sb, int subscript) {
/* 24 */     String digits = Integer.toString(subscript);
/* 25 */     for (int i = 0; i != digits.length(); i++) {
/* 26 */       int digit = digits.charAt(i) - 48;
/* 27 */       sb.appendCodePoint(8320 + digit);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/ir/IRFormatting.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */