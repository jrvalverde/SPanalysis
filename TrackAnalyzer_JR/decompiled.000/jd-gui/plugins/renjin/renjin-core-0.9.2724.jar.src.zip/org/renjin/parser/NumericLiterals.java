/*     */ package org.renjin.parser;
/*     */ 
/*     */ import java.text.NumberFormat;
/*     */ import org.apache.commons.math.complex.Complex;
/*     */ import org.renjin.sexp.ComplexVector;
/*     */ import org.renjin.sexp.DoubleVector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NumericLiterals
/*     */ {
/*  32 */   public static final NumberFormat REAL_FORMAT = createRealFormat();
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int SIGNIFICAND_WIDTH = 53;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int EXP_SHIFT = 52;
/*     */ 
/*     */   
/*     */   private static final long FRACT_HOB = 4503599627370496L;
/*     */ 
/*     */   
/*     */   public static final int EXP_BIAS = 1023;
/*     */ 
/*     */   
/*     */   private static final long EXP_ONE = 4607182418800017408L;
/*     */ 
/*     */   
/*     */   private static final int MAX_SMALL_BIN_EXP = 62;
/*     */ 
/*     */   
/*     */   private static final int MIN_SMALL_BIN_EXP = -21;
/*     */ 
/*     */   
/*     */   private static final int MAX_DECIMAL_DIGITS = 15;
/*     */ 
/*     */   
/*     */   private static final int MAX_DECIMAL_EXPONENT = 308;
/*     */ 
/*     */   
/*     */   private static final int MIN_DECIMAL_EXPONENT = -324;
/*     */ 
/*     */   
/*     */   private static final int BIG_DECIMAL_EXPONENT = 324;
/*     */ 
/*     */   
/*     */   private static final int MAX_NDIGITS = 1100;
/*     */ 
/*     */   
/*     */   private static final int INT_DECIMAL_DIGITS = 9;
/*     */ 
/*     */   
/*     */   public static final long EXP_BIT_MASK = 9218868437227405312L;
/*     */ 
/*     */   
/*     */   public static final long SIGNIF_BIT_MASK = 4503599627370495L;
/*     */ 
/*     */   
/*     */   private static final long SIGN_BIT_MASK = -9223372036854775808L;
/*     */ 
/*     */   
/*  85 */   private static final double[] SMALL_10_POW = new double[] { 1.0D, 10.0D, 100.0D, 1000.0D, 10000.0D, 100000.0D, 1000000.0D, 1.0E7D, 1.0E8D, 1.0E9D, 1.0E10D, 1.0E11D, 1.0E12D, 1.0E13D, 1.0E14D, 1.0E15D, 1.0E16D, 1.0E17D, 1.0E18D, 1.0E19D, 1.0E20D, 1.0E21D, 1.0E22D };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  94 */   private static final float[] SINGLE_SMALL_10_POW = new float[] { 1.0F, 10.0F, 100.0F, 1000.0F, 10000.0F, 100000.0F, 1000000.0F, 1.0E7F, 1.0E8F, 1.0E9F, 1.0E10F };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 100 */   private static final double[] BIG_10_POW = new double[] { 1.0E16D, 1.0E32D, 1.0E64D, 1.0E128D, 1.0E256D };
/*     */   
/* 102 */   private static final double[] TINY_10_POW = new double[] { 1.0E-16D, 1.0E-32D, 1.0E-64D, 1.0E-128D, 1.0E-256D };
/*     */ 
/*     */   
/* 105 */   private static final int MAX_SMALL_TEN = SMALL_10_POW.length - 1;
/* 106 */   private static final int SINGLE_MAX_SMALL_TEN = SINGLE_SMALL_10_POW.length - 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String format(double value, String naString) {
/* 116 */     if (DoubleVector.isNA(value)) {
/* 117 */       return naString;
/*     */     }
/* 119 */     return toString(value);
/*     */   }
/*     */ 
/*     */   
/*     */   public static String format(int value) {
/* 124 */     return Integer.toString(value);
/*     */   }
/*     */   
/*     */   public static String toString(double value) {
/* 128 */     if (Double.isNaN(value)) {
/* 129 */       return "NaN";
/*     */     }
/* 131 */     if (Double.isInfinite(value)) {
/* 132 */       if (value < 0.0D) {
/* 133 */         return "-Inf";
/*     */       }
/* 135 */       return "Inf";
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 140 */     if (value > 100000.0D) {
/* 141 */       return Double.toString(value);
/*     */     }
/* 143 */     return REAL_FORMAT.format(value);
/*     */   }
/*     */   
/*     */   public static String toString(Complex complex) {
/* 147 */     StringBuilder sb = new StringBuilder();
/* 148 */     sb.append(toString(complex.getReal()));
/* 149 */     if (complex.getImaginary() >= 0.0D) {
/* 150 */       sb.append('+');
/*     */     }
/* 152 */     sb.append(toString(complex.getImaginary()));
/* 153 */     sb.append('i');
/* 154 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public static NumberFormat createRealFormat() {
/* 158 */     NumberFormat format = NumberFormat.getNumberInstance();
/* 159 */     format.setMinimumFractionDigits(0);
/* 160 */     format.setMaximumFractionDigits(14);
/* 161 */     format.setGroupingUsed(false);
/* 162 */     return format;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double parseDouble(CharSequence text) {
/* 169 */     return parseDouble(text, 0, text.length(), '.', false);
/*     */   }
/*     */   
/*     */   public static Complex parseComplex(CharSequence s) {
/* 173 */     int lastCharIndex = s.length() - 1;
/* 174 */     if (s.charAt(lastCharIndex) == 'i') {
/*     */       
/* 176 */       int imaginaryStart = findImaginaryStart(s);
/* 177 */       if (imaginaryStart <= 0)
/*     */       {
/* 179 */         return ComplexVector.NA;
/*     */       }
/* 181 */       double d1 = parseDouble(s, 0, imaginaryStart, '.', true);
/* 182 */       if (DoubleVector.isNA(d1)) {
/* 183 */         return ComplexVector.NA;
/*     */       }
/* 185 */       double imaginary = parseDouble(s, imaginaryStart, lastCharIndex, '.', true);
/* 186 */       return ComplexVector.complex(d1, imaginary);
/*     */     } 
/*     */ 
/*     */     
/* 190 */     double real = parseDouble(s, 0, s.length(), '.', true);
/* 191 */     return ComplexVector.complex(real);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static int findImaginaryStart(CharSequence s) {
/* 197 */     int index = s.length() - 2;
/* 198 */     while (index >= 0) {
/* 199 */       char c = s.charAt(index);
/* 200 */       if (c == '+' || c == '-') {
/* 201 */         return index;
/*     */       }
/* 203 */       index--;
/*     */     } 
/* 205 */     return -1;
/*     */   }
/*     */   
/*     */   public static int parseInt(CharSequence line) {
/* 209 */     return (int)parseDouble(line);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double parseDouble(CharSequence s, int startIndex, int endIndex, char dec, boolean NA) {
/* 223 */     int sign = 1;
/* 224 */     int p = startIndex;
/*     */ 
/*     */     
/* 227 */     while (p < endIndex && Character.isWhitespace(s.charAt(p))) {
/* 228 */       p++;
/*     */     }
/* 230 */     while (endIndex > p && Character.isWhitespace(s.charAt(endIndex - 1))) {
/* 231 */       endIndex--;
/*     */     }
/*     */ 
/*     */     
/* 235 */     if (NA && p + 2 < endIndex && s.charAt(p) == 'N' && s.charAt(p + 1) == 'A') {
/* 236 */       return DoubleVector.NA;
/*     */     }
/*     */ 
/*     */     
/* 240 */     if (p == endIndex) {
/* 241 */       return DoubleVector.NA;
/*     */     }
/*     */ 
/*     */     
/* 245 */     switch (s.charAt(p)) {
/*     */       case '-':
/* 247 */         sign = -1;
/* 248 */         p++;
/*     */         break;
/*     */       case '+':
/* 251 */         p++;
/*     */         break;
/*     */     } 
/*     */     
/* 255 */     if (equalsIgnoringCase(s, p, endIndex, "NAN")) {
/* 256 */       return Double.NaN;
/*     */     }
/*     */     
/* 259 */     if (equalsIgnoringCase(s, p, endIndex, "INF") || 
/* 260 */       equalsIgnoringCase(s, p, endIndex, "INFINITY"))
/*     */     {
/* 262 */       return sign * Double.POSITIVE_INFINITY;
/*     */     }
/*     */     
/* 265 */     if (endIndex - p > 2 && s.charAt(p) == '0' && (s.charAt(p + 1) == 'x' || s.charAt(p + 2) == 'X')) {
/* 266 */       return parseDoubleHex(s, sign, p, endIndex, dec);
/*     */     }
/* 268 */     return parseDoubleDecimal(s, sign, p, endIndex, dec);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static double parseDoubleDecimal(CharSequence in, int sign, int startIndex, int endIndex, char decimalPoint) {
/*     */     int j;
/* 288 */     char[] digits = new char[endIndex - startIndex];
/* 289 */     int nDigits = 0;
/* 290 */     boolean decSeen = false;
/* 291 */     int decPt = 0;
/* 292 */     int nLeadZero = 0;
/* 293 */     int nTrailZero = 0;
/* 294 */     int i = startIndex;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 299 */     while (i < endIndex) {
/* 300 */       char c1 = in.charAt(i);
/* 301 */       if (c1 == '0') {
/* 302 */         nLeadZero++;
/* 303 */       } else if (c1 == decimalPoint) {
/* 304 */         if (decSeen)
/*     */         {
/* 306 */           return DoubleVector.NA;
/*     */         }
/* 308 */         decPt = i - startIndex;
/* 309 */         decSeen = true;
/*     */       } else {
/*     */         break;
/*     */       } 
/* 313 */       i++;
/*     */     } 
/*     */ 
/*     */     
/* 317 */     while (i < endIndex) {
/* 318 */       char c1 = in.charAt(i);
/* 319 */       if (c1 >= '1' && c1 <= '9') {
/* 320 */         digits[nDigits++] = c1;
/* 321 */         nTrailZero = 0;
/* 322 */       } else if (c1 == '0') {
/* 323 */         digits[nDigits++] = c1;
/* 324 */         nTrailZero++;
/* 325 */       } else if (c1 == decimalPoint) {
/* 326 */         if (decSeen)
/*     */         {
/* 328 */           return DoubleVector.NA;
/*     */         }
/* 330 */         decPt = i - startIndex;
/* 331 */         decSeen = true;
/*     */       } else {
/*     */         break;
/*     */       } 
/* 335 */       i++;
/*     */     } 
/* 337 */     nDigits -= nTrailZero;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 357 */     boolean isZero = (nDigits == 0);
/* 358 */     if (isZero && nLeadZero == 0)
/*     */     {
/*     */ 
/*     */       
/* 362 */       return DoubleVector.NA;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 370 */     if (decSeen) {
/* 371 */       j = decPt - nLeadZero;
/*     */     } else {
/* 373 */       j = nDigits + nTrailZero;
/*     */     } 
/*     */ 
/*     */     
/*     */     char c;
/*     */     
/* 379 */     if (i < endIndex && ((c = in.charAt(i)) == 'e' || c == 'E')) {
/* 380 */       int expSign = 1;
/* 381 */       int expVal = 0;
/* 382 */       int reallyBig = 214748364;
/* 383 */       boolean expOverflow = false;
/* 384 */       switch (in.charAt(++i)) {
/*     */         case '-':
/* 386 */           expSign = -1;
/*     */         
/*     */         case '+':
/* 389 */           i++; break;
/*     */       } 
/* 391 */       int expAt = i;
/*     */       
/* 393 */       while (i < endIndex) {
/* 394 */         if (expVal >= reallyBig)
/*     */         {
/*     */           
/* 397 */           expOverflow = true;
/*     */         }
/* 399 */         c = in.charAt(i++);
/* 400 */         if (c >= '0' && c <= '9') {
/* 401 */           expVal = expVal * 10 + c - 48; continue;
/*     */         } 
/* 403 */         i--;
/*     */       } 
/*     */ 
/*     */       
/* 407 */       int expLimit = 324 + nDigits + nTrailZero;
/* 408 */       if (expOverflow || expVal > expLimit) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 421 */         j = expSign * expLimit;
/*     */       }
/*     */       else {
/*     */         
/* 425 */         j += expSign * expVal;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 434 */       if (i == expAt) {
/* 435 */         return DoubleVector.NA;
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 442 */     if (i < endIndex)
/*     */     {
/* 444 */       return DoubleVector.NA;
/*     */     }
/* 446 */     if (isZero) {
/* 447 */       return sign * 0.0D;
/*     */     }
/* 449 */     return doubleValue((sign < 0), j, digits, nDigits);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static double parseDoubleHex(CharSequence s, int sign, int startIndex, int endIndex, char dec) {
/* 455 */     double ans = 0.0D;
/* 456 */     int expn = 0;
/* 457 */     int exph = -1;
/* 458 */     int p = startIndex;
/*     */ 
/*     */     
/* 461 */     p += 2; while (true) { if (p < s.length())
/* 462 */       { char c = s.charAt(p);
/* 463 */         if ('0' <= c && c <= '9')
/* 464 */         { ans = 16.0D * ans + (s.charAt(p) - 48); }
/* 465 */         else if ('a' <= c && c <= 'f')
/* 466 */         { ans = 16.0D * ans + (s.charAt(p) - 97 + 10); }
/* 467 */         else if ('A' <= c && c <= 'F')
/* 468 */         { ans = 16.0D * ans + (s.charAt(p) - 65 + 10); }
/* 469 */         else { if (c == dec) {
/* 470 */             exph = 0;
/*     */           } else {
/*     */             break;
/*     */           }  p++; }
/*     */         
/* 475 */         if (exph >= 0)
/* 476 */           exph += 4;  }
/*     */       else { break; }
/*     */        p++; }
/* 479 */      if (p < endIndex && (s.charAt(p) == 'p' || s.charAt(p) == 'P')) {
/* 480 */       int expsign = 1;
/* 481 */       double p2 = 2.0D;
/* 482 */       switch (s.charAt(++p)) {
/*     */         case '-':
/* 484 */           expsign = -1;
/* 485 */           p++;
/*     */           break;
/*     */         case '+':
/* 488 */           p++; break;
/*     */       } 
/*     */       int n;
/* 491 */       for (n = 0; p < endIndex && s.charAt(p) >= '0' && s.charAt(p) <= '9'; p++) {
/* 492 */         n = n * 10 + s.charAt(p) - 48;
/*     */       }
/* 494 */       expn += expsign * n;
/* 495 */       if (exph > 0) {
/* 496 */         expn -= exph;
/*     */       }
/* 498 */       if (expn < 0) {
/* 499 */         double fac; for (n = -expn, fac = 1.0D; n != 0; n >>= 1, p2 *= p2) {
/* 500 */           if ((n & 0x1) != 0) {
/* 501 */             fac *= p2;
/*     */           }
/*     */         } 
/* 504 */         ans /= fac;
/*     */       } else {
/* 506 */         double fac; for (n = expn, fac = 1.0D; n != 0; n >>= 1, p2 *= p2) {
/* 507 */           if ((n & 0x1) != 0) fac *= p2; 
/*     */         } 
/* 509 */         ans *= fac;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 514 */     if (p < endIndex) {
/* 515 */       ans = DoubleVector.NA;
/* 516 */       p = 0;
/* 517 */       return sign * ans;
/*     */     } 
/*     */     
/* 520 */     return sign * ans;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double doubleValue(boolean isNegative, int decExponent, char[] digits, int nDigits) {
/* 540 */     int kDigits = Math.min(nDigits, 16);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 545 */     int iValue = digits[0] - 48;
/* 546 */     int iDigits = Math.min(kDigits, 9);
/* 547 */     for (int i = 1; i < iDigits; i++) {
/* 548 */       iValue = iValue * 10 + digits[i] - 48;
/*     */     }
/* 550 */     long lValue = iValue;
/* 551 */     for (int j = iDigits; j < kDigits; j++) {
/* 552 */       lValue = lValue * 10L + (digits[j] - 48);
/*     */     }
/* 554 */     double dValue = lValue;
/* 555 */     int exp = decExponent - kDigits;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 562 */     if (nDigits <= 15) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 573 */       if (exp == 0 || dValue == 0.0D) {
/* 574 */         return isNegative ? -dValue : dValue;
/*     */       }
/* 576 */       if (exp >= 0) {
/* 577 */         if (exp <= MAX_SMALL_TEN) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 582 */           double rValue = dValue * SMALL_10_POW[exp];
/* 583 */           return isNegative ? -rValue : rValue;
/*     */         } 
/* 585 */         int slop = 15 - kDigits;
/* 586 */         if (exp <= MAX_SMALL_TEN + slop)
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 593 */           dValue *= SMALL_10_POW[slop];
/* 594 */           double rValue = dValue * SMALL_10_POW[exp - slop];
/* 595 */           return isNegative ? -rValue : rValue;
/*     */         
/*     */         }
/*     */ 
/*     */       
/*     */       }
/* 601 */       else if (exp >= -MAX_SMALL_TEN) {
/*     */ 
/*     */ 
/*     */         
/* 605 */         double rValue = dValue / SMALL_10_POW[-exp];
/* 606 */         return isNegative ? -rValue : rValue;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 622 */     if (exp > 0) {
/* 623 */       if (decExponent > 309)
/*     */       {
/*     */ 
/*     */ 
/*     */         
/* 628 */         return isNegative ? Double.NEGATIVE_INFINITY : Double.POSITIVE_INFINITY;
/*     */       }
/* 630 */       if ((exp & 0xF) != 0) {
/* 631 */         dValue *= SMALL_10_POW[exp & 0xF];
/*     */       }
/* 633 */       if ((exp >>= 4) != 0) {
/*     */         int k;
/* 635 */         for (k = 0; exp > 1; k++, exp >>= 1) {
/* 636 */           if ((exp & 0x1) != 0) {
/* 637 */             dValue *= BIG_10_POW[k];
/*     */           }
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 646 */         double t = dValue * BIG_10_POW[k];
/* 647 */         if (Double.isInfinite(t)) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 660 */           t = dValue / 2.0D;
/* 661 */           t *= BIG_10_POW[k];
/* 662 */           if (Double.isInfinite(t)) {
/* 663 */             return isNegative ? Double.NEGATIVE_INFINITY : Double.POSITIVE_INFINITY;
/*     */           }
/* 665 */           t = Double.MAX_VALUE;
/*     */         } 
/* 667 */         dValue = t;
/*     */       } 
/* 669 */     } else if (exp < 0) {
/* 670 */       exp = -exp;
/* 671 */       if (decExponent < -325)
/*     */       {
/*     */ 
/*     */ 
/*     */         
/* 676 */         return isNegative ? -0.0D : 0.0D;
/*     */       }
/* 678 */       if ((exp & 0xF) != 0) {
/* 679 */         dValue /= SMALL_10_POW[exp & 0xF];
/*     */       }
/* 681 */       if ((exp >>= 4) != 0) {
/*     */         int k;
/* 683 */         for (k = 0; exp > 1; k++, exp >>= 1) {
/* 684 */           if ((exp & 0x1) != 0) {
/* 685 */             dValue *= TINY_10_POW[k];
/*     */           }
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 694 */         double t = dValue * TINY_10_POW[k];
/* 695 */         if (t == 0.0D) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 708 */           t = dValue * 2.0D;
/* 709 */           t *= TINY_10_POW[k];
/* 710 */           if (t == 0.0D) {
/* 711 */             return isNegative ? -0.0D : 0.0D;
/*     */           }
/* 713 */           t = Double.MIN_VALUE;
/*     */         } 
/* 715 */         dValue = t;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 726 */     if (nDigits > 1100) {
/* 727 */       nDigits = 1101;
/* 728 */       digits[1100] = '1';
/*     */     } 
/* 730 */     FDBigInteger bigD0 = new FDBigInteger(lValue, digits, kDigits, nDigits);
/* 731 */     exp = decExponent - nDigits;
/*     */     
/* 733 */     long ieeeBits = Double.doubleToRawLongBits(dValue);
/* 734 */     int B5 = Math.max(0, -exp);
/* 735 */     int D5 = Math.max(0, exp);
/* 736 */     bigD0 = bigD0.multByPow52(D5, 0);
/* 737 */     bigD0.makeImmutable();
/* 738 */     FDBigInteger bigD = null;
/* 739 */     int prevD2 = 0;
/*     */     do {
/*     */       int hulpbias;
/*     */       FDBigInteger diff;
/*     */       boolean overvalue;
/* 744 */       int binexp = (int)(ieeeBits >>> 52L);
/* 745 */       long bigBbits = ieeeBits & 0xFFFFFFFFFFFFFL;
/* 746 */       if (binexp > 0) {
/* 747 */         bigBbits |= 0x10000000000000L;
/*     */       } else {
/* 749 */         assert bigBbits != 0L : bigBbits;
/* 750 */         int leadingZeros = Long.numberOfLeadingZeros(bigBbits);
/* 751 */         int shift = leadingZeros - 11;
/* 752 */         bigBbits <<= shift;
/* 753 */         binexp = 1 - shift;
/*     */       } 
/* 755 */       binexp -= 1023;
/* 756 */       int lowOrderZeros = Long.numberOfTrailingZeros(bigBbits);
/* 757 */       bigBbits >>>= lowOrderZeros;
/* 758 */       int bigIntExp = binexp - 52 + lowOrderZeros;
/* 759 */       int bigIntNBits = 53 - lowOrderZeros;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 770 */       int B2 = B5;
/* 771 */       int D2 = D5;
/*     */       
/* 773 */       if (bigIntExp >= 0) {
/* 774 */         B2 += bigIntExp;
/*     */       } else {
/* 776 */         D2 -= bigIntExp;
/*     */       } 
/* 778 */       int Ulp2 = B2;
/*     */ 
/*     */ 
/*     */       
/* 782 */       if (binexp <= -1023) {
/*     */ 
/*     */ 
/*     */         
/* 786 */         hulpbias = binexp + lowOrderZeros + 1023;
/*     */       } else {
/* 788 */         hulpbias = 1 + lowOrderZeros;
/*     */       } 
/* 790 */       B2 += hulpbias;
/* 791 */       D2 += hulpbias;
/*     */ 
/*     */       
/* 794 */       int common2 = Math.min(B2, Math.min(D2, Ulp2));
/* 795 */       B2 -= common2;
/* 796 */       D2 -= common2;
/* 797 */       Ulp2 -= common2;
/*     */       
/* 799 */       FDBigInteger bigB = FDBigInteger.valueOfMulPow52(bigBbits, B5, B2);
/* 800 */       if (bigD == null || prevD2 != D2) {
/* 801 */         bigD = bigD0.leftShift(D2);
/* 802 */         prevD2 = D2;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       int cmpResult;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 821 */       if ((cmpResult = bigB.cmp(bigD)) > 0) {
/* 822 */         overvalue = true;
/* 823 */         diff = bigB.leftInplaceSub(bigD);
/* 824 */         if (bigIntNBits == 1 && bigIntExp > -1022) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 829 */           Ulp2--;
/* 830 */           if (Ulp2 < 0) {
/*     */ 
/*     */             
/* 833 */             Ulp2 = 0;
/* 834 */             diff = diff.leftShift(1);
/*     */           } 
/*     */         } 
/* 837 */       } else if (cmpResult < 0) {
/* 838 */         overvalue = false;
/* 839 */         diff = bigD.rightInplaceSub(bigB);
/*     */       } else {
/*     */         break;
/*     */       } 
/*     */ 
/*     */       
/* 845 */       cmpResult = diff.cmpPow52(B5, Ulp2);
/* 846 */       if (cmpResult < 0) {
/*     */         break;
/*     */       }
/*     */       
/* 850 */       if (cmpResult == 0) {
/*     */ 
/*     */         
/* 853 */         if ((ieeeBits & 0x1L) != 0L) {
/* 854 */           ieeeBits += overvalue ? -1L : 1L;
/*     */         }
/*     */ 
/*     */         
/*     */         break;
/*     */       } 
/*     */ 
/*     */       
/* 862 */       ieeeBits += overvalue ? -1L : 1L;
/* 863 */     } while (ieeeBits != 0L && ieeeBits != 9218868437227405312L);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 870 */     if (isNegative) {
/* 871 */       ieeeBits |= Long.MIN_VALUE;
/*     */     }
/* 873 */     return Double.longBitsToDouble(ieeeBits);
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean equalsIgnoringCase(CharSequence s, int start, int endIndex, String word) {
/* 878 */     int lenRemaining = endIndex - start;
/* 879 */     int wordLen = word.length();
/* 880 */     if (lenRemaining != wordLen) {
/* 881 */       return false;
/*     */     }
/* 883 */     for (int i = 0; i < wordLen; i++) {
/* 884 */       if (Character.toUpperCase(s.charAt(start + i)) != word.charAt(i)) {
/* 885 */         return false;
/*     */       }
/*     */     } 
/* 888 */     return true;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/parser/NumericLiterals.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */