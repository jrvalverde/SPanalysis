/*    */ package org.renjin.primitives.special;
/*    */ 
/*    */ import org.renjin.eval.Context;
/*    */ import org.renjin.sexp.Environment;
/*    */ import org.renjin.sexp.FunctionCall;
/*    */ import org.renjin.sexp.Null;
/*    */ import org.renjin.sexp.PairList;
/*    */ import org.renjin.sexp.SEXP;
/*    */ import org.renjin.sexp.SpecialFunction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BeginFunction
/*    */   extends SpecialFunction
/*    */ {
/*    */   public BeginFunction() {
/* 27 */     super("{");
/*    */   }
/*    */   
/*    */   public SEXP apply(Context context, Environment rho, FunctionCall call, PairList args) {
/*    */     SEXP sEXP;
/* 32 */     if (args == Null.INSTANCE) {
/* 33 */       context.setInvisibleFlag();
/* 34 */       return (SEXP)Null.INSTANCE;
/*    */     } 
/* 36 */     Null null = Null.INSTANCE;
/* 37 */     for (SEXP sexp : call.getArguments().values()) {
/* 38 */       sEXP = context.evaluate(sexp, rho);
/*    */     }
/* 40 */     return sEXP;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/special/BeginFunction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */