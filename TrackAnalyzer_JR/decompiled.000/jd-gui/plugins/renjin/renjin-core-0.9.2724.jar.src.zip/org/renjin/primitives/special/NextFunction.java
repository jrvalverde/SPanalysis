/*    */ package org.renjin.primitives.special;
/*    */ 
/*    */ import org.renjin.eval.Context;
/*    */ import org.renjin.sexp.Environment;
/*    */ import org.renjin.sexp.FunctionCall;
/*    */ import org.renjin.sexp.PairList;
/*    */ import org.renjin.sexp.SEXP;
/*    */ import org.renjin.sexp.SpecialFunction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NextFunction
/*    */   extends SpecialFunction
/*    */ {
/*    */   public NextFunction() {
/* 27 */     super("next");
/*    */   }
/*    */ 
/*    */   
/*    */   public SEXP apply(Context context, Environment rho, FunctionCall call, PairList args) {
/* 32 */     throw NextException.INSTANCE;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/special/NextFunction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */