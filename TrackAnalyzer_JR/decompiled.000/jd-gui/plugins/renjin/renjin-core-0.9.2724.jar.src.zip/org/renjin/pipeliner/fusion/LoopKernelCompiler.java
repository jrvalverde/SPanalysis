/*     */ package org.renjin.pipeliner.fusion;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import java.util.concurrent.Callable;
/*     */ import org.renjin.compiler.JitClassLoader;
/*     */ import org.renjin.pipeliner.ComputeMethod;
/*     */ import org.renjin.pipeliner.VectorPipeliner;
/*     */ import org.renjin.pipeliner.fusion.kernel.CompiledKernel;
/*     */ import org.renjin.pipeliner.fusion.kernel.LoopKernel;
/*     */ import org.renjin.pipeliner.fusion.node.LoopNode;
/*     */ import org.renjin.repackaged.asm.ClassVisitor;
/*     */ import org.renjin.repackaged.asm.ClassWriter;
/*     */ import org.renjin.repackaged.asm.MethodVisitor;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ import org.renjin.repackaged.asm.tree.MethodNode;
/*     */ import org.renjin.repackaged.asm.util.Printer;
/*     */ import org.renjin.repackaged.asm.util.Textifier;
/*     */ import org.renjin.repackaged.asm.util.TraceMethodVisitor;
/*     */ import org.renjin.repackaged.guava.io.Files;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LoopKernelCompiler
/*     */   implements Callable<CompiledKernel>
/*     */ {
/*  77 */   public static final boolean DEBUG = (System.getProperty("renjin.vp.jit.debug") != null);
/*     */   
/*  79 */   private static final String KERNEL_INTERFACE = Type.getInternalName(CompiledKernel.class);
/*     */   
/*     */   private final LoopKernel kernel;
/*     */   
/*     */   private final LoopNode[] operands;
/*     */   private String className;
/*     */   private ClassVisitor cv;
/*     */   
/*     */   public LoopKernelCompiler(LoopKernel kernel, LoopNode[] operands) {
/*  88 */     this.kernel = kernel;
/*  89 */     this.operands = operands;
/*  90 */     this.className = "Jit" + System.identityHashCode(this);
/*     */   }
/*     */   
/*     */   public CompiledKernel call() {
/*  94 */     long startTime = System.nanoTime();
/*  95 */     ClassWriter cw = new ClassWriter(3);
/*  96 */     this.cv = (ClassVisitor)cw;
/*  97 */     this.cv.visit(50, 33, this.className, null, "java/lang/Object", new String[] { KERNEL_INTERFACE });
/*     */     
/*  99 */     writeConstructor();
/* 100 */     if (DEBUG) {
/* 101 */       writeComputeDebug(this.kernel, this.operands);
/*     */     } else {
/* 103 */       writeCompute(this.kernel, this.operands);
/*     */     } 
/* 105 */     this.cv.visitEnd();
/*     */     
/* 107 */     byte[] classBytes = cw.toByteArray();
/* 108 */     long compileTime = System.nanoTime() - startTime;
/*     */     
/* 110 */     Class<CompiledKernel> jitClass = JitClassLoader.defineClass(CompiledKernel.class, this.className, classBytes);
/*     */     
/* 112 */     long loadTime = System.nanoTime() - startTime - compileTime;
/*     */     
/* 114 */     if (VectorPipeliner.DEBUG) {
/* 115 */       System.out.println(this.className + ": compile: " + (compileTime / 1000000.0D) + "ms");
/* 116 */       System.out.println(this.className + ": load: " + (loadTime / 1000000.0D) + "ms");
/* 117 */       if (DEBUG) {
/*     */         try {
/* 119 */           File classFile = File.createTempFile("Specialization", ".class");
/* 120 */           Files.write(classBytes, classFile);
/* 121 */           System.out.println("Wrote class file to " + classFile);
/* 122 */         } catch (Exception e) {
/* 123 */           e.printStackTrace();
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/*     */     try {
/* 129 */       return jitClass.newInstance();
/* 130 */     } catch (Exception e) {
/* 131 */       throw new RuntimeException("Could not invoke jitted computation", e);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void writeConstructor() {
/* 136 */     MethodVisitor mv = this.cv.visitMethod(1, "<init>", "()V", null, null);
/* 137 */     mv.visitCode();
/* 138 */     mv.visitVarInsn(25, 0);
/* 139 */     mv.visitMethodInsn(183, "java/lang/Object", "<init>", "()V", false);
/* 140 */     mv.visitInsn(177);
/* 141 */     mv.visitMaxs(1, 1);
/* 142 */     mv.visitEnd();
/*     */   }
/*     */   
/*     */   private void writeCompute(LoopKernel kernel, LoopNode[] operands) {
/* 146 */     String typeDescriptor = "([Lorg/renjin/sexp/Vector;)[D";
/*     */     
/* 148 */     MethodVisitor mv = this.cv.visitMethod(1, "compute", typeDescriptor, null, null);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 153 */     ComputeMethod methodContext = new ComputeMethod(mv);
/*     */     
/* 155 */     kernel.compute(methodContext, operands);
/*     */     
/* 157 */     mv.visitMaxs(1, methodContext.getMaxLocals());
/* 158 */     mv.visitEnd();
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeComputeDebug(LoopKernel kernel, LoopNode[] operands) {
/* 163 */     MethodNode mv = new MethodNode(1, "compute", "([Lorg/renjin/sexp/Vector;)[D", null, null);
/* 164 */     mv.visitCode();
/*     */     
/* 166 */     ComputeMethod methodContext = new ComputeMethod((MethodVisitor)mv);
/*     */     
/* 168 */     kernel.compute(methodContext, operands);
/*     */     
/* 170 */     mv.visitMaxs(1, methodContext.getMaxLocals());
/* 171 */     mv.visitEnd();
/*     */     
/*     */     try {
/* 174 */       mv.accept(this.cv);
/*     */       
/* 176 */       if (DEBUG) {
/* 177 */         System.out.println(toString(mv));
/*     */       }
/*     */     }
/* 180 */     catch (Exception e) {
/* 181 */       throw new RuntimeException("Toxic bytecode generated: " + toString(mv), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private String toString(MethodNode methodNode) {
/*     */     try {
/* 188 */       Textifier p = new Textifier();
/* 189 */       methodNode.accept((MethodVisitor)new TraceMethodVisitor((Printer)p));
/* 190 */       StringWriter sw = new StringWriter();
/* 191 */       try (PrintWriter pw = new PrintWriter(sw)) {
/* 192 */         p.print(pw);
/*     */       } 
/* 194 */       return sw.toString();
/* 195 */     } catch (Exception e) {
/* 196 */       return "<Exception generating bytecode: " + e.getClass().getName() + ": " + e.getMessage() + ">";
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/pipeliner/fusion/LoopKernelCompiler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */