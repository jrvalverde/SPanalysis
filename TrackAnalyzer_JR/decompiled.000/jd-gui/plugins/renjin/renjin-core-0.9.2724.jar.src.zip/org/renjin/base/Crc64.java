/*    */ package org.renjin.base;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Crc64
/*    */ {
/* 23 */   private static long[] _crc64Array = new long[256];
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static {
/* 30 */     for (int i = 0; i <= 255; i++) {
/* 31 */       long k = i;
/* 32 */       for (int j = 0; j < 8; j++) {
/* 33 */         if ((k & 0x1L) != 0L) {
/* 34 */           k = k >>> 1L ^ 0xD800000000000000L;
/*    */         } else {
/*    */           
/* 37 */           k >>>= 1L;
/*    */         } 
/*    */       } 
/* 40 */       _crc64Array[i] = k;
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static String getCrc64(String sequence) {
/* 52 */     long crc64Number = 0L;
/* 53 */     for (int i = 0; i < sequence.length(); i++) {
/* 54 */       char symbol = sequence.charAt(i);
/* 55 */       long a = crc64Number >>> 8L;
/* 56 */       long b = (crc64Number ^ symbol) & 0xFFL;
/* 57 */       crc64Number = a ^ _crc64Array[(int)b];
/*    */     } 
/*    */     
/* 60 */     String crc64String = Long.toHexString(crc64Number).toUpperCase();
/* 61 */     StringBuffer crc64 = new StringBuffer("0000000000000000");
/* 62 */     crc64.replace(crc64.length() - crc64String.length(), crc64
/* 63 */         .length(), crc64String);
/*    */ 
/*    */     
/* 66 */     return crc64.toString();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/base/Crc64.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */