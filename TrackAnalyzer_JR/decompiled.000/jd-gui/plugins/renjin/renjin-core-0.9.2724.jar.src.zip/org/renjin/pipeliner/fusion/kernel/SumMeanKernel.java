/*     */ package org.renjin.pipeliner.fusion.kernel;
/*     */ 
/*     */ import org.renjin.pipeliner.ComputeMethod;
/*     */ import org.renjin.pipeliner.fusion.node.LoopNode;
/*     */ import org.renjin.repackaged.asm.Label;
/*     */ import org.renjin.repackaged.asm.MethodVisitor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SumMeanKernel
/*     */   implements LoopKernel
/*     */ {
/*     */   private boolean mean;
/*     */   
/*     */   private SumMeanKernel(boolean mean) {
/*  33 */     this.mean = mean;
/*     */   }
/*     */   
/*     */   public static SumMeanKernel mean() {
/*  37 */     return new SumMeanKernel(true);
/*     */   }
/*     */   
/*     */   public static SumMeanKernel sum() {
/*  41 */     return new SumMeanKernel(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void compute(ComputeMethod method, LoopNode[] operands) {
/*  48 */     MethodVisitor mv = method.getVisitor();
/*     */     
/*  50 */     LoopNode vector = operands[0];
/*  51 */     vector.init(method);
/*     */ 
/*     */     
/*  54 */     int lengthLocal = method.reserveLocal(1);
/*  55 */     vector.pushLength(method);
/*  56 */     mv.visitVarInsn(54, lengthLocal);
/*     */ 
/*     */     
/*  59 */     int sumLocal = method.reserveLocal(2);
/*  60 */     mv.visitInsn(14);
/*  61 */     mv.visitVarInsn(57, sumLocal);
/*     */     
/*  63 */     int counterLocal = method.reserveLocal(1);
/*  64 */     mv.visitInsn(3);
/*  65 */     mv.visitVarInsn(54, counterLocal);
/*     */     
/*  67 */     Label l3 = new Label();
/*  68 */     mv.visitLabel(l3);
/*  69 */     mv.visitVarInsn(21, counterLocal);
/*  70 */     mv.visitVarInsn(21, lengthLocal);
/*     */     
/*  72 */     Label l4 = new Label();
/*  73 */     mv.visitJumpInsn(159, l4);
/*     */     
/*  75 */     Label l5 = new Label();
/*  76 */     mv.visitLabel(l5);
/*     */ 
/*     */     
/*  79 */     mv.visitVarInsn(24, sumLocal);
/*  80 */     mv.visitVarInsn(21, counterLocal);
/*  81 */     vector.pushElementAsDouble(method);
/*     */ 
/*     */     
/*  84 */     mv.visitInsn(99);
/*  85 */     mv.visitVarInsn(57, sumLocal);
/*     */     
/*  87 */     Label l6 = new Label();
/*  88 */     mv.visitLabel(l6);
/*  89 */     mv.visitIincInsn(counterLocal, 1);
/*  90 */     mv.visitJumpInsn(167, l3);
/*  91 */     mv.visitLabel(l4);
/*     */ 
/*     */     
/*  94 */     mv.visitInsn(4);
/*  95 */     mv.visitIntInsn(188, 7);
/*  96 */     mv.visitInsn(89);
/*  97 */     mv.visitInsn(3);
/*  98 */     mv.visitVarInsn(24, sumLocal);
/*     */     
/* 100 */     if (this.mean) {
/* 101 */       mv.visitVarInsn(21, lengthLocal);
/* 102 */       mv.visitInsn(135);
/* 103 */       mv.visitInsn(111);
/*     */     } 
/*     */     
/* 106 */     mv.visitInsn(82);
/* 107 */     mv.visitInsn(176);
/*     */   }
/*     */ 
/*     */   
/*     */   public String debugLabel(LoopNode[] operands) {
/* 112 */     return (this.mean ? "mean" : "sum") + "(...)";
/*     */   }
/*     */ 
/*     */   
/*     */   public void appendToKey(StringBuilder key) {
/* 117 */     key.append(this.mean ? "mean" : "sum");
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/pipeliner/fusion/kernel/SumMeanKernel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */