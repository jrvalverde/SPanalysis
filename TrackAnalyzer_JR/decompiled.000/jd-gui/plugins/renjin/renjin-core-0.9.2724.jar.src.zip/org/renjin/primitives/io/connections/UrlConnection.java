/*     */ package org.renjin.primitives.io.connections;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.net.URL;
/*     */ import java.nio.charset.Charset;
/*     */ import org.renjin.eval.EvalException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UrlConnection
/*     */   extends AbstractConnection
/*     */ {
/*     */   private final URL url;
/*     */   private InputStream in;
/*  36 */   private OpenSpec openSpec = new OpenSpec("r");
/*     */   
/*     */   public UrlConnection(URL url) {
/*  39 */     this.url = url;
/*     */   }
/*     */   
/*     */   public UrlConnection(URL url, Charset charset) {
/*  43 */     super(charset);
/*  44 */     this.url = url;
/*     */   }
/*     */ 
/*     */   
/*     */   public void open(OpenSpec spec) throws IOException {
/*  49 */     this.openSpec = spec;
/*  50 */     if (spec.forWriting()) {
/*  51 */       throw new EvalException("Cannot open url connection for writing", new Object[0]);
/*     */     }
/*  53 */     if (spec.isText()) {
/*  54 */       getReader();
/*     */     } else {
/*  56 */       getInputStream();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InputStream getInputStream() throws IOException {
/*  64 */     if (this.in == null) {
/*  65 */       this.in = this.url.openStream();
/*     */     }
/*  67 */     return this.in;
/*     */   }
/*     */ 
/*     */   
/*     */   public OutputStream getOutputStream() throws IOException {
/*  72 */     throw new EvalException("Cannot open URL for output", new Object[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isOpen() {
/*  77 */     return (this.in != null);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void closeInputIfOpen() throws IOException {
/*  82 */     this.in.close();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void closeOutputIfOpen() throws IOException {}
/*     */ 
/*     */   
/*     */   public String getClassName() {
/*  91 */     return "url";
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canRead() {
/*  96 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canWrite() {
/* 101 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDescription() {
/* 106 */     return this.url.toExternalForm();
/*     */   }
/*     */ 
/*     */   
/*     */   public Connection.Type getType() {
/* 111 */     return this.openSpec.getType();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/io/connections/UrlConnection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */