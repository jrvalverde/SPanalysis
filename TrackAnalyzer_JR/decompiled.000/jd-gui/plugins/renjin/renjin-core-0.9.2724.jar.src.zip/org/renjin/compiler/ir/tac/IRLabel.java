/*    */ package org.renjin.compiler.ir.tac;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IRLabel
/*    */ {
/* 23 */   public static final IRLabel EXIT = new IRLabel(2147483647);
/*    */   
/*    */   private final int index;
/*    */   
/*    */   public IRLabel(int index) {
/* 28 */     this.index = index;
/*    */   }
/*    */   
/*    */   public int getIndex() {
/* 32 */     return this.index;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 37 */     return "L" + this.index;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 42 */     int prime = 31;
/* 43 */     int result = 1;
/* 44 */     result = 31 * result + this.index;
/* 45 */     return result;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 50 */     if (this == obj) {
/* 51 */       return true;
/*    */     }
/* 53 */     if (obj == null) {
/* 54 */       return false;
/*    */     }
/* 56 */     if (getClass() != obj.getClass()) {
/* 57 */       return false;
/*    */     }
/* 59 */     IRLabel other = (IRLabel)obj;
/* 60 */     if (this.index != other.index) {
/* 61 */       return false;
/*    */     }
/* 63 */     return true;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/ir/tac/IRLabel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */