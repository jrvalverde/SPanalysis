/*     */ package org.renjin.primitives.combine;
/*     */ 
/*     */ import org.renjin.primitives.combine.view.PrefixedNameVector;
/*     */ import org.renjin.primitives.sequence.RepStringVector;
/*     */ import org.renjin.sexp.AtomicVector;
/*     */ import org.renjin.sexp.AttributeMap;
/*     */ import org.renjin.sexp.ListVector;
/*     */ import org.renjin.sexp.StringVector;
/*     */ import org.renjin.sexp.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CombinedNames
/*     */ {
/*     */   public static final String EMPTY = "";
/*     */   
/*     */   public static StringVector combine(String prefix, Vector vector) {
/*     */     StringVector names;
/*  40 */     boolean numberUnnamedElements, hasNames = vector.getAttributes().hasNames();
/*     */     
/*  42 */     if (hasNames) {
/*  43 */       names = (StringVector)vector.getNames();
/*     */     } else {
/*  45 */       names = RepStringVector.createConstantVector("", vector.length());
/*     */     } 
/*     */ 
/*     */     
/*  49 */     if (!isPresent(prefix)) {
/*  50 */       return names;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  56 */     if (vector instanceof ListVector) {
/*  57 */       numberUnnamedElements = (countUnnamedElements((ListVector)vector) > 1);
/*     */     } else {
/*  59 */       numberUnnamedElements = (vector.length() > 1);
/*     */     } 
/*  61 */     return (StringVector)new PrefixedNameVector(prefix, (AtomicVector)names, numberUnnamedElements, AttributeMap.EMPTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toString(String name) {
/*  70 */     if (StringVector.isNA(name)) {
/*  71 */       return "NA";
/*     */     }
/*  73 */     return name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isPresent(String name) {
/*  82 */     return (name == null || name.length() > 0);
/*     */   }
/*     */   
/*     */   public static int countUnnamedElements(ListVector list) {
/*  86 */     if (!list.getAttributes().hasNames()) {
/*  87 */       return list.length();
/*     */     }
/*     */     
/*  90 */     int count = 0;
/*  91 */     StringVector names = (StringVector)list.getNames();
/*  92 */     for (int i = 0; i < names.length(); i++) {
/*  93 */       if (!isPresent(names.getElementAsString(i))) {
/*  94 */         count++;
/*     */       }
/*     */     } 
/*  97 */     return count;
/*     */   }
/*     */   
/*     */   public static boolean hasNames(String prefix, Vector value) {
/* 101 */     return (isPresent(prefix) || value.getAttributes().hasNames());
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/combine/CombinedNames.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */