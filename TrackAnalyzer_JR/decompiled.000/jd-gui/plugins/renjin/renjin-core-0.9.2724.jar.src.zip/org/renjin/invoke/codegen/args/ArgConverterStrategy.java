/*    */ package org.renjin.invoke.codegen.args;
/*    */ 
/*    */ import com.sun.codemodel.JCodeModel;
/*    */ import com.sun.codemodel.JExpression;
/*    */ import com.sun.codemodel.JVar;
/*    */ import org.renjin.invoke.codegen.ApplyMethodContext;
/*    */ import org.renjin.invoke.model.JvmMethod;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ArgConverterStrategy
/*    */ {
/*    */   protected final JvmMethod.Argument formal;
/*    */   
/*    */   public ArgConverterStrategy(JvmMethod.Argument formal) {
/* 42 */     this.formal = formal;
/*    */   }
/*    */   
/*    */   public abstract JExpression getTestExpr(JCodeModel paramJCodeModel, JVar paramJVar);
/*    */   
/*    */   public abstract JExpression convertArgument(ApplyMethodContext paramApplyMethodContext, JExpression paramJExpression);
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/codegen/args/ArgConverterStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */