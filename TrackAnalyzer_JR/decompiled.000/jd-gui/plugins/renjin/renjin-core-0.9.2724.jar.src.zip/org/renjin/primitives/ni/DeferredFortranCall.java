/*     */ package org.renjin.primitives.ni;
/*     */ 
/*     */ import java.lang.invoke.MethodHandle;
/*     */ import org.renjin.eval.EvalException;
/*     */ import org.renjin.gcc.runtime.BooleanPtr;
/*     */ import org.renjin.gcc.runtime.DoublePtr;
/*     */ import org.renjin.gcc.runtime.IntPtr;
/*     */ import org.renjin.sexp.AtomicVector;
/*     */ import org.renjin.sexp.ListVector;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DeferredFortranCall
/*     */   implements DeferredNativeCall
/*     */ {
/*     */   private String methodName;
/*     */   private final MethodHandle method;
/*     */   private final Class<?>[] parameterType;
/*     */   private final Vector[] operands;
/*     */   private final Object[] outputArrays;
/*     */   private final ListVector outputList;
/*     */   private boolean inputsDeferred = false;
/*     */   private boolean evaluated = false;
/*     */   
/*     */   public DeferredFortranCall(String methodName, MethodHandle method, ListVector inputs) {
/*  53 */     this.methodName = methodName;
/*  54 */     this.method = method;
/*     */     
/*  56 */     this.parameterType = method.type().parameterArray();
/*  57 */     if (this.parameterType.length != inputs.length()) {
/*  58 */       throw new EvalException("Invalid number of args", new Object[0]);
/*     */     }
/*     */     
/*  61 */     this.operands = new Vector[inputs.length()];
/*  62 */     this.outputArrays = new Object[inputs.length()];
/*     */ 
/*     */ 
/*     */     
/*  66 */     ListVector.NamedBuilder outputList = new ListVector.NamedBuilder();
/*  67 */     for (int i = 0; i != inputs.length(); i++) {
/*  68 */       AtomicVector vector = (AtomicVector)inputs.get(i);
/*     */       
/*  70 */       this.operands[i] = (Vector)vector;
/*     */       
/*  72 */       if (vector.isDeferred()) {
/*  73 */         this.inputsDeferred = true;
/*     */       }
/*     */       
/*  76 */       if (this.parameterType[i].equals(DoublePtr.class)) {
/*  77 */         outputList.add(inputs.getName(i), (SEXP)new NativeOutputDoubleVector(this, i, vector.length(), vector.getAttributes()));
/*     */       }
/*  79 */       else if (this.parameterType[i].equals(IntPtr.class)) {
/*  80 */         outputList.add(inputs.getName(i), (SEXP)new NativeOutputIntVector(this, i, vector.length(), vector.getAttributes()));
/*     */       }
/*  82 */       else if (this.parameterType[i].equals(BooleanPtr.class)) {
/*  83 */         outputList.add(inputs.getName(i), (SEXP)new NativeOutputBoolVector(this, i, vector.length(), vector.getAttributes()));
/*     */       } else {
/*     */         
/*  86 */         throw new UnsupportedOperationException("fortran type: " + this.parameterType[i]);
/*     */       } 
/*     */     } 
/*  89 */     this.outputList = outputList.build();
/*     */   }
/*     */ 
/*     */   
/*     */   public Vector[] getOperands() {
/*  94 */     return this.operands;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getOutputName(int outputIndex) {
/*  99 */     return this.outputList.getNames().getElementAsString(outputIndex);
/*     */   }
/*     */   
/*     */   public boolean isEvaluated() {
/* 103 */     return this.evaluated;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object output(int outputIndex) {
/* 108 */     if (!this.evaluated) {
/* 109 */       throw new IllegalStateException("Not evaluated yet.");
/*     */     }
/* 111 */     return this.outputArrays[outputIndex];
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDebugName() {
/* 116 */     return this.methodName;
/*     */   }
/*     */   
/*     */   public ListVector getOutputList() {
/* 120 */     return this.outputList;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void evaluate(Vector[] operands) {
/* 127 */     for (int i = 0; i < operands.length; i++) {
/* 128 */       AtomicVector inputVector = (AtomicVector)operands[i];
/* 129 */       if (this.parameterType[i].equals(DoublePtr.class)) {
/* 130 */         this.outputArrays[i] = inputVector.toDoubleArray();
/* 131 */       } else if (this.parameterType[i].equals(IntPtr.class)) {
/* 132 */         this.outputArrays[i] = inputVector.toIntArray();
/* 133 */       } else if (this.parameterType[i].equals(BooleanPtr.class)) {
/* 134 */         this.outputArrays[i] = toBooleanArray(inputVector);
/*     */       } else {
/* 136 */         throw new UnsupportedOperationException("parameterType: " + this.parameterType);
/*     */       } 
/*     */     } 
/* 139 */     invoke();
/*     */   }
/*     */   
/*     */   private static boolean[] toBooleanArray(AtomicVector vector) {
/* 143 */     boolean[] array = new boolean[vector.length()];
/* 144 */     for (int i = 0; i < vector.length(); i++) {
/* 145 */       int element = vector.getElementAsRawLogical(i);
/* 146 */       if (element == Integer.MIN_VALUE) {
/* 147 */         throw new EvalException("NAs cannot be passed to logical fortran argument", new Object[0]);
/*     */       }
/* 149 */       array[i] = (element != 0);
/*     */     } 
/* 151 */     return array;
/*     */   }
/*     */ 
/*     */   
/*     */   private void invoke() {
/* 156 */     Object[] fortranArgs = new Object[this.operands.length];
/* 157 */     for (int i = 0; i < this.operands.length; i++) {
/* 158 */       if (this.parameterType[i].equals(DoublePtr.class)) {
/* 159 */         fortranArgs[i] = new DoublePtr((double[])this.outputArrays[i]);
/* 160 */       } else if (this.parameterType[i].equals(IntPtr.class)) {
/* 161 */         fortranArgs[i] = new IntPtr((int[])this.outputArrays[i]);
/* 162 */       } else if (this.parameterType[i].equals(BooleanPtr.class)) {
/* 163 */         fortranArgs[i] = new BooleanPtr((boolean[])this.outputArrays[i]);
/*     */       } else {
/* 165 */         throw new UnsupportedOperationException("parameterType: " + this.parameterType[i]);
/*     */       } 
/*     */     } 
/*     */     
/*     */     try {
/* 170 */       this.method.invokeWithArguments(fortranArgs);
/* 171 */       this.evaluated = true;
/* 172 */     } catch (Error e) {
/* 173 */       throw e;
/* 174 */     } catch (Throwable e) {
/* 175 */       throw new EvalException("Exception thrown while executing " + this.method, e);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/ni/DeferredFortranCall.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */