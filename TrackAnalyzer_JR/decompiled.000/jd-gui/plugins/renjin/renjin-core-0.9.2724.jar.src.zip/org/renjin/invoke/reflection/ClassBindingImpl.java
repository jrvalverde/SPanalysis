/*     */ package org.renjin.invoke.reflection;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.IdentityHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.ExecutionException;
/*     */ import org.renjin.eval.Context;
/*     */ import org.renjin.eval.EvalException;
/*     */ import org.renjin.invoke.ClassBinding;
/*     */ import org.renjin.repackaged.guava.cache.Cache;
/*     */ import org.renjin.repackaged.guava.cache.CacheBuilder;
/*     */ import org.renjin.repackaged.guava.collect.ArrayListMultimap;
/*     */ import org.renjin.repackaged.guava.collect.Maps;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.Symbol;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClassBindingImpl
/*     */   implements ClassBinding
/*     */ {
/*  44 */   private static final Cache<Class, ClassBindingImpl> TABLE = CacheBuilder.newBuilder().build();
/*     */   
/*     */   public static ClassBindingImpl get(final Class clazz) {
/*     */     try {
/*  48 */       return (ClassBindingImpl)TABLE.get(clazz, new Callable<ClassBindingImpl>()
/*     */           {
/*     */             public ClassBindingImpl call() throws Exception {
/*  51 */               return new ClassBindingImpl(clazz);
/*     */             }
/*     */           });
/*  54 */     } catch (ExecutionException e) {
/*  55 */       throw new EvalException(e.getCause());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private Class clazz;
/*  61 */   private Map<String, FunctionBinding> staticMethods = Maps.newHashMap();
/*     */   
/*     */   private ConstructorBinding constructorBinding;
/*  64 */   private IdentityHashMap<Symbol, MemberBinding> members = Maps.newIdentityHashMap();
/*  65 */   private IdentityHashMap<Symbol, StaticBinding> staticMembers = Maps.newIdentityHashMap();
/*     */ 
/*     */   
/*     */   private ClassBindingImpl(Class clazz) {
/*  69 */     this.clazz = clazz;
/*     */     
/*  71 */     Map<Symbol, Method> getters = Maps.newHashMap();
/*  72 */     ArrayListMultimap arrayListMultimap1 = ArrayListMultimap.create();
/*  73 */     ArrayListMultimap arrayListMultimap2 = ArrayListMultimap.create();
/*  74 */     ArrayListMultimap arrayListMultimap3 = ArrayListMultimap.create();
/*     */ 
/*     */     
/*  77 */     for (Method method : clazz.getMethods()) {
/*  78 */       if ((method.getModifiers() & 0x1) != 0)
/*     */       {
/*  80 */         if ((method.getModifiers() & 0x8) != 0) {
/*  81 */           arrayListMultimap3.put(Symbol.get(method.getName()), method);
/*     */         } else {
/*     */           
/*  84 */           arrayListMultimap2.put(Symbol.get(method.getName()), method);
/*     */           
/*     */           String propertyName;
/*  87 */           if ((propertyName = isGetter(method)) != null) {
/*  88 */             getters.put(Symbol.get(propertyName), method);
/*  89 */           } else if ((propertyName = isSetter(method)) != null) {
/*  90 */             arrayListMultimap1.put(Symbol.get(propertyName), method);
/*     */           } 
/*     */         } 
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  99 */     for (Symbol methodName : arrayListMultimap2.keySet()) {
/* 100 */       this.members.put(methodName, new MethodBinding(methodName, new FunctionBinding(arrayListMultimap2.get(methodName))));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 105 */     for (Map.Entry<Symbol, Method> getterEntry : getters.entrySet()) {
/*     */       
/* 107 */       Symbol propertySymbol = getterEntry.getKey();
/* 108 */       if (!arrayListMultimap2.containsKey(propertySymbol)) {
/* 109 */         this.members.put(propertySymbol, new PropertyBinding(propertySymbol, getterEntry
/*     */ 
/*     */               
/* 112 */               .getValue(), arrayListMultimap1
/* 113 */               .get(propertySymbol)));
/*     */       }
/*     */     } 
/*     */     
/* 117 */     for (Symbol name : arrayListMultimap3.keySet()) {
/* 118 */       FunctionBinding functionBinding = new FunctionBinding(arrayListMultimap3.get(name));
/* 119 */       this.staticMethods.put(name.getPrintName(), functionBinding);
/* 120 */       this.staticMembers.put(name, new StaticBinding(new MethodBinding(name, functionBinding)));
/*     */     } 
/*     */     
/* 123 */     for (Field field : clazz.getFields()) {
/* 124 */       if (Modifier.isPublic(field.getModifiers()) && 
/* 125 */         Modifier.isStatic(field.getModifiers())) {
/* 126 */         Symbol name = Symbol.get(field.getName());
/* 127 */         this.staticMembers.put(name, new StaticBinding(new FieldBinding(field)));
/*     */       } 
/*     */     } 
/*     */     
/* 131 */     this.constructorBinding = new ConstructorBinding((Constructor[])clazz.getConstructors());
/*     */   }
/*     */ 
/*     */   
/*     */   private String isGetter(Method method) {
/* 136 */     if ((method.getParameterTypes()).length != 0) {
/* 137 */       return null;
/*     */     }
/*     */     
/* 140 */     String name = method.getName();
/* 141 */     if (name.startsWith("get") && name
/* 142 */       .length() > "get".length())
/*     */     {
/* 144 */       return name.substring(3, 4).toLowerCase() + name.substring(4);
/*     */     }
/*     */     
/* 147 */     if (name.startsWith("is") && name
/* 148 */       .length() > "is".length())
/*     */     {
/* 150 */       return name.substring(2, 3).toLowerCase() + name.substring(3);
/*     */     }
/*     */     
/* 153 */     return null;
/*     */   }
/*     */   
/*     */   private String isSetter(Method method) {
/* 157 */     if ((method.getParameterTypes()).length != 1) {
/* 158 */       return null;
/*     */     }
/*     */     
/* 161 */     String name = method.getName();
/* 162 */     if (name.startsWith("set") && name
/* 163 */       .length() > "set".length()) {
/* 164 */       return name.substring(3, 4).toLowerCase() + name.substring(4);
/*     */     }
/*     */     
/* 167 */     return null;
/*     */   }
/*     */   
/*     */   public Set<Symbol> getMembers() {
/* 171 */     return this.members.keySet();
/*     */   }
/*     */ 
/*     */   
/*     */   public MemberBinding getMemberBinding(Symbol name) {
/* 176 */     MemberBinding memberBinding = this.members.get(name);
/* 177 */     if (memberBinding == null)
/* 178 */       throw new EvalException("Instance of class %s has no member named '%s'", new Object[] {
/* 179 */             getBoundClass().getName(), name.getPrintName()
/*     */           }); 
/* 181 */     return memberBinding;
/*     */   }
/*     */   
/*     */   public Set<Symbol> getStaticMembers() {
/* 185 */     return this.staticMembers.keySet();
/*     */   }
/*     */   
/*     */   public StaticBinding getStaticMember(Symbol name) {
/* 189 */     return this.staticMembers.get(name);
/*     */   }
/*     */   
/*     */   public StaticBinding getStaticMember(String name) {
/* 193 */     return getStaticMember(Symbol.get(name));
/*     */   }
/*     */   
/*     */   public Object newInstance(Context context, List<SEXP> constructorArgs) {
/* 197 */     return this.constructorBinding.newInstance(context, constructorArgs);
/*     */   }
/*     */   
/*     */   public Class getBoundClass() {
/* 201 */     return this.clazz;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FunctionBinding getStaticMethodBinding(String name) {
/* 209 */     FunctionBinding functionBinding = this.staticMethods.get(name);
/* 210 */     if (functionBinding == null) {
/* 211 */       throw new IllegalArgumentException("Class " + this.clazz.getName() + " has no method named " + name);
/*     */     }
/* 213 */     return functionBinding;
/*     */   }
/*     */   
/*     */   public ConstructorBinding getConstructorBinding() {
/* 217 */     return this.constructorBinding;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/reflection/ClassBindingImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */