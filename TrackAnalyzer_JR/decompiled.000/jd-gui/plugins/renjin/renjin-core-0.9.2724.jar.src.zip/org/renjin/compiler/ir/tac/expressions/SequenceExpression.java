/*    */ package org.renjin.compiler.ir.tac.expressions;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.renjin.compiler.codegen.EmitContext;
/*    */ import org.renjin.compiler.ir.ValueBounds;
/*    */ import org.renjin.primitives.sequence.DoubleSequence;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ import org.renjin.repackaged.asm.commons.InstructionAdapter;
/*    */ import org.renjin.sexp.AtomicVector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SequenceExpression
/*    */   extends SpecializedCallExpression
/*    */ {
/*    */   private ValueBounds valueBounds;
/*    */   
/*    */   public SequenceExpression(Expression from, Expression to) {
/* 36 */     super(new Expression[] { from, to });
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isFunctionDefinitelyPure() {
/* 41 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isPure() {
/* 46 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public ValueBounds updateTypeBounds(Map<Expression, ValueBounds> typeMap) {
/* 51 */     ValueBounds fromType = childAt(0).updateTypeBounds(typeMap);
/* 52 */     ValueBounds toType = childAt(1).updateTypeBounds(typeMap);
/*    */     
/* 54 */     this
/*    */ 
/*    */       
/* 57 */       .valueBounds = ValueBounds.builder().setTypeSet(fromType.getTypeSet() | toType.getTypeSet()).setEmptyAttributes().build();
/*    */     
/* 59 */     return this.valueBounds;
/*    */   }
/*    */ 
/*    */   
/*    */   public ValueBounds getValueBounds() {
/* 64 */     return this.valueBounds;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int load(EmitContext emitContext, InstructionAdapter mv) {
/* 70 */     childAt(0).load(emitContext, mv);
/* 71 */     emitContext.convert(mv, childAt(0).getType(), Type.DOUBLE_TYPE);
/*    */     
/* 73 */     childAt(1).load(emitContext, mv);
/* 74 */     emitContext.convert(mv, childAt(1).getType(), Type.DOUBLE_TYPE);
/*    */     
/* 76 */     mv.visitMethodInsn(184, Type.getInternalName(DoubleSequence.class), "fromTo", 
/* 77 */         Type.getMethodDescriptor(Type.getType(AtomicVector.class), new Type[] { Type.DOUBLE_TYPE, Type.DOUBLE_TYPE }), false);
/*    */     
/* 79 */     return 0;
/*    */   }
/*    */ 
/*    */   
/*    */   public Type getType() {
/* 84 */     return this.valueBounds.storageType();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 90 */     return childAt(0) + ":" + childAt(1);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/ir/tac/expressions/SequenceExpression.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */