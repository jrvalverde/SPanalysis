/*    */ package org.renjin.eval;
/*    */ 
/*    */ import java.lang.ref.Reference;
/*    */ import java.lang.ref.ReferenceQueue;
/*    */ import java.lang.ref.WeakReference;
/*    */ import java.util.ArrayList;
/*    */ import java.util.HashSet;
/*    */ import java.util.List;
/*    */ import java.util.Set;
/*    */ import org.renjin.sexp.SEXP;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FinalizerRegistry
/*    */ {
/*    */   private class Finalizer
/*    */     extends WeakReference<SEXP>
/*    */   {
/*    */     private final FinalizationHandler function;
/*    */     private boolean onExit;
/*    */     
/*    */     public Finalizer(SEXP sexp, FinalizationHandler function, boolean onExit) {
/* 43 */       super(sexp, FinalizerRegistry.this.queue);
/* 44 */       this.function = function;
/* 45 */       this.onExit = onExit;
/*    */     }
/*    */     
/*    */     private void invoke(Context context) {
/* 49 */       this.function.finalizeSexp(context, get());
/*    */     }
/*    */     
/*    */     public SEXP getSexp() {
/* 53 */       SEXP e = get();
/* 54 */       if (e == null) {
/* 55 */         throw new IllegalStateException("Environment has already been garbage collected!");
/*    */       }
/* 57 */       return e;
/*    */     }
/*    */     
/*    */     public boolean isOnExit() {
/* 61 */       return this.onExit;
/*    */     }
/*    */   }
/*    */   
/* 65 */   private final ReferenceQueue<SEXP> queue = new ReferenceQueue<>();
/* 66 */   private final Set<Finalizer> finalizers = new HashSet<>();
/*    */   
/*    */   public void register(SEXP sexp, FinalizationHandler handler, boolean onExit) {
/* 69 */     this.finalizers.add(new Finalizer(sexp, handler, onExit));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void finalizeDisposedEnvironments(Context context) {
/*    */     Reference<? extends SEXP> ref;
/* 80 */     while ((ref = this.queue.poll()) != null) {
/* 81 */       Finalizer finalizer = (Finalizer)ref;
/* 82 */       this.finalizers.remove(finalizer);
/*    */       
/* 84 */       finalizer.invoke(context);
/*    */     } 
/*    */   }
/*    */   
/*    */   public void finalizeOnExit(Context context) {
/* 89 */     List<Finalizer> toInvoke = new ArrayList<>(this.finalizers);
/* 90 */     this.finalizers.clear();
/*    */     
/* 92 */     for (Finalizer finalizer : toInvoke) {
/* 93 */       if (finalizer.isOnExit())
/* 94 */         finalizer.invoke(context); 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/eval/FinalizerRegistry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */