/*    */ package org.renjin.compiler.ir.tac.functions;
/*    */ 
/*    */ import org.renjin.compiler.NotCompilableException;
/*    */ import org.renjin.compiler.ir.tac.IRBodyBuilder;
/*    */ import org.renjin.compiler.ir.tac.expressions.Expression;
/*    */ import org.renjin.compiler.ir.tac.expressions.NamedSlotAccess;
/*    */ import org.renjin.compiler.ir.tac.statements.ExprStatement;
/*    */ import org.renjin.compiler.ir.tac.statements.Statement;
/*    */ import org.renjin.sexp.Function;
/*    */ import org.renjin.sexp.FunctionCall;
/*    */ import org.renjin.sexp.SEXP;
/*    */ import org.renjin.sexp.Symbol;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SlotTranslator
/*    */   extends FunctionCallTranslator
/*    */ {
/*    */   public void addStatement(IRBodyBuilder builder, TranslationContext context, Function resolvedFunction, FunctionCall call) {
/* 38 */     builder.addStatement((Statement)new ExprStatement(translateToExpression(builder, context, resolvedFunction, call)));
/*    */   }
/*    */ 
/*    */   
/*    */   public Expression translateToSetterExpression(IRBodyBuilder builder, TranslationContext context, Function resolvedFunction, FunctionCall getterCall, Expression rhs) {
/* 43 */     throw new UnsupportedOperationException("TODO ");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Expression translateToExpression(IRBodyBuilder builder, TranslationContext context, Function resolvedFunction, FunctionCall call) {
/* 49 */     Expression object = builder.translateExpression(context, call.getArgument(0));
/*    */     
/* 51 */     SEXP nameArgument = call.getArgument(1);
/* 52 */     if (!(nameArgument instanceof Symbol)) {
/* 53 */       throw new NotCompilableException(call);
/*    */     }
/* 55 */     String name = ((Symbol)nameArgument).getPrintName();
/*    */     
/* 57 */     return (Expression)new NamedSlotAccess(object, name);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/ir/tac/functions/SlotTranslator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */