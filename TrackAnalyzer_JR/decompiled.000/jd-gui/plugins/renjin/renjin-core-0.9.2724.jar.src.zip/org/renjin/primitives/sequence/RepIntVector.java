/*    */ package org.renjin.primitives.sequence;
/*    */ 
/*    */ import org.renjin.sexp.AttributeMap;
/*    */ import org.renjin.sexp.IntVector;
/*    */ import org.renjin.sexp.SEXP;
/*    */ import org.renjin.sexp.Vector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RepIntVector
/*    */   extends IntVector
/*    */ {
/*    */   public static final int LENGTH_THRESHOLD = 100;
/*    */   private final Vector source;
/*    */   private int length;
/*    */   private int each;
/*    */   
/*    */   public RepIntVector(Vector source, int length, int each, AttributeMap attributes) {
/* 35 */     super(attributes);
/* 36 */     this.source = source;
/* 37 */     this.length = length;
/* 38 */     this.each = each;
/* 39 */     if (this.length <= 0) {
/* 40 */       throw new IllegalArgumentException("length: " + length);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   protected SEXP cloneWithNewAttributes(AttributeMap attributes) {
/* 46 */     return (SEXP)new RepIntVector(this.source, this.length, this.each, attributes);
/*    */   }
/*    */ 
/*    */   
/*    */   public int getElementAsInt(int index) {
/* 51 */     return this.source.getElementAsInt(index / this.each % this.source.length());
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isConstantAccessTime() {
/* 56 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public int length() {
/* 61 */     return this.length;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/sequence/RepIntVector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */