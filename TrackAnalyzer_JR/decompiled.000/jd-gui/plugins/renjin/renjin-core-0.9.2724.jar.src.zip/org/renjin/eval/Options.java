/*    */ package org.renjin.eval;
/*    */ 
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ import org.renjin.repackaged.guava.collect.Maps;
/*    */ import org.renjin.sexp.AtomicVector;
/*    */ import org.renjin.sexp.IntArrayVector;
/*    */ import org.renjin.sexp.LogicalArrayVector;
/*    */ import org.renjin.sexp.Null;
/*    */ import org.renjin.sexp.SEXP;
/*    */ import org.renjin.sexp.StringArrayVector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Options
/*    */ {
/*    */   private Map<String, SEXP> map;
/*    */   
/*    */   public Options() {
/* 35 */     this.map = Maps.newHashMap();
/* 36 */     this.map.put("prompt", new StringArrayVector(new String[] { "> " }));
/* 37 */     this.map.put("continue", new StringArrayVector(new String[] { "+ " }));
/* 38 */     this.map.put("expressions", new IntArrayVector(new int[] { 5000 }));
/* 39 */     this.map.put("width", new IntArrayVector(new int[] { 80 }));
/* 40 */     this.map.put("digits", new IntArrayVector(new int[] { 7 }));
/* 41 */     this.map.put("echo", new LogicalArrayVector(new boolean[] { false }));
/* 42 */     this.map.put("verbose", new LogicalArrayVector(new boolean[] { false }));
/* 43 */     this.map.put("check.bounds", new LogicalArrayVector(new boolean[] { false }));
/* 44 */     this.map.put("keep.source", new LogicalArrayVector(new boolean[] { true }));
/* 45 */     this.map.put("keep.source.pkgs", new LogicalArrayVector(new boolean[] { false }));
/* 46 */     this.map.put("warnings.length", new IntArrayVector(new int[] { 1000 }));
/* 47 */     this.map.put("OutDec", new StringArrayVector(new String[] { "." }));
/* 48 */     this.map.put("encoding", new StringArrayVector(new String[] { "UTF8" }));
/*    */   }
/*    */   
/*    */   public SEXP get(String name) {
/* 52 */     SEXP value = this.map.get(name);
/* 53 */     return (value == null) ? (SEXP)Null.INSTANCE : value;
/*    */   }
/*    */   
/*    */   public int getInt(String name, int defaultValue) {
/* 57 */     SEXP value = get(name);
/* 58 */     if (value instanceof AtomicVector && value.length() >= 1) {
/* 59 */       return ((AtomicVector)value).getElementAsInt(0);
/*    */     }
/* 61 */     return defaultValue;
/*    */   }
/*    */   
/*    */   public SEXP set(String name, SEXP value) {
/* 65 */     SEXP old = this.map.put(name, value);
/* 66 */     return (old == null) ? (SEXP)Null.INSTANCE : value;
/*    */   }
/*    */   
/*    */   public Set<String> names() {
/* 70 */     return this.map.keySet();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/eval/Options.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */