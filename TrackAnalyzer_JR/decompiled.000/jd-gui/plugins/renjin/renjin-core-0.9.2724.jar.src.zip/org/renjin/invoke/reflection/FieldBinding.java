/*    */ package org.renjin.invoke.reflection;
/*    */ 
/*    */ import java.lang.reflect.Field;
/*    */ import java.lang.reflect.Modifier;
/*    */ import org.renjin.eval.EvalException;
/*    */ import org.renjin.invoke.reflection.converters.Converter;
/*    */ import org.renjin.invoke.reflection.converters.Converters;
/*    */ import org.renjin.sexp.SEXP;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FieldBinding
/*    */   implements MemberBinding
/*    */ {
/*    */   private final Field field;
/*    */   private final Converter converter;
/*    */   
/*    */   public FieldBinding(Field field) {
/* 35 */     this.field = field;
/* 36 */     this.converter = Converters.get(field.getType());
/*    */   }
/*    */ 
/*    */   
/*    */   public SEXP getValue(Object instance) {
/*    */     try {
/* 42 */       return this.converter.convertToR(this.field.get(instance));
/* 43 */     } catch (IllegalAccessException e) {
/* 44 */       throw new IllegalStateException("Exception reading value of field " + this.field, e);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void setValue(Object instance, SEXP value) {
/* 50 */     if (!Modifier.isFinal(this.field.getModifiers())) {
/* 51 */       throw new EvalException("The static field '%s' is read-only", new Object[] { this.field
/* 52 */             .toString() });
/*    */     }
/*    */     try {
/* 55 */       this.field.set(instance, this.converter.convertToJava(value));
/* 56 */     } catch (IllegalAccessException e) {
/* 57 */       throw new EvalException("Exception setting field " + this.field.toString(), e);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/reflection/FieldBinding.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */