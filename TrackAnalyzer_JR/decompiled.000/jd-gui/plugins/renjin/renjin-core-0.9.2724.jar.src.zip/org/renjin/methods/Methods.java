/*     */ package org.renjin.methods;
/*     */ import java.util.Arrays;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import java.util.Set;
/*     */ import org.renjin.eval.ClosureDispatcher;
/*     */ import org.renjin.eval.Context;
/*     */ import org.renjin.eval.EvalException;
/*     */ import org.renjin.invoke.annotations.Builtin;
/*     */ import org.renjin.invoke.annotations.Current;
/*     */ import org.renjin.invoke.annotations.Internal;
/*     */ import org.renjin.primitives.Types;
/*     */ import org.renjin.primitives.packaging.Namespace;
/*     */ import org.renjin.primitives.special.SubstituteFunction;
/*     */ import org.renjin.repackaged.guava.base.Strings;
/*     */ import org.renjin.s4.CallingArguments;
/*     */ import org.renjin.s4.Generic;
/*     */ import org.renjin.s4.RankedMethod;
/*     */ import org.renjin.s4.S4;
/*     */ import org.renjin.s4.S4Cache;
/*     */ import org.renjin.s4.S4Class;
/*     */ import org.renjin.s4.S4ClassCache;
/*     */ import org.renjin.s4.S4MethodCache;
/*     */ import org.renjin.s4.S4MethodTable;
/*     */ import org.renjin.s4.Signature;
/*     */ import org.renjin.sexp.Closure;
/*     */ import org.renjin.sexp.Environment;
/*     */ import org.renjin.sexp.ExternalPtr;
/*     */ import org.renjin.sexp.FunctionCall;
/*     */ import org.renjin.sexp.IntVector;
/*     */ import org.renjin.sexp.Logical;
/*     */ import org.renjin.sexp.LogicalArrayVector;
/*     */ import org.renjin.sexp.LogicalVector;
/*     */ import org.renjin.sexp.Null;
/*     */ import org.renjin.sexp.PairList;
/*     */ import org.renjin.sexp.PrimitiveFunction;
/*     */ import org.renjin.sexp.S4Object;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.SpecialFunction;
/*     */ import org.renjin.sexp.StringArrayVector;
/*     */ import org.renjin.sexp.StringVector;
/*     */ import org.renjin.sexp.Symbol;
/*     */ import org.renjin.sexp.Symbols;
/*     */ 
/*     */ public class Methods {
/*     */   public static SEXP R_initMethodDispatch(@Current Context context, SEXP environ) {
/*  47 */     ((MethodDispatch)context.getSession().getSingleton(MethodDispatch.class))
/*  48 */       .init((environ == Null.INSTANCE) ? context.getGlobalEnvironment() : (Environment)environ);
/*  49 */     return environ;
/*     */   }
/*     */   
/*     */   @Builtin(".isMethodsDispatchOn")
/*     */   public static boolean isMethodsDispatchOn(@Current MethodDispatch methodDispatch) {
/*  54 */     return methodDispatch.isEnabled();
/*     */   }
/*     */   
/*     */   @Builtin(".isMethodsDispatchOn")
/*     */   public static void setMethodsDispatchOn(@Current MethodDispatch methodDispatch, boolean enabled) {
/*  59 */     methodDispatch.setEnabled(enabled);
/*     */   }
/*     */   
/*     */   public static boolean R_set_method_dispatch(@Current Context context, LogicalVector onOff) {
/*  63 */     MethodDispatch methodContext = (MethodDispatch)context.getSession().getSingleton(MethodDispatch.class);
/*  64 */     boolean oldValue = methodContext.isEnabled();
/*  65 */     if (onOff.getElementAsLogical(0) == Logical.TRUE) {
/*  66 */       methodContext.setEnabled(true);
/*  67 */     } else if (onOff.getElementAsLogical(0) == Logical.FALSE) {
/*  68 */       methodContext.setEnabled(false);
/*     */     } 
/*  70 */     return oldValue;
/*     */   }
/*     */   
/*     */   public static S4Object Rf_allocS4Object() {
/*  74 */     return new S4Object();
/*     */   }
/*     */ 
/*     */   
/*     */   public static ExternalPtr R_externalptr_prototype_object() {
/*  79 */     return new ExternalPtr(null);
/*     */   }
/*     */   
/*     */   public static SEXP R_set_slot(@Current Context context, SEXP object, String name, SEXP value) {
/*  83 */     if (name.equals(".Data"))
/*     */     {
/*     */ 
/*     */       
/*  87 */       return context.evaluate((SEXP)FunctionCall.newCall((SEXP)Symbol.get("setDataPart"), new SEXP[] { object, value }), ((MethodDispatch)context
/*  88 */           .getSingleton(MethodDispatch.class)).getMethodsNamespace());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  95 */     SEXP slotValue = (value == Null.INSTANCE) ? (SEXP)Symbols.S4_NULL : value;
/*  96 */     return object.setAttributes(object.getAttributes().copyS4().set(name, slotValue));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static SEXP R_get_slot(@Current Context context, SEXP object, String what) {
/* 102 */     return R_do_slot(context, object, (SEXP)StringArrayVector.valueOf(what));
/*     */   }
/*     */   
/*     */   public static int R_has_slot(SEXP obj, SEXP name) {
/* 106 */     Symbol slot = Symbol.get(name.asString());
/* 107 */     Map<Symbol, SEXP> objSlots = obj.getAttributes().toMap();
/* 108 */     if (objSlots.containsKey(slot)) {
/* 109 */       return 1;
/*     */     }
/* 111 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String R_methodsPackageMetaName(String prefix, String name, String packageName) {
/* 119 */     StringBuilder metaName = (new StringBuilder()).append(".__").append(prefix).append("__").append(name);
/* 120 */     if (!Strings.isNullOrEmpty(packageName)) {
/* 121 */       metaName.append(":").append(packageName);
/*     */     }
/* 123 */     return metaName.toString();
/*     */   }
/*     */   
/*     */   public static SEXP R_getClassFromCache(@Current Context context, SEXP className, Environment table) {
/* 127 */     if (className instanceof StringVector) {
/* 128 */       String packageName = className.getAttributes().getPackage();
/* 129 */       SEXP cachedValue = table.getVariable(context, Symbol.get(((StringVector)className).getElementAsString(0)));
/*     */       
/* 131 */       if (cachedValue == Symbol.UNBOUND_VALUE) {
/* 132 */         return (SEXP)Null.INSTANCE;
/*     */       }
/* 134 */       String cachedPackage = cachedValue.getAttributes().getPackage();
/*     */       
/* 136 */       if (packageName == null || cachedPackage == null || packageName
/* 137 */         .equals(cachedPackage))
/*     */       {
/* 139 */         return cachedValue;
/*     */       }
/*     */       
/* 142 */       return (SEXP)Null.INSTANCE;
/*     */     } 
/*     */ 
/*     */     
/* 146 */     if (!(className instanceof S4Object)) {
/* 147 */       throw new EvalException("Class should be either a character-string name or a class definition", new Object[0]);
/*     */     }
/* 149 */     return className;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean R_identC(SEXP e1, SEXP e2) {
/* 160 */     if (e1 instanceof StringVector && e2 instanceof StringVector && e1
/* 161 */       .length() == 1 && e2.length() == 1) {
/*     */       
/* 163 */       StringVector s1 = (StringVector)e1;
/* 164 */       StringVector s2 = (StringVector)e2;
/* 165 */       if (!s1.isElementNA(0)) {
/* 166 */         return s1.getElementAsString(0).equals(s2.getElementAsString(0));
/*     */       }
/*     */     } 
/*     */     
/* 170 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static SEXP R_do_new_object(S4Object classRepresentation) {
/* 176 */     SEXP classNameExp = classRepresentation.getAttributes().get(Symbols.CLASS_NAME);
/* 177 */     String className = ((StringVector)classNameExp).getElementAsString(0);
/* 178 */     SEXP prototype = classRepresentation.getAttribute(Symbols.PROTOTYPE);
/*     */     
/* 180 */     if (prototype instanceof S4Object || classNameExp.getAttributes().getPackage() != null) {
/* 181 */       return prototype.setAttribute(Symbols.CLASS, classNameExp);
/*     */     }
/* 183 */     return prototype;
/*     */   }
/*     */ 
/*     */   
/*     */   @Builtin(".cache_class")
/*     */   public static SEXP cacheClass(@Current Context context, String className) {
/* 189 */     return ((MethodDispatch)context
/* 190 */       .getSession()
/* 191 */       .getSingleton(MethodDispatch.class))
/* 192 */       .getExtends(className);
/*     */   }
/*     */   
/*     */   @Builtin(".cache_class")
/*     */   public static SEXP cacheClass(@Current Context context, String className, SEXP klass) {
/* 197 */     ((MethodDispatch)context
/* 198 */       .getSession()
/* 199 */       .getSingleton(MethodDispatch.class))
/* 200 */       .putExtends(className, klass);
/* 201 */     return klass;
/*     */   }
/*     */   
/*     */   public static SEXP R_getGeneric(@Current Context context, String symbol, boolean mustFind, Environment rho, String pkg) {
/* 205 */     return R_getGeneric(context, Symbol.get(symbol), mustFind, rho, pkg);
/*     */   }
/*     */   
/*     */   public static SEXP R_getGeneric(@Current Context context, Symbol symbol, boolean mustFind, Environment rho, String pkg) {
/*     */     Null null;
/* 210 */     SEXP generic = getGeneric(context, symbol, rho, pkg);
/* 211 */     if (generic == Symbol.UNBOUND_VALUE) {
/* 212 */       if (mustFind) {
/* 213 */         throw new EvalException("No generic function definition found for '%s' in the supplied environment", new Object[] { symbol.getPrintName() });
/*     */       }
/* 215 */       null = Null.INSTANCE;
/*     */     } 
/* 217 */     return (SEXP)null;
/*     */   }
/*     */   
/*     */   protected static SEXP getGeneric(@Current Context context, Symbol symbol, Environment env, String pkg) {
/*     */     SEXP sEXP;
/* 222 */     Symbol symbol1, symbol2 = Symbol.UNBOUND_VALUE;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 227 */     Environment rho = env;
/* 228 */     while (rho != Environment.EMPTY) {
/* 229 */       SEXP vl = rho.getVariable(context, symbol);
/* 230 */       if (vl != Symbol.UNBOUND_VALUE) {
/* 231 */         vl = vl.force(context);
/*     */         
/* 233 */         boolean ok = false;
/* 234 */         if (IS_GENERIC(vl)) {
/* 235 */           if (!Strings.isNullOrEmpty(pkg)) {
/* 236 */             String gpackage = vl.getAttributes().getPackage();
/* 237 */             ok = pkg.equals(gpackage);
/*     */           } else {
/* 239 */             ok = true;
/*     */           } 
/*     */         }
/* 242 */         if (ok) {
/* 243 */           sEXP = vl;
/*     */           break;
/*     */         } 
/* 246 */         Symbol symbol3 = Symbol.UNBOUND_VALUE;
/*     */       } 
/*     */       
/* 249 */       rho = rho.getParent();
/*     */     } 
/*     */     
/* 252 */     if (sEXP == Symbol.UNBOUND_VALUE) {
/* 253 */       SEXP vl = context.getBaseEnvironment().getVariable(context, symbol);
/* 254 */       if (IS_GENERIC(vl)) {
/* 255 */         sEXP = vl;
/* 256 */         if (vl.getAttributes().getPackage() != null) {
/* 257 */           String gpackage = vl.getAttributes().getPackage();
/* 258 */           if (!gpackage.equals(pkg)) {
/* 259 */             symbol1 = Symbol.UNBOUND_VALUE;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 264 */     return (SEXP)symbol1;
/*     */   }
/*     */   
/*     */   private static boolean IS_GENERIC(SEXP value) {
/* 268 */     return (value instanceof Closure && value.getAttributes().has(Symbols.GENERIC));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SEXP do_substitute_direct(@Current Context context, SEXP f, SEXP env) {
/* 277 */     return SubstituteFunction.substitute(context, f, env);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static SEXP R_M_setPrimitiveMethods(@Current Context context, SEXP fname, SEXP op, String code_vec, SEXP fundef, SEXP mlist) {
/* 283 */     return R_set_prim_method(context, fname, op, code_vec, fundef, mlist);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void do_set_prim_method(@Current Context context, PrimitiveFunction op, String code_string, SEXP fundef, SEXP mlist) {
/* 291 */     PrimitiveMethodTable.prim_methods_t code = parseCode(code_string);
/*     */     
/* 293 */     PrimitiveMethodTable table = (PrimitiveMethodTable)context.getSession().getSingleton(PrimitiveMethodTable.class);
/* 294 */     PrimitiveMethodTable.Entry entry = table.get(op);
/*     */     
/* 296 */     entry.setMethods(code);
/*     */     
/* 298 */     if (code != PrimitiveMethodTable.prim_methods_t.SUPPRESSED && 
/* 299 */       fundef != Null.INSTANCE) {
/* 300 */       entry.setGeneric((Closure)fundef);
/*     */     }
/*     */     
/* 303 */     if (code == PrimitiveMethodTable.prim_methods_t.HAS_METHODS) {
/* 304 */       entry.setMethodList(mlist);
/*     */     }
/*     */   }
/*     */   
/*     */   public static SEXP R_set_prim_method(@Current Context context, SEXP fname, SEXP op, String code_string, SEXP fundef, SEXP mlist) {
/* 309 */     PrimitiveMethodTable table = (PrimitiveMethodTable)context.getSession().getSingleton(PrimitiveMethodTable.class);
/*     */ 
/*     */ 
/*     */     
/* 313 */     if (op == Null.INSTANCE) {
/* 314 */       SEXP value = LogicalVector.valueOf(table.isPrimitiveMethodsAllowed());
/* 315 */       switch (parseCode(code_string)) {
/*     */         case NO_METHODS:
/* 317 */           table.setPrimitiveMethodsAllowed(false);
/*     */           break;
/*     */         case HAS_METHODS:
/* 320 */           table.setPrimitiveMethodsAllowed(true);
/*     */           break;
/*     */       } 
/*     */ 
/*     */       
/* 325 */       return value;
/*     */     } 
/* 327 */     do_set_prim_method(context, (PrimitiveFunction)op, code_string, fundef, mlist);
/* 328 */     return fname;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static PrimitiveMethodTable.prim_methods_t parseCode(String code_string) {
/* 334 */     PrimitiveMethodTable.prim_methods_t code = PrimitiveMethodTable.prim_methods_t.NO_METHODS;
/* 335 */     if (code_string.equalsIgnoreCase("clear")) {
/* 336 */       code = PrimitiveMethodTable.prim_methods_t.NO_METHODS;
/* 337 */     } else if (code_string.equalsIgnoreCase("reset")) {
/* 338 */       code = PrimitiveMethodTable.prim_methods_t.NEEDS_RESET;
/* 339 */     } else if (code_string.equalsIgnoreCase("set")) {
/* 340 */       code = PrimitiveMethodTable.prim_methods_t.HAS_METHODS;
/* 341 */     } else if (code_string.equalsIgnoreCase("suppress")) {
/* 342 */       code = PrimitiveMethodTable.prim_methods_t.SUPPRESSED;
/*     */     } else {
/* 344 */       throw new EvalException("invalid primitive methods code (\"%s\"): should be \"clear\", \"reset\", \"set\", or \"suppress\"", new Object[] { code_string });
/*     */     } 
/* 346 */     return code;
/*     */   }
/*     */ 
/*     */   
/*     */   @Internal
/*     */   public static SEXP getClass(@Current Context context, SEXP className, boolean dotForce, SEXP where) {
/* 352 */     if (className instanceof S4Object) {
/* 353 */       return className;
/*     */     }
/*     */     
/* 356 */     SEXP classDef = getClassDef(context, (StringVector)className, (SEXP)Null.INSTANCE, (SEXP)Null.INSTANCE, true);
/*     */     
/* 358 */     if (dotForce && (classDef == Null.INSTANCE || classDef == Symbol.UNBOUND_VALUE)) {
/* 359 */       if (dotForce) {
/* 360 */         SEXP env; System.out.println("getClass(" + ((StringVector)className).getElementAsString(0) + ", .Force = TRUE)");
/*     */         
/* 362 */         if (where == Null.INSTANCE) {
/* 363 */           Environment environment = context.getCallingEnvironment();
/*     */         } else {
/* 365 */           env = where;
/*     */         } 
/* 367 */         PairList.Builder args = new PairList.Builder();
/* 368 */         args.add(className);
/* 369 */         args.add(Symbol.get("package"), (SEXP)StringVector.valueOf("base"));
/* 370 */         args.add(Symbol.get("virtual"), (SEXP)LogicalVector.TRUE);
/* 371 */         args.add(Symbol.get("where"), env);
/* 372 */         classDef = context.evaluate((SEXP)FunctionCall.newCall((SEXP)Symbol.get("makeClassRepresentation"), new SEXP[] { (SEXP)args.build() }));
/*     */       } else {
/* 374 */         throw new EvalException("'" + ((StringVector)className).getElementAsString(0) + "' is not a defined class", new Object[0]);
/*     */       } 
/*     */     }
/* 377 */     return classDef;
/*     */   }
/*     */   
/*     */   @Internal
/*     */   public static SEXP getClassDef(@Current Context context, StringVector className, SEXP where, SEXP packageName, boolean inherits) {
/* 382 */     Symbol symbol = Symbol.UNBOUND_VALUE;
/* 383 */     String providedPackage = null;
/*     */     
/* 385 */     if (inherits) {
/* 386 */       S4Cache s4Cache = context.getSession().getS4Cache();
/* 387 */       S4Class s4Class = s4Cache.getS4ClassCache().lookupClass(context, className.getElementAsString(0));
/* 388 */       if (s4Class != null) {
/* 389 */         sEXP = s4Class.getDefinition();
/*     */       }
/*     */     } 
/*     */     
/* 393 */     if (sEXP == Symbol.UNBOUND_VALUE) {
/* 394 */       Symbol metadataName = Symbol.get(".__C__" + className);
/*     */       
/* 396 */       if (packageName == Null.INSTANCE) {
/* 397 */         SEXP packageSlot = className.getAttribute(Symbols.PACKAGE);
/* 398 */         if (packageSlot != Null.INSTANCE) {
/* 399 */           providedPackage = ((StringArrayVector)packageSlot).getElementAsString(0);
/*     */         }
/* 401 */       } else if (packageName instanceof StringArrayVector) {
/* 402 */         providedPackage = ((StringArrayVector)packageName).getElementAsString(0);
/*     */       } 
/*     */       
/* 405 */       if (!Strings.isNullOrEmpty(providedPackage)) {
/* 406 */         Optional<Namespace> namespace = context.getNamespaceRegistry().getNamespaceIfPresent(Symbol.get(providedPackage));
/* 407 */         if (!namespace.isPresent()) {
/* 408 */           throw new EvalException("Package " + providedPackage + " is not loaded", new Object[0]);
/*     */         }
/* 410 */         sEXP = ((Namespace)namespace.get()).getNamespaceEnvironment().findVariable(context, metadataName, x -> true, inherits);
/*     */       } else {
/*     */         
/* 413 */         if (where == Null.INSTANCE) {
/* 414 */           SEXP parentFrame = context.evaluate((SEXP)FunctionCall.newCall((SEXP)Symbol.get("parent.frame"), new SEXP[] { (SEXP)IntVector.valueOf(1) }));
/* 415 */           where = context.evaluate((SEXP)FunctionCall.newCall((SEXP)Symbol.get("topenv"), new SEXP[] { parentFrame }));
/*     */         } 
/* 417 */         sEXP = ((Environment)where).findVariable(context, metadataName, x -> true, inherits);
/*     */       } 
/*     */     } 
/*     */     
/* 421 */     if (sEXP == Symbol.UNBOUND_VALUE) {
/* 422 */       return (SEXP)Null.INSTANCE;
/*     */     }
/*     */     
/* 425 */     SEXP sEXP = sEXP.force(context);
/*     */     
/* 427 */     if (!Types.isS4(sEXP)) {
/* 428 */       throw new EvalException("ClassDefinition " + className + " is corrupted. Please rebuild package: " + sEXP.getAttribute(Symbol.get("package")), new Object[0]);
/*     */     }
/* 430 */     return sEXP;
/*     */   }
/*     */ 
/*     */   
/*     */   @Internal
/*     */   public static SEXP selectMethod(@Current Context context, SEXP functionName, StringArrayVector args, LogicalArrayVector opt, LogicalArrayVector useInherited, SEXP mlist, SEXP fdef, SEXP verbose, SEXP doCache) {
/*     */     String fname;
/* 437 */     boolean optional = opt.isElementTrue(0);
/*     */     
/* 439 */     if (functionName instanceof StringVector) {
/* 440 */       fname = ((StringVector)functionName).getElementAsString(0);
/* 441 */     } else if (functionName instanceof SpecialFunction) {
/* 442 */       fname = ((SpecialFunction)functionName).getName();
/* 443 */     } else if (functionName instanceof Closure) {
/* 444 */       fname = ((StringArrayVector)functionName.getAttribute(Symbols.GENERIC)).getElementAsString(0);
/*     */     } else {
/* 446 */       throw new EvalException("type of f is invalid, should be string, generic function, or primitive", new Object[0]);
/*     */     } 
/*     */     
/* 449 */     String packageName = getPackageName(context, fdef);
/*     */     
/* 451 */     Generic generic = Generic.standardGeneric(context, fname, packageName);
/*     */     
/* 453 */     S4MethodCache methodCache = context.getSession().getS4Cache().getS4MethodCache();
/* 454 */     S4MethodTable methodTable = methodCache.getMethod(context, generic, fname);
/*     */     
/* 456 */     if (methodTable == null || methodTable.isEmpty()) {
/* 457 */       if (optional) {
/* 458 */         return (SEXP)Null.INSTANCE;
/*     */       }
/* 460 */       throw new EvalException("selectMethod(" + fname + "): No methods found!", new Object[0]);
/*     */     } 
/*     */ 
/*     */     
/* 464 */     Signature signature = new Signature(args.toArray());
/*     */     
/* 466 */     boolean[] inheritance = computeUseInheritance(args, useInherited, generic, methodTable);
/*     */     
/* 468 */     RankedMethod selectedMethod = methodTable.selectMethod(context, generic, signature, inheritance);
/*     */     
/* 470 */     if (selectedMethod == null) {
/* 471 */       if (optional) {
/* 472 */         return (SEXP)Null.INSTANCE;
/*     */       }
/* 474 */       throw new EvalException("selectMethod(" + fname + "): No matching methods found! 'optional' is set to FALSE.", new Object[0]);
/*     */     } 
/*     */ 
/*     */     
/* 478 */     return (SEXP)selectedMethod.getMethodDefinition();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean[] computeUseInheritance(StringArrayVector args, LogicalArrayVector useInherited, Generic generic, S4MethodTable methodTable) {
/* 486 */     boolean[] inheritance = new boolean[methodTable.getMaximumSignatureLength()];
/* 487 */     int useInheritedLength = useInherited.length();
/*     */     
/* 489 */     if (useInheritedLength == 1) {
/* 490 */       Arrays.fill(inheritance, useInherited.isElementTrue(0));
/*     */     } else {
/* 492 */       int j = 0;
/* 493 */       for (int i = 0; i < args.length(); i++, j++) {
/* 494 */         if (j == useInheritedLength) {
/* 495 */           j = 0;
/*     */         }
/* 497 */         inheritance[i] = (useInherited.isElementTrue(j) && 
/* 498 */           !"ANY".equals(args.getElementAsString(i)));
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 505 */     if ("coerce".equals(generic.getName())) {
/* 506 */       inheritance = new boolean[] { inheritance[0], false };
/*     */     }
/* 508 */     return inheritance;
/*     */   }
/*     */   
/*     */   public static String getPackageName(@Current Context context, SEXP fdef) {
/*     */     String packageName;
/* 513 */     if (fdef instanceof Closure) {
/* 514 */       packageName = fdef.getAttribute(S4.PACKAGE).asString();
/*     */     } else {
/* 516 */       packageName = context.getFunction().getAttribute(S4.PACKAGE).asString();
/*     */     } 
/* 518 */     return packageName;
/*     */   }
/*     */   
/*     */   @Builtin
/*     */   public static SEXP standardGeneric(@Current Context context, Symbol fname, SEXP fdef) {
/* 523 */     return standardGeneric(context, (Environment)Environment.EMPTY, fname.getPrintName());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Builtin
/*     */   public static SEXP standardGeneric(@Current Context context, @Current Environment ev, String fname) {
/* 530 */     if (Strings.isNullOrEmpty(fname)) {
/* 531 */       throw new EvalException("argument to 'standardGeneric' must be a non-empty character string", new Object[0]);
/*     */     }
/*     */     
/* 534 */     String packageName = context.getFunction().getAttribute(S4.PACKAGE).asString();
/* 535 */     Generic generic = Generic.standardGeneric(context, fname, packageName);
/*     */     
/* 537 */     S4MethodCache methodCache = context.getSession().getS4Cache().getS4MethodCache();
/* 538 */     S4MethodTable methodTable = methodCache.getMethod(context, generic, fname);
/*     */     
/* 540 */     if (methodTable == null || methodTable.isEmpty()) {
/* 541 */       throw new EvalException("standardGeneric(" + fname + "): No methods found!", new Object[0]);
/*     */     }
/*     */     
/* 544 */     CallingArguments arguments = CallingArguments.standardGenericArguments(context, methodTable.getArgumentMatcher());
/*     */     
/* 546 */     Signature signature = arguments.getSignature(methodTable.getMaximumSignatureLength(), generic.getSignatureArgumentNames());
/*     */     
/* 548 */     boolean[] useInheritance = new boolean[methodTable.getMaximumSignatureLength()];
/* 549 */     Arrays.fill(useInheritance, Boolean.TRUE.booleanValue());
/*     */     
/* 551 */     RankedMethod selectedMethod = methodTable.selectMethod(context, generic, signature, useInheritance);
/*     */     
/* 553 */     if (selectedMethod == null) {
/* 554 */       throw new EvalException("unable to find an inherited method for function '" + fname + "' for signature " + arguments
/* 555 */           .getFullSignatureString(methodTable.getMaximumSignatureLength()), new Object[0]);
/*     */     }
/*     */     
/* 558 */     Closure function = selectedMethod.getMethodDefinition();
/*     */     
/* 560 */     Map<Symbol, SEXP> metadata = S4.generateCallMetaData(context, selectedMethod, signature, fname);
/*     */     
/* 562 */     PairList coercedArgs = coerce(context, arguments, selectedMethod);
/*     */ 
/*     */ 
/*     */     
/* 566 */     FunctionCall call = new FunctionCall((SEXP)function, context.getCall().getArguments());
/*     */     
/* 568 */     return ClosureDispatcher.apply(context, context.getCallingEnvironment(), call, function, coercedArgs, metadata);
/*     */   }
/*     */ 
/*     */   
/*     */   public static PairList coerce(Context context, CallingArguments arguments, RankedMethod method) {
/* 573 */     int signatureLength = method.getMethodSignatureLength();
/*     */     
/* 575 */     Set<String> argNames = method.getMethod().getGeneric().getSignatureArgumentNames();
/*     */     
/* 577 */     S4ClassCache classCache = context.getSession().getS4Cache().getS4ClassCache();
/*     */     
/* 579 */     PairList.Builder coercedArgs = new PairList.Builder();
/*     */     
/* 581 */     int step = 0;
/*     */     
/* 583 */     for (PairList.Node arg : arguments.getPromisedArgs().nodes()) {
/* 584 */       SEXP value = arg.getValue();
/* 585 */       SEXP tag = arg.getRawTag();
/* 586 */       if (step < signatureLength && tag != Null.INSTANCE && argNames.contains(arg.getTag().getPrintName())) {
/* 587 */         String from = arguments.getArgumentClass(step);
/* 588 */         String to = method.getArgumentClass(step);
/* 589 */         if (to.equals(from) || to.equals("ANY") || classCache.isSimple(from, to)) {
/* 590 */           coercedArgs.add(tag, value);
/*     */         } else {
/* 592 */           SEXP coercedArg = classCache.coerceComplex(context, value, from, to);
/* 593 */           coercedArgs.add(tag, coercedArg);
/*     */         } 
/* 595 */         step++; continue;
/*     */       } 
/* 597 */       coercedArgs.add(tag, value);
/*     */     } 
/*     */     
/* 600 */     return coercedArgs.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SEXP get_this_generic(Context context, String fname) {
/*     */     SEXP sEXP;
/* 610 */     Null null = Null.INSTANCE;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 619 */     Context cptr = context;
/* 620 */     while (!cptr.isTopLevel()) {
/* 621 */       SEXP function = cptr.getFunction();
/* 622 */       if (function.isObject()) {
/* 623 */         SEXP generic = function.getAttribute(MethodDispatch.GENERIC);
/* 624 */         if (generic instanceof StringVector && generic.asString().equals(fname)) {
/* 625 */           sEXP = function;
/*     */           break;
/*     */         } 
/*     */       } 
/* 629 */       cptr = cptr.getParent();
/*     */     } 
/* 631 */     return sEXP;
/*     */   }
/*     */ 
/*     */   
/*     */   private static Symbol checkSlotName(SEXP name) {
/* 636 */     if (name instanceof Symbol) {
/* 637 */       return (Symbol)name;
/*     */     }
/* 639 */     if (name instanceof StringVector && name.length() == 1) {
/* 640 */       return Symbol.get(name.asString());
/*     */     }
/* 642 */     throw new EvalException("Invalid type or length for a slot name", new Object[0]);
/*     */   }
/*     */   static SEXP R_do_slot(Context context, SEXP obj, SEXP slotName) {
/*     */     Null null;
/* 646 */     Symbol name = checkSlotName(slotName);
/*     */     
/* 648 */     if (name == MethodDispatch.s_dot_Data) {
/* 649 */       return data_part(context, obj);
/*     */     }
/* 651 */     SEXP value = obj.getAttribute(name);
/* 652 */     if (value == Null.INSTANCE) {
/* 653 */       String input = name.getPrintName();
/*     */       
/* 655 */       if (name == MethodDispatch.s_dot_S3Class)
/*     */       {
/*     */         
/* 658 */         throw new UnsupportedOperationException();
/*     */       }
/* 660 */       input = name.getPrintName();
/* 661 */       SEXP classString = obj.getAttribute(Symbols.CLASS);
/* 662 */       if (classString == Null.INSTANCE) {
/* 663 */         throw new EvalException("cannot get a slot (\"%s\") from an object of type \"%s\"", new Object[] { input, obj
/* 664 */               .getTypeName() });
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 671 */       throw new EvalException("no slot of name \"%s\" for this object of class \"%s\"", new Object[] { input, classString
/* 672 */             .asString() });
/*     */     } 
/* 674 */     if (value == MethodDispatch.pseudo_NULL) {
/* 675 */       null = Null.INSTANCE;
/*     */     }
/* 677 */     return (SEXP)null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SEXP data_part(Context context, SEXP obj) {
/* 684 */     SEXP val = context.evaluate((SEXP)FunctionCall.newCall((SEXP)MethodDispatch.s_getDataPart, new SEXP[] { obj }), ((MethodDispatch)context
/* 685 */         .getSession().getSingleton(MethodDispatch.class)).getMethodsNamespace());
/*     */ 
/*     */     
/* 688 */     return Types.setS4Object(val, false, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static StringVector R_data_class(SEXP obj, boolean singleString) {
/* 700 */     SEXP klass = obj.getAttribute(Symbols.CLASS);
/* 701 */     int n = klass.length();
/* 702 */     if (n == 1 || (n > 0 && !singleString)) {
/* 703 */       return (StringVector)klass;
/*     */     }
/* 705 */     if (n == 0) {
/* 706 */       SEXP dim = obj.getAttribute(Symbols.DIM);
/* 707 */       int nd = dim.length();
/* 708 */       if (nd > 0) {
/* 709 */         if (nd == 2) {
/* 710 */           return StringVector.valueOf("matrix");
/*     */         }
/* 712 */         return StringVector.valueOf("array");
/*     */       } 
/*     */       
/* 715 */       if (obj instanceof org.renjin.sexp.Function)
/* 716 */         return StringVector.valueOf("function"); 
/* 717 */       if (obj instanceof org.renjin.sexp.DoubleVector)
/* 718 */         return StringVector.valueOf("numeric"); 
/* 719 */       if (obj instanceof Symbol) {
/* 720 */         return StringVector.valueOf("name");
/*     */       }
/*     */     } 
/*     */     
/* 724 */     return StringVector.valueOf(obj.getImplicitClass());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static SEXP dispatchNonGeneric(Context context, String name, Environment env, SEXP fdef) {
/* 734 */     Symbol symbol = Symbol.get(name);
/* 735 */     for (Environment rho = env.getParent(); rho != Environment.EMPTY; 
/* 736 */       rho = rho.getParent()) {
/* 737 */       SEXP fun = rho.getVariable(context, symbol);
/* 738 */       if (fun instanceof Closure && 
/* 739 */         !isGenericFunction(context, fun)) {
/*     */         break;
/*     */       }
/*     */       
/* 743 */       Symbol symbol2 = Symbol.UNBOUND_VALUE;
/*     */     } 
/* 745 */     Symbol symbol1 = symbol;
/* 746 */     if (symbol1 == Symbol.UNBOUND_VALUE) {
/* 747 */       throw new EvalException("unable to find a non-generic version of function \"%s\"", new Object[] { name });
/*     */     }
/*     */ 
/*     */     
/* 751 */     Context cptr = context;
/*     */     
/* 753 */     while (!cptr.isTopLevel() && (
/* 754 */       cptr.getType() != Context.Type.FUNCTION || 
/* 755 */       cptr.getEnvironment() != env))
/*     */     {
/*     */ 
/*     */       
/* 759 */       cptr = cptr.getParent();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 766 */     return context.evaluate((SEXP)FunctionCall.newCall((SEXP)symbol1, new SEXP[] { (SEXP)cptr.getArguments(), (SEXP)cptr.getCallingEnvironment() }));
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean isGenericFunction(@Current Context context, SEXP fun) {
/* 771 */     SEXP value = ((Closure)fun).getEnclosingEnvironment().getVariable(context, MethodDispatch.DOT_GENERIC);
/* 772 */     return (value != Symbol.UNBOUND_VALUE);
/*     */   }
/*     */ 
/*     */   
/*     */   public static String R_get_primname(PrimitiveFunction function) {
/* 777 */     return function.getName();
/*     */   }
/*     */ 
/*     */   
/*     */   public static SEXP R_nextMethod(@Current Context context, FunctionCall matched_call, Environment ev) {
/* 782 */     int nargs = matched_call.length() - 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 788 */     SEXP op = ev.findVariable(context, MethodDispatch.R_dot_nextMethod);
/*     */     
/* 790 */     if (op == Symbol.UNBOUND_VALUE) {
/* 791 */       throw new EvalException("internal error in 'callNextMethod': '.nextMethod' was not assigned in the frame of the method call", new Object[0]);
/*     */     }
/*     */ 
/*     */     
/* 795 */     PairList.Node e = (PairList.Node)matched_call.newCopyBuilder().build();
/*     */     
/* 797 */     boolean prim_case = op instanceof PrimitiveFunction;
/* 798 */     if (prim_case)
/*     */     {
/*     */ 
/*     */       
/* 802 */       throw new UnsupportedOperationException();
/*     */     }
/* 804 */     e.setValue((SEXP)MethodDispatch.R_dot_nextMethod);
/*     */     
/* 806 */     PairList args = e.getNext();
/*     */ 
/*     */ 
/*     */     
/* 810 */     for (int i = 0; i < nargs; i++) {
/* 811 */       PairList.Node argsNode = (PairList.Node)args;
/* 812 */       SEXP this_sym = args.getRawTag();
/* 813 */       if (argsNode.getValue() != Symbol.MISSING_ARG) {
/* 814 */         argsNode.setValue(this_sym);
/*     */       }
/* 816 */       args = argsNode.getNext();
/*     */     } 
/*     */     
/* 819 */     if (prim_case) {
/* 820 */       throw new UnsupportedOperationException("todo: do_set_prim_method");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 834 */     SEXP val = context.evaluate((SEXP)e, ev);
/*     */     
/* 836 */     return val;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/methods/Methods.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */