/*    */ package org.renjin.primitives.io.serialization;
/*    */ 
/*    */ import org.renjin.eval.Context;
/*    */ import org.renjin.eval.Session;
/*    */ import org.renjin.primitives.packaging.FqPackageName;
/*    */ import org.renjin.sexp.Environment;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SessionWriteContext
/*    */   implements WriteContext
/*    */ {
/*    */   private Context context;
/*    */   
/*    */   @Deprecated
/*    */   public SessionWriteContext(Session session) {
/* 37 */     this(session.getTopLevelContext());
/*    */   }
/*    */   
/*    */   public SessionWriteContext(Context context) {
/* 41 */     this.context = context;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isBaseEnvironment(Environment exp) {
/* 46 */     return (exp == this.context.getBaseEnvironment());
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isNamespaceEnvironment(Environment environment) {
/* 51 */     return this.context.getNamespaceRegistry().isNamespaceEnv(environment);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isBaseNamespaceEnvironment(Environment ns) {
/* 56 */     return 
/*    */       
/* 58 */       (ns == this.context.getNamespaceRegistry().getBaseNamespaceEnv());
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isGlobalEnvironment(Environment env) {
/* 63 */     return (env == this.context.getGlobalEnvironment());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getNamespaceName(Environment ns) {
/* 78 */     FqPackageName packageName = this.context.getNamespaceRegistry().getNamespace(ns).getFullyQualifiedName();
/* 79 */     if (packageName.getGroupId().equals("org.renjin")) {
/* 80 */       return packageName.getPackageName();
/*    */     }
/*    */     
/* 83 */     return packageName.toString(':');
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/io/serialization/SessionWriteContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */