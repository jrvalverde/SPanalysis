/*     */ package org.renjin.eval;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.renjin.sexp.Closure;
/*     */ import org.renjin.sexp.Environment;
/*     */ import org.renjin.sexp.Null;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.StringArrayVector;
/*     */ import org.renjin.sexp.StringVector;
/*     */ import org.renjin.sexp.Symbol;
/*     */ import org.renjin.sexp.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DispatchChain
/*     */ {
/*  27 */   public static final Symbol GENERIC = Symbol.get(".Generic");
/*  28 */   public static final Symbol METHOD = Symbol.get(".Method");
/*  29 */   public static final Symbol CLASS = Symbol.get(".Class");
/*  30 */   public static final Symbol GROUP = Symbol.get(".Group");
/*     */   
/*     */   private String generic;
/*     */   
/*     */   private String group;
/*     */   
/*     */   private String method;
/*     */   private Closure closure;
/*     */   private Vector classes;
/*     */   private final Context context;
/*     */   
/*     */   public DispatchChain(Context context) {
/*  42 */     this.context = context;
/*     */   }
/*     */   
/*     */   public static DispatchChain newChain(Context context, Environment callingEnvironment, String generic, Vector classes) {
/*  46 */     for (int i = 0; i != classes.length(); i++) {
/*  47 */       Symbol method = Symbol.get(generic + "." + classes.getElementAsString(i));
/*  48 */       SEXP function = callingEnvironment.findVariable(context, method, x -> x instanceof org.renjin.sexp.Function, true);
/*  49 */       if (function != Symbol.UNBOUND_VALUE) {
/*  50 */         DispatchChain chain = new DispatchChain(context);
/*  51 */         chain.classes = classes;
/*  52 */         chain.generic = generic;
/*  53 */         chain.method = method.getPrintName();
/*  54 */         chain.closure = (Closure)function;
/*  55 */         return chain;
/*     */       } 
/*     */     } 
/*  58 */     return null;
/*     */   }
/*     */   
/*     */   public Map<Symbol, SEXP> createMetadata() {
/*  62 */     Map<Symbol, SEXP> metadata = new HashMap<>();
/*  63 */     metadata.put(CLASS, this.classes);
/*  64 */     metadata.put(METHOD, new StringArrayVector(new String[] { this.method }));
/*  65 */     metadata.put(GENERIC, StringVector.valueOf(this.generic));
/*  66 */     if (this.group != null) {
/*  67 */       metadata.put(GROUP, StringVector.valueOf(this.group));
/*     */     }
/*  69 */     return metadata;
/*     */   }
/*     */   
/*     */   public Closure getClosure() {
/*  73 */     return this.closure;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DispatchChain withGenericArgument(SEXP sexp) {
/*  82 */     if (sexp instanceof StringVector) {
/*  83 */       this.generic = ((StringVector)sexp).getElementAsString(0);
/*     */     }
/*  85 */     return this;
/*     */   }
/*     */   
/*     */   public DispatchChain withObjectArgument(SEXP sexp) {
/*  89 */     if (sexp != Null.INSTANCE) {
/*  90 */       throw new EvalException("oops, NextMethod(object!=null) is not yet implemented", new Object[0]);
/*     */     }
/*  92 */     return this;
/*     */   }
/*     */   
/*     */   public boolean next() {
/*  96 */     StringVector previous = (StringVector)this.classes;
/*     */     
/*  98 */     if (previous.length() <= 1) {
/*  99 */       this.classes = (Vector)Null.INSTANCE;
/* 100 */       return false;
/*     */     } 
/* 102 */     StringVector.Builder newClass = StringVector.newBuilder();
/* 103 */     for (int i = 1; i != previous.length(); i++) {
/* 104 */       newClass.add(previous.getElementAsString(i));
/*     */     }
/* 106 */     newClass.setAttribute(Symbol.get("previous"), (SEXP)previous);
/* 107 */     this.classes = (Vector)newClass.build();
/*     */ 
/*     */     
/* 110 */     return false;
/*     */   }
/*     */   
/*     */   public Symbol getGenericSymbol() {
/* 114 */     return Symbol.get(this.generic);
/*     */   }
/*     */   
/*     */   public Symbol getMethodSymbol() {
/* 118 */     return Symbol.get(this.method);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/eval/DispatchChain.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */