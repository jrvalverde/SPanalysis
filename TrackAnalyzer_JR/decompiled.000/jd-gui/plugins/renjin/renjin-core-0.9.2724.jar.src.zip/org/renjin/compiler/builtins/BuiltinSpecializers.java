/*    */ package org.renjin.compiler.builtins;
/*    */ 
/*    */ import java.util.Map;
/*    */ import java.util.concurrent.ExecutionException;
/*    */ import org.renjin.compiler.ir.exception.InternalCompilerException;
/*    */ import org.renjin.primitives.Primitives;
/*    */ import org.renjin.repackaged.guava.cache.CacheBuilder;
/*    */ import org.renjin.repackaged.guava.cache.CacheLoader;
/*    */ import org.renjin.repackaged.guava.cache.LoadingCache;
/*    */ import org.renjin.repackaged.guava.collect.Maps;
/*    */ import org.renjin.sexp.Symbol;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BuiltinSpecializers
/*    */ {
/* 35 */   public static final BuiltinSpecializers INSTANCE = new BuiltinSpecializers();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 41 */   private final Map<String, Specializer> specializers = Maps.newHashMap();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private final LoadingCache<String, Specializer> cache;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public BuiltinSpecializers() {
/* 54 */     this.specializers.put("length", new GenericBuiltinGuard(new LengthSpecializer()));
/* 55 */     this.specializers.put("[<-", new GenericBuiltinGuard(new ReplaceSpecializer()));
/* 56 */     this.specializers.put("[", new GenericBuiltinGuard(new SubsetSpecializer()));
/* 57 */     this.specializers.put("[[", new GenericBuiltinGuard(new SingleSubsetSpecializer()));
/* 58 */     this.specializers.put("c", new GenericBuiltinGuard(new CombineSpecializer()));
/* 59 */     this.specializers.put("is.array", new GenericBuiltinGuard(new IsArraySpecializer()));
/* 60 */     this.specializers.put("dim", new GenericBuiltinGuard(new DimSpecializer()));
/* 61 */     this.specializers.put("rep", new RepSpecializer());
/* 62 */     this.specializers.put("invisible", new InvisibleSpecializer());
/*    */     
/* 64 */     this.cache = CacheBuilder.newBuilder().build(new CacheLoader<String, Specializer>()
/*    */         {
/*    */           public Specializer load(String primitive) throws Exception {
/* 67 */             Symbol primitiveName = Symbol.get(primitive);
/* 68 */             Primitives.Entry entry = Primitives.getBuiltinEntry(primitiveName);
/* 69 */             if (entry == null) {
/* 70 */               entry = Primitives.getInternalEntry(primitiveName);
/*    */             }
/* 72 */             if (entry == null) {
/* 73 */               throw new IllegalStateException("No builtin entry for " + primitiveName);
/*    */             }
/* 75 */             AnnotationBasedSpecializer specializer = new AnnotationBasedSpecializer(entry);
/* 76 */             if (specializer.isGeneric()) {
/* 77 */               return new GenericBuiltinGuard(specializer);
/*    */             }
/* 79 */             return specializer;
/*    */           }
/*    */         });
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Specializer get(String primitiveName) {
/* 87 */     if (this.specializers.containsKey(primitiveName)) {
/* 88 */       return this.specializers.get(primitiveName);
/*    */     }
/*    */     
/*    */     try {
/* 92 */       return (Specializer)this.cache.get(primitiveName);
/* 93 */     } catch (ExecutionException e) {
/* 94 */       throw new InternalCompilerException(e);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/builtins/BuiltinSpecializers.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */