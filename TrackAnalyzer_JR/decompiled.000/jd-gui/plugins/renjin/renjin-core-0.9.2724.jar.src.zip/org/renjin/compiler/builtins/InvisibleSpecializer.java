/*    */ package org.renjin.compiler.builtins;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.renjin.compiler.ir.tac.RuntimeState;
/*    */ import org.renjin.sexp.Null;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InvisibleSpecializer
/*    */   implements Specializer
/*    */ {
/*    */   public Specialization trySpecialize(RuntimeState runtimeState, List<ArgumentBounds> arguments) {
/* 31 */     return new ConstantCall(Null.INSTANCE);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/builtins/InvisibleSpecializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */