/*    */ package org.renjin.parser;
/*    */ 
/*    */ import org.renjin.sexp.StringVector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StringLiterals
/*    */ {
/*    */   public static String format(String value, String naString) {
/* 36 */     if (StringVector.isNA(value)) {
/* 37 */       return naString;
/*    */     }
/* 39 */     StringBuilder sb = new StringBuilder("\"");
/* 40 */     appendEscaped(sb, value);
/* 41 */     sb.append('"');
/* 42 */     return sb.toString();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static void appendEscaped(StringBuilder buf, String s) {
/* 48 */     for (int i = 0; i != s.length(); i++) {
/*    */       
/* 50 */       int codePoint = s.codePointAt(i);
/* 51 */       if (codePoint == 10) {
/* 52 */         buf.append("\\n");
/* 53 */       } else if (codePoint == 13) {
/* 54 */         buf.append("\\r");
/* 55 */       } else if (codePoint == 9) {
/* 56 */         buf.append("\\t");
/* 57 */       } else if (codePoint == 7) {
/* 58 */         buf.append("\\a");
/* 59 */       } else if (codePoint == 8) {
/* 60 */         buf.append("\\b");
/* 61 */       } else if (codePoint == 12) {
/* 62 */         buf.append("\\f");
/* 63 */       } else if (codePoint == 11) {
/* 64 */         buf.append("\\v");
/* 65 */       } else if (codePoint == 34) {
/* 66 */         buf.append("\\\"");
/* 67 */       } else if (codePoint == 92) {
/* 68 */         buf.append("\\\\");
/* 69 */       } else if (codePoint < 32 || codePoint > 126) {
/* 70 */         appendUnicodeEscape(buf, codePoint);
/*    */       } else {
/* 72 */         buf.appendCodePoint(codePoint);
/*    */       } 
/*    */     } 
/*    */   }
/*    */   
/*    */   private static void appendUnicodeEscape(StringBuilder buf, int codePoint) {
/* 78 */     buf.append("\\u");
/* 79 */     if (codePoint < 15) {
/* 80 */       buf.append("000");
/* 81 */     } else if (codePoint < 255) {
/* 82 */       buf.append("00");
/* 83 */     } else if (codePoint < 4095) {
/* 84 */       buf.append("0");
/*    */     } 
/* 86 */     buf.append(Integer.toHexString(codePoint));
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/parser/StringLiterals.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */