/*     */ package org.renjin.primitives.sequence;
/*     */ 
/*     */ import org.renjin.eval.Context;
/*     */ import org.renjin.eval.EvalException;
/*     */ import org.renjin.invoke.annotations.Builtin;
/*     */ import org.renjin.invoke.annotations.Current;
/*     */ import org.renjin.invoke.annotations.Internal;
/*     */ import org.renjin.repackaged.guava.annotations.VisibleForTesting;
/*     */ import org.renjin.sexp.AtomicVector;
/*     */ import org.renjin.sexp.DoubleVector;
/*     */ import org.renjin.sexp.IntVector;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Sequences
/*     */ {
/*     */   @Builtin(":")
/*     */   public static AtomicVector colon(@Current Context context, SEXP n1, SEXP n2) {
/*  37 */     if (n1.inherits("factor") && n2.inherits("factor")) {
/*  38 */       return crossColon(n1, n2);
/*     */     }
/*     */     
/*  41 */     return colonSequence(context, n1, n2);
/*     */   }
/*     */ 
/*     */   
/*     */   private static AtomicVector crossColon(SEXP n1, SEXP n2) {
/*  46 */     throw new UnsupportedOperationException("crossColon not yet implemented");
/*     */   }
/*     */   
/*     */   public static AtomicVector colonSequence(Context context, SEXP s1, SEXP s2) {
/*  50 */     assertScalar(context, s1);
/*  51 */     assertScalar(context, s2);
/*     */     
/*  53 */     double n1 = s1.asReal();
/*  54 */     double n2 = s2.asReal();
/*     */     
/*  56 */     assertNotNa(n1);
/*  57 */     assertNotNa(n2);
/*     */     
/*  59 */     return (new Range(n1, n2)).vector();
/*     */   }
/*     */ 
/*     */   
/*     */   private static void assertNotNa(double r1) {
/*  64 */     if (DoubleVector.isNaN(r1)) {
/*  65 */       throw new EvalException("NA/NaN argument", new Object[0]);
/*     */     }
/*     */   }
/*     */   
/*     */   private static void assertScalar(Context context, SEXP exp) {
/*  70 */     if (exp.length() == 0)
/*  71 */       throw new EvalException("argument of length 0", new Object[0]); 
/*  72 */     if (exp.length() > 1) {
/*  73 */       context.warn(String.format("numerical expression has %d elements: only the first used", new Object[] { Integer.valueOf(exp.length()) }));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @Internal("rep.int")
/*     */   public static Vector repeatInt(Vector x, Vector timesVector) {
/*  80 */     if (timesVector.length() == 1) {
/*  81 */       int times = timesVector.getElementAsInt(0);
/*  82 */       Vector.Builder builder = x.newBuilderWithInitialSize(x.length() * times);
/*  83 */       int count = 0;
/*  84 */       while (times > 0) {
/*  85 */         for (int j = 0; j != x.length(); j++) {
/*  86 */           builder.setFrom(count++, (SEXP)x, j);
/*     */         }
/*  88 */         times--;
/*     */       } 
/*  90 */       return builder.build();
/*     */     } 
/*  92 */     if (timesVector.length() != x.length()) {
/*  93 */       throw new EvalException("Invalid 'times' value: times must be the same length as x", new Object[0]);
/*     */     }
/*  95 */     Vector.Builder result = x.newBuilderWithInitialCapacity(x.length());
/*  96 */     for (int i = 0; i != x.length(); i++) {
/*  97 */       int times = timesVector.getElementAsInt(i);
/*  98 */       while (times > 0) {
/*  99 */         result.addFrom((SEXP)x, i);
/* 100 */         times--;
/*     */       } 
/*     */     } 
/* 103 */     return result.build();
/*     */   }
/*     */   
/*     */   @VisibleForTesting
/*     */   static class Range
/*     */   {
/*     */     boolean useInteger;
/*     */     private double range;
/*     */     double count;
/*     */     final double n1;
/*     */     final double n2;
/*     */     
/*     */     public Range(double n1, double n2) {
/* 116 */       this.n1 = n1;
/* 117 */       this.n2 = n2;
/* 118 */       this.range = Math.abs(n2 - n1);
/* 119 */       this.count = this.range + 1.0D + 2.220446E-16D;
/*     */       
/* 121 */       determineType();
/*     */     }
/*     */     
/*     */     private void determineType() {
/* 125 */       int in1 = (int)this.n1;
/* 126 */       this.useInteger = (this.n1 == in1);
/* 127 */       if (this.useInteger) {
/* 128 */         if (this.n1 <= -2.147483648E9D || this.n1 > 2.147483647E9D) {
/* 129 */           this.useInteger = false;
/*     */         } else {
/*     */           
/* 132 */           double upperBound = this.n1 + ((this.n1 <= this.n2) ? (this.count - 1.0D) : -(this.count - 1.0D));
/* 133 */           if (upperBound <= -2.147483648E9D || upperBound > 2.147483647E9D) {
/* 134 */             this.useInteger = false;
/*     */           }
/*     */         } 
/*     */       }
/*     */     }
/*     */     
/*     */     public AtomicVector vector() {
/* 141 */       if (this.useInteger) {
/* 142 */         return IntSequence.fromTo(this.n1, this.n2);
/*     */       }
/* 144 */       return DoubleSequence.fromTo(this.n1, this.n2);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @Builtin
/*     */   public static IntVector seq_along(SEXP exp) {
/* 151 */     return new IntSequence(1, 1, exp.length());
/*     */   }
/*     */   
/*     */   @Builtin
/*     */   public static IntVector seq_len(int length) {
/* 156 */     return new IntSequence(1, 1, length);
/*     */   }
/*     */   
/*     */   private static SEXP newSequence(double from, double by, double to, int length) {
/* 160 */     if (isIntegerRange(from, to, by)) {
/* 161 */       return (SEXP)new IntSequence((int)from, (int)by, length);
/*     */     }
/* 163 */     return (SEXP)new DoubleSequence(from, by, length);
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean isIntegerRange(double from, double to, double by) {
/* 168 */     return (by == (int)by && from <= 2.147483647E9D && from >= -2.147483648E9D && to <= 2.147483647E9D && to >= -2.147483648E9D);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/sequence/Sequences.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */