/*     */ package org.renjin.compiler.ir.ssa;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.renjin.compiler.cfg.FlowEdge;
/*     */ import org.renjin.compiler.codegen.EmitContext;
/*     */ import org.renjin.compiler.ir.ValueBounds;
/*     */ import org.renjin.compiler.ir.tac.expressions.Expression;
/*     */ import org.renjin.compiler.ir.tac.expressions.Variable;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ import org.renjin.repackaged.asm.commons.InstructionAdapter;
/*     */ import org.renjin.repackaged.guava.base.Joiner;
/*     */ import org.renjin.repackaged.guava.collect.Lists;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PhiFunction
/*     */   implements Expression
/*     */ {
/*     */   private List<Variable> arguments;
/*     */   private List<FlowEdge> incomingEdges;
/*     */   
/*     */   public PhiFunction(Variable variable, List<FlowEdge> incomingEdges) {
/*  41 */     if (incomingEdges.size() < 2) {
/*  42 */       throw new IllegalArgumentException("variable=" + variable + ", count=" + incomingEdges.size() + " (count must be >= 2)");
/*     */     }
/*  44 */     this.incomingEdges = Lists.newArrayList(incomingEdges);
/*  45 */     this.arguments = Lists.newArrayList();
/*  46 */     for (int i = 0; i != incomingEdges.size(); i++) {
/*  47 */       this.arguments.add(variable);
/*     */     }
/*     */   }
/*     */   
/*     */   public List<Variable> getArguments() {
/*  52 */     return this.arguments;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  57 */     return "Φ(" + Joiner.on(", ").join(this.arguments) + ")";
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPure() {
/*  62 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int load(EmitContext emitContext, InstructionAdapter mv) {
/*  67 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public Type getType() {
/*  72 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public ValueBounds updateTypeBounds(Map<Expression, ValueBounds> typeMap) {
/*  77 */     Iterator<Variable> it = this.arguments.iterator();
/*  78 */     ValueBounds bounds = ((Variable)it.next()).updateTypeBounds(typeMap);
/*     */     
/*  80 */     while (it.hasNext()) {
/*  81 */       bounds = bounds.union(((Variable)it.next()).updateTypeBounds(typeMap));
/*     */     }
/*  83 */     return bounds;
/*     */   }
/*     */ 
/*     */   
/*     */   public ValueBounds getValueBounds() {
/*  88 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public List<FlowEdge> getIncomingEdges() {
/*  92 */     return this.incomingEdges;
/*     */   }
/*     */   
/*     */   public void setVersionNumber(int argumentIndex, int versionNumber) {
/*  96 */     this.arguments.set(argumentIndex, ((Variable)this.arguments.get(argumentIndex)).getVersion(versionNumber));
/*     */   }
/*     */   
/*     */   public Variable getArgument(int j) {
/* 100 */     return this.arguments.get(j);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setChild(int childIndex, Expression child) {
/* 105 */     this.arguments.set(childIndex, (Variable)child);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getChildCount() {
/* 110 */     return this.arguments.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public Expression childAt(int index) {
/* 115 */     return (Expression)this.arguments.get(index);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/ir/ssa/PhiFunction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */