/*    */ package org.renjin.packaging;
/*    */ 
/*    */ import java.io.ByteArrayInputStream;
/*    */ import java.io.DataInputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import org.renjin.eval.Context;
/*    */ import org.renjin.primitives.io.serialization.RDataReader;
/*    */ import org.renjin.repackaged.guava.base.Function;
/*    */ import org.renjin.sexp.ListVector;
/*    */ import org.renjin.sexp.NamedValue;
/*    */ import org.renjin.sexp.SEXP;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LazyLoadFrame
/*    */ {
/*    */   private static final int OLD_VERSION = 1;
/*    */   private static final int VERSION = 2;
/*    */   
/*    */   public static Iterable<NamedValue> load(Context context, Function<String, InputStream> resourceProvider) throws IOException {
/* 41 */     DataInputStream din = new DataInputStream((InputStream)resourceProvider.apply("environment"));
/* 42 */     int version = din.readInt();
/* 43 */     if (version == 1) {
/* 44 */       return readOldVersion(din);
/*    */     }
/* 46 */     if (version != 2) {
/* 47 */       throw new IOException("Unsupported version: " + version);
/*    */     }
/*    */     
/* 50 */     int count = din.readInt();
/* 51 */     ListVector.NamedBuilder vector = new ListVector.NamedBuilder(0, count);
/*    */     
/* 53 */     for (int i = 0; i != count; i++) {
/* 54 */       String name = din.readUTF();
/* 55 */       int length = din.readInt();
/* 56 */       if (length < 0) {
/* 57 */         vector.add(name, (SEXP)new SerializedPromise(resourceProvider, name));
/*    */       } else {
/* 59 */         byte[] serialized = new byte[length];
/* 60 */         din.readFully(serialized);
/* 61 */         RDataReader reader = new RDataReader(context, new ByteArrayInputStream(serialized));
/* 62 */         vector.add(name, reader.readFile());
/*    */       } 
/*    */     } 
/* 65 */     din.close();
/* 66 */     return vector.build().namedValues();
/*    */   }
/*    */   
/*    */   private static Iterable<NamedValue> readOldVersion(DataInputStream din) throws IOException {
/* 70 */     int count = din.readInt();
/* 71 */     ListVector.NamedBuilder vector = new ListVector.NamedBuilder(0, count);
/*    */     
/* 73 */     for (int i = 0; i != count; i++) {
/* 74 */       String name = din.readUTF();
/* 75 */       int byteCount = din.readInt();
/* 76 */       byte[] bytes = new byte[byteCount];
/* 77 */       din.readFully(bytes);
/* 78 */       vector.add(name, (SEXP)new SerializedPromise1(bytes));
/*    */     } 
/* 80 */     din.close();
/* 81 */     return vector.build().namedValues();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/packaging/LazyLoadFrame.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */