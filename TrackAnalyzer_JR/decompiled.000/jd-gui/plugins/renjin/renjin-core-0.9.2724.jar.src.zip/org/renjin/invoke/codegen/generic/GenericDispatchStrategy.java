/*    */ package org.renjin.invoke.codegen.generic;
/*    */ 
/*    */ import com.sun.codemodel.JBlock;
/*    */ import com.sun.codemodel.JCodeModel;
/*    */ import com.sun.codemodel.JExpr;
/*    */ import com.sun.codemodel.JExpression;
/*    */ import com.sun.codemodel.JInvocation;
/*    */ import com.sun.codemodel.JType;
/*    */ import java.util.List;
/*    */ import org.renjin.invoke.codegen.ApplyMethodContext;
/*    */ import org.renjin.invoke.codegen.VarArgParser;
/*    */ import org.renjin.sexp.AbstractSEXP;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GenericDispatchStrategy
/*    */ {
/*    */   protected final JCodeModel codeModel;
/*    */   
/*    */   public GenericDispatchStrategy(JCodeModel codeModel) {
/* 36 */     this.codeModel = codeModel;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void afterFirstArgIsEvaluated(ApplyMethodContext context, JExpression functionCall, JExpression arguments, JBlock parent, JExpression argument) {}
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void beforeTypeMatching(ApplyMethodContext context, JExpression functionCall, List<JExpression> arguments, JBlock parent) {}
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected JInvocation fastIsObject(JExpression argument) {
/* 53 */     return JExpr.invoke((JExpression)JExpr.cast((JType)this.codeModel.ref(AbstractSEXP.class), argument), "isObject");
/*    */   }
/*    */   
/*    */   public void beforePrimitiveCalled(JBlock parent, VarArgParser args, ApplyMethodContext context, JExpression call) {}
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/codegen/generic/GenericDispatchStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */