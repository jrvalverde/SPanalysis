/*    */ package org.renjin.primitives.packaging;
/*    */ 
/*    */ import org.renjin.sexp.Environment;
/*    */ import org.renjin.sexp.SEXP;
/*    */ import org.renjin.sexp.Symbol;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BaseNamespace
/*    */   extends Namespace
/*    */ {
/*    */   public BaseNamespace(Environment baseNamespaceEnvironment) {
/* 28 */     super(new BasePackage(), baseNamespaceEnvironment);
/*    */     try {
/* 30 */       this.libraries.add(new DllInfo("appl", Class.forName("org.renjin.appl.Appl")));
/* 31 */       this.libraries.add(new DllInfo("base", Class.forName("org.renjin.base.Base")));
/* 32 */     } catch (ClassNotFoundException e) {
/* 33 */       throw new RuntimeException("Could not load base package", e);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public SEXP getExport(Symbol entry) {
/* 40 */     return getEntry(entry);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/packaging/BaseNamespace.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */