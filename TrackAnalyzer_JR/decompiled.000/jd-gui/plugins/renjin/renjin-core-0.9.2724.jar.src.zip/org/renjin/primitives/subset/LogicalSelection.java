/*     */ package org.renjin.primitives.subset;
/*     */ 
/*     */ import org.renjin.eval.Context;
/*     */ import org.renjin.eval.EvalException;
/*     */ import org.renjin.sexp.AtomicVector;
/*     */ import org.renjin.sexp.IntVector;
/*     */ import org.renjin.sexp.ListVector;
/*     */ import org.renjin.sexp.LogicalVector;
/*     */ import org.renjin.sexp.Null;
/*     */ import org.renjin.sexp.PairList;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.Symbols;
/*     */ import org.renjin.sexp.Vector;
/*     */ import org.renjin.util.NamesBuilder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class LogicalSelection
/*     */   implements SelectionStrategy
/*     */ {
/*     */   private final LogicalVector mask;
/*     */   
/*     */   public LogicalSelection(LogicalVector mask) {
/*  37 */     this.mask = mask;
/*     */   }
/*     */ 
/*     */   
/*     */   public SEXP getVectorSubset(Context context, Vector source, boolean drop) {
/*  42 */     LogicalSubscript subscript = new LogicalSubscript(this.mask, source.length());
/*     */     
/*  44 */     return (SEXP)VectorIndexSelection.buildSelection(source, subscript, drop);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector replaceAtomicVectorElements(Context context, AtomicVector source, Vector replacements) {
/*  59 */     source = (AtomicVector)context.materialize((Vector)source);
/*  60 */     replacements = context.materialize(replacements);
/*     */     
/*  62 */     if (this.mask.length() <= source.length()) {
/*  63 */       return buildMaskedReplacement((Vector)source, replacements);
/*     */     }
/*  65 */     return buildExtendedReplacement((Vector)source, replacements);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ListVector replaceListElements(Context context, ListVector source, Vector replacement) {
/*  73 */     if (replacement == Null.INSTANCE) {
/*  74 */       if (this.mask.length() == 0) {
/*  75 */         return source;
/*     */       }
/*  77 */       return ListSubsetting.removeListElements(source, new LogicalPredicate(this.mask));
/*     */     } 
/*     */ 
/*     */     
/*  81 */     if (this.mask.length() <= source.length()) {
/*  82 */       return (ListVector)buildMaskedReplacement((Vector)source, replacement);
/*     */     }
/*  84 */     return (ListVector)buildExtendedReplacement((Vector)source, replacement);
/*     */   }
/*     */ 
/*     */   
/*     */   private Vector buildExtendedReplacement(Vector source, Vector replacements) {
/*  89 */     assert source.length() < this.mask.length();
/*     */     
/*  91 */     int resultLength = this.mask.length();
/*  92 */     int sourceLength = source.length();
/*     */     
/*  94 */     Vector.Builder result = Vector.Type.widest(source, (SEXP)replacements).newBuilderWithInitialCapacity(resultLength);
/*     */ 
/*     */     
/*  97 */     AtomicVector sourceNames = source.getNames();
/*  98 */     NamesBuilder resultNames = null;
/*  99 */     if (sourceNames != Null.INSTANCE) {
/* 100 */       resultNames = NamesBuilder.withInitialCapacity(resultLength);
/*     */     }
/*     */ 
/*     */     
/* 104 */     int replacementIndex = 0;
/*     */     
/* 106 */     for (int i = 0; i < resultLength; i++) {
/* 107 */       int maskValue = this.mask.getElementAsRawLogical(i);
/* 108 */       if (maskValue == 0) {
/*     */         
/* 110 */         if (i < sourceLength) {
/* 111 */           result.addFrom((SEXP)source, i);
/* 112 */           if (resultNames != null) {
/* 113 */             resultNames.add(sourceNames.getElementAsString(i));
/*     */           }
/*     */         } else {
/* 116 */           result.addNA();
/* 117 */           if (resultNames != null) {
/* 118 */             resultNames.add("");
/*     */           }
/*     */         } 
/* 121 */       } else if (IntVector.isNA(maskValue)) {
/*     */         
/* 123 */         result.setNA(i);
/* 124 */         if (resultNames != null) {
/* 125 */           resultNames.add("");
/*     */         }
/*     */       } else {
/*     */         
/* 129 */         result.setFrom(i, (SEXP)replacements, replacementIndex);
/* 130 */         if (resultNames != null) {
/* 131 */           if (i < sourceLength) {
/* 132 */             resultNames.add(sourceNames.getElementAsString(i));
/*     */           } else {
/* 134 */             resultNames.add("");
/*     */           } 
/*     */         }
/* 137 */         replacementIndex++;
/* 138 */         if (replacementIndex >= replacements.length()) {
/* 139 */           replacementIndex = 0;
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 146 */     if (resultNames != null) {
/* 147 */       result.setAttribute(Symbols.NAMES, (SEXP)resultNames.build());
/*     */     }
/* 149 */     return result.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Vector buildMaskedReplacement(Vector source, Vector replacements) {
/* 156 */     Vector.Builder builder = source.newCopyBuilder(replacements.getVectorType());
/* 157 */     int maskIndex = 0;
/* 158 */     int resultIndex = 0;
/* 159 */     int replacementIndex = 0;
/*     */     
/* 161 */     int sourceLength = source.length();
/*     */     
/* 163 */     if (this.mask.length() > 0) {
/* 164 */       while (resultIndex < sourceLength) {
/* 165 */         int maskValue = this.mask.getElementAsRawLogical(maskIndex++);
/*     */         
/* 167 */         if (maskValue == 1) {
/* 168 */           if (replacements.length() == 0) {
/* 169 */             throw new EvalException("replacement has zero length", new Object[0]);
/*     */           }
/* 171 */           builder.setFrom(resultIndex, (SEXP)replacements, replacementIndex++);
/* 172 */           if (replacementIndex >= replacements.length()) {
/* 173 */             replacementIndex = 0;
/*     */           }
/*     */         } 
/* 176 */         resultIndex++;
/*     */         
/* 178 */         if (maskIndex >= this.mask.length()) {
/* 179 */           maskIndex = 0;
/*     */         }
/*     */       } 
/*     */     }
/* 183 */     return builder.build();
/*     */   }
/*     */ 
/*     */   
/*     */   public SEXP getSingleListElement(ListVector source, boolean exact) {
/* 188 */     throw new UnsupportedOperationException("[[ operator never uses logical subscripts");
/*     */   }
/*     */ 
/*     */   
/*     */   public AtomicVector getSingleAtomicVectorElement(AtomicVector source, boolean exact) {
/* 193 */     throw new UnsupportedOperationException("[[ operator never uses logical subscrpts");
/*     */   }
/*     */ 
/*     */   
/*     */   public Vector replaceSingleElement(Context context, AtomicVector source, Vector replacement) {
/* 198 */     throw new UnsupportedOperationException("[[ operator never uses logical subscrpts");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ListVector replaceSingleListElement(ListVector list, SEXP replacement) {
/* 204 */     throw new UnsupportedOperationException("[[ operator never uses logical subscrpts");
/*     */   }
/*     */ 
/*     */   
/*     */   public SEXP replaceSinglePairListElement(PairList.Node list, SEXP replacement) {
/* 209 */     throw new UnsupportedOperationException("[[ operator never uses logical subscrpts");
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/subset/LogicalSelection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */