/*     */ package org.renjin.parser;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.PushbackReader;
/*     */ import java.io.Reader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RLexerReader
/*     */ {
/*     */   private static final int PUSHBACK_BUFSIZE = 16;
/*  31 */   private int[] pushback = new int[16];
/*  32 */   private int npush = 0;
/*     */   
/*     */   private Reader reader;
/*     */   
/*  36 */   private int prevpos = 0;
/*  37 */   private int[] prevlines = new int[16];
/*  38 */   private int[] prevcols = new int[16];
/*  39 */   private int[] prevbytes = new int[16];
/*     */   
/*  41 */   private int lineNumber = 0;
/*  42 */   private int charIndex = -1;
/*  43 */   private int columnNumber = -1;
/*     */ 
/*     */   
/*     */   public RLexerReader(Reader reader) {
/*  47 */     this.reader = new PushbackReader(reader);
/*     */   }
/*     */   
/*     */   public Position getPosition() {
/*  51 */     return new Position(this.lineNumber, this.columnNumber, this.charIndex);
/*     */   }
/*     */ 
/*     */   
/*     */   public int read() throws IOException {
/*     */     int c;
/*  57 */     if (this.npush != 0) {
/*  58 */       c = this.pushback[--this.npush];
/*     */     } else {
/*     */       try {
/*  61 */         c = this.reader.read();
/*  62 */       } catch (IOException e) {
/*  63 */         throw new RLexException("IOException while reading", e);
/*     */       } 
/*     */     } 
/*     */     
/*  67 */     this.prevpos = (this.prevpos + 1) % 16;
/*  68 */     this.prevcols[this.prevpos] = this.columnNumber;
/*  69 */     this.prevlines[this.prevpos] = this.lineNumber;
/*  70 */     this.prevbytes[this.prevpos] = this.charIndex;
/*     */     
/*  72 */     if (c == 10) {
/*  73 */       this.lineNumber++;
/*  74 */       this.columnNumber = -1;
/*  75 */       this.charIndex = -1;
/*     */     } else {
/*  77 */       this.columnNumber++;
/*  78 */       this.charIndex++;
/*     */     } 
/*     */     
/*  81 */     if (c == 9) {
/*  82 */       this.columnNumber = this.columnNumber + 7 & 0xFFFFFFF8;
/*     */     }
/*     */     
/*  85 */     return c;
/*     */   }
/*     */   
/*     */   public int unread(int c) {
/*  89 */     this.lineNumber = this.prevlines[this.prevpos];
/*  90 */     this.columnNumber = this.prevcols[this.prevpos];
/*  91 */     this.charIndex = this.prevbytes[this.prevpos];
/*  92 */     this.prevpos = (this.prevpos + 16 - 1) % 16;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  99 */     if (this.npush >= 16) {
/* 100 */       throw new RuntimeException("Pusback buffer exceeded");
/*     */     }
/* 102 */     this.pushback[this.npush++] = c;
/* 103 */     return c;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLineNumber() {
/* 111 */     return this.lineNumber;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getColumnNumber() {
/* 118 */     return this.columnNumber;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getCharacterIndex() {
/* 125 */     return this.charIndex;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setLineNumber(int lineNumber) {
/* 130 */     this.lineNumber = lineNumber;
/* 131 */     this.columnNumber = 0;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/parser/RLexerReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */