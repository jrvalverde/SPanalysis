/*    */ package org.renjin.invoke.reflection.converters;
/*    */ 
/*    */ import org.renjin.sexp.IntArrayVector;
/*    */ import org.renjin.sexp.IntVector;
/*    */ import org.renjin.sexp.SEXP;
/*    */ import org.renjin.sexp.Vector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IntegerConverter
/*    */   extends PrimitiveScalarConverter<Number>
/*    */ {
/* 31 */   public static final IntegerConverter INSTANCE = new IntegerConverter();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SEXP convertToR(Number value) {
/* 38 */     if (value == null) {
/* 39 */       return (SEXP)new IntArrayVector(new int[] { Integer.MIN_VALUE });
/*    */     }
/* 41 */     return (SEXP)new IntArrayVector(new int[] { value.intValue() });
/*    */   }
/*    */ 
/*    */   
/*    */   public static boolean accept(Class<int> clazz) {
/* 46 */     return (clazz == int.class || clazz == Integer.class || clazz == short.class || clazz == Short.class);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Vector.Type getVectorType() {
/* 53 */     return IntVector.VECTOR_TYPE;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Object getFirstElement(Vector value) {
/* 58 */     return Integer.valueOf(value.getElementAsInt(0));
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean acceptsSEXP(SEXP exp) {
/* 63 */     return exp instanceof IntVector;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int getSpecificity() {
/* 69 */     return 2;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/reflection/converters/IntegerConverter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */