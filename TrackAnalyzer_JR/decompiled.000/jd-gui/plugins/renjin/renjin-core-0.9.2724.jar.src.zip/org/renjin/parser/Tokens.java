package org.renjin.parser;

public class Tokens {
  public static final char LBRACE = '{';
  
  public static final char RBRACE = '}';
  
  public static final int R_EOF = -1;
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/parser/Tokens.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */