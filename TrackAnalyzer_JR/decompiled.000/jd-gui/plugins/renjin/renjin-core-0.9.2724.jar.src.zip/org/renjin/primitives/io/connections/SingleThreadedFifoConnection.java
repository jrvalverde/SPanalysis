/*     */ package org.renjin.primitives.io.connections;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PrintWriter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SingleThreadedFifoConnection
/*     */   implements Connection
/*     */ {
/*  42 */   private ByteArrayOutputStream out = new ByteArrayOutputStream();
/*  43 */   private PrintWriter writer = new PrintWriter(this.out);
/*     */   
/*     */   private PushbackBufferedReader reader;
/*     */   
/*     */   public InputStream getInputStream() throws IOException {
/*  48 */     return new ByteArrayInputStream(getContent());
/*     */   }
/*     */   
/*     */   protected byte[] getContent() {
/*  52 */     this.writer.flush();
/*  53 */     byte[] content = this.out.toByteArray();
/*  54 */     this.out.reset();
/*  55 */     return content;
/*     */   }
/*     */ 
/*     */   
/*     */   public OutputStream getOutputStream() throws IOException {
/*  60 */     return this.out;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isOpen() {
/*  66 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void flush() throws IOException {
/*  71 */     this.writer.flush();
/*     */   }
/*     */ 
/*     */   
/*     */   public PushbackBufferedReader getReader() throws IOException {
/*  76 */     return this
/*     */       
/*  78 */       .reader = new PushbackBufferedReader(new InputStreamReader(new ByteArrayInputStream(getContent())));
/*     */   }
/*     */ 
/*     */   
/*     */   public PrintWriter getPrintWriter() {
/*  83 */     return this.writer;
/*     */   }
/*     */ 
/*     */   
/*     */   public PrintWriter getOpenPrintWriter() {
/*  88 */     return this.writer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void open(OpenSpec spec) throws IOException {}
/*     */ 
/*     */ 
/*     */   
/*     */   public String getClassName() {
/* 104 */     return "fifo";
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDescription() {
/* 109 */     return "";
/*     */   }
/*     */ 
/*     */   
/*     */   public String getMode() {
/* 114 */     return "rw";
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canRead() {
/* 119 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canWrite() {
/* 124 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Connection.Type getType() {
/* 130 */     return Connection.Type.TEXT;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/io/connections/SingleThreadedFifoConnection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */