/*    */ package org.renjin.compiler.ir.tac.functions;
/*    */ 
/*    */ import org.renjin.compiler.ir.tac.IRBodyBuilder;
/*    */ import org.renjin.compiler.ir.tac.IRLabel;
/*    */ import org.renjin.compiler.ir.tac.expressions.CmpGE;
/*    */ import org.renjin.compiler.ir.tac.expressions.Constant;
/*    */ import org.renjin.compiler.ir.tac.expressions.ElementAccess;
/*    */ import org.renjin.compiler.ir.tac.expressions.EnvironmentVariable;
/*    */ import org.renjin.compiler.ir.tac.expressions.Expression;
/*    */ import org.renjin.compiler.ir.tac.expressions.Increment;
/*    */ import org.renjin.compiler.ir.tac.expressions.LValue;
/*    */ import org.renjin.compiler.ir.tac.expressions.Length;
/*    */ import org.renjin.compiler.ir.tac.expressions.LocalVariable;
/*    */ import org.renjin.compiler.ir.tac.expressions.SimpleExpression;
/*    */ import org.renjin.compiler.ir.tac.expressions.Temp;
/*    */ import org.renjin.compiler.ir.tac.statements.Assignment;
/*    */ import org.renjin.compiler.ir.tac.statements.GotoStatement;
/*    */ import org.renjin.compiler.ir.tac.statements.IfStatement;
/*    */ import org.renjin.compiler.ir.tac.statements.Statement;
/*    */ import org.renjin.sexp.Function;
/*    */ import org.renjin.sexp.FunctionCall;
/*    */ import org.renjin.sexp.SEXP;
/*    */ import org.renjin.sexp.Symbol;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ForTranslator
/*    */   extends FunctionCallTranslator
/*    */ {
/*    */   public Expression translateToExpression(IRBodyBuilder builder, TranslationContext context, Function resolvedFunction, FunctionCall call) {
/* 36 */     addForLoop(builder, context, call);
/*    */     
/* 38 */     return (Expression)Constant.NULL;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void addStatement(IRBodyBuilder builder, TranslationContext context, Function resolvedFunction, FunctionCall call) {
/* 44 */     addForLoop(builder, context, call);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   private void addForLoop(IRBodyBuilder factory, TranslationContext context, FunctionCall call) {
/* 50 */     SimpleExpression simpleExpression = factory.translateSimpleExpression(context, call.getArgument(1));
/*    */ 
/*    */     
/* 53 */     LocalVariable counter = factory.newLocalVariable("i");
/* 54 */     factory.addStatement((Statement)new Assignment((LValue)counter, (Expression)new Constant(0)));
/*    */     
/* 56 */     buildLoop(context, factory, call, (Expression)simpleExpression, (LValue)counter);
/*    */   }
/*    */   
/*    */   public static void buildLoop(TranslationContext parentContext, IRBodyBuilder factory, FunctionCall call, Expression vector, LValue counter) {
/* 60 */     Symbol symbol = (Symbol)call.getArgument(0);
/* 61 */     Temp length = factory.newTemp();
/*    */     
/* 63 */     EnvironmentVariable environmentVariable = factory.getEnvironmentVariable(symbol);
/*    */ 
/*    */     
/* 66 */     SEXP body = call.getArgument(2);
/*    */     
/* 68 */     IRLabel counterLabel = factory.newLabel();
/* 69 */     IRLabel bodyLabel = factory.newLabel();
/* 70 */     IRLabel nextLabel = factory.newLabel();
/* 71 */     IRLabel exitLabel = factory.newLabel();
/*    */     
/* 73 */     factory.addStatement((Statement)new Assignment((LValue)length, (Expression)new Length(vector)));
/*    */ 
/*    */     
/* 76 */     factory.addLabel(counterLabel);
/* 77 */     factory.addStatement((Statement)new IfStatement((Expression)new CmpGE((Expression)counter, (Expression)length), exitLabel, bodyLabel));
/*    */ 
/*    */     
/* 80 */     factory.addLabel(bodyLabel);
/* 81 */     factory.addStatement((Statement)new Assignment((LValue)environmentVariable, (Expression)new ElementAccess(vector, (Expression)counter)));
/*    */     
/* 83 */     LoopContext loopContext = new LoopContext(parentContext, nextLabel, exitLabel);
/* 84 */     factory.translateStatements(loopContext, body);
/*    */ 
/*    */     
/* 87 */     factory.addLabel(nextLabel);
/* 88 */     factory.addStatement((Statement)new Assignment(counter, (Expression)new Increment(counter)));
/* 89 */     factory.addStatement((Statement)new GotoStatement(counterLabel));
/*    */     
/* 91 */     factory.addLabel(exitLabel);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/ir/tac/functions/ForTranslator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */