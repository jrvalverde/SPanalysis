/*    */ package org.renjin.invoke.reflection.converters;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import org.renjin.sexp.ListVector;
/*    */ import org.renjin.sexp.SEXP;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CollectionConverter
/*    */   implements Converter<Iterable>
/*    */ {
/*    */   public static boolean accept(Class<?> clazz) {
/* 34 */     if (Collection.class.isAssignableFrom(clazz))
/*    */     {
/* 36 */       return true;
/*    */     }
/* 38 */     return false;
/*    */   }
/*    */ 
/*    */   
/* 42 */   private Converter elementConverter = RuntimeConverter.INSTANCE;
/*    */ 
/*    */   
/*    */   public SEXP convertToR(Iterable collection) {
/* 46 */     ListVector.Builder list = new ListVector.Builder();
/* 47 */     for (Object element : collection) {
/* 48 */       list.add(this.elementConverter.convertToR(element));
/*    */     }
/* 50 */     return (SEXP)list.build();
/*    */   }
/*    */ 
/*    */   
/*    */   public Object convertToJava(SEXP value) {
/* 55 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean acceptsSEXP(SEXP exp) {
/* 60 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int getSpecificity() {
/* 66 */     return 10;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/reflection/converters/CollectionConverter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */