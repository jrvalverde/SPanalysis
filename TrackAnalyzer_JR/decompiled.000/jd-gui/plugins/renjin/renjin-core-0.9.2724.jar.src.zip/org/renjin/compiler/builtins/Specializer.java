package org.renjin.compiler.builtins;

import java.util.List;
import org.renjin.compiler.ir.tac.RuntimeState;

public interface Specializer {
  Specialization trySpecialize(RuntimeState paramRuntimeState, List<ArgumentBounds> paramList);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/builtins/Specializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */