/*    */ package org.renjin.eval;
/*    */ 
/*    */ import org.renjin.primitives.special.ReturnException;
/*    */ import org.renjin.sexp.Closure;
/*    */ import org.renjin.sexp.Environment;
/*    */ import org.renjin.sexp.Frame;
/*    */ import org.renjin.sexp.FunctionCall;
/*    */ import org.renjin.sexp.PairList;
/*    */ import org.renjin.sexp.Promise;
/*    */ import org.renjin.sexp.PromisePairList;
/*    */ import org.renjin.sexp.SEXP;
/*    */ import org.renjin.sexp.Symbol;
/*    */ import org.renjin.sexp.Symbols;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Calls
/*    */ {
/*    */   public static SEXP applyClosure(Closure closure, Context context, Environment callingEnvironment, FunctionCall call, PairList promisedArgs, Frame suppliedEnvironment) {
/* 35 */     Context functionContext = context.beginFunction(callingEnvironment, call, closure, promisedArgs);
/* 36 */     Environment functionEnvironment = functionContext.getEnvironment();
/*    */     
/*    */     try {
/* 39 */       ClosureDispatcher.matchArgumentsInto(closure.getFormals(), promisedArgs, functionEnvironment);
/*    */ 
/*    */       
/* 42 */       for (Symbol name : suppliedEnvironment.getSymbols())
/*    */       {
/* 44 */         functionEnvironment.setVariableUnsafe(name, suppliedEnvironment.getVariable(name));
/*    */       }
/*    */       
/* 47 */       return functionContext.evaluate(closure.getBody(), functionEnvironment);
/*    */     }
/* 49 */     catch (ReturnException e) {
/*    */       
/* 51 */       if (e.getEnvironment() != functionEnvironment) {
/* 52 */         throw e;
/*    */       }
/* 54 */       return e.getValue();
/*    */     } finally {
/*    */       
/* 57 */       functionContext.exit();
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static PairList promiseArgs(PairList argumentList, Context context, Environment rho) {
/* 69 */     PairList.Builder list = new PairList.Builder();
/*    */     
/* 71 */     for (PairList.Node node : argumentList.nodes()) {
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 82 */       if (node.getValue().equals(Symbols.ELLIPSES)) {
/* 83 */         SEXP ellipsesValue = rho.findVariable(context, Symbols.ELLIPSES);
/* 84 */         if (ellipsesValue == Symbol.UNBOUND_VALUE) {
/* 85 */           throw new EvalException("'...' used in an incorrect context", new Object[0]);
/*    */         }
/* 87 */         PromisePairList dotExp = (PromisePairList)ellipsesValue;
/* 88 */         for (PairList.Node dotNode : dotExp.nodes())
/* 89 */           list.add(dotNode.getRawTag(), dotNode.getValue()); 
/*    */         continue;
/*    */       } 
/* 92 */       if (node.getValue() == Symbol.MISSING_ARG) {
/* 93 */         list.add(node.getRawTag(), node.getValue());
/*    */         continue;
/*    */       } 
/* 96 */       list.add(node.getRawTag(), (SEXP)Promise.repromise(rho, node.getValue()));
/*    */     } 
/*    */     
/* 99 */     return list.build();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/eval/Calls.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */