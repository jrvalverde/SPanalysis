/*     */ package org.renjin.primitives.io.serialization;
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.ByteOrder;
/*     */ import java.nio.IntBuffer;
/*     */ import java.nio.channels.Channels;
/*     */ import java.nio.channels.ReadableByteChannel;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.List;
/*     */ import org.apache.commons.math.complex.Complex;
/*     */ import org.renjin.eval.Context;
/*     */ import org.renjin.eval.EvalException;
/*     */ import org.renjin.parser.NumericLiterals;
/*     */ import org.renjin.primitives.Primitives;
/*     */ import org.renjin.primitives.sequence.IntSequence;
/*     */ import org.renjin.primitives.vector.ConvertingStringVector;
/*     */ import org.renjin.primitives.vector.RowNamesVector;
/*     */ import org.renjin.repackaged.guava.base.Charsets;
/*     */ import org.renjin.repackaged.guava.collect.Lists;
/*     */ import org.renjin.repackaged.guava.io.ByteSource;
/*     */ import org.renjin.sexp.AttributeMap;
/*     */ import org.renjin.sexp.CHARSEXP;
/*     */ import org.renjin.sexp.Closure;
/*     */ import org.renjin.sexp.ComplexArrayVector;
/*     */ import org.renjin.sexp.DoubleArrayVector;
/*     */ import org.renjin.sexp.Environment;
/*     */ import org.renjin.sexp.ExpressionVector;
/*     */ import org.renjin.sexp.ExternalPtr;
/*     */ import org.renjin.sexp.FunctionCall;
/*     */ import org.renjin.sexp.IntVector;
/*     */ import org.renjin.sexp.ListVector;
/*     */ import org.renjin.sexp.LogicalArrayVector;
/*     */ import org.renjin.sexp.Null;
/*     */ import org.renjin.sexp.PairList;
/*     */ import org.renjin.sexp.PrimitiveFunction;
/*     */ import org.renjin.sexp.Promise;
/*     */ import org.renjin.sexp.S4Object;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.StringArrayVector;
/*     */ import org.renjin.sexp.StringVector;
/*     */ import org.renjin.sexp.Symbol;
/*     */ import org.renjin.sexp.Symbols;
/*     */ import org.renjin.sexp.Vector;
/*     */ 
/*     */ public class RDataReader implements AutoCloseable {
/*     */   private InputStream conn;
/*     */   private StreamReader in;
/*     */   private int version;
/*     */   private Version writerVersion;
/*     */   private Version releaseVersion;
/*  57 */   private List<SEXP> referenceTable = Lists.newArrayList();
/*     */   
/*     */   private PersistentRestorer restorer;
/*     */   private ReadContext readContext;
/*     */   
/*     */   public RDataReader(Context context, InputStream conn) {
/*  63 */     this.readContext = new SessionReadContext(context.getSession());
/*  64 */     this.conn = conn;
/*     */   }
/*     */   
/*     */   public RDataReader(Context context, Environment rho, InputStream conn, PersistentRestorer restorer) {
/*  68 */     this(context, conn);
/*  69 */     this.restorer = restorer;
/*     */   }
/*     */   
/*     */   public RDataReader(InputStream conn) {
/*  73 */     this.readContext = new NullReadContext();
/*  74 */     this.conn = conn;
/*     */   }
/*     */   
/*     */   public SEXP readFile() throws IOException {
/*  78 */     byte streamType = readStreamType(this.conn);
/*  79 */     this.in = createStreamReader(streamType, this.conn);
/*  80 */     readAndVerifyVersion();
/*  81 */     return readExp();
/*     */   }
/*     */   
/*     */   protected void readAndVerifyVersion() throws IOException {
/*  85 */     this.version = this.in.readInt();
/*  86 */     this.writerVersion = new Version(this.in.readInt());
/*  87 */     this.releaseVersion = new Version(this.in.readInt());
/*     */     
/*  89 */     if (this.version != 2) {
/*  90 */       if (this.releaseVersion.isExperimental())
/*  91 */         throw new IOException(String.format("cannot read unreleased workspace version %d written by experimental R %s", new Object[] {
/*  92 */                 Integer.valueOf(this.version), this.writerVersion
/*     */               })); 
/*  94 */       throw new IOException(String.format("cannot read workspace version %d written by R %s; need R %s or newer", new Object[] {
/*  95 */               Integer.valueOf(this.version), this.releaseVersion, this.releaseVersion
/*     */             }));
/*     */     } 
/*     */   }
/*     */   
/*     */   public static boolean isRDataFile(ByteSource inputSupplier) throws IOException {
/* 101 */     try (InputStream in = inputSupplier.openStream()) {
/* 102 */       byte streamType = readStreamType(in);
/* 103 */       return (streamType != -1);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static byte readStreamType(InputStream in) throws IOException {
/* 108 */     byte[] bytes = new byte[7];
/* 109 */     bytes[0] = (byte)in.read();
/* 110 */     bytes[1] = (byte)in.read();
/*     */     
/* 112 */     if (bytes[1] == 10) {
/* 113 */       switch (bytes[0]) {
/*     */         case 65:
/*     */         case 66:
/*     */         case 88:
/* 117 */           return bytes[0];
/*     */       } 
/* 119 */       return -1;
/*     */     } 
/*     */     
/* 122 */     for (int i = 2; i != 7; i++) {
/* 123 */       bytes[i] = (byte)in.read();
/*     */     }
/*     */     
/* 126 */     String header = new String(bytes, 0, 5);
/* 127 */     if (header.equals("RDA2\n"))
/* 128 */       return 65; 
/* 129 */     if (header.equals("RDB2\n"))
/* 130 */       return 66; 
/* 131 */     if (header.equals("RDX2\n")) {
/* 132 */       return 88;
/*     */     }
/* 134 */     return -1;
/*     */   }
/*     */ 
/*     */   
/*     */   private static StreamReader createStreamReader(byte type, InputStream conn) throws IOException {
/* 139 */     switch (type) {
/*     */       case 66:
/*     */       case 88:
/* 142 */         return new XdrReader(conn);
/*     */       case 65:
/* 144 */         return new AsciiReader(conn);
/*     */     } 
/* 146 */     throw new IOException("Unknown format");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public SEXP readExp() throws IOException {
/* 152 */     int flags = this.in.readInt();
/* 153 */     switch (Flags.getType(flags)) {
/*     */       case 254:
/* 155 */         return (SEXP)Null.INSTANCE;
/*     */       case 242:
/* 157 */         return (SEXP)Environment.EMPTY;
/*     */       case 241:
/* 159 */         return (SEXP)this.readContext.getBaseEnvironment();
/*     */       case 253:
/* 161 */         return (SEXP)this.readContext.getGlobalEnvironment();
/*     */       case 252:
/* 163 */         return (SEXP)Symbol.UNBOUND_VALUE;
/*     */       case 251:
/* 165 */         return (SEXP)Symbol.MISSING_ARG;
/*     */       case 250:
/* 167 */         return (SEXP)this.readContext.getBaseNamespaceEnvironment();
/*     */       case 255:
/* 169 */         return readReference(flags);
/*     */       case 247:
/* 171 */         return readPersistentExp();
/*     */       case 1:
/* 173 */         return readSymbol();
/*     */       case 248:
/* 175 */         return readPackage();
/*     */       case 249:
/* 177 */         return readNamespace();
/*     */       case 4:
/* 179 */         return readEnv(flags);
/*     */       case 2:
/* 181 */         return (SEXP)readPairList(flags);
/*     */       case 6:
/* 183 */         return readLangExp(flags);
/*     */       case 3:
/* 185 */         return readClosure(flags);
/*     */       case 5:
/* 187 */         return readPromise(flags);
/*     */       case 17:
/* 189 */         return readDotExp(flags);
/*     */       case 22:
/* 191 */         return readExternalPointer(flags);
/*     */       case 23:
/* 193 */         return readWeakReference(flags);
/*     */       case 7:
/*     */       case 8:
/* 196 */         return readPrimitive(flags);
/*     */       case 9:
/* 198 */         return readCharExp(flags);
/*     */       case 10:
/* 200 */         return readLogical(flags);
/*     */       case 13:
/* 202 */         return readIntVector(flags);
/*     */       case 14:
/* 204 */         return readDoubleExp(flags);
/*     */       case 15:
/* 206 */         return readComplexExp(flags);
/*     */       case 16:
/* 208 */         return readStringVector(flags);
/*     */       case 19:
/* 210 */         return readListExp(flags);
/*     */       case 20:
/* 212 */         return readExpExp(flags);
/*     */       case 21:
/* 214 */         return readBytecode(flags);
/*     */       case 246:
/* 216 */         throw new IOException("this version of R cannot read class references");
/*     */       case 245:
/* 218 */         throw new IOException("this version of R cannot read generic function references");
/*     */       case 24:
/* 220 */         return rawRawVector(flags);
/*     */       case 25:
/* 222 */         return readS4XP(flags);
/*     */     } 
/* 224 */     throw new IOException(String.format("ReadItem: unknown type %d, perhaps written by later version of R", new Object[] {
/* 225 */             Integer.valueOf(Flags.getType(flags))
/*     */           }));
/*     */   }
/*     */ 
/*     */   
/*     */   private SEXP rawRawVector(int flags) throws IOException {
/* 231 */     int length = this.in.readInt();
/* 232 */     byte[] bytes = this.in.readString(length);
/* 233 */     AttributeMap attributes = readAttributes(flags);
/* 234 */     return (SEXP)new RawVector(bytes, attributes);
/*     */   }
/*     */   
/*     */   private SEXP readPromise(int flags) throws IOException {
/* 238 */     AttributeMap attributes = readAttributes(flags);
/* 239 */     SEXP env = readTag(flags);
/* 240 */     SEXP value = readExp();
/* 241 */     SEXP expr = readExp();
/*     */     
/* 243 */     if (env != Null.INSTANCE) {
/* 244 */       return (SEXP)this.readContext.createPromise(expr, (Environment)env);
/*     */     }
/* 246 */     return (SEXP)new Promise(expr, value);
/*     */   }
/*     */ 
/*     */   
/*     */   private SEXP readClosure(int flags) throws IOException {
/* 251 */     AttributeMap attributes = readAttributes(flags);
/* 252 */     Environment env = (Environment)readTag(flags);
/* 253 */     PairList formals = (PairList)readExp();
/* 254 */     SEXP body = readExp();
/*     */     
/* 256 */     return (SEXP)new Closure(env, formals, body, attributes);
/*     */   }
/*     */   
/*     */   private SEXP readLangExp(int flags) throws IOException {
/* 260 */     AttributeMap attributes = readAttributes(flags);
/* 261 */     SEXP tag = readTag(flags);
/* 262 */     SEXP function = readExp();
/* 263 */     PairList arguments = (PairList)readExp();
/* 264 */     return (SEXP)new FunctionCall(function, arguments, attributes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private SEXP readBytecode(int flags) throws IOException {
/* 277 */     int nReps = this.in.readInt();
/* 278 */     SEXP[] reps = new SEXP[nReps];
/* 279 */     return readBC1(reps);
/*     */   }
/*     */ 
/*     */   
/*     */   private SEXP readBC1(SEXP[] reps) throws IOException {
/* 284 */     SEXP code = readExp();
/*     */ 
/*     */     
/* 287 */     SEXP[] constants = readBytecodeConstants(reps);
/*     */ 
/*     */     
/* 290 */     return constants[0];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private SEXP[] readBytecodeConstants(SEXP[] reps) throws IOException {
/* 298 */     int nEntries = this.in.readInt();
/* 299 */     SEXP[] pool = new SEXP[nEntries];
/* 300 */     for (int i = 0; i < nEntries; i++) {
/* 301 */       int type = this.in.readInt();
/* 302 */       switch (type) {
/*     */         case 21:
/* 304 */           pool[i] = readBC1(reps);
/*     */           break;
/*     */         case 2:
/*     */         case 6:
/*     */         case 239:
/*     */         case 240:
/*     */         case 243:
/*     */         case 244:
/* 312 */           pool[i] = readBCLang(type, reps);
/*     */           break;
/*     */         default:
/* 315 */           pool[i] = readExp(); break;
/*     */       } 
/*     */     } 
/* 318 */     return pool; } private SEXP readBCLang(int type, SEXP[] reps) throws IOException { FunctionCall functionCall; PairList.Node ans;
/*     */     int pos;
/*     */     AttributeMap attributes;
/*     */     SEXP next;
/* 322 */     switch (type) {
/*     */       case 243:
/* 324 */         return reps[this.in.readInt()];
/*     */ 
/*     */ 
/*     */       
/*     */       case 2:
/*     */       case 6:
/*     */       case 239:
/*     */       case 240:
/*     */       case 244:
/* 333 */         pos = -1;
/* 334 */         if (type == 244) {
/* 335 */           pos = this.in.readInt();
/* 336 */           type = this.in.readInt();
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 341 */         switch (type) {
/*     */           case 239:
/*     */           case 240:
/* 344 */             attributes = readAttributeValues(0);
/*     */             break;
/*     */           
/*     */           default:
/* 348 */             attributes = AttributeMap.EMPTY;
/*     */             break;
/*     */         } 
/*     */ 
/*     */         
/* 353 */         switch (type) {
/*     */           case 6:
/*     */           case 240:
/* 356 */             functionCall = new FunctionCall((SEXP)Null.INSTANCE, (PairList)Null.INSTANCE, attributes);
/*     */             break;
/*     */           case 2:
/*     */           case 239:
/* 360 */             ans = new PairList.Node((SEXP)Null.INSTANCE, (SEXP)Null.INSTANCE, attributes, (PairList)Null.INSTANCE);
/*     */             break;
/*     */           
/*     */           default:
/* 364 */             throw new UnsupportedOperationException("BCLang type: " + type);
/*     */         } 
/*     */         
/* 367 */         if (pos >= 0) {
/* 368 */           reps[pos] = (SEXP)ans;
/*     */         }
/*     */         
/* 371 */         ans.setTag(readExp());
/* 372 */         ans.setValue(readBCLang(this.in.readInt(), reps));
/*     */         
/* 374 */         next = readBCLang(this.in.readInt(), reps);
/* 375 */         if (next != Null.INSTANCE) {
/* 376 */           ans.setNextNode((PairList.Node)next);
/*     */         }
/* 378 */         return (SEXP)ans;
/*     */     } 
/*     */ 
/*     */     
/* 382 */     return readExp(); }
/*     */ 
/*     */ 
/*     */   
/*     */   private SEXP readDotExp(int flags) throws IOException {
/* 387 */     return (SEXP)PromisePairList.Builder.fromPairList(readPairList(flags));
/*     */   }
/*     */ 
/*     */   
/*     */   private PairList readPairList(int flags) throws IOException {
/* 392 */     PairList.Node head = null;
/* 393 */     PairList.Node tail = null;
/*     */     
/* 395 */     while (Flags.getType(flags) != 254) {
/* 396 */       RowNamesVector rowNamesVector; AttributeMap attributes = readAttributes(flags);
/* 397 */       SEXP tag = readTag(flags);
/* 398 */       SEXP value = readExp();
/*     */       
/* 400 */       if (tag == Symbols.ROW_NAMES && RowNamesVector.isOldCompactForm(value)) {
/* 401 */         rowNamesVector = RowNamesVector.fromOldCompactForm(value);
/*     */       }
/*     */       
/* 404 */       PairList.Node node = new PairList.Node(tag, (SEXP)rowNamesVector, attributes, (PairList)Null.INSTANCE);
/* 405 */       if (head == null) {
/* 406 */         head = node;
/* 407 */         tail = node;
/*     */       } else {
/* 409 */         tail.setNextNode(node);
/* 410 */         tail = node;
/*     */       } 
/*     */ 
/*     */       
/* 414 */       flags = this.in.readInt();
/*     */     } 
/* 416 */     return (head == null) ? (PairList)Null.INSTANCE : (PairList)head;
/*     */   }
/*     */   
/*     */   private SEXP readTag(int flags) throws IOException {
/* 420 */     return Flags.hasTag(flags) ? readExp() : (SEXP)Null.INSTANCE;
/*     */   }
/*     */   
/*     */   private AttributeMap readAttributes(int flags) throws IOException {
/* 424 */     if (Flags.hasAttributes(flags))
/* 425 */       return readAttributeValues(flags); 
/* 426 */     if (Flags.isS4(flags)) {
/* 427 */       return AttributeMap.builder().setS4(true).build();
/*     */     }
/* 429 */     return AttributeMap.EMPTY;
/*     */   }
/*     */ 
/*     */   
/*     */   private AttributeMap readAttributeValues(int flags) throws IOException {
/* 434 */     PairList pairList = (PairList)readExp();
/* 435 */     AttributeMap.Builder attributes = AttributeMap.builder();
/*     */     
/* 437 */     for (PairList.Node node : pairList.nodes()) {
/* 438 */       if (node.getTag() == Flags.OLD_S4_BIT) {
/* 439 */         attributes.setS4(true); continue;
/*     */       } 
/* 441 */       attributes.set(node.getTag(), node.getValue());
/*     */     } 
/*     */ 
/*     */     
/* 445 */     if (Flags.isS4(flags)) {
/* 446 */       attributes.setS4(true);
/*     */     }
/*     */     
/* 449 */     SEXP rns = attributes.get(Symbols.ROW_NAMES);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 455 */     if (rns instanceof IntVector) {
/* 456 */       IntVector rniv = (IntVector)rns;
/* 457 */       if (rniv.length() == 2 && rniv.isElementNA(0)) {
/*     */         
/* 459 */         ConvertingStringVector csv = new ConvertingStringVector((Vector)IntSequence.fromTo(1, rniv.getElementAsInt(1)), AttributeMap.EMPTY);
/* 460 */         attributes.set(Symbols.ROW_NAMES, (SEXP)csv);
/*     */       } 
/*     */     } 
/* 463 */     return attributes.build();
/*     */   }
/*     */   
/*     */   private SEXP readPackage() throws IOException {
/* 467 */     throw new IOException("package");
/*     */   }
/*     */   
/*     */   private SEXP readReference(int flags) throws IOException {
/* 471 */     int i = readReferenceIndex(flags);
/* 472 */     return this.referenceTable.get(i);
/*     */   }
/*     */   
/*     */   private int readReferenceIndex(int flags) throws IOException {
/* 476 */     int i = Flags.unpackRefIndex(flags);
/* 477 */     if (i == 0) {
/* 478 */       return this.in.readInt() - 1;
/*     */     }
/* 480 */     return i - 1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private SEXP readSymbol() throws IOException {
/*     */     String name;
/* 487 */     int flags = this.in.readInt();
/* 488 */     if (Flags.getType(flags) != 9) {
/* 489 */       throw new IllegalStateException("Expected a CHARSXP");
/*     */     }
/*     */     
/* 492 */     int length = this.in.readInt();
/* 493 */     if (length < 0) {
/* 494 */       name = "NA";
/*     */     } else {
/* 496 */       name = new String(this.in.readString(length));
/*     */     } 
/* 498 */     return addReadRef((SEXP)Symbol.get(name));
/*     */   }
/*     */   
/*     */   private SEXP addReadRef(SEXP value) {
/* 502 */     this.referenceTable.add(value);
/* 503 */     return value;
/*     */   }
/*     */   
/*     */   private SEXP readNamespace() throws IOException {
/* 507 */     StringVector name = readPersistentNamesVector();
/* 508 */     Environment environment = this.readContext.findNamespace(Symbol.get(name.getElementAsString(0)));
/* 509 */     if (environment == Null.INSTANCE) {
/* 510 */       throw new IllegalStateException("Cannot find namespace '" + name + "'");
/*     */     }
/* 512 */     return addReadRef((SEXP)environment);
/*     */   }
/*     */ 
/*     */   
/*     */   private SEXP readEnv(int flags) throws IOException {
/* 517 */     Environment env = Environment.createChildEnvironment((Environment)Environment.EMPTY).build();
/* 518 */     addReadRef((SEXP)env);
/*     */     
/* 520 */     boolean locked = (this.in.readInt() == 1);
/* 521 */     SEXP parent = readExp();
/* 522 */     readEnvFrame(env);
/* 523 */     readEnvHashTab(env);
/*     */ 
/*     */ 
/*     */     
/* 527 */     SEXP attributes = readExp();
/*     */     
/* 529 */     env.setParent((parent == Null.INSTANCE) ? (Environment)Environment.EMPTY : (Environment)parent);
/* 530 */     env.setAttributes(AttributeMap.fromPairList((PairList)attributes));
/*     */     
/* 532 */     if (locked) {
/* 533 */       env.lock(false);
/*     */     }
/*     */     
/* 536 */     return (SEXP)env;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readEnvHashTab(Environment env) throws IOException {
/* 547 */     int tableFlags = this.in.readInt();
/* 548 */     if (Flags.getType(tableFlags) == 254) {
/*     */       return;
/*     */     }
/* 551 */     if (Flags.getType(tableFlags) != 19) {
/* 552 */       throw new IOException("Expected type VECSEXP for environment hashtable.");
/*     */     }
/* 554 */     int length = this.in.readInt();
/* 555 */     for (int i = 0; i < length; i++) {
/* 556 */       readEnvFrame(env);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readEnvFrame(Environment env) throws IOException {
/* 571 */     int flags = this.in.readInt();
/*     */     
/* 573 */     while (Flags.getType(flags) != 254) {
/*     */       RowNamesVector rowNamesVector;
/* 575 */       if (Flags.getType(flags) != 2) {
/* 576 */         throw new IOException("Expected type LISTSXP for environment frame");
/*     */       }
/*     */       
/* 579 */       AttributeMap attributes = readAttributes(flags);
/* 580 */       Symbol tag = (Symbol)readTag(flags);
/* 581 */       SEXP value = readExp();
/*     */       
/* 583 */       if (tag == Symbols.ROW_NAMES && RowNamesVector.isOldCompactForm(value)) {
/* 584 */         rowNamesVector = RowNamesVector.fromOldCompactForm(value);
/*     */       }
/* 586 */       if (Flags.isActiveBinding(flags)) {
/* 587 */         env.makeActiveBinding(tag, (Closure)rowNamesVector);
/*     */       } else {
/* 589 */         env.setVariableUnsafe(tag, (SEXP)rowNamesVector);
/*     */       } 
/*     */ 
/*     */       
/* 593 */       flags = this.in.readInt();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private SEXP readS4XP(int flags) throws IOException {
/* 599 */     return (SEXP)new S4Object(readAttributes(flags));
/*     */   }
/*     */   
/*     */   private SEXP readListExp(int flags) throws IOException {
/* 603 */     SEXP[] values = readExpArray();
/* 604 */     AttributeMap attributes = readAttributes(flags);
/* 605 */     return (SEXP)new ListVector(values, attributes);
/*     */   }
/*     */   
/*     */   private SEXP readExpExp(int flags) throws IOException {
/* 609 */     SEXP[] values = readExpArray();
/* 610 */     AttributeMap attributes = readAttributes(flags);
/* 611 */     return (SEXP)new ExpressionVector(values, attributes);
/*     */   }
/*     */   
/*     */   private SEXP[] readExpArray() throws IOException {
/* 615 */     int length = this.in.readInt();
/* 616 */     SEXP[] values = new SEXP[length];
/* 617 */     for (int i = 0; i != length; i++) {
/* 618 */       values[i] = readExp();
/*     */     }
/* 620 */     return values;
/*     */   }
/*     */   
/*     */   private SEXP readStringVector(int flags) throws IOException {
/* 624 */     int length = this.in.readInt();
/* 625 */     if (length > 100) {
/* 626 */       return readStringVectorAsByteArray(length, flags);
/*     */     }
/* 628 */     return readStringsAsArray(length, flags);
/*     */   }
/*     */ 
/*     */   
/*     */   private SEXP readStringsAsArray(int length, int flags) throws IOException {
/* 633 */     StringVector.Builder array = new StringVector.Builder(0, length);
/* 634 */     for (int i = 0; i < length; i++) {
/*     */       
/* 636 */       int elementFlags = this.in.readInt();
/* 637 */       assert Flags.getType(elementFlags) == 9;
/*     */ 
/*     */       
/* 640 */       int elementLength = this.in.readInt();
/* 641 */       if (elementLength < 0) {
/* 642 */         array.addNA();
/*     */       } else {
/* 644 */         array.add(readString(flags, elementLength));
/*     */       } 
/*     */     } 
/* 647 */     return array.build().setAttributes(readAttributes(flags));
/*     */   }
/*     */   
/*     */   private SEXP readStringVectorAsByteArray(int length, int flags) throws IOException {
/* 651 */     StringByteArrayVector.Builder builder = new StringByteArrayVector.Builder(length);
/*     */     
/* 653 */     int elementFlags = 0;
/* 654 */     for (int i = 0; i != length; i++) {
/*     */       
/* 656 */       elementFlags = this.in.readInt();
/* 657 */       assert Flags.getType(elementFlags) == 9;
/*     */ 
/*     */       
/* 660 */       int elementLength = this.in.readInt();
/* 661 */       builder.readFrom(this.in, elementLength);
/*     */     } 
/*     */ 
/*     */     
/* 665 */     if (Flags.isUTF8Encoded(elementFlags)) {
/* 666 */       builder.setCharset(Charsets.UTF_8);
/* 667 */     } else if (Flags.isLatin1Encoded(flags)) {
/* 668 */       builder.setCharset(Charset.forName("Latin1"));
/*     */     } 
/*     */ 
/*     */     
/* 672 */     return builder.build(readAttributes(flags));
/*     */   }
/*     */   
/*     */   private SEXP readComplexExp(int flags) throws IOException {
/* 676 */     int length = this.in.readInt();
/* 677 */     Complex[] values = new Complex[length];
/* 678 */     for (int i = 0; i != length; i++) {
/* 679 */       values[i] = new Complex(this.in.readDouble(), this.in.readDouble());
/*     */     }
/* 681 */     return (SEXP)new ComplexArrayVector(values, readAttributes(flags));
/*     */   }
/*     */   
/*     */   private SEXP readDoubleExp(int flags) throws IOException {
/* 685 */     int length = this.in.readInt();
/* 686 */     double[] values = new double[length];
/* 687 */     for (int i = 0; i != length; i++) {
/* 688 */       values[i] = this.in.readDouble();
/*     */     }
/* 690 */     return (SEXP)new DoubleArrayVector(values, readAttributes(flags));
/*     */   }
/*     */   
/*     */   private SEXP readIntVector(int flags) throws IOException {
/* 694 */     int length = this.in.readInt();
/* 695 */     IntBuffer buffer = this.in.readIntBuffer(length);
/* 696 */     return (SEXP)new IntBufferVector(buffer, length, readAttributes(flags));
/*     */   }
/*     */ 
/*     */   
/*     */   private SEXP readLogical(int flags) throws IOException {
/* 701 */     int length = this.in.readInt();
/* 702 */     int[] values = new int[length];
/* 703 */     for (int i = 0; i != length; i++) {
/* 704 */       values[i] = this.in.readInt();
/*     */     }
/* 706 */     return (SEXP)new LogicalArrayVector(values, readAttributes(flags));
/*     */   }
/*     */   
/*     */   private SEXP readCharExp(int flags) throws IOException {
/* 710 */     int length = this.in.readInt();
/* 711 */     if (length == -1) {
/* 712 */       return (SEXP)new CHARSEXP(StringVector.NA);
/*     */     }
/* 714 */     String string = readString(flags, length);
/* 715 */     return (SEXP)new CHARSEXP(string);
/*     */   }
/*     */   
/*     */   private String readString(int flags, int length) throws IOException {
/*     */     String string;
/* 720 */     byte[] buf = this.in.readString(length);
/*     */     
/* 722 */     if (Flags.isUTF8Encoded(flags)) {
/* 723 */       string = new String(buf, "UTF8");
/* 724 */     } else if (Flags.isLatin1Encoded(flags)) {
/* 725 */       string = new String(buf, "Latin1");
/*     */     } else {
/* 727 */       string = new String(buf);
/*     */     } 
/* 729 */     return string;
/*     */   }
/*     */   
/*     */   private SEXP readPrimitive(int flags) throws IOException {
/* 733 */     int nameLength = this.in.readInt();
/* 734 */     String name = new String(this.in.readString(nameLength));
/* 735 */     PrimitiveFunction builtin = Primitives.getBuiltin(name);
/* 736 */     if (builtin != null) {
/* 737 */       return (SEXP)builtin;
/*     */     }
/* 739 */     builtin = Primitives.getInternal(Symbol.get(name));
/* 740 */     if (builtin != null) {
/* 741 */       return (SEXP)builtin;
/*     */     }
/* 743 */     throw new EvalException("Cannot read primitive '" + name + "': does not exist.", new Object[0]);
/*     */   }
/*     */   
/*     */   private SEXP readWeakReference(int flags) throws IOException {
/* 747 */     throw new IOException("weakRef not yet impl");
/*     */   }
/*     */   
/*     */   private SEXP readExternalPointer(int flags) throws IOException {
/* 751 */     ExternalPtr ptr = new ExternalPtr(null);
/* 752 */     addReadRef((SEXP)ptr);
/*     */     
/* 754 */     readExp();
/* 755 */     readExp();
/* 756 */     ptr = (ExternalPtr)ptr.setAttributes(readAttributes(flags));
/* 757 */     return (SEXP)ptr;
/*     */   }
/*     */   
/*     */   private SEXP readPersistentExp() throws IOException {
/* 761 */     if (this.restorer == null) {
/* 762 */       throw new IOException("no restore method available");
/*     */     }
/* 764 */     return addReadRef(this.restorer.restore(readPersistentNamesVector()));
/*     */   }
/*     */   
/*     */   private StringVector readPersistentNamesVector() throws IOException {
/* 768 */     if (this.in.readInt() != 0) {
/* 769 */       throw new IOException("names in persistent strings are not supported yet");
/*     */     }
/* 771 */     int len = this.in.readInt();
/* 772 */     String[] values = new String[len];
/* 773 */     for (int i = 0; i != len; i++) {
/* 774 */       values[i] = ((CHARSEXP)readExp()).getValue();
/*     */     }
/* 776 */     return (StringVector)new StringArrayVector(values);
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 781 */     this.conn.close();
/*     */   }
/*     */   static interface StreamReader {
/*     */     int readInt() throws IOException;
/*     */     
/*     */     IntBuffer readIntBuffer(int param1Int) throws IOException;
/*     */     
/*     */     byte[] readString(int param1Int) throws IOException;
/*     */     
/*     */     void readFully(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) throws IOException;
/*     */     
/*     */     double readDouble() throws IOException; }
/*     */   
/*     */   private static class AsciiReader implements StreamReader { private BufferedReader reader;
/*     */     
/*     */     private AsciiReader(BufferedReader reader) {
/* 797 */       this.reader = reader;
/*     */     }
/*     */     
/*     */     private AsciiReader(InputStream in) {
/* 801 */       this(new BufferedReader(new InputStreamReader(in)));
/*     */     }
/*     */     
/*     */     public String readWord() throws IOException {
/*     */       int codePoint;
/*     */       do {
/* 807 */         codePoint = this.reader.read();
/* 808 */         if (codePoint == -1) {
/* 809 */           throw new EOFException();
/*     */         }
/* 811 */       } while (Character.isWhitespace(codePoint));
/*     */       
/* 813 */       StringBuilder sb = new StringBuilder();
/* 814 */       while (!Character.isWhitespace(codePoint)) {
/* 815 */         sb.appendCodePoint(codePoint);
/* 816 */         codePoint = this.reader.read();
/*     */       } 
/* 818 */       return sb.toString();
/*     */     }
/*     */ 
/*     */     
/*     */     public int readInt() throws IOException {
/* 823 */       String word = readWord();
/* 824 */       if ("NA".equals(word)) {
/* 825 */         return Integer.MIN_VALUE;
/*     */       }
/* 827 */       return Integer.parseInt(word);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public IntBuffer readIntBuffer(int size) throws IOException {
/* 833 */       int[] array = new int[size];
/* 834 */       for (int i = 0; i != size; i++) {
/* 835 */         array[i] = readInt();
/*     */       }
/* 837 */       return IntBuffer.wrap(array);
/*     */     }
/*     */ 
/*     */     
/*     */     public double readDouble() throws IOException {
/* 842 */       String word = readWord();
/* 843 */       if ("NA".equals(word))
/* 844 */         return DoubleVector.NA; 
/* 845 */       if ("Inf".equals(word))
/* 846 */         return Double.POSITIVE_INFINITY; 
/* 847 */       if ("-Inf".equals(word)) {
/* 848 */         return Double.NEGATIVE_INFINITY;
/*     */       }
/* 850 */       return NumericLiterals.parseDouble(word);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public byte[] readString(int length) throws IOException {
/* 856 */       byte[] buf = null;
/* 857 */       if (length > 0) {
/* 858 */         int codePoint; buf = new byte[length];
/*     */         
/*     */         do {
/* 861 */           codePoint = this.reader.read();
/* 862 */           if (codePoint == -1) {
/* 863 */             throw new EOFException();
/*     */           }
/* 865 */         } while (Character.isWhitespace(codePoint));
/*     */         
/* 867 */         for (int i = 0; i < length; i++) {
/* 868 */           if (codePoint == 92)
/* 869 */           { int d, j; codePoint = this.reader.read();
/* 870 */             switch (codePoint) { case 110:
/* 871 */                 buf[i] = 10;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/* 899 */                 codePoint = this.reader.read();case 116: buf[i] = 9; codePoint = this.reader.read();case 118: buf[i] = 11; codePoint = this.reader.read();case 98: buf[i] = 8; codePoint = this.reader.read();case 114: buf[i] = 13; codePoint = this.reader.read();case 102: buf[i] = 12; codePoint = this.reader.read();case 97: buf[i] = 7; codePoint = this.reader.read();case 92: buf[i] = 92; codePoint = this.reader.read();case 63: buf[i] = Byte.MAX_VALUE; codePoint = this.reader.read();case 39: buf[i] = 39; codePoint = this.reader.read();case 34: buf[i] = 34; codePoint = this.reader.read();case 48: case 49: case 50: case 51: case 52: case 53: case 54: case 55: d = 0; j = 0; while (48 <= codePoint && codePoint < 56 && j < 3) { d = d * 8 + codePoint - 48; codePoint = this.reader.read(); j++; }  buf[i] = (byte)d; break;default: buf[i] = (byte)codePoint; codePoint = this.reader.read(); }  } else { buf[i] = (byte)codePoint; codePoint = this.reader.read(); }
/*     */         
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 906 */       return buf;
/*     */     }
/*     */ 
/*     */     
/*     */     public void readFully(byte[] buffer, int offset, int length) throws IOException {
/* 911 */       System.arraycopy(readString(length), 0, buffer, offset, length);
/*     */     } }
/*     */ 
/*     */   
/*     */   private static class XdrReader implements StreamReader {
/*     */     private final DataInputStream in;
/*     */     
/*     */     private XdrReader(DataInputStream in) throws IOException {
/* 919 */       this.in = in;
/*     */     }
/*     */     
/*     */     public XdrReader(InputStream conn) throws IOException {
/* 923 */       this(new DataInputStream(new BufferedInputStream(conn)));
/*     */     }
/*     */ 
/*     */     
/*     */     public int readInt() throws IOException {
/* 928 */       return this.in.readInt();
/*     */     }
/*     */ 
/*     */     
/*     */     public IntBuffer readIntBuffer(int size) throws IOException {
/* 933 */       ByteBuffer byteBuffer = ByteBuffer.allocateDirect(size * 4);
/* 934 */       ReadableByteChannel channel = Channels.newChannel(this.in);
/* 935 */       while (byteBuffer.hasRemaining()) {
/* 936 */         channel.read(byteBuffer);
/*     */       }
/* 938 */       byteBuffer = (ByteBuffer)byteBuffer.rewind();
/* 939 */       byteBuffer.order(ByteOrder.BIG_ENDIAN);
/* 940 */       IntBuffer intBuffer = byteBuffer.asIntBuffer();
/* 941 */       assert intBuffer.limit() == size;
/* 942 */       return intBuffer;
/*     */     }
/*     */ 
/*     */     
/*     */     public byte[] readString(int length) throws IOException {
/* 947 */       byte[] buf = new byte[length];
/* 948 */       this.in.readFully(buf);
/* 949 */       return buf;
/*     */     }
/*     */ 
/*     */     
/*     */     public void readFully(byte[] buffer, int offset, int length) throws IOException {
/* 954 */       this.in.readFully(buffer, offset, length);
/*     */     }
/*     */ 
/*     */     
/*     */     public double readDouble() throws IOException {
/* 959 */       long bits = this.in.readLong();
/* 960 */       return Double.longBitsToDouble(bits);
/*     */     }
/*     */   }
/*     */   
/*     */   public static interface PersistentRestorer {
/*     */     SEXP restore(StringVector param1StringVector);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/io/serialization/RDataReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */