/*    */ package org.renjin.invoke.codegen.args;
/*    */ 
/*    */ import com.sun.codemodel.JCodeModel;
/*    */ import com.sun.codemodel.JExpression;
/*    */ import com.sun.codemodel.JVar;
/*    */ import org.renjin.invoke.codegen.ApplyMethodContext;
/*    */ import org.renjin.invoke.codegen.WrapperRuntime;
/*    */ import org.renjin.invoke.codegen.scalars.ScalarType;
/*    */ import org.renjin.invoke.codegen.scalars.ScalarTypes;
/*    */ import org.renjin.invoke.model.JvmMethod;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Recyclable
/*    */   extends ArgConverterStrategy
/*    */ {
/*    */   private ScalarType scalarType;
/*    */   
/*    */   public Recyclable(JvmMethod.Argument formal) {
/* 36 */     super(formal);
/* 37 */     this.scalarType = ScalarTypes.get(formal.getClazz());
/*    */   }
/*    */   
/*    */   public static boolean accept(JvmMethod.Argument formal) {
/* 41 */     return formal.isRecycle();
/*    */   }
/*    */ 
/*    */   
/*    */   public JExpression getTestExpr(JCodeModel codeModel, JVar sexp) {
/* 46 */     return this.scalarType.testExpr(codeModel, sexp, this.formal);
/*    */   }
/*    */ 
/*    */   
/*    */   public JExpression convertArgument(ApplyMethodContext parent, JExpression sexp) {
/* 51 */     return (JExpression)parent.classRef(WrapperRuntime.class).staticInvoke("convertToVector").arg(sexp);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/codegen/args/Recyclable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */