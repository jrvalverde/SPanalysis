/*     */ package org.renjin.compiler.ir;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import org.renjin.primitives.sequence.IntSequence;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ import org.renjin.repackaged.guava.base.Preconditions;
/*     */ import org.renjin.repackaged.guava.collect.Sets;
/*     */ import org.renjin.sexp.AtomicVector;
/*     */ import org.renjin.sexp.AttributeMap;
/*     */ import org.renjin.sexp.DoubleVector;
/*     */ import org.renjin.sexp.IntVector;
/*     */ import org.renjin.sexp.ListVector;
/*     */ import org.renjin.sexp.Null;
/*     */ import org.renjin.sexp.PairList;
/*     */ import org.renjin.sexp.RawVector;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.StringVector;
/*     */ import org.renjin.sexp.Symbol;
/*     */ import org.renjin.sexp.Symbols;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ValueBounds
/*     */ {
/*     */   public static final int UNKNOWN_LENGTH = -1;
/*     */   public static final int SCALAR_LENGTH = 1;
/*     */   public static final int MAY_HAVE_NA = 0;
/*     */   public static final int NO_NA = 1;
/*  49 */   public static final ValueBounds UNBOUNDED = (new Builder()).build();
/*     */   
/*  51 */   public static final ValueBounds INT_PRIMITIVE = primitive(16);
/*     */   
/*  53 */   public static final ValueBounds DOUBLE_PRIMITIVE = primitive(32);
/*     */   
/*  55 */   public static final ValueBounds LOGICAL_PRIMITIVE = primitive(8);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  60 */   private int length = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  66 */   private int na = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  71 */   private int typeSet = 8190;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  76 */   private SEXP constantValue = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean attributesOpen = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Map<Symbol, SEXP> attributes;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ValueBounds(ValueBounds toCopy) {
/*  96 */     assert toCopy.attributes != null;
/*  97 */     this.length = toCopy.length;
/*  98 */     this.typeSet = toCopy.typeSet;
/*  99 */     this.na = toCopy.na;
/* 100 */     this.constantValue = toCopy.constantValue;
/* 101 */     this.attributes = toCopy.attributes;
/* 102 */     this.attributesOpen = toCopy.attributesOpen;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ValueBounds primitive(int type) {
/* 110 */     ValueBounds valueBounds = new ValueBounds();
/* 111 */     valueBounds.typeSet = type;
/* 112 */     valueBounds.length = 1;
/* 113 */     valueBounds.attributes = Collections.emptyMap();
/* 114 */     valueBounds.attributesOpen = false;
/* 115 */     valueBounds.na = 1;
/* 116 */     return valueBounds;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ValueBounds of(SEXP value) {
/* 123 */     ValueBounds valueBounds = new ValueBounds();
/* 124 */     valueBounds.na = hasAnyNAs(value);
/* 125 */     valueBounds.constantValue = value;
/* 126 */     valueBounds.typeSet = TypeSet.of(value);
/* 127 */     valueBounds.length = value.length();
/* 128 */     valueBounds.attributes = value.getAttributes().toMap();
/* 129 */     valueBounds.attributesOpen = false;
/* 130 */     return valueBounds;
/*     */   }
/*     */   
/*     */   private static int hasAnyNAs(SEXP value) {
/* 134 */     if (value instanceof AtomicVector && (
/* 135 */       (AtomicVector)value).containsNA()) {
/* 136 */       return 0;
/*     */     }
/*     */     
/* 139 */     return 1;
/*     */   }
/*     */   
/*     */   public ValueBounds of(Object value) {
/* 143 */     if (value instanceof SEXP)
/* 144 */       return of((SEXP)value); 
/* 145 */     if (value instanceof Integer)
/* 146 */       return of((SEXP)IntVector.valueOf(((Integer)value).intValue())); 
/* 147 */     if (value instanceof Double) {
/* 148 */       return of((SEXP)DoubleVector.valueOf(((Double)value).doubleValue()));
/*     */     }
/* 150 */     throw new UnsupportedOperationException("value: " + value);
/*     */   }
/*     */   
/*     */   public static ValueBounds of(Class returnType) {
/* 154 */     ValueBounds valueBounds = new ValueBounds();
/* 155 */     valueBounds.attributesOpen = true;
/* 156 */     valueBounds.attributes = Collections.emptyMap();
/* 157 */     valueBounds.typeSet = TypeSet.of(returnType);
/* 158 */     if (returnType.isPrimitive()) {
/* 159 */       valueBounds.length = 1;
/*     */     } else {
/* 161 */       valueBounds.length = -1;
/*     */     } 
/* 163 */     return valueBounds;
/*     */   }
/*     */   
/*     */   public boolean isConstant() {
/* 167 */     return (this.constantValue != null);
/*     */   }
/*     */   
/*     */   public boolean isConstant(Symbol symbol) {
/* 171 */     return (this.constantValue == symbol);
/*     */   }
/*     */   
/*     */   public boolean isLengthConstant() {
/* 175 */     return (this.length != -1);
/*     */   }
/*     */   
/*     */   public boolean isAttributeConstant(Symbol name) {
/* 179 */     if (this.attributesOpen) {
/* 180 */       return (this.attributes.get(name) != null);
/*     */     }
/*     */ 
/*     */     
/* 184 */     if (!this.attributes.containsKey(name)) {
/* 185 */       return true;
/*     */     }
/* 187 */     return (this.attributes.get(name) != null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAttributeDefinitelyNull(Symbol name) {
/* 193 */     return (getAttributeIfConstant(name) == Null.INSTANCE);
/*     */   }
/*     */   
/*     */   public SEXP getAttributeIfConstant(Symbol name) {
/* 197 */     if (this.attributesOpen) {
/* 198 */       return this.attributes.get(name);
/*     */     }
/*     */ 
/*     */     
/* 202 */     if (!this.attributes.containsKey(name)) {
/* 203 */       return (SEXP)Null.INSTANCE;
/*     */     }
/* 205 */     return this.attributes.get(name);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isClassAttributeConstant() {
/* 211 */     return isAttributeConstant(Symbols.CLASS);
/*     */   }
/*     */   
/*     */   public boolean isDimAttributeConstant() {
/* 215 */     return isAttributeConstant(Symbols.DIM);
/*     */   }
/*     */   
/*     */   public boolean isDimCountConstant() {
/* 219 */     return isDimAttributeConstant();
/*     */   }
/*     */   
/*     */   public boolean isAttributeConstant() {
/* 223 */     return (!this.attributesOpen && !this.attributes.containsValue(null));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean attributeCouldBePresent(Symbol attributeName) {
/* 229 */     SEXP bounds = this.attributes.get(attributeName);
/* 230 */     if (bounds == Null.INSTANCE) {
/* 231 */       return false;
/*     */     }
/*     */     
/* 234 */     if (this.attributesOpen)
/*     */     {
/* 236 */       return true;
/*     */     }
/*     */ 
/*     */     
/* 240 */     return this.attributes.containsKey(attributeName);
/*     */   }
/*     */ 
/*     */   
/*     */   public AtomicVector getConstantClassAttribute() {
/* 245 */     return (AtomicVector)getAttributeIfConstant(Symbols.CLASS);
/*     */   }
/*     */   
/*     */   public AtomicVector getConstantDimAttribute() {
/* 249 */     return (AtomicVector)getAttributeIfConstant(Symbols.DIM);
/*     */   }
/*     */   
/*     */   public int getConstantDimCount() {
/* 253 */     return getConstantDimAttribute().length();
/*     */   }
/*     */   
/*     */   public Map<Symbol, SEXP> getAttributeBounds() {
/* 257 */     return this.attributes;
/*     */   }
/*     */   
/*     */   public boolean isAttributeSetOpen() {
/* 261 */     return this.attributesOpen;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ValueBounds getElementBounds() {
/* 269 */     if (this.constantValue instanceof ListVector) {
/* 270 */       ListVector constantList = (ListVector)this.constantValue;
/* 271 */       List<ValueBounds> elementBounds = new ArrayList<>();
/* 272 */       for (int i = 0; i < constantList.length(); i++) {
/* 273 */         elementBounds.add(of(constantList.getElementAsSEXP(i)));
/*     */       }
/* 275 */       return union(elementBounds);
/*     */     } 
/* 277 */     if (TypeSet.isDefinitelyAtomic(this.typeSet)) {
/* 278 */       return primitive(this.typeSet);
/*     */     }
/*     */     
/* 281 */     return UNBOUNDED;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public AttributeMap getConstantAttributes() {
/* 287 */     if (this.attributesOpen) {
/* 288 */       throw new IllegalArgumentException("attribute set is not closed");
/*     */     }
/*     */     
/* 291 */     AttributeMap.Builder attributeMap = AttributeMap.builder();
/* 292 */     for (Map.Entry<Symbol, SEXP> entry : this.attributes.entrySet()) {
/* 293 */       assert entry.getValue() != null;
/* 294 */       attributeMap.set(entry.getKey(), entry.getValue());
/*     */     } 
/*     */     
/* 297 */     return attributeMap.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTypeSet() {
/* 304 */     return this.typeSet;
/*     */   }
/*     */   
/*     */   public int getNA() {
/* 308 */     return this.na;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean maybeNA() {
/* 313 */     return (this.na == 0);
/*     */   }
/*     */   
/*     */   public int getLength() {
/* 317 */     return this.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ValueBounds union(ValueBounds other) {
/* 324 */     ValueBounds u = new ValueBounds();
/* 325 */     this.typeSet |= other.typeSet;
/* 326 */     u.length = unionLengths(this.length, other.length);
/* 327 */     this.na &= other.na;
/* 328 */     u.attributesOpen = (this.attributesOpen || other.attributesOpen);
/*     */     
/* 330 */     if (this.attributes == other.attributes) {
/* 331 */       Preconditions.checkNotNull(this.attributes, "attributes");
/* 332 */       u.attributes = this.attributes;
/* 333 */     } else if (this.attributes.isEmpty() && other.attributes.isEmpty()) {
/* 334 */       u.attributes = Collections.emptyMap();
/*     */     } else {
/* 336 */       u.attributes = new HashMap<>();
/* 337 */       Sets.SetView setView = Sets.union(this.attributes.keySet(), other.attributes.keySet());
/* 338 */       for (Symbol attributeName : setView) {
/* 339 */         SEXP thisValue = this.attributes.get(attributeName);
/* 340 */         SEXP otherValue = other.attributes.get(attributeName);
/*     */         
/* 342 */         u.attributes.put(attributeName, unionConstant(thisValue, otherValue));
/*     */       } 
/*     */     } 
/* 345 */     return u;
/*     */   }
/*     */ 
/*     */   
/*     */   private static int unionLengths(int x, int y) {
/* 350 */     if (x == y) {
/* 351 */       return x;
/*     */     }
/* 353 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private <T> T unionConstant(T x, T y) {
/* 359 */     if (x == null || y == null) {
/* 360 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 364 */     if (x.equals(y)) {
/* 365 */       return x;
/*     */     }
/*     */ 
/*     */     
/* 369 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ValueBounds union(Iterable<ValueBounds> bounds) {
/* 378 */     Iterator<ValueBounds> it = bounds.iterator();
/* 379 */     Preconditions.checkArgument(it.hasNext());
/*     */     
/* 381 */     ValueBounds union = it.next();
/*     */     
/* 383 */     while (it.hasNext()) {
/* 384 */       union = union.union(it.next());
/*     */     }
/* 386 */     return union;
/*     */   }
/*     */ 
/*     */   
/*     */   public Type storageType() {
/* 391 */     if (this.typeSet == 32) {
/* 392 */       if (this.length == 1) {
/* 393 */         return Type.DOUBLE_TYPE;
/*     */       }
/* 395 */       return Type.getType(DoubleVector.class);
/*     */     } 
/* 397 */     if (this.typeSet == 16 || this.typeSet == 8) {
/*     */       
/* 399 */       if (this.length == 1) {
/* 400 */         return Type.INT_TYPE;
/*     */       }
/* 402 */       return Type.getType(IntVector.class);
/*     */     } 
/* 404 */     if (this.typeSet == 256) {
/* 405 */       if (this.length == 1) {
/* 406 */         return Type.BYTE_TYPE;
/*     */       }
/* 408 */       return Type.getType(RawVector.class);
/*     */     } 
/* 410 */     if (this.typeSet == 64) {
/* 411 */       if (this.length == 1) {
/* 412 */         return Type.getType(String.class);
/*     */       }
/* 414 */       return Type.getType(StringVector.class);
/*     */     } 
/*     */     
/* 417 */     return Type.getType(SEXP.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 424 */     if (isConstant()) {
/* 425 */       return "[const " + formatConstant(this.constantValue) + "]";
/*     */     }
/*     */     
/* 428 */     if (this.typeSet == 8190 && this.length == -1) {
/* 429 */       return "[*]";
/*     */     }
/*     */     
/* 432 */     StringBuilder s = new StringBuilder();
/* 433 */     s.append("[");
/* 434 */     s.append(TypeSet.toString(this.typeSet));
/* 435 */     s.append(", len=");
/* 436 */     if (this.length == -1) {
/* 437 */       s.append("*");
/*     */     } else {
/* 439 */       s.append(this.length);
/*     */     } 
/* 441 */     if (this.na == 0) {
/* 442 */       s.append(", ?NA");
/*     */     }
/* 444 */     for (Map.Entry<Symbol, SEXP> attribute : this.attributes.entrySet()) {
/* 445 */       s.append(", ").append(((Symbol)attribute.getKey()).getPrintName()).append("=");
/* 446 */       if (attribute.getValue() == null) {
/* 447 */         s.append("?"); continue;
/* 448 */       }  if (attribute.getValue() == Null.INSTANCE) {
/* 449 */         s.append("∅"); continue;
/*     */       } 
/* 451 */       s.append("{").append(attribute.getValue()).append("}");
/*     */     } 
/*     */     
/* 454 */     if (this.attributesOpen) {
/* 455 */       s.append(", ...=?");
/*     */     }
/*     */     
/* 458 */     s.append("]");
/*     */     
/* 460 */     return s.toString();
/*     */   }
/*     */   
/*     */   private String formatConstant(SEXP constantValue) {
/* 464 */     StringBuilder s = new StringBuilder(formatConstantValue(constantValue));
/* 465 */     AttributeMap attributes = constantValue.getAttributes();
/* 466 */     appendAttributesTo(s, attributes);
/* 467 */     return s.toString();
/*     */   }
/*     */   
/*     */   private void appendAttributesTo(StringBuilder s, AttributeMap attributes) {
/* 471 */     if (attributes != AttributeMap.EMPTY) {
/* 472 */       for (PairList.Node node : attributes.nodes()) {
/* 473 */         s.append(", ").append(node.getTag().getPrintName()).append("=").append(formatConstant(node.getValue()));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private String formatConstantValue(SEXP constantValue) {
/* 479 */     if (constantValue.length() == 1) {
/* 480 */       if (constantValue instanceof IntVector)
/* 481 */         return ((IntVector)constantValue).getElementAsInt(0) + "L"; 
/* 482 */       if (constantValue instanceof DoubleVector) {
/* 483 */         return Double.toString(((DoubleVector)constantValue).getElementAsDouble(0));
/*     */       }
/*     */     } 
/* 486 */     if (constantValue instanceof IntSequence) {
/* 487 */       IntSequence seq = (IntSequence)constantValue;
/* 488 */       if (seq.getBy() == 1) {
/* 489 */         return seq.getFrom() + ":" + (seq.getFrom() + seq.getLength());
/*     */       }
/*     */     } 
/* 492 */     return constantValue.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 497 */     if (this == o) {
/* 498 */       return true;
/*     */     }
/* 500 */     if (o == null || getClass() != o.getClass()) {
/* 501 */       return false;
/*     */     }
/*     */     
/* 504 */     ValueBounds that = (ValueBounds)o;
/*     */     
/* 506 */     return (this.length == that.length && this.typeSet == that.typeSet && this.attributesOpen == that.attributesOpen && this.na == that.na && 
/*     */ 
/*     */       
/* 509 */       Objects.equals(this.constantValue, that.constantValue) && 
/* 510 */       Objects.equals(this.attributes, that.attributes));
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 515 */     int result = this.length;
/* 516 */     result = 31 * result + this.typeSet;
/* 517 */     return result;
/*     */   }
/*     */   
/*     */   public SEXP getConstantValue() {
/* 521 */     return this.constantValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean allConstant(Iterable<ValueBounds> argumentTypes) {
/* 526 */     for (ValueBounds argumentType : argumentTypes) {
/* 527 */       if (!argumentType.isConstant()) {
/* 528 */         return false;
/*     */       }
/*     */     } 
/* 531 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ValueBounds withVaryingValues() {
/* 539 */     ValueBounds bounds = new ValueBounds();
/* 540 */     bounds.length = this.length;
/* 541 */     bounds.typeSet = this.typeSet;
/* 542 */     bounds.attributes = this.attributes;
/* 543 */     bounds.attributesOpen = this.attributesOpen;
/* 544 */     return this;
/*     */   }
/*     */   
/*     */   public static Builder builder() {
/* 548 */     return new Builder();
/*     */   }
/*     */   
/*     */   private ValueBounds() {}
/*     */   
/*     */   public static class Builder { private ValueBounds bounds;
/*     */     
/*     */     public Builder() {
/* 556 */       this.bounds = new ValueBounds();
/*     */     }
/*     */     
/*     */     public Builder(ValueBounds bounds) {
/* 560 */       this.bounds = new ValueBounds(bounds);
/*     */     }
/*     */     
/*     */     public Builder setLength(int length) {
/* 564 */       this.bounds.length = length;
/* 565 */       return this;
/*     */     }
/*     */     
/*     */     public Builder setTypeSet(int typeSet) {
/* 569 */       this.bounds.typeSet = typeSet;
/* 570 */       return this;
/*     */     }
/*     */     
/*     */     public Builder setNA(int na) {
/* 574 */       this.bounds.na = na;
/* 575 */       return this;
/*     */     }
/*     */     
/*     */     public Builder setType(Class type) {
/* 579 */       return setTypeSet(TypeSet.of(type));
/*     */     }
/*     */     
/*     */     public Builder setEmptyAttributes() {
/* 583 */       this.bounds.attributes = Collections.emptyMap();
/* 584 */       this.bounds.attributesOpen = false;
/* 585 */       return this;
/*     */     }
/*     */     
/*     */     public void setAttributeBounds(Map<Symbol, SEXP> attributes) {
/* 589 */       this.bounds.attributes = attributes;
/*     */     }
/*     */     
/*     */     public void setAttributeSetOpen(boolean open) {
/* 593 */       this.bounds.attributesOpen = open;
/*     */     }
/*     */     
/*     */     public void setClosedAttributes(Map<Symbol, SEXP> attributes) {
/* 597 */       this.bounds.attributes = attributes;
/* 598 */       this.bounds.attributesOpen = false;
/*     */     }
/*     */ 
/*     */     
/*     */     public void setAttribute(Symbol name, SEXP value) {
/* 603 */       if (this.bounds.attributes == null) {
/* 604 */         this.bounds.attributes = (Map)new HashMap<>();
/*     */       }
/* 606 */       this.bounds.attributes.put(name, value);
/*     */     }
/*     */     
/*     */     public void attributeCouldBePresent(Symbol attributeName) {
/* 610 */       setAttribute(attributeName, null);
/*     */     }
/*     */     
/*     */     public void setDimAttribute(AtomicVector value) {
/* 614 */       setAttribute(Symbols.DIM, (SEXP)value);
/*     */     }
/*     */     
/*     */     public ValueBounds build() {
/* 618 */       if (this.bounds.attributes == null) {
/* 619 */         this.bounds.attributes = Collections.emptyMap();
/*     */       }
/* 621 */       return this.bounds;
/*     */     } }
/*     */ 
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/ir/ValueBounds.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */