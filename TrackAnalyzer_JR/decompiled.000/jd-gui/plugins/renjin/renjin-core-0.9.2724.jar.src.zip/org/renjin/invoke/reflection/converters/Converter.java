package org.renjin.invoke.reflection.converters;

import org.renjin.sexp.SEXP;

public interface Converter<T> {
  SEXP convertToR(T paramT);
  
  boolean acceptsSEXP(SEXP paramSEXP);
  
  Object convertToJava(SEXP paramSEXP);
  
  int getSpecificity();
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/reflection/converters/Converter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */