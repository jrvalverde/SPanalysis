/*    */ package org.renjin.invoke.reflection.converters;
/*    */ 
/*    */ import org.renjin.sexp.SEXP;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SexpConverter
/*    */   implements Converter<SEXP>
/*    */ {
/*    */   private Class clazz;
/*    */   
/*    */   public SexpConverter(Class clazz) {
/* 32 */     this.clazz = clazz;
/*    */   }
/*    */ 
/*    */   
/*    */   public SEXP convertToR(SEXP value) {
/* 37 */     return value;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean acceptsSEXP(SEXP exp) {
/* 42 */     return this.clazz.isAssignableFrom(exp.getClass());
/*    */   }
/*    */   
/*    */   public static boolean acceptsJava(Class<?> clazz) {
/* 46 */     return SEXP.class.isAssignableFrom(clazz);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object convertToJava(SEXP value) {
/* 51 */     return value;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getSpecificity() {
/* 56 */     return 9;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/reflection/converters/SexpConverter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */