/*     */ package org.renjin.compiler.cfg;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import org.renjin.compiler.ir.tac.expressions.LValue;
/*     */ import org.renjin.compiler.ir.tac.statements.Statement;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LiveSet
/*     */ {
/*     */   private DominanceTree tree;
/*     */   private UseDefMap useDefMap;
/*     */   
/*     */   public LiveSet(DominanceTree tree, UseDefMap useDefMap) {
/*  37 */     this.tree = tree;
/*  38 */     this.useDefMap = useDefMap;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isLiveOut(BasicBlock q, Statement s, LValue a) {
/*  44 */     int i = q.getStatements().indexOf(s) + 1;
/*  45 */     while (i < q.getStatements().size()) {
/*  46 */       if (uses(q.getStatements().get(i), a))
/*     */       {
/*  48 */         return true;
/*     */       }
/*     */     } 
/*     */     
/*  52 */     return isLiveOut(q, a);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isLiveOut(BasicBlock q, LValue a) {
/*  62 */     BasicBlock def = def(a);
/*  63 */     if (def == q) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  69 */       for (BasicBlock use : uses(a)) {
/*  70 */         if (use != def) {
/*  71 */           return true;
/*     */         }
/*     */       } 
/*  74 */       return false;
/*     */     } 
/*     */ 
/*     */     
/*  78 */     if (this.tree.strictlyDominates(def, q))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  84 */       throw new UnsupportedOperationException("TODO");
/*     */     }
/*     */     
/*  87 */     return false;
/*     */   }
/*     */   
/*     */   private Collection<BasicBlock> uses(LValue a) {
/*  91 */     return this.useDefMap.getUsedBlocks(a);
/*     */   }
/*     */   
/*     */   private BasicBlock def(LValue a) {
/*  95 */     return this.useDefMap.getDefinitionBlock(a);
/*     */   }
/*     */   
/*     */   private boolean uses(Statement statement, LValue a) {
/*  99 */     if (statement.getRHS().equals(a)) {
/* 100 */       return true;
/*     */     }
/* 102 */     for (int i = 0; i < statement.getChildCount(); i++) {
/* 103 */       if (statement.childAt(i).equals(a)) {
/* 104 */         return true;
/*     */       }
/*     */     } 
/*     */     
/* 108 */     return false;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/cfg/LiveSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */