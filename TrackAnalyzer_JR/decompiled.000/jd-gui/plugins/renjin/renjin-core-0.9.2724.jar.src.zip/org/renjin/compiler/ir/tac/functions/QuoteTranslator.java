/*    */ package org.renjin.compiler.ir.tac.functions;
/*    */ 
/*    */ import org.renjin.compiler.NotCompilableException;
/*    */ import org.renjin.compiler.ir.tac.IRBodyBuilder;
/*    */ import org.renjin.compiler.ir.tac.expressions.Expression;
/*    */ import org.renjin.sexp.Function;
/*    */ import org.renjin.sexp.FunctionCall;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class QuoteTranslator
/*    */   extends FunctionCallTranslator
/*    */ {
/*    */   public Expression translateToExpression(IRBodyBuilder builder, TranslationContext context, Function resolvedFunction, FunctionCall call) {
/* 31 */     throw new NotCompilableException(call);
/*    */   }
/*    */ 
/*    */   
/*    */   public void addStatement(IRBodyBuilder builder, TranslationContext context, Function resolvedFunction, FunctionCall call) {
/* 36 */     throw new NotCompilableException(call);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/ir/tac/functions/QuoteTranslator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */