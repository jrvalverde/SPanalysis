/*    */ package org.renjin.compiler.ir.tac;
/*    */ 
/*    */ import org.renjin.compiler.ir.tac.expressions.Expression;
/*    */ import org.renjin.compiler.ir.tac.expressions.SimpleExpression;
/*    */ import org.renjin.sexp.Null;
/*    */ import org.renjin.sexp.SEXP;
/*    */ import org.renjin.sexp.Symbol;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IRArgument
/*    */ {
/*    */   private String name;
/*    */   private Expression expression;
/*    */   
/*    */   public IRArgument(String name, Expression expression) {
/* 34 */     this.name = name;
/* 35 */     this.expression = expression;
/*    */   }
/*    */   
/*    */   public IRArgument(SEXP name, SimpleExpression expression) {
/* 39 */     if (name == Null.INSTANCE) {
/* 40 */       this.name = null;
/* 41 */     } else if (name instanceof Symbol) {
/* 42 */       this.name = ((Symbol)name).getPrintName();
/*    */     } else {
/* 44 */       throw new IllegalArgumentException("name: " + name);
/*    */     } 
/* 46 */     this.expression = (Expression)expression;
/*    */   }
/*    */   
/*    */   public IRArgument(Expression expression) {
/* 50 */     this.name = null;
/* 51 */     this.expression = expression;
/*    */   }
/*    */   
/*    */   public boolean isNamed() {
/* 55 */     return (this.name != null);
/*    */   }
/*    */   
/*    */   public String getName() {
/* 59 */     return this.name;
/*    */   }
/*    */   
/*    */   public Expression getExpression() {
/* 63 */     return this.expression;
/*    */   }
/*    */   
/*    */   public void setExpression(Expression expression) {
/* 67 */     this.expression = expression;
/*    */   }
/*    */   
/*    */   public static boolean anyNamed(Iterable<IRArgument> arguments) {
/* 71 */     for (IRArgument argument : arguments) {
/* 72 */       if (argument.isNamed()) {
/* 73 */         return true;
/*    */       }
/*    */     } 
/* 76 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 81 */     if (isNamed()) {
/* 82 */       return this.name + " = " + this.expression;
/*    */     }
/* 84 */     return this.expression.toString();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/ir/tac/IRArgument.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */