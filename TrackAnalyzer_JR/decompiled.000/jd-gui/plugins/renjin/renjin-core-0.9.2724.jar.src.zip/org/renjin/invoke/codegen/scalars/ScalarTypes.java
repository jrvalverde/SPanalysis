/*    */ package org.renjin.invoke.codegen.scalars;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.apache.commons.math.complex.Complex;
/*    */ import org.renjin.invoke.codegen.GeneratorDefinitionException;
/*    */ import org.renjin.repackaged.guava.collect.Maps;
/*    */ import org.renjin.sexp.Logical;
/*    */ import org.renjin.sexp.SEXP;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ScalarTypes
/*    */ {
/* 31 */   private static final ScalarTypes INSTANCE = new ScalarTypes();
/*    */   
/* 33 */   private Map<Class, ScalarType> types = Maps.newHashMap();
/* 34 */   private SexpType sexpType = new SexpType();
/*    */ 
/*    */   
/*    */   private ScalarTypes() {
/* 38 */     this.types.put(int.class, new IntegerType());
/* 39 */     this.types.put(String.class, new StringType());
/* 40 */     this.types.put(boolean.class, new BooleanType());
/* 41 */     this.types.put(double.class, new DoubleType());
/* 42 */     this.types.put(float.class, new FloatType());
/* 43 */     this.types.put(Logical.class, new LogicalType());
/* 44 */     this.types.put(Complex.class, new ComplexType());
/* 45 */     this.types.put(byte.class, new ByteType());
/*    */   }
/*    */   
/*    */   public static boolean has(Class clazz) {
/* 49 */     return INSTANCE.types.containsKey(clazz);
/*    */   }
/*    */   
/*    */   public static ScalarType get(Class<?> clazz) {
/* 53 */     if (SEXP.class.isAssignableFrom(clazz)) {
/* 54 */       return INSTANCE.sexpType;
/*    */     }
/* 56 */     ScalarType type = INSTANCE.types.get(clazz);
/* 57 */     if (type == null) {
/* 58 */       throw new GeneratorDefinitionException(clazz.getName() + " cannot be recycled upon");
/*    */     }
/* 60 */     return type;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/codegen/scalars/ScalarTypes.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */