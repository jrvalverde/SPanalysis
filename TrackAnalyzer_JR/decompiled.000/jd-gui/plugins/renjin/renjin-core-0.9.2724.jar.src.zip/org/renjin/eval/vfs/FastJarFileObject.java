/*     */ package org.renjin.eval.vfs;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.util.jar.JarEntry;
/*     */ import org.apache.commons.vfs2.FileObject;
/*     */ import org.apache.commons.vfs2.FileSystemException;
/*     */ import org.apache.commons.vfs2.FileType;
/*     */ import org.apache.commons.vfs2.provider.AbstractFileName;
/*     */ import org.apache.commons.vfs2.provider.AbstractFileObject;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FastJarFileObject
/*     */   extends AbstractFileObject
/*     */   implements FileObject
/*     */ {
/*     */   private final FastJarFileSystem fs;
/*     */   protected JarEntry entry;
/*     */   private FileType type;
/*     */   
/*     */   protected FastJarFileObject(AbstractFileName name, JarEntry entry, FastJarFileSystem fs) throws FileSystemException {
/*  40 */     super(name, fs);
/*  41 */     this.fs = fs;
/*  42 */     setZipEntry(entry);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setZipEntry(JarEntry entry) {
/*  50 */     if (this.entry != null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/*  55 */     if (entry == null || entry.isDirectory()) {
/*     */       
/*  57 */       this.type = FileType.FOLDER;
/*     */     }
/*     */     else {
/*     */       
/*  61 */       this.type = FileType.FILE;
/*     */     } 
/*     */     
/*  64 */     this.entry = entry;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isWriteable() throws FileSystemException {
/*  75 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected FileType doGetType() {
/*  82 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String[] doListChildren() {
/*  89 */     return this.fs.listChildren(this.entry.getName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected long doGetContentSize() {
/*  97 */     return this.entry.getSize();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected long doGetLastModifiedTime() throws Exception {
/* 104 */     return this.entry.getTime();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected InputStream doGetInputStream() throws Exception {
/* 114 */     return this.fs.getInputStream(this.entry);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/eval/vfs/FastJarFileObject.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */