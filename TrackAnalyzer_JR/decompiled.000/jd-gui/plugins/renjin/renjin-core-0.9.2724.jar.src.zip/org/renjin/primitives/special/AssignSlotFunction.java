/*    */ package org.renjin.primitives.special;
/*    */ 
/*    */ import org.renjin.eval.Context;
/*    */ import org.renjin.eval.EvalException;
/*    */ import org.renjin.methods.Methods;
/*    */ import org.renjin.primitives.Attributes;
/*    */ import org.renjin.primitives.S3;
/*    */ import org.renjin.sexp.Environment;
/*    */ import org.renjin.sexp.FunctionCall;
/*    */ import org.renjin.sexp.Null;
/*    */ import org.renjin.sexp.PairList;
/*    */ import org.renjin.sexp.SEXP;
/*    */ import org.renjin.sexp.SpecialFunction;
/*    */ import org.renjin.sexp.StringArrayVector;
/*    */ import org.renjin.sexp.StringVector;
/*    */ import org.renjin.sexp.Symbol;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AssignSlotFunction
/*    */   extends SpecialFunction
/*    */ {
/*    */   public AssignSlotFunction() {
/* 32 */     super("@<-");
/*    */   }
/*    */ 
/*    */   
/*    */   public SEXP apply(Context context, Environment rho, FunctionCall call, PairList args) {
/*    */     String slotName;
/* 38 */     if (args.length() != 3) {
/* 39 */       throw new EvalException("Expected three arguments", new Object[0]);
/*    */     }
/* 41 */     SEXP object = context.evaluate(args.getElementAsSEXP(0), rho);
/* 42 */     if (object == Null.INSTANCE) {
/* 43 */       throw new EvalException("Cannot set slots on the NULL object", new Object[0]);
/*    */     }
/*    */ 
/*    */     
/* 47 */     SEXP which = args.getElementAsSEXP(1);
/* 48 */     if (which instanceof Symbol) {
/* 49 */       slotName = ((Symbol)which).getPrintName();
/* 50 */     } else if (which instanceof StringVector) {
/* 51 */       slotName = ((StringVector)which).getElementAsString(0);
/*    */     } else {
/* 53 */       throw new EvalException("invalid type '%s' for slot name", new Object[] { which.getTypeName() });
/*    */     } 
/*    */     
/* 56 */     SEXP unevaluatedValue = args.getElementAsSEXP(2);
/*    */ 
/*    */     
/* 59 */     PairList repackagedArgs = PairList.Node.fromArray(new SEXP[] { object, (SEXP)new StringArrayVector(new String[] { slotName }), unevaluatedValue });
/*    */     
/* 61 */     SEXP genericResult = S3.tryDispatchFromPrimitive(context, rho, call, getName(), object, repackagedArgs);
/* 62 */     if (genericResult != null) {
/* 63 */       return genericResult;
/*    */     }
/*    */ 
/*    */     
/* 67 */     SEXP rhs = context.evaluate(args.getElementAsSEXP(2));
/*    */ 
/*    */     
/* 70 */     StringVector valueClass = Attributes.getClass(rhs);
/* 71 */     StringVector stringVector1 = object.getS3Class();
/*    */     
/* 73 */     context.getSession()
/* 74 */       .getS4Cache()
/* 75 */       .getS4ClassCache()
/* 76 */       .lookupClass(context, stringVector1.asString())
/* 77 */       .getSlot(context, slotName)
/* 78 */       .checkAssignment(context, valueClass.getElementAsString(0));
/*    */ 
/*    */ 
/*    */     
/* 82 */     return Methods.R_set_slot(context, object, slotName, rhs);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/special/AssignSlotFunction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */