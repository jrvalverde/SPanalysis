/*     */ package org.renjin.compiler.cfg;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.renjin.compiler.ir.tac.IRBody;
/*     */ import org.renjin.compiler.ir.tac.IRLabel;
/*     */ import org.renjin.compiler.ir.tac.statements.Statement;
/*     */ import org.renjin.repackaged.guava.collect.Lists;
/*     */ import org.renjin.repackaged.guava.collect.Maps;
/*     */ import org.renjin.util.DebugGraph;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ControlFlowGraph
/*     */ {
/*     */   private final IRBody parent;
/*     */   private final List<BasicBlock> basicBlocks;
/*     */   private BasicBlock entry;
/*     */   private BasicBlock exit;
/*  37 */   private Map<IRLabel, BasicBlock> basicBlockMap = Maps.newHashMap();
/*     */   
/*     */   public ControlFlowGraph(IRBody body) {
/*  40 */     this.parent = body;
/*  41 */     this.basicBlocks = Lists.newArrayList();
/*     */     
/*  43 */     addBasicBlocks();
/*  44 */     linkBasicBlocks();
/*  45 */     removeDeadBlocks();
/*     */   }
/*     */ 
/*     */   
/*     */   private void addBasicBlocks() {
/*  50 */     this.entry = new BasicBlock(this.parent);
/*  51 */     this.entry.setDebugId("entry");
/*  52 */     this.basicBlocks.add(this.entry);
/*     */     
/*  54 */     BasicBlock current = null;
/*  55 */     for (int i = 0; i < this.parent.getStatements().size(); i++) {
/*  56 */       Statement stmt = this.parent.getStatements().get(i);
/*     */       
/*  58 */       if (current == null || this.parent.isLabeled(i)) {
/*  59 */         current = addNewBasicBlock(this.parent, i);
/*     */       } else {
/*  61 */         current.addStatement(stmt);
/*     */       } 
/*     */       
/*  64 */       if (stmt instanceof org.renjin.compiler.ir.tac.statements.BasicBlockEndingStatement) {
/*  65 */         current = null;
/*     */       }
/*     */     } 
/*     */     
/*  69 */     this.exit = new BasicBlock(this.parent);
/*  70 */     this.exit.setDebugId("exit");
/*  71 */     this.basicBlocks.add(this.exit);
/*     */ 
/*     */     
/*  74 */     addEdge(this.entry, this.exit);
/*     */   }
/*     */   
/*     */   public List<BasicBlock> getLiveBasicBlocks() {
/*  78 */     return Collections.unmodifiableList(this.basicBlocks);
/*     */   }
/*     */   
/*     */   private BasicBlock addNewBasicBlock(IRBody body, int i) {
/*  82 */     BasicBlock bb = BasicBlock.createWithStartAt(body, i);
/*  83 */     bb.setDebugId(this.basicBlocks.size());
/*  84 */     this.basicBlocks.add(bb);
/*  85 */     for (IRLabel label : bb.getLabels()) {
/*  86 */       this.basicBlockMap.put(label, bb);
/*     */     }
/*  88 */     return bb;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void linkBasicBlocks() {
/*  94 */     for (int i = 1; i < this.basicBlocks.size() - 1; i++) {
/*  95 */       BasicBlock bb = this.basicBlocks.get(i);
/*  96 */       if (bb.fallsThrough()) {
/*  97 */         addEdge(bb, this.basicBlocks.get(i + 1));
/*     */       }
/*  99 */       else if (bb.returns()) {
/* 100 */         addEdge(bb, this.exit);
/*     */       } else {
/*     */         
/* 103 */         for (IRLabel targetLabel : bb.targets()) {
/* 104 */           BasicBlock targetBB = this.basicBlockMap.get(targetLabel);
/* 105 */           if (targetBB == null) {
/* 106 */             throw new NullPointerException("whoops! no basic block with label '" + targetLabel + "' in IRBody " + this.parent);
/*     */           }
/*     */           
/* 109 */           addEdge(bb, targetBB);
/*     */         } 
/*     */       } 
/*     */     } 
/* 113 */     addEdge(this.entry, this.basicBlocks.get(1));
/*     */   }
/*     */   
/*     */   private void addEdge(BasicBlock bb, BasicBlock basicBlock) {
/* 117 */     bb.addFlowSuccessor(basicBlock);
/*     */   }
/*     */   
/*     */   private void removeDeadBlocks() {
/*     */     boolean changing;
/* 122 */     Set<BasicBlock> live = new HashSet<>();
/* 123 */     live.add(this.entry);
/* 124 */     live.add(this.basicBlocks.get(1));
/*     */ 
/*     */     
/*     */     do {
/* 128 */       changing = false;
/*     */       
/* 130 */       for (BasicBlock basicBlock : Lists.newArrayList(live)) {
/* 131 */         if (live.addAll(basicBlock.getFlowSuccessors())) {
/* 132 */           changing = true;
/*     */         }
/*     */       } 
/* 135 */     } while (changing);
/*     */ 
/*     */     
/* 138 */     this.basicBlocks.retainAll(live);
/* 139 */     for (BasicBlock basicBlock : this.basicBlocks) {
/* 140 */       basicBlock.removeDeadEdges(live);
/*     */     }
/*     */     
/* 143 */     int i = 1;
/* 144 */     for (BasicBlock bb : this.basicBlocks) {
/* 145 */       if (bb != this.entry && bb != this.exit) {
/* 146 */         bb.setDebugId(i++);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public List<BasicBlock> getBasicBlocks() {
/* 152 */     return this.basicBlocks;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 157 */     StringBuilder sb = new StringBuilder();
/* 158 */     for (BasicBlock bb : this.basicBlocks) {
/* 159 */       sb.append("\n" + bb.toString());
/* 160 */       if (bb.getLabels() != null) {
/* 161 */         sb.append(": ").append(bb.getLabels());
/*     */       }
/* 163 */       sb.append(" =============\n");
/* 164 */       sb.append(bb.statementsToString());
/*     */     } 
/* 166 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public BasicBlock getEntry() {
/* 170 */     return this.entry;
/*     */   }
/*     */   
/*     */   public BasicBlock getExit() {
/* 174 */     return this.exit;
/*     */   }
/*     */   
/*     */   public List<BasicBlock> getSuccessors(BasicBlock x) {
/* 178 */     return x.getFlowSuccessors();
/*     */   }
/*     */   
/*     */   public List<BasicBlock> getPredecessors(BasicBlock x) {
/* 182 */     return x.getFlowPredecessors();
/*     */   }
/*     */   
/*     */   public void dumpGraph() {
/* 186 */     DebugGraph dump = new DebugGraph("compute");
/* 187 */     for (BasicBlock basicBlock : this.basicBlocks) {
/* 188 */       for (BasicBlock successor : basicBlock.getFlowSuccessors()) {
/* 189 */         dump.printEdge(basicBlock.getDebugId(), successor.getDebugId());
/*     */       }
/*     */     } 
/* 192 */     dump.close();
/*     */   }
/*     */   
/*     */   public void dumpEdges() {
/* 196 */     for (BasicBlock basicBlock : this.basicBlocks) {
/* 197 */       for (BasicBlock block : basicBlock.getFlowSuccessors()) {
/* 198 */         System.out.println("edge[" + basicBlock.getDebugId() + ", " + block.getDebugId() + "]");
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public BasicBlock get(String debugId) {
/* 204 */     for (BasicBlock basicBlock : this.basicBlocks) {
/* 205 */       if (basicBlock.getDebugId().equals(debugId)) {
/* 206 */         return basicBlock;
/*     */       }
/*     */     } 
/* 209 */     throw new IllegalArgumentException("No such block: " + debugId);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/cfg/ControlFlowGraph.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */