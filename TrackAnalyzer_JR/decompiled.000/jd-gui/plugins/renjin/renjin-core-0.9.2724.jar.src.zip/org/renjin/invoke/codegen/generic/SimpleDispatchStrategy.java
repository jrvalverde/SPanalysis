/*    */ package org.renjin.invoke.codegen.generic;
/*    */ 
/*    */ import com.sun.codemodel.JBlock;
/*    */ import com.sun.codemodel.JCodeModel;
/*    */ import com.sun.codemodel.JExpr;
/*    */ import com.sun.codemodel.JExpression;
/*    */ import com.sun.codemodel.JType;
/*    */ import com.sun.codemodel.JVar;
/*    */ import org.renjin.invoke.codegen.ApplyMethodContext;
/*    */ import org.renjin.primitives.S3;
/*    */ import org.renjin.sexp.SEXP;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SimpleDispatchStrategy
/*    */   extends GenericDispatchStrategy
/*    */ {
/*    */   private final String name;
/*    */   
/*    */   public SimpleDispatchStrategy(JCodeModel codeModel, String name) {
/* 37 */     super(codeModel);
/* 38 */     this.name = name;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void afterFirstArgIsEvaluated(ApplyMethodContext context, JExpression functionCall, JExpression arguments, JBlock parent, JExpression argument) {
/* 46 */     JBlock ifObject = parent._if((JExpression)fastIsObject(argument))._then();
/* 47 */     JVar jVar = ifObject.decl((JType)this.codeModel.ref(SEXP.class), "genericResult", (JExpression)this.codeModel
/* 48 */         .ref(S3.class).staticInvoke("tryDispatchFromPrimitive")
/* 49 */         .arg(context.getContext())
/* 50 */         .arg(context.getEnvironment())
/* 51 */         .arg(functionCall)
/* 52 */         .arg(JExpr.lit(this.name))
/* 53 */         .arg(argument)
/* 54 */         .arg(arguments));
/* 55 */     ifObject._if(jVar.ne(JExpr._null()))._then()._return((JExpression)jVar);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/codegen/generic/SimpleDispatchStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */