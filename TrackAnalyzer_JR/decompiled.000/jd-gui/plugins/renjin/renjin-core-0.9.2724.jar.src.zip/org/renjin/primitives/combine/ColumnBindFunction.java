/*    */ package org.renjin.primitives.combine;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.renjin.eval.Context;
/*    */ import org.renjin.sexp.AtomicVector;
/*    */ import org.renjin.sexp.Null;
/*    */ import org.renjin.sexp.SEXP;
/*    */ import org.renjin.sexp.Vector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ColumnBindFunction
/*    */   extends AbstractBindFunction
/*    */ {
/*    */   public ColumnBindFunction() {
/* 35 */     super("cbind", MatrixDim.COL);
/*    */   }
/*    */ 
/*    */   
/*    */   public SEXP apply(Context context, List<BindArgument> bindArguments) {
/* 40 */     int rows = computeRowCount(bindArguments, context);
/*    */ 
/*    */ 
/*    */     
/* 44 */     if (rows > 0) {
/* 45 */       bindArguments = excludeZeroLengthVectors(bindArguments);
/*    */     }
/*    */ 
/*    */ 
/*    */     
/* 50 */     int columns = countRowOrCols(bindArguments, MatrixDim.COL);
/*    */ 
/*    */     
/* 53 */     Vector.Builder vectorBuilder = builderForCommonType(bindArguments);
/* 54 */     Matrix2dBuilder builder = new Matrix2dBuilder(vectorBuilder, rows, columns);
/* 55 */     for (BindArgument argument : bindArguments) {
/* 56 */       if (!argument.isZeroLength()) {
/* 57 */         for (int j = 0; j != argument.getCols(); j++) {
/* 58 */           for (int i = 0; i != rows; i++) {
/* 59 */             builder.addFrom(argument, i, j);
/*    */           }
/*    */         } 
/*    */       }
/*    */     } 
/*    */     
/* 65 */     AtomicVector rowNames = dimNamesFromLongest(bindArguments, MatrixDim.ROW, rows);
/* 66 */     AtomicVector colNames = combineDimNames(bindArguments, MatrixDim.COL);
/*    */     
/* 68 */     if (allZeroLengthVectors(bindArguments)) {
/*    */ 
/*    */       
/* 71 */       builder.setDimNames((AtomicVector)Null.INSTANCE, (AtomicVector)Null.INSTANCE);
/*    */     }
/* 73 */     else if (rowNames != Null.INSTANCE || colNames != Null.INSTANCE) {
/* 74 */       builder.setDimNames(rowNames, colNames);
/*    */     } 
/*    */     
/* 77 */     return (SEXP)builder.build();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   private int computeRowCount(List<BindArgument> bindArguments, Context context) {
/* 83 */     int rows = findCommonMatrixDimLength(bindArguments, MatrixDim.ROW);
/*    */ 
/*    */ 
/*    */     
/* 87 */     if (rows == -1) {
/* 88 */       rows = findMaxLength(bindArguments);
/*    */     }
/*    */     
/* 91 */     warnIfVectorLengthsAreNotMultiple(context, bindArguments, rows);
/* 92 */     return rows;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/combine/ColumnBindFunction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */