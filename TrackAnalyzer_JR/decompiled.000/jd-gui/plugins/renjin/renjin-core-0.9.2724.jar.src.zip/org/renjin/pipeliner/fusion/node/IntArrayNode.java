/*    */ package org.renjin.pipeliner.fusion.node;
/*    */ 
/*    */ import java.util.Optional;
/*    */ import org.renjin.pipeliner.ComputeMethod;
/*    */ import org.renjin.repackaged.asm.Label;
/*    */ import org.renjin.repackaged.asm.MethodVisitor;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IntArrayNode
/*    */   extends LoopNode
/*    */ {
/*    */   protected int arrayLocalIndex;
/*    */   protected int operandIndex;
/*    */   private String vectorType;
/*    */   
/*    */   public IntArrayNode(int operandIndex, Type vectorType) {
/* 41 */     this.operandIndex = operandIndex;
/* 42 */     this.vectorType = vectorType.getInternalName();
/*    */   }
/*    */ 
/*    */   
/*    */   public void init(ComputeMethod method) {
/* 47 */     this.arrayLocalIndex = method.reserveLocal(1);
/*    */     
/* 49 */     MethodVisitor mv = method.getVisitor();
/* 50 */     mv.visitVarInsn(25, method.getOperandsLocalIndex());
/* 51 */     pushIntConstant(mv, this.operandIndex);
/* 52 */     mv.visitInsn(50);
/* 53 */     mv.visitTypeInsn(192, this.vectorType);
/* 54 */     mv.visitMethodInsn(182, this.vectorType, "toIntArrayUnsafe", "()[I", false);
/* 55 */     mv.visitVarInsn(58, this.arrayLocalIndex);
/*    */   }
/*    */ 
/*    */   
/*    */   public void pushLength(ComputeMethod method) {
/* 60 */     MethodVisitor mv = method.getVisitor();
/* 61 */     mv.visitVarInsn(25, this.arrayLocalIndex);
/* 62 */     mv.visitInsn(190);
/*    */   }
/*    */ 
/*    */   
/*    */   public void pushElementAsDouble(ComputeMethod method, Optional<Label> integerNaLabel) {
/* 67 */     pushElementAsInt(method, integerNaLabel);
/* 68 */     MethodVisitor mv = method.getVisitor();
/* 69 */     mv.visitInsn(135);
/*    */   }
/*    */ 
/*    */   
/*    */   public void pushElementAsInt(ComputeMethod method, Optional<Label> integerNaLabel) {
/* 74 */     MethodVisitor mv = method.getVisitor();
/* 75 */     mv.visitVarInsn(25, this.arrayLocalIndex);
/* 76 */     mv.visitInsn(95);
/* 77 */     mv.visitInsn(46);
/* 78 */     doIntegerNaCheck(mv, integerNaLabel);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean mustCheckForIntegerNAs() {
/* 83 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public void appendToKey(StringBuilder key) {
/* 88 */     key.append("IAN:" + this.vectorType);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 93 */     return "x" + this.operandIndex;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/pipeliner/fusion/node/IntArrayNode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */