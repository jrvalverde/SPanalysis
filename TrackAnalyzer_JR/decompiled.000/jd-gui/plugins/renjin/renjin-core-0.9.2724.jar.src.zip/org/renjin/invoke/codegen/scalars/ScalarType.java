/*    */ package org.renjin.invoke.codegen.scalars;
/*    */ 
/*    */ import com.sun.codemodel.JClass;
/*    */ import com.sun.codemodel.JCodeModel;
/*    */ import com.sun.codemodel.JExpr;
/*    */ import com.sun.codemodel.JExpression;
/*    */ import com.sun.codemodel.JFieldRef;
/*    */ import com.sun.codemodel.JType;
/*    */ import com.sun.codemodel.JVar;
/*    */ import org.renjin.invoke.annotations.DownCastComplex;
/*    */ import org.renjin.invoke.model.JvmMethod;
/*    */ import org.renjin.sexp.ComplexVector;
/*    */ import org.renjin.sexp.Vector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ScalarType
/*    */ {
/*    */   public abstract Class getScalarType();
/*    */   
/*    */   public abstract String getConversionMethod();
/*    */   
/*    */   public abstract String getAccessorMethod();
/*    */   
/*    */   public abstract Class getVectorType();
/*    */   
/*    */   public abstract Class<? extends Vector.Builder<?>> getBuilderClass();
/*    */   
/*    */   public abstract Class getBuilderArrayElementClass();
/*    */   
/*    */   public JExpression toBuildArrayElementType(JExpression resultValue) {
/* 43 */     return resultValue;
/*    */   }
/*    */   
/*    */   public abstract Class getArrayVectorClass();
/*    */   
/*    */   public JExpression testExpr(JCodeModel codeModel, JVar sexpVariable, JvmMethod.Argument formal) {
/* 49 */     JClass vectorClass = codeModel.ref(Vector.class);
/* 50 */     JFieldRef jFieldRef = codeModel.ref(getVectorType()).staticRef("VECTOR_TYPE");
/*    */     
/* 52 */     JExpression condition = sexpVariable._instanceof((JType)vectorClass).cand((JExpression)jFieldRef.invoke("isWiderThanOrEqualTo").arg((JExpression)JExpr.cast((JType)vectorClass, (JExpression)sexpVariable)));
/*    */     
/* 54 */     if (formal.isAnnotatedWith(DownCastComplex.class)) {
/* 55 */       condition = condition.cor(sexpVariable._instanceof((JType)codeModel.ref(ComplexVector.class)));
/*    */     }
/*    */     
/* 58 */     return condition;
/*    */   }
/*    */   
/*    */   public Vector.Type getVectorTypeInstance() {
/*    */     try {
/* 63 */       return (Vector.Type)getVectorType().getField("VECTOR_TYPE").get(null);
/* 64 */     } catch (Exception e) {
/* 65 */       throw new RuntimeException(e);
/*    */     } 
/*    */   }
/*    */   
/*    */   public abstract JExpression naLiteral(JCodeModel paramJCodeModel);
/*    */   
/*    */   public JExpression testNaExpr(JCodeModel codeModel, JVar scalarVariable) {
/* 72 */     return (JExpression)codeModel.ref(getVectorType()).staticInvoke("isNA").arg((JExpression)scalarVariable);
/*    */   }
/*    */ 
/*    */   
/*    */   public Class<?> getElementStorageType() {
/* 77 */     return getScalarType();
/*    */   }
/*    */ 
/*    */   
/*    */   public JExpression fromElementStorageType(JExpression expression) {
/* 82 */     return expression;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/codegen/scalars/ScalarType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */