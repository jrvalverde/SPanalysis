/*    */ package org.renjin.invoke.reflection;
/*    */ 
/*    */ import org.renjin.sexp.SEXP;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ExceptionUtil
/*    */ {
/*    */   static String toString(Iterable<SEXP> args) {
/* 26 */     StringBuilder list = new StringBuilder();
/* 27 */     for (SEXP arg : args) {
/* 28 */       if (arg == null) {
/*    */         break;
/*    */       }
/* 31 */       if (list.length() > 0) {
/* 32 */         list.append(", ");
/*    */       }
/* 34 */       list.append(arg.getTypeName());
/*    */     } 
/* 36 */     return list.toString();
/*    */   }
/*    */   
/*    */   static String overloadListToString(Iterable<?> overloads) {
/* 40 */     StringBuilder sb = new StringBuilder();
/* 41 */     for (Object overload : overloads) {
/* 42 */       sb.append("\n\t").append(overload.toString());
/*    */     }
/* 44 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/reflection/ExceptionUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */