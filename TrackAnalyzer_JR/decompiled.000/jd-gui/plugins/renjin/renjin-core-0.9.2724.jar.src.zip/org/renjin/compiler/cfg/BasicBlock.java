/*     */ package org.renjin.compiler.cfg;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ import java.util.Set;
/*     */ import org.renjin.compiler.ir.ssa.PhiFunction;
/*     */ import org.renjin.compiler.ir.tac.IRBody;
/*     */ import org.renjin.compiler.ir.tac.IRLabel;
/*     */ import org.renjin.compiler.ir.tac.expressions.Expression;
/*     */ import org.renjin.compiler.ir.tac.expressions.LValue;
/*     */ import org.renjin.compiler.ir.tac.expressions.Variable;
/*     */ import org.renjin.compiler.ir.tac.statements.Assignment;
/*     */ import org.renjin.compiler.ir.tac.statements.Statement;
/*     */ import org.renjin.repackaged.guava.collect.Iterables;
/*     */ import org.renjin.repackaged.guava.collect.Lists;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BasicBlock
/*     */ {
/*     */   private final IRBody parent;
/*     */   private String debugId;
/*     */   private Set<IRLabel> labels;
/*  40 */   private List<Statement> statements = Lists.newLinkedList();
/*     */   
/*  42 */   List<BasicBlock> flowSuccessors = new ArrayList<>();
/*  43 */   List<BasicBlock> flowPredecessors = new ArrayList<>();
/*     */   
/*  45 */   List<BasicBlock> dominanceSuccessors = new ArrayList<>();
/*  46 */   List<BasicBlock> dominancePredecessors = new ArrayList<>();
/*     */   
/*  48 */   final List<FlowEdge> outgoing = new ArrayList<>();
/*  49 */   final List<FlowEdge> incoming = new ArrayList<>();
/*     */   
/*     */   private boolean live = false;
/*     */ 
/*     */   
/*     */   public BasicBlock(IRBody parent) {
/*  55 */     this.parent = parent;
/*     */   }
/*     */   
/*     */   public void addStatement(Statement statement) {
/*  59 */     this.statements.add(statement);
/*     */   }
/*     */   
/*     */   public void insertPhiFunction(Variable variable, List<FlowEdge> incomingEdges) {
/*  63 */     this.statements.add(0, new Assignment((LValue)variable, (Expression)new PhiFunction(variable, incomingEdges)));
/*     */   }
/*     */   
/*     */   public boolean isLive() {
/*  67 */     return this.live;
/*     */   }
/*     */   
/*     */   public void setLive(boolean live) {
/*  71 */     this.live = live;
/*     */   }
/*     */   
/*     */   public Statement replaceStatement(Statement stmt, Statement newStmt) {
/*  75 */     int i = this.statements.indexOf(stmt);
/*  76 */     this.statements.set(i, newStmt);
/*  77 */     return newStmt;
/*     */   }
/*     */   
/*     */   public void replaceStatement(int i, Statement stmt) {
/*  81 */     this.statements.set(i, stmt);
/*     */   }
/*     */   
/*     */   public List<Statement> getStatements() {
/*  85 */     return this.statements;
/*     */   }
/*     */   
/*     */   public void setDebugId(int index) {
/*  89 */     this.debugId = "BB" + index;
/*     */   }
/*     */   
/*     */   public void setDebugId(String string) {
/*  93 */     this.debugId = string;
/*     */   }
/*     */   
/*     */   public static BasicBlock createWithStartAt(IRBody parent, int statementIndex) {
/*  97 */     BasicBlock block = new BasicBlock(parent);
/*  98 */     block.labels = parent.getIntructionLabels(statementIndex);
/*  99 */     block.statements = Lists.newArrayList();
/* 100 */     block.statements.add(parent.getStatements().get(statementIndex));
/* 101 */     return block;
/*     */   }
/*     */   
/*     */   public Set<IRLabel> getLabels() {
/* 105 */     return this.labels;
/*     */   }
/*     */   
/*     */   public boolean isLabeled() {
/* 109 */     return !this.labels.isEmpty();
/*     */   }
/*     */   
/*     */   public Statement getTerminal() {
/* 113 */     return this.statements.get(this.statements.size() - 1);
/*     */   }
/*     */   
/*     */   public void addFlowSuccessor(BasicBlock successor) {
/* 117 */     FlowEdge edge = new FlowEdge(this, successor);
/* 118 */     this.outgoing.add(edge);
/* 119 */     this.flowSuccessors.add(successor);
/* 120 */     successor.incoming.add(edge);
/* 121 */     successor.flowPredecessors.add(this);
/*     */   }
/*     */   
/*     */   public void addDominanceSuccessor(BasicBlock basicBlock) {
/* 125 */     this.dominanceSuccessors.add(basicBlock);
/* 126 */     basicBlock.dominancePredecessors.add(this);
/*     */   }
/*     */   
/*     */   public List<FlowEdge> getIncoming() {
/* 130 */     return this.incoming;
/*     */   }
/*     */   
/*     */   public List<FlowEdge> getOutgoing() {
/* 134 */     return this.outgoing;
/*     */   }
/*     */   
/*     */   public FlowEdge getOutgoing(IRLabel target) {
/* 138 */     for (FlowEdge flowEdge : this.outgoing) {
/* 139 */       if (flowEdge.getSuccessor().getLabels().contains(target)) {
/* 140 */         return flowEdge;
/*     */       }
/*     */     } 
/* 143 */     throw new IllegalStateException("No outgoing edge to " + target);
/*     */   }
/*     */   
/*     */   public List<BasicBlock> getFlowSuccessors() {
/* 147 */     return this.flowSuccessors;
/*     */   }
/*     */   
/*     */   public List<BasicBlock> getFlowPredecessors() {
/* 151 */     return this.flowPredecessors;
/*     */   }
/*     */   
/*     */   public List<BasicBlock> getDominanceSuccessors() {
/* 155 */     return this.dominanceSuccessors;
/*     */   }
/*     */   
/*     */   public List<BasicBlock> getDominancePredecessors() {
/* 159 */     return this.dominancePredecessors;
/*     */   }
/*     */   
/*     */   public boolean returns() {
/* 163 */     return getTerminal() instanceof org.renjin.compiler.ir.tac.statements.ReturnStatement;
/*     */   }
/*     */   
/*     */   public boolean fallsThrough() {
/* 167 */     Statement terminal = getTerminal();
/* 168 */     return (!(terminal instanceof org.renjin.compiler.ir.tac.statements.GotoStatement) && !(terminal instanceof org.renjin.compiler.ir.tac.statements.IfStatement) && !(terminal instanceof org.renjin.compiler.ir.tac.statements.ReturnStatement));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterable<IRLabel> targets() {
/* 174 */     return getTerminal().possibleTargets();
/*     */   }
/*     */   
/*     */   public String statementsToString() {
/* 178 */     StringBuilder sb = new StringBuilder();
/* 179 */     for (Statement statement : this.statements) {
/* 180 */       sb.append(statement).append("\n");
/*     */     }
/* 182 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public Iterable<Assignment> assignments() {
/* 186 */     return Iterables.filter(this.statements, Assignment.class);
/*     */   }
/*     */   
/*     */   public Iterable<Assignment> phiAssignments() {
/* 190 */     return Iterables.filter(this.statements, CfgPredicates.isPhiAssignment());
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 195 */     return this.debugId;
/*     */   }
/*     */   
/*     */   public String getDebugId() {
/* 199 */     return this.debugId;
/*     */   }
/*     */   
/*     */   public void addStatementBeforeJump(Assignment assignment) {
/* 203 */     int pos = getStatements().size();
/* 204 */     if (!fallsThrough()) {
/* 205 */       pos--;
/*     */     }
/* 207 */     getStatements().add(pos, assignment);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 213 */     return this.debugId.hashCode();
/*     */   }
/*     */   
/*     */   public void removeDeadEdges(Set<BasicBlock> live) {
/* 217 */     this.flowPredecessors.retainAll(live);
/* 218 */     this.flowSuccessors.retainAll(live);
/*     */     
/* 220 */     ListIterator<FlowEdge> incomingIt = this.incoming.listIterator();
/* 221 */     while (incomingIt.hasNext()) {
/* 222 */       if (!live.contains(((FlowEdge)incomingIt.next()).getPredecessor())) {
/* 223 */         incomingIt.remove();
/*     */       }
/*     */     } 
/*     */     
/* 227 */     ListIterator<FlowEdge> outgoingIt = this.outgoing.listIterator();
/* 228 */     while (outgoingIt.hasNext()) {
/* 229 */       if (!live.contains(((FlowEdge)outgoingIt.next()).getSuccessor())) {
/* 230 */         outgoingIt.remove();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPure() {
/* 237 */     for (Statement statement : this.statements) {
/* 238 */       if (!statement.isPure()) {
/* 239 */         return false;
/*     */       }
/*     */     } 
/* 242 */     return true;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/cfg/BasicBlock.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */