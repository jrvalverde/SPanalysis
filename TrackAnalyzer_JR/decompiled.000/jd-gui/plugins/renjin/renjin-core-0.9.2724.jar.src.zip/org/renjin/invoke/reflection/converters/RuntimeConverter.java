/*    */ package org.renjin.invoke.reflection.converters;
/*    */ 
/*    */ import org.renjin.sexp.SEXP;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RuntimeConverter
/*    */   implements Converter<Object>
/*    */ {
/* 25 */   public static final RuntimeConverter INSTANCE = new RuntimeConverter();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SEXP convertToR(Object value) {
/* 33 */     Converter<Object> converter = Converters.get(value.getClass());
/* 34 */     return converter.convertToR(value);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object convertToJava(SEXP value) {
/* 39 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean acceptsSEXP(SEXP exp) {
/* 44 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   
/*    */   public int getSpecificity() {
/* 49 */     return Integer.MAX_VALUE;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/reflection/converters/RuntimeConverter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */