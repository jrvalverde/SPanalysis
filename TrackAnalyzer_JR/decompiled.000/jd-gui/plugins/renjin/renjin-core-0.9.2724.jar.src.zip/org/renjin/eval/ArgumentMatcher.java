/*     */ package org.renjin.eval;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import org.renjin.sexp.Closure;
/*     */ import org.renjin.sexp.PairList;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.Symbol;
/*     */ import org.renjin.sexp.Symbols;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ArgumentMatcher
/*     */ {
/*     */   private final String[] formalNames;
/*     */   private final SEXP[] defaultValues;
/*     */   private int formalEllipses;
/*     */   
/*     */   public ArgumentMatcher(Closure closure) {
/*  41 */     this(closure.getFormals());
/*     */   }
/*     */   
/*     */   public ArgumentMatcher(PairList formals) {
/*  45 */     int formalCount = formals.length();
/*  46 */     this.formalNames = new String[formalCount];
/*  47 */     this.formalEllipses = -1;
/*  48 */     this.defaultValues = new SEXP[formalCount];
/*     */     
/*  50 */     int i = 0;
/*  51 */     for (PairList.Node node : formals.nodes()) {
/*  52 */       SEXP tag = node.getRawTag();
/*  53 */       if (tag instanceof Symbol) {
/*  54 */         Symbol formalName = (Symbol)tag;
/*  55 */         if (formalName == Symbols.ELLIPSES) {
/*  56 */           this.formalEllipses = i;
/*     */         }
/*  58 */         this.formalNames[i] = formalName.getPrintName();
/*     */       } 
/*  60 */       this.defaultValues[i] = node.getValue();
/*  61 */       i++;
/*     */     } 
/*     */   }
/*     */   
/*     */   public ArgumentMatcher(String... formalNames) {
/*  66 */     this.formalNames = Arrays.<String>copyOf(formalNames, formalNames.length);
/*  67 */     this.defaultValues = new SEXP[formalNames.length];
/*  68 */     Arrays.fill((Object[])this.defaultValues, Symbol.MISSING_ARG);
/*  69 */     this.formalEllipses = -1;
/*  70 */     for (int i = 0; i < formalNames.length; i++) {
/*  71 */       if (formalNames[i].equals("...")) {
/*  72 */         this.formalEllipses = i;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNamedFormalCount() {
/*  81 */     if (this.formalEllipses == -1) {
/*  82 */       return this.formalNames.length;
/*     */     }
/*  84 */     return this.formalNames.length - 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MatchedArgumentPositions match(String[] actualNames) {
/* 113 */     int[] formalToActual = new int[this.formalNames.length];
/* 114 */     Arrays.fill(formalToActual, -1);
/*     */     
/* 116 */     boolean[] matchedFormals = new boolean[this.formalNames.length];
/* 117 */     boolean[] matchedActuals = new boolean[actualNames.length];
/*     */ 
/*     */     
/* 120 */     for (int formalIndex = 0; formalIndex < this.formalNames.length; formalIndex++) {
/* 121 */       String formalName = this.formalNames[formalIndex];
/* 122 */       if (formalIndex != this.formalEllipses) {
/* 123 */         int exactMatchIndex = findExactMatch(formalName, actualNames);
/* 124 */         if (exactMatchIndex != -1) {
/* 125 */           formalToActual[formalIndex] = exactMatchIndex;
/* 126 */           matchedActuals[exactMatchIndex] = true;
/* 127 */           matchedFormals[formalIndex] = true;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 132 */     for (int actualIndex = 0; actualIndex < actualNames.length; actualIndex++) {
/* 133 */       if (!matchedActuals[actualIndex]) {
/* 134 */         String actualName = actualNames[actualIndex];
/* 135 */         if (actualName != null && !actualName.equals("...")) {
/* 136 */           int partialMatch = findPartialMatch(actualName, this.formalNames, matchedFormals);
/* 137 */           if (partialMatch != -1) {
/* 138 */             formalToActual[partialMatch] = actualIndex;
/* 139 */             matchedActuals[actualIndex] = true;
/* 140 */             matchedFormals[partialMatch] = true;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 148 */     int nextActual = 0;
/* 149 */     for (int i = 0; i < this.formalNames.length && 
/* 150 */       i != this.formalEllipses; i++) {
/*     */ 
/*     */       
/* 153 */       if (!matchedFormals[i]) {
/* 154 */         nextActual = findNextUnnamed(actualNames, nextActual);
/* 155 */         if (nextActual == -1) {
/*     */           break;
/*     */         }
/* 158 */         formalToActual[i] = nextActual;
/* 159 */         matchedActuals[nextActual] = true;
/* 160 */         nextActual++;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 165 */     if (this.formalEllipses == -1 && 
/* 166 */       hasUnmatched(matchedActuals)) {
/* 167 */       throw new EvalException("Unused arguments", new Object[0]);
/*     */     }
/*     */ 
/*     */     
/* 171 */     return new MatchedArgumentPositions(this.formalNames, formalToActual, matchedActuals, this.formalEllipses);
/*     */   }
/*     */   
/*     */   public MatchedArguments match(PairList actuals) {
/* 175 */     int numActuals = actuals.length();
/* 176 */     SEXP[] actualTags = new SEXP[numActuals];
/* 177 */     String[] actualNames = new String[numActuals];
/* 178 */     SEXP[] actualValues = new SEXP[numActuals];
/*     */     
/* 180 */     int i = 0;
/* 181 */     for (PairList.Node node : actuals.nodes()) {
/* 182 */       actualTags[i] = node.getRawTag();
/* 183 */       if (node.hasName()) {
/* 184 */         actualNames[i] = node.getName();
/*     */       }
/* 186 */       actualValues[i] = node.getValue();
/* 187 */       i++;
/*     */     } 
/*     */ 
/*     */     
/* 191 */     return new MatchedArguments(match(actualNames), actualTags, actualValues);
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean hasUnmatched(boolean[] matchedActuals) {
/* 196 */     for (int i = 0; i < matchedActuals.length; i++) {
/* 197 */       if (!matchedActuals[i]) {
/* 198 */         return true;
/*     */       }
/*     */     } 
/* 201 */     return false;
/*     */   }
/*     */   
/*     */   private static int findNextUnnamed(String[] actualNames, int start) {
/* 205 */     int i = start;
/* 206 */     while (i < actualNames.length) {
/* 207 */       if (actualNames[i] == null) {
/* 208 */         return i;
/*     */       }
/* 210 */       i++;
/*     */     } 
/* 212 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int findExactMatch(String formalName, String[] argumentNames) {
/* 223 */     int match = -1;
/*     */     
/* 225 */     for (int i = 0; i < argumentNames.length; i++) {
/* 226 */       if (argumentNames[i] != null && 
/* 227 */         argumentNames[i].equals(formalName)) {
/* 228 */         if (match != -1) {
/* 229 */           throw new EvalException(String.format("Multiple named values provided for argument '%s'", new Object[] { formalName }), new Object[0]);
/*     */         }
/* 231 */         match = i;
/*     */       } 
/*     */     } 
/*     */     
/* 235 */     return match;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int findPartialMatch(String actualName, String[] formalNames, boolean[] matchedFormals) {
/* 245 */     int match = -1;
/* 246 */     for (int i = 0; i < formalNames.length; i++) {
/* 247 */       if (!matchedFormals[i]) {
/* 248 */         String formalName = formalNames[i];
/* 249 */         if (formalName.equals("...")) {
/*     */           break;
/*     */         }
/* 252 */         if (formalName.startsWith(actualName)) {
/* 253 */           if (match != -1) {
/* 254 */             throw new EvalException(String.format("Provided argument '%s' matches multiple named formal arguments", new Object[] { actualName }), new Object[0]);
/*     */           }
/*     */           
/* 257 */           match = i;
/*     */         } 
/*     */       } 
/*     */     } 
/* 261 */     return match;
/*     */   }
/*     */   
/*     */   public SEXP getDefaultValue(int formalIndex) {
/* 265 */     return this.defaultValues[formalIndex];
/*     */   }
/*     */   
/*     */   public List<String> getFormalNames() {
/* 269 */     return Arrays.asList(this.formalNames);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/eval/ArgumentMatcher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */