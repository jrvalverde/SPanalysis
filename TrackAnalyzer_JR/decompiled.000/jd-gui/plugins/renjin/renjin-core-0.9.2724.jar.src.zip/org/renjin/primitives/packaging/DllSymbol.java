/*     */ package org.renjin.primitives.packaging;
/*     */ 
/*     */ import java.lang.invoke.MethodHandle;
/*     */ import java.lang.invoke.MethodHandles;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Optional;
/*     */ import org.renjin.eval.EvalException;
/*     */ import org.renjin.sexp.AttributeMap;
/*     */ import org.renjin.sexp.ExternalPtr;
/*     */ import org.renjin.sexp.ListVector;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.StringArrayVector;
/*     */ import org.renjin.sexp.Symbols;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DllSymbol
/*     */ {
/*     */   private final String name;
/*     */   private final MethodHandle methodHandle;
/*     */   private final Optional<Convention> convention;
/*     */   private final boolean registered;
/*     */   
/*     */   public enum Convention
/*     */   {
/*  37 */     C("CRoutine"),
/*  38 */     CALL("CallRoutine"),
/*  39 */     FORTRAN("FortranRoutine"),
/*  40 */     EXTERNAL("ExternalRoutine");
/*     */     
/*     */     private String className;
/*     */     
/*     */     Convention(String className) {
/*  45 */       this.className = className;
/*     */     }
/*     */     
/*     */     public String getClassName() {
/*  49 */       return this.className;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DllSymbol(String name, MethodHandle methodHandle, Convention convention, boolean registered) {
/*  60 */     if (methodHandle == null) {
/*  61 */       throw new NullPointerException("Null method handle for symbol '" + name + "'");
/*     */     }
/*  63 */     this.name = name;
/*  64 */     this.methodHandle = methodHandle;
/*  65 */     this.convention = Optional.of(convention);
/*  66 */     this.registered = registered;
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public DllSymbol(String name, MethodHandle methodHandle, Convention convention) {
/*  71 */     this(name, methodHandle, convention, true);
/*     */   }
/*     */   
/*     */   public DllSymbol(Convention convention, Method method) {
/*  75 */     this(Optional.of(convention), method);
/*     */   }
/*     */   
/*     */   public DllSymbol(Optional<Convention> convention, Method method) {
/*  79 */     this.name = method.getName();
/*  80 */     this.registered = false;
/*  81 */     this.convention = convention;
/*     */     try {
/*  83 */       this.methodHandle = MethodHandles.publicLookup().unreflect(method);
/*  84 */     } catch (IllegalAccessException e) {
/*  85 */       throw new EvalException("Cannot access method '%s': %s", new Object[] { method.getName(), e.getMessage(), e });
/*     */     } 
/*  87 */     if (this.methodHandle == null) {
/*  88 */       throw new NullPointerException("unreflect() returned null for " + method);
/*     */     }
/*     */   }
/*     */   
/*     */   public String getName() {
/*  93 */     return this.name;
/*     */   }
/*     */   
/*     */   public MethodHandle getMethodHandle() {
/*  97 */     return this.methodHandle;
/*     */   }
/*     */   
/*     */   public Convention getConvention() {
/* 101 */     return this.convention.orElse(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ListVector buildNativeSymbolInfoSexp() {
/* 110 */     ListVector.NamedBuilder symbol = new ListVector.NamedBuilder();
/* 111 */     symbol.add("name", this.name);
/* 112 */     symbol.add("address", (SEXP)buildAddressSexp());
/* 113 */     symbol.add("numParameters", this.methodHandle.type().parameterCount());
/*     */     
/* 115 */     if (this.convention.isPresent()) {
/* 116 */       symbol.setAttribute(Symbols.CLASS, (SEXP)new StringArrayVector(new String[] { ((Convention)this.convention.get()).getClassName(), "NativeSymbolInfo" }));
/*     */     } else {
/* 118 */       symbol.setAttribute(Symbols.CLASS, (SEXP)new StringArrayVector(new String[] { "NativeSymbolInfo" }));
/*     */     } 
/*     */     
/* 121 */     return symbol.build();
/*     */   }
/*     */   
/*     */   private ExternalPtr<MethodHandle> buildAddressSexp() {
/* 125 */     AttributeMap.Builder attributes = AttributeMap.builder();
/* 126 */     if (this.registered) {
/* 127 */       attributes.setClass(new String[] { "RegisteredNativeSymbol" });
/*     */     } else {
/* 129 */       attributes.setClass(new String[] { "NativeSymbol" });
/*     */     } 
/* 131 */     return new ExternalPtr(this.methodHandle, attributes.build());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DllSymbol fromSexp(SEXP method) {
/* 138 */     ListVector list = (ListVector)method;
/* 139 */     String name = list.getElementAsString("name");
/* 140 */     ExternalPtr<MethodHandle> address = (ExternalPtr<MethodHandle>)list.get("address");
/* 141 */     Convention convention = conventionFromClass(method);
/* 142 */     boolean registered = address.inherits("RegisteredNativeSymbol");
/*     */     
/* 144 */     return new DllSymbol(name, (MethodHandle)address.getInstance(), convention, registered);
/*     */   }
/*     */   
/*     */   public static DllSymbol fromAddressSexp(SEXP method) {
/* 148 */     ExternalPtr<MethodHandle> address = (ExternalPtr<MethodHandle>)method;
/* 149 */     boolean registered = address.inherits("RegisteredNativeSymbol");
/*     */     
/* 151 */     return new DllSymbol("native", (MethodHandle)address.getInstance(), Convention.C, registered);
/*     */   }
/*     */   
/*     */   private static Convention conventionFromClass(SEXP method) {
/* 155 */     for (Convention convention : Convention.values()) {
/* 156 */       if (method.inherits(convention.getClassName())) {
/* 157 */         return convention;
/*     */       }
/*     */     } 
/* 160 */     return Convention.C;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/packaging/DllSymbol.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */