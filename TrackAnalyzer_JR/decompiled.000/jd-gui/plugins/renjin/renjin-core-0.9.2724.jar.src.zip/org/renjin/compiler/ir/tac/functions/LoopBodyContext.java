/*    */ package org.renjin.compiler.ir.tac.functions;
/*    */ 
/*    */ import org.renjin.compiler.ir.tac.RuntimeState;
/*    */ import org.renjin.sexp.PairList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LoopBodyContext
/*    */   implements TranslationContext
/*    */ {
/*    */   private RuntimeState runtimeState;
/*    */   
/*    */   public LoopBodyContext(RuntimeState runtimeState) {
/* 29 */     this.runtimeState = runtimeState;
/*    */   }
/*    */ 
/*    */   
/*    */   public PairList getEllipsesArguments() {
/* 34 */     return this.runtimeState.getEllipsesVariable();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/ir/tac/functions/LoopBodyContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */