/*    */ package org.renjin.eval.vfs;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.Collection;
/*    */ import java.util.Collections;
/*    */ import org.apache.commons.vfs2.Capability;
/*    */ import org.apache.commons.vfs2.FileName;
/*    */ import org.apache.commons.vfs2.FileObject;
/*    */ import org.apache.commons.vfs2.FileSystem;
/*    */ import org.apache.commons.vfs2.FileSystemException;
/*    */ import org.apache.commons.vfs2.FileSystemOptions;
/*    */ import org.apache.commons.vfs2.FileType;
/*    */ import org.apache.commons.vfs2.provider.AbstractLayeredFileProvider;
/*    */ import org.apache.commons.vfs2.provider.LayeredFileName;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FastJarFileProvider
/*    */   extends AbstractLayeredFileProvider
/*    */ {
/* 43 */   static final Collection<Capability> capabilities = Collections.unmodifiableCollection(Arrays.asList(new Capability[] { Capability.GET_LAST_MODIFIED, Capability.GET_TYPE, Capability.LIST_CHILDREN, Capability.READ_CONTENT, Capability.URI, Capability.COMPRESS, Capability.VIRTUAL }));
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected FileSystem doCreateFileSystem(String scheme, FileObject file, FileSystemOptions fileSystemOptions) throws FileSystemException {
/* 67 */     LayeredFileName layeredFileName = new LayeredFileName(scheme, file.getName(), "/", FileType.FOLDER);
/* 68 */     return new FastJarFileSystem((FileName)layeredFileName, file, fileSystemOptions);
/*    */   }
/*    */   
/*    */   public Collection<Capability> getCapabilities() {
/* 72 */     return capabilities;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/eval/vfs/FastJarFileProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */