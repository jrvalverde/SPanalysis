/*    */ package org.renjin.primitives.special;
/*    */ 
/*    */ import org.renjin.eval.Context;
/*    */ import org.renjin.eval.EvalException;
/*    */ import org.renjin.sexp.Closure;
/*    */ import org.renjin.sexp.Environment;
/*    */ import org.renjin.sexp.FunctionCall;
/*    */ import org.renjin.sexp.PairList;
/*    */ import org.renjin.sexp.SEXP;
/*    */ import org.renjin.sexp.SpecialFunction;
/*    */ import org.renjin.sexp.Symbols;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RecallFunction
/*    */   extends SpecialFunction
/*    */ {
/*    */   public RecallFunction() {
/* 28 */     super("Recall");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SEXP apply(Context context, Environment rho, FunctionCall call, PairList args) {
/* 35 */     Context originalContext = context.getParent();
/* 36 */     if (!(originalContext.getFunction() instanceof Closure)) {
/* 37 */       throw new EvalException("Recall() must be called from within a closure", new Object[0]);
/*    */     }
/*    */     
/* 40 */     Closure closure = (Closure)originalContext.getFunction();
/*    */     
/* 42 */     PairList newArguments = (PairList)rho.getVariable(context, Symbols.ELLIPSES);
/* 43 */     FunctionCall newCall = new FunctionCall(originalContext.getCall().getFunction(), newArguments);
/*    */     
/* 45 */     return closure.apply(originalContext, originalContext
/* 46 */         .getEnvironment(), newCall, newArguments);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/special/RecallFunction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */