/*     */ package org.renjin.invoke.codegen;
/*     */ 
/*     */ import java.util.Comparator;
/*     */ import org.apache.commons.math.complex.Complex;
/*     */ import org.renjin.invoke.codegen.scalars.ScalarTypes;
/*     */ import org.renjin.invoke.model.JvmMethod;
/*     */ import org.renjin.sexp.AtomicVector;
/*     */ import org.renjin.sexp.ComplexVector;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.StringVector;
/*     */ import org.renjin.sexp.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OverloadComparator
/*     */   implements Comparator<JvmMethod>
/*     */ {
/*     */   private static final int ATOMIC_VECTOR_GROUP = 100;
/*     */   private static final int VECTOR_GROUP = 150;
/*     */   private static final int SEXP_GROUP = 200;
/*     */   private static final int OTHER_OBJECT = 300;
/*     */   
/*     */   public int compare(JvmMethod o1, JvmMethod o2) {
/*  37 */     if (o1.getPositionalFormals().size() != o2.getPositionalFormals().size()) {
/*  38 */       return o1.getPositionalFormals().size() - o2.getPositionalFormals().size();
/*     */     }
/*  40 */     for (int i = 0; i != o1.getPositionalFormals().size(); i++) {
/*  41 */       Class c1 = ((JvmMethod.Argument)o1.getPositionalFormals().get(i)).getClazz();
/*  42 */       Class c2 = ((JvmMethod.Argument)o2.getPositionalFormals().get(i)).getClazz();
/*  43 */       int cmp = compareArguments(c1, c2);
/*  44 */       if (cmp != 0) {
/*  45 */         return cmp;
/*     */       }
/*     */     } 
/*  48 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private int compareArguments(Class c1, Class c2) {
/*  54 */     int g1 = group(c1);
/*  55 */     int g2 = group(c2);
/*     */     
/*     */     try {
/*  58 */       if (g1 != g2) {
/*  59 */         return g1 - g2;
/*     */       }
/*  61 */       return compareIntraGroup(g1, c1, c2);
/*     */     }
/*  63 */     catch (Exception e) {
/*  64 */       throw new RuntimeException("Exception while comparing " + c1 + " and " + c2, e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int group(Class<?> clazz) {
/*  74 */     if (clazz.isPrimitive() || clazz.equals(Complex.class) || clazz.equals(String.class) || AtomicVector.class
/*  75 */       .isAssignableFrom(clazz))
/*  76 */       return 100; 
/*  77 */     if (Vector.class.isAssignableFrom(clazz))
/*  78 */       return 150; 
/*  79 */     if (SEXP.class.isAssignableFrom(clazz)) {
/*  80 */       return 200;
/*     */     }
/*  82 */     return 300;
/*     */   }
/*     */ 
/*     */   
/*     */   private int compareIntraGroup(int group, Class c1, Class c2) {
/*  87 */     if (group == 100) {
/*  88 */       return compareVectors(c1, c2);
/*     */     }
/*  90 */     return compareClasses(c1, c2);
/*     */   }
/*     */ 
/*     */   
/*     */   private int compareClasses(Class<?> c1, Class<?> c2) {
/*  95 */     int a = c1.isAssignableFrom(c2) ? 1 : 0;
/*  96 */     int b = c2.isAssignableFrom(c1) ? 1 : 0;
/*  97 */     return a - b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int compareVectors(Class c1, Class c2) {
/* 104 */     int cmp = compareClasses(c1, c2);
/* 105 */     if (cmp == 0) {
/* 106 */       Vector.Type t1 = vectorType(c1);
/* 107 */       Vector.Type t2 = vectorType(c2);
/*     */       
/* 109 */       cmp = t1.compareTo(t2);
/*     */     } 
/* 111 */     return cmp;
/*     */   }
/*     */   
/*     */   private Vector.Type vectorType(Class clazz) {
/* 115 */     if (clazz.isPrimitive())
/* 116 */       return ScalarTypes.get(clazz).getVectorTypeInstance(); 
/* 117 */     if (clazz.equals(Complex.class))
/* 118 */       return ComplexVector.VECTOR_TYPE; 
/* 119 */     if (clazz.equals(String.class)) {
/* 120 */       return StringVector.VECTOR_TYPE;
/*     */     }
/*     */     try {
/* 123 */       return (Vector.Type)clazz.getField("VECTOR_TYPE").get(null);
/* 124 */     } catch (Exception e) {
/* 125 */       throw new RuntimeException("Could not get VECTOR_TYPE from " + clazz.getName(), e);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/codegen/OverloadComparator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */