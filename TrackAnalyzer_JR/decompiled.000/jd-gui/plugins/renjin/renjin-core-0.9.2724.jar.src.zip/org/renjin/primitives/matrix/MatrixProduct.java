/*     */ package org.renjin.primitives.matrix;
/*     */ 
/*     */ import com.github.fommil.netlib.BLAS;
/*     */ import org.renjin.eval.EvalException;
/*     */ import org.renjin.primitives.sequence.RepDoubleVector;
/*     */ import org.renjin.sexp.AtomicVector;
/*     */ import org.renjin.sexp.AttributeMap;
/*     */ import org.renjin.sexp.DoubleArrayVector;
/*     */ import org.renjin.sexp.ListVector;
/*     */ import org.renjin.sexp.Null;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MatrixProduct
/*     */ {
/*     */   public static final int PROD = 0;
/*     */   public static final int CROSSPROD = 1;
/*     */   public static final int TCROSSPROD = 2;
/*     */   private static final int ROWS = 0;
/*     */   private static final int COLS = 1;
/*     */   private int operation;
/*     */   private boolean symmetrical;
/*     */   private AtomicVector x;
/*     */   private AtomicVector y;
/*  42 */   private int nrx = 0;
/*  43 */   private int ncx = 0;
/*  44 */   private int nry = 0;
/*  45 */   private int ncy = 0;
/*     */   
/*     */   private int ldx;
/*     */   
/*     */   private int ldy;
/*     */   private Vector[] operands;
/*     */   
/*     */   public MatrixProduct(int operation, AtomicVector x, AtomicVector y) {
/*  53 */     this.x = x;
/*  54 */     this.y = y;
/*     */     
/*  56 */     this.symmetrical = (y == Null.INSTANCE);
/*  57 */     if (this.symmetrical && operation > 0) {
/*  58 */       this.y = x;
/*     */     }
/*     */     
/*  61 */     this.operation = operation;
/*     */     
/*  63 */     if (this.symmetrical) {
/*  64 */       this.operands = new Vector[] { (Vector)x };
/*     */     } else {
/*  66 */       this.operands = new Vector[] { (Vector)x, (Vector)y };
/*     */     } 
/*     */     
/*  69 */     computeMatrixDims();
/*     */   }
/*     */ 
/*     */   
/*     */   private void computeMatrixDims() {
/*  74 */     Vector xdims = this.x.getAttributes().getDim();
/*  75 */     Vector ydims = this.y.getAttributes().getDim();
/*  76 */     this.ldx = xdims.length();
/*  77 */     this.ldy = ydims.length();
/*     */     
/*  79 */     if (this.ldx != 2 && this.ldy != 2) {
/*     */ 
/*     */ 
/*     */       
/*  83 */       if (this.operation == 0) {
/*     */         
/*  85 */         this.nrx = 1;
/*  86 */         this.ncx = this.x.length();
/*     */       } else {
/*     */         
/*  89 */         this.nrx = this.x.length();
/*  90 */         this.ncx = 1;
/*     */       } 
/*     */       
/*  93 */       this.nry = this.y.length();
/*  94 */       this.ncy = 1;
/*     */     }
/*  96 */     else if (this.ldx != 2) {
/*     */ 
/*     */ 
/*     */       
/* 100 */       this.nry = ydims.getElementAsInt(0);
/* 101 */       this.ncy = ydims.getElementAsInt(1);
/* 102 */       this.nrx = 0;
/* 103 */       this.ncx = 0;
/*     */       
/* 105 */       switch (this.operation) {
/*     */         case 0:
/* 107 */           if (this.x.length() == this.nry) {
/*     */             
/* 109 */             this.nrx = 1;
/* 110 */             this.ncx = this.nry; break;
/*     */           } 
/* 112 */           if (this.nry == 1) {
/*     */             
/* 114 */             this.nrx = this.x.length();
/* 115 */             this.ncx = 1;
/*     */           } 
/*     */           break;
/*     */ 
/*     */         
/*     */         case 1:
/* 121 */           if (this.x.length() == this.nry) {
/*     */             
/* 123 */             this.nrx = this.nry;
/* 124 */             this.ncx = 1;
/*     */           } 
/*     */           break;
/*     */         
/*     */         case 2:
/* 129 */           if (this.x.length() == this.ncy) {
/*     */             
/* 131 */             this.nrx = 1;
/* 132 */             this.ncx = this.ncy; break;
/*     */           } 
/* 134 */           if (this.ncy == 1) {
/*     */             
/* 136 */             this.nrx = this.x.length();
/* 137 */             this.ncx = 1;
/*     */           } 
/*     */           break;
/*     */       } 
/* 141 */     } else if (this.ldy != 2) {
/*     */ 
/*     */ 
/*     */       
/* 145 */       this.nrx = xdims.getElementAsInt(0);
/* 146 */       this.ncx = xdims.getElementAsInt(1);
/* 147 */       this.nry = 0;
/* 148 */       this.ncy = 0;
/*     */       
/* 150 */       switch (this.operation) {
/*     */         case 0:
/* 152 */           if (this.y.length() == this.ncx) {
/*     */             
/* 154 */             this.nry = this.ncx;
/* 155 */             this.ncy = 1; break;
/*     */           } 
/* 157 */           if (this.ncx == 1) {
/*     */             
/* 159 */             this.nry = 1;
/* 160 */             this.ncy = this.y.length();
/*     */           } 
/*     */           break;
/*     */         
/*     */         case 1:
/* 165 */           if (this.y.length() == this.nrx) {
/*     */             
/* 167 */             this.nry = this.nrx;
/* 168 */             this.ncy = 1;
/*     */           } 
/*     */           break;
/*     */         
/*     */         case 2:
/* 173 */           this.nry = this.y.length();
/* 174 */           this.ncy = 1;
/*     */           break;
/*     */       } 
/*     */ 
/*     */ 
/*     */     
/*     */     } else {
/* 181 */       this.nrx = xdims.getElementAsInt(0);
/* 182 */       this.ncx = xdims.getElementAsInt(1);
/* 183 */       this.nry = ydims.getElementAsInt(0);
/* 184 */       this.ncy = ydims.getElementAsInt(1);
/*     */     } 
/*     */     
/* 187 */     if ((this.operation == 0 && this.ncx != this.nry) || (this.operation == 1 && this.nrx != this.nry) || (this.operation == 2 && this.ncx != this.ncy))
/*     */     {
/*     */       
/* 190 */       throw new EvalException("non-conformable arguments", new Object[0]);
/*     */     }
/*     */   }
/*     */   
/*     */   public String getName() {
/* 195 */     switch (this.operation)
/*     */     
/*     */     { default:
/* 198 */         return "%*%";
/*     */       case 1:
/* 200 */         return "crossprod";
/*     */       case 2:
/* 202 */         break; }  return "tcrossprod";
/*     */   }
/*     */ 
/*     */   
/*     */   public Vector[] getOperands() {
/* 207 */     return this.operands;
/*     */   }
/*     */   
/*     */   public boolean isNonZero() {
/* 211 */     return (this.nrx > 0 && this.ncx > 0 && this.nry > 0 && this.ncy > 0);
/*     */   }
/*     */   
/*     */   public int computeLength() {
/* 215 */     switch (this.operation)
/*     */     
/*     */     { default:
/* 218 */         return this.nrx * this.ncy;
/*     */       case 1:
/* 220 */         return this.ncx * this.ncy;
/*     */       case 2:
/* 222 */         break; }  return this.nrx * this.nry;
/*     */   }
/*     */ 
/*     */   
/*     */   public AttributeMap computeAttributes() {
/* 227 */     AttributeMap.Builder attributes = new AttributeMap.Builder();
/*     */     
/* 229 */     switch (this.operation) {
/*     */       case 0:
/* 231 */         attributes.setDim(this.nrx, this.ncy);
/* 232 */         attributes.setDimNames((SEXP)computeDimensionNames(0, 1));
/*     */         break;
/*     */       
/*     */       case 1:
/* 236 */         attributes.setDim(this.ncx, this.ncy);
/* 237 */         attributes.setDimNames((SEXP)computeDimensionNames(1, 1));
/*     */         break;
/*     */       
/*     */       case 2:
/* 241 */         attributes.setDim(this.nrx, this.nry);
/* 242 */         attributes.setDimNames((SEXP)computeDimensionNames(0, 0));
/*     */         break;
/*     */     } 
/* 245 */     return attributes.build();
/*     */   }
/*     */ 
/*     */   
/*     */   public Vector compute() {
/* 250 */     if (!isNonZero()) {
/* 251 */       return (Vector)RepDoubleVector.createConstantVector(0.0D, computeLength())
/* 252 */         .setAttributes(computeAttributes());
/*     */     }
/*     */     
/* 255 */     if (this.x.isDeferred() || this.y.isDeferred() || computeLength() > 500) {
/* 256 */       return (Vector)new DeferredMatrixProduct(this);
/*     */     }
/*     */     
/* 259 */     return (Vector)DoubleArrayVector.unsafe(computeResult(), computeAttributes());
/*     */   }
/*     */   
/*     */   private Vector computeDimensionNames(int rowNamesDim, int colNamesDim) {
/* 263 */     Vector xdims = this.x.getAttributes().getDimNames();
/* 264 */     Vector ydims = this.y.getAttributes().getDimNames();
/*     */     
/* 266 */     ListVector.NamedBuilder dimNames = new ListVector.NamedBuilder(2);
/* 267 */     dimNames.set(0, (SEXP)Null.INSTANCE);
/* 268 */     dimNames.set(1, (SEXP)Null.INSTANCE);
/*     */     
/* 270 */     boolean hasNames = false;
/*     */     
/* 272 */     if (xdims != Null.INSTANCE && 
/* 273 */       this.ldx == 2) {
/* 274 */       SEXP rowNames = xdims.getElementAsSEXP(rowNamesDim);
/* 275 */       if (rowNames != Null.INSTANCE) {
/* 276 */         hasNames = true;
/*     */       }
/* 278 */       if (rowNames != Null.INSTANCE || xdims.hasNames()) {
/* 279 */         dimNames.set(0, rowNames);
/* 280 */         dimNames.setName(0, xdims.getName(rowNamesDim));
/*     */       } 
/*     */     } 
/*     */     
/* 284 */     if (ydims != Null.INSTANCE && 
/* 285 */       this.ldy == 2) {
/* 286 */       SEXP rowNames = ydims.getElementAsSEXP(colNamesDim);
/* 287 */       if (rowNames != Null.INSTANCE) {
/* 288 */         hasNames = true;
/*     */       }
/* 290 */       if (rowNames != Null.INSTANCE || ydims.hasNames()) {
/* 291 */         dimNames.set(1, rowNames);
/* 292 */         dimNames.setName(1, ydims.getName(colNamesDim));
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 297 */     if (hasNames) {
/* 298 */       return (Vector)dimNames.build();
/*     */     }
/* 300 */     return (Vector)Null.INSTANCE;
/*     */   }
/*     */ 
/*     */   
/*     */   private double[] getXArray() {
/* 305 */     return this.x.toDoubleArray();
/*     */   }
/*     */   
/*     */   private double[] getYArray() {
/* 309 */     return this.y.toDoubleArray();
/*     */   }
/*     */   
/*     */   Vector computeResultVector(AttributeMap attributes) {
/* 313 */     return (Vector)DoubleArrayVector.unsafe(computeResult(), attributes);
/*     */   }
/*     */   
/*     */   double[] computeResult() {
/* 317 */     switch (this.operation) {
/*     */       case 1:
/* 319 */         if (this.symmetrical) {
/* 320 */           return computeSymmetricalCrossProduct();
/*     */         }
/* 322 */         return computeCrossProduct();
/*     */       
/*     */       case 2:
/* 325 */         if (this.symmetrical) {
/* 326 */           return computeTransposeSymmetricalCrossProduct();
/*     */         }
/* 328 */         return computeTransposeCrossProduct();
/*     */     } 
/*     */ 
/*     */     
/* 332 */     return computeMatrixProduct();
/*     */   }
/*     */ 
/*     */   
/*     */   private double[] computeMatrixProduct() {
/* 337 */     String transa = "N";
/* 338 */     String transb = "N";
/*     */     
/* 340 */     double one = 1.0D, zero = 0.0D;
/*     */     
/* 342 */     boolean haveNA = false;
/*     */     
/* 344 */     double[] x = getXArray();
/* 345 */     double[] y = getYArray();
/* 346 */     double[] z = new double[this.nrx * this.ncy];
/*     */     
/* 348 */     if (this.nrx > 0 && this.ncx > 0 && this.nry > 0 && this.ncy > 0) {
/*     */       int i;
/*     */ 
/*     */ 
/*     */       
/* 353 */       for (i = 0; i < this.nrx * this.ncx; i++) {
/* 354 */         if (Double.isNaN(x[i])) {
/* 355 */           haveNA = true;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/* 360 */       if (!haveNA) {
/* 361 */         for (i = 0; i < this.nry * this.ncy; i++) {
/* 362 */           if (Double.isNaN(y[i])) {
/* 363 */             haveNA = true;
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       }
/* 369 */       if (haveNA) {
/* 370 */         for (i = 0; i < this.nrx; i++) {
/* 371 */           for (int k = 0; k < this.ncy; k++) {
/* 372 */             double sum = 0.0D;
/* 373 */             for (int j = 0; j < this.ncx; j++) {
/* 374 */               sum += x[i + j * this.nrx] * y[j + k * this.nry];
/*     */             }
/* 376 */             z[i + k * this.nrx] = sum;
/*     */           } 
/*     */         } 
/*     */       } else {
/* 380 */         BLAS.getInstance().dgemm(transa, transb, this.nrx, this.ncy, this.ncx, one, x, this.nrx, y, this.nry, zero, z, this.nrx);
/*     */       } 
/*     */     } 
/*     */     
/* 384 */     return z;
/*     */   }
/*     */ 
/*     */   
/*     */   private double[] computeCrossProduct() {
/* 389 */     double[] x = getXArray();
/* 390 */     double[] y = getYArray();
/* 391 */     double[] z = new double[this.ncx * this.ncy];
/*     */     
/* 393 */     String transa = "T";
/* 394 */     String transb = "N";
/* 395 */     double one = 1.0D, zero = 0.0D;
/* 396 */     if (this.nrx > 0 && this.ncx > 0 && this.nry > 0 && this.ncy > 0) {
/* 397 */       BLAS.getInstance().dgemm(transa, transb, this.ncx, this.ncy, this.nrx, one, x, this.nrx, y, this.nry, zero, z, this.ncx);
/*     */     }
/*     */ 
/*     */     
/* 401 */     return z;
/*     */   }
/*     */   
/*     */   private double[] computeTransposeCrossProduct() {
/* 405 */     double[] x = getXArray();
/* 406 */     double[] y = getYArray();
/* 407 */     double[] z = new double[this.nrx * this.nry];
/*     */     
/* 409 */     String transa = "N";
/* 410 */     String transb = "T";
/* 411 */     double one = 1.0D, zero = 0.0D;
/* 412 */     if (this.nrx > 0 && this.ncx > 0 && this.nry > 0 && this.ncy > 0) {
/* 413 */       BLAS.getInstance().dgemm(transa, transb, this.nrx, this.nry, this.ncx, one, x, this.nrx, y, this.nry, zero, z, this.nrx);
/*     */     }
/*     */     
/* 416 */     return z;
/*     */   }
/*     */ 
/*     */   
/*     */   private double[] computeSymmetricalCrossProduct() {
/* 421 */     String trans = "T";
/* 422 */     String uplo = "U";
/* 423 */     double one = 1.0D, zero = 0.0D;
/*     */     
/* 425 */     double[] x = getXArray();
/* 426 */     double[] z = new double[this.ncx * this.ncy];
/*     */ 
/*     */     
/* 429 */     if (this.nrx > 0 && this.ncx > 0) {
/* 430 */       BLAS.getInstance().dsyrk(uplo, trans, this.ncx, this.nrx, one, x, this.nrx, zero, z, this.ncx);
/*     */       
/* 432 */       for (int i = 1; i < this.ncx; i++) {
/* 433 */         for (int j = 0; j < i; j++) {
/* 434 */           z[i + this.ncx * j] = z[j + this.ncx * i];
/*     */         }
/*     */       } 
/*     */     } 
/* 438 */     return z;
/*     */   }
/*     */ 
/*     */   
/*     */   private double[] computeTransposeSymmetricalCrossProduct() {
/* 443 */     double[] x = getXArray();
/* 444 */     double[] z = new double[this.nrx * this.nry];
/*     */     
/* 446 */     String trans = "N";
/* 447 */     String uplo = "U";
/* 448 */     double one = 1.0D, zero = 0.0D;
/*     */     
/* 450 */     if (this.nrx > 0 && this.ncx > 0) {
/* 451 */       BLAS.getInstance().dsyrk(uplo, trans, this.nrx, this.ncx, one, x, this.nrx, zero, z, this.nrx);
/* 452 */       for (int i = 1; i < this.nrx; i++) {
/* 453 */         for (int j = 0; j < i; j++) {
/* 454 */           z[i + this.nrx * j] = z[j + this.nrx * i];
/*     */         }
/*     */       } 
/*     */     } 
/* 458 */     return z;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/matrix/MatrixProduct.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */