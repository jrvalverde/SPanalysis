/*     */ package org.renjin.pipeliner.fusion.node;
/*     */ 
/*     */ import java.util.Optional;
/*     */ import org.renjin.pipeliner.ComputeMethod;
/*     */ import org.renjin.repackaged.asm.Label;
/*     */ import org.renjin.repackaged.asm.MethodVisitor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DistanceMatrixNode
/*     */   extends LoopNode
/*     */ {
/*     */   private LoopNode operandNode;
/*     */   private int indexTempLocal;
/*     */   private int rowTempLocal;
/*     */   private int colTempLocal;
/*     */   
/*     */   public DistanceMatrixNode(LoopNode operandNode) {
/*  36 */     this.operandNode = operandNode;
/*     */   }
/*     */ 
/*     */   
/*     */   public void init(ComputeMethod method) {
/*  41 */     this.operandNode.init(method);
/*  42 */     this.indexTempLocal = method.reserveLocal(1);
/*  43 */     this.rowTempLocal = method.reserveLocal(1);
/*  44 */     this.colTempLocal = method.reserveLocal(1);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void pushLength(ComputeMethod method) {
/*  50 */     this.operandNode.pushLength(method);
/*  51 */     MethodVisitor mv = method.getVisitor();
/*  52 */     mv.visitInsn(89);
/*  53 */     mv.visitInsn(104);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean mustCheckForIntegerNAs() {
/*  58 */     return this.operandNode.mustCheckForIntegerNAs();
/*     */   }
/*     */ 
/*     */   
/*     */   public void appendToKey(StringBuilder key) {
/*  63 */     key.append("DMN");
/*     */   }
/*     */ 
/*     */   
/*     */   public void pushElementAsDouble(ComputeMethod method, Optional<Label> integerNaLabel) {
/*  68 */     MethodVisitor mv = method.getVisitor();
/*     */     
/*  70 */     mv.visitInsn(89);
/*  71 */     mv.visitVarInsn(54, this.indexTempLocal);
/*     */ 
/*     */     
/*  74 */     this.operandNode.pushLength(method);
/*  75 */     mv.visitInsn(112);
/*     */     
/*  77 */     mv.visitVarInsn(54, this.rowTempLocal);
/*     */ 
/*     */     
/*  80 */     mv.visitVarInsn(21, this.indexTempLocal);
/*  81 */     this.operandNode.pushLength(method);
/*  82 */     mv.visitInsn(108);
/*  83 */     mv.visitVarInsn(54, this.colTempLocal);
/*     */ 
/*     */ 
/*     */     
/*  87 */     mv.visitVarInsn(21, this.rowTempLocal);
/*  88 */     this.operandNode.pushElementAsDouble(method, integerNaLabel);
/*     */ 
/*     */     
/*  91 */     mv.visitVarInsn(21, this.colTempLocal);
/*  92 */     this.operandNode.pushElementAsDouble(method, integerNaLabel);
/*     */ 
/*     */     
/*  95 */     mv.visitInsn(103);
/*  96 */     mv.visitMethodInsn(184, "java/lang/Math", "abs", "(D)D", false);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 101 */     return "dist(" + this.operandNode + ")";
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/pipeliner/fusion/node/DistanceMatrixNode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */