/*    */ package org.renjin.eval.vfs;
/*    */ 
/*    */ import java.io.InputStream;
/*    */ import org.apache.commons.vfs2.FileSystemException;
/*    */ import org.apache.commons.vfs2.FileType;
/*    */ import org.apache.commons.vfs2.provider.AbstractFileName;
/*    */ import org.apache.commons.vfs2.provider.AbstractFileObject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NonExistentJarFileObject
/*    */   extends AbstractFileObject
/*    */ {
/*    */   protected NonExistentJarFileObject(AbstractFileName name, FastJarFileSystem fs) {
/* 32 */     super(name, fs);
/*    */   }
/*    */ 
/*    */   
/*    */   protected FileType doGetType() throws Exception {
/* 37 */     return FileType.IMAGINARY;
/*    */   }
/*    */ 
/*    */   
/*    */   protected String[] doListChildren() throws Exception {
/* 42 */     throw new FileSystemException("File doesn't exist");
/*    */   }
/*    */ 
/*    */   
/*    */   protected long doGetContentSize() throws Exception {
/* 47 */     throw new FileSystemException("File doesn't exist");
/*    */   }
/*    */ 
/*    */   
/*    */   protected InputStream doGetInputStream() throws Exception {
/* 52 */     throw new FileSystemException("File doesn't exist");
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/eval/vfs/NonExistentJarFileObject.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */