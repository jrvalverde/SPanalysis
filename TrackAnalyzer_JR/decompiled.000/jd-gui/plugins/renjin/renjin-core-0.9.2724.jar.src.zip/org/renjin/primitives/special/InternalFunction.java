/*    */ package org.renjin.primitives.special;
/*    */ 
/*    */ import org.renjin.eval.Context;
/*    */ import org.renjin.eval.EvalException;
/*    */ import org.renjin.primitives.Primitives;
/*    */ import org.renjin.sexp.Environment;
/*    */ import org.renjin.sexp.Function;
/*    */ import org.renjin.sexp.FunctionCall;
/*    */ import org.renjin.sexp.Null;
/*    */ import org.renjin.sexp.PairList;
/*    */ import org.renjin.sexp.PrimitiveFunction;
/*    */ import org.renjin.sexp.SEXP;
/*    */ import org.renjin.sexp.SpecialFunction;
/*    */ import org.renjin.sexp.Symbol;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InternalFunction
/*    */   extends SpecialFunction
/*    */ {
/*    */   public InternalFunction() {
/* 29 */     super(".Internal");
/*    */   }
/*    */ 
/*    */   
/*    */   public SEXP apply(Context context, Environment rho, FunctionCall call, PairList args) {
/* 34 */     SEXP arg = call.getArgument(0);
/* 35 */     assert arg != null;
/* 36 */     if (!(arg instanceof FunctionCall)) {
/* 37 */       throw new EvalException("invalid .Internal() argument", new Object[0]);
/*    */     }
/* 39 */     FunctionCall internalCall = (FunctionCall)arg;
/* 40 */     Symbol internalName = (Symbol)internalCall.getFunction();
/* 41 */     PrimitiveFunction primitiveFunction = Primitives.getInternal(internalName);
/* 42 */     if (primitiveFunction == null || primitiveFunction == Null.INSTANCE) {
/* 43 */       throw new EvalException(String.format("no internal function \"%s\"", new Object[] { internalName.getPrintName() }), new Object[0]);
/*    */     }
/* 45 */     return ((Function)primitiveFunction).apply(context, rho, internalCall, internalCall.getArguments());
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/special/InternalFunction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */