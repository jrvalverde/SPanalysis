/*    */ package org.renjin.compiler.ir.tac.functions;
/*    */ 
/*    */ import org.renjin.compiler.ir.tac.IRBodyBuilder;
/*    */ import org.renjin.compiler.ir.tac.IRLabel;
/*    */ import org.renjin.compiler.ir.tac.expressions.Constant;
/*    */ import org.renjin.compiler.ir.tac.expressions.Expression;
/*    */ import org.renjin.compiler.ir.tac.statements.GotoStatement;
/*    */ import org.renjin.compiler.ir.tac.statements.IfStatement;
/*    */ import org.renjin.compiler.ir.tac.statements.Statement;
/*    */ import org.renjin.sexp.Function;
/*    */ import org.renjin.sexp.FunctionCall;
/*    */ import org.renjin.sexp.SEXP;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WhileTranslator
/*    */   extends FunctionCallTranslator
/*    */ {
/*    */   public Expression translateToExpression(IRBodyBuilder builder, TranslationContext context, Function resolvedFunction, FunctionCall call) {
/* 36 */     addLoop(builder, context, call);
/*    */     
/* 38 */     return (Expression)Constant.NULL;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void addStatement(IRBodyBuilder builder, TranslationContext context, Function resolvedFunction, FunctionCall call) {
/* 44 */     addLoop(builder, context, call);
/*    */   }
/*    */ 
/*    */   
/*    */   private void addLoop(IRBodyBuilder factory, TranslationContext context, FunctionCall call) {
/* 49 */     SEXP condition = call.getArgument(0);
/*    */     
/* 51 */     SEXP body = call.getArgument(1);
/*    */     
/* 53 */     IRLabel checkLabel = factory.newLabel();
/* 54 */     IRLabel bodyLabel = factory.newLabel();
/* 55 */     IRLabel exitLabel = factory.newLabel();
/*    */ 
/*    */     
/* 58 */     factory.addLabel(checkLabel);
/* 59 */     factory.addStatement((Statement)new IfStatement((Expression)factory
/* 60 */           .translateSimpleExpression(context, condition), bodyLabel, exitLabel));
/*    */ 
/*    */ 
/*    */     
/* 64 */     factory.addLabel(bodyLabel);
/*    */     
/* 66 */     LoopContext loopContext = new LoopContext(context, checkLabel, exitLabel);
/* 67 */     factory.translateStatements(loopContext, body);
/*    */ 
/*    */     
/* 70 */     factory.addStatement((Statement)new GotoStatement(checkLabel));
/*    */     
/* 72 */     factory.addLabel(exitLabel);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/ir/tac/functions/WhileTranslator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */