/*    */ package org.renjin.primitives.io.connections;
/*    */ 
/*    */ import org.renjin.repackaged.guava.base.Strings;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OpenSpec
/*    */ {
/*    */   private String spec;
/*    */   
/*    */   public OpenSpec(String spec) {
/* 49 */     this.spec = Strings.nullToEmpty(spec).toLowerCase();
/*    */   }
/*    */   
/*    */   public boolean forReading() {
/* 53 */     return (this.spec.startsWith("r") || this.spec.equals("w+b"));
/*    */   }
/*    */   
/*    */   public boolean forWriting() {
/* 57 */     return (this.spec.equals("r+") || this.spec.contains("w") || this.spec.contains("a"));
/*    */   }
/*    */   
/*    */   public boolean isAppend() {
/* 61 */     return this.spec.contains("a");
/*    */   }
/*    */   
/*    */   public boolean isText() {
/* 65 */     return !this.spec.contains("b");
/*    */   }
/*    */   
/*    */   public boolean isBinary() {
/* 69 */     return this.spec.contains("b");
/*    */   }
/*    */   
/*    */   public Connection.Type getType() {
/* 73 */     return isText() ? Connection.Type.TEXT : Connection.Type.BINARY;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 78 */     return this.spec;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/io/connections/OpenSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */