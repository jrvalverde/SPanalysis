/*     */ package org.renjin.invoke.reflection;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import org.renjin.eval.Context;
/*     */ import org.renjin.invoke.reflection.converters.Converter;
/*     */ import org.renjin.invoke.reflection.converters.Converters;
/*     */ import org.renjin.sexp.SEXP;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractOverload
/*     */ {
/*     */   private int nargs;
/*     */   private int baseArgCount;
/*     */   private boolean varArgs;
/*  43 */   private int firstArg = 0;
/*     */   
/*     */   private boolean context;
/*     */   
/*     */   private Converter[] argumentConverters;
/*     */   private Converter varArgConverter;
/*     */   private Converter varArgArrayConverter;
/*     */   private Class varArgElementClass;
/*     */   
/*     */   public AbstractOverload(Class[] parameterTypes, Annotation[][] annotations, boolean varArgs) {
/*  53 */     this.nargs = parameterTypes.length;
/*  54 */     this.varArgs = varArgs;
/*     */     
/*  56 */     if (varArgs) {
/*  57 */       this.baseArgCount = this.nargs - 1;
/*     */     } else {
/*  59 */       this.baseArgCount = this.nargs;
/*     */     } 
/*     */ 
/*     */     
/*  63 */     if (firstArgIsContext(annotations)) {
/*  64 */       this.firstArg = 1;
/*  65 */       this.baseArgCount--;
/*  66 */       this.context = true;
/*     */     } 
/*     */     
/*  69 */     this.argumentConverters = new Converter[this.baseArgCount];
/*  70 */     for (int i = 0; i != this.baseArgCount; i++) {
/*  71 */       this.argumentConverters[i] = Converters.get(parameterTypes[this.firstArg + i]);
/*     */     }
/*     */     
/*  74 */     if (varArgs) {
/*  75 */       this.varArgArrayConverter = Converters.get(parameterTypes[this.nargs - 1]);
/*  76 */       this.varArgElementClass = parameterTypes[this.nargs - 1].getComponentType();
/*  77 */       this.varArgConverter = Converters.get(this.varArgElementClass);
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean firstArgIsContext(Annotation[][] annotations) {
/*  82 */     if (annotations.length == 0) {
/*  83 */       return false;
/*     */     }
/*  85 */     for (int i = 0; i != (annotations[0]).length; i++) {
/*  86 */       if (annotations[0][i] instanceof org.renjin.invoke.annotations.Current) {
/*  87 */         return true;
/*     */       }
/*     */     } 
/*  90 */     return false;
/*     */   }
/*     */   
/*     */   protected final Object[] convertArguments(Context context, List<SEXP> args) {
/*  94 */     Object[] converted = new Object[this.nargs];
/*  95 */     if (this.context) {
/*  96 */       converted[0] = context;
/*     */     }
/*  98 */     for (int i = 0; i != this.baseArgCount; i++) {
/*  99 */       converted[i + this.firstArg] = this.argumentConverters[i].convertToJava(args.get(i));
/*     */     }
/* 101 */     if (this.varArgs) {
/* 102 */       int nVarArgs = args.size() - this.baseArgCount;
/* 103 */       if (nVarArgs == 1 && this.varArgArrayConverter.acceptsSEXP(args.get(this.baseArgCount))) {
/* 104 */         converted[this.nargs - 1] = this.varArgArrayConverter.convertToJava(args.get(this.baseArgCount));
/*     */       } else {
/* 106 */         Object extra = Array.newInstance(this.varArgElementClass, args.size() - this.baseArgCount);
/* 107 */         for (int j = 0; j + this.baseArgCount < args.size(); j++) {
/* 108 */           Array.set(extra, j, this.varArgConverter.convertToJava(args.get(j + this.baseArgCount)));
/*     */         }
/* 110 */         converted[this.nargs - 1] = extra;
/*     */       } 
/*     */     } 
/* 113 */     return converted;
/*     */   }
/*     */   
/*     */   public final int getArgCount() {
/* 117 */     return this.nargs;
/*     */   }
/*     */   
/*     */   public boolean isVarArgs() {
/* 121 */     return this.varArgs;
/*     */   }
/*     */   
/*     */   public boolean accept(List<SEXP> args) {
/* 125 */     if (args.size() < this.baseArgCount) {
/* 126 */       return false;
/*     */     }
/* 128 */     if (!this.varArgs && args.size() > this.baseArgCount)
/* 129 */       return false; 
/*     */     int i;
/* 131 */     for (i = 0; i != this.baseArgCount; i++) {
/* 132 */       if (!this.argumentConverters[i].acceptsSEXP(args.get(i))) {
/* 133 */         return false;
/*     */       }
/*     */     } 
/* 136 */     for (i = this.baseArgCount; i < args.size(); i++) {
/* 137 */       if (!this.varArgConverter.acceptsSEXP(args.get(i))) {
/* 138 */         return false;
/*     */       }
/*     */     } 
/* 141 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void sortOverloads(List<? extends AbstractOverload> overloads) {
/* 149 */     Collections.sort(overloads, new Comparator<AbstractOverload>()
/*     */         {
/*     */           public int compare(AbstractOverload o1, AbstractOverload o2)
/*     */           {
/* 153 */             if (o1.baseArgCount != o2.baseArgCount) {
/* 154 */               return o1.baseArgCount - o2.baseArgCount;
/*     */             }
/* 156 */             for (int i = 0; i != o1.baseArgCount; i++) {
/*     */               
/* 158 */               int cmp = o1.argumentConverters[i].getSpecificity() - o2.argumentConverters[i].getSpecificity();
/* 159 */               if (cmp != 0) {
/* 160 */                 return cmp;
/*     */               }
/*     */             } 
/* 163 */             if (!o1.varArgs && !o2.varArgs) {
/* 164 */               return 0;
/*     */             }
/* 166 */             if (o1.varArgs && !o2.varArgs) {
/* 167 */               return 1;
/*     */             }
/* 169 */             if (!o1.varArgs && o2.varArgs) {
/* 170 */               return -1;
/*     */             }
/*     */             
/* 173 */             return o1.varArgConverter.getSpecificity() - o2
/* 174 */               .varArgConverter.getSpecificity();
/*     */           }
/*     */         });
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/reflection/AbstractOverload.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */