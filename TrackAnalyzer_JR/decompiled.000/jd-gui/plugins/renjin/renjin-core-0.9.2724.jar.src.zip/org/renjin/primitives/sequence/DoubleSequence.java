/*    */ package org.renjin.primitives.sequence;
/*    */ 
/*    */ import org.renjin.sexp.AtomicVector;
/*    */ import org.renjin.sexp.AttributeMap;
/*    */ import org.renjin.sexp.DoubleArrayVector;
/*    */ import org.renjin.sexp.DoubleVector;
/*    */ import org.renjin.sexp.SEXP;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DoubleSequence
/*    */   extends DoubleVector
/*    */ {
/*    */   private double from;
/*    */   private double by;
/*    */   private int length;
/*    */   
/*    */   public DoubleSequence(AttributeMap attributes, double from, double by, int length) {
/* 33 */     super(attributes);
/* 34 */     this.from = from;
/* 35 */     this.by = by;
/* 36 */     this.length = length;
/*    */   }
/*    */   
/*    */   public DoubleSequence(double from, double by, int length) {
/* 40 */     this.from = from;
/* 41 */     this.by = by;
/* 42 */     this.length = length;
/*    */   }
/*    */ 
/*    */   
/*    */   public double getElementAsDouble(int index) {
/* 47 */     return this.from + index * this.by;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isConstantAccessTime() {
/* 52 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public int length() {
/* 57 */     return this.length;
/*    */   }
/*    */ 
/*    */   
/*    */   protected SEXP cloneWithNewAttributes(AttributeMap attributes) {
/* 62 */     return (SEXP)new DoubleSequence(attributes, this.from, this.by, this.length);
/*    */   }
/*    */   
/*    */   public static AtomicVector fromTo(double n1, double n2) {
/* 66 */     if (n1 == n2)
/* 67 */       return (AtomicVector)new DoubleArrayVector(new double[] { n1 }); 
/* 68 */     if (n1 <= n2) {
/* 69 */       return (AtomicVector)new DoubleSequence(n1, 1.0D, (int)Math.ceil(n2 - n1));
/*    */     }
/* 71 */     return (AtomicVector)new DoubleSequence(n1, -1.0D, (int)(Math.floor(n1 - n2) + 1.0D));
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/sequence/DoubleSequence.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */