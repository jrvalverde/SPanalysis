/*     */ package org.renjin.compiler.ir.tac.functions;
/*     */ 
/*     */ import org.renjin.compiler.ir.tac.IRBodyBuilder;
/*     */ import org.renjin.compiler.ir.tac.IRLabel;
/*     */ import org.renjin.compiler.ir.tac.expressions.Constant;
/*     */ import org.renjin.compiler.ir.tac.expressions.Expression;
/*     */ import org.renjin.compiler.ir.tac.expressions.LValue;
/*     */ import org.renjin.compiler.ir.tac.expressions.SimpleExpression;
/*     */ import org.renjin.compiler.ir.tac.expressions.Temp;
/*     */ import org.renjin.compiler.ir.tac.statements.Assignment;
/*     */ import org.renjin.compiler.ir.tac.statements.ExprStatement;
/*     */ import org.renjin.compiler.ir.tac.statements.GotoStatement;
/*     */ import org.renjin.compiler.ir.tac.statements.IfStatement;
/*     */ import org.renjin.compiler.ir.tac.statements.Statement;
/*     */ import org.renjin.sexp.Function;
/*     */ import org.renjin.sexp.FunctionCall;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OrTranslator
/*     */   extends FunctionCallTranslator
/*     */ {
/*     */   public Expression translateToExpression(IRBodyBuilder builder, TranslationContext context, Function resolvedFunction, FunctionCall call) {
/*  42 */     Temp result = builder.newTemp();
/*  43 */     IRLabel firstFalse = builder.newLabel();
/*  44 */     IRLabel firstNA = builder.newLabel();
/*     */     
/*  46 */     IRLabel test2Label = builder.newLabel();
/*     */     
/*  48 */     IRLabel trueLabel = builder.newLabel();
/*  49 */     IRLabel naLabel = builder.newLabel();
/*  50 */     IRLabel finishLabel = builder.newLabel();
/*     */ 
/*     */     
/*  53 */     SimpleExpression condition1 = builder.translateSimpleExpression(context, call.getArgument(0));
/*  54 */     builder.addStatement((Statement)new IfStatement((Expression)condition1, trueLabel, firstFalse, firstNA));
/*     */ 
/*     */ 
/*     */     
/*  58 */     builder.addLabel(firstFalse);
/*  59 */     builder.addStatement((Statement)new Assignment((LValue)result, (Expression)Constant.FALSE));
/*  60 */     builder.addStatement((Statement)new GotoStatement(test2Label));
/*     */ 
/*     */ 
/*     */     
/*  64 */     builder.addLabel(firstNA);
/*  65 */     builder.addStatement((Statement)new Assignment((LValue)result, (Expression)Constant.NA));
/*  66 */     builder.addStatement((Statement)new GotoStatement(test2Label));
/*     */ 
/*     */     
/*  69 */     builder.addLabel(test2Label);
/*  70 */     SimpleExpression condition2 = builder.translateSimpleExpression(context, call.getArgument(1));
/*  71 */     builder.addStatement((Statement)new IfStatement((Expression)condition2, trueLabel, finishLabel, naLabel));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  76 */     builder.addLabel(trueLabel);
/*  77 */     builder.addStatement((Statement)new Assignment((LValue)result, (Expression)Constant.TRUE));
/*  78 */     builder.addStatement((Statement)new GotoStatement(finishLabel));
/*     */     
/*  80 */     builder.addLabel(naLabel);
/*  81 */     builder.addStatement((Statement)new Assignment((LValue)result, (Expression)Constant.NA));
/*     */     
/*  83 */     builder.addLabel(finishLabel);
/*     */     
/*  85 */     return (Expression)result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addStatement(IRBodyBuilder builder, TranslationContext context, Function resolvedFunction, FunctionCall call) {
/*  92 */     IRLabel test2Label = builder.newLabel();
/*  93 */     IRLabel finishLabel = builder.newLabel();
/*     */ 
/*     */     
/*  96 */     SimpleExpression condition1 = builder.translateSimpleExpression(context, call.getArgument(0));
/*  97 */     builder.addStatement((Statement)new IfStatement((Expression)condition1, finishLabel, test2Label, test2Label));
/*     */ 
/*     */     
/* 100 */     builder.addLabel(test2Label);
/* 101 */     builder.addStatement((Statement)new ExprStatement(builder.translateExpression(context, call.getArgument(1))));
/*     */     
/* 103 */     builder.addLabel(finishLabel);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/ir/tac/functions/OrTranslator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */