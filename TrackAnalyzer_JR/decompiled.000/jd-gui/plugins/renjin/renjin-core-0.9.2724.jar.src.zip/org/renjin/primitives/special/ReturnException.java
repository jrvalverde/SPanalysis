/*    */ package org.renjin.primitives.special;
/*    */ 
/*    */ import org.renjin.sexp.Environment;
/*    */ import org.renjin.sexp.SEXP;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReturnException
/*    */   extends ControlFlowException
/*    */ {
/*    */   private final Environment environment;
/*    */   private final SEXP value;
/*    */   
/*    */   public ReturnException(Environment environment, SEXP value) {
/* 31 */     this.environment = environment;
/* 32 */     this.value = value;
/*    */   }
/*    */   
/*    */   public SEXP getValue() {
/* 36 */     return this.value;
/*    */   }
/*    */   
/*    */   public Environment getEnvironment() {
/* 40 */     return this.environment;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/special/ReturnException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */