/*     */ package org.renjin.primitives.subset;
/*     */ 
/*     */ import org.renjin.sexp.IntVector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ArrayIndexIterator
/*     */   implements IndexIterator
/*     */ {
/*     */   private static final int STATE_BEGIN = 0;
/*     */   private static final int STATE_RUNNING = 1;
/*     */   private static final int STATE_END = 2;
/*     */   private final int numDim;
/*     */   private IndexIterator[] iterators;
/*     */   private int[] increments;
/*     */   private int[] offsetStack;
/*  44 */   private int state = 0;
/*     */   
/*     */   public ArrayIndexIterator(int[] dim, Subscript[] subscripts) {
/*  47 */     this.numDim = subscripts.length;
/*     */ 
/*     */ 
/*     */     
/*  51 */     this.iterators = new IndexIterator[subscripts.length];
/*  52 */     for (int i = 0; i < this.numDim; i++) {
/*  53 */       this.iterators[i] = subscripts[i].computeIndexes();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  59 */     this.increments = new int[this.numDim];
/*  60 */     this.increments[0] = 1;
/*  61 */     for (int d = 1; d < this.numDim; d++) {
/*  62 */       this.increments[d] = this.increments[d - 1] * dim[d - 1];
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  68 */     this.offsetStack = new int[this.numDim + 1];
/*     */   }
/*     */ 
/*     */   
/*     */   public int next() {
/*  73 */     if (this.state == 2) {
/*  74 */       return -1;
/*     */     }
/*     */     
/*  77 */     if (this.state == 0) {
/*     */       
/*  79 */       int firstIndex = 0;
/*  80 */       for (int i = this.numDim - 1; i >= 0; i--) {
/*  81 */         int index = this.iterators[i].next();
/*     */ 
/*     */ 
/*     */         
/*  85 */         if (index == -1) {
/*  86 */           this.state = 2;
/*  87 */           return -1;
/*     */         } 
/*  89 */         if (IntVector.isNA(index)) {
/*  90 */           firstIndex = Integer.MIN_VALUE;
/*  91 */         } else if (!IntVector.isNA(firstIndex)) {
/*  92 */           firstIndex += index * this.increments[i];
/*     */         } 
/*  94 */         this.offsetStack[i] = firstIndex;
/*     */       } 
/*  96 */       this.state = 1;
/*  97 */       return firstIndex;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 102 */     int d = 0;
/*     */     while (true) {
/* 104 */       int nextIndex = this.iterators[d].next();
/* 105 */       if (nextIndex != -1) {
/* 106 */         updateOffset(d, nextIndex);
/*     */         break;
/*     */       } 
/* 109 */       this.iterators[d].restart();
/* 110 */       d++;
/* 111 */       if (d >= this.numDim) {
/* 112 */         this.state = 2;
/* 113 */         return -1;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 119 */     while (d > 0) {
/* 120 */       d--;
/* 121 */       int nextIndex = this.iterators[d].next();
/* 122 */       updateOffset(d, nextIndex);
/*     */     } 
/*     */     
/* 125 */     return this.offsetStack[0];
/*     */   }
/*     */   
/*     */   private void updateOffset(int dimensionIndex, int nextIndex) {
/* 129 */     int offset = this.offsetStack[dimensionIndex + 1];
/* 130 */     if (IntVector.isNA(offset) || IntVector.isNA(nextIndex)) {
/* 131 */       this.offsetStack[dimensionIndex] = Integer.MIN_VALUE;
/*     */     } else {
/* 133 */       this.offsetStack[dimensionIndex] = offset + nextIndex * this.increments[dimensionIndex];
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void restart() {
/* 139 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/subset/ArrayIndexIterator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */