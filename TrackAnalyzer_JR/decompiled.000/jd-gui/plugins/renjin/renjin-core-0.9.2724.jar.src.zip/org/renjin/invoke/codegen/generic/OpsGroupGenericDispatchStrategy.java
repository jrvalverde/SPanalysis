/*    */ package org.renjin.invoke.codegen.generic;
/*    */ 
/*    */ import com.sun.codemodel.JBlock;
/*    */ import com.sun.codemodel.JCodeModel;
/*    */ import com.sun.codemodel.JExpr;
/*    */ import com.sun.codemodel.JExpression;
/*    */ import com.sun.codemodel.JInvocation;
/*    */ import com.sun.codemodel.JType;
/*    */ import com.sun.codemodel.JVar;
/*    */ import java.util.List;
/*    */ import org.renjin.invoke.codegen.ApplyMethodContext;
/*    */ import org.renjin.primitives.S3;
/*    */ import org.renjin.sexp.SEXP;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OpsGroupGenericDispatchStrategy
/*    */   extends GenericDispatchStrategy
/*    */ {
/*    */   private final String name;
/*    */   
/*    */   public OpsGroupGenericDispatchStrategy(JCodeModel codeModel, String name) {
/* 37 */     super(codeModel);
/* 38 */     this.name = name;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void beforeTypeMatching(ApplyMethodContext context, JExpression functionCall, List<JExpression> arguments, JBlock parent) {
/* 52 */     JInvocation dispatchInvocation = this.codeModel.ref(S3.class).staticInvoke("tryDispatchOpsFromPrimitive").arg(context.getContext()).arg(context.getEnvironment()).arg(functionCall).arg(JExpr.lit(this.name));
/*    */     
/* 54 */     for (JExpression arg : arguments) {
/* 55 */       dispatchInvocation.arg(arg);
/*    */     }
/*    */     
/* 58 */     JBlock ifObjects = parent._if(anyObjects(arguments))._then();
/* 59 */     JVar dispatchResult = ifObjects.decl((JType)this.codeModel.ref(SEXP.class), "genericResult", (JExpression)dispatchInvocation);
/* 60 */     ifObjects._if(dispatchResult.ne(JExpr._null()))._then()._return((JExpression)dispatchResult);
/*    */   }
/*    */   
/*    */   private JExpression anyObjects(List<JExpression> arguments) {
/* 64 */     if (arguments.size() == 1)
/* 65 */       return (JExpression)fastIsObject(arguments.get(0)); 
/* 66 */     if (arguments.size() == 2) {
/* 67 */       return fastIsObject(arguments.get(0)).cor((JExpression)fastIsObject(arguments.get(1)));
/*    */     }
/* 69 */     throw new UnsupportedOperationException("n arguments = " + arguments.size());
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/codegen/generic/OpsGroupGenericDispatchStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */