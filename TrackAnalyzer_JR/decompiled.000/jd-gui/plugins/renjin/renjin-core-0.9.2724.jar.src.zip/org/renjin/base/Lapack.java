/*     */ package org.renjin.base;
/*     */ 
/*     */ import com.github.fommil.netlib.BLAS;
/*     */ import com.github.fommil.netlib.LAPACK;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.apache.commons.math.complex.Complex;
/*     */ import org.netlib.util.doubleW;
/*     */ import org.netlib.util.intW;
/*     */ import org.renjin.eval.Context;
/*     */ import org.renjin.eval.EvalException;
/*     */ import org.renjin.gcc.runtime.BytePtr;
/*     */ import org.renjin.gcc.runtime.DoublePtr;
/*     */ import org.renjin.gcc.runtime.IntPtr;
/*     */ import org.renjin.gcc.runtime.Ptr;
/*     */ import org.renjin.invoke.annotations.Current;
/*     */ import org.renjin.invoke.annotations.Internal;
/*     */ import org.renjin.primitives.ComplexGroup;
/*     */ import org.renjin.primitives.Types;
/*     */ import org.renjin.repackaged.guava.base.Strings;
/*     */ import org.renjin.sexp.AtomicVector;
/*     */ import org.renjin.sexp.AttributeMap;
/*     */ import org.renjin.sexp.ComplexArrayVector;
/*     */ import org.renjin.sexp.ComplexVector;
/*     */ import org.renjin.sexp.DoubleArrayVector;
/*     */ import org.renjin.sexp.DoubleVector;
/*     */ import org.renjin.sexp.IntArrayVector;
/*     */ import org.renjin.sexp.IntVector;
/*     */ import org.renjin.sexp.ListVector;
/*     */ import org.renjin.sexp.Null;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.StringVector;
/*     */ import org.renjin.sexp.Symbols;
/*     */ import org.renjin.sexp.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Lapack
/*     */ {
/*  50 */   public static final BytePtr UPPER_TRIANGLE = BytePtr.asciiString("U");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Internal
/*     */   public static DoubleVector La_chol2inv(DoubleVector a, int sz) {
/*  63 */     if (IntVector.isNA(sz) || sz < 1) {
/*  64 */       throw new EvalException("'size' argument must be a positive integer", new Object[0]);
/*     */     }
/*     */     
/*  67 */     int m = 1, n = 1;
/*     */     
/*  69 */     if (sz == 1 && !Types.isMatrix((SEXP)a))
/*     */     {
/*  71 */       return a;
/*     */     }
/*  73 */     if (Types.isMatrix((SEXP)a)) {
/*  74 */       Vector adims = a.getAttributes().getDim();
/*  75 */       m = adims.getElementAsInt(0);
/*  76 */       n = adims.getElementAsInt(1);
/*     */     } else {
/*  78 */       throw new EvalException("'a' must be a numeric matrix", new Object[0]);
/*     */     } 
/*     */     
/*  81 */     if (sz > n) {
/*  82 */       throw new EvalException("'size' cannot exceed ncol(x) = %d", new Object[] { Integer.valueOf(n) });
/*     */     }
/*  84 */     if (sz > m) {
/*  85 */       throw new EvalException("'size' cannot exceed nrow(x) = %d", new Object[] { Integer.valueOf(m) });
/*     */     }
/*     */     
/*  88 */     double[] result = new double[sz * sz];
/*  89 */     for (int j = 0; j < sz; j++) {
/*  90 */       for (int k = 0; k <= j; k++) {
/*  91 */         result[k + j * sz] = a.getElementAsDouble(k + j * m);
/*     */       }
/*     */     } 
/*     */     
/*  95 */     intW resultCode = new intW(0);
/*  96 */     LAPACK.getInstance().dpotri("Upper", sz, result, sz, resultCode);
/*     */     
/*  98 */     if (resultCode.val != 0) {
/*  99 */       if (resultCode.val > 0)
/* 100 */         throw new EvalException("element (%d, %d) is zero, so the inverse cannot be computed", new Object[] {
/* 101 */               Integer.valueOf(resultCode.val), Integer.valueOf(resultCode.val)
/*     */             }); 
/* 103 */       throw new EvalException("argument %d of Lapack routine %s had invalid value", new Object[] { Integer.valueOf(-resultCode.val), "dpotri" });
/*     */     } 
/*     */ 
/*     */     
/* 107 */     for (int i = 0; i < sz; i++) {
/* 108 */       for (int k = i + 1; k < sz; k++) {
/* 109 */         result[k + i * sz] = result[i + k * sz];
/*     */       }
/*     */     } 
/*     */     
/* 113 */     return (DoubleVector)DoubleArrayVector.unsafe(result, AttributeMap.builder().setDim(sz, sz));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ListVector svd(String jobu, String jobv, DoubleVector x, DoubleVector sexp, DoubleVector uexp, DoubleVector vexp, String method) {
/* 124 */     Vector xdims = x.getAttributes().getDim();
/* 125 */     int n = xdims.getElementAsInt(0);
/* 126 */     int p = xdims.getElementAsInt(1);
/*     */     
/* 128 */     double[] xvals = x.toDoubleArray();
/*     */     
/* 130 */     int ldu = uexp.getAttributes().getDim().getElementAsInt(0);
/* 131 */     int ldvt = vexp.getAttributes().getDim().getElementAsInt(0);
/*     */     
/* 133 */     double[] s = sexp.toDoubleArray();
/* 134 */     double[] u = uexp.toDoubleArray();
/* 135 */     double[] v = vexp.toDoubleArray();
/* 136 */     double[] tmp = new double[1];
/*     */     
/* 138 */     int[] iwork = new int[8 * ((n < p) ? n : p)];
/*     */     
/* 140 */     LAPACK lapack = LAPACK.getInstance();
/*     */ 
/*     */     
/* 143 */     int lwork = -1;
/* 144 */     intW info = new intW(0);
/* 145 */     lapack.dgesdd(jobu, n, p, xvals, n, s, u, ldu, v, ldvt, tmp, lwork, iwork, info);
/*     */     
/* 147 */     if (info.val != 0) {
/* 148 */       throw new EvalException("error code %d from Lapack routine '%s'", new Object[] { Integer.valueOf(info.val), "dgesdd" });
/*     */     }
/*     */     
/* 151 */     lwork = (int)tmp[0];
/* 152 */     double[] work = new double[lwork];
/*     */     
/* 154 */     lapack.dgesdd(jobu, n, p, xvals, n, s, u, ldu, v, ldvt, work, lwork, iwork, info);
/*     */     
/* 156 */     return ListVector.newNamedBuilder()
/* 157 */       .add("d", (SEXP)DoubleArrayVector.unsafe(s, sexp.getAttributes()))
/* 158 */       .add("u", (SEXP)DoubleArrayVector.unsafe(u, uexp.getAttributes()))
/* 159 */       .add("vt", (SEXP)DoubleArrayVector.unsafe(v, vexp.getAttributes()))
/* 160 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SEXP dgesv(DoubleVector A, DoubleVector B, double tolerance) {
/* 177 */     doubleW rcond = new doubleW(0.0D);
/*     */     
/* 179 */     if (!Types.isMatrix((SEXP)A)) {
/* 180 */       throw new EvalException("'a' must be a numeric matrix", new Object[0]);
/*     */     }
/* 182 */     if (!Types.isMatrix((SEXP)B)) {
/* 183 */       throw new EvalException("'b' must be a numeric matrix", new Object[0]);
/*     */     }
/*     */     
/* 186 */     Vector Adims = A.getAttributes().getDim();
/* 187 */     Vector Bdims = B.getAttributes().getDim();
/*     */     
/* 189 */     int n = Adims.getElementAsInt(0);
/* 190 */     if (n == 0) {
/* 191 */       throw new EvalException("'a' is 0-diml", new Object[0]);
/*     */     }
/* 193 */     int p = Bdims.getElementAsInt(1);
/* 194 */     if (p == 0) {
/* 195 */       throw new EvalException("no right-hand side in 'b'", new Object[0]);
/*     */     }
/* 197 */     if (Adims.getElementAsInt(1) != n) {
/* 198 */       throw new EvalException("'a' (" + n + " x " + Adims.getElementAsInt(1) + ") must be square", new Object[0]);
/*     */     }
/* 200 */     if (Bdims.getElementAsInt(0) != n) {
/* 201 */       throw new EvalException("'b' (" + Bdims.getElementAsInt(0) + " x " + p + ") must be compatible with 'a' (" + n + " x " + n + ")", new Object[0]);
/*     */     }
/*     */     
/* 204 */     int[] ipiv = new int[n];
/* 205 */     double[] avals = A.toDoubleArray();
/*     */     
/* 207 */     LAPACK lapack = LAPACK.getInstance();
/* 208 */     intW info = new intW(0);
/*     */     
/* 210 */     double[] result = B.toDoubleArray();
/*     */     
/* 212 */     lapack.dgesv(n, p, avals, n, ipiv, result, n, info);
/*     */     
/* 214 */     if (info.val < 0) {
/* 215 */       throw new EvalException("argument -" + info.val + " of Lapack routine 'dgsv' had invalid value", new Object[0]);
/*     */     }
/* 217 */     if (info.val > 0) {
/* 218 */       throw new EvalException("Lapack routine dgesv: system is exactly singular", new Object[0]);
/*     */     }
/*     */     
/* 221 */     double anorm = lapack.dlange("1", n, n, A.toDoubleArray(), n, null);
/*     */     
/* 223 */     double[] arrWork = new double[4 * n];
/* 224 */     lapack.dgecon("1", n, avals, n, anorm, rcond, arrWork, ipiv, info);
/*     */     
/* 226 */     if (rcond.val < tolerance) {
/* 227 */       throw new EvalException("system is computationally singular: reciprocal condition number = " + rcond.val, new Object[0]);
/*     */     }
/* 229 */     return (SEXP)DoubleArrayVector.unsafe(result, B.getAttributes());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SEXP rs(DoubleVector x, boolean ov) {
/* 246 */     double vl = 0.0D, vu = 0.0D, abstol = 0.0D;
/*     */ 
/*     */ 
/*     */     
/* 250 */     int il = 0, iu = 0;
/*     */     
/* 252 */     String uplo = "L";
/* 253 */     int n = getSquareMatrixSize((SEXP)x);
/*     */     
/* 255 */     double[] rx = x.toDoubleArray();
/* 256 */     double[] rvalues = new double[n];
/*     */     
/* 258 */     String range = "A";
/* 259 */     double[] rz = null;
/* 260 */     if (!ov) {
/* 261 */       rz = new double[n * n];
/*     */     }
/*     */     
/* 264 */     String jobv = ov ? "N" : "V";
/*     */ 
/*     */     
/* 267 */     int[] isuppz = new int[2 * n];
/*     */ 
/*     */     
/* 270 */     int lwork = -1;
/* 271 */     int liwork = -1;
/* 272 */     intW m = new intW(0);
/* 273 */     int[] itmp = new int[1];
/*     */     
/* 275 */     double[] tmp = new double[1];
/*     */     
/* 277 */     LAPACK lapack = LAPACK.getInstance();
/* 278 */     intW info = new intW(0);
/* 279 */     lapack.dsyevr(jobv, range, uplo, n, rx, n, vl, vu, il, iu, abstol, m, rvalues, rz, n, isuppz, tmp, lwork, itmp, liwork, info);
/*     */ 
/*     */ 
/*     */     
/* 283 */     if (info.val != 0) {
/* 284 */       throw new EvalException("error code %d from Lapack routine '%s'", new Object[] { Integer.valueOf(info.val), "dsyevr" });
/*     */     }
/*     */     
/* 287 */     lwork = (int)tmp[0];
/* 288 */     liwork = itmp[0];
/*     */     
/* 290 */     double[] work = new double[lwork];
/* 291 */     int[] iwork = new int[liwork];
/*     */     
/* 293 */     lapack.dsyevr(jobv, range, uplo, n, rx, n, vl, vu, il, iu, abstol, m, rvalues, rz, n, isuppz, work, lwork, iwork, liwork, info);
/*     */ 
/*     */ 
/*     */     
/* 297 */     if (info.val != 0) {
/* 298 */       throw new EvalException("error code %d from Lapack routine '%s'", new Object[] { Integer.valueOf(info.val), "dsyevr" });
/*     */     }
/*     */     
/* 301 */     ListVector.NamedBuilder ret = ListVector.newNamedBuilder();
/* 302 */     ret.add("values", (SEXP)new DoubleArrayVector(rvalues));
/* 303 */     if (!ov) {
/* 304 */       ret.add("vectors", (SEXP)DoubleArrayVector.newMatrix(rz, n, n));
/*     */     }
/* 306 */     return (SEXP)ret.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Internal
/*     */   public static SEXP La_chol(@Current Context context, SEXP a, int pivot, double tol) {
/* 321 */     if (!Types.isMatrix(a)) {
/* 322 */       throw new EvalException("'a' must be a numeric matrix", new Object[0]);
/*     */     }
/*     */     
/* 325 */     double[] matrix = ((AtomicVector)a).toDoubleArray();
/* 326 */     int[] dim = a.getAttributes().getDimArray();
/*     */     
/* 328 */     int m = dim[0];
/* 329 */     int n = dim[1];
/*     */     
/* 331 */     if (m != n) {
/* 332 */       throw new EvalException("'a' must be a square matrix", new Object[0]);
/*     */     }
/* 334 */     if (m <= 0) {
/* 335 */       throw new EvalException("'a' must have dims > 0", new Object[0]);
/*     */     }
/*     */ 
/*     */     
/* 339 */     int N = dim[0];
/* 340 */     for (int j = 0; j < n; j++) {
/* 341 */       for (int i = j + 1; i < n; i++) {
/* 342 */         matrix[i + N * j] = 0.0D;
/*     */       }
/*     */     } 
/* 345 */     if (pivot != 0 && pivot != 1) {
/* 346 */       throw new EvalException("invalid 'pivot' value", new Object[0]);
/*     */     }
/* 348 */     if (pivot == 0) {
/* 349 */       intW intW = new intW(0);
/* 350 */       LAPACK.getInstance().dpotrf("Upper", m, matrix, m, intW);
/* 351 */       if (intW.val != 0) {
/* 352 */         if (intW.val > 0) {
/* 353 */           throw new EvalException("the leading minor of order %d is not positive definite", new Object[] { Integer.valueOf(intW.val) });
/*     */         }
/* 355 */         throw new EvalException("argument %d of Lapack routine %s had invalid value", new Object[] { Integer.valueOf(intW.val), "dpotrf" });
/*     */       } 
/*     */       
/* 358 */       return (SEXP)DoubleArrayVector.unsafe(matrix, a.getAttributes());
/*     */     } 
/*     */ 
/*     */     
/* 362 */     int[] pivoti = new int[m];
/* 363 */     double[] work = new double[m * 2];
/* 364 */     IntPtr rank = new IntPtr(new int[] { 0 });
/* 365 */     IntPtr info = new IntPtr(new int[] { 0 });
/* 366 */     org.renjin.math.Lapack.dpstrf_((Ptr)UPPER_TRIANGLE, (Ptr)new IntPtr(new int[] { m }, ), (Ptr)new DoublePtr(matrix), (Ptr)new IntPtr(new int[] { m }, ), (Ptr)new IntPtr(pivoti), (Ptr)rank, (Ptr)new DoublePtr(new double[] { tol }, ), (Ptr)new DoublePtr(work), (Ptr)info, 1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 378 */     if (info.get() != 0) {
/* 379 */       if (info.get() > 0) {
/* 380 */         context.warn("the matrix is either rank-deficient or indefinite");
/*     */       } else {
/* 382 */         throw new EvalException("argument %d of Lapack routine %s had invalid value", new Object[] { Integer.valueOf(-info.get()), "dpstrf" });
/*     */       } 
/*     */     }
/*     */     
/* 386 */     return (SEXP)DoubleArrayVector.unsafe(matrix, a
/* 387 */         .getAttributes().copy()
/* 388 */         .set("pivot", (SEXP)IntArrayVector.unsafe(pivoti))
/* 389 */         .set("rank", (SEXP)IntArrayVector.unsafe(rank.array))
/* 390 */         .setDimNames((SEXP)pivotColumnNames(a.getAttributes().getDimNames(), pivoti))
/* 391 */         .build());
/*     */   }
/*     */ 
/*     */   
/*     */   private static Vector pivotColumnNames(Vector dimNames, int[] pivoti) {
/* 396 */     if (dimNames == Null.INSTANCE) {
/* 397 */       return (Vector)Null.INSTANCE;
/*     */     }
/* 399 */     Vector colNames = (Vector)dimNames.getElementAsSEXP(1);
/* 400 */     if (colNames == Null.INSTANCE) {
/* 401 */       return dimNames;
/*     */     }
/* 403 */     ListVector dimNamesList = (ListVector)dimNames;
/* 404 */     StringVector.Builder pivotedCallNames = new StringVector.Builder(colNames.length());
/* 405 */     for (int i = 0; i < pivoti.length; i++) {
/* 406 */       pivotedCallNames.set(i, colNames.getElementAsString(pivoti[i] - 1));
/*     */     }
/*     */     
/* 409 */     return (Vector)dimNamesList.newCopyBuilder()
/* 410 */       .set(1, (SEXP)pivotedCallNames.build())
/* 411 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Internal
/*     */   public static SEXP backsolve(AtomicVector r, AtomicVector b, int k, boolean upper, boolean trans) {
/* 429 */     int nrr = r.getAttributes().getDimArray()[0];
/* 430 */     int nrb = b.getAttributes().getDimArray()[0];
/* 431 */     int ncb = b.getAttributes().getDimArray()[1];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 437 */     if (IntVector.isNA(k) || k <= 0 || k > nrr || k > r.getAttributes().getDimArray()[1] || k > nrb) {
/* 438 */       throw new EvalException("invalid k argument", new Object[0]);
/*     */     }
/*     */     
/* 441 */     double[] rr = r.toDoubleArray();
/*     */ 
/*     */     
/* 444 */     int incr = nrr + 1;
/* 445 */     for (int i = 0; i < k; i++) {
/* 446 */       if (rr[i * incr] == 0.0D) {
/* 447 */         throw new EvalException("singular matrix in 'backsolve'. First zero in diagonal [%d]", new Object[] { Integer.valueOf(i + 1) });
/*     */       }
/*     */     } 
/*     */     
/* 451 */     double[] ans = new double[k * ncb];
/* 452 */     double[] ba = b.toDoubleArray();
/* 453 */     double one = 1.0D;
/*     */     
/* 455 */     if (k > 0 && ncb > 0) {
/*     */       
/* 457 */       for (int j = 0; j < ncb; j++) {
/* 458 */         System.arraycopy(ba, j * nrb, ans, j * k, k);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 465 */       BLAS.getInstance().dtrsm("L", upper ? "U" : "L", trans ? "T" : "N", "N", k, ncb, one, rr, nrr, ans, k);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 478 */     return (SEXP)DoubleArrayVector.unsafe(ans, AttributeMap.builder().setDim(k, ncb));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Internal
/*     */   public static double La_dlange(AtomicVector A, StringVector type) {
/* 492 */     if (!Types.isMatrix((SEXP)A)) {
/* 493 */       throw new EvalException("'A' must be a numeric matrix", new Object[0]);
/*     */     }
/*     */     
/* 496 */     double[] a = A.toDoubleArray();
/*     */     
/* 498 */     int[] xdims = A.getAttributes().getDimArray();
/* 499 */     int m = xdims[0];
/* 500 */     int n = xdims[1];
/*     */     
/* 502 */     double[] work = null;
/*     */     
/* 504 */     String normalizationType = La_norm_type(type);
/* 505 */     if (normalizationType.equals("I")) {
/* 506 */       work = new double[m];
/*     */     }
/*     */     
/* 509 */     return LAPACK.getInstance().dlange(normalizationType, m, n, a, m, work);
/*     */   }
/*     */ 
/*     */   
/*     */   private static String La_norm_type(StringVector typeVector) {
/* 514 */     String type = Strings.nullToEmpty(typeVector.getElementAsString(0)).toUpperCase();
/* 515 */     switch (type) {
/*     */       case "1":
/* 517 */         return "O";
/*     */       case "E":
/* 519 */         return "F";
/*     */       case "M":
/*     */       case "O":
/*     */       case "I":
/*     */       case "F":
/* 524 */         return type;
/*     */     } 
/*     */     
/* 527 */     throw new EvalException("argument type[1]='%s' must be one of 'M','1','O','I','F' or 'E'", new Object[] { type });
/*     */   }
/*     */ 
/*     */   
/*     */   private static String La_rcond_type(StringVector typeVector) {
/* 532 */     String type = Strings.nullToEmpty(typeVector.getElementAsString(0)).toUpperCase();
/* 533 */     switch (type) {
/*     */       case "1":
/* 535 */         return "O";
/*     */       case "O":
/*     */       case "I":
/* 538 */         return type;
/*     */     } 
/* 540 */     throw new EvalException("argument type[1]='%s' must be one of '1','O', or 'I'", new Object[] { type });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Internal
/*     */   public static double La_dtrcon(AtomicVector A, StringVector typeVector) {
/* 556 */     if (!Types.isMatrix((SEXP)A)) {
/* 557 */       throw new EvalException("'A' must be a numeric matrix", new Object[0]);
/*     */     }
/*     */     
/* 560 */     double[] a = A.toDoubleArray();
/*     */     
/* 562 */     int[] xdims = A.getAttributes().getDimArray();
/* 563 */     int n = xdims[0];
/* 564 */     int m = xdims[1];
/*     */     
/* 566 */     if (n != m) {
/* 567 */       throw new EvalException("'A' must be a *square* matrix", new Object[0]);
/*     */     }
/*     */     
/* 570 */     String type = La_rcond_type(typeVector);
/*     */     
/* 572 */     doubleW val = new doubleW(0.0D);
/* 573 */     intW info = new intW(0);
/*     */     
/* 575 */     LAPACK.getInstance().dtrcon(type, "U", "N", n, a, n, val, new double[n], new int[n], info);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 589 */     if (info.val != 0) {
/* 590 */       throw new EvalException("error [%d] from Lapack 'dtrcon()'", new Object[] { Integer.valueOf(info.val) });
/*     */     }
/*     */     
/* 593 */     return val.val;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Internal
/*     */   public static double La_dgecon(AtomicVector A, StringVector norm) {
/*     */     double[] work;
/* 608 */     if (!Types.isMatrix((SEXP)A)) {
/* 609 */       throw new EvalException("'A' must be a numeric matrix", new Object[0]);
/*     */     }
/*     */     
/* 612 */     int[] xdims = A.getAttributes().getDimArray();
/* 613 */     int m = xdims[0];
/* 614 */     int n = xdims[1];
/*     */     
/* 616 */     String typeNorm = La_rcond_type(norm);
/*     */ 
/*     */     
/* 619 */     if (typeNorm.equals("I") && m > 4 * n) {
/* 620 */       work = new double[m];
/*     */     } else {
/* 622 */       work = new double[4 * n];
/*     */     } 
/*     */     
/* 625 */     double[] a = A.toDoubleArray();
/* 626 */     int[] iwork = new int[m];
/*     */     
/* 628 */     double anorm = LAPACK.getInstance().dlange(typeNorm, m, n, a, m, work);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 638 */     intW info = new intW(0);
/* 639 */     LAPACK.getInstance().dgetrf(m, n, a, m, iwork, info);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 648 */     if (info.val != 0) {
/* 649 */       if (info.val < 0) {
/* 650 */         throw new EvalException("error [%d] from Lapack 'dgetrf()'", new Object[] { Integer.valueOf(info.val) });
/*     */       }
/*     */ 
/*     */       
/* 654 */       return 0.0D;
/*     */     } 
/*     */ 
/*     */     
/* 658 */     doubleW val = new doubleW(0.0D);
/* 659 */     LAPACK.getInstance().dgecon(typeNorm, n, a, n, anorm, val, work, iwork, info);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 670 */     if (info.val != 0) {
/* 671 */       throw new EvalException("error [%d] from Lapack 'dgecon()'", new Object[] { Integer.valueOf(info.val) });
/*     */     }
/* 673 */     return val.val;
/*     */   }
/*     */   
/*     */   @Internal
/*     */   public static SEXP La_zgecon(SEXP x, StringVector norm) {
/* 678 */     throw new EvalException("TODO", new Object[0]);
/*     */   }
/*     */   
/*     */   @Internal
/*     */   public static SEXP La_ztrcon(SEXP x, StringVector norm) {
/* 683 */     throw new EvalException("TODO", new Object[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   private static class ComplexEntry
/*     */     implements Comparable<ComplexEntry>
/*     */   {
/*     */     public Complex z;
/*     */     
/*     */     public double[] vector;
/*     */ 
/*     */     
/*     */     public ComplexEntry(Complex z, double[] vector) {
/* 696 */       this.z = z;
/* 697 */       this.vector = vector;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int compareTo(ComplexEntry that) {
/* 704 */       Complex o1 = this.z;
/* 705 */       Complex o2 = that.z;
/* 706 */       if (o1.getImaginary() == 0.0D && o2.getImaginary() != 0.0D)
/* 707 */         return -1; 
/* 708 */       if (o1.getImaginary() != 0.0D && o2.getImaginary() == 0.0D) {
/* 709 */         return 1;
/*     */       }
/* 711 */       return (int)(ComplexGroup.Mod(o2) - ComplexGroup.Mod(o1));
/*     */     }
/*     */ 
/*     */     
/*     */     public static Complex[] getEigenvalues(int n, List<ComplexEntry> complex) {
/* 716 */       Complex[] eigenvalues = new Complex[n];
/* 717 */       for (int i = 0; i < n; i++) {
/* 718 */         eigenvalues[i] = ((ComplexEntry)complex.get(i)).z;
/*     */       }
/* 720 */       return eigenvalues;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Complex[] getEigenvectors(List<ComplexEntry> complexes) {
/* 730 */       int n = complexes.size();
/* 731 */       Complex[] result = new Complex[n * n];
/* 732 */       for (int j = 0; j < n; j++) {
/* 733 */         Complex z = ((ComplexEntry)complexes.get(j)).z;
/* 734 */         if (z.getImaginary() == 0.0D) {
/*     */           
/* 736 */           for (int index = 0; index < n; index++) {
/* 737 */             result[n * j + index] = Lapack.complex(((ComplexEntry)complexes.get(j)).vector[index]);
/*     */           }
/* 739 */         } else if (j + 1 < n && isConjugate(z, ((ComplexEntry)complexes.get(j + 1)).z)) {
/*     */           
/* 741 */           for (int index = 0; index < n; index++) {
/* 742 */             result[n * j + index] = Lapack.complex(((ComplexEntry)complexes.get(j)).vector[index], ((ComplexEntry)complexes.get(j + 1)).vector[index]);
/*     */           }
/* 744 */         } else if (j > 0 && isConjugate(z, ((ComplexEntry)complexes.get(j - 1)).z)) {
/*     */           
/* 746 */           for (int index = 0; index < n; index++) {
/* 747 */             result[n * j + index] = Lapack.complex(((ComplexEntry)complexes.get(j - 1)).vector[index], -1.0D * ((ComplexEntry)complexes.get(j)).vector[index]);
/*     */           }
/*     */         } else {
/* 750 */           assert false : "This should never happen!";
/*     */         } 
/*     */       } 
/* 753 */       return result;
/*     */     }
/*     */     private static boolean isConjugate(Complex z, Complex w) {
/* 756 */       return (z.getReal() == w.getReal() && z.getImaginary() == -1.0D * w.getImaginary());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SEXP rg(SEXP x, boolean ov) {
/* 767 */     int n = getSquareMatrixSize(x);
/*     */ 
/*     */     
/* 770 */     double[] xvals = ((DoubleVector)x).toDoubleArray();
/*     */     
/* 772 */     boolean vectors = !ov;
/* 773 */     String jobVR = "N", jobVL = jobVR;
/*     */ 
/*     */     
/* 776 */     double[] left = null;
/* 777 */     double[] right = null;
/*     */     
/* 779 */     if (vectors) {
/* 780 */       jobVR = "V";
/* 781 */       jobVL = "V";
/* 782 */       right = new double[n * n];
/* 783 */       left = new double[n * n];
/*     */     } 
/* 785 */     double[] wR = new double[n];
/* 786 */     double[] wI = new double[n];
/*     */ 
/*     */     
/* 789 */     int lwork = -1;
/*     */     
/* 791 */     LAPACK lapack = LAPACK.getInstance();
/*     */     
/* 793 */     double[] tmp = new double[1];
/* 794 */     intW info = new intW(0);
/* 795 */     lapack.dgeev(jobVL, jobVR, n, xvals, n, wR, wI, left, n, right, n, tmp, lwork, info);
/*     */     
/* 797 */     if (info.val != 0) {
/* 798 */       throw new EvalException("error code %d from Lapack routine '%s'", new Object[] { Integer.valueOf(info.val), "dgeev" });
/*     */     }
/*     */     
/* 801 */     lwork = (int)tmp[0];
/* 802 */     double[] work = new double[lwork];
/* 803 */     lapack.dgeev(jobVL, jobVR, n, xvals, n, wR, wI, left, n, right, n, work, lwork, info);
/*     */     
/* 805 */     if (info.val != 0) {
/* 806 */       throw new EvalException("error code %d from Lapack routine '%s'", new Object[] { Integer.valueOf(info.val), "dgeev" });
/*     */     }
/*     */     
/* 809 */     ListVector.NamedBuilder ret = new ListVector.NamedBuilder();
/*     */     
/* 811 */     if (thereAreComplexResults(n, wR, wI)) {
/*     */ 
/*     */       
/* 814 */       List<ComplexEntry> complex = new ArrayList<>();
/* 815 */       for (int i = 0; i < n; i++) {
/* 816 */         complex.add(new ComplexEntry(complex(wR[i], wI[i]), Arrays.copyOfRange(right, n * i, n * (i + 1))));
/*     */       }
/* 818 */       Collections.sort(complex);
/* 819 */       Complex[] eigenvalues = ComplexEntry.getEigenvalues(n, complex);
/* 820 */       ComplexArrayVector values = new ComplexArrayVector(eigenvalues);
/*     */       
/* 822 */       ret.add("values", (SEXP)values);
/*     */       
/* 824 */       ret.add("vectors", vectors ? (SEXP)ComplexArrayVector.newMatrix(ComplexEntry.getEigenvectors(complex), n, n) : (SEXP)Null.INSTANCE);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 839 */       ret.add("values", (SEXP)new DoubleArrayVector(wR));
/* 840 */       ret.add("vectors", vectors ? (SEXP)DoubleArrayVector.newMatrix(right, n, n) : (SEXP)Null.INSTANCE);
/*     */     } 
/* 842 */     return (SEXP)ret.build();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean thereAreComplexResults(int n, double[] wR, double[] wI) {
/* 848 */     boolean complexValues = false;
/* 849 */     for (int i = 0; i < n; i++) {
/*     */       
/* 851 */       if (Math.abs(wI[i]) > 2.220446E-15D * Math.abs(wR[i])) {
/* 852 */         complexValues = true;
/*     */         break;
/*     */       } 
/*     */     } 
/* 856 */     return complexValues;
/*     */   }
/*     */ 
/*     */   
/*     */   public static ComplexVector c(double... d) {
/* 861 */     ComplexArrayVector.Builder builder = new ComplexArrayVector.Builder();
/* 862 */     for (double di : d) {
/* 863 */       builder.add(ComplexVector.complex(di));
/*     */     }
/* 865 */     return builder.build();
/*     */   }
/*     */   
/*     */   public static Complex complex(double x, double y) {
/* 869 */     return ComplexVector.complex(x, y);
/*     */   }
/*     */   
/*     */   public static Complex complex(double x) {
/* 873 */     return complex(x, 0.0D);
/*     */   }
/*     */   
/*     */   protected static Complex[] row(Complex... z) {
/* 877 */     return z;
/*     */   }
/*     */   
/*     */   protected static SEXP matrix(Complex[]... rows) {
/* 881 */     ComplexArrayVector.Builder matrix = new ComplexArrayVector.Builder();
/* 882 */     int nrows = rows.length;
/* 883 */     int ncols = (rows[0]).length;
/*     */     
/* 885 */     for (int j = 0; j != ncols; j++) {
/* 886 */       for (int i = 0; i != nrows; i++) {
/* 887 */         matrix.add(rows[i][j]);
/*     */       }
/*     */     } 
/* 890 */     return (SEXP)matrix.build();
/*     */   }
/*     */   
/*     */   private static int getSquareMatrixSize(SEXP x) {
/* 894 */     Vector xdims = (Vector)x.getAttribute(Symbols.DIM);
/* 895 */     if (xdims.length() != 2 || xdims.getElementAsInt(0) != xdims.getElementAsInt(1)) {
/* 896 */       throw new EvalException("'x' must be a square numeric matrix", new Object[0]);
/*     */     }
/* 898 */     int n = xdims.getElementAsInt(0);
/* 899 */     return n;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/base/Lapack.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */