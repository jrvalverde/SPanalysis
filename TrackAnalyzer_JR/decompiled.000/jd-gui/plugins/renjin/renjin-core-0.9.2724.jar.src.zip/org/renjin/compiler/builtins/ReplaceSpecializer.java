/*    */ package org.renjin.compiler.builtins;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.renjin.compiler.ir.ValueBounds;
/*    */ import org.renjin.compiler.ir.tac.RuntimeState;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReplaceSpecializer
/*    */   implements Specializer, BuiltinSpecializer
/*    */ {
/*    */   public String getName() {
/* 34 */     return "[<-";
/*    */   }
/*    */ 
/*    */   
/*    */   public String getGroup() {
/* 39 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public Specialization trySpecialize(RuntimeState runtimeState, List<ArgumentBounds> arguments) {
/* 44 */     if (arguments.size() == 3) {
/*    */ 
/*    */       
/* 47 */       ValueBounds inputVector = ((ArgumentBounds)arguments.get(0)).getBounds();
/* 48 */       ValueBounds subscript = ((ArgumentBounds)arguments.get(1)).getBounds();
/* 49 */       ValueBounds replacement = ((ArgumentBounds)arguments.get(2)).getBounds();
/*    */       
/* 51 */       if (subscript.getLength() == 1 && replacement.getLength() == 1 && inputVector
/* 52 */         .getTypeSet() == replacement.getTypeSet()) {
/* 53 */         return new UpdateElementCall(inputVector, subscript, replacement);
/*    */       }
/*    */     } 
/*    */ 
/*    */     
/* 58 */     return UnspecializedCall.INSTANCE;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/builtins/ReplaceSpecializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */