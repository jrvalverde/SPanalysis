/*     */ package org.renjin.compiler.codegen;
/*     */ 
/*     */ import java.io.PrintWriter;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ import org.renjin.compiler.CompiledBody;
/*     */ import org.renjin.compiler.CompiledLoopBody;
/*     */ import org.renjin.compiler.JitClassLoader;
/*     */ import org.renjin.compiler.NotCompilableException;
/*     */ import org.renjin.compiler.TypeSolver;
/*     */ import org.renjin.compiler.cfg.BasicBlock;
/*     */ import org.renjin.compiler.cfg.ControlFlowGraph;
/*     */ import org.renjin.compiler.ir.exception.InternalCompilerException;
/*     */ import org.renjin.compiler.ir.tac.IRLabel;
/*     */ import org.renjin.compiler.ir.tac.statements.Statement;
/*     */ import org.renjin.eval.Context;
/*     */ import org.renjin.repackaged.asm.ClassVisitor;
/*     */ import org.renjin.repackaged.asm.ClassWriter;
/*     */ import org.renjin.repackaged.asm.MethodVisitor;
/*     */ import org.renjin.repackaged.asm.Opcodes;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ import org.renjin.repackaged.asm.commons.InstructionAdapter;
/*     */ import org.renjin.repackaged.asm.tree.MethodNode;
/*     */ import org.renjin.repackaged.asm.util.Textifier;
/*     */ import org.renjin.sexp.Environment;
/*     */ import org.renjin.sexp.SEXP;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ByteCodeEmitter
/*     */   implements Opcodes
/*     */ {
/*  44 */   private static final AtomicLong CLASS_COUNTER = new AtomicLong(1L);
/*     */   
/*     */   private ClassWriter cw;
/*     */   
/*     */   private ClassVisitor cv;
/*     */   
/*     */   private ControlFlowGraph cfg;
/*     */   
/*     */   private String className;
/*     */   private TypeSolver types;
/*     */   
/*     */   public ByteCodeEmitter(ControlFlowGraph cfg, TypeSolver types) {
/*  56 */     this.cfg = cfg;
/*  57 */     this.types = types;
/*  58 */     this.className = "Body" + CLASS_COUNTER.getAndIncrement();
/*     */   }
/*     */   
/*     */   public Class<CompiledBody> compile() {
/*  62 */     startClass(CompiledBody.class);
/*  63 */     writeImplementation();
/*  64 */     writeConstructor();
/*  65 */     writeClassEnd();
/*     */     
/*  67 */     return JitClassLoader.defineClass(CompiledBody.class, this.className.replace('/', '.'), this.cw.toByteArray());
/*     */   }
/*     */   
/*     */   public Class<CompiledLoopBody> compileLoopBody() {
/*  71 */     startClass(CompiledLoopBody.class);
/*  72 */     writeLoopImplementation();
/*  73 */     writeConstructor();
/*  74 */     writeClassEnd();
/*     */     
/*  76 */     return JitClassLoader.defineClass(CompiledLoopBody.class, this.className.replace('/', '.'), this.cw.toByteArray());
/*     */   }
/*     */ 
/*     */   
/*     */   private void startClass(Class<?> interfaceClass) {
/*  81 */     this.cw = new ClassWriter(2);
/*  82 */     this.cv = (ClassVisitor)this.cw;
/*  83 */     this.cv.visit(50, 33, this.className, null, 
/*  84 */         Type.getInternalName(Object.class), new String[] { Type.getInternalName(interfaceClass) });
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeConstructor() {
/*  89 */     MethodVisitor mv = this.cv.visitMethod(1, "<init>", "()V", null, null);
/*  90 */     mv.visitCode();
/*  91 */     mv.visitVarInsn(25, 0);
/*  92 */     mv.visitMethodInsn(183, Type.getInternalName(Object.class), "<init>", "()V", false);
/*  93 */     mv.visitInsn(177);
/*  94 */     mv.visitMaxs(2, 1);
/*  95 */     mv.visitEnd();
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeImplementation() {
/* 100 */     int argumentSize = 3;
/* 101 */     VariableSlots variableSlots = new VariableSlots(argumentSize, this.types);
/* 102 */     EmitContext emitContext = new EmitContext(this.cfg, argumentSize, variableSlots);
/*     */     
/* 104 */     MethodVisitor mv = this.cv.visitMethod(1, "evaluate", 
/* 105 */         Type.getMethodDescriptor(Type.getType(SEXP.class), new Type[] { Type.getType(Context.class), Type.getType(Environment.class) }), null, null);
/*     */ 
/*     */     
/* 108 */     Textifier p = new Textifier();
/*     */ 
/*     */     
/* 111 */     mv.visitCode();
/* 112 */     writeBody(emitContext, mv, this.cfg);
/* 113 */     mv.visitEnd();
/*     */     
/* 115 */     try (PrintWriter pw = new PrintWriter(System.out)) {
/* 116 */       p.print(pw);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void writeLoopImplementation() {
/* 121 */     int argumentSize = 5;
/* 122 */     VariableSlots variableSlots = new VariableSlots(argumentSize, this.types);
/* 123 */     EmitContext emitContext = new EmitContext(this.cfg, argumentSize, variableSlots);
/* 124 */     emitContext.setLoopVectorIndex(3);
/* 125 */     emitContext.setLoopIterationIndex(4);
/*     */ 
/*     */     
/* 128 */     MethodNode methodNode = new MethodNode(1, "run", Type.getMethodDescriptor(Type.getType(SEXP.class), new Type[] { Type.getType(Context.class), Type.getType(Environment.class), 
/* 129 */             Type.getType(SEXP.class), Type.INT_TYPE }), null, null);
/*     */ 
/*     */     
/* 132 */     MethodNode methodNode1 = methodNode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 140 */     Textifier p = new Textifier();
/*     */ 
/*     */     
/* 143 */     methodNode1.visitCode();
/* 144 */     writeBody(emitContext, (MethodVisitor)methodNode1, this.cfg);
/* 145 */     methodNode1.visitEnd();
/*     */     
/* 147 */     PrintWriter pw = new PrintWriter(System.out);
/* 148 */     p.print(pw);
/* 149 */     pw.flush();
/*     */     
/* 151 */     methodNode.accept(this.cv);
/*     */   }
/*     */   
/*     */   public static void writeBody(EmitContext emitContext, MethodVisitor mv, ControlFlowGraph cfg) {
/* 155 */     InstructionAdapter instructionAdapter = new InstructionAdapter(mv);
/*     */     
/* 157 */     for (BasicBlock basicBlock : cfg.getBasicBlocks()) {
/* 158 */       if (basicBlock.isLive() && basicBlock != cfg.getEntry() && basicBlock != cfg.getExit()) {
/* 159 */         for (IRLabel label : basicBlock.getLabels()) {
/* 160 */           mv.visitLabel(emitContext.getAsmLabel(label));
/*     */         }
/*     */         
/* 163 */         for (Statement stmt : basicBlock.getStatements()) {
/*     */           try {
/* 165 */             stmt.emit(emitContext, instructionAdapter);
/* 166 */           } catch (NotCompilableException e) {
/* 167 */             throw e;
/* 168 */           } catch (Exception e) {
/* 169 */             throw new InternalCompilerException("Exception compiling statement " + stmt, e);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 174 */     emitContext.writeDone(instructionAdapter);
/*     */     
/* 176 */     mv.visitMaxs(0, emitContext.getLocalVariableCount());
/*     */   }
/*     */   
/*     */   private void writeClassEnd() {
/* 180 */     this.cv.visitEnd();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/codegen/ByteCodeEmitter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */