/*    */ package org.renjin.compiler.builtins;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.renjin.compiler.codegen.EmitContext;
/*    */ import org.renjin.compiler.ir.ValueBounds;
/*    */ import org.renjin.compiler.ir.tac.IRArgument;
/*    */ import org.renjin.compiler.ir.tac.expressions.Expression;
/*    */ import org.renjin.invoke.model.JvmMethod;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ import org.renjin.repackaged.asm.commons.InstructionAdapter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StaticMethodCall
/*    */   implements Specialization
/*    */ {
/*    */   private final JvmMethod method;
/*    */   private final ValueBounds valueBounds;
/*    */   private final boolean pure;
/*    */   
/*    */   public StaticMethodCall(JvmMethod method) {
/* 42 */     this.method = method;
/* 43 */     this.pure = method.isPure();
/* 44 */     this.valueBounds = ValueBounds.of(method.getReturnType());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static boolean isEligible(JvmMethod method) {
/* 53 */     for (JvmMethod.Argument argument : method.getAllArguments()) {
/* 54 */       if (argument.isContextual()) {
/* 55 */         return false;
/*    */       }
/*    */     } 
/*    */     
/* 59 */     return true;
/*    */   }
/*    */   
/*    */   public Specialization furtherSpecialize(List<ValueBounds> argumentBounds) {
/* 63 */     if (this.pure && ValueBounds.allConstant(argumentBounds)) {
/* 64 */       return ConstantCall.evaluate(this.method, argumentBounds);
/*    */     }
/* 66 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public Type getType() {
/* 71 */     return Type.getType(this.method.getReturnType());
/*    */   }
/*    */   
/*    */   public ValueBounds getResultBounds() {
/* 75 */     return this.valueBounds;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void load(EmitContext emitContext, InstructionAdapter mv, List<IRArgument> arguments) {
/* 81 */     for (JvmMethod.Argument argument : this.method.getAllArguments()) {
/* 82 */       assert !argument.isContextual();
/* 83 */       Expression argumentExpr = ((IRArgument)arguments.get(argument.getIndex())).getExpression();
/* 84 */       argumentExpr.load(emitContext, mv);
/* 85 */       emitContext.convert(mv, argumentExpr.getType(), Type.getType(argument.getClazz()));
/*    */     } 
/*    */     
/* 88 */     mv.invokestatic(Type.getInternalName(this.method.getDeclaringClass()), this.method.getName(), 
/* 89 */         Type.getMethodDescriptor(this.method.getMethod()), false);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isPure() {
/* 95 */     return this.method.isPure();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/builtins/StaticMethodCall.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */