/*     */ package org.renjin.compiler.ir.tac.functions;
/*     */ 
/*     */ import org.renjin.compiler.ir.tac.IRBodyBuilder;
/*     */ import org.renjin.compiler.ir.tac.IRLabel;
/*     */ import org.renjin.compiler.ir.tac.expressions.Constant;
/*     */ import org.renjin.compiler.ir.tac.expressions.Expression;
/*     */ import org.renjin.compiler.ir.tac.expressions.LValue;
/*     */ import org.renjin.compiler.ir.tac.expressions.SimpleExpression;
/*     */ import org.renjin.compiler.ir.tac.expressions.Temp;
/*     */ import org.renjin.compiler.ir.tac.statements.Assignment;
/*     */ import org.renjin.compiler.ir.tac.statements.GotoStatement;
/*     */ import org.renjin.compiler.ir.tac.statements.IfStatement;
/*     */ import org.renjin.compiler.ir.tac.statements.Statement;
/*     */ import org.renjin.sexp.Function;
/*     */ import org.renjin.sexp.FunctionCall;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IfTranslator
/*     */   extends FunctionCallTranslator
/*     */ {
/*     */   public Expression translateToExpression(IRBodyBuilder builder, TranslationContext context, Function resolvedFunction, FunctionCall call) {
/*     */     Constant constant;
/*  39 */     SimpleExpression condition = builder.translateSimpleExpression(context, call.getArgument(0));
/*     */ 
/*     */ 
/*     */     
/*  43 */     Temp ifResult = builder.newTemp();
/*     */     
/*  45 */     IRLabel trueTarget = builder.newLabel();
/*  46 */     IRLabel falseTarget = builder.newLabel();
/*  47 */     IRLabel endLabel = builder.newLabel();
/*     */     
/*  49 */     IfStatement jump = new IfStatement((Expression)condition, trueTarget, falseTarget);
/*  50 */     builder.addStatement((Statement)jump);
/*     */ 
/*     */     
/*  53 */     builder.addLabel(trueTarget);
/*  54 */     Expression ifTrueResult = builder.translateExpression(context, call.getArgument(1));
/*     */ 
/*     */     
/*  57 */     builder.addStatement((Statement)new Assignment((LValue)ifResult, ifTrueResult));
/*     */     
/*  59 */     builder.addStatement((Statement)new GotoStatement(endLabel));
/*     */     
/*  61 */     builder.addLabel(falseTarget);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  67 */     if (hasElse(call)) {
/*  68 */       SimpleExpression simpleExpression = builder.translateSimpleExpression(context, call.getArgument(2));
/*     */     } else {
/*  70 */       constant = Constant.NULL;
/*     */     } 
/*     */     
/*  73 */     builder.addStatement((Statement)new Assignment((LValue)ifResult, (Expression)constant));
/*     */     
/*  75 */     builder.addLabel(endLabel);
/*     */     
/*  77 */     return (Expression)ifResult;
/*     */   }
/*     */   
/*     */   private boolean hasElse(FunctionCall call) {
/*  81 */     return (call.getArguments().length() == 3);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addStatement(IRBodyBuilder builder, TranslationContext context, Function resolvedFunction, FunctionCall call) {
/*     */     IRLabel endLabel;
/*  87 */     SimpleExpression condition = builder.translateSimpleExpression(context, call.getArgument(0));
/*  88 */     IRLabel trueLabel = builder.newLabel();
/*  89 */     IRLabel falseLabel = builder.newLabel();
/*     */ 
/*     */     
/*  92 */     if (hasElse(call)) {
/*  93 */       endLabel = builder.newLabel();
/*     */     } else {
/*  95 */       endLabel = falseLabel;
/*     */     } 
/*     */     
/*  98 */     IfStatement jump = new IfStatement((Expression)condition, trueLabel, falseLabel);
/*  99 */     builder.addStatement((Statement)jump);
/*     */ 
/*     */     
/* 102 */     builder.addLabel(trueLabel);
/* 103 */     builder.translateStatements(context, call.getArgument(1));
/*     */     
/* 105 */     if (hasElse(call)) {
/* 106 */       builder.addStatement((Statement)new GotoStatement(endLabel));
/* 107 */       builder.addLabel(falseLabel);
/* 108 */       builder.translateStatements(context, call.getArgument(2));
/*     */     } 
/*     */     
/* 111 */     builder.addLabel(endLabel);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/ir/tac/functions/IfTranslator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */