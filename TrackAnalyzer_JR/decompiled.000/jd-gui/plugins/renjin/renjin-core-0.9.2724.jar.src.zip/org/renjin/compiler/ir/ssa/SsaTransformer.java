/*     */ package org.renjin.compiler.ir.ssa;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ import java.util.Map;
/*     */ import java.util.Queue;
/*     */ import java.util.Set;
/*     */ import java.util.Stack;
/*     */ import org.renjin.compiler.TypeSolver;
/*     */ import org.renjin.compiler.cfg.BasicBlock;
/*     */ import org.renjin.compiler.cfg.CfgPredicates;
/*     */ import org.renjin.compiler.cfg.ControlFlowGraph;
/*     */ import org.renjin.compiler.cfg.DominanceTree;
/*     */ import org.renjin.compiler.cfg.FlowEdge;
/*     */ import org.renjin.compiler.ir.tac.TreeNode;
/*     */ import org.renjin.compiler.ir.tac.expressions.Expression;
/*     */ import org.renjin.compiler.ir.tac.expressions.LValue;
/*     */ import org.renjin.compiler.ir.tac.expressions.Variable;
/*     */ import org.renjin.compiler.ir.tac.statements.Assignment;
/*     */ import org.renjin.compiler.ir.tac.statements.Statement;
/*     */ import org.renjin.repackaged.guava.collect.Iterables;
/*     */ import org.renjin.repackaged.guava.collect.Lists;
/*     */ import org.renjin.repackaged.guava.collect.Maps;
/*     */ import org.renjin.repackaged.guava.collect.Sets;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SsaTransformer
/*     */ {
/*     */   private ControlFlowGraph cfg;
/*     */   private DominanceTree dtree;
/*  46 */   private Map<Variable, Integer> C = Maps.newHashMap();
/*  47 */   private Map<Variable, Stack<Integer>> S = Maps.newHashMap();
/*     */   
/*     */   private Set<Variable> allVariables;
/*     */   
/*     */   public SsaTransformer(ControlFlowGraph cfg, DominanceTree dtree) {
/*  52 */     this.cfg = cfg;
/*  53 */     this.dtree = dtree;
/*  54 */     this.allVariables = allVariables();
/*     */   }
/*     */   
/*     */   public void transform() {
/*  58 */     insertPhiFunctions();
/*  59 */     renameVariables();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void insertPhiFunctions() {
/*  70 */     int iterCount = 0;
/*     */     
/*  72 */     Map<BasicBlock, Integer> hasAlready = Maps.newHashMap();
/*  73 */     Map<BasicBlock, Integer> work = Maps.newHashMap();
/*     */     
/*  75 */     for (BasicBlock X : this.cfg.getLiveBasicBlocks()) {
/*  76 */       hasAlready.put(X, Integer.valueOf(0));
/*  77 */       work.put(X, Integer.valueOf(0));
/*     */     } 
/*     */     
/*  80 */     Queue<BasicBlock> W = Lists.newLinkedList();
/*     */     
/*  82 */     for (Variable V : this.allVariables) {
/*  83 */       iterCount++;
/*     */       
/*  85 */       for (BasicBlock X : Iterables.filter(this.cfg.getLiveBasicBlocks(), CfgPredicates.containsAssignmentTo(V))) {
/*  86 */         work.put(X, Integer.valueOf(iterCount));
/*  87 */         W.add(X);
/*     */       } 
/*  89 */       while (!W.isEmpty()) {
/*  90 */         BasicBlock X = W.poll();
/*  91 */         for (BasicBlock Y : this.dtree.getFrontier(X)) {
/*  92 */           if (X != this.cfg.getExit() && (
/*  93 */             (Integer)hasAlready.get(Y)).intValue() < iterCount) {
/*  94 */             Y.insertPhiFunction(V, Y.getIncoming());
/*     */             
/*  96 */             hasAlready.put(Y, Integer.valueOf(iterCount));
/*  97 */             if (((Integer)work.get(Y)).intValue() < iterCount) {
/*  98 */               work.put(Y, Integer.valueOf(iterCount));
/*  99 */               W.add(Y);
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void renameVariables() {
/* 112 */     for (Variable V : this.allVariables) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 117 */       this.C.put(V, Integer.valueOf(1));
/*     */       
/* 119 */       Stack<Integer> stack = new Stack<>();
/* 120 */       stack.push(Integer.valueOf(0));
/* 121 */       this.S.put(V, stack);
/*     */     } 
/*     */     
/* 124 */     search(this.cfg.getEntry());
/*     */   }
/*     */   
/*     */   private Set<Variable> allVariables() {
/* 128 */     Set<Variable> set = Sets.newHashSet();
/* 129 */     for (BasicBlock bb : this.cfg.getBasicBlocks()) {
/* 130 */       for (Statement statement : bb.getStatements()) {
/* 131 */         collectVariables(set, statement.getRHS());
/* 132 */         if (statement instanceof Assignment) {
/* 133 */           collectVariables(set, (Expression)((Assignment)statement).getLHS());
/*     */         }
/*     */       } 
/*     */     } 
/* 137 */     return set;
/*     */   }
/*     */ 
/*     */   
/*     */   private void search(BasicBlock X) {
/* 142 */     for (Statement stmt : X.getStatements()) {
/* 143 */       renameVariables((TreeNode)stmt);
/*     */ 
/*     */       
/* 146 */       if (stmt instanceof Assignment) {
/* 147 */         Assignment assignment = (Assignment)stmt;
/* 148 */         if (assignment.getLHS() instanceof Variable) {
/* 149 */           Variable V = (Variable)assignment.getLHS();
/* 150 */           int i = ((Integer)this.C.get(V)).intValue();
/* 151 */           assignment.setLHS((LValue)V.getVersion(i));
/* 152 */           ((Stack<Integer>)this.S.get(V)).push(Integer.valueOf(i));
/* 153 */           this.C.put(V, Integer.valueOf(i + 1));
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 158 */     for (BasicBlock Y : this.cfg.getSuccessors(X)) {
/* 159 */       int j = whichPred(Y, X);
/* 160 */       for (Assignment A : Lists.newArrayList(Y.phiAssignments())) {
/* 161 */         PhiFunction rhs = (PhiFunction)A.getRHS();
/* 162 */         Variable V = rhs.getArgument(j);
/* 163 */         int i = Top(V);
/*     */         
/* 165 */         rhs.setVersionNumber(j, i);
/*     */       } 
/*     */     } 
/* 168 */     for (BasicBlock Y : this.dtree.getChildren(X)) {
/* 169 */       search(Y);
/*     */     }
/* 171 */     for (Assignment A : X.assignments()) {
/* 172 */       if (A.getLHS() instanceof SsaVariable) {
/* 173 */         SsaVariable lhs = (SsaVariable)A.getLHS();
/* 174 */         ((Stack)this.S.get(lhs.getInner())).pop();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void renameVariables(TreeNode node) {
/* 180 */     if (node instanceof PhiFunction) {
/*     */       return;
/*     */     }
/*     */     
/* 184 */     for (int childIndex = 0; childIndex != node.getChildCount(); childIndex++) {
/* 185 */       Expression child = node.childAt(childIndex);
/* 186 */       if (child instanceof Variable) {
/* 187 */         Variable V = (Variable)child;
/* 188 */         int i = Top(V);
/* 189 */         node.setChild(childIndex, (Expression)V.getVersion(i));
/* 190 */       } else if (child.getChildCount() > 0) {
/* 191 */         renameVariables((TreeNode)child);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void collectVariables(Set<Variable> set, Expression rhs) {
/* 197 */     if (rhs instanceof Variable) {
/* 198 */       set.add((Variable)rhs);
/*     */     } else {
/* 200 */       for (int i = 0; i != rhs.getChildCount(); i++) {
/* 201 */         collectVariables(set, rhs.childAt(i));
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private int Top(Variable V) {
/* 207 */     Stack<Integer> stack = this.S.get(V);
/* 208 */     if (stack.isEmpty()) {
/* 209 */       throw new IllegalStateException("Variable " + V + " has not been assigned to before its use");
/*     */     }
/* 211 */     return ((Integer)stack.peek()).intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int whichPred(BasicBlock X, BasicBlock Y) {
/* 221 */     int j = 0;
/* 222 */     for (FlowEdge P : X.getIncoming()) {
/* 223 */       if (P.getPredecessor().equals(Y)) {
/* 224 */         return j;
/*     */       }
/* 226 */       j++;
/*     */     } 
/* 228 */     throw new IllegalArgumentException("X is not a predecessor of Y");
/*     */   }
/*     */   
/*     */   public void removePhiFunctions(TypeSolver types) {
/* 232 */     for (BasicBlock bb : this.cfg.getBasicBlocks()) {
/* 233 */       if (bb != this.cfg.getExit()) {
/*     */         
/* 235 */         List<Assignment> phiAssignments = new ArrayList<>();
/* 236 */         ListIterator<Statement> it = bb.getStatements().listIterator();
/* 237 */         while (it.hasNext()) {
/* 238 */           Statement statement = it.next();
/* 239 */           if (statement instanceof Assignment && statement.getRHS() instanceof PhiFunction) {
/* 240 */             phiAssignments.add((Assignment)statement);
/* 241 */             it.remove();
/*     */           } 
/*     */         } 
/*     */         
/* 245 */         for (Assignment assignment : phiAssignments) {
/* 246 */           if (types.isUsed(assignment)) {
/* 247 */             insertAssignments(assignment.getLHS(), (PhiFunction)assignment.getRHS());
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void insertAssignments(LValue lhs, PhiFunction phi) {
/* 255 */     for (int i = 0; i < phi.getArguments().size(); i++) {
/* 256 */       SsaVariable variable = (SsaVariable)phi.getArgument(i);
/*     */       
/* 258 */       if (variable.getVersion() == 0) {
/* 259 */         this.cfg.getEntry().addStatement((Statement)new Assignment(lhs, (Expression)variable));
/*     */       } else {
/* 261 */         FlowEdge incoming = phi.getIncomingEdges().get(i);
/* 262 */         BasicBlock definingBlock = incoming.getPredecessor();
/* 263 */         definingBlock.addStatementBeforeJump(new Assignment(lhs, (Expression)variable));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/ir/ssa/SsaTransformer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */