/*     */ package org.renjin.invoke.codegen;
/*     */ 
/*     */ import org.renjin.eval.Context;
/*     */ import org.renjin.sexp.Environment;
/*     */ import org.renjin.sexp.Null;
/*     */ import org.renjin.sexp.PairList;
/*     */ import org.renjin.sexp.PromisePairList;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.Symbol;
/*     */ import org.renjin.sexp.Symbols;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ArgumentIterator
/*     */ {
/*     */   private Context context;
/*     */   private Environment rho;
/*     */   private PairList args;
/*  44 */   private PairList ellipses = (PairList)Null.INSTANCE;
/*     */   
/*     */   private String currentName;
/*     */   
/*     */   public ArgumentIterator(Context context, Environment rho, PairList args) {
/*  49 */     this.context = context;
/*  50 */     this.rho = rho;
/*  51 */     this.args = args;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SEXP evalNext() {
/*  59 */     PairList.Node node = nextNode();
/*  60 */     SEXP value = node.getValue();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  66 */     if (value == Symbol.MISSING_ARG) {
/*  67 */       throw new ArgumentException("empty argument");
/*     */     }
/*     */     
/*  70 */     return this.context.evaluate(value, this.rho);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SEXP evalNextOrMissing() {
/*  80 */     SEXP value = nextNode().getValue();
/*     */     
/*  82 */     return this.context.evaluate(value, this.rho, true);
/*     */   }
/*     */   
/*     */   public String getCurrentName() {
/*  86 */     return this.currentName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SEXP next() {
/*     */     PairList.Node node;
/*  95 */     if (this.ellipses != Null.INSTANCE) {
/*  96 */       node = (PairList.Node)this.ellipses;
/*  97 */       this.ellipses = node.getNext();
/*     */     }
/*  99 */     else if (this.args != Null.INSTANCE) {
/* 100 */       node = (PairList.Node)this.args;
/* 101 */       this.args = node.getNext();
/*     */     }
/*     */     else {
/*     */       
/* 105 */       throw new ArgumentException("too few arguments");
/*     */     } 
/*     */     
/* 108 */     this.currentName = node.getName();
/* 109 */     return node.getValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PairList.Node nextNode() {
/*     */     PairList.Node node;
/* 119 */     if (this.ellipses != Null.INSTANCE) {
/* 120 */       node = (PairList.Node)this.ellipses;
/* 121 */       this.ellipses = node.getNext();
/*     */     }
/* 123 */     else if (this.args != Null.INSTANCE) {
/* 124 */       node = (PairList.Node)this.args;
/* 125 */       this.args = node.getNext();
/*     */     }
/*     */     else {
/*     */       
/* 129 */       throw new ArgumentException("too few arguments");
/*     */     } 
/*     */     
/* 132 */     SEXP arg = node.getValue();
/*     */     
/* 134 */     if (Symbols.ELLIPSES.equals(arg)) {
/* 135 */       PromisePairList dotdot = (PromisePairList)this.context.evaluate(arg, this.rho);
/* 136 */       this.ellipses = (PairList)dotdot;
/* 137 */       return nextNode();
/*     */     } 
/*     */     
/* 140 */     this.currentName = node.getName();
/* 141 */     return node;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasNext() {
/* 146 */     if (this.ellipses != Null.INSTANCE) {
/* 147 */       return true;
/*     */     }
/*     */     
/* 150 */     if (this.args != Null.INSTANCE) {
/* 151 */       SEXP arg = ((PairList.Node)this.args).getValue();
/* 152 */       if (Symbols.ELLIPSES.equals(arg)) {
/* 153 */         PromisePairList dotdot = (PromisePairList)this.context.evaluate(arg, this.rho);
/* 154 */         this.ellipses = (PairList)dotdot;
/* 155 */         this.args = ((PairList.Node)this.args).getNext();
/*     */         
/* 157 */         return hasNext();
/*     */       } 
/*     */       
/* 160 */       return true;
/*     */     } 
/*     */     
/* 163 */     return false;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/codegen/ArgumentIterator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */