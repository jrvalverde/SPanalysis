/*     */ package org.renjin.compiler.ir.tac;
/*     */ 
/*     */ import java.util.Map;
/*     */ import org.renjin.compiler.NotCompilableException;
/*     */ import org.renjin.compiler.ir.exception.InvalidSyntaxException;
/*     */ import org.renjin.eval.Context;
/*     */ import org.renjin.primitives.S3;
/*     */ import org.renjin.repackaged.guava.collect.Maps;
/*     */ import org.renjin.sexp.Environment;
/*     */ import org.renjin.sexp.Function;
/*     */ import org.renjin.sexp.PairList;
/*     */ import org.renjin.sexp.Promise;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.StringVector;
/*     */ import org.renjin.sexp.Symbol;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RuntimeState
/*     */ {
/*     */   private Context context;
/*     */   private Environment rho;
/*     */   private Environment methodTable;
/*  48 */   private Map<Symbol, Function> resolvedFunctions = Maps.newHashMap();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RuntimeState(Context context, Environment rho) {
/*  56 */     this.context = context;
/*  57 */     this.rho = rho;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RuntimeState(RuntimeState parentState, Environment enclosingEnvironment) {
/*  66 */     this(parentState.context, enclosingEnvironment);
/*     */     
/*  68 */     SEXP methodTableSexp = enclosingEnvironment.getVariable(S3.METHODS_TABLE);
/*  69 */     if (methodTableSexp instanceof Promise) {
/*  70 */       throw new NotCompilableException(S3.METHODS_TABLE, S3.METHODS_TABLE + " is not evaluated.");
/*     */     }
/*  72 */     if (methodTableSexp instanceof Environment) {
/*  73 */       this.methodTable = (Environment)methodTableSexp;
/*     */     }
/*     */   }
/*     */   
/*     */   public PairList getEllipsesVariable() {
/*  78 */     SEXP ellipses = this.rho.getEllipsesVariable();
/*  79 */     if (ellipses == Symbol.UNBOUND_VALUE) {
/*  80 */       throw new InvalidSyntaxException("'...' used in an incorrect context.");
/*     */     }
/*  82 */     return (PairList)ellipses;
/*     */   }
/*     */ 
/*     */   
/*     */   public SEXP findVariable(Symbol name) {
/*  87 */     SEXP value = null;
/*  88 */     Environment environment = this.rho;
/*  89 */     while (environment != Environment.EMPTY) {
/*  90 */       if (environment.isActiveBinding(name)) {
/*  91 */         throw new NotCompilableException(name, "Active Binding encountered");
/*     */       }
/*  93 */       value = this.rho.findVariable(this.context, name);
/*  94 */       if (value instanceof Promise) {
/*  95 */         Promise promisedValue = (Promise)value;
/*  96 */         if (promisedValue.isEvaluated()) {
/*  97 */           value = promisedValue.force(this.context);
/*     */         }
/*     */         else {
/*     */           
/* 101 */           throw new NotCompilableException(name, "Unevaluated promise encountered");
/*     */         } 
/*     */       } 
/* 104 */       environment = environment.getParent();
/*     */     } 
/* 106 */     if (value == null) {
/* 107 */       throw new NotCompilableException(name, "Symbol not found. Should not reach here!");
/*     */     }
/* 109 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Function findFunction(Symbol functionName) {
/* 115 */     Function f = findFunctionIfExists(functionName);
/* 116 */     if (f != null) {
/* 117 */       return f;
/*     */     }
/* 119 */     throw new NotCompilableException(functionName, "Could not find function " + functionName);
/*     */   }
/*     */   
/*     */   public Function findFunctionIfExists(Symbol functionName) {
/* 123 */     if (this.resolvedFunctions.containsKey(functionName)) {
/* 124 */       return this.resolvedFunctions.get(functionName);
/*     */     }
/*     */     
/* 127 */     Environment environment = this.rho;
/* 128 */     while (environment != Environment.EMPTY) {
/* 129 */       Function f = isFunction(functionName, environment.getVariable(this.context, functionName));
/* 130 */       if (f != null) {
/* 131 */         this.resolvedFunctions.put(functionName, f);
/* 132 */         return f;
/*     */       } 
/* 134 */       environment = environment.getParent();
/*     */     } 
/* 136 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Function isFunction(Symbol functionName, SEXP exp) {
/* 149 */     if (exp instanceof Function) {
/* 150 */       return (Function)exp;
/*     */     }
/* 152 */     if (exp instanceof org.renjin.packaging.SerializedPromise)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 158 */       return isFunction(functionName, exp.force(this.context));
/*     */     }
/* 160 */     if (exp instanceof Promise) {
/* 161 */       Promise promise = (Promise)exp;
/* 162 */       if (promise.isEvaluated()) {
/* 163 */         return isFunction(functionName, promise.getValue());
/*     */       }
/* 165 */       throw new NotCompilableException(functionName, "Symbol " + functionName + " cannot be resolved to a function  an enclosing environment has a binding of the same name to an unevaluated promise");
/*     */     } 
/*     */ 
/*     */     
/* 169 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<Symbol, Function> getResolvedFunctions() {
/* 174 */     return this.resolvedFunctions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Function findMethod(String generic, String group, StringVector objectClasses) {
/* 185 */     Function method = null;
/*     */     
/* 187 */     for (String className : objectClasses) {
/* 188 */       method = findMethod(generic, group, className);
/* 189 */       if (method != null) {
/* 190 */         return method;
/*     */       }
/*     */     } 
/*     */     
/* 194 */     return findMethod(generic, group, "default");
/*     */   }
/*     */ 
/*     */   
/*     */   private Function findMethod(String generic, String group, String className) {
/* 199 */     Function method = findMethod(generic, className);
/* 200 */     if (method != null) {
/* 201 */       return method;
/*     */     }
/* 203 */     if (group != null) {
/* 204 */       method = findMethod(group, className);
/* 205 */       if (method != null) {
/* 206 */         return method;
/*     */       }
/*     */     } 
/* 209 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Function findMethod(String generic, String className) {
/* 220 */     Symbol method = Symbol.get(generic + "." + className);
/* 221 */     Function function = findFunctionIfExists(method);
/* 222 */     if (function != null) {
/* 223 */       return function;
/*     */     }
/*     */     
/* 226 */     if (this.methodTable != null) {
/* 227 */       SEXP functionSexp = this.methodTable.getVariable(method);
/* 228 */       if (functionSexp instanceof Promise) {
/* 229 */         throw new NotCompilableException(method, "Unevaluated entry in " + S3.METHODS_TABLE);
/*     */       }
/* 231 */       if (functionSexp instanceof Function) {
/* 232 */         return (Function)functionSexp;
/*     */       }
/*     */     } 
/*     */     
/* 236 */     return null;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/ir/tac/RuntimeState.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */