/*     */ package org.renjin.primitives.sequence;
/*     */ 
/*     */ import org.renjin.eval.EvalException;
/*     */ import org.renjin.sexp.AbstractAtomicVector;
/*     */ import org.renjin.sexp.AttributeMap;
/*     */ import org.renjin.sexp.Logical;
/*     */ import org.renjin.sexp.LogicalVector;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.Symbol;
/*     */ import org.renjin.sexp.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RepLogicalVector
/*     */   extends LogicalVector
/*     */ {
/*     */   public static final int LENGTH_THRESHOLD = 100;
/*     */   private final Vector source;
/*     */   private int length;
/*     */   private int each;
/*     */   
/*     */   public RepLogicalVector(Vector source, int length, int each, AttributeMap attributes) {
/*  33 */     super(attributes);
/*  34 */     this.source = source;
/*  35 */     this.length = length;
/*  36 */     this.each = each;
/*  37 */     if (this.length <= 0) {
/*  38 */       throw new IllegalArgumentException("length: " + length);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected SEXP cloneWithNewAttributes(AttributeMap attributes) {
/*  44 */     return (SEXP)new RepLogicalVector(this.source, this.length, this.each, attributes);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isConstantAccessTime() {
/*  49 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int length() {
/*  54 */     return this.length;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getElementAsRawLogical(int index) {
/*  59 */     return this.source.getElementAsInt(index / this.each % this.source.length());
/*     */   }
/*     */   
/*     */   public static Builder newConstantBuilder(Logical value, int length) {
/*  63 */     return new Builder(value, length);
/*     */   }
/*     */   
/*     */   public static class Builder extends AbstractAtomicVector.AbstractAtomicBuilder {
/*     */     private LogicalVector vector;
/*  68 */     private int length = 1;
/*  69 */     private int each = 1;
/*     */     
/*     */     public Builder(Logical value, int length) {
/*  72 */       switch (value) {
/*     */         case TRUE:
/*  74 */           this.vector = LogicalVector.TRUE;
/*     */           break;
/*     */         case FALSE:
/*  77 */           this.vector = LogicalVector.FALSE;
/*     */           break;
/*     */         default:
/*  80 */           this.vector = LogicalVector.NA_VECTOR;
/*     */           break;
/*     */       } 
/*  83 */       this.length = length;
/*     */     }
/*     */ 
/*     */     
/*     */     public int length() {
/*  88 */       return this.length;
/*     */     }
/*     */ 
/*     */     
/*     */     public LogicalVector build() {
/*  93 */       return new RepLogicalVector((Vector)this.vector, this.length, this.each, buildAttributes());
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder setNA(int index) {
/*  98 */       throw new EvalException("cannot set na on constant builder", new Object[0]);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setFrom(int destinationIndex, Vector source, int sourceIndex) {
/* 104 */       throw new EvalException("cannot set from on constant builder", new Object[0]);
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder add(Number value) {
/* 109 */       throw new EvalException("cannot add something to constant builder", new Object[0]);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/sequence/RepLogicalVector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */