/*    */ package org.renjin.invoke.codegen.args;
/*    */ 
/*    */ import org.renjin.invoke.codegen.GeneratorDefinitionException;
/*    */ import org.renjin.invoke.model.JvmMethod;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ArgConverterStrategies
/*    */ {
/*    */   public static ArgConverterStrategy findArgConverterStrategy(JvmMethod.Argument formal) {
/* 28 */     if (Recyclable.accept(formal)) {
/* 29 */       return new Recyclable(formal);
/*    */     }
/* 31 */     if (UsingAsCharacter.accept(formal)) {
/* 32 */       return new UsingAsCharacter(formal);
/*    */     }
/* 34 */     if (UnwrapS4Environment.accept(formal)) {
/* 35 */       return new UnwrapS4Environment(formal);
/*    */     }
/* 37 */     if (SexpSubclass.accept(formal)) {
/* 38 */       return new SexpSubclass(formal);
/*    */     }
/* 40 */     if (ToScalar.accept(formal)) {
/* 41 */       return new ToScalar(formal);
/*    */     }
/* 43 */     if (UnwrapExternalObject.accept(formal)) {
/* 44 */       return new UnwrapExternalObject(formal);
/*    */     }
/*    */     
/* 47 */     throw new GeneratorDefinitionException("Could not find a strategy for converting to argument " + formal.getIndex() + " of type " + formal.getClazz());
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/codegen/args/ArgConverterStrategies.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */