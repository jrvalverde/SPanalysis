/*    */ package org.renjin.primitives.match;
/*    */ 
/*    */ import org.renjin.sexp.LogicalArrayVector;
/*    */ import org.renjin.sexp.LogicalVector;
/*    */ import org.renjin.sexp.Vector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DuplicatedAlgorithm
/*    */   implements DuplicateSearchAlgorithm<LogicalVector>
/*    */ {
/*    */   private LogicalArrayVector.Builder result;
/*    */   
/*    */   public void init(Vector source) {
/* 31 */     this.result = new LogicalArrayVector.Builder(source.length());
/*    */   }
/*    */ 
/*    */   
/*    */   public void onUnique(int index) {
/* 36 */     this.result.set(index, false);
/*    */   }
/*    */ 
/*    */   
/*    */   public DuplicateSearchAlgorithm.Action onDuplicate(int duplicateIndex, int originalIndex) {
/* 41 */     this.result.set(duplicateIndex, true);
/* 42 */     return DuplicateSearchAlgorithm.Action.CONTINUE;
/*    */   }
/*    */ 
/*    */   
/*    */   public LogicalVector getResult() {
/* 47 */     return this.result.build();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/match/DuplicatedAlgorithm.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */