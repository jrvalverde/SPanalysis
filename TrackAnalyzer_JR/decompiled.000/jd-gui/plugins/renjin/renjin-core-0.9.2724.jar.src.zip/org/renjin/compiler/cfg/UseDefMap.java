/*     */ package org.renjin.compiler.cfg;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.renjin.compiler.ir.tac.expressions.Expression;
/*     */ import org.renjin.compiler.ir.tac.expressions.LValue;
/*     */ import org.renjin.compiler.ir.tac.statements.Assignment;
/*     */ import org.renjin.compiler.ir.tac.statements.Statement;
/*     */ import org.renjin.repackaged.guava.collect.HashMultimap;
/*     */ import org.renjin.repackaged.guava.collect.Maps;
/*     */ import org.renjin.repackaged.guava.collect.Multimap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UseDefMap
/*     */ {
/*  41 */   private Map<LValue, Assignment> assignmentMap = Maps.newHashMap();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  46 */   private Map<LValue, BasicBlock> defBlockMap = Maps.newHashMap();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  51 */   private Multimap<LValue, BasicBlock> useBlockMap = (Multimap<LValue, BasicBlock>)HashMultimap.create();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  56 */   private Multimap<LValue, Statement> useStatementMap = (Multimap<LValue, Statement>)HashMultimap.create();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  61 */   private final Set<LValue> variableUsages = new HashSet<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  66 */   private final Multimap<LValue, SsaEdge> ssaEdges = (Multimap<LValue, SsaEdge>)HashMultimap.create();
/*     */   private ControlFlowGraph cfg;
/*     */   
/*     */   public UseDefMap(ControlFlowGraph cfg) {
/*  70 */     this.cfg = cfg;
/*  71 */     for (BasicBlock basicBlock : cfg.getBasicBlocks()) {
/*  72 */       for (Statement statement : basicBlock.getStatements()) {
/*  73 */         if (statement instanceof Assignment) {
/*  74 */           Assignment assignment = (Assignment)statement;
/*  75 */           this.assignmentMap.put(assignment.getLHS(), assignment);
/*  76 */           this.defBlockMap.put(assignment.getLHS(), basicBlock);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/*  81 */     for (BasicBlock basicBlock : cfg.getBasicBlocks()) {
/*  82 */       for (Statement statement : basicBlock.getStatements()) {
/*  83 */         Expression rhs = statement.getRHS();
/*  84 */         if (rhs instanceof LValue) {
/*  85 */           addSsaEdge((LValue)rhs, basicBlock, statement);
/*  86 */           this.useBlockMap.put(rhs, basicBlock); continue;
/*     */         } 
/*  88 */         for (int i = 0; i != rhs.getChildCount(); i++) {
/*  89 */           Expression expression = rhs.childAt(i);
/*  90 */           if (expression instanceof LValue) {
/*  91 */             addSsaEdge((LValue)expression, basicBlock, statement);
/*  92 */             this.useBlockMap.put(expression, basicBlock);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void addSsaEdge(LValue variable, BasicBlock basicBlock, Statement usage) {
/* 102 */     Assignment definition = this.assignmentMap.get(variable);
/* 103 */     if (definition != null) {
/* 104 */       SsaEdge edge = new SsaEdge(definition, basicBlock, usage);
/* 105 */       this.ssaEdges.put(definition.getLHS(), edge);
/*     */       
/* 107 */       if (basicBlock != this.cfg.getExit()) {
/* 108 */         this.variableUsages.add(definition.getLHS());
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean isDefined(LValue variable) {
/* 114 */     return this.assignmentMap.containsKey(variable);
/*     */   }
/*     */   
/*     */   public Assignment getDefinition(LValue variable) {
/* 118 */     return this.assignmentMap.get(variable);
/*     */   }
/*     */   
/*     */   public BasicBlock getDefinitionBlock(LValue a) {
/* 122 */     return this.defBlockMap.get(a);
/*     */   }
/*     */   
/*     */   public Collection<SsaEdge> getSsaEdges(LValue lhs) {
/* 126 */     return this.ssaEdges.get(lhs);
/*     */   }
/*     */   
/*     */   public boolean isUsed(LValue variable) {
/* 130 */     return this.variableUsages.contains(variable);
/*     */   }
/*     */   
/*     */   public Set<LValue> getUsedVariables() {
/* 134 */     return this.variableUsages;
/*     */   }
/*     */   
/*     */   public Collection<BasicBlock> getUsedBlocks(LValue a) {
/* 138 */     return this.useBlockMap.get(a);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/cfg/UseDefMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */