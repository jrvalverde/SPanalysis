/*    */ package org.renjin.compiler.codegen;
/*    */ 
/*    */ import org.renjin.compiler.ir.TypeSet;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ import org.renjin.sexp.DoubleArrayVector;
/*    */ import org.renjin.sexp.IntArrayVector;
/*    */ import org.renjin.sexp.LogicalArrayVector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum VectorGen
/*    */ {
/* 29 */   LOGICAL
/*    */   {
/*    */     public Type getElementType() {
/* 32 */       return Type.INT_TYPE;
/*    */     }
/*    */ 
/*    */     
/*    */     public Type getVectorArrayType() {
/* 37 */       return Type.getType(LogicalArrayVector.class);
/*    */     }
/*    */   },
/* 40 */   INTEGER
/*    */   {
/*    */     public Type getElementType() {
/* 43 */       return Type.INT_TYPE;
/*    */     }
/*    */ 
/*    */     
/*    */     public Type getVectorArrayType() {
/* 48 */       return Type.getType(IntArrayVector.class);
/*    */     }
/*    */   },
/* 51 */   DOUBLE
/*    */   {
/*    */     public Type getElementType() {
/* 54 */       return Type.DOUBLE_TYPE;
/*    */     }
/*    */ 
/*    */     
/*    */     public Type getVectorArrayType() {
/* 59 */       return Type.getType(DoubleArrayVector.class);
/*    */     }
/*    */   };
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static VectorGen forType(int typeSet) {
/* 73 */     switch (typeSet) {
/*    */       case 8:
/* 75 */         return LOGICAL;
/*    */       case 16:
/* 77 */         return INTEGER;
/*    */       case 32:
/* 79 */         return DOUBLE;
/*    */     } 
/* 81 */     throw new IllegalArgumentException("typeSet: " + TypeSet.toString(typeSet));
/*    */   }
/*    */   
/*    */   public Type getArrayType() {
/* 85 */     return Type.getType("[" + getElementType().getDescriptor());
/*    */   }
/*    */   
/*    */   public abstract Type getElementType();
/*    */   
/*    */   public abstract Type getVectorArrayType();
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/codegen/VectorGen.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */