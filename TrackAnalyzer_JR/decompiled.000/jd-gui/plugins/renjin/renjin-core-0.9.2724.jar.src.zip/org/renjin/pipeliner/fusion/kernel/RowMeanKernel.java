/*     */ package org.renjin.pipeliner.fusion.kernel;
/*     */ 
/*     */ import org.renjin.pipeliner.ComputeMethod;
/*     */ import org.renjin.pipeliner.fusion.node.LoopNode;
/*     */ import org.renjin.repackaged.asm.Label;
/*     */ import org.renjin.repackaged.asm.MethodVisitor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RowMeanKernel
/*     */   implements LoopKernel
/*     */ {
/*     */   public void compute(ComputeMethod method, LoopNode[] kernelOperands) {
/*  33 */     LoopNode matrix = kernelOperands[0];
/*  34 */     matrix.init(method);
/*     */     
/*  36 */     int meansLocal = method.reserveLocal(1);
/*  37 */     LoopNode numRows = kernelOperands[1];
/*  38 */     numRows.init(method);
/*     */     
/*  40 */     MethodVisitor mv = method.getVisitor();
/*  41 */     int numRowsLocal = method.reserveLocal(meansLocal);
/*  42 */     int rowLocal = method.reserveLocal(1);
/*  43 */     int counterLocal = method.reserveLocal(1);
/*     */     
/*  45 */     numRows.pushElementAsInt(method, 0);
/*  46 */     mv.visitInsn(89);
/*  47 */     mv.visitVarInsn(54, numRowsLocal);
/*     */ 
/*     */     
/*  50 */     mv.visitIntInsn(188, 7);
/*  51 */     mv.visitVarInsn(58, meansLocal);
/*     */ 
/*     */     
/*  54 */     mv.visitInsn(3);
/*  55 */     mv.visitVarInsn(54, rowLocal);
/*     */ 
/*     */     
/*  58 */     mv.visitInsn(3);
/*  59 */     mv.visitVarInsn(54, counterLocal);
/*     */ 
/*     */     
/*  62 */     Label l4 = new Label();
/*  63 */     mv.visitLabel(l4);
/*  64 */     mv.visitVarInsn(21, counterLocal);
/*  65 */     matrix.pushLength(method);
/*     */     
/*  67 */     Label l5 = new Label();
/*  68 */     mv.visitJumpInsn(159, l5);
/*     */     
/*  70 */     Label l6 = new Label();
/*  71 */     mv.visitLabel(l6);
/*  72 */     mv.visitVarInsn(25, meansLocal);
/*  73 */     mv.visitVarInsn(21, rowLocal);
/*  74 */     mv.visitInsn(92);
/*     */ 
/*     */     
/*  77 */     mv.visitInsn(49);
/*     */ 
/*     */     
/*  80 */     mv.visitVarInsn(21, counterLocal);
/*  81 */     matrix.pushElementAsDouble(method);
/*     */ 
/*     */     
/*  84 */     mv.visitInsn(99);
/*  85 */     mv.visitInsn(82);
/*     */     
/*  87 */     Label l7 = new Label();
/*  88 */     mv.visitLabel(l7);
/*  89 */     mv.visitIincInsn(rowLocal, 1);
/*     */ 
/*     */ 
/*     */     
/*  93 */     Label l8 = new Label();
/*  94 */     mv.visitLabel(l8);
/*  95 */     mv.visitVarInsn(21, rowLocal);
/*  96 */     mv.visitVarInsn(21, numRowsLocal);
/*  97 */     Label l9 = new Label();
/*  98 */     mv.visitJumpInsn(160, l9);
/*  99 */     Label l10 = new Label();
/* 100 */     mv.visitLabel(l10);
/* 101 */     mv.visitInsn(3);
/* 102 */     mv.visitVarInsn(54, rowLocal);
/*     */ 
/*     */     
/* 105 */     mv.visitLabel(l9);
/* 106 */     mv.visitIincInsn(counterLocal, 1);
/* 107 */     mv.visitJumpInsn(167, l4);
/*     */     
/* 109 */     mv.visitLabel(l5);
/*     */     
/* 111 */     int numColsLocal = method.reserveLocal(2);
/*     */     
/* 113 */     matrix.pushLength(method);
/* 114 */     mv.visitVarInsn(21, numRowsLocal);
/* 115 */     mv.visitInsn(108);
/* 116 */     mv.visitInsn(135);
/* 117 */     mv.visitVarInsn(57, numColsLocal);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 122 */     mv.visitInsn(3);
/* 123 */     mv.visitVarInsn(54, counterLocal);
/*     */ 
/*     */     
/* 126 */     Label l11 = new Label();
/* 127 */     mv.visitLabel(l11);
/* 128 */     mv.visitVarInsn(21, counterLocal);
/* 129 */     mv.visitVarInsn(21, numRowsLocal);
/* 130 */     Label l12 = new Label();
/* 131 */     mv.visitJumpInsn(159, l12);
/*     */ 
/*     */     
/* 134 */     Label l13 = new Label();
/* 135 */     mv.visitLabel(l13);
/* 136 */     mv.visitVarInsn(25, meansLocal);
/* 137 */     mv.visitVarInsn(21, counterLocal);
/* 138 */     mv.visitInsn(92);
/*     */     
/* 140 */     mv.visitInsn(49);
/* 141 */     mv.visitVarInsn(24, numColsLocal);
/*     */     
/* 143 */     mv.visitInsn(111);
/*     */ 
/*     */     
/* 146 */     mv.visitInsn(82);
/* 147 */     Label l14 = new Label();
/*     */     
/* 149 */     mv.visitLabel(l14);
/* 150 */     mv.visitIincInsn(counterLocal, 1);
/* 151 */     mv.visitJumpInsn(167, l11);
/* 152 */     mv.visitLabel(l12);
/*     */     
/* 154 */     mv.visitVarInsn(25, meansLocal);
/* 155 */     mv.visitInsn(176);
/*     */   }
/*     */ 
/*     */   
/*     */   public String debugLabel(LoopNode[] operands) {
/* 160 */     return "rowMeans(" + operands[0] + ")";
/*     */   }
/*     */ 
/*     */   
/*     */   public void appendToKey(StringBuilder key) {
/* 165 */     key.append("rowMeans");
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/pipeliner/fusion/kernel/RowMeanKernel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */