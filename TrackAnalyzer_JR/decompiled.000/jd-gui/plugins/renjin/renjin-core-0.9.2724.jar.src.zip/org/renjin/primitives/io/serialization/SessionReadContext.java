/*    */ package org.renjin.primitives.io.serialization;
/*    */ 
/*    */ import org.renjin.eval.Context;
/*    */ import org.renjin.eval.Session;
/*    */ import org.renjin.sexp.Environment;
/*    */ import org.renjin.sexp.Promise;
/*    */ import org.renjin.sexp.SEXP;
/*    */ import org.renjin.sexp.Symbol;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SessionReadContext
/*    */   implements ReadContext
/*    */ {
/*    */   private Context context;
/*    */   
/*    */   @Deprecated
/*    */   public SessionReadContext(Session session) {
/* 37 */     this(session.getTopLevelContext());
/*    */   }
/*    */   
/*    */   public SessionReadContext(Context context) {
/* 41 */     this.context = context;
/*    */   }
/*    */ 
/*    */   
/*    */   public Environment getBaseEnvironment() {
/* 46 */     return this.context.getBaseEnvironment();
/*    */   }
/*    */ 
/*    */   
/*    */   public Promise createPromise(SEXP expr, Environment env) {
/* 51 */     return Promise.repromise(env, expr);
/*    */   }
/*    */ 
/*    */   
/*    */   public Environment findNamespace(Symbol symbol) {
/* 56 */     return this.context.getNamespaceRegistry().getNamespace(this.context, symbol).getNamespaceEnvironment();
/*    */   }
/*    */ 
/*    */   
/*    */   public Environment getBaseNamespaceEnvironment() {
/* 61 */     return this.context.getSession().getBaseNamespaceEnv();
/*    */   }
/*    */ 
/*    */   
/*    */   public Environment getGlobalEnvironment() {
/* 66 */     return this.context.getGlobalEnvironment();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/io/serialization/SessionReadContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */