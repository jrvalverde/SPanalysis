/*    */ package org.renjin.primitives.combine;
/*    */ 
/*    */ import org.renjin.sexp.ListVector;
/*    */ import org.renjin.sexp.PairList;
/*    */ import org.renjin.sexp.SEXP;
/*    */ import org.renjin.sexp.StringVector;
/*    */ import org.renjin.sexp.Vector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class Combiner
/*    */ {
/*    */   private boolean recursive;
/*    */   private CombinedBuilder builder;
/*    */   
/*    */   public Combiner(boolean recursive, CombinedBuilder builder) {
/* 34 */     this.recursive = recursive;
/* 35 */     this.builder = builder;
/*    */   }
/*    */   
/*    */   public Combiner add(ListVector list) {
/* 39 */     return add("", list);
/*    */   }
/*    */ 
/*    */   
/*    */   public Combiner add(String parentPrefix, ListVector list) {
/* 44 */     StringVector names = CombinedNames.combine(parentPrefix, (Vector)list);
/* 45 */     for (int i = 0; i < list.length(); i++) {
/*    */       
/* 47 */       String name = names.getElementAsString(i);
/* 48 */       SEXP value = list.getElementAsSEXP(i);
/*    */       
/* 50 */       addElement(name, value);
/*    */     } 
/* 52 */     return this;
/*    */   }
/*    */   
/*    */   private void addElement(String prefix, SEXP value) {
/* 56 */     if (value instanceof org.renjin.sexp.FunctionCall) {
/*    */ 
/*    */       
/* 59 */       this.builder.add(prefix, value);
/*    */     }
/* 61 */     else if (value instanceof org.renjin.sexp.AtomicVector || value instanceof org.renjin.sexp.ExpressionVector) {
/*    */ 
/*    */ 
/*    */       
/* 65 */       this.builder.addElements(prefix, (Vector)value);
/*    */     }
/* 67 */     else if (value instanceof ListVector) {
/* 68 */       if (this.recursive) {
/* 69 */         add(prefix, (ListVector)value);
/*    */       } else {
/* 71 */         this.builder.addElements(prefix, (Vector)value);
/*    */       }
/*    */     
/* 74 */     } else if (value instanceof PairList.Node) {
/* 75 */       if (this.recursive) {
/* 76 */         add(prefix, ((PairList.Node)value).toVector());
/*    */       } else {
/* 78 */         this.builder.addElements(prefix, ((PairList)value).toVector());
/*    */       } 
/*    */     } else {
/* 81 */       this.builder.add(prefix, value);
/*    */     } 
/*    */   }
/*    */   
/*    */   public Vector build() {
/* 86 */     return this.builder.build();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/combine/Combiner.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */