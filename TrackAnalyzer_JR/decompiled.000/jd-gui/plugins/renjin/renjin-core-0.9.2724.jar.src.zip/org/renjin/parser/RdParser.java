/*      */ package org.renjin.parser;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.PrintStream;
/*      */ import java.io.Reader;
/*      */ import java.util.Arrays;
/*      */ import org.renjin.sexp.IntArrayVector;
/*      */ import org.renjin.sexp.IntVector;
/*      */ import org.renjin.sexp.ListVector;
/*      */ import org.renjin.sexp.Null;
/*      */ import org.renjin.sexp.PairList;
/*      */ import org.renjin.sexp.SEXP;
/*      */ import org.renjin.sexp.SEXPBuilder;
/*      */ import org.renjin.sexp.StringArrayVector;
/*      */ import org.renjin.sexp.Symbol;
/*      */ import org.renjin.sexp.Symbols;
/*      */ import org.renjin.util.CDefines;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class RdParser
/*      */ {
/*      */   public static final String bisonVersion = "2.4.1";
/*      */   public static final String bisonSkeleton = "lalr1.java";
/*      */   public boolean errorVerbose = false;
/*      */   public static final int EOF = 0;
/*      */   public static final int END_OF_INPUT = 258;
/*      */   public static final int ERROR = 259;
/*      */   public static final int SECTIONHEADER = 260;
/*      */   public static final int RSECTIONHEADER = 261;
/*      */   public static final int VSECTIONHEADER = 262;
/*      */   public static final int SECTIONHEADER2 = 263;
/*      */   public static final int RCODEMACRO = 264;
/*      */   public static final int SEXPR = 265;
/*      */   public static final int RDOPTS = 266;
/*      */   public static final int LATEXMACRO = 267;
/*      */   public static final int VERBMACRO = 268;
/*      */   public static final int OPTMACRO = 269;
/*      */   public static final int ESCAPE = 270;
/*      */   public static final int LISTSECTION = 271;
/*      */   public static final int ITEMIZE = 272;
/*      */   public static final int DESCRIPTION = 273;
/*      */   public static final int NOITEM = 274;
/*      */   public static final int LATEXMACRO2 = 275;
/*      */   public static final int VERBMACRO2 = 276;
/*      */   public static final int LATEXMACRO3 = 277;
/*      */   public static final int IFDEF = 278;
/*      */   public static final int ENDIF = 279;
/*      */   public static final int TEXT = 280;
/*      */   public static final int RCODE = 281;
/*      */   public static final int VERB = 282;
/*      */   public static final int COMMENT = 283;
/*      */   public static final int UNKNOWN = 284;
/*      */   public static final int STARTFILE = 285;
/*      */   public static final int STARTFRAGMENT = 286;
/*      */   private Lexer yylexer;
/*      */   private PrintStream yyDebugStream;
/*      */   private int yydebug;
/*      */   public static final int YYACCEPT = 0;
/*      */   public static final int YYABORT = 1;
/*      */   public static final int YYERROR = 2;
/*      */   public static final int YYFAIL = 3;
/*      */   private static final int YYNEWSTATE = 4;
/*      */   private static final int YYDEFAULT = 5;
/*      */   private static final int YYREDUCE = 6;
/*      */   private static final int YYERRLAB1 = 7;
/*      */   private static final int YYRETURN = 8;
/*      */   private int yyerrstatus_;
/*      */   private static final short yypact_ninf_ = -71;
/*      */   
/*      */   public class Location
/*      */   {
/*      */     public Position begin;
/*      */     public Position end;
/*      */     
/*      */     public Location(Position loc) {
/*  126 */       this.begin = this.end = loc;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Location(Position begin, Position end) {
/*  134 */       this.begin = begin;
/*  135 */       this.end = end;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String toString() {
/*  143 */       if (this.begin.equals(this.end)) {
/*  144 */         return this.begin.toString();
/*      */       }
/*  146 */       return this.begin.toString() + "-" + this.end.toString();
/*      */     }
/*      */   } public final PrintStream getDebugStream() { return this.yyDebugStream; } public final void setDebugStream(PrintStream s) { this.yyDebugStream = s; } public final int getDebugLevel() { return this.yydebug; } public final void setDebugLevel(int level) { this.yydebug = level; } private final int yylex() throws IOException { return this.yylexer.yylex(); } protected final void yyerror(Location loc, String s) { this.yylexer.yyerror(loc, s); } protected final void yyerror(String s) { this.yylexer.yyerror((Location)null, s); } protected final void yyerror(Position loc, String s) { this.yylexer.yyerror(new Location(loc), s); }
/*      */   protected final void yycdebug(String s) { if (this.yydebug > 0) this.yyDebugStream.println(s);  }
/*      */   public static interface Lexer { Position getStartPos();
/*      */     Position getEndPos();
/*      */     Object getLVal();
/*      */     int yylex() throws IOException;
/*      */     void yyerror(RdParser.Location param1Location, String param1String); }
/*      */   private final class YYStack { private int[] stateStack = new int[16]; private RdParser.Location[] locStack = new RdParser.Location[16]; private Object[] valueStack = new Object[16]; public int size = 16; public int height = -1;
/*      */     public final void push(int state, Object value, RdParser.Location loc) { this.height++; if (this.size == this.height) { int[] newStateStack = new int[this.size * 2]; System.arraycopy(this.stateStack, 0, newStateStack, 0, this.height); this.stateStack = newStateStack; RdParser.Location[] newLocStack = new RdParser.Location[this.size * 2]; System.arraycopy(this.locStack, 0, newLocStack, 0, this.height); this.locStack = newLocStack; Object[] newValueStack = new Object[this.size * 2]; System.arraycopy(this.valueStack, 0, newValueStack, 0, this.height); this.valueStack = newValueStack; this.size *= 2; }  this.stateStack[this.height] = state; this.locStack[this.height] = loc; this.valueStack[this.height] = value; }
/*      */     public final void pop() { this.height--; }
/*      */     public final void pop(int num) { if (num > 0) { Arrays.fill(this.valueStack, this.height - num + 1, this.height, (Object)null); Arrays.fill((Object[])this.locStack, this.height - num + 1, this.height, (Object)null); }  this.height -= num; }
/*      */     public final int stateAt(int i) { return this.stateStack[this.height - i]; }
/*      */     public final RdParser.Location locationAt(int i) { return this.locStack[this.height - i]; }
/*      */     public final SEXP valueAt(int i) { return (SEXP)this.valueStack[this.height - i]; }
/*      */     public void print(PrintStream out) { out.print("Stack now"); for (int i = 0; i < this.height; i++) { out.print(' '); out.print(this.stateStack[i]); }  out.println(); }
/*      */     private YYStack() {} }
/*      */   public final boolean recovering() { return (this.yyerrstatus_ == 0); }
/*      */   private int yyaction(int yyn, YYStack yystack, int yylen) { Object object; Location yyloc = yylloc(yystack, yylen); if (yylen > 0) { object = yystack.valueAt(yylen - 1); } else { object = yystack.valueAt(0); }  yy_reduce_print(yyn, yystack); switch (yyn) { case 2: if (yyn == 2) { xxsavevalue(yystack.valueAt(1), yyloc); CDefines.UNPROTECT_PTR(yystack.valueAt(2)); return 0; }  break;case 3: if (yyn == 3) { xxsavevalue(yystack.valueAt(1), yyloc); CDefines.UNPROTECT_PTR(yystack.valueAt(2)); return 0; }  break;case 4: if (yyn == 4) { CDefines.PROTECT(this.Value = (SEXP)CDefines.R_NilValue); return 1; }  break;case 5: if (yyn == 5) { object = yystack.valueAt(0); CDefines.UNPROTECT_PTR(yystack.valueAt(1)); }  break;case 6: if (yyn == 6) object = yystack.valueAt(0);  break;case 7: if (yyn == 7) object = xxnewlist(yystack.valueAt(0));  break;case 8: if (yyn == 8) object = xxlist(yystack.valueAt(1), yystack.valueAt(0));  break;case 9: if (yyn == 9) object = xxmarkup(yystack.valueAt(1), yystack.valueAt(0), 0, yyloc);  break;case 10: if (yyn == 10)
/*      */           object = xxmarkup(yystack.valueAt(1), yystack.valueAt(0), 2, yyloc);  break;case 11: if (yyn == 11)
/*      */           object = xxmarkup(yystack.valueAt(1), yystack.valueAt(0), 0, yyloc);  break;case 12: if (yyn == 12)
/*      */           object = xxmarkup(yystack.valueAt(1), yystack.valueAt(0), 0, yyloc);  break;case 13: if (yyn == 13)
/*      */           object = xxmarkup(yystack.valueAt(1), yystack.valueAt(0), 0, yyloc);  break;case 14: if (yyn == 14)
/*      */           object = xxmarkup2(yystack.valueAt(2), yystack.valueAt(1), yystack.valueAt(0), 2, 0, yyloc);  break;case 15: if (yyn == 15) { object = xxmarkup2(yystack.valueAt(3), yystack.valueAt(2), yystack.valueAt(1), 2, 1, yyloc); CDefines.UNPROTECT_PTR(yystack.valueAt(0)); }  break;case 16: if (yyn == 16) { object = xxmarkup(yystack.valueAt(2), yystack.valueAt(0), 2, yyloc); xxpopMode(yystack.valueAt(1)); }  break;case 17: if (yyn == 17) { object = xxOptionmarkup(yystack.valueAt(3), yystack.valueAt(1), yystack.valueAt(0), 0, yyloc); xxpopMode(yystack.valueAt(2)); }  break;case 18: if (yyn == 18)
/*      */           object = yystack.valueStack[0] = xxtag(yystack.valueAt(0), 283, yyloc);  break;case 19: if (yyn == 19)
/*      */           object = yystack.valueStack[0] = xxtag(yystack.valueAt(0), 280, yyloc);  break;case 20: if (yyn == 20)
/*      */           object = yystack.valueAt(0);  break;case 21: if (yyn == 21)
/*      */           object = xxnewlist(yystack.valueAt(0));  break;case 22: if (yyn == 22)
/*      */           object = xxlist(yystack.valueAt(1), yystack.valueAt(0));  break;case 23: if (yyn == 23)
/*      */           object = yystack.valueStack[0] = xxtag(yystack.valueAt(0), 280, yyloc);  break;case 24: if (yyn == 24)
/*      */           object = yystack.valueStack[0] = xxtag(yystack.valueAt(0), 281, yyloc);  break;case 25: if (yyn == 25)
/*      */           object = yystack.valueStack[0] = xxtag(yystack.valueAt(0), 282, yyloc);  break;case 26: if (yyn == 26)
/*      */           object = yystack.valueStack[0] = xxtag(yystack.valueAt(0), 283, yyloc);  break;case 27: if (yyn == 27) { object = yystack.valueStack[0] = xxtag(yystack.valueAt(0), 284, yyloc); yyerror(this.yyunknown); }  break;case 28: if (yyn == 28)
/*      */           object = xxmarkup((SEXP)CDefines.R_NilValue, yystack.valueAt(0), 0, yyloc);  break;case 29: if (yyn == 29)
/*      */           object = yystack.valueAt(0);  break;case 30: if (yyn == 30)
/*      */           object = yystack.valueAt(0);  break;case 31: if (yyn == 31)
/*      */           object = xxmarkup(yystack.valueAt(1), yystack.valueAt(0), 0, yyloc);  break;case 32: if (yyn == 32)
/*      */           object = xxmarkup2(yystack.valueAt(2), yystack.valueAt(1), yystack.valueAt(0), 2, 0, yyloc);  break;case 33: if (yyn == 33)
/*      */           object = xxmarkup3(yystack.valueAt(3), yystack.valueAt(2), yystack.valueAt(1), yystack.valueAt(0), 0, yyloc);  break;case 34: if (yyn == 34)
/*      */           object = xxmarkup(yystack.valueAt(1), yystack.valueAt(0), 0, yyloc);  break;case 35: if (yyn == 35)
/*      */           object = xxmarkup(yystack.valueAt(1), yystack.valueAt(0), 0, yyloc);  break;case 36: if (yyn == 36) { object = xxmarkup(yystack.valueAt(2), yystack.valueAt(0), 0, yyloc); xxpopMode(yystack.valueAt(1)); }  break;case 37: if (yyn == 37) { object = xxOptionmarkup(yystack.valueAt(3), yystack.valueAt(1), yystack.valueAt(0), 0, yyloc); xxpopMode(yystack.valueAt(2)); }  break;case 38: if (yyn == 38)
/*      */           object = xxmarkup(yystack.valueAt(1), yystack.valueAt(0), 0, yyloc);  break;case 39: if (yyn == 39) { object = xxmarkup(yystack.valueAt(2), yystack.valueAt(0), 2, yyloc); xxpopMode(yystack.valueAt(1)); }  break;case 40: if (yyn == 40) { object = xxOptionmarkup(yystack.valueAt(3), yystack.valueAt(1), yystack.valueAt(0), 2, yyloc); xxpopMode(yystack.valueAt(2)); }  break;case 41: if (yyn == 41)
/*      */           object = xxmarkup(yystack.valueAt(1), yystack.valueAt(0), 0, yyloc);  break;case 42: if (yyn == 42)
/*      */           object = xxmarkup2(yystack.valueAt(1), yystack.valueAt(0), (SEXP)CDefines.R_NilValue, 1, 0, yyloc);  break;case 43: if (yyn == 43)
/*      */           object = xxmarkup2(yystack.valueAt(2), yystack.valueAt(1), yystack.valueAt(0), 2, 0, yyloc);  break;case 44: if (yyn == 44)
/*      */           object = xxmarkup(yystack.valueAt(0), (SEXP)CDefines.R_NilValue, 0, yyloc);  break;case 45: if (yyn == 45) { object = xxmarkup2(yystack.valueAt(3), yystack.valueAt(2), yystack.valueAt(1), 2, 1, yyloc); CDefines.UNPROTECT_PTR(yystack.valueAt(0)); }  break;case 46: if (yyn == 46) { xxpopMode(yystack.valueAt(1)); object = yystack.valueAt(0); }  break;case 47: if (yyn == 47) { xxpopMode(yystack.valueAt(1)); object = yystack.valueAt(0); }  break;case 48: if (yyn == 48) { xxpopMode(yystack.valueAt(1)); object = xxnewlist(yystack.valueAt(0)); System.out.println(String.format(CDefines._("bad markup (extra space?) at %s:%d:%d"), new Object[] { this.xxBasename, Integer.valueOf((yystack.locationAt(0)).begin.getLine()), Integer.valueOf((yystack.locationAt(0)).begin.getColumn()) })); }  break;case 49: if (yyn == 49) { xxpopMode(yystack.valueAt(1)); object = yystack.valueAt(0); }  break;case 50: if (yyn == 50) { xxpopMode(yystack.valueAt(1)); object = yystack.valueAt(0); }  break;case 51: if (yyn == 51) { xxpopMode(yystack.valueAt(1)); object = yystack.valueAt(0); }  break;case 52: if (yyn == 52) { xxpopMode(yystack.valueAt(2)); object = yystack.valueAt(1); }  break;case 53: if (yyn == 53) { xxpopMode(yystack.valueAt(1)); object = xxnewlist((SEXP)Null.INSTANCE); }  break;case 54: if (yyn == 54) { xxpopMode(yystack.valueAt(1)); object = yystack.valueAt(0); }  break;case 55: if (yyn == 55) { xxpopMode(yystack.valueAt(1)); object = yystack.valueAt(0); }  break;case 56: if (yyn == 56) { xxpopMode(yystack.valueAt(2)); object = yystack.valueAt(1); }  break;case 57: if (yyn == 57) { xxpopMode(yystack.valueAt(1)); object = xxnewlist((SEXP)Null.INSTANCE); }  break;case 58: if (yyn == 58) { xxpopMode(yystack.valueAt(1)); object = xxnewlist(yystack.valueAt(0)); }  break;case 59: if (yyn == 59)
/*      */           object = xxpushMode(2, 284, false);  break;case 60: if (yyn == 60)
/*      */           object = xxpushMode(1, 284, false);  break;case 61: if (yyn == 61) { this.xxbraceDepth--; object = xxpushMode(1, 284, false); this.xxbraceDepth++; }  break;case 62: if (yyn == 62)
/*      */           object = xxpushMode(4, 284, false);  break;case 63: if (yyn == 63)
/*      */           object = xxpushMode(3, 284, false);  break;case 64: if (yyn == 64)
/*      */           object = xxpushMode(3, 284, true);  break;case 65: if (yyn == 65) { this.xxbraceDepth--; object = xxpushMode(3, 284, false); this.xxbraceDepth++; }  break;case 66: if (yyn == 66)
/*      */           object = xxpushMode(2, 270, false);  break;case 67: if (yyn == 67)
/*      */           object = xxpushMode(2, 275, false);  break;case 68: if (yyn == 68)
/*      */           object = yystack.valueAt(1);  break;case 69: if (yyn == 69)
/*      */           object = xxnewlist((SEXP)Null.INSTANCE);  break;case 70: if (yyn == 70)
/*      */           object = yystack.valueAt(2);  break;case 71: if (yyn == 71)
/*      */           object = xxnewlist((SEXP)Null.INSTANCE);  break;case 72: if (yyn == 72)
/*      */           object = yystack.valueAt(2);  break;case 73: if (yyn == 73)
/*      */           object = yystack.valueAt(1);  break; }  yy_symbol_print("-> $$ =", yyr1_[yyn], object, yyloc); yystack.pop(yylen); yylen = 0; yyn = yyr1_[yyn]; int yystate = yypgoto_[yyn - 36] + yystack.stateAt(0); if (0 <= yystate && yystate <= 490 && yycheck_[yystate] == yystack.stateAt(0)) { yystate = yytable_[yystate]; } else { yystate = yydefgoto_[yyn - 36]; }  yystack.push(yystate, object, yyloc); return 4; }
/*      */   private final String yytname_rr_(String yystr) { if (yystr.charAt(0) == '"') { StringBuffer yyr = new StringBuffer(); for (int i = 1; i < yystr.length(); i++) { switch (yystr.charAt(i)) { case '\'': case ',': break;case '\\': if (yystr.charAt(++i) != '\\')
/*      */               break; default: yyr.append(yystr.charAt(i)); break;case '"': return yyr.toString(); }  }  } else if (yystr.equals("$end")) { return "end of input"; }  return yystr; }
/*      */   private void yy_symbol_print(String s, int yytype, Object yyvaluep, Object yylocationp) { if (this.yydebug > 0)
/*      */       yycdebug(s + ((yytype < 36) ? " token " : " nterm ") + yytname__[yytype] + " (" + yylocationp + ": " + ((yyvaluep == null) ? "(null)" : yyvaluep.toString()) + ")");  }
/*      */   public boolean parse() throws IOException { int yychar = -2; int yytoken = 0; int yyn = 0; int yylen = 0; int yystate = 0; YYStack yystack = new YYStack(); int yynerrs_ = 0; Location yyerrloc = null; Location yylloc = new Location(null, null); Object yylval = null; yycdebug("Starting parse\n"); this.yyerrstatus_ = 0; yystack.push(yystate, yylval, yylloc); int label = 4; while (true) { Location yyloc; switch (label) { case 4: yycdebug("Entering state " + yystate + "\n"); if (this.yydebug > 0)
/*      */             yystack.print(this.yyDebugStream);  if (yystate == 21)
/*      */             return true;  yyn = yypact_[yystate]; if (yyn == -71) { label = 5; continue; }  if (yychar == -2) { yycdebug("Reading a token: "); yychar = yylex(); yylloc = new Location(this.yylexer.getStartPos(), this.yylexer.getEndPos()); yylval = this.yylexer.getLVal(); }  if (yychar <= 0) { yychar = yytoken = 0; yycdebug("Now at end of input.\n"); } else { yytoken = yytranslate_(yychar); yy_symbol_print("Next token is", yytoken, yylval, yylloc); }  yyn += yytoken; if (yyn < 0 || 490 < yyn || yycheck_[yyn] != yytoken) { label = 5; continue; }  if ((yyn = yytable_[yyn]) <= 0) { if (yyn == 0 || yyn == -7) { label = 3; continue; }  yyn = -yyn; label = 6; continue; }  yy_symbol_print("Shifting", yytoken, yylval, yylloc); yychar = -2; if (this.yyerrstatus_ > 0)
/*      */             this.yyerrstatus_--;  yystate = yyn; yystack.push(yystate, yylval, yylloc); label = 4;case 5: yyn = yydefact_[yystate]; if (yyn == 0) { label = 3; continue; }  label = 6;case 6: yylen = yyr2_[yyn]; label = yyaction(yyn, yystack, yylen); yystate = yystack.stateAt(0);case 3: if (this.yyerrstatus_ == 0) { yynerrs_++; yyerror(yylloc, yysyntax_error(yystate, yytoken)); }  yyerrloc = yylloc; if (this.yyerrstatus_ == 3)
/*      */             if (yychar <= 0) { if (yychar == 0)
/*      */                 return false;  } else { yychar = -2; }   label = 7;case 2: yyerrloc = yystack.locationAt(yylen - 1); yystack.pop(yylen); yylen = 0; yystate = yystack.stateAt(0); label = 7;case 7: this.yyerrstatus_ = 3; while (true) { yyn = yypact_[yystate]; if (yyn != -71) { yyn++; if (0 <= yyn && yyn <= 490 && yycheck_[yyn] == 1) { yyn = yytable_[yyn]; if (0 < yyn)
/*      */                   break;  }  }  if (yystack.height == 1)
/*      */               return false;  yyerrloc = yystack.locationAt(0); yystack.pop(); yystate = yystack.stateAt(0); if (this.yydebug > 0)
/*      */               yystack.print(this.yyDebugStream);  }  yystack.push(0, null, yylloc); yystack.push(0, null, yyerrloc); yyloc = yylloc(yystack, 2); yystack.pop(2); yy_symbol_print("Shifting", yystos_[yyn], yylval, yyloc); yystate = yyn; yystack.push(yyn, yylval, yyloc); label = 4;case 0: return true;case 1: break; }  }  return false; }
/*      */   private String yysyntax_error(int yystate, int tok) { if (this.errorVerbose) { int yyn = yypact_[yystate]; if (-71 < yyn && yyn <= 490) { int yyxbegin = (yyn < 0) ? -yyn : 0; int yychecklim = 490 - yyn + 1; int yyxend = (yychecklim < 36) ? yychecklim : 36; int count = 0; int x; for (x = yyxbegin; x < yyxend; x++) { if (yycheck_[x + yyn] == x && x != 1)
/*      */             count++;  }  StringBuffer res = new StringBuffer("syntax error, unexpected "); res.append(yytname_rr_(yytname__[tok])); if (count < 5) { count = 0; for (x = yyxbegin; x < yyxend; x++) { if (yycheck_[x + yyn] == x && x != 1) { res.append((count++ == 0) ? ", expecting " : " or "); res.append(yytname_rr_(yytname__[x])); }  }  }  return res.toString(); }  }  return "syntax error"; }
/*  221 */   private Location yylloc(YYStack rhs, int n) { if (n > 0) {
/*  222 */       return new Location((rhs.locationAt(1)).begin, (rhs.locationAt(n)).end);
/*      */     }
/*  224 */     return new Location((rhs.locationAt(0)).end); }
/*      */   private static final short[] yypact_ = new short[] { 19, -71, 462, -71, 2, 462, -71, -71, -71, -71, -71, -71, -71, -71, -71, -71, 8, 412, -71, 14, 382, -71, -71, -71, -9, -71, -9, -71, -9, -71, -1, -71, -71, -9, 462, 4, -71, -71, -71, 382, -71, -71, -71, -71, -71, -71, -71, -71, -71, -71, -71, -71, -71, -71, -71, -71, -71, 117, 324, -71, -71, -71, -71, -71, -71, -71, -13, -71, 382, -71, -2, -71, 437, -71, -71, -71, -1, -71, -71, 5, -71, -9, -71, -71, 3, -9, -71, 382, 146, -71, 175, -71, -71, -71, 204, 6, -71, -71, -71, -2, -71, -71, -71, -71, -71, -71, -71, -71, 353, -71, 88, -71, -71, 233, -71, -71, -71, 262, -71, -71, -71, -71, -71, -71, 291, -71 };
/*      */   private static final byte[] yydefact_ = new byte[] { 0, 4, 0, 59, 0, 0, 59, 60, 63, 59, 62, 63, 67, 59, 19, 18, 0, 0, 7, 0, 0, 1, 20, 12, 0, 11, 0, 9, 0, 59, 0, 10, 13, 0, 0, 0, 2, 8, 3, 0, 60, 62, 59, 63, 62, 44, 66, 67, 59, 64, 59, 59, 23, 24, 25, 26, 27, 0, 0, 21, 29, 28, 46, 51, 54, 14, 0, 61, 0, 16, 0, 50, 0, 58, 30, 38, 0, 31, 41, 59, 34, 0, 35, 59, 42, 0, 59, 0, 0, 69, 0, 22, 48, 47, 0, 0, 17, 15, 39, 0, 36, 59, 49, 32, 65, 43, 55, 59, 0, 71, 0, 68, 53, 0, 73, 40, 37, 0, 33, 45, 72, 70, 52, 57, 0, 56 };
/*      */   private static final byte[] yypgoto_ = new byte[] { -71, -71, -71, -71, 9, 1, -49, -36, -71, -8, -70, -71, 10, 11, -55, -7, -71, -71, -5, -3, -71, -71, -17, -71, -71, -71, -71, -71, -19, -51 };
/*      */   private static final byte[] yydefgoto_ = new byte[] { -1, 4, 19, 16, 17, 18, 58, 59, 60, 23, 65, 80, 32, 25, 69, 27, 84, 105, 34, 24, 26, 94, 30, 28, 85, 117, 81, 33, 61, 70 };
/*      */   private static final byte yytable_ninf_ = -7;
/*      */   private static final byte[] yytable_ = new byte[] { 20, 29, 21, 74, 31, 62, 22, 63, 90, 64, 35, 36, 92, 103, 71, 96, 107, 38, 37, 57, 1, 98, 91, 57, 76, 99, 66, 79, 101, 73, 67, 67, 95, 68, 77, 104, 78, 118, 108, 68, 83, 114, 86, 72, 115, 113, 87, 93, 35, 2, 3, 75, 74, 0, 91, 0, 0, 82, 0, 0, 0, 0, 102, 0, 0, 0, 106, 0, 124, 0, 0, 100, 91, 37, 74, 0, 0, 91, 0, 0, 66, 0, 0, 66, 0, 0, 0, 0, 91, 39, 0, 120, 0, 116, 0, 0, 0, 40, 41, 0, 42, 43, 44, 45, 66, 46, 47, 0, 48, 49, 50, 51, 0, 52, 53, 54, 55, 56, 88, 0, 57, 121, 0, 0, 0, 0, 40, 41, 0, 42, 43, 44, 45, 0, 46, 47, 0, 48, 49, 50, 51, 0, 52, 53, 54, 55, 56, 39, 0, 57, 89, 0, 0, 0, 0, 40, 41, 0, 42, 43, 44, 45, 0, 46, 47, 0, 48, 49, 50, 51, 0, 52, 53, 54, 55, 56, 110, 0, 57, 109, 0, 0, 0, 0, 40, 41, 0, 42, 43, 44, 45, 0, 46, 47, 0, 48, 49, 50, 51, 0, 52, 53, 54, 55, 56, 39, 0, 57, 111, 0, 0, 0, 0, 40, 41, 0, 42, 43, 44, 45, 0, 46, 47, 0, 48, 49, 50, 51, 0, 52, 53, 54, 55, 56, 39, 0, 57, 112, 0, 0, 0, 0, 40, 41, 0, 42, 43, 44, 45, 0, 46, 47, 0, 48, 49, 50, 51, 0, 52, 53, 54, 55, 56, 39, 0, 57, 122, 0, 0, 0, 0, 40, 41, 0, 42, 43, 44, 45, 0, 46, 47, 0, 48, 49, 50, 51, 0, 52, 53, 54, 55, 56, 39, 0, 57, 123, 0, 0, 0, 0, 40, 41, 0, 42, 43, 44, 45, 0, 46, 47, 0, 48, 49, 50, 51, 0, 52, 53, 54, 55, 56, 0, 0, 57, 125, 39, 0, -5, 0, 0, 0, 0, 0, 40, 41, 0, 42, 43, 44, 45, 0, 46, 47, 0, 48, 49, 50, 51, 0, 52, 53, 54, 55, 56, 39, 0, 57, 0, 0, 0, 0, 0, 40, 41, 0, 42, 43, 44, 45, 0, 46, 47, 0, 48, 49, 50, 51, 119, 52, 53, 54, 55, 56, 39, 0, 57, 0, 0, 0, 0, 0, 40, 41, 0, 42, 43, 44, 45, 0, 46, 47, 0, 48, 49, 50, 51, 0, 52, 53, 54, 55, 56, 0, 5, 57, -6, 0, 6, 7, 8, 9, 0, 10, 11, 0, 0, 0, 0, 12, 0, 0, 0, 0, 0, 0, 13, 0, 14, 5, 0, 15, 0, 6, 7, 8, 9, 0, 10, 11, 0, 0, 0, 0, 12, 0, 0, 0, 0, 0, 0, 13, 97, 14, 5, 0, 15, 0, 6, 7, 8, 9, 0, 10, 11, 0, 0, 0, 0, 12, 0, 0, 0, 0, 0, 0, 13, 0, 14, 0, 0, 15 };
/*      */   private static final byte[] yycheck_ = new byte[] { 3, 9, 0, 39, 11, 24, 5, 26, 57, 28, 13, 3, 25, 83, 33, 70, 86, 3, 17, 32, 1, 76, 58, 32, 41, 76, 29, 44, 79, 25, 32, 32, 68, 34, 42, 32, 43, 107, 87, 34, 48, 35, 50, 34, 99, 94, 51, 66, 51, 30, 31, 40, 88, -1, 90, -1, -1, 47, -1, -1, -1, -1, 81, -1, -1, -1, 85, -1, 117, -1, -1, 79, 108, 72, 110, -1, -1, 113, -1, -1, 83, -1, -1, 86, -1, -1, -1, -1, 124, 1, -1, 3, -1, 101, -1, -1, -1, 9, 10, -1, 12, 13, 14, 15, 107, 17, 18, -1, 20, 21, 22, 23, -1, 25, 26, 27, 28, 29, 1, -1, 32, 33, -1, -1, -1, -1, 9, 10, -1, 12, 13, 14, 15, -1, 17, 18, -1, 20, 21, 22, 23, -1, 25, 26, 27, 28, 29, 1, -1, 32, 33, -1, -1, -1, -1, 9, 10, -1, 12, 13, 14, 15, -1, 17, 18, -1, 20, 21, 22, 23, -1, 25, 26, 27, 28, 29, 1, -1, 32, 33, -1, -1, -1, -1, 9, 10, -1, 12, 13, 14, 15, -1, 17, 18, -1, 20, 21, 22, 23, -1, 25, 26, 27, 28, 29, 1, -1, 32, 33, -1, -1, -1, -1, 9, 10, -1, 12, 13, 14, 15, -1, 17, 18, -1, 20, 21, 22, 23, -1, 25, 26, 27, 28, 29, 1, -1, 32, 33, -1, -1, -1, -1, 9, 10, -1, 12, 13, 14, 15, -1, 17, 18, -1, 20, 21, 22, 23, -1, 25, 26, 27, 28, 29, 1, -1, 32, 33, -1, -1, -1, -1, 9, 10, -1, 12, 13, 14, 15, -1, 17, 18, -1, 20, 21, 22, 23, -1, 25, 26, 27, 28, 29, 1, -1, 32, 33, -1, -1, -1, -1, 9, 10, -1, 12, 13, 14, 15, -1, 17, 18, -1, 20, 21, 22, 23, -1, 25, 26, 27, 28, 29, -1, -1, 32, 33, 1, -1, 3, -1, -1, -1, -1, -1, 9, 10, -1, 12, 13, 14, 15, -1, 17, 18, -1, 20, 21, 22, 23, -1, 25, 26, 27, 28, 29, 1, -1, 32, -1, -1, -1, -1, -1, 9, 10, -1, 12, 13, 14, 15, -1, 17, 18, -1, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 1, -1, 32, -1, -1, -1, -1, -1, 9, 10, -1, 12, 13, 14, 15, -1, 17, 18, -1, 20, 21, 22, 23, -1, 25, 26, 27, 28, 29, -1, 1, 32, 3, -1, 5, 6, 7, 8, -1, 10, 11, -1, -1, -1, -1, 16, -1, -1, -1, -1, -1, -1, 23, -1, 25, 1, -1, 28, -1, 5, 6, 7, 8, -1, 10, 11, -1, -1, -1, -1, 16, -1, -1, -1, -1, -1, -1, 23, 24, 25, 1, -1, 28, -1, 5, 6, 7, 8, -1, 10, 11, -1, -1, -1, -1, 16, -1, -1, -1, -1, -1, -1, 23, -1, 25, -1, -1, 28 };
/*      */   private static final byte[] yystos_ = new byte[] { 0, 1, 30, 31, 37, 1, 5, 6, 7, 8, 10, 11, 16, 23, 25, 28, 39, 40, 41, 38, 55, 0, 41, 45, 55, 49, 56, 51, 59, 45, 58, 51, 48, 63, 54, 55, 3, 41, 3, 1, 9, 10, 12, 13, 14, 15, 17, 18, 20, 21, 22, 23, 25, 26, 27, 28, 29, 32, 42, 43, 44, 64, 64, 64, 64, 46, 55, 32, 34, 50, 65, 64, 40, 25, 43, 49, 58, 45, 51, 58, 47, 62, 48, 45, 52, 60, 45, 54, 1, 33, 42, 43, 25, 64, 57, 43, 50, 24, 50, 65, 45, 65, 64, 46, 32, 53, 64, 46, 42, 33, 1, 33, 33, 42, 35, 50, 45, 61, 46, 24, 3, 33, 33, 33, 42, 33 }; private static final short[] yytoken_number_ = new short[] { 0, 256, 257, 258, 259, 260, 261, 262, 263, 264, 265, 266, 267, 268, 269, 270, 271, 272, 273, 274, 275, 276, 277, 278, 279, 280, 281, 282, 283, 284, 285, 286, 123, 125, 91, 93 }; private static final byte[] yyr1_ = new byte[] { 0, 36, 37, 37, 37, 38, 39, 40, 40, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 42, 42, 43, 43, 43, 43, 43, 43, 43, 43, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 45, 46, 46, 47, 48, 49, 50, 50, 51, 52, 53, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 64, 64, 64, 64, 65 }; private static final byte[] yyr2_ = new byte[] { 0, 2, 3, 3, 1, 2, 1, 1, 2, 2, 2, 2, 2, 2, 3, 4, 3, 4, 1, 1, 2, 1, 2, 1, 1, 1, 1, 1, 1, 1, 2, 2, 3, 4, 2, 2, 3, 4, 2, 3, 4, 2, 2, 3, 1, 4, 2, 2, 2, 2, 2, 2, 4, 3, 2, 2, 4, 3, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 2, 4, 3, 4, 3 }; private static final String[] yytname__ = new String[] { "$end", "error", "$undefined", "END_OF_INPUT", "ERROR", "SECTIONHEADER", "RSECTIONHEADER", "VSECTIONHEADER", "SECTIONHEADER2", "RCODEMACRO", "SEXPR", "RDOPTS", "LATEXMACRO", "VERBMACRO", "OPTMACRO", "ESCAPE", "LISTSECTION", "ITEMIZE", "DESCRIPTION", "NOITEM", "LATEXMACRO2", "VERBMACRO2", "LATEXMACRO3", "IFDEF", "ENDIF", "TEXT", "RCODE", "VERB", "COMMENT", "UNKNOWN", "STARTFILE", "STARTFRAGMENT", "'{'", "'}'", "'['", "']'", "$accept", "Init", "RdFragment", "RdFile", "SectionList", "Section", "ArgItems", "Item", "Markup", "LatexArg", "LatexArg2", "Item0Arg", "Item2Arg", "RLikeArg", "RLikeArg2", "VerbatimArg", "VerbatimArg1", "VerbatimArg2", "IfDefTarget", "goLatexLike", "goRLike", "goRLike2", "goOption", "goVerbatim", "goVerbatim1", "goVerbatim2", "goItem0", "goItem2", "Arg", "Option", null }; private static final byte[] yyrhs_ = new byte[] { 37, 0, -1, 30, 39, 3, -1, 31, 38, 3, -1, 1, -1, 55, 42, -1, 40, -1, 41, -1, 40, 41, -1, 7, 51, -1, 11, 51, -1, 6, 49, -1, 5, 45, -1, 16, 48, -1, 8, 45, 46, -1, 23, 54, 40, 24, -1, 10, 58, 50, -1, 10, 58, 65, 50, -1, 28, -1, 25, -1, 1, 41, -1, 43, -1, 42, 43, -1, 25, -1, 26, -1, 27, -1, 28, -1, 29, -1, 64, -1, 44, -1, 1, 43, -1, 12, 45, -1, 20, 45, 46, -1, 22, 45, 46, 46, -1, 17, 47, -1, 18, 48, -1, 14, 58, 45, -1, 14, 58, 65, 45, -1, 9, 49, -1, 10, 58, 50, -1, 10, 58, 65, 50, -1, 13, 51, -1, 21, 52, -1, 21, 52, 53, -1, 15, -1, 23, 54, 42, 24, -1, 55, 64, -1, 55, 64, -1, 55, 25, -1, 62, 64, -1, 63, 64, -1, 56, 64, -1, 32, 57, 42, 33, -1, 32, 57, 33, -1, 59, 64, -1, 60, 64, -1, 32, 61, 42, 33, -1, 32, 
/*      */       61, 33, -1, 55, 25, -1, -1, -1, -1, -1, 
/*      */       -1, -1, -1, -1, -1, 32, 42, 33, -1, 32, 
/*      */       33, -1, 32, 42, 1, 33, -1, 32, 1, 33, 
/*      */       -1, 32, 42, 1, 3, -1, 34, 43, 35, -1 }; private static final short[] yyprhs_ = new short[] { 
/*      */       0, 0, 3, 7, 11, 13, 16, 18, 20, 23, 
/*      */       26, 29, 32, 35, 38, 42, 47, 51, 56, 58, 
/*      */       60, 63, 65, 68, 70, 72, 74, 76, 78, 80, 
/*      */       82, 85, 88, 92, 97, 100, 103, 107, 112, 115, 
/*      */       119, 124, 127, 130, 134, 136, 141, 144, 147, 150, 
/*      */       153, 156, 159, 164, 168, 171, 174, 179, 183, 186, 
/*      */       187, 188, 189, 190, 191, 192, 193, 194, 195, 199, 
/*      */       202, 207, 211, 216 }; private static final short[] yyrline_ = new short[] { 
/*      */       0, 181, 181, 182, 183, 186, 189, 192, 193, 195, 
/*      */       196, 197, 198, 199, 200, 201, 202, 203, 204, 205, 
/*      */       206, 208, 209, 211, 212, 213, 214, 215, 216, 217, 
/*      */       218, 220, 221, 222, 223, 224, 225, 226, 227, 228, 
/*      */       229, 230, 231, 232, 233, 234, 236, 238, 239, 248, 
/*      */       250, 252, 256, 257, 259, 261, 265, 266, 268, 271, 
/*      */       273, 275, 277, 279, 281, 283, 285, 287, 289, 290, 
/*      */       291, 292, 293, 295 }; private void yy_reduce_print(int yyrule, YYStack yystack) { if (this.yydebug == 0) return;  int yylno = yyrline_[yyrule]; int yynrhs = yyr2_[yyrule]; yycdebug("Reducing stack by rule " + (yyrule - 1) + " (line " + yylno + "), "); for (int yyi = 0; yyi < yynrhs; yyi++) yy_symbol_print("   $" + (yyi + 1) + " =", yyrhs_[yyprhs_[yyrule] + yyi], yystack.valueAt(yynrhs - yyi + 1), yystack.locationAt(yynrhs - yyi + 1));  } private static final byte[] yytranslate_table_ = new byte[] { 
/*      */       0, 2, 2, 2, 2, 2, 2, 2, 2, 2, 
/*      */       2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 
/*      */       2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 
/*      */       2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 
/*      */       2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 
/*      */       2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 
/*      */       2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 
/*      */       2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 
/*      */       2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 
/*      */       2, 34, 2, 35, 2, 2, 2, 2, 2, 2, 
/*      */       2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 
/*      */       2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 
/*      */       2, 2, 2, 32, 2, 33, 2, 2, 2, 2, 
/*      */       2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 
/*      */       2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 
/*      */       2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 
/*      */       2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 
/*      */       2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 
/*      */       2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 
/*      */       2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 
/*      */       2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 
/*      */       2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 
/*      */       2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 
/*      */       2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 
/*      */       2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 
/*      */       2, 2, 2, 2, 2, 2, 1, 2, 3, 4, 
/*      */       5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 
/*      */       15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 
/*  281 */       25, 26, 27, 28, 29, 30, 31 }; private static final int yylast_ = 490; private static final int yynnts_ = 30; private static final int yyempty_ = -2; private static final int yyfinal_ = 21; private static final int yyterror_ = 1; private static final int yyerrcode_ = 256; private static final int yyntokens_ = 36; private static final int yyuser_token_number_max_ = 286; private static final int yyundef_token_ = 2; private static final boolean DEBUGVALS = false; private static final boolean DEBUGMODE = false; private boolean wCalls; private int YYERROR_VERBOSE; private static final char LBRACE = '{'; private static final char RBRACE = '}'; private static final int STATIC = 0; private static final int HAS_IFDEF = 1; private static final int HAS_SEXPR = 2; private static final int RLIKE = 1; private static final int LATEXLIKE = 2; private static final int VERBATIM = 3; private static final int INOPTION = 4; private static final int COMMENTMODE = 5; private static final int UNKNOWNMODE = 6; private static final int PARSE_CONTEXT_SIZE = 32; private SEXP SrcFile; private int xxinRString; private int xxQuoteLine; private int xxQuoteCol; private boolean xxinEqn; private boolean xxNewlineInString; private int xxlineno; private int xxbyteno; private int xxcolno; private int xxmode; private int xxitemType; private int xxbraceDepth; private boolean xxDebugTokens; private String xxBasename; private SEXP Value; private int xxinitvalue; private String yyunknown; private int PUSHBACK_BUFSIZE; private int[] pushback; private int npush; private int prevpos; private int[] prevlines; private int[] prevcols; private int[] prevbytes; private int R_ParseContextLine; private ParseStatus status; private int R_ParseContextLast; private int[] R_ParseContext; private Reader con_parse; private Keyword[] keywords; private static final int DIRECTIVE_LEN = 7; String[] yytname__translations; public static final int INITBUFSIZE = 128; private Location yylloc; private SEXP yylval; private static final int R_EOF = -1; private static final byte yytranslate_(int t) { if (t >= 0 && t <= 286) return yytranslate_table_[t];  return 2; } private SEXP xxpushMode(int newmode, int newitem, boolean neweqn) { IntArrayVector.Builder ans = new IntArrayVector.Builder(); ans.add(this.xxmode); ans.add(this.xxitemType); ans.add(this.xxbraceDepth); ans.add(this.xxinRString); ans.add(this.xxQuoteLine); ans.add(this.xxQuoteCol); ans.add(this.xxinEqn ? 1 : 0); this.xxmode = newmode; this.xxitemType = newitem; this.xxbraceDepth = 0; this.xxinRString = 0; this.xxinEqn = neweqn; return (SEXP)ans.build(); } void xxpopMode(SEXP oldmodeExp) { IntVector oldmode = (IntVector)oldmodeExp; this.xxmode = oldmode.getElementAsInt(0); this.xxitemType = oldmode.getElementAsInt(1); this.xxbraceDepth = oldmode.getElementAsInt(2); this.xxinRString = oldmode.getElementAsInt(3); this.xxQuoteLine = oldmode.getElementAsInt(4); this.xxQuoteCol = oldmode.getElementAsInt(5); this.xxinEqn = (oldmode.getElementAsInt(6) != 0); } private int getDynamicFlag(SEXP item) { SEXP flag = CDefines.getAttrib(item, CDefines.install("dynamicFlag")); if (CDefines.isNull(flag)) return 0;  return ((IntVector)flag).getElementAsInt(0); } private void setDynamicFlag(ListVector.Builder item, int flag) { if (flag != 0) CDefines.setAttrib((SEXPBuilder)item, Symbol.get("dynamicFlag"), (SEXP)new IntArrayVector(new int[] { flag }));  } private SEXP setDynamicFlag(SEXP item, int flag) { if (flag != 0) return item.setAttribute(Symbol.get("dynamicFlag"), (SEXP)new IntArrayVector(new int[] { flag }));  return item; } private SEXP xxnewlist(SEXP item) { SEXP ans, tmp; CDefines.PROTECT(tmp = NewList()); if (item != null) { int flag = getDynamicFlag(item); CDefines.PROTECT(ans = GrowList(tmp, item)); ans = setDynamicFlag(ans, flag); CDefines.UNPROTECT_PTR(tmp); CDefines.UNPROTECT_PTR(item); } else { ans = tmp; }  return ans; } public RdParser() { this.yyDebugStream = System.err;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  295 */     this.yydebug = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  428 */     this.yyerrstatus_ = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1854 */     this.wCalls = true;
/*      */     
/* 1856 */     this.YYERROR_VERBOSE = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1902 */     this.xxDebugTokens = false;
/*      */ 
/*      */ 
/*      */     
/* 1906 */     this.yyunknown = "unknown macro";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2183 */     this.PUSHBACK_BUFSIZE = 30;
/*      */     
/* 2185 */     this.pushback = new int[this.PUSHBACK_BUFSIZE];
/* 2186 */     this.npush = 0;
/*      */     
/* 2188 */     this.prevpos = 0;
/* 2189 */     this.prevlines = new int[this.PUSHBACK_BUFSIZE];
/* 2190 */     this.prevcols = new int[this.PUSHBACK_BUFSIZE];
/* 2191 */     this.prevbytes = new int[this.PUSHBACK_BUFSIZE];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2322 */     this.R_ParseContext = new int[32];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2416 */     this.keywords = new Keyword[] { new Keyword("\\author", 260), new Keyword("\\concept", 260), new Keyword("\\description", 260), new Keyword("\\details", 260), new Keyword("\\docType", 260), new Keyword("\\encoding", 260), new Keyword("\\format", 260), new Keyword("\\keyword", 260), new Keyword("\\note", 260), new Keyword("\\references", 260), new Keyword("\\section", 263), new Keyword("\\seealso", 260), new Keyword("\\source", 260), new Keyword("\\title", 260), new Keyword("\\examples", 261), new Keyword("\\usage", 261), new Keyword("\\alias", 262), new Keyword("\\name", 262), new Keyword("\\synopsis", 262), new Keyword("\\Rdversion", 262), new Keyword("\\cr", 270), new Keyword("\\dots", 270), new Keyword("\\ldots", 270), new Keyword("\\R", 270), new Keyword("\\tab", 270), new Keyword("\\acronym", 267), new Keyword("\\bold", 267), new Keyword("\\cite", 267), new Keyword("\\command", 267), new Keyword("\\dfn", 267), new Keyword("\\dQuote", 267), new Keyword("\\email", 267), new Keyword("\\emph", 267), new Keyword("\\file", 267), new Keyword("\\linkS4class", 267), new Keyword("\\pkg", 267), new Keyword("\\sQuote", 267), new Keyword("\\strong", 267), new Keyword("\\var", 267), new Keyword("\\arguments", 271), new Keyword("\\value", 271), new Keyword("\\describe", 273), new Keyword("\\enumerate", 272), new Keyword("\\itemize", 272), new Keyword("\\item", 274), new Keyword("\\enc", 275), new Keyword("\\if", 275), new Keyword("\\method", 275), new Keyword("\\S3method", 275), new Keyword("\\S4method", 275), new Keyword("\\tabular", 275), new Keyword("\\ifelse", 277), new Keyword("\\link", 269), new Keyword("\\code", 264), new Keyword("\\dontshow", 264), new Keyword("\\donttest", 264), new Keyword("\\testonly", 264), new Keyword("\\Sexpr", 265), new Keyword("\\RdOpts", 266), new Keyword("\\dontrun", 268), new Keyword("\\env", 268), new Keyword("\\kbd", 268), new Keyword("\\option", 268), new Keyword("\\out", 268), new Keyword("\\preformatted", 268), new Keyword("\\samp", 268), new Keyword("\\special", 268), new Keyword("\\url", 268), new Keyword("\\verb", 268), new Keyword("\\eqn", 276), new Keyword("\\deqn", 276), new Keyword("#ifdef", 278), new Keyword("#ifndef", 278), new Keyword("}", 279) };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2561 */     this.yytname__translations = new String[] { "$undefined", "input", "SECTIONHEADER", "section header", "RSECTIONHEADER", "section header", "VSECTIONHEADER", "section header", "LISTSECTION", "section header", "LATEXMACRO", "macro", "LATEXMACRO2", "macro", "LATEXMACRO3", "macro", "RCODEMACRO", "macro", "VERBMACRO", "macro", "VERBMACRO2", "macro", "ESCAPE", "macro", "ITEMIZE", "macro", "IFDEF", "conditional", "SECTIONHEADER2", "section header", "OPTMACRO", "macro", "DESCRIPTION", "macro", "VERB", "VERBATIM TEXT" };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2932 */     this.yylloc = new Location(new Position()); this.yylexer = new RdLexer(); }
/*      */   private SEXP xxlist(SEXP oldlist, SEXP item) { int flag = getDynamicFlag(oldlist) | getDynamicFlag(item); SEXP ans; CDefines.PROTECT(ans = GrowList(oldlist, item)); CDefines.UNPROTECT_PTR(item); CDefines.UNPROTECT_PTR(oldlist); setDynamicFlag(ans, flag); return ans; }
/*      */   private SEXP xxmarkup(SEXP header, SEXP body, int flag, Location lloc) { StringArrayVector stringArrayVector; if (CDefines.isNull(body)) { ListVector listVector = new ListVector(new SEXP[0]); } else { flag |= getDynamicFlag(body); CDefines.PROTECT(ans = PairToVectorList(CDefines.CDR(body))); CDefines.UNPROTECT_PTR(body); }  if (CDefines.isNull(header)) CDefines.PROTECT(stringArrayVector = new StringArrayVector(new String[] { "LIST" }));  SEXP ans = ans.setAttribute(CDefines.install("Rd_tag"), (SEXP)stringArrayVector); ans = ans.setAttribute(Symbols.SRC_REF, makeSrcref(lloc, this.SrcFile)); ans = setDynamicFlag(ans, flag); return ans; }
/*      */   private SEXP xxOptionmarkup(SEXP header, SEXP option, SEXP body, int flag, Location lloc) { flag |= getDynamicFlag(body); SEXP ans; CDefines.PROTECT(ans = PairToVectorList(CDefines.CDR(body))); CDefines.UNPROTECT_PTR(body); ans = setAttrib(ans, CDefines.install("Rd_tag"), header); CDefines.UNPROTECT_PTR(header); flag |= getDynamicFlag(option); ans = setAttrib(ans, CDefines.install("Rd_option"), option); CDefines.UNPROTECT_PTR(option); ans = setAttrib(ans, Symbols.SRC_REF, makeSrcref(lloc, this.SrcFile)); ans = setDynamicFlag(ans, flag); return ans; }
/*      */   private SEXP setAttrib(SEXP ans, Symbol install, SEXP header) { return ans.setAttribute(install, header); }
/*      */   private SEXP xxmarkup2(SEXP header, SEXP body1, SEXP body2, int argcount, int flag, Location lloc) { ListVector.Builder ans = new ListVector.Builder(); if (!CDefines.isNull(body1)) { int flag1 = getDynamicFlag(body1); ans.set(0, setDynamicFlag(PairToVectorList(CDefines.CDR(body1)), flag1)); flag |= flag1; }  if (!CDefines.isNull(body2)) { if (argcount < 2) CDefines.error("internal error: inconsistent argument count", new Object[0]);  int flag2 = getDynamicFlag(body2); ans.set(1, setDynamicFlag(PairToVectorList(CDefines.CDR(body2)), flag2)); flag |= flag2; }  ans.setAttribute(CDefines.install("Rd_tag"), header); ans.setAttribute(Symbols.SRC_REF, makeSrcref(lloc, this.SrcFile)); setDynamicFlag(ans, flag); return (SEXP)ans.build(); }
/*      */   private SEXP xxmarkup3(SEXP header, SEXP body1, SEXP body2, SEXP body3, int flag, Location lloc) { ListVector.Builder ans = new ListVector.Builder(3); if (!CDefines.isNull(body1)) { int flag1 = getDynamicFlag(body1); ans.set(0, setDynamicFlag(PairToVectorList(CDefines.CDR(body1)), flag1)); flag |= flag1; }  if (!CDefines.isNull(body2)) { int flag2 = getDynamicFlag(body2); ans.set(1, setDynamicFlag(PairToVectorList(CDefines.CDR(body2)), flag2)); flag |= flag2; }  if (!CDefines.isNull(body3)) { int flag3 = getDynamicFlag(body3); ans.set(2, setDynamicFlag(PairToVectorList(CDefines.CDR(body3)), flag3)); flag |= flag3; }  ans.setAttribute(CDefines.install("Rd_tag"), header); ans.setAttribute(Symbols.SRC_REF, makeSrcref(lloc, this.SrcFile)); setDynamicFlag(ans, flag); return (SEXP)ans.build(); }
/*      */   private SEXP PairToVectorList(SEXP exp) { PairList pairList = (PairList)exp; return (SEXP)pairList.toVector(); }
/*      */   private void xxsavevalue(SEXP Rd, Location lloc) { int flag = getDynamicFlag(Rd); if (CDefines.CDR(Rd).length() == 0) { this.Value = (SEXP)Null.INSTANCE; } else { ListVector.NamedBuilder valueBuilder = new ListVector.NamedBuilder(); PairList pairList = (PairList)CDefines.CDR(Rd); for (PairList.Node node : pairList.nodes()) { if (node.hasTag()) { valueBuilder.add(node.getTag().getPrintName(), node.getValue()); continue; }  valueBuilder.add(node.getValue()); }  valueBuilder.setAttribute(Symbols.CLASS, (SEXP)new StringArrayVector(new String[] { "Rd" })); valueBuilder.setAttribute(Symbols.SRC_REF, makeSrcref(lloc, this.SrcFile)); setDynamicFlag((ListVector.Builder)valueBuilder, flag); this.Value = (SEXP)valueBuilder.build(); }  } private SEXP xxtag(SEXP item, int type, Location lloc) { item = setAttrib(item, CDefines.install("Rd_tag"), (SEXP)new StringArrayVector(new String[] { yytname__[yytranslate_(type)] })); item = setAttrib(item, Symbols.SRC_REF, makeSrcref(lloc, this.SrcFile)); return item; } private void xxWarnNewline() { if (this.xxNewlineInString) System.out.println(String.format(CDefines._("newline within quoted string at %s:%d"), new Object[] { this.xxBasename, Boolean.valueOf(this.xxNewlineInString) }));  } private int xxgetc() { int c; if (this.npush != 0) { c = this.pushback[--this.npush]; } else { c = con_getc(); }  this.prevpos = (this.prevpos + 1) % this.PUSHBACK_BUFSIZE; this.prevcols[this.prevpos] = this.xxcolno; this.prevbytes[this.prevpos] = this.xxbyteno; this.prevlines[this.prevpos] = this.xxlineno; if (c == 0) return -1;  this.R_ParseContextLast = (this.R_ParseContextLast + 1) % 32; this.R_ParseContext[this.R_ParseContextLast] = c; if (c == 10) { this.xxlineno++; this.xxcolno = 1; this.xxbyteno = 1; } else { this.xxcolno++; this.xxbyteno++; }  if (c == 9) this.xxcolno = (this.xxcolno + 6 & 0xFFFFFFF8) + 1;  this.R_ParseContextLine = this.xxlineno; return c; } private int xxungetc(int c) { this.xxlineno = this.prevlines[this.prevpos]; this.xxbyteno = this.prevbytes[this.prevpos]; this.xxcolno = this.prevcols[this.prevpos]; this.prevpos = (this.prevpos + this.PUSHBACK_BUFSIZE - 1) % this.PUSHBACK_BUFSIZE; this.R_ParseContextLine = this.xxlineno; this.R_ParseContext[this.R_ParseContextLast] = 0; this.R_ParseContextLast = (this.R_ParseContextLast + 32 - 1) % 32; if (this.npush >= this.PUSHBACK_BUFSIZE - 2) return 0;  this.pushback[this.npush++] = c; return c; } private SEXP makeSrcref(Location lloc, SEXP srcfile) { if (lloc.begin != null && lloc.end != null) { IntArrayVector.Builder val = new IntArrayVector.Builder(); val.add(lloc.begin.getLine()); val.add(lloc.begin.getCharIndex()); val.add(lloc.end.getLine()); val.add(lloc.end.getCharIndex()); val.add(lloc.begin.getColumn()); val.add(lloc.end.getColumn()); val.setAttribute(Symbols.SRC_FILE, srcfile); val.setAttribute(Symbols.CLASS, (SEXP)new StringArrayVector(new String[] { "srcref" })); return (SEXP)val.build(); }  return (SEXP)Null.INSTANCE; } private SEXP NewList() { PairList.Node node = CDefines.CONS((SEXP)CDefines.R_NilValue, (SEXP)CDefines.R_NilValue); CDefines.SETCAR((SEXP)node, (SEXP)node); return (SEXP)node; } private SEXP GrowList(SEXP l, SEXP s) { CDefines.PROTECT(s); PairList.Node node = CDefines.CONS(s, (SEXP)CDefines.R_NilValue); CDefines.UNPROTECT(1); CDefines.SETCDR(CDefines.CAR(l), (SEXP)node); CDefines.SETCAR(l, (SEXP)node); return l; } public enum ParseStatus {
/*      */     PARSE_OK, PARSE_ERR;
/*      */   } private SEXP ParseRd(SEXP srcfile, boolean fragment) throws IOException { this.R_ParseContextLast = 0; this.R_ParseContext[0] = 0; this.xxlineno = 1; this.xxcolno = 1; this.xxbyteno = 1; this.SrcFile = srcfile; this.npush = 0; this.xxmode = 2; this.xxitemType = 284; this.xxbraceDepth = 0; this.xxinRString = 0; this.xxNewlineInString = false; this.xxinEqn = false; if (fragment) { this.xxinitvalue = 286; } else { this.xxinitvalue = 285; }  this.Value = (SEXP)CDefines.R_NilValue; if (parse()) { this.status = ParseStatus.PARSE_ERR; } else { this.status = ParseStatus.PARSE_OK; }  CDefines.UNPROTECT_PTR(this.Value); return this.Value; } private int con_getc() { int last = -1000; try { int c = this.con_parse.read(); if (c == 0 && last != 10) c = 10;  return last = c; } catch (IOException e) { throw new RuntimeException(e); }  } public SEXP R_ParseRd(Reader con, SEXP srcfile, boolean fragment) throws IOException { this.con_parse = con; return ParseRd(srcfile, fragment); } private static class Keyword {
/*      */     public String name; public int token; public Keyword(String name, int token) { this.name = name; this.token = token; }
/* 2944 */   } private int KeywordLookup(String s) { for (int i = 0; i != this.keywords.length; i++) { if ((this.keywords[i]).name.equals(s)) return (this.keywords[i]).token;  }  return 284; } private void setfirstloc() { this.yylloc.begin = new Position(this.xxlineno, this.xxcolno, this.xxbyteno); } private void setlastloc() { this.yylloc.end = new Position(this.prevlines[this.prevpos], this.prevcols[this.prevpos], this.prevbytes[this.prevpos]); } private int mkText(int c) { StringBuilder text = new StringBuilder(); while (true) { int lookahead; switch (c) { case 92: lookahead = xxgetc(); if (lookahead == 123 || lookahead == 125 || lookahead == 37 || lookahead == 92) { c = lookahead; break; }  xxungetc(lookahead); if (Character.isLetter(lookahead)) break; case 93: if (this.xxmode == 4) break;  break;case -1: case 37: case 123: case 125: break; }  text.appendCodePoint(c); if (c == 10) break;  c = xxgetc(); }  if (c != 10) xxungetc(c);  this.yylval = (SEXP)new StringArrayVector(new String[] { correctCrLf(text.toString()) }); return 280; } private String correctCrLf(String s) { return s.replace("\r\n", "\n"); } private int mkComment(int c) { StringBuilder text = new StringBuilder(); do { text.appendCodePoint(c); } while ((c = xxgetc()) != 10 && c != -1); xxungetc(c); this.yylval = (SEXP)new StringArrayVector(new String[] { removeTrailingCR(text.toString()) }); return 283; } private String removeTrailingCR(String string) { if (string.endsWith("\r")) return string.substring(0, string.length() - 1);  return string; } private int mkCode(int c) { StringBuilder text = new StringBuilder(); if (c == 123 && this.xxinRString == 0) this.xxbraceDepth--;  if (c == 125 && this.xxinRString == 0) this.xxbraceDepth++;  while (true) { boolean escaped = false; if (c == 92) { int lookahead = xxgetc(); if (lookahead == 92 || lookahead == 37) { c = lookahead; escaped = true; } else { xxungetc(lookahead); }  }  if ((!escaped && c == 37) || c == -1) break;  if (this.xxinRString != 0) { if (c == 92) { int lookahead = xxgetc(); if (lookahead == 92) { lookahead = xxgetc(); if (lookahead == this.xxinRString || lookahead == 92) { text.appendCodePoint(c); c = lookahead; escaped = true; } else { xxungetc(lookahead); xxungetc(92); }  } else if (lookahead == this.xxinRString) { text.appendCodePoint(c); c = lookahead; escaped = true; } else { if (!escaped && (lookahead == 108 || lookahead == 118)) { xxungetc(lookahead); break; }  xxungetc(lookahead); }  }  if (!escaped && c == this.xxinRString) this.xxinRString = 0;  } else { if (c == 35) { do { escaped = false; text.appendCodePoint(c); c = xxgetc(); if (c == 92) { int lookahead = xxgetc(); if (lookahead == 92 || lookahead == 37 || lookahead == 123 || lookahead == 125) { c = lookahead; escaped = true; } else { xxungetc(lookahead); }  }  if (c == 123 && !escaped) { this.xxbraceDepth++; } else if (c == 125 && !escaped) { this.xxbraceDepth--; }  } while (c != 10 && c != -1 && this.xxbraceDepth > 0); if (c == 125 && !escaped) this.xxbraceDepth++;  }  if (c == 39 || c == 34 || c == 96) { this.xxinRString = c; this.xxQuoteLine = this.xxlineno; this.xxQuoteCol = this.xxcolno; } else if (c == 92 && !escaped) { int lookahead = xxgetc(); if (lookahead == 123 || lookahead == 125) { c = lookahead; } else { if (Character.isLetter(lookahead)) { xxungetc(lookahead); c = 92; break; }  text.append('\\'); c = lookahead; }  } else if (c == 123) { this.xxbraceDepth++; } else if (c == 125) { if (this.xxbraceDepth == 1) break;  this.xxbraceDepth--; } else if (c == -1) { break; }  }  text.appendCodePoint(c); if (c == 10) { if (this.xxinRString != 0 && !this.xxNewlineInString) this.xxNewlineInString = (this.xxlineno - 1 != 0);  break; }  c = xxgetc(); }  if (c != 10) xxungetc(c);  this.yylval = (SEXP)new StringArrayVector(new String[] { correctCrLf(text.toString()) }); return 281; } private int mkMarkup(int c) { StringBuilder text = new StringBuilder(); int retval = 0, attempt = 0; text.appendCodePoint(c); while (isalnum(c = xxgetc())) text.appendCodePoint(c);  while (attempt++ < 2) { if (text.length() == 1) { text.appendCodePoint(c); retval = 280; c = xxgetc(); break; }  retval = KeywordLookup(text.toString()); if (retval == 284 && attempt == 1) { while (isdigit(text.codePointAt(text.length() - 1))) { xxungetc(c); c = text.codePointAt(text.length() - 1); }  continue; }  if (retval == 274) retval = this.xxitemType;  }  CDefines.PROTECT(this.yylval = (SEXP)new StringArrayVector(new String[] { text.toString() })); xxungetc(c); return retval; } private boolean isdigit(int cp) { return Character.isDigit(cp); } private boolean isalnum(int cp) { return (Character.isLetter(cp) || Character.isDigit(cp)); } private int mkIfdef(int c) { StringBuilder text = new StringBuilder(); text.appendCodePoint(c); while (Character.isDigit(c = xxgetc()) && text.length() <= 7) text.appendCodePoint(c);  xxungetc(c); int retval = KeywordLookup(text.toString()); this.yylval = (SEXP)new StringArrayVector(new String[] { text.toString() }); switch (retval) { case 279: do { c = xxgetc(); } while (c != 10 && c != -1); break;case 284: while (text.length() > 1) { xxungetc(text.codePointAt(text.length() - 1)); text.setLength(text.length() - 1); }  switch (this.xxmode) { case 1: retval = mkCode(text.codePointAt(0)); break;case 2: case 4: retval = mkText(text.codePointAt(0)); break;case 3: retval = mkVerb(text.codePointAt(0)); break; }  break; }  return retval; } private int mkVerb(int c) { StringBuilder text = new StringBuilder(); if (c == 123) this.xxbraceDepth--;  if (c == 125) this.xxbraceDepth++;  while (true) { int escaped = 0; if (c == 92) { int lookahead = xxgetc(); if (lookahead == 92 || lookahead == 37 || lookahead == 123 || lookahead == 125) { escaped = 1; if (this.xxinEqn) text.appendCodePoint(c);  c = lookahead; } else { xxungetc(lookahead); }  }  if (c == -1) break;  if (escaped == 0) { if (c == 37 && !this.xxinEqn) break;  if (c == 123) { this.xxbraceDepth++; } else if (c == 125) { if (this.xxbraceDepth == 1) break;  this.xxbraceDepth--; }  }  text.appendCodePoint(c); if (c == 10) break;  c = xxgetc(); }  if (c != 10) xxungetc(c);  this.yylval = (SEXP)new StringArrayVector(new String[] { text.toString() }); return 282; } private class RdLexer implements Lexer { public int yylex() { int tok = token();
/*      */       
/* 2946 */       if (RdParser.this.xxDebugTokens) {
/* 2947 */         RdParser.this.Rprintf("%d:%d: %s", new Object[] { Integer.valueOf((RdParser.access$400(this.this$0)).begin.getLine()), Integer.valueOf((RdParser.access$400(this.this$0)).begin.getColumn()), RdParser.access$500()[RdParser.access$600(tok)] });
/* 2948 */         if (RdParser.this.xxinRString != 0) {
/* 2949 */           RdParser.this.Rprintf("(in %c%c)", new Object[] { Integer.valueOf(RdParser.access$800(this.this$0)), Integer.valueOf(RdParser.access$800(this.this$0)) });
/*      */         }
/* 2951 */         if (tok > 255 && tok != 258) {
/* 2952 */           RdParser.this.Rprintf(": %s", new Object[] { CDefines.CHAR(CDefines.STRING_ELT(RdParser.access$900(this.this$0), 0)) });
/*      */         }
/* 2954 */         RdParser.this.Rprintf("\n", new Object[0]);
/*      */       } 
/* 2956 */       RdParser.this.setlastloc();
/* 2957 */       return tok; }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private RdLexer() {}
/*      */ 
/*      */     
/*      */     private int token() {
/* 2966 */       boolean outsideLiteral = (RdParser.this.xxmode == 2 || RdParser.this.xxmode == 4 || RdParser.this.xxbraceDepth == 0);
/*      */       
/* 2968 */       if (RdParser.this.xxinitvalue != 0) {
/* 2969 */         RdParser.this.yylloc.begin = new Position(0, 0, 0);
/* 2970 */         RdParser.this.yylloc.end = new Position(0, 0, 0);
/* 2971 */         CDefines.PROTECT(RdParser.this.yylval = (SEXP)new StringArrayVector(new String[] { "" }));
/* 2972 */         int i = RdParser.this.xxinitvalue;
/* 2973 */         RdParser.this.xxinitvalue = 0;
/* 2974 */         return i;
/*      */       } 
/*      */       
/* 2977 */       RdParser.this.setfirstloc();
/* 2978 */       int c = RdParser.this.xxgetc();
/*      */       
/* 2980 */       switch (c) { case 37:
/* 2981 */           if (!RdParser.this.xxinEqn) {
/* 2982 */             return RdParser.this.mkComment(c);
/*      */           }
/*      */           break;
/*      */         case 92:
/* 2986 */           if (!RdParser.this.xxinEqn) {
/* 2987 */             int lookahead = RdParser.this.xxungetc(RdParser.this.xxgetc());
/* 2988 */             if (Character.isLetter(lookahead) && RdParser.this.xxmode != 3 && (lookahead == 108 || lookahead == 118 || RdParser.this
/*      */               
/* 2990 */               .xxinRString == 0)) {
/* 2991 */               return RdParser.this.mkMarkup(c);
/*      */             }
/*      */           } 
/*      */           break;
/*      */         case -1:
/* 2996 */           if (RdParser.this.xxinRString != 0) {
/* 2997 */             RdParser.this.xxWarnNewline();
/* 2998 */             CDefines.error(CDefines._("Unexpected end of input (in %c quoted string opened at %s:%d:%d)"), new Object[] {
/* 2999 */                   Integer.valueOf(RdParser.access$800(this.this$0)), RdParser.access$2100(this.this$0), Integer.valueOf(RdParser.access$2200(this.this$0)), Integer.valueOf(RdParser.access$2300(this.this$0)) });
/*      */           } 
/* 3001 */           return 258;
/*      */         case 35:
/* 3003 */           if (!RdParser.this.xxinEqn && RdParser.this.yylloc.begin.getColumn() == 1) {
/* 3004 */             return RdParser.this.mkIfdef(c);
/*      */           }
/*      */           break;
/*      */         case 123:
/* 3008 */           if (RdParser.this.xxinRString == 0) {
/* 3009 */             RdParser.this.xxbraceDepth++;
/* 3010 */             if (outsideLiteral) {
/* 3011 */               return c;
/*      */             }
/*      */           } 
/*      */           break;
/*      */         case 125:
/* 3016 */           if (RdParser.this.xxinRString == 0) {
/* 3017 */             RdParser.this.xxbraceDepth--;
/* 3018 */             if (outsideLiteral || RdParser.this.xxbraceDepth == 0) {
/* 3019 */               return c;
/*      */             }
/*      */           } 
/*      */           break;
/*      */         case 91:
/*      */         case 93:
/* 3025 */           if (RdParser.this.xxmode == 4) {
/* 3026 */             return c;
/*      */           }
/*      */           break; }
/*      */ 
/*      */       
/* 3031 */       switch (RdParser.this.xxmode) { case 1:
/* 3032 */           return RdParser.this.mkCode(c);
/*      */         case 2: case 4:
/* 3034 */           return RdParser.this.mkText(c);
/* 3035 */         case 3: return RdParser.this.mkVerb(c); }
/*      */ 
/*      */       
/* 3038 */       return 259;
/*      */     }
/*      */ 
/*      */     
/*      */     private void yyerror(String s) {
/* 3043 */       throw new RuntimeException(s);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Position getStartPos() {
/* 3124 */       return RdParser.this.yylloc.begin;
/*      */     }
/*      */ 
/*      */     
/*      */     public Position getEndPos() {
/* 3129 */       return RdParser.this.yylloc.end;
/*      */     }
/*      */ 
/*      */     
/*      */     public Object getLVal() {
/* 3134 */       return RdParser.this.yylval;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void yyerror(RdParser.Location loc, String s) {
/* 3140 */       throw new RuntimeException(s);
/*      */     } }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void Rprintf(String message, Object... arguments) {
/* 3147 */     for (int i = 0; i != arguments.length; i++) {
/* 3148 */       if (arguments[i] instanceof SEXP) {
/* 3149 */         arguments[i] = Integer.valueOf(System.identityHashCode(arguments[i]));
/*      */       }
/*      */     } 
/* 3152 */     message = message.replace("%p", "0x%x");
/* 3153 */     System.out.println(String.format(message, arguments));
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/parser/RdParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */