/*     */ package org.renjin.primitives.packaging;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Optional;
/*     */ import org.apache.commons.vfs2.FileObject;
/*     */ import org.apache.commons.vfs2.FileSystemException;
/*     */ import org.renjin.eval.Context;
/*     */ import org.renjin.eval.EvalException;
/*     */ import org.renjin.invoke.annotations.Builtin;
/*     */ import org.renjin.invoke.annotations.Current;
/*     */ import org.renjin.invoke.annotations.Internal;
/*     */ import org.renjin.invoke.annotations.Unevaluated;
/*     */ import org.renjin.primitives.S3;
/*     */ import org.renjin.sexp.AtomicVector;
/*     */ import org.renjin.sexp.Closure;
/*     */ import org.renjin.sexp.Environment;
/*     */ import org.renjin.sexp.Function;
/*     */ import org.renjin.sexp.Null;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.StringArrayVector;
/*     */ import org.renjin.sexp.StringVector;
/*     */ import org.renjin.sexp.Symbol;
/*     */ import org.renjin.sexp.Symbols;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Namespaces
/*     */ {
/*     */   @Internal
/*     */   public static SEXP getRegisteredNamespace(@Current Context context, @Current NamespaceRegistry registry, SEXP nameSexp) {
/*     */     Symbol name;
/*  40 */     if (nameSexp instanceof Symbol) {
/*  41 */       name = (Symbol)nameSexp;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  47 */       if (".GlobalEnv".equals(name.getPrintName())) {
/*  48 */         return (SEXP)Null.INSTANCE;
/*     */       }
/*     */     }
/*  51 */     else if (nameSexp instanceof StringVector) {
/*  52 */       name = Symbol.get(nameSexp.asString());
/*     */     } else {
/*  54 */       throw new EvalException("Illegal type of argument name: '%s'", new Object[] { nameSexp.getTypeName() });
/*     */     } 
/*     */     
/*  57 */     if (registry.isRegistered(name)) {
/*  58 */       return (SEXP)registry.getNamespace(context, name).getNamespaceEnvironment();
/*     */     }
/*  60 */     return (SEXP)Null.INSTANCE;
/*     */   }
/*     */ 
/*     */   
/*     */   @Internal
/*     */   public static Environment getNamespaceRegistry(@Current NamespaceRegistry registry) {
/*  66 */     return Environment.createChildEnvironment((Environment)Environment.EMPTY, new NamespaceFrame(registry)).build();
/*     */   }
/*     */   
/*     */   @Builtin
/*     */   public static SEXP getNamespace(@Current Context context, @Current NamespaceRegistry registry, Symbol name) {
/*  71 */     Namespace namespace = registry.getNamespace(context, name);
/*  72 */     Environment namespaceEnv = namespace.getNamespaceEnvironment();
/*  73 */     return (SEXP)namespaceEnv;
/*     */   }
/*     */   
/*     */   @Builtin
/*     */   public static SEXP getNamespace(@Current Context context, @Current NamespaceRegistry registry, String name) {
/*  78 */     Namespace namespace = registry.getNamespace(context, name);
/*  79 */     return (SEXP)namespace.getNamespaceEnvironment();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Builtin
/*     */   public static boolean isNamespace(@Current NamespaceRegistry registry, SEXP envExp) {
/*  86 */     if (envExp instanceof Environment) {
/*  87 */       return registry.isNamespaceEnv((Environment)envExp);
/*     */     }
/*  89 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   @Builtin
/*     */   public static StringVector loadedNamespaces(@Current NamespaceRegistry registry) {
/*  95 */     StringVector.Builder result = new StringVector.Builder();
/*  96 */     for (Symbol name : registry.getLoadedNamespaceNames()) {
/*  97 */       result.add(name.getPrintName());
/*     */     }
/*  99 */     return (StringVector)result.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Builtin(":::")
/*     */   public static SEXP getNamespaceValue(@Current Context context, @Current NamespaceRegistry registry, @Unevaluated Symbol namespace, @Unevaluated Symbol entry) {
/* 108 */     return registry.getNamespace(context, namespace).getEntry(entry).force(context);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Builtin("::")
/*     */   public static SEXP getExportedNamespaceValue(@Current Context context, @Current NamespaceRegistry registry, @Unevaluated Symbol namespace, @Unevaluated Symbol entry) {
/* 117 */     return registry.getNamespace(context, namespace).getExport(entry).force(context);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Internal
/*     */   public static SEXP getDataset(@Current Context context, @Current NamespaceRegistry registry, String namespaceName, String datasetName) throws IOException {
/* 125 */     return registry.getNamespace(context, namespaceName).getPackage().getDataset(datasetName);
/*     */   }
/*     */ 
/*     */   
/*     */   private static Namespace resolveNamespace(Context context, NamespaceRegistry registry, SEXP sexp) {
/* 130 */     if (sexp instanceof Environment) {
/* 131 */       Environment environment = (Environment)sexp;
/* 132 */       if (registry.isNamespaceEnv(environment)) {
/* 133 */         return registry.getNamespace(environment);
/*     */       }
/* 135 */     } else if (sexp instanceof StringVector && sexp.length() == 1) {
/* 136 */       return registry.getNamespace(context, ((StringVector)sexp).getElementAsString(0));
/*     */     } 
/* 138 */     throw new EvalException("Error in argument " + sexp + " : not a namespace", new Object[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Builtin
/*     */   public static StringVector getNamespaceName(@Current Context context, @Current NamespaceRegistry registry, SEXP envExp) {
/* 146 */     Namespace namespace = resolveNamespace(context, registry, envExp);
/*     */     
/* 148 */     if (namespace == registry.getBaseNamespace())
/*     */     {
/* 150 */       return (StringVector)new StringArrayVector(new String[] { "base" });
/*     */     }
/*     */ 
/*     */     
/* 154 */     StringVector.Builder builder = StringArrayVector.newBuilder();
/* 155 */     builder.add(namespace.getCompatibleName());
/* 156 */     builder.setAttribute(Symbols.NAMES, (SEXP)StringArrayVector.valueOf("name"));
/* 157 */     return (StringVector)builder.build();
/*     */   }
/*     */ 
/*     */   
/*     */   @Builtin
/*     */   public static StringVector getNamespaceExports(@Current Context context, @Current NamespaceRegistry registry, SEXP sexp) {
/* 163 */     Namespace ns = resolveNamespace(context, registry, sexp);
/*     */     
/* 165 */     StringVector.Builder result = new StringVector.Builder();
/* 166 */     for (Symbol name : ns.getExports()) {
/* 167 */       result.add(name.getPrintName());
/*     */     }
/* 169 */     return (StringVector)result.build();
/*     */   }
/*     */ 
/*     */   
/*     */   @Builtin
/*     */   public static StringVector getNamespaceImports(@Current Context context, @Current NamespaceRegistry registry, SEXP sexp) {
/* 175 */     Namespace ns = resolveNamespace(context, registry, sexp);
/* 176 */     throw new UnsupportedOperationException("TODO: implement getNamespaceImports!");
/*     */   }
/*     */   
/*     */   @Internal("find.package")
/*     */   public static StringVector findPackage(@Current Context context, AtomicVector packageNames) throws FileSystemException {
/* 181 */     StringVector.Builder result = new StringVector.Builder();
/* 182 */     for (int i = 0; i < packageNames.length(); i++) {
/* 183 */       String packageName = packageNames.getElementAsString(i);
/* 184 */       Namespace namespace = context.getNamespaceRegistry().getNamespace(context, packageName);
/* 185 */       FileObject fileObject = namespace.getPackage().resolvePackageRoot(context.getFileSystemManager());
/* 186 */       result.add(fileObject.getURL().toString());
/*     */     } 
/* 188 */     return (StringVector)result.build();
/*     */   }
/*     */   @Internal("library.dynam")
/*     */   public static SEXP libraryDynam(@Current Context context, String libraryName, String packageName) {
/*     */     DllInfo dllInfo;
/* 193 */     Namespace namespace = context.getNamespaceRegistry().getNamespace(context, packageName);
/*     */     
/*     */     try {
/* 196 */       dllInfo = namespace.loadDynamicLibrary(context, libraryName);
/* 197 */     } catch (ClassNotFoundException e) {
/*     */       
/* 199 */       context.warn("Could not load the dynamic library: " + e.getMessage());
/* 200 */       return (SEXP)Null.INSTANCE;
/*     */     } 
/*     */     
/* 203 */     return dllInfo.buildDllInfoSexp();
/*     */   }
/*     */   
/*     */   @Internal("library.dynam.unload")
/*     */   public static SEXP libraryDynamUnload(@Current Context context, String name) {
/* 208 */     return (SEXP)Null.INSTANCE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Internal
/*     */   public static void registerS3method(@Current Context context, String genericName, String className, SEXP methodSexp, Environment environment) {
/*     */     Function method;
/* 220 */     Optional<Environment> definitionEnv = resolveGenericFunctionNamespace(context, genericName, environment);
/* 221 */     if (!definitionEnv.isPresent()) {
/* 222 */       throw new EvalException("Cannot find generic function '" + genericName + "'", new Object[0]);
/*     */     }
/*     */ 
/*     */     
/* 226 */     if (methodSexp instanceof Function) {
/* 227 */       method = (Function)methodSexp;
/*     */     }
/* 229 */     else if (methodSexp instanceof StringVector && methodSexp.length() == 1) {
/* 230 */       StringVector methodVector = (StringVector)methodSexp;
/* 231 */       Symbol methodName = Symbol.get(methodVector.getElementAsString(0));
/* 232 */       method = environment.findFunction(context, methodName);
/*     */     } else {
/*     */       
/* 235 */       throw new EvalException("Invalid method argument of type " + methodSexp.getTypeName(), new Object[0]);
/*     */     } 
/*     */     
/* 238 */     registerS3Method(context, genericName, className, method, definitionEnv.get());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Optional<Environment> resolveGenericFunctionNamespace(Context context, String genericName, Environment environment) {
/* 252 */     if (S3.GROUPS.contains(genericName)) {
/* 253 */       return Optional.of(context.getNamespaceRegistry().getBaseNamespaceEnv());
/*     */     }
/*     */     
/* 256 */     Function function = environment.findFunction(context, Symbol.get(genericName));
/* 257 */     if (function == null) {
/* 258 */       return Optional.empty();
/*     */     }
/* 260 */     if (function instanceof Closure) {
/* 261 */       return Optional.of(((Closure)function).getEnclosingEnvironment());
/*     */     }
/* 263 */     if (function instanceof org.renjin.sexp.PrimitiveFunction) {
/* 264 */       return Optional.of(context.getNamespaceRegistry().getBaseNamespaceEnv());
/*     */     }
/*     */     
/* 267 */     throw new EvalException("Cannot resolve namespace environment from generic function '%s' of type '%s'", new Object[] { genericName, function
/* 268 */           .getTypeName() });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void registerS3Method(Context context, String genericName, String className, Function method, Environment definitionEnv) {
/* 282 */     if (!definitionEnv.hasVariable(S3.METHODS_TABLE)) {
/* 283 */       definitionEnv.setVariableUnsafe(S3.METHODS_TABLE, (SEXP)Environment.createChildEnvironment(context.getBaseEnvironment()).build());
/*     */     }
/* 285 */     Environment methodsTable = (Environment)definitionEnv.getVariableUnsafe(S3.METHODS_TABLE);
/* 286 */     methodsTable.setVariableUnsafe(genericName + "." + className, (SEXP)method);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/packaging/Namespaces.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */