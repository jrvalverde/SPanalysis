package org.renjin.primitives.io.serialization;

import org.renjin.sexp.Environment;
import org.renjin.sexp.Promise;
import org.renjin.sexp.SEXP;
import org.renjin.sexp.Symbol;

public interface ReadContext {
  Environment getBaseEnvironment();
  
  Promise createPromise(SEXP paramSEXP, Environment paramEnvironment);
  
  Environment findNamespace(Symbol paramSymbol);
  
  Environment getBaseNamespaceEnvironment();
  
  Environment getGlobalEnvironment();
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/io/serialization/ReadContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */