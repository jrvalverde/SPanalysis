/*    */ package org.renjin.invoke;
/*    */ 
/*    */ import org.renjin.invoke.reflection.ClassBindingImpl;
/*    */ import org.renjin.invoke.reflection.ClassDefinitionBinding;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClassBindings
/*    */ {
/*    */   public static <T> ClassBinding getClassDefinitionBinding(Class instance) {
/* 30 */     return (ClassBinding)new ClassDefinitionBinding(instance, ClassBindingImpl.get(instance));
/*    */   }
/*    */   
/*    */   public static ClassBinding getClassBinding(Class aClass) {
/* 34 */     return (ClassBinding)ClassBindingImpl.get(aClass);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/ClassBindings.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */