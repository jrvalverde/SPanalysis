/*     */ package org.renjin.pipeliner;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.ArrayList;
/*     */ import java.util.IdentityHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.renjin.pipeliner.fusion.FusedNode;
/*     */ import org.renjin.pipeliner.fusion.LoopKernelCache;
/*     */ import org.renjin.pipeliner.fusion.LoopKernels;
/*     */ import org.renjin.pipeliner.node.CallNode;
/*     */ import org.renjin.pipeliner.node.DataNode;
/*     */ import org.renjin.pipeliner.node.DeferredNode;
/*     */ import org.renjin.pipeliner.node.FunctionNode;
/*     */ import org.renjin.pipeliner.node.OutputNode;
/*     */ import org.renjin.pipeliner.optimize.Optimizers;
/*     */ import org.renjin.primitives.ni.DeferredNativeCall;
/*     */ import org.renjin.primitives.ni.NativeOutputVector;
/*     */ import org.renjin.primitives.vector.DeferredComputation;
/*     */ import org.renjin.repackaged.guava.base.Preconditions;
/*     */ import org.renjin.repackaged.guava.collect.HashMultimap;
/*     */ import org.renjin.repackaged.guava.collect.Lists;
/*     */ import org.renjin.repackaged.guava.collect.Maps;
/*     */ import org.renjin.repackaged.guava.collect.Multimap;
/*     */ import org.renjin.repackaged.guava.collect.Sets;
/*     */ import org.renjin.sexp.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DeferredGraph
/*     */ {
/*  46 */   private List<DeferredNode> rootNodes = new ArrayList<>();
/*  47 */   private List<DeferredNode> nodes = Lists.newArrayList();
/*  48 */   private IdentityHashMap<Vector, DeferredNode> vectorMap = Maps.newIdentityHashMap();
/*  49 */   private IdentityHashMap<DeferredNativeCall, CallNode> callMap = Maps.newIdentityHashMap();
/*  50 */   private Multimap<String, FunctionNode> computationIndex = (Multimap<String, FunctionNode>)HashMultimap.create();
/*     */   
/*     */   public DeferredGraph(DeferredNativeCall call) {
/*  53 */     addRoot(call);
/*     */   }
/*     */   
/*     */   public DeferredGraph(Vector root) {
/*  57 */     addRoot(root);
/*     */   }
/*     */ 
/*     */   
/*     */   public DeferredGraph() {}
/*     */   
/*     */   public void optimize(LoopKernelCache loopKernelCache) {
/*  64 */     Optimizers optimizers = new Optimizers();
/*  65 */     optimizers.optimize(this);
/*  66 */     fuse(loopKernelCache);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void fuse(LoopKernelCache loopKernelCache) {
/*  72 */     Set<DeferredNode> visited = Sets.newIdentityHashSet();
/*  73 */     List<DeferredNode> toCheck = new ArrayList<>(this.rootNodes);
/*  74 */     for (DeferredNode rootNode : toCheck) {
/*  75 */       fuse(loopKernelCache, visited, rootNode);
/*     */     }
/*     */   }
/*     */   
/*     */   private void fuse(LoopKernelCache loopKernelCache, Set<DeferredNode> visited, DeferredNode node) {
/*  80 */     if (visited.add(node))
/*     */     {
/*     */       
/*  83 */       for (DeferredNode operand : node.getOperands()) {
/*  84 */         fuse(loopKernelCache, visited, operand);
/*     */       }
/*     */     }
/*  87 */     FusedNode fused = tryFuse(node);
/*  88 */     if (fused != null) {
/*  89 */       fused.startCompilation(loopKernelCache);
/*  90 */       replaceNode(node, (DeferredNode)fused);
/*     */     } 
/*     */   }
/*     */   
/*     */   private FusedNode tryFuse(DeferredNode root) {
/*  95 */     if (LoopKernels.INSTANCE.supports(root)) {
/*  96 */       return new FusedNode((FunctionNode)root);
/*     */     }
/*  98 */     return null;
/*     */   }
/*     */   
/*     */   void addRoot(Vector root) {
/* 102 */     DeferredNode rootNode = addNode(root);
/* 103 */     this.rootNodes.add(rootNode);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private DeferredNode addNode(Vector vector) {
/*     */     DataNode dataNode;
/* 111 */     DeferredNode node = this.vectorMap.get(vector);
/* 112 */     if (node != null) {
/* 113 */       return node;
/*     */     }
/*     */     
/* 116 */     if (vector.isDeferred()) {
/* 117 */       if (vector instanceof NativeOutputVector) {
/*     */         
/* 119 */         node = addOutputNode(vector);
/*     */       }
/* 121 */       else if (vector instanceof DeferredComputation) {
/* 122 */         node = addComputeNode((DeferredComputation)vector);
/*     */       } else {
/*     */         
/* 125 */         throw new UnsupportedOperationException("deferred: " + vector.getClass().getName());
/*     */       } 
/*     */     } else {
/* 128 */       dataNode = addDataNode(vector);
/*     */     } 
/* 130 */     return (DeferredNode)dataNode;
/*     */   }
/*     */   
/*     */   private DataNode addDataNode(Vector vector) {
/* 134 */     DataNode dataNode = new DataNode(vector);
/* 135 */     this.vectorMap.put(vector, dataNode);
/* 136 */     this.nodes.add(dataNode);
/* 137 */     return dataNode;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private DeferredNode addComputeNode(DeferredComputation vector) {
/* 143 */     Vector[] operands = vector.getOperands();
/* 144 */     DeferredNode[] children = new DeferredNode[operands.length];
/* 145 */     for (int i = 0; i < operands.length; i++) {
/* 146 */       children[i] = addNode(operands[i]);
/*     */     }
/*     */ 
/*     */     
/* 150 */     if (this.computationIndex.containsKey(vector.getComputationName())) {
/* 151 */       for (FunctionNode existingNode : this.computationIndex.get(vector.getComputationName())) {
/* 152 */         if (equivalent(children, existingNode.getOperands())) {
/* 153 */           return (DeferredNode)existingNode;
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/* 158 */     FunctionNode newNode = new FunctionNode(vector);
/* 159 */     newNode.addInputs(children);
/* 160 */     this.nodes.add(newNode);
/* 161 */     this.vectorMap.put(vector, newNode);
/* 162 */     this.computationIndex.put(vector.getComputationName(), newNode);
/* 163 */     return (DeferredNode)newNode;
/*     */   }
/*     */   
/*     */   private boolean equivalent(DeferredNode[] a, List<DeferredNode> b) {
/* 167 */     if (a.length != b.size()) {
/* 168 */       return false;
/*     */     }
/* 170 */     for (int i = 0; i < a.length; i++) {
/* 171 */       if (!equivalent(a[i], b.get(i))) {
/* 172 */         return false;
/*     */       }
/*     */     } 
/* 175 */     return true;
/*     */   }
/*     */   
/*     */   private boolean equivalent(DeferredNode a, DeferredNode b) {
/* 179 */     if (a == b) {
/* 180 */       return true;
/*     */     }
/* 182 */     if (a instanceof DataNode) {
/* 183 */       return ((DataNode)a).equivalent(b);
/*     */     }
/* 185 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private DeferredNode addOutputNode(Vector vector) {
/* 190 */     OutputNode outputNode = new OutputNode((NativeOutputVector)vector);
/* 191 */     this.vectorMap.put(vector, outputNode);
/* 192 */     this.nodes.add(outputNode);
/* 193 */     addCallChild((DeferredNode)outputNode, ((NativeOutputVector)vector).getCall());
/* 194 */     return (DeferredNode)outputNode;
/*     */   }
/*     */   
/*     */   private CallNode addNode(DeferredNativeCall call) {
/* 198 */     CallNode node = this.callMap.get(call);
/* 199 */     if (node != null) {
/* 200 */       return node;
/*     */     }
/*     */     
/* 203 */     node = new CallNode(call);
/* 204 */     this.nodes.add(node);
/* 205 */     this.callMap.put(call, node);
/*     */     
/* 207 */     addChildren((DeferredNode)node, call.getOperands());
/*     */     
/* 209 */     return node;
/*     */   }
/*     */ 
/*     */   
/*     */   private void addCallChild(DeferredNode parentNode, DeferredNativeCall call) {
/* 214 */     CallNode callNode = addNode(call);
/*     */     
/* 216 */     parentNode.addInput((DeferredNode)callNode);
/* 217 */     callNode.addOutput(parentNode);
/*     */   }
/*     */   
/*     */   private void addRoot(DeferredNativeCall call) {
/* 221 */     CallNode callNode = new CallNode(call);
/* 222 */     this.rootNodes.add(callNode);
/* 223 */     this.nodes.add(callNode);
/* 224 */     addChildren((DeferredNode)callNode, call.getOperands());
/*     */   }
/*     */   
/*     */   private void addChildren(DeferredNode parent, Vector[] operands) {
/* 228 */     for (Vector operand : operands) {
/* 229 */       DeferredNode node = addNode(operand);
/* 230 */       parent.addInput(node);
/* 231 */       node.addOutput(parent);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void dumpGraph() {
/*     */     try {
/* 237 */       File tempFile = File.createTempFile("deferred", ".dot");
/* 238 */       PrintWriter writer = new PrintWriter(tempFile);
/* 239 */       printGraph(writer);
/* 240 */       writer.close();
/* 241 */       System.out.println("Dumping compute graph to " + tempFile.getAbsolutePath());
/* 242 */     } catch (IOException iOException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void printGraph(PrintWriter writer) {
/* 249 */     Set<DeferredNode> nodes = Sets.newIdentityHashSet();
/* 250 */     ArrayDeque<DeferredNode> workingList = new ArrayDeque<>(this.rootNodes);
/* 251 */     while (!workingList.isEmpty()) {
/* 252 */       DeferredNode node = workingList.poll();
/* 253 */       if (nodes.add(node)) {
/* 254 */         workingList.addAll(node.getOperands());
/*     */       }
/*     */     } 
/*     */     
/* 258 */     writer.println("digraph G {");
/* 259 */     printEdges(writer, nodes);
/* 260 */     printNodes(writer, nodes);
/* 261 */     writer.println("}");
/* 262 */     writer.flush();
/*     */   }
/*     */   
/*     */   private void printEdges(PrintWriter writer, Set<DeferredNode> nodes) {
/* 266 */     for (DeferredNode node : nodes) {
/* 267 */       for (DeferredNode operand : node.getOperands()) {
/* 268 */         writer.println(operand.getDebugId() + " -> " + node.getDebugId());
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void printNodes(PrintWriter writer, Set<DeferredNode> nodes) {
/* 275 */     for (DeferredNode node : nodes) {
/* 276 */       writer.println(node.getDebugId() + " [ label=\"" + node.getDebugLabel() + "\",  shape=\"" + node
/* 277 */           .getShape().name().toLowerCase() + "\"]");
/*     */     }
/*     */   }
/*     */   
/*     */   public List<DeferredNode> getRoots() {
/* 282 */     return this.rootNodes;
/*     */   }
/*     */   
/*     */   public Vector getRootResult(int rootIndex) {
/* 286 */     return ((DeferredNode)this.rootNodes.get(rootIndex)).getVector();
/*     */   }
/*     */   
/*     */   public DeferredNode getRoot() {
/* 290 */     Preconditions.checkState((this.rootNodes.size() == 1));
/* 291 */     return this.rootNodes.get(0);
/*     */   }
/*     */   
/*     */   public List<DeferredNode> getNodes() {
/* 295 */     return this.nodes;
/*     */   }
/*     */   
/*     */   public void replaceNode(DeferredNode toReplace, DeferredNode replacementNode) {
/* 299 */     this.nodes.remove(toReplace);
/* 300 */     if (!this.nodes.contains(replacementNode)) {
/* 301 */       this.nodes.add(replacementNode);
/*     */     }
/*     */     
/* 304 */     if (this.rootNodes.remove(toReplace)) {
/* 305 */       this.rootNodes.add(replacementNode);
/*     */     }
/*     */     
/* 308 */     for (DeferredNode operand : toReplace.getOperands()) {
/* 309 */       operand.removeUse(toReplace);
/*     */     }
/*     */     
/* 312 */     for (DeferredNode node : toReplace.getUses())
/* 313 */       node.replaceOperand(toReplace, replacementNode); 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/pipeliner/DeferredGraph.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */