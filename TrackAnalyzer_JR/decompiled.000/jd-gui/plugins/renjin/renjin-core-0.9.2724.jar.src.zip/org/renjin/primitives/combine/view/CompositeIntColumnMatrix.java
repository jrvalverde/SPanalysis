/*     */ package org.renjin.primitives.combine.view;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.renjin.eval.Context;
/*     */ import org.renjin.primitives.subset.ArraySubsettable;
/*     */ import org.renjin.primitives.subset.IndexIterator;
/*     */ import org.renjin.primitives.subset.Subscript;
/*     */ import org.renjin.primitives.vector.DeferredComputation;
/*     */ import org.renjin.sexp.AttributeMap;
/*     */ import org.renjin.sexp.IntArrayVector;
/*     */ import org.renjin.sexp.IntVector;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CompositeIntColumnMatrix
/*     */   extends IntVector
/*     */   implements DeferredComputation, ArraySubsettable
/*     */ {
/*     */   private int columnLength;
/*     */   private int length;
/*     */   private final Vector[] columns;
/*     */   
/*     */   public CompositeIntColumnMatrix(Vector[] columns, AttributeMap attributeMap) {
/*  43 */     super(attributeMap);
/*  44 */     this.columns = columns;
/*  45 */     this.columnLength = columns[0].length();
/*  46 */     this.length = columns.length * this.columnLength;
/*     */   }
/*     */ 
/*     */   
/*     */   public int length() {
/*  51 */     return this.length;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getElementAsInt(int index) {
/*  56 */     int columnIndex = index / this.columnLength;
/*  57 */     int rowIndex = index % this.columnLength;
/*  58 */     return this.columns[columnIndex].getElementAsInt(rowIndex);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isConstantAccessTime() {
/*  63 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected SEXP cloneWithNewAttributes(AttributeMap attributes) {
/*  68 */     return (SEXP)new CompositeIntColumnMatrix(this.columns, attributes);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDeferred() {
/*  73 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public Vector[] getOperands() {
/*  78 */     return this.columns;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getComputationName() {
/*  83 */     return "cols";
/*     */   }
/*     */ 
/*     */   
/*     */   public Vector subscript(Context context, int[] sourceDim, Subscript[] subscripts) {
/*  88 */     if (sourceDim.length == 2 && sourceDim[1] == this.columns.length && subscripts[0] instanceof org.renjin.primitives.subset.MissingSubscript) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  93 */       IndexIterator columnIt = subscripts[1].computeIndexes();
/*  94 */       List<Vector> selectedColumns = new ArrayList<>();
/*     */       int columnIndex;
/*  96 */       while ((columnIndex = columnIt.next()) != -1) {
/*  97 */         selectedColumns.add(this.columns[columnIndex]);
/*     */       }
/*     */       
/* 100 */       if (selectedColumns.size() == 0) {
/* 101 */         return (Vector)IntArrayVector.EMPTY;
/*     */       }
/* 103 */       if (selectedColumns.size() == 1) {
/* 104 */         return selectedColumns.get(0);
/*     */       }
/*     */ 
/*     */       
/* 108 */       Vector[] selectedColumnsArray = selectedColumns.<Vector>toArray(new Vector[selectedColumns.size()]);
/*     */       
/* 110 */       return (Vector)new CompositeIntColumnMatrix(selectedColumnsArray, AttributeMap.EMPTY);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 115 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void copyTo(double[] array, int offset, int length) {
/* 120 */     for (int i = 0; i < this.columns.length; i++)
/* 121 */       this.columns[i].copyTo(array, offset + i * this.columnLength, this.columnLength); 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/combine/view/CompositeIntColumnMatrix.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */