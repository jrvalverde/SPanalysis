/*     */ package org.renjin.primitives.io.connections;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import org.renjin.eval.EvalException;
/*     */ import org.renjin.sexp.IntArrayVector;
/*     */ import org.renjin.sexp.IntVector;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.StringArrayVector;
/*     */ import org.renjin.sexp.Symbols;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConnectionTable
/*     */ {
/*     */   public static final int STDIN_HANDLE = 0;
/*     */   public static final int STDOUT_HANDLE = 1;
/*     */   public static final int STDERR_HANDLE = 2;
/*     */   private StdInConnection stdin;
/*     */   private StdOutConnection stdout;
/*     */   private StdOutConnection stderr;
/*     */   private static final int NUM_CONNECTIONS = 128;
/*  49 */   private Connection[] table = new Connection[128];
/*     */ 
/*     */   
/*     */   public ConnectionTable() {
/*  53 */     this.table[0] = this.stdin = new StdInConnection();
/*  54 */     this.table[1] = this.stdout = new StdOutConnection();
/*  55 */     this.table[2] = this.stderr = new StdOutConnection();
/*     */   }
/*     */   
/*     */   public IntVector newConnection(Connection conn) {
/*  59 */     IntArrayVector.Builder sexp = new IntArrayVector.Builder(1);
/*  60 */     sexp.set(0, installConnection(conn));
/*  61 */     sexp.setAttribute(Symbols.CLASS, (SEXP)new StringArrayVector(new String[] { "connection", conn.getClassName() }));
/*  62 */     return sexp.build();
/*     */   }
/*     */ 
/*     */   
/*     */   public void close(int index) throws IOException {
/*  67 */     this.table[index].close();
/*  68 */     this.table[index] = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void close(Connection connection) throws IOException {
/*  73 */     for (int i = 0; i < this.table.length; i++) {
/*  74 */       if (this.table[i] == connection) {
/*  75 */         this.table[i].close();
/*  76 */         this.table[i] = null;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private int installConnection(Connection conn) {
/*  83 */     for (int i = 0; i != this.table.length; i++) {
/*  84 */       if (this.table[i] == null) {
/*  85 */         this.table[i] = conn;
/*  86 */         return i;
/*     */       } 
/*     */     } 
/*  89 */     throw new EvalException("maximum number of connections exceeded", new Object[0]);
/*     */   }
/*     */   
/*     */   public Connection getConnection(int index) {
/*  93 */     if (index >= this.table.length || this.table[index] == null) {
/*  94 */       throw new EvalException("invalid connection", new Object[0]);
/*     */     }
/*  96 */     return this.table[index];
/*     */   }
/*     */   
/*     */   public Connection getConnection(IntVector conn) {
/* 100 */     return getConnection(conn.getElementAsInt(0));
/*     */   }
/*     */   
/*     */   public StdInConnection getStdin() {
/* 104 */     return this.stdin;
/*     */   }
/*     */   
/*     */   public StdOutConnection getStdout() {
/* 108 */     return this.stdout;
/*     */   }
/*     */   
/*     */   public StdOutConnection getStderr() {
/* 112 */     return this.stderr;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/io/connections/ConnectionTable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */