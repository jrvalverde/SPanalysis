/*     */ package org.renjin.compiler.builtins;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.renjin.compiler.codegen.EmitContext;
/*     */ import org.renjin.compiler.ir.TypeSet;
/*     */ import org.renjin.compiler.ir.ValueBounds;
/*     */ import org.renjin.compiler.ir.tac.IRArgument;
/*     */ import org.renjin.compiler.ir.tac.expressions.Expression;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ import org.renjin.repackaged.asm.commons.InstructionAdapter;
/*     */ import org.renjin.sexp.AtomicVector;
/*     */ import org.renjin.sexp.Null;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.Symbols;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GetAtomicElement
/*     */   implements Specialization
/*     */ {
/*     */   private final ValueBounds resultBounds;
/*     */   private final Type type;
/*     */   
/*     */   public static boolean accept(ValueBounds source, ValueBounds subscript) {
/*  46 */     if (!TypeSet.isDefinitelyAtomic(source.getTypeSet())) {
/*  47 */       return false;
/*     */     }
/*     */     
/*  50 */     if (subscript.getLength() != 1) {
/*  51 */       return false;
/*     */     }
/*  53 */     if (subscript.maybeNA()) {
/*  54 */       return false;
/*     */     }
/*     */     
/*  57 */     return true;
/*     */   }
/*     */   
/*     */   public GetAtomicElement(ValueBounds source, ValueBounds subscript) {
/*  61 */     assert accept(source, subscript);
/*     */     
/*  63 */     ValueBounds.Builder resultBounds = new ValueBounds.Builder();
/*  64 */     resultBounds.setTypeSet(TypeSet.elementOf(source.getTypeSet()));
/*  65 */     resultBounds.setNA(source.getNA());
/*  66 */     resultBounds.setAttributeSetOpen(false);
/*  67 */     resultBounds.setLength(1);
/*     */     
/*  69 */     SEXP resultNames = namesBounds(source);
/*  70 */     if (resultNames != Null.INSTANCE) {
/*  71 */       resultBounds.setAttribute(Symbols.NAMES, null);
/*     */     }
/*     */     
/*  74 */     this.resultBounds = resultBounds.build();
/*  75 */     this.type = this.resultBounds.storageType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private SEXP namesBounds(ValueBounds source) {
/*  86 */     SEXP names = source.getAttributeIfConstant(Symbols.NAMES);
/*  87 */     SEXP dimnames = source.getAttributeIfConstant(Symbols.DIMNAMES);
/*     */     
/*  89 */     if (names == Null.INSTANCE && dimnames == Null.INSTANCE) {
/*  90 */       return (SEXP)Null.INSTANCE;
/*     */     }
/*     */     
/*  93 */     SEXP dim = source.getAttributeIfConstant(Symbols.DIM);
/*  94 */     if (dim != null) {
/*  95 */       if (dim.length() == 1) {
/*  96 */         if (dimnames == Null.INSTANCE) {
/*  97 */           return (SEXP)Null.INSTANCE;
/*     */         }
/*     */       }
/* 100 */       else if (names == Null.INSTANCE) {
/* 101 */         return (SEXP)Null.INSTANCE;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 107 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Type getType() {
/* 112 */     return this.type;
/*     */   }
/*     */ 
/*     */   
/*     */   public ValueBounds getResultBounds() {
/* 117 */     return this.resultBounds;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void load(EmitContext emitContext, InstructionAdapter mv, List<IRArgument> arguments) {
/* 123 */     Expression sourceArgument = ((IRArgument)arguments.get(0)).getExpression();
/* 124 */     sourceArgument.load(emitContext, mv);
/* 125 */     emitContext.convert(mv, sourceArgument.getType(), Type.getType(AtomicVector.class));
/*     */ 
/*     */     
/* 128 */     Expression indexArgument = ((IRArgument)arguments.get(0)).getExpression();
/* 129 */     indexArgument.load(emitContext, mv);
/* 130 */     emitContext.convert(mv, indexArgument.getType(), Type.INT_TYPE);
/*     */     
/* 132 */     switch (this.resultBounds.getTypeSet()) {
/*     */       case 16:
/* 134 */         mv.invokeinterface(Type.getInternalName(AtomicVector.class), "getElementAsInt", 
/* 135 */             Type.getMethodDescriptor(Type.INT_TYPE, new Type[] { Type.INT_TYPE }));
/*     */         return;
/*     */       case 32:
/* 138 */         mv.invokeinterface(Type.getInternalName(AtomicVector.class), "getElementAsDouble", 
/* 139 */             Type.getMethodDescriptor(Type.DOUBLE_TYPE, new Type[] { Type.INT_TYPE }));
/*     */         return;
/*     */     } 
/*     */     
/* 143 */     throw new UnsupportedOperationException("type: " + TypeSet.toString(this.resultBounds.getTypeSet()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isPure() {
/* 150 */     return true;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/compiler/builtins/GetAtomicElement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */