/*    */ package org.renjin.invoke.reflection.converters;
/*    */ 
/*    */ import java.lang.reflect.Array;
/*    */ import org.renjin.eval.EvalException;
/*    */ import org.renjin.sexp.AtomicVector;
/*    */ import org.renjin.sexp.DoubleArrayVector;
/*    */ import org.renjin.sexp.DoubleVector;
/*    */ import org.renjin.sexp.SEXP;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DoubleArrayConverter
/*    */   implements Converter<Object>
/*    */ {
/* 32 */   public static final DoubleArrayConverter DOUBLE_ARRAY = new DoubleArrayConverter(double.class);
/*    */   
/*    */   protected final Class componentClass;
/*    */   
/*    */   protected DoubleArrayConverter(Class clazz) {
/* 37 */     this.componentClass = clazz;
/*    */   }
/*    */   
/*    */   public boolean accept(Class clazz) {
/* 41 */     return (clazz.isArray() && clazz.getComponentType().equals(this.componentClass));
/*    */   }
/*    */ 
/*    */   
/*    */   public final DoubleVector convertToR(Object value) {
/* 46 */     if (value == null) {
/* 47 */       return (DoubleVector)new DoubleArrayVector(new double[] { DoubleVector.NA });
/*    */     }
/* 49 */     double[] dArray = new double[Array.getLength(value)];
/* 50 */     for (int i = 0; i < Array.getLength(value); i++) {
/* 51 */       dArray[i] = ((Number)Array.get(value, i)).doubleValue();
/*    */     }
/* 53 */     return (DoubleVector)new DoubleArrayVector(dArray);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public final boolean acceptsSEXP(SEXP exp) {
/* 59 */     return (exp instanceof DoubleVector || exp instanceof org.renjin.sexp.IntVector || exp instanceof org.renjin.sexp.LogicalVector);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final int getSpecificity() {
/* 66 */     return 3;
/*    */   }
/*    */ 
/*    */   
/*    */   public final Object convertToJava(SEXP value) {
/* 71 */     if (!(value instanceof AtomicVector)) {
/* 72 */       throw new EvalException("It's not an AtomicVector", new Object[] { value.getTypeName() });
/*    */     }
/* 74 */     return convertToJavaArray((AtomicVector)value);
/*    */   }
/*    */   
/*    */   protected Object convertToJavaArray(AtomicVector vector) {
/* 78 */     return vector.toDoubleArray();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/reflection/converters/DoubleArrayConverter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */