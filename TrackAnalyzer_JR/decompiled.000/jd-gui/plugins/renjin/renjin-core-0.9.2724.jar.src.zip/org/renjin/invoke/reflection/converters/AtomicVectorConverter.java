package org.renjin.invoke.reflection.converters;

import org.renjin.sexp.Vector;

public interface AtomicVectorConverter {
  Vector.Type getVectorType();
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/invoke/reflection/converters/AtomicVectorConverter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */