/*     */ package org.renjin.primitives.io;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import org.renjin.eval.Context;
/*     */ import org.renjin.eval.EvalException;
/*     */ import org.renjin.invoke.annotations.Current;
/*     */ import org.renjin.invoke.annotations.Internal;
/*     */ import org.renjin.invoke.annotations.Invisible;
/*     */ import org.renjin.primitives.io.connections.Connections;
/*     */ import org.renjin.sexp.AtomicVector;
/*     */ import org.renjin.sexp.DoubleVector;
/*     */ import org.renjin.sexp.IntVector;
/*     */ import org.renjin.sexp.ListVector;
/*     */ import org.renjin.sexp.LogicalVector;
/*     */ import org.renjin.sexp.Null;
/*     */ import org.renjin.sexp.RawVector;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.SexpVisitor;
/*     */ import org.renjin.sexp.StringVector;
/*     */ import org.renjin.sexp.Symbol;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Cat
/*     */   extends SexpVisitor<String>
/*     */ {
/*     */   private final PrintWriter writer;
/*     */   private String separator;
/*     */   
/*     */   @Internal
/*     */   @Invisible
/*     */   public static void cat(@Current Context context, ListVector list, SEXP connection, String sep, int fill, SEXP labels, boolean append) throws IOException {
/*  42 */     list = context.materialize(list);
/*     */     
/*  44 */     PrintWriter printWriter = Connections.getConnection(context, connection).getPrintWriter();
/*  45 */     Cat visitor = new Cat(printWriter, sep, 0);
/*  46 */     for (SEXP element : list) {
/*  47 */       element.accept(visitor);
/*  48 */       if (fill > 0) {
/*  49 */         printWriter.println();
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  56 */     if (sep.contains("\n")) {
/*  57 */       printWriter.println();
/*     */     }
/*  59 */     printWriter.flush();
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean needsSeparator = false;
/*     */   
/*     */   private int fill;
/*     */ 
/*     */   
/*     */   private Cat(PrintWriter writer, String separator, int fill) {
/*  69 */     this.writer = writer;
/*  70 */     this.separator = separator;
/*  71 */     this.fill = fill;
/*     */   }
/*     */ 
/*     */   
/*     */   public void visit(StringVector vector) {
/*  76 */     catVector((AtomicVector)vector);
/*     */   }
/*     */ 
/*     */   
/*     */   public void visit(IntVector vector) {
/*  81 */     catVector((AtomicVector)vector);
/*     */   }
/*     */ 
/*     */   
/*     */   public void visit(LogicalVector vector) {
/*  86 */     catVector((AtomicVector)vector);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void visit(Null nullExpression) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void visit(DoubleVector vector) {
/*  96 */     catVector((AtomicVector)vector);
/*     */   }
/*     */   
/*     */   private void catVector(AtomicVector vector) {
/* 100 */     for (int i = 0; i != vector.length(); i++) {
/* 101 */       catElement(vector.getElementAsString(i));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void visit(Symbol symbol) {
/* 107 */     catElement(symbol.getPrintName());
/*     */   }
/*     */   
/*     */   private void catElement(String element) {
/* 111 */     if (this.needsSeparator) {
/* 112 */       this.writer.print(this.separator);
/*     */     } else {
/* 114 */       this.needsSeparator = true;
/*     */     } 
/* 116 */     this.writer.print(element);
/*     */   }
/*     */ 
/*     */   
/*     */   public void visit(RawVector vector) {
/* 121 */     catVector((AtomicVector)vector);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void unhandled(SEXP exp) {
/* 126 */     throw new EvalException("argument of type '%s' cannot be handled by 'cat'", new Object[] { exp
/* 127 */           .getTypeName() });
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-core-0.9.2724.jar!/org/renjin/primitives/io/Cat.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */