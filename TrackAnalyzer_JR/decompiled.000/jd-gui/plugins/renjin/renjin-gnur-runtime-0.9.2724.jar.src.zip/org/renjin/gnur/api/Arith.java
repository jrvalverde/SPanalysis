/*    */ package org.renjin.gnur.api;
/*    */ 
/*    */ import org.renjin.sexp.DoubleVector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Arith
/*    */ {
/*    */   public static final double R_NaN = NaND;
/*    */   public static final double R_PosInf = InfinityD;
/*    */   public static final double R_NegInf = -InfinityD;
/* 36 */   public static final double R_NaReal = DoubleVector.NA;
/*    */   public static final int R_NaInt = -2147483648;
/*    */   
/*    */   public static int R_IsNA(double p0) {
/* 40 */     return DoubleVector.isNA(p0) ? 1 : 0;
/*    */   }
/*    */   
/*    */   public static int R_IsNaN(double p0) {
/* 44 */     return DoubleVector.isNaN(p0) ? 1 : 0;
/*    */   }
/*    */   
/*    */   public static int R_finite(double p0) {
/* 48 */     return DoubleVector.isFinite(p0) ? 1 : 0;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-gnur-runtime-0.9.2724.jar!/org/renjin/gnur/api/Arith.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */