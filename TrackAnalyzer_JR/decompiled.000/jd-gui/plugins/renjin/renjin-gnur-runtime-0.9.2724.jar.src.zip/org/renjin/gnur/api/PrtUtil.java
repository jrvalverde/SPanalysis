/*     */ package org.renjin.gnur.api;
/*     */ 
/*     */ import java.text.DecimalFormat;
/*     */ import java.text.NumberFormat;
/*     */ import org.renjin.gcc.runtime.BytePtr;
/*     */ import org.renjin.gcc.runtime.DoublePtr;
/*     */ import org.renjin.gcc.runtime.IntPtr;
/*     */ import org.renjin.repackaged.guava.base.Charsets;
/*     */ import org.renjin.repackaged.guava.base.Strings;
/*     */ import org.renjin.sexp.DoubleVector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PrtUtil
/*     */ {
/*     */   public static void Rf_formatLogical(IntPtr p0, int p1, IntPtr p2) {
/*  40 */     throw new UnimplementedGnuApiMethod("Rf_formatLogical");
/*     */   }
/*     */   
/*     */   public static void Rf_formatInteger(IntPtr p0, int p1, IntPtr p2) {
/*  44 */     throw new UnimplementedGnuApiMethod("Rf_formatInteger");
/*     */   }
/*     */   
/*     */   public static void Rf_formatReal(DoublePtr x, int n, IntPtr w, IntPtr d, IntPtr e, int nsmall) {
/*  48 */     throw new UnimplementedGnuApiMethod("Rf_formatReal");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static BytePtr Rf_EncodeLogical(int p0, int p1) {
/*  54 */     throw new UnimplementedGnuApiMethod("Rf_EncodeLogical");
/*     */   }
/*     */   
/*     */   public static BytePtr Rf_EncodeInteger(int p0, int p1) {
/*  58 */     throw new UnimplementedGnuApiMethod("Rf_EncodeInteger");
/*     */   }
/*     */ 
/*     */   
/*     */   public static BytePtr Rf_EncodeReal0(double x, int w, int d, int e, BytePtr dec) {
/*     */     String result;
/*  64 */     if (x == 0.0D) {
/*  65 */       x = 0.0D;
/*     */     }
/*  67 */     if (!Double.isFinite(x)) {
/*  68 */       if (DoubleVector.isNA(x)) {
/*  69 */         result = "NA";
/*  70 */       } else if (DoubleVector.isNaN(x)) {
/*  71 */         result = "NaN";
/*  72 */       } else if (x > 0.0D) {
/*  73 */         result = "Inf";
/*     */       } else {
/*  75 */         result = "-Inf";
/*     */       } 
/*  77 */     } else if (e != 0) {
/*     */       String format;
/*     */ 
/*     */ 
/*     */       
/*  82 */       if (d != 0) {
/*  83 */         if (w == 0) {
/*  84 */           format = String.format("%%#.%de", new Object[] { Integer.valueOf(d) });
/*     */         } else {
/*  86 */           format = String.format("%%#%d.%de", new Object[] { Integer.valueOf(w), Integer.valueOf(d) });
/*     */         }
/*     */       
/*  89 */       } else if (w == 0) {
/*  90 */         format = String.format("%%.%de", new Object[] { Integer.valueOf(d) });
/*     */       } else {
/*  92 */         format = String.format("%%%d.%de", new Object[] { Integer.valueOf(w), Integer.valueOf(d) });
/*     */       } 
/*     */ 
/*     */       
/*  96 */       result = String.format(format, new Object[] { Double.valueOf(x) });
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 102 */       NumberFormat format = DecimalFormat.getNumberInstance();
/* 103 */       format.setMinimumFractionDigits(d);
/* 104 */       format.setGroupingUsed(false);
/* 105 */       result = format.format(x);
/*     */     } 
/*     */     
/* 108 */     return BytePtr.nullTerminatedString(Strings.padStart(result, w, ' '), Charsets.UTF_8);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int IndexWidth(int p0) {
/* 116 */     throw new UnimplementedGnuApiMethod("IndexWidth");
/*     */   }
/*     */   
/*     */   public static void Rf_VectorIndex(int p0, int p1) {
/* 120 */     throw new UnimplementedGnuApiMethod("Rf_VectorIndex");
/*     */   }
/*     */   
/*     */   public static void Rf_printIntegerVector(IntPtr p0, int p1, int p2) {
/* 124 */     throw new UnimplementedGnuApiMethod("Rf_printIntegerVector");
/*     */   }
/*     */   
/*     */   public static void Rf_printRealVector(DoublePtr p0, int p1, int p2) {
/* 128 */     throw new UnimplementedGnuApiMethod("Rf_printRealVector");
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-gnur-runtime-0.9.2724.jar!/org/renjin/gnur/api/PrtUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */