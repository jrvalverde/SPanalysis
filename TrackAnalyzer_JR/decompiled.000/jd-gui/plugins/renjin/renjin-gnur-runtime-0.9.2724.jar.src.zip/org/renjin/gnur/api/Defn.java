/*      */ package org.renjin.gnur.api;
/*      */ 
/*      */ import java.nio.charset.StandardCharsets;
/*      */ import java.util.Iterator;
/*      */ import org.renjin.eval.EvalException;
/*      */ import org.renjin.gcc.runtime.BytePtr;
/*      */ import org.renjin.gcc.runtime.DoublePtr;
/*      */ import org.renjin.gcc.runtime.IntPtr;
/*      */ import org.renjin.gcc.runtime.Ptr;
/*      */ import org.renjin.gcc.runtime.Stdlib;
/*      */ import org.renjin.gnur.api.annotations.Allocator;
/*      */ import org.renjin.parser.NumericLiterals;
/*      */ import org.renjin.primitives.Deparse;
/*      */ import org.renjin.primitives.Native;
/*      */ import org.renjin.primitives.Primitives;
/*      */ import org.renjin.repackaged.guava.base.Charsets;
/*      */ import org.renjin.sexp.AbstractSEXP;
/*      */ import org.renjin.sexp.AttributeMap;
/*      */ import org.renjin.sexp.Environment;
/*      */ import org.renjin.sexp.Frame;
/*      */ import org.renjin.sexp.HashFrame;
/*      */ import org.renjin.sexp.LogicalVector;
/*      */ import org.renjin.sexp.Null;
/*      */ import org.renjin.sexp.PairList;
/*      */ import org.renjin.sexp.SEXP;
/*      */ import org.renjin.sexp.StringVector;
/*      */ import org.renjin.sexp.Symbol;
/*      */ import org.renjin.sexp.Symbols;
/*      */ import org.renjin.sexp.Vector;
/*      */ import org.renjin.util.CDefines;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class Defn
/*      */ {
/*   45 */   public static final SEXP R_CommentSymbol = (SEXP)Symbol.get("comment");
/*   46 */   public static final SEXP R_DotEnvSymbol = (SEXP)Symbol.get(".Environment");
/*   47 */   public static final SEXP R_ExactSymbol = (SEXP)Symbol.get("exact");
/*   48 */   public static final SEXP R_RecursiveSymbol = (SEXP)Symbol.get("recursive");
/*   49 */   public static final SEXP R_WholeSrcrefSymbol = (SEXP)Symbol.get("wholeSrcref");
/*   50 */   public static final SEXP R_TmpvalSymbol = (SEXP)Symbol.get("*tmp*");
/*   51 */   public static final SEXP R_UseNamesSymbol = (SEXP)Symbol.get("use.names");
/*   52 */   public static final SEXP R_ColonSymbol = (SEXP)Symbol.get(":");
/*      */ 
/*      */   
/*   55 */   public static final SEXP R_ConnIdSymbol = (SEXP)Symbol.get("conn_id");
/*   56 */   public static final SEXP R_DevicesSymbol = (SEXP)Symbol.get(".Devices");
/*   57 */   public static final SEXP R_dot_Generic = (SEXP)Symbol.get(".Generic");
/*   58 */   public static final SEXP R_dot_Methods = (SEXP)Symbol.get(".Methods");
/*   59 */   public static final SEXP R_dot_Group = (SEXP)Symbol.get(".Group");
/*   60 */   public static final SEXP R_dot_Class = (SEXP)Symbol.get(".Class");
/*   61 */   public static final SEXP R_dot_GenericCallEnv = (SEXP)Symbol.get(".GenericCallEnv");
/*   62 */   public static final SEXP R_dot_GenericDefEnv = (SEXP)Symbol.get(".GenericDefEnv");
/*      */   
/*   64 */   public static int R_interrupts_suspended = 0;
/*      */   
/*   66 */   public static int R_interrupts_pending = 0;
/*      */   
/*   68 */   public static int R_Interactive = 1;
/*      */   
/*   70 */   public static int known_to_be_latin1 = 0;
/*      */   
/*   72 */   public static int utf8locale = 0;
/*      */   
/*   74 */   public static int mbcslocale = 0;
/*      */   
/*   76 */   public static int max_contour_segments = 25000;
/*      */   
/*   78 */   public static int R_Visible = 1;
/*      */   
/*   80 */   public static int R_dec_min_exponent = -308;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   85 */   public static Ptr OutDec = (Ptr)new BytePtr(new byte[] { 46, 0 });
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int IS_BYTES(SEXP x) {
/*   91 */     return 0;
/*      */   }
/*      */   
/*      */   public static void SET_BYTES(SEXP x) {
/*   95 */     throw new UnimplementedGnuApiMethod("SET_BYTES");
/*      */   }
/*      */ 
/*      */   
/*      */   public static int IS_LATIN1(SEXP x) {
/*  100 */     return 0;
/*      */   }
/*      */   public static void SET_LATIN1(SEXP x) {
/*  103 */     throw new UnimplementedGnuApiMethod("SET_LATIN1");
/*      */   }
/*      */ 
/*      */   
/*      */   public static int IS_ASCII(SEXP x) {
/*  108 */     return 0;
/*      */   }
/*      */ 
/*      */   
/*      */   public static void SET_ASCII(SEXP x) {
/*  113 */     throw new UnimplementedGnuApiMethod("SET_ASCII");
/*      */   }
/*      */ 
/*      */   
/*      */   public static int IS_UTF8(SEXP x) {
/*  118 */     return 1;
/*      */   }
/*      */ 
/*      */   
/*      */   public static void SET_UTF8(SEXP x) {}
/*      */ 
/*      */   
/*      */   public static void Rf_CoercionWarning(int p0) {
/*  126 */     throw new UnimplementedGnuApiMethod("Rf_CoercionWarning");
/*      */   }
/*      */   
/*      */   public static int Rf_LogicalFromInteger(int p0, IntPtr p1) {
/*  130 */     throw new UnimplementedGnuApiMethod("Rf_LogicalFromInteger");
/*      */   }
/*      */   
/*      */   public static int Rf_LogicalFromReal(double p0, IntPtr p1) {
/*  134 */     throw new UnimplementedGnuApiMethod("Rf_LogicalFromReal");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static int Rf_IntegerFromLogical(int p0, IntPtr p1) {
/*  140 */     throw new UnimplementedGnuApiMethod("Rf_IntegerFromLogical");
/*      */   }
/*      */   
/*      */   public static int Rf_IntegerFromReal(double p0, IntPtr p1) {
/*  144 */     throw new UnimplementedGnuApiMethod("Rf_IntegerFromReal");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static double Rf_RealFromLogical(int p0, IntPtr p1) {
/*  150 */     throw new UnimplementedGnuApiMethod("Rf_RealFromLogical");
/*      */   }
/*      */   
/*      */   public static double Rf_RealFromInteger(int p0, IntPtr p1) {
/*  154 */     throw new UnimplementedGnuApiMethod("Rf_RealFromInteger");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP SET_CXTAIL(SEXP x, SEXP y) {
/*  166 */     throw new UnimplementedGnuApiMethod("SET_CXTAIL");
/*      */   }
/*      */   
/*      */   public static void R_ProcessEvents() {
/*  170 */     throw new UnimplementedGnuApiMethod("R_ProcessEvents");
/*      */   }
/*      */   
/*      */   public static void R_setupHistory() {
/*  174 */     throw new UnimplementedGnuApiMethod("R_setupHistory");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static void resetTimeLimits() {
/*  180 */     throw new UnimplementedGnuApiMethod("resetTimeLimits");
/*      */   }
/*      */   
/*      */   public static SEXP R_cmpfun(SEXP p0) {
/*  184 */     throw new UnimplementedGnuApiMethod("R_cmpfun");
/*      */   }
/*      */   
/*      */   public static void R_init_jit_enabled() {
/*  188 */     throw new UnimplementedGnuApiMethod("R_init_jit_enabled");
/*      */   }
/*      */   
/*      */   public static void R_initAsignSymbols() {
/*  192 */     throw new UnimplementedGnuApiMethod("R_initAsignSymbols");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP R_deferred_default_method() {
/*  198 */     throw new UnimplementedGnuApiMethod("R_deferred_default_method");
/*      */   }
/*      */   
/*      */   public static SEXP R_set_prim_method(SEXP fname, SEXP op, SEXP code_vec, SEXP fundef, SEXP mlist) {
/*  202 */     throw new UnimplementedGnuApiMethod("R_set_prim_method");
/*      */   }
/*      */   
/*      */   public static SEXP do_set_prim_method(SEXP op, BytePtr code_string, SEXP fundef, SEXP mlist) {
/*  206 */     throw new UnimplementedGnuApiMethod("do_set_prim_method");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP R_primitive_methods(SEXP op) {
/*  212 */     throw new UnimplementedGnuApiMethod("R_primitive_methods");
/*      */   }
/*      */   
/*      */   public static SEXP R_primitive_generic(SEXP op) {
/*  216 */     throw new UnimplementedGnuApiMethod("R_primitive_generic");
/*      */   }
/*      */   
/*      */   public static int R_ReadConsole(Ptr promptPtr, Ptr buffer, int bufferLength, int addToHistory) {
/*  220 */     String promptString = Stdlib.nullTerminatedString(promptPtr);
/*  221 */     String result = Native.currentContext().getSession().getSessionController().readLine(promptString);
/*  222 */     byte[] resultBytes = result.getBytes(Charsets.UTF_8);
/*      */     int i;
/*  224 */     for (i = 0; i < bufferLength - 1 && i < resultBytes.length; i++) {
/*  225 */       buffer.setByte(i, resultBytes[i]);
/*      */     }
/*  227 */     buffer.setByte(i, (byte)0);
/*  228 */     return i;
/*      */   }
/*      */   
/*      */   public static void R_WriteConsole(BytePtr p0, int p1) {
/*  232 */     throw new UnimplementedGnuApiMethod("R_WriteConsole");
/*      */   }
/*      */   
/*      */   public static void R_WriteConsoleEx(BytePtr p0, int p1, int p2) {
/*  236 */     throw new UnimplementedGnuApiMethod("R_WriteConsoleEx");
/*      */   }
/*      */   
/*      */   public static void R_ResetConsole() {
/*  240 */     throw new UnimplementedGnuApiMethod("R_ResetConsole");
/*      */   }
/*      */   
/*      */   public static void R_FlushConsole() {
/*  244 */     throw new UnimplementedGnuApiMethod("R_FlushConsole");
/*      */   }
/*      */   
/*      */   public static void R_ClearerrConsole() {
/*  248 */     throw new UnimplementedGnuApiMethod("R_ClearerrConsole");
/*      */   }
/*      */   
/*      */   public static void R_Busy(int p0) {
/*  252 */     throw new UnimplementedGnuApiMethod("R_Busy");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int R_ChooseFile(int p0, BytePtr p1, int p2) {
/*  260 */     throw new UnimplementedGnuApiMethod("R_ChooseFile");
/*      */   }
/*      */   
/*      */   public static BytePtr R_HomeDir() {
/*  264 */     throw new UnimplementedGnuApiMethod("R_HomeDir");
/*      */   }
/*      */   
/*      */   public static boolean R_FileExists(BytePtr p0) {
/*  268 */     throw new UnimplementedGnuApiMethod("R_FileExists");
/*      */   }
/*      */   
/*      */   public static boolean R_HiddenFile(BytePtr p0) {
/*  272 */     throw new UnimplementedGnuApiMethod("R_HiddenFile");
/*      */   }
/*      */   
/*      */   public static double R_FileMtime(BytePtr p0) {
/*  276 */     throw new UnimplementedGnuApiMethod("R_FileMtime");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int Rf_LogicalFromString(SEXP p0, IntPtr p1) {
/*  290 */     throw new UnimplementedGnuApiMethod("Rf_LogicalFromString");
/*      */   }
/*      */   
/*      */   public static int Rf_IntegerFromString(SEXP p0, IntPtr p1) {
/*  294 */     throw new UnimplementedGnuApiMethod("Rf_IntegerFromString");
/*      */   }
/*      */   
/*      */   public static double Rf_RealFromString(SEXP p0, IntPtr p1) {
/*  298 */     throw new UnimplementedGnuApiMethod("Rf_RealFromString");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP Rf_StringFromLogical(int p0, IntPtr p1) {
/*  304 */     throw new UnimplementedGnuApiMethod("Rf_StringFromLogical");
/*      */   }
/*      */   
/*      */   public static SEXP Rf_StringFromInteger(int p0, IntPtr p1) {
/*  308 */     throw new UnimplementedGnuApiMethod("Rf_StringFromInteger");
/*      */   }
/*      */   
/*      */   public static SEXP Rf_StringFromReal(double p0, IntPtr p1) {
/*  312 */     throw new UnimplementedGnuApiMethod("Rf_StringFromReal");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP Rf_EnsureString(SEXP p0) {
/*  318 */     throw new UnimplementedGnuApiMethod("Rf_EnsureString");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP Rf_append(SEXP p0, SEXP p1) {
/*  324 */     throw new UnimplementedGnuApiMethod("Rf_append");
/*      */   }
/*      */   
/*      */   public static int Rf_asVecSize(SEXP x) {
/*  328 */     throw new UnimplementedGnuApiMethod("Rf_asVecSize");
/*      */   }
/*      */   
/*      */   public static void Rf_check1arg(SEXP p0, SEXP p1, BytePtr p2) {
/*  332 */     throw new UnimplementedGnuApiMethod("Rf_check1arg");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static void Rf_checkArityCall(SEXP op, SEXP args, SEXP call) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public static void Rf_CheckFormals(SEXP p0) {
/*  342 */     throw new UnimplementedGnuApiMethod("Rf_CheckFormals");
/*      */   }
/*      */   
/*      */   public static void R_check_locale() {
/*  346 */     throw new UnimplementedGnuApiMethod("R_check_locale");
/*      */   }
/*      */   
/*      */   public static void Rf_check_stack_balance(SEXP op, int save) {
/*  350 */     throw new UnimplementedGnuApiMethod("Rf_check_stack_balance");
/*      */   }
/*      */   
/*      */   public static void Rf_CleanEd() {
/*  354 */     throw new UnimplementedGnuApiMethod("Rf_CleanEd");
/*      */   }
/*      */   
/*      */   public static void Rf_copyMostAttribNoTs(SEXP inp, SEXP ans) {
/*  358 */     if (ans == Null.INSTANCE) {
/*  359 */       throw new EvalException("attempt to set an attribute on NULL", new Object[0]);
/*      */     }
/*      */     
/*  362 */     AttributeMap.Builder attributeBuilder = new AttributeMap.Builder();
/*  363 */     Iterator<PairList.Node> itr = inp.getAttributes().nodes().iterator();
/*  364 */     while (itr.hasNext()) {
/*  365 */       PairList.Node s = itr.next();
/*  366 */       Symbol tag = s.getTag();
/*  367 */       if (tag != Symbols.NAMES || tag != Symbols.CLASS || tag != Symbols.DIM || tag != Symbols.DIMNAMES || tag != Symbols.TSP) {
/*  368 */         attributeBuilder.set(tag, ans.getAttributes().get(tag)); continue;
/*  369 */       }  if (tag == Symbols.CLASS) {
/*  370 */         SEXP cl = s.getValue();
/*      */         
/*  372 */         boolean ists = false; int i;
/*  373 */         for (i = 0; i < cl.length(); i++) {
/*  374 */           if ("ts".equals(cl.getElementAsSEXP(i).asString())) {
/*  375 */             ists = true;
/*      */             break;
/*      */           } 
/*      */         } 
/*  379 */         if (!ists) {
/*  380 */           attributeBuilder.set(tag, cl); continue;
/*  381 */         }  if (cl.length() <= 1) {
/*      */           continue;
/*      */         }
/*  384 */         int l = cl.length();
/*  385 */         Vector.Builder new_cl = CDefines.allocVector(CDefines.STRSXP, l - 1);
/*  386 */         for (int e = 0, j = 0; e < l; i++) {
/*  387 */           if (!"ts".equals(cl.getElementAsSEXP(i).asString())) {
/*  388 */             Rinternals.SET_STRING_ELT((SEXP)new_cl.build(), j++, Rinternals.STRING_ELT(cl, i));
/*      */           }
/*      */         } 
/*  391 */         attributeBuilder.set(tag, (SEXP)new_cl.build());
/*      */       } 
/*      */     } 
/*      */     
/*  395 */     ((AbstractSEXP)ans).unsafeSetAttributes(attributeBuilder);
/*  396 */     if (Rinternals.IS_S4_OBJECT(inp) != 0) {
/*  397 */       Rinternals.SET_S4_OBJECT(ans);
/*      */     } else {
/*  399 */       Rinternals.UNSET_S4_OBJECT(ans);
/*      */     } 
/*      */   }
/*      */   
/*      */   public static SEXP Rf_createS3Vars(SEXP p0, SEXP p1, SEXP p2, SEXP p3, SEXP p4, SEXP p5) {
/*  404 */     throw new UnimplementedGnuApiMethod("Rf_createS3Vars");
/*      */   }
/*      */   
/*      */   public static void Rf_CustomPrintValue(SEXP p0, SEXP p1) {
/*  408 */     throw new UnimplementedGnuApiMethod("Rf_CustomPrintValue");
/*      */   }
/*      */   
/*      */   public static double Rf_currentTime() {
/*  412 */     throw new UnimplementedGnuApiMethod("Rf_currentTime");
/*      */   }
/*      */   
/*      */   public static void Rf_DataFrameClass(SEXP p0) {
/*  416 */     throw new UnimplementedGnuApiMethod("Rf_DataFrameClass");
/*      */   }
/*      */   
/*      */   public static SEXP Rf_ddfindVar(SEXP p0, SEXP p1) {
/*  420 */     throw new UnimplementedGnuApiMethod("Rf_ddfindVar");
/*      */   }
/*      */   
/*      */   public static SEXP Rf_deparse1(SEXP p0, boolean p1, int p2) {
/*  424 */     throw new UnimplementedGnuApiMethod("Rf_deparse1");
/*      */   }
/*      */   
/*      */   public static SEXP Rf_deparse1w(SEXP p0, boolean p1, int p2) {
/*  428 */     throw new UnimplementedGnuApiMethod("Rf_deparse1w");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP Rf_deparse1line(SEXP call, boolean abbrev) {
/*  434 */     String line = Deparse.deparseExp(Native.currentContext(), call);
/*  435 */     if (abbrev && line.length() > 12) {
/*  436 */       return (SEXP)StringVector.valueOf(line.substring(12));
/*      */     }
/*  438 */     return (SEXP)StringVector.valueOf(line);
/*      */   }
/*      */ 
/*      */   
/*      */   public static SEXP Rf_deparse1s(SEXP call) {
/*  443 */     throw new UnimplementedGnuApiMethod("Rf_deparse1s");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP duplicated(SEXP p0, boolean p1) {
/*  453 */     throw new UnimplementedGnuApiMethod("duplicated");
/*      */   }
/*      */   
/*      */   public static int any_duplicated(SEXP p0, boolean p1) {
/*  457 */     throw new UnimplementedGnuApiMethod("any_duplicated");
/*      */   }
/*      */   
/*      */   public static int any_duplicated3(SEXP p0, SEXP p1, boolean p2) {
/*  461 */     throw new UnimplementedGnuApiMethod("any_duplicated3");
/*      */   }
/*      */   
/*      */   public static int Rf_envlength(SEXP p0) {
/*  465 */     throw new UnimplementedGnuApiMethod("Rf_envlength");
/*      */   }
/*      */   
/*      */   public static SEXP Rf_evalList(SEXP p0, SEXP p1, SEXP p2, int p3) {
/*  469 */     throw new UnimplementedGnuApiMethod("Rf_evalList");
/*      */   }
/*      */   
/*      */   public static SEXP Rf_evalListKeepMissing(SEXP p0, SEXP p1) {
/*  473 */     throw new UnimplementedGnuApiMethod("Rf_evalListKeepMissing");
/*      */   }
/*      */   
/*      */   public static int Rf_factorsConform(SEXP p0, SEXP p1) {
/*  477 */     throw new UnimplementedGnuApiMethod("Rf_factorsConform");
/*      */   }
/*      */   
/*      */   public static void Rf_findcontext(int p0, SEXP p1, SEXP p2) {
/*  481 */     throw new UnimplementedGnuApiMethod("Rf_findcontext");
/*      */   }
/*      */   
/*      */   public static SEXP Rf_findVar1(SEXP p0, SEXP p1, int p2, int p3) {
/*  485 */     throw new UnimplementedGnuApiMethod("Rf_findVar1");
/*      */   }
/*      */   
/*      */   public static void Rf_FrameClassFix(SEXP p0) {
/*  489 */     throw new UnimplementedGnuApiMethod("Rf_FrameClassFix");
/*      */   }
/*      */   
/*      */   public static SEXP Rf_frameSubscript(int p0, SEXP p1, SEXP p2) {
/*  493 */     throw new UnimplementedGnuApiMethod("Rf_frameSubscript");
/*      */   }
/*      */   
/*      */   public static int Rf_get1index(SEXP p0, SEXP p1, int p2, int p3, int p4, SEXP p5) {
/*  497 */     throw new UnimplementedGnuApiMethod("Rf_get1index");
/*      */   }
/*      */   
/*      */   public static int Rf_GetOptionCutoff() {
/*  501 */     throw new UnimplementedGnuApiMethod("Rf_GetOptionCutoff");
/*      */   }
/*      */   
/*      */   public static SEXP Rf_getVar(SEXP p0, SEXP p1) {
/*  505 */     throw new UnimplementedGnuApiMethod("Rf_getVar");
/*      */   }
/*      */   
/*      */   public static SEXP Rf_getVarInFrame(SEXP p0, SEXP p1) {
/*  509 */     throw new UnimplementedGnuApiMethod("Rf_getVarInFrame");
/*      */   }
/*      */   
/*      */   public static void Rf_InitArithmetic() {
/*  513 */     throw new UnimplementedGnuApiMethod("Rf_InitArithmetic");
/*      */   }
/*      */   
/*      */   public static void Rf_InitConnections() {
/*  517 */     throw new UnimplementedGnuApiMethod("Rf_InitConnections");
/*      */   }
/*      */   
/*      */   public static void Rf_InitEd() {
/*  521 */     throw new UnimplementedGnuApiMethod("Rf_InitEd");
/*      */   }
/*      */   
/*      */   public static void Rf_InitFunctionHashing() {
/*  525 */     throw new UnimplementedGnuApiMethod("Rf_InitFunctionHashing");
/*      */   }
/*      */   
/*      */   public static void Rf_InitBaseEnv() {
/*  529 */     throw new UnimplementedGnuApiMethod("Rf_InitBaseEnv");
/*      */   }
/*      */   
/*      */   public static void Rf_InitGlobalEnv() {
/*  533 */     throw new UnimplementedGnuApiMethod("Rf_InitGlobalEnv");
/*      */   }
/*      */   
/*      */   public static boolean R_current_trace_state() {
/*  537 */     throw new UnimplementedGnuApiMethod("R_current_trace_state");
/*      */   }
/*      */   
/*      */   public static boolean R_current_debug_state() {
/*  541 */     throw new UnimplementedGnuApiMethod("R_current_debug_state");
/*      */   }
/*      */   
/*      */   public static boolean R_has_methods(SEXP p0) {
/*  545 */     throw new UnimplementedGnuApiMethod("R_has_methods");
/*      */   }
/*      */   
/*      */   public static void R_InitialData() {
/*  549 */     throw new UnimplementedGnuApiMethod("R_InitialData");
/*      */   }
/*      */   
/*      */   public static SEXP R_possible_dispatch(SEXP p0, SEXP p1, SEXP p2, SEXP p3, boolean p4) {
/*  553 */     throw new UnimplementedGnuApiMethod("R_possible_dispatch");
/*      */   }
/*      */   
/*      */   public static void Rf_InitGraphics() {
/*  557 */     throw new UnimplementedGnuApiMethod("Rf_InitGraphics");
/*      */   }
/*      */   
/*      */   public static void Rf_InitMemory() {
/*  561 */     throw new UnimplementedGnuApiMethod("Rf_InitMemory");
/*      */   }
/*      */   
/*      */   public static void Rf_InitNames() {
/*  565 */     throw new UnimplementedGnuApiMethod("Rf_InitNames");
/*      */   }
/*      */   
/*      */   public static void Rf_InitOptions() {
/*  569 */     throw new UnimplementedGnuApiMethod("Rf_InitOptions");
/*      */   }
/*      */   
/*      */   public static void Rf_InitStringHash() {
/*  573 */     throw new UnimplementedGnuApiMethod("Rf_InitStringHash");
/*      */   }
/*      */   
/*      */   public static void Init_R_Variables(SEXP p0) {
/*  577 */     throw new UnimplementedGnuApiMethod("Init_R_Variables");
/*      */   }
/*      */   
/*      */   public static void Rf_InitTempDir() {
/*  581 */     throw new UnimplementedGnuApiMethod("Rf_InitTempDir");
/*      */   }
/*      */   
/*      */   public static void Rf_InitTypeTables() {
/*  585 */     throw new UnimplementedGnuApiMethod("Rf_InitTypeTables");
/*      */   }
/*      */   
/*      */   public static void Rf_initStack() {
/*  589 */     throw new UnimplementedGnuApiMethod("Rf_initStack");
/*      */   }
/*      */   
/*      */   public static void Rf_InitS3DefaultTypes() {
/*  593 */     throw new UnimplementedGnuApiMethod("Rf_InitS3DefaultTypes");
/*      */   }
/*      */   
/*      */   public static void Rf_internalTypeCheck(SEXP p0, SEXP p1, int p2) {
/*  597 */     throw new UnimplementedGnuApiMethod("Rf_internalTypeCheck");
/*      */   }
/*      */   
/*      */   public static boolean isMethodsDispatchOn() {
/*  601 */     throw new UnimplementedGnuApiMethod("isMethodsDispatchOn");
/*      */   }
/*      */   
/*      */   public static int Rf_isValidName(BytePtr p0) {
/*  605 */     throw new UnimplementedGnuApiMethod("Rf_isValidName");
/*      */   }
/*      */   
/*      */   public static void Rf_jump_to_toplevel() {
/*  609 */     throw new UnimplementedGnuApiMethod("Rf_jump_to_toplevel");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static void Rf_KillAllDevices() {
/*  617 */     throw new RuntimeException("Please recompile with the latest version of Renjin");
/*      */   }
/*      */   
/*      */   public static SEXP Rf_levelsgets(SEXP p0, SEXP p1) {
/*  621 */     throw new UnimplementedGnuApiMethod("Rf_levelsgets");
/*      */   }
/*      */   
/*      */   public static void Rf_mainloop() {
/*  625 */     throw new UnimplementedGnuApiMethod("Rf_mainloop");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP Rf_markKnown(BytePtr p0, SEXP p1) {
/*  631 */     throw new UnimplementedGnuApiMethod("Rf_markKnown");
/*      */   }
/*      */   
/*      */   public static SEXP Rf_mat2indsub(SEXP p0, SEXP p1, SEXP p2) {
/*  635 */     throw new UnimplementedGnuApiMethod("Rf_mat2indsub");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP Rf_matchArgs(SEXP p0, SEXP p1, SEXP p2) {
/*  643 */     throw new UnimplementedGnuApiMethod("Rf_matchArgs");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static void memtrace_report(Object p0, Object p1) {
/*  649 */     throw new UnimplementedGnuApiMethod("memtrace_report");
/*      */   }
/*      */   
/*      */   public static SEXP Rf_mkCLOSXP(SEXP p0, SEXP p1, SEXP p2) {
/*  653 */     throw new UnimplementedGnuApiMethod("Rf_mkCLOSXP");
/*      */   }
/*      */   
/*      */   public static SEXP Rf_mkFalse() {
/*  657 */     return (SEXP)LogicalVector.FALSE;
/*      */   }
/*      */   
/*      */   public static SEXP mkPRIMSXP(int p0, int p1) {
/*  661 */     throw new UnimplementedGnuApiMethod("mkPRIMSXP");
/*      */   }
/*      */   
/*      */   public static SEXP Rf_mkPROMISE(SEXP p0, SEXP p1) {
/*  665 */     throw new UnimplementedGnuApiMethod("Rf_mkPROMISE");
/*      */   }
/*      */   
/*      */   public static SEXP R_mkEVPROMISE(SEXP p0, SEXP p1) {
/*  669 */     throw new UnimplementedGnuApiMethod("R_mkEVPROMISE");
/*      */   }
/*      */   
/*      */   public static SEXP R_mkEVPROMISE_NR(SEXP p0, SEXP p1) {
/*  673 */     throw new UnimplementedGnuApiMethod("R_mkEVPROMISE_NR");
/*      */   }
/*      */   
/*      */   public static SEXP Rf_mkQUOTE(SEXP p0) {
/*  677 */     throw new UnimplementedGnuApiMethod("Rf_mkQUOTE");
/*      */   }
/*      */   
/*      */   public static SEXP Rf_mkSYMSXP(SEXP p0, SEXP p1) {
/*  681 */     throw new UnimplementedGnuApiMethod("Rf_mkSYMSXP");
/*      */   }
/*      */   
/*      */   public static SEXP Rf_mkTrue() {
/*  685 */     return (SEXP)LogicalVector.TRUE;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Allocator
/*      */   public static SEXP Rf_NewEnvironment(SEXP namelist, SEXP valuelist, SEXP parentEnv) {
/*  706 */     Environment.Builder newEnv = new Environment.Builder((Environment)parentEnv, (Frame)new HashFrame());
/*      */     
/*  708 */     Iterator<PairList.Node> valueIt = ((PairList)valuelist).nodes().iterator();
/*  709 */     Iterator<PairList.Node> nameIt = ((PairList)namelist).nodes().iterator();
/*      */     
/*  711 */     while (nameIt.hasNext() && valueIt.hasNext()) {
/*  712 */       newEnv.setVariable((Symbol)((PairList.Node)nameIt.next()).getValue(), (SEXP)valueIt.next());
/*      */     }
/*      */     
/*  715 */     while (valueIt.hasNext()) {
/*  716 */       PairList.Node node = valueIt.next();
/*  717 */       if (node.hasTag()) {
/*  718 */         newEnv.setVariable(node.getTag(), node.getValue());
/*      */       }
/*      */     } 
/*      */     
/*  722 */     return (SEXP)newEnv.build();
/*      */   }
/*      */   
/*      */   public static void Rf_onintr() {
/*  726 */     throw new UnimplementedGnuApiMethod("Rf_onintr");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP Rf_patchArgsByActuals(SEXP p0, SEXP p1, SEXP p2) {
/*  738 */     throw new UnimplementedGnuApiMethod("Rf_patchArgsByActuals");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void Rf_PrintDefaults() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void Rf_PrintGreeting() {
/*  761 */     throw new UnimplementedGnuApiMethod("Rf_PrintGreeting");
/*      */   }
/*      */   
/*      */   public static void Rf_PrintValueEnv(SEXP p0, SEXP p1) {
/*  765 */     throw new UnimplementedGnuApiMethod("Rf_PrintValueEnv");
/*      */   }
/*      */   
/*      */   public static void Rf_PrintValueRec(SEXP p0, SEXP p1) {
/*  769 */     throw new UnimplementedGnuApiMethod("Rf_PrintValueRec");
/*      */   }
/*      */   
/*      */   public static void Rf_PrintVersion(BytePtr p0, int len) {
/*  773 */     throw new UnimplementedGnuApiMethod("Rf_PrintVersion");
/*      */   }
/*      */   
/*      */   public static void Rf_PrintVersion_part_1(BytePtr p0, int len) {
/*  777 */     throw new UnimplementedGnuApiMethod("Rf_PrintVersion_part_1");
/*      */   }
/*      */   
/*      */   public static void Rf_PrintVersionString(BytePtr p0, int len) {
/*  781 */     throw new UnimplementedGnuApiMethod("Rf_PrintVersionString");
/*      */   }
/*      */   
/*      */   public static void Rf_PrintWarnings() {
/*  785 */     throw new UnimplementedGnuApiMethod("Rf_PrintWarnings");
/*      */   }
/*      */   
/*      */   public static void process_site_Renviron() {
/*  789 */     throw new UnimplementedGnuApiMethod("process_site_Renviron");
/*      */   }
/*      */   
/*      */   public static void process_system_Renviron() {
/*  793 */     throw new UnimplementedGnuApiMethod("process_system_Renviron");
/*      */   }
/*      */   
/*      */   public static void process_user_Renviron() {
/*  797 */     throw new UnimplementedGnuApiMethod("process_user_Renviron");
/*      */   }
/*      */   
/*      */   public static SEXP Rf_promiseArgs(SEXP p0, SEXP p1) {
/*  801 */     throw new UnimplementedGnuApiMethod("Rf_promiseArgs");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP R_data_class(SEXP p0, boolean p1) {
/*  807 */     throw new UnimplementedGnuApiMethod("R_data_class");
/*      */   }
/*      */   
/*      */   public static SEXP R_data_class2(SEXP p0) {
/*  811 */     throw new UnimplementedGnuApiMethod("R_data_class2");
/*      */   }
/*      */   
/*      */   public static BytePtr R_LibraryFileName(BytePtr p0, BytePtr p1, int p2) {
/*  815 */     throw new UnimplementedGnuApiMethod("R_LibraryFileName");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP R_NewHashedEnv(SEXP p0, SEXP p1) {
/*  821 */     throw new UnimplementedGnuApiMethod("R_NewHashedEnv");
/*      */   }
/*      */   
/*      */   public static int R_Newhashpjw(BytePtr p0) {
/*  825 */     throw new UnimplementedGnuApiMethod("R_Newhashpjw");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static SEXP R_Primitive(BytePtr p0) {
/*  832 */     return R_Primitive((Ptr)p0);
/*      */   }
/*      */   
/*      */   public static SEXP R_Primitive(Ptr name) {
/*  836 */     return (SEXP)Primitives.getPrimitive(Symbol.get(Stdlib.nullTerminatedString(name)));
/*      */   }
/*      */   
/*      */   public static void R_RestoreGlobalEnv() {
/*  840 */     throw new UnimplementedGnuApiMethod("R_RestoreGlobalEnv");
/*      */   }
/*      */   
/*      */   public static void R_RestoreGlobalEnvFromFile(BytePtr p0, boolean p1) {
/*  844 */     throw new UnimplementedGnuApiMethod("R_RestoreGlobalEnvFromFile");
/*      */   }
/*      */   
/*      */   public static void R_SaveGlobalEnv() {
/*  848 */     throw new UnimplementedGnuApiMethod("R_SaveGlobalEnv");
/*      */   }
/*      */   
/*      */   public static void R_SaveGlobalEnvToFile(BytePtr p0) {
/*  852 */     throw new UnimplementedGnuApiMethod("R_SaveGlobalEnvToFile");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean R_seemsOldStyleS4Object(SEXP object) {
/*  860 */     throw new UnimplementedGnuApiMethod("R_seemsOldStyleS4Object");
/*      */   }
/*      */   
/*      */   public static int R_SetOptionWarn(int p0) {
/*  864 */     throw new UnimplementedGnuApiMethod("R_SetOptionWarn");
/*      */   }
/*      */   
/*      */   public static int R_SetOptionWidth(int p0) {
/*  868 */     throw new UnimplementedGnuApiMethod("R_SetOptionWidth");
/*      */   }
/*      */   
/*      */   public static void R_Suicide(BytePtr p0) {
/*  872 */     throw new UnimplementedGnuApiMethod("R_Suicide");
/*      */   }
/*      */   
/*      */   public static void R_getProcTime(DoublePtr data) {
/*  876 */     throw new UnimplementedGnuApiMethod("R_getProcTime");
/*      */   }
/*      */   
/*      */   public static int R_isMissing(SEXP symbol, SEXP rho) {
/*  880 */     throw new UnimplementedGnuApiMethod("R_isMissing");
/*      */   }
/*      */   
/*      */   public static BytePtr Rf_sexptype2char(int type) {
/*  884 */     throw new UnimplementedGnuApiMethod("Rf_sexptype2char");
/*      */   }
/*      */   
/*      */   public static void Rf_sortVector(SEXP p0, boolean p1) {
/*  888 */     throw new UnimplementedGnuApiMethod("Rf_sortVector");
/*      */   }
/*      */   
/*      */   public static void Rf_SrcrefPrompt(BytePtr p0, SEXP p1) {
/*  892 */     throw new UnimplementedGnuApiMethod("Rf_SrcrefPrompt");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static int Rf_StrToInternal(BytePtr p0) {
/*  898 */     throw new UnimplementedGnuApiMethod("Rf_StrToInternal");
/*      */   }
/*      */   
/*      */   public static SEXP Rf_strmat2intmat(SEXP p0, SEXP p1, SEXP p2) {
/*  902 */     throw new UnimplementedGnuApiMethod("Rf_strmat2intmat");
/*      */   }
/*      */   
/*      */   public static SEXP Rf_substituteList(SEXP p0, SEXP p1) {
/*  906 */     throw new UnimplementedGnuApiMethod("Rf_substituteList");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean Rf_tsConform(SEXP p0, SEXP p1) {
/*  912 */     throw new UnimplementedGnuApiMethod("Rf_tsConform");
/*      */   }
/*      */   
/*      */   public static SEXP Rf_tspgets(SEXP p0, SEXP p1) {
/*  916 */     throw new UnimplementedGnuApiMethod("Rf_tspgets");
/*      */   }
/*      */   
/*      */   public static SEXP Rf_type2symbol(int p0) {
/*  920 */     throw new UnimplementedGnuApiMethod("Rf_type2symbol");
/*      */   }
/*      */   
/*      */   public static void Rf_unbindVar(SEXP p0, SEXP p1) {
/*  924 */     throw new UnimplementedGnuApiMethod("Rf_unbindVar");
/*      */   }
/*      */   
/*      */   public static SEXP R_LookupMethod(SEXP p0, SEXP p1, SEXP p2, SEXP p3) {
/*  928 */     throw new UnimplementedGnuApiMethod("R_LookupMethod");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP Rf_vectorIndex(SEXP p0, SEXP p1, int p2, int p3, int p4, SEXP p5, boolean p6) {
/*  934 */     throw new UnimplementedGnuApiMethod("Rf_vectorIndex");
/*      */   }
/*      */   
/*      */   public static SEXP Rf_ItemName(SEXP p0, int p1) {
/*  938 */     throw new UnimplementedGnuApiMethod("Rf_ItemName");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP R_GetTraceback(int p0) {
/*  946 */     throw new UnimplementedGnuApiMethod("R_GetTraceback");
/*      */   }
/*      */   
/*      */   public static int R_GetMaxVSize() {
/*  950 */     throw new UnimplementedGnuApiMethod("R_GetMaxVSize");
/*      */   }
/*      */   
/*      */   public static void R_SetMaxVSize(int p0) {
/*  954 */     throw new UnimplementedGnuApiMethod("R_SetMaxVSize");
/*      */   }
/*      */   
/*      */   public static int R_GetMaxNSize() {
/*  958 */     throw new UnimplementedGnuApiMethod("R_GetMaxNSize");
/*      */   }
/*      */   
/*      */   public static void R_SetMaxNSize(int p0) {
/*  962 */     throw new UnimplementedGnuApiMethod("R_SetMaxNSize");
/*      */   }
/*      */   
/*      */   public static int R_Decode2Long(BytePtr p, IntPtr ierr) {
/*  966 */     throw new UnimplementedGnuApiMethod("R_Decode2Long");
/*      */   }
/*      */   
/*      */   public static void R_SetPPSize(int p0) {
/*  970 */     throw new UnimplementedGnuApiMethod("R_SetPPSize");
/*      */   }
/*      */   
/*      */   public static int Rstrlen(SEXP p0, int p1) {
/*  974 */     throw new UnimplementedGnuApiMethod("Rstrlen");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BytePtr Rf_EncodeReal2(double p0, int p1, int p2, int p3) {
/*  982 */     throw new UnimplementedGnuApiMethod("Rf_EncodeReal2");
/*      */   }
/*      */   
/*      */   public static BytePtr Rf_EncodeChar(SEXP p0) {
/*  986 */     throw new UnimplementedGnuApiMethod("Rf_EncodeChar");
/*      */   }
/*      */   
/*      */   public static void orderVector1(IntPtr indx, int n, SEXP key, boolean nalast, boolean decreasing, SEXP rho) {
/*  990 */     throw new UnimplementedGnuApiMethod("orderVector1");
/*      */   }
/*      */   
/*      */   public static SEXP R_subset3_dflt(SEXP p0, SEXP p1, SEXP p2) {
/*  994 */     throw new UnimplementedGnuApiMethod("R_subset3_dflt");
/*      */   }
/*      */   
/*      */   public static SEXP R_subassign3_dflt(SEXP p0, SEXP p1, SEXP p2, SEXP p3) {
/*  998 */     throw new UnimplementedGnuApiMethod("R_subassign3_dflt");
/*      */   }
/*      */   
/*      */   public static void UNIMPLEMENTED_TYPE(BytePtr s, SEXP x) {
/* 1002 */     throw new UnimplementedGnuApiMethod("UNIMPLEMENTED_TYPE");
/*      */   }
/*      */   
/*      */   public static void UNIMPLEMENTED_TYPEt(BytePtr s, int t) {
/* 1006 */     throw new UnimplementedGnuApiMethod("UNIMPLEMENTED_TYPEt");
/*      */   }
/*      */   
/*      */   public static boolean Rf_strIsASCII(BytePtr str) {
/* 1010 */     for (int i = 0;; i++) {
/* 1011 */       byte c = str.getByte(i);
/* 1012 */       if (c == 0) {
/*      */         break;
/*      */       }
/*      */       
/* 1016 */       if (c < 0) {
/* 1017 */         return false;
/*      */       }
/*      */     } 
/* 1020 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static int Rf_AdobeSymbol2ucs2(int n) {
/* 1026 */     throw new UnimplementedGnuApiMethod("Rf_AdobeSymbol2ucs2");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP Rf_installTrChar(SEXP x) {
/* 1046 */     if (!(x instanceof GnuCharSexp)) {
/* 1047 */       throw new EvalException("'installTrChar' must be called on 'CHARSXP'", new Object[0]);
/*      */     }
/* 1049 */     BytePtr ptr = ((GnuCharSexp)x).getValue();
/* 1050 */     byte[] allBytes = ptr.getArray();
/* 1051 */     byte[] minusLast = new byte[allBytes.length - 1];
/* 1052 */     for (int i = 0; i < minusLast.length; i++) {
/* 1053 */       minusLast[i] = allBytes[i];
/*      */     }
/* 1055 */     String name = new String(minusLast, StandardCharsets.UTF_8);
/* 1056 */     return (SEXP)Symbol.get(name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean mbcsValid(BytePtr str) {
/* 1064 */     throw new UnimplementedGnuApiMethod("mbcsValid");
/*      */   }
/*      */   
/*      */   public static boolean utf8Valid(BytePtr str) {
/* 1068 */     throw new UnimplementedGnuApiMethod("utf8Valid");
/*      */   }
/*      */   
/*      */   public static BytePtr Rf_strchr(BytePtr s, int c) {
/* 1072 */     throw new UnimplementedGnuApiMethod("Rf_strchr");
/*      */   }
/*      */   
/*      */   public static BytePtr Rf_strrchr(BytePtr s, int c) {
/* 1076 */     throw new UnimplementedGnuApiMethod("Rf_strrchr");
/*      */   }
/*      */   
/*      */   public static SEXP fixup_NaRm(SEXP args) {
/* 1080 */     throw new UnimplementedGnuApiMethod("fixup_NaRm");
/*      */   }
/*      */   
/*      */   public static void invalidate_cached_recodings() {
/* 1084 */     throw new UnimplementedGnuApiMethod("invalidate_cached_recodings");
/*      */   }
/*      */   
/*      */   public static void resetICUcollator() {
/* 1088 */     throw new UnimplementedGnuApiMethod("resetICUcollator");
/*      */   }
/*      */   
/*      */   public static void dt_invalidate_locale() {
/* 1092 */     throw new UnimplementedGnuApiMethod("dt_invalidate_locale");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void reset_duplicate_counter() {
/* 1100 */     throw new UnimplementedGnuApiMethod("reset_duplicate_counter");
/*      */   }
/*      */   
/*      */   public static void Rf_BindDomain(BytePtr p0) {
/* 1104 */     throw new UnimplementedGnuApiMethod("Rf_BindDomain");
/*      */   }
/*      */   
/*      */   public static double R_getClockIncrement() {
/* 1108 */     throw new UnimplementedGnuApiMethod("R_getClockIncrement");
/*      */   }
/*      */   
/*      */   public static void InitDynload() {
/* 1112 */     throw new UnimplementedGnuApiMethod("InitDynload");
/*      */   }
/*      */   
/*      */   public static void R_CleanTempDir() {
/* 1116 */     throw new UnimplementedGnuApiMethod("R_CleanTempDir");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static int Rf_Seql(SEXP a, SEXP b) {
/* 1122 */     throw new UnimplementedGnuApiMethod("Rf_Seql");
/*      */   }
/*      */   
/*      */   public static int Rf_Scollate(SEXP a, SEXP b) {
/* 1126 */     throw new UnimplementedGnuApiMethod("Rf_Scollate");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static double R_atof(BytePtr str) {
/* 1135 */     return R_atof((Ptr)str);
/*      */   }
/*      */   
/*      */   public static double R_atof(Ptr str) {
/* 1139 */     return NumericLiterals.parseDouble(Stdlib.nullTerminatedString(str));
/*      */   }
/*      */   
/*      */   public static void set_rl_word_breaks(BytePtr str) {
/* 1143 */     throw new UnimplementedGnuApiMethod("set_rl_word_breaks");
/*      */   }
/*      */   
/*      */   public static BytePtr locale2charset(BytePtr p0) {
/* 1147 */     throw new UnimplementedGnuApiMethod("locale2charset");
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-gnur-runtime-0.9.2724.jar!/org/renjin/gnur/api/Defn.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */