/*    */ package org.renjin.gnur.api;
/*    */ 
/*    */ import java.lang.invoke.MethodHandle;
/*    */ import org.renjin.gcc.runtime.Ptr;
/*    */ import org.renjin.gcc.runtime.Stdlib;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MethodDef2
/*    */ {
/*    */   public static final int BYTES = 20;
/*    */   public String name;
/*    */   public Ptr types;
/*    */   public int numArgs;
/*    */   public MethodHandle fun;
/*    */   
/*    */   @Deprecated
/*    */   public MethodDef2() {
/* 38 */     throw new RuntimeException("Please recompile this package with the latest version of Renjin.");
/*    */   }
/*    */   
/*    */   public MethodDef2(Ptr ptr) {
/* 42 */     Ptr namePtr = ptr.getPointer(0);
/* 43 */     this.name = namePtr.isNull() ? null : Stdlib.nullTerminatedString(namePtr);
/* 44 */     this.fun = ptr.getPointer(4).toMethodHandle();
/* 45 */     this.numArgs = ptr.getInt(8);
/* 46 */     this.types = ptr.getPointer(12);
/*    */   }
/*    */   
/*    */   public String getName() {
/* 50 */     return this.name;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-gnur-runtime-0.9.2724.jar!/org/renjin/gnur/api/MethodDef2.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */