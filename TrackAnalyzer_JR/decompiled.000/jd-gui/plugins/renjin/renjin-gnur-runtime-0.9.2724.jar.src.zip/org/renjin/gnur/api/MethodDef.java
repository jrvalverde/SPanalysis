/*    */ package org.renjin.gnur.api;
/*    */ 
/*    */ import java.lang.invoke.MethodHandle;
/*    */ import org.renjin.gcc.runtime.BytePtr;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class MethodDef
/*    */ {
/*    */   public byte[] name;
/*    */   public int name$offset;
/*    */   public int[] types;
/*    */   public int types$offset;
/*    */   public int numArgs;
/*    */   public MethodHandle fun;
/*    */   
/*    */   public String getName() {
/* 36 */     return (new BytePtr(this.name, this.name$offset)).nullTerminatedString();
/*    */   }
/*    */   
/*    */   public void set(MethodDef o) {
/* 40 */     this.name = o.name;
/* 41 */     this.name$offset = o.name$offset;
/* 42 */     this.types = o.types;
/* 43 */     this.types$offset = o.types$offset;
/* 44 */     this.numArgs = o.numArgs;
/* 45 */     this.fun = o.fun;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-gnur-runtime-0.9.2724.jar!/org/renjin/gnur/api/MethodDef.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */