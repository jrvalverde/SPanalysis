/*    */ package org.renjin.gnur.api;
/*    */ 
/*    */ import org.renjin.eval.EvalException;
/*    */ import org.renjin.gcc.runtime.DoublePtr;
/*    */ import org.renjin.gcc.runtime.IntPtr;
/*    */ import org.renjin.gcc.runtime.Ptr;
/*    */ import org.renjin.sexp.AtomicVector;
/*    */ import org.renjin.sexp.DoubleArrayVector;
/*    */ import org.renjin.sexp.IntArrayVector;
/*    */ import org.renjin.sexp.LogicalArrayVector;
/*    */ import org.renjin.sexp.Null;
/*    */ import org.renjin.sexp.SEXP;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Rinternals2
/*    */ {
/*    */   public static Ptr INTEGER(SEXP x) {
/* 31 */     if (x instanceof IntArrayVector) {
/* 32 */       return (Ptr)new IntPtr(((IntArrayVector)x).toIntArrayUnsafe());
/*    */     }
/* 34 */     if (x instanceof LogicalArrayVector) {
/* 35 */       return (Ptr)new IntPtr(((LogicalArrayVector)x).toIntArrayUnsafe());
/*    */     }
/*    */     
/* 38 */     if (x == Null.INSTANCE) {
/* 39 */       return (Ptr)new IntPtr(new int[] { 0 });
/*    */     }
/*    */     
/* 42 */     if (x instanceof AtomicVector) {
/* 43 */       return (Ptr)new IntVectorPtr((AtomicVector)x, 0);
/*    */     }
/*    */     
/* 46 */     throw new EvalException("INTEGER(): expected integer vector, found %s", new Object[] { x.getTypeName() });
/*    */   }
/*    */   
/*    */   public static Ptr REAL(SEXP x) {
/* 50 */     if (x instanceof DoubleArrayVector)
/*    */     {
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 56 */       return (Ptr)new DoublePtr(((DoubleArrayVector)x).toDoubleArrayUnsafe()); } 
/* 57 */     if (x instanceof org.renjin.sexp.DoubleVector) {
/* 58 */       return (Ptr)new DoubleVectorPtr((AtomicVector)x, 0);
/*    */     }
/* 60 */     throw new EvalException("REAL(): expected numeric vector, found %s", new Object[] { x.getTypeName() });
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-gnur-runtime-0.9.2724.jar!/org/renjin/gnur/api/Rinternals2.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */