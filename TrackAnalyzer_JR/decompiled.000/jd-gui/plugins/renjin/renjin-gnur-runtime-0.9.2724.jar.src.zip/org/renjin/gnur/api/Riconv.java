/*    */ package org.renjin.gnur.api;
/*    */ 
/*    */ import org.renjin.gcc.runtime.BytePtr;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Riconv
/*    */ {
/*    */   public static Object Riconv_open(BytePtr tocode, BytePtr fromcode) {
/* 30 */     throw new UnimplementedGnuApiMethod("Riconv_open");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static int Riconv_close(Object cd) {
/* 36 */     throw new UnimplementedGnuApiMethod("Riconv_close");
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-gnur-runtime-0.9.2724.jar!/org/renjin/gnur/api/Riconv.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */