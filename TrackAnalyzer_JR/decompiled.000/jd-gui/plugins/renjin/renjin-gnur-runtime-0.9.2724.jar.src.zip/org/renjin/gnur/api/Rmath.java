/*     */ package org.renjin.gnur.api;
/*     */ 
/*     */ import org.renjin.gcc.runtime.DoublePtr;
/*     */ import org.renjin.gcc.runtime.IntPtr;
/*     */ import org.renjin.gcc.runtime.Ptr;
/*     */ import org.renjin.nmath.bessel_i;
/*     */ import org.renjin.nmath.bessel_j;
/*     */ import org.renjin.nmath.bessel_k;
/*     */ import org.renjin.nmath.bessel_y;
/*     */ import org.renjin.nmath.beta;
/*     */ import org.renjin.nmath.choose;
/*     */ import org.renjin.nmath.cospi;
/*     */ import org.renjin.nmath.fmax2;
/*     */ import org.renjin.nmath.fmin2;
/*     */ import org.renjin.nmath.fprec;
/*     */ import org.renjin.nmath.fround;
/*     */ import org.renjin.nmath.fsign;
/*     */ import org.renjin.nmath.gamma;
/*     */ import org.renjin.nmath.imax2;
/*     */ import org.renjin.nmath.imin2;
/*     */ import org.renjin.nmath.lbeta;
/*     */ import org.renjin.nmath.lgamma;
/*     */ import org.renjin.nmath.mlutils;
/*     */ import org.renjin.nmath.polygamma;
/*     */ import org.renjin.nmath.sign;
/*     */ import org.renjin.stats.internals.Distributions;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Rmath
/*     */ {
/*     */   public static double R_pow(double x, double y) {
/*  34 */     return mlutils.R_pow(x, y);
/*     */   }
/*     */   
/*     */   public static double R_pow_di(double x, int n) {
/*  38 */     return mlutils.R_pow_di(x, n);
/*     */   }
/*     */ 
/*     */   
/*     */   public static double norm_rand() {
/*  43 */     throw new UnimplementedGnuApiMethod("norm_rand");
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public static double unif_rand() {
/*  48 */     return Random.unif_rand();
/*     */   }
/*     */   
/*     */   public static double exp_rand() {
/*  52 */     throw new UnimplementedGnuApiMethod("exp_rand");
/*     */   }
/*     */   
/*     */   public static double Rf_dnorm4(double x, double mean, double sd, int log) {
/*  56 */     return Distributions.dnorm(x, mean, sd, (log != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_pnorm5(double q, double mean, double sd, int lowerTail, int logP) {
/*  60 */     return Distributions.pnorm(q, mean, sd, (lowerTail != 0), (logP != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_qnorm5(double q, double mean, double sd, int lowerTail, int logP) {
/*  64 */     return Distributions.qnorm(q, mean, sd, (lowerTail != 0), (logP != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_rnorm(double p0, double p1) {
/*  68 */     throw new UnimplementedGnuApiMethod("Rf_rnorm");
/*     */   }
/*     */   
/*     */   public static void Rf_pnorm_both(double p0, DoublePtr p1, DoublePtr p2, int p3, int p4) {
/*  72 */     throw new UnimplementedGnuApiMethod("Rf_pnorm_both");
/*     */   }
/*     */   
/*     */   public static double Rf_dunif(double x, double min, double max, int log) {
/*  76 */     return Distributions.dunif(x, min, max, (log != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_punif(double q, double min, double max, int lowerTail, int logP) {
/*  80 */     return Distributions.punif(q, min, max, (lowerTail != 0), (logP != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_qunif(double p, double min, double max, int lowerTail, int logP) {
/*  84 */     return Distributions.qunif(p, min, max, (lowerTail != 0), (logP != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_runif(double p0, double p1) {
/*  88 */     throw new UnimplementedGnuApiMethod("Rf_runif");
/*     */   }
/*     */   
/*     */   public static double Rf_dgamma(double x, double shape, double scale, int log) {
/*  92 */     return Distributions.dgamma(x, shape, scale, (log != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_pgamma(double q, double shape, double scale, int lowerTail, int logP) {
/*  96 */     return Distributions.pgamma(q, shape, scale, (lowerTail != 0), (logP != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_qgamma(double p, double shape, double scale, int lowerTail, int logP) {
/* 100 */     return Distributions.qgamma(p, shape, scale, (lowerTail != 0), (logP != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_rgamma(double p0, double p1) {
/* 104 */     throw new UnimplementedGnuApiMethod("Rf_rgamma");
/*     */   }
/*     */   
/*     */   public static double Rf_log1pmx(double p0) {
/* 108 */     throw new UnimplementedGnuApiMethod("Rf_log1pmx");
/*     */   }
/*     */   
/*     */   public static double log1pexp(double p0) {
/* 112 */     throw new UnimplementedGnuApiMethod("log1pexp");
/*     */   }
/*     */   
/*     */   public static double Rf_lgamma1p(double p0) {
/* 116 */     throw new UnimplementedGnuApiMethod("Rf_lgamma1p");
/*     */   }
/*     */   
/*     */   public static double Rf_logspace_add(double p0, double p1) {
/* 120 */     throw new UnimplementedGnuApiMethod("Rf_logspace_add");
/*     */   }
/*     */   
/*     */   public static double Rf_logspace_sub(double p0, double p1) {
/* 124 */     throw new UnimplementedGnuApiMethod("Rf_logspace_sub");
/*     */   }
/*     */   
/*     */   public static double logspace_sum(DoublePtr p0, int p1) {
/* 128 */     throw new UnimplementedGnuApiMethod("logspace_sum");
/*     */   }
/*     */   
/*     */   public static double Rf_dbeta(double x, double shape1, double shape2, int log) {
/* 132 */     return Distributions.dbeta(x, shape1, shape2, (log != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_pbeta(double q, double shape1, double shape2, int lowerTail, int logP) {
/* 136 */     return Distributions.pbeta(q, shape1, shape2, (lowerTail != 0), (logP != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_qbeta(double p, double shape1, double shape2, int lowerTail, int logP) {
/* 140 */     return Distributions.qbeta(p, shape1, shape2, (lowerTail != 0), (logP != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_rbeta(double p0, double p1) {
/* 144 */     throw new UnimplementedGnuApiMethod("Rf_rbeta");
/*     */   }
/*     */   
/*     */   public static double Rf_dlnorm(double x, double meanlog, double sdlog, int log) {
/* 148 */     return Distributions.dlnorm(x, meanlog, sdlog, (log != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_plnorm(double q, double meanlog, double sdlog, int lowerTail, int logP) {
/* 152 */     return Distributions.plnorm(q, meanlog, sdlog, (lowerTail != 0), (logP != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_qlnorm(double p, double meanlog, double sdlog, int lowerTail, int logP) {
/* 156 */     return Distributions.qlnorm(p, meanlog, sdlog, (lowerTail != 0), (logP != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_rlnorm(double p0, double p1) {
/* 160 */     throw new UnimplementedGnuApiMethod("Rf_rlnorm");
/*     */   }
/*     */   
/*     */   public static double Rf_dchisq(double x, double df, int log) {
/* 164 */     return Distributions.dchisq(x, df, (log != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_pchisq(double q, double df, int lowerTail, int logP) {
/* 168 */     return Distributions.pchisq(q, df, (lowerTail != 0), (logP != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_qchisq(double p, double df, int lowerTail, int logP) {
/* 172 */     return Distributions.qchisq(p, df, (lowerTail != 0), (logP != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_rchisq(double p0) {
/* 176 */     throw new UnimplementedGnuApiMethod("Rf_rchisq");
/*     */   }
/*     */   
/*     */   public static double Rf_dnchisq(double x, double df, double ncp, int log) {
/* 180 */     return Distributions.dnchisq(x, df, ncp, (log != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_pnchisq(double q, double df, double ncp, int lowerTail, int logP) {
/* 184 */     return Distributions.pnchisq(q, df, ncp, (lowerTail != 0), (logP != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_qnchisq(double p, double df, double ncp, int lowerTail, int logP) {
/* 188 */     return Distributions.qnchisq(p, df, ncp, (lowerTail != 0), (logP != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_rnchisq(double df, double ncp) {
/* 192 */     throw new UnimplementedGnuApiMethod("Rf_rnchisq");
/*     */   }
/*     */   
/*     */   public static double Rf_df(double x, double df1, double df2, int log) {
/* 196 */     return Distributions.df(x, df1, df2, (log != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_pf(double q, double df1, double df2, int lowerTail, int logP) {
/* 200 */     return Distributions.pf(q, df1, df2, (lowerTail != 0), (logP != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_qf(double p, double df1, double df2, int lowerTail, int logP) {
/* 204 */     return Distributions.qf(p, df1, df2, (lowerTail != 0), (logP != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_rf(double d1, double d2) {
/* 208 */     throw new UnimplementedGnuApiMethod("Rf_rf");
/*     */   }
/*     */   
/*     */   public static double Rf_dt(double x, double df, int log) {
/* 212 */     return Distributions.dt(x, df, (log != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_pt(double q, double df, int lowerTail, int logP) {
/* 216 */     return Distributions.pt(q, df, (lowerTail != 0), (logP != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_qt(double p, double df, int lowerTail, int logP) {
/* 220 */     return Distributions.qt(p, df, (lowerTail != 0), (logP != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_rt(double df) {
/* 224 */     throw new UnimplementedGnuApiMethod("Rf_rt");
/*     */   }
/*     */   
/*     */   public static double Rf_dbinom_raw(double x, double n, double p, double q, int give_log) {
/* 228 */     throw new UnimplementedGnuApiMethod("Rf_dbinom_raw");
/*     */   }
/*     */   
/*     */   public static double Rf_dbinom(double x, double size, double prob, int log) {
/* 232 */     return Distributions.dbinom(x, size, prob, (log != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_pbinom(double q, double size, double prob, int lowerTail, int logP) {
/* 236 */     return Distributions.pbinom(q, size, prob, (lowerTail != 0), (logP != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_qbinom(double p, double size, double prob, int lowerTail, int logP) {
/* 240 */     return Distributions.qbinom(p, size, prob, (lowerTail != 0), (logP != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_rbinom(double p0, double p1) {
/* 244 */     throw new UnimplementedGnuApiMethod("Rf_rbinom");
/*     */   }
/*     */   
/*     */   public static void Rf_rmultinom(int p0, DoublePtr p1, int p2, IntPtr p3) {
/* 248 */     throw new UnimplementedGnuApiMethod("Rf_rmultinom");
/*     */   }
/*     */   
/*     */   public static double Rf_dcauchy(double x, double location, double scale, int log) {
/* 252 */     return Distributions.dcauchy(x, location, scale, (log != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_pcauchy(double q, double location, double scale, int lowerTail, int logP) {
/* 256 */     return Distributions.pcauchy(q, location, scale, (lowerTail != 0), (logP != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_qcauchy(double p, double location, double scale, int lowerTail, int logP) {
/* 260 */     return Distributions.qcauchy(p, location, scale, (lowerTail != 0), (logP != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_rcauchy(double p0, double p1) {
/* 264 */     throw new UnimplementedGnuApiMethod("Rf_rcauchy");
/*     */   }
/*     */   
/*     */   public static double Rf_dexp(double x, double scale, int log) {
/* 268 */     return Distributions.dexp(x, scale, (log != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_pexp(double q, double scale, int lowerTail, int logP) {
/* 272 */     return Distributions.pexp(q, scale, (lowerTail != 0), (logP != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_qexp(double p, double scale, int lowerTail, int logP) {
/* 276 */     return Distributions.qexp(p, scale, (lowerTail != 0), (logP != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_rexp(double p0) {
/* 280 */     throw new UnimplementedGnuApiMethod("Rf_rexp");
/*     */   }
/*     */   
/*     */   public static double Rf_dgeom(double x, double prob, int log) {
/* 284 */     return Distributions.dgeom(x, prob, (log != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_pgeom(double q, double prob, int lowerTail, int logP) {
/* 288 */     return Distributions.pgeom(q, prob, (lowerTail != 0), (logP != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_qgeom(double p, double prob, int lowerTail, int logP) {
/* 292 */     return Distributions.qgeom(p, prob, (lowerTail != 0), (logP != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_rgeom(double p0) {
/* 296 */     throw new UnimplementedGnuApiMethod("Rf_rgeom");
/*     */   }
/*     */   
/*     */   public static double Rf_dhyper(double x, double m, double n, double k, int log) {
/* 300 */     return Distributions.dhyper(x, m, n, k, (log != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_phyper(double q, double m, double n, double k, int lowerTail, int logP) {
/* 304 */     return Distributions.phyper(q, m, n, k, (lowerTail != 0), (logP != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_qhyper(double p, double m, double n, double k, int lowerTail, int logP) {
/* 308 */     return Distributions.qhyper(p, m, n, k, (lowerTail != 0), (logP != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_rhyper(double p0, double p1, double p2) {
/* 312 */     throw new UnimplementedGnuApiMethod("Rf_rhyper");
/*     */   }
/*     */   
/*     */   public static double Rf_dnbinom(double x, double size, double prob, int log) {
/* 316 */     return Distributions.dnbinom(x, size, prob, (log != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_pnbinom(double q, double size, double prob, int lowerTail, int logP) {
/* 320 */     return Distributions.pnbinom(q, size, prob, (lowerTail != 0), (logP != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_qnbinom(double p, double size, double prob, int lowerTail, int logP) {
/* 324 */     return Distributions.qnbinom(p, size, prob, (lowerTail != 0), (logP != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_rnbinom(double p0, double p1) {
/* 328 */     throw new UnimplementedGnuApiMethod("Rf_rnbinom");
/*     */   }
/*     */   
/*     */   public static double Rf_dnbinom_mu(double x, double size, double mu, int log) {
/* 332 */     return Distributions.dnbinom_mu(x, size, mu, (log != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_pnbinom_mu(double q, double size, double mu, int lowerTail, int logP) {
/* 336 */     return Distributions.pnbinom_mu(q, size, mu, (lowerTail != 0), (logP != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_qnbinom_mu(double p, double size, double mu, int lowerTail, int logP) {
/* 340 */     return Distributions.qnbinom_mu(p, size, mu, (lowerTail != 0), (logP != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_rnbinom_mu(double p0, double p1) {
/* 344 */     throw new UnimplementedGnuApiMethod("Rf_rnbinom_mu");
/*     */   }
/*     */   
/*     */   public static double Rf_dpois_raw(double x, double lambda, int log) {
/* 348 */     throw new UnimplementedGnuApiMethod("Rf_dpois_raw");
/*     */   }
/*     */   
/*     */   public static double Rf_dpois(double x, double lambda, int log) {
/* 352 */     return Distributions.dpois(x, lambda, (log != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_ppois(double q, double lambda, int lowerTail, int logP) {
/* 356 */     return Distributions.ppois(q, lambda, (lowerTail != 0), (logP != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_qpois(double p, double lambda, int lowerTail, int logP) {
/* 360 */     return Distributions.qpois(p, lambda, (lowerTail != 0), (logP != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_rpois(double p0) {
/* 364 */     throw new UnimplementedGnuApiMethod("Rf_rpois");
/*     */   }
/*     */   
/*     */   public static double Rf_dweibull(double x, double shape, double scale, int log) {
/* 368 */     return Distributions.dweibull(x, shape, scale, (log != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_pweibull(double q, double shape, double scale, int lowerTail, int logP) {
/* 372 */     return Distributions.pweibull(q, shape, scale, (lowerTail != 0), (logP != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_qweibull(double p, double shape, double scale, int lowerTail, int logP) {
/* 376 */     return Distributions.qweibull(p, shape, scale, (lowerTail != 0), (logP != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_rweibull(double p0, double p1) {
/* 380 */     throw new UnimplementedGnuApiMethod("Rf_rweibull");
/*     */   }
/*     */   
/*     */   public static double Rf_dlogis(double x, double location, double scale, int log) {
/* 384 */     return Distributions.dlogis(x, location, scale, (log != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_plogis(double q, double location, double scale, int lowerTail, int logP) {
/* 388 */     return Distributions.plogis(q, location, scale, (lowerTail != 0), (logP != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_qlogis(double p, double location, double scale, int lowerTail, int logP) {
/* 392 */     return Distributions.qlogis(p, location, scale, (lowerTail != 0), (logP != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_rlogis(double p0, double p1) {
/* 396 */     throw new UnimplementedGnuApiMethod("Rf_rlogis");
/*     */   }
/*     */   
/*     */   public static double Rf_dnbeta(double x, double shape1, double shape2, double ncp, int log) {
/* 400 */     return Distributions.dnbeta(x, shape1, shape2, ncp, (log != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_pnbeta(double q, double shape1, double shape2, double ncp, int lowerTail, int logP) {
/* 404 */     return Distributions.pnbeta(q, shape1, shape2, ncp, (lowerTail != 0), (logP != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_qnbeta(double p, double shape1, double shape2, double ncp, int lowerTail, int logP) {
/* 408 */     return Distributions.qnbeta(p, shape1, shape2, ncp, (lowerTail != 0), (logP != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_rnbeta(double p0, double p1, double p2) {
/* 412 */     throw new UnimplementedGnuApiMethod("Rf_rnbeta");
/*     */   }
/*     */   
/*     */   public static double Rf_dnf(double x, double df1, double df2, double ncp, int log) {
/* 416 */     return Distributions.dnf(x, df1, df2, ncp, (log != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_pnf(double q, double df1, double df2, double ncp, int lowerTail, int logP) {
/* 420 */     return Distributions.pnf(q, df1, df2, ncp, (lowerTail != 0), (logP != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_qnf(double p, double df1, double df2, double ncp, int lowerTail, int logP) {
/* 424 */     return Distributions.qnf(p, df1, df2, ncp, (lowerTail != 0), (logP != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_dnt(double x, double df, double ncp, int log) {
/* 428 */     return Distributions.dnt(x, df, ncp, (log != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_pnt(double q, double df, double ncp, int lowerTail, int logP) {
/* 432 */     return Distributions.pnt(q, df, ncp, (lowerTail != 0), (logP != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_qnt(double p, double df, double ncp, int lowerTail, int logP) {
/* 436 */     return Distributions.qnt(p, df, ncp, (lowerTail != 0), (logP != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_ptukey(double q, double nranges, double nmeans, double df, int lowerTail, int logP) {
/* 440 */     return Distributions.ptukey(q, nranges, nmeans, df, (lowerTail != 0), (logP != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_qtukey(double p, double nranges, double nmeans, double df, int lowerTail, int logP) {
/* 444 */     return Distributions.qtukey(p, nranges, nmeans, df, (lowerTail != 0), (logP != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_dwilcox(double x, double m, double n, int log) {
/* 448 */     return Distributions.dwilcox(x, m, n, (log != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_pwilcox(double q, double m, double n, int lowerTail, int logP) {
/* 452 */     return Distributions.pwilcox(q, m, n, (lowerTail != 0), (logP != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_qwilcox(double p, double m, double n, int lowerTail, int logP) {
/* 456 */     return Distributions.qwilcox(p, m, n, (lowerTail != 0), (logP != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_rwilcox(double p0, double p1) {
/* 460 */     throw new UnimplementedGnuApiMethod("Rf_rwilcox");
/*     */   }
/*     */   
/*     */   public static double Rf_dsignrank(double x, double n, int log) {
/* 464 */     return Distributions.dsignrank(x, n, (log != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_psignrank(double q, double n, int lowerTail, int logP) {
/* 468 */     return Distributions.psignrank(q, n, (lowerTail != 0), (logP != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_qsignrank(double p, double n, int lowerTail, int logP) {
/* 472 */     return Distributions.qsignrank(p, n, (lowerTail != 0), (logP != 0));
/*     */   }
/*     */   
/*     */   public static double Rf_rsignrank(double p0) {
/* 476 */     throw new UnimplementedGnuApiMethod("Rf_rsignrank");
/*     */   }
/*     */   
/*     */   public static double Rf_gammafn(double p0) {
/* 480 */     return gamma.gammafn(p0);
/*     */   }
/*     */   
/*     */   public static double Rf_lgammafn(double p0) {
/* 484 */     return lgamma.lgammafn(p0);
/*     */   }
/*     */   
/*     */   public static double Rf_lgammafn_sign(double p0, IntPtr p1) {
/* 488 */     return lgamma.lgammafn_sign(p0, (Ptr)p1);
/*     */   }
/*     */   
/*     */   public static void Rf_dpsifn(double p0, int p1, int p2, int p3, DoublePtr p4, IntPtr p5, IntPtr p6) {
/* 492 */     throw new UnimplementedGnuApiMethod("Rf_dpsifn");
/*     */   }
/*     */   
/*     */   public static double Rf_psigamma(double p0, double p1) {
/* 496 */     return polygamma.psigamma(p0, p1);
/*     */   }
/*     */   
/*     */   public static double Rf_digamma(double p0) {
/* 500 */     return polygamma.digamma(p0);
/*     */   }
/*     */   
/*     */   public static double Rf_trigamma(double p0) {
/* 504 */     return polygamma.trigamma(p0);
/*     */   }
/*     */   
/*     */   public static double Rf_tetragamma(double p0) {
/* 508 */     return polygamma.tetragamma(p0);
/*     */   }
/*     */   
/*     */   public static double Rf_pentagamma(double p0) {
/* 512 */     return polygamma.pentagamma(p0);
/*     */   }
/*     */   
/*     */   public static double Rf_beta(double p0, double p1) {
/* 516 */     return beta.beta(p0, p1);
/*     */   }
/*     */   
/*     */   public static double Rf_lbeta(double p0, double p1) {
/* 520 */     return lbeta.lbeta(p0, p1);
/*     */   }
/*     */   
/*     */   public static double Rf_choose(double p0, double p1) {
/* 524 */     return choose.choose(p0, p1);
/*     */   }
/*     */   
/*     */   public static double Rf_lchoose(double p0, double p1) {
/* 528 */     return choose.lchoose(p0, p1);
/*     */   }
/*     */   
/*     */   public static double Rf_bessel_i(double p0, double p1, double p2) {
/* 532 */     return bessel_i.bessel_i(p0, p1, p2);
/*     */   }
/*     */   
/*     */   public static double Rf_bessel_j(double p0, double p1) {
/* 536 */     return bessel_j.bessel_j(p0, p1);
/*     */   }
/*     */   
/*     */   public static double Rf_bessel_k(double p0, double p1, double p2) {
/* 540 */     return bessel_k.bessel_k(p0, p1, p2);
/*     */   }
/*     */   
/*     */   public static double Rf_bessel_y(double p0, double p1) {
/* 544 */     return bessel_y.bessel_y(p0, p1);
/*     */   }
/*     */   
/*     */   public static double Rf_bessel_i_ex(double p0, double p1, double p2, DoublePtr p3) {
/* 548 */     return bessel_i.bessel_i_ex(p0, p1, p2, (Ptr)p3);
/*     */   }
/*     */   
/*     */   public static double Rf_bessel_j_ex(double p0, double p1, DoublePtr p2) {
/* 552 */     return bessel_j.bessel_j_ex(p0, p1, (Ptr)p2);
/*     */   }
/*     */   
/*     */   public static double Rf_bessel_k_ex(double p0, double p1, double p2, DoublePtr p3) {
/* 556 */     return bessel_k.bessel_k_ex(p0, p1, p2, (Ptr)p3);
/*     */   }
/*     */   
/*     */   public static double Rf_bessel_y_ex(double p0, double p1, DoublePtr p2) {
/* 560 */     return bessel_y.bessel_y_ex(p0, p1, (Ptr)p2);
/*     */   }
/*     */   
/*     */   public static double Rf_pythag(double p0, double p1) {
/* 564 */     throw new UnimplementedGnuApiMethod("Rf_pythag");
/*     */   }
/*     */   
/*     */   public static int Rf_imax2(int x, int y) {
/* 568 */     return imax2.imax2(x, y);
/*     */   }
/*     */   
/*     */   public static int Rf_imin2(int x, int y) {
/* 572 */     return imin2.imin2(x, y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double Rf_fmax2(double x, double y) {
/* 579 */     return fmax2.fmax2(x, y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double Rf_fmin2(double x, double y) {
/* 586 */     return fmin2.fmin2(x, y);
/*     */   }
/*     */   
/*     */   public static double Rf_sign(double p0) {
/* 590 */     return sign.sign(p0);
/*     */   }
/*     */   
/*     */   public static double Rf_fprec(double p0, double p1) {
/* 594 */     return fprec.fprec(p0, p1);
/*     */   }
/*     */   
/*     */   public static double Rf_fround(double p0, double p1) {
/* 598 */     return fround.fround(p0, p1);
/*     */   }
/*     */   
/*     */   public static double Rf_fsign(double x, double y) {
/* 602 */     return fsign.fsign(x, y);
/*     */   }
/*     */   
/*     */   public static double Rf_ftrunc(double p0) {
/* 606 */     throw new UnimplementedGnuApiMethod("Rf_ftrunc");
/*     */   }
/*     */   
/*     */   public static double cospi(double p0) {
/* 610 */     return cospi.cospi(p0);
/*     */   }
/*     */   
/*     */   public static double sinpi(double p0) {
/* 614 */     return cospi.sinpi(p0);
/*     */   }
/*     */   
/*     */   public static double tanpi(double p0) {
/* 618 */     return cospi.tanpi(p0);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-gnur-runtime-0.9.2724.jar!/org/renjin/gnur/api/Rmath.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */