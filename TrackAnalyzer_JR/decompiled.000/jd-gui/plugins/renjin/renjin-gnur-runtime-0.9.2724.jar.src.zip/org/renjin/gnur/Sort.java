/*     */ package org.renjin.gnur;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import org.renjin.gcc.runtime.DoublePtr;
/*     */ import org.renjin.gcc.runtime.IntPtr;
/*     */ import org.renjin.gcc.runtime.Ptr;
/*     */ import org.renjin.sexp.DoubleVector;
/*     */ import org.renjin.sexp.IntVector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Sort
/*     */ {
/*     */   public static void iPsort2(Ptr x, int lo, int hi, int k) {
/*  40 */     boolean nalast = true;
/*     */     
/*     */     int R;
/*     */     
/*  44 */     for (int L = lo; L < R; ) {
/*  45 */       int v = x.getAlignedInt(k); int i, j;
/*  46 */       for (i = L, j = R; i <= j; ) {
/*  47 */         while (icmp(x.getAlignedInt(i), v, nalast) < 0) {
/*  48 */           i++;
/*     */         }
/*  50 */         while (icmp(v, x.getAlignedInt(j), nalast) < 0) {
/*  51 */           j--;
/*     */         }
/*  53 */         if (i <= j) {
/*  54 */           int w = x.getAlignedInt(i);
/*  55 */           x.setAlignedInt(i++, x.getAlignedInt(j));
/*  56 */           x.setAlignedInt(j--, w);
/*     */         } 
/*     */       } 
/*  59 */       if (j < k) {
/*  60 */         L = i;
/*     */       }
/*  62 */       if (k < i) {
/*  63 */         R = j;
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void rPsort2(Ptr x, int lo, int hi, int k) {
/*  69 */     boolean nalast = true;
/*     */     
/*     */     int R;
/*     */     
/*  73 */     for (int L = lo; L < R; ) {
/*  74 */       double v = x.getAlignedDouble(k); int i, j;
/*  75 */       for (i = L, j = R; i <= j; ) {
/*  76 */         while (rcmp(x.getAlignedDouble(i), v, nalast) < 0) {
/*  77 */           i++;
/*     */         }
/*  79 */         while (rcmp(v, x.getAlignedDouble(j), nalast) < 0) {
/*  80 */           j--;
/*     */         }
/*  82 */         if (i <= j) {
/*  83 */           double w = x.getAlignedDouble(i);
/*  84 */           x.setAlignedDouble(i++, x.getAlignedDouble(j));
/*  85 */           x.setAlignedDouble(j--, w);
/*     */         } 
/*     */       } 
/*  88 */       if (j < k) {
/*  89 */         L = i;
/*     */       }
/*  91 */       if (k < i) {
/*  92 */         R = j;
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void Rf_iPsort(Ptr x, int n, int k) {
/*  98 */     iPsort2(x, 0, n - 1, k);
/*     */   }
/*     */   
/*     */   public static void Rf_rPsort(Ptr x, int n, int k) {
/* 102 */     rPsort2(x, 0, n - 1, k);
/*     */   }
/*     */   
/*     */   public static void R_isort(IntPtr x, int n) {
/* 106 */     Arrays.sort(x.array, x.offset, x.offset + n);
/*     */   }
/*     */   
/*     */   public static void R_rsort(DoublePtr x, int n) {
/* 110 */     Arrays.sort(x.array, x.offset, x.offset + n);
/*     */   }
/*     */   
/*     */   private static int icmp(int x, int y, boolean nalast) {
/* 114 */     boolean nax = IntVector.isNA(x), nay = IntVector.isNA(y);
/* 115 */     if (nax && nay) {
/* 116 */       return 0;
/*     */     }
/* 118 */     if (nax) {
/* 119 */       return nalast ? 1 : -1;
/*     */     }
/* 121 */     if (nay) {
/* 122 */       return nalast ? -1 : 1;
/*     */     }
/* 124 */     if (x < y) {
/* 125 */       return -1;
/*     */     }
/* 127 */     if (x > y) {
/* 128 */       return 1;
/*     */     }
/* 130 */     return 0;
/*     */   }
/*     */   
/*     */   public static int rcmp(double x, double y, boolean nalast) {
/* 134 */     boolean nax = DoubleVector.isNA(x), nay = DoubleVector.isNA(y);
/* 135 */     if (nax && nay) {
/* 136 */       return 0;
/*     */     }
/* 138 */     if (nax) {
/* 139 */       return nalast ? 1 : -1;
/*     */     }
/* 141 */     if (nay) {
/* 142 */       return nalast ? -1 : 1;
/*     */     }
/* 144 */     if (x < y) {
/* 145 */       return -1;
/*     */     }
/* 147 */     if (x > y) {
/* 148 */       return 1;
/*     */     }
/* 150 */     return 0;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-gnur-runtime-0.9.2724.jar!/org/renjin/gnur/Sort.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */