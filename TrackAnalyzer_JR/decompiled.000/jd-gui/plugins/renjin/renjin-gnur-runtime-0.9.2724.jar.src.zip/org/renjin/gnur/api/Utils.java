/*     */ package org.renjin.gnur.api;
/*     */ 
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import org.renjin.eval.EvalException;
/*     */ import org.renjin.gcc.annotations.Noop;
/*     */ import org.renjin.gcc.runtime.BytePtr;
/*     */ import org.renjin.gcc.runtime.DoublePtr;
/*     */ import org.renjin.gcc.runtime.IntPtr;
/*     */ import org.renjin.gcc.runtime.Ptr;
/*     */ import org.renjin.gnur.Sort;
/*     */ import org.renjin.gnur.qsort;
/*     */ import org.renjin.primitives.files.Files;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Utils
/*     */ {
/*     */   public static void R_isort(IntPtr p0, int p1) {
/*  42 */     Sort.R_isort(p0, p1);
/*     */   }
/*     */   
/*     */   public static void R_rsort(DoublePtr p0, int p1) {
/*  46 */     Sort.R_rsort(p0, p1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void rsort_with_index(DoublePtr x, IntPtr indx, int n) {
/*  55 */     int h = 1;
/*  56 */     boolean loop = true;
/*  57 */     while (loop) {
/*  58 */       if (h <= n / 9) {
/*  59 */         loop = false;
/*     */       }
/*  61 */       h = 3 * h + 1;
/*     */     } 
/*     */     
/*  64 */     for (; h > 0; h /= 3) {
/*  65 */       for (int i = h; i < n; i++) {
/*  66 */         double v = x.getDouble(i);
/*  67 */         int iv = indx.getInt(i);
/*  68 */         int j = i;
/*  69 */         while (j >= h && Sort.rcmp(x.getDouble(j - h), v, true) > 0) {
/*  70 */           x.set(j, x.getDouble(j - h));
/*  71 */           indx.setInt(j, indx.getInt(j - h));
/*  72 */           j -= h;
/*     */         } 
/*  74 */         x.set(j, v);
/*  75 */         indx.setInt(j, iv);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void Rf_revsort(DoublePtr p0, IntPtr p1, int p2) {
/*  81 */     throw new UnimplementedGnuApiMethod("Rf_revsort");
/*     */   }
/*     */   
/*     */   public static void Rf_iPsort(IntPtr p0, int p1, int p2) {
/*  85 */     Sort.Rf_iPsort((Ptr)p0, p1, p2);
/*     */   }
/*     */   
/*     */   public static void Rf_rPsort(DoublePtr p0, int p1, int p2) {
/*  89 */     Sort.Rf_rPsort((Ptr)p0, p1, p2);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void R_qsort(DoublePtr v, int i, int j) {
/*  95 */     qsort.R_qsort((Ptr)v, i, j);
/*     */   }
/*     */   
/*     */   public static void R_qsort_I(DoublePtr v, IntPtr II, int i, int j) {
/*  99 */     qsort.R_qsort_I((Ptr)v, (Ptr)II, i, j);
/*     */   }
/*     */   
/*     */   public static void R_qsort_int(IntPtr iv, int i, int j) {
/* 103 */     qsort.R_qsort_int((Ptr)iv, i, j);
/*     */   }
/*     */   
/*     */   public static void R_qsort_int_I(IntPtr iv, IntPtr II, int i, int j) {
/* 107 */     qsort.R_qsort_int_I((Ptr)iv, (Ptr)II, i, j);
/*     */   }
/*     */   
/*     */   public static BytePtr R_ExpandFileName(BytePtr p0) {
/* 111 */     return BytePtr.nullTerminatedString(Files.pathExpand(p0.nullTerminatedString()), StandardCharsets.UTF_8);
/*     */   }
/*     */   
/*     */   public static void Rf_setIVector(IntPtr p0, int p1, int p2) {
/* 115 */     throw new UnimplementedGnuApiMethod("Rf_setIVector");
/*     */   }
/*     */   
/*     */   public static void Rf_setRVector(DoublePtr p0, int p1, double p2) {
/* 119 */     throw new UnimplementedGnuApiMethod("Rf_setRVector");
/*     */   }
/*     */   
/*     */   public static boolean Rf_StringFalse(BytePtr p0) {
/* 123 */     throw new UnimplementedGnuApiMethod("Rf_StringFalse");
/*     */   }
/*     */   
/*     */   public static boolean Rf_StringTrue(BytePtr p0) {
/* 127 */     throw new UnimplementedGnuApiMethod("Rf_StringTrue");
/*     */   }
/*     */   
/*     */   public static boolean Rf_isBlankString(BytePtr p0) {
/* 131 */     throw new UnimplementedGnuApiMethod("Rf_isBlankString");
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public static double R_atof(BytePtr str) {
/* 136 */     return Defn.R_atof((Ptr)str);
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public static double R_atof(Ptr str) {
/* 141 */     return Defn.R_atof(str);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static BytePtr R_tmpnam(BytePtr prefix, BytePtr tempdir) {
/* 147 */     throw new UnimplementedGnuApiMethod("R_tmpnam");
/*     */   }
/*     */   
/*     */   public static BytePtr R_tmpnam2(BytePtr prefix, BytePtr tempdir, BytePtr fileext) {
/* 151 */     throw new UnimplementedGnuApiMethod("R_tmpnam2");
/*     */   }
/*     */   
/*     */   public static void R_CheckUserInterrupt() {
/* 155 */     if (Thread.interrupted()) {
/* 156 */       throw new EvalException("Interrupted.", new Object[0]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Noop
/*     */   public static void R_CheckStack() {}
/*     */ 
/*     */   
/*     */   @Noop
/*     */   public static void R_CheckStack2(int p0) {}
/*     */ 
/*     */   
/*     */   public static int findInterval(DoublePtr xt, int n, double x, boolean rightmost_closed, boolean all_inside, int ilo, IntPtr mflag) {
/* 171 */     throw new UnimplementedGnuApiMethod("findInterval");
/*     */   }
/*     */   
/*     */   public static void find_interv_vec(DoublePtr xt, IntPtr n, DoublePtr x, IntPtr nx, IntPtr rightmost_closed, IntPtr all_inside, IntPtr indx) {
/* 175 */     throw new UnimplementedGnuApiMethod("find_interv_vec");
/*     */   }
/*     */   
/*     */   public static void R_max_col(DoublePtr matrix, IntPtr nr, IntPtr nc, IntPtr maxes, IntPtr ties_meth) {
/* 179 */     throw new UnimplementedGnuApiMethod("R_max_col");
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-gnur-runtime-0.9.2724.jar!/org/renjin/gnur/api/Utils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */