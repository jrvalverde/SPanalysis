/*    */ package org.renjin.gnur.api;
/*    */ 
/*    */ import org.renjin.gcc.runtime.AbstractPtr;
/*    */ import org.renjin.gcc.runtime.OffsetPtr;
/*    */ import org.renjin.gcc.runtime.Ptr;
/*    */ import org.renjin.sexp.AtomicVector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class IntVectorPtr
/*    */   extends AbstractPtr
/*    */ {
/*    */   private AtomicVector vector;
/*    */   private int offset;
/*    */   
/*    */   public IntVectorPtr(AtomicVector vector, int offset) {
/* 36 */     this.vector = vector;
/* 37 */     this.offset = offset;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object getArray() {
/* 42 */     return this.vector;
/*    */   }
/*    */ 
/*    */   
/*    */   public final int getOffsetInBytes() {
/* 47 */     return this.offset * 4;
/*    */   }
/*    */ 
/*    */   
/*    */   public Ptr realloc(int newSizeInBytes) {
/* 52 */     throw new UnsupportedOperationException("TODO");
/*    */   }
/*    */ 
/*    */   
/*    */   public Ptr pointerPlus(int bytes) {
/* 57 */     if (bytes == 0) {
/* 58 */       return (Ptr)this;
/*    */     }
/* 60 */     if (bytes % 4 == 0) {
/* 61 */       return (Ptr)new IntVectorPtr(this.vector, this.offset + bytes / 4);
/*    */     }
/* 63 */     return (Ptr)new OffsetPtr((Ptr)this, bytes);
/*    */   }
/*    */ 
/*    */   
/*    */   public int getAlignedInt(int index) {
/* 68 */     return this.vector.getElementAsInt(this.offset + index);
/*    */   }
/*    */ 
/*    */   
/*    */   public int getInt(int offset) {
/* 73 */     if (offset % 4 == 0) {
/* 74 */       return getAlignedInt(offset / 4);
/*    */     }
/* 76 */     return super.getInt(offset);
/*    */   }
/*    */ 
/*    */   
/*    */   public byte getByte(int offset) {
/* 81 */     return getByteViaInt(offset);
/*    */   }
/*    */ 
/*    */   
/*    */   public void setByte(int offset, byte value) {
/* 86 */     throw new UnsupportedOperationException("Illegal modification of a shared vector! Mis-behaving C/C++ code has tried to modify a vector that it should not.");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int toInt() {
/* 92 */     return this.offset * 4;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isNull() {
/* 97 */     return false;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-gnur-runtime-0.9.2724.jar!/org/renjin/gnur/api/IntVectorPtr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */