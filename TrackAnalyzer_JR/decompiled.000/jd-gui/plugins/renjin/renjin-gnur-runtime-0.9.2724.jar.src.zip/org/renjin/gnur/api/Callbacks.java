/*    */ package org.renjin.gnur.api;
/*    */ 
/*    */ import org.renjin.gcc.runtime.BytePtr;
/*    */ import org.renjin.sexp.SEXP;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Callbacks
/*    */ {
/*    */   public static boolean Rf_removeTaskCallbackByIndex(int id) {
/* 36 */     throw new UnimplementedGnuApiMethod("Rf_removeTaskCallbackByIndex");
/*    */   }
/*    */   
/*    */   public static boolean Rf_removeTaskCallbackByName(BytePtr name) {
/* 40 */     throw new UnimplementedGnuApiMethod("Rf_removeTaskCallbackByName");
/*    */   }
/*    */   
/*    */   public static SEXP R_removeTaskCallback(SEXP which) {
/* 44 */     throw new UnimplementedGnuApiMethod("R_removeTaskCallback");
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-gnur-runtime-0.9.2724.jar!/org/renjin/gnur/api/Callbacks.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */