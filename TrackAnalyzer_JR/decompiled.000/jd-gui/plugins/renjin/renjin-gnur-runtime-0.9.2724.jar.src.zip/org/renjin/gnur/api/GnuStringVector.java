/*    */ package org.renjin.gnur.api;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import org.renjin.sexp.AttributeMap;
/*    */ import org.renjin.sexp.SEXP;
/*    */ import org.renjin.sexp.StringVector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GnuStringVector
/*    */   extends StringVector
/*    */ {
/*    */   private GnuCharSexp[] values;
/*    */   
/*    */   public GnuStringVector(String string) {
/* 34 */     this(new GnuCharSexp[] { GnuCharSexp.valueOf(string) });
/*    */   }
/*    */   
/*    */   public GnuStringVector(GnuCharSexp... values) {
/* 38 */     this(values, AttributeMap.EMPTY);
/*    */   }
/*    */   
/*    */   public GnuStringVector(GnuCharSexp[] values, AttributeMap attributes) {
/* 42 */     super(attributes);
/* 43 */     this.values = values;
/*    */   }
/*    */   
/*    */   public static GnuStringVector copyOf(StringVector vector) {
/* 47 */     if (vector instanceof GnuStringVector) {
/* 48 */       return new GnuStringVector(Arrays.<GnuCharSexp>copyOf(((GnuStringVector)vector).values, vector.length()));
/*    */     }
/* 50 */     GnuCharSexp[] values = new GnuCharSexp[vector.length()];
/* 51 */     for (int i = 0; i < values.length; i++) {
/* 52 */       values[i] = GnuCharSexp.valueOf(vector.getElementAsString(i));
/*    */     }
/* 54 */     return new GnuStringVector(values);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int length() {
/* 60 */     return this.values.length;
/*    */   }
/*    */ 
/*    */   
/*    */   protected StringVector cloneWithNewAttributes(AttributeMap attributes) {
/* 65 */     return new GnuStringVector(this.values, attributes);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getElementAsString(int index) {
/* 70 */     GnuCharSexp value = this.values[index];
/* 71 */     if (value == GnuCharSexp.NA_STRING) {
/* 72 */       return null;
/*    */     }
/* 74 */     return value.getValue().nullTerminatedString();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isElementNA(int index) {
/* 80 */     return (this.values[index] == null);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isConstantAccessTime() {
/* 85 */     return true;
/*    */   }
/*    */   
/*    */   public void set(int index, GnuCharSexp charValue) {
/* 89 */     this.values[index] = charValue;
/*    */   }
/*    */   
/*    */   public GnuCharSexp getElementAsCharSexp(int index) {
/* 93 */     return this.values[index];
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-gnur-runtime-0.9.2724.jar!/org/renjin/gnur/api/GnuStringVector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */