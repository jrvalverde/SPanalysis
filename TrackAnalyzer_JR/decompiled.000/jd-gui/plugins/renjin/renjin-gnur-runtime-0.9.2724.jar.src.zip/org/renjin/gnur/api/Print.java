/*    */ package org.renjin.gnur.api;
/*    */ 
/*    */ import org.renjin.gcc.runtime.BytePtr;
/*    */ import org.renjin.gcc.runtime.DoublePtr;
/*    */ import org.renjin.gcc.runtime.IntPtr;
/*    */ import org.renjin.gcc.runtime.MixedPtr;
/*    */ import org.renjin.gcc.runtime.Ptr;
/*    */ import org.renjin.gcc.runtime.Stdlib;
/*    */ import org.renjin.sexp.SEXP;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Print
/*    */ {
/* 30 */   public static Ptr R_print = (Ptr)MixedPtr.malloc(52);
/*    */   
/*    */   public static void Rprintf(BytePtr format, Object... formatArgs) {
/* 33 */     Stdlib.printf(format, formatArgs);
/*    */   }
/*    */   
/*    */   public static void REprintf(BytePtr format, Object... formatArgs) {
/* 37 */     Stdlib.printf(format, formatArgs);
/*    */   }
/*    */   
/*    */   public static void Rf_formatRaw(BytePtr p0, int p1, IntPtr p2) {
/* 41 */     throw new UnimplementedGnuApiMethod("Rf_formatRaw");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static BytePtr Rf_EncodeElement0(SEXP p0, int p1, int p2, BytePtr p3) {
/* 47 */     throw new UnimplementedGnuApiMethod("Rf_EncodeElement0");
/*    */   }
/*    */   
/*    */   public static BytePtr Rf_EncodeEnvironment(SEXP p0) {
/* 51 */     throw new UnimplementedGnuApiMethod("Rf_EncodeEnvironment");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static void Rf_printArray(SEXP p0, SEXP p1, int p2, int p3, SEXP p4) {
/* 57 */     throw new UnimplementedGnuApiMethod("Rf_printArray");
/*    */   }
/*    */   
/*    */   public static void Rf_printMatrix(SEXP p0, int p1, SEXP p2, int p3, int p4, SEXP p5, SEXP p6, BytePtr p7, BytePtr p8) {
/* 61 */     throw new UnimplementedGnuApiMethod("Rf_printMatrix");
/*    */   }
/*    */   
/*    */   public static void Rf_printNamedVector(SEXP p0, SEXP p1, int p2, BytePtr p3) {
/* 65 */     throw new UnimplementedGnuApiMethod("Rf_printNamedVector");
/*    */   }
/*    */   
/*    */   public static void Rf_printVector(SEXP p0, int p1, int p2) {
/* 69 */     throw new UnimplementedGnuApiMethod("Rf_printVector");
/*    */   }
/*    */   
/*    */   public static int dblepr0(BytePtr p0, IntPtr p1, DoublePtr p2, IntPtr p3) {
/* 73 */     throw new UnimplementedGnuApiMethod("dblepr0");
/*    */   }
/*    */   
/*    */   public static int intpr0(BytePtr p0, IntPtr p1, IntPtr p2, IntPtr p3) {
/* 77 */     throw new UnimplementedGnuApiMethod("intpr0");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static void R_PV(SEXP s) {
/* 83 */     throw new UnimplementedGnuApiMethod("R_PV");
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-gnur-runtime-0.9.2724.jar!/org/renjin/gnur/api/Print.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */