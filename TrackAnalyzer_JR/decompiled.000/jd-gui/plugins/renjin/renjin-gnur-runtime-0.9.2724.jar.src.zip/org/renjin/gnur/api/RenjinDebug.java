/*    */ package org.renjin.gnur.api;
/*    */ 
/*    */ import org.renjin.gcc.runtime.BytePtr;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RenjinDebug
/*    */ {
/*    */   public static void dump_double(BytePtr varName, double x) {
/* 26 */     System.out.println(varName.nullTerminatedString() + " = " + x);
/*    */   }
/*    */   
/*    */   public static void dump_int(BytePtr varName, int value) {
/* 30 */     System.out.println(varName.nullTerminatedString() + " = " + value);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-gnur-runtime-0.9.2724.jar!/org/renjin/gnur/api/RenjinDebug.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */