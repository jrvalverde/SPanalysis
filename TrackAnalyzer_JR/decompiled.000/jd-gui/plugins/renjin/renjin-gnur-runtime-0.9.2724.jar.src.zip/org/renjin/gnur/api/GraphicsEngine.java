/*    */ package org.renjin.gnur.api;
/*    */ 
/*    */ import org.renjin.gcc.runtime.DoublePtr;
/*    */ import org.renjin.gcc.runtime.IntPtr;
/*    */ import org.renjin.sexp.SEXP;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class GraphicsEngine
/*    */ {
/*    */   @Deprecated
/*    */   public static int R_GE_getVersion() {
/* 36 */     throw new RuntimeException("Please recompile with the latest version of Renjin.");
/*    */   }
/*    */   
/*    */   @Deprecated
/*    */   public static void R_GE_checkVersionOrDie(int version) {
/* 41 */     throw new RuntimeException("Please recompile with the latest version of Renjin.");
/*    */   }
/*    */   
/*    */   @Deprecated
/*    */   public static void GEPretty(DoublePtr lo, DoublePtr up, IntPtr ndiv) {
/* 46 */     throw new RuntimeException("Please recompile with the latest version of Renjin.");
/*    */   }
/*    */   
/*    */   @Deprecated
/*    */   public static int GEstring_to_pch(SEXP pch) {
/* 51 */     throw new RuntimeException("Please recompile with the latest version of Renjin.");
/*    */   }
/*    */   
/*    */   @Deprecated
/*    */   public static void R_GE_rasterRotatedSize(int w, int h, double angle, IntPtr wnew, IntPtr hnew) {
/* 56 */     throw new RuntimeException("Please recompile with the latest version of Renjin.");
/*    */   }
/*    */   
/*    */   @Deprecated
/*    */   public static void R_GE_rasterRotatedOffset(int w, int h, double angle, int botleft, DoublePtr xoff, DoublePtr yoff) {
/* 61 */     throw new RuntimeException("Please recompile with the latest version of Renjin.");
/*    */   }
/*    */   
/*    */   @Deprecated
/*    */   public static SEXP GEcontourLines(DoublePtr x, int nx, DoublePtr y, int ny, DoublePtr z, DoublePtr levels, int nl) {
/* 66 */     throw new RuntimeException("Please recompile with the latest version of Renjin.");
/*    */   }
/*    */   
/*    */   @Deprecated
/*    */   public static void GEcopyDisplayList(int fromDevice) {
/* 71 */     throw new RuntimeException("Please recompile with the latest version of Renjin.");
/*    */   }
/*    */   
/*    */   @Deprecated
/*    */   public static void GEonExit() {
/* 76 */     throw new RuntimeException("Please recompile with the latest version of Renjin.");
/*    */   }
/*    */   
/*    */   @Deprecated
/*    */   public static void GEnullDevice() {
/* 81 */     throw new RuntimeException("Please recompile with the latest version of Renjin.");
/*    */   }
/*    */   
/*    */   @Deprecated
/*    */   public static SEXP Rf_CreateAtVector(DoublePtr p0, DoublePtr p1, int p2, boolean p3) {
/* 86 */     throw new RuntimeException("Please recompile with the latest version of Renjin.");
/*    */   }
/*    */   
/*    */   @Deprecated
/*    */   public static void Rf_GAxisPars(DoublePtr min, DoublePtr max, IntPtr n, boolean log, int axis) {
/* 91 */     throw new RuntimeException("Please recompile with the latest version of Renjin.");
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-gnur-runtime-0.9.2724.jar!/org/renjin/gnur/api/GraphicsEngine.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */