/*    */ package org.renjin.gnur.api;
/*    */ 
/*    */ import org.renjin.gcc.runtime.BytePtr;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GetText
/*    */ {
/*    */   public static BytePtr gettext(BytePtr message) {
/* 30 */     return message;
/*    */   }
/*    */   
/*    */   public static BytePtr dgettext(BytePtr packageName, BytePtr message) {
/* 34 */     return message;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-gnur-runtime-0.9.2724.jar!/org/renjin/gnur/api/GetText.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */