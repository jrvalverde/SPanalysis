/*    */ package org.renjin.gnur.api;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class R
/*    */ {
/*    */   public static void R_FlushConsole() {
/* 30 */     throw new UnimplementedGnuApiMethod("R_FlushConsole");
/*    */   }
/*    */   
/*    */   public static void R_ProcessEvents() {
/* 34 */     throw new UnimplementedGnuApiMethod("R_ProcessEvents");
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-gnur-runtime-0.9.2724.jar!/org/renjin/gnur/api/R.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */