/*     */ package org.renjin.gnur.api;
/*     */ 
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import org.apache.commons.vfs2.FileContent;
/*     */ import org.apache.commons.vfs2.FileObject;
/*     */ import org.apache.commons.vfs2.FileSystemException;
/*     */ import org.renjin.gcc.runtime.AbstractFileHandle;
/*     */ import org.renjin.gcc.runtime.BytePtr;
/*     */ import org.renjin.gcc.runtime.FileHandle;
/*     */ import org.renjin.gcc.runtime.Ptr;
/*     */ import org.renjin.gcc.runtime.RecordUnitPtr;
/*     */ import org.renjin.gcc.runtime.Stdlib;
/*     */ import org.renjin.primitives.Native;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RenjinFiles
/*     */ {
/*     */   public static Ptr fopen(Ptr filename, Ptr mode) {
/*     */     FileObject fileObject;
/*  41 */     String filenameString = Stdlib.nullTerminatedString(filename);
/*  42 */     String modeString = Stdlib.nullTerminatedString(mode);
/*     */ 
/*     */     
/*     */     try {
/*  46 */       fileObject = Native.currentContext().resolveFile(filenameString);
/*  47 */     } catch (FileSystemException e) {
/*  48 */       return (Ptr)BytePtr.NULL;
/*     */     } 
/*     */     
/*     */     try {
/*  52 */       return (Ptr)new RecordUnitPtr(fopen(fileObject, modeString));
/*     */     }
/*  54 */     catch (IOException e) {
/*  55 */       return (Ptr)BytePtr.NULL;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static FileHandle fopen(FileObject fileObject, String mode) throws FileSystemException {
/*  60 */     switch (mode) {
/*     */       case "r":
/*     */       case "rb":
/*  63 */         return (FileHandle)new InputStreamHandle(fileObject.getContent());
/*     */       
/*     */       case "w":
/*     */       case "wb":
/*  67 */         return (FileHandle)new OutputStreamHandle(fileObject.getContent().getOutputStream());
/*     */     } 
/*     */     
/*  70 */     throw new UnsupportedOperationException("mode: " + mode);
/*     */   }
/*     */   
/*     */   private static class InputStreamHandle
/*     */     extends AbstractFileHandle
/*     */   {
/*     */     private FileContent content;
/*     */     private InputStream inputStream;
/*  78 */     private long position = 0L;
/*     */     
/*     */     public InputStreamHandle(FileContent content) throws FileSystemException {
/*  81 */       this.content = content;
/*  82 */       this.inputStream = content.getInputStream();
/*     */     }
/*     */ 
/*     */     
/*     */     public int read() throws IOException {
/*  87 */       int b = this.inputStream.read();
/*  88 */       if (b != -1) {
/*  89 */         this.position++;
/*     */       }
/*  91 */       return b;
/*     */     }
/*     */ 
/*     */     
/*     */     public void write(int b) throws IOException {
/*  96 */       throw new UnsupportedOperationException("Cannot write on input stream handle.");
/*     */     }
/*     */ 
/*     */     
/*     */     public void rewind() throws IOException {
/* 101 */       this.inputStream.close();
/* 102 */       this.inputStream = this.content.getInputStream();
/* 103 */       this.position = 0L;
/*     */     }
/*     */ 
/*     */     
/*     */     public void flush() throws IOException {
/* 108 */       throw new UnsupportedOperationException("Cannot flush an input stream handle.");
/*     */     }
/*     */ 
/*     */     
/*     */     public void close() throws IOException {
/* 113 */       this.inputStream.close();
/*     */     }
/*     */ 
/*     */     
/*     */     public void seekSet(long offset) throws IOException {
/* 118 */       if (offset < this.position) {
/* 119 */         throw new IOException("Cannot rewind the stream");
/*     */       }
/* 121 */       long toSkip = offset - this.position;
/* 122 */       long skipped = this.inputStream.skip(toSkip);
/* 123 */       if (skipped < toSkip) {
/* 124 */         throw new EOFException();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void seekCurrent(long offset) throws IOException {
/* 130 */       long skipped = this.inputStream.skip(offset);
/* 131 */       if (skipped < offset) {
/* 132 */         throw new EOFException();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void seekEnd(long offset) {
/* 138 */       throw new UnsupportedOperationException("TODO");
/*     */     }
/*     */   }
/*     */   
/*     */   private static class OutputStreamHandle
/*     */     extends AbstractFileHandle {
/*     */     private OutputStream outputStream;
/*     */     
/*     */     public OutputStreamHandle(OutputStream outputStream) {
/* 147 */       this.outputStream = outputStream;
/*     */     }
/*     */ 
/*     */     
/*     */     public int read() throws IOException {
/* 152 */       throw new UnsupportedOperationException("Cannot read from output stream handle.");
/*     */     }
/*     */ 
/*     */     
/*     */     public void write(int b) throws IOException {
/* 157 */       this.outputStream.write(b);
/*     */     }
/*     */ 
/*     */     
/*     */     public void rewind() throws IOException {
/* 162 */       throw new UnsupportedOperationException("TODO");
/*     */     }
/*     */ 
/*     */     
/*     */     public void flush() throws IOException {
/* 167 */       this.outputStream.flush();
/*     */     }
/*     */ 
/*     */     
/*     */     public void close() throws IOException {
/* 172 */       this.outputStream.close();
/*     */     }
/*     */ 
/*     */     
/*     */     public void seekSet(long offset) throws IOException {
/* 177 */       throw new UnsupportedOperationException("TODO");
/*     */     }
/*     */ 
/*     */     
/*     */     public void seekCurrent(long offset) throws IOException {
/* 182 */       throw new UnsupportedOperationException("TODO");
/*     */     }
/*     */ 
/*     */     
/*     */     public void seekEnd(long offset) {
/* 187 */       throw new UnsupportedOperationException("TODO");
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-gnur-runtime-0.9.2724.jar!/org/renjin/gnur/api/RenjinFiles.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */