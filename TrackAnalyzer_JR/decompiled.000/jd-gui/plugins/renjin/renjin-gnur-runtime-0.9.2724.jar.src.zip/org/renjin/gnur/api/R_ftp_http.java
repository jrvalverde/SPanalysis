/*     */ package org.renjin.gnur.api;
/*     */ 
/*     */ import org.renjin.gcc.runtime.BytePtr;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class R_ftp_http
/*     */ {
/*     */   public static Object R_HTTPOpen(BytePtr url) {
/*  32 */     throw new UnimplementedGnuApiMethod("R_HTTPOpen");
/*     */   }
/*     */   
/*     */   public static int R_HTTPRead(Object ctx, BytePtr dest, int len) {
/*  36 */     throw new UnimplementedGnuApiMethod("R_HTTPRead");
/*     */   }
/*     */   
/*     */   public static void R_HTTPClose(Object ctx) {
/*  40 */     throw new UnimplementedGnuApiMethod("R_HTTPClose");
/*     */   }
/*     */   
/*     */   public static Object R_FTPOpen(BytePtr url) {
/*  44 */     throw new UnimplementedGnuApiMethod("R_FTPOpen");
/*     */   }
/*     */   
/*     */   public static int R_FTPRead(Object ctx, BytePtr dest, int len) {
/*  48 */     throw new UnimplementedGnuApiMethod("R_FTPRead");
/*     */   }
/*     */   
/*     */   public static void R_FTPClose(Object ctx) {
/*  52 */     throw new UnimplementedGnuApiMethod("R_FTPClose");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static int RxmlNanoHTTPRead(Object ctx, Object dest, int len) {
/*  58 */     throw new UnimplementedGnuApiMethod("RxmlNanoHTTPRead");
/*     */   }
/*     */   
/*     */   public static void RxmlNanoHTTPClose(Object ctx) {
/*  62 */     throw new UnimplementedGnuApiMethod("RxmlNanoHTTPClose");
/*     */   }
/*     */   
/*     */   public static int RxmlNanoHTTPReturnCode(Object ctx) {
/*  66 */     throw new UnimplementedGnuApiMethod("RxmlNanoHTTPReturnCode");
/*     */   }
/*     */   
/*     */   public static BytePtr RxmlNanoHTTPStatusMsg(Object ctx) {
/*  70 */     throw new UnimplementedGnuApiMethod("RxmlNanoHTTPStatusMsg");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static BytePtr RxmlNanoHTTPContentType(Object ctx) {
/*  76 */     throw new UnimplementedGnuApiMethod("RxmlNanoHTTPContentType");
/*     */   }
/*     */   
/*     */   public static void RxmlNanoHTTPTimeout(int delay) {
/*  80 */     throw new UnimplementedGnuApiMethod("RxmlNanoHTTPTimeout");
/*     */   }
/*     */   
/*     */   public static Object RxmlNanoFTPOpen(BytePtr URL) {
/*  84 */     throw new UnimplementedGnuApiMethod("RxmlNanoFTPOpen");
/*     */   }
/*     */   
/*     */   public static int RxmlNanoFTPRead(Object ctx, Object dest, int len) {
/*  88 */     throw new UnimplementedGnuApiMethod("RxmlNanoFTPRead");
/*     */   }
/*     */   
/*     */   public static int RxmlNanoFTPClose(Object ctx) {
/*  92 */     throw new UnimplementedGnuApiMethod("RxmlNanoFTPClose");
/*     */   }
/*     */   
/*     */   public static void RxmlNanoFTPTimeout(int delay) {
/*  96 */     throw new UnimplementedGnuApiMethod("RxmlNanoFTPTimeout");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void RxmlNanoFTPCleanup() {
/* 104 */     throw new UnimplementedGnuApiMethod("RxmlNanoFTPCleanup");
/*     */   }
/*     */   
/*     */   public static void RxmlNanoHTTPCleanup() {
/* 108 */     throw new UnimplementedGnuApiMethod("RxmlNanoHTTPCleanup");
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-gnur-runtime-0.9.2724.jar!/org/renjin/gnur/api/R_ftp_http.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */