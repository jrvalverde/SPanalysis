/*     */ package org.renjin.gnur;
/*     */ 
/*     */ import org.apache.commons.math.util.FastMath;
/*     */ import org.renjin.eval.EvalException;
/*     */ import org.renjin.gcc.runtime.BytePtr;
/*     */ import org.renjin.gcc.runtime.DoublePtr;
/*     */ import org.renjin.gcc.runtime.FunPtr;
/*     */ import org.renjin.gcc.runtime.IntPtr;
/*     */ import org.renjin.sexp.DoubleVector;
/*     */ import org.renjin.sexp.IntVector;
/*     */ import org.renjin.sexp.SEXP;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class RenjinCApi
/*     */ {
/*  44 */   public static final double R_NaReal = DoubleVector.NA;
/*     */   
/*     */   public static final double R_NaN = NaND;
/*     */   
/*     */   public static final double R_PosInf = InfinityD;
/*     */   
/*     */   public static void warning(BytePtr text) {
/*  51 */     System.out.println(text.nullTerminatedString());
/*     */   }
/*     */   
/*     */   public static void error(BytePtr text) {
/*  55 */     throw new EvalException(text.nullTerminatedString(), new Object[0]);
/*     */   }
/*     */   
/*     */   public static int R_finite(double x) {
/*  59 */     return DoubleVector.isFinite(x) ? 1 : 0;
/*     */   }
/*     */   
/*     */   public static double R_pow(double x, double y) {
/*  63 */     return FastMath.pow(x, y);
/*     */   }
/*     */ 
/*     */   
/*     */   public static double R_pow_di(double x, int n) {
/*  68 */     double xn = 1.0D;
/*     */     
/*  70 */     if (Double.isNaN(x)) {
/*  71 */       return x;
/*     */     }
/*  73 */     if (IntVector.isNA(n)) {
/*  74 */       return DoubleVector.NA;
/*     */     }
/*  76 */     if (n != 0) {
/*  77 */       if (!DoubleVector.isFinite(x)) {
/*  78 */         return R_pow(x, n);
/*     */       }
/*  80 */       boolean isNegative = (n < 0);
/*  81 */       if (isNegative) {
/*  82 */         n = -n;
/*     */       }
/*     */       while (true) {
/*  85 */         if ((n & 0x1) != 0) {
/*  86 */           xn *= x;
/*     */         }
/*  88 */         n >>= 1;
/*  89 */         if (n != 0) {
/*  90 */           x *= x;
/*     */           continue;
/*     */         } 
/*     */         break;
/*     */       } 
/*  95 */       if (isNegative) {
/*  96 */         xn = 1.0D / xn;
/*     */       }
/*     */     } 
/*  99 */     return xn;
/*     */   }
/*     */ 
/*     */   
/*     */   public static int TYPEOF(SEXP sexp) {
/* 104 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public static void Rf_warning(BytePtr text) {
/* 109 */     System.err.println(text.nullTerminatedString());
/*     */   }
/*     */   
/*     */   public static BytePtr gettext(BytePtr message) {
/* 113 */     return message;
/*     */   }
/*     */   
/*     */   public static BytePtr dgettext(BytePtr packageName, BytePtr message) {
/* 117 */     return message;
/*     */   }
/*     */   
/*     */   public static void Rf_error(BytePtr text) {
/* 121 */     throw new RuntimeException(text.nullTerminatedString());
/*     */   }
/*     */   
/*     */   public static int R_IsNA(double x) {
/* 125 */     return DoubleVector.isNA(x) ? 1 : 0;
/*     */   }
/*     */   
/*     */   public static void debugij(int i, int j) {
/* 129 */     System.out.println("i = " + i + ", j = " + j);
/*     */   }
/*     */   
/*     */   public static void debugi(int i) {
/* 133 */     System.out.println("i = " + i);
/*     */   }
/*     */   
/*     */   public static void debugiter(int i) {
/* 137 */     System.out.println("iter = " + i);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void debug(String str) {
/* 143 */     System.out.println(str);
/*     */   }
/*     */   
/*     */   public static int LENGTH(SEXP x) {
/* 147 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public static DoublePtr REAL(SEXP x) {
/* 152 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public static SEXP Rf_coerceVector(SEXP x, int type) {
/* 157 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public static SEXP Rf_protect(SEXP obj) {
/* 162 */     return obj;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void Rf_unprotect(int count) {}
/*     */ 
/*     */   
/*     */   public static SEXP Rf_allocVector(int type, int size) {
/* 170 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void R_CheckUserInterrupt() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public static void rwarn_(BytePtr message, int charCount) {
/* 180 */     System.err.println(message.nullTerminatedString());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void GetRNGstate() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public static void PutRNGstate() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public static double unif_rand() {
/* 194 */     return Math.random();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void vmmin(int n0, DoublePtr b, DoublePtr fmin, FunPtr fminfn, FunPtr fmingr, int maxit, int trace, IntPtr mask, double abstol, double reltol, int nREPORT, Object ex, IntPtr fncount, IntPtr grcount, IntPtr fail) {
/* 200 */     throw new UnsupportedOperationException("not implemented");
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-gnur-runtime-0.9.2724.jar!/org/renjin/gnur/RenjinCApi.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */