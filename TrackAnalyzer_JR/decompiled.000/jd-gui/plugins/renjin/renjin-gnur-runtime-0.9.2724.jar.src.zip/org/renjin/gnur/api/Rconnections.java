/*    */ package org.renjin.gnur.api;
/*    */ 
/*    */ import org.renjin.gcc.runtime.IntPtr;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Rconnections
/*    */ {
/*    */   public static boolean switch_stdout(int icon, int closeOnExit) {
/* 44 */     throw new UnimplementedGnuApiMethod("switch_stdout");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static int getActiveSink(int n) {
/* 62 */     throw new UnimplementedGnuApiMethod("getActiveSink");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static int Rsockselect(int nsock, IntPtr insockfd, IntPtr ready, IntPtr write, double timeout) {
/* 68 */     throw new UnimplementedGnuApiMethod("Rsockselect");
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-gnur-runtime-0.9.2724.jar!/org/renjin/gnur/api/Rconnections.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */