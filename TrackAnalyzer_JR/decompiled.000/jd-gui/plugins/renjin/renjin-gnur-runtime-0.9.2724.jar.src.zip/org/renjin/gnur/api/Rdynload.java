/*     */ package org.renjin.gnur.api;
/*     */ 
/*     */ import java.lang.invoke.MethodHandle;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.renjin.gcc.runtime.BytePtr;
/*     */ import org.renjin.gcc.runtime.ObjectPtr;
/*     */ import org.renjin.gcc.runtime.Ptr;
/*     */ import org.renjin.primitives.packaging.DllInfo;
/*     */ import org.renjin.primitives.packaging.DllSymbol;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Rdynload
/*     */ {
/*  35 */   private static final Map<String, MethodHandle> CALL_MAP = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static int R_registerRoutines(DllInfo info, ObjectPtr<MethodDef> croutines, ObjectPtr<MethodDef> callRoutines, ObjectPtr<MethodDef> fortranRoutines, ObjectPtr<MethodDef> externalRoutines) {
/*  47 */     addTo(info, DllSymbol.Convention.C, croutines);
/*  48 */     addTo(info, DllSymbol.Convention.CALL, callRoutines);
/*  49 */     addTo(info, DllSymbol.Convention.FORTRAN, fortranRoutines);
/*  50 */     addTo(info, DllSymbol.Convention.EXTERNAL, externalRoutines);
/*     */     
/*  52 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int R_registerRoutines(DllInfo info, Ptr croutines, Ptr callRoutines, Ptr fortranRoutines, Ptr externalRoutines) {
/*  62 */     addTo(info, DllSymbol.Convention.C, croutines);
/*  63 */     addTo(info, DllSymbol.Convention.CALL, callRoutines);
/*  64 */     addTo(info, DllSymbol.Convention.FORTRAN, fortranRoutines);
/*  65 */     addTo(info, DllSymbol.Convention.EXTERNAL, externalRoutines);
/*     */     
/*  67 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   private static void addTo(DllInfo library, DllSymbol.Convention convention, ObjectPtr<MethodDef> methods) {
/*  75 */     if (methods != null && methods.array != null) {
/*  76 */       for (int i = 0;; i++) {
/*  77 */         MethodDef def = (MethodDef)methods.get(i);
/*  78 */         if (def.fun == null) {
/*     */           break;
/*     */         }
/*  81 */         library.register(new DllSymbol(def.getName(), def.fun, convention, true));
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static void addTo(DllInfo library, DllSymbol.Convention convention, Ptr methods) {
/*  88 */     if (!methods.isNull()) {
/*  89 */       for (int i = 0;; i++) {
/*  90 */         MethodDef2 def = new MethodDef2(methods.pointerPlus(i * 20));
/*  91 */         if (def.fun == null) {
/*     */           break;
/*     */         }
/*  94 */         library.register(new DllSymbol(def.getName(), def.fun, convention, true));
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   public static boolean R_useDynamicSymbols(DllInfo info, boolean value) {
/* 100 */     return info.setUseDynamicSymbols(value);
/*     */   }
/*     */   
/*     */   public static boolean R_forceSymbols(DllInfo info, boolean value) {
/* 104 */     return info.forceSymbols(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static void R_RegisterCCallable(BytePtr packageName, BytePtr name, Object method) {
/* 117 */     R_RegisterCCallable(packageName, name, (MethodHandle)method);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void R_RegisterCCallable(BytePtr packageName, BytePtr name, MethodHandle method) {
/* 123 */     String key = packageName.nullTerminatedString() + "." + name.nullTerminatedString();
/* 124 */     CALL_MAP.put(key, method);
/*     */   }
/*     */   
/*     */   public static MethodHandle R_GetCCallable(BytePtr packageName, BytePtr name) {
/* 128 */     String key = packageName.nullTerminatedString() + "." + name.nullTerminatedString();
/* 129 */     return CALL_MAP.get(key);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-gnur-runtime-0.9.2724.jar!/org/renjin/gnur/api/Rdynload.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */