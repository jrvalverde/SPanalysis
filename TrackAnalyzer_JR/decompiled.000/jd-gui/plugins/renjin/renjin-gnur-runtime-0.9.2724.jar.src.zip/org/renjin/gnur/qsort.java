package org.renjin.gnur;

import org.renjin.gcc.runtime.Ptr;

public class qsort {
  public static void R_qsort_int(Ptr v, int i, int j) {
    // Byte code:
    //   0: bipush #40
    //   2: newarray int
    //   4: astore #12
    //   6: bipush #40
    //   8: newarray int
    //   10: astore #13
    //   12: iconst_0
    //   13: istore_3
    //   14: iconst_0
    //   15: istore #4
    //   17: iconst_0
    //   18: istore #5
    //   20: iconst_0
    //   21: istore #7
    //   23: dconst_0
    //   24: dstore #8
    //   26: iconst_0
    //   27: istore #10
    //   29: iconst_0
    //   30: istore #11
    //   32: ldc2_w 0.375
    //   35: dstore #8
    //   37: aload_0
    //   38: bipush #-4
    //   40: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   45: astore_0
    //   46: iload_1
    //   47: istore #7
    //   49: iconst_1
    //   50: istore_3
    //   51: iload_1
    //   52: iload_2
    //   53: invokestatic compareUnsigned : (II)I
    //   56: iflt -> 62
    //   59: goto -> 754
    //   62: dload #8
    //   64: ldc2_w 0.5898437
    //   67: dcmpg
    //   68: iflt -> 74
    //   71: goto -> 85
    //   74: dload #8
    //   76: ldc2_w 0.0390625
    //   79: dadd
    //   80: dstore #8
    //   82: goto -> 93
    //   85: dload #8
    //   87: ldc2_w 0.21875
    //   90: dsub
    //   91: dstore #8
    //   93: iload_1
    //   94: istore #5
    //   96: iload_2
    //   97: iload_1
    //   98: isub
    //   99: invokestatic toUnsignedLong : (I)J
    //   102: l2d
    //   103: dload #8
    //   105: dmul
    //   106: d2l
    //   107: l2i
    //   108: iload_1
    //   109: iadd
    //   110: istore #6
    //   112: iload #6
    //   114: iconst_4
    //   115: imul
    //   116: istore #115
    //   118: aload_0
    //   119: astore #113
    //   121: iload #115
    //   123: istore #114
    //   125: aload #113
    //   127: iload #114
    //   129: invokeinterface getInt : (I)I
    //   134: istore #11
    //   136: iload_1
    //   137: iconst_4
    //   138: imul
    //   139: istore #112
    //   141: aload_0
    //   142: astore #110
    //   144: iload #112
    //   146: istore #111
    //   148: aload #110
    //   150: iload #111
    //   152: invokeinterface getInt : (I)I
    //   157: iload #11
    //   159: if_icmpgt -> 165
    //   162: goto -> 259
    //   165: iload #6
    //   167: iconst_4
    //   168: imul
    //   169: istore #108
    //   171: aload_0
    //   172: astore #106
    //   174: iload #108
    //   176: istore #107
    //   178: iload_1
    //   179: iconst_4
    //   180: imul
    //   181: istore #105
    //   183: aload_0
    //   184: astore #103
    //   186: iload #105
    //   188: istore #104
    //   190: aload #103
    //   192: iload #104
    //   194: invokeinterface getInt : (I)I
    //   199: istore #102
    //   201: aload #106
    //   203: iload #107
    //   205: iload #102
    //   207: invokeinterface setInt : (II)V
    //   212: iload_1
    //   213: iconst_4
    //   214: imul
    //   215: istore #101
    //   217: aload_0
    //   218: astore #99
    //   220: iload #101
    //   222: istore #100
    //   224: aload #99
    //   226: iload #100
    //   228: iload #11
    //   230: invokeinterface setInt : (II)V
    //   235: iload #6
    //   237: iconst_4
    //   238: imul
    //   239: istore #98
    //   241: aload_0
    //   242: astore #96
    //   244: iload #98
    //   246: istore #97
    //   248: aload #96
    //   250: iload #97
    //   252: invokeinterface getInt : (I)I
    //   257: istore #11
    //   259: iload_2
    //   260: istore #4
    //   262: iload_2
    //   263: iconst_4
    //   264: imul
    //   265: istore #95
    //   267: aload_0
    //   268: astore #93
    //   270: iload #95
    //   272: istore #94
    //   274: aload #93
    //   276: iload #94
    //   278: invokeinterface getInt : (I)I
    //   283: iload #11
    //   285: if_icmplt -> 291
    //   288: goto -> 508
    //   291: iload #6
    //   293: iconst_4
    //   294: imul
    //   295: istore #91
    //   297: aload_0
    //   298: astore #89
    //   300: iload #91
    //   302: istore #90
    //   304: iload_2
    //   305: iconst_4
    //   306: imul
    //   307: istore #88
    //   309: aload_0
    //   310: astore #86
    //   312: iload #88
    //   314: istore #87
    //   316: aload #86
    //   318: iload #87
    //   320: invokeinterface getInt : (I)I
    //   325: istore #85
    //   327: aload #89
    //   329: iload #90
    //   331: iload #85
    //   333: invokeinterface setInt : (II)V
    //   338: iload_2
    //   339: iconst_4
    //   340: imul
    //   341: istore #84
    //   343: aload_0
    //   344: astore #82
    //   346: iload #84
    //   348: istore #83
    //   350: aload #82
    //   352: iload #83
    //   354: iload #11
    //   356: invokeinterface setInt : (II)V
    //   361: iload #6
    //   363: iconst_4
    //   364: imul
    //   365: istore #81
    //   367: aload_0
    //   368: astore #79
    //   370: iload #81
    //   372: istore #80
    //   374: aload #79
    //   376: iload #80
    //   378: invokeinterface getInt : (I)I
    //   383: istore #11
    //   385: iload_1
    //   386: iconst_4
    //   387: imul
    //   388: istore #78
    //   390: aload_0
    //   391: astore #76
    //   393: iload #78
    //   395: istore #77
    //   397: aload #76
    //   399: iload #77
    //   401: invokeinterface getInt : (I)I
    //   406: iload #11
    //   408: if_icmpgt -> 414
    //   411: goto -> 508
    //   414: iload #6
    //   416: iconst_4
    //   417: imul
    //   418: istore #74
    //   420: aload_0
    //   421: astore #72
    //   423: iload #74
    //   425: istore #73
    //   427: iload_1
    //   428: iconst_4
    //   429: imul
    //   430: istore #71
    //   432: aload_0
    //   433: astore #69
    //   435: iload #71
    //   437: istore #70
    //   439: aload #69
    //   441: iload #70
    //   443: invokeinterface getInt : (I)I
    //   448: istore #68
    //   450: aload #72
    //   452: iload #73
    //   454: iload #68
    //   456: invokeinterface setInt : (II)V
    //   461: iload_1
    //   462: iconst_4
    //   463: imul
    //   464: istore #67
    //   466: aload_0
    //   467: astore #65
    //   469: iload #67
    //   471: istore #66
    //   473: aload #65
    //   475: iload #66
    //   477: iload #11
    //   479: invokeinterface setInt : (II)V
    //   484: iload #6
    //   486: iconst_4
    //   487: imul
    //   488: istore #64
    //   490: aload_0
    //   491: astore #62
    //   493: iload #64
    //   495: istore #63
    //   497: aload #62
    //   499: iload #63
    //   501: invokeinterface getInt : (I)I
    //   506: istore #11
    //   508: iload #4
    //   510: iconst_1
    //   511: isub
    //   512: istore #4
    //   514: iload #4
    //   516: iconst_4
    //   517: imul
    //   518: istore #61
    //   520: aload_0
    //   521: astore #59
    //   523: iload #61
    //   525: istore #60
    //   527: aload #59
    //   529: iload #60
    //   531: invokeinterface getInt : (I)I
    //   536: iload #11
    //   538: if_icmpgt -> 508
    //   541: goto -> 544
    //   544: iload #4
    //   546: iconst_4
    //   547: imul
    //   548: istore #57
    //   550: aload_0
    //   551: astore #55
    //   553: iload #57
    //   555: istore #56
    //   557: aload #55
    //   559: iload #56
    //   561: invokeinterface getInt : (I)I
    //   566: istore #10
    //   568: iinc #5, 1
    //   571: iload #5
    //   573: iconst_4
    //   574: imul
    //   575: istore #54
    //   577: aload_0
    //   578: astore #52
    //   580: iload #54
    //   582: istore #53
    //   584: aload #52
    //   586: iload #53
    //   588: invokeinterface getInt : (I)I
    //   593: iload #11
    //   595: if_icmplt -> 568
    //   598: goto -> 601
    //   601: iload #5
    //   603: iload #4
    //   605: invokestatic compareUnsigned : (II)I
    //   608: ifgt -> 614
    //   611: goto -> 617
    //   614: goto -> 692
    //   617: iload #4
    //   619: iconst_4
    //   620: imul
    //   621: istore #50
    //   623: aload_0
    //   624: astore #48
    //   626: iload #50
    //   628: istore #49
    //   630: iload #5
    //   632: iconst_4
    //   633: imul
    //   634: istore #47
    //   636: aload_0
    //   637: astore #45
    //   639: iload #47
    //   641: istore #46
    //   643: aload #45
    //   645: iload #46
    //   647: invokeinterface getInt : (I)I
    //   652: istore #44
    //   654: aload #48
    //   656: iload #49
    //   658: iload #44
    //   660: invokeinterface setInt : (II)V
    //   665: iload #5
    //   667: iconst_4
    //   668: imul
    //   669: istore #43
    //   671: aload_0
    //   672: astore #41
    //   674: iload #43
    //   676: istore #42
    //   678: aload #41
    //   680: iload #42
    //   682: iload #10
    //   684: invokeinterface setInt : (II)V
    //   689: goto -> 508
    //   692: iinc #3, 1
    //   695: iload #4
    //   697: iload_1
    //   698: isub
    //   699: istore #40
    //   701: iload_2
    //   702: iload #5
    //   704: isub
    //   705: istore #39
    //   707: iload #40
    //   709: iload #39
    //   711: invokestatic compareUnsigned : (II)I
    //   714: ifle -> 720
    //   717: goto -> 737
    //   720: aload #13
    //   722: iload_3
    //   723: iload #5
    //   725: iastore
    //   726: aload #12
    //   728: iload_3
    //   729: iload_2
    //   730: iastore
    //   731: iload #4
    //   733: istore_2
    //   734: goto -> 776
    //   737: aload #13
    //   739: iload_3
    //   740: iload_1
    //   741: iastore
    //   742: aload #12
    //   744: iload_3
    //   745: iload #4
    //   747: iastore
    //   748: iload #5
    //   750: istore_1
    //   751: goto -> 776
    //   754: iload_3
    //   755: iconst_1
    //   756: if_icmpeq -> 995
    //   759: goto -> 762
    //   762: aload #13
    //   764: iload_3
    //   765: iaload
    //   766: istore_1
    //   767: aload #12
    //   769: iload_3
    //   770: iaload
    //   771: istore_2
    //   772: iload_3
    //   773: iconst_1
    //   774: isub
    //   775: istore_3
    //   776: iload_2
    //   777: iload_1
    //   778: isub
    //   779: bipush #10
    //   781: invokestatic compareUnsigned : (II)I
    //   784: ifgt -> 790
    //   787: goto -> 793
    //   790: goto -> 93
    //   793: iload_1
    //   794: iload #7
    //   796: if_icmpeq -> 802
    //   799: goto -> 805
    //   802: goto -> 51
    //   805: iload_1
    //   806: iconst_1
    //   807: isub
    //   808: istore_1
    //   809: iinc #1, 1
    //   812: iload_1
    //   813: iload_2
    //   814: if_icmpeq -> 820
    //   817: goto -> 823
    //   820: goto -> 754
    //   823: iload_1
    //   824: iconst_1
    //   825: iadd
    //   826: iconst_4
    //   827: imul
    //   828: istore #36
    //   830: aload_0
    //   831: astore #34
    //   833: iload #36
    //   835: istore #35
    //   837: aload #34
    //   839: iload #35
    //   841: invokeinterface getInt : (I)I
    //   846: istore #11
    //   848: iload_1
    //   849: iconst_4
    //   850: imul
    //   851: istore #33
    //   853: aload_0
    //   854: astore #31
    //   856: iload #33
    //   858: istore #32
    //   860: aload #31
    //   862: iload #32
    //   864: invokeinterface getInt : (I)I
    //   869: iload #11
    //   871: if_icmple -> 809
    //   874: goto -> 877
    //   877: iload_1
    //   878: istore #5
    //   880: iload #5
    //   882: iconst_1
    //   883: iadd
    //   884: iconst_4
    //   885: imul
    //   886: istore #28
    //   888: aload_0
    //   889: astore #26
    //   891: iload #28
    //   893: istore #27
    //   895: iload #5
    //   897: iconst_4
    //   898: imul
    //   899: istore #25
    //   901: aload_0
    //   902: astore #23
    //   904: iload #25
    //   906: istore #24
    //   908: aload #23
    //   910: iload #24
    //   912: invokeinterface getInt : (I)I
    //   917: istore #22
    //   919: aload #26
    //   921: iload #27
    //   923: iload #22
    //   925: invokeinterface setInt : (II)V
    //   930: iload #5
    //   932: iconst_1
    //   933: isub
    //   934: istore #5
    //   936: iload #5
    //   938: iconst_4
    //   939: imul
    //   940: istore #21
    //   942: aload_0
    //   943: astore #19
    //   945: iload #21
    //   947: istore #20
    //   949: aload #19
    //   951: iload #20
    //   953: invokeinterface getInt : (I)I
    //   958: iload #11
    //   960: if_icmpgt -> 880
    //   963: goto -> 966
    //   966: iload #5
    //   968: iconst_1
    //   969: iadd
    //   970: iconst_4
    //   971: imul
    //   972: istore #16
    //   974: aload_0
    //   975: astore #14
    //   977: iload #16
    //   979: istore #15
    //   981: aload #14
    //   983: iload #15
    //   985: iload #11
    //   987: invokeinterface setInt : (II)V
    //   992: goto -> 809
    //   995: return
    // Line number table:
    //   Java source line number -> byte code offset
    //   #47	-> 32
    //   #55	-> 37
    //   #60	-> 46
    //   #61	-> 49
    //   #64	-> 51
    //   #65	-> 62
    //   #65	-> 74
    //   #65	-> 85
    //   #67	-> 93
    //   #69	-> 96
    //   #73	-> 112
    //   #74	-> 136
    //   #78	-> 165
    //   #81	-> 259
    //   #82	-> 262
    //   #86	-> 291
    //   #87	-> 385
    //   #91	-> 414
    //   #96	-> 508
    //   #101	-> 544
    //   #102	-> 568
    //   #104	-> 601
    //   #110	-> 617
    //   #113	-> 692
    //   #114	-> 695
    //   #116	-> 720
    //   #117	-> 726
    //   #118	-> 731
    //   #121	-> 737
    //   #122	-> 742
    //   #123	-> 748
    //   #129	-> 754
    //   #132	-> 762
    //   #133	-> 767
    //   #134	-> 772
    //   #137	-> 776
    //   #139	-> 793
    //   #141	-> 805
    //   #144	-> 809
    //   #145	-> 812
    //   #151	-> 823
    //   #152	-> 848
    //   #154	-> 877
    //   #160	-> 880
    //   #161	-> 930
    //   #162	-> 936
    //   #167	-> 966
    //   #0	-> 995
    //   #129	-> 995
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	996	0	v	Lorg/renjin/gcc/runtime/Ptr;
    //   0	996	1	i	I
    //   0	996	2	j	I
    //   0	996	3	m	I
    //   0	996	4	l	I
    //   0	996	5	k	I
    //   0	996	6	ij	I
    //   0	996	7	ii	I
    //   0	996	8	R	D
    //   0	996	10	vtt	I
    //   0	996	11	vt	I
    //   0	996	12	iu	[I
    //   0	996	13	il	[I
  }
  
  public static void R_qsort(Ptr v, int i, int j) {
    // Byte code:
    //   0: bipush #40
    //   2: newarray int
    //   4: astore #14
    //   6: bipush #40
    //   8: newarray int
    //   10: astore #15
    //   12: iconst_0
    //   13: istore_3
    //   14: iconst_0
    //   15: istore #4
    //   17: iconst_0
    //   18: istore #5
    //   20: iconst_0
    //   21: istore #7
    //   23: dconst_0
    //   24: dstore #8
    //   26: dconst_0
    //   27: dstore #10
    //   29: dconst_0
    //   30: dstore #12
    //   32: ldc2_w 0.375
    //   35: dstore #8
    //   37: aload_0
    //   38: bipush #-8
    //   40: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   45: astore_0
    //   46: iload_1
    //   47: istore #7
    //   49: iconst_1
    //   50: istore_3
    //   51: iload_1
    //   52: iload_2
    //   53: invokestatic compareUnsigned : (II)I
    //   56: iflt -> 62
    //   59: goto -> 781
    //   62: dload #8
    //   64: ldc2_w 0.5898437
    //   67: dcmpg
    //   68: iflt -> 74
    //   71: goto -> 85
    //   74: dload #8
    //   76: ldc2_w 0.0390625
    //   79: dadd
    //   80: dstore #8
    //   82: goto -> 93
    //   85: dload #8
    //   87: ldc2_w 0.21875
    //   90: dsub
    //   91: dstore #8
    //   93: iload_1
    //   94: istore #5
    //   96: iload_2
    //   97: iload_1
    //   98: isub
    //   99: invokestatic toUnsignedLong : (I)J
    //   102: l2d
    //   103: dload #8
    //   105: dmul
    //   106: d2l
    //   107: l2i
    //   108: iload_1
    //   109: iadd
    //   110: istore #6
    //   112: iload #6
    //   114: bipush #8
    //   116: imul
    //   117: istore #129
    //   119: aload_0
    //   120: astore #127
    //   122: iload #129
    //   124: istore #128
    //   126: aload #127
    //   128: iload #128
    //   130: invokeinterface getDouble : (I)D
    //   135: dstore #12
    //   137: iload_1
    //   138: bipush #8
    //   140: imul
    //   141: istore #126
    //   143: aload_0
    //   144: astore #124
    //   146: iload #126
    //   148: istore #125
    //   150: aload #124
    //   152: iload #125
    //   154: invokeinterface getDouble : (I)D
    //   159: dload #12
    //   161: dcmpl
    //   162: ifgt -> 168
    //   165: goto -> 266
    //   168: iload #6
    //   170: bipush #8
    //   172: imul
    //   173: istore #121
    //   175: aload_0
    //   176: astore #119
    //   178: iload #121
    //   180: istore #120
    //   182: iload_1
    //   183: bipush #8
    //   185: imul
    //   186: istore #118
    //   188: aload_0
    //   189: astore #116
    //   191: iload #118
    //   193: istore #117
    //   195: aload #116
    //   197: iload #117
    //   199: invokeinterface getDouble : (I)D
    //   204: dstore #114
    //   206: aload #119
    //   208: iload #120
    //   210: dload #114
    //   212: invokeinterface setDouble : (ID)V
    //   217: iload_1
    //   218: bipush #8
    //   220: imul
    //   221: istore #113
    //   223: aload_0
    //   224: astore #111
    //   226: iload #113
    //   228: istore #112
    //   230: aload #111
    //   232: iload #112
    //   234: dload #12
    //   236: invokeinterface setDouble : (ID)V
    //   241: iload #6
    //   243: bipush #8
    //   245: imul
    //   246: istore #110
    //   248: aload_0
    //   249: astore #108
    //   251: iload #110
    //   253: istore #109
    //   255: aload #108
    //   257: iload #109
    //   259: invokeinterface getDouble : (I)D
    //   264: dstore #12
    //   266: iload_2
    //   267: istore #4
    //   269: iload_2
    //   270: bipush #8
    //   272: imul
    //   273: istore #107
    //   275: aload_0
    //   276: astore #105
    //   278: iload #107
    //   280: istore #106
    //   282: aload #105
    //   284: iload #106
    //   286: invokeinterface getDouble : (I)D
    //   291: dload #12
    //   293: dcmpg
    //   294: iflt -> 300
    //   297: goto -> 527
    //   300: iload #6
    //   302: bipush #8
    //   304: imul
    //   305: istore #102
    //   307: aload_0
    //   308: astore #100
    //   310: iload #102
    //   312: istore #101
    //   314: iload_2
    //   315: bipush #8
    //   317: imul
    //   318: istore #99
    //   320: aload_0
    //   321: astore #97
    //   323: iload #99
    //   325: istore #98
    //   327: aload #97
    //   329: iload #98
    //   331: invokeinterface getDouble : (I)D
    //   336: dstore #95
    //   338: aload #100
    //   340: iload #101
    //   342: dload #95
    //   344: invokeinterface setDouble : (ID)V
    //   349: iload_2
    //   350: bipush #8
    //   352: imul
    //   353: istore #94
    //   355: aload_0
    //   356: astore #92
    //   358: iload #94
    //   360: istore #93
    //   362: aload #92
    //   364: iload #93
    //   366: dload #12
    //   368: invokeinterface setDouble : (ID)V
    //   373: iload #6
    //   375: bipush #8
    //   377: imul
    //   378: istore #91
    //   380: aload_0
    //   381: astore #89
    //   383: iload #91
    //   385: istore #90
    //   387: aload #89
    //   389: iload #90
    //   391: invokeinterface getDouble : (I)D
    //   396: dstore #12
    //   398: iload_1
    //   399: bipush #8
    //   401: imul
    //   402: istore #88
    //   404: aload_0
    //   405: astore #86
    //   407: iload #88
    //   409: istore #87
    //   411: aload #86
    //   413: iload #87
    //   415: invokeinterface getDouble : (I)D
    //   420: dload #12
    //   422: dcmpl
    //   423: ifgt -> 429
    //   426: goto -> 527
    //   429: iload #6
    //   431: bipush #8
    //   433: imul
    //   434: istore #83
    //   436: aload_0
    //   437: astore #81
    //   439: iload #83
    //   441: istore #82
    //   443: iload_1
    //   444: bipush #8
    //   446: imul
    //   447: istore #80
    //   449: aload_0
    //   450: astore #78
    //   452: iload #80
    //   454: istore #79
    //   456: aload #78
    //   458: iload #79
    //   460: invokeinterface getDouble : (I)D
    //   465: dstore #76
    //   467: aload #81
    //   469: iload #82
    //   471: dload #76
    //   473: invokeinterface setDouble : (ID)V
    //   478: iload_1
    //   479: bipush #8
    //   481: imul
    //   482: istore #75
    //   484: aload_0
    //   485: astore #73
    //   487: iload #75
    //   489: istore #74
    //   491: aload #73
    //   493: iload #74
    //   495: dload #12
    //   497: invokeinterface setDouble : (ID)V
    //   502: iload #6
    //   504: bipush #8
    //   506: imul
    //   507: istore #72
    //   509: aload_0
    //   510: astore #70
    //   512: iload #72
    //   514: istore #71
    //   516: aload #70
    //   518: iload #71
    //   520: invokeinterface getDouble : (I)D
    //   525: dstore #12
    //   527: iload #4
    //   529: iconst_1
    //   530: isub
    //   531: istore #4
    //   533: iload #4
    //   535: bipush #8
    //   537: imul
    //   538: istore #69
    //   540: aload_0
    //   541: astore #67
    //   543: iload #69
    //   545: istore #68
    //   547: aload #67
    //   549: iload #68
    //   551: invokeinterface getDouble : (I)D
    //   556: dload #12
    //   558: dcmpl
    //   559: ifgt -> 527
    //   562: goto -> 565
    //   565: iload #4
    //   567: bipush #8
    //   569: imul
    //   570: istore #64
    //   572: aload_0
    //   573: astore #62
    //   575: iload #64
    //   577: istore #63
    //   579: aload #62
    //   581: iload #63
    //   583: invokeinterface getDouble : (I)D
    //   588: dstore #10
    //   590: iinc #5, 1
    //   593: iload #5
    //   595: bipush #8
    //   597: imul
    //   598: istore #61
    //   600: aload_0
    //   601: astore #59
    //   603: iload #61
    //   605: istore #60
    //   607: aload #59
    //   609: iload #60
    //   611: invokeinterface getDouble : (I)D
    //   616: dload #12
    //   618: dcmpg
    //   619: iflt -> 590
    //   622: goto -> 625
    //   625: iload #5
    //   627: iload #4
    //   629: invokestatic compareUnsigned : (II)I
    //   632: ifgt -> 638
    //   635: goto -> 641
    //   638: goto -> 719
    //   641: iload #4
    //   643: bipush #8
    //   645: imul
    //   646: istore #56
    //   648: aload_0
    //   649: astore #54
    //   651: iload #56
    //   653: istore #55
    //   655: iload #5
    //   657: bipush #8
    //   659: imul
    //   660: istore #53
    //   662: aload_0
    //   663: astore #51
    //   665: iload #53
    //   667: istore #52
    //   669: aload #51
    //   671: iload #52
    //   673: invokeinterface getDouble : (I)D
    //   678: dstore #49
    //   680: aload #54
    //   682: iload #55
    //   684: dload #49
    //   686: invokeinterface setDouble : (ID)V
    //   691: iload #5
    //   693: bipush #8
    //   695: imul
    //   696: istore #48
    //   698: aload_0
    //   699: astore #46
    //   701: iload #48
    //   703: istore #47
    //   705: aload #46
    //   707: iload #47
    //   709: dload #10
    //   711: invokeinterface setDouble : (ID)V
    //   716: goto -> 527
    //   719: iinc #3, 1
    //   722: iload #4
    //   724: iload_1
    //   725: isub
    //   726: istore #45
    //   728: iload_2
    //   729: iload #5
    //   731: isub
    //   732: istore #44
    //   734: iload #45
    //   736: iload #44
    //   738: invokestatic compareUnsigned : (II)I
    //   741: ifle -> 747
    //   744: goto -> 764
    //   747: aload #15
    //   749: iload_3
    //   750: iload #5
    //   752: iastore
    //   753: aload #14
    //   755: iload_3
    //   756: iload_2
    //   757: iastore
    //   758: iload #4
    //   760: istore_2
    //   761: goto -> 803
    //   764: aload #15
    //   766: iload_3
    //   767: iload_1
    //   768: iastore
    //   769: aload #14
    //   771: iload_3
    //   772: iload #4
    //   774: iastore
    //   775: iload #5
    //   777: istore_1
    //   778: goto -> 803
    //   781: iload_3
    //   782: iconst_1
    //   783: if_icmpeq -> 1030
    //   786: goto -> 789
    //   789: aload #15
    //   791: iload_3
    //   792: iaload
    //   793: istore_1
    //   794: aload #14
    //   796: iload_3
    //   797: iaload
    //   798: istore_2
    //   799: iload_3
    //   800: iconst_1
    //   801: isub
    //   802: istore_3
    //   803: iload_2
    //   804: iload_1
    //   805: isub
    //   806: bipush #10
    //   808: invokestatic compareUnsigned : (II)I
    //   811: ifgt -> 817
    //   814: goto -> 820
    //   817: goto -> 93
    //   820: iload_1
    //   821: iload #7
    //   823: if_icmpeq -> 829
    //   826: goto -> 832
    //   829: goto -> 51
    //   832: iload_1
    //   833: iconst_1
    //   834: isub
    //   835: istore_1
    //   836: iinc #1, 1
    //   839: iload_1
    //   840: iload_2
    //   841: if_icmpeq -> 847
    //   844: goto -> 850
    //   847: goto -> 781
    //   850: iload_1
    //   851: iconst_1
    //   852: iadd
    //   853: bipush #8
    //   855: imul
    //   856: istore #41
    //   858: aload_0
    //   859: astore #39
    //   861: iload #41
    //   863: istore #40
    //   865: aload #39
    //   867: iload #40
    //   869: invokeinterface getDouble : (I)D
    //   874: dstore #12
    //   876: iload_1
    //   877: bipush #8
    //   879: imul
    //   880: istore #38
    //   882: aload_0
    //   883: astore #36
    //   885: iload #38
    //   887: istore #37
    //   889: aload #36
    //   891: iload #37
    //   893: invokeinterface getDouble : (I)D
    //   898: dload #12
    //   900: dcmpg
    //   901: ifle -> 836
    //   904: goto -> 907
    //   907: iload_1
    //   908: istore #5
    //   910: iload #5
    //   912: iconst_1
    //   913: iadd
    //   914: bipush #8
    //   916: imul
    //   917: istore #32
    //   919: aload_0
    //   920: astore #30
    //   922: iload #32
    //   924: istore #31
    //   926: iload #5
    //   928: bipush #8
    //   930: imul
    //   931: istore #29
    //   933: aload_0
    //   934: astore #27
    //   936: iload #29
    //   938: istore #28
    //   940: aload #27
    //   942: iload #28
    //   944: invokeinterface getDouble : (I)D
    //   949: dstore #25
    //   951: aload #30
    //   953: iload #31
    //   955: dload #25
    //   957: invokeinterface setDouble : (ID)V
    //   962: iload #5
    //   964: iconst_1
    //   965: isub
    //   966: istore #5
    //   968: iload #5
    //   970: bipush #8
    //   972: imul
    //   973: istore #24
    //   975: aload_0
    //   976: astore #22
    //   978: iload #24
    //   980: istore #23
    //   982: aload #22
    //   984: iload #23
    //   986: invokeinterface getDouble : (I)D
    //   991: dload #12
    //   993: dcmpl
    //   994: ifgt -> 910
    //   997: goto -> 1000
    //   1000: iload #5
    //   1002: iconst_1
    //   1003: iadd
    //   1004: bipush #8
    //   1006: imul
    //   1007: istore #18
    //   1009: aload_0
    //   1010: astore #16
    //   1012: iload #18
    //   1014: istore #17
    //   1016: aload #16
    //   1018: iload #17
    //   1020: dload #12
    //   1022: invokeinterface setDouble : (ID)V
    //   1027: goto -> 836
    //   1030: return
    // Line number table:
    //   Java source line number -> byte code offset
    //   #47	-> 32
    //   #55	-> 37
    //   #60	-> 46
    //   #61	-> 49
    //   #64	-> 51
    //   #65	-> 62
    //   #65	-> 74
    //   #65	-> 85
    //   #67	-> 93
    //   #69	-> 96
    //   #73	-> 112
    //   #74	-> 137
    //   #78	-> 168
    //   #81	-> 266
    //   #82	-> 269
    //   #86	-> 300
    //   #87	-> 398
    //   #91	-> 429
    //   #96	-> 527
    //   #101	-> 565
    //   #102	-> 590
    //   #104	-> 625
    //   #110	-> 641
    //   #113	-> 719
    //   #114	-> 722
    //   #116	-> 747
    //   #117	-> 753
    //   #118	-> 758
    //   #121	-> 764
    //   #122	-> 769
    //   #123	-> 775
    //   #129	-> 781
    //   #132	-> 789
    //   #133	-> 794
    //   #134	-> 799
    //   #137	-> 803
    //   #139	-> 820
    //   #141	-> 832
    //   #144	-> 836
    //   #145	-> 839
    //   #151	-> 850
    //   #152	-> 876
    //   #154	-> 907
    //   #160	-> 910
    //   #161	-> 962
    //   #162	-> 968
    //   #167	-> 1000
    //   #0	-> 1030
    //   #129	-> 1030
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	1031	0	v	Lorg/renjin/gcc/runtime/Ptr;
    //   0	1031	1	i	I
    //   0	1031	2	j	I
    //   0	1031	3	m	I
    //   0	1031	4	l	I
    //   0	1031	5	k	I
    //   0	1031	6	ij	I
    //   0	1031	7	ii	I
    //   0	1031	8	R	D
    //   0	1031	10	vtt	D
    //   0	1031	12	vt	D
    //   0	1031	14	iu	[I
    //   0	1031	15	il	[I
  }
  
  public static void R_qsort_int_I(Ptr v, Ptr I, int i, int j) {
    // Byte code:
    //   0: bipush #40
    //   2: newarray int
    //   4: astore #15
    //   6: bipush #40
    //   8: newarray int
    //   10: astore #16
    //   12: iconst_0
    //   13: istore #4
    //   15: iconst_0
    //   16: istore #5
    //   18: iconst_0
    //   19: istore #6
    //   21: iconst_0
    //   22: istore #7
    //   24: iconst_0
    //   25: istore #8
    //   27: iconst_0
    //   28: istore #10
    //   30: dconst_0
    //   31: dstore #11
    //   33: iconst_0
    //   34: istore #13
    //   36: iconst_0
    //   37: istore #14
    //   39: ldc2_w 0.375
    //   42: dstore #11
    //   44: aload_0
    //   45: bipush #-4
    //   47: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   52: astore_0
    //   53: aload_1
    //   54: bipush #-4
    //   56: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   61: astore_1
    //   62: iload_2
    //   63: istore #10
    //   65: iconst_1
    //   66: istore #6
    //   68: iload_2
    //   69: iload_3
    //   70: if_icmplt -> 76
    //   73: goto -> 1164
    //   76: dload #11
    //   78: ldc2_w 0.5898437
    //   81: dcmpg
    //   82: iflt -> 88
    //   85: goto -> 99
    //   88: dload #11
    //   90: ldc2_w 0.0390625
    //   93: dadd
    //   94: dstore #11
    //   96: goto -> 107
    //   99: dload #11
    //   101: ldc2_w 0.21875
    //   104: dsub
    //   105: dstore #11
    //   107: iload_2
    //   108: istore #8
    //   110: iload_3
    //   111: iload_2
    //   112: isub
    //   113: i2d
    //   114: dload #11
    //   116: dmul
    //   117: d2i
    //   118: iload_2
    //   119: iadd
    //   120: istore #9
    //   122: iload #9
    //   124: iconst_4
    //   125: imul
    //   126: istore #237
    //   128: aload_1
    //   129: astore #235
    //   131: iload #237
    //   133: istore #236
    //   135: aload #235
    //   137: iload #236
    //   139: invokeinterface getInt : (I)I
    //   144: istore #5
    //   146: iload #9
    //   148: iconst_4
    //   149: imul
    //   150: istore #233
    //   152: aload_0
    //   153: astore #231
    //   155: iload #233
    //   157: istore #232
    //   159: aload #231
    //   161: iload #232
    //   163: invokeinterface getInt : (I)I
    //   168: istore #14
    //   170: iload_2
    //   171: iconst_4
    //   172: imul
    //   173: istore #229
    //   175: aload_0
    //   176: astore #227
    //   178: iload #229
    //   180: istore #228
    //   182: aload #227
    //   184: iload #228
    //   186: invokeinterface getInt : (I)I
    //   191: iload #14
    //   193: if_icmpgt -> 199
    //   196: goto -> 387
    //   199: iload #9
    //   201: iconst_4
    //   202: imul
    //   203: istore #224
    //   205: aload_1
    //   206: astore #222
    //   208: iload #224
    //   210: istore #223
    //   212: iload_2
    //   213: iconst_4
    //   214: imul
    //   215: istore #220
    //   217: aload_1
    //   218: astore #218
    //   220: iload #220
    //   222: istore #219
    //   224: aload #218
    //   226: iload #219
    //   228: invokeinterface getInt : (I)I
    //   233: istore #217
    //   235: aload #222
    //   237: iload #223
    //   239: iload #217
    //   241: invokeinterface setInt : (II)V
    //   246: iload_2
    //   247: iconst_4
    //   248: imul
    //   249: istore #215
    //   251: aload_1
    //   252: astore #213
    //   254: iload #215
    //   256: istore #214
    //   258: aload #213
    //   260: iload #214
    //   262: iload #5
    //   264: invokeinterface setInt : (II)V
    //   269: iload #9
    //   271: iconst_4
    //   272: imul
    //   273: istore #211
    //   275: aload_1
    //   276: astore #209
    //   278: iload #211
    //   280: istore #210
    //   282: aload #209
    //   284: iload #210
    //   286: invokeinterface getInt : (I)I
    //   291: istore #5
    //   293: iload #9
    //   295: iconst_4
    //   296: imul
    //   297: istore #207
    //   299: aload_0
    //   300: astore #205
    //   302: iload #207
    //   304: istore #206
    //   306: iload_2
    //   307: iconst_4
    //   308: imul
    //   309: istore #203
    //   311: aload_0
    //   312: astore #201
    //   314: iload #203
    //   316: istore #202
    //   318: aload #201
    //   320: iload #202
    //   322: invokeinterface getInt : (I)I
    //   327: istore #200
    //   329: aload #205
    //   331: iload #206
    //   333: iload #200
    //   335: invokeinterface setInt : (II)V
    //   340: iload_2
    //   341: iconst_4
    //   342: imul
    //   343: istore #198
    //   345: aload_0
    //   346: astore #196
    //   348: iload #198
    //   350: istore #197
    //   352: aload #196
    //   354: iload #197
    //   356: iload #14
    //   358: invokeinterface setInt : (II)V
    //   363: iload #9
    //   365: iconst_4
    //   366: imul
    //   367: istore #194
    //   369: aload_0
    //   370: astore #192
    //   372: iload #194
    //   374: istore #193
    //   376: aload #192
    //   378: iload #193
    //   380: invokeinterface getInt : (I)I
    //   385: istore #14
    //   387: iload_3
    //   388: istore #7
    //   390: iload_3
    //   391: iconst_4
    //   392: imul
    //   393: istore #190
    //   395: aload_0
    //   396: astore #188
    //   398: iload #190
    //   400: istore #189
    //   402: aload #188
    //   404: iload #189
    //   406: invokeinterface getInt : (I)I
    //   411: iload #14
    //   413: if_icmplt -> 419
    //   416: goto -> 824
    //   419: iload #9
    //   421: iconst_4
    //   422: imul
    //   423: istore #185
    //   425: aload_1
    //   426: astore #183
    //   428: iload #185
    //   430: istore #184
    //   432: iload_3
    //   433: iconst_4
    //   434: imul
    //   435: istore #181
    //   437: aload_1
    //   438: astore #179
    //   440: iload #181
    //   442: istore #180
    //   444: aload #179
    //   446: iload #180
    //   448: invokeinterface getInt : (I)I
    //   453: istore #178
    //   455: aload #183
    //   457: iload #184
    //   459: iload #178
    //   461: invokeinterface setInt : (II)V
    //   466: iload_3
    //   467: iconst_4
    //   468: imul
    //   469: istore #176
    //   471: aload_1
    //   472: astore #174
    //   474: iload #176
    //   476: istore #175
    //   478: aload #174
    //   480: iload #175
    //   482: iload #5
    //   484: invokeinterface setInt : (II)V
    //   489: iload #9
    //   491: iconst_4
    //   492: imul
    //   493: istore #172
    //   495: aload_1
    //   496: astore #170
    //   498: iload #172
    //   500: istore #171
    //   502: aload #170
    //   504: iload #171
    //   506: invokeinterface getInt : (I)I
    //   511: istore #5
    //   513: iload #9
    //   515: iconst_4
    //   516: imul
    //   517: istore #168
    //   519: aload_0
    //   520: astore #166
    //   522: iload #168
    //   524: istore #167
    //   526: iload_3
    //   527: iconst_4
    //   528: imul
    //   529: istore #164
    //   531: aload_0
    //   532: astore #162
    //   534: iload #164
    //   536: istore #163
    //   538: aload #162
    //   540: iload #163
    //   542: invokeinterface getInt : (I)I
    //   547: istore #161
    //   549: aload #166
    //   551: iload #167
    //   553: iload #161
    //   555: invokeinterface setInt : (II)V
    //   560: iload_3
    //   561: iconst_4
    //   562: imul
    //   563: istore #159
    //   565: aload_0
    //   566: astore #157
    //   568: iload #159
    //   570: istore #158
    //   572: aload #157
    //   574: iload #158
    //   576: iload #14
    //   578: invokeinterface setInt : (II)V
    //   583: iload #9
    //   585: iconst_4
    //   586: imul
    //   587: istore #155
    //   589: aload_0
    //   590: astore #153
    //   592: iload #155
    //   594: istore #154
    //   596: aload #153
    //   598: iload #154
    //   600: invokeinterface getInt : (I)I
    //   605: istore #14
    //   607: iload_2
    //   608: iconst_4
    //   609: imul
    //   610: istore #151
    //   612: aload_0
    //   613: astore #149
    //   615: iload #151
    //   617: istore #150
    //   619: aload #149
    //   621: iload #150
    //   623: invokeinterface getInt : (I)I
    //   628: iload #14
    //   630: if_icmpgt -> 636
    //   633: goto -> 824
    //   636: iload #9
    //   638: iconst_4
    //   639: imul
    //   640: istore #146
    //   642: aload_1
    //   643: astore #144
    //   645: iload #146
    //   647: istore #145
    //   649: iload_2
    //   650: iconst_4
    //   651: imul
    //   652: istore #142
    //   654: aload_1
    //   655: astore #140
    //   657: iload #142
    //   659: istore #141
    //   661: aload #140
    //   663: iload #141
    //   665: invokeinterface getInt : (I)I
    //   670: istore #139
    //   672: aload #144
    //   674: iload #145
    //   676: iload #139
    //   678: invokeinterface setInt : (II)V
    //   683: iload_2
    //   684: iconst_4
    //   685: imul
    //   686: istore #137
    //   688: aload_1
    //   689: astore #135
    //   691: iload #137
    //   693: istore #136
    //   695: aload #135
    //   697: iload #136
    //   699: iload #5
    //   701: invokeinterface setInt : (II)V
    //   706: iload #9
    //   708: iconst_4
    //   709: imul
    //   710: istore #133
    //   712: aload_1
    //   713: astore #131
    //   715: iload #133
    //   717: istore #132
    //   719: aload #131
    //   721: iload #132
    //   723: invokeinterface getInt : (I)I
    //   728: istore #5
    //   730: iload #9
    //   732: iconst_4
    //   733: imul
    //   734: istore #129
    //   736: aload_0
    //   737: astore #127
    //   739: iload #129
    //   741: istore #128
    //   743: iload_2
    //   744: iconst_4
    //   745: imul
    //   746: istore #125
    //   748: aload_0
    //   749: astore #123
    //   751: iload #125
    //   753: istore #124
    //   755: aload #123
    //   757: iload #124
    //   759: invokeinterface getInt : (I)I
    //   764: istore #122
    //   766: aload #127
    //   768: iload #128
    //   770: iload #122
    //   772: invokeinterface setInt : (II)V
    //   777: iload_2
    //   778: iconst_4
    //   779: imul
    //   780: istore #120
    //   782: aload_0
    //   783: astore #118
    //   785: iload #120
    //   787: istore #119
    //   789: aload #118
    //   791: iload #119
    //   793: iload #14
    //   795: invokeinterface setInt : (II)V
    //   800: iload #9
    //   802: iconst_4
    //   803: imul
    //   804: istore #116
    //   806: aload_0
    //   807: astore #114
    //   809: iload #116
    //   811: istore #115
    //   813: aload #114
    //   815: iload #115
    //   817: invokeinterface getInt : (I)I
    //   822: istore #14
    //   824: iload #7
    //   826: iconst_1
    //   827: isub
    //   828: istore #7
    //   830: iload #7
    //   832: iconst_4
    //   833: imul
    //   834: istore #112
    //   836: aload_0
    //   837: astore #110
    //   839: iload #112
    //   841: istore #111
    //   843: aload #110
    //   845: iload #111
    //   847: invokeinterface getInt : (I)I
    //   852: iload #14
    //   854: if_icmpgt -> 824
    //   857: goto -> 860
    //   860: iload #7
    //   862: iconst_4
    //   863: imul
    //   864: istore #107
    //   866: aload_1
    //   867: astore #105
    //   869: iload #107
    //   871: istore #106
    //   873: aload #105
    //   875: iload #106
    //   877: invokeinterface getInt : (I)I
    //   882: istore #4
    //   884: iload #7
    //   886: iconst_4
    //   887: imul
    //   888: istore #103
    //   890: aload_0
    //   891: astore #101
    //   893: iload #103
    //   895: istore #102
    //   897: aload #101
    //   899: iload #102
    //   901: invokeinterface getInt : (I)I
    //   906: istore #13
    //   908: iinc #8, 1
    //   911: iload #8
    //   913: iconst_4
    //   914: imul
    //   915: istore #99
    //   917: aload_0
    //   918: astore #97
    //   920: iload #99
    //   922: istore #98
    //   924: aload #97
    //   926: iload #98
    //   928: invokeinterface getInt : (I)I
    //   933: iload #14
    //   935: if_icmplt -> 908
    //   938: goto -> 941
    //   941: iload #8
    //   943: iload #7
    //   945: if_icmpgt -> 951
    //   948: goto -> 954
    //   951: goto -> 1101
    //   954: iload #7
    //   956: iconst_4
    //   957: imul
    //   958: istore #94
    //   960: aload_1
    //   961: astore #92
    //   963: iload #94
    //   965: istore #93
    //   967: iload #8
    //   969: iconst_4
    //   970: imul
    //   971: istore #90
    //   973: aload_1
    //   974: astore #88
    //   976: iload #90
    //   978: istore #89
    //   980: aload #88
    //   982: iload #89
    //   984: invokeinterface getInt : (I)I
    //   989: istore #87
    //   991: aload #92
    //   993: iload #93
    //   995: iload #87
    //   997: invokeinterface setInt : (II)V
    //   1002: iload #8
    //   1004: iconst_4
    //   1005: imul
    //   1006: istore #85
    //   1008: aload_1
    //   1009: astore #83
    //   1011: iload #85
    //   1013: istore #84
    //   1015: aload #83
    //   1017: iload #84
    //   1019: iload #4
    //   1021: invokeinterface setInt : (II)V
    //   1026: iload #7
    //   1028: iconst_4
    //   1029: imul
    //   1030: istore #81
    //   1032: aload_0
    //   1033: astore #79
    //   1035: iload #81
    //   1037: istore #80
    //   1039: iload #8
    //   1041: iconst_4
    //   1042: imul
    //   1043: istore #77
    //   1045: aload_0
    //   1046: astore #75
    //   1048: iload #77
    //   1050: istore #76
    //   1052: aload #75
    //   1054: iload #76
    //   1056: invokeinterface getInt : (I)I
    //   1061: istore #74
    //   1063: aload #79
    //   1065: iload #80
    //   1067: iload #74
    //   1069: invokeinterface setInt : (II)V
    //   1074: iload #8
    //   1076: iconst_4
    //   1077: imul
    //   1078: istore #72
    //   1080: aload_0
    //   1081: astore #70
    //   1083: iload #72
    //   1085: istore #71
    //   1087: aload #70
    //   1089: iload #71
    //   1091: iload #13
    //   1093: invokeinterface setInt : (II)V
    //   1098: goto -> 824
    //   1101: iinc #6, 1
    //   1104: iload #7
    //   1106: iload_2
    //   1107: isub
    //   1108: istore #69
    //   1110: iload_3
    //   1111: iload #8
    //   1113: isub
    //   1114: istore #68
    //   1116: iload #69
    //   1118: iload #68
    //   1120: if_icmple -> 1126
    //   1123: goto -> 1145
    //   1126: aload #16
    //   1128: iload #6
    //   1130: iload #8
    //   1132: iastore
    //   1133: aload #15
    //   1135: iload #6
    //   1137: iload_3
    //   1138: iastore
    //   1139: iload #7
    //   1141: istore_3
    //   1142: goto -> 1191
    //   1145: aload #16
    //   1147: iload #6
    //   1149: iload_2
    //   1150: iastore
    //   1151: aload #15
    //   1153: iload #6
    //   1155: iload #7
    //   1157: iastore
    //   1158: iload #8
    //   1160: istore_2
    //   1161: goto -> 1191
    //   1164: iload #6
    //   1166: iconst_1
    //   1167: if_icmpeq -> 1508
    //   1170: goto -> 1173
    //   1173: aload #16
    //   1175: iload #6
    //   1177: iaload
    //   1178: istore_2
    //   1179: aload #15
    //   1181: iload #6
    //   1183: iaload
    //   1184: istore_3
    //   1185: iload #6
    //   1187: iconst_1
    //   1188: isub
    //   1189: istore #6
    //   1191: iload_3
    //   1192: iload_2
    //   1193: isub
    //   1194: bipush #10
    //   1196: if_icmpgt -> 1202
    //   1199: goto -> 1205
    //   1202: goto -> 107
    //   1205: iload_2
    //   1206: iload #10
    //   1208: if_icmpeq -> 1214
    //   1211: goto -> 1217
    //   1214: goto -> 68
    //   1217: iload_2
    //   1218: iconst_1
    //   1219: isub
    //   1220: istore_2
    //   1221: iinc #2, 1
    //   1224: iload_2
    //   1225: iload_3
    //   1226: if_icmpeq -> 1232
    //   1229: goto -> 1235
    //   1232: goto -> 1164
    //   1235: iload_2
    //   1236: iconst_1
    //   1237: iadd
    //   1238: iconst_4
    //   1239: imul
    //   1240: istore #64
    //   1242: aload_1
    //   1243: astore #62
    //   1245: iload #64
    //   1247: istore #63
    //   1249: aload #62
    //   1251: iload #63
    //   1253: invokeinterface getInt : (I)I
    //   1258: istore #5
    //   1260: iload_2
    //   1261: iconst_1
    //   1262: iadd
    //   1263: iconst_4
    //   1264: imul
    //   1265: istore #59
    //   1267: aload_0
    //   1268: astore #57
    //   1270: iload #59
    //   1272: istore #58
    //   1274: aload #57
    //   1276: iload #58
    //   1278: invokeinterface getInt : (I)I
    //   1283: istore #14
    //   1285: iload_2
    //   1286: iconst_4
    //   1287: imul
    //   1288: istore #55
    //   1290: aload_0
    //   1291: astore #53
    //   1293: iload #55
    //   1295: istore #54
    //   1297: aload #53
    //   1299: iload #54
    //   1301: invokeinterface getInt : (I)I
    //   1306: iload #14
    //   1308: if_icmple -> 1221
    //   1311: goto -> 1314
    //   1314: iload_2
    //   1315: istore #8
    //   1317: iload #8
    //   1319: iconst_1
    //   1320: iadd
    //   1321: iconst_4
    //   1322: imul
    //   1323: istore #49
    //   1325: aload_1
    //   1326: astore #47
    //   1328: iload #49
    //   1330: istore #48
    //   1332: iload #8
    //   1334: iconst_4
    //   1335: imul
    //   1336: istore #45
    //   1338: aload_1
    //   1339: astore #43
    //   1341: iload #45
    //   1343: istore #44
    //   1345: aload #43
    //   1347: iload #44
    //   1349: invokeinterface getInt : (I)I
    //   1354: istore #42
    //   1356: aload #47
    //   1358: iload #48
    //   1360: iload #42
    //   1362: invokeinterface setInt : (II)V
    //   1367: iload #8
    //   1369: iconst_1
    //   1370: iadd
    //   1371: iconst_4
    //   1372: imul
    //   1373: istore #39
    //   1375: aload_0
    //   1376: astore #37
    //   1378: iload #39
    //   1380: istore #38
    //   1382: iload #8
    //   1384: iconst_4
    //   1385: imul
    //   1386: istore #35
    //   1388: aload_0
    //   1389: astore #33
    //   1391: iload #35
    //   1393: istore #34
    //   1395: aload #33
    //   1397: iload #34
    //   1399: invokeinterface getInt : (I)I
    //   1404: istore #32
    //   1406: aload #37
    //   1408: iload #38
    //   1410: iload #32
    //   1412: invokeinterface setInt : (II)V
    //   1417: iload #8
    //   1419: iconst_1
    //   1420: isub
    //   1421: istore #8
    //   1423: iload #8
    //   1425: iconst_4
    //   1426: imul
    //   1427: istore #30
    //   1429: aload_0
    //   1430: astore #28
    //   1432: iload #30
    //   1434: istore #29
    //   1436: aload #28
    //   1438: iload #29
    //   1440: invokeinterface getInt : (I)I
    //   1445: iload #14
    //   1447: if_icmpgt -> 1317
    //   1450: goto -> 1453
    //   1453: iload #8
    //   1455: iconst_1
    //   1456: iadd
    //   1457: iconst_4
    //   1458: imul
    //   1459: istore #24
    //   1461: aload_1
    //   1462: astore #22
    //   1464: iload #24
    //   1466: istore #23
    //   1468: aload #22
    //   1470: iload #23
    //   1472: iload #5
    //   1474: invokeinterface setInt : (II)V
    //   1479: iload #8
    //   1481: iconst_1
    //   1482: iadd
    //   1483: iconst_4
    //   1484: imul
    //   1485: istore #19
    //   1487: aload_0
    //   1488: astore #17
    //   1490: iload #19
    //   1492: istore #18
    //   1494: aload #17
    //   1496: iload #18
    //   1498: iload #14
    //   1500: invokeinterface setInt : (II)V
    //   1505: goto -> 1221
    //   1508: return
    // Line number table:
    //   Java source line number -> byte code offset
    //   #47	-> 39
    //   #55	-> 44
    //   #57	-> 53
    //   #60	-> 62
    //   #61	-> 65
    //   #64	-> 68
    //   #65	-> 76
    //   #65	-> 88
    //   #65	-> 99
    //   #67	-> 107
    //   #69	-> 110
    //   #71	-> 122
    //   #73	-> 146
    //   #74	-> 170
    //   #76	-> 199
    //   #78	-> 293
    //   #81	-> 387
    //   #82	-> 390
    //   #84	-> 419
    //   #86	-> 513
    //   #87	-> 607
    //   #89	-> 636
    //   #91	-> 730
    //   #96	-> 824
    //   #99	-> 860
    //   #101	-> 884
    //   #102	-> 908
    //   #104	-> 941
    //   #108	-> 954
    //   #110	-> 1026
    //   #113	-> 1101
    //   #114	-> 1104
    //   #116	-> 1126
    //   #117	-> 1133
    //   #118	-> 1139
    //   #121	-> 1145
    //   #122	-> 1151
    //   #123	-> 1158
    //   #129	-> 1164
    //   #132	-> 1173
    //   #133	-> 1179
    //   #134	-> 1185
    //   #137	-> 1191
    //   #139	-> 1205
    //   #141	-> 1217
    //   #144	-> 1221
    //   #145	-> 1224
    //   #149	-> 1235
    //   #151	-> 1260
    //   #152	-> 1285
    //   #154	-> 1314
    //   #158	-> 1317
    //   #160	-> 1367
    //   #161	-> 1417
    //   #162	-> 1423
    //   #165	-> 1453
    //   #167	-> 1479
    //   #0	-> 1508
    //   #129	-> 1508
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	1509	0	v	Lorg/renjin/gcc/runtime/Ptr;
    //   0	1509	1	I	Lorg/renjin/gcc/runtime/Ptr;
    //   0	1509	2	i	I
    //   0	1509	3	j	I
    //   0	1509	4	tt	I
    //   0	1509	5	it	I
    //   0	1509	6	m	I
    //   0	1509	7	l	I
    //   0	1509	8	k	I
    //   0	1509	9	ij	I
    //   0	1509	10	ii	I
    //   0	1509	11	R	D
    //   0	1509	13	vtt	I
    //   0	1509	14	vt	I
    //   0	1509	15	iu	[I
    //   0	1509	16	il	[I
    //   0	1509	21	k$48	I
    //   0	1509	26	k$47	I
    //   0	1509	31	k$46	I
    //   0	1509	36	k$45	I
    //   0	1509	41	k$44	I
    //   0	1509	46	k$43	I
    //   0	1509	51	k$42	I
    //   0	1509	56	i$41	I
    //   0	1509	61	i$40	I
    //   0	1509	66	i$39	I
    //   0	1509	73	k$38	I
    //   0	1509	78	k$37	I
    //   0	1509	82	l$36	I
    //   0	1509	86	k$35	I
    //   0	1509	91	k$34	I
    //   0	1509	95	l$33	I
    //   0	1509	100	k$32	I
    //   0	1509	104	l$31	I
    //   0	1509	108	l$30	I
    //   0	1509	113	l$29	I
    //   0	1509	117	ij$28	I
    //   0	1509	121	i$27	I
    //   0	1509	126	i$26	I
    //   0	1509	130	ij$25	I
    //   0	1509	134	ij$24	I
    //   0	1509	138	i$23	I
    //   0	1509	143	i$22	I
    //   0	1509	147	ij$21	I
    //   0	1509	152	i$20	I
    //   0	1509	156	ij$19	I
    //   0	1509	160	j$18	I
    //   0	1509	165	j$17	I
    //   0	1509	169	ij$16	I
    //   0	1509	173	ij$15	I
    //   0	1509	177	j$14	I
    //   0	1509	182	j$13	I
    //   0	1509	186	ij$12	I
    //   0	1509	191	j$11	I
    //   0	1509	195	ij$10	I
    //   0	1509	199	i$9	I
    //   0	1509	204	i$8	I
    //   0	1509	208	ij$7	I
    //   0	1509	212	ij$6	I
    //   0	1509	216	i$5	I
    //   0	1509	221	i$4	I
    //   0	1509	225	ij$3	I
    //   0	1509	230	i$2	I
    //   0	1509	234	ij$1	I
    //   0	1509	238	ij$0	I
  }
  
  public static void R_qsort_I(Ptr v, Ptr I, int i, int j) {
    // Byte code:
    //   0: bipush #40
    //   2: newarray int
    //   4: astore #17
    //   6: bipush #40
    //   8: newarray int
    //   10: astore #18
    //   12: iconst_0
    //   13: istore #4
    //   15: iconst_0
    //   16: istore #5
    //   18: iconst_0
    //   19: istore #6
    //   21: iconst_0
    //   22: istore #7
    //   24: iconst_0
    //   25: istore #8
    //   27: iconst_0
    //   28: istore #10
    //   30: dconst_0
    //   31: dstore #11
    //   33: dconst_0
    //   34: dstore #13
    //   36: dconst_0
    //   37: dstore #15
    //   39: ldc2_w 0.375
    //   42: dstore #11
    //   44: aload_0
    //   45: bipush #-8
    //   47: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   52: astore_0
    //   53: aload_1
    //   54: bipush #-4
    //   56: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   61: astore_1
    //   62: iload_2
    //   63: istore #10
    //   65: iconst_1
    //   66: istore #6
    //   68: iload_2
    //   69: iload_3
    //   70: if_icmplt -> 76
    //   73: goto -> 1191
    //   76: dload #11
    //   78: ldc2_w 0.5898437
    //   81: dcmpg
    //   82: iflt -> 88
    //   85: goto -> 99
    //   88: dload #11
    //   90: ldc2_w 0.0390625
    //   93: dadd
    //   94: dstore #11
    //   96: goto -> 107
    //   99: dload #11
    //   101: ldc2_w 0.21875
    //   104: dsub
    //   105: dstore #11
    //   107: iload_2
    //   108: istore #8
    //   110: iload_3
    //   111: iload_2
    //   112: isub
    //   113: i2d
    //   114: dload #11
    //   116: dmul
    //   117: d2i
    //   118: iload_2
    //   119: iadd
    //   120: istore #9
    //   122: iload #9
    //   124: iconst_4
    //   125: imul
    //   126: istore #251
    //   128: aload_1
    //   129: astore #249
    //   131: iload #251
    //   133: istore #250
    //   135: aload #249
    //   137: iload #250
    //   139: invokeinterface getInt : (I)I
    //   144: istore #5
    //   146: iload #9
    //   148: bipush #8
    //   150: imul
    //   151: istore #247
    //   153: aload_0
    //   154: astore #245
    //   156: iload #247
    //   158: istore #246
    //   160: aload #245
    //   162: iload #246
    //   164: invokeinterface getDouble : (I)D
    //   169: dstore #15
    //   171: iload_2
    //   172: bipush #8
    //   174: imul
    //   175: istore #243
    //   177: aload_0
    //   178: astore #241
    //   180: iload #243
    //   182: istore #242
    //   184: aload #241
    //   186: iload #242
    //   188: invokeinterface getDouble : (I)D
    //   193: dload #15
    //   195: dcmpl
    //   196: ifgt -> 202
    //   199: goto -> 394
    //   202: iload #9
    //   204: iconst_4
    //   205: imul
    //   206: istore #237
    //   208: aload_1
    //   209: astore #235
    //   211: iload #237
    //   213: istore #236
    //   215: iload_2
    //   216: iconst_4
    //   217: imul
    //   218: istore #233
    //   220: aload_1
    //   221: astore #231
    //   223: iload #233
    //   225: istore #232
    //   227: aload #231
    //   229: iload #232
    //   231: invokeinterface getInt : (I)I
    //   236: istore #230
    //   238: aload #235
    //   240: iload #236
    //   242: iload #230
    //   244: invokeinterface setInt : (II)V
    //   249: iload_2
    //   250: iconst_4
    //   251: imul
    //   252: istore #228
    //   254: aload_1
    //   255: astore #226
    //   257: iload #228
    //   259: istore #227
    //   261: aload #226
    //   263: iload #227
    //   265: iload #5
    //   267: invokeinterface setInt : (II)V
    //   272: iload #9
    //   274: iconst_4
    //   275: imul
    //   276: istore #224
    //   278: aload_1
    //   279: astore #222
    //   281: iload #224
    //   283: istore #223
    //   285: aload #222
    //   287: iload #223
    //   289: invokeinterface getInt : (I)I
    //   294: istore #5
    //   296: iload #9
    //   298: bipush #8
    //   300: imul
    //   301: istore #220
    //   303: aload_0
    //   304: astore #218
    //   306: iload #220
    //   308: istore #219
    //   310: iload_2
    //   311: bipush #8
    //   313: imul
    //   314: istore #216
    //   316: aload_0
    //   317: astore #214
    //   319: iload #216
    //   321: istore #215
    //   323: aload #214
    //   325: iload #215
    //   327: invokeinterface getDouble : (I)D
    //   332: dstore #212
    //   334: aload #218
    //   336: iload #219
    //   338: dload #212
    //   340: invokeinterface setDouble : (ID)V
    //   345: iload_2
    //   346: bipush #8
    //   348: imul
    //   349: istore #210
    //   351: aload_0
    //   352: astore #208
    //   354: iload #210
    //   356: istore #209
    //   358: aload #208
    //   360: iload #209
    //   362: dload #15
    //   364: invokeinterface setDouble : (ID)V
    //   369: iload #9
    //   371: bipush #8
    //   373: imul
    //   374: istore #206
    //   376: aload_0
    //   377: astore #204
    //   379: iload #206
    //   381: istore #205
    //   383: aload #204
    //   385: iload #205
    //   387: invokeinterface getDouble : (I)D
    //   392: dstore #15
    //   394: iload_3
    //   395: istore #7
    //   397: iload_3
    //   398: bipush #8
    //   400: imul
    //   401: istore #202
    //   403: aload_0
    //   404: astore #200
    //   406: iload #202
    //   408: istore #201
    //   410: aload #200
    //   412: iload #201
    //   414: invokeinterface getDouble : (I)D
    //   419: dload #15
    //   421: dcmpg
    //   422: iflt -> 428
    //   425: goto -> 843
    //   428: iload #9
    //   430: iconst_4
    //   431: imul
    //   432: istore #196
    //   434: aload_1
    //   435: astore #194
    //   437: iload #196
    //   439: istore #195
    //   441: iload_3
    //   442: iconst_4
    //   443: imul
    //   444: istore #192
    //   446: aload_1
    //   447: astore #190
    //   449: iload #192
    //   451: istore #191
    //   453: aload #190
    //   455: iload #191
    //   457: invokeinterface getInt : (I)I
    //   462: istore #189
    //   464: aload #194
    //   466: iload #195
    //   468: iload #189
    //   470: invokeinterface setInt : (II)V
    //   475: iload_3
    //   476: iconst_4
    //   477: imul
    //   478: istore #187
    //   480: aload_1
    //   481: astore #185
    //   483: iload #187
    //   485: istore #186
    //   487: aload #185
    //   489: iload #186
    //   491: iload #5
    //   493: invokeinterface setInt : (II)V
    //   498: iload #9
    //   500: iconst_4
    //   501: imul
    //   502: istore #183
    //   504: aload_1
    //   505: astore #181
    //   507: iload #183
    //   509: istore #182
    //   511: aload #181
    //   513: iload #182
    //   515: invokeinterface getInt : (I)I
    //   520: istore #5
    //   522: iload #9
    //   524: bipush #8
    //   526: imul
    //   527: istore #179
    //   529: aload_0
    //   530: astore #177
    //   532: iload #179
    //   534: istore #178
    //   536: iload_3
    //   537: bipush #8
    //   539: imul
    //   540: istore #175
    //   542: aload_0
    //   543: astore #173
    //   545: iload #175
    //   547: istore #174
    //   549: aload #173
    //   551: iload #174
    //   553: invokeinterface getDouble : (I)D
    //   558: dstore #171
    //   560: aload #177
    //   562: iload #178
    //   564: dload #171
    //   566: invokeinterface setDouble : (ID)V
    //   571: iload_3
    //   572: bipush #8
    //   574: imul
    //   575: istore #169
    //   577: aload_0
    //   578: astore #167
    //   580: iload #169
    //   582: istore #168
    //   584: aload #167
    //   586: iload #168
    //   588: dload #15
    //   590: invokeinterface setDouble : (ID)V
    //   595: iload #9
    //   597: bipush #8
    //   599: imul
    //   600: istore #165
    //   602: aload_0
    //   603: astore #163
    //   605: iload #165
    //   607: istore #164
    //   609: aload #163
    //   611: iload #164
    //   613: invokeinterface getDouble : (I)D
    //   618: dstore #15
    //   620: iload_2
    //   621: bipush #8
    //   623: imul
    //   624: istore #161
    //   626: aload_0
    //   627: astore #159
    //   629: iload #161
    //   631: istore #160
    //   633: aload #159
    //   635: iload #160
    //   637: invokeinterface getDouble : (I)D
    //   642: dload #15
    //   644: dcmpl
    //   645: ifgt -> 651
    //   648: goto -> 843
    //   651: iload #9
    //   653: iconst_4
    //   654: imul
    //   655: istore #155
    //   657: aload_1
    //   658: astore #153
    //   660: iload #155
    //   662: istore #154
    //   664: iload_2
    //   665: iconst_4
    //   666: imul
    //   667: istore #151
    //   669: aload_1
    //   670: astore #149
    //   672: iload #151
    //   674: istore #150
    //   676: aload #149
    //   678: iload #150
    //   680: invokeinterface getInt : (I)I
    //   685: istore #148
    //   687: aload #153
    //   689: iload #154
    //   691: iload #148
    //   693: invokeinterface setInt : (II)V
    //   698: iload_2
    //   699: iconst_4
    //   700: imul
    //   701: istore #146
    //   703: aload_1
    //   704: astore #144
    //   706: iload #146
    //   708: istore #145
    //   710: aload #144
    //   712: iload #145
    //   714: iload #5
    //   716: invokeinterface setInt : (II)V
    //   721: iload #9
    //   723: iconst_4
    //   724: imul
    //   725: istore #142
    //   727: aload_1
    //   728: astore #140
    //   730: iload #142
    //   732: istore #141
    //   734: aload #140
    //   736: iload #141
    //   738: invokeinterface getInt : (I)I
    //   743: istore #5
    //   745: iload #9
    //   747: bipush #8
    //   749: imul
    //   750: istore #138
    //   752: aload_0
    //   753: astore #136
    //   755: iload #138
    //   757: istore #137
    //   759: iload_2
    //   760: bipush #8
    //   762: imul
    //   763: istore #134
    //   765: aload_0
    //   766: astore #132
    //   768: iload #134
    //   770: istore #133
    //   772: aload #132
    //   774: iload #133
    //   776: invokeinterface getDouble : (I)D
    //   781: dstore #130
    //   783: aload #136
    //   785: iload #137
    //   787: dload #130
    //   789: invokeinterface setDouble : (ID)V
    //   794: iload_2
    //   795: bipush #8
    //   797: imul
    //   798: istore #128
    //   800: aload_0
    //   801: astore #126
    //   803: iload #128
    //   805: istore #127
    //   807: aload #126
    //   809: iload #127
    //   811: dload #15
    //   813: invokeinterface setDouble : (ID)V
    //   818: iload #9
    //   820: bipush #8
    //   822: imul
    //   823: istore #124
    //   825: aload_0
    //   826: astore #122
    //   828: iload #124
    //   830: istore #123
    //   832: aload #122
    //   834: iload #123
    //   836: invokeinterface getDouble : (I)D
    //   841: dstore #15
    //   843: iload #7
    //   845: iconst_1
    //   846: isub
    //   847: istore #7
    //   849: iload #7
    //   851: bipush #8
    //   853: imul
    //   854: istore #120
    //   856: aload_0
    //   857: astore #118
    //   859: iload #120
    //   861: istore #119
    //   863: aload #118
    //   865: iload #119
    //   867: invokeinterface getDouble : (I)D
    //   872: dload #15
    //   874: dcmpl
    //   875: ifgt -> 843
    //   878: goto -> 881
    //   881: iload #7
    //   883: iconst_4
    //   884: imul
    //   885: istore #114
    //   887: aload_1
    //   888: astore #112
    //   890: iload #114
    //   892: istore #113
    //   894: aload #112
    //   896: iload #113
    //   898: invokeinterface getInt : (I)I
    //   903: istore #4
    //   905: iload #7
    //   907: bipush #8
    //   909: imul
    //   910: istore #110
    //   912: aload_0
    //   913: astore #108
    //   915: iload #110
    //   917: istore #109
    //   919: aload #108
    //   921: iload #109
    //   923: invokeinterface getDouble : (I)D
    //   928: dstore #13
    //   930: iinc #8, 1
    //   933: iload #8
    //   935: bipush #8
    //   937: imul
    //   938: istore #106
    //   940: aload_0
    //   941: astore #104
    //   943: iload #106
    //   945: istore #105
    //   947: aload #104
    //   949: iload #105
    //   951: invokeinterface getDouble : (I)D
    //   956: dload #15
    //   958: dcmpg
    //   959: iflt -> 930
    //   962: goto -> 965
    //   965: iload #8
    //   967: iload #7
    //   969: if_icmpgt -> 975
    //   972: goto -> 978
    //   975: goto -> 1128
    //   978: iload #7
    //   980: iconst_4
    //   981: imul
    //   982: istore #100
    //   984: aload_1
    //   985: astore #98
    //   987: iload #100
    //   989: istore #99
    //   991: iload #8
    //   993: iconst_4
    //   994: imul
    //   995: istore #96
    //   997: aload_1
    //   998: astore #94
    //   1000: iload #96
    //   1002: istore #95
    //   1004: aload #94
    //   1006: iload #95
    //   1008: invokeinterface getInt : (I)I
    //   1013: istore #93
    //   1015: aload #98
    //   1017: iload #99
    //   1019: iload #93
    //   1021: invokeinterface setInt : (II)V
    //   1026: iload #8
    //   1028: iconst_4
    //   1029: imul
    //   1030: istore #91
    //   1032: aload_1
    //   1033: astore #89
    //   1035: iload #91
    //   1037: istore #90
    //   1039: aload #89
    //   1041: iload #90
    //   1043: iload #4
    //   1045: invokeinterface setInt : (II)V
    //   1050: iload #7
    //   1052: bipush #8
    //   1054: imul
    //   1055: istore #87
    //   1057: aload_0
    //   1058: astore #85
    //   1060: iload #87
    //   1062: istore #86
    //   1064: iload #8
    //   1066: bipush #8
    //   1068: imul
    //   1069: istore #83
    //   1071: aload_0
    //   1072: astore #81
    //   1074: iload #83
    //   1076: istore #82
    //   1078: aload #81
    //   1080: iload #82
    //   1082: invokeinterface getDouble : (I)D
    //   1087: dstore #79
    //   1089: aload #85
    //   1091: iload #86
    //   1093: dload #79
    //   1095: invokeinterface setDouble : (ID)V
    //   1100: iload #8
    //   1102: bipush #8
    //   1104: imul
    //   1105: istore #77
    //   1107: aload_0
    //   1108: astore #75
    //   1110: iload #77
    //   1112: istore #76
    //   1114: aload #75
    //   1116: iload #76
    //   1118: dload #13
    //   1120: invokeinterface setDouble : (ID)V
    //   1125: goto -> 843
    //   1128: iinc #6, 1
    //   1131: iload #7
    //   1133: iload_2
    //   1134: isub
    //   1135: istore #74
    //   1137: iload_3
    //   1138: iload #8
    //   1140: isub
    //   1141: istore #73
    //   1143: iload #74
    //   1145: iload #73
    //   1147: if_icmple -> 1153
    //   1150: goto -> 1172
    //   1153: aload #18
    //   1155: iload #6
    //   1157: iload #8
    //   1159: iastore
    //   1160: aload #17
    //   1162: iload #6
    //   1164: iload_3
    //   1165: iastore
    //   1166: iload #7
    //   1168: istore_3
    //   1169: goto -> 1218
    //   1172: aload #18
    //   1174: iload #6
    //   1176: iload_2
    //   1177: iastore
    //   1178: aload #17
    //   1180: iload #6
    //   1182: iload #7
    //   1184: iastore
    //   1185: iload #8
    //   1187: istore_2
    //   1188: goto -> 1218
    //   1191: iload #6
    //   1193: iconst_1
    //   1194: if_icmpeq -> 1543
    //   1197: goto -> 1200
    //   1200: aload #18
    //   1202: iload #6
    //   1204: iaload
    //   1205: istore_2
    //   1206: aload #17
    //   1208: iload #6
    //   1210: iaload
    //   1211: istore_3
    //   1212: iload #6
    //   1214: iconst_1
    //   1215: isub
    //   1216: istore #6
    //   1218: iload_3
    //   1219: iload_2
    //   1220: isub
    //   1221: bipush #10
    //   1223: if_icmpgt -> 1229
    //   1226: goto -> 1232
    //   1229: goto -> 107
    //   1232: iload_2
    //   1233: iload #10
    //   1235: if_icmpeq -> 1241
    //   1238: goto -> 1244
    //   1241: goto -> 68
    //   1244: iload_2
    //   1245: iconst_1
    //   1246: isub
    //   1247: istore_2
    //   1248: iinc #2, 1
    //   1251: iload_2
    //   1252: iload_3
    //   1253: if_icmpeq -> 1259
    //   1256: goto -> 1262
    //   1259: goto -> 1191
    //   1262: iload_2
    //   1263: iconst_1
    //   1264: iadd
    //   1265: iconst_4
    //   1266: imul
    //   1267: istore #69
    //   1269: aload_1
    //   1270: astore #67
    //   1272: iload #69
    //   1274: istore #68
    //   1276: aload #67
    //   1278: iload #68
    //   1280: invokeinterface getInt : (I)I
    //   1285: istore #5
    //   1287: iload_2
    //   1288: iconst_1
    //   1289: iadd
    //   1290: bipush #8
    //   1292: imul
    //   1293: istore #64
    //   1295: aload_0
    //   1296: astore #62
    //   1298: iload #64
    //   1300: istore #63
    //   1302: aload #62
    //   1304: iload #63
    //   1306: invokeinterface getDouble : (I)D
    //   1311: dstore #15
    //   1313: iload_2
    //   1314: bipush #8
    //   1316: imul
    //   1317: istore #60
    //   1319: aload_0
    //   1320: astore #58
    //   1322: iload #60
    //   1324: istore #59
    //   1326: aload #58
    //   1328: iload #59
    //   1330: invokeinterface getDouble : (I)D
    //   1335: dload #15
    //   1337: dcmpg
    //   1338: ifle -> 1248
    //   1341: goto -> 1344
    //   1344: iload_2
    //   1345: istore #8
    //   1347: iload #8
    //   1349: iconst_1
    //   1350: iadd
    //   1351: iconst_4
    //   1352: imul
    //   1353: istore #53
    //   1355: aload_1
    //   1356: astore #51
    //   1358: iload #53
    //   1360: istore #52
    //   1362: iload #8
    //   1364: iconst_4
    //   1365: imul
    //   1366: istore #49
    //   1368: aload_1
    //   1369: astore #47
    //   1371: iload #49
    //   1373: istore #48
    //   1375: aload #47
    //   1377: iload #48
    //   1379: invokeinterface getInt : (I)I
    //   1384: istore #46
    //   1386: aload #51
    //   1388: iload #52
    //   1390: iload #46
    //   1392: invokeinterface setInt : (II)V
    //   1397: iload #8
    //   1399: iconst_1
    //   1400: iadd
    //   1401: bipush #8
    //   1403: imul
    //   1404: istore #43
    //   1406: aload_0
    //   1407: astore #41
    //   1409: iload #43
    //   1411: istore #42
    //   1413: iload #8
    //   1415: bipush #8
    //   1417: imul
    //   1418: istore #39
    //   1420: aload_0
    //   1421: astore #37
    //   1423: iload #39
    //   1425: istore #38
    //   1427: aload #37
    //   1429: iload #38
    //   1431: invokeinterface getDouble : (I)D
    //   1436: dstore #35
    //   1438: aload #41
    //   1440: iload #42
    //   1442: dload #35
    //   1444: invokeinterface setDouble : (ID)V
    //   1449: iload #8
    //   1451: iconst_1
    //   1452: isub
    //   1453: istore #8
    //   1455: iload #8
    //   1457: bipush #8
    //   1459: imul
    //   1460: istore #33
    //   1462: aload_0
    //   1463: astore #31
    //   1465: iload #33
    //   1467: istore #32
    //   1469: aload #31
    //   1471: iload #32
    //   1473: invokeinterface getDouble : (I)D
    //   1478: dload #15
    //   1480: dcmpl
    //   1481: ifgt -> 1347
    //   1484: goto -> 1487
    //   1487: iload #8
    //   1489: iconst_1
    //   1490: iadd
    //   1491: iconst_4
    //   1492: imul
    //   1493: istore #26
    //   1495: aload_1
    //   1496: astore #24
    //   1498: iload #26
    //   1500: istore #25
    //   1502: aload #24
    //   1504: iload #25
    //   1506: iload #5
    //   1508: invokeinterface setInt : (II)V
    //   1513: iload #8
    //   1515: iconst_1
    //   1516: iadd
    //   1517: bipush #8
    //   1519: imul
    //   1520: istore #21
    //   1522: aload_0
    //   1523: astore #19
    //   1525: iload #21
    //   1527: istore #20
    //   1529: aload #19
    //   1531: iload #20
    //   1533: dload #15
    //   1535: invokeinterface setDouble : (ID)V
    //   1540: goto -> 1248
    //   1543: return
    // Line number table:
    //   Java source line number -> byte code offset
    //   #47	-> 39
    //   #55	-> 44
    //   #57	-> 53
    //   #60	-> 62
    //   #61	-> 65
    //   #64	-> 68
    //   #65	-> 76
    //   #65	-> 88
    //   #65	-> 99
    //   #67	-> 107
    //   #69	-> 110
    //   #71	-> 122
    //   #73	-> 146
    //   #74	-> 171
    //   #76	-> 202
    //   #78	-> 296
    //   #81	-> 394
    //   #82	-> 397
    //   #84	-> 428
    //   #86	-> 522
    //   #87	-> 620
    //   #89	-> 651
    //   #91	-> 745
    //   #96	-> 843
    //   #99	-> 881
    //   #101	-> 905
    //   #102	-> 930
    //   #104	-> 965
    //   #108	-> 978
    //   #110	-> 1050
    //   #113	-> 1128
    //   #114	-> 1131
    //   #116	-> 1153
    //   #117	-> 1160
    //   #118	-> 1166
    //   #121	-> 1172
    //   #122	-> 1178
    //   #123	-> 1185
    //   #129	-> 1191
    //   #132	-> 1200
    //   #133	-> 1206
    //   #134	-> 1212
    //   #137	-> 1218
    //   #139	-> 1232
    //   #141	-> 1244
    //   #144	-> 1248
    //   #145	-> 1251
    //   #149	-> 1262
    //   #151	-> 1287
    //   #152	-> 1313
    //   #154	-> 1344
    //   #158	-> 1347
    //   #160	-> 1397
    //   #161	-> 1449
    //   #162	-> 1455
    //   #165	-> 1487
    //   #167	-> 1513
    //   #0	-> 1543
    //   #129	-> 1543
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	1544	0	v	Lorg/renjin/gcc/runtime/Ptr;
    //   0	1544	1	I	Lorg/renjin/gcc/runtime/Ptr;
    //   0	1544	2	i	I
    //   0	1544	3	j	I
    //   0	1544	4	tt	I
    //   0	1544	5	it	I
    //   0	1544	6	m	I
    //   0	1544	7	l	I
    //   0	1544	8	k	I
    //   0	1544	9	ij	I
    //   0	1544	10	ii	I
    //   0	1544	11	R	D
    //   0	1544	13	vtt	D
    //   0	1544	15	vt	D
    //   0	1544	17	iu	[I
    //   0	1544	18	il	[I
    //   0	1544	23	k$97	I
    //   0	1544	28	k$96	I
    //   0	1544	34	k$95	I
    //   0	1544	40	k$94	I
    //   0	1544	45	k$93	I
    //   0	1544	50	k$92	I
    //   0	1544	55	k$91	I
    //   0	1544	61	i$90	I
    //   0	1544	66	i$89	I
    //   0	1544	71	i$88	I
    //   0	1544	78	k$87	I
    //   0	1544	84	k$86	I
    //   0	1544	88	l$85	I
    //   0	1544	92	k$84	I
    //   0	1544	97	k$83	I
    //   0	1544	101	l$82	I
    //   0	1544	107	k$81	I
    //   0	1544	111	l$80	I
    //   0	1544	115	l$79	I
    //   0	1544	121	l$78	I
    //   0	1544	125	ij$77	I
    //   0	1544	129	i$76	I
    //   0	1544	135	i$75	I
    //   0	1544	139	ij$74	I
    //   0	1544	143	ij$73	I
    //   0	1544	147	i$72	I
    //   0	1544	152	i$71	I
    //   0	1544	156	ij$70	I
    //   0	1544	162	i$69	I
    //   0	1544	166	ij$68	I
    //   0	1544	170	j$67	I
    //   0	1544	176	j$66	I
    //   0	1544	180	ij$65	I
    //   0	1544	184	ij$64	I
    //   0	1544	188	j$63	I
    //   0	1544	193	j$62	I
    //   0	1544	197	ij$61	I
    //   0	1544	203	j$60	I
    //   0	1544	207	ij$59	I
    //   0	1544	211	i$58	I
    //   0	1544	217	i$57	I
    //   0	1544	221	ij$56	I
    //   0	1544	225	ij$55	I
    //   0	1544	229	i$54	I
    //   0	1544	234	i$53	I
    //   0	1544	238	ij$52	I
    //   0	1544	244	i$51	I
    //   0	1544	248	ij$50	I
    //   0	1544	252	ij$49	I
  }
  
  static {
  
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-gnur-runtime-0.9.2724.jar!/org/renjin/gnur/qsort.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */