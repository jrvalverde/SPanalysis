/*    */ package org.renjin.gnur.api;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class stats_package
/*    */ {
/*    */   public static void S_Rf_divset(int alg, int iv, int liv, int lv, double v) {
/* 30 */     throw new UnimplementedGnuApiMethod("S_Rf_divset");
/*    */   }
/*    */   
/*    */   public static void S_nlsb_iterate(double b, double d, double dr, int iv, int liv, int lv, int n, int nd, int p, double r, double rd, double v, double x) {
/* 34 */     throw new UnimplementedGnuApiMethod("S_nlsb_iterate");
/*    */   }
/*    */   
/*    */   public static void S_nlminb_iterate(double b, double d, double fx, double g, double h, int iv, int liv, int lv, int n, double v, double x) {
/* 38 */     throw new UnimplementedGnuApiMethod("S_nlminb_iterate");
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-gnur-runtime-0.9.2724.jar!/org/renjin/gnur/api/stats_package.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */