/*      */ package org.renjin.gnur.api;
/*      */ import java.lang.invoke.MethodHandle;
/*      */ import java.nio.charset.StandardCharsets;
/*      */ import java.util.Arrays;
/*      */ import java.util.HashSet;
/*      */ import java.util.Set;
/*      */ import org.renjin.eval.Context;
/*      */ import org.renjin.eval.EvalException;
/*      */ import org.renjin.eval.FinalizationClosure;
/*      */ import org.renjin.eval.FinalizationHandler;
/*      */ import org.renjin.eval.Options;
/*      */ import org.renjin.gcc.annotations.GlobalVar;
/*      */ import org.renjin.gcc.annotations.Noop;
/*      */ import org.renjin.gcc.format.FormatArrayInput;
/*      */ import org.renjin.gcc.runtime.BytePtr;
/*      */ import org.renjin.gcc.runtime.DoublePtr;
/*      */ import org.renjin.gcc.runtime.IntPtr;
/*      */ import org.renjin.gcc.runtime.ObjectPtr;
/*      */ import org.renjin.gcc.runtime.PointerPtr;
/*      */ import org.renjin.gcc.runtime.Ptr;
/*      */ import org.renjin.gcc.runtime.Stdlib;
/*      */ import org.renjin.gnur.api.annotations.Allocator;
/*      */ import org.renjin.gnur.api.annotations.Mutee;
/*      */ import org.renjin.gnur.api.annotations.PotentialMutator;
/*      */ import org.renjin.methods.MethodDispatch;
/*      */ import org.renjin.methods.Methods;
/*      */ import org.renjin.primitives.Environments;
/*      */ import org.renjin.primitives.Identical;
/*      */ import org.renjin.primitives.Native;
/*      */ import org.renjin.primitives.R;
/*      */ import org.renjin.primitives.Sort;
/*      */ import org.renjin.primitives.Types;
/*      */ import org.renjin.primitives.Vectors;
/*      */ import org.renjin.primitives.Warning;
/*      */ import org.renjin.primitives.match.Duplicates;
/*      */ import org.renjin.primitives.packaging.Namespace;
/*      */ import org.renjin.primitives.packaging.Namespaces;
/*      */ import org.renjin.primitives.vector.RowNamesVector;
/*      */ import org.renjin.sexp.AbstractSEXP;
/*      */ import org.renjin.sexp.AtomicVector;
/*      */ import org.renjin.sexp.AttributeMap;
/*      */ import org.renjin.sexp.Closure;
/*      */ import org.renjin.sexp.ComplexArrayVector;
/*      */ import org.renjin.sexp.ComplexVector;
/*      */ import org.renjin.sexp.DoubleArrayVector;
/*      */ import org.renjin.sexp.DoubleVector;
/*      */ import org.renjin.sexp.Environment;
/*      */ import org.renjin.sexp.ExpressionVector;
/*      */ import org.renjin.sexp.ExternalPtr;
/*      */ import org.renjin.sexp.FunctionCall;
/*      */ import org.renjin.sexp.IntArrayVector;
/*      */ import org.renjin.sexp.IntVector;
/*      */ import org.renjin.sexp.ListVector;
/*      */ import org.renjin.sexp.Logical;
/*      */ import org.renjin.sexp.LogicalArrayVector;
/*      */ import org.renjin.sexp.LogicalVector;
/*      */ import org.renjin.sexp.Null;
/*      */ import org.renjin.sexp.PairList;
/*      */ import org.renjin.sexp.Promise;
/*      */ import org.renjin.sexp.RawVector;
/*      */ import org.renjin.sexp.S4Object;
/*      */ import org.renjin.sexp.SEXP;
/*      */ import org.renjin.sexp.SexpType;
/*      */ import org.renjin.sexp.StringArrayVector;
/*      */ import org.renjin.sexp.StringVector;
/*      */ import org.renjin.sexp.Symbol;
/*      */ import org.renjin.sexp.Symbols;
/*      */ import org.renjin.sexp.Vector;
/*      */ 
/*      */ public final class Rinternals {
/*      */   @GlobalVar
/*      */   public static SEXP R_GlobalEnv() {
/*   73 */     return (SEXP)Native.currentContext().getGlobalEnvironment();
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static SEXP R_GlobalEnv;
/*   79 */   public static SEXP R_EmptyEnv = (SEXP)Environment.EMPTY; @Deprecated
/*      */   public static SEXP R_BaseEnv;
/*      */   @Deprecated
/*      */   public static SEXP R_BaseNamespace;
/*      */   @Deprecated
/*      */   public static SEXP R_NamespaceRegistry;
/*      */   public static SEXP R_Srcref;
/*      */   
/*      */   @GlobalVar
/*      */   public static SEXP R_BaseEnv() {
/*   89 */     return (SEXP)Native.currentContext().getBaseEnvironment();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @GlobalVar
/*      */   public static SEXP R_BaseNamespace() {
/*  100 */     return (SEXP)Native.currentContext().getNamespaceRegistry().getBaseNamespaceEnv();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @GlobalVar
/*      */   public static SEXP R_NamespaceRegistry() {
/*  112 */     return (SEXP)Namespaces.getNamespaceRegistry(Native.currentContext().getNamespaceRegistry());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  125 */   public static final SEXP R_NilValue = (SEXP)Null.INSTANCE;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  130 */   public static final SEXP R_UnboundValue = (SEXP)Symbol.UNBOUND_VALUE;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  135 */   public static final SEXP R_MissingArg = (SEXP)Symbol.MISSING_ARG;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP R_RestartToken;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  147 */   public static final SEXP R_baseSymbol = (SEXP)Symbol.get("base");
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  152 */   public static final SEXP R_BaseSymbol = (SEXP)Symbol.get("base");
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  157 */   public static final SEXP R_BraceSymbol = (SEXP)Symbol.get("{");
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  162 */   public static final SEXP R_Bracket2Symbol = (SEXP)Symbol.get("[[");
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  167 */   public static final SEXP R_BracketSymbol = (SEXP)Symbol.get("[");
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  172 */   public static final SEXP R_ClassSymbol = (SEXP)Symbol.get("class");
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  177 */   public static final SEXP R_DeviceSymbol = (SEXP)Symbol.get(".Device");
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  182 */   public static final SEXP R_DimNamesSymbol = (SEXP)Symbol.get("dimnames");
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  187 */   public static final SEXP R_DimSymbol = (SEXP)Symbol.get("dim");
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  192 */   public static final SEXP R_DollarSymbol = (SEXP)Symbol.get("$");
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  197 */   public static final SEXP R_DotsSymbol = (SEXP)Symbol.get("...");
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  202 */   public static final SEXP R_DoubleColonSymbol = (SEXP)Symbol.get("::");
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  207 */   public static final SEXP R_DropSymbol = (SEXP)Symbol.get("drop");
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  212 */   public static final SEXP R_LastvalueSymbol = (SEXP)Symbol.get(".Last.value");
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  217 */   public static final SEXP R_LevelsSymbol = (SEXP)Symbol.get("levels");
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  222 */   public static final SEXP R_ModeSymbol = (SEXP)Symbol.get("mode");
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  227 */   public static final SEXP R_NaRmSymbol = (SEXP)Symbol.get("na.rm");
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  232 */   public static final SEXP R_NameSymbol = (SEXP)Symbol.get("name");
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  237 */   public static final SEXP R_NamesSymbol = (SEXP)Symbol.get("names");
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  242 */   public static final SEXP R_NamespaceEnvSymbol = (SEXP)Symbol.get(".__NAMESPACE__.");
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  247 */   public static final SEXP R_PackageSymbol = (SEXP)Symbol.get("package");
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  252 */   public static final SEXP R_PreviousSymbol = (SEXP)Symbol.get("previous");
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  257 */   public static final SEXP R_QuoteSymbol = (SEXP)Symbol.get("quote");
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  262 */   public static final SEXP R_RowNamesSymbol = (SEXP)Symbol.get("row.names");
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  267 */   public static final SEXP R_SeedsSymbol = (SEXP)Symbol.get(".Random.seed");
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  272 */   public static final SEXP R_SortListSymbol = (SEXP)Symbol.get("sort.list");
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  277 */   public static final SEXP R_SourceSymbol = (SEXP)Symbol.get("source");
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  282 */   public static final SEXP R_SpecSymbol = (SEXP)Symbol.get("spec");
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  287 */   public static final SEXP R_TripleColonSymbol = (SEXP)Symbol.get(":::");
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  292 */   public static final SEXP R_TspSymbol = (SEXP)Symbol.get("tsp");
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  297 */   public static final SEXP R_dot_defined = (SEXP)Symbol.get(".defined");
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  302 */   public static final SEXP R_dot_Method = (SEXP)Symbol.get(".Method");
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  307 */   public static final SEXP R_dot_packageName = (SEXP)Symbol.get(".packageName");
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  312 */   public static final SEXP R_dot_target = (SEXP)Symbol.get(".target");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  319 */   public static final SEXP R_NaString = (SEXP)GnuCharSexp.NA_STRING;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  324 */   public static final SEXP R_BlankString = (SEXP)GnuCharSexp.BLANK_STRING;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  329 */   public static final SEXP R_BlankScalarString = (SEXP)new GnuStringVector(new GnuCharSexp[] { GnuCharSexp.BLANK_STRING });
/*      */   
/*      */   public static final int CE_NATIVE = 0;
/*      */   
/*      */   public static final int CE_UTF8 = 1;
/*      */   public static final int CE_LATIN1 = 2;
/*      */   public static final int CE_BYTES = 3;
/*      */   public static final int CE_SYMBOL = 5;
/*      */   public static final int CE_ANY = 99;
/*      */   
/*      */   public static BytePtr R_CHAR(SEXP x) {
/*  340 */     GnuCharSexp charSexp = (GnuCharSexp)x;
/*  341 */     return charSexp.getValue();
/*      */   }
/*      */   
/*      */   public static boolean Rf_isNull(SEXP s) {
/*  345 */     return Types.isNull(s);
/*      */   }
/*      */   
/*      */   public static boolean Rf_isSymbol(SEXP s) {
/*  349 */     return Types.isSymbol(s);
/*      */   }
/*      */   
/*      */   public static boolean Rf_isLogical(SEXP s) {
/*  353 */     return Types.isLogical(s);
/*      */   }
/*      */   
/*      */   public static boolean Rf_isReal(SEXP s) {
/*  357 */     return Types.isReal(s);
/*      */   }
/*      */   
/*      */   public static boolean Rf_isComplex(SEXP s) {
/*  361 */     return Types.isComplex(s);
/*      */   }
/*      */   
/*      */   public static boolean Rf_isExpression(SEXP s) {
/*  365 */     return Types.isExpression(s);
/*      */   }
/*      */   
/*      */   public static boolean Rf_isEnvironment(SEXP s) {
/*  369 */     return Types.isEnvironment(s);
/*      */   }
/*      */   
/*      */   public static boolean Rf_isString(SEXP s) {
/*  373 */     return s instanceof StringVector;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean Rf_isObject(SEXP s) {
/*  384 */     return Types.isObject(s);
/*      */   }
/*      */   
/*      */   public static SEXP ATTRIB(SEXP x) {
/*  388 */     return (SEXP)x.getAttributes().asPairList();
/*      */   }
/*      */   
/*      */   public static boolean OBJECT(SEXP x) {
/*  392 */     return x.isObject();
/*      */   }
/*      */   
/*      */   public static int MARK(SEXP x) {
/*  396 */     throw new UnimplementedGnuApiMethod("MARK");
/*      */   }
/*      */   
/*      */   public static int TYPEOF(SEXP s) {
/*  400 */     if (s == Null.INSTANCE)
/*  401 */       return 0; 
/*  402 */     if (s instanceof ExpressionVector)
/*  403 */       return 20; 
/*  404 */     if (s instanceof ListVector)
/*  405 */       return 19; 
/*  406 */     if (s instanceof StringVector)
/*  407 */       return 16; 
/*  408 */     if (s instanceof DoubleVector)
/*  409 */       return 14; 
/*  410 */     if (s instanceof IntVector)
/*  411 */       return 13; 
/*  412 */     if (s instanceof LogicalVector)
/*  413 */       return 10; 
/*  414 */     if (s instanceof RawVector)
/*  415 */       return 24; 
/*  416 */     if (s instanceof Environment)
/*  417 */       return 4; 
/*  418 */     if (s instanceof ComplexVector)
/*  419 */       return 15; 
/*  420 */     if (s instanceof Closure)
/*  421 */       return 3; 
/*  422 */     if (s instanceof FunctionCall)
/*  423 */       return 6; 
/*  424 */     if (s instanceof PairList)
/*  425 */       return 2; 
/*  426 */     if (s instanceof S4Object)
/*  427 */       return 25; 
/*  428 */     if (s instanceof Promise)
/*  429 */       return 5; 
/*  430 */     if (s instanceof Symbol)
/*  431 */       return 1; 
/*  432 */     if (s instanceof GnuCharSexp)
/*  433 */       return 9; 
/*  434 */     if (s instanceof org.renjin.sexp.SpecialFunction)
/*  435 */       return 7; 
/*  436 */     if (s instanceof org.renjin.sexp.Function)
/*  437 */       return 8; 
/*  438 */     if (s instanceof ExternalPtr) {
/*  439 */       return 22;
/*      */     }
/*  441 */     throw new UnsupportedOperationException("Unknown SEXP Type: " + s.getClass().getName());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int NAMED(SEXP sexp) {
/*  453 */     return 2;
/*      */   }
/*      */ 
/*      */   
/*      */   @Noop
/*      */   public static void SET_NAMED(SEXP sexp, int value) {}
/*      */ 
/*      */   
/*      */   public static int REFCNT(SEXP x) {
/*  462 */     throw new UnimplementedGnuApiMethod("REFCNT");
/*      */   }
/*      */   
/*      */   public static void SET_OBJECT(SEXP x, int v) {
/*  466 */     if (x.isObject() && v == 0) {
/*  467 */       throw new EvalException("SET_OBJECT: value SEXP Object field doesn't match expected value", new Object[0]);
/*      */     }
/*      */   }
/*      */   
/*      */   public static void SET_TYPEOF(@Mutee SEXP x, int v) {
/*  472 */     if (TYPEOF(x) != v)
/*  473 */       throw new UnimplementedGnuApiMethod(String.format("Cannot change SEXP of type '%s' to '%s'", new Object[] {
/*  474 */               SexpType.typeName(TYPEOF(x)), 
/*  475 */               SexpType.typeName(v)
/*      */             })); 
/*      */   }
/*      */   
/*      */   public static void SET_ATTRIB(SEXP x, SEXP v) {
/*  480 */     if (v instanceof PairList) {
/*  481 */       ((AbstractSEXP)x).unsafeSetAttributes(AttributeMap.fromPairList((PairList)v));
/*      */     } else {
/*  483 */       ((AbstractSEXP)x).unsafeSetAttributes(v.getAttributes());
/*      */     } 
/*      */   }
/*      */   
/*      */   public static void DUPLICATE_ATTRIB(SEXP to, SEXP from) {
/*  488 */     AbstractSEXP abstractSEXP = (AbstractSEXP)to;
/*  489 */     if (Types.isS4(from) && !Types.isS4(to)) {
/*  490 */       abstractSEXP.unsafeSetAttributes(from.getAttributes().copy().setS4(true));
/*      */     } else {
/*  492 */       abstractSEXP.unsafeSetAttributes(from.getAttributes().copy());
/*      */     } 
/*      */   }
/*      */   
/*      */   public static int IS_S4_OBJECT(SEXP x) {
/*  497 */     return Types.isS4(x) ? 1 : 0;
/*      */   }
/*      */   
/*      */   public static void SET_S4_OBJECT(SEXP x) {
/*  501 */     AbstractSEXP abstractSEXP = (AbstractSEXP)x;
/*  502 */     abstractSEXP.unsafeSetAttributes(x.getAttributes().copy().setS4(true));
/*      */   }
/*      */   
/*      */   public static void UNSET_S4_OBJECT(SEXP x) {
/*  506 */     AbstractSEXP abstractSEXP = (AbstractSEXP)x;
/*  507 */     abstractSEXP.unsafeSetAttributes(x.getAttributes().copy().setS4(false));
/*      */   }
/*      */   
/*      */   public static int LENGTH(SEXP x) {
/*  511 */     return x.length();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int TRUELENGTH(SEXP x) {
/*  523 */     return 0;
/*      */   }
/*      */   
/*      */   public static void SETLENGTH(SEXP x, int v) {
/*  527 */     throw new UnimplementedGnuApiMethod("SETLENGTH");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void SET_TRUELENGTH(SEXP x, int v) {
/*  538 */     throw new UnimplementedGnuApiMethod("SET_TRUELENGTH");
/*      */   }
/*      */   
/*      */   public static int XLENGTH(SEXP x) {
/*  542 */     return x.length();
/*      */   }
/*      */   
/*      */   public static int XTRUELENGTH(SEXP x) {
/*  546 */     throw new UnimplementedGnuApiMethod("XTRUELENGTH");
/*      */   }
/*      */   
/*      */   public static int IS_LONG_VEC(SEXP x) {
/*  550 */     return 0;
/*      */   }
/*      */   
/*      */   public static int LEVELS(SEXP x) {
/*  554 */     SEXP levels = x.getAttribute(Symbols.LEVELS);
/*  555 */     if (Null.INSTANCE == levels) {
/*  556 */       return Integer.MIN_VALUE;
/*      */     }
/*  558 */     return levels.asInt();
/*      */   }
/*      */ 
/*      */   
/*      */   public static int SETLEVELS(SEXP x, int v) {
/*  563 */     AbstractSEXP abstractSEXP = (AbstractSEXP)x;
/*  564 */     abstractSEXP.unsafeSetAttributes(x.getAttributes().copy().set(Symbols.LEVELS, (SEXP)IntVector.valueOf(v)));
/*  565 */     return LEVELS(x);
/*      */   }
/*      */   
/*      */   public static Object DATAPTR(SEXP x) {
/*  569 */     if (x instanceof IntVector || x instanceof LogicalVector)
/*  570 */       return INTEGER(x); 
/*  571 */     if (x instanceof DoubleVector)
/*  572 */       return REAL(x); 
/*  573 */     if (x instanceof ComplexVector)
/*  574 */       return COMPLEX(x); 
/*  575 */     if (x instanceof RawVector) {
/*  576 */       return RAW(x);
/*      */     }
/*  578 */     throw new UnsupportedOperationException("DATAPTR on type " + x.getClass().getName());
/*      */   }
/*      */ 
/*      */   
/*      */   public static IntPtr LOGICAL(SEXP x) {
/*  583 */     if (x instanceof LogicalArrayVector)
/*  584 */       return new IntPtr(((LogicalArrayVector)x).toIntArrayUnsafe()); 
/*  585 */     if (x instanceof LogicalVector)
/*      */     {
/*  587 */       return new IntPtr(((LogicalVector)x).toIntArray());
/*      */     }
/*  589 */     throw new EvalException("LOGICAL(): expected logical vector, found %s", new Object[] { x.getTypeName() });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static IntPtr INTEGER(SEXP x) {
/*  598 */     if (x instanceof IntArrayVector)
/*  599 */       return new IntPtr(((IntArrayVector)x).toIntArrayUnsafe()); 
/*  600 */     if (x instanceof LogicalArrayVector)
/*  601 */       return new IntPtr(((LogicalArrayVector)x).toIntArrayUnsafe()); 
/*  602 */     if (x instanceof DoubleVector)
/*  603 */       return new IntPtr(((DoubleVector)x).toIntArray()); 
/*  604 */     if (x instanceof IntVector)
/*      */     {
/*  606 */       return new IntPtr(((IntVector)x).toIntArray()); } 
/*  607 */     if (x instanceof LogicalVector)
/*  608 */       return new IntPtr(((LogicalVector)x).toIntArray()); 
/*  609 */     if (x == Null.INSTANCE) {
/*  610 */       return new IntPtr(new int[] { 0 });
/*      */     }
/*  612 */     throw new EvalException("INTEGER(): expected integer vector, found %s", new Object[] { x.getTypeName() });
/*      */   }
/*      */ 
/*      */   
/*      */   public static BytePtr RAW(SEXP x) {
/*  617 */     if (x instanceof RawVector) {
/*  618 */       return new BytePtr(((RawVector)x).toByteArrayUnsafe());
/*      */     }
/*  620 */     throw new EvalException("RAW(): Expected raw vector, found %s", new Object[] { x.getTypeName() });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static DoublePtr REAL(SEXP x) {
/*  628 */     if (x instanceof DoubleArrayVector)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  634 */       return new DoublePtr(((DoubleArrayVector)x).toDoubleArrayUnsafe()); } 
/*  635 */     if (x instanceof DoubleVector)
/*      */     {
/*      */       
/*  638 */       return new DoublePtr(((DoubleVector)x).toDoubleArray());
/*      */     }
/*  640 */     throw new EvalException("REAL(): expected numeric vector, found %s", new Object[] { x.getTypeName() });
/*      */   }
/*      */ 
/*      */   
/*      */   public static DoublePtr COMPLEX(SEXP x) {
/*  645 */     if (x instanceof ComplexArrayVector) {
/*  646 */       return new DoublePtr(((ComplexArrayVector)x).toComplexArrayVectorUnsafe());
/*      */     }
/*      */ 
/*      */     
/*  650 */     throw new EvalException("COMPLEX(): expected complex vector, found %s", new Object[] { x.getTypeName() });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP STRING_ELT(SEXP x, int i) {
/*  665 */     if (x instanceof GnuStringVector) {
/*  666 */       return (SEXP)((GnuStringVector)x).getElementAsCharSexp(i);
/*      */     }
/*  668 */     StringVector stringVector = (StringVector)x;
/*  669 */     String string = stringVector.getElementAsString(i);
/*      */     
/*  671 */     return (SEXP)GnuCharSexp.valueOf(string);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP VECTOR_ELT(SEXP x, int i) {
/*  684 */     if (x instanceof FunctionCall || x instanceof PairList) {
/*  685 */       return ((PairList)x).getElementAsSEXP(i);
/*      */     }
/*  687 */     return ((ListVector)x).getElementAsSEXP(i);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void SET_STRING_ELT(@Mutee SEXP x, int i, SEXP v) {
/*  701 */     if (x instanceof GnuStringVector) {
/*  702 */       GnuStringVector stringVector = (GnuStringVector)x;
/*  703 */       GnuCharSexp charValue = (GnuCharSexp)v;
/*      */       
/*  705 */       stringVector.set(i, charValue);
/*      */     } else {
/*  707 */       throw new IllegalStateException("Attempt to modify a shared SEXP");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP SET_VECTOR_ELT(SEXP x, int i, SEXP v) {
/*  724 */     ListVector listVector = (ListVector)x;
/*  725 */     SEXP[] elements = listVector.toArrayUnsafe();
/*  726 */     elements[i] = v;
/*  727 */     return v;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP TAG(SEXP e) {
/*  735 */     return ((PairList.Node)e).getRawTag();
/*      */   }
/*      */ 
/*      */   
/*      */   public static SEXP CAR(SEXP e) {
/*  740 */     if (e == Null.INSTANCE) {
/*  741 */       return (SEXP)Null.INSTANCE;
/*      */     }
/*      */ 
/*      */     
/*  745 */     if (e instanceof Symbol)
/*  746 */       return (SEXP)new GnuCharSexp((Symbol)e); 
/*  747 */     if (e instanceof Closure) {
/*  748 */       return (SEXP)((Closure)e).getFormals();
/*      */     }
/*  750 */     return ((PairList.Node)e).getValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public static SEXP CDR(SEXP e) {
/*  755 */     if (e instanceof Null) {
/*  756 */       return (SEXP)Null.INSTANCE;
/*      */     }
/*  758 */     return (SEXP)((PairList.Node)e).getNext();
/*      */   }
/*      */   
/*      */   public static SEXP CAAR(SEXP e) {
/*  762 */     return CAR(CAR(e));
/*      */   }
/*      */   
/*      */   public static SEXP CDAR(SEXP e) {
/*  766 */     return CDR(CAR(e));
/*      */   }
/*      */   
/*      */   public static SEXP CADR(SEXP e) {
/*  770 */     return CAR(CDR(e));
/*      */   }
/*      */   
/*      */   public static SEXP CDDR(SEXP e) {
/*  774 */     return CDR(CDR(e));
/*      */   }
/*      */   
/*      */   public static SEXP CDDDR(SEXP e) {
/*  778 */     return CDR(CDR(CDR(e)));
/*      */   }
/*      */   
/*      */   public static SEXP CADDR(SEXP e) {
/*  782 */     return CAR(CDR(CDR(e)));
/*      */   }
/*      */   
/*      */   public static SEXP CADDDR(SEXP e) {
/*  786 */     return CAR(CDR(CDR(CDR(e))));
/*      */   }
/*      */   
/*      */   public static SEXP CAD4R(SEXP e) {
/*  790 */     return CAR(CDR(CDR(CDR(CDR(e)))));
/*      */   }
/*      */   
/*      */   public static SEXP CD4R(SEXP x) {
/*  794 */     return CDR(CDR(CDR(CDR(x))));
/*      */   }
/*      */   
/*      */   public static int MISSING(SEXP x) {
/*  798 */     throw new UnimplementedGnuApiMethod("MISSING");
/*      */   }
/*      */   
/*      */   public static void SET_MISSING(SEXP x, int v) {
/*  802 */     throw new UnimplementedGnuApiMethod("SET_MISSING");
/*      */   }
/*      */   
/*      */   public static void SET_TAG(SEXP x, SEXP y) {
/*  806 */     ((PairList)x).setTag(y);
/*      */   }
/*      */   
/*      */   public static SEXP SETCAR(SEXP x, SEXP y) {
/*  810 */     if (x == null || x == R_NilValue) {
/*  811 */       throw new EvalException("bad value", new Object[0]);
/*      */     }
/*      */     
/*  814 */     ((PairList.Node)x).setValue(y);
/*  815 */     return y;
/*      */   }
/*      */   
/*      */   public static SEXP SETCDR(SEXP x, SEXP y) {
/*  819 */     if (x == null || x == R_NilValue) {
/*  820 */       throw new EvalException("bad value", new Object[0]);
/*      */     }
/*      */     
/*  823 */     ((PairList.Node)x).setNextNode((PairList)y);
/*  824 */     return y;
/*      */   }
/*      */ 
/*      */   
/*      */   public static SEXP SETCADR(SEXP x, SEXP y) {
/*  829 */     if (x == null || x == R_NilValue || 
/*  830 */       CDR(x) == null || CDR(x) == R_NilValue) {
/*  831 */       throw new EvalException("bad value", new Object[0]);
/*      */     }
/*  833 */     SEXP cell = CDR(x);
/*  834 */     ((PairList.Node)cell).setValue(y);
/*  835 */     return y;
/*      */   }
/*      */   
/*      */   public static SEXP CHK(SEXP sexp) {
/*  839 */     return sexp;
/*      */   }
/*      */ 
/*      */   
/*      */   public static SEXP SETCADDR(SEXP x, SEXP y) {
/*  844 */     if (x == null || x == R_NilValue || 
/*  845 */       CDR(x) == null || CDR(x) == R_NilValue || 
/*  846 */       CDDR(x) == null || CDDR(x) == R_NilValue) {
/*  847 */       throw new EvalException("bad value", new Object[0]);
/*      */     }
/*      */     
/*  850 */     SEXP cell = CDDR(x);
/*  851 */     ((PairList.Node)cell).setValue(y);
/*  852 */     return y;
/*      */   }
/*      */ 
/*      */   
/*      */   public static SEXP SETCADDDR(SEXP x, SEXP y) {
/*  857 */     if (CHK(x) == null || x == R_NilValue || 
/*  858 */       CHK(CDR(x)) == null || CDR(x) == R_NilValue || 
/*  859 */       CHK(CDDR(x)) == null || CDDR(x) == R_NilValue || 
/*  860 */       CHK(CDDDR(x)) == null || CDDDR(x) == R_NilValue) {
/*  861 */       throw new EvalException("bad value", new Object[0]);
/*      */     }
/*  863 */     SEXP cell = CDDDR(x);
/*  864 */     ((PairList.Node)cell).setValue(y);
/*  865 */     return y;
/*      */   }
/*      */ 
/*      */   
/*      */   public static SEXP SETCAD4R(SEXP x, SEXP y) {
/*  870 */     if (CHK(x) == null || x == R_NilValue || 
/*  871 */       CHK(CDR(x)) == null || CDR(x) == R_NilValue || 
/*  872 */       CHK(CDDR(x)) == null || CDDR(x) == R_NilValue || 
/*  873 */       CHK(CDDDR(x)) == null || CDDDR(x) == R_NilValue || 
/*  874 */       CHK(CD4R(x)) == null || CD4R(x) == R_NilValue) {
/*  875 */       throw new EvalException("bad value", new Object[0]);
/*      */     }
/*  877 */     SEXP cell = CD4R(x);
/*  878 */     ((PairList.Node)cell).setValue(y);
/*  879 */     return y;
/*      */   }
/*      */   
/*      */   public static SEXP CONS_NR(SEXP a, SEXP b) {
/*  883 */     throw new UnimplementedGnuApiMethod("CONS_NR");
/*      */   }
/*      */   
/*      */   public static SEXP FORMALS(SEXP x) {
/*  887 */     return (SEXP)((Closure)x).getFormals();
/*      */   }
/*      */   
/*      */   public static SEXP BODY(SEXP x) {
/*  891 */     return ((Closure)x).getBody();
/*      */   }
/*      */   
/*      */   public static SEXP CLOENV(SEXP x) {
/*  895 */     return (SEXP)((Closure)x).getEnclosingEnvironment();
/*      */   }
/*      */   
/*      */   public static int RDEBUG(SEXP x) {
/*  899 */     throw new UnimplementedGnuApiMethod("RDEBUG");
/*      */   }
/*      */   
/*      */   public static int RSTEP(SEXP x) {
/*  903 */     throw new UnimplementedGnuApiMethod("RSTEP");
/*      */   }
/*      */   
/*      */   public static int RTRACE(SEXP x) {
/*  907 */     throw new UnimplementedGnuApiMethod("RTRACE");
/*      */   }
/*      */   
/*      */   public static void SET_RDEBUG(SEXP x, int v) {
/*  911 */     throw new UnimplementedGnuApiMethod("SET_RDEBUG");
/*      */   }
/*      */   
/*      */   public static void SET_RSTEP(SEXP x, int v) {
/*  915 */     throw new UnimplementedGnuApiMethod("SET_RSTEP");
/*      */   }
/*      */   
/*      */   public static void SET_RTRACE(SEXP x, int v) {
/*  919 */     throw new UnimplementedGnuApiMethod("SET_RTRACE");
/*      */   }
/*      */   
/*      */   public static void SET_FORMALS(SEXP x, SEXP v) {
/*  923 */     ((Closure)x).unsafeSetFormals((PairList)v);
/*      */   }
/*      */   
/*      */   public static void SET_BODY(SEXP x, SEXP v) {
/*  927 */     ((Closure)x).unsafeSetBody(v);
/*      */   }
/*      */   
/*      */   public static int IS_CACHED(SEXP x) {
/*  931 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void SET_CLOENV(SEXP x, SEXP v) {
/*  943 */     ((Closure)x).unsafeSetEnclosingEnvironment((Environment)v);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP PRINTNAME(SEXP x) {
/*  953 */     return (SEXP)GnuCharSexp.valueOf(((Symbol)x).getPrintName());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP SYMVALUE(SEXP x) {
/*  966 */     throw new UnimplementedGnuApiMethod("SYMVALUE");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP INTERNAL(SEXP x) {
/*  978 */     throw new UnimplementedGnuApiMethod("INTERNAL");
/*      */   }
/*      */   
/*      */   public static int DDVAL(SEXP x) {
/*  982 */     throw new UnimplementedGnuApiMethod("DDVAL");
/*      */   }
/*      */   
/*      */   public static void SET_DDVAL(SEXP x, int v) {
/*  986 */     throw new UnimplementedGnuApiMethod("SET_DDVAL");
/*      */   }
/*      */   
/*      */   public static void SET_PRINTNAME(SEXP x, SEXP v) {
/*  990 */     throw new UnimplementedGnuApiMethod("SET_PRINTNAME");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void SET_SYMVALUE(SEXP x, SEXP val) {
/* 1003 */     throw new UnimplementedGnuApiMethod("SET_SYMVALUE");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void SET_INTERNAL(SEXP x, SEXP v) {
/* 1017 */     throw new UnimplementedGnuApiMethod("SET_INTERNAL");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP FRAME(SEXP x) {
/* 1028 */     throw new UnimplementedGnuApiMethod("FRAME");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP ENCLOS(SEXP x) {
/* 1039 */     return (SEXP)((Environment)x).getParent();
/*      */   }
/*      */   
/*      */   public static SEXP HASHTAB(SEXP x) {
/* 1043 */     throw new UnimplementedGnuApiMethod("HASHTAB");
/*      */   }
/*      */   
/*      */   public static int ENVFLAGS(SEXP x) {
/* 1047 */     throw new UnimplementedGnuApiMethod("ENVFLAGS");
/*      */   }
/*      */   
/*      */   public static void SET_ENVFLAGS(SEXP x, int v) {
/* 1051 */     throw new UnimplementedGnuApiMethod("SET_ENVFLAGS");
/*      */   }
/*      */   
/*      */   public static void SET_FRAME(SEXP x, SEXP v) {
/* 1055 */     throw new UnimplementedGnuApiMethod("SET_FRAME");
/*      */   }
/*      */   
/*      */   public static void SET_ENCLOS(SEXP env, SEXP parent) {
/* 1059 */     ((Environment)env).setParent((Environment)parent);
/*      */   }
/*      */   
/*      */   public static void SET_HASHTAB(SEXP x, SEXP v) {
/* 1063 */     throw new UnimplementedGnuApiMethod("SET_HASHTAB");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP PRCODE(SEXP x) {
/* 1075 */     throw new UnimplementedGnuApiMethod("PRCODE");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP PRENV(SEXP x) {
/* 1087 */     Promise promise = (Promise)x;
/* 1088 */     if (promise.isEvaluated()) {
/* 1089 */       return (SEXP)Null.INSTANCE;
/*      */     }
/* 1091 */     return (SEXP)promise.getEnvironment();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP PRVALUE(SEXP x) {
/* 1103 */     throw new UnimplementedGnuApiMethod("PRVALUE");
/*      */   }
/*      */   
/*      */   public static int PRSEEN(SEXP x) {
/* 1107 */     throw new UnimplementedGnuApiMethod("PRSEEN");
/*      */   }
/*      */   
/*      */   public static void SET_PRSEEN(SEXP x, int v) {
/* 1111 */     throw new UnimplementedGnuApiMethod("SET_PRSEEN");
/*      */   }
/*      */   
/*      */   public static void SET_PRENV(SEXP x, SEXP v) {
/* 1115 */     throw new UnimplementedGnuApiMethod("SET_PRENV");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void SET_PRVALUE(SEXP x, SEXP v) {
/* 1129 */     throw new UnimplementedGnuApiMethod("SET_PRVALUE");
/*      */   }
/*      */   
/*      */   public static void SET_PRCODE(SEXP x, SEXP v) {
/* 1133 */     throw new UnimplementedGnuApiMethod("SET_PRCODE");
/*      */   }
/*      */   
/*      */   public static int HASHASH(SEXP x) {
/* 1137 */     throw new UnimplementedGnuApiMethod("HASHASH");
/*      */   }
/*      */   
/*      */   public static int HASHVALUE(SEXP x) {
/* 1141 */     throw new UnimplementedGnuApiMethod("HASHVALUE");
/*      */   }
/*      */   
/*      */   public static void SET_HASHASH(SEXP x, int v) {
/* 1145 */     throw new UnimplementedGnuApiMethod("SET_HASHASH");
/*      */   }
/*      */   
/*      */   public static void SET_HASHVALUE(SEXP x, int v) {
/* 1149 */     throw new UnimplementedGnuApiMethod("SET_HASHVALUE");
/*      */   }
/*      */   
/*      */   public static SEXP R_GetCurrentSrcref(int p0) {
/* 1153 */     throw new UnimplementedGnuApiMethod("R_GetCurrentSrcref");
/*      */   }
/*      */   
/*      */   public static SEXP R_GetSrcFilename(SEXP p0) {
/* 1157 */     throw new UnimplementedGnuApiMethod("R_GetSrcFilename");
/*      */   }
/*      */   
/*      */   public static SEXP Rf_asChar(SEXP p0) {
/* 1161 */     if (p0.length() == 0) {
/* 1162 */       return R_NaString;
/*      */     }
/* 1164 */     return (SEXP)GnuCharSexp.valueOf(((AtomicVector)p0).getElementAsString(0));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP Rf_coerceVector(SEXP p0, int type) {
/* 1172 */     switch (type) {
/*      */       case 2:
/* 1174 */         return (SEXP)PairList.Node.fromVector((Vector)p0);
/*      */       case 10:
/* 1176 */         return Vectors.asLogical((Vector)p0).setAttributes(p0.getAttributes());
/*      */       case 13:
/* 1178 */         return asIntArrayVector((Vector)p0);
/*      */       case 14:
/* 1180 */         return asDoubleArrayVector((Vector)p0);
/*      */       case 15:
/* 1182 */         return Vectors.asComplex((Vector)p0).setAttributes(p0.getAttributes());
/*      */       case 16:
/* 1184 */         return Vectors.asCharacter(Native.currentContext(), (Vector)p0).setAttributes(p0.getAttributes());
/*      */       case 20:
/* 1186 */         return toExpressionList(p0);
/*      */     } 
/* 1188 */     throw new UnimplementedGnuApiMethod("Rf_coerceVector: " + type);
/*      */   }
/*      */   
/*      */   private static SEXP asIntArrayVector(Vector vector) {
/* 1192 */     Vectors.checkForListThatCannotBeCoercedToAtomicVector(vector, "integer");
/*      */     
/* 1194 */     IntArrayVector.Builder builder = new IntArrayVector.Builder(0, vector.length());
/* 1195 */     Vector integerVector = Vectors.convertToAtomicVector((Vector.Builder)builder, vector);
/* 1196 */     return integerVector.setAttributes(vector.getAttributes());
/*      */   }
/*      */   
/*      */   private static SEXP asDoubleArrayVector(Vector vector) {
/* 1200 */     Vectors.checkForListThatCannotBeCoercedToAtomicVector(vector, "double");
/*      */     
/* 1202 */     DoubleArrayVector.Builder builder = new DoubleArrayVector.Builder(0, vector.length());
/* 1203 */     Vector integerVector = Vectors.convertToAtomicVector((Vector.Builder)builder, vector);
/* 1204 */     return integerVector.setAttributes(vector.getAttributes());
/*      */   }
/*      */   
/*      */   private static SEXP toExpressionList(SEXP sexp) {
/* 1208 */     if (sexp instanceof Vector)
/* 1209 */       return Vectors.asVector((Vector)sexp, "expression"); 
/* 1210 */     if (sexp instanceof PairList) {
/* 1211 */       return toExpressionList((SEXP)((PairList)sexp).toVector());
/*      */     }
/* 1213 */     throw new UnsupportedOperationException("Rf_coerceVector: from: " + sexp.getTypeName() + " to EXPRSXP");
/*      */   }
/*      */ 
/*      */   
/*      */   public static SEXP Rf_PairToVectorList(SEXP x) {
/* 1218 */     PairList pairList = (PairList)x;
/* 1219 */     return (SEXP)pairList.toVector();
/*      */   }
/*      */   
/*      */   public static SEXP Rf_VectorToPairList(SEXP x) {
/* 1223 */     return (SEXP)PairList.Node.fromVector((Vector)x);
/*      */   }
/*      */   
/*      */   public static SEXP Rf_asCharacterFactor(SEXP x) {
/* 1227 */     throw new UnimplementedGnuApiMethod("Rf_asCharacterFactor");
/*      */   }
/*      */   
/*      */   public static int Rf_asLogical(SEXP x) {
/* 1231 */     int warn = 0;
/*      */     
/* 1233 */     if (Rf_isVectorAtomic(x)) {
/* 1234 */       if (XLENGTH(x) < 1) {
/* 1235 */         return Integer.MIN_VALUE;
/*      */       }
/*      */       
/* 1238 */       return ((AtomicVector)x).getElementAsRawLogical(0);
/*      */     } 
/* 1240 */     if (x instanceof GnuCharSexp) {
/* 1241 */       return StringVector.logicalFromString(((GnuCharSexp)x).getValue().nullTerminatedString());
/*      */     }
/*      */     
/* 1244 */     return LogicalVector.NA;
/*      */   }
/*      */   
/*      */   public static int Rf_asInteger(SEXP x) {
/* 1248 */     int warn = 0;
/*      */     
/* 1250 */     if (Rf_isVectorAtomic(x) && XLENGTH(x) >= 1) {
/* 1251 */       if (x instanceof AtomicVector) {
/* 1252 */         return ((AtomicVector)x).getElementAsInt(0);
/*      */       }
/* 1254 */       throw UNIMPLEMENTED_TYPE("asInteger", x);
/*      */     } 
/* 1256 */     if (x instanceof org.renjin.sexp.CHARSEXP) {
/* 1257 */       throw new UnsupportedOperationException();
/*      */     }
/* 1259 */     return Integer.MIN_VALUE;
/*      */   }
/*      */   
/*      */   public static double Rf_asReal(SEXP x) {
/* 1263 */     int warn = 0;
/*      */     
/* 1265 */     if (Rf_isVectorAtomic(x) && XLENGTH(x) >= 1) {
/* 1266 */       if (x instanceof AtomicVector) {
/* 1267 */         return ((AtomicVector)x).getElementAsDouble(0);
/*      */       }
/* 1269 */       throw UNIMPLEMENTED_TYPE("asReal", x);
/*      */     } 
/* 1271 */     if (x instanceof org.renjin.sexp.CHARSEXP) {
/* 1272 */       throw new UnsupportedOperationException();
/*      */     }
/* 1274 */     return DoubleVector.NA;
/*      */   }
/*      */ 
/*      */   
/*      */   private static EvalException UNIMPLEMENTED_TYPE(String s, SEXP t) {
/* 1279 */     return new EvalException("unimplemented type '%s' in '%s'\n", new Object[] { t.getTypeName(), s });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BytePtr Rf_acopy_string(BytePtr p0) {
/* 1286 */     throw new UnimplementedGnuApiMethod("Rf_acopy_string");
/*      */   }
/*      */   
/*      */   public static void Rf_addMissingVarsToNewEnv(SEXP p0, SEXP p1) {
/* 1290 */     throw new UnimplementedGnuApiMethod("Rf_addMissingVarsToNewEnv");
/*      */   }
/*      */   
/*      */   public static SEXP Rf_alloc3DArray(int p0, int p1, int p2, int p3) {
/* 1294 */     throw new UnimplementedGnuApiMethod("Rf_alloc3DArray");
/*      */   }
/*      */   
/*      */   public static SEXP Rf_allocArray(int p0, SEXP p1) {
/* 1298 */     throw new UnimplementedGnuApiMethod("Rf_allocArray");
/*      */   }
/*      */   
/*      */   public static SEXP Rf_allocFormalsList2(SEXP sym1, SEXP sym2) {
/* 1302 */     throw new UnimplementedGnuApiMethod("Rf_allocFormalsList2");
/*      */   }
/*      */   
/*      */   public static SEXP Rf_allocFormalsList3(SEXP sym1, SEXP sym2, SEXP sym3) {
/* 1306 */     throw new UnimplementedGnuApiMethod("Rf_allocFormalsList3");
/*      */   }
/*      */   
/*      */   public static SEXP Rf_allocFormalsList4(SEXP sym1, SEXP sym2, SEXP sym3, SEXP sym4) {
/* 1310 */     throw new UnimplementedGnuApiMethod("Rf_allocFormalsList4");
/*      */   }
/*      */   
/*      */   public static SEXP Rf_allocFormalsList5(SEXP sym1, SEXP sym2, SEXP sym3, SEXP sym4, SEXP sym5) {
/* 1314 */     throw new UnimplementedGnuApiMethod("Rf_allocFormalsList5");
/*      */   }
/*      */   
/*      */   public static SEXP Rf_allocFormalsList6(SEXP sym1, SEXP sym2, SEXP sym3, SEXP sym4, SEXP sym5, SEXP sym6) {
/* 1318 */     throw new UnimplementedGnuApiMethod("Rf_allocFormalsList6");
/*      */   }
/*      */   
/*      */   public static SEXP Rf_allocMatrix(int type, int numRows, int numCols) {
/* 1322 */     AttributeMap attributes = AttributeMap.builder().setDim(numRows, numCols).build();
/* 1323 */     switch (type) {
/*      */       case 13:
/* 1325 */         return (SEXP)new IntArrayVector(new int[numRows * numCols], attributes);
/*      */       case 14:
/* 1327 */         return (SEXP)new DoubleArrayVector(new double[numRows * numCols], attributes);
/*      */       case 10:
/* 1329 */         return (SEXP)new LogicalArrayVector(new int[numRows * numCols], attributes);
/*      */     } 
/* 1331 */     throw new IllegalArgumentException("type: " + type);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Allocator
/*      */   public static SEXP Rf_allocList(int n) {
/* 1348 */     PairList.Builder list = new PairList.Builder();
/* 1349 */     for (int i = 0; i < n; i++) {
/* 1350 */       list.add(R_NilValue, R_NilValue);
/*      */     }
/* 1352 */     return (SEXP)list.build();
/*      */   }
/*      */   
/*      */   @Allocator
/*      */   public static SEXP Rf_allocLang(int n) {
/* 1357 */     FunctionCall.Builder lang = new FunctionCall.Builder();
/* 1358 */     for (int i = 0; i < n; i++) {
/* 1359 */       lang.add(R_NilValue, R_NilValue);
/*      */     }
/* 1361 */     return (SEXP)lang.build();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Allocator
/*      */   public static SEXP Rf_allocS4Object() {
/* 1370 */     throw new UnimplementedGnuApiMethod("Rf_allocS4Object");
/*      */   }
/*      */   
/*      */   @Allocator
/*      */   public static SEXP Rf_allocSExp(int type) {
/* 1375 */     switch (type) {
/*      */       case 3:
/* 1377 */         return (SEXP)new Closure((Environment)Environment.EMPTY, (PairList)Null.INSTANCE, (SEXP)Null.INSTANCE);
/*      */     } 
/* 1379 */     throw new UnimplementedGnuApiMethod("Rf_allocSExp: " + type);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static int Rf_any_duplicated(SEXP x, boolean from_last) {
/* 1385 */     return Duplicates.anyDuplicated((Vector)x, (AtomicVector)LogicalVector.FALSE, from_last);
/*      */   }
/*      */   
/*      */   public static int Rf_any_duplicated3(SEXP x, SEXP incomp, boolean from_last) {
/* 1389 */     return Duplicates.anyDuplicated((Vector)x, (AtomicVector)incomp, from_last);
/*      */   }
/*      */   
/*      */   public static SEXP Rf_applyClosure(SEXP p0, SEXP p1, SEXP p2, SEXP p3, SEXP p4) {
/* 1393 */     throw new UnimplementedGnuApiMethod("Rf_applyClosure");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @PotentialMutator
/*      */   public static SEXP Rf_classgets(@Mutee SEXP object, SEXP classNames) {
/* 1400 */     return Native.currentContext().evaluate((SEXP)FunctionCall.newCall((SEXP)Symbol.get("class<-"), new SEXP[] { object, classNames }));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP Rf_cons(SEXP cr, SEXP tail) {
/* 1415 */     assert tail instanceof PairList : "tail argument must be a pairlist";
/* 1416 */     return (SEXP)new PairList.Node(cr, (PairList)tail);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static void Rf_copyMatrix(SEXP s, SEXP t, boolean byrow) {
/* 1422 */     int nr = Rf_nrows(s), nc = Rf_ncols(s);
/* 1423 */     int nt = XLENGTH(t);
/*      */     
/* 1425 */     if (byrow) {
/* 1426 */       throw new UnimplementedGnuApiMethod("copyMatrix(byrow=TRUE)");
/*      */     }
/* 1428 */     Rf_copyVector(s, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public static void Rf_copyListMatrix(SEXP p0, SEXP p1, boolean p2) {
/* 1433 */     throw new UnimplementedGnuApiMethod("Rf_copyListMatrix");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void Rf_copyMostAttrib(SEXP inp, SEXP ans) {
/* 1453 */     AttributeMap inpAttrib = inp.getAttributes().copy().removeDim().removeDimnames().remove(Symbols.NAMES).build();
/* 1454 */     ((AbstractSEXP)ans).unsafeSetAttributes(ans.getAttributes().copy().combineFrom(inpAttrib));
/*      */   }
/*      */ 
/*      */   
/*      */   public static void Rf_copyVector(SEXP s, SEXP t) {
/* 1459 */     int sT = TYPEOF(s), tT = TYPEOF(t);
/* 1460 */     if (sT != tT) {
/* 1461 */       throw new EvalException("vector types do not match in copyVector", new Object[0]);
/*      */     }
/*      */     
/* 1464 */     int ns = XLENGTH(s), nt = XLENGTH(t);
/* 1465 */     switch (sT) {
/*      */       case 16:
/* 1467 */         xcopyStringWithRecycle(s, t, 0, ns, nt);
/*      */         return;
/*      */       case 10:
/* 1470 */         xcopyLogicalWithRecycle(s, t, 0, ns, nt);
/*      */         return;
/*      */       case 13:
/* 1473 */         xcopyIntegerWithRecycle(s, t, 0, ns, nt);
/*      */         return;
/*      */       case 14:
/* 1476 */         xcopyRealWithRecycle(s, t, 0, ns, nt);
/*      */         return;
/*      */       case 15:
/* 1479 */         xcopyComplexWithRecycle(s, t, 0, ns, nt);
/*      */         return;
/*      */       case 19:
/*      */       case 20:
/* 1483 */         xcopyVectorWithRecycle(s, t, 0, ns, nt);
/*      */         return;
/*      */       case 24:
/* 1486 */         xcopyRawWithRecycle(s, t, 0, ns, nt);
/*      */         return;
/*      */     } 
/* 1489 */     UNIMPLEMENTED_TYPE("copyVector", s);
/*      */   }
/*      */ 
/*      */   
/*      */   private static void xcopyRawWithRecycle(SEXP s, SEXP t, int i, int ns, int nt) {
/* 1494 */     throw new UnimplementedGnuApiMethod("xcopyRawWithRecycle");
/*      */   }
/*      */ 
/*      */   
/*      */   private static void xcopyVectorWithRecycle(SEXP s, SEXP t, int i, int ns, int nt) {
/* 1499 */     throw new UnimplementedGnuApiMethod("xcopyVectorWithRecycle");
/*      */   }
/*      */   
/*      */   private static void xcopyComplexWithRecycle(SEXP s, SEXP t, int i, int ns, int nt) {
/* 1503 */     throw new UnimplementedGnuApiMethod("xcopyComplexWithRecycle");
/*      */   }
/*      */   
/*      */   private static void xcopyRealWithRecycle(SEXP dst, SEXP src, int dstart, int n, int nsrc) {
/*      */     double[] sa;
/* 1508 */     DoubleVector sv = (DoubleVector)src;
/* 1509 */     if (!(dst instanceof DoubleArrayVector)) {
/* 1510 */       throw new EvalException("Illegal modification of target vector: " + src.getClass().getName(), new Object[0]);
/*      */     }
/* 1512 */     DoubleArrayVector dv = (DoubleArrayVector)dst;
/*      */ 
/*      */     
/* 1515 */     double[] da = dv.toDoubleArrayUnsafe();
/* 1516 */     if (sv instanceof DoubleArrayVector) {
/* 1517 */       sa = ((DoubleArrayVector)sv).toDoubleArrayUnsafe();
/*      */     } else {
/* 1519 */       sa = sv.toDoubleArray();
/*      */     } 
/*      */     
/* 1522 */     if (nsrc >= n) {
/* 1523 */       System.arraycopy(sa, 0, da, dstart, n);
/*      */     }
/* 1525 */     else if (nsrc == 1) {
/* 1526 */       Arrays.fill(da, dstart, dstart + n, sa[0]);
/*      */     }
/*      */     else {
/*      */       
/* 1530 */       int sidx = 0;
/* 1531 */       for (int i = 0; i < n; i++, sidx++) {
/* 1532 */         if (sidx == nsrc) {
/* 1533 */           sidx = 0;
/*      */         }
/* 1535 */         da[dstart + i] = sa[sidx];
/*      */       } 
/*      */     } 
/*      */   }
/*      */   private static void xcopyIntegerWithRecycle(SEXP dst, SEXP src, int dstart, int n, int nsrc) {
/*      */     int[] sa;
/* 1541 */     IntVector sv = (IntVector)src;
/* 1542 */     if (!(dst instanceof IntArrayVector)) {
/* 1543 */       throw new EvalException("Illegal modification of target vector: " + src.getClass().getName(), new Object[0]);
/*      */     }
/* 1545 */     IntArrayVector dv = (IntArrayVector)dst;
/*      */ 
/*      */     
/* 1548 */     int[] da = dv.toIntArrayUnsafe();
/* 1549 */     if (sv instanceof IntArrayVector) {
/* 1550 */       sa = ((IntArrayVector)sv).toIntArrayUnsafe();
/*      */     } else {
/* 1552 */       sa = sv.toIntArray();
/*      */     } 
/* 1554 */     copy(sa, da, dstart, n, nsrc);
/*      */   }
/*      */   private static void xcopyLogicalWithRecycle(SEXP dst, SEXP src, int dstart, int n, int nsrc) {
/*      */     int[] sa;
/* 1558 */     LogicalVector sv = (LogicalVector)src;
/* 1559 */     if (!(dst instanceof LogicalArrayVector)) {
/* 1560 */       throw new EvalException("Illegal modification of target vector: " + dst.getClass().getName(), new Object[0]);
/*      */     }
/* 1562 */     LogicalArrayVector dv = (LogicalArrayVector)dst;
/*      */ 
/*      */     
/* 1565 */     int[] da = dv.toIntArrayUnsafe();
/* 1566 */     if (sv instanceof LogicalArrayVector) {
/* 1567 */       sa = ((LogicalArrayVector)sv).toIntArrayUnsafe();
/*      */     } else {
/* 1569 */       sa = sv.toIntArray();
/*      */     } 
/* 1571 */     copy(sa, da, dstart, n, nsrc);
/*      */   }
/*      */   
/*      */   private static void copy(int[] sa, int[] da, int dstart, int n, int nsrc) {
/* 1575 */     if (nsrc >= n) {
/*      */       
/* 1577 */       System.arraycopy(sa, 0, da, dstart, n);
/*      */     }
/* 1579 */     else if (nsrc == 1) {
/*      */       
/* 1581 */       Arrays.fill(da, dstart, dstart + n, sa[0]);
/*      */     }
/*      */     else {
/*      */       
/* 1585 */       int sidx = 0;
/* 1586 */       for (int i = 0; i < n; i++, sidx++) {
/* 1587 */         if (sidx == nsrc) {
/* 1588 */           sidx = 0;
/*      */         }
/* 1590 */         da[dstart + i] = sa[sidx];
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private static void xcopyStringWithRecycle(SEXP s, SEXP t, int i, int ns, int nt) {
/* 1596 */     throw new UnsupportedOperationException("xcopyStringWithRecycle: not yet supported by Renjin");
/*      */   }
/*      */   
/*      */   public static int Rf_countContexts(int p0, int p1) {
/* 1600 */     throw new UnimplementedGnuApiMethod("Rf_countContexts");
/*      */   }
/*      */   
/*      */   public static SEXP Rf_CreateTag(SEXP p0) {
/* 1604 */     throw new UnimplementedGnuApiMethod("Rf_CreateTag");
/*      */   }
/*      */   
/*      */   public static void Rf_defineVar(SEXP nameSexp, SEXP value, SEXP rhoSexp) {
/* 1608 */     Symbol name = (Symbol)nameSexp;
/* 1609 */     Environment rho = (Environment)rhoSexp;
/*      */     
/* 1611 */     rho.setVariable(Native.currentContext(), name, value);
/*      */   }
/*      */   
/*      */   public static SEXP Rf_dimgets(SEXP sexp, SEXP dim) {
/* 1615 */     return sexp.setAttributes(sexp.getAttributes().copy().setDim(dim));
/*      */   }
/*      */   
/*      */   public static SEXP Rf_dimnamesgets(SEXP sexp, SEXP dimnames) {
/* 1619 */     return sexp.setAttributes(sexp.getAttributes().copy().setDimNames(dimnames));
/*      */   }
/*      */   
/*      */   public static SEXP Rf_DropDims(SEXP p0) {
/* 1623 */     throw new UnimplementedGnuApiMethod("Rf_DropDims");
/*      */   }
/*      */   
/*      */   public static SEXP Rf_duplicate(SEXP sexp) {
/* 1627 */     return duplicate(sexp, true);
/*      */   }
/*      */   
/*      */   private static SEXP duplicate(SEXP sexp, boolean deep) {
/* 1631 */     if (sexp == Null.INSTANCE) {
/* 1632 */       return sexp;
/*      */     }
/* 1634 */     if (sexp instanceof DoubleVector) {
/* 1635 */       return (SEXP)new DoubleArrayVector((AtomicVector)sexp);
/*      */     }
/* 1637 */     if (sexp instanceof IntVector) {
/* 1638 */       return (SEXP)new IntArrayVector((AtomicVector)sexp);
/*      */     }
/* 1640 */     if (sexp instanceof ComplexVector) {
/* 1641 */       return (SEXP)new ComplexArrayVector((ComplexVector)sexp);
/*      */     }
/* 1643 */     if (sexp instanceof StringVector) {
/* 1644 */       return (SEXP)GnuStringVector.copyOf((StringVector)sexp);
/*      */     }
/* 1646 */     if (sexp instanceof LogicalVector) {
/* 1647 */       return (SEXP)new LogicalArrayVector(((LogicalArrayVector)sexp).toIntArray(), sexp.getAttributes());
/*      */     }
/* 1649 */     if (sexp instanceof RawVector) {
/* 1650 */       return (SEXP)new RawVector(((RawVector)sexp).toByteArrayUnsafe(), sexp.getAttributes());
/*      */     }
/* 1652 */     if (sexp instanceof S4Object) {
/* 1653 */       return (SEXP)new S4Object(duplicate(sexp.getAttributes()));
/*      */     }
/* 1655 */     if (sexp instanceof ListVector) {
/* 1656 */       SEXP[] elements = ((ListVector)sexp).toArrayUnsafe();
/* 1657 */       for (int i = 0; i < elements.length; i++) {
/* 1658 */         elements[i] = deep ? duplicate(elements[i], deep) : elements[i];
/*      */       }
/* 1660 */       return (SEXP)new ListVector(elements, sexp.getAttributes());
/*      */     } 
/* 1662 */     if (sexp instanceof FunctionCall) {
/* 1663 */       return duplicateCall((FunctionCall)sexp, deep);
/*      */     }
/* 1665 */     if (sexp instanceof PairList) {
/* 1666 */       return duplicatePairList((PairList)sexp, deep);
/*      */     }
/* 1668 */     if ((sexp instanceof Symbol | sexp instanceof org.renjin.sexp.PrimitiveFunction | sexp instanceof ExternalPtr | sexp instanceof Environment | sexp instanceof Promise) != 0)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1675 */       return sexp;
/*      */     }
/*      */     
/* 1678 */     throw new UnimplementedGnuApiMethod("Rf_duplicate: " + sexp.getTypeName());
/*      */   }
/*      */   
/*      */   private static AttributeMap duplicate(AttributeMap attributes) {
/* 1682 */     AttributeMap.Builder copy = AttributeMap.builder();
/* 1683 */     for (Symbol symbol : attributes.names()) {
/* 1684 */       copy.set(symbol, Rf_duplicate(attributes.get(symbol)));
/*      */     }
/* 1686 */     return copy.build();
/*      */   }
/*      */   
/*      */   private static SEXP duplicatePairList(PairList pairlist, boolean deep) {
/* 1690 */     PairList.Builder copy = new PairList.Builder();
/* 1691 */     for (PairList.Node node : pairlist.nodes()) {
/* 1692 */       copy.add(node.getRawTag(), deep ? Rf_duplicate(node.getValue()) : node.getValue());
/*      */     }
/* 1694 */     return (SEXP)copy.build();
/*      */   }
/*      */   
/*      */   private static SEXP duplicateCall(FunctionCall call, boolean deep) {
/* 1698 */     FunctionCall.Builder copy = new FunctionCall.Builder();
/* 1699 */     for (PairList.Node node : call.nodes()) {
/* 1700 */       copy.add(node.getRawTag(), deep ? Rf_duplicate(node.getValue()) : node.getValue());
/*      */     }
/* 1702 */     return (SEXP)copy.build();
/*      */   }
/*      */   
/*      */   public static SEXP Rf_shallow_duplicate(SEXP p0) {
/* 1706 */     return duplicate(p0, false);
/*      */   }
/*      */   
/*      */   public static SEXP Rf_lazy_duplicate(SEXP p0) {
/* 1710 */     throw new UnimplementedGnuApiMethod("Rf_lazy_duplicate");
/*      */   }
/*      */   
/*      */   public static SEXP Rf_duplicated(SEXP p0, boolean p1) {
/* 1714 */     LogicalArrayVector.Builder result = new LogicalArrayVector.Builder();
/* 1715 */     if (!(p0.getElementAsSEXP(0) instanceof IntArrayVector)) {
/* 1716 */       throw new UnsupportedOperationException("argument to internal function 'Rf_duplicated' is not of type 'IntArrayVector'");
/*      */     }
/* 1718 */     Set<IntArrayVector> elementsHash = new HashSet<>();
/* 1719 */     for (int i = 0; i < p0.length(); i++) {
/* 1720 */       IntArrayVector element = (IntArrayVector)p0.getElementAsSEXP(i);
/* 1721 */       if (elementsHash.contains(element)) {
/* 1722 */         result.add((SEXP)LogicalVector.TRUE);
/*      */       } else {
/* 1724 */         result.add((SEXP)LogicalVector.FALSE);
/* 1725 */         elementsHash.add(element);
/*      */       } 
/*      */     } 
/* 1728 */     return (SEXP)result.build();
/*      */   }
/*      */   
/*      */   public static boolean R_envHasNoSpecialSymbols(SEXP p0) {
/* 1732 */     throw new UnimplementedGnuApiMethod("R_envHasNoSpecialSymbols");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP Rf_eval(SEXP e, SEXP rho) {
/* 1744 */     return Native.currentContext().evaluate(e, (Environment)rho);
/*      */   }
/*      */   
/*      */   public static SEXP Rf_findFun(SEXP symbol, SEXP rho) {
/* 1748 */     return (SEXP)((Environment)rho).findFunction(Native.currentContext(), (Symbol)symbol);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP Rf_findVar(SEXP symbol, SEXP rho) {
/* 1764 */     return ((Environment)rho).findVariable(Native.currentContext(), (Symbol)symbol);
/*      */   }
/*      */   
/*      */   public static SEXP Rf_findVarInFrame(SEXP rho, SEXP symbol) {
/* 1768 */     return Rf_findVarInFrame3(rho, symbol, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP Rf_findVarInFrame3(SEXP rho, SEXP symbol, boolean doGet) {
/* 1789 */     return ((Environment)rho).getVariable(Native.currentContext(), (Symbol)symbol);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP Rf_getAttrib(SEXP vec, SEXP name) {
/* 1810 */     return vec.getAttribute((Symbol)name);
/*      */   }
/*      */   
/*      */   public static SEXP Rf_GetArrayDimnames(SEXP p0) {
/* 1814 */     throw new UnimplementedGnuApiMethod("Rf_GetArrayDimnames");
/*      */   }
/*      */   
/*      */   public static SEXP Rf_GetColNames(SEXP p0) {
/* 1818 */     throw new UnimplementedGnuApiMethod("Rf_GetColNames");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP Rf_GetOption(SEXP p0, SEXP p1) {
/* 1824 */     throw new UnimplementedGnuApiMethod("Rf_GetOption");
/*      */   }
/*      */   
/*      */   public static SEXP Rf_GetOption1(SEXP optionNameSexp) {
/* 1828 */     Symbol optionName = (Symbol)optionNameSexp;
/*      */     
/* 1830 */     Options options = (Options)Native.currentContext().getSession().getSingleton(Options.class);
/* 1831 */     return options.get(optionName.getPrintName());
/*      */   }
/*      */   
/*      */   public static int Rf_GetOptionDigits() {
/* 1835 */     throw new UnimplementedGnuApiMethod("Rf_GetOptionDigits");
/*      */   }
/*      */   
/*      */   public static int Rf_GetOptionWidth() {
/* 1839 */     throw new UnimplementedGnuApiMethod("Rf_GetOptionWidth");
/*      */   }
/*      */   
/*      */   public static SEXP Rf_GetRowNames(SEXP p0) {
/* 1843 */     throw new UnimplementedGnuApiMethod("Rf_GetRowNames");
/*      */   }
/*      */   public static void Rf_gsetVar(SEXP symbolName, SEXP value, SEXP environment) {
/*      */     Environment environment1;
/* 1847 */     if (environment == Null.INSTANCE) {
/* 1848 */       environment1 = Native.currentContext().getBaseEnvironment();
/*      */     }
/*      */     
/* 1851 */     environment1.setVariable(Native.currentContext(), (Symbol)symbolName, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP Rf_install(BytePtr name) {
/* 1869 */     return (SEXP)Symbol.get(name.nullTerminatedString());
/*      */   }
/*      */   
/*      */   public static SEXP Rf_installChar(SEXP charSexp) {
/* 1873 */     return Rf_install(((GnuCharSexp)charSexp).getValue());
/*      */   }
/*      */   
/*      */   public static SEXP Rf_installDDVAL(int i) {
/* 1877 */     throw new UnimplementedGnuApiMethod("Rf_installDDVAL");
/*      */   }
/*      */   
/*      */   public static SEXP Rf_installS3Signature(BytePtr p0, BytePtr p1) {
/* 1881 */     throw new UnimplementedGnuApiMethod("Rf_installS3Signature");
/*      */   }
/*      */   
/*      */   public static boolean Rf_isFree(SEXP p0) {
/* 1885 */     throw new UnimplementedGnuApiMethod("Rf_isFree");
/*      */   }
/*      */   
/*      */   public static boolean Rf_isOrdered(SEXP p0) {
/* 1889 */     throw new UnimplementedGnuApiMethod("Rf_isOrdered");
/*      */   }
/*      */   
/*      */   public static boolean Rf_isUnordered(SEXP p0) {
/* 1893 */     throw new UnimplementedGnuApiMethod("Rf_isUnordered");
/*      */   }
/*      */   
/*      */   public static boolean Rf_isUnsorted(SEXP p0, boolean p1) {
/* 1897 */     throw new UnimplementedGnuApiMethod("Rf_isUnsorted");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP Rf_xlengthgets(SEXP p0, int p1) {
/* 1903 */     throw new UnimplementedGnuApiMethod("Rf_xlengthgets");
/*      */   }
/*      */   
/*      */   public static SEXP R_lsInternal(SEXP env, boolean allNames) {
/* 1907 */     return (SEXP)Environments.ls((Environment)env, allNames);
/*      */   }
/*      */   
/*      */   public static SEXP R_lsInternal3(SEXP env, boolean allNames, boolean sorted) {
/* 1911 */     StringVector names = Environments.ls((Environment)env, allNames);
/* 1912 */     if (sorted) {
/* 1913 */       return (SEXP)Sort.sort(names, false);
/*      */     }
/* 1915 */     return (SEXP)names;
/*      */   }
/*      */ 
/*      */   
/*      */   public static SEXP Rf_match(SEXP p0, SEXP p1, int p2) {
/* 1920 */     throw new UnimplementedGnuApiMethod("Rf_match");
/*      */   }
/*      */   
/*      */   public static SEXP Rf_matchE(SEXP p0, SEXP p1, int p2, SEXP p3) {
/* 1924 */     throw new UnimplementedGnuApiMethod("Rf_matchE");
/*      */   }
/*      */   
/*      */   public static SEXP Rf_namesgets(SEXP p0, SEXP p1) {
/* 1928 */     throw new UnimplementedGnuApiMethod("Rf_namesgets");
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public static SEXP Rf_mkChar(BytePtr string) {
/* 1933 */     return Rf_mkChar((Ptr)string);
/*      */   }
/*      */   
/*      */   public static SEXP Rf_mkChar(Ptr string) {
/* 1937 */     if (string.isNull()) {
/* 1938 */       return (SEXP)GnuCharSexp.NA_STRING;
/*      */     }
/* 1940 */     return Rf_mkCharLen(string, Stdlib.strlen(string));
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public static SEXP Rf_mkCharLen(BytePtr string, int length) {
/* 1945 */     return Rf_mkCharLen((Ptr)string, length);
/*      */   }
/*      */   
/*      */   public static SEXP Rf_mkCharLen(Ptr string, int length) {
/* 1949 */     if (string.isNull()) {
/* 1950 */       return (SEXP)GnuCharSexp.NA_STRING;
/*      */     }
/*      */     
/* 1953 */     if (length == 0) {
/* 1954 */       return R_BlankString;
/*      */     }
/*      */     
/* 1957 */     BytePtr copy = BytePtr.malloc(length + 1);
/* 1958 */     copy.memcpy(string, length);
/*      */     
/* 1960 */     return (SEXP)new GnuCharSexp(copy.array);
/*      */   }
/*      */   
/*      */   public static boolean Rf_NonNullStringMatch(SEXP p0, SEXP p1) {
/* 1964 */     throw new UnimplementedGnuApiMethod("Rf_NonNullStringMatch");
/*      */   }
/*      */   
/*      */   public static int Rf_ncols(SEXP s) {
/* 1968 */     if (Rf_isVector(s) || Rf_isList(s)) {
/* 1969 */       Vector dim = s.getAttributes().getDim();
/* 1970 */       if (dim.length() >= 2) {
/* 1971 */         return dim.getElementAsInt(1);
/*      */       }
/* 1973 */       return 1;
/*      */     } 
/*      */     
/* 1976 */     if (Rf_isFrame(s)) {
/* 1977 */       return Rf_length(s);
/*      */     }
/*      */     
/* 1980 */     throw new EvalException("object is not a matrix", new Object[0]);
/*      */   }
/*      */ 
/*      */   
/*      */   public static int Rf_nrows(SEXP s) {
/* 1985 */     if (Rf_isVector(s) || Rf_isList(s)) {
/* 1986 */       Vector dim = s.getAttributes().getDim();
/* 1987 */       if (dim == Null.INSTANCE) {
/* 1988 */         return s.length();
/*      */       }
/* 1990 */       return dim.getElementAsInt(0);
/*      */     } 
/*      */     
/* 1993 */     if (Rf_isFrame(s)) {
/* 1994 */       return Rf_nrows(s.getElementAsSEXP(0));
/*      */     }
/*      */     
/* 1997 */     throw new EvalException("object is not a matrix", new Object[0]);
/*      */   }
/*      */ 
/*      */   
/*      */   public static SEXP Rf_nthcdr(SEXP p0, int p1) {
/* 2002 */     if (Rf_isList(p0) || Rf_isLanguage(p0) || Rf_isFrame(p0) || TYPEOF(p0) == 17) {
/* 2003 */       while (p1-- > 0) {
/* 2004 */         if (p0 == R_NilValue) {
/* 2005 */           throw new EvalException(String.format("'nthcdr' list shorter than %d", new Object[] { Integer.valueOf(p1) }), new Object[0]);
/*      */         }
/* 2007 */         p0 = CDR(p0);
/*      */       } 
/* 2009 */       return p0;
/*      */     } 
/* 2011 */     throw new EvalException("'nthcdr' needs a list to CDR down", new Object[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean Rf_pmatch(SEXP p0, SEXP p1, boolean p2) {
/* 2018 */     throw new UnimplementedGnuApiMethod("Rf_pmatch");
/*      */   }
/*      */   
/*      */   public static boolean Rf_psmatch(BytePtr p0, BytePtr p1, boolean p2) {
/* 2022 */     throw new UnimplementedGnuApiMethod("Rf_psmatch");
/*      */   }
/*      */   
/*      */   public static void Rf_PrintValue(SEXP p0) {
/* 2026 */     throw new UnimplementedGnuApiMethod("Rf_PrintValue");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP Rf_setAttrib(@Mutee SEXP vec, SEXP name, SEXP val) {
/*      */     RowNamesVector rowNamesVector;
/*      */     Symbol attributeSymbol;
/* 2051 */     if (name == null) {
/* 2052 */       throw new IllegalArgumentException("attributeName is NULL");
/*      */     }
/* 2054 */     if (name == R_RowNamesSymbol && (
/* 2055 */       RowNamesVector.isOldCompactForm(val) || RowNamesVector.isCompactForm(val))) {
/* 2056 */       rowNamesVector = new RowNamesVector(Math.abs(val.getElementAsSEXP(1).asInt()));
/*      */     }
/*      */ 
/*      */     
/* 2060 */     if (name instanceof StringVector) {
/* 2061 */       attributeSymbol = Symbol.get(((StringVector)name).getElementAsString(0));
/*      */     } else {
/* 2063 */       attributeSymbol = (Symbol)name;
/*      */     } 
/* 2065 */     AbstractSEXP abstractSEXP = (AbstractSEXP)vec;
/* 2066 */     abstractSEXP.unsafeSetAttributes(vec.getAttributes().copy().set(attributeSymbol, (SEXP)rowNamesVector));
/* 2067 */     return vec;
/*      */   }
/*      */ 
/*      */   
/*      */   public static void Rf_setVar(SEXP p0, SEXP p1, SEXP p2) {
/* 2072 */     throw new UnimplementedGnuApiMethod("Rf_setVar");
/*      */   }
/*      */   
/*      */   public static SEXP Rf_stringSuffix(SEXP p0, int p1) {
/* 2076 */     throw new UnimplementedGnuApiMethod("Rf_stringSuffix");
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public static int Rf_str2type(BytePtr p0) {
/* 2081 */     return Rf_str2type((Ptr)p0);
/*      */   }
/*      */   
/*      */   public static int Rf_str2type(Ptr string) {
/* 2085 */     switch (Stdlib.nullTerminatedString(string)) {
/*      */       case "NULL":
/* 2087 */         return 0;
/*      */       case "pairlist":
/* 2089 */         return 2;
/*      */       case "language":
/* 2091 */         return 6;
/*      */       case "list":
/* 2093 */         return 19;
/*      */       case "character":
/* 2095 */         return 16;
/*      */       case "integer":
/* 2097 */         return 13;
/*      */       case "double":
/* 2099 */         return 14;
/*      */       case "raw":
/* 2101 */         return 24;
/*      */       case "logical":
/* 2103 */         return 10;
/*      */       case "environment":
/* 2105 */         return 4;
/*      */       case "promise":
/* 2107 */         return 5;
/*      */       case "symbol":
/* 2109 */         return 1;
/*      */     } 
/* 2111 */     throw new UnimplementedGnuApiMethod("Rf_str2type: " + Stdlib.nullTerminatedString(string));
/*      */   }
/*      */   
/*      */   public static boolean Rf_StringBlank(SEXP p0) {
/* 2115 */     throw new UnimplementedGnuApiMethod("Rf_StringBlank");
/*      */   }
/*      */   
/*      */   public static SEXP Rf_substitute(SEXP p0, SEXP p1) {
/* 2119 */     throw new UnimplementedGnuApiMethod("Rf_substitute");
/*      */   }
/*      */   
/*      */   public static BytePtr Rf_translateChar(SEXP p0) {
/* 2123 */     return ((GnuCharSexp)p0).getValue();
/*      */   }
/*      */   
/*      */   public static BytePtr Rf_translateChar0(SEXP p0) {
/* 2127 */     throw new UnimplementedGnuApiMethod("Rf_translateChar0");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BytePtr Rf_translateCharUTF8(SEXP x) {
/* 2139 */     GnuCharSexp charsexp = (GnuCharSexp)x;
/* 2140 */     return charsexp.getValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BytePtr Rf_type2char(int st) {
/* 2152 */     return BytePtr.nullTerminatedString(SexpType.typeName(st), StandardCharsets.UTF_8);
/*      */   }
/*      */   
/*      */   public static SEXP Rf_type2rstr(int p0) {
/* 2156 */     throw new UnimplementedGnuApiMethod("Rf_type2rstr");
/*      */   }
/*      */   
/*      */   public static SEXP Rf_type2str(int p0) {
/* 2160 */     throw new UnimplementedGnuApiMethod("Rf_type2str");
/*      */   }
/*      */   
/*      */   public static SEXP Rf_type2str_nowarn(int p0) {
/* 2164 */     throw new UnimplementedGnuApiMethod("Rf_type2str_nowarn");
/*      */   }
/*      */ 
/*      */   
/*      */   @Noop
/*      */   public static void Rf_unprotect_ptr(SEXP p0) {}
/*      */ 
/*      */   
/*      */   public static void R_signal_protect_error() {
/* 2173 */     throw new UnimplementedGnuApiMethod("R_signal_protect_error");
/*      */   }
/*      */   
/*      */   public static void R_signal_unprotect_error() {
/* 2177 */     throw new UnimplementedGnuApiMethod("R_signal_unprotect_error");
/*      */   }
/*      */   
/*      */   public static void R_signal_reprotect_error(int i) {
/* 2181 */     throw new UnimplementedGnuApiMethod("R_signal_reprotect_error");
/*      */   }
/*      */   
/*      */   public static SEXP R_tryEval(SEXP p0, SEXP p1, IntPtr p2) {
/* 2185 */     throw new UnimplementedGnuApiMethod("R_tryEval");
/*      */   }
/*      */   
/*      */   public static SEXP R_tryEvalSilent(SEXP p0, SEXP p1, IntPtr p2) {
/* 2189 */     throw new UnimplementedGnuApiMethod("R_tryEvalSilent");
/*      */   }
/*      */   
/*      */   public static BytePtr R_curErrorBuf() {
/* 2193 */     throw new UnimplementedGnuApiMethod("R_curErrorBuf");
/*      */   }
/*      */   
/*      */   public static boolean Rf_isS4(SEXP p0) {
/* 2197 */     throw new UnimplementedGnuApiMethod("Rf_isS4");
/*      */   }
/*      */   
/*      */   public static SEXP Rf_asS4(SEXP p0, boolean p1, int p2) {
/* 2201 */     throw new UnimplementedGnuApiMethod("Rf_asS4");
/*      */   }
/*      */   
/*      */   public static SEXP Rf_S3Class(SEXP p0) {
/* 2205 */     throw new UnimplementedGnuApiMethod("Rf_S3Class");
/*      */   }
/*      */   
/*      */   public static int Rf_isBasicClass(BytePtr p0) {
/* 2209 */     throw new UnimplementedGnuApiMethod("Rf_isBasicClass");
/*      */   }
/*      */   
/*      */   public static boolean R_cycle_detected(SEXP s, SEXP child) {
/* 2213 */     throw new UnimplementedGnuApiMethod("R_cycle_detected");
/*      */   }
/*      */   
/*      */   public static int Rf_getCharCE(SEXP s) {
/* 2217 */     return 1;
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public static SEXP Rf_mkCharCE(BytePtr str, int encoding) {
/* 2222 */     return Rf_mkCharCE((Ptr)str, encoding);
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public static SEXP Rf_mkCharLenCE(BytePtr text, int length, int encoding) {
/* 2227 */     return Rf_mkCharLenCE((Ptr)text, length, encoding);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP Rf_mkCharCE(Ptr str, int encoding) {
/* 2248 */     return Rf_mkCharLenCE(str, Stdlib.strlen(str), encoding);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP Rf_mkCharLenCE(Ptr text, int length, int encoding) {
/* 2273 */     if (text.isNull()) {
/* 2274 */       return (SEXP)GnuCharSexp.NA_STRING;
/*      */     }
/*      */     
/* 2277 */     if (length == 0) {
/* 2278 */       return R_BlankString;
/*      */     }
/*      */     
/* 2281 */     if (encoding != 1) {
/* 2282 */       throw new UnsupportedOperationException("encoding: " + encoding);
/*      */     }
/*      */     
/* 2285 */     BytePtr copy = BytePtr.malloc(length + 1);
/* 2286 */     copy.memcpy(text, length);
/*      */     
/* 2288 */     return (SEXP)new GnuCharSexp(copy.array);
/*      */   }
/*      */   
/*      */   public static Ptr Rf_reEnc(BytePtr x, int ce_in, int ce_out, int subst) {
/* 2292 */     if (ce_in == ce_out)
/* 2293 */       return (Ptr)x; 
/* 2294 */     if (ce_in == -1 && ce_out == 1)
/* 2295 */       return (Ptr)x; 
/* 2296 */     if (ce_in == 0 && ce_out == 1)
/* 2297 */       return (Ptr)x; 
/* 2298 */     if (ce_in == 99 && ce_out == 1) {
/* 2299 */       return (Ptr)x;
/*      */     }
/* 2301 */     throw new UnsupportedOperationException(String.format("Rf_reEnc: from %d to %d", new Object[] { Integer.valueOf(ce_in), Integer.valueOf(ce_out) }));
/*      */   }
/*      */ 
/*      */   
/*      */   public static SEXP R_forceAndCall(SEXP e, int n, SEXP rho) {
/* 2306 */     throw new UnimplementedGnuApiMethod("R_forceAndCall");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP R_MakeExternalPtr(Object p, SEXP tag, SEXP prot) {
/* 2323 */     return (SEXP)new ExternalPtr(p, tag, prot);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object R_ExternalPtrAddr(SEXP s) {
/* 2335 */     return ((ExternalPtr)s).getInstance();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP R_ExternalPtrTag(SEXP s) {
/* 2345 */     return ((ExternalPtr)s).getTag();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP R_ExternalPtrProtected(SEXP s) {
/* 2355 */     return ((ExternalPtr)s).getProtected();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void R_ClearExternalPtr(SEXP s) {
/* 2363 */     ((ExternalPtr)s).unsafeSetAddress(null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void R_SetExternalPtrAddr(SEXP s, Object p) {
/* 2374 */     ((ExternalPtr)s).unsafeSetAddress(p);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void R_SetExternalPtrTag(SEXP s, SEXP tag) {
/* 2384 */     ((ExternalPtr)s).unsafeSetTag(tag);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void R_SetExternalPtrProtected(SEXP s, SEXP p) {
/* 2394 */     ((ExternalPtr)s).unsafeSetProtected(p);
/*      */   }
/*      */   
/*      */   public static void R_RegisterFinalizer(SEXP s, SEXP fun) {
/* 2398 */     throw new UnimplementedGnuApiMethod("R_RegisterFinalizer");
/*      */   }
/*      */   
/*      */   public static void R_RegisterFinalizerEx(SEXP s, SEXP fun, boolean onexit) {
/* 2402 */     Native.currentContext().getSession().registerFinalizer(s, (FinalizationHandler)new FinalizationClosure((Closure)fun), onexit);
/*      */   }
/*      */   
/*      */   public static void R_RegisterCFinalizer(SEXP s, MethodHandle fun) {
/* 2406 */     R_RegisterCFinalizerEx(s, fun, false);
/*      */   }
/*      */   
/*      */   public static void R_RegisterCFinalizerEx(SEXP s, final MethodHandle fun, boolean onexit) {
/* 2410 */     FinalizationHandler handler = new FinalizationHandler()
/*      */       {
/*      */         public void finalizeSexp(Context context, SEXP sexp) {
/*      */           try {
/* 2414 */             fun.invoke(sexp);
/* 2415 */           } catch (Throwable throwable) {
/* 2416 */             throw new RuntimeException(throwable);
/*      */           } 
/*      */         }
/*      */       };
/* 2420 */     Native.currentContext().getSession().registerFinalizer(s, handler, onexit);
/*      */   }
/*      */   
/*      */   public static void R_RunPendingFinalizers() {
/* 2424 */     Native.currentContext().getSession().runFinalizers();
/*      */   }
/*      */   
/*      */   public static SEXP R_MakeWeakRef(SEXP key, SEXP val, SEXP fin, boolean onexit) {
/* 2428 */     throw new UnimplementedGnuApiMethod("R_MakeWeakRef");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP R_WeakRefKey(SEXP w) {
/* 2434 */     throw new UnimplementedGnuApiMethod("R_WeakRefKey");
/*      */   }
/*      */   
/*      */   public static SEXP R_WeakRefValue(SEXP w) {
/* 2438 */     throw new UnimplementedGnuApiMethod("R_WeakRefValue");
/*      */   }
/*      */   
/*      */   public static void R_RunWeakRefFinalizer(SEXP w) {
/* 2442 */     throw new UnimplementedGnuApiMethod("R_RunWeakRefFinalizer");
/*      */   }
/*      */   
/*      */   public static SEXP R_PromiseExpr(SEXP x) {
/* 2446 */     return ((Promise)x).getExpression();
/*      */   }
/*      */   
/*      */   public static SEXP R_ClosureExpr(SEXP p0) {
/* 2450 */     throw new UnimplementedGnuApiMethod("R_ClosureExpr");
/*      */   }
/*      */   
/*      */   public static void R_initialize_bcode() {
/* 2454 */     throw new UnimplementedGnuApiMethod("R_initialize_bcode");
/*      */   }
/*      */   
/*      */   public static SEXP R_bcEncode(SEXP p0) {
/* 2458 */     throw new UnimplementedGnuApiMethod("R_bcEncode");
/*      */   }
/*      */   
/*      */   public static SEXP R_bcDecode(SEXP p0) {
/* 2462 */     throw new UnimplementedGnuApiMethod("R_bcDecode");
/*      */   }
/*      */   
/*      */   public static boolean R_ToplevelExec(MethodHandle fun, Ptr data) throws Throwable {
/* 2466 */     fun.invoke(data);
/* 2467 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void R_RestoreHashCount(SEXP rho) {
/* 2474 */     throw new UnimplementedGnuApiMethod("R_RestoreHashCount");
/*      */   }
/*      */   
/*      */   public static boolean R_IsPackageEnv(SEXP rho) {
/* 2478 */     throw new UnimplementedGnuApiMethod("R_IsPackageEnv");
/*      */   }
/*      */   
/*      */   public static SEXP R_PackageEnvName(SEXP rho) {
/* 2482 */     throw new UnimplementedGnuApiMethod("R_PackageEnvName");
/*      */   }
/*      */   
/*      */   public static SEXP R_FindPackageEnv(SEXP info) {
/* 2486 */     throw new UnimplementedGnuApiMethod("R_FindPackageEnv");
/*      */   }
/*      */   
/*      */   public static boolean R_IsNamespaceEnv(SEXP rho) {
/* 2490 */     throw new UnimplementedGnuApiMethod("R_IsNamespaceEnv");
/*      */   }
/*      */   
/*      */   public static SEXP R_NamespaceEnvSpec(SEXP rho) {
/* 2494 */     throw new UnimplementedGnuApiMethod("R_NamespaceEnvSpec");
/*      */   }
/*      */   
/*      */   public static SEXP R_FindNamespace(SEXP namespaceExp) throws Exception {
/* 2498 */     Context context = Native.currentContext();
/* 2499 */     return R.primitive.getNamespace.doApply(context, context.getEnvironment(), namespaceExp);
/*      */   }
/*      */   
/*      */   public static void R_LockEnvironment(SEXP env, boolean bindings) {
/* 2503 */     throw new UnimplementedGnuApiMethod("R_LockEnvironment");
/*      */   }
/*      */   
/*      */   public static boolean R_EnvironmentIsLocked(SEXP env) {
/* 2507 */     throw new UnimplementedGnuApiMethod("R_EnvironmentIsLocked");
/*      */   }
/*      */   
/*      */   public static void R_LockBinding(SEXP sym, SEXP env) {
/* 2511 */     throw new UnimplementedGnuApiMethod("R_LockBinding");
/*      */   }
/*      */   
/*      */   public static void R_unLockBinding(SEXP sym, SEXP env) {
/* 2515 */     throw new UnimplementedGnuApiMethod("R_unLockBinding");
/*      */   }
/*      */   
/*      */   public static void R_MakeActiveBinding(SEXP sym, SEXP fun, SEXP env) {
/* 2519 */     throw new UnimplementedGnuApiMethod("R_MakeActiveBinding");
/*      */   }
/*      */   
/*      */   public static boolean R_BindingIsLocked(SEXP sym, SEXP env) {
/* 2523 */     throw new UnimplementedGnuApiMethod("R_BindingIsLocked");
/*      */   }
/*      */   
/*      */   public static boolean R_BindingIsActive(SEXP sym, SEXP env) {
/* 2527 */     throw new UnimplementedGnuApiMethod("R_BindingIsActive");
/*      */   }
/*      */   
/*      */   public static boolean R_HasFancyBindings(SEXP rho) {
/* 2531 */     throw new UnimplementedGnuApiMethod("R_HasFancyBindings");
/*      */   }
/*      */   
/*      */   public static void Rf_errorcall(SEXP call, Ptr format, Object... args) {
/* 2535 */     String errorMessage = Stdlib.format(format, args);
/* 2536 */     throw new EvalException(errorMessage, new Object[0]);
/*      */   }
/*      */   
/*      */   public static void Rf_warningcall(SEXP call, Ptr format, Object... args) {
/* 2540 */     Warning.warning(Native.currentContext(), call, false, Stdlib.format(format, new Object[] { new FormatArrayInput(args) }));
/*      */   }
/*      */   
/*      */   public static void Rf_warningcall_immediate(SEXP call, Ptr format, Object... args) {
/* 2544 */     Warning.warning(Native.currentContext(), call, true, Stdlib.format(format, new Object[] { new FormatArrayInput(args) }));
/*      */   }
/*      */   
/*      */   public static void R_XDREncodeDouble(double d, Object buf) {
/* 2548 */     throw new UnimplementedGnuApiMethod("R_XDREncodeDouble");
/*      */   }
/*      */   
/*      */   public static double R_XDRDecodeDouble(Object buf) {
/* 2552 */     throw new UnimplementedGnuApiMethod("R_XDRDecodeDouble");
/*      */   }
/*      */   
/*      */   public static void R_XDREncodeInteger(int i, Object buf) {
/* 2556 */     throw new UnimplementedGnuApiMethod("R_XDREncodeInteger");
/*      */   }
/*      */   
/*      */   public static int R_XDRDecodeInteger(Object buf) {
/* 2560 */     throw new UnimplementedGnuApiMethod("R_XDRDecodeInteger");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP R_do_slot(SEXP obj, SEXP name) {
/* 2576 */     Context context = Native.currentContext();
/* 2577 */     MethodDispatch methodDispatch = (MethodDispatch)context.getSingleton(MethodDispatch.class);
/* 2578 */     return Subsetting.getSlotValue(context, methodDispatch, obj, (Symbol)name);
/*      */   }
/*      */ 
/*      */   
/*      */   public static SEXP R_do_slot_assign(SEXP obj, SEXP name, SEXP value) {
/*      */     Symbol symbol;
/* 2584 */     if (name instanceof StringVector && LENGTH(name) == 1) {
/* 2585 */       symbol = Symbol.get(name.asString());
/* 2586 */     } else if (symbol instanceof GnuCharSexp) {
/* 2587 */       symbol = Symbol.get(((GnuCharSexp)symbol).getValue().nullTerminatedString());
/*      */     } 
/* 2589 */     if (!(symbol instanceof Symbol)) {
/* 2590 */       throw new EvalException("invalid type or length for slot name", new Object[0]);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2600 */     if (symbol.asString().equals(".Data"))
/*      */     {
/*      */ 
/*      */       
/* 2604 */       return Native.currentContext().evaluate((SEXP)FunctionCall.newCall((SEXP)Symbol.get("setDataPart"), new SEXP[] { obj, value
/* 2605 */             }), ((MethodDispatch)Native.currentContext().getSingleton(MethodDispatch.class)).getMethodsNamespace());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2612 */     SEXP slotValue = (value == Null.INSTANCE) ? (SEXP)Symbols.S4_NULL : value;
/* 2613 */     ((AbstractSEXP)obj).unsafeSetAttributes(obj.getAttributes().copy().set(symbol.asString(), slotValue));
/* 2614 */     return obj;
/*      */   }
/*      */ 
/*      */   
/*      */   public static int R_has_slot(SEXP obj, SEXP name) {
/* 2619 */     return Methods.R_has_slot(obj, name);
/*      */   }
/*      */   
/*      */   public static SEXP R_do_MAKE_CLASS(BytePtr what) {
/* 2623 */     if (what == null || what.array == null) {
/* 2624 */       throw new EvalException("C level MAKE_CLASS macro called with NULL string pointer", new Object[0]);
/*      */     }
/* 2626 */     Context context = Native.currentContext();
/*      */     
/* 2628 */     return Methods.getClass(context, (SEXP)StringVector.valueOf(what.nullTerminatedString()), false, (SEXP)Null.INSTANCE);
/*      */   }
/*      */   
/*      */   public static SEXP R_getClassDef(BytePtr what) {
/* 2632 */     if (what == null || what.array == null) {
/* 2633 */       throw new EvalException("R_getClassDef(.) called with NULL string pointer", new Object[0]);
/*      */     }
/*      */     
/* 2636 */     return R_getClassDef_R(StringArrayVector.valueOf(what.nullTerminatedString()));
/*      */   }
/*      */   
/*      */   public static SEXP R_getClassDef_R(StringVector what) {
/* 2640 */     Context context = Native.currentContext();
/* 2641 */     return Methods.getClassDef(context, what, (SEXP)Null.INSTANCE, (SEXP)Null.INSTANCE, true);
/*      */   }
/*      */   
/*      */   public static boolean R_has_methods_attached() {
/* 2645 */     throw new UnimplementedGnuApiMethod("R_has_methods_attached");
/*      */   }
/*      */   
/*      */   public static boolean R_isVirtualClass(SEXP class_def, SEXP env) {
/* 2649 */     throw new UnimplementedGnuApiMethod("R_isVirtualClass");
/*      */   }
/*      */   
/*      */   public static boolean R_extends(SEXP class1, SEXP class2, SEXP env) {
/* 2653 */     throw new UnimplementedGnuApiMethod("R_extends");
/*      */   }
/*      */ 
/*      */   
/*      */   public static SEXP R_do_new_object(SEXP class_def) {
/* 2658 */     if (class_def == null) {
/* 2659 */       throw new EvalException("C level NEW macro called with null class definition pointer", new Object[0]);
/*      */     }
/* 2661 */     SEXP virtual = R_do_slot(class_def, (SEXP)Symbol.get("virtual"));
/* 2662 */     SEXP className = R_do_slot(class_def, (SEXP)Symbol.get("className"));
/*      */     
/* 2664 */     if (virtual.asLogical() != Logical.FALSE) {
/* 2665 */       throw new EvalException("trying to generate an object from a virtual class (\"%s\")", new Object[] { className.asString() });
/*      */     }
/* 2667 */     SEXP value = Rf_duplicate(R_do_slot(class_def, (SEXP)Symbol.get("prototype")));
/* 2668 */     if (value instanceof S4Object || Rf_getAttrib(className, R_PackageSymbol) != R_NilValue) {
/*      */       
/* 2670 */       Rf_setAttrib(value, R_ClassSymbol, className);
/* 2671 */       SET_S4_OBJECT(value);
/*      */     } 
/* 2673 */     return value;
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public static int R_check_class_and_super(SEXP x, ObjectPtr<BytePtr> valid, SEXP rho) {
/* 2678 */     return R_check_class_and_super(x, (Ptr)new PointerPtr((Ptr[])valid.array, valid.offset), rho);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int R_check_class_and_super(SEXP x, Ptr valid, SEXP rho) {
/* 2693 */     SEXP cl = Rf_asChar(Rf_getAttrib(x, R_ClassSymbol));
/* 2694 */     BytePtr class_ = R_CHAR(cl);
/* 2695 */     int ans = 0;
/* 2696 */     for (; Stdlib.strlen(valid.getAlignedPointer(ans)) != 0; ans++) {
/*      */ 
/*      */       
/* 2699 */       if (Stdlib.strcmp((Ptr)class_, valid.getAlignedPointer(ans)) == 0) {
/* 2700 */         return ans;
/*      */       }
/*      */     } 
/*      */     
/* 2704 */     if (IS_S4_OBJECT(x) != 0) {
/*      */ 
/*      */ 
/*      */       
/* 2708 */       Symbol s_contains = Symbol.get("contains");
/* 2709 */       Symbol s_selectSuperCl = Symbol.get(".selectSuperClasses");
/* 2710 */       SEXP classDef = R_getClassDef(class_);
/* 2711 */       SEXP classExts = R_do_slot(classDef, (SEXP)s_contains);
/* 2712 */       SEXP _call = Rf_lang3((SEXP)s_selectSuperCl, classExts, 
/* 2713 */           Rf_ScalarLogical(1));
/* 2714 */       SEXP superCl = Rf_eval(_call, rho);
/* 2715 */       for (int i = 0; i < LENGTH(superCl); i++) {
/* 2716 */         BytePtr s_class = R_CHAR(STRING_ELT(superCl, i));
/* 2717 */         ans = 0;
/* 2718 */         for (; Stdlib.strlen(valid.getAlignedPointer(ans)) != 0; ans++) {
/*      */ 
/*      */           
/* 2721 */           if (Stdlib.strcmp((Ptr)s_class, valid.getAlignedPointer(ans)) == 0) {
/* 2722 */             return ans;
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/* 2727 */     return -1;
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public static int R_check_class_etc(SEXP x, ObjectPtr<BytePtr> valid) {
/* 2732 */     return R_check_class_etc(x, (Ptr)new PointerPtr((Ptr[])valid.array, valid.offset));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int R_check_class_etc(SEXP x, Ptr valid) {
/* 2747 */     SEXP cl = Rf_getAttrib(x, R_ClassSymbol);
/* 2748 */     SEXP rho = R_GlobalEnv();
/*      */     
/* 2750 */     Symbol meth_classEnv = Symbol.get(".classEnv");
/*      */     
/* 2752 */     SEXP pkg = Rf_getAttrib(cl, R_PackageSymbol);
/* 2753 */     if (!Rf_isNull(pkg)) {
/*      */ 
/*      */       
/* 2756 */       SEXP clEnvCall = Rf_lang2((SEXP)meth_classEnv, cl);
/* 2757 */       rho = Rf_eval(clEnvCall, (SEXP)methodsNamespace());
/* 2758 */       if (!Rf_isEnvironment(rho)) {
/* 2759 */         throw new EvalException("could not find correct environment; please report!", new Object[0]);
/*      */       }
/*      */     } 
/* 2762 */     return R_check_class_and_super(x, valid, rho);
/*      */   }
/*      */   
/*      */   private static Environment methodsNamespace() {
/* 2766 */     return ((Namespace)Native.currentContext().getNamespaceRegistry().getNamespaceIfPresent(Symbol.get("methods")).get()).getNamespaceEnvironment();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Noop
/*      */   public static void R_PreserveObject(SEXP p0) {}
/*      */ 
/*      */ 
/*      */   
/*      */   @Noop
/*      */   public static void R_ReleaseObject(SEXP p0) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public static void R_dot_Last() {
/* 2782 */     throw new UnimplementedGnuApiMethod("R_dot_Last");
/*      */   }
/*      */   
/*      */   public static void R_RunExitFinalizers() {
/* 2786 */     throw new UnimplementedGnuApiMethod("R_RunExitFinalizers");
/*      */   }
/*      */   
/*      */   public static int R_system(BytePtr p0) {
/* 2790 */     throw new UnimplementedGnuApiMethod("R_system");
/*      */   }
/*      */   private static final boolean NUM_EQ(int flags) {
/* 2793 */     return ((flags & 0x1) == 0);
/*      */   } private static final boolean SINGLE_NA(int flags) {
/* 2795 */     return ((flags & 0x2) == 0);
/*      */   } private static final boolean ATTR_AS_SET(int flags) {
/* 2797 */     return ((flags & 0x4) == 0);
/*      */   } private static final boolean IGNORE_BYTECODE(int flags) {
/* 2799 */     return ((flags & 0x8) == 0);
/*      */   }
/*      */   public static boolean R_compute_identical(SEXP x, SEXP y, int flags) {
/* 2802 */     return Identical.identical(x, y, 
/* 2803 */         NUM_EQ(flags), 
/* 2804 */         SINGLE_NA(flags), 
/* 2805 */         ATTR_AS_SET(flags), 
/* 2806 */         IGNORE_BYTECODE(flags));
/*      */   }
/*      */   
/*      */   public static void R_orderVector(IntPtr indx, int n, SEXP arglist, boolean nalast, boolean decreasing) {
/* 2810 */     throw new UnimplementedGnuApiMethod("R_orderVector");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Allocator
/*      */   public static SEXP Rf_allocVector(int stype, int length) {
/*      */     SEXP[] elements;
/*      */     GnuCharSexp[] strings;
/* 2828 */     switch (stype) {
/*      */       case 13:
/* 2830 */         return (SEXP)new IntArrayVector(new int[length]);
/*      */       case 14:
/* 2832 */         return (SEXP)new DoubleArrayVector(new double[length]);
/*      */       case 10:
/* 2834 */         return (SEXP)new LogicalArrayVector(new int[length]);
/*      */       case 19:
/* 2836 */         elements = new SEXP[length];
/* 2837 */         Arrays.fill((Object[])elements, Null.INSTANCE);
/* 2838 */         return (SEXP)new ListVector(elements);
/*      */       case 16:
/* 2840 */         strings = new GnuCharSexp[length];
/* 2841 */         Arrays.fill((Object[])strings, GnuCharSexp.NA_STRING);
/* 2842 */         return (SEXP)new GnuStringVector(strings);
/*      */       
/*      */       case 2:
/* 2845 */         return (SEXP)new ListVector(elements(length));
/*      */       
/*      */       case 20:
/* 2848 */         return (SEXP)new ExpressionVector(elements(length));
/*      */       
/*      */       case 24:
/* 2851 */         return (SEXP)new RawVector(new byte[length]);
/*      */     } 
/* 2853 */     throw new UnimplementedGnuApiMethod("Rf_allocVector: type = " + stype);
/*      */   }
/*      */   
/*      */   private static SEXP[] elements(int length) {
/* 2857 */     SEXP[] array = new SEXP[length];
/* 2858 */     Arrays.fill((Object[])array, Null.INSTANCE);
/* 2859 */     return array;
/*      */   }
/*      */   
/*      */   public static boolean Rf_conformable(SEXP p0, SEXP p1) {
/* 2863 */     throw new UnimplementedGnuApiMethod("Rf_conformable");
/*      */   }
/*      */   
/*      */   public static SEXP Rf_elt(SEXP vector, int index) {
/* 2867 */     return vector.getElementAsSEXP(index);
/*      */   }
/*      */   
/*      */   public static boolean Rf_inherits(SEXP p0, BytePtr p1) {
/* 2871 */     return p0.inherits(p1.nullTerminatedString());
/*      */   }
/*      */   
/*      */   public static boolean Rf_isArray(SEXP p0) {
/* 2875 */     return Types.isArray(p0);
/*      */   }
/*      */   
/*      */   public static boolean Rf_isFactor(SEXP p0) {
/* 2879 */     return Types.isFactor(p0);
/*      */   }
/*      */   
/*      */   public static boolean Rf_isFrame(SEXP s) {
/* 2883 */     return s.inherits("data.frame");
/*      */   }
/*      */   
/*      */   public static boolean Rf_isFunction(SEXP sexp) {
/* 2887 */     return sexp instanceof org.renjin.sexp.Function;
/*      */   }
/*      */   
/*      */   public static boolean Rf_isInteger(SEXP p0) {
/* 2891 */     return p0 instanceof IntVector;
/*      */   }
/*      */   
/*      */   public static boolean Rf_isLanguage(SEXP p0) {
/* 2895 */     return p0 instanceof FunctionCall;
/*      */   }
/*      */   
/*      */   public static boolean Rf_isList(SEXP s) {
/* 2899 */     return (s == Null.INSTANCE || s instanceof PairList.Node);
/*      */   }
/*      */   
/*      */   public static boolean Rf_isMatrix(SEXP p0) {
/* 2903 */     return Types.isMatrix(p0);
/*      */   }
/*      */   
/*      */   public static boolean Rf_isNewList(SEXP p0) {
/* 2907 */     return p0 instanceof ListVector;
/*      */   }
/*      */   
/*      */   public static boolean Rf_isNumber(SEXP p0) {
/* 2911 */     if (p0 instanceof IntVector) {
/* 2912 */       return !p0.inherits("factor");
/*      */     }
/* 2914 */     return (p0 instanceof LogicalVector || p0 instanceof DoubleVector || p0 instanceof ComplexVector);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean Rf_isNumeric(SEXP p0) {
/* 2921 */     return Types.isNumeric(p0);
/*      */   }
/*      */   
/*      */   public static boolean Rf_isPairList(SEXP p0) {
/* 2925 */     return Types.isPairList(p0);
/*      */   }
/*      */   
/*      */   public static boolean Rf_isPrimitive(SEXP p0) {
/* 2929 */     return p0 instanceof org.renjin.sexp.PrimitiveFunction;
/*      */   }
/*      */   
/*      */   public static boolean Rf_isTs(SEXP p0) {
/* 2933 */     throw new UnimplementedGnuApiMethod("Rf_isTs");
/*      */   }
/*      */   
/*      */   public static boolean Rf_isUserBinop(SEXP p0) {
/* 2937 */     if (TYPEOF(p0) == 1) {
/* 2938 */       BytePtr str = R_CHAR(PRINTNAME(p0));
/* 2939 */       int strlen = str.nullTerminatedStringLength();
/* 2940 */       return (strlen >= 2 && str.getChar(0) == '%' && str.getChar(strlen - 1) == '%');
/*      */     } 
/* 2942 */     return false;
/*      */   }
/*      */   
/*      */   public static boolean Rf_isValidString(SEXP p0) {
/* 2946 */     return (TYPEOF(p0) == 16 && LENGTH(p0) > 0 && TYPEOF(STRING_ELT(p0, 0)) != 0);
/*      */   }
/*      */   
/*      */   public static boolean Rf_isValidStringF(SEXP p0) {
/* 2950 */     return (Rf_isValidString(p0) && R_CHAR(STRING_ELT(p0, 0)).getChar(0) != '\000');
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean Rf_isVector(SEXP s) {
/* 2963 */     return s instanceof Vector;
/*      */   }
/*      */   
/*      */   public static boolean Rf_isVectorAtomic(SEXP s) {
/* 2967 */     return s instanceof AtomicVector;
/*      */   }
/*      */   
/*      */   public static boolean Rf_isVectorList(SEXP s) {
/* 2971 */     return s instanceof ListVector;
/*      */   }
/*      */   
/*      */   public static boolean Rf_isVectorizable(SEXP p0) {
/* 2975 */     throw new UnimplementedGnuApiMethod("Rf_isVectorizable");
/*      */   }
/*      */   
/*      */   public static SEXP Rf_lang1(SEXP p0) {
/* 2979 */     return (SEXP)FunctionCall.newCall(p0, new SEXP[0]);
/*      */   }
/*      */   
/*      */   public static SEXP Rf_lang2(SEXP p0, SEXP p1) {
/* 2983 */     return (SEXP)FunctionCall.newCall(p0, new SEXP[] { p1 });
/*      */   }
/*      */   
/*      */   public static SEXP Rf_lang3(SEXP p0, SEXP p1, SEXP p2) {
/* 2987 */     return (SEXP)FunctionCall.newCall(p0, new SEXP[] { p1, p2 });
/*      */   }
/*      */   
/*      */   public static SEXP Rf_lang4(SEXP p0, SEXP p1, SEXP p2, SEXP p3) {
/* 2991 */     return (SEXP)FunctionCall.newCall(p0, new SEXP[] { p1, p2, p3 });
/*      */   }
/*      */   
/*      */   public static SEXP Rf_lang5(SEXP p0, SEXP p1, SEXP p2, SEXP p3, SEXP p4) {
/* 2995 */     return (SEXP)FunctionCall.newCall(p0, new SEXP[] { p1, p2, p3, p4 });
/*      */   }
/*      */   
/*      */   public static SEXP Rf_lang6(SEXP p0, SEXP p1, SEXP p2, SEXP p3, SEXP p4, SEXP p5) {
/* 2999 */     return (SEXP)FunctionCall.newCall(p0, new SEXP[] { p1, p2, p3, p4, p5 });
/*      */   }
/*      */   public static SEXP Rf_lastElt(SEXP list) {
/*      */     SEXP sEXP;
/* 3003 */     Null null = Null.INSTANCE;
/* 3004 */     while (list != Null.INSTANCE) {
/* 3005 */       sEXP = list;
/* 3006 */       list = CDR(list);
/*      */     } 
/* 3008 */     return sEXP;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP Rf_lcons(SEXP cr, SEXP tl) {
/* 3024 */     return (SEXP)new FunctionCall(cr, (PairList)tl);
/*      */   }
/*      */   
/*      */   public static int Rf_length(SEXP sexp) {
/* 3028 */     return sexp.length();
/*      */   }
/*      */   
/*      */   public static SEXP Rf_lengthgets(SEXP sexp, int length) {
/* 3032 */     return (SEXP)Vectors.setLength((Vector)sexp, length);
/*      */   }
/*      */   
/*      */   public static SEXP Rf_list1(SEXP p0) {
/* 3036 */     return (SEXP)new PairList.Node(p0, (PairList)Null.INSTANCE);
/*      */   }
/*      */   
/*      */   public static SEXP Rf_list2(SEXP p0, SEXP p1) {
/* 3040 */     return (SEXP)new PairList.Node(p0, (PairList)new PairList.Node(p1, (PairList)Null.INSTANCE));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP Rf_list3(SEXP p0, SEXP p1, SEXP p2) {
/* 3046 */     return (SEXP)new PairList.Node(p0, (PairList)new PairList.Node(p1, (PairList)new PairList.Node(p2, (PairList)Null.INSTANCE)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP Rf_list4(SEXP p0, SEXP p1, SEXP p2, SEXP p3) {
/* 3053 */     return (SEXP)new PairList.Node(p0, (PairList)new PairList.Node(p1, (PairList)new PairList.Node(p2, (PairList)new PairList.Node(p3, (PairList)Null.INSTANCE))));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP Rf_list5(SEXP p0, SEXP p1, SEXP p2, SEXP p3, SEXP p4) {
/* 3061 */     return (SEXP)new PairList.Node(p0, (PairList)new PairList.Node(p1, (PairList)new PairList.Node(p2, (PairList)new PairList.Node(p3, (PairList)new PairList.Node(p4, (PairList)Null.INSTANCE)))));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP Rf_listAppend(SEXP s, SEXP t) {
/* 3071 */     if (s == R_NilValue) {
/* 3072 */       return t;
/*      */     }
/* 3074 */     SEXP r = s;
/* 3075 */     while (CDR(r) != R_NilValue) {
/* 3076 */       r = CDR(r);
/*      */     }
/* 3078 */     SETCDR(r, t);
/* 3079 */     return s;
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public static SEXP Rf_mkNamed(int sexpType, ObjectPtr<BytePtr> names) {
/* 3084 */     return Rf_mkNamed(sexpType, (Ptr)new PointerPtr((Ptr[])names.array, names.offset));
/*      */   }
/*      */   
/*      */   public static SEXP Rf_mkNamed(int sexpType, Ptr names) {
/* 3088 */     if (sexpType == 19) {
/* 3089 */       ListVector.NamedBuilder list = new ListVector.NamedBuilder();
/* 3090 */       int i = 0;
/*      */       while (true) {
/* 3092 */         String name = Stdlib.nullTerminatedString(names.getAlignedPointer(i));
/* 3093 */         if (name.isEmpty()) {
/*      */           break;
/*      */         }
/* 3096 */         list.add(name, (SEXP)Null.INSTANCE);
/* 3097 */         i++;
/*      */       } 
/* 3099 */       return (SEXP)list.build();
/*      */     } 
/* 3101 */     throw new UnsupportedOperationException("mkNamed: type = " + sexpType);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static SEXP Rf_mkString(BytePtr string) {
/* 3107 */     return Rf_mkString((Ptr)string);
/*      */   }
/*      */   
/*      */   public static SEXP Rf_mkString(Ptr string) {
/* 3111 */     return (SEXP)new StringArrayVector(new String[] { Stdlib.nullTerminatedString(string) });
/*      */   }
/*      */   
/*      */   public static int Rf_nlevels(SEXP p0) {
/* 3115 */     if (!Types.isFactor(p0)) {
/* 3116 */       return 0;
/*      */     }
/* 3118 */     return LENGTH(p0.getAttribute(Symbol.get("levels")));
/*      */   }
/*      */   
/*      */   public static int Rf_stringPositionTr(SEXP p0, BytePtr p1) {
/* 3122 */     throw new UnimplementedGnuApiMethod("Rf_stringPositionTr");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP Rf_ScalarInteger(int p0) {
/* 3128 */     return (SEXP)new IntArrayVector(new int[] { p0 });
/*      */   }
/*      */   
/*      */   public static SEXP Rf_ScalarLogical(int p0) {
/* 3132 */     if (p0 == LogicalVector.NA)
/* 3133 */       return (SEXP)LogicalVector.NA_VECTOR; 
/* 3134 */     if (p0 == 0) {
/* 3135 */       return (SEXP)LogicalVector.FALSE;
/*      */     }
/* 3137 */     return (SEXP)LogicalVector.TRUE;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP Rf_ScalarReal(double p0) {
/* 3144 */     return (SEXP)new DoubleArrayVector(new double[] { p0 });
/*      */   }
/*      */   
/*      */   public static SEXP Rf_ScalarString(SEXP p0) {
/* 3148 */     return (SEXP)new GnuStringVector(new GnuCharSexp[] { (GnuCharSexp)p0 });
/*      */   }
/*      */   
/*      */   public static int Rf_xlength(SEXP p0) {
/* 3152 */     return p0.length();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP Rf_protect(SEXP node) {
/* 3165 */     return node;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Noop
/*      */   public static void Rf_unprotect(int count) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static void R_ProtectWithIndex(SEXP node, IntPtr iptr) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Noop
/*      */   public static void R_ProtectWithIndex(SEXP node, Ptr iptr) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Noop
/*      */   public static void R_Reprotect(SEXP node, int index) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP R_FixupRHS(SEXP x, SEXP y) {
/* 3237 */     throw new UnimplementedGnuApiMethod("R_FixupRHS");
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-gnur-runtime-0.9.2724.jar!/org/renjin/gnur/api/Rinternals.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */