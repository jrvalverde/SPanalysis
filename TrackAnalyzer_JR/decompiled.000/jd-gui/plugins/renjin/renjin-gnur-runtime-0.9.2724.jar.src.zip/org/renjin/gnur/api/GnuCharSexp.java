/*    */ package org.renjin.gnur.api;
/*    */ 
/*    */ import org.renjin.gcc.runtime.BytePtr;
/*    */ import org.renjin.gcc.runtime.Ptr;
/*    */ import org.renjin.gcc.runtime.Stdlib;
/*    */ import org.renjin.repackaged.guava.base.Charsets;
/*    */ import org.renjin.sexp.AbstractSEXP;
/*    */ import org.renjin.sexp.SexpVisitor;
/*    */ import org.renjin.sexp.StringVector;
/*    */ import org.renjin.sexp.Symbol;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GnuCharSexp
/*    */   extends AbstractSEXP
/*    */ {
/* 35 */   public static final GnuCharSexp NA_STRING = new GnuCharSexp(new byte[] { 78, 65, 0 });
/* 36 */   public static final GnuCharSexp BLANK_STRING = new GnuCharSexp(new byte[] { 0 });
/*    */   
/*    */   private byte[] value;
/*    */   
/*    */   public GnuCharSexp(byte[] value) {
/* 41 */     this.value = value;
/*    */   }
/*    */   
/*    */   public GnuCharSexp(Symbol symbol) {
/* 45 */     this(symbol.getPrintName().getBytes(Charsets.UTF_8));
/*    */   }
/*    */ 
/*    */   
/*    */   public static GnuCharSexp valueOf(String value) {
/* 50 */     if (StringVector.isNA(value))
/* 51 */       return NA_STRING; 
/* 52 */     if (value.isEmpty()) {
/* 53 */       return BLANK_STRING;
/*    */     }
/* 55 */     return new GnuCharSexp((BytePtr.nullTerminatedString(value, Charsets.UTF_8)).array);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int length() {
/* 61 */     return Stdlib.strlen((Ptr)new BytePtr(this.value));
/*    */   }
/*    */ 
/*    */   
/*    */   public String getTypeName() {
/* 66 */     return "char";
/*    */   }
/*    */ 
/*    */   
/*    */   public void accept(SexpVisitor visitor) {}
/*    */ 
/*    */   
/*    */   public BytePtr getValue() {
/* 74 */     return new BytePtr(this.value, 0);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-gnur-runtime-0.9.2724.jar!/org/renjin/gnur/api/GnuCharSexp.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */