/*    */ package org.renjin.gnur.api;
/*    */ 
/*    */ import org.renjin.eval.EvalException;
/*    */ import org.renjin.gcc.runtime.BytePtr;
/*    */ import org.renjin.gcc.runtime.Ptr;
/*    */ import org.renjin.gcc.runtime.Stdlib;
/*    */ import org.renjin.primitives.Native;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Error
/*    */ {
/*    */   @Deprecated
/*    */   public static void Rf_warning(BytePtr text) {
/* 40 */     Rf_warning(text, new Object[0]);
/*    */   }
/*    */   
/*    */   public static void Rf_warning(BytePtr text, Object... formatArgs) {
/* 44 */     Native.currentContext().warn(Stdlib.format((Ptr)text, formatArgs));
/*    */   }
/*    */   
/*    */   public static void Rf_error(BytePtr text, Object... formatArguments) {
/* 48 */     BytePtr string = new BytePtr(new byte[1024]);
/* 49 */     Stdlib.sprintf(string, text, formatArguments);
/*    */     
/* 51 */     throw new EvalException(string.nullTerminatedString(), new Object[0]);
/*    */   }
/*    */   
/*    */   public static void UNIMPLEMENTED(BytePtr p0) {
/* 55 */     throw new UnimplementedGnuApiMethod("UNIMPLEMENTED");
/*    */   }
/*    */   
/*    */   public static void WrongArgCount(BytePtr p0) {
/* 59 */     throw new UnimplementedGnuApiMethod("WrongArgCount");
/*    */   }
/*    */   
/*    */   public static void R_ShowMessage(BytePtr s) {
/* 63 */     throw new UnimplementedGnuApiMethod("R_ShowMessage");
/*    */   }
/*    */   
/*    */   public static void rwarn_(BytePtr message, int messageLen) {
/* 67 */     Native.currentContext().warn(message.toString(messageLen));
/*    */   }
/*    */   
/*    */   public static void rexit_(BytePtr message, int messageLen) {
/* 71 */     throw new EvalException(message.toString(messageLen), new Object[0]);
/*    */   }
/*    */   
/*    */   public static void rchkuser_() {
/* 75 */     Utils.R_CheckUserInterrupt();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-gnur-runtime-0.9.2724.jar!/org/renjin/gnur/api/Error.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */