/*    */ package org.renjin.gnur.api;
/*    */ 
/*    */ import java.lang.invoke.MethodHandle;
/*    */ import org.renjin.gcc.runtime.DoublePtr;
/*    */ import org.renjin.gcc.runtime.IntPtr;
/*    */ import org.renjin.nmath.rnorm;
/*    */ import org.renjin.primitives.Native;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Random
/*    */ {
/*    */   public static void GetRNGstate() {}
/*    */   
/*    */   public static void PutRNGstate() {}
/*    */   
/*    */   public static double unif_rand() {
/* 45 */     return Native.currentContext().getSession().getRNG().unif_rand();
/*    */   }
/*    */   
/*    */   public static double norm_rand() {
/* 49 */     MethodHandle runif = Native.currentContext().getSession().getRngMethod();
/* 50 */     return rnorm.rnorm(runif, 0.0D, 1.0D);
/*    */   }
/*    */   
/*    */   public static double exp_rand() {
/* 54 */     throw new UnimplementedGnuApiMethod("exp_rand");
/*    */   }
/*    */   
/*    */   public static DoublePtr user_unif_rand() {
/* 58 */     throw new UnimplementedGnuApiMethod("user_unif_rand");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static IntPtr user_unif_nseed() {
/* 64 */     throw new UnimplementedGnuApiMethod("user_unif_nseed");
/*    */   }
/*    */   
/*    */   public static IntPtr user_unif_seedloc() {
/* 68 */     throw new UnimplementedGnuApiMethod("user_unif_seedloc");
/*    */   }
/*    */   
/*    */   public static DoublePtr user_norm_rand() {
/* 72 */     throw new UnimplementedGnuApiMethod("user_norm_rand");
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-gnur-runtime-0.9.2724.jar!/org/renjin/gnur/api/Random.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */