/*    */ package org.renjin.gnur.api;
/*    */ 
/*    */ import org.renjin.gcc.runtime.LongPtr;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class S
/*    */ {
/*    */   public static void seed_in(LongPtr p0) {
/* 32 */     throw new UnimplementedGnuApiMethod("seed_in");
/*    */   }
/*    */   
/*    */   public static void seed_out(LongPtr p0) {
/* 36 */     throw new UnimplementedGnuApiMethod("seed_out");
/*    */   }
/*    */   
/*    */   public static double unif_rand() {
/* 40 */     return Random.unif_rand();
/*    */   }
/*    */   
/*    */   public static double norm_rand() {
/* 44 */     return Random.norm_rand();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-gnur-runtime-0.9.2724.jar!/org/renjin/gnur/api/S.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */