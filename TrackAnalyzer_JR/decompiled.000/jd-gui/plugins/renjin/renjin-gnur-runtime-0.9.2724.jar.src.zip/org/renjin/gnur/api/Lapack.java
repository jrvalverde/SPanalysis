/*      */ package org.renjin.gnur.api;
/*      */ 
/*      */ import org.renjin.gcc.runtime.BytePtr;
/*      */ import org.renjin.gcc.runtime.DoublePtr;
/*      */ import org.renjin.gcc.runtime.IntPtr;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Deprecated
/*      */ public final class Lapack
/*      */ {
/*      */   public static void ilaver_(IntPtr major, IntPtr minor, IntPtr patch) {
/*   34 */     throw new UnimplementedGnuApiMethod("ilaver_");
/*      */   }
/*      */   
/*      */   public static void dbdsqr_(BytePtr uplo, IntPtr n, IntPtr ncvt, IntPtr nru, IntPtr ncc, DoublePtr d, DoublePtr e, DoublePtr vt, IntPtr ldvt, DoublePtr u, IntPtr ldu, DoublePtr c, IntPtr ldc, DoublePtr work, IntPtr info) {
/*   38 */     throw new UnimplementedGnuApiMethod("dbdsqr_");
/*      */   }
/*      */   
/*      */   public static void ddisna_(BytePtr job, IntPtr m, IntPtr n, DoublePtr d, DoublePtr sep, IntPtr info) {
/*   42 */     throw new UnimplementedGnuApiMethod("ddisna_");
/*      */   }
/*      */   
/*      */   public static void dgbbrd_(BytePtr vect, IntPtr m, IntPtr n, IntPtr ncc, IntPtr kl, IntPtr ku, DoublePtr ab, IntPtr ldab, DoublePtr d, DoublePtr e, DoublePtr q, IntPtr ldq, DoublePtr pt, IntPtr ldpt, DoublePtr c, IntPtr ldc, DoublePtr work, IntPtr info) {
/*   46 */     throw new UnimplementedGnuApiMethod("dgbbrd_");
/*      */   }
/*      */   
/*      */   public static void dgbcon_(BytePtr norm, IntPtr n, IntPtr kl, IntPtr ku, DoublePtr ab, IntPtr ldab, IntPtr ipiv, DoublePtr anorm, DoublePtr rcond, DoublePtr work, IntPtr iwork, IntPtr info) {
/*   50 */     throw new UnimplementedGnuApiMethod("dgbcon_");
/*      */   }
/*      */   
/*      */   public static void dgbequ_(IntPtr m, IntPtr n, IntPtr kl, IntPtr ku, DoublePtr ab, IntPtr ldab, DoublePtr r, DoublePtr c, DoublePtr rowcnd, DoublePtr colcnd, DoublePtr amax, IntPtr info) {
/*   54 */     throw new UnimplementedGnuApiMethod("dgbequ_");
/*      */   }
/*      */   
/*      */   public static void dgbrfs_(BytePtr trans, IntPtr n, IntPtr kl, IntPtr ku, IntPtr nrhs, DoublePtr ab, IntPtr ldab, DoublePtr afb, IntPtr ldafb, IntPtr ipiv, DoublePtr b, IntPtr ldb, DoublePtr x, IntPtr ldx, DoublePtr ferr, DoublePtr berr, DoublePtr work, IntPtr iwork, IntPtr info) {
/*   58 */     throw new UnimplementedGnuApiMethod("dgbrfs_");
/*      */   }
/*      */   
/*      */   public static void dgbsv_(IntPtr n, IntPtr kl, IntPtr ku, IntPtr nrhs, DoublePtr ab, IntPtr ldab, IntPtr ipiv, DoublePtr b, IntPtr ldb, IntPtr info) {
/*   62 */     throw new UnimplementedGnuApiMethod("dgbsv_");
/*      */   }
/*      */   
/*      */   public static void dgbsvx_(IntPtr fact, BytePtr trans, IntPtr n, IntPtr kl, IntPtr ku, IntPtr nrhs, DoublePtr ab, IntPtr ldab, DoublePtr afb, IntPtr ldafb, IntPtr ipiv, BytePtr equed, DoublePtr r, DoublePtr c, DoublePtr b, IntPtr ldb, DoublePtr x, IntPtr ldx, DoublePtr rcond, DoublePtr ferr, DoublePtr berr, DoublePtr work, IntPtr iwork, IntPtr info) {
/*   66 */     throw new UnimplementedGnuApiMethod("dgbsvx_");
/*      */   }
/*      */   
/*      */   public static void dgbtf2_(IntPtr m, IntPtr n, IntPtr kl, IntPtr ku, DoublePtr ab, IntPtr ldab, IntPtr ipiv, IntPtr info) {
/*   70 */     throw new UnimplementedGnuApiMethod("dgbtf2_");
/*      */   }
/*      */   
/*      */   public static void dgbtrf_(IntPtr m, IntPtr n, IntPtr kl, IntPtr ku, DoublePtr ab, IntPtr ldab, IntPtr ipiv, IntPtr info) {
/*   74 */     throw new UnimplementedGnuApiMethod("dgbtrf_");
/*      */   }
/*      */   
/*      */   public static void dgbtrs_(BytePtr trans, IntPtr n, IntPtr kl, IntPtr ku, IntPtr nrhs, DoublePtr ab, IntPtr ldab, IntPtr ipiv, DoublePtr b, IntPtr ldb, IntPtr info) {
/*   78 */     throw new UnimplementedGnuApiMethod("dgbtrs_");
/*      */   }
/*      */   
/*      */   public static void dgebak_(BytePtr job, BytePtr side, IntPtr n, IntPtr ilo, IntPtr ihi, DoublePtr scale, IntPtr m, DoublePtr v, IntPtr ldv, IntPtr info) {
/*   82 */     throw new UnimplementedGnuApiMethod("dgebak_");
/*      */   }
/*      */   
/*      */   public static void dgebal_(BytePtr job, IntPtr n, DoublePtr a, IntPtr lda, IntPtr ilo, IntPtr ihi, DoublePtr scale, IntPtr info) {
/*   86 */     throw new UnimplementedGnuApiMethod("dgebal_");
/*      */   }
/*      */   
/*      */   public static void dgebd2_(IntPtr m, IntPtr n, DoublePtr a, IntPtr lda, DoublePtr d, DoublePtr e, DoublePtr tauq, DoublePtr taup, DoublePtr work, IntPtr info) {
/*   90 */     throw new UnimplementedGnuApiMethod("dgebd2_");
/*      */   }
/*      */   
/*      */   public static void dgebrd_(IntPtr m, IntPtr n, DoublePtr a, IntPtr lda, DoublePtr d, DoublePtr e, DoublePtr tauq, DoublePtr taup, DoublePtr work, IntPtr lwork, IntPtr info) {
/*   94 */     throw new UnimplementedGnuApiMethod("dgebrd_");
/*      */   }
/*      */   
/*      */   public static void dgecon_(BytePtr norm, IntPtr n, DoublePtr a, IntPtr lda, DoublePtr anorm, DoublePtr rcond, DoublePtr work, IntPtr iwork, IntPtr info) {
/*   98 */     throw new UnimplementedGnuApiMethod("dgecon_");
/*      */   }
/*      */   
/*      */   public static void dgeequ_(IntPtr m, IntPtr n, DoublePtr a, IntPtr lda, DoublePtr r, DoublePtr c, DoublePtr rowcnd, DoublePtr colcnd, DoublePtr amax, IntPtr info) {
/*  102 */     throw new UnimplementedGnuApiMethod("dgeequ_");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void dgeev_(BytePtr jobvl, BytePtr jobvr, IntPtr n, DoublePtr a, IntPtr lda, DoublePtr wr, DoublePtr wi, DoublePtr vl, IntPtr ldvl, DoublePtr vr, IntPtr ldvr, DoublePtr work, IntPtr lwork, IntPtr info) {
/*  110 */     throw new UnimplementedGnuApiMethod("dgeev_");
/*      */   }
/*      */   
/*      */   public static void dgeevx_(BytePtr balanc, BytePtr jobvl, BytePtr jobvr, BytePtr sense, IntPtr n, DoublePtr a, IntPtr lda, DoublePtr wr, DoublePtr wi, DoublePtr vl, IntPtr ldvl, DoublePtr vr, IntPtr ldvr, IntPtr ilo, IntPtr ihi, DoublePtr scale, DoublePtr abnrm, DoublePtr rconde, DoublePtr rcondv, DoublePtr work, IntPtr lwork, IntPtr iwork, IntPtr info) {
/*  114 */     throw new UnimplementedGnuApiMethod("dgeevx_");
/*      */   }
/*      */   
/*      */   public static void dgegv_(BytePtr jobvl, BytePtr jobvr, IntPtr n, DoublePtr a, IntPtr lda, DoublePtr b, IntPtr ldb, DoublePtr alphar, DoublePtr alphai, DoublePtr beta, DoublePtr vl, IntPtr ldvl, DoublePtr vr, IntPtr ldvr, DoublePtr work, IntPtr lwork, IntPtr info) {
/*  118 */     throw new UnimplementedGnuApiMethod("dgegv_");
/*      */   }
/*      */   
/*      */   public static void dgehd2_(IntPtr n, IntPtr ilo, IntPtr ihi, DoublePtr a, IntPtr lda, DoublePtr tau, DoublePtr work, IntPtr info) {
/*  122 */     throw new UnimplementedGnuApiMethod("dgehd2_");
/*      */   }
/*      */   
/*      */   public static void dgehrd_(IntPtr n, IntPtr ilo, IntPtr ihi, DoublePtr a, IntPtr lda, DoublePtr tau, DoublePtr work, IntPtr lwork, IntPtr info) {
/*  126 */     throw new UnimplementedGnuApiMethod("dgehrd_");
/*      */   }
/*      */   
/*      */   public static void dgelq2_(IntPtr m, IntPtr n, DoublePtr a, IntPtr lda, DoublePtr tau, DoublePtr work, IntPtr info) {
/*  130 */     throw new UnimplementedGnuApiMethod("dgelq2_");
/*      */   }
/*      */   
/*      */   public static void dgelqf_(IntPtr m, IntPtr n, DoublePtr a, IntPtr lda, DoublePtr tau, DoublePtr work, IntPtr lwork, IntPtr info) {
/*  134 */     throw new UnimplementedGnuApiMethod("dgelqf_");
/*      */   }
/*      */   
/*      */   public static void dgels_(BytePtr trans, IntPtr m, IntPtr n, IntPtr nrhs, DoublePtr a, IntPtr lda, DoublePtr b, IntPtr ldb, DoublePtr work, IntPtr lwork, IntPtr info) {
/*  138 */     throw new UnimplementedGnuApiMethod("dgels_");
/*      */   }
/*      */   
/*      */   public static void dgelss_(IntPtr m, IntPtr n, IntPtr nrhs, DoublePtr a, IntPtr lda, DoublePtr b, IntPtr ldb, DoublePtr s, DoublePtr rcond, IntPtr rank, DoublePtr work, IntPtr lwork, IntPtr info) {
/*  142 */     throw new UnimplementedGnuApiMethod("dgelss_");
/*      */   }
/*      */   
/*      */   public static void dgelsy_(IntPtr m, IntPtr n, IntPtr nrhs, DoublePtr a, IntPtr lda, DoublePtr b, IntPtr ldb, IntPtr jpvt, DoublePtr rcond, IntPtr rank, DoublePtr work, IntPtr lwork, IntPtr info) {
/*  146 */     throw new UnimplementedGnuApiMethod("dgelsy_");
/*      */   }
/*      */   
/*      */   public static void dgeql2_(IntPtr m, IntPtr n, DoublePtr a, IntPtr lda, DoublePtr tau, DoublePtr work, IntPtr info) {
/*  150 */     throw new UnimplementedGnuApiMethod("dgeql2_");
/*      */   }
/*      */   
/*      */   public static void dgeqlf_(IntPtr m, IntPtr n, DoublePtr a, IntPtr lda, DoublePtr tau, DoublePtr work, IntPtr lwork, IntPtr info) {
/*  154 */     throw new UnimplementedGnuApiMethod("dgeqlf_");
/*      */   }
/*      */   
/*      */   public static void dgeqp3_(IntPtr m, IntPtr n, DoublePtr a, IntPtr lda, IntPtr jpvt, DoublePtr tau, DoublePtr work, IntPtr lwork, IntPtr info) {
/*  158 */     throw new UnimplementedGnuApiMethod("dgeqp3_");
/*      */   }
/*      */   
/*      */   public static void dgeqpf_(IntPtr m, IntPtr n, DoublePtr a, IntPtr lda, IntPtr jpvt, DoublePtr tau, DoublePtr work, IntPtr info) {
/*  162 */     throw new UnimplementedGnuApiMethod("dgeqpf_");
/*      */   }
/*      */   
/*      */   public static void dgeqr2_(IntPtr m, IntPtr n, DoublePtr a, IntPtr lda, DoublePtr tau, DoublePtr work, IntPtr info) {
/*  166 */     throw new UnimplementedGnuApiMethod("dgeqr2_");
/*      */   }
/*      */   
/*      */   public static void dgeqrf_(IntPtr m, IntPtr n, DoublePtr a, IntPtr lda, DoublePtr tau, DoublePtr work, IntPtr lwork, IntPtr info) {
/*  170 */     throw new UnimplementedGnuApiMethod("dgeqrf_");
/*      */   }
/*      */   
/*      */   public static void dgerfs_(BytePtr trans, IntPtr n, IntPtr nrhs, DoublePtr a, IntPtr lda, DoublePtr af, IntPtr ldaf, IntPtr ipiv, DoublePtr b, IntPtr ldb, DoublePtr x, IntPtr ldx, DoublePtr ferr, DoublePtr berr, DoublePtr work, IntPtr iwork, IntPtr info) {
/*  174 */     throw new UnimplementedGnuApiMethod("dgerfs_");
/*      */   }
/*      */   
/*      */   public static void dgerq2_(IntPtr m, IntPtr n, DoublePtr a, IntPtr lda, DoublePtr tau, DoublePtr work, IntPtr info) {
/*  178 */     throw new UnimplementedGnuApiMethod("dgerq2_");
/*      */   }
/*      */   
/*      */   public static void dgerqf_(IntPtr m, IntPtr n, DoublePtr a, IntPtr lda, DoublePtr tau, DoublePtr work, IntPtr lwork, IntPtr info) {
/*  182 */     throw new UnimplementedGnuApiMethod("dgerqf_");
/*      */   }
/*      */   
/*      */   public static void dgesv_(IntPtr n, IntPtr nrhs, DoublePtr a, IntPtr lda, IntPtr ipiv, DoublePtr b, IntPtr ldb, IntPtr info) {
/*  186 */     throw new UnimplementedGnuApiMethod("dgesv_");
/*      */   }
/*      */   
/*      */   public static void dgesvd_(BytePtr jobu, BytePtr jobvt, IntPtr m, IntPtr n, DoublePtr a, IntPtr lda, DoublePtr s, DoublePtr u, IntPtr ldu, DoublePtr vt, IntPtr ldvt, DoublePtr work, IntPtr lwork, IntPtr info) {
/*  190 */     throw new UnimplementedGnuApiMethod("dgesvd_");
/*      */   }
/*      */   
/*      */   public static void dgesvx_(BytePtr fact, BytePtr trans, IntPtr n, IntPtr nrhs, DoublePtr a, IntPtr lda, DoublePtr af, IntPtr ldaf, IntPtr ipiv, BytePtr equed, DoublePtr r, DoublePtr c, DoublePtr b, IntPtr ldb, DoublePtr x, IntPtr ldx, DoublePtr rcond, DoublePtr ferr, DoublePtr berr, DoublePtr work, IntPtr iwork, IntPtr info) {
/*  194 */     throw new UnimplementedGnuApiMethod("dgesvx_");
/*      */   }
/*      */   
/*      */   public static void dgetf2_(IntPtr m, IntPtr n, DoublePtr a, IntPtr lda, IntPtr ipiv, IntPtr info) {
/*  198 */     throw new UnimplementedGnuApiMethod("dgetf2_");
/*      */   }
/*      */   
/*      */   public static void dgetrf_(IntPtr m, IntPtr n, DoublePtr a, IntPtr lda, IntPtr ipiv, IntPtr info) {
/*  202 */     throw new UnimplementedGnuApiMethod("dgetrf_");
/*      */   }
/*      */   
/*      */   public static void dgetri_(IntPtr n, DoublePtr a, IntPtr lda, IntPtr ipiv, DoublePtr work, IntPtr lwork, IntPtr info) {
/*  206 */     throw new UnimplementedGnuApiMethod("dgetri_");
/*      */   }
/*      */   
/*      */   public static void dgetrs_(BytePtr trans, IntPtr n, IntPtr nrhs, DoublePtr a, IntPtr lda, IntPtr ipiv, DoublePtr b, IntPtr ldb, IntPtr info) {
/*  210 */     throw new UnimplementedGnuApiMethod("dgetrs_");
/*      */   }
/*      */   
/*      */   public static void dggbak_(BytePtr job, BytePtr side, IntPtr n, IntPtr ilo, IntPtr ihi, DoublePtr lscale, DoublePtr rscale, IntPtr m, DoublePtr v, IntPtr ldv, IntPtr info) {
/*  214 */     throw new UnimplementedGnuApiMethod("dggbak_");
/*      */   }
/*      */   
/*      */   public static void dggbal_(BytePtr job, IntPtr n, DoublePtr a, IntPtr lda, DoublePtr b, IntPtr ldb, IntPtr ilo, IntPtr ihi, DoublePtr lscale, DoublePtr rscale, DoublePtr work, IntPtr info) {
/*  218 */     throw new UnimplementedGnuApiMethod("dggbal_");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static void dggglm_(IntPtr n, IntPtr m, IntPtr p, DoublePtr a, IntPtr lda, DoublePtr b, IntPtr ldb, DoublePtr d, DoublePtr x, DoublePtr y, DoublePtr work, IntPtr lwork, IntPtr info) {
/*  224 */     throw new UnimplementedGnuApiMethod("dggglm_");
/*      */   }
/*      */   
/*      */   public static void dgghrd_(BytePtr compq, BytePtr compz, IntPtr n, IntPtr ilo, IntPtr ihi, DoublePtr a, IntPtr lda, DoublePtr b, IntPtr ldb, DoublePtr q, IntPtr ldq, DoublePtr z, IntPtr ldz, IntPtr info) {
/*  228 */     throw new UnimplementedGnuApiMethod("dgghrd_");
/*      */   }
/*      */   
/*      */   public static void dgglse_(IntPtr m, IntPtr n, IntPtr p, DoublePtr a, IntPtr lda, DoublePtr b, IntPtr ldb, DoublePtr c, DoublePtr d, DoublePtr x, DoublePtr work, IntPtr lwork, IntPtr info) {
/*  232 */     throw new UnimplementedGnuApiMethod("dgglse_");
/*      */   }
/*      */   
/*      */   public static void dggqrf_(IntPtr n, IntPtr m, IntPtr p, DoublePtr a, IntPtr lda, DoublePtr taua, DoublePtr b, IntPtr ldb, DoublePtr taub, DoublePtr work, IntPtr lwork, IntPtr info) {
/*  236 */     throw new UnimplementedGnuApiMethod("dggqrf_");
/*      */   }
/*      */   
/*      */   public static void dggrqf_(IntPtr m, IntPtr p, IntPtr n, DoublePtr a, IntPtr lda, DoublePtr taua, DoublePtr b, IntPtr ldb, DoublePtr taub, DoublePtr work, IntPtr lwork, IntPtr info) {
/*  240 */     throw new UnimplementedGnuApiMethod("dggrqf_");
/*      */   }
/*      */   
/*      */   public static void dggsvd_(BytePtr jobu, BytePtr jobv, BytePtr jobq, IntPtr m, IntPtr n, IntPtr p, IntPtr k, IntPtr l, DoublePtr a, IntPtr lda, DoublePtr b, IntPtr ldb, DoublePtr alpha, DoublePtr beta, DoublePtr u, IntPtr ldu, DoublePtr v, IntPtr ldv, DoublePtr q, IntPtr ldq, DoublePtr work, IntPtr iwork, IntPtr info) {
/*  244 */     throw new UnimplementedGnuApiMethod("dggsvd_");
/*      */   }
/*      */   
/*      */   public static void dgtcon_(BytePtr norm, IntPtr n, DoublePtr dl, DoublePtr d, DoublePtr du, DoublePtr du2, IntPtr ipiv, DoublePtr anorm, DoublePtr rcond, DoublePtr work, IntPtr iwork, IntPtr info) {
/*  248 */     throw new UnimplementedGnuApiMethod("dgtcon_");
/*      */   }
/*      */   
/*      */   public static void dgtrfs_(BytePtr trans, IntPtr n, IntPtr nrhs, DoublePtr dl, DoublePtr d, DoublePtr du, DoublePtr dlf, DoublePtr df, DoublePtr duf, DoublePtr du2, IntPtr ipiv, DoublePtr b, IntPtr ldb, DoublePtr x, IntPtr ldx, DoublePtr ferr, DoublePtr berr, DoublePtr work, IntPtr iwork, IntPtr info) {
/*  252 */     throw new UnimplementedGnuApiMethod("dgtrfs_");
/*      */   }
/*      */   
/*      */   public static void dgtsv_(IntPtr n, IntPtr nrhs, DoublePtr dl, DoublePtr d, DoublePtr du, DoublePtr b, IntPtr ldb, IntPtr info) {
/*  256 */     throw new UnimplementedGnuApiMethod("dgtsv_");
/*      */   }
/*      */   
/*      */   public static void dgtsvx_(IntPtr fact, BytePtr trans, IntPtr n, IntPtr nrhs, DoublePtr dl, DoublePtr d, DoublePtr du, DoublePtr dlf, DoublePtr df, DoublePtr duf, DoublePtr du2, IntPtr ipiv, DoublePtr b, IntPtr ldb, DoublePtr x, IntPtr ldx, DoublePtr rcond, DoublePtr ferr, DoublePtr berr, DoublePtr work, IntPtr iwork, IntPtr info) {
/*  260 */     throw new UnimplementedGnuApiMethod("dgtsvx_");
/*      */   }
/*      */   
/*      */   public static void dgttrf_(IntPtr n, DoublePtr dl, DoublePtr d, DoublePtr du, DoublePtr du2, IntPtr ipiv, IntPtr info) {
/*  264 */     throw new UnimplementedGnuApiMethod("dgttrf_");
/*      */   }
/*      */   
/*      */   public static void dgttrs_(BytePtr trans, IntPtr n, IntPtr nrhs, DoublePtr dl, DoublePtr d, DoublePtr du, DoublePtr du2, IntPtr ipiv, DoublePtr b, IntPtr ldb, IntPtr info) {
/*  268 */     throw new UnimplementedGnuApiMethod("dgttrs_");
/*      */   }
/*      */   
/*      */   public static void dopgtr_(BytePtr uplo, IntPtr n, DoublePtr ap, DoublePtr tau, DoublePtr q, IntPtr ldq, DoublePtr work, IntPtr info) {
/*  272 */     throw new UnimplementedGnuApiMethod("dopgtr_");
/*      */   }
/*      */   
/*      */   public static void dopmtr_(BytePtr side, BytePtr uplo, BytePtr trans, IntPtr m, IntPtr n, DoublePtr ap, DoublePtr tau, DoublePtr c, IntPtr ldc, DoublePtr work, IntPtr info) {
/*  276 */     throw new UnimplementedGnuApiMethod("dopmtr_");
/*      */   }
/*      */   
/*      */   public static void dorg2l_(IntPtr m, IntPtr n, IntPtr k, DoublePtr a, IntPtr lda, DoublePtr tau, DoublePtr work, IntPtr info) {
/*  280 */     throw new UnimplementedGnuApiMethod("dorg2l_");
/*      */   }
/*      */   
/*      */   public static void dorg2r_(IntPtr m, IntPtr n, IntPtr k, DoublePtr a, IntPtr lda, DoublePtr tau, DoublePtr work, IntPtr info) {
/*  284 */     throw new UnimplementedGnuApiMethod("dorg2r_");
/*      */   }
/*      */   
/*      */   public static void dorgbr_(BytePtr vect, IntPtr m, IntPtr n, IntPtr k, DoublePtr a, IntPtr lda, DoublePtr tau, DoublePtr work, IntPtr lwork, IntPtr info) {
/*  288 */     throw new UnimplementedGnuApiMethod("dorgbr_");
/*      */   }
/*      */   
/*      */   public static void dorghr_(IntPtr n, IntPtr ilo, IntPtr ihi, DoublePtr a, IntPtr lda, DoublePtr tau, DoublePtr work, IntPtr lwork, IntPtr info) {
/*  292 */     throw new UnimplementedGnuApiMethod("dorghr_");
/*      */   }
/*      */   
/*      */   public static void dorgl2_(IntPtr m, IntPtr n, IntPtr k, DoublePtr a, IntPtr lda, DoublePtr tau, DoublePtr work, IntPtr info) {
/*  296 */     throw new UnimplementedGnuApiMethod("dorgl2_");
/*      */   }
/*      */   
/*      */   public static void dorglq_(IntPtr m, IntPtr n, IntPtr k, DoublePtr a, IntPtr lda, DoublePtr tau, DoublePtr work, IntPtr lwork, IntPtr info) {
/*  300 */     throw new UnimplementedGnuApiMethod("dorglq_");
/*      */   }
/*      */   
/*      */   public static void dorgql_(IntPtr m, IntPtr n, IntPtr k, DoublePtr a, IntPtr lda, DoublePtr tau, DoublePtr work, IntPtr lwork, IntPtr info) {
/*  304 */     throw new UnimplementedGnuApiMethod("dorgql_");
/*      */   }
/*      */   
/*      */   public static void dorgqr_(IntPtr m, IntPtr n, IntPtr k, DoublePtr a, IntPtr lda, DoublePtr tau, DoublePtr work, IntPtr lwork, IntPtr info) {
/*  308 */     throw new UnimplementedGnuApiMethod("dorgqr_");
/*      */   }
/*      */   
/*      */   public static void dorgr2_(IntPtr m, IntPtr n, IntPtr k, DoublePtr a, IntPtr lda, DoublePtr tau, DoublePtr work, IntPtr info) {
/*  312 */     throw new UnimplementedGnuApiMethod("dorgr2_");
/*      */   }
/*      */   
/*      */   public static void dorgrq_(IntPtr m, IntPtr n, IntPtr k, DoublePtr a, IntPtr lda, DoublePtr tau, DoublePtr work, IntPtr lwork, IntPtr info) {
/*  316 */     throw new UnimplementedGnuApiMethod("dorgrq_");
/*      */   }
/*      */   
/*      */   public static void dorgtr_(BytePtr uplo, IntPtr n, DoublePtr a, IntPtr lda, DoublePtr tau, DoublePtr work, IntPtr lwork, IntPtr info) {
/*  320 */     throw new UnimplementedGnuApiMethod("dorgtr_");
/*      */   }
/*      */   
/*      */   public static void dorm2l_(BytePtr side, BytePtr trans, IntPtr m, IntPtr n, IntPtr k, DoublePtr a, IntPtr lda, DoublePtr tau, DoublePtr c, IntPtr ldc, DoublePtr work, IntPtr info) {
/*  324 */     throw new UnimplementedGnuApiMethod("dorm2l_");
/*      */   }
/*      */   
/*      */   public static void dorm2r_(BytePtr side, BytePtr trans, IntPtr m, IntPtr n, IntPtr k, DoublePtr a, IntPtr lda, DoublePtr tau, DoublePtr c, IntPtr ldc, DoublePtr work, IntPtr info) {
/*  328 */     throw new UnimplementedGnuApiMethod("dorm2r_");
/*      */   }
/*      */   
/*      */   public static void dormbr_(BytePtr vect, BytePtr side, BytePtr trans, IntPtr m, IntPtr n, IntPtr k, DoublePtr a, IntPtr lda, DoublePtr tau, DoublePtr c, IntPtr ldc, DoublePtr work, IntPtr lwork, IntPtr info) {
/*  332 */     throw new UnimplementedGnuApiMethod("dormbr_");
/*      */   }
/*      */   
/*      */   public static void dormhr_(BytePtr side, BytePtr trans, IntPtr m, IntPtr n, IntPtr ilo, IntPtr ihi, DoublePtr a, IntPtr lda, DoublePtr tau, DoublePtr c, IntPtr ldc, DoublePtr work, IntPtr lwork, IntPtr info) {
/*  336 */     throw new UnimplementedGnuApiMethod("dormhr_");
/*      */   }
/*      */   
/*      */   public static void dorml2_(BytePtr side, BytePtr trans, IntPtr m, IntPtr n, IntPtr k, DoublePtr a, IntPtr lda, DoublePtr tau, DoublePtr c, IntPtr ldc, DoublePtr work, IntPtr info) {
/*  340 */     throw new UnimplementedGnuApiMethod("dorml2_");
/*      */   }
/*      */   
/*      */   public static void dormlq_(BytePtr side, BytePtr trans, IntPtr m, IntPtr n, IntPtr k, DoublePtr a, IntPtr lda, DoublePtr tau, DoublePtr c, IntPtr ldc, DoublePtr work, IntPtr lwork, IntPtr info) {
/*  344 */     throw new UnimplementedGnuApiMethod("dormlq_");
/*      */   }
/*      */   
/*      */   public static void dormql_(BytePtr side, BytePtr trans, IntPtr m, IntPtr n, IntPtr k, DoublePtr a, IntPtr lda, DoublePtr tau, DoublePtr c, IntPtr ldc, DoublePtr work, IntPtr lwork, IntPtr info) {
/*  348 */     throw new UnimplementedGnuApiMethod("dormql_");
/*      */   }
/*      */   
/*      */   public static void dormqr_(BytePtr side, BytePtr trans, IntPtr m, IntPtr n, IntPtr k, DoublePtr a, IntPtr lda, DoublePtr tau, DoublePtr c, IntPtr ldc, DoublePtr work, IntPtr lwork, IntPtr info) {
/*  352 */     throw new UnimplementedGnuApiMethod("dormqr_");
/*      */   }
/*      */   
/*      */   public static void dormr2_(BytePtr side, BytePtr trans, IntPtr m, IntPtr n, IntPtr k, DoublePtr a, IntPtr lda, DoublePtr tau, DoublePtr c, IntPtr ldc, DoublePtr work, IntPtr info) {
/*  356 */     throw new UnimplementedGnuApiMethod("dormr2_");
/*      */   }
/*      */   
/*      */   public static void dormrq_(BytePtr side, BytePtr trans, IntPtr m, IntPtr n, IntPtr k, DoublePtr a, IntPtr lda, DoublePtr tau, DoublePtr c, IntPtr ldc, DoublePtr work, IntPtr lwork, IntPtr info) {
/*  360 */     throw new UnimplementedGnuApiMethod("dormrq_");
/*      */   }
/*      */   
/*      */   public static void dormtr_(BytePtr side, BytePtr uplo, BytePtr trans, IntPtr m, IntPtr n, DoublePtr a, IntPtr lda, DoublePtr tau, DoublePtr c, IntPtr ldc, DoublePtr work, IntPtr lwork, IntPtr info) {
/*  364 */     throw new UnimplementedGnuApiMethod("dormtr_");
/*      */   }
/*      */   
/*      */   public static void dpbcon_(BytePtr uplo, IntPtr n, IntPtr kd, DoublePtr ab, IntPtr ldab, DoublePtr anorm, DoublePtr rcond, DoublePtr work, IntPtr iwork, IntPtr info) {
/*  368 */     throw new UnimplementedGnuApiMethod("dpbcon_");
/*      */   }
/*      */   
/*      */   public static void dpbequ_(BytePtr uplo, IntPtr n, IntPtr kd, DoublePtr ab, IntPtr ldab, DoublePtr s, DoublePtr scond, DoublePtr amax, IntPtr info) {
/*  372 */     throw new UnimplementedGnuApiMethod("dpbequ_");
/*      */   }
/*      */   
/*      */   public static void dpbrfs_(BytePtr uplo, IntPtr n, IntPtr kd, IntPtr nrhs, DoublePtr ab, IntPtr ldab, DoublePtr afb, IntPtr ldafb, DoublePtr b, IntPtr ldb, DoublePtr x, IntPtr ldx, DoublePtr ferr, DoublePtr berr, DoublePtr work, IntPtr iwork, IntPtr info) {
/*  376 */     throw new UnimplementedGnuApiMethod("dpbrfs_");
/*      */   }
/*      */   
/*      */   public static void dpbstf_(BytePtr uplo, IntPtr n, IntPtr kd, DoublePtr ab, IntPtr ldab, IntPtr info) {
/*  380 */     throw new UnimplementedGnuApiMethod("dpbstf_");
/*      */   }
/*      */   
/*      */   public static void dpbsv_(BytePtr uplo, IntPtr n, IntPtr kd, IntPtr nrhs, DoublePtr ab, IntPtr ldab, DoublePtr b, IntPtr ldb, IntPtr info) {
/*  384 */     throw new UnimplementedGnuApiMethod("dpbsv_");
/*      */   }
/*      */   
/*      */   public static void dpbsvx_(IntPtr fact, BytePtr uplo, IntPtr n, IntPtr kd, IntPtr nrhs, DoublePtr ab, IntPtr ldab, DoublePtr afb, IntPtr ldafb, BytePtr equed, DoublePtr s, DoublePtr b, IntPtr ldb, DoublePtr x, IntPtr ldx, DoublePtr rcond, DoublePtr ferr, DoublePtr berr, DoublePtr work, IntPtr iwork, IntPtr info) {
/*  388 */     throw new UnimplementedGnuApiMethod("dpbsvx_");
/*      */   }
/*      */   
/*      */   public static void dpbtf2_(BytePtr uplo, IntPtr n, IntPtr kd, DoublePtr ab, IntPtr ldab, IntPtr info) {
/*  392 */     throw new UnimplementedGnuApiMethod("dpbtf2_");
/*      */   }
/*      */   
/*      */   public static void dpbtrf_(BytePtr uplo, IntPtr n, IntPtr kd, DoublePtr ab, IntPtr ldab, IntPtr info) {
/*  396 */     throw new UnimplementedGnuApiMethod("dpbtrf_");
/*      */   }
/*      */   
/*      */   public static void dpbtrs_(BytePtr uplo, IntPtr n, IntPtr kd, IntPtr nrhs, DoublePtr ab, IntPtr ldab, DoublePtr b, IntPtr ldb, IntPtr info) {
/*  400 */     throw new UnimplementedGnuApiMethod("dpbtrs_");
/*      */   }
/*      */   
/*      */   public static void dpocon_(BytePtr uplo, IntPtr n, DoublePtr a, IntPtr lda, DoublePtr anorm, DoublePtr rcond, DoublePtr work, IntPtr iwork, IntPtr info) {
/*  404 */     throw new UnimplementedGnuApiMethod("dpocon_");
/*      */   }
/*      */   
/*      */   public static void dpoequ_(IntPtr n, DoublePtr a, IntPtr lda, DoublePtr s, DoublePtr scond, DoublePtr amax, IntPtr info) {
/*  408 */     throw new UnimplementedGnuApiMethod("dpoequ_");
/*      */   }
/*      */   
/*      */   public static void dporfs_(BytePtr uplo, IntPtr n, IntPtr nrhs, DoublePtr a, IntPtr lda, DoublePtr af, IntPtr ldaf, DoublePtr b, IntPtr ldb, DoublePtr x, IntPtr ldx, DoublePtr ferr, DoublePtr berr, DoublePtr work, IntPtr iwork, IntPtr info) {
/*  412 */     throw new UnimplementedGnuApiMethod("dporfs_");
/*      */   }
/*      */   
/*      */   public static void dposv_(BytePtr uplo, IntPtr n, IntPtr nrhs, DoublePtr a, IntPtr lda, DoublePtr b, IntPtr ldb, IntPtr info) {
/*  416 */     throw new UnimplementedGnuApiMethod("dposv_");
/*      */   }
/*      */   
/*      */   public static void dposvx_(IntPtr fact, BytePtr uplo, IntPtr n, IntPtr nrhs, DoublePtr a, IntPtr lda, DoublePtr af, IntPtr ldaf, BytePtr equed, DoublePtr s, DoublePtr b, IntPtr ldb, DoublePtr x, IntPtr ldx, DoublePtr rcond, DoublePtr ferr, DoublePtr berr, DoublePtr work, IntPtr iwork, IntPtr info) {
/*  420 */     throw new UnimplementedGnuApiMethod("dposvx_");
/*      */   }
/*      */   
/*      */   public static void dpotf2_(BytePtr uplo, IntPtr n, DoublePtr a, IntPtr lda, IntPtr info) {
/*  424 */     throw new UnimplementedGnuApiMethod("dpotf2_");
/*      */   }
/*      */   
/*      */   public static void dpotrf_(BytePtr uplo, IntPtr n, DoublePtr a, IntPtr lda, IntPtr info) {
/*  428 */     throw new UnimplementedGnuApiMethod("dpotrf_");
/*      */   }
/*      */   
/*      */   public static void dpotri_(BytePtr uplo, IntPtr n, DoublePtr a, IntPtr lda, IntPtr info) {
/*  432 */     throw new UnimplementedGnuApiMethod("dpotri_");
/*      */   }
/*      */   
/*      */   public static void dpotrs_(BytePtr uplo, IntPtr n, IntPtr nrhs, DoublePtr a, IntPtr lda, DoublePtr b, IntPtr ldb, IntPtr info) {
/*  436 */     throw new UnimplementedGnuApiMethod("dpotrs_");
/*      */   }
/*      */   
/*      */   public static void dppcon_(BytePtr uplo, IntPtr n, DoublePtr ap, DoublePtr anorm, DoublePtr rcond, DoublePtr work, IntPtr iwork, IntPtr info) {
/*  440 */     throw new UnimplementedGnuApiMethod("dppcon_");
/*      */   }
/*      */   
/*      */   public static void dppequ_(BytePtr uplo, IntPtr n, DoublePtr ap, DoublePtr s, DoublePtr scond, DoublePtr amax, IntPtr info) {
/*  444 */     throw new UnimplementedGnuApiMethod("dppequ_");
/*      */   }
/*      */   
/*      */   public static void dpprfs_(BytePtr uplo, IntPtr n, IntPtr nrhs, DoublePtr ap, DoublePtr afp, DoublePtr b, IntPtr ldb, DoublePtr x, IntPtr ldx, DoublePtr ferr, DoublePtr berr, DoublePtr work, IntPtr iwork, IntPtr info) {
/*  448 */     throw new UnimplementedGnuApiMethod("dpprfs_");
/*      */   }
/*      */   
/*      */   public static void dppsv_(BytePtr uplo, IntPtr n, IntPtr nrhs, DoublePtr ap, DoublePtr b, IntPtr ldb, IntPtr info) {
/*  452 */     throw new UnimplementedGnuApiMethod("dppsv_");
/*      */   }
/*      */   
/*      */   public static void dppsvx_(IntPtr fact, BytePtr uplo, IntPtr n, IntPtr nrhs, DoublePtr ap, DoublePtr afp, BytePtr equed, DoublePtr s, DoublePtr b, IntPtr ldb, DoublePtr x, IntPtr ldx, DoublePtr rcond, DoublePtr ferr, DoublePtr berr, DoublePtr work, IntPtr iwork, IntPtr info) {
/*  456 */     throw new UnimplementedGnuApiMethod("dppsvx_");
/*      */   }
/*      */   
/*      */   public static void dpptrf_(BytePtr uplo, IntPtr n, DoublePtr ap, IntPtr info) {
/*  460 */     throw new UnimplementedGnuApiMethod("dpptrf_");
/*      */   }
/*      */   
/*      */   public static void dpptri_(BytePtr uplo, IntPtr n, DoublePtr ap, IntPtr info) {
/*  464 */     throw new UnimplementedGnuApiMethod("dpptri_");
/*      */   }
/*      */   
/*      */   public static void dpptrs_(BytePtr uplo, IntPtr n, IntPtr nrhs, DoublePtr ap, DoublePtr b, IntPtr ldb, IntPtr info) {
/*  468 */     throw new UnimplementedGnuApiMethod("dpptrs_");
/*      */   }
/*      */   
/*      */   public static void dptcon_(IntPtr n, DoublePtr d, DoublePtr e, DoublePtr anorm, DoublePtr rcond, DoublePtr work, IntPtr info) {
/*  472 */     throw new UnimplementedGnuApiMethod("dptcon_");
/*      */   }
/*      */   
/*      */   public static void dpteqr_(BytePtr compz, IntPtr n, DoublePtr d, DoublePtr e, DoublePtr z, IntPtr ldz, DoublePtr work, IntPtr info) {
/*  476 */     throw new UnimplementedGnuApiMethod("dpteqr_");
/*      */   }
/*      */   
/*      */   public static void dptrfs_(IntPtr n, IntPtr nrhs, DoublePtr d, DoublePtr e, DoublePtr df, DoublePtr ef, DoublePtr b, IntPtr ldb, DoublePtr x, IntPtr ldx, DoublePtr ferr, DoublePtr berr, DoublePtr work, IntPtr info) {
/*  480 */     throw new UnimplementedGnuApiMethod("dptrfs_");
/*      */   }
/*      */   
/*      */   public static void dptsv_(IntPtr n, IntPtr nrhs, DoublePtr d, DoublePtr e, DoublePtr b, IntPtr ldb, IntPtr info) {
/*  484 */     throw new UnimplementedGnuApiMethod("dptsv_");
/*      */   }
/*      */   
/*      */   public static void dptsvx_(IntPtr fact, IntPtr n, IntPtr nrhs, DoublePtr d, DoublePtr e, DoublePtr df, DoublePtr ef, DoublePtr b, IntPtr ldb, DoublePtr x, IntPtr ldx, DoublePtr rcond, DoublePtr ferr, DoublePtr berr, DoublePtr work, IntPtr info) {
/*  488 */     throw new UnimplementedGnuApiMethod("dptsvx_");
/*      */   }
/*      */   
/*      */   public static void dpttrf_(IntPtr n, DoublePtr d, DoublePtr e, IntPtr info) {
/*  492 */     throw new UnimplementedGnuApiMethod("dpttrf_");
/*      */   }
/*      */   
/*      */   public static void dpttrs_(IntPtr n, IntPtr nrhs, DoublePtr d, DoublePtr e, DoublePtr b, IntPtr ldb, IntPtr info) {
/*  496 */     throw new UnimplementedGnuApiMethod("dpttrs_");
/*      */   }
/*      */   
/*      */   public static void drscl_(IntPtr n, DoublePtr da, DoublePtr x, IntPtr incx) {
/*  500 */     throw new UnimplementedGnuApiMethod("drscl_");
/*      */   }
/*      */   
/*      */   public static void dsbev_(BytePtr jobz, BytePtr uplo, IntPtr n, IntPtr kd, DoublePtr ab, IntPtr ldab, DoublePtr w, DoublePtr z, IntPtr ldz, DoublePtr work, IntPtr info) {
/*  504 */     throw new UnimplementedGnuApiMethod("dsbev_");
/*      */   }
/*      */   
/*      */   public static void dsbevd_(BytePtr jobz, BytePtr uplo, IntPtr n, IntPtr kd, DoublePtr ab, IntPtr ldab, DoublePtr w, DoublePtr z, IntPtr ldz, DoublePtr work, IntPtr lwork, IntPtr iwork, IntPtr liwork, IntPtr info) {
/*  508 */     throw new UnimplementedGnuApiMethod("dsbevd_");
/*      */   }
/*      */   
/*      */   public static void dsbevx_(BytePtr jobz, BytePtr range, BytePtr uplo, IntPtr n, IntPtr kd, DoublePtr ab, IntPtr ldab, DoublePtr q, IntPtr ldq, DoublePtr vl, DoublePtr vu, IntPtr il, IntPtr iu, DoublePtr abstol, IntPtr m, DoublePtr w, DoublePtr z, IntPtr ldz, DoublePtr work, IntPtr iwork, IntPtr ifail, IntPtr info) {
/*  512 */     throw new UnimplementedGnuApiMethod("dsbevx_");
/*      */   }
/*      */   
/*      */   public static void dsbgst_(BytePtr vect, BytePtr uplo, IntPtr n, IntPtr ka, IntPtr kb, DoublePtr ab, IntPtr ldab, DoublePtr bb, IntPtr ldbb, DoublePtr x, IntPtr ldx, DoublePtr work, IntPtr info) {
/*  516 */     throw new UnimplementedGnuApiMethod("dsbgst_");
/*      */   }
/*      */   
/*      */   public static void dsbgv_(BytePtr jobz, BytePtr uplo, IntPtr n, IntPtr ka, IntPtr kb, DoublePtr ab, IntPtr ldab, DoublePtr bb, IntPtr ldbb, DoublePtr w, DoublePtr z, IntPtr ldz, DoublePtr work, IntPtr info) {
/*  520 */     throw new UnimplementedGnuApiMethod("dsbgv_");
/*      */   }
/*      */   
/*      */   public static void dsbtrd_(BytePtr vect, BytePtr uplo, IntPtr n, IntPtr kd, DoublePtr ab, IntPtr ldab, DoublePtr d, DoublePtr e, DoublePtr q, IntPtr ldq, DoublePtr work, IntPtr info) {
/*  524 */     throw new UnimplementedGnuApiMethod("dsbtrd_");
/*      */   }
/*      */   
/*      */   public static void dspcon_(BytePtr uplo, IntPtr n, DoublePtr ap, IntPtr ipiv, DoublePtr anorm, DoublePtr rcond, DoublePtr work, IntPtr iwork, IntPtr info) {
/*  528 */     throw new UnimplementedGnuApiMethod("dspcon_");
/*      */   }
/*      */   
/*      */   public static void dspev_(BytePtr jobz, BytePtr uplo, IntPtr n, DoublePtr ap, DoublePtr w, DoublePtr z, IntPtr ldz, DoublePtr work, IntPtr info) {
/*  532 */     throw new UnimplementedGnuApiMethod("dspev_");
/*      */   }
/*      */   
/*      */   public static void dspevd_(BytePtr jobz, BytePtr uplo, IntPtr n, DoublePtr ap, DoublePtr w, DoublePtr z, IntPtr ldz, DoublePtr work, IntPtr lwork, IntPtr iwork, IntPtr liwork, IntPtr info) {
/*  536 */     throw new UnimplementedGnuApiMethod("dspevd_");
/*      */   }
/*      */   
/*      */   public static void dspevx_(BytePtr jobz, BytePtr range, BytePtr uplo, IntPtr n, DoublePtr ap, DoublePtr vl, DoublePtr vu, IntPtr il, IntPtr iu, DoublePtr abstol, IntPtr m, DoublePtr w, DoublePtr z, IntPtr ldz, DoublePtr work, IntPtr iwork, IntPtr ifail, IntPtr info) {
/*  540 */     throw new UnimplementedGnuApiMethod("dspevx_");
/*      */   }
/*      */   
/*      */   public static void dspgst_(IntPtr itype, BytePtr uplo, IntPtr n, DoublePtr ap, DoublePtr bp, IntPtr info) {
/*  544 */     throw new UnimplementedGnuApiMethod("dspgst_");
/*      */   }
/*      */   
/*      */   public static void dspgv_(IntPtr itype, BytePtr jobz, BytePtr uplo, IntPtr n, DoublePtr ap, DoublePtr bp, DoublePtr w, DoublePtr z, IntPtr ldz, DoublePtr work, IntPtr info) {
/*  548 */     throw new UnimplementedGnuApiMethod("dspgv_");
/*      */   }
/*      */   
/*      */   public static void dsprfs_(BytePtr uplo, IntPtr n, IntPtr nrhs, DoublePtr ap, DoublePtr afp, IntPtr ipiv, DoublePtr b, IntPtr ldb, DoublePtr x, IntPtr ldx, DoublePtr ferr, DoublePtr berr, DoublePtr work, IntPtr iwork, IntPtr info) {
/*  552 */     throw new UnimplementedGnuApiMethod("dsprfs_");
/*      */   }
/*      */   
/*      */   public static void dspsv_(BytePtr uplo, IntPtr n, IntPtr nrhs, DoublePtr ap, IntPtr ipiv, DoublePtr b, IntPtr ldb, IntPtr info) {
/*  556 */     throw new UnimplementedGnuApiMethod("dspsv_");
/*      */   }
/*      */   
/*      */   public static void dspsvx_(IntPtr fact, BytePtr uplo, IntPtr n, IntPtr nrhs, DoublePtr ap, DoublePtr afp, IntPtr ipiv, DoublePtr b, IntPtr ldb, DoublePtr x, IntPtr ldx, DoublePtr rcond, DoublePtr ferr, DoublePtr berr, DoublePtr work, IntPtr iwork, IntPtr info) {
/*  560 */     throw new UnimplementedGnuApiMethod("dspsvx_");
/*      */   }
/*      */   
/*      */   public static void dsptrd_(BytePtr uplo, IntPtr n, DoublePtr ap, DoublePtr d, DoublePtr e, DoublePtr tau, IntPtr info) {
/*  564 */     throw new UnimplementedGnuApiMethod("dsptrd_");
/*      */   }
/*      */   
/*      */   public static void dsptrf_(BytePtr uplo, IntPtr n, DoublePtr ap, IntPtr ipiv, IntPtr info) {
/*  568 */     throw new UnimplementedGnuApiMethod("dsptrf_");
/*      */   }
/*      */   
/*      */   public static void dsptri_(BytePtr uplo, IntPtr n, DoublePtr ap, IntPtr ipiv, DoublePtr work, IntPtr info) {
/*  572 */     throw new UnimplementedGnuApiMethod("dsptri_");
/*      */   }
/*      */   
/*      */   public static void dsptrs_(BytePtr uplo, IntPtr n, IntPtr nrhs, DoublePtr ap, IntPtr ipiv, DoublePtr b, IntPtr ldb, IntPtr info) {
/*  576 */     throw new UnimplementedGnuApiMethod("dsptrs_");
/*      */   }
/*      */   
/*      */   public static void dstebz_(BytePtr range, BytePtr order, IntPtr n, DoublePtr vl, DoublePtr vu, IntPtr il, IntPtr iu, DoublePtr abstol, DoublePtr d, DoublePtr e, IntPtr m, IntPtr nsplit, DoublePtr w, IntPtr iblock, IntPtr isplit, DoublePtr work, IntPtr iwork, IntPtr info) {
/*  580 */     throw new UnimplementedGnuApiMethod("dstebz_");
/*      */   }
/*      */   
/*      */   public static void dstedc_(BytePtr compz, IntPtr n, DoublePtr d, DoublePtr e, DoublePtr z, IntPtr ldz, DoublePtr work, IntPtr lwork, IntPtr iwork, IntPtr liwork, IntPtr info) {
/*  584 */     throw new UnimplementedGnuApiMethod("dstedc_");
/*      */   }
/*      */   
/*      */   public static void dstein_(IntPtr n, DoublePtr d, DoublePtr e, IntPtr m, DoublePtr w, IntPtr iblock, IntPtr isplit, DoublePtr z, IntPtr ldz, DoublePtr work, IntPtr iwork, IntPtr ifail, IntPtr info) {
/*  588 */     throw new UnimplementedGnuApiMethod("dstein_");
/*      */   }
/*      */   
/*      */   public static void dsteqr_(BytePtr compz, IntPtr n, DoublePtr d, DoublePtr e, DoublePtr z, IntPtr ldz, DoublePtr work, IntPtr info) {
/*  592 */     throw new UnimplementedGnuApiMethod("dsteqr_");
/*      */   }
/*      */   
/*      */   public static void dsterf_(IntPtr n, DoublePtr d, DoublePtr e, IntPtr info) {
/*  596 */     throw new UnimplementedGnuApiMethod("dsterf_");
/*      */   }
/*      */   
/*      */   public static void dstev_(BytePtr jobz, IntPtr n, DoublePtr d, DoublePtr e, DoublePtr z, IntPtr ldz, DoublePtr work, IntPtr info) {
/*  600 */     throw new UnimplementedGnuApiMethod("dstev_");
/*      */   }
/*      */   
/*      */   public static void dstevd_(BytePtr jobz, IntPtr n, DoublePtr d, DoublePtr e, DoublePtr z, IntPtr ldz, DoublePtr work, IntPtr lwork, IntPtr iwork, IntPtr liwork, IntPtr info) {
/*  604 */     throw new UnimplementedGnuApiMethod("dstevd_");
/*      */   }
/*      */   
/*      */   public static void dstevx_(BytePtr jobz, BytePtr range, IntPtr n, DoublePtr d, DoublePtr e, DoublePtr vl, DoublePtr vu, IntPtr il, IntPtr iu, DoublePtr abstol, IntPtr m, DoublePtr w, DoublePtr z, IntPtr ldz, DoublePtr work, IntPtr iwork, IntPtr ifail, IntPtr info) {
/*  608 */     throw new UnimplementedGnuApiMethod("dstevx_");
/*      */   }
/*      */   
/*      */   public static void dsycon_(BytePtr uplo, IntPtr n, DoublePtr a, IntPtr lda, IntPtr ipiv, DoublePtr anorm, DoublePtr rcond, DoublePtr work, IntPtr iwork, IntPtr info) {
/*  612 */     throw new UnimplementedGnuApiMethod("dsycon_");
/*      */   }
/*      */   
/*      */   public static void dsyev_(BytePtr jobz, BytePtr uplo, IntPtr n, DoublePtr a, IntPtr lda, DoublePtr w, DoublePtr work, IntPtr lwork, IntPtr info) {
/*  616 */     throw new UnimplementedGnuApiMethod("dsyev_");
/*      */   }
/*      */   
/*      */   public static void dsyevd_(BytePtr jobz, BytePtr uplo, IntPtr n, DoublePtr a, IntPtr lda, DoublePtr w, DoublePtr work, IntPtr lwork, IntPtr iwork, IntPtr liwork, IntPtr info) {
/*  620 */     throw new UnimplementedGnuApiMethod("dsyevd_");
/*      */   }
/*      */   
/*      */   public static void dsyevx_(BytePtr jobz, BytePtr range, BytePtr uplo, IntPtr n, DoublePtr a, IntPtr lda, DoublePtr vl, DoublePtr vu, IntPtr il, IntPtr iu, DoublePtr abstol, IntPtr m, DoublePtr w, DoublePtr z, IntPtr ldz, DoublePtr work, IntPtr lwork, IntPtr iwork, IntPtr ifail, IntPtr info) {
/*  624 */     throw new UnimplementedGnuApiMethod("dsyevx_");
/*      */   }
/*      */   
/*      */   public static void dsyevr_(BytePtr jobz, BytePtr range, BytePtr uplo, IntPtr n, DoublePtr a, IntPtr lda, DoublePtr vl, DoublePtr vu, IntPtr il, IntPtr iu, DoublePtr abstol, IntPtr m, DoublePtr w, DoublePtr z, IntPtr ldz, IntPtr isuppz, DoublePtr work, IntPtr lwork, IntPtr iwork, IntPtr liwork, IntPtr info) {
/*  628 */     throw new UnimplementedGnuApiMethod("dsyevr_");
/*      */   }
/*      */   
/*      */   public static void dsygs2_(IntPtr itype, BytePtr uplo, IntPtr n, DoublePtr a, IntPtr lda, DoublePtr b, IntPtr ldb, IntPtr info) {
/*  632 */     throw new UnimplementedGnuApiMethod("dsygs2_");
/*      */   }
/*      */   
/*      */   public static void dsygst_(IntPtr itype, BytePtr uplo, IntPtr n, DoublePtr a, IntPtr lda, DoublePtr b, IntPtr ldb, IntPtr info) {
/*  636 */     throw new UnimplementedGnuApiMethod("dsygst_");
/*      */   }
/*      */   
/*      */   public static void dsygv_(IntPtr itype, BytePtr jobz, BytePtr uplo, IntPtr n, DoublePtr a, IntPtr lda, DoublePtr b, IntPtr ldb, DoublePtr w, DoublePtr work, IntPtr lwork, IntPtr info) {
/*  640 */     throw new UnimplementedGnuApiMethod("dsygv_");
/*      */   }
/*      */   
/*      */   public static void dsyrfs_(BytePtr uplo, IntPtr n, IntPtr nrhs, DoublePtr a, IntPtr lda, DoublePtr af, IntPtr ldaf, IntPtr ipiv, DoublePtr b, IntPtr ldb, DoublePtr x, IntPtr ldx, DoublePtr ferr, DoublePtr berr, DoublePtr work, IntPtr iwork, IntPtr info) {
/*  644 */     throw new UnimplementedGnuApiMethod("dsyrfs_");
/*      */   }
/*      */   
/*      */   public static void dsysv_(BytePtr uplo, IntPtr n, IntPtr nrhs, DoublePtr a, IntPtr lda, IntPtr ipiv, DoublePtr b, IntPtr ldb, DoublePtr work, IntPtr lwork, IntPtr info) {
/*  648 */     throw new UnimplementedGnuApiMethod("dsysv_");
/*      */   }
/*      */   
/*      */   public static void dsysvx_(IntPtr fact, BytePtr uplo, IntPtr n, IntPtr nrhs, DoublePtr a, IntPtr lda, DoublePtr af, IntPtr ldaf, IntPtr ipiv, DoublePtr b, IntPtr ldb, DoublePtr x, IntPtr ldx, DoublePtr rcond, DoublePtr ferr, DoublePtr berr, DoublePtr work, IntPtr lwork, IntPtr iwork, IntPtr info) {
/*  652 */     throw new UnimplementedGnuApiMethod("dsysvx_");
/*      */   }
/*      */   
/*      */   public static void dsytd2_(BytePtr uplo, IntPtr n, DoublePtr a, IntPtr lda, DoublePtr d, DoublePtr e, DoublePtr tau, IntPtr info) {
/*  656 */     throw new UnimplementedGnuApiMethod("dsytd2_");
/*      */   }
/*      */   
/*      */   public static void dsytf2_(BytePtr uplo, IntPtr n, DoublePtr a, IntPtr lda, IntPtr ipiv, IntPtr info) {
/*  660 */     throw new UnimplementedGnuApiMethod("dsytf2_");
/*      */   }
/*      */   
/*      */   public static void dsytrd_(BytePtr uplo, IntPtr n, DoublePtr a, IntPtr lda, DoublePtr d, DoublePtr e, DoublePtr tau, DoublePtr work, IntPtr lwork, IntPtr info) {
/*  664 */     throw new UnimplementedGnuApiMethod("dsytrd_");
/*      */   }
/*      */   
/*      */   public static void dsytrf_(BytePtr uplo, IntPtr n, DoublePtr a, IntPtr lda, IntPtr ipiv, DoublePtr work, IntPtr lwork, IntPtr info) {
/*  668 */     throw new UnimplementedGnuApiMethod("dsytrf_");
/*      */   }
/*      */   
/*      */   public static void dsytri_(BytePtr uplo, IntPtr n, DoublePtr a, IntPtr lda, IntPtr ipiv, DoublePtr work, IntPtr info) {
/*  672 */     throw new UnimplementedGnuApiMethod("dsytri_");
/*      */   }
/*      */   
/*      */   public static void dsytrs_(BytePtr uplo, IntPtr n, IntPtr nrhs, DoublePtr a, IntPtr lda, IntPtr ipiv, DoublePtr b, IntPtr ldb, IntPtr info) {
/*  676 */     throw new UnimplementedGnuApiMethod("dsytrs_");
/*      */   }
/*      */   
/*      */   public static void dtbcon_(BytePtr norm, BytePtr uplo, BytePtr diag, IntPtr n, IntPtr kd, DoublePtr ab, IntPtr ldab, DoublePtr rcond, DoublePtr work, IntPtr iwork, IntPtr info) {
/*  680 */     throw new UnimplementedGnuApiMethod("dtbcon_");
/*      */   }
/*      */   
/*      */   public static void dtbrfs_(BytePtr uplo, BytePtr trans, BytePtr diag, IntPtr n, IntPtr kd, IntPtr nrhs, DoublePtr ab, IntPtr ldab, DoublePtr b, IntPtr ldb, DoublePtr x, IntPtr ldx, DoublePtr ferr, DoublePtr berr, DoublePtr work, IntPtr iwork, IntPtr info) {
/*  684 */     throw new UnimplementedGnuApiMethod("dtbrfs_");
/*      */   }
/*      */   
/*      */   public static void dtbtrs_(BytePtr uplo, BytePtr trans, BytePtr diag, IntPtr n, IntPtr kd, IntPtr nrhs, DoublePtr ab, IntPtr ldab, DoublePtr b, IntPtr ldb, IntPtr info) {
/*  688 */     throw new UnimplementedGnuApiMethod("dtbtrs_");
/*      */   }
/*      */   
/*      */   public static void dtgevc_(BytePtr side, BytePtr howmny, IntPtr select, IntPtr n, DoublePtr a, IntPtr lda, DoublePtr b, IntPtr ldb, DoublePtr vl, IntPtr ldvl, DoublePtr vr, IntPtr ldvr, IntPtr mm, IntPtr m, DoublePtr work, IntPtr info) {
/*  692 */     throw new UnimplementedGnuApiMethod("dtgevc_");
/*      */   }
/*      */   
/*      */   public static void dtgsja_(BytePtr jobu, BytePtr jobv, BytePtr jobq, IntPtr m, IntPtr p, IntPtr n, IntPtr k, IntPtr l, DoublePtr a, IntPtr lda, DoublePtr b, IntPtr ldb, DoublePtr tola, DoublePtr tolb, DoublePtr alpha, DoublePtr beta, DoublePtr u, IntPtr ldu, DoublePtr v, IntPtr ldv, DoublePtr q, IntPtr ldq, DoublePtr work, IntPtr ncycle, IntPtr info) {
/*  696 */     throw new UnimplementedGnuApiMethod("dtgsja_");
/*      */   }
/*      */   
/*      */   public static void dtpcon_(BytePtr norm, BytePtr uplo, BytePtr diag, IntPtr n, DoublePtr ap, DoublePtr rcond, DoublePtr work, IntPtr iwork, IntPtr info) {
/*  700 */     throw new UnimplementedGnuApiMethod("dtpcon_");
/*      */   }
/*      */   
/*      */   public static void dtprfs_(BytePtr uplo, BytePtr trans, BytePtr diag, IntPtr n, IntPtr nrhs, DoublePtr ap, DoublePtr b, IntPtr ldb, DoublePtr x, IntPtr ldx, DoublePtr ferr, DoublePtr berr, DoublePtr work, IntPtr iwork, IntPtr info) {
/*  704 */     throw new UnimplementedGnuApiMethod("dtprfs_");
/*      */   }
/*      */   
/*      */   public static void dtptri_(BytePtr uplo, BytePtr diag, IntPtr n, DoublePtr ap, IntPtr info) {
/*  708 */     throw new UnimplementedGnuApiMethod("dtptri_");
/*      */   }
/*      */   
/*      */   public static void dtptrs_(BytePtr uplo, BytePtr trans, BytePtr diag, IntPtr n, IntPtr nrhs, DoublePtr ap, DoublePtr b, IntPtr ldb, IntPtr info) {
/*  712 */     throw new UnimplementedGnuApiMethod("dtptrs_");
/*      */   }
/*      */   
/*      */   public static void dtrcon_(BytePtr norm, BytePtr uplo, BytePtr diag, IntPtr n, DoublePtr a, IntPtr lda, DoublePtr rcond, DoublePtr work, IntPtr iwork, IntPtr info) {
/*  716 */     throw new UnimplementedGnuApiMethod("dtrcon_");
/*      */   }
/*      */   
/*      */   public static void dtrevc_(BytePtr side, BytePtr howmny, IntPtr select, IntPtr n, DoublePtr t, IntPtr ldt, DoublePtr vl, IntPtr ldvl, DoublePtr vr, IntPtr ldvr, IntPtr mm, IntPtr m, DoublePtr work, IntPtr info) {
/*  720 */     throw new UnimplementedGnuApiMethod("dtrevc_");
/*      */   }
/*      */   
/*      */   public static void dtrexc_(BytePtr compq, IntPtr n, DoublePtr t, IntPtr ldt, DoublePtr q, IntPtr ldq, IntPtr ifst, IntPtr ILST, DoublePtr work, IntPtr info) {
/*  724 */     throw new UnimplementedGnuApiMethod("dtrexc_");
/*      */   }
/*      */   
/*      */   public static void dtrrfs_(BytePtr uplo, BytePtr trans, BytePtr diag, IntPtr n, IntPtr nrhs, DoublePtr a, IntPtr lda, DoublePtr b, IntPtr ldb, DoublePtr x, IntPtr ldx, DoublePtr ferr, DoublePtr berr, DoublePtr work, IntPtr iwork, IntPtr info) {
/*  728 */     throw new UnimplementedGnuApiMethod("dtrrfs_");
/*      */   }
/*      */   
/*      */   public static void dtrsen_(BytePtr job, BytePtr compq, IntPtr select, IntPtr n, DoublePtr t, IntPtr ldt, DoublePtr q, IntPtr ldq, DoublePtr wr, DoublePtr wi, IntPtr m, DoublePtr s, DoublePtr sep, DoublePtr work, IntPtr lwork, IntPtr iwork, IntPtr liwork, IntPtr info) {
/*  732 */     throw new UnimplementedGnuApiMethod("dtrsen_");
/*      */   }
/*      */   
/*      */   public static void dtrsna_(BytePtr job, BytePtr howmny, IntPtr select, IntPtr n, DoublePtr t, IntPtr ldt, DoublePtr vl, IntPtr ldvl, DoublePtr vr, IntPtr ldvr, DoublePtr s, DoublePtr sep, IntPtr mm, IntPtr m, DoublePtr work, IntPtr lwork, IntPtr iwork, IntPtr info) {
/*  736 */     throw new UnimplementedGnuApiMethod("dtrsna_");
/*      */   }
/*      */   
/*      */   public static void dtrsyl_(BytePtr trana, BytePtr tranb, IntPtr isgn, IntPtr m, IntPtr n, DoublePtr a, IntPtr lda, DoublePtr b, IntPtr ldb, DoublePtr c, IntPtr ldc, DoublePtr scale, IntPtr info) {
/*  740 */     throw new UnimplementedGnuApiMethod("dtrsyl_");
/*      */   }
/*      */   
/*      */   public static void dtrti2_(BytePtr uplo, BytePtr diag, IntPtr n, DoublePtr a, IntPtr lda, IntPtr info) {
/*  744 */     throw new UnimplementedGnuApiMethod("dtrti2_");
/*      */   }
/*      */   
/*      */   public static void dtrtri_(BytePtr uplo, BytePtr diag, IntPtr n, DoublePtr a, IntPtr lda, IntPtr info) {
/*  748 */     throw new UnimplementedGnuApiMethod("dtrtri_");
/*      */   }
/*      */   
/*      */   public static void dtrtrs_(BytePtr uplo, BytePtr trans, BytePtr diag, IntPtr n, IntPtr nrhs, DoublePtr a, IntPtr lda, DoublePtr b, IntPtr ldb, IntPtr info) {
/*  752 */     throw new UnimplementedGnuApiMethod("dtrtrs_");
/*      */   }
/*      */   
/*      */   public static void dtzrqf_(IntPtr m, IntPtr n, DoublePtr a, IntPtr lda, DoublePtr tau, IntPtr info) {
/*  756 */     throw new UnimplementedGnuApiMethod("dtzrqf_");
/*      */   }
/*      */   
/*      */   public static void dhgeqz_(BytePtr job, BytePtr compq, BytePtr compz, IntPtr n, IntPtr ILO, IntPtr IHI, DoublePtr a, IntPtr lda, DoublePtr b, IntPtr ldb, DoublePtr alphar, DoublePtr alphai, DoublePtr beta, DoublePtr q, IntPtr ldq, DoublePtr z, IntPtr ldz, DoublePtr work, IntPtr lwork, IntPtr info) {
/*  760 */     throw new UnimplementedGnuApiMethod("dhgeqz_");
/*      */   }
/*      */   
/*      */   public static void dhsein_(BytePtr side, BytePtr eigsrc, BytePtr initv, IntPtr select, IntPtr n, DoublePtr h, IntPtr ldh, DoublePtr wr, DoublePtr wi, DoublePtr vl, IntPtr ldvl, DoublePtr vr, IntPtr ldvr, IntPtr mm, IntPtr m, DoublePtr work, IntPtr ifaill, IntPtr ifailr, IntPtr info) {
/*  764 */     throw new UnimplementedGnuApiMethod("dhsein_");
/*      */   }
/*      */   
/*      */   public static void dhseqr_(BytePtr job, BytePtr compz, IntPtr n, IntPtr ilo, IntPtr ihi, DoublePtr h, IntPtr ldh, DoublePtr wr, DoublePtr wi, DoublePtr z, IntPtr ldz, DoublePtr work, IntPtr lwork, IntPtr info) {
/*  768 */     throw new UnimplementedGnuApiMethod("dhseqr_");
/*      */   }
/*      */   
/*      */   public static void dlabad_(DoublePtr small, DoublePtr large) {
/*  772 */     throw new UnimplementedGnuApiMethod("dlabad_");
/*      */   }
/*      */   
/*      */   public static void dlabrd_(IntPtr m, IntPtr n, IntPtr nb, DoublePtr a, IntPtr lda, DoublePtr d, DoublePtr e, DoublePtr tauq, DoublePtr taup, DoublePtr x, IntPtr ldx, DoublePtr y, IntPtr ldy) {
/*  776 */     throw new UnimplementedGnuApiMethod("dlabrd_");
/*      */   }
/*      */   
/*      */   public static void dlacon_(IntPtr n, DoublePtr v, DoublePtr x, IntPtr isgn, DoublePtr est, IntPtr kase) {
/*  780 */     throw new UnimplementedGnuApiMethod("dlacon_");
/*      */   }
/*      */   
/*      */   public static void dlacpy_(BytePtr uplo, IntPtr m, IntPtr n, DoublePtr a, IntPtr lda, DoublePtr b, IntPtr ldb) {
/*  784 */     throw new UnimplementedGnuApiMethod("dlacpy_");
/*      */   }
/*      */   
/*      */   public static void dladiv_(DoublePtr a, DoublePtr b, DoublePtr c, DoublePtr d, DoublePtr p, DoublePtr q) {
/*  788 */     throw new UnimplementedGnuApiMethod("dladiv_");
/*      */   }
/*      */   
/*      */   public static void dlae2_(DoublePtr a, DoublePtr b, DoublePtr c, DoublePtr rt1, DoublePtr rt2) {
/*  792 */     throw new UnimplementedGnuApiMethod("dlae2_");
/*      */   }
/*      */   
/*      */   public static void dlaebz_(IntPtr ijob, IntPtr nitmax, IntPtr n, IntPtr mmax, IntPtr minp, IntPtr nbmin, DoublePtr abstol, DoublePtr reltol, DoublePtr pivmin, DoublePtr d, DoublePtr e, DoublePtr e2, IntPtr nval, DoublePtr ab, DoublePtr c, IntPtr mout, IntPtr nab, DoublePtr work, IntPtr iwork, IntPtr info) {
/*  796 */     throw new UnimplementedGnuApiMethod("dlaebz_");
/*      */   }
/*      */   
/*      */   public static void dlaed0_(IntPtr icompq, IntPtr qsiz, IntPtr n, DoublePtr d, DoublePtr e, DoublePtr q, IntPtr ldq, DoublePtr qstore, IntPtr ldqs, DoublePtr work, IntPtr iwork, IntPtr info) {
/*  800 */     throw new UnimplementedGnuApiMethod("dlaed0_");
/*      */   }
/*      */   
/*      */   public static void dlaed1_(IntPtr n, DoublePtr d, DoublePtr q, IntPtr ldq, IntPtr indxq, DoublePtr rho, IntPtr cutpnt, DoublePtr work, IntPtr iwork, IntPtr info) {
/*  804 */     throw new UnimplementedGnuApiMethod("dlaed1_");
/*      */   }
/*      */   
/*      */   public static void dlaed2_(IntPtr k, IntPtr n, DoublePtr d, DoublePtr q, IntPtr ldq, IntPtr indxq, DoublePtr rho, DoublePtr z, DoublePtr dlamda, DoublePtr w, DoublePtr q2, IntPtr indx, IntPtr indxc, IntPtr indxp, IntPtr coltyp, IntPtr info) {
/*  808 */     throw new UnimplementedGnuApiMethod("dlaed2_");
/*      */   }
/*      */   
/*      */   public static void dlaed3_(IntPtr k, IntPtr n, IntPtr n1, DoublePtr d, DoublePtr q, IntPtr ldq, DoublePtr rho, DoublePtr dlamda, DoublePtr q2, IntPtr indx, IntPtr ctot, DoublePtr w, DoublePtr s, IntPtr info) {
/*  812 */     throw new UnimplementedGnuApiMethod("dlaed3_");
/*      */   }
/*      */   
/*      */   public static void dlaed4_(IntPtr n, IntPtr i, DoublePtr d, DoublePtr z, DoublePtr delta, DoublePtr rho, DoublePtr dlam, IntPtr info) {
/*  816 */     throw new UnimplementedGnuApiMethod("dlaed4_");
/*      */   }
/*      */   
/*      */   public static void dlaed5_(IntPtr i, DoublePtr d, DoublePtr z, DoublePtr delta, DoublePtr rho, DoublePtr dlam) {
/*  820 */     throw new UnimplementedGnuApiMethod("dlaed5_");
/*      */   }
/*      */   
/*      */   public static void dlaed6_(IntPtr kniter, IntPtr orgati, DoublePtr rho, DoublePtr d, DoublePtr z, DoublePtr finit, DoublePtr tau, IntPtr info) {
/*  824 */     throw new UnimplementedGnuApiMethod("dlaed6_");
/*      */   }
/*      */   
/*      */   public static void dlaed7_(IntPtr icompq, IntPtr n, IntPtr qsiz, IntPtr tlvls, IntPtr curlvl, IntPtr curpbm, DoublePtr d, DoublePtr q, IntPtr ldq, IntPtr indxq, DoublePtr rho, IntPtr cutpnt, DoublePtr qstore, DoublePtr qptr, IntPtr prmptr, IntPtr perm, IntPtr givptr, IntPtr givcol, DoublePtr givnum, DoublePtr work, IntPtr iwork, IntPtr info) {
/*  828 */     throw new UnimplementedGnuApiMethod("dlaed7_");
/*      */   }
/*      */   
/*      */   public static void dlaed8_(IntPtr icompq, IntPtr k, IntPtr n, IntPtr qsiz, DoublePtr d, DoublePtr q, IntPtr ldq, IntPtr indxq, DoublePtr rho, IntPtr cutpnt, DoublePtr z, DoublePtr dlamda, DoublePtr q2, IntPtr ldq2, DoublePtr w, IntPtr perm, IntPtr givptr, IntPtr givcol, DoublePtr givnum, IntPtr indxp, IntPtr indx, IntPtr info) {
/*  832 */     throw new UnimplementedGnuApiMethod("dlaed8_");
/*      */   }
/*      */   
/*      */   public static void dlaed9_(IntPtr k, IntPtr kstart, IntPtr kstop, IntPtr n, DoublePtr d, DoublePtr q, IntPtr ldq, DoublePtr rho, DoublePtr dlamda, DoublePtr w, DoublePtr s, IntPtr lds, IntPtr info) {
/*  836 */     throw new UnimplementedGnuApiMethod("dlaed9_");
/*      */   }
/*      */   
/*      */   public static void dlaeda_(IntPtr n, IntPtr tlvls, IntPtr curlvl, IntPtr curpbm, IntPtr prmptr, IntPtr perm, IntPtr givptr, IntPtr givcol, DoublePtr givnum, DoublePtr q, IntPtr qptr, DoublePtr z, DoublePtr ztemp, IntPtr info) {
/*  840 */     throw new UnimplementedGnuApiMethod("dlaeda_");
/*      */   }
/*      */   
/*      */   public static void dlaein_(IntPtr rightv, IntPtr noinit, IntPtr n, DoublePtr h, IntPtr ldh, DoublePtr wr, DoublePtr wi, DoublePtr vr, DoublePtr vi, DoublePtr b, IntPtr ldb, DoublePtr work, DoublePtr eps3, DoublePtr smlnum, DoublePtr bignum, IntPtr info) {
/*  844 */     throw new UnimplementedGnuApiMethod("dlaein_");
/*      */   }
/*      */   
/*      */   public static void dlaev2_(DoublePtr a, DoublePtr b, DoublePtr c, DoublePtr rt1, DoublePtr rt2, DoublePtr cs1, DoublePtr sn1) {
/*  848 */     throw new UnimplementedGnuApiMethod("dlaev2_");
/*      */   }
/*      */   
/*      */   public static void dlaexc_(IntPtr wantq, IntPtr n, DoublePtr t, IntPtr ldt, DoublePtr q, IntPtr ldq, IntPtr j1, IntPtr n1, IntPtr n2, DoublePtr work, IntPtr info) {
/*  852 */     throw new UnimplementedGnuApiMethod("dlaexc_");
/*      */   }
/*      */   
/*      */   public static void dlag2_(DoublePtr a, IntPtr lda, DoublePtr b, IntPtr ldb, DoublePtr safmin, DoublePtr scale1, DoublePtr scale2, DoublePtr wr1, DoublePtr wr2, DoublePtr wi) {
/*  856 */     throw new UnimplementedGnuApiMethod("dlag2_");
/*      */   }
/*      */   
/*      */   public static void dlags2_(IntPtr upper, DoublePtr a1, DoublePtr a2, DoublePtr a3, DoublePtr b1, DoublePtr b2, DoublePtr b3, DoublePtr csu, DoublePtr snu, DoublePtr csv, DoublePtr snv, DoublePtr csq, DoublePtr snq) {
/*  860 */     throw new UnimplementedGnuApiMethod("dlags2_");
/*      */   }
/*      */   
/*      */   public static void dlagtf_(IntPtr n, DoublePtr a, DoublePtr lambda, DoublePtr b, DoublePtr c, DoublePtr tol, DoublePtr d, IntPtr in, IntPtr info) {
/*  864 */     throw new UnimplementedGnuApiMethod("dlagtf_");
/*      */   }
/*      */   
/*      */   public static void dlagtm_(BytePtr trans, IntPtr n, IntPtr nrhs, DoublePtr alpha, DoublePtr dl, DoublePtr d, DoublePtr du, DoublePtr x, IntPtr ldx, DoublePtr beta, DoublePtr b, IntPtr ldb) {
/*  868 */     throw new UnimplementedGnuApiMethod("dlagtm_");
/*      */   }
/*      */   
/*      */   public static void dlagts_(IntPtr job, IntPtr n, DoublePtr a, DoublePtr b, DoublePtr c, DoublePtr d, IntPtr in, DoublePtr y, DoublePtr tol, IntPtr info) {
/*  872 */     throw new UnimplementedGnuApiMethod("dlagts_");
/*      */   }
/*      */   
/*      */   public static void dlahqr_(IntPtr wantt, IntPtr wantz, IntPtr n, IntPtr ilo, IntPtr ihi, DoublePtr H, IntPtr ldh, DoublePtr wr, DoublePtr wi, IntPtr iloz, IntPtr ihiz, DoublePtr z, IntPtr ldz, IntPtr info) {
/*  876 */     throw new UnimplementedGnuApiMethod("dlahqr_");
/*      */   }
/*      */   
/*      */   public static void dlahrd_(IntPtr n, IntPtr k, IntPtr nb, DoublePtr a, IntPtr lda, DoublePtr tau, DoublePtr t, IntPtr ldt, DoublePtr y, IntPtr ldy) {
/*  880 */     throw new UnimplementedGnuApiMethod("dlahrd_");
/*      */   }
/*      */   
/*      */   public static void dlaic1_(IntPtr job, IntPtr j, DoublePtr x, DoublePtr sest, DoublePtr w, DoublePtr gamma, DoublePtr sestpr, DoublePtr s, DoublePtr c) {
/*  884 */     throw new UnimplementedGnuApiMethod("dlaic1_");
/*      */   }
/*      */   
/*      */   public static void dlaln2_(IntPtr ltrans, IntPtr na, IntPtr nw, DoublePtr smin, DoublePtr ca, DoublePtr a, IntPtr lda, DoublePtr d1, DoublePtr d2, DoublePtr b, IntPtr ldb, DoublePtr wr, DoublePtr wi, DoublePtr x, IntPtr ldx, DoublePtr scale, DoublePtr xnorm, IntPtr info) {
/*  888 */     throw new UnimplementedGnuApiMethod("dlaln2_");
/*      */   }
/*      */   
/*      */   public static double dlamch_(BytePtr cmach) {
/*  892 */     throw new UnimplementedGnuApiMethod("dlamch_");
/*      */   }
/*      */   
/*      */   public static void dlamrg_(IntPtr n1, IntPtr n2, DoublePtr a, IntPtr dtrd1, IntPtr dtrd2, IntPtr index) {
/*  896 */     throw new UnimplementedGnuApiMethod("dlamrg_");
/*      */   }
/*      */   
/*      */   public static double dlangb_(BytePtr norm, IntPtr n, IntPtr kl, IntPtr ku, DoublePtr ab, IntPtr ldab, DoublePtr work) {
/*  900 */     throw new UnimplementedGnuApiMethod("dlangb_");
/*      */   }
/*      */   
/*      */   public static double dlange_(BytePtr norm, IntPtr m, IntPtr n, DoublePtr a, IntPtr lda, DoublePtr work) {
/*  904 */     throw new UnimplementedGnuApiMethod("dlange_");
/*      */   }
/*      */   
/*      */   public static double dlangt_(BytePtr norm, IntPtr n, DoublePtr dl, DoublePtr d, DoublePtr du) {
/*  908 */     throw new UnimplementedGnuApiMethod("dlangt_");
/*      */   }
/*      */   
/*      */   public static double dlanhs_(BytePtr norm, IntPtr n, DoublePtr a, IntPtr lda, DoublePtr work) {
/*  912 */     throw new UnimplementedGnuApiMethod("dlanhs_");
/*      */   }
/*      */   
/*      */   public static double dlansb_(BytePtr norm, BytePtr uplo, IntPtr n, IntPtr k, DoublePtr ab, IntPtr ldab, DoublePtr work) {
/*  916 */     throw new UnimplementedGnuApiMethod("dlansb_");
/*      */   }
/*      */   
/*      */   public static double dlansp_(BytePtr norm, BytePtr uplo, IntPtr n, DoublePtr ap, DoublePtr work) {
/*  920 */     throw new UnimplementedGnuApiMethod("dlansp_");
/*      */   }
/*      */   
/*      */   public static double dlanst_(BytePtr norm, IntPtr n, DoublePtr d, DoublePtr e) {
/*  924 */     throw new UnimplementedGnuApiMethod("dlanst_");
/*      */   }
/*      */   
/*      */   public static double dlansy_(BytePtr norm, BytePtr uplo, IntPtr n, DoublePtr a, IntPtr lda, DoublePtr work) {
/*  928 */     throw new UnimplementedGnuApiMethod("dlansy_");
/*      */   }
/*      */   
/*      */   public static double dlantb_(BytePtr norm, BytePtr uplo, BytePtr diag, IntPtr n, IntPtr k, DoublePtr ab, IntPtr ldab, DoublePtr work) {
/*  932 */     throw new UnimplementedGnuApiMethod("dlantb_");
/*      */   }
/*      */   
/*      */   public static double dlantp_(BytePtr norm, BytePtr uplo, BytePtr diag, IntPtr n, DoublePtr ap, DoublePtr work) {
/*  936 */     throw new UnimplementedGnuApiMethod("dlantp_");
/*      */   }
/*      */   
/*      */   public static double dlantr_(BytePtr norm, BytePtr uplo, BytePtr diag, IntPtr m, IntPtr n, DoublePtr a, IntPtr lda, DoublePtr work) {
/*  940 */     throw new UnimplementedGnuApiMethod("dlantr_");
/*      */   }
/*      */   
/*      */   public static void dlanv2_(DoublePtr a, DoublePtr b, DoublePtr c, DoublePtr d, DoublePtr rt1r, DoublePtr rt1i, DoublePtr rt2r, DoublePtr rt2i, DoublePtr cs, DoublePtr sn) {
/*  944 */     throw new UnimplementedGnuApiMethod("dlanv2_");
/*      */   }
/*      */   
/*      */   public static void dlapll_(IntPtr n, DoublePtr x, IntPtr incx, DoublePtr y, IntPtr incy, DoublePtr ssmin) {
/*  948 */     throw new UnimplementedGnuApiMethod("dlapll_");
/*      */   }
/*      */   
/*      */   public static void dlapmt_(IntPtr forwrd, IntPtr m, IntPtr n, DoublePtr x, IntPtr ldx, IntPtr k) {
/*  952 */     throw new UnimplementedGnuApiMethod("dlapmt_");
/*      */   }
/*      */   
/*      */   public static double dlapy2_(DoublePtr x, DoublePtr y) {
/*  956 */     throw new UnimplementedGnuApiMethod("dlapy2_");
/*      */   }
/*      */   
/*      */   public static double dlapy3_(DoublePtr x, DoublePtr y, DoublePtr z) {
/*  960 */     throw new UnimplementedGnuApiMethod("dlapy3_");
/*      */   }
/*      */   
/*      */   public static void dlaqgb_(IntPtr m, IntPtr n, IntPtr kl, IntPtr ku, DoublePtr ab, IntPtr ldab, DoublePtr r, DoublePtr c, DoublePtr rowcnd, DoublePtr colcnd, DoublePtr amax, BytePtr equed) {
/*  964 */     throw new UnimplementedGnuApiMethod("dlaqgb_");
/*      */   }
/*      */   
/*      */   public static void dlaqge_(IntPtr m, IntPtr n, DoublePtr a, IntPtr lda, DoublePtr r, DoublePtr c, DoublePtr rowcnd, DoublePtr colcnd, DoublePtr amax, BytePtr equed) {
/*  968 */     throw new UnimplementedGnuApiMethod("dlaqge_");
/*      */   }
/*      */   
/*      */   public static void dlaqsb_(BytePtr uplo, IntPtr n, IntPtr kd, DoublePtr ab, IntPtr ldab, DoublePtr s, DoublePtr scond, DoublePtr amax, BytePtr equed) {
/*  972 */     throw new UnimplementedGnuApiMethod("dlaqsb_");
/*      */   }
/*      */   
/*      */   public static void dlaqsp_(BytePtr uplo, IntPtr n, DoublePtr ap, DoublePtr s, DoublePtr scond, DoublePtr amax, IntPtr equed) {
/*  976 */     throw new UnimplementedGnuApiMethod("dlaqsp_");
/*      */   }
/*      */   
/*      */   public static void dlaqsy_(BytePtr uplo, IntPtr n, DoublePtr a, IntPtr lda, DoublePtr s, DoublePtr scond, DoublePtr amax, IntPtr equed) {
/*  980 */     throw new UnimplementedGnuApiMethod("dlaqsy_");
/*      */   }
/*      */   
/*      */   public static void dlaqtr_(IntPtr ltran, IntPtr lreal, IntPtr n, DoublePtr t, IntPtr ldt, DoublePtr b, DoublePtr w, DoublePtr scale, DoublePtr x, DoublePtr work, IntPtr info) {
/*  984 */     throw new UnimplementedGnuApiMethod("dlaqtr_");
/*      */   }
/*      */   
/*      */   public static void dlar2v_(IntPtr n, DoublePtr x, DoublePtr y, DoublePtr z, IntPtr incx, DoublePtr c, DoublePtr s, IntPtr incc) {
/*  988 */     throw new UnimplementedGnuApiMethod("dlar2v_");
/*      */   }
/*      */   
/*      */   public static void dlarf_(BytePtr side, IntPtr m, IntPtr n, DoublePtr v, IntPtr incv, DoublePtr tau, DoublePtr c, IntPtr ldc, DoublePtr work) {
/*  992 */     throw new UnimplementedGnuApiMethod("dlarf_");
/*      */   }
/*      */   
/*      */   public static void dlarfb_(BytePtr side, BytePtr trans, BytePtr direct, BytePtr storev, IntPtr m, IntPtr n, IntPtr k, DoublePtr v, IntPtr ldv, DoublePtr t, IntPtr ldt, DoublePtr c, IntPtr ldc, DoublePtr work, IntPtr lwork) {
/*  996 */     throw new UnimplementedGnuApiMethod("dlarfb_");
/*      */   }
/*      */   
/*      */   public static void dlarfg_(IntPtr n, DoublePtr alpha, DoublePtr x, IntPtr incx, DoublePtr tau) {
/* 1000 */     throw new UnimplementedGnuApiMethod("dlarfg_");
/*      */   }
/*      */   
/*      */   public static void dlarft_(BytePtr direct, BytePtr storev, IntPtr n, IntPtr k, DoublePtr v, IntPtr ldv, DoublePtr tau, DoublePtr t, IntPtr ldt) {
/* 1004 */     throw new UnimplementedGnuApiMethod("dlarft_");
/*      */   }
/*      */   
/*      */   public static void dlarfx_(BytePtr side, IntPtr m, IntPtr n, DoublePtr v, DoublePtr tau, DoublePtr c, IntPtr ldc, DoublePtr work) {
/* 1008 */     throw new UnimplementedGnuApiMethod("dlarfx_");
/*      */   }
/*      */   
/*      */   public static void dlargv_(IntPtr n, DoublePtr x, IntPtr incx, DoublePtr y, IntPtr incy, DoublePtr c, IntPtr incc) {
/* 1012 */     throw new UnimplementedGnuApiMethod("dlargv_");
/*      */   }
/*      */   
/*      */   public static void dlarnv_(IntPtr idist, IntPtr iseed, IntPtr n, DoublePtr x) {
/* 1016 */     throw new UnimplementedGnuApiMethod("dlarnv_");
/*      */   }
/*      */   
/*      */   public static void dlartg_(DoublePtr f, DoublePtr g, DoublePtr cs, DoublePtr sn, DoublePtr r) {
/* 1020 */     throw new UnimplementedGnuApiMethod("dlartg_");
/*      */   }
/*      */   
/*      */   public static void dlartv_(IntPtr n, DoublePtr x, IntPtr incx, DoublePtr y, IntPtr incy, DoublePtr c, DoublePtr s, IntPtr incc) {
/* 1024 */     throw new UnimplementedGnuApiMethod("dlartv_");
/*      */   }
/*      */   
/*      */   public static void dlaruv_(IntPtr iseed, IntPtr n, DoublePtr x) {
/* 1028 */     throw new UnimplementedGnuApiMethod("dlaruv_");
/*      */   }
/*      */   
/*      */   public static void dlas2_(DoublePtr f, DoublePtr g, DoublePtr h, DoublePtr ssmin, DoublePtr ssmax) {
/* 1032 */     throw new UnimplementedGnuApiMethod("dlas2_");
/*      */   }
/*      */   
/*      */   public static void dlascl_(BytePtr type, IntPtr kl, IntPtr ku, DoublePtr cfrom, DoublePtr cto, IntPtr m, IntPtr n, DoublePtr a, IntPtr lda, IntPtr info) {
/* 1036 */     throw new UnimplementedGnuApiMethod("dlascl_");
/*      */   }
/*      */   
/*      */   public static void dlaset_(BytePtr uplo, IntPtr m, IntPtr n, DoublePtr alpha, DoublePtr beta, DoublePtr a, IntPtr lda) {
/* 1040 */     throw new UnimplementedGnuApiMethod("dlaset_");
/*      */   }
/*      */   
/*      */   public static void dlasq1_(IntPtr n, DoublePtr d, DoublePtr e, DoublePtr work, IntPtr info) {
/* 1044 */     throw new UnimplementedGnuApiMethod("dlasq1_");
/*      */   }
/*      */   
/*      */   public static void dlasq2_(IntPtr m, DoublePtr q, DoublePtr e, DoublePtr qq, DoublePtr ee, DoublePtr eps, DoublePtr tol2, DoublePtr small2, DoublePtr sup, IntPtr kend, IntPtr info) {
/* 1048 */     throw new UnimplementedGnuApiMethod("dlasq2_");
/*      */   }
/*      */   
/*      */   public static void dlasq3_(IntPtr n, DoublePtr q, DoublePtr e, DoublePtr qq, DoublePtr ee, DoublePtr sup, DoublePtr sigma, IntPtr kend, IntPtr off, IntPtr iphase, IntPtr iconv, DoublePtr eps, DoublePtr tol2, DoublePtr small2) {
/* 1052 */     throw new UnimplementedGnuApiMethod("dlasq3_");
/*      */   }
/*      */   
/*      */   public static void dlasq4_(IntPtr n, DoublePtr q, DoublePtr e, DoublePtr tau, DoublePtr sup) {
/* 1056 */     throw new UnimplementedGnuApiMethod("dlasq4_");
/*      */   }
/*      */   
/*      */   public static void dlasr_(BytePtr side, BytePtr pivot, BytePtr direct, IntPtr m, IntPtr n, DoublePtr c, DoublePtr s, DoublePtr a, IntPtr lda) {
/* 1060 */     throw new UnimplementedGnuApiMethod("dlasr_");
/*      */   }
/*      */   
/*      */   public static void dlasrt_(BytePtr id, IntPtr n, DoublePtr d, IntPtr info) {
/* 1064 */     throw new UnimplementedGnuApiMethod("dlasrt_");
/*      */   }
/*      */   
/*      */   public static void dlassq_(IntPtr n, DoublePtr x, IntPtr incx, DoublePtr scale, DoublePtr sumsq) {
/* 1068 */     throw new UnimplementedGnuApiMethod("dlassq_");
/*      */   }
/*      */   
/*      */   public static void dlasv2_(DoublePtr f, DoublePtr g, DoublePtr h, DoublePtr ssmin, DoublePtr ssmax, DoublePtr snr, DoublePtr csr, DoublePtr snl, DoublePtr csl) {
/* 1072 */     throw new UnimplementedGnuApiMethod("dlasv2_");
/*      */   }
/*      */   
/*      */   public static void dlaswp_(IntPtr n, DoublePtr a, IntPtr lda, IntPtr k1, IntPtr k2, IntPtr ipiv, IntPtr incx) {
/* 1076 */     throw new UnimplementedGnuApiMethod("dlaswp_");
/*      */   }
/*      */   
/*      */   public static void dlasy2_(IntPtr ltranl, IntPtr ltranr, IntPtr isgn, IntPtr n1, IntPtr n2, DoublePtr tl, IntPtr ldtl, DoublePtr tr, IntPtr ldtr, DoublePtr b, IntPtr ldb, DoublePtr scale, DoublePtr x, IntPtr ldx, DoublePtr xnorm, IntPtr info) {
/* 1080 */     throw new UnimplementedGnuApiMethod("dlasy2_");
/*      */   }
/*      */   
/*      */   public static void dlasyf_(BytePtr uplo, IntPtr n, IntPtr nb, IntPtr kb, DoublePtr a, IntPtr lda, IntPtr ipiv, DoublePtr w, IntPtr ldw, IntPtr info) {
/* 1084 */     throw new UnimplementedGnuApiMethod("dlasyf_");
/*      */   }
/*      */   
/*      */   public static void dlatbs_(BytePtr uplo, BytePtr trans, BytePtr diag, BytePtr normin, IntPtr n, IntPtr kd, DoublePtr ab, IntPtr ldab, DoublePtr x, DoublePtr scale, DoublePtr cnorm, IntPtr info) {
/* 1088 */     throw new UnimplementedGnuApiMethod("dlatbs_");
/*      */   }
/*      */   
/*      */   public static void dlatps_(BytePtr uplo, BytePtr trans, BytePtr diag, BytePtr normin, IntPtr n, DoublePtr ap, DoublePtr x, DoublePtr scale, DoublePtr cnorm, IntPtr info) {
/* 1092 */     throw new UnimplementedGnuApiMethod("dlatps_");
/*      */   }
/*      */   
/*      */   public static void dlatrd_(BytePtr uplo, IntPtr n, IntPtr nb, DoublePtr a, IntPtr lda, DoublePtr e, DoublePtr tau, DoublePtr w, IntPtr ldw) {
/* 1096 */     throw new UnimplementedGnuApiMethod("dlatrd_");
/*      */   }
/*      */   
/*      */   public static void dlatrs_(BytePtr uplo, BytePtr trans, BytePtr diag, BytePtr normin, IntPtr n, DoublePtr a, IntPtr lda, DoublePtr x, DoublePtr scale, DoublePtr cnorm, IntPtr info) {
/* 1100 */     throw new UnimplementedGnuApiMethod("dlatrs_");
/*      */   }
/*      */   
/*      */   public static void dlatzm_(BytePtr side, IntPtr m, IntPtr n, DoublePtr v, IntPtr incv, DoublePtr tau, DoublePtr c1, DoublePtr c2, IntPtr ldc, DoublePtr work) {
/* 1104 */     throw new UnimplementedGnuApiMethod("dlatzm_");
/*      */   }
/*      */   
/*      */   public static void dlauu2_(BytePtr uplo, IntPtr n, DoublePtr a, IntPtr lda, IntPtr info) {
/* 1108 */     throw new UnimplementedGnuApiMethod("dlauu2_");
/*      */   }
/*      */   
/*      */   public static void dlauum_(BytePtr uplo, IntPtr n, DoublePtr a, IntPtr lda, IntPtr info) {
/* 1112 */     throw new UnimplementedGnuApiMethod("dlauum_");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void dbdsdc_(BytePtr uplo, BytePtr compq, IntPtr n, DoublePtr d, DoublePtr e, DoublePtr u, IntPtr ldu, DoublePtr vt, IntPtr ldvt, DoublePtr q, IntPtr iq, DoublePtr work, IntPtr iwork, IntPtr info) {
/* 1140 */     throw new UnimplementedGnuApiMethod("dbdsdc_");
/*      */   }
/*      */   
/*      */   public static void dgegs_(BytePtr jobvsl, BytePtr jobvsr, IntPtr n, DoublePtr a, IntPtr lda, DoublePtr b, IntPtr ldb, DoublePtr alphar, DoublePtr alphai, DoublePtr beta, DoublePtr vsl, IntPtr ldvsl, DoublePtr vsr, IntPtr ldvsr, DoublePtr work, IntPtr lwork, IntPtr info) {
/* 1144 */     throw new UnimplementedGnuApiMethod("dgegs_");
/*      */   }
/*      */   
/*      */   public static void dgelsd_(IntPtr m, IntPtr n, IntPtr nrhs, DoublePtr a, IntPtr lda, DoublePtr b, IntPtr ldb, DoublePtr s, DoublePtr rcond, IntPtr rank, DoublePtr work, IntPtr lwork, IntPtr iwork, IntPtr info) {
/* 1148 */     throw new UnimplementedGnuApiMethod("dgelsd_");
/*      */   }
/*      */   
/*      */   public static void dgelsx_(IntPtr m, IntPtr n, IntPtr nrhs, DoublePtr a, IntPtr lda, DoublePtr b, IntPtr ldb, IntPtr jpvt, DoublePtr rcond, IntPtr rank, DoublePtr work, IntPtr info) {
/* 1152 */     throw new UnimplementedGnuApiMethod("dgelsx_");
/*      */   }
/*      */   
/*      */   public static void dgesc2_(IntPtr n, DoublePtr a, IntPtr lda, DoublePtr rhs, IntPtr ipiv, IntPtr jpiv, DoublePtr scale) {
/* 1156 */     throw new UnimplementedGnuApiMethod("dgesc2_");
/*      */   }
/*      */   
/*      */   public static void dgesdd_(BytePtr jobz, IntPtr m, IntPtr n, DoublePtr a, IntPtr lda, DoublePtr s, DoublePtr u, IntPtr ldu, DoublePtr vt, IntPtr ldvt, DoublePtr work, IntPtr lwork, IntPtr iwork, IntPtr info) {
/* 1160 */     throw new UnimplementedGnuApiMethod("dgesdd_");
/*      */   }
/*      */   
/*      */   public static void dgetc2_(IntPtr n, DoublePtr a, IntPtr lda, IntPtr ipiv, IntPtr jpiv, IntPtr info) {
/* 1164 */     throw new UnimplementedGnuApiMethod("dgetc2_");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static void dggev_(BytePtr jobvl, BytePtr jobvr, IntPtr n, DoublePtr a, IntPtr lda, DoublePtr b, IntPtr ldb, DoublePtr alphar, DoublePtr alphai, DoublePtr beta, DoublePtr vl, IntPtr ldvl, DoublePtr vr, IntPtr ldvr, DoublePtr work, IntPtr lwork, IntPtr info) {
/* 1170 */     throw new UnimplementedGnuApiMethod("dggev_");
/*      */   }
/*      */   
/*      */   public static void dggevx_(BytePtr balanc, BytePtr jobvl, BytePtr jobvr, BytePtr sense, IntPtr n, DoublePtr a, IntPtr lda, DoublePtr b, IntPtr ldb, DoublePtr alphar, DoublePtr alphai, DoublePtr beta, DoublePtr vl, IntPtr ldvl, DoublePtr vr, IntPtr ldvr, IntPtr ilo, IntPtr ihi, DoublePtr lscale, DoublePtr rscale, DoublePtr abnrm, DoublePtr bbnrm, DoublePtr rconde, DoublePtr rcondv, DoublePtr work, IntPtr lwork, IntPtr iwork, IntPtr bwork, IntPtr info) {
/* 1174 */     throw new UnimplementedGnuApiMethod("dggevx_");
/*      */   }
/*      */   
/*      */   public static void dggsvp_(BytePtr jobu, BytePtr jobv, BytePtr jobq, IntPtr m, IntPtr p, IntPtr n, DoublePtr a, IntPtr lda, DoublePtr b, IntPtr ldb, DoublePtr tola, DoublePtr tolb, IntPtr k, IntPtr l, DoublePtr u, IntPtr ldu, DoublePtr v, IntPtr ldv, DoublePtr q, IntPtr ldq, IntPtr iwork, DoublePtr tau, DoublePtr work, IntPtr info) {
/* 1178 */     throw new UnimplementedGnuApiMethod("dggsvp_");
/*      */   }
/*      */   
/*      */   public static void dgtts2_(IntPtr itrans, IntPtr n, IntPtr nrhs, DoublePtr dl, DoublePtr d, DoublePtr du, DoublePtr du2, IntPtr ipiv, DoublePtr b, IntPtr ldb) {
/* 1182 */     throw new UnimplementedGnuApiMethod("dgtts2_");
/*      */   }
/*      */   
/*      */   public static void dlagv2_(DoublePtr a, IntPtr lda, DoublePtr b, IntPtr ldb, DoublePtr alphar, DoublePtr alphai, DoublePtr beta, DoublePtr csl, DoublePtr snl, DoublePtr csr, DoublePtr snr) {
/* 1186 */     throw new UnimplementedGnuApiMethod("dlagv2_");
/*      */   }
/*      */   
/*      */   public static void dlals0_(IntPtr icompq, IntPtr nl, IntPtr nr, IntPtr sqre, IntPtr nrhs, DoublePtr b, IntPtr ldb, DoublePtr bx, IntPtr ldbx, IntPtr perm, IntPtr givptr, IntPtr givcol, IntPtr ldgcol, DoublePtr givnum, IntPtr ldgnum, DoublePtr poles, DoublePtr difl, DoublePtr difr, DoublePtr z, IntPtr k, DoublePtr c, DoublePtr s, DoublePtr work, IntPtr info) {
/* 1190 */     throw new UnimplementedGnuApiMethod("dlals0_");
/*      */   }
/*      */   
/*      */   public static void dlalsa_(IntPtr icompq, IntPtr smlsiz, IntPtr n, IntPtr nrhs, DoublePtr b, IntPtr ldb, DoublePtr bx, IntPtr ldbx, DoublePtr u, IntPtr ldu, DoublePtr vt, IntPtr k, DoublePtr difl, DoublePtr difr, DoublePtr z, DoublePtr poles, IntPtr givptr, IntPtr givcol, IntPtr ldgcol, IntPtr perm, DoublePtr givnum, DoublePtr c, DoublePtr s, DoublePtr work, IntPtr iwork, IntPtr info) {
/* 1194 */     throw new UnimplementedGnuApiMethod("dlalsa_");
/*      */   }
/*      */   
/*      */   public static void dlalsd_(BytePtr uplo, IntPtr smlsiz, IntPtr n, IntPtr nrhs, DoublePtr d, DoublePtr e, DoublePtr b, IntPtr ldb, DoublePtr rcond, IntPtr rank, DoublePtr work, IntPtr iwork, IntPtr info) {
/* 1198 */     throw new UnimplementedGnuApiMethod("dlalsd_");
/*      */   }
/*      */   
/*      */   public static void dlamc1_(IntPtr beta, IntPtr t, IntPtr rnd, IntPtr ieee1) {
/* 1202 */     throw new UnimplementedGnuApiMethod("dlamc1_");
/*      */   }
/*      */   
/*      */   public static void dlamc2_(IntPtr beta, IntPtr t, IntPtr rnd, DoublePtr eps, IntPtr emin, DoublePtr rmin, IntPtr emax, DoublePtr rmax) {
/* 1206 */     throw new UnimplementedGnuApiMethod("dlamc2_");
/*      */   }
/*      */   
/*      */   public static double dlamc3_(DoublePtr a, DoublePtr b) {
/* 1210 */     throw new UnimplementedGnuApiMethod("dlamc3_");
/*      */   }
/*      */   
/*      */   public static void dlamc4_(IntPtr emin, DoublePtr start, IntPtr base) {
/* 1214 */     throw new UnimplementedGnuApiMethod("dlamc4_");
/*      */   }
/*      */   
/*      */   public static void dlamc5_(IntPtr beta, IntPtr p, IntPtr emin, IntPtr ieee, IntPtr emax, DoublePtr rmax) {
/* 1218 */     throw new UnimplementedGnuApiMethod("dlamc5_");
/*      */   }
/*      */   
/*      */   public static void dlaqp2_(IntPtr m, IntPtr n, IntPtr offset, DoublePtr a, IntPtr lda, IntPtr jpvt, DoublePtr tau, DoublePtr vn1, DoublePtr vn2, DoublePtr work) {
/* 1222 */     throw new UnimplementedGnuApiMethod("dlaqp2_");
/*      */   }
/*      */   
/*      */   public static void dlaqps_(IntPtr m, IntPtr n, IntPtr offset, IntPtr nb, IntPtr kb, DoublePtr a, IntPtr lda, IntPtr jpvt, DoublePtr tau, DoublePtr vn1, DoublePtr vn2, DoublePtr auxv, DoublePtr f, IntPtr ldf) {
/* 1226 */     throw new UnimplementedGnuApiMethod("dlaqps_");
/*      */   }
/*      */   
/*      */   public static void dlar1v_(IntPtr n, IntPtr b1, IntPtr bn, DoublePtr sigma, DoublePtr d, DoublePtr l, DoublePtr ld, DoublePtr lld, DoublePtr gersch, DoublePtr z, DoublePtr ztz, DoublePtr mingma, IntPtr r, IntPtr isuppz, DoublePtr work) {
/* 1230 */     throw new UnimplementedGnuApiMethod("dlar1v_");
/*      */   }
/*      */   
/*      */   public static void dlarrb_(IntPtr n, DoublePtr d, DoublePtr l, DoublePtr ld, DoublePtr lld, IntPtr ifirst, IntPtr ilast, DoublePtr sigma, DoublePtr reltol, DoublePtr w, DoublePtr wgap, DoublePtr werr, DoublePtr work, IntPtr iwork, IntPtr info) {
/* 1234 */     throw new UnimplementedGnuApiMethod("dlarrb_");
/*      */   }
/*      */   
/*      */   public static void dlarre_(IntPtr n, DoublePtr d, DoublePtr e, DoublePtr tol, IntPtr nsplit, IntPtr isplit, IntPtr m, DoublePtr w, DoublePtr woff, DoublePtr gersch, DoublePtr work, IntPtr info) {
/* 1238 */     throw new UnimplementedGnuApiMethod("dlarre_");
/*      */   }
/*      */   
/*      */   public static void dlarrf_(IntPtr n, DoublePtr d, DoublePtr l, DoublePtr ld, DoublePtr lld, IntPtr ifirst, IntPtr ilast, DoublePtr w, DoublePtr dplus, DoublePtr lplus, DoublePtr work, IntPtr iwork, IntPtr info) {
/* 1242 */     throw new UnimplementedGnuApiMethod("dlarrf_");
/*      */   }
/*      */   
/*      */   public static void dlarrv_(IntPtr n, DoublePtr d, DoublePtr l, IntPtr isplit, IntPtr m, DoublePtr w, IntPtr iblock, DoublePtr gersch, DoublePtr tol, DoublePtr z, IntPtr ldz, IntPtr isuppz, DoublePtr work, IntPtr iwork, IntPtr info) {
/* 1246 */     throw new UnimplementedGnuApiMethod("dlarrv_");
/*      */   }
/*      */   
/*      */   public static void dlarz_(BytePtr side, IntPtr m, IntPtr n, IntPtr l, DoublePtr v, IntPtr incv, DoublePtr tau, DoublePtr c, IntPtr ldc, DoublePtr work) {
/* 1250 */     throw new UnimplementedGnuApiMethod("dlarz_");
/*      */   }
/*      */   
/*      */   public static void dlarzb_(BytePtr side, BytePtr trans, BytePtr direct, BytePtr storev, IntPtr m, IntPtr n, IntPtr k, IntPtr l, DoublePtr v, IntPtr ldv, DoublePtr t, IntPtr ldt, DoublePtr c, IntPtr ldc, DoublePtr work, IntPtr ldwork) {
/* 1254 */     throw new UnimplementedGnuApiMethod("dlarzb_");
/*      */   }
/*      */   
/*      */   public static void dlarzt_(BytePtr direct, BytePtr storev, IntPtr n, IntPtr k, DoublePtr v, IntPtr ldv, DoublePtr tau, DoublePtr t, IntPtr ldt) {
/* 1258 */     throw new UnimplementedGnuApiMethod("dlarzt_");
/*      */   }
/*      */   
/*      */   public static void dlasd0_(IntPtr n, IntPtr sqre, DoublePtr d, DoublePtr e, DoublePtr u, IntPtr ldu, DoublePtr vt, IntPtr ldvt, IntPtr smlsiz, IntPtr iwork, DoublePtr work, IntPtr info) {
/* 1262 */     throw new UnimplementedGnuApiMethod("dlasd0_");
/*      */   }
/*      */   
/*      */   public static void dlasd1_(IntPtr nl, IntPtr nr, IntPtr sqre, DoublePtr d, DoublePtr alpha, DoublePtr beta, DoublePtr u, IntPtr ldu, DoublePtr vt, IntPtr ldvt, IntPtr idxq, IntPtr iwork, DoublePtr work, IntPtr info) {
/* 1266 */     throw new UnimplementedGnuApiMethod("dlasd1_");
/*      */   }
/*      */   
/*      */   public static void dlasd2_(IntPtr nl, IntPtr nr, IntPtr sqre, IntPtr k, DoublePtr d, DoublePtr z, DoublePtr alpha, DoublePtr beta, DoublePtr u, IntPtr ldu, DoublePtr vt, IntPtr ldvt, DoublePtr dsigma, DoublePtr u2, IntPtr ldu2, DoublePtr vt2, IntPtr ldvt2, IntPtr idxp, IntPtr idx, IntPtr idxc, IntPtr idxq, IntPtr coltyp, IntPtr info) {
/* 1270 */     throw new UnimplementedGnuApiMethod("dlasd2_");
/*      */   }
/*      */   
/*      */   public static void dlasd3_(IntPtr nl, IntPtr nr, IntPtr sqre, IntPtr k, DoublePtr d, DoublePtr q, IntPtr ldq, DoublePtr dsigma, DoublePtr u, IntPtr ldu, DoublePtr u2, IntPtr ldu2, DoublePtr vt, IntPtr ldvt, DoublePtr vt2, IntPtr ldvt2, IntPtr idxc, IntPtr ctot, DoublePtr z, IntPtr info) {
/* 1274 */     throw new UnimplementedGnuApiMethod("dlasd3_");
/*      */   }
/*      */   
/*      */   public static void dlasd4_(IntPtr n, IntPtr i, DoublePtr d, DoublePtr z, DoublePtr delta, DoublePtr rho, DoublePtr sigma, DoublePtr work, IntPtr info) {
/* 1278 */     throw new UnimplementedGnuApiMethod("dlasd4_");
/*      */   }
/*      */   
/*      */   public static void dlasd5_(IntPtr i, DoublePtr d, DoublePtr z, DoublePtr delta, DoublePtr rho, DoublePtr dsigma, DoublePtr work) {
/* 1282 */     throw new UnimplementedGnuApiMethod("dlasd5_");
/*      */   }
/*      */   
/*      */   public static void dlasd6_(IntPtr icompq, IntPtr nl, IntPtr nr, IntPtr sqre, DoublePtr d, DoublePtr vf, DoublePtr vl, DoublePtr alpha, DoublePtr beta, IntPtr idxq, IntPtr perm, IntPtr givptr, IntPtr givcol, IntPtr ldgcol, DoublePtr givnum, IntPtr ldgnum, DoublePtr poles, DoublePtr difl, DoublePtr difr, DoublePtr z, IntPtr k, DoublePtr c, DoublePtr s, DoublePtr work, IntPtr iwork, IntPtr info) {
/* 1286 */     throw new UnimplementedGnuApiMethod("dlasd6_");
/*      */   }
/*      */   
/*      */   public static void dlasd7_(IntPtr icompq, IntPtr nl, IntPtr nr, IntPtr sqre, IntPtr k, DoublePtr d, DoublePtr z, DoublePtr zw, DoublePtr vf, DoublePtr vfw, DoublePtr vl, DoublePtr vlw, DoublePtr alpha, DoublePtr beta, DoublePtr dsigma, IntPtr idx, IntPtr idxp, IntPtr idxq, IntPtr perm, IntPtr givptr, IntPtr givcol, IntPtr ldgcol, DoublePtr givnum, IntPtr ldgnum, DoublePtr c, DoublePtr s, IntPtr info) {
/* 1290 */     throw new UnimplementedGnuApiMethod("dlasd7_");
/*      */   }
/*      */   
/*      */   public static void dlasd8_(IntPtr icompq, IntPtr k, DoublePtr d, DoublePtr z, DoublePtr vf, DoublePtr vl, DoublePtr difl, DoublePtr difr, IntPtr lddifr, DoublePtr dsigma, DoublePtr work, IntPtr info) {
/* 1294 */     throw new UnimplementedGnuApiMethod("dlasd8_");
/*      */   }
/*      */   
/*      */   public static void dlasd9_(IntPtr icompq, IntPtr ldu, IntPtr k, DoublePtr d, DoublePtr z, DoublePtr vf, DoublePtr vl, DoublePtr difl, DoublePtr difr, DoublePtr dsigma, DoublePtr work, IntPtr info) {
/* 1298 */     throw new UnimplementedGnuApiMethod("dlasd9_");
/*      */   }
/*      */   
/*      */   public static void dlasda_(IntPtr icompq, IntPtr smlsiz, IntPtr n, IntPtr sqre, DoublePtr d, DoublePtr e, DoublePtr u, IntPtr ldu, DoublePtr vt, IntPtr k, DoublePtr difl, DoublePtr difr, DoublePtr z, DoublePtr poles, IntPtr givptr, IntPtr givcol, IntPtr ldgcol, IntPtr perm, DoublePtr givnum, DoublePtr c, DoublePtr s, DoublePtr work, IntPtr iwork, IntPtr info) {
/* 1302 */     throw new UnimplementedGnuApiMethod("dlasda_");
/*      */   }
/*      */   
/*      */   public static void dlasdq_(BytePtr uplo, IntPtr sqre, IntPtr n, IntPtr ncvt, IntPtr nru, IntPtr ncc, DoublePtr d, DoublePtr e, DoublePtr vt, IntPtr ldvt, DoublePtr u, IntPtr ldu, DoublePtr c, IntPtr ldc, DoublePtr work, IntPtr info) {
/* 1306 */     throw new UnimplementedGnuApiMethod("dlasdq_");
/*      */   }
/*      */   
/*      */   public static void dlasdt_(IntPtr n, IntPtr lvl, IntPtr nd, IntPtr inode, IntPtr ndiml, IntPtr ndimr, IntPtr msub) {
/* 1310 */     throw new UnimplementedGnuApiMethod("dlasdt_");
/*      */   }
/*      */   
/*      */   public static void dlasq5_(IntPtr i0, IntPtr n0, DoublePtr z, IntPtr pp, DoublePtr tau, DoublePtr dmin, DoublePtr dmin1, DoublePtr dmin2, DoublePtr dn, DoublePtr dnm1, DoublePtr dnm2, IntPtr ieee) {
/* 1314 */     throw new UnimplementedGnuApiMethod("dlasq5_");
/*      */   }
/*      */   
/*      */   public static void dlasq6_(IntPtr i0, IntPtr n0, DoublePtr z, IntPtr pp, DoublePtr dmin, DoublePtr dmin1, DoublePtr dmin2, DoublePtr dn, DoublePtr dnm1, DoublePtr dnm2) {
/* 1318 */     throw new UnimplementedGnuApiMethod("dlasq6_");
/*      */   }
/*      */   
/*      */   public static void dlatdf_(IntPtr ijob, IntPtr n, DoublePtr z, IntPtr ldz, DoublePtr rhs, DoublePtr rdsum, DoublePtr rdscal, IntPtr ipiv, IntPtr jpiv) {
/* 1322 */     throw new UnimplementedGnuApiMethod("dlatdf_");
/*      */   }
/*      */   
/*      */   public static void dlatrz_(IntPtr m, IntPtr n, IntPtr l, DoublePtr a, IntPtr lda, DoublePtr tau, DoublePtr work) {
/* 1326 */     throw new UnimplementedGnuApiMethod("dlatrz_");
/*      */   }
/*      */   
/*      */   public static void dormr3_(BytePtr side, BytePtr trans, IntPtr m, IntPtr n, IntPtr k, IntPtr l, DoublePtr a, IntPtr lda, DoublePtr tau, DoublePtr c, IntPtr ldc, DoublePtr work, IntPtr info) {
/* 1330 */     throw new UnimplementedGnuApiMethod("dormr3_");
/*      */   }
/*      */   
/*      */   public static void dormrz_(BytePtr side, BytePtr trans, IntPtr m, IntPtr n, IntPtr k, IntPtr l, DoublePtr a, IntPtr lda, DoublePtr tau, DoublePtr c, IntPtr ldc, DoublePtr work, IntPtr lwork, IntPtr info) {
/* 1334 */     throw new UnimplementedGnuApiMethod("dormrz_");
/*      */   }
/*      */   
/*      */   public static void dptts2_(IntPtr n, IntPtr nrhs, DoublePtr d, DoublePtr e, DoublePtr b, IntPtr ldb) {
/* 1338 */     throw new UnimplementedGnuApiMethod("dptts2_");
/*      */   }
/*      */   
/*      */   public static void dsbgvd_(BytePtr jobz, BytePtr uplo, IntPtr n, IntPtr ka, IntPtr kb, DoublePtr ab, IntPtr ldab, DoublePtr bb, IntPtr ldbb, DoublePtr w, DoublePtr z, IntPtr ldz, DoublePtr work, IntPtr lwork, IntPtr iwork, IntPtr liwork, IntPtr info) {
/* 1342 */     throw new UnimplementedGnuApiMethod("dsbgvd_");
/*      */   }
/*      */   
/*      */   public static void dsbgvx_(BytePtr jobz, BytePtr range, BytePtr uplo, IntPtr n, IntPtr ka, IntPtr kb, DoublePtr ab, IntPtr ldab, DoublePtr bb, IntPtr ldbb, DoublePtr q, IntPtr ldq, DoublePtr vl, DoublePtr vu, IntPtr il, IntPtr iu, DoublePtr abstol, IntPtr m, DoublePtr w, DoublePtr z, IntPtr ldz, DoublePtr work, IntPtr iwork, IntPtr ifail, IntPtr info) {
/* 1346 */     throw new UnimplementedGnuApiMethod("dsbgvx_");
/*      */   }
/*      */   
/*      */   public static void dspgvd_(IntPtr itype, BytePtr jobz, BytePtr uplo, IntPtr n, DoublePtr ap, DoublePtr bp, DoublePtr w, DoublePtr z, IntPtr ldz, DoublePtr work, IntPtr lwork, IntPtr iwork, IntPtr liwork, IntPtr info) {
/* 1350 */     throw new UnimplementedGnuApiMethod("dspgvd_");
/*      */   }
/*      */   
/*      */   public static void dspgvx_(IntPtr itype, BytePtr jobz, BytePtr range, BytePtr uplo, IntPtr n, DoublePtr ap, DoublePtr bp, DoublePtr vl, DoublePtr vu, IntPtr il, IntPtr iu, DoublePtr abstol, IntPtr m, DoublePtr w, DoublePtr z, IntPtr ldz, DoublePtr work, IntPtr iwork, IntPtr ifail, IntPtr info) {
/* 1354 */     throw new UnimplementedGnuApiMethod("dspgvx_");
/*      */   }
/*      */   
/*      */   public static void dstegr_(BytePtr jobz, BytePtr range, IntPtr n, DoublePtr d, DoublePtr e, DoublePtr vl, DoublePtr vu, IntPtr il, IntPtr iu, DoublePtr abstol, IntPtr m, DoublePtr w, DoublePtr z, IntPtr ldz, IntPtr isuppz, DoublePtr work, IntPtr lwork, IntPtr iwork, IntPtr liwork, IntPtr info) {
/* 1358 */     throw new UnimplementedGnuApiMethod("dstegr_");
/*      */   }
/*      */   
/*      */   public static void dstevr_(BytePtr jobz, BytePtr range, IntPtr n, DoublePtr d, DoublePtr e, DoublePtr vl, DoublePtr vu, IntPtr il, IntPtr iu, DoublePtr abstol, IntPtr m, DoublePtr w, DoublePtr z, IntPtr ldz, IntPtr isuppz, DoublePtr work, IntPtr lwork, IntPtr iwork, IntPtr liwork, IntPtr info) {
/* 1362 */     throw new UnimplementedGnuApiMethod("dstevr_");
/*      */   }
/*      */   
/*      */   public static void dsygvd_(IntPtr itype, BytePtr jobz, BytePtr uplo, IntPtr n, DoublePtr a, IntPtr lda, DoublePtr b, IntPtr ldb, DoublePtr w, DoublePtr work, IntPtr lwork, IntPtr iwork, IntPtr liwork, IntPtr info) {
/* 1366 */     throw new UnimplementedGnuApiMethod("dsygvd_");
/*      */   }
/*      */   
/*      */   public static void dsygvx_(IntPtr itype, BytePtr jobz, BytePtr range, BytePtr uplo, IntPtr n, DoublePtr a, IntPtr lda, DoublePtr b, IntPtr ldb, DoublePtr vl, DoublePtr vu, IntPtr il, IntPtr iu, DoublePtr abstol, IntPtr m, DoublePtr w, DoublePtr z, IntPtr ldz, DoublePtr work, IntPtr lwork, IntPtr iwork, IntPtr ifail, IntPtr info) {
/* 1370 */     throw new UnimplementedGnuApiMethod("dsygvx_");
/*      */   }
/*      */   
/*      */   public static void dtgex2_(IntPtr wantq, IntPtr wantz, IntPtr n, DoublePtr a, IntPtr lda, DoublePtr b, IntPtr ldb, DoublePtr q, IntPtr ldq, DoublePtr z, IntPtr ldz, IntPtr j1, IntPtr n1, IntPtr n2, DoublePtr work, IntPtr lwork, IntPtr info) {
/* 1374 */     throw new UnimplementedGnuApiMethod("dtgex2_");
/*      */   }
/*      */   
/*      */   public static void dtgexc_(IntPtr wantq, IntPtr wantz, IntPtr n, DoublePtr a, IntPtr lda, DoublePtr b, IntPtr ldb, DoublePtr q, IntPtr ldq, DoublePtr z, IntPtr ldz, IntPtr ifst, IntPtr ilst, DoublePtr work, IntPtr lwork, IntPtr info) {
/* 1378 */     throw new UnimplementedGnuApiMethod("dtgexc_");
/*      */   }
/*      */   
/*      */   public static void dtgsen_(IntPtr ijob, IntPtr wantq, IntPtr wantz, IntPtr select, IntPtr n, DoublePtr a, IntPtr lda, DoublePtr b, IntPtr ldb, DoublePtr alphar, DoublePtr alphai, DoublePtr beta, DoublePtr q, IntPtr ldq, DoublePtr z, IntPtr ldz, IntPtr m, DoublePtr pl, DoublePtr pr, DoublePtr dif, DoublePtr work, IntPtr lwork, IntPtr iwork, IntPtr liwork, IntPtr info) {
/* 1382 */     throw new UnimplementedGnuApiMethod("dtgsen_");
/*      */   }
/*      */   
/*      */   public static void dtgsna_(BytePtr job, BytePtr howmny, IntPtr select, IntPtr n, DoublePtr a, IntPtr lda, DoublePtr b, IntPtr ldb, DoublePtr vl, IntPtr ldvl, DoublePtr vr, IntPtr ldvr, DoublePtr s, DoublePtr dif, IntPtr mm, IntPtr m, DoublePtr work, IntPtr lwork, IntPtr iwork, IntPtr info) {
/* 1386 */     throw new UnimplementedGnuApiMethod("dtgsna_");
/*      */   }
/*      */   
/*      */   public static void dtgsy2_(BytePtr trans, IntPtr ijob, IntPtr m, IntPtr n, DoublePtr a, IntPtr lda, DoublePtr b, IntPtr ldb, DoublePtr c, IntPtr ldc, DoublePtr d, IntPtr ldd, DoublePtr e, IntPtr lde, DoublePtr f, IntPtr ldf, DoublePtr scale, DoublePtr rdsum, DoublePtr rdscal, IntPtr iwork, IntPtr pq, IntPtr info) {
/* 1390 */     throw new UnimplementedGnuApiMethod("dtgsy2_");
/*      */   }
/*      */   
/*      */   public static void dtgsyl_(BytePtr trans, IntPtr ijob, IntPtr m, IntPtr n, DoublePtr a, IntPtr lda, DoublePtr b, IntPtr ldb, DoublePtr c, IntPtr ldc, DoublePtr d, IntPtr ldd, DoublePtr e, IntPtr lde, DoublePtr f, IntPtr ldf, DoublePtr scale, DoublePtr dif, DoublePtr work, IntPtr lwork, IntPtr iwork, IntPtr info) {
/* 1394 */     throw new UnimplementedGnuApiMethod("dtgsyl_");
/*      */   }
/*      */   
/*      */   public static void dtzrzf_(IntPtr m, IntPtr n, DoublePtr a, IntPtr lda, DoublePtr tau, DoublePtr work, IntPtr lwork, IntPtr info) {
/* 1398 */     throw new UnimplementedGnuApiMethod("dtzrzf_");
/*      */   }
/*      */   
/*      */   public static void dpstrf_(BytePtr uplo, IntPtr n, DoublePtr a, IntPtr lda, IntPtr piv, IntPtr rank, DoublePtr tol, DoublePtr work, IntPtr info) {
/* 1402 */     throw new UnimplementedGnuApiMethod("dpstrf_");
/*      */   }
/*      */   
/*      */   public static int lsame_(BytePtr ca, BytePtr cb) {
/* 1406 */     throw new UnimplementedGnuApiMethod("lsame_");
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-gnur-runtime-0.9.2724.jar!/org/renjin/gnur/api/Lapack.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */