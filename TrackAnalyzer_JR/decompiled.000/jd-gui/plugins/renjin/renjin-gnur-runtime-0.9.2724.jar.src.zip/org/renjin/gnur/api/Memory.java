/*    */ package org.renjin.gnur.api;
/*    */ 
/*    */ import org.renjin.gcc.annotations.Noop;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Memory
/*    */ {
/*    */   public static Object vmaxget() {
/* 36 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Noop
/*    */   public static void vmaxset(Object p0) {}
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Noop
/*    */   public static void R_gc() {}
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static int R_gc_running() {
/* 56 */     return 0;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-gnur-runtime-0.9.2724.jar!/org/renjin/gnur/api/Memory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */