/*    */ package org.renjin.gnur.api;
/*    */ 
/*    */ import org.renjin.gcc.runtime.BytePtr;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class GraphicsDevice
/*    */ {
/*    */   @Deprecated
/*    */   public static int Rf_NumDevices() {
/* 36 */     throw new RuntimeException("Please recompile with the latest version of Renjin.");
/*    */   }
/*    */   
/*    */   @Deprecated
/*    */   public static void R_CheckDeviceAvailable() {
/* 41 */     throw new RuntimeException("Please recompile with the latest version of Renjin.");
/*    */   }
/*    */   
/*    */   @Deprecated
/*    */   public static boolean R_CheckDeviceAvailableBool() {
/* 46 */     throw new RuntimeException("Please recompile with the latest version of Renjin.");
/*    */   }
/*    */   
/*    */   @Deprecated
/*    */   public static int Rf_curDevice() {
/* 51 */     throw new RuntimeException("Please recompile with the latest version of Renjin.");
/*    */   }
/*    */   
/*    */   @Deprecated
/*    */   public static int Rf_nextDevice(int p0) {
/* 56 */     throw new RuntimeException("Please recompile with the latest version of Renjin.");
/*    */   }
/*    */   
/*    */   @Deprecated
/*    */   public static int Rf_prevDevice(int p0) {
/* 61 */     throw new RuntimeException("Please recompile with the latest version of Renjin.");
/*    */   }
/*    */   
/*    */   @Deprecated
/*    */   public static int Rf_selectDevice(int p0) {
/* 66 */     throw new RuntimeException("Please recompile with the latest version of Renjin.");
/*    */   }
/*    */   
/*    */   @Deprecated
/*    */   public static void Rf_killDevice(int p0) {
/* 71 */     throw new RuntimeException("Please recompile with the latest version of Renjin.");
/*    */   }
/*    */   
/*    */   @Deprecated
/*    */   public static int Rf_NoDevices() {
/* 76 */     throw new RuntimeException("Please recompile with the latest version of Renjin.");
/*    */   }
/*    */   
/*    */   @Deprecated
/*    */   public static void Rf_onintr() {
/* 81 */     throw new RuntimeException("Please recompile with the latest version of Renjin.");
/*    */   }
/*    */   
/*    */   @Deprecated
/*    */   public static Object Rf_AdobeSymbol2utf8(BytePtr out, BytePtr in, int nwork) {
/* 86 */     throw new RuntimeException("Please recompile with the latest version of Renjin.");
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-gnur-runtime-0.9.2724.jar!/org/renjin/gnur/api/GraphicsDevice.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */