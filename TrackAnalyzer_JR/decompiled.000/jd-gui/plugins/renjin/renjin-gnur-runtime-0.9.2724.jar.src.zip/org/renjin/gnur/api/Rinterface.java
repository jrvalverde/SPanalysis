/*    */ package org.renjin.gnur.api;
/*    */ 
/*    */ import org.renjin.gcc.runtime.BytePtr;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Rinterface
/*    */ {
/*    */   public static void R_RestoreGlobalEnv() {
/* 32 */     throw new UnimplementedGnuApiMethod("R_RestoreGlobalEnv");
/*    */   }
/*    */   
/*    */   public static void R_RestoreGlobalEnvFromFile(BytePtr p0, boolean p1) {
/* 36 */     throw new UnimplementedGnuApiMethod("R_RestoreGlobalEnvFromFile");
/*    */   }
/*    */   
/*    */   public static void R_SaveGlobalEnv() {
/* 40 */     throw new UnimplementedGnuApiMethod("R_SaveGlobalEnv");
/*    */   }
/*    */   
/*    */   public static void R_SaveGlobalEnvToFile(BytePtr p0) {
/* 44 */     throw new UnimplementedGnuApiMethod("R_SaveGlobalEnvToFile");
/*    */   }
/*    */   
/*    */   public static void R_FlushConsole() {
/* 48 */     throw new UnimplementedGnuApiMethod("R_FlushConsole");
/*    */   }
/*    */   
/*    */   public static void R_ClearerrConsole() {
/* 52 */     throw new UnimplementedGnuApiMethod("R_ClearerrConsole");
/*    */   }
/*    */   
/*    */   public static void R_Suicide(BytePtr p0) {
/* 56 */     throw new UnimplementedGnuApiMethod("R_Suicide");
/*    */   }
/*    */   
/*    */   public static BytePtr R_HomeDir() {
/* 60 */     throw new UnimplementedGnuApiMethod("R_HomeDir");
/*    */   }
/*    */   
/*    */   public static void R_setupHistory() {
/* 64 */     throw new UnimplementedGnuApiMethod("R_setupHistory");
/*    */   }
/*    */   
/*    */   public static void Rf_jump_to_toplevel() {
/* 68 */     throw new UnimplementedGnuApiMethod("Rf_jump_to_toplevel");
/*    */   }
/*    */   
/*    */   public static void Rf_mainloop() {
/* 72 */     throw new UnimplementedGnuApiMethod("Rf_mainloop");
/*    */   }
/*    */   
/*    */   public static void Rf_onintr() {
/* 76 */     throw new UnimplementedGnuApiMethod("Rf_onintr");
/*    */   }
/*    */   
/*    */   public static void process_site_Renviron() {
/* 80 */     throw new UnimplementedGnuApiMethod("process_site_Renviron");
/*    */   }
/*    */   
/*    */   public static void process_system_Renviron() {
/* 84 */     throw new UnimplementedGnuApiMethod("process_system_Renviron");
/*    */   }
/*    */   
/*    */   public static void process_user_Renviron() {
/* 88 */     throw new UnimplementedGnuApiMethod("process_user_Renviron");
/*    */   }
/*    */   
/*    */   public static void R_setStartTime() {
/* 92 */     throw new UnimplementedGnuApiMethod("R_setStartTime");
/*    */   }
/*    */   
/*    */   public static void fpu_setup(boolean p0) {
/* 96 */     throw new UnimplementedGnuApiMethod("fpu_setup");
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-gnur-runtime-0.9.2724.jar!/org/renjin/gnur/api/Rinterface.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */