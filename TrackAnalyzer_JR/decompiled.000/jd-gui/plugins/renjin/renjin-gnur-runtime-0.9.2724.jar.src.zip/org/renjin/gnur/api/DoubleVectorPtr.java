/*    */ package org.renjin.gnur.api;
/*    */ 
/*    */ import org.renjin.gcc.runtime.AbstractPtr;
/*    */ import org.renjin.gcc.runtime.OffsetPtr;
/*    */ import org.renjin.gcc.runtime.Ptr;
/*    */ import org.renjin.sexp.AtomicVector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DoubleVectorPtr
/*    */   extends AbstractPtr
/*    */ {
/*    */   private AtomicVector vector;
/*    */   private int offset;
/*    */   
/*    */   public DoubleVectorPtr(AtomicVector vector, int offset) {
/* 34 */     this.vector = vector;
/* 35 */     this.offset = offset;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object getArray() {
/* 40 */     return this.vector;
/*    */   }
/*    */ 
/*    */   
/*    */   public final int getOffsetInBytes() {
/* 45 */     return this.offset * 8;
/*    */   }
/*    */ 
/*    */   
/*    */   public Ptr realloc(int newSizeInBytes) {
/* 50 */     throw new UnsupportedOperationException("TODO");
/*    */   }
/*    */ 
/*    */   
/*    */   public Ptr pointerPlus(int bytes) {
/* 55 */     if (bytes == 0) {
/* 56 */       return (Ptr)this;
/*    */     }
/* 58 */     if (bytes % 8 == 0) {
/* 59 */       return (Ptr)new DoubleVectorPtr(this.vector, this.offset + bytes / 8);
/*    */     }
/* 61 */     return (Ptr)new OffsetPtr((Ptr)this, bytes);
/*    */   }
/*    */ 
/*    */   
/*    */   public double getAlignedDouble(int index) {
/* 66 */     return this.vector.getElementAsDouble(this.offset + index);
/*    */   }
/*    */ 
/*    */   
/*    */   public double getDouble(int offset) {
/* 71 */     if (offset % 8 == 0) {
/* 72 */       return getAlignedDouble(offset / 8);
/*    */     }
/* 74 */     return super.getDouble(offset);
/*    */   }
/*    */ 
/*    */   
/*    */   public byte getByte(int bytes) {
/* 79 */     return getByteViaDouble(bytes);
/*    */   }
/*    */   
/*    */   public void setByte(int offset, byte value) {
/* 83 */     throw new UnsupportedOperationException("Illegal modification of a shared vector! Mis-behaving C/C++ code has tried to modify a vector that it should not.");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int toInt() {
/* 89 */     return this.offset * 8;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isNull() {
/* 94 */     return false;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-gnur-runtime-0.9.2724.jar!/org/renjin/gnur/api/DoubleVectorPtr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */