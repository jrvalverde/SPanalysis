/*    */ package org.renjin.gnur.api;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UnimplementedGnuApiMethod
/*    */   extends RuntimeException
/*    */ {
/*    */   UnimplementedGnuApiMethod(String functionName) {
/* 27 */     super("Unimplemented GNU R API function '" + functionName + "'");
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-gnur-runtime-0.9.2724.jar!/org/renjin/gnur/api/UnimplementedGnuApiMethod.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */