/*    */ package org.renjin.gnur.api;
/*    */ 
/*    */ import org.renjin.gcc.runtime.DoublePtr;
/*    */ import org.renjin.gcc.runtime.IntPtr;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Rgraphics
/*    */ {
/*    */   @Deprecated
/*    */   public static void Rf_GPretty(DoublePtr p0, DoublePtr p1, IntPtr p2) {
/* 32 */     throw new RuntimeException("Please compile against the latest version of Renjin.");
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-gnur-runtime-0.9.2724.jar!/org/renjin/gnur/api/Rgraphics.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */