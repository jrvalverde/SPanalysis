package org.renjin.grid;

import org.renjin.gcc.runtime.BytePtr;
import org.renjin.gcc.runtime.MixedPtr;
import org.renjin.gcc.runtime.Ptr;
import org.renjin.gnur.api.Rdynload;
import org.renjin.primitives.packaging.DllInfo;

public class register__ {
  public static Ptr callMethods = (Ptr)MixedPtr.malloc(1180);
  
  static {
    callMethods$$clinit();
  }
  
  public static void R_init_grid(DllInfo paramDllInfo) {
    Rdynload.R_registerRoutines(paramDllInfo, BytePtr.of(0), callMethods, BytePtr.of(0), BytePtr.of(0));
    Rdynload.R_useDynamicSymbols(paramDllInfo, false);
    Rdynload.R_forceSymbols(paramDllInfo, false);
  }
  
  static void callMethods$$clinit() {
    // Byte code:
    //   0: sipush #1180
    //   3: invokestatic malloc : (I)Lorg/renjin/gcc/runtime/MixedPtr;
    //   6: astore_0
    //   7: aload_0
    //   8: new org/renjin/gcc/runtime/BytePtr
    //   11: dup
    //   12: ldc 'initGrid '
    //   14: invokevirtual getBytes : ()[B
    //   17: iconst_0
    //   18: invokespecial <init> : ([BI)V
    //   21: invokeinterface setPointer : (Lorg/renjin/gcc/runtime/Ptr;)V
    //   26: aload_0
    //   27: iconst_1
    //   28: ldc
    //   30: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   33: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   38: aload_0
    //   39: iconst_2
    //   40: iconst_1
    //   41: invokeinterface setAlignedInt : (II)V
    //   46: aload_0
    //   47: iconst_5
    //   48: new org/renjin/gcc/runtime/BytePtr
    //   51: dup
    //   52: ldc 'killGrid '
    //   54: invokevirtual getBytes : ()[B
    //   57: iconst_0
    //   58: invokespecial <init> : ([BI)V
    //   61: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   66: aload_0
    //   67: bipush #6
    //   69: ldc
    //   71: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   74: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   79: aload_0
    //   80: bipush #7
    //   82: iconst_0
    //   83: invokeinterface setAlignedInt : (II)V
    //   88: aload_0
    //   89: bipush #10
    //   91: new org/renjin/gcc/runtime/BytePtr
    //   94: dup
    //   95: ldc 'gridDirty '
    //   97: invokevirtual getBytes : ()[B
    //   100: iconst_0
    //   101: invokespecial <init> : ([BI)V
    //   104: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   109: aload_0
    //   110: bipush #11
    //   112: ldc
    //   114: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   117: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   122: aload_0
    //   123: bipush #12
    //   125: iconst_0
    //   126: invokeinterface setAlignedInt : (II)V
    //   131: aload_0
    //   132: bipush #15
    //   134: new org/renjin/gcc/runtime/BytePtr
    //   137: dup
    //   138: ldc 'currentViewport '
    //   140: invokevirtual getBytes : ()[B
    //   143: iconst_0
    //   144: invokespecial <init> : ([BI)V
    //   147: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   152: aload_0
    //   153: bipush #16
    //   155: ldc
    //   157: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   160: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   165: aload_0
    //   166: bipush #17
    //   168: iconst_0
    //   169: invokeinterface setAlignedInt : (II)V
    //   174: aload_0
    //   175: bipush #20
    //   177: new org/renjin/gcc/runtime/BytePtr
    //   180: dup
    //   181: ldc 'setviewport '
    //   183: invokevirtual getBytes : ()[B
    //   186: iconst_0
    //   187: invokespecial <init> : ([BI)V
    //   190: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   195: aload_0
    //   196: bipush #21
    //   198: ldc
    //   200: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   203: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   208: aload_0
    //   209: bipush #22
    //   211: iconst_2
    //   212: invokeinterface setAlignedInt : (II)V
    //   217: aload_0
    //   218: bipush #25
    //   220: new org/renjin/gcc/runtime/BytePtr
    //   223: dup
    //   224: ldc 'downviewport '
    //   226: invokevirtual getBytes : ()[B
    //   229: iconst_0
    //   230: invokespecial <init> : ([BI)V
    //   233: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   238: aload_0
    //   239: bipush #26
    //   241: ldc
    //   243: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   246: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   251: aload_0
    //   252: bipush #27
    //   254: iconst_2
    //   255: invokeinterface setAlignedInt : (II)V
    //   260: aload_0
    //   261: bipush #30
    //   263: new org/renjin/gcc/runtime/BytePtr
    //   266: dup
    //   267: ldc 'downvppath '
    //   269: invokevirtual getBytes : ()[B
    //   272: iconst_0
    //   273: invokespecial <init> : ([BI)V
    //   276: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   281: aload_0
    //   282: bipush #31
    //   284: ldc
    //   286: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   289: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   294: aload_0
    //   295: bipush #32
    //   297: iconst_3
    //   298: invokeinterface setAlignedInt : (II)V
    //   303: aload_0
    //   304: bipush #35
    //   306: new org/renjin/gcc/runtime/BytePtr
    //   309: dup
    //   310: ldc 'unsetviewport '
    //   312: invokevirtual getBytes : ()[B
    //   315: iconst_0
    //   316: invokespecial <init> : ([BI)V
    //   319: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   324: aload_0
    //   325: bipush #36
    //   327: ldc
    //   329: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   332: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   337: aload_0
    //   338: bipush #37
    //   340: iconst_1
    //   341: invokeinterface setAlignedInt : (II)V
    //   346: aload_0
    //   347: bipush #40
    //   349: new org/renjin/gcc/runtime/BytePtr
    //   352: dup
    //   353: ldc 'upviewport '
    //   355: invokevirtual getBytes : ()[B
    //   358: iconst_0
    //   359: invokespecial <init> : ([BI)V
    //   362: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   367: aload_0
    //   368: bipush #41
    //   370: ldc
    //   372: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   375: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   380: aload_0
    //   381: bipush #42
    //   383: iconst_1
    //   384: invokeinterface setAlignedInt : (II)V
    //   389: aload_0
    //   390: bipush #45
    //   392: new org/renjin/gcc/runtime/BytePtr
    //   395: dup
    //   396: ldc 'getDisplayList '
    //   398: invokevirtual getBytes : ()[B
    //   401: iconst_0
    //   402: invokespecial <init> : ([BI)V
    //   405: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   410: aload_0
    //   411: bipush #46
    //   413: ldc
    //   415: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   418: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   423: aload_0
    //   424: bipush #47
    //   426: iconst_0
    //   427: invokeinterface setAlignedInt : (II)V
    //   432: aload_0
    //   433: bipush #50
    //   435: new org/renjin/gcc/runtime/BytePtr
    //   438: dup
    //   439: ldc 'setDisplayList '
    //   441: invokevirtual getBytes : ()[B
    //   444: iconst_0
    //   445: invokespecial <init> : ([BI)V
    //   448: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   453: aload_0
    //   454: bipush #51
    //   456: ldc
    //   458: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   461: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   466: aload_0
    //   467: bipush #52
    //   469: iconst_1
    //   470: invokeinterface setAlignedInt : (II)V
    //   475: aload_0
    //   476: bipush #55
    //   478: new org/renjin/gcc/runtime/BytePtr
    //   481: dup
    //   482: ldc 'getDLelt '
    //   484: invokevirtual getBytes : ()[B
    //   487: iconst_0
    //   488: invokespecial <init> : ([BI)V
    //   491: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   496: aload_0
    //   497: bipush #56
    //   499: ldc
    //   501: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   504: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   509: aload_0
    //   510: bipush #57
    //   512: iconst_1
    //   513: invokeinterface setAlignedInt : (II)V
    //   518: aload_0
    //   519: bipush #60
    //   521: new org/renjin/gcc/runtime/BytePtr
    //   524: dup
    //   525: ldc 'setDLelt '
    //   527: invokevirtual getBytes : ()[B
    //   530: iconst_0
    //   531: invokespecial <init> : ([BI)V
    //   534: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   539: aload_0
    //   540: bipush #61
    //   542: ldc
    //   544: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   547: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   552: aload_0
    //   553: bipush #62
    //   555: iconst_1
    //   556: invokeinterface setAlignedInt : (II)V
    //   561: aload_0
    //   562: bipush #65
    //   564: new org/renjin/gcc/runtime/BytePtr
    //   567: dup
    //   568: ldc 'getDLindex '
    //   570: invokevirtual getBytes : ()[B
    //   573: iconst_0
    //   574: invokespecial <init> : ([BI)V
    //   577: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   582: aload_0
    //   583: bipush #66
    //   585: ldc
    //   587: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   590: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   595: aload_0
    //   596: bipush #67
    //   598: iconst_0
    //   599: invokeinterface setAlignedInt : (II)V
    //   604: aload_0
    //   605: bipush #70
    //   607: new org/renjin/gcc/runtime/BytePtr
    //   610: dup
    //   611: ldc 'setDLindex '
    //   613: invokevirtual getBytes : ()[B
    //   616: iconst_0
    //   617: invokespecial <init> : ([BI)V
    //   620: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   625: aload_0
    //   626: bipush #71
    //   628: ldc
    //   630: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   633: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   638: aload_0
    //   639: bipush #72
    //   641: iconst_1
    //   642: invokeinterface setAlignedInt : (II)V
    //   647: aload_0
    //   648: bipush #75
    //   650: new org/renjin/gcc/runtime/BytePtr
    //   653: dup
    //   654: ldc 'getDLon '
    //   656: invokevirtual getBytes : ()[B
    //   659: iconst_0
    //   660: invokespecial <init> : ([BI)V
    //   663: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   668: aload_0
    //   669: bipush #76
    //   671: ldc
    //   673: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   676: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   681: aload_0
    //   682: bipush #77
    //   684: iconst_0
    //   685: invokeinterface setAlignedInt : (II)V
    //   690: aload_0
    //   691: bipush #80
    //   693: new org/renjin/gcc/runtime/BytePtr
    //   696: dup
    //   697: ldc 'setDLon '
    //   699: invokevirtual getBytes : ()[B
    //   702: iconst_0
    //   703: invokespecial <init> : ([BI)V
    //   706: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   711: aload_0
    //   712: bipush #81
    //   714: ldc
    //   716: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   719: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   724: aload_0
    //   725: bipush #82
    //   727: iconst_1
    //   728: invokeinterface setAlignedInt : (II)V
    //   733: aload_0
    //   734: bipush #85
    //   736: new org/renjin/gcc/runtime/BytePtr
    //   739: dup
    //   740: ldc 'getEngineDLon '
    //   742: invokevirtual getBytes : ()[B
    //   745: iconst_0
    //   746: invokespecial <init> : ([BI)V
    //   749: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   754: aload_0
    //   755: bipush #86
    //   757: ldc
    //   759: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   762: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   767: aload_0
    //   768: bipush #87
    //   770: iconst_0
    //   771: invokeinterface setAlignedInt : (II)V
    //   776: aload_0
    //   777: bipush #90
    //   779: new org/renjin/gcc/runtime/BytePtr
    //   782: dup
    //   783: ldc 'setEngineDLon '
    //   785: invokevirtual getBytes : ()[B
    //   788: iconst_0
    //   789: invokespecial <init> : ([BI)V
    //   792: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   797: aload_0
    //   798: bipush #91
    //   800: ldc
    //   802: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   805: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   810: aload_0
    //   811: bipush #92
    //   813: iconst_1
    //   814: invokeinterface setAlignedInt : (II)V
    //   819: aload_0
    //   820: bipush #95
    //   822: new org/renjin/gcc/runtime/BytePtr
    //   825: dup
    //   826: ldc 'getCurrentGrob '
    //   828: invokevirtual getBytes : ()[B
    //   831: iconst_0
    //   832: invokespecial <init> : ([BI)V
    //   835: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   840: aload_0
    //   841: bipush #96
    //   843: ldc
    //   845: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   848: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   853: aload_0
    //   854: bipush #97
    //   856: iconst_0
    //   857: invokeinterface setAlignedInt : (II)V
    //   862: aload_0
    //   863: bipush #100
    //   865: new org/renjin/gcc/runtime/BytePtr
    //   868: dup
    //   869: ldc 'setCurrentGrob '
    //   871: invokevirtual getBytes : ()[B
    //   874: iconst_0
    //   875: invokespecial <init> : ([BI)V
    //   878: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   883: aload_0
    //   884: bipush #101
    //   886: ldc
    //   888: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   891: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   896: aload_0
    //   897: bipush #102
    //   899: iconst_1
    //   900: invokeinterface setAlignedInt : (II)V
    //   905: aload_0
    //   906: bipush #105
    //   908: new org/renjin/gcc/runtime/BytePtr
    //   911: dup
    //   912: ldc 'getEngineRecording '
    //   914: invokevirtual getBytes : ()[B
    //   917: iconst_0
    //   918: invokespecial <init> : ([BI)V
    //   921: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   926: aload_0
    //   927: bipush #106
    //   929: ldc
    //   931: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   934: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   939: aload_0
    //   940: bipush #107
    //   942: iconst_0
    //   943: invokeinterface setAlignedInt : (II)V
    //   948: aload_0
    //   949: bipush #110
    //   951: new org/renjin/gcc/runtime/BytePtr
    //   954: dup
    //   955: ldc 'setEngineRecording '
    //   957: invokevirtual getBytes : ()[B
    //   960: iconst_0
    //   961: invokespecial <init> : ([BI)V
    //   964: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   969: aload_0
    //   970: bipush #111
    //   972: ldc
    //   974: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   977: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   982: aload_0
    //   983: bipush #112
    //   985: iconst_1
    //   986: invokeinterface setAlignedInt : (II)V
    //   991: aload_0
    //   992: bipush #115
    //   994: new org/renjin/gcc/runtime/BytePtr
    //   997: dup
    //   998: ldc 'currentGPar '
    //   1000: invokevirtual getBytes : ()[B
    //   1003: iconst_0
    //   1004: invokespecial <init> : ([BI)V
    //   1007: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1012: aload_0
    //   1013: bipush #116
    //   1015: ldc
    //   1017: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   1020: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1025: aload_0
    //   1026: bipush #117
    //   1028: iconst_0
    //   1029: invokeinterface setAlignedInt : (II)V
    //   1034: aload_0
    //   1035: bipush #120
    //   1037: new org/renjin/gcc/runtime/BytePtr
    //   1040: dup
    //   1041: ldc 'newpagerecording '
    //   1043: invokevirtual getBytes : ()[B
    //   1046: iconst_0
    //   1047: invokespecial <init> : ([BI)V
    //   1050: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1055: aload_0
    //   1056: bipush #121
    //   1058: ldc
    //   1060: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   1063: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1068: aload_0
    //   1069: bipush #122
    //   1071: iconst_0
    //   1072: invokeinterface setAlignedInt : (II)V
    //   1077: aload_0
    //   1078: bipush #125
    //   1080: new org/renjin/gcc/runtime/BytePtr
    //   1083: dup
    //   1084: ldc 'newpage '
    //   1086: invokevirtual getBytes : ()[B
    //   1089: iconst_0
    //   1090: invokespecial <init> : ([BI)V
    //   1093: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1098: aload_0
    //   1099: bipush #126
    //   1101: ldc
    //   1103: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   1106: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1111: aload_0
    //   1112: bipush #127
    //   1114: iconst_0
    //   1115: invokeinterface setAlignedInt : (II)V
    //   1120: aload_0
    //   1121: sipush #130
    //   1124: new org/renjin/gcc/runtime/BytePtr
    //   1127: dup
    //   1128: ldc 'initGPar '
    //   1130: invokevirtual getBytes : ()[B
    //   1133: iconst_0
    //   1134: invokespecial <init> : ([BI)V
    //   1137: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1142: aload_0
    //   1143: sipush #131
    //   1146: ldc
    //   1148: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   1151: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1156: aload_0
    //   1157: sipush #132
    //   1160: iconst_0
    //   1161: invokeinterface setAlignedInt : (II)V
    //   1166: aload_0
    //   1167: sipush #135
    //   1170: new org/renjin/gcc/runtime/BytePtr
    //   1173: dup
    //   1174: ldc 'initViewportStack '
    //   1176: invokevirtual getBytes : ()[B
    //   1179: iconst_0
    //   1180: invokespecial <init> : ([BI)V
    //   1183: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1188: aload_0
    //   1189: sipush #136
    //   1192: ldc
    //   1194: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   1197: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1202: aload_0
    //   1203: sipush #137
    //   1206: iconst_0
    //   1207: invokeinterface setAlignedInt : (II)V
    //   1212: aload_0
    //   1213: sipush #140
    //   1216: new org/renjin/gcc/runtime/BytePtr
    //   1219: dup
    //   1220: ldc 'initDisplayList '
    //   1222: invokevirtual getBytes : ()[B
    //   1225: iconst_0
    //   1226: invokespecial <init> : ([BI)V
    //   1229: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1234: aload_0
    //   1235: sipush #141
    //   1238: ldc
    //   1240: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   1243: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1248: aload_0
    //   1249: sipush #142
    //   1252: iconst_0
    //   1253: invokeinterface setAlignedInt : (II)V
    //   1258: aload_0
    //   1259: sipush #145
    //   1262: new org/renjin/gcc/runtime/BytePtr
    //   1265: dup
    //   1266: ldc 'moveTo '
    //   1268: invokevirtual getBytes : ()[B
    //   1271: iconst_0
    //   1272: invokespecial <init> : ([BI)V
    //   1275: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1280: aload_0
    //   1281: sipush #146
    //   1284: ldc_w
    //   1287: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   1290: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1295: aload_0
    //   1296: sipush #147
    //   1299: iconst_2
    //   1300: invokeinterface setAlignedInt : (II)V
    //   1305: aload_0
    //   1306: sipush #150
    //   1309: new org/renjin/gcc/runtime/BytePtr
    //   1312: dup
    //   1313: ldc_w 'lineTo '
    //   1316: invokevirtual getBytes : ()[B
    //   1319: iconst_0
    //   1320: invokespecial <init> : ([BI)V
    //   1323: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1328: aload_0
    //   1329: sipush #151
    //   1332: ldc_w
    //   1335: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   1338: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1343: aload_0
    //   1344: sipush #152
    //   1347: iconst_3
    //   1348: invokeinterface setAlignedInt : (II)V
    //   1353: aload_0
    //   1354: sipush #155
    //   1357: new org/renjin/gcc/runtime/BytePtr
    //   1360: dup
    //   1361: ldc_w 'lines '
    //   1364: invokevirtual getBytes : ()[B
    //   1367: iconst_0
    //   1368: invokespecial <init> : ([BI)V
    //   1371: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1376: aload_0
    //   1377: sipush #156
    //   1380: ldc_w
    //   1383: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   1386: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1391: aload_0
    //   1392: sipush #157
    //   1395: iconst_4
    //   1396: invokeinterface setAlignedInt : (II)V
    //   1401: aload_0
    //   1402: sipush #160
    //   1405: new org/renjin/gcc/runtime/BytePtr
    //   1408: dup
    //   1409: ldc_w 'segments '
    //   1412: invokevirtual getBytes : ()[B
    //   1415: iconst_0
    //   1416: invokespecial <init> : ([BI)V
    //   1419: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1424: aload_0
    //   1425: sipush #161
    //   1428: ldc_w
    //   1431: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   1434: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1439: aload_0
    //   1440: sipush #162
    //   1443: iconst_5
    //   1444: invokeinterface setAlignedInt : (II)V
    //   1449: aload_0
    //   1450: sipush #165
    //   1453: new org/renjin/gcc/runtime/BytePtr
    //   1456: dup
    //   1457: ldc_w 'arrows '
    //   1460: invokevirtual getBytes : ()[B
    //   1463: iconst_0
    //   1464: invokespecial <init> : ([BI)V
    //   1467: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1472: aload_0
    //   1473: sipush #166
    //   1476: ldc_w
    //   1479: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   1482: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1487: aload_0
    //   1488: sipush #167
    //   1491: bipush #12
    //   1493: invokeinterface setAlignedInt : (II)V
    //   1498: aload_0
    //   1499: sipush #170
    //   1502: new org/renjin/gcc/runtime/BytePtr
    //   1505: dup
    //   1506: ldc_w 'path '
    //   1509: invokevirtual getBytes : ()[B
    //   1512: iconst_0
    //   1513: invokespecial <init> : ([BI)V
    //   1516: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1521: aload_0
    //   1522: sipush #171
    //   1525: ldc_w
    //   1528: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   1531: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1536: aload_0
    //   1537: sipush #172
    //   1540: iconst_4
    //   1541: invokeinterface setAlignedInt : (II)V
    //   1546: aload_0
    //   1547: sipush #175
    //   1550: new org/renjin/gcc/runtime/BytePtr
    //   1553: dup
    //   1554: ldc_w 'polygon '
    //   1557: invokevirtual getBytes : ()[B
    //   1560: iconst_0
    //   1561: invokespecial <init> : ([BI)V
    //   1564: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1569: aload_0
    //   1570: sipush #176
    //   1573: ldc_w
    //   1576: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   1579: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1584: aload_0
    //   1585: sipush #177
    //   1588: iconst_3
    //   1589: invokeinterface setAlignedInt : (II)V
    //   1594: aload_0
    //   1595: sipush #180
    //   1598: new org/renjin/gcc/runtime/BytePtr
    //   1601: dup
    //   1602: ldc_w 'xspline '
    //   1605: invokevirtual getBytes : ()[B
    //   1608: iconst_0
    //   1609: invokespecial <init> : ([BI)V
    //   1612: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1617: aload_0
    //   1618: sipush #181
    //   1621: ldc_w
    //   1624: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   1627: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1632: aload_0
    //   1633: sipush #182
    //   1636: bipush #7
    //   1638: invokeinterface setAlignedInt : (II)V
    //   1643: aload_0
    //   1644: sipush #185
    //   1647: new org/renjin/gcc/runtime/BytePtr
    //   1650: dup
    //   1651: ldc_w 'circle '
    //   1654: invokevirtual getBytes : ()[B
    //   1657: iconst_0
    //   1658: invokespecial <init> : ([BI)V
    //   1661: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1666: aload_0
    //   1667: sipush #186
    //   1670: ldc_w
    //   1673: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   1676: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1681: aload_0
    //   1682: sipush #187
    //   1685: iconst_3
    //   1686: invokeinterface setAlignedInt : (II)V
    //   1691: aload_0
    //   1692: sipush #190
    //   1695: new org/renjin/gcc/runtime/BytePtr
    //   1698: dup
    //   1699: ldc_w 'rect '
    //   1702: invokevirtual getBytes : ()[B
    //   1705: iconst_0
    //   1706: invokespecial <init> : ([BI)V
    //   1709: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1714: aload_0
    //   1715: sipush #191
    //   1718: ldc_w
    //   1721: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   1724: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1729: aload_0
    //   1730: sipush #192
    //   1733: bipush #6
    //   1735: invokeinterface setAlignedInt : (II)V
    //   1740: aload_0
    //   1741: sipush #195
    //   1744: new org/renjin/gcc/runtime/BytePtr
    //   1747: dup
    //   1748: ldc_w 'raster '
    //   1751: invokevirtual getBytes : ()[B
    //   1754: iconst_0
    //   1755: invokespecial <init> : ([BI)V
    //   1758: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1763: aload_0
    //   1764: sipush #196
    //   1767: ldc_w
    //   1770: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   1773: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1778: aload_0
    //   1779: sipush #197
    //   1782: bipush #8
    //   1784: invokeinterface setAlignedInt : (II)V
    //   1789: aload_0
    //   1790: sipush #200
    //   1793: new org/renjin/gcc/runtime/BytePtr
    //   1796: dup
    //   1797: ldc_w 'cap '
    //   1800: invokevirtual getBytes : ()[B
    //   1803: iconst_0
    //   1804: invokespecial <init> : ([BI)V
    //   1807: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1812: aload_0
    //   1813: sipush #201
    //   1816: ldc_w
    //   1819: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   1822: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1827: aload_0
    //   1828: sipush #202
    //   1831: iconst_0
    //   1832: invokeinterface setAlignedInt : (II)V
    //   1837: aload_0
    //   1838: sipush #205
    //   1841: new org/renjin/gcc/runtime/BytePtr
    //   1844: dup
    //   1845: ldc_w 'text '
    //   1848: invokevirtual getBytes : ()[B
    //   1851: iconst_0
    //   1852: invokespecial <init> : ([BI)V
    //   1855: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1860: aload_0
    //   1861: sipush #206
    //   1864: ldc_w
    //   1867: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   1870: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1875: aload_0
    //   1876: sipush #207
    //   1879: bipush #7
    //   1881: invokeinterface setAlignedInt : (II)V
    //   1886: aload_0
    //   1887: sipush #210
    //   1890: new org/renjin/gcc/runtime/BytePtr
    //   1893: dup
    //   1894: ldc_w 'points '
    //   1897: invokevirtual getBytes : ()[B
    //   1900: iconst_0
    //   1901: invokespecial <init> : ([BI)V
    //   1904: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1909: aload_0
    //   1910: sipush #211
    //   1913: ldc_w
    //   1916: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   1919: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1924: aload_0
    //   1925: sipush #212
    //   1928: iconst_4
    //   1929: invokeinterface setAlignedInt : (II)V
    //   1934: aload_0
    //   1935: sipush #215
    //   1938: new org/renjin/gcc/runtime/BytePtr
    //   1941: dup
    //   1942: ldc_w 'clip '
    //   1945: invokevirtual getBytes : ()[B
    //   1948: iconst_0
    //   1949: invokespecial <init> : ([BI)V
    //   1952: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1957: aload_0
    //   1958: sipush #216
    //   1961: ldc_w
    //   1964: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   1967: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1972: aload_0
    //   1973: sipush #217
    //   1976: bipush #6
    //   1978: invokeinterface setAlignedInt : (II)V
    //   1983: aload_0
    //   1984: sipush #220
    //   1987: new org/renjin/gcc/runtime/BytePtr
    //   1990: dup
    //   1991: ldc_w 'pretty '
    //   1994: invokevirtual getBytes : ()[B
    //   1997: iconst_0
    //   1998: invokespecial <init> : ([BI)V
    //   2001: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2006: aload_0
    //   2007: sipush #221
    //   2010: ldc_w
    //   2013: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   2016: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2021: aload_0
    //   2022: sipush #222
    //   2025: iconst_1
    //   2026: invokeinterface setAlignedInt : (II)V
    //   2031: aload_0
    //   2032: sipush #225
    //   2035: new org/renjin/gcc/runtime/BytePtr
    //   2038: dup
    //   2039: ldc_w 'locator '
    //   2042: invokevirtual getBytes : ()[B
    //   2045: iconst_0
    //   2046: invokespecial <init> : ([BI)V
    //   2049: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2054: aload_0
    //   2055: sipush #226
    //   2058: ldc_w
    //   2061: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   2064: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2069: aload_0
    //   2070: sipush #227
    //   2073: iconst_0
    //   2074: invokeinterface setAlignedInt : (II)V
    //   2079: aload_0
    //   2080: sipush #230
    //   2083: new org/renjin/gcc/runtime/BytePtr
    //   2086: dup
    //   2087: ldc_w 'convert '
    //   2090: invokevirtual getBytes : ()[B
    //   2093: iconst_0
    //   2094: invokespecial <init> : ([BI)V
    //   2097: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2102: aload_0
    //   2103: sipush #231
    //   2106: ldc_w
    //   2109: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   2112: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2117: aload_0
    //   2118: sipush #232
    //   2121: iconst_4
    //   2122: invokeinterface setAlignedInt : (II)V
    //   2127: aload_0
    //   2128: sipush #235
    //   2131: new org/renjin/gcc/runtime/BytePtr
    //   2134: dup
    //   2135: ldc_w 'layoutRegion '
    //   2138: invokevirtual getBytes : ()[B
    //   2141: iconst_0
    //   2142: invokespecial <init> : ([BI)V
    //   2145: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2150: aload_0
    //   2151: sipush #236
    //   2154: ldc_w
    //   2157: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   2160: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2165: aload_0
    //   2166: sipush #237
    //   2169: iconst_2
    //   2170: invokeinterface setAlignedInt : (II)V
    //   2175: aload_0
    //   2176: sipush #240
    //   2179: new org/renjin/gcc/runtime/BytePtr
    //   2182: dup
    //   2183: ldc_w 'getGPar '
    //   2186: invokevirtual getBytes : ()[B
    //   2189: iconst_0
    //   2190: invokespecial <init> : ([BI)V
    //   2193: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2198: aload_0
    //   2199: sipush #241
    //   2202: ldc_w
    //   2205: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   2208: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2213: aload_0
    //   2214: sipush #242
    //   2217: iconst_0
    //   2218: invokeinterface setAlignedInt : (II)V
    //   2223: aload_0
    //   2224: sipush #245
    //   2227: new org/renjin/gcc/runtime/BytePtr
    //   2230: dup
    //   2231: ldc_w 'setGPar '
    //   2234: invokevirtual getBytes : ()[B
    //   2237: iconst_0
    //   2238: invokespecial <init> : ([BI)V
    //   2241: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2246: aload_0
    //   2247: sipush #246
    //   2250: ldc_w
    //   2253: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   2256: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2261: aload_0
    //   2262: sipush #247
    //   2265: iconst_1
    //   2266: invokeinterface setAlignedInt : (II)V
    //   2271: aload_0
    //   2272: sipush #250
    //   2275: new org/renjin/gcc/runtime/BytePtr
    //   2278: dup
    //   2279: ldc_w 'circleBounds '
    //   2282: invokevirtual getBytes : ()[B
    //   2285: iconst_0
    //   2286: invokespecial <init> : ([BI)V
    //   2289: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2294: aload_0
    //   2295: sipush #251
    //   2298: ldc_w
    //   2301: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   2304: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2309: aload_0
    //   2310: sipush #252
    //   2313: iconst_4
    //   2314: invokeinterface setAlignedInt : (II)V
    //   2319: aload_0
    //   2320: sipush #255
    //   2323: new org/renjin/gcc/runtime/BytePtr
    //   2326: dup
    //   2327: ldc_w 'locnBounds '
    //   2330: invokevirtual getBytes : ()[B
    //   2333: iconst_0
    //   2334: invokespecial <init> : ([BI)V
    //   2337: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2342: aload_0
    //   2343: sipush #256
    //   2346: ldc_w
    //   2349: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   2352: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2357: aload_0
    //   2358: sipush #257
    //   2361: iconst_3
    //   2362: invokeinterface setAlignedInt : (II)V
    //   2367: aload_0
    //   2368: sipush #260
    //   2371: new org/renjin/gcc/runtime/BytePtr
    //   2374: dup
    //   2375: ldc_w 'rectBounds '
    //   2378: invokevirtual getBytes : ()[B
    //   2381: iconst_0
    //   2382: invokespecial <init> : ([BI)V
    //   2385: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2390: aload_0
    //   2391: sipush #261
    //   2394: ldc_w
    //   2397: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   2400: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2405: aload_0
    //   2406: sipush #262
    //   2409: bipush #7
    //   2411: invokeinterface setAlignedInt : (II)V
    //   2416: aload_0
    //   2417: sipush #265
    //   2420: new org/renjin/gcc/runtime/BytePtr
    //   2423: dup
    //   2424: ldc_w 'textBounds '
    //   2427: invokevirtual getBytes : ()[B
    //   2430: iconst_0
    //   2431: invokespecial <init> : ([BI)V
    //   2434: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2439: aload_0
    //   2440: sipush #266
    //   2443: ldc_w
    //   2446: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   2449: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2454: aload_0
    //   2455: sipush #267
    //   2458: bipush #7
    //   2460: invokeinterface setAlignedInt : (II)V
    //   2465: aload_0
    //   2466: sipush #270
    //   2469: new org/renjin/gcc/runtime/BytePtr
    //   2472: dup
    //   2473: ldc_w 'xsplineBounds '
    //   2476: invokevirtual getBytes : ()[B
    //   2479: iconst_0
    //   2480: invokespecial <init> : ([BI)V
    //   2483: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2488: aload_0
    //   2489: sipush #271
    //   2492: ldc_w
    //   2495: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   2498: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2503: aload_0
    //   2504: sipush #272
    //   2507: bipush #8
    //   2509: invokeinterface setAlignedInt : (II)V
    //   2514: aload_0
    //   2515: sipush #275
    //   2518: new org/renjin/gcc/runtime/BytePtr
    //   2521: dup
    //   2522: ldc_w 'xsplinePoints '
    //   2525: invokevirtual getBytes : ()[B
    //   2528: iconst_0
    //   2529: invokespecial <init> : ([BI)V
    //   2532: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2537: aload_0
    //   2538: sipush #276
    //   2541: ldc_w
    //   2544: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   2547: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2552: aload_0
    //   2553: sipush #277
    //   2556: bipush #8
    //   2558: invokeinterface setAlignedInt : (II)V
    //   2563: aload_0
    //   2564: sipush #280
    //   2567: new org/renjin/gcc/runtime/BytePtr
    //   2570: dup
    //   2571: ldc_w 'stringMetric '
    //   2574: invokevirtual getBytes : ()[B
    //   2577: iconst_0
    //   2578: invokespecial <init> : ([BI)V
    //   2581: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2586: aload_0
    //   2587: sipush #281
    //   2590: ldc_w
    //   2593: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   2596: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2601: aload_0
    //   2602: sipush #282
    //   2605: iconst_1
    //   2606: invokeinterface setAlignedInt : (II)V
    //   2611: aload_0
    //   2612: sipush #285
    //   2615: new org/renjin/gcc/runtime/BytePtr
    //   2618: dup
    //   2619: ldc_w 'validUnits '
    //   2622: invokevirtual getBytes : ()[B
    //   2625: iconst_0
    //   2626: invokespecial <init> : ([BI)V
    //   2629: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2634: aload_0
    //   2635: sipush #286
    //   2638: ldc_w
    //   2641: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   2644: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2649: aload_0
    //   2650: sipush #287
    //   2653: iconst_1
    //   2654: invokeinterface setAlignedInt : (II)V
    //   2659: aload_0
    //   2660: sipush #290
    //   2663: iconst_0
    //   2664: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   2667: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2672: aload_0
    //   2673: sipush #291
    //   2676: iconst_0
    //   2677: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   2680: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2685: aload_0
    //   2686: sipush #292
    //   2689: iconst_0
    //   2690: invokeinterface setAlignedInt : (II)V
    //   2695: getstatic org/renjin/grid/register__.callMethods : Lorg/renjin/gcc/runtime/Ptr;
    //   2698: aload_0
    //   2699: sipush #1180
    //   2702: invokeinterface memcpy : (Lorg/renjin/gcc/runtime/Ptr;I)V
    //   2707: return
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/grid-0.9.2724.jar!/org/renjin/grid/register__.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */