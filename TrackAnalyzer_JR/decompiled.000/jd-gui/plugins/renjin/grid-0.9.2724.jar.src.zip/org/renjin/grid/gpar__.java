package org.renjin.grid;

import org.renjin.gcc.runtime.BytePtr;
import org.renjin.gcc.runtime.Ptr;
import org.renjin.gcc.runtime.Stdlib;
import org.renjin.gnur.api.Rinternals;
import org.renjin.gnur.api.Rinternals2;
import org.renjin.grDevices.baseEngine__;
import org.renjin.grDevices.colors__;
import org.renjin.sexp.SEXP;

public class gpar__ {
  static {
  
  }
  
  public static SEXP L_getGPar() {
    return state__.gridStateElement(grid__.getDevice(), 5);
  }
  
  public static SEXP L_getGPsaved() {
    return state__.gridStateElement(grid__.getDevice(), 6);
  }
  
  public static SEXP L_setGPar(SEXP paramSEXP) {
    state__.setGridStateElement(grid__.getDevice(), 5, paramSEXP);
    return Rinternals.R_NilValue;
  }
  
  public static SEXP L_setGPsaved(SEXP paramSEXP) {
    state__.setGridStateElement(grid__.getDevice(), 6, paramSEXP);
    return Rinternals.R_NilValue;
  }
  
  public static int combineAlpha(double paramDouble, int paramInt) {
    return (int)(long)((paramInt >>> 24) / 255.0D * paramDouble * 255.0D) << 24 | paramInt & 0xFFFFFF;
  }
  
  public static void gcontextFromgpar(SEXP paramSEXP, int paramInt, Ptr paramPtr1, Ptr paramPtr2) {
    int i = gpCol(paramSEXP, paramInt);
    paramPtr1.setInt(combineAlpha(gpAlpha(paramSEXP, paramInt), i));
    i = gpFill(paramSEXP, paramInt);
    paramPtr1.setAlignedInt(1, combineAlpha(gpAlpha(paramSEXP, paramInt), i));
    paramPtr1.setAlignedDouble(1, gpGamma(paramSEXP, paramInt));
    paramPtr1.setAlignedDouble(2, gpLineWidth(paramSEXP, paramInt) * gpLex(paramSEXP, paramInt) * Rinternals2.REAL(state__.gridStateElement(paramPtr2, 15)).getDouble());
    paramPtr1.setAlignedInt(6, gpLineType(paramSEXP, paramInt));
    paramPtr1.setAlignedInt(7, gpLineEnd(paramSEXP, paramInt));
    paramPtr1.setAlignedInt(8, gpLineJoin(paramSEXP, paramInt));
    paramPtr1.setDouble(36, gpLineMitre(paramSEXP, paramInt));
    paramPtr1.setDouble(44, gpCex(paramSEXP, paramInt));
    paramPtr1.setDouble(52, gpFontSize(paramSEXP, paramInt) * Rinternals2.REAL(state__.gridStateElement(paramPtr2, 15)).getDouble());
    paramPtr1.setDouble(60, gpLineHeight(paramSEXP, paramInt));
    paramPtr1.setAlignedInt(17, gpFont(paramSEXP, paramInt));
    Ptr ptr = gpFontFamily(paramSEXP, paramInt);
    Stdlib.strcpy(paramPtr1.pointerPlus(72), ptr);
  }
  
  public static double gpAlpha(SEXP paramSEXP, int paramInt) {
    Ptr ptr = Rinternals2.REAL(gpAlphaSXP(paramSEXP));
    int i = 0 + paramInt % Rinternals.LENGTH(gpAlphaSXP(paramSEXP)) * 8;
    return ptr.getDouble(i);
  }
  
  public static SEXP gpAlphaSXP(SEXP paramSEXP) {
    return Rinternals.VECTOR_ELT(paramSEXP, 10);
  }
  
  public static double gpCex(SEXP paramSEXP, int paramInt) {
    Ptr ptr = Rinternals2.REAL(gpCexSXP(paramSEXP));
    int i = 0 + paramInt % Rinternals.LENGTH(gpCexSXP(paramSEXP)) * 8;
    return ptr.getDouble(i);
  }
  
  public static SEXP gpCexSXP(SEXP paramSEXP) {
    return Rinternals.VECTOR_ELT(paramSEXP, 5);
  }
  
  public static int gpCol(SEXP paramSEXP, int paramInt) {
    paramSEXP = Rinternals.VECTOR_ELT(paramSEXP, 1);
    return !Rinternals.Rf_isNull(paramSEXP) ? colors__.Rf_RGBpar3(paramSEXP, paramInt % Rinternals.LENGTH(paramSEXP), 16777215) : 16777215;
  }
  
  public static int gpFill(SEXP paramSEXP, int paramInt) {
    paramSEXP = gpFillSXP(paramSEXP);
    return !Rinternals.Rf_isNull(paramSEXP) ? colors__.Rf_RGBpar3(paramSEXP, paramInt % Rinternals.LENGTH(paramSEXP), 16777215) : 16777215;
  }
  
  public static SEXP gpFillSXP(SEXP paramSEXP) {
    return Rinternals.VECTOR_ELT(paramSEXP, 0);
  }
  
  public static int gpFont(SEXP paramSEXP, int paramInt) {
    Ptr ptr = Rinternals2.INTEGER(gpFontSXP(paramSEXP));
    int i = 0 + paramInt % Rinternals.LENGTH(gpFontSXP(paramSEXP)) * 4;
    return ptr.getInt(i);
  }
  
  public static Ptr gpFontFamily(SEXP paramSEXP, int paramInt) {
    int i = Rinternals.LENGTH(gpFontFamilySXP(paramSEXP));
    return (Ptr)Rinternals.R_CHAR(Rinternals.STRING_ELT(gpFontFamilySXP(paramSEXP), paramInt % i));
  }
  
  public static SEXP gpFontFamilySXP(SEXP paramSEXP) {
    return Rinternals.VECTOR_ELT(paramSEXP, 9);
  }
  
  public static SEXP gpFontSXP(SEXP paramSEXP) {
    return Rinternals.VECTOR_ELT(paramSEXP, 8);
  }
  
  public static double gpFontSize(SEXP paramSEXP, int paramInt) {
    Ptr ptr = Rinternals2.REAL(gpFontSizeSXP(paramSEXP));
    int i = 0 + paramInt % Rinternals.LENGTH(gpFontSizeSXP(paramSEXP)) * 8;
    return ptr.getDouble(i);
  }
  
  public static SEXP gpFontSizeSXP(SEXP paramSEXP) {
    return Rinternals.VECTOR_ELT(paramSEXP, 6);
  }
  
  public static double gpGamma(SEXP paramSEXP, int paramInt) {
    Ptr ptr = Rinternals2.REAL(gpGammaSXP(paramSEXP));
    int i = 0 + paramInt % Rinternals.LENGTH(gpGammaSXP(paramSEXP)) * 8;
    return ptr.getDouble(i);
  }
  
  public static SEXP gpGammaSXP(SEXP paramSEXP) {
    return Rinternals.VECTOR_ELT(paramSEXP, 2);
  }
  
  public static double gpLex(SEXP paramSEXP, int paramInt) {
    Ptr ptr = Rinternals2.REAL(gpLexSXP(paramSEXP));
    int i = 0 + paramInt % Rinternals.LENGTH(gpLexSXP(paramSEXP)) * 8;
    return ptr.getDouble(i);
  }
  
  public static SEXP gpLexSXP(SEXP paramSEXP) {
    return Rinternals.VECTOR_ELT(paramSEXP, 14);
  }
  
  public static int gpLineEnd(SEXP paramSEXP, int paramInt) {
    int i = Rinternals.LENGTH(gpLineEndSXP(paramSEXP));
    return baseEngine__.GE_LENDpar(gpLineEndSXP(paramSEXP), paramInt % i);
  }
  
  public static SEXP gpLineEndSXP(SEXP paramSEXP) {
    return Rinternals.VECTOR_ELT(paramSEXP, 11);
  }
  
  public static double gpLineHeight(SEXP paramSEXP, int paramInt) {
    Ptr ptr = Rinternals2.REAL(gpLineHeightSXP(paramSEXP));
    int i = 0 + paramInt % Rinternals.LENGTH(gpLineHeightSXP(paramSEXP)) * 8;
    return ptr.getDouble(i);
  }
  
  public static SEXP gpLineHeightSXP(SEXP paramSEXP) {
    return Rinternals.VECTOR_ELT(paramSEXP, 7);
  }
  
  public static int gpLineJoin(SEXP paramSEXP, int paramInt) {
    int i = Rinternals.LENGTH(gpLineJoinSXP(paramSEXP));
    return baseEngine__.GE_LJOINpar(gpLineJoinSXP(paramSEXP), paramInt % i);
  }
  
  public static SEXP gpLineJoinSXP(SEXP paramSEXP) {
    return Rinternals.VECTOR_ELT(paramSEXP, 12);
  }
  
  public static double gpLineMitre(SEXP paramSEXP, int paramInt) {
    Ptr ptr = Rinternals2.REAL(gpLineMitreSXP(paramSEXP));
    int i = 0 + paramInt % Rinternals.LENGTH(gpLineMitreSXP(paramSEXP)) * 8;
    return ptr.getDouble(i);
  }
  
  public static SEXP gpLineMitreSXP(SEXP paramSEXP) {
    return Rinternals.VECTOR_ELT(paramSEXP, 13);
  }
  
  public static int gpLineType(SEXP paramSEXP, int paramInt) {
    int i = Rinternals.LENGTH(gpLineTypeSXP(paramSEXP));
    return baseEngine__.GE_LTYpar(gpLineTypeSXP(paramSEXP), paramInt % i);
  }
  
  public static SEXP gpLineTypeSXP(SEXP paramSEXP) {
    return Rinternals.VECTOR_ELT(paramSEXP, 3);
  }
  
  public static double gpLineWidth(SEXP paramSEXP, int paramInt) {
    Ptr ptr = Rinternals2.REAL(gpLineWidthSXP(paramSEXP));
    int i = 0 + paramInt % Rinternals.LENGTH(gpLineWidthSXP(paramSEXP)) * 8;
    return ptr.getDouble(i);
  }
  
  public static SEXP gpLineWidthSXP(SEXP paramSEXP) {
    return Rinternals.VECTOR_ELT(paramSEXP, 4);
  }
  
  public static void initGPar(Ptr paramPtr) {
    Ptr ptr = paramPtr.getPointer();
    SEXP sEXP1 = Rinternals.Rf_allocVector(19, 15);
    Rinternals.Rf_protect(sEXP1);
    SEXP sEXP3 = Rinternals.Rf_allocVector(16, 15);
    Rinternals.Rf_protect(sEXP3);
    Rinternals.SET_STRING_ELT(sEXP3, 0, Rinternals.Rf_mkChar((Ptr)new BytePtr("fill\000".getBytes(), 0)));
    Rinternals.SET_STRING_ELT(sEXP3, 1, Rinternals.Rf_mkChar((Ptr)new BytePtr("col\000".getBytes(), 0)));
    Rinternals.SET_STRING_ELT(sEXP3, 2, Rinternals.Rf_mkChar((Ptr)new BytePtr("gamma\000".getBytes(), 0)));
    Rinternals.SET_STRING_ELT(sEXP3, 3, Rinternals.Rf_mkChar((Ptr)new BytePtr("lty\000".getBytes(), 0)));
    Rinternals.SET_STRING_ELT(sEXP3, 4, Rinternals.Rf_mkChar((Ptr)new BytePtr("lwd\000".getBytes(), 0)));
    Rinternals.SET_STRING_ELT(sEXP3, 5, Rinternals.Rf_mkChar((Ptr)new BytePtr("cex\000".getBytes(), 0)));
    Rinternals.SET_STRING_ELT(sEXP3, 6, Rinternals.Rf_mkChar((Ptr)new BytePtr("fontsize\000".getBytes(), 0)));
    Rinternals.SET_STRING_ELT(sEXP3, 7, Rinternals.Rf_mkChar((Ptr)new BytePtr("lineheight\000".getBytes(), 0)));
    Rinternals.SET_STRING_ELT(sEXP3, 8, Rinternals.Rf_mkChar((Ptr)new BytePtr("font\000".getBytes(), 0)));
    Rinternals.SET_STRING_ELT(sEXP3, 9, Rinternals.Rf_mkChar((Ptr)new BytePtr("fontfamily\000".getBytes(), 0)));
    Rinternals.SET_STRING_ELT(sEXP3, 10, Rinternals.Rf_mkChar((Ptr)new BytePtr("alpha\000".getBytes(), 0)));
    Rinternals.SET_STRING_ELT(sEXP3, 11, Rinternals.Rf_mkChar((Ptr)new BytePtr("lineend\000".getBytes(), 0)));
    Rinternals.SET_STRING_ELT(sEXP3, 12, Rinternals.Rf_mkChar((Ptr)new BytePtr("linejoin\000".getBytes(), 0)));
    Rinternals.SET_STRING_ELT(sEXP3, 13, Rinternals.Rf_mkChar((Ptr)new BytePtr("linemitre\000".getBytes(), 0)));
    Rinternals.SET_STRING_ELT(sEXP3, 14, Rinternals.Rf_mkChar((Ptr)new BytePtr("lex\000".getBytes(), 0)));
    Rinternals.Rf_setAttrib(sEXP1, Rinternals.R_NamesSymbol, sEXP3);
    sEXP3 = Rinternals.Rf_allocVector(16, 1);
    Rinternals.Rf_protect(sEXP3);
    Rinternals.SET_STRING_ELT(sEXP3, 0, Rinternals.Rf_mkChar(colors__.Rf_col2name(ptr.getInt(152))));
    Rinternals.SET_VECTOR_ELT(sEXP1, 0, sEXP3);
    sEXP3 = Rinternals.Rf_allocVector(16, 1);
    Rinternals.Rf_protect(sEXP3);
    Rinternals.SET_STRING_ELT(sEXP3, 0, Rinternals.Rf_mkChar(colors__.Rf_col2name(ptr.getInt(148))));
    Rinternals.SET_VECTOR_ELT(sEXP1, 1, sEXP3);
    sEXP3 = Rinternals.Rf_allocVector(14, 1);
    Rinternals.Rf_protect(sEXP3);
    Rinternals2.REAL(sEXP3).setDouble(0, ptr.getDouble(164));
    Rinternals.SET_VECTOR_ELT(sEXP1, 2, sEXP3);
    Rinternals.Rf_protect(baseEngine__.GE_LTYget(ptr.getInt(156)));
    Rinternals.SET_VECTOR_ELT(sEXP1, 3, baseEngine__.GE_LTYget(ptr.getInt(156)));
    sEXP3 = Rinternals.Rf_allocVector(14, 1);
    Rinternals.Rf_protect(sEXP3);
    Rinternals2.REAL(sEXP3).setDouble(0, 1.0D);
    Rinternals.SET_VECTOR_ELT(sEXP1, 4, sEXP3);
    sEXP3 = Rinternals.Rf_allocVector(14, 1);
    Rinternals.Rf_protect(sEXP3);
    Rinternals2.REAL(sEXP3).setDouble(0, 1.0D);
    Rinternals.SET_VECTOR_ELT(sEXP1, 5, sEXP3);
    sEXP3 = Rinternals.Rf_allocVector(14, 1);
    Rinternals.Rf_protect(sEXP3);
    Rinternals2.REAL(sEXP3).setDouble(0, ptr.getDouble(140));
    Rinternals.SET_VECTOR_ELT(sEXP1, 6, sEXP3);
    sEXP3 = Rinternals.Rf_allocVector(14, 1);
    Rinternals.Rf_protect(sEXP3);
    Rinternals2.REAL(sEXP3).setDouble(0, 1.2D);
    Rinternals.SET_VECTOR_ELT(sEXP1, 7, sEXP3);
    sEXP3 = Rinternals.Rf_allocVector(13, 1);
    Rinternals.Rf_protect(sEXP3);
    Rinternals2.INTEGER(sEXP3).setInt(0, ptr.getInt(160));
    Rinternals.SET_VECTOR_ELT(sEXP1, 8, sEXP3);
    SEXP sEXP2 = Rinternals.Rf_allocVector(16, 1);
    Rinternals.Rf_protect(sEXP2);
    Rinternals.SET_STRING_ELT(sEXP2, 0, Rinternals.Rf_mkChar((Ptr)new BytePtr("\000".getBytes(), 0)));
    Rinternals.SET_VECTOR_ELT(sEXP1, 9, sEXP2);
    sEXP2 = Rinternals.Rf_allocVector(14, 1);
    Rinternals.Rf_protect(sEXP2);
    Rinternals2.REAL(sEXP2).setDouble(0, 1.0D);
    Rinternals.SET_VECTOR_ELT(sEXP1, 10, sEXP2);
    sEXP2 = Rinternals.Rf_allocVector(16, 1);
    Rinternals.Rf_protect(sEXP2);
    Rinternals.SET_STRING_ELT(sEXP2, 0, Rinternals.Rf_mkChar((Ptr)new BytePtr("round\000".getBytes(), 0)));
    Rinternals.SET_VECTOR_ELT(sEXP1, 11, sEXP2);
    sEXP2 = Rinternals.Rf_allocVector(16, 1);
    Rinternals.Rf_protect(sEXP2);
    Rinternals.SET_STRING_ELT(sEXP2, 0, Rinternals.Rf_mkChar((Ptr)new BytePtr("round\000".getBytes(), 0)));
    Rinternals.SET_VECTOR_ELT(sEXP1, 12, sEXP2);
    sEXP2 = Rinternals.Rf_allocVector(14, 1);
    Rinternals.Rf_protect(sEXP2);
    Rinternals2.REAL(sEXP2).setDouble(0, 10.0D);
    Rinternals.SET_VECTOR_ELT(sEXP1, 13, sEXP2);
    sEXP2 = Rinternals.Rf_allocVector(14, 1);
    Rinternals.Rf_protect(sEXP2);
    Rinternals2.REAL(sEXP2).setDouble(0, 1.0D);
    Rinternals.SET_VECTOR_ELT(sEXP1, 14, sEXP2);
    sEXP2 = Rinternals.Rf_allocVector(16, 1);
    Rinternals.Rf_protect(sEXP2);
    Rinternals.SET_STRING_ELT(sEXP2, 0, Rinternals.Rf_mkChar((Ptr)new BytePtr("gpar\000".getBytes(), 0)));
    Rinternals.SET_VECTOR_ELT((SEXP)paramPtr.getPointer(28 + matrix__.gridRegisterIndex * 4).getPointer().getArray(), 5, Rinternals.Rf_classgets(sEXP1, sEXP2));
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/grid-0.9.2724.jar!/org/renjin/grid/gpar__.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */