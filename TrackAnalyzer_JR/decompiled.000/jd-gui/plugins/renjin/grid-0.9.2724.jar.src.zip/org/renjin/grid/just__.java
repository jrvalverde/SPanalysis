package org.renjin.grid;

import org.renjin.gcc.runtime.Ptr;

public class just__ {
  static {
  
  }
  
  public static double convertJust(int paramInt) {
    double d = 0.0D;
    switch (paramInt) {
      case 0:
      case 2:
        d = 0.0D;
        break;
      case 4:
      case 5:
        d = 0.5D;
        break;
      case 1:
      case 3:
        d = 1.0D;
        break;
    } 
    return d;
  }
  
  public static void justification(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, Ptr paramPtr1, Ptr paramPtr2) {
    paramPtr1.setDouble(-paramDouble1 * paramDouble3);
    paramPtr2.setDouble(-paramDouble2 * paramDouble4);
  }
  
  public static double justifyX(double paramDouble1, double paramDouble2, double paramDouble3) {
    return paramDouble1 - paramDouble2 * paramDouble3;
  }
  
  public static double justifyY(double paramDouble1, double paramDouble2, double paramDouble3) {
    return paramDouble1 - paramDouble2 * paramDouble3;
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/grid-0.9.2724.jar!/org/renjin/grid/just__.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */