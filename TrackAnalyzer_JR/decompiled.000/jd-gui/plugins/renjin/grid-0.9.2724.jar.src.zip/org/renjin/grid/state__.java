package org.renjin.grid;

import org.renjin.gcc.runtime.BytePtr;
import org.renjin.gcc.runtime.MixedPtr;
import org.renjin.gcc.runtime.Ptr;
import org.renjin.gcc.runtime.RecordUnitPtr;
import org.renjin.gcc.runtime.Stdlib;
import org.renjin.gnur.api.Arith;
import org.renjin.gnur.api.Error;
import org.renjin.gnur.api.GetText;
import org.renjin.gnur.api.Rinternals;
import org.renjin.gnur.api.Rinternals2;
import org.renjin.gnur.api.Rmath;
import org.renjin.grDevices.baseDevices__;
import org.renjin.grDevices.baseEngine__;
import org.renjin.sexp.SEXP;

public class state__ {
  static {
  
  }
  
  public static SEXP createGridSystemState() {
    return Rinternals.Rf_allocVector(19, 16);
  }
  
  public static void deglobaliseState(SEXP paramSEXP) {
    int i = Rinternals2.INTEGER(Rinternals.VECTOR_ELT(paramSEXP, 8)).getInt();
    SEXP sEXP2 = Rinternals.R_NilValue;
    SEXP sEXP1 = grid__.R_gridEvalEnv;
    Rinternals.SET_VECTOR_ELT(Rinternals.Rf_findVar(Rinternals.Rf_install(new BytePtr(".GRID.STATE\000".getBytes(), 0)), sEXP1), i, sEXP2);
  }
  
  public static void fillGridSystemState(SEXP paramSEXP, Ptr paramPtr) {
    Rinternals.Rf_protect(paramSEXP);
    SEXP sEXP = Rinternals.Rf_allocVector(14, 2);
    Rinternals2.REAL(sEXP).setDouble(0, 0.0D);
    Rinternals2.REAL(sEXP).setDouble(8, 0.0D);
    Rinternals.SET_VECTOR_ELT(paramSEXP, 0, sEXP);
    sEXP = Rinternals.Rf_allocVector(14, 2);
    Rinternals2.REAL(sEXP).setDouble(0, Arith.R_NaReal);
    Rinternals2.REAL(sEXP).setDouble(8, Arith.R_NaReal);
    Rinternals.SET_VECTOR_ELT(paramSEXP, 1, sEXP);
    sEXP = Rinternals.Rf_allocVector(14, 2);
    Rinternals2.REAL(sEXP).setDouble(0, Arith.R_NaReal);
    Rinternals2.REAL(sEXP).setDouble(8, Arith.R_NaReal);
    Rinternals.SET_VECTOR_ELT(paramSEXP, 10, sEXP);
    Rinternals.SET_VECTOR_ELT(paramSEXP, 4, Rinternals.Rf_ScalarLogical(1));
    Rinternals.SET_VECTOR_ELT(paramSEXP, 11, Rinternals.Rf_ScalarLogical(1));
    Rinternals.SET_VECTOR_ELT(paramSEXP, 12, Rinternals.R_NilValue);
    Rinternals.SET_VECTOR_ELT(paramSEXP, 13, Rinternals.Rf_ScalarLogical(0));
    gpar__.initGPar(paramPtr);
    Rinternals.SET_VECTOR_ELT(paramSEXP, 6, Rinternals.R_NilValue);
    Rinternals.SET_VECTOR_ELT(paramSEXP, 8, Rinternals.R_NilValue);
    Rinternals.SET_VECTOR_ELT(paramSEXP, 9, Rinternals.Rf_ScalarLogical(0));
    Rinternals.SET_VECTOR_ELT(paramSEXP, 15, Rinternals.Rf_ScalarReal(1.0D));
  }
  
  public static int findStateSlot() {
    SEXP sEXP2 = (SEXP)BytePtr.of(0).getArray();
    byte b = -1;
    SEXP sEXP1 = grid__.R_gridEvalEnv;
    sEXP1 = Rinternals.Rf_findVar(Rinternals.Rf_install(new BytePtr(".GRID.STATE\000".getBytes(), 0)), sEXP1);
    byte b1 = 0;
    while (Rinternals.Rf_length(sEXP1) > b1) {
      if (Rinternals.VECTOR_ELT(sEXP1, b1) != Rinternals.R_NilValue) {
        b1++;
        continue;
      } 
      b = b1;
      break;
    } 
    if (b < 0)
      Error.Rf_error(GetText.dgettext(new BytePtr("grid\000".getBytes(), 0), new BytePtr("unable to store 'grid' state.  Too many devices open?\000".getBytes(), 0)), new Object[0]); 
    return b;
  }
  
  public static void globaliseState(SEXP paramSEXP) {
    int i = findStateSlot();
    SEXP sEXP = grid__.R_gridEvalEnv;
    Rinternals.Rf_protect(Rinternals.Rf_findVar(Rinternals.Rf_install(new BytePtr(".GRID.STATE\000".getBytes(), 0)), sEXP));
    sEXP = Rinternals.Rf_allocVector(13, 1);
    Rinternals.Rf_protect(sEXP);
    Rinternals2.INTEGER(sEXP).setInt(0, i);
    Rinternals.SET_VECTOR_ELT(paramSEXP, 8, sEXP);
    Rinternals.SET_VECTOR_ELT(Rinternals.Rf_findVar(Rinternals.Rf_install(new BytePtr(".GRID.STATE\000".getBytes(), 0)), sEXP), i, paramSEXP);
  }
  
  public static SEXP gridCallback(int paramInt, Ptr paramPtr, SEXP paramSEXP) {
    SEXP sEXP1;
    Ptr ptr1;
    SEXP sEXP2;
    Ptr ptr2;
    int i;
    Ptr ptr3;
    MixedPtr mixedPtr = MixedPtr.malloc(276);
    SEXP sEXP3 = (SEXP)BytePtr.of(0).getArray();
    sEXP3 = (SEXP)BytePtr.of(0).getArray();
    sEXP3 = Rinternals.R_NilValue;
    switch (paramInt) {
      case 0:
        sEXP1 = createGridSystemState();
        Rinternals.Rf_protect(sEXP1);
        paramPtr.getPointer(28 + matrix__.gridRegisterIndex * 4).setPointer(0, (Ptr)new RecordUnitPtr(sEXP1));
        fillGridSystemState(sEXP1, paramPtr);
        globaliseState(sEXP1);
        sEXP3 = Rinternals.R_BlankString;
        break;
      case 1:
        deglobaliseState((SEXP)paramPtr.getPointer(28 + matrix__.gridRegisterIndex * 4).getPointer(0).getArray());
        paramPtr.getPointer(28 + matrix__.gridRegisterIndex * 4).setPointer(0, BytePtr.of(0));
        break;
      case 6:
        sEXP1 = Rinternals.Rf_allocVector(14, 2);
        Rinternals.Rf_protect(sEXP1);
        ptr2 = Rinternals2.REAL(sEXP1);
        ptr3 = Rinternals2.REAL(sEXP1).pointerPlus(8);
        grid__.getDeviceSize(paramPtr, ptr2, ptr3);
        Rinternals.SET_VECTOR_ELT((SEXP)paramPtr.getPointer(28 + matrix__.gridRegisterIndex * 4).getPointer().getArray(), 0, sEXP1);
        if (Rinternals.LOGICAL(gridStateElement(paramPtr, 9)).getInt() == 0)
          break; 
        if (Rinternals.LOGICAL(gridStateElement(paramPtr, 11)).getInt() == 0) {
          Rinternals.Rf_protect(Rinternals.Rf_lang1(Rinternals.Rf_install(new BytePtr("draw.all\000".getBytes(), 0))));
          Rinternals.Rf_eval(Rinternals.Rf_lang1(Rinternals.Rf_install(new BytePtr("draw.all\000".getBytes(), 0))), grid__.R_gridEvalEnv);
          break;
        } 
        if (paramSEXP != Rinternals.R_NilValue) {
          paramSEXP = Rinternals.CADR(Rinternals.CAR(paramSEXP));
          boolean bool = true;
          if (Rinternals.Rf_isVector(Rinternals.CAR(paramSEXP))) {
            paramSEXP = Rinternals.VECTOR_ELT(Rinternals.CAR(paramSEXP), 0);
            if (Rinternals.Rf_isString(paramSEXP) && (Stdlib.strcmp((Ptr)Rinternals.R_CHAR(Rinternals.STRING_ELT(paramSEXP, 0)), (Ptr)new BytePtr("C_par\000".getBytes(), 0)) == 0 || Stdlib.strcmp((Ptr)Rinternals.R_CHAR(Rinternals.STRING_ELT(paramSEXP, 0)), (Ptr)new BytePtr("C_plot_new\000".getBytes(), 0)) == 0))
              bool = false; 
          } 
          if (bool) {
            gpar__.gcontextFromgpar(gridStateElement(paramPtr, 5), 0, (Ptr)mixedPtr, paramPtr);
            baseEngine__.GENewPage((Ptr)mixedPtr, paramPtr);
          } 
        } 
        gpar__.initGPar(paramPtr);
        viewport__.initVP(paramPtr);
        initOtherState(paramPtr);
        break;
      case 3:
        if (Rinternals.Rf_isNull(gridStateElement(paramPtr, 2)) || Rinternals2.INTEGER(gridStateElement(paramPtr, 3)).getInt() <= 0)
          break; 
        ptr1 = baseDevices__.GEcurrentDevice();
        sEXP1 = Rinternals.Rf_allocVector(10, 1);
        Rinternals.Rf_protect(sEXP1);
        Rinternals.LOGICAL(sEXP1).setInt(0, 1);
        Rinternals.SET_VECTOR_ELT((SEXP)ptr1.getPointer(28 + matrix__.gridRegisterIndex * 4).getPointer().getArray(), 9, sEXP1);
        baseEngine__.GEdirtyDevice(ptr1);
        setGridStateElement(ptr1, 2, gridStateElement(paramPtr, 2));
        setGridStateElement(ptr1, 3, gridStateElement(paramPtr, 3));
        break;
      case 7:
        sEXP1 = Rinternals.Rf_allocVector(10, 1);
        Rinternals.Rf_protect(sEXP1);
        Rinternals.LOGICAL(sEXP1).setInt(0, 1);
        sEXP3 = sEXP1;
        break;
      case 4:
        sEXP3 = Rinternals.Rf_allocVector(19, 2);
        Rinternals.Rf_protect(sEXP3);
        Rinternals.SET_VECTOR_ELT(sEXP3, 0, gridStateElement(paramPtr, 2));
        Rinternals.SET_VECTOR_ELT(sEXP3, 1, gridStateElement(paramPtr, 3));
        sEXP1 = Rinternals.Rf_mkString((Ptr)new BytePtr("grid\000".getBytes(), 0));
        Rinternals.Rf_protect(sEXP1);
        Rinternals.Rf_setAttrib(sEXP3, Rinternals.Rf_install(new BytePtr("pkgName\000".getBytes(), 0)), sEXP1);
        break;
      case 5:
        i = Rinternals.LENGTH((SEXP)ptr1) + -1;
        sEXP1 = Rinternals.R_NilValue;
        Rinternals.Rf_protect(sEXP1);
        Rinternals.Rf_protect(Rinternals.Rf_getAttrib((SEXP)ptr1, Rinternals.Rf_install(new BytePtr("engineVersion\000".getBytes(), 0))));
        if (!Rinternals.Rf_isNull(Rinternals.Rf_getAttrib((SEXP)ptr1, Rinternals.Rf_install(new BytePtr("engineVersion\000".getBytes(), 0))))) {
          for (byte b = 0; b < i; b++) {
            SEXP sEXP = Rinternals.VECTOR_ELT((SEXP)ptr1, b + 1);
            if (Stdlib.strcmp((Ptr)Rinternals.R_CHAR(Rinternals.STRING_ELT(Rinternals.Rf_getAttrib(sEXP, Rinternals.Rf_install(new BytePtr("pkgName\000".getBytes(), 0))), 0)), (Ptr)new BytePtr("grid\000".getBytes(), 0)) == 0)
              sEXP1 = sEXP; 
          } 
        } else {
          sEXP1 = Rinternals.VECTOR_ELT((SEXP)ptr1, Rmath.Rf_imin2(i, 2));
        } 
        if (Rinternals.Rf_isNull(sEXP1) || Rinternals.Rf_isNull(Rinternals.VECTOR_ELT(sEXP1, 0)) || Rinternals2.INTEGER(Rinternals.VECTOR_ELT(sEXP1, 1)).getInt() <= 0)
          break; 
        if (Rinternals.LOGICAL(gridStateElement(paramPtr, 9)).getInt() == 0) {
          sEXP2 = Rinternals.Rf_allocVector(10, 1);
          Rinternals.Rf_protect(sEXP2);
          Rinternals.LOGICAL(sEXP2).setInt(0, 1);
          Rinternals.SET_VECTOR_ELT((SEXP)paramPtr.getPointer(28 + matrix__.gridRegisterIndex * 4).getPointer().getArray(), 9, sEXP2);
          baseEngine__.GEdirtyDevice(paramPtr);
        } 
        setGridStateElement(paramPtr, 2, Rinternals.VECTOR_ELT(sEXP1, 0));
        setGridStateElement(paramPtr, 3, Rinternals.VECTOR_ELT(sEXP1, 1));
        break;
      case 8:
        sEXP1 = Rinternals.Rf_allocVector(14, 1);
        Rinternals.Rf_protect(sEXP1);
        Rinternals2.REAL(sEXP1).setDouble(0, Rinternals2.REAL(gridStateElement(paramPtr, 15)).getDouble() * Rinternals2.REAL(sEXP2).getDouble());
        setGridStateElement(paramPtr, 15, sEXP1);
        break;
    } 
    return sEXP3;
  }
  
  public static SEXP gridStateElement(Ptr paramPtr, int paramInt) {
    return Rinternals.VECTOR_ELT((SEXP)paramPtr.getPointer(28 + matrix__.gridRegisterIndex * 4).getPointer().getArray(), paramInt);
  }
  
  public static void initDL(Ptr paramPtr) {
    SEXP sEXP2 = gridStateElement(paramPtr, 7);
    SEXP sEXP1 = Rinternals.Rf_allocVector(19, 100);
    Rinternals.Rf_protect(sEXP1);
    Rinternals.SET_VECTOR_ELT(sEXP1, 0, sEXP2);
    Rinternals.SET_VECTOR_ELT((SEXP)paramPtr.getPointer(28 + matrix__.gridRegisterIndex * 4).getPointer().getArray(), 2, sEXP1);
    sEXP1 = Rinternals.Rf_allocVector(13, 1);
    Rinternals.Rf_protect(sEXP1);
    Rinternals2.INTEGER(sEXP1).setInt(0, 1);
    Rinternals.SET_VECTOR_ELT((SEXP)paramPtr.getPointer(28 + matrix__.gridRegisterIndex * 4).getPointer().getArray(), 3, sEXP1);
  }
  
  public static void initOtherState(Ptr paramPtr) {
    SEXP sEXP = (SEXP)paramPtr.getPointer(28 + matrix__.gridRegisterIndex * 4).getPointer().getArray();
    Rinternals2.REAL(Rinternals.VECTOR_ELT(sEXP, 1)).setDouble(0, Arith.R_NaReal);
    Rinternals2.REAL(Rinternals.VECTOR_ELT(sEXP, 1)).setDouble(8, Arith.R_NaReal);
    Rinternals2.REAL(Rinternals.VECTOR_ELT(sEXP, 10)).setDouble(0, Arith.R_NaReal);
    Rinternals2.REAL(Rinternals.VECTOR_ELT(sEXP, 10)).setDouble(8, Arith.R_NaReal);
    Rinternals.SET_VECTOR_ELT(sEXP, 12, Rinternals.R_NilValue);
    Rinternals.LOGICAL(Rinternals.VECTOR_ELT(sEXP, 13)).setInt(0, 0);
    Rinternals.SET_VECTOR_ELT(sEXP, 13, Rinternals.VECTOR_ELT(sEXP, 13));
  }
  
  public static void setGridStateElement(Ptr paramPtr, int paramInt, SEXP paramSEXP) {
    Rinternals.SET_VECTOR_ELT((SEXP)paramPtr.getPointer(28 + matrix__.gridRegisterIndex * 4).getPointer().getArray(), paramInt, paramSEXP);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/grid-0.9.2724.jar!/org/renjin/grid/state__.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */