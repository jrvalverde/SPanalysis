package org.renjin.grid;

import org.renjin.gcc.runtime.BytePtr;
import org.renjin.gcc.runtime.Mathlib;
import org.renjin.gcc.runtime.Ptr;
import org.renjin.gnur.api.Error;
import org.renjin.gnur.api.GetText;

public class matrix__ {
  public static int gridRegisterIndex = 0;
  
  public static void copyTransform(Ptr paramPtr1, Ptr paramPtr2) {
    for (byte b = 0; b <= 2; b++) {
      for (byte b1 = 0; b1 <= 2; b1++)
        paramPtr2.setDouble(b * 24 + b1 * 8, paramPtr1.getDouble(b * 24 + b1 * 8)); 
    } 
  }
  
  public static void identity(Ptr paramPtr) {
    for (byte b = 0; b <= 2; b++) {
      for (byte b1 = 0; b1 <= 2; b1++) {
        if (b != b1) {
          paramPtr.setDouble(b * 24 + b1 * 8, 0.0D);
        } else {
          paramPtr.setDouble(b * 24 + b1 * 8, 1.0D);
        } 
      } 
    } 
  }
  
  public static void invTransform(Ptr paramPtr1, Ptr paramPtr2) {
    double d = paramPtr1.getDouble() * (paramPtr1.getDouble(64) * paramPtr1.getDouble(32) - paramPtr1.getDouble(56) * paramPtr1.getDouble(40)) - paramPtr1.getDouble(24) * (paramPtr1.getDouble(64) * paramPtr1.getAlignedDouble(1) - paramPtr1.getDouble(56) * paramPtr1.getAlignedDouble(2)) + paramPtr1.getDouble(48) * (paramPtr1.getDouble(40) * paramPtr1.getAlignedDouble(1) - paramPtr1.getDouble(32) * paramPtr1.getAlignedDouble(2));
    if (d == 0.0D)
      Error.Rf_error(GetText.dgettext(new BytePtr("grid\000".getBytes(), 0), new BytePtr("singular transformation matrix\000".getBytes(), 0)), new Object[0]); 
    paramPtr2.setDouble(1.0D / d * (paramPtr1.getDouble(64) * paramPtr1.getDouble(32) - paramPtr1.getDouble(56) * paramPtr1.getDouble(40)));
    paramPtr2.setAlignedDouble(1, -1.0D / d * (paramPtr1.getDouble(64) * paramPtr1.getAlignedDouble(1) - paramPtr1.getDouble(56) * paramPtr1.getAlignedDouble(2)));
    paramPtr2.setAlignedDouble(2, 1.0D / d * (paramPtr1.getDouble(40) * paramPtr1.getAlignedDouble(1) - paramPtr1.getDouble(32) * paramPtr1.getAlignedDouble(2)));
    paramPtr2.setDouble(24, -1.0D / d * (paramPtr1.getDouble(64) * paramPtr1.getDouble(24) - paramPtr1.getDouble(48) * paramPtr1.getDouble(40)));
    paramPtr2.setDouble(32, 1.0D / d * (paramPtr1.getDouble(64) * paramPtr1.getDouble() - paramPtr1.getDouble(48) * paramPtr1.getAlignedDouble(2)));
    paramPtr2.setDouble(40, -1.0D / d * (paramPtr1.getDouble(40) * paramPtr1.getDouble() - paramPtr1.getDouble(24) * paramPtr1.getAlignedDouble(2)));
    paramPtr2.setDouble(48, 1.0D / d * (paramPtr1.getDouble(56) * paramPtr1.getDouble(24) - paramPtr1.getDouble(48) * paramPtr1.getDouble(32)));
    paramPtr2.setDouble(56, -1.0D / d * (paramPtr1.getDouble(56) * paramPtr1.getDouble() - paramPtr1.getDouble(48) * paramPtr1.getAlignedDouble(1)));
    paramPtr2.setDouble(64, 1.0D / d * (paramPtr1.getDouble(32) * paramPtr1.getDouble() - paramPtr1.getDouble(24) * paramPtr1.getAlignedDouble(1)));
  }
  
  public static void location(double paramDouble1, double paramDouble2, Ptr paramPtr) {
    paramPtr.setDouble(paramDouble1);
    paramPtr.setDouble(8, paramDouble2);
    paramPtr.setDouble(16, 1.0D);
  }
  
  public static double locationX(Ptr paramPtr) {
    return paramPtr.getDouble();
  }
  
  public static double locationY(Ptr paramPtr) {
    return paramPtr.getAlignedDouble(1);
  }
  
  public static void multiply(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3) {
    paramPtr3.setDouble(paramPtr1.getDouble() * paramPtr2.getDouble() + paramPtr1.getAlignedDouble(1) * paramPtr2.getDouble(24) + paramPtr1.getAlignedDouble(2) * paramPtr2.getDouble(48));
    paramPtr3.setAlignedDouble(1, paramPtr1.getDouble() * paramPtr2.getAlignedDouble(1) + paramPtr1.getAlignedDouble(1) * paramPtr2.getDouble(32) + paramPtr1.getAlignedDouble(2) * paramPtr2.getDouble(56));
    paramPtr3.setAlignedDouble(2, paramPtr1.getDouble() * paramPtr2.getAlignedDouble(2) + paramPtr1.getAlignedDouble(1) * paramPtr2.getDouble(40) + paramPtr1.getAlignedDouble(2) * paramPtr2.getDouble(64));
    paramPtr3.setDouble(24, paramPtr1.getDouble(24) * paramPtr2.getDouble() + paramPtr1.getDouble(32) * paramPtr2.getDouble(24) + paramPtr1.getDouble(40) * paramPtr2.getDouble(48));
    paramPtr3.setDouble(32, paramPtr1.getDouble(24) * paramPtr2.getAlignedDouble(1) + paramPtr1.getDouble(32) * paramPtr2.getDouble(32) + paramPtr1.getDouble(40) * paramPtr2.getDouble(56));
    paramPtr3.setDouble(40, paramPtr1.getDouble(24) * paramPtr2.getAlignedDouble(2) + paramPtr1.getDouble(32) * paramPtr2.getDouble(40) + paramPtr1.getDouble(40) * paramPtr2.getDouble(64));
    paramPtr3.setDouble(48, paramPtr1.getDouble(48) * paramPtr2.getDouble() + paramPtr1.getDouble(56) * paramPtr2.getDouble(24) + paramPtr1.getDouble(64) * paramPtr2.getDouble(48));
    paramPtr3.setDouble(56, paramPtr1.getDouble(48) * paramPtr2.getAlignedDouble(1) + paramPtr1.getDouble(56) * paramPtr2.getDouble(32) + paramPtr1.getDouble(64) * paramPtr2.getDouble(56));
    paramPtr3.setDouble(64, paramPtr1.getDouble(48) * paramPtr2.getAlignedDouble(2) + paramPtr1.getDouble(56) * paramPtr2.getDouble(40) + paramPtr1.getDouble(64) * paramPtr2.getDouble(64));
  }
  
  public static void rotation(double paramDouble, Ptr paramPtr) {
    double d = Mathlib.cos(paramDouble / 180.0D * Math.PI);
    paramDouble = Mathlib.sin(paramDouble / 180.0D * Math.PI);
    identity(paramPtr);
    paramPtr.setDouble(d);
    paramPtr.setAlignedDouble(1, paramDouble);
    paramPtr.setDouble(24, -paramDouble);
    paramPtr.setDouble(32, d);
  }
  
  public static void scaling(double paramDouble1, double paramDouble2, Ptr paramPtr) {
    identity(paramPtr);
    paramPtr.setDouble(paramDouble1);
    paramPtr.setDouble(32, paramDouble2);
  }
  
  public static void trans(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3) {
    paramPtr3.setDouble(paramPtr1.getDouble() * paramPtr2.getDouble() + paramPtr1.getDouble(8) * paramPtr2.getDouble(24) + paramPtr1.getDouble(16) * paramPtr2.getDouble(48));
    paramPtr3.setDouble(8, paramPtr1.getDouble() * paramPtr2.getAlignedDouble(1) + paramPtr1.getDouble(8) * paramPtr2.getDouble(32) + paramPtr1.getDouble(16) * paramPtr2.getDouble(56));
    paramPtr3.setDouble(16, paramPtr1.getDouble() * paramPtr2.getAlignedDouble(2) + paramPtr1.getDouble(8) * paramPtr2.getDouble(40) + paramPtr1.getDouble(16) * paramPtr2.getDouble(64));
  }
  
  public static void translation(double paramDouble1, double paramDouble2, Ptr paramPtr) {
    identity(paramPtr);
    paramPtr.setDouble(48, paramDouble1);
    paramPtr.setDouble(56, paramDouble2);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/grid-0.9.2724.jar!/org/renjin/grid/matrix__.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */