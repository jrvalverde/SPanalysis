package org.renjin.grid;

import org.renjin.gcc.runtime.BytePtr;
import org.renjin.gcc.runtime.DoublePtr;
import org.renjin.gcc.runtime.IntPtr;
import org.renjin.gcc.runtime.Ptr;
import org.renjin.gcc.runtime.RecordUnitPtr;
import org.renjin.gnur.api.Error;
import org.renjin.gnur.api.GetText;
import org.renjin.gnur.api.Rinternals;
import org.renjin.gnur.api.Rinternals2;
import org.renjin.sexp.SEXP;

public class layout__ {
  static {
  
  }
  
  public static void allocateKnownHeights(SEXP paramSEXP, Ptr paramPtr1, double paramDouble1, double paramDouble2, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6) {
    SEXP sEXP = (SEXP)BytePtr.of(0).getArray();
    sEXP = layoutHeights(paramSEXP);
    for (byte b = 0; layoutNRow(paramSEXP) > b; b++) {
      if (paramPtr1.getInt(b * 4) == 0) {
        paramPtr5.setDouble(b * 8, unit__.transformHeight(sEXP, b, paramPtr2.copyOf(32), paramPtr3, paramDouble1, paramDouble2, 0, 0, paramPtr4) * 2.54D);
        paramPtr6.setDouble(paramPtr6.getDouble() - paramPtr5.getDouble(b * 8));
      } 
    } 
  }
  
  public static void allocateKnownWidths(SEXP paramSEXP, Ptr paramPtr1, double paramDouble1, double paramDouble2, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6) {
    SEXP sEXP = (SEXP)BytePtr.of(0).getArray();
    sEXP = layoutWidths(paramSEXP);
    for (byte b = 0; layoutNCol(paramSEXP) > b; b++) {
      if (paramPtr1.getInt(b * 4) == 0) {
        paramPtr5.setDouble(b * 8, unit__.transformWidth(sEXP, b, paramPtr2.copyOf(32), paramPtr3, paramDouble1, paramDouble2, 0, 0, paramPtr4) * 2.54D);
        paramPtr6.setDouble(paramPtr6.getDouble() - paramPtr5.getDouble(b * 8));
      } 
    } 
  }
  
  public static void allocateRemainingHeight(SEXP paramSEXP, Ptr paramPtr1, double paramDouble, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5) {
    SEXP sEXP = (SEXP)BytePtr.of(0).getArray();
    sEXP = layoutHeights(paramSEXP);
    double d = totalUnrespectedHeight(paramSEXP, paramPtr1, paramPtr2.copyOf(32), paramPtr3, paramPtr4);
    if (d <= 0.0D) {
      setRemainingHeightZero(paramSEXP, paramPtr1, paramPtr5);
      return;
    } 
    for (byte b = 0; layoutNRow(paramSEXP) > b; b++) {
      if (paramPtr1.getInt(b * 4) != 0 && rowRespected(b, paramSEXP) == 0)
        paramPtr5.setDouble(b * 8, unit__.transformHeight(sEXP, b, paramPtr2.copyOf(32), paramPtr3, 0.0D, 0.0D, 1, 0, paramPtr4) * paramDouble / d); 
    } 
  }
  
  public static void allocateRemainingWidth(SEXP paramSEXP, Ptr paramPtr1, double paramDouble, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5) {
    SEXP sEXP = (SEXP)BytePtr.of(0).getArray();
    sEXP = layoutWidths(paramSEXP);
    double d = totalUnrespectedWidth(paramSEXP, paramPtr1, paramPtr2.copyOf(32), paramPtr3, paramPtr4);
    if (d <= 0.0D) {
      setRemainingWidthZero(paramSEXP, paramPtr1, paramPtr5);
      return;
    } 
    for (byte b = 0; layoutNCol(paramSEXP) > b; b++) {
      if (paramPtr1.getInt(b * 4) != 0 && colRespected(b, paramSEXP) == 0)
        paramPtr5.setDouble(b * 8, unit__.transformWidth(sEXP, b, paramPtr2.copyOf(32), paramPtr3, 0.0D, 0.0D, 1, 0, paramPtr4) * paramDouble / d); 
    } 
  }
  
  public static void allocateRespected(SEXP paramSEXP, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9) {
    SEXP sEXP1 = (SEXP)BytePtr.of(0).getArray();
    sEXP1 = (SEXP)BytePtr.of(0).getArray();
    SEXP sEXP2 = layoutWidths(paramSEXP);
    sEXP1 = layoutHeights(paramSEXP);
    double d1 = totalWidth(paramSEXP, paramPtr1, paramPtr5.copyOf(32), paramPtr6, paramPtr7);
    double d2 = totalHeight(paramSEXP, paramPtr2, paramPtr5.copyOf(32), paramPtr6, paramPtr7);
    double d3 = paramPtr3.getDouble();
    double d4 = paramPtr4.getDouble();
    if (layoutRespect(paramSEXP) > 0) {
      if (d4 * d1 <= d2 * d3) {
        double d5 = d2;
        double d6 = d4;
      } else {
        double d5 = d1;
        double d6 = d3;
      } 
      for (byte b2 = 0; layoutNCol(paramSEXP) > b2; b2++) {
        if (paramPtr1.getInt(b2 * 4) != 0 && colRespected(b2, paramSEXP) != 0) {
          double d5;
          double d6;
          if (d2 == 0.0D) {
            d5 = d1;
            d6 = d3;
          } 
          paramPtr8.setDouble(b2 * 8, unit__.pureNullUnitValue(sEXP2, b2) / d5 * d6);
          paramPtr3.setDouble(paramPtr3.getDouble() - paramPtr8.getDouble(b2 * 8));
        } 
      } 
      for (byte b1 = 0; layoutNRow(paramSEXP) > b1; b1++) {
        if (paramPtr2.getInt(b1 * 4) != 0 && rowRespected(b1, paramSEXP) != 0) {
          double d5;
          double d6;
          if (d1 == 0.0D) {
            d5 = d2;
            d6 = d4;
          } 
          paramPtr9.setDouble(b1 * 8, unit__.pureNullUnitValue(sEXP1, b1) / d5 * d6);
          paramPtr4.setDouble(paramPtr4.getDouble() - paramPtr9.getDouble(b1 * 8));
        } 
      } 
    } 
  }
  
  public static void calcViewportLayout(SEXP paramSEXP, double paramDouble1, double paramDouble2, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3) {
    double[] arrayOfDouble1 = new double[1];
    double[] arrayOfDouble2 = new double[1];
    BytePtr.of(0);
    BytePtr.of(0);
    SEXP sEXP3 = (SEXP)BytePtr.of(0).getArray();
    sEXP3 = (SEXP)BytePtr.of(0).getArray();
    sEXP3 = (SEXP)BytePtr.of(0).getArray();
    sEXP3 = viewport__.viewportLayout(paramSEXP);
    DoublePtr doublePtr1 = DoublePtr.malloc(layoutNCol(sEXP3) * 8);
    DoublePtr doublePtr2 = DoublePtr.malloc(layoutNRow(sEXP3) * 8);
    IntPtr intPtr2 = IntPtr.malloc(layoutNCol(sEXP3) * 4);
    IntPtr intPtr1 = IntPtr.malloc(layoutNRow(sEXP3) * 4);
    arrayOfDouble2[0] = paramDouble1;
    arrayOfDouble1[0] = paramDouble2;
    findRelWidths(sEXP3, (Ptr)intPtr2, paramPtr3);
    findRelHeights(sEXP3, (Ptr)intPtr1, paramPtr3);
    allocateKnownWidths(sEXP3, (Ptr)intPtr2, paramDouble1, paramDouble2, paramPtr1.copyOf(32), paramPtr2, paramPtr3, doublePtr1.pointerPlus(0), (Ptr)new DoublePtr(arrayOfDouble2, 0));
    allocateKnownHeights(sEXP3, (Ptr)intPtr1, paramDouble1, paramDouble2, paramPtr1.copyOf(32), paramPtr2, paramPtr3, doublePtr2.pointerPlus(0), (Ptr)new DoublePtr(arrayOfDouble1, 0));
    if (arrayOfDouble2[0] <= 0.0D && arrayOfDouble1[0] <= 0.0D) {
      setRespectedZero(sEXP3, (Ptr)intPtr2, (Ptr)intPtr1, doublePtr1.pointerPlus(0), doublePtr2.pointerPlus(0));
    } else {
      allocateRespected(sEXP3, (Ptr)intPtr2, (Ptr)intPtr1, (Ptr)new DoublePtr(arrayOfDouble2, 0), (Ptr)new DoublePtr(arrayOfDouble1, 0), paramPtr1.copyOf(32), paramPtr2, paramPtr3, doublePtr1.pointerPlus(0), doublePtr2.pointerPlus(0));
    } 
    if (arrayOfDouble2[0] <= 0.0D) {
      setRemainingWidthZero(sEXP3, (Ptr)intPtr2, doublePtr1.pointerPlus(0));
    } else {
      allocateRemainingWidth(sEXP3, (Ptr)intPtr2, arrayOfDouble2[0], paramPtr1.copyOf(32), paramPtr2, paramPtr3, doublePtr1.pointerPlus(0));
    } 
    if (arrayOfDouble1[0] <= 0.0D) {
      setRemainingHeightZero(sEXP3, (Ptr)intPtr1, doublePtr2.pointerPlus(0));
    } else {
      allocateRemainingHeight(sEXP3, (Ptr)intPtr1, arrayOfDouble1[0], paramPtr1.copyOf(32), paramPtr2, paramPtr3, doublePtr2.pointerPlus(0));
    } 
    SEXP sEXP1 = Rinternals.Rf_allocVector(14, layoutNCol(sEXP3));
    Rinternals.Rf_protect(sEXP1);
    SEXP sEXP2 = Rinternals.Rf_allocVector(14, layoutNRow(sEXP3));
    Rinternals.Rf_protect(sEXP2);
    byte b;
    for (b = 0; layoutNCol(sEXP3) > b; b++)
      Rinternals2.REAL(sEXP1).setDouble(0 + b * 8, doublePtr1.getDouble(0 + b * 8)); 
    for (b = 0; layoutNRow(sEXP3) > b; b++)
      Rinternals2.REAL(sEXP2).setDouble(0 + b * 8, doublePtr2.getDouble(0 + b * 8)); 
    Rinternals.SET_VECTOR_ELT(paramSEXP, 20, sEXP1);
    Rinternals.SET_VECTOR_ELT(paramSEXP, 21, sEXP2);
  }
  
  public static void calcViewportLocationFromLayout(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, Ptr paramPtr) {
    int i;
    boolean bool1;
    boolean bool2;
    int j;
    double[] arrayOfDouble1 = new double[1];
    double[] arrayOfDouble2 = new double[1];
    double[] arrayOfDouble3 = new double[1];
    double[] arrayOfDouble4 = new double[1];
    arrayOfDouble1[0] = 0.0D;
    arrayOfDouble2[0] = 0.0D;
    arrayOfDouble3[0] = 0.0D;
    arrayOfDouble4[0] = 0.0D;
    SEXP sEXP2 = viewport__.viewportLayout(paramSEXP3);
    if (!Rinternals.Rf_isNull(paramSEXP1)) {
      bool1 = Rinternals2.INTEGER(paramSEXP1).getInt() + -1;
      i = Rinternals2.INTEGER(paramSEXP1).getInt(4) + -1;
    } else {
      bool1 = false;
      i = layoutNRow(sEXP2) + -1;
    } 
    if (!Rinternals.Rf_isNull(paramSEXP2)) {
      bool2 = Rinternals2.INTEGER(paramSEXP2).getInt() + -1;
      j = Rinternals2.INTEGER(paramSEXP2).getInt(4) + -1;
    } else {
      bool2 = false;
      j = layoutNCol(sEXP2) + -1;
    } 
    double d2 = Rinternals2.REAL(viewport__.viewportHeightCM(paramSEXP3)).getDouble();
    double d1 = Rinternals2.REAL(viewport__.viewportWidthCM(paramSEXP3)).getDouble();
    Ptr ptr2 = Rinternals2.REAL(viewport__.viewportLayoutHeights(paramSEXP3));
    Ptr ptr1 = Rinternals2.REAL(viewport__.viewportLayoutWidths(paramSEXP3));
    subRegion(viewport__.viewportLayout(paramSEXP3), bool1, i, bool2, j, ptr1, ptr2, d1, d2, (Ptr)new DoublePtr(arrayOfDouble4, 0), (Ptr)new DoublePtr(arrayOfDouble3, 0), (Ptr)new DoublePtr(arrayOfDouble2, 0), (Ptr)new DoublePtr(arrayOfDouble1, 0));
    SEXP sEXP1 = unit__.unit(arrayOfDouble4[0], 1);
    Rinternals.Rf_protect(sEXP1);
    paramPtr.setPointer((Ptr)new RecordUnitPtr(sEXP1));
    sEXP1 = unit__.unit(arrayOfDouble3[0], 1);
    Rinternals.Rf_protect(sEXP1);
    paramPtr.setAlignedPointer(1, (Ptr)new RecordUnitPtr(sEXP1));
    sEXP1 = unit__.unit(arrayOfDouble2[0], 1);
    Rinternals.Rf_protect(sEXP1);
    paramPtr.setAlignedPointer(2, (Ptr)new RecordUnitPtr(sEXP1));
    sEXP1 = unit__.unit(arrayOfDouble1[0], 1);
    Rinternals.Rf_protect(sEXP1);
    paramPtr.setAlignedPointer(3, (Ptr)new RecordUnitPtr(sEXP1));
    paramPtr.setAlignedDouble(2, 0.0D);
    paramPtr.setAlignedDouble(3, 0.0D);
  }
  
  public static int checkPosRowPosCol(SEXP paramSEXP1, SEXP paramSEXP2) {
    int j = layoutNCol(viewport__.viewportLayout(paramSEXP2));
    int i = layoutNRow(viewport__.viewportLayout(paramSEXP2));
    if (!Rinternals.Rf_isNull(viewport__.viewportLayoutPosRow(paramSEXP1)) && (Rinternals2.INTEGER(viewport__.viewportLayoutPosRow(paramSEXP1)).getInt() <= 0 || Rinternals2.INTEGER(viewport__.viewportLayoutPosRow(paramSEXP1)).getInt(4) > i))
      Error.Rf_error(GetText.dgettext(new BytePtr("grid\000".getBytes(), 0), new BytePtr("invalid 'layout.pos.row'\000".getBytes(), 0)), new Object[0]); 
    if (!Rinternals.Rf_isNull(viewport__.viewportLayoutPosCol(paramSEXP1)) && (Rinternals2.INTEGER(viewport__.viewportLayoutPosCol(paramSEXP1)).getInt() <= 0 || Rinternals2.INTEGER(viewport__.viewportLayoutPosCol(paramSEXP1)).getInt(4) > j))
      Error.Rf_error(GetText.dgettext(new BytePtr("grid\000".getBytes(), 0), new BytePtr("invalid 'layout.pos.col'\000".getBytes(), 0)), new Object[0]); 
    return 1;
  }
  
  public static int colRespected(int paramInt, SEXP paramSEXP) {
    BytePtr.of(0);
    null = false;
    Ptr ptr = layoutRespectMat(paramSEXP);
    if (layoutRespect(paramSEXP) != 1) {
      for (byte b = 0; layoutNRow(paramSEXP) > b; b++) {
        if (ptr.getInt(0 + (layoutNRow(paramSEXP) * paramInt + b) * 4) != 0)
          null = true; 
      } 
      return null;
    } 
    return 1;
  }
  
  public static void findRelHeights(SEXP paramSEXP, Ptr paramPtr1, Ptr paramPtr2) {
    SEXP sEXP = (SEXP)BytePtr.of(0).getArray();
    sEXP = layoutHeights(paramSEXP);
    for (byte b = 0; layoutNRow(paramSEXP) > b; b++)
      paramPtr1.setInt(b * 4, relativeUnit(sEXP, b, paramPtr2)); 
  }
  
  public static void findRelWidths(SEXP paramSEXP, Ptr paramPtr1, Ptr paramPtr2) {
    SEXP sEXP = (SEXP)BytePtr.of(0).getArray();
    sEXP = layoutWidths(paramSEXP);
    for (byte b = 0; layoutNCol(paramSEXP) > b; b++)
      paramPtr1.setInt(b * 4, relativeUnit(sEXP, b, paramPtr2)); 
  }
  
  public static double layoutHJust(SEXP paramSEXP) {
    return Rinternals2.REAL(Rinternals.VECTOR_ELT(paramSEXP, 8)).getDouble();
  }
  
  public static SEXP layoutHeights(SEXP paramSEXP) {
    return Rinternals.VECTOR_ELT(paramSEXP, 3);
  }
  
  public static int layoutNCol(SEXP paramSEXP) {
    return Rinternals2.INTEGER(Rinternals.VECTOR_ELT(paramSEXP, 1)).getInt();
  }
  
  public static int layoutNRow(SEXP paramSEXP) {
    return Rinternals2.INTEGER(Rinternals.VECTOR_ELT(paramSEXP, 0)).getInt();
  }
  
  public static int layoutRespect(SEXP paramSEXP) {
    return Rinternals2.INTEGER(Rinternals.VECTOR_ELT(paramSEXP, 5)).getInt();
  }
  
  public static Ptr layoutRespectMat(SEXP paramSEXP) {
    return Rinternals2.INTEGER(Rinternals.VECTOR_ELT(paramSEXP, 6));
  }
  
  public static double layoutVJust(SEXP paramSEXP) {
    return Rinternals2.REAL(Rinternals.VECTOR_ELT(paramSEXP, 8)).getDouble(8);
  }
  
  public static SEXP layoutWidths(SEXP paramSEXP) {
    return Rinternals.VECTOR_ELT(paramSEXP, 2);
  }
  
  public static int relativeUnit(SEXP paramSEXP, int paramInt, Ptr paramPtr) {
    return unit__.pureNullUnit(paramSEXP, paramInt, paramPtr);
  }
  
  public static int rowRespected(int paramInt, SEXP paramSEXP) {
    BytePtr.of(0);
    null = false;
    Ptr ptr = layoutRespectMat(paramSEXP);
    if (layoutRespect(paramSEXP) != 1) {
      for (byte b = 0; layoutNCol(paramSEXP) > b; b++) {
        if (ptr.getInt(0 + (layoutNRow(paramSEXP) * b + paramInt) * 4) != 0)
          null = true; 
      } 
      return null;
    } 
    return 1;
  }
  
  public static void setRemainingHeightZero(SEXP paramSEXP, Ptr paramPtr1, Ptr paramPtr2) {
    for (byte b = 0; layoutNRow(paramSEXP) > b; b++) {
      if (paramPtr1.getInt(b * 4) != 0 && rowRespected(b, paramSEXP) == 0)
        paramPtr2.setDouble(b * 8, 0.0D); 
    } 
  }
  
  public static void setRemainingWidthZero(SEXP paramSEXP, Ptr paramPtr1, Ptr paramPtr2) {
    for (byte b = 0; layoutNCol(paramSEXP) > b; b++) {
      if (paramPtr1.getInt(b * 4) != 0 && colRespected(b, paramSEXP) == 0)
        paramPtr2.setDouble(b * 8, 0.0D); 
    } 
  }
  
  public static void setRespectedZero(SEXP paramSEXP, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4) {
    for (byte b2 = 0; layoutNCol(paramSEXP) > b2; b2++) {
      if (paramPtr1.getInt(b2 * 4) != 0 && colRespected(b2, paramSEXP) != 0)
        paramPtr3.setDouble(b2 * 8, 0.0D); 
    } 
    for (byte b1 = 0; layoutNRow(paramSEXP) > b1; b1++) {
      if (paramPtr2.getInt(b1 * 4) != 0 && rowRespected(b1, paramSEXP) != 0)
        paramPtr4.setDouble(b1 * 8, 0.0D); 
    } 
  }
  
  public static void subRegion(SEXP paramSEXP, int paramInt1, int paramInt2, int paramInt3, int paramInt4, Ptr paramPtr1, Ptr paramPtr2, double paramDouble1, double paramDouble2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6) {
    double d3 = layoutHJust(paramSEXP);
    double d2 = layoutVJust(paramSEXP);
    double d1 = sumDims(paramPtr1, 0, layoutNCol(paramSEXP) + -1);
    paramDouble1 = sumDims(paramPtr2, 0, layoutNRow(paramSEXP) + -1);
    paramPtr5.setDouble(sumDims(paramPtr1, paramInt3, paramInt4));
    paramPtr6.setDouble(sumDims(paramPtr2, paramInt1, paramInt2));
    paramPtr3.setDouble(paramDouble1 * d3 - d3 * d1 + sumDims(paramPtr1, 0, paramInt3 + -1));
    paramPtr4.setDouble(paramDouble2 * d2 + (1.0D - d2) * paramDouble1 - sumDims(paramPtr2, 0, paramInt2));
  }
  
  public static double sumDims(Ptr paramPtr, int paramInt1, int paramInt2) {
    double d = 0.0D;
    for (paramInt1 = paramInt1; paramInt2 + 1 > paramInt1; paramInt1++)
      d = paramPtr.getDouble(paramInt1 * 8) + d; 
    return d;
  }
  
  public static double totalHeight(SEXP paramSEXP, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4) {
    SEXP sEXP = (SEXP)BytePtr.of(0).getArray();
    sEXP = layoutHeights(paramSEXP);
    double d = 0.0D;
    for (byte b = 0; layoutNRow(paramSEXP) > b; b++) {
      if (paramPtr1.getInt(b * 4) != 0)
        d = unit__.transformHeight(sEXP, b, paramPtr2.copyOf(32), paramPtr3, 0.0D, 0.0D, 1, 0, paramPtr4) + d; 
    } 
    return d;
  }
  
  public static double totalUnrespectedHeight(SEXP paramSEXP, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4) {
    SEXP sEXP = (SEXP)BytePtr.of(0).getArray();
    sEXP = layoutHeights(paramSEXP);
    double d = 0.0D;
    for (byte b = 0; layoutNRow(paramSEXP) > b; b++) {
      if (paramPtr1.getInt(b * 4) != 0 && rowRespected(b, paramSEXP) == 0)
        d = unit__.transformHeight(sEXP, b, paramPtr2.copyOf(32), paramPtr3, 0.0D, 0.0D, 1, 0, paramPtr4) + d; 
    } 
    return d;
  }
  
  public static double totalUnrespectedWidth(SEXP paramSEXP, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4) {
    SEXP sEXP = (SEXP)BytePtr.of(0).getArray();
    sEXP = layoutWidths(paramSEXP);
    double d = 0.0D;
    for (byte b = 0; layoutNCol(paramSEXP) > b; b++) {
      if (paramPtr1.getInt(b * 4) != 0 && colRespected(b, paramSEXP) == 0)
        d = unit__.transformWidth(sEXP, b, paramPtr2.copyOf(32), paramPtr3, 0.0D, 0.0D, 1, 0, paramPtr4) + d; 
    } 
    return d;
  }
  
  public static double totalWidth(SEXP paramSEXP, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4) {
    SEXP sEXP = (SEXP)BytePtr.of(0).getArray();
    sEXP = layoutWidths(paramSEXP);
    double d = 0.0D;
    for (byte b = 0; layoutNCol(paramSEXP) > b; b++) {
      if (paramPtr1.getInt(b * 4) != 0)
        d = unit__.transformWidth(sEXP, b, paramPtr2.copyOf(32), paramPtr3, 0.0D, 0.0D, 1, 0, paramPtr4) + d; 
    } 
    return d;
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/grid-0.9.2724.jar!/org/renjin/grid/layout__.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */