package org.renjin.grid;

import org.renjin.gcc.runtime.BytePtr;
import org.renjin.gcc.runtime.DoublePtr;
import org.renjin.gcc.runtime.MixedPtr;
import org.renjin.gcc.runtime.Ptr;
import org.renjin.gcc.runtime.RecordUnitPtr;
import org.renjin.gnur.api.Arith;
import org.renjin.gnur.api.Error;
import org.renjin.gnur.api.GetText;
import org.renjin.gnur.api.Rinternals;
import org.renjin.gnur.api.Rinternals2;
import org.renjin.sexp.SEXP;

public class viewport__ {
  static {
  
  }
  
  public static void calcViewportTransform(SEXP paramSEXP1, SEXP paramSEXP2, int paramInt, Ptr paramPtr) {
    double[] arrayOfDouble1 = new double[9];
    double[] arrayOfDouble2 = new double[9];
    double[] arrayOfDouble3 = new double[9];
    double[] arrayOfDouble4 = new double[9];
    double[] arrayOfDouble5 = new double[9];
    double[] arrayOfDouble6 = new double[9];
    double[] arrayOfDouble7 = new double[9];
    MixedPtr mixedPtr1 = MixedPtr.malloc(276);
    MixedPtr mixedPtr2 = MixedPtr.malloc(276);
    MixedPtr mixedPtr3 = MixedPtr.malloc(32);
    MixedPtr mixedPtr4 = MixedPtr.malloc(32);
    MixedPtr mixedPtr5 = MixedPtr.malloc(32);
    double[] arrayOfDouble8 = new double[1];
    double[] arrayOfDouble9 = new double[1];
    double[] arrayOfDouble10 = new double[1];
    double[] arrayOfDouble11 = new double[1];
    SEXP sEXP4 = (SEXP)BytePtr.of(0).getArray();
    sEXP4 = (SEXP)BytePtr.of(0).getArray();
    sEXP4 = (SEXP)BytePtr.of(0).getArray();
    sEXP4 = (SEXP)BytePtr.of(0).getArray();
    arrayOfDouble8[0] = 0.0D;
    arrayOfDouble9[0] = 0.0D;
    arrayOfDouble10[0] = 0.0D;
    arrayOfDouble11[0] = 0.0D;
    if (!Rinternals.Rf_isNull(paramSEXP2)) {
      if (paramInt == 0)
        calcViewportTransform(paramSEXP2, viewportParent(paramSEXP2), 0, paramPtr); 
      arrayOfDouble11[0] = Rinternals2.REAL(viewportWidthCM(paramSEXP2)).getDouble();
      arrayOfDouble10[0] = Rinternals2.REAL(viewportHeightCM(paramSEXP2)).getDouble();
      d3 = Rinternals2.REAL(viewportRotation(paramSEXP2)).getDouble();
      for (paramInt = 0; paramInt <= 2; paramInt++) {
        for (byte b1 = 0; b1 <= 2; b1++)
          arrayOfDouble2[paramInt * 3 + b1] = Rinternals2.REAL(viewportTransform(paramSEXP2)).getDouble(0 + (b1 * 3 + paramInt) * 8); 
      } 
      fillViewportContextFromViewport(paramSEXP2, (Ptr)mixedPtr3);
      gpar__.gcontextFromgpar(viewportParentGPar(paramSEXP1), 0, (Ptr)mixedPtr1, paramPtr);
      if ((!Rinternals.Rf_isNull(viewportLayoutPosRow(paramSEXP1)) || !Rinternals.Rf_isNull(viewportLayoutPosCol(paramSEXP1))) && !Rinternals.Rf_isNull(viewportLayout(paramSEXP2))) {
        if (layout__.checkPosRowPosCol(paramSEXP1, paramSEXP2) != 0) {
          SEXP sEXP = viewportLayoutPosCol(paramSEXP1);
          layout__.calcViewportLocationFromLayout(viewportLayoutPosRow(paramSEXP1), sEXP, paramSEXP2, (Ptr)mixedPtr5);
        } 
      } else {
        fillViewportLocationFromViewport(paramSEXP1, (Ptr)mixedPtr5);
      } 
    } else {
      grid__.getDeviceSize(paramPtr, (Ptr)new DoublePtr(arrayOfDouble11, 0), (Ptr)new DoublePtr(arrayOfDouble10, 0));
      matrix__.identity((Ptr)new DoublePtr(arrayOfDouble2, 0));
      mixedPtr3.setDouble(0.0D);
      mixedPtr3.setAlignedDouble(2, 0.0D);
      mixedPtr3.setAlignedDouble(1, 1.0D);
      mixedPtr3.setAlignedDouble(3, 1.0D);
      mixedPtr1.setDouble(52, 10.0D);
      mixedPtr1.setDouble(60, 1.2D);
      mixedPtr1.setDouble(44, 1.0D);
      mixedPtr1.setAlignedInt(17, 1);
      mixedPtr1.setByte(72, (byte)0);
      d3 = 0.0D;
      fillViewportLocationFromViewport(paramSEXP1, (Ptr)mixedPtr5);
    } 
    double d1 = arrayOfDouble10[0];
    double d2 = arrayOfDouble11[0];
    d2 = unit__.transformXtoINCHES((SEXP)mixedPtr5.getPointer().getArray(), 0, mixedPtr3.copyOf(32), (Ptr)mixedPtr1, d2, d1, paramPtr);
    double d5 = arrayOfDouble10[0];
    d1 = arrayOfDouble11[0];
    d1 = unit__.transformYtoINCHES((SEXP)mixedPtr5.getAlignedPointer(1).getArray(), 0, mixedPtr3.copyOf(32), (Ptr)mixedPtr1, d1, d5, paramPtr);
    double d4 = arrayOfDouble10[0];
    d5 = arrayOfDouble11[0];
    d5 = unit__.transformWidthtoINCHES((SEXP)mixedPtr5.getAlignedPointer(2).getArray(), 0, mixedPtr3.copyOf(32), (Ptr)mixedPtr1, d5, d4, paramPtr) * 2.54D;
    double d6 = arrayOfDouble10[0];
    d4 = arrayOfDouble11[0];
    d4 = unit__.transformHeighttoINCHES((SEXP)mixedPtr5.getAlignedPointer(3).getArray(), 0, mixedPtr3.copyOf(32), (Ptr)mixedPtr1, d4, d6, paramPtr) * 2.54D;
    if (Arith.R_finite(d2) == 0 || Arith.R_finite(d1) == 0 || Arith.R_finite(d5) == 0 || Arith.R_finite(d4) == 0)
      Error.Rf_error(GetText.dgettext(new BytePtr("grid\000".getBytes(), 0), new BytePtr("non-finite location and/or size for viewport\000".getBytes(), 0)), new Object[0]); 
    d6 = mixedPtr5.getAlignedDouble(3);
    just__.justification(d5, d4, mixedPtr5.getAlignedDouble(2), d6, (Ptr)new DoublePtr(arrayOfDouble9, 0), (Ptr)new DoublePtr(arrayOfDouble8, 0));
    matrix__.translation(d2, d1, (Ptr)new DoublePtr(arrayOfDouble7, 0));
    if (viewportAngle(paramSEXP1) == 0.0D) {
      matrix__.identity((Ptr)new DoublePtr(arrayOfDouble6, 0));
    } else {
      matrix__.rotation(viewportAngle(paramSEXP1), (Ptr)new DoublePtr(arrayOfDouble6, 0));
    } 
    matrix__.translation(arrayOfDouble9[0] / 2.54D, arrayOfDouble8[0] / 2.54D, (Ptr)new DoublePtr(arrayOfDouble5, 0));
    matrix__.multiply((Ptr)new DoublePtr(arrayOfDouble5, 0), (Ptr)new DoublePtr(arrayOfDouble6, 0), (Ptr)new DoublePtr(arrayOfDouble3, 0));
    matrix__.multiply((Ptr)new DoublePtr(arrayOfDouble3, 0), (Ptr)new DoublePtr(arrayOfDouble7, 0), (Ptr)new DoublePtr(arrayOfDouble4, 0));
    matrix__.multiply((Ptr)new DoublePtr(arrayOfDouble4, 0), (Ptr)new DoublePtr(arrayOfDouble2, 0), (Ptr)new DoublePtr(arrayOfDouble1, 0));
    double d3 = viewportAngle(paramSEXP1) + d3;
    if (!Rinternals.Rf_isNull(viewportLayout(paramSEXP1))) {
      fillViewportContextFromViewport(paramSEXP1, (Ptr)mixedPtr4);
      gcontextFromViewport(paramSEXP1, (Ptr)mixedPtr2, paramPtr);
      layout__.calcViewportLayout(paramSEXP1, d5, d4, mixedPtr4.copyOf(32), (Ptr)mixedPtr2, paramPtr);
    } 
    paramSEXP2 = Rinternals.Rf_ScalarReal(d5);
    Rinternals.Rf_protect(paramSEXP2);
    SEXP sEXP1 = Rinternals.Rf_ScalarReal(d4);
    Rinternals.Rf_protect(sEXP1);
    SEXP sEXP2 = Rinternals.Rf_ScalarReal(d3);
    Rinternals.Rf_protect(sEXP2);
    SEXP sEXP3 = Rinternals.Rf_allocMatrix(14, 3, 3);
    Rinternals.Rf_protect(sEXP3);
    for (byte b = 0; b <= 2; b++) {
      for (byte b1 = 0; b1 <= 2; b1++)
        Rinternals2.REAL(sEXP3).setDouble(0 + (b1 * 3 + b) * 8, arrayOfDouble1[b * 3 + b1]); 
    } 
    Rinternals.SET_VECTOR_ELT(paramSEXP1, 22, paramSEXP2);
    Rinternals.SET_VECTOR_ELT(paramSEXP1, 23, sEXP1);
    Rinternals.SET_VECTOR_ELT(paramSEXP1, 24, sEXP2);
    Rinternals.SET_VECTOR_ELT(paramSEXP1, 19, sEXP3);
  }
  
  public static void copyViewportContext(Ptr paramPtr1, Ptr paramPtr2) {
    paramPtr2.setDouble(paramPtr1.getDouble());
    paramPtr2.setAlignedDouble(1, paramPtr1.getAlignedDouble(1));
    paramPtr2.setAlignedDouble(2, paramPtr1.getAlignedDouble(2));
    paramPtr2.setAlignedDouble(3, paramPtr1.getAlignedDouble(3));
  }
  
  public static void fillViewportContextFromViewport(SEXP paramSEXP, Ptr paramPtr) {
    paramPtr.setDouble(viewportXScaleMin(paramSEXP));
    paramPtr.setAlignedDouble(1, viewportXScaleMax(paramSEXP));
    paramPtr.setAlignedDouble(2, viewportYScaleMin(paramSEXP));
    paramPtr.setAlignedDouble(3, viewportYScaleMax(paramSEXP));
  }
  
  public static void fillViewportLocationFromViewport(SEXP paramSEXP, Ptr paramPtr) {
    paramPtr.setPointer((Ptr)new RecordUnitPtr(viewportX(paramSEXP)));
    paramPtr.setAlignedPointer(1, (Ptr)new RecordUnitPtr(viewportY(paramSEXP)));
    paramPtr.setAlignedPointer(2, (Ptr)new RecordUnitPtr(viewportWidth(paramSEXP)));
    paramPtr.setAlignedPointer(3, (Ptr)new RecordUnitPtr(viewportHeight(paramSEXP)));
    paramPtr.setAlignedDouble(2, viewportHJust(paramSEXP));
    paramPtr.setAlignedDouble(3, viewportVJust(paramSEXP));
  }
  
  public static void gcontextFromViewport(SEXP paramSEXP, Ptr paramPtr1, Ptr paramPtr2) {
    gpar__.gcontextFromgpar(viewportgpar(paramSEXP), 0, paramPtr1, paramPtr2);
  }
  
  public static void initVP(Ptr paramPtr) {
    SEXP sEXP1 = state__.gridStateElement(paramPtr, 5);
    SEXP sEXP3 = grid__.R_gridEvalEnv;
    Rinternals.Rf_protect(Rinternals.Rf_findFun(Rinternals.Rf_install(new BytePtr("grid.top.level.vp\000".getBytes(), 0)), sEXP3));
    Rinternals.Rf_protect(Rinternals.Rf_lang1(Rinternals.Rf_findFun(Rinternals.Rf_install(new BytePtr("grid.top.level.vp\000".getBytes(), 0)), sEXP3)));
    sEXP3 = Rinternals.Rf_eval(Rinternals.Rf_lang1(Rinternals.Rf_findFun(Rinternals.Rf_install(new BytePtr("grid.top.level.vp\000".getBytes(), 0)), sEXP3)), Rinternals.R_GlobalEnv());
    Rinternals.Rf_protect(sEXP3);
    SEXP sEXP2 = Rinternals.Rf_allocVector(14, 2);
    Rinternals.Rf_protect(sEXP2);
    Rinternals2.REAL(sEXP2).setDouble(0, paramPtr.getPointer().getDouble());
    Rinternals2.REAL(sEXP2).setDouble(8, paramPtr.getPointer().getDouble(8));
    Rinternals.SET_VECTOR_ELT(sEXP3, 7, sEXP2);
    sEXP2 = Rinternals.Rf_allocVector(14, 2);
    Rinternals.Rf_protect(sEXP2);
    Rinternals2.REAL(sEXP2).setDouble(0, paramPtr.getPointer().getDouble(16));
    Rinternals2.REAL(sEXP2).setDouble(8, paramPtr.getPointer().getDouble(24));
    Rinternals.SET_VECTOR_ELT(sEXP3, 8, sEXP2);
    Rinternals.SET_VECTOR_ELT(sEXP3, 18, sEXP1);
    Rinternals.SET_VECTOR_ELT((SEXP)paramPtr.getPointer(28 + matrix__.gridRegisterIndex * 4).getPointer().getArray(), 7, grid__.doSetViewport(sEXP3, 1, 1, paramPtr));
  }
  
  public static double viewportAngle(SEXP paramSEXP) {
    return util__.numeric(Rinternals.VECTOR_ELT(paramSEXP, 9), 0);
  }
  
  public static double viewportCex(SEXP paramSEXP) {
    return util__.numeric(Rinternals.VECTOR_ELT(Rinternals.VECTOR_ELT(paramSEXP, 18), 5), 0);
  }
  
  public static SEXP viewportChildren(SEXP paramSEXP) {
    return Rinternals.VECTOR_ELT(paramSEXP, 27);
  }
  
  public static int viewportClip(SEXP paramSEXP) {
    return Rinternals.LOGICAL(Rinternals.VECTOR_ELT(paramSEXP, 6)).getInt();
  }
  
  public static SEXP viewportClipRect(SEXP paramSEXP) {
    return Rinternals.VECTOR_ELT(paramSEXP, 25);
  }
  
  public static SEXP viewportDevHeightCM(SEXP paramSEXP) {
    return Rinternals.VECTOR_ELT(paramSEXP, 29);
  }
  
  public static SEXP viewportDevWidthCM(SEXP paramSEXP) {
    return Rinternals.VECTOR_ELT(paramSEXP, 28);
  }
  
  public static int viewportFont(SEXP paramSEXP) {
    return Rinternals2.INTEGER(Rinternals.VECTOR_ELT(Rinternals.VECTOR_ELT(paramSEXP, 18), 8)).getInt();
  }
  
  public static Ptr viewportFontFamily(SEXP paramSEXP) {
    return (Ptr)Rinternals.R_CHAR(Rinternals.STRING_ELT(Rinternals.VECTOR_ELT(Rinternals.VECTOR_ELT(paramSEXP, 18), 9), 0));
  }
  
  public static double viewportFontSize(SEXP paramSEXP) {
    return Rinternals2.REAL(Rinternals.VECTOR_ELT(Rinternals.VECTOR_ELT(paramSEXP, 18), 6)).getDouble();
  }
  
  public static double viewportHJust(SEXP paramSEXP) {
    return Rinternals2.REAL(Rinternals.VECTOR_ELT(paramSEXP, 13)).getDouble();
  }
  
  public static SEXP viewportHeight(SEXP paramSEXP) {
    return Rinternals.VECTOR_ELT(paramSEXP, 3);
  }
  
  public static SEXP viewportHeightCM(SEXP paramSEXP) {
    return Rinternals.VECTOR_ELT(paramSEXP, 23);
  }
  
  public static SEXP viewportLayout(SEXP paramSEXP) {
    return Rinternals.VECTOR_ELT(paramSEXP, 10);
  }
  
  public static SEXP viewportLayoutHeights(SEXP paramSEXP) {
    return Rinternals.VECTOR_ELT(paramSEXP, 21);
  }
  
  public static SEXP viewportLayoutPosCol(SEXP paramSEXP) {
    return Rinternals.VECTOR_ELT(paramSEXP, 15);
  }
  
  public static SEXP viewportLayoutPosRow(SEXP paramSEXP) {
    return Rinternals.VECTOR_ELT(paramSEXP, 14);
  }
  
  public static SEXP viewportLayoutWidths(SEXP paramSEXP) {
    return Rinternals.VECTOR_ELT(paramSEXP, 20);
  }
  
  public static double viewportLineHeight(SEXP paramSEXP) {
    return Rinternals2.REAL(Rinternals.VECTOR_ELT(Rinternals.VECTOR_ELT(paramSEXP, 18), 7)).getDouble();
  }
  
  public static SEXP viewportParent(SEXP paramSEXP) {
    return Rinternals.VECTOR_ELT(paramSEXP, 26);
  }
  
  public static SEXP viewportParentGPar(SEXP paramSEXP) {
    return Rinternals.VECTOR_ELT(paramSEXP, 17);
  }
  
  public static SEXP viewportRotation(SEXP paramSEXP) {
    return Rinternals.VECTOR_ELT(paramSEXP, 24);
  }
  
  public static SEXP viewportTransform(SEXP paramSEXP) {
    return Rinternals.VECTOR_ELT(paramSEXP, 19);
  }
  
  public static double viewportVJust(SEXP paramSEXP) {
    return Rinternals2.REAL(Rinternals.VECTOR_ELT(paramSEXP, 13)).getDouble(8);
  }
  
  public static SEXP viewportWidth(SEXP paramSEXP) {
    return Rinternals.VECTOR_ELT(paramSEXP, 2);
  }
  
  public static SEXP viewportWidthCM(SEXP paramSEXP) {
    return Rinternals.VECTOR_ELT(paramSEXP, 22);
  }
  
  public static SEXP viewportX(SEXP paramSEXP) {
    return Rinternals.VECTOR_ELT(paramSEXP, 0);
  }
  
  public static double viewportXScaleMax(SEXP paramSEXP) {
    return util__.numeric(Rinternals.VECTOR_ELT(paramSEXP, 7), 1);
  }
  
  public static double viewportXScaleMin(SEXP paramSEXP) {
    return util__.numeric(Rinternals.VECTOR_ELT(paramSEXP, 7), 0);
  }
  
  public static SEXP viewportY(SEXP paramSEXP) {
    return Rinternals.VECTOR_ELT(paramSEXP, 1);
  }
  
  public static double viewportYScaleMax(SEXP paramSEXP) {
    return util__.numeric(Rinternals.VECTOR_ELT(paramSEXP, 8), 1);
  }
  
  public static double viewportYScaleMin(SEXP paramSEXP) {
    return util__.numeric(Rinternals.VECTOR_ELT(paramSEXP, 8), 0);
  }
  
  public static SEXP viewportgpar(SEXP paramSEXP) {
    return Rinternals.VECTOR_ELT(paramSEXP, 18);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/grid-0.9.2724.jar!/org/renjin/grid/viewport__.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */