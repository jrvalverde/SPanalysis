package org.renjin.grid;

import org.renjin.gcc.runtime.BytePtr;
import org.renjin.gcc.runtime.DoublePtr;
import org.renjin.gcc.runtime.IntPtr;
import org.renjin.gcc.runtime.Mathlib;
import org.renjin.gcc.runtime.MixedPtr;
import org.renjin.gcc.runtime.Ptr;
import org.renjin.gcc.runtime.Stdlib;
import org.renjin.gcc.runtime.UnsatisfiedLinkException;
import org.renjin.gcc.runtime.VoidPtr;
import org.renjin.gnur.api.Arith;
import org.renjin.gnur.api.Error;
import org.renjin.gnur.api.GetText;
import org.renjin.gnur.api.Memory;
import org.renjin.gnur.api.Rinternals;
import org.renjin.gnur.api.Rinternals2;
import org.renjin.gnur.api.Rmath;
import org.renjin.grDevices.baseDevices__;
import org.renjin.grDevices.baseEngine__;
import org.renjin.grDevices.colors__;
import org.renjin.sexp.SEXP;

public class grid__ {
  public static SEXP R_gridEvalEnv = (SEXP)BytePtr.of(0).getArray();
  
  public static SEXP L_arrows(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4, SEXP paramSEXP5, SEXP paramSEXP6, SEXP paramSEXP7, SEXP paramSEXP8, SEXP paramSEXP9, SEXP paramSEXP10, SEXP paramSEXP11, SEXP paramSEXP12) {
    double[] arrayOfDouble1 = new double[3];
    double[] arrayOfDouble2 = new double[3];
    double[] arrayOfDouble3 = new double[1];
    double[] arrayOfDouble4 = new double[1];
    double[] arrayOfDouble5 = new double[1];
    double[] arrayOfDouble6 = new double[1];
    double[] arrayOfDouble7 = new double[1];
    double[] arrayOfDouble8 = new double[1];
    double[] arrayOfDouble9 = new double[1];
    double[] arrayOfDouble10 = new double[1];
    double[] arrayOfDouble11 = new double[9];
    MixedPtr mixedPtr1 = MixedPtr.malloc(276);
    MixedPtr mixedPtr2 = MixedPtr.malloc(32);
    double[] arrayOfDouble12 = new double[1];
    double[] arrayOfDouble13 = new double[1];
    double[] arrayOfDouble14 = new double[1];
    arrayOfDouble3[0] = 0.0D;
    arrayOfDouble4[0] = 0.0D;
    arrayOfDouble5[0] = 0.0D;
    arrayOfDouble6[0] = 0.0D;
    arrayOfDouble7[0] = 0.0D;
    arrayOfDouble8[0] = 0.0D;
    arrayOfDouble9[0] = 0.0D;
    arrayOfDouble10[0] = 0.0D;
    BytePtr.of(0);
    SEXP sEXP1 = (SEXP)BytePtr.of(0).getArray();
    sEXP1 = (SEXP)BytePtr.of(0).getArray();
    arrayOfDouble12[0] = 0.0D;
    arrayOfDouble13[0] = 0.0D;
    arrayOfDouble14[0] = 0.0D;
    sEXP1 = Rinternals.R_NilValue;
    Ptr ptr = getDevice();
    SEXP sEXP2 = state__.gridStateElement(ptr.pointerPlus(0), 5);
    getViewportTransform(state__.gridStateElement(ptr.pointerPlus(0), 7), ptr.pointerPlus(0), (Ptr)new DoublePtr(arrayOfDouble14, 0), (Ptr)new DoublePtr(arrayOfDouble13, 0), (Ptr)new DoublePtr(arrayOfDouble11, 0), (Ptr)new DoublePtr(arrayOfDouble12, 0));
    getViewportContext(state__.gridStateElement(ptr.pointerPlus(0), 7), (Ptr)mixedPtr2);
    int i = getArrowN(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4, paramSEXP5, paramSEXP6, paramSEXP7, paramSEXP8);
    int j = Rinternals.LENGTH(paramSEXP11);
    baseEngine__.GEMode(1, ptr.pointerPlus(0));
    for (byte b = 0; b < i; b++) {
      boolean bool1 = true;
      boolean bool2 = true;
      switch (Rinternals2.INTEGER(paramSEXP11).getInt(0 + b % j * 4)) {
        case 2:
          bool1 = false;
          break;
        case 1:
          bool2 = false;
          break;
      } 
      gpar__.gcontextFromgpar(sEXP2, b, (Ptr)mixedPtr1, ptr.pointerPlus(0));
      if (Rinternals.Rf_isNull(paramSEXP1)) {
        sEXP1 = state__.gridStateElement(ptr.pointerPlus(0), 1);
        Rinternals.Rf_protect(sEXP1);
      } 
      if (bool1) {
        if (!Rinternals.Rf_isNull(paramSEXP1)) {
          double d4 = arrayOfDouble13[0];
          double d3 = arrayOfDouble14[0];
          unit__.transformLocn(paramSEXP1, paramSEXP5, b, mixedPtr2.copyOf(32), (Ptr)mixedPtr1, d3, d4, ptr.pointerPlus(0), (Ptr)new DoublePtr(arrayOfDouble11, 0), (Ptr)new DoublePtr(arrayOfDouble10, 0), (Ptr)new DoublePtr(arrayOfDouble6, 0));
        } else {
          arrayOfDouble10[0] = Rinternals2.REAL(sEXP1).getDouble();
          arrayOfDouble6[0] = Rinternals2.REAL(sEXP1).getDouble(8);
        } 
        double d2 = arrayOfDouble13[0];
        double d1 = arrayOfDouble14[0];
        unit__.transformLocn(paramSEXP2, paramSEXP6, b, mixedPtr2.copyOf(32), (Ptr)mixedPtr1, d1, d2, ptr.pointerPlus(0), (Ptr)new DoublePtr(arrayOfDouble11, 0), (Ptr)new DoublePtr(arrayOfDouble9, 0), (Ptr)new DoublePtr(arrayOfDouble5, 0));
        d2 = arrayOfDouble13[0];
        d1 = arrayOfDouble14[0];
        calcArrow(arrayOfDouble10[0], arrayOfDouble6[0], arrayOfDouble9[0], arrayOfDouble5[0], paramSEXP9, paramSEXP10, b, mixedPtr2.copyOf(32), d1, d2, (Ptr)new DoublePtr(arrayOfDouble2, 0), (Ptr)new DoublePtr(arrayOfDouble1, 0), (Ptr)mixedPtr1, ptr.pointerPlus(0));
        if (Arith.R_finite(baseEngine__.GEtoDeviceX(arrayOfDouble9[0], 2, ptr.pointerPlus(0))) != 0 && Arith.R_finite(baseEngine__.GEtoDeviceY(arrayOfDouble5[0], 2, ptr.pointerPlus(0))) != 0 && Arith.R_finite(arrayOfDouble2[1]) != 0 && Arith.R_finite(arrayOfDouble1[1]) != 0)
          drawArrow((Ptr)new DoublePtr(arrayOfDouble2, 0), (Ptr)new DoublePtr(arrayOfDouble1, 0), paramSEXP12, b, (Ptr)mixedPtr1, ptr.pointerPlus(0)); 
      } 
      if (bool2) {
        if (!Rinternals.Rf_isNull(paramSEXP3)) {
          double d4 = arrayOfDouble13[0];
          double d3 = arrayOfDouble14[0];
          unit__.transformLocn(paramSEXP3, paramSEXP7, b, mixedPtr2.copyOf(32), (Ptr)mixedPtr1, d3, d4, ptr.pointerPlus(0), (Ptr)new DoublePtr(arrayOfDouble11, 0), (Ptr)new DoublePtr(arrayOfDouble8, 0), (Ptr)new DoublePtr(arrayOfDouble4, 0));
        } else {
          arrayOfDouble8[0] = Rinternals2.REAL(sEXP1).getDouble();
          arrayOfDouble4[0] = Rinternals2.REAL(sEXP1).getDouble(8);
        } 
        double d2 = arrayOfDouble13[0];
        double d1 = arrayOfDouble14[0];
        unit__.transformLocn(paramSEXP4, paramSEXP8, b, mixedPtr2.copyOf(32), (Ptr)mixedPtr1, d1, d2, ptr.pointerPlus(0), (Ptr)new DoublePtr(arrayOfDouble11, 0), (Ptr)new DoublePtr(arrayOfDouble7, 0), (Ptr)new DoublePtr(arrayOfDouble3, 0));
        d2 = arrayOfDouble13[0];
        d1 = arrayOfDouble14[0];
        calcArrow(arrayOfDouble7[0], arrayOfDouble3[0], arrayOfDouble8[0], arrayOfDouble4[0], paramSEXP9, paramSEXP10, b, mixedPtr2.copyOf(32), d1, d2, (Ptr)new DoublePtr(arrayOfDouble2, 0), (Ptr)new DoublePtr(arrayOfDouble1, 0), (Ptr)mixedPtr1, ptr.pointerPlus(0));
        if (Arith.R_finite(baseEngine__.GEtoDeviceX(arrayOfDouble8[0], 2, ptr.pointerPlus(0))) != 0 && Arith.R_finite(baseEngine__.GEtoDeviceY(arrayOfDouble4[0], 2, ptr.pointerPlus(0))) != 0 && Arith.R_finite(arrayOfDouble2[1]) != 0 && Arith.R_finite(arrayOfDouble1[1]) != 0)
          drawArrow((Ptr)new DoublePtr(arrayOfDouble2, 0), (Ptr)new DoublePtr(arrayOfDouble1, 0), paramSEXP12, b, (Ptr)mixedPtr1, ptr.pointerPlus(0)); 
      } 
      if (!Rinternals.Rf_isNull(paramSEXP1));
    } 
    baseEngine__.GEMode(0, ptr.pointerPlus(0));
    return Rinternals.R_NilValue;
  }
  
  public static SEXP L_cap() {
    Ptr ptr;
    SEXP sEXP2 = (SEXP)BytePtr.of(0).getArray();
    BytePtr.of(0);
    SEXP sEXP1 = baseEngine__.GECap(getDevice());
    Rinternals.Rf_protect(sEXP1);
    if (!Rinternals.Rf_isNull(sEXP1)) {
      int i = Rinternals.LENGTH(sEXP1);
      int j = Rinternals2.INTEGER(Rinternals.Rf_getAttrib(sEXP1, Rinternals.R_DimSymbol)).getInt();
      int k = Rinternals2.INTEGER(Rinternals.Rf_getAttrib(sEXP1, Rinternals.R_DimSymbol)).getInt(4);
      sEXP2 = Rinternals.Rf_allocVector(16, i);
      Rinternals.Rf_protect(sEXP2);
      ptr = Rinternals2.INTEGER(sEXP1);
      for (byte b = 0; b < i; b++)
        Rinternals.SET_STRING_ELT(sEXP2, (b % k + 1 + -1) * j + b / k + 1 + -1, Rinternals.Rf_mkChar(colors__.Rf_col2name(ptr.getInt(0 + b * 4)))); 
      SEXP sEXP = Rinternals.Rf_allocVector(13, 2);
      Rinternals.Rf_protect(sEXP);
      Rinternals2.INTEGER(sEXP).setInt(0, j);
      Rinternals2.INTEGER(sEXP).setInt(4, k);
      Rinternals.Rf_setAttrib(sEXP2, Rinternals.R_DimSymbol, sEXP);
      return sEXP2;
    } 
    return (SEXP)ptr;
  }
  
  public static SEXP L_circle(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3) {
    gridCircle(paramSEXP1, paramSEXP2, paramSEXP3, 0.0D, 1);
    return Rinternals.R_NilValue;
  }
  
  public static SEXP L_circleBounds(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4) {
    return gridCircle(paramSEXP1, paramSEXP2, paramSEXP3, Rinternals2.REAL(paramSEXP4).getDouble(), 0);
  }
  
  public static SEXP L_clip(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4, SEXP paramSEXP5, SEXP paramSEXP6) {
    MixedPtr mixedPtr1 = MixedPtr.malloc(276);
    MixedPtr mixedPtr2 = MixedPtr.malloc(32);
    double[] arrayOfDouble2 = new double[1];
    double[] arrayOfDouble3 = new double[1];
    double[] arrayOfDouble4 = new double[1];
    double[] arrayOfDouble5 = new double[1];
    double[] arrayOfDouble6 = new double[1];
    arrayOfDouble2[0] = 0.0D;
    arrayOfDouble3[0] = 0.0D;
    arrayOfDouble4[0] = 0.0D;
    arrayOfDouble5[0] = 0.0D;
    arrayOfDouble6[0] = 0.0D;
    Ptr ptr = getDevice();
    SEXP sEXP = state__.gridStateElement(ptr, 7);
    double[] arrayOfDouble1 = new double[9];
    getViewportTransform(sEXP, ptr, (Ptr)new DoublePtr(arrayOfDouble4, 0), (Ptr)new DoublePtr(arrayOfDouble3, 0), (Ptr)new DoublePtr(arrayOfDouble1, 0), (Ptr)new DoublePtr(arrayOfDouble2, 0));
    getViewportContext(sEXP, (Ptr)mixedPtr2);
    baseEngine__.GEMode(1, ptr);
    gpar__.gcontextFromgpar(state__.gridStateElement(ptr, 5), 0, (Ptr)mixedPtr1, ptr);
    double d2 = arrayOfDouble3[0];
    double d3 = arrayOfDouble4[0];
    unit__.transformLocn(paramSEXP1, paramSEXP2, 0, mixedPtr2.copyOf(32), (Ptr)mixedPtr1, d3, d2, ptr, (Ptr)new DoublePtr(arrayOfDouble1, 0), (Ptr)new DoublePtr(arrayOfDouble6, 0), (Ptr)new DoublePtr(arrayOfDouble5, 0));
    d2 = arrayOfDouble3[0];
    d3 = arrayOfDouble4[0];
    d3 = unit__.transformWidthtoINCHES(paramSEXP3, 0, mixedPtr2.copyOf(32), (Ptr)mixedPtr1, d3, d2, ptr);
    double d1 = arrayOfDouble3[0];
    d2 = arrayOfDouble4[0];
    d2 = unit__.transformHeighttoINCHES(paramSEXP4, 0, mixedPtr2.copyOf(32), (Ptr)mixedPtr1, d2, d1, ptr);
    if (arrayOfDouble2[0] != 0.0D) {
      Error.Rf_warning(GetText.dgettext(new BytePtr("grid\000".getBytes(), 0), new BytePtr("unable to clip to rotated rectangle\000".getBytes(), 0)), new Object[0]);
      baseEngine__.GEMode(0, ptr);
      return Rinternals.R_NilValue;
    } 
    d1 = Rinternals2.REAL(paramSEXP5).getDouble();
    arrayOfDouble6[0] = just__.justifyX(arrayOfDouble6[0], d3, d1);
    d1 = Rinternals2.REAL(paramSEXP6).getDouble();
    arrayOfDouble5[0] = just__.justifyY(arrayOfDouble5[0], d2, d1);
    arrayOfDouble6[0] = baseEngine__.GEtoDeviceX(arrayOfDouble6[0], 2, ptr);
    arrayOfDouble5[0] = baseEngine__.GEtoDeviceY(arrayOfDouble5[0], 2, ptr);
    d3 = baseEngine__.GEtoDeviceWidth(d3, 2, ptr);
    d2 = baseEngine__.GEtoDeviceHeight(d2, 2, ptr);
    if (Arith.R_finite(arrayOfDouble6[0]) != 0 && Arith.R_finite(arrayOfDouble5[0]) != 0 && Arith.R_finite(d3) != 0 && Arith.R_finite(d2) != 0) {
      baseEngine__.GESetClip(arrayOfDouble6[0], arrayOfDouble5[0], arrayOfDouble6[0] + d3, arrayOfDouble5[0] + d2, ptr);
      paramSEXP1 = Rinternals.Rf_allocVector(14, 4);
      Rinternals.Rf_protect(paramSEXP1);
      Rinternals2.REAL(paramSEXP1).setDouble(0, arrayOfDouble6[0]);
      Rinternals2.REAL(paramSEXP1).setDouble(8, arrayOfDouble5[0]);
      Rinternals2.REAL(paramSEXP1).setDouble(16, arrayOfDouble6[0] + d3);
      Rinternals2.REAL(paramSEXP1).setDouble(24, arrayOfDouble5[0] + d2);
      Rinternals.SET_VECTOR_ELT(sEXP, 25, paramSEXP1);
    } 
    baseEngine__.GEMode(0, ptr);
    return Rinternals.R_NilValue;
  }
  
  public static SEXP L_convert(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4) {
    MixedPtr mixedPtr1 = MixedPtr.malloc(276);
    MixedPtr mixedPtr2 = MixedPtr.malloc(32);
    double[] arrayOfDouble1 = new double[1];
    double[] arrayOfDouble2 = new double[1];
    double[] arrayOfDouble3 = new double[1];
    BytePtr.of(0);
    SEXP sEXP1 = (SEXP)BytePtr.of(0).getArray();
    arrayOfDouble1[0] = 0.0D;
    arrayOfDouble2[0] = 0.0D;
    arrayOfDouble3[0] = 0.0D;
    sEXP1 = (SEXP)BytePtr.of(0).getArray();
    Ptr ptr = getDevice();
    SEXP sEXP2 = state__.gridStateElement(ptr.pointerPlus(0), 5);
    getViewportTransform(state__.gridStateElement(ptr.pointerPlus(0), 7), ptr.pointerPlus(0), (Ptr)new DoublePtr(arrayOfDouble3, 0), (Ptr)new DoublePtr(arrayOfDouble2, 0), (Ptr)new DoublePtr(new double[9], 0), (Ptr)new DoublePtr(arrayOfDouble1, 0));
    getViewportContext(state__.gridStateElement(ptr.pointerPlus(0), 7), (Ptr)mixedPtr2);
    int i = unit__.unitLength(paramSEXP1);
    SEXP sEXP3 = Rinternals.Rf_allocVector(14, i);
    Rinternals.Rf_protect(sEXP3);
    for (byte b = 0; b < i; b++) {
      double d1;
      double d2;
      boolean bool1;
      gpar__.gcontextFromgpar(sEXP2, b, (Ptr)mixedPtr1, ptr.pointerPlus(0));
      int m = Rinternals2.INTEGER(paramSEXP4).getInt(0 + b % Rinternals.LENGTH(paramSEXP4) * 4);
      int k = Rinternals2.INTEGER(paramSEXP2).getInt();
      int j = Rinternals2.INTEGER(paramSEXP3).getInt();
      if (unit__.isUnitArithmetic(paramSEXP1) != 0 || unit__.isUnitList(paramSEXP1) != 0 || (unit__.unitUnit(paramSEXP1, b) != 4 && unit__.unitUnit(paramSEXP1, b) != 0) || (m != 4 && m != 0) || (k != j && (k != 0 || j != 2) && (k != 2 || j != 0) && (k != 1 || j != 3) && (k != 3 || j != 1))) {
        bool1 = false;
      } else {
        bool1 = true;
      } 
      boolean bool2 = bool1;
      switch (k) {
        case 0:
          if (!bool1 || arrayOfDouble3[0] >= 1.0E-6D) {
            bool2 = false;
            double d4 = arrayOfDouble2[0];
            double d3 = arrayOfDouble3[0];
            Rinternals2.REAL(sEXP3).setDouble(0 + b * 8, unit__.transformXtoINCHES(paramSEXP1, b, mixedPtr2.copyOf(32), (Ptr)mixedPtr1, d3, d4, ptr.pointerPlus(0)));
            break;
          } 
          d2 = mixedPtr2.getAlignedDouble(1);
          d1 = mixedPtr2.getDouble();
          k = unit__.unitUnit(paramSEXP1, b);
          Rinternals2.REAL(sEXP3).setDouble(0 + b * 8, unit__.transformXYtoNPC(unit__.unitValue(paramSEXP1, b), k, d1, d2));
          break;
        case 1:
          if (!bool1 || arrayOfDouble2[0] >= 1.0E-6D) {
            bool2 = false;
            d2 = arrayOfDouble2[0];
            d1 = arrayOfDouble3[0];
            Rinternals2.REAL(sEXP3).setDouble(0 + b * 8, unit__.transformYtoINCHES(paramSEXP1, b, mixedPtr2.copyOf(32), (Ptr)mixedPtr1, d1, d2, ptr.pointerPlus(0)));
            break;
          } 
          d2 = mixedPtr2.getAlignedDouble(3);
          d1 = mixedPtr2.getAlignedDouble(2);
          k = unit__.unitUnit(paramSEXP1, b);
          Rinternals2.REAL(sEXP3).setDouble(0 + b * 8, unit__.transformXYtoNPC(unit__.unitValue(paramSEXP1, b), k, d1, d2));
          break;
        case 2:
          if (!bool1 || arrayOfDouble3[0] >= 1.0E-6D) {
            bool2 = false;
            d2 = arrayOfDouble2[0];
            d1 = arrayOfDouble3[0];
            Rinternals2.REAL(sEXP3).setDouble(0 + b * 8, unit__.transformWidthtoINCHES(paramSEXP1, b, mixedPtr2.copyOf(32), (Ptr)mixedPtr1, d1, d2, ptr.pointerPlus(0)));
            break;
          } 
          d2 = mixedPtr2.getAlignedDouble(1);
          d1 = mixedPtr2.getDouble();
          k = unit__.unitUnit(paramSEXP1, b);
          Rinternals2.REAL(sEXP3).setDouble(0 + b * 8, unit__.transformWHtoNPC(unit__.unitValue(paramSEXP1, b), k, d1, d2));
          break;
        case 3:
          if (!bool1 || arrayOfDouble2[0] >= 1.0E-6D) {
            bool2 = false;
            d2 = arrayOfDouble2[0];
            d1 = arrayOfDouble3[0];
            Rinternals2.REAL(sEXP3).setDouble(0 + b * 8, unit__.transformHeighttoINCHES(paramSEXP1, b, mixedPtr2.copyOf(32), (Ptr)mixedPtr1, d1, d2, ptr.pointerPlus(0)));
            break;
          } 
          d2 = mixedPtr2.getAlignedDouble(3);
          d1 = mixedPtr2.getAlignedDouble(2);
          k = unit__.unitUnit(paramSEXP1, b);
          Rinternals2.REAL(sEXP3).setDouble(0 + b * 8, unit__.transformWHtoNPC(unit__.unitValue(paramSEXP1, b), k, d1, d2));
          break;
      } 
      switch (j) {
        case 0:
          if (!bool2) {
            double d4 = arrayOfDouble2[0];
            double d3 = arrayOfDouble3[0];
            d2 = mixedPtr2.getAlignedDouble(1);
            d1 = mixedPtr2.getDouble();
            Rinternals2.REAL(sEXP3).setDouble(0 + b * 8, unit__.transformXYFromINCHES(Rinternals2.REAL(sEXP3).getDouble(0 + b * 8), m, d1, d2, (Ptr)mixedPtr1, d3, d4, ptr.pointerPlus(0)));
            break;
          } 
          d2 = mixedPtr2.getAlignedDouble(1);
          d1 = mixedPtr2.getDouble();
          Rinternals2.REAL(sEXP3).setDouble(0 + b * 8, unit__.transformXYfromNPC(Rinternals2.REAL(sEXP3).getDouble(0 + b * 8), m, d1, d2));
          break;
        case 1:
          if (!bool2) {
            double d4 = arrayOfDouble3[0];
            double d3 = arrayOfDouble2[0];
            d2 = mixedPtr2.getAlignedDouble(3);
            d1 = mixedPtr2.getAlignedDouble(2);
            Rinternals2.REAL(sEXP3).setDouble(0 + b * 8, unit__.transformXYFromINCHES(Rinternals2.REAL(sEXP3).getDouble(0 + b * 8), m, d1, d2, (Ptr)mixedPtr1, d3, d4, ptr.pointerPlus(0)));
            break;
          } 
          d2 = mixedPtr2.getAlignedDouble(3);
          d1 = mixedPtr2.getAlignedDouble(2);
          Rinternals2.REAL(sEXP3).setDouble(0 + b * 8, unit__.transformXYfromNPC(Rinternals2.REAL(sEXP3).getDouble(0 + b * 8), m, d1, d2));
          break;
        case 2:
          if (!bool2) {
            double d4 = arrayOfDouble2[0];
            double d3 = arrayOfDouble3[0];
            d2 = mixedPtr2.getAlignedDouble(1);
            d1 = mixedPtr2.getDouble();
            Rinternals2.REAL(sEXP3).setDouble(0 + b * 8, unit__.transformWidthHeightFromINCHES(Rinternals2.REAL(sEXP3).getDouble(0 + b * 8), m, d1, d2, (Ptr)mixedPtr1, d3, d4, ptr.pointerPlus(0)));
            break;
          } 
          d2 = mixedPtr2.getAlignedDouble(1);
          d1 = mixedPtr2.getDouble();
          Rinternals2.REAL(sEXP3).setDouble(0 + b * 8, unit__.transformWHfromNPC(Rinternals2.REAL(sEXP3).getDouble(0 + b * 8), m, d1, d2));
          break;
        case 3:
          if (!bool2) {
            double d4 = arrayOfDouble3[0];
            double d3 = arrayOfDouble2[0];
            d2 = mixedPtr2.getAlignedDouble(3);
            d1 = mixedPtr2.getAlignedDouble(2);
            Rinternals2.REAL(sEXP3).setDouble(0 + b * 8, unit__.transformWidthHeightFromINCHES(Rinternals2.REAL(sEXP3).getDouble(0 + b * 8), m, d1, d2, (Ptr)mixedPtr1, d3, d4, ptr.pointerPlus(0)));
            break;
          } 
          d2 = mixedPtr2.getAlignedDouble(3);
          d1 = mixedPtr2.getAlignedDouble(2);
          Rinternals2.REAL(sEXP3).setDouble(0 + b * 8, unit__.transformWHfromNPC(Rinternals2.REAL(sEXP3).getDouble(0 + b * 8), m, d1, d2));
          break;
      } 
    } 
    return sEXP3;
  }
  
  public static SEXP L_currentGPar() {
    return state__.gridStateElement(getDevice(), 5);
  }
  
  public static SEXP L_currentViewport() {
    return state__.gridStateElement(getDevice(), 7);
  }
  
  public static SEXP L_downviewport(SEXP paramSEXP1, SEXP paramSEXP2) {
    byte[] arrayOfByte = new byte[1024];
    null = (SEXP)BytePtr.of(0).getArray();
    Ptr ptr = getDevice();
    paramSEXP2 = findViewport(paramSEXP1, paramSEXP2, state__.gridStateElement(ptr, 7), 1);
    Rinternals.Rf_protect(paramSEXP2);
    if (Rinternals2.INTEGER(Rinternals.VECTOR_ELT(paramSEXP2, 0)).getInt() == 0) {
      BytePtr bytePtr = Rinternals.R_CHAR(Rinternals.STRING_ELT(paramSEXP1, 0));
      Stdlib.snprintf(new BytePtr(arrayOfByte, 0), 1024, new BytePtr("Viewport '%s' was not found\000".getBytes(), 0), new Object[] { bytePtr });
      Error.Rf_error(GetText.dgettext(new BytePtr("grid\000".getBytes(), 0), new BytePtr(arrayOfByte, 0)), new Object[0]);
      return null;
    } 
    state__.setGridStateElement(ptr, 7, doSetViewport(Rinternals.VECTOR_ELT(paramSEXP2, 1), 0, 0, ptr));
    return Rinternals.VECTOR_ELT(paramSEXP2, 0);
  }
  
  public static SEXP L_downvppath(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3) {
    BytePtr bytePtr;
    byte[] arrayOfByte = new byte[1024];
    null = (SEXP)BytePtr.of(0).getArray();
    Ptr ptr = getDevice();
    paramSEXP1 = state__.gridStateElement(ptr, 7);
    paramSEXP1 = findvppath(paramSEXP1, paramSEXP2, paramSEXP3, Rinternals.R_NilValue, paramSEXP1, 1);
    Rinternals.Rf_protect(paramSEXP1);
    if (Rinternals2.INTEGER(Rinternals.VECTOR_ELT(paramSEXP1, 0)).getInt() == 0) {
      bytePtr = Rinternals.R_CHAR(Rinternals.STRING_ELT(paramSEXP2, 0));
      Stdlib.snprintf(new BytePtr(arrayOfByte, 0), 1024, new BytePtr("Viewport '%s' was not found\000".getBytes(), 0), new Object[] { bytePtr });
      Error.Rf_error(GetText.dgettext(new BytePtr("grid\000".getBytes(), 0), new BytePtr(arrayOfByte, 0)), new Object[0]);
      return null;
    } 
    state__.setGridStateElement(ptr, 7, doSetViewport(Rinternals.VECTOR_ELT((SEXP)bytePtr, 1), 0, 0, ptr));
    return Rinternals.VECTOR_ELT((SEXP)bytePtr, 0);
  }
  
  public static SEXP L_getCurrentGrob() {
    return state__.gridStateElement(getDevice(), 12);
  }
  
  public static SEXP L_getDLelt(SEXP paramSEXP) {
    Rinternals.Rf_protect(state__.gridStateElement(getDevice(), 2));
    return Rinternals.VECTOR_ELT(state__.gridStateElement(getDevice(), 2), Rinternals2.INTEGER(paramSEXP).getInt());
  }
  
  public static SEXP L_getDLindex() {
    return state__.gridStateElement(getDevice(), 3);
  }
  
  public static SEXP L_getDLon() {
    return state__.gridStateElement(getDevice(), 4);
  }
  
  public static SEXP L_getDisplayList() {
    return state__.gridStateElement(getDevice(), 2);
  }
  
  public static SEXP L_getEngineDLon() {
    return state__.gridStateElement(getDevice(), 11);
  }
  
  public static SEXP L_getEngineRecording() {
    return state__.gridStateElement(getDevice(), 13);
  }
  
  public static SEXP L_gridDirty() {
    dirtyGridDevice(getDevice());
    return Rinternals.R_NilValue;
  }
  
  public static SEXP L_initDisplayList() {
    state__.initDL(getDevice());
    return Rinternals.R_NilValue;
  }
  
  public static SEXP L_initGPar() {
    gpar__.initGPar(getDevice());
    return Rinternals.R_NilValue;
  }
  
  public static SEXP L_initGrid(SEXP paramSEXP) {
    // Byte code:
    //   0: aload_0
    //   1: putstatic org/renjin/grid/grid__.R_gridEvalEnv : Lorg/renjin/sexp/SEXP;
    //   4: ldc_w
    //   7: ldc_w org/renjin/grid/matrix__
    //   10: ldc_w 'gridRegisterIndex'
    //   13: invokestatic addressOf : (Ljava/lang/Class;Ljava/lang/String;)Lorg/renjin/gcc/runtime/Ptr;
    //   16: invokestatic GEregisterSystem : (Ljava/lang/invoke/MethodHandle;Lorg/renjin/gcc/runtime/Ptr;)V
    //   19: getstatic org/renjin/gnur/api/Rinternals.R_NilValue : Lorg/renjin/sexp/SEXP;
    //   22: areturn
  }
  
  public static SEXP L_initViewportStack() {
    viewport__.initVP(getDevice());
    return Rinternals.R_NilValue;
  }
  
  public static SEXP L_killGrid() {
    baseEngine__.GEunregisterSystem(matrix__.gridRegisterIndex);
    return Rinternals.R_NilValue;
  }
  
  public static SEXP L_layoutRegion(SEXP paramSEXP1, SEXP paramSEXP2) {
    double[] arrayOfDouble1 = new double[1];
    MixedPtr mixedPtr = MixedPtr.malloc(32);
    arrayOfDouble1[0] = 0.0D;
    double[] arrayOfDouble2 = new double[1];
    arrayOfDouble2[0] = 0.0D;
    double[] arrayOfDouble3 = new double[1];
    arrayOfDouble3[0] = 0.0D;
    Ptr ptr = getDevice();
    SEXP sEXP2 = state__.gridStateElement(ptr, 7);
    getViewportTransform(sEXP2, ptr, (Ptr)new DoublePtr(arrayOfDouble3, 0), (Ptr)new DoublePtr(arrayOfDouble2, 0), (Ptr)new DoublePtr(new double[9], 0), (Ptr)new DoublePtr(arrayOfDouble1, 0));
    if (Rinternals.Rf_isNull(viewport__.viewportLayout(sEXP2)))
      Error.Rf_error(GetText.dgettext(new BytePtr("grid\000".getBytes(), 0), new BytePtr("there is no layout defined\000".getBytes(), 0)), new Object[0]); 
    SEXP sEXP1 = Rinternals.Rf_allocVector(14, 4);
    Rinternals.Rf_protect(sEXP1);
    layout__.calcViewportLocationFromLayout(paramSEXP1, paramSEXP2, sEXP2, (Ptr)mixedPtr);
    Rinternals2.REAL(sEXP1).setDouble(0, unit__.unitValue((SEXP)mixedPtr.getPointer().getArray(), 0));
    Rinternals2.REAL(sEXP1).setDouble(8, unit__.unitValue((SEXP)mixedPtr.getAlignedPointer(1).getArray(), 0));
    Rinternals2.REAL(sEXP1).setDouble(16, unit__.unitValue((SEXP)mixedPtr.getAlignedPointer(2).getArray(), 0));
    Rinternals2.REAL(sEXP1).setDouble(24, unit__.unitValue((SEXP)mixedPtr.getAlignedPointer(3).getArray(), 0));
    return sEXP1;
  }
  
  public static SEXP L_lineTo(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3) {
    double[] arrayOfDouble1 = new double[2];
    double[] arrayOfDouble2 = new double[2];
    MixedPtr mixedPtr1 = MixedPtr.malloc(276);
    MixedPtr mixedPtr2 = MixedPtr.malloc(32);
    double[] arrayOfDouble4 = new double[1];
    double[] arrayOfDouble5 = new double[1];
    double[] arrayOfDouble6 = new double[1];
    double[] arrayOfDouble7 = new double[1];
    double[] arrayOfDouble8 = new double[1];
    arrayOfDouble4[0] = 0.0D;
    arrayOfDouble5[0] = 0.0D;
    arrayOfDouble6[0] = 0.0D;
    arrayOfDouble7[0] = 0.0D;
    arrayOfDouble8[0] = 0.0D;
    Ptr ptr = getDevice();
    SEXP sEXP1 = state__.gridStateElement(ptr, 5);
    SEXP sEXP2 = state__.gridStateElement(ptr, 10);
    Rinternals.Rf_protect(sEXP2);
    SEXP sEXP3 = state__.gridStateElement(ptr, 1);
    Rinternals.Rf_protect(sEXP3);
    double[] arrayOfDouble3 = new double[9];
    getViewportTransform(state__.gridStateElement(ptr, 7), ptr, (Ptr)new DoublePtr(arrayOfDouble6, 0), (Ptr)new DoublePtr(arrayOfDouble5, 0), (Ptr)new DoublePtr(arrayOfDouble3, 0), (Ptr)new DoublePtr(arrayOfDouble4, 0));
    getViewportContext(state__.gridStateElement(ptr, 7), (Ptr)mixedPtr2);
    gpar__.gcontextFromgpar(sEXP1, 0, (Ptr)mixedPtr1, ptr);
    double d2 = arrayOfDouble5[0];
    double d1 = arrayOfDouble6[0];
    unit__.transformLocn(paramSEXP1, paramSEXP2, 0, mixedPtr2.copyOf(32), (Ptr)mixedPtr1, d1, d2, ptr, (Ptr)new DoublePtr(arrayOfDouble3, 0), (Ptr)new DoublePtr(arrayOfDouble8, 0), (Ptr)new DoublePtr(arrayOfDouble7, 0));
    Rinternals2.REAL(sEXP2).setDouble(0, Rinternals2.REAL(sEXP3).getDouble());
    Rinternals2.REAL(sEXP2).setDouble(8, Rinternals2.REAL(sEXP3).getDouble(8));
    Rinternals2.REAL(sEXP3).setDouble(0, arrayOfDouble8[0]);
    Rinternals2.REAL(sEXP3).setDouble(8, arrayOfDouble7[0]);
    double d4 = baseEngine__.GEtoDeviceX(Rinternals2.REAL(sEXP2).getDouble(), 2, ptr);
    double d3 = baseEngine__.GEtoDeviceY(Rinternals2.REAL(sEXP2).getDouble(8), 2, ptr);
    d2 = baseEngine__.GEtoDeviceX(arrayOfDouble8[0], 2, ptr);
    d1 = baseEngine__.GEtoDeviceY(arrayOfDouble7[0], 2, ptr);
    if (Arith.R_finite(d4) != 0 && Arith.R_finite(d3) != 0 && Arith.R_finite(d2) != 0 && Arith.R_finite(d1) != 0) {
      baseEngine__.GEMode(1, ptr);
      baseEngine__.GELine(d4, d3, d2, d1, (Ptr)mixedPtr1, ptr);
      if (!Rinternals.Rf_isNull(paramSEXP3)) {
        arrayOfDouble2[0] = d4;
        arrayOfDouble2[1] = d2;
        arrayOfDouble1[0] = d3;
        arrayOfDouble1[1] = d1;
        d2 = arrayOfDouble5[0];
        d1 = arrayOfDouble6[0];
        arrows((Ptr)new DoublePtr(arrayOfDouble2, 0), (Ptr)new DoublePtr(arrayOfDouble1, 0), 2, paramSEXP3, 0, 1, 1, mixedPtr2.copyOf(32), d1, d2, (Ptr)mixedPtr1, ptr);
      } 
      baseEngine__.GEMode(0, ptr);
    } 
    return Rinternals.R_NilValue;
  }
  
  public static SEXP L_lines(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4) {
    double[] arrayOfDouble1 = new double[9];
    MixedPtr mixedPtr1 = MixedPtr.malloc(276);
    MixedPtr mixedPtr2 = MixedPtr.malloc(32);
    double[] arrayOfDouble2 = new double[1];
    double[] arrayOfDouble3 = new double[1];
    double[] arrayOfDouble4 = new double[1];
    SEXP sEXP1 = (SEXP)BytePtr.of(0).getArray();
    BytePtr.of(0);
    sEXP1 = (SEXP)BytePtr.of(0).getArray();
    BytePtr.of(0);
    arrayOfDouble2[0] = 0.0D;
    arrayOfDouble3[0] = 0.0D;
    arrayOfDouble4[0] = 0.0D;
    BytePtr.of(0);
    BytePtr.of(0);
    byte b1 = 0;
    Ptr ptr = getDevice();
    SEXP sEXP2 = state__.gridStateElement(ptr.pointerPlus(0), 5);
    getViewportTransform(state__.gridStateElement(ptr.pointerPlus(0), 7), ptr.pointerPlus(0), (Ptr)new DoublePtr(arrayOfDouble4, 0), (Ptr)new DoublePtr(arrayOfDouble3, 0), (Ptr)new DoublePtr(arrayOfDouble1, 0), (Ptr)new DoublePtr(arrayOfDouble2, 0));
    getViewportContext(state__.gridStateElement(ptr.pointerPlus(0), 7), (Ptr)mixedPtr2);
    baseEngine__.GEMode(1, ptr.pointerPlus(0));
    int i = Rinternals.LENGTH(paramSEXP3);
    for (byte b2 = 0; b2 < i; b2++) {
      SEXP sEXP = Rinternals.VECTOR_ELT(paramSEXP3, b2);
      gpar__.gcontextFromgpar(sEXP2, b2, (Ptr)mixedPtr1, ptr.pointerPlus(0));
      int j = Rinternals.LENGTH(sEXP);
      VoidPtr.toPtr(Memory.vmaxget());
      DoublePtr doublePtr1 = DoublePtr.malloc(j * 8);
      DoublePtr doublePtr2 = DoublePtr.malloc(j * 8);
      double d1 = Arith.R_NaReal;
      double d2 = Arith.R_NaReal;
      for (byte b = 0; b < j; b++) {
        double d4 = arrayOfDouble3[0];
        double d3 = arrayOfDouble4[0];
        int k = Rinternals2.INTEGER(sEXP).getInt(0 + b * 4) + -1;
        Ptr ptr1 = mixedPtr2.copyOf(32);
        Ptr ptr2 = ptr.pointerPlus(0);
        Ptr ptr3 = (Ptr)new DoublePtr(arrayOfDouble1, 0);
        Ptr ptr4 = doublePtr1.pointerPlus(0 + b * 8);
        Ptr ptr5 = doublePtr2.pointerPlus(0 + b * 8);
        unit__.transformLocn(paramSEXP1, paramSEXP2, k, ptr1, (Ptr)mixedPtr1, d3, d4, ptr2, ptr3, ptr4, ptr5);
        doublePtr1.setDouble(0 + b * 8, baseEngine__.GEtoDeviceX(doublePtr1.getDouble(0 + b * 8), 2, ptr.pointerPlus(0)));
        doublePtr2.setDouble(0 + b * 8, baseEngine__.GEtoDeviceY(doublePtr2.getDouble(0 + b * 8), 2, ptr.pointerPlus(0)));
        if (Arith.R_finite(doublePtr1.getDouble(0 + b * 8)) == 0 || Arith.R_finite(doublePtr2.getDouble(0 + b * 8)) == 0 || (Arith.R_finite(d1) != 0 && Arith.R_finite(d2) != 0)) {
          if (Arith.R_finite(d1) == 0 || Arith.R_finite(d2) == 0 || (Arith.R_finite(doublePtr1.getDouble(0 + b * 8)) != 0 && Arith.R_finite(doublePtr2.getDouble(0 + b * 8)) != 0)) {
            if (Arith.R_finite(d1) != 0 && Arith.R_finite(d2) != 0 && j + -1 == b) {
              Ptr ptr6 = doublePtr1.pointerPlus(0 + b1 * 8);
              ptr1 = doublePtr2.pointerPlus(0 + b1 * 8);
              baseEngine__.GEPolyline(j - b1, ptr6, ptr1, (Ptr)mixedPtr1, ptr.pointerPlus(0));
              if (!Rinternals.Rf_isNull(paramSEXP4)) {
                boolean bool;
                d4 = arrayOfDouble3[0];
                d3 = arrayOfDouble4[0];
                if (b1 != 0) {
                  bool = false;
                } else {
                  bool = true;
                } 
                ptr6 = doublePtr1.pointerPlus(0 + b1 * 8);
                ptr1 = doublePtr2.pointerPlus(0 + b1 * 8);
                arrows(ptr6, ptr1, j - b1, paramSEXP4, b2, bool, 1, mixedPtr2.copyOf(32), d3, d4, (Ptr)mixedPtr1, ptr.pointerPlus(0));
              } 
            } 
          } else if (b - b1 > 1) {
            Ptr ptr6 = doublePtr1.pointerPlus(0 + b1 * 8);
            ptr1 = doublePtr2.pointerPlus(0 + b1 * 8);
            baseEngine__.GEPolyline(b - b1, ptr6, ptr1, (Ptr)mixedPtr1, ptr.pointerPlus(0));
            if (!Rinternals.Rf_isNull(paramSEXP4)) {
              boolean bool;
              d4 = arrayOfDouble3[0];
              d3 = arrayOfDouble4[0];
              if (b1 != 0) {
                bool = false;
              } else {
                bool = true;
              } 
              ptr6 = doublePtr1.pointerPlus(0 + b1 * 8);
              ptr1 = doublePtr2.pointerPlus(0 + b1 * 8);
              arrows(ptr6, ptr1, b - b1, paramSEXP4, b2, bool, 0, mixedPtr2.copyOf(32), d3, d4, (Ptr)mixedPtr1, ptr.pointerPlus(0));
            } 
          } 
        } else {
          b1 = b;
        } 
        d1 = doublePtr1.getDouble(0 + b * 8);
        d2 = doublePtr2.getDouble(0 + b * 8);
      } 
    } 
    baseEngine__.GEMode(0, ptr.pointerPlus(0));
    return Rinternals.R_NilValue;
  }
  
  public static SEXP L_locator() {
    double[] arrayOfDouble1 = new double[1];
    double[] arrayOfDouble2 = new double[1];
    arrayOfDouble2[0] = 0.0D;
    arrayOfDouble1[0] = 0.0D;
    Ptr ptr1 = getDevice();
    baseEngine__.GEMode(2, ptr1);
    SEXP sEXP = Rinternals.Rf_allocVector(14, 2);
    Rinternals.Rf_protect(sEXP);
    Ptr ptr2 = ptr1.getPointer();
    if (ptr1.getPointer().getPointer(220).toMethodHandle() == null || ptr1.getPointer().getPointer(220).toMethodHandle().invoke((Ptr)new DoublePtr(arrayOfDouble2, 0), (Ptr)new DoublePtr(arrayOfDouble1, 0), ptr2) == 0) {
      Rinternals2.REAL(sEXP).setDouble(0, Arith.R_NaReal);
      Rinternals2.REAL(sEXP).setDouble(8, Arith.R_NaReal);
      baseEngine__.GEMode(0, ptr1);
      return sEXP;
    } 
    Rinternals2.REAL(sEXP).setDouble(0, baseEngine__.GEfromDeviceX(arrayOfDouble2[0], 2, ptr1));
    Rinternals2.REAL(sEXP).setDouble(8, baseEngine__.GEfromDeviceY(arrayOfDouble1[0], 2, ptr1));
    baseEngine__.GEMode(0, ptr1);
    return sEXP;
  }
  
  public static SEXP L_locnBounds(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3) {
    DoublePtr doublePtr1;
    DoublePtr doublePtr2;
    double[] arrayOfDouble1 = new double[1];
    double[] arrayOfDouble2 = new double[1];
    MixedPtr mixedPtr1 = MixedPtr.malloc(276);
    MixedPtr mixedPtr2 = MixedPtr.malloc(32);
    double[] arrayOfDouble3 = new double[1];
    double[] arrayOfDouble4 = new double[1];
    double[] arrayOfDouble5 = new double[1];
    BytePtr.of(0);
    arrayOfDouble1[0] = 0.0D;
    arrayOfDouble2[0] = 0.0D;
    BytePtr.of(0);
    SEXP sEXP1 = (SEXP)BytePtr.of(0).getArray();
    sEXP1 = (SEXP)BytePtr.of(0).getArray();
    arrayOfDouble3[0] = 0.0D;
    arrayOfDouble4[0] = 0.0D;
    arrayOfDouble5[0] = 0.0D;
    Ptr ptr1 = BytePtr.of(0);
    Ptr ptr2 = BytePtr.of(0);
    SEXP sEXP2 = Rinternals.R_NilValue;
    double d1 = Double.MAX_VALUE;
    double d2 = -1.7976931348623157E308D;
    double d3 = Double.MAX_VALUE;
    double d4 = -1.7976931348623157E308D;
    Ptr ptr3 = getDevice();
    SEXP sEXP3 = state__.gridStateElement(ptr3.pointerPlus(0), 5);
    getViewportTransform(state__.gridStateElement(ptr3.pointerPlus(0), 7), ptr3.pointerPlus(0), (Ptr)new DoublePtr(arrayOfDouble5, 0), (Ptr)new DoublePtr(arrayOfDouble4, 0), (Ptr)new DoublePtr(new double[9], 0), (Ptr)new DoublePtr(arrayOfDouble3, 0));
    getViewportContext(state__.gridStateElement(ptr3.pointerPlus(0), 7), (Ptr)mixedPtr2);
    int i = unit__.unitLength(paramSEXP1);
    int j = unit__.unitLength(paramSEXP2);
    if (j > i)
      i = j; 
    j = 0;
    VoidPtr.toPtr(Memory.vmaxget());
    if (i > 0) {
      doublePtr2 = DoublePtr.malloc(i * 8);
      doublePtr1 = DoublePtr.malloc(i * 8);
      for (byte b = 0; b < i; b++) {
        gpar__.gcontextFromgpar(sEXP3, b, (Ptr)mixedPtr1, ptr3.pointerPlus(0));
        double d6 = arrayOfDouble4[0];
        double d5 = arrayOfDouble5[0];
        doublePtr2.setDouble(0 + b * 8, unit__.transformXtoINCHES(paramSEXP1, b, mixedPtr2.copyOf(32), (Ptr)mixedPtr1, d5, d6, ptr3.pointerPlus(0)));
        d6 = arrayOfDouble4[0];
        d5 = arrayOfDouble5[0];
        doublePtr1.setDouble(0 + b * 8, unit__.transformYtoINCHES(paramSEXP2, b, mixedPtr2.copyOf(32), (Ptr)mixedPtr1, d5, d6, ptr3.pointerPlus(0)));
        if (Arith.R_finite(doublePtr2.getDouble(0 + b * 8)) != 0 && Arith.R_finite(doublePtr1.getDouble(0 + b * 8)) != 0) {
          if (doublePtr2.getDouble(0 + b * 8) < d1)
            d1 = doublePtr2.getDouble(0 + b * 8); 
          if (doublePtr2.getDouble(0 + b * 8) > d2)
            d2 = doublePtr2.getDouble(0 + b * 8); 
          if (doublePtr1.getDouble(0 + b * 8) < d3)
            d3 = doublePtr1.getDouble(0 + b * 8); 
          if (doublePtr1.getDouble(0 + b * 8) > d4)
            d4 = doublePtr1.getDouble(0 + b * 8); 
          j++;
        } 
      } 
    } 
    if (j > 0) {
      double d = Rinternals2.REAL(paramSEXP3).getDouble();
      hullEdge(doublePtr2.pointerPlus(0), doublePtr1.pointerPlus(0), i, d, (Ptr)new DoublePtr(arrayOfDouble2, 0), (Ptr)new DoublePtr(arrayOfDouble1, 0));
      sEXP2 = Rinternals.Rf_allocVector(14, 4);
      Rinternals2.REAL(sEXP2).setDouble(0, arrayOfDouble2[0] / Rinternals2.REAL(state__.gridStateElement(ptr3.pointerPlus(0), 15)).getDouble());
      Rinternals2.REAL(sEXP2).setDouble(8, arrayOfDouble1[0] / Rinternals2.REAL(state__.gridStateElement(ptr3.pointerPlus(0), 15)).getDouble());
      Rinternals2.REAL(sEXP2).setDouble(16, (d2 - d1) / Rinternals2.REAL(state__.gridStateElement(ptr3.pointerPlus(0), 15)).getDouble());
      Rinternals2.REAL(sEXP2).setDouble(24, (d4 - d3) / Rinternals2.REAL(state__.gridStateElement(ptr3.pointerPlus(0), 15)).getDouble());
    } 
    return sEXP2;
  }
  
  public static SEXP L_moveTo(SEXP paramSEXP1, SEXP paramSEXP2) {
    MixedPtr mixedPtr1 = MixedPtr.malloc(276);
    MixedPtr mixedPtr2 = MixedPtr.malloc(32);
    double[] arrayOfDouble2 = new double[1];
    double[] arrayOfDouble3 = new double[1];
    double[] arrayOfDouble4 = new double[1];
    double[] arrayOfDouble5 = new double[1];
    double[] arrayOfDouble6 = new double[1];
    arrayOfDouble2[0] = 0.0D;
    arrayOfDouble3[0] = 0.0D;
    arrayOfDouble4[0] = 0.0D;
    arrayOfDouble5[0] = 0.0D;
    arrayOfDouble6[0] = 0.0D;
    Ptr ptr = getDevice();
    SEXP sEXP1 = state__.gridStateElement(ptr, 5);
    SEXP sEXP2 = state__.gridStateElement(ptr, 10);
    Rinternals.Rf_protect(sEXP2);
    SEXP sEXP3 = state__.gridStateElement(ptr, 1);
    Rinternals.Rf_protect(sEXP3);
    double[] arrayOfDouble1 = new double[9];
    getViewportTransform(state__.gridStateElement(ptr, 7), ptr, (Ptr)new DoublePtr(arrayOfDouble4, 0), (Ptr)new DoublePtr(arrayOfDouble3, 0), (Ptr)new DoublePtr(arrayOfDouble1, 0), (Ptr)new DoublePtr(arrayOfDouble2, 0));
    getViewportContext(state__.gridStateElement(ptr, 7), (Ptr)mixedPtr2);
    gpar__.gcontextFromgpar(sEXP1, 0, (Ptr)mixedPtr1, ptr);
    double d2 = arrayOfDouble3[0];
    double d1 = arrayOfDouble4[0];
    unit__.transformLocn(paramSEXP1, paramSEXP2, 0, mixedPtr2.copyOf(32), (Ptr)mixedPtr1, d1, d2, ptr, (Ptr)new DoublePtr(arrayOfDouble1, 0), (Ptr)new DoublePtr(arrayOfDouble6, 0), (Ptr)new DoublePtr(arrayOfDouble5, 0));
    Rinternals2.REAL(sEXP2).setDouble(0, Rinternals2.REAL(sEXP3).getDouble());
    Rinternals2.REAL(sEXP2).setDouble(8, Rinternals2.REAL(sEXP3).getDouble(8));
    Rinternals2.REAL(sEXP3).setDouble(0, arrayOfDouble6[0]);
    Rinternals2.REAL(sEXP3).setDouble(8, arrayOfDouble5[0]);
    return Rinternals.R_NilValue;
  }
  
  public static SEXP L_newpage() {
    MixedPtr mixedPtr = MixedPtr.malloc(276);
    Ptr ptr = getDevice();
    int j = baseEngine__.GEdeviceDirty(ptr);
    int i = Rinternals.LOGICAL(state__.gridStateElement(ptr, 9)).getInt();
    if (i == 0)
      dirtyGridDevice(ptr); 
    if (i != 0 || j != 0) {
      gpar__.gcontextFromgpar(state__.gridStateElement(ptr, 5), 0, (Ptr)mixedPtr, ptr);
      baseEngine__.GENewPage((Ptr)mixedPtr, ptr);
    } 
    return Rinternals.R_NilValue;
  }
  
  public static SEXP L_newpagerecording() {
    Ptr ptr = getDevice();
    if (ptr.getInt(124) != 0) {
      baseDevices__.Rf_NewFrameConfirm(ptr.getPointer(0));
      if (baseDevices__.Rf_NoDevices() != 0)
        Error.Rf_error(GetText.dgettext(new BytePtr("grid\000".getBytes(), 0), new BytePtr("attempt to plot on null device\000".getBytes(), 0)), new Object[0]); 
      ptr = baseDevices__.GEcurrentDevice();
    } 
    baseEngine__.GEinitDisplayList(ptr.pointerPlus(0));
    return Rinternals.R_NilValue;
  }
  
  public static SEXP L_path(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4) {
    double[] arrayOfDouble1 = new double[9];
    MixedPtr mixedPtr1 = MixedPtr.malloc(276);
    MixedPtr mixedPtr2 = MixedPtr.malloc(32);
    double[] arrayOfDouble2 = new double[1];
    double[] arrayOfDouble3 = new double[1];
    double[] arrayOfDouble4 = new double[1];
    SEXP sEXP1 = (SEXP)BytePtr.of(0).getArray();
    BytePtr.of(0);
    sEXP1 = (SEXP)BytePtr.of(0).getArray();
    arrayOfDouble2[0] = 0.0D;
    arrayOfDouble3[0] = 0.0D;
    arrayOfDouble4[0] = 0.0D;
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    Ptr ptr = getDevice();
    SEXP sEXP2 = state__.gridStateElement(ptr.pointerPlus(0), 5);
    getViewportTransform(state__.gridStateElement(ptr.pointerPlus(0), 7), ptr.pointerPlus(0), (Ptr)new DoublePtr(arrayOfDouble4, 0), (Ptr)new DoublePtr(arrayOfDouble3, 0), (Ptr)new DoublePtr(arrayOfDouble1, 0), (Ptr)new DoublePtr(arrayOfDouble2, 0));
    getViewportContext(state__.gridStateElement(ptr.pointerPlus(0), 7), (Ptr)mixedPtr2);
    baseEngine__.GEMode(1, ptr.pointerPlus(0));
    VoidPtr.toPtr(Memory.vmaxget());
    int j = Rinternals.LENGTH(paramSEXP3);
    int k = 0;
    IntPtr intPtr = IntPtr.malloc(j * 4);
    for (byte b1 = 0; b1 < j; b1++) {
      intPtr.setInt(0 + b1 * 4, Rinternals.LENGTH(Rinternals.VECTOR_ELT(paramSEXP3, b1)));
      k = intPtr.getInt(0 + b1 * 4) + k;
    } 
    DoublePtr doublePtr2 = DoublePtr.malloc(k * 8);
    DoublePtr doublePtr1 = DoublePtr.malloc(k * 8);
    byte b2 = 0;
    for (byte b3 = 0; b3 < j; b3++) {
      SEXP sEXP = Rinternals.VECTOR_ELT(paramSEXP3, b3);
      for (byte b = 0; intPtr.getInt(0 + b3 * 4) > b; b++) {
        double d2 = arrayOfDouble3[0];
        double d1 = arrayOfDouble4[0];
        int m = Rinternals2.INTEGER(sEXP).getInt(0 + b * 4) + -1;
        Ptr ptr1 = mixedPtr2.copyOf(32);
        Ptr ptr2 = ptr.pointerPlus(0);
        Ptr ptr3 = (Ptr)new DoublePtr(arrayOfDouble1, 0);
        Ptr ptr4 = doublePtr2.pointerPlus(0 + b2 * 8);
        Ptr ptr5 = doublePtr1.pointerPlus(0 + b2 * 8);
        unit__.transformLocn(paramSEXP1, paramSEXP2, m, ptr1, (Ptr)mixedPtr1, d1, d2, ptr2, ptr3, ptr4, ptr5);
        doublePtr2.setDouble(0 + b2 * 8, baseEngine__.GEtoDeviceX(doublePtr2.getDouble(0 + b2 * 8), 2, ptr.pointerPlus(0)));
        doublePtr1.setDouble(0 + b2 * 8, baseEngine__.GEtoDeviceY(doublePtr1.getDouble(0 + b2 * 8), 2, ptr.pointerPlus(0)));
        if (Arith.R_finite(doublePtr2.getDouble(0 + b2 * 8)) == 0 || Arith.R_finite(doublePtr1.getDouble(0 + b2 * 8)) == 0)
          Error.Rf_error(GetText.dgettext(new BytePtr("grid\000".getBytes(), 0), new BytePtr("non-finite x or y in graphics path\000".getBytes(), 0)), new Object[0]); 
        b2++;
      } 
    } 
    gpar__.gcontextFromgpar(sEXP2, 0, (Ptr)mixedPtr1, ptr.pointerPlus(0));
    int i = Rinternals2.INTEGER(paramSEXP4).getInt();
    baseEngine__.GEPath(doublePtr2.pointerPlus(0), doublePtr1.pointerPlus(0), j, intPtr.pointerPlus(0), i, (Ptr)mixedPtr1, ptr.pointerPlus(0));
    baseEngine__.GEMode(0, ptr.pointerPlus(0));
    return Rinternals.R_NilValue;
  }
  
  public static SEXP L_points(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4) {
    double[] arrayOfDouble1 = new double[9];
    MixedPtr mixedPtr1 = MixedPtr.malloc(276);
    MixedPtr mixedPtr2 = MixedPtr.malloc(32);
    double[] arrayOfDouble2 = new double[1];
    double[] arrayOfDouble3 = new double[1];
    double[] arrayOfDouble4 = new double[1];
    BytePtr.of(0);
    SEXP sEXP1 = (SEXP)BytePtr.of(0).getArray();
    BytePtr.of(0);
    arrayOfDouble2[0] = 0.0D;
    arrayOfDouble3[0] = 0.0D;
    arrayOfDouble4[0] = 0.0D;
    BytePtr.of(0);
    BytePtr.of(0);
    Ptr ptr = getDevice();
    SEXP sEXP2 = state__.gridStateElement(ptr.pointerPlus(0), 5);
    getViewportTransform(state__.gridStateElement(ptr.pointerPlus(0), 7), ptr.pointerPlus(0), (Ptr)new DoublePtr(arrayOfDouble4, 0), (Ptr)new DoublePtr(arrayOfDouble3, 0), (Ptr)new DoublePtr(arrayOfDouble1, 0), (Ptr)new DoublePtr(arrayOfDouble2, 0));
    getViewportContext(state__.gridStateElement(ptr.pointerPlus(0), 7), (Ptr)mixedPtr2);
    int i = unit__.unitLength(paramSEXP1);
    int j = Rinternals.LENGTH(paramSEXP3);
    VoidPtr.toPtr(Memory.vmaxget());
    DoublePtr doublePtr1 = DoublePtr.malloc(i * 8);
    DoublePtr doublePtr2 = DoublePtr.malloc(i * 8);
    for (byte b2 = 0; b2 < i; b2++) {
      gpar__.gcontextFromgpar(sEXP2, b2, (Ptr)mixedPtr1, ptr.pointerPlus(0));
      double d2 = arrayOfDouble3[0];
      double d1 = arrayOfDouble4[0];
      Ptr ptr1 = mixedPtr2.copyOf(32);
      Ptr ptr2 = ptr.pointerPlus(0);
      Ptr ptr3 = (Ptr)new DoublePtr(arrayOfDouble1, 0);
      Ptr ptr4 = doublePtr1.pointerPlus(0 + b2 * 8);
      Ptr ptr5 = doublePtr2.pointerPlus(0 + b2 * 8);
      unit__.transformLocn(paramSEXP1, paramSEXP2, b2, ptr1, (Ptr)mixedPtr1, d1, d2, ptr2, ptr3, ptr4, ptr5);
      doublePtr1.setDouble(0 + b2 * 8, baseEngine__.GEtoDeviceX(doublePtr1.getDouble(0 + b2 * 8), 2, ptr.pointerPlus(0)));
      doublePtr2.setDouble(0 + b2 * 8, baseEngine__.GEtoDeviceY(doublePtr2.getDouble(0 + b2 * 8), 2, ptr.pointerPlus(0)));
    } 
    baseEngine__.GEMode(1, ptr.pointerPlus(0));
    for (byte b1 = 0; b1 < i; b1++) {
      if (Arith.R_finite(doublePtr1.getDouble(0 + b1 * 8)) != 0 && Arith.R_finite(doublePtr2.getDouble(0 + b1 * 8)) != 0) {
        int k = Arith.R_NaInt;
        gpar__.gcontextFromgpar(sEXP2, b1, (Ptr)mixedPtr1, ptr.pointerPlus(0));
        double d2 = arrayOfDouble3[0];
        double d1 = arrayOfDouble4[0];
        d2 = baseEngine__.GEtoDeviceWidth(unit__.transformWidthtoINCHES(paramSEXP4, b1, mixedPtr2.copyOf(32), (Ptr)mixedPtr1, d1, d2, ptr.pointerPlus(0)), 2, ptr.pointerPlus(0));
        if (Arith.R_finite(d2) != 0) {
          if (!Rinternals.Rf_isString(paramSEXP3)) {
            if (!Rinternals.Rf_isInteger(paramSEXP3)) {
              if (!Rinternals.Rf_isReal(paramSEXP3)) {
                Error.Rf_error(GetText.dgettext(new BytePtr("grid\000".getBytes(), 0), new BytePtr("invalid plotting symbol\000".getBytes(), 0)), new Object[0]);
              } else {
                if (Arith.R_finite(Rinternals2.REAL(paramSEXP3).getDouble(0 + b1 % j * 8)) == 0) {
                  k = Arith.R_NaInt;
                } else {
                  k = (int)Rinternals2.REAL(paramSEXP3).getDouble(0 + b1 % j * 8);
                } 
                k = k;
              } 
            } else {
              k = Rinternals2.INTEGER(paramSEXP3).getInt(0 + b1 % j * 4);
            } 
          } else {
            k = baseEngine__.GEstring_to_pch(Rinternals.STRING_ELT(paramSEXP3, b1 % j));
          } 
          if (k == 46)
            d2 = gpar__.gpCex(sEXP2, b1); 
          d1 = doublePtr2.getDouble(0 + b1 * 8);
          baseEngine__.GESymbol(doublePtr1.getDouble(0 + b1 * 8), d1, k, d2, (Ptr)mixedPtr1, ptr.pointerPlus(0));
        } 
      } 
    } 
    baseEngine__.GEMode(0, ptr.pointerPlus(0));
    return Rinternals.R_NilValue;
  }
  
  public static SEXP L_polygon(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3) {
    double[] arrayOfDouble1 = new double[9];
    MixedPtr mixedPtr1 = MixedPtr.malloc(276);
    MixedPtr mixedPtr2 = MixedPtr.malloc(32);
    double[] arrayOfDouble2 = new double[1];
    double[] arrayOfDouble3 = new double[1];
    double[] arrayOfDouble4 = new double[1];
    SEXP sEXP1 = (SEXP)BytePtr.of(0).getArray();
    BytePtr.of(0);
    BytePtr.of(0);
    sEXP1 = (SEXP)BytePtr.of(0).getArray();
    arrayOfDouble2[0] = 0.0D;
    arrayOfDouble3[0] = 0.0D;
    arrayOfDouble4[0] = 0.0D;
    BytePtr.of(0);
    BytePtr.of(0);
    byte b1 = 0;
    Ptr ptr = getDevice();
    SEXP sEXP2 = state__.gridStateElement(ptr.pointerPlus(0), 5);
    getViewportTransform(state__.gridStateElement(ptr.pointerPlus(0), 7), ptr.pointerPlus(0), (Ptr)new DoublePtr(arrayOfDouble4, 0), (Ptr)new DoublePtr(arrayOfDouble3, 0), (Ptr)new DoublePtr(arrayOfDouble1, 0), (Ptr)new DoublePtr(arrayOfDouble2, 0));
    getViewportContext(state__.gridStateElement(ptr.pointerPlus(0), 7), (Ptr)mixedPtr2);
    baseEngine__.GEMode(1, ptr.pointerPlus(0));
    int i = Rinternals.LENGTH(paramSEXP3);
    for (byte b2 = 0; b2 < i; b2++) {
      SEXP sEXP = Rinternals.VECTOR_ELT(paramSEXP3, b2);
      gpar__.gcontextFromgpar(sEXP2, b2, (Ptr)mixedPtr1, ptr.pointerPlus(0));
      int j = Rinternals.LENGTH(sEXP);
      VoidPtr.toPtr(Memory.vmaxget());
      DoublePtr doublePtr1 = DoublePtr.malloc((j + 1) * 8);
      DoublePtr doublePtr2 = DoublePtr.malloc((j + 1) * 8);
      double d1 = Arith.R_NaReal;
      double d2 = Arith.R_NaReal;
      for (byte b = 0; b < j; b++) {
        double d4 = arrayOfDouble3[0];
        double d3 = arrayOfDouble4[0];
        int k = Rinternals2.INTEGER(sEXP).getInt(0 + b * 4) + -1;
        Ptr ptr1 = mixedPtr2.copyOf(32);
        Ptr ptr2 = ptr.pointerPlus(0);
        Ptr ptr3 = (Ptr)new DoublePtr(arrayOfDouble1, 0);
        Ptr ptr4 = doublePtr1.pointerPlus(0 + b * 8);
        Ptr ptr5 = doublePtr2.pointerPlus(0 + b * 8);
        unit__.transformLocn(paramSEXP1, paramSEXP2, k, ptr1, (Ptr)mixedPtr1, d3, d4, ptr2, ptr3, ptr4, ptr5);
        doublePtr1.setDouble(0 + b * 8, baseEngine__.GEtoDeviceX(doublePtr1.getDouble(0 + b * 8), 2, ptr.pointerPlus(0)));
        doublePtr2.setDouble(0 + b * 8, baseEngine__.GEtoDeviceY(doublePtr2.getDouble(0 + b * 8), 2, ptr.pointerPlus(0)));
        if (Arith.R_finite(doublePtr1.getDouble(0 + b * 8)) == 0 || Arith.R_finite(doublePtr2.getDouble(0 + b * 8)) == 0 || (Arith.R_finite(d1) != 0 && Arith.R_finite(d2) != 0)) {
          if (Arith.R_finite(d1) == 0 || Arith.R_finite(d2) == 0 || (Arith.R_finite(doublePtr1.getDouble(0 + b * 8)) != 0 && Arith.R_finite(doublePtr2.getDouble(0 + b * 8)) != 0)) {
            if (Arith.R_finite(d1) != 0 && Arith.R_finite(d2) != 0 && j + -1 == b) {
              Ptr ptr6 = doublePtr1.pointerPlus(0 + b1 * 8);
              ptr1 = doublePtr2.pointerPlus(0 + b1 * 8);
              baseEngine__.GEPolygon(j - b1, ptr6, ptr1, (Ptr)mixedPtr1, ptr.pointerPlus(0));
            } 
          } else if (b - b1 > 1) {
            Ptr ptr6 = doublePtr1.pointerPlus(0 + b1 * 8);
            ptr1 = doublePtr2.pointerPlus(0 + b1 * 8);
            baseEngine__.GEPolygon(b - b1, ptr6, ptr1, (Ptr)mixedPtr1, ptr.pointerPlus(0));
          } 
        } else {
          b1 = b;
        } 
        d1 = doublePtr1.getDouble(0 + b * 8);
        d2 = doublePtr2.getDouble(0 + b * 8);
      } 
    } 
    baseEngine__.GEMode(0, ptr.pointerPlus(0));
    return Rinternals.R_NilValue;
  }
  
  public static SEXP L_pretty(SEXP paramSEXP) {
    byte b;
    int[] arrayOfInt = new int[1];
    double[] arrayOfDouble1 = new double[3];
    double[] arrayOfDouble2 = new double[1];
    double[] arrayOfDouble3 = new double[1];
    arrayOfDouble3[0] = util__.numeric(paramSEXP, 0);
    arrayOfDouble2[0] = util__.numeric(paramSEXP, 1);
    BytePtr.of(0);
    arrayOfInt[0] = 5;
    if (arrayOfDouble3[0] <= arrayOfDouble2[0]) {
      b = 0;
    } else {
      b = 1;
    } 
    int i = b;
    if (b) {
      arrayOfDouble3[0] = arrayOfDouble2[0];
      arrayOfDouble2[0] = arrayOfDouble3[0];
    } 
    baseEngine__.GEPretty((Ptr)new DoublePtr(arrayOfDouble3, 0), (Ptr)new DoublePtr(arrayOfDouble2, 0), (Ptr)new IntPtr(arrayOfInt, 0));
    if (i) {
      arrayOfDouble3[0] = arrayOfDouble2[0];
      arrayOfDouble2[0] = arrayOfDouble3[0];
    } 
    arrayOfDouble1[0] = arrayOfDouble3[0];
    arrayOfDouble1[1] = arrayOfDouble2[0];
    arrayOfDouble1[2] = arrayOfInt[0];
    i = arrayOfInt[0];
    throw new UnsatisfiedLinkException("Rf_CreateAtVector");
  }
  
  public static SEXP L_raster(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4, SEXP paramSEXP5, SEXP paramSEXP6, SEXP paramSEXP7, SEXP paramSEXP8) {
    Ptr ptr2;
    double[] arrayOfDouble1 = new double[1];
    double[] arrayOfDouble2 = new double[1];
    double[] arrayOfDouble3 = new double[1];
    double[] arrayOfDouble4 = new double[1];
    double[] arrayOfDouble5 = new double[9];
    MixedPtr mixedPtr1 = MixedPtr.malloc(276);
    MixedPtr mixedPtr2 = MixedPtr.malloc(32);
    double[] arrayOfDouble6 = new double[1];
    double[] arrayOfDouble7 = new double[1];
    double[] arrayOfDouble8 = new double[1];
    double[] arrayOfDouble9 = new double[1];
    double[] arrayOfDouble10 = new double[1];
    arrayOfDouble1[0] = 0.0D;
    arrayOfDouble2[0] = 0.0D;
    arrayOfDouble3[0] = 0.0D;
    arrayOfDouble4[0] = 0.0D;
    BytePtr.of(0);
    BytePtr.of(0);
    SEXP sEXP1 = (SEXP)BytePtr.of(0).getArray();
    sEXP1 = (SEXP)BytePtr.of(0).getArray();
    arrayOfDouble6[0] = 0.0D;
    arrayOfDouble7[0] = 0.0D;
    arrayOfDouble8[0] = 0.0D;
    arrayOfDouble9[0] = 0.0D;
    arrayOfDouble10[0] = 0.0D;
    BytePtr.of(0);
    Ptr ptr1 = getDevice();
    SEXP sEXP2 = state__.gridStateElement(ptr1.pointerPlus(0), 5);
    getViewportTransform(state__.gridStateElement(ptr1.pointerPlus(0), 7), ptr1.pointerPlus(0), (Ptr)new DoublePtr(arrayOfDouble8, 0), (Ptr)new DoublePtr(arrayOfDouble7, 0), (Ptr)new DoublePtr(arrayOfDouble5, 0), (Ptr)new DoublePtr(arrayOfDouble6, 0));
    getViewportContext(state__.gridStateElement(ptr1.pointerPlus(0), 7), (Ptr)mixedPtr2);
    int m = Rinternals.LENGTH(paramSEXP1);
    if (m <= 0)
      Error.Rf_error(GetText.dgettext(new BytePtr("grid\000".getBytes(), 0), new BytePtr("Empty raster\000".getBytes(), 0)), new Object[0]); 
    VoidPtr.toPtr(Memory.vmaxget());
    if (!Rinternals.Rf_inherits(paramSEXP1, new BytePtr("nativeRaster\000".getBytes(), 0)) || !Rinternals.Rf_isInteger(paramSEXP1)) {
      IntPtr intPtr = IntPtr.malloc(m * 4);
      for (byte b = 0; b < m; b++)
        intPtr.setInt(0 + b * 4, colors__.Rf_RGBpar3(paramSEXP1, b, 16777215)); 
    } else {
      ptr2 = Rinternals2.INTEGER(paramSEXP1);
    } 
    paramSEXP1 = Rinternals.Rf_getAttrib(paramSEXP1, Rinternals.R_DimSymbol);
    m = unit__.unitLength(paramSEXP2);
    int k = unit__.unitLength(paramSEXP3);
    int j = unit__.unitLength(paramSEXP4);
    int i = unit__.unitLength(paramSEXP5);
    if (k > m)
      m = k; 
    if (j > m)
      m = j; 
    if (i > m)
      m = i; 
    baseEngine__.GEMode(1, ptr1.pointerPlus(0));
    for (i = 0; i < m; i++) {
      gpar__.gcontextFromgpar(sEXP2, i, (Ptr)mixedPtr1, ptr1.pointerPlus(0));
      double d1 = arrayOfDouble7[0];
      double d3 = arrayOfDouble8[0];
      unit__.transformLocn(paramSEXP2, paramSEXP3, i, mixedPtr2.copyOf(32), (Ptr)mixedPtr1, d3, d1, ptr1.pointerPlus(0), (Ptr)new DoublePtr(arrayOfDouble5, 0), (Ptr)new DoublePtr(arrayOfDouble10, 0), (Ptr)new DoublePtr(arrayOfDouble9, 0));
      d1 = arrayOfDouble7[0];
      d3 = arrayOfDouble8[0];
      d3 = unit__.transformWidthtoINCHES(paramSEXP4, i, mixedPtr2.copyOf(32), (Ptr)mixedPtr1, d3, d1, ptr1.pointerPlus(0));
      double d2 = arrayOfDouble7[0];
      d1 = arrayOfDouble8[0];
      d1 = unit__.transformHeighttoINCHES(paramSEXP5, i, mixedPtr2.copyOf(32), (Ptr)mixedPtr1, d1, d2, ptr1.pointerPlus(0));
      if (arrayOfDouble6[0] != 0.0D) {
        d2 = Rinternals2.REAL(paramSEXP7).getDouble(0 + i % Rinternals.LENGTH(paramSEXP7) * 8);
        just__.justification(d3, d1, Rinternals2.REAL(paramSEXP6).getDouble(0 + i % Rinternals.LENGTH(paramSEXP6) * 8), d2, (Ptr)new DoublePtr(arrayOfDouble4, 0), (Ptr)new DoublePtr(arrayOfDouble3, 0));
        Rinternals.Rf_protect(unit__.unit(arrayOfDouble4[0], 2));
        Rinternals.Rf_protect(unit__.unit(arrayOfDouble3[0], 2));
        double d5 = arrayOfDouble6[0];
        double d4 = arrayOfDouble7[0];
        d2 = arrayOfDouble8[0];
        unit__.transformDimn(unit__.unit(arrayOfDouble4[0], 2), unit__.unit(arrayOfDouble3[0], 2), 0, mixedPtr2.copyOf(32), (Ptr)mixedPtr1, d2, d4, ptr1.pointerPlus(0), d5, (Ptr)new DoublePtr(arrayOfDouble2, 0), (Ptr)new DoublePtr(arrayOfDouble1, 0));
        d4 = arrayOfDouble9[0] + arrayOfDouble1[0];
        d2 = baseEngine__.GEtoDeviceX(arrayOfDouble10[0] + arrayOfDouble2[0], 2, ptr1.pointerPlus(0));
        d4 = baseEngine__.GEtoDeviceY(d4, 2, ptr1.pointerPlus(0));
        d3 = baseEngine__.GEtoDeviceWidth(d3, 2, ptr1.pointerPlus(0));
        d5 = baseEngine__.GEtoDeviceHeight(d1, 2, ptr1.pointerPlus(0));
        if (Arith.R_finite(d2) != 0 && Arith.R_finite(d4) != 0 && Arith.R_finite(d3) != 0 && Arith.R_finite(d5) != 0) {
          int n = Rinternals.LOGICAL(paramSEXP8).getInt(0 + i % Rinternals.LENGTH(paramSEXP8) * 4);
          d1 = arrayOfDouble6[0];
          k = Rinternals2.INTEGER(paramSEXP1).getInt();
          j = Rinternals2.INTEGER(paramSEXP1).getInt(4);
          baseEngine__.GERaster(ptr2.pointerPlus(0), j, k, d2, d4, d3, d5, d1, n, (Ptr)mixedPtr1, ptr1.pointerPlus(0));
        } 
      } else {
        d2 = Rinternals2.REAL(paramSEXP6).getDouble(0 + i % Rinternals.LENGTH(paramSEXP6) * 8);
        arrayOfDouble10[0] = just__.justifyX(arrayOfDouble10[0], d3, d2);
        d2 = Rinternals2.REAL(paramSEXP7).getDouble(0 + i % Rinternals.LENGTH(paramSEXP7) * 8);
        arrayOfDouble9[0] = just__.justifyY(arrayOfDouble9[0], d1, d2);
        arrayOfDouble10[0] = baseEngine__.GEtoDeviceX(arrayOfDouble10[0], 2, ptr1.pointerPlus(0));
        arrayOfDouble9[0] = baseEngine__.GEtoDeviceY(arrayOfDouble9[0], 2, ptr1.pointerPlus(0));
        d3 = baseEngine__.GEtoDeviceWidth(d3, 2, ptr1.pointerPlus(0));
        double d = baseEngine__.GEtoDeviceHeight(d1, 2, ptr1.pointerPlus(0));
        if (Arith.R_finite(arrayOfDouble10[0]) != 0 && Arith.R_finite(arrayOfDouble9[0]) != 0 && Arith.R_finite(d3) != 0 && Arith.R_finite(d) != 0) {
          int n = Rinternals.LOGICAL(paramSEXP8).getInt(0 + i % Rinternals.LENGTH(paramSEXP8) * 4);
          double d4 = arrayOfDouble6[0];
          d2 = arrayOfDouble9[0];
          d1 = arrayOfDouble10[0];
          k = Rinternals2.INTEGER(paramSEXP1).getInt();
          j = Rinternals2.INTEGER(paramSEXP1).getInt(4);
          baseEngine__.GERaster(ptr2.pointerPlus(0), j, k, d1, d2, d3, d, d4, n, (Ptr)mixedPtr1, ptr1.pointerPlus(0));
        } 
      } 
    } 
    baseEngine__.GEMode(0, ptr1.pointerPlus(0));
    return Rinternals.R_NilValue;
  }
  
  public static SEXP L_rect(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4, SEXP paramSEXP5, SEXP paramSEXP6) {
    gridRect(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4, paramSEXP5, paramSEXP6, 0.0D, 1);
    return Rinternals.R_NilValue;
  }
  
  public static SEXP L_rectBounds(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4, SEXP paramSEXP5, SEXP paramSEXP6, SEXP paramSEXP7) {
    return gridRect(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4, paramSEXP5, paramSEXP6, Rinternals2.REAL(paramSEXP7).getDouble(), 0);
  }
  
  public static SEXP L_segments(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4, SEXP paramSEXP5) {
    double[] arrayOfDouble1 = new double[2];
    double[] arrayOfDouble2 = new double[2];
    double[] arrayOfDouble3 = new double[1];
    double[] arrayOfDouble4 = new double[1];
    double[] arrayOfDouble5 = new double[1];
    double[] arrayOfDouble6 = new double[1];
    double[] arrayOfDouble7 = new double[9];
    MixedPtr mixedPtr1 = MixedPtr.malloc(276);
    MixedPtr mixedPtr2 = MixedPtr.malloc(32);
    double[] arrayOfDouble8 = new double[1];
    double[] arrayOfDouble9 = new double[1];
    double[] arrayOfDouble10 = new double[1];
    arrayOfDouble3[0] = 0.0D;
    arrayOfDouble4[0] = 0.0D;
    arrayOfDouble5[0] = 0.0D;
    arrayOfDouble6[0] = 0.0D;
    BytePtr.of(0);
    SEXP sEXP1 = (SEXP)BytePtr.of(0).getArray();
    arrayOfDouble8[0] = 0.0D;
    arrayOfDouble9[0] = 0.0D;
    arrayOfDouble10[0] = 0.0D;
    Ptr ptr = getDevice();
    SEXP sEXP2 = state__.gridStateElement(ptr.pointerPlus(0), 5);
    getViewportTransform(state__.gridStateElement(ptr.pointerPlus(0), 7), ptr.pointerPlus(0), (Ptr)new DoublePtr(arrayOfDouble10, 0), (Ptr)new DoublePtr(arrayOfDouble9, 0), (Ptr)new DoublePtr(arrayOfDouble7, 0), (Ptr)new DoublePtr(arrayOfDouble8, 0));
    getViewportContext(state__.gridStateElement(ptr.pointerPlus(0), 7), (Ptr)mixedPtr2);
    int i = unit__.unitLength(paramSEXP1);
    int m = unit__.unitLength(paramSEXP2);
    int k = unit__.unitLength(paramSEXP3);
    int j = unit__.unitLength(paramSEXP4);
    if (m > i)
      i = m; 
    if (k > i)
      i = k; 
    if (j > i)
      i = j; 
    baseEngine__.GEMode(1, ptr.pointerPlus(0));
    for (j = 0; j < i; j++) {
      gpar__.gcontextFromgpar(sEXP2, j, (Ptr)mixedPtr1, ptr.pointerPlus(0));
      double d2 = arrayOfDouble9[0];
      double d1 = arrayOfDouble10[0];
      unit__.transformLocn(paramSEXP1, paramSEXP2, j, mixedPtr2.copyOf(32), (Ptr)mixedPtr1, d1, d2, ptr.pointerPlus(0), (Ptr)new DoublePtr(arrayOfDouble7, 0), (Ptr)new DoublePtr(arrayOfDouble6, 0), (Ptr)new DoublePtr(arrayOfDouble5, 0));
      d2 = arrayOfDouble9[0];
      d1 = arrayOfDouble10[0];
      unit__.transformLocn(paramSEXP3, paramSEXP4, j, mixedPtr2.copyOf(32), (Ptr)mixedPtr1, d1, d2, ptr.pointerPlus(0), (Ptr)new DoublePtr(arrayOfDouble7, 0), (Ptr)new DoublePtr(arrayOfDouble4, 0), (Ptr)new DoublePtr(arrayOfDouble3, 0));
      arrayOfDouble6[0] = baseEngine__.GEtoDeviceX(arrayOfDouble6[0], 2, ptr.pointerPlus(0));
      arrayOfDouble5[0] = baseEngine__.GEtoDeviceY(arrayOfDouble5[0], 2, ptr.pointerPlus(0));
      arrayOfDouble4[0] = baseEngine__.GEtoDeviceX(arrayOfDouble4[0], 2, ptr.pointerPlus(0));
      arrayOfDouble3[0] = baseEngine__.GEtoDeviceY(arrayOfDouble3[0], 2, ptr.pointerPlus(0));
      if (Arith.R_finite(arrayOfDouble6[0]) != 0 && Arith.R_finite(arrayOfDouble5[0]) != 0 && Arith.R_finite(arrayOfDouble4[0]) != 0 && Arith.R_finite(arrayOfDouble3[0]) != 0) {
        baseEngine__.GELine(arrayOfDouble6[0], arrayOfDouble5[0], arrayOfDouble4[0], arrayOfDouble3[0], (Ptr)mixedPtr1, ptr.pointerPlus(0));
        if (!Rinternals.Rf_isNull(paramSEXP5)) {
          arrayOfDouble2[0] = arrayOfDouble6[0];
          arrayOfDouble2[1] = arrayOfDouble4[0];
          arrayOfDouble1[0] = arrayOfDouble5[0];
          arrayOfDouble1[1] = arrayOfDouble3[0];
          d2 = arrayOfDouble9[0];
          d1 = arrayOfDouble10[0];
          arrows((Ptr)new DoublePtr(arrayOfDouble2, 0), (Ptr)new DoublePtr(arrayOfDouble1, 0), 2, paramSEXP5, j, 1, 1, mixedPtr2.copyOf(32), d1, d2, (Ptr)mixedPtr1, ptr.pointerPlus(0));
        } 
      } 
    } 
    baseEngine__.GEMode(0, ptr.pointerPlus(0));
    return Rinternals.R_NilValue;
  }
  
  public static SEXP L_setCurrentGrob(SEXP paramSEXP) {
    state__.setGridStateElement(getDevice(), 12, paramSEXP);
    return Rinternals.R_NilValue;
  }
  
  public static SEXP L_setDLelt(SEXP paramSEXP) {
    SEXP sEXP = state__.gridStateElement(getDevice(), 2);
    Rinternals.Rf_protect(sEXP);
    int i = Rinternals2.INTEGER(state__.gridStateElement(getDevice(), 3)).getInt();
    Rinternals.SET_VECTOR_ELT(sEXP, i, paramSEXP);
    return Rinternals.R_NilValue;
  }
  
  public static SEXP L_setDLindex(SEXP paramSEXP) {
    state__.setGridStateElement(getDevice(), 3, paramSEXP);
    return Rinternals.R_NilValue;
  }
  
  public static SEXP L_setDLon(SEXP paramSEXP) {
    SEXP sEXP = state__.gridStateElement(getDevice(), 4);
    state__.setGridStateElement(getDevice(), 4, paramSEXP);
    return sEXP;
  }
  
  public static SEXP L_setDisplayList(SEXP paramSEXP) {
    state__.setGridStateElement(getDevice(), 2, paramSEXP);
    return Rinternals.R_NilValue;
  }
  
  public static SEXP L_setEngineDLon(SEXP paramSEXP) {
    state__.setGridStateElement(getDevice(), 11, paramSEXP);
    return Rinternals.R_NilValue;
  }
  
  public static SEXP L_setEngineRecording(SEXP paramSEXP) {
    state__.setGridStateElement(getDevice(), 13, paramSEXP);
    return Rinternals.R_NilValue;
  }
  
  public static SEXP L_setviewport(SEXP paramSEXP1, SEXP paramSEXP2) {
    boolean bool;
    Ptr ptr = getDevice();
    paramSEXP1 = Rinternals.Rf_duplicate(paramSEXP1);
    Rinternals.Rf_protect(paramSEXP1);
    Rinternals.Rf_protect(Rinternals.Rf_lang2(Rinternals.Rf_install(new BytePtr("pushedvp\000".getBytes(), 0)), paramSEXP1));
    paramSEXP1 = Rinternals.Rf_eval(Rinternals.Rf_lang2(Rinternals.Rf_install(new BytePtr("pushedvp\000".getBytes(), 0)), paramSEXP1), R_gridEvalEnv);
    Rinternals.Rf_protect(paramSEXP1);
    if (Rinternals.LOGICAL(paramSEXP2).getInt() != 0) {
      bool = false;
    } else {
      bool = true;
    } 
    state__.setGridStateElement(ptr, 7, doSetViewport(paramSEXP1, bool, 1, ptr));
    return Rinternals.R_NilValue;
  }
  
  public static SEXP L_stringMetric(SEXP paramSEXP) {
    double[] arrayOfDouble1 = new double[1];
    double[] arrayOfDouble2 = new double[1];
    double[] arrayOfDouble3 = new double[1];
    MixedPtr mixedPtr1 = MixedPtr.malloc(276);
    MixedPtr mixedPtr2 = MixedPtr.malloc(32);
    double[] arrayOfDouble4 = new double[1];
    BytePtr.of(0);
    arrayOfDouble1[0] = 0.0D;
    arrayOfDouble2[0] = 0.0D;
    arrayOfDouble3[0] = 0.0D;
    BytePtr.of(0);
    SEXP sEXP5 = (SEXP)BytePtr.of(0).getArray();
    sEXP5 = (SEXP)BytePtr.of(0).getArray();
    sEXP5 = (SEXP)BytePtr.of(0).getArray();
    sEXP5 = (SEXP)BytePtr.of(0).getArray();
    sEXP5 = (SEXP)BytePtr.of(0).getArray();
    arrayOfDouble4[0] = 0.0D;
    double[] arrayOfDouble5 = new double[1];
    arrayOfDouble5[0] = 0.0D;
    double[] arrayOfDouble6 = new double[1];
    arrayOfDouble6[0] = 0.0D;
    sEXP5 = Rinternals.R_NilValue;
    sEXP5 = Rinternals.R_NilValue;
    sEXP5 = Rinternals.R_NilValue;
    sEXP5 = Rinternals.R_NilValue;
    Ptr ptr = getDevice();
    SEXP sEXP6 = state__.gridStateElement(ptr.pointerPlus(0), 5);
    getViewportTransform(state__.gridStateElement(ptr.pointerPlus(0), 7), ptr.pointerPlus(0), (Ptr)new DoublePtr(arrayOfDouble6, 0), (Ptr)new DoublePtr(arrayOfDouble5, 0), (Ptr)new DoublePtr(new double[9], 0), (Ptr)new DoublePtr(arrayOfDouble4, 0));
    getViewportContext(state__.gridStateElement(ptr.pointerPlus(0), 7), (Ptr)mixedPtr2);
    SEXP sEXP2 = paramSEXP;
    if (!Rinternals.Rf_isSymbol(paramSEXP) && !Rinternals.Rf_isLanguage(paramSEXP)) {
      if (!Rinternals.Rf_isExpression(paramSEXP))
        sEXP2 = Rinternals.Rf_coerceVector(paramSEXP, 16); 
    } else {
      sEXP2 = Rinternals.Rf_coerceVector(paramSEXP, 20);
    } 
    Rinternals.Rf_protect(sEXP2);
    int i = Rinternals.LENGTH(sEXP2);
    VoidPtr.toPtr(Memory.vmaxget());
    paramSEXP = Rinternals.Rf_allocVector(14, i);
    Rinternals.Rf_protect(paramSEXP);
    SEXP sEXP3 = Rinternals.Rf_allocVector(14, i);
    Rinternals.Rf_protect(sEXP3);
    SEXP sEXP4 = Rinternals.Rf_allocVector(14, i);
    Rinternals.Rf_protect(sEXP4);
    if (i > 0) {
      byte b = 0;
      while (b < i) {
        gpar__.gcontextFromgpar(sEXP6, b, (Ptr)mixedPtr1, ptr.pointerPlus(0));
        if (!Rinternals.Rf_isExpression(sEXP2)) {
          int j = Rinternals.Rf_getCharCE(Rinternals.STRING_ELT(sEXP2, b));
          baseEngine__.GEStrMetric((Ptr)Rinternals.R_CHAR(Rinternals.STRING_ELT(sEXP2, b)), j, (Ptr)mixedPtr1, (Ptr)new DoublePtr(arrayOfDouble3, 0), (Ptr)new DoublePtr(arrayOfDouble2, 0), (Ptr)new DoublePtr(arrayOfDouble1, 0), ptr.pointerPlus(0));
          Rinternals2.REAL(paramSEXP).setDouble(0 + b * 8, baseEngine__.GEfromDeviceHeight(arrayOfDouble3[0], 2, ptr.pointerPlus(0)) / Rinternals2.REAL(state__.gridStateElement(ptr.pointerPlus(0), 15)).getDouble());
          Rinternals2.REAL(sEXP3).setDouble(0 + b * 8, baseEngine__.GEfromDeviceHeight(arrayOfDouble2[0], 2, ptr.pointerPlus(0)) / Rinternals2.REAL(state__.gridStateElement(ptr.pointerPlus(0), 15)).getDouble());
          Rinternals2.REAL(sEXP4).setDouble(0 + b * 8, baseEngine__.GEfromDeviceWidth(arrayOfDouble1[0], 2, ptr.pointerPlus(0)) / Rinternals2.REAL(state__.gridStateElement(ptr.pointerPlus(0), 15)).getDouble());
          b++;
          continue;
        } 
        Rinternals.VECTOR_ELT(sEXP2, b % Rinternals.LENGTH(sEXP2));
        throw new UnsatisfiedLinkException("GEExpressionMetric");
      } 
    } 
    SEXP sEXP1 = Rinternals.Rf_allocVector(19, 3);
    Rinternals.Rf_protect(sEXP1);
    Rinternals.SET_VECTOR_ELT(sEXP1, 0, paramSEXP);
    Rinternals.SET_VECTOR_ELT(sEXP1, 1, sEXP3);
    Rinternals.SET_VECTOR_ELT(sEXP1, 2, sEXP4);
    return sEXP1;
  }
  
  public static SEXP L_text(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4, SEXP paramSEXP5, SEXP paramSEXP6, SEXP paramSEXP7) {
    gridText(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4, paramSEXP5, paramSEXP6, paramSEXP7, 0.0D, 1);
    return Rinternals.R_NilValue;
  }
  
  public static SEXP L_textBounds(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4, SEXP paramSEXP5, SEXP paramSEXP6, SEXP paramSEXP7) {
    Rinternals.LOGICAL(Rinternals.Rf_allocVector(10, 1)).setInt(0, 0);
    return gridText(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4, paramSEXP5, paramSEXP6, Rinternals.Rf_allocVector(10, 1), Rinternals2.REAL(paramSEXP7).getDouble(), 0);
  }
  
  public static SEXP L_unsetviewport(SEXP paramSEXP) {
    double[] arrayOfDouble1 = new double[1];
    double[] arrayOfDouble2 = new double[1];
    BytePtr.of(0);
    arrayOfDouble1[0] = 0.0D;
    arrayOfDouble2[0] = 0.0D;
    Ptr ptr = getDevice();
    SEXP sEXP3 = state__.gridStateElement(ptr.pointerPlus(0), 7);
    SEXP sEXP4 = Rinternals.VECTOR_ELT(sEXP3, 26);
    if (Rinternals.Rf_isNull(sEXP4))
      Error.Rf_error(GetText.dgettext(new BytePtr("grid\000".getBytes(), 0), new BytePtr("cannot pop the top-level viewport ('grid' and 'graphics' output mixed?)\000".getBytes(), 0)), new Object[0]); 
    for (byte b = 1; Rinternals2.INTEGER(paramSEXP).getInt() > b; b++) {
      sEXP3 = sEXP4;
      sEXP4 = Rinternals.VECTOR_ELT(sEXP4, 26);
      if (Rinternals.Rf_isNull(sEXP4))
        Error.Rf_error(GetText.dgettext(new BytePtr("grid\000".getBytes(), 0), new BytePtr("cannot pop the top-level viewport ('grid' and 'graphics' output mixed?)\000".getBytes(), 0)), new Object[0]); 
    } 
    Rinternals.Rf_protect(sEXP3);
    Rinternals.Rf_protect(sEXP4);
    paramSEXP = Rinternals.Rf_allocVector(10, 1);
    Rinternals.Rf_protect(paramSEXP);
    Rinternals.LOGICAL(paramSEXP).setInt(0, 0);
    SEXP sEXP2 = Rinternals.VECTOR_ELT(sEXP4, 27);
    SEXP sEXP1 = Rinternals.VECTOR_ELT(sEXP3, 16);
    paramSEXP = Rinternals.Rf_lang4(Rinternals.Rf_install(new BytePtr("remove\000".getBytes(), 0)), sEXP1, sEXP2, paramSEXP);
    Rinternals.Rf_protect(paramSEXP);
    Rinternals.SET_TAG(Rinternals.CDR(Rinternals.CDR(paramSEXP)), Rinternals.Rf_install(new BytePtr("envir\000".getBytes(), 0)));
    Rinternals.SET_TAG(Rinternals.CDR(Rinternals.CDR(Rinternals.CDR(paramSEXP))), Rinternals.Rf_install(new BytePtr("inherits\000".getBytes(), 0)));
    Rinternals.Rf_eval(paramSEXP, R_gridEvalEnv);
    getDeviceSize(ptr.pointerPlus(0), (Ptr)new DoublePtr(arrayOfDouble2, 0), (Ptr)new DoublePtr(arrayOfDouble1, 0));
    if (deviceChanged(arrayOfDouble2[0], arrayOfDouble1[0], sEXP4) != 0)
      viewport__.calcViewportTransform(sEXP4, viewport__.viewportParent(sEXP4), 1, ptr.pointerPlus(0)); 
    paramSEXP = viewport__.viewportgpar(sEXP4);
    state__.setGridStateElement(ptr.pointerPlus(0), 5, paramSEXP);
    paramSEXP = viewport__.viewportClipRect(sEXP4);
    baseEngine__.GESetClip(Rinternals2.REAL(paramSEXP).getDouble(), Rinternals2.REAL(paramSEXP).getDouble(8), Rinternals2.REAL(paramSEXP).getDouble(16), Rinternals2.REAL(paramSEXP).getDouble(24), ptr.pointerPlus(0));
    state__.setGridStateElement(ptr.pointerPlus(0), 7, sEXP4);
    Rinternals.SET_VECTOR_ELT(sEXP3, 26, Rinternals.R_NilValue);
    return Rinternals.R_NilValue;
  }
  
  public static SEXP L_upviewport(SEXP paramSEXP) {
    double[] arrayOfDouble1 = new double[1];
    double[] arrayOfDouble2 = new double[1];
    BytePtr.of(0);
    arrayOfDouble1[0] = 0.0D;
    arrayOfDouble2[0] = 0.0D;
    Ptr ptr = getDevice();
    SEXP sEXP = Rinternals.VECTOR_ELT(state__.gridStateElement(ptr.pointerPlus(0), 7), 26);
    if (Rinternals.Rf_isNull(sEXP))
      Error.Rf_error(GetText.dgettext(new BytePtr("grid\000".getBytes(), 0), new BytePtr("cannot pop the top-level viewport ('grid' and 'graphics' output mixed?)\000".getBytes(), 0)), new Object[0]); 
    for (byte b = 1; Rinternals2.INTEGER(paramSEXP).getInt() > b; b++) {
      sEXP = Rinternals.VECTOR_ELT(sEXP, 26);
      if (Rinternals.Rf_isNull(sEXP))
        Error.Rf_error(GetText.dgettext(new BytePtr("grid\000".getBytes(), 0), new BytePtr("cannot pop the top-level viewport ('grid' and 'graphics' output mixed?)\000".getBytes(), 0)), new Object[0]); 
    } 
    getDeviceSize(ptr.pointerPlus(0), (Ptr)new DoublePtr(arrayOfDouble2, 0), (Ptr)new DoublePtr(arrayOfDouble1, 0));
    if (deviceChanged(arrayOfDouble2[0], arrayOfDouble1[0], sEXP) != 0)
      viewport__.calcViewportTransform(sEXP, viewport__.viewportParent(sEXP), 1, ptr.pointerPlus(0)); 
    paramSEXP = viewport__.viewportgpar(sEXP);
    state__.setGridStateElement(ptr.pointerPlus(0), 5, paramSEXP);
    paramSEXP = viewport__.viewportClipRect(sEXP);
    baseEngine__.GESetClip(Rinternals2.REAL(paramSEXP).getDouble(), Rinternals2.REAL(paramSEXP).getDouble(8), Rinternals2.REAL(paramSEXP).getDouble(16), Rinternals2.REAL(paramSEXP).getDouble(24), ptr.pointerPlus(0));
    state__.setGridStateElement(ptr.pointerPlus(0), 7, sEXP);
    return Rinternals.R_NilValue;
  }
  
  public static SEXP L_xspline(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4, SEXP paramSEXP5, SEXP paramSEXP6, SEXP paramSEXP7) {
    gridXspline(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4, paramSEXP5, paramSEXP6, paramSEXP7, 0.0D, 1, 0);
    return Rinternals.R_NilValue;
  }
  
  public static SEXP L_xsplineBounds(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4, SEXP paramSEXP5, SEXP paramSEXP6, SEXP paramSEXP7, SEXP paramSEXP8) {
    return gridXspline(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4, paramSEXP5, paramSEXP6, paramSEXP7, Rinternals2.REAL(paramSEXP8).getDouble(), 0, 0);
  }
  
  public static SEXP L_xsplinePoints(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4, SEXP paramSEXP5, SEXP paramSEXP6, SEXP paramSEXP7, SEXP paramSEXP8) {
    return gridXspline(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4, paramSEXP5, paramSEXP6, paramSEXP7, Rinternals2.REAL(paramSEXP8).getDouble(), 0, 1);
  }
  
  public static void arrows(Ptr paramPtr1, Ptr paramPtr2, int paramInt1, SEXP paramSEXP, int paramInt2, int paramInt3, int paramInt4, Ptr paramPtr3, double paramDouble1, double paramDouble2, Ptr paramPtr4, Ptr paramPtr5) {
    double[] arrayOfDouble1 = new double[3];
    double[] arrayOfDouble2 = new double[3];
    SEXP sEXP = Rinternals.VECTOR_ELT(paramSEXP, 2);
    int i = Rinternals.LENGTH(sEXP);
    if (paramInt1 <= 1)
      Error.Rf_error(GetText.dgettext(new BytePtr("grid\000".getBytes(), 0), new BytePtr("require at least two points to draw arrow\000".getBytes(), 0)), new Object[0]); 
    boolean bool1 = true;
    boolean bool2 = true;
    switch (Rinternals2.INTEGER(sEXP).getInt(0 + paramInt2 % i * 4)) {
      case 2:
        bool1 = false;
        break;
      case 1:
        bool2 = false;
        break;
    } 
    if (bool1 && paramInt3 != 0) {
      SEXP sEXP2 = Rinternals.VECTOR_ELT(paramSEXP, 1);
      SEXP sEXP1 = Rinternals.VECTOR_ELT(paramSEXP, 0);
      double d3 = baseEngine__.GEfromDeviceY(paramPtr2.getDouble(8), 2, paramPtr5);
      double d2 = baseEngine__.GEfromDeviceX(paramPtr1.getDouble(8), 2, paramPtr5);
      double d1 = baseEngine__.GEfromDeviceY(paramPtr2.getDouble(), 2, paramPtr5);
      calcArrow(baseEngine__.GEfromDeviceX(paramPtr1.getDouble(), 2, paramPtr5), d1, d2, d3, sEXP1, sEXP2, paramInt2, paramPtr3.copyOf(32), paramDouble1, paramDouble2, (Ptr)new DoublePtr(arrayOfDouble2, 0), (Ptr)new DoublePtr(arrayOfDouble1, 0), paramPtr4, paramPtr5);
      sEXP1 = Rinternals.VECTOR_ELT(paramSEXP, 3);
      drawArrow((Ptr)new DoublePtr(arrayOfDouble2, 0), (Ptr)new DoublePtr(arrayOfDouble1, 0), sEXP1, paramInt2, paramPtr4, paramPtr5);
    } 
    if (bool2 && paramInt4 != 0) {
      SEXP sEXP3 = Rinternals.VECTOR_ELT(paramSEXP, 1);
      SEXP sEXP2 = Rinternals.VECTOR_ELT(paramSEXP, 0);
      double d3 = baseEngine__.GEfromDeviceY(paramPtr2.getDouble((paramInt1 + -2) * 8), 2, paramPtr5);
      double d2 = baseEngine__.GEfromDeviceX(paramPtr1.getDouble((paramInt1 + -2) * 8), 2, paramPtr5);
      double d1 = baseEngine__.GEfromDeviceY(paramPtr2.getDouble((paramInt1 + -1) * 8), 2, paramPtr5);
      calcArrow(baseEngine__.GEfromDeviceX(paramPtr1.getDouble((paramInt1 + -1) * 8), 2, paramPtr5), d1, d2, d3, sEXP2, sEXP3, paramInt2, paramPtr3.copyOf(32), paramDouble1, paramDouble2, (Ptr)new DoublePtr(arrayOfDouble2, 0), (Ptr)new DoublePtr(arrayOfDouble1, 0), paramPtr4, paramPtr5);
      SEXP sEXP1 = Rinternals.VECTOR_ELT(paramSEXP, 3);
      drawArrow((Ptr)new DoublePtr(arrayOfDouble2, 0), (Ptr)new DoublePtr(arrayOfDouble1, 0), sEXP1, paramInt2, paramPtr4, paramPtr5);
    } 
  }
  
  public static void calcArrow(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, SEXP paramSEXP1, SEXP paramSEXP2, int paramInt, Ptr paramPtr1, double paramDouble5, double paramDouble6, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5) {
    int i = Rinternals.LENGTH(paramSEXP2);
    double d = unit__.transformWidthtoINCHES(paramSEXP2, paramInt % i, paramPtr1.copyOf(32), paramPtr4, paramDouble5, paramDouble6, paramPtr5);
    paramDouble5 = unit__.transformHeighttoINCHES(paramSEXP2, paramInt % i, paramPtr1.copyOf(32), paramPtr4, paramDouble5, paramDouble6, paramPtr5);
    paramDouble6 = Rmath.Rf_fmin2(d, paramDouble5);
    i = 0 + paramInt % Rinternals.LENGTH(paramSEXP1) * 8;
    paramDouble5 = Rinternals2.REAL(paramSEXP1).getDouble(i) * 0.017453292519943295D;
    paramDouble3 = Mathlib.atan2(paramDouble4 - paramDouble2, paramDouble3 - paramDouble1);
    paramPtr2.setDouble(baseEngine__.GEtoDeviceX(Mathlib.cos(paramDouble3 + paramDouble5) * paramDouble6 + paramDouble1, 2, paramPtr5));
    paramPtr3.setDouble(baseEngine__.GEtoDeviceY(Mathlib.sin(paramDouble3 + paramDouble5) * paramDouble6 + paramDouble2, 2, paramPtr5));
    paramPtr2.setDouble(8, baseEngine__.GEtoDeviceX(paramDouble1, 2, paramPtr5));
    paramPtr3.setDouble(8, baseEngine__.GEtoDeviceY(paramDouble2, 2, paramPtr5));
    paramPtr2.setDouble(16, baseEngine__.GEtoDeviceX(Mathlib.cos(paramDouble3 - paramDouble5) * paramDouble6 + paramDouble1, 2, paramPtr5));
    paramPtr3.setDouble(16, baseEngine__.GEtoDeviceY(Mathlib.sin(paramDouble3 - paramDouble5) * paramDouble6 + paramDouble2, 2, paramPtr5));
  }
  
  public static int childExists(SEXP paramSEXP1, SEXP paramSEXP2) {
    Rinternals.Rf_protect(Rinternals.Rf_lang3(Rinternals.Rf_install(new BytePtr("child.exists\000".getBytes(), 0)), paramSEXP1, paramSEXP2));
    Rinternals.Rf_protect(Rinternals.Rf_eval(Rinternals.Rf_lang3(Rinternals.Rf_install(new BytePtr("child.exists\000".getBytes(), 0)), paramSEXP1, paramSEXP2), R_gridEvalEnv));
    return Rinternals.LOGICAL(Rinternals.Rf_eval(Rinternals.Rf_lang3(Rinternals.Rf_install(new BytePtr("child.exists\000".getBytes(), 0)), paramSEXP1, paramSEXP2), R_gridEvalEnv)).getInt();
  }
  
  public static SEXP childList(SEXP paramSEXP) {
    Rinternals.Rf_protect(Rinternals.Rf_lang2(Rinternals.Rf_install(new BytePtr("child.list\000".getBytes(), 0)), paramSEXP));
    Rinternals.Rf_protect(Rinternals.Rf_eval(Rinternals.Rf_lang2(Rinternals.Rf_install(new BytePtr("child.list\000".getBytes(), 0)), paramSEXP), R_gridEvalEnv));
    return Rinternals.Rf_eval(Rinternals.Rf_lang2(Rinternals.Rf_install(new BytePtr("child.list\000".getBytes(), 0)), paramSEXP), R_gridEvalEnv);
  }
  
  public static void circleEdge(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, Ptr paramPtr1, Ptr paramPtr2) {
    paramDouble1 = Mathlib.cos(paramDouble4 / 180.0D * Math.PI) * paramDouble3 + paramDouble1;
    paramPtr1.setDouble(paramDouble1);
    paramPtr2.setDouble(Mathlib.sin(paramDouble4 / 180.0D * Math.PI) * paramDouble3 + paramDouble2);
  }
  
  public static int deviceChanged(double paramDouble1, double paramDouble2, SEXP paramSEXP) {
    boolean bool = false;
    SEXP sEXP2 = Rinternals.VECTOR_ELT(paramSEXP, 28);
    Rinternals.Rf_protect(sEXP2);
    SEXP sEXP1 = Rinternals.VECTOR_ELT(paramSEXP, 29);
    Rinternals.Rf_protect(sEXP1);
    if (Math.abs(Rinternals2.REAL(sEXP2).getDouble() - paramDouble1) > 1.0E-6D) {
      bool = true;
      Rinternals2.REAL(sEXP2).setDouble(0, paramDouble1);
      Rinternals.SET_VECTOR_ELT(paramSEXP, 28, sEXP2);
    } 
    if (Math.abs(Rinternals2.REAL(sEXP1).getDouble() - paramDouble2) > 1.0E-6D) {
      bool = true;
      Rinternals2.REAL(sEXP1).setDouble(0, paramDouble2);
      Rinternals.SET_VECTOR_ELT(paramSEXP, 29, sEXP1);
    } 
    return bool;
  }
  
  public static void dirtyGridDevice(Ptr paramPtr) {
    MixedPtr mixedPtr = MixedPtr.malloc(276);
    if (Rinternals.LOGICAL(state__.gridStateElement(paramPtr, 9)).getInt() == 0) {
      SEXP sEXP = Rinternals.Rf_allocVector(10, 1);
      Rinternals.Rf_protect(sEXP);
      Rinternals.LOGICAL(sEXP).setInt(0, 1);
      Rinternals.SET_VECTOR_ELT((SEXP)paramPtr.getPointer(28 + matrix__.gridRegisterIndex * 4).getPointer().getArray(), 9, sEXP);
      if (baseEngine__.GEdeviceDirty(paramPtr) == 0) {
        gpar__.gcontextFromgpar(state__.gridStateElement(paramPtr, 5), 0, (Ptr)mixedPtr, paramPtr);
        baseEngine__.GENewPage((Ptr)mixedPtr, paramPtr);
        baseEngine__.GEdirtyDevice(paramPtr);
      } 
      viewport__.initVP(paramPtr);
      state__.initDL(paramPtr);
    } 
  }
  
  public static SEXP doSetViewport(SEXP paramSEXP, int paramInt1, int paramInt2, Ptr paramPtr) {
    // Byte code:
    //   0: bipush #9
    //   2: newarray double
    //   4: astore #4
    //   6: sipush #276
    //   9: invokestatic malloc : (I)Lorg/renjin/gcc/runtime/MixedPtr;
    //   12: astore #5
    //   14: bipush #32
    //   16: invokestatic malloc : (I)Lorg/renjin/gcc/runtime/MixedPtr;
    //   19: astore #6
    //   21: iconst_1
    //   22: newarray double
    //   24: astore #10
    //   26: iconst_1
    //   27: newarray double
    //   29: astore #11
    //   31: iconst_1
    //   32: newarray double
    //   34: astore #12
    //   36: iconst_1
    //   37: newarray double
    //   39: astore #13
    //   41: iconst_1
    //   42: newarray double
    //   44: astore #14
    //   46: iconst_1
    //   47: newarray double
    //   49: astore #15
    //   51: aload #10
    //   53: iconst_0
    //   54: dconst_0
    //   55: dastore
    //   56: aload #11
    //   58: iconst_0
    //   59: dconst_0
    //   60: dastore
    //   61: aload #12
    //   63: iconst_0
    //   64: dconst_0
    //   65: dastore
    //   66: aload #13
    //   68: iconst_0
    //   69: dconst_0
    //   70: dastore
    //   71: aload #14
    //   73: iconst_0
    //   74: dconst_0
    //   75: dastore
    //   76: aload #15
    //   78: iconst_0
    //   79: dconst_0
    //   80: dastore
    //   81: aload_3
    //   82: new org/renjin/gcc/runtime/DoublePtr
    //   85: dup
    //   86: aload #15
    //   88: iconst_0
    //   89: invokespecial <init> : ([DI)V
    //   92: checkcast org/renjin/gcc/runtime/Ptr
    //   95: new org/renjin/gcc/runtime/DoublePtr
    //   98: dup
    //   99: aload #14
    //   101: iconst_0
    //   102: invokespecial <init> : ([DI)V
    //   105: checkcast org/renjin/gcc/runtime/Ptr
    //   108: invokestatic getDeviceSize : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)V
    //   111: iload_1
    //   112: ifeq -> 118
    //   115: goto -> 170
    //   118: iload_2
    //   119: ifne -> 125
    //   122: goto -> 170
    //   125: aload_0
    //   126: bipush #26
    //   128: aload_3
    //   129: bipush #7
    //   131: invokestatic gridStateElement : (Lorg/renjin/gcc/runtime/Ptr;I)Lorg/renjin/sexp/SEXP;
    //   134: astore #9
    //   136: aload #9
    //   138: invokestatic SET_VECTOR_ELT : (Lorg/renjin/sexp/SEXP;ILorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   141: pop
    //   142: aload #9
    //   144: bipush #27
    //   146: invokestatic VECTOR_ELT : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
    //   149: astore #9
    //   151: aload_0
    //   152: bipush #16
    //   154: invokestatic VECTOR_ELT : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
    //   157: iconst_0
    //   158: invokestatic STRING_ELT : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
    //   161: invokestatic Rf_installChar : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   164: aload_0
    //   165: aload #9
    //   167: invokestatic Rf_defineVar : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)V
    //   170: iload_1
    //   171: ifeq -> 177
    //   174: goto -> 208
    //   177: aload_0
    //   178: invokestatic viewportParent : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   181: astore #9
    //   183: aload #15
    //   185: iconst_0
    //   186: daload
    //   187: aload #14
    //   189: iconst_0
    //   190: daload
    //   191: aload #9
    //   193: invokestatic deviceChanged : (DDLorg/renjin/sexp/SEXP;)I
    //   196: ifeq -> 202
    //   199: goto -> 208
    //   202: iconst_1
    //   203: istore #9
    //   205: goto -> 211
    //   208: iconst_0
    //   209: istore #9
    //   211: aload_0
    //   212: aload_0
    //   213: invokestatic viewportParent : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   216: iload #9
    //   218: aload_3
    //   219: invokestatic calcViewportTransform : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;ILorg/renjin/gcc/runtime/Ptr;)V
    //   222: aload_0
    //   223: invokestatic viewportClip : (Lorg/renjin/sexp/SEXP;)I
    //   226: getstatic org/renjin/gnur/api/Arith.R_NaInt : I
    //   229: if_icmpeq -> 235
    //   232: goto -> 342
    //   235: aload #13
    //   237: iconst_0
    //   238: aload #15
    //   240: iconst_0
    //   241: daload
    //   242: ldc2_w -0.5
    //   245: dmul
    //   246: ldc2_w 2.54
    //   249: ddiv
    //   250: iconst_2
    //   251: aload_3
    //   252: invokestatic GEtoDeviceX : (DILorg/renjin/gcc/runtime/Ptr;)D
    //   255: dastore
    //   256: aload #12
    //   258: iconst_0
    //   259: aload #14
    //   261: iconst_0
    //   262: daload
    //   263: ldc2_w -0.5
    //   266: dmul
    //   267: ldc2_w 2.54
    //   270: ddiv
    //   271: iconst_2
    //   272: aload_3
    //   273: invokestatic GEtoDeviceY : (DILorg/renjin/gcc/runtime/Ptr;)D
    //   276: dastore
    //   277: aload #11
    //   279: iconst_0
    //   280: aload #15
    //   282: iconst_0
    //   283: daload
    //   284: ldc2_w 1.5
    //   287: dmul
    //   288: ldc2_w 2.54
    //   291: ddiv
    //   292: iconst_2
    //   293: aload_3
    //   294: invokestatic GEtoDeviceX : (DILorg/renjin/gcc/runtime/Ptr;)D
    //   297: dastore
    //   298: aload #10
    //   300: iconst_0
    //   301: aload #14
    //   303: iconst_0
    //   304: daload
    //   305: ldc2_w 1.5
    //   308: dmul
    //   309: ldc2_w 2.54
    //   312: ddiv
    //   313: iconst_2
    //   314: aload_3
    //   315: invokestatic GEtoDeviceY : (DILorg/renjin/gcc/runtime/Ptr;)D
    //   318: dastore
    //   319: aload #13
    //   321: iconst_0
    //   322: daload
    //   323: aload #12
    //   325: iconst_0
    //   326: daload
    //   327: aload #11
    //   329: iconst_0
    //   330: daload
    //   331: aload #10
    //   333: iconst_0
    //   334: daload
    //   335: aload_3
    //   336: invokestatic GESetClip : (DDDDLorg/renjin/gcc/runtime/Ptr;)V
    //   339: goto -> 1038
    //   342: aload_0
    //   343: invokestatic viewportClip : (Lorg/renjin/sexp/SEXP;)I
    //   346: ifne -> 352
    //   349: goto -> 940
    //   352: aload_0
    //   353: invokestatic viewportRotation : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   356: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
    //   359: invokeinterface getDouble : ()D
    //   364: dstore #7
    //   366: dload #7
    //   368: dconst_0
    //   369: dcmpl
    //   370: ifne -> 376
    //   373: goto -> 526
    //   376: dload #7
    //   378: ldc2_w 90.0
    //   381: dcmpl
    //   382: ifne -> 388
    //   385: goto -> 526
    //   388: dload #7
    //   390: ldc2_w 270.0
    //   393: dcmpl
    //   394: ifne -> 400
    //   397: goto -> 526
    //   400: dload #7
    //   402: ldc2_w 360.0
    //   405: dcmpl
    //   406: ifne -> 412
    //   409: goto -> 526
    //   412: new org/renjin/gcc/runtime/BytePtr
    //   415: dup
    //   416: ldc 'grid '
    //   418: invokevirtual getBytes : ()[B
    //   421: iconst_0
    //   422: invokespecial <init> : ([BI)V
    //   425: new org/renjin/gcc/runtime/BytePtr
    //   428: dup
    //   429: ldc_w 'cannot clip to rotated viewport '
    //   432: invokevirtual getBytes : ()[B
    //   435: iconst_0
    //   436: invokespecial <init> : ([BI)V
    //   439: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
    //   442: checkcast org/renjin/gcc/runtime/BytePtr
    //   445: iconst_0
    //   446: anewarray java/lang/Object
    //   449: invokestatic Rf_warning : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
    //   452: aload_0
    //   453: invokestatic viewportParent : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   456: invokestatic viewportClipRect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   459: astore_1
    //   460: aload_1
    //   461: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   464: pop
    //   465: aload #13
    //   467: iconst_0
    //   468: aload_1
    //   469: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
    //   472: invokeinterface getDouble : ()D
    //   477: dastore
    //   478: aload #12
    //   480: iconst_0
    //   481: aload_1
    //   482: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
    //   485: bipush #8
    //   487: invokeinterface getDouble : (I)D
    //   492: dastore
    //   493: aload #11
    //   495: iconst_0
    //   496: aload_1
    //   497: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
    //   500: bipush #16
    //   502: invokeinterface getDouble : (I)D
    //   507: dastore
    //   508: aload #10
    //   510: iconst_0
    //   511: aload_1
    //   512: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
    //   515: bipush #24
    //   517: invokeinterface getDouble : (I)D
    //   522: dastore
    //   523: goto -> 1038
    //   526: aload_0
    //   527: invokestatic viewportWidthCM : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   530: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
    //   533: invokeinterface getDouble : ()D
    //   538: dstore #7
    //   540: aload_0
    //   541: invokestatic viewportHeightCM : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   544: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
    //   547: invokeinterface getDouble : ()D
    //   552: dstore #16
    //   554: iconst_0
    //   555: istore_2
    //   556: goto -> 609
    //   559: iconst_0
    //   560: istore #9
    //   562: goto -> 600
    //   565: aload #4
    //   567: iload_2
    //   568: iconst_3
    //   569: imul
    //   570: iload #9
    //   572: iadd
    //   573: aload_0
    //   574: invokestatic viewportTransform : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   577: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
    //   580: iconst_0
    //   581: iload #9
    //   583: iconst_3
    //   584: imul
    //   585: iload_2
    //   586: iadd
    //   587: bipush #8
    //   589: imul
    //   590: iadd
    //   591: invokeinterface getDouble : (I)D
    //   596: dastore
    //   597: iinc #9, 1
    //   600: iload #9
    //   602: iconst_2
    //   603: if_icmple -> 565
    //   606: iinc #2, 1
    //   609: iload_2
    //   610: iconst_2
    //   611: if_icmple -> 559
    //   614: iload_1
    //   615: ifeq -> 621
    //   618: goto -> 672
    //   621: dconst_0
    //   622: iconst_0
    //   623: invokestatic unit : (DI)Lorg/renjin/sexp/SEXP;
    //   626: astore_1
    //   627: aload_1
    //   628: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   631: pop
    //   632: dconst_0
    //   633: iconst_0
    //   634: invokestatic unit : (DI)Lorg/renjin/sexp/SEXP;
    //   637: astore_2
    //   638: aload_2
    //   639: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   642: pop
    //   643: dconst_1
    //   644: iconst_0
    //   645: invokestatic unit : (DI)Lorg/renjin/sexp/SEXP;
    //   648: astore #9
    //   650: aload #9
    //   652: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   655: pop
    //   656: dconst_1
    //   657: iconst_0
    //   658: invokestatic unit : (DI)Lorg/renjin/sexp/SEXP;
    //   661: astore #18
    //   663: aload #18
    //   665: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   668: pop
    //   669: goto -> 728
    //   672: ldc2_w -0.5
    //   675: iconst_0
    //   676: invokestatic unit : (DI)Lorg/renjin/sexp/SEXP;
    //   679: astore_1
    //   680: aload_1
    //   681: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   684: pop
    //   685: ldc2_w -0.5
    //   688: iconst_0
    //   689: invokestatic unit : (DI)Lorg/renjin/sexp/SEXP;
    //   692: astore_2
    //   693: aload_2
    //   694: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   697: pop
    //   698: ldc2_w 1.5
    //   701: iconst_0
    //   702: invokestatic unit : (DI)Lorg/renjin/sexp/SEXP;
    //   705: astore #9
    //   707: aload #9
    //   709: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   712: pop
    //   713: ldc2_w 1.5
    //   716: iconst_0
    //   717: invokestatic unit : (DI)Lorg/renjin/sexp/SEXP;
    //   720: astore #18
    //   722: aload #18
    //   724: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   727: pop
    //   728: aload_0
    //   729: aload #6
    //   731: invokestatic getViewportContext : (Lorg/renjin/sexp/SEXP;Lorg/renjin/gcc/runtime/Ptr;)V
    //   734: aload_0
    //   735: aload #5
    //   737: aload_3
    //   738: invokestatic gcontextFromViewport : (Lorg/renjin/sexp/SEXP;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)V
    //   741: aload_1
    //   742: aload_2
    //   743: iconst_0
    //   744: aload #6
    //   746: bipush #32
    //   748: invokeinterface copyOf : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   753: aload #5
    //   755: dload #7
    //   757: dload #16
    //   759: aload_3
    //   760: new org/renjin/gcc/runtime/DoublePtr
    //   763: dup
    //   764: aload #4
    //   766: iconst_0
    //   767: invokespecial <init> : ([DI)V
    //   770: checkcast org/renjin/gcc/runtime/Ptr
    //   773: new org/renjin/gcc/runtime/DoublePtr
    //   776: dup
    //   777: aload #13
    //   779: iconst_0
    //   780: invokespecial <init> : ([DI)V
    //   783: checkcast org/renjin/gcc/runtime/Ptr
    //   786: new org/renjin/gcc/runtime/DoublePtr
    //   789: dup
    //   790: aload #12
    //   792: iconst_0
    //   793: invokespecial <init> : ([DI)V
    //   796: checkcast org/renjin/gcc/runtime/Ptr
    //   799: invokestatic transformLocn : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;ILorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;DDLorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)V
    //   802: aload #9
    //   804: aload #18
    //   806: iconst_0
    //   807: aload #6
    //   809: bipush #32
    //   811: invokeinterface copyOf : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   816: aload #5
    //   818: dload #7
    //   820: dload #16
    //   822: aload_3
    //   823: new org/renjin/gcc/runtime/DoublePtr
    //   826: dup
    //   827: aload #4
    //   829: iconst_0
    //   830: invokespecial <init> : ([DI)V
    //   833: checkcast org/renjin/gcc/runtime/Ptr
    //   836: new org/renjin/gcc/runtime/DoublePtr
    //   839: dup
    //   840: aload #11
    //   842: iconst_0
    //   843: invokespecial <init> : ([DI)V
    //   846: checkcast org/renjin/gcc/runtime/Ptr
    //   849: new org/renjin/gcc/runtime/DoublePtr
    //   852: dup
    //   853: aload #10
    //   855: iconst_0
    //   856: invokespecial <init> : ([DI)V
    //   859: checkcast org/renjin/gcc/runtime/Ptr
    //   862: invokestatic transformLocn : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;ILorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;DDLorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)V
    //   865: aload #13
    //   867: iconst_0
    //   868: aload #13
    //   870: iconst_0
    //   871: daload
    //   872: iconst_2
    //   873: aload_3
    //   874: invokestatic GEtoDeviceX : (DILorg/renjin/gcc/runtime/Ptr;)D
    //   877: dastore
    //   878: aload #12
    //   880: iconst_0
    //   881: aload #12
    //   883: iconst_0
    //   884: daload
    //   885: iconst_2
    //   886: aload_3
    //   887: invokestatic GEtoDeviceY : (DILorg/renjin/gcc/runtime/Ptr;)D
    //   890: dastore
    //   891: aload #11
    //   893: iconst_0
    //   894: aload #11
    //   896: iconst_0
    //   897: daload
    //   898: iconst_2
    //   899: aload_3
    //   900: invokestatic GEtoDeviceX : (DILorg/renjin/gcc/runtime/Ptr;)D
    //   903: dastore
    //   904: aload #10
    //   906: iconst_0
    //   907: aload #10
    //   909: iconst_0
    //   910: daload
    //   911: iconst_2
    //   912: aload_3
    //   913: invokestatic GEtoDeviceY : (DILorg/renjin/gcc/runtime/Ptr;)D
    //   916: dastore
    //   917: aload #13
    //   919: iconst_0
    //   920: daload
    //   921: aload #12
    //   923: iconst_0
    //   924: daload
    //   925: aload #11
    //   927: iconst_0
    //   928: daload
    //   929: aload #10
    //   931: iconst_0
    //   932: daload
    //   933: aload_3
    //   934: invokestatic GESetClip : (DDDDLorg/renjin/gcc/runtime/Ptr;)V
    //   937: goto -> 1038
    //   940: aload_0
    //   941: invokestatic viewportParent : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   944: invokestatic viewportClipRect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   947: astore_1
    //   948: aload_1
    //   949: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   952: pop
    //   953: aload #13
    //   955: iconst_0
    //   956: aload_1
    //   957: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
    //   960: invokeinterface getDouble : ()D
    //   965: dastore
    //   966: aload #12
    //   968: iconst_0
    //   969: aload_1
    //   970: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
    //   973: bipush #8
    //   975: invokeinterface getDouble : (I)D
    //   980: dastore
    //   981: aload #11
    //   983: iconst_0
    //   984: aload_1
    //   985: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
    //   988: bipush #16
    //   990: invokeinterface getDouble : (I)D
    //   995: dastore
    //   996: aload #10
    //   998: iconst_0
    //   999: aload_1
    //   1000: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
    //   1003: bipush #24
    //   1005: invokeinterface getDouble : (I)D
    //   1010: dastore
    //   1011: iload_2
    //   1012: ifeq -> 1018
    //   1015: goto -> 1038
    //   1018: aload #13
    //   1020: iconst_0
    //   1021: daload
    //   1022: aload #12
    //   1024: iconst_0
    //   1025: daload
    //   1026: aload #11
    //   1028: iconst_0
    //   1029: daload
    //   1030: aload #10
    //   1032: iconst_0
    //   1033: daload
    //   1034: aload_3
    //   1035: invokestatic GESetClip : (DDDDLorg/renjin/gcc/runtime/Ptr;)V
    //   1038: bipush #14
    //   1040: iconst_4
    //   1041: invokestatic Rf_allocVector : (II)Lorg/renjin/sexp/SEXP;
    //   1044: astore_1
    //   1045: aload_1
    //   1046: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1049: pop
    //   1050: aload_1
    //   1051: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
    //   1054: iconst_0
    //   1055: aload #13
    //   1057: iconst_0
    //   1058: daload
    //   1059: invokeinterface setDouble : (ID)V
    //   1064: aload_1
    //   1065: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
    //   1068: bipush #8
    //   1070: aload #12
    //   1072: iconst_0
    //   1073: daload
    //   1074: invokeinterface setDouble : (ID)V
    //   1079: aload_1
    //   1080: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
    //   1083: bipush #16
    //   1085: aload #11
    //   1087: iconst_0
    //   1088: daload
    //   1089: invokeinterface setDouble : (ID)V
    //   1094: aload_1
    //   1095: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
    //   1098: bipush #24
    //   1100: aload #10
    //   1102: iconst_0
    //   1103: daload
    //   1104: invokeinterface setDouble : (ID)V
    //   1109: aload_0
    //   1110: bipush #25
    //   1112: aload_1
    //   1113: invokestatic SET_VECTOR_ELT : (Lorg/renjin/sexp/SEXP;ILorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1116: pop
    //   1117: bipush #14
    //   1119: iconst_1
    //   1120: invokestatic Rf_allocVector : (II)Lorg/renjin/sexp/SEXP;
    //   1123: astore_1
    //   1124: aload_1
    //   1125: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1128: pop
    //   1129: aload_1
    //   1130: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
    //   1133: iconst_0
    //   1134: aload #15
    //   1136: iconst_0
    //   1137: daload
    //   1138: invokeinterface setDouble : (ID)V
    //   1143: aload_0
    //   1144: bipush #28
    //   1146: aload_1
    //   1147: invokestatic SET_VECTOR_ELT : (Lorg/renjin/sexp/SEXP;ILorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1150: pop
    //   1151: bipush #14
    //   1153: iconst_1
    //   1154: invokestatic Rf_allocVector : (II)Lorg/renjin/sexp/SEXP;
    //   1157: astore_1
    //   1158: aload_1
    //   1159: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1162: pop
    //   1163: aload_1
    //   1164: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
    //   1167: iconst_0
    //   1168: aload #14
    //   1170: iconst_0
    //   1171: daload
    //   1172: invokeinterface setDouble : (ID)V
    //   1177: aload_0
    //   1178: bipush #29
    //   1180: aload_1
    //   1181: invokestatic SET_VECTOR_ELT : (Lorg/renjin/sexp/SEXP;ILorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1184: pop
    //   1185: aload_0
    //   1186: areturn
  }
  
  public static void drawArrow(Ptr paramPtr1, Ptr paramPtr2, SEXP paramSEXP, int paramInt, Ptr paramPtr3, Ptr paramPtr4) {
    paramInt = 0 + paramInt % Rinternals.LENGTH(paramSEXP) * 4;
    switch (Rinternals2.INTEGER(paramSEXP).getInt(paramInt)) {
      case 1:
        baseEngine__.GEPolyline(3, paramPtr1, paramPtr2, paramPtr3, paramPtr4);
        break;
      case 2:
        baseEngine__.GEPolygon(3, paramPtr1, paramPtr2, paramPtr3, paramPtr4);
        break;
    } 
  }
  
  public static SEXP findInChildren(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, int paramInt) {
    SEXP sEXP1 = (SEXP)BytePtr.of(0).getArray();
    sEXP1 = childList(paramSEXP3);
    int i = Rinternals.LENGTH(sEXP1);
    byte b = 0;
    boolean bool = false;
    SEXP sEXP2 = Rinternals.R_NilValue;
    Rinternals.Rf_protect(sEXP1);
    Rinternals.Rf_protect(sEXP2);
    while (b < i && !bool) {
      sEXP2 = findViewport(paramSEXP1, paramSEXP2, Rinternals.Rf_protect(Rinternals.Rf_findVar(Rinternals.Rf_installChar(Rinternals.STRING_ELT(sEXP1, b)), paramSEXP3)), paramInt);
      if (Rinternals2.INTEGER(Rinternals.VECTOR_ELT(sEXP2, 0)).getInt() <= 0) {
        bool = false;
      } else {
        bool = true;
      } 
      bool = bool;
      b++;
    } 
    if (!bool) {
      paramSEXP2 = Rinternals.Rf_allocVector(19, 2);
      Rinternals.Rf_protect(paramSEXP2);
      paramSEXP1 = Rinternals.Rf_allocVector(13, 1);
      Rinternals.Rf_protect(paramSEXP1);
      Rinternals2.INTEGER(paramSEXP1).setInt(0, 0);
      Rinternals.SET_VECTOR_ELT(paramSEXP2, 0, paramSEXP1);
      Rinternals.SET_VECTOR_ELT(paramSEXP2, 1, Rinternals.R_NilValue);
      sEXP2 = paramSEXP2;
    } 
    return sEXP2;
  }
  
  public static SEXP findViewport(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, int paramInt) {
    SEXP sEXP3 = Rinternals.Rf_allocVector(19, 2);
    Rinternals.Rf_protect(sEXP3);
    SEXP sEXP2 = Rinternals.Rf_allocVector(13, 1);
    Rinternals.Rf_protect(sEXP2);
    Rinternals2.INTEGER(sEXP2).setInt(0, 0);
    SEXP sEXP1 = Rinternals.Rf_allocVector(13, 1);
    Rinternals.Rf_protect(sEXP1);
    Rinternals2.INTEGER(sEXP1).setInt(0, paramInt);
    if (noChildren(viewport__.viewportChildren(paramSEXP3)) == 0) {
      if (childExists(paramSEXP1, viewport__.viewportChildren(paramSEXP3)) == 0) {
        if (Rinternals.LOGICAL(paramSEXP2).getInt() == 0)
          return findInChildren(paramSEXP1, paramSEXP2, viewport__.viewportChildren(paramSEXP3), paramInt + 1); 
        Rinternals.SET_VECTOR_ELT(sEXP3, 0, sEXP2);
        Rinternals.SET_VECTOR_ELT(sEXP3, 1, Rinternals.R_NilValue);
        return sEXP3;
      } 
      Rinternals.SET_VECTOR_ELT(sEXP3, 0, sEXP1);
      paramSEXP2 = viewport__.viewportChildren(paramSEXP3);
      Rinternals.SET_VECTOR_ELT(sEXP3, 1, Rinternals.Rf_findVar(Rinternals.Rf_installChar(Rinternals.STRING_ELT(paramSEXP1, 0)), paramSEXP2));
      return sEXP3;
    } 
    Rinternals.SET_VECTOR_ELT(sEXP3, 0, sEXP2);
    Rinternals.SET_VECTOR_ELT(sEXP3, 1, Rinternals.R_NilValue);
    return sEXP3;
  }
  
  public static SEXP findvppath(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4, SEXP paramSEXP5, int paramInt) {
    SEXP sEXP3 = Rinternals.Rf_allocVector(19, 2);
    Rinternals.Rf_protect(sEXP3);
    SEXP sEXP2 = Rinternals.Rf_allocVector(13, 1);
    Rinternals.Rf_protect(sEXP2);
    Rinternals2.INTEGER(sEXP2).setInt(0, 0);
    SEXP sEXP1 = Rinternals.Rf_allocVector(13, 1);
    Rinternals.Rf_protect(sEXP1);
    Rinternals2.INTEGER(sEXP1).setInt(0, paramInt);
    if (noChildren(viewport__.viewportChildren(paramSEXP5)) == 0) {
      if (childExists(paramSEXP2, viewport__.viewportChildren(paramSEXP5)) == 0 || pathMatch(paramSEXP1, paramSEXP4, paramSEXP3) == 0)
        return findvppathInChildren(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4, viewport__.viewportChildren(paramSEXP5), paramInt + 1); 
      Rinternals.SET_VECTOR_ELT(sEXP3, 0, sEXP1);
      paramSEXP1 = viewport__.viewportChildren(paramSEXP5);
      Rinternals.SET_VECTOR_ELT(sEXP3, 1, Rinternals.Rf_findVar(Rinternals.Rf_installChar(Rinternals.STRING_ELT(paramSEXP2, 0)), paramSEXP1));
      return sEXP3;
    } 
    Rinternals.SET_VECTOR_ELT(sEXP3, 0, sEXP2);
    Rinternals.SET_VECTOR_ELT(sEXP3, 1, Rinternals.R_NilValue);
    return sEXP3;
  }
  
  public static SEXP findvppathInChildren(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4, SEXP paramSEXP5, int paramInt) {
    SEXP sEXP2 = (SEXP)BytePtr.of(0).getArray();
    sEXP2 = childList(paramSEXP5);
    int i = Rinternals.LENGTH(sEXP2);
    byte b = 0;
    boolean bool = false;
    SEXP sEXP1 = Rinternals.R_NilValue;
    Rinternals.Rf_protect(sEXP2);
    Rinternals.Rf_protect(sEXP1);
    while (b < i && !bool) {
      sEXP1 = Rinternals.Rf_findVar(Rinternals.Rf_installChar(Rinternals.STRING_ELT(sEXP2, b)), paramSEXP5);
      Rinternals.Rf_protect(sEXP1);
      Rinternals.Rf_protect(growPath(paramSEXP4, Rinternals.VECTOR_ELT(sEXP1, 16)));
      sEXP1 = findvppath(paramSEXP1, paramSEXP2, paramSEXP3, growPath(paramSEXP4, Rinternals.VECTOR_ELT(sEXP1, 16)), sEXP1, paramInt);
      if (Rinternals2.INTEGER(Rinternals.VECTOR_ELT(sEXP1, 0)).getInt() <= 0) {
        bool = false;
      } else {
        bool = true;
      } 
      bool = bool;
      b++;
    } 
    if (!bool) {
      paramSEXP2 = Rinternals.Rf_allocVector(19, 2);
      Rinternals.Rf_protect(paramSEXP2);
      paramSEXP1 = Rinternals.Rf_allocVector(13, 1);
      Rinternals.Rf_protect(paramSEXP1);
      Rinternals2.INTEGER(paramSEXP1).setInt(0, 0);
      Rinternals.SET_VECTOR_ELT(paramSEXP2, 0, paramSEXP1);
      Rinternals.SET_VECTOR_ELT(paramSEXP2, 1, Rinternals.R_NilValue);
      sEXP1 = paramSEXP2;
    } 
    return sEXP1;
  }
  
  public static int getArrowN(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4, SEXP paramSEXP5, SEXP paramSEXP6, SEXP paramSEXP7, SEXP paramSEXP8) {
    byte b1;
    byte b2;
    byte b3;
    int i = 0;
    if (!Rinternals.Rf_isNull(paramSEXP5)) {
      b2 = unit__.unitLength(paramSEXP5);
    } else {
      b2 = 0;
    } 
    int j = unit__.unitLength(paramSEXP2);
    int m = unit__.unitLength(paramSEXP6);
    if (!Rinternals.Rf_isNull(paramSEXP3)) {
      b1 = unit__.unitLength(paramSEXP3);
    } else {
      b1 = 0;
    } 
    if (!Rinternals.Rf_isNull(paramSEXP7)) {
      b3 = unit__.unitLength(paramSEXP7);
    } else {
      b3 = 0;
    } 
    int k = unit__.unitLength(paramSEXP4);
    int n = unit__.unitLength(paramSEXP8);
    if (!b2)
      i = b2; 
    if (j > i)
      i = j; 
    if (m > i)
      i = m; 
    if (b1 > i)
      i = b1; 
    if (b3 > i)
      i = b3; 
    if (k > i)
      i = k; 
    if (n > i)
      i = n; 
    return i;
  }
  
  public static Ptr getDevice() {
    return baseDevices__.GEcurrentDevice();
  }
  
  public static void getDeviceSize(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3) {
    double[] arrayOfDouble1 = new double[1];
    double[] arrayOfDouble2 = new double[1];
    double[] arrayOfDouble3 = new double[1];
    double[] arrayOfDouble4 = new double[1];
    arrayOfDouble1[0] = 0.0D;
    arrayOfDouble2[0] = 0.0D;
    arrayOfDouble3[0] = 0.0D;
    arrayOfDouble4[0] = 0.0D;
    Ptr ptr = paramPtr1.getPointer();
    paramPtr1.getPointer().getPointer(264).toMethodHandle().invoke((Ptr)new DoublePtr(arrayOfDouble4, 0), (Ptr)new DoublePtr(arrayOfDouble3, 0), (Ptr)new DoublePtr(arrayOfDouble2, 0), (Ptr)new DoublePtr(arrayOfDouble1, 0), ptr);
    paramPtr2.setDouble(Math.abs(arrayOfDouble3[0] - arrayOfDouble4[0]) * paramPtr1.getPointer().getDouble(88) * 2.54D);
    paramPtr3.setDouble(Math.abs(arrayOfDouble1[0] - arrayOfDouble2[0]) * paramPtr1.getPointer().getDouble(96) * 2.54D);
  }
  
  public static void getViewportContext(SEXP paramSEXP, Ptr paramPtr) {
    viewport__.fillViewportContextFromViewport(paramSEXP, paramPtr);
  }
  
  public static void getViewportTransform(SEXP paramSEXP, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5) {
    double[] arrayOfDouble1 = new double[1];
    double[] arrayOfDouble2 = new double[1];
    arrayOfDouble1[0] = 0.0D;
    arrayOfDouble2[0] = 0.0D;
    getDeviceSize(paramPtr1, (Ptr)new DoublePtr(arrayOfDouble2, 0), (Ptr)new DoublePtr(arrayOfDouble1, 0));
    if (deviceChanged(arrayOfDouble2[0], arrayOfDouble1[0], paramSEXP) != 0)
      viewport__.calcViewportTransform(paramSEXP, viewport__.viewportParent(paramSEXP), 1, paramPtr1); 
    for (byte b = 0; b <= 2; b++) {
      for (byte b1 = 0; b1 <= 2; b1++)
        paramPtr4.setDouble(b * 24 + b1 * 8, Rinternals2.REAL(viewport__.viewportTransform(paramSEXP)).getDouble(0 + (b1 * 3 + b) * 8)); 
    } 
    paramPtr5.setDouble(Rinternals2.REAL(viewport__.viewportRotation(paramSEXP)).getDouble());
    paramPtr2.setDouble(Rinternals2.REAL(viewport__.viewportWidthCM(paramSEXP)).getDouble());
    paramPtr3.setDouble(Rinternals2.REAL(viewport__.viewportHeightCM(paramSEXP)).getDouble());
  }
  
  public static SEXP gridCircle(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, double paramDouble, int paramInt) {
    double[] arrayOfDouble1 = new double[1];
    double[] arrayOfDouble2 = new double[1];
    double[] arrayOfDouble3 = new double[9];
    MixedPtr mixedPtr1 = MixedPtr.malloc(276);
    MixedPtr mixedPtr2 = MixedPtr.malloc(32);
    double[] arrayOfDouble4 = new double[1];
    double[] arrayOfDouble5 = new double[1];
    double[] arrayOfDouble6 = new double[1];
    double[] arrayOfDouble7 = new double[1];
    double[] arrayOfDouble8 = new double[1];
    BytePtr.of(0);
    arrayOfDouble1[0] = 0.0D;
    arrayOfDouble2[0] = 0.0D;
    SEXP sEXP1 = (SEXP)BytePtr.of(0).getArray();
    sEXP1 = (SEXP)BytePtr.of(0).getArray();
    arrayOfDouble4[0] = 0.0D;
    arrayOfDouble5[0] = 0.0D;
    arrayOfDouble6[0] = 0.0D;
    arrayOfDouble7[0] = 0.0D;
    arrayOfDouble8[0] = 0.0D;
    double d1 = 0.0D;
    sEXP1 = Rinternals.R_NilValue;
    double d2 = Double.MAX_VALUE;
    double d3 = -1.7976931348623157E308D;
    double d4 = Double.MAX_VALUE;
    double d5 = -1.7976931348623157E308D;
    Ptr ptr = getDevice();
    SEXP sEXP2 = state__.gridStateElement(ptr.pointerPlus(0), 5);
    getViewportTransform(state__.gridStateElement(ptr.pointerPlus(0), 7), ptr.pointerPlus(0), (Ptr)new DoublePtr(arrayOfDouble6, 0), (Ptr)new DoublePtr(arrayOfDouble5, 0), (Ptr)new DoublePtr(arrayOfDouble3, 0), (Ptr)new DoublePtr(arrayOfDouble4, 0));
    getViewportContext(state__.gridStateElement(ptr.pointerPlus(0), 7), (Ptr)mixedPtr2);
    int i = unit__.unitLength(paramSEXP1);
    int j = unit__.unitLength(paramSEXP2);
    int k = unit__.unitLength(paramSEXP3);
    if (j > i)
      i = j; 
    if (k > i)
      i = k; 
    if (paramInt != 0)
      baseEngine__.GEMode(1, ptr.pointerPlus(0)); 
    j = 0;
    for (byte b = 0; b < i; b++) {
      gpar__.gcontextFromgpar(sEXP2, b, (Ptr)mixedPtr1, ptr.pointerPlus(0));
      if (paramInt == 0) {
        double d6 = arrayOfDouble5[0];
        d1 = arrayOfDouble6[0];
        arrayOfDouble8[0] = unit__.transformXtoINCHES(paramSEXP1, b, mixedPtr2.copyOf(32), (Ptr)mixedPtr1, d1, d6, ptr.pointerPlus(0));
        d6 = arrayOfDouble5[0];
        d1 = arrayOfDouble6[0];
        arrayOfDouble7[0] = unit__.transformYtoINCHES(paramSEXP2, b, mixedPtr2.copyOf(32), (Ptr)mixedPtr1, d1, d6, ptr.pointerPlus(0));
      } else {
        double d6 = arrayOfDouble5[0];
        d1 = arrayOfDouble6[0];
        unit__.transformLocn(paramSEXP1, paramSEXP2, b, mixedPtr2.copyOf(32), (Ptr)mixedPtr1, d1, d6, ptr.pointerPlus(0), (Ptr)new DoublePtr(arrayOfDouble3, 0), (Ptr)new DoublePtr(arrayOfDouble8, 0), (Ptr)new DoublePtr(arrayOfDouble7, 0));
      } 
      double d = arrayOfDouble5[0];
      d1 = arrayOfDouble6[0];
      d = arrayOfDouble5[0];
      d1 = arrayOfDouble6[0];
      d1 = Math.abs(unit__.transformHeighttoINCHES(paramSEXP3, b % k, mixedPtr2.copyOf(32), (Ptr)mixedPtr1, d1, d, ptr.pointerPlus(0)));
      d1 = Rmath.Rf_fmin2(Math.abs(unit__.transformWidthtoINCHES(paramSEXP3, b % k, mixedPtr2.copyOf(32), (Ptr)mixedPtr1, d1, d, ptr.pointerPlus(0))), d1);
      if (Arith.R_finite(arrayOfDouble8[0]) != 0 && Arith.R_finite(arrayOfDouble7[0]) != 0 && Arith.R_finite(d1) != 0)
        if (paramInt == 0) {
          if (arrayOfDouble8[0] + d1 < d2)
            d2 = arrayOfDouble8[0] + d1; 
          if (arrayOfDouble8[0] + d1 > d3)
            d3 = arrayOfDouble8[0] + d1; 
          if (arrayOfDouble8[0] - d1 < d2)
            d2 = arrayOfDouble8[0] - d1; 
          if (arrayOfDouble8[0] - d1 > d3)
            d3 = arrayOfDouble8[0] - d1; 
          if (arrayOfDouble7[0] + d1 < d4)
            d4 = arrayOfDouble7[0] + d1; 
          if (arrayOfDouble7[0] + d1 > d5)
            d5 = arrayOfDouble7[0] + d1; 
          if (arrayOfDouble7[0] - d1 < d4)
            d4 = arrayOfDouble7[0] - d1; 
          if (arrayOfDouble7[0] - d1 > d5)
            d5 = arrayOfDouble7[0] - d1; 
          j++;
        } else {
          arrayOfDouble8[0] = baseEngine__.GEtoDeviceX(arrayOfDouble8[0], 2, ptr.pointerPlus(0));
          arrayOfDouble7[0] = baseEngine__.GEtoDeviceY(arrayOfDouble7[0], 2, ptr.pointerPlus(0));
          d1 = baseEngine__.GEtoDeviceWidth(d1, 2, ptr.pointerPlus(0));
          baseEngine__.GECircle(arrayOfDouble8[0], arrayOfDouble7[0], d1, (Ptr)mixedPtr1, ptr.pointerPlus(0));
        }  
    } 
    if (paramInt == 0) {
      if (j > 0) {
        sEXP1 = Rinternals.Rf_allocVector(14, 4);
        if (j != 1) {
          rectEdge(d2, d4, d3, d5, paramDouble, (Ptr)new DoublePtr(arrayOfDouble2, 0), (Ptr)new DoublePtr(arrayOfDouble1, 0));
        } else {
          circleEdge(arrayOfDouble8[0], arrayOfDouble7[0], d1, paramDouble, (Ptr)new DoublePtr(arrayOfDouble2, 0), (Ptr)new DoublePtr(arrayOfDouble1, 0));
        } 
        Rinternals2.REAL(sEXP1).setDouble(0, arrayOfDouble2[0] / Rinternals2.REAL(state__.gridStateElement(ptr.pointerPlus(0), 15)).getDouble());
        Rinternals2.REAL(sEXP1).setDouble(8, arrayOfDouble1[0] / Rinternals2.REAL(state__.gridStateElement(ptr.pointerPlus(0), 15)).getDouble());
        Rinternals2.REAL(sEXP1).setDouble(16, (d3 - d2) / Rinternals2.REAL(state__.gridStateElement(ptr.pointerPlus(0), 15)).getDouble());
        Rinternals2.REAL(sEXP1).setDouble(24, (d5 - d4) / Rinternals2.REAL(state__.gridStateElement(ptr.pointerPlus(0), 15)).getDouble());
      } 
      return sEXP1;
    } 
    baseEngine__.GEMode(0, ptr.pointerPlus(0));
    return sEXP1;
  }
  
  public static SEXP gridRect(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4, SEXP paramSEXP5, SEXP paramSEXP6, double paramDouble, int paramInt) {
    double[] arrayOfDouble1 = new double[1];
    double[] arrayOfDouble2 = new double[1];
    double[] arrayOfDouble3 = new double[1];
    double[] arrayOfDouble4 = new double[1];
    double[] arrayOfDouble5 = new double[5];
    double[] arrayOfDouble6 = new double[5];
    double[] arrayOfDouble7 = new double[1];
    double[] arrayOfDouble8 = new double[1];
    double[] arrayOfDouble9 = new double[9];
    MixedPtr mixedPtr1 = MixedPtr.malloc(276);
    MixedPtr mixedPtr2 = MixedPtr.malloc(32);
    double[] arrayOfDouble10 = new double[1];
    double[] arrayOfDouble11 = new double[1];
    double[] arrayOfDouble12 = new double[1];
    double[] arrayOfDouble13 = new double[1];
    double[] arrayOfDouble14 = new double[1];
    arrayOfDouble1[0] = 0.0D;
    arrayOfDouble2[0] = 0.0D;
    arrayOfDouble3[0] = 0.0D;
    arrayOfDouble4[0] = 0.0D;
    BytePtr.of(0);
    arrayOfDouble7[0] = 0.0D;
    arrayOfDouble8[0] = 0.0D;
    SEXP sEXP1 = (SEXP)BytePtr.of(0).getArray();
    sEXP1 = (SEXP)BytePtr.of(0).getArray();
    arrayOfDouble10[0] = 0.0D;
    arrayOfDouble11[0] = 0.0D;
    arrayOfDouble12[0] = 0.0D;
    arrayOfDouble13[0] = 0.0D;
    arrayOfDouble14[0] = 0.0D;
    sEXP1 = Rinternals.R_NilValue;
    double d1 = Double.MAX_VALUE;
    double d2 = -1.7976931348623157E308D;
    double d3 = Double.MAX_VALUE;
    double d4 = -1.7976931348623157E308D;
    Ptr ptr = getDevice();
    SEXP sEXP2 = state__.gridStateElement(ptr.pointerPlus(0), 5);
    getViewportTransform(state__.gridStateElement(ptr.pointerPlus(0), 7), ptr.pointerPlus(0), (Ptr)new DoublePtr(arrayOfDouble12, 0), (Ptr)new DoublePtr(arrayOfDouble11, 0), (Ptr)new DoublePtr(arrayOfDouble9, 0), (Ptr)new DoublePtr(arrayOfDouble10, 0));
    getViewportContext(state__.gridStateElement(ptr.pointerPlus(0), 7), (Ptr)mixedPtr2);
    int m = unit__.unitLength(paramSEXP1);
    int k = unit__.unitLength(paramSEXP2);
    int j = unit__.unitLength(paramSEXP3);
    int i = unit__.unitLength(paramSEXP4);
    if (k > m)
      m = k; 
    if (j > m)
      m = j; 
    if (i > m)
      m = i; 
    if (paramInt != 0)
      baseEngine__.GEMode(1, ptr.pointerPlus(0)); 
    byte b1 = 0;
    for (byte b2 = 0; b2 < m; b2++) {
      gpar__.gcontextFromgpar(sEXP2, b2, (Ptr)mixedPtr1, ptr.pointerPlus(0));
      if (paramInt == 0) {
        double d9 = arrayOfDouble11[0];
        double d8 = arrayOfDouble12[0];
        arrayOfDouble14[0] = unit__.transformXtoINCHES(paramSEXP1, b2, mixedPtr2.copyOf(32), (Ptr)mixedPtr1, d8, d9, ptr.pointerPlus(0));
        d9 = arrayOfDouble11[0];
        d8 = arrayOfDouble12[0];
        arrayOfDouble13[0] = unit__.transformYtoINCHES(paramSEXP2, b2, mixedPtr2.copyOf(32), (Ptr)mixedPtr1, d8, d9, ptr.pointerPlus(0));
      } else {
        double d9 = arrayOfDouble11[0];
        double d8 = arrayOfDouble12[0];
        unit__.transformLocn(paramSEXP1, paramSEXP2, b2, mixedPtr2.copyOf(32), (Ptr)mixedPtr1, d8, d9, ptr.pointerPlus(0), (Ptr)new DoublePtr(arrayOfDouble9, 0), (Ptr)new DoublePtr(arrayOfDouble14, 0), (Ptr)new DoublePtr(arrayOfDouble13, 0));
      } 
      double d7 = arrayOfDouble11[0];
      double d6 = arrayOfDouble12[0];
      d6 = unit__.transformWidthtoINCHES(paramSEXP3, b2, mixedPtr2.copyOf(32), (Ptr)mixedPtr1, d6, d7, ptr.pointerPlus(0));
      double d5 = arrayOfDouble11[0];
      d7 = arrayOfDouble12[0];
      d7 = unit__.transformHeighttoINCHES(paramSEXP4, b2, mixedPtr2.copyOf(32), (Ptr)mixedPtr1, d7, d5, ptr.pointerPlus(0));
      if (paramInt == 0) {
        d5 = Rinternals2.REAL(paramSEXP5).getDouble(0 + b2 % Rinternals.LENGTH(paramSEXP5) * 8);
        arrayOfDouble14[0] = just__.justifyX(arrayOfDouble14[0], d6, d5);
        d5 = Rinternals2.REAL(paramSEXP6).getDouble(0 + b2 % Rinternals.LENGTH(paramSEXP6) * 8);
        arrayOfDouble13[0] = just__.justifyY(arrayOfDouble13[0], d7, d5);
        if (Arith.R_finite(arrayOfDouble14[0]) != 0 && Arith.R_finite(arrayOfDouble13[0]) != 0 && Arith.R_finite(d6) != 0 && Arith.R_finite(d7) != 0) {
          if (arrayOfDouble14[0] < d1)
            d1 = arrayOfDouble14[0]; 
          if (arrayOfDouble14[0] > d2)
            d2 = arrayOfDouble14[0]; 
          if (arrayOfDouble14[0] + d6 < d1)
            d1 = arrayOfDouble14[0] + d6; 
          if (arrayOfDouble14[0] + d6 > d2)
            d2 = arrayOfDouble14[0] + d6; 
          if (arrayOfDouble13[0] < d3)
            d3 = arrayOfDouble13[0]; 
          if (arrayOfDouble13[0] > d4)
            d4 = arrayOfDouble13[0]; 
          if (arrayOfDouble13[0] + d7 < d3)
            d3 = arrayOfDouble13[0] + d7; 
          if (arrayOfDouble13[0] + d7 > d4)
            d4 = arrayOfDouble13[0] + d7; 
          rectEdge(arrayOfDouble14[0], arrayOfDouble13[0], arrayOfDouble14[0] + d6, arrayOfDouble13[0] + d7, paramDouble, (Ptr)new DoublePtr(arrayOfDouble8, 0), (Ptr)new DoublePtr(arrayOfDouble7, 0));
          b1++;
        } 
      } else if (arrayOfDouble10[0] != 0.0D) {
        SEXP sEXP5 = unit__.unit(0.0D, 2);
        Rinternals.Rf_protect(sEXP5);
        d5 = Rinternals2.REAL(paramSEXP6).getDouble(0 + b2 % Rinternals.LENGTH(paramSEXP6) * 8);
        just__.justification(d6, d7, Rinternals2.REAL(paramSEXP5).getDouble(0 + b2 % Rinternals.LENGTH(paramSEXP5) * 8), d5, (Ptr)new DoublePtr(arrayOfDouble4, 0), (Ptr)new DoublePtr(arrayOfDouble3, 0));
        Rinternals.Rf_protect(unit__.unit(arrayOfDouble4[0], 2));
        Rinternals.Rf_protect(unit__.unit(arrayOfDouble3[0], 2));
        double d9 = arrayOfDouble10[0];
        double d8 = arrayOfDouble11[0];
        d5 = arrayOfDouble12[0];
        unit__.transformDimn(unit__.unit(arrayOfDouble4[0], 2), unit__.unit(arrayOfDouble3[0], 2), 0, mixedPtr2.copyOf(32), (Ptr)mixedPtr1, d5, d8, ptr.pointerPlus(0), d9, (Ptr)new DoublePtr(arrayOfDouble2, 0), (Ptr)new DoublePtr(arrayOfDouble1, 0));
        arrayOfDouble6[0] = arrayOfDouble14[0] + arrayOfDouble2[0];
        arrayOfDouble5[0] = arrayOfDouble13[0] + arrayOfDouble1[0];
        SEXP sEXP3 = unit__.unit(d7, 2);
        Rinternals.Rf_protect(sEXP3);
        d8 = arrayOfDouble10[0];
        d5 = arrayOfDouble11[0];
        d7 = arrayOfDouble12[0];
        unit__.transformDimn(sEXP5, sEXP3, 0, mixedPtr2.copyOf(32), (Ptr)mixedPtr1, d7, d5, ptr.pointerPlus(0), d8, (Ptr)new DoublePtr(arrayOfDouble2, 0), (Ptr)new DoublePtr(arrayOfDouble1, 0));
        arrayOfDouble6[1] = arrayOfDouble6[0] + arrayOfDouble2[0];
        arrayOfDouble5[1] = arrayOfDouble5[0] + arrayOfDouble1[0];
        SEXP sEXP4 = unit__.unit(d6, 2);
        Rinternals.Rf_protect(sEXP4);
        d5 = arrayOfDouble10[0];
        d7 = arrayOfDouble11[0];
        d6 = arrayOfDouble12[0];
        unit__.transformDimn(sEXP4, sEXP3, 0, mixedPtr2.copyOf(32), (Ptr)mixedPtr1, d6, d7, ptr.pointerPlus(0), d5, (Ptr)new DoublePtr(arrayOfDouble2, 0), (Ptr)new DoublePtr(arrayOfDouble1, 0));
        arrayOfDouble6[2] = arrayOfDouble6[0] + arrayOfDouble2[0];
        arrayOfDouble5[2] = arrayOfDouble5[0] + arrayOfDouble1[0];
        d5 = arrayOfDouble10[0];
        d7 = arrayOfDouble11[0];
        d6 = arrayOfDouble12[0];
        unit__.transformDimn(sEXP4, sEXP5, 0, mixedPtr2.copyOf(32), (Ptr)mixedPtr1, d6, d7, ptr.pointerPlus(0), d5, (Ptr)new DoublePtr(arrayOfDouble2, 0), (Ptr)new DoublePtr(arrayOfDouble1, 0));
        arrayOfDouble6[3] = arrayOfDouble6[0] + arrayOfDouble2[0];
        arrayOfDouble5[3] = arrayOfDouble5[0] + arrayOfDouble1[0];
        if (Arith.R_finite(arrayOfDouble6[0]) != 0 && Arith.R_finite(arrayOfDouble5[0]) != 0 && Arith.R_finite(arrayOfDouble6[1]) != 0 && Arith.R_finite(arrayOfDouble5[1]) != 0 && Arith.R_finite(arrayOfDouble6[2]) != 0 && Arith.R_finite(arrayOfDouble5[2]) != 0 && Arith.R_finite(arrayOfDouble6[3]) != 0 && Arith.R_finite(arrayOfDouble5[3]) != 0) {
          arrayOfDouble6[0] = baseEngine__.GEtoDeviceX(arrayOfDouble6[0], 2, ptr.pointerPlus(0));
          arrayOfDouble5[0] = baseEngine__.GEtoDeviceY(arrayOfDouble5[0], 2, ptr.pointerPlus(0));
          arrayOfDouble6[1] = baseEngine__.GEtoDeviceX(arrayOfDouble6[1], 2, ptr.pointerPlus(0));
          arrayOfDouble5[1] = baseEngine__.GEtoDeviceY(arrayOfDouble5[1], 2, ptr.pointerPlus(0));
          arrayOfDouble6[2] = baseEngine__.GEtoDeviceX(arrayOfDouble6[2], 2, ptr.pointerPlus(0));
          arrayOfDouble5[2] = baseEngine__.GEtoDeviceY(arrayOfDouble5[2], 2, ptr.pointerPlus(0));
          arrayOfDouble6[3] = baseEngine__.GEtoDeviceX(arrayOfDouble6[3], 2, ptr.pointerPlus(0));
          arrayOfDouble5[3] = baseEngine__.GEtoDeviceY(arrayOfDouble5[3], 2, ptr.pointerPlus(0));
          arrayOfDouble6[4] = arrayOfDouble6[0];
          arrayOfDouble5[4] = arrayOfDouble5[0];
          mixedPtr1.setInt(16777215);
          baseEngine__.GEPolygon(5, (Ptr)new DoublePtr(arrayOfDouble6, 0), (Ptr)new DoublePtr(arrayOfDouble5, 0), (Ptr)mixedPtr1, ptr.pointerPlus(0));
          mixedPtr1.setInt(mixedPtr1.getInt());
          mixedPtr1.setAlignedInt(1, 16777215);
          baseEngine__.GEPolygon(5, (Ptr)new DoublePtr(arrayOfDouble6, 0), (Ptr)new DoublePtr(arrayOfDouble5, 0), (Ptr)mixedPtr1, ptr.pointerPlus(0));
        } 
      } else {
        d5 = Rinternals2.REAL(paramSEXP5).getDouble(0 + b2 % Rinternals.LENGTH(paramSEXP5) * 8);
        arrayOfDouble14[0] = just__.justifyX(arrayOfDouble14[0], d6, d5);
        d5 = Rinternals2.REAL(paramSEXP6).getDouble(0 + b2 % Rinternals.LENGTH(paramSEXP6) * 8);
        arrayOfDouble13[0] = just__.justifyY(arrayOfDouble13[0], d7, d5);
        arrayOfDouble14[0] = baseEngine__.GEtoDeviceX(arrayOfDouble14[0], 2, ptr.pointerPlus(0));
        arrayOfDouble13[0] = baseEngine__.GEtoDeviceY(arrayOfDouble13[0], 2, ptr.pointerPlus(0));
        d6 = baseEngine__.GEtoDeviceWidth(d6, 2, ptr.pointerPlus(0));
        d7 = baseEngine__.GEtoDeviceHeight(d7, 2, ptr.pointerPlus(0));
        if (Arith.R_finite(arrayOfDouble14[0]) != 0 && Arith.R_finite(arrayOfDouble13[0]) != 0 && Arith.R_finite(d6) != 0 && Arith.R_finite(d7) != 0)
          baseEngine__.GERect(arrayOfDouble14[0], arrayOfDouble13[0], arrayOfDouble14[0] + d6, arrayOfDouble13[0] + d7, (Ptr)mixedPtr1, ptr.pointerPlus(0)); 
      } 
    } 
    if (paramInt != 0)
      baseEngine__.GEMode(0, ptr.pointerPlus(0)); 
    if (b1 > 0) {
      sEXP1 = Rinternals.Rf_allocVector(14, 4);
      if (b1 > 1)
        rectEdge(d1, d3, d2, d4, paramDouble, (Ptr)new DoublePtr(arrayOfDouble8, 0), (Ptr)new DoublePtr(arrayOfDouble7, 0)); 
      Rinternals2.REAL(sEXP1).setDouble(0, arrayOfDouble8[0] / Rinternals2.REAL(state__.gridStateElement(ptr.pointerPlus(0), 15)).getDouble());
      Rinternals2.REAL(sEXP1).setDouble(8, arrayOfDouble7[0] / Rinternals2.REAL(state__.gridStateElement(ptr.pointerPlus(0), 15)).getDouble());
      Rinternals2.REAL(sEXP1).setDouble(16, (d2 - d1) / Rinternals2.REAL(state__.gridStateElement(ptr.pointerPlus(0), 15)).getDouble());
      Rinternals2.REAL(sEXP1).setDouble(24, (d4 - d3) / Rinternals2.REAL(state__.gridStateElement(ptr.pointerPlus(0), 15)).getDouble());
    } 
    return sEXP1;
  }
  
  public static SEXP gridText(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4, SEXP paramSEXP5, SEXP paramSEXP6, SEXP paramSEXP7, double paramDouble, int paramInt) {
    MixedPtr mixedPtr5;
    double[] arrayOfDouble1 = new double[4];
    double[] arrayOfDouble2 = new double[4];
    MixedPtr mixedPtr1 = MixedPtr.malloc(64);
    double[] arrayOfDouble3 = new double[1];
    double[] arrayOfDouble4 = new double[1];
    double[] arrayOfDouble5 = new double[9];
    MixedPtr mixedPtr2 = MixedPtr.malloc(276);
    MixedPtr mixedPtr3 = MixedPtr.malloc(32);
    double[] arrayOfDouble6 = new double[1];
    double[] arrayOfDouble7 = new double[1];
    double[] arrayOfDouble8 = new double[1];
    MixedPtr mixedPtr4 = MixedPtr.malloc(64);
    BytePtr.of(0);
    SEXP sEXP1 = (SEXP)BytePtr.of(0).getArray();
    BytePtr.of(0);
    BytePtr.of(0);
    arrayOfDouble3[0] = 0.0D;
    arrayOfDouble4[0] = 0.0D;
    sEXP1 = (SEXP)BytePtr.of(0).getArray();
    sEXP1 = (SEXP)BytePtr.of(0).getArray();
    arrayOfDouble6[0] = 0.0D;
    arrayOfDouble7[0] = 0.0D;
    arrayOfDouble8[0] = 0.0D;
    BytePtr.of(0);
    BytePtr.of(0);
    sEXP1 = Rinternals.R_NilValue;
    double d1 = Double.MAX_VALUE;
    double d2 = -1.7976931348623157E308D;
    double d3 = Double.MAX_VALUE;
    double d4 = -1.7976931348623157E308D;
    Ptr ptr1 = BytePtr.of(0);
    byte b1 = 0;
    int i = Rinternals.LOGICAL(paramSEXP7).getInt();
    Ptr ptr2 = getDevice();
    SEXP sEXP2 = state__.gridStateElement(ptr2.pointerPlus(0), 5);
    getViewportTransform(state__.gridStateElement(ptr2.pointerPlus(0), 7), ptr2.pointerPlus(0), (Ptr)new DoublePtr(arrayOfDouble8, 0), (Ptr)new DoublePtr(arrayOfDouble7, 0), (Ptr)new DoublePtr(arrayOfDouble5, 0), (Ptr)new DoublePtr(arrayOfDouble6, 0));
    getViewportContext(state__.gridStateElement(ptr2.pointerPlus(0), 7), (Ptr)mixedPtr3);
    int k = unit__.unitLength(paramSEXP2);
    int j = unit__.unitLength(paramSEXP3);
    if (j > k)
      k = j; 
    VoidPtr.toPtr(Memory.vmaxget());
    DoublePtr doublePtr1 = DoublePtr.malloc(k * 8);
    DoublePtr doublePtr2 = DoublePtr.malloc(k * 8);
    for (byte b2 = 0; b2 < k; b2++) {
      gpar__.gcontextFromgpar(sEXP2, b2, (Ptr)mixedPtr2, ptr2.pointerPlus(0));
      if (paramInt == 0) {
        double d6 = arrayOfDouble7[0];
        double d5 = arrayOfDouble8[0];
        doublePtr1.setDouble(0 + b2 * 8, unit__.transformXtoINCHES(paramSEXP2, b2, mixedPtr3.copyOf(32), (Ptr)mixedPtr2, d5, d6, ptr2.pointerPlus(0)));
        d6 = arrayOfDouble7[0];
        d5 = arrayOfDouble8[0];
        doublePtr2.setDouble(0 + b2 * 8, unit__.transformYtoINCHES(paramSEXP3, b2, mixedPtr3.copyOf(32), (Ptr)mixedPtr2, d5, d6, ptr2.pointerPlus(0)));
      } else {
        double d6 = arrayOfDouble7[0];
        double d5 = arrayOfDouble8[0];
        Ptr ptr3 = mixedPtr3.copyOf(32);
        Ptr ptr4 = ptr2.pointerPlus(0);
        Ptr ptr5 = (Ptr)new DoublePtr(arrayOfDouble5, 0);
        Ptr ptr6 = doublePtr1.pointerPlus(0 + b2 * 8);
        Ptr ptr7 = doublePtr2.pointerPlus(0 + b2 * 8);
        unit__.transformLocn(paramSEXP2, paramSEXP3, b2, ptr3, (Ptr)mixedPtr2, d5, d6, ptr4, ptr5, ptr6, ptr7);
      } 
    } 
    paramSEXP2 = paramSEXP1;
    Rinternals.Rf_protect(paramSEXP1);
    if (!Rinternals.Rf_isSymbol(paramSEXP1) && !Rinternals.Rf_isLanguage(paramSEXP1)) {
      if (!Rinternals.Rf_isExpression(paramSEXP1))
        paramSEXP2 = Rinternals.Rf_coerceVector(paramSEXP1, 16); 
    } else {
      paramSEXP2 = Rinternals.Rf_coerceVector(paramSEXP1, 20);
    } 
    Rinternals.Rf_protect(paramSEXP2);
    if (i != 0 || paramInt == 0)
      mixedPtr5 = MixedPtr.malloc(k * 64); 
    if (Rinternals.LENGTH(paramSEXP2) > 0) {
      byte b3 = 0;
      if (paramInt != 0)
        baseEngine__.GEMode(1, ptr2.pointerPlus(0)); 
      for (byte b4 = 0; b4 < k; b4++) {
        boolean bool = true;
        gpar__.gcontextFromgpar(sEXP2, b4, (Ptr)mixedPtr2, ptr2.pointerPlus(0));
        if (i != 0 || paramInt == 0) {
          byte b = 0;
          double d8 = util__.numeric(paramSEXP6, b4 % Rinternals.LENGTH(paramSEXP6));
          double d7 = Rinternals2.REAL(paramSEXP5).getDouble(0 + b4 % Rinternals.LENGTH(paramSEXP5) * 8);
          double d6 = Rinternals2.REAL(paramSEXP4).getDouble(0 + b4 % Rinternals.LENGTH(paramSEXP4) * 8);
          double d5 = doublePtr2.getDouble(0 + b4 * 8);
          util__.textRect(doublePtr1.getDouble(0 + b4 * 8), d5, paramSEXP2, b4, (Ptr)mixedPtr2, d6, d7, d8, ptr2.pointerPlus(0), (Ptr)mixedPtr1);
          while (bool && b < b1) {
            mixedPtr4.memcpy(mixedPtr5.pointerPlus(0 + b * 64), 64);
            b++;
            if (util__.intersect(mixedPtr1.copyOf(64), mixedPtr4.copyOf(64)) == 0)
              continue; 
            bool = false;
          } 
          if (bool) {
            Ptr ptr3 = mixedPtr1.copyOf(64);
            Ptr ptr4 = mixedPtr5.pointerPlus(0 + b1 * 64);
            util__.copyRect(ptr3, ptr4);
            b1++;
          } 
        } 
        if (paramInt != 0 && bool) {
          doublePtr1.setDouble(0 + b4 * 8, baseEngine__.GEtoDeviceX(doublePtr1.getDouble(0 + b4 * 8), 2, ptr2.pointerPlus(0)));
          doublePtr2.setDouble(0 + b4 * 8, baseEngine__.GEtoDeviceY(doublePtr2.getDouble(0 + b4 * 8), 2, ptr2.pointerPlus(0)));
          if (Arith.R_finite(doublePtr1.getDouble(0 + b4 * 8)) != 0 && Arith.R_finite(doublePtr2.getDouble(0 + b4 * 8)) != 0) {
            gpar__.gcontextFromgpar(sEXP2, b4, (Ptr)mixedPtr2, ptr2.pointerPlus(0));
            if (!Rinternals.Rf_isExpression(paramSEXP2)) {
              int m;
              double d8 = util__.numeric(paramSEXP6, b4 % Rinternals.LENGTH(paramSEXP6)) + arrayOfDouble6[0];
              double d7 = Rinternals2.REAL(paramSEXP5).getDouble(0 + b4 % Rinternals.LENGTH(paramSEXP5) * 8);
              double d6 = Rinternals2.REAL(paramSEXP4).getDouble(0 + b4 % Rinternals.LENGTH(paramSEXP4) * 8);
              if (mixedPtr2.getAlignedInt(17) == 5) {
                m = 5;
              } else {
                m = Rinternals.Rf_getCharCE(Rinternals.STRING_ELT(paramSEXP2, b4 % Rinternals.LENGTH(paramSEXP2)));
              } 
              BytePtr bytePtr = Rinternals.R_CHAR(Rinternals.STRING_ELT(paramSEXP2, b4 % Rinternals.LENGTH(paramSEXP2)));
              double d5 = doublePtr2.getDouble(0 + b4 * 8);
              baseEngine__.GEText(doublePtr1.getDouble(0 + b4 * 8), d5, (Ptr)bytePtr, m, d6, d7, d8, (Ptr)mixedPtr2, ptr2.pointerPlus(0));
            } else {
              util__.numeric(paramSEXP6, b4 % Rinternals.LENGTH(paramSEXP6));
              paramDouble = arrayOfDouble6[0];
              Rinternals2.REAL(paramSEXP5).getDouble(0 + b4 % Rinternals.LENGTH(paramSEXP5) * 8);
              Rinternals2.REAL(paramSEXP4).getDouble(0 + b4 % Rinternals.LENGTH(paramSEXP4) * 8);
              Rinternals.VECTOR_ELT(paramSEXP2, b4 % Rinternals.LENGTH(paramSEXP2));
              doublePtr2.getDouble(0 + b4 * 8);
              doublePtr1.getDouble(0 + b4 * 8);
              throw new UnsatisfiedLinkException("GEMathText");
            } 
          } 
        } 
        if (paramInt == 0 && Arith.R_finite(doublePtr1.getDouble(0 + b4 * 8)) != 0 && Arith.R_finite(doublePtr2.getDouble(0 + b4 * 8)) != 0) {
          double d = mixedPtr1.getAlignedDouble(3);
          d = Rmath.Rf_fmin2(mixedPtr1.getAlignedDouble(2), d);
          d = Rmath.Rf_fmin2(mixedPtr1.getAlignedDouble(1), d);
          d = Rmath.Rf_fmin2(mixedPtr1.getDouble(), d);
          if (d < d1)
            d1 = d; 
          d = mixedPtr1.getAlignedDouble(3);
          d = Rmath.Rf_fmax2(mixedPtr1.getAlignedDouble(2), d);
          d = Rmath.Rf_fmax2(mixedPtr1.getAlignedDouble(1), d);
          d = Rmath.Rf_fmax2(mixedPtr1.getDouble(), d);
          if (d > d2)
            d2 = d; 
          d = mixedPtr1.getAlignedDouble(7);
          d = Rmath.Rf_fmin2(mixedPtr1.getAlignedDouble(6), d);
          d = Rmath.Rf_fmin2(mixedPtr1.getAlignedDouble(5), d);
          d = Rmath.Rf_fmin2(mixedPtr1.getAlignedDouble(4), d);
          if (d < d3)
            d3 = d; 
          d = mixedPtr1.getAlignedDouble(7);
          d = Rmath.Rf_fmax2(mixedPtr1.getAlignedDouble(6), d);
          d = Rmath.Rf_fmax2(mixedPtr1.getAlignedDouble(5), d);
          d = Rmath.Rf_fmax2(mixedPtr1.getAlignedDouble(4), d);
          if (d > d4)
            d4 = d; 
          arrayOfDouble2[0] = mixedPtr1.getAlignedDouble(3);
          arrayOfDouble1[0] = mixedPtr1.getAlignedDouble(7);
          arrayOfDouble2[1] = mixedPtr1.getAlignedDouble(2);
          arrayOfDouble1[1] = mixedPtr1.getAlignedDouble(6);
          arrayOfDouble2[2] = mixedPtr1.getAlignedDouble(1);
          arrayOfDouble1[2] = mixedPtr1.getAlignedDouble(5);
          arrayOfDouble2[3] = mixedPtr1.getDouble();
          arrayOfDouble1[3] = mixedPtr1.getAlignedDouble(4);
          polygonEdge((Ptr)new DoublePtr(arrayOfDouble2, 0), (Ptr)new DoublePtr(arrayOfDouble1, 0), 4, paramDouble, (Ptr)new DoublePtr(arrayOfDouble4, 0), (Ptr)new DoublePtr(arrayOfDouble3, 0));
          b3++;
        } 
      } 
      if (paramInt != 0)
        baseEngine__.GEMode(0, ptr2.pointerPlus(0)); 
      if (b3 > 0) {
        sEXP1 = Rinternals.Rf_allocVector(14, 4);
        if (b3 > 1)
          rectEdge(d1, d3, d2, d4, paramDouble, (Ptr)new DoublePtr(arrayOfDouble4, 0), (Ptr)new DoublePtr(arrayOfDouble3, 0)); 
        Rinternals2.REAL(sEXP1).setDouble(0, arrayOfDouble4[0] / Rinternals2.REAL(state__.gridStateElement(ptr2.pointerPlus(0), 15)).getDouble());
        Rinternals2.REAL(sEXP1).setDouble(8, arrayOfDouble3[0] / Rinternals2.REAL(state__.gridStateElement(ptr2.pointerPlus(0), 15)).getDouble());
        Rinternals2.REAL(sEXP1).setDouble(16, (d2 - d1) / Rinternals2.REAL(state__.gridStateElement(ptr2.pointerPlus(0), 15)).getDouble());
        Rinternals2.REAL(sEXP1).setDouble(24, (d4 - d3) / Rinternals2.REAL(state__.gridStateElement(ptr2.pointerPlus(0), 15)).getDouble());
      } 
    } 
    return sEXP1;
  }
  
  public static SEXP gridXspline(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4, SEXP paramSEXP5, SEXP paramSEXP6, SEXP paramSEXP7, double paramDouble, int paramInt1, int paramInt2) {
    double[] arrayOfDouble1 = new double[1];
    double[] arrayOfDouble2 = new double[1];
    double[] arrayOfDouble3 = new double[9];
    MixedPtr mixedPtr1 = MixedPtr.malloc(276);
    MixedPtr mixedPtr2 = MixedPtr.malloc(32);
    double[] arrayOfDouble4 = new double[1];
    double[] arrayOfDouble5 = new double[1];
    double[] arrayOfDouble6 = new double[1];
    BytePtr.of(0);
    BytePtr.of(0);
    SEXP sEXP1 = (SEXP)BytePtr.of(0).getArray();
    sEXP1 = (SEXP)BytePtr.of(0).getArray();
    sEXP1 = (SEXP)BytePtr.of(0).getArray();
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    sEXP1 = (SEXP)BytePtr.of(0).getArray();
    sEXP1 = (SEXP)BytePtr.of(0).getArray();
    BytePtr.of(0);
    BytePtr.of(0);
    arrayOfDouble1[0] = 0.0D;
    arrayOfDouble2[0] = 0.0D;
    sEXP1 = (SEXP)BytePtr.of(0).getArray();
    sEXP1 = (SEXP)BytePtr.of(0).getArray();
    sEXP1 = (SEXP)BytePtr.of(0).getArray();
    arrayOfDouble4[0] = 0.0D;
    arrayOfDouble5[0] = 0.0D;
    arrayOfDouble6[0] = 0.0D;
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    sEXP1 = Rinternals.R_NilValue;
    sEXP1 = Rinternals.R_NilValue;
    double d1 = Double.MAX_VALUE;
    double d2 = -1.7976931348623157E308D;
    double d3 = Double.MAX_VALUE;
    double d4 = -1.7976931348623157E308D;
    Ptr ptr = getDevice();
    SEXP sEXP2 = state__.gridStateElement(ptr.pointerPlus(0), 5);
    getViewportTransform(state__.gridStateElement(ptr.pointerPlus(0), 7), ptr.pointerPlus(0), (Ptr)new DoublePtr(arrayOfDouble6, 0), (Ptr)new DoublePtr(arrayOfDouble5, 0), (Ptr)new DoublePtr(arrayOfDouble3, 0), (Ptr)new DoublePtr(arrayOfDouble4, 0));
    getViewportContext(state__.gridStateElement(ptr.pointerPlus(0), 7), (Ptr)mixedPtr2);
    gpar__.gcontextFromgpar(sEXP2, 0, (Ptr)mixedPtr1, ptr.pointerPlus(0));
    int i = Rinternals.LENGTH(paramSEXP7);
    SEXP sEXP3 = Rinternals.Rf_allocVector(19, i);
    Rinternals.Rf_protect(sEXP3);
    byte b1 = 0;
    for (byte b2 = 0; b2 < i; b2++) {
      SEXP sEXP4 = Rinternals.VECTOR_ELT(paramSEXP7, b2);
      gpar__.gcontextFromgpar(sEXP2, b2, (Ptr)mixedPtr1, ptr.pointerPlus(0));
      int n = Rinternals.LENGTH(sEXP4);
      VoidPtr.toPtr(Memory.vmaxget());
      if (paramInt1 != 0)
        baseEngine__.GEMode(1, ptr.pointerPlus(0)); 
      DoublePtr doublePtr1 = DoublePtr.malloc(n * 8);
      DoublePtr doublePtr2 = DoublePtr.malloc(n * 8);
      DoublePtr doublePtr3 = DoublePtr.malloc(n * 8);
      int i1;
      for (i1 = 0; i1 < n; i1++) {
        doublePtr3.setDouble(0 + i1 * 8, Rinternals2.REAL(paramSEXP3).getDouble(0 + (Rinternals2.INTEGER(sEXP4).getInt(0 + i1 * 4) + -1) % Rinternals.LENGTH(paramSEXP3) * 8));
        if (paramInt1 == 0) {
          double d6 = arrayOfDouble5[0];
          double d5 = arrayOfDouble6[0];
          doublePtr1.setDouble(0 + i1 * 8, unit__.transformXtoINCHES(paramSEXP1, Rinternals2.INTEGER(sEXP4).getInt(0 + i1 * 4) + -1, mixedPtr2.copyOf(32), (Ptr)mixedPtr1, d5, d6, ptr.pointerPlus(0)));
          d6 = arrayOfDouble5[0];
          d5 = arrayOfDouble6[0];
          doublePtr2.setDouble(0 + i1 * 8, unit__.transformYtoINCHES(paramSEXP2, Rinternals2.INTEGER(sEXP4).getInt(0 + i1 * 4) + -1, mixedPtr2.copyOf(32), (Ptr)mixedPtr1, d5, d6, ptr.pointerPlus(0)));
        } else {
          double d6 = arrayOfDouble5[0];
          double d5 = arrayOfDouble6[0];
          int i2 = Rinternals2.INTEGER(sEXP4).getInt(0 + i1 * 4) + -1;
          Ptr ptr4 = mixedPtr2.copyOf(32);
          Ptr ptr5 = ptr.pointerPlus(0);
          Ptr ptr6 = (Ptr)new DoublePtr(arrayOfDouble3, 0);
          Ptr ptr7 = doublePtr1.pointerPlus(0 + i1 * 8);
          Ptr ptr3 = doublePtr2.pointerPlus(0 + i1 * 8);
          unit__.transformLocn(paramSEXP1, paramSEXP2, i2, ptr4, (Ptr)mixedPtr1, d5, d6, ptr5, ptr6, ptr7, ptr3);
        } 
        doublePtr1.setDouble(0 + i1 * 8, baseEngine__.GEtoDeviceX(doublePtr1.getDouble(0 + i1 * 8), 2, ptr.pointerPlus(0)));
        doublePtr2.setDouble(0 + i1 * 8, baseEngine__.GEtoDeviceY(doublePtr2.getDouble(0 + i1 * 8), 2, ptr.pointerPlus(0)));
        if (Arith.R_finite(doublePtr1.getDouble(0 + i1 * 8)) == 0 || Arith.R_finite(doublePtr2.getDouble(0 + i1 * 8)) == 0)
          Error.Rf_error(GetText.dgettext(new BytePtr("grid\000".getBytes(), 0), new BytePtr("non-finite control point in Xspline\000".getBytes(), 0)), new Object[0]); 
      } 
      int k = Rinternals.LOGICAL(paramSEXP6).getInt();
      int j = Rinternals.LOGICAL(paramSEXP4).getInt();
      SEXP sEXP5 = baseEngine__.GEXspline(n, doublePtr1.pointerPlus(0), doublePtr2.pointerPlus(0), doublePtr3.pointerPlus(0), j, k, paramInt1, (Ptr)mixedPtr1, ptr.pointerPlus(0));
      Rinternals.Rf_protect(sEXP5);
      j = Rinternals.LENGTH(Rinternals.VECTOR_ELT(sEXP5, 0));
      Ptr ptr1 = Rinternals2.REAL(Rinternals.VECTOR_ELT(sEXP5, 0));
      Ptr ptr2 = Rinternals2.REAL(Rinternals.VECTOR_ELT(sEXP5, 1));
      k = 0;
      int m = j + -1;
      while (j > 1 && ptr1.getDouble(0 + k * 8) == ptr1.getDouble(0 + (k + 1) * 8) && ptr2.getDouble(0 + k * 8) == ptr2.getDouble(0 + (k + 1) * 8)) {
        k++;
        j--;
      } 
      while (j > 1 && ptr1.getDouble(0 + m * 8) == ptr1.getDouble(0 + (m + -1) * 8) && ptr2.getDouble(0 + m * 8) == ptr2.getDouble(0 + (m + -1) * 8)) {
        m--;
        j--;
      } 
      if (paramInt2 != 0) {
        int i2 = m - k + 1;
        SEXP sEXP7 = Rinternals.Rf_allocVector(19, 2);
        Rinternals.Rf_protect(sEXP7);
        SEXP sEXP8 = Rinternals.Rf_allocVector(14, i2);
        Rinternals.Rf_protect(sEXP8);
        SEXP sEXP6 = Rinternals.Rf_allocVector(14, i2);
        Rinternals.Rf_protect(sEXP6);
        Ptr ptr3 = Rinternals2.REAL(sEXP8);
        Ptr ptr4 = Rinternals2.REAL(sEXP6);
        for (i1 = k; m + 1 > i1; i1++) {
          ptr3.setDouble(0 + (i1 - k) * 8, baseEngine__.GEfromDeviceX(ptr1.getDouble(0 + i1 * 8), 2, ptr.pointerPlus(0)));
          ptr4.setDouble(0 + (i1 - k) * 8, baseEngine__.GEfromDeviceY(ptr2.getDouble(0 + i1 * 8), 2, ptr.pointerPlus(0)));
        } 
        Rinternals.SET_VECTOR_ELT(sEXP7, 0, sEXP8);
        Rinternals.SET_VECTOR_ELT(sEXP7, 1, sEXP6);
        Rinternals.SET_VECTOR_ELT(sEXP3, b2, sEXP7);
      } 
      if (paramInt1 != 0 && !Rinternals.Rf_isNull(paramSEXP5) && !Rinternals.Rf_isNull(sEXP5)) {
        double d6 = arrayOfDouble5[0];
        double d5 = arrayOfDouble6[0];
        Ptr ptr3 = ptr1.pointerPlus(0 + k * 8);
        Ptr ptr4 = ptr2.pointerPlus(0 + k * 8);
        arrows(ptr3, ptr4, j, paramSEXP5, b2, 1, 1, mixedPtr2.copyOf(32), d5, d6, (Ptr)mixedPtr1, ptr.pointerPlus(0));
      } 
      if (paramInt1 == 0 && paramInt2 == 0 && !Rinternals.Rf_isNull(sEXP5)) {
        int i2 = Rinternals.LENGTH(Rinternals.VECTOR_ELT(sEXP5, 0));
        DoublePtr doublePtr4 = DoublePtr.malloc(i2 * 8);
        DoublePtr doublePtr5 = DoublePtr.malloc(i2 * 8);
        for (m = 0; m < i2; m++) {
          doublePtr4.setDouble(0 + m * 8, baseEngine__.GEfromDeviceX(ptr1.getDouble(0 + m * 8), 2, ptr.pointerPlus(0)));
          doublePtr5.setDouble(0 + m * 8, baseEngine__.GEfromDeviceY(ptr2.getDouble(0 + m * 8), 2, ptr.pointerPlus(0)));
          if (Arith.R_finite(doublePtr4.getDouble(0 + m * 8)) != 0 && Arith.R_finite(doublePtr5.getDouble(0 + m * 8)) != 0) {
            if (doublePtr4.getDouble(0 + m * 8) < d1)
              d1 = doublePtr4.getDouble(0 + m * 8); 
            if (doublePtr4.getDouble(0 + m * 8) > d2)
              d2 = doublePtr4.getDouble(0 + m * 8); 
            if (doublePtr5.getDouble(0 + m * 8) < d3)
              d3 = doublePtr5.getDouble(0 + m * 8); 
            if (doublePtr5.getDouble(0 + m * 8) > d4)
              d4 = doublePtr5.getDouble(0 + m * 8); 
            b1++;
          } 
        } 
        hullEdge(doublePtr4.pointerPlus(0), doublePtr5.pointerPlus(0), i2, paramDouble, (Ptr)new DoublePtr(arrayOfDouble2, 0), (Ptr)new DoublePtr(arrayOfDouble1, 0));
      } 
      if (paramInt1 != 0)
        baseEngine__.GEMode(0, ptr.pointerPlus(0)); 
    } 
    if (paramInt1 != 0 || paramInt2 != 0 || b1 <= 0) {
      if (paramInt2 != 0)
        sEXP1 = sEXP3; 
      return sEXP1;
    } 
    sEXP1 = Rinternals.Rf_allocVector(14, 4);
    Rinternals.Rf_protect(sEXP1);
    if (i > 1)
      rectEdge(d1, d3, d2, d4, paramDouble, (Ptr)new DoublePtr(arrayOfDouble2, 0), (Ptr)new DoublePtr(arrayOfDouble1, 0)); 
    Rinternals2.REAL(sEXP1).setDouble(0, arrayOfDouble2[0] / Rinternals2.REAL(state__.gridStateElement(ptr.pointerPlus(0), 15)).getDouble());
    Rinternals2.REAL(sEXP1).setDouble(8, arrayOfDouble1[0] / Rinternals2.REAL(state__.gridStateElement(ptr.pointerPlus(0), 15)).getDouble());
    Rinternals2.REAL(sEXP1).setDouble(16, (d2 - d1) / Rinternals2.REAL(state__.gridStateElement(ptr.pointerPlus(0), 15)).getDouble());
    Rinternals2.REAL(sEXP1).setDouble(24, (d4 - d3) / Rinternals2.REAL(state__.gridStateElement(ptr.pointerPlus(0), 15)).getDouble());
    return sEXP1;
  }
  
  public static SEXP growPath(SEXP paramSEXP1, SEXP paramSEXP2) {
    if (!Rinternals.Rf_isNull(paramSEXP1)) {
      Rinternals.Rf_protect(Rinternals.Rf_lang3(Rinternals.Rf_install(new BytePtr("growPath\000".getBytes(), 0)), paramSEXP1, paramSEXP2));
      paramSEXP1 = Rinternals.Rf_eval(Rinternals.Rf_lang3(Rinternals.Rf_install(new BytePtr("growPath\000".getBytes(), 0)), paramSEXP1, paramSEXP2), R_gridEvalEnv);
      Rinternals.Rf_protect(paramSEXP1);
      return paramSEXP1;
    } 
    return paramSEXP2;
  }
  
  public static void hullEdge(Ptr paramPtr1, Ptr paramPtr2, int paramInt, double paramDouble, Ptr paramPtr3, Ptr paramPtr4) {
    BytePtr.of(0);
    BytePtr.of(0);
    SEXP sEXP3 = (SEXP)BytePtr.of(0).getArray();
    sEXP3 = (SEXP)BytePtr.of(0).getArray();
    sEXP3 = (SEXP)BytePtr.of(0).getArray();
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    byte b1 = 0;
    VoidPtr.toPtr(Memory.vmaxget());
    DoublePtr doublePtr1 = DoublePtr.malloc(paramInt * 8);
    DoublePtr doublePtr3 = DoublePtr.malloc(paramInt * 8);
    int j;
    for (j = 0; j < paramInt; j++) {
      if (Arith.R_finite(paramPtr1.getDouble(j * 8)) != 0 && Arith.R_finite(paramPtr2.getDouble(j * 8)) != 0) {
        doublePtr1.setDouble(0 + (j + b1) * 8, paramPtr1.getDouble(j * 8));
        doublePtr3.setDouble(0 + (j + b1) * 8, paramPtr2.getDouble(j * 8));
      } else {
        b1--;
      } 
    } 
    j = paramInt + b1;
    SEXP sEXP1 = Rinternals.Rf_allocVector(14, j);
    Rinternals.Rf_protect(sEXP1);
    SEXP sEXP4 = Rinternals.Rf_allocVector(14, j);
    Rinternals.Rf_protect(sEXP4);
    for (byte b2 = 0; b2 < j; b2++) {
      Rinternals2.REAL(sEXP1).setDouble(0 + b2 * 8, doublePtr1.getDouble(0 + b2 * 8));
      Rinternals2.REAL(sEXP4).setDouble(0 + b2 * 8, doublePtr3.getDouble(0 + b2 * 8));
    } 
    SEXP sEXP2 = R_gridEvalEnv;
    Rinternals.Rf_protect(Rinternals.Rf_findFun(Rinternals.Rf_install(new BytePtr("chull\000".getBytes(), 0)), sEXP2));
    Rinternals.Rf_protect(Rinternals.Rf_lang3(Rinternals.Rf_findFun(Rinternals.Rf_install(new BytePtr("chull\000".getBytes(), 0)), sEXP2), sEXP1, sEXP4));
    sEXP1 = Rinternals.Rf_eval(Rinternals.Rf_lang3(Rinternals.Rf_findFun(Rinternals.Rf_install(new BytePtr("chull\000".getBytes(), 0)), sEXP2), sEXP1, sEXP4), R_gridEvalEnv);
    Rinternals.Rf_protect(sEXP1);
    int i = Rinternals.LENGTH(sEXP1);
    doublePtr3 = DoublePtr.malloc(i * 8);
    DoublePtr doublePtr2 = DoublePtr.malloc(i * 8);
    for (j = 0; j < i; j++) {
      doublePtr3.setDouble(0 + j * 8, paramPtr1.getDouble((Rinternals2.INTEGER(sEXP1).getInt(0 + j * 4) + -1) * 8));
      doublePtr2.setDouble(0 + j * 8, paramPtr2.getDouble((Rinternals2.INTEGER(sEXP1).getInt(0 + j * 4) + -1) * 8));
    } 
    polygonEdge(doublePtr3.pointerPlus(0), doublePtr2.pointerPlus(0), i, paramDouble, paramPtr3, paramPtr4);
  }
  
  public static int noChildren(SEXP paramSEXP) {
    Rinternals.Rf_protect(Rinternals.Rf_lang2(Rinternals.Rf_install(new BytePtr("no.children\000".getBytes(), 0)), paramSEXP));
    Rinternals.Rf_protect(Rinternals.Rf_eval(Rinternals.Rf_lang2(Rinternals.Rf_install(new BytePtr("no.children\000".getBytes(), 0)), paramSEXP), R_gridEvalEnv));
    return Rinternals.LOGICAL(Rinternals.Rf_eval(Rinternals.Rf_lang2(Rinternals.Rf_install(new BytePtr("no.children\000".getBytes(), 0)), paramSEXP), R_gridEvalEnv)).getInt();
  }
  
  public static int pathMatch(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3) {
    Rinternals.Rf_protect(Rinternals.Rf_lang4(Rinternals.Rf_install(new BytePtr("pathMatch\000".getBytes(), 0)), paramSEXP1, paramSEXP2, paramSEXP3));
    Rinternals.Rf_protect(Rinternals.Rf_eval(Rinternals.Rf_lang4(Rinternals.Rf_install(new BytePtr("pathMatch\000".getBytes(), 0)), paramSEXP1, paramSEXP2, paramSEXP3), R_gridEvalEnv));
    return Rinternals.LOGICAL(Rinternals.Rf_eval(Rinternals.Rf_lang4(Rinternals.Rf_install(new BytePtr("pathMatch\000".getBytes(), 0)), paramSEXP1, paramSEXP2, paramSEXP3), R_gridEvalEnv)).getInt();
  }
  
  public static void polygonEdge(Ptr paramPtr1, Ptr paramPtr2, int paramInt, double paramDouble, Ptr paramPtr3, Ptr paramPtr4) {
    double[] arrayOfDouble1 = new double[1];
    double[] arrayOfDouble2 = new double[1];
    arrayOfDouble1[0] = 0.0D;
    arrayOfDouble2[0] = 0.0D;
    int i = 0;
    byte b1 = 0;
    double d2 = Double.MAX_VALUE;
    double d3 = -1.7976931348623157E308D;
    double d4 = Double.MAX_VALUE;
    double d5 = -1.7976931348623157E308D;
    boolean bool = false;
    double d1 = paramDouble / 180.0D * Math.PI;
    byte b2;
    for (b2 = 0; b2 < paramInt; b2++) {
      if (paramPtr1.getDouble(b2 * 8) < d2)
        d2 = paramPtr1.getDouble(b2 * 8); 
      if (paramPtr1.getDouble(b2 * 8) > d3)
        d3 = paramPtr1.getDouble(b2 * 8); 
      if (paramPtr2.getDouble(b2 * 8) < d4)
        d4 = paramPtr2.getDouble(b2 * 8); 
      if (paramPtr2.getDouble(b2 * 8) > d5)
        d5 = paramPtr2.getDouble(b2 * 8); 
    } 
    double d6 = (d2 + d3) / 2.0D;
    double d7 = (d4 + d5) / 2.0D;
    if (Math.abs(d2 - d3) >= 1.0E-6D) {
      if (Math.abs(d4 - d5) >= 1.0E-6D) {
        b2 = 0;
        while (b2 < paramInt) {
          b1 = b2;
          i = b2 + 1;
          if (i == paramInt)
            i = 0; 
          double d10 = paramPtr1.getDouble(b1 * 8) - d6;
          d10 = Mathlib.atan2(paramPtr2.getDouble(b1 * 8) - d7, d10);
          if (d10 < 0.0D)
            d10 += 6.283185307179586D; 
          double d11 = paramPtr1.getDouble(i * 8) - d6;
          d11 = Mathlib.atan2(paramPtr2.getDouble(i * 8) - d7, d11);
          if (d11 < 0.0D)
            d11 += 6.283185307179586D; 
          if ((d10 < d11 || d10 < d1 || d11 >= d1) && (d10 >= d11 || ((d10 < d1 || d1 < 0.0D) && (d11 >= d1 || d1 > 6.283185307179586D)))) {
            b2++;
            continue;
          } 
          bool = true;
          break;
        } 
        if (!bool) {
          Error.Rf_error(GetText.dgettext(new BytePtr("grid\000".getBytes(), 0), new BytePtr("polygon edge not found\000".getBytes(), 0)), new Object[0]);
          return;
        } 
        double d9 = paramPtr1.getDouble(b1 * 8);
        double d8 = paramPtr2.getDouble(b1 * 8);
        d1 = paramPtr2.getDouble(i * 8);
        rectEdge(d2, d4, d3, d5, paramDouble, (Ptr)new DoublePtr(arrayOfDouble2, 0), (Ptr)new DoublePtr(arrayOfDouble1, 0));
        paramDouble = (paramPtr1.getDouble(i * 8) - d9) * (d7 - d8) - (d1 - d8) * (d6 - d9);
        d2 = (paramPtr1.getDouble(i * 8) - d9) * (arrayOfDouble1[0] - d7);
        paramDouble /= (d1 - d8) * (arrayOfDouble2[0] - d6) - d2;
        if (Arith.R_finite(paramDouble) == 0)
          Error.Rf_error(GetText.dgettext(new BytePtr("grid\000".getBytes(), 0), new BytePtr("polygon edge not found (zero-width or zero-height?)\000".getBytes(), 0)), new Object[0]); 
        paramPtr3.setDouble((arrayOfDouble2[0] - d6) * paramDouble + d6);
        paramPtr4.setDouble((arrayOfDouble1[0] - d7) * paramDouble + d7);
        return;
      } 
      paramPtr4.setDouble(d4);
      if (paramDouble != 0.0D) {
        if (paramDouble != 180.0D) {
          paramPtr3.setDouble(d6);
          return;
        } 
        paramPtr3.setDouble(d2);
        return;
      } 
      paramPtr3.setDouble(d3);
      return;
    } 
    paramPtr3.setDouble(d2);
    if (paramDouble != 90.0D) {
      if (paramDouble != 270.0D) {
        paramPtr4.setDouble(d7);
        return;
      } 
      paramPtr4.setDouble(d4);
      return;
    } 
    paramPtr4.setDouble(d5);
  }
  
  public static void rectEdge(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, Ptr paramPtr1, Ptr paramPtr2) {
    double d4 = (paramDouble1 + paramDouble3) / 2.0D;
    double d3 = (paramDouble2 + paramDouble4) / 2.0D;
    double d2 = (paramDouble3 - paramDouble1) / 2.0D;
    double d1 = (paramDouble4 - paramDouble2) / 2.0D;
    if (paramDouble5 != 0.0D) {
      if (paramDouble5 != 270.0D) {
        if (paramDouble5 != 180.0D) {
          if (paramDouble5 != 90.0D) {
            double d5 = paramDouble5 / 180.0D * Math.PI;
            double d6 = Mathlib.tan(d5);
            paramDouble5 = Mathlib.cos(d5);
            d5 = Mathlib.sin(d5);
            if (Math.abs(d6) >= d1 / d2) {
              if (d5 <= 0.0D) {
                paramPtr2.setDouble(paramDouble2);
                paramPtr1.setDouble(d4 - d1 / d6);
                return;
              } 
              paramPtr2.setDouble(paramDouble4);
              paramPtr1.setDouble(d1 / d6 + d4);
              return;
            } 
            if (paramDouble5 <= 0.0D) {
              paramPtr1.setDouble(paramDouble1);
              paramPtr2.setDouble(d3 - d6 * d2);
              return;
            } 
            paramPtr1.setDouble(paramDouble3);
            paramPtr2.setDouble(d6 * d2 + d3);
            return;
          } 
          paramPtr1.setDouble(d4);
          paramPtr2.setDouble(paramDouble4);
          return;
        } 
        paramPtr1.setDouble(paramDouble1);
        paramPtr2.setDouble(d3);
        return;
      } 
      paramPtr1.setDouble(d4);
      paramPtr2.setDouble(paramDouble2);
      return;
    } 
    paramPtr1.setDouble(paramDouble3);
    paramPtr2.setDouble(d3);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/grid-0.9.2724.jar!/org/renjin/grid/grid__.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */