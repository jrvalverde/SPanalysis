package org.renjin.grid;

import org.renjin.gcc.runtime.Ptr;
import org.renjin.primitives.packaging.DllInfo;
import org.renjin.sexp.SEXP;

public class grid {
  public static SEXP L_CreateSEXPPtr(SEXP paramSEXP) {
    return util__.L_CreateSEXPPtr(paramSEXP);
  }
  
  public static SEXP L_GetSEXPPtr(SEXP paramSEXP) {
    return util__.L_GetSEXPPtr(paramSEXP);
  }
  
  public static SEXP L_SetSEXPPtr(SEXP paramSEXP1, SEXP paramSEXP2) {
    return util__.L_SetSEXPPtr(paramSEXP1, paramSEXP2);
  }
  
  public static SEXP L_arrows(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4, SEXP paramSEXP5, SEXP paramSEXP6, SEXP paramSEXP7, SEXP paramSEXP8, SEXP paramSEXP9, SEXP paramSEXP10, SEXP paramSEXP11, SEXP paramSEXP12) {
    return grid__.L_arrows(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4, paramSEXP5, paramSEXP6, paramSEXP7, paramSEXP8, paramSEXP9, paramSEXP10, paramSEXP11, paramSEXP12);
  }
  
  public static SEXP L_cap() {
    return grid__.L_cap();
  }
  
  public static SEXP L_circle(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3) {
    return grid__.L_circle(paramSEXP1, paramSEXP2, paramSEXP3);
  }
  
  public static SEXP L_circleBounds(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4) {
    return grid__.L_circleBounds(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4);
  }
  
  public static SEXP L_clip(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4, SEXP paramSEXP5, SEXP paramSEXP6) {
    return grid__.L_clip(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4, paramSEXP5, paramSEXP6);
  }
  
  public static SEXP L_convert(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4) {
    return grid__.L_convert(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4);
  }
  
  public static SEXP L_currentGPar() {
    return grid__.L_currentGPar();
  }
  
  public static SEXP L_currentViewport() {
    return grid__.L_currentViewport();
  }
  
  public static SEXP L_downviewport(SEXP paramSEXP1, SEXP paramSEXP2) {
    return grid__.L_downviewport(paramSEXP1, paramSEXP2);
  }
  
  public static SEXP L_downvppath(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3) {
    return grid__.L_downvppath(paramSEXP1, paramSEXP2, paramSEXP3);
  }
  
  public static SEXP L_getCurrentGrob() {
    return grid__.L_getCurrentGrob();
  }
  
  public static SEXP L_getDLelt(SEXP paramSEXP) {
    return grid__.L_getDLelt(paramSEXP);
  }
  
  public static SEXP L_getDLindex() {
    return grid__.L_getDLindex();
  }
  
  public static SEXP L_getDLon() {
    return grid__.L_getDLon();
  }
  
  public static SEXP L_getDisplayList() {
    return grid__.L_getDisplayList();
  }
  
  public static SEXP L_getEngineDLon() {
    return grid__.L_getEngineDLon();
  }
  
  public static SEXP L_getEngineRecording() {
    return grid__.L_getEngineRecording();
  }
  
  public static SEXP L_getGPar() {
    return gpar__.L_getGPar();
  }
  
  public static SEXP L_getGPsaved() {
    return gpar__.L_getGPsaved();
  }
  
  public static SEXP L_gridDirty() {
    return grid__.L_gridDirty();
  }
  
  public static SEXP L_initDisplayList() {
    return grid__.L_initDisplayList();
  }
  
  public static SEXP L_initGPar() {
    return grid__.L_initGPar();
  }
  
  public static SEXP L_initGrid(SEXP paramSEXP) {
    return grid__.L_initGrid(paramSEXP);
  }
  
  public static SEXP L_initViewportStack() {
    return grid__.L_initViewportStack();
  }
  
  public static SEXP L_killGrid() {
    return grid__.L_killGrid();
  }
  
  public static SEXP L_layoutRegion(SEXP paramSEXP1, SEXP paramSEXP2) {
    return grid__.L_layoutRegion(paramSEXP1, paramSEXP2);
  }
  
  public static SEXP L_lineTo(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3) {
    return grid__.L_lineTo(paramSEXP1, paramSEXP2, paramSEXP3);
  }
  
  public static SEXP L_lines(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4) {
    return grid__.L_lines(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4);
  }
  
  public static SEXP L_locator() {
    return grid__.L_locator();
  }
  
  public static SEXP L_locnBounds(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3) {
    return grid__.L_locnBounds(paramSEXP1, paramSEXP2, paramSEXP3);
  }
  
  public static SEXP L_moveTo(SEXP paramSEXP1, SEXP paramSEXP2) {
    return grid__.L_moveTo(paramSEXP1, paramSEXP2);
  }
  
  public static SEXP L_newpage() {
    return grid__.L_newpage();
  }
  
  public static SEXP L_newpagerecording() {
    return grid__.L_newpagerecording();
  }
  
  public static SEXP L_path(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4) {
    return grid__.L_path(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4);
  }
  
  public static SEXP L_points(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4) {
    return grid__.L_points(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4);
  }
  
  public static SEXP L_polygon(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3) {
    return grid__.L_polygon(paramSEXP1, paramSEXP2, paramSEXP3);
  }
  
  public static SEXP L_pretty(SEXP paramSEXP) {
    return grid__.L_pretty(paramSEXP);
  }
  
  public static SEXP L_raster(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4, SEXP paramSEXP5, SEXP paramSEXP6, SEXP paramSEXP7, SEXP paramSEXP8) {
    return grid__.L_raster(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4, paramSEXP5, paramSEXP6, paramSEXP7, paramSEXP8);
  }
  
  public static SEXP L_rect(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4, SEXP paramSEXP5, SEXP paramSEXP6) {
    return grid__.L_rect(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4, paramSEXP5, paramSEXP6);
  }
  
  public static SEXP L_rectBounds(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4, SEXP paramSEXP5, SEXP paramSEXP6, SEXP paramSEXP7) {
    return grid__.L_rectBounds(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4, paramSEXP5, paramSEXP6, paramSEXP7);
  }
  
  public static SEXP L_segments(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4, SEXP paramSEXP5) {
    return grid__.L_segments(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4, paramSEXP5);
  }
  
  public static SEXP L_setCurrentGrob(SEXP paramSEXP) {
    return grid__.L_setCurrentGrob(paramSEXP);
  }
  
  public static SEXP L_setDLelt(SEXP paramSEXP) {
    return grid__.L_setDLelt(paramSEXP);
  }
  
  public static SEXP L_setDLindex(SEXP paramSEXP) {
    return grid__.L_setDLindex(paramSEXP);
  }
  
  public static SEXP L_setDLon(SEXP paramSEXP) {
    return grid__.L_setDLon(paramSEXP);
  }
  
  public static SEXP L_setDisplayList(SEXP paramSEXP) {
    return grid__.L_setDisplayList(paramSEXP);
  }
  
  public static SEXP L_setEngineDLon(SEXP paramSEXP) {
    return grid__.L_setEngineDLon(paramSEXP);
  }
  
  public static SEXP L_setEngineRecording(SEXP paramSEXP) {
    return grid__.L_setEngineRecording(paramSEXP);
  }
  
  public static SEXP L_setGPar(SEXP paramSEXP) {
    return gpar__.L_setGPar(paramSEXP);
  }
  
  public static SEXP L_setGPsaved(SEXP paramSEXP) {
    return gpar__.L_setGPsaved(paramSEXP);
  }
  
  public static SEXP L_setviewport(SEXP paramSEXP1, SEXP paramSEXP2) {
    return grid__.L_setviewport(paramSEXP1, paramSEXP2);
  }
  
  public static SEXP L_stringMetric(SEXP paramSEXP) {
    return grid__.L_stringMetric(paramSEXP);
  }
  
  public static SEXP L_text(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4, SEXP paramSEXP5, SEXP paramSEXP6, SEXP paramSEXP7) {
    return grid__.L_text(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4, paramSEXP5, paramSEXP6, paramSEXP7);
  }
  
  public static SEXP L_textBounds(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4, SEXP paramSEXP5, SEXP paramSEXP6, SEXP paramSEXP7) {
    return grid__.L_textBounds(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4, paramSEXP5, paramSEXP6, paramSEXP7);
  }
  
  public static SEXP L_unsetviewport(SEXP paramSEXP) {
    return grid__.L_unsetviewport(paramSEXP);
  }
  
  public static SEXP L_upviewport(SEXP paramSEXP) {
    return grid__.L_upviewport(paramSEXP);
  }
  
  public static SEXP L_xspline(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4, SEXP paramSEXP5, SEXP paramSEXP6, SEXP paramSEXP7) {
    return grid__.L_xspline(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4, paramSEXP5, paramSEXP6, paramSEXP7);
  }
  
  public static SEXP L_xsplineBounds(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4, SEXP paramSEXP5, SEXP paramSEXP6, SEXP paramSEXP7, SEXP paramSEXP8) {
    return grid__.L_xsplineBounds(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4, paramSEXP5, paramSEXP6, paramSEXP7, paramSEXP8);
  }
  
  public static SEXP L_xsplinePoints(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4, SEXP paramSEXP5, SEXP paramSEXP6, SEXP paramSEXP7, SEXP paramSEXP8) {
    return grid__.L_xsplinePoints(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4, paramSEXP5, paramSEXP6, paramSEXP7, paramSEXP8);
  }
  
  public static void R_init_grid(DllInfo paramDllInfo) {
    register__.R_init_grid(paramDllInfo);
  }
  
  public static int addOp(SEXP paramSEXP) {
    return unit__.addOp(paramSEXP);
  }
  
  public static void allocateKnownHeights(SEXP paramSEXP, Ptr paramPtr1, double paramDouble1, double paramDouble2, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6) {
    layout__.allocateKnownHeights(paramSEXP, paramPtr1, paramDouble1, paramDouble2, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramPtr6);
  }
  
  public static void allocateKnownWidths(SEXP paramSEXP, Ptr paramPtr1, double paramDouble1, double paramDouble2, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6) {
    layout__.allocateKnownWidths(paramSEXP, paramPtr1, paramDouble1, paramDouble2, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramPtr6);
  }
  
  public static void allocateRemainingHeight(SEXP paramSEXP, Ptr paramPtr1, double paramDouble, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5) {
    layout__.allocateRemainingHeight(paramSEXP, paramPtr1, paramDouble, paramPtr2, paramPtr3, paramPtr4, paramPtr5);
  }
  
  public static void allocateRemainingWidth(SEXP paramSEXP, Ptr paramPtr1, double paramDouble, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5) {
    layout__.allocateRemainingWidth(paramSEXP, paramPtr1, paramDouble, paramPtr2, paramPtr3, paramPtr4, paramPtr5);
  }
  
  public static void allocateRespected(SEXP paramSEXP, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9) {
    layout__.allocateRespected(paramSEXP, paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramPtr6, paramPtr7, paramPtr8, paramPtr9);
  }
  
  public static SEXP arg1(SEXP paramSEXP) {
    return unit__.arg1(paramSEXP);
  }
  
  public static SEXP arg2(SEXP paramSEXP) {
    return unit__.arg2(paramSEXP);
  }
  
  public static void calcViewportLayout(SEXP paramSEXP, double paramDouble1, double paramDouble2, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3) {
    layout__.calcViewportLayout(paramSEXP, paramDouble1, paramDouble2, paramPtr1, paramPtr2, paramPtr3);
  }
  
  public static void calcViewportLocationFromLayout(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, Ptr paramPtr) {
    layout__.calcViewportLocationFromLayout(paramSEXP1, paramSEXP2, paramSEXP3, paramPtr);
  }
  
  public static void calcViewportTransform(SEXP paramSEXP1, SEXP paramSEXP2, int paramInt, Ptr paramPtr) {
    viewport__.calcViewportTransform(paramSEXP1, paramSEXP2, paramInt, paramPtr);
  }
  
  public static int checkPosRowPosCol(SEXP paramSEXP1, SEXP paramSEXP2) {
    return layout__.checkPosRowPosCol(paramSEXP1, paramSEXP2);
  }
  
  public static int colRespected(int paramInt, SEXP paramSEXP) {
    return layout__.colRespected(paramInt, paramSEXP);
  }
  
  public static double convertJust(int paramInt) {
    return just__.convertJust(paramInt);
  }
  
  public static int convertUnit(SEXP paramSEXP, int paramInt) {
    return unit__.convertUnit(paramSEXP, paramInt);
  }
  
  public static void copyRect(Ptr paramPtr1, Ptr paramPtr2) {
    util__.copyRect(paramPtr1, paramPtr2);
  }
  
  public static void copyTransform(Ptr paramPtr1, Ptr paramPtr2) {
    matrix__.copyTransform(paramPtr1, paramPtr2);
  }
  
  public static void copyViewportContext(Ptr paramPtr1, Ptr paramPtr2) {
    viewport__.copyViewportContext(paramPtr1, paramPtr2);
  }
  
  public static SEXP createGridSystemState() {
    return state__.createGridSystemState();
  }
  
  public static void dirtyGridDevice(Ptr paramPtr) {
    grid__.dirtyGridDevice(paramPtr);
  }
  
  public static SEXP doSetViewport(SEXP paramSEXP, int paramInt1, int paramInt2, Ptr paramPtr) {
    return grid__.doSetViewport(paramSEXP, paramInt1, paramInt2, paramPtr);
  }
  
  public static int edgesIntersect(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, Ptr paramPtr) {
    return util__.edgesIntersect(paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramPtr);
  }
  
  public static double evaluateGrobAscentUnit(SEXP paramSEXP, double paramDouble1, double paramDouble2, int paramInt1, int paramInt2, Ptr paramPtr) {
    return unit__.evaluateGrobAscentUnit(paramSEXP, paramDouble1, paramDouble2, paramInt1, paramInt2, paramPtr);
  }
  
  public static double evaluateGrobDescentUnit(SEXP paramSEXP, double paramDouble1, double paramDouble2, int paramInt1, int paramInt2, Ptr paramPtr) {
    return unit__.evaluateGrobDescentUnit(paramSEXP, paramDouble1, paramDouble2, paramInt1, paramInt2, paramPtr);
  }
  
  public static double evaluateGrobHeightUnit(SEXP paramSEXP, double paramDouble1, double paramDouble2, int paramInt1, int paramInt2, Ptr paramPtr) {
    return unit__.evaluateGrobHeightUnit(paramSEXP, paramDouble1, paramDouble2, paramInt1, paramInt2, paramPtr);
  }
  
  public static double evaluateGrobUnit(double paramDouble1, SEXP paramSEXP, double paramDouble2, double paramDouble3, int paramInt1, int paramInt2, int paramInt3, Ptr paramPtr) {
    return unit__.evaluateGrobUnit(paramDouble1, paramSEXP, paramDouble2, paramDouble3, paramInt1, paramInt2, paramInt3, paramPtr);
  }
  
  public static double evaluateGrobWidthUnit(SEXP paramSEXP, double paramDouble1, double paramDouble2, int paramInt1, int paramInt2, Ptr paramPtr) {
    return unit__.evaluateGrobWidthUnit(paramSEXP, paramDouble1, paramDouble2, paramInt1, paramInt2, paramPtr);
  }
  
  public static double evaluateGrobXUnit(double paramDouble1, SEXP paramSEXP, double paramDouble2, double paramDouble3, int paramInt1, int paramInt2, Ptr paramPtr) {
    return unit__.evaluateGrobXUnit(paramDouble1, paramSEXP, paramDouble2, paramDouble3, paramInt1, paramInt2, paramPtr);
  }
  
  public static double evaluateGrobYUnit(double paramDouble1, SEXP paramSEXP, double paramDouble2, double paramDouble3, int paramInt1, int paramInt2, Ptr paramPtr) {
    return unit__.evaluateGrobYUnit(paramDouble1, paramSEXP, paramDouble2, paramDouble3, paramInt1, paramInt2, paramPtr);
  }
  
  public static Ptr fName(SEXP paramSEXP) {
    return unit__.fName(paramSEXP);
  }
  
  public static int fNameMatch(SEXP paramSEXP, Ptr paramPtr) {
    return unit__.fNameMatch(paramSEXP, paramPtr);
  }
  
  public static int fOp(SEXP paramSEXP) {
    return unit__.fOp(paramSEXP);
  }
  
  public static void fillGridSystemState(SEXP paramSEXP, Ptr paramPtr) {
    state__.fillGridSystemState(paramSEXP, paramPtr);
  }
  
  public static void fillViewportContextFromViewport(SEXP paramSEXP, Ptr paramPtr) {
    viewport__.fillViewportContextFromViewport(paramSEXP, paramPtr);
  }
  
  public static void fillViewportLocationFromViewport(SEXP paramSEXP, Ptr paramPtr) {
    viewport__.fillViewportLocationFromViewport(paramSEXP, paramPtr);
  }
  
  public static void findRelHeights(SEXP paramSEXP, Ptr paramPtr1, Ptr paramPtr2) {
    layout__.findRelHeights(paramSEXP, paramPtr1, paramPtr2);
  }
  
  public static void findRelWidths(SEXP paramSEXP, Ptr paramPtr1, Ptr paramPtr2) {
    layout__.findRelWidths(paramSEXP, paramPtr1, paramPtr2);
  }
  
  public static void gcontextFromViewport(SEXP paramSEXP, Ptr paramPtr1, Ptr paramPtr2) {
    viewport__.gcontextFromViewport(paramSEXP, paramPtr1, paramPtr2);
  }
  
  public static void gcontextFromgpar(SEXP paramSEXP, int paramInt, Ptr paramPtr1, Ptr paramPtr2) {
    gpar__.gcontextFromgpar(paramSEXP, paramInt, paramPtr1, paramPtr2);
  }
  
  public static Ptr getDevice() {
    return grid__.getDevice();
  }
  
  public static void getDeviceSize(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3) {
    grid__.getDeviceSize(paramPtr1, paramPtr2, paramPtr3);
  }
  
  public static SEXP getListElement(SEXP paramSEXP, Ptr paramPtr) {
    return util__.getListElement(paramSEXP, paramPtr);
  }
  
  public static void getViewportContext(SEXP paramSEXP, Ptr paramPtr) {
    grid__.getViewportContext(paramSEXP, paramPtr);
  }
  
  public static void getViewportTransform(SEXP paramSEXP, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5) {
    grid__.getViewportTransform(paramSEXP, paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5);
  }
  
  public static double gpAlpha(SEXP paramSEXP, int paramInt) {
    return gpar__.gpAlpha(paramSEXP, paramInt);
  }
  
  public static SEXP gpAlphaSXP(SEXP paramSEXP) {
    return gpar__.gpAlphaSXP(paramSEXP);
  }
  
  public static double gpCex(SEXP paramSEXP, int paramInt) {
    return gpar__.gpCex(paramSEXP, paramInt);
  }
  
  public static SEXP gpCexSXP(SEXP paramSEXP) {
    return gpar__.gpCexSXP(paramSEXP);
  }
  
  public static int gpCol(SEXP paramSEXP, int paramInt) {
    return gpar__.gpCol(paramSEXP, paramInt);
  }
  
  public static int gpFill(SEXP paramSEXP, int paramInt) {
    return gpar__.gpFill(paramSEXP, paramInt);
  }
  
  public static SEXP gpFillSXP(SEXP paramSEXP) {
    return gpar__.gpFillSXP(paramSEXP);
  }
  
  public static int gpFont(SEXP paramSEXP, int paramInt) {
    return gpar__.gpFont(paramSEXP, paramInt);
  }
  
  public static Ptr gpFontFamily(SEXP paramSEXP, int paramInt) {
    return gpar__.gpFontFamily(paramSEXP, paramInt);
  }
  
  public static SEXP gpFontFamilySXP(SEXP paramSEXP) {
    return gpar__.gpFontFamilySXP(paramSEXP);
  }
  
  public static SEXP gpFontSXP(SEXP paramSEXP) {
    return gpar__.gpFontSXP(paramSEXP);
  }
  
  public static double gpFontSize(SEXP paramSEXP, int paramInt) {
    return gpar__.gpFontSize(paramSEXP, paramInt);
  }
  
  public static SEXP gpFontSizeSXP(SEXP paramSEXP) {
    return gpar__.gpFontSizeSXP(paramSEXP);
  }
  
  public static double gpGamma(SEXP paramSEXP, int paramInt) {
    return gpar__.gpGamma(paramSEXP, paramInt);
  }
  
  public static SEXP gpGammaSXP(SEXP paramSEXP) {
    return gpar__.gpGammaSXP(paramSEXP);
  }
  
  public static double gpLex(SEXP paramSEXP, int paramInt) {
    return gpar__.gpLex(paramSEXP, paramInt);
  }
  
  public static SEXP gpLexSXP(SEXP paramSEXP) {
    return gpar__.gpLexSXP(paramSEXP);
  }
  
  public static int gpLineEnd(SEXP paramSEXP, int paramInt) {
    return gpar__.gpLineEnd(paramSEXP, paramInt);
  }
  
  public static SEXP gpLineEndSXP(SEXP paramSEXP) {
    return gpar__.gpLineEndSXP(paramSEXP);
  }
  
  public static double gpLineHeight(SEXP paramSEXP, int paramInt) {
    return gpar__.gpLineHeight(paramSEXP, paramInt);
  }
  
  public static SEXP gpLineHeightSXP(SEXP paramSEXP) {
    return gpar__.gpLineHeightSXP(paramSEXP);
  }
  
  public static int gpLineJoin(SEXP paramSEXP, int paramInt) {
    return gpar__.gpLineJoin(paramSEXP, paramInt);
  }
  
  public static SEXP gpLineJoinSXP(SEXP paramSEXP) {
    return gpar__.gpLineJoinSXP(paramSEXP);
  }
  
  public static double gpLineMitre(SEXP paramSEXP, int paramInt) {
    return gpar__.gpLineMitre(paramSEXP, paramInt);
  }
  
  public static SEXP gpLineMitreSXP(SEXP paramSEXP) {
    return gpar__.gpLineMitreSXP(paramSEXP);
  }
  
  public static int gpLineType(SEXP paramSEXP, int paramInt) {
    return gpar__.gpLineType(paramSEXP, paramInt);
  }
  
  public static SEXP gpLineTypeSXP(SEXP paramSEXP) {
    return gpar__.gpLineTypeSXP(paramSEXP);
  }
  
  public static double gpLineWidth(SEXP paramSEXP, int paramInt) {
    return gpar__.gpLineWidth(paramSEXP, paramInt);
  }
  
  public static SEXP gpLineWidthSXP(SEXP paramSEXP) {
    return gpar__.gpLineWidthSXP(paramSEXP);
  }
  
  public static SEXP gridCallback(int paramInt, Ptr paramPtr, SEXP paramSEXP) {
    return state__.gridCallback(paramInt, paramPtr, paramSEXP);
  }
  
  public static SEXP gridStateElement(Ptr paramPtr, int paramInt) {
    return state__.gridStateElement(paramPtr, paramInt);
  }
  
  public static SEXP gridXspline(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4, SEXP paramSEXP5, SEXP paramSEXP6, SEXP paramSEXP7, double paramDouble, int paramInt1, int paramInt2) {
    return grid__.gridXspline(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4, paramSEXP5, paramSEXP6, paramSEXP7, paramDouble, paramInt1, paramInt2);
  }
  
  public static void identity(Ptr paramPtr) {
    matrix__.identity(paramPtr);
  }
  
  public static void initDL(Ptr paramPtr) {
    state__.initDL(paramPtr);
  }
  
  public static void initGPar(Ptr paramPtr) {
    gpar__.initGPar(paramPtr);
  }
  
  public static void initOtherState(Ptr paramPtr) {
    state__.initOtherState(paramPtr);
  }
  
  public static void initVP(Ptr paramPtr) {
    viewport__.initVP(paramPtr);
  }
  
  public static int intersect(Ptr paramPtr1, Ptr paramPtr2) {
    return util__.intersect(paramPtr1, paramPtr2);
  }
  
  public static void invTransform(Ptr paramPtr1, Ptr paramPtr2) {
    matrix__.invTransform(paramPtr1, paramPtr2);
  }
  
  public static int isUnitArithmetic(SEXP paramSEXP) {
    return unit__.isUnitArithmetic(paramSEXP);
  }
  
  public static int isUnitList(SEXP paramSEXP) {
    return unit__.isUnitList(paramSEXP);
  }
  
  public static void justification(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, Ptr paramPtr1, Ptr paramPtr2) {
    just__.justification(paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramPtr1, paramPtr2);
  }
  
  public static double justifyX(double paramDouble1, double paramDouble2, double paramDouble3) {
    return just__.justifyX(paramDouble1, paramDouble2, paramDouble3);
  }
  
  public static double justifyY(double paramDouble1, double paramDouble2, double paramDouble3) {
    return just__.justifyY(paramDouble1, paramDouble2, paramDouble3);
  }
  
  public static double layoutHJust(SEXP paramSEXP) {
    return layout__.layoutHJust(paramSEXP);
  }
  
  public static SEXP layoutHeights(SEXP paramSEXP) {
    return layout__.layoutHeights(paramSEXP);
  }
  
  public static int layoutNCol(SEXP paramSEXP) {
    return layout__.layoutNCol(paramSEXP);
  }
  
  public static int layoutNRow(SEXP paramSEXP) {
    return layout__.layoutNRow(paramSEXP);
  }
  
  public static int layoutRespect(SEXP paramSEXP) {
    return layout__.layoutRespect(paramSEXP);
  }
  
  public static Ptr layoutRespectMat(SEXP paramSEXP) {
    return layout__.layoutRespectMat(paramSEXP);
  }
  
  public static double layoutVJust(SEXP paramSEXP) {
    return layout__.layoutVJust(paramSEXP);
  }
  
  public static SEXP layoutWidths(SEXP paramSEXP) {
    return layout__.layoutWidths(paramSEXP);
  }
  
  public static int linesIntersect(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, double paramDouble7, double paramDouble8) {
    return util__.linesIntersect(paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5, paramDouble6, paramDouble7, paramDouble8);
  }
  
  public static void location(double paramDouble1, double paramDouble2, Ptr paramPtr) {
    matrix__.location(paramDouble1, paramDouble2, paramPtr);
  }
  
  public static double locationX(Ptr paramPtr) {
    return matrix__.locationX(paramPtr);
  }
  
  public static double locationY(Ptr paramPtr) {
    return matrix__.locationY(paramPtr);
  }
  
  public static int maxFunc(SEXP paramSEXP) {
    return unit__.maxFunc(paramSEXP);
  }
  
  public static int minFunc(SEXP paramSEXP) {
    return unit__.minFunc(paramSEXP);
  }
  
  public static int minusOp(SEXP paramSEXP) {
    return unit__.minusOp(paramSEXP);
  }
  
  public static void multiply(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3) {
    matrix__.multiply(paramPtr1, paramPtr2, paramPtr3);
  }
  
  public static double numeric(SEXP paramSEXP, int paramInt) {
    return util__.numeric(paramSEXP, paramInt);
  }
  
  public static int pureNullUnit(SEXP paramSEXP, int paramInt, Ptr paramPtr) {
    return unit__.pureNullUnit(paramSEXP, paramInt, paramPtr);
  }
  
  public static int pureNullUnitArithmetic(SEXP paramSEXP, int paramInt, Ptr paramPtr) {
    return unit__.pureNullUnitArithmetic(paramSEXP, paramInt, paramPtr);
  }
  
  public static double pureNullUnitValue(SEXP paramSEXP, int paramInt) {
    return unit__.pureNullUnitValue(paramSEXP, paramInt);
  }
  
  public static void rect(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, double paramDouble7, double paramDouble8, Ptr paramPtr) {
    util__.rect(paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5, paramDouble6, paramDouble7, paramDouble8, paramPtr);
  }
  
  public static int relativeUnit(SEXP paramSEXP, int paramInt, Ptr paramPtr) {
    return layout__.relativeUnit(paramSEXP, paramInt, paramPtr);
  }
  
  public static void rotation(double paramDouble, Ptr paramPtr) {
    matrix__.rotation(paramDouble, paramPtr);
  }
  
  public static int rowRespected(int paramInt, SEXP paramSEXP) {
    return layout__.rowRespected(paramInt, paramSEXP);
  }
  
  public static void scaling(double paramDouble1, double paramDouble2, Ptr paramPtr) {
    matrix__.scaling(paramDouble1, paramDouble2, paramPtr);
  }
  
  public static void setGridStateElement(Ptr paramPtr, int paramInt, SEXP paramSEXP) {
    state__.setGridStateElement(paramPtr, paramInt, paramSEXP);
  }
  
  public static void setListElement(SEXP paramSEXP1, Ptr paramPtr, SEXP paramSEXP2) {
    util__.setListElement(paramSEXP1, paramPtr, paramSEXP2);
  }
  
  public static void setRemainingHeightZero(SEXP paramSEXP, Ptr paramPtr1, Ptr paramPtr2) {
    layout__.setRemainingHeightZero(paramSEXP, paramPtr1, paramPtr2);
  }
  
  public static void setRemainingWidthZero(SEXP paramSEXP, Ptr paramPtr1, Ptr paramPtr2) {
    layout__.setRemainingWidthZero(paramSEXP, paramPtr1, paramPtr2);
  }
  
  public static void setRespectedZero(SEXP paramSEXP, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4) {
    layout__.setRespectedZero(paramSEXP, paramPtr1, paramPtr2, paramPtr3, paramPtr4);
  }
  
  public static int sumFunc(SEXP paramSEXP) {
    return unit__.sumFunc(paramSEXP);
  }
  
  public static void textRect(double paramDouble1, double paramDouble2, SEXP paramSEXP, int paramInt, Ptr paramPtr1, double paramDouble3, double paramDouble4, double paramDouble5, Ptr paramPtr2, Ptr paramPtr3) {
    util__.textRect(paramDouble1, paramDouble2, paramSEXP, paramInt, paramPtr1, paramDouble3, paramDouble4, paramDouble5, paramPtr2, paramPtr3);
  }
  
  public static int timesOp(SEXP paramSEXP) {
    return unit__.timesOp(paramSEXP);
  }
  
  public static double totalHeight(SEXP paramSEXP, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4) {
    return layout__.totalHeight(paramSEXP, paramPtr1, paramPtr2, paramPtr3, paramPtr4);
  }
  
  public static double totalUnrespectedHeight(SEXP paramSEXP, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4) {
    return layout__.totalUnrespectedHeight(paramSEXP, paramPtr1, paramPtr2, paramPtr3, paramPtr4);
  }
  
  public static double totalUnrespectedWidth(SEXP paramSEXP, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4) {
    return layout__.totalUnrespectedWidth(paramSEXP, paramPtr1, paramPtr2, paramPtr3, paramPtr4);
  }
  
  public static double totalWidth(SEXP paramSEXP, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4) {
    return layout__.totalWidth(paramSEXP, paramPtr1, paramPtr2, paramPtr3, paramPtr4);
  }
  
  public static void trans(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3) {
    matrix__.trans(paramPtr1, paramPtr2, paramPtr3);
  }
  
  public static double transform(double paramDouble1, int paramInt1, SEXP paramSEXP, double paramDouble2, double paramDouble3, Ptr paramPtr1, double paramDouble4, double paramDouble5, int paramInt2, int paramInt3, Ptr paramPtr2) {
    return unit__.transform(paramDouble1, paramInt1, paramSEXP, paramDouble2, paramDouble3, paramPtr1, paramDouble4, paramDouble5, paramInt2, paramInt3, paramPtr2);
  }
  
  public static double transformDimension(double paramDouble1, int paramInt1, SEXP paramSEXP, double paramDouble2, double paramDouble3, Ptr paramPtr1, double paramDouble4, double paramDouble5, int paramInt2, int paramInt3, Ptr paramPtr2) {
    return unit__.transformDimension(paramDouble1, paramInt1, paramSEXP, paramDouble2, paramDouble3, paramPtr1, paramDouble4, paramDouble5, paramInt2, paramInt3, paramPtr2);
  }
  
  public static void transformDimn(SEXP paramSEXP1, SEXP paramSEXP2, int paramInt, Ptr paramPtr1, Ptr paramPtr2, double paramDouble1, double paramDouble2, Ptr paramPtr3, double paramDouble3, Ptr paramPtr4, Ptr paramPtr5) {
    unit__.transformDimn(paramSEXP1, paramSEXP2, paramInt, paramPtr1, paramPtr2, paramDouble1, paramDouble2, paramPtr3, paramDouble3, paramPtr4, paramPtr5);
  }
  
  public static double transformFromINCHES(double paramDouble1, int paramInt, Ptr paramPtr1, double paramDouble2, double paramDouble3, Ptr paramPtr2) {
    return unit__.transformFromINCHES(paramDouble1, paramInt, paramPtr1, paramDouble2, paramDouble3, paramPtr2);
  }
  
  public static double transformHeight(SEXP paramSEXP, int paramInt1, Ptr paramPtr1, Ptr paramPtr2, double paramDouble1, double paramDouble2, int paramInt2, int paramInt3, Ptr paramPtr3) {
    return unit__.transformHeight(paramSEXP, paramInt1, paramPtr1, paramPtr2, paramDouble1, paramDouble2, paramInt2, paramInt3, paramPtr3);
  }
  
  public static double transformHeightArithmetic(SEXP paramSEXP, int paramInt1, Ptr paramPtr1, Ptr paramPtr2, double paramDouble1, double paramDouble2, int paramInt2, Ptr paramPtr3) {
    return unit__.transformHeightArithmetic(paramSEXP, paramInt1, paramPtr1, paramPtr2, paramDouble1, paramDouble2, paramInt2, paramPtr3);
  }
  
  public static double transformHeighttoINCHES(SEXP paramSEXP, int paramInt, Ptr paramPtr1, Ptr paramPtr2, double paramDouble1, double paramDouble2, Ptr paramPtr3) {
    return unit__.transformHeighttoINCHES(paramSEXP, paramInt, paramPtr1, paramPtr2, paramDouble1, paramDouble2, paramPtr3);
  }
  
  public static double transformLocation(double paramDouble1, int paramInt1, SEXP paramSEXP, double paramDouble2, double paramDouble3, Ptr paramPtr1, double paramDouble4, double paramDouble5, int paramInt2, int paramInt3, Ptr paramPtr2) {
    return unit__.transformLocation(paramDouble1, paramInt1, paramSEXP, paramDouble2, paramDouble3, paramPtr1, paramDouble4, paramDouble5, paramInt2, paramInt3, paramPtr2);
  }
  
  public static void transformLocn(SEXP paramSEXP1, SEXP paramSEXP2, int paramInt, Ptr paramPtr1, Ptr paramPtr2, double paramDouble1, double paramDouble2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6) {
    unit__.transformLocn(paramSEXP1, paramSEXP2, paramInt, paramPtr1, paramPtr2, paramDouble1, paramDouble2, paramPtr3, paramPtr4, paramPtr5, paramPtr6);
  }
  
  public static double transformWHfromNPC(double paramDouble1, int paramInt, double paramDouble2, double paramDouble3) {
    return unit__.transformWHfromNPC(paramDouble1, paramInt, paramDouble2, paramDouble3);
  }
  
  public static double transformWHtoNPC(double paramDouble1, int paramInt, double paramDouble2, double paramDouble3) {
    return unit__.transformWHtoNPC(paramDouble1, paramInt, paramDouble2, paramDouble3);
  }
  
  public static double transformWidth(SEXP paramSEXP, int paramInt1, Ptr paramPtr1, Ptr paramPtr2, double paramDouble1, double paramDouble2, int paramInt2, int paramInt3, Ptr paramPtr3) {
    return unit__.transformWidth(paramSEXP, paramInt1, paramPtr1, paramPtr2, paramDouble1, paramDouble2, paramInt2, paramInt3, paramPtr3);
  }
  
  public static double transformWidthArithmetic(SEXP paramSEXP, int paramInt1, Ptr paramPtr1, Ptr paramPtr2, double paramDouble1, double paramDouble2, int paramInt2, Ptr paramPtr3) {
    return unit__.transformWidthArithmetic(paramSEXP, paramInt1, paramPtr1, paramPtr2, paramDouble1, paramDouble2, paramInt2, paramPtr3);
  }
  
  public static double transformWidthHeightFromINCHES(double paramDouble1, int paramInt, double paramDouble2, double paramDouble3, Ptr paramPtr1, double paramDouble4, double paramDouble5, Ptr paramPtr2) {
    return unit__.transformWidthHeightFromINCHES(paramDouble1, paramInt, paramDouble2, paramDouble3, paramPtr1, paramDouble4, paramDouble5, paramPtr2);
  }
  
  public static double transformWidthtoINCHES(SEXP paramSEXP, int paramInt, Ptr paramPtr1, Ptr paramPtr2, double paramDouble1, double paramDouble2, Ptr paramPtr3) {
    return unit__.transformWidthtoINCHES(paramSEXP, paramInt, paramPtr1, paramPtr2, paramDouble1, paramDouble2, paramPtr3);
  }
  
  public static double transformX(SEXP paramSEXP, int paramInt1, Ptr paramPtr1, Ptr paramPtr2, double paramDouble1, double paramDouble2, int paramInt2, int paramInt3, Ptr paramPtr3) {
    return unit__.transformX(paramSEXP, paramInt1, paramPtr1, paramPtr2, paramDouble1, paramDouble2, paramInt2, paramInt3, paramPtr3);
  }
  
  public static double transformXArithmetic(SEXP paramSEXP, int paramInt1, Ptr paramPtr1, Ptr paramPtr2, double paramDouble1, double paramDouble2, int paramInt2, Ptr paramPtr3) {
    return unit__.transformXArithmetic(paramSEXP, paramInt1, paramPtr1, paramPtr2, paramDouble1, paramDouble2, paramInt2, paramPtr3);
  }
  
  public static double transformXYFromINCHES(double paramDouble1, int paramInt, double paramDouble2, double paramDouble3, Ptr paramPtr1, double paramDouble4, double paramDouble5, Ptr paramPtr2) {
    return unit__.transformXYFromINCHES(paramDouble1, paramInt, paramDouble2, paramDouble3, paramPtr1, paramDouble4, paramDouble5, paramPtr2);
  }
  
  public static double transformXYfromNPC(double paramDouble1, int paramInt, double paramDouble2, double paramDouble3) {
    return unit__.transformXYfromNPC(paramDouble1, paramInt, paramDouble2, paramDouble3);
  }
  
  public static double transformXYtoNPC(double paramDouble1, int paramInt, double paramDouble2, double paramDouble3) {
    return unit__.transformXYtoNPC(paramDouble1, paramInt, paramDouble2, paramDouble3);
  }
  
  public static double transformXtoINCHES(SEXP paramSEXP, int paramInt, Ptr paramPtr1, Ptr paramPtr2, double paramDouble1, double paramDouble2, Ptr paramPtr3) {
    return unit__.transformXtoINCHES(paramSEXP, paramInt, paramPtr1, paramPtr2, paramDouble1, paramDouble2, paramPtr3);
  }
  
  public static double transformY(SEXP paramSEXP, int paramInt1, Ptr paramPtr1, Ptr paramPtr2, double paramDouble1, double paramDouble2, int paramInt2, int paramInt3, Ptr paramPtr3) {
    return unit__.transformY(paramSEXP, paramInt1, paramPtr1, paramPtr2, paramDouble1, paramDouble2, paramInt2, paramInt3, paramPtr3);
  }
  
  public static double transformYArithmetic(SEXP paramSEXP, int paramInt1, Ptr paramPtr1, Ptr paramPtr2, double paramDouble1, double paramDouble2, int paramInt2, Ptr paramPtr3) {
    return unit__.transformYArithmetic(paramSEXP, paramInt1, paramPtr1, paramPtr2, paramDouble1, paramDouble2, paramInt2, paramPtr3);
  }
  
  public static double transformYtoINCHES(SEXP paramSEXP, int paramInt, Ptr paramPtr1, Ptr paramPtr2, double paramDouble1, double paramDouble2, Ptr paramPtr3) {
    return unit__.transformYtoINCHES(paramSEXP, paramInt, paramPtr1, paramPtr2, paramDouble1, paramDouble2, paramPtr3);
  }
  
  public static void translation(double paramDouble1, double paramDouble2, Ptr paramPtr) {
    matrix__.translation(paramDouble1, paramDouble2, paramPtr);
  }
  
  public static SEXP unit(double paramDouble, int paramInt) {
    return unit__.unit(paramDouble, paramInt);
  }
  
  public static SEXP unitData(SEXP paramSEXP, int paramInt) {
    return unit__.unitData(paramSEXP, paramInt);
  }
  
  public static int unitLength(SEXP paramSEXP) {
    return unit__.unitLength(paramSEXP);
  }
  
  public static int unitUnit(SEXP paramSEXP, int paramInt) {
    return unit__.unitUnit(paramSEXP, paramInt);
  }
  
  public static double unitValue(SEXP paramSEXP, int paramInt) {
    return unit__.unitValue(paramSEXP, paramInt);
  }
  
  public static SEXP validUnits(SEXP paramSEXP) {
    return unit__.validUnits(paramSEXP);
  }
  
  public static double viewportAngle(SEXP paramSEXP) {
    return viewport__.viewportAngle(paramSEXP);
  }
  
  public static double viewportCex(SEXP paramSEXP) {
    return viewport__.viewportCex(paramSEXP);
  }
  
  public static SEXP viewportChildren(SEXP paramSEXP) {
    return viewport__.viewportChildren(paramSEXP);
  }
  
  public static int viewportClip(SEXP paramSEXP) {
    return viewport__.viewportClip(paramSEXP);
  }
  
  public static SEXP viewportClipRect(SEXP paramSEXP) {
    return viewport__.viewportClipRect(paramSEXP);
  }
  
  public static SEXP viewportDevHeightCM(SEXP paramSEXP) {
    return viewport__.viewportDevHeightCM(paramSEXP);
  }
  
  public static SEXP viewportDevWidthCM(SEXP paramSEXP) {
    return viewport__.viewportDevWidthCM(paramSEXP);
  }
  
  public static int viewportFont(SEXP paramSEXP) {
    return viewport__.viewportFont(paramSEXP);
  }
  
  public static Ptr viewportFontFamily(SEXP paramSEXP) {
    return viewport__.viewportFontFamily(paramSEXP);
  }
  
  public static double viewportFontSize(SEXP paramSEXP) {
    return viewport__.viewportFontSize(paramSEXP);
  }
  
  public static double viewportHJust(SEXP paramSEXP) {
    return viewport__.viewportHJust(paramSEXP);
  }
  
  public static SEXP viewportHeight(SEXP paramSEXP) {
    return viewport__.viewportHeight(paramSEXP);
  }
  
  public static SEXP viewportHeightCM(SEXP paramSEXP) {
    return viewport__.viewportHeightCM(paramSEXP);
  }
  
  public static SEXP viewportLayout(SEXP paramSEXP) {
    return viewport__.viewportLayout(paramSEXP);
  }
  
  public static SEXP viewportLayoutHeights(SEXP paramSEXP) {
    return viewport__.viewportLayoutHeights(paramSEXP);
  }
  
  public static SEXP viewportLayoutPosCol(SEXP paramSEXP) {
    return viewport__.viewportLayoutPosCol(paramSEXP);
  }
  
  public static SEXP viewportLayoutPosRow(SEXP paramSEXP) {
    return viewport__.viewportLayoutPosRow(paramSEXP);
  }
  
  public static SEXP viewportLayoutWidths(SEXP paramSEXP) {
    return viewport__.viewportLayoutWidths(paramSEXP);
  }
  
  public static double viewportLineHeight(SEXP paramSEXP) {
    return viewport__.viewportLineHeight(paramSEXP);
  }
  
  public static SEXP viewportParent(SEXP paramSEXP) {
    return viewport__.viewportParent(paramSEXP);
  }
  
  public static SEXP viewportParentGPar(SEXP paramSEXP) {
    return viewport__.viewportParentGPar(paramSEXP);
  }
  
  public static SEXP viewportRotation(SEXP paramSEXP) {
    return viewport__.viewportRotation(paramSEXP);
  }
  
  public static SEXP viewportTransform(SEXP paramSEXP) {
    return viewport__.viewportTransform(paramSEXP);
  }
  
  public static double viewportVJust(SEXP paramSEXP) {
    return viewport__.viewportVJust(paramSEXP);
  }
  
  public static SEXP viewportWidth(SEXP paramSEXP) {
    return viewport__.viewportWidth(paramSEXP);
  }
  
  public static SEXP viewportWidthCM(SEXP paramSEXP) {
    return viewport__.viewportWidthCM(paramSEXP);
  }
  
  public static SEXP viewportX(SEXP paramSEXP) {
    return viewport__.viewportX(paramSEXP);
  }
  
  public static double viewportXScaleMax(SEXP paramSEXP) {
    return viewport__.viewportXScaleMax(paramSEXP);
  }
  
  public static double viewportXScaleMin(SEXP paramSEXP) {
    return viewport__.viewportXScaleMin(paramSEXP);
  }
  
  public static SEXP viewportY(SEXP paramSEXP) {
    return viewport__.viewportY(paramSEXP);
  }
  
  public static double viewportYScaleMax(SEXP paramSEXP) {
    return viewport__.viewportYScaleMax(paramSEXP);
  }
  
  public static double viewportYScaleMin(SEXP paramSEXP) {
    return viewport__.viewportYScaleMin(paramSEXP);
  }
  
  public static SEXP viewportgpar(SEXP paramSEXP) {
    return viewport__.viewportgpar(paramSEXP);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/grid-0.9.2724.jar!/org/renjin/grid/grid.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */