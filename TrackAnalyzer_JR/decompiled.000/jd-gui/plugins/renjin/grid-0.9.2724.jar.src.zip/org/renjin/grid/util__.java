package org.renjin.grid;

import org.renjin.gcc.runtime.BytePtr;
import org.renjin.gcc.runtime.DoublePtr;
import org.renjin.gcc.runtime.Ptr;
import org.renjin.gcc.runtime.Stdlib;
import org.renjin.gcc.runtime.UnsatisfiedLinkException;
import org.renjin.gnur.api.Arith;
import org.renjin.gnur.api.Error;
import org.renjin.gnur.api.Rinternals;
import org.renjin.gnur.api.Rinternals2;
import org.renjin.gnur.api.Rmath;
import org.renjin.grDevices.baseEngine__;
import org.renjin.sexp.SEXP;

public class util__ {
  static {
  
  }
  
  public static SEXP L_CreateSEXPPtr(SEXP paramSEXP) {
    SEXP sEXP = Rinternals.Rf_allocVector(19, 1);
    Rinternals.Rf_protect(sEXP);
    Rinternals.SET_VECTOR_ELT(sEXP, 0, paramSEXP);
    return Rinternals.R_MakeExternalPtr(sEXP, Rinternals.R_NilValue, sEXP);
  }
  
  public static SEXP L_GetSEXPPtr(SEXP paramSEXP) {
    paramSEXP = (SEXP)Rinternals.R_ExternalPtrAddr(paramSEXP);
    if (paramSEXP == null)
      Error.Rf_error(new BytePtr("grid grob object is empty\000".getBytes(), 0), new Object[0]); 
    return Rinternals.VECTOR_ELT(paramSEXP, 0);
  }
  
  public static SEXP L_SetSEXPPtr(SEXP paramSEXP1, SEXP paramSEXP2) {
    paramSEXP1 = (SEXP)Rinternals.R_ExternalPtrAddr(paramSEXP1);
    if (paramSEXP1 == null)
      Error.Rf_error(new BytePtr("grid grob object is empty\000".getBytes(), 0), new Object[0]); 
    Rinternals.SET_VECTOR_ELT(paramSEXP1, 0, paramSEXP2);
    return Rinternals.R_NilValue;
  }
  
  public static void copyRect(Ptr paramPtr1, Ptr paramPtr2) {
    paramPtr2.setDouble(paramPtr1.getDouble());
    paramPtr2.setAlignedDouble(1, paramPtr1.getAlignedDouble(1));
    paramPtr2.setAlignedDouble(2, paramPtr1.getAlignedDouble(2));
    paramPtr2.setAlignedDouble(3, paramPtr1.getAlignedDouble(3));
    paramPtr2.setAlignedDouble(4, paramPtr1.getAlignedDouble(4));
    paramPtr2.setAlignedDouble(5, paramPtr1.getAlignedDouble(5));
    paramPtr2.setAlignedDouble(6, paramPtr1.getAlignedDouble(6));
    paramPtr2.setAlignedDouble(7, paramPtr1.getAlignedDouble(7));
  }
  
  public static int edgesIntersect(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, Ptr paramPtr) {
    boolean bool = false;
    double d3 = paramPtr.getAlignedDouble(5);
    double d2 = paramPtr.getAlignedDouble(4);
    double d1 = paramPtr.getAlignedDouble(1);
    d3 = paramPtr.getAlignedDouble(6);
    d2 = paramPtr.getAlignedDouble(5);
    d1 = paramPtr.getAlignedDouble(2);
    d3 = paramPtr.getAlignedDouble(7);
    d2 = paramPtr.getAlignedDouble(6);
    d1 = paramPtr.getAlignedDouble(3);
    d1 = paramPtr.getAlignedDouble(4);
    paramDouble2 = paramPtr.getAlignedDouble(7);
    paramDouble1 = paramPtr.getDouble();
    if (linesIntersect(paramDouble1, paramDouble2, paramPtr.getDouble(), d1, paramDouble3, paramDouble4, d2, d3) != 0 || linesIntersect(paramDouble1, paramDouble2, paramPtr.getAlignedDouble(1), d1, paramDouble3, paramDouble4, d2, d3) != 0 || linesIntersect(paramDouble1, paramDouble2, paramPtr.getAlignedDouble(2), d1, paramDouble3, paramDouble4, d2, d3) != 0 || linesIntersect(paramDouble1, paramDouble2, paramPtr.getAlignedDouble(3), paramDouble1, paramDouble3, paramDouble4, paramDouble2, d1) != 0)
      bool = true; 
    return bool;
  }
  
  public static SEXP getListElement(SEXP paramSEXP, Ptr paramPtr) {
    SEXP sEXP1 = (SEXP)BytePtr.of(0).getArray();
    sEXP1 = (SEXP)BytePtr.of(0).getArray();
    sEXP1 = Rinternals.R_NilValue;
    SEXP sEXP2 = Rinternals.Rf_getAttrib(paramSEXP, Rinternals.R_NamesSymbol);
    byte b = 0;
    while (Rinternals.Rf_length(paramSEXP) > b) {
      if (Stdlib.strcmp((Ptr)Rinternals.R_CHAR(Rinternals.STRING_ELT(sEXP2, b)), paramPtr) != 0) {
        b++;
        continue;
      } 
      sEXP1 = Rinternals.VECTOR_ELT(paramSEXP, b);
      break;
    } 
    return sEXP1;
  }
  
  public static int intersect(Ptr paramPtr1, Ptr paramPtr2) {
    null = false;
    double d3 = paramPtr1.getAlignedDouble(5);
    double d2 = paramPtr1.getAlignedDouble(4);
    double d1 = paramPtr1.getAlignedDouble(1);
    if (edgesIntersect(paramPtr1.getDouble(), d1, d2, d3, paramPtr2.copyOf(64)) == 0) {
      d3 = paramPtr1.getAlignedDouble(6);
      d2 = paramPtr1.getAlignedDouble(5);
      d1 = paramPtr1.getAlignedDouble(2);
      if (edgesIntersect(paramPtr1.getAlignedDouble(1), d1, d2, d3, paramPtr2.copyOf(64)) == 0) {
        d3 = paramPtr1.getAlignedDouble(7);
        d2 = paramPtr1.getAlignedDouble(6);
        d1 = paramPtr1.getAlignedDouble(3);
        if (edgesIntersect(paramPtr1.getAlignedDouble(2), d1, d2, d3, paramPtr2.copyOf(64)) == 0) {
          d3 = paramPtr1.getAlignedDouble(4);
          d2 = paramPtr1.getAlignedDouble(7);
          d1 = paramPtr1.getDouble();
          if (edgesIntersect(paramPtr1.getAlignedDouble(3), d1, d2, d3, paramPtr2.copyOf(64)) == 0)
            return null; 
        } 
      } 
    } 
    return 1;
  }
  
  public static int linesIntersect(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, double paramDouble7, double paramDouble8) {
    double d2 = 0.0D;
    double d1 = (paramDouble8 - paramDouble7) * (paramDouble2 - paramDouble1) - (paramDouble4 - paramDouble3) * (paramDouble6 - paramDouble5);
    double d3 = (paramDouble4 - paramDouble3) * (paramDouble5 - paramDouble7) - (paramDouble8 - paramDouble7) * (paramDouble1 - paramDouble3);
    if (d1 != 0.0D) {
      paramDouble1 = d3 / d1;
      paramDouble2 = ((paramDouble2 - paramDouble1) * (paramDouble5 - paramDouble7) - (paramDouble6 - paramDouble5) * (paramDouble1 - paramDouble3)) / d1;
      if (paramDouble1 > 0.0D && paramDouble1 < 1.0D && paramDouble2 > 0.0D && paramDouble2 < 1.0D)
        d2 = 1.0D; 
      return (int)d2;
    } 
    if (d3 == 0.0D) {
      boolean bool;
      if (paramDouble1 != paramDouble2) {
        if (paramDouble1 >= paramDouble3) {
          bool = false;
        } else {
          bool = true;
        } 
        if ((bool ^ true) == 0) {
          if (Rmath.Rf_fmax2(paramDouble1, paramDouble2) >= Rmath.Rf_fmin2(paramDouble3, paramDouble4)) {
            bool = false;
          } else {
            bool = true;
          } 
          if ((bool ^ true) == 0)
            return (int)d2; 
        } 
        if (paramDouble3 >= paramDouble1) {
          bool = false;
        } else {
          bool = true;
        } 
        if ((bool ^ true) == 0) {
          if (Rmath.Rf_fmax2(paramDouble3, paramDouble4) >= Rmath.Rf_fmin2(paramDouble1, paramDouble2)) {
            bool = false;
          } else {
            bool = true;
          } 
          if ((bool ^ true) == 0)
            return (int)d2; 
        } 
        d2 = 1.0D;
        return (int)d2;
      } 
      if (paramDouble5 >= paramDouble7) {
        bool = false;
      } else {
        bool = true;
      } 
      if ((bool ^ true) == 0) {
        if (Rmath.Rf_fmax2(paramDouble5, paramDouble6) >= Rmath.Rf_fmin2(paramDouble7, paramDouble8)) {
          bool = false;
        } else {
          bool = true;
        } 
        if ((bool ^ true) == 0)
          return (int)d2; 
      } 
      if (paramDouble7 >= paramDouble5) {
        bool = false;
      } else {
        bool = true;
      } 
      if ((bool ^ true) == 0) {
        if (Rmath.Rf_fmax2(paramDouble7, paramDouble8) >= Rmath.Rf_fmin2(paramDouble5, paramDouble6)) {
          bool = false;
        } else {
          bool = true;
        } 
        if ((bool ^ true) == 0)
          return (int)d2; 
      } 
      d2 = 1.0D;
    } 
    return (int)d2;
  }
  
  public static double numeric(SEXP paramSEXP, int paramInt) {
    return !Rinternals.Rf_isReal(paramSEXP) ? (!Rinternals.Rf_isInteger(paramSEXP) ? Arith.R_NaReal : Rinternals2.INTEGER(paramSEXP).getInt(0 + paramInt * 4)) : Rinternals2.REAL(paramSEXP).getDouble(0 + paramInt * 8);
  }
  
  public static void rect(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, double paramDouble7, double paramDouble8, Ptr paramPtr) {
    paramPtr.setDouble(paramDouble1);
    paramPtr.setAlignedDouble(1, paramDouble2);
    paramPtr.setAlignedDouble(2, paramDouble3);
    paramPtr.setAlignedDouble(3, paramDouble4);
    paramPtr.setAlignedDouble(4, paramDouble5);
    paramPtr.setAlignedDouble(5, paramDouble6);
    paramPtr.setAlignedDouble(6, paramDouble7);
    paramPtr.setAlignedDouble(7, paramDouble8);
  }
  
  public static void setListElement(SEXP paramSEXP1, Ptr paramPtr, SEXP paramSEXP2) {
    SEXP sEXP = (SEXP)BytePtr.of(0).getArray();
    sEXP = Rinternals.Rf_getAttrib(paramSEXP1, Rinternals.R_NamesSymbol);
    byte b = 0;
    while (Rinternals.Rf_length(paramSEXP1) > b) {
      if (Stdlib.strcmp((Ptr)Rinternals.R_CHAR(Rinternals.STRING_ELT(sEXP, b)), paramPtr) != 0) {
        b++;
        continue;
      } 
      Rinternals.SET_VECTOR_ELT(paramSEXP1, b, paramSEXP2);
      break;
    } 
  }
  
  public static void textRect(double paramDouble1, double paramDouble2, SEXP paramSEXP, int paramInt, Ptr paramPtr1, double paramDouble3, double paramDouble4, double paramDouble5, Ptr paramPtr2, Ptr paramPtr3) {
    int i;
    double[] arrayOfDouble1 = new double[9];
    double[] arrayOfDouble2 = new double[9];
    double[] arrayOfDouble3 = new double[9];
    double[] arrayOfDouble4 = new double[9];
    double[] arrayOfDouble5 = new double[9];
    double[] arrayOfDouble6 = new double[3];
    double[] arrayOfDouble7 = new double[3];
    double[] arrayOfDouble8 = new double[3];
    double[] arrayOfDouble9 = new double[3];
    double[] arrayOfDouble10 = new double[3];
    double[] arrayOfDouble11 = new double[3];
    double[] arrayOfDouble12 = new double[3];
    double[] arrayOfDouble13 = new double[3];
    if (!Rinternals.Rf_isExpression(paramSEXP)) {
      int j;
      BytePtr bytePtr = Rinternals.R_CHAR(Rinternals.STRING_ELT(paramSEXP, paramInt % Rinternals.LENGTH(paramSEXP)));
      if (paramPtr1.getAlignedInt(17) == 5) {
        j = 5;
      } else {
        j = Rinternals.Rf_getCharCE(Rinternals.STRING_ELT(paramSEXP, paramInt % Rinternals.LENGTH(paramSEXP)));
      } 
      double d2 = baseEngine__.GEfromDeviceWidth(baseEngine__.GEStrWidth((Ptr)bytePtr, j, paramPtr1, paramPtr2), 2, paramPtr2);
      if (paramPtr1.getAlignedInt(17) == 5) {
        i = 5;
      } else {
        i = Rinternals.Rf_getCharCE(Rinternals.STRING_ELT(i, paramInt % Rinternals.LENGTH(i)));
      } 
      double d1 = baseEngine__.GEfromDeviceHeight(baseEngine__.GEStrHeight((Ptr)bytePtr, i, paramPtr1, paramPtr2), 2, paramPtr2);
      matrix__.location(0.0D, 0.0D, (Ptr)new DoublePtr(arrayOfDouble13, 0));
      matrix__.location(d2, 0.0D, (Ptr)new DoublePtr(arrayOfDouble12, 0));
      matrix__.location(d2, d1, (Ptr)new DoublePtr(arrayOfDouble11, 0));
      matrix__.location(0.0D, d1, (Ptr)new DoublePtr(arrayOfDouble10, 0));
      matrix__.translation(-paramDouble3 * d2, -paramDouble4 * d1, (Ptr)new DoublePtr(arrayOfDouble3, 0));
      matrix__.translation(paramDouble1, paramDouble2, (Ptr)new DoublePtr(arrayOfDouble5, 0));
      if (paramDouble5 == 0.0D) {
        matrix__.identity((Ptr)new DoublePtr(arrayOfDouble4, 0));
      } else {
        matrix__.rotation(paramDouble5, (Ptr)new DoublePtr(arrayOfDouble4, 0));
      } 
      matrix__.multiply((Ptr)new DoublePtr(arrayOfDouble3, 0), (Ptr)new DoublePtr(arrayOfDouble4, 0), (Ptr)new DoublePtr(arrayOfDouble2, 0));
      matrix__.multiply((Ptr)new DoublePtr(arrayOfDouble2, 0), (Ptr)new DoublePtr(arrayOfDouble5, 0), (Ptr)new DoublePtr(arrayOfDouble1, 0));
      matrix__.trans((Ptr)new DoublePtr(arrayOfDouble13, 0), (Ptr)new DoublePtr(arrayOfDouble1, 0), (Ptr)new DoublePtr(arrayOfDouble9, 0));
      matrix__.trans((Ptr)new DoublePtr(arrayOfDouble12, 0), (Ptr)new DoublePtr(arrayOfDouble1, 0), (Ptr)new DoublePtr(arrayOfDouble8, 0));
      matrix__.trans((Ptr)new DoublePtr(arrayOfDouble11, 0), (Ptr)new DoublePtr(arrayOfDouble1, 0), (Ptr)new DoublePtr(arrayOfDouble7, 0));
      matrix__.trans((Ptr)new DoublePtr(arrayOfDouble10, 0), (Ptr)new DoublePtr(arrayOfDouble1, 0), (Ptr)new DoublePtr(arrayOfDouble6, 0));
      d2 = matrix__.locationY((Ptr)new DoublePtr(arrayOfDouble6, 0));
      d1 = matrix__.locationY((Ptr)new DoublePtr(arrayOfDouble7, 0));
      paramDouble5 = matrix__.locationY((Ptr)new DoublePtr(arrayOfDouble8, 0));
      paramDouble4 = matrix__.locationY((Ptr)new DoublePtr(arrayOfDouble9, 0));
      paramDouble3 = matrix__.locationX((Ptr)new DoublePtr(arrayOfDouble6, 0));
      paramDouble2 = matrix__.locationX((Ptr)new DoublePtr(arrayOfDouble7, 0));
      paramDouble1 = matrix__.locationX((Ptr)new DoublePtr(arrayOfDouble8, 0));
      rect(matrix__.locationX((Ptr)new DoublePtr(arrayOfDouble9, 0)), paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5, d1, d2, paramPtr3);
      return;
    } 
    Rinternals.VECTOR_ELT(i, paramInt % Rinternals.LENGTH(i));
    throw new UnsatisfiedLinkException("GEExpressionWidth");
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/grid-0.9.2724.jar!/org/renjin/grid/util__.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */