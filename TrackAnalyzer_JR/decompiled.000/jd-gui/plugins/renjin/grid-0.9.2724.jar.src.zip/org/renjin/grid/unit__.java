package org.renjin.grid;

import org.renjin.gcc.runtime.BytePtr;
import org.renjin.gcc.runtime.DoublePtr;
import org.renjin.gcc.runtime.MixedPtr;
import org.renjin.gcc.runtime.Ptr;
import org.renjin.gcc.runtime.Stdlib;
import org.renjin.gcc.runtime.UnsatisfiedLinkException;
import org.renjin.gnur.api.Error;
import org.renjin.gnur.api.GetText;
import org.renjin.gnur.api.Rinternals;
import org.renjin.gnur.api.Rinternals2;
import org.renjin.grDevices.baseEngine__;
import org.renjin.sexp.SEXP;

public class unit__ {
  public static Ptr UnitTable = (Ptr)MixedPtr.malloc(344);
  
  static {
    UnitTable$$clinit();
  }
  
  static void UnitTable$$clinit() {
    MixedPtr mixedPtr = MixedPtr.malloc(344);
    mixedPtr.setPointer((Ptr)new BytePtr("npc\000".getBytes(), 0));
    mixedPtr.setAlignedInt(1, 0);
    mixedPtr.setAlignedPointer(2, (Ptr)new BytePtr("cm\000".getBytes(), 0));
    mixedPtr.setAlignedInt(3, 1);
    mixedPtr.setAlignedPointer(4, (Ptr)new BytePtr("inches\000".getBytes(), 0));
    mixedPtr.setAlignedInt(5, 2);
    mixedPtr.setAlignedPointer(6, (Ptr)new BytePtr("lines\000".getBytes(), 0));
    mixedPtr.setAlignedInt(7, 3);
    mixedPtr.setAlignedPointer(8, (Ptr)new BytePtr("native\000".getBytes(), 0));
    mixedPtr.setAlignedInt(9, 4);
    mixedPtr.setAlignedPointer(10, (Ptr)new BytePtr("null\000".getBytes(), 0));
    mixedPtr.setAlignedInt(11, 5);
    mixedPtr.setAlignedPointer(12, (Ptr)new BytePtr("snpc\000".getBytes(), 0));
    mixedPtr.setAlignedInt(13, 6);
    mixedPtr.setAlignedPointer(14, (Ptr)new BytePtr("mm\000".getBytes(), 0));
    mixedPtr.setAlignedInt(15, 7);
    mixedPtr.setAlignedPointer(16, (Ptr)new BytePtr("points\000".getBytes(), 0));
    mixedPtr.setAlignedInt(17, 8);
    mixedPtr.setAlignedPointer(18, (Ptr)new BytePtr("picas\000".getBytes(), 0));
    mixedPtr.setAlignedInt(19, 9);
    mixedPtr.setAlignedPointer(20, (Ptr)new BytePtr("bigpts\000".getBytes(), 0));
    mixedPtr.setAlignedInt(21, 10);
    mixedPtr.setAlignedPointer(22, (Ptr)new BytePtr("dida\000".getBytes(), 0));
    mixedPtr.setAlignedInt(23, 11);
    mixedPtr.setAlignedPointer(24, (Ptr)new BytePtr("cicero\000".getBytes(), 0));
    mixedPtr.setAlignedInt(25, 12);
    mixedPtr.setAlignedPointer(26, (Ptr)new BytePtr("scaledpts\000".getBytes(), 0));
    mixedPtr.setAlignedInt(27, 13);
    mixedPtr.setAlignedPointer(28, (Ptr)new BytePtr("strwidth\000".getBytes(), 0));
    mixedPtr.setAlignedInt(29, 14);
    mixedPtr.setAlignedPointer(30, (Ptr)new BytePtr("strheight\000".getBytes(), 0));
    mixedPtr.setAlignedInt(31, 15);
    mixedPtr.setAlignedPointer(32, (Ptr)new BytePtr("strascent\000".getBytes(), 0));
    mixedPtr.setAlignedInt(33, 16);
    mixedPtr.setAlignedPointer(34, (Ptr)new BytePtr("strdescent\000".getBytes(), 0));
    mixedPtr.setAlignedInt(35, 17);
    mixedPtr.setAlignedPointer(36, (Ptr)new BytePtr("char\000".getBytes(), 0));
    mixedPtr.setAlignedInt(37, 18);
    mixedPtr.setAlignedPointer(38, (Ptr)new BytePtr("grobx\000".getBytes(), 0));
    mixedPtr.setAlignedInt(39, 19);
    mixedPtr.setAlignedPointer(40, (Ptr)new BytePtr("groby\000".getBytes(), 0));
    mixedPtr.setAlignedInt(41, 20);
    mixedPtr.setAlignedPointer(42, (Ptr)new BytePtr("grobwidth\000".getBytes(), 0));
    mixedPtr.setAlignedInt(43, 21);
    mixedPtr.setAlignedPointer(44, (Ptr)new BytePtr("grobheight\000".getBytes(), 0));
    mixedPtr.setAlignedInt(45, 22);
    mixedPtr.setAlignedPointer(46, (Ptr)new BytePtr("grobascent\000".getBytes(), 0));
    mixedPtr.setAlignedInt(47, 23);
    mixedPtr.setAlignedPointer(48, (Ptr)new BytePtr("grobdescent\000".getBytes(), 0));
    mixedPtr.setAlignedInt(49, 24);
    mixedPtr.setAlignedPointer(50, (Ptr)new BytePtr("mylines\000".getBytes(), 0));
    mixedPtr.setAlignedInt(51, 103);
    mixedPtr.setAlignedPointer(52, (Ptr)new BytePtr("mychar\000".getBytes(), 0));
    mixedPtr.setAlignedInt(53, 104);
    mixedPtr.setAlignedPointer(54, (Ptr)new BytePtr("mystrwidth\000".getBytes(), 0));
    mixedPtr.setAlignedInt(55, 105);
    mixedPtr.setAlignedPointer(56, (Ptr)new BytePtr("mystrheight\000".getBytes(), 0));
    mixedPtr.setAlignedInt(57, 106);
    mixedPtr.setAlignedPointer(58, (Ptr)new BytePtr("centimetre\000".getBytes(), 0));
    mixedPtr.setAlignedInt(59, 1001);
    mixedPtr.setAlignedPointer(60, (Ptr)new BytePtr("centimetres\000".getBytes(), 0));
    mixedPtr.setAlignedInt(61, 1001);
    mixedPtr.setAlignedPointer(62, (Ptr)new BytePtr("centimeter\000".getBytes(), 0));
    mixedPtr.setAlignedInt(63, 1001);
    mixedPtr.setAlignedPointer(64, (Ptr)new BytePtr("centimeters\000".getBytes(), 0));
    mixedPtr.setAlignedInt(65, 1001);
    mixedPtr.setAlignedPointer(66, (Ptr)new BytePtr("in\000".getBytes(), 0));
    mixedPtr.setAlignedInt(67, 1002);
    mixedPtr.setAlignedPointer(68, (Ptr)new BytePtr("inch\000".getBytes(), 0));
    mixedPtr.setAlignedInt(69, 1002);
    mixedPtr.setAlignedPointer(70, (Ptr)new BytePtr("line\000".getBytes(), 0));
    mixedPtr.setAlignedInt(71, 1003);
    mixedPtr.setAlignedPointer(72, (Ptr)new BytePtr("millimetre\000".getBytes(), 0));
    mixedPtr.setAlignedInt(73, 1007);
    mixedPtr.setAlignedPointer(74, (Ptr)new BytePtr("millimetres\000".getBytes(), 0));
    mixedPtr.setAlignedInt(75, 1007);
    mixedPtr.setAlignedPointer(76, (Ptr)new BytePtr("millimeter\000".getBytes(), 0));
    mixedPtr.setAlignedInt(77, 1007);
    mixedPtr.setAlignedPointer(78, (Ptr)new BytePtr("millimeters\000".getBytes(), 0));
    mixedPtr.setAlignedInt(79, 1007);
    mixedPtr.setAlignedPointer(80, (Ptr)new BytePtr("point\000".getBytes(), 0));
    mixedPtr.setAlignedInt(81, 1008);
    mixedPtr.setAlignedPointer(82, (Ptr)new BytePtr("pt\000".getBytes(), 0));
    mixedPtr.setAlignedInt(83, 1008);
    mixedPtr.setAlignedPointer(84, BytePtr.of(0));
    mixedPtr.setAlignedInt(85, -1);
    UnitTable.memcpy((Ptr)mixedPtr, 344);
  }
  
  public static int addOp(SEXP paramSEXP) {
    return fNameMatch(paramSEXP, (Ptr)new BytePtr("+\000".getBytes(), 0));
  }
  
  public static SEXP arg1(SEXP paramSEXP) {
    return util__.getListElement(paramSEXP, (Ptr)new BytePtr("arg1\000".getBytes(), 0));
  }
  
  public static SEXP arg2(SEXP paramSEXP) {
    return util__.getListElement(paramSEXP, (Ptr)new BytePtr("arg2\000".getBytes(), 0));
  }
  
  public static int convertUnit(SEXP paramSEXP, int paramInt) {
    byte b = 0;
    int i = 0;
    boolean bool = false;
    while (!i && !bool) {
      if (!UnitTable.getPointer(b * 8).isNull()) {
        boolean bool2;
        Ptr ptr = UnitTable.getPointer(b * 8);
        if (Stdlib.strcmp((Ptr)Rinternals.R_CHAR(Rinternals.STRING_ELT(paramSEXP, paramInt)), ptr) != 0) {
          bool2 = false;
        } else {
          bool2 = true;
        } 
        boolean bool1 = bool2;
        if (bool2) {
          i = UnitTable.getInt(b * 8 + 4);
          if (i > 1000)
            i -= 1000; 
        } 
      } else {
        i = -1;
      } 
      b++;
    } 
    if (i < 0)
      Error.Rf_error(GetText.dgettext(new BytePtr("grid\000".getBytes(), 0), new BytePtr("Invalid unit\000".getBytes(), 0)), new Object[0]); 
    return i;
  }
  
  public static double evaluateGrobAscentUnit(SEXP paramSEXP, double paramDouble1, double paramDouble2, int paramInt1, int paramInt2, Ptr paramPtr) {
    return evaluateGrobUnit(1.0D, paramSEXP, paramDouble1, paramDouble2, paramInt1, paramInt2, 4, paramPtr);
  }
  
  public static double evaluateGrobDescentUnit(SEXP paramSEXP, double paramDouble1, double paramDouble2, int paramInt1, int paramInt2, Ptr paramPtr) {
    return evaluateGrobUnit(1.0D, paramSEXP, paramDouble1, paramDouble2, paramInt1, paramInt2, 5, paramPtr);
  }
  
  public static double evaluateGrobHeightUnit(SEXP paramSEXP, double paramDouble1, double paramDouble2, int paramInt1, int paramInt2, Ptr paramPtr) {
    return evaluateGrobUnit(1.0D, paramSEXP, paramDouble1, paramDouble2, paramInt1, paramInt2, 3, paramPtr);
  }
  
  public static double evaluateGrobUnit(double paramDouble1, SEXP paramSEXP, double paramDouble2, double paramDouble3, int paramInt1, int paramInt2, int paramInt3, Ptr paramPtr) {
    SEXP sEXP1;
    double[] arrayOfDouble1 = new double[9];
    double[] arrayOfDouble2 = new double[3];
    double[] arrayOfDouble3 = new double[3];
    double[] arrayOfDouble4 = new double[1];
    double[] arrayOfDouble5 = new double[1];
    double[] arrayOfDouble7 = new double[9];
    double[] arrayOfDouble8 = new double[9];
    MixedPtr mixedPtr1 = MixedPtr.malloc(276);
    MixedPtr mixedPtr2 = MixedPtr.malloc(32);
    double[] arrayOfDouble6 = new double[1];
    double[] arrayOfDouble9 = new double[1];
    double[] arrayOfDouble10 = new double[1];
    arrayOfDouble4[0] = 0.0D;
    arrayOfDouble5[0] = 0.0D;
    arrayOfDouble6[0] = 0.0D;
    arrayOfDouble9[0] = 0.0D;
    arrayOfDouble10[0] = 0.0D;
    SEXP sEXP7 = Rinternals.R_NilValue;
    SEXP sEXP6 = Rinternals.R_NilValue;
    SEXP sEXP8 = Rinternals.R_NilValue;
    SEXP sEXP9 = Rinternals.R_NilValue;
    paramDouble2 = 0.0D;
    boolean bool = false;
    int i = paramPtr.getAlignedInt(6);
    paramPtr.setAlignedInt(6, 0);
    grid__.getViewportTransform(state__.gridStateElement(paramPtr, 7), paramPtr, (Ptr)new DoublePtr(arrayOfDouble10, 0), (Ptr)new DoublePtr(arrayOfDouble9, 0), (Ptr)new DoublePtr(arrayOfDouble7, 0), (Ptr)new DoublePtr(arrayOfDouble6, 0));
    SEXP sEXP3 = state__.gridStateElement(paramPtr, 5);
    Rinternals.Rf_protect(sEXP3);
    SEXP sEXP2 = state__.gridStateElement(paramPtr, 12);
    Rinternals.Rf_protect(sEXP2);
    SEXP sEXP5 = grid__.R_gridEvalEnv;
    sEXP5 = Rinternals.Rf_findFun(Rinternals.Rf_install(new BytePtr("preDraw\000".getBytes(), 0)), sEXP5);
    Rinternals.Rf_protect(sEXP5);
    switch (paramInt3) {
      case 0:
      case 1:
        sEXP7 = grid__.R_gridEvalEnv;
        sEXP7 = Rinternals.Rf_findFun(Rinternals.Rf_install(new BytePtr("xDetails\000".getBytes(), 0)), sEXP7);
        Rinternals.Rf_protect(sEXP7);
        sEXP6 = grid__.R_gridEvalEnv;
        sEXP6 = Rinternals.Rf_findFun(Rinternals.Rf_install(new BytePtr("yDetails\000".getBytes(), 0)), sEXP6);
        Rinternals.Rf_protect(sEXP6);
        break;
      case 2:
        sEXP7 = grid__.R_gridEvalEnv;
        sEXP7 = Rinternals.Rf_findFun(Rinternals.Rf_install(new BytePtr("width\000".getBytes(), 0)), sEXP7);
        Rinternals.Rf_protect(sEXP7);
        break;
      case 3:
        sEXP6 = grid__.R_gridEvalEnv;
        sEXP6 = Rinternals.Rf_findFun(Rinternals.Rf_install(new BytePtr("height\000".getBytes(), 0)), sEXP6);
        Rinternals.Rf_protect(sEXP6);
        break;
      case 4:
        sEXP6 = grid__.R_gridEvalEnv;
        sEXP6 = Rinternals.Rf_findFun(Rinternals.Rf_install(new BytePtr("ascentDetails\000".getBytes(), 0)), sEXP6);
        Rinternals.Rf_protect(sEXP6);
        break;
      case 5:
        sEXP6 = grid__.R_gridEvalEnv;
        sEXP6 = Rinternals.Rf_findFun(Rinternals.Rf_install(new BytePtr("descentDetails\000".getBytes(), 0)), sEXP6);
        Rinternals.Rf_protect(sEXP6);
        break;
    } 
    SEXP sEXP4 = grid__.R_gridEvalEnv;
    sEXP4 = Rinternals.Rf_findFun(Rinternals.Rf_install(new BytePtr("postDraw\000".getBytes(), 0)), sEXP4);
    Rinternals.Rf_protect(sEXP4);
    if (Rinternals.Rf_inherits(paramSEXP, new BytePtr("gPath\000".getBytes(), 0))) {
      if (!Rinternals.Rf_isNull(sEXP2)) {
        SEXP sEXP = grid__.R_gridEvalEnv;
        Rinternals.Rf_protect(Rinternals.Rf_findFun(Rinternals.Rf_install(new BytePtr("findGrobinChildren\000".getBytes(), 0)), sEXP));
        sEXP = util__.getListElement(sEXP2, (Ptr)new BytePtr("children\000".getBytes(), 0));
        Rinternals.Rf_protect(Rinternals.Rf_lang3(Rinternals.Rf_findFun(Rinternals.Rf_install(new BytePtr("findGrobinChildren\000".getBytes(), 0)), sEXP), util__.getListElement(paramSEXP, (Ptr)new BytePtr("name\000".getBytes(), 0)), sEXP));
        paramSEXP = Rinternals.Rf_eval(Rinternals.Rf_lang3(Rinternals.Rf_findFun(Rinternals.Rf_install(new BytePtr("findGrobinChildren\000".getBytes(), 0)), sEXP), util__.getListElement(paramSEXP, (Ptr)new BytePtr("name\000".getBytes(), 0)), sEXP), grid__.R_gridEvalEnv);
        Rinternals.Rf_protect(paramSEXP);
      } else {
        SEXP sEXP = grid__.R_gridEvalEnv;
        Rinternals.Rf_protect(Rinternals.Rf_findFun(Rinternals.Rf_install(new BytePtr("findGrobinDL\000".getBytes(), 0)), sEXP));
        Rinternals.Rf_protect(Rinternals.Rf_lang2(Rinternals.Rf_findFun(Rinternals.Rf_install(new BytePtr("findGrobinDL\000".getBytes(), 0)), sEXP), util__.getListElement(paramSEXP, (Ptr)new BytePtr("name\000".getBytes(), 0))));
        paramSEXP = Rinternals.Rf_eval(Rinternals.Rf_lang2(Rinternals.Rf_findFun(Rinternals.Rf_install(new BytePtr("findGrobinDL\000".getBytes(), 0)), sEXP), util__.getListElement(paramSEXP, (Ptr)new BytePtr("name\000".getBytes(), 0))), grid__.R_gridEvalEnv);
        Rinternals.Rf_protect(paramSEXP);
      } 
      bool = true;
    } 
    Rinternals.Rf_protect(Rinternals.Rf_lang2(sEXP5, paramSEXP));
    paramSEXP = Rinternals.Rf_eval(Rinternals.Rf_lang2(sEXP5, paramSEXP), grid__.R_gridEvalEnv);
    Rinternals.Rf_protect(paramSEXP);
    sEXP5 = state__.gridStateElement(paramPtr, 5);
    grid__.getViewportTransform(state__.gridStateElement(paramPtr, 7), paramPtr, (Ptr)new DoublePtr(arrayOfDouble10, 0), (Ptr)new DoublePtr(arrayOfDouble9, 0), (Ptr)new DoublePtr(arrayOfDouble8, 0), (Ptr)new DoublePtr(arrayOfDouble6, 0));
    viewport__.fillViewportContextFromViewport(state__.gridStateElement(paramPtr, 7), (Ptr)mixedPtr2);
    switch (paramInt3) {
      case 0:
      case 1:
        sEXP1 = Rinternals.Rf_ScalarReal(paramDouble1);
        Rinternals.Rf_protect(sEXP1);
        Rinternals.Rf_protect(Rinternals.Rf_lang3(sEXP7, paramSEXP, sEXP1));
        sEXP8 = Rinternals.Rf_eval(Rinternals.Rf_lang3(sEXP7, paramSEXP, sEXP1), grid__.R_gridEvalEnv);
        Rinternals.Rf_protect(sEXP8);
        Rinternals.Rf_protect(Rinternals.Rf_lang3(sEXP6, paramSEXP, sEXP1));
        sEXP9 = Rinternals.Rf_eval(Rinternals.Rf_lang3(sEXP6, paramSEXP, sEXP1), grid__.R_gridEvalEnv);
        Rinternals.Rf_protect(sEXP9);
        break;
      case 2:
        Rinternals.Rf_protect(Rinternals.Rf_lang2(sEXP7, paramSEXP));
        sEXP8 = Rinternals.Rf_eval(Rinternals.Rf_lang2(sEXP7, paramSEXP), grid__.R_gridEvalEnv);
        Rinternals.Rf_protect(sEXP8);
        break;
      case 3:
      case 4:
      case 5:
        Rinternals.Rf_protect(Rinternals.Rf_lang2(sEXP6, paramSEXP));
        sEXP9 = Rinternals.Rf_eval(Rinternals.Rf_lang2(sEXP6, paramSEXP), grid__.R_gridEvalEnv);
        Rinternals.Rf_protect(sEXP9);
        break;
    } 
    gpar__.gcontextFromgpar(sEXP5, 0, (Ptr)mixedPtr1, paramPtr);
    switch (paramInt3) {
      case 0:
      case 1:
        if (paramInt3 == 0 || pureNullUnit(sEXP9, 0, paramPtr) == 0) {
          if (pureNullUnit(sEXP8, 0, paramPtr) == 0) {
            matrix__.invTransform((Ptr)new DoublePtr(arrayOfDouble7, 0), (Ptr)new DoublePtr(arrayOfDouble1, 0));
            paramDouble2 = arrayOfDouble9[0];
            paramDouble1 = arrayOfDouble10[0];
            transformLocn(sEXP8, sEXP9, 0, mixedPtr2.copyOf(32), (Ptr)mixedPtr1, paramDouble1, paramDouble2, paramPtr, (Ptr)new DoublePtr(arrayOfDouble8, 0), (Ptr)new DoublePtr(arrayOfDouble5, 0), (Ptr)new DoublePtr(arrayOfDouble4, 0));
            matrix__.location(arrayOfDouble5[0], arrayOfDouble4[0], (Ptr)new DoublePtr(arrayOfDouble3, 0));
            matrix__.trans((Ptr)new DoublePtr(arrayOfDouble3, 0), (Ptr)new DoublePtr(arrayOfDouble1, 0), (Ptr)new DoublePtr(arrayOfDouble2, 0));
            arrayOfDouble5[0] = matrix__.locationX((Ptr)new DoublePtr(arrayOfDouble2, 0));
            arrayOfDouble4[0] = matrix__.locationY((Ptr)new DoublePtr(arrayOfDouble2, 0));
            if (paramInt3 == 0) {
              paramDouble2 = arrayOfDouble5[0];
              break;
            } 
            paramDouble2 = arrayOfDouble4[0];
            break;
          } 
          paramDouble1 = arrayOfDouble10[0];
          paramDouble2 = evaluateNullUnit(pureNullUnitValue(sEXP8, 0), paramDouble1, paramInt1, paramInt2);
          break;
        } 
        paramDouble1 = arrayOfDouble10[0];
        paramDouble2 = evaluateNullUnit(pureNullUnitValue(sEXP9, 0), paramDouble1, paramInt1, paramInt2);
        break;
      case 2:
        if (pureNullUnit(sEXP8, 0, paramPtr) == 0) {
          paramDouble2 = arrayOfDouble9[0];
          paramDouble1 = arrayOfDouble10[0];
          paramDouble2 = transformWidthtoINCHES(sEXP8, 0, mixedPtr2.copyOf(32), (Ptr)mixedPtr1, paramDouble1, paramDouble2, paramPtr);
          break;
        } 
        paramDouble1 = arrayOfDouble10[0];
        paramDouble2 = evaluateNullUnit(pureNullUnitValue(sEXP8, 0), paramDouble1, paramInt1, paramInt2);
        break;
      case 3:
      case 4:
      case 5:
        if (pureNullUnit(sEXP9, 0, paramPtr) == 0) {
          paramDouble2 = arrayOfDouble9[0];
          paramDouble1 = arrayOfDouble10[0];
          paramDouble2 = transformHeighttoINCHES(sEXP9, 0, mixedPtr2.copyOf(32), (Ptr)mixedPtr1, paramDouble1, paramDouble2, paramPtr);
          break;
        } 
        paramDouble1 = arrayOfDouble10[0];
        paramDouble2 = evaluateNullUnit(pureNullUnitValue(sEXP9, 0), paramDouble1, paramInt1, paramInt2);
        break;
    } 
    Rinternals.Rf_protect(Rinternals.Rf_lang2(sEXP4, paramSEXP));
    Rinternals.Rf_eval(Rinternals.Rf_lang2(sEXP4, paramSEXP), grid__.R_gridEvalEnv);
    state__.setGridStateElement(paramPtr, 5, sEXP3);
    state__.setGridStateElement(paramPtr, 12, sEXP2);
    if (!bool);
    switch (paramInt3) {
    
    } 
    paramPtr.setAlignedInt(6, i);
    return paramDouble2;
  }
  
  public static double evaluateGrobWidthUnit(SEXP paramSEXP, double paramDouble1, double paramDouble2, int paramInt1, int paramInt2, Ptr paramPtr) {
    return evaluateGrobUnit(1.0D, paramSEXP, paramDouble1, paramDouble2, paramInt1, paramInt2, 2, paramPtr);
  }
  
  public static double evaluateGrobXUnit(double paramDouble1, SEXP paramSEXP, double paramDouble2, double paramDouble3, int paramInt1, int paramInt2, Ptr paramPtr) {
    return evaluateGrobUnit(paramDouble1, paramSEXP, paramDouble2, paramDouble3, paramInt1, paramInt2, 0, paramPtr);
  }
  
  public static double evaluateGrobYUnit(double paramDouble1, SEXP paramSEXP, double paramDouble2, double paramDouble3, int paramInt1, int paramInt2, Ptr paramPtr) {
    return evaluateGrobUnit(paramDouble1, paramSEXP, paramDouble2, paramDouble3, paramInt1, paramInt2, 1, paramPtr);
  }
  
  public static double evaluateNullUnit(double paramDouble1, double paramDouble2, int paramInt1, int paramInt2) {
    paramDouble1 = paramDouble1;
    if (paramInt1 == 0)
      switch (paramInt2) {
        case 1:
        case 2:
        case 3:
        case 4:
          paramDouble1 = 0.0D;
          break;
        case 7:
          paramDouble1 = 0.0D;
          break;
        case 5:
          paramDouble1 = 0.0D;
          break;
        case 6:
          paramDouble1 = paramDouble2;
          break;
      }  
    return paramDouble1;
  }
  
  public static Ptr fName(SEXP paramSEXP) {
    return (Ptr)Rinternals.R_CHAR(Rinternals.STRING_ELT(util__.getListElement(paramSEXP, (Ptr)new BytePtr("fname\000".getBytes(), 0)), 0));
  }
  
  public static int fNameMatch(SEXP paramSEXP, Ptr paramPtr) {
    boolean bool;
    if (Stdlib.strcmp(fName(paramSEXP), paramPtr) != 0) {
      bool = false;
    } else {
      bool = true;
    } 
    return bool;
  }
  
  public static int fOp(SEXP paramSEXP) {
    return (addOp(paramSEXP) == 0 && minusOp(paramSEXP) == 0 && timesOp(paramSEXP) == 0) ? 0 : 1;
  }
  
  public static int isUnitArithmetic(SEXP paramSEXP) {
    return Rinternals.Rf_inherits(paramSEXP, new BytePtr("unit.arithmetic\000".getBytes(), 0));
  }
  
  public static int isUnitList(SEXP paramSEXP) {
    return Rinternals.Rf_inherits(paramSEXP, new BytePtr("unit.list\000".getBytes(), 0));
  }
  
  public static int maxFunc(SEXP paramSEXP) {
    return fNameMatch(paramSEXP, (Ptr)new BytePtr("max\000".getBytes(), 0));
  }
  
  public static int minFunc(SEXP paramSEXP) {
    return fNameMatch(paramSEXP, (Ptr)new BytePtr("min\000".getBytes(), 0));
  }
  
  public static int minusOp(SEXP paramSEXP) {
    return fNameMatch(paramSEXP, (Ptr)new BytePtr("-\000".getBytes(), 0));
  }
  
  public static int pureNullUnit(SEXP paramSEXP, int paramInt, Ptr paramPtr) {
    SEXP sEXP1;
    SEXP sEXP2;
    if (isUnitArithmetic(paramSEXP) == 0) {
      if (isUnitList(paramSEXP) == 0) {
        if (unitUnit(paramSEXP, paramInt) != 21) {
          boolean bool;
          if (unitUnit(paramSEXP, paramInt) != 22) {
            if (unitUnit(paramSEXP, paramInt) != 5) {
              bool = false;
            } else {
              bool = true;
            } 
            return bool;
          } 
          SEXP sEXP10 = unitData(bool, paramInt);
          Rinternals.Rf_protect(sEXP10);
          sEXP2 = state__.gridStateElement(paramPtr, 5);
          Rinternals.Rf_protect(sEXP2);
          sEXP1 = state__.gridStateElement(paramPtr, 12);
          Rinternals.Rf_protect(sEXP1);
          SEXP sEXP7 = grid__.R_gridEvalEnv;
          SEXP sEXP9 = Rinternals.Rf_findFun(Rinternals.Rf_install(new BytePtr("preDraw\000".getBytes(), 0)), sEXP7);
          Rinternals.Rf_protect(sEXP9);
          sEXP7 = grid__.R_gridEvalEnv;
          SEXP sEXP8 = Rinternals.Rf_findFun(Rinternals.Rf_install(new BytePtr("height\000".getBytes(), 0)), sEXP7);
          Rinternals.Rf_protect(sEXP8);
          sEXP7 = grid__.R_gridEvalEnv;
          sEXP7 = Rinternals.Rf_findFun(Rinternals.Rf_install(new BytePtr("postDraw\000".getBytes(), 0)), sEXP7);
          Rinternals.Rf_protect(sEXP7);
          if (Rinternals.Rf_inherits(sEXP10, new BytePtr("gPath\000".getBytes(), 0)))
            if (!Rinternals.Rf_isNull(sEXP1)) {
              SEXP sEXP = grid__.R_gridEvalEnv;
              Rinternals.Rf_protect(Rinternals.Rf_findFun(Rinternals.Rf_install(new BytePtr("findGrobinChildren\000".getBytes(), 0)), sEXP));
              sEXP = util__.getListElement(sEXP1, (Ptr)new BytePtr("children\000".getBytes(), 0));
              Rinternals.Rf_protect(Rinternals.Rf_lang3(Rinternals.Rf_findFun(Rinternals.Rf_install(new BytePtr("findGrobinChildren\000".getBytes(), 0)), sEXP), util__.getListElement(sEXP10, (Ptr)new BytePtr("name\000".getBytes(), 0)), sEXP));
              sEXP10 = Rinternals.Rf_eval(Rinternals.Rf_lang3(Rinternals.Rf_findFun(Rinternals.Rf_install(new BytePtr("findGrobinChildren\000".getBytes(), 0)), sEXP), util__.getListElement(sEXP10, (Ptr)new BytePtr("name\000".getBytes(), 0)), sEXP), grid__.R_gridEvalEnv);
            } else {
              SEXP sEXP = grid__.R_gridEvalEnv;
              Rinternals.Rf_protect(Rinternals.Rf_findFun(Rinternals.Rf_install(new BytePtr("findGrobinDL\000".getBytes(), 0)), sEXP));
              Rinternals.Rf_protect(Rinternals.Rf_lang2(Rinternals.Rf_findFun(Rinternals.Rf_install(new BytePtr("findGrobinDL\000".getBytes(), 0)), sEXP), util__.getListElement(sEXP10, (Ptr)new BytePtr("name\000".getBytes(), 0))));
              sEXP10 = Rinternals.Rf_eval(Rinternals.Rf_lang2(Rinternals.Rf_findFun(Rinternals.Rf_install(new BytePtr("findGrobinDL\000".getBytes(), 0)), sEXP), util__.getListElement(sEXP10, (Ptr)new BytePtr("name\000".getBytes(), 0))), grid__.R_gridEvalEnv);
            }  
          Rinternals.Rf_protect(Rinternals.Rf_lang2(sEXP9, sEXP10));
          sEXP9 = Rinternals.Rf_eval(Rinternals.Rf_lang2(sEXP9, sEXP10), grid__.R_gridEvalEnv);
          Rinternals.Rf_protect(sEXP9);
          Rinternals.Rf_protect(Rinternals.Rf_lang2(sEXP8, sEXP9));
          Rinternals.Rf_protect(Rinternals.Rf_eval(Rinternals.Rf_lang2(sEXP8, sEXP9), grid__.R_gridEvalEnv));
          int j = pureNullUnit(Rinternals.Rf_eval(Rinternals.Rf_lang2(sEXP8, sEXP9), grid__.R_gridEvalEnv), 0, paramPtr);
          Rinternals.Rf_protect(Rinternals.Rf_lang2(sEXP7, sEXP9));
          Rinternals.Rf_eval(Rinternals.Rf_lang2(sEXP7, sEXP9), grid__.R_gridEvalEnv);
          state__.setGridStateElement(paramPtr, 5, sEXP2);
          state__.setGridStateElement(paramPtr, 12, sEXP1);
          return j;
        } 
        SEXP sEXP6 = unitData(sEXP1, sEXP2);
        Rinternals.Rf_protect(sEXP6);
        sEXP2 = state__.gridStateElement(paramPtr, 5);
        Rinternals.Rf_protect(sEXP2);
        sEXP1 = state__.gridStateElement(paramPtr, 12);
        Rinternals.Rf_protect(sEXP1);
        SEXP sEXP3 = grid__.R_gridEvalEnv;
        SEXP sEXP5 = Rinternals.Rf_findFun(Rinternals.Rf_install(new BytePtr("preDraw\000".getBytes(), 0)), sEXP3);
        Rinternals.Rf_protect(sEXP5);
        sEXP3 = grid__.R_gridEvalEnv;
        SEXP sEXP4 = Rinternals.Rf_findFun(Rinternals.Rf_install(new BytePtr("width\000".getBytes(), 0)), sEXP3);
        Rinternals.Rf_protect(sEXP4);
        sEXP3 = grid__.R_gridEvalEnv;
        sEXP3 = Rinternals.Rf_findFun(Rinternals.Rf_install(new BytePtr("postDraw\000".getBytes(), 0)), sEXP3);
        Rinternals.Rf_protect(sEXP3);
        if (Rinternals.Rf_inherits(sEXP6, new BytePtr("gPath\000".getBytes(), 0)))
          if (!Rinternals.Rf_isNull(sEXP1)) {
            SEXP sEXP = grid__.R_gridEvalEnv;
            Rinternals.Rf_protect(Rinternals.Rf_findFun(Rinternals.Rf_install(new BytePtr("findGrobinChildren\000".getBytes(), 0)), sEXP));
            sEXP = util__.getListElement(sEXP1, (Ptr)new BytePtr("children\000".getBytes(), 0));
            Rinternals.Rf_protect(Rinternals.Rf_lang3(Rinternals.Rf_findFun(Rinternals.Rf_install(new BytePtr("findGrobinChildren\000".getBytes(), 0)), sEXP), util__.getListElement(sEXP6, (Ptr)new BytePtr("name\000".getBytes(), 0)), sEXP));
            sEXP6 = Rinternals.Rf_eval(Rinternals.Rf_lang3(Rinternals.Rf_findFun(Rinternals.Rf_install(new BytePtr("findGrobinChildren\000".getBytes(), 0)), sEXP), util__.getListElement(sEXP6, (Ptr)new BytePtr("name\000".getBytes(), 0)), sEXP), grid__.R_gridEvalEnv);
          } else {
            SEXP sEXP = grid__.R_gridEvalEnv;
            Rinternals.Rf_protect(Rinternals.Rf_findFun(Rinternals.Rf_install(new BytePtr("findGrobinDL\000".getBytes(), 0)), sEXP));
            Rinternals.Rf_protect(Rinternals.Rf_lang2(Rinternals.Rf_findFun(Rinternals.Rf_install(new BytePtr("findGrobinDL\000".getBytes(), 0)), sEXP), util__.getListElement(sEXP6, (Ptr)new BytePtr("name\000".getBytes(), 0))));
            sEXP6 = Rinternals.Rf_eval(Rinternals.Rf_lang2(Rinternals.Rf_findFun(Rinternals.Rf_install(new BytePtr("findGrobinDL\000".getBytes(), 0)), sEXP), util__.getListElement(sEXP6, (Ptr)new BytePtr("name\000".getBytes(), 0))), grid__.R_gridEvalEnv);
          }  
        Rinternals.Rf_protect(Rinternals.Rf_lang2(sEXP5, sEXP6));
        sEXP5 = Rinternals.Rf_eval(Rinternals.Rf_lang2(sEXP5, sEXP6), grid__.R_gridEvalEnv);
        Rinternals.Rf_protect(sEXP5);
        Rinternals.Rf_protect(Rinternals.Rf_lang2(sEXP4, sEXP5));
        Rinternals.Rf_protect(Rinternals.Rf_eval(Rinternals.Rf_lang2(sEXP4, sEXP5), grid__.R_gridEvalEnv));
        int i = pureNullUnit(Rinternals.Rf_eval(Rinternals.Rf_lang2(sEXP4, sEXP5), grid__.R_gridEvalEnv), 0, paramPtr);
        Rinternals.Rf_protect(Rinternals.Rf_lang2(sEXP3, sEXP5));
        Rinternals.Rf_eval(Rinternals.Rf_lang2(sEXP3, sEXP5), grid__.R_gridEvalEnv);
        state__.setGridStateElement(paramPtr, 5, sEXP2);
        state__.setGridStateElement(paramPtr, 12, sEXP1);
        return i;
      } 
      return pureNullUnit(Rinternals.VECTOR_ELT(sEXP1, sEXP2 % unitLength(sEXP1)), 0, paramPtr);
    } 
    return pureNullUnitArithmetic(sEXP1, sEXP2, paramPtr);
  }
  
  public static int pureNullUnitArithmetic(SEXP paramSEXP, int paramInt, Ptr paramPtr) {
    boolean bool;
    null = 0;
    if (addOp(paramSEXP) == 0 && minusOp(paramSEXP) == 0) {
      if (timesOp(paramSEXP) == 0) {
        if (minFunc(paramSEXP) == 0 && maxFunc(paramSEXP) == 0 && sumFunc(paramSEXP) == 0) {
          Error.Rf_error(GetText.dgettext(new BytePtr("grid\000".getBytes(), 0), new BytePtr("unimplemented unit function\000".getBytes(), 0)), new Object[0]);
          return null;
        } 
        paramInt = unitLength(arg1(paramSEXP));
        byte b = 0;
        null = 1;
        while (null && b < paramInt) {
          if (!null || pureNullUnit(arg1(paramSEXP), b, paramPtr) == 0) {
            null = 0;
          } else {
            null = 1;
          } 
          null = null;
          b++;
        } 
        return null;
      } 
      return pureNullUnit(arg2(paramSEXP), paramInt, paramPtr);
    } 
    if (pureNullUnit(arg1(paramSEXP), paramInt, paramPtr) == 0 || pureNullUnit(arg2(paramSEXP), paramInt, paramPtr) == 0) {
      bool = false;
    } else {
      bool = true;
    } 
    return bool;
  }
  
  public static double pureNullUnitValue(SEXP paramSEXP, int paramInt) {
    if (isUnitArithmetic(paramSEXP) != 0)
      if (addOp(paramSEXP) == 0) {
        if (minusOp(paramSEXP) == 0) {
          if (timesOp(paramSEXP) == 0) {
            if (minFunc(paramSEXP) == 0) {
              if (maxFunc(paramSEXP) == 0) {
                if (sumFunc(paramSEXP) == 0) {
                  Error.Rf_error(GetText.dgettext(new BytePtr("grid\000".getBytes(), 0), new BytePtr("unimplemented unit function\000".getBytes(), 0)), new Object[0]);
                } else {
                  paramInt = unitLength(arg1(paramSEXP));
                  double d = 0.0D;
                  for (byte b = 0; b < paramInt; b++)
                    d = pureNullUnitValue(arg1(paramSEXP), b) + d; 
                  return d;
                } 
              } else {
                paramInt = unitLength(arg1(paramSEXP));
                double d = pureNullUnitValue(arg1(paramSEXP), 0);
                for (byte b = 1; b < paramInt; b++) {
                  double d1 = pureNullUnitValue(arg1(paramSEXP), b);
                  if (d1 > d)
                    d = d1; 
                } 
                return d;
              } 
            } else {
              paramInt = unitLength(arg1(paramSEXP));
              double d = pureNullUnitValue(arg1(paramSEXP), 0);
              for (byte b = 1; b < paramInt; b++) {
                double d1 = pureNullUnitValue(arg1(paramSEXP), b);
                if (d1 < d)
                  d = d1; 
              } 
              return d;
            } 
          } else {
            return Rinternals2.REAL(arg1(paramSEXP)).getDouble(0 + paramInt * 8) * pureNullUnitValue(arg2(paramSEXP), paramInt);
          } 
        } else {
          return pureNullUnitValue(arg1(paramSEXP), paramInt) - pureNullUnitValue(arg2(paramSEXP), paramInt);
        } 
      } else {
        return pureNullUnitValue(arg1(paramSEXP), paramInt) + pureNullUnitValue(arg2(paramSEXP), paramInt);
      }  
    return (isUnitList(paramSEXP) == 0) ? unitValue(paramSEXP, paramInt) : pureNullUnitValue(Rinternals.VECTOR_ELT(paramSEXP, paramInt % unitLength(paramSEXP)), 0);
  }
  
  public static int sumFunc(SEXP paramSEXP) {
    return fNameMatch(paramSEXP, (Ptr)new BytePtr("sum\000".getBytes(), 0));
  }
  
  public static int timesOp(SEXP paramSEXP) {
    return fNameMatch(paramSEXP, (Ptr)new BytePtr("*\000".getBytes(), 0));
  }
  
  public static double transform(double paramDouble1, int paramInt1, SEXP paramSEXP, double paramDouble2, double paramDouble3, Ptr paramPtr1, double paramDouble4, double paramDouble5, int paramInt2, int paramInt3, Ptr paramPtr2) {
    double[] arrayOfDouble1 = new double[1];
    double[] arrayOfDouble2 = new double[1];
    double[] arrayOfDouble3 = new double[1];
    arrayOfDouble1[0] = 0.0D;
    arrayOfDouble2[0] = 0.0D;
    arrayOfDouble3[0] = 0.0D;
    paramDouble2 = paramDouble1;
    switch (paramInt1) {
      case 0:
        paramDouble2 = paramDouble1 * paramDouble4 / 2.54D;
        break;
      case 1:
        paramDouble2 = paramDouble1 / 2.54D;
        break;
      case 2:
        break;
      case 18:
      case 104:
        paramDouble2 = paramPtr1.getDouble(52) * paramDouble1 * paramPtr1.getDouble(44) / 72.0D;
        break;
      case 3:
      case 103:
        paramDouble2 = paramPtr1.getDouble(52) * paramDouble1 * paramPtr1.getDouble(44) * paramPtr1.getDouble(60) / 72.0D;
        break;
      case 6:
        if (paramDouble4 > paramDouble5) {
          paramDouble2 = paramDouble1 * paramDouble5 / 2.54D;
          break;
        } 
        paramDouble2 = paramDouble1 * paramDouble4 / 2.54D;
        break;
      case 7:
        paramDouble2 = paramDouble1 / 10.0D / 2.54D;
        break;
      case 8:
        paramDouble2 = paramDouble1 / 72.27D;
        break;
      case 9:
        paramDouble2 = paramDouble1 * 12.0D / 72.27D;
        break;
      case 10:
        paramDouble2 = paramDouble1 / 72.0D;
        break;
      case 11:
        paramDouble2 = paramDouble1 / 1157.0D * 1238.0D / 72.27D;
        break;
      case 12:
        paramDouble2 = paramDouble1 * 12.0D / 1157.0D * 1238.0D / 72.27D;
        break;
      case 13:
        paramDouble2 = paramDouble1 / 65536.0D / 72.27D;
        break;
      case 14:
      case 105:
        if (!Rinternals.Rf_isExpression(paramSEXP)) {
          paramInt2 = Rinternals.Rf_getCharCE(Rinternals.STRING_ELT(paramSEXP, 0));
          paramDouble2 = baseEngine__.GEfromDeviceWidth(baseEngine__.GEStrWidth((Ptr)Rinternals.R_CHAR(Rinternals.STRING_ELT(paramSEXP, 0)), paramInt2, paramPtr1, paramPtr2), 2, paramPtr2) * paramDouble1;
          break;
        } 
        Rinternals.VECTOR_ELT(paramSEXP, 0);
        throw new UnsatisfiedLinkException("GEExpressionWidth");
      case 15:
      case 106:
        if (!Rinternals.Rf_isExpression(paramSEXP)) {
          paramDouble2 = baseEngine__.GEfromDeviceHeight(baseEngine__.GEStrHeight((Ptr)Rinternals.R_CHAR(Rinternals.STRING_ELT(paramSEXP, 0)), -1, paramPtr1, paramPtr2), 2, paramPtr2) * paramDouble1;
          break;
        } 
        Rinternals.VECTOR_ELT(paramSEXP, 0);
        throw new UnsatisfiedLinkException("GEExpressionHeight");
      case 16:
        if (!Rinternals.Rf_isExpression(paramSEXP)) {
          paramInt2 = Rinternals.Rf_getCharCE(Rinternals.STRING_ELT(paramSEXP, 0));
          baseEngine__.GEStrMetric((Ptr)Rinternals.R_CHAR(Rinternals.STRING_ELT(paramSEXP, 0)), paramInt2, paramPtr1, (Ptr)new DoublePtr(arrayOfDouble3, 0), (Ptr)new DoublePtr(arrayOfDouble2, 0), (Ptr)new DoublePtr(arrayOfDouble1, 0), paramPtr2);
          paramDouble2 = baseEngine__.GEfromDeviceHeight(arrayOfDouble3[0], 2, paramPtr2) * paramDouble1;
          break;
        } 
        Rinternals.VECTOR_ELT(paramSEXP, 0);
        throw new UnsatisfiedLinkException("GEExpressionMetric");
      case 17:
        if (!Rinternals.Rf_isExpression(paramSEXP)) {
          paramInt2 = Rinternals.Rf_getCharCE(Rinternals.STRING_ELT(paramSEXP, 0));
          baseEngine__.GEStrMetric((Ptr)Rinternals.R_CHAR(Rinternals.STRING_ELT(paramSEXP, 0)), paramInt2, paramPtr1, (Ptr)new DoublePtr(arrayOfDouble3, 0), (Ptr)new DoublePtr(arrayOfDouble2, 0), (Ptr)new DoublePtr(arrayOfDouble1, 0), paramPtr2);
          paramDouble2 = baseEngine__.GEfromDeviceHeight(arrayOfDouble2[0], 2, paramPtr2) * paramDouble1;
          break;
        } 
        Rinternals.VECTOR_ELT(paramSEXP, 0);
        throw new UnsatisfiedLinkException("GEExpressionMetric");
      case 19:
        paramDouble2 = evaluateGrobXUnit(paramDouble1, paramSEXP, paramDouble4, paramDouble5, paramInt2, paramInt3, paramPtr2);
        break;
      case 20:
        paramDouble2 = evaluateGrobYUnit(paramDouble1, paramSEXP, paramDouble5, paramDouble4, paramInt2, paramInt3, paramPtr2);
        break;
      case 21:
        paramDouble2 = evaluateGrobWidthUnit(paramSEXP, paramDouble4, paramDouble5, paramInt2, paramInt3, paramPtr2) * paramDouble1;
        break;
      case 22:
        paramDouble2 = evaluateGrobHeightUnit(paramSEXP, paramDouble5, paramDouble4, paramInt2, paramInt3, paramPtr2) * paramDouble1;
        break;
      case 23:
        paramDouble2 = evaluateGrobAscentUnit(paramSEXP, paramDouble5, paramDouble4, paramInt2, paramInt3, paramPtr2) * paramDouble1;
        break;
      case 24:
        paramDouble2 = evaluateGrobDescentUnit(paramSEXP, paramDouble5, paramDouble4, paramInt2, paramInt3, paramPtr2) * paramDouble1;
        break;
      case 5:
        paramDouble2 = evaluateNullUnit(paramDouble1, paramDouble4, paramInt2, paramInt3);
        break;
      default:
        Error.Rf_error(GetText.dgettext(new BytePtr("grid\000".getBytes(), 0), new BytePtr("invalid unit or unit not yet implemented\000".getBytes(), 0)), new Object[0]);
        break;
    } 
    switch (paramInt1) {
      case 1:
      case 2:
      case 7:
      case 8:
      case 9:
      case 10:
      case 11:
      case 12:
      case 13:
        paramDouble2 = Rinternals2.REAL(state__.gridStateElement(paramPtr2, 15)).getDouble() * paramDouble2;
        break;
    } 
    return paramDouble2;
  }
  
  public static double transformDimension(double paramDouble1, int paramInt1, SEXP paramSEXP, double paramDouble2, double paramDouble3, Ptr paramPtr1, double paramDouble4, double paramDouble5, int paramInt2, int paramInt3, Ptr paramPtr2) {
    switch (paramInt1) {
      case 4:
        return paramDouble1 / (paramDouble3 - paramDouble2) * paramDouble4 / 2.54D;
    } 
    return transform(paramDouble1, paramInt1, paramSEXP, paramDouble2, paramDouble3, paramPtr1, paramDouble4, paramDouble5, paramInt2, paramInt3, paramPtr2);
  }
  
  public static void transformDimn(SEXP paramSEXP1, SEXP paramSEXP2, int paramInt, Ptr paramPtr1, Ptr paramPtr2, double paramDouble1, double paramDouble2, Ptr paramPtr3, double paramDouble3, Ptr paramPtr4, Ptr paramPtr5) {
    double[] arrayOfDouble3 = new double[3];
    paramPtr4.setDouble(transformWidthtoINCHES(paramSEXP1, paramInt, paramPtr1.copyOf(32), paramPtr2, paramDouble1, paramDouble2, paramPtr3));
    paramPtr5.setDouble(transformHeighttoINCHES(paramSEXP2, paramInt, paramPtr1.copyOf(32), paramPtr2, paramDouble1, paramDouble2, paramPtr3));
    paramDouble1 = paramPtr5.getDouble();
    double[] arrayOfDouble2 = new double[3];
    matrix__.location(paramPtr4.getDouble(), paramDouble1, (Ptr)new DoublePtr(arrayOfDouble2, 0));
    double[] arrayOfDouble1 = new double[9];
    matrix__.rotation(paramDouble3, (Ptr)new DoublePtr(arrayOfDouble1, 0));
    matrix__.trans((Ptr)new DoublePtr(arrayOfDouble2, 0), (Ptr)new DoublePtr(arrayOfDouble1, 0), (Ptr)new DoublePtr(arrayOfDouble3, 0));
    paramPtr4.setDouble(matrix__.locationX((Ptr)new DoublePtr(arrayOfDouble3, 0)));
    paramPtr5.setDouble(matrix__.locationY((Ptr)new DoublePtr(arrayOfDouble3, 0)));
  }
  
  public static double transformFromINCHES(double paramDouble1, int paramInt, Ptr paramPtr1, double paramDouble2, double paramDouble3, Ptr paramPtr2) {
    paramDouble3 = paramDouble1;
    switch (paramInt) {
      case 0:
        paramDouble3 = paramDouble1 / paramDouble2 / 2.54D;
        break;
      case 1:
        paramDouble3 = paramDouble1 * 2.54D;
        break;
      case 2:
        break;
      case 18:
        paramDouble3 = paramDouble1 * 72.0D / paramPtr1.getDouble(52) * paramPtr1.getDouble(44);
        break;
      case 3:
        paramDouble3 = paramDouble1 * 72.0D / paramPtr1.getDouble(52) * paramPtr1.getDouble(44) * paramPtr1.getDouble(60);
        break;
      case 7:
        paramDouble3 = paramDouble1 * 2.54D * 10.0D;
        break;
      case 8:
        paramDouble3 = paramDouble1 * 72.27D;
        break;
      case 9:
        paramDouble3 = paramDouble1 / 12.0D * 72.27D;
        break;
      case 10:
        paramDouble3 = paramDouble1 * 72.0D;
        break;
      case 11:
        paramDouble3 = paramDouble1 / 1238.0D * 1157.0D * 72.27D;
        break;
      case 12:
        paramDouble3 = paramDouble1 / 1238.0D * 1157.0D * 72.27D / 12.0D;
        break;
      case 13:
        paramDouble3 = paramDouble1 * 65536.0D * 72.27D;
        break;
      default:
        Error.Rf_error(GetText.dgettext(new BytePtr("grid\000".getBytes(), 0), new BytePtr("invalid unit or unit not yet implemented\000".getBytes(), 0)), new Object[0]);
        break;
    } 
    switch (paramInt) {
      case 1:
      case 2:
      case 7:
      case 8:
      case 9:
      case 10:
      case 11:
      case 12:
      case 13:
        paramDouble3 /= Rinternals2.REAL(state__.gridStateElement(paramPtr2, 15)).getDouble();
        break;
    } 
    return paramDouble3;
  }
  
  public static double transformHeight(SEXP paramSEXP, int paramInt1, Ptr paramPtr1, Ptr paramPtr2, double paramDouble1, double paramDouble2, int paramInt2, int paramInt3, Ptr paramPtr3) {
    if (isUnitArithmetic(paramSEXP) == 0) {
      if (isUnitList(paramSEXP) == 0) {
        if (paramInt3 != 0) {
          paramInt3 = paramInt3;
        } else {
          paramInt3 = 4;
        } 
        Rinternals.Rf_protect(unitData(paramSEXP, paramInt1));
        double d = paramPtr1.getAlignedDouble(3);
        return transformDimension(unitValue(paramSEXP, paramInt1), unitUnit(paramSEXP, paramInt1), unitData(paramSEXP, paramInt1), paramPtr1.getAlignedDouble(2), d, paramPtr2, paramDouble2, paramDouble1, paramInt2, paramInt3, paramPtr3);
      } 
      return transformHeight(Rinternals.VECTOR_ELT(paramSEXP, paramInt1 % unitLength(paramSEXP)), 0, paramPtr1.copyOf(32), paramPtr2, paramDouble1, paramDouble2, paramInt2, paramInt3, paramPtr3);
    } 
    return transformHeightArithmetic(paramSEXP, paramInt1, paramPtr1.copyOf(32), paramPtr2, paramDouble1, paramDouble2, paramInt2, paramPtr3);
  }
  
  public static double transformHeightArithmetic(SEXP paramSEXP, int paramInt1, Ptr paramPtr1, Ptr paramPtr2, double paramDouble1, double paramDouble2, int paramInt2, Ptr paramPtr3) {
    null = 0.0D;
    if (addOp(paramSEXP) == 0) {
      if (minusOp(paramSEXP) == 0) {
        if (timesOp(paramSEXP) == 0) {
          if (minFunc(paramSEXP) == 0) {
            if (maxFunc(paramSEXP) == 0) {
              if (sumFunc(paramSEXP) == 0) {
                Error.Rf_error(GetText.dgettext(new BytePtr("grid\000".getBytes(), 0), new BytePtr("unimplemented unit function\000".getBytes(), 0)), new Object[0]);
                return null;
              } 
              paramInt1 = unitLength(arg1(paramSEXP));
              null = 0.0D;
              for (byte b2 = 0; b2 < paramInt1; b2++)
                null = transformHeight(arg1(paramSEXP), b2, paramPtr1.copyOf(32), paramPtr2, paramDouble1, paramDouble2, paramInt2, 3, paramPtr3) + null; 
              return null;
            } 
            paramInt1 = unitLength(arg1(paramSEXP));
            null = transformHeight(arg1(paramSEXP), 0, paramPtr1.copyOf(32), paramPtr2, paramDouble1, paramDouble2, paramInt2, 5, paramPtr3);
            for (byte b1 = 1; b1 < paramInt1; b1++) {
              double d = transformHeight(arg1(paramSEXP), b1, paramPtr1.copyOf(32), paramPtr2, paramDouble1, paramDouble2, paramInt2, 5, paramPtr3);
              if (d > null)
                null = d; 
            } 
            return null;
          } 
          paramInt1 = unitLength(arg1(paramSEXP));
          null = transformHeight(arg1(paramSEXP), 0, paramPtr1.copyOf(32), paramPtr2, paramDouble1, paramDouble2, paramInt2, 6, paramPtr3);
          for (byte b = 1; b < paramInt1; b++) {
            double d = transformHeight(arg1(paramSEXP), b, paramPtr1.copyOf(32), paramPtr2, paramDouble1, paramDouble2, paramInt2, 6, paramPtr3);
            if (d < null)
              null = d; 
          } 
          return null;
        } 
        return Rinternals2.REAL(arg1(paramSEXP)).getDouble(0 + paramInt1 % Rinternals.LENGTH(arg1(paramSEXP)) * 8) * transformHeight(arg2(paramSEXP), paramInt1, paramPtr1.copyOf(32), paramPtr2, paramDouble1, paramDouble2, paramInt2, 7, paramPtr3);
      } 
      return transformHeight(arg1(paramSEXP), paramInt1, paramPtr1.copyOf(32), paramPtr2, paramDouble1, paramDouble2, paramInt2, 2, paramPtr3) - transformHeight(arg2(paramSEXP), paramInt1, paramPtr1.copyOf(32), paramPtr2, paramDouble1, paramDouble2, paramInt2, 2, paramPtr3);
    } 
    return transformHeight(arg1(paramSEXP), paramInt1, paramPtr1.copyOf(32), paramPtr2, paramDouble1, paramDouble2, paramInt2, 1, paramPtr3) + transformHeight(arg2(paramSEXP), paramInt1, paramPtr1.copyOf(32), paramPtr2, paramDouble1, paramDouble2, paramInt2, 1, paramPtr3);
  }
  
  public static double transformHeighttoINCHES(SEXP paramSEXP, int paramInt, Ptr paramPtr1, Ptr paramPtr2, double paramDouble1, double paramDouble2, Ptr paramPtr3) {
    return transformHeight(paramSEXP, paramInt, paramPtr1.copyOf(32), paramPtr2, paramDouble1, paramDouble2, 0, 0, paramPtr3);
  }
  
  public static double transformLocation(double paramDouble1, int paramInt1, SEXP paramSEXP, double paramDouble2, double paramDouble3, Ptr paramPtr1, double paramDouble4, double paramDouble5, int paramInt2, int paramInt3, Ptr paramPtr2) {
    switch (paramInt1) {
      case 4:
        return (paramDouble1 - paramDouble2) / (paramDouble3 - paramDouble2) * paramDouble4 / 2.54D;
    } 
    return transform(paramDouble1, paramInt1, paramSEXP, paramDouble2, paramDouble3, paramPtr1, paramDouble4, paramDouble5, paramInt2, paramInt3, paramPtr2);
  }
  
  public static void transformLocn(SEXP paramSEXP1, SEXP paramSEXP2, int paramInt, Ptr paramPtr1, Ptr paramPtr2, double paramDouble1, double paramDouble2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6) {
    double[] arrayOfDouble2 = new double[3];
    paramPtr5.setDouble(transformXtoINCHES(paramSEXP1, paramInt, paramPtr1.copyOf(32), paramPtr2, paramDouble1, paramDouble2, paramPtr3));
    paramPtr6.setDouble(transformYtoINCHES(paramSEXP2, paramInt, paramPtr1.copyOf(32), paramPtr2, paramDouble1, paramDouble2, paramPtr3));
    paramDouble1 = paramPtr6.getDouble();
    double[] arrayOfDouble1 = new double[3];
    matrix__.location(paramPtr5.getDouble(), paramDouble1, (Ptr)new DoublePtr(arrayOfDouble1, 0));
    matrix__.trans((Ptr)new DoublePtr(arrayOfDouble1, 0), paramPtr4, (Ptr)new DoublePtr(arrayOfDouble2, 0));
    paramPtr5.setDouble(matrix__.locationX((Ptr)new DoublePtr(arrayOfDouble2, 0)));
    paramPtr6.setDouble(matrix__.locationY((Ptr)new DoublePtr(arrayOfDouble2, 0)));
  }
  
  public static double transformWHfromNPC(double paramDouble1, int paramInt, double paramDouble2, double paramDouble3) {
    double d = paramDouble1;
    switch (paramInt) {
      case 0:
        return d;
      case 4:
        d = (paramDouble3 - paramDouble2) * paramDouble1;
    } 
    Error.Rf_error(GetText.dgettext(new BytePtr("grid\000".getBytes(), 0), new BytePtr("Unsupported unit conversion\000".getBytes(), 0)), new Object[0]);
  }
  
  public static double transformWHtoNPC(double paramDouble1, int paramInt, double paramDouble2, double paramDouble3) {
    double d = paramDouble1;
    switch (paramInt) {
      case 0:
        return d;
      case 4:
        d = paramDouble1 / (paramDouble3 - paramDouble2);
    } 
    Error.Rf_error(GetText.dgettext(new BytePtr("grid\000".getBytes(), 0), new BytePtr("Unsupported unit conversion\000".getBytes(), 0)), new Object[0]);
  }
  
  public static double transformWidth(SEXP paramSEXP, int paramInt1, Ptr paramPtr1, Ptr paramPtr2, double paramDouble1, double paramDouble2, int paramInt2, int paramInt3, Ptr paramPtr3) {
    if (isUnitArithmetic(paramSEXP) == 0) {
      if (isUnitList(paramSEXP) == 0) {
        if (paramInt3 != 0) {
          paramInt3 = paramInt3;
        } else {
          paramInt3 = 4;
        } 
        Rinternals.Rf_protect(unitData(paramSEXP, paramInt1));
        double d = paramPtr1.getAlignedDouble(1);
        return transformDimension(unitValue(paramSEXP, paramInt1), unitUnit(paramSEXP, paramInt1), unitData(paramSEXP, paramInt1), paramPtr1.getDouble(), d, paramPtr2, paramDouble1, paramDouble2, paramInt2, paramInt3, paramPtr3);
      } 
      return transformWidth(Rinternals.VECTOR_ELT(paramSEXP, paramInt1 % unitLength(paramSEXP)), 0, paramPtr1.copyOf(32), paramPtr2, paramDouble1, paramDouble2, paramInt2, paramInt3, paramPtr3);
    } 
    return transformWidthArithmetic(paramSEXP, paramInt1, paramPtr1.copyOf(32), paramPtr2, paramDouble1, paramDouble2, paramInt2, paramPtr3);
  }
  
  public static double transformWidthArithmetic(SEXP paramSEXP, int paramInt1, Ptr paramPtr1, Ptr paramPtr2, double paramDouble1, double paramDouble2, int paramInt2, Ptr paramPtr3) {
    null = 0.0D;
    if (addOp(paramSEXP) == 0) {
      if (minusOp(paramSEXP) == 0) {
        if (timesOp(paramSEXP) == 0) {
          if (minFunc(paramSEXP) == 0) {
            if (maxFunc(paramSEXP) == 0) {
              if (sumFunc(paramSEXP) == 0) {
                Error.Rf_error(GetText.dgettext(new BytePtr("grid\000".getBytes(), 0), new BytePtr("unimplemented unit function\000".getBytes(), 0)), new Object[0]);
                return null;
              } 
              paramInt1 = unitLength(arg1(paramSEXP));
              null = 0.0D;
              for (byte b2 = 0; b2 < paramInt1; b2++)
                null = transformWidth(arg1(paramSEXP), b2, paramPtr1.copyOf(32), paramPtr2, paramDouble1, paramDouble2, paramInt2, 3, paramPtr3) + null; 
              return null;
            } 
            paramInt1 = unitLength(arg1(paramSEXP));
            null = transformWidth(arg1(paramSEXP), 0, paramPtr1.copyOf(32), paramPtr2, paramDouble1, paramDouble2, paramInt2, 5, paramPtr3);
            for (byte b1 = 1; b1 < paramInt1; b1++) {
              double d = transformWidth(arg1(paramSEXP), b1, paramPtr1.copyOf(32), paramPtr2, paramDouble1, paramDouble2, paramInt2, 5, paramPtr3);
              if (d > null)
                null = d; 
            } 
            return null;
          } 
          paramInt1 = unitLength(arg1(paramSEXP));
          null = transformWidth(arg1(paramSEXP), 0, paramPtr1.copyOf(32), paramPtr2, paramDouble1, paramDouble2, paramInt2, 6, paramPtr3);
          for (byte b = 1; b < paramInt1; b++) {
            double d = transformWidth(arg1(paramSEXP), b, paramPtr1.copyOf(32), paramPtr2, paramDouble1, paramDouble2, paramInt2, 6, paramPtr3);
            if (d < null)
              null = d; 
          } 
          return null;
        } 
        return Rinternals2.REAL(arg1(paramSEXP)).getDouble(0 + paramInt1 % Rinternals.LENGTH(arg1(paramSEXP)) * 8) * transformWidth(arg2(paramSEXP), paramInt1, paramPtr1.copyOf(32), paramPtr2, paramDouble1, paramDouble2, paramInt2, 7, paramPtr3);
      } 
      return transformWidth(arg1(paramSEXP), paramInt1, paramPtr1.copyOf(32), paramPtr2, paramDouble1, paramDouble2, paramInt2, 2, paramPtr3) - transformWidth(arg2(paramSEXP), paramInt1, paramPtr1.copyOf(32), paramPtr2, paramDouble1, paramDouble2, paramInt2, 2, paramPtr3);
    } 
    return transformWidth(arg1(paramSEXP), paramInt1, paramPtr1.copyOf(32), paramPtr2, paramDouble1, paramDouble2, paramInt2, 1, paramPtr3) + transformWidth(arg2(paramSEXP), paramInt1, paramPtr1.copyOf(32), paramPtr2, paramDouble1, paramDouble2, paramInt2, 1, paramPtr3);
  }
  
  public static double transformWidthHeightFromINCHES(double paramDouble1, int paramInt, double paramDouble2, double paramDouble3, Ptr paramPtr1, double paramDouble4, double paramDouble5, Ptr paramPtr2) {
    double d = paramDouble1;
    if ((paramInt != 4 && paramInt != 0) || paramDouble4 >= 1.0E-6D) {
      switch (paramInt) {
        case 4:
          return paramDouble1 / paramDouble4 / 2.54D * (paramDouble3 - paramDouble2);
      } 
      return transformFromINCHES(paramDouble1, paramInt, paramPtr1, paramDouble4, paramDouble5, paramPtr2);
    } 
    if (paramDouble1 != 0.0D)
      Error.Rf_error(GetText.dgettext(new BytePtr("grid\000".getBytes(), 0), new BytePtr("Viewport has zero dimension(s)\000".getBytes(), 0)), new Object[0]); 
    return d;
  }
  
  public static double transformWidthtoINCHES(SEXP paramSEXP, int paramInt, Ptr paramPtr1, Ptr paramPtr2, double paramDouble1, double paramDouble2, Ptr paramPtr3) {
    return transformWidth(paramSEXP, paramInt, paramPtr1.copyOf(32), paramPtr2, paramDouble1, paramDouble2, 0, 0, paramPtr3);
  }
  
  public static double transformX(SEXP paramSEXP, int paramInt1, Ptr paramPtr1, Ptr paramPtr2, double paramDouble1, double paramDouble2, int paramInt2, int paramInt3, Ptr paramPtr3) {
    if (isUnitArithmetic(paramSEXP) == 0) {
      if (isUnitList(paramSEXP) == 0) {
        if (paramInt3 != 0) {
          paramInt3 = paramInt3;
        } else {
          paramInt3 = 4;
        } 
        Rinternals.Rf_protect(unitData(paramSEXP, paramInt1));
        double d = paramPtr1.getAlignedDouble(1);
        return transformLocation(unitValue(paramSEXP, paramInt1), unitUnit(paramSEXP, paramInt1), unitData(paramSEXP, paramInt1), paramPtr1.getDouble(), d, paramPtr2, paramDouble1, paramDouble2, paramInt2, paramInt3, paramPtr3);
      } 
      return transformX(Rinternals.VECTOR_ELT(paramSEXP, paramInt1 % unitLength(paramSEXP)), 0, paramPtr1.copyOf(32), paramPtr2, paramDouble1, paramDouble2, paramInt2, paramInt3, paramPtr3);
    } 
    return transformXArithmetic(paramSEXP, paramInt1, paramPtr1.copyOf(32), paramPtr2, paramDouble1, paramDouble2, paramInt2, paramPtr3);
  }
  
  public static double transformXArithmetic(SEXP paramSEXP, int paramInt1, Ptr paramPtr1, Ptr paramPtr2, double paramDouble1, double paramDouble2, int paramInt2, Ptr paramPtr3) {
    null = 0.0D;
    if (addOp(paramSEXP) == 0) {
      if (minusOp(paramSEXP) == 0) {
        if (timesOp(paramSEXP) == 0) {
          if (minFunc(paramSEXP) == 0) {
            if (maxFunc(paramSEXP) == 0) {
              if (sumFunc(paramSEXP) == 0) {
                Error.Rf_error(GetText.dgettext(new BytePtr("grid\000".getBytes(), 0), new BytePtr("unimplemented unit function\000".getBytes(), 0)), new Object[0]);
                return null;
              } 
              paramInt1 = unitLength(arg1(paramSEXP));
              null = 0.0D;
              for (byte b2 = 0; b2 < paramInt1; b2++)
                null = transformX(arg1(paramSEXP), b2, paramPtr1.copyOf(32), paramPtr2, paramDouble1, paramDouble2, paramInt2, 3, paramPtr3) + null; 
              return null;
            } 
            paramInt1 = unitLength(arg1(paramSEXP));
            null = transformX(arg1(paramSEXP), 0, paramPtr1.copyOf(32), paramPtr2, paramDouble1, paramDouble2, paramInt2, 5, paramPtr3);
            for (byte b1 = 1; b1 < paramInt1; b1++) {
              double d = transformX(arg1(paramSEXP), b1, paramPtr1.copyOf(32), paramPtr2, paramDouble1, paramDouble2, paramInt2, 5, paramPtr3);
              if (d > null)
                null = d; 
            } 
            return null;
          } 
          paramInt1 = unitLength(arg1(paramSEXP));
          null = transformX(arg1(paramSEXP), 0, paramPtr1.copyOf(32), paramPtr2, paramDouble1, paramDouble2, paramInt2, 6, paramPtr3);
          for (byte b = 1; b < paramInt1; b++) {
            double d = transformX(arg1(paramSEXP), b, paramPtr1.copyOf(32), paramPtr2, paramDouble1, paramDouble2, paramInt2, 6, paramPtr3);
            if (d < null)
              null = d; 
          } 
          return null;
        } 
        return Rinternals2.REAL(arg1(paramSEXP)).getDouble(0 + paramInt1 % Rinternals.LENGTH(arg1(paramSEXP)) * 8) * transformX(arg2(paramSEXP), paramInt1, paramPtr1.copyOf(32), paramPtr2, paramDouble1, paramDouble2, paramInt2, 7, paramPtr3);
      } 
      return transformX(arg1(paramSEXP), paramInt1, paramPtr1.copyOf(32), paramPtr2, paramDouble1, paramDouble2, paramInt2, 2, paramPtr3) - transformX(arg2(paramSEXP), paramInt1, paramPtr1.copyOf(32), paramPtr2, paramDouble1, paramDouble2, paramInt2, 2, paramPtr3);
    } 
    return transformX(arg1(paramSEXP), paramInt1, paramPtr1.copyOf(32), paramPtr2, paramDouble1, paramDouble2, paramInt2, 1, paramPtr3) + transformX(arg2(paramSEXP), paramInt1, paramPtr1.copyOf(32), paramPtr2, paramDouble1, paramDouble2, paramInt2, 1, paramPtr3);
  }
  
  public static double transformXYFromINCHES(double paramDouble1, int paramInt, double paramDouble2, double paramDouble3, Ptr paramPtr1, double paramDouble4, double paramDouble5, Ptr paramPtr2) {
    double d = paramDouble1;
    if ((paramInt != 4 && paramInt != 0) || paramDouble4 >= 1.0E-6D) {
      switch (paramInt) {
        case 4:
          return paramDouble1 / paramDouble4 / 2.54D * (paramDouble3 - paramDouble2) + paramDouble2;
      } 
      return transformFromINCHES(paramDouble1, paramInt, paramPtr1, paramDouble4, paramDouble5, paramPtr2);
    } 
    if (paramDouble1 != 0.0D)
      Error.Rf_error(GetText.dgettext(new BytePtr("grid\000".getBytes(), 0), new BytePtr("Viewport has zero dimension(s)\000".getBytes(), 0)), new Object[0]); 
    return d;
  }
  
  public static double transformXYfromNPC(double paramDouble1, int paramInt, double paramDouble2, double paramDouble3) {
    double d = paramDouble1;
    switch (paramInt) {
      case 0:
        return d;
      case 4:
        d = (paramDouble3 - paramDouble2) * paramDouble1 + paramDouble2;
    } 
    Error.Rf_error(GetText.dgettext(new BytePtr("grid\000".getBytes(), 0), new BytePtr("Unsupported unit conversion\000".getBytes(), 0)), new Object[0]);
  }
  
  public static double transformXYtoNPC(double paramDouble1, int paramInt, double paramDouble2, double paramDouble3) {
    double d = paramDouble1;
    switch (paramInt) {
      case 0:
        return d;
      case 4:
        d = (paramDouble1 - paramDouble2) / (paramDouble3 - paramDouble2);
    } 
    Error.Rf_error(GetText.dgettext(new BytePtr("grid\000".getBytes(), 0), new BytePtr("Unsupported unit conversion\000".getBytes(), 0)), new Object[0]);
  }
  
  public static double transformXtoINCHES(SEXP paramSEXP, int paramInt, Ptr paramPtr1, Ptr paramPtr2, double paramDouble1, double paramDouble2, Ptr paramPtr3) {
    return transformX(paramSEXP, paramInt, paramPtr1.copyOf(32), paramPtr2, paramDouble1, paramDouble2, 0, 0, paramPtr3);
  }
  
  public static double transformY(SEXP paramSEXP, int paramInt1, Ptr paramPtr1, Ptr paramPtr2, double paramDouble1, double paramDouble2, int paramInt2, int paramInt3, Ptr paramPtr3) {
    if (isUnitArithmetic(paramSEXP) == 0) {
      if (isUnitList(paramSEXP) == 0) {
        if (paramInt3 != 0) {
          paramInt3 = paramInt3;
        } else {
          paramInt3 = 4;
        } 
        Rinternals.Rf_protect(unitData(paramSEXP, paramInt1));
        double d = paramPtr1.getAlignedDouble(3);
        return transformLocation(unitValue(paramSEXP, paramInt1), unitUnit(paramSEXP, paramInt1), unitData(paramSEXP, paramInt1), paramPtr1.getAlignedDouble(2), d, paramPtr2, paramDouble2, paramDouble1, paramInt2, paramInt3, paramPtr3);
      } 
      return transformY(Rinternals.VECTOR_ELT(paramSEXP, paramInt1 % unitLength(paramSEXP)), 0, paramPtr1.copyOf(32), paramPtr2, paramDouble1, paramDouble2, paramInt2, paramInt3, paramPtr3);
    } 
    return transformYArithmetic(paramSEXP, paramInt1, paramPtr1.copyOf(32), paramPtr2, paramDouble1, paramDouble2, paramInt2, paramPtr3);
  }
  
  public static double transformYArithmetic(SEXP paramSEXP, int paramInt1, Ptr paramPtr1, Ptr paramPtr2, double paramDouble1, double paramDouble2, int paramInt2, Ptr paramPtr3) {
    null = 0.0D;
    if (addOp(paramSEXP) == 0) {
      if (minusOp(paramSEXP) == 0) {
        if (timesOp(paramSEXP) == 0) {
          if (minFunc(paramSEXP) == 0) {
            if (maxFunc(paramSEXP) == 0) {
              if (sumFunc(paramSEXP) == 0) {
                Error.Rf_error(GetText.dgettext(new BytePtr("grid\000".getBytes(), 0), new BytePtr("unimplemented unit function\000".getBytes(), 0)), new Object[0]);
                return null;
              } 
              paramInt1 = unitLength(arg1(paramSEXP));
              null = 0.0D;
              for (byte b2 = 0; b2 < paramInt1; b2++)
                null = transformY(arg1(paramSEXP), b2, paramPtr1.copyOf(32), paramPtr2, paramDouble1, paramDouble2, paramInt2, 3, paramPtr3) + null; 
              return null;
            } 
            paramInt1 = unitLength(arg1(paramSEXP));
            null = transformY(arg1(paramSEXP), 0, paramPtr1.copyOf(32), paramPtr2, paramDouble1, paramDouble2, paramInt2, 5, paramPtr3);
            for (byte b1 = 1; b1 < paramInt1; b1++) {
              double d = transformY(arg1(paramSEXP), b1, paramPtr1.copyOf(32), paramPtr2, paramDouble1, paramDouble2, paramInt2, 5, paramPtr3);
              if (d > null)
                null = d; 
            } 
            return null;
          } 
          paramInt1 = unitLength(arg1(paramSEXP));
          null = transformY(arg1(paramSEXP), 0, paramPtr1.copyOf(32), paramPtr2, paramDouble1, paramDouble2, paramInt2, 6, paramPtr3);
          for (byte b = 1; b < paramInt1; b++) {
            double d = transformY(arg1(paramSEXP), b, paramPtr1.copyOf(32), paramPtr2, paramDouble1, paramDouble2, paramInt2, 6, paramPtr3);
            if (d < null)
              null = d; 
          } 
          return null;
        } 
        return Rinternals2.REAL(arg1(paramSEXP)).getDouble(0 + paramInt1 % Rinternals.LENGTH(arg1(paramSEXP)) * 8) * transformY(arg2(paramSEXP), paramInt1, paramPtr1.copyOf(32), paramPtr2, paramDouble1, paramDouble2, paramInt2, 7, paramPtr3);
      } 
      return transformY(arg1(paramSEXP), paramInt1, paramPtr1.copyOf(32), paramPtr2, paramDouble1, paramDouble2, paramInt2, 2, paramPtr3) - transformY(arg2(paramSEXP), paramInt1, paramPtr1.copyOf(32), paramPtr2, paramDouble1, paramDouble2, paramInt2, 2, paramPtr3);
    } 
    return transformY(arg1(paramSEXP), paramInt1, paramPtr1.copyOf(32), paramPtr2, paramDouble1, paramDouble2, paramInt2, 1, paramPtr3) + transformY(arg2(paramSEXP), paramInt1, paramPtr1.copyOf(32), paramPtr2, paramDouble1, paramDouble2, paramInt2, 1, paramPtr3);
  }
  
  public static double transformYtoINCHES(SEXP paramSEXP, int paramInt, Ptr paramPtr1, Ptr paramPtr2, double paramDouble1, double paramDouble2, Ptr paramPtr3) {
    return transformY(paramSEXP, paramInt, paramPtr1.copyOf(32), paramPtr2, paramDouble1, paramDouble2, 0, 0, paramPtr3);
  }
  
  public static SEXP unit(double paramDouble, int paramInt) {
    SEXP sEXP2 = Rinternals.Rf_ScalarReal(paramDouble);
    Rinternals.Rf_protect(sEXP2);
    SEXP sEXP1 = Rinternals.Rf_ScalarInteger(paramInt);
    Rinternals.Rf_protect(sEXP1);
    Rinternals.Rf_setAttrib(sEXP2, Rinternals.Rf_install(new BytePtr("valid.unit\000".getBytes(), 0)), sEXP1);
    sEXP1 = Rinternals.R_NilValue;
    Rinternals.Rf_setAttrib(sEXP2, Rinternals.Rf_install(new BytePtr("data\000".getBytes(), 0)), sEXP1);
    Rinternals.Rf_protect(Rinternals.Rf_mkString((Ptr)new BytePtr("unit\000".getBytes(), 0)));
    Rinternals.Rf_classgets(sEXP2, Rinternals.Rf_mkString((Ptr)new BytePtr("unit\000".getBytes(), 0)));
    return sEXP2;
  }
  
  public static SEXP unitData(SEXP paramSEXP, int paramInt) {
    paramSEXP = Rinternals.Rf_getAttrib(paramSEXP, Rinternals.Rf_install(new BytePtr("data\000".getBytes(), 0)));
    if (!Rinternals.Rf_isNull(paramSEXP)) {
      if (Rinternals.TYPEOF(paramSEXP) != 19) {
        Error.Rf_warning(new BytePtr("unit attribute 'data' is of incorrect type\000".getBytes(), 0), new Object[0]);
        return Rinternals.R_NilValue;
      } 
      paramSEXP = Rinternals.VECTOR_ELT(paramSEXP, paramInt % Rinternals.LENGTH(paramSEXP));
    } else {
      paramSEXP = Rinternals.R_NilValue;
    } 
    return paramSEXP;
  }
  
  public static int unitLength(SEXP paramSEXP) {
    if (isUnitList(paramSEXP) == 0) {
      if (isUnitArithmetic(paramSEXP) == 0)
        return Rinternals.LENGTH(paramSEXP); 
      if (fOp(paramSEXP) == 0)
        return 1; 
      if (timesOp(paramSEXP) == 0) {
        int j = unitLength(arg1(paramSEXP));
        return Math.max(unitLength(arg2(paramSEXP)), j);
      } 
      int i = Rinternals.LENGTH(arg1(paramSEXP));
      return Math.max(unitLength(arg2(paramSEXP)), i);
    } 
    return Rinternals.LENGTH(paramSEXP);
  }
  
  public static int unitUnit(SEXP paramSEXP, int paramInt) {
    int i = Rinternals.LENGTH(Rinternals.Rf_getAttrib(paramSEXP, Rinternals.Rf_install(new BytePtr("valid.unit\000".getBytes(), 0))));
    return Rinternals2.INTEGER(Rinternals.Rf_getAttrib(paramSEXP, Rinternals.Rf_install(new BytePtr("valid.unit\000".getBytes(), 0)))).getInt(0 + paramInt % i * 4);
  }
  
  public static double unitValue(SEXP paramSEXP, int paramInt) {
    return util__.numeric(paramSEXP, paramInt % Rinternals.LENGTH(paramSEXP));
  }
  
  public static SEXP validUnits(SEXP paramSEXP) {
    SEXP sEXP1 = (SEXP)BytePtr.of(0).getArray();
    SEXP sEXP2 = (SEXP)BytePtr.of(0).getArray();
    int i = Rinternals.LENGTH(paramSEXP);
    SEXP sEXP3 = Rinternals.R_NilValue;
    if (i > 0)
      if (!Rinternals.Rf_isString(paramSEXP)) {
        Error.Rf_error(GetText.dgettext(new BytePtr("grid\000".getBytes(), 0), new BytePtr("'units' must be character\000".getBytes(), 0)), new Object[0]);
      } else {
        sEXP2 = Rinternals.Rf_allocVector(13, i);
        Rinternals.Rf_protect(sEXP2);
        for (byte b = 0; b < i; b++)
          Rinternals2.INTEGER(sEXP2).setInt(0 + b * 4, convertUnit(paramSEXP, b)); 
        return sEXP2;
      }  
    Error.Rf_error(GetText.dgettext(new BytePtr("grid\000".getBytes(), 0), new BytePtr("'units' must be of length > 0\000".getBytes(), 0)), new Object[0]);
    return sEXP2;
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/grid-0.9.2724.jar!/org/renjin/grid/unit__.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */