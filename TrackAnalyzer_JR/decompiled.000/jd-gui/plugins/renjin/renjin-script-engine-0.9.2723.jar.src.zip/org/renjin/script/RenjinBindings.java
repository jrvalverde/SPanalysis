/*     */ package org.renjin.script;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.script.Bindings;
/*     */ import org.renjin.invoke.reflection.converters.Converters;
/*     */ import org.renjin.repackaged.guava.base.Function;
/*     */ import org.renjin.repackaged.guava.collect.Collections2;
/*     */ import org.renjin.repackaged.guava.collect.Sets;
/*     */ import org.renjin.sexp.Frame;
/*     */ import org.renjin.sexp.Null;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.Symbol;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RenjinBindings
/*     */   implements Bindings
/*     */ {
/*     */   private final Frame frame;
/*     */   
/*     */   public RenjinBindings(Frame frame) {
/*  42 */     this.frame = frame;
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear() {
/*  47 */     this.frame.clear();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsValue(Object value) {
/*  52 */     for (Symbol symbol : this.frame.getSymbols()) {
/*  53 */       if (this.frame.getVariable(symbol).equals(value)) {
/*  54 */         return true;
/*     */       }
/*     */     } 
/*  57 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<Map.Entry<String, Object>> entrySet() {
/*  62 */     throw new UnsupportedOperationException("nyi");
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/*  67 */     return this.frame.getSymbols().isEmpty();
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<String> keySet() {
/*  72 */     Set<String> names = Sets.newHashSet();
/*  73 */     for (Symbol symbol : this.frame.getSymbols()) {
/*  74 */       names.add(symbol.getPrintName());
/*     */     }
/*  76 */     return names;
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/*  81 */     return this.frame.getSymbols().size();
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<Object> values() {
/*  86 */     return Collections2.transform(this.frame.getSymbols(), new Function<Symbol, Object>()
/*     */         {
/*     */           public Object apply(Symbol symbol)
/*     */           {
/*  90 */             return RenjinBindings.this.frame.getVariable(symbol);
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsKey(Object key) {
/*  97 */     return this.frame.getSymbols().contains(toSymbol(key));
/*     */   }
/*     */ 
/*     */   
/*     */   public Object get(Object key) {
/* 102 */     return this.frame.getVariable(toSymbol(key));
/*     */   }
/*     */   
/*     */   private Symbol toSymbol(Object key) {
/* 106 */     if (key instanceof Symbol)
/* 107 */       return (Symbol)key; 
/* 108 */     if (key instanceof String) {
/* 109 */       return Symbol.get((String)key);
/*     */     }
/* 111 */     return Symbol.UNBOUND_VALUE;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object put(String name, Object value) {
/*     */     SEXP exp;
/* 117 */     Symbol symbol = Symbol.get(name);
/* 118 */     SEXP previousValue = this.frame.getVariable(symbol);
/*     */     
/* 120 */     if (value == null) {
/* 121 */       Null null = Null.INSTANCE;
/*     */     } else {
/* 123 */       exp = Converters.get(value.getClass()).convertToR(value);
/*     */     } 
/* 125 */     this.frame.setVariable(symbol, exp);
/* 126 */     return previousValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public void putAll(Map<? extends String, ? extends Object> toMerge) {
/* 131 */     for (Map.Entry<? extends String, ? extends Object> entry : toMerge.entrySet()) {
/* 132 */       put(entry.getKey(), entry.getValue());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public Object remove(Object key) {
/* 138 */     Object originalValue = get(key);
/* 139 */     this.frame.remove(toSymbol(key));
/* 140 */     return originalValue;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-script-engine-0.9.2723.jar!/org/renjin/script/RenjinBindings.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */