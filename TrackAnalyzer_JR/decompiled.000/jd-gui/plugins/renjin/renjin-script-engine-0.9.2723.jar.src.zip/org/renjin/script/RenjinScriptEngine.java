/*     */ package org.renjin.script;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import javax.script.Bindings;
/*     */ import javax.script.Invocable;
/*     */ import javax.script.ScriptContext;
/*     */ import javax.script.ScriptEngine;
/*     */ import javax.script.ScriptEngineFactory;
/*     */ import javax.script.ScriptException;
/*     */ import org.renjin.eval.Context;
/*     */ import org.renjin.eval.EvalException;
/*     */ import org.renjin.eval.Session;
/*     */ import org.renjin.invoke.reflection.converters.Converters;
/*     */ import org.renjin.invoke.reflection.converters.RuntimeConverter;
/*     */ import org.renjin.parser.RParser;
/*     */ import org.renjin.primitives.Warning;
/*     */ import org.renjin.primitives.special.BreakException;
/*     */ import org.renjin.primitives.special.NextException;
/*     */ import org.renjin.repackaged.guava.io.CharSource;
/*     */ import org.renjin.sexp.CHARSEXP;
/*     */ import org.renjin.sexp.Environment;
/*     */ import org.renjin.sexp.ExpressionVector;
/*     */ import org.renjin.sexp.Frame;
/*     */ import org.renjin.sexp.Function;
/*     */ import org.renjin.sexp.FunctionCall;
/*     */ import org.renjin.sexp.HashFrame;
/*     */ import org.renjin.sexp.ListVector;
/*     */ import org.renjin.sexp.Null;
/*     */ import org.renjin.sexp.PairList;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.Symbol;
/*     */ 
/*     */ 
/*     */ public class RenjinScriptEngine
/*     */   implements ScriptEngine, Invocable
/*     */ {
/*     */   private final RenjinScriptEngineFactory factory;
/*     */   private final Context topLevelContext;
/*     */   private final ScriptContext scriptContext;
/*     */   private static final String INLINE_STRING = "inline-string";
/*     */   private static final String UNKNOWN = "unknown";
/*     */   
/*     */   RenjinScriptEngine(RenjinScriptEngineFactory factory, Session session) {
/*  51 */     this.factory = factory;
/*  52 */     this.topLevelContext = session.getTopLevelContext();
/*  53 */     this.scriptContext = new RenjinScriptContext(this.topLevelContext);
/*     */   }
/*     */   
/*     */   public Session getSession() {
/*  57 */     return this.topLevelContext.getSession();
/*     */   }
/*     */   
/*     */   public Context getTopLevelContext() {
/*  61 */     return this.topLevelContext;
/*     */   }
/*     */ 
/*     */   
/*     */   public Bindings createBindings() {
/*  66 */     return new RenjinBindings((Frame)new HashFrame());
/*     */   }
/*     */ 
/*     */   
/*     */   public Object get(String key) {
/*  71 */     return this.topLevelContext.getEnvironment().getVariable(this.topLevelContext, Symbol.get(key));
/*     */   }
/*     */ 
/*     */   
/*     */   public Bindings getBindings(int scope) {
/*  76 */     switch (scope) {
/*     */       case 100:
/*  78 */         return new RenjinBindings(this.topLevelContext.getEnvironment().getFrame());
/*     */     } 
/*     */ 
/*     */     
/*  82 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ScriptContext getContext() {
/*  89 */     return this.scriptContext;
/*     */   }
/*     */ 
/*     */   
/*     */   public void put(String key, Object value) {
/*     */     SEXP convertedValue;
/*  95 */     if (value == null) {
/*  96 */       Null null = Null.INSTANCE;
/*     */     } else {
/*  98 */       convertedValue = Converters.get(value.getClass()).convertToR(value);
/*     */     } 
/* 100 */     this.topLevelContext.getEnvironment().setVariable(this.topLevelContext, Symbol.get(key), convertedValue);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBindings(Bindings bindings, int scope) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void setContext(ScriptContext context) {
/* 110 */     throw new UnsupportedOperationException("Cannot set the context");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object eval(Reader reader, Bindings n) throws ScriptException {
/* 116 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object eval(String script, Bindings n) throws ScriptException {
/* 121 */     throw new UnsupportedOperationException("nyi");
/*     */   }
/*     */ 
/*     */   
/*     */   public Object eval(String script) throws ScriptException {
/* 126 */     String filename = getFilenameFromContext(this.scriptContext, "inline-string");
/* 127 */     return eval(this.topLevelContext, (SEXP)RParser.parseSource(script + "\n", filename));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object eval(String script, ScriptContext scriptContext) throws ScriptException {
/* 134 */     String filename = getFilenameFromContext(scriptContext, "inline-string");
/* 135 */     ExpressionVector expressionVector = RParser.parseSource(script + "\n", filename);
/* 136 */     return eval(unwrapContext(scriptContext), (SEXP)expressionVector);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object eval(Reader reader) throws ScriptException {
/* 141 */     String filename = getFilenameFromContext(this.scriptContext, "inline-string");
/* 142 */     return eval(reader, this.topLevelContext, filename);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object eval(Reader reader, ScriptContext scriptContext) throws ScriptException {
/* 148 */     String filename = getFilenameFromContext(scriptContext, "unknown");
/* 149 */     return eval(reader, unwrapContext(scriptContext), filename);
/*     */   }
/*     */ 
/*     */   
/*     */   private Object eval(Reader reader, Context context, String filename) throws ScriptException {
/*     */     ExpressionVector expressionVector;
/*     */     try {
/* 156 */       CharSource terminated = CharSource.concat(new CharSource[] {
/* 157 */             newReaderSupplier(reader), 
/* 158 */             CharSource.wrap("\n") });
/* 159 */       expressionVector = RParser.parseSource(terminated, (SEXP)new CHARSEXP(filename));
/* 160 */     } catch (IOException e) {
/* 161 */       throw new ScriptException(e);
/*     */     } 
/* 163 */     return eval(context, (SEXP)expressionVector);
/*     */   }
/*     */   
/*     */   private Object eval(Context context, SEXP source) {
/*     */     try {
/* 168 */       return context.evaluate(source, context.getEnvironment());
/* 169 */     } catch (BreakException e) {
/* 170 */       throw new EvalException("no loop for break", new Object[0]);
/* 171 */     } catch (NextException e) {
/* 172 */       throw new EvalException("no loop for next", new Object[0]);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void eval(File file) throws IOException, ScriptException {
/* 178 */     InputStreamReader reader = new InputStreamReader(new FileInputStream(file));
/*     */     
/* 180 */     this.scriptContext.setAttribute("javax.script.filename", file.getName(), 100);
/* 181 */     eval(reader);
/* 182 */     reader.close();
/*     */   }
/*     */ 
/*     */   
/*     */   private CharSource newReaderSupplier(final Reader reader) {
/* 187 */     return new CharSource()
/*     */       {
/*     */         public Reader openStream() throws IOException {
/* 190 */           return reader;
/*     */         }
/*     */       };
/*     */   }
/*     */   
/*     */   private Context unwrapContext(ScriptContext scriptContext) {
/* 196 */     return ((RenjinScriptContext)scriptContext).getContext();
/*     */   }
/*     */   
/*     */   private String getFilenameFromContext(ScriptContext ctx, String defaultValue) {
/* 200 */     String fileName = defaultValue;
/* 201 */     Object oFileName = this.scriptContext.getAttribute("javax.script.filename");
/* 202 */     if (oFileName != null) {
/* 203 */       fileName = oFileName.toString();
/*     */     }
/* 205 */     return fileName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ScriptEngineFactory getFactory() {
/* 215 */     return this.factory;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T getInterface(Class<T> clasz) {
/* 221 */     return (T)Proxy.newProxyInstance(getClass().getClassLoader(), new Class[] { clasz }, new InvocationHandler()
/*     */         {
/*     */           
/*     */           public Object invoke(Object instance, Method method, Object[] arguments) throws Exception
/*     */           {
/* 226 */             SEXP result = RenjinScriptEngine.this.invokeFunction(method.getName(), arguments);
/* 227 */             return Converters.get(method.getReturnType()).convertToJava(result);
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T getInterface(final Object thiz, Class<T> clasz) {
/* 236 */     return (T)Proxy.newProxyInstance(getClass().getClassLoader(), new Class[] { clasz }, new InvocationHandler()
/*     */         {
/*     */           public Object invoke(Object instance, Method method, Object[] arguments) throws Exception
/*     */           {
/* 240 */             SEXP result = RenjinScriptEngine.this.invokeMethod(thiz, method.getName(), arguments);
/* 241 */             return Converters.get(method.getReturnType()).convertToJava(result);
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SEXP invokeFunction(String name, Object... arguments) throws ScriptException, NoSuchMethodException {
/* 250 */     if (name == null) {
/* 251 */       throw new NullPointerException("name");
/*     */     }
/*     */     
/* 254 */     Function function = this.topLevelContext.getEnvironment().findFunction(this.topLevelContext, Symbol.get(name));
/* 255 */     if (function == null) {
/* 256 */       throw new NoSuchMethodException(name);
/*     */     }
/*     */     
/* 259 */     return invoke(function, arguments);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SEXP invokeMethod(Object thiz, String name, Object... arguments) throws ScriptException, NoSuchMethodException {
/*     */     SEXP element;
/* 267 */     if (thiz instanceof Environment) {
/* 268 */       element = ((Environment)thiz).getVariable(this.topLevelContext, name);
/* 269 */     } else if (thiz instanceof ListVector) {
/* 270 */       element = ((ListVector)thiz).get(name);
/*     */     } else {
/* 272 */       throw new NoSuchMethodException(name);
/*     */     } 
/* 274 */     if (!(element instanceof Function)) {
/* 275 */       throw new NoSuchMethodException(name);
/*     */     }
/* 277 */     Function method = (Function)element;
/*     */     
/* 279 */     return invoke(method, arguments);
/*     */   }
/*     */   
/*     */   private SEXP invoke(Function function, Object... arguments) {
/* 283 */     PairList.Builder argList = new PairList.Builder();
/* 284 */     for (Object argument : arguments) {
/* 285 */       argList.add(RuntimeConverter.INSTANCE.convertToR(argument));
/*     */     }
/*     */     
/* 288 */     FunctionCall call = new FunctionCall((SEXP)function, argList.build());
/*     */     
/* 290 */     return this.topLevelContext.evaluate((SEXP)call);
/*     */   }
/*     */   
/*     */   public FunctionCallBuilder invoke(String functionName) {
/* 294 */     return new FunctionCallBuilder(functionName);
/*     */   }
/*     */   
/*     */   public void printWarnings() {
/* 298 */     SEXP warnings = this.topLevelContext.getBaseEnvironment().getVariable(this.topLevelContext, Warning.LAST_WARNING);
/* 299 */     if (warnings != Symbol.UNBOUND_VALUE) {
/* 300 */       this.topLevelContext.evaluate((SEXP)FunctionCall.newCall((SEXP)Symbol.get("print.warnings"), new SEXP[] { warnings }), this.topLevelContext
/* 301 */           .getBaseEnvironment());
/*     */     }
/*     */     
/* 304 */     this.topLevelContext.getBaseEnvironment().remove(Warning.LAST_WARNING);
/*     */   }
/*     */   
/*     */   public class FunctionCallBuilder
/*     */   {
/*     */     private Symbol function;
/* 310 */     private PairList.Builder arguments = new PairList.Builder();
/*     */     
/*     */     private FunctionCallBuilder(String functionName) {
/* 313 */       this.function = Symbol.get(functionName);
/*     */     }
/*     */     
/*     */     public FunctionCallBuilder withArgument(Object argument) {
/* 317 */       this.arguments.add(RuntimeConverter.INSTANCE.convertToR(argument));
/* 318 */       return this;
/*     */     }
/*     */     
/*     */     public FunctionCallBuilder withNamedArgument(String name, Object argument) {
/* 322 */       this.arguments.add(name, RuntimeConverter.INSTANCE.convertToR(argument));
/* 323 */       return this;
/*     */     }
/*     */     
/*     */     public <S extends SEXP> S apply() {
/* 327 */       FunctionCall call = new FunctionCall((SEXP)this.function, this.arguments.build());
/* 328 */       return (S)RenjinScriptEngine.this.topLevelContext.evaluate((SEXP)call);
/*     */     }
/*     */   }
/*     */   
/*     */   public Context getRuntimeContext() {
/* 333 */     return this.topLevelContext;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-script-engine-0.9.2723.jar!/org/renjin/script/RenjinScriptEngine.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */