/*     */ package org.renjin.script;
/*     */ 
/*     */ import java.io.PrintWriter;
/*     */ import java.io.Reader;
/*     */ import java.io.Writer;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.TreeMap;
/*     */ import javax.script.Bindings;
/*     */ import javax.script.ScriptContext;
/*     */ import org.renjin.eval.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RenjinScriptContext
/*     */   implements ScriptContext
/*     */ {
/*     */   private Context context;
/*  37 */   private Map<String, Object> attributes = new TreeMap<>();
/*     */   
/*     */   RenjinScriptContext(Context context) {
/*  40 */     this.context = context;
/*     */   }
/*     */   
/*     */   public Context getContext() {
/*  44 */     return this.context;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getAttribute(String arg0) {
/*  49 */     return this.attributes.get(arg0);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getAttribute(String arg0, int arg1) {
/*  54 */     return this.attributes.get(arg0);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getAttributesScope(String arg0) {
/*  59 */     return 100;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Bindings getBindings(int arg0) {
/*  65 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Writer getErrorWriter() {
/*  70 */     return this.context.getSession().getConnectionTable().getStderr().getPrintWriter();
/*     */   }
/*     */ 
/*     */   
/*     */   public Reader getReader() {
/*  75 */     return this.context.getSession().getStdIn();
/*     */   }
/*     */ 
/*     */   
/*     */   public List<Integer> getScopes() {
/*  80 */     return Collections.singletonList(Integer.valueOf(100));
/*     */   }
/*     */ 
/*     */   
/*     */   public Writer getWriter() {
/*  85 */     return this.context.getSession().getStdOut();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object removeAttribute(String arg0, int arg1) {
/*  90 */     return this.attributes.remove(arg0);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAttribute(String name, Object value, int scope) {
/*  95 */     if (scope == 100) {
/*  96 */       this.attributes.put(name, value);
/*     */     } else {
/*  98 */       throw new UnsupportedOperationException(
/*  99 */           String.format("setting attribute in scope (%d) not supported", new Object[] { Integer.valueOf(scope) }));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBindings(Bindings arg0, int arg1) {
/* 105 */     throw new UnsupportedOperationException("nyi");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setErrorWriter(Writer errorWriter) {
/* 110 */     this.context.getSession().setStdErr(new PrintWriter(errorWriter));
/*     */   }
/*     */ 
/*     */   
/*     */   public void setReader(Reader reader) {
/* 115 */     this.context.getSession().setStdIn(reader);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setWriter(Writer writer) {
/* 120 */     this.context.getSession().setStdOut(new PrintWriter(writer));
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-script-engine-0.9.2723.jar!/org/renjin/script/RenjinScriptContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */