/*     */ package org.renjin.script;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.URL;
/*     */ import java.util.Arrays;
/*     */ import java.util.Iterator;
/*     */ import org.renjin.eval.Context;
/*     */ import org.renjin.primitives.packaging.Namespace;
/*     */ import org.renjin.repackaged.guava.base.Charsets;
/*     */ import org.renjin.repackaged.guava.base.Strings;
/*     */ import org.renjin.repackaged.guava.io.Resources;
/*     */ import org.renjin.sexp.Closure;
/*     */ import org.renjin.sexp.DoubleVector;
/*     */ import org.renjin.sexp.FunctionCall;
/*     */ import org.renjin.sexp.PairList;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.StringVector;
/*     */ import org.renjin.sexp.Symbol;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Execute
/*     */ {
/*     */   public static void main(String[] args) throws IOException {
/*  43 */     String namespace = getNamespace();
/*     */     
/*  45 */     System.err.println("Namespace = " + namespace);
/*     */     
/*  47 */     RenjinScriptEngineFactory factory = new RenjinScriptEngineFactory();
/*  48 */     RenjinScriptEngine scriptEngine = factory.getScriptEngine();
/*     */     
/*  50 */     Context context = scriptEngine.getTopLevelContext();
/*  51 */     Namespace executableNamespace = scriptEngine.getSession().getNamespaceRegistry().getNamespace(context, namespace);
/*  52 */     SEXP execute = executableNamespace.getNamespaceEnvironment().getVariable(context, Symbol.get("execute"));
/*  53 */     if (execute instanceof Closure) {
/*  54 */       FunctionCall call; Closure closure = (Closure)execute;
/*     */       
/*     */       try {
/*  57 */         call = new FunctionCall(execute, prepareArguments(closure, args));
/*  58 */       } catch (IllegalArgumentException e) {
/*  59 */         printHelpAndExit(closure, e.getMessage());
/*  60 */         throw new Error();
/*     */       } 
/*  62 */       context.evaluate((SEXP)call);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static PairList prepareArguments(Closure function, String[] args) {
/*  68 */     Iterator<String> argumentIterator = Arrays.<String>asList(args).iterator();
/*  69 */     Iterator<PairList.Node> formalIterator = function.getFormals().nodes().iterator();
/*     */     
/*  71 */     PairList.Builder builder = new PairList.Builder();
/*     */     
/*  73 */     while (formalIterator.hasNext()) {
/*  74 */       PairList.Node formal = formalIterator.next();
/*     */       
/*  76 */       if (!argumentIterator.hasNext()) {
/*  77 */         throw new IllegalArgumentException("Not enough arguments");
/*     */       }
/*     */       
/*  80 */       builder.add(formal.getTag(), convertArgument(argumentIterator.next(), formal.getValue()));
/*     */     } 
/*     */     
/*  83 */     return builder.build();
/*     */   }
/*     */ 
/*     */   
/*     */   private static SEXP convertArgument(String argument, SEXP formalDefaultValue) {
/*  88 */     if (isNumber(formalDefaultValue)) {
/*  89 */       return (SEXP)DoubleVector.valueOf(Double.parseDouble(argument));
/*     */     }
/*  91 */     return (SEXP)StringVector.valueOf(argument);
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean isNumber(SEXP formalDefaultValue) {
/*  96 */     if (formalDefaultValue instanceof DoubleVector || formalDefaultValue instanceof org.renjin.sexp.IntVector) {
/*  97 */       return true;
/*     */     }
/*  99 */     if (formalDefaultValue instanceof FunctionCall) {
/* 100 */       SEXP function = ((FunctionCall)formalDefaultValue).getFunction();
/* 101 */       if (function instanceof Symbol && (
/* 102 */         (Symbol)function).getPrintName().startsWith("number")) {
/* 103 */         return true;
/*     */       }
/*     */     } 
/*     */     
/* 107 */     return false;
/*     */   }
/*     */   
/*     */   private static void printHelpAndExit(Closure function, String message) {
/* 111 */     System.err.println("ERROR: " + message);
/* 112 */     System.err.println(helpFromClosure(function));
/* 113 */     System.exit(-1);
/*     */   }
/*     */   
/*     */   private static String helpFromClosure(Closure function) {
/* 117 */     StringBuilder s = new StringBuilder();
/* 118 */     s.append("Usage: java -jar <jarfile>");
/* 119 */     for (PairList.Node formal : function.getFormals().nodes()) {
/* 120 */       s.append(" <");
/* 121 */       s.append(formal.getTag().getPrintName());
/* 122 */       s.append(">");
/*     */     } 
/* 124 */     s.append('\n');
/* 125 */     s.append('\n');
/* 126 */     s.append("Arguments:\n");
/*     */     
/* 128 */     for (PairList.Node formal : function.getFormals().nodes()) {
/* 129 */       s.append("  ");
/* 130 */       s.append(Strings.padEnd(formal.getTag().getPrintName(), 20, ' '));
/* 131 */       s.append('\n');
/*     */     } 
/*     */     
/* 134 */     return s.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public static String getNamespace() throws IOException {
/*     */     URL namespaceResource;
/*     */     try {
/* 141 */       namespaceResource = Resources.getResource("META-INF/org.renjin.execute.namespace");
/* 142 */     } catch (IllegalArgumentException e) {
/* 143 */       throw new IllegalStateException("Cannot locate META-INF/org.renjin.execute.namespace resource.");
/*     */     } 
/* 145 */     return Resources.toString(namespaceResource, Charsets.UTF_8);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-script-engine-0.9.2723.jar!/org/renjin/script/Execute.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */