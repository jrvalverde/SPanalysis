/*     */ package org.renjin.script;
/*     */ 
/*     */ import java.util.List;
/*     */ import javax.script.ScriptEngine;
/*     */ import javax.script.ScriptEngineFactory;
/*     */ import org.renjin.RVersion;
/*     */ import org.renjin.eval.Session;
/*     */ import org.renjin.eval.SessionBuilder;
/*     */ import org.renjin.repackaged.guava.collect.Lists;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RenjinScriptEngineFactory
/*     */   implements ScriptEngineFactory
/*     */ {
/*     */   public String getEngineName() {
/*  37 */     return "Renjin";
/*     */   }
/*     */ 
/*     */   
/*     */   public String getEngineVersion() {
/*  42 */     return "017";
/*     */   }
/*     */ 
/*     */   
/*     */   public List<String> getExtensions() {
/*  47 */     return Lists.newArrayList((Object[])new String[] { "R", "r", "S", "s" });
/*     */   }
/*     */ 
/*     */   
/*     */   public String getLanguageName() {
/*  52 */     return "R";
/*     */   }
/*     */ 
/*     */   
/*     */   public String getLanguageVersion() {
/*  57 */     return RVersion.STRING;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getMethodCallSyntax(String arg0, String arg1, String... arg2) {
/*  62 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public List<String> getMimeTypes() {
/*  67 */     return Lists.newArrayList((Object[])new String[] { "text/x-R" });
/*     */   }
/*     */ 
/*     */   
/*     */   public List<String> getNames() {
/*  72 */     return Lists.newArrayList((Object[])new String[] { "Renjin" });
/*     */   }
/*     */ 
/*     */   
/*     */   public String getOutputStatement(String arg0) {
/*  77 */     throw new UnsupportedOperationException("nyi");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getParameter(String key) {
/*  86 */     if (key.equals("javax.script.engine"))
/*  87 */       return getEngineName(); 
/*  88 */     if (key.equals("javax.script.engine_version"))
/*  89 */       return getEngineVersion(); 
/*  90 */     if (key.equals("javax.script.name"))
/*  91 */       return getNames().get(0); 
/*  92 */     if (key.equals("javax.script.language"))
/*  93 */       return getLanguageName(); 
/*  94 */     if (key.equals("javax.script.language_version"))
/*  95 */       return getLanguageVersion(); 
/*  96 */     if (key.equals("THREADING")) {
/*  97 */       return null;
/*     */     }
/*  99 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getProgram(String... arg0) {
/* 105 */     throw new UnsupportedOperationException("nyi");
/*     */   }
/*     */ 
/*     */   
/*     */   public RenjinScriptEngine getScriptEngine() {
/* 110 */     return new RenjinScriptEngine(this, (new SessionBuilder()).withDefaultPackages().build());
/*     */   }
/*     */   
/*     */   public RenjinScriptEngine getScriptEngine(Session session) {
/* 114 */     return new RenjinScriptEngine(this, session);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-script-engine-0.9.2723.jar!/org/renjin/script/RenjinScriptEngineFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */