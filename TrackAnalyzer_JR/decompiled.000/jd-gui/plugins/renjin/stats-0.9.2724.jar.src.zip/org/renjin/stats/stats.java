package org.renjin.stats;

import java.lang.invoke.MethodHandle;
import org.renjin.gcc.runtime.Ptr;
import org.renjin.sexp.SEXP;

public class stats {
  public static SEXP ARIMA_CSS(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4, SEXP paramSEXP5, SEXP paramSEXP6) {
    return arima__.ARIMA_CSS(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4, paramSEXP5, paramSEXP6);
  }
  
  public static SEXP ARIMA_Gradtrans(SEXP paramSEXP1, SEXP paramSEXP2) {
    return arima__.ARIMA_Gradtrans(paramSEXP1, paramSEXP2);
  }
  
  public static SEXP ARIMA_Invtrans(SEXP paramSEXP1, SEXP paramSEXP2) {
    return arima__.ARIMA_Invtrans(paramSEXP1, paramSEXP2);
  }
  
  public static SEXP ARIMA_Like(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4) {
    return arima__.ARIMA_Like(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4);
  }
  
  public static SEXP ARIMA_transPars(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3) {
    return arima__.ARIMA_transPars(paramSEXP1, paramSEXP2, paramSEXP3);
  }
  
  public static SEXP ARIMA_undoPars(SEXP paramSEXP1, SEXP paramSEXP2) {
    return arima__.ARIMA_undoPars(paramSEXP1, paramSEXP2);
  }
  
  public static SEXP ARMAtoMA(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3) {
    return pacf__.ARMAtoMA(paramSEXP1, paramSEXP2, paramSEXP3);
  }
  
  public static SEXP Burg(SEXP paramSEXP1, SEXP paramSEXP2) {
    return burg__.Burg(paramSEXP1, paramSEXP2);
  }
  
  public static SEXP Dotrans(SEXP paramSEXP1, SEXP paramSEXP2) {
    return pacf__.Dotrans(paramSEXP1, paramSEXP2);
  }
  
  public static SEXP DoubleCentre(SEXP paramSEXP) {
    return dblcen__.DoubleCentre(paramSEXP);
  }
  
  public static SEXP Gradtrans(SEXP paramSEXP1, SEXP paramSEXP2) {
    return pacf__.Gradtrans(paramSEXP1, paramSEXP2);
  }
  
  public static void HoltWinters(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, Ptr paramPtr11, Ptr paramPtr12, Ptr paramPtr13, Ptr paramPtr14, Ptr paramPtr15, Ptr paramPtr16, Ptr paramPtr17) {
    HoltWinters__.HoltWinters(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramPtr6, paramPtr7, paramPtr8, paramPtr9, paramPtr10, paramPtr11, paramPtr12, paramPtr13, paramPtr14, paramPtr15, paramPtr16, paramPtr17);
  }
  
  public static SEXP Invtrans(SEXP paramSEXP1, SEXP paramSEXP2) {
    return pacf__.Invtrans(paramSEXP1, paramSEXP2);
  }
  
  public static SEXP KalmanFore(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3) {
    return arima__.KalmanFore(paramSEXP1, paramSEXP2, paramSEXP3);
  }
  
  public static SEXP KalmanLike(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4, SEXP paramSEXP5) {
    return arima__.KalmanLike(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4, paramSEXP5);
  }
  
  public static SEXP KalmanSmooth(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3) {
    return arima__.KalmanSmooth(paramSEXP1, paramSEXP2, paramSEXP3);
  }
  
  public static void R_approx(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9) {
    approx__.R_approx(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramPtr6, paramPtr7, paramPtr8, paramPtr9);
  }
  
  public static void R_approxfun(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9) {
    approx__.R_approxfun(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramPtr6, paramPtr7, paramPtr8, paramPtr9);
  }
  
  public static void R_approxtest(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5) {
    approx__.R_approxtest(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5);
  }
  
  public static SEXP R_cutree(SEXP paramSEXP1, SEXP paramSEXP2) {
    return hclust_utils__.R_cutree(paramSEXP1, paramSEXP2);
  }
  
  public static void R_distance(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7) {
    distance__.R_distance(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramPtr6, paramPtr7);
  }
  
  public static SEXP SplineCoef(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3) {
    return splines__.SplineCoef(paramSEXP1, paramSEXP2, paramSEXP3);
  }
  
  public static SEXP SplineEval(SEXP paramSEXP1, SEXP paramSEXP2) {
    return splines__.SplineEval(paramSEXP1, paramSEXP2);
  }
  
  public static SEXP Starma_method(SEXP paramSEXP1, SEXP paramSEXP2) {
    return pacf__.Starma_method(paramSEXP1, paramSEXP2);
  }
  
  public static SEXP TSconv(SEXP paramSEXP1, SEXP paramSEXP2) {
    return arima__.TSconv(paramSEXP1, paramSEXP2);
  }
  
  public static SEXP acf(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3) {
    return filter__.acf(paramSEXP1, paramSEXP2, paramSEXP3);
  }
  
  public static SEXP ar2ma(SEXP paramSEXP1, SEXP paramSEXP2) {
    return pacf__.ar2ma(paramSEXP1, paramSEXP2);
  }
  
  public static SEXP arma0_kfore(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4) {
    return pacf__.arma0_kfore(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4);
  }
  
  public static SEXP arma0fa(SEXP paramSEXP1, SEXP paramSEXP2) {
    return pacf__.arma0fa(paramSEXP1, paramSEXP2);
  }
  
  public static SEXP binomial_dev_resids(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3) {
    return family__.binomial_dev_resids(paramSEXP1, paramSEXP2, paramSEXP3);
  }
  
  public static void bsplvb_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7) {
    bsplvd__.bsplvb_(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramPtr6, paramPtr7);
  }
  
  public static void bsplvd_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8) {
    bsplvd__.bsplvd_(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramPtr6, paramPtr7, paramPtr8);
  }
  
  public static double bvalue_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6) {
    return bvalue__.bvalue_(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramPtr6);
  }
  
  public static void bvalus_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7) {
    bvalus__.bvalus_(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramPtr6, paramPtr7);
  }
  
  public static SEXP cfilter(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4) {
    return filter__.cfilter(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4);
  }
  
  public static void cgmin(int paramInt1, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, MethodHandle paramMethodHandle1, MethodHandle paramMethodHandle2, Ptr paramPtr4, double paramDouble1, double paramDouble2, Ptr paramPtr5, int paramInt2, int paramInt3, Ptr paramPtr6, Ptr paramPtr7, int paramInt4) {
    apply_optim__.cgmin(paramInt1, paramPtr1, paramPtr2, paramPtr3, paramMethodHandle1, paramMethodHandle2, paramPtr4, paramDouble1, paramDouble2, paramPtr5, paramInt2, paramInt3, paramPtr6, paramPtr7, paramInt4);
  }
  
  public static SEXP cor(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4) {
    return cov__.cor(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4);
  }
  
  public static SEXP cov(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4) {
    return cov__.cov(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4);
  }
  
  public static SEXP deriv(SEXP paramSEXP) {
    return deriv__.deriv(paramSEXP);
  }
  
  public static SEXP doD(SEXP paramSEXP) {
    return deriv__.doD(paramSEXP);
  }
  
  public static SEXP do_fmin(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4) {
    return optimize__.do_fmin(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4);
  }
  
  public static void ehg106_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7) {
    loessf__.ehg106_(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramPtr6, paramPtr7);
  }
  
  public static void ehg124_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, Ptr paramPtr11, Ptr paramPtr12, Ptr paramPtr13, Ptr paramPtr14, Ptr paramPtr15, Ptr paramPtr16, Ptr paramPtr17, Ptr paramPtr18, Ptr paramPtr19, Ptr paramPtr20, Ptr paramPtr21) {
    loessf__.ehg124_(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramPtr6, paramPtr7, paramPtr8, paramPtr9, paramPtr10, paramPtr11, paramPtr12, paramPtr13, paramPtr14, paramPtr15, paramPtr16, paramPtr17, paramPtr18, paramPtr19, paramPtr20, paramPtr21);
  }
  
  public static void ehg125_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, Ptr paramPtr11, Ptr paramPtr12, Ptr paramPtr13) {
    loessf__.ehg125_(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramPtr6, paramPtr7, paramPtr8, paramPtr9, paramPtr10, paramPtr11, paramPtr12, paramPtr13);
  }
  
  public static void ehg126_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6) {
    loessf__.ehg126_(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramPtr6);
  }
  
  public static void ehg127_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, Ptr paramPtr11, Ptr paramPtr12, Ptr paramPtr13, Ptr paramPtr14, Ptr paramPtr15, Ptr paramPtr16, Ptr paramPtr17, Ptr paramPtr18, Ptr paramPtr19, Ptr paramPtr20, Ptr paramPtr21, Ptr paramPtr22, Ptr paramPtr23, Ptr paramPtr24, Ptr paramPtr25, Ptr paramPtr26, Ptr paramPtr27, Ptr paramPtr28, Ptr paramPtr29) {
    loessf__.ehg127_(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramPtr6, paramPtr7, paramPtr8, paramPtr9, paramPtr10, paramPtr11, paramPtr12, paramPtr13, paramPtr14, paramPtr15, paramPtr16, paramPtr17, paramPtr18, paramPtr19, paramPtr20, paramPtr21, paramPtr22, paramPtr23, paramPtr24, paramPtr25, paramPtr26, paramPtr27, paramPtr28, paramPtr29);
  }
  
  public static double ehg128_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, Ptr paramPtr11, Ptr paramPtr12) {
    return loessf__.ehg128_(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramPtr6, paramPtr7, paramPtr8, paramPtr9, paramPtr10, paramPtr11, paramPtr12);
  }
  
  public static void ehg129_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7) {
    loessf__.ehg129_(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramPtr6, paramPtr7);
  }
  
  public static void ehg131_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, Ptr paramPtr11, Ptr paramPtr12, Ptr paramPtr13, Ptr paramPtr14, Ptr paramPtr15, Ptr paramPtr16, Ptr paramPtr17, Ptr paramPtr18, Ptr paramPtr19, Ptr paramPtr20, Ptr paramPtr21, Ptr paramPtr22, Ptr paramPtr23, Ptr paramPtr24, Ptr paramPtr25, Ptr paramPtr26, Ptr paramPtr27, Ptr paramPtr28, Ptr paramPtr29, Ptr paramPtr30, Ptr paramPtr31, Ptr paramPtr32, Ptr paramPtr33, Ptr paramPtr34, Ptr paramPtr35, Ptr paramPtr36, Ptr paramPtr37, Ptr paramPtr38, Ptr paramPtr39, Ptr paramPtr40, Ptr paramPtr41) {
    loessf__.ehg131_(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramPtr6, paramPtr7, paramPtr8, paramPtr9, paramPtr10, paramPtr11, paramPtr12, paramPtr13, paramPtr14, paramPtr15, paramPtr16, paramPtr17, paramPtr18, paramPtr19, paramPtr20, paramPtr21, paramPtr22, paramPtr23, paramPtr24, paramPtr25, paramPtr26, paramPtr27, paramPtr28, paramPtr29, paramPtr30, paramPtr31, paramPtr32, paramPtr33, paramPtr34, paramPtr35, paramPtr36, paramPtr37, paramPtr38, paramPtr39, paramPtr40, paramPtr41);
  }
  
  public static void ehg133_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, Ptr paramPtr11, Ptr paramPtr12, Ptr paramPtr13, Ptr paramPtr14, Ptr paramPtr15, Ptr paramPtr16) {
    loessf__.ehg133_(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramPtr6, paramPtr7, paramPtr8, paramPtr9, paramPtr10, paramPtr11, paramPtr12, paramPtr13, paramPtr14, paramPtr15, paramPtr16);
  }
  
  public static void ehg136_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, Ptr paramPtr11, Ptr paramPtr12, Ptr paramPtr13, Ptr paramPtr14, Ptr paramPtr15, Ptr paramPtr16, Ptr paramPtr17, Ptr paramPtr18, Ptr paramPtr19, Ptr paramPtr20, Ptr paramPtr21, Ptr paramPtr22, Ptr paramPtr23, Ptr paramPtr24, Ptr paramPtr25, Ptr paramPtr26) {
    loessf__.ehg136_(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramPtr6, paramPtr7, paramPtr8, paramPtr9, paramPtr10, paramPtr11, paramPtr12, paramPtr13, paramPtr14, paramPtr15, paramPtr16, paramPtr17, paramPtr18, paramPtr19, paramPtr20, paramPtr21, paramPtr22, paramPtr23, paramPtr24, paramPtr25, paramPtr26);
  }
  
  public static void ehg137_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, Ptr paramPtr11, Ptr paramPtr12) {
    loessf__.ehg137_(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramPtr6, paramPtr7, paramPtr8, paramPtr9, paramPtr10, paramPtr11, paramPtr12);
  }
  
  public static int ehg138_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7) {
    return loessf__.ehg138_(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramPtr6, paramPtr7);
  }
  
  public static void ehg139_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, Ptr paramPtr11, Ptr paramPtr12, Ptr paramPtr13, Ptr paramPtr14, Ptr paramPtr15, Ptr paramPtr16, Ptr paramPtr17, Ptr paramPtr18, Ptr paramPtr19, Ptr paramPtr20, Ptr paramPtr21, Ptr paramPtr22, Ptr paramPtr23, Ptr paramPtr24, Ptr paramPtr25, Ptr paramPtr26, Ptr paramPtr27, Ptr paramPtr28, Ptr paramPtr29, Ptr paramPtr30, Ptr paramPtr31, Ptr paramPtr32, Ptr paramPtr33, Ptr paramPtr34, Ptr paramPtr35, Ptr paramPtr36, Ptr paramPtr37, Ptr paramPtr38, Ptr paramPtr39, Ptr paramPtr40) {
    loessf__.ehg139_(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramPtr6, paramPtr7, paramPtr8, paramPtr9, paramPtr10, paramPtr11, paramPtr12, paramPtr13, paramPtr14, paramPtr15, paramPtr16, paramPtr17, paramPtr18, paramPtr19, paramPtr20, paramPtr21, paramPtr22, paramPtr23, paramPtr24, paramPtr25, paramPtr26, paramPtr27, paramPtr28, paramPtr29, paramPtr30, paramPtr31, paramPtr32, paramPtr33, paramPtr34, paramPtr35, paramPtr36, paramPtr37, paramPtr38, paramPtr39, paramPtr40);
  }
  
  public static void ehg140_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3) {
    loessf__.ehg140_(paramPtr1, paramPtr2, paramPtr3);
  }
  
  public static void ehg141_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9) {
    loessf__.ehg141_(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramPtr6, paramPtr7, paramPtr8, paramPtr9);
  }
  
  public static void ehg169_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, Ptr paramPtr11, Ptr paramPtr12) {
    loessf__.ehg169_(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramPtr6, paramPtr7, paramPtr8, paramPtr9, paramPtr10, paramPtr11, paramPtr12);
  }
  
  public static double ehg176_(Ptr paramPtr) {
    return loessf__.ehg176_(paramPtr);
  }
  
  public static void ehg182_(Ptr paramPtr) {
    loessc__.ehg182_(paramPtr);
  }
  
  public static void ehg183_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, int paramInt) {
    loessf__.ehg183_(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramInt);
  }
  
  public static void ehg183a_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5) {
    loessc__.ehg183a_(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5);
  }
  
  public static void ehg184_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, int paramInt) {
    loessf__.ehg184_(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramInt);
  }
  
  public static void ehg184a_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5) {
    loessc__.ehg184a_(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5);
  }
  
  public static void ehg191_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, Ptr paramPtr11, Ptr paramPtr12, Ptr paramPtr13, Ptr paramPtr14, Ptr paramPtr15, Ptr paramPtr16, Ptr paramPtr17, Ptr paramPtr18, Ptr paramPtr19) {
    loessf__.ehg191_(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramPtr6, paramPtr7, paramPtr8, paramPtr9, paramPtr10, paramPtr11, paramPtr12, paramPtr13, paramPtr14, paramPtr15, paramPtr16, paramPtr17, paramPtr18, paramPtr19);
  }
  
  public static void ehg192_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9) {
    loessf__.ehg192_(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramPtr6, paramPtr7, paramPtr8, paramPtr9);
  }
  
  public static void ehg196_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4) {
    loessf__.ehg196_(paramPtr1, paramPtr2, paramPtr3, paramPtr4);
  }
  
  public static void ehg197_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6) {
    loessf__.ehg197_(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramPtr6);
  }
  
  public static void eureka_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6) {
    eureka__.eureka_(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramPtr6);
  }
  
  public static SEXP fft(SEXP paramSEXP1, SEXP paramSEXP2) {
    return fourier__.fft(paramSEXP1, paramSEXP2);
  }
  
  public static void fft_factor(Ptr paramPtr1, int paramInt, Ptr paramPtr2, Ptr paramPtr3) {
    fft__.fft_factor(paramPtr1, paramInt, paramPtr2, paramPtr3);
  }
  
  public static int fft_work(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, int paramInt1, int paramInt2, int paramInt3, int paramInt4, Ptr paramPtr4, Ptr paramPtr5) {
    return fft__.fft_work(paramPtr1, paramPtr2, paramPtr3, paramInt1, paramInt2, paramInt3, paramInt4, paramPtr4, paramPtr5);
  }
  
  public static SEXP free_starma(SEXP paramSEXP) {
    return pacf__.free_starma(paramSEXP);
  }
  
  public static SEXP getListElement(SEXP paramSEXP, Ptr paramPtr) {
    return splines__.getListElement(paramSEXP, paramPtr);
  }
  
  public static SEXP getQ0(SEXP paramSEXP1, SEXP paramSEXP2) {
    return arima__.getQ0(paramSEXP1, paramSEXP2);
  }
  
  public static SEXP getQ0bis(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3) {
    return arima__.getQ0bis(paramSEXP1, paramSEXP2, paramSEXP3);
  }
  
  public static SEXP get_resid(SEXP paramSEXP) {
    return pacf__.get_resid(paramSEXP);
  }
  
  public static SEXP get_s2(SEXP paramSEXP) {
    return pacf__.get_s2(paramSEXP);
  }
  
  public static void hcass2_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6) {
    hclust__.hcass2_(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramPtr6);
  }
  
  public static void hclust_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, Ptr paramPtr11) {
    hclust__.hclust_(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramPtr6, paramPtr7, paramPtr8, paramPtr9, paramPtr10, paramPtr11);
  }
  
  public static int ifloor_(Ptr paramPtr) {
    return loessf__.ifloor_(paramPtr);
  }
  
  public static int ioffst_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3) {
    return hclust__.ioffst_(paramPtr1, paramPtr2, paramPtr3);
  }
  
  public static void kmeans_Lloyd(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9) {
    kmeans__.kmeans_Lloyd(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramPtr6, paramPtr7, paramPtr8, paramPtr9);
  }
  
  public static void kmeans_MacQueen(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9) {
    kmeans__.kmeans_MacQueen(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramPtr6, paramPtr7, paramPtr8, paramPtr9);
  }
  
  public static void kmns_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, Ptr paramPtr11, Ptr paramPtr12, Ptr paramPtr13, Ptr paramPtr14, Ptr paramPtr15, Ptr paramPtr16, Ptr paramPtr17) {
    kmns__.kmns_(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramPtr6, paramPtr7, paramPtr8, paramPtr9, paramPtr10, paramPtr11, paramPtr12, paramPtr13, paramPtr14, paramPtr15, paramPtr16, paramPtr17);
  }
  
  public static void lbfgsb(int paramInt1, int paramInt2, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, MethodHandle paramMethodHandle1, MethodHandle paramMethodHandle2, Ptr paramPtr6, Ptr paramPtr7, double paramDouble1, double paramDouble2, Ptr paramPtr8, Ptr paramPtr9, int paramInt3, Ptr paramPtr10, int paramInt4, int paramInt5) {
    apply_optim__.lbfgsb(paramInt1, paramInt2, paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramMethodHandle1, paramMethodHandle2, paramPtr6, paramPtr7, paramDouble1, paramDouble2, paramPtr8, paramPtr9, paramInt3, paramPtr10, paramInt4, paramInt5);
  }
  
  public static void lminfl_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, Ptr paramPtr11) {
    lminfl__.lminfl_(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramPtr6, paramPtr7, paramPtr8, paramPtr9, paramPtr10, paramPtr11);
  }
  
  public static void loess_dfit(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, Ptr paramPtr11, Ptr paramPtr12, Ptr paramPtr13) {
    loessc__.loess_dfit(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramPtr6, paramPtr7, paramPtr8, paramPtr9, paramPtr10, paramPtr11, paramPtr12, paramPtr13);
  }
  
  public static void loess_dfitse(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, Ptr paramPtr11, Ptr paramPtr12, Ptr paramPtr13, Ptr paramPtr14, Ptr paramPtr15, Ptr paramPtr16) {
    loessc__.loess_dfitse(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramPtr6, paramPtr7, paramPtr8, paramPtr9, paramPtr10, paramPtr11, paramPtr12, paramPtr13, paramPtr14, paramPtr15, paramPtr16);
  }
  
  public static void loess_ifit(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8) {
    loessc__.loess_ifit(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramPtr6, paramPtr7, paramPtr8);
  }
  
  public static void loess_ise(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, Ptr paramPtr11, Ptr paramPtr12, Ptr paramPtr13, Ptr paramPtr14, Ptr paramPtr15) {
    loessc__.loess_ise(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramPtr6, paramPtr7, paramPtr8, paramPtr9, paramPtr10, paramPtr11, paramPtr12, paramPtr13, paramPtr14, paramPtr15);
  }
  
  public static void loess_raw(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, Ptr paramPtr11, Ptr paramPtr12, Ptr paramPtr13, Ptr paramPtr14, Ptr paramPtr15, Ptr paramPtr16, Ptr paramPtr17, Ptr paramPtr18, Ptr paramPtr19, Ptr paramPtr20, Ptr paramPtr21, Ptr paramPtr22, Ptr paramPtr23, Ptr paramPtr24) {
    loessc__.loess_raw(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramPtr6, paramPtr7, paramPtr8, paramPtr9, paramPtr10, paramPtr11, paramPtr12, paramPtr13, paramPtr14, paramPtr15, paramPtr16, paramPtr17, paramPtr18, paramPtr19, paramPtr20, paramPtr21, paramPtr22, paramPtr23, paramPtr24);
  }
  
  public static SEXP logit_link(SEXP paramSEXP) {
    return family__.logit_link(paramSEXP);
  }
  
  public static SEXP logit_linkinv(SEXP paramSEXP) {
    return family__.logit_linkinv(paramSEXP);
  }
  
  public static SEXP logit_mu_eta(SEXP paramSEXP) {
    return family__.logit_mu_eta(paramSEXP);
  }
  
  public static void loglin(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, Ptr paramPtr11, Ptr paramPtr12, Ptr paramPtr13, Ptr paramPtr14, Ptr paramPtr15, Ptr paramPtr16, Ptr paramPtr17) {
    loglin__.loglin(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramPtr6, paramPtr7, paramPtr8, paramPtr9, paramPtr10, paramPtr11, paramPtr12, paramPtr13, paramPtr14, paramPtr15, paramPtr16, paramPtr17);
  }
  
  public static void lowesa_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7) {
    loessf__.lowesa_(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramPtr6, paramPtr7);
  }
  
  public static void lowesb_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9) {
    loessf__.lowesb_(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramPtr6, paramPtr7, paramPtr8, paramPtr9);
  }
  
  public static void lowesc_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6) {
    loessf__.lowesc_(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramPtr6);
  }
  
  public static void lowesd_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, Ptr paramPtr11) {
    loessf__.lowesd_(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramPtr6, paramPtr7, paramPtr8, paramPtr9, paramPtr10, paramPtr11);
  }
  
  public static void lowese_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7) {
    loessf__.lowese_(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramPtr6, paramPtr7);
  }
  
  public static void lowesf_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, Ptr paramPtr11, Ptr paramPtr12) {
    loessf__.lowesf_(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramPtr6, paramPtr7, paramPtr8, paramPtr9, paramPtr10, paramPtr11, paramPtr12);
  }
  
  public static void lowesl_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7) {
    loessf__.lowesl_(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramPtr6, paramPtr7);
  }
  
  public static void lowesp_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7) {
    loessf__.lowesp_(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramPtr6, paramPtr7);
  }
  
  public static void lowesr_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5) {
    loessf__.lowesr_(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5);
  }
  
  public static SEXP lowess(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4, SEXP paramSEXP5) {
    return lowess__.lowess(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4, paramSEXP5);
  }
  
  public static void lowesw_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4) {
    loessf__.lowesw_(paramPtr1, paramPtr2, paramPtr3, paramPtr4);
  }
  
  public static void massdist(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7) {
    massdist__.massdist(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramPtr6, paramPtr7);
  }
  
  public static SEXP modelframe(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4) {
    return model__.modelframe(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4);
  }
  
  public static SEXP modelmatrix(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4) {
    return model__.modelmatrix(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4);
  }
  
  public static SEXP monoFC_m(SEXP paramSEXP1, SEXP paramSEXP2) {
    return monoSpl__.monoFC_m(paramSEXP1, paramSEXP2);
  }
  
  public static void monoFC_mod(Ptr paramPtr1, Ptr paramPtr2, int paramInt) {
    monoSpl__.monoFC_mod(paramPtr1, paramPtr2, paramInt);
  }
  
  public static SEXP mvfft(SEXP paramSEXP1, SEXP paramSEXP2) {
    return fourier__.mvfft(paramSEXP1, paramSEXP2);
  }
  
  public static SEXP nextn(SEXP paramSEXP1, SEXP paramSEXP2) {
    return fourier__.nextn(paramSEXP1, paramSEXP2);
  }
  
  public static SEXP nlm(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4) {
    return optimize__.nlm(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4);
  }
  
  public static void nmmin(int paramInt1, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, MethodHandle paramMethodHandle, Ptr paramPtr4, double paramDouble1, double paramDouble2, Ptr paramPtr5, double paramDouble3, double paramDouble4, double paramDouble5, int paramInt2, Ptr paramPtr6, int paramInt3) {
    apply_optim__.nmmin(paramInt1, paramPtr1, paramPtr2, paramPtr3, paramMethodHandle, paramPtr4, paramDouble1, paramDouble2, paramPtr5, paramDouble3, paramDouble4, paramDouble5, paramInt2, paramPtr6, paramInt3);
  }
  
  public static SEXP optim(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4) {
    return optim__.optim(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4);
  }
  
  public static SEXP optimhess(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4) {
    return optim__.optimhess(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4);
  }
  
  public static void optra_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, Ptr paramPtr11, Ptr paramPtr12, Ptr paramPtr13, Ptr paramPtr14, Ptr paramPtr15) {
    kmns__.optra_(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramPtr6, paramPtr7, paramPtr8, paramPtr9, paramPtr10, paramPtr11, paramPtr12, paramPtr13, paramPtr14, paramPtr15);
  }
  
  public static SEXP pacf1(SEXP paramSEXP1, SEXP paramSEXP2) {
    return pacf__.pacf1(paramSEXP1, paramSEXP2);
  }
  
  public static void pkolmogorov2x(Ptr paramPtr1, Ptr paramPtr2) {
    ks__.pkolmogorov2x(paramPtr1, paramPtr2);
  }
  
  public static void pkstwo(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3) {
    ks__.pkstwo(paramPtr1, paramPtr2, paramPtr3);
  }
  
  public static void psmirnov2x(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3) {
    ks__.psmirnov2x(paramPtr1, paramPtr2, paramPtr3);
  }
  
  public static void psort_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4) {
    stl__.psort_(paramPtr1, paramPtr2, paramPtr3, paramPtr4);
  }
  
  public static void qtran_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, Ptr paramPtr11, Ptr paramPtr12, Ptr paramPtr13, Ptr paramPtr14) {
    kmns__.qtran_(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramPtr6, paramPtr7, paramPtr8, paramPtr9, paramPtr10, paramPtr11, paramPtr12, paramPtr13, paramPtr14);
  }
  
  public static void rbart_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, Ptr paramPtr11, Ptr paramPtr12, Ptr paramPtr13, Ptr paramPtr14, Ptr paramPtr15, Ptr paramPtr16, Ptr paramPtr17, Ptr paramPtr18, Ptr paramPtr19, Ptr paramPtr20) {
    qsbart__.rbart_(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramPtr6, paramPtr7, paramPtr8, paramPtr9, paramPtr10, paramPtr11, paramPtr12, paramPtr13, paramPtr14, paramPtr15, paramPtr16, paramPtr17, paramPtr18, paramPtr19, paramPtr20);
  }
  
  public static SEXP rfilter(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3) {
    return filter__.rfilter(paramSEXP1, paramSEXP2, paramSEXP3);
  }
  
  public static SEXP runmed(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4, SEXP paramSEXP5) {
    return Srunmed__.runmed(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4, paramSEXP5);
  }
  
  public static void samin(int paramInt1, Ptr paramPtr1, Ptr paramPtr2, MethodHandle paramMethodHandle, int paramInt2, int paramInt3, double paramDouble, int paramInt4, Ptr paramPtr3) {
    apply_optim__.samin(paramInt1, paramPtr1, paramPtr2, paramMethodHandle, paramInt2, paramInt3, paramDouble, paramInt4, paramPtr3);
  }
  
  public static void sbart_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, Ptr paramPtr11, Ptr paramPtr12, Ptr paramPtr13, Ptr paramPtr14, Ptr paramPtr15, Ptr paramPtr16, Ptr paramPtr17, Ptr paramPtr18, Ptr paramPtr19, Ptr paramPtr20, Ptr paramPtr21, Ptr paramPtr22, Ptr paramPtr23, Ptr paramPtr24, Ptr paramPtr25, Ptr paramPtr26, Ptr paramPtr27, Ptr paramPtr28, Ptr paramPtr29, Ptr paramPtr30, Ptr paramPtr31, Ptr paramPtr32, Ptr paramPtr33, Ptr paramPtr34, Ptr paramPtr35, Ptr paramPtr36, Ptr paramPtr37, Ptr paramPtr38) {
    sbart__.sbart_(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramPtr6, paramPtr7, paramPtr8, paramPtr9, paramPtr10, paramPtr11, paramPtr12, paramPtr13, paramPtr14, paramPtr15, paramPtr16, paramPtr17, paramPtr18, paramPtr19, paramPtr20, paramPtr21, paramPtr22, paramPtr23, paramPtr24, paramPtr25, paramPtr26, paramPtr27, paramPtr28, paramPtr29, paramPtr30, paramPtr31, paramPtr32, paramPtr33, paramPtr34, paramPtr35, paramPtr36, paramPtr37, paramPtr38);
  }
  
  public static SEXP set_trans(SEXP paramSEXP1, SEXP paramSEXP2) {
    return pacf__.set_trans(paramSEXP1, paramSEXP2);
  }
  
  public static SEXP setup_starma(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4, SEXP paramSEXP5, SEXP paramSEXP6, SEXP paramSEXP7, SEXP paramSEXP8) {
    return pacf__.setup_starma(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4, paramSEXP5, paramSEXP6, paramSEXP7, paramSEXP8);
  }
  
  public static void sgram_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6) {
    sgram__.sgram_(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramPtr6);
  }
  
  public static void sinerp_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7) {
    sinerp__.sinerp_(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramPtr6, paramPtr7);
  }
  
  public static void sslvrg_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, Ptr paramPtr11, Ptr paramPtr12, Ptr paramPtr13, Ptr paramPtr14, Ptr paramPtr15, Ptr paramPtr16, Ptr paramPtr17, Ptr paramPtr18, Ptr paramPtr19, Ptr paramPtr20, Ptr paramPtr21, Ptr paramPtr22, Ptr paramPtr23, Ptr paramPtr24, Ptr paramPtr25, Ptr paramPtr26, Ptr paramPtr27, Ptr paramPtr28, Ptr paramPtr29, Ptr paramPtr30) {
    sslvrg__.sslvrg_(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramPtr6, paramPtr7, paramPtr8, paramPtr9, paramPtr10, paramPtr11, paramPtr12, paramPtr13, paramPtr14, paramPtr15, paramPtr16, paramPtr17, paramPtr18, paramPtr19, paramPtr20, paramPtr21, paramPtr22, paramPtr23, paramPtr24, paramPtr25, paramPtr26, paramPtr27, paramPtr28, paramPtr29, paramPtr30);
  }
  
  public static void stl_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, Ptr paramPtr11, Ptr paramPtr12, Ptr paramPtr13, Ptr paramPtr14, Ptr paramPtr15, Ptr paramPtr16, Ptr paramPtr17, Ptr paramPtr18) {
    stl__.stl_(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramPtr6, paramPtr7, paramPtr8, paramPtr9, paramPtr10, paramPtr11, paramPtr12, paramPtr13, paramPtr14, paramPtr15, paramPtr16, paramPtr17, paramPtr18);
  }
  
  public static void stless_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9) {
    stl__.stless_(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramPtr6, paramPtr7, paramPtr8, paramPtr9);
  }
  
  public static void stlest_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, Ptr paramPtr11, Ptr paramPtr12) {
    stl__.stlest_(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramPtr6, paramPtr7, paramPtr8, paramPtr9, paramPtr10, paramPtr11, paramPtr12);
  }
  
  public static void stlez_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, Ptr paramPtr11, Ptr paramPtr12) {
    stl__.stlez_(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramPtr6, paramPtr7, paramPtr8, paramPtr9, paramPtr10, paramPtr11, paramPtr12);
  }
  
  public static void stlfts_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5) {
    stl__.stlfts_(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5);
  }
  
  public static void stlma_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4) {
    stl__.stlma_(paramPtr1, paramPtr2, paramPtr3, paramPtr4);
  }
  
  public static void stlrwt_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4) {
    stl__.stlrwt_(paramPtr1, paramPtr2, paramPtr3, paramPtr4);
  }
  
  public static void stlss_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, Ptr paramPtr11, Ptr paramPtr12, Ptr paramPtr13) {
    stl__.stlss_(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramPtr6, paramPtr7, paramPtr8, paramPtr9, paramPtr10, paramPtr11, paramPtr12, paramPtr13);
  }
  
  public static void stlstp_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, Ptr paramPtr11, Ptr paramPtr12, Ptr paramPtr13, Ptr paramPtr14, Ptr paramPtr15, Ptr paramPtr16, Ptr paramPtr17, Ptr paramPtr18) {
    stl__.stlstp_(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramPtr6, paramPtr7, paramPtr8, paramPtr9, paramPtr10, paramPtr11, paramPtr12, paramPtr13, paramPtr14, paramPtr15, paramPtr16, paramPtr17, paramPtr18);
  }
  
  public static void stxwx_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, Ptr paramPtr11) {
    stxwx__.stxwx_(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramPtr6, paramPtr7, paramPtr8, paramPtr9, paramPtr10, paramPtr11);
  }
  
  public static SEXP termsform(SEXP paramSEXP) {
    return model__.termsform(paramSEXP);
  }
  
  public static SEXP updateform(SEXP paramSEXP1, SEXP paramSEXP2) {
    return model__.updateform(paramSEXP1, paramSEXP2);
  }
  
  public static void vmmin(int paramInt1, Ptr paramPtr1, Ptr paramPtr2, MethodHandle paramMethodHandle1, MethodHandle paramMethodHandle2, int paramInt2, int paramInt3, Ptr paramPtr3, double paramDouble1, double paramDouble2, int paramInt4, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7) {
    apply_optim__.vmmin(paramInt1, paramPtr1, paramPtr2, paramMethodHandle1, paramMethodHandle2, paramInt2, paramInt3, paramPtr3, paramDouble1, paramDouble2, paramInt4, paramPtr4, paramPtr5, paramPtr6, paramPtr7);
  }
  
  public static SEXP zeroin2(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4) {
    return optimize__.zeroin2(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/stats-0.9.2724.jar!/org/renjin/stats/stats.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */