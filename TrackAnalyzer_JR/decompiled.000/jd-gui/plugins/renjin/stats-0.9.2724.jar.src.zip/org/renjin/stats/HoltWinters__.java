package org.renjin.stats;

import org.renjin.gcc.runtime.Ptr;

public class HoltWinters__ {
  static {
  
  }
  
  public static void HoltWinters(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, Ptr paramPtr11, Ptr paramPtr12, Ptr paramPtr13, Ptr paramPtr14, Ptr paramPtr15, Ptr paramPtr16, Ptr paramPtr17) {
    paramPtr15.setDouble(paramPtr11.getDouble());
    if (paramPtr9.getInt() == 1)
      paramPtr16.setDouble(paramPtr12.getDouble()); 
    if (paramPtr10.getInt() == 1)
      paramPtr17.memcpy(paramPtr13, paramPtr8.getInt() * 8); 
    for (int i = paramPtr6.getInt() + -1; paramPtr2.getInt() > i; i++) {
      double d3;
      int k = i - paramPtr6.getInt() + 2;
      int j = paramPtr8.getInt() + k + -1;
      double d1 = paramPtr15.getDouble((k + -1) * 8);
      if (paramPtr9.getInt() != 1) {
        d2 = 0.0D;
      } else {
        d2 = paramPtr16.getDouble((k + -1) * 8);
      } 
      d1 += d2;
      if (paramPtr10.getInt() != 1) {
        if (paramPtr7.getInt() == 1) {
          d2 = 0.0D;
        } else {
          d2 = 1.0D;
        } 
        d3 = d2;
      } else {
        d3 = paramPtr17.getDouble((j - paramPtr8.getInt()) * 8);
      } 
      double d2 = d3;
      if (paramPtr7.getInt() != 1) {
        d1 *= d3;
      } else {
        d1 += d3;
      } 
      paramPtr14.setDouble((paramPtr1.getDouble(i * 8) - d1) * (paramPtr1.getDouble(i * 8) - d1) + paramPtr14.getDouble());
      if (paramPtr7.getInt() != 1) {
        paramPtr15.setDouble(k * 8, paramPtr3.getDouble() * paramPtr1.getDouble(i * 8) / d2 + (1.0D - paramPtr3.getDouble()) * (paramPtr15.getDouble((k + -1) * 8) + paramPtr16.getDouble((k + -1) * 8)));
      } else {
        paramPtr15.setDouble(k * 8, paramPtr3.getDouble() * (paramPtr1.getDouble(i * 8) - d2) + (1.0D - paramPtr3.getDouble()) * (paramPtr15.getDouble((k + -1) * 8) + paramPtr16.getDouble((k + -1) * 8)));
      } 
      if (paramPtr9.getInt() == 1)
        paramPtr16.setDouble(k * 8, paramPtr4.getDouble() * (paramPtr15.getDouble(k * 8) - paramPtr15.getDouble((k + -1) * 8)) + (1.0D - paramPtr4.getDouble()) * paramPtr16.getDouble((k + -1) * 8)); 
      if (paramPtr10.getInt() == 1)
        if (paramPtr7.getInt() != 1) {
          paramPtr17.setDouble(j * 8, paramPtr5.getDouble() * paramPtr1.getDouble(i * 8) / paramPtr15.getDouble(k * 8) + (1.0D - paramPtr5.getDouble()) * d2);
        } else {
          paramPtr17.setDouble(j * 8, paramPtr5.getDouble() * (paramPtr1.getDouble(i * 8) - paramPtr15.getDouble(k * 8)) + (1.0D - paramPtr5.getDouble()) * d2);
        }  
    } 
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/stats-0.9.2724.jar!/org/renjin/stats/HoltWinters__.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */