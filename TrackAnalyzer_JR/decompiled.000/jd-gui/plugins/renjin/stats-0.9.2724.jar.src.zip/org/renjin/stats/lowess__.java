package org.renjin.stats;

import org.renjin.gcc.runtime.BytePtr;
import org.renjin.gcc.runtime.DoublePtr;
import org.renjin.gcc.runtime.IntPtr;
import org.renjin.gcc.runtime.Mathlib;
import org.renjin.gcc.runtime.Ptr;
import org.renjin.gnur.api.Arith;
import org.renjin.gnur.api.Error;
import org.renjin.gnur.api.Rinternals;
import org.renjin.gnur.api.Rinternals2;
import org.renjin.gnur.api.Rmath;
import org.renjin.gnur.api.Utils;
import org.renjin.sexp.SEXP;

public class lowess__ {
  static {
  
  }
  
  public static void clowess(Ptr paramPtr1, Ptr paramPtr2, int paramInt1, double paramDouble1, int paramInt2, double paramDouble2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5) {
    int[] arrayOfInt = new int[1];
    arrayOfInt[0] = 0;
    if (paramInt1 > 1) {
      paramPtr1 = paramPtr1.pointerPlus(-8);
      paramPtr2 = paramPtr2.pointerPlus(-8);
      paramPtr3 = paramPtr3.pointerPlus(-8);
      int i = Rmath.Rf_imax2(2, Rmath.Rf_imin2(paramInt1, (int)(paramInt1 * paramDouble1 + 1.0E-7D)));
      byte b = 1;
      while (paramInt2 + 1 >= b) {
        int j = 1;
        int k = i;
        int m = 0;
        int n = 1;
        while (true) {
          if (k >= paramInt1 || paramPtr1.getDouble(n * 8) - paramPtr1.getDouble(j * 8) <= paramPtr1.getDouble((k + 1) * 8) - paramPtr1.getDouble(n * 8)) {
            boolean bool;
            if (b <= 1) {
              bool = false;
            } else {
              bool = true;
            } 
            Ptr ptr1 = paramPtr1.pointerPlus(8);
            Ptr ptr2 = paramPtr2.pointerPlus(8);
            Ptr ptr3 = paramPtr1.pointerPlus(n * 8);
            Ptr ptr4 = paramPtr3.pointerPlus(n * 8);
            lowest(ptr1, ptr2, paramInt1, ptr3, ptr4, j, k, paramPtr5, bool, paramPtr4, (Ptr)new IntPtr(arrayOfInt, 0));
            if (arrayOfInt[0] == 0)
              paramPtr3.setDouble(n * 8, paramPtr2.getDouble(n * 8)); 
            if (n + -1 > m) {
              double d1 = paramPtr1.getDouble(n * 8) - paramPtr1.getDouble(m * 8);
              for (int i1 = m + 1; i1 < n; i1++) {
                paramDouble1 = (paramPtr1.getDouble(i1 * 8) - paramPtr1.getDouble(m * 8)) / d1;
                paramPtr3.setDouble(i1 * 8, paramPtr3.getDouble(n * 8) * paramDouble1 + (1.0D - paramDouble1) * paramPtr3.getDouble(m * 8));
              } 
            } 
            m = n;
            paramDouble1 = paramPtr1.getDouble(n * 8) + paramDouble2;
            while (++n <= paramInt1 && paramPtr1.getDouble(n * 8) <= paramDouble1) {
              if (paramPtr1.getDouble(n * 8) == paramPtr1.getDouble(m * 8)) {
                paramPtr3.setDouble(n * 8, paramPtr3.getDouble(m * 8));
                m = n;
              } 
              n++;
            } 
            n = Rmath.Rf_imax2(m + 1, n + -1);
            if (m < paramInt1)
              continue; 
            for (j = 0; j < paramInt1; j++)
              paramPtr5.setDouble(j * 8, paramPtr2.getDouble((j + 1) * 8) - paramPtr3.getDouble((j + 1) * 8)); 
            paramDouble1 = 0.0D;
            for (j = 0; j < paramInt1; j++)
              paramDouble1 = Math.abs(paramPtr5.getDouble(j * 8)) + paramDouble1; 
            double d = paramDouble1 / paramInt1;
            if (b <= paramInt2) {
              for (j = 0; j < paramInt1; j++)
                paramPtr4.setDouble(j * 8, Math.abs(paramPtr5.getDouble(j * 8))); 
              k = paramInt1 / 2;
              Utils.Rf_rPsort((DoublePtr)paramPtr4, paramInt1, k);
              if ((paramInt1 & 0x1) != 0) {
                paramDouble1 = paramPtr4.getDouble(k * 8) * 6.0D;
              } else {
                j = paramInt1 - k + -1;
                Utils.Rf_rPsort((DoublePtr)paramPtr4, paramInt1, j);
                paramDouble1 = (paramPtr4.getDouble(k * 8) + paramPtr4.getDouble(j * 8)) * 3.0D;
              } 
              if (d * 1.0E-7D <= paramDouble1) {
                double d1 = paramDouble1 * 0.999D;
                double d2 = paramDouble1 * 0.001D;
                for (j = 0; j < paramInt1; j++) {
                  d = Math.abs(paramPtr5.getDouble(j * 8));
                  if (d > d2) {
                    if (d > d1) {
                      paramPtr4.setDouble(j * 8, 0.0D);
                    } else {
                      paramPtr4.setDouble(j * 8, fsquare(1.0D - fsquare(d / paramDouble1)));
                    } 
                  } else {
                    paramPtr4.setDouble(j * 8, 1.0D);
                  } 
                } 
                b++;
                continue;
              } 
            } 
            break;
          } 
          j++;
          k++;
        } 
        break;
      } 
      return;
    } 
    paramPtr3.setDouble(paramPtr2.getDouble());
  }
  
  public static double fcube(double paramDouble) {
    return paramDouble * paramDouble * paramDouble;
  }
  
  public static double fsquare(double paramDouble) {
    return paramDouble * paramDouble;
  }
  
  public static SEXP lowess(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4, SEXP paramSEXP5) {
    if (Rinternals.TYPEOF(paramSEXP1) != 14 || Rinternals.TYPEOF(paramSEXP2) != 14)
      Error.Rf_error(new BytePtr("invalid input\000".getBytes(), 0), new Object[0]); 
    int j = Rinternals.LENGTH(paramSEXP1);
    if (j == Arith.R_NaInt || j == 0)
      Error.Rf_error(new BytePtr("invalid input\000".getBytes(), 0), new Object[0]); 
    double d2 = Rinternals.Rf_asReal(paramSEXP3);
    if (Arith.R_finite(d2) == 0 || d2 <= 0.0D)
      Error.Rf_error(new BytePtr("'f' must be finite and > 0\000".getBytes(), 0), new Object[0]); 
    int i = Rinternals.Rf_asInteger(paramSEXP4);
    if (i == Arith.R_NaInt || i < 0)
      Error.Rf_error(new BytePtr("'iter' must be finite and >= 0\000".getBytes(), 0), new Object[0]); 
    double d1 = Rinternals.Rf_asReal(paramSEXP5);
    if (Arith.R_finite(d1) == 0 || d1 < 0.0D)
      Error.Rf_error(new BytePtr("'delta' must be finite and > 0\000".getBytes(), 0), new Object[0]); 
    paramSEXP4 = Rinternals.Rf_allocVector(14, j);
    Rinternals.Rf_protect(paramSEXP4);
    DoublePtr doublePtr2 = DoublePtr.malloc(j * 8);
    DoublePtr doublePtr1 = DoublePtr.malloc(j * 8);
    Ptr ptr2 = Rinternals2.REAL(paramSEXP4);
    Ptr ptr1 = Rinternals2.REAL(paramSEXP2);
    clowess(Rinternals2.REAL(paramSEXP1), ptr1, j, d2, i, d1, ptr2, (Ptr)doublePtr2, (Ptr)doublePtr1);
    return paramSEXP4;
  }
  
  public static void lowest(Ptr paramPtr1, Ptr paramPtr2, int paramInt1, Ptr paramPtr3, Ptr paramPtr4, int paramInt2, int paramInt3, Ptr paramPtr5, int paramInt4, Ptr paramPtr6, Ptr paramPtr7) {
    paramPtr1 = paramPtr1.pointerPlus(-8);
    paramPtr2 = paramPtr2.pointerPlus(-8);
    paramPtr5 = paramPtr5.pointerPlus(-8);
    paramPtr6 = paramPtr6.pointerPlus(-8);
    double d2 = paramPtr1.getDouble(paramInt1 * 8) - paramPtr1.getDouble(8);
    double d1 = paramPtr1.getDouble(paramInt3 * 8) - paramPtr3.getDouble();
    double d3 = Rmath.Rf_fmax2(paramPtr3.getDouble() - paramPtr1.getDouble(paramInt2 * 8), d1);
    double d4 = d3 * 0.999D;
    double d5 = d3 * 0.001D;
    double d6 = 0.0D;
    for (paramInt3 = paramInt2; paramInt3 <= paramInt1; paramInt3++) {
      paramPtr5.setDouble(paramInt3 * 8, 0.0D);
      d1 = Math.abs(paramPtr1.getDouble(paramInt3 * 8) - paramPtr3.getDouble());
      if (d1 > d4) {
        if (paramPtr1.getDouble(paramInt3 * 8) <= paramPtr3.getDouble())
          continue; 
        break;
      } 
      if (d1 > d5) {
        paramPtr5.setDouble(paramInt3 * 8, fcube(1.0D - fcube(d1 / d3)));
      } else {
        paramPtr5.setDouble(paramInt3 * 8, 1.0D);
      } 
      if (paramInt4 != 0)
        paramPtr5.setDouble(paramInt3 * 8, paramPtr5.getDouble(paramInt3 * 8) * paramPtr6.getDouble(paramInt3 * 8)); 
      d6 = paramPtr5.getDouble(paramInt3 * 8) + d6;
      continue;
    } 
    paramInt1 = paramInt3 + -1;
    if (d6 > 0.0D) {
      paramPtr7.setInt(1);
      for (paramInt3 = paramInt2; paramInt3 <= paramInt1; paramInt3++)
        paramPtr5.setDouble(paramInt3 * 8, paramPtr5.getDouble(paramInt3 * 8) / d6); 
      if (d3 > 0.0D) {
        d1 = 0.0D;
        for (paramInt3 = paramInt2; paramInt3 <= paramInt1; paramInt3++)
          d1 = paramPtr5.getDouble(paramInt3 * 8) * paramPtr1.getDouble(paramInt3 * 8) + d1; 
        d3 = paramPtr3.getDouble() - d1;
        d4 = 0.0D;
        int j;
        for (j = paramInt2; j <= paramInt1; j++)
          d4 = paramPtr5.getDouble(j * 8) * fsquare(paramPtr1.getDouble(j * 8) - d1) + d4; 
        if (Mathlib.sqrt(d4) > d2 * 0.001D) {
          d2 = d3 / d4;
          for (j = paramInt2; j <= paramInt1; j++)
            paramPtr5.setDouble(j * 8, paramPtr5.getDouble(j * 8) * ((paramPtr1.getDouble(j * 8) - d1) * d2 + 1.0D)); 
        } 
      } 
      paramPtr4.setDouble(0.0D);
      for (int i = paramInt2; i <= paramInt1; i++)
        paramPtr4.setDouble(paramPtr4.getDouble() + paramPtr5.getDouble(i * 8) * paramPtr2.getDouble(i * 8)); 
      return;
    } 
    paramPtr7.setInt(0);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/stats-0.9.2724.jar!/org/renjin/stats/lowess__.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */