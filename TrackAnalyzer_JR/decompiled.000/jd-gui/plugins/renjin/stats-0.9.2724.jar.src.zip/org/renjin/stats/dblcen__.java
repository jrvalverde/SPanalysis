package org.renjin.stats;

import org.renjin.gcc.runtime.BytePtr;
import org.renjin.gcc.runtime.Ptr;
import org.renjin.gnur.api.Rinternals;
import org.renjin.gnur.api.Rinternals2;
import org.renjin.sexp.SEXP;

public class dblcen__ {
  static {
  
  }
  
  public static SEXP DoubleCentre(SEXP paramSEXP) {
    BytePtr.of(0);
    int i = Rinternals.Rf_nrows(paramSEXP);
    Ptr ptr = Rinternals2.REAL(paramSEXP);
    byte b;
    for (b = 0; b < i; b++) {
      double d = 0.0D;
      byte b1;
      for (b1 = 0; b1 < i; b1++)
        d = ptr.getDouble(0 + (b1 * i + b) * 8) + d; 
      d /= i;
      for (b1 = 0; b1 < i; b1++)
        ptr.setDouble(0 + (b1 * i + b) * 8, ptr.getDouble(0 + (b1 * i + b) * 8) - d); 
    } 
    for (b = 0; b < i; b++) {
      double d = 0.0D;
      byte b1;
      for (b1 = 0; b1 < i; b1++)
        d = ptr.getDouble(0 + (b * i + b1) * 8) + d; 
      d /= i;
      for (b1 = 0; b1 < i; b1++)
        ptr.setDouble(0 + (b * i + b1) * 8, ptr.getDouble(0 + (b * i + b1) * 8) - d); 
    } 
    return paramSEXP;
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/stats-0.9.2724.jar!/org/renjin/stats/dblcen__.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */