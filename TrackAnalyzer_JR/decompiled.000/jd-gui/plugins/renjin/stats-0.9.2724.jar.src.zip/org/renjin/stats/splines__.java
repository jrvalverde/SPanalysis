package org.renjin.stats;

import org.renjin.gcc.runtime.Builtins;
import org.renjin.gcc.runtime.BytePtr;
import org.renjin.gcc.runtime.DoublePtr;
import org.renjin.gcc.runtime.Mathlib;
import org.renjin.gcc.runtime.Ptr;
import org.renjin.gcc.runtime.Stdlib;
import org.renjin.gnur.api.Error;
import org.renjin.gnur.api.Rinternals;
import org.renjin.gnur.api.Rinternals2;
import org.renjin.sexp.SEXP;

public class splines__ {
  static {
  
  }
  
  public static SEXP SplineCoef(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3) {
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    SEXP sEXP3 = (SEXP)BytePtr.of(0).getArray();
    sEXP3 = (SEXP)BytePtr.of(0).getArray();
    sEXP3 = (SEXP)BytePtr.of(0).getArray();
    paramSEXP2 = Rinternals.Rf_protect(Rinternals.Rf_coerceVector(paramSEXP2, 14));
    paramSEXP3 = Rinternals.Rf_protect(Rinternals.Rf_coerceVector(paramSEXP3, 14));
    int j = Rinternals.LENGTH(paramSEXP2);
    int i = Rinternals.Rf_asInteger(paramSEXP1);
    if (Rinternals.LENGTH(paramSEXP3) != j)
      Error.Rf_error(new BytePtr("inputs of different lengths\000".getBytes(), 0), new Object[0]); 
    SEXP sEXP4 = Rinternals.Rf_protect(Rinternals.Rf_allocVector(14, j));
    SEXP sEXP5 = Rinternals.Rf_protect(Rinternals.Rf_allocVector(14, j));
    SEXP sEXP6 = Rinternals.Rf_protect(Rinternals.Rf_allocVector(14, j));
    Ptr ptr1 = Rinternals2.REAL(sEXP4);
    Ptr ptr3 = Rinternals2.REAL(sEXP5);
    Ptr ptr4 = Rinternals2.REAL(sEXP6);
    for (byte b = 0; b < j; b++) {
      int m = 0 + b * 8;
      int k = 0 + b * 8;
      ptr4.setDouble(k, 0.0D);
      ptr3.setDouble(m, ptr4.getDouble(k));
      ptr1.setDouble(0 + b * 8, ptr3.getDouble(m));
    } 
    Ptr ptr2 = Rinternals2.REAL(paramSEXP3);
    spline_coef(i, j, Rinternals2.REAL(paramSEXP2), ptr2, ptr1.pointerPlus(0), ptr3.pointerPlus(0), ptr4.pointerPlus(0));
    SEXP sEXP2 = Rinternals.Rf_protect(Rinternals.Rf_allocVector(19, 7));
    Rinternals.SET_VECTOR_ELT(sEXP2, 0, Rinternals.Rf_ScalarInteger(i));
    Rinternals.SET_VECTOR_ELT(sEXP2, 1, Rinternals.Rf_ScalarInteger(j));
    Rinternals.SET_VECTOR_ELT(sEXP2, 2, paramSEXP2);
    Rinternals.SET_VECTOR_ELT(sEXP2, 3, paramSEXP3);
    Rinternals.SET_VECTOR_ELT(sEXP2, 4, sEXP4);
    Rinternals.SET_VECTOR_ELT(sEXP2, 5, sEXP5);
    Rinternals.SET_VECTOR_ELT(sEXP2, 6, sEXP6);
    SEXP sEXP1 = Rinternals.Rf_allocVector(16, 7);
    Rinternals.Rf_setAttrib(sEXP2, Rinternals.R_NamesSymbol, sEXP1);
    Rinternals.SET_STRING_ELT(sEXP1, 0, Rinternals.Rf_mkChar((Ptr)new BytePtr("method\000".getBytes(), 0)));
    Rinternals.SET_STRING_ELT(sEXP1, 1, Rinternals.Rf_mkChar((Ptr)new BytePtr("n\000".getBytes(), 0)));
    Rinternals.SET_STRING_ELT(sEXP1, 2, Rinternals.Rf_mkChar((Ptr)new BytePtr("x\000".getBytes(), 0)));
    Rinternals.SET_STRING_ELT(sEXP1, 3, Rinternals.Rf_mkChar((Ptr)new BytePtr("y\000".getBytes(), 0)));
    Rinternals.SET_STRING_ELT(sEXP1, 4, Rinternals.Rf_mkChar((Ptr)new BytePtr("b\000".getBytes(), 0)));
    Rinternals.SET_STRING_ELT(sEXP1, 5, Rinternals.Rf_mkChar((Ptr)new BytePtr("c\000".getBytes(), 0)));
    Rinternals.SET_STRING_ELT(sEXP1, 6, Rinternals.Rf_mkChar((Ptr)new BytePtr("d\000".getBytes(), 0)));
    return sEXP2;
  }
  
  public static SEXP SplineEval(SEXP paramSEXP1, SEXP paramSEXP2) {
    int k = Rinternals.LENGTH(Rinternals.Rf_protect(Rinternals.Rf_coerceVector(paramSEXP1, 14)));
    SEXP sEXP = Rinternals.Rf_protect(Rinternals.Rf_allocVector(14, k));
    int j = Rinternals.Rf_asInteger(getListElement(paramSEXP2, (Ptr)new BytePtr("method\000".getBytes(), 0)));
    int i = Rinternals.Rf_asInteger(getListElement(paramSEXP2, (Ptr)new BytePtr("n\000".getBytes(), 0)));
    Ptr ptr7 = Rinternals2.REAL(getListElement(paramSEXP2, (Ptr)new BytePtr("d\000".getBytes(), 0)));
    Ptr ptr6 = Rinternals2.REAL(getListElement(paramSEXP2, (Ptr)new BytePtr("c\000".getBytes(), 0)));
    Ptr ptr5 = Rinternals2.REAL(getListElement(paramSEXP2, (Ptr)new BytePtr("b\000".getBytes(), 0)));
    Ptr ptr4 = Rinternals2.REAL(getListElement(paramSEXP2, (Ptr)new BytePtr("y\000".getBytes(), 0)));
    Ptr ptr3 = Rinternals2.REAL(getListElement(paramSEXP2, (Ptr)new BytePtr("x\000".getBytes(), 0)));
    Ptr ptr2 = Rinternals2.REAL(sEXP);
    Ptr ptr1 = Rinternals2.REAL(Rinternals.Rf_protect(Rinternals.Rf_coerceVector(paramSEXP1, 14)));
    spline_eval(j, k, ptr1, ptr2, i, ptr3, ptr4, ptr5, ptr6, ptr7);
    return sEXP;
  }
  
  public static void fmm_spline(int paramInt, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5) {
    Ptr ptr = paramPtr1.pointerPlus(-8);
    paramPtr1 = paramPtr2.pointerPlus(-8);
    paramPtr2 = paramPtr3.pointerPlus(-8);
    paramPtr3 = paramPtr4.pointerPlus(-8);
    paramPtr4 = paramPtr5.pointerPlus(-8);
    if (paramInt > 1) {
      int i;
      if (paramInt > 2) {
        int j = paramInt + -1;
        paramPtr4.setDouble(8, ptr.getDouble(16) - ptr.getDouble(8));
        paramPtr3.setDouble(16, (paramPtr1.getDouble(16) - paramPtr1.getDouble(8)) / paramPtr4.getDouble(8));
        int k;
        for (k = 2; k < paramInt; k++) {
          paramPtr4.setDouble(k * 8, ptr.getDouble((k + 1) * 8) - ptr.getDouble(k * 8));
          paramPtr2.setDouble(k * 8, (paramPtr4.getDouble((k + -1) * 8) + paramPtr4.getDouble(k * 8)) * 2.0D);
          paramPtr3.setDouble((k + 1) * 8, (paramPtr1.getDouble((k + 1) * 8) - paramPtr1.getDouble(k * 8)) / paramPtr4.getDouble(k * 8));
          paramPtr3.setDouble(k * 8, paramPtr3.getDouble((k + 1) * 8) - paramPtr3.getDouble(k * 8));
        } 
        paramPtr2.setDouble(8, -paramPtr4.getDouble(8));
        paramPtr2.setDouble(paramInt * 8, -paramPtr4.getDouble(j * 8));
        k = paramInt * 8;
        paramPtr3.setDouble(k, 0.0D);
        paramPtr3.setDouble(8, paramPtr3.getDouble(k));
        if (paramInt > 3) {
          paramPtr3.setDouble(8, paramPtr3.getDouble(24) / (ptr.getDouble(32) - ptr.getDouble(16)) - paramPtr3.getDouble(16) / (ptr.getDouble(24) - ptr.getDouble(8)));
          paramPtr3.setDouble(paramInt * 8, paramPtr3.getDouble(j * 8) / (ptr.getDouble(paramInt * 8) - ptr.getDouble((paramInt + -2) * 8)) - paramPtr3.getDouble((paramInt + -2) * 8) / (ptr.getDouble(j * 8) - ptr.getDouble((paramInt + -3) * 8)));
          paramPtr3.setDouble(8, paramPtr3.getDouble(8) * paramPtr4.getDouble(8) * paramPtr4.getDouble(8) / (ptr.getDouble(32) - ptr.getDouble(8)));
          paramPtr3.setDouble(paramInt * 8, -paramPtr3.getDouble(paramInt * 8) * paramPtr4.getDouble(j * 8) * paramPtr4.getDouble(j * 8) / (ptr.getDouble(paramInt * 8) - ptr.getDouble((paramInt + -3) * 8)));
        } 
        for (i = 2; i <= paramInt; i++) {
          double d = paramPtr4.getDouble((i + -1) * 8) / paramPtr2.getDouble((i + -1) * 8);
          paramPtr2.setDouble(i * 8, paramPtr2.getDouble(i * 8) - paramPtr4.getDouble((i + -1) * 8) * d);
          paramPtr3.setDouble(i * 8, paramPtr3.getDouble(i * 8) - paramPtr3.getDouble((i + -1) * 8) * d);
        } 
        paramPtr3.setDouble(paramInt * 8, paramPtr3.getDouble(paramInt * 8) / paramPtr2.getDouble(paramInt * 8));
        for (i = j; i > 0; i--)
          paramPtr3.setDouble(i * 8, (paramPtr3.getDouble(i * 8) - paramPtr4.getDouble(i * 8) * paramPtr3.getDouble((i + 1) * 8)) / paramPtr2.getDouble(i * 8)); 
        paramPtr2.setDouble(paramInt * 8, (paramPtr1.getDouble(paramInt * 8) - paramPtr1.getDouble((paramInt + -1) * 8)) / paramPtr4.getDouble((paramInt + -1) * 8) + paramPtr4.getDouble((paramInt + -1) * 8) * (paramPtr3.getDouble((paramInt + -1) * 8) + paramPtr3.getDouble(paramInt * 8) * 2.0D));
        for (i = 1; i <= j; i++) {
          paramPtr2.setDouble(i * 8, (paramPtr1.getDouble((i + 1) * 8) - paramPtr1.getDouble(i * 8)) / paramPtr4.getDouble(i * 8) - paramPtr4.getDouble(i * 8) * (paramPtr3.getDouble((i + 1) * 8) + paramPtr3.getDouble(i * 8) * 2.0D));
          paramPtr4.setDouble(i * 8, (paramPtr3.getDouble((i + 1) * 8) - paramPtr3.getDouble(i * 8)) / paramPtr4.getDouble(i * 8));
          paramPtr3.setDouble(i * 8, paramPtr3.getDouble(i * 8) * 3.0D);
        } 
        paramPtr3.setDouble(paramInt * 8, paramPtr3.getDouble(paramInt * 8) * 3.0D);
        paramPtr4.setDouble(paramInt * 8, paramPtr4.getDouble(j * 8));
        return;
      } 
      paramPtr2.setDouble(8, (paramPtr1.getDouble(16) - paramPtr1.getDouble(8)) / (i.getDouble(16) - i.getDouble(8)));
      paramPtr2.setDouble(16, paramPtr2.getAlignedDouble(1));
      paramPtr4.setDouble(16, 0.0D);
      paramPtr4.setDouble(8, paramPtr4.getDouble(16));
      paramPtr3.setDouble(16, paramPtr4.getDouble(8));
      paramPtr3.setDouble(8, paramPtr3.getDouble(16));
      return;
    } 
    Builtins.__errno_location().setInt(0, 33);
  }
  
  public static SEXP getListElement(SEXP paramSEXP, Ptr paramPtr) {
    SEXP sEXP1 = (SEXP)BytePtr.of(0).getArray();
    sEXP1 = (SEXP)BytePtr.of(0).getArray();
    sEXP1 = Rinternals.R_NilValue;
    SEXP sEXP2 = Rinternals.Rf_getAttrib(paramSEXP, Rinternals.R_NamesSymbol);
    byte b = 0;
    while (Rinternals.Rf_length(paramSEXP) > b) {
      if (Stdlib.strcmp((Ptr)Rinternals.R_CHAR(Rinternals.STRING_ELT(sEXP2, b)), paramPtr) != 0) {
        b++;
        continue;
      } 
      sEXP1 = Rinternals.VECTOR_ELT(paramSEXP, b);
      break;
    } 
    return sEXP1;
  }
  
  public static void natural_spline(int paramInt, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5) {
    Ptr ptr = paramPtr1.pointerPlus(-8);
    paramPtr1 = paramPtr2.pointerPlus(-8);
    paramPtr2 = paramPtr3.pointerPlus(-8);
    paramPtr3 = paramPtr4.pointerPlus(-8);
    paramPtr4 = paramPtr5.pointerPlus(-8);
    if (paramInt > 1) {
      int i;
      if (paramInt > 2) {
        int j = paramInt + -1;
        paramPtr4.setDouble(8, ptr.getDouble(16) - ptr.getDouble(8));
        paramPtr3.setDouble(16, (paramPtr1.getDouble(16) - paramPtr1.getDouble(8)) / paramPtr4.getDouble(8));
        int k;
        for (k = 2; k < paramInt; k++) {
          paramPtr4.setDouble(k * 8, ptr.getDouble((k + 1) * 8) - ptr.getDouble(k * 8));
          paramPtr2.setDouble(k * 8, (paramPtr4.getDouble((k + -1) * 8) + paramPtr4.getDouble(k * 8)) * 2.0D);
          paramPtr3.setDouble((k + 1) * 8, (paramPtr1.getDouble((k + 1) * 8) - paramPtr1.getDouble(k * 8)) / paramPtr4.getDouble(k * 8));
          paramPtr3.setDouble(k * 8, paramPtr3.getDouble((k + 1) * 8) - paramPtr3.getDouble(k * 8));
        } 
        for (i = 3; i < paramInt; i++) {
          double d = paramPtr4.getDouble((i + -1) * 8) / paramPtr2.getDouble((i + -1) * 8);
          paramPtr2.setDouble(i * 8, paramPtr2.getDouble(i * 8) - paramPtr4.getDouble((i + -1) * 8) * d);
          paramPtr3.setDouble(i * 8, paramPtr3.getDouble(i * 8) - paramPtr3.getDouble((i + -1) * 8) * d);
        } 
        paramPtr3.setDouble(j * 8, paramPtr3.getDouble(j * 8) / paramPtr2.getDouble(j * 8));
        for (k = paramInt + -2; k > 1; k--)
          paramPtr3.setDouble(k * 8, (paramPtr3.getDouble(k * 8) - paramPtr4.getDouble(k * 8) * paramPtr3.getDouble((k + 1) * 8)) / paramPtr2.getDouble(k * 8)); 
        i = paramInt * 8;
        paramPtr3.setDouble(i, 0.0D);
        paramPtr3.setDouble(8, paramPtr3.getDouble(i));
        paramPtr2.setDouble(8, (paramPtr1.getDouble(16) - paramPtr1.getDouble(8)) / paramPtr4.getDouble(8) - paramPtr4.getDouble(k * 8) * paramPtr3.getDouble(16));
        paramPtr3.setDouble(8, 0.0D);
        paramPtr4.setDouble(8, paramPtr3.getDouble(16) / paramPtr4.getDouble(8));
        paramPtr2.setDouble(paramInt * 8, (paramPtr1.getDouble(paramInt * 8) - paramPtr1.getDouble(j * 8)) / paramPtr4.getDouble(j * 8) + paramPtr4.getDouble(j * 8) * paramPtr3.getDouble(j * 8));
        for (j = 2; j < paramInt; j++) {
          paramPtr2.setDouble(j * 8, (paramPtr1.getDouble((j + 1) * 8) - paramPtr1.getDouble(j * 8)) / paramPtr4.getDouble(j * 8) - paramPtr4.getDouble(j * 8) * (paramPtr3.getDouble((j + 1) * 8) + paramPtr3.getDouble(j * 8) * 2.0D));
          paramPtr4.setDouble(j * 8, (paramPtr3.getDouble((j + 1) * 8) - paramPtr3.getDouble(j * 8)) / paramPtr4.getDouble(j * 8));
          paramPtr3.setDouble(j * 8, paramPtr3.getDouble(j * 8) * 3.0D);
        } 
        paramPtr3.setDouble(paramInt * 8, 0.0D);
        paramPtr4.setDouble(paramInt * 8, 0.0D);
        return;
      } 
      paramPtr2.setDouble(8, (paramPtr1.getDouble(16) - paramPtr1.getDouble(8)) / (i.getDouble(16) - i.getDouble(8)));
      paramPtr2.setDouble(16, paramPtr2.getAlignedDouble(1));
      paramPtr4.setDouble(16, 0.0D);
      paramPtr4.setDouble(8, paramPtr4.getDouble(16));
      paramPtr3.setDouble(16, paramPtr4.getDouble(8));
      paramPtr3.setDouble(8, paramPtr3.getDouble(16));
      return;
    } 
    Builtins.__errno_location().setInt(0, 33);
  }
  
  public static void periodic_spline(int paramInt, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5) {
    BytePtr.of(0);
    DoublePtr doublePtr = DoublePtr.malloc(paramInt * 8);
    paramPtr1 = paramPtr1.pointerPlus(-8);
    paramPtr2 = paramPtr2.pointerPlus(-8);
    paramPtr3 = paramPtr3.pointerPlus(-8);
    paramPtr4 = paramPtr4.pointerPlus(-8);
    paramPtr5 = paramPtr5.pointerPlus(-8);
    if (paramInt > 1 && paramPtr2.getDouble(8) == paramPtr2.getDouble(paramInt * 8)) {
      if (paramInt != 2) {
        if (paramInt != 3) {
          int i = paramInt + -1;
          paramPtr5.setDouble(8, paramPtr1.getDouble(16) - paramPtr1.getDouble(8));
          paramPtr5.setDouble(i * 8, paramPtr1.getDouble(paramInt * 8) - paramPtr1.getDouble(i * 8));
          paramPtr3.setDouble(8, (paramPtr5.getDouble(8) + paramPtr5.getDouble(i * 8)) * 2.0D);
          paramPtr4.setDouble(8, (paramPtr2.getDouble(16) - paramPtr2.getDouble(8)) / paramPtr5.getDouble(8) - (paramPtr2.getDouble(paramInt * 8) - paramPtr2.getDouble(i * 8)) / paramPtr5.getDouble(i * 8));
          int j;
          for (j = 2; j < paramInt; j++) {
            paramPtr5.setDouble(j * 8, paramPtr1.getDouble((j + 1) * 8) - paramPtr1.getDouble(j * 8));
            paramPtr3.setDouble(j * 8, (paramPtr5.getDouble(j * 8) + paramPtr5.getDouble((j + -1) * 8)) * 2.0D);
            paramPtr4.setDouble(j * 8, (paramPtr2.getDouble((j + 1) * 8) - paramPtr2.getDouble(j * 8)) / paramPtr5.getDouble(j * 8) - (paramPtr2.getDouble(j * 8) - paramPtr2.getDouble((j + -1) * 8)) / paramPtr5.getDouble((j + -1) * 8));
          } 
          paramPtr3.setDouble(8, Mathlib.sqrt(paramPtr3.getDouble(8)));
          doublePtr.setDouble(0, (paramPtr1.getDouble(paramInt * 8) - paramPtr1.getDouble(i * 8)) / paramPtr3.getDouble(8));
          double d = 0.0D;
          for (j = 1; i + -2 >= j; j++) {
            paramPtr5.setDouble(j * 8, paramPtr5.getDouble(j * 8) / paramPtr3.getDouble(j * 8));
            if (j != 1)
              doublePtr.setDouble(-8 + j * 8, -doublePtr.getDouble(-8 + (j + -1) * 8) * paramPtr5.getDouble((j + -1) * 8) / paramPtr3.getDouble(j * 8)); 
            paramPtr3.setDouble((j + 1) * 8, Mathlib.sqrt(paramPtr3.getDouble((j + 1) * 8) - paramPtr5.getDouble(j * 8) * paramPtr5.getDouble(j * 8)));
            d = doublePtr.getDouble(-8 + j * 8) * doublePtr.getDouble(-8 + j * 8) + d;
          } 
          paramPtr5.setDouble((i + -1) * 8, (paramPtr5.getDouble((i + -1) * 8) - doublePtr.getDouble(-8 + (i + -2) * 8) * paramPtr5.getDouble((i + -2) * 8)) / paramPtr3.getDouble((i + -1) * 8));
          paramPtr3.setDouble(i * 8, Mathlib.sqrt(paramPtr3.getDouble(i * 8) - paramPtr5.getDouble((i + -1) * 8) * paramPtr5.getDouble((i + -1) * 8) - d));
          paramPtr4.setDouble(8, paramPtr4.getDouble(8) / paramPtr3.getDouble(8));
          d = 0.0D;
          for (j = 2; i + -1 >= j; j++) {
            paramPtr4.setDouble(j * 8, (paramPtr4.getDouble(j * 8) - paramPtr5.getDouble((j + -1) * 8) * paramPtr4.getDouble((j + -1) * 8)) / paramPtr3.getDouble(j * 8));
            d = doublePtr.getDouble(-8 + (j + -1) * 8) * paramPtr4.getDouble((j + -1) * 8) + d;
          } 
          paramPtr4.setDouble(i * 8, (paramPtr4.getDouble(i * 8) - paramPtr5.getDouble((i + -1) * 8) * paramPtr4.getDouble((i + -1) * 8) - d) / paramPtr3.getDouble(i * 8));
          paramPtr4.setDouble(i * 8, paramPtr4.getDouble(i * 8) / paramPtr3.getDouble(i * 8));
          paramPtr4.setDouble((i + -1) * 8, (paramPtr4.getDouble((i + -1) * 8) - paramPtr5.getDouble((i + -1) * 8) * paramPtr4.getDouble(i * 8)) / paramPtr3.getDouble((i + -1) * 8));
          for (j = i + -2; j > 0; j--)
            paramPtr4.setDouble(j * 8, (paramPtr4.getDouble(j * 8) - paramPtr5.getDouble(j * 8) * paramPtr4.getDouble((j + 1) * 8) - doublePtr.getDouble(-8 + j * 8) * paramPtr4.getDouble(i * 8)) / paramPtr3.getDouble(j * 8)); 
          paramPtr4.setDouble(paramInt * 8, paramPtr4.getAlignedDouble(1));
          for (byte b = 1; b <= i; b++) {
            d = paramPtr1.getDouble((b + 1) * 8) - paramPtr1.getDouble(b * 8);
            paramPtr3.setDouble(b * 8, (paramPtr2.getDouble((b + 1) * 8) - paramPtr2.getDouble(b * 8)) / d - (paramPtr4.getDouble((b + 1) * 8) + paramPtr4.getDouble(b * 8) * 2.0D) * d);
            paramPtr5.setDouble(b * 8, (paramPtr4.getDouble((b + 1) * 8) - paramPtr4.getDouble(b * 8)) / d);
            paramPtr4.setDouble(b * 8, paramPtr4.getDouble(b * 8) * 3.0D);
          } 
          paramPtr3.setDouble(paramInt * 8, paramPtr3.getAlignedDouble(1));
          paramPtr4.setDouble(paramInt * 8, paramPtr4.getAlignedDouble(1));
          paramPtr5.setDouble(paramInt * 8, paramPtr5.getAlignedDouble(1));
          return;
        } 
        paramPtr3.setDouble(24, -(paramPtr2.getDouble(8) - paramPtr2.getDouble(16)) * (paramPtr1.getDouble(8) - paramPtr1.getDouble(16) * 2.0D + paramPtr1.getDouble(24)) / (paramPtr1.getDouble(24) - paramPtr1.getDouble(16)) / (paramPtr1.getDouble(16) - paramPtr1.getDouble(8)));
        paramPtr3.setDouble(16, paramPtr3.getDouble(24));
        paramPtr3.setDouble(8, paramPtr3.getDouble(16));
        paramPtr4.setDouble(8, (paramPtr2.getDouble(8) - paramPtr2.getDouble(16)) * -3.0D / (paramPtr1.getDouble(24) - paramPtr1.getDouble(16)) / (paramPtr1.getDouble(16) - paramPtr1.getDouble(8)));
        paramPtr4.setDouble(16, -paramPtr4.getDouble(8));
        paramPtr4.setDouble(24, paramPtr4.getAlignedDouble(1));
        paramPtr5.setDouble(8, paramPtr4.getDouble(8) * -2.0D / 3.0D / (paramPtr1.getDouble(16) - paramPtr1.getDouble(8)));
        paramPtr5.setDouble(16, -paramPtr5.getDouble(8) * (paramPtr1.getDouble(16) - paramPtr1.getDouble(8)) / (paramPtr1.getDouble(24) - paramPtr1.getDouble(16)));
        paramPtr5.setDouble(24, paramPtr5.getAlignedDouble(1));
        return;
      } 
      paramPtr5.setDouble(16, 0.0D);
      paramPtr5.setDouble(8, paramPtr5.getDouble(16));
      paramPtr4.setDouble(16, paramPtr5.getDouble(8));
      paramPtr4.setDouble(8, paramPtr4.getDouble(16));
      paramPtr3.setDouble(16, paramPtr4.getDouble(8));
      paramPtr3.setDouble(8, paramPtr3.getDouble(16));
      return;
    } 
    Builtins.__errno_location().setInt(0, 33);
  }
  
  public static void spline_coef(int paramInt1, int paramInt2, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5) {
    switch (paramInt1) {
      case 1:
        periodic_spline(paramInt2, paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5);
        break;
      case 2:
        natural_spline(paramInt2, paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5);
        break;
      case 3:
        fmm_spline(paramInt2, paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5);
        break;
    } 
  }
  
  public static void spline_eval(int paramInt1, int paramInt2, Ptr paramPtr1, Ptr paramPtr2, int paramInt3, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7) {
    // Byte code:
    //   0: iload #4
    //   2: iconst_m1
    //   3: iadd
    //   4: istore #11
    //   6: iload_0
    //   7: iconst_1
    //   8: if_icmpeq -> 14
    //   11: goto -> 172
    //   14: iload #4
    //   16: iconst_1
    //   17: if_icmpgt -> 23
    //   20: goto -> 172
    //   23: aload #5
    //   25: iload #11
    //   27: bipush #8
    //   29: imul
    //   30: invokeinterface getDouble : (I)D
    //   35: aload #5
    //   37: invokeinterface getDouble : ()D
    //   42: dsub
    //   43: dstore #12
    //   45: iconst_0
    //   46: istore #14
    //   48: goto -> 163
    //   51: aload_3
    //   52: iload #14
    //   54: bipush #8
    //   56: imul
    //   57: aload_2
    //   58: iload #14
    //   60: bipush #8
    //   62: imul
    //   63: invokeinterface getDouble : (I)D
    //   68: aload #5
    //   70: invokeinterface getDouble : ()D
    //   75: dsub
    //   76: dload #12
    //   78: invokestatic fmod : (DD)D
    //   81: invokeinterface setDouble : (ID)V
    //   86: aload_3
    //   87: iload #14
    //   89: bipush #8
    //   91: imul
    //   92: invokeinterface getDouble : (I)D
    //   97: dconst_0
    //   98: dcmpg
    //   99: iflt -> 105
    //   102: goto -> 130
    //   105: aload_3
    //   106: iload #14
    //   108: bipush #8
    //   110: imul
    //   111: aload_3
    //   112: iload #14
    //   114: bipush #8
    //   116: imul
    //   117: invokeinterface getDouble : (I)D
    //   122: dload #12
    //   124: dadd
    //   125: invokeinterface setDouble : (ID)V
    //   130: aload_3
    //   131: iload #14
    //   133: bipush #8
    //   135: imul
    //   136: aload_3
    //   137: iload #14
    //   139: bipush #8
    //   141: imul
    //   142: invokeinterface getDouble : (I)D
    //   147: aload #5
    //   149: invokeinterface getDouble : ()D
    //   154: dadd
    //   155: invokeinterface setDouble : (ID)V
    //   160: iinc #14, 1
    //   163: iload #14
    //   165: iload_1
    //   166: if_icmplt -> 51
    //   169: goto -> 209
    //   172: iconst_0
    //   173: istore #14
    //   175: goto -> 203
    //   178: aload_3
    //   179: iload #14
    //   181: bipush #8
    //   183: imul
    //   184: aload_2
    //   185: iload #14
    //   187: bipush #8
    //   189: imul
    //   190: invokeinterface getDouble : (I)D
    //   195: invokeinterface setDouble : (ID)V
    //   200: iinc #14, 1
    //   203: iload #14
    //   205: iload_1
    //   206: if_icmplt -> 178
    //   209: iconst_0
    //   210: istore_2
    //   211: iconst_0
    //   212: istore #14
    //   214: goto -> 474
    //   217: aload_3
    //   218: iload_2
    //   219: bipush #8
    //   221: imul
    //   222: invokeinterface getDouble : (I)D
    //   227: dstore #15
    //   229: aload #5
    //   231: iload #14
    //   233: bipush #8
    //   235: imul
    //   236: invokeinterface getDouble : (I)D
    //   241: dload #15
    //   243: dcmpl
    //   244: ifgt -> 280
    //   247: iload #14
    //   249: iload #11
    //   251: if_icmplt -> 257
    //   254: goto -> 337
    //   257: aload #5
    //   259: iload #14
    //   261: iconst_1
    //   262: iadd
    //   263: bipush #8
    //   265: imul
    //   266: invokeinterface getDouble : (I)D
    //   271: dload #15
    //   273: dcmpg
    //   274: iflt -> 280
    //   277: goto -> 337
    //   280: iconst_0
    //   281: istore #14
    //   283: iload #4
    //   285: istore #17
    //   287: iload #14
    //   289: iload #17
    //   291: iadd
    //   292: iconst_2
    //   293: idiv
    //   294: istore #10
    //   296: aload #5
    //   298: iload #10
    //   300: bipush #8
    //   302: imul
    //   303: invokeinterface getDouble : (I)D
    //   308: dload #15
    //   310: dcmpl
    //   311: ifgt -> 317
    //   314: goto -> 324
    //   317: iload #10
    //   319: istore #17
    //   321: goto -> 328
    //   324: iload #10
    //   326: istore #14
    //   328: iload #14
    //   330: iconst_1
    //   331: iadd
    //   332: iload #17
    //   334: if_icmplt -> 287
    //   337: dload #15
    //   339: aload #5
    //   341: iload #14
    //   343: bipush #8
    //   345: imul
    //   346: invokeinterface getDouble : (I)D
    //   351: dsub
    //   352: dstore #12
    //   354: iload_0
    //   355: iconst_2
    //   356: if_icmpne -> 391
    //   359: aload #5
    //   361: invokeinterface getDouble : ()D
    //   366: dload #15
    //   368: dcmpl
    //   369: ifgt -> 378
    //   372: iconst_0
    //   373: istore #10
    //   375: goto -> 381
    //   378: iconst_1
    //   379: istore #10
    //   381: iload #10
    //   383: iconst_1
    //   384: ixor
    //   385: ifne -> 391
    //   388: goto -> 408
    //   391: aload #9
    //   393: iload #14
    //   395: bipush #8
    //   397: imul
    //   398: invokeinterface getDouble : (I)D
    //   403: dstore #15
    //   405: goto -> 411
    //   408: dconst_0
    //   409: dstore #15
    //   411: aload_3
    //   412: iload_2
    //   413: bipush #8
    //   415: imul
    //   416: aload #6
    //   418: iload #14
    //   420: bipush #8
    //   422: imul
    //   423: invokeinterface getDouble : (I)D
    //   428: aload #7
    //   430: iload #14
    //   432: bipush #8
    //   434: imul
    //   435: invokeinterface getDouble : (I)D
    //   440: aload #8
    //   442: iload #14
    //   444: bipush #8
    //   446: imul
    //   447: invokeinterface getDouble : (I)D
    //   452: dload #12
    //   454: dload #15
    //   456: dmul
    //   457: dadd
    //   458: dload #12
    //   460: dmul
    //   461: dadd
    //   462: dload #12
    //   464: dmul
    //   465: dadd
    //   466: invokeinterface setDouble : (ID)V
    //   471: iinc #2, 1
    //   474: iload_2
    //   475: iload_1
    //   476: if_icmplt -> 217
    //   479: return
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/stats-0.9.2724.jar!/org/renjin/stats/splines__.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */