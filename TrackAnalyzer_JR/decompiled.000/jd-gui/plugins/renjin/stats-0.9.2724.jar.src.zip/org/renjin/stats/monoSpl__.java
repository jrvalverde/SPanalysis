package org.renjin.stats;

import org.renjin.gcc.runtime.BytePtr;
import org.renjin.gcc.runtime.Mathlib;
import org.renjin.gcc.runtime.Ptr;
import org.renjin.gnur.api.Error;
import org.renjin.gnur.api.GetText;
import org.renjin.gnur.api.Rinternals;
import org.renjin.gnur.api.Rinternals2;
import org.renjin.sexp.SEXP;

public class monoSpl__ {
  static {
  
  }
  
  public static SEXP monoFC_m(SEXP paramSEXP1, SEXP paramSEXP2) {
    int i = Rinternals.LENGTH(paramSEXP1);
    if (!Rinternals.Rf_isInteger(paramSEXP1)) {
      if (!Rinternals.Rf_isReal(paramSEXP1))
        Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("Argument m must be numeric\000".getBytes(), 0)), new Object[0]); 
      paramSEXP1 = Rinternals.Rf_protect(Rinternals.Rf_duplicate(paramSEXP1));
    } else {
      paramSEXP1 = Rinternals.Rf_protect(Rinternals.Rf_coerceVector(paramSEXP1, 14));
    } 
    if (i <= 1)
      Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("length(m) must be at least two\000".getBytes(), 0)), new Object[0]); 
    if (!Rinternals.Rf_isReal(paramSEXP2) || Rinternals.LENGTH(paramSEXP2) != i + -1)
      Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("Argument Sx must be numeric vector one shorter than m[]\000".getBytes(), 0)), new Object[0]); 
    Ptr ptr = Rinternals2.REAL(paramSEXP2);
    monoFC_mod(Rinternals2.REAL(paramSEXP1), ptr, i);
    return paramSEXP1;
  }
  
  public static void monoFC_mod(Ptr paramPtr1, Ptr paramPtr2, int paramInt) {
    if (paramInt <= 1)
      Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("n must be at least two\000".getBytes(), 0)), new Object[0]); 
    for (byte b = 0; paramInt + -1 > b; b++) {
      double d = paramPtr2.getDouble(b * 8);
      int i = b + 1;
      if (d != 0.0D) {
        double d3 = paramPtr1.getDouble(b * 8) / d;
        double d2 = paramPtr1.getDouble(i * 8) / d;
        double d1 = d3 * 2.0D + d2 - 3.0D;
        if (d1 > 0.0D) {
          double d4 = d2 * 2.0D + d3 - 3.0D;
          if (d4 > 0.0D && (d1 + d4) * d3 < d1 * d1) {
            d4 = d * 3.0D / Mathlib.sqrt(d3 * d3 + d2 * d2) * d3;
            paramPtr1.setDouble(b * 8, d4);
            paramPtr1.setDouble(i * 8, d * 3.0D / Mathlib.sqrt(d3 * d3 + d2 * d2) * d2);
          } 
        } 
      } else {
        i *= 8;
        paramPtr1.setDouble(i, 0.0D);
        paramPtr1.setDouble(b * 8, paramPtr1.getDouble(i));
      } 
    } 
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/stats-0.9.2724.jar!/org/renjin/stats/monoSpl__.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */