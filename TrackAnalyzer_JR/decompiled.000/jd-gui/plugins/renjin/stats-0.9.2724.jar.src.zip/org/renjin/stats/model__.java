package org.renjin.stats;

import org.renjin.gcc.runtime.BytePtr;
import org.renjin.gcc.runtime.IntPtr;
import org.renjin.gcc.runtime.Ptr;
import org.renjin.gcc.runtime.Stdlib;
import org.renjin.gcc.runtime.UnsatisfiedLinkException;
import org.renjin.gcc.runtime.VoidPtr;
import org.renjin.gnur.api.Arith;
import org.renjin.gnur.api.Defn;
import org.renjin.gnur.api.Error;
import org.renjin.gnur.api.GetText;
import org.renjin.gnur.api.Memory;
import org.renjin.gnur.api.Rinternals;
import org.renjin.gnur.api.Rinternals2;
import org.renjin.sexp.SEXP;

public class model__ {
  public static int haveDot = 0;
  
  public static SEXP framenames = (SEXP)BytePtr.of(0).getArray();
  
  public static int vpi = 0;
  
  public static SEXP varlist = (SEXP)BytePtr.of(0).getArray();
  
  public static int nterm = 0;
  
  public static int nwords = 0;
  
  public static int nvar = 0;
  
  public static int response = 0;
  
  public static int parity = 0;
  
  public static int intercept = 0;
  
  public static SEXP inSymbol = (SEXP)BytePtr.of(0).getArray();
  
  public static SEXP parenSymbol = (SEXP)BytePtr.of(0).getArray();
  
  public static SEXP dotSymbol = (SEXP)BytePtr.of(0).getArray();
  
  public static SEXP powerSymbol = (SEXP)BytePtr.of(0).getArray();
  
  public static SEXP colonSymbol = (SEXP)BytePtr.of(0).getArray();
  
  public static SEXP slashSymbol = (SEXP)BytePtr.of(0).getArray();
  
  public static SEXP timesSymbol = (SEXP)BytePtr.of(0).getArray();
  
  public static SEXP minusSymbol = (SEXP)BytePtr.of(0).getArray();
  
  public static SEXP plusSymbol = (SEXP)BytePtr.of(0).getArray();
  
  public static SEXP tildeSymbol = (SEXP)BytePtr.of(0).getArray();
  
  public static SEXP AllocTerm() {
    SEXP sEXP = (SEXP)BytePtr.of(0).getArray();
    sEXP = Rinternals.Rf_allocVector(13, nwords);
    for (byte b = 0; b < nwords; b++)
      Rinternals2.INTEGER(sEXP).setInt(0 + b * 4, 0); 
    return sEXP;
  }
  
  public static Ptr AppendInteger(Ptr paramPtr, int paramInt) {
    Stdlib.sprintf((BytePtr)paramPtr, new BytePtr("%d\000".getBytes(), 0), new Object[] { Integer.valueOf(paramInt) });
    while (paramPtr.getByte() != (byte)0)
      paramPtr = paramPtr.pointerPlus(1); 
    return paramPtr;
  }
  
  public static Ptr AppendString(Ptr paramPtr1, Ptr paramPtr2) {
    while (paramPtr2.getByte() != (byte)0) {
      paramPtr1.setByte(paramPtr2.getByte());
      paramPtr1 = paramPtr1.pointerPlus(1);
      paramPtr2 = paramPtr2.pointerPlus(1);
    } 
    paramPtr1.setByte((byte)0);
    return paramPtr1;
  }
  
  public static int BitCount(SEXP paramSEXP) {
    int i = 0;
    for (byte b = 1; b <= nvar; b++)
      i = GetBit(paramSEXP, b) + i; 
    return i;
  }
  
  public static void CheckRHS(SEXP paramSEXP) {
    SEXP sEXP = (SEXP)BytePtr.of(0).getArray();
    while ((Rinternals.Rf_isList(paramSEXP) || Rinternals.Rf_isLanguage(paramSEXP)) && paramSEXP != Rinternals.R_NilValue) {
      CheckRHS(Rinternals.CAR(paramSEXP));
      paramSEXP = Rinternals.CDR(paramSEXP);
    } 
    if (Rinternals.TYPEOF(paramSEXP) == 1)
      for (byte b = 0; Rinternals.Rf_length(framenames) > b; b++) {
        if (paramSEXP == Defn.Rf_installTrChar(Rinternals.STRING_ELT(framenames, b))) {
          SEXP sEXP1 = Rinternals.Rf_allocVector(16, Rinternals.Rf_length(framenames) + -1);
          int i;
          for (i = 0; Rinternals.Rf_length(sEXP1) > i; i++) {
            if (i >= b) {
              Rinternals.SET_STRING_ELT(sEXP1, i, Rinternals.STRING_ELT(framenames, i + 1));
            } else {
              Rinternals.SET_STRING_ELT(sEXP1, i, Rinternals.STRING_ELT(framenames, i));
            } 
          } 
          i = vpi;
          framenames = sEXP1;
          sEXP1 = framenames;
        } 
      }  
  }
  
  public static SEXP ColumnNames(SEXP paramSEXP) {
    paramSEXP = Rinternals.Rf_getAttrib(paramSEXP, Rinternals.R_DimNamesSymbol);
    return (paramSEXP != Rinternals.R_NilValue && Rinternals.Rf_length(paramSEXP) > 1) ? Rinternals.VECTOR_ELT(paramSEXP, 1) : Rinternals.R_NilValue;
  }
  
  public static SEXP CrossTerms(SEXP paramSEXP1, SEXP paramSEXP2) {
    SEXP sEXP1 = (SEXP)BytePtr.of(0).getArray();
    sEXP1 = (SEXP)BytePtr.of(0).getArray();
    sEXP1 = (SEXP)BytePtr.of(0).getArray();
    paramSEXP1 = EncodeVars(paramSEXP1);
    Rinternals.Rf_protect(paramSEXP1);
    sEXP1 = EncodeVars(paramSEXP2);
    Rinternals.Rf_protect(sEXP1);
    SEXP sEXP2 = Rinternals.Rf_allocList(Rinternals.Rf_length(paramSEXP1) * Rinternals.Rf_length(sEXP1));
    Rinternals.Rf_protect(sEXP2);
    SEXP sEXP3 = sEXP2;
    for (SEXP sEXP4 = paramSEXP1; sEXP4 != Rinternals.R_NilValue; sEXP4 = Rinternals.CDR(sEXP4)) {
      for (SEXP sEXP = sEXP1; sEXP != Rinternals.R_NilValue; sEXP = Rinternals.CDR(sEXP)) {
        paramSEXP2 = Rinternals.CAR(sEXP);
        Rinternals.SETCAR(sEXP3, OrBits(Rinternals.CAR(sEXP4), paramSEXP2));
        sEXP3 = Rinternals.CDR(sEXP3);
      } 
    } 
    Rinternals.Rf_listAppend(sEXP1, sEXP2);
    Rinternals.Rf_listAppend(paramSEXP1, sEXP1);
    return TrimRepeats(paramSEXP1);
  }
  
  public static SEXP DeleteTerms(SEXP paramSEXP1, SEXP paramSEXP2) {
    paramSEXP1 = EncodeVars(paramSEXP1);
    Rinternals.Rf_protect(paramSEXP1);
    parity = 1 - parity;
    Rinternals.Rf_protect(EncodeVars(paramSEXP2));
    parity = 1 - parity;
    for (paramSEXP2 = EncodeVars(paramSEXP2); paramSEXP2 != Rinternals.R_NilValue; paramSEXP2 = Rinternals.CDR(paramSEXP2))
      paramSEXP1 = StripTerm(Rinternals.CAR(paramSEXP2), paramSEXP1); 
    return paramSEXP1;
  }
  
  public static SEXP EncodeVars(SEXP paramSEXP) {
    BytePtr.of(0);
    BytePtr.of(0);
    null = (SEXP)BytePtr.of(0).getArray();
    null = (SEXP)BytePtr.of(0).getArray();
    null = (SEXP)BytePtr.of(0).getArray();
    if (Rinternals.TYPEOF(paramSEXP) != 0) {
      if (isOne(paramSEXP) == 0) {
        if (isZero(paramSEXP) == 0) {
          SEXP sEXP;
          if (Rinternals.TYPEOF(paramSEXP) != 1) {
            if (!Rinternals.Rf_isLanguage(paramSEXP)) {
              Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("invalid model formula in EncodeVars\000".getBytes(), 0)), new Object[0]);
              return null;
            } 
            int i = Rinternals.Rf_length(paramSEXP);
            if (Rinternals.CAR(paramSEXP) != tildeSymbol) {
              if (Rinternals.CAR(paramSEXP) != plusSymbol) {
                if (Rinternals.CAR(paramSEXP) != colonSymbol) {
                  if (Rinternals.CAR(paramSEXP) != timesSymbol) {
                    if (Rinternals.CAR(paramSEXP) != inSymbol) {
                      if (Rinternals.CAR(paramSEXP) != slashSymbol) {
                        if (Rinternals.CAR(paramSEXP) != powerSymbol) {
                          int j;
                          if (Rinternals.CAR(paramSEXP) != minusSymbol) {
                            if (Rinternals.CAR(paramSEXP) != parenSymbol) {
                              j = InstallVar(paramSEXP);
                              SetBit(AllocTerm(), j, 1);
                              return Rinternals.Rf_cons(AllocTerm(), Rinternals.R_NilValue);
                            } 
                            return EncodeVars(Rinternals.CADR(j));
                          } 
                          if (i != 2) {
                            null = Rinternals.CADDR(j);
                            return DeleteTerms(Rinternals.CADR(j), null);
                          } 
                          sEXP = Rinternals.CADR(j);
                          return DeleteTerms(Rinternals.R_NilValue, sEXP);
                        } 
                        null = Rinternals.CADDR(sEXP);
                        return PowerTerms(Rinternals.CADR(sEXP), null);
                      } 
                      null = Rinternals.CADDR(sEXP);
                      return NestTerms(Rinternals.CADR(sEXP), null);
                    } 
                    null = Rinternals.CADDR(sEXP);
                    return InTerms(Rinternals.CADR(sEXP), null);
                  } 
                  null = Rinternals.CADDR(sEXP);
                  return CrossTerms(Rinternals.CADR(sEXP), null);
                } 
                null = Rinternals.CADDR(sEXP);
                return InteractTerms(Rinternals.CADR(sEXP), null);
              } 
              if (i != 2) {
                null = Rinternals.CADDR(sEXP);
                return PlusTerms(Rinternals.CADR(sEXP), null);
              } 
              return EncodeVars(Rinternals.CADR(sEXP));
            } 
            return (Rinternals.TYPEOF(Rinternals.CDDR(sEXP)) != 0) ? EncodeVars(Rinternals.CADDR(sEXP)) : EncodeVars(Rinternals.CADR(sEXP));
          } 
          if (sEXP == dotSymbol && framenames != Rinternals.R_NilValue) {
            sEXP = Rinternals.R_NilValue;
            null = Rinternals.R_NilValue;
            VoidPtr.toPtr(Memory.vmaxget());
            if (Rinternals.LENGTH(framenames) != 0) {
              for (byte b = 0; Rinternals.LENGTH(framenames) > b; b++) {
                BytePtr bytePtr = Rinternals.Rf_translateChar(Rinternals.STRING_ELT(framenames, b));
                for (byte b1 = 0; b1 < b; b1++) {
                  BytePtr bytePtr1 = Rinternals.Rf_translateChar(Rinternals.STRING_ELT(framenames, b1));
                  if (Stdlib.strcmp(bytePtr.pointerPlus(0), (Ptr)bytePtr1) == 0)
                    Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("duplicated name '%s' in data frame using '.'\000".getBytes(), 0)), new Object[] { bytePtr.pointerPlus(0) }); 
                } 
                int i = InstallVar(Rinternals.Rf_install((BytePtr)bytePtr.pointerPlus(0)));
                SEXP sEXP1 = AllocTerm();
                SetBit(sEXP1, i, 1);
                if (b != 0) {
                  Rinternals.SETCDR(null, Rinternals.Rf_cons(sEXP1, Rinternals.R_NilValue));
                  null = Rinternals.CDR(null);
                } else {
                  sEXP = Rinternals.Rf_cons(sEXP1, Rinternals.R_NilValue);
                  null = sEXP;
                  Rinternals.Rf_protect(sEXP);
                } 
              } 
              return sEXP;
            } 
            null = sEXP;
          } else {
            int i = InstallVar(sEXP);
            SetBit(AllocTerm(), i, 1);
            null = Rinternals.Rf_cons(AllocTerm(), Rinternals.R_NilValue);
          } 
          return null;
        } 
        if (parity == 0) {
          intercept = 1;
        } else {
          intercept = 0;
        } 
        return Rinternals.R_NilValue;
      } 
      if (parity == 0) {
        intercept = 0;
      } else {
        intercept = 1;
      } 
      return Rinternals.R_NilValue;
    } 
    return Rinternals.R_NilValue;
  }
  
  public static SEXP ExpandDots(SEXP paramSEXP1, SEXP paramSEXP2) {
    // Byte code:
    //   0: iconst_0
    //   1: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   4: invokeinterface getArray : ()Ljava/lang/Object;
    //   9: checkcast org/renjin/sexp/SEXP
    //   12: astore_2
    //   13: aload_0
    //   14: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
    //   17: iconst_1
    //   18: if_icmpeq -> 24
    //   21: goto -> 44
    //   24: aload_0
    //   25: getstatic org/renjin/stats/model__.dotSymbol : Lorg/renjin/sexp/SEXP;
    //   28: if_acmpeq -> 34
    //   31: goto -> 39
    //   34: aload_1
    //   35: invokestatic Rf_duplicate : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   38: astore_0
    //   39: aload_0
    //   40: astore_2
    //   41: goto -> 1027
    //   44: aload_0
    //   45: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
    //   48: bipush #6
    //   50: if_icmpeq -> 56
    //   53: goto -> 981
    //   56: aload_1
    //   57: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
    //   60: bipush #6
    //   62: if_icmpeq -> 68
    //   65: goto -> 76
    //   68: aload_1
    //   69: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   72: astore_3
    //   73: goto -> 89
    //   76: iconst_0
    //   77: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   80: invokeinterface getArray : ()Ljava/lang/Object;
    //   85: checkcast org/renjin/sexp/SEXP
    //   88: astore_3
    //   89: aload_0
    //   90: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   93: pop
    //   94: aload_0
    //   95: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   98: getstatic org/renjin/stats/model__.plusSymbol : Lorg/renjin/sexp/SEXP;
    //   101: if_acmpeq -> 107
    //   104: goto -> 182
    //   107: aload_0
    //   108: invokestatic Rf_length : (Lorg/renjin/sexp/SEXP;)I
    //   111: iconst_2
    //   112: if_icmpeq -> 118
    //   115: goto -> 134
    //   118: aload_0
    //   119: aload_0
    //   120: invokestatic CADR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   123: aload_1
    //   124: invokestatic ExpandDots : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   127: invokestatic SETCADR : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   130: pop
    //   131: goto -> 976
    //   134: aload_0
    //   135: invokestatic Rf_length : (Lorg/renjin/sexp/SEXP;)I
    //   138: iconst_3
    //   139: if_icmpeq -> 145
    //   142: goto -> 986
    //   145: aload_0
    //   146: aload_0
    //   147: invokestatic CADR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   150: aload_1
    //   151: invokestatic ExpandDots : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   154: invokestatic SETCADR : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   157: pop
    //   158: aload_0
    //   159: aload_0
    //   160: invokestatic CADDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   163: aload_1
    //   164: invokestatic ExpandDots : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   167: astore_1
    //   168: getstatic org/renjin/stats/model__.parenSymbol : Lorg/renjin/sexp/SEXP;
    //   171: aload_1
    //   172: invokestatic Rf_lang2 : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   175: invokestatic SETCADDR : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   178: pop
    //   179: goto -> 976
    //   182: aload_0
    //   183: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   186: getstatic org/renjin/stats/model__.minusSymbol : Lorg/renjin/sexp/SEXP;
    //   189: if_acmpeq -> 195
    //   192: goto -> 424
    //   195: aload_0
    //   196: invokestatic Rf_length : (Lorg/renjin/sexp/SEXP;)I
    //   199: iconst_2
    //   200: if_icmpeq -> 206
    //   203: goto -> 276
    //   206: aload_0
    //   207: invokestatic CADR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   210: getstatic org/renjin/stats/model__.dotSymbol : Lorg/renjin/sexp/SEXP;
    //   213: if_acmpeq -> 219
    //   216: goto -> 260
    //   219: aload_3
    //   220: getstatic org/renjin/stats/model__.plusSymbol : Lorg/renjin/sexp/SEXP;
    //   223: if_acmpeq -> 236
    //   226: aload_3
    //   227: getstatic org/renjin/stats/model__.minusSymbol : Lorg/renjin/sexp/SEXP;
    //   230: if_acmpeq -> 236
    //   233: goto -> 260
    //   236: aload_0
    //   237: aload_0
    //   238: invokestatic CADR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   241: aload_1
    //   242: invokestatic ExpandDots : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   245: astore_1
    //   246: getstatic org/renjin/stats/model__.parenSymbol : Lorg/renjin/sexp/SEXP;
    //   249: aload_1
    //   250: invokestatic Rf_lang2 : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   253: invokestatic SETCADR : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   256: pop
    //   257: goto -> 976
    //   260: aload_0
    //   261: aload_0
    //   262: invokestatic CADR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   265: aload_1
    //   266: invokestatic ExpandDots : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   269: invokestatic SETCADR : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   272: pop
    //   273: goto -> 976
    //   276: aload_0
    //   277: invokestatic Rf_length : (Lorg/renjin/sexp/SEXP;)I
    //   280: iconst_3
    //   281: if_icmpeq -> 287
    //   284: goto -> 986
    //   287: aload_0
    //   288: invokestatic CADR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   291: getstatic org/renjin/stats/model__.dotSymbol : Lorg/renjin/sexp/SEXP;
    //   294: if_acmpeq -> 300
    //   297: goto -> 341
    //   300: aload_3
    //   301: getstatic org/renjin/stats/model__.plusSymbol : Lorg/renjin/sexp/SEXP;
    //   304: if_acmpeq -> 317
    //   307: aload_3
    //   308: getstatic org/renjin/stats/model__.minusSymbol : Lorg/renjin/sexp/SEXP;
    //   311: if_acmpeq -> 317
    //   314: goto -> 341
    //   317: aload_0
    //   318: aload_0
    //   319: invokestatic CADR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   322: aload_1
    //   323: invokestatic ExpandDots : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   326: astore_2
    //   327: getstatic org/renjin/stats/model__.parenSymbol : Lorg/renjin/sexp/SEXP;
    //   330: aload_2
    //   331: invokestatic Rf_lang2 : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   334: invokestatic SETCADR : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   337: pop
    //   338: goto -> 354
    //   341: aload_0
    //   342: aload_0
    //   343: invokestatic CADR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   346: aload_1
    //   347: invokestatic ExpandDots : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   350: invokestatic SETCADR : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   353: pop
    //   354: aload_0
    //   355: invokestatic CADDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   358: getstatic org/renjin/stats/model__.dotSymbol : Lorg/renjin/sexp/SEXP;
    //   361: if_acmpeq -> 367
    //   364: goto -> 408
    //   367: aload_3
    //   368: getstatic org/renjin/stats/model__.plusSymbol : Lorg/renjin/sexp/SEXP;
    //   371: if_acmpeq -> 384
    //   374: aload_3
    //   375: getstatic org/renjin/stats/model__.minusSymbol : Lorg/renjin/sexp/SEXP;
    //   378: if_acmpeq -> 384
    //   381: goto -> 408
    //   384: aload_0
    //   385: aload_0
    //   386: invokestatic CADDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   389: aload_1
    //   390: invokestatic ExpandDots : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   393: astore_1
    //   394: getstatic org/renjin/stats/model__.parenSymbol : Lorg/renjin/sexp/SEXP;
    //   397: aload_1
    //   398: invokestatic Rf_lang2 : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   401: invokestatic SETCADDR : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   404: pop
    //   405: goto -> 976
    //   408: aload_0
    //   409: aload_0
    //   410: invokestatic CADDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   413: aload_1
    //   414: invokestatic ExpandDots : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   417: invokestatic SETCADDR : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   420: pop
    //   421: goto -> 976
    //   424: aload_0
    //   425: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   428: getstatic org/renjin/stats/model__.timesSymbol : Lorg/renjin/sexp/SEXP;
    //   431: if_acmpeq -> 447
    //   434: aload_0
    //   435: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   438: getstatic org/renjin/stats/model__.slashSymbol : Lorg/renjin/sexp/SEXP;
    //   441: if_acmpeq -> 447
    //   444: goto -> 592
    //   447: aload_0
    //   448: invokestatic Rf_length : (Lorg/renjin/sexp/SEXP;)I
    //   451: iconst_3
    //   452: if_icmpne -> 986
    //   455: aload_0
    //   456: invokestatic CADR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   459: getstatic org/renjin/stats/model__.dotSymbol : Lorg/renjin/sexp/SEXP;
    //   462: if_acmpeq -> 468
    //   465: goto -> 509
    //   468: aload_3
    //   469: getstatic org/renjin/stats/model__.plusSymbol : Lorg/renjin/sexp/SEXP;
    //   472: if_acmpeq -> 485
    //   475: aload_3
    //   476: getstatic org/renjin/stats/model__.minusSymbol : Lorg/renjin/sexp/SEXP;
    //   479: if_acmpeq -> 485
    //   482: goto -> 509
    //   485: aload_0
    //   486: aload_0
    //   487: invokestatic CADR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   490: aload_1
    //   491: invokestatic ExpandDots : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   494: astore_2
    //   495: getstatic org/renjin/stats/model__.parenSymbol : Lorg/renjin/sexp/SEXP;
    //   498: aload_2
    //   499: invokestatic Rf_lang2 : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   502: invokestatic SETCADR : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   505: pop
    //   506: goto -> 522
    //   509: aload_0
    //   510: aload_0
    //   511: invokestatic CADR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   514: aload_1
    //   515: invokestatic ExpandDots : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   518: invokestatic SETCADR : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   521: pop
    //   522: aload_0
    //   523: invokestatic CADDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   526: getstatic org/renjin/stats/model__.dotSymbol : Lorg/renjin/sexp/SEXP;
    //   529: if_acmpeq -> 535
    //   532: goto -> 576
    //   535: aload_3
    //   536: getstatic org/renjin/stats/model__.plusSymbol : Lorg/renjin/sexp/SEXP;
    //   539: if_acmpeq -> 552
    //   542: aload_3
    //   543: getstatic org/renjin/stats/model__.minusSymbol : Lorg/renjin/sexp/SEXP;
    //   546: if_acmpeq -> 552
    //   549: goto -> 576
    //   552: aload_0
    //   553: aload_0
    //   554: invokestatic CADDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   557: aload_1
    //   558: invokestatic ExpandDots : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   561: astore_1
    //   562: getstatic org/renjin/stats/model__.parenSymbol : Lorg/renjin/sexp/SEXP;
    //   565: aload_1
    //   566: invokestatic Rf_lang2 : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   569: invokestatic SETCADDR : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   572: pop
    //   573: goto -> 976
    //   576: aload_0
    //   577: aload_0
    //   578: invokestatic CADDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   581: aload_1
    //   582: invokestatic ExpandDots : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   585: invokestatic SETCADDR : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   588: pop
    //   589: goto -> 976
    //   592: aload_0
    //   593: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   596: getstatic org/renjin/stats/model__.colonSymbol : Lorg/renjin/sexp/SEXP;
    //   599: if_acmpeq -> 605
    //   602: goto -> 764
    //   605: aload_0
    //   606: invokestatic Rf_length : (Lorg/renjin/sexp/SEXP;)I
    //   609: iconst_3
    //   610: if_icmpne -> 986
    //   613: aload_0
    //   614: invokestatic CADR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   617: getstatic org/renjin/stats/model__.dotSymbol : Lorg/renjin/sexp/SEXP;
    //   620: if_acmpeq -> 626
    //   623: goto -> 681
    //   626: aload_3
    //   627: getstatic org/renjin/stats/model__.plusSymbol : Lorg/renjin/sexp/SEXP;
    //   630: if_acmpeq -> 657
    //   633: aload_3
    //   634: getstatic org/renjin/stats/model__.minusSymbol : Lorg/renjin/sexp/SEXP;
    //   637: if_acmpeq -> 657
    //   640: aload_3
    //   641: getstatic org/renjin/stats/model__.timesSymbol : Lorg/renjin/sexp/SEXP;
    //   644: if_acmpeq -> 657
    //   647: aload_3
    //   648: getstatic org/renjin/stats/model__.slashSymbol : Lorg/renjin/sexp/SEXP;
    //   651: if_acmpeq -> 657
    //   654: goto -> 681
    //   657: aload_0
    //   658: aload_0
    //   659: invokestatic CADR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   662: aload_1
    //   663: invokestatic ExpandDots : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   666: astore_2
    //   667: getstatic org/renjin/stats/model__.parenSymbol : Lorg/renjin/sexp/SEXP;
    //   670: aload_2
    //   671: invokestatic Rf_lang2 : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   674: invokestatic SETCADR : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   677: pop
    //   678: goto -> 694
    //   681: aload_0
    //   682: aload_0
    //   683: invokestatic CADR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   686: aload_1
    //   687: invokestatic ExpandDots : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   690: invokestatic SETCADR : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   693: pop
    //   694: aload_0
    //   695: invokestatic CADDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   698: getstatic org/renjin/stats/model__.dotSymbol : Lorg/renjin/sexp/SEXP;
    //   701: if_acmpeq -> 707
    //   704: goto -> 748
    //   707: aload_3
    //   708: getstatic org/renjin/stats/model__.plusSymbol : Lorg/renjin/sexp/SEXP;
    //   711: if_acmpeq -> 724
    //   714: aload_3
    //   715: getstatic org/renjin/stats/model__.minusSymbol : Lorg/renjin/sexp/SEXP;
    //   718: if_acmpeq -> 724
    //   721: goto -> 748
    //   724: aload_0
    //   725: aload_0
    //   726: invokestatic CADDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   729: aload_1
    //   730: invokestatic ExpandDots : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   733: astore_1
    //   734: getstatic org/renjin/stats/model__.parenSymbol : Lorg/renjin/sexp/SEXP;
    //   737: aload_1
    //   738: invokestatic Rf_lang2 : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   741: invokestatic SETCADDR : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   744: pop
    //   745: goto -> 976
    //   748: aload_0
    //   749: aload_0
    //   750: invokestatic CADDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   753: aload_1
    //   754: invokestatic ExpandDots : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   757: invokestatic SETCADDR : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   760: pop
    //   761: goto -> 976
    //   764: aload_0
    //   765: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   768: getstatic org/renjin/stats/model__.powerSymbol : Lorg/renjin/sexp/SEXP;
    //   771: if_acmpeq -> 777
    //   774: goto -> 943
    //   777: aload_0
    //   778: invokestatic Rf_length : (Lorg/renjin/sexp/SEXP;)I
    //   781: iconst_3
    //   782: if_icmpne -> 986
    //   785: aload_0
    //   786: invokestatic CADR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   789: getstatic org/renjin/stats/model__.dotSymbol : Lorg/renjin/sexp/SEXP;
    //   792: if_acmpeq -> 798
    //   795: goto -> 860
    //   798: aload_3
    //   799: getstatic org/renjin/stats/model__.plusSymbol : Lorg/renjin/sexp/SEXP;
    //   802: if_acmpeq -> 836
    //   805: aload_3
    //   806: getstatic org/renjin/stats/model__.minusSymbol : Lorg/renjin/sexp/SEXP;
    //   809: if_acmpeq -> 836
    //   812: aload_3
    //   813: getstatic org/renjin/stats/model__.timesSymbol : Lorg/renjin/sexp/SEXP;
    //   816: if_acmpeq -> 836
    //   819: aload_3
    //   820: getstatic org/renjin/stats/model__.slashSymbol : Lorg/renjin/sexp/SEXP;
    //   823: if_acmpeq -> 836
    //   826: aload_3
    //   827: getstatic org/renjin/stats/model__.colonSymbol : Lorg/renjin/sexp/SEXP;
    //   830: if_acmpeq -> 836
    //   833: goto -> 860
    //   836: aload_0
    //   837: aload_0
    //   838: invokestatic CADR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   841: aload_1
    //   842: invokestatic ExpandDots : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   845: astore_2
    //   846: getstatic org/renjin/stats/model__.parenSymbol : Lorg/renjin/sexp/SEXP;
    //   849: aload_2
    //   850: invokestatic Rf_lang2 : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   853: invokestatic SETCADR : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   856: pop
    //   857: goto -> 873
    //   860: aload_0
    //   861: aload_0
    //   862: invokestatic CADR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   865: aload_1
    //   866: invokestatic ExpandDots : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   869: invokestatic SETCADR : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   872: pop
    //   873: aload_0
    //   874: invokestatic CADDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   877: getstatic org/renjin/stats/model__.dotSymbol : Lorg/renjin/sexp/SEXP;
    //   880: if_acmpeq -> 886
    //   883: goto -> 927
    //   886: aload_3
    //   887: getstatic org/renjin/stats/model__.plusSymbol : Lorg/renjin/sexp/SEXP;
    //   890: if_acmpeq -> 903
    //   893: aload_3
    //   894: getstatic org/renjin/stats/model__.minusSymbol : Lorg/renjin/sexp/SEXP;
    //   897: if_acmpeq -> 903
    //   900: goto -> 927
    //   903: aload_0
    //   904: aload_0
    //   905: invokestatic CADDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   908: aload_1
    //   909: invokestatic ExpandDots : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   912: astore_1
    //   913: getstatic org/renjin/stats/model__.parenSymbol : Lorg/renjin/sexp/SEXP;
    //   916: aload_1
    //   917: invokestatic Rf_lang2 : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   920: invokestatic SETCADDR : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   923: pop
    //   924: goto -> 976
    //   927: aload_0
    //   928: aload_0
    //   929: invokestatic CADDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   932: aload_1
    //   933: invokestatic ExpandDots : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   936: invokestatic SETCADDR : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   939: pop
    //   940: goto -> 976
    //   943: aload_0
    //   944: astore_3
    //   945: goto -> 966
    //   948: aload_3
    //   949: aload_3
    //   950: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   953: aload_1
    //   954: invokestatic ExpandDots : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   957: invokestatic SETCAR : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   960: pop
    //   961: aload_3
    //   962: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   965: astore_3
    //   966: aload_3
    //   967: getstatic org/renjin/gnur/api/Rinternals.R_NilValue : Lorg/renjin/sexp/SEXP;
    //   970: if_acmpeq -> 976
    //   973: goto -> 948
    //   976: aload_0
    //   977: astore_2
    //   978: goto -> 1027
    //   981: aload_0
    //   982: astore_2
    //   983: goto -> 1027
    //   986: new org/renjin/gcc/runtime/BytePtr
    //   989: dup
    //   990: ldc_w 'stats '
    //   993: invokevirtual getBytes : ()[B
    //   996: iconst_0
    //   997: invokespecial <init> : ([BI)V
    //   1000: new org/renjin/gcc/runtime/BytePtr
    //   1003: dup
    //   1004: ldc_w 'invalid formula in 'update' '
    //   1007: invokevirtual getBytes : ()[B
    //   1010: iconst_0
    //   1011: invokespecial <init> : ([BI)V
    //   1014: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
    //   1017: checkcast org/renjin/gcc/runtime/BytePtr
    //   1020: iconst_0
    //   1021: anewarray java/lang/Object
    //   1024: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
    //   1027: aload_2
    //   1028: areturn
  }
  
  public static void ExtractVars(SEXP paramSEXP, int paramInt) {
    if (Rinternals.TYPEOF(paramSEXP) != 0 && isZeroOne(paramSEXP) == 0) {
      if (Rinternals.TYPEOF(paramSEXP) != 1) {
        if (!Rinternals.Rf_isLanguage(paramSEXP)) {
          Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("invalid model formula in ExtractVars\000".getBytes(), 0)), new Object[0]);
          return;
        } 
        int i = Rinternals.Rf_length(paramSEXP);
        if (Rinternals.CAR(paramSEXP) != tildeSymbol) {
          if (Rinternals.CAR(paramSEXP) != plusSymbol) {
            if (Rinternals.CAR(paramSEXP) != colonSymbol) {
              if (Rinternals.CAR(paramSEXP) != powerSymbol) {
                if (Rinternals.CAR(paramSEXP) != timesSymbol) {
                  if (Rinternals.CAR(paramSEXP) != inSymbol) {
                    if (Rinternals.CAR(paramSEXP) != slashSymbol) {
                      if (Rinternals.CAR(paramSEXP) != minusSymbol) {
                        if (Rinternals.CAR(paramSEXP) != parenSymbol) {
                          InstallVar(paramSEXP);
                          return;
                        } 
                        ExtractVars(Rinternals.CADR(paramSEXP), paramInt);
                        return;
                      } 
                      if (i != 2) {
                        ExtractVars(Rinternals.CADR(paramSEXP), paramInt);
                        ExtractVars(Rinternals.CADDR(paramSEXP), 1);
                        return;
                      } 
                      ExtractVars(Rinternals.CADR(paramSEXP), 1);
                      return;
                    } 
                    ExtractVars(Rinternals.CADR(paramSEXP), paramInt);
                    ExtractVars(Rinternals.CADDR(paramSEXP), paramInt);
                    return;
                  } 
                  ExtractVars(Rinternals.CADR(paramSEXP), paramInt);
                  ExtractVars(Rinternals.CADDR(paramSEXP), paramInt);
                  return;
                } 
                ExtractVars(Rinternals.CADR(paramSEXP), paramInt);
                ExtractVars(Rinternals.CADDR(paramSEXP), paramInt);
                return;
              } 
              if (!Rinternals.Rf_isNumeric(Rinternals.CADDR(paramSEXP)))
                Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("invalid power in formula\000".getBytes(), 0)), new Object[0]); 
              ExtractVars(Rinternals.CADR(paramSEXP), paramInt);
              return;
            } 
            ExtractVars(Rinternals.CADR(paramSEXP), paramInt);
            ExtractVars(Rinternals.CADDR(paramSEXP), paramInt);
            return;
          } 
          if (Rinternals.Rf_length(paramSEXP) > 1)
            ExtractVars(Rinternals.CADR(paramSEXP), paramInt); 
          if (Rinternals.Rf_length(paramSEXP) > 2)
            ExtractVars(Rinternals.CADDR(paramSEXP), paramInt); 
          return;
        } 
        if (response != 0)
          Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("invalid model formula\000".getBytes(), 0)), new Object[0]); 
        if (Rinternals.TYPEOF(Rinternals.CDDR(paramSEXP)) != 0) {
          response = 1;
          InstallVar(Rinternals.CADR(paramSEXP));
          ExtractVars(Rinternals.CADDR(paramSEXP), 0);
          return;
        } 
        response = 0;
        ExtractVars(Rinternals.CADR(paramSEXP), 0);
        return;
      } 
      if (paramSEXP == dotSymbol)
        haveDot = 1; 
      if (paramInt == 0)
        if (paramSEXP == dotSymbol && framenames != Rinternals.R_NilValue) {
          haveDot = 1;
          for (paramInt = 0; Rinternals.Rf_length(framenames) > paramInt; paramInt++) {
            paramSEXP = Defn.Rf_installTrChar(Rinternals.STRING_ELT(framenames, paramInt));
            if (MatchVar(paramSEXP, Rinternals.CADR(varlist)) == 0)
              InstallVar(paramSEXP); 
          } 
        } else {
          InstallVar(paramSEXP);
        }  
    } 
  }
  
  public static int GetBit(SEXP paramSEXP, int paramInt) {
    int i = 0 + Integer.divideUnsigned(paramInt + -1, 32) * 4;
    return Rinternals2.INTEGER(paramSEXP).getInt(i) >>> (-paramInt & 0x1F) & 0x1;
  }
  
  public static SEXP InTerms(SEXP paramSEXP1, SEXP paramSEXP2) {
    SEXP sEXP = (SEXP)BytePtr.of(0).getArray();
    sEXP = (SEXP)BytePtr.of(0).getArray();
    paramSEXP1 = EncodeVars(paramSEXP1);
    Rinternals.Rf_protect(paramSEXP1);
    Rinternals.Rf_protect(EncodeVars(paramSEXP2));
    paramSEXP2 = AllocTerm();
    Rinternals.Rf_protect(paramSEXP2);
    for (sEXP = EncodeVars(paramSEXP2); sEXP != Rinternals.R_NilValue; sEXP = Rinternals.CDR(sEXP)) {
      for (byte b = 0; b < nwords; b++)
        Rinternals2.INTEGER(paramSEXP2).setInt(0 + b * 4, Rinternals2.INTEGER(paramSEXP2).getInt(0 + b * 4) | Rinternals2.INTEGER(Rinternals.CAR(sEXP)).getInt(0 + b * 4)); 
    } 
    for (sEXP = paramSEXP1; sEXP != Rinternals.R_NilValue; sEXP = Rinternals.CDR(sEXP)) {
      for (byte b = 0; b < nwords; b++)
        Rinternals2.INTEGER(Rinternals.CAR(sEXP)).setInt(0 + b * 4, Rinternals2.INTEGER(paramSEXP2).getInt(0 + b * 4) | Rinternals2.INTEGER(Rinternals.CAR(sEXP)).getInt(0 + b * 4)); 
    } 
    return TrimRepeats(paramSEXP1);
  }
  
  public static int InstallVar(SEXP paramSEXP) {
    int i;
    if (Rinternals.TYPEOF(paramSEXP) != 1 && !Rinternals.Rf_isLanguage(paramSEXP) && isZeroOne(paramSEXP) == 0)
      Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("invalid term in model formula\000".getBytes(), 0)), new Object[0]); 
    byte b = 0;
    SEXP sEXP = varlist;
    while (true) {
      if (Rinternals.CDR(sEXP) != Rinternals.R_NilValue) {
        b++;
        if (MatchVar(paramSEXP, Rinternals.CADR(sEXP)) == 0) {
          sEXP = Rinternals.CDR(sEXP);
          continue;
        } 
        i = b;
        break;
      } 
      Rinternals.SETCDR(sEXP, Rinternals.Rf_cons(i, Rinternals.R_NilValue));
      i = b + 1;
      break;
    } 
    return i;
  }
  
  public static SEXP InteractTerms(SEXP paramSEXP1, SEXP paramSEXP2) {
    SEXP sEXP2 = (SEXP)BytePtr.of(0).getArray();
    sEXP2 = (SEXP)BytePtr.of(0).getArray();
    sEXP2 = (SEXP)BytePtr.of(0).getArray();
    SEXP sEXP1 = EncodeVars(paramSEXP1);
    Rinternals.Rf_protect(sEXP1);
    paramSEXP1 = EncodeVars(paramSEXP2);
    Rinternals.Rf_protect(paramSEXP1);
    paramSEXP2 = Rinternals.Rf_allocList(Rinternals.Rf_length(sEXP1) * Rinternals.Rf_length(paramSEXP1));
    Rinternals.Rf_protect(paramSEXP2);
    sEXP2 = paramSEXP2;
    for (SEXP sEXP3 = sEXP1; sEXP3 != Rinternals.R_NilValue; sEXP3 = Rinternals.CDR(sEXP3)) {
      for (SEXP sEXP = paramSEXP1; sEXP != Rinternals.R_NilValue; sEXP = Rinternals.CDR(sEXP)) {
        sEXP1 = Rinternals.CAR(sEXP);
        Rinternals.SETCAR(sEXP2, OrBits(Rinternals.CAR(sEXP3), sEXP1));
        sEXP2 = Rinternals.CDR(sEXP2);
      } 
    } 
    return TrimRepeats(paramSEXP2);
  }
  
  public static int MatchVar(SEXP paramSEXP1, SEXP paramSEXP2) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: if_acmpeq -> 8
    //   5: goto -> 13
    //   8: iconst_1
    //   9: istore_0
    //   10: goto -> 291
    //   13: aload_0
    //   14: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
    //   17: ifeq -> 23
    //   20: goto -> 38
    //   23: aload_1
    //   24: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
    //   27: ifeq -> 33
    //   30: goto -> 38
    //   33: iconst_1
    //   34: istore_0
    //   35: goto -> 291
    //   38: aload_0
    //   39: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
    //   42: ifeq -> 55
    //   45: aload_1
    //   46: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
    //   49: ifeq -> 55
    //   52: goto -> 60
    //   55: iconst_0
    //   56: istore_0
    //   57: goto -> 291
    //   60: aload_0
    //   61: invokestatic Rf_isList : (Lorg/renjin/sexp/SEXP;)Z
    //   64: ifne -> 77
    //   67: aload_0
    //   68: invokestatic Rf_isLanguage : (Lorg/renjin/sexp/SEXP;)Z
    //   71: ifne -> 77
    //   74: goto -> 163
    //   77: aload_1
    //   78: invokestatic Rf_isList : (Lorg/renjin/sexp/SEXP;)Z
    //   81: ifne -> 94
    //   84: aload_1
    //   85: invokestatic Rf_isLanguage : (Lorg/renjin/sexp/SEXP;)Z
    //   88: ifne -> 94
    //   91: goto -> 163
    //   94: aload_1
    //   95: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   98: astore_2
    //   99: aload_0
    //   100: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   103: aload_2
    //   104: invokestatic MatchVar : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)I
    //   107: ifne -> 113
    //   110: goto -> 156
    //   113: aload_1
    //   114: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   117: astore_2
    //   118: aload_0
    //   119: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   122: aload_2
    //   123: invokestatic MatchVar : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)I
    //   126: ifne -> 132
    //   129: goto -> 156
    //   132: aload_1
    //   133: invokestatic TAG : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   136: astore_1
    //   137: aload_0
    //   138: invokestatic TAG : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   141: aload_1
    //   142: invokestatic MatchVar : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)I
    //   145: ifne -> 151
    //   148: goto -> 156
    //   151: iconst_1
    //   152: istore_0
    //   153: goto -> 158
    //   156: iconst_0
    //   157: istore_0
    //   158: iload_0
    //   159: istore_0
    //   160: goto -> 291
    //   163: aload_0
    //   164: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
    //   167: iconst_1
    //   168: if_icmpeq -> 174
    //   171: goto -> 202
    //   174: aload_1
    //   175: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
    //   178: iconst_1
    //   179: if_icmpeq -> 185
    //   182: goto -> 202
    //   185: aload_0
    //   186: aload_1
    //   187: if_acmpeq -> 195
    //   190: iconst_0
    //   191: istore_0
    //   192: goto -> 197
    //   195: iconst_1
    //   196: istore_0
    //   197: iload_0
    //   198: istore_0
    //   199: goto -> 291
    //   202: aload_0
    //   203: invokestatic Rf_isNumeric : (Lorg/renjin/sexp/SEXP;)Z
    //   206: ifne -> 212
    //   209: goto -> 246
    //   212: aload_1
    //   213: invokestatic Rf_isNumeric : (Lorg/renjin/sexp/SEXP;)Z
    //   216: ifne -> 222
    //   219: goto -> 246
    //   222: aload_0
    //   223: invokestatic Rf_asReal : (Lorg/renjin/sexp/SEXP;)D
    //   226: aload_1
    //   227: invokestatic Rf_asReal : (Lorg/renjin/sexp/SEXP;)D
    //   230: dcmpl
    //   231: ifeq -> 239
    //   234: iconst_0
    //   235: istore_0
    //   236: goto -> 241
    //   239: iconst_1
    //   240: istore_0
    //   241: iload_0
    //   242: istore_0
    //   243: goto -> 291
    //   246: aload_0
    //   247: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
    //   250: bipush #16
    //   252: if_icmpeq -> 258
    //   255: goto -> 289
    //   258: aload_1
    //   259: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
    //   262: bipush #16
    //   264: if_icmpeq -> 270
    //   267: goto -> 289
    //   270: aload_1
    //   271: iconst_0
    //   272: invokestatic STRING_ELT : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
    //   275: astore_1
    //   276: aload_0
    //   277: iconst_0
    //   278: invokestatic STRING_ELT : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
    //   281: aload_1
    //   282: invokestatic Seql2 : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)I
    //   285: istore_0
    //   286: goto -> 291
    //   289: iconst_0
    //   290: istore_0
    //   291: iload_0
    //   292: ireturn
  }
  
  public static SEXP NestTerms(SEXP paramSEXP1, SEXP paramSEXP2) {
    SEXP sEXP1 = (SEXP)BytePtr.of(0).getArray();
    sEXP1 = (SEXP)BytePtr.of(0).getArray();
    paramSEXP1 = EncodeVars(paramSEXP1);
    Rinternals.Rf_protect(paramSEXP1);
    paramSEXP2 = EncodeVars(paramSEXP2);
    Rinternals.Rf_protect(paramSEXP2);
    sEXP1 = AllocTerm();
    Rinternals.Rf_protect(sEXP1);
    SEXP sEXP2;
    for (sEXP2 = paramSEXP1; sEXP2 != Rinternals.R_NilValue; sEXP2 = Rinternals.CDR(sEXP2)) {
      for (byte b = 0; b < nwords; b++)
        Rinternals2.INTEGER(sEXP1).setInt(0 + b * 4, Rinternals2.INTEGER(sEXP1).getInt(0 + b * 4) | Rinternals2.INTEGER(Rinternals.CAR(sEXP2)).getInt(0 + b * 4)); 
    } 
    for (sEXP2 = paramSEXP2; sEXP2 != Rinternals.R_NilValue; sEXP2 = Rinternals.CDR(sEXP2)) {
      for (byte b = 0; b < nwords; b++)
        Rinternals2.INTEGER(Rinternals.CAR(sEXP2)).setInt(0 + b * 4, Rinternals2.INTEGER(sEXP1).getInt(0 + b * 4) | Rinternals2.INTEGER(Rinternals.CAR(sEXP2)).getInt(0 + b * 4)); 
    } 
    Rinternals.Rf_listAppend(paramSEXP1, paramSEXP2);
    return TrimRepeats(paramSEXP1);
  }
  
  public static SEXP OrBits(SEXP paramSEXP1, SEXP paramSEXP2) {
    SEXP sEXP = (SEXP)BytePtr.of(0).getArray();
    sEXP = AllocTerm();
    for (byte b = 0; b < nwords; b++)
      Rinternals2.INTEGER(sEXP).setInt(0 + b * 4, Rinternals2.INTEGER(paramSEXP1).getInt(0 + b * 4) | Rinternals2.INTEGER(paramSEXP2).getInt(0 + b * 4)); 
    return sEXP;
  }
  
  public static SEXP PlusTerms(SEXP paramSEXP1, SEXP paramSEXP2) {
    Rinternals.Rf_protect(EncodeVars(paramSEXP1));
    return TrimRepeats(Rinternals.Rf_listAppend(EncodeVars(paramSEXP1), EncodeVars(paramSEXP2)));
  }
  
  public static SEXP PowerTerms(SEXP paramSEXP1, SEXP paramSEXP2) {
    SEXP sEXP1 = (SEXP)BytePtr.of(0).getArray();
    sEXP1 = (SEXP)BytePtr.of(0).getArray();
    sEXP1 = (SEXP)BytePtr.of(0).getArray();
    int i = Rinternals.Rf_asInteger(paramSEXP2);
    if (i == Arith.R_NaInt || i <= 1)
      Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("invalid power in formula\000".getBytes(), 0)), new Object[0]); 
    sEXP1 = Rinternals.R_NilValue;
    SEXP sEXP2 = EncodeVars(paramSEXP1);
    Rinternals.Rf_protect(sEXP2);
    SEXP sEXP3 = sEXP2;
    for (byte b = 1; b < i; b++) {
      Rinternals.Rf_protect(sEXP3);
      sEXP1 = Rinternals.Rf_allocList(Rinternals.Rf_length(sEXP2) * Rinternals.Rf_length(sEXP3));
      Rinternals.Rf_protect(sEXP1);
      SEXP sEXP4 = sEXP1;
      for (SEXP sEXP5 = sEXP2; sEXP5 != Rinternals.R_NilValue; sEXP5 = Rinternals.CDR(sEXP5)) {
        for (SEXP sEXP = sEXP3; sEXP != Rinternals.R_NilValue; sEXP = Rinternals.CDR(sEXP)) {
          paramSEXP1 = Rinternals.CAR(sEXP);
          Rinternals.SETCAR(sEXP4, OrBits(Rinternals.CAR(sEXP5), paramSEXP1));
          sEXP4 = Rinternals.CDR(sEXP4);
        } 
      } 
      sEXP3 = TrimRepeats(sEXP1);
    } 
    return sEXP1;
  }
  
  public static int Seql2(SEXP paramSEXP1, SEXP paramSEXP2) {
    if (paramSEXP1 != paramSEXP2) {
      if (Rinternals.IS_CACHED(paramSEXP1) == 0 || Rinternals.IS_CACHED(paramSEXP2) == 0) {
        VoidPtr.toPtr(Memory.vmaxget());
        BytePtr bytePtr = Rinternals.Rf_translateCharUTF8(paramSEXP2);
        if (Stdlib.strcmp((Ptr)Rinternals.Rf_translateCharUTF8(paramSEXP1), (Ptr)bytePtr) != 0) {
          null = false;
        } else {
          null = true;
        } 
        return null;
      } 
      throw new UnsatisfiedLinkException("ENC_KNOWN");
    } 
    return 1;
  }
  
  public static void SetBit(SEXP paramSEXP, int paramInt1, int paramInt2) {
    int j = Integer.divideUnsigned(paramInt1 + -1, 32);
    paramInt1 = -paramInt1 & 0x1F;
    if (paramInt2 == 0) {
      i = Rinternals2.INTEGER(paramSEXP).getInt(0 + j * 4) & (1 << paramInt1 ^ 0xFFFFFFFF);
      Rinternals2.INTEGER(paramSEXP).setInt(0 + j * 4, i);
      return;
    } 
    int i = Rinternals2.INTEGER(i).getInt(0 + j * 4) | 1 << paramInt1;
    Rinternals2.INTEGER(i).setInt(0 + j * 4, i);
  }
  
  public static SEXP StripTerm(SEXP paramSEXP1, SEXP paramSEXP2) {
    SEXP sEXP1 = (SEXP)BytePtr.of(0).getArray();
    sEXP1 = (SEXP)BytePtr.of(0).getArray();
    sEXP1 = Rinternals.R_NilValue;
    SEXP sEXP2 = Rinternals.R_NilValue;
    if (TermZero(paramSEXP1) != 0)
      intercept = 0; 
    while (paramSEXP2 != Rinternals.R_NilValue) {
      if (TermEqual(paramSEXP1, Rinternals.CAR(paramSEXP2)) == 0) {
        if (sEXP1 == Rinternals.R_NilValue)
          sEXP1 = paramSEXP2; 
        sEXP2 = paramSEXP2;
      } else if (sEXP2 != Rinternals.R_NilValue) {
        Rinternals.SETCDR(sEXP2, Rinternals.CDR(paramSEXP2));
      } 
      paramSEXP2 = Rinternals.CDR(paramSEXP2);
    } 
    return sEXP1;
  }
  
  public static int TermCode(SEXP paramSEXP1, SEXP paramSEXP2, int paramInt, SEXP paramSEXP3) {
    SEXP sEXP = (SEXP)BytePtr.of(0).getArray();
    byte b;
    for (b = 0; b < nwords; b++)
      Rinternals2.INTEGER(paramSEXP3).setInt(0 + b * 4, Rinternals2.INTEGER(Rinternals.CAR(paramSEXP2)).getInt(0 + b * 4)); 
    SetBit(paramSEXP3, paramInt, 0);
    paramInt = 1;
    b = 0;
    while (b < nwords) {
      if (Rinternals2.INTEGER(paramSEXP3).getInt(0 + b * 4) == 0) {
        b++;
        continue;
      } 
      paramInt = 0;
      break;
    } 
    if (paramInt == 0) {
      byte b1;
      paramSEXP1 = paramSEXP1;
      while (true) {
        if (paramSEXP1 != paramSEXP2) {
          paramInt = 1;
          for (b = 0; b < nwords; b++) {
            if (((Rinternals2.INTEGER(Rinternals.CAR(paramSEXP1)).getInt(0 + b * 4) ^ 0xFFFFFFFF) & Rinternals2.INTEGER(paramSEXP3).getInt(0 + b * 4)) != 0)
              paramInt = 0; 
          } 
          if (paramInt == 0) {
            paramSEXP1 = Rinternals.CDR(paramSEXP1);
            continue;
          } 
          boolean bool = true;
          break;
        } 
        b1 = 2;
        break;
      } 
      return b1;
    } 
    return 1;
  }
  
  public static int TermEqual(SEXP paramSEXP1, SEXP paramSEXP2) {
    boolean bool;
    byte b = 0;
    while (true) {
      if (b >= nwords) {
        bool = true;
        break;
      } 
      if (Rinternals2.INTEGER(bool).getInt(0 + b * 4) == Rinternals2.INTEGER(paramSEXP2).getInt(0 + b * 4)) {
        b++;
        continue;
      } 
      bool = false;
      break;
    } 
    return bool;
  }
  
  public static int TermZero(SEXP paramSEXP) {
    boolean bool;
    byte b = 0;
    while (true) {
      if (b >= nwords) {
        bool = true;
        break;
      } 
      if (Rinternals2.INTEGER(bool).getInt(0 + b * 4) == 0) {
        b++;
        continue;
      } 
      bool = false;
      break;
    } 
    return bool;
  }
  
  public static SEXP TrimRepeats(SEXP paramSEXP) {
    SEXP sEXP = (SEXP)BytePtr.of(0).getArray();
    BytePtr.of(0);
    while (paramSEXP != Rinternals.R_NilValue && TermZero(Rinternals.CAR(paramSEXP)) != 0)
      paramSEXP = Rinternals.CDR(paramSEXP); 
    if (paramSEXP != Rinternals.R_NilValue && Rinternals.CDR(paramSEXP) != Rinternals.R_NilValue) {
      Rinternals.Rf_protect(paramSEXP);
      byte b = 1;
      IntPtr intPtr = Rinternals.LOGICAL(Rinternals.Rf_protect(Rinternals.Rf_duplicated(Rinternals.Rf_protect(Rinternals.Rf_PairToVectorList(paramSEXP)), false)));
      SEXP sEXP1 = paramSEXP;
      while (Rinternals.CDR(sEXP1) != Rinternals.R_NilValue) {
        sEXP = Rinternals.CDR(sEXP1);
        if (intPtr.getInt(0 + b * 4) == 0 && TermZero(Rinternals.CAR(sEXP)) == 0) {
          sEXP1 = sEXP;
        } else {
          Rinternals.SETCDR(sEXP1, Rinternals.CDR(sEXP));
        } 
        b++;
      } 
      return paramSEXP;
    } 
    return paramSEXP;
  }
  
  public static void addfactor(Ptr paramPtr1, int paramInt1, int paramInt2, Ptr paramPtr2, int paramInt3, int paramInt4, Ptr paramPtr3) {
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    for (int i = paramInt4 + -1; i >= 0; i--) {
      for (byte b = 0; b < paramInt2; b++) {
        int k = b * paramInt1 * 8;
        int j = (i * paramInt2 + b) * paramInt1 * 8;
        paramInt4 = i * paramInt3 * 8;
        for (byte b1 = 0; b1 < paramInt1; b1++) {
          if (paramPtr3.getInt(b1 * 4) != Arith.R_NaInt) {
            paramPtr1.setDouble(j + b1 * 8, paramPtr2.getDouble(paramInt4 + (paramPtr3.getInt(b1 * 4) + -1) * 8) * paramPtr1.getDouble(k + b1 * 8));
          } else {
            paramPtr1.setDouble(j + b1 * 8, Arith.R_NaReal);
          } 
        } 
      } 
    } 
  }
  
  public static void addvar(Ptr paramPtr1, int paramInt1, int paramInt2, Ptr paramPtr2, int paramInt3, int paramInt4) {
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    for (int i = paramInt4 + -1; i >= 0; i--) {
      for (byte b = 0; b < paramInt2; b++) {
        int k = b * paramInt1 * 8;
        int j = (i * paramInt2 + b) * paramInt1 * 8;
        paramInt4 = i * paramInt3 * 8;
        for (byte b1 = 0; b1 < paramInt1; b1++)
          paramPtr1.setDouble(j + b1 * 8, paramPtr2.getDouble(paramInt4 + b1 * 8) * paramPtr1.getDouble(k + b1 * 8)); 
      } 
    } 
  }
  
  public static void firstfactor(Ptr paramPtr1, int paramInt1, int paramInt2, Ptr paramPtr2, int paramInt3, int paramInt4, Ptr paramPtr3) {
    BytePtr.of(0);
    BytePtr.of(0);
    for (byte b = 0; b < paramInt4; b++) {
      int i = b * paramInt1 * 8;
      paramInt2 = b * paramInt3 * 8;
      for (byte b1 = 0; b1 < paramInt1; b1++) {
        if (paramPtr3.getInt(b1 * 4) != Arith.R_NaInt) {
          paramPtr1.setDouble(i + b1 * 8, paramPtr2.getDouble(paramInt2 + (paramPtr3.getInt(b1 * 4) + -1) * 8));
        } else {
          paramPtr1.setDouble(i + b1 * 8, Arith.R_NaReal);
        } 
      } 
    } 
  }
  
  public static void firstvar(Ptr paramPtr1, int paramInt1, int paramInt2, Ptr paramPtr2, int paramInt3, int paramInt4) {
    BytePtr.of(0);
    BytePtr.of(0);
    for (byte b = 0; b < paramInt4; b++) {
      int i = b * paramInt1 * 8;
      paramInt2 = b * paramInt3 * 8;
      for (byte b1 = 0; b1 < paramInt1; b1++)
        paramPtr1.setDouble(i + b1 * 8, paramPtr2.getDouble(paramInt2 + b1 * 8)); 
    } 
  }
  
  public static int isOne(SEXP paramSEXP) {
    if (Rinternals.Rf_isNumeric(paramSEXP)) {
      if (Rinternals.Rf_asReal(paramSEXP) != 1.0D) {
        null = false;
      } else {
        null = true;
      } 
      return null;
    } 
    return 0;
  }
  
  public static int isOrdered_int(SEXP paramSEXP) {
    return (Rinternals.TYPEOF(paramSEXP) != 13 || !Rinternals.Rf_inherits(paramSEXP, new BytePtr("factor\000".getBytes(), 0)) || !Rinternals.Rf_inherits(paramSEXP, new BytePtr("ordered\000".getBytes(), 0))) ? 0 : 1;
  }
  
  public static int isUnordered_int(SEXP paramSEXP) {
    return (Rinternals.TYPEOF(paramSEXP) != 13 || !Rinternals.Rf_inherits(paramSEXP, new BytePtr("factor\000".getBytes(), 0)) || Rinternals.Rf_inherits(paramSEXP, new BytePtr("ordered\000".getBytes(), 0))) ? 0 : 1;
  }
  
  public static int isZero(SEXP paramSEXP) {
    if (Rinternals.Rf_isNumeric(paramSEXP)) {
      if (Rinternals.Rf_asReal(paramSEXP) != 0.0D) {
        null = false;
      } else {
        null = true;
      } 
      return null;
    } 
    return 0;
  }
  
  public static int isZeroOne(SEXP paramSEXP) {
    if (Rinternals.Rf_isNumeric(paramSEXP)) {
      if (Rinternals.Rf_asReal(paramSEXP) != 0.0D && Rinternals.Rf_asReal(paramSEXP) != 1.0D) {
        null = false;
      } else {
        null = true;
      } 
      return null;
    } 
    return 0;
  }
  
  public static SEXP modelframe(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4) {
    int i;
    SEXP sEXP2;
    byte[] arrayOfByte = new byte[256];
    BytePtr.of(0);
    paramSEXP1 = (SEXP)BytePtr.of(0).getArray();
    paramSEXP1 = (SEXP)BytePtr.of(0).getArray();
    paramSEXP1 = (SEXP)BytePtr.of(0).getArray();
    paramSEXP1 = (SEXP)BytePtr.of(0).getArray();
    paramSEXP1 = (SEXP)BytePtr.of(0).getArray();
    paramSEXP1 = (SEXP)BytePtr.of(0).getArray();
    paramSEXP1 = (SEXP)BytePtr.of(0).getArray();
    paramSEXP1 = (SEXP)BytePtr.of(0).getArray();
    paramSEXP1 = (SEXP)BytePtr.of(0).getArray();
    paramSEXP1 = (SEXP)BytePtr.of(0).getArray();
    paramSEXP1 = (SEXP)BytePtr.of(0).getArray();
    VoidPtr.toPtr(Memory.vmaxget());
    paramSEXP3 = Rinternals.CAR(Rinternals.CDR(paramSEXP3));
    SEXP sEXP4 = Rinternals.CAR(Rinternals.CDR(Rinternals.CDR(paramSEXP3)));
    SEXP sEXP3 = Rinternals.CAR(Rinternals.CDR(Rinternals.CDR(Rinternals.CDR(paramSEXP3))));
    SEXP sEXP5 = Rinternals.CAR(Rinternals.CDR(Rinternals.CDR(Rinternals.CDR(Rinternals.CDR(paramSEXP3)))));
    SEXP sEXP6 = Rinternals.CAR(Rinternals.CDR(Rinternals.CDR(Rinternals.CDR(Rinternals.CDR(Rinternals.CDR(paramSEXP3))))));
    SEXP sEXP7 = Rinternals.CAR(Rinternals.CDR(Rinternals.CDR(Rinternals.CDR(Rinternals.CDR(Rinternals.CDR(Rinternals.CDR(paramSEXP3)))))));
    SEXP sEXP8 = Rinternals.CAR(Rinternals.CDR(Rinternals.CDR(Rinternals.CDR(Rinternals.CDR(Rinternals.CDR(Rinternals.CDR(Rinternals.CDR(paramSEXP3))))))));
    SEXP sEXP9 = Rinternals.CAR(Rinternals.CDR(Rinternals.CDR(Rinternals.CDR(Rinternals.CDR(Rinternals.CDR(Rinternals.CDR(Rinternals.CDR(Rinternals.CDR(paramSEXP3)))))))));
    if (!Rinternals.Rf_isNewList(sEXP3))
      Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("invalid variables\000".getBytes(), 0)), new Object[0]); 
    if (Rinternals.TYPEOF(sEXP5) != 16)
      Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("invalid variable names\000".getBytes(), 0)), new Object[0]); 
    int j = Rinternals.Rf_length(sEXP3);
    if (j != Rinternals.Rf_length(sEXP5))
      Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("number of variables != number of variable names\000".getBytes(), 0)), new Object[0]); 
    if (!Rinternals.Rf_isNewList(sEXP6))
      Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("invalid extra variables\000".getBytes(), 0)), new Object[0]); 
    int k = Rinternals.Rf_length(sEXP6);
    if (k != Rinternals.Rf_length(sEXP7))
      Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("number of variables != number of variable names\000".getBytes(), 0)), new Object[0]); 
    if (k != 0 && Rinternals.TYPEOF(sEXP7) != 16)
      Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("invalid extra variable names\000".getBytes(), 0)), new Object[0]); 
    byte b3 = 0;
    for (byte b1 = 0; b1 < k; b1++) {
      if (Rinternals.VECTOR_ELT(sEXP6, b1) != Rinternals.R_NilValue)
        b3++; 
    } 
    SEXP sEXP1 = Rinternals.Rf_allocVector(19, j + b3);
    Rinternals.Rf_protect(sEXP1);
    SEXP sEXP10 = Rinternals.Rf_allocVector(16, j + b3);
    Rinternals.Rf_protect(sEXP10);
    byte b4;
    for (b4 = 0; b4 < j; b4++) {
      Rinternals.SET_VECTOR_ELT(sEXP1, b4, Rinternals.VECTOR_ELT(sEXP3, b4));
      Rinternals.SET_STRING_ELT(sEXP10, b4, Rinternals.STRING_ELT(sEXP5, b4));
    } 
    byte b2 = 0;
    b4 = 0;
    while (b2 < k) {
      if (Rinternals.VECTOR_ELT(sEXP6, b2) != Rinternals.R_NilValue) {
        BytePtr bytePtr = Rinternals.Rf_translateChar(Rinternals.STRING_ELT(sEXP7, b2));
        if (Integer.compareUnsigned(Stdlib.strlen((Ptr)bytePtr) + 3, 256) > 0)
          Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("overlong names in '%s'\000".getBytes(), 0)), new Object[] { bytePtr }); 
        Stdlib.snprintf(new BytePtr(arrayOfByte, 0), 256, new BytePtr("(%s)\000".getBytes(), 0), new Object[] { bytePtr });
        Rinternals.SET_VECTOR_ELT(sEXP1, j + b4, Rinternals.VECTOR_ELT(sEXP6, b2));
        Rinternals.SET_STRING_ELT(sEXP10, j + b4, Rinternals.Rf_mkChar((Ptr)new BytePtr(arrayOfByte, 0)));
        b4++;
      } 
      b2++;
    } 
    Rinternals.Rf_setAttrib(sEXP1, Rinternals.R_NamesSymbol, sEXP10);
    int m = Rinternals.Rf_length(sEXP1);
    if (m <= 0) {
      i = Rinternals.Rf_length(sEXP4);
    } else {
      i = Rinternals.Rf_nrows(Rinternals.VECTOR_ELT(sEXP1, 0));
      for (byte b = 0; b < m; b++) {
        Object[] arrayOfObject;
        BytePtr bytePtr1;
        BytePtr bytePtr2;
        SEXP sEXP = Rinternals.VECTOR_ELT(sEXP1, b);
        switch (Rinternals.TYPEOF(sEXP)) {
          case 10:
          case 13:
          case 14:
          case 15:
          case 16:
          case 24:
            break;
          default:
            bytePtr2 = Rinternals.Rf_translateChar(Rinternals.STRING_ELT(sEXP10, b));
            bytePtr1 = Rinternals.Rf_type2char(Rinternals.TYPEOF(sEXP));
            arrayOfObject = new Object[2];
            arrayOfObject[0] = bytePtr1;
            arrayOfObject[1] = bytePtr2;
            Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("invalid type (%s) for variable '%s'\000".getBytes(), 0)), arrayOfObject);
            break;
        } 
        if (Rinternals.Rf_nrows(sEXP) != i) {
          bytePtr1 = Rinternals.Rf_translateChar(Rinternals.STRING_ELT(sEXP10, b));
          Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("variable lengths differ (found for '%s')\000".getBytes(), 0)), new Object[] { bytePtr1 });
        } 
      } 
    } 
    Rinternals.Rf_protect(sEXP1);
    Rinternals.Rf_protect(sEXP8);
    sEXP10 = Rinternals.Rf_mkString((Ptr)new BytePtr("data.frame\000".getBytes(), 0));
    Rinternals.Rf_protect(sEXP10);
    Rinternals.Rf_setAttrib(sEXP1, Rinternals.R_ClassSymbol, sEXP10);
    if (Rinternals.Rf_length(sEXP4) != i) {
      sEXP4 = Rinternals.Rf_allocVector(13, 2);
      Rinternals.Rf_protect(sEXP4);
      Rinternals2.INTEGER(sEXP4).setInt(0, Arith.R_NaInt);
      Rinternals2.INTEGER(sEXP4).setInt(4, i);
      Rinternals.Rf_setAttrib(sEXP1, Rinternals.R_RowNamesSymbol, sEXP4);
    } else {
      Rinternals.Rf_setAttrib(sEXP1, Rinternals.R_RowNamesSymbol, sEXP4);
    } 
    if (sEXP8 != Rinternals.R_NilValue) {
      Rinternals.Rf_protect(Rinternals.Rf_install(new BytePtr("[.data.frame\000".getBytes(), 0)));
      sEXP1 = Defn.Rf_mkFalse();
      Rinternals.Rf_protect(Rinternals.Rf_lcons(Rinternals.Rf_install(new BytePtr("[.data.frame\000".getBytes(), 0)), Rinternals.Rf_list4(sEXP1, sEXP8, Rinternals.R_MissingArg, sEXP1)));
      sEXP1 = Rinternals.Rf_eval(Rinternals.Rf_lcons(Rinternals.Rf_install(new BytePtr("[.data.frame\000".getBytes(), 0)), Rinternals.Rf_list4(sEXP1, sEXP8, Rinternals.R_MissingArg, sEXP1)), paramSEXP4);
    } 
    Rinternals.Rf_protect(sEXP1);
    if (sEXP9 != Rinternals.R_NilValue) {
      Rinternals.Rf_setAttrib(sEXP1, Rinternals.Rf_install(new BytePtr("terms\000".getBytes(), 0)), paramSEXP3);
      if (Rinternals.TYPEOF(sEXP9) == 16 && Rinternals.Rf_length(sEXP9) > 0)
        sEXP9 = Defn.Rf_installTrChar(Rinternals.STRING_ELT(sEXP9, 0)); 
      Rinternals.Rf_protect(sEXP9);
      Rinternals.Rf_protect(Rinternals.Rf_lang2(sEXP9, sEXP1));
      sEXP2 = Rinternals.Rf_eval(Rinternals.Rf_lang2(sEXP9, sEXP1), paramSEXP4);
      Rinternals.Rf_protect(sEXP2);
      if (!Rinternals.Rf_isNewList(sEXP2) || Rinternals.Rf_length(sEXP2) != Rinternals.Rf_length(sEXP1))
        Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("invalid result from na.action\000".getBytes(), 0)), new Object[0]); 
      int n = Rinternals.Rf_length(sEXP2);
      while (true) {
        boolean bool;
        if (n == 0) {
          bool = false;
        } else {
          bool = true;
        } 
        n--;
        if (!bool)
          break; 
        if (Rinternals.VECTOR_ELT(sEXP1, n) != Rinternals.VECTOR_ELT(sEXP2, n)) {
          SEXP sEXP = Rinternals.VECTOR_ELT(sEXP2, n);
          Defn.Rf_copyMostAttribNoTs(Rinternals.VECTOR_ELT(sEXP1, n), sEXP);
        } 
      } 
    } else {
      sEXP2 = sEXP1;
    } 
    Rinternals.Rf_protect(sEXP2);
    return sEXP2;
  }
  
  public static SEXP modelmatrix(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4) {
    double d;
    byte[] arrayOfByte = new byte[4096];
    BytePtr.of(0);
    BytePtr.of(0);
    paramSEXP1 = (SEXP)BytePtr.of(0).getArray();
    paramSEXP1 = (SEXP)BytePtr.of(0).getArray();
    paramSEXP1 = (SEXP)BytePtr.of(0).getArray();
    paramSEXP1 = (SEXP)BytePtr.of(0).getArray();
    paramSEXP1 = (SEXP)BytePtr.of(0).getArray();
    paramSEXP1 = (SEXP)BytePtr.of(0).getArray();
    paramSEXP1 = (SEXP)BytePtr.of(0).getArray();
    paramSEXP1 = (SEXP)BytePtr.of(0).getArray();
    paramSEXP1 = (SEXP)BytePtr.of(0).getArray();
    paramSEXP1 = (SEXP)BytePtr.of(0).getArray();
    paramSEXP1 = (SEXP)BytePtr.of(0).getArray();
    paramSEXP1 = (SEXP)BytePtr.of(0).getArray();
    paramSEXP1 = (SEXP)BytePtr.of(0).getArray();
    paramSEXP1 = (SEXP)BytePtr.of(0).getArray();
    paramSEXP1 = (SEXP)BytePtr.of(0).getArray();
    paramSEXP1 = (SEXP)BytePtr.of(0).getArray();
    System.arraycopy("\000\000".getBytes(), 0, arrayOfByte, 0, 2);
    SEXP sEXP6 = Rinternals.CDR(paramSEXP3);
    paramSEXP3 = Rinternals.CAR(sEXP6);
    int n = Rinternals.Rf_asLogical(Rinternals.Rf_getAttrib(paramSEXP3, Rinternals.Rf_install(new BytePtr("intercept\000".getBytes(), 0))));
    if (n == Arith.R_NaInt)
      n = 0; 
    int i1 = Rinternals.Rf_asLogical(Rinternals.Rf_getAttrib(paramSEXP3, Rinternals.Rf_install(new BytePtr("response\000".getBytes(), 0))));
    if (i1 == Arith.R_NaInt)
      i1 = 0; 
    int i = 0;
    int j = 0;
    paramSEXP3 = Rinternals.Rf_duplicate(Rinternals.Rf_getAttrib(paramSEXP3, Rinternals.Rf_install(new BytePtr("factors\000".getBytes(), 0))));
    Rinternals.Rf_protect(paramSEXP3);
    if (Rinternals.Rf_length(paramSEXP3) != 0) {
      if (!Rinternals.Rf_isInteger(paramSEXP3) || !Rinternals.Rf_isMatrix(paramSEXP3)) {
        Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("invalid '%s' argument\000".getBytes(), 0)), new Object[] { new BytePtr("terms\000".getBytes(), 0) });
      } else {
        j = Rinternals.Rf_nrows(paramSEXP3);
        i = Rinternals.Rf_ncols(paramSEXP3);
      } 
    } else {
      j = 1;
      i = 0;
    } 
    SEXP sEXP9 = Rinternals.Rf_getAttrib(paramSEXP3, Rinternals.R_DimNamesSymbol);
    if (Rinternals.Rf_length(paramSEXP3) > 0) {
      if (Rinternals.Rf_length(sEXP9) <= 0 || (j - n > 0 && Rinternals.TYPEOF(Rinternals.VECTOR_ELT(sEXP9, 0)) != 16))
        Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("invalid '%s' argument\000".getBytes(), 0)), new Object[] { new BytePtr("terms\000".getBytes(), 0) }); 
      sEXP9 = Rinternals.VECTOR_ELT(sEXP9, 0);
    } 
    SEXP sEXP10 = Rinternals.CADR(sEXP6);
    if (!Rinternals.Rf_isNewList(sEXP10) || Rinternals.Rf_length(sEXP10) < j)
      Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("invalid model frame\000".getBytes(), 0)), new Object[0]); 
    if (Rinternals.Rf_length(sEXP10) == 0)
      Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("do not know how many cases\000".getBytes(), 0)), new Object[0]); 
    int i2 = Rinternals.Rf_nrows(Rinternals.VECTOR_ELT(sEXP10, 0));
    sEXP6 = Rinternals.Rf_getAttrib(sEXP10, Rinternals.R_RowNamesSymbol);
    Rinternals.Rf_protect(sEXP6);
    SEXP sEXP11 = Rinternals.Rf_allocVector(19, j);
    Rinternals.Rf_protect(sEXP11);
    SEXP sEXP12 = Rinternals.Rf_allocVector(13, j);
    Rinternals.Rf_protect(sEXP12);
    SEXP sEXP13 = Rinternals.Rf_allocVector(10, j);
    Rinternals.Rf_protect(sEXP13);
    SEXP sEXP14 = Rinternals.Rf_allocVector(13, j);
    Rinternals.Rf_protect(sEXP14);
    for (byte b4 = 0; b4 < j; b4++) {
      int i3;
      SEXP sEXP = Rinternals.SET_VECTOR_ELT(sEXP11, b4, Rinternals.VECTOR_ELT(sEXP10, b4));
      if (Rinternals.Rf_nrows(sEXP) != i2)
        Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("variable lengths differ (found for variable %d)\000".getBytes(), 0)), new Object[] { Integer.valueOf(b4) }); 
      if (isOrdered_int(sEXP) == 0) {
        if (isUnordered_int(sEXP) == 0) {
          if (Rinternals.TYPEOF(sEXP) != 10) {
            if (!Rinternals.Rf_isNumeric(sEXP)) {
              Rinternals.LOGICAL(sEXP13).setInt(0 + b4 * 4, 0);
              Rinternals2.INTEGER(sEXP12).setInt(0 + b4 * 4, 0);
              Rinternals2.INTEGER(sEXP14).setInt(0 + b4 * 4, Rinternals.Rf_ncols(sEXP));
            } else {
              Rinternals.SET_VECTOR_ELT(sEXP11, b4, Rinternals.Rf_coerceVector(sEXP, 14));
              Rinternals.LOGICAL(sEXP13).setInt(0 + b4 * 4, 0);
              Rinternals2.INTEGER(sEXP12).setInt(0 + b4 * 4, 0);
              Ptr ptr1 = Rinternals2.INTEGER(sEXP14);
              i3 = Rinternals.Rf_ncols(Rinternals.VECTOR_ELT(sEXP11, b4));
              ptr1.setInt(0 + b4 * 4, i3);
            } 
          } else {
            Rinternals.LOGICAL(sEXP13).setInt(0 + b4 * 4, 0);
            Rinternals2.INTEGER(sEXP12).setInt(0 + b4 * 4, 2);
            Rinternals2.INTEGER(sEXP14).setInt(0 + b4 * 4, Rinternals.Rf_ncols(i3));
          } 
        } else {
          Rinternals.LOGICAL(sEXP13).setInt(0 + b4 * 4, 0);
          int i4 = 0 + b4 * 4;
          Rinternals2.INTEGER(sEXP12).setInt(i4, Rinternals.Rf_nlevels(i3));
          if (Rinternals2.INTEGER(sEXP12).getInt(i4) <= 0) {
            Object[] arrayOfObject = new Object[1];
            BytePtr bytePtr = GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("variable %d has no levels\000".getBytes(), 0));
            arrayOfObject[0] = Integer.valueOf(b4 + 1);
            Error.Rf_error(bytePtr, arrayOfObject);
          } 
          Rinternals2.INTEGER(sEXP14).setInt(0 + b4 * 4, Rinternals.Rf_ncols(i3));
        } 
      } else {
        Rinternals.LOGICAL(sEXP13).setInt(0 + b4 * 4, 1);
        int i4 = 0 + b4 * 4;
        Rinternals2.INTEGER(sEXP12).setInt(i4, Rinternals.Rf_nlevels(i3));
        if (Rinternals2.INTEGER(sEXP12).getInt(i4) <= 0) {
          Object[] arrayOfObject = new Object[1];
          BytePtr bytePtr = GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("variable %d has no levels\000".getBytes(), 0));
          arrayOfObject[0] = Integer.valueOf(b4 + 1);
          Error.Rf_error(bytePtr, arrayOfObject);
        } 
        Rinternals2.INTEGER(sEXP14).setInt(0 + b4 * 4, Rinternals.Rf_ncols(i3));
      } 
    } 
    if (n == 0) {
      byte b6;
      label326: for (b6 = 0; b6 < i; b6++) {
        int i3 = i1;
        while (i3 < j) {
          if (Rinternals2.INTEGER(sEXP12).getInt(0 + i3 * 4) <= 1 || Rinternals2.INTEGER(paramSEXP3).getInt(0 + (b6 * j + i3) * 4) <= 0) {
            i3++;
            continue;
          } 
          Rinternals2.INTEGER(paramSEXP3).setInt(0 + (b6 * j + i3) * 4, 2);
          break label326;
        } 
      } 
    } 
    sEXP10 = Rinternals.Rf_allocVector(19, j);
    Rinternals.Rf_protect(sEXP10);
    sEXP13 = Rinternals.Rf_allocVector(19, j);
    Rinternals.Rf_protect(sEXP13);
    SEXP sEXP5 = Rinternals.Rf_lang3(Rinternals.R_NilValue, Rinternals.R_NilValue, Rinternals.R_NilValue);
    Rinternals.Rf_protect(sEXP5);
    Rinternals.SETCAR(sEXP5, Rinternals.Rf_install(new BytePtr("contrasts\000".getBytes(), 0)));
    Rinternals.SETCADDR(sEXP5, Rinternals.Rf_allocVector(10, 1));
    byte b1;
    for (b1 = 0; b1 < j; b1++) {
      if (Rinternals2.INTEGER(sEXP12).getInt(0 + b1 * 4) != 0) {
        int i3 = 0;
        for (byte b6 = 0; b6 < i; b6++) {
          if (Rinternals2.INTEGER(paramSEXP3).getInt(0 + (b6 * j + b1) * 4) != 1) {
            if (Rinternals2.INTEGER(paramSEXP3).getInt(0 + (b6 * j + b1) * 4) == 2)
              i3 |= 0x2; 
          } else {
            i3 |= 0x1;
          } 
        } 
        Rinternals.SETCADR(sEXP5, Rinternals.VECTOR_ELT(sEXP11, b1));
        if ((i3 & 0x1) != 0) {
          Rinternals.LOGICAL(Rinternals.CADDR(sEXP5)).setInt(0, 1);
          Rinternals.SET_VECTOR_ELT(sEXP10, b1, Rinternals.Rf_eval(sEXP5, paramSEXP4));
        } 
        if ((i3 & 0x2) != 0) {
          Rinternals.LOGICAL(Rinternals.CADDR(sEXP5)).setInt(0, 0);
          Rinternals.SET_VECTOR_ELT(sEXP13, b1, Rinternals.Rf_eval(sEXP5, paramSEXP4));
        } 
      } 
    } 
    byte b = -1;
    if (i1 > 0)
      for (byte b6 = 0; b6 < i; b6++) {
        if (Rinternals2.INTEGER(paramSEXP3).getInt(0 + (i1 + -1 + b6 * j) * 4) != 0) {
          b1 = 0;
          int i3 = 0;
          while (b1 < j) {
            byte b7;
            if (Rinternals2.INTEGER(paramSEXP3).getInt(0 + (b6 * j + b1) * 4) <= 0) {
              b7 = 0;
            } else {
              b7 = 1;
            } 
            i3 = b7 + i3;
            b1++;
          } 
          if (i3 == 1) {
            b = b6;
            break;
          } 
        } 
      }  
    SEXP sEXP3 = Rinternals.Rf_allocVector(13, i);
    Rinternals.Rf_protect(sEXP3);
    if (n == 0) {
      d = 0.0D;
    } else {
      d = 1.0D;
    } 
    for (i1 = 0; i1 < i; i1++) {
      if (i1 != b) {
        double d1 = 1.0D;
        for (byte b6 = 0; b6 < j; b6++) {
          if (Rinternals2.INTEGER(paramSEXP3).getInt(0 + (i1 * j + b6) * 4) != 0)
            if (Rinternals2.INTEGER(sEXP12).getInt(0 + b6 * 4) == 0) {
              d1 = Rinternals2.INTEGER(sEXP14).getInt(0 + b6 * 4) * d1;
            } else {
              switch (Rinternals2.INTEGER(paramSEXP3).getInt(0 + (i1 * j + b6) * 4)) {
                case 1:
                  d1 = Rinternals.Rf_ncols(Rinternals.VECTOR_ELT(sEXP10, b6)) * d1;
                  break;
                case 2:
                  d1 = Rinternals.Rf_ncols(Rinternals.VECTOR_ELT(sEXP13, b6)) * d1;
                  break;
              } 
            }  
        } 
        if (d1 > 2.147483647E9D) {
          BytePtr bytePtr = GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("term %d would require %.0g columns\000".getBytes(), 0));
          Object[] arrayOfObject = new Object[2];
          Integer integer = Integer.valueOf(i1 + 1);
          arrayOfObject[0] = integer;
          arrayOfObject[1] = Double.valueOf(d1);
          Error.Rf_error(bytePtr, arrayOfObject);
        } 
        Rinternals2.INTEGER(sEXP3).setInt(0 + i1 * 4, (int)d1);
        d += d1;
      } else {
        Error.Rf_warning(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("the response appeared on the right-hand side and was dropped\000".getBytes(), 0)), new Object[0]);
        Rinternals2.INTEGER(sEXP3).setInt(0 + i1 * 4, 0);
      } 
    } 
    if (d > 2.147483647E9D)
      Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("matrix would require %.0g columns\000".getBytes(), 0)), new Object[] { Double.valueOf(d) }); 
    int m = (int)d;
    SEXP sEXP8 = Rinternals.Rf_allocVector(13, m);
    Rinternals.Rf_protect(sEXP8);
    byte b3 = 0;
    if (n != 0) {
      Rinternals2.INTEGER(sEXP8).setInt(0, 0);
      b3 = 1;
    } 
    byte b2;
    for (b2 = 0; b2 < i; b2++) {
      if (Rinternals2.INTEGER(sEXP3).getInt(0 + b2 * 4) <= 0) {
        Object[] arrayOfObject = new Object[1];
        BytePtr bytePtr = GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("problem with term %d in model.matrix: no columns are assigned\000".getBytes(), 0));
        arrayOfObject[0] = Integer.valueOf(b2 + 1);
        Error.Rf_warning(bytePtr, arrayOfObject);
      } 
      for (byte b6 = 0; Rinternals2.INTEGER(sEXP3).getInt(0 + b2 * 4) > b6; b6++) {
        Rinternals2.INTEGER(sEXP8).setInt(0 + b3 * 4, b2 + 1);
        b3++;
      } 
    } 
    SEXP sEXP4 = Rinternals.Rf_allocVector(16, m);
    Rinternals.Rf_protect(sEXP4);
    b2 = 0;
    if (n != 0) {
      b2 = 1;
      Rinternals.SET_STRING_ELT(sEXP4, 0, Rinternals.Rf_mkChar((Ptr)new BytePtr("(Intercept)\000".getBytes(), 0)));
    } 
    byte b5;
    for (b5 = 0; b5 < i; b5++) {
      if (b5 != b)
        for (byte b6 = 0; Rinternals2.INTEGER(sEXP3).getInt(0 + b5 * 4) > b6; b6++) {
          boolean bool = true;
          int i3 = b6;
          BytePtr bytePtr = new BytePtr(arrayOfByte, 0);
          for (byte b7 = 0; b7 < j; b7++) {
            int i4 = Rinternals2.INTEGER(paramSEXP3).getInt(0 + (b5 * j + b7) * 4);
            if (i4 != 0) {
              Ptr ptr1;
              SEXP sEXP = Rinternals.VECTOR_ELT(sEXP11, b7);
              if (!bool)
                ptr1 = AppendString(bytePtr.pointerPlus(0), (Ptr)new BytePtr(":\000".getBytes(), 0)); 
              bool = false;
              if (!Rinternals.Rf_isFactor(sEXP) && Rinternals.TYPEOF(sEXP) != 10) {
                if (Rinternals.TYPEOF(sEXP) == 15)
                  Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("complex variables are not currently allowed in model matrices\000".getBytes(), 0)), new Object[0]); 
                if (!Rinternals.Rf_isNumeric(sEXP)) {
                  BytePtr bytePtr1 = Rinternals.Rf_type2char(Rinternals.TYPEOF(sEXP));
                  Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("variables of type '%s' are not allowed in model matrices\000".getBytes(), 0)), new Object[] { bytePtr1 });
                } else {
                  SEXP sEXP15 = ColumnNames(sEXP);
                  i4 = Rinternals.Rf_ncols(sEXP);
                  BytePtr bytePtr1 = Rinternals.Rf_translateChar(Rinternals.STRING_ELT(sEXP9, b7));
                  if (Integer.compareUnsigned(Stdlib.strlen((Ptr)new BytePtr(arrayOfByte, 0)) + Stdlib.strlen(bytePtr1.pointerPlus(0)), 4095) > 0) {
                    Error.Rf_warning(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("term names will be truncated\000".getBytes(), 0)), new Object[0]);
                  } else {
                    ptr1 = AppendString(ptr1.pointerPlus(0), bytePtr1.pointerPlus(0));
                  } 
                  if (i4 > 1)
                    if (sEXP15 != Rinternals.R_NilValue) {
                      BytePtr bytePtr2 = Rinternals.Rf_translateChar(Rinternals.STRING_ELT(sEXP15, i3 % i4));
                      if (Integer.compareUnsigned(Stdlib.strlen((Ptr)new BytePtr(arrayOfByte, 0)) + Stdlib.strlen(bytePtr2.pointerPlus(0)), 4095) > 0) {
                        Error.Rf_warning(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("term names will be truncated\000".getBytes(), 0)), new Object[0]);
                      } else {
                        ptr1 = AppendString(ptr1.pointerPlus(0), bytePtr2.pointerPlus(0));
                      } 
                    } else if (Integer.compareUnsigned(Stdlib.strlen((Ptr)new BytePtr(arrayOfByte, 0)) + 10, 4095) > 0) {
                      Error.Rf_warning(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("term names will be truncated\000".getBytes(), 0)), new Object[0]);
                    } else {
                      ptr1 = AppendInteger(ptr1.pointerPlus(0), i3 % i4 + 1);
                    }  
                } 
              } else {
                SEXP sEXP15;
                if (i4 != 1) {
                  sEXP15 = ColumnNames(Rinternals.VECTOR_ELT(sEXP13, b7));
                  i4 = Rinternals.Rf_ncols(Rinternals.VECTOR_ELT(sEXP13, b7));
                } else {
                  sEXP15 = ColumnNames(Rinternals.VECTOR_ELT(sEXP10, b7));
                  i4 = Rinternals.Rf_ncols(Rinternals.VECTOR_ELT(sEXP10, b7));
                } 
                BytePtr bytePtr1 = Rinternals.Rf_translateChar(Rinternals.STRING_ELT(sEXP9, b7));
                if (Integer.compareUnsigned(Stdlib.strlen((Ptr)new BytePtr(arrayOfByte, 0)) + Stdlib.strlen(bytePtr1.pointerPlus(0)), 4095) > 0) {
                  Error.Rf_warning(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("term names will be truncated\000".getBytes(), 0)), new Object[0]);
                } else {
                  ptr1 = AppendString(ptr1.pointerPlus(0), bytePtr1.pointerPlus(0));
                } 
                if (sEXP15 != Rinternals.R_NilValue) {
                  BytePtr bytePtr2 = Rinternals.Rf_translateChar(Rinternals.STRING_ELT(sEXP15, i3 % i4));
                  if (Integer.compareUnsigned(Stdlib.strlen((Ptr)new BytePtr(arrayOfByte, 0)) + Stdlib.strlen(bytePtr2.pointerPlus(0)), 4095) > 0) {
                    Error.Rf_warning(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("term names will be truncated\000".getBytes(), 0)), new Object[0]);
                  } else {
                    ptr1 = AppendString(ptr1.pointerPlus(0), bytePtr2.pointerPlus(0));
                  } 
                } else if (Integer.compareUnsigned(Stdlib.strlen((Ptr)new BytePtr(arrayOfByte, 0)) + 10, 4095) > 0) {
                  Error.Rf_warning(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("term names will be truncated\000".getBytes(), 0)), new Object[0]);
                } else {
                  ptr1 = AppendInteger(ptr1.pointerPlus(0), i3 % i4 + 1);
                } 
              } 
              i3 /= i4;
            } 
          } 
          Rinternals.SET_STRING_ELT(sEXP4, b2++, Rinternals.Rf_mkChar((Ptr)new BytePtr(arrayOfByte, 0)));
        }  
    } 
    SEXP sEXP2 = Rinternals.Rf_allocMatrix(14, i2, m);
    Rinternals.Rf_protect(sEXP2);
    Ptr ptr = Rinternals2.REAL(sEXP2);
    int k = n;
    m = n;
    if (n != 0)
      for (n = 0; n < i2; n++)
        ptr.setDouble(0 + n * 8, 1.0D);  
    SEXP sEXP7 = Rinternals.R_NilValue;
    for (b2 = 0; b2 < i; b2++) {
      if (b2 != b) {
        for (b5 = 0; b5 < j; b5++) {
          if (Rinternals2.INTEGER(sEXP14).getInt(0 + b5 * 4) != 0) {
            SEXP sEXP = Rinternals.VECTOR_ELT(sEXP11, b5);
            int i3 = Rinternals2.INTEGER(paramSEXP3).getInt(0 + (b2 * j + b5) * 4);
            if (i3 != 0) {
              Ptr ptr1;
              switch (i3) {
                case 1:
                  sEXP7 = Rinternals.Rf_coerceVector(Rinternals.VECTOR_ELT(sEXP10, b5), 14);
                  break;
                case 2:
                  sEXP7 = Rinternals.Rf_coerceVector(Rinternals.VECTOR_ELT(sEXP13, b5), 14);
                  break;
              } 
              Rinternals.Rf_protect(sEXP7);
              if (m != k) {
                if (Rinternals2.INTEGER(sEXP12).getInt(0 + b5 * 4) <= 0) {
                  int i4 = Rinternals.Rf_ncols(sEXP);
                  Ptr ptr2 = Rinternals2.REAL(sEXP);
                  addvar(ptr.pointerPlus(0 + k * i2 * 8), i2, m - k, ptr2, i2, i4);
                  m = (m - k) * (Rinternals.Rf_ncols(sEXP) + -1) + m;
                } else {
                  if (Rinternals.TYPEOF(sEXP) != 10) {
                    i3 = 0;
                  } else {
                    i3 = 1;
                  } 
                  int i4 = Rinternals.Rf_ncols(sEXP7);
                  i3 = Rinternals.Rf_nrows(sEXP7);
                  ptr1 = Rinternals2.REAL(sEXP7);
                  Ptr ptr2 = ptr.pointerPlus(0 + k * i2 * 8);
                  Ptr ptr3 = Rinternals2.INTEGER(sEXP).pointerPlus(0 + i3 * 4);
                  addfactor(ptr2, i2, m - k, ptr1, i3, i4, ptr3);
                  m = (m - k) * (Rinternals.Rf_ncols(sEXP7) + -1) + m;
                } 
              } else if (Rinternals2.INTEGER(sEXP12).getInt(0 + b5 * 4) <= 0) {
                int i4 = Rinternals.Rf_ncols((SEXP)ptr1);
                Ptr ptr2 = Rinternals2.REAL((SEXP)ptr1);
                firstvar(ptr.pointerPlus(0 + k * i2 * 8), i2, m - k, ptr2, i2, i4);
                m = Rinternals.Rf_ncols((SEXP)ptr1) + m;
              } else {
                if (Rinternals.TYPEOF((SEXP)ptr1) != 10) {
                  i3 = 0;
                } else {
                  i3 = 1;
                } 
                int i4 = Rinternals.Rf_ncols(sEXP7);
                i3 = Rinternals.Rf_nrows(sEXP7);
                ptr1 = Rinternals2.REAL(sEXP7);
                Ptr ptr2 = ptr.pointerPlus(0 + k * i2 * 8);
                Ptr ptr3 = Rinternals2.INTEGER((SEXP)ptr1).pointerPlus(0 + i3 * 4);
                firstfactor(ptr2, i2, m - k, ptr1, i3, i4, ptr3);
                m = Rinternals.Rf_ncols(sEXP7) + m;
              } 
            } 
          } 
        } 
        k = m;
      } 
    } 
    SEXP sEXP1 = Rinternals.Rf_allocVector(19, 2);
    Rinternals.Rf_protect(sEXP1);
    Rinternals.SET_VECTOR_ELT(sEXP1, 0, sEXP6);
    Rinternals.SET_VECTOR_ELT(sEXP1, 1, sEXP4);
    Rinternals.Rf_setAttrib(sEXP2, Rinternals.R_DimNamesSymbol, sEXP1);
    Rinternals.Rf_setAttrib(sEXP2, Rinternals.Rf_install(new BytePtr("assign\000".getBytes(), 0)), sEXP8);
    return sEXP2;
  }
  
  public static SEXP termsform(SEXP paramSEXP) {
    boolean bool2;
    SEXP sEXP8;
    int[] arrayOfInt = new int[1];
    BytePtr.of(0);
    BytePtr.of(0);
    arrayOfInt[0] = 0;
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    SEXP sEXP5 = (SEXP)BytePtr.of(0).getArray();
    sEXP5 = (SEXP)BytePtr.of(0).getArray();
    sEXP5 = (SEXP)BytePtr.of(0).getArray();
    sEXP5 = (SEXP)BytePtr.of(0).getArray();
    sEXP5 = (SEXP)BytePtr.of(0).getArray();
    sEXP5 = (SEXP)BytePtr.of(0).getArray();
    sEXP5 = (SEXP)BytePtr.of(0).getArray();
    sEXP5 = (SEXP)BytePtr.of(0).getArray();
    sEXP5 = (SEXP)BytePtr.of(0).getArray();
    sEXP5 = (SEXP)BytePtr.of(0).getArray();
    sEXP5 = (SEXP)BytePtr.of(0).getArray();
    sEXP5 = (SEXP)BytePtr.of(0).getArray();
    sEXP5 = (SEXP)BytePtr.of(0).getArray();
    sEXP5 = (SEXP)BytePtr.of(0).getArray();
    BytePtr.of(0);
    boolean bool1 = false;
    SEXP sEXP6 = Rinternals.CDR(paramSEXP);
    tildeSymbol = Rinternals.Rf_install(new BytePtr("~\000".getBytes(), 0));
    plusSymbol = Rinternals.Rf_install(new BytePtr("+\000".getBytes(), 0));
    minusSymbol = Rinternals.Rf_install(new BytePtr("-\000".getBytes(), 0));
    timesSymbol = Rinternals.Rf_install(new BytePtr("*\000".getBytes(), 0));
    slashSymbol = Rinternals.Rf_install(new BytePtr("/\000".getBytes(), 0));
    colonSymbol = Rinternals.Rf_install(new BytePtr(":\000".getBytes(), 0));
    powerSymbol = Rinternals.Rf_install(new BytePtr("^\000".getBytes(), 0));
    dotSymbol = Rinternals.Rf_install(new BytePtr(".\000".getBytes(), 0));
    parenSymbol = Rinternals.Rf_install(new BytePtr("(\000".getBytes(), 0));
    inSymbol = Rinternals.Rf_install(new BytePtr("%in%\000".getBytes(), 0));
    if (!Rinternals.Rf_isLanguage(Rinternals.CAR(sEXP6)) || Rinternals.CAR(Rinternals.CAR(sEXP6)) != tildeSymbol || (Rinternals.Rf_length(Rinternals.CAR(sEXP6)) != 2 && Rinternals.Rf_length(Rinternals.CAR(sEXP6)) != 3))
      Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("argument is not a valid model\000".getBytes(), 0)), new Object[0]); 
    haveDot = 0;
    paramSEXP = Rinternals.Rf_duplicate(Rinternals.CAR(sEXP6));
    Rinternals.Rf_protect(paramSEXP);
    SEXP sEXP7 = Rinternals.CADR(sEXP6);
    if (Rinternals.Rf_length(sEXP7) != 0 && Rinternals.TYPEOF(sEXP7) != 16)
      Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("'specials' must be NULL or a character vector\000".getBytes(), 0)), new Object[0]); 
    SEXP sEXP2 = Rinternals.CAR(Rinternals.CDDR(sEXP6));
    sEXP5 = Rinternals.CDR(Rinternals.CDDR(sEXP6));
    if (Rinternals.TYPEOF(sEXP2) != 0 && Rinternals.TYPEOF(sEXP2) != 4) {
      if (!Rinternals.Rf_isFrame(sEXP2)) {
        Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("'data' argument is of the wrong type\000".getBytes(), 0)), new Object[0]);
      } else {
        framenames = Rinternals.Rf_getAttrib(sEXP2, Rinternals.R_NamesSymbol);
      } 
    } else {
      framenames = Rinternals.R_NilValue;
    } 
    sEXP2 = framenames;
    if (framenames != Rinternals.R_NilValue) {
      if (Rinternals.Rf_length(framenames) != 0)
        bool1 = true; 
      if (Rinternals.Rf_length(Rinternals.CAR(sEXP6)) == 3)
        CheckRHS(Rinternals.CADR(Rinternals.CAR(sEXP6))); 
    } 
    int j = Rinternals.Rf_asLogical(Rinternals.CAR(sEXP5));
    if (j == Arith.R_NaInt)
      j = 0; 
    int i = Rinternals.Rf_asLogical(Rinternals.CAR(Rinternals.CDR(sEXP5)));
    if (i == Arith.R_NaInt)
      i = 0; 
    if (sEXP7 != Rinternals.R_NilValue) {
      sEXP5 = Rinternals.Rf_allocList(9);
    } else {
      sEXP5 = Rinternals.Rf_allocList(8);
    } 
    intercept = 1;
    parity = 1;
    response = 0;
    SEXP sEXP4 = Rinternals.R_NilValue;
    varlist = Rinternals.Rf_lcons(Rinternals.Rf_install(new BytePtr("list\000".getBytes(), 0)), sEXP4);
    Rinternals.Rf_protect(varlist);
    ExtractVars(Rinternals.CAR(sEXP6), 1);
    Rinternals.SETCAR(sEXP5, varlist);
    Rinternals.SET_TAG(sEXP5, Rinternals.Rf_install(new BytePtr("variables\000".getBytes(), 0)));
    SEXP sEXP9 = Rinternals.CDR(sEXP5);
    nvar = Rinternals.Rf_length(varlist) + -1;
    nwords = Integer.divideUnsigned(nvar, 32) + 1;
    sEXP6 = EncodeVars(Rinternals.CAR(sEXP6));
    Rinternals.Rf_protect(sEXP6);
    nvar = Rinternals.Rf_length(varlist) + -1;
    sEXP4 = Rinternals.Rf_allocVector(16, nvar);
    Rinternals.Rf_protect(sEXP4);
    SEXP sEXP11 = Rinternals.CDR(varlist);
    byte b2 = 0;
    while (sEXP11 != Rinternals.R_NilValue) {
      Rinternals.SET_STRING_ELT(sEXP4, b2++, Rinternals.STRING_ELT(Defn.Rf_deparse1line(Rinternals.CAR(sEXP11), false), 0));
      sEXP11 = Rinternals.CDR(sEXP11);
    } 
    int k = response;
    b2 = 0;
    while (k < nvar) {
      if (Stdlib.strncmp((Ptr)Rinternals.R_CHAR(Rinternals.STRING_ELT(sEXP4, k)), (Ptr)new BytePtr("offset(\000".getBytes(), 0), 7) == 0)
        b2++; 
      k++;
    } 
    if (b2 > 0) {
      k = 0;
      SEXP sEXP = Rinternals.Rf_allocVector(13, b2);
      Rinternals.SETCAR(sEXP9, sEXP);
      int i1 = response;
      byte b = 0;
      while (i1 < nvar) {
        if (Stdlib.strncmp((Ptr)Rinternals.R_CHAR(Rinternals.STRING_ELT(sEXP4, i1)), (Ptr)new BytePtr("offset(\000".getBytes(), 0), 7) == 0) {
          Rinternals2.INTEGER(sEXP).setInt(0 + b * 4, i1 + 1);
          b++;
        } 
        i1++;
      } 
      Rinternals.SET_TAG(sEXP9, Rinternals.Rf_install(new BytePtr("offset\000".getBytes(), 0)));
      sEXP9 = Rinternals.CDR(sEXP9);
      sEXP = sEXP6;
      while (true) {
        SEXP sEXP16;
        if (k == 0) {
          sEXP16 = sEXP;
        } else {
          sEXP16 = Rinternals.CDR(sEXP);
        } 
        SEXP sEXP17 = sEXP16;
        b = 0;
        if (Rinternals.Rf_length(sEXP16) != 0) {
          byte b5 = 1;
          while (b5 <= nvar) {
            if (GetBit(Rinternals.CAR(sEXP17), b5) == 0 || Stdlib.strncmp((Ptr)Rinternals.R_CHAR(Rinternals.STRING_ELT(sEXP4, b5 + -1)), (Ptr)new BytePtr("offset(\000".getBytes(), 0), 7) != 0) {
              b5++;
              continue;
            } 
            b = 1;
            break;
          } 
          if (b == 0) {
            if (k != 0)
              sEXP = Rinternals.CDR(sEXP); 
            k = 1;
            continue;
          } 
          if (k != 0) {
            Rinternals.SETCDR(sEXP, Rinternals.CDR(sEXP17));
            continue;
          } 
          sEXP6 = Rinternals.CDR(sEXP6);
          sEXP = sEXP6;
          continue;
        } 
        break;
      } 
    } 
    nterm = Rinternals.Rf_length(sEXP6);
    SEXP sEXP10 = Rinternals.Rf_allocVector(13, nterm);
    Rinternals.Rf_protect(sEXP10);
    int m = 0;
    Ptr ptr3 = Rinternals2.INTEGER(sEXP10);
    SEXP sEXP3 = Rinternals.Rf_allocVector(19, nterm);
    Rinternals.Rf_protect(sEXP3);
    Rinternals.Rf_protect(Rinternals.Rf_allocVector(13, nterm));
    Ptr ptr4 = Rinternals2.INTEGER(Rinternals.Rf_allocVector(13, nterm));
    SEXP sEXP15 = sEXP6;
    byte b4;
    for (b4 = 0; sEXP15 != Rinternals.R_NilValue; b4++) {
      Rinternals.SET_VECTOR_ELT(sEXP3, b4, Rinternals.CAR(sEXP15));
      ptr4.setInt(0 + b4 * 4, BitCount(Rinternals.CAR(sEXP15)));
      sEXP15 = Rinternals.CDR(sEXP15);
    } 
    int n;
    for (n = 0; n < nterm; n++) {
      if (ptr4.getInt(0 + n * 4) > m)
        m = ptr4.getInt(0 + n * 4); 
    } 
    if (j == 0) {
      sEXP8 = sEXP6;
      n = 0;
      for (b4 = 0; b4 <= m; b4++) {
        for (byte b = 0; b < nterm; b++) {
          if (ptr4.getInt(0 + b * 4) == b4) {
            Rinternals.SETCAR(sEXP8, Rinternals.VECTOR_ELT(sEXP3, b));
            sEXP8 = Rinternals.CDR(sEXP8);
            ptr3.setInt(0 + n * 4, b4);
            n++;
          } 
        } 
      } 
    } else {
      for (j = 0; j < nterm; j++)
        ptr3.setInt(0 + j * 4, ptr4.getInt(0 + j * 4)); 
    } 
    if (nterm <= 0) {
      sEXP8 = Rinternals.Rf_allocVector(13, 0);
      Rinternals.SETCAR(sEXP9, sEXP8);
      Rinternals.SET_TAG(sEXP9, Rinternals.Rf_install(new BytePtr("factors\000".getBytes(), 0)));
      sEXP9 = Rinternals.CDR(sEXP9);
    } else {
      sEXP8 = Rinternals.Rf_allocMatrix(13, nvar, nterm);
      Rinternals.SETCAR(sEXP9, sEXP8);
      Rinternals.SET_TAG(sEXP9, Rinternals.Rf_install(new BytePtr("factors\000".getBytes(), 0)));
      sEXP9 = Rinternals.CDR(sEXP9);
      for (byte b5 = 0; nterm * nvar > b5; b5++)
        Rinternals2.INTEGER(sEXP8).setInt(0 + b5 * 4, 0); 
      SEXP sEXP16 = AllocTerm();
      Rinternals.Rf_protect(sEXP16);
      byte b6 = 0;
      for (SEXP sEXP17 = sEXP6; sEXP17 != Rinternals.R_NilValue; sEXP17 = Rinternals.CDR(sEXP17)) {
        for (byte b = 1; b <= nvar; b++) {
          if (GetBit(Rinternals.CAR(sEXP17), b) != 0)
            Rinternals2.INTEGER(sEXP8).setInt(0 + (b + -1 + b6 * nvar) * 4, TermCode(sEXP6, sEXP17, b, sEXP16)); 
        } 
        b6++;
      } 
    } 
    SEXP sEXP12 = Rinternals.Rf_allocVector(16, nterm);
    Rinternals.Rf_protect(sEXP12);
    byte b3 = 0;
    SEXP sEXP14;
    for (sEXP14 = sEXP6; sEXP14 != Rinternals.R_NilValue; sEXP14 = Rinternals.CDR(sEXP14)) {
      int i1 = 0;
      for (n = 1; n <= nvar; n++) {
        if (GetBit(Rinternals.CAR(sEXP14), n) != 0) {
          if (!i1)
            i1++; 
          i1 = Stdlib.strlen((Ptr)Rinternals.R_CHAR(Rinternals.STRING_ELT(sEXP4, n + -1))) + i1;
        } 
      } 
      Integer.toUnsignedLong(++i1);
      Integer.toUnsignedLong(i1);
      BytePtr bytePtr = BytePtr.malloc(i1);
      bytePtr.setByte(0, (byte)0);
      b4 = 0;
      for (byte b = 1; b <= nvar; b++) {
        if (GetBit(Rinternals.CAR(sEXP14), b) != 0) {
          if (b4 > 0)
            bytePtr.pointerPlus(0 + Stdlib.strlen(bytePtr.pointerPlus(0))).memcpy((Ptr)new BytePtr(":\000".getBytes(), 0), 2); 
          BytePtr bytePtr1 = Rinternals.R_CHAR(Rinternals.STRING_ELT(sEXP4, b + -1));
          Stdlib.strcat(bytePtr.pointerPlus(0), (Ptr)bytePtr1);
          b4++;
        } 
      } 
      Rinternals.SET_STRING_ELT(sEXP12, b3, Rinternals.Rf_mkChar(bytePtr.pointerPlus(0)));
      b3++;
    } 
    SEXP sEXP13 = Rinternals.Rf_allocVector(19, 2);
    Rinternals.Rf_protect(sEXP13);
    Rinternals.SET_VECTOR_ELT(sEXP13, 0, sEXP4);
    Rinternals.SET_VECTOR_ELT(sEXP13, 1, sEXP12);
    if (nterm > 0)
      Rinternals.Rf_setAttrib(sEXP8, Rinternals.R_DimNamesSymbol, sEXP13); 
    Rinternals.SETCAR(sEXP9, sEXP12);
    Rinternals.SET_TAG(sEXP9, Rinternals.Rf_install(new BytePtr("term.labels\000".getBytes(), 0)));
    sEXP9 = Rinternals.CDR(sEXP9);
    if (sEXP7 != Rinternals.R_NilValue) {
      VoidPtr.toPtr(Memory.vmaxget());
      int i1 = Rinternals.Rf_length(sEXP7);
      sEXP12 = Rinternals.Rf_allocList(i1);
      Rinternals.Rf_protect(sEXP12);
      byte b = 0;
      for (sEXP14 = sEXP12; b < i1; sEXP14 = Rinternals.CDR(sEXP14)) {
        BytePtr bytePtr = Rinternals.Rf_translateChar(Rinternals.STRING_ELT(sEXP7, b));
        Rinternals.SET_TAG(sEXP14, Rinternals.Rf_install((BytePtr)bytePtr.pointerPlus(0)));
        n = Stdlib.strlen(bytePtr.pointerPlus(0));
        Rinternals.SETCAR(sEXP14, Rinternals.Rf_allocVector(13, 0));
        b4 = 0;
        byte b5;
        for (b5 = 0; b5 < nvar; b5++) {
          if (Stdlib.strncmp((Ptr)Rinternals.R_CHAR(Rinternals.STRING_ELT(sEXP4, b5)), bytePtr.pointerPlus(0), n) == 0 && Rinternals.R_CHAR(Rinternals.STRING_ELT(sEXP4, b5)).getByte(0 + n) == (byte)40)
            b4++; 
        } 
        if (b4 <= 0) {
          Rinternals.SETCAR(sEXP14, Rinternals.R_NilValue);
        } else {
          Rinternals.SETCAR(sEXP14, Rinternals.Rf_allocVector(13, b4));
          b4 = 0;
          for (b5 = 0; b5 < nvar; b5++) {
            if (Stdlib.strncmp((Ptr)Rinternals.R_CHAR(Rinternals.STRING_ELT(sEXP4, b5)), bytePtr.pointerPlus(0), n) == 0 && Rinternals.R_CHAR(Rinternals.STRING_ELT(sEXP4, b5)).getByte(0 + n) == (byte)40) {
              Rinternals2.INTEGER(Rinternals.CAR(sEXP14)).setInt(0 + b4 * 4, b5 + 1);
              b4++;
            } 
          } 
        } 
        b++;
      } 
      Rinternals.SETCAR(sEXP9, sEXP12);
      Rinternals.SET_TAG(sEXP9, Rinternals.Rf_install(new BytePtr("specials\000".getBytes(), 0)));
      sEXP9 = Rinternals.CDR(sEXP9);
    } 
    if (haveDot != 0)
      if (Rinternals.Rf_length(framenames) == 0) {
        if (i == 0 && !bool1)
          Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("'.' in formula and no 'data' argument\000".getBytes(), 0)), new Object[0]); 
      } else {
        SEXP sEXP = Defn.Rf_installTrChar(Rinternals.STRING_ELT(framenames, 0));
        for (byte b = 1; Rinternals.LENGTH(framenames) > b; b++) {
          i = arrayOfInt[0];
          SEXP sEXP16 = Defn.Rf_installTrChar(Rinternals.STRING_ELT(framenames, b));
          sEXP = Rinternals.Rf_lang3(plusSymbol, sEXP, sEXP16);
        } 
        if (Rinternals.TYPEOF(Rinternals.CADDR(paramSEXP)) == 0) {
          Rinternals.SETCADR(paramSEXP, ExpandDots(Rinternals.CADR(paramSEXP), sEXP));
        } else {
          Rinternals.SETCADDR(paramSEXP, ExpandDots(Rinternals.CADDR(paramSEXP), sEXP));
        } 
      }  
    Rinternals.SETCAR(sEXP9, Rinternals.Rf_allocVector(13, nterm));
    byte b1 = 0;
    Ptr ptr1 = Rinternals2.INTEGER(Rinternals.CAR(sEXP9));
    Ptr ptr2 = Rinternals2.INTEGER(sEXP10);
    sEXP6 = sEXP6;
    while (sEXP6 != Rinternals.R_NilValue) {
      ptr1.setInt(0 + b1 * 4, ptr2.getInt(0 + b1 * 4));
      sEXP6 = Rinternals.CDR(sEXP6);
      b1++;
    } 
    Rinternals.SET_TAG(sEXP9, Rinternals.Rf_install(new BytePtr("order\000".getBytes(), 0)));
    SEXP sEXP1 = Rinternals.CDR(sEXP9);
    if (intercept == 0) {
      bool2 = false;
    } else {
      bool2 = true;
    } 
    Rinternals.SETCAR(sEXP1, Rinternals.Rf_ScalarInteger(bool2));
    Rinternals.SET_TAG(sEXP1, Rinternals.Rf_install(new BytePtr("intercept\000".getBytes(), 0)));
    sEXP1 = Rinternals.CDR(sEXP1);
    if (response == 0) {
      bool2 = false;
    } else {
      bool2 = true;
    } 
    Rinternals.SETCAR(sEXP1, Rinternals.Rf_ScalarInteger(bool2));
    Rinternals.SET_TAG(sEXP1, Rinternals.Rf_install(new BytePtr("response\000".getBytes(), 0)));
    sEXP1 = Rinternals.CDR(sEXP1);
    Rinternals.SETCAR(sEXP1, Rinternals.Rf_mkString((Ptr)new BytePtr("terms\000".getBytes(), 0)));
    Rinternals.SET_TAG(sEXP1, Rinternals.R_ClassSymbol);
    Rinternals.SET_OBJECT(paramSEXP, 1);
    Rinternals.SETCDR(sEXP1, Rinternals.R_NilValue);
    Rinternals.SET_ATTRIB(paramSEXP, sEXP5);
    return paramSEXP;
  }
  
  public static SEXP updateform(SEXP paramSEXP1, SEXP paramSEXP2) {
    tildeSymbol = Rinternals.Rf_install(new BytePtr("~\000".getBytes(), 0));
    plusSymbol = Rinternals.Rf_install(new BytePtr("+\000".getBytes(), 0));
    minusSymbol = Rinternals.Rf_install(new BytePtr("-\000".getBytes(), 0));
    timesSymbol = Rinternals.Rf_install(new BytePtr("*\000".getBytes(), 0));
    slashSymbol = Rinternals.Rf_install(new BytePtr("/\000".getBytes(), 0));
    colonSymbol = Rinternals.Rf_install(new BytePtr(":\000".getBytes(), 0));
    powerSymbol = Rinternals.Rf_install(new BytePtr("^\000".getBytes(), 0));
    dotSymbol = Rinternals.Rf_install(new BytePtr(".\000".getBytes(), 0));
    parenSymbol = Rinternals.Rf_install(new BytePtr("(\000".getBytes(), 0));
    inSymbol = Rinternals.Rf_install(new BytePtr("%in%\000".getBytes(), 0));
    paramSEXP2 = Rinternals.Rf_duplicate(paramSEXP2);
    Rinternals.Rf_protect(paramSEXP2);
    if (Rinternals.TYPEOF(paramSEXP1) != 6 || (Rinternals.TYPEOF(paramSEXP2) != 6 && Rinternals.CAR(paramSEXP1) != tildeSymbol) || Rinternals.CAR(paramSEXP2) != tildeSymbol)
      Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("formula expected\000".getBytes(), 0)), new Object[0]); 
    if (Rinternals.Rf_length(paramSEXP1) != 3) {
      SEXP sEXP = Rinternals.CADR(paramSEXP1);
      if (Rinternals.Rf_length(paramSEXP2) != 3) {
        Rinternals.SETCADR(paramSEXP2, ExpandDots(Rinternals.CADR(paramSEXP2), sEXP));
        Rinternals.SET_ATTRIB(paramSEXP2, Rinternals.R_NilValue);
        Rinternals.SET_OBJECT(paramSEXP2, 0);
        paramSEXP1 = Rinternals.Rf_install(new BytePtr(".Environment\000".getBytes(), 0));
        sEXP = Rinternals.Rf_getAttrib(paramSEXP1, paramSEXP1);
        Rinternals.Rf_setAttrib(paramSEXP2, paramSEXP1, sEXP);
        return paramSEXP2;
      } 
      Rinternals.SETCADDR(paramSEXP2, ExpandDots(Rinternals.CADDR(paramSEXP2), sEXP));
      Rinternals.SET_ATTRIB(paramSEXP2, Rinternals.R_NilValue);
      Rinternals.SET_OBJECT(paramSEXP2, 0);
      paramSEXP1 = Rinternals.Rf_install(new BytePtr(".Environment\000".getBytes(), 0));
      sEXP = Rinternals.Rf_getAttrib(paramSEXP1, paramSEXP1);
      Rinternals.Rf_setAttrib(paramSEXP2, paramSEXP1, sEXP);
      return paramSEXP2;
    } 
    SEXP sEXP2 = Rinternals.CADR(paramSEXP1);
    SEXP sEXP1 = Rinternals.CADDR(paramSEXP1);
    if (Rinternals.Rf_length(paramSEXP2) == 2)
      Rinternals.SETCDR(paramSEXP2, Rinternals.Rf_cons(sEXP2, Rinternals.CDR(paramSEXP2))); 
    Rinternals.Rf_protect(sEXP1);
    Rinternals.SETCADR(paramSEXP2, ExpandDots(Rinternals.CADR(paramSEXP2), sEXP2));
    Rinternals.SETCADDR(paramSEXP2, ExpandDots(Rinternals.CADDR(paramSEXP2), sEXP1));
    Rinternals.SET_ATTRIB(paramSEXP2, Rinternals.R_NilValue);
    Rinternals.SET_OBJECT(paramSEXP2, 0);
    paramSEXP1 = Rinternals.Rf_install(new BytePtr(".Environment\000".getBytes(), 0));
    sEXP1 = Rinternals.Rf_getAttrib(paramSEXP1, paramSEXP1);
    Rinternals.Rf_setAttrib(paramSEXP2, paramSEXP1, sEXP1);
    return paramSEXP2;
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/stats-0.9.2724.jar!/org/renjin/stats/model__.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */