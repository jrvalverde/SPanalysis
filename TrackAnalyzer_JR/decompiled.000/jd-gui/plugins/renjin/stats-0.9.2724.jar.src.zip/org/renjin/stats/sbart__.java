package org.renjin.stats;

import org.renjin.gcc.runtime.Ptr;

public class sbart__ {
  public static double c_Gold$5835 = 0.38196601125010515D;
  
  public static double ratio$5836 = 0.0D;
  
  public static double $sbart_$ratio = 0.0D;
  
  public static double $sbart_$c_Gold = 0.38196601125010515D;
  
  public static void sbart_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, Ptr paramPtr11, Ptr paramPtr12, Ptr paramPtr13, Ptr paramPtr14, Ptr paramPtr15, Ptr paramPtr16, Ptr paramPtr17, Ptr paramPtr18, Ptr paramPtr19, Ptr paramPtr20, Ptr paramPtr21, Ptr paramPtr22, Ptr paramPtr23, Ptr paramPtr24, Ptr paramPtr25, Ptr paramPtr26, Ptr paramPtr27, Ptr paramPtr28, Ptr paramPtr29, Ptr paramPtr30, Ptr paramPtr31, Ptr paramPtr32, Ptr paramPtr33, Ptr paramPtr34, Ptr paramPtr35, Ptr paramPtr36, Ptr paramPtr37, Ptr paramPtr38) {
    // Byte code:
    //   0: iconst_0
    //   1: istore #52
    //   3: aload #15
    //   5: invokeinterface getInt : ()I
    //   10: iflt -> 19
    //   13: iconst_0
    //   14: istore #54
    //   16: goto -> 22
    //   19: iconst_1
    //   20: istore #54
    //   22: iload #54
    //   24: istore #54
    //   26: iconst_0
    //   27: istore #55
    //   29: dconst_0
    //   30: dstore #46
    //   32: dconst_1
    //   33: putstatic org/renjin/stats/sbart__.$sbart_$ratio : D
    //   36: iconst_0
    //   37: istore #53
    //   39: goto -> 92
    //   42: aload #4
    //   44: iload #53
    //   46: bipush #8
    //   48: imul
    //   49: invokeinterface getDouble : (I)D
    //   54: dconst_0
    //   55: dcmpl
    //   56: ifgt -> 62
    //   59: goto -> 89
    //   62: aload #4
    //   64: iload #53
    //   66: bipush #8
    //   68: imul
    //   69: aload #4
    //   71: iload #53
    //   73: bipush #8
    //   75: imul
    //   76: invokeinterface getDouble : (I)D
    //   81: invokestatic sqrt : (D)D
    //   84: invokeinterface setDouble : (ID)V
    //   89: iinc #53, 1
    //   92: aload #6
    //   94: invokeinterface getInt : ()I
    //   99: iload #53
    //   101: if_icmpgt -> 42
    //   104: aload #22
    //   106: invokeinterface getInt : ()I
    //   111: iflt -> 117
    //   114: goto -> 123
    //   117: iconst_1
    //   118: istore #55
    //   120: goto -> 287
    //   123: aload #22
    //   125: invokeinterface getInt : ()I
    //   130: iconst_1
    //   131: if_icmpne -> 137
    //   134: goto -> 287
    //   137: aload #28
    //   139: aload #29
    //   141: aload #30
    //   143: aload #31
    //   145: aload #7
    //   147: aload #8
    //   149: invokestatic sgram_ : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)V
    //   152: aload_2
    //   153: aload_3
    //   154: aload #4
    //   156: aload #6
    //   158: aload #7
    //   160: aload #8
    //   162: aload #23
    //   164: aload #24
    //   166: aload #25
    //   168: aload #26
    //   170: aload #27
    //   172: invokestatic stxwx_ : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)V
    //   175: aload #22
    //   177: invokeinterface getInt : ()I
    //   182: iconst_2
    //   183: if_icmpeq -> 192
    //   186: iconst_0
    //   187: istore #53
    //   189: goto -> 195
    //   192: iconst_1
    //   193: istore #53
    //   195: iload #53
    //   197: istore #55
    //   199: iload #53
    //   201: ifeq -> 207
    //   204: goto -> 279
    //   207: dconst_0
    //   208: dstore #56
    //   210: dconst_0
    //   211: dstore #58
    //   213: iconst_2
    //   214: istore #53
    //   216: goto -> 256
    //   219: aload #24
    //   221: iload #53
    //   223: bipush #8
    //   225: imul
    //   226: invokeinterface getDouble : (I)D
    //   231: dload #56
    //   233: dadd
    //   234: dstore #56
    //   236: aload #28
    //   238: iload #53
    //   240: bipush #8
    //   242: imul
    //   243: invokeinterface getDouble : (I)D
    //   248: dload #58
    //   250: dadd
    //   251: dstore #58
    //   253: iinc #53, 1
    //   256: aload #8
    //   258: invokeinterface getInt : ()I
    //   263: bipush #-3
    //   265: iadd
    //   266: iload #53
    //   268: if_icmpgt -> 219
    //   271: dload #56
    //   273: dload #58
    //   275: ddiv
    //   276: putstatic org/renjin/stats/sbart__.$sbart_$ratio : D
    //   279: aload #22
    //   281: iconst_1
    //   282: invokeinterface setInt : (I)V
    //   287: aload #15
    //   289: invokeinterface getInt : ()I
    //   294: iconst_1
    //   295: if_icmpeq -> 301
    //   298: goto -> 429
    //   301: iload #55
    //   303: ifne -> 309
    //   306: goto -> 321
    //   309: aload #14
    //   311: invokeinterface getDouble : ()D
    //   316: dstore #46
    //   318: goto -> 348
    //   321: ldc2_w 16.0
    //   324: aload #14
    //   326: invokeinterface getDouble : ()D
    //   331: ldc2_w 6.0
    //   334: dmul
    //   335: ldc2_w 2.0
    //   338: dsub
    //   339: invokestatic R_pow : (DD)D
    //   342: getstatic org/renjin/stats/sbart__.$sbart_$ratio : D
    //   345: dmul
    //   346: dstore #46
    //   348: aload #17
    //   350: dload #46
    //   352: invokeinterface setDouble : (D)V
    //   357: aload_0
    //   358: aload_1
    //   359: aload_2
    //   360: aload_3
    //   361: aload #4
    //   363: aload #5
    //   365: aload #6
    //   367: aload #7
    //   369: aload #8
    //   371: aload #9
    //   373: aload #10
    //   375: aload #11
    //   377: aload #12
    //   379: aload #13
    //   381: aload #17
    //   383: aload #23
    //   385: aload #24
    //   387: aload #25
    //   389: aload #26
    //   391: aload #27
    //   393: aload #28
    //   395: aload #29
    //   397: aload #30
    //   399: aload #31
    //   401: aload #32
    //   403: aload #33
    //   405: aload #34
    //   407: aload #35
    //   409: aload #36
    //   411: aload #37
    //   413: invokestatic sslvrg_ : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)V
    //   416: aload #21
    //   418: getstatic org/renjin/stats/sbart__.$sbart_$ratio : D
    //   421: invokeinterface setDouble : (D)V
    //   426: goto -> 2197
    //   429: aload #17
    //   431: invokeinterface getDouble : ()D
    //   436: dstore #44
    //   438: aload #18
    //   440: invokeinterface getDouble : ()D
    //   445: dup2
    //   446: aload #16
    //   448: invokeinterface getInt : ()I
    //   453: istore #15
    //   455: aload #16
    //   457: iconst_0
    //   458: invokeinterface setInt : (I)V
    //   463: dload #44
    //   465: dstore #56
    //   467: dstore #58
    //   469: dload #44
    //   471: dsub
    //   472: getstatic org/renjin/stats/sbart__.$sbart_$c_Gold : D
    //   475: dmul
    //   476: dload #44
    //   478: dadd
    //   479: dstore #60
    //   481: dload #60
    //   483: dstore #62
    //   485: dload #60
    //   487: dstore #44
    //   489: dconst_0
    //   490: dstore #64
    //   492: iload #55
    //   494: ifeq -> 500
    //   497: goto -> 525
    //   500: ldc2_w 16.0
    //   503: dload #60
    //   505: ldc2_w 6.0
    //   508: dmul
    //   509: ldc2_w 2.0
    //   512: dsub
    //   513: invokestatic R_pow : (DD)D
    //   516: getstatic org/renjin/stats/sbart__.$sbart_$ratio : D
    //   519: dmul
    //   520: dstore #66
    //   522: goto -> 529
    //   525: dload #60
    //   527: dstore #66
    //   529: aload #17
    //   531: dload #66
    //   533: invokeinterface setDouble : (D)V
    //   538: aload_0
    //   539: aload_1
    //   540: aload_2
    //   541: aload_3
    //   542: aload #4
    //   544: aload #5
    //   546: aload #6
    //   548: aload #7
    //   550: aload #8
    //   552: aload #9
    //   554: aload #10
    //   556: aload #11
    //   558: aload #12
    //   560: aload #13
    //   562: aload #17
    //   564: aload #23
    //   566: aload #24
    //   568: aload #25
    //   570: aload #26
    //   572: aload #27
    //   574: aload #28
    //   576: aload #29
    //   578: aload #30
    //   580: aload #31
    //   582: aload #32
    //   584: aload #33
    //   586: aload #34
    //   588: aload #35
    //   590: aload #36
    //   592: aload #37
    //   594: invokestatic sslvrg_ : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)V
    //   597: aload #12
    //   599: invokeinterface getDouble : ()D
    //   604: dstore #66
    //   606: dload #66
    //   608: dstore #68
    //   610: dload #66
    //   612: dstore #70
    //   614: goto -> 2075
    //   617: dload #56
    //   619: dload #58
    //   621: dadd
    //   622: ldc2_w 0.5
    //   625: dmul
    //   626: dstore #42
    //   628: aload #20
    //   630: invokeinterface getDouble : ()D
    //   635: dload #44
    //   637: invokestatic abs : (D)D
    //   640: dmul
    //   641: aload #19
    //   643: invokeinterface getDouble : ()D
    //   648: ldc2_w 3.0
    //   651: ddiv
    //   652: dadd
    //   653: dstore #40
    //   655: dload #40
    //   657: ldc2_w 2.0
    //   660: dmul
    //   661: dstore #38
    //   663: aload #16
    //   665: aload #16
    //   667: invokeinterface getInt : ()I
    //   672: iconst_1
    //   673: iadd
    //   674: invokeinterface setInt : (I)V
    //   679: iload #54
    //   681: ifne -> 687
    //   684: goto -> 1089
    //   687: aload #16
    //   689: invokeinterface getInt : ()I
    //   694: iconst_1
    //   695: if_icmpeq -> 701
    //   698: goto -> 990
    //   701: aload #13
    //   703: invokeinterface getInt : ()I
    //   708: iconst_1
    //   709: if_icmpne -> 715
    //   712: goto -> 805
    //   715: aload #13
    //   717: invokeinterface getInt : ()I
    //   722: iconst_2
    //   723: if_icmpne -> 729
    //   726: goto -> 783
    //   729: aload #13
    //   731: invokeinterface getInt : ()I
    //   736: iconst_3
    //   737: if_icmpeq -> 743
    //   740: goto -> 761
    //   743: new org/renjin/gcc/runtime/BytePtr
    //   746: dup
    //   747: ldc '(df0-df)^2 '
    //   749: invokevirtual getBytes : ()[B
    //   752: iconst_0
    //   753: invokespecial <init> : ([BI)V
    //   756: astore #18
    //   758: goto -> 776
    //   761: new org/renjin/gcc/runtime/BytePtr
    //   764: dup
    //   765: ldc '?f? '
    //   767: invokevirtual getBytes : ()[B
    //   770: iconst_0
    //   771: invokespecial <init> : ([BI)V
    //   774: astore #18
    //   776: aload #18
    //   778: astore #18
    //   780: goto -> 798
    //   783: new org/renjin/gcc/runtime/BytePtr
    //   786: dup
    //   787: ldc 'CV '
    //   789: invokevirtual getBytes : ()[B
    //   792: iconst_0
    //   793: invokespecial <init> : ([BI)V
    //   796: astore #18
    //   798: aload #18
    //   800: astore #53
    //   802: goto -> 820
    //   805: new org/renjin/gcc/runtime/BytePtr
    //   808: dup
    //   809: ldc 'GCV '
    //   811: invokevirtual getBytes : ()[B
    //   814: iconst_0
    //   815: invokespecial <init> : ([BI)V
    //   818: astore #53
    //   820: getstatic org/renjin/stats/sbart__.$sbart_$ratio : D
    //   823: new org/renjin/gcc/runtime/BytePtr
    //   826: astore #18
    //   828: aload #18
    //   830: ldc 'sbart (ratio = %15.8g) iterations; initial tol1 = %12.6e :\\n%11s %14s  %9s %11s  Kind %11s %12s\\n%s\\n '
    //   832: invokevirtual getBytes : ()[B
    //   835: iconst_0
    //   836: invokespecial <init> : ([BI)V
    //   839: bipush #9
    //   841: anewarray java/lang/Object
    //   844: astore #22
    //   846: invokestatic valueOf : (D)Ljava/lang/Double;
    //   849: astore #52
    //   851: aload #22
    //   853: iconst_0
    //   854: aload #52
    //   856: aastore
    //   857: aload #22
    //   859: iconst_1
    //   860: dload #40
    //   862: invokestatic valueOf : (D)Ljava/lang/Double;
    //   865: aastore
    //   866: aload #22
    //   868: iconst_2
    //   869: new org/renjin/gcc/runtime/BytePtr
    //   872: dup
    //   873: ldc 'spar '
    //   875: invokevirtual getBytes : ()[B
    //   878: iconst_0
    //   879: invokespecial <init> : ([BI)V
    //   882: aastore
    //   883: aload #22
    //   885: iconst_3
    //   886: aload #53
    //   888: iconst_0
    //   889: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   894: aastore
    //   895: aload #22
    //   897: iconst_4
    //   898: new org/renjin/gcc/runtime/BytePtr
    //   901: dup
    //   902: ldc 'b - a '
    //   904: invokevirtual getBytes : ()[B
    //   907: iconst_0
    //   908: invokespecial <init> : ([BI)V
    //   911: aastore
    //   912: aload #22
    //   914: iconst_5
    //   915: new org/renjin/gcc/runtime/BytePtr
    //   918: dup
    //   919: ldc 'e '
    //   921: invokevirtual getBytes : ()[B
    //   924: iconst_0
    //   925: invokespecial <init> : ([BI)V
    //   928: aastore
    //   929: aload #22
    //   931: bipush #6
    //   933: new org/renjin/gcc/runtime/BytePtr
    //   936: dup
    //   937: ldc 'NEW lspar '
    //   939: invokevirtual getBytes : ()[B
    //   942: iconst_0
    //   943: invokespecial <init> : ([BI)V
    //   946: aastore
    //   947: aload #22
    //   949: bipush #7
    //   951: new org/renjin/gcc/runtime/BytePtr
    //   954: dup
    //   955: ldc 'crit '
    //   957: invokevirtual getBytes : ()[B
    //   960: iconst_0
    //   961: invokespecial <init> : ([BI)V
    //   964: aastore
    //   965: aload #22
    //   967: bipush #8
    //   969: new org/renjin/gcc/runtime/BytePtr
    //   972: dup
    //   973: ldc ' ------------------------------------------------------------------------------- '
    //   975: invokevirtual getBytes : ()[B
    //   978: iconst_0
    //   979: invokespecial <init> : ([BI)V
    //   982: aastore
    //   983: aload #18
    //   985: aload #22
    //   987: invokestatic Rprintf : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
    //   990: dload #58
    //   992: dload #56
    //   994: dsub
    //   995: dstore #50
    //   997: aload #13
    //   999: invokeinterface getInt : ()I
    //   1004: iconst_3
    //   1005: if_icmpeq -> 1011
    //   1008: goto -> 1022
    //   1011: dload #66
    //   1013: ldc2_w 3.0
    //   1016: dsub
    //   1017: dstore #72
    //   1019: goto -> 1026
    //   1022: dload #66
    //   1024: dstore #72
    //   1026: new org/renjin/gcc/runtime/BytePtr
    //   1029: dup
    //   1030: ldc '%11.8f %14.9g %9.4e %11.5g '
    //   1032: invokevirtual getBytes : ()[B
    //   1035: iconst_0
    //   1036: invokespecial <init> : ([BI)V
    //   1039: iconst_4
    //   1040: anewarray java/lang/Object
    //   1043: astore #18
    //   1045: aload #18
    //   1047: iconst_0
    //   1048: dload #44
    //   1050: invokestatic valueOf : (D)Ljava/lang/Double;
    //   1053: aastore
    //   1054: aload #18
    //   1056: iconst_1
    //   1057: dload #72
    //   1059: invokestatic valueOf : (D)Ljava/lang/Double;
    //   1062: aastore
    //   1063: aload #18
    //   1065: iconst_2
    //   1066: dload #50
    //   1068: invokestatic valueOf : (D)Ljava/lang/Double;
    //   1071: aastore
    //   1072: aload #18
    //   1074: iconst_3
    //   1075: dload #64
    //   1077: invokestatic valueOf : (D)Ljava/lang/Double;
    //   1080: aastore
    //   1081: aload #18
    //   1083: invokestatic Rprintf : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
    //   1086: iconst_0
    //   1087: istore #52
    //   1089: dload #44
    //   1091: dload #42
    //   1093: dsub
    //   1094: invokestatic abs : (D)D
    //   1097: dload #38
    //   1099: dload #58
    //   1101: dload #56
    //   1103: dsub
    //   1104: ldc2_w 0.5
    //   1107: dmul
    //   1108: dsub
    //   1109: dcmpg
    //   1110: ifle -> 2085
    //   1113: aload #16
    //   1115: invokeinterface getInt : ()I
    //   1120: iload #15
    //   1122: if_icmpgt -> 2085
    //   1125: dload #64
    //   1127: invokestatic abs : (D)D
    //   1130: dload #40
    //   1132: dcmpg
    //   1133: ifle -> 1516
    //   1136: dload #66
    //   1138: ldc2_w 1.0E100
    //   1141: dcmpl
    //   1142: ifge -> 1516
    //   1145: dload #68
    //   1147: ldc2_w 1.0E100
    //   1150: dcmpl
    //   1151: ifge -> 1516
    //   1154: dload #70
    //   1156: ldc2_w 1.0E100
    //   1159: dcmpl
    //   1160: ifge -> 1516
    //   1163: iload #54
    //   1165: ifne -> 1171
    //   1168: goto -> 1194
    //   1171: new org/renjin/gcc/runtime/BytePtr
    //   1174: dup
    //   1175: ldc ' FP '
    //   1177: invokevirtual getBytes : ()[B
    //   1180: iconst_0
    //   1181: invokespecial <init> : ([BI)V
    //   1184: iconst_0
    //   1185: anewarray java/lang/Object
    //   1188: invokestatic Rprintf : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
    //   1191: iconst_1
    //   1192: istore #52
    //   1194: dload #44
    //   1196: dload #62
    //   1198: dsub
    //   1199: dload #66
    //   1201: dload #68
    //   1203: dsub
    //   1204: dmul
    //   1205: dstore #72
    //   1207: dload #44
    //   1209: dload #60
    //   1211: dsub
    //   1212: dload #66
    //   1214: dload #70
    //   1216: dsub
    //   1217: dmul
    //   1218: dstore #48
    //   1220: dload #44
    //   1222: dload #60
    //   1224: dsub
    //   1225: dload #48
    //   1227: dmul
    //   1228: dload #44
    //   1230: dload #62
    //   1232: dsub
    //   1233: dload #72
    //   1235: dmul
    //   1236: dsub
    //   1237: dstore #50
    //   1239: dload #48
    //   1241: dload #72
    //   1243: dsub
    //   1244: ldc2_w 2.0
    //   1247: dmul
    //   1248: dstore #72
    //   1250: dload #72
    //   1252: dconst_0
    //   1253: dcmpl
    //   1254: ifgt -> 1260
    //   1257: goto -> 1265
    //   1260: dload #50
    //   1262: dneg
    //   1263: dstore #50
    //   1265: dload #72
    //   1267: invokestatic abs : (D)D
    //   1270: dstore #72
    //   1272: dload #64
    //   1274: dload #46
    //   1276: dstore #64
    //   1278: dload #50
    //   1280: invokestatic abs : (D)D
    //   1283: dstore #48
    //   1285: dload #72
    //   1287: ldc2_w 0.5
    //   1290: dmul
    //   1291: dmul
    //   1292: invokestatic abs : (D)D
    //   1295: dstore #46
    //   1297: dload #48
    //   1299: dload #46
    //   1301: dcmpl
    //   1302: ifge -> 1516
    //   1305: dload #72
    //   1307: dconst_0
    //   1308: dcmpl
    //   1309: ifeq -> 1516
    //   1312: dload #56
    //   1314: dload #44
    //   1316: dsub
    //   1317: dload #72
    //   1319: dmul
    //   1320: dload #50
    //   1322: dcmpl
    //   1323: ifge -> 1516
    //   1326: dload #58
    //   1328: dload #44
    //   1330: dsub
    //   1331: dload #72
    //   1333: dmul
    //   1334: dload #50
    //   1336: dcmpg
    //   1337: ifle -> 1516
    //   1340: iload #54
    //   1342: ifne -> 1348
    //   1345: goto -> 1368
    //   1348: new org/renjin/gcc/runtime/BytePtr
    //   1351: dup
    //   1352: ldc ' PI  '
    //   1354: invokevirtual getBytes : ()[B
    //   1357: iconst_0
    //   1358: invokespecial <init> : ([BI)V
    //   1361: iconst_0
    //   1362: anewarray java/lang/Object
    //   1365: invokestatic Rprintf : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
    //   1368: dload #50
    //   1370: dload #72
    //   1372: ddiv
    //   1373: dstore #46
    //   1375: dload #46
    //   1377: invokestatic R_finite : (D)I
    //   1380: ifeq -> 1386
    //   1383: goto -> 1469
    //   1386: aload #37
    //   1388: invokeinterface getInt : ()I
    //   1393: new org/renjin/gcc/runtime/BytePtr
    //   1396: astore #18
    //   1398: aload #18
    //   1400: ldc ' !FIN(d:=p/q): ier=%d, (v,w, p,q)= %g, %g, %g, %g\\n '
    //   1402: invokevirtual getBytes : ()[B
    //   1405: iconst_0
    //   1406: invokespecial <init> : ([BI)V
    //   1409: iconst_5
    //   1410: anewarray java/lang/Object
    //   1413: astore #22
    //   1415: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   1418: astore #53
    //   1420: aload #22
    //   1422: iconst_0
    //   1423: aload #53
    //   1425: aastore
    //   1426: aload #22
    //   1428: iconst_1
    //   1429: dload #60
    //   1431: invokestatic valueOf : (D)Ljava/lang/Double;
    //   1434: aastore
    //   1435: aload #22
    //   1437: iconst_2
    //   1438: dload #62
    //   1440: invokestatic valueOf : (D)Ljava/lang/Double;
    //   1443: aastore
    //   1444: aload #22
    //   1446: iconst_3
    //   1447: dload #50
    //   1449: invokestatic valueOf : (D)Ljava/lang/Double;
    //   1452: aastore
    //   1453: aload #22
    //   1455: iconst_4
    //   1456: dload #72
    //   1458: invokestatic valueOf : (D)Ljava/lang/Double;
    //   1461: aastore
    //   1462: aload #18
    //   1464: aload #22
    //   1466: invokestatic REprintf : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
    //   1469: dload #44
    //   1471: dload #46
    //   1473: dadd
    //   1474: dstore #50
    //   1476: dload #50
    //   1478: dload #56
    //   1480: dsub
    //   1481: dload #38
    //   1483: dcmpg
    //   1484: iflt -> 1501
    //   1487: dload #58
    //   1489: dload #50
    //   1491: dsub
    //   1492: dload #38
    //   1494: dcmpg
    //   1495: iflt -> 1501
    //   1498: goto -> 1632
    //   1501: dload #40
    //   1503: dload #42
    //   1505: dload #44
    //   1507: dsub
    //   1508: invokestatic Rf_fsign : (DD)D
    //   1511: dstore #46
    //   1513: goto -> 1632
    //   1516: iload #54
    //   1518: ifne -> 1524
    //   1521: goto -> 1596
    //   1524: iload #52
    //   1526: ifne -> 1532
    //   1529: goto -> 1550
    //   1532: new org/renjin/gcc/runtime/BytePtr
    //   1535: dup
    //   1536: ldc ' '
    //   1538: invokevirtual getBytes : ()[B
    //   1541: iconst_0
    //   1542: invokespecial <init> : ([BI)V
    //   1545: astore #18
    //   1547: goto -> 1565
    //   1550: new org/renjin/gcc/runtime/BytePtr
    //   1553: dup
    //   1554: ldc ' -- '
    //   1556: invokevirtual getBytes : ()[B
    //   1559: iconst_0
    //   1560: invokespecial <init> : ([BI)V
    //   1563: astore #18
    //   1565: new org/renjin/gcc/runtime/BytePtr
    //   1568: dup
    //   1569: ldc ' GS%s  '
    //   1571: invokevirtual getBytes : ()[B
    //   1574: iconst_0
    //   1575: invokespecial <init> : ([BI)V
    //   1578: iconst_1
    //   1579: anewarray java/lang/Object
    //   1582: dup
    //   1583: iconst_0
    //   1584: aload #18
    //   1586: iconst_0
    //   1587: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   1592: aastore
    //   1593: invokestatic Rprintf : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
    //   1596: dload #44
    //   1598: dload #42
    //   1600: dcmpl
    //   1601: ifge -> 1607
    //   1604: goto -> 1617
    //   1607: dload #56
    //   1609: dload #44
    //   1611: dsub
    //   1612: dstore #64
    //   1614: goto -> 1624
    //   1617: dload #58
    //   1619: dload #44
    //   1621: dsub
    //   1622: dstore #64
    //   1624: getstatic org/renjin/stats/sbart__.$sbart_$c_Gold : D
    //   1627: dload #64
    //   1629: dmul
    //   1630: dstore #46
    //   1632: dload #46
    //   1634: invokestatic abs : (D)D
    //   1637: dload #40
    //   1639: dcmpl
    //   1640: ifge -> 1646
    //   1643: goto -> 1653
    //   1646: dload #46
    //   1648: dstore #38
    //   1650: goto -> 1662
    //   1653: dload #40
    //   1655: dload #46
    //   1657: invokestatic Rf_fsign : (DD)D
    //   1660: dstore #38
    //   1662: dload #38
    //   1664: dload #44
    //   1666: dadd
    //   1667: dstore #38
    //   1669: iload #55
    //   1671: ifeq -> 1677
    //   1674: goto -> 1702
    //   1677: ldc2_w 16.0
    //   1680: dload #38
    //   1682: ldc2_w 6.0
    //   1685: dmul
    //   1686: ldc2_w 2.0
    //   1689: dsub
    //   1690: invokestatic R_pow : (DD)D
    //   1693: getstatic org/renjin/stats/sbart__.$sbart_$ratio : D
    //   1696: dmul
    //   1697: dstore #40
    //   1699: goto -> 1706
    //   1702: dload #38
    //   1704: dstore #40
    //   1706: aload #17
    //   1708: dload #40
    //   1710: invokeinterface setDouble : (D)V
    //   1715: aload_0
    //   1716: aload_1
    //   1717: aload_2
    //   1718: aload_3
    //   1719: aload #4
    //   1721: aload #5
    //   1723: aload #6
    //   1725: aload #7
    //   1727: aload #8
    //   1729: aload #9
    //   1731: aload #10
    //   1733: aload #11
    //   1735: aload #12
    //   1737: aload #13
    //   1739: aload #17
    //   1741: aload #23
    //   1743: aload #24
    //   1745: aload #25
    //   1747: aload #26
    //   1749: aload #27
    //   1751: aload #28
    //   1753: aload #29
    //   1755: aload #30
    //   1757: aload #31
    //   1759: aload #32
    //   1761: aload #33
    //   1763: aload #34
    //   1765: aload #35
    //   1767: aload #36
    //   1769: aload #37
    //   1771: invokestatic sslvrg_ : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)V
    //   1774: aload #12
    //   1776: invokeinterface getDouble : ()D
    //   1781: dstore #40
    //   1783: iload #54
    //   1785: ifne -> 1791
    //   1788: goto -> 1876
    //   1791: aload #13
    //   1793: invokeinterface getInt : ()I
    //   1798: iconst_3
    //   1799: if_icmpeq -> 1805
    //   1802: goto -> 1816
    //   1805: dload #40
    //   1807: ldc2_w 3.0
    //   1810: dsub
    //   1811: dstore #42
    //   1813: goto -> 1820
    //   1816: dload #40
    //   1818: dstore #42
    //   1820: aload #17
    //   1822: invokeinterface getDouble : ()D
    //   1827: new org/renjin/gcc/runtime/BytePtr
    //   1830: astore #18
    //   1832: aload #18
    //   1834: ldc '%11g %12g\\n '
    //   1836: invokevirtual getBytes : ()[B
    //   1839: iconst_0
    //   1840: invokespecial <init> : ([BI)V
    //   1843: iconst_2
    //   1844: anewarray java/lang/Object
    //   1847: astore #22
    //   1849: invokestatic valueOf : (D)Ljava/lang/Double;
    //   1852: astore #53
    //   1854: aload #22
    //   1856: iconst_0
    //   1857: aload #53
    //   1859: aastore
    //   1860: aload #22
    //   1862: iconst_1
    //   1863: dload #42
    //   1865: invokestatic valueOf : (D)Ljava/lang/Double;
    //   1868: aastore
    //   1869: aload #18
    //   1871: aload #22
    //   1873: invokestatic Rprintf : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
    //   1876: dload #40
    //   1878: invokestatic R_finite : (D)I
    //   1881: ifeq -> 1887
    //   1884: goto -> 1920
    //   1887: new org/renjin/gcc/runtime/BytePtr
    //   1890: dup
    //   1891: ldc 'spar-finding: non-finite value %g; using BIG value\\n '
    //   1893: invokevirtual getBytes : ()[B
    //   1896: iconst_0
    //   1897: invokespecial <init> : ([BI)V
    //   1900: iconst_1
    //   1901: anewarray java/lang/Object
    //   1904: dup
    //   1905: iconst_0
    //   1906: dload #40
    //   1908: invokestatic valueOf : (D)Ljava/lang/Double;
    //   1911: aastore
    //   1912: invokestatic REprintf : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
    //   1915: ldc2_w 2.0E100
    //   1918: dstore #40
    //   1920: dload #40
    //   1922: dload #66
    //   1924: dcmpg
    //   1925: ifle -> 1931
    //   1928: goto -> 1980
    //   1931: dload #38
    //   1933: dload #44
    //   1935: dcmpl
    //   1936: ifge -> 1942
    //   1939: goto -> 1949
    //   1942: dload #44
    //   1944: dstore #56
    //   1946: goto -> 1953
    //   1949: dload #44
    //   1951: dstore #58
    //   1953: dload #62
    //   1955: dstore #60
    //   1957: dload #70
    //   1959: dstore #68
    //   1961: dload #44
    //   1963: dstore #62
    //   1965: dload #66
    //   1967: dstore #70
    //   1969: dload #38
    //   1971: dstore #44
    //   1973: dload #40
    //   1975: dstore #66
    //   1977: goto -> 2075
    //   1980: dload #38
    //   1982: dload #44
    //   1984: dcmpg
    //   1985: iflt -> 1991
    //   1988: goto -> 1998
    //   1991: dload #38
    //   1993: dstore #56
    //   1995: goto -> 2002
    //   1998: dload #38
    //   2000: dstore #58
    //   2002: dload #40
    //   2004: dload #70
    //   2006: dcmpg
    //   2007: ifle -> 2021
    //   2010: dload #62
    //   2012: dload #44
    //   2014: dcmpl
    //   2015: ifeq -> 2021
    //   2018: goto -> 2040
    //   2021: dload #62
    //   2023: dstore #60
    //   2025: dload #70
    //   2027: dstore #68
    //   2029: dload #38
    //   2031: dstore #62
    //   2033: dload #40
    //   2035: dstore #70
    //   2037: goto -> 2075
    //   2040: dload #40
    //   2042: dload #68
    //   2044: dcmpg
    //   2045: ifle -> 2067
    //   2048: dload #60
    //   2050: dload #44
    //   2052: dcmpl
    //   2053: ifeq -> 2067
    //   2056: dload #60
    //   2058: dload #62
    //   2060: dcmpl
    //   2061: ifeq -> 2067
    //   2064: goto -> 2075
    //   2067: dload #38
    //   2069: dstore #60
    //   2071: dload #40
    //   2073: dstore #68
    //   2075: aload #37
    //   2077: invokeinterface getInt : ()I
    //   2082: ifeq -> 617
    //   2085: iload #54
    //   2087: ifne -> 2093
    //   2090: goto -> 2169
    //   2093: aload #13
    //   2095: invokeinterface getInt : ()I
    //   2100: iconst_3
    //   2101: if_icmpeq -> 2107
    //   2104: goto -> 2118
    //   2107: dload #66
    //   2109: ldc2_w 3.0
    //   2112: dsub
    //   2113: dstore #46
    //   2115: goto -> 2122
    //   2118: dload #66
    //   2120: dstore #46
    //   2122: aload #17
    //   2124: invokeinterface getDouble : ()D
    //   2129: new org/renjin/gcc/runtime/BytePtr
    //   2132: astore_0
    //   2133: aload_0
    //   2134: ldc '  >>> %12g %12g\\n '
    //   2136: invokevirtual getBytes : ()[B
    //   2139: iconst_0
    //   2140: invokespecial <init> : ([BI)V
    //   2143: iconst_2
    //   2144: anewarray java/lang/Object
    //   2147: astore_1
    //   2148: invokestatic valueOf : (D)Ljava/lang/Double;
    //   2151: astore_2
    //   2152: aload_1
    //   2153: iconst_0
    //   2154: aload_2
    //   2155: aastore
    //   2156: aload_1
    //   2157: iconst_1
    //   2158: dload #46
    //   2160: invokestatic valueOf : (D)Ljava/lang/Double;
    //   2163: aastore
    //   2164: aload_0
    //   2165: aload_1
    //   2166: invokestatic Rprintf : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
    //   2169: aload #21
    //   2171: getstatic org/renjin/stats/sbart__.$sbart_$ratio : D
    //   2174: invokeinterface setDouble : (D)V
    //   2179: aload #14
    //   2181: dload #44
    //   2183: invokeinterface setDouble : (D)V
    //   2188: aload #12
    //   2190: dload #66
    //   2192: invokeinterface setDouble : (D)V
    //   2197: return
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/stats-0.9.2724.jar!/org/renjin/stats/sbart__.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */