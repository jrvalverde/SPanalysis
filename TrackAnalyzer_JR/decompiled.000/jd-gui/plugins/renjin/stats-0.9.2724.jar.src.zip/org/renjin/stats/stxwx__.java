package org.renjin.stats;

import org.renjin.appl.Appl;
import org.renjin.gcc.runtime.DoublePtr;
import org.renjin.gcc.runtime.IntPtr;
import org.renjin.gcc.runtime.Ptr;

public class stxwx__ {
  static {
  
  }
  
  public static void stxwx_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, Ptr paramPtr11) {
    int[] arrayOfInt1 = new int[1];
    double[] arrayOfDouble1 = new double[16];
    double[] arrayOfDouble2 = new double[4];
    int[] arrayOfInt2 = new int[1];
    int[] arrayOfInt3 = new int[1];
    int[] arrayOfInt4 = new int[1];
    arrayOfInt2[0] = 0;
    arrayOfInt3[0] = 0;
    Integer.toUnsignedLong(Math.max(paramPtr6.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr6.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr6.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr6.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr6.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr6.getInt() + 4, 0));
    Integer.toUnsignedLong(Math.max(paramPtr4.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr4.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr4.getInt(), 0));
    arrayOfInt3[0] = paramPtr6.getInt() + 4;
    int j = paramPtr6.getInt();
    byte b = 1;
    if (1 <= j)
      while (true) {
        boolean bool;
        paramPtr7.setAlignedDouble(b + -1, 0.0D);
        paramPtr8.setAlignedDouble(b + -1, 0.0D);
        paramPtr9.setAlignedDouble(b + -1, 0.0D);
        paramPtr10.setAlignedDouble(b + -1, 0.0D);
        paramPtr11.setAlignedDouble(b + -1, 0.0D);
        if (b != j) {
          bool = false;
        } else {
          bool = true;
        } 
        b++;
        if (!bool)
          continue; 
        break;
      }  
    arrayOfInt4[0] = 1;
    int i = paramPtr4.getInt();
    j = 1;
    if (1 <= i)
      while (true) {
        arrayOfInt1[0] = paramPtr6.getInt() + 1;
        Ptr ptr1 = (Ptr)new IntPtr(arrayOfInt1, 0);
        Ptr ptr2 = paramPtr1.pointerPlus((j + -1) * 8);
        arrayOfInt4[0] = Appl.interv_(paramPtr5, ptr1, ptr2, (Ptr)new IntPtr(new int[] { 0 }, 0), (Ptr)new IntPtr(new int[] { 0 }, 0), (Ptr)new IntPtr(arrayOfInt4, 0), (Ptr)new IntPtr(arrayOfInt2, 0));
        if (arrayOfInt2[0] == 1) {
          if (paramPtr1.getAlignedDouble(j + -1) > paramPtr5.getAlignedDouble(arrayOfInt4[0] + -1) + 1.0E-10D)
            break; 
          arrayOfInt4[0] = arrayOfInt4[0] + -1;
        } 
        ptr1 = (Ptr)new IntPtr(arrayOfInt3, 0);
        ptr2 = (Ptr)new IntPtr(new int[] { 4 }, 0);
        Ptr ptr3 = paramPtr1.pointerPlus((j + -1) * 8);
        bsplvd__.bsplvd_(paramPtr5, ptr1, ptr2, ptr3, (Ptr)new IntPtr(arrayOfInt4, 0), (Ptr)new DoublePtr(arrayOfDouble1, 0), (Ptr)new DoublePtr(arrayOfDouble2, 0), (Ptr)new IntPtr(new int[] { 1 }, 0));
        int k = arrayOfInt4[0] + -3;
        double d = paramPtr7.getAlignedDouble(k + -1);
        paramPtr7.setAlignedDouble(k + -1, paramPtr3.getAlignedDouble(j + -1) * paramPtr3.getAlignedDouble(j + -1) * paramPtr2.getAlignedDouble(j + -1) * arrayOfDouble2[0] + d);
        paramPtr8.setAlignedDouble(k + -1, paramPtr3.getAlignedDouble(j + -1) * paramPtr3.getAlignedDouble(j + -1) * arrayOfDouble2[0] * arrayOfDouble2[0] + paramPtr8.getAlignedDouble(k + -1));
        d = paramPtr9.getAlignedDouble(k + -1);
        paramPtr9.setAlignedDouble(k + -1, paramPtr3.getAlignedDouble(j + -1) * paramPtr3.getAlignedDouble(j + -1) * arrayOfDouble2[0] * arrayOfDouble2[1] + d);
        d = paramPtr10.getAlignedDouble(k + -1);
        paramPtr10.setAlignedDouble(k + -1, paramPtr3.getAlignedDouble(j + -1) * paramPtr3.getAlignedDouble(j + -1) * arrayOfDouble2[0] * arrayOfDouble2[2] + d);
        d = paramPtr11.getAlignedDouble(k + -1);
        paramPtr11.setAlignedDouble(k + -1, paramPtr3.getAlignedDouble(j + -1) * paramPtr3.getAlignedDouble(j + -1) * arrayOfDouble2[0] * arrayOfDouble2[3] + d);
        k = arrayOfInt4[0] + -2;
        d = paramPtr7.getAlignedDouble(k + -1);
        paramPtr7.setAlignedDouble(k + -1, paramPtr3.getAlignedDouble(j + -1) * paramPtr3.getAlignedDouble(j + -1) * paramPtr2.getAlignedDouble(j + -1) * arrayOfDouble2[1] + d);
        paramPtr8.setAlignedDouble(k + -1, paramPtr3.getAlignedDouble(j + -1) * paramPtr3.getAlignedDouble(j + -1) * arrayOfDouble2[1] * arrayOfDouble2[1] + paramPtr8.getAlignedDouble(k + -1));
        d = paramPtr9.getAlignedDouble(k + -1);
        paramPtr9.setAlignedDouble(k + -1, paramPtr3.getAlignedDouble(j + -1) * paramPtr3.getAlignedDouble(j + -1) * arrayOfDouble2[1] * arrayOfDouble2[2] + d);
        d = paramPtr10.getAlignedDouble(k + -1);
        paramPtr10.setAlignedDouble(k + -1, paramPtr3.getAlignedDouble(j + -1) * paramPtr3.getAlignedDouble(j + -1) * arrayOfDouble2[1] * arrayOfDouble2[3] + d);
        k = arrayOfInt4[0] + -1;
        d = paramPtr7.getAlignedDouble(k + -1);
        paramPtr7.setAlignedDouble(k + -1, paramPtr3.getAlignedDouble(j + -1) * paramPtr3.getAlignedDouble(j + -1) * paramPtr2.getAlignedDouble(j + -1) * arrayOfDouble2[2] + d);
        paramPtr8.setAlignedDouble(k + -1, paramPtr3.getAlignedDouble(j + -1) * paramPtr3.getAlignedDouble(j + -1) * arrayOfDouble2[2] * arrayOfDouble2[2] + paramPtr8.getAlignedDouble(k + -1));
        d = paramPtr9.getAlignedDouble(k + -1);
        paramPtr9.setAlignedDouble(k + -1, paramPtr3.getAlignedDouble(j + -1) * paramPtr3.getAlignedDouble(j + -1) * arrayOfDouble2[2] * arrayOfDouble2[3] + d);
        k = arrayOfInt4[0];
        d = paramPtr7.getAlignedDouble(k + -1);
        paramPtr7.setAlignedDouble(k + -1, paramPtr3.getAlignedDouble(j + -1) * paramPtr3.getAlignedDouble(j + -1) * paramPtr2.getAlignedDouble(j + -1) * arrayOfDouble2[3] + d);
        paramPtr8.setAlignedDouble(k + -1, paramPtr3.getAlignedDouble(j + -1) * paramPtr3.getAlignedDouble(j + -1) * arrayOfDouble2[3] * arrayOfDouble2[3] + paramPtr8.getAlignedDouble(k + -1));
        if (j != i) {
          k = 0;
        } else {
          k = 1;
        } 
        j++;
        if (k == 0)
          continue; 
        break;
      }  
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/stats-0.9.2724.jar!/org/renjin/stats/stxwx__.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */