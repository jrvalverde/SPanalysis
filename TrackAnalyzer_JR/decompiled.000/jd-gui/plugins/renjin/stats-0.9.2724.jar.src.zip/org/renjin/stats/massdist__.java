package org.renjin.stats;

import org.renjin.gcc.runtime.Mathlib;
import org.renjin.gcc.runtime.Ptr;
import org.renjin.gnur.api.Arith;

public class massdist__ {
  static {
  
  }
  
  public static void massdist(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7) {
    int j = paramPtr7.getInt() + -2;
    double d = (paramPtr5.getDouble() - paramPtr4.getDouble()) / (paramPtr7.getInt() + -1);
    int i;
    for (i = 0; paramPtr7.getInt() > i; i++)
      paramPtr6.setDouble(i * 8, 0.0D); 
    for (byte b = 0; paramPtr3.getInt() > b; b++) {
      if (Arith.R_finite(paramPtr1.getDouble(b * 8)) != 0) {
        i = (int)Mathlib.floor((paramPtr1.getDouble(b * 8) - paramPtr4.getDouble()) / d);
        double d2 = (paramPtr1.getDouble(b * 8) - paramPtr4.getDouble()) / d - i;
        double d1 = paramPtr2.getDouble(b * 8);
        if (i < 0 || i > j) {
          if (i != -1) {
            if (j + 1 == i)
              paramPtr6.setDouble(i * 8, paramPtr6.getDouble(i * 8) + (1.0D - d2) * d1); 
          } else {
            paramPtr6.setDouble(paramPtr6.getDouble() + d2 * d1);
          } 
        } else {
          paramPtr6.setDouble(i * 8, paramPtr6.getDouble(i * 8) + (1.0D - d2) * d1);
          paramPtr6.setDouble((i + 1) * 8, paramPtr6.getDouble((i + 1) * 8) + d2 * d1);
        } 
      } 
    } 
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/stats-0.9.2724.jar!/org/renjin/stats/massdist__.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */