package org.renjin.stats;

import org.renjin.gcc.runtime.BytePtr;
import org.renjin.gcc.runtime.DoublePtr;
import org.renjin.gcc.runtime.IntPtr;
import org.renjin.gcc.runtime.Mathlib;
import org.renjin.gcc.runtime.Ptr;

public class ks__ {
  static {
  
  }
  
  public static double K(int paramInt, double paramDouble) {
    int[] arrayOfInt = new int[1];
    BytePtr.of(0);
    BytePtr.of(0);
    arrayOfInt[0] = 0;
    int j = (int)(paramInt * paramDouble) + 1;
    int k = j * 2 + -1;
    double d = j - paramInt * paramDouble;
    DoublePtr doublePtr1 = DoublePtr.malloc(k * k * 8);
    DoublePtr doublePtr2 = DoublePtr.malloc(k * k * 8);
    int i;
    for (i = 0; i < k; i++) {
      for (byte b = 0; b < k; b++) {
        if (i - b + 1 >= 0) {
          doublePtr1.setDouble(0 + (i * k + b) * 8, 1.0D);
        } else {
          doublePtr1.setDouble(0 + (i * k + b) * 8, 0.0D);
        } 
      } 
    } 
    for (i = 0; i < k; i++) {
      doublePtr1.setDouble(0 + i * k * 8, doublePtr1.getDouble(0 + i * k * 8) - Mathlib.pow(d, (i + 1)));
      doublePtr1.setDouble(0 + ((k + -1) * k + i) * 8, doublePtr1.getDouble(0 + ((k + -1) * k + i) * 8) - Mathlib.pow(d, (k - i)));
    } 
    i = 0 + (k + -1) * 8 * k;
    paramDouble = doublePtr1.getDouble(0 + (k + -1) * 8 * k);
    if (d * 2.0D - 1.0D <= 0.0D) {
      d = 0.0D;
    } else {
      d = Mathlib.pow(d * 2.0D - 1.0D, k);
    } 
    doublePtr1.setDouble(i, paramDouble + d);
    for (i = 0; i < k; i++) {
      for (byte b = 0; b < k; b++) {
        if (i - b + 1 > 0)
          for (byte b1 = 1; i - b + 1 >= b1; b1++)
            doublePtr1.setDouble(0 + (i * k + b) * 8, doublePtr1.getDouble(0 + (i * k + b) * 8) / b1);  
      } 
    } 
    m_power(doublePtr1.pointerPlus(0), 0, doublePtr2.pointerPlus(0), (Ptr)new IntPtr(arrayOfInt, 0), k, paramInt);
    paramDouble = doublePtr2.getDouble(0 + ((j + -1) * k + j + -1) * 8);
    for (j = 1; j <= paramInt; j++) {
      paramDouble = j * paramDouble / paramInt;
      if (paramDouble < 1.0E-140D) {
        paramDouble *= 1.0E140D;
        arrayOfInt[0] = arrayOfInt[0] + -140;
      } 
    } 
    BytePtr.of(0);
    BytePtr.of(0);
    return Mathlib.pow(10.0D, arrayOfInt[0]) * paramDouble;
  }
  
  public static void m_multiply(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, int paramInt) {
    for (byte b = 0; b < paramInt; b++) {
      for (byte b1 = 0; b1 < paramInt; b1++) {
        double d = 0.0D;
        for (byte b2 = 0; b2 < paramInt; b2++)
          d = paramPtr1.getDouble((b * paramInt + b2) * 8) * paramPtr2.getDouble((b2 * paramInt + b1) * 8) + d; 
        paramPtr3.setDouble((b * paramInt + b1) * 8, d);
      } 
    } 
  }
  
  public static void m_power(Ptr paramPtr1, int paramInt1, Ptr paramPtr2, Ptr paramPtr3, int paramInt2, int paramInt3) {
    byte b;
    BytePtr.of(0);
    if (paramInt3 != 1) {
      m_power(paramPtr1, paramInt1, paramPtr2, paramPtr3, paramInt2, paramInt3 / 2);
      DoublePtr doublePtr = DoublePtr.malloc(paramInt2 * paramInt2 * 8);
      m_multiply(paramPtr2, paramPtr2, doublePtr.pointerPlus(0), paramInt2);
      int i = paramPtr3.getInt() * 2;
      if ((paramInt3 & 0x1) != 0) {
        m_multiply(paramPtr1, doublePtr.pointerPlus(0), paramPtr2, paramInt2);
        paramPtr3.setInt(paramInt1 + i);
      } else {
        for (b = 0; paramInt2 * paramInt2 > b; b++)
          paramPtr2.setDouble(b * 8, doublePtr.getDouble(0 + b * 8)); 
        paramPtr3.setInt(i);
      } 
      if (paramPtr2.getDouble((paramInt2 + 1) * 8 * paramInt2 / 2) > 1.0E140D) {
        for (b = 0; paramInt2 * paramInt2 > b; b++)
          paramPtr2.setDouble(b * 8, paramPtr2.getDouble(b * 8) * 1.0E-140D); 
        paramPtr3.setInt(paramPtr3.getInt() + 140);
      } 
      BytePtr.of(0);
      return;
    } 
    for (paramInt3 = 0; paramInt2 * paramInt2 > paramInt3; paramInt3++)
      paramPtr2.setDouble(paramInt3 * 8, b.getDouble(paramInt3 * 8)); 
    paramPtr3.setInt(paramInt1);
  }
  
  public static void pkolmogorov2x(Ptr paramPtr1, Ptr paramPtr2) {
    double d = paramPtr1.getDouble();
    paramPtr1.setDouble(K(paramPtr2.getInt(), d));
  }
  
  public static void pkstwo(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3) {
    int i = (int)Mathlib.sqrt(2.0D - Math.log(paramPtr3.getDouble()));
    for (byte b = 0; paramPtr1.getInt() > b; b++) {
      if (paramPtr2.getDouble(b * 8) >= 1.0D) {
        double d1 = paramPtr2.getDouble(b * 8) * -2.0D * paramPtr2.getDouble(b * 8);
        double d2 = -1.0D;
        byte b1 = 1;
        double d3 = 0.0D;
        double d4 = 1.0D;
        while (Math.abs(d3 - d4) > paramPtr3.getDouble()) {
          d3 = d4;
          d4 = d2 * 2.0D * Math.exp(b1 * d1 * b1) + d4;
          d2 = -d2;
          b1++;
        } 
        paramPtr2.setDouble(b * 8, d4);
      } else {
        double d1 = -1.2337005501361697D / paramPtr2.getDouble(b * 8) * paramPtr2.getDouble(b * 8);
        double d2 = Math.log(paramPtr2.getDouble(b * 8));
        double d3 = 0.0D;
        for (byte b1 = 1; b1 < i; b1 += 2)
          d3 = Math.exp((b1 * b1) * d1 - d2) + d3; 
        paramPtr2.setDouble(b * 8, d3 / 0.3989422804014327D);
      } 
    } 
  }
  
  public static void psmirnov2x(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3) {
    BytePtr.of(0);
    if (paramPtr2.getInt() > paramPtr3.getInt()) {
      paramPtr3.setInt(paramPtr2.getInt());
      paramPtr2.setInt(paramPtr3.getInt());
    } 
    double d1 = paramPtr2.getInt();
    double d2 = paramPtr3.getInt();
    double d3 = (Mathlib.floor(paramPtr1.getDouble() * d1 * d2 - 1.0E-7D) + 0.5D) / d1 * d2;
    DoublePtr doublePtr = DoublePtr.malloc((paramPtr3.getInt() + 1) * 8);
    byte b2;
    for (b2 = 0; paramPtr3.getInt() >= b2; b2++) {
      boolean bool;
      int i = 0 + b2 * 8;
      if (b2 / d2 <= d3) {
        bool = false;
      } else {
        bool = true;
      } 
      doublePtr.setDouble(i, (bool ^ true));
    } 
    for (byte b1 = 1; paramPtr2.getInt() >= b1; b1++) {
      double d = b1 / (paramPtr3.getInt() + b1);
      if (b1 / d1 <= d3) {
        doublePtr.setDouble(0, doublePtr.getDouble(0) * d);
      } else {
        doublePtr.setDouble(0, 0.0D);
      } 
      for (b2 = 1; paramPtr3.getInt() >= b2; b2++) {
        if (Math.abs(b1 / d1 - b2 / d2) <= d3) {
          doublePtr.setDouble(0 + b2 * 8, doublePtr.getDouble(0 + b2 * 8) * d + doublePtr.getDouble(0 + (b2 + -1) * 8));
        } else {
          doublePtr.setDouble(0 + b2 * 8, 0.0D);
        } 
      } 
    } 
    paramPtr1.setDouble(doublePtr.getDouble(0 + paramPtr3.getInt() * 8));
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/stats-0.9.2724.jar!/org/renjin/stats/ks__.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */