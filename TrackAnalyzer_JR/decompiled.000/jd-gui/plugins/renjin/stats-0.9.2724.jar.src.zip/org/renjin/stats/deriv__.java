package org.renjin.stats;

import org.renjin.gcc.runtime.BytePtr;
import org.renjin.gcc.runtime.Ptr;
import org.renjin.gcc.runtime.Stdlib;
import org.renjin.gcc.runtime.VoidPtr;
import org.renjin.gnur.api.Arith;
import org.renjin.gnur.api.Defn;
import org.renjin.gnur.api.Error;
import org.renjin.gnur.api.GetText;
import org.renjin.gnur.api.Memory;
import org.renjin.gnur.api.Rinternals;
import org.renjin.sexp.SEXP;

public class deriv__ {
  public static int Initialized = 0;
  
  public static SEXP LFactorialSymbol = (SEXP)BytePtr.of(0).getArray();
  
  public static SEXP FactorialSymbol = (SEXP)BytePtr.of(0).getArray();
  
  public static SEXP TanPiSymbol = (SEXP)BytePtr.of(0).getArray();
  
  public static SEXP CosPiSymbol = (SEXP)BytePtr.of(0).getArray();
  
  public static SEXP SinPiSymbol = (SEXP)BytePtr.of(0).getArray();
  
  public static SEXP Log10Symbol = (SEXP)BytePtr.of(0).getArray();
  
  public static SEXP Log2Symbol = (SEXP)BytePtr.of(0).getArray();
  
  public static SEXP Log1PSymbol = (SEXP)BytePtr.of(0).getArray();
  
  public static SEXP ExpM1Symbol = (SEXP)BytePtr.of(0).getArray();
  
  public static SEXP PiSymbol = (SEXP)BytePtr.of(0).getArray();
  
  public static SEXP PsiSymbol = (SEXP)BytePtr.of(0).getArray();
  
  public static SEXP TriGammaSymbol = (SEXP)BytePtr.of(0).getArray();
  
  public static SEXP DiGammaSymbol = (SEXP)BytePtr.of(0).getArray();
  
  public static SEXP LGammaSymbol = (SEXP)BytePtr.of(0).getArray();
  
  public static SEXP GammaSymbol = (SEXP)BytePtr.of(0).getArray();
  
  public static SEXP AtanSymbol = (SEXP)BytePtr.of(0).getArray();
  
  public static SEXP AcosSymbol = (SEXP)BytePtr.of(0).getArray();
  
  public static SEXP AsinSymbol = (SEXP)BytePtr.of(0).getArray();
  
  public static SEXP DnormSymbol = (SEXP)BytePtr.of(0).getArray();
  
  public static SEXP PnormSymbol = (SEXP)BytePtr.of(0).getArray();
  
  public static SEXP SqrtSymbol = (SEXP)BytePtr.of(0).getArray();
  
  public static SEXP TanhSymbol = (SEXP)BytePtr.of(0).getArray();
  
  public static SEXP CoshSymbol = (SEXP)BytePtr.of(0).getArray();
  
  public static SEXP SinhSymbol = (SEXP)BytePtr.of(0).getArray();
  
  public static SEXP TanSymbol = (SEXP)BytePtr.of(0).getArray();
  
  public static SEXP CosSymbol = (SEXP)BytePtr.of(0).getArray();
  
  public static SEXP SinSymbol = (SEXP)BytePtr.of(0).getArray();
  
  public static SEXP LogSymbol = (SEXP)BytePtr.of(0).getArray();
  
  public static SEXP ExpSymbol = (SEXP)BytePtr.of(0).getArray();
  
  public static SEXP PowerSymbol = (SEXP)BytePtr.of(0).getArray();
  
  public static SEXP DivideSymbol = (SEXP)BytePtr.of(0).getArray();
  
  public static SEXP TimesSymbol = (SEXP)BytePtr.of(0).getArray();
  
  public static SEXP MinusSymbol = (SEXP)BytePtr.of(0).getArray();
  
  public static SEXP PlusSymbol = (SEXP)BytePtr.of(0).getArray();
  
  public static SEXP ParenSymbol = (SEXP)BytePtr.of(0).getArray();
  
  public static int Accumulate(SEXP paramSEXP1, SEXP paramSEXP2) {
    int i;
    paramSEXP2 = paramSEXP2;
    byte b = 0;
    while (true) {
      if (Rinternals.CDR(paramSEXP2) != Rinternals.R_NilValue) {
        paramSEXP2 = Rinternals.CDR(paramSEXP2);
        b++;
        if (equal(paramSEXP1, Rinternals.CAR(paramSEXP2)) == 0)
          continue; 
        i = b;
        break;
      } 
      Rinternals.SETCDR(paramSEXP2, Rinternals.Rf_cons(i, Rinternals.R_NilValue));
      i = b + 1;
      break;
    } 
    return i;
  }
  
  public static int Accumulate2(SEXP paramSEXP1, SEXP paramSEXP2) {
    paramSEXP2 = paramSEXP2;
    byte b;
    for (b = 0; Rinternals.CDR(paramSEXP2) != Rinternals.R_NilValue; b++)
      paramSEXP2 = Rinternals.CDR(paramSEXP2); 
    Rinternals.SETCDR(paramSEXP2, Rinternals.Rf_cons(paramSEXP1, Rinternals.R_NilValue));
    return b + 1;
  }
  
  public static SEXP AddGrad() {
    SEXP sEXP2 = Rinternals.Rf_mkString((Ptr)new BytePtr("gradient\000".getBytes(), 0));
    Rinternals.Rf_protect(sEXP2);
    SEXP sEXP1 = Rinternals.Rf_install(new BytePtr(".value\000".getBytes(), 0));
    sEXP2 = Rinternals.Rf_lang3(Rinternals.Rf_install(new BytePtr("attr\000".getBytes(), 0)), sEXP1, sEXP2);
    Rinternals.Rf_protect(sEXP2);
    sEXP1 = Rinternals.Rf_install(new BytePtr(".grad\000".getBytes(), 0));
    return Rinternals.Rf_lang3(Rinternals.Rf_install(new BytePtr("<-\000".getBytes(), 0)), sEXP2, sEXP1);
  }
  
  public static SEXP AddHess() {
    SEXP sEXP2 = Rinternals.Rf_mkString((Ptr)new BytePtr("hessian\000".getBytes(), 0));
    Rinternals.Rf_protect(sEXP2);
    SEXP sEXP1 = Rinternals.Rf_install(new BytePtr(".value\000".getBytes(), 0));
    sEXP2 = Rinternals.Rf_lang3(Rinternals.Rf_install(new BytePtr("attr\000".getBytes(), 0)), sEXP1, sEXP2);
    Rinternals.Rf_protect(sEXP2);
    sEXP1 = Rinternals.Rf_install(new BytePtr(".hessian\000".getBytes(), 0));
    return Rinternals.Rf_lang3(Rinternals.Rf_install(new BytePtr("<-\000".getBytes(), 0)), sEXP2, sEXP1);
  }
  
  public static SEXP AddParens(SEXP paramSEXP) {
    if (Rinternals.TYPEOF(paramSEXP) == 6)
      for (SEXP sEXP = Rinternals.CDR(paramSEXP); sEXP != Rinternals.R_NilValue; sEXP = Rinternals.CDR(sEXP))
        Rinternals.SETCAR(sEXP, AddParens(Rinternals.CAR(sEXP)));  
    if (isPlusForm(paramSEXP) == 0) {
      if (isMinusForm(paramSEXP) == 0) {
        if (isTimesForm(paramSEXP) == 0) {
          if (isDivideForm(paramSEXP) == 0) {
            if (isPowerForm(paramSEXP) != 0) {
              if (isPowerForm(Rinternals.CADR(paramSEXP)) != 0) {
                SEXP sEXP = Rinternals.CADR(paramSEXP);
                Rinternals.SETCADR(paramSEXP, Rinternals.Rf_lang2(ParenSymbol, sEXP));
              } 
              if (isPlusForm(Rinternals.CADDR(paramSEXP)) != 0 || isMinusForm(Rinternals.CADDR(paramSEXP)) != 0 || isTimesForm(Rinternals.CADDR(paramSEXP)) != 0 || isDivideForm(Rinternals.CADDR(paramSEXP)) != 0) {
                SEXP sEXP = Rinternals.CADDR(paramSEXP);
                Rinternals.SETCADDR(paramSEXP, Rinternals.Rf_lang2(ParenSymbol, sEXP));
              } 
            } 
            return paramSEXP;
          } 
          if (isPlusForm(Rinternals.CADDR(paramSEXP)) != 0 || isMinusForm(Rinternals.CADDR(paramSEXP)) != 0 || isTimesForm(Rinternals.CADDR(paramSEXP)) != 0 || isDivideForm(Rinternals.CADDR(paramSEXP)) != 0) {
            SEXP sEXP = Rinternals.CADDR(paramSEXP);
            Rinternals.SETCADDR(paramSEXP, Rinternals.Rf_lang2(ParenSymbol, sEXP));
          } 
          if (isPlusForm(Rinternals.CADR(paramSEXP)) != 0 || isMinusForm(Rinternals.CADR(paramSEXP)) != 0) {
            SEXP sEXP = Rinternals.CADR(paramSEXP);
            Rinternals.SETCADR(paramSEXP, Rinternals.Rf_lang2(ParenSymbol, sEXP));
          } 
          return paramSEXP;
        } 
        if (isPlusForm(Rinternals.CADDR(paramSEXP)) != 0 || isMinusForm(Rinternals.CADDR(paramSEXP)) != 0 || isTimesForm(Rinternals.CADDR(paramSEXP)) != 0 || isDivideForm(Rinternals.CADDR(paramSEXP)) != 0) {
          SEXP sEXP = Rinternals.CADDR(paramSEXP);
          Rinternals.SETCADDR(paramSEXP, Rinternals.Rf_lang2(ParenSymbol, sEXP));
        } 
        if (isPlusForm(Rinternals.CADR(paramSEXP)) != 0 || isMinusForm(Rinternals.CADR(paramSEXP)) != 0) {
          SEXP sEXP = Rinternals.CADR(paramSEXP);
          Rinternals.SETCADR(paramSEXP, Rinternals.Rf_lang2(ParenSymbol, sEXP));
        } 
        return paramSEXP;
      } 
      if (isPlusForm(Rinternals.CADDR(paramSEXP)) != 0 || isMinusForm(Rinternals.CADDR(paramSEXP)) != 0) {
        SEXP sEXP = Rinternals.CADDR(paramSEXP);
        Rinternals.SETCADDR(paramSEXP, Rinternals.Rf_lang2(ParenSymbol, sEXP));
      } 
      return paramSEXP;
    } 
    if (isPlusForm(Rinternals.CADDR(paramSEXP)) != 0) {
      SEXP sEXP = Rinternals.CADDR(paramSEXP);
      Rinternals.SETCADDR(paramSEXP, Rinternals.Rf_lang2(ParenSymbol, sEXP));
    } 
    return paramSEXP;
  }
  
  public static SEXP Constant(double paramDouble) {
    return Rinternals.Rf_ScalarReal(paramDouble);
  }
  
  public static int CountOccurrences(SEXP paramSEXP1, SEXP paramSEXP2) {
    switch (Rinternals.TYPEOF(paramSEXP2)) {
      case 1:
        if (paramSEXP2 != paramSEXP1) {
          null = false;
        } else {
          null = true;
        } 
        return null;
      case 2:
      case 6:
        return CountOccurrences(paramSEXP1, Rinternals.CAR(paramSEXP2)) + CountOccurrences(paramSEXP1, Rinternals.CDR(paramSEXP2));
    } 
    return 0;
  }
  
  public static SEXP CreateGrad(SEXP paramSEXP) {
    SEXP sEXP3 = (SEXP)BytePtr.of(0).getArray();
    int i = Rinternals.Rf_length(paramSEXP);
    sEXP3 = Rinternals.Rf_lang3(Rinternals.R_NilValue, Rinternals.R_NilValue, Rinternals.R_NilValue);
    Rinternals.Rf_protect(sEXP3);
    Rinternals.SETCAR(sEXP3, Rinternals.Rf_install(new BytePtr("list\000".getBytes(), 0)));
    SEXP sEXP2 = Rinternals.Rf_allocList(i);
    Rinternals.Rf_protect(sEXP2);
    Rinternals.SETCADDR(sEXP3, Rinternals.Rf_lcons(Rinternals.Rf_install(new BytePtr("c\000".getBytes(), 0)), sEXP2));
    for (byte b = 0; b < i; b++) {
      Rinternals.SETCAR(sEXP2, Rinternals.Rf_ScalarString(Rinternals.STRING_ELT(paramSEXP, b)));
      sEXP2 = Rinternals.CDR(sEXP2);
    } 
    SEXP sEXP1 = Rinternals.Rf_lang3(Rinternals.R_NilValue, Rinternals.R_NilValue, Rinternals.R_NilValue);
    Rinternals.Rf_protect(sEXP1);
    Rinternals.SETCAR(sEXP1, Rinternals.Rf_install(new BytePtr("c\000".getBytes(), 0)));
    sEXP2 = Rinternals.Rf_install(new BytePtr(".value\000".getBytes(), 0));
    Rinternals.SETCADR(sEXP1, Rinternals.Rf_lang2(Rinternals.Rf_install(new BytePtr("length\000".getBytes(), 0)), sEXP2));
    Rinternals.SETCADDR(sEXP1, Rinternals.Rf_ScalarInteger(Rinternals.Rf_length(paramSEXP)));
    paramSEXP = Rinternals.Rf_ScalarReal(0.0D);
    Rinternals.Rf_protect(paramSEXP);
    sEXP3 = Rinternals.Rf_lang4(Rinternals.Rf_install(new BytePtr("array\000".getBytes(), 0)), paramSEXP, sEXP1, sEXP3);
    Rinternals.Rf_protect(sEXP3);
    paramSEXP = Rinternals.Rf_install(new BytePtr(".grad\000".getBytes(), 0));
    return Rinternals.Rf_lang3(Rinternals.Rf_install(new BytePtr("<-\000".getBytes(), 0)), paramSEXP, sEXP3);
  }
  
  public static SEXP CreateHess(SEXP paramSEXP) {
    SEXP sEXP3 = (SEXP)BytePtr.of(0).getArray();
    int i = Rinternals.Rf_length(paramSEXP);
    sEXP3 = Rinternals.Rf_lang4(Rinternals.R_NilValue, Rinternals.R_NilValue, Rinternals.R_NilValue, Rinternals.R_NilValue);
    Rinternals.Rf_protect(sEXP3);
    Rinternals.SETCAR(sEXP3, Rinternals.Rf_install(new BytePtr("list\000".getBytes(), 0)));
    SEXP sEXP2 = Rinternals.Rf_allocList(i);
    Rinternals.Rf_protect(sEXP2);
    Rinternals.SETCADDR(sEXP3, Rinternals.Rf_lcons(Rinternals.Rf_install(new BytePtr("c\000".getBytes(), 0)), sEXP2));
    for (byte b = 0; b < i; b++) {
      Rinternals.SETCAR(sEXP2, Rinternals.Rf_ScalarString(Rinternals.STRING_ELT(paramSEXP, b)));
      sEXP2 = Rinternals.CDR(sEXP2);
    } 
    Rinternals.SETCADDDR(sEXP3, Rinternals.Rf_duplicate(Rinternals.CADDR(sEXP3)));
    SEXP sEXP1 = Rinternals.Rf_lang4(Rinternals.R_NilValue, Rinternals.R_NilValue, Rinternals.R_NilValue, Rinternals.R_NilValue);
    Rinternals.Rf_protect(sEXP1);
    Rinternals.SETCAR(sEXP1, Rinternals.Rf_install(new BytePtr("c\000".getBytes(), 0)));
    sEXP2 = Rinternals.Rf_install(new BytePtr(".value\000".getBytes(), 0));
    Rinternals.SETCADR(sEXP1, Rinternals.Rf_lang2(Rinternals.Rf_install(new BytePtr("length\000".getBytes(), 0)), sEXP2));
    Rinternals.SETCADDR(sEXP1, Rinternals.Rf_ScalarInteger(Rinternals.Rf_length(paramSEXP)));
    Rinternals.SETCADDDR(sEXP1, Rinternals.Rf_ScalarInteger(Rinternals.Rf_length(paramSEXP)));
    paramSEXP = Rinternals.Rf_ScalarReal(0.0D);
    Rinternals.Rf_protect(paramSEXP);
    sEXP3 = Rinternals.Rf_lang4(Rinternals.Rf_install(new BytePtr("array\000".getBytes(), 0)), paramSEXP, sEXP1, sEXP3);
    Rinternals.Rf_protect(sEXP3);
    paramSEXP = Rinternals.Rf_install(new BytePtr(".hessian\000".getBytes(), 0));
    return Rinternals.Rf_lang3(Rinternals.Rf_install(new BytePtr("<-\000".getBytes(), 0)), paramSEXP, sEXP3);
  }
  
  public static SEXP D(SEXP paramSEXP1, SEXP paramSEXP2) {
    SEXP sEXP;
    null = Rinternals.R_NilValue;
    switch (Rinternals.TYPEOF(paramSEXP1)) {
      case 10:
      case 13:
      case 14:
      case 15:
        return Constant(0.0D);
      case 1:
        return (paramSEXP1 != paramSEXP2) ? Constant(0.0D) : Constant(1.0D);
      case 2:
        return !Rinternals.Rf_inherits(paramSEXP1, new BytePtr("expression\000".getBytes(), 0)) ? Constant(Arith.R_NaReal) : D(Rinternals.CAR(paramSEXP1), paramSEXP2);
      case 6:
        if (Rinternals.CAR(paramSEXP1) != ParenSymbol) {
          if (Rinternals.CAR(paramSEXP1) != PlusSymbol) {
            if (Rinternals.CAR(paramSEXP1) != MinusSymbol) {
              if (Rinternals.CAR(paramSEXP1) != TimesSymbol) {
                if (Rinternals.CAR(paramSEXP1) != DivideSymbol) {
                  if (Rinternals.CAR(paramSEXP1) != PowerSymbol) {
                    if (Rinternals.CAR(paramSEXP1) != ExpSymbol) {
                      if (Rinternals.CAR(paramSEXP1) != LogSymbol) {
                        if (Rinternals.CAR(paramSEXP1) != CosSymbol) {
                          if (Rinternals.CAR(paramSEXP1) != SinSymbol) {
                            if (Rinternals.CAR(paramSEXP1) != TanSymbol) {
                              if (Rinternals.CAR(paramSEXP1) != CoshSymbol) {
                                if (Rinternals.CAR(paramSEXP1) != SinhSymbol) {
                                  if (Rinternals.CAR(paramSEXP1) != TanhSymbol) {
                                    if (Rinternals.CAR(paramSEXP1) != SqrtSymbol) {
                                      if (Rinternals.CAR(paramSEXP1) != PnormSymbol) {
                                        if (Rinternals.CAR(paramSEXP1) != DnormSymbol) {
                                          if (Rinternals.CAR(paramSEXP1) != AsinSymbol) {
                                            if (Rinternals.CAR(paramSEXP1) != AcosSymbol) {
                                              if (Rinternals.CAR(paramSEXP1) != AtanSymbol) {
                                                if (Rinternals.CAR(paramSEXP1) != LGammaSymbol) {
                                                  if (Rinternals.CAR(paramSEXP1) != GammaSymbol) {
                                                    if (Rinternals.CAR(paramSEXP1) != DiGammaSymbol) {
                                                      if (Rinternals.CAR(paramSEXP1) != TriGammaSymbol) {
                                                        if (Rinternals.CAR(paramSEXP1) != PsiSymbol) {
                                                          if (Rinternals.CAR(paramSEXP1) != ExpM1Symbol) {
                                                            if (Rinternals.CAR(paramSEXP1) != Log1PSymbol) {
                                                              if (Rinternals.CAR(paramSEXP1) != Log2Symbol) {
                                                                if (Rinternals.CAR(paramSEXP1) != Log10Symbol) {
                                                                  if (Rinternals.CAR(paramSEXP1) != CosPiSymbol) {
                                                                    if (Rinternals.CAR(paramSEXP1) != SinPiSymbol) {
                                                                      if (Rinternals.CAR(paramSEXP1) != TanPiSymbol) {
                                                                        if (Rinternals.CAR(paramSEXP1) != LFactorialSymbol) {
                                                                          BytePtr bytePtr;
                                                                          if (Rinternals.CAR(paramSEXP1) != FactorialSymbol) {
                                                                            bytePtr = Rinternals.Rf_translateChar(Rinternals.STRING_ELT(Defn.Rf_deparse1(Rinternals.CAR(paramSEXP1), false, 0), 0));
                                                                            Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("Function '%s' is not in the derivatives table\000".getBytes(), 0)), new Object[] { bytePtr });
                                                                            return (SEXP)SYNTHETIC_LOCAL_VARIABLE_2;
                                                                          } 
                                                                          null = Rinternals.R_MissingArg;
                                                                          SEXP sEXP29 = PP(Rinternals.Rf_ScalarInteger(1));
                                                                          SEXP sEXP28 = Rinternals.CADR((SEXP)bytePtr);
                                                                          sEXP28 = PP(simplify(PlusSymbol, sEXP28, sEXP29));
                                                                          null = PP(simplify(DiGammaSymbol, sEXP28, null));
                                                                          null = PP(simplify(TimesSymbol, (SEXP)bytePtr, null));
                                                                          sEXP = PP(D(Rinternals.CADR((SEXP)bytePtr), paramSEXP2));
                                                                          return simplify(TimesSymbol, sEXP, null);
                                                                        } 
                                                                        null = Rinternals.R_MissingArg;
                                                                        SEXP sEXP27 = PP(Rinternals.Rf_ScalarInteger(1));
                                                                        SEXP sEXP26 = Rinternals.CADR(sEXP);
                                                                        sEXP26 = PP(simplify(PlusSymbol, sEXP26, sEXP27));
                                                                        null = PP(simplify(DiGammaSymbol, sEXP26, null));
                                                                        sEXP = PP(D(Rinternals.CADR(sEXP), paramSEXP2));
                                                                        return simplify(TimesSymbol, sEXP, null);
                                                                      } 
                                                                      null = PP(Constant(2.0D));
                                                                      SEXP sEXP25 = Rinternals.R_MissingArg;
                                                                      SEXP sEXP24 = Rinternals.CADR(sEXP);
                                                                      sEXP24 = PP(simplify(CosPiSymbol, sEXP24, sEXP25));
                                                                      null = PP(simplify(PowerSymbol, sEXP24, null));
                                                                      sEXP = PP(D(Rinternals.CADR(sEXP), paramSEXP2));
                                                                      sEXP = PP(simplify(TimesSymbol, PiSymbol, sEXP));
                                                                      return simplify(DivideSymbol, sEXP, null);
                                                                    } 
                                                                    paramSEXP2 = PP(D(Rinternals.CADR(sEXP), paramSEXP2));
                                                                    paramSEXP2 = PP(simplify(TimesSymbol, PiSymbol, paramSEXP2));
                                                                    null = Rinternals.R_MissingArg;
                                                                    sEXP = Rinternals.CADR(sEXP);
                                                                    sEXP = PP(simplify(CosPiSymbol, sEXP, null));
                                                                    return simplify(TimesSymbol, sEXP, paramSEXP2);
                                                                  } 
                                                                  null = PP(D(Rinternals.CADR(sEXP), paramSEXP2));
                                                                  paramSEXP2 = PP(simplify(MinusSymbol, PiSymbol, Rinternals.R_MissingArg));
                                                                  paramSEXP2 = PP(simplify(TimesSymbol, paramSEXP2, null));
                                                                  null = Rinternals.R_MissingArg;
                                                                  sEXP = Rinternals.CADR(sEXP);
                                                                  sEXP = PP(simplify(SinPiSymbol, sEXP, null));
                                                                  return simplify(TimesSymbol, sEXP, paramSEXP2);
                                                                } 
                                                                SEXP sEXP23 = Rinternals.R_MissingArg;
                                                                null = PP(Constant(10.0D));
                                                                sEXP23 = PP(simplify(LogSymbol, null, sEXP23));
                                                                null = Rinternals.CADR(sEXP);
                                                                null = PP(simplify(TimesSymbol, null, sEXP23));
                                                                sEXP = PP(D(Rinternals.CADR(sEXP), paramSEXP2));
                                                                return simplify(DivideSymbol, sEXP, null);
                                                              } 
                                                              SEXP sEXP22 = Rinternals.R_MissingArg;
                                                              null = PP(Constant(2.0D));
                                                              sEXP22 = PP(simplify(LogSymbol, null, sEXP22));
                                                              null = Rinternals.CADR(sEXP);
                                                              null = PP(simplify(TimesSymbol, null, sEXP22));
                                                              sEXP = PP(D(Rinternals.CADR(sEXP), paramSEXP2));
                                                              return simplify(DivideSymbol, sEXP, null);
                                                            } 
                                                            SEXP sEXP21 = Rinternals.CADR(sEXP);
                                                            null = PP(Constant(1.0D));
                                                            null = PP(simplify(PlusSymbol, null, sEXP21));
                                                            sEXP = PP(D(Rinternals.CADR(sEXP), paramSEXP2));
                                                            return simplify(DivideSymbol, sEXP, null);
                                                          } 
                                                          paramSEXP2 = PP(D(Rinternals.CADR(sEXP), paramSEXP2));
                                                          null = Rinternals.R_MissingArg;
                                                          sEXP = Rinternals.CADR(sEXP);
                                                          sEXP = PP(simplify(ExpSymbol, sEXP, null));
                                                          return simplify(TimesSymbol, sEXP, paramSEXP2);
                                                        } 
                                                        if (Rinternals.Rf_length(sEXP) != 2) {
                                                          if (Rinternals.TYPEOF(Rinternals.CADDR(sEXP)) != 13 && Rinternals.TYPEOF(Rinternals.CADDR(sEXP)) != 14) {
                                                            SEXP sEXP22 = PP(Rinternals.Rf_ScalarInteger(1));
                                                            null = Rinternals.CADDR(sEXP);
                                                            sEXP22 = simplify(PlusSymbol, null, sEXP22);
                                                            null = Rinternals.CADR(sEXP);
                                                            null = PP(simplify(PsiSymbol, null, sEXP22));
                                                            sEXP = PP(D(Rinternals.CADR(sEXP), paramSEXP2));
                                                            return simplify(TimesSymbol, sEXP, null);
                                                          } 
                                                          SEXP sEXP21 = PP(Rinternals.Rf_ScalarInteger(Rinternals.Rf_asInteger(Rinternals.CADDR(sEXP)) + 1));
                                                          null = Rinternals.CADR(sEXP);
                                                          null = PP(simplify(PsiSymbol, null, sEXP21));
                                                          sEXP = PP(D(Rinternals.CADR(sEXP), paramSEXP2));
                                                          return simplify(TimesSymbol, sEXP, null);
                                                        } 
                                                        SEXP sEXP20 = PP(Rinternals.Rf_ScalarInteger(1));
                                                        null = Rinternals.CADR(sEXP);
                                                        null = PP(simplify(PsiSymbol, null, sEXP20));
                                                        sEXP = PP(D(Rinternals.CADR(sEXP), paramSEXP2));
                                                        return simplify(TimesSymbol, sEXP, null);
                                                      } 
                                                      SEXP sEXP19 = PP(Rinternals.Rf_ScalarInteger(2));
                                                      null = Rinternals.CADR(sEXP);
                                                      null = PP(simplify(PsiSymbol, null, sEXP19));
                                                      sEXP = PP(D(Rinternals.CADR(sEXP), paramSEXP2));
                                                      return simplify(TimesSymbol, sEXP, null);
                                                    } 
                                                    SEXP sEXP18 = Rinternals.R_MissingArg;
                                                    null = Rinternals.CADR(sEXP);
                                                    null = PP(simplify(TriGammaSymbol, null, sEXP18));
                                                    sEXP = PP(D(Rinternals.CADR(sEXP), paramSEXP2));
                                                    return simplify(TimesSymbol, sEXP, null);
                                                  } 
                                                  SEXP sEXP17 = Rinternals.R_MissingArg;
                                                  null = Rinternals.CADR(sEXP);
                                                  null = PP(simplify(DiGammaSymbol, null, sEXP17));
                                                  null = PP(simplify(TimesSymbol, sEXP, null));
                                                  sEXP = PP(D(Rinternals.CADR(sEXP), paramSEXP2));
                                                  return simplify(TimesSymbol, sEXP, null);
                                                } 
                                                SEXP sEXP16 = Rinternals.R_MissingArg;
                                                null = Rinternals.CADR(sEXP);
                                                null = PP(simplify(DiGammaSymbol, null, sEXP16));
                                                sEXP = PP(D(Rinternals.CADR(sEXP), paramSEXP2));
                                                return simplify(TimesSymbol, sEXP, null);
                                              } 
                                              SEXP sEXP15 = PP(Constant(2.0D));
                                              null = Rinternals.CADR(sEXP);
                                              sEXP15 = PP(simplify(PowerSymbol, null, sEXP15));
                                              null = PP(Constant(1.0D));
                                              null = PP(simplify(PlusSymbol, null, sEXP15));
                                              sEXP = PP(D(Rinternals.CADR(sEXP), paramSEXP2));
                                              return simplify(DivideSymbol, sEXP, null);
                                            } 
                                            null = Rinternals.R_MissingArg;
                                            SEXP sEXP12 = Rinternals.R_MissingArg;
                                            SEXP sEXP14 = PP(Constant(2.0D));
                                            SEXP sEXP13 = Rinternals.CADR(sEXP);
                                            sEXP14 = PP(simplify(PowerSymbol, sEXP13, sEXP14));
                                            sEXP13 = PP(Constant(1.0D));
                                            sEXP13 = PP(simplify(MinusSymbol, sEXP13, sEXP14));
                                            sEXP12 = PP(simplify(SqrtSymbol, sEXP13, sEXP12));
                                            sEXP = PP(D(Rinternals.CADR(sEXP), paramSEXP2));
                                            sEXP = PP(simplify(DivideSymbol, sEXP, sEXP12));
                                            return simplify(MinusSymbol, sEXP, null);
                                          } 
                                          null = Rinternals.R_MissingArg;
                                          SEXP sEXP11 = PP(Constant(2.0D));
                                          SEXP sEXP10 = Rinternals.CADR(sEXP);
                                          sEXP11 = PP(simplify(PowerSymbol, sEXP10, sEXP11));
                                          sEXP10 = PP(Constant(1.0D));
                                          sEXP10 = PP(simplify(MinusSymbol, sEXP10, sEXP11));
                                          null = PP(simplify(SqrtSymbol, sEXP10, null));
                                          sEXP = PP(D(Rinternals.CADR(sEXP), paramSEXP2));
                                          return simplify(DivideSymbol, sEXP, null);
                                        } 
                                        paramSEXP2 = PP(D(Rinternals.CADR(sEXP), paramSEXP2));
                                        SEXP sEXP9 = Rinternals.R_MissingArg;
                                        null = Rinternals.CADR(sEXP);
                                        null = PP(simplify(DnormSymbol, null, sEXP9));
                                        paramSEXP2 = PP(simplify(TimesSymbol, null, paramSEXP2));
                                        null = Rinternals.R_MissingArg;
                                        sEXP = Rinternals.CADR(sEXP);
                                        sEXP = PP(simplify(MinusSymbol, sEXP, null));
                                        return simplify(TimesSymbol, sEXP, paramSEXP2);
                                      } 
                                      paramSEXP2 = PP(D(Rinternals.CADR(sEXP), paramSEXP2));
                                      null = Rinternals.R_MissingArg;
                                      sEXP = Rinternals.CADR(sEXP);
                                      sEXP = PP(simplify(DnormSymbol, sEXP, null));
                                      return simplify(TimesSymbol, sEXP, paramSEXP2);
                                    } 
                                    null = Rinternals.Rf_allocLang(3);
                                    Rinternals.Rf_protect(null);
                                    Rinternals.SET_TYPEOF(null, 6);
                                    Rinternals.SETCAR(null, PowerSymbol);
                                    Rinternals.SETCADR(null, Rinternals.CADR(sEXP));
                                    Rinternals.SETCADDR(null, Constant(0.5D));
                                    return D(null, paramSEXP2);
                                  } 
                                  null = PP(Constant(2.0D));
                                  SEXP sEXP8 = Rinternals.R_MissingArg;
                                  SEXP sEXP7 = Rinternals.CADR(sEXP);
                                  sEXP7 = PP(simplify(CoshSymbol, sEXP7, sEXP8));
                                  null = PP(simplify(PowerSymbol, sEXP7, null));
                                  sEXP = PP(D(Rinternals.CADR(sEXP), paramSEXP2));
                                  return simplify(DivideSymbol, sEXP, null);
                                } 
                                paramSEXP2 = PP(D(Rinternals.CADR(sEXP), paramSEXP2));
                                null = Rinternals.R_MissingArg;
                                sEXP = Rinternals.CADR(sEXP);
                                sEXP = PP(simplify(CoshSymbol, sEXP, null));
                                return simplify(TimesSymbol, sEXP, paramSEXP2);
                              } 
                              paramSEXP2 = PP(D(Rinternals.CADR(sEXP), paramSEXP2));
                              null = Rinternals.R_MissingArg;
                              sEXP = Rinternals.CADR(sEXP);
                              sEXP = PP(simplify(SinhSymbol, sEXP, null));
                              return simplify(TimesSymbol, sEXP, paramSEXP2);
                            } 
                            null = PP(Constant(2.0D));
                            SEXP sEXP6 = Rinternals.R_MissingArg;
                            SEXP sEXP5 = Rinternals.CADR(sEXP);
                            sEXP5 = PP(simplify(CosSymbol, sEXP5, sEXP6));
                            null = PP(simplify(PowerSymbol, sEXP5, null));
                            sEXP = PP(D(Rinternals.CADR(sEXP), paramSEXP2));
                            return simplify(DivideSymbol, sEXP, null);
                          } 
                          paramSEXP2 = PP(D(Rinternals.CADR(sEXP), paramSEXP2));
                          null = Rinternals.R_MissingArg;
                          sEXP = Rinternals.CADR(sEXP);
                          sEXP = PP(simplify(CosSymbol, sEXP, null));
                          return simplify(TimesSymbol, sEXP, paramSEXP2);
                        } 
                        null = Rinternals.R_MissingArg;
                        paramSEXP2 = PP(D(Rinternals.CADR(sEXP), paramSEXP2));
                        paramSEXP2 = PP(simplify(MinusSymbol, paramSEXP2, null));
                        null = Rinternals.R_MissingArg;
                        sEXP = Rinternals.CADR(sEXP);
                        sEXP = PP(simplify(SinSymbol, sEXP, null));
                        return simplify(TimesSymbol, sEXP, paramSEXP2);
                      } 
                      if (Rinternals.Rf_length(sEXP) != 2)
                        Error.Rf_error(new BytePtr("only single-argument calls to log() are supported;\n  maybe use log(x,a) = log(x)/log(a)\000".getBytes(), 0), new Object[0]); 
                      null = Rinternals.CADR(sEXP);
                      sEXP = PP(D(Rinternals.CADR(sEXP), paramSEXP2));
                      return simplify(DivideSymbol, sEXP, null);
                    } 
                    paramSEXP2 = PP(D(Rinternals.CADR(sEXP), paramSEXP2));
                    return simplify(TimesSymbol, sEXP, paramSEXP2);
                  } 
                  if (Rinternals.TYPEOF(Rinternals.CADDR(sEXP)) != 10 && !Rinternals.Rf_isNumeric(Rinternals.CADDR(sEXP))) {
                    SEXP sEXP5 = PP(D(Rinternals.CADR(sEXP), paramSEXP2));
                    null = Rinternals.CADDR(sEXP);
                    null = PP(simplify(TimesSymbol, null, sEXP5));
                    SEXP sEXP6 = PP(Constant(1.0D));
                    sEXP5 = Rinternals.CADDR(sEXP);
                    sEXP6 = PP(simplify(MinusSymbol, sEXP5, sEXP6));
                    sEXP5 = Rinternals.CADR(sEXP);
                    sEXP5 = PP(simplify(PowerSymbol, sEXP5, sEXP6));
                    null = simplify(TimesSymbol, sEXP5, null);
                    Rinternals.Rf_protect(null);
                    paramSEXP2 = PP(D(Rinternals.CADDR(sEXP), paramSEXP2));
                    sEXP6 = Rinternals.R_MissingArg;
                    sEXP5 = Rinternals.CADR(sEXP);
                    sEXP5 = PP(simplify(LogSymbol, sEXP5, sEXP6));
                    paramSEXP2 = PP(simplify(TimesSymbol, sEXP5, paramSEXP2));
                    sEXP5 = Rinternals.CADDR(sEXP);
                    sEXP = Rinternals.CADR(sEXP);
                    sEXP = PP(simplify(PowerSymbol, sEXP, sEXP5));
                    sEXP = simplify(TimesSymbol, sEXP, paramSEXP2);
                    Rinternals.Rf_protect(sEXP);
                    return simplify(PlusSymbol, null, sEXP);
                  } 
                  SEXP sEXP4 = PP(Constant(Rinternals.Rf_asReal(Rinternals.CADDR(sEXP)) - 1.0D));
                  null = Rinternals.CADR(sEXP);
                  null = PP(simplify(PowerSymbol, null, sEXP4));
                  paramSEXP2 = PP(D(Rinternals.CADR(sEXP), paramSEXP2));
                  paramSEXP2 = PP(simplify(TimesSymbol, paramSEXP2, null));
                  sEXP = Rinternals.CADDR(sEXP);
                  return simplify(TimesSymbol, sEXP, paramSEXP2);
                } 
                null = D(Rinternals.CADR(sEXP), paramSEXP2);
                Rinternals.Rf_protect(null);
                paramSEXP2 = D(Rinternals.CADDR(sEXP), paramSEXP2);
                Rinternals.Rf_protect(paramSEXP2);
                SEXP sEXP3 = PP(Constant(2.0D));
                SEXP sEXP2 = Rinternals.CADDR(sEXP);
                sEXP2 = PP(simplify(PowerSymbol, sEXP2, sEXP3));
                sEXP3 = Rinternals.CADR(sEXP);
                paramSEXP2 = PP(simplify(TimesSymbol, sEXP3, paramSEXP2));
                paramSEXP2 = PP(simplify(DivideSymbol, paramSEXP2, sEXP2));
                sEXP = Rinternals.CADDR(sEXP);
                sEXP = PP(simplify(DivideSymbol, null, sEXP));
                return simplify(MinusSymbol, sEXP, paramSEXP2);
              } 
              SEXP sEXP1 = PP(D(Rinternals.CADDR(sEXP), paramSEXP2));
              null = Rinternals.CADR(sEXP);
              null = PP(simplify(TimesSymbol, null, sEXP1));
              sEXP1 = Rinternals.CADDR(sEXP);
              sEXP = PP(D(Rinternals.CADR(sEXP), paramSEXP2));
              sEXP = PP(simplify(TimesSymbol, sEXP, sEXP1));
              return simplify(PlusSymbol, sEXP, null);
            } 
            if (Rinternals.Rf_length(sEXP) != 2) {
              null = PP(D(Rinternals.CADDR(sEXP), paramSEXP2));
              sEXP = PP(D(Rinternals.CADR(sEXP), paramSEXP2));
              return simplify(MinusSymbol, sEXP, null);
            } 
            null = Rinternals.R_MissingArg;
            sEXP = PP(D(Rinternals.CADR(sEXP), paramSEXP2));
            return simplify(MinusSymbol, sEXP, null);
          } 
          if (Rinternals.Rf_length(sEXP) != 2) {
            null = PP(D(Rinternals.CADDR(sEXP), paramSEXP2));
            sEXP = PP(D(Rinternals.CADR(sEXP), paramSEXP2));
            return simplify(PlusSymbol, sEXP, null);
          } 
          return D(Rinternals.CADR(sEXP), paramSEXP2);
        } 
        return D(Rinternals.CADR(sEXP), paramSEXP2);
    } 
    return Constant(Arith.R_NaReal);
  }
  
  public static SEXP DerivAssign(SEXP paramSEXP1, SEXP paramSEXP2) {
    SEXP sEXP1 = Rinternals.R_NilValue;
    paramSEXP2 = Rinternals.Rf_lang3(Rinternals.Rf_install(new BytePtr("<-\000".getBytes(), 0)), sEXP1, paramSEXP2);
    Rinternals.Rf_protect(paramSEXP2);
    paramSEXP1 = Rinternals.Rf_ScalarString(paramSEXP1);
    Rinternals.Rf_protect(paramSEXP1);
    SEXP sEXP2 = Rinternals.R_MissingArg;
    sEXP1 = Rinternals.Rf_install(new BytePtr(".grad\000".getBytes(), 0));
    Rinternals.SETCADR(paramSEXP2, Rinternals.Rf_lang4(Rinternals.R_BracketSymbol, sEXP1, sEXP2, paramSEXP1));
    return paramSEXP2;
  }
  
  public static int FindSubexprs(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3) {
    null = false;
    switch (Rinternals.TYPEOF(paramSEXP1)) {
      case 1:
      case 10:
      case 13:
      case 14:
      case 15:
        return 0;
      case 2:
        if (!Rinternals.Rf_inherits(paramSEXP1, new BytePtr("expression\000".getBytes(), 0))) {
          InvalidExpression((Ptr)new BytePtr("FindSubexprs\000".getBytes(), 0));
        } else {
          return FindSubexprs(Rinternals.CAR(paramSEXP1), paramSEXP2, paramSEXP3);
        } 
      case 6:
        if (Rinternals.CAR(paramSEXP1) != Rinternals.Rf_install(new BytePtr("(\000".getBytes(), 0))) {
          for (SEXP sEXP = Rinternals.CDR(paramSEXP1); sEXP != Rinternals.R_NilValue; sEXP = Rinternals.CDR(sEXP)) {
            int i = FindSubexprs(Rinternals.CAR(sEXP), paramSEXP2, paramSEXP3);
            if (i != 0)
              Rinternals.SETCAR(sEXP, MakeVariable(i, paramSEXP3)); 
          } 
          return Accumulate(paramSEXP1, paramSEXP2);
        } 
        return FindSubexprs(Rinternals.CADR(paramSEXP1), paramSEXP2, paramSEXP3);
    } 
    InvalidExpression((Ptr)new BytePtr("FindSubexprs\000".getBytes(), 0));
    return SYNTHETIC_LOCAL_VARIABLE_3;
  }
  
  public static SEXP HessAssign1(SEXP paramSEXP1, SEXP paramSEXP2) {
    SEXP sEXP1 = Rinternals.R_NilValue;
    paramSEXP2 = Rinternals.Rf_lang3(Rinternals.Rf_install(new BytePtr("<-\000".getBytes(), 0)), sEXP1, paramSEXP2);
    Rinternals.Rf_protect(paramSEXP2);
    paramSEXP1 = Rinternals.Rf_ScalarString(paramSEXP1);
    Rinternals.Rf_protect(paramSEXP1);
    SEXP sEXP2 = Rinternals.R_MissingArg;
    sEXP1 = Rinternals.Rf_install(new BytePtr(".hessian\000".getBytes(), 0));
    Rinternals.SETCADR(paramSEXP2, Rinternals.Rf_lang5(Rinternals.R_BracketSymbol, sEXP1, sEXP2, paramSEXP1, paramSEXP1));
    return paramSEXP2;
  }
  
  public static SEXP HessAssign2(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3) {
    paramSEXP1 = Rinternals.Rf_ScalarString(paramSEXP1);
    Rinternals.Rf_protect(paramSEXP1);
    SEXP sEXP1 = Rinternals.Rf_ScalarString(paramSEXP2);
    Rinternals.Rf_protect(sEXP1);
    SEXP sEXP2 = Rinternals.R_MissingArg;
    paramSEXP2 = Rinternals.Rf_install(new BytePtr(".hessian\000".getBytes(), 0));
    paramSEXP2 = Rinternals.Rf_lang5(Rinternals.R_BracketSymbol, paramSEXP2, sEXP2, paramSEXP1, sEXP1);
    Rinternals.Rf_protect(paramSEXP2);
    SEXP sEXP3 = Rinternals.R_MissingArg;
    sEXP2 = Rinternals.Rf_install(new BytePtr(".hessian\000".getBytes(), 0));
    paramSEXP1 = Rinternals.Rf_lang5(Rinternals.R_BracketSymbol, sEXP2, sEXP3, sEXP1, paramSEXP1);
    Rinternals.Rf_protect(paramSEXP1);
    paramSEXP1 = Rinternals.Rf_lang3(Rinternals.Rf_install(new BytePtr("<-\000".getBytes(), 0)), paramSEXP1, paramSEXP3);
    Rinternals.Rf_protect(paramSEXP1);
    return Rinternals.Rf_lang3(Rinternals.Rf_install(new BytePtr("<-\000".getBytes(), 0)), paramSEXP2, paramSEXP1);
  }
  
  public static void InitDerivSymbols() {
    if (Initialized == 0) {
      ParenSymbol = Rinternals.Rf_install(new BytePtr("(\000".getBytes(), 0));
      PlusSymbol = Rinternals.Rf_install(new BytePtr("+\000".getBytes(), 0));
      MinusSymbol = Rinternals.Rf_install(new BytePtr("-\000".getBytes(), 0));
      TimesSymbol = Rinternals.Rf_install(new BytePtr("*\000".getBytes(), 0));
      DivideSymbol = Rinternals.Rf_install(new BytePtr("/\000".getBytes(), 0));
      PowerSymbol = Rinternals.Rf_install(new BytePtr("^\000".getBytes(), 0));
      ExpSymbol = Rinternals.Rf_install(new BytePtr("exp\000".getBytes(), 0));
      LogSymbol = Rinternals.Rf_install(new BytePtr("log\000".getBytes(), 0));
      SinSymbol = Rinternals.Rf_install(new BytePtr("sin\000".getBytes(), 0));
      CosSymbol = Rinternals.Rf_install(new BytePtr("cos\000".getBytes(), 0));
      TanSymbol = Rinternals.Rf_install(new BytePtr("tan\000".getBytes(), 0));
      SinhSymbol = Rinternals.Rf_install(new BytePtr("sinh\000".getBytes(), 0));
      CoshSymbol = Rinternals.Rf_install(new BytePtr("cosh\000".getBytes(), 0));
      TanhSymbol = Rinternals.Rf_install(new BytePtr("tanh\000".getBytes(), 0));
      SqrtSymbol = Rinternals.Rf_install(new BytePtr("sqrt\000".getBytes(), 0));
      PnormSymbol = Rinternals.Rf_install(new BytePtr("pnorm\000".getBytes(), 0));
      DnormSymbol = Rinternals.Rf_install(new BytePtr("dnorm\000".getBytes(), 0));
      AsinSymbol = Rinternals.Rf_install(new BytePtr("asin\000".getBytes(), 0));
      AcosSymbol = Rinternals.Rf_install(new BytePtr("acos\000".getBytes(), 0));
      AtanSymbol = Rinternals.Rf_install(new BytePtr("atan\000".getBytes(), 0));
      GammaSymbol = Rinternals.Rf_install(new BytePtr("gamma\000".getBytes(), 0));
      LGammaSymbol = Rinternals.Rf_install(new BytePtr("lgamma\000".getBytes(), 0));
      DiGammaSymbol = Rinternals.Rf_install(new BytePtr("digamma\000".getBytes(), 0));
      TriGammaSymbol = Rinternals.Rf_install(new BytePtr("trigamma\000".getBytes(), 0));
      PsiSymbol = Rinternals.Rf_install(new BytePtr("psigamma\000".getBytes(), 0));
      PiSymbol = Rinternals.Rf_install(new BytePtr("pi\000".getBytes(), 0));
      ExpM1Symbol = Rinternals.Rf_install(new BytePtr("expm1\000".getBytes(), 0));
      Log1PSymbol = Rinternals.Rf_install(new BytePtr("log1p\000".getBytes(), 0));
      Log2Symbol = Rinternals.Rf_install(new BytePtr("log2\000".getBytes(), 0));
      Log10Symbol = Rinternals.Rf_install(new BytePtr("log10\000".getBytes(), 0));
      SinPiSymbol = Rinternals.Rf_install(new BytePtr("sinpi\000".getBytes(), 0));
      CosPiSymbol = Rinternals.Rf_install(new BytePtr("cospi\000".getBytes(), 0));
      TanPiSymbol = Rinternals.Rf_install(new BytePtr("tanpi\000".getBytes(), 0));
      FactorialSymbol = Rinternals.Rf_install(new BytePtr("factorial\000".getBytes(), 0));
      LFactorialSymbol = Rinternals.Rf_install(new BytePtr("lfactorial\000".getBytes(), 0));
      Initialized = 1;
    } 
  }
  
  public static void InvalidExpression(Ptr paramPtr) {
    Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("invalid expression in '%s'\000".getBytes(), 0)), new Object[] { paramPtr });
  }
  
  public static SEXP MakeVariable(int paramInt, SEXP paramSEXP) {
    VoidPtr.toPtr(Memory.vmaxget());
    BytePtr bytePtr = Rinternals.Rf_translateChar(Rinternals.STRING_ELT(paramSEXP, 0));
    byte[] arrayOfByte = new byte[64];
    Object[] arrayOfObject = new Object[2];
    arrayOfObject[0] = bytePtr;
    arrayOfObject[1] = Integer.valueOf(paramInt);
    Stdlib.snprintf(new BytePtr(arrayOfByte, 0), 64, new BytePtr("%s%d\000".getBytes(), 0), arrayOfObject);
    return Rinternals.Rf_install(new BytePtr(arrayOfByte, 0));
  }
  
  public static SEXP PP(SEXP paramSEXP) {
    Rinternals.Rf_protect(paramSEXP);
    return paramSEXP;
  }
  
  public static SEXP Prune(SEXP paramSEXP) {
    if (paramSEXP != Rinternals.R_NilValue) {
      Rinternals.SETCDR(paramSEXP, Prune(Rinternals.CDR(paramSEXP)));
      return (Rinternals.CAR(paramSEXP) != Rinternals.R_MissingArg) ? paramSEXP : Rinternals.CDR(paramSEXP);
    } 
    return paramSEXP;
  }
  
  public static SEXP Replace(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3) {
    switch (Rinternals.TYPEOF(paramSEXP3)) {
      case 1:
        return (paramSEXP3 != paramSEXP1) ? paramSEXP3 : paramSEXP2;
      case 2:
      case 6:
        Rinternals.SETCAR(paramSEXP3, Replace(paramSEXP1, paramSEXP2, Rinternals.CAR(paramSEXP3)));
        Rinternals.SETCDR(paramSEXP3, Replace(paramSEXP1, paramSEXP2, Rinternals.CDR(paramSEXP3)));
        return paramSEXP3;
    } 
    return paramSEXP3;
  }
  
  public static SEXP deriv(SEXP paramSEXP) {
    // Byte code:
    //   0: iconst_0
    //   1: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   4: invokeinterface getArray : ()Ljava/lang/Object;
    //   9: checkcast org/renjin/sexp/SEXP
    //   12: astore #7
    //   14: iconst_0
    //   15: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   18: invokeinterface getArray : ()Ljava/lang/Object;
    //   23: checkcast org/renjin/sexp/SEXP
    //   26: astore #7
    //   28: iconst_0
    //   29: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   32: pop
    //   33: iconst_0
    //   34: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   37: pop
    //   38: iconst_0
    //   39: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   42: invokeinterface getArray : ()Ljava/lang/Object;
    //   47: checkcast org/renjin/sexp/SEXP
    //   50: astore #7
    //   52: iconst_0
    //   53: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   56: invokeinterface getArray : ()Ljava/lang/Object;
    //   61: checkcast org/renjin/sexp/SEXP
    //   64: astore #7
    //   66: iconst_0
    //   67: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   70: invokeinterface getArray : ()Ljava/lang/Object;
    //   75: checkcast org/renjin/sexp/SEXP
    //   78: astore #7
    //   80: iconst_0
    //   81: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   84: invokeinterface getArray : ()Ljava/lang/Object;
    //   89: checkcast org/renjin/sexp/SEXP
    //   92: astore #7
    //   94: iconst_0
    //   95: istore #7
    //   97: aload_0
    //   98: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   101: astore_2
    //   102: invokestatic InitDerivSymbols : ()V
    //   105: getstatic org/renjin/gnur/api/Rinternals.R_BraceSymbol : Lorg/renjin/sexp/SEXP;
    //   108: getstatic org/renjin/gnur/api/Rinternals.R_NilValue : Lorg/renjin/sexp/SEXP;
    //   111: invokestatic Rf_lcons : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   114: astore_0
    //   115: aload_0
    //   116: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   119: pop
    //   120: aload_2
    //   121: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   124: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
    //   127: bipush #20
    //   129: if_icmpeq -> 135
    //   132: goto -> 154
    //   135: aload_2
    //   136: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   139: iconst_0
    //   140: invokestatic VECTOR_ELT : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
    //   143: astore #8
    //   145: aload #8
    //   147: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   150: pop
    //   151: goto -> 166
    //   154: aload_2
    //   155: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   158: astore #8
    //   160: aload #8
    //   162: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   165: pop
    //   166: aload_2
    //   167: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   170: astore #9
    //   172: aload #9
    //   174: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   177: astore_2
    //   178: aload_2
    //   179: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
    //   182: bipush #16
    //   184: if_icmpne -> 201
    //   187: aload_2
    //   188: invokestatic Rf_length : (Lorg/renjin/sexp/SEXP;)I
    //   191: istore #7
    //   193: iload #7
    //   195: ifle -> 201
    //   198: goto -> 242
    //   201: new org/renjin/gcc/runtime/BytePtr
    //   204: dup
    //   205: ldc_w 'stats '
    //   208: invokevirtual getBytes : ()[B
    //   211: iconst_0
    //   212: invokespecial <init> : ([BI)V
    //   215: new org/renjin/gcc/runtime/BytePtr
    //   218: dup
    //   219: ldc_w 'invalid variable names '
    //   222: invokevirtual getBytes : ()[B
    //   225: iconst_0
    //   226: invokespecial <init> : ([BI)V
    //   229: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
    //   232: checkcast org/renjin/gcc/runtime/BytePtr
    //   235: iconst_0
    //   236: anewarray java/lang/Object
    //   239: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
    //   242: aload #9
    //   244: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   247: dup
    //   248: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   251: astore #9
    //   253: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   256: astore #10
    //   258: aload #10
    //   260: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   263: astore #5
    //   265: aload #5
    //   267: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
    //   270: bipush #16
    //   272: if_icmpne -> 312
    //   275: aload #5
    //   277: invokestatic Rf_length : (Lorg/renjin/sexp/SEXP;)I
    //   280: ifle -> 312
    //   283: aload #5
    //   285: iconst_0
    //   286: invokestatic STRING_ELT : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
    //   289: invokestatic Rf_length : (Lorg/renjin/sexp/SEXP;)I
    //   292: ifle -> 312
    //   295: aload #5
    //   297: iconst_0
    //   298: invokestatic STRING_ELT : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
    //   301: invokestatic Rf_length : (Lorg/renjin/sexp/SEXP;)I
    //   304: bipush #60
    //   306: if_icmpgt -> 312
    //   309: goto -> 353
    //   312: new org/renjin/gcc/runtime/BytePtr
    //   315: dup
    //   316: ldc_w 'stats '
    //   319: invokevirtual getBytes : ()[B
    //   322: iconst_0
    //   323: invokespecial <init> : ([BI)V
    //   326: new org/renjin/gcc/runtime/BytePtr
    //   329: dup
    //   330: ldc_w 'invalid tag '
    //   333: invokevirtual getBytes : ()[B
    //   336: iconst_0
    //   337: invokespecial <init> : ([BI)V
    //   340: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
    //   343: checkcast org/renjin/gcc/runtime/BytePtr
    //   346: iconst_0
    //   347: anewarray java/lang/Object
    //   350: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
    //   353: aload #10
    //   355: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   358: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   361: invokestatic Rf_asLogical : (Lorg/renjin/sexp/SEXP;)I
    //   364: istore #10
    //   366: aload #8
    //   368: invokestatic Rf_duplicate : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   371: dup
    //   372: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   375: pop
    //   376: aload_0
    //   377: aload #5
    //   379: invokestatic FindSubexprs : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)I
    //   382: istore #6
    //   384: iload #7
    //   386: iconst_4
    //   387: imul
    //   388: invokestatic malloc : (I)Lorg/renjin/gcc/runtime/IntPtr;
    //   391: astore_3
    //   392: iload #10
    //   394: ifne -> 400
    //   397: goto -> 418
    //   400: iload #7
    //   402: iconst_1
    //   403: iadd
    //   404: iload #7
    //   406: imul
    //   407: iconst_2
    //   408: idiv
    //   409: iconst_4
    //   410: imul
    //   411: invokestatic malloc : (I)Lorg/renjin/gcc/runtime/IntPtr;
    //   414: astore_1
    //   415: goto -> 420
    //   418: aload_3
    //   419: astore_1
    //   420: iconst_0
    //   421: istore #4
    //   423: iconst_0
    //   424: istore #11
    //   426: goto -> 576
    //   429: aload #8
    //   431: invokestatic Rf_duplicate : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   434: dup
    //   435: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   438: pop
    //   439: aload_2
    //   440: iload #4
    //   442: invokestatic STRING_ELT : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
    //   445: invokestatic Rf_installTrChar : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   448: invokestatic D : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   451: astore #12
    //   453: aload #12
    //   455: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   458: pop
    //   459: aload #12
    //   461: invokestatic Rf_duplicate : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   464: dup
    //   465: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   468: pop
    //   469: aload_3
    //   470: iconst_0
    //   471: iload #4
    //   473: iconst_4
    //   474: imul
    //   475: iadd
    //   476: aload #12
    //   478: aload_0
    //   479: aload #5
    //   481: invokestatic FindSubexprs : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)I
    //   484: invokeinterface setInt : (II)V
    //   489: invokestatic Rf_duplicate : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   492: astore #12
    //   494: aload #12
    //   496: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   499: pop
    //   500: iload #10
    //   502: ifne -> 508
    //   505: goto -> 573
    //   508: iload #4
    //   510: istore #13
    //   512: goto -> 566
    //   515: aload_1
    //   516: iconst_0
    //   517: iload #11
    //   519: iconst_4
    //   520: imul
    //   521: iadd
    //   522: aload #12
    //   524: invokestatic Rf_duplicate : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   527: dup
    //   528: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   531: pop
    //   532: aload_2
    //   533: iload #13
    //   535: invokestatic STRING_ELT : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
    //   538: invokestatic Rf_installTrChar : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   541: invokestatic D : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   544: dup
    //   545: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   548: pop
    //   549: aload_0
    //   550: aload #5
    //   552: invokestatic FindSubexprs : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)I
    //   555: invokeinterface setInt : (II)V
    //   560: iinc #11, 1
    //   563: iinc #13, 1
    //   566: iload #13
    //   568: iload #7
    //   570: if_icmplt -> 515
    //   573: iinc #4, 1
    //   576: iload #4
    //   578: iload #7
    //   580: if_icmplt -> 429
    //   583: aload_0
    //   584: invokestatic Rf_length : (Lorg/renjin/sexp/SEXP;)I
    //   587: iconst_m1
    //   588: iadd
    //   589: istore #4
    //   591: iload #6
    //   593: ifne -> 599
    //   596: goto -> 614
    //   599: iload #6
    //   601: aload #5
    //   603: invokestatic MakeVariable : (ILorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   606: aload_0
    //   607: invokestatic Accumulate2 : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)I
    //   610: pop
    //   611: goto -> 630
    //   614: aload #8
    //   616: invokestatic Rf_duplicate : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   619: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   622: pop
    //   623: aload #8
    //   625: aload_0
    //   626: invokestatic Accumulate2 : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)I
    //   629: pop
    //   630: getstatic org/renjin/gnur/api/Rinternals.R_NilValue : Lorg/renjin/sexp/SEXP;
    //   633: aload_0
    //   634: invokestatic Accumulate2 : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)I
    //   637: pop
    //   638: iload #10
    //   640: ifne -> 646
    //   643: goto -> 654
    //   646: getstatic org/renjin/gnur/api/Rinternals.R_NilValue : Lorg/renjin/sexp/SEXP;
    //   649: aload_0
    //   650: invokestatic Accumulate2 : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)I
    //   653: pop
    //   654: iconst_0
    //   655: istore #6
    //   657: iconst_0
    //   658: istore #11
    //   660: goto -> 1009
    //   663: aload_3
    //   664: iconst_0
    //   665: iload #6
    //   667: iconst_4
    //   668: imul
    //   669: iadd
    //   670: invokeinterface getInt : (I)I
    //   675: ifne -> 681
    //   678: goto -> 839
    //   681: aload_3
    //   682: iconst_0
    //   683: iload #6
    //   685: iconst_4
    //   686: imul
    //   687: iadd
    //   688: invokeinterface getInt : (I)I
    //   693: aload #5
    //   695: invokestatic MakeVariable : (ILorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   698: aload_0
    //   699: invokestatic Accumulate2 : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)I
    //   702: pop
    //   703: iload #10
    //   705: ifne -> 711
    //   708: goto -> 1006
    //   711: aload #8
    //   713: invokestatic Rf_duplicate : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   716: dup
    //   717: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   720: pop
    //   721: aload_2
    //   722: iload #6
    //   724: invokestatic STRING_ELT : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
    //   727: invokestatic Rf_installTrChar : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   730: invokestatic D : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   733: astore #12
    //   735: aload #12
    //   737: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   740: pop
    //   741: iload #6
    //   743: istore #13
    //   745: goto -> 829
    //   748: aload_1
    //   749: iconst_0
    //   750: iload #11
    //   752: iconst_4
    //   753: imul
    //   754: iadd
    //   755: invokeinterface getInt : (I)I
    //   760: ifne -> 766
    //   763: goto -> 791
    //   766: aload_1
    //   767: iconst_0
    //   768: iload #11
    //   770: iconst_4
    //   771: imul
    //   772: iadd
    //   773: invokeinterface getInt : (I)I
    //   778: aload #5
    //   780: invokestatic MakeVariable : (ILorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   783: aload_0
    //   784: invokestatic Accumulate2 : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)I
    //   787: pop
    //   788: goto -> 823
    //   791: aload #12
    //   793: invokestatic Rf_duplicate : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   796: dup
    //   797: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   800: pop
    //   801: aload_2
    //   802: iload #13
    //   804: invokestatic STRING_ELT : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
    //   807: invokestatic Rf_installTrChar : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   810: invokestatic D : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   813: dup
    //   814: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   817: pop
    //   818: aload_0
    //   819: invokestatic Accumulate2 : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)I
    //   822: pop
    //   823: iinc #11, 1
    //   826: iinc #13, 1
    //   829: iload #13
    //   831: iload #7
    //   833: if_icmplt -> 748
    //   836: goto -> 1006
    //   839: aload #8
    //   841: invokestatic Rf_duplicate : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   844: dup
    //   845: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   848: pop
    //   849: aload_2
    //   850: iload #6
    //   852: invokestatic STRING_ELT : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
    //   855: invokestatic Rf_installTrChar : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   858: invokestatic D : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   861: astore #12
    //   863: aload #12
    //   865: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   868: pop
    //   869: aload #12
    //   871: aload_0
    //   872: invokestatic Accumulate2 : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)I
    //   875: pop
    //   876: iload #10
    //   878: ifne -> 884
    //   881: goto -> 1006
    //   884: iload #6
    //   886: istore #13
    //   888: goto -> 999
    //   891: aload_1
    //   892: iconst_0
    //   893: iload #11
    //   895: iconst_4
    //   896: imul
    //   897: iadd
    //   898: invokeinterface getInt : (I)I
    //   903: ifne -> 909
    //   906: goto -> 934
    //   909: aload_1
    //   910: iconst_0
    //   911: iload #11
    //   913: iconst_4
    //   914: imul
    //   915: iadd
    //   916: invokeinterface getInt : (I)I
    //   921: aload #5
    //   923: invokestatic MakeVariable : (ILorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   926: aload_0
    //   927: invokestatic Accumulate2 : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)I
    //   930: pop
    //   931: goto -> 993
    //   934: aload #12
    //   936: invokestatic Rf_duplicate : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   939: dup
    //   940: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   943: pop
    //   944: aload_2
    //   945: iload #13
    //   947: invokestatic STRING_ELT : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
    //   950: invokestatic Rf_installTrChar : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   953: invokestatic D : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   956: astore #14
    //   958: aload #14
    //   960: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   963: pop
    //   964: aload #14
    //   966: invokestatic isZero : (Lorg/renjin/sexp/SEXP;)I
    //   969: ifne -> 975
    //   972: goto -> 986
    //   975: getstatic org/renjin/gnur/api/Rinternals.R_MissingArg : Lorg/renjin/sexp/SEXP;
    //   978: aload_0
    //   979: invokestatic Accumulate2 : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)I
    //   982: pop
    //   983: goto -> 993
    //   986: aload #14
    //   988: aload_0
    //   989: invokestatic Accumulate2 : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)I
    //   992: pop
    //   993: iinc #11, 1
    //   996: iinc #13, 1
    //   999: iload #13
    //   1001: iload #7
    //   1003: if_icmplt -> 891
    //   1006: iinc #6, 1
    //   1009: iload #6
    //   1011: iload #7
    //   1013: if_icmplt -> 663
    //   1016: getstatic org/renjin/gnur/api/Rinternals.R_NilValue : Lorg/renjin/sexp/SEXP;
    //   1019: aload_0
    //   1020: invokestatic Accumulate2 : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)I
    //   1023: pop
    //   1024: getstatic org/renjin/gnur/api/Rinternals.R_NilValue : Lorg/renjin/sexp/SEXP;
    //   1027: aload_0
    //   1028: invokestatic Accumulate2 : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)I
    //   1031: pop
    //   1032: iload #10
    //   1034: ifne -> 1040
    //   1037: goto -> 1048
    //   1040: getstatic org/renjin/gnur/api/Rinternals.R_NilValue : Lorg/renjin/sexp/SEXP;
    //   1043: aload_0
    //   1044: invokestatic Accumulate2 : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)I
    //   1047: pop
    //   1048: iconst_0
    //   1049: istore_3
    //   1050: aload_0
    //   1051: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1054: astore #8
    //   1056: goto -> 1191
    //   1059: aload #8
    //   1061: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1064: astore_1
    //   1065: iload_3
    //   1066: iconst_1
    //   1067: iadd
    //   1068: aload #5
    //   1070: invokestatic MakeVariable : (ILorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1073: aload_1
    //   1074: invokestatic CountOccurrences : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)I
    //   1077: iconst_1
    //   1078: if_icmple -> 1084
    //   1081: goto -> 1129
    //   1084: aload #8
    //   1086: aload #8
    //   1088: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1091: astore #6
    //   1093: aload #8
    //   1095: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1098: astore_1
    //   1099: iload_3
    //   1100: iconst_1
    //   1101: iadd
    //   1102: aload #5
    //   1104: invokestatic MakeVariable : (ILorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1107: aload_1
    //   1108: aload #6
    //   1110: invokestatic Replace : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1113: invokestatic SETCDR : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1116: pop
    //   1117: aload #8
    //   1119: getstatic org/renjin/gnur/api/Rinternals.R_MissingArg : Lorg/renjin/sexp/SEXP;
    //   1122: invokestatic SETCAR : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1125: pop
    //   1126: goto -> 1181
    //   1129: aload #8
    //   1131: iload_3
    //   1132: iconst_1
    //   1133: iadd
    //   1134: aload #5
    //   1136: invokestatic MakeVariable : (ILorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1139: astore_1
    //   1140: aload_1
    //   1141: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1144: pop
    //   1145: aload #8
    //   1147: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1150: invokestatic AddParens : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1153: astore #6
    //   1155: new org/renjin/gcc/runtime/BytePtr
    //   1158: dup
    //   1159: ldc '<- '
    //   1161: invokevirtual getBytes : ()[B
    //   1164: iconst_0
    //   1165: invokespecial <init> : ([BI)V
    //   1168: invokestatic Rf_install : (Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/sexp/SEXP;
    //   1171: aload_1
    //   1172: aload #6
    //   1174: invokestatic Rf_lang3 : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1177: invokestatic SETCAR : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1180: pop
    //   1181: iinc #3, 1
    //   1184: aload #8
    //   1186: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1189: astore #8
    //   1191: iload_3
    //   1192: iload #4
    //   1194: if_icmplt -> 1059
    //   1197: aload #8
    //   1199: aload #8
    //   1201: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1204: invokestatic AddParens : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1207: astore #4
    //   1209: new org/renjin/gcc/runtime/BytePtr
    //   1212: dup
    //   1213: ldc '.value '
    //   1215: invokevirtual getBytes : ()[B
    //   1218: iconst_0
    //   1219: invokespecial <init> : ([BI)V
    //   1222: invokestatic Rf_install : (Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/sexp/SEXP;
    //   1225: astore #5
    //   1227: new org/renjin/gcc/runtime/BytePtr
    //   1230: dup
    //   1231: ldc '<- '
    //   1233: invokevirtual getBytes : ()[B
    //   1236: iconst_0
    //   1237: invokespecial <init> : ([BI)V
    //   1240: invokestatic Rf_install : (Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/sexp/SEXP;
    //   1243: aload #5
    //   1245: aload #4
    //   1247: invokestatic Rf_lang3 : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1250: invokestatic SETCAR : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1253: pop
    //   1254: aload #8
    //   1256: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1259: dup
    //   1260: aload_2
    //   1261: invokestatic CreateGrad : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1264: invokestatic SETCAR : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1267: pop
    //   1268: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1271: astore #5
    //   1273: iload #10
    //   1275: ifne -> 1281
    //   1278: goto -> 1298
    //   1281: aload #5
    //   1283: aload_2
    //   1284: invokestatic CreateHess : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1287: invokestatic SETCAR : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1290: pop
    //   1291: aload #5
    //   1293: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1296: astore #5
    //   1298: iconst_0
    //   1299: istore #8
    //   1301: goto -> 1455
    //   1304: aload #5
    //   1306: aload #5
    //   1308: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1311: invokestatic AddParens : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1314: astore #4
    //   1316: aload_2
    //   1317: iload #8
    //   1319: invokestatic STRING_ELT : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
    //   1322: aload #4
    //   1324: invokestatic DerivAssign : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1327: invokestatic SETCAR : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1330: pop
    //   1331: aload #5
    //   1333: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1336: astore #5
    //   1338: iload #10
    //   1340: ifne -> 1346
    //   1343: goto -> 1452
    //   1346: iload #8
    //   1348: istore #4
    //   1350: goto -> 1445
    //   1353: aload #5
    //   1355: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1358: getstatic org/renjin/gnur/api/Rinternals.R_MissingArg : Lorg/renjin/sexp/SEXP;
    //   1361: if_acmpeq -> 1435
    //   1364: iload #8
    //   1366: iload #4
    //   1368: if_icmpeq -> 1374
    //   1371: goto -> 1402
    //   1374: aload #5
    //   1376: aload #5
    //   1378: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1381: invokestatic AddParens : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1384: astore_3
    //   1385: aload_2
    //   1386: iload #8
    //   1388: invokestatic STRING_ELT : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
    //   1391: aload_3
    //   1392: invokestatic HessAssign1 : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1395: invokestatic SETCAR : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1398: pop
    //   1399: goto -> 1435
    //   1402: aload #5
    //   1404: aload #5
    //   1406: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1409: invokestatic AddParens : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1412: astore_1
    //   1413: aload_2
    //   1414: iload #4
    //   1416: invokestatic STRING_ELT : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
    //   1419: astore_3
    //   1420: aload_2
    //   1421: iload #8
    //   1423: invokestatic STRING_ELT : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
    //   1426: aload_3
    //   1427: aload_1
    //   1428: invokestatic HessAssign2 : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1431: invokestatic SETCAR : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1434: pop
    //   1435: aload #5
    //   1437: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1440: astore #5
    //   1442: iinc #4, 1
    //   1445: iload #4
    //   1447: iload #7
    //   1449: if_icmplt -> 1353
    //   1452: iinc #8, 1
    //   1455: iload #8
    //   1457: iload #7
    //   1459: if_icmplt -> 1304
    //   1462: aload #5
    //   1464: invokestatic AddGrad : ()Lorg/renjin/sexp/SEXP;
    //   1467: invokestatic SETCAR : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1470: pop
    //   1471: aload #5
    //   1473: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1476: astore #7
    //   1478: iload #10
    //   1480: ifne -> 1486
    //   1483: goto -> 1502
    //   1486: aload #7
    //   1488: invokestatic AddHess : ()Lorg/renjin/sexp/SEXP;
    //   1491: invokestatic SETCAR : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1494: pop
    //   1495: aload #7
    //   1497: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1500: astore #7
    //   1502: aload #7
    //   1504: new org/renjin/gcc/runtime/BytePtr
    //   1507: dup
    //   1508: ldc '.value '
    //   1510: invokevirtual getBytes : ()[B
    //   1513: iconst_0
    //   1514: invokespecial <init> : ([BI)V
    //   1517: invokestatic Rf_install : (Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/sexp/SEXP;
    //   1520: invokestatic SETCAR : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1523: pop
    //   1524: aload_0
    //   1525: aload_0
    //   1526: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1529: invokestatic Prune : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1532: invokestatic SETCDR : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1535: pop
    //   1536: aload #9
    //   1538: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
    //   1541: bipush #10
    //   1543: if_icmpeq -> 1549
    //   1546: goto -> 1568
    //   1549: aload #9
    //   1551: invokestatic LOGICAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/IntPtr;
    //   1554: invokeinterface getInt : ()I
    //   1559: ifne -> 1565
    //   1562: goto -> 1568
    //   1565: aload_2
    //   1566: astore #9
    //   1568: aload #9
    //   1570: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
    //   1573: iconst_3
    //   1574: if_icmpeq -> 1580
    //   1577: goto -> 1614
    //   1580: iconst_3
    //   1581: invokestatic Rf_allocSExp : (I)Lorg/renjin/sexp/SEXP;
    //   1584: astore_2
    //   1585: aload_2
    //   1586: aload #9
    //   1588: invokestatic FORMALS : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1591: invokestatic SET_FORMALS : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)V
    //   1594: aload_2
    //   1595: aload #9
    //   1597: invokestatic CLOENV : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1600: invokestatic SET_CLOENV : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)V
    //   1603: aload_2
    //   1604: astore #7
    //   1606: aload_2
    //   1607: aload_0
    //   1608: invokestatic SET_BODY : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)V
    //   1611: goto -> 1753
    //   1614: aload #9
    //   1616: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
    //   1619: bipush #16
    //   1621: if_icmpeq -> 1627
    //   1624: goto -> 1737
    //   1627: aload #9
    //   1629: invokestatic Rf_duplicate : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1632: astore_2
    //   1633: aload_2
    //   1634: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1637: pop
    //   1638: iconst_3
    //   1639: invokestatic Rf_allocSExp : (I)Lorg/renjin/sexp/SEXP;
    //   1642: astore #7
    //   1644: aload #7
    //   1646: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1649: pop
    //   1650: aload_2
    //   1651: invokestatic Rf_length : (Lorg/renjin/sexp/SEXP;)I
    //   1654: invokestatic Rf_allocList : (I)Lorg/renjin/sexp/SEXP;
    //   1657: astore #9
    //   1659: aload #9
    //   1661: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1664: pop
    //   1665: aload #7
    //   1667: aload #9
    //   1669: invokestatic SET_FORMALS : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)V
    //   1672: iconst_0
    //   1673: istore #10
    //   1675: goto -> 1711
    //   1678: aload #9
    //   1680: aload_2
    //   1681: iload #10
    //   1683: invokestatic STRING_ELT : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
    //   1686: invokestatic Rf_installTrChar : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1689: invokestatic SET_TAG : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)V
    //   1692: aload #9
    //   1694: getstatic org/renjin/gnur/api/Rinternals.R_MissingArg : Lorg/renjin/sexp/SEXP;
    //   1697: invokestatic SETCAR : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1700: pop
    //   1701: aload #9
    //   1703: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1706: astore #9
    //   1708: iinc #10, 1
    //   1711: aload_2
    //   1712: invokestatic Rf_length : (Lorg/renjin/sexp/SEXP;)I
    //   1715: iload #10
    //   1717: if_icmpgt -> 1678
    //   1720: aload #7
    //   1722: aload_0
    //   1723: invokestatic SET_BODY : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)V
    //   1726: aload #7
    //   1728: invokestatic R_GlobalEnv : ()Lorg/renjin/sexp/SEXP;
    //   1731: invokestatic SET_CLOENV : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)V
    //   1734: goto -> 1753
    //   1737: bipush #20
    //   1739: iconst_1
    //   1740: invokestatic Rf_allocVector : (II)Lorg/renjin/sexp/SEXP;
    //   1743: astore #7
    //   1745: aload #7
    //   1747: iconst_0
    //   1748: aload_0
    //   1749: invokestatic SET_VECTOR_ELT : (Lorg/renjin/sexp/SEXP;ILorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1752: pop
    //   1753: aload #7
    //   1755: areturn
  }
  
  public static SEXP doD(SEXP paramSEXP) {
    SEXP sEXP2 = Rinternals.CDR(paramSEXP);
    if (Rinternals.TYPEOF(Rinternals.CAR(sEXP2)) != 20) {
      paramSEXP = Rinternals.CAR(sEXP2);
    } else {
      paramSEXP = Rinternals.VECTOR_ELT(Rinternals.CAR(sEXP2), 0);
    } 
    if (!Rinternals.Rf_isLanguage(paramSEXP) && Rinternals.TYPEOF(paramSEXP) != 1 && !Rinternals.Rf_isNumeric(paramSEXP) && Rinternals.TYPEOF(paramSEXP) != 15) {
      BytePtr bytePtr = Rinternals.Rf_type2char(Rinternals.TYPEOF(paramSEXP));
      Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("expression must not be type '%s'\000".getBytes(), 0)), new Object[] { bytePtr });
    } 
    SEXP sEXP1 = Rinternals.CADR(sEXP2);
    if (Rinternals.TYPEOF(sEXP1) != 16 || Rinternals.Rf_length(sEXP1) <= 0)
      Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("variable must be a character string\000".getBytes(), 0)), new Object[0]); 
    if (Rinternals.Rf_length(sEXP1) > 1)
      Error.Rf_warning(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("only the first element is used as variable name\000".getBytes(), 0)), new Object[0]); 
    InitDerivSymbols();
    Rinternals.Rf_protect(D(paramSEXP, Defn.Rf_installTrChar(Rinternals.STRING_ELT(sEXP1, 0))));
    return AddParens(D(paramSEXP, Defn.Rf_installTrChar(Rinternals.STRING_ELT(sEXP1, 0))));
  }
  
  public static int equal(SEXP paramSEXP1, SEXP paramSEXP2) {
    // Byte code:
    //   0: aload_0
    //   1: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
    //   4: aload_1
    //   5: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
    //   8: if_icmpeq -> 14
    //   11: goto -> 317
    //   14: aload_0
    //   15: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
    //   18: lookupswitch default -> 297, 0 -> 92, 1 -> 97, 2 -> 247, 6 -> 247, 10 -> 114, 13 -> 114, 14 -> 147, 15 -> 181
    //   92: iconst_1
    //   93: istore_0
    //   94: goto -> 319
    //   97: aload_0
    //   98: aload_1
    //   99: if_acmpeq -> 107
    //   102: iconst_0
    //   103: istore_0
    //   104: goto -> 109
    //   107: iconst_1
    //   108: istore_0
    //   109: iload_0
    //   110: istore_0
    //   111: goto -> 319
    //   114: aload_0
    //   115: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
    //   118: invokeinterface getInt : ()I
    //   123: aload_1
    //   124: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
    //   127: invokeinterface getInt : ()I
    //   132: if_icmpeq -> 140
    //   135: iconst_0
    //   136: istore_0
    //   137: goto -> 142
    //   140: iconst_1
    //   141: istore_0
    //   142: iload_0
    //   143: istore_0
    //   144: goto -> 319
    //   147: aload_0
    //   148: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
    //   151: invokeinterface getDouble : ()D
    //   156: aload_1
    //   157: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
    //   160: invokeinterface getDouble : ()D
    //   165: dcmpl
    //   166: ifeq -> 174
    //   169: iconst_0
    //   170: istore_0
    //   171: goto -> 176
    //   174: iconst_1
    //   175: istore_0
    //   176: iload_0
    //   177: istore_0
    //   178: goto -> 319
    //   181: aload_0
    //   182: invokestatic COMPLEX : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/DoublePtr;
    //   185: invokeinterface getDouble : ()D
    //   190: aload_1
    //   191: invokestatic COMPLEX : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/DoublePtr;
    //   194: invokeinterface getDouble : ()D
    //   199: dcmpl
    //   200: ifeq -> 206
    //   203: goto -> 240
    //   206: aload_0
    //   207: invokestatic COMPLEX : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/DoublePtr;
    //   210: bipush #8
    //   212: invokeinterface getDouble : (I)D
    //   217: aload_1
    //   218: invokestatic COMPLEX : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/DoublePtr;
    //   221: bipush #8
    //   223: invokeinterface getDouble : (I)D
    //   228: dcmpl
    //   229: ifeq -> 235
    //   232: goto -> 240
    //   235: iconst_1
    //   236: istore_0
    //   237: goto -> 242
    //   240: iconst_0
    //   241: istore_0
    //   242: iload_0
    //   243: istore_0
    //   244: goto -> 319
    //   247: aload_1
    //   248: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   251: astore_2
    //   252: aload_0
    //   253: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   256: aload_2
    //   257: invokestatic equal : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)I
    //   260: ifne -> 266
    //   263: goto -> 290
    //   266: aload_1
    //   267: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   270: astore_1
    //   271: aload_0
    //   272: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   275: aload_1
    //   276: invokestatic equal : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)I
    //   279: ifne -> 285
    //   282: goto -> 290
    //   285: iconst_1
    //   286: istore_0
    //   287: goto -> 292
    //   290: iconst_0
    //   291: istore_0
    //   292: iload_0
    //   293: istore_0
    //   294: goto -> 319
    //   297: new org/renjin/gcc/runtime/BytePtr
    //   300: dup
    //   301: ldc_w 'equal '
    //   304: invokevirtual getBytes : ()[B
    //   307: iconst_0
    //   308: invokespecial <init> : ([BI)V
    //   311: checkcast org/renjin/gcc/runtime/Ptr
    //   314: invokestatic InvalidExpression : (Lorg/renjin/gcc/runtime/Ptr;)V
    //   317: iconst_0
    //   318: istore_0
    //   319: iload_0
    //   320: ireturn
  }
  
  public static int isDivideForm(SEXP paramSEXP) {
    return (Rinternals.TYPEOF(paramSEXP) != 6 || Rinternals.Rf_length(paramSEXP) != 3 || Rinternals.CAR(paramSEXP) != DivideSymbol) ? 0 : 1;
  }
  
  public static int isMinusForm(SEXP paramSEXP) {
    return (Rinternals.TYPEOF(paramSEXP) != 6 || Rinternals.Rf_length(paramSEXP) != 3 || Rinternals.CAR(paramSEXP) != MinusSymbol) ? 0 : 1;
  }
  
  public static int isOne(SEXP paramSEXP) {
    boolean bool;
    if (Rinternals.Rf_asReal(paramSEXP) != 1.0D) {
      bool = false;
    } else {
      bool = true;
    } 
    return bool;
  }
  
  public static int isPlusForm(SEXP paramSEXP) {
    return (Rinternals.TYPEOF(paramSEXP) != 6 || Rinternals.Rf_length(paramSEXP) != 3 || Rinternals.CAR(paramSEXP) != PlusSymbol) ? 0 : 1;
  }
  
  public static int isPowerForm(SEXP paramSEXP) {
    return (Rinternals.TYPEOF(paramSEXP) != 6 || Rinternals.Rf_length(paramSEXP) != 3 || Rinternals.CAR(paramSEXP) != PowerSymbol) ? 0 : 1;
  }
  
  public static int isTimesForm(SEXP paramSEXP) {
    return (Rinternals.TYPEOF(paramSEXP) != 6 || Rinternals.Rf_length(paramSEXP) != 3 || Rinternals.CAR(paramSEXP) != TimesSymbol) ? 0 : 1;
  }
  
  public static int isUminus(SEXP paramSEXP) {
    if (Rinternals.TYPEOF(paramSEXP) == 6 && Rinternals.CAR(paramSEXP) == MinusSymbol) {
      switch (Rinternals.Rf_length(paramSEXP)) {
        case 2:
          return 1;
        case 3:
          return (Rinternals.CADDR(paramSEXP) != Rinternals.R_MissingArg) ? 0 : 1;
      } 
      Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("invalid form in unary minus check\000".getBytes(), 0)), new Object[0]);
    } 
    return 0;
  }
  
  public static int isZero(SEXP paramSEXP) {
    boolean bool;
    if (Rinternals.Rf_asReal(paramSEXP) != 0.0D) {
      bool = false;
    } else {
      bool = true;
    } 
    return bool;
  }
  
  public static SEXP simplify(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3) {
    if (paramSEXP1 != PlusSymbol) {
      if (paramSEXP1 != MinusSymbol) {
        if (paramSEXP1 != TimesSymbol) {
          if (paramSEXP1 != DivideSymbol)
            return (paramSEXP1 != PowerSymbol) ? ((paramSEXP1 != ExpSymbol) ? ((paramSEXP1 != LogSymbol) ? ((paramSEXP1 != CosSymbol) ? ((paramSEXP1 != SinSymbol) ? ((paramSEXP1 != TanSymbol) ? ((paramSEXP1 != CoshSymbol) ? ((paramSEXP1 != SinhSymbol) ? ((paramSEXP1 != TanhSymbol) ? ((paramSEXP1 != SqrtSymbol) ? ((paramSEXP1 != PnormSymbol) ? ((paramSEXP1 != DnormSymbol) ? ((paramSEXP1 != AsinSymbol) ? ((paramSEXP1 != AcosSymbol) ? ((paramSEXP1 != AtanSymbol) ? ((paramSEXP1 != GammaSymbol) ? ((paramSEXP1 != LGammaSymbol) ? ((paramSEXP1 != DiGammaSymbol) ? ((paramSEXP1 != TriGammaSymbol) ? ((paramSEXP1 != PsiSymbol) ? ((paramSEXP1 != ExpM1Symbol) ? ((paramSEXP1 != LogSymbol) ? ((paramSEXP1 != Log2Symbol) ? ((paramSEXP1 != Log10Symbol) ? ((paramSEXP1 != CosPiSymbol) ? ((paramSEXP1 != SinPiSymbol) ? ((paramSEXP1 != TanPiSymbol) ? ((paramSEXP1 != FactorialSymbol) ? ((paramSEXP1 != LFactorialSymbol) ? Constant(Arith.R_NaReal) : Rinternals.Rf_lang2(LFactorialSymbol, paramSEXP2)) : Rinternals.Rf_lang2(FactorialSymbol, paramSEXP2)) : Rinternals.Rf_lang2(TanPiSymbol, paramSEXP2)) : Rinternals.Rf_lang2(SinPiSymbol, paramSEXP2)) : Rinternals.Rf_lang2(CosPiSymbol, paramSEXP2)) : Rinternals.Rf_lang2(Log10Symbol, paramSEXP2)) : Rinternals.Rf_lang2(Log2Symbol, paramSEXP2)) : Rinternals.Rf_lang2(Log1PSymbol, paramSEXP2)) : Rinternals.Rf_lang2(ExpM1Symbol, paramSEXP2)) : ((paramSEXP3 != Rinternals.R_MissingArg) ? Rinternals.Rf_lang3(PsiSymbol, paramSEXP2, paramSEXP3) : Rinternals.Rf_lang2(PsiSymbol, paramSEXP2))) : Rinternals.Rf_lang2(TriGammaSymbol, paramSEXP2)) : Rinternals.Rf_lang2(DiGammaSymbol, paramSEXP2)) : Rinternals.Rf_lang2(LGammaSymbol, paramSEXP2)) : Rinternals.Rf_lang2(GammaSymbol, paramSEXP2)) : Rinternals.Rf_lang2(AtanSymbol, paramSEXP2)) : Rinternals.Rf_lang2(AcosSymbol, paramSEXP2)) : Rinternals.Rf_lang2(AsinSymbol, paramSEXP2)) : Rinternals.Rf_lang2(DnormSymbol, paramSEXP2)) : Rinternals.Rf_lang2(PnormSymbol, paramSEXP2)) : Rinternals.Rf_lang2(SqrtSymbol, paramSEXP2)) : Rinternals.Rf_lang2(TanhSymbol, paramSEXP2)) : Rinternals.Rf_lang2(SinhSymbol, paramSEXP2)) : Rinternals.Rf_lang2(CoshSymbol, paramSEXP2)) : Rinternals.Rf_lang2(TanSymbol, paramSEXP2)) : Rinternals.Rf_lang2(SinSymbol, paramSEXP2)) : Rinternals.Rf_lang2(CosSymbol, paramSEXP2)) : Rinternals.Rf_lang2(LogSymbol, paramSEXP2)) : Rinternals.Rf_lang2(ExpSymbol, paramSEXP2)) : ((isZero(paramSEXP3) == 0) ? ((isZero(paramSEXP2) == 0) ? ((isOne(paramSEXP2) == 0) ? ((isOne(paramSEXP3) == 0) ? Rinternals.Rf_lang3(PowerSymbol, paramSEXP2, paramSEXP3) : paramSEXP2) : Constant(1.0D)) : Constant(0.0D)) : Constant(1.0D)); 
          if (isZero(paramSEXP2) == 0) {
            if (isZero(paramSEXP3) == 0) {
              if (isOne(paramSEXP3) == 0) {
                if (isUminus(paramSEXP2) == 0) {
                  if (isUminus(paramSEXP3) == 0)
                    return Rinternals.Rf_lang3(DivideSymbol, paramSEXP2, paramSEXP3); 
                  paramSEXP1 = Rinternals.R_MissingArg;
                  paramSEXP3 = Rinternals.CADR(paramSEXP3);
                  paramSEXP2 = PP(simplify(DivideSymbol, paramSEXP2, paramSEXP3));
                  return simplify(MinusSymbol, paramSEXP2, paramSEXP1);
                } 
                paramSEXP1 = Rinternals.R_MissingArg;
                paramSEXP2 = Rinternals.CADR(paramSEXP2);
                paramSEXP2 = PP(simplify(DivideSymbol, paramSEXP2, paramSEXP3));
                return simplify(MinusSymbol, paramSEXP2, paramSEXP1);
              } 
              return paramSEXP2;
            } 
            return Constant(Arith.R_NaReal);
          } 
          return Constant(0.0D);
        } 
        if (isZero(paramSEXP2) == 0 && isZero(paramSEXP3) == 0) {
          if (isOne(paramSEXP2) == 0) {
            if (isOne(paramSEXP3) == 0) {
              if (isUminus(paramSEXP2) == 0) {
                if (isUminus(paramSEXP3) == 0)
                  return Rinternals.Rf_lang3(TimesSymbol, paramSEXP2, paramSEXP3); 
                paramSEXP1 = Rinternals.R_MissingArg;
                paramSEXP3 = Rinternals.CADR(paramSEXP3);
                paramSEXP2 = PP(simplify(TimesSymbol, paramSEXP2, paramSEXP3));
                return simplify(MinusSymbol, paramSEXP2, paramSEXP1);
              } 
              paramSEXP1 = Rinternals.R_MissingArg;
              paramSEXP2 = Rinternals.CADR(paramSEXP2);
              paramSEXP2 = PP(simplify(TimesSymbol, paramSEXP2, paramSEXP3));
              return simplify(MinusSymbol, paramSEXP2, paramSEXP1);
            } 
            return paramSEXP2;
          } 
          return paramSEXP3;
        } 
        return Constant(0.0D);
      } 
      if (paramSEXP3 != Rinternals.R_MissingArg) {
        if (isZero(paramSEXP3) == 0) {
          if (isZero(paramSEXP2) == 0) {
            if (isUminus(paramSEXP2) == 0) {
              if (isUminus(paramSEXP3) == 0)
                return Rinternals.Rf_lang3(MinusSymbol, paramSEXP2, paramSEXP3); 
              paramSEXP1 = Rinternals.CADR(paramSEXP3);
              return simplify(PlusSymbol, paramSEXP2, paramSEXP1);
            } 
            paramSEXP1 = Rinternals.R_MissingArg;
            paramSEXP2 = Rinternals.CADR(paramSEXP2);
            paramSEXP2 = PP(simplify(PlusSymbol, paramSEXP2, paramSEXP3));
            return simplify(MinusSymbol, paramSEXP2, paramSEXP1);
          } 
          return simplify(MinusSymbol, paramSEXP3, Rinternals.R_MissingArg);
        } 
        return paramSEXP2;
      } 
      return (isZero(paramSEXP2) == 0) ? ((isUminus(paramSEXP2) == 0) ? Rinternals.Rf_lang2(MinusSymbol, paramSEXP2) : Rinternals.CADR(paramSEXP2)) : Constant(0.0D);
    } 
    if (isZero(paramSEXP2) == 0) {
      if (isZero(paramSEXP3) == 0) {
        if (isUminus(paramSEXP2) == 0) {
          if (isUminus(paramSEXP3) == 0)
            return Rinternals.Rf_lang3(PlusSymbol, paramSEXP2, paramSEXP3); 
          paramSEXP1 = Rinternals.CADR(paramSEXP3);
          return simplify(MinusSymbol, paramSEXP2, paramSEXP1);
        } 
        paramSEXP1 = Rinternals.CADR(paramSEXP2);
        return simplify(MinusSymbol, paramSEXP3, paramSEXP1);
      } 
      return paramSEXP2;
    } 
    return paramSEXP3;
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/stats-0.9.2724.jar!/org/renjin/stats/deriv__.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */