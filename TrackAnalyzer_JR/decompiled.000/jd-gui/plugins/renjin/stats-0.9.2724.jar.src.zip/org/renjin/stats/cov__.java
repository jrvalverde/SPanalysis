package org.renjin.stats;

import org.renjin.gcc.runtime.Builtins;
import org.renjin.gcc.runtime.BytePtr;
import org.renjin.gcc.runtime.IntPtr;
import org.renjin.gcc.runtime.Mathlib;
import org.renjin.gcc.runtime.Ptr;
import org.renjin.gnur.api.Arith;
import org.renjin.gnur.api.Error;
import org.renjin.gnur.api.GetText;
import org.renjin.gnur.api.Rinternals;
import org.renjin.gnur.api.Rinternals2;
import org.renjin.gnur.api.Rmath;
import org.renjin.sexp.SEXP;

public class cov__ {
  static {
  
  }
  
  public static void complete1(int paramInt1, int paramInt2, Ptr paramPtr1, Ptr paramPtr2, int paramInt3) {
    BytePtr.of(0);
    int i;
    for (i = 0; i < paramInt1; i++)
      paramPtr2.setInt(i * 4, 1); 
    for (byte b = 0; b < paramInt2; b++) {
      i = b * paramInt1 * 8;
      for (byte b1 = 0; b1 < paramInt1; b1++) {
        if (Builtins.__isnan(paramPtr1.getDouble(i + b1 * 8)) != 0) {
          if (paramInt3 != 0)
            Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("missing observations in cov/cor\000".getBytes(), 0)), new Object[0]); 
          paramPtr2.setInt(b1 * 4, 0);
        } 
      } 
    } 
  }
  
  public static void complete2(int paramInt1, int paramInt2, int paramInt3, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, int paramInt4) {
    BytePtr.of(0);
    int i;
    for (i = 0; i < paramInt1; i++)
      paramPtr3.setInt(i * 4, 1); 
    for (byte b2 = 0; b2 < paramInt2; b2++) {
      i = b2 * paramInt1 * 8;
      for (byte b = 0; b < paramInt1; b++) {
        if (Builtins.__isnan(paramPtr1.getDouble(i + b * 8)) != 0) {
          if (paramInt4 != 0)
            Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("missing observations in cov/cor\000".getBytes(), 0)), new Object[0]); 
          paramPtr3.setInt(b * 4, 0);
        } 
      } 
    } 
    for (byte b1 = 0; b1 < paramInt3; b1++) {
      paramInt2 = b1 * paramInt1 * 8;
      for (i = 0; i < paramInt1; i++) {
        if (Builtins.__isnan(paramPtr2.getDouble(paramInt2 + i * 8)) != 0) {
          if (paramInt4 != 0)
            Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("missing observations in cov/cor\000".getBytes(), 0)), new Object[0]); 
          paramPtr3.setInt(i * 4, 0);
        } 
      } 
    } 
  }
  
  public static SEXP cor(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4) {
    return corcov(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4, 1);
  }
  
  public static SEXP corcov(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4, int paramInt) {
    Ptr ptr1;
    int j;
    Ptr ptr2;
    int k;
    Ptr ptr3;
    int m;
    Ptr ptr4;
    Ptr ptr5;
    int[] arrayOfInt = new int[1];
    arrayOfInt[0] = 0;
    SEXP sEXP = (SEXP)BytePtr.of(0).getArray();
    sEXP = (SEXP)BytePtr.of(0).getArray();
    if (Rinternals.TYPEOF(paramSEXP1) == 0)
      Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("'x' is NULL\000".getBytes(), 0)), new Object[0]); 
    if (Rinternals.Rf_isFactor(paramSEXP1))
      Error.Rf_warning(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("Calling var(x) on a factor x is deprecated and will become an error.\n  Use something like 'all(duplicated(x)[-1L])' to test for a constant vector.\000".getBytes(), 0)), new Object[0]); 
    sEXP = Rinternals.Rf_protect(Rinternals.Rf_coerceVector(paramSEXP1, 14));
    boolean bool = Rinternals.Rf_isMatrix(sEXP);
    if (!bool) {
      j = Rinternals.Rf_length(sEXP);
      k = 1;
    } else {
      j = Rinternals.Rf_nrows(sEXP);
      k = Rinternals.Rf_ncols(sEXP);
    } 
    if (Rinternals.TYPEOF(paramSEXP2) != 0) {
      if (Rinternals.Rf_isFactor(paramSEXP2))
        Error.Rf_warning(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("Calling var(x) on a factor x is deprecated and will become an error.\n  Use something like 'all(duplicated(x)[-1L])' to test for a constant vector.\000".getBytes(), 0)), new Object[0]); 
      paramSEXP2 = Rinternals.Rf_protect(Rinternals.Rf_coerceVector(paramSEXP2, 14));
      if (!Rinternals.Rf_isMatrix(paramSEXP2)) {
        if (Rinternals.Rf_length(paramSEXP2) != j)
          Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("incompatible dimensions\000".getBytes(), 0)), new Object[0]); 
        m = 1;
      } else {
        if (Rinternals.Rf_nrows(paramSEXP2) != j)
          Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("incompatible dimensions\000".getBytes(), 0)), new Object[0]); 
        m = Rinternals.Rf_ncols(paramSEXP2);
        bool = true;
      } 
    } else {
      m = k;
    } 
    int i = Rinternals.Rf_asLogical(paramSEXP4);
    boolean bool3 = false;
    boolean bool2 = false;
    boolean bool1 = true;
    boolean bool4 = false;
    switch (Rinternals.Rf_asInteger(paramSEXP3)) {
      case 1:
        bool3 = true;
        break;
      case 2:
        if (Rinternals.LENGTH(sEXP) != 0)
          break; 
        Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("no complete element pairs\000".getBytes(), 0)), new Object[0]);
        break;
      case 3:
        bool4 = true;
        break;
      case 4:
        bool2 = true;
        bool1 = false;
        break;
      case 5:
        bool1 = false;
        break;
      default:
        Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("invalid 'use' (computational method)\000".getBytes(), 0)), new Object[0]);
        break;
    } 
    if (bool1 && Rinternals.LENGTH(sEXP) == 0)
      Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("'x' is empty\000".getBytes(), 0)), new Object[0]); 
    if (!bool) {
      paramSEXP1 = Rinternals.Rf_allocVector(14, k * m);
      Rinternals.Rf_protect(paramSEXP1);
    } else {
      paramSEXP1 = Rinternals.Rf_allocMatrix(14, k, m);
      Rinternals.Rf_protect(paramSEXP1);
    } 
    arrayOfInt[0] = 0;
    if (Rinternals.TYPEOF(paramSEXP2) != 0) {
      Ptr ptr;
      if (!bool2) {
        Ptr ptr6;
        if (bool4) {
          ptr2 = Rinternals2.REAL(paramSEXP1);
          ptr6 = Rinternals2.REAL(paramSEXP2);
          cov_pairwise2(j, k, m, Rinternals2.REAL(sEXP), ptr6, ptr2, (Ptr)new IntPtr(arrayOfInt, 0), paramInt, i);
        } else {
          Rinternals.Rf_protect(Rinternals.Rf_allocVector(14, k));
          Rinternals.Rf_protect(Rinternals.Rf_allocVector(14, m));
          SEXP sEXP1 = Rinternals.Rf_allocVector(13, ptr2);
          Rinternals.Rf_protect(sEXP1);
          ptr = Rinternals2.INTEGER(sEXP1);
          ptr3 = Rinternals2.REAL(paramSEXP2);
          complete2(ptr2, k, m, Rinternals2.REAL(sEXP), ptr3, ptr, bool3);
          Ptr ptr7 = Rinternals2.REAL(paramSEXP1);
          ptr5 = Rinternals2.INTEGER(sEXP1);
          ptr4 = Rinternals2.REAL(Rinternals.Rf_allocVector(14, m));
          ptr = Rinternals2.REAL(Rinternals.Rf_allocVector(14, k));
          ptr3 = Rinternals2.REAL(paramSEXP2);
          cov_complete2(ptr2, k, m, Rinternals2.REAL(sEXP), ptr3, ptr, ptr4, ptr5, ptr7, (Ptr)new IntPtr(arrayOfInt, 0), paramInt, i);
          if (ptr6 != null) {
            i = 0;
            byte b = 0;
            while (b < ptr2) {
              if (Rinternals2.INTEGER(sEXP1).getInt(0 + b * 4) != 1) {
                b++;
                continue;
              } 
              i = 1;
              break;
            } 
            if (i == 0)
              Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("no complete element pairs\000".getBytes(), 0)), new Object[0]); 
          } 
        } 
      } else {
        Rinternals.Rf_protect(Rinternals.Rf_allocVector(14, ptr3));
        Rinternals.Rf_protect(Rinternals.Rf_allocVector(14, ptr));
        SEXP sEXP1 = Rinternals.Rf_allocVector(10, ptr3);
        Rinternals.Rf_protect(sEXP1);
        SEXP sEXP2 = Rinternals.Rf_allocVector(10, ptr);
        Rinternals.Rf_protect(sEXP2);
        ptr = Rinternals2.INTEGER(sEXP2);
        ptr3 = Rinternals2.INTEGER(sEXP1);
        ptr2 = Rinternals2.REAL(paramSEXP2);
        find_na_2(ptr2, ptr3, ptr, Rinternals2.REAL(sEXP), ptr2, ptr3, ptr);
        ptr2 = Rinternals2.REAL(paramSEXP1);
        ptr1 = Rinternals2.INTEGER(sEXP2);
        ptr4 = Rinternals2.INTEGER(sEXP1);
        ptr = Rinternals2.REAL(Rinternals.Rf_allocVector(14, ptr));
        ptr3 = Rinternals2.REAL(Rinternals.Rf_allocVector(14, ptr3));
        Ptr ptr6 = Rinternals2.REAL(paramSEXP2);
        cov_na_2(ptr2, ptr3, ptr, Rinternals2.REAL(sEXP), ptr6, ptr3, ptr, ptr4, ptr1, ptr2, (Ptr)new IntPtr(arrayOfInt, 0), paramInt, i);
      } 
    } else if (ptr1 == null) {
      Ptr ptr;
      if (ptr5 != null) {
        ptr = Rinternals2.REAL(paramSEXP1);
        cov_pairwise1(ptr2, ptr3, Rinternals2.REAL(sEXP), ptr, (Ptr)new IntPtr(arrayOfInt, 0), paramInt, i);
      } else {
        Rinternals.Rf_protect(Rinternals.Rf_allocVector(14, ptr3));
        SEXP sEXP1 = Rinternals.Rf_allocVector(13, ptr2);
        Rinternals.Rf_protect(sEXP1);
        ptr3 = Rinternals2.INTEGER(sEXP1);
        complete1(ptr2, ptr3, Rinternals2.REAL(sEXP), ptr3, ptr4);
        ptr4 = Rinternals2.REAL(paramSEXP1);
        Ptr ptr6 = Rinternals2.INTEGER(sEXP1);
        ptr3 = Rinternals2.REAL(Rinternals.Rf_allocVector(14, ptr3));
        cov_complete1(ptr2, ptr3, Rinternals2.REAL(sEXP), ptr3, ptr6, ptr4, (Ptr)new IntPtr(arrayOfInt, 0), paramInt, i);
        if (ptr != null) {
          i = 0;
          byte b = 0;
          while (b < ptr2) {
            if (Rinternals2.INTEGER(sEXP1).getInt(0 + b * 4) != 1) {
              b++;
              continue;
            } 
            i = 1;
            break;
          } 
          if (i == 0)
            Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("no complete element pairs\000".getBytes(), 0)), new Object[0]); 
        } 
      } 
    } else {
      Rinternals.Rf_protect(Rinternals.Rf_allocVector(14, ptr3));
      SEXP sEXP1 = Rinternals.Rf_allocVector(10, ptr3);
      Rinternals.Rf_protect(sEXP1);
      IntPtr intPtr2 = Rinternals.LOGICAL(sEXP1);
      find_na_1(ptr2, ptr3, Rinternals2.REAL(sEXP), (Ptr)intPtr2);
      Ptr ptr7 = Rinternals2.REAL(paramSEXP1);
      IntPtr intPtr1 = Rinternals.LOGICAL(sEXP1);
      Ptr ptr6 = Rinternals2.REAL(Rinternals.Rf_allocVector(14, ptr3));
      cov_na_1(ptr2, ptr3, Rinternals2.REAL(sEXP), ptr6, (Ptr)intPtr1, ptr7, (Ptr)new IntPtr(arrayOfInt, 0), paramInt, i);
    } 
    if (bool)
      if (Rinternals.TYPEOF(paramSEXP2) != 0) {
        SEXP sEXP1 = Rinternals.Rf_getAttrib(sEXP, Rinternals.R_DimNamesSymbol);
        paramSEXP2 = Rinternals.Rf_getAttrib(paramSEXP2, Rinternals.R_DimNamesSymbol);
        if ((Rinternals.Rf_length(sEXP1) > 1 && Rinternals.TYPEOF(Rinternals.VECTOR_ELT(sEXP1, 1)) != 0) || (Rinternals.Rf_length(paramSEXP2) > 1 && Rinternals.TYPEOF(Rinternals.VECTOR_ELT(paramSEXP2, 1)) != 0)) {
          SEXP sEXP2 = Rinternals.Rf_allocVector(19, 2);
          Rinternals.Rf_protect(sEXP2);
          if (Rinternals.Rf_length(sEXP1) > 1 && Rinternals.TYPEOF(Rinternals.VECTOR_ELT(sEXP1, 1)) != 0)
            Rinternals.SET_VECTOR_ELT(sEXP2, 0, Rinternals.Rf_duplicate(Rinternals.VECTOR_ELT(sEXP1, 1))); 
          if (Rinternals.Rf_length(paramSEXP2) > 1 && Rinternals.TYPEOF(Rinternals.VECTOR_ELT(paramSEXP2, 1)) != 0)
            Rinternals.SET_VECTOR_ELT(sEXP2, 1, Rinternals.Rf_duplicate(Rinternals.VECTOR_ELT(paramSEXP2, 1))); 
          Rinternals.Rf_setAttrib(paramSEXP1, Rinternals.R_DimNamesSymbol, sEXP2);
        } 
      } else {
        paramSEXP2 = Rinternals.Rf_getAttrib(sEXP, Rinternals.R_DimNamesSymbol);
        if (Rinternals.TYPEOF(paramSEXP2) != 0 && Rinternals.TYPEOF(Rinternals.VECTOR_ELT(paramSEXP2, 1)) != 0) {
          SEXP sEXP1 = Rinternals.Rf_allocVector(19, 2);
          Rinternals.Rf_protect(sEXP1);
          Rinternals.SET_VECTOR_ELT(sEXP1, 0, Rinternals.Rf_duplicate(Rinternals.VECTOR_ELT(paramSEXP2, 1)));
          Rinternals.SET_VECTOR_ELT(sEXP1, 1, Rinternals.Rf_duplicate(Rinternals.VECTOR_ELT(paramSEXP2, 1)));
          Rinternals.Rf_setAttrib(paramSEXP1, Rinternals.R_DimNamesSymbol, sEXP1);
        } 
      }  
    if (arrayOfInt[0] != 0)
      Error.Rf_warning(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("the standard deviation is zero\000".getBytes(), 0)), new Object[0]); 
    return paramSEXP1;
  }
  
  public static SEXP cov(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4) {
    return corcov(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4, 0);
  }
  
  public static void cov_complete1(int paramInt1, int paramInt2, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, int paramInt3, int paramInt4) {
    BytePtr.of(0);
    BytePtr.of(0);
    int j = -1;
    int i = 0;
    byte b;
    for (b = 0; b < paramInt1; b++) {
      if (paramPtr3.getInt(b * 4) != 0)
        i++; 
    } 
    if (i > 1) {
      if (paramInt4 == 0) {
        for (b = 0; b < paramInt2; b++) {
          j = b * paramInt1 * 8;
          double d = 0.0D;
          byte b1;
          for (b1 = 0; b1 < paramInt1; b1++) {
            if (paramPtr3.getInt(b1 * 4) != 0)
              d = paramPtr1.getDouble(j + b1 * 8) + d; 
          } 
          d /= i;
          if (Arith.R_finite(d) != 0) {
            double d1 = 0.0D;
            for (b1 = 0; b1 < paramInt1; b1++) {
              if (paramPtr3.getInt(b1 * 4) != 0)
                d1 = paramPtr1.getDouble(j + b1 * 8) - d + d1; 
            } 
            d = d1 / i + d;
          } 
          paramPtr2.setDouble(b * 8, d);
        } 
        j = i + -1;
      } 
      for (b = 0; b < paramInt2; b++) {
        i = b * paramInt1 * 8;
        if (paramInt4 != 0) {
          for (byte b1 = 0; b1 <= b; b1++) {
            int k = b1 * paramInt1 * 8;
            double d = 0.0D;
            for (byte b2 = 0; b2 < paramInt1; b2++) {
              if (paramPtr3.getInt(b2 * 4) != 0)
                for (j = 0; j < paramInt1; j++) {
                  if (paramPtr3.getInt(j * 4) != 0)
                    d = Rmath.Rf_sign(paramPtr1.getDouble(i + b2 * 8) - paramPtr1.getDouble(i + j * 8)) * Rmath.Rf_sign(paramPtr1.getDouble(k + b2 * 8) - paramPtr1.getDouble(k + j * 8)) + d; 
                }  
            } 
            k = (b1 * paramInt2 + b) * 8;
            paramPtr4.setDouble(k, d);
            paramPtr4.setDouble((b * paramInt2 + b1) * 8, paramPtr4.getDouble(k));
          } 
        } else {
          double d = paramPtr2.getDouble(b * 8);
          for (byte b1 = 0; b1 <= b; b1++) {
            int k = b1 * paramInt1 * 8;
            double d1 = paramPtr2.getDouble(b1 * 8);
            double d2 = 0.0D;
            for (byte b2 = 0; b2 < paramInt1; b2++) {
              if (paramPtr3.getInt(b2 * 4) != 0)
                d2 = (paramPtr1.getDouble(i + b2 * 8) - d) * (paramPtr1.getDouble(k + b2 * 8) - d1) + d2; 
            } 
            k = (b1 * paramInt2 + b) * 8;
            paramPtr4.setDouble(k, d2 / j);
            paramPtr4.setDouble((b * paramInt2 + b1) * 8, paramPtr4.getDouble(k));
          } 
        } 
      } 
      if (paramInt3 != 0) {
        for (paramInt1 = 0; paramInt1 < paramInt2; paramInt1++)
          paramPtr2.setDouble(paramInt1 * 8, Mathlib.sqrt(paramPtr4.getDouble((paramInt2 + 1) * 8 * paramInt1))); 
        for (paramInt1 = 0; paramInt1 < paramInt2; paramInt1++) {
          for (byte b1 = 0; b1 < paramInt1; b1++) {
            if (paramPtr2.getDouble(paramInt1 * 8) != 0.0D && paramPtr2.getDouble(b1 * 8) != 0.0D) {
              double d = paramPtr4.getDouble((b1 * paramInt2 + paramInt1) * 8) / paramPtr2.getDouble(paramInt1 * 8) * paramPtr2.getDouble(b1 * 8);
              if (d > 1.0D)
                d = 1.0D; 
              int k = (b1 * paramInt2 + paramInt1) * 8;
              paramPtr4.setDouble(k, d);
              paramPtr4.setDouble((paramInt1 * paramInt2 + b1) * 8, paramPtr4.getDouble(k));
            } else {
              paramPtr5.setInt(1);
              int k = (b1 * paramInt2 + paramInt1) * 8;
              paramPtr4.setDouble(k, Arith.R_NaReal);
              paramPtr4.setDouble((paramInt1 * paramInt2 + b1) * 8, paramPtr4.getDouble(k));
            } 
          } 
          paramPtr4.setDouble((paramInt2 + 1) * 8 * paramInt1, 1.0D);
        } 
      } 
      return;
    } 
    for (paramInt1 = 0; paramInt1 < paramInt2; paramInt1++) {
      for (byte b1 = 0; b1 < paramInt2; b1++)
        paramPtr4.setDouble((b1 * paramInt2 + paramInt1) * 8, Arith.R_NaReal); 
    } 
  }
  
  public static void cov_complete2(int paramInt1, int paramInt2, int paramInt3, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, int paramInt4, int paramInt5) {
    BytePtr.of(0);
    BytePtr.of(0);
    int j = -1;
    int i = 0;
    byte b;
    for (b = 0; b < paramInt1; b++) {
      if (paramPtr5.getInt(b * 4) != 0)
        i++; 
    } 
    if (i > 1) {
      if (paramInt5 == 0) {
        for (b = 0; b < paramInt2; b++) {
          j = b * paramInt1 * 8;
          double d = 0.0D;
          byte b1;
          for (b1 = 0; b1 < paramInt1; b1++) {
            if (paramPtr5.getInt(b1 * 4) != 0)
              d = paramPtr1.getDouble(j + b1 * 8) + d; 
          } 
          d /= i;
          if (Arith.R_finite(d) != 0) {
            double d1 = 0.0D;
            for (b1 = 0; b1 < paramInt1; b1++) {
              if (paramPtr5.getInt(b1 * 4) != 0)
                d1 = paramPtr1.getDouble(j + b1 * 8) - d + d1; 
            } 
            d = d1 / i + d;
          } 
          paramPtr3.setDouble(b * 8, d);
        } 
        for (b = 0; b < paramInt3; b++) {
          j = b * paramInt1 * 8;
          double d = 0.0D;
          byte b1;
          for (b1 = 0; b1 < paramInt1; b1++) {
            if (paramPtr5.getInt(b1 * 4) != 0)
              d = paramPtr2.getDouble(j + b1 * 8) + d; 
          } 
          d /= i;
          if (Arith.R_finite(d) != 0) {
            double d1 = 0.0D;
            for (b1 = 0; b1 < paramInt1; b1++) {
              if (paramPtr5.getInt(b1 * 4) != 0)
                d1 = paramPtr2.getDouble(j + b1 * 8) - d + d1; 
            } 
            d = d1 / i + d;
          } 
          paramPtr4.setDouble(b * 8, d);
        } 
        j = i + -1;
      } 
      for (b = 0; b < paramInt2; b++) {
        i = b * paramInt1 * 8;
        if (paramInt5 != 0) {
          for (byte b1 = 0; b1 < paramInt3; b1++) {
            int k = b1 * paramInt1 * 8;
            double d = 0.0D;
            for (byte b2 = 0; b2 < paramInt1; b2++) {
              if (paramPtr5.getInt(b2 * 4) != 0)
                for (j = 0; j < paramInt1; j++) {
                  if (paramPtr5.getInt(j * 4) != 0)
                    d = Rmath.Rf_sign(paramPtr1.getDouble(i + b2 * 8) - paramPtr1.getDouble(i + j * 8)) * Rmath.Rf_sign(paramPtr2.getDouble(k + b2 * 8) - paramPtr2.getDouble(k + j * 8)) + d; 
                }  
            } 
            paramPtr6.setDouble((b1 * paramInt2 + b) * 8, d);
          } 
        } else {
          double d = paramPtr3.getDouble(b * 8);
          for (byte b1 = 0; b1 < paramInt3; b1++) {
            int k = b1 * paramInt1 * 8;
            double d1 = paramPtr4.getDouble(b1 * 8);
            double d2 = 0.0D;
            for (byte b2 = 0; b2 < paramInt1; b2++) {
              if (paramPtr5.getInt(b2 * 4) != 0)
                d2 = (paramPtr1.getDouble(i + b2 * 8) - d) * (paramPtr2.getDouble(k + b2 * 8) - d1) + d2; 
            } 
            paramPtr6.setDouble((b1 * paramInt2 + b) * 8, d2 / j);
          } 
        } 
      } 
      if (paramInt4 != 0) {
        for (i = 0; i < paramInt2; i++) {
          paramInt4 = i * paramInt1 * 8;
          double d = 0.0D;
          if (paramInt5 != 0) {
            for (b = 0; b < paramInt1; b++) {
              if (paramPtr5.getInt(b * 4) != 0)
                for (j = 0; j < paramInt1; j++) {
                  if (paramPtr5.getInt(j * 4) != 0 && paramPtr1.getDouble(paramInt4 + b * 8) != paramPtr1.getDouble(paramInt4 + j * 8))
                    d++; 
                }  
            } 
          } else {
            double d1 = paramPtr3.getDouble(i * 8);
            for (b = 0; b < paramInt1; b++) {
              if (paramPtr5.getInt(b * 4) != 0)
                d = (paramPtr1.getDouble(paramInt4 + b * 8) - d1) * (paramPtr1.getDouble(paramInt4 + b * 8) - d1) + d; 
            } 
            d /= j;
          } 
          paramPtr3.setDouble(i * 8, Mathlib.sqrt(d));
        } 
        for (paramInt4 = 0; paramInt4 < paramInt3; paramInt4++) {
          int k = paramInt4 * paramInt1 * 8;
          double d = 0.0D;
          if (paramInt5 != 0) {
            for (i = 0; i < paramInt1; i++) {
              if (paramPtr5.getInt(i * 4) != 0)
                for (j = 0; j < paramInt1; j++) {
                  if (paramPtr5.getInt(j * 4) != 0 && paramPtr2.getDouble(k + i * 8) != paramPtr2.getDouble(k + j * 8))
                    d++; 
                }  
            } 
          } else {
            double d1 = paramPtr4.getDouble(paramInt4 * 8);
            for (i = 0; i < paramInt1; i++) {
              if (paramPtr5.getInt(i * 4) != 0)
                d = (paramPtr2.getDouble(k + i * 8) - d1) * (paramPtr2.getDouble(k + i * 8) - d1) + d; 
            } 
            d /= j;
          } 
          paramPtr4.setDouble(paramInt4 * 8, Mathlib.sqrt(d));
        } 
        for (paramInt1 = 0; paramInt1 < paramInt2; paramInt1++) {
          for (byte b1 = 0; b1 < paramInt3; b1++) {
            if (paramPtr3.getDouble(paramInt1 * 8) != 0.0D && paramPtr4.getDouble(b1 * 8) != 0.0D) {
              paramPtr6.setDouble((b1 * paramInt2 + paramInt1) * 8, paramPtr6.getDouble((b1 * paramInt2 + paramInt1) * 8) / paramPtr3.getDouble(paramInt1 * 8) * paramPtr4.getDouble(b1 * 8));
              if (paramPtr6.getDouble((b1 * paramInt2 + paramInt1) * 8) > 1.0D)
                paramPtr6.setDouble((b1 * paramInt2 + paramInt1) * 8, 1.0D); 
            } else {
              paramPtr7.setInt(1);
              paramPtr6.setDouble((b1 * paramInt2 + paramInt1) * 8, Arith.R_NaReal);
            } 
          } 
        } 
      } 
      return;
    } 
    for (paramInt1 = 0; paramInt1 < paramInt2; paramInt1++) {
      for (byte b1 = 0; b1 < paramInt3; b1++)
        paramPtr6.setDouble((b1 * paramInt2 + paramInt1) * 8, Arith.R_NaReal); 
    } 
  }
  
  public static void cov_na_1(int paramInt1, int paramInt2, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, int paramInt3, int paramInt4) {
    BytePtr.of(0);
    BytePtr.of(0);
    int i = -1;
    if (paramInt1 > 1) {
      if (paramInt4 == 0) {
        for (byte b1 = 0; b1 < paramInt2; b1++) {
          double d;
          if (paramPtr3.getInt(b1 * 4) == 0) {
            i = b1 * paramInt1 * 8;
            d = 0.0D;
            byte b2;
            for (b2 = 0; b2 < paramInt1; b2++)
              d = paramPtr1.getDouble(i + b2 * 8) + d; 
            d /= paramInt1;
            if (Arith.R_finite(d) != 0) {
              double d1 = 0.0D;
              for (b2 = 0; b2 < paramInt1; b2++)
                d1 = paramPtr1.getDouble(i + b2 * 8) - d + d1; 
              d = d1 / paramInt1 + d;
            } 
          } else {
            d = Arith.R_NaReal;
          } 
          paramPtr2.setDouble(b1 * 8, d);
        } 
        i = paramInt1 + -1;
      } 
      for (byte b = 0; b < paramInt2; b++) {
        if (paramPtr3.getInt(b * 4) == 0) {
          int j = b * paramInt1 * 8;
          if (paramInt4 != 0) {
            for (byte b1 = 0; b1 <= b; b1++) {
              if (paramPtr3.getInt(b1 * 4) == 0) {
                int k = b1 * paramInt1 * 8;
                double d = 0.0D;
                for (byte b2 = 0; b2 < paramInt1; b2++) {
                  for (i = 0; i < paramInt1; i++)
                    d = Rmath.Rf_sign(paramPtr1.getDouble(j + b2 * 8) - paramPtr1.getDouble(j + i * 8)) * Rmath.Rf_sign(paramPtr1.getDouble(k + b2 * 8) - paramPtr1.getDouble(k + i * 8)) + d; 
                } 
                k = (b1 * paramInt2 + b) * 8;
                paramPtr4.setDouble(k, d);
                paramPtr4.setDouble((b * paramInt2 + b1) * 8, paramPtr4.getDouble(k));
              } else {
                int k = (b1 * paramInt2 + b) * 8;
                paramPtr4.setDouble(k, Arith.R_NaReal);
                paramPtr4.setDouble((b * paramInt2 + b1) * 8, paramPtr4.getDouble(k));
              } 
            } 
          } else {
            double d = paramPtr2.getDouble(b * 8);
            for (byte b1 = 0; b1 <= b; b1++) {
              if (paramPtr3.getInt(b1 * 4) == 0) {
                int k = b1 * paramInt1 * 8;
                double d1 = paramPtr2.getDouble(b1 * 8);
                double d2 = 0.0D;
                for (byte b2 = 0; b2 < paramInt1; b2++)
                  d2 = (paramPtr1.getDouble(j + b2 * 8) - d) * (paramPtr1.getDouble(k + b2 * 8) - d1) + d2; 
                k = (b1 * paramInt2 + b) * 8;
                paramPtr4.setDouble(k, d2 / i);
                paramPtr4.setDouble((b * paramInt2 + b1) * 8, paramPtr4.getDouble(k));
              } else {
                int k = (b1 * paramInt2 + b) * 8;
                paramPtr4.setDouble(k, Arith.R_NaReal);
                paramPtr4.setDouble((b * paramInt2 + b1) * 8, paramPtr4.getDouble(k));
              } 
            } 
          } 
        } else {
          for (byte b1 = 0; b1 <= b; b1++) {
            int j = (b1 * paramInt2 + b) * 8;
            paramPtr4.setDouble(j, Arith.R_NaReal);
            paramPtr4.setDouble((b * paramInt2 + b1) * 8, paramPtr4.getDouble(j));
          } 
        } 
      } 
      if (paramInt3 != 0) {
        for (paramInt1 = 0; paramInt1 < paramInt2; paramInt1++) {
          if (paramPtr3.getInt(paramInt1 * 4) == 0)
            paramPtr2.setDouble(paramInt1 * 8, Mathlib.sqrt(paramPtr4.getDouble((paramInt2 + 1) * 8 * paramInt1))); 
        } 
        for (paramInt1 = 0; paramInt1 < paramInt2; paramInt1++) {
          if (paramPtr3.getInt(paramInt1 * 4) == 0)
            for (byte b1 = 0; b1 < paramInt1; b1++) {
              if (paramPtr2.getDouble(paramInt1 * 8) != 0.0D && paramPtr2.getDouble(b1 * 8) != 0.0D) {
                double d = paramPtr4.getDouble((b1 * paramInt2 + paramInt1) * 8) / paramPtr2.getDouble(paramInt1 * 8) * paramPtr2.getDouble(b1 * 8);
                if (d > 1.0D)
                  d = 1.0D; 
                paramInt3 = (b1 * paramInt2 + paramInt1) * 8;
                paramPtr4.setDouble(paramInt3, d);
                paramPtr4.setDouble((paramInt1 * paramInt2 + b1) * 8, paramPtr4.getDouble(paramInt3));
              } else {
                paramPtr5.setInt(1);
                paramInt3 = (b1 * paramInt2 + paramInt1) * 8;
                paramPtr4.setDouble(paramInt3, Arith.R_NaReal);
                paramPtr4.setDouble((paramInt1 * paramInt2 + b1) * 8, paramPtr4.getDouble(paramInt3));
              } 
            }  
          paramPtr4.setDouble((paramInt2 + 1) * 8 * paramInt1, 1.0D);
        } 
      } 
      return;
    } 
    for (paramInt1 = 0; paramInt1 < paramInt2; paramInt1++) {
      for (byte b = 0; b < paramInt2; b++)
        paramPtr4.setDouble((b * paramInt2 + paramInt1) * 8, Arith.R_NaReal); 
    } 
  }
  
  public static void cov_na_2(int paramInt1, int paramInt2, int paramInt3, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, int paramInt4, int paramInt5) {
    BytePtr.of(0);
    BytePtr.of(0);
    int i = -1;
    if (paramInt1 > 1) {
      if (paramInt5 == 0) {
        byte b1;
        for (b1 = 0; b1 < paramInt2; b1++) {
          double d;
          if (paramPtr5.getInt(b1 * 4) == 0) {
            i = b1 * paramInt1 * 8;
            d = 0.0D;
            byte b2;
            for (b2 = 0; b2 < paramInt1; b2++)
              d = paramPtr1.getDouble(i + b2 * 8) + d; 
            d /= paramInt1;
            if (Arith.R_finite(d) != 0) {
              double d1 = 0.0D;
              for (b2 = 0; b2 < paramInt1; b2++)
                d1 = paramPtr1.getDouble(i + b2 * 8) - d + d1; 
              d = d1 / paramInt1 + d;
            } 
          } else {
            d = Arith.R_NaReal;
          } 
          paramPtr3.setDouble(b1 * 8, d);
        } 
        for (b1 = 0; b1 < paramInt3; b1++) {
          double d;
          if (paramPtr6.getInt(b1 * 4) == 0) {
            i = b1 * paramInt1 * 8;
            d = 0.0D;
            byte b2;
            for (b2 = 0; b2 < paramInt1; b2++)
              d = paramPtr2.getDouble(i + b2 * 8) + d; 
            d /= paramInt1;
            if (Arith.R_finite(d) != 0) {
              double d1 = 0.0D;
              for (b2 = 0; b2 < paramInt1; b2++)
                d1 = paramPtr2.getDouble(i + b2 * 8) - d + d1; 
              d = d1 / paramInt1 + d;
            } 
          } else {
            d = Arith.R_NaReal;
          } 
          paramPtr4.setDouble(b1 * 8, d);
        } 
        i = paramInt1 + -1;
      } 
      byte b;
      for (b = 0; b < paramInt2; b++) {
        if (paramPtr5.getInt(b * 4) == 0) {
          int j = b * paramInt1 * 8;
          if (paramInt5 != 0) {
            for (byte b1 = 0; b1 < paramInt3; b1++) {
              if (paramPtr6.getInt(b1 * 4) == 0) {
                int k = b1 * paramInt1 * 8;
                double d = 0.0D;
                for (byte b2 = 0; b2 < paramInt1; b2++) {
                  for (i = 0; i < paramInt1; i++)
                    d = Rmath.Rf_sign(paramPtr1.getDouble(j + b2 * 8) - paramPtr1.getDouble(j + i * 8)) * Rmath.Rf_sign(paramPtr2.getDouble(k + b2 * 8) - paramPtr2.getDouble(k + i * 8)) + d; 
                } 
                paramPtr7.setDouble((b1 * paramInt2 + b) * 8, d);
              } else {
                paramPtr7.setDouble((b1 * paramInt2 + b) * 8, Arith.R_NaReal);
              } 
            } 
          } else {
            double d = paramPtr3.getDouble(b * 8);
            for (byte b1 = 0; b1 < paramInt3; b1++) {
              if (paramPtr6.getInt(b1 * 4) == 0) {
                int k = b1 * paramInt1 * 8;
                double d1 = paramPtr4.getDouble(b1 * 8);
                double d2 = 0.0D;
                for (byte b2 = 0; b2 < paramInt1; b2++)
                  d2 = (paramPtr1.getDouble(j + b2 * 8) - d) * (paramPtr2.getDouble(k + b2 * 8) - d1) + d2; 
                paramPtr7.setDouble((b1 * paramInt2 + b) * 8, d2 / i);
              } else {
                paramPtr7.setDouble((b1 * paramInt2 + b) * 8, Arith.R_NaReal);
              } 
            } 
          } 
        } else {
          for (byte b1 = 0; b1 < paramInt3; b1++)
            paramPtr7.setDouble((b1 * paramInt2 + b) * 8, Arith.R_NaReal); 
        } 
      } 
      if (paramInt4 != 0) {
        for (b = 0; b < paramInt2; b++) {
          if (paramPtr5.getInt(b * 4) == 0) {
            paramInt4 = b * paramInt1 * 8;
            double d = 0.0D;
            if (paramInt5 != 0) {
              for (byte b1 = 0; b1 < paramInt1; b1++) {
                for (i = 0; i < paramInt1; i++) {
                  if (paramPtr1.getDouble(paramInt4 + b1 * 8) != paramPtr1.getDouble(paramInt4 + i * 8))
                    d++; 
                } 
              } 
            } else {
              double d1 = paramPtr3.getDouble(b * 8);
              for (byte b1 = 0; b1 < paramInt1; b1++)
                d = (paramPtr1.getDouble(paramInt4 + b1 * 8) - d1) * (paramPtr1.getDouble(paramInt4 + b1 * 8) - d1) + d; 
              d /= i;
            } 
            paramPtr3.setDouble(b * 8, Mathlib.sqrt(d));
          } 
        } 
        for (paramInt4 = 0; paramInt4 < paramInt3; paramInt4++) {
          if (paramPtr6.getInt(paramInt4 * 4) == 0) {
            int j = paramInt4 * paramInt1 * 8;
            double d = 0.0D;
            if (paramInt5 != 0) {
              for (b = 0; b < paramInt1; b++) {
                for (i = 0; i < paramInt1; i++) {
                  if (paramPtr2.getDouble(j + b * 8) != paramPtr2.getDouble(j + i * 8))
                    d++; 
                } 
              } 
            } else {
              double d1 = paramPtr4.getDouble(paramInt4 * 8);
              for (b = 0; b < paramInt1; b++)
                d = (paramPtr2.getDouble(j + b * 8) - d1) * (paramPtr2.getDouble(j + b * 8) - d1) + d; 
              d /= i;
            } 
            paramPtr4.setDouble(paramInt4 * 8, Mathlib.sqrt(d));
          } 
        } 
        for (paramInt1 = 0; paramInt1 < paramInt2; paramInt1++) {
          if (paramPtr5.getInt(paramInt1 * 4) == 0)
            for (byte b1 = 0; b1 < paramInt3; b1++) {
              if (paramPtr6.getInt(b1 * 4) == 0)
                if (paramPtr3.getDouble(paramInt1 * 8) != 0.0D && paramPtr4.getDouble(b1 * 8) != 0.0D) {
                  paramPtr7.setDouble((b1 * paramInt2 + paramInt1) * 8, paramPtr7.getDouble((b1 * paramInt2 + paramInt1) * 8) / paramPtr3.getDouble(paramInt1 * 8) * paramPtr4.getDouble(b1 * 8));
                  if (paramPtr7.getDouble((b1 * paramInt2 + paramInt1) * 8) > 1.0D)
                    paramPtr7.setDouble((b1 * paramInt2 + paramInt1) * 8, 1.0D); 
                } else {
                  paramPtr8.setInt(1);
                  paramPtr7.setDouble((b1 * paramInt2 + paramInt1) * 8, Arith.R_NaReal);
                }  
            }  
        } 
      } 
      return;
    } 
    for (paramInt1 = 0; paramInt1 < paramInt2; paramInt1++) {
      for (byte b = 0; b < paramInt3; b++)
        paramPtr7.setDouble((b * paramInt2 + paramInt1) * 8, Arith.R_NaReal); 
    } 
  }
  
  public static void cov_pairwise1(int paramInt1, int paramInt2, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, int paramInt3, int paramInt4) {
    BytePtr.of(0);
    BytePtr.of(0);
    for (byte b = 0; b < paramInt2; b++) {
      int i = b * paramInt1 * 8;
      for (byte b1 = 0; b1 <= b; b1++) {
        int j = b1 * paramInt1 * 8;
        double d1 = 0.0D;
        double d2 = 0.0D;
        int k = -1;
        byte b2 = 0;
        if (paramInt4 != 0) {
          for (byte b3 = 0; b3 < paramInt1; b3++) {
            if (Builtins.__isnan(paramPtr1.getDouble(i + b3 * 8)) == 0 && Builtins.__isnan(paramPtr1.getDouble(j + b3 * 8)) == 0)
              b2++; 
          } 
        } else {
          d2 = 0.0D;
          d1 = 0.0D;
          for (byte b3 = 0; b3 < paramInt1; b3++) {
            if (Builtins.__isnan(paramPtr1.getDouble(i + b3 * 8)) == 0 && Builtins.__isnan(paramPtr1.getDouble(j + b3 * 8)) == 0) {
              b2++;
              d1 = paramPtr1.getDouble(i + b3 * 8) + d1;
              d2 = paramPtr1.getDouble(j + b3 * 8) + d2;
            } 
          } 
        } 
        if (b2 <= 1) {
          paramPtr2.setDouble((b1 * paramInt2 + b) * 8, Arith.R_NaReal);
        } else {
          double d3 = 0.0D;
          double d4 = 0.0D;
          double d5 = 0.0D;
          if (paramInt4 == 0) {
            d1 /= b2;
            d2 /= b2;
            k = b2 + -1;
          } 
          for (b2 = 0; b2 < paramInt1; b2++) {
            if (Builtins.__isnan(paramPtr1.getDouble(i + b2 * 8)) == 0 && Builtins.__isnan(paramPtr1.getDouble(j + b2 * 8)) == 0)
              if (paramInt4 != 0) {
                for (k = 0; k < b2; k++) {
                  if (Builtins.__isnan(paramPtr1.getDouble(i + k * 8)) == 0 && Builtins.__isnan(paramPtr1.getDouble(j + k * 8)) == 0) {
                    double d6 = Rmath.Rf_sign(paramPtr1.getDouble(i + b2 * 8) - paramPtr1.getDouble(i + k * 8));
                    double d7 = Rmath.Rf_sign(paramPtr1.getDouble(j + b2 * 8) - paramPtr1.getDouble(j + k * 8));
                    d3 = d6 * d7 + d3;
                    if (paramInt3 != 0) {
                      d5 = d6 * d6 + d5;
                      d4 = d7 * d7 + d4;
                    } 
                  } 
                } 
              } else {
                double d6 = paramPtr1.getDouble(i + b2 * 8) - d1;
                double d7 = paramPtr1.getDouble(j + b2 * 8) - d2;
                d3 = d6 * d7 + d3;
                if (paramInt3 != 0) {
                  d5 = d6 * d6 + d5;
                  d4 = d7 * d7 + d4;
                } 
              }  
          } 
          if (paramInt3 == 0) {
            if (paramInt4 == 0)
              d3 /= k; 
          } else if (d5 != 0.0D && d4 != 0.0D) {
            if (paramInt4 == 0) {
              d5 /= k;
              d4 /= k;
              d3 /= k;
            } 
            d3 /= Mathlib.sqrt(d5) * Mathlib.sqrt(d4);
            if (d3 > 1.0D)
              d3 = 1.0D; 
          } else {
            paramPtr3.setInt(1);
            d3 = Arith.R_NaReal;
          } 
          paramPtr2.setDouble((b1 * paramInt2 + b) * 8, d3);
        } 
        paramPtr2.setDouble((b * paramInt2 + b1) * 8, paramPtr2.getDouble((b1 * paramInt2 + b) * 8));
      } 
    } 
  }
  
  public static void cov_pairwise2(int paramInt1, int paramInt2, int paramInt3, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, int paramInt4, int paramInt5) {
    BytePtr.of(0);
    BytePtr.of(0);
    for (byte b = 0; b < paramInt2; b++) {
      int i = b * paramInt1 * 8;
      for (byte b1 = 0; b1 < paramInt3; b1++) {
        int j = b1 * paramInt1 * 8;
        double d1 = 0.0D;
        double d2 = 0.0D;
        int k = -1;
        byte b2 = 0;
        if (paramInt5 != 0) {
          for (byte b3 = 0; b3 < paramInt1; b3++) {
            if (Builtins.__isnan(paramPtr1.getDouble(i + b3 * 8)) == 0 && Builtins.__isnan(paramPtr2.getDouble(j + b3 * 8)) == 0)
              b2++; 
          } 
        } else {
          d2 = 0.0D;
          d1 = 0.0D;
          for (byte b3 = 0; b3 < paramInt1; b3++) {
            if (Builtins.__isnan(paramPtr1.getDouble(i + b3 * 8)) == 0 && Builtins.__isnan(paramPtr2.getDouble(j + b3 * 8)) == 0) {
              b2++;
              d1 = paramPtr1.getDouble(i + b3 * 8) + d1;
              d2 = paramPtr2.getDouble(j + b3 * 8) + d2;
            } 
          } 
        } 
        if (b2 <= 1) {
          paramPtr3.setDouble((b1 * paramInt2 + b) * 8, Arith.R_NaReal);
        } else {
          double d3 = 0.0D;
          double d4 = 0.0D;
          double d5 = 0.0D;
          if (paramInt5 == 0) {
            d1 /= b2;
            d2 /= b2;
            k = b2 + -1;
          } 
          for (b2 = 0; b2 < paramInt1; b2++) {
            if (Builtins.__isnan(paramPtr1.getDouble(i + b2 * 8)) == 0 && Builtins.__isnan(paramPtr2.getDouble(j + b2 * 8)) == 0)
              if (paramInt5 != 0) {
                for (k = 0; k < b2; k++) {
                  if (Builtins.__isnan(paramPtr1.getDouble(i + k * 8)) == 0 && Builtins.__isnan(paramPtr2.getDouble(j + k * 8)) == 0) {
                    double d6 = Rmath.Rf_sign(paramPtr1.getDouble(i + b2 * 8) - paramPtr1.getDouble(i + k * 8));
                    double d7 = Rmath.Rf_sign(paramPtr2.getDouble(j + b2 * 8) - paramPtr2.getDouble(j + k * 8));
                    d3 = d6 * d7 + d3;
                    if (paramInt4 != 0) {
                      d5 = d6 * d6 + d5;
                      d4 = d7 * d7 + d4;
                    } 
                  } 
                } 
              } else {
                double d6 = paramPtr1.getDouble(i + b2 * 8) - d1;
                double d7 = paramPtr2.getDouble(j + b2 * 8) - d2;
                d3 = d6 * d7 + d3;
                if (paramInt4 != 0) {
                  d5 = d6 * d6 + d5;
                  d4 = d7 * d7 + d4;
                } 
              }  
          } 
          if (paramInt4 == 0) {
            if (paramInt5 == 0)
              d3 /= k; 
          } else if (d5 != 0.0D && d4 != 0.0D) {
            if (paramInt5 == 0) {
              d5 /= k;
              d4 /= k;
              d3 /= k;
            } 
            d3 /= Mathlib.sqrt(d5) * Mathlib.sqrt(d4);
            if (d3 > 1.0D)
              d3 = 1.0D; 
          } else {
            paramPtr4.setInt(1);
            d3 = Arith.R_NaReal;
          } 
          paramPtr3.setDouble((b1 * paramInt2 + b) * 8, d3);
        } 
      } 
    } 
  }
  
  public static void find_na_1(int paramInt1, int paramInt2, Ptr paramPtr1, Ptr paramPtr2) {
    BytePtr.of(0);
    for (byte b = 0; b < paramInt2; b++) {
      int i = b * paramInt1 * 8;
      paramPtr2.setInt(b * 4, 0);
      byte b1 = 0;
      while (b1 < paramInt1) {
        if (Builtins.__isnan(paramPtr1.getDouble(i + b1 * 8)) == 0) {
          b1++;
          continue;
        } 
        paramPtr2.setInt(b * 4, 1);
        break;
      } 
    } 
  }
  
  public static void find_na_2(int paramInt1, int paramInt2, int paramInt3, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4) {
    BytePtr.of(0);
    for (byte b2 = 0; b2 < paramInt2; b2++) {
      int i = b2 * paramInt1 * 8;
      paramPtr3.setInt(b2 * 4, 0);
      byte b = 0;
      while (b < paramInt1) {
        if (Builtins.__isnan(paramPtr1.getDouble(i + b * 8)) == 0) {
          b++;
          continue;
        } 
        paramPtr3.setInt(b2 * 4, 1);
        break;
      } 
    } 
    for (byte b1 = 0; b1 < paramInt3; b1++) {
      paramInt2 = b1 * paramInt1 * 8;
      paramPtr4.setInt(b1 * 4, 0);
      byte b = 0;
      while (b < paramInt1) {
        if (Builtins.__isnan(paramPtr2.getDouble(paramInt2 + b * 8)) == 0) {
          b++;
          continue;
        } 
        paramPtr4.setInt(b1 * 4, 1);
        break;
      } 
    } 
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/stats-0.9.2724.jar!/org/renjin/stats/cov__.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */