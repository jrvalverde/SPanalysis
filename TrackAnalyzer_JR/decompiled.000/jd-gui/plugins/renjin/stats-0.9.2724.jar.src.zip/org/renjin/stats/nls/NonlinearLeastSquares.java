package org.renjin.stats.nls;

import java.io.IOException;
import org.renjin.eval.Context;
import org.renjin.eval.EvalException;
import org.renjin.invoke.annotations.Current;
import org.renjin.invoke.annotations.Internal;
import org.renjin.primitives.matrix.DoubleMatrixBuilder;
import org.renjin.sexp.AtomicVector;
import org.renjin.sexp.DoubleArrayVector;
import org.renjin.sexp.DoubleVector;
import org.renjin.sexp.Environment;
import org.renjin.sexp.ListVector;
import org.renjin.sexp.SEXP;
import org.renjin.sexp.StringVector;
import org.renjin.sexp.Symbol;
import org.renjin.sexp.Vector;

public class NonlinearLeastSquares {
  private static SEXP convergenceResult(NlsControl paramNlsControl, String paramString, int paramInt, StopReason paramStopReason, double paramDouble) {
    boolean bool;
    if (!paramNlsControl.isWarnOnly() && paramStopReason != StopReason.CONVERGED)
      throw new EvalException(paramString, new Object[0]); 
    ListVector.NamedBuilder namedBuilder = ListVector.newNamedBuilder();
    if (paramStopReason == StopReason.CONVERGED) {
      bool = true;
    } else {
      bool = false;
    } 
    namedBuilder.add("isConv", bool);
    namedBuilder.add("finIter", paramInt);
    namedBuilder.add("finTol", paramDouble);
    namedBuilder.add("stopCode", paramStopReason.ordinal());
    namedBuilder.add("stopMessage", paramString);
    return (SEXP)namedBuilder.build();
  }
  
  @Internal
  public static SEXP iterate(@Current Context paramContext, ListVector paramListVector1, ListVector paramListVector2, boolean paramBoolean) throws IOException {
    NlsModel nlsModel = new NlsModel();
    this(paramContext, paramListVector1);
    NlsControl nlsControl = new NlsControl();
    this(paramListVector2);
    AtomicVector atomicVector = nlsModel.getParameterValues();
    int i = atomicVector.length();
    double d1 = nlsModel.calculateDeviation();
    if (paramBoolean)
      nlsModel.trace(); 
    double d2 = 1.0D;
    boolean bool = false;
    double[] arrayOfDouble = new double[i];
    byte b2 = 1;
    double d3 = Double.POSITIVE_INFINITY;
    byte b1;
    for (b1 = 0; b1 < nlsControl.getMaxIterations(); b1++) {
      d3 = nlsModel.getConvergence();
      if (d3 < nlsControl.getTolerance()) {
        bool = true;
        break;
      } 
      DoubleVector doubleVector = nlsModel.calculateIncrements();
      byte b = 1;
      while (d2 >= nlsControl.getMinFactor()) {
        if (nlsControl.isPrintEval()) {
          Object[] arrayOfObject = new Object[4];
          arrayOfObject[0] = Integer.valueOf(b1 + 1);
          arrayOfObject[1] = Double.valueOf(d2);
          arrayOfObject[2] = Integer.valueOf(b);
          arrayOfObject[3] = Integer.valueOf(b2);
          paramContext.getSession().getStdOut().printf("  It. %3d, fac= %11.6f, eval (no.,total): (%2d,%3d):\n", arrayOfObject);
          b++;
          b2++;
        } 
        for (byte b3 = 0; b3 < i; b3++)
          arrayOfDouble[b3] = atomicVector.getElementAsDouble(b3) + d2 * doubleVector.getElementAsDouble(b3); 
        if (nlsModel.updateParameters(arrayOfDouble))
          return convergenceResult(nlsControl, "singular gradient", b1, StopReason.SINGULAR_GRADIENT, d3); 
        double d = nlsModel.calculateDeviation();
        if (nlsControl.isPrintEval())
          paramContext.getSession().getStdOut().printf(" new dev = %f\n", new Object[] { Double.valueOf(d) }); 
        if (d <= d1) {
          d1 = d;
          d2 = Math.min(2.0D * d2, 1.0D);
          DoubleArrayVector doubleArrayVector = new DoubleArrayVector(arrayOfDouble);
          break;
        } 
        d2 /= 2.0D;
      } 
      if (d2 < nlsControl.getMinFactor()) {
        Object[] arrayOfObject = new Object[2];
        arrayOfObject[0] = Double.valueOf(d2);
        arrayOfObject[1] = Double.valueOf(nlsControl.getMinFactor());
        return convergenceResult(nlsControl, String.format("step factor %f reduced below 'minFactor' of %f", arrayOfObject), b1, StopReason.MIN_FACTOR_REACHED, d3);
      } 
      if (paramBoolean)
        nlsModel.trace(); 
    } 
    return !bool ? convergenceResult(nlsControl, String.format("number of iterations exceeded maximum of %d", new Object[] { Integer.valueOf(nlsControl.getMaxIterations()) }), b1, StopReason.MAX_ITERATIONS_EXCEEDED, d3) : convergenceResult(nlsControl, "converged", b1, StopReason.CONVERGED, d3);
  }
  
  public static SEXP numericDerivative(@Current Context paramContext, SEXP paramSEXP, StringVector paramStringVector, Environment paramEnvironment, DoubleVector paramDoubleVector) {
    if (paramDoubleVector.length() != paramStringVector.length())
      throw new EvalException("'dir' is not a numeric vector of the correct length", new Object[0]); 
    SEXP sEXP = paramContext.evaluate(paramSEXP, paramEnvironment);
    if (!(sEXP instanceof Vector))
      throw new EvalException("Expected numeric response from model", new Object[0]); 
    Vector vector = (Vector)sEXP;
    for (byte b1 = 0; b1 != vector.length(); b1++) {
      if (!DoubleVector.isFinite(vector.getElementAsDouble(b1)))
        throw new EvalException("Missing value or an infinity produced when evaluating the model", new Object[0]); 
    } 
    double[][] arrayOfDouble = new double[paramStringVector.length()][];
    int i = 0;
    byte b2;
    for (b2 = 0; b2 < paramStringVector.length(); b2++) {
      String str = paramStringVector.getElementAsString(b2);
      SEXP sEXP1 = paramEnvironment.findVariable(paramContext, Symbol.get(str));
      if (!(sEXP1 instanceof AtomicVector))
        throw new EvalException("variable '%s' is not numeric", new Object[] { str }); 
      arrayOfDouble[b2] = ((AtomicVector)sEXP1).toDoubleArray();
      i += (arrayOfDouble[b2]).length;
    } 
    double d = Math.sqrt(2.220446E-16D);
    DoubleMatrixBuilder doubleMatrixBuilder = new DoubleMatrixBuilder();
    this(vector.length(), i);
    b2 = 0;
    for (byte b3 = 0; b3 < paramStringVector.length(); b3++) {
      double d1 = paramDoubleVector.getElementAsDouble(b3);
      for (byte b = 0; b < (arrayOfDouble[b3]).length; b++) {
        double d2 = arrayOfDouble[b3][b];
        double d3 = Math.abs(d2);
        if (d3 == 0.0D) {
          d4 = d;
        } else {
          d4 = d3 * d;
        } 
        d3 = d4;
        double d4 = arrayOfDouble[b3][b] + d1 * d4;
        arrayOfDouble[b3][b] = d4;
        paramEnvironment.setVariable(paramContext, paramStringVector.getElementAsString(b3), (SEXP)new DoubleArrayVector(arrayOfDouble[b3]));
        DoubleVector doubleVector = (DoubleVector)paramContext.evaluate(paramSEXP, paramEnvironment);
        for (byte b4 = 0; b4 < vector.length(); b4++) {
          if (!DoubleVector.isFinite(doubleVector.getElementAsDouble(b4)))
            throw new EvalException("Missing value or an infinity produced when evaluating the model", new Object[0]); 
          doubleMatrixBuilder.set(b4, b2, d1 * (doubleVector.getElementAsDouble(b4) - vector.getElementAsDouble(b4)) / d3);
        } 
        arrayOfDouble[b3][b] = d2;
        b2++;
      } 
      paramEnvironment.setVariable(paramContext, paramStringVector.getElementAsString(b3), (SEXP)new DoubleArrayVector(arrayOfDouble[b3]));
    } 
    return vector.setAttribute(Symbol.get("gradient"), (SEXP)doubleMatrixBuilder.build());
  }
  
  private enum StopReason {
    CONVERGED, SINGULAR_GRADIENT, MIN_FACTOR_REACHED, MAX_ITERATIONS_EXCEEDED;
    
    static {
      StopReason[] arrayOfStopReason = new StopReason[4];
      arrayOfStopReason[0] = CONVERGED;
      arrayOfStopReason[1] = SINGULAR_GRADIENT;
      arrayOfStopReason[2] = MIN_FACTOR_REACHED;
      arrayOfStopReason[3] = MAX_ITERATIONS_EXCEEDED;
      $VALUES = arrayOfStopReason;
    }
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/stats-0.9.2724.jar!/org/renjin/stats/nls/NonlinearLeastSquares.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */