package org.renjin.stats;

import org.renjin.gcc.runtime.IntPtr;
import org.renjin.gcc.runtime.Ptr;

public class bsplvd__ {
  public static double[] deltal$1815 = new double[20];
  
  public static double[] deltar$1817 = new double[20];
  
  public static int j$1819;
  
  public static int $bsplvb_$j;
  
  public static double[] $bsplvb_$deltar = new double[20];
  
  public static double[] $bsplvb_$deltal = new double[20];
  
  static {
    j$1819 = 1;
    $bsplvb_$j = 1;
  }
  
  public static void bsplvb_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7) {
    // Byte code:
    //   0: aload_2
    //   1: invokeinterface getInt : ()I
    //   6: iconst_0
    //   7: invokestatic max : (II)I
    //   10: invokestatic toUnsignedLong : (I)J
    //   13: pop2
    //   14: aload_1
    //   15: invokeinterface getInt : ()I
    //   20: iconst_0
    //   21: invokestatic max : (II)I
    //   24: invokestatic toUnsignedLong : (I)J
    //   27: pop2
    //   28: aload_3
    //   29: invokeinterface getInt : ()I
    //   34: iconst_2
    //   35: if_icmpeq -> 62
    //   38: iconst_1
    //   39: putstatic org/renjin/stats/bsplvd__.$bsplvb_$j : I
    //   42: aload #6
    //   44: dconst_1
    //   45: invokeinterface setDouble : (D)V
    //   50: aload_2
    //   51: invokeinterface getInt : ()I
    //   56: getstatic org/renjin/stats/bsplvd__.$bsplvb_$j : I
    //   59: if_icmple -> 299
    //   62: getstatic org/renjin/stats/bsplvd__.$bsplvb_$j : I
    //   65: iconst_1
    //   66: iadd
    //   67: istore_1
    //   68: getstatic org/renjin/stats/bsplvd__.$bsplvb_$j : I
    //   71: iconst_m1
    //   72: iadd
    //   73: istore_3
    //   74: aload_0
    //   75: aload #5
    //   77: invokeinterface getInt : ()I
    //   82: getstatic org/renjin/stats/bsplvd__.$bsplvb_$j : I
    //   85: iadd
    //   86: iconst_m1
    //   87: iadd
    //   88: invokeinterface getAlignedDouble : (I)D
    //   93: aload #4
    //   95: invokeinterface getDouble : ()D
    //   100: dsub
    //   101: dstore #7
    //   103: getstatic org/renjin/stats/bsplvd__.$bsplvb_$deltar : [D
    //   106: iload_3
    //   107: dload #7
    //   109: dastore
    //   110: getstatic org/renjin/stats/bsplvd__.$bsplvb_$j : I
    //   113: iconst_m1
    //   114: iadd
    //   115: istore_3
    //   116: aload #4
    //   118: invokeinterface getDouble : ()D
    //   123: aload_0
    //   124: aload #5
    //   126: invokeinterface getInt : ()I
    //   131: iconst_1
    //   132: iadd
    //   133: getstatic org/renjin/stats/bsplvd__.$bsplvb_$j : I
    //   136: isub
    //   137: iconst_m1
    //   138: iadd
    //   139: invokeinterface getAlignedDouble : (I)D
    //   144: dsub
    //   145: dstore #7
    //   147: getstatic org/renjin/stats/bsplvd__.$bsplvb_$deltal : [D
    //   150: iload_3
    //   151: dload #7
    //   153: dastore
    //   154: dconst_0
    //   155: dstore #9
    //   157: getstatic org/renjin/stats/bsplvd__.$bsplvb_$j : I
    //   160: istore_3
    //   161: iconst_1
    //   162: istore #11
    //   164: iconst_1
    //   165: iload_3
    //   166: if_icmple -> 172
    //   169: goto -> 271
    //   172: aload #6
    //   174: aload #6
    //   176: iload #11
    //   178: iconst_m1
    //   179: iadd
    //   180: invokeinterface getAlignedDouble : (I)D
    //   185: getstatic org/renjin/stats/bsplvd__.$bsplvb_$deltar : [D
    //   188: iload #11
    //   190: iconst_m1
    //   191: iadd
    //   192: daload
    //   193: getstatic org/renjin/stats/bsplvd__.$bsplvb_$deltal : [D
    //   196: iload_1
    //   197: iload #11
    //   199: isub
    //   200: iconst_m1
    //   201: iadd
    //   202: daload
    //   203: dadd
    //   204: ddiv
    //   205: dstore #7
    //   207: iload #11
    //   209: iconst_m1
    //   210: iadd
    //   211: getstatic org/renjin/stats/bsplvd__.$bsplvb_$deltar : [D
    //   214: iload #11
    //   216: iconst_m1
    //   217: iadd
    //   218: daload
    //   219: dload #7
    //   221: dmul
    //   222: dload #9
    //   224: dadd
    //   225: invokeinterface setAlignedDouble : (ID)V
    //   230: getstatic org/renjin/stats/bsplvd__.$bsplvb_$deltal : [D
    //   233: iload_1
    //   234: iload #11
    //   236: isub
    //   237: iconst_m1
    //   238: iadd
    //   239: daload
    //   240: dload #7
    //   242: dmul
    //   243: dstore #9
    //   245: iload #11
    //   247: iload_3
    //   248: if_icmpeq -> 257
    //   251: iconst_0
    //   252: istore #12
    //   254: goto -> 260
    //   257: iconst_1
    //   258: istore #12
    //   260: iinc #11, 1
    //   263: iload #12
    //   265: ifne -> 271
    //   268: goto -> 172
    //   271: aload #6
    //   273: iload_1
    //   274: iconst_m1
    //   275: iadd
    //   276: dload #9
    //   278: invokeinterface setAlignedDouble : (ID)V
    //   283: iload_1
    //   284: putstatic org/renjin/stats/bsplvd__.$bsplvb_$j : I
    //   287: aload_2
    //   288: invokeinterface getInt : ()I
    //   293: getstatic org/renjin/stats/bsplvd__.$bsplvb_$j : I
    //   296: if_icmpgt -> 62
    //   299: return
  }
  
  public static void bsplvd_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8) {
    int[] arrayOfInt1 = new int[1];
    int[] arrayOfInt2 = new int[1];
    Integer.toUnsignedLong(Math.max(paramPtr2.getInt(), 0));
    int k = Math.max(paramPtr3.getInt(), 0);
    Integer.toUnsignedLong(Math.max(k * paramPtr8.getInt(), 0));
    int m = k ^ 0xFFFFFFFF;
    int n = Math.max(paramPtr3.getInt(), 0);
    Integer.toUnsignedLong(Math.max(n * paramPtr3.getInt(), 0));
    int i1 = n ^ 0xFFFFFFFF;
    int i = paramPtr8.getInt();
    int j = paramPtr3.getInt();
    if (j < i)
      i = j; 
    int i2 = i;
    if (i <= 0)
      i2 = 1; 
    i = i2;
    j = paramPtr3.getInt() + 1;
    arrayOfInt2[0] = j - i2;
    bsplvb_(paramPtr1, paramPtr2, (Ptr)new IntPtr(arrayOfInt2, 0), (Ptr)new IntPtr(new int[] { 1 }, 0), paramPtr4, paramPtr5, paramPtr7);
    if (i2 != 1) {
      int i6 = i2;
      int i7 = i2;
      int i8 = 2;
      if (2 <= i2)
        while (true) {
          i2 = 1;
          int i9 = paramPtr3.getInt();
          int i10 = i6;
          if (i6 <= i9)
            while (true) {
              boolean bool;
              paramPtr7.setAlignedDouble(i6 * k + m + i10, paramPtr7.getAlignedDouble(m + k + i2));
              i2++;
              if (i10 != i9) {
                bool = false;
              } else {
                bool = true;
              } 
              i10++;
              if (!bool)
                continue; 
              break;
            }  
          arrayOfInt1[0] = j - --i6;
          bsplvb_(paramPtr1, paramPtr2, (Ptr)new IntPtr(arrayOfInt1, 0), (Ptr)new IntPtr(new int[] { 2 }, 0), paramPtr4, paramPtr5, paramPtr7);
          if (i8 != i7) {
            i2 = 0;
          } else {
            i2 = 1;
          } 
          i8++;
          if (i2 == 0)
            continue; 
          break;
        }  
      int i5 = 1;
      int i3 = paramPtr3.getInt();
      int i4 = 1;
      if (1 <= i3)
        while (true) {
          i6 = paramPtr3.getInt();
          i7 = i5;
          if (i5 <= i6)
            while (true) {
              paramPtr6.setAlignedDouble(i4 * n + i1 + i7, 0.0D);
              if (i7 != i6) {
                i5 = 0;
              } else {
                i5 = 1;
              } 
              i7++;
              if (i5 == 0)
                continue; 
              break;
            }  
          i5 = i4;
          paramPtr6.setAlignedDouble(i4 * n + i1 + i4, 1.0D);
          if (i4 != i3) {
            i6 = 0;
          } else {
            i6 = 1;
          } 
          i4++;
          if (i6 == 0)
            continue; 
          break;
        }  
      i3 = 2;
      if (2 <= i)
        while (true) {
          i4 = j - i3;
          double d = i4;
          i5 = paramPtr5.getInt();
          i6 = paramPtr3.getInt();
          i7 = 1;
          if (1 <= i4)
            while (true) {
              double d1 = d / (paramPtr1.getAlignedDouble(i5 + i4 + -1) - paramPtr1.getAlignedDouble(i5 + -1));
              i8 = i6;
              i2 = 1;
              if (1 <= i6)
                while (true) {
                  boolean bool;
                  paramPtr6.setAlignedDouble(i2 * n + i1 + i6, (paramPtr6.getAlignedDouble(i2 * n + i1 + i6) - paramPtr6.getAlignedDouble(i2 * n + i1 + i6 + -1)) * d1);
                  if (i2 != i8) {
                    bool = false;
                  } else {
                    bool = true;
                  } 
                  i2++;
                  if (!bool)
                    continue; 
                  break;
                }  
              i5--;
              i6--;
              if (i7 != i4) {
                i8 = 0;
              } else {
                i8 = 1;
              } 
              i7++;
              if (i8 == 0)
                continue; 
              break;
            }  
          i4 = paramPtr3.getInt();
          i5 = 1;
          if (1 <= i4)
            while (true) {
              d = 0.0D;
              i8 = i5;
              if (i3 > i5)
                i8 = i3; 
              i6 = paramPtr3.getInt();
              i7 = i8;
              if (i8 <= i6)
                while (true) {
                  d = paramPtr6.getAlignedDouble(i5 * n + i1 + i7) * paramPtr7.getAlignedDouble(i3 * k + m + i7) + d;
                  if (i7 != i6) {
                    i8 = 0;
                  } else {
                    i8 = 1;
                  } 
                  i7++;
                  if (i8 == 0)
                    continue; 
                  break;
                }  
              paramPtr7.setAlignedDouble(i3 * k + m + i5, d);
              if (i5 != i4) {
                i6 = 0;
              } else {
                i6 = 1;
              } 
              i5++;
              if (i6 == 0)
                continue; 
              break;
            }  
          if (i3 != i) {
            i4 = 0;
          } else {
            i4 = 1;
          } 
          i3++;
          if (i4 == 0)
            continue; 
          break;
        }  
    } 
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/stats-0.9.2724.jar!/org/renjin/stats/bsplvd__.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */