package org.renjin.stats;

import java.lang.invoke.MethodHandle;
import org.renjin.gcc.runtime.BytePtr;
import org.renjin.gcc.runtime.DoublePtr;
import org.renjin.gcc.runtime.IntPtr;
import org.renjin.gcc.runtime.Mathlib;
import org.renjin.gcc.runtime.MixedPtr;
import org.renjin.gcc.runtime.Ptr;
import org.renjin.gcc.runtime.RecordUnitPtr;
import org.renjin.gcc.runtime.UnsatisfiedLinkException;
import org.renjin.gnur.api.Arith;
import org.renjin.gnur.api.Defn;
import org.renjin.gnur.api.Error;
import org.renjin.gnur.api.GetText;
import org.renjin.gnur.api.Print;
import org.renjin.gnur.api.Rinternals;
import org.renjin.gnur.api.Rinternals2;
import org.renjin.sexp.SEXP;

public class optimize__ {
  public static int LoadInitFile = 0;
  
  public static int R_ReadItemDepth = 0;
  
  public static int R_InitReadItemDepth = 0;
  
  public static int R_OutputCon = 0;
  
  public static double Brent_fmin(double paramDouble1, double paramDouble2, MethodHandle paramMethodHandle, Ptr paramPtr, double paramDouble3) {
    double d1 = Mathlib.sqrt(2.220446049250313E-16D);
    double d2 = paramDouble1;
    double d3 = paramDouble2;
    paramDouble1 = (paramDouble2 - paramDouble1) * 0.3819660112501051D + paramDouble1;
    paramDouble2 = paramDouble1;
    double d4 = paramDouble1;
    double d5 = 0.0D;
    double d6 = 0.0D;
    double d7 = paramMethodHandle.invoke(paramDouble1, paramPtr);
    double d8 = d7;
    double d9 = d7;
    paramDouble3 /= 3.0D;
    while (true) {
      double d10 = (d2 + d3) * 0.5D;
      double d12 = Math.abs(d4) * d1 + paramDouble3;
      double d11 = d12 * 2.0D;
      if (Math.abs(d4 - d10) > d11 - (d3 - d2) * 0.5D) {
        double d13 = 0.0D;
        double d14 = 0.0D;
        double d15 = 0.0D;
        if (Math.abs(d6) > d12) {
          d14 = (d4 - paramDouble2) * (d7 - d8);
          d15 = (d4 - paramDouble1) * (d7 - d9);
          d13 = (d4 - paramDouble1) * d15 - (d4 - paramDouble2) * d14;
          d14 = (d15 - d14) * 2.0D;
          if (d14 <= 0.0D) {
            d14 = -d14;
          } else {
            d13 = -d13;
          } 
          d15 = d6;
          d6 = d5;
        } 
        if (Math.abs(d13) < Math.abs(d14 * 0.5D * d15) && (d2 - d4) * d14 < d13 && (d3 - d4) * d14 > d13) {
          d5 = d13 / d14;
          d13 = d4 + d5;
          if (d13 - d2 < d11 || d3 - d13 < d11) {
            d5 = d12;
            if (d4 >= d10)
              d5 = -d12; 
          } 
        } else {
          if (d4 >= d10) {
            d6 = d2 - d4;
          } else {
            d6 = d3 - d4;
          } 
          d5 = 0.3819660112501051D * d6;
        } 
        if (Math.abs(d5) < d12) {
          if (d5 <= 0.0D) {
            d11 = d4 - d12;
          } else {
            d11 = d4 + d12;
          } 
        } else {
          d11 = d4 + d5;
        } 
        d10 = paramMethodHandle.invoke(d11, paramPtr);
        if (d10 > d7) {
          if (d11 >= d4) {
            d3 = d11;
          } else {
            d2 = d11;
          } 
          if (d10 > d9 && paramDouble2 != d4) {
            if (d10 > d8 && paramDouble1 != d4 && paramDouble1 != paramDouble2)
              continue; 
            paramDouble1 = d11;
            d8 = d10;
            continue;
          } 
          paramDouble1 = paramDouble2;
          d8 = d9;
          paramDouble2 = d11;
          d9 = d10;
          continue;
        } 
        if (d11 >= d4) {
          d2 = d4;
        } else {
          d3 = d4;
        } 
        paramDouble1 = paramDouble2;
        paramDouble2 = d4;
        d4 = d11;
        d8 = d9;
        d9 = d7;
        d7 = d10;
        continue;
      } 
      return d4;
    } 
  }
  
  public static void Cd1fcn(int paramInt, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3) {
    int i = FT_lookup(paramInt, paramPtr1, paramPtr3);
    if (i < 0) {
      fcn(paramInt, paramPtr1, paramPtr2, paramPtr3);
      i = FT_lookup(paramInt, paramPtr1, paramPtr3);
      if (i < 0)
        Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("function value caching for optimization is seriously confused\000".getBytes(), 0)), new Object[0]); 
    } 
    paramPtr2.memcpy(paramPtr3.getAlignedPointer(6).getPointer(0 + i * 20 + 12), paramInt * 8);
  }
  
  public static void Cd2fcn(int paramInt1, int paramInt2, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3) {
    paramInt1 = FT_lookup(paramInt2, paramPtr1, paramPtr3);
    if (paramInt1 < 0) {
      fcn(paramInt2, paramPtr1, paramPtr2, paramPtr3);
      paramInt1 = FT_lookup(paramInt2, paramPtr1, paramPtr3);
      if (paramInt1 < 0)
        Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("function value caching for optimization is seriously confused\000".getBytes(), 0)), new Object[0]); 
    } 
    for (byte b = 0; b < paramInt2; b++) {
      paramPtr1 = paramPtr2.pointerPlus((paramInt2 + 1) * 8 * b);
      Ptr ptr = paramPtr3.getAlignedPointer(6).getPointer(0 + paramInt1 * 20 + 16).pointerPlus(0 + (paramInt2 + 1) * 8 * b);
      paramPtr1.memcpy(ptr, (paramInt2 - b) * 8);
    } 
  }
  
  public static void FT_init(int paramInt1, int paramInt2, Ptr paramPtr) {
    BytePtr.of(0);
    int i = paramPtr.getAlignedInt(2);
    int j = paramPtr.getAlignedInt(3);
    MixedPtr mixedPtr = MixedPtr.malloc(paramInt2 * 20);
    for (byte b = 0; b < paramInt2; b++) {
      mixedPtr.setPointer(0 + b * 20 + 8, (Ptr)DoublePtr.malloc(paramInt1 * 8));
      for (byte b1 = 0; b1 < paramInt1; b1++)
        mixedPtr.getPointer(0 + b * 20 + 8).setDouble(0 + b1 * 8, Double.MAX_VALUE); 
      if (i != 0) {
        mixedPtr.setPointer(0 + b * 20 + 12, (Ptr)DoublePtr.malloc(paramInt1 * 8));
        if (j != 0)
          mixedPtr.setPointer(0 + b * 20 + 16, (Ptr)DoublePtr.malloc(paramInt1 * paramInt1 * 8)); 
      } 
    } 
    paramPtr.setAlignedPointer(6, mixedPtr.pointerPlus(0));
    paramPtr.setAlignedInt(4, paramInt2);
    paramPtr.setAlignedInt(5, -1);
  }
  
  public static int FT_lookup(int paramInt, Ptr paramPtr1, Ptr paramPtr2) {
    BytePtr.of(0);
    BytePtr.of(0);
    int i = paramPtr2.getAlignedInt(5);
    int j = paramPtr2.getAlignedInt(4);
    paramPtr2 = paramPtr2.getAlignedPointer(6);
    for (byte b = 0;; b++) {
      if (b >= j) {
        paramInt = -1;
        break;
      } 
      int k = (i - b) % j;
      if (k < 0)
        k += j; 
      Ptr ptr = paramPtr2.getPointer(0 + k * 20 + 8);
      if (!ptr.pointerPlus(0).isNull()) {
        boolean bool = true;
        byte b1 = 0;
        while (b1 < paramInt) {
          if (paramPtr1.getDouble(b1 * 8) == ptr.getDouble(0 + b1 * 8)) {
            b1++;
            continue;
          } 
          bool = false;
          break;
        } 
        if (bool) {
          paramInt = k;
          break;
        } 
      } 
    } 
    return paramInt;
  }
  
  public static void FT_store(int paramInt, double paramDouble, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4) {
    paramPtr4.setAlignedInt(5, paramPtr4.getAlignedInt(5) + 1);
    int i = paramPtr4.getAlignedInt(5) % paramPtr4.getAlignedInt(4);
    paramPtr4.getAlignedPointer(6).setDouble(0 + i * 20, paramDouble);
    paramPtr4.getAlignedPointer(6).getPointer(0 + i * 20 + 8).memcpy(paramPtr1, paramInt * 8);
    if (!paramPtr2.isNull()) {
      paramPtr4.getAlignedPointer(6).getPointer(0 + i * 20 + 12).memcpy(paramPtr2, paramInt * 8);
      if (!paramPtr3.isNull())
        paramPtr4.getAlignedPointer(6).getPointer(0 + i * 20 + 16).memcpy(paramPtr3, paramInt * paramInt * 8); 
    } 
  }
  
  public static SEXP do_fmin(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4) {
    // Byte code:
    //   0: bipush #8
    //   2: invokestatic malloc : (I)Lorg/renjin/gcc/runtime/MixedPtr;
    //   5: astore_0
    //   6: aload_2
    //   7: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   10: astore_2
    //   11: invokestatic Rf_PrintDefaults : ()V
    //   14: aload_2
    //   15: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   18: astore_1
    //   19: aload_1
    //   20: invokestatic Rf_isFunction : (Lorg/renjin/sexp/SEXP;)Z
    //   23: ifeq -> 29
    //   26: goto -> 68
    //   29: new org/renjin/gcc/runtime/BytePtr
    //   32: dup
    //   33: ldc 'stats '
    //   35: invokevirtual getBytes : ()[B
    //   38: iconst_0
    //   39: invokespecial <init> : ([BI)V
    //   42: new org/renjin/gcc/runtime/BytePtr
    //   45: dup
    //   46: ldc 'attempt to minimize non-function '
    //   48: invokevirtual getBytes : ()[B
    //   51: iconst_0
    //   52: invokespecial <init> : ([BI)V
    //   55: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
    //   58: checkcast org/renjin/gcc/runtime/BytePtr
    //   61: iconst_0
    //   62: anewarray java/lang/Object
    //   65: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
    //   68: aload_2
    //   69: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   72: astore_2
    //   73: aload_2
    //   74: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   77: invokestatic Rf_asReal : (Lorg/renjin/sexp/SEXP;)D
    //   80: dstore #8
    //   82: dload #8
    //   84: invokestatic R_finite : (D)I
    //   87: ifeq -> 93
    //   90: goto -> 148
    //   93: new org/renjin/gcc/runtime/BytePtr
    //   96: dup
    //   97: ldc 'stats '
    //   99: invokevirtual getBytes : ()[B
    //   102: iconst_0
    //   103: invokespecial <init> : ([BI)V
    //   106: new org/renjin/gcc/runtime/BytePtr
    //   109: dup
    //   110: ldc 'invalid '%s' value '
    //   112: invokevirtual getBytes : ()[B
    //   115: iconst_0
    //   116: invokespecial <init> : ([BI)V
    //   119: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
    //   122: checkcast org/renjin/gcc/runtime/BytePtr
    //   125: iconst_1
    //   126: anewarray java/lang/Object
    //   129: dup
    //   130: iconst_0
    //   131: new org/renjin/gcc/runtime/BytePtr
    //   134: dup
    //   135: ldc 'xmin '
    //   137: invokevirtual getBytes : ()[B
    //   140: iconst_0
    //   141: invokespecial <init> : ([BI)V
    //   144: aastore
    //   145: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
    //   148: aload_2
    //   149: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   152: astore_2
    //   153: aload_2
    //   154: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   157: invokestatic Rf_asReal : (Lorg/renjin/sexp/SEXP;)D
    //   160: dstore #6
    //   162: dload #6
    //   164: invokestatic R_finite : (D)I
    //   167: ifeq -> 173
    //   170: goto -> 228
    //   173: new org/renjin/gcc/runtime/BytePtr
    //   176: dup
    //   177: ldc 'stats '
    //   179: invokevirtual getBytes : ()[B
    //   182: iconst_0
    //   183: invokespecial <init> : ([BI)V
    //   186: new org/renjin/gcc/runtime/BytePtr
    //   189: dup
    //   190: ldc 'invalid '%s' value '
    //   192: invokevirtual getBytes : ()[B
    //   195: iconst_0
    //   196: invokespecial <init> : ([BI)V
    //   199: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
    //   202: checkcast org/renjin/gcc/runtime/BytePtr
    //   205: iconst_1
    //   206: anewarray java/lang/Object
    //   209: dup
    //   210: iconst_0
    //   211: new org/renjin/gcc/runtime/BytePtr
    //   214: dup
    //   215: ldc 'xmax '
    //   217: invokevirtual getBytes : ()[B
    //   220: iconst_0
    //   221: invokespecial <init> : ([BI)V
    //   224: aastore
    //   225: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
    //   228: dload #8
    //   230: dload #6
    //   232: dcmpl
    //   233: ifge -> 239
    //   236: goto -> 278
    //   239: new org/renjin/gcc/runtime/BytePtr
    //   242: dup
    //   243: ldc 'stats '
    //   245: invokevirtual getBytes : ()[B
    //   248: iconst_0
    //   249: invokespecial <init> : ([BI)V
    //   252: new org/renjin/gcc/runtime/BytePtr
    //   255: dup
    //   256: ldc ''xmin' not less than 'xmax' '
    //   258: invokevirtual getBytes : ()[B
    //   261: iconst_0
    //   262: invokespecial <init> : ([BI)V
    //   265: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
    //   268: checkcast org/renjin/gcc/runtime/BytePtr
    //   271: iconst_0
    //   272: anewarray java/lang/Object
    //   275: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
    //   278: aload_2
    //   279: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   282: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   285: invokestatic Rf_asReal : (Lorg/renjin/sexp/SEXP;)D
    //   288: dstore #4
    //   290: dload #4
    //   292: invokestatic R_finite : (D)I
    //   295: ifeq -> 308
    //   298: dload #4
    //   300: dconst_0
    //   301: dcmpg
    //   302: ifle -> 308
    //   305: goto -> 363
    //   308: new org/renjin/gcc/runtime/BytePtr
    //   311: dup
    //   312: ldc 'stats '
    //   314: invokevirtual getBytes : ()[B
    //   317: iconst_0
    //   318: invokespecial <init> : ([BI)V
    //   321: new org/renjin/gcc/runtime/BytePtr
    //   324: dup
    //   325: ldc 'invalid '%s' value '
    //   327: invokevirtual getBytes : ()[B
    //   330: iconst_0
    //   331: invokespecial <init> : ([BI)V
    //   334: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
    //   337: checkcast org/renjin/gcc/runtime/BytePtr
    //   340: iconst_1
    //   341: anewarray java/lang/Object
    //   344: dup
    //   345: iconst_0
    //   346: new org/renjin/gcc/runtime/BytePtr
    //   349: dup
    //   350: ldc 'tol '
    //   352: invokevirtual getBytes : ()[B
    //   355: iconst_0
    //   356: invokespecial <init> : ([BI)V
    //   359: aastore
    //   360: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
    //   363: aload_0
    //   364: iconst_1
    //   365: new org/renjin/gcc/runtime/RecordUnitPtr
    //   368: dup
    //   369: aload_3
    //   370: invokespecial <init> : (Ljava/lang/Object;)V
    //   373: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   378: aload_0
    //   379: new org/renjin/gcc/runtime/RecordUnitPtr
    //   382: dup
    //   383: aload_1
    //   384: getstatic org/renjin/gnur/api/Rinternals.R_NilValue : Lorg/renjin/sexp/SEXP;
    //   387: invokestatic Rf_lang2 : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   390: invokespecial <init> : (Ljava/lang/Object;)V
    //   393: invokeinterface setPointer : (Lorg/renjin/gcc/runtime/Ptr;)V
    //   398: aload_0
    //   399: invokeinterface getPointer : ()Lorg/renjin/gcc/runtime/Ptr;
    //   404: invokeinterface getArray : ()Ljava/lang/Object;
    //   409: checkcast org/renjin/sexp/SEXP
    //   412: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   415: pop
    //   416: bipush #14
    //   418: iconst_1
    //   419: invokestatic Rf_allocVector : (II)Lorg/renjin/sexp/SEXP;
    //   422: astore_1
    //   423: aload_1
    //   424: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   427: pop
    //   428: aload_1
    //   429: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
    //   432: iconst_0
    //   433: dload #8
    //   435: dload #6
    //   437: ldc
    //   439: aload_0
    //   440: dload #4
    //   442: invokestatic Brent_fmin : (DDLjava/lang/invoke/MethodHandle;Lorg/renjin/gcc/runtime/Ptr;D)D
    //   445: invokeinterface setDouble : (ID)V
    //   450: aload_1
    //   451: areturn
  }
  
  public static void fcn(int paramInt, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3) {
    // Byte code:
    //   0: iconst_0
    //   1: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   4: pop
    //   5: iconst_0
    //   6: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   9: pop
    //   10: iconst_0
    //   11: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   14: invokeinterface getArray : ()Ljava/lang/Object;
    //   19: checkcast org/renjin/sexp/SEXP
    //   22: astore #6
    //   24: iconst_0
    //   25: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   28: astore #6
    //   30: iconst_0
    //   31: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   34: astore #7
    //   36: aload_3
    //   37: invokeinterface getPointer : ()Lorg/renjin/gcc/runtime/Ptr;
    //   42: invokeinterface getArray : ()Ljava/lang/Object;
    //   47: checkcast org/renjin/sexp/SEXP
    //   50: astore #5
    //   52: aload_3
    //   53: bipush #6
    //   55: invokeinterface getAlignedPointer : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   60: astore #4
    //   62: iload_0
    //   63: aload_1
    //   64: aload_3
    //   65: invokestatic FT_lookup : (ILorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
    //   68: istore #8
    //   70: iload #8
    //   72: ifge -> 78
    //   75: goto -> 101
    //   78: aload_2
    //   79: aload #4
    //   81: iconst_0
    //   82: iload #8
    //   84: bipush #20
    //   86: imul
    //   87: iadd
    //   88: invokeinterface getDouble : (I)D
    //   93: invokeinterface setDouble : (D)V
    //   98: goto -> 677
    //   101: bipush #14
    //   103: iload_0
    //   104: invokestatic Rf_allocVector : (II)Lorg/renjin/sexp/SEXP;
    //   107: astore #4
    //   109: aload #5
    //   111: aload #4
    //   113: invokestatic SETCADR : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   116: pop
    //   117: iconst_0
    //   118: istore #5
    //   120: goto -> 213
    //   123: aload_1
    //   124: iload #5
    //   126: bipush #8
    //   128: imul
    //   129: invokeinterface getDouble : (I)D
    //   134: invokestatic R_finite : (D)I
    //   137: ifeq -> 143
    //   140: goto -> 182
    //   143: new org/renjin/gcc/runtime/BytePtr
    //   146: dup
    //   147: ldc 'stats '
    //   149: invokevirtual getBytes : ()[B
    //   152: iconst_0
    //   153: invokespecial <init> : ([BI)V
    //   156: new org/renjin/gcc/runtime/BytePtr
    //   159: dup
    //   160: ldc 'non-finite value supplied by 'nlm' '
    //   162: invokevirtual getBytes : ()[B
    //   165: iconst_0
    //   166: invokespecial <init> : ([BI)V
    //   169: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
    //   172: checkcast org/renjin/gcc/runtime/BytePtr
    //   175: iconst_0
    //   176: anewarray java/lang/Object
    //   179: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
    //   182: aload #4
    //   184: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
    //   187: iconst_0
    //   188: iload #5
    //   190: bipush #8
    //   192: imul
    //   193: iadd
    //   194: aload_1
    //   195: iload #5
    //   197: bipush #8
    //   199: imul
    //   200: invokeinterface getDouble : (I)D
    //   205: invokeinterface setDouble : (ID)V
    //   210: iinc #5, 1
    //   213: iload #5
    //   215: iload_0
    //   216: if_icmplt -> 123
    //   219: aload_3
    //   220: iconst_1
    //   221: invokeinterface getAlignedPointer : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   226: invokeinterface getArray : ()Ljava/lang/Object;
    //   231: checkcast org/renjin/sexp/SEXP
    //   234: astore #5
    //   236: aload_3
    //   237: invokeinterface getPointer : ()Lorg/renjin/gcc/runtime/Ptr;
    //   242: invokeinterface getArray : ()Ljava/lang/Object;
    //   247: checkcast org/renjin/sexp/SEXP
    //   250: aload #5
    //   252: invokestatic Rf_eval : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   255: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   258: astore #5
    //   260: aload #5
    //   262: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
    //   265: lookupswitch default -> 491, 13 -> 292, 14 -> 392
    //   292: aload #5
    //   294: invokestatic Rf_length : (Lorg/renjin/sexp/SEXP;)I
    //   297: iconst_1
    //   298: if_icmpne -> 637
    //   301: aload #5
    //   303: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
    //   306: invokeinterface getInt : ()I
    //   311: getstatic org/renjin/gnur/api/Arith.R_NaInt : I
    //   314: if_icmpeq -> 320
    //   317: goto -> 372
    //   320: new org/renjin/gcc/runtime/BytePtr
    //   323: dup
    //   324: ldc 'stats '
    //   326: invokevirtual getBytes : ()[B
    //   329: iconst_0
    //   330: invokespecial <init> : ([BI)V
    //   333: new org/renjin/gcc/runtime/BytePtr
    //   336: dup
    //   337: ldc_w 'NA replaced by maximum positive value '
    //   340: invokevirtual getBytes : ()[B
    //   343: iconst_0
    //   344: invokespecial <init> : ([BI)V
    //   347: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
    //   350: checkcast org/renjin/gcc/runtime/BytePtr
    //   353: iconst_0
    //   354: anewarray java/lang/Object
    //   357: invokestatic Rf_warning : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
    //   360: aload_2
    //   361: ldc2_w 1.7976931348623157E308
    //   364: invokeinterface setDouble : (D)V
    //   369: goto -> 494
    //   372: aload_2
    //   373: aload #5
    //   375: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
    //   378: invokeinterface getInt : ()I
    //   383: i2d
    //   384: invokeinterface setDouble : (D)V
    //   389: goto -> 494
    //   392: aload #5
    //   394: invokestatic Rf_length : (Lorg/renjin/sexp/SEXP;)I
    //   397: iconst_1
    //   398: if_icmpne -> 637
    //   401: aload #5
    //   403: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
    //   406: invokeinterface getDouble : ()D
    //   411: invokestatic R_finite : (D)I
    //   414: ifeq -> 420
    //   417: goto -> 472
    //   420: new org/renjin/gcc/runtime/BytePtr
    //   423: dup
    //   424: ldc 'stats '
    //   426: invokevirtual getBytes : ()[B
    //   429: iconst_0
    //   430: invokespecial <init> : ([BI)V
    //   433: new org/renjin/gcc/runtime/BytePtr
    //   436: dup
    //   437: ldc_w 'NA/Inf replaced by maximum positive value '
    //   440: invokevirtual getBytes : ()[B
    //   443: iconst_0
    //   444: invokespecial <init> : ([BI)V
    //   447: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
    //   450: checkcast org/renjin/gcc/runtime/BytePtr
    //   453: iconst_0
    //   454: anewarray java/lang/Object
    //   457: invokestatic Rf_warning : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
    //   460: aload_2
    //   461: ldc2_w 1.7976931348623157E308
    //   464: invokeinterface setDouble : (D)V
    //   469: goto -> 494
    //   472: aload_2
    //   473: aload #5
    //   475: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
    //   478: invokeinterface getDouble : ()D
    //   483: invokeinterface setDouble : (D)V
    //   488: goto -> 494
    //   491: goto -> 637
    //   494: aload_3
    //   495: iconst_2
    //   496: invokeinterface getAlignedInt : (I)I
    //   501: ifne -> 507
    //   504: goto -> 590
    //   507: aload #5
    //   509: new org/renjin/gcc/runtime/BytePtr
    //   512: dup
    //   513: ldc_w 'gradient '
    //   516: invokevirtual getBytes : ()[B
    //   519: iconst_0
    //   520: invokespecial <init> : ([BI)V
    //   523: invokestatic Rf_install : (Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/sexp/SEXP;
    //   526: invokestatic Rf_getAttrib : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   529: bipush #14
    //   531: invokestatic Rf_coerceVector : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
    //   534: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   537: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
    //   540: astore #6
    //   542: aload_3
    //   543: iconst_3
    //   544: invokeinterface getAlignedInt : (I)I
    //   549: ifne -> 555
    //   552: goto -> 590
    //   555: aload #5
    //   557: new org/renjin/gcc/runtime/BytePtr
    //   560: dup
    //   561: ldc_w 'hessian '
    //   564: invokevirtual getBytes : ()[B
    //   567: iconst_0
    //   568: invokespecial <init> : ([BI)V
    //   571: invokestatic Rf_install : (Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/sexp/SEXP;
    //   574: invokestatic Rf_getAttrib : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   577: bipush #14
    //   579: invokestatic Rf_coerceVector : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
    //   582: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   585: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
    //   588: astore #7
    //   590: iload_0
    //   591: aload_2
    //   592: invokeinterface getDouble : ()D
    //   597: aload_1
    //   598: aload #6
    //   600: iconst_0
    //   601: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   606: aload #7
    //   608: iconst_0
    //   609: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   614: aload_3
    //   615: invokestatic FT_store : (IDLorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)V
    //   618: aload_3
    //   619: iconst_2
    //   620: invokeinterface getAlignedInt : (I)I
    //   625: pop
    //   626: aload_3
    //   627: iconst_3
    //   628: invokeinterface getAlignedInt : (I)I
    //   633: pop
    //   634: goto -> 677
    //   637: new org/renjin/gcc/runtime/BytePtr
    //   640: dup
    //   641: ldc 'stats '
    //   643: invokevirtual getBytes : ()[B
    //   646: iconst_0
    //   647: invokespecial <init> : ([BI)V
    //   650: new org/renjin/gcc/runtime/BytePtr
    //   653: dup
    //   654: ldc_w 'invalid function value in 'nlm' optimizer '
    //   657: invokevirtual getBytes : ()[B
    //   660: iconst_0
    //   661: invokespecial <init> : ([BI)V
    //   664: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
    //   667: checkcast org/renjin/gcc/runtime/BytePtr
    //   670: iconst_0
    //   671: anewarray java/lang/Object
    //   674: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
    //   677: return
  }
  
  public static double fcn1(double paramDouble, Ptr paramPtr) {
    double d = 0.0D;
    SEXP sEXP2 = Rinternals.Rf_ScalarReal(paramDouble);
    Rinternals.Rf_protect(sEXP2);
    Rinternals.SETCADR((SEXP)paramPtr.getPointer().getArray(), sEXP2);
    sEXP2 = (SEXP)paramPtr.getAlignedPointer(1).getArray();
    SEXP sEXP1 = Rinternals.Rf_eval((SEXP)paramPtr.getPointer().getArray(), sEXP2);
    switch (Rinternals.TYPEOF(sEXP1)) {
      case 13:
        if (Rinternals.Rf_length(sEXP1) == 1) {
          if (Rinternals2.INTEGER(sEXP1).getInt() != Arith.R_NaInt)
            return Rinternals2.INTEGER(sEXP1).getInt(); 
          Error.Rf_warning(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("NA replaced by maximum positive value\000".getBytes(), 0)), new Object[0]);
          return Double.MAX_VALUE;
        } 
        break;
      case 14:
        if (Rinternals.Rf_length(sEXP1) == 1) {
          if (Arith.R_finite(Rinternals2.REAL(sEXP1).getDouble()) != 0)
            return Rinternals2.REAL(sEXP1).getDouble(); 
          Error.Rf_warning(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("NA/Inf replaced by maximum positive value\000".getBytes(), 0)), new Object[0]);
          return Double.MAX_VALUE;
        } 
        break;
    } 
    Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("invalid function value in 'optimize'\000".getBytes(), 0)), new Object[0]);
    return d;
  }
  
  public static double fcn2(double paramDouble, Ptr paramPtr) {
    double d = 0.0D;
    SEXP sEXP2 = Rinternals.Rf_ScalarReal(paramDouble);
    Rinternals.Rf_protect(sEXP2);
    Rinternals.SETCADR((SEXP)paramPtr.getPointer().getArray(), sEXP2);
    sEXP2 = (SEXP)paramPtr.getAlignedPointer(1).getArray();
    SEXP sEXP1 = Rinternals.Rf_eval((SEXP)paramPtr.getPointer().getArray(), sEXP2);
    switch (Rinternals.TYPEOF(sEXP1)) {
      case 13:
        if (Rinternals.Rf_length(sEXP1) == 1) {
          if (Rinternals2.INTEGER(sEXP1).getInt() != Arith.R_NaInt)
            return Rinternals2.INTEGER(sEXP1).getInt(); 
          Error.Rf_warning(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("NA replaced by maximum positive value\000".getBytes(), 0)), new Object[0]);
          return Double.MAX_VALUE;
        } 
        break;
      case 14:
        if (Rinternals.Rf_length(sEXP1) == 1) {
          if (Arith.R_finite(Rinternals2.REAL(sEXP1).getDouble()) != 0)
            return Rinternals2.REAL(sEXP1).getDouble(); 
          if (Rinternals2.REAL(sEXP1).getDouble() != Arith.R_NegInf) {
            Error.Rf_warning(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("NA/Inf replaced by maximum positive value\000".getBytes(), 0)), new Object[0]);
            return Double.MAX_VALUE;
          } 
          Error.Rf_warning(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("-Inf replaced by maximally negative value\000".getBytes(), 0)), new Object[0]);
          return -1.7976931348623157E308D;
        } 
        break;
    } 
    Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("invalid function value in 'zeroin'\000".getBytes(), 0)), new Object[0]);
    return d;
  }
  
  public static Ptr fixparam(SEXP paramSEXP, Ptr paramPtr) {
    // Byte code:
    //   0: iconst_0
    //   1: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   4: pop
    //   5: aload_0
    //   6: invokestatic Rf_isNumeric : (Lorg/renjin/sexp/SEXP;)Z
    //   9: ifeq -> 15
    //   12: goto -> 55
    //   15: new org/renjin/gcc/runtime/BytePtr
    //   18: dup
    //   19: ldc 'stats '
    //   21: invokevirtual getBytes : ()[B
    //   24: iconst_0
    //   25: invokespecial <init> : ([BI)V
    //   28: new org/renjin/gcc/runtime/BytePtr
    //   31: dup
    //   32: ldc_w 'numeric parameter expected '
    //   35: invokevirtual getBytes : ()[B
    //   38: iconst_0
    //   39: invokespecial <init> : ([BI)V
    //   42: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
    //   45: checkcast org/renjin/gcc/runtime/BytePtr
    //   48: iconst_0
    //   49: anewarray java/lang/Object
    //   52: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
    //   55: aload_1
    //   56: invokeinterface getInt : ()I
    //   61: ifne -> 67
    //   64: goto -> 123
    //   67: aload_0
    //   68: invokestatic LENGTH : (Lorg/renjin/sexp/SEXP;)I
    //   71: aload_1
    //   72: invokeinterface getInt : ()I
    //   77: if_icmpne -> 83
    //   80: goto -> 183
    //   83: new org/renjin/gcc/runtime/BytePtr
    //   86: dup
    //   87: ldc 'stats '
    //   89: invokevirtual getBytes : ()[B
    //   92: iconst_0
    //   93: invokespecial <init> : ([BI)V
    //   96: new org/renjin/gcc/runtime/BytePtr
    //   99: dup
    //   100: ldc_w 'conflicting parameter lengths '
    //   103: invokevirtual getBytes : ()[B
    //   106: iconst_0
    //   107: invokespecial <init> : ([BI)V
    //   110: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
    //   113: checkcast org/renjin/gcc/runtime/BytePtr
    //   116: iconst_0
    //   117: anewarray java/lang/Object
    //   120: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
    //   123: aload_0
    //   124: invokestatic LENGTH : (Lorg/renjin/sexp/SEXP;)I
    //   127: ifle -> 133
    //   130: goto -> 173
    //   133: new org/renjin/gcc/runtime/BytePtr
    //   136: dup
    //   137: ldc 'stats '
    //   139: invokevirtual getBytes : ()[B
    //   142: iconst_0
    //   143: invokespecial <init> : ([BI)V
    //   146: new org/renjin/gcc/runtime/BytePtr
    //   149: dup
    //   150: ldc_w 'invalid parameter length '
    //   153: invokevirtual getBytes : ()[B
    //   156: iconst_0
    //   157: invokespecial <init> : ([BI)V
    //   160: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
    //   163: checkcast org/renjin/gcc/runtime/BytePtr
    //   166: iconst_0
    //   167: anewarray java/lang/Object
    //   170: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
    //   173: aload_1
    //   174: aload_0
    //   175: invokestatic LENGTH : (Lorg/renjin/sexp/SEXP;)I
    //   178: invokeinterface setInt : (I)V
    //   183: aload_1
    //   184: invokeinterface getInt : ()I
    //   189: bipush #8
    //   191: imul
    //   192: invokestatic malloc : (I)Lorg/renjin/gcc/runtime/DoublePtr;
    //   195: astore_2
    //   196: aload_0
    //   197: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
    //   200: lookupswitch default -> 459, 10 -> 236, 13 -> 236, 14 -> 347
    //   236: iconst_0
    //   237: istore_3
    //   238: goto -> 334
    //   241: aload_0
    //   242: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
    //   245: iconst_0
    //   246: iload_3
    //   247: iconst_4
    //   248: imul
    //   249: iadd
    //   250: invokeinterface getInt : (I)I
    //   255: getstatic org/renjin/gnur/api/Arith.R_NaInt : I
    //   258: if_icmpeq -> 264
    //   261: goto -> 304
    //   264: new org/renjin/gcc/runtime/BytePtr
    //   267: dup
    //   268: ldc 'stats '
    //   270: invokevirtual getBytes : ()[B
    //   273: iconst_0
    //   274: invokespecial <init> : ([BI)V
    //   277: new org/renjin/gcc/runtime/BytePtr
    //   280: dup
    //   281: ldc_w 'missing value in parameter '
    //   284: invokevirtual getBytes : ()[B
    //   287: iconst_0
    //   288: invokespecial <init> : ([BI)V
    //   291: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
    //   294: checkcast org/renjin/gcc/runtime/BytePtr
    //   297: iconst_0
    //   298: anewarray java/lang/Object
    //   301: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
    //   304: aload_2
    //   305: iconst_0
    //   306: iload_3
    //   307: bipush #8
    //   309: imul
    //   310: iadd
    //   311: aload_0
    //   312: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
    //   315: iconst_0
    //   316: iload_3
    //   317: iconst_4
    //   318: imul
    //   319: iadd
    //   320: invokeinterface getInt : (I)I
    //   325: i2d
    //   326: invokeinterface setDouble : (ID)V
    //   331: iinc #3, 1
    //   334: aload_1
    //   335: invokeinterface getInt : ()I
    //   340: iload_3
    //   341: if_icmpgt -> 241
    //   344: goto -> 499
    //   347: iconst_0
    //   348: istore_3
    //   349: goto -> 446
    //   352: aload_0
    //   353: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
    //   356: iconst_0
    //   357: iload_3
    //   358: bipush #8
    //   360: imul
    //   361: iadd
    //   362: invokeinterface getDouble : (I)D
    //   367: invokestatic R_finite : (D)I
    //   370: ifeq -> 376
    //   373: goto -> 416
    //   376: new org/renjin/gcc/runtime/BytePtr
    //   379: dup
    //   380: ldc 'stats '
    //   382: invokevirtual getBytes : ()[B
    //   385: iconst_0
    //   386: invokespecial <init> : ([BI)V
    //   389: new org/renjin/gcc/runtime/BytePtr
    //   392: dup
    //   393: ldc_w 'missing value in parameter '
    //   396: invokevirtual getBytes : ()[B
    //   399: iconst_0
    //   400: invokespecial <init> : ([BI)V
    //   403: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
    //   406: checkcast org/renjin/gcc/runtime/BytePtr
    //   409: iconst_0
    //   410: anewarray java/lang/Object
    //   413: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
    //   416: aload_2
    //   417: iconst_0
    //   418: iload_3
    //   419: bipush #8
    //   421: imul
    //   422: iadd
    //   423: aload_0
    //   424: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
    //   427: iconst_0
    //   428: iload_3
    //   429: bipush #8
    //   431: imul
    //   432: iadd
    //   433: invokeinterface getDouble : (I)D
    //   438: invokeinterface setDouble : (ID)V
    //   443: iinc #3, 1
    //   446: aload_1
    //   447: invokeinterface getInt : ()I
    //   452: iload_3
    //   453: if_icmpgt -> 352
    //   456: goto -> 499
    //   459: new org/renjin/gcc/runtime/BytePtr
    //   462: dup
    //   463: ldc 'stats '
    //   465: invokevirtual getBytes : ()[B
    //   468: iconst_0
    //   469: invokespecial <init> : ([BI)V
    //   472: new org/renjin/gcc/runtime/BytePtr
    //   475: dup
    //   476: ldc_w 'invalid parameter type '
    //   479: invokevirtual getBytes : ()[B
    //   482: iconst_0
    //   483: invokespecial <init> : ([BI)V
    //   486: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
    //   489: checkcast org/renjin/gcc/runtime/BytePtr
    //   492: iconst_0
    //   493: anewarray java/lang/Object
    //   496: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
    //   499: aload_2
    //   500: iconst_0
    //   501: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   506: areturn
  }
  
  public static SEXP nlm(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4) {
    int[] arrayOfInt1 = new int[1];
    int[] arrayOfInt2 = new int[1];
    BytePtr.of(0);
    (new int[1])[0] = 0;
    arrayOfInt1[0] = 0;
    arrayOfInt2[0] = 0;
    (new int[1])[0] = 0;
    BytePtr.of(0);
    (new double[1])[0] = 0.0D;
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    SEXP sEXP2 = (SEXP)BytePtr.of(0).getArray();
    sEXP2 = (SEXP)BytePtr.of(0).getArray();
    sEXP2 = (SEXP)BytePtr.of(0).getArray();
    sEXP2 = (SEXP)BytePtr.of(0).getArray();
    sEXP2 = (SEXP)BytePtr.of(0).getArray();
    sEXP2 = Rinternals.CDR(paramSEXP3);
    Defn.Rf_PrintDefaults();
    MixedPtr mixedPtr = MixedPtr.malloc(28);
    SEXP sEXP3 = Rinternals.CAR(sEXP2);
    if (!Rinternals.Rf_isFunction(sEXP3))
      Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("attempt to minimize non-function\000".getBytes(), 0)), new Object[0]); 
    mixedPtr.setPointer(0, (Ptr)new RecordUnitPtr(Rinternals.Rf_lang2(sEXP3, Rinternals.R_NilValue)));
    Rinternals.Rf_protect((SEXP)mixedPtr.getPointer(0).getArray());
    arrayOfInt1[0] = 0;
    Ptr ptr = fixparam(Rinternals.CAR(Rinternals.CDR(sEXP2)), (Ptr)new IntPtr(arrayOfInt1, 0));
    sEXP3 = Rinternals.CDR(Rinternals.CDR(sEXP2));
    if (Rinternals.Rf_asLogical(Rinternals.CAR(sEXP3)) != Arith.R_NaInt);
    fixparam(Rinternals.CAR(Rinternals.CDR(sEXP3)), (Ptr)new IntPtr(arrayOfInt1, 0));
    sEXP3 = Rinternals.CDR(Rinternals.CDR(sEXP3));
    if (Arith.R_IsNA(Rinternals.Rf_asReal(Rinternals.CAR(sEXP3))) != 0)
      Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("invalid NA value in parameter\000".getBytes(), 0)), new Object[0]); 
    sEXP3 = Rinternals.CDR(sEXP3);
    arrayOfInt2[0] = Rinternals.Rf_asInteger(Rinternals.CAR(sEXP3));
    int k = arrayOfInt2[0];
    if (arrayOfInt2[0] == Arith.R_NaInt)
      Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("invalid NA value in parameter\000".getBytes(), 0)), new Object[0]); 
    sEXP3 = Rinternals.CDR(sEXP3);
    if (Rinternals.Rf_asInteger(Rinternals.CAR(sEXP3)) == Arith.R_NaInt)
      Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("invalid NA value in parameter\000".getBytes(), 0)), new Object[0]); 
    sEXP3 = Rinternals.CDR(sEXP3);
    if (Arith.R_IsNA(Rinternals.Rf_asReal(Rinternals.CAR(sEXP3))) != 0)
      Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("invalid NA value in parameter\000".getBytes(), 0)), new Object[0]); 
    sEXP3 = Rinternals.CDR(sEXP3);
    if (Arith.R_IsNA(Rinternals.Rf_asReal(Rinternals.CAR(sEXP3))) != 0)
      Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("invalid NA value in parameter\000".getBytes(), 0)), new Object[0]); 
    sEXP3 = Rinternals.CDR(sEXP3);
    if (Arith.R_IsNA(Rinternals.Rf_asReal(Rinternals.CAR(sEXP3))) != 0)
      Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("invalid NA value in parameter\000".getBytes(), 0)), new Object[0]); 
    if (Rinternals.Rf_asInteger(Rinternals.CAR(Rinternals.CDR(sEXP3))) == Arith.R_NaInt)
      Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("invalid NA value in parameter\000".getBytes(), 0)), new Object[0]); 
    mixedPtr.setPointer(4, (Ptr)new RecordUnitPtr(paramSEXP4));
    boolean bool1 = false;
    boolean bool2 = false;
    mixedPtr.setInt(8, 0);
    mixedPtr.setInt(12, 0);
    SEXP sEXP5 = Rinternals.Rf_install(new BytePtr("gradient\000".getBytes(), 0));
    SEXP sEXP4 = Rinternals.Rf_install(new BytePtr("hessian\000".getBytes(), 0));
    SEXP sEXP6 = Rinternals.Rf_allocVector(14, arrayOfInt1[0]);
    for (byte b = 0; b < arrayOfInt1[0]; b++)
      Rinternals2.REAL(sEXP6).setDouble(0 + b * 8, ptr.getDouble(0 + b * 8)); 
    Rinternals.SETCADR((SEXP)mixedPtr.getPointer(0).getArray(), sEXP6);
    SEXP sEXP1 = (SEXP)mixedPtr.getPointer(4).getArray();
    sEXP1 = Rinternals.Rf_eval((SEXP)mixedPtr.getPointer(0).getArray(), sEXP1);
    Rinternals.Rf_protect(sEXP1);
    sEXP5 = Rinternals.Rf_getAttrib(sEXP1, sEXP5);
    if (sEXP5 != Rinternals.R_NilValue)
      if (Rinternals.LENGTH(sEXP5) != arrayOfInt1[0] || (Rinternals.TYPEOF(sEXP5) != 14 && !Rinternals.Rf_isInteger(sEXP5))) {
        Error.Rf_warning(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("gradient supplied is of the wrong length or mode, so ignored\000".getBytes(), 0)), new Object[0]);
      } else {
        bool1 = true;
        mixedPtr.setInt(8, 1);
        sEXP1 = Rinternals.Rf_getAttrib(sEXP1, sEXP4);
        if (sEXP1 != Rinternals.R_NilValue)
          if (Rinternals.LENGTH(sEXP1) != arrayOfInt1[0] * arrayOfInt1[0] || (Rinternals.TYPEOF(sEXP1) != 14 && !Rinternals.Rf_isInteger(sEXP1))) {
            Error.Rf_warning(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("hessian supplied is of the wrong length or mode, so ignored\000".getBytes(), 0)), new Object[0]);
          } else {
            bool2 = true;
            mixedPtr.setInt(12, 1);
          }  
      }  
    if ((arrayOfInt2[0] / 4 & 0x1) != 0 && !bool2)
      arrayOfInt2[0] = arrayOfInt2[0] + -4; 
    if ((arrayOfInt2[0] / 2 & 0x1) != 0 && !bool1)
      arrayOfInt2[0] = arrayOfInt2[0] + -2; 
    FT_init(arrayOfInt1[0], 5, mixedPtr.pointerPlus(0));
    if (bool2);
    DoublePtr.malloc(arrayOfInt1[0] * 8);
    DoublePtr.malloc(arrayOfInt1[0] * 8);
    DoublePtr.malloc(arrayOfInt1[0] * arrayOfInt1[0] * 8);
    DoublePtr.malloc(arrayOfInt1[0] * 64);
    int j = arrayOfInt1[0];
    int i = arrayOfInt1[0];
    throw new UnsatisfiedLinkException("optif9");
  }
  
  public static void optcode(int paramInt) {
    switch (paramInt) {
      case 1:
        Print.Rprintf(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("Relative gradient close to zero.\n\000".getBytes(), 0)), new Object[0]);
        Print.Rprintf(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("Current iterate is probably solution.\n\000".getBytes(), 0)), new Object[0]);
        break;
      case 2:
        Print.Rprintf(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("Successive iterates within tolerance.\n\000".getBytes(), 0)), new Object[0]);
        Print.Rprintf(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("Current iterate is probably solution.\n\000".getBytes(), 0)), new Object[0]);
        break;
      case 3:
        Print.Rprintf(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("Last global step failed to locate a point lower than x.\n\000".getBytes(), 0)), new Object[0]);
        Print.Rprintf(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("Either x is an approximate local minimum of the function,\nthe function is too non-linear for this algorithm,\nor steptol is too large.\n\000".getBytes(), 0)), new Object[0]);
        break;
      case 4:
        Print.Rprintf(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("Iteration limit exceeded.  Algorithm failed.\n\000".getBytes(), 0)), new Object[0]);
        break;
      case 5:
        Print.Rprintf(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("Maximum step size exceeded 5 consecutive times.\nEither the function is unbounded below,\nbecomes asymptotic to a finite value\nfrom above in some direction,\nor stepmx is too small.\n\000".getBytes(), 0)), new Object[0]);
        break;
    } 
    Print.Rprintf(new BytePtr("\n\000".getBytes(), 0), new Object[0]);
  }
  
  public static void opterror(int paramInt) {
    switch (paramInt) {
      case -1:
        Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("non-positive number of parameters in nlm\000".getBytes(), 0)), new Object[0]);
      case -2:
        Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("nlm is inefficient for 1-d problems\000".getBytes(), 0)), new Object[0]);
      case -3:
        Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("invalid gradient tolerance in nlm\000".getBytes(), 0)), new Object[0]);
      case -4:
        Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("invalid iteration limit in nlm\000".getBytes(), 0)), new Object[0]);
      case -5:
        Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("minimization function has no good digits in nlm\000".getBytes(), 0)), new Object[0]);
      case -6:
        Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("no analytic gradient to check in nlm!\000".getBytes(), 0)), new Object[0]);
      case -7:
        Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("no analytic Hessian to check in nlm!\000".getBytes(), 0)), new Object[0]);
      case -21:
        Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("probable coding error in analytic gradient\000".getBytes(), 0)), new Object[0]);
      case -22:
        Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("probable coding error in analytic Hessian\000".getBytes(), 0)), new Object[0]);
        break;
    } 
    Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("*** unknown error message (msg = %d) in nlm()\n*** should not happen!\000".getBytes(), 0)), new Object[] { Integer.valueOf(paramInt) });
  }
  
  public static SEXP zeroin2(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4) {
    MixedPtr mixedPtr = MixedPtr.malloc(8);
    int[] arrayOfInt = new int[1];
    double[] arrayOfDouble = new double[1];
    SEXP sEXP = Rinternals.CDR(paramSEXP3);
    Defn.Rf_PrintDefaults();
    paramSEXP3 = Rinternals.CAR(sEXP);
    if (!Rinternals.Rf_isFunction(paramSEXP3))
      Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("attempt to minimize non-function\000".getBytes(), 0)), new Object[0]); 
    sEXP = Rinternals.CDR(sEXP);
    double d2 = Rinternals.Rf_asReal(Rinternals.CAR(sEXP));
    if (Arith.R_finite(d2) == 0)
      Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("invalid '%s' value\000".getBytes(), 0)), new Object[] { new BytePtr("xmin\000".getBytes(), 0) }); 
    sEXP = Rinternals.CDR(sEXP);
    double d1 = Rinternals.Rf_asReal(Rinternals.CAR(sEXP));
    if (Arith.R_finite(d1) == 0)
      Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("invalid '%s' value\000".getBytes(), 0)), new Object[] { new BytePtr("xmax\000".getBytes(), 0) }); 
    if (d2 >= d1)
      Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("'xmin' not less than 'xmax'\000".getBytes(), 0)), new Object[0]); 
    sEXP = Rinternals.CDR(sEXP);
    if (Arith.R_IsNA(Rinternals.Rf_asReal(Rinternals.CAR(sEXP))) != 0)
      Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("NA value for '%s' is not allowed\000".getBytes(), 0)), new Object[] { new BytePtr("f.lower\000".getBytes(), 0) }); 
    sEXP = Rinternals.CDR(sEXP);
    if (Arith.R_IsNA(Rinternals.Rf_asReal(Rinternals.CAR(sEXP))) != 0)
      Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("NA value for '%s' is not allowed\000".getBytes(), 0)), new Object[] { new BytePtr("f.upper\000".getBytes(), 0) }); 
    sEXP = Rinternals.CDR(sEXP);
    arrayOfDouble[0] = Rinternals.Rf_asReal(Rinternals.CAR(sEXP));
    if (Arith.R_finite(arrayOfDouble[0]) == 0 || arrayOfDouble[0] <= 0.0D)
      Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("invalid '%s' value\000".getBytes(), 0)), new Object[] { new BytePtr("tol\000".getBytes(), 0) }); 
    arrayOfInt[0] = Rinternals.Rf_asInteger(Rinternals.CAR(Rinternals.CDR(sEXP)));
    if (arrayOfInt[0] <= 0)
      Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("'maxiter' must be positive\000".getBytes(), 0)), new Object[0]); 
    mixedPtr.setAlignedPointer(1, (Ptr)new RecordUnitPtr(paramSEXP4));
    mixedPtr.setPointer((Ptr)new RecordUnitPtr(Rinternals.Rf_lang2(paramSEXP3, Rinternals.R_NilValue)));
    Rinternals.Rf_protect((SEXP)mixedPtr.getPointer().getArray());
    Rinternals.Rf_protect(Rinternals.Rf_allocVector(14, 3));
    Rinternals2.REAL(Rinternals.Rf_allocVector(14, 3));
    throw new UnsatisfiedLinkException("R_zeroin2");
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/stats-0.9.2724.jar!/org/renjin/stats/optimize__.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */