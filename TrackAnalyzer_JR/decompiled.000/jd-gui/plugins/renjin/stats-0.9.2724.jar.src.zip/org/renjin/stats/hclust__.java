package org.renjin.stats;

import org.renjin.gcc.runtime.IntPtr;
import org.renjin.gcc.runtime.Ptr;

public class hclust__ {
  public static double inf$1859 = 1.0E300D;
  
  public static double $hclust_$inf = 1.0E300D;
  
  public static void hcass2_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6) {
    Integer.toUnsignedLong(Math.max(paramPtr1.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr1.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr1.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr1.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr1.getInt(), 0));
    int m = paramPtr1.getInt();
    int n = 1;
    if (1 <= m)
      while (true) {
        boolean bool;
        paramPtr5.setAlignedInt(n + -1, paramPtr2.getAlignedInt(n + -1));
        paramPtr6.setAlignedInt(n + -1, paramPtr3.getAlignedInt(n + -1));
        if (n != m) {
          bool = false;
        } else {
          bool = true;
        } 
        n++;
        if (!bool)
          continue; 
        break;
      }  
    m = paramPtr1.getInt() + -2;
    n = 1;
    if (1 <= m)
      while (true) {
        int i2 = paramPtr2.getAlignedInt(n + -1);
        int i1 = paramPtr3.getAlignedInt(n + -1);
        if (i1 < i2)
          i2 = i1; 
        i1 = i2;
        i2 = paramPtr1.getInt() + -1;
        int i3;
        if ((i3 = n + 1) <= i2)
          while (true) {
            boolean bool;
            if (paramPtr2.getAlignedInt(i3 + -1) == i1)
              paramPtr5.setAlignedInt(i3 + -1, -n); 
            if (paramPtr3.getAlignedInt(i3 + -1) == i1)
              paramPtr6.setAlignedInt(i3 + -1, -n); 
            if (i3 != i2) {
              bool = false;
            } else {
              bool = true;
            } 
            i3++;
            if (!bool)
              continue; 
            break;
          }  
        if (n != m) {
          i1 = 0;
        } else {
          i1 = 1;
        } 
        n++;
        if (i1 == 0)
          continue; 
        break;
      }  
    int j = paramPtr1.getInt() + -1;
    int k = 1;
    if (1 <= j)
      while (true) {
        paramPtr5.setAlignedInt(k + -1, -paramPtr5.getAlignedInt(k + -1));
        paramPtr6.setAlignedInt(k + -1, -paramPtr6.getAlignedInt(k + -1));
        if (k != j) {
          m = 0;
        } else {
          m = 1;
        } 
        k++;
        if (m == 0)
          continue; 
        break;
      }  
    j = paramPtr1.getInt() + -1;
    k = 1;
    if (1 <= j)
      while (true) {
        if (paramPtr5.getAlignedInt(k + -1) > 0 && paramPtr6.getAlignedInt(k + -1) < 0) {
          m = paramPtr5.getAlignedInt(k + -1);
          paramPtr5.setAlignedInt(k + -1, paramPtr6.getAlignedInt(k + -1));
          paramPtr6.setAlignedInt(k + -1, m);
        } 
        if (paramPtr5.getAlignedInt(k + -1) > 0 && paramPtr6.getAlignedInt(k + -1) > 0) {
          n = paramPtr5.getAlignedInt(k + -1);
          m = paramPtr6.getAlignedInt(k + -1);
          if (m < n)
            n = m; 
          n = n;
          int i1 = paramPtr5.getAlignedInt(k + -1);
          m = paramPtr6.getAlignedInt(k + -1);
          if (m > i1)
            i1 = m; 
          paramPtr5.setAlignedInt(k + -1, n);
          paramPtr6.setAlignedInt(k + -1, i1);
        } 
        if (k != j) {
          m = 0;
        } else {
          m = 1;
        } 
        k++;
        if (m == 0)
          continue; 
        break;
      }  
    paramPtr4.setInt(paramPtr5.getAlignedInt(paramPtr1.getInt() + -2));
    paramPtr4.setAlignedInt(1, paramPtr6.getAlignedInt(paramPtr1.getInt() + -2));
    j = 2;
    k = paramPtr1.getInt() + -2;
    if (k > 0)
      while (true) {
        n = j;
        m = 1;
        if (1 <= j)
          while (true) {
            if (paramPtr4.getAlignedInt(m + -1) != k) {
              boolean bool;
              if (m != n) {
                bool = false;
              } else {
                bool = true;
              } 
              m++;
              if (!bool)
                continue; 
              break;
            } 
            paramPtr4.setAlignedInt(m + -1, paramPtr5.getAlignedInt(k + -1));
            if (m != j) {
              j++;
              n = m + 2;
              int i1 = j;
              if (j >= n)
                while (true) {
                  boolean bool;
                  paramPtr4.setAlignedInt(i1 + -1, paramPtr4.getAlignedInt(i1 + -2));
                  if (i1 != n) {
                    bool = false;
                  } else {
                    bool = true;
                  } 
                  i1--;
                  if (!bool)
                    continue; 
                  break;
                }  
              paramPtr4.setAlignedInt(m, paramPtr6.getAlignedInt(k + -1));
              break;
            } 
            paramPtr4.setAlignedInt(++j + -1, paramPtr6.getAlignedInt(k + -1));
            break;
          }  
        if (k != 1) {
          m = 0;
        } else {
          m = 1;
        } 
        k--;
        if (m == 0)
          continue; 
        break;
      }  
    int i = paramPtr1.getInt();
    j = 1;
    if (1 <= i)
      while (true) {
        paramPtr4.setAlignedInt(j + -1, -paramPtr4.getAlignedInt(j + -1));
        if (j != i) {
          k = 0;
        } else {
          k = 1;
        } 
        j++;
        if (k == 0)
          continue; 
        break;
      }  
  }
  
  public static void hclust_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, Ptr paramPtr11) {
    int[] arrayOfInt1 = new int[1];
    int[] arrayOfInt2 = new int[1];
    int[] arrayOfInt3 = new int[1];
    int[] arrayOfInt4 = new int[1];
    int[] arrayOfInt5 = new int[1];
    arrayOfInt2[0] = 0;
    arrayOfInt4[0] = 0;
    arrayOfInt5[0] = 0;
    Integer.toUnsignedLong(Math.max(paramPtr1.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr2.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr1.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr1.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr1.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr1.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr1.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr1.getInt(), 0));
    int i = 0;
    int j = 0;
    int k = 0;
    int m = paramPtr1.getInt();
    arrayOfInt5[0] = 1;
    if (arrayOfInt5[0] <= m)
      while (true) {
        boolean bool;
        paramPtr10.setBoolean(arrayOfInt5[0] + -1, true);
        if (arrayOfInt5[0] != m) {
          bool = false;
        } else {
          bool = true;
        } 
        arrayOfInt5[0] = arrayOfInt5[0] + 1;
        if (!bool)
          continue; 
        break;
      }  
    m = paramPtr1.getInt();
    int n = paramPtr1.getInt() + -1;
    arrayOfInt5[0] = 1;
    if (arrayOfInt5[0] <= n)
      while (true) {
        double d = $hclust_$inf;
        int i1 = paramPtr1.getInt();
        arrayOfInt3[0] = arrayOfInt5[0] + 1;
        if (arrayOfInt3[0] <= i1)
          while (true) {
            int i2 = ioffst_(paramPtr1, (Ptr)new IntPtr(arrayOfInt5, 0), (Ptr)new IntPtr(arrayOfInt3, 0));
            if (paramPtr11.getAlignedDouble(i2 + -1) < d) {
              d = paramPtr11.getAlignedDouble(i2 + -1);
              k = arrayOfInt3[0];
            } 
            if (arrayOfInt3[0] != i1) {
              i2 = 0;
            } else {
              i2 = 1;
            } 
            arrayOfInt3[0] = arrayOfInt3[0] + 1;
            if (i2 == 0)
              continue; 
            break;
          }  
        paramPtr8.setAlignedInt(arrayOfInt5[0] + -1, k);
        paramPtr9.setAlignedDouble(arrayOfInt5[0] + -1, d);
        if (arrayOfInt5[0] != n) {
          i1 = 0;
        } else {
          i1 = 1;
        } 
        arrayOfInt5[0] = arrayOfInt5[0] + 1;
        if (i1 == 0)
          continue; 
        break;
      }  
    do {
      double d = $hclust_$inf;
      n = paramPtr1.getInt() + -1;
      arrayOfInt5[0] = 1;
      if (arrayOfInt5[0] <= n)
        while (true) {
          boolean bool;
          if (paramPtr10.getBoolean(arrayOfInt5[0] + -1) && paramPtr9.getAlignedDouble(arrayOfInt5[0] + -1) < d) {
            d = paramPtr9.getAlignedDouble(arrayOfInt5[0] + -1);
            i = arrayOfInt5[0];
            k = paramPtr8.getAlignedInt(arrayOfInt5[0] + -1);
          } 
          if (arrayOfInt5[0] != n) {
            bool = false;
          } else {
            bool = true;
          } 
          arrayOfInt5[0] = arrayOfInt5[0] + 1;
          if (!bool)
            continue; 
          break;
        }  
      m--;
      n = i;
      if (k < i)
        n = k; 
      arrayOfInt4[0] = n;
      n = i;
      if (k > i)
        n = k; 
      arrayOfInt2[0] = n;
      paramPtr4.setAlignedInt(paramPtr1.getInt() - m + -1, arrayOfInt4[0]);
      paramPtr5.setAlignedInt(paramPtr1.getInt() - m + -1, arrayOfInt2[0]);
      paramPtr6.setAlignedDouble(paramPtr1.getInt() - m + -1, d);
      paramPtr10.setBoolean(arrayOfInt2[0] + -1, false);
      d = $hclust_$inf;
      n = paramPtr1.getInt();
      arrayOfInt1[0] = 1;
      if (arrayOfInt1[0] <= n)
        while (true) {
          boolean bool;
          if (paramPtr10.getBoolean(arrayOfInt1[0] + -1) && arrayOfInt1[0] != arrayOfInt4[0]) {
            int i1;
            if (arrayOfInt4[0] >= arrayOfInt1[0]) {
              bool = ioffst_(paramPtr1, (Ptr)new IntPtr(arrayOfInt1, 0), (Ptr)new IntPtr(arrayOfInt4, 0));
            } else {
              bool = ioffst_(paramPtr1, (Ptr)new IntPtr(arrayOfInt4, 0), (Ptr)new IntPtr(arrayOfInt1, 0));
            } 
            if (arrayOfInt2[0] >= arrayOfInt1[0]) {
              i1 = ioffst_(paramPtr1, (Ptr)new IntPtr(arrayOfInt1, 0), (Ptr)new IntPtr(arrayOfInt2, 0));
            } else {
              i1 = ioffst_(paramPtr1, (Ptr)new IntPtr(arrayOfInt2, 0), (Ptr)new IntPtr(arrayOfInt1, 0));
            } 
            d = paramPtr11.getAlignedDouble(ioffst_(paramPtr1, (Ptr)new IntPtr(arrayOfInt4, 0), (Ptr)new IntPtr(arrayOfInt2, 0)) + -1);
            if (paramPtr3.getInt() == 1) {
              paramPtr11.setAlignedDouble(bool + -1, (paramPtr7.getAlignedDouble(arrayOfInt4[0] + -1) + paramPtr7.getAlignedDouble(arrayOfInt1[0] + -1)) * paramPtr11.getAlignedDouble(bool + -1) + (paramPtr7.getAlignedDouble(arrayOfInt2[0] + -1) + paramPtr7.getAlignedDouble(arrayOfInt1[0] + -1)) * paramPtr11.getAlignedDouble(i1 + -1) - paramPtr7.getAlignedDouble(arrayOfInt1[0] + -1) * d);
              paramPtr11.setAlignedDouble(bool + -1, paramPtr11.getAlignedDouble(bool + -1) / (paramPtr7.getAlignedDouble(arrayOfInt4[0] + -1) + paramPtr7.getAlignedDouble(arrayOfInt2[0] + -1) + paramPtr7.getAlignedDouble(arrayOfInt1[0] + -1)));
            } 
            if (paramPtr3.getInt() == 2) {
              boolean bool2;
              double d2 = paramPtr11.getAlignedDouble(bool + -1);
              double d1 = paramPtr11.getAlignedDouble(i1 + -1);
              if (d1 >= d2) {
                bool1 = false;
              } else {
                bool1 = true;
              } 
              boolean bool1 = bool1;
              if (!Double.isNaN(d2) && !Double.isNaN(d2)) {
                bool2 = false;
              } else {
                bool2 = true;
              } 
              if ((bool1 | bool2 & true) != 0)
                d2 = d1; 
              paramPtr11.setAlignedDouble(bool + -1, d2);
            } 
            if (paramPtr3.getInt() == 3) {
              boolean bool2;
              double d2 = paramPtr11.getAlignedDouble(bool + -1);
              double d1 = paramPtr11.getAlignedDouble(i1 + -1);
              if (d1 <= d2) {
                bool1 = false;
              } else {
                bool1 = true;
              } 
              boolean bool1 = bool1;
              if (!Double.isNaN(d2) && !Double.isNaN(d2)) {
                bool2 = false;
              } else {
                bool2 = true;
              } 
              if ((bool1 | bool2 & true) != 0)
                d2 = d1; 
              paramPtr11.setAlignedDouble(bool + -1, d2);
            } 
            if (paramPtr3.getInt() == 4)
              paramPtr11.setAlignedDouble(bool + -1, (paramPtr7.getAlignedDouble(arrayOfInt4[0] + -1) * paramPtr11.getAlignedDouble(bool + -1) + paramPtr7.getAlignedDouble(arrayOfInt2[0] + -1) * paramPtr11.getAlignedDouble(i1 + -1)) / (paramPtr7.getAlignedDouble(arrayOfInt4[0] + -1) + paramPtr7.getAlignedDouble(arrayOfInt2[0] + -1))); 
            if (paramPtr3.getInt() == 5)
              paramPtr11.setAlignedDouble(bool + -1, paramPtr11.getAlignedDouble(bool + -1) * 0.5D + paramPtr11.getAlignedDouble(i1 + -1) * 0.5D); 
            if (paramPtr3.getInt() == 6)
              paramPtr11.setAlignedDouble(bool + -1, paramPtr11.getAlignedDouble(bool + -1) * 0.5D + paramPtr11.getAlignedDouble(i1 + -1) * 0.5D - d * 0.25D); 
            if (paramPtr3.getInt() == 7)
              paramPtr11.setAlignedDouble(bool + -1, (paramPtr7.getAlignedDouble(arrayOfInt4[0] + -1) * paramPtr11.getAlignedDouble(bool + -1) + paramPtr7.getAlignedDouble(arrayOfInt2[0] + -1) * paramPtr11.getAlignedDouble(i1 + -1) - paramPtr7.getAlignedDouble(arrayOfInt4[0] + -1) * paramPtr7.getAlignedDouble(arrayOfInt2[0] + -1) * d / (paramPtr7.getAlignedDouble(arrayOfInt4[0] + -1) + paramPtr7.getAlignedDouble(arrayOfInt2[0] + -1))) / (paramPtr7.getAlignedDouble(arrayOfInt4[0] + -1) + paramPtr7.getAlignedDouble(arrayOfInt2[0] + -1))); 
          } 
          if (arrayOfInt1[0] != n) {
            bool = false;
          } else {
            bool = true;
          } 
          arrayOfInt1[0] = arrayOfInt1[0] + 1;
          if (!bool)
            continue; 
          break;
        }  
      paramPtr7.setAlignedDouble(arrayOfInt4[0] + -1, paramPtr7.getAlignedDouble(arrayOfInt4[0] + -1) + paramPtr7.getAlignedDouble(arrayOfInt2[0] + -1));
      n = paramPtr1.getInt() + -1;
      arrayOfInt5[0] = 1;
      if (arrayOfInt5[0] > n)
        continue; 
      while (true) {
        boolean bool;
        if (paramPtr10.getBoolean(arrayOfInt5[0] + -1)) {
          d = $hclust_$inf;
          bool = paramPtr1.getInt();
          arrayOfInt3[0] = arrayOfInt5[0] + 1;
          if (arrayOfInt3[0] <= bool)
            while (true) {
              boolean bool1;
              if (paramPtr10.getBoolean(arrayOfInt3[0] + -1)) {
                bool1 = ioffst_(paramPtr1, (Ptr)new IntPtr(arrayOfInt5, 0), (Ptr)new IntPtr(arrayOfInt3, 0));
                if (paramPtr11.getAlignedDouble(bool1 + -1) < d) {
                  d = paramPtr11.getAlignedDouble(bool1 + -1);
                  j = arrayOfInt3[0];
                } 
              } 
              if (arrayOfInt3[0] != bool) {
                bool1 = false;
              } else {
                bool1 = true;
              } 
              arrayOfInt3[0] = arrayOfInt3[0] + 1;
              if (!bool1)
                continue; 
              break;
            }  
          paramPtr8.setAlignedInt(arrayOfInt5[0] + -1, j);
          paramPtr9.setAlignedDouble(arrayOfInt5[0] + -1, d);
        } 
        if (arrayOfInt5[0] != n) {
          bool = false;
        } else {
          bool = true;
        } 
        arrayOfInt5[0] = arrayOfInt5[0] + 1;
        if (!bool)
          continue; 
        break;
      } 
    } while (m > 1);
  }
  
  public static int ioffst_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3) {
    return paramPtr3.getInt() + (paramPtr2.getInt() + -1) * paramPtr1.getInt() - paramPtr2.getInt() * (paramPtr2.getInt() + 1) / 2;
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/stats-0.9.2724.jar!/org/renjin/stats/hclust__.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */