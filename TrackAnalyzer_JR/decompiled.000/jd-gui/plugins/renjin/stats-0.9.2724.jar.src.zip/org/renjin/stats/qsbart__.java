package org.renjin.stats;

import org.renjin.gcc.runtime.IntPtr;
import org.renjin.gcc.runtime.Ptr;

public class qsbart__ {
  static {
  
  }
  
  public static void rbart_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, Ptr paramPtr11, Ptr paramPtr12, Ptr paramPtr13, Ptr paramPtr14, Ptr paramPtr15, Ptr paramPtr16, Ptr paramPtr17, Ptr paramPtr18, Ptr paramPtr19, Ptr paramPtr20) {
    int[] arrayOfInt = new int[1];
    Integer.toUnsignedLong(Math.max(paramPtr7.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr7.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr7.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr9.getInt() + 4, 0));
    Integer.toUnsignedLong(Math.max(paramPtr9.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr7.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr7.getInt(), 0));
    if (paramPtr14.getAlignedInt(3) != 1) {
      arrayOfInt[0] = 0;
    } else {
      arrayOfInt[0] = 2;
    } 
    paramPtr1 = paramPtr14.pointerPlus(4);
    paramPtr2 = paramPtr14.pointerPlus(8);
    paramPtr3 = paramPtr16.pointerPlus(8);
    paramPtr4 = paramPtr16.pointerPlus(16);
    paramPtr5 = paramPtr16.pointerPlus(24);
    paramPtr6 = paramPtr16.pointerPlus(32);
    paramPtr7 = (Ptr)new IntPtr(arrayOfInt, 0);
    paramPtr8 = paramPtr17.pointerPlus(paramPtr9.getInt() * 8);
    paramPtr9 = paramPtr17.pointerPlus(paramPtr9.getInt() * 2 * 8);
    paramPtr10 = paramPtr17.pointerPlus(paramPtr9.getInt() * 3 * 8);
    paramPtr11 = paramPtr17.pointerPlus(paramPtr9.getInt() * 4 * 8);
    paramPtr12 = paramPtr17.pointerPlus(paramPtr9.getInt() * 5 * 8);
    paramPtr13 = paramPtr17.pointerPlus(paramPtr9.getInt() * 6 * 8);
    paramPtr14 = paramPtr17.pointerPlus(paramPtr9.getInt() * 7 * 8);
    paramPtr15 = paramPtr17.pointerPlus(paramPtr9.getInt() * 8 * 8);
    Ptr ptr1 = paramPtr17.pointerPlus(paramPtr9.getInt() * 9 * 8);
    Ptr ptr2 = paramPtr17.pointerPlus((paramPtr18.getInt() + 9) * paramPtr9.getInt() * 8);
    Ptr ptr3 = paramPtr17.pointerPlus((paramPtr18.getInt() * 2 + 9) * paramPtr9.getInt() * 8);
    sbart__.sbart_(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramPtr6, paramPtr7, paramPtr8, paramPtr9, paramPtr10, paramPtr11, paramPtr12, paramPtr13, paramPtr14, paramPtr15, paramPtr1, paramPtr2, paramPtr16, paramPtr3, paramPtr4, paramPtr5, paramPtr6, paramPtr7, paramPtr17, paramPtr8, paramPtr9, paramPtr10, paramPtr11, paramPtr12, paramPtr13, paramPtr14, paramPtr15, ptr1, ptr2, ptr3, paramPtr18, paramPtr19, paramPtr20);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/stats-0.9.2724.jar!/org/renjin/stats/qsbart__.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */