package org.renjin.stats;

import org.renjin.gcc.runtime.BytePtr;
import org.renjin.gcc.runtime.DoublePtr;
import org.renjin.gcc.runtime.IntPtr;
import org.renjin.gcc.runtime.Ptr;
import org.renjin.gnur.api.Error;
import org.renjin.gnur.api.GetText;
import org.renjin.gnur.api.Print;
import org.renjin.gnur.api.Rinternals;
import org.renjin.gnur.api.Rinternals2;
import org.renjin.sexp.SEXP;

public class Srunmed__ {
  static {
  
  }
  
  public static void R_heapsort(int paramInt1, int paramInt2, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, int paramInt3) {
    int i = paramInt2 / 2 + 1;
    int j = paramInt2;
    while (i > paramInt1)
      siftup(--i, paramInt2, paramPtr1, paramPtr2, paramPtr3, paramInt3); 
    while (j > paramInt1) {
      swap(i, j, paramPtr1, paramPtr2, paramPtr3, paramInt3);
      siftup(i, --j, paramPtr1, paramPtr2, paramPtr3, paramInt3);
    } 
  }
  
  public static void Srunmed(Ptr paramPtr1, Ptr paramPtr2, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    int i;
    BytePtr.of(0);
    DoublePtr doublePtr = DoublePtr.malloc(paramInt2 * 8);
    if (paramInt2 > paramInt1)
      Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("bandwidth/span of running medians is larger than n\000".getBytes(), 0)), new Object[0]); 
    int j;
    for (j = 0; j < paramInt2; j++)
      doublePtr.setDouble(0 + j * 8, paramPtr1.getDouble(j * 8)); 
    double d2 = doublePtr.getDouble(0);
    j = 0;
    int m;
    for (m = 1; m < paramInt2; m++) {
      if (doublePtr.getDouble(0 + m * 8) < d2) {
        d2 = doublePtr.getDouble(0 + m * 8);
        j = m;
      } 
    } 
    double d1 = doublePtr.getDouble(0);
    doublePtr.setDouble(0, d2);
    doublePtr.setDouble(0 + j * 8, d1);
    for (j = 2; j < paramInt2; j++) {
      if (doublePtr.getDouble(0 + j * 8) < doublePtr.getDouble(0 + (j + -1) * 8)) {
        d2 = doublePtr.getDouble(0 + j * 8);
        m = j;
        while (true) {
          doublePtr.setDouble(0 + m * 8, doublePtr.getDouble(0 + (m + -1) * 8));
          if (doublePtr.getDouble(0 + (--m + -1) * 8) <= d2) {
            doublePtr.setDouble(0 + m * 8, d2);
            break;
          } 
        } 
      } 
    } 
    j = paramInt2 / 2;
    d2 = doublePtr.getDouble(0 + j * 8);
    if (paramInt3 != 0) {
      for (byte b = 0; b < j; b++)
        paramPtr2.setDouble(b * 8, d2); 
    } else {
      for (byte b = 0; b < j; b++)
        paramPtr2.setDouble(b * 8, paramPtr1.getDouble(b * 8)); 
    } 
    paramPtr2.setDouble(j * 8, d2);
    int k = j + 1;
    if (paramInt4 != 0) {
      Object[] arrayOfObject = new Object[2];
      arrayOfObject[0] = Integer.valueOf(paramInt2);
      arrayOfObject[1] = Integer.valueOf(k);
      Print.REprintf(new BytePtr("(bw,b2)= (%d,%d)\n\000".getBytes(), 0), arrayOfObject);
    } 
    j = 1;
    paramInt2 = paramInt2;
    for (m = k; paramInt2 < paramInt1; m++) {
      d1 = paramPtr1.getDouble(paramInt2 * 8);
      double d3 = paramPtr1.getDouble((j + -1) * 8);
      if (paramInt4 != 0) {
        Object[] arrayOfObject = new Object[3];
        arrayOfObject[0] = Integer.valueOf(m);
        arrayOfObject[1] = Double.valueOf(d1);
        arrayOfObject[2] = Double.valueOf(d3);
        Print.REprintf(new BytePtr(" is=%d, y(in/out)= %10g, %10g\000".getBytes(), 0), arrayOfObject);
      } 
      double d4 = d2;
      if (d1 >= d2) {
        if (d1 != d2 && d3 <= d2) {
          byte b = 0;
          if (d3 >= d2) {
            if (paramInt4 != 0)
              Print.REprintf(new BytePtr(": yout == rmed < yin \000".getBytes(), 0), new Object[0]); 
            d4 = d1;
            d1 = d1;
            for (int n = j; n <= paramInt2; n++) {
              d3 = paramPtr1.getDouble(n * 8);
              if (d3 >= d2)
                if (d3 <= d2) {
                  d1 = d3;
                } else {
                  b++;
                  if (d3 < d4)
                    d4 = d3; 
                  if (d3 < d1)
                    d1 = d3; 
                }  
            } 
            if (b != k) {
              d1 = d1;
            } else {
              d1 = d4;
            } 
            d4 = d1;
            if (paramInt4 != 0)
              Print.REprintf(new BytePtr("k+ : %d,\000".getBytes(), 0), new Object[] { Integer.valueOf(b) }); 
          } else {
            if (paramInt4 != 0)
              Print.REprintf(new BytePtr(": yout < rmed < yin \000".getBytes(), 0), new Object[0]); 
            d4 = d1;
            for (int n = j; n <= paramInt2; n++) {
              d1 = paramPtr1.getDouble(n * 8);
              if (d1 > d2) {
                b++;
                if (d1 < d4)
                  d4 = d1; 
              } 
            } 
            if (b < k)
              d4 = d2; 
          } 
        } 
      } else if (d3 >= d2) {
        byte b = 0;
        if (d3 <= d2) {
          if (paramInt4 != 0)
            Print.REprintf(new BytePtr(": yin < rmed == yout \000".getBytes(), 0), new Object[0]); 
          d4 = d1;
          d1 = d1;
          for (int n = j; n <= paramInt2; n++) {
            d3 = paramPtr1.getDouble(n * 8);
            if (d3 <= d2)
              if (d3 >= d2) {
                d1 = d3;
              } else {
                b++;
                if (d3 > d4)
                  d4 = d3; 
                if (d3 > d1)
                  d1 = d3; 
              }  
          } 
          if (b != k) {
            d1 = d1;
          } else {
            d1 = d4;
          } 
          d4 = d1;
          if (paramInt4 != 0)
            Print.REprintf(new BytePtr("k- : %d,\000".getBytes(), 0), new Object[] { Integer.valueOf(b) }); 
        } else {
          if (paramInt4 != 0)
            Print.REprintf(new BytePtr(": yin < rmed < yout \000".getBytes(), 0), new Object[0]); 
          d4 = d1;
          for (int n = j; n <= paramInt2; n++) {
            d1 = paramPtr1.getDouble(n * 8);
            if (d1 < d2) {
              b++;
              if (d1 > d4)
                d4 = d1; 
            } 
          } 
          if (b < k)
            d4 = d2; 
        } 
      } 
      if (paramInt4 != 0) {
        Object[] arrayOfObject = new Object[2];
        arrayOfObject[0] = Double.valueOf(d2);
        arrayOfObject[1] = Double.valueOf(d4);
        Print.REprintf(new BytePtr("=> %12g, %12g\n\000".getBytes(), 0), arrayOfObject);
      } 
      d2 = d4;
      paramPtr2.setDouble(m * 8, d4);
      j++;
      paramInt2++;
    } 
    if (paramInt3 != 0) {
      for (i = m; i < paramInt1; i++)
        paramPtr2.setDouble(i * 8, d2); 
      return;
    } 
    for (paramInt2 = m; paramInt2 < paramInt1; paramInt2++)
      paramPtr2.setDouble(paramInt2 * 8, i.getDouble(paramInt2 * 8)); 
  }
  
  public static void Trunmed(int paramInt1, int paramInt2, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, int paramInt3, int paramInt4) {
    int i = (paramInt2 + -1) / 2;
    inittree(paramInt1, paramInt2, i, paramPtr1, paramPtr5, paramPtr3, paramPtr4, paramInt4);
    if (paramInt4 != 0) {
      Print.Rprintf(new BytePtr("After inittree():\n\000".getBytes(), 0), new Object[0]);
      Print.Rprintf(new BytePtr(" %9s: \000".getBytes(), 0), new Object[] { new BytePtr("j\000".getBytes(), 0) });
      byte b1;
      for (b1 = 0; paramInt2 * 2 >= b1; b1++) {
        Print.Rprintf(new BytePtr("%6d\000".getBytes(), 0), new Object[] { Integer.valueOf(b1) });
      } 
      Print.Rprintf(new BytePtr("\n\000".getBytes(), 0), new Object[0]);
      Print.Rprintf(new BytePtr(" %9s: \000".getBytes(), 0), new Object[] { new BytePtr("window []\000".getBytes(), 0) });
      byte b2;
      for (b2 = 0; paramInt2 * 2 >= b2; b2++) {
        Object[] arrayOfObject = new Object[1];
        BytePtr bytePtr = new BytePtr();
        this("%6g\000".getBytes(), 0);
        arrayOfObject[0] = Double.valueOf(paramPtr5.getDouble(b2 * 8));
        Print.Rprintf(bytePtr, arrayOfObject);
      } 
      Print.Rprintf(new BytePtr("\n\000".getBytes(), 0), new Object[0]);
      Print.Rprintf(new BytePtr(" %9s: \000".getBytes(), 0), new Object[] { new BytePtr(" nrlist[]\000".getBytes(), 0) });
      for (b2 = 0; paramInt2 * 2 >= b2; b2++) {
        Object[] arrayOfObject = new Object[1];
        BytePtr bytePtr = new BytePtr();
        this("%6d\000".getBytes(), 0);
        arrayOfObject[0] = Integer.valueOf(paramPtr4.getInt(b2 * 4));
        Print.Rprintf(bytePtr, arrayOfObject);
      } 
      Print.Rprintf(new BytePtr("\n\000".getBytes(), 0), new Object[0]);
      Print.Rprintf(new BytePtr(" %9s: \000".getBytes(), 0), new Object[] { new BytePtr("outlist[]\000".getBytes(), 0) });
      for (b1 = 0; paramInt2 * 2 >= b1; b1++) {
        int j;
        if (b1 <= i || paramInt2 + i < b1) {
          j = -9;
        } else {
          j = paramPtr3.getInt((b1 - i) * 4);
        } 
        Print.Rprintf(new BytePtr("%6d\000".getBytes(), 0), new Object[] { Integer.valueOf(j) });
      } 
      Print.Rprintf(new BytePtr("\n\000".getBytes(), 0), new Object[0]);
    } 
    runmedint(paramInt1, paramInt2, i, paramPtr1, paramPtr2, paramPtr5, paramPtr3, paramPtr4, paramInt3, paramInt4);
  }
  
  public static void downoutdownin(int paramInt1, int paramInt2, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, int paramInt3) {
    if (paramInt3 > 1) {
      Object[] arrayOfObject = new Object[2];
      arrayOfObject[0] = Integer.valueOf(paramInt1);
      arrayOfObject[1] = Integer.valueOf(paramInt2);
      Print.Rprintf(new BytePtr("\nDownoutDOWNin(%d, %d)\n  \000".getBytes(), 0), arrayOfObject);
    } 
    downtoleave(paramInt1, paramInt2, paramPtr1, paramPtr2, paramPtr3, paramInt3);
    for (int i = paramInt1 / 2; paramPtr1.getDouble((paramInt1 + paramInt2) * 8) > paramPtr1.getDouble((i + paramInt2) * 8); i /= 2) {
      swap(paramInt1 + paramInt2, i + paramInt2, paramPtr1, paramPtr2, paramPtr3, paramInt3);
      paramInt1 = i;
    } 
    if (paramInt3 > 1)
      Print.Rprintf(new BytePtr("\n\000".getBytes(), 0), new Object[0]); 
  }
  
  public static void downoutupperin(int paramInt1, int paramInt2, int paramInt3, int paramInt4, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, int paramInt5) {
    if (paramInt5 > 1) {
      Object[] arrayOfObject = new Object[2];
      arrayOfObject[0] = Integer.valueOf(paramInt1);
      arrayOfObject[1] = Integer.valueOf(paramInt2);
      Print.Rprintf(new BytePtr("\n__downoutUPPERin(%d, %d)\n  \000".getBytes(), 0), arrayOfObject);
    } 
    toroot(paramInt1, paramInt2, paramInt3, paramInt4, paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramInt5);
    if (paramPtr2.getDouble(paramInt2 * 8) > paramPtr2.getDouble((paramInt2 + 1) * 8)) {
      swap(paramInt2, paramInt2 + 1, paramPtr2, paramPtr3, paramPtr4, paramInt5);
      uptoleave(1, paramInt2, paramPtr2, paramPtr3, paramPtr4, paramInt5);
    } 
  }
  
  public static void downtoleave(int paramInt1, int paramInt2, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, int paramInt3) {
    if (paramInt3 > 1) {
      Object[] arrayOfObject = new Object[2];
      arrayOfObject[0] = Integer.valueOf(paramInt1);
      arrayOfObject[1] = Integer.valueOf(paramInt2);
      Print.Rprintf(new BytePtr("\n downtoleave(%d, %d)\n   \000".getBytes(), 0), arrayOfObject);
    } 
    while (true) {
      int j = paramInt1 * 2;
      int i = j + -1;
      if (paramPtr1.getDouble((j + paramInt2) * 8) < paramPtr1.getDouble((i + paramInt2) * 8))
        j = i; 
      if (paramPtr1.getDouble((paramInt1 + paramInt2) * 8) < paramPtr1.getDouble((j + paramInt2) * 8)) {
        swap(paramInt1 + paramInt2, j + paramInt2, paramPtr1, paramPtr2, paramPtr3, paramInt3);
        paramInt1 = j;
        continue;
      } 
      break;
    } 
  }
  
  public static void inittree(int paramInt1, int paramInt2, int paramInt3, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, int paramInt4) {
    for (byte b = 1; b <= paramInt2; b++) {
      paramPtr2.setDouble(b * 8, paramPtr1.getDouble((b + -1) * 8));
      int i = b * 4;
      paramPtr3.setInt(i, b);
      paramPtr4.setInt(b * 4, paramPtr3.getInt(i));
    } 
    R_heapsort(1, paramInt2, paramPtr2, paramPtr3, paramPtr4, paramInt4);
    double d = Math.abs(paramPtr2.getDouble(paramInt2 * 8));
    if (Math.abs(paramPtr2.getDouble(8)) > d)
      d = Math.abs(paramPtr2.getDouble(8)); 
    for (paramInt4 = paramInt2; paramInt4 < paramInt1; paramInt4++) {
      if (Math.abs(paramPtr1.getDouble(paramInt4 * 8)) > d)
        d = Math.abs(paramPtr1.getDouble(paramInt4 * 8)); 
    } 
    d = d * 2.0D + 1.0D;
    for (paramInt1 = paramInt2; paramInt1 > 0; paramInt1--) {
      paramPtr2.setDouble((paramInt1 + paramInt3) * 8, paramPtr2.getDouble(paramInt1 * 8));
      paramPtr4.setInt((paramInt1 + paramInt3) * 4, paramPtr4.getInt(paramInt1 * 4) + -1);
    } 
    for (paramInt1 = 0; paramInt1 < paramInt2; paramInt1++)
      paramPtr3.setInt(paramInt1 * 4, paramPtr3.getInt((paramInt1 + 1) * 4) + paramInt3); 
    paramInt1 = paramInt3 + 1;
    for (paramInt3 = 0; paramInt3 < paramInt1; paramInt3++) {
      paramPtr2.setDouble(paramInt3 * 8, -d);
      paramPtr2.setDouble((paramInt2 + paramInt1 + paramInt3) * 8, d);
    } 
  }
  
  public static SEXP runmed(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4, SEXP paramSEXP5) {
    Ptr ptr1;
    if (Rinternals.TYPEOF(paramSEXP1) != 14)
      Error.Rf_error(new BytePtr("numeric 'x' required\000".getBytes(), 0), new Object[0]); 
    int m = Rinternals.XLENGTH(paramSEXP1);
    int k = Rinternals.Rf_asInteger(paramSEXP3);
    int i = Rinternals.Rf_asInteger(paramSEXP4);
    int j = Rinternals.Rf_asInteger(paramSEXP5);
    paramSEXP3 = Rinternals.Rf_protect(Rinternals.Rf_allocVector(14, m));
    if (Rinternals.Rf_asInteger(paramSEXP2) != 1) {
      boolean bool;
      if (j <= 0) {
        bool = false;
      } else {
        bool = true;
      } 
      ptr1 = Rinternals2.REAL(paramSEXP3);
      Srunmed(Rinternals2.REAL(paramSEXP1), ptr1, m, k, i, bool);
      return paramSEXP3;
    } 
    if (Rinternals.IS_LONG_VEC(paramSEXP1) != 0)
      Error.Rf_error(new BytePtr("long vectors are not supported for algorithm = \"Turlach\"\000".getBytes(), 0), new Object[0]); 
    IntPtr intPtr2 = IntPtr.malloc((k + 1) * 4);
    IntPtr intPtr1 = IntPtr.malloc(k * 8 + 4);
    DoublePtr doublePtr = DoublePtr.malloc(k * 16 + 8);
    Ptr ptr2 = Rinternals2.REAL(paramSEXP3);
    Trunmed(m, k, Rinternals2.REAL(paramSEXP1), ptr2, (Ptr)intPtr2, (Ptr)intPtr1, (Ptr)doublePtr, i, ptr1);
    return paramSEXP3;
  }
  
  public static void runmedint(int paramInt1, int paramInt2, int paramInt3, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, int paramInt4, int paramInt5) {
    if (paramInt4 == 0) {
      for (byte b = 0; b < paramInt3; b++)
        paramPtr2.setDouble(b * 8, paramPtr1.getDouble(b * 8)); 
      paramPtr2.setDouble(paramInt3 * 8, paramPtr3.getDouble(paramInt2 * 8));
    } else {
      for (byte b = 0; b <= paramInt3; b++)
        paramPtr2.setDouble(b * 8, paramPtr3.getDouble(paramInt2 * 8)); 
    } 
    int i = 0;
    for (int j = paramInt3 + 1; paramInt1 - paramInt3 > j; j++) {
      int n = paramPtr4.getInt(i * 4);
      int k = j + paramInt3;
      paramPtr3.setDouble(n * 8, paramPtr1.getDouble(k * 8));
      int m = n - paramInt2;
      if (n <= paramInt2) {
        if (n >= paramInt2) {
          if (paramPtr3.getDouble(paramInt2 * 8) <= paramPtr3.getDouble((paramInt2 + 1) * 8)) {
            if (paramPtr3.getDouble(paramInt2 * 8) < paramPtr3.getDouble((paramInt2 + -1) * 8))
              wentouttwo(paramInt2, paramPtr3, paramPtr4, paramPtr5, paramInt5); 
          } else {
            wentoutone(paramInt2, paramPtr3, paramPtr4, paramPtr5, paramInt5);
          } 
        } else if (paramPtr1.getDouble(k * 8) >= paramPtr3.getDouble(paramInt2 * 8)) {
          downoutupperin(m, paramInt2, k, i, paramPtr1, paramPtr3, paramPtr4, paramPtr5, paramInt5);
        } else {
          downoutdownin(m, paramInt2, paramPtr3, paramPtr4, paramPtr5, paramInt5);
        } 
      } else if (paramPtr1.getDouble(k * 8) < paramPtr3.getDouble(paramInt2 * 8)) {
        upperoutdownin(m, paramInt2, k, i, paramPtr1, paramPtr3, paramPtr4, paramPtr5, paramInt5);
      } else {
        upperoutupperin(m, paramInt2, paramPtr3, paramPtr4, paramPtr5, paramInt5);
      } 
      paramPtr2.setDouble(j * 8, paramPtr3.getDouble(paramInt2 * 8));
      i = (i + 1) % paramInt2;
    } 
    if (paramInt4 == 0) {
      for (paramInt2 = paramInt1 - paramInt3; paramInt2 < paramInt1; paramInt2++)
        paramPtr2.setDouble(paramInt2 * 8, paramPtr1.getDouble(paramInt2 * 8)); 
      return;
    } 
    for (paramInt3 = paramInt1 - paramInt3; paramInt3 < paramInt1; paramInt3++)
      paramPtr2.setDouble(paramInt3 * 8, paramPtr3.getDouble(paramInt2 * 8)); 
  }
  
  public static void siftup(int paramInt1, int paramInt2, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, int paramInt3) {
    if (paramInt3 > 1) {
      Object[] arrayOfObject = new Object[2];
      arrayOfObject[0] = Integer.valueOf(paramInt1);
      arrayOfObject[1] = Integer.valueOf(paramInt2);
      Print.Rprintf(new BytePtr("siftup(%d,%d) \000".getBytes(), 0), arrayOfObject);
    } 
    paramInt3 = paramInt1;
    int i = paramInt1 * 2;
    double d = paramPtr1.getDouble(paramInt1 * 8);
    paramInt1 = paramPtr3.getInt(paramInt1 * 4);
    while (i <= paramInt2) {
      if (i < paramInt2 && paramPtr1.getDouble(i * 8) < paramPtr1.getDouble((i + 1) * 8))
        i++; 
      if (paramPtr1.getDouble(i * 8) > d) {
        paramPtr1.setDouble(paramInt3 * 8, paramPtr1.getDouble(i * 8));
        paramPtr2.setInt(paramPtr3.getInt(i * 4) * 4, paramInt3);
        paramPtr3.setInt(paramInt3 * 4, paramPtr3.getInt(i * 4));
        paramInt3 = i;
        i *= 2;
        continue;
      } 
      break;
    } 
    paramPtr1.setDouble(paramInt3 * 8, d);
    paramPtr2.setInt(paramInt1 * 4, paramInt3);
    paramPtr3.setInt(paramInt3 * 4, paramInt1);
  }
  
  public static void swap(int paramInt1, int paramInt2, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, int paramInt3) {
    if (paramInt3 > 2) {
      Object[] arrayOfObject = new Object[2];
      arrayOfObject[0] = Integer.valueOf(paramInt1);
      arrayOfObject[1] = Integer.valueOf(paramInt2);
      Print.Rprintf(new BytePtr("SW(%d,%d) \000".getBytes(), 0), arrayOfObject);
    } 
    double d = paramPtr1.getDouble(paramInt1 * 8);
    paramPtr1.setDouble(paramInt1 * 8, paramPtr1.getDouble(paramInt2 * 8));
    paramPtr1.setDouble(paramInt2 * 8, d);
    int i = paramPtr3.getInt(paramInt1 * 4);
    int j = paramPtr3.getInt(paramInt2 * 4);
    paramPtr3.setInt(paramInt1 * 4, j);
    paramPtr3.setInt(paramInt2 * 4, i);
    paramPtr2.setInt(i * 4, paramInt2);
    paramPtr2.setInt(j * 4, paramInt1);
  }
  
  public static void toroot(int paramInt1, int paramInt2, int paramInt3, int paramInt4, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, int paramInt5) {
    if (paramInt5 > 1) {
      Object[] arrayOfObject = new Object[3];
      arrayOfObject[0] = Integer.valueOf(paramInt2);
      arrayOfObject[1] = Integer.valueOf(paramInt3);
      arrayOfObject[2] = Integer.valueOf(paramInt4);
      Print.Rprintf(new BytePtr("toroot(%d, %d,%d) \000".getBytes(), 0), arrayOfObject);
    } 
    while (true) {
      paramInt5 = paramInt1 / 2;
      paramPtr2.setDouble((paramInt1 + paramInt2) * 8, paramPtr2.getDouble((paramInt5 + paramInt2) * 8));
      paramPtr3.setInt(paramPtr4.getInt((paramInt5 + paramInt2) * 4) * 4, paramInt1 + paramInt2);
      paramPtr4.setInt((paramInt1 + paramInt2) * 4, paramPtr4.getInt((paramInt5 + paramInt2) * 4));
      paramInt1 = paramInt5;
      if (paramInt5 == 0) {
        paramPtr2.setDouble(paramInt2 * 8, paramPtr1.getDouble(paramInt3 * 8));
        paramPtr3.setInt(paramInt4 * 4, paramInt2);
        paramPtr4.setInt(paramInt2 * 4, paramInt4);
        return;
      } 
    } 
  }
  
  public static void upperoutdownin(int paramInt1, int paramInt2, int paramInt3, int paramInt4, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, int paramInt5) {
    if (paramInt5 > 1) {
      Object[] arrayOfObject = new Object[2];
      arrayOfObject[0] = Integer.valueOf(paramInt1);
      arrayOfObject[1] = Integer.valueOf(paramInt2);
      Print.Rprintf(new BytePtr("\n__upperoutDOWNin(%d, %d)\n  \000".getBytes(), 0), arrayOfObject);
    } 
    toroot(paramInt1, paramInt2, paramInt3, paramInt4, paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramInt5);
    if (paramPtr2.getDouble(paramInt2 * 8) < paramPtr2.getDouble((paramInt2 + -1) * 8)) {
      swap(paramInt2, paramInt2 + -1, paramPtr2, paramPtr3, paramPtr4, paramInt5);
      downtoleave(-1, paramInt2, paramPtr2, paramPtr3, paramPtr4, paramInt5);
    } 
  }
  
  public static void upperoutupperin(int paramInt1, int paramInt2, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, int paramInt3) {
    if (paramInt3 > 1) {
      Object[] arrayOfObject = new Object[2];
      arrayOfObject[0] = Integer.valueOf(paramInt1);
      arrayOfObject[1] = Integer.valueOf(paramInt2);
      Print.Rprintf(new BytePtr("\nUpperoutUPPERin(%d, %d)\n  \000".getBytes(), 0), arrayOfObject);
    } 
    uptoleave(paramInt1, paramInt2, paramPtr1, paramPtr2, paramPtr3, paramInt3);
    for (int i = paramInt1 / 2; paramPtr1.getDouble((paramInt1 + paramInt2) * 8) < paramPtr1.getDouble((i + paramInt2) * 8); i /= 2) {
      swap(paramInt1 + paramInt2, i + paramInt2, paramPtr1, paramPtr2, paramPtr3, paramInt3);
      paramInt1 = i;
    } 
    if (paramInt3 > 1)
      Print.Rprintf(new BytePtr("\n\000".getBytes(), 0), new Object[0]); 
  }
  
  public static void uptoleave(int paramInt1, int paramInt2, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, int paramInt3) {
    if (paramInt3 > 1) {
      Object[] arrayOfObject = new Object[2];
      arrayOfObject[0] = Integer.valueOf(paramInt1);
      arrayOfObject[1] = Integer.valueOf(paramInt2);
      Print.Rprintf(new BytePtr("\n uptoleave(%d, %d)\n   \000".getBytes(), 0), arrayOfObject);
    } 
    while (true) {
      int j = paramInt1 * 2;
      int i = j + 1;
      if (paramPtr1.getDouble((j + paramInt2) * 8) > paramPtr1.getDouble((i + paramInt2) * 8))
        j = i; 
      if (paramPtr1.getDouble((paramInt1 + paramInt2) * 8) > paramPtr1.getDouble((j + paramInt2) * 8)) {
        swap(paramInt1 + paramInt2, j + paramInt2, paramPtr1, paramPtr2, paramPtr3, paramInt3);
        paramInt1 = j;
        continue;
      } 
      break;
    } 
  }
  
  public static void wentoutone(int paramInt1, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, int paramInt2) {
    if (paramInt2 > 1)
      Print.Rprintf(new BytePtr("\nwentOUT_1(%d)\n  \000".getBytes(), 0), new Object[] { Integer.valueOf(paramInt1) }); 
    swap(paramInt1, paramInt1 + 1, paramPtr1, paramPtr2, paramPtr3, paramInt2);
    uptoleave(1, paramInt1, paramPtr1, paramPtr2, paramPtr3, paramInt2);
  }
  
  public static void wentouttwo(int paramInt1, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, int paramInt2) {
    if (paramInt2 > 1)
      Print.Rprintf(new BytePtr("\nwentOUT_2(%d)\n  \000".getBytes(), 0), new Object[] { Integer.valueOf(paramInt1) }); 
    swap(paramInt1, paramInt1 + -1, paramPtr1, paramPtr2, paramPtr3, paramInt2);
    downtoleave(-1, paramInt1, paramPtr1, paramPtr2, paramPtr3, paramInt2);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/stats-0.9.2724.jar!/org/renjin/stats/Srunmed__.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */