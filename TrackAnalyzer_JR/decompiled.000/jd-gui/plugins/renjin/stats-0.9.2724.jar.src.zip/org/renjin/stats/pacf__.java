package org.renjin.stats;

import org.renjin.gcc.runtime.Builtins;
import org.renjin.gcc.runtime.BytePtr;
import org.renjin.gcc.runtime.DoublePtr;
import org.renjin.gcc.runtime.Mathlib;
import org.renjin.gcc.runtime.MixedPtr;
import org.renjin.gcc.runtime.Ptr;
import org.renjin.gcc.runtime.Stdlib;
import org.renjin.gcc.runtime.UnsatisfiedLinkException;
import org.renjin.gcc.runtime.VoidPtr;
import org.renjin.gnur.api.Arith;
import org.renjin.gnur.api.Error;
import org.renjin.gnur.api.GetText;
import org.renjin.gnur.api.Rinternals;
import org.renjin.gnur.api.Rinternals2;
import org.renjin.sexp.SEXP;

public class pacf__ {
  public static SEXP Starma_tag = (SEXP)BytePtr.of(0).getArray();
  
  public static SEXP ARMAtoMA(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3) {
    SEXP sEXP1 = (SEXP)BytePtr.of(0).getArray();
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    int j = Rinternals.LENGTH(paramSEXP1);
    int k = Rinternals.LENGTH(paramSEXP2);
    int i = Rinternals.Rf_asInteger(paramSEXP3);
    Ptr ptr1 = Rinternals2.REAL(paramSEXP1);
    Ptr ptr2 = Rinternals2.REAL(paramSEXP2);
    if (i <= 0 || i == Arith.R_NaInt)
      Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("invalid value of lag.max\000".getBytes(), 0)), new Object[0]); 
    SEXP sEXP2 = Rinternals.Rf_allocVector(14, i);
    Rinternals.Rf_protect(sEXP2);
    Ptr ptr3 = Rinternals2.REAL(sEXP2);
    for (byte b = 0; b < i; b++) {
      double d1;
      if (b >= k) {
        d1 = 0.0D;
      } else {
        d1 = ptr2.getDouble(0 + b * 8);
      } 
      double d2 = d1;
      for (byte b1 = 0; Math.min(b + 1, j) > b1; b1++) {
        double d;
        d1 = ptr1.getDouble(0 + b1 * 8);
        if (b - b1 + -1 < 0) {
          d = 1.0D;
        } else {
          d = ptr3.getDouble(0 + (b - b1 + -1) * 8);
        } 
        d2 = d1 * d + d2;
      } 
      ptr3.setDouble(0 + b * 8, d2);
    } 
    return sEXP2;
  }
  
  public static SEXP Dotrans(SEXP paramSEXP1, SEXP paramSEXP2) {
    SEXP sEXP = Rinternals.Rf_allocVector(14, Rinternals.LENGTH(paramSEXP2));
    if (Rinternals.TYPEOF(paramSEXP1) != 22 || Rinternals.R_ExternalPtrTag(paramSEXP1) != Starma_tag)
      Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("bad Starma struct\000".getBytes(), 0)), new Object[0]); 
    Ptr ptr = Rinternals2.REAL(sEXP);
    dotrans(VoidPtr.toPtr(Rinternals.R_ExternalPtrAddr(paramSEXP1)), Rinternals2.REAL(paramSEXP2), ptr, 1);
    return sEXP;
  }
  
  public static SEXP Gradtrans(SEXP paramSEXP1, SEXP paramSEXP2) {
    double[] arrayOfDouble1 = new double[100];
    double[] arrayOfDouble2 = new double[100];
    double[] arrayOfDouble3 = new double[100];
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    SEXP sEXP2 = (SEXP)BytePtr.of(0).getArray();
    int i = Rinternals.LENGTH(paramSEXP2);
    SEXP sEXP1 = Rinternals.Rf_allocMatrix(14, Rinternals.LENGTH(paramSEXP2), i);
    Ptr ptr3 = Rinternals2.REAL(paramSEXP2);
    Ptr ptr2 = Rinternals2.REAL(sEXP1);
    if (Rinternals.TYPEOF(paramSEXP1) != 22 || Rinternals.R_ExternalPtrTag(paramSEXP1) != Starma_tag)
      Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("bad Starma struct\000".getBytes(), 0)), new Object[0]); 
    Ptr ptr1 = VoidPtr.toPtr(Rinternals.R_ExternalPtrAddr(paramSEXP1));
    int j = ptr1.getInt(44) + ptr1.getInt(48) + ptr1.getInt(52) + ptr1.getInt(56) + ptr1.getInt(28);
    byte b;
    for (b = 0; b < j; b++) {
      for (byte b1 = 0; b1 < j; b1++) {
        double d;
        int k = 0 + (b1 * j + b) * 8;
        if (b != b1) {
          d = 0.0D;
        } else {
          d = 1.0D;
        } 
        ptr2.setDouble(k, d);
      } 
    } 
    if (ptr1.getInt(44) > 0) {
      byte b1;
      for (b1 = 0; ptr1.getInt(44) > b1; b1++)
        arrayOfDouble3[b1] = ptr3.getDouble(0 + b1 * 8); 
      partrans(ptr1.getInt(44), (Ptr)new DoublePtr(arrayOfDouble3, 0), (Ptr)new DoublePtr(arrayOfDouble2, 0));
      for (b1 = 0; ptr1.getInt(44) > b1; b1++) {
        arrayOfDouble3[b1] = arrayOfDouble3[b1] + 0.001D;
        partrans(ptr1.getInt(44), (Ptr)new DoublePtr(arrayOfDouble3, 0), (Ptr)new DoublePtr(arrayOfDouble1, 0));
        for (b = 0; ptr1.getInt(44) > b; b++)
          ptr2.setDouble(0 + (b * j + b1) * 8, (arrayOfDouble1[b] - arrayOfDouble2[b]) / 0.001D); 
        arrayOfDouble3[b1] = arrayOfDouble3[b1] - 0.001D;
      } 
    } 
    if (ptr1.getInt(48) > 0) {
      int k = ptr1.getInt(44);
      for (b = 0; ptr1.getInt(48) > b; b++)
        arrayOfDouble3[b] = ptr3.getDouble(0 + (b + k) * 8); 
      partrans(ptr1.getInt(48), (Ptr)new DoublePtr(arrayOfDouble3, 0), (Ptr)new DoublePtr(arrayOfDouble2, 0));
      for (b = 0; ptr1.getInt(48) > b; b++) {
        arrayOfDouble3[b] = arrayOfDouble3[b] + 0.001D;
        partrans(ptr1.getInt(48), (Ptr)new DoublePtr(arrayOfDouble3, 0), (Ptr)new DoublePtr(arrayOfDouble1, 0));
        for (byte b1 = 0; ptr1.getInt(48) > b1; b1++)
          ptr2.setDouble(0 + (b + k + b1 * j) * 8, (arrayOfDouble1[b1] - arrayOfDouble2[b1]) / 0.001D); 
        arrayOfDouble3[b] = arrayOfDouble3[b] - 0.001D;
      } 
    } 
    if (ptr1.getInt(52) > 0) {
      int k = ptr1.getInt(44) + ptr1.getInt(48);
      for (b = 0; ptr1.getInt(52) > b; b++)
        arrayOfDouble3[b] = ptr3.getDouble(0 + (b + k) * 8); 
      partrans(ptr1.getInt(52), (Ptr)new DoublePtr(arrayOfDouble3, 0), (Ptr)new DoublePtr(arrayOfDouble2, 0));
      for (b = 0; ptr1.getInt(52) > b; b++) {
        arrayOfDouble3[b] = arrayOfDouble3[b] + 0.001D;
        partrans(ptr1.getInt(52), (Ptr)new DoublePtr(arrayOfDouble3, 0), (Ptr)new DoublePtr(arrayOfDouble1, 0));
        for (byte b1 = 0; ptr1.getInt(52) > b1; b1++)
          ptr2.setDouble(0 + (b + k + (b1 + k) * j) * 8, (arrayOfDouble1[b1] - arrayOfDouble2[b1]) / 0.001D); 
        arrayOfDouble3[b] = arrayOfDouble3[b] - 0.001D;
      } 
    } 
    if (ptr1.getInt(56) > 0) {
      int k = ptr1.getInt(44) + ptr1.getInt(48) + ptr1.getInt(52);
      for (b = 0; ptr1.getInt(56) > b; b++)
        arrayOfDouble3[b] = ptr3.getDouble(0 + (b + k) * 8); 
      partrans(ptr1.getInt(56), (Ptr)new DoublePtr(arrayOfDouble3, 0), (Ptr)new DoublePtr(arrayOfDouble2, 0));
      for (byte b1 = 0; ptr1.getInt(56) > b1; b1++) {
        arrayOfDouble3[b1] = arrayOfDouble3[b1] + 0.001D;
        partrans(ptr1.getInt(56), (Ptr)new DoublePtr(arrayOfDouble3, 0), (Ptr)new DoublePtr(arrayOfDouble1, 0));
        for (b = 0; ptr1.getInt(56) > b; b++)
          ptr2.setDouble(0 + (b1 + k + (b + k) * j) * 8, (arrayOfDouble1[b] - arrayOfDouble2[b]) / 0.001D); 
        arrayOfDouble3[b1] = arrayOfDouble3[b1] - 0.001D;
      } 
    } 
    return sEXP1;
  }
  
  public static SEXP Invtrans(SEXP paramSEXP1, SEXP paramSEXP2) {
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    SEXP sEXP = (SEXP)BytePtr.of(0).getArray();
    sEXP = Rinternals.Rf_allocVector(14, Rinternals.LENGTH(paramSEXP2));
    Ptr ptr2 = Rinternals2.REAL(paramSEXP2);
    Ptr ptr3 = Rinternals2.REAL(sEXP);
    if (Rinternals.TYPEOF(paramSEXP1) != 22 || Rinternals.R_ExternalPtrTag(paramSEXP1) != Starma_tag)
      Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("bad Starma struct\000".getBytes(), 0)), new Object[0]); 
    Ptr ptr1 = VoidPtr.toPtr(Rinternals.R_ExternalPtrAddr(paramSEXP1));
    int j = ptr1.getInt(44) + ptr1.getInt(48) + ptr1.getInt(52) + ptr1.getInt(56);
    invpartrans(ptr1.getInt(44), ptr2.pointerPlus(0), ptr3.pointerPlus(0));
    int i = ptr1.getInt(44) + 0;
    int k = ptr1.getInt(48);
    Ptr ptr4 = ptr2.pointerPlus(0 + i * 8);
    Ptr ptr5 = ptr3.pointerPlus(0 + i * 8);
    invpartrans(k, ptr4, ptr5);
    i = ptr1.getInt(48) + i;
    k = ptr1.getInt(52);
    ptr4 = ptr2.pointerPlus(0 + i * 8);
    ptr5 = ptr3.pointerPlus(0 + i * 8);
    invpartrans(k, ptr4, ptr5);
    i = (ptr1.getInt(52) + i) * 8 + 0;
    k = ptr1.getInt(56);
    ptr4 = ptr2.pointerPlus(0 + (ptr1.getInt(52) + i) * 8);
    invpartrans(k, ptr4, ptr3.pointerPlus(i));
    for (i = j; ptr1.getInt(28) + j > i; i++)
      ptr3.setDouble(0 + i * 8, ptr2.getDouble(0 + i * 8)); 
    return sEXP;
  }
  
  public static SEXP Starma_method(SEXP paramSEXP1, SEXP paramSEXP2) {
    if (Rinternals.TYPEOF(paramSEXP1) != 22 || Rinternals.R_ExternalPtrTag(paramSEXP1) != Starma_tag)
      Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("bad Starma struct\000".getBytes(), 0)), new Object[0]); 
    VoidPtr.toPtr(Rinternals.R_ExternalPtrAddr(paramSEXP1)).setInt(36, Rinternals.Rf_asInteger(paramSEXP2));
    return Rinternals.R_NilValue;
  }
  
  public static SEXP ar2ma(SEXP paramSEXP1, SEXP paramSEXP2) {
    int i = Rinternals.LENGTH(Rinternals.Rf_protect(Rinternals.Rf_coerceVector(paramSEXP1, 14)));
    int k = Rinternals.Rf_asInteger(paramSEXP2);
    int j = i + k + 1;
    paramSEXP2 = Rinternals.Rf_protect(Rinternals.Rf_allocVector(14, j));
    Ptr ptr2 = Rinternals2.REAL(paramSEXP2);
    Ptr ptr1 = Rinternals2.REAL(Rinternals.Rf_protect(Rinternals.Rf_coerceVector(paramSEXP1, 14)));
    artoma(i, ptr1, ptr2, j);
    return Rinternals.Rf_lengthgets(paramSEXP2, k);
  }
  
  public static SEXP arma0_kfore(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4) {
    BytePtr.of(0);
    SEXP sEXP2 = (SEXP)BytePtr.of(0).getArray();
    sEXP2 = (SEXP)BytePtr.of(0).getArray();
    sEXP2 = (SEXP)BytePtr.of(0).getArray();
    BytePtr.of(0);
    BytePtr.of(0);
    (new int[1])[0] = 0;
    int j = Rinternals.Rf_asInteger(paramSEXP2);
    int i = Rinternals.Rf_asInteger(paramSEXP4);
    (new int[1])[0] = 0;
    if (Rinternals.TYPEOF(paramSEXP1) != 22 || Rinternals.R_ExternalPtrTag(paramSEXP1) != Starma_tag)
      Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("bad Starma struct\000".getBytes(), 0)), new Object[0]); 
    Ptr ptr = VoidPtr.toPtr(Rinternals.R_ExternalPtrAddr(paramSEXP1));
    SEXP sEXP3 = Rinternals.Rf_allocVector(19, 2);
    Rinternals.Rf_protect(sEXP3);
    paramSEXP1 = Rinternals.Rf_allocVector(14, i);
    Rinternals.SET_VECTOR_ELT(sEXP3, 0, paramSEXP1);
    SEXP sEXP1 = Rinternals.Rf_allocVector(14, i);
    Rinternals.SET_VECTOR_ELT(sEXP3, 1, sEXP1);
    int k = ptr.getInt(60) * Rinternals.Rf_asInteger(paramSEXP3) + j;
    DoublePtr doublePtr1 = DoublePtr.malloc((k + 1) * 8);
    DoublePtr doublePtr2 = DoublePtr.malloc((k + 1) * 8);
    doublePtr1.setDouble(0, 1.0D);
    byte b2;
    for (b2 = 1; b2 <= k; b2++)
      doublePtr1.setDouble(0 + b2 * 8, 0.0D); 
    for (b2 = 0; b2 < j; b2++) {
      byte b;
      for (b = 0; b <= k; b++)
        doublePtr2.setDouble(0 + b * 8, doublePtr1.getDouble(0 + b * 8)); 
      for (b = 0; k + -1 >= b; b++)
        doublePtr1.setDouble(0 + (b + 1) * 8, doublePtr1.getDouble(0 + (b + 1) * 8) - doublePtr2.getDouble(0 + b * 8)); 
    } 
    for (j = 0; Rinternals.Rf_asInteger(paramSEXP3) > j; j++) {
      for (b2 = 0; b2 <= k; b2++)
        doublePtr2.setDouble(0 + b2 * 8, doublePtr1.getDouble(0 + b2 * 8)); 
      for (b2 = 0; k - ptr.getInt(60) >= b2; b2++)
        doublePtr1.setDouble(0 + (ptr.getInt(60) + b2) * 8, doublePtr1.getDouble(0 + (ptr.getInt(60) + b2) * 8) - doublePtr2.getDouble(0 + b2 * 8)); 
    } 
    for (byte b1 = 1; b1 <= k; b1++)
      doublePtr1.setDouble(0 + b1 * 8, -doublePtr1.getDouble(0 + b1 * 8)); 
    Rinternals2.REAL(sEXP1);
    Rinternals2.REAL(paramSEXP1);
    throw new UnsatisfiedLinkException("forkal");
  }
  
  public static SEXP arma0fa(SEXP paramSEXP1, SEXP paramSEXP2) {
    double[] arrayOfDouble1 = new double[1];
    double[] arrayOfDouble2 = new double[1];
    int[] arrayOfInt = new int[1];
    BytePtr.of(0);
    arrayOfDouble1[0] = 0.0D;
    (new int[1])[0] = 0;
    (new int[1])[0] = 0;
    if (Rinternals.TYPEOF(paramSEXP1) != 22 || Rinternals.R_ExternalPtrTag(paramSEXP1) != Starma_tag)
      Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("bad Starma struct\000".getBytes(), 0)), new Object[0]); 
    Ptr ptr1 = VoidPtr.toPtr(Rinternals.R_ExternalPtrAddr(paramSEXP1));
    int k = ptr1.getInt(32);
    Ptr ptr3 = ptr1.getPointer(80);
    Ptr ptr2 = Rinternals2.REAL(paramSEXP2);
    dotrans(ptr1.pointerPlus(0), ptr2, ptr3, k);
    if (ptr1.getInt(60) <= 0) {
      byte b;
      for (b = 0; ptr1.getInt(44) > b; b++)
        ptr1.getPointer(84).setDouble(0 + b * 8, ptr1.getPointer(80).getDouble(0 + b * 8)); 
      for (b = 0; ptr1.getInt(48) > b; b++)
        ptr1.getPointer(88).setDouble(0 + b * 8, ptr1.getPointer(80).getDouble(0 + (ptr1.getInt(44) + b) * 8)); 
    } else {
      int n;
      for (n = 0; ptr1.getInt(44) > n; n++)
        ptr1.getPointer(84).setDouble(0 + n * 8, ptr1.getPointer(80).getDouble(0 + n * 8)); 
      for (n = 0; ptr1.getInt(48) > n; n++)
        ptr1.getPointer(88).setDouble(0 + n * 8, ptr1.getPointer(80).getDouble(0 + (ptr1.getInt(44) + n) * 8)); 
      for (n = ptr1.getInt(44); ptr1.getInt(0) > n; n++)
        ptr1.getPointer(84).setDouble(0 + n * 8, 0.0D); 
      for (n = ptr1.getInt(48); ptr1.getInt(4) > n; n++)
        ptr1.getPointer(88).setDouble(0 + n * 8, 0.0D); 
      for (n = 0; ptr1.getInt(52) > n; n++) {
        ptr1.getPointer(84).setDouble(0 + (n + 1) * 8 * ptr1.getInt(60) + -8, ptr1.getPointer(84).getDouble(0 + (n + 1) * 8 * ptr1.getInt(60) + -8) + ptr1.getPointer(80).getDouble(0 + (ptr1.getInt(44) + n + ptr1.getInt(48)) * 8));
        for (byte b = 0; ptr1.getInt(44) > b; b++)
          ptr1.getPointer(84).setDouble(0 + ((n + 1) * ptr1.getInt(60) + b) * 8, ptr1.getPointer(84).getDouble(0 + ((n + 1) * ptr1.getInt(60) + b) * 8) - ptr1.getPointer(80).getDouble(0 + b * 8) * ptr1.getPointer(80).getDouble(0 + (ptr1.getInt(44) + n + ptr1.getInt(48)) * 8)); 
      } 
      for (n = 0; ptr1.getInt(56) > n; n++) {
        ptr1.getPointer(88).setDouble(0 + (n + 1) * 8 * ptr1.getInt(60) + -8, ptr1.getPointer(88).getDouble(0 + (n + 1) * 8 * ptr1.getInt(60) + -8) + ptr1.getPointer(80).getDouble(0 + (ptr1.getInt(44) + n + ptr1.getInt(48) + ptr1.getInt(52)) * 8));
        for (byte b = 0; ptr1.getInt(48) > b; b++)
          ptr1.getPointer(88).setDouble(0 + ((n + 1) * ptr1.getInt(60) + b) * 8, ptr1.getPointer(88).getDouble(0 + ((n + 1) * ptr1.getInt(60) + b) * 8) + ptr1.getPointer(80).getDouble(0 + (ptr1.getInt(44) + b) * 8) * ptr1.getPointer(80).getDouble(0 + (ptr1.getInt(44) + n + ptr1.getInt(48) + ptr1.getInt(52)) * 8)); 
      } 
    } 
    int i = ptr1.getInt(44) + ptr1.getInt(48) + ptr1.getInt(52) + ptr1.getInt(56);
    if (ptr1.getInt(28) > 0)
      for (byte b = 0; ptr1.getInt(20) > b; b++) {
        double d1 = ptr1.getPointer(124).getDouble(0 + b * 8);
        for (k = 0; ptr1.getInt(28) > k; k++)
          d1 -= ptr1.getPointer(132).getDouble(0 + (ptr1.getInt(20) * k + b) * 8) * ptr1.getPointer(80).getDouble(0 + (i + k) * 8); 
        ptr1.getPointer(120).setDouble(0 + b * 8, d1);
      }  
    if (ptr1.getInt(36) != 1)
      throw new UnsatisfiedLinkException("starma"); 
    i = ptr1.getInt(44) + ptr1.getInt(60) * ptr1.getInt(52);
    int j = ptr1.getInt(48) + ptr1.getInt(60) * ptr1.getInt(56);
    k = 0;
    arrayOfDouble1[0] = 0.0D;
    int m;
    for (m = 0; ptr1.getInt(24) > m; m++)
      ptr1.getPointer(128).setDouble(0 + m * 8, 0.0D); 
    for (m = ptr1.getInt(24); ptr1.getInt(20) > m; m++) {
      double d1 = ptr1.getPointer(120).getDouble(0 + m * 8);
      byte b;
      for (b = 0; Math.min(m - ptr1.getInt(24), i) > b; b++)
        d1 -= ptr1.getPointer(84).getDouble(0 + b * 8) * ptr1.getPointer(120).getDouble(0 + (m - b + -1) * 8); 
      for (b = 0; Math.min(m - ptr1.getInt(24), j) > b; b++)
        d1 -= ptr1.getPointer(88).getDouble(0 + b * 8) * ptr1.getPointer(128).getDouble(0 + (m - b + -1) * 8); 
      ptr1.getPointer(128).setDouble(0 + m * 8, d1);
      if (Builtins.__isnan(d1) == 0) {
        k++;
        arrayOfDouble1[0] = d1 * d1 + arrayOfDouble1[0];
      } 
    } 
    ptr1.setDouble(72, arrayOfDouble1[0] / k);
    double d = Math.log(ptr1.getDouble(72)) * 0.5D;
    return Rinternals.Rf_ScalarReal(d);
  }
  
  public static void artoma(int paramInt1, Ptr paramPtr1, Ptr paramPtr2, int paramInt2) {
    int i;
    for (i = 0; i < paramInt1; i++)
      paramPtr2.setDouble(i * 8, paramPtr1.getDouble(i * 8)); 
    for (i = paramInt1; i < paramInt2; i++)
      paramPtr2.setDouble(i * 8, 0.0D); 
    for (i = 0; paramInt2 - paramInt1 + -1 > i; i++) {
      for (byte b = 0; b < paramInt1; b++)
        paramPtr2.setDouble((i + b + 1) * 8, paramPtr2.getDouble((i + b + 1) * 8) + paramPtr1.getDouble(b * 8) * paramPtr2.getDouble(i * 8)); 
    } 
  }
  
  public static void dotrans(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, int paramInt) {
    int i = paramPtr1.getAlignedInt(11) + paramPtr1.getAlignedInt(12) + paramPtr1.getAlignedInt(13) + paramPtr1.getAlignedInt(14) + paramPtr1.getAlignedInt(7);
    for (byte b = 0; b < i; b++)
      paramPtr3.setDouble(b * 8, paramPtr2.getDouble(b * 8)); 
    if (paramInt != 0) {
      partrans(paramPtr1.getAlignedInt(11), paramPtr2, paramPtr3);
      int m = paramPtr1.getAlignedInt(11);
      paramInt = paramPtr1.getAlignedInt(12);
      Ptr ptr2 = paramPtr2.pointerPlus(m * 8);
      Ptr ptr3 = paramPtr3.pointerPlus(m * 8);
      partrans(paramInt, ptr2, ptr3);
      m = paramPtr1.getAlignedInt(12) + m;
      paramInt = paramPtr1.getAlignedInt(13);
      ptr2 = paramPtr2.pointerPlus(m * 8);
      ptr3 = paramPtr3.pointerPlus(m * 8);
      partrans(paramInt, ptr2, ptr3);
      int k = (paramPtr1.getAlignedInt(13) + m) * 8;
      int j = paramPtr1.getAlignedInt(14);
      Ptr ptr1 = paramPtr2.pointerPlus((paramPtr1.getAlignedInt(13) + m) * 8);
      partrans(j, ptr1, paramPtr3.pointerPlus(k));
    } 
  }
  
  public static SEXP free_starma(SEXP paramSEXP) {
    if (Rinternals.TYPEOF(paramSEXP) != 22 || Rinternals.R_ExternalPtrTag(paramSEXP) != Starma_tag)
      Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("bad Starma struct\000".getBytes(), 0)), new Object[0]); 
    Ptr ptr = VoidPtr.toPtr(Rinternals.R_ExternalPtrAddr(paramSEXP));
    ptr.getPointer(80);
    ptr.setPointer(80, BytePtr.of(0));
    ptr.getPointer(92);
    ptr.setPointer(92, BytePtr.of(0));
    ptr.getPointer(96);
    ptr.setPointer(96, BytePtr.of(0));
    ptr.getPointer(100);
    ptr.setPointer(100, BytePtr.of(0));
    ptr.getPointer(104);
    ptr.setPointer(104, BytePtr.of(0));
    ptr.getPointer(108);
    ptr.setPointer(108, BytePtr.of(0));
    ptr.getPointer(112);
    ptr.setPointer(112, BytePtr.of(0));
    ptr.getPointer(116);
    ptr.setPointer(116, BytePtr.of(0));
    ptr.getPointer(120);
    ptr.setPointer(120, BytePtr.of(0));
    ptr.getPointer(124);
    ptr.setPointer(124, BytePtr.of(0));
    ptr.getPointer(128);
    ptr.setPointer(128, BytePtr.of(0));
    ptr.getPointer(84);
    ptr.setPointer(84, BytePtr.of(0));
    ptr.getPointer(88);
    ptr.setPointer(88, BytePtr.of(0));
    ptr.getPointer(132);
    ptr.setPointer(132, BytePtr.of(0));
    BytePtr.of(0);
    return Rinternals.R_NilValue;
  }
  
  public static SEXP get_resid(SEXP paramSEXP) {
    BytePtr.of(0);
    BytePtr.of(0);
    SEXP sEXP = (SEXP)BytePtr.of(0).getArray();
    if (Rinternals.TYPEOF(paramSEXP) != 22 || Rinternals.R_ExternalPtrTag(paramSEXP) != Starma_tag)
      Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("bad Starma struct\000".getBytes(), 0)), new Object[0]); 
    Ptr ptr1 = VoidPtr.toPtr(Rinternals.R_ExternalPtrAddr(paramSEXP));
    sEXP = Rinternals.Rf_allocVector(14, ptr1.getInt(20));
    Ptr ptr2 = Rinternals2.REAL(sEXP);
    for (byte b = 0; ptr1.getInt(20) > b; b++)
      ptr2.setDouble(0 + b * 8, ptr1.getPointer(128).getDouble(0 + b * 8)); 
    return sEXP;
  }
  
  public static SEXP get_s2(SEXP paramSEXP) {
    if (Rinternals.TYPEOF(paramSEXP) != 22 || Rinternals.R_ExternalPtrTag(paramSEXP) != Starma_tag)
      Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("bad Starma struct\000".getBytes(), 0)), new Object[0]); 
    return Rinternals.Rf_ScalarReal(VoidPtr.toPtr(Rinternals.R_ExternalPtrAddr(paramSEXP)).getDouble(72));
  }
  
  public static void invpartrans(int paramInt, Ptr paramPtr1, Ptr paramPtr2) {
    double[] arrayOfDouble = new double[100];
    if (paramInt > 100)
      Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("can only transform 100 pars in arima0\000".getBytes(), 0)), new Object[0]); 
    for (byte b = 0; b < paramInt; b++) {
      int j = b * 8;
      paramPtr2.setDouble(j, paramPtr1.getDouble(b * 8));
      arrayOfDouble[b] = paramPtr2.getDouble(j);
    } 
    int i;
    for (i = paramInt + -1; i > 0; i--) {
      double d = paramPtr2.getDouble(i * 8);
      byte b1;
      for (b1 = 0; b1 < i; b1++)
        arrayOfDouble[b1] = (paramPtr2.getDouble(b1 * 8) + paramPtr2.getDouble((i - b1 + -1) * 8) * d) / (1.0D - d * d); 
      for (b1 = 0; b1 < i; b1++)
        paramPtr2.setDouble(b1 * 8, arrayOfDouble[b1]); 
    } 
    for (i = 0; i < paramInt; i++)
      paramPtr2.setDouble(i * 8, Stdlib.atanh(paramPtr2.getDouble(i * 8))); 
  }
  
  public static SEXP pacf1(SEXP paramSEXP1, SEXP paramSEXP2) {
    int i = Rinternals.Rf_asInteger(paramSEXP2);
    paramSEXP1 = Rinternals.Rf_protect(Rinternals.Rf_allocVector(14, i));
    Ptr ptr = Rinternals2.REAL(paramSEXP1);
    uni_pacf(Rinternals2.REAL(Rinternals.Rf_protect(Rinternals.Rf_coerceVector(paramSEXP1, 14))), ptr, i);
    SEXP sEXP = Rinternals.Rf_protect(Rinternals.Rf_allocVector(13, 3));
    Rinternals2.INTEGER(sEXP).setInt(0, i);
    Rinternals2.INTEGER(sEXP).setInt(8, 1);
    Rinternals2.INTEGER(sEXP).setInt(4, Rinternals2.INTEGER(sEXP).getInt(8));
    Rinternals.Rf_setAttrib(paramSEXP1, Rinternals.R_DimSymbol, sEXP);
    return paramSEXP1;
  }
  
  public static void partrans(int paramInt, Ptr paramPtr1, Ptr paramPtr2) {
    double[] arrayOfDouble = new double[100];
    if (paramInt > 100)
      Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("can only transform 100 pars in arima0\000".getBytes(), 0)), new Object[0]); 
    for (byte b2 = 0; b2 < paramInt; b2++) {
      int i = b2 * 8;
      paramPtr2.setDouble(i, Mathlib.tanh(paramPtr1.getDouble(b2 * 8)));
      arrayOfDouble[b2] = paramPtr2.getDouble(i);
    } 
    for (byte b1 = 1; b1 < paramInt; b1++) {
      double d = paramPtr2.getDouble(b1 * 8);
      byte b;
      for (b = 0; b < b1; b++)
        arrayOfDouble[b] = arrayOfDouble[b] - paramPtr2.getDouble((b1 - b + -1) * 8) * d; 
      for (b = 0; b < b1; b++)
        paramPtr2.setDouble(b * 8, arrayOfDouble[b]); 
    } 
  }
  
  public static SEXP set_trans(SEXP paramSEXP1, SEXP paramSEXP2) {
    if (Rinternals.TYPEOF(paramSEXP1) != 22 || Rinternals.R_ExternalPtrTag(paramSEXP1) != Starma_tag)
      Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("bad Starma struct\000".getBytes(), 0)), new Object[0]); 
    VoidPtr.toPtr(Rinternals.R_ExternalPtrAddr(paramSEXP1)).setInt(32, Rinternals.Rf_asInteger(paramSEXP2));
    return Rinternals.R_NilValue;
  }
  
  public static SEXP setup_starma(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4, SEXP paramSEXP5, SEXP paramSEXP6, SEXP paramSEXP7, SEXP paramSEXP8) {
    int n;
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    Ptr ptr2 = Rinternals2.REAL(paramSEXP2);
    Ptr ptr1 = Rinternals2.REAL(paramSEXP4);
    MixedPtr mixedPtr = MixedPtr.malloc(136);
    mixedPtr.setInt(44, Rinternals2.INTEGER(paramSEXP1).getInt());
    mixedPtr.setInt(48, Rinternals2.INTEGER(paramSEXP1).getInt(4));
    mixedPtr.setInt(52, Rinternals2.INTEGER(paramSEXP1).getInt(8));
    mixedPtr.setInt(56, Rinternals2.INTEGER(paramSEXP1).getInt(12));
    mixedPtr.setInt(60, Rinternals2.INTEGER(paramSEXP1).getInt(16));
    int i = Rinternals.Rf_asInteger(paramSEXP3);
    mixedPtr.setInt(20, i);
    mixedPtr.setInt(24, Rinternals.Rf_asInteger(paramSEXP8));
    int j = Rinternals.Rf_asInteger(paramSEXP5);
    mixedPtr.setInt(28, j);
    mixedPtr.setPointer(80, (Ptr)DoublePtr.malloc((mixedPtr.getInt(44) + mixedPtr.getInt(48) + mixedPtr.getInt(52) + mixedPtr.getInt(56) + mixedPtr.getInt(28)) * 8));
    int m = mixedPtr.getInt(60) * mixedPtr.getInt(52) + mixedPtr.getInt(44);
    mixedPtr.setInt(0, m);
    int k = mixedPtr.getInt(60) * mixedPtr.getInt(56) + mixedPtr.getInt(48);
    mixedPtr.setInt(4, k);
    m = Math.max(k + 1, m);
    mixedPtr.setInt(8, m);
    k = (m + 1) * m / 2;
    mixedPtr.setInt(12, k);
    if ((k + -1) * k <= 3) {
      n = 1;
    } else {
      n = (k + -1) * k / 2;
    } 
    mixedPtr.setInt(16, n);
    mixedPtr.setInt(32, Rinternals.Rf_asInteger(paramSEXP7));
    mixedPtr.setPointer(92, (Ptr)DoublePtr.malloc(m * 8));
    mixedPtr.setPointer(96, (Ptr)DoublePtr.malloc(k * 8));
    mixedPtr.setPointer(100, (Ptr)DoublePtr.malloc(k * 8));
    mixedPtr.setPointer(104, (Ptr)DoublePtr.malloc(k * 8));
    mixedPtr.setPointer(108, (Ptr)DoublePtr.malloc(k * 8));
    mixedPtr.setPointer(112, (Ptr)DoublePtr.malloc(k * 8));
    mixedPtr.setPointer(116, (Ptr)DoublePtr.malloc(mixedPtr.getInt(16) * 8));
    mixedPtr.setPointer(120, (Ptr)DoublePtr.malloc(i * 8));
    mixedPtr.setPointer(124, (Ptr)DoublePtr.malloc(i * 8));
    mixedPtr.setPointer(128, (Ptr)DoublePtr.malloc(i * 8));
    mixedPtr.setPointer(84, (Ptr)DoublePtr.malloc(m * 8));
    mixedPtr.setPointer(88, (Ptr)DoublePtr.malloc(m * 8));
    mixedPtr.setPointer(132, (Ptr)DoublePtr.malloc((i * j + 1) * 8));
    mixedPtr.setDouble(64, Rinternals.Rf_asReal(paramSEXP6));
    for (byte b = 0; b < i; b++) {
      k = 0 + b * 8;
      mixedPtr.getPointer(124).setDouble(k, ptr2.getDouble(0 + b * 8));
      mixedPtr.getPointer(120).setDouble(0 + b * 8, mixedPtr.getPointer(124).getDouble(k));
    } 
    for (k = 0; i * j > k; k++)
      mixedPtr.getPointer(132).setDouble(0 + k * 8, ptr1.getDouble(0 + k * 8)); 
    Starma_tag = Rinternals.Rf_install(new BytePtr("STARMA_TAG\000".getBytes(), 0));
    SEXP sEXP2 = Rinternals.R_NilValue;
    SEXP sEXP1 = Starma_tag;
    return Rinternals.R_MakeExternalPtr(mixedPtr.pointerPlus(0), sEXP1, sEXP2);
  }
  
  public static void uni_pacf(Ptr paramPtr1, Ptr paramPtr2, int paramInt) {
    BytePtr.of(0);
    BytePtr.of(0);
    DoublePtr doublePtr1 = DoublePtr.malloc(paramInt * 8);
    DoublePtr doublePtr2 = DoublePtr.malloc(paramInt * 8);
    paramPtr2.setDouble(paramPtr1.getAlignedDouble(1));
    doublePtr2.setDouble(0, paramPtr2.getDouble());
    byte b = 1;
    while (b < paramInt) {
      double d1 = paramPtr1.getDouble((b + 1) * 8);
      double d2 = 1.0D;
      byte b1;
      for (b1 = 0; b1 < b; b1++) {
        d1 -= doublePtr2.getDouble(0 + b1 * 8) * paramPtr1.getDouble((b - b1) * 8);
        d2 -= doublePtr2.getDouble(0 + b1 * 8) * paramPtr1.getDouble((b1 + 1) * 8);
      } 
      d1 /= d2;
      paramPtr2.setDouble(b * 8, d1);
      if (b + 1 != paramInt) {
        doublePtr2.setDouble(0 + b * 8, d1);
        for (b1 = 0; b1 < b; b1++)
          doublePtr1.setDouble(0 + (b - b1 + -1) * 8, doublePtr2.getDouble(0 + b1 * 8)); 
        for (b1 = 0; b1 < b; b1++)
          doublePtr2.setDouble(0 + b1 * 8, doublePtr2.getDouble(0 + b1 * 8) - doublePtr1.getDouble(0 + b1 * 8) * d1); 
        b++;
        continue;
      } 
      break;
    } 
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/stats-0.9.2724.jar!/org/renjin/stats/pacf__.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */