package org.renjin.stats;

import org.renjin.gcc.runtime.BytePtr;
import org.renjin.gcc.runtime.DoublePtr;
import org.renjin.gcc.runtime.MixedPtr;
import org.renjin.gcc.runtime.Ptr;
import org.renjin.gcc.runtime.RecordUnitPtr;
import org.renjin.gcc.runtime.Stdlib;
import org.renjin.gnur.api.Arith;
import org.renjin.gnur.api.Error;
import org.renjin.gnur.api.GetText;
import org.renjin.gnur.api.Rinternals;
import org.renjin.gnur.api.Rinternals2;
import org.renjin.sexp.SEXP;

public class optim__ {
  static {
  
  }
  
  public static double fminfn(int paramInt, Ptr paramPtr1, Ptr paramPtr2) {
    int[] arrayOfInt = new int[1];
    arrayOfInt[0] = 0;
    BytePtr.of(0);
    SEXP sEXP3 = (SEXP)BytePtr.of(0).getArray();
    sEXP3 = Rinternals.Rf_allocVector(14, paramInt);
    Rinternals.Rf_protect(sEXP3);
    if (Rinternals.TYPEOF((SEXP)paramPtr2.getPointer(40).getArray()) != 0) {
      SEXP sEXP = (SEXP)paramPtr2.getPointer(40).getArray();
      Rinternals.Rf_setAttrib(sEXP3, Rinternals.R_NamesSymbol, sEXP);
    } 
    for (byte b = 0; b < paramInt; b++) {
      if (Arith.R_finite(paramPtr1.getDouble(b * 8)) == 0)
        Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("non-finite value supplied by optim\000".getBytes(), 0)), new Object[0]); 
      Rinternals2.REAL(sEXP3).setDouble(0 + b * 8, paramPtr1.getDouble(b * 8) * paramPtr2.getPointer(24).getDouble(0 + b * 8));
    } 
    Rinternals.SETCADR((SEXP)paramPtr2.getPointer(0).getArray(), sEXP3);
    SEXP sEXP1 = (SEXP)paramPtr2.getPointer(8).getArray();
    int i = arrayOfInt[0];
    SEXP sEXP2 = Rinternals.Rf_coerceVector(Rinternals.Rf_eval((SEXP)paramPtr2.getPointer(0).getArray(), sEXP1), 14);
    if (Rinternals.LENGTH(sEXP2) != 1) {
      Object[] arrayOfObject = new Object[1];
      BytePtr bytePtr = GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("objective function in optim evaluates to length %d not 1\000".getBytes(), 0));
      arrayOfObject[0] = Integer.valueOf(Rinternals.LENGTH(sEXP2));
      Error.Rf_error(bytePtr, arrayOfObject);
    } 
    return Rinternals2.REAL(sEXP2).getDouble() / paramPtr2.getDouble(16);
  }
  
  public static void fmingr(int paramInt, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3) {
    int[] arrayOfInt = new int[1];
    arrayOfInt[0] = 0;
    BytePtr.of(0);
    SEXP sEXP3 = (SEXP)BytePtr.of(0).getArray();
    sEXP3 = (SEXP)BytePtr.of(0).getArray();
    if (Rinternals.TYPEOF((SEXP)paramPtr3.getPointer(4).getArray()) == 0) {
      sEXP3 = Rinternals.Rf_allocVector(14, paramInt);
      Rinternals.Rf_protect(sEXP3);
      SEXP sEXP = (SEXP)paramPtr3.getPointer(40).getArray();
      Rinternals.Rf_setAttrib(sEXP3, Rinternals.R_NamesSymbol, sEXP);
      byte b;
      for (b = 0; b < paramInt; b++)
        Rinternals2.REAL(sEXP3).setDouble(0 + b * 8, paramPtr1.getDouble(b * 8) * paramPtr3.getPointer(24).getDouble(0 + b * 8)); 
      Rinternals.SETCADR((SEXP)paramPtr3.getPointer(0).getArray(), sEXP3);
      if (paramPtr3.getInt(28) != 0) {
        for (b = 0; b < paramInt; b++) {
          double d1 = paramPtr3.getPointer(12).getDouble(0 + b * 8);
          double d2 = d1;
          double d3 = paramPtr1.getDouble(b * 8) + d1;
          if (paramPtr3.getPointer(36).getDouble(0 + b * 8) < d3) {
            d3 = paramPtr3.getPointer(36).getDouble(0 + b * 8);
            d2 = d3 - paramPtr1.getDouble(b * 8);
          } 
          Rinternals2.REAL(sEXP3).setDouble(0 + b * 8, paramPtr3.getPointer(24).getDouble(0 + b * 8) * d3);
          SEXP sEXP5 = (SEXP)paramPtr3.getPointer(8).getArray();
          int k = arrayOfInt[0];
          d3 = Rinternals2.REAL(Rinternals.Rf_coerceVector(Rinternals.Rf_eval((SEXP)paramPtr3.getPointer(0).getArray(), sEXP5), 14)).getDouble() / paramPtr3.getDouble(16);
          double d4 = paramPtr1.getDouble(b * 8) - d1;
          if (paramPtr3.getPointer(32).getDouble(0 + b * 8) > d4) {
            d4 = paramPtr3.getPointer(32).getDouble(0 + b * 8);
            d1 = paramPtr1.getDouble(b * 8) - d4;
          } 
          Rinternals2.REAL(sEXP3).setDouble(0 + b * 8, paramPtr3.getPointer(24).getDouble(0 + b * 8) * d4);
          k = arrayOfInt[0];
          SEXP sEXP4 = (SEXP)paramPtr3.getPointer(8).getArray();
          int j = arrayOfInt[0];
          paramPtr2.setDouble(b * 8, (d3 - Rinternals2.REAL(Rinternals.Rf_coerceVector(Rinternals.Rf_eval((SEXP)paramPtr3.getPointer(0).getArray(), sEXP4), 14)).getDouble() / paramPtr3.getDouble(16)) / (d2 + d1));
          if (Arith.R_finite(paramPtr2.getDouble(b * 8)) == 0) {
            Object[] arrayOfObject = new Object[1];
            BytePtr bytePtr = new BytePtr();
            this("non-finite finite-difference value [%d]\000".getBytes(), 0);
            arrayOfObject[0] = Integer.valueOf(b + 1);
            Error.Rf_error(bytePtr, arrayOfObject);
          } 
          Rinternals2.REAL(sEXP3).setDouble(0 + b * 8, paramPtr1.getDouble(b * 8) * paramPtr3.getPointer(24).getDouble(0 + b * 8));
        } 
        return;
      } 
      for (b = 0; b < paramInt; b++) {
        double d = paramPtr3.getPointer(12).getDouble(0 + b * 8);
        Rinternals2.REAL(sEXP3).setDouble(0 + b * 8, (paramPtr1.getDouble(b * 8) + d) * paramPtr3.getPointer(24).getDouble(0 + b * 8));
        SEXP sEXP5 = (SEXP)paramPtr3.getPointer(8).getArray();
        int k = arrayOfInt[0];
        Rinternals2.REAL(sEXP3).setDouble(0 + b * 8, (paramPtr1.getDouble(b * 8) - d) * paramPtr3.getPointer(24).getDouble(0 + b * 8));
        k = arrayOfInt[0];
        SEXP sEXP4 = (SEXP)paramPtr3.getPointer(8).getArray();
        int j = arrayOfInt[0];
        paramPtr2.setDouble(b * 8, (Rinternals2.REAL(Rinternals.Rf_coerceVector(Rinternals.Rf_eval((SEXP)paramPtr3.getPointer(0).getArray(), sEXP5), 14)).getDouble() / paramPtr3.getDouble(16) - Rinternals2.REAL(Rinternals.Rf_coerceVector(Rinternals.Rf_eval((SEXP)paramPtr3.getPointer(0).getArray(), sEXP4), 14)).getDouble() / paramPtr3.getDouble(16)) / d * 2.0D);
        if (Arith.R_finite(paramPtr2.getDouble(b * 8)) == 0) {
          Object[] arrayOfObject = new Object[1];
          BytePtr bytePtr = new BytePtr();
          this("non-finite finite-difference value [%d]\000".getBytes(), 0);
          arrayOfObject[0] = Integer.valueOf(b + 1);
          Error.Rf_error(bytePtr, arrayOfObject);
        } 
        Rinternals2.REAL(sEXP3).setDouble(0 + b * 8, paramPtr1.getDouble(b * 8) * paramPtr3.getPointer(24).getDouble(0 + b * 8));
      } 
      return;
    } 
    sEXP3 = Rinternals.Rf_allocVector(14, paramInt);
    Rinternals.Rf_protect(sEXP3);
    if (Rinternals.TYPEOF((SEXP)paramPtr3.getPointer(40).getArray()) != 0) {
      SEXP sEXP = (SEXP)paramPtr3.getPointer(40).getArray();
      Rinternals.Rf_setAttrib(sEXP3, Rinternals.R_NamesSymbol, sEXP);
    } 
    for (byte b2 = 0; b2 < paramInt; b2++) {
      if (Arith.R_finite(paramPtr1.getDouble(b2 * 8)) == 0)
        Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("non-finite value supplied by optim\000".getBytes(), 0)), new Object[0]); 
      Rinternals2.REAL(sEXP3).setDouble(0 + b2 * 8, paramPtr1.getDouble(b2 * 8) * paramPtr3.getPointer(24).getDouble(0 + b2 * 8));
    } 
    Rinternals.SETCADR((SEXP)paramPtr3.getPointer(4).getArray(), sEXP3);
    SEXP sEXP2 = (SEXP)paramPtr3.getPointer(8).getArray();
    int i = arrayOfInt[0];
    SEXP sEXP1 = Rinternals.Rf_coerceVector(Rinternals.Rf_eval((SEXP)paramPtr3.getPointer(4).getArray(), sEXP2), 14);
    if (Rinternals.LENGTH(sEXP1) != paramInt) {
      BytePtr bytePtr = GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("gradient in optim evaluated to length %d not %d\000".getBytes(), 0));
      Object[] arrayOfObject = new Object[2];
      Integer integer = Integer.valueOf(Rinternals.LENGTH(sEXP1));
      arrayOfObject[0] = integer;
      arrayOfObject[1] = Integer.valueOf(paramInt);
      Error.Rf_error(bytePtr, arrayOfObject);
    } 
    for (byte b1 = 0; b1 < paramInt; b1++)
      paramPtr2.setDouble(b1 * 8, Rinternals2.REAL(sEXP1).getDouble(0 + b1 * 8) * paramPtr3.getPointer(24).getDouble(0 + b1 * 8) / paramPtr3.getDouble(16)); 
  }
  
  public static SEXP getListElement(SEXP paramSEXP, Ptr paramPtr) {
    SEXP sEXP1 = (SEXP)BytePtr.of(0).getArray();
    sEXP1 = (SEXP)BytePtr.of(0).getArray();
    sEXP1 = Rinternals.R_NilValue;
    SEXP sEXP2 = Rinternals.Rf_getAttrib(paramSEXP, Rinternals.R_NamesSymbol);
    byte b = 0;
    while (Rinternals.Rf_length(paramSEXP) > b) {
      if (Stdlib.strcmp((Ptr)Rinternals.R_CHAR(Rinternals.STRING_ELT(sEXP2, b)), paramPtr) != 0) {
        b++;
        continue;
      } 
      sEXP1 = Rinternals.VECTOR_ELT(paramSEXP, b);
      break;
    } 
    return sEXP1;
  }
  
  public static SEXP optim(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4) {
    // Byte code:
    //   0: bipush #60
    //   2: newarray byte
    //   4: astore #4
    //   6: iconst_1
    //   7: newarray int
    //   9: astore #13
    //   11: iconst_1
    //   12: newarray double
    //   14: astore_0
    //   15: iconst_1
    //   16: newarray int
    //   18: astore_1
    //   19: iconst_1
    //   20: newarray int
    //   22: astore #14
    //   24: iconst_1
    //   25: newarray int
    //   27: astore #15
    //   29: iconst_0
    //   30: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   33: pop
    //   34: iconst_0
    //   35: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   38: pop
    //   39: iconst_0
    //   40: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   43: pop
    //   44: iconst_0
    //   45: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   48: invokeinterface getArray : ()Ljava/lang/Object;
    //   53: checkcast org/renjin/sexp/SEXP
    //   56: astore #16
    //   58: iconst_0
    //   59: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   62: invokeinterface getArray : ()Ljava/lang/Object;
    //   67: checkcast org/renjin/sexp/SEXP
    //   70: astore #16
    //   72: iconst_0
    //   73: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   76: invokeinterface getArray : ()Ljava/lang/Object;
    //   81: checkcast org/renjin/sexp/SEXP
    //   84: astore #16
    //   86: aload #13
    //   88: iconst_0
    //   89: iconst_0
    //   90: iastore
    //   91: iconst_0
    //   92: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   95: pop
    //   96: iconst_0
    //   97: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   100: pop
    //   101: aload_0
    //   102: iconst_0
    //   103: dconst_0
    //   104: dastore
    //   105: iconst_0
    //   106: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   109: pop
    //   110: iconst_0
    //   111: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   114: pop
    //   115: aload_1
    //   116: iconst_0
    //   117: iconst_0
    //   118: iastore
    //   119: aload #14
    //   121: iconst_0
    //   122: iconst_0
    //   123: iastore
    //   124: aload #15
    //   126: iconst_0
    //   127: iconst_0
    //   128: iastore
    //   129: iconst_0
    //   130: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   133: pop
    //   134: iconst_0
    //   135: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   138: invokeinterface getArray : ()Ljava/lang/Object;
    //   143: checkcast org/renjin/sexp/SEXP
    //   146: astore #16
    //   148: iconst_0
    //   149: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   152: invokeinterface getArray : ()Ljava/lang/Object;
    //   157: checkcast org/renjin/sexp/SEXP
    //   160: astore #16
    //   162: iconst_0
    //   163: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   166: invokeinterface getArray : ()Ljava/lang/Object;
    //   171: checkcast org/renjin/sexp/SEXP
    //   174: astore #16
    //   176: iconst_0
    //   177: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   180: invokeinterface getArray : ()Ljava/lang/Object;
    //   185: checkcast org/renjin/sexp/SEXP
    //   188: astore #16
    //   190: iconst_0
    //   191: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   194: invokeinterface getArray : ()Ljava/lang/Object;
    //   199: checkcast org/renjin/sexp/SEXP
    //   202: astore #16
    //   204: iconst_0
    //   205: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   208: invokeinterface getArray : ()Ljava/lang/Object;
    //   213: checkcast org/renjin/sexp/SEXP
    //   216: astore #16
    //   218: iconst_0
    //   219: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   222: invokeinterface getArray : ()Ljava/lang/Object;
    //   227: checkcast org/renjin/sexp/SEXP
    //   230: astore #16
    //   232: iconst_0
    //   233: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   236: invokeinterface getArray : ()Ljava/lang/Object;
    //   241: checkcast org/renjin/sexp/SEXP
    //   244: astore #16
    //   246: iconst_0
    //   247: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   250: invokeinterface getArray : ()Ljava/lang/Object;
    //   255: checkcast org/renjin/sexp/SEXP
    //   258: astore #16
    //   260: iconst_0
    //   261: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   264: invokeinterface getArray : ()Ljava/lang/Object;
    //   269: checkcast org/renjin/sexp/SEXP
    //   272: astore #16
    //   274: aload #15
    //   276: iconst_0
    //   277: iconst_0
    //   278: iastore
    //   279: aload #14
    //   281: iconst_0
    //   282: iconst_0
    //   283: iastore
    //   284: aload_1
    //   285: iconst_0
    //   286: iconst_0
    //   287: iastore
    //   288: aload_0
    //   289: iconst_0
    //   290: dconst_0
    //   291: dastore
    //   292: aload_2
    //   293: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   296: dup
    //   297: bipush #44
    //   299: invokestatic malloc : (I)Lorg/renjin/gcc/runtime/MixedPtr;
    //   302: astore_2
    //   303: aload_2
    //   304: bipush #28
    //   306: iconst_0
    //   307: invokeinterface setInt : (II)V
    //   312: aload_2
    //   313: bipush #8
    //   315: new org/renjin/gcc/runtime/RecordUnitPtr
    //   318: dup
    //   319: aload_3
    //   320: invokespecial <init> : (Ljava/lang/Object;)V
    //   323: invokeinterface setPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   328: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   331: astore #16
    //   333: aload_2
    //   334: bipush #40
    //   336: new org/renjin/gcc/runtime/RecordUnitPtr
    //   339: dup
    //   340: aload #16
    //   342: getstatic org/renjin/gnur/api/Rinternals.R_NamesSymbol : Lorg/renjin/sexp/SEXP;
    //   345: invokestatic Rf_getAttrib : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   348: invokespecial <init> : (Ljava/lang/Object;)V
    //   351: invokeinterface setPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   356: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   359: astore #17
    //   361: aload #17
    //   363: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   366: astore_3
    //   367: aload_3
    //   368: invokestatic Rf_isFunction : (Lorg/renjin/sexp/SEXP;)Z
    //   371: ifeq -> 377
    //   374: goto -> 416
    //   377: new org/renjin/gcc/runtime/BytePtr
    //   380: dup
    //   381: ldc 'stats '
    //   383: invokevirtual getBytes : ()[B
    //   386: iconst_0
    //   387: invokespecial <init> : ([BI)V
    //   390: new org/renjin/gcc/runtime/BytePtr
    //   393: dup
    //   394: ldc ''fn' is not a function '
    //   396: invokevirtual getBytes : ()[B
    //   399: iconst_0
    //   400: invokespecial <init> : ([BI)V
    //   403: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
    //   406: checkcast org/renjin/gcc/runtime/BytePtr
    //   409: iconst_0
    //   410: anewarray java/lang/Object
    //   413: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
    //   416: aload #17
    //   418: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   421: dup
    //   422: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   425: astore #18
    //   427: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   430: astore #17
    //   432: aload #17
    //   434: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   437: astore #12
    //   439: aload #12
    //   441: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
    //   444: bipush #16
    //   446: if_icmpne -> 461
    //   449: aload #12
    //   451: invokestatic LENGTH : (Lorg/renjin/sexp/SEXP;)I
    //   454: iconst_1
    //   455: if_icmpne -> 461
    //   458: goto -> 516
    //   461: new org/renjin/gcc/runtime/BytePtr
    //   464: dup
    //   465: ldc 'stats '
    //   467: invokevirtual getBytes : ()[B
    //   470: iconst_0
    //   471: invokespecial <init> : ([BI)V
    //   474: new org/renjin/gcc/runtime/BytePtr
    //   477: dup
    //   478: ldc 'invalid '%s' argument '
    //   480: invokevirtual getBytes : ()[B
    //   483: iconst_0
    //   484: invokespecial <init> : ([BI)V
    //   487: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
    //   490: checkcast org/renjin/gcc/runtime/BytePtr
    //   493: iconst_1
    //   494: anewarray java/lang/Object
    //   497: dup
    //   498: iconst_0
    //   499: new org/renjin/gcc/runtime/BytePtr
    //   502: dup
    //   503: ldc 'method '
    //   505: invokevirtual getBytes : ()[B
    //   508: iconst_0
    //   509: invokespecial <init> : ([BI)V
    //   512: aastore
    //   513: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
    //   516: aload #12
    //   518: iconst_0
    //   519: invokestatic STRING_ELT : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
    //   522: invokestatic R_CHAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/BytePtr;
    //   525: astore #19
    //   527: aload #17
    //   529: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   532: astore #20
    //   534: aload #20
    //   536: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   539: astore #21
    //   541: aload_2
    //   542: iconst_0
    //   543: new org/renjin/gcc/runtime/RecordUnitPtr
    //   546: dup
    //   547: aload_3
    //   548: getstatic org/renjin/gnur/api/Rinternals.R_NilValue : Lorg/renjin/sexp/SEXP;
    //   551: invokestatic Rf_lang2 : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   554: invokespecial <init> : (Ljava/lang/Object;)V
    //   557: invokeinterface setPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   562: aload_2
    //   563: iconst_0
    //   564: invokeinterface getPointer : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   569: invokeinterface getArray : ()Ljava/lang/Object;
    //   574: checkcast org/renjin/sexp/SEXP
    //   577: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   580: pop
    //   581: aload #16
    //   583: bipush #14
    //   585: invokestatic Rf_coerceVector : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
    //   588: astore_3
    //   589: aload_3
    //   590: invokestatic NAMED : (Lorg/renjin/sexp/SEXP;)I
    //   593: ifne -> 599
    //   596: goto -> 610
    //   599: aload #13
    //   601: iconst_0
    //   602: iaload
    //   603: istore #13
    //   605: aload_3
    //   606: invokestatic Rf_duplicate : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   609: astore_3
    //   610: aload_3
    //   611: invokestatic LENGTH : (Lorg/renjin/sexp/SEXP;)I
    //   614: istore #13
    //   616: iload #13
    //   618: invokestatic vect : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   621: astore #16
    //   623: iload #13
    //   625: invokestatic vect : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   628: astore #22
    //   630: aload #21
    //   632: new org/renjin/gcc/runtime/BytePtr
    //   635: dup
    //   636: ldc 'trace '
    //   638: invokevirtual getBytes : ()[B
    //   641: iconst_0
    //   642: invokespecial <init> : ([BI)V
    //   645: checkcast org/renjin/gcc/runtime/Ptr
    //   648: invokestatic getListElement : (Lorg/renjin/sexp/SEXP;Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/sexp/SEXP;
    //   651: invokestatic Rf_asInteger : (Lorg/renjin/sexp/SEXP;)I
    //   654: istore #23
    //   656: aload_2
    //   657: bipush #16
    //   659: aload #21
    //   661: new org/renjin/gcc/runtime/BytePtr
    //   664: dup
    //   665: ldc 'fnscale '
    //   667: invokevirtual getBytes : ()[B
    //   670: iconst_0
    //   671: invokespecial <init> : ([BI)V
    //   674: checkcast org/renjin/gcc/runtime/Ptr
    //   677: invokestatic getListElement : (Lorg/renjin/sexp/SEXP;Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/sexp/SEXP;
    //   680: invokestatic Rf_asReal : (Lorg/renjin/sexp/SEXP;)D
    //   683: invokeinterface setDouble : (ID)V
    //   688: aload #21
    //   690: new org/renjin/gcc/runtime/BytePtr
    //   693: dup
    //   694: ldc 'parscale '
    //   696: invokevirtual getBytes : ()[B
    //   699: iconst_0
    //   700: invokespecial <init> : ([BI)V
    //   703: checkcast org/renjin/gcc/runtime/Ptr
    //   706: invokestatic getListElement : (Lorg/renjin/sexp/SEXP;Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/sexp/SEXP;
    //   709: astore #17
    //   711: aload #17
    //   713: invokestatic LENGTH : (Lorg/renjin/sexp/SEXP;)I
    //   716: iload #13
    //   718: if_icmpne -> 724
    //   721: goto -> 763
    //   724: new org/renjin/gcc/runtime/BytePtr
    //   727: dup
    //   728: ldc 'stats '
    //   730: invokevirtual getBytes : ()[B
    //   733: iconst_0
    //   734: invokespecial <init> : ([BI)V
    //   737: new org/renjin/gcc/runtime/BytePtr
    //   740: dup
    //   741: ldc ''parscale' is of the wrong length '
    //   743: invokevirtual getBytes : ()[B
    //   746: iconst_0
    //   747: invokespecial <init> : ([BI)V
    //   750: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
    //   753: checkcast org/renjin/gcc/runtime/BytePtr
    //   756: iconst_0
    //   757: anewarray java/lang/Object
    //   760: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
    //   763: aload #17
    //   765: bipush #14
    //   767: invokestatic Rf_coerceVector : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
    //   770: astore #17
    //   772: aload #17
    //   774: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   777: pop
    //   778: aload_2
    //   779: bipush #24
    //   781: iload #13
    //   783: invokestatic vect : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   786: invokeinterface setPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   791: iconst_0
    //   792: istore #12
    //   794: goto -> 837
    //   797: aload_2
    //   798: bipush #24
    //   800: invokeinterface getPointer : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   805: iconst_0
    //   806: iload #12
    //   808: bipush #8
    //   810: imul
    //   811: iadd
    //   812: aload #17
    //   814: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
    //   817: iconst_0
    //   818: iload #12
    //   820: bipush #8
    //   822: imul
    //   823: iadd
    //   824: invokeinterface getDouble : (I)D
    //   829: invokeinterface setDouble : (ID)V
    //   834: iinc #12, 1
    //   837: iload #12
    //   839: iload #13
    //   841: if_icmplt -> 797
    //   844: iconst_0
    //   845: istore #17
    //   847: goto -> 904
    //   850: aload #16
    //   852: iconst_0
    //   853: iload #17
    //   855: bipush #8
    //   857: imul
    //   858: iadd
    //   859: aload_3
    //   860: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
    //   863: iconst_0
    //   864: iload #17
    //   866: bipush #8
    //   868: imul
    //   869: iadd
    //   870: invokeinterface getDouble : (I)D
    //   875: aload_2
    //   876: bipush #24
    //   878: invokeinterface getPointer : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   883: iconst_0
    //   884: iload #17
    //   886: bipush #8
    //   888: imul
    //   889: iadd
    //   890: invokeinterface getDouble : (I)D
    //   895: ddiv
    //   896: invokeinterface setDouble : (ID)V
    //   901: iinc #17, 1
    //   904: iload #17
    //   906: iload #13
    //   908: if_icmplt -> 850
    //   911: bipush #19
    //   913: iconst_5
    //   914: invokestatic Rf_allocVector : (II)Lorg/renjin/sexp/SEXP;
    //   917: astore #17
    //   919: aload #17
    //   921: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   924: pop
    //   925: bipush #16
    //   927: iconst_5
    //   928: invokestatic Rf_allocVector : (II)Lorg/renjin/sexp/SEXP;
    //   931: astore #12
    //   933: aload #12
    //   935: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   938: pop
    //   939: aload #12
    //   941: iconst_0
    //   942: new org/renjin/gcc/runtime/BytePtr
    //   945: dup
    //   946: ldc 'par '
    //   948: invokevirtual getBytes : ()[B
    //   951: iconst_0
    //   952: invokespecial <init> : ([BI)V
    //   955: checkcast org/renjin/gcc/runtime/Ptr
    //   958: invokestatic Rf_mkChar : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/sexp/SEXP;
    //   961: invokestatic SET_STRING_ELT : (Lorg/renjin/sexp/SEXP;ILorg/renjin/sexp/SEXP;)V
    //   964: aload #12
    //   966: iconst_1
    //   967: new org/renjin/gcc/runtime/BytePtr
    //   970: dup
    //   971: ldc 'value '
    //   973: invokevirtual getBytes : ()[B
    //   976: iconst_0
    //   977: invokespecial <init> : ([BI)V
    //   980: checkcast org/renjin/gcc/runtime/Ptr
    //   983: invokestatic Rf_mkChar : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/sexp/SEXP;
    //   986: invokestatic SET_STRING_ELT : (Lorg/renjin/sexp/SEXP;ILorg/renjin/sexp/SEXP;)V
    //   989: aload #12
    //   991: iconst_2
    //   992: new org/renjin/gcc/runtime/BytePtr
    //   995: dup
    //   996: ldc 'counts '
    //   998: invokevirtual getBytes : ()[B
    //   1001: iconst_0
    //   1002: invokespecial <init> : ([BI)V
    //   1005: checkcast org/renjin/gcc/runtime/Ptr
    //   1008: invokestatic Rf_mkChar : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/sexp/SEXP;
    //   1011: invokestatic SET_STRING_ELT : (Lorg/renjin/sexp/SEXP;ILorg/renjin/sexp/SEXP;)V
    //   1014: aload #12
    //   1016: iconst_3
    //   1017: new org/renjin/gcc/runtime/BytePtr
    //   1020: dup
    //   1021: ldc 'convergence '
    //   1023: invokevirtual getBytes : ()[B
    //   1026: iconst_0
    //   1027: invokespecial <init> : ([BI)V
    //   1030: checkcast org/renjin/gcc/runtime/Ptr
    //   1033: invokestatic Rf_mkChar : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/sexp/SEXP;
    //   1036: invokestatic SET_STRING_ELT : (Lorg/renjin/sexp/SEXP;ILorg/renjin/sexp/SEXP;)V
    //   1039: aload #12
    //   1041: iconst_4
    //   1042: new org/renjin/gcc/runtime/BytePtr
    //   1045: dup
    //   1046: ldc 'message '
    //   1048: invokevirtual getBytes : ()[B
    //   1051: iconst_0
    //   1052: invokespecial <init> : ([BI)V
    //   1055: checkcast org/renjin/gcc/runtime/Ptr
    //   1058: invokestatic Rf_mkChar : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/sexp/SEXP;
    //   1061: invokestatic SET_STRING_ELT : (Lorg/renjin/sexp/SEXP;ILorg/renjin/sexp/SEXP;)V
    //   1064: aload #17
    //   1066: getstatic org/renjin/gnur/api/Rinternals.R_NamesSymbol : Lorg/renjin/sexp/SEXP;
    //   1069: aload #12
    //   1071: invokestatic Rf_setAttrib : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1074: pop
    //   1075: bipush #14
    //   1077: iconst_1
    //   1078: invokestatic Rf_allocVector : (II)Lorg/renjin/sexp/SEXP;
    //   1081: astore #12
    //   1083: aload #12
    //   1085: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1088: pop
    //   1089: bipush #13
    //   1091: iconst_2
    //   1092: invokestatic Rf_allocVector : (II)Lorg/renjin/sexp/SEXP;
    //   1095: astore #24
    //   1097: aload #24
    //   1099: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1102: pop
    //   1103: bipush #16
    //   1105: iconst_2
    //   1106: invokestatic Rf_allocVector : (II)Lorg/renjin/sexp/SEXP;
    //   1109: astore #11
    //   1111: aload #11
    //   1113: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1116: pop
    //   1117: aload #11
    //   1119: iconst_0
    //   1120: new org/renjin/gcc/runtime/BytePtr
    //   1123: dup
    //   1124: ldc 'function '
    //   1126: invokevirtual getBytes : ()[B
    //   1129: iconst_0
    //   1130: invokespecial <init> : ([BI)V
    //   1133: checkcast org/renjin/gcc/runtime/Ptr
    //   1136: invokestatic Rf_mkChar : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/sexp/SEXP;
    //   1139: invokestatic SET_STRING_ELT : (Lorg/renjin/sexp/SEXP;ILorg/renjin/sexp/SEXP;)V
    //   1142: aload #11
    //   1144: iconst_1
    //   1145: new org/renjin/gcc/runtime/BytePtr
    //   1148: dup
    //   1149: ldc 'gradient '
    //   1151: invokevirtual getBytes : ()[B
    //   1154: iconst_0
    //   1155: invokespecial <init> : ([BI)V
    //   1158: checkcast org/renjin/gcc/runtime/Ptr
    //   1161: invokestatic Rf_mkChar : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/sexp/SEXP;
    //   1164: invokestatic SET_STRING_ELT : (Lorg/renjin/sexp/SEXP;ILorg/renjin/sexp/SEXP;)V
    //   1167: aload #24
    //   1169: getstatic org/renjin/gnur/api/Rinternals.R_NamesSymbol : Lorg/renjin/sexp/SEXP;
    //   1172: aload #11
    //   1174: invokestatic Rf_setAttrib : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1177: pop
    //   1178: bipush #13
    //   1180: iconst_1
    //   1181: invokestatic Rf_allocVector : (II)Lorg/renjin/sexp/SEXP;
    //   1184: astore #11
    //   1186: aload #11
    //   1188: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1191: pop
    //   1192: aload #21
    //   1194: new org/renjin/gcc/runtime/BytePtr
    //   1197: dup
    //   1198: ldc 'abstol '
    //   1200: invokevirtual getBytes : ()[B
    //   1203: iconst_0
    //   1204: invokespecial <init> : ([BI)V
    //   1207: checkcast org/renjin/gcc/runtime/Ptr
    //   1210: invokestatic getListElement : (Lorg/renjin/sexp/SEXP;Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/sexp/SEXP;
    //   1213: invokestatic Rf_asReal : (Lorg/renjin/sexp/SEXP;)D
    //   1216: dstore #25
    //   1218: aload #21
    //   1220: new org/renjin/gcc/runtime/BytePtr
    //   1223: dup
    //   1224: ldc 'reltol '
    //   1226: invokevirtual getBytes : ()[B
    //   1229: iconst_0
    //   1230: invokespecial <init> : ([BI)V
    //   1233: checkcast org/renjin/gcc/runtime/Ptr
    //   1236: invokestatic getListElement : (Lorg/renjin/sexp/SEXP;Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/sexp/SEXP;
    //   1239: invokestatic Rf_asReal : (Lorg/renjin/sexp/SEXP;)D
    //   1242: dstore #27
    //   1244: aload #21
    //   1246: new org/renjin/gcc/runtime/BytePtr
    //   1249: dup
    //   1250: ldc_w 'maxit '
    //   1253: invokevirtual getBytes : ()[B
    //   1256: iconst_0
    //   1257: invokespecial <init> : ([BI)V
    //   1260: checkcast org/renjin/gcc/runtime/Ptr
    //   1263: invokestatic getListElement : (Lorg/renjin/sexp/SEXP;Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/sexp/SEXP;
    //   1266: invokestatic Rf_asInteger : (Lorg/renjin/sexp/SEXP;)I
    //   1269: istore #29
    //   1271: iload #29
    //   1273: getstatic org/renjin/gnur/api/Arith.R_NaInt : I
    //   1276: if_icmpeq -> 1282
    //   1279: goto -> 1322
    //   1282: new org/renjin/gcc/runtime/BytePtr
    //   1285: dup
    //   1286: ldc 'stats '
    //   1288: invokevirtual getBytes : ()[B
    //   1291: iconst_0
    //   1292: invokespecial <init> : ([BI)V
    //   1295: new org/renjin/gcc/runtime/BytePtr
    //   1298: dup
    //   1299: ldc_w ''maxit' is not an integer '
    //   1302: invokevirtual getBytes : ()[B
    //   1305: iconst_0
    //   1306: invokespecial <init> : ([BI)V
    //   1309: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
    //   1312: checkcast org/renjin/gcc/runtime/BytePtr
    //   1315: iconst_0
    //   1316: anewarray java/lang/Object
    //   1319: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
    //   1322: aload #19
    //   1324: iconst_0
    //   1325: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   1330: new org/renjin/gcc/runtime/BytePtr
    //   1333: dup
    //   1334: ldc_w 'Nelder-Mead '
    //   1337: invokevirtual getBytes : ()[B
    //   1340: iconst_0
    //   1341: invokespecial <init> : ([BI)V
    //   1344: checkcast org/renjin/gcc/runtime/Ptr
    //   1347: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
    //   1350: ifeq -> 1356
    //   1353: goto -> 1596
    //   1356: iload #13
    //   1358: aload #21
    //   1360: new org/renjin/gcc/runtime/BytePtr
    //   1363: dup
    //   1364: ldc_w 'alpha '
    //   1367: invokevirtual getBytes : ()[B
    //   1370: iconst_0
    //   1371: invokespecial <init> : ([BI)V
    //   1374: checkcast org/renjin/gcc/runtime/Ptr
    //   1377: invokestatic getListElement : (Lorg/renjin/sexp/SEXP;Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/sexp/SEXP;
    //   1380: invokestatic Rf_asReal : (Lorg/renjin/sexp/SEXP;)D
    //   1383: dstore #9
    //   1385: aload #21
    //   1387: new org/renjin/gcc/runtime/BytePtr
    //   1390: dup
    //   1391: ldc_w 'beta '
    //   1394: invokevirtual getBytes : ()[B
    //   1397: iconst_0
    //   1398: invokespecial <init> : ([BI)V
    //   1401: checkcast org/renjin/gcc/runtime/Ptr
    //   1404: invokestatic getListElement : (Lorg/renjin/sexp/SEXP;Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/sexp/SEXP;
    //   1407: invokestatic Rf_asReal : (Lorg/renjin/sexp/SEXP;)D
    //   1410: dstore #7
    //   1412: aload #21
    //   1414: new org/renjin/gcc/runtime/BytePtr
    //   1417: dup
    //   1418: ldc_w 'gamma '
    //   1421: invokevirtual getBytes : ()[B
    //   1424: iconst_0
    //   1425: invokespecial <init> : ([BI)V
    //   1428: checkcast org/renjin/gcc/runtime/Ptr
    //   1431: invokestatic getListElement : (Lorg/renjin/sexp/SEXP;Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/sexp/SEXP;
    //   1434: invokestatic Rf_asReal : (Lorg/renjin/sexp/SEXP;)D
    //   1437: dstore #5
    //   1439: aload #16
    //   1441: iconst_0
    //   1442: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   1447: aload #22
    //   1449: iconst_0
    //   1450: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   1455: new org/renjin/gcc/runtime/DoublePtr
    //   1458: dup
    //   1459: aload_0
    //   1460: iconst_0
    //   1461: invokespecial <init> : ([DI)V
    //   1464: checkcast org/renjin/gcc/runtime/Ptr
    //   1467: ldc_w
    //   1470: new org/renjin/gcc/runtime/IntPtr
    //   1473: dup
    //   1474: aload_1
    //   1475: iconst_0
    //   1476: invokespecial <init> : ([II)V
    //   1479: checkcast org/renjin/gcc/runtime/Ptr
    //   1482: dload #25
    //   1484: dload #27
    //   1486: aload_2
    //   1487: iconst_0
    //   1488: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   1493: dload #9
    //   1495: dload #7
    //   1497: dload #5
    //   1499: iload #23
    //   1501: new org/renjin/gcc/runtime/IntPtr
    //   1504: dup
    //   1505: aload #15
    //   1507: iconst_0
    //   1508: invokespecial <init> : ([II)V
    //   1511: checkcast org/renjin/gcc/runtime/Ptr
    //   1514: iload #29
    //   1516: invokestatic nmmin : (ILorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Ljava/lang/invoke/MethodHandle;Lorg/renjin/gcc/runtime/Ptr;DDLorg/renjin/gcc/runtime/Ptr;DDDILorg/renjin/gcc/runtime/Ptr;I)V
    //   1519: iconst_0
    //   1520: istore #4
    //   1522: goto -> 1579
    //   1525: aload_3
    //   1526: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
    //   1529: iconst_0
    //   1530: iload #4
    //   1532: bipush #8
    //   1534: imul
    //   1535: iadd
    //   1536: aload #22
    //   1538: iconst_0
    //   1539: iload #4
    //   1541: bipush #8
    //   1543: imul
    //   1544: iadd
    //   1545: invokeinterface getDouble : (I)D
    //   1550: aload_2
    //   1551: bipush #24
    //   1553: invokeinterface getPointer : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   1558: iconst_0
    //   1559: iload #4
    //   1561: bipush #8
    //   1563: imul
    //   1564: iadd
    //   1565: invokeinterface getDouble : (I)D
    //   1570: dmul
    //   1571: invokeinterface setDouble : (ID)V
    //   1576: iinc #4, 1
    //   1579: iload #4
    //   1581: iload #13
    //   1583: if_icmplt -> 1525
    //   1586: aload #14
    //   1588: iconst_0
    //   1589: getstatic org/renjin/gnur/api/Arith.R_NaInt : I
    //   1592: iastore
    //   1593: goto -> 4192
    //   1596: aload #19
    //   1598: iconst_0
    //   1599: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   1604: new org/renjin/gcc/runtime/BytePtr
    //   1607: dup
    //   1608: ldc_w 'SANN '
    //   1611: invokevirtual getBytes : ()[B
    //   1614: iconst_0
    //   1615: invokespecial <init> : ([BI)V
    //   1618: checkcast org/renjin/gcc/runtime/Ptr
    //   1621: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
    //   1624: ifeq -> 1630
    //   1627: goto -> 2061
    //   1630: aload #21
    //   1632: new org/renjin/gcc/runtime/BytePtr
    //   1635: dup
    //   1636: ldc_w 'tmax '
    //   1639: invokevirtual getBytes : ()[B
    //   1642: iconst_0
    //   1643: invokespecial <init> : ([BI)V
    //   1646: checkcast org/renjin/gcc/runtime/Ptr
    //   1649: invokestatic getListElement : (Lorg/renjin/sexp/SEXP;Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/sexp/SEXP;
    //   1652: invokestatic Rf_asInteger : (Lorg/renjin/sexp/SEXP;)I
    //   1655: istore #4
    //   1657: aload #21
    //   1659: new org/renjin/gcc/runtime/BytePtr
    //   1662: dup
    //   1663: ldc_w 'temp '
    //   1666: invokevirtual getBytes : ()[B
    //   1669: iconst_0
    //   1670: invokespecial <init> : ([BI)V
    //   1673: checkcast org/renjin/gcc/runtime/Ptr
    //   1676: invokestatic getListElement : (Lorg/renjin/sexp/SEXP;Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/sexp/SEXP;
    //   1679: invokestatic Rf_asReal : (Lorg/renjin/sexp/SEXP;)D
    //   1682: dstore #5
    //   1684: iload #23
    //   1686: ifne -> 1692
    //   1689: goto -> 1719
    //   1692: aload #21
    //   1694: new org/renjin/gcc/runtime/BytePtr
    //   1697: dup
    //   1698: ldc_w 'REPORT '
    //   1701: invokevirtual getBytes : ()[B
    //   1704: iconst_0
    //   1705: invokespecial <init> : ([BI)V
    //   1708: checkcast org/renjin/gcc/runtime/Ptr
    //   1711: invokestatic getListElement : (Lorg/renjin/sexp/SEXP;Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/sexp/SEXP;
    //   1714: invokestatic Rf_asInteger : (Lorg/renjin/sexp/SEXP;)I
    //   1717: istore #23
    //   1719: iload #4
    //   1721: getstatic org/renjin/gnur/api/Arith.R_NaInt : I
    //   1724: if_icmpeq -> 1735
    //   1727: iload #4
    //   1729: ifle -> 1735
    //   1732: goto -> 1775
    //   1735: new org/renjin/gcc/runtime/BytePtr
    //   1738: dup
    //   1739: ldc 'stats '
    //   1741: invokevirtual getBytes : ()[B
    //   1744: iconst_0
    //   1745: invokespecial <init> : ([BI)V
    //   1748: new org/renjin/gcc/runtime/BytePtr
    //   1751: dup
    //   1752: ldc_w ''tmax' is not a positive integer '
    //   1755: invokevirtual getBytes : ()[B
    //   1758: iconst_0
    //   1759: invokespecial <init> : ([BI)V
    //   1762: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
    //   1765: checkcast org/renjin/gcc/runtime/BytePtr
    //   1768: iconst_0
    //   1769: anewarray java/lang/Object
    //   1772: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
    //   1775: aload #18
    //   1777: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
    //   1780: ifne -> 1786
    //   1783: goto -> 1881
    //   1786: aload #18
    //   1788: invokestatic Rf_isFunction : (Lorg/renjin/sexp/SEXP;)Z
    //   1791: ifeq -> 1797
    //   1794: goto -> 1837
    //   1797: new org/renjin/gcc/runtime/BytePtr
    //   1800: dup
    //   1801: ldc 'stats '
    //   1803: invokevirtual getBytes : ()[B
    //   1806: iconst_0
    //   1807: invokespecial <init> : ([BI)V
    //   1810: new org/renjin/gcc/runtime/BytePtr
    //   1813: dup
    //   1814: ldc_w ''gr' is not a function '
    //   1817: invokevirtual getBytes : ()[B
    //   1820: iconst_0
    //   1821: invokespecial <init> : ([BI)V
    //   1824: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
    //   1827: checkcast org/renjin/gcc/runtime/BytePtr
    //   1830: iconst_0
    //   1831: anewarray java/lang/Object
    //   1834: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
    //   1837: aload_2
    //   1838: iconst_4
    //   1839: new org/renjin/gcc/runtime/RecordUnitPtr
    //   1842: dup
    //   1843: aload #18
    //   1845: getstatic org/renjin/gnur/api/Rinternals.R_NilValue : Lorg/renjin/sexp/SEXP;
    //   1848: invokestatic Rf_lang2 : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1851: invokespecial <init> : (Ljava/lang/Object;)V
    //   1854: invokeinterface setPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1859: aload_2
    //   1860: iconst_4
    //   1861: invokeinterface getPointer : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   1866: invokeinterface getArray : ()Ljava/lang/Object;
    //   1871: checkcast org/renjin/sexp/SEXP
    //   1874: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1877: pop
    //   1878: goto -> 1917
    //   1881: aload_2
    //   1882: iconst_4
    //   1883: new org/renjin/gcc/runtime/RecordUnitPtr
    //   1886: dup
    //   1887: getstatic org/renjin/gnur/api/Rinternals.R_NilValue : Lorg/renjin/sexp/SEXP;
    //   1890: invokespecial <init> : (Ljava/lang/Object;)V
    //   1893: invokeinterface setPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1898: aload_2
    //   1899: iconst_4
    //   1900: invokeinterface getPointer : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   1905: invokeinterface getArray : ()Ljava/lang/Object;
    //   1910: checkcast org/renjin/sexp/SEXP
    //   1913: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   1916: pop
    //   1917: iload #13
    //   1919: aload #16
    //   1921: iconst_0
    //   1922: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   1927: new org/renjin/gcc/runtime/DoublePtr
    //   1930: dup
    //   1931: aload_0
    //   1932: iconst_0
    //   1933: invokespecial <init> : ([DI)V
    //   1936: checkcast org/renjin/gcc/runtime/Ptr
    //   1939: ldc_w
    //   1942: iload #29
    //   1944: iload #4
    //   1946: dload #5
    //   1948: iload #23
    //   1950: aload_2
    //   1951: iconst_0
    //   1952: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   1957: invokestatic samin : (ILorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Ljava/lang/invoke/MethodHandle;IIDILorg/renjin/gcc/runtime/Ptr;)V
    //   1960: iconst_0
    //   1961: istore #4
    //   1963: goto -> 2020
    //   1966: aload_3
    //   1967: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
    //   1970: iconst_0
    //   1971: iload #4
    //   1973: bipush #8
    //   1975: imul
    //   1976: iadd
    //   1977: aload #16
    //   1979: iconst_0
    //   1980: iload #4
    //   1982: bipush #8
    //   1984: imul
    //   1985: iadd
    //   1986: invokeinterface getDouble : (I)D
    //   1991: aload_2
    //   1992: bipush #24
    //   1994: invokeinterface getPointer : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   1999: iconst_0
    //   2000: iload #4
    //   2002: bipush #8
    //   2004: imul
    //   2005: iadd
    //   2006: invokeinterface getDouble : (I)D
    //   2011: dmul
    //   2012: invokeinterface setDouble : (ID)V
    //   2017: iinc #4, 1
    //   2020: iload #4
    //   2022: iload #13
    //   2024: if_icmplt -> 1966
    //   2027: iload #13
    //   2029: ifgt -> 2035
    //   2032: goto -> 2042
    //   2035: iload #29
    //   2037: istore #4
    //   2039: goto -> 2045
    //   2042: iconst_1
    //   2043: istore #4
    //   2045: aload #15
    //   2047: iconst_0
    //   2048: iload #4
    //   2050: iastore
    //   2051: aload #14
    //   2053: iconst_0
    //   2054: getstatic org/renjin/gnur/api/Arith.R_NaInt : I
    //   2057: iastore
    //   2058: goto -> 4192
    //   2061: aload #19
    //   2063: iconst_0
    //   2064: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   2069: new org/renjin/gcc/runtime/BytePtr
    //   2072: dup
    //   2073: ldc_w 'BFGS '
    //   2076: invokevirtual getBytes : ()[B
    //   2079: iconst_0
    //   2080: invokespecial <init> : ([BI)V
    //   2083: checkcast org/renjin/gcc/runtime/Ptr
    //   2086: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
    //   2089: ifeq -> 2095
    //   2092: goto -> 2625
    //   2095: aload #21
    //   2097: new org/renjin/gcc/runtime/BytePtr
    //   2100: dup
    //   2101: ldc_w 'REPORT '
    //   2104: invokevirtual getBytes : ()[B
    //   2107: iconst_0
    //   2108: invokespecial <init> : ([BI)V
    //   2111: checkcast org/renjin/gcc/runtime/Ptr
    //   2114: invokestatic getListElement : (Lorg/renjin/sexp/SEXP;Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/sexp/SEXP;
    //   2117: invokestatic Rf_asInteger : (Lorg/renjin/sexp/SEXP;)I
    //   2120: istore #4
    //   2122: aload #18
    //   2124: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
    //   2127: ifne -> 2133
    //   2130: goto -> 2228
    //   2133: aload #18
    //   2135: invokestatic Rf_isFunction : (Lorg/renjin/sexp/SEXP;)Z
    //   2138: ifeq -> 2144
    //   2141: goto -> 2184
    //   2144: new org/renjin/gcc/runtime/BytePtr
    //   2147: dup
    //   2148: ldc 'stats '
    //   2150: invokevirtual getBytes : ()[B
    //   2153: iconst_0
    //   2154: invokespecial <init> : ([BI)V
    //   2157: new org/renjin/gcc/runtime/BytePtr
    //   2160: dup
    //   2161: ldc_w ''gr' is not a function '
    //   2164: invokevirtual getBytes : ()[B
    //   2167: iconst_0
    //   2168: invokespecial <init> : ([BI)V
    //   2171: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
    //   2174: checkcast org/renjin/gcc/runtime/BytePtr
    //   2177: iconst_0
    //   2178: anewarray java/lang/Object
    //   2181: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
    //   2184: aload_2
    //   2185: iconst_4
    //   2186: new org/renjin/gcc/runtime/RecordUnitPtr
    //   2189: dup
    //   2190: aload #18
    //   2192: getstatic org/renjin/gnur/api/Rinternals.R_NilValue : Lorg/renjin/sexp/SEXP;
    //   2195: invokestatic Rf_lang2 : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   2198: invokespecial <init> : (Ljava/lang/Object;)V
    //   2201: invokeinterface setPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2206: aload_2
    //   2207: iconst_4
    //   2208: invokeinterface getPointer : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   2213: invokeinterface getArray : ()Ljava/lang/Object;
    //   2218: checkcast org/renjin/sexp/SEXP
    //   2221: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   2224: pop
    //   2225: goto -> 2422
    //   2228: aload_2
    //   2229: iconst_4
    //   2230: new org/renjin/gcc/runtime/RecordUnitPtr
    //   2233: dup
    //   2234: getstatic org/renjin/gnur/api/Rinternals.R_NilValue : Lorg/renjin/sexp/SEXP;
    //   2237: invokespecial <init> : (Ljava/lang/Object;)V
    //   2240: invokeinterface setPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2245: aload_2
    //   2246: iconst_4
    //   2247: invokeinterface getPointer : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   2252: invokeinterface getArray : ()Ljava/lang/Object;
    //   2257: checkcast org/renjin/sexp/SEXP
    //   2260: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   2263: pop
    //   2264: aload #21
    //   2266: new org/renjin/gcc/runtime/BytePtr
    //   2269: dup
    //   2270: ldc_w 'ndeps '
    //   2273: invokevirtual getBytes : ()[B
    //   2276: iconst_0
    //   2277: invokespecial <init> : ([BI)V
    //   2280: checkcast org/renjin/gcc/runtime/Ptr
    //   2283: invokestatic getListElement : (Lorg/renjin/sexp/SEXP;Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/sexp/SEXP;
    //   2286: astore #18
    //   2288: aload #18
    //   2290: invokestatic LENGTH : (Lorg/renjin/sexp/SEXP;)I
    //   2293: iload #13
    //   2295: if_icmpne -> 2301
    //   2298: goto -> 2341
    //   2301: new org/renjin/gcc/runtime/BytePtr
    //   2304: dup
    //   2305: ldc 'stats '
    //   2307: invokevirtual getBytes : ()[B
    //   2310: iconst_0
    //   2311: invokespecial <init> : ([BI)V
    //   2314: new org/renjin/gcc/runtime/BytePtr
    //   2317: dup
    //   2318: ldc_w ''ndeps' is of the wrong length '
    //   2321: invokevirtual getBytes : ()[B
    //   2324: iconst_0
    //   2325: invokespecial <init> : ([BI)V
    //   2328: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
    //   2331: checkcast org/renjin/gcc/runtime/BytePtr
    //   2334: iconst_0
    //   2335: anewarray java/lang/Object
    //   2338: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
    //   2341: aload_2
    //   2342: bipush #12
    //   2344: iload #13
    //   2346: invokestatic vect : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   2349: invokeinterface setPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2354: aload #18
    //   2356: bipush #14
    //   2358: invokestatic Rf_coerceVector : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
    //   2361: astore #18
    //   2363: aload #18
    //   2365: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   2368: pop
    //   2369: iconst_0
    //   2370: istore #20
    //   2372: goto -> 2415
    //   2375: aload_2
    //   2376: bipush #12
    //   2378: invokeinterface getPointer : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   2383: iconst_0
    //   2384: iload #20
    //   2386: bipush #8
    //   2388: imul
    //   2389: iadd
    //   2390: aload #18
    //   2392: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
    //   2395: iconst_0
    //   2396: iload #20
    //   2398: bipush #8
    //   2400: imul
    //   2401: iadd
    //   2402: invokeinterface getDouble : (I)D
    //   2407: invokeinterface setDouble : (ID)V
    //   2412: iinc #20, 1
    //   2415: iload #20
    //   2417: iload #13
    //   2419: if_icmplt -> 2375
    //   2422: iload #13
    //   2424: iconst_4
    //   2425: imul
    //   2426: invokestatic malloc : (I)Lorg/renjin/gcc/runtime/IntPtr;
    //   2429: astore #18
    //   2431: iconst_0
    //   2432: istore #20
    //   2434: goto -> 2454
    //   2437: aload #18
    //   2439: iconst_0
    //   2440: iload #20
    //   2442: iconst_4
    //   2443: imul
    //   2444: iadd
    //   2445: iconst_1
    //   2446: invokeinterface setInt : (II)V
    //   2451: iinc #20, 1
    //   2454: iload #20
    //   2456: iload #13
    //   2458: if_icmplt -> 2437
    //   2461: iload #13
    //   2463: aload #16
    //   2465: iconst_0
    //   2466: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   2471: new org/renjin/gcc/runtime/DoublePtr
    //   2474: dup
    //   2475: aload_0
    //   2476: iconst_0
    //   2477: invokespecial <init> : ([DI)V
    //   2480: checkcast org/renjin/gcc/runtime/Ptr
    //   2483: ldc_w
    //   2486: ldc_w
    //   2489: iload #29
    //   2491: iload #23
    //   2493: aload #18
    //   2495: iconst_0
    //   2496: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   2501: dload #25
    //   2503: dload #27
    //   2505: iload #4
    //   2507: aload_2
    //   2508: iconst_0
    //   2509: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   2514: new org/renjin/gcc/runtime/IntPtr
    //   2517: dup
    //   2518: aload #15
    //   2520: iconst_0
    //   2521: invokespecial <init> : ([II)V
    //   2524: checkcast org/renjin/gcc/runtime/Ptr
    //   2527: new org/renjin/gcc/runtime/IntPtr
    //   2530: dup
    //   2531: aload #14
    //   2533: iconst_0
    //   2534: invokespecial <init> : ([II)V
    //   2537: checkcast org/renjin/gcc/runtime/Ptr
    //   2540: new org/renjin/gcc/runtime/IntPtr
    //   2543: dup
    //   2544: aload_1
    //   2545: iconst_0
    //   2546: invokespecial <init> : ([II)V
    //   2549: checkcast org/renjin/gcc/runtime/Ptr
    //   2552: invokestatic vmmin : (ILorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodHandle;IILorg/renjin/gcc/runtime/Ptr;DDILorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)V
    //   2555: iconst_0
    //   2556: istore #4
    //   2558: goto -> 2615
    //   2561: aload_3
    //   2562: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
    //   2565: iconst_0
    //   2566: iload #4
    //   2568: bipush #8
    //   2570: imul
    //   2571: iadd
    //   2572: aload #16
    //   2574: iconst_0
    //   2575: iload #4
    //   2577: bipush #8
    //   2579: imul
    //   2580: iadd
    //   2581: invokeinterface getDouble : (I)D
    //   2586: aload_2
    //   2587: bipush #24
    //   2589: invokeinterface getPointer : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   2594: iconst_0
    //   2595: iload #4
    //   2597: bipush #8
    //   2599: imul
    //   2600: iadd
    //   2601: invokeinterface getDouble : (I)D
    //   2606: dmul
    //   2607: invokeinterface setDouble : (ID)V
    //   2612: iinc #4, 1
    //   2615: iload #4
    //   2617: iload #13
    //   2619: if_icmplt -> 2561
    //   2622: goto -> 4192
    //   2625: aload #19
    //   2627: iconst_0
    //   2628: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   2633: new org/renjin/gcc/runtime/BytePtr
    //   2636: dup
    //   2637: ldc_w 'CG '
    //   2640: invokevirtual getBytes : ()[B
    //   2643: iconst_0
    //   2644: invokespecial <init> : ([BI)V
    //   2647: checkcast org/renjin/gcc/runtime/Ptr
    //   2650: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
    //   2653: ifeq -> 2659
    //   2656: goto -> 3150
    //   2659: aload #21
    //   2661: new org/renjin/gcc/runtime/BytePtr
    //   2664: dup
    //   2665: ldc_w 'type '
    //   2668: invokevirtual getBytes : ()[B
    //   2671: iconst_0
    //   2672: invokespecial <init> : ([BI)V
    //   2675: checkcast org/renjin/gcc/runtime/Ptr
    //   2678: invokestatic getListElement : (Lorg/renjin/sexp/SEXP;Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/sexp/SEXP;
    //   2681: invokestatic Rf_asInteger : (Lorg/renjin/sexp/SEXP;)I
    //   2684: istore #4
    //   2686: aload #18
    //   2688: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
    //   2691: ifne -> 2697
    //   2694: goto -> 2792
    //   2697: aload #18
    //   2699: invokestatic Rf_isFunction : (Lorg/renjin/sexp/SEXP;)Z
    //   2702: ifeq -> 2708
    //   2705: goto -> 2748
    //   2708: new org/renjin/gcc/runtime/BytePtr
    //   2711: dup
    //   2712: ldc 'stats '
    //   2714: invokevirtual getBytes : ()[B
    //   2717: iconst_0
    //   2718: invokespecial <init> : ([BI)V
    //   2721: new org/renjin/gcc/runtime/BytePtr
    //   2724: dup
    //   2725: ldc_w ''gr' is not a function '
    //   2728: invokevirtual getBytes : ()[B
    //   2731: iconst_0
    //   2732: invokespecial <init> : ([BI)V
    //   2735: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
    //   2738: checkcast org/renjin/gcc/runtime/BytePtr
    //   2741: iconst_0
    //   2742: anewarray java/lang/Object
    //   2745: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
    //   2748: aload_2
    //   2749: iconst_4
    //   2750: new org/renjin/gcc/runtime/RecordUnitPtr
    //   2753: dup
    //   2754: aload #18
    //   2756: getstatic org/renjin/gnur/api/Rinternals.R_NilValue : Lorg/renjin/sexp/SEXP;
    //   2759: invokestatic Rf_lang2 : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   2762: invokespecial <init> : (Ljava/lang/Object;)V
    //   2765: invokeinterface setPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2770: aload_2
    //   2771: iconst_4
    //   2772: invokeinterface getPointer : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   2777: invokeinterface getArray : ()Ljava/lang/Object;
    //   2782: checkcast org/renjin/sexp/SEXP
    //   2785: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   2788: pop
    //   2789: goto -> 2986
    //   2792: aload_2
    //   2793: iconst_4
    //   2794: new org/renjin/gcc/runtime/RecordUnitPtr
    //   2797: dup
    //   2798: getstatic org/renjin/gnur/api/Rinternals.R_NilValue : Lorg/renjin/sexp/SEXP;
    //   2801: invokespecial <init> : (Ljava/lang/Object;)V
    //   2804: invokeinterface setPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2809: aload_2
    //   2810: iconst_4
    //   2811: invokeinterface getPointer : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   2816: invokeinterface getArray : ()Ljava/lang/Object;
    //   2821: checkcast org/renjin/sexp/SEXP
    //   2824: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   2827: pop
    //   2828: aload #21
    //   2830: new org/renjin/gcc/runtime/BytePtr
    //   2833: dup
    //   2834: ldc_w 'ndeps '
    //   2837: invokevirtual getBytes : ()[B
    //   2840: iconst_0
    //   2841: invokespecial <init> : ([BI)V
    //   2844: checkcast org/renjin/gcc/runtime/Ptr
    //   2847: invokestatic getListElement : (Lorg/renjin/sexp/SEXP;Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/sexp/SEXP;
    //   2850: astore #18
    //   2852: aload #18
    //   2854: invokestatic LENGTH : (Lorg/renjin/sexp/SEXP;)I
    //   2857: iload #13
    //   2859: if_icmpne -> 2865
    //   2862: goto -> 2905
    //   2865: new org/renjin/gcc/runtime/BytePtr
    //   2868: dup
    //   2869: ldc 'stats '
    //   2871: invokevirtual getBytes : ()[B
    //   2874: iconst_0
    //   2875: invokespecial <init> : ([BI)V
    //   2878: new org/renjin/gcc/runtime/BytePtr
    //   2881: dup
    //   2882: ldc_w ''ndeps' is of the wrong length '
    //   2885: invokevirtual getBytes : ()[B
    //   2888: iconst_0
    //   2889: invokespecial <init> : ([BI)V
    //   2892: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
    //   2895: checkcast org/renjin/gcc/runtime/BytePtr
    //   2898: iconst_0
    //   2899: anewarray java/lang/Object
    //   2902: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
    //   2905: aload_2
    //   2906: bipush #12
    //   2908: iload #13
    //   2910: invokestatic vect : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   2913: invokeinterface setPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2918: aload #18
    //   2920: bipush #14
    //   2922: invokestatic Rf_coerceVector : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
    //   2925: astore #18
    //   2927: aload #18
    //   2929: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   2932: pop
    //   2933: iconst_0
    //   2934: istore #20
    //   2936: goto -> 2979
    //   2939: aload_2
    //   2940: bipush #12
    //   2942: invokeinterface getPointer : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   2947: iconst_0
    //   2948: iload #20
    //   2950: bipush #8
    //   2952: imul
    //   2953: iadd
    //   2954: aload #18
    //   2956: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
    //   2959: iconst_0
    //   2960: iload #20
    //   2962: bipush #8
    //   2964: imul
    //   2965: iadd
    //   2966: invokeinterface getDouble : (I)D
    //   2971: invokeinterface setDouble : (ID)V
    //   2976: iinc #20, 1
    //   2979: iload #20
    //   2981: iload #13
    //   2983: if_icmplt -> 2939
    //   2986: iload #13
    //   2988: aload #16
    //   2990: iconst_0
    //   2991: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   2996: aload #22
    //   2998: iconst_0
    //   2999: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   3004: new org/renjin/gcc/runtime/DoublePtr
    //   3007: dup
    //   3008: aload_0
    //   3009: iconst_0
    //   3010: invokespecial <init> : ([DI)V
    //   3013: checkcast org/renjin/gcc/runtime/Ptr
    //   3016: ldc_w
    //   3019: ldc_w
    //   3022: new org/renjin/gcc/runtime/IntPtr
    //   3025: dup
    //   3026: aload_1
    //   3027: iconst_0
    //   3028: invokespecial <init> : ([II)V
    //   3031: checkcast org/renjin/gcc/runtime/Ptr
    //   3034: dload #25
    //   3036: dload #27
    //   3038: aload_2
    //   3039: iconst_0
    //   3040: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   3045: iload #4
    //   3047: iload #23
    //   3049: new org/renjin/gcc/runtime/IntPtr
    //   3052: dup
    //   3053: aload #15
    //   3055: iconst_0
    //   3056: invokespecial <init> : ([II)V
    //   3059: checkcast org/renjin/gcc/runtime/Ptr
    //   3062: new org/renjin/gcc/runtime/IntPtr
    //   3065: dup
    //   3066: aload #14
    //   3068: iconst_0
    //   3069: invokespecial <init> : ([II)V
    //   3072: checkcast org/renjin/gcc/runtime/Ptr
    //   3075: iload #29
    //   3077: invokestatic cgmin : (ILorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodHandle;Lorg/renjin/gcc/runtime/Ptr;DDLorg/renjin/gcc/runtime/Ptr;IILorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;I)V
    //   3080: iconst_0
    //   3081: istore #4
    //   3083: goto -> 3140
    //   3086: aload_3
    //   3087: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
    //   3090: iconst_0
    //   3091: iload #4
    //   3093: bipush #8
    //   3095: imul
    //   3096: iadd
    //   3097: aload #22
    //   3099: iconst_0
    //   3100: iload #4
    //   3102: bipush #8
    //   3104: imul
    //   3105: iadd
    //   3106: invokeinterface getDouble : (I)D
    //   3111: aload_2
    //   3112: bipush #24
    //   3114: invokeinterface getPointer : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   3119: iconst_0
    //   3120: iload #4
    //   3122: bipush #8
    //   3124: imul
    //   3125: iadd
    //   3126: invokeinterface getDouble : (I)D
    //   3131: dmul
    //   3132: invokeinterface setDouble : (ID)V
    //   3137: iinc #4, 1
    //   3140: iload #4
    //   3142: iload #13
    //   3144: if_icmplt -> 3086
    //   3147: goto -> 4192
    //   3150: aload #19
    //   3152: iconst_0
    //   3153: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   3158: new org/renjin/gcc/runtime/BytePtr
    //   3161: dup
    //   3162: ldc_w 'L-BFGS-B '
    //   3165: invokevirtual getBytes : ()[B
    //   3168: iconst_0
    //   3169: invokespecial <init> : ([BI)V
    //   3172: checkcast org/renjin/gcc/runtime/Ptr
    //   3175: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
    //   3178: ifeq -> 3184
    //   3181: goto -> 4152
    //   3184: iload #13
    //   3186: invokestatic vect : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   3189: astore #22
    //   3191: iload #13
    //   3193: invokestatic vect : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   3196: astore #19
    //   3198: iload #13
    //   3200: iconst_4
    //   3201: imul
    //   3202: invokestatic malloc : (I)Lorg/renjin/gcc/runtime/IntPtr;
    //   3205: astore #30
    //   3207: aload #21
    //   3209: new org/renjin/gcc/runtime/BytePtr
    //   3212: dup
    //   3213: ldc_w 'REPORT '
    //   3216: invokevirtual getBytes : ()[B
    //   3219: iconst_0
    //   3220: invokespecial <init> : ([BI)V
    //   3223: checkcast org/renjin/gcc/runtime/Ptr
    //   3226: invokestatic getListElement : (Lorg/renjin/sexp/SEXP;Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/sexp/SEXP;
    //   3229: invokestatic Rf_asInteger : (Lorg/renjin/sexp/SEXP;)I
    //   3232: istore #31
    //   3234: aload #21
    //   3236: new org/renjin/gcc/runtime/BytePtr
    //   3239: dup
    //   3240: ldc_w 'factr '
    //   3243: invokevirtual getBytes : ()[B
    //   3246: iconst_0
    //   3247: invokespecial <init> : ([BI)V
    //   3250: checkcast org/renjin/gcc/runtime/Ptr
    //   3253: invokestatic getListElement : (Lorg/renjin/sexp/SEXP;Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/sexp/SEXP;
    //   3256: invokestatic Rf_asReal : (Lorg/renjin/sexp/SEXP;)D
    //   3259: dstore #5
    //   3261: aload #21
    //   3263: new org/renjin/gcc/runtime/BytePtr
    //   3266: dup
    //   3267: ldc_w 'pgtol '
    //   3270: invokevirtual getBytes : ()[B
    //   3273: iconst_0
    //   3274: invokespecial <init> : ([BI)V
    //   3277: checkcast org/renjin/gcc/runtime/Ptr
    //   3280: invokestatic getListElement : (Lorg/renjin/sexp/SEXP;Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/sexp/SEXP;
    //   3283: invokestatic Rf_asReal : (Lorg/renjin/sexp/SEXP;)D
    //   3286: dstore #7
    //   3288: aload #21
    //   3290: new org/renjin/gcc/runtime/BytePtr
    //   3293: dup
    //   3294: ldc_w 'lmm '
    //   3297: invokevirtual getBytes : ()[B
    //   3300: iconst_0
    //   3301: invokespecial <init> : ([BI)V
    //   3304: checkcast org/renjin/gcc/runtime/Ptr
    //   3307: invokestatic getListElement : (Lorg/renjin/sexp/SEXP;Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/sexp/SEXP;
    //   3310: invokestatic Rf_asInteger : (Lorg/renjin/sexp/SEXP;)I
    //   3313: istore #32
    //   3315: aload #18
    //   3317: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
    //   3320: ifne -> 3326
    //   3323: goto -> 3421
    //   3326: aload #18
    //   3328: invokestatic Rf_isFunction : (Lorg/renjin/sexp/SEXP;)Z
    //   3331: ifeq -> 3337
    //   3334: goto -> 3377
    //   3337: new org/renjin/gcc/runtime/BytePtr
    //   3340: dup
    //   3341: ldc 'stats '
    //   3343: invokevirtual getBytes : ()[B
    //   3346: iconst_0
    //   3347: invokespecial <init> : ([BI)V
    //   3350: new org/renjin/gcc/runtime/BytePtr
    //   3353: dup
    //   3354: ldc_w ''gr' is not a function '
    //   3357: invokevirtual getBytes : ()[B
    //   3360: iconst_0
    //   3361: invokespecial <init> : ([BI)V
    //   3364: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
    //   3367: checkcast org/renjin/gcc/runtime/BytePtr
    //   3370: iconst_0
    //   3371: anewarray java/lang/Object
    //   3374: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
    //   3377: aload_2
    //   3378: iconst_4
    //   3379: new org/renjin/gcc/runtime/RecordUnitPtr
    //   3382: dup
    //   3383: aload #18
    //   3385: getstatic org/renjin/gnur/api/Rinternals.R_NilValue : Lorg/renjin/sexp/SEXP;
    //   3388: invokestatic Rf_lang2 : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   3391: invokespecial <init> : (Ljava/lang/Object;)V
    //   3394: invokeinterface setPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   3399: aload_2
    //   3400: iconst_4
    //   3401: invokeinterface getPointer : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   3406: invokeinterface getArray : ()Ljava/lang/Object;
    //   3411: checkcast org/renjin/sexp/SEXP
    //   3414: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   3417: pop
    //   3418: goto -> 3615
    //   3421: aload_2
    //   3422: iconst_4
    //   3423: new org/renjin/gcc/runtime/RecordUnitPtr
    //   3426: dup
    //   3427: getstatic org/renjin/gnur/api/Rinternals.R_NilValue : Lorg/renjin/sexp/SEXP;
    //   3430: invokespecial <init> : (Ljava/lang/Object;)V
    //   3433: invokeinterface setPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   3438: aload_2
    //   3439: iconst_4
    //   3440: invokeinterface getPointer : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   3445: invokeinterface getArray : ()Ljava/lang/Object;
    //   3450: checkcast org/renjin/sexp/SEXP
    //   3453: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   3456: pop
    //   3457: aload #21
    //   3459: new org/renjin/gcc/runtime/BytePtr
    //   3462: dup
    //   3463: ldc_w 'ndeps '
    //   3466: invokevirtual getBytes : ()[B
    //   3469: iconst_0
    //   3470: invokespecial <init> : ([BI)V
    //   3473: checkcast org/renjin/gcc/runtime/Ptr
    //   3476: invokestatic getListElement : (Lorg/renjin/sexp/SEXP;Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/sexp/SEXP;
    //   3479: astore #18
    //   3481: aload #18
    //   3483: invokestatic LENGTH : (Lorg/renjin/sexp/SEXP;)I
    //   3486: iload #13
    //   3488: if_icmpne -> 3494
    //   3491: goto -> 3534
    //   3494: new org/renjin/gcc/runtime/BytePtr
    //   3497: dup
    //   3498: ldc 'stats '
    //   3500: invokevirtual getBytes : ()[B
    //   3503: iconst_0
    //   3504: invokespecial <init> : ([BI)V
    //   3507: new org/renjin/gcc/runtime/BytePtr
    //   3510: dup
    //   3511: ldc_w ''ndeps' is of the wrong length '
    //   3514: invokevirtual getBytes : ()[B
    //   3517: iconst_0
    //   3518: invokespecial <init> : ([BI)V
    //   3521: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
    //   3524: checkcast org/renjin/gcc/runtime/BytePtr
    //   3527: iconst_0
    //   3528: anewarray java/lang/Object
    //   3531: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
    //   3534: aload_2
    //   3535: bipush #12
    //   3537: iload #13
    //   3539: invokestatic vect : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   3542: invokeinterface setPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   3547: aload #18
    //   3549: bipush #14
    //   3551: invokestatic Rf_coerceVector : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
    //   3554: astore #18
    //   3556: aload #18
    //   3558: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   3561: pop
    //   3562: iconst_0
    //   3563: istore #21
    //   3565: goto -> 3608
    //   3568: aload_2
    //   3569: bipush #12
    //   3571: invokeinterface getPointer : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   3576: iconst_0
    //   3577: iload #21
    //   3579: bipush #8
    //   3581: imul
    //   3582: iadd
    //   3583: aload #18
    //   3585: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
    //   3588: iconst_0
    //   3589: iload #21
    //   3591: bipush #8
    //   3593: imul
    //   3594: iadd
    //   3595: invokeinterface getDouble : (I)D
    //   3600: invokeinterface setDouble : (ID)V
    //   3605: iinc #21, 1
    //   3608: iload #21
    //   3610: iload #13
    //   3612: if_icmplt -> 3568
    //   3615: aload #20
    //   3617: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   3620: dup
    //   3621: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   3624: astore #18
    //   3626: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   3629: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   3632: astore #20
    //   3634: iconst_0
    //   3635: istore #21
    //   3637: goto -> 3881
    //   3640: aload #22
    //   3642: iconst_0
    //   3643: iload #21
    //   3645: bipush #8
    //   3647: imul
    //   3648: iadd
    //   3649: aload #18
    //   3651: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
    //   3654: iconst_0
    //   3655: iload #21
    //   3657: bipush #8
    //   3659: imul
    //   3660: iadd
    //   3661: invokeinterface getDouble : (I)D
    //   3666: aload_2
    //   3667: bipush #24
    //   3669: invokeinterface getPointer : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   3674: iconst_0
    //   3675: iload #21
    //   3677: bipush #8
    //   3679: imul
    //   3680: iadd
    //   3681: invokeinterface getDouble : (I)D
    //   3686: ddiv
    //   3687: invokeinterface setDouble : (ID)V
    //   3692: aload #19
    //   3694: iconst_0
    //   3695: iload #21
    //   3697: bipush #8
    //   3699: imul
    //   3700: iadd
    //   3701: aload #20
    //   3703: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
    //   3706: iconst_0
    //   3707: iload #21
    //   3709: bipush #8
    //   3711: imul
    //   3712: iadd
    //   3713: invokeinterface getDouble : (I)D
    //   3718: aload_2
    //   3719: bipush #24
    //   3721: invokeinterface getPointer : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   3726: iconst_0
    //   3727: iload #21
    //   3729: bipush #8
    //   3731: imul
    //   3732: iadd
    //   3733: invokeinterface getDouble : (I)D
    //   3738: ddiv
    //   3739: invokeinterface setDouble : (ID)V
    //   3744: aload #22
    //   3746: iconst_0
    //   3747: iload #21
    //   3749: bipush #8
    //   3751: imul
    //   3752: iadd
    //   3753: invokeinterface getDouble : (I)D
    //   3758: invokestatic R_finite : (D)I
    //   3761: ifeq -> 3767
    //   3764: goto -> 3824
    //   3767: aload #19
    //   3769: iconst_0
    //   3770: iload #21
    //   3772: bipush #8
    //   3774: imul
    //   3775: iadd
    //   3776: invokeinterface getDouble : (I)D
    //   3781: invokestatic R_finite : (D)I
    //   3784: ifeq -> 3790
    //   3787: goto -> 3807
    //   3790: aload #30
    //   3792: iconst_0
    //   3793: iload #21
    //   3795: iconst_4
    //   3796: imul
    //   3797: iadd
    //   3798: iconst_0
    //   3799: invokeinterface setInt : (II)V
    //   3804: goto -> 3878
    //   3807: aload #30
    //   3809: iconst_0
    //   3810: iload #21
    //   3812: iconst_4
    //   3813: imul
    //   3814: iadd
    //   3815: iconst_3
    //   3816: invokeinterface setInt : (II)V
    //   3821: goto -> 3878
    //   3824: aload #19
    //   3826: iconst_0
    //   3827: iload #21
    //   3829: bipush #8
    //   3831: imul
    //   3832: iadd
    //   3833: invokeinterface getDouble : (I)D
    //   3838: invokestatic R_finite : (D)I
    //   3841: ifeq -> 3847
    //   3844: goto -> 3864
    //   3847: aload #30
    //   3849: iconst_0
    //   3850: iload #21
    //   3852: iconst_4
    //   3853: imul
    //   3854: iadd
    //   3855: iconst_1
    //   3856: invokeinterface setInt : (II)V
    //   3861: goto -> 3878
    //   3864: aload #30
    //   3866: iconst_0
    //   3867: iload #21
    //   3869: iconst_4
    //   3870: imul
    //   3871: iadd
    //   3872: iconst_2
    //   3873: invokeinterface setInt : (II)V
    //   3878: iinc #21, 1
    //   3881: iload #21
    //   3883: iload #13
    //   3885: if_icmplt -> 3640
    //   3888: aload_2
    //   3889: bipush #28
    //   3891: iconst_1
    //   3892: invokeinterface setInt : (II)V
    //   3897: aload_2
    //   3898: bipush #32
    //   3900: aload #22
    //   3902: iconst_0
    //   3903: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   3908: invokeinterface setPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   3913: aload_2
    //   3914: bipush #36
    //   3916: aload #19
    //   3918: iconst_0
    //   3919: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   3924: invokeinterface setPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   3929: iload #13
    //   3931: iload #32
    //   3933: aload #16
    //   3935: iconst_0
    //   3936: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   3941: aload #22
    //   3943: iconst_0
    //   3944: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   3949: aload #19
    //   3951: iconst_0
    //   3952: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   3957: aload #30
    //   3959: iconst_0
    //   3960: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   3965: new org/renjin/gcc/runtime/DoublePtr
    //   3968: dup
    //   3969: aload_0
    //   3970: iconst_0
    //   3971: invokespecial <init> : ([DI)V
    //   3974: checkcast org/renjin/gcc/runtime/Ptr
    //   3977: ldc_w
    //   3980: ldc_w
    //   3983: new org/renjin/gcc/runtime/IntPtr
    //   3986: dup
    //   3987: aload_1
    //   3988: iconst_0
    //   3989: invokespecial <init> : ([II)V
    //   3992: checkcast org/renjin/gcc/runtime/Ptr
    //   3995: aload_2
    //   3996: iconst_0
    //   3997: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   4002: dload #5
    //   4004: dload #7
    //   4006: new org/renjin/gcc/runtime/IntPtr
    //   4009: dup
    //   4010: aload #15
    //   4012: iconst_0
    //   4013: invokespecial <init> : ([II)V
    //   4016: checkcast org/renjin/gcc/runtime/Ptr
    //   4019: new org/renjin/gcc/runtime/IntPtr
    //   4022: dup
    //   4023: aload #14
    //   4025: iconst_0
    //   4026: invokespecial <init> : ([II)V
    //   4029: checkcast org/renjin/gcc/runtime/Ptr
    //   4032: iload #29
    //   4034: new org/renjin/gcc/runtime/BytePtr
    //   4037: dup
    //   4038: aload #4
    //   4040: iconst_0
    //   4041: invokespecial <init> : ([BI)V
    //   4044: checkcast org/renjin/gcc/runtime/Ptr
    //   4047: iload #23
    //   4049: iload #31
    //   4051: invokestatic lbfgsb : (IILorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodHandle;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;DDLorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;ILorg/renjin/gcc/runtime/Ptr;II)V
    //   4054: iconst_0
    //   4055: istore #23
    //   4057: goto -> 4114
    //   4060: aload_3
    //   4061: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
    //   4064: iconst_0
    //   4065: iload #23
    //   4067: bipush #8
    //   4069: imul
    //   4070: iadd
    //   4071: aload #16
    //   4073: iconst_0
    //   4074: iload #23
    //   4076: bipush #8
    //   4078: imul
    //   4079: iadd
    //   4080: invokeinterface getDouble : (I)D
    //   4085: aload_2
    //   4086: bipush #24
    //   4088: invokeinterface getPointer : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   4093: iconst_0
    //   4094: iload #23
    //   4096: bipush #8
    //   4098: imul
    //   4099: iadd
    //   4100: invokeinterface getDouble : (I)D
    //   4105: dmul
    //   4106: invokeinterface setDouble : (ID)V
    //   4111: iinc #23, 1
    //   4114: iload #23
    //   4116: iload #13
    //   4118: if_icmplt -> 4060
    //   4121: aload #17
    //   4123: iconst_4
    //   4124: new org/renjin/gcc/runtime/BytePtr
    //   4127: dup
    //   4128: aload #4
    //   4130: iconst_0
    //   4131: invokespecial <init> : ([BI)V
    //   4134: checkcast org/renjin/gcc/runtime/Ptr
    //   4137: invokestatic Rf_mkString : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/sexp/SEXP;
    //   4140: dup
    //   4141: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   4144: pop
    //   4145: invokestatic SET_VECTOR_ELT : (Lorg/renjin/sexp/SEXP;ILorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   4148: pop
    //   4149: goto -> 4192
    //   4152: new org/renjin/gcc/runtime/BytePtr
    //   4155: dup
    //   4156: ldc 'stats '
    //   4158: invokevirtual getBytes : ()[B
    //   4161: iconst_0
    //   4162: invokespecial <init> : ([BI)V
    //   4165: new org/renjin/gcc/runtime/BytePtr
    //   4168: dup
    //   4169: ldc_w 'unknown 'method' '
    //   4172: invokevirtual getBytes : ()[B
    //   4175: iconst_0
    //   4176: invokespecial <init> : ([BI)V
    //   4179: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
    //   4182: checkcast org/renjin/gcc/runtime/BytePtr
    //   4185: iconst_0
    //   4186: anewarray java/lang/Object
    //   4189: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
    //   4192: aload_2
    //   4193: bipush #40
    //   4195: invokeinterface getPointer : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   4200: invokeinterface getArray : ()Ljava/lang/Object;
    //   4205: checkcast org/renjin/sexp/SEXP
    //   4208: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
    //   4211: ifne -> 4217
    //   4214: goto -> 4245
    //   4217: aload_3
    //   4218: aload_2
    //   4219: bipush #40
    //   4221: invokeinterface getPointer : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   4226: invokeinterface getArray : ()Ljava/lang/Object;
    //   4231: checkcast org/renjin/sexp/SEXP
    //   4234: astore #4
    //   4236: getstatic org/renjin/gnur/api/Rinternals.R_NamesSymbol : Lorg/renjin/sexp/SEXP;
    //   4239: aload #4
    //   4241: invokestatic Rf_setAttrib : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   4244: pop
    //   4245: aload #12
    //   4247: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
    //   4250: iconst_0
    //   4251: aload_2
    //   4252: bipush #16
    //   4254: invokeinterface getDouble : (I)D
    //   4259: aload_0
    //   4260: iconst_0
    //   4261: daload
    //   4262: dmul
    //   4263: invokeinterface setDouble : (ID)V
    //   4268: aload #17
    //   4270: iconst_0
    //   4271: aload_3
    //   4272: invokestatic SET_VECTOR_ELT : (Lorg/renjin/sexp/SEXP;ILorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   4275: pop
    //   4276: aload #17
    //   4278: iconst_1
    //   4279: aload #12
    //   4281: invokestatic SET_VECTOR_ELT : (Lorg/renjin/sexp/SEXP;ILorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   4284: pop
    //   4285: aload #24
    //   4287: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
    //   4290: iconst_0
    //   4291: aload #15
    //   4293: iconst_0
    //   4294: iaload
    //   4295: invokeinterface setInt : (II)V
    //   4300: aload #24
    //   4302: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
    //   4305: iconst_4
    //   4306: aload #14
    //   4308: iconst_0
    //   4309: iaload
    //   4310: invokeinterface setInt : (II)V
    //   4315: aload #17
    //   4317: iconst_2
    //   4318: aload #24
    //   4320: invokestatic SET_VECTOR_ELT : (Lorg/renjin/sexp/SEXP;ILorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   4323: pop
    //   4324: aload #11
    //   4326: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
    //   4329: iconst_0
    //   4330: aload_1
    //   4331: iconst_0
    //   4332: iaload
    //   4333: invokeinterface setInt : (II)V
    //   4338: aload #17
    //   4340: iconst_3
    //   4341: aload #11
    //   4343: invokestatic SET_VECTOR_ELT : (Lorg/renjin/sexp/SEXP;ILorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   4346: pop
    //   4347: aload #17
    //   4349: areturn
  }
  
  public static SEXP optimhess(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4) {
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    paramSEXP1 = (SEXP)BytePtr.of(0).getArray();
    paramSEXP1 = (SEXP)BytePtr.of(0).getArray();
    paramSEXP1 = (SEXP)BytePtr.of(0).getArray();
    paramSEXP1 = (SEXP)BytePtr.of(0).getArray();
    paramSEXP1 = (SEXP)BytePtr.of(0).getArray();
    paramSEXP1 = (SEXP)BytePtr.of(0).getArray();
    paramSEXP1 = (SEXP)BytePtr.of(0).getArray();
    MixedPtr mixedPtr = MixedPtr.malloc(44);
    mixedPtr.setInt(28, 0);
    mixedPtr.setPointer(8, (Ptr)new RecordUnitPtr(paramSEXP4));
    paramSEXP3 = Rinternals.CAR(Rinternals.CDR(paramSEXP3));
    int i = Rinternals.LENGTH(paramSEXP3);
    mixedPtr.setPointer(40, (Ptr)new RecordUnitPtr(Rinternals.Rf_getAttrib(paramSEXP3, Rinternals.R_NamesSymbol)));
    SEXP sEXP2 = Rinternals.CDR(Rinternals.CDR(paramSEXP3));
    paramSEXP4 = Rinternals.CAR(sEXP2);
    if (!Rinternals.Rf_isFunction(paramSEXP4))
      Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("'fn' is not a function\000".getBytes(), 0)), new Object[0]); 
    sEXP2 = Rinternals.CAR(Rinternals.CDR(sEXP2));
    SEXP sEXP3 = Rinternals.CAR(Rinternals.CDR(Rinternals.CDR(sEXP2)));
    mixedPtr.setDouble(16, Rinternals.Rf_asReal(getListElement(sEXP3, (Ptr)new BytePtr("fnscale\000".getBytes(), 0))));
    SEXP sEXP4 = getListElement(sEXP3, (Ptr)new BytePtr("parscale\000".getBytes(), 0));
    if (Rinternals.LENGTH(sEXP4) != i)
      Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("'parscale' is of the wrong length\000".getBytes(), 0)), new Object[0]); 
    sEXP4 = Rinternals.Rf_coerceVector(sEXP4, 14);
    Rinternals.Rf_protect(sEXP4);
    mixedPtr.setPointer(24, vect(i));
    byte b4;
    for (b4 = 0; b4 < i; b4++)
      mixedPtr.getPointer(24).setDouble(0 + b4 * 8, Rinternals2.REAL(sEXP4).getDouble(0 + b4 * 8)); 
    mixedPtr.setPointer(0, (Ptr)new RecordUnitPtr(Rinternals.Rf_lang2(paramSEXP4, Rinternals.R_NilValue)));
    Rinternals.Rf_protect((SEXP)mixedPtr.getPointer(0).getArray());
    paramSEXP3 = Rinternals.Rf_coerceVector(paramSEXP3, 14);
    Rinternals.Rf_protect(paramSEXP3);
    if (Rinternals.TYPEOF(sEXP2) == 0) {
      mixedPtr.setPointer(4, (Ptr)new RecordUnitPtr(Rinternals.R_NilValue));
      Rinternals.Rf_protect((SEXP)mixedPtr.getPointer(4).getArray());
    } else {
      if (!Rinternals.Rf_isFunction(sEXP2))
        Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("'gr' is not a function\000".getBytes(), 0)), new Object[0]); 
      mixedPtr.setPointer(4, (Ptr)new RecordUnitPtr(Rinternals.Rf_lang2(sEXP2, Rinternals.R_NilValue)));
      Rinternals.Rf_protect((SEXP)mixedPtr.getPointer(4).getArray());
    } 
    paramSEXP4 = getListElement(sEXP3, (Ptr)new BytePtr("ndeps\000".getBytes(), 0));
    if (Rinternals.LENGTH(paramSEXP4) != i)
      Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("'ndeps' is of the wrong length\000".getBytes(), 0)), new Object[0]); 
    mixedPtr.setPointer(12, vect(i));
    paramSEXP4 = Rinternals.Rf_coerceVector(paramSEXP4, 14);
    Rinternals.Rf_protect(paramSEXP4);
    for (byte b2 = 0; b2 < i; b2++)
      mixedPtr.getPointer(12).setDouble(0 + b2 * 8, Rinternals2.REAL(paramSEXP4).getDouble(0 + b2 * 8)); 
    paramSEXP4 = Rinternals.Rf_allocMatrix(14, i, i);
    Rinternals.Rf_protect(paramSEXP4);
    Ptr ptr1 = vect(i);
    for (byte b3 = 0; b3 < i; b3++)
      ptr1.setDouble(0 + b3 * 8, Rinternals2.REAL(paramSEXP3).getDouble(0 + b3 * 8) / mixedPtr.getPointer(24).getDouble(0 + b3 * 8)); 
    Ptr ptr2 = vect(i);
    Ptr ptr3 = vect(i);
    for (b4 = 0; b4 < i; b4++) {
      double d = mixedPtr.getPointer(12).getDouble(0 + b4 * 8) / mixedPtr.getPointer(24).getDouble(0 + b4 * 8);
      ptr1.setDouble(0 + b4 * 8, ptr1.getDouble(0 + b4 * 8) + d);
      fmingr(i, ptr1.pointerPlus(0), ptr2.pointerPlus(0), mixedPtr.pointerPlus(0));
      ptr1.setDouble(0 + b4 * 8, ptr1.getDouble(0 + b4 * 8) - d * 2.0D);
      fmingr(i, ptr1.pointerPlus(0), ptr3.pointerPlus(0), mixedPtr.pointerPlus(0));
      for (byte b = 0; b < i; b++)
        Rinternals2.REAL(paramSEXP4).setDouble(0 + (b4 * i + b) * 8, mixedPtr.getDouble(16) * (ptr2.getDouble(0 + b * 8) - ptr3.getDouble(0 + b * 8)) / d * 2.0D * mixedPtr.getPointer(24).getDouble(0 + b4 * 8) * mixedPtr.getPointer(24).getDouble(0 + b * 8)); 
      ptr1.setDouble(0 + b4 * 8, ptr1.getDouble(0 + b4 * 8) + d);
    } 
    for (byte b1 = 0; b1 < i; b1++) {
      for (byte b = 0; b < b1; b++) {
        double d = (Rinternals2.REAL(paramSEXP4).getDouble(0 + (b1 * i + b) * 8) + Rinternals2.REAL(paramSEXP4).getDouble(0 + (b * i + b1) * 8)) * 0.5D;
        int j = 0 + (b * i + b1) * 8;
        Rinternals2.REAL(paramSEXP4).setDouble(j, d);
        Rinternals2.REAL(paramSEXP4).setDouble(0 + (b1 * i + b) * 8, Rinternals2.REAL(paramSEXP4).getDouble(j));
      } 
    } 
    SEXP sEXP1 = Rinternals.Rf_getAttrib(paramSEXP3, Rinternals.R_NamesSymbol);
    if (Rinternals.TYPEOF(sEXP1) != 0) {
      SEXP sEXP = Rinternals.Rf_allocVector(19, 2);
      Rinternals.Rf_protect(sEXP);
      Rinternals.SET_VECTOR_ELT(sEXP, 0, Rinternals.Rf_duplicate(sEXP1));
      Rinternals.SET_VECTOR_ELT(sEXP, 1, Rinternals.Rf_duplicate(sEXP1));
      Rinternals.Rf_setAttrib(paramSEXP4, Rinternals.R_DimNamesSymbol, sEXP);
    } 
    return paramSEXP4;
  }
  
  public static Ptr vect(int paramInt) {
    return (Ptr)DoublePtr.malloc(paramInt * 8);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/stats-0.9.2724.jar!/org/renjin/stats/optim__.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */