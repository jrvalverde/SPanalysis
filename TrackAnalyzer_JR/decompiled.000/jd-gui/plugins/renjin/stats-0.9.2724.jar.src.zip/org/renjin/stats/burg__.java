package org.renjin.stats;

import org.renjin.gcc.runtime.BytePtr;
import org.renjin.gcc.runtime.DoublePtr;
import org.renjin.gcc.runtime.Ptr;
import org.renjin.gnur.api.Rinternals;
import org.renjin.gnur.api.Rinternals2;
import org.renjin.sexp.SEXP;

public class burg__ {
  static {
  
  }
  
  public static SEXP Burg(SEXP paramSEXP1, SEXP paramSEXP2) {
    int i = Rinternals.LENGTH(Rinternals.Rf_protect(Rinternals.Rf_coerceVector(paramSEXP1, 14)));
    int j = Rinternals.Rf_asInteger(paramSEXP2);
    SEXP sEXP2 = Rinternals.Rf_protect(Rinternals.Rf_allocVector(14, j * j));
    paramSEXP2 = Rinternals.Rf_protect(Rinternals.Rf_allocVector(14, j + 1));
    paramSEXP1 = Rinternals.Rf_protect(Rinternals.Rf_allocVector(14, j + 1));
    Ptr ptr4 = Rinternals2.REAL(paramSEXP1);
    Ptr ptr3 = Rinternals2.REAL(paramSEXP2);
    Ptr ptr2 = Rinternals2.REAL(sEXP2);
    Ptr ptr1 = Rinternals2.REAL(Rinternals.Rf_protect(Rinternals.Rf_coerceVector(paramSEXP1, 14)));
    burg(i, ptr1, j, ptr2, ptr3, ptr4);
    SEXP sEXP1 = Rinternals.Rf_protect(Rinternals.Rf_allocVector(19, 3));
    Rinternals.SET_VECTOR_ELT(sEXP1, 0, sEXP2);
    Rinternals.SET_VECTOR_ELT(sEXP1, 1, paramSEXP2);
    Rinternals.SET_VECTOR_ELT(sEXP1, 2, paramSEXP1);
    return sEXP1;
  }
  
  public static void burg(int paramInt1, Ptr paramPtr1, int paramInt2, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4) {
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    DoublePtr doublePtr1 = DoublePtr.malloc(paramInt1 * 8);
    DoublePtr doublePtr2 = DoublePtr.malloc(paramInt1 * 8);
    DoublePtr doublePtr3 = DoublePtr.malloc(paramInt1 * 8);
    int i;
    for (i = 0; paramInt2 * paramInt2 > i; i++)
      paramPtr2.setDouble(i * 8, 0.0D); 
    double d = 0.0D;
    for (byte b2 = 0; b2 < paramInt1; b2++) {
      i = 0 + b2 * 8;
      doublePtr2.setDouble(i, paramPtr1.getDouble((paramInt1 + -1 - b2) * 8));
      doublePtr1.setDouble(0 + b2 * 8, doublePtr2.getDouble(i));
      d = paramPtr1.getDouble(b2 * 8) * paramPtr1.getDouble(b2 * 8) + d;
    } 
    paramPtr4.setDouble(d / paramInt1);
    paramPtr3.setDouble(paramPtr4.getDouble());
    for (byte b1 = 1; b1 <= paramInt2; b1++) {
      d = 0.0D;
      double d1 = 0.0D;
      for (i = b1; i < paramInt1; i++) {
        d = doublePtr2.getDouble(0 + i * 8) * doublePtr1.getDouble(0 + (i + -1) * 8) + d;
        d1 = doublePtr2.getDouble(0 + i * 8) * doublePtr2.getDouble(0 + i * 8) + doublePtr1.getDouble(0 + (i + -1) * 8) * doublePtr1.getDouble(0 + (i + -1) * 8) + d1;
      } 
      d = d * 2.0D / d1;
      paramPtr2.setDouble((paramInt2 + 1) * 8 * (b1 + -1), d);
      if (b1 > 1)
        for (i = 1; i < b1; i++)
          paramPtr2.setDouble((b1 + -1) * 8 + (i + -1) * 8 * paramInt2, paramPtr2.getDouble((b1 + -2) * 8 + (i + -1) * 8 * paramInt2) - paramPtr2.getDouble((b1 + -2) * 8 + (b1 - i + -1) * 8 * paramInt2) * d);  
      for (i = 0; i < paramInt1; i++)
        doublePtr3.setDouble(0 + i * 8, doublePtr1.getDouble(0 + i * 8)); 
      for (i = b1; i < paramInt1; i++) {
        doublePtr1.setDouble(0 + i * 8, doublePtr3.getDouble(0 + (i + -1) * 8) - doublePtr2.getDouble(0 + i * 8) * d);
        doublePtr2.setDouble(0 + i * 8, doublePtr2.getDouble(0 + i * 8) - doublePtr3.getDouble(0 + (i + -1) * 8) * d);
      } 
      paramPtr3.setDouble(b1 * 8, paramPtr3.getDouble((b1 + -1) * 8) * (1.0D - d * d));
      d = 0.0D;
      for (i = b1; i < paramInt1; i++)
        d = doublePtr2.getDouble(0 + i * 8) * doublePtr2.getDouble(0 + i * 8) + doublePtr1.getDouble(0 + i * 8) * doublePtr1.getDouble(0 + i * 8) + d; 
      paramPtr4.setDouble(b1 * 8, d / (paramInt1 - b1) * 2.0D);
    } 
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/stats-0.9.2724.jar!/org/renjin/stats/burg__.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */