package org.renjin.stats;

import org.renjin.gcc.runtime.Ptr;

public class bvalue__ {
  public static int i$1819;
  
  public static int[] $bvalue_$i = new int[1];
  
  static {
    i$1819 = 1;
    $bvalue_$i[0] = 1;
  }
  
  public static double bvalue_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6) {
    // Byte code:
    //   0: iconst_1
    //   1: newarray int
    //   3: astore #6
    //   5: iconst_1
    //   6: newarray int
    //   8: astore #7
    //   10: bipush #20
    //   12: newarray double
    //   14: astore #8
    //   16: bipush #20
    //   18: newarray double
    //   20: astore #9
    //   22: bipush #20
    //   24: newarray double
    //   26: astore #10
    //   28: aload #7
    //   30: iconst_0
    //   31: iconst_0
    //   32: iastore
    //   33: aload_2
    //   34: invokeinterface getInt : ()I
    //   39: iconst_0
    //   40: invokestatic max : (II)I
    //   43: invokestatic toUnsignedLong : (I)J
    //   46: pop2
    //   47: dconst_0
    //   48: dstore #11
    //   50: aload #5
    //   52: invokeinterface getInt : ()I
    //   57: aload_3
    //   58: invokeinterface getInt : ()I
    //   63: if_icmpge -> 1177
    //   66: aload #4
    //   68: invokeinterface getDouble : ()D
    //   73: aload_0
    //   74: aload_2
    //   75: invokeinterface getInt : ()I
    //   80: invokeinterface getAlignedDouble : (I)D
    //   85: dcmpl
    //   86: ifne -> 129
    //   89: aload_0
    //   90: aload_2
    //   91: invokeinterface getInt : ()I
    //   96: invokeinterface getAlignedDouble : (I)D
    //   101: aload_0
    //   102: aload_2
    //   103: invokeinterface getInt : ()I
    //   108: aload_3
    //   109: invokeinterface getInt : ()I
    //   114: iadd
    //   115: iconst_m1
    //   116: iadd
    //   117: invokeinterface getAlignedDouble : (I)D
    //   122: dcmpl
    //   123: ifne -> 129
    //   126: goto -> 268
    //   129: aload #6
    //   131: iconst_0
    //   132: aload_2
    //   133: invokeinterface getInt : ()I
    //   138: aload_3
    //   139: invokeinterface getInt : ()I
    //   144: iadd
    //   145: iastore
    //   146: aload_0
    //   147: new org/renjin/gcc/runtime/IntPtr
    //   150: dup
    //   151: aload #6
    //   153: iconst_0
    //   154: invokespecial <init> : ([II)V
    //   157: checkcast org/renjin/gcc/runtime/Ptr
    //   160: aload #4
    //   162: new org/renjin/gcc/runtime/IntPtr
    //   165: dup
    //   166: iconst_1
    //   167: newarray int
    //   169: dup
    //   170: iconst_0
    //   171: iconst_0
    //   172: iastore
    //   173: iconst_0
    //   174: invokespecial <init> : ([II)V
    //   177: checkcast org/renjin/gcc/runtime/Ptr
    //   180: new org/renjin/gcc/runtime/IntPtr
    //   183: dup
    //   184: iconst_1
    //   185: newarray int
    //   187: dup
    //   188: iconst_0
    //   189: iconst_0
    //   190: iastore
    //   191: iconst_0
    //   192: invokespecial <init> : ([II)V
    //   195: checkcast org/renjin/gcc/runtime/Ptr
    //   198: new org/renjin/gcc/runtime/IntPtr
    //   201: dup
    //   202: getstatic org/renjin/stats/bvalue__.$bvalue_$i : [I
    //   205: iconst_0
    //   206: invokespecial <init> : ([II)V
    //   209: checkcast org/renjin/gcc/runtime/Ptr
    //   212: new org/renjin/gcc/runtime/IntPtr
    //   215: dup
    //   216: aload #7
    //   218: iconst_0
    //   219: invokespecial <init> : ([II)V
    //   222: checkcast org/renjin/gcc/runtime/Ptr
    //   225: invokestatic interv_ : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
    //   228: istore #6
    //   230: getstatic org/renjin/stats/bvalue__.$bvalue_$i : [I
    //   233: iconst_0
    //   234: iload #6
    //   236: iastore
    //   237: aload #7
    //   239: iconst_0
    //   240: iaload
    //   241: ifne -> 247
    //   244: goto -> 283
    //   247: new org/renjin/gcc/runtime/BytePtr
    //   250: dup
    //   251: ldc 'bvalue()  mflag != 0: should never happen!'
    //   253: invokevirtual getBytes : ()[B
    //   256: iconst_0
    //   257: invokespecial <init> : ([BI)V
    //   260: bipush #42
    //   262: invokestatic rwarn_ : (Lorg/renjin/gcc/runtime/BytePtr;I)V
    //   265: goto -> 1177
    //   268: aload_2
    //   269: invokeinterface getInt : ()I
    //   274: istore #7
    //   276: getstatic org/renjin/stats/bvalue__.$bvalue_$i : [I
    //   279: iconst_0
    //   280: iload #7
    //   282: iastore
    //   283: aload_3
    //   284: invokeinterface getInt : ()I
    //   289: iconst_m1
    //   290: iadd
    //   291: istore #7
    //   293: iload #7
    //   295: ifle -> 301
    //   298: goto -> 319
    //   301: aload_1
    //   302: getstatic org/renjin/stats/bvalue__.$bvalue_$i : [I
    //   305: iconst_0
    //   306: iaload
    //   307: iconst_m1
    //   308: iadd
    //   309: invokeinterface getAlignedDouble : (I)D
    //   314: dstore #11
    //   316: goto -> 1177
    //   319: iconst_1
    //   320: istore #13
    //   322: getstatic org/renjin/stats/bvalue__.$bvalue_$i : [I
    //   325: iconst_0
    //   326: iaload
    //   327: aload_3
    //   328: invokeinterface getInt : ()I
    //   333: isub
    //   334: istore #6
    //   336: iload #6
    //   338: ifge -> 344
    //   341: goto -> 416
    //   344: iconst_1
    //   345: istore #14
    //   347: iconst_1
    //   348: iload #7
    //   350: if_icmple -> 356
    //   353: goto -> 576
    //   356: aload #9
    //   358: iload #14
    //   360: iconst_m1
    //   361: iadd
    //   362: aload #4
    //   364: invokeinterface getDouble : ()D
    //   369: aload_0
    //   370: getstatic org/renjin/stats/bvalue__.$bvalue_$i : [I
    //   373: iconst_0
    //   374: iaload
    //   375: iconst_1
    //   376: iadd
    //   377: iload #14
    //   379: isub
    //   380: iconst_m1
    //   381: iadd
    //   382: invokeinterface getAlignedDouble : (I)D
    //   387: dsub
    //   388: dastore
    //   389: iload #14
    //   391: iload #7
    //   393: if_icmpeq -> 402
    //   396: iconst_0
    //   397: istore #15
    //   399: goto -> 405
    //   402: iconst_1
    //   403: istore #15
    //   405: iinc #14, 1
    //   408: iload #15
    //   410: ifne -> 576
    //   413: goto -> 356
    //   416: iconst_1
    //   417: iload #6
    //   419: isub
    //   420: istore #13
    //   422: getstatic org/renjin/stats/bvalue__.$bvalue_$i : [I
    //   425: iconst_0
    //   426: iaload
    //   427: istore #14
    //   429: iconst_1
    //   430: istore #15
    //   432: iconst_1
    //   433: iload #14
    //   435: if_icmple -> 441
    //   438: goto -> 501
    //   441: aload #9
    //   443: iload #15
    //   445: iconst_m1
    //   446: iadd
    //   447: aload #4
    //   449: invokeinterface getDouble : ()D
    //   454: aload_0
    //   455: getstatic org/renjin/stats/bvalue__.$bvalue_$i : [I
    //   458: iconst_0
    //   459: iaload
    //   460: iconst_1
    //   461: iadd
    //   462: iload #15
    //   464: isub
    //   465: iconst_m1
    //   466: iadd
    //   467: invokeinterface getAlignedDouble : (I)D
    //   472: dsub
    //   473: dastore
    //   474: iload #15
    //   476: iload #14
    //   478: if_icmpeq -> 487
    //   481: iconst_0
    //   482: istore #16
    //   484: goto -> 490
    //   487: iconst_1
    //   488: istore #16
    //   490: iinc #15, 1
    //   493: iload #16
    //   495: ifne -> 501
    //   498: goto -> 441
    //   501: getstatic org/renjin/stats/bvalue__.$bvalue_$i : [I
    //   504: iconst_0
    //   505: iaload
    //   506: dup
    //   507: istore #14
    //   509: iload #7
    //   511: if_icmple -> 517
    //   514: goto -> 576
    //   517: aload #10
    //   519: aload_3
    //   520: invokeinterface getInt : ()I
    //   525: iload #14
    //   527: isub
    //   528: iconst_m1
    //   529: iadd
    //   530: dconst_0
    //   531: dastore
    //   532: aload #9
    //   534: iload #14
    //   536: iconst_m1
    //   537: iadd
    //   538: aload #9
    //   540: getstatic org/renjin/stats/bvalue__.$bvalue_$i : [I
    //   543: iconst_0
    //   544: iaload
    //   545: iconst_m1
    //   546: iadd
    //   547: daload
    //   548: dastore
    //   549: iload #14
    //   551: iload #7
    //   553: if_icmpeq -> 562
    //   556: iconst_0
    //   557: istore #15
    //   559: goto -> 565
    //   562: iconst_1
    //   563: istore #15
    //   565: iinc #14, 1
    //   568: iload #15
    //   570: ifne -> 576
    //   573: goto -> 517
    //   576: aload_3
    //   577: invokeinterface getInt : ()I
    //   582: istore #14
    //   584: aload_2
    //   585: invokeinterface getInt : ()I
    //   590: getstatic org/renjin/stats/bvalue__.$bvalue_$i : [I
    //   593: iconst_0
    //   594: iaload
    //   595: isub
    //   596: istore_2
    //   597: iload_2
    //   598: ifge -> 604
    //   601: goto -> 670
    //   604: iconst_1
    //   605: istore_2
    //   606: iconst_1
    //   607: iload #7
    //   609: if_icmple -> 615
    //   612: goto -> 806
    //   615: aload #8
    //   617: iload_2
    //   618: iconst_m1
    //   619: iadd
    //   620: aload_0
    //   621: getstatic org/renjin/stats/bvalue__.$bvalue_$i : [I
    //   624: iconst_0
    //   625: iaload
    //   626: iload_2
    //   627: iadd
    //   628: iconst_m1
    //   629: iadd
    //   630: invokeinterface getAlignedDouble : (I)D
    //   635: aload #4
    //   637: invokeinterface getDouble : ()D
    //   642: dsub
    //   643: dastore
    //   644: iload_2
    //   645: iload #7
    //   647: if_icmpeq -> 656
    //   650: iconst_0
    //   651: istore #15
    //   653: goto -> 659
    //   656: iconst_1
    //   657: istore #15
    //   659: iinc #2, 1
    //   662: iload #15
    //   664: ifne -> 806
    //   667: goto -> 615
    //   670: aload_3
    //   671: invokeinterface getInt : ()I
    //   676: iload_2
    //   677: iadd
    //   678: istore #14
    //   680: iload #14
    //   682: istore_2
    //   683: iconst_1
    //   684: istore #15
    //   686: iconst_1
    //   687: iload #14
    //   689: if_icmple -> 695
    //   692: goto -> 752
    //   695: aload #8
    //   697: iload #15
    //   699: iconst_m1
    //   700: iadd
    //   701: aload_0
    //   702: getstatic org/renjin/stats/bvalue__.$bvalue_$i : [I
    //   705: iconst_0
    //   706: iaload
    //   707: iload #15
    //   709: iadd
    //   710: iconst_m1
    //   711: iadd
    //   712: invokeinterface getAlignedDouble : (I)D
    //   717: aload #4
    //   719: invokeinterface getDouble : ()D
    //   724: dsub
    //   725: dastore
    //   726: iload #15
    //   728: iload_2
    //   729: if_icmpeq -> 738
    //   732: iconst_0
    //   733: istore #16
    //   735: goto -> 741
    //   738: iconst_1
    //   739: istore #16
    //   741: iinc #15, 1
    //   744: iload #16
    //   746: ifne -> 752
    //   749: goto -> 695
    //   752: iload #14
    //   754: istore_0
    //   755: iload #14
    //   757: iload #7
    //   759: if_icmple -> 765
    //   762: goto -> 806
    //   765: aload #10
    //   767: iload_0
    //   768: dconst_0
    //   769: dastore
    //   770: aload #8
    //   772: iload_0
    //   773: iconst_m1
    //   774: iadd
    //   775: aload #8
    //   777: iload #14
    //   779: iconst_m1
    //   780: iadd
    //   781: daload
    //   782: dastore
    //   783: iload_0
    //   784: iload #7
    //   786: if_icmpeq -> 794
    //   789: iconst_0
    //   790: istore_2
    //   791: goto -> 796
    //   794: iconst_1
    //   795: istore_2
    //   796: iinc #0, 1
    //   799: iload_2
    //   800: ifne -> 806
    //   803: goto -> 765
    //   806: iload #14
    //   808: istore_0
    //   809: iload #13
    //   811: istore_2
    //   812: iload #13
    //   814: iload #14
    //   816: if_icmple -> 822
    //   819: goto -> 865
    //   822: aload #10
    //   824: iload_2
    //   825: iconst_m1
    //   826: iadd
    //   827: aload_1
    //   828: iload #6
    //   830: iload_2
    //   831: iadd
    //   832: iconst_m1
    //   833: iadd
    //   834: invokeinterface getAlignedDouble : (I)D
    //   839: dastore
    //   840: iload_2
    //   841: iload_0
    //   842: if_icmpeq -> 851
    //   845: iconst_0
    //   846: istore #4
    //   848: goto -> 854
    //   851: iconst_1
    //   852: istore #4
    //   854: iinc #2, 1
    //   857: iload #4
    //   859: ifne -> 865
    //   862: goto -> 822
    //   865: aload #5
    //   867: invokeinterface getInt : ()I
    //   872: ifgt -> 878
    //   875: goto -> 1013
    //   878: aload #5
    //   880: invokeinterface getInt : ()I
    //   885: istore_0
    //   886: iconst_1
    //   887: istore_1
    //   888: iconst_1
    //   889: iload_0
    //   890: if_icmple -> 896
    //   893: goto -> 1013
    //   896: aload_3
    //   897: invokeinterface getInt : ()I
    //   902: iload_1
    //   903: isub
    //   904: istore_2
    //   905: iload_2
    //   906: i2d
    //   907: dstore #11
    //   909: iload_2
    //   910: istore #4
    //   912: iconst_1
    //   913: istore #6
    //   915: iconst_1
    //   916: iload_2
    //   917: if_icmple -> 923
    //   920: goto -> 991
    //   923: aload #10
    //   925: iload #6
    //   927: iconst_m1
    //   928: iadd
    //   929: aload #10
    //   931: iload #6
    //   933: daload
    //   934: aload #10
    //   936: iload #6
    //   938: iconst_m1
    //   939: iadd
    //   940: daload
    //   941: dsub
    //   942: aload #9
    //   944: iload #4
    //   946: iconst_m1
    //   947: iadd
    //   948: daload
    //   949: aload #8
    //   951: iload #6
    //   953: iconst_m1
    //   954: iadd
    //   955: daload
    //   956: dadd
    //   957: ddiv
    //   958: dload #11
    //   960: dmul
    //   961: dastore
    //   962: iinc #4, -1
    //   965: iload #6
    //   967: iload_2
    //   968: if_icmpeq -> 977
    //   971: iconst_0
    //   972: istore #13
    //   974: goto -> 980
    //   977: iconst_1
    //   978: istore #13
    //   980: iinc #6, 1
    //   983: iload #13
    //   985: ifne -> 991
    //   988: goto -> 923
    //   991: iload_1
    //   992: iload_0
    //   993: if_icmpeq -> 1001
    //   996: iconst_0
    //   997: istore_2
    //   998: goto -> 1003
    //   1001: iconst_1
    //   1002: istore_2
    //   1003: iinc #1, 1
    //   1006: iload_2
    //   1007: ifne -> 1013
    //   1010: goto -> 896
    //   1013: aload #5
    //   1015: invokeinterface getInt : ()I
    //   1020: iload #7
    //   1022: if_icmpne -> 1028
    //   1025: goto -> 1171
    //   1028: aload #5
    //   1030: invokeinterface getInt : ()I
    //   1035: iconst_1
    //   1036: iadd
    //   1037: dup
    //   1038: istore_0
    //   1039: iload #7
    //   1041: if_icmple -> 1047
    //   1044: goto -> 1171
    //   1047: aload_3
    //   1048: invokeinterface getInt : ()I
    //   1053: iload_0
    //   1054: isub
    //   1055: istore_1
    //   1056: iload_1
    //   1057: istore_2
    //   1058: iconst_1
    //   1059: istore #4
    //   1061: iconst_1
    //   1062: iload_1
    //   1063: if_icmple -> 1069
    //   1066: goto -> 1148
    //   1069: aload #10
    //   1071: iload #4
    //   1073: iconst_m1
    //   1074: iadd
    //   1075: aload #10
    //   1077: iload #4
    //   1079: daload
    //   1080: aload #9
    //   1082: iload_2
    //   1083: iconst_m1
    //   1084: iadd
    //   1085: daload
    //   1086: dmul
    //   1087: aload #10
    //   1089: iload #4
    //   1091: iconst_m1
    //   1092: iadd
    //   1093: daload
    //   1094: aload #8
    //   1096: iload #4
    //   1098: iconst_m1
    //   1099: iadd
    //   1100: daload
    //   1101: dmul
    //   1102: dadd
    //   1103: aload #9
    //   1105: iload_2
    //   1106: iconst_m1
    //   1107: iadd
    //   1108: daload
    //   1109: aload #8
    //   1111: iload #4
    //   1113: iconst_m1
    //   1114: iadd
    //   1115: daload
    //   1116: dadd
    //   1117: ddiv
    //   1118: dastore
    //   1119: iinc #2, -1
    //   1122: iload #4
    //   1124: iload_1
    //   1125: if_icmpeq -> 1134
    //   1128: iconst_0
    //   1129: istore #5
    //   1131: goto -> 1137
    //   1134: iconst_1
    //   1135: istore #5
    //   1137: iinc #4, 1
    //   1140: iload #5
    //   1142: ifne -> 1148
    //   1145: goto -> 1069
    //   1148: iload_0
    //   1149: iload #7
    //   1151: if_icmpeq -> 1159
    //   1154: iconst_0
    //   1155: istore_1
    //   1156: goto -> 1161
    //   1159: iconst_1
    //   1160: istore_1
    //   1161: iinc #0, 1
    //   1164: iload_1
    //   1165: ifne -> 1171
    //   1168: goto -> 1047
    //   1171: aload #10
    //   1173: iconst_0
    //   1174: daload
    //   1175: dstore #11
    //   1177: dload #11
    //   1179: dreturn
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/stats-0.9.2724.jar!/org/renjin/stats/bvalue__.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */