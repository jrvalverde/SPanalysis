package org.renjin.stats;

import org.renjin.gcc.runtime.BytePtr;
import org.renjin.gcc.runtime.Ptr;
import org.renjin.gnur.api.Error;
import org.renjin.gnur.api.GetText;
import org.renjin.gnur.api.Rinternals;
import org.renjin.gnur.api.Rinternals2;
import org.renjin.sexp.SEXP;

public class family__ {
  public static double INVEPS = 4.503599627370496E15D;
  
  public static double MTHRESH = -30.0D;
  
  public static double THRESH = 30.0D;
  
  public static SEXP binomial_dev_resids(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3) {
    byte b;
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    SEXP sEXP = (SEXP)BytePtr.of(0).getArray();
    int j = Rinternals.LENGTH(paramSEXP1);
    int i = Rinternals.LENGTH(paramSEXP2);
    int k = Rinternals.LENGTH(paramSEXP3);
    if (!Rinternals.Rf_isReal(paramSEXP1))
      paramSEXP1 = Rinternals.Rf_protect(Rinternals.Rf_coerceVector(paramSEXP1, 14)); 
    Ptr ptr2 = Rinternals2.REAL(paramSEXP1);
    paramSEXP1 = Rinternals.Rf_protect(Rinternals.Rf_duplicate(paramSEXP1));
    Ptr ptr3 = Rinternals2.REAL(paramSEXP1);
    if (!Rinternals.Rf_isReal(paramSEXP2))
      paramSEXP2 = Rinternals.Rf_protect(Rinternals.Rf_coerceVector(paramSEXP2, 14)); 
    if (!Rinternals.Rf_isReal(paramSEXP3))
      paramSEXP3 = Rinternals.Rf_protect(Rinternals.Rf_coerceVector(paramSEXP3, 14)); 
    Ptr ptr4 = Rinternals2.REAL(paramSEXP2);
    Ptr ptr1 = Rinternals2.REAL(paramSEXP3);
    if (i != j && i != 1)
      Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("argument %s must be a numeric vector of length 1 or length %d\000".getBytes(), 0)), new Object[0]); 
    if (k != j && k != 1)
      Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("argument %s must be a numeric vector of length 1 or length %d\000".getBytes(), 0)), new Object[0]); 
    if (i <= 1) {
      double d = ptr4.getDouble(0);
      for (b = 0; b < j; b++) {
        double d1 = ptr2.getDouble(0 + b * 8);
        int m = 0 + b * 8;
        if (k <= 1) {
          i = 0;
        } else {
          i = b * 8;
        } 
        ptr3.setDouble(m, ptr1.getDouble(0 + i) * 2.0D * (y_log_y(d1, d) + y_log_y(1.0D - d1, 1.0D - d)));
      } 
      return paramSEXP1;
    } 
    for (i = 0; i < j; i++) {
      int n;
      double d1 = b.getDouble(0 + i * 8);
      double d2 = ptr2.getDouble(0 + i * 8);
      int m = 0 + i * 8;
      if (k <= 1) {
        n = 0;
      } else {
        n = i * 8;
      } 
      ptr3.setDouble(m, ptr1.getDouble(0 + n) * 2.0D * (y_log_y(d2, d1) + y_log_y(1.0D - d2, 1.0D - d1)));
    } 
    return paramSEXP1;
  }
  
  public static SEXP logit_link(SEXP paramSEXP) {
    BytePtr.of(0);
    BytePtr.of(0);
    SEXP sEXP1 = (SEXP)BytePtr.of(0).getArray();
    int i = Rinternals.LENGTH(paramSEXP);
    SEXP sEXP2 = Rinternals.Rf_protect(Rinternals.Rf_duplicate(paramSEXP));
    Ptr ptr1 = Rinternals2.REAL(sEXP2);
    Ptr ptr2 = Rinternals2.REAL(paramSEXP);
    if (i == 0 || !Rinternals.Rf_isReal(paramSEXP))
      Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("Argument %s must be a nonempty numeric vector\000".getBytes(), 0)), new Object[0]); 
    for (byte b = 0; b < i; b++)
      ptr1.setDouble(0 + b * 8, Math.log(x_d_omx(ptr2.getDouble(0 + b * 8)))); 
    return sEXP2;
  }
  
  public static SEXP logit_linkinv(SEXP paramSEXP) {
    BytePtr.of(0);
    BytePtr.of(0);
    SEXP sEXP = (SEXP)BytePtr.of(0).getArray();
    sEXP = Rinternals.Rf_protect(Rinternals.Rf_duplicate(paramSEXP));
    int i = Rinternals.LENGTH(paramSEXP);
    Ptr ptr1 = Rinternals2.REAL(sEXP);
    Ptr ptr2 = Rinternals2.REAL(paramSEXP);
    if (i == 0 || !Rinternals.Rf_isReal(paramSEXP))
      Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("Argument %s must be a nonempty numeric vector\000".getBytes(), 0)), new Object[0]); 
    for (byte b = 0; b < i; b++) {
      double d = ptr2.getDouble(0 + b * 8);
      if (d >= MTHRESH) {
        if (d <= THRESH) {
          d = Math.exp(d);
        } else {
          d = INVEPS;
        } 
        d = d;
      } else {
        d = 2.220446049250313E-16D;
      } 
      ptr1.setDouble(0 + b * 8, x_d_opx(d));
    } 
    return sEXP;
  }
  
  public static SEXP logit_mu_eta(SEXP paramSEXP) {
    // Byte code:
    //   0: iconst_0
    //   1: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   4: pop
    //   5: iconst_0
    //   6: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   9: pop
    //   10: iconst_0
    //   11: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   14: invokeinterface getArray : ()Ljava/lang/Object;
    //   19: checkcast org/renjin/sexp/SEXP
    //   22: astore #5
    //   24: aload_0
    //   25: invokestatic Rf_duplicate : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   28: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
    //   31: astore #5
    //   33: aload_0
    //   34: invokestatic LENGTH : (Lorg/renjin/sexp/SEXP;)I
    //   37: istore #6
    //   39: aload #5
    //   41: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
    //   44: astore #7
    //   46: aload_0
    //   47: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
    //   50: astore #8
    //   52: iload #6
    //   54: ifeq -> 67
    //   57: aload_0
    //   58: invokestatic Rf_isReal : (Lorg/renjin/sexp/SEXP;)Z
    //   61: ifeq -> 67
    //   64: goto -> 106
    //   67: new org/renjin/gcc/runtime/BytePtr
    //   70: dup
    //   71: ldc 'stats '
    //   73: invokevirtual getBytes : ()[B
    //   76: iconst_0
    //   77: invokespecial <init> : ([BI)V
    //   80: new org/renjin/gcc/runtime/BytePtr
    //   83: dup
    //   84: ldc 'Argument %s must be a nonempty numeric vector '
    //   86: invokevirtual getBytes : ()[B
    //   89: iconst_0
    //   90: invokespecial <init> : ([BI)V
    //   93: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
    //   96: checkcast org/renjin/gcc/runtime/BytePtr
    //   99: iconst_0
    //   100: anewarray java/lang/Object
    //   103: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
    //   106: iconst_0
    //   107: istore #9
    //   109: goto -> 224
    //   112: aload #8
    //   114: iconst_0
    //   115: iload #9
    //   117: bipush #8
    //   119: imul
    //   120: iadd
    //   121: invokeinterface getDouble : (I)D
    //   126: dstore_3
    //   127: dload_3
    //   128: invokestatic exp : (D)D
    //   131: dconst_1
    //   132: dadd
    //   133: dstore_1
    //   134: iconst_0
    //   135: iload #9
    //   137: bipush #8
    //   139: imul
    //   140: iadd
    //   141: istore_0
    //   142: dload_3
    //   143: getstatic org/renjin/stats/family__.THRESH : D
    //   146: dcmpl
    //   147: ifgt -> 156
    //   150: iconst_0
    //   151: istore #10
    //   153: goto -> 159
    //   156: iconst_1
    //   157: istore #10
    //   159: iload #10
    //   161: iconst_1
    //   162: ixor
    //   163: ifne -> 169
    //   166: goto -> 208
    //   169: dload_3
    //   170: getstatic org/renjin/stats/family__.MTHRESH : D
    //   173: dcmpg
    //   174: iflt -> 183
    //   177: iconst_0
    //   178: istore #10
    //   180: goto -> 186
    //   183: iconst_1
    //   184: istore #10
    //   186: iload #10
    //   188: iconst_1
    //   189: ixor
    //   190: ifne -> 196
    //   193: goto -> 208
    //   196: dload_3
    //   197: invokestatic exp : (D)D
    //   200: dload_1
    //   201: dload_1
    //   202: dmul
    //   203: ddiv
    //   204: dstore_1
    //   205: goto -> 212
    //   208: ldc2_w 2.220446049250313E-16
    //   211: dstore_1
    //   212: aload #7
    //   214: iload_0
    //   215: dload_1
    //   216: invokeinterface setDouble : (ID)V
    //   221: iinc #9, 1
    //   224: iload #9
    //   226: iload #6
    //   228: if_icmplt -> 112
    //   231: aload #5
    //   233: areturn
  }
  
  public static double x_d_omx(double paramDouble) {
    if (paramDouble < 0.0D || paramDouble > 1.0D)
      Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("Value %g out of range (0, 1)\000".getBytes(), 0)), new Object[0]); 
    return paramDouble / (1.0D - paramDouble);
  }
  
  public static double x_d_opx(double paramDouble) {
    return paramDouble / (paramDouble + 1.0D);
  }
  
  public static double y_log_y(double paramDouble1, double paramDouble2) {
    return (paramDouble1 == 0.0D) ? 0.0D : (Math.log(paramDouble1 / paramDouble2) * paramDouble1);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/stats-0.9.2724.jar!/org/renjin/stats/family__.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */