package org.renjin.stats;

import org.renjin.gcc.runtime.Ptr;

public class sinerp__ {
  static {
  
  }
  
  public static void sinerp_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7) {
    double[] arrayOfDouble1 = new double[3];
    double[] arrayOfDouble2 = new double[2];
    double[] arrayOfDouble3 = new double[1];
    int k = Math.max(paramPtr2.getInt(), 0);
    Integer.toUnsignedLong(Math.max(k * paramPtr3.getInt(), 0));
    int m = k ^ 0xFFFFFFFF;
    int n = Math.max(paramPtr2.getInt(), 0);
    Integer.toUnsignedLong(Math.max(n * paramPtr3.getInt(), 0));
    int i1 = n ^ 0xFFFFFFFF;
    int i = Math.max(paramPtr6.getInt(), 0);
    Integer.toUnsignedLong(Math.max(i * paramPtr3.getInt(), 0));
    int j = i ^ 0xFFFFFFFF;
    double d1 = 0.0D;
    double d2 = 0.0D;
    double d3 = 0.0D;
    arrayOfDouble1[0] = 0.0D;
    arrayOfDouble1[1] = 0.0D;
    arrayOfDouble1[2] = 0.0D;
    arrayOfDouble2[0] = 0.0D;
    arrayOfDouble2[1] = 0.0D;
    arrayOfDouble3[0] = 0.0D;
    int i2 = paramPtr3.getInt();
    byte b = 1;
    if (1 <= i2)
      while (true) {
        int i3 = paramPtr3.getInt() - b + 1;
        double d = 1.0D / paramPtr1.getAlignedDouble(i3 * k + m + 4);
        if (paramPtr3.getInt() + -3 < i3) {
          if (paramPtr3.getInt() + -2 != i3) {
            if (paramPtr3.getInt() + -1 != i3) {
              if (paramPtr3.getInt() == i3) {
                d1 = 0.0D;
                d2 = 0.0D;
                d3 = 0.0D;
              } 
            } else {
              d1 = 0.0D;
              d2 = 0.0D;
              d3 = paramPtr1.getAlignedDouble((i3 + 1) * k + m + 3) * d;
            } 
          } else {
            d1 = 0.0D;
            d2 = paramPtr1.getAlignedDouble((i3 + 2) * k + m + 2) * d;
            d3 = paramPtr1.getAlignedDouble((i3 + 1) * k + m + 3) * d;
          } 
        } else {
          d1 = paramPtr1.getAlignedDouble((i3 + 3) * k + m + 1) * d;
          d2 = paramPtr1.getAlignedDouble((i3 + 2) * k + m + 2) * d;
          d3 = paramPtr1.getAlignedDouble((i3 + 1) * k + m + 3) * d;
        } 
        paramPtr4.setAlignedDouble(i3 * n + i1 + 1, 0.0D - arrayOfDouble1[0] * d1 + arrayOfDouble1[1] * d2 + arrayOfDouble1[2] * d3);
        paramPtr4.setAlignedDouble(i3 * n + i1 + 2, 0.0D - arrayOfDouble1[1] * d1 + arrayOfDouble2[0] * d2 + arrayOfDouble2[1] * d3);
        paramPtr4.setAlignedDouble(i3 * n + i1 + 3, 0.0D - arrayOfDouble1[2] * d1 + arrayOfDouble2[1] * d2 + arrayOfDouble3[0] * d3);
        paramPtr4.setAlignedDouble(i3 * n + i1 + 4, d * d + d1 * d1 * arrayOfDouble1[0] + d1 * 2.0D * d2 * arrayOfDouble1[1] + d1 * 2.0D * d3 * arrayOfDouble1[2] + arrayOfDouble2[0] * d2 * d2 + d2 * 2.0D * d3 * arrayOfDouble2[1] + arrayOfDouble3[0] * d3 * d3);
        arrayOfDouble1[0] = arrayOfDouble2[0];
        arrayOfDouble1[1] = arrayOfDouble2[1];
        arrayOfDouble1[2] = paramPtr4.getAlignedDouble(i3 * n + i1 + 2);
        arrayOfDouble2[0] = arrayOfDouble3[0];
        arrayOfDouble2[1] = paramPtr4.getAlignedDouble(i3 * n + i1 + 3);
        arrayOfDouble3[0] = paramPtr4.getAlignedDouble(i3 * n + i1 + 4);
        if (b != i2) {
          i3 = 0;
        } else {
          i3 = 1;
        } 
        b++;
        if (i3 == 0)
          continue; 
        break;
      }  
    if (paramPtr7.getInt() != 0) {
      int i4 = paramPtr3.getInt();
      byte b1 = 1;
      if (1 <= i4)
        while (true) {
          int i5 = paramPtr3.getInt() - b1 + 1;
          byte b2 = 1;
          while (i5 + b2 + -1 <= paramPtr3.getInt()) {
            paramPtr5.setAlignedDouble((i5 + b2 + -1) * i + j + i5, paramPtr4.getAlignedDouble(i5 * n + i1 + 5 - b2));
            if (b2 != 4) {
              i2 = 0;
            } else {
              i2 = 1;
            } 
            b2++;
            if (i2 == 0);
          } 
          if (b1 != i4) {
            i5 = 0;
          } else {
            i5 = 1;
          } 
          b1++;
          if (i5 == 0)
            continue; 
          break;
        }  
      int i3 = paramPtr3.getInt();
      i4 = 1;
      if (1 <= i3)
        while (true) {
          n = paramPtr3.getInt() - i4 + 1;
          if (n + -4 > 0) {
            i1 = n + -4;
            if (i1 > 0)
              while (true) {
                d2 = 1.0D / paramPtr1.getAlignedDouble(i1 * k + m + 4);
                d1 = paramPtr1.getAlignedDouble((i1 + 2) * k + m + 2) * d2;
                d2 = paramPtr1.getAlignedDouble((i1 + 1) * k + m + 3) * d2;
                paramPtr5.setAlignedDouble(n * i + j + i1, 0.0D - paramPtr1.getAlignedDouble((i1 + 3) * k + m + 1) * d2 * paramPtr5.getAlignedDouble(n * i + j + i1 + 3) + paramPtr5.getAlignedDouble(n * i + j + i1 + 2) * d1 + paramPtr5.getAlignedDouble(n * i + j + i1 + 1) * d2);
                if (i1 != 1) {
                  b1 = 0;
                } else {
                  b1 = 1;
                } 
                i1--;
                if (b1 == 0)
                  continue; 
                break;
              }  
          } 
          if (i4 != i3) {
            n = 0;
          } else {
            n = 1;
          } 
          i4++;
          if (n == 0)
            continue; 
          break;
        }  
    } 
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/stats-0.9.2724.jar!/org/renjin/stats/sinerp__.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */