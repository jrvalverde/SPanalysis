package org.renjin.stats;

import org.renjin.gcc.runtime.Builtins;
import org.renjin.gcc.runtime.BytePtr;
import org.renjin.gcc.runtime.DoublePtr;
import org.renjin.gcc.runtime.Mathlib;
import org.renjin.gcc.runtime.Ptr;
import org.renjin.gnur.api.Arith;
import org.renjin.gnur.api.Error;
import org.renjin.gnur.api.Rinternals;
import org.renjin.gnur.api.Rinternals2;
import org.renjin.sexp.SEXP;

public class filter__ {
  static {
  
  }
  
  public static SEXP acf(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3) {
    int m = Rinternals.Rf_nrows(paramSEXP1);
    int k = Rinternals.Rf_ncols(paramSEXP1);
    int i = Rinternals.Rf_asInteger(paramSEXP2);
    int j = Rinternals.Rf_asLogical(paramSEXP3);
    paramSEXP1 = Rinternals.Rf_protect(Rinternals.Rf_allocVector(14, (i + 1) * k * k));
    Ptr ptr = Rinternals2.REAL(paramSEXP1);
    acf0(Rinternals2.REAL(Rinternals.Rf_protect(Rinternals.Rf_coerceVector(paramSEXP1, 14))), m, k, i, j, ptr);
    SEXP sEXP = Rinternals.Rf_protect(Rinternals.Rf_allocVector(13, 3));
    Rinternals2.INTEGER(sEXP).setInt(0, i + 1);
    Rinternals2.INTEGER(sEXP).setInt(8, k);
    Rinternals2.INTEGER(sEXP).setInt(4, Rinternals2.INTEGER(sEXP).getInt(8));
    Rinternals.Rf_setAttrib(paramSEXP1, Rinternals.R_DimSymbol, sEXP);
    return paramSEXP1;
  }
  
  public static void acf0(Ptr paramPtr1, int paramInt1, int paramInt2, int paramInt3, int paramInt4, Ptr paramPtr2) {
    BytePtr.of(0);
    int i = paramInt3 + 1;
    int j = paramInt2 * i;
    byte b;
    for (b = 0; b < paramInt2; b++) {
      for (byte b1 = 0; b1 < paramInt2; b1++) {
        for (byte b2 = 0; b2 <= paramInt3; b2++) {
          double d = 0.0D;
          byte b3 = 0;
          int k;
          for (k = 0; paramInt1 - b2 > k; k++) {
            if (Builtins.__isnan(paramPtr1.getDouble((k + b2 + paramInt1 * b) * 8)) == 0 && Builtins.__isnan(paramPtr1.getDouble((paramInt1 * b1 + k) * 8)) == 0) {
              b3++;
              d = paramPtr1.getDouble((k + b2 + paramInt1 * b) * 8) * paramPtr1.getDouble((paramInt1 * b1 + k) * 8) + d;
            } 
          } 
          k = (i * b + b2 + j * b1) * 8;
          if (b3 <= 0) {
            d = Arith.R_NaReal;
          } else {
            d /= (b3 + b2);
          } 
          paramPtr2.setDouble(k, d);
        } 
      } 
    } 
    if (paramInt4 != 0) {
      if (paramInt1 != 1) {
        DoublePtr doublePtr = DoublePtr.malloc(paramInt2 * 8);
        for (paramInt1 = 0; paramInt1 < paramInt2; paramInt1++)
          doublePtr.setDouble(0 + paramInt1 * 8, Mathlib.sqrt(paramPtr2.getDouble((i + j) * paramInt1 * 8))); 
        for (paramInt4 = 0; paramInt4 < paramInt2; paramInt4++) {
          for (b = 0; b < paramInt2; b++) {
            for (byte b2 = 0; b2 <= paramInt3; b2++) {
              double d = paramPtr2.getDouble((i * paramInt4 + b2 + j * b) * 8) / doublePtr.getDouble(0 + paramInt4 * 8) * doublePtr.getDouble(0 + b * 8);
              paramInt1 = (i * paramInt4 + b2 + j * b) * 8;
              if (d <= 1.0D) {
                if (d >= -1.0D) {
                  d = d;
                } else {
                  d = -1.0D;
                } 
                d = d;
              } else {
                d = 1.0D;
              } 
              paramPtr2.setDouble(paramInt1, d);
            } 
          } 
        } 
        return;
      } 
      for (byte b1 = 0; b1 < paramInt2; b1++)
        paramPtr2.setDouble((i + j) * b1 * 8, 1.0D); 
    } 
  }
  
  public static SEXP cfilter(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4) {
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    SEXP sEXP = (SEXP)BytePtr.of(0).getArray();
    if (Rinternals.TYPEOF(paramSEXP1) != 14 || Rinternals.TYPEOF(paramSEXP2) != 14)
      Error.Rf_error(new BytePtr("invalid input\000".getBytes(), 0), new Object[0]); 
    int k = Rinternals.XLENGTH(paramSEXP1);
    int m = Rinternals.XLENGTH(paramSEXP2);
    int j = Rinternals.Rf_asInteger(paramSEXP3);
    int i = Rinternals.Rf_asLogical(paramSEXP4);
    if (j == Arith.R_NaInt || i == Arith.R_NaInt)
      Error.Rf_error(new BytePtr("invalid input\000".getBytes(), 0), new Object[0]); 
    paramSEXP3 = Rinternals.Rf_allocVector(14, k);
    Ptr ptr1 = Rinternals2.REAL(paramSEXP1);
    Ptr ptr2 = Rinternals2.REAL(paramSEXP2);
    Ptr ptr3 = Rinternals2.REAL(paramSEXP3);
    if (j != 2) {
      j = 0;
    } else {
      j = m / 2;
    } 
    if (i != 0) {
      for (i = 0; i < k; i++) {
        double d = 0.0D;
        for (byte b = 0;; b++) {
          byte b1;
          if (b >= m) {
            ptr3.setDouble(0 + i * 8, d);
            break;
          } 
          int n = i + j - b;
          if (n < 0)
            n += k; 
          if (n >= k)
            n -= k; 
          double d1 = ptr1.getDouble(0 + n * 8);
          if (Arith.R_IsNA(d1) != 0) {
            n = 0;
          } else {
            n = 1;
          } 
          n = n;
          if (Builtins.__isnan(d1) != 0) {
            b1 = 0;
          } else {
            b1 = 1;
          } 
          if ((n & b1) == 0) {
            ptr3.setDouble(0 + i * 8, Arith.R_NaReal);
            break;
          } 
          d = ptr2.getDouble(0 + b * 8) * d1 + d;
        } 
      } 
      return paramSEXP3;
    } 
    for (i = 0; i < k; i++) {
      double d = 0.0D;
      if (i + j + 1 - m >= 0 && i + j < k) {
        for (int n = Math.max(j + i - k, 0);; n++) {
          boolean bool2;
          if (Math.min(i + j + 1, m) <= n) {
            ptr3.setDouble(0 + i * 8, d);
            break;
          } 
          double d1 = ptr1.getDouble(0 + (i + j - n) * 8);
          if (Arith.R_IsNA(d1) != 0) {
            bool1 = false;
          } else {
            bool1 = true;
          } 
          boolean bool1 = bool1;
          if (Builtins.__isnan(d1) != 0) {
            bool2 = false;
          } else {
            bool2 = true;
          } 
          if ((bool1 & bool2) == 0) {
            ptr3.setDouble(0 + i * 8, Arith.R_NaReal);
            break;
          } 
          d = ptr2.getDouble(0 + n * 8) * d1 + d;
        } 
      } else {
        ptr3.setDouble(0 + i * 8, Arith.R_NaReal);
      } 
    } 
    return paramSEXP3;
  }
  
  public static SEXP rfilter(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3) {
    BytePtr.of(0);
    SEXP sEXP = (SEXP)BytePtr.of(0).getArray();
    BytePtr.of(0);
    BytePtr.of(0);
    if (Rinternals.TYPEOF(paramSEXP1) != 14 || Rinternals.TYPEOF(paramSEXP2) != 14 || Rinternals.TYPEOF(paramSEXP3) != 14)
      Error.Rf_error(new BytePtr("invalid input\000".getBytes(), 0), new Object[0]); 
    int i = Rinternals.XLENGTH(paramSEXP1);
    int j = Rinternals.XLENGTH(paramSEXP2);
    Ptr ptr1 = Rinternals2.REAL(paramSEXP1);
    Ptr ptr2 = Rinternals2.REAL(paramSEXP2);
    paramSEXP3 = Rinternals.Rf_duplicate(paramSEXP3);
    Ptr ptr3 = Rinternals2.REAL(paramSEXP3);
    for (byte b = 0; b < i; b++) {
      double d = ptr1.getDouble(0 + b * 8);
      for (byte b1 = 0;; b1++) {
        boolean bool2;
        if (b1 >= j) {
          ptr3.setDouble(0 + (j + b) * 8, d);
          break;
        } 
        double d1 = ptr3.getDouble(0 + (j + b - b1 + -1) * 8);
        if (Arith.R_IsNA(d1) != 0) {
          bool1 = false;
        } else {
          bool1 = true;
        } 
        boolean bool1 = bool1;
        if (Builtins.__isnan(d1) != 0) {
          bool2 = false;
        } else {
          bool2 = true;
        } 
        if ((bool1 & bool2) == 0) {
          ptr3.setDouble(0 + (j + b) * 8, Arith.R_NaReal);
          break;
        } 
        d = ptr2.getDouble(0 + b1 * 8) * d1 + d;
      } 
    } 
    return paramSEXP3;
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/stats-0.9.2724.jar!/org/renjin/stats/filter__.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */