package org.renjin.stats.nls;

import org.renjin.eval.Context;
import org.renjin.eval.EvalException;
import org.renjin.sexp.AtomicVector;
import org.renjin.sexp.DoubleArrayVector;
import org.renjin.sexp.DoubleVector;
import org.renjin.sexp.Function;
import org.renjin.sexp.FunctionCall;
import org.renjin.sexp.ListVector;
import org.renjin.sexp.Logical;
import org.renjin.sexp.Null;
import org.renjin.sexp.SEXP;
import org.renjin.sexp.Vector;

class NlsModel {
  private final FunctionCall conv;
  
  private final FunctionCall incr;
  
  private final FunctionCall deviance;
  
  private final FunctionCall trace;
  
  private final Function setPars;
  
  private final FunctionCall getPars;
  
  private Context context;
  
  NlsModel(Context paramContext, ListVector paramListVector) {
    this.context = paramContext;
    this.conv = getElementAsFunctionCall(paramListVector, "conv");
    this.incr = getElementAsFunctionCall(paramListVector, "incr");
    this.deviance = getElementAsFunctionCall(paramListVector, "deviance");
    this.trace = getElementAsFunctionCall(paramListVector, "trace");
    this.setPars = getElementAsFunction(paramListVector, "setPars");
    this.getPars = getElementAsFunctionCall(paramListVector, "getPars");
  }
  
  public double calculateDeviation() {
    return evaluateCallAsDouble(this.deviance);
  }
  
  public DoubleVector calculateIncrements() {
    return (DoubleVector)evaluateCall(this.incr);
  }
  
  private SEXP evaluateCall(FunctionCall paramFunctionCall) {
    return this.context.evaluate((SEXP)paramFunctionCall, this.context.getGlobalEnvironment());
  }
  
  private double evaluateCallAsDouble(FunctionCall paramFunctionCall) {
    return ((Vector)evaluateCall(paramFunctionCall)).getElementAsDouble(0);
  }
  
  public double getConvergence() {
    return evaluateCallAsDouble(this.conv);
  }
  
  private static Function getElementAsFunction(ListVector paramListVector, String paramString) {
    SEXP sEXP = paramListVector.get(paramString);
    if (sEXP == Null.INSTANCE || !(sEXP instanceof Function))
      throw new EvalException("'%s' absent", new Object[] { "m$" + paramString + "()" }); 
    return (Function)sEXP;
  }
  
  private static FunctionCall getElementAsFunctionCall(ListVector paramListVector, String paramString) {
    return FunctionCall.newCall((SEXP)getElementAsFunction(paramListVector, paramString), new SEXP[0]);
  }
  
  public AtomicVector getParameterValues() {
    return (AtomicVector)evaluateCall(this.getPars);
  }
  
  public void trace() {
    this.context.evaluate((SEXP)this.trace, this.context.getGlobalEnvironment());
  }
  
  public boolean updateParameters(double[] paramArrayOfdouble) {
    boolean bool;
    SEXP sEXP = this.context.evaluate((SEXP)FunctionCall.newCall((SEXP)this.setPars, new SEXP[] { (SEXP)new DoubleArrayVector(paramArrayOfdouble) }), this.context.getGlobalEnvironment());
    if (!(this instanceof AtomicVector))
      throw new EvalException("Unexpected result from setPars", new Object[0]); 
    if (((AtomicVector)this).getElementAsLogical(0) == Logical.TRUE) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/stats-0.9.2724.jar!/org/renjin/stats/nls/NlsModel.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */