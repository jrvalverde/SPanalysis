package org.renjin.stats;

import org.renjin.gcc.runtime.BytePtr;
import org.renjin.gcc.runtime.DoublePtr;
import org.renjin.gcc.runtime.IntFieldPtr;
import org.renjin.gcc.runtime.IntPtr;
import org.renjin.gcc.runtime.Ptr;
import org.renjin.gcc.runtime.Stdlib;
import org.renjin.gnur.api.Error;
import org.renjin.gnur.api.GetText;

public class loessc__ {
  public static Ptr v = BytePtr.of(0);
  
  public static int tau = 0;
  
  public static int lv = 0;
  
  public static int liv = 0;
  
  public static Ptr iv = BytePtr.of(0);
  
  public static void ehg182_(Ptr paramPtr) {
    BytePtr bytePtr1;
    BytePtr bytePtr2;
    Object[] arrayOfObject;
    byte[] arrayOfByte = new byte[50];
    switch (paramPtr.getInt()) {
      case 100:
        bytePtr1 = GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("wrong version number in lowesd.   Probably typo in caller.\000".getBytes(), 0));
        break;
      case 101:
        bytePtr1 = GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("d>dMAX in ehg131.  Need to recompile with increased dimensions.\000".getBytes(), 0));
        break;
      case 102:
        bytePtr1 = GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("liv too small.    (Discovered by lowesd)\000".getBytes(), 0));
        break;
      case 103:
        bytePtr1 = GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("lv too small.     (Discovered by lowesd)\000".getBytes(), 0));
        break;
      case 104:
        bytePtr1 = GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("span too small.   fewer data values than degrees of freedom.\000".getBytes(), 0));
        break;
      case 105:
        bytePtr1 = GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("k>d2MAX in ehg136.  Need to recompile with increased dimensions.\000".getBytes(), 0));
        break;
      case 106:
        bytePtr1 = GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("lwork too small\000".getBytes(), 0));
        break;
      case 107:
        bytePtr1 = GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("invalid value for kernel\000".getBytes(), 0));
        break;
      case 108:
        bytePtr1 = GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("invalid value for ideg\000".getBytes(), 0));
        break;
      case 109:
        bytePtr1 = GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("lowstt only applies when kernel=1.\000".getBytes(), 0));
        break;
      case 110:
        bytePtr1 = GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("not enough extra workspace for robustness calculation\000".getBytes(), 0));
        break;
      case 120:
        bytePtr1 = GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("zero-width neighborhood. make span bigger\000".getBytes(), 0));
        break;
      case 121:
        bytePtr1 = GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("all data on boundary of neighborhood. make span bigger\000".getBytes(), 0));
        break;
      case 122:
        bytePtr1 = GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("extrapolation not allowed with blending\000".getBytes(), 0));
        break;
      case 123:
        bytePtr1 = GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("ihat=1 (diag L) in l2fit only makes sense if z=x (eval=data).\000".getBytes(), 0));
        break;
      case 171:
        bytePtr1 = GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("lowesd must be called first.\000".getBytes(), 0));
        break;
      case 172:
        bytePtr1 = GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("lowesf must not come between lowesb and lowese, lowesr, or lowesl.\000".getBytes(), 0));
        break;
      case 173:
        bytePtr1 = GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("lowesb must come before lowese, lowesr, or lowesl.\000".getBytes(), 0));
        break;
      case 174:
        bytePtr1 = GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("lowesb need not be called twice.\000".getBytes(), 0));
        break;
      case 175:
        bytePtr1 = GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("need setLf=.true. for lowesl.\000".getBytes(), 0));
        break;
      case 180:
        bytePtr1 = GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("nv>nvmax in cpvert.\000".getBytes(), 0));
        break;
      case 181:
        bytePtr1 = GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("nt>20 in eval.\000".getBytes(), 0));
        break;
      case 182:
        bytePtr1 = GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("svddc failed in l2fit.\000".getBytes(), 0));
        break;
      case 183:
        bytePtr1 = GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("didnt find edge in vleaf.\000".getBytes(), 0));
        break;
      case 184:
        bytePtr1 = GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("zero-width cell found in vleaf.\000".getBytes(), 0));
        break;
      case 185:
        bytePtr1 = GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("trouble descending to leaf in vleaf.\000".getBytes(), 0));
        break;
      case 186:
        bytePtr1 = GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("insufficient workspace for lowesf.\000".getBytes(), 0));
        break;
      case 187:
        bytePtr1 = GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("insufficient stack space\000".getBytes(), 0));
        break;
      case 188:
        bytePtr1 = GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("lv too small for computing explicit L\000".getBytes(), 0));
        break;
      case 191:
        bytePtr1 = GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("computed trace L was negative; something is wrong!\000".getBytes(), 0));
        break;
      case 192:
        bytePtr1 = GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("computed delta was negative; something is wrong!\000".getBytes(), 0));
        break;
      case 193:
        bytePtr1 = GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("workspace in loread appears to be corrupted\000".getBytes(), 0));
        break;
      case 194:
        bytePtr1 = GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("trouble in l2fit/l2tr\000".getBytes(), 0));
        break;
      case 195:
        bytePtr1 = GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("only constant, linear, or quadratic local models allowed\000".getBytes(), 0));
        break;
      case 196:
        bytePtr1 = GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("degree must be at least 1 for vertex influence matrix\000".getBytes(), 0));
        break;
      case 999:
        bytePtr1 = GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("not yet implemented\000".getBytes(), 0));
        break;
      default:
        arrayOfObject = new Object[1];
        bytePtr1 = new BytePtr();
        this(arrayOfByte, 0);
        bytePtr2 = new BytePtr();
        this("Assert failed; error code %d\n\000".getBytes(), 0);
        arrayOfObject[0] = Integer.valueOf(bytePtr1.getInt());
        Stdlib.snprintf(bytePtr1, 50, bytePtr2, arrayOfObject);
        bytePtr1 = new BytePtr(arrayOfByte, 0);
        break;
    } 
    Error.Rf_warning((BytePtr)bytePtr1.pointerPlus(0), new Object[0]);
  }
  
  public static void ehg183a_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5) {
    byte[] arrayOfByte1 = new byte[20];
    byte[] arrayOfByte2 = new byte[4000];
    int i = paramPtr2.getInt();
    Stdlib.strncpy((Ptr)new BytePtr(arrayOfByte2, 0), paramPtr1, i);
    arrayOfByte2[paramPtr2.getInt()] = (byte)0;
    for (byte b = 0; paramPtr4.getInt() > b; b++) {
      Object[] arrayOfObject = new Object[1];
      BytePtr bytePtr1 = new BytePtr();
      this(arrayOfByte1, 0);
      BytePtr bytePtr2 = new BytePtr();
      this(" %d\000".getBytes(), 0);
      arrayOfObject[0] = Integer.valueOf(paramPtr3.getInt(paramPtr5.getInt() * b * 4));
      Stdlib.snprintf(bytePtr1, 20, bytePtr2, arrayOfObject);
      Stdlib.strcat((Ptr)new BytePtr(arrayOfByte2, 0), (Ptr)new BytePtr(arrayOfByte1, 0));
    } 
    (new BytePtr(arrayOfByte2, Stdlib.strlen((Ptr)new BytePtr(arrayOfByte2, 0)) / 1)).memcpy((Ptr)new BytePtr("\n\000".getBytes(), 0), 2);
    Error.Rf_warning(new BytePtr(arrayOfByte2, 0), new Object[0]);
  }
  
  public static void ehg184a_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5) {
    byte[] arrayOfByte1 = new byte[30];
    byte[] arrayOfByte2 = new byte[4000];
    int i = paramPtr2.getInt();
    Stdlib.strncpy((Ptr)new BytePtr(arrayOfByte2, 0), paramPtr1, i);
    arrayOfByte2[paramPtr2.getInt()] = (byte)0;
    for (byte b = 0; paramPtr4.getInt() > b; b++) {
      Object[] arrayOfObject = new Object[1];
      BytePtr bytePtr1 = new BytePtr();
      this(arrayOfByte1, 0);
      BytePtr bytePtr2 = new BytePtr();
      this(" %.5g\000".getBytes(), 0);
      arrayOfObject[0] = Double.valueOf(paramPtr3.getDouble(paramPtr5.getInt() * b * 8));
      Stdlib.snprintf(bytePtr1, 30, bytePtr2, arrayOfObject);
      Stdlib.strcat((Ptr)new BytePtr(arrayOfByte2, 0), (Ptr)new BytePtr(arrayOfByte1, 0));
    } 
    (new BytePtr(arrayOfByte2, Stdlib.strlen((Ptr)new BytePtr(arrayOfByte2, 0)) / 1)).memcpy((Ptr)new BytePtr("\n\000".getBytes(), 0), 2);
    Error.Rf_warning(new BytePtr(arrayOfByte2, 0), new Object[0]);
  }
  
  public static void loess_dfit(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, Ptr paramPtr11, Ptr paramPtr12, Ptr paramPtr13) {
    double[] arrayOfDouble = new double[1];
    int[] arrayOfInt = new int[1];
    arrayOfInt[0] = 0;
    arrayOfDouble[0] = 0.0D;
    loess_workspace(paramPtr10, paramPtr11, paramPtr5, paramPtr6, paramPtr7, paramPtr8, paramPtr9, (Ptr)new IntPtr(arrayOfInt, 0));
    paramPtr4 = v;
    loessf__.lowesf_(paramPtr2, paramPtr1, paramPtr4, iv, IntFieldPtr.addressOf(loessc__.class, "liv"), IntFieldPtr.addressOf(loessc__.class, "lv"), paramPtr4, paramPtr12, paramPtr3, (Ptr)new DoublePtr(arrayOfDouble, 0), (Ptr)new IntPtr(arrayOfInt, 0), paramPtr13);
    loess_free();
  }
  
  public static void loess_dfitse(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, Ptr paramPtr11, Ptr paramPtr12, Ptr paramPtr13, Ptr paramPtr14, Ptr paramPtr15, Ptr paramPtr16) {
    double[] arrayOfDouble = new double[1];
    int[] arrayOfInt1 = new int[1];
    int[] arrayOfInt2 = new int[1];
    arrayOfInt2[0] = 0;
    arrayOfInt1[0] = 2;
    arrayOfDouble[0] = 0.0D;
    loess_workspace(paramPtr12, paramPtr13, paramPtr7, paramPtr8, paramPtr9, paramPtr10, paramPtr11, (Ptr)new IntPtr(arrayOfInt2, 0));
    if (paramPtr6.getInt() != 1) {
      if (paramPtr6.getInt() == 0) {
        paramPtr4 = v;
        loessf__.lowesf_(paramPtr2, paramPtr1, paramPtr4, iv, IntFieldPtr.addressOf(loessc__.class, "liv"), IntFieldPtr.addressOf(loessc__.class, "lv"), paramPtr4, paramPtr14, paramPtr3, paramPtr16, (Ptr)new IntPtr(arrayOfInt1, 0), paramPtr15);
        paramPtr1 = v;
        loessf__.lowesf_(paramPtr2, paramPtr1, paramPtr5, iv, IntFieldPtr.addressOf(loessc__.class, "liv"), IntFieldPtr.addressOf(loessc__.class, "lv"), paramPtr1, paramPtr14, paramPtr3, (Ptr)new DoublePtr(arrayOfDouble, 0), (Ptr)new IntPtr(arrayOfInt2, 0), paramPtr15);
      } 
    } else {
      paramPtr1 = v;
      loessf__.lowesf_(paramPtr2, paramPtr1, paramPtr4, iv, IntFieldPtr.addressOf(loessc__.class, "liv"), IntFieldPtr.addressOf(loessc__.class, "lv"), paramPtr1, paramPtr14, paramPtr3, paramPtr16, (Ptr)new IntPtr(arrayOfInt1, 0), paramPtr15);
    } 
    loess_free();
  }
  
  public static void loess_free() {
    Ptr ptr = v;
    v = BytePtr.of(0);
    ptr = iv;
    iv = BytePtr.of(0);
  }
  
  public static void loess_grow(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5) {
    int[] arrayOfInt1 = new int[1];
    int[] arrayOfInt2 = new int[1];
    int[] arrayOfInt3 = new int[1];
    int[] arrayOfInt4 = new int[1];
    arrayOfInt1[0] = 0;
    arrayOfInt2[0] = 0;
    arrayOfInt3[0] = 0;
    arrayOfInt4[0] = 0;
    arrayOfInt4[0] = paramPtr1.getInt();
    arrayOfInt3[0] = paramPtr1.getAlignedInt(2);
    arrayOfInt2[0] = paramPtr1.getAlignedInt(3);
    arrayOfInt1[0] = paramPtr1.getAlignedInt(4);
    liv = paramPtr1.getAlignedInt(5);
    lv = paramPtr1.getAlignedInt(6);
    iv = (Ptr)IntPtr.malloc(liv * 4);
    v = (Ptr)DoublePtr.malloc(lv * 8);
    iv.setInt(4, arrayOfInt4[0]);
    iv.setInt(8, paramPtr1.getAlignedInt(1));
    iv.setInt(12, arrayOfInt3[0]);
    iv.setInt(52, arrayOfInt1[0]);
    iv.setInt(20, iv.getInt(52));
    iv.setInt(64, arrayOfInt2[0]);
    iv.setInt(16, iv.getInt(64));
    iv.setInt(24, 50);
    iv.setInt(28, iv.getInt(24) + arrayOfInt2[0]);
    iv.setInt(32, iv.getInt(28) + arrayOfInt3[0] * arrayOfInt2[0]);
    iv.setInt(36, iv.getInt(32) + arrayOfInt2[0]);
    iv.setInt(40, 50);
    iv.setInt(48, iv.getInt(40) + arrayOfInt1[0] * arrayOfInt4[0]);
    iv.setInt(44, iv.getInt(48) + (arrayOfInt4[0] + 1) * arrayOfInt1[0]);
    iv.setInt(108, 173);
    int i = iv.getInt(40) + -1;
    int k = iv.getInt(44) + -1;
    int m = iv.getInt(24) + -1;
    int n = iv.getInt(48) + -1;
    for (byte b3 = 0; b3 < arrayOfInt4[0]; b3++) {
      int i1 = arrayOfInt1[0] * b3;
      v.setDouble(0 + (i + i1) * 8, paramPtr4.getDouble(b3 * 8));
      v.setDouble(0 + (i1 + i + arrayOfInt3[0] + -1) * 8, paramPtr4.getDouble((b3 + arrayOfInt4[0]) * 8));
    } 
    for (byte b2 = 0; b2 < arrayOfInt2[0]; b2++) {
      v.setDouble(0 + (k + b2) * 8, paramPtr3.getDouble(b2 * 8));
      iv.setInt(0 + (m + b2) * 4, paramPtr2.getInt(b2 * 4));
    } 
    int j = (arrayOfInt4[0] + 1) * arrayOfInt1[0];
    for (byte b1 = 0; b1 < j; b1++)
      v.setDouble(0 + (n + b1) * 8, paramPtr5.getDouble(b1 * 8)); 
    Ptr ptr1 = (Ptr)new IntPtr(arrayOfInt4, 0);
    Ptr ptr2 = (Ptr)new IntPtr(arrayOfInt3, 0);
    Ptr ptr3 = (Ptr)new IntPtr(arrayOfInt2, 0);
    Ptr ptr4 = (Ptr)new IntPtr(arrayOfInt2, 0);
    paramPtr5 = (Ptr)new IntPtr(arrayOfInt1, 0);
    Ptr ptr5 = (Ptr)new IntPtr(arrayOfInt1, 0);
    Ptr ptr6 = v.pointerPlus(0 + i * 8);
    Ptr ptr7 = iv.pointerPlus(0 + m * 4);
    Ptr ptr8 = v.pointerPlus(0 + k * 8);
    Ptr ptr9 = iv.pointerPlus(0 + (iv.getInt(28) + -1) * 4);
    Ptr ptr10 = iv.pointerPlus(0 + (iv.getInt(32) + -1) * 4);
    Ptr ptr11 = iv.pointerPlus(0 + (iv.getInt(36) + -1) * 4);
    loessf__.ehg169_(ptr1, ptr2, ptr3, ptr4, paramPtr5, ptr5, ptr6, ptr7, ptr8, ptr9, ptr10, ptr11);
  }
  
  public static void loess_ifit(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8) {
    loess_grow(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5);
    paramPtr1 = v;
    loessf__.lowese_(iv, IntFieldPtr.addressOf(loessc__.class, "liv"), IntFieldPtr.addressOf(loessc__.class, "lv"), paramPtr1, paramPtr6, paramPtr7, paramPtr8);
    loess_free();
  }
  
  public static void loess_ise(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, Ptr paramPtr11, Ptr paramPtr12, Ptr paramPtr13, Ptr paramPtr14, Ptr paramPtr15) {
    double[] arrayOfDouble = new double[1];
    int[] arrayOfInt2 = new int[1];
    int[] arrayOfInt1 = new int[1];
    arrayOfInt1[0] = 0;
    arrayOfInt2[0] = 1;
    arrayOfDouble[0] = 0.0D;
    loess_workspace(paramPtr11, paramPtr12, paramPtr5, paramPtr6, paramPtr7, paramPtr8, paramPtr9, (Ptr)new IntPtr(arrayOfInt2, 0));
    v.setDouble(8, paramPtr10.getDouble());
    paramPtr5 = v;
    Ptr ptr2 = iv;
    loessf__.lowesb_(paramPtr2, paramPtr1, paramPtr4, (Ptr)new DoublePtr(arrayOfDouble, 0), (Ptr)new IntPtr(arrayOfInt1, 0), ptr2, IntFieldPtr.addressOf(loessc__.class, "liv"), IntFieldPtr.addressOf(loessc__.class, "lv"), paramPtr5);
    Ptr ptr1 = v;
    loessf__.lowesl_(iv, IntFieldPtr.addressOf(loessc__.class, "liv"), IntFieldPtr.addressOf(loessc__.class, "lv"), ptr1, paramPtr13, paramPtr3, paramPtr15);
    loess_free();
  }
  
  public static void loess_prune(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5) {
    int j = iv.getInt(4);
    int k = iv.getInt(12) + -1;
    int m = iv.getInt(16);
    int n = iv.getInt(20);
    int i1 = iv.getInt(24) + -1;
    int i2 = iv.getInt(40) + -1;
    int i3 = iv.getInt(44) + -1;
    int i4 = iv.getInt(48) + -1;
    int i5 = iv.getInt(52);
    int i6;
    for (i6 = 0; i6 <= 4; i6++)
      paramPtr1.setInt(i6 * 4, iv.getInt(0 + (i6 + 1) * 4)); 
    paramPtr1.setInt(20, iv.getInt(84) + -1);
    paramPtr1.setInt(24, iv.getInt(56) + -1);
    int i;
    for (i = 0; i < j; i++) {
      i6 = i5 * i;
      paramPtr4.setDouble(i * 8, v.getDouble(0 + (i2 + i6) * 8));
      paramPtr4.setDouble((i + j) * 8, v.getDouble(0 + (i6 + i2 + k) * 8));
    } 
    for (i = 0; i < m; i++) {
      paramPtr3.setDouble(i * 8, v.getDouble(0 + (i3 + i) * 8));
      paramPtr2.setInt(i * 4, iv.getInt(0 + (i1 + i) * 4));
    } 
    i = (j + 1) * n;
    for (byte b = 0; b < i; b++)
      paramPtr5.setDouble(b * 8, v.getDouble(0 + (i4 + b) * 8)); 
  }
  
  public static void loess_raw(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, Ptr paramPtr11, Ptr paramPtr12, Ptr paramPtr13, Ptr paramPtr14, Ptr paramPtr15, Ptr paramPtr16, Ptr paramPtr17, Ptr paramPtr18, Ptr paramPtr19, Ptr paramPtr20, Ptr paramPtr21, Ptr paramPtr22, Ptr paramPtr23, Ptr paramPtr24) {
    Ptr ptr;
    byte b;
    DoublePtr doublePtr;
    double[] arrayOfDouble = new double[1];
    int[] arrayOfInt1 = new int[1];
    int[] arrayOfInt2 = new int[1];
    int[] arrayOfInt3 = new int[1];
    int[] arrayOfInt4 = new int[1];
    BytePtr.of(0);
    arrayOfInt1[0] = 0;
    arrayOfInt4[0] = 0;
    arrayOfInt3[0] = 1;
    arrayOfInt2[0] = 2;
    arrayOfDouble[0] = 0.0D;
    paramPtr21.setDouble(0.0D);
    loess_workspace(paramPtr5, paramPtr6, paramPtr7, paramPtr8, paramPtr9, paramPtr10, paramPtr11, paramPtr24);
    v.setDouble(8, paramPtr12.getDouble());
    if (Stdlib.strcmp(paramPtr13.getPointer(), (Ptr)new BytePtr("interpolate/none\000".getBytes(), 0)) != 0) {
      byte b1;
      if (Stdlib.strcmp(paramPtr13.getPointer(), (Ptr)new BytePtr("direct/none\000".getBytes(), 0)) != 0) {
        if (Stdlib.strcmp(paramPtr13.getPointer(), (Ptr)new BytePtr("interpolate/1.approx\000".getBytes(), 0)) != 0) {
          if (Stdlib.strcmp(paramPtr13.getPointer(), (Ptr)new BytePtr("interpolate/2.approx\000".getBytes(), 0)) != 0) {
            if (Stdlib.strcmp(paramPtr13.getPointer(), (Ptr)new BytePtr("direct/approximate\000".getBytes(), 0)) != 0) {
              if (Stdlib.strcmp(paramPtr13.getPointer(), (Ptr)new BytePtr("interpolate/exact\000".getBytes(), 0)) != 0) {
                if (Stdlib.strcmp(paramPtr13.getPointer(), (Ptr)new BytePtr("direct/exact\000".getBytes(), 0)) == 0) {
                  doublePtr = DoublePtr.malloc(paramPtr6.getInt() * paramPtr6.getInt() * 8);
                  paramPtr1 = v;
                  loessf__.lowesf_(paramPtr2, paramPtr1, paramPtr3, iv, IntFieldPtr.addressOf(loessc__.class, "liv"), IntFieldPtr.addressOf(loessc__.class, "lv"), paramPtr1, paramPtr6, paramPtr2, doublePtr.pointerPlus(0), (Ptr)new IntPtr(arrayOfInt2, 0), paramPtr14);
                  paramPtr1 = doublePtr.pointerPlus(0);
                  paramPtr2 = DoublePtr.malloc(paramPtr6.getInt() * paramPtr6.getInt() * 8).pointerPlus(0);
                  loessf__.lowesc_(paramPtr6, paramPtr1, paramPtr2, paramPtr21, paramPtr22, paramPtr23);
                  b1 = paramPtr6.getInt() + 1;
                  for (b = 0; paramPtr6.getInt() > b; b++)
                    paramPtr20.setDouble(b * 8, doublePtr.getDouble(0 + b * b1 * 8)); 
                } 
              } else {
                doublePtr = DoublePtr.malloc(paramPtr6.getInt() * paramPtr6.getInt() * 8);
                paramPtr3 = v;
                ptr = iv;
                loessf__.lowesb_(b, b1, paramPtr3, paramPtr20, (Ptr)new IntPtr(arrayOfInt3, 0), ptr, IntFieldPtr.addressOf(loessc__.class, "liv"), IntFieldPtr.addressOf(loessc__.class, "lv"), paramPtr3);
                ptr = v;
                paramPtr3 = iv;
                paramPtr5 = IntFieldPtr.addressOf(loessc__.class, "liv");
                paramPtr7 = IntFieldPtr.addressOf(loessc__.class, "lv");
                paramPtr8 = DoublePtr.malloc(paramPtr6.getInt() * paramPtr6.getInt() * 8).pointerPlus(0);
                loessf__.lowesl_(paramPtr3, paramPtr5, paramPtr7, ptr, paramPtr6, b, paramPtr8);
                loessf__.lowesc_(paramPtr6, DoublePtr.malloc(paramPtr6.getInt() * paramPtr6.getInt() * 8).pointerPlus(0), doublePtr.pointerPlus(0), paramPtr21, paramPtr22, paramPtr23);
                ptr = v;
                loessf__.lowese_(iv, IntFieldPtr.addressOf(loessc__.class, "liv"), IntFieldPtr.addressOf(loessc__.class, "lv"), ptr, paramPtr6, b, paramPtr14);
                loess_prune(paramPtr15, paramPtr16, paramPtr17, paramPtr18, paramPtr19);
              } 
            } else {
              ptr = v;
              loessf__.lowesf_(b, ptr, paramPtr3, iv, IntFieldPtr.addressOf(loessc__.class, "liv"), IntFieldPtr.addressOf(loessc__.class, "lv"), ptr, paramPtr6, b, paramPtr20, (Ptr)new IntPtr(arrayOfInt3, 0), paramPtr14);
              arrayOfInt1[0] = iv.getInt(116);
              for (b1 = 0; paramPtr6.getInt() > b1; b1++)
                paramPtr21.setDouble(paramPtr21.getDouble() + paramPtr20.getDouble(b1 * 8)); 
              loessf__.lowesa_(paramPtr21, paramPtr6, paramPtr5, IntFieldPtr.addressOf(loessc__.class, "tau"), (Ptr)new IntPtr(arrayOfInt1, 0), paramPtr22, paramPtr23);
            } 
          } else {
            paramPtr3 = v;
            ptr = iv;
            loessf__.lowesb_(b, b1, paramPtr3, (Ptr)new DoublePtr(arrayOfDouble, 0), (Ptr)new IntPtr(arrayOfInt4, 0), ptr, IntFieldPtr.addressOf(loessc__.class, "liv"), IntFieldPtr.addressOf(loessc__.class, "lv"), paramPtr3);
            ptr = v;
            loessf__.lowese_(iv, IntFieldPtr.addressOf(loessc__.class, "liv"), IntFieldPtr.addressOf(loessc__.class, "lv"), ptr, paramPtr6, b, paramPtr14);
            arrayOfInt1[0] = iv.getInt(116);
            loessf__.ehg196_(IntFieldPtr.addressOf(loessc__.class, "tau"), paramPtr5, paramPtr7, paramPtr21);
            loessf__.lowesa_(paramPtr21, paramPtr6, paramPtr5, IntFieldPtr.addressOf(loessc__.class, "tau"), (Ptr)new IntPtr(arrayOfInt1, 0), paramPtr22, paramPtr23);
            loess_prune(paramPtr15, paramPtr16, paramPtr17, paramPtr18, paramPtr19);
          } 
        } else {
          paramPtr3 = v;
          ptr = iv;
          loessf__.lowesb_(b, ptr, paramPtr3, paramPtr20, (Ptr)new IntPtr(arrayOfInt3, 0), ptr, IntFieldPtr.addressOf(loessc__.class, "liv"), IntFieldPtr.addressOf(loessc__.class, "lv"), paramPtr3);
          ptr = v;
          loessf__.lowese_(iv, IntFieldPtr.addressOf(loessc__.class, "liv"), IntFieldPtr.addressOf(loessc__.class, "lv"), ptr, paramPtr6, b, paramPtr14);
          arrayOfInt1[0] = iv.getInt(116);
          for (b1 = 0; paramPtr6.getInt() > b1; b1++)
            paramPtr21.setDouble(paramPtr21.getDouble() + paramPtr20.getDouble(b1 * 8)); 
          loessf__.lowesa_(paramPtr21, paramPtr6, paramPtr5, IntFieldPtr.addressOf(loessc__.class, "tau"), (Ptr)new IntPtr(arrayOfInt1, 0), paramPtr22, paramPtr23);
          loess_prune(paramPtr15, paramPtr16, paramPtr17, paramPtr18, paramPtr19);
        } 
      } else {
        ptr = v;
        loessf__.lowesf_(b, b1, (Ptr)doublePtr, iv, IntFieldPtr.addressOf(loessc__.class, "liv"), IntFieldPtr.addressOf(loessc__.class, "lv"), ptr, paramPtr6, b, (Ptr)new DoublePtr(arrayOfDouble, 0), (Ptr)new IntPtr(arrayOfInt4, 0), paramPtr14);
      } 
    } else {
      paramPtr3 = v;
      ptr = iv;
      loessf__.lowesb_(b, ptr, (Ptr)doublePtr, (Ptr)new DoublePtr(arrayOfDouble, 0), (Ptr)new IntPtr(arrayOfInt4, 0), ptr, IntFieldPtr.addressOf(loessc__.class, "liv"), IntFieldPtr.addressOf(loessc__.class, "lv"), paramPtr3);
      ptr = v;
      loessf__.lowese_(iv, IntFieldPtr.addressOf(loessc__.class, "liv"), IntFieldPtr.addressOf(loessc__.class, "lv"), ptr, paramPtr6, b, paramPtr14);
      loess_prune(paramPtr15, paramPtr16, paramPtr17, paramPtr18, paramPtr19);
    } 
    loess_free();
  }
  
  public static void loess_workspace(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8) {
    // Byte code:
    //   0: iconst_1
    //   1: newarray int
    //   3: astore #10
    //   5: iconst_1
    //   6: newarray int
    //   8: astore #12
    //   10: aload_0
    //   11: invokeinterface getInt : ()I
    //   16: istore #14
    //   18: aload_1
    //   19: invokeinterface getInt : ()I
    //   24: istore #13
    //   26: aload #10
    //   28: iconst_0
    //   29: bipush #106
    //   31: iastore
    //   32: aload #12
    //   34: iconst_0
    //   35: iload #13
    //   37: sipush #200
    //   40: invokestatic max : (II)I
    //   43: iastore
    //   44: iload #13
    //   46: i2d
    //   47: aload_2
    //   48: invokeinterface getDouble : ()D
    //   53: dmul
    //   54: ldc2_w 1.0E-5
    //   57: dadd
    //   58: invokestatic floor : (D)D
    //   61: d2i
    //   62: iload #13
    //   64: invokestatic min : (II)I
    //   67: istore #11
    //   69: iload #11
    //   71: ifle -> 77
    //   74: goto -> 117
    //   77: new org/renjin/gcc/runtime/BytePtr
    //   80: dup
    //   81: ldc 'stats '
    //   83: invokevirtual getBytes : ()[B
    //   86: iconst_0
    //   87: invokespecial <init> : ([BI)V
    //   90: new org/renjin/gcc/runtime/BytePtr
    //   93: dup
    //   94: ldc_w 'span is too small '
    //   97: invokevirtual getBytes : ()[B
    //   100: iconst_0
    //   101: invokespecial <init> : ([BI)V
    //   104: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
    //   107: checkcast org/renjin/gcc/runtime/BytePtr
    //   110: iconst_0
    //   111: anewarray java/lang/Object
    //   114: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
    //   117: aload_3
    //   118: invokeinterface getInt : ()I
    //   123: iconst_1
    //   124: if_icmpgt -> 130
    //   127: goto -> 150
    //   130: iload #14
    //   132: iconst_2
    //   133: iadd
    //   134: iload #14
    //   136: iconst_1
    //   137: iadd
    //   138: imul
    //   139: i2d
    //   140: ldc2_w 0.5
    //   143: dmul
    //   144: d2i
    //   145: istore #15
    //   147: goto -> 156
    //   150: iload #14
    //   152: iconst_1
    //   153: iadd
    //   154: istore #15
    //   156: iload #15
    //   158: aload #6
    //   160: invokeinterface getInt : ()I
    //   165: isub
    //   166: putstatic org/renjin/stats/loessc__.tau : I
    //   169: iload #14
    //   171: iconst_1
    //   172: iadd
    //   173: iconst_3
    //   174: imul
    //   175: aload #12
    //   177: iconst_0
    //   178: iaload
    //   179: imul
    //   180: bipush #50
    //   182: iadd
    //   183: iload #13
    //   185: iadd
    //   186: iload #15
    //   188: iconst_2
    //   189: iadd
    //   190: iload #11
    //   192: imul
    //   193: iadd
    //   194: putstatic org/renjin/stats/loessc__.lv : I
    //   197: ldc2_w 2.0
    //   200: iload #14
    //   202: i2d
    //   203: invokestatic pow : (DD)D
    //   206: ldc2_w 4.0
    //   209: dadd
    //   210: aload #12
    //   212: iconst_0
    //   213: iaload
    //   214: i2d
    //   215: dmul
    //   216: ldc2_w 50.0
    //   219: dadd
    //   220: iload #13
    //   222: i2d
    //   223: ldc2_w 2.0
    //   226: dmul
    //   227: dadd
    //   228: dstore #8
    //   230: dload #8
    //   232: ldc2_w 2.147483647E9
    //   235: dcmpg
    //   236: iflt -> 242
    //   239: goto -> 261
    //   242: dload #8
    //   244: d2i
    //   245: putstatic org/renjin/stats/loessc__.liv : I
    //   248: aload #7
    //   250: invokeinterface getInt : ()I
    //   255: ifne -> 282
    //   258: goto -> 315
    //   261: new org/renjin/gcc/runtime/BytePtr
    //   264: dup
    //   265: ldc_w 'workspace required is too large '
    //   268: invokevirtual getBytes : ()[B
    //   271: iconst_0
    //   272: invokespecial <init> : ([BI)V
    //   275: iconst_0
    //   276: anewarray java/lang/Object
    //   279: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
    //   282: iload #14
    //   284: iconst_1
    //   285: iadd
    //   286: iload #11
    //   288: imul
    //   289: aload #12
    //   291: iconst_0
    //   292: iaload
    //   293: imul
    //   294: getstatic org/renjin/stats/loessc__.lv : I
    //   297: iadd
    //   298: putstatic org/renjin/stats/loessc__.lv : I
    //   301: iload #11
    //   303: aload #12
    //   305: iconst_0
    //   306: iaload
    //   307: imul
    //   308: getstatic org/renjin/stats/loessc__.liv : I
    //   311: iadd
    //   312: putstatic org/renjin/stats/loessc__.liv : I
    //   315: getstatic org/renjin/stats/loessc__.liv : I
    //   318: iconst_4
    //   319: imul
    //   320: invokestatic malloc : (I)Lorg/renjin/gcc/runtime/IntPtr;
    //   323: putstatic org/renjin/stats/loessc__.iv : Lorg/renjin/gcc/runtime/Ptr;
    //   326: getstatic org/renjin/stats/loessc__.lv : I
    //   329: bipush #8
    //   331: imul
    //   332: invokestatic malloc : (I)Lorg/renjin/gcc/runtime/DoublePtr;
    //   335: putstatic org/renjin/stats/loessc__.v : Lorg/renjin/gcc/runtime/Ptr;
    //   338: getstatic org/renjin/stats/loessc__.v : Lorg/renjin/gcc/runtime/Ptr;
    //   341: astore #11
    //   343: getstatic org/renjin/stats/loessc__.iv : Lorg/renjin/gcc/runtime/Ptr;
    //   346: astore #6
    //   348: new org/renjin/gcc/runtime/IntPtr
    //   351: dup
    //   352: aload #10
    //   354: iconst_0
    //   355: invokespecial <init> : ([II)V
    //   358: checkcast org/renjin/gcc/runtime/Ptr
    //   361: aload #6
    //   363: ldc org/renjin/stats/loessc__
    //   365: ldc 'liv'
    //   367: invokestatic addressOf : (Ljava/lang/Class;Ljava/lang/String;)Lorg/renjin/gcc/runtime/Ptr;
    //   370: ldc org/renjin/stats/loessc__
    //   372: ldc 'lv'
    //   374: invokestatic addressOf : (Ljava/lang/Class;Ljava/lang/String;)Lorg/renjin/gcc/runtime/Ptr;
    //   377: aload #11
    //   379: aload_0
    //   380: aload_1
    //   381: aload_2
    //   382: aload_3
    //   383: new org/renjin/gcc/runtime/IntPtr
    //   386: dup
    //   387: aload #12
    //   389: iconst_0
    //   390: invokespecial <init> : ([II)V
    //   393: checkcast org/renjin/gcc/runtime/Ptr
    //   396: aload #7
    //   398: invokestatic lowesd_ : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)V
    //   401: getstatic org/renjin/stats/loessc__.iv : Lorg/renjin/gcc/runtime/Ptr;
    //   404: sipush #128
    //   407: aload #4
    //   409: invokeinterface getInt : ()I
    //   414: invokeinterface setInt : (II)V
    //   419: iconst_0
    //   420: istore_0
    //   421: goto -> 453
    //   424: getstatic org/renjin/stats/loessc__.iv : Lorg/renjin/gcc/runtime/Ptr;
    //   427: iconst_0
    //   428: iload_0
    //   429: bipush #40
    //   431: iadd
    //   432: iconst_4
    //   433: imul
    //   434: iadd
    //   435: aload #5
    //   437: iload_0
    //   438: iconst_4
    //   439: imul
    //   440: invokeinterface getInt : (I)I
    //   445: invokeinterface setInt : (II)V
    //   450: iinc #0, 1
    //   453: iload_0
    //   454: iload #14
    //   456: if_icmplt -> 424
    //   459: return
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/stats-0.9.2724.jar!/org/renjin/stats/loessc__.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */