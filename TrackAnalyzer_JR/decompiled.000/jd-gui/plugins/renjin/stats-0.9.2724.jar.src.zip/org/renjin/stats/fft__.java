package org.renjin.stats;

import org.renjin.gcc.runtime.Mathlib;
import org.renjin.gcc.runtime.Ptr;
import org.renjin.gnur.api.Rmath;

public class fft__ {
  static {
  
  }
  
  public static void fft_factor(Ptr paramPtr1, int paramInt, Ptr paramPtr2, Ptr paramPtr3) {
    if (paramInt > 0) {
      paramPtr1.setInt(paramInt);
      paramPtr1.setAlignedInt(21, 0);
      int i = paramInt;
      if (paramInt != 1) {
        while ((i & 0xF) == 0) {
          paramInt = paramPtr1.getAlignedInt(21) * 4 + 4;
          paramPtr1.setInt(paramInt, 4);
          paramPtr1.setAlignedInt(21, paramPtr1.getAlignedInt(21) + 1);
          i /= 16;
        } 
        int j = 0;
        paramInt = (int)Mathlib.sqrt(i);
        int k;
        for (k = 3; k <= paramInt; k += 2) {
          int m = k * k;
          while (i % m == 0) {
            j = paramPtr1.getAlignedInt(21) * 4 + 4;
            paramPtr1.setInt(j, k);
            paramPtr1.setAlignedInt(21, paramPtr1.getAlignedInt(21) + 1);
            i /= m;
            j = 1;
          } 
          if (j != 0) {
            j = 0;
            paramInt = (int)Mathlib.sqrt(i);
          } 
        } 
        if (i > 4) {
          if ((i & 0x3) == 0) {
            paramInt = paramPtr1.getAlignedInt(21) * 4 + 4;
            paramPtr1.setInt(paramInt, 2);
            paramPtr1.setAlignedInt(21, paramPtr1.getAlignedInt(21) + 1);
            i /= 4;
          } 
          paramPtr1.setAlignedInt(22, paramPtr1.getAlignedInt(21));
          paramPtr1.setAlignedInt(24, Rmath.Rf_imax2(paramPtr1.getAlignedInt(22) + paramPtr1.getAlignedInt(22) + 2, i + -1));
          k = 2;
          while (true) {
            if (i % k == 0) {
              paramInt = paramPtr1.getAlignedInt(21) * 4 + 4;
              paramPtr1.setInt(paramInt, k);
              paramPtr1.setAlignedInt(21, paramPtr1.getAlignedInt(21) + 1);
              i /= k;
            } 
            if (k <= 2147483645) {
              k = (k + 1) / 2 * 2 + 1;
              if (k > i)
                break; 
              continue;
            } 
            break;
          } 
        } else {
          paramPtr1.setAlignedInt(22, paramPtr1.getAlignedInt(21));
          paramPtr1.setInt(4 + paramPtr1.getAlignedInt(21) * 4, i);
          if (i != 1)
            paramPtr1.setAlignedInt(21, paramPtr1.getAlignedInt(21) + 1); 
        } 
        if (paramPtr1.getAlignedInt(21) <= paramPtr1.getAlignedInt(22) + 1)
          paramPtr1.setAlignedInt(24, paramPtr1.getAlignedInt(21) + paramPtr1.getAlignedInt(22) + 1); 
        if (paramPtr1.getAlignedInt(21) + paramPtr1.getAlignedInt(22) <= 20) {
          if (paramPtr1.getAlignedInt(22) != 0) {
            i = paramPtr1.getAlignedInt(22);
            while (i != 0) {
              i--;
              paramInt = paramPtr1.getAlignedInt(21) * 4 + 4;
              paramPtr1.setInt(paramInt, paramPtr1.getInt(4 + i * 4));
              paramPtr1.setAlignedInt(21, paramPtr1.getAlignedInt(21) + 1);
            } 
          } 
          paramPtr1.setAlignedInt(23, paramPtr1.getInt(4 + (paramPtr1.getAlignedInt(21) - paramPtr1.getAlignedInt(22) + -1) * 4));
          if (paramPtr1.getAlignedInt(22) > 0) {
            paramInt = paramPtr1.getAlignedInt(23);
            paramPtr1.setAlignedInt(23, Rmath.Rf_imax2(paramPtr1.getInt(4 + (paramPtr1.getAlignedInt(22) + -1) * 4), paramInt));
          } 
          if (paramPtr1.getAlignedInt(22) > 1) {
            paramInt = paramPtr1.getAlignedInt(23);
            paramPtr1.setAlignedInt(23, Rmath.Rf_imax2(paramPtr1.getInt(4 + (paramPtr1.getAlignedInt(22) + -2) * 4), paramInt));
          } 
          if (paramPtr1.getAlignedInt(22) > 2) {
            paramInt = paramPtr1.getAlignedInt(23);
            paramPtr1.setAlignedInt(23, Rmath.Rf_imax2(paramPtr1.getInt(4 + (paramPtr1.getAlignedInt(22) + -3) * 4), paramInt));
          } 
          paramPtr2.setInt(paramPtr1.getAlignedInt(23));
          paramPtr3.setInt(paramPtr1.getAlignedInt(24));
          return;
        } 
        paramPtr1.setInt(0);
        paramPtr2.setInt(0);
        paramPtr3.setInt(0);
      } 
      return;
    } 
    paramPtr1.setInt(0);
    paramPtr2.setInt(0);
    paramPtr3.setInt(0);
  }
  
  public static int fft_work(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, int paramInt1, int paramInt2, int paramInt3, int paramInt4, Ptr paramPtr4, Ptr paramPtr5) {
    if (paramPtr1.getInt() != 0) {
      if (paramPtr1.getInt() == paramInt2 && paramInt1 > 0 && paramInt3 > 0 && paramInt4 != 0) {
        int i = paramInt2 * paramInt3;
        int j = paramPtr1.getAlignedInt(22);
        i = paramPtr1.getAlignedInt(21);
        Ptr ptr1 = paramPtr4.pointerPlus(paramPtr1.getAlignedInt(23) * 8);
        Ptr ptr2 = paramPtr4.pointerPlus(paramPtr1.getAlignedInt(23) * 16);
        Ptr ptr3 = paramPtr4.pointerPlus(paramPtr1.getAlignedInt(23) * 24);
        fftmx(paramPtr2, paramPtr3, i * paramInt1, paramInt2, i, paramInt4, i, j, paramPtr4, ptr1, ptr2, ptr3, paramPtr5, paramPtr1.pointerPlus(4));
        return 1;
      } 
      return 0;
    } 
    return 0;
  }
  
  public static void fftmx(Ptr paramPtr1, Ptr paramPtr2, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8) {
    // Byte code:
    //   0: dconst_0
    //   1: dstore #21
    //   3: dconst_0
    //   4: dstore #23
    //   6: dconst_0
    //   7: dstore #25
    //   9: dconst_0
    //   10: dstore #27
    //   12: iconst_0
    //   13: istore #29
    //   15: aload_0
    //   16: bipush #-8
    //   18: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   23: astore_0
    //   24: aload_1
    //   25: bipush #-8
    //   27: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   32: astore_1
    //   33: aload #8
    //   35: bipush #-8
    //   37: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   42: astore #8
    //   44: aload #9
    //   46: bipush #-8
    //   48: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   53: astore #30
    //   55: aload #10
    //   57: bipush #-8
    //   59: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   64: astore #9
    //   66: aload #11
    //   68: bipush #-8
    //   70: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   75: astore #31
    //   77: aload #12
    //   79: bipush #-4
    //   81: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   86: astore #10
    //   88: aload #13
    //   90: bipush #-4
    //   92: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   97: astore #32
    //   99: iload #5
    //   101: invokestatic abs : (I)I
    //   104: istore #11
    //   106: iload #11
    //   108: iload_2
    //   109: imul
    //   110: istore #12
    //   112: iload #11
    //   114: iload #4
    //   116: imul
    //   117: istore #33
    //   119: ldc2_w 0.7853981633974483
    //   122: dstore #34
    //   124: ldc2_w 1.2566370614359172
    //   127: invokestatic cos : (D)D
    //   130: dstore #36
    //   132: ldc2_w 1.2566370614359172
    //   135: invokestatic sin : (D)D
    //   138: dstore #38
    //   140: ldc2_w 0.8660254037844386
    //   143: dstore #40
    //   145: iload #5
    //   147: ifle -> 153
    //   150: goto -> 168
    //   153: dload #38
    //   155: dneg
    //   156: dstore #38
    //   158: ldc2_w -0.8660254037844386
    //   161: dstore #40
    //   163: ldc2_w -0.7853981633974483
    //   166: dstore #34
    //   168: iload #33
    //   170: istore #42
    //   172: iload #12
    //   174: iload #11
    //   176: isub
    //   177: istore #43
    //   179: iload #33
    //   181: iload_3
    //   182: idiv
    //   183: istore #4
    //   185: bipush #32
    //   187: iload #4
    //   189: imul
    //   190: istore #44
    //   192: iconst_0
    //   193: istore #45
    //   195: iconst_0
    //   196: istore #46
    //   198: aload #32
    //   200: iload #6
    //   202: iload #7
    //   204: isub
    //   205: iconst_4
    //   206: imul
    //   207: invokeinterface getInt : (I)I
    //   212: istore #13
    //   214: iload #7
    //   216: ifgt -> 222
    //   219: goto -> 240
    //   222: aload #32
    //   224: iload #7
    //   226: iconst_4
    //   227: imul
    //   228: invokeinterface getInt : (I)I
    //   233: iload #13
    //   235: invokestatic Rf_imax2 : (II)I
    //   238: istore #13
    //   240: iload #4
    //   242: i2d
    //   243: ldc2_w 8.0
    //   246: dmul
    //   247: iload #42
    //   249: i2d
    //   250: ddiv
    //   251: dstore #47
    //   253: dload #47
    //   255: ldc2_w 0.5
    //   258: dmul
    //   259: dload #34
    //   261: dmul
    //   262: invokestatic sin : (D)D
    //   265: dup2
    //   266: ldc2_w 2.0
    //   269: dmul
    //   270: dmul
    //   271: dstore #49
    //   273: dload #47
    //   275: dload #34
    //   277: dmul
    //   278: invokestatic sin : (D)D
    //   281: dstore #51
    //   283: iconst_1
    //   284: istore #53
    //   286: iinc #45, 1
    //   289: aload #32
    //   291: iload #45
    //   293: iconst_4
    //   294: imul
    //   295: invokeinterface getInt : (I)I
    //   300: iconst_2
    //   301: if_icmpne -> 1144
    //   304: iload #42
    //   306: iconst_2
    //   307: idiv
    //   308: istore #42
    //   310: iload #42
    //   312: iconst_2
    //   313: iadd
    //   314: istore #54
    //   316: iload #53
    //   318: iload #42
    //   320: iadd
    //   321: istore #14
    //   323: aload_0
    //   324: aload_0
    //   325: iload #14
    //   327: bipush #8
    //   329: imul
    //   330: invokeinterface getDouble : (I)D
    //   335: dstore #55
    //   337: aload_1
    //   338: iload #14
    //   340: bipush #8
    //   342: imul
    //   343: invokeinterface getDouble : (I)D
    //   348: dstore #57
    //   350: iload #14
    //   352: bipush #8
    //   354: imul
    //   355: aload_0
    //   356: iload #53
    //   358: bipush #8
    //   360: imul
    //   361: invokeinterface getDouble : (I)D
    //   366: dload #55
    //   368: dsub
    //   369: invokeinterface setDouble : (ID)V
    //   374: aload_1
    //   375: iload #14
    //   377: bipush #8
    //   379: imul
    //   380: aload_1
    //   381: iload #53
    //   383: bipush #8
    //   385: imul
    //   386: invokeinterface getDouble : (I)D
    //   391: dload #57
    //   393: dsub
    //   394: invokeinterface setDouble : (ID)V
    //   399: aload_0
    //   400: iload #53
    //   402: bipush #8
    //   404: imul
    //   405: aload_0
    //   406: iload #53
    //   408: bipush #8
    //   410: imul
    //   411: invokeinterface getDouble : (I)D
    //   416: dload #55
    //   418: dadd
    //   419: invokeinterface setDouble : (ID)V
    //   424: aload_1
    //   425: iload #53
    //   427: bipush #8
    //   429: imul
    //   430: aload_1
    //   431: iload #53
    //   433: bipush #8
    //   435: imul
    //   436: invokeinterface getDouble : (I)D
    //   441: dload #57
    //   443: dadd
    //   444: invokeinterface setDouble : (ID)V
    //   449: iload #14
    //   451: iload #42
    //   453: iadd
    //   454: istore #53
    //   456: iload #53
    //   458: iload #43
    //   460: if_icmple -> 316
    //   463: iload #53
    //   465: iload #43
    //   467: isub
    //   468: istore #53
    //   470: iload #53
    //   472: iload #4
    //   474: if_icmple -> 316
    //   477: iload #53
    //   479: iload #42
    //   481: if_icmpgt -> 3693
    //   484: dconst_1
    //   485: dload #49
    //   487: dsub
    //   488: dstore #55
    //   490: dload #51
    //   492: dstore #57
    //   494: iload #54
    //   496: iconst_2
    //   497: idiv
    //   498: iload #44
    //   500: invokestatic Rf_imin2 : (II)I
    //   503: istore #14
    //   505: goto -> 540
    //   508: dload #55
    //   510: dload #49
    //   512: dload #55
    //   514: dmul
    //   515: dload #51
    //   517: dload #57
    //   519: dmul
    //   520: dadd
    //   521: dsub
    //   522: dload #51
    //   524: dload #55
    //   526: dmul
    //   527: dload #49
    //   529: dload #57
    //   531: dmul
    //   532: dsub
    //   533: dload #57
    //   535: dadd
    //   536: dstore #57
    //   538: dstore #55
    //   540: iload #53
    //   542: iload #42
    //   544: iadd
    //   545: istore #59
    //   547: aload_1
    //   548: iload #59
    //   550: bipush #8
    //   552: imul
    //   553: dload #57
    //   555: aload_0
    //   556: iload #59
    //   558: bipush #8
    //   560: imul
    //   561: dload #55
    //   563: aload_0
    //   564: iload #53
    //   566: bipush #8
    //   568: imul
    //   569: invokeinterface getDouble : (I)D
    //   574: aload_0
    //   575: iload #59
    //   577: bipush #8
    //   579: imul
    //   580: invokeinterface getDouble : (I)D
    //   585: dsub
    //   586: dstore #19
    //   588: dload #19
    //   590: aload_1
    //   591: iload #53
    //   593: bipush #8
    //   595: imul
    //   596: invokeinterface getDouble : (I)D
    //   601: aload_1
    //   602: iload #59
    //   604: bipush #8
    //   606: imul
    //   607: invokeinterface getDouble : (I)D
    //   612: dsub
    //   613: dstore #17
    //   615: aload_0
    //   616: iload #53
    //   618: bipush #8
    //   620: imul
    //   621: aload_0
    //   622: iload #53
    //   624: bipush #8
    //   626: imul
    //   627: invokeinterface getDouble : (I)D
    //   632: aload_0
    //   633: iload #59
    //   635: bipush #8
    //   637: imul
    //   638: invokeinterface getDouble : (I)D
    //   643: dadd
    //   644: invokeinterface setDouble : (ID)V
    //   649: aload_1
    //   650: iload #53
    //   652: bipush #8
    //   654: imul
    //   655: aload_1
    //   656: iload #53
    //   658: bipush #8
    //   660: imul
    //   661: invokeinterface getDouble : (I)D
    //   666: aload_1
    //   667: iload #59
    //   669: bipush #8
    //   671: imul
    //   672: invokeinterface getDouble : (I)D
    //   677: dadd
    //   678: invokeinterface setDouble : (ID)V
    //   683: dmul
    //   684: dload #57
    //   686: dload #17
    //   688: dmul
    //   689: dsub
    //   690: invokeinterface setDouble : (ID)V
    //   695: dload #19
    //   697: dmul
    //   698: dload #55
    //   700: dload #17
    //   702: dmul
    //   703: dadd
    //   704: invokeinterface setDouble : (ID)V
    //   709: iload #59
    //   711: iload #42
    //   713: iadd
    //   714: istore #53
    //   716: iload #53
    //   718: iload #12
    //   720: if_icmplt -> 540
    //   723: iload #53
    //   725: iload #12
    //   727: isub
    //   728: istore #59
    //   730: dload #55
    //   732: dneg
    //   733: dstore #55
    //   735: iload #54
    //   737: iload #59
    //   739: isub
    //   740: istore #53
    //   742: iload #53
    //   744: iload #59
    //   746: if_icmpgt -> 540
    //   749: iload #53
    //   751: iload #4
    //   753: iadd
    //   754: istore #53
    //   756: iload #53
    //   758: iload #14
    //   760: if_icmple -> 508
    //   763: iload #53
    //   765: iload #59
    //   767: if_icmpge -> 773
    //   770: goto -> 808
    //   773: iload #54
    //   775: iload #11
    //   777: iadd
    //   778: iload #11
    //   780: iadd
    //   781: istore #54
    //   783: iload #54
    //   785: iload #42
    //   787: isub
    //   788: iconst_2
    //   789: idiv
    //   790: iload #4
    //   792: iadd
    //   793: istore #53
    //   795: iload #4
    //   797: iload #4
    //   799: iadd
    //   800: iload #53
    //   802: if_icmpge -> 484
    //   805: goto -> 240
    //   808: iload #53
    //   810: iconst_m1
    //   811: iadd
    //   812: iload #4
    //   814: idiv
    //   815: i2d
    //   816: dload #47
    //   818: dmul
    //   819: dload #34
    //   821: dmul
    //   822: dup2
    //   823: invokestatic cos : (D)D
    //   826: dstore #55
    //   828: invokestatic sin : (D)D
    //   831: dstore #57
    //   833: iload #54
    //   835: iconst_2
    //   836: idiv
    //   837: iload #14
    //   839: iload #44
    //   841: iadd
    //   842: invokestatic Rf_imin2 : (II)I
    //   845: istore #14
    //   847: goto -> 540
    //   850: iload #53
    //   852: iload #42
    //   854: iadd
    //   855: istore #14
    //   857: iload #14
    //   859: iload #42
    //   861: iadd
    //   862: istore #59
    //   864: aload_0
    //   865: iload #53
    //   867: bipush #8
    //   869: imul
    //   870: aload_0
    //   871: iload #53
    //   873: bipush #8
    //   875: imul
    //   876: invokeinterface getDouble : (I)D
    //   881: dstore #55
    //   883: dload #55
    //   885: aload_1
    //   886: iload #53
    //   888: bipush #8
    //   890: imul
    //   891: invokeinterface getDouble : (I)D
    //   896: dstore #21
    //   898: aload_0
    //   899: iload #14
    //   901: bipush #8
    //   903: imul
    //   904: invokeinterface getDouble : (I)D
    //   909: aload_0
    //   910: iload #59
    //   912: bipush #8
    //   914: imul
    //   915: invokeinterface getDouble : (I)D
    //   920: dadd
    //   921: dstore #57
    //   923: dload #57
    //   925: aload_1
    //   926: iload #14
    //   928: bipush #8
    //   930: imul
    //   931: invokeinterface getDouble : (I)D
    //   936: aload_1
    //   937: iload #59
    //   939: bipush #8
    //   941: imul
    //   942: invokeinterface getDouble : (I)D
    //   947: dadd
    //   948: dstore #25
    //   950: dadd
    //   951: invokeinterface setDouble : (ID)V
    //   956: aload_1
    //   957: iload #53
    //   959: bipush #8
    //   961: imul
    //   962: dload #21
    //   964: dload #25
    //   966: dadd
    //   967: invokeinterface setDouble : (ID)V
    //   972: aload_0
    //   973: iload #59
    //   975: bipush #8
    //   977: imul
    //   978: dload #55
    //   980: dload #57
    //   982: ldc2_w -0.5
    //   985: dmul
    //   986: dadd
    //   987: dup2
    //   988: aload_0
    //   989: iload #14
    //   991: bipush #8
    //   993: imul
    //   994: invokeinterface getDouble : (I)D
    //   999: aload_0
    //   1000: iload #59
    //   1002: bipush #8
    //   1004: imul
    //   1005: invokeinterface getDouble : (I)D
    //   1010: dsub
    //   1011: dload #40
    //   1013: dmul
    //   1014: dstore #55
    //   1016: aload_1
    //   1017: iload #14
    //   1019: bipush #8
    //   1021: imul
    //   1022: invokeinterface getDouble : (I)D
    //   1027: aload_1
    //   1028: iload #59
    //   1030: bipush #8
    //   1032: imul
    //   1033: invokeinterface getDouble : (I)D
    //   1038: dsub
    //   1039: dload #40
    //   1041: dmul
    //   1042: dstore #57
    //   1044: dload #57
    //   1046: dsub
    //   1047: dstore #19
    //   1049: aload_0
    //   1050: iload #14
    //   1052: bipush #8
    //   1054: imul
    //   1055: dload #19
    //   1057: invokeinterface setDouble : (ID)V
    //   1062: aload_1
    //   1063: iload #14
    //   1065: bipush #8
    //   1067: imul
    //   1068: dload #25
    //   1070: ldc2_w -0.5
    //   1073: dmul
    //   1074: dload #21
    //   1076: dadd
    //   1077: dstore #21
    //   1079: dload #21
    //   1081: dload #55
    //   1083: dadd
    //   1084: invokeinterface setDouble : (ID)V
    //   1089: dload #57
    //   1091: dadd
    //   1092: invokeinterface setDouble : (ID)V
    //   1097: aload_1
    //   1098: iload #59
    //   1100: bipush #8
    //   1102: imul
    //   1103: dload #21
    //   1105: dload #55
    //   1107: dsub
    //   1108: invokeinterface setDouble : (ID)V
    //   1113: iload #59
    //   1115: iload #42
    //   1117: iadd
    //   1118: istore #53
    //   1120: iload #53
    //   1122: iload #43
    //   1124: if_icmplt -> 850
    //   1127: iload #53
    //   1129: iload #43
    //   1131: isub
    //   1132: istore #53
    //   1134: iload #53
    //   1136: iload #42
    //   1138: if_icmple -> 850
    //   1141: goto -> 3379
    //   1144: aload #32
    //   1146: iload #45
    //   1148: iconst_4
    //   1149: imul
    //   1150: invokeinterface getInt : (I)I
    //   1155: iconst_4
    //   1156: if_icmpne -> 2523
    //   1159: iload #42
    //   1161: iconst_4
    //   1162: idiv
    //   1163: istore #42
    //   1165: dconst_1
    //   1166: dstore #55
    //   1168: dconst_0
    //   1169: dstore #57
    //   1171: iload #42
    //   1173: iload #44
    //   1175: invokestatic Rf_imin2 : (II)I
    //   1178: istore #54
    //   1180: goto -> 1265
    //   1183: dload #55
    //   1185: dload #49
    //   1187: dload #55
    //   1189: dmul
    //   1190: dload #51
    //   1192: dload #57
    //   1194: dmul
    //   1195: dadd
    //   1196: dsub
    //   1197: dload #51
    //   1199: dload #55
    //   1201: dmul
    //   1202: dload #49
    //   1204: dload #57
    //   1206: dmul
    //   1207: dsub
    //   1208: dload #57
    //   1210: dadd
    //   1211: dstore #57
    //   1213: dstore #55
    //   1215: dload #55
    //   1217: dload #55
    //   1219: dmul
    //   1220: dload #57
    //   1222: dload #57
    //   1224: dmul
    //   1225: dsub
    //   1226: dstore #21
    //   1228: dload #55
    //   1230: dload #57
    //   1232: dmul
    //   1233: ldc2_w 2.0
    //   1236: dmul
    //   1237: dstore #25
    //   1239: dload #21
    //   1241: dload #55
    //   1243: dmul
    //   1244: dload #25
    //   1246: dload #57
    //   1248: dmul
    //   1249: dsub
    //   1250: dstore #23
    //   1252: dload #21
    //   1254: dload #57
    //   1256: dmul
    //   1257: dload #25
    //   1259: dload #55
    //   1261: dmul
    //   1262: dadd
    //   1263: dstore #27
    //   1265: iload #53
    //   1267: iload #42
    //   1269: iadd
    //   1270: istore #14
    //   1272: iload #14
    //   1274: iload #42
    //   1276: iadd
    //   1277: istore #59
    //   1279: iload #59
    //   1281: iload #42
    //   1283: iadd
    //   1284: istore #29
    //   1286: aload_0
    //   1287: iload #53
    //   1289: bipush #8
    //   1291: imul
    //   1292: invokeinterface getDouble : (I)D
    //   1297: aload_0
    //   1298: iload #59
    //   1300: bipush #8
    //   1302: imul
    //   1303: invokeinterface getDouble : (I)D
    //   1308: dadd
    //   1309: dup2
    //   1310: aload_0
    //   1311: iload #53
    //   1313: bipush #8
    //   1315: imul
    //   1316: invokeinterface getDouble : (I)D
    //   1321: aload_0
    //   1322: iload #59
    //   1324: bipush #8
    //   1326: imul
    //   1327: invokeinterface getDouble : (I)D
    //   1332: dsub
    //   1333: dstore #60
    //   1335: aload_0
    //   1336: iload #14
    //   1338: bipush #8
    //   1340: imul
    //   1341: invokeinterface getDouble : (I)D
    //   1346: aload_0
    //   1347: iload #29
    //   1349: bipush #8
    //   1351: imul
    //   1352: invokeinterface getDouble : (I)D
    //   1357: dadd
    //   1358: dstore #62
    //   1360: dload #62
    //   1362: aload_0
    //   1363: iload #14
    //   1365: bipush #8
    //   1367: imul
    //   1368: invokeinterface getDouble : (I)D
    //   1373: aload_0
    //   1374: iload #29
    //   1376: bipush #8
    //   1378: imul
    //   1379: invokeinterface getDouble : (I)D
    //   1384: dsub
    //   1385: dstore #19
    //   1387: dadd
    //   1388: dstore #17
    //   1390: aload_0
    //   1391: iload #53
    //   1393: bipush #8
    //   1395: imul
    //   1396: dload #17
    //   1398: invokeinterface setDouble : (ID)V
    //   1403: dload #62
    //   1405: dsub
    //   1406: dstore #17
    //   1408: aload_1
    //   1409: iload #53
    //   1411: bipush #8
    //   1413: imul
    //   1414: invokeinterface getDouble : (I)D
    //   1419: aload_1
    //   1420: iload #59
    //   1422: bipush #8
    //   1424: imul
    //   1425: invokeinterface getDouble : (I)D
    //   1430: dadd
    //   1431: dup2
    //   1432: aload_1
    //   1433: iload #53
    //   1435: bipush #8
    //   1437: imul
    //   1438: invokeinterface getDouble : (I)D
    //   1443: aload_1
    //   1444: iload #59
    //   1446: bipush #8
    //   1448: imul
    //   1449: invokeinterface getDouble : (I)D
    //   1454: dsub
    //   1455: dstore #62
    //   1457: aload_1
    //   1458: iload #14
    //   1460: bipush #8
    //   1462: imul
    //   1463: invokeinterface getDouble : (I)D
    //   1468: aload_1
    //   1469: iload #29
    //   1471: bipush #8
    //   1473: imul
    //   1474: invokeinterface getDouble : (I)D
    //   1479: dadd
    //   1480: dstore #64
    //   1482: dload #64
    //   1484: aload_1
    //   1485: iload #14
    //   1487: bipush #8
    //   1489: imul
    //   1490: invokeinterface getDouble : (I)D
    //   1495: aload_1
    //   1496: iload #29
    //   1498: bipush #8
    //   1500: imul
    //   1501: invokeinterface getDouble : (I)D
    //   1506: dsub
    //   1507: dstore #66
    //   1509: dadd
    //   1510: dstore #15
    //   1512: aload_1
    //   1513: iload #53
    //   1515: bipush #8
    //   1517: imul
    //   1518: dload #15
    //   1520: invokeinterface setDouble : (ID)V
    //   1525: dload #64
    //   1527: dsub
    //   1528: dstore #15
    //   1530: iload #5
    //   1532: iflt -> 1767
    //   1535: dload #60
    //   1537: dload #66
    //   1539: dsub
    //   1540: dstore #64
    //   1542: dload #60
    //   1544: dload #66
    //   1546: dadd
    //   1547: dstore #60
    //   1549: dload #62
    //   1551: dload #19
    //   1553: dadd
    //   1554: dstore #66
    //   1556: dload #62
    //   1558: dload #19
    //   1560: dsub
    //   1561: dstore #19
    //   1563: dload #57
    //   1565: dconst_0
    //   1566: dcmpl
    //   1567: ifeq -> 1802
    //   1570: aload_0
    //   1571: iload #14
    //   1573: bipush #8
    //   1575: imul
    //   1576: dload #64
    //   1578: dload #55
    //   1580: dmul
    //   1581: dload #66
    //   1583: dload #57
    //   1585: dmul
    //   1586: dsub
    //   1587: invokeinterface setDouble : (ID)V
    //   1592: aload_1
    //   1593: iload #14
    //   1595: bipush #8
    //   1597: imul
    //   1598: dload #64
    //   1600: dload #57
    //   1602: dmul
    //   1603: dload #66
    //   1605: dload #55
    //   1607: dmul
    //   1608: dadd
    //   1609: invokeinterface setDouble : (ID)V
    //   1614: aload_0
    //   1615: iload #59
    //   1617: bipush #8
    //   1619: imul
    //   1620: dload #17
    //   1622: dload #21
    //   1624: dmul
    //   1625: dload #15
    //   1627: dload #25
    //   1629: dmul
    //   1630: dsub
    //   1631: invokeinterface setDouble : (ID)V
    //   1636: aload_1
    //   1637: iload #59
    //   1639: bipush #8
    //   1641: imul
    //   1642: dload #17
    //   1644: dload #25
    //   1646: dmul
    //   1647: dload #15
    //   1649: dload #21
    //   1651: dmul
    //   1652: dadd
    //   1653: invokeinterface setDouble : (ID)V
    //   1658: aload_0
    //   1659: iload #29
    //   1661: bipush #8
    //   1663: imul
    //   1664: dload #60
    //   1666: dload #23
    //   1668: dmul
    //   1669: dload #19
    //   1671: dload #27
    //   1673: dmul
    //   1674: dsub
    //   1675: invokeinterface setDouble : (ID)V
    //   1680: aload_1
    //   1681: iload #29
    //   1683: bipush #8
    //   1685: imul
    //   1686: dload #60
    //   1688: dload #27
    //   1690: dmul
    //   1691: dload #19
    //   1693: dload #23
    //   1695: dmul
    //   1696: dadd
    //   1697: invokeinterface setDouble : (ID)V
    //   1702: iload #29
    //   1704: iload #42
    //   1706: iadd
    //   1707: istore #53
    //   1709: iload #53
    //   1711: iload #12
    //   1713: if_icmple -> 1265
    //   1716: iload #53
    //   1718: iload #12
    //   1720: isub
    //   1721: iload #4
    //   1723: iadd
    //   1724: istore #53
    //   1726: iload #53
    //   1728: iload #54
    //   1730: if_icmple -> 1183
    //   1733: iload #53
    //   1735: iload #42
    //   1737: if_icmplt -> 1897
    //   1740: iload #53
    //   1742: iload #42
    //   1744: isub
    //   1745: iload #11
    //   1747: iadd
    //   1748: istore #53
    //   1750: iload #53
    //   1752: iload #4
    //   1754: if_icmple -> 1165
    //   1757: iload #42
    //   1759: iload #4
    //   1761: if_icmpeq -> 3693
    //   1764: goto -> 240
    //   1767: dload #60
    //   1769: dload #66
    //   1771: dadd
    //   1772: dstore #64
    //   1774: dload #60
    //   1776: dload #66
    //   1778: dsub
    //   1779: dstore #60
    //   1781: dload #62
    //   1783: dload #19
    //   1785: dsub
    //   1786: dstore #66
    //   1788: dload #62
    //   1790: dload #19
    //   1792: dadd
    //   1793: dstore #19
    //   1795: dload #57
    //   1797: dconst_0
    //   1798: dcmpl
    //   1799: ifne -> 1570
    //   1802: aload_0
    //   1803: iload #14
    //   1805: bipush #8
    //   1807: imul
    //   1808: dload #64
    //   1810: invokeinterface setDouble : (ID)V
    //   1815: aload_1
    //   1816: iload #14
    //   1818: bipush #8
    //   1820: imul
    //   1821: dload #66
    //   1823: invokeinterface setDouble : (ID)V
    //   1828: aload_0
    //   1829: iload #59
    //   1831: bipush #8
    //   1833: imul
    //   1834: dload #17
    //   1836: invokeinterface setDouble : (ID)V
    //   1841: aload_1
    //   1842: iload #59
    //   1844: bipush #8
    //   1846: imul
    //   1847: dload #15
    //   1849: invokeinterface setDouble : (ID)V
    //   1854: aload_0
    //   1855: iload #29
    //   1857: bipush #8
    //   1859: imul
    //   1860: dload #60
    //   1862: invokeinterface setDouble : (ID)V
    //   1867: aload_1
    //   1868: iload #29
    //   1870: bipush #8
    //   1872: imul
    //   1873: dload #19
    //   1875: invokeinterface setDouble : (ID)V
    //   1880: iload #29
    //   1882: iload #42
    //   1884: iadd
    //   1885: istore #53
    //   1887: iload #53
    //   1889: iload #12
    //   1891: if_icmple -> 1265
    //   1894: goto -> 1716
    //   1897: iload #53
    //   1899: iconst_m1
    //   1900: iadd
    //   1901: iload #4
    //   1903: idiv
    //   1904: i2d
    //   1905: dload #47
    //   1907: dmul
    //   1908: dload #34
    //   1910: dmul
    //   1911: dup2
    //   1912: invokestatic cos : (D)D
    //   1915: dstore #55
    //   1917: invokestatic sin : (D)D
    //   1920: dstore #57
    //   1922: iload #42
    //   1924: iload #54
    //   1926: iload #44
    //   1928: iadd
    //   1929: invokestatic Rf_imin2 : (II)I
    //   1932: istore #54
    //   1934: goto -> 1215
    //   1937: dload #36
    //   1939: dload #36
    //   1941: dmul
    //   1942: dload #38
    //   1944: dload #38
    //   1946: dmul
    //   1947: dsub
    //   1948: dstore #21
    //   1950: dload #36
    //   1952: ldc2_w 2.0
    //   1955: dmul
    //   1956: dload #38
    //   1958: dmul
    //   1959: dstore #25
    //   1961: iload #53
    //   1963: iload #42
    //   1965: iadd
    //   1966: istore #59
    //   1968: iload #59
    //   1970: iload #42
    //   1972: iadd
    //   1973: istore #68
    //   1975: iload #68
    //   1977: iload #42
    //   1979: iadd
    //   1980: istore #29
    //   1982: iload #29
    //   1984: iload #42
    //   1986: iadd
    //   1987: istore #14
    //   1989: aload_0
    //   1990: iload #59
    //   1992: bipush #8
    //   1994: imul
    //   1995: invokeinterface getDouble : (I)D
    //   2000: aload_0
    //   2001: iload #14
    //   2003: bipush #8
    //   2005: imul
    //   2006: invokeinterface getDouble : (I)D
    //   2011: dadd
    //   2012: dstore #62
    //   2014: aload_1
    //   2015: aload_0
    //   2016: iload #59
    //   2018: bipush #8
    //   2020: imul
    //   2021: invokeinterface getDouble : (I)D
    //   2026: aload_0
    //   2027: iload #14
    //   2029: bipush #8
    //   2031: imul
    //   2032: invokeinterface getDouble : (I)D
    //   2037: dsub
    //   2038: dup2
    //   2039: aload_1
    //   2040: iload #59
    //   2042: bipush #8
    //   2044: imul
    //   2045: invokeinterface getDouble : (I)D
    //   2050: aload_1
    //   2051: iload #14
    //   2053: bipush #8
    //   2055: imul
    //   2056: invokeinterface getDouble : (I)D
    //   2061: dadd
    //   2062: dstore #55
    //   2064: aload_1
    //   2065: iload #59
    //   2067: bipush #8
    //   2069: imul
    //   2070: invokeinterface getDouble : (I)D
    //   2075: aload_1
    //   2076: iload #14
    //   2078: bipush #8
    //   2080: imul
    //   2081: invokeinterface getDouble : (I)D
    //   2086: dsub
    //   2087: dstore #17
    //   2089: aload_0
    //   2090: iload #68
    //   2092: bipush #8
    //   2094: imul
    //   2095: invokeinterface getDouble : (I)D
    //   2100: aload_0
    //   2101: iload #29
    //   2103: bipush #8
    //   2105: imul
    //   2106: invokeinterface getDouble : (I)D
    //   2111: dadd
    //   2112: dstore #15
    //   2114: aload_0
    //   2115: iload #68
    //   2117: bipush #8
    //   2119: imul
    //   2120: invokeinterface getDouble : (I)D
    //   2125: aload_0
    //   2126: iload #29
    //   2128: bipush #8
    //   2130: imul
    //   2131: invokeinterface getDouble : (I)D
    //   2136: dsub
    //   2137: dstore #66
    //   2139: aload_1
    //   2140: iload #68
    //   2142: bipush #8
    //   2144: imul
    //   2145: invokeinterface getDouble : (I)D
    //   2150: aload_1
    //   2151: iload #29
    //   2153: bipush #8
    //   2155: imul
    //   2156: invokeinterface getDouble : (I)D
    //   2161: dadd
    //   2162: dstore #57
    //   2164: aload_1
    //   2165: iload #68
    //   2167: bipush #8
    //   2169: imul
    //   2170: invokeinterface getDouble : (I)D
    //   2175: aload_1
    //   2176: iload #29
    //   2178: bipush #8
    //   2180: imul
    //   2181: invokeinterface getDouble : (I)D
    //   2186: dsub
    //   2187: dstore #60
    //   2189: aload_0
    //   2190: iload #53
    //   2192: bipush #8
    //   2194: imul
    //   2195: invokeinterface getDouble : (I)D
    //   2200: dstore #64
    //   2202: aload_1
    //   2203: iload #53
    //   2205: bipush #8
    //   2207: imul
    //   2208: invokeinterface getDouble : (I)D
    //   2213: dstore #19
    //   2215: aload_0
    //   2216: iload #53
    //   2218: bipush #8
    //   2220: imul
    //   2221: dload #64
    //   2223: dload #62
    //   2225: dadd
    //   2226: dload #15
    //   2228: dadd
    //   2229: invokeinterface setDouble : (ID)V
    //   2234: aload_1
    //   2235: iload #53
    //   2237: bipush #8
    //   2239: imul
    //   2240: dload #19
    //   2242: dload #55
    //   2244: dadd
    //   2245: dload #57
    //   2247: dadd
    //   2248: invokeinterface setDouble : (ID)V
    //   2253: dload #38
    //   2255: dmul
    //   2256: dload #66
    //   2258: dload #25
    //   2260: dmul
    //   2261: dadd
    //   2262: dstore #71
    //   2264: aload_0
    //   2265: iload #59
    //   2267: bipush #8
    //   2269: imul
    //   2270: dload #62
    //   2272: dload #36
    //   2274: dmul
    //   2275: dload #15
    //   2277: dload #21
    //   2279: dmul
    //   2280: dadd
    //   2281: dload #64
    //   2283: dadd
    //   2284: dstore #69
    //   2286: dload #69
    //   2288: dload #17
    //   2290: dload #38
    //   2292: dmul
    //   2293: dload #60
    //   2295: dload #25
    //   2297: dmul
    //   2298: dadd
    //   2299: dstore #73
    //   2301: dload #73
    //   2303: dsub
    //   2304: invokeinterface setDouble : (ID)V
    //   2309: aload_0
    //   2310: iload #14
    //   2312: bipush #8
    //   2314: imul
    //   2315: dload #69
    //   2317: dload #73
    //   2319: dadd
    //   2320: invokeinterface setDouble : (ID)V
    //   2325: aload_1
    //   2326: iload #59
    //   2328: bipush #8
    //   2330: imul
    //   2331: dload #71
    //   2333: dload #55
    //   2335: dload #36
    //   2337: dmul
    //   2338: dload #57
    //   2340: dload #21
    //   2342: dmul
    //   2343: dadd
    //   2344: dload #19
    //   2346: dadd
    //   2347: dstore #69
    //   2349: dload #69
    //   2351: dadd
    //   2352: invokeinterface setDouble : (ID)V
    //   2357: aload_1
    //   2358: iload #14
    //   2360: bipush #8
    //   2362: imul
    //   2363: dload #69
    //   2365: dload #71
    //   2367: dsub
    //   2368: invokeinterface setDouble : (ID)V
    //   2373: dload #25
    //   2375: dmul
    //   2376: dload #66
    //   2378: dload #38
    //   2380: dmul
    //   2381: dsub
    //   2382: dstore #66
    //   2384: aload_0
    //   2385: iload #68
    //   2387: bipush #8
    //   2389: imul
    //   2390: dload #62
    //   2392: dload #21
    //   2394: dmul
    //   2395: dload #15
    //   2397: dload #36
    //   2399: dmul
    //   2400: dadd
    //   2401: dload #64
    //   2403: dadd
    //   2404: dstore #62
    //   2406: dload #62
    //   2408: dload #17
    //   2410: dload #25
    //   2412: dmul
    //   2413: dload #60
    //   2415: dload #38
    //   2417: dmul
    //   2418: dsub
    //   2419: dstore #17
    //   2421: dload #17
    //   2423: dsub
    //   2424: invokeinterface setDouble : (ID)V
    //   2429: aload_0
    //   2430: iload #29
    //   2432: bipush #8
    //   2434: imul
    //   2435: dload #62
    //   2437: dload #17
    //   2439: dadd
    //   2440: invokeinterface setDouble : (ID)V
    //   2445: iload #68
    //   2447: bipush #8
    //   2449: imul
    //   2450: dload #66
    //   2452: dload #55
    //   2454: dload #21
    //   2456: dmul
    //   2457: dload #57
    //   2459: dload #36
    //   2461: dmul
    //   2462: dadd
    //   2463: dload #19
    //   2465: dadd
    //   2466: dstore #55
    //   2468: dload #55
    //   2470: dadd
    //   2471: invokeinterface setDouble : (ID)V
    //   2476: aload_1
    //   2477: iload #29
    //   2479: bipush #8
    //   2481: imul
    //   2482: dload #55
    //   2484: dload #66
    //   2486: dsub
    //   2487: invokeinterface setDouble : (ID)V
    //   2492: iload #14
    //   2494: iload #42
    //   2496: iadd
    //   2497: istore #53
    //   2499: iload #53
    //   2501: iload #43
    //   2503: if_icmplt -> 1961
    //   2506: iload #53
    //   2508: iload #43
    //   2510: isub
    //   2511: istore #53
    //   2513: iload #53
    //   2515: iload #42
    //   2517: if_icmple -> 1961
    //   2520: goto -> 3379
    //   2523: aload #32
    //   2525: iload #45
    //   2527: iconst_4
    //   2528: imul
    //   2529: invokeinterface getInt : (I)I
    //   2534: istore #14
    //   2536: iload #42
    //   2538: istore #54
    //   2540: iload #42
    //   2542: iload #14
    //   2544: idiv
    //   2545: istore #42
    //   2547: iload #14
    //   2549: iconst_3
    //   2550: if_icmpeq -> 850
    //   2553: iload #14
    //   2555: iconst_5
    //   2556: if_icmpeq -> 1937
    //   2559: iload #14
    //   2561: iload #46
    //   2563: if_icmpeq -> 2771
    //   2566: iload #14
    //   2568: istore #46
    //   2570: dload #34
    //   2572: iload #14
    //   2574: i2d
    //   2575: ldc2_w 8.0
    //   2578: ddiv
    //   2579: ddiv
    //   2580: dup2
    //   2581: invokestatic cos : (D)D
    //   2584: dstore #21
    //   2586: invokestatic sin : (D)D
    //   2589: dstore #25
    //   2591: aload #30
    //   2593: iload #14
    //   2595: bipush #8
    //   2597: imul
    //   2598: dconst_1
    //   2599: invokeinterface setDouble : (ID)V
    //   2604: aload #31
    //   2606: iload #14
    //   2608: bipush #8
    //   2610: imul
    //   2611: dconst_0
    //   2612: invokeinterface setDouble : (ID)V
    //   2617: iconst_1
    //   2618: istore #59
    //   2620: goto -> 2764
    //   2623: aload #30
    //   2625: iload #59
    //   2627: bipush #8
    //   2629: imul
    //   2630: aload #30
    //   2632: iload #14
    //   2634: bipush #8
    //   2636: imul
    //   2637: invokeinterface getDouble : (I)D
    //   2642: dload #21
    //   2644: dmul
    //   2645: aload #31
    //   2647: iload #14
    //   2649: bipush #8
    //   2651: imul
    //   2652: invokeinterface getDouble : (I)D
    //   2657: dload #25
    //   2659: dmul
    //   2660: dadd
    //   2661: invokeinterface setDouble : (ID)V
    //   2666: aload #31
    //   2668: iload #59
    //   2670: bipush #8
    //   2672: imul
    //   2673: aload #30
    //   2675: iload #14
    //   2677: bipush #8
    //   2679: imul
    //   2680: invokeinterface getDouble : (I)D
    //   2685: dload #25
    //   2687: dmul
    //   2688: aload #31
    //   2690: iload #14
    //   2692: bipush #8
    //   2694: imul
    //   2695: invokeinterface getDouble : (I)D
    //   2700: dload #21
    //   2702: dmul
    //   2703: dsub
    //   2704: invokeinterface setDouble : (ID)V
    //   2709: iinc #14, -1
    //   2712: aload #30
    //   2714: iload #14
    //   2716: bipush #8
    //   2718: imul
    //   2719: aload #30
    //   2721: iload #59
    //   2723: bipush #8
    //   2725: imul
    //   2726: invokeinterface getDouble : (I)D
    //   2731: invokeinterface setDouble : (ID)V
    //   2736: aload #31
    //   2738: iload #14
    //   2740: bipush #8
    //   2742: imul
    //   2743: aload #31
    //   2745: iload #59
    //   2747: bipush #8
    //   2749: imul
    //   2750: invokeinterface getDouble : (I)D
    //   2755: dneg
    //   2756: invokeinterface setDouble : (ID)V
    //   2761: iinc #59, 1
    //   2764: iload #59
    //   2766: iload #14
    //   2768: if_icmplt -> 2623
    //   2771: iload #53
    //   2773: iload #54
    //   2775: iadd
    //   2776: istore #14
    //   2778: aload_0
    //   2779: iload #53
    //   2781: bipush #8
    //   2783: imul
    //   2784: invokeinterface getDouble : (I)D
    //   2789: dstore #21
    //   2791: aload_1
    //   2792: iload #53
    //   2794: bipush #8
    //   2796: imul
    //   2797: invokeinterface getDouble : (I)D
    //   2802: dstore #25
    //   2804: dload #21
    //   2806: dstore #55
    //   2808: dload #25
    //   2810: dstore #57
    //   2812: iconst_1
    //   2813: istore #68
    //   2815: iload #53
    //   2817: iload #42
    //   2819: iadd
    //   2820: istore #59
    //   2822: iload #14
    //   2824: iload #42
    //   2826: isub
    //   2827: istore #14
    //   2829: iload #68
    //   2831: iconst_1
    //   2832: iadd
    //   2833: istore #68
    //   2835: aload #8
    //   2837: iload #68
    //   2839: bipush #8
    //   2841: imul
    //   2842: aload_0
    //   2843: iload #59
    //   2845: bipush #8
    //   2847: imul
    //   2848: invokeinterface getDouble : (I)D
    //   2853: aload_0
    //   2854: iload #14
    //   2856: bipush #8
    //   2858: imul
    //   2859: invokeinterface getDouble : (I)D
    //   2864: dadd
    //   2865: invokeinterface setDouble : (ID)V
    //   2870: aload #8
    //   2872: iload #68
    //   2874: bipush #8
    //   2876: imul
    //   2877: invokeinterface getDouble : (I)D
    //   2882: dload #55
    //   2884: dadd
    //   2885: dstore #55
    //   2887: aload #9
    //   2889: iload #68
    //   2891: bipush #8
    //   2893: imul
    //   2894: aload_1
    //   2895: iload #59
    //   2897: bipush #8
    //   2899: imul
    //   2900: invokeinterface getDouble : (I)D
    //   2905: aload_1
    //   2906: iload #14
    //   2908: bipush #8
    //   2910: imul
    //   2911: invokeinterface getDouble : (I)D
    //   2916: dadd
    //   2917: invokeinterface setDouble : (ID)V
    //   2922: aload #9
    //   2924: iload #68
    //   2926: bipush #8
    //   2928: imul
    //   2929: invokeinterface getDouble : (I)D
    //   2934: dload #57
    //   2936: dadd
    //   2937: dstore #57
    //   2939: iload #68
    //   2941: iconst_1
    //   2942: iadd
    //   2943: istore #68
    //   2945: aload #8
    //   2947: iload #68
    //   2949: bipush #8
    //   2951: imul
    //   2952: aload_0
    //   2953: iload #59
    //   2955: bipush #8
    //   2957: imul
    //   2958: invokeinterface getDouble : (I)D
    //   2963: aload_0
    //   2964: iload #14
    //   2966: bipush #8
    //   2968: imul
    //   2969: invokeinterface getDouble : (I)D
    //   2974: dsub
    //   2975: invokeinterface setDouble : (ID)V
    //   2980: aload #9
    //   2982: iload #68
    //   2984: bipush #8
    //   2986: imul
    //   2987: aload_1
    //   2988: iload #59
    //   2990: bipush #8
    //   2992: imul
    //   2993: invokeinterface getDouble : (I)D
    //   2998: aload_1
    //   2999: iload #14
    //   3001: bipush #8
    //   3003: imul
    //   3004: invokeinterface getDouble : (I)D
    //   3009: dsub
    //   3010: invokeinterface setDouble : (ID)V
    //   3015: iload #59
    //   3017: iload #42
    //   3019: iadd
    //   3020: istore #59
    //   3022: iload #59
    //   3024: iload #14
    //   3026: if_icmplt -> 2822
    //   3029: aload_0
    //   3030: iload #53
    //   3032: bipush #8
    //   3034: imul
    //   3035: dload #55
    //   3037: invokeinterface setDouble : (ID)V
    //   3042: aload_1
    //   3043: iload #53
    //   3045: bipush #8
    //   3047: imul
    //   3048: dload #57
    //   3050: invokeinterface setDouble : (ID)V
    //   3055: iload #53
    //   3057: istore #14
    //   3059: iload #53
    //   3061: iload #54
    //   3063: iadd
    //   3064: istore #59
    //   3066: iconst_1
    //   3067: istore #68
    //   3069: iload #14
    //   3071: iload #42
    //   3073: iadd
    //   3074: istore #14
    //   3076: iload #59
    //   3078: iload #42
    //   3080: isub
    //   3081: istore #59
    //   3083: iload #68
    //   3085: istore #75
    //   3087: dload #21
    //   3089: dstore #55
    //   3091: dload #25
    //   3093: dstore #57
    //   3095: dconst_0
    //   3096: dstore #19
    //   3098: dconst_0
    //   3099: dstore #17
    //   3101: iconst_2
    //   3102: istore #76
    //   3104: goto -> 3263
    //   3107: aload #8
    //   3109: iload #76
    //   3111: bipush #8
    //   3113: imul
    //   3114: invokeinterface getDouble : (I)D
    //   3119: aload #30
    //   3121: iload #75
    //   3123: bipush #8
    //   3125: imul
    //   3126: invokeinterface getDouble : (I)D
    //   3131: dmul
    //   3132: dload #55
    //   3134: dadd
    //   3135: dstore #55
    //   3137: aload #9
    //   3139: iload #76
    //   3141: bipush #8
    //   3143: imul
    //   3144: invokeinterface getDouble : (I)D
    //   3149: aload #30
    //   3151: iload #75
    //   3153: bipush #8
    //   3155: imul
    //   3156: invokeinterface getDouble : (I)D
    //   3161: dmul
    //   3162: dload #57
    //   3164: dadd
    //   3165: dstore #57
    //   3167: iload #76
    //   3169: iconst_1
    //   3170: iadd
    //   3171: istore #76
    //   3173: aload #8
    //   3175: iload #76
    //   3177: bipush #8
    //   3179: imul
    //   3180: invokeinterface getDouble : (I)D
    //   3185: aload #31
    //   3187: iload #75
    //   3189: bipush #8
    //   3191: imul
    //   3192: invokeinterface getDouble : (I)D
    //   3197: dmul
    //   3198: dload #19
    //   3200: dadd
    //   3201: dstore #19
    //   3203: aload #9
    //   3205: iload #76
    //   3207: bipush #8
    //   3209: imul
    //   3210: invokeinterface getDouble : (I)D
    //   3215: aload #31
    //   3217: iload #75
    //   3219: bipush #8
    //   3221: imul
    //   3222: invokeinterface getDouble : (I)D
    //   3227: dmul
    //   3228: dload #17
    //   3230: dadd
    //   3231: dstore #17
    //   3233: iload #75
    //   3235: iload #68
    //   3237: iadd
    //   3238: istore #75
    //   3240: iload #75
    //   3242: iload #46
    //   3244: if_icmpgt -> 3250
    //   3247: goto -> 3257
    //   3250: iload #75
    //   3252: iload #46
    //   3254: isub
    //   3255: istore #75
    //   3257: iload #76
    //   3259: iconst_1
    //   3260: iadd
    //   3261: istore #76
    //   3263: iload #76
    //   3265: iload #46
    //   3267: if_icmplt -> 3107
    //   3270: iload #46
    //   3272: iload #68
    //   3274: isub
    //   3275: istore #75
    //   3277: aload_0
    //   3278: iload #14
    //   3280: bipush #8
    //   3282: imul
    //   3283: dload #55
    //   3285: dload #17
    //   3287: dsub
    //   3288: invokeinterface setDouble : (ID)V
    //   3293: aload_1
    //   3294: iload #14
    //   3296: bipush #8
    //   3298: imul
    //   3299: dload #57
    //   3301: dload #19
    //   3303: dadd
    //   3304: invokeinterface setDouble : (ID)V
    //   3309: aload_0
    //   3310: iload #59
    //   3312: bipush #8
    //   3314: imul
    //   3315: dload #55
    //   3317: dload #17
    //   3319: dadd
    //   3320: invokeinterface setDouble : (ID)V
    //   3325: aload_1
    //   3326: iload #59
    //   3328: bipush #8
    //   3330: imul
    //   3331: dload #57
    //   3333: dload #19
    //   3335: dsub
    //   3336: invokeinterface setDouble : (ID)V
    //   3341: iinc #68, 1
    //   3344: iload #68
    //   3346: iload #75
    //   3348: if_icmplt -> 3069
    //   3351: iload #53
    //   3353: iload #54
    //   3355: iadd
    //   3356: istore #53
    //   3358: iload #53
    //   3360: iload #43
    //   3362: if_icmple -> 2771
    //   3365: iload #53
    //   3367: iload #43
    //   3369: isub
    //   3370: istore #53
    //   3372: iload #53
    //   3374: iload #42
    //   3376: if_icmple -> 2771
    //   3379: iload #45
    //   3381: iload #6
    //   3383: if_icmpeq -> 3693
    //   3386: iload #4
    //   3388: iconst_1
    //   3389: iadd
    //   3390: istore #14
    //   3392: dconst_1
    //   3393: dload #49
    //   3395: dsub
    //   3396: dstore #21
    //   3398: dload #51
    //   3400: dstore #55
    //   3402: iload #42
    //   3404: iload #44
    //   3406: invokestatic Rf_imin2 : (II)I
    //   3409: istore #53
    //   3411: dload #21
    //   3413: dstore #57
    //   3415: dload #55
    //   3417: dstore #25
    //   3419: iload #14
    //   3421: iload #42
    //   3423: iadd
    //   3424: istore #14
    //   3426: aload_1
    //   3427: iload #14
    //   3429: bipush #8
    //   3431: imul
    //   3432: dload #25
    //   3434: aload_0
    //   3435: iload #14
    //   3437: bipush #8
    //   3439: imul
    //   3440: dload #21
    //   3442: aload_0
    //   3443: iload #14
    //   3445: bipush #8
    //   3447: imul
    //   3448: invokeinterface getDouble : (I)D
    //   3453: dstore #19
    //   3455: dload #19
    //   3457: dmul
    //   3458: aload_1
    //   3459: iload #14
    //   3461: bipush #8
    //   3463: imul
    //   3464: invokeinterface getDouble : (I)D
    //   3469: dload #25
    //   3471: dmul
    //   3472: dsub
    //   3473: invokeinterface setDouble : (ID)V
    //   3478: dload #19
    //   3480: dmul
    //   3481: aload_1
    //   3482: iload #14
    //   3484: bipush #8
    //   3486: imul
    //   3487: invokeinterface getDouble : (I)D
    //   3492: dload #21
    //   3494: dmul
    //   3495: dadd
    //   3496: invokeinterface setDouble : (ID)V
    //   3501: iload #14
    //   3503: iload #54
    //   3505: iadd
    //   3506: istore #14
    //   3508: iload #14
    //   3510: iload #12
    //   3512: if_icmple -> 3426
    //   3515: dload #55
    //   3517: dload #25
    //   3519: dmul
    //   3520: dstore #19
    //   3522: dload #55
    //   3524: dload #21
    //   3526: dmul
    //   3527: dload #57
    //   3529: dload #25
    //   3531: dmul
    //   3532: dadd
    //   3533: dstore #25
    //   3535: dload #57
    //   3537: dload #21
    //   3539: dmul
    //   3540: dload #19
    //   3542: dsub
    //   3543: dstore #21
    //   3545: iload #42
    //   3547: iload #12
    //   3549: isub
    //   3550: iload #14
    //   3552: iadd
    //   3553: istore #14
    //   3555: iload #14
    //   3557: iload #54
    //   3559: if_icmple -> 3426
    //   3562: iload #4
    //   3564: iload #54
    //   3566: isub
    //   3567: iload #14
    //   3569: iadd
    //   3570: istore #14
    //   3572: iload #14
    //   3574: iload #53
    //   3576: if_icmple -> 3582
    //   3579: goto -> 3617
    //   3582: dload #57
    //   3584: dload #49
    //   3586: dload #57
    //   3588: dmul
    //   3589: dload #51
    //   3591: dload #55
    //   3593: dmul
    //   3594: dadd
    //   3595: dsub
    //   3596: dstore #21
    //   3598: dload #51
    //   3600: dload #57
    //   3602: dmul
    //   3603: dload #49
    //   3605: dload #55
    //   3607: dmul
    //   3608: dsub
    //   3609: dload #55
    //   3611: dadd
    //   3612: dstore #55
    //   3614: goto -> 3411
    //   3617: iload #14
    //   3619: iload #42
    //   3621: if_icmpge -> 3627
    //   3624: goto -> 3653
    //   3627: iload #14
    //   3629: iload #42
    //   3631: isub
    //   3632: iload #4
    //   3634: iadd
    //   3635: iload #11
    //   3637: iadd
    //   3638: istore #14
    //   3640: iload #4
    //   3642: iload #4
    //   3644: iadd
    //   3645: iload #14
    //   3647: if_icmpge -> 3392
    //   3650: goto -> 240
    //   3653: iload #14
    //   3655: iconst_m1
    //   3656: iadd
    //   3657: iload #4
    //   3659: idiv
    //   3660: i2d
    //   3661: dload #47
    //   3663: dmul
    //   3664: dload #34
    //   3666: dmul
    //   3667: dup2
    //   3668: invokestatic cos : (D)D
    //   3671: dstore #21
    //   3673: invokestatic sin : (D)D
    //   3676: dstore #55
    //   3678: iload #42
    //   3680: iload #53
    //   3682: iload #44
    //   3684: iadd
    //   3685: invokestatic Rf_imin2 : (II)I
    //   3688: istore #53
    //   3690: goto -> 3411
    //   3693: aload #10
    //   3695: iconst_4
    //   3696: iload #33
    //   3698: invokeinterface setInt : (II)V
    //   3703: iload #7
    //   3705: ifeq -> 4362
    //   3708: iload #7
    //   3710: iload #7
    //   3712: iadd
    //   3713: iconst_1
    //   3714: iadd
    //   3715: istore #5
    //   3717: iload #6
    //   3719: iload #5
    //   3721: if_icmplt -> 3727
    //   3724: goto -> 3730
    //   3727: iinc #5, -1
    //   3730: aload #10
    //   3732: iload #5
    //   3734: iconst_1
    //   3735: iadd
    //   3736: iconst_4
    //   3737: imul
    //   3738: iload #4
    //   3740: invokeinterface setInt : (II)V
    //   3745: iconst_1
    //   3746: istore #29
    //   3748: goto -> 3829
    //   3751: aload #10
    //   3753: iload #29
    //   3755: iconst_1
    //   3756: iadd
    //   3757: iconst_4
    //   3758: imul
    //   3759: aload #10
    //   3761: iload #29
    //   3763: iconst_4
    //   3764: imul
    //   3765: invokeinterface getInt : (I)I
    //   3770: aload #32
    //   3772: iload #29
    //   3774: iconst_4
    //   3775: imul
    //   3776: invokeinterface getInt : (I)I
    //   3781: idiv
    //   3782: invokeinterface setInt : (II)V
    //   3787: aload #10
    //   3789: iload #5
    //   3791: iconst_4
    //   3792: imul
    //   3793: aload #10
    //   3795: iload #5
    //   3797: iconst_1
    //   3798: iadd
    //   3799: iconst_4
    //   3800: imul
    //   3801: invokeinterface getInt : (I)I
    //   3806: aload #32
    //   3808: iload #29
    //   3810: iconst_4
    //   3811: imul
    //   3812: invokeinterface getInt : (I)I
    //   3817: imul
    //   3818: invokeinterface setInt : (II)V
    //   3823: iinc #29, 1
    //   3826: iinc #5, -1
    //   3829: iload #29
    //   3831: iload #5
    //   3833: if_icmplt -> 3751
    //   3836: aload #10
    //   3838: iload #5
    //   3840: iconst_1
    //   3841: iadd
    //   3842: iconst_4
    //   3843: imul
    //   3844: invokeinterface getInt : (I)I
    //   3849: istore #29
    //   3851: aload #10
    //   3853: iconst_2
    //   3854: invokeinterface getAlignedInt : (I)I
    //   3859: istore #5
    //   3861: iload #4
    //   3863: iconst_1
    //   3864: iadd
    //   3865: istore #30
    //   3867: iload #5
    //   3869: iconst_1
    //   3870: iadd
    //   3871: istore #31
    //   3873: iconst_1
    //   3874: istore #42
    //   3876: iload_3
    //   3877: iload_2
    //   3878: if_icmpeq -> 3884
    //   3881: goto -> 4095
    //   3884: aload_0
    //   3885: aload_0
    //   3886: iload #30
    //   3888: bipush #8
    //   3890: imul
    //   3891: invokeinterface getDouble : (I)D
    //   3896: dstore #23
    //   3898: aload_0
    //   3899: iload #30
    //   3901: bipush #8
    //   3903: imul
    //   3904: aload_0
    //   3905: iload #31
    //   3907: bipush #8
    //   3909: imul
    //   3910: invokeinterface getDouble : (I)D
    //   3915: invokeinterface setDouble : (ID)V
    //   3920: iload #31
    //   3922: bipush #8
    //   3924: imul
    //   3925: dload #23
    //   3927: invokeinterface setDouble : (ID)V
    //   3932: aload_1
    //   3933: aload_1
    //   3934: iload #30
    //   3936: bipush #8
    //   3938: imul
    //   3939: invokeinterface getDouble : (I)D
    //   3944: dstore #23
    //   3946: aload_1
    //   3947: iload #30
    //   3949: bipush #8
    //   3951: imul
    //   3952: aload_1
    //   3953: iload #31
    //   3955: bipush #8
    //   3957: imul
    //   3958: invokeinterface getDouble : (I)D
    //   3963: invokeinterface setDouble : (ID)V
    //   3968: iload #31
    //   3970: bipush #8
    //   3972: imul
    //   3973: dload #23
    //   3975: invokeinterface setDouble : (ID)V
    //   3980: iload #30
    //   3982: iload #11
    //   3984: iadd
    //   3985: istore #30
    //   3987: iload #31
    //   3989: iload #5
    //   3991: iadd
    //   3992: istore #31
    //   3994: iload #31
    //   3996: iload #33
    //   3998: if_icmplt -> 3884
    //   4001: iload #31
    //   4003: aload #10
    //   4005: iload #42
    //   4007: iconst_4
    //   4008: imul
    //   4009: invokeinterface getInt : (I)I
    //   4014: isub
    //   4015: iinc #42, 1
    //   4018: aload #10
    //   4020: iload #42
    //   4022: iconst_1
    //   4023: iadd
    //   4024: iconst_4
    //   4025: imul
    //   4026: invokeinterface getInt : (I)I
    //   4031: iadd
    //   4032: istore #31
    //   4034: aload #10
    //   4036: iload #42
    //   4038: iconst_4
    //   4039: imul
    //   4040: invokeinterface getInt : (I)I
    //   4045: iload #31
    //   4047: if_icmplt -> 4001
    //   4050: iconst_1
    //   4051: istore #42
    //   4053: iload #30
    //   4055: iload #31
    //   4057: if_icmplt -> 3884
    //   4060: iload #30
    //   4062: iload #11
    //   4064: iadd
    //   4065: istore #30
    //   4067: iload #31
    //   4069: iload #5
    //   4071: iadd
    //   4072: istore #31
    //   4074: iload #31
    //   4076: iload #33
    //   4078: if_icmplt -> 4053
    //   4081: iload #30
    //   4083: iload #33
    //   4085: if_icmplt -> 4001
    //   4088: iload #29
    //   4090: istore #4
    //   4092: goto -> 4362
    //   4095: iload #30
    //   4097: iload #4
    //   4099: iadd
    //   4100: istore_2
    //   4101: aload_0
    //   4102: aload_0
    //   4103: iload #30
    //   4105: bipush #8
    //   4107: imul
    //   4108: invokeinterface getDouble : (I)D
    //   4113: dstore #23
    //   4115: aload_0
    //   4116: iload #30
    //   4118: bipush #8
    //   4120: imul
    //   4121: aload_0
    //   4122: iload #31
    //   4124: bipush #8
    //   4126: imul
    //   4127: invokeinterface getDouble : (I)D
    //   4132: invokeinterface setDouble : (ID)V
    //   4137: iload #31
    //   4139: bipush #8
    //   4141: imul
    //   4142: dload #23
    //   4144: invokeinterface setDouble : (ID)V
    //   4149: aload_1
    //   4150: aload_1
    //   4151: iload #30
    //   4153: bipush #8
    //   4155: imul
    //   4156: invokeinterface getDouble : (I)D
    //   4161: dstore #23
    //   4163: aload_1
    //   4164: iload #30
    //   4166: bipush #8
    //   4168: imul
    //   4169: aload_1
    //   4170: iload #31
    //   4172: bipush #8
    //   4174: imul
    //   4175: invokeinterface getDouble : (I)D
    //   4180: invokeinterface setDouble : (ID)V
    //   4185: iload #31
    //   4187: bipush #8
    //   4189: imul
    //   4190: dload #23
    //   4192: invokeinterface setDouble : (ID)V
    //   4197: iload #30
    //   4199: iload #11
    //   4201: iadd
    //   4202: istore #30
    //   4204: iload #31
    //   4206: iload #11
    //   4208: iadd
    //   4209: istore #31
    //   4211: iload #30
    //   4213: iload_2
    //   4214: if_icmplt -> 4101
    //   4217: iload #33
    //   4219: iload #4
    //   4221: isub
    //   4222: iload #30
    //   4224: iadd
    //   4225: istore #30
    //   4227: iload #33
    //   4229: iload #4
    //   4231: isub
    //   4232: iload #31
    //   4234: iadd
    //   4235: istore #31
    //   4237: iload #30
    //   4239: iload #12
    //   4241: if_icmplt -> 4095
    //   4244: iload #5
    //   4246: iload #12
    //   4248: isub
    //   4249: iload #31
    //   4251: iadd
    //   4252: istore #31
    //   4254: iload #4
    //   4256: iload #12
    //   4258: isub
    //   4259: iload #30
    //   4261: iadd
    //   4262: istore #30
    //   4264: iload #31
    //   4266: iload #33
    //   4268: if_icmplt -> 4095
    //   4271: iload #31
    //   4273: aload #10
    //   4275: iload #42
    //   4277: iconst_4
    //   4278: imul
    //   4279: invokeinterface getInt : (I)I
    //   4284: isub
    //   4285: iinc #42, 1
    //   4288: aload #10
    //   4290: iload #42
    //   4292: iconst_1
    //   4293: iadd
    //   4294: iconst_4
    //   4295: imul
    //   4296: invokeinterface getInt : (I)I
    //   4301: iadd
    //   4302: istore #31
    //   4304: aload #10
    //   4306: iload #42
    //   4308: iconst_4
    //   4309: imul
    //   4310: invokeinterface getInt : (I)I
    //   4315: iload #31
    //   4317: if_icmplt -> 4271
    //   4320: iconst_1
    //   4321: istore #42
    //   4323: iload #30
    //   4325: iload #31
    //   4327: if_icmplt -> 4095
    //   4330: iload #30
    //   4332: iload #4
    //   4334: iadd
    //   4335: istore #30
    //   4337: iload #31
    //   4339: iload #5
    //   4341: iadd
    //   4342: istore #31
    //   4344: iload #31
    //   4346: iload #33
    //   4348: if_icmplt -> 4323
    //   4351: iload #30
    //   4353: iload #33
    //   4355: if_icmplt -> 4271
    //   4358: iload #29
    //   4360: istore #4
    //   4362: iload #7
    //   4364: iconst_2
    //   4365: imul
    //   4366: iconst_1
    //   4367: iadd
    //   4368: iload #6
    //   4370: if_icmpge -> 5048
    //   4373: aload #10
    //   4375: iload #7
    //   4377: iconst_1
    //   4378: iadd
    //   4379: iconst_4
    //   4380: imul
    //   4381: invokeinterface getInt : (I)I
    //   4386: istore_2
    //   4387: iload #6
    //   4389: iload #7
    //   4391: isub
    //   4392: dup
    //   4393: iconst_1
    //   4394: iadd
    //   4395: iconst_4
    //   4396: imul
    //   4397: istore_3
    //   4398: aload #32
    //   4400: iload_3
    //   4401: iconst_1
    //   4402: invokeinterface setInt : (II)V
    //   4407: istore_3
    //   4408: goto -> 4447
    //   4411: aload #32
    //   4413: iload_3
    //   4414: iconst_4
    //   4415: imul
    //   4416: aload #32
    //   4418: iload_3
    //   4419: iconst_4
    //   4420: imul
    //   4421: invokeinterface getInt : (I)I
    //   4426: aload #32
    //   4428: iload_3
    //   4429: iconst_1
    //   4430: iadd
    //   4431: iconst_4
    //   4432: imul
    //   4433: invokeinterface getInt : (I)I
    //   4438: imul
    //   4439: invokeinterface setInt : (II)V
    //   4444: iinc #3, -1
    //   4447: iload_3
    //   4448: iload #7
    //   4450: if_icmpgt -> 4411
    //   4453: iload #7
    //   4455: iconst_1
    //   4456: iadd
    //   4457: istore #5
    //   4459: aload #32
    //   4461: iload #5
    //   4463: iconst_4
    //   4464: imul
    //   4465: invokeinterface getInt : (I)I
    //   4470: iconst_m1
    //   4471: iadd
    //   4472: istore_3
    //   4473: iconst_0
    //   4474: istore #6
    //   4476: iconst_0
    //   4477: istore #7
    //   4479: goto -> 4536
    //   4482: iload #6
    //   4484: iload #33
    //   4486: isub
    //   4487: istore #6
    //   4489: iload #31
    //   4491: istore #33
    //   4493: iinc #30, 1
    //   4496: aload #32
    //   4498: iload #30
    //   4500: iconst_4
    //   4501: imul
    //   4502: invokeinterface getInt : (I)I
    //   4507: istore #31
    //   4509: iload #6
    //   4511: iload #31
    //   4513: iadd
    //   4514: istore #6
    //   4516: iload #6
    //   4518: iload #33
    //   4520: if_icmpge -> 4482
    //   4523: aload #10
    //   4525: iload #7
    //   4527: iconst_4
    //   4528: imul
    //   4529: iload #6
    //   4531: invokeinterface setInt : (II)V
    //   4536: aload #32
    //   4538: iload #5
    //   4540: iconst_4
    //   4541: imul
    //   4542: invokeinterface getInt : (I)I
    //   4547: istore #33
    //   4549: iload #5
    //   4551: iconst_1
    //   4552: iadd
    //   4553: istore #30
    //   4555: aload #32
    //   4557: iload #30
    //   4559: iconst_4
    //   4560: imul
    //   4561: invokeinterface getInt : (I)I
    //   4566: istore #31
    //   4568: iinc #7, 1
    //   4571: iload #7
    //   4573: iload_3
    //   4574: if_icmple -> 4509
    //   4577: iconst_0
    //   4578: istore #5
    //   4580: goto -> 4621
    //   4583: aload #10
    //   4585: iload #6
    //   4587: aload #10
    //   4589: iload #6
    //   4591: iconst_4
    //   4592: imul
    //   4593: invokeinterface getInt : (I)I
    //   4598: istore #6
    //   4600: iconst_4
    //   4601: imul
    //   4602: iload #6
    //   4604: ineg
    //   4605: invokeinterface setInt : (II)V
    //   4610: iload #6
    //   4612: iload #5
    //   4614: if_icmpne -> 4583
    //   4617: iload #6
    //   4619: istore #29
    //   4621: iinc #5, 1
    //   4624: aload #10
    //   4626: iload #5
    //   4628: iconst_4
    //   4629: imul
    //   4630: invokeinterface getInt : (I)I
    //   4635: istore #6
    //   4637: iload #6
    //   4639: iflt -> 4621
    //   4642: iload #6
    //   4644: iload #5
    //   4646: if_icmpne -> 4583
    //   4649: aload #10
    //   4651: iload #5
    //   4653: iconst_4
    //   4654: imul
    //   4655: iload #5
    //   4657: ineg
    //   4658: invokeinterface setInt : (II)V
    //   4663: iload #5
    //   4665: iload_3
    //   4666: if_icmpne -> 4621
    //   4669: iload #13
    //   4671: iload #11
    //   4673: imul
    //   4674: istore_3
    //   4675: goto -> 5022
    //   4678: iinc #5, -1
    //   4681: aload #10
    //   4683: iload #5
    //   4685: iconst_4
    //   4686: imul
    //   4687: invokeinterface getInt : (I)I
    //   4692: iflt -> 4678
    //   4695: iload #4
    //   4697: istore #6
    //   4699: iload #6
    //   4701: iload_3
    //   4702: invokestatic Rf_imin2 : (II)I
    //   4705: istore #32
    //   4707: iload #6
    //   4709: iload #32
    //   4711: isub
    //   4712: istore #6
    //   4714: aload #10
    //   4716: iload #5
    //   4718: iconst_4
    //   4719: imul
    //   4720: invokeinterface getInt : (I)I
    //   4725: istore #33
    //   4727: iload #4
    //   4729: iload #33
    //   4731: imul
    //   4732: iload #13
    //   4734: iadd
    //   4735: iload #6
    //   4737: iadd
    //   4738: istore #7
    //   4740: iload #7
    //   4742: iload #32
    //   4744: iadd
    //   4745: istore #30
    //   4747: iconst_1
    //   4748: istore #31
    //   4750: goto -> 4809
    //   4753: aload #8
    //   4755: iload #31
    //   4757: bipush #8
    //   4759: imul
    //   4760: aload_0
    //   4761: iload #30
    //   4763: bipush #8
    //   4765: imul
    //   4766: invokeinterface getDouble : (I)D
    //   4771: invokeinterface setDouble : (ID)V
    //   4776: aload #9
    //   4778: iload #31
    //   4780: bipush #8
    //   4782: imul
    //   4783: aload_1
    //   4784: iload #30
    //   4786: bipush #8
    //   4788: imul
    //   4789: invokeinterface getDouble : (I)D
    //   4794: invokeinterface setDouble : (ID)V
    //   4799: iload #30
    //   4801: iload #11
    //   4803: isub
    //   4804: istore #30
    //   4806: iinc #31, 1
    //   4809: iload #30
    //   4811: iload #7
    //   4813: if_icmpne -> 4753
    //   4816: iload #7
    //   4818: iload #32
    //   4820: iadd
    //   4821: istore #30
    //   4823: iload #30
    //   4825: aload #10
    //   4827: iload #33
    //   4829: iconst_4
    //   4830: imul
    //   4831: invokeinterface getInt : (I)I
    //   4836: iload #33
    //   4838: iadd
    //   4839: iload #4
    //   4841: imul
    //   4842: isub
    //   4843: istore #31
    //   4845: aload #10
    //   4847: iload #33
    //   4849: iconst_4
    //   4850: imul
    //   4851: invokeinterface getInt : (I)I
    //   4856: ineg
    //   4857: istore #33
    //   4859: aload_0
    //   4860: iload #30
    //   4862: bipush #8
    //   4864: imul
    //   4865: aload_0
    //   4866: iload #31
    //   4868: bipush #8
    //   4870: imul
    //   4871: invokeinterface getDouble : (I)D
    //   4876: invokeinterface setDouble : (ID)V
    //   4881: aload_1
    //   4882: iload #30
    //   4884: bipush #8
    //   4886: imul
    //   4887: aload_1
    //   4888: iload #31
    //   4890: bipush #8
    //   4892: imul
    //   4893: invokeinterface getDouble : (I)D
    //   4898: invokeinterface setDouble : (ID)V
    //   4903: iload #30
    //   4905: iload #11
    //   4907: isub
    //   4908: istore #30
    //   4910: iload #31
    //   4912: iload #11
    //   4914: isub
    //   4915: istore #31
    //   4917: iload #30
    //   4919: iload #7
    //   4921: if_icmpne -> 4859
    //   4924: iload #31
    //   4926: istore #7
    //   4928: iload #33
    //   4930: iload #5
    //   4932: if_icmpne -> 4816
    //   4935: iload #31
    //   4937: iload #32
    //   4939: iadd
    //   4940: istore #32
    //   4942: iconst_1
    //   4943: istore #33
    //   4945: goto -> 5004
    //   4948: aload_0
    //   4949: iload #32
    //   4951: bipush #8
    //   4953: imul
    //   4954: aload #8
    //   4956: iload #33
    //   4958: bipush #8
    //   4960: imul
    //   4961: invokeinterface getDouble : (I)D
    //   4966: invokeinterface setDouble : (ID)V
    //   4971: aload_1
    //   4972: iload #32
    //   4974: bipush #8
    //   4976: imul
    //   4977: aload #9
    //   4979: iload #33
    //   4981: bipush #8
    //   4983: imul
    //   4984: invokeinterface getDouble : (I)D
    //   4989: invokeinterface setDouble : (ID)V
    //   4994: iload #32
    //   4996: iload #11
    //   4998: isub
    //   4999: istore #32
    //   5001: iinc #33, 1
    //   5004: iload #32
    //   5006: iload #7
    //   5008: if_icmpgt -> 4948
    //   5011: iload #6
    //   5013: ifne -> 4699
    //   5016: iload #5
    //   5018: iconst_1
    //   5019: if_icmpne -> 4678
    //   5022: iload #29
    //   5024: iconst_1
    //   5025: iadd
    //   5026: istore #5
    //   5028: iload #12
    //   5030: iload_2
    //   5031: isub
    //   5032: istore #12
    //   5034: iload #12
    //   5036: iload #11
    //   5038: isub
    //   5039: iconst_1
    //   5040: iadd
    //   5041: istore #13
    //   5043: iload #12
    //   5045: ifge -> 4678
    //   5048: return
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/stats-0.9.2724.jar!/org/renjin/stats/fft__.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */