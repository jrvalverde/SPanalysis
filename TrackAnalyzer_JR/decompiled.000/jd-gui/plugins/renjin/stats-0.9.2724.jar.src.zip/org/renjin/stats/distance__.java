package org.renjin.stats;

import org.renjin.gcc.runtime.Builtins;
import org.renjin.gcc.runtime.BytePtr;
import org.renjin.gcc.runtime.Mathlib;
import org.renjin.gcc.runtime.Ptr;
import org.renjin.gnur.api.Arith;
import org.renjin.gnur.api.Error;
import org.renjin.gnur.api.GetText;
import org.renjin.gnur.api.Rmath;

public class distance__ {
  static {
  
  }
  
  public static double R_canberra(Ptr paramPtr, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    // Byte code:
    //   0: iconst_0
    //   1: istore #9
    //   3: dconst_0
    //   4: dstore #10
    //   6: iconst_0
    //   7: istore #12
    //   9: goto -> 189
    //   12: aload_0
    //   13: iload_3
    //   14: bipush #8
    //   16: imul
    //   17: invokeinterface getDouble : (I)D
    //   22: invokestatic __isnan : (D)I
    //   25: ifeq -> 31
    //   28: goto -> 176
    //   31: aload_0
    //   32: iload #4
    //   34: bipush #8
    //   36: imul
    //   37: invokeinterface getDouble : (I)D
    //   42: invokestatic __isnan : (D)I
    //   45: ifeq -> 51
    //   48: goto -> 176
    //   51: aload_0
    //   52: iload_3
    //   53: bipush #8
    //   55: imul
    //   56: invokeinterface getDouble : (I)D
    //   61: aload_0
    //   62: iload #4
    //   64: bipush #8
    //   66: imul
    //   67: invokeinterface getDouble : (I)D
    //   72: dadd
    //   73: invokestatic abs : (D)D
    //   76: dstore #7
    //   78: aload_0
    //   79: iload_3
    //   80: bipush #8
    //   82: imul
    //   83: invokeinterface getDouble : (I)D
    //   88: aload_0
    //   89: iload #4
    //   91: bipush #8
    //   93: imul
    //   94: invokeinterface getDouble : (I)D
    //   99: dsub
    //   100: invokestatic abs : (D)D
    //   103: dstore #5
    //   105: dload #7
    //   107: ldc2_w 2.2250738585072014E-308
    //   110: dcmpl
    //   111: ifgt -> 126
    //   114: dload #5
    //   116: ldc2_w 2.2250738585072014E-308
    //   119: dcmpl
    //   120: ifgt -> 126
    //   123: goto -> 176
    //   126: dload #5
    //   128: dload #7
    //   130: ddiv
    //   131: dstore #13
    //   133: dload #13
    //   135: invokestatic __isnan : (D)I
    //   138: ifeq -> 166
    //   141: dload #5
    //   143: invokestatic R_finite : (D)I
    //   146: ifeq -> 152
    //   149: goto -> 176
    //   152: dload #5
    //   154: dload #7
    //   156: dcmpl
    //   157: ifeq -> 163
    //   160: goto -> 176
    //   163: dconst_1
    //   164: dstore #13
    //   166: dload #10
    //   168: dload #13
    //   170: dadd
    //   171: dstore #10
    //   173: iinc #9, 1
    //   176: iload_3
    //   177: iload_1
    //   178: iadd
    //   179: istore_3
    //   180: iload #4
    //   182: iload_1
    //   183: iadd
    //   184: istore #4
    //   186: iinc #12, 1
    //   189: iload #12
    //   191: iload_2
    //   192: if_icmplt -> 12
    //   195: iload #9
    //   197: ifeq -> 203
    //   200: goto -> 211
    //   203: getstatic org/renjin/gnur/api/Arith.R_NaReal : D
    //   206: dstore #5
    //   208: goto -> 235
    //   211: iload #9
    //   213: iload_2
    //   214: if_icmpne -> 220
    //   217: goto -> 231
    //   220: dload #10
    //   222: iload #9
    //   224: i2d
    //   225: iload_2
    //   226: i2d
    //   227: ddiv
    //   228: ddiv
    //   229: dstore #10
    //   231: dload #10
    //   233: dstore #5
    //   235: dload #5
    //   237: dreturn
  }
  
  public static double R_dist_binary(Ptr paramPtr, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    byte b1 = 0;
    byte b2 = 0;
    byte b3 = 0;
    for (byte b4 = 0; b4 < paramInt2; b4++) {
      if (Builtins.__isnan(paramPtr.getDouble(paramInt3 * 8)) == 0 && Builtins.__isnan(paramPtr.getDouble(paramInt4 * 8)) == 0)
        if (Arith.R_finite(paramPtr.getDouble(paramInt3 * 8)) != 0 && Arith.R_finite(paramPtr.getDouble(paramInt4 * 8)) != 0) {
          if (paramPtr.getDouble(paramInt3 * 8) != 0.0D || paramPtr.getDouble(paramInt4 * 8) != 0.0D) {
            b2++;
            if (paramPtr.getDouble(paramInt3 * 8) == 0.0D || paramPtr.getDouble(paramInt4 * 8) == 0.0D)
              b3++; 
          } 
          b1++;
        } else {
          Error.Rf_warning(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("treating non-finite values as NA\000".getBytes(), 0)), new Object[0]);
        }  
      paramInt3 += paramInt1;
      paramInt4 += paramInt1;
    } 
    return (b1 != 0) ? ((b2 != 0) ? (b3 / b2) : 0.0D) : Arith.R_NaReal;
  }
  
  public static void R_distance(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7) {
    // Byte code:
    //   0: iconst_0
    //   1: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   4: invokeinterface toMethodHandle : ()Ljava/lang/invoke/MethodHandle;
    //   9: pop
    //   10: iconst_0
    //   11: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   14: invokeinterface toMethodHandle : ()Ljava/lang/invoke/MethodHandle;
    //   19: astore #10
    //   21: aload #5
    //   23: invokeinterface getInt : ()I
    //   28: lookupswitch default -> 193, 1 -> 88, 2 -> 95, 3 -> 102, 4 -> 109, 5 -> 116, 6 -> 123
    //   88: ldc
    //   90: astore #10
    //   92: goto -> 232
    //   95: ldc
    //   97: astore #10
    //   99: goto -> 232
    //   102: ldc
    //   104: astore #10
    //   106: goto -> 232
    //   109: ldc
    //   111: astore #10
    //   113: goto -> 232
    //   116: ldc
    //   118: astore #10
    //   120: goto -> 232
    //   123: aload #6
    //   125: invokeinterface getDouble : ()D
    //   130: invokestatic R_finite : (D)I
    //   133: ifeq -> 151
    //   136: aload #6
    //   138: invokeinterface getDouble : ()D
    //   143: dconst_0
    //   144: dcmpg
    //   145: ifle -> 151
    //   148: goto -> 232
    //   151: new org/renjin/gcc/runtime/BytePtr
    //   154: dup
    //   155: ldc 'stats '
    //   157: invokevirtual getBytes : ()[B
    //   160: iconst_0
    //   161: invokespecial <init> : ([BI)V
    //   164: new org/renjin/gcc/runtime/BytePtr
    //   167: dup
    //   168: ldc 'distance(): invalid p '
    //   170: invokevirtual getBytes : ()[B
    //   173: iconst_0
    //   174: invokespecial <init> : ([BI)V
    //   177: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
    //   180: checkcast org/renjin/gcc/runtime/BytePtr
    //   183: iconst_0
    //   184: anewarray java/lang/Object
    //   187: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
    //   190: goto -> 232
    //   193: new org/renjin/gcc/runtime/BytePtr
    //   196: dup
    //   197: ldc 'stats '
    //   199: invokevirtual getBytes : ()[B
    //   202: iconst_0
    //   203: invokespecial <init> : ([BI)V
    //   206: new org/renjin/gcc/runtime/BytePtr
    //   209: dup
    //   210: ldc 'distance(): invalid distance '
    //   212: invokevirtual getBytes : ()[B
    //   215: iconst_0
    //   216: invokespecial <init> : ([BI)V
    //   219: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
    //   222: checkcast org/renjin/gcc/runtime/BytePtr
    //   225: iconst_0
    //   226: anewarray java/lang/Object
    //   229: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
    //   232: aload #4
    //   234: invokeinterface getInt : ()I
    //   239: ifeq -> 248
    //   242: iconst_0
    //   243: istore #4
    //   245: goto -> 251
    //   248: iconst_1
    //   249: istore #4
    //   251: iload #4
    //   253: istore #11
    //   255: iconst_0
    //   256: istore #12
    //   258: iconst_0
    //   259: istore #13
    //   261: goto -> 394
    //   264: iload #13
    //   266: iload #11
    //   268: iadd
    //   269: istore #14
    //   271: goto -> 380
    //   274: iload #12
    //   276: bipush #8
    //   278: imul
    //   279: istore #4
    //   281: aload #5
    //   283: invokeinterface getInt : ()I
    //   288: bipush #6
    //   290: if_icmpne -> 296
    //   293: goto -> 327
    //   296: aload #10
    //   298: aload_0
    //   299: aload_2
    //   300: invokeinterface getInt : ()I
    //   305: istore #7
    //   307: aload_1
    //   308: invokeinterface getInt : ()I
    //   313: iload #7
    //   315: iload #14
    //   317: iload #13
    //   319: invokevirtual invoke : (Lorg/renjin/gcc/runtime/Ptr;IIII)D
    //   322: dstore #8
    //   324: goto -> 364
    //   327: aload_0
    //   328: aload #6
    //   330: invokeinterface getDouble : ()D
    //   335: dstore #8
    //   337: aload_2
    //   338: invokeinterface getInt : ()I
    //   343: istore #7
    //   345: aload_1
    //   346: invokeinterface getInt : ()I
    //   351: iload #7
    //   353: iload #14
    //   355: iload #13
    //   357: dload #8
    //   359: invokestatic R_minkowski : (Lorg/renjin/gcc/runtime/Ptr;IIIID)D
    //   362: dstore #8
    //   364: aload_3
    //   365: iload #4
    //   367: dload #8
    //   369: invokeinterface setDouble : (ID)V
    //   374: iinc #12, 1
    //   377: iinc #14, 1
    //   380: aload_1
    //   381: invokeinterface getInt : ()I
    //   386: iload #14
    //   388: if_icmpgt -> 274
    //   391: iinc #13, 1
    //   394: aload_1
    //   395: invokeinterface getInt : ()I
    //   400: iload #13
    //   402: if_icmpge -> 264
    //   405: return
  }
  
  public static double R_euclidean(Ptr paramPtr, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    byte b1 = 0;
    double d = 0.0D;
    for (byte b2 = 0; b2 < paramInt2; b2++) {
      if (Builtins.__isnan(paramPtr.getDouble(paramInt3 * 8)) == 0 && Builtins.__isnan(paramPtr.getDouble(paramInt4 * 8)) == 0) {
        double d1 = paramPtr.getDouble(paramInt3 * 8) - paramPtr.getDouble(paramInt4 * 8);
        if (Builtins.__isnan(d1) == 0) {
          d = d1 * d1 + d;
          b1++;
        } 
      } 
      paramInt3 += paramInt1;
      paramInt4 += paramInt1;
    } 
    if (b1 != 0) {
      if (b1 != paramInt2)
        d /= b1 / paramInt2; 
      return Mathlib.sqrt(d);
    } 
    return Arith.R_NaReal;
  }
  
  public static double R_manhattan(Ptr paramPtr, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    byte b1 = 0;
    double d = 0.0D;
    for (byte b2 = 0; b2 < paramInt2; b2++) {
      if (Builtins.__isnan(paramPtr.getDouble(paramInt3 * 8)) == 0 && Builtins.__isnan(paramPtr.getDouble(paramInt4 * 8)) == 0) {
        double d1 = Math.abs(paramPtr.getDouble(paramInt3 * 8) - paramPtr.getDouble(paramInt4 * 8));
        if (Builtins.__isnan(d1) == 0) {
          d += d1;
          b1++;
        } 
      } 
      paramInt3 += paramInt1;
      paramInt4 += paramInt1;
    } 
    if (b1 != 0) {
      if (b1 != paramInt2)
        d /= b1 / paramInt2; 
      return d;
    } 
    return Arith.R_NaReal;
  }
  
  public static double R_maximum(Ptr paramPtr, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    byte b1 = 0;
    double d = -1.7976931348623157E308D;
    for (byte b2 = 0; b2 < paramInt2; b2++) {
      if (Builtins.__isnan(paramPtr.getDouble(paramInt3 * 8)) == 0 && Builtins.__isnan(paramPtr.getDouble(paramInt4 * 8)) == 0) {
        double d1 = Math.abs(paramPtr.getDouble(paramInt3 * 8) - paramPtr.getDouble(paramInt4 * 8));
        if (Builtins.__isnan(d1) == 0) {
          if (d1 > d)
            d = d1; 
          b1++;
        } 
      } 
      paramInt3 += paramInt1;
      paramInt4 += paramInt1;
    } 
    return (b1 != 0) ? d : Arith.R_NaReal;
  }
  
  public static double R_minkowski(Ptr paramPtr, int paramInt1, int paramInt2, int paramInt3, int paramInt4, double paramDouble) {
    byte b1 = 0;
    double d = 0.0D;
    for (byte b2 = 0; b2 < paramInt2; b2++) {
      if (Builtins.__isnan(paramPtr.getDouble(paramInt3 * 8)) == 0 && Builtins.__isnan(paramPtr.getDouble(paramInt4 * 8)) == 0) {
        double d1 = paramPtr.getDouble(paramInt3 * 8) - paramPtr.getDouble(paramInt4 * 8);
        if (Builtins.__isnan(d1) == 0) {
          d = Rmath.R_pow(Math.abs(d1), paramDouble) + d;
          b1++;
        } 
      } 
      paramInt3 += paramInt1;
      paramInt4 += paramInt1;
    } 
    if (b1 != 0) {
      if (b1 != paramInt2)
        d /= b1 / paramInt2; 
      return Rmath.R_pow(d, 1.0D / paramDouble);
    } 
    return Arith.R_NaReal;
  }
  
  public static double Rtest(double paramDouble) {
    return (Builtins.__isnan(paramDouble) == 0) ? 42.0D : 1.0D;
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/stats-0.9.2724.jar!/org/renjin/stats/distance__.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */