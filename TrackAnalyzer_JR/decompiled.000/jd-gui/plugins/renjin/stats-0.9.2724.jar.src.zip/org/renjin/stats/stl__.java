package org.renjin.stats;

import org.renjin.gcc.runtime.BooleanPtr;
import org.renjin.gcc.runtime.Builtins;
import org.renjin.gcc.runtime.DoublePtr;
import org.renjin.gcc.runtime.IntPtr;
import org.renjin.gcc.runtime.Mathlib;
import org.renjin.gcc.runtime.Ptr;

public class stl__ {
  static {
  
  }
  
  public static void psort_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4) {
    // Byte code:
    //   0: bipush #16
    //   2: newarray int
    //   4: astore #4
    //   6: bipush #16
    //   8: newarray int
    //   10: astore #5
    //   12: bipush #16
    //   14: newarray int
    //   16: astore #6
    //   18: bipush #16
    //   20: newarray int
    //   22: astore #7
    //   24: aload_1
    //   25: invokeinterface getInt : ()I
    //   30: iconst_0
    //   31: invokestatic max : (II)I
    //   34: invokestatic toUnsignedLong : (I)J
    //   37: pop2
    //   38: aload_3
    //   39: invokeinterface getInt : ()I
    //   44: iconst_0
    //   45: invokestatic max : (II)I
    //   48: invokestatic toUnsignedLong : (I)J
    //   51: pop2
    //   52: aload_1
    //   53: invokeinterface getInt : ()I
    //   58: iflt -> 802
    //   61: aload_3
    //   62: invokeinterface getInt : ()I
    //   67: iflt -> 802
    //   70: aload_1
    //   71: invokeinterface getInt : ()I
    //   76: iconst_1
    //   77: if_icmple -> 802
    //   80: aload_3
    //   81: invokeinterface getInt : ()I
    //   86: ifeq -> 802
    //   89: iconst_1
    //   90: istore #9
    //   92: aload_3
    //   93: invokeinterface getInt : ()I
    //   98: istore #10
    //   100: aload #6
    //   102: iconst_0
    //   103: iconst_1
    //   104: iastore
    //   105: aload #5
    //   107: iconst_0
    //   108: aload_3
    //   109: invokeinterface getInt : ()I
    //   114: iastore
    //   115: iconst_1
    //   116: istore #11
    //   118: aload_1
    //   119: invokeinterface getInt : ()I
    //   124: istore_1
    //   125: iconst_1
    //   126: istore_3
    //   127: iload #11
    //   129: iload_1
    //   130: if_icmplt -> 187
    //   133: iinc #3, -1
    //   136: iload_3
    //   137: ifeq -> 802
    //   140: aload #7
    //   142: iload_3
    //   143: iconst_m1
    //   144: iadd
    //   145: iaload
    //   146: istore #11
    //   148: aload #4
    //   150: iload_3
    //   151: iconst_m1
    //   152: iadd
    //   153: iaload
    //   154: istore_1
    //   155: aload #6
    //   157: iload_3
    //   158: iconst_m1
    //   159: iadd
    //   160: iaload
    //   161: istore #9
    //   163: aload #5
    //   165: iload_3
    //   166: iconst_m1
    //   167: iadd
    //   168: iaload
    //   169: istore #10
    //   171: iload #9
    //   173: iload #10
    //   175: if_icmpgt -> 133
    //   178: iload_1
    //   179: iload #11
    //   181: isub
    //   182: bipush #10
    //   184: if_icmple -> 679
    //   187: iload #11
    //   189: istore #12
    //   191: iload #11
    //   193: iload_1
    //   194: iadd
    //   195: iconst_2
    //   196: idiv
    //   197: istore #8
    //   199: aload_0
    //   200: iload #8
    //   202: iconst_m1
    //   203: iadd
    //   204: invokeinterface getAlignedDouble : (I)D
    //   209: dstore #13
    //   211: aload_0
    //   212: iload #11
    //   214: iconst_m1
    //   215: iadd
    //   216: invokeinterface getAlignedDouble : (I)D
    //   221: dload #13
    //   223: dcmpl
    //   224: ifgt -> 230
    //   227: goto -> 274
    //   230: aload_0
    //   231: iload #8
    //   233: iconst_m1
    //   234: iadd
    //   235: aload_0
    //   236: iload #11
    //   238: iconst_m1
    //   239: iadd
    //   240: invokeinterface getAlignedDouble : (I)D
    //   245: invokeinterface setAlignedDouble : (ID)V
    //   250: aload_0
    //   251: iload #11
    //   253: iconst_m1
    //   254: iadd
    //   255: dload #13
    //   257: invokeinterface setAlignedDouble : (ID)V
    //   262: aload_0
    //   263: iload #8
    //   265: iconst_m1
    //   266: iadd
    //   267: invokeinterface getAlignedDouble : (I)D
    //   272: dstore #13
    //   274: iload_1
    //   275: istore #15
    //   277: aload_0
    //   278: iload_1
    //   279: iconst_m1
    //   280: iadd
    //   281: invokeinterface getAlignedDouble : (I)D
    //   286: dload #13
    //   288: dcmpg
    //   289: iflt -> 295
    //   292: goto -> 400
    //   295: aload_0
    //   296: iload #8
    //   298: iconst_m1
    //   299: iadd
    //   300: aload_0
    //   301: iload_1
    //   302: iconst_m1
    //   303: iadd
    //   304: invokeinterface getAlignedDouble : (I)D
    //   309: invokeinterface setAlignedDouble : (ID)V
    //   314: aload_0
    //   315: iload_1
    //   316: iconst_m1
    //   317: iadd
    //   318: dload #13
    //   320: invokeinterface setAlignedDouble : (ID)V
    //   325: aload_0
    //   326: iload #8
    //   328: iconst_m1
    //   329: iadd
    //   330: invokeinterface getAlignedDouble : (I)D
    //   335: dstore #13
    //   337: aload_0
    //   338: iload #11
    //   340: iconst_m1
    //   341: iadd
    //   342: invokeinterface getAlignedDouble : (I)D
    //   347: dload #13
    //   349: dcmpl
    //   350: ifgt -> 356
    //   353: goto -> 400
    //   356: aload_0
    //   357: iload #8
    //   359: iconst_m1
    //   360: iadd
    //   361: aload_0
    //   362: iload #11
    //   364: iconst_m1
    //   365: iadd
    //   366: invokeinterface getAlignedDouble : (I)D
    //   371: invokeinterface setAlignedDouble : (ID)V
    //   376: aload_0
    //   377: iload #11
    //   379: iconst_m1
    //   380: iadd
    //   381: dload #13
    //   383: invokeinterface setAlignedDouble : (ID)V
    //   388: aload_0
    //   389: iload #8
    //   391: iconst_m1
    //   392: iadd
    //   393: invokeinterface getAlignedDouble : (I)D
    //   398: dstore #13
    //   400: iinc #15, -1
    //   403: aload_0
    //   404: iload #15
    //   406: iconst_m1
    //   407: iadd
    //   408: invokeinterface getAlignedDouble : (I)D
    //   413: dload #13
    //   415: dcmpg
    //   416: ifle -> 422
    //   419: goto -> 400
    //   422: aload_0
    //   423: iload #15
    //   425: iconst_m1
    //   426: iadd
    //   427: invokeinterface getAlignedDouble : (I)D
    //   432: dstore #16
    //   434: iinc #12, 1
    //   437: aload_0
    //   438: iload #12
    //   440: iconst_m1
    //   441: iadd
    //   442: invokeinterface getAlignedDouble : (I)D
    //   447: dload #13
    //   449: dcmpl
    //   450: ifge -> 459
    //   453: iconst_0
    //   454: istore #8
    //   456: goto -> 462
    //   459: iconst_1
    //   460: istore #8
    //   462: iload #8
    //   464: iconst_1
    //   465: ixor
    //   466: ifne -> 434
    //   469: iload #12
    //   471: iload #15
    //   473: if_icmpgt -> 511
    //   476: aload_0
    //   477: iload #15
    //   479: iconst_m1
    //   480: iadd
    //   481: aload_0
    //   482: iload #12
    //   484: iconst_m1
    //   485: iadd
    //   486: invokeinterface getAlignedDouble : (I)D
    //   491: invokeinterface setAlignedDouble : (ID)V
    //   496: aload_0
    //   497: iload #12
    //   499: iconst_m1
    //   500: iadd
    //   501: dload #16
    //   503: invokeinterface setAlignedDouble : (ID)V
    //   508: goto -> 400
    //   511: aload #6
    //   513: iload_3
    //   514: iconst_m1
    //   515: iadd
    //   516: iload #9
    //   518: iastore
    //   519: aload #5
    //   521: iload_3
    //   522: iconst_m1
    //   523: iadd
    //   524: iload #10
    //   526: iastore
    //   527: iload_3
    //   528: istore #8
    //   530: iinc #3, 1
    //   533: iload #15
    //   535: iload #11
    //   537: isub
    //   538: iload_1
    //   539: iload #12
    //   541: isub
    //   542: if_icmple -> 548
    //   545: goto -> 612
    //   548: aload #7
    //   550: iload #8
    //   552: iconst_m1
    //   553: iadd
    //   554: iload #12
    //   556: iastore
    //   557: aload #4
    //   559: iload #8
    //   561: iconst_m1
    //   562: iadd
    //   563: iload_1
    //   564: iastore
    //   565: iload #15
    //   567: istore_1
    //   568: iload #9
    //   570: iload #10
    //   572: if_icmpgt -> 133
    //   575: aload_2
    //   576: iload #10
    //   578: iconst_m1
    //   579: iadd
    //   580: invokeinterface getAlignedInt : (I)I
    //   585: iload_1
    //   586: if_icmpgt -> 592
    //   589: goto -> 598
    //   592: iinc #10, -1
    //   595: goto -> 568
    //   598: aload #6
    //   600: iload #8
    //   602: iconst_m1
    //   603: iadd
    //   604: iload #10
    //   606: iconst_1
    //   607: iadd
    //   608: iastore
    //   609: goto -> 178
    //   612: aload #7
    //   614: iload #8
    //   616: iconst_m1
    //   617: iadd
    //   618: iload #11
    //   620: iastore
    //   621: aload #4
    //   623: iload #8
    //   625: iconst_m1
    //   626: iadd
    //   627: iload #15
    //   629: iastore
    //   630: iload #12
    //   632: istore #11
    //   634: iload #9
    //   636: iload #10
    //   638: if_icmpgt -> 133
    //   641: aload_2
    //   642: iload #9
    //   644: iconst_m1
    //   645: iadd
    //   646: invokeinterface getAlignedInt : (I)I
    //   651: iload #11
    //   653: if_icmplt -> 659
    //   656: goto -> 665
    //   659: iinc #9, 1
    //   662: goto -> 634
    //   665: aload #5
    //   667: iload #8
    //   669: iconst_m1
    //   670: iadd
    //   671: iload #9
    //   673: iconst_m1
    //   674: iadd
    //   675: iastore
    //   676: goto -> 178
    //   679: iload #11
    //   681: iconst_1
    //   682: if_icmpne -> 688
    //   685: goto -> 127
    //   688: iload #11
    //   690: iconst_m1
    //   691: iadd
    //   692: istore #9
    //   694: iinc #9, 1
    //   697: iload #9
    //   699: iload_1
    //   700: if_icmpeq -> 133
    //   703: aload_0
    //   704: iload #9
    //   706: invokeinterface getAlignedDouble : (I)D
    //   711: dstore #13
    //   713: aload_0
    //   714: iload #9
    //   716: iconst_m1
    //   717: iadd
    //   718: invokeinterface getAlignedDouble : (I)D
    //   723: dload #13
    //   725: dcmpl
    //   726: ifgt -> 732
    //   729: goto -> 694
    //   732: iload #9
    //   734: istore #10
    //   736: aload_0
    //   737: iload #10
    //   739: aload_0
    //   740: iload #10
    //   742: iconst_m1
    //   743: iadd
    //   744: invokeinterface getAlignedDouble : (I)D
    //   749: invokeinterface setAlignedDouble : (ID)V
    //   754: iinc #10, -1
    //   757: aload_0
    //   758: iload #10
    //   760: iconst_m1
    //   761: iadd
    //   762: invokeinterface getAlignedDouble : (I)D
    //   767: dload #13
    //   769: dcmpg
    //   770: ifle -> 779
    //   773: iconst_0
    //   774: istore #11
    //   776: goto -> 782
    //   779: iconst_1
    //   780: istore #11
    //   782: iload #11
    //   784: iconst_1
    //   785: ixor
    //   786: ifne -> 736
    //   789: aload_0
    //   790: iload #10
    //   792: dload #13
    //   794: invokeinterface setAlignedDouble : (ID)V
    //   799: goto -> 694
    //   802: return
  }
  
  public static void stl_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, Ptr paramPtr11, Ptr paramPtr12, Ptr paramPtr13, Ptr paramPtr14, Ptr paramPtr15, Ptr paramPtr16, Ptr paramPtr17, Ptr paramPtr18) {
    boolean[] arrayOfBoolean = new boolean[1];
    int[] arrayOfInt1 = new int[1];
    int[] arrayOfInt2 = new int[1];
    int[] arrayOfInt3 = new int[1];
    int[] arrayOfInt4 = new int[1];
    arrayOfBoolean[0] = false;
    arrayOfInt1[0] = 0;
    arrayOfInt2[0] = 0;
    arrayOfInt3[0] = 0;
    arrayOfInt4[0] = 0;
    Integer.toUnsignedLong(Math.max(paramPtr2.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr2.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr2.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr2.getInt(), 0));
    int m = Math.max(paramPtr2.getInt() + paramPtr3.getInt() * 2, 0);
    Integer.toUnsignedLong(Math.max(m * 5, 0));
    int n = m ^ 0xFFFFFFFF;
    arrayOfBoolean[0] = false;
    int i1 = paramPtr2.getInt();
    byte b = 1;
    if (1 <= i1)
      while (true) {
        boolean bool;
        paramPtr17.setAlignedDouble(b + -1, 0.0D);
        if (b != i1) {
          bool = false;
        } else {
          bool = true;
        } 
        b++;
        if (!bool)
          continue; 
        break;
      }  
    i1 = 3;
    int j = paramPtr4.getInt();
    if (j > 3)
      i1 = j; 
    arrayOfInt2[0] = i1;
    j = 3;
    int k = paramPtr5.getInt();
    if (k > 3)
      j = k; 
    arrayOfInt1[0] = j;
    j = 3;
    k = paramPtr6.getInt();
    if (k > 3)
      j = k; 
    arrayOfInt4[0] = j;
    if ((arrayOfInt2[0] & 0x1) == 0)
      arrayOfInt2[0] = arrayOfInt2[0] + 1; 
    if ((arrayOfInt1[0] & 0x1) == 0)
      arrayOfInt1[0] = arrayOfInt1[0] + 1; 
    if ((arrayOfInt4[0] & 0x1) == 0)
      arrayOfInt4[0] = arrayOfInt4[0] + 1; 
    j = 2;
    int i = paramPtr3.getInt();
    if (i > 2)
      j = i; 
    arrayOfInt3[0] = j;
    i = 0;
    while (true) {
      stlstp_(paramPtr1, paramPtr2, (Ptr)new IntPtr(arrayOfInt3, 0), (Ptr)new IntPtr(arrayOfInt2, 0), (Ptr)new IntPtr(arrayOfInt1, 0), (Ptr)new IntPtr(arrayOfInt4, 0), paramPtr7, paramPtr8, paramPtr9, paramPtr10, paramPtr11, paramPtr12, paramPtr13, (Ptr)new BooleanPtr(arrayOfBoolean, 0), paramPtr15, paramPtr16, paramPtr17, paramPtr18);
      if (paramPtr14.getInt() >= ++i) {
        j = paramPtr2.getInt();
        k = 1;
        if (1 <= j)
          while (true) {
            boolean bool;
            paramPtr18.setAlignedDouble(n + m + k, paramPtr17.getAlignedDouble(k + -1) + paramPtr16.getAlignedDouble(k + -1));
            if (k != j) {
              bool = false;
            } else {
              bool = true;
            } 
            k++;
            if (!bool)
              continue; 
            break;
          }  
        stlrwt_(paramPtr1, paramPtr2, paramPtr18.pointerPlus((n + m + 1) * 8), paramPtr15);
        arrayOfBoolean[0] = true;
        continue;
      } 
      if (paramPtr14.getInt() <= 0) {
        int i2 = paramPtr2.getInt();
        byte b1 = 1;
        if (1 <= i2)
          while (true) {
            paramPtr15.setAlignedDouble(b1 + -1, 1.0D);
            if (b1 != i2) {
              i = 0;
            } else {
              i = 1;
            } 
            b1++;
            if (i == 0)
              continue; 
            break;
          }  
      } 
      return;
    } 
  }
  
  public static void stless_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9) {
    int i;
    double[] arrayOfDouble1 = new double[1];
    double[] arrayOfDouble3 = new double[1];
    double[] arrayOfDouble4 = new double[1];
    double[] arrayOfDouble2 = new double[1];
    boolean[] arrayOfBoolean = new boolean[1];
    int[] arrayOfInt1 = new int[1];
    int[] arrayOfInt2 = new int[1];
    arrayOfBoolean[0] = false;
    arrayOfInt1[0] = 0;
    arrayOfInt2[0] = 0;
    Integer.toUnsignedLong(Math.max(paramPtr2.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr2.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr2.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr2.getInt(), 0));
    if (paramPtr2.getInt() > 1) {
      int k;
      byte b = paramPtr5.getInt();
      int j = paramPtr2.getInt() + -1;
      if (j < b)
        b = j; 
      j = b;
      if (paramPtr3.getInt() < paramPtr2.getInt()) {
        int m;
        if (b != 1) {
          k = (paramPtr3.getInt() + 1) / 2;
          int n = paramPtr2.getInt();
          m = b;
          int i1 = 1;
          if ((b <= 0) ? (n <= 1) : (n > 0)) {
            b = n + -1;
            if (m >= 0) {
              n = 1;
            } else {
              n = -1;
            } 
            b *= n;
            if (m >= 0) {
              n = 1;
            } else {
              n = -1;
            } 
            b = Integer.divideUnsigned(b, n * m);
            while (true) {
              if (i1 >= k) {
                if (paramPtr2.getInt() - k + 1 > i1) {
                  arrayOfInt2[0] = i1 - k + 1;
                  arrayOfInt1[0] = paramPtr3.getInt() + i1 - k;
                } else {
                  arrayOfInt2[0] = paramPtr2.getInt() - paramPtr3.getInt() + 1;
                  arrayOfInt1[0] = paramPtr2.getInt();
                } 
              } else {
                arrayOfInt2[0] = 1;
                arrayOfInt1[0] = paramPtr3.getInt();
              } 
              arrayOfDouble3[0] = i1;
              Ptr ptr1 = (Ptr)new DoublePtr(arrayOfDouble3, 0);
              Ptr ptr2 = paramPtr8.pointerPlus((i1 + -1) * 8);
              stlest_(paramPtr1, paramPtr2, paramPtr3, paramPtr4, ptr1, ptr2, (Ptr)new IntPtr(arrayOfInt2, 0), (Ptr)new IntPtr(arrayOfInt1, 0), paramPtr9, paramPtr6, paramPtr7, (Ptr)new BooleanPtr(arrayOfBoolean, 0));
              if ((arrayOfBoolean[0] ^ true) != 0)
                paramPtr8.setAlignedDouble(i1 + -1, paramPtr1.getAlignedDouble(i1 + -1)); 
              i1 += m;
              if (b != 0) {
                b--;
                continue;
              } 
              break;
            } 
          } 
        } else {
          int n = (paramPtr3.getInt() + 1) / 2;
          arrayOfInt2[0] = 1;
          arrayOfInt1[0] = paramPtr3.getInt();
          k = paramPtr2.getInt();
          byte b1 = 1;
          if (1 <= k)
            while (true) {
              if (b1 > n && paramPtr2.getInt() != arrayOfInt1[0]) {
                arrayOfInt2[0] = arrayOfInt2[0] + 1;
                arrayOfInt1[0] = arrayOfInt1[0] + 1;
              } 
              m[0] = b1;
              Ptr ptr2 = (Ptr)new DoublePtr(m, 0);
              Ptr ptr1 = paramPtr8.pointerPlus((b1 + -1) * 8);
              stlest_(paramPtr1, paramPtr2, paramPtr3, paramPtr4, ptr2, ptr1, (Ptr)new IntPtr(arrayOfInt2, 0), (Ptr)new IntPtr(arrayOfInt1, 0), paramPtr9, paramPtr6, paramPtr7, (Ptr)new BooleanPtr(arrayOfBoolean, 0));
              if ((arrayOfBoolean[0] ^ true) != 0)
                paramPtr8.setAlignedDouble(b1 + -1, paramPtr1.getAlignedDouble(b1 + -1)); 
              if (b1 != k) {
                b = 0;
              } else {
                b = 1;
              } 
              b1++;
              if (!b)
                continue; 
              break;
            }  
        } 
      } else {
        arrayOfInt2[0] = 1;
        arrayOfInt1[0] = paramPtr2.getInt();
        int n = paramPtr2.getInt();
        byte b1 = b;
        int m = 1;
        if (b ? (n <= 1) : (n > 0)) {
          n--;
          if (b1) {
            b = 1;
          } else {
            b = -1;
          } 
          n *= b;
          if (b1 >= 0) {
            b = 1;
          } else {
            b = -1;
          } 
          n = Integer.divideUnsigned(n, b * b1);
          while (true) {
            k[0] = m;
            Ptr ptr2 = (Ptr)new DoublePtr(k, 0);
            Ptr ptr1 = paramPtr8.pointerPlus((m + -1) * 8);
            stlest_(paramPtr1, paramPtr2, paramPtr3, paramPtr4, ptr2, ptr1, (Ptr)new IntPtr(arrayOfInt2, 0), (Ptr)new IntPtr(arrayOfInt1, 0), paramPtr9, paramPtr6, paramPtr7, (Ptr)new BooleanPtr(arrayOfBoolean, 0));
            if ((arrayOfBoolean[0] ^ true) != 0)
              paramPtr8.setAlignedDouble(m + -1, paramPtr1.getAlignedDouble(m + -1)); 
            m += b1;
            if (n != 0) {
              n--;
              continue;
            } 
            break;
          } 
        } 
      } 
      if (j != 1) {
        k = paramPtr2.getInt() - j;
        int m = 1;
        if ((j <= 0) ? (k <= 1) : (k > 0)) {
          int n;
          k--;
          if (j >= 0) {
            n = 1;
          } else {
            n = -1;
          } 
          k *= n;
          if (j >= 0) {
            n = 1;
          } else {
            n = -1;
          } 
          k = Integer.divideUnsigned(k, n * j);
          while (true) {
            double d = (paramPtr8.getAlignedDouble(m + j + -1) - paramPtr8.getAlignedDouble(m + -1)) / j;
            n = m + j + -1;
            int i1;
            if ((i1 = m + 1) <= n)
              while (true) {
                paramPtr8.setAlignedDouble(i1 + -1, paramPtr8.getAlignedDouble(m + -1) + (i1 - m) * d);
                if (i1 != n) {
                  b = 0;
                } else {
                  b = 1;
                } 
                i1++;
                if (b == 0)
                  continue; 
                break;
              }  
            m += j;
            if (k != 0) {
              k--;
              continue;
            } 
            break;
          } 
        } 
        j = (paramPtr2.getInt() + -1) / j * j + 1;
        if (paramPtr2.getInt() != j) {
          arrayOfDouble1[0] = paramPtr2.getInt();
          paramPtr3 = (Ptr)new DoublePtr(arrayOfDouble1, 0);
          paramPtr4 = paramPtr8.pointerPlus((paramPtr2.getInt() + -1) * 8);
          stlest_(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr3, paramPtr4, (Ptr)new IntPtr(arrayOfInt2, 0), (Ptr)new IntPtr(arrayOfInt1, 0), paramPtr9, paramPtr6, paramPtr7, (Ptr)new BooleanPtr(arrayOfBoolean, 0));
          if ((arrayOfBoolean[0] ^ true) != 0)
            paramPtr8.setAlignedDouble(paramPtr2.getInt() + -1, paramPtr1.getAlignedDouble(paramPtr2.getInt() + -1)); 
          double d = (paramPtr8.getAlignedDouble(paramPtr2.getInt() + -1) - paramPtr8.getAlignedDouble(j + -1)) / (paramPtr2.getInt() - j);
          i = paramPtr2.getInt() + -1;
          int n;
          if (paramPtr2.getInt() + -1 != j && (n = j + 1) <= i)
            while (true) {
              boolean bool;
              paramPtr8.setAlignedDouble(n + -1, paramPtr8.getAlignedDouble(j + -1) + (n - j) * d);
              if (n != i) {
                bool = false;
              } else {
                bool = true;
              } 
              n++;
              if (!bool)
                continue; 
              break;
            }  
        } 
      } 
      return;
    } 
    paramPtr8.setDouble(i.getDouble());
  }
  
  public static void stlest_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, Ptr paramPtr11, Ptr paramPtr12) {
    boolean bool2;
    Integer.toUnsignedLong(Math.max(paramPtr2.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr2.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr2.getInt(), 0));
    double d3 = paramPtr2.getInt() - 1.0D;
    double d2 = paramPtr5.getDouble() - paramPtr7.getInt();
    double d1 = paramPtr8.getInt() - paramPtr5.getDouble();
    if (d1 <= d2) {
      bool1 = false;
    } else {
      bool1 = true;
    } 
    boolean bool1 = bool1;
    if (!Double.isNaN(d2) && !Double.isNaN(d2)) {
      bool2 = false;
    } else {
      bool2 = true;
    } 
    if ((bool1 | bool2 & true) != 0)
      d2 = d1; 
    d1 = d2;
    if (paramPtr3.getInt() > paramPtr2.getInt())
      d1 = ((paramPtr3.getInt() - paramPtr2.getInt()) / 2) + d2; 
    double d4 = d1 * 0.999D;
    double d5 = d1 * 0.001D;
    double d6 = 0.0D;
    int i = paramPtr8.getInt();
    int j;
    if ((j = paramPtr7.getInt()) <= i)
      while (true) {
        d2 = Math.abs(j - paramPtr5.getDouble());
        if (d2 > d4) {
          paramPtr9.setAlignedDouble(j + -1, 0.0D);
        } else {
          if (d2 > d5) {
            paramPtr9.setAlignedDouble(j + -1, Builtins.powi(1.0D - Builtins.powi(d2 / d1, 3), 3));
          } else {
            paramPtr9.setAlignedDouble(j + -1, 1.0D);
          } 
          if (paramPtr10.getBoolean())
            paramPtr9.setAlignedDouble(j + -1, paramPtr11.getAlignedDouble(j + -1) * paramPtr9.getAlignedDouble(j + -1)); 
          d6 = paramPtr9.getAlignedDouble(j + -1) + d6;
        } 
        if (j != i) {
          bool1 = false;
        } else {
          bool1 = true;
        } 
        j++;
        if (!bool1)
          continue; 
        break;
      }  
    if (d6 > 0.0D) {
      paramPtr12.setBoolean(true);
      i = paramPtr8.getInt();
      if ((j = paramPtr7.getInt()) <= i)
        while (true) {
          boolean bool;
          paramPtr9.setAlignedDouble(j + -1, paramPtr9.getAlignedDouble(j + -1) / d6);
          if (j != i) {
            bool = false;
          } else {
            bool = true;
          } 
          j++;
          if (!bool)
            continue; 
          break;
        }  
      if (d1 > 0.0D && paramPtr4.getInt() > 0) {
        d1 = 0.0D;
        i = paramPtr8.getInt();
        if ((j = paramPtr7.getInt()) <= i)
          while (true) {
            boolean bool;
            d1 = paramPtr9.getAlignedDouble(j + -1) * j + d1;
            if (j != i) {
              bool = false;
            } else {
              bool = true;
            } 
            j++;
            if (!bool)
              continue; 
            break;
          }  
        d2 = paramPtr5.getDouble() - d1;
        d4 = 0.0D;
        i = paramPtr8.getInt();
        if ((j = paramPtr7.getInt()) <= i)
          while (true) {
            boolean bool;
            d4 = (j - d1) * (j - d1) * paramPtr9.getAlignedDouble(j + -1) + d4;
            if (j != i) {
              bool = false;
            } else {
              bool = true;
            } 
            j++;
            if (!bool)
              continue; 
            break;
          }  
        d3 = d2 / d4;
        i = paramPtr8.getInt();
        if (Mathlib.sqrt(d4) > d3 * 0.001D && (j = paramPtr7.getInt()) <= i)
          while (true) {
            boolean bool;
            paramPtr9.setAlignedDouble(j + -1, paramPtr9.getAlignedDouble(j + -1) * ((j - d1) * d3 + 1.0D));
            if (j != i) {
              bool = false;
            } else {
              bool = true;
            } 
            j++;
            if (!bool)
              continue; 
            break;
          }  
      } 
      paramPtr6.setDouble(0.0D);
      i = paramPtr8.getInt();
      if ((j = paramPtr7.getInt()) <= i)
        while (true) {
          boolean bool;
          paramPtr6.setDouble(paramPtr6.getDouble() + paramPtr9.getAlignedDouble(j + -1) * paramPtr1.getAlignedDouble(j + -1));
          if (j != i) {
            bool = false;
          } else {
            bool = true;
          } 
          j++;
          if (!bool)
            continue; 
          break;
        }  
      return;
    } 
    paramPtr12.setBoolean(false);
  }
  
  public static void stlez_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, Ptr paramPtr11, Ptr paramPtr12) {
    int i;
    byte b;
    int[] arrayOfInt1 = new int[1];
    int[] arrayOfInt2 = new int[1];
    int[] arrayOfInt3 = new int[1];
    int[] arrayOfInt4 = new int[1];
    int[] arrayOfInt5 = new int[1];
    int[] arrayOfInt6 = new int[1];
    int[] arrayOfInt7 = new int[1];
    int[] arrayOfInt8 = new int[1];
    int[] arrayOfInt9 = new int[1];
    arrayOfInt1[0] = 0;
    arrayOfInt2[0] = 0;
    arrayOfInt3[0] = 0;
    arrayOfInt4[0] = 0;
    arrayOfInt5[0] = 0;
    arrayOfInt6[0] = 0;
    arrayOfInt7[0] = 0;
    arrayOfInt8[0] = 0;
    arrayOfInt9[0] = 0;
    Integer.toUnsignedLong(Math.max(paramPtr2.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr2.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr2.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr2.getInt(), 0));
    int m = Math.max(paramPtr2.getInt() + paramPtr3.getInt() * 2, 0);
    Integer.toUnsignedLong(Math.max(m * 7, 0));
    int n = m ^ 0xFFFFFFFF;
    arrayOfInt9[0] = paramPtr6.getInt();
    int i1 = 3;
    int k = paramPtr4.getInt();
    if (k > 3)
      i1 = k; 
    arrayOfInt7[0] = i1;
    if ((arrayOfInt7[0] & 0x1) == 0)
      arrayOfInt7[0] = arrayOfInt7[0] + 1; 
    k = 2;
    int j = paramPtr3.getInt();
    if (j > 2)
      k = j; 
    arrayOfInt8[0] = k;
    arrayOfInt2[0] = (int)(arrayOfInt8[0] * 1.5D / (1.0D - 1.5D / arrayOfInt7[0]) + 0.5D);
    j = 3;
    if (arrayOfInt2[0] > 3)
      j = arrayOfInt2[0]; 
    arrayOfInt2[0] = j;
    if ((arrayOfInt2[0] & 0x1) == 0)
      arrayOfInt2[0] = arrayOfInt2[0] + 1; 
    arrayOfInt5[0] = arrayOfInt8[0];
    if ((arrayOfInt5[0] & 0x1) == 0)
      arrayOfInt5[0] = arrayOfInt5[0] + 1; 
    if (!paramPtr7.getBoolean()) {
      arrayOfInt6[0] = 2;
    } else {
      arrayOfInt6[0] = 1;
    } 
    k = 1;
    j = (int)(arrayOfInt7[0] / 10.0F + 0.9F);
    if (j > 1)
      k = j; 
    arrayOfInt3[0] = k;
    k = 1;
    j = (int)(arrayOfInt2[0] / 10.0F + 0.9F);
    if (j > 1)
      k = j; 
    arrayOfInt1[0] = k;
    k = 1;
    j = (int)(arrayOfInt5[0] / 10.0F + 0.9F);
    if (j > 1)
      k = j; 
    arrayOfInt4[0] = k;
    j = paramPtr2.getInt();
    k = 1;
    if (1 <= j)
      while (true) {
        paramPtr11.setAlignedDouble(k + -1, 0.0D);
        if (k != j) {
          i1 = 0;
        } else {
          i1 = 1;
        } 
        k++;
        if (i1 == 0)
          continue; 
        break;
      }  
    stlstp_(paramPtr1, paramPtr2, (Ptr)new IntPtr(arrayOfInt8, 0), (Ptr)new IntPtr(arrayOfInt7, 0), (Ptr)new IntPtr(arrayOfInt2, 0), (Ptr)new IntPtr(arrayOfInt5, 0), paramPtr5, paramPtr6, (Ptr)new IntPtr(arrayOfInt9, 0), (Ptr)new IntPtr(arrayOfInt3, 0), (Ptr)new IntPtr(arrayOfInt1, 0), (Ptr)new IntPtr(arrayOfInt4, 0), (Ptr)new IntPtr(arrayOfInt6, 0), (Ptr)new BooleanPtr(new boolean[] { false }, 0), paramPtr9, paramPtr10, paramPtr11, paramPtr12);
    paramPtr8.setInt(0);
    if (!paramPtr7.getBoolean()) {
      i = paramPtr2.getInt();
      b = 1;
      if (1 <= i)
        while (true) {
          paramPtr9.setAlignedDouble(b + -1, 1.0D);
          if (b != i) {
            j = 0;
          } else {
            j = 1;
          } 
          b++;
          if (j == 0)
            continue; 
          break;
        }  
      return;
    } 
    j = 1;
    while (j <= 15) {
      k = b.getInt();
      byte b1 = 1;
      if (1 <= k)
        while (true) {
          paramPtr12.setAlignedDouble(m * 6 + n + b1, paramPtr10.getAlignedDouble(b1 + -1));
          paramPtr12.setAlignedDouble(m * 7 + n + b1, paramPtr11.getAlignedDouble(b1 + -1));
          paramPtr12.setAlignedDouble(n + m + b1, paramPtr11.getAlignedDouble(b1 + -1) + paramPtr10.getAlignedDouble(b1 + -1));
          if (b1 != k) {
            i1 = 0;
          } else {
            i1 = 1;
          } 
          b1++;
          if (i1 == 0)
            continue; 
          break;
        }  
      stlrwt_(i, b, paramPtr12.pointerPlus((n + m + 1) * 8), paramPtr9);
      stlstp_(i, b, (Ptr)new IntPtr(arrayOfInt8, 0), (Ptr)new IntPtr(arrayOfInt7, 0), (Ptr)new IntPtr(arrayOfInt2, 0), (Ptr)new IntPtr(arrayOfInt5, 0), paramPtr5, paramPtr6, (Ptr)new IntPtr(arrayOfInt9, 0), (Ptr)new IntPtr(arrayOfInt3, 0), (Ptr)new IntPtr(arrayOfInt1, 0), (Ptr)new IntPtr(arrayOfInt4, 0), (Ptr)new IntPtr(arrayOfInt6, 0), (Ptr)new BooleanPtr(new boolean[] { true }, 0), paramPtr9, paramPtr10, paramPtr11, paramPtr12);
      paramPtr8.setInt(paramPtr8.getInt() + 1);
      double d1 = paramPtr12.getAlignedDouble(m * 6 + n + 1);
      double d2 = paramPtr12.getAlignedDouble(m * 6 + n + 1);
      double d3 = paramPtr12.getAlignedDouble(m * 7 + n + 1);
      double d4 = paramPtr12.getAlignedDouble(m * 7 + n + 1);
      double d5 = Math.abs(paramPtr12.getAlignedDouble(m * 6 + n + 1) - paramPtr10.getDouble());
      double d6 = Math.abs(paramPtr12.getAlignedDouble(m * 7 + n + 1) - paramPtr11.getDouble());
      k = b.getInt();
      b1 = 2;
      if (2 <= k)
        while (true) {
          if (paramPtr12.getAlignedDouble(m * 6 + n + b1) > d1)
            d1 = paramPtr12.getAlignedDouble(m * 6 + n + b1); 
          if (paramPtr12.getAlignedDouble(m * 7 + n + b1) > d3)
            d3 = paramPtr12.getAlignedDouble(m * 7 + n + b1); 
          if (paramPtr12.getAlignedDouble(m * 6 + n + b1) < d2)
            d2 = paramPtr12.getAlignedDouble(m * 6 + n + b1); 
          if (paramPtr12.getAlignedDouble(m * 7 + n + b1) < d4)
            d4 = paramPtr12.getAlignedDouble(m * 7 + n + b1); 
          double d8 = Math.abs(paramPtr12.getAlignedDouble(m * 6 + n + b1) - paramPtr10.getAlignedDouble(b1 + -1));
          double d7 = Math.abs(paramPtr12.getAlignedDouble(m * 7 + n + b1) - paramPtr11.getAlignedDouble(b1 + -1));
          if (d5 < d8)
            d5 = d8; 
          if (d6 < d7)
            d6 = d7; 
          if (b1 != k) {
            i1 = 0;
          } else {
            i1 = 1;
          } 
          b1++;
          if (i1 == 0)
            continue; 
          break;
        }  
      if (d5 / (d1 - d2) >= 0.01D || d6 / (d3 - d4) >= 0.01D) {
        j++;
        continue;
      } 
      break;
    } 
  }
  
  public static void stlfts_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5) {
    int[] arrayOfInt1 = new int[1];
    int[] arrayOfInt2 = new int[1];
    Integer.toUnsignedLong(Math.max(paramPtr2.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr2.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr2.getInt(), 0));
    stlma_(paramPtr1, paramPtr2, paramPtr3, paramPtr4);
    arrayOfInt2[0] = paramPtr2.getInt() - paramPtr3.getInt() + 1;
    stlma_(paramPtr4, (Ptr)new IntPtr(arrayOfInt2, 0), paramPtr3, paramPtr5);
    arrayOfInt1[0] = paramPtr2.getInt() + paramPtr3.getInt() * -2 + 2;
    stlma_(paramPtr5, (Ptr)new IntPtr(arrayOfInt1, 0), (Ptr)new IntPtr(new int[] { 3 }, 0), paramPtr4);
  }
  
  public static void stlma_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4) {
    Integer.toUnsignedLong(Math.max(paramPtr2.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr2.getInt(), 0));
    int i = paramPtr2.getInt() - paramPtr3.getInt() + 1;
    double d1 = paramPtr3.getInt();
    double d2 = 0.0D;
    int j = paramPtr3.getInt();
    byte b = 1;
    if (1 <= j)
      while (true) {
        boolean bool;
        d2 = paramPtr1.getAlignedDouble(b + -1) + d2;
        if (b != j) {
          bool = false;
        } else {
          bool = true;
        } 
        b++;
        if (!bool)
          continue; 
        break;
      }  
    paramPtr4.setDouble(d2 / d1);
    if (i > 1) {
      int k = paramPtr3.getInt();
      j = 0;
      b = 2;
      if (2 <= i)
        while (true) {
          boolean bool;
          d2 = d2 - paramPtr1.getAlignedDouble(++j + -1) + paramPtr1.getAlignedDouble(++k + -1);
          paramPtr4.setAlignedDouble(b + -1, d2 / d1);
          if (b != i) {
            bool = false;
          } else {
            bool = true;
          } 
          b++;
          if (!bool)
            continue; 
          break;
        }  
    } 
  }
  
  public static void stlrwt_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4) {
    int[] arrayOfInt = new int[2];
    Integer.toUnsignedLong(Math.max(paramPtr2.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr2.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr2.getInt(), 0));
    int j = paramPtr2.getInt();
    byte b2 = 1;
    if (1 <= j)
      while (true) {
        boolean bool;
        paramPtr4.setAlignedDouble(b2 + -1, Math.abs(paramPtr1.getAlignedDouble(b2 + -1) - paramPtr3.getAlignedDouble(b2 + -1)));
        if (b2 != j) {
          bool = false;
        } else {
          bool = true;
        } 
        b2++;
        if (!bool)
          continue; 
        break;
      }  
    arrayOfInt[0] = paramPtr2.getInt() / 2 + 1;
    arrayOfInt[1] = paramPtr2.getInt() - arrayOfInt[0] + 1;
    psort_(paramPtr4, paramPtr2, (Ptr)new IntPtr(arrayOfInt, 0), (Ptr)new IntPtr(new int[] { 2 }, 0));
    double d1 = (paramPtr4.getAlignedDouble(arrayOfInt[0] + -1) + paramPtr4.getAlignedDouble(arrayOfInt[1] + -1)) * 3.0D;
    double d2 = d1 * 0.999D;
    double d3 = d1 * 0.001D;
    int i = paramPtr2.getInt();
    byte b1 = 1;
    if (1 <= i)
      while (true) {
        double d = Math.abs(paramPtr1.getAlignedDouble(b1 + -1) - paramPtr3.getAlignedDouble(b1 + -1));
        if (d > d3) {
          if (d > d2) {
            paramPtr4.setAlignedDouble(b1 + -1, 0.0D);
          } else {
            paramPtr4.setAlignedDouble(b1 + -1, (1.0D - d / d1 * d / d1) * (1.0D - d / d1 * d / d1));
          } 
        } else {
          paramPtr4.setAlignedDouble(b1 + -1, 1.0D);
        } 
        if (b1 != i) {
          j = 0;
        } else {
          j = 1;
        } 
        b1++;
        if (j == 0)
          continue; 
        break;
      }  
  }
  
  public static void stlss_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, Ptr paramPtr11, Ptr paramPtr12, Ptr paramPtr13) {
    double[] arrayOfDouble = new double[1];
    boolean[] arrayOfBoolean = new boolean[1];
    int[] arrayOfInt1 = new int[1];
    int[] arrayOfInt2 = new int[1];
    int[] arrayOfInt3 = new int[1];
    arrayOfBoolean[0] = false;
    arrayOfInt3[0] = 0;
    Integer.toUnsignedLong(Math.max(paramPtr2.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr2.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr2.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr2.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr2.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr2.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr2.getInt() + paramPtr3.getInt() * 2, 0));
    if (paramPtr3.getInt() > 0) {
      int i = paramPtr3.getInt();
      byte b = 1;
      if (1 <= i)
        while (true) {
          arrayOfInt3[0] = (paramPtr2.getInt() - b) / paramPtr3.getInt() + 1;
          int k = arrayOfInt3[0];
          int m = 1;
          if (1 <= k)
            while (true) {
              boolean bool;
              paramPtr10.setAlignedDouble(m + -1, paramPtr1.getAlignedDouble((m + -1) * paramPtr3.getInt() + b + -1));
              if (m != k) {
                bool = false;
              } else {
                bool = true;
              } 
              m++;
              if (!bool)
                continue; 
              break;
            }  
          if (paramPtr7.getBoolean()) {
            k = arrayOfInt3[0];
            m = 1;
            if (1 <= k)
              while (true) {
                boolean bool;
                paramPtr12.setAlignedDouble(m + -1, paramPtr8.getAlignedDouble((m + -1) * paramPtr3.getInt() + b + -1));
                if (m != k) {
                  bool = false;
                } else {
                  bool = true;
                } 
                m++;
                if (!bool)
                  continue; 
                break;
              }  
          } 
          stless_(paramPtr10, (Ptr)new IntPtr(arrayOfInt3, 0), paramPtr4, paramPtr5, paramPtr6, paramPtr7, paramPtr12, paramPtr11.pointerPlus(8), paramPtr13);
          arrayOfDouble[0] = 0.0D;
          k = paramPtr4.getInt();
          if (arrayOfInt3[0] < k)
            k = arrayOfInt3[0]; 
          arrayOfInt1[0] = k;
          stlest_(paramPtr10, (Ptr)new IntPtr(arrayOfInt3, 0), paramPtr4, paramPtr5, (Ptr)new DoublePtr(arrayOfDouble, 0), paramPtr11, (Ptr)new IntPtr(new int[] { 1 }, 0), (Ptr)new IntPtr(arrayOfInt1, 0), paramPtr13, paramPtr7, paramPtr12, (Ptr)new BooleanPtr(arrayOfBoolean, 0));
          if ((arrayOfBoolean[0] ^ true) != 0)
            paramPtr11.setDouble(paramPtr11.getAlignedDouble(1)); 
          arrayOfDouble[0] = (arrayOfInt3[0] + 1);
          m = 1;
          k = arrayOfInt3[0] - paramPtr4.getInt() + 1;
          if (k > 1)
            m = k; 
          arrayOfInt2[0] = m;
          Ptr ptr1 = (Ptr)new IntPtr(arrayOfInt3, 0);
          Ptr ptr2 = (Ptr)new DoublePtr(arrayOfDouble, 0);
          Ptr ptr3 = paramPtr11.pointerPlus((arrayOfInt3[0] + 1) * 8);
          stlest_(paramPtr10, ptr1, paramPtr4, paramPtr5, ptr2, ptr3, (Ptr)new IntPtr(arrayOfInt2, 0), (Ptr)new IntPtr(arrayOfInt3, 0), paramPtr13, paramPtr7, paramPtr12, (Ptr)new BooleanPtr(arrayOfBoolean, 0));
          if ((arrayOfBoolean[0] ^ true) != 0)
            paramPtr11.setAlignedDouble(arrayOfInt3[0] + 1, paramPtr11.getAlignedDouble(arrayOfInt3[0])); 
          int j = arrayOfInt3[0] + 2;
          byte b1 = 1;
          if (1 <= j)
            while (true) {
              boolean bool;
              paramPtr9.setAlignedDouble((b1 + -1) * paramPtr3.getInt() + b + -1, paramPtr11.getAlignedDouble(b1 + -1));
              if (b1 != j) {
                bool = false;
              } else {
                bool = true;
              } 
              b1++;
              if (!bool)
                continue; 
              break;
            }  
          if (b != i) {
            j = 0;
          } else {
            j = 1;
          } 
          b++;
          if (j == 0)
            continue; 
          break;
        }  
    } 
  }
  
  public static void stlstp_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, Ptr paramPtr11, Ptr paramPtr12, Ptr paramPtr13, Ptr paramPtr14, Ptr paramPtr15, Ptr paramPtr16, Ptr paramPtr17, Ptr paramPtr18) {
    int[] arrayOfInt = new int[1];
    int j = Math.max(paramPtr2.getInt() + paramPtr3.getInt() * 2, 0);
    Integer.toUnsignedLong(Math.max(j * 5, 0));
    int k = j ^ 0xFFFFFFFF;
    Integer.toUnsignedLong(Math.max(paramPtr2.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr2.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr2.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr2.getInt(), 0));
    int i = paramPtr13.getInt();
    int m = 1;
    if (1 <= i)
      while (true) {
        boolean bool;
        int i1 = paramPtr2.getInt();
        byte b2 = 1;
        if (1 <= i1)
          while (true) {
            boolean bool1;
            paramPtr18.setAlignedDouble(k + j + b2, paramPtr1.getAlignedDouble(b2 + -1) - paramPtr17.getAlignedDouble(b2 + -1));
            if (b2 != i1) {
              bool1 = false;
            } else {
              bool1 = true;
            } 
            b2++;
            if (!bool1)
              continue; 
            break;
          }  
        Ptr ptr2 = paramPtr18.pointerPlus((k + j + 1) * 8);
        Ptr ptr4 = paramPtr18.pointerPlus((j * 2 + k + 1) * 8);
        Ptr ptr5 = paramPtr18.pointerPlus((j * 3 + k + 1) * 8);
        Ptr ptr6 = paramPtr18.pointerPlus((j * 4 + k + 1) * 8);
        Ptr ptr7 = paramPtr18.pointerPlus((j * 5 + k + 1) * 8);
        stlss_(ptr2, paramPtr2, paramPtr3, paramPtr4, paramPtr7, paramPtr10, paramPtr14, paramPtr15, ptr4, ptr5, ptr6, ptr7, paramPtr16);
        arrayOfInt[0] = paramPtr2.getInt() + paramPtr3.getInt() * 2;
        ptr2 = paramPtr18.pointerPlus((j * 2 + k + 1) * 8);
        ptr4 = (Ptr)new IntPtr(arrayOfInt, 0);
        ptr5 = paramPtr18.pointerPlus((j * 3 + k + 1) * 8);
        ptr6 = paramPtr18.pointerPlus((k + j + 1) * 8);
        stlfts_(ptr2, ptr4, paramPtr3, ptr5, ptr6);
        ptr2 = paramPtr18.pointerPlus((j * 3 + k + 1) * 8);
        ptr4 = (Ptr)new BooleanPtr(new boolean[] { false }, 0);
        ptr5 = paramPtr18.pointerPlus((j * 4 + k + 1) * 8);
        ptr6 = paramPtr18.pointerPlus((k + j + 1) * 8);
        ptr7 = paramPtr18.pointerPlus((j * 5 + k + 1) * 8);
        stless_(ptr2, paramPtr2, paramPtr6, paramPtr9, paramPtr12, ptr4, ptr5, ptr6, ptr7);
        int n = paramPtr2.getInt();
        byte b1 = 1;
        if (1 <= n)
          while (true) {
            boolean bool1;
            paramPtr16.setAlignedDouble(b1 + -1, paramPtr18.getAlignedDouble(j * 2 + k + paramPtr3.getInt() + b1) - paramPtr18.getAlignedDouble(k + j + b1));
            if (b1 != n) {
              bool1 = false;
            } else {
              bool1 = true;
            } 
            b1++;
            if (!bool1)
              continue; 
            break;
          }  
        n = paramPtr2.getInt();
        b1 = 1;
        if (1 <= n)
          while (true) {
            boolean bool1;
            paramPtr18.setAlignedDouble(k + j + b1, paramPtr1.getAlignedDouble(b1 + -1) - paramPtr16.getAlignedDouble(b1 + -1));
            if (b1 != n) {
              bool1 = false;
            } else {
              bool1 = true;
            } 
            b1++;
            if (!bool1)
              continue; 
            break;
          }  
        Ptr ptr1 = paramPtr18.pointerPlus((k + j + 1) * 8);
        Ptr ptr3 = paramPtr18.pointerPlus((j * 3 + k + 1) * 8);
        stless_(ptr1, paramPtr2, paramPtr5, paramPtr8, paramPtr11, paramPtr14, paramPtr15, paramPtr17, ptr3);
        if (m != i) {
          bool = false;
        } else {
          bool = true;
        } 
        m++;
        if (!bool)
          continue; 
        break;
      }  
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/stats-0.9.2724.jar!/org/renjin/stats/stl__.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */