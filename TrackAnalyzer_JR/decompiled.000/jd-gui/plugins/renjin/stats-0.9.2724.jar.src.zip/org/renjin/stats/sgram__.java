package org.renjin.stats;

import org.renjin.appl.Appl;
import org.renjin.gcc.runtime.DoublePtr;
import org.renjin.gcc.runtime.IntPtr;
import org.renjin.gcc.runtime.Ptr;

public class sgram__ {
  static {
  
  }
  
  public static void sgram_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6) {
    int[] arrayOfInt1 = new int[1];
    double[] arrayOfDouble1 = new double[4];
    double[] arrayOfDouble2 = new double[4];
    double[] arrayOfDouble3 = new double[16];
    double[] arrayOfDouble4 = new double[12];
    int[] arrayOfInt2 = new int[1];
    int[] arrayOfInt3 = new int[1];
    int[] arrayOfInt4 = new int[1];
    arrayOfInt2[0] = 0;
    arrayOfInt3[0] = 0;
    arrayOfInt4[0] = 0;
    Integer.toUnsignedLong(Math.max(paramPtr6.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr6.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr6.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr6.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr6.getInt() + 4, 0));
    arrayOfInt3[0] = paramPtr6.getInt() + 4;
    int i = paramPtr6.getInt();
    byte b = 1;
    if (1 <= i)
      while (true) {
        boolean bool;
        paramPtr1.setAlignedDouble(b + -1, 0.0D);
        paramPtr2.setAlignedDouble(b + -1, 0.0D);
        paramPtr3.setAlignedDouble(b + -1, 0.0D);
        paramPtr4.setAlignedDouble(b + -1, 0.0D);
        if (b != i) {
          bool = false;
        } else {
          bool = true;
        } 
        b++;
        if (!bool)
          continue; 
        break;
      }  
    arrayOfInt4[0] = 1;
    i = paramPtr6.getInt();
    b = 1;
    if (1 <= i)
      while (true) {
        arrayOfInt1[0] = paramPtr6.getInt() + 1;
        Ptr ptr1 = (Ptr)new IntPtr(arrayOfInt1, 0);
        Ptr ptr2 = paramPtr5.pointerPlus((b + -1) * 8);
        arrayOfInt4[0] = Appl.interv_(paramPtr5, ptr1, ptr2, (Ptr)new IntPtr(new int[] { 0 }, 0), (Ptr)new IntPtr(new int[] { 0 }, 0), (Ptr)new IntPtr(arrayOfInt4, 0), (Ptr)new IntPtr(arrayOfInt2, 0));
        ptr1 = (Ptr)new IntPtr(arrayOfInt3, 0);
        ptr2 = (Ptr)new IntPtr(new int[] { 4 }, 0);
        Ptr ptr3 = paramPtr5.pointerPlus((b + -1) * 8);
        bsplvd__.bsplvd_(paramPtr5, ptr1, ptr2, ptr3, (Ptr)new IntPtr(arrayOfInt4, 0), (Ptr)new DoublePtr(arrayOfDouble3, 0), (Ptr)new DoublePtr(arrayOfDouble4, 0), (Ptr)new IntPtr(new int[] { 3 }, 0));
        byte b1 = 1;
        while (true) {
          boolean bool;
          arrayOfDouble2[b1 + -1] = arrayOfDouble4[b1 + 7];
          if (b1 != 4) {
            bool = false;
          } else {
            bool = true;
          } 
          b1++;
          if (!bool)
            continue; 
          Ptr ptr4 = (Ptr)new IntPtr(arrayOfInt3, 0);
          Ptr ptr5 = (Ptr)new IntPtr(new int[] { 4 }, 0);
          ptr3 = paramPtr5.pointerPlus(b * 8);
          bsplvd__.bsplvd_(paramPtr5, ptr4, ptr5, ptr3, (Ptr)new IntPtr(arrayOfInt4, 0), (Ptr)new DoublePtr(arrayOfDouble3, 0), (Ptr)new DoublePtr(arrayOfDouble4, 0), (Ptr)new IntPtr(new int[] { 3 }, 0));
          b1 = 1;
          while (true) {
            int j;
            arrayOfDouble1[b1 + -1] = arrayOfDouble4[b1 + 7] - arrayOfDouble2[b1 + -1];
            if (b1 != 4) {
              j = 0;
            } else {
              j = 1;
            } 
            b1++;
            if (!j)
              continue; 
            double d = paramPtr5.getAlignedDouble(b) - paramPtr5.getAlignedDouble(b + -1);
            if (arrayOfInt4[0] <= 3) {
              if (arrayOfInt4[0] != 3) {
                if (arrayOfInt4[0] != 2) {
                  if (arrayOfInt4[0] == 1) {
                    b1 = 1;
                    while (true) {
                      paramPtr1.setAlignedDouble(arrayOfInt4[0] + -1 + b1 + -1, paramPtr1.getAlignedDouble(arrayOfInt4[0] + -1 + b1 + -1) + (arrayOfDouble2[b1 + -1] * arrayOfDouble2[b1 + -1] + (arrayOfDouble1[b1 + -1] * arrayOfDouble2[b1 + -1] + arrayOfDouble1[b1 + -1] * arrayOfDouble2[b1 + -1]) * 0.5D + arrayOfDouble1[b1 + -1] * arrayOfDouble1[b1 + -1] * 0.333D) * d);
                      if (b1 != 1) {
                        j = 0;
                      } else {
                        j = 1;
                      } 
                      b1++;
                      if (!j)
                        continue; 
                      break;
                    } 
                  } 
                } else {
                  b1 = 1;
                  while (true) {
                    paramPtr1.setAlignedDouble(arrayOfInt4[0] + -2 + b1 + -1, paramPtr1.getAlignedDouble(arrayOfInt4[0] + -2 + b1 + -1) + (arrayOfDouble2[b1 + -1] * arrayOfDouble2[b1 + -1] + (arrayOfDouble1[b1 + -1] * arrayOfDouble2[b1 + -1] + arrayOfDouble1[b1 + -1] * arrayOfDouble2[b1 + -1]) * 0.5D + arrayOfDouble1[b1 + -1] * arrayOfDouble1[b1 + -1] * 0.333D) * d);
                    j = b1 + 1;
                    if (j <= 2)
                      paramPtr2.setAlignedDouble(arrayOfInt4[0] + b1 + -3, paramPtr2.getAlignedDouble(arrayOfInt4[0] + b1 + -3) + (arrayOfDouble2[b1 + -1] * arrayOfDouble2[j + -1] + (arrayOfDouble1[b1 + -1] * arrayOfDouble2[j + -1] + arrayOfDouble1[j + -1] * arrayOfDouble2[b1 + -1]) * 0.5D + arrayOfDouble1[b1 + -1] * arrayOfDouble1[j + -1] * 0.333D) * d); 
                    if (b1 != 2) {
                      j = 0;
                    } else {
                      j = 1;
                    } 
                    b1++;
                    if (j == 0)
                      continue; 
                    break;
                  } 
                } 
              } else {
                b1 = 1;
                while (true) {
                  paramPtr1.setAlignedDouble(arrayOfInt4[0] + -3 + b1 + -1, paramPtr1.getAlignedDouble(arrayOfInt4[0] + -3 + b1 + -1) + (arrayOfDouble2[b1 + -1] * arrayOfDouble2[b1 + -1] + (arrayOfDouble1[b1 + -1] * arrayOfDouble2[b1 + -1] + arrayOfDouble1[b1 + -1] * arrayOfDouble2[b1 + -1]) * 0.5D + arrayOfDouble1[b1 + -1] * arrayOfDouble1[b1 + -1] * 0.333D) * d);
                  j = b1 + 1;
                  if (j <= 3)
                    paramPtr2.setAlignedDouble(arrayOfInt4[0] + b1 + -4, paramPtr2.getAlignedDouble(arrayOfInt4[0] + b1 + -4) + (arrayOfDouble2[b1 + -1] * arrayOfDouble2[j + -1] + (arrayOfDouble1[b1 + -1] * arrayOfDouble2[j + -1] + arrayOfDouble1[j + -1] * arrayOfDouble2[b1 + -1]) * 0.5D + arrayOfDouble1[b1 + -1] * arrayOfDouble1[j + -1] * 0.333D) * d); 
                  j = b1 + 2;
                  if (j <= 3)
                    paramPtr3.setAlignedDouble(arrayOfInt4[0] + b1 + -4, paramPtr3.getAlignedDouble(arrayOfInt4[0] + b1 + -4) + (arrayOfDouble2[b1 + -1] * arrayOfDouble2[j + -1] + (arrayOfDouble1[b1 + -1] * arrayOfDouble2[j + -1] + arrayOfDouble1[j + -1] * arrayOfDouble2[b1 + -1]) * 0.5D + arrayOfDouble1[b1 + -1] * arrayOfDouble1[j + -1] * 0.333D) * d); 
                  if (b1 != 3) {
                    j = 0;
                  } else {
                    j = 1;
                  } 
                  b1++;
                  if (j == 0)
                    continue; 
                  break;
                } 
              } 
            } else {
              b1 = 1;
              while (true) {
                paramPtr1.setAlignedDouble(arrayOfInt4[0] + -4 + b1 + -1, paramPtr1.getAlignedDouble(arrayOfInt4[0] + -4 + b1 + -1) + (arrayOfDouble2[b1 + -1] * arrayOfDouble2[b1 + -1] + (arrayOfDouble1[b1 + -1] * arrayOfDouble2[b1 + -1] + arrayOfDouble1[b1 + -1] * arrayOfDouble2[b1 + -1]) * 0.5D + arrayOfDouble1[b1 + -1] * arrayOfDouble1[b1 + -1] * 0.333D) * d);
                j = b1 + 1;
                if (j <= 4)
                  paramPtr2.setAlignedDouble(arrayOfInt4[0] + b1 + -5, paramPtr2.getAlignedDouble(arrayOfInt4[0] + b1 + -5) + (arrayOfDouble2[b1 + -1] * arrayOfDouble2[j + -1] + (arrayOfDouble1[b1 + -1] * arrayOfDouble2[j + -1] + arrayOfDouble1[j + -1] * arrayOfDouble2[b1 + -1]) * 0.5D + arrayOfDouble1[b1 + -1] * arrayOfDouble1[j + -1] * 0.333D) * d); 
                j = b1 + 2;
                if (j <= 4)
                  paramPtr3.setAlignedDouble(arrayOfInt4[0] + b1 + -5, paramPtr3.getAlignedDouble(arrayOfInt4[0] + b1 + -5) + (arrayOfDouble2[b1 + -1] * arrayOfDouble2[j + -1] + (arrayOfDouble1[b1 + -1] * arrayOfDouble2[j + -1] + arrayOfDouble1[j + -1] * arrayOfDouble2[b1 + -1]) * 0.5D + arrayOfDouble1[b1 + -1] * arrayOfDouble1[j + -1] * 0.333D) * d); 
                j = b1 + 3;
                if (j <= 4)
                  paramPtr4.setAlignedDouble(arrayOfInt4[0] + b1 + -5, paramPtr4.getAlignedDouble(arrayOfInt4[0] + b1 + -5) + (arrayOfDouble2[b1 + -1] * arrayOfDouble2[j + -1] + (arrayOfDouble1[b1 + -1] * arrayOfDouble2[j + -1] + arrayOfDouble1[j + -1] * arrayOfDouble2[b1 + -1]) * 0.5D + arrayOfDouble1[b1 + -1] * arrayOfDouble1[j + -1] * 0.333D) * d); 
                if (b1 != 4) {
                  j = 0;
                } else {
                  j = 1;
                } 
                b1++;
                if (j == 0)
                  continue; 
                break;
              } 
            } 
            if (b != i) {
              b1 = 0;
            } else {
              b1 = 1;
            } 
            b++;
            break;
          } 
          break;
        } 
        if (b1 == 0)
          continue; 
        break;
      }  
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/stats-0.9.2724.jar!/org/renjin/stats/sgram__.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */