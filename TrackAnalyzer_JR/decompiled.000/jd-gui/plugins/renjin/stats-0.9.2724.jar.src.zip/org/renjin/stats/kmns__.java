package org.renjin.stats;

import org.renjin.gcc.runtime.IntPtr;
import org.renjin.gcc.runtime.Ptr;

public class kmns__ {
  public static double big$1846 = 1.0000000150474662E30D;
  
  public static double one$1881 = 1.0D;
  
  public static double zero$1883 = 0.0D;
  
  public static double big$1994 = 1.0000000150474662E30D;
  
  public static double one$2034 = 1.0D;
  
  public static double zero$2037 = 0.0D;
  
  public static double big$2174 = 1.0000000150474662E30D;
  
  public static double one$2214 = 1.0D;
  
  public static double zero$2219 = 0.0D;
  
  public static double $kmns_$zero = 0.0D;
  
  public static double $kmns_$one = 1.0D;
  
  public static double $kmns_$big = 1.0000000150474662E30D;
  
  public static double $optra_$zero = 0.0D;
  
  public static double $optra_$one = 1.0D;
  
  public static double $optra_$big = 1.0000000150474662E30D;
  
  public static double $qtran_$zero = 0.0D;
  
  public static double $qtran_$one = 1.0D;
  
  public static double $qtran_$big = 1.0000000150474662E30D;
  
  public static void kmns_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, Ptr paramPtr11, Ptr paramPtr12, Ptr paramPtr13, Ptr paramPtr14, Ptr paramPtr15, Ptr paramPtr16, Ptr paramPtr17) {
    int[] arrayOfInt = new int[1];
    double[] arrayOfDouble = new double[2];
    arrayOfInt[0] = 0;
    Integer.toUnsignedLong(Math.max(paramPtr2.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr2.getInt(), 0));
    int i = Math.max(paramPtr2.getInt(), 0);
    Integer.toUnsignedLong(Math.max(i * paramPtr3.getInt(), 0));
    int j = i ^ 0xFFFFFFFF;
    int k = Math.max(paramPtr5.getInt(), 0);
    Integer.toUnsignedLong(Math.max(k * paramPtr3.getInt(), 0));
    int m = k ^ 0xFFFFFFFF;
    Integer.toUnsignedLong(Math.max(paramPtr5.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr5.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr5.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr5.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr5.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr2.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr5.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr5.getInt(), 0));
    paramPtr17.setInt(3);
    if (paramPtr5.getInt() > 1 && paramPtr5.getInt() < paramPtr2.getInt()) {
      int n;
      int i1;
      byte b;
      int i2;
      boolean bool;
      paramPtr17.setInt(0);
      int i4 = paramPtr2.getInt();
      int i5 = 1;
      if (1 <= i4)
        while (true) {
          paramPtr6.setAlignedInt(i5 + -1, 1);
          paramPtr7.setAlignedInt(i5 + -1, 2);
          int i6 = 1;
          while (true) {
            arrayOfDouble[i6 + -1] = $kmns_$zero;
            int i7 = paramPtr3.getInt();
            int i8 = 1;
            if (1 <= i7)
              while (true) {
                boolean bool1;
                arrayOfDouble[i6 + -1] = (paramPtr1.getAlignedDouble(i8 * i + j + i5) - paramPtr4.getAlignedDouble(i8 * k + m + i6)) * (paramPtr1.getAlignedDouble(i8 * i + j + i5) - paramPtr4.getAlignedDouble(i8 * k + m + i6)) + arrayOfDouble[i6 + -1];
                if (i8 != i7) {
                  bool1 = false;
                } else {
                  bool1 = true;
                } 
                i8++;
                if (!bool1)
                  continue; 
                break;
              }  
            if (i6 != 2) {
              i7 = 0;
            } else {
              i7 = 1;
            } 
            i6++;
            if (i7 == 0)
              continue; 
            if (arrayOfDouble[0] > arrayOfDouble[1]) {
              paramPtr6.setAlignedInt(i5 + -1, 2);
              paramPtr7.setAlignedInt(i5 + -1, 1);
              arrayOfDouble[0] = arrayOfDouble[1];
              arrayOfDouble[1] = arrayOfDouble[0];
            } 
            i6 = paramPtr5.getInt();
            i7 = 3;
            if (3 <= i6)
              label250: while (true) {
                double d = $kmns_$zero;
                i8 = paramPtr3.getInt();
                byte b1 = 1;
                if (1 > i8) {
                  if (arrayOfDouble[0] <= d) {
                    arrayOfDouble[1] = d;
                    paramPtr7.setAlignedInt(i5 + -1, i7);
                  } else {
                    arrayOfDouble[1] = arrayOfDouble[0];
                    paramPtr7.setAlignedInt(i5 + -1, paramPtr6.getAlignedInt(i5 + -1));
                    arrayOfDouble[0] = d;
                    paramPtr6.setAlignedInt(i5 + -1, i7);
                  } 
                } else {
                  d = (paramPtr1.getAlignedDouble(b1 * i + j + i5) - paramPtr4.getAlignedDouble(b1 * k + m + i7)) * (paramPtr1.getAlignedDouble(b1 * i + j + i5) - paramPtr4.getAlignedDouble(b1 * k + m + i7)) + d;
                  while (arrayOfDouble[1] > d) {
                    boolean bool1;
                    if (b1 != i8) {
                      bool1 = false;
                    } else {
                      bool1 = true;
                    } 
                    b1++;
                    if (!bool1)
                      continue; 
                    continue label250;
                  } 
                } 
                if (i7 != i6) {
                  i8 = 0;
                } else {
                  i8 = 1;
                } 
                i7++;
                if (i8 == 0)
                  continue; 
                break;
              }  
            if (i5 != i4) {
              i6 = 0;
            } else {
              i6 = 1;
            } 
            i5++;
            break;
          } 
          if (i6 == 0)
            continue; 
          break;
        }  
      int i3 = paramPtr5.getInt();
      i4 = 1;
      if (1 <= i3)
        while (true) {
          paramPtr8.setAlignedInt(i4 + -1, 0);
          i5 = paramPtr3.getInt();
          byte b1 = 1;
          if (1 <= i5)
            while (true) {
              boolean bool1;
              paramPtr4.setAlignedDouble(b1 * k + m + i4, $kmns_$zero);
              if (b1 != i5) {
                bool1 = false;
              } else {
                bool1 = true;
              } 
              b1++;
              if (!bool1)
                continue; 
              break;
            }  
          if (i4 != i3) {
            i5 = 0;
          } else {
            i5 = 1;
          } 
          i4++;
          if (i5 == 0)
            continue; 
          break;
        }  
      i3 = paramPtr2.getInt();
      i4 = 1;
      if (1 <= i3)
        while (true) {
          i5 = paramPtr6.getAlignedInt(i4 + -1);
          paramPtr8.setAlignedInt(i5 + -1, paramPtr8.getAlignedInt(i5 + -1) + 1);
          int i6 = paramPtr3.getInt();
          byte b1 = 1;
          if (1 <= i6)
            while (true) {
              boolean bool1;
              paramPtr4.setAlignedDouble(b1 * k + m + i5, paramPtr4.getAlignedDouble(b1 * k + m + i5) + paramPtr1.getAlignedDouble(b1 * i + j + i4));
              if (b1 != i6) {
                bool1 = false;
              } else {
                bool1 = true;
              } 
              b1++;
              if (!bool1)
                continue; 
              break;
            }  
          if (i4 != i3) {
            i5 = 0;
          } else {
            i5 = 1;
          } 
          i4++;
          if (i5 == 0)
            continue; 
          break;
        }  
      i3 = paramPtr5.getInt();
      i4 = 1;
      if (1 > i3) {
        arrayOfInt[0] = 0;
        int i7 = paramPtr15.getInt();
        i3 = 1;
        if (1 > i7) {
          paramPtr17.setInt(2);
        } else {
          while (true) {
            optra_(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramPtr6, paramPtr7, paramPtr8, paramPtr9, paramPtr10, paramPtr11, paramPtr12, paramPtr13, paramPtr14, (Ptr)new IntPtr(arrayOfInt, 0));
            if (paramPtr2.getInt() != arrayOfInt[0]) {
              qtran_(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramPtr6, paramPtr7, paramPtr8, paramPtr9, paramPtr10, paramPtr11, paramPtr12, paramPtr13, (Ptr)new IntPtr(arrayOfInt, 0));
              if (paramPtr5.getInt() != 2) {
                i4 = paramPtr5.getInt();
                i5 = 1;
                if (1 <= i4)
                  while (true) {
                    boolean bool1;
                    paramPtr11.setAlignedInt(i5 + -1, 0);
                    if (i5 != i4) {
                      bool1 = false;
                    } else {
                      bool1 = true;
                    } 
                    i5++;
                    if (!bool1)
                      continue; 
                    break;
                  }  
                if (i3 != i7) {
                  i4 = 0;
                } else {
                  i4 = 1;
                } 
                i3++;
                if (i4 == 0)
                  continue; 
                // Byte code: goto -> 1562
              } 
            } 
            break;
          } 
        } 
        int i6 = paramPtr5.getInt();
        i1 = 1;
        if (1 <= i6)
          while (true) {
            paramPtr16.setAlignedDouble(i1 + -1, $kmns_$zero);
            b = paramPtr3.getInt();
            i2 = 1;
            if (1 <= b)
              while (true) {
                boolean bool1;
                paramPtr4.setAlignedDouble(i2 * k + m + i1, $kmns_$zero);
                if (i2 != b) {
                  bool1 = false;
                } else {
                  bool1 = true;
                } 
                i2++;
                if (!bool1)
                  continue; 
                break;
              }  
            if (i1 != i6) {
              b = 0;
            } else {
              b = 1;
            } 
            i1++;
            if (b == 0)
              continue; 
            break;
          }  
        i6 = paramPtr2.getInt();
        i1 = 1;
        if (1 <= i6)
          while (true) {
            b = paramPtr6.getAlignedInt(i1 + -1);
            i2 = paramPtr3.getInt();
            byte b1 = 1;
            if (1 <= i2)
              while (true) {
                paramPtr4.setAlignedDouble(b1 * k + m + b, paramPtr4.getAlignedDouble(b1 * k + m + b) + paramPtr1.getAlignedDouble(b1 * i + j + i1));
                if (b1 != i2) {
                  bool = false;
                } else {
                  bool = true;
                } 
                b1++;
                if (!bool)
                  continue; 
                break;
              }  
            if (i1 != i6) {
              b = 0;
            } else {
              b = 1;
            } 
            i1++;
            if (b == 0)
              continue; 
            break;
          }  
        n = paramPtr3.getInt();
        i6 = 1;
        if (1 <= n)
          while (true) {
            i1 = paramPtr5.getInt();
            b = 1;
            if (1 <= i1)
              while (true) {
                paramPtr4.setAlignedDouble(i6 * k + m + b, paramPtr4.getAlignedDouble(i6 * k + m + b) / paramPtr8.getAlignedInt(b + -1));
                if (b != i1) {
                  i2 = 0;
                } else {
                  i2 = 1;
                } 
                b++;
                if (!i2)
                  continue; 
                break;
              }  
            i1 = paramPtr2.getInt();
            b = 1;
            if (1 <= i1)
              while (true) {
                i2 = paramPtr6.getAlignedInt(b + -1);
                paramPtr16.setAlignedDouble(i2 + -1, (paramPtr1.getAlignedDouble(i6 * i + j + b) - paramPtr4.getAlignedDouble(i6 * k + m + i2)) * (paramPtr1.getAlignedDouble(i6 * i + j + b) - paramPtr4.getAlignedDouble(i6 * k + m + i2)) + paramPtr16.getAlignedDouble(i2 + -1));
                if (b != i1) {
                  i2 = 0;
                } else {
                  i2 = 1;
                } 
                b++;
                if (i2 == 0)
                  continue; 
                break;
              }  
            if (i6 != n) {
              i1 = 0;
            } else {
              i1 = 1;
            } 
            i6++;
            if (i1 == 0)
              continue; 
            break;
          }  
        return;
      } 
      while (true) {
        if (paramPtr8.getAlignedInt(i4 + -1) != 0) {
          double d = paramPtr8.getAlignedInt(i4 + -1);
          i5 = n.getInt();
          byte b1 = 1;
          if (1 <= i5)
            while (true) {
              boolean bool1;
              paramPtr4.setAlignedDouble(b1 * k + m + i4, paramPtr4.getAlignedDouble(b1 * k + m + i4) / d);
              if (b1 != i5) {
                bool1 = false;
              } else {
                bool1 = true;
              } 
              b1++;
              if (!bool1)
                continue; 
              break;
            }  
          b.setAlignedDouble(i4 + -1, d / (d + $kmns_$one));
          i1.setAlignedDouble(i4 + -1, $kmns_$big);
          if (d > $kmns_$one)
            i1.setAlignedDouble(i4 + -1, d / (d - $kmns_$one)); 
          bool.setAlignedInt(i4 + -1, 1);
          i2.setAlignedInt(i4 + -1, -1);
          if (i4 != i3) {
            i5 = 0;
          } else {
            i5 = 1;
          } 
          i4++;
          if (i5 == 0)
            continue; 
          // Byte code: goto -> 1347
        } 
        paramPtr17.setInt(1);
        break;
      } 
    } 
  }
  
  public static void optra_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, Ptr paramPtr11, Ptr paramPtr12, Ptr paramPtr13, Ptr paramPtr14, Ptr paramPtr15) {
    int i;
    byte b1;
    boolean bool;
    Integer.toUnsignedLong(Math.max(paramPtr5.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr5.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr2.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr2.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr5.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr5.getInt(), 0));
    int j = Math.max(paramPtr2.getInt(), 0);
    Integer.toUnsignedLong(Math.max(j * paramPtr3.getInt(), 0));
    int k = j ^ 0xFFFFFFFF;
    int m = Math.max(paramPtr5.getInt(), 0);
    Integer.toUnsignedLong(Math.max(m * paramPtr3.getInt(), 0));
    int n = m ^ 0xFFFFFFFF;
    Integer.toUnsignedLong(Math.max(paramPtr2.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr5.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr5.getInt(), 0));
    int i1 = paramPtr5.getInt();
    byte b2 = 1;
    if (1 <= i1)
      while (true) {
        boolean bool1;
        if (paramPtr13.getAlignedInt(b2 + -1) == 1)
          paramPtr14.setAlignedInt(b2 + -1, paramPtr2.getInt() + 1); 
        if (b2 != i1) {
          bool1 = false;
        } else {
          bool1 = true;
        } 
        b2++;
        if (!bool1)
          continue; 
        break;
      }  
    i1 = paramPtr2.getInt();
    b2 = 1;
    if (1 > i1) {
      i = paramPtr5.getInt();
      b1 = 1;
      if (1 <= i)
        while (true) {
          paramPtr13.setAlignedInt(b1 + -1, 0);
          paramPtr14.setAlignedInt(b1 + -1, paramPtr14.getAlignedInt(b1 + -1) - paramPtr2.getInt());
          if (b1 != i) {
            bool = false;
          } else {
            bool = true;
          } 
          b1++;
          if (!bool)
            continue; 
          break;
        }  
      return;
    } 
    while (true) {
      paramPtr15.setInt(paramPtr15.getInt() + 1);
      int i2 = paramPtr6.getAlignedInt(b2 + -1);
      int i3 = paramPtr7.getAlignedInt(b2 + -1);
      int i4 = i3;
      if (paramPtr8.getAlignedInt(i2 + -1) != 1) {
        if (paramPtr11.getAlignedInt(i2 + -1) != 0) {
          double d1 = $optra_$zero;
          int i6 = b1.getInt();
          byte b3 = 1;
          if (1 <= i6)
            while (true) {
              boolean bool1;
              d1 = (i.getAlignedDouble(b3 * j + k + b2) - bool.getAlignedDouble(b3 * m + n + i2)) * (i.getAlignedDouble(b3 * j + k + b2) - bool.getAlignedDouble(b3 * m + n + i2)) + d1;
              if (b3 != i6) {
                bool1 = false;
              } else {
                bool1 = true;
              } 
              b3++;
              if (!bool1)
                continue; 
              break;
            }  
          paramPtr12.setAlignedDouble(b2 + -1, paramPtr9.getAlignedDouble(i2 + -1) * d1);
        } 
        double d = $optra_$zero;
        int i5 = b1.getInt();
        byte b = 1;
        if (1 <= i5)
          while (true) {
            boolean bool1;
            d = (i.getAlignedDouble(b * j + k + b2) - bool.getAlignedDouble(b * m + n + i3)) * (i.getAlignedDouble(b * j + k + b2) - bool.getAlignedDouble(b * m + n + i3)) + d;
            if (b != i5) {
              bool1 = false;
            } else {
              bool1 = true;
            } 
            b++;
            if (!bool1)
              continue; 
            break;
          }  
        d = paramPtr10.getAlignedDouble(i3 + -1) * d;
        i5 = paramPtr5.getInt();
        b = 1;
        if (1 <= i5)
          label117: while (true) {
            boolean bool1;
            if ((paramPtr14.getAlignedInt(i2 + -1) > b2 || paramPtr14.getAlignedInt(b + -1) > b2) && b != i2 && b != i4) {
              double d1 = d / paramPtr10.getAlignedDouble(b + -1);
              double d2 = $optra_$zero;
              bool1 = b1.getInt();
              byte b3 = 1;
              if (true > bool1) {
                d = paramPtr10.getAlignedDouble(b + -1) * d2;
                i3 = b;
              } else {
                d2 = (i.getAlignedDouble(b3 * j + k + b2) - bool.getAlignedDouble(b3 * m + n + b)) * (i.getAlignedDouble(b3 * j + k + b2) - bool.getAlignedDouble(b3 * m + n + b)) + d2;
                while (d2 < d1) {
                  boolean bool2;
                  if (b3 != bool1) {
                    bool2 = false;
                  } else {
                    bool2 = true;
                  } 
                  b3++;
                  if (!bool2)
                    continue; 
                  continue label117;
                } 
              } 
            } 
            if (b != i5) {
              bool1 = false;
            } else {
              bool1 = true;
            } 
            b++;
            if (!bool1)
              continue; 
            break;
          }  
        if (paramPtr12.getAlignedDouble(b2 + -1) <= d) {
          paramPtr7.setAlignedInt(b2 + -1, i3);
        } else {
          paramPtr15.setInt(0);
          paramPtr14.setAlignedInt(i2 + -1, paramPtr2.getInt() + b2);
          paramPtr14.setAlignedInt(i3 + -1, paramPtr2.getInt() + b2);
          paramPtr11.setAlignedInt(i2 + -1, b2);
          paramPtr11.setAlignedInt(i3 + -1, b2);
          d = paramPtr8.getAlignedInt(i2 + -1);
          double d1 = d - $optra_$one;
          double d2 = paramPtr8.getAlignedInt(i3 + -1);
          double d3 = d2 + $optra_$one;
          i4 = b1.getInt();
          i5 = 1;
          if (1 <= i4)
            while (true) {
              bool.setAlignedDouble(i5 * m + n + i2, (bool.getAlignedDouble(i5 * m + n + i2) * d - i.getAlignedDouble(i5 * j + k + b2)) / d1);
              bool.setAlignedDouble(i5 * m + n + i3, (bool.getAlignedDouble(i5 * m + n + i3) * d2 + i.getAlignedDouble(i5 * j + k + b2)) / d3);
              if (i5 != i4) {
                b = 0;
              } else {
                b = 1;
              } 
              i5++;
              if (b == 0)
                continue; 
              break;
            }  
          paramPtr8.setAlignedInt(i2 + -1, paramPtr8.getAlignedInt(i2 + -1) + -1);
          paramPtr8.setAlignedInt(i3 + -1, paramPtr8.getAlignedInt(i3 + -1) + 1);
          paramPtr10.setAlignedDouble(i2 + -1, d1 / d);
          paramPtr9.setAlignedDouble(i2 + -1, $optra_$big);
          if (d1 > $optra_$one)
            paramPtr9.setAlignedDouble(i2 + -1, d1 / (d1 - $optra_$one)); 
          paramPtr9.setAlignedDouble(i3 + -1, d3 / d2);
          paramPtr10.setAlignedDouble(i3 + -1, d3 / (d3 + $optra_$one));
          paramPtr6.setAlignedInt(b2 + -1, i3);
          paramPtr7.setAlignedInt(b2 + -1, i2);
        } 
      } 
      if (paramPtr15.getInt() != paramPtr2.getInt()) {
        if (b2 != i1) {
          i2 = 0;
        } else {
          i2 = 1;
        } 
        b2++;
        if (i2 == 0)
          continue; 
        continue;
      } 
      break;
    } 
  }
  
  public static void qtran_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, Ptr paramPtr11, Ptr paramPtr12, Ptr paramPtr13, Ptr paramPtr14) {
    Integer.toUnsignedLong(Math.max(paramPtr2.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr2.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr5.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr5.getInt(), 0));
    int i = Math.max(paramPtr2.getInt(), 0);
    Integer.toUnsignedLong(Math.max(i * paramPtr3.getInt(), 0));
    int j = i ^ 0xFFFFFFFF;
    int k = Math.max(paramPtr5.getInt(), 0);
    Integer.toUnsignedLong(Math.max(k * paramPtr3.getInt(), 0));
    int m = k ^ 0xFFFFFFFF;
    Integer.toUnsignedLong(Math.max(paramPtr2.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr5.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr5.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr5.getInt(), 0));
    byte b1 = 0;
    byte b2 = 0;
    label66: while (true) {
      int n = paramPtr2.getInt();
      byte b = 1;
      if (1 > n)
        continue; 
      label64: while (true) {
        b1++;
        b2++;
        int i1 = paramPtr6.getAlignedInt(b + -1);
        int i2 = paramPtr7.getAlignedInt(b + -1);
        if (paramPtr8.getAlignedInt(i1 + -1) != 1) {
          if (paramPtr11.getAlignedInt(i1 + -1) >= b2) {
            double d = $qtran_$zero;
            int i3 = paramPtr3.getInt();
            byte b3 = 1;
            if (1 <= i3)
              while (true) {
                boolean bool;
                d = (paramPtr1.getAlignedDouble(b3 * i + j + b) - paramPtr4.getAlignedDouble(b3 * k + m + i1)) * (paramPtr1.getAlignedDouble(b3 * i + j + b) - paramPtr4.getAlignedDouble(b3 * k + m + i1)) + d;
                if (b3 != i3) {
                  bool = false;
                } else {
                  bool = true;
                } 
                b3++;
                if (!bool)
                  continue; 
                break;
              }  
            paramPtr12.setAlignedDouble(b + -1, paramPtr9.getAlignedDouble(i1 + -1) * d);
          } 
          if (paramPtr11.getAlignedInt(i1 + -1) > b2 || paramPtr11.getAlignedInt(i2 + -1) > b2) {
            double d1 = paramPtr12.getAlignedDouble(b + -1) / paramPtr10.getAlignedDouble(i2 + -1);
            double d2 = $qtran_$zero;
            int i3 = paramPtr3.getInt();
            byte b3 = 1;
            if (1 > i3) {
              b1 = 0;
              paramPtr14.setInt(0);
              paramPtr13.setAlignedInt(i1 + -1, 1);
              paramPtr13.setAlignedInt(i2 + -1, 1);
              paramPtr11.setAlignedInt(i1 + -1, paramPtr2.getInt() + b2);
              paramPtr11.setAlignedInt(i2 + -1, paramPtr2.getInt() + b2);
              d1 = paramPtr8.getAlignedInt(i1 + -1);
              d2 = d1 - $qtran_$one;
              double d3 = paramPtr8.getAlignedInt(i2 + -1);
              double d4 = d3 + $qtran_$one;
              i3 = paramPtr3.getInt();
              b3 = 1;
              if (1 <= i3)
                while (true) {
                  boolean bool;
                  paramPtr4.setAlignedDouble(b3 * k + m + i1, (paramPtr4.getAlignedDouble(b3 * k + m + i1) * d1 - paramPtr1.getAlignedDouble(b3 * i + j + b)) / d2);
                  paramPtr4.setAlignedDouble(b3 * k + m + i2, (paramPtr4.getAlignedDouble(b3 * k + m + i2) * d3 + paramPtr1.getAlignedDouble(b3 * i + j + b)) / d4);
                  if (b3 != i3) {
                    bool = false;
                  } else {
                    bool = true;
                  } 
                  b3++;
                  if (!bool)
                    continue; 
                  break;
                }  
              paramPtr8.setAlignedInt(i1 + -1, paramPtr8.getAlignedInt(i1 + -1) + -1);
              paramPtr8.setAlignedInt(i2 + -1, paramPtr8.getAlignedInt(i2 + -1) + 1);
              paramPtr10.setAlignedDouble(i1 + -1, d2 / d1);
              paramPtr9.setAlignedDouble(i1 + -1, $qtran_$big);
              if (d2 > $qtran_$one)
                paramPtr9.setAlignedDouble(i1 + -1, d2 / (d2 - $qtran_$one)); 
              paramPtr9.setAlignedDouble(i2 + -1, d4 / d3);
              paramPtr10.setAlignedDouble(i2 + -1, d4 / (d4 + $qtran_$one));
              paramPtr6.setAlignedInt(b + -1, i2);
              paramPtr7.setAlignedInt(b + -1, i1);
            } else {
              d2 = (paramPtr1.getAlignedDouble(b3 * i + j + b) - paramPtr4.getAlignedDouble(b3 * k + m + i2)) * (paramPtr1.getAlignedDouble(b3 * i + j + b) - paramPtr4.getAlignedDouble(b3 * k + m + i2)) + d2;
              while (d2 < d1) {
                boolean bool;
                if (b3 != i3) {
                  bool = false;
                } else {
                  bool = true;
                } 
                b3++;
                if (!bool)
                  continue; 
                continue label64;
              } 
            } 
          } 
        } 
        if (paramPtr2.getInt() != b1) {
          if (b != n) {
            i1 = 0;
          } else {
            i1 = 1;
          } 
          b++;
          if (i1 == 0)
            continue; 
          continue label66;
        } 
        break;
      } 
      break;
    } 
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/stats-0.9.2724.jar!/org/renjin/stats/kmns__.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */