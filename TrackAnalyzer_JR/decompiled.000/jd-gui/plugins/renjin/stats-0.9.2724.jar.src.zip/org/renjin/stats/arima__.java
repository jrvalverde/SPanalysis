package org.renjin.stats;

import org.renjin.gcc.runtime.Builtins;
import org.renjin.gcc.runtime.BytePtr;
import org.renjin.gcc.runtime.DoublePtr;
import org.renjin.gcc.runtime.Mathlib;
import org.renjin.gcc.runtime.Ptr;
import org.renjin.gcc.runtime.Stdlib;
import org.renjin.gnur.api.Arith;
import org.renjin.gnur.api.Error;
import org.renjin.gnur.api.GetText;
import org.renjin.gnur.api.Rinternals;
import org.renjin.gnur.api.Rinternals2;
import org.renjin.sexp.SEXP;

public class arima__ {
  static {
  
  }
  
  public static SEXP ARIMA_CSS(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4, SEXP paramSEXP5, SEXP paramSEXP6) {
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    SEXP sEXP1 = (SEXP)BytePtr.of(0).getArray();
    sEXP1 = Rinternals.R_NilValue;
    double d = 0.0D;
    Ptr ptr3 = Rinternals2.REAL(paramSEXP1);
    Ptr ptr1 = Rinternals2.REAL(paramSEXP3);
    Ptr ptr4 = Rinternals2.REAL(paramSEXP4);
    int i = Rinternals.LENGTH(paramSEXP1);
    Ptr ptr5 = Rinternals2.INTEGER(paramSEXP2);
    int j = Rinternals.LENGTH(paramSEXP3);
    int k = Rinternals.LENGTH(paramSEXP4);
    int m = Rinternals.Rf_asInteger(paramSEXP5);
    byte b = 0;
    int n = Rinternals.Rf_asLogical(paramSEXP6);
    DoublePtr doublePtr = DoublePtr.malloc(i * 8);
    int i2;
    for (i2 = 0; i2 < i; i2++)
      doublePtr.setDouble(0 + i2 * 8, ptr3.getDouble(0 + i2 * 8)); 
    int i1;
    for (i1 = 0; ptr5.getInt(20) > i1; i1++) {
      for (i2 = i + -1; i2 > 0; i2--)
        doublePtr.setDouble(0 + i2 * 8, doublePtr.getDouble(0 + i2 * 8) - doublePtr.getDouble(0 + (i2 + -1) * 8)); 
    } 
    i1 = ptr5.getInt(16);
    for (i2 = 0; ptr5.getInt(24) > i2; i2++) {
      for (int i3 = i + -1; i3 >= i1; i3--)
        doublePtr.setDouble(0 + i3 * 8, doublePtr.getDouble(0 + i3 * 8) - doublePtr.getDouble(0 + (i3 - i1) * 8)); 
    } 
    SEXP sEXP2 = Rinternals.Rf_allocVector(14, i);
    Rinternals.Rf_protect(sEXP2);
    Ptr ptr2 = Rinternals2.REAL(sEXP2);
    if (n != 0)
      for (i2 = 0; i2 < m; i2++)
        ptr2.setDouble(0 + i2 * 8, 0.0D);  
    for (i2 = m; i2 < i; i2++) {
      double d1 = doublePtr.getDouble(0 + i2 * 8);
      byte b1;
      for (b1 = 0; b1 < j; b1++)
        d1 -= ptr1.getDouble(0 + b1 * 8) * doublePtr.getDouble(0 + (i2 - b1 + -1) * 8); 
      for (b1 = 0; Math.min(i2 - m, k) > b1; b1++)
        d1 -= ptr4.getDouble(0 + b1 * 8) * ptr2.getDouble(0 + (i2 - b1 + -1) * 8); 
      ptr2.setDouble(0 + i2 * 8, d1);
      if (Builtins.__isnan(d1) == 0) {
        b++;
        d = d1 * d1 + d;
      } 
    } 
    if (n == 0)
      return Rinternals.Rf_ScalarReal(d / b); 
    null = Rinternals.Rf_allocVector(19, 2);
    Rinternals.Rf_protect(null);
    Rinternals.SET_VECTOR_ELT(null, 0, Rinternals.Rf_ScalarReal(d / b));
    Rinternals.SET_VECTOR_ELT(null, 1, sEXP2);
    return null;
  }
  
  public static SEXP ARIMA_Gradtrans(SEXP paramSEXP1, SEXP paramSEXP2) {
    double[] arrayOfDouble1 = new double[100];
    double[] arrayOfDouble2 = new double[100];
    double[] arrayOfDouble3 = new double[100];
    BytePtr.of(0);
    BytePtr.of(0);
    SEXP sEXP1 = (SEXP)BytePtr.of(0).getArray();
    Ptr ptr2 = Rinternals2.INTEGER(paramSEXP2);
    int k = ptr2.getInt();
    int m = ptr2.getInt(4);
    int i = ptr2.getInt(8);
    int j = Rinternals.LENGTH(paramSEXP1);
    SEXP sEXP2 = Rinternals.Rf_allocMatrix(14, j, j);
    Ptr ptr3 = Rinternals2.REAL(paramSEXP1);
    Ptr ptr1 = Rinternals2.REAL(sEXP2);
    byte b;
    for (b = 0; b < j; b++) {
      for (byte b1 = 0; b1 < j; b1++) {
        double d;
        int n = 0 + (b1 * j + b) * 8;
        if (b != b1) {
          d = 0.0D;
        } else {
          d = 1.0D;
        } 
        ptr1.setDouble(n, d);
      } 
    } 
    if (k > 0) {
      byte b1;
      for (b1 = 0; b1 < k; b1++)
        arrayOfDouble3[b1] = ptr3.getDouble(0 + b1 * 8); 
      partrans(k, (Ptr)new DoublePtr(arrayOfDouble3, 0), (Ptr)new DoublePtr(arrayOfDouble2, 0));
      for (b1 = 0; b1 < k; b1++) {
        arrayOfDouble3[b1] = arrayOfDouble3[b1] + 0.001D;
        partrans(k, (Ptr)new DoublePtr(arrayOfDouble3, 0), (Ptr)new DoublePtr(arrayOfDouble1, 0));
        for (b = 0; b < k; b++)
          ptr1.setDouble(0 + (b * j + b1) * 8, (arrayOfDouble1[b] - arrayOfDouble2[b]) / 0.001D); 
        arrayOfDouble3[b1] = arrayOfDouble3[b1] - 0.001D;
      } 
    } 
    if (i > 0) {
      k += m;
      for (m = 0; m < i; m++)
        arrayOfDouble3[m] = ptr3.getDouble(0 + (m + k) * 8); 
      partrans(i, (Ptr)new DoublePtr(arrayOfDouble3, 0), (Ptr)new DoublePtr(arrayOfDouble2, 0));
      for (m = 0; m < i; m++) {
        arrayOfDouble3[m] = arrayOfDouble3[m] + 0.001D;
        partrans(i, (Ptr)new DoublePtr(arrayOfDouble3, 0), (Ptr)new DoublePtr(arrayOfDouble1, 0));
        for (byte b1 = 0; b1 < i; b1++)
          ptr1.setDouble(0 + (m + k + (b1 + k) * j) * 8, (arrayOfDouble1[b1] - arrayOfDouble2[b1]) / 0.001D); 
        arrayOfDouble3[m] = arrayOfDouble3[m] - 0.001D;
      } 
    } 
    return sEXP2;
  }
  
  public static SEXP ARIMA_Invtrans(SEXP paramSEXP1, SEXP paramSEXP2) {
    BytePtr.of(0);
    BytePtr.of(0);
    SEXP sEXP2 = (SEXP)BytePtr.of(0).getArray();
    Ptr ptr2 = Rinternals2.INTEGER(paramSEXP2);
    int i = ptr2.getInt();
    int j = ptr2.getInt(4);
    int k = ptr2.getInt(8);
    int m = Rinternals.LENGTH(paramSEXP1);
    SEXP sEXP1 = Rinternals.Rf_allocVector(14, m);
    Ptr ptr1 = Rinternals2.REAL(paramSEXP1);
    Ptr ptr3 = Rinternals2.REAL(sEXP1);
    for (byte b = 0; b < m; b++)
      ptr3.setDouble(0 + b * 8, ptr1.getDouble(0 + b * 8)); 
    if (i > 0)
      invpartrans(i, ptr1.pointerPlus(0), ptr3.pointerPlus(0)); 
    i += j;
    if (k > 0) {
      ptr1 = ptr1.pointerPlus(0 + i * 8);
      Ptr ptr = ptr3.pointerPlus(0 + i * 8);
      invpartrans(k, ptr1, ptr);
    } 
    return sEXP1;
  }
  
  public static SEXP ARIMA_Like(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4) {
    DoublePtr doublePtr1;
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    SEXP sEXP7 = (SEXP)BytePtr.of(0).getArray();
    SEXP sEXP6 = splines__.getListElement(paramSEXP2, (Ptr)new BytePtr("phi\000".getBytes(), 0));
    SEXP sEXP5 = splines__.getListElement(paramSEXP2, (Ptr)new BytePtr("theta\000".getBytes(), 0));
    SEXP sEXP4 = splines__.getListElement(paramSEXP2, (Ptr)new BytePtr("Delta\000".getBytes(), 0));
    SEXP sEXP3 = splines__.getListElement(paramSEXP2, (Ptr)new BytePtr("a\000".getBytes(), 0));
    SEXP sEXP2 = splines__.getListElement(paramSEXP2, (Ptr)new BytePtr("P\000".getBytes(), 0));
    SEXP sEXP1 = splines__.getListElement(paramSEXP2, (Ptr)new BytePtr("Pn\000".getBytes(), 0));
    if (Rinternals.TYPEOF(sEXP6) != 14 || Rinternals.TYPEOF(sEXP5) != 14 || Rinternals.TYPEOF(sEXP4) != 14 || Rinternals.TYPEOF(sEXP3) != 14 || Rinternals.TYPEOF(sEXP2) != 14 || Rinternals.TYPEOF(sEXP1) != 14)
      Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("invalid argument type\000".getBytes(), 0)), new Object[0]); 
    paramSEXP2 = Rinternals.R_NilValue;
    int j = Rinternals.LENGTH(paramSEXP1);
    int k = Rinternals.LENGTH(sEXP3);
    int m = Rinternals.LENGTH(sEXP6);
    int n = Rinternals.LENGTH(sEXP5);
    int i1 = Rinternals.LENGTH(sEXP4);
    int i2 = k - i1;
    Ptr ptr1 = Rinternals2.REAL(paramSEXP1);
    Ptr ptr4 = Rinternals2.REAL(sEXP3);
    Ptr ptr3 = Rinternals2.REAL(sEXP2);
    Ptr ptr2 = Rinternals2.REAL(sEXP1);
    Ptr ptr6 = Rinternals2.REAL(sEXP6);
    Ptr ptr5 = Rinternals2.REAL(sEXP5);
    Ptr ptr7 = Rinternals2.REAL(sEXP4);
    double d1 = 0.0D;
    double d2 = 0.0D;
    Ptr ptr8 = BytePtr.of(0);
    byte b1 = 0;
    int i = Rinternals.Rf_asLogical(paramSEXP4);
    Ptr ptr9 = BytePtr.of(0);
    DoublePtr doublePtr2 = DoublePtr.malloc(k * 8);
    DoublePtr doublePtr3 = DoublePtr.malloc(k * 8);
    if (i1 > 0)
      doublePtr1 = DoublePtr.malloc(k * k * 8); 
    if (i != 0) {
      paramSEXP2 = Rinternals.Rf_allocVector(14, j);
      Rinternals.Rf_protect(paramSEXP2);
      ptr9 = Rinternals2.REAL(paramSEXP2);
    } 
    for (byte b2 = 0; b2 < j; b2++) {
      int i3;
      for (i3 = 0; i3 < i2; i3++) {
        double d3;
        if (i2 + -1 <= i3) {
          d3 = 0.0D;
        } else {
          d3 = ptr4.getDouble(0 + (i3 + 1) * 8);
        } 
        double d4 = d3;
        if (i3 < m)
          d4 = ptr6.getDouble(0 + i3 * 8) * ptr4.getDouble(0) + d3; 
        doublePtr2.setDouble(0 + i3 * 8, d4);
      } 
      if (i1 > 0) {
        for (i3 = i2 + 1; i3 < k; i3++)
          doublePtr2.setDouble(0 + i3 * 8, ptr4.getDouble(0 + (i3 + -1) * 8)); 
        double d = ptr4.getDouble(0);
        for (i3 = 0; i3 < i1; i3++)
          d = ptr7.getDouble(0 + i3 * 8) * ptr4.getDouble(0 + (i2 + i3) * 8) + d; 
        doublePtr2.setDouble(0 + i2 * 8, d);
      } 
      if (Rinternals.Rf_asInteger(paramSEXP3) < b2)
        if (i1 != 0) {
          for (i3 = 0; i3 < i2; i3++) {
            for (byte b3 = 0; b3 < k; b3++) {
              double d = 0.0D;
              if (i3 < m)
                d = ptr6.getDouble(0 + i3 * 8) * ptr3.getDouble(0 + k * b3 * 8) + 0.0D; 
              if (i2 + -1 > i3)
                d = ptr3.getDouble(0 + (i3 + 1 + k * b3) * 8) + d; 
              doublePtr1.setDouble(0 + (k * b3 + i3) * 8, d);
            } 
          } 
          for (i3 = 0; i3 < k; i3++) {
            double d = ptr3.getDouble(0 + k * i3 * 8);
            for (byte b3 = 0; b3 < i1; b3++)
              d = ptr7.getDouble(0 + b3 * 8) * ptr3.getDouble(0 + (i2 + b3 + k * i3) * 8) + d; 
            doublePtr1.setDouble(0 + (k * i3 + i2) * 8, d);
          } 
          for (i3 = 1; i3 < i1; i3++) {
            for (byte b3 = 0; b3 < k; b3++)
              doublePtr1.setDouble(0 + (i2 + i3 + k * b3) * 8, ptr3.getDouble(0 + (i2 + i3 + -1 + k * b3) * 8)); 
          } 
          for (i3 = 0; i3 < i2; i3++) {
            for (byte b3 = 0; b3 < k; b3++) {
              double d = 0.0D;
              if (i3 < m)
                d = ptr6.getDouble(0 + i3 * 8) * doublePtr1.getDouble(0 + b3 * 8) + 0.0D; 
              if (i2 + -1 > i3)
                d = doublePtr1.getDouble(0 + ((i3 + 1) * k + b3) * 8) + d; 
              ptr2.setDouble(0 + (k * i3 + b3) * 8, d);
            } 
          } 
          for (i3 = 0; i3 < k; i3++) {
            double d = doublePtr1.getDouble(0 + i3 * 8);
            for (byte b3 = 0; b3 < i1; b3++)
              d = ptr7.getDouble(0 + b3 * 8) * doublePtr1.getDouble(0 + ((i2 + b3) * k + i3) * 8) + d; 
            ptr2.setDouble(0 + (k * i2 + i3) * 8, d);
          } 
          for (i3 = 1; i3 < i1; i3++) {
            for (byte b3 = 0; b3 < k; b3++)
              ptr2.setDouble(0 + ((i2 + i3) * k + b3) * 8, doublePtr1.getDouble(0 + ((i2 + i3 + -1) * k + b3) * 8)); 
          } 
          for (byte b = 0; b <= n; b++) {
            double d3;
            if (b == 0) {
              d3 = 1.0D;
            } else {
              d3 = ptr5.getDouble(0 + (b + -1) * 8);
            } 
            double d4 = d3;
            for (byte b3 = 0; b3 <= n; b3++) {
              double d;
              i3 = 0 + (k * b3 + b) * 8;
              d3 = ptr2.getDouble(0 + (k * b3 + b) * 8);
              if (b3 == 0) {
                d = 1.0D;
              } else {
                d = ptr5.getDouble(0 + (b3 + -1) * 8);
              } 
              ptr2.setDouble(i3, d3 + d * d4);
            } 
          } 
        } else {
          for (i3 = 0; i3 < i2; i3++) {
            double d = 0.0D;
            if (i3 != 0) {
              if (i3 + -1 < n)
                d = ptr5.getDouble(0 + (i3 + -1) * 8); 
            } else {
              d = 1.0D;
            } 
            for (byte b = 0; b < i2; b++) {
              double d3 = 0.0D;
              if (b != 0) {
                if (b + -1 < n)
                  d3 = ptr5.getDouble(0 + (b + -1) * 8) * d; 
              } else {
                d3 = d;
              } 
              if (i3 < m && b < m)
                d3 = ptr6.getDouble(0 + i3 * 8) * ptr6.getDouble(0 + b * 8) * ptr3.getDouble(0) + d3; 
              if (i2 + -1 > i3 && i2 + -1 > b)
                d3 = ptr3.getDouble(0 + (i3 + 1) * 8 + (b + 1) * 8 * i2) + d3; 
              if (i3 < m && i2 + -1 > b)
                d3 = ptr6.getDouble(0 + i3 * 8) * ptr3.getDouble(0 + (b + 1) * 8) + d3; 
              if (b < m && i2 + -1 > i3)
                d3 = ptr6.getDouble(0 + b * 8) * ptr3.getDouble(0 + (i3 + 1) * 8) + d3; 
              ptr2.setDouble(0 + (i2 * b + i3) * 8, d3);
            } 
          } 
        }  
      if (Builtins.__isnan(ptr1.getDouble(0 + b2 * 8)) != 0) {
        for (i3 = 0; i3 < k; i3++)
          ptr4.setDouble(0 + i3 * 8, doublePtr2.getDouble(0 + i3 * 8)); 
        for (i3 = 0; k * k > i3; i3++)
          ptr3.setDouble(0 + i3 * 8, ptr2.getDouble(0 + i3 * 8)); 
        if (i != 0)
          ptr9.setDouble(0 + b2 * 8, Arith.R_NaReal); 
      } else {
        double d3 = ptr1.getDouble(0 + b2 * 8) - doublePtr2.getDouble(0);
        for (i3 = 0; i3 < i1; i3++)
          d3 -= ptr7.getDouble(0 + i3 * 8) * doublePtr2.getDouble(0 + (i2 + i3) * 8); 
        for (i3 = 0; i3 < k; i3++) {
          double d = ptr2.getDouble(0 + i3 * 8);
          for (byte b = 0; b < i1; b++)
            d = ptr2.getDouble(0 + ((i2 + b) * k + i3) * 8) * ptr7.getDouble(0 + b * 8) + d; 
          doublePtr3.setDouble(0 + i3 * 8, d);
        } 
        double d4 = doublePtr3.getDouble(0);
        for (i3 = 0; i3 < i1; i3++)
          d4 = ptr7.getDouble(0 + i3 * 8) * doublePtr3.getDouble(0 + (i2 + i3) * 8) + d4; 
        if (d4 < 10000.0D) {
          b1++;
          d2 = d3 * d3 / d4 + d2;
          d1 = Math.log(d4) + d1;
        } 
        if (i != 0)
          ptr9.setDouble(0 + b2 * 8, d3 / Mathlib.sqrt(d4)); 
        for (i3 = 0; i3 < k; i3++)
          ptr4.setDouble(0 + i3 * 8, doublePtr2.getDouble(0 + i3 * 8) + doublePtr3.getDouble(0 + i3 * 8) * d3 / d4); 
        for (i3 = 0; i3 < k; i3++) {
          for (byte b = 0; b < k; b++)
            ptr3.setDouble(0 + (b * k + i3) * 8, ptr2.getDouble(0 + (b * k + i3) * 8) - doublePtr3.getDouble(0 + i3 * 8) * doublePtr3.getDouble(0 + b * 8) / d4); 
        } 
      } 
    } 
    if (i == 0) {
      null = Rinternals.Rf_allocVector(14, 3);
      Rinternals2.REAL(null).setDouble(0, d2);
      Rinternals2.REAL(null).setDouble(8, d1);
      Rinternals2.REAL(null).setDouble(16, b1);
      return null;
    } 
    null = Rinternals.Rf_allocVector(19, 3);
    Rinternals.Rf_protect(null);
    paramSEXP3 = Rinternals.Rf_allocVector(14, 3);
    Rinternals.SET_VECTOR_ELT(null, 0, paramSEXP3);
    Rinternals2.REAL(paramSEXP3).setDouble(0, d2);
    Rinternals2.REAL(paramSEXP3).setDouble(8, d1);
    Rinternals2.REAL(paramSEXP3).setDouble(16, b1);
    Rinternals.SET_VECTOR_ELT(null, 1, paramSEXP2);
    return null;
  }
  
  public static SEXP ARIMA_transPars(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3) {
    DoublePtr doublePtr;
    SEXP sEXP4 = (SEXP)BytePtr.of(0).getArray();
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    Ptr ptr4 = Rinternals2.INTEGER(paramSEXP2);
    int i = ptr4.getInt();
    int j = ptr4.getInt(4);
    int m = ptr4.getInt(8);
    int n = ptr4.getInt(12);
    int i1 = ptr4.getInt(16);
    int i2 = i1 * m + i;
    int i3 = i1 * n + j;
    Ptr ptr5 = Rinternals2.REAL(paramSEXP1);
    Ptr ptr1 = Rinternals2.REAL(paramSEXP1);
    SEXP sEXP3 = Rinternals.Rf_allocVector(19, 2);
    Rinternals.Rf_protect(sEXP3);
    SEXP sEXP2 = Rinternals.Rf_allocVector(14, i2);
    Rinternals.SET_VECTOR_ELT(sEXP3, 0, sEXP2);
    SEXP sEXP1 = Rinternals.Rf_allocVector(14, i3);
    Rinternals.SET_VECTOR_ELT(sEXP3, 1, sEXP1);
    Ptr ptr3 = Rinternals2.REAL(sEXP2);
    Ptr ptr2 = Rinternals2.REAL(sEXP1);
    if (Rinternals.Rf_asLogical(paramSEXP3) != 0) {
      int i4 = i + j + m + n;
      doublePtr = DoublePtr.malloc(i4 * 8);
      for (byte b1 = 0; b1 < i4; b1++)
        doublePtr.setDouble(0 + b1 * 8, ptr5.getDouble(0 + b1 * 8)); 
      if (i > 0)
        partrans(i, ptr5.pointerPlus(0), doublePtr.pointerPlus(0)); 
      i4 = i + j;
      if (m > 0) {
        ptr5 = ptr5.pointerPlus(0 + i4 * 8);
        Ptr ptr = doublePtr.pointerPlus(0 + i4 * 8);
        partrans(m, ptr5, ptr);
      } 
    } 
    if (i1 <= 0) {
      for (m = 0; m < i; m++)
        ptr3.setDouble(0 + m * 8, doublePtr.getDouble(0 + m * 8)); 
      for (m = 0; m < j; m++)
        ptr2.setDouble(0 + m * 8, doublePtr.getDouble(0 + (m + i) * 8)); 
      return sEXP3;
    } 
    int k;
    for (k = 0; k < i; k++)
      ptr3.setDouble(0 + k * 8, doublePtr.getDouble(0 + k * 8)); 
    for (k = 0; k < j; k++)
      ptr2.setDouble(0 + k * 8, doublePtr.getDouble(0 + (k + i) * 8)); 
    for (k = i; k < i2; k++)
      ptr3.setDouble(0 + k * 8, 0.0D); 
    for (i2 = j; i2 < i3; i2++)
      ptr2.setDouble(0 + i2 * 8, 0.0D); 
    for (i3 = 0; i3 < m; i3++) {
      ptr3.setDouble(0 + (i3 + 1) * 8 * i1 + -8, ptr3.getDouble(0 + (i3 + 1) * 8 * i1 + -8) + doublePtr.getDouble(0 + (i3 + i + j) * 8));
      for (i2 = 0; i2 < i; i2++)
        ptr3.setDouble(0 + ((i3 + 1) * i1 + i2) * 8, ptr3.getDouble(0 + ((i3 + 1) * i1 + i2) * 8) - doublePtr.getDouble(0 + i2 * 8) * doublePtr.getDouble(0 + (i3 + i + j) * 8)); 
    } 
    for (byte b = 0; b < n; b++) {
      ptr2.setDouble(0 + (b + 1) * 8 * i1 + -8, ptr2.getDouble(0 + (b + 1) * 8 * i1 + -8) + doublePtr.getDouble(0 + (b + i + j + m) * 8));
      for (i3 = 0; i3 < j; i3++)
        ptr2.setDouble(0 + ((b + 1) * i1 + i3) * 8, ptr2.getDouble(0 + ((b + 1) * i1 + i3) * 8) + doublePtr.getDouble(0 + (i3 + i) * 8) * doublePtr.getDouble(0 + (b + i + j + m) * 8)); 
    } 
    return sEXP3;
  }
  
  public static SEXP ARIMA_undoPars(SEXP paramSEXP1, SEXP paramSEXP2) {
    SEXP sEXP = (SEXP)BytePtr.of(0).getArray();
    BytePtr.of(0);
    BytePtr.of(0);
    Ptr ptr1 = Rinternals2.INTEGER(paramSEXP2);
    int i = ptr1.getInt();
    int k = ptr1.getInt(4);
    int j = ptr1.getInt(8);
    int m = Rinternals.LENGTH(paramSEXP1);
    Ptr ptr2 = Rinternals2.REAL(paramSEXP1);
    paramSEXP1 = Rinternals.Rf_allocVector(14, m);
    Ptr ptr3 = Rinternals2.REAL(paramSEXP1);
    for (byte b = 0; b < m; b++)
      ptr3.setDouble(0 + b * 8, ptr2.getDouble(0 + b * 8)); 
    if (i > 0)
      partrans(i, ptr2.pointerPlus(0), ptr3.pointerPlus(0)); 
    i += k;
    if (j > 0) {
      Ptr ptr4 = ptr2.pointerPlus(0 + i * 8);
      Ptr ptr5 = ptr3.pointerPlus(0 + i * 8);
      partrans(j, ptr4, ptr5);
    } 
    return paramSEXP1;
  }
  
  public static SEXP KalmanFore(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3) {
    SEXP sEXP8 = (SEXP)BytePtr.of(0).getArray();
    sEXP8 = (SEXP)BytePtr.of(0).getArray();
    sEXP8 = (SEXP)BytePtr.of(0).getArray();
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    paramSEXP2 = Rinternals.Rf_protect(Rinternals.Rf_duplicate(paramSEXP2));
    SEXP sEXP7 = splines__.getListElement(paramSEXP2, (Ptr)new BytePtr("Z\000".getBytes(), 0));
    SEXP sEXP6 = splines__.getListElement(paramSEXP2, (Ptr)new BytePtr("a\000".getBytes(), 0));
    SEXP sEXP5 = splines__.getListElement(paramSEXP2, (Ptr)new BytePtr("P\000".getBytes(), 0));
    SEXP sEXP4 = splines__.getListElement(paramSEXP2, (Ptr)new BytePtr("T\000".getBytes(), 0));
    SEXP sEXP3 = splines__.getListElement(paramSEXP2, (Ptr)new BytePtr("V\000".getBytes(), 0));
    SEXP sEXP2 = splines__.getListElement(paramSEXP2, (Ptr)new BytePtr("h\000".getBytes(), 0));
    if (Rinternals.TYPEOF(sEXP7) != 14 || Rinternals.TYPEOF(sEXP6) != 14 || Rinternals.TYPEOF(sEXP5) != 14 || Rinternals.TYPEOF(sEXP4) != 14 || Rinternals.TYPEOF(sEXP3) != 14)
      Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("invalid argument type\000".getBytes(), 0)), new Object[0]); 
    int i = Rinternals.Rf_asInteger(paramSEXP1);
    int j = Rinternals.LENGTH(sEXP6);
    Ptr ptr5 = Rinternals2.REAL(sEXP7);
    Ptr ptr4 = Rinternals2.REAL(sEXP6);
    Ptr ptr3 = Rinternals2.REAL(sEXP5);
    Ptr ptr2 = Rinternals2.REAL(sEXP4);
    Ptr ptr1 = Rinternals2.REAL(sEXP3);
    double d = Rinternals.Rf_asReal(sEXP2);
    DoublePtr doublePtr1 = DoublePtr.malloc(j * 8);
    DoublePtr doublePtr2 = DoublePtr.malloc(j * j * 8);
    DoublePtr doublePtr3 = DoublePtr.malloc(j * j * 8);
    SEXP sEXP9 = Rinternals.Rf_allocVector(19, 2);
    Rinternals.Rf_protect(sEXP9);
    SEXP sEXP10 = Rinternals.Rf_allocVector(14, i);
    Rinternals.SET_VECTOR_ELT(sEXP9, 0, sEXP10);
    SEXP sEXP11 = Rinternals.Rf_allocVector(14, i);
    Rinternals.SET_VECTOR_ELT(sEXP9, 1, sEXP11);
    SEXP sEXP1 = Rinternals.Rf_protect(Rinternals.Rf_allocVector(16, 2));
    Rinternals.SET_STRING_ELT(sEXP1, 0, Rinternals.Rf_mkChar((Ptr)new BytePtr("pred\000".getBytes(), 0)));
    Rinternals.SET_STRING_ELT(sEXP1, 1, Rinternals.Rf_mkChar((Ptr)new BytePtr("var\000".getBytes(), 0)));
    Rinternals.Rf_setAttrib(sEXP9, Rinternals.R_NamesSymbol, sEXP1);
    for (byte b = 0; b < i; b++) {
      double d1 = 0.0D;
      byte b1;
      for (b1 = 0; b1 < j; b1++) {
        double d2 = 0.0D;
        for (byte b2 = 0; b2 < j; b2++)
          d2 = ptr2.getDouble(0 + (j * b2 + b1) * 8) * ptr4.getDouble(0 + b2 * 8) + d2; 
        doublePtr1.setDouble(0 + b1 * 8, d2);
        d1 = ptr5.getDouble(0 + b1 * 8) * d2 + d1;
      } 
      for (b1 = 0; b1 < j; b1++)
        ptr4.setDouble(0 + b1 * 8, doublePtr1.getDouble(0 + b1 * 8)); 
      Rinternals2.REAL(sEXP10).setDouble(0 + b * 8, d1);
      for (b1 = 0; b1 < j; b1++) {
        for (byte b2 = 0; b2 < j; b2++) {
          d1 = 0.0D;
          for (byte b3 = 0; b3 < j; b3++)
            d1 = ptr2.getDouble(0 + (j * b3 + b1) * 8) * ptr3.getDouble(0 + (j * b2 + b3) * 8) + d1; 
          doublePtr3.setDouble(0 + (j * b2 + b1) * 8, d1);
        } 
      } 
      for (b1 = 0; b1 < j; b1++) {
        for (byte b2 = 0; b2 < j; b2++) {
          d1 = ptr1.getDouble(0 + (j * b2 + b1) * 8);
          for (byte b3 = 0; b3 < j; b3++)
            d1 = doublePtr3.getDouble(0 + (j * b3 + b1) * 8) * ptr2.getDouble(0 + (j * b3 + b2) * 8) + d1; 
          doublePtr2.setDouble(0 + (j * b2 + b1) * 8, d1);
        } 
      } 
      d1 = d;
      for (b1 = 0; b1 < j; b1++) {
        for (byte b2 = 0; b2 < j; b2++) {
          ptr3.setDouble(0 + (b2 * j + b1) * 8, doublePtr2.getDouble(0 + (b2 * j + b1) * 8));
          d1 = ptr5.getDouble(0 + b1 * 8) * ptr5.getDouble(0 + b2 * 8) * ptr3.getDouble(0 + (b2 * j + b1) * 8) + d1;
        } 
      } 
      Rinternals2.REAL(sEXP11).setDouble(0 + b * 8, d1);
    } 
    if (Rinternals.Rf_asLogical(paramSEXP3) != 0)
      Rinternals.Rf_setAttrib(sEXP9, Rinternals.Rf_install(new BytePtr("mod\000".getBytes(), 0)), paramSEXP2); 
    return sEXP9;
  }
  
  public static SEXP KalmanLike(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4, SEXP paramSEXP5) {
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    SEXP sEXP8 = (SEXP)BytePtr.of(0).getArray();
    sEXP8 = (SEXP)BytePtr.of(0).getArray();
    sEXP8 = (SEXP)BytePtr.of(0).getArray();
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    int i = Rinternals.Rf_asLogical(paramSEXP4);
    paramSEXP2 = Rinternals.Rf_protect(Rinternals.Rf_duplicate(paramSEXP2));
    SEXP sEXP7 = splines__.getListElement(paramSEXP2, (Ptr)new BytePtr("Z\000".getBytes(), 0));
    SEXP sEXP6 = splines__.getListElement(paramSEXP2, (Ptr)new BytePtr("a\000".getBytes(), 0));
    SEXP sEXP5 = splines__.getListElement(paramSEXP2, (Ptr)new BytePtr("P\000".getBytes(), 0));
    SEXP sEXP4 = splines__.getListElement(paramSEXP2, (Ptr)new BytePtr("T\000".getBytes(), 0));
    SEXP sEXP3 = splines__.getListElement(paramSEXP2, (Ptr)new BytePtr("V\000".getBytes(), 0));
    SEXP sEXP2 = splines__.getListElement(paramSEXP2, (Ptr)new BytePtr("h\000".getBytes(), 0));
    SEXP sEXP1 = splines__.getListElement(paramSEXP2, (Ptr)new BytePtr("Pn\000".getBytes(), 0));
    if (Rinternals.TYPEOF(paramSEXP1) != 14 || Rinternals.TYPEOF(sEXP7) != 14 || Rinternals.TYPEOF(sEXP6) != 14 || Rinternals.TYPEOF(sEXP5) != 14 || Rinternals.TYPEOF(sEXP1) != 14 || Rinternals.TYPEOF(sEXP4) != 14 || Rinternals.TYPEOF(sEXP3) != 14)
      Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("invalid argument type\000".getBytes(), 0)), new Object[0]); 
    int j = Rinternals.LENGTH(paramSEXP1);
    int k = Rinternals.LENGTH(sEXP6);
    Ptr ptr1 = Rinternals2.REAL(paramSEXP1);
    Ptr ptr7 = Rinternals2.REAL(sEXP7);
    Ptr ptr4 = Rinternals2.REAL(sEXP4);
    Ptr ptr3 = Rinternals2.REAL(sEXP3);
    Ptr ptr5 = Rinternals2.REAL(sEXP5);
    Ptr ptr6 = Rinternals2.REAL(sEXP6);
    Ptr ptr2 = Rinternals2.REAL(sEXP1);
    double d1 = Rinternals.Rf_asReal(sEXP2);
    DoublePtr doublePtr1 = DoublePtr.malloc(k * 8);
    DoublePtr doublePtr2 = DoublePtr.malloc(k * 8);
    DoublePtr doublePtr3 = DoublePtr.malloc(k * k * 8);
    sEXP2 = Rinternals.R_NilValue;
    SEXP sEXP9 = Rinternals.R_NilValue;
    SEXP sEXP10 = Rinternals.R_NilValue;
    if (i != 0) {
      sEXP2 = Rinternals.Rf_allocVector(19, 3);
      Rinternals.Rf_protect(sEXP2);
      sEXP9 = Rinternals.Rf_allocVector(14, j);
      Rinternals.SET_VECTOR_ELT(sEXP2, 1, sEXP9);
      sEXP10 = Rinternals.Rf_allocMatrix(14, j, k);
      Rinternals.SET_VECTOR_ELT(sEXP2, 2, sEXP10);
      SEXP sEXP = Rinternals.Rf_protect(Rinternals.Rf_allocVector(16, 3));
      Rinternals.SET_STRING_ELT(sEXP, 0, Rinternals.Rf_mkChar((Ptr)new BytePtr("values\000".getBytes(), 0)));
      Rinternals.SET_STRING_ELT(sEXP, 1, Rinternals.Rf_mkChar((Ptr)new BytePtr("resid\000".getBytes(), 0)));
      Rinternals.SET_STRING_ELT(sEXP, 2, Rinternals.Rf_mkChar((Ptr)new BytePtr("states\000".getBytes(), 0)));
      Rinternals.Rf_setAttrib(sEXP2, Rinternals.R_NamesSymbol, sEXP);
    } 
    double d2 = 0.0D;
    double d3 = 0.0D;
    byte b1 = 0;
    for (byte b2 = 0; b2 < j; b2++) {
      byte b;
      for (b = 0; b < k; b++) {
        double d = 0.0D;
        for (byte b3 = 0; b3 < k; b3++)
          d = ptr4.getDouble(0 + (k * b3 + b) * 8) * ptr6.getDouble(0 + b3 * 8) + d; 
        doublePtr1.setDouble(0 + b * 8, d);
      } 
      if (Rinternals.Rf_asInteger(paramSEXP3) < b2) {
        for (b = 0; b < k; b++) {
          for (byte b3 = 0; b3 < k; b3++) {
            double d = 0.0D;
            for (byte b4 = 0; b4 < k; b4++)
              d = ptr4.getDouble(0 + (k * b4 + b) * 8) * ptr5.getDouble(0 + (k * b3 + b4) * 8) + d; 
            doublePtr3.setDouble(0 + (k * b3 + b) * 8, d);
          } 
        } 
        for (b = 0; b < k; b++) {
          for (byte b3 = 0; b3 < k; b3++) {
            double d = ptr3.getDouble(0 + (k * b3 + b) * 8);
            for (byte b4 = 0; b4 < k; b4++)
              d = doublePtr3.getDouble(0 + (k * b4 + b) * 8) * ptr4.getDouble(0 + (k * b4 + b3) * 8) + d; 
            ptr2.setDouble(0 + (k * b3 + b) * 8, d);
          } 
        } 
      } 
      if (Builtins.__isnan(ptr1.getDouble(0 + b2 * 8)) != 0) {
        Ptr ptr = BytePtr.of(0);
        if (i != 0)
          ptr = Rinternals2.REAL(sEXP9); 
        byte b3;
        for (b3 = 0; b3 < k; b3++)
          ptr6.setDouble(0 + b3 * 8, doublePtr1.getDouble(0 + b3 * 8)); 
        for (b3 = 0; k * k > b3; b3++)
          ptr5.setDouble(0 + b3 * 8, ptr2.getDouble(0 + b3 * 8)); 
        if (i != 0)
          ptr.setDouble(0 + b2 * 8, Arith.R_NaReal); 
      } else {
        b1++;
        Ptr ptr = BytePtr.of(0);
        if (i != 0)
          ptr = Rinternals2.REAL(sEXP9); 
        double d4 = ptr1.getDouble(0 + b2 * 8);
        byte b4;
        for (b4 = 0; b4 < k; b4++)
          d4 -= ptr7.getDouble(0 + b4 * 8) * doublePtr1.getDouble(0 + b4 * 8); 
        double d5 = d1;
        for (b4 = 0; b4 < k; b4++) {
          double d = 0.0D;
          for (byte b5 = 0; b5 < k; b5++)
            d = ptr2.getDouble(0 + (b5 * k + b4) * 8) * ptr7.getDouble(0 + b5 * 8) + d; 
          doublePtr2.setDouble(0 + b4 * 8, d);
          d5 = ptr7.getDouble(0 + b4 * 8) * doublePtr2.getDouble(0 + b4 * 8) + d5;
        } 
        d3 = d4 * d4 / d5 + d3;
        if (i != 0)
          ptr.setDouble(0 + b2 * 8, d4 / Mathlib.sqrt(d5)); 
        d2 = Math.log(d5) + d2;
        byte b3;
        for (b3 = 0; b3 < k; b3++)
          ptr6.setDouble(0 + b3 * 8, doublePtr1.getDouble(0 + b3 * 8) + doublePtr2.getDouble(0 + b3 * 8) * d4 / d5); 
        for (b3 = 0; b3 < k; b3++) {
          for (b4 = 0; b4 < k; b4++)
            ptr5.setDouble(0 + (b4 * k + b3) * 8, ptr2.getDouble(0 + (b4 * k + b3) * 8) - doublePtr2.getDouble(0 + b3 * 8) * doublePtr2.getDouble(0 + b4 * 8) / d5); 
        } 
      } 
      if (i != 0) {
        Ptr ptr = Rinternals2.REAL(sEXP10);
        for (byte b3 = 0; b3 < k; b3++)
          ptr.setDouble(0 + (j * b3 + b2) * 8, ptr6.getDouble(0 + b3 * 8)); 
      } 
    } 
    null = Rinternals.Rf_protect(Rinternals.Rf_allocVector(14, 2));
    Rinternals2.REAL(null).setDouble(0, d3 / b1);
    Rinternals2.REAL(null).setDouble(8, d2 / b1);
    if (i == 0) {
      if (Rinternals.Rf_asLogical(paramSEXP5) != 0)
        Rinternals.Rf_setAttrib(null, Rinternals.Rf_install(new BytePtr("mod\000".getBytes(), 0)), paramSEXP2); 
      return null;
    } 
    Rinternals.SET_VECTOR_ELT(sEXP2, 0, null);
    if (Rinternals.Rf_asLogical(paramSEXP5) != 0)
      Rinternals.Rf_setAttrib(sEXP2, Rinternals.Rf_install(new BytePtr("mod\000".getBytes(), 0)), paramSEXP2); 
    return sEXP2;
  }
  
  public static SEXP KalmanSmooth(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3) {
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    SEXP sEXP8 = (SEXP)BytePtr.of(0).getArray();
    SEXP sEXP7 = splines__.getListElement(paramSEXP2, (Ptr)new BytePtr("Z\000".getBytes(), 0));
    SEXP sEXP6 = splines__.getListElement(paramSEXP2, (Ptr)new BytePtr("a\000".getBytes(), 0));
    SEXP sEXP5 = splines__.getListElement(paramSEXP2, (Ptr)new BytePtr("P\000".getBytes(), 0));
    SEXP sEXP4 = splines__.getListElement(paramSEXP2, (Ptr)new BytePtr("T\000".getBytes(), 0));
    SEXP sEXP3 = splines__.getListElement(paramSEXP2, (Ptr)new BytePtr("V\000".getBytes(), 0));
    SEXP sEXP2 = splines__.getListElement(paramSEXP2, (Ptr)new BytePtr("h\000".getBytes(), 0));
    SEXP sEXP1 = splines__.getListElement(paramSEXP2, (Ptr)new BytePtr("Pn\000".getBytes(), 0));
    if (Rinternals.TYPEOF(paramSEXP1) != 14 || Rinternals.TYPEOF(sEXP7) != 14 || Rinternals.TYPEOF(sEXP6) != 14 || Rinternals.TYPEOF(sEXP5) != 14 || Rinternals.TYPEOF(sEXP4) != 14 || Rinternals.TYPEOF(sEXP3) != 14)
      Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("invalid argument type\000".getBytes(), 0)), new Object[0]); 
    paramSEXP2 = Rinternals.R_NilValue;
    int i = Rinternals.LENGTH(paramSEXP1);
    int j = Rinternals.LENGTH(sEXP6);
    Ptr ptr6 = Rinternals2.REAL(paramSEXP1);
    Ptr ptr4 = Rinternals2.REAL(sEXP7);
    Ptr ptr2 = Rinternals2.REAL(sEXP4);
    Ptr ptr5 = Rinternals2.REAL(sEXP3);
    double d = Rinternals.Rf_asReal(sEXP2);
    Rinternals.Rf_protect(Rinternals.Rf_duplicate(sEXP6));
    Ptr ptr7 = Rinternals2.REAL(Rinternals.Rf_duplicate(sEXP6));
    Rinternals.Rf_protect(Rinternals.Rf_duplicate(sEXP5));
    Ptr ptr8 = Rinternals2.REAL(Rinternals.Rf_duplicate(sEXP5));
    Rinternals.Rf_protect(Rinternals.Rf_duplicate(sEXP1));
    Ptr ptr9 = Rinternals2.REAL(Rinternals.Rf_duplicate(sEXP1));
    paramSEXP1 = Rinternals.Rf_allocVector(19, 2);
    Rinternals.Rf_protect(paramSEXP1);
    sEXP1 = Rinternals.Rf_protect(Rinternals.Rf_allocVector(16, 2));
    Rinternals.SET_STRING_ELT(sEXP1, 0, Rinternals.Rf_mkChar((Ptr)new BytePtr("smooth\000".getBytes(), 0)));
    Rinternals.SET_STRING_ELT(sEXP1, 1, Rinternals.Rf_mkChar((Ptr)new BytePtr("var\000".getBytes(), 0)));
    Rinternals.Rf_setAttrib(paramSEXP1, Rinternals.R_NamesSymbol, sEXP1);
    sEXP1 = Rinternals.Rf_allocMatrix(14, i, j);
    Rinternals.SET_VECTOR_ELT(paramSEXP1, 0, sEXP1);
    Ptr ptr3 = Rinternals2.REAL(sEXP1);
    sEXP1 = Rinternals.Rf_allocVector(14, i * j * j);
    Rinternals.SET_VECTOR_ELT(paramSEXP1, 1, sEXP1);
    Ptr ptr1 = Rinternals2.REAL(sEXP1);
    DoublePtr doublePtr5 = DoublePtr.malloc(j * 8);
    DoublePtr doublePtr6 = DoublePtr.malloc(j * 8);
    DoublePtr doublePtr4 = DoublePtr.malloc(j * j * 8);
    DoublePtr doublePtr2 = DoublePtr.malloc(i * j * j * 8);
    DoublePtr doublePtr3 = DoublePtr.malloc(i * 8);
    DoublePtr doublePtr7 = DoublePtr.malloc(i * 8);
    DoublePtr doublePtr8 = DoublePtr.malloc(i * j * 8);
    DoublePtr doublePtr9 = DoublePtr.malloc(j * j * 8);
    for (byte b2 = 0; b2 < i; b2++) {
      byte b;
      for (b = 0; b < j; b++) {
        double d1 = 0.0D;
        for (byte b3 = 0; b3 < j; b3++)
          d1 = ptr2.getDouble(0 + (j * b3 + b) * 8) * ptr7.getDouble(0 + b3 * 8) + d1; 
        doublePtr5.setDouble(0 + b * 8, d1);
      } 
      if (Rinternals.Rf_asInteger(paramSEXP3) < b2) {
        for (b = 0; b < j; b++) {
          for (byte b3 = 0; b3 < j; b3++) {
            double d1 = 0.0D;
            for (byte b4 = 0; b4 < j; b4++)
              d1 = ptr2.getDouble(0 + (j * b4 + b) * 8) * ptr8.getDouble(0 + (j * b3 + b4) * 8) + d1; 
            doublePtr4.setDouble(0 + (j * b3 + b) * 8, d1);
          } 
        } 
        for (b = 0; b < j; b++) {
          for (byte b3 = 0; b3 < j; b3++) {
            double d1 = ptr5.getDouble(0 + (j * b3 + b) * 8);
            for (byte b4 = 0; b4 < j; b4++)
              d1 = doublePtr4.getDouble(0 + (j * b4 + b) * 8) * ptr2.getDouble(0 + (j * b4 + b3) * 8) + d1; 
            ptr9.setDouble(0 + (j * b3 + b) * 8, d1);
          } 
        } 
      } 
      for (b = 0; b < j; b++)
        ptr3.setDouble(0 + (i * b + b2) * 8, doublePtr5.getDouble(0 + b * 8)); 
      for (b = 0; j * j > b; b++)
        doublePtr2.setDouble(0 + (i * b + b2) * 8, ptr9.getDouble(0 + b * 8)); 
      if (Builtins.__isnan(ptr6.getDouble(0 + b2 * 8)) != 0) {
        for (b = 0; b < j; b++) {
          ptr7.setDouble(0 + b * 8, doublePtr5.getDouble(0 + b * 8));
          doublePtr8.setDouble(0 + (i * b + b2) * 8, 0.0D);
        } 
        for (b = 0; j * j > b; b++)
          ptr8.setDouble(0 + b * 8, ptr9.getDouble(0 + b * 8)); 
        doublePtr3.setDouble(0 + b2 * 8, Arith.R_NaReal);
        doublePtr7.setDouble(0 + b2 * 8, Arith.R_NaReal);
      } else {
        double d1 = ptr6.getDouble(0 + b2 * 8);
        for (b = 0; b < j; b++)
          d1 -= ptr4.getDouble(0 + b * 8) * doublePtr5.getDouble(0 + b * 8); 
        double d2 = d;
        for (b = 0; b < j; b++) {
          double d3 = 0.0D;
          int m;
          for (m = 0; m < j; m++)
            d3 = ptr9.getDouble(0 + (m * j + b) * 8) * ptr4.getDouble(0 + m * 8) + d3; 
          m = 0 + b * 8;
          doublePtr6.setDouble(m, d3);
          doublePtr8.setDouble(0 + (i * b + b2) * 8, doublePtr6.getDouble(m));
          d2 = ptr4.getDouble(0 + b * 8) * doublePtr6.getDouble(0 + b * 8) + d2;
        } 
        doublePtr3.setDouble(0 + b2 * 8, d2);
        doublePtr7.setDouble(0 + b2 * 8, d1);
        for (b = 0; b < j; b++)
          ptr7.setDouble(0 + b * 8, doublePtr5.getDouble(0 + b * 8) + doublePtr6.getDouble(0 + b * 8) * d1 / d2); 
        for (b = 0; b < j; b++) {
          for (byte b3 = 0; b3 < j; b3++)
            ptr8.setDouble(0 + (b3 * j + b) * 8, ptr9.getDouble(0 + (b3 * j + b) * 8) - doublePtr6.getDouble(0 + b * 8) * doublePtr6.getDouble(0 + b3 * 8) / d2); 
        } 
      } 
    } 
    DoublePtr doublePtr1 = DoublePtr.malloc(i * j * 8);
    for (int k = i + -1; k >= 0; k--) {
      if (Builtins.__isnan(doublePtr3.getDouble(0 + k * 8)) != 0) {
        for (byte b = 0; b < j; b++)
          doublePtr1.setDouble(0 + (i * b + k) * 8, 0.0D); 
        d = 0.0D;
      } else {
        d = 1.0D / doublePtr3.getDouble(0 + k * 8);
        for (byte b = 0; b < j; b++)
          doublePtr1.setDouble(0 + (i * b + k) * 8, ptr4.getDouble(0 + b * 8) * doublePtr7.getDouble(0 + k * 8) * d); 
      } 
      int m;
      for (m = 0; m < j; m++) {
        for (byte b = 0; b < j; b++)
          ptr1.setDouble(0 + (i * m + k + i * j * b) * 8, ptr4.getDouble(0 + m * 8) * ptr4.getDouble(0 + b * 8) * d); 
      } 
      if (i + -1 > k) {
        byte b;
        for (b = 0; b < j; b++) {
          for (byte b3 = 0; b3 < j; b3++) {
            double d1;
            m = 0 + (j * b3 + b) * 8;
            if (b != b3) {
              d1 = 0.0D;
            } else {
              d1 = 1.0D;
            } 
            doublePtr4.setDouble(m, d1 - doublePtr8.getDouble(0 + (i * b + k) * 8) * ptr4.getDouble(0 + b3 * 8) * d);
          } 
        } 
        for (m = 0; m < j; m++) {
          for (b = 0; b < j; b++) {
            d = 0.0D;
            for (byte b3 = 0; b3 < j; b3++)
              d = ptr2.getDouble(0 + (j * b3 + m) * 8) * doublePtr4.getDouble(0 + (j * b + b3) * 8) + d; 
            doublePtr9.setDouble(0 + (j * b + m) * 8, d);
          } 
        } 
        for (m = 0; m < j; m++) {
          d = 0.0D;
          for (b = 0; b < j; b++)
            d = doublePtr9.getDouble(0 + (j * m + b) * 8) * doublePtr1.getDouble(0 + (k + 1 + i * b) * 8) + d; 
          doublePtr1.setDouble(0 + (i * m + k) * 8, doublePtr1.getDouble(0 + (i * m + k) * 8) + d);
        } 
        for (m = 0; m < j; m++) {
          for (b = 0; b < j; b++) {
            d = 0.0D;
            for (byte b3 = 0; b3 < j; b3++)
              d = doublePtr9.getDouble(0 + (j * m + b3) * 8) * ptr1.getDouble(0 + (k + 1 + i * b3 + i * j * b) * 8) + d; 
            doublePtr4.setDouble(0 + (j * b + m) * 8, d);
          } 
        } 
        for (m = 0; m < j; m++) {
          for (b = 0; b < j; b++) {
            d = 0.0D;
            for (byte b3 = 0; b3 < j; b3++)
              d = doublePtr4.getDouble(0 + (j * b3 + m) * 8) * doublePtr9.getDouble(0 + (j * b + b3) * 8) + d; 
            ptr1.setDouble(0 + (i * m + k + i * j * b) * 8, ptr1.getDouble(0 + (i * m + k + i * j * b) * 8) + d);
          } 
        } 
      } 
      for (m = 0; m < j; m++) {
        d = 0.0D;
        for (byte b = 0; b < j; b++)
          d = doublePtr2.getDouble(0 + (i * m + k + i * j * b) * 8) * doublePtr1.getDouble(0 + (i * b + k) * 8) + d; 
        ptr3.setDouble(0 + (i * m + k) * 8, ptr3.getDouble(0 + (i * m + k) * 8) + d);
      } 
    } 
    for (byte b1 = 0; b1 < i; b1++) {
      byte b;
      for (b = 0; b < j; b++) {
        for (byte b3 = 0; b3 < j; b3++) {
          d = 0.0D;
          for (byte b4 = 0; b4 < j; b4++)
            d = doublePtr2.getDouble(0 + (i * b + b1 + i * j * b4) * 8) * ptr1.getDouble(0 + (i * b4 + b1 + i * j * b3) * 8) + d; 
          doublePtr4.setDouble(0 + (j * b3 + b) * 8, d);
        } 
      } 
      for (b = 0; b < j; b++) {
        for (byte b3 = 0; b3 < j; b3++) {
          d = doublePtr2.getDouble(0 + (i * b + b1 + i * j * b3) * 8);
          for (byte b4 = 0; b4 < j; b4++)
            d -= doublePtr4.getDouble(0 + (j * b4 + b) * 8) * doublePtr2.getDouble(0 + (i * b4 + b1 + i * j * b3) * 8); 
          ptr1.setDouble(0 + (i * b + b1 + i * j * b3) * 8, d);
        } 
      } 
    } 
    return paramSEXP1;
  }
  
  public static SEXP TSconv(SEXP paramSEXP1, SEXP paramSEXP2) {
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    SEXP sEXP1 = (SEXP)BytePtr.of(0).getArray();
    SEXP sEXP2 = Rinternals.Rf_coerceVector(paramSEXP1, 14);
    Rinternals.Rf_protect(sEXP2);
    SEXP sEXP3 = Rinternals.Rf_coerceVector(paramSEXP2, 14);
    Rinternals.Rf_protect(sEXP3);
    int i = Rinternals.LENGTH(sEXP2);
    int j = Rinternals.LENGTH(sEXP3);
    int k = i + j + -1;
    sEXP1 = Rinternals.Rf_allocVector(14, k);
    Rinternals.Rf_protect(sEXP1);
    Ptr ptr1 = Rinternals2.REAL(sEXP2);
    Ptr ptr2 = Rinternals2.REAL(sEXP3);
    Ptr ptr3 = Rinternals2.REAL(sEXP1);
    byte b;
    for (b = 0; b < k; b++)
      ptr3.setDouble(0 + b * 8, 0.0D); 
    for (k = 0; k < i; k++) {
      for (b = 0; b < j; b++)
        ptr3.setDouble(0 + (k + b) * 8, ptr3.getDouble(0 + (k + b) * 8) + ptr1.getDouble(0 + k * 8) * ptr2.getDouble(0 + b * 8)); 
    } 
    return sEXP1;
  }
  
  public static SEXP getQ0(SEXP paramSEXP1, SEXP paramSEXP2) {
    byte b1;
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    SEXP sEXP2 = (SEXP)BytePtr.of(0).getArray();
    int m = Rinternals.LENGTH(paramSEXP1);
    int k = Rinternals.LENGTH(paramSEXP2);
    Ptr ptr1 = Rinternals2.REAL(paramSEXP1);
    Ptr ptr2 = Rinternals2.REAL(paramSEXP2);
    int i = Math.max(k + 1, m);
    int j = (i + 1) * i / 2;
    int n = Integer.divideUnsigned((j + -1) * j, 2);
    if (i > 350)
      Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("maximum supported lag is 350\000".getBytes(), 0)), new Object[0]); 
    DoublePtr doublePtr1 = DoublePtr.malloc(j * 8);
    DoublePtr doublePtr2 = DoublePtr.malloc(j * 8);
    DoublePtr doublePtr3 = DoublePtr.malloc(n * 8);
    DoublePtr doublePtr4 = DoublePtr.malloc(j * 8);
    DoublePtr doublePtr5 = DoublePtr.malloc(j * 8);
    int i1 = 0;
    byte b2;
    for (b2 = 0; Integer.compareUnsigned(i, b2) > 0; b2++) {
      double d = 0.0D;
      if (b2) {
        if (Integer.compareUnsigned(b2 + -1, k) < 0)
          d = ptr2.getDouble(0 + (b2 + -1) * 8); 
      } else {
        d = 1.0D;
      } 
      for (byte b = b2; Integer.compareUnsigned(i, b) > 0; b++) {
        double d1 = 0.0D;
        if (b != 0) {
          if (Integer.compareUnsigned(b + -1, k) < 0)
            d1 = ptr2.getDouble(0 + (b + -1) * 8); 
        } else {
          d1 = 1.0D;
        } 
        doublePtr5.setDouble(0 + i1 * 8, d1 * d);
        i1++;
      } 
    } 
    SEXP sEXP1 = Rinternals.Rf_allocMatrix(14, i, i);
    Rinternals.Rf_protect(sEXP1);
    ptr2 = Rinternals2.REAL(sEXP1);
    if (i != 1) {
      int i3;
      int i4;
      if (m <= 0) {
        i2 = j;
        i3 = j;
        for (i4 = 0; Integer.compareUnsigned(i, i4) > 0; i4++) {
          for (i1 = 0; Integer.compareUnsigned(i1, i4) <= 0; i1++) {
            ptr2.setDouble(0 + --i3 * 8, doublePtr5.getDouble(0 + i3 * 8));
            if (i1 != 0)
              ptr2.setDouble(0 + i3 * 8, ptr2.getDouble(0 + i3 * 8) + ptr2.getDouble(0 + --i2 * 8)); 
          } 
        } 
      } else {
        for (i1 = 0; Integer.compareUnsigned(i1, n) < 0; i1++)
          i3.setDouble(0 + i1 * 8, 0.0D); 
        for (i1 = 0; Integer.compareUnsigned(i1, j) < 0; i1++) {
          ptr2.setDouble(0 + i1 * 8, 0.0D);
          i4.setDouble(0 + i1 * 8, 0.0D);
          i2.setDouble(0 + i1 * 8, 0.0D);
        } 
        b2 = 0;
        byte b = -1;
        i1 = j - i;
        int i6 = i1 + 1;
        int i7 = i1;
        int i8 = i1 + -1;
        for (byte b3 = 0; Integer.compareUnsigned(i, b3) > 0; b3++) {
          double d1;
          if (Integer.compareUnsigned(m, b3) <= 0) {
            d1 = 0.0D;
          } else {
            d1 = ptr1.getDouble(0 + b3 * 8);
          } 
          double d2 = d1;
          i2.setDouble(0 + i7 * 8, 0.0D);
          i7++;
          int i9 = i6 + b3;
          for (byte b4 = b3; Integer.compareUnsigned(i, b4) > 0; b4++) {
            double d4;
            double d3 = doublePtr5.getDouble(0 + b2 * 8);
            b2++;
            if (Integer.compareUnsigned(m, b4) <= 0) {
              d4 = 0.0D;
            } else {
              d4 = ptr1.getDouble(0 + b4 * 8);
            } 
            d1 = d4;
            if (i + -1 != b3) {
              i2.setDouble(0 + i7 * 8, -d4);
              if (i + -1 != b4) {
                i2.setDouble(0 + i9 * 8, i2.getDouble(0 + i9 * 8) - d2);
                i2.setDouble(0 + ++b * 8, -1.0D);
              } 
            } 
            i2.setDouble(0 + i1 * 8, -d1 * d2);
            if (Integer.compareUnsigned(++i8, j) >= 0)
              i8 = 0; 
            i2.setDouble(0 + i8 * 8, i2.getDouble(0 + i8 * 8) + 1.0D);
            inclu2(j, i2.pointerPlus(0), doublePtr2.pointerPlus(0), d3, ptr2.pointerPlus(0), i3.pointerPlus(0), i4.pointerPlus(0));
            i2.setDouble(0 + i8 * 8, 0.0D);
            if (i + -1 != b4) {
              i2.setDouble(0 + i9 * 8, 0.0D);
              i9++;
              i2.setDouble(0 + b * 8, 0.0D);
            } 
          } 
        } 
        int i5 = n + -1;
        m = j + -1;
        for (b1 = 0; Integer.compareUnsigned(b1, j) < 0; b1++) {
          double d = i4.getDouble(0 + m * 8);
          n = j + -1;
          for (byte b4 = 0; Integer.compareUnsigned(b4, b1) < 0; b4++) {
            d -= i3.getDouble(0 + i5 * 8) * ptr2.getDouble(0 + n * 8);
            i5--;
            n--;
          } 
          ptr2.setDouble(0 + m * 8, d);
          m--;
        } 
        i3 = i1;
        for (i4 = 0; Integer.compareUnsigned(i, i4) > 0; i4++) {
          i2.setDouble(0 + i4 * 8, ptr2.getDouble(0 + i3 * 8));
          i3++;
        } 
        i3 = j + -1;
        i4 = i1 + -1;
        for (i5 = 0; Integer.compareUnsigned(i5, i1) < 0; i5++) {
          ptr2.setDouble(0 + i3 * 8, ptr2.getDouble(0 + i4 * 8));
          i3--;
          i4--;
        } 
        for (i3 = 0; Integer.compareUnsigned(i, i3) > 0; i3++)
          ptr2.setDouble(0 + i3 * 8, i2.getDouble(0 + i3 * 8)); 
      } 
      int i2 = i + -1;
      j = j;
      while (i2 != 0) {
        for (i3 = i + -1; Integer.compareUnsigned(i3, i2) >= 0; i3--)
          ptr2.setDouble(0 + (i * i2 + i3) * 8, ptr2.getDouble(0 + --j * 8)); 
        i2--;
      } 
      for (j = 0; Integer.compareUnsigned(i + -1, j) > 0; j++) {
        for (i2 = j + 1; Integer.compareUnsigned(i, i2) > 0; i2++)
          ptr2.setDouble(0 + (i * i2 + j) * 8, ptr2.getDouble(0 + (i * j + i2) * 8)); 
      } 
      return sEXP1;
    } 
    if (m != 0) {
      ptr2.setDouble(0, 1.0D / (1.0D - b1.getDouble(0) * b1.getDouble(0)));
    } else {
      ptr2.setDouble(0, 1.0D);
    } 
    return sEXP1;
  }
  
  public static SEXP getQ0bis(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3) {
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    SEXP sEXP = (SEXP)BytePtr.of(0).getArray();
    sEXP = (SEXP)BytePtr.of(0).getArray();
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    sEXP = (SEXP)BytePtr.of(0).getArray();
    int k = Rinternals.LENGTH(paramSEXP1);
    int j = Rinternals.LENGTH(paramSEXP2);
    Ptr ptr1 = Rinternals2.REAL(paramSEXP1);
    Ptr ptr2 = Rinternals2.REAL(paramSEXP2);
    int i = Math.max(j + 1, k);
    paramSEXP2 = Rinternals.Rf_allocMatrix(14, i, i);
    Rinternals.Rf_protect(paramSEXP2);
    Ptr ptr3 = Rinternals2.REAL(paramSEXP2);
    ptr3.pointerPlus(0).memset(0, i * i * 8);
    DoublePtr doublePtr = DoublePtr.malloc((j + 1) * 8);
    doublePtr.setDouble(0, 1.0D);
    int m;
    for (m = 1; j + 1 > m; m++)
      doublePtr.setDouble(0 + m * 8, ptr2.getDouble(0 + (m + -1) * 8)); 
    if (k > 0) {
      m = Math.max(k + j, k + 1);
      SEXP sEXP1 = Rinternals.Rf_protect(Rinternals.Rf_allocMatrix(14, m, m));
      SEXP sEXP2 = Rinternals.Rf_protect(Rinternals.Rf_allocVector(14, m));
      Ptr ptr5 = Rinternals2.REAL(sEXP1);
      Ptr ptr6 = Rinternals2.REAL(sEXP2);
      DoublePtr doublePtr2 = DoublePtr.malloc((k + 1) * 8);
      doublePtr2.setDouble(0, 1.0D);
      byte b3;
      for (b3 = 1; k + 1 > b3; b3++)
        doublePtr2.setDouble(0 + b3 * 8, -ptr1.getDouble(0 + (b3 + -1) * 8)); 
      ptr5.pointerPlus(0).memset(0, m * m * 8);
      for (b3 = 0; b3 < m; b3++) {
        for (byte b4 = b3; b4 < m && b4 - b3 < k + 1; b4++)
          ptr5.setDouble(0 + (b3 * m + b4) * 8, ptr5.getDouble(0 + (b3 * m + b4) * 8) + doublePtr2.getDouble(0 + (b4 - b3) * 8)); 
      } 
      for (b3 = 0; b3 < m; b3++) {
        for (byte b4 = 1; b4 < m && b3 + b4 < k + 1; b4++)
          ptr5.setDouble(0 + (b4 * m + b3) * 8, ptr5.getDouble(0 + (b4 * m + b3) * 8) + doublePtr2.getDouble(0 + (b3 + b4) * 8)); 
      } 
      ptr6.setDouble(0, 1.0D);
      byte b2;
      for (b2 = 1; b2 < m; b2++)
        ptr6.setDouble(0 + b2 * 8, 0.0D); 
      Ptr ptr4 = Rinternals2.REAL(Rinternals.Rf_protect(Rinternals.Rf_eval(Rinternals.Rf_protect(Rinternals.Rf_lang4(Rinternals.Rf_install(new BytePtr("solve.default\000".getBytes(), 0)), sEXP1, sEXP2, paramSEXP3)), Rinternals.R_BaseEnv())));
      for (m = 0; m < i; m++) {
        for (int n = m; n < i; n++) {
          for (byte b4 = 0; m + b4 < k; b4++) {
            for (byte b5 = b4; b5 - b4 < j + 1; b5++) {
              for (b2 = 0; n + b2 < k; b2++) {
                for (b3 = b2; b3 - b2 < j + 1; b3++)
                  ptr3.setDouble(0 + (i * m + n) * 8, ptr3.getDouble(0 + (i * m + n) * 8) + ptr1.getDouble(0 + (m + b4) * 8) * ptr1.getDouble(0 + (n + b2) * 8) * doublePtr.getDouble(0 + (b5 - b4) * 8) * doublePtr.getDouble(0 + (b3 - b2) * 8) * ptr4.getDouble(0 + Math.abs(b5 - b3) * 8)); 
              } 
            } 
          } 
        } 
      } 
      DoublePtr doublePtr1 = DoublePtr.malloc(j * 8);
      if (j > 0)
        for (m = 0; m < j; m++) {
          doublePtr1.setDouble(0 + m * 8, doublePtr.getDouble(0 + m * 8));
          for (int n = Math.max(m - k, 0); n < m; n++)
            doublePtr1.setDouble(0 + m * 8, doublePtr1.getDouble(0 + m * 8) - doublePtr1.getDouble(0 + n * 8) * doublePtr2.getDouble(0 + (m - n) * 8)); 
        }  
      for (byte b1 = 0; b1 < i; b1++) {
        for (m = b1; m < i; m++) {
          byte b4;
          for (b4 = 0; b1 + b4 < k; b4++) {
            for (int n = b4 + 1; m + n < j + 1; n++)
              ptr3.setDouble(0 + (i * b1 + m) * 8, ptr3.getDouble(0 + (i * b1 + m) * 8) + ptr1.getDouble(0 + (b1 + b4) * 8) * doublePtr.getDouble(0 + (m + n) * 8) * doublePtr1.getDouble(0 + (n - b4 + -1) * 8)); 
          } 
          for (b4 = 0; m + b4 < k; b4++) {
            for (int n = b4 + 1; b1 + n < j + 1; n++)
              ptr3.setDouble(0 + (i * b1 + m) * 8, ptr3.getDouble(0 + (i * b1 + m) * 8) + ptr1.getDouble(0 + (m + b4) * 8) * doublePtr.getDouble(0 + (b1 + n) * 8) * doublePtr1.getDouble(0 + (n - b4 + -1) * 8)); 
          } 
        } 
      } 
    } 
    byte b;
    for (b = 0; b < i; b++) {
      for (k = b; k < i; k++) {
        for (byte b1 = 0; k + b1 < j + 1; b1++)
          ptr3.setDouble(0 + (i * b + k) * 8, ptr3.getDouble(0 + (i * b + k) * 8) + doublePtr.getDouble(0 + (b + b1) * 8) * doublePtr.getDouble(0 + (k + b1) * 8)); 
      } 
    } 
    for (b = 0; b < i; b++) {
      for (j = b + 1; j < i; j++)
        ptr3.setDouble(0 + (i * j + b) * 8, ptr3.getDouble(0 + (i * b + j) * 8)); 
    } 
    return paramSEXP2;
  }
  
  public static void inclu2(int paramInt, Ptr paramPtr1, Ptr paramPtr2, double paramDouble, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5) {
    byte b;
    for (b = 0; Integer.compareUnsigned(b, paramInt) < 0; b++)
      paramPtr2.setDouble(b * 8, paramPtr1.getDouble(b * 8)); 
    int i = 0;
    for (b = 0; Integer.compareUnsigned(b, paramInt) < 0; b++) {
      if (paramPtr2.getDouble(b * 8) == 0.0D) {
        i = i + paramInt - b + -1;
        continue;
      } 
      double d2 = paramPtr2.getDouble(b * 8);
      double d3 = paramPtr3.getDouble(b * 8);
      double d1 = d2 * d2 + d3;
      paramPtr3.setDouble(b * 8, d1);
      double d4 = d3 / d1;
      double d5 = d2 / d1;
      for (int j = b + 1; Integer.compareUnsigned(j, paramInt) < 0; j++) {
        d1 = paramPtr4.getDouble(i * 8);
        double d = paramPtr2.getDouble(j * 8) - d2 * d1;
        paramPtr2.setDouble(j * 8, d);
        paramPtr4.setDouble(i * 8, d5 * paramPtr2.getDouble(j * 8) + d4 * d1);
        i++;
      } 
      paramDouble -= paramPtr5.getDouble(b * 8) * d2;
      paramPtr5.setDouble(b * 8, d5 * paramDouble + paramPtr5.getDouble(b * 8) * d4);
      if (d3 != 0.0D)
        continue; 
      break;
    } 
  }
  
  public static void invpartrans(int paramInt, Ptr paramPtr1, Ptr paramPtr2) {
    double[] arrayOfDouble = new double[100];
    if (paramInt > 100)
      Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("can only transform 100 pars in arima0\000".getBytes(), 0)), new Object[0]); 
    for (byte b = 0; b < paramInt; b++) {
      int j = b * 8;
      paramPtr2.setDouble(j, paramPtr1.getDouble(b * 8));
      arrayOfDouble[b] = paramPtr2.getDouble(j);
    } 
    int i;
    for (i = paramInt + -1; i > 0; i--) {
      double d = paramPtr2.getDouble(i * 8);
      byte b1;
      for (b1 = 0; b1 < i; b1++)
        arrayOfDouble[b1] = (paramPtr2.getDouble(b1 * 8) + paramPtr2.getDouble((i - b1 + -1) * 8) * d) / (1.0D - d * d); 
      for (b1 = 0; b1 < i; b1++)
        paramPtr2.setDouble(b1 * 8, arrayOfDouble[b1]); 
    } 
    for (i = 0; i < paramInt; i++)
      paramPtr2.setDouble(i * 8, Stdlib.atanh(paramPtr2.getDouble(i * 8))); 
  }
  
  public static void partrans(int paramInt, Ptr paramPtr1, Ptr paramPtr2) {
    double[] arrayOfDouble = new double[100];
    if (paramInt > 100)
      Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("can only transform 100 pars in arima0\000".getBytes(), 0)), new Object[0]); 
    for (byte b2 = 0; b2 < paramInt; b2++) {
      int i = b2 * 8;
      paramPtr2.setDouble(i, Mathlib.tanh(paramPtr1.getDouble(b2 * 8)));
      arrayOfDouble[b2] = paramPtr2.getDouble(i);
    } 
    for (byte b1 = 1; b1 < paramInt; b1++) {
      double d = paramPtr2.getDouble(b1 * 8);
      byte b;
      for (b = 0; b < b1; b++)
        arrayOfDouble[b] = arrayOfDouble[b] - paramPtr2.getDouble((b1 - b + -1) * 8) * d; 
      for (b = 0; b < b1; b++)
        paramPtr2.setDouble(b * 8, arrayOfDouble[b]); 
    } 
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/stats-0.9.2724.jar!/org/renjin/stats/arima__.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */