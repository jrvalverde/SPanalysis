package org.renjin.stats;

import org.renjin.appl.Appl;
import org.renjin.gcc.runtime.DoublePtr;
import org.renjin.gcc.runtime.IntPtr;
import org.renjin.gcc.runtime.Ptr;

public class sslvrg__ {
  static {
  
  }
  
  public static void sslvrg_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, Ptr paramPtr11, Ptr paramPtr12, Ptr paramPtr13, Ptr paramPtr14, Ptr paramPtr15, Ptr paramPtr16, Ptr paramPtr17, Ptr paramPtr18, Ptr paramPtr19, Ptr paramPtr20, Ptr paramPtr21, Ptr paramPtr22, Ptr paramPtr23, Ptr paramPtr24, Ptr paramPtr25, Ptr paramPtr26, Ptr paramPtr27, Ptr paramPtr28, Ptr paramPtr29, Ptr paramPtr30) {
    int[] arrayOfInt1 = new int[1];
    double[] arrayOfDouble1 = new double[1];
    double[] arrayOfDouble2 = new double[16];
    double[] arrayOfDouble3 = new double[4];
    int[] arrayOfInt2 = new int[1];
    int[] arrayOfInt3 = new int[1];
    int[] arrayOfInt4 = new int[1];
    arrayOfInt2[0] = 0;
    arrayOfInt3[0] = 0;
    arrayOfInt4[0] = 0;
    Integer.toUnsignedLong(Math.max(paramPtr9.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr9.getInt(), 0));
    int j = Math.max(paramPtr28.getInt(), 0);
    Integer.toUnsignedLong(Math.max(j * paramPtr9.getInt(), 0));
    int k = j ^ 0xFFFFFFFF;
    Integer.toUnsignedLong(Math.max(paramPtr9.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr9.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr9.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr9.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr9.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr9.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr9.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr9.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr7.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr7.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr9.getInt() + 4, 0));
    int m = Math.max(paramPtr28.getInt(), 0);
    Integer.toUnsignedLong(Math.max(m * paramPtr9.getInt(), 0));
    int n = m ^ 0xFFFFFFFF;
    Integer.toUnsignedLong(Math.max(Math.max(paramPtr29.getInt(), 0) * paramPtr9.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr7.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr7.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr7.getInt(), 0));
    arrayOfInt3[0] = paramPtr9.getInt() + 4;
    arrayOfInt4[0] = 1;
    int i1 = paramPtr9.getInt();
    byte b2 = 1;
    if (1 <= i1)
      while (true) {
        boolean bool;
        paramPtr10.setAlignedDouble(b2 + -1, paramPtr16.getAlignedDouble(b2 + -1));
        paramPtr25.setAlignedDouble(b2 * j + k + 4, paramPtr17.getAlignedDouble(b2 + -1) + paramPtr15.getDouble() * paramPtr21.getAlignedDouble(b2 + -1));
        if (b2 != i1) {
          bool = false;
        } else {
          bool = true;
        } 
        b2++;
        if (!bool)
          continue; 
        break;
      }  
    int i = paramPtr9.getInt() + -1;
    byte b1 = 1;
    if (1 <= i)
      while (true) {
        boolean bool;
        paramPtr25.setAlignedDouble((b1 + 1) * j + k + 3, paramPtr18.getAlignedDouble(b1 + -1) + paramPtr15.getDouble() * paramPtr22.getAlignedDouble(b1 + -1));
        if (b1 != i) {
          bool = false;
        } else {
          bool = true;
        } 
        b1++;
        if (!bool)
          continue; 
        break;
      }  
    i = paramPtr9.getInt() + -2;
    b1 = 1;
    if (1 <= i)
      while (true) {
        boolean bool;
        paramPtr25.setAlignedDouble((b1 + 2) * j + k + 2, paramPtr19.getAlignedDouble(b1 + -1) + paramPtr15.getDouble() * paramPtr23.getAlignedDouble(b1 + -1));
        if (b1 != i) {
          bool = false;
        } else {
          bool = true;
        } 
        b1++;
        if (!bool)
          continue; 
        break;
      }  
    i = paramPtr9.getInt() + -3;
    b1 = 1;
    if (1 <= i)
      while (true) {
        boolean bool;
        paramPtr25.setAlignedDouble((b1 + 3) * j + k + 1, paramPtr20.getAlignedDouble(b1 + -1) + paramPtr15.getDouble() * paramPtr24.getAlignedDouble(b1 + -1));
        if (b1 != i) {
          bool = false;
        } else {
          bool = true;
        } 
        b1++;
        if (!bool)
          continue; 
        break;
      }  
    Appl.dpbfa_(paramPtr25, paramPtr28, paramPtr9, (Ptr)new IntPtr(new int[] { 3 }, 0), paramPtr30);
    if (paramPtr30.getInt() == 0) {
      Appl.dpbsl_(paramPtr25, paramPtr28, paramPtr9, (Ptr)new IntPtr(new int[] { 3 }, 0), paramPtr10);
      int i2 = paramPtr7.getInt();
      i = 1;
      if (1 <= i2)
        while (true) {
          arrayOfDouble1[0] = paramPtr3.getAlignedDouble(i + -1);
          paramPtr11.setAlignedDouble(i + -1, bvalue__.bvalue_(paramPtr8, paramPtr10, paramPtr9, (Ptr)new IntPtr(new int[] { 4 }, 0), (Ptr)new DoublePtr(arrayOfDouble1, 0), (Ptr)new IntPtr(new int[] { 0 }, 0)));
          if (i != i2) {
            b1 = 0;
          } else {
            b1 = 1;
          } 
          i++;
          if (b1 == 0)
            continue; 
          break;
        }  
      if (paramPtr14.getInt() > 0) {
        int i3;
        byte b3;
        boolean bool;
        sinerp__.sinerp_(paramPtr25, paramPtr28, paramPtr9, paramPtr26, paramPtr27, paramPtr29, (Ptr)new IntPtr(new int[] { 0 }, 0));
        int i5 = paramPtr7.getInt();
        i2 = 1;
        if (1 <= i5)
          while (true) {
            arrayOfDouble1[0] = paramPtr3.getAlignedDouble(i2 + -1);
            arrayOfInt1[0] = paramPtr9.getInt() + 1;
            arrayOfInt4[0] = Appl.interv_(paramPtr8, (Ptr)new IntPtr(arrayOfInt1, 0), (Ptr)new DoublePtr(arrayOfDouble1, 0), (Ptr)new IntPtr(new int[] { 0 }, 0), (Ptr)new IntPtr(new int[] { 0 }, 0), (Ptr)new IntPtr(arrayOfInt4, 0), (Ptr)new IntPtr(arrayOfInt2, 0));
            if (arrayOfInt2[0] != -1) {
              if (arrayOfInt2[0] == 1) {
                arrayOfInt4[0] = paramPtr9.getInt();
                arrayOfDouble1[0] = paramPtr8.getAlignedDouble(paramPtr9.getInt()) - 1.0E-11D;
              } 
            } else {
              arrayOfInt4[0] = 4;
              arrayOfDouble1[0] = paramPtr8.getAlignedDouble(3) + 1.0E-11D;
            } 
            i = arrayOfInt4[0] + -3;
            bsplvd__.bsplvd_(paramPtr8, (Ptr)new IntPtr(arrayOfInt3, 0), (Ptr)new IntPtr(new int[] { 4 }, 0), (Ptr)new DoublePtr(arrayOfDouble1, 0), (Ptr)new IntPtr(arrayOfInt4, 0), (Ptr)new DoublePtr(arrayOfDouble2, 0), (Ptr)new DoublePtr(arrayOfDouble3, 0), (Ptr)new IntPtr(new int[] { 1 }, 0));
            double d8 = arrayOfDouble3[0];
            double d7 = arrayOfDouble3[1];
            double d6 = arrayOfDouble3[2];
            double d5 = arrayOfDouble3[3];
            double d4 = paramPtr5.getAlignedDouble(i2 + -1) * paramPtr5.getAlignedDouble(i2 + -1);
            paramPtr12.setAlignedDouble(i2 + -1, (d8 * d8 * paramPtr26.getAlignedDouble(i * m + n + 4) + paramPtr26.getAlignedDouble(i * m + n + 3) * 2.0D * d8 * d7 + paramPtr26.getAlignedDouble(i * m + n + 2) * 2.0D * d8 * d6 + paramPtr26.getAlignedDouble(i * m + n + 1) * 2.0D * d8 * d5 + paramPtr26.getAlignedDouble((i + 1) * m + n + 4) * d7 * d7 + paramPtr26.getAlignedDouble((i + 1) * m + n + 3) * 2.0D * d7 * d6 + paramPtr26.getAlignedDouble((i + 1) * m + n + 2) * 2.0D * d7 * d5 + paramPtr26.getAlignedDouble((i + 2) * m + n + 4) * d6 * d6 + paramPtr26.getAlignedDouble((i + 2) * m + n + 3) * 2.0D * d6 * d5 + paramPtr26.getAlignedDouble((i + 3) * m + n + 4) * d5 * d5) * d4);
            if (i2 != i5) {
              i = 0;
            } else {
              i = 1;
            } 
            i2++;
            if (i == 0)
              continue; 
            break;
          }  
        double d1 = 0.0D;
        if (paramPtr14.getInt() != 1) {
          if (paramPtr14.getInt() != 2) {
            int i6 = paramPtr7.getInt();
            byte b = 1;
            if (1 <= i6)
              while (true) {
                d1 = paramPtr12.getAlignedDouble(b + -1) + d1;
                if (b != i6) {
                  bool = false;
                } else {
                  bool = true;
                } 
                b++;
                if (!bool)
                  continue; 
                break;
              }  
            if (paramPtr14.getInt() != 3) {
              paramPtr13.setDouble(d1 - paramPtr2.getDouble());
              return;
            } 
            paramPtr13.setDouble((paramPtr2.getDouble() - d1) * (paramPtr2.getDouble() - d1) + 3.0D);
          } 
          paramPtr13.setDouble(0.0D);
          i3 = paramPtr7.getInt();
          b3 = 1;
          if (1 <= i3)
            while (true) {
              boolean bool1;
              paramPtr13.setDouble((bool.getAlignedDouble(b3 + -1) - paramPtr11.getAlignedDouble(b3 + -1)) * paramPtr5.getAlignedDouble(b3 + -1) / (1.0D - paramPtr12.getAlignedDouble(b3 + -1)) * (bool.getAlignedDouble(b3 + -1) - paramPtr11.getAlignedDouble(b3 + -1)) * paramPtr5.getAlignedDouble(b3 + -1) / (1.0D - paramPtr12.getAlignedDouble(b3 + -1)) + paramPtr13.getDouble());
              if (b3 != i3) {
                bool1 = false;
              } else {
                bool1 = true;
              } 
              b3++;
              if (!bool1)
                continue; 
              break;
            }  
          paramPtr13.setDouble(paramPtr13.getDouble() / paramPtr7.getInt());
          return;
        } 
        double d2 = paramPtr6.getDouble();
        double d3 = 0.0D;
        int i4 = paramPtr7.getInt();
        byte b4 = 1;
        if (1 <= i4)
          while (true) {
            boolean bool1;
            d2 += (bool.getAlignedDouble(b4 + -1) - paramPtr11.getAlignedDouble(b4 + -1)) * paramPtr5.getAlignedDouble(b4 + -1) * (bool.getAlignedDouble(b4 + -1) - paramPtr11.getAlignedDouble(b4 + -1)) * paramPtr5.getAlignedDouble(b4 + -1);
            d1 = paramPtr12.getAlignedDouble(b4 + -1) + d1;
            d3 += paramPtr5.getAlignedDouble(b4 + -1) * paramPtr5.getAlignedDouble(b4 + -1);
            if (b4 != i4) {
              bool1 = false;
            } else {
              bool1 = true;
            } 
            b4++;
            if (!bool1)
              continue; 
            break;
          }  
        paramPtr13.setDouble(d2 / d3 / (1.0D - (b3.getDouble() + i3.getDouble() * d1) / d3) * (1.0D - (b3.getDouble() + i3.getDouble() * d1) / d3));
      } 
    } 
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/stats-0.9.2724.jar!/org/renjin/stats/sslvrg__.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */